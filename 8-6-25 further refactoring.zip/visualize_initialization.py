# -*- coding: utf-8 -*-
"""
Created on Sun Aug  3 08:44:57 2025

@author: chris and christine
"""
import matplotlib.pyplot as plt
import numpy as np
import config
from agent_initialization import initialize_agents


def plot_mu_sigma_fields(agents, field="belief"):
    for i, agent in enumerate(agents):
        if field == "belief":
            mu = agent.mu_q_field
            sigma = agent.sigma_q_field
        elif field == "model":
            mu = agent.mu_p_field
            sigma = agent.sigma_p_field
        else:
            raise ValueError(f"Invalid field type: {field}")

        mask = agent.mask
        K = mu.shape[-1]

        # ─── Plot μ components ───
        for k in range(K):
            plt.figure(figsize=(4, 4))
            plt.title(f"Agent {i} — μ[{k}] ({field})")
            plt.imshow(mu[..., k], cmap='coolwarm')
            plt.colorbar()
            plt.tight_layout()
            plt.show()

        # ─── Plot Σ diagonal entries ───
        for k in range(K):
            plt.figure(figsize=(4, 4))
            plt.title(f"Agent {i} — Σ[{k},{k}] ({field})")
            plt.imshow(sigma[..., k, k], cmap='viridis')
            plt.colorbar()
            plt.tight_layout()
            plt.show()

        # ─── Trace of Σ ───
        trace_sigma = np.trace(sigma, axis1=-2, axis2=-1)
        plt.figure(figsize=(4, 4))
        plt.title(f"Agent {i} — Tr(Σ) ({field})")
        plt.imshow(trace_sigma, cmap='inferno')
        plt.colorbar()
        plt.tight_layout()
        plt.show()


if __name__ == "__main__":
    seed = 42
    domain_size = (50, 50)
    N = 2
    K_q = config.K_q
    K_p = config.K_p
    d = 3  # SO(3)

    agents = initialize_agents(seed, domain_size, N, K_q, K_p, d)
    plot_mu_sigma_fields(agents, field="belief")

