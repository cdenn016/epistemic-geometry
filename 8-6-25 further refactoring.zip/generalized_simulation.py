
import os
os.environ["OMP_NUM_THREADS"] = "1"
os.environ["MKL_NUM_THREADS"] = "1"
os.environ["NUMEXPR_NUM_THREADS"] = "1"  # Optional: just in case
os.environ["OPENBLAS_NUM_THREADS"]= "1"



# Standard library
import os
import time

# Third-party
import pickle
import pandas as pd
from update_rules import synchronous_step
# Local configuration & utilities

from config_utils import set_config_from_params
from get_generators import get_generators
# run_simulation.py (cleaner entrypoint)
import sys


# I/O helpers
from generalized_io_utils import (
    save_step,
    load_checkpoint,
    find_resume_step,
    save_config_to_readme,
)

# Agent construction
from agent_initialization import initialize_agents, initialize_agent_gradients

import config

#from metrics import log_all_metrics, full_field_logger
from generalized_diagnostics_metrics import log_all_metrics, full_field_logger




def run_simulation(
    outdir="checkpoints",
    resume=False,
    log_metrics=True,
    log_fields=True,
    num_cores=None,
    params=None,
):
    
    os.makedirs(outdir, exist_ok=True)
    save_config_to_readme(outdir)

    if num_cores is None:
        num_cores = 18

    params = params or {}
    G_q = params.get("generators_q")
    G_p = params.get("generators_p")

    # ─────────── Initialization ─────────────
    if resume:
        agents, _ = load_checkpoint(outdir)
        step_start = find_resume_step(outdir)
    else:
        agents = initialize_agents(
            seed=getattr(config, "seed", None),
            domain_size=config.domain_size,
            N=config.N,
            K_q=config.K_q,
            K_p=config.K_p,
            lie_algebra_dim=3,
            visualize=False,
            fixed_location=True,
        )
        step_start = 0
        for agent in agents:
            initialize_agent_gradients(agent, config)
            agent.generators_q = G_q
            agent.generators_p = G_p

    metric_log = []
    print(f"[RUN] Starting simulation at step {step_start} with {num_cores} cores")

    # ─────────── Simulation Loop ─────────────
    for step in range(step_start, config.steps):
        print(f"\n[STEP {step}] -----------------------------")

        t0 = time.perf_counter()
        step_params = dict(params)
        step_params["step"] = step

        agents = synchronous_step(agents, G_q, G_p, params=step_params, n_jobs=num_cores)
        print(f"[TIMER] synchronous update: {time.perf_counter() - t0:.3f}s")

        # (B) Log metrics
        if log_metrics:
            t0 = time.perf_counter()
            m = log_all_metrics(agents, step=step, params=params, n_jobs=num_cores)
            metric_log.append({"step": step, **m})
            print(f"[Energy Totals @ step {step}]")
            print(f"  Self belief      = {m['e_self']:.4e}")
            print(f"  Feedback model   = {m['e_feedback']:.4e}")
            print(f"  Belief alignment = {m['e_align']:.4e}")
            print(f"  Model alignment  = {m['e_mod_align']:.4e}")
            print(f"  Model Mass       = {m['e_mass_mod']:.4e}")
            print(f"  Belief Mass      = {m['e_mass']:.4e}")
            print(f"  Belief Curvature = {m['e_curv']:.4e}")
            print(f"  Model Curvature  = {m['e_curv_mod']:.4e}")
            print(f"[TIMER] log_all_metrics_fused: {time.perf_counter() - t0:.3f}s")

        # (C) Dump full fields
        if log_fields and getattr(config, "log_full_fields", False):
            t0_fields = time.perf_counter()
            field_dir = os.path.join(outdir, "fields")
            full_field_logger(agents, step, field_dir)
            print(f"[TIMER] full_step_field_logger: {time.perf_counter() - t0_fields:.3f}s")

        # (D) Save checkpoint
        for A in agents:
            A.clear_omega_cache()
            A.clear_fisher_caches()
        save_step(agents, outdir, step)
        print(f"[SAVE] Checkpoint → {outdir}/step_{step:04d}.pkl")

    # ─────────── Final Output ─────────────
    if log_metrics:
        with open(os.path.join(outdir, "metric_log.pkl"), "wb") as f:
            pickle.dump(metric_log, f)
        print(f"[SAVE] Metrics log → {outdir}/metric_log.pkl")

        rows = []
        for A in agents:
            for entry in A.metrics_log:
                rows.append({"agent": A.id, **entry})
        pd.DataFrame(rows).to_csv(os.path.join(outdir, "per_agent_metrics.csv"), index=False)
        print("[SAVE] Per-agent metrics → per_agent_metrics.csv")

    print("[DONE] Simulation completed.")
    return agents, metric_log


if __name__ == "__main__":
    

    # ─────────────────────────────────────────────
    # 1. Optional param override
    # ─────────────────────────────────────────────
    if len(sys.argv) > 1:
        with open(sys.argv[1], "rb") as f:
            param_override = pickle.load(f)
        set_config_from_params(param_override)
    else:
        param_override = {}

    # ─────────────────────────────────────────────
    # 2. Load SO(3) generators for q and p fibers
    # ─────────────────────────────────────────────
    G_q, meta_q = get_generators(config.group_name, config.K_q, return_meta=True)
    G_p, meta_p = get_generators(config.group_name, config.K_p, return_meta=True)

    # ─────────────────────────────────────────────
    # 3. Bundle runtime-only params
    # ─────────────────────────────────────────────
    runtime_params = {
        "generators_q": G_q,
        "generators_p": G_p,
    }

    # ─────────────────────────────────────────────
    # 4. Run the simulation
    # ─────────────────────────────────────────────
    run_simulation(
        outdir="checkpoints",
        resume=False,
        log_metrics=True,
        log_fields=True ,
        params=runtime_params,
    )
