import numpy as np
import matplotlib.pyplot as plt
import os
from numpy.linalg import inv
from generalized_io_utils import load_all_checkpoints, load_latest_checkpoint
from get_generators import get_generators
from generalized_omega import compute_field_strength
from numerical_utils import safe_inv
import config

def compute_fisher_pullback_mu_sigma(mu, Sigma, mask=None, eps=1e-8):
    """
    Compute pullback Fisher metric G_{μν}(c) from μ, Σ fields.
    """
    if mask is not None:
        mu    = mu * mask[..., None]
        Sigma = Sigma * mask[..., None, None]

    Sigma_inv = safe_inv(Sigma, eps=eps)

    dmu_dx     = np.gradient(mu, axis=0)
    dmu_dy     = np.gradient(mu, axis=1)
    dSigma_dx  = np.gradient(Sigma, axis=0)
    dSigma_dy  = np.gradient(Sigma, axis=1)

    G_xx = np.einsum("...i,...ij,...j->...", dmu_dx, Sigma_inv, dmu_dx) + \
           0.5 * np.einsum("...ij,...jk,...kl,...li->...", Sigma_inv, dSigma_dx, Sigma_inv, dSigma_dx)

    G_xy = np.einsum("...i,...ij,...j->...", dmu_dx, Sigma_inv, dmu_dy) + \
           0.5 * np.einsum("...ij,...jk,...kl,...li->...", Sigma_inv, dSigma_dx, Sigma_inv, dSigma_dy)

    G_yy = np.einsum("...i,...ij,...j->...", dmu_dy, Sigma_inv, dmu_dy) + \
           0.5 * np.einsum("...ij,...jk,...kl,...li->...", Sigma_inv, dSigma_dy, Sigma_inv, dSigma_dy)

    G = np.stack([
        np.stack([G_xx, G_xy], axis=-1),
        np.stack([G_xy, G_yy], axis=-1)
    ], axis=-2)

    if mask is not None:
        G *= mask[..., None, None]

    return G

def compute_pullback_curl_eta(G_field: np.ndarray, dx: float = 1.0):
    dG_dx = (np.roll(G_field, -1, axis=0) - np.roll(G_field, 1, axis=0)) / (2 * dx)
    dG_dy = (np.roll(G_field, -1, axis=1) - np.roll(G_field, 1, axis=1)) / (2 * dx)
    return dG_dx - dG_dy

def compare_curvature_to_pullback(F: np.ndarray, curl_G: np.ndarray):
    norm_F = np.linalg.norm(F, ord="fro", axis=(-2, -1))
    norm_curl_G = np.linalg.norm(curl_G, ord="fro", axis=(-2, -1))
    mask = np.isfinite(norm_F) & np.isfinite(norm_curl_G)
    correlation = np.corrcoef(norm_F[mask].flatten(), norm_curl_G[mask].flatten())[0, 1]
    return norm_F, norm_curl_G, correlation

def run_diagnostics(checkpoint_path, load_latest=True):
    if load_latest:
        agents = load_latest_checkpoint(checkpoint_path)
    else:
        all_data = load_all_checkpoints(checkpoint_path)
        agents = all_data[-1]

    total_mask = np.sum([a.mask for a in agents], axis=0)

    mu_q = np.sum([a.mu_q_field * a.mask[..., None] for a in agents], axis=0) \
         / (total_mask[..., None] + 1e-8)

    sigma_q = np.sum([a.sigma_q_field * a.mask[..., None, None] for a in agents], axis=0) \
         / (total_mask[..., None, None] + 1e-8)

    phi = np.sum([a.phi * a.mask[..., None] for a in agents], axis=0) \
        / (total_mask[..., None] + 1e-8)

    G_pullback = compute_fisher_pullback_mu_sigma(mu_q, sigma_q)
    curl_G     = compute_pullback_curl_eta(G_pullback, dx=1.0)

    generators = get_generators(config.group_name, config.K_q)
    F_field    = compute_field_strength(phi, generators)["xy"]

    norm_F, norm_curl_G, correlation = compare_curvature_to_pullback(F_field, curl_G)

    plt.figure(figsize=(12, 6))
    plt.subplot(1, 2, 1)
    plt.imshow(norm_F, cmap='hot')
    plt.title("||F_{μν}||")
    plt.colorbar()

    plt.subplot(1, 2, 2)
    plt.imshow(norm_curl_G, cmap='hot')
    plt.title("||∇_{[μ} G_{ν]}||")
    plt.colorbar()

    plt.tight_layout()
    plt.show()

    print(f"[Fisher Curvature Diagnostic] Correlation = {correlation:.4f}")

if __name__ == "__main__":
    checkpoint_path = "checkpoints"
    run_diagnostics(checkpoint_path, load_latest=True)
