# -*- coding: utf-8 -*-
"""
Created on Wed Aug  6 12:27:32 2025

@author: chris and christine
"""



import numpy as np
import config
from numerical_utils import sanitize_sigma, safe_inv
from natural_gradient import apply_natural_gradient_batch


def accumulate_mu_sigma_gradient(agent_i, agents, params, mode):
    """
    Accumulate natural gradient ∇μ and ∇Σ for belief or model.

    Args:
        agent_i : current agent
        agents  : list of all agents
        params  : simulation parameters
        mode    : "belief" or "model"
    """
    # Euclidean gradient
    dmu, dsigma = compute_mu_sigma_gradient_euclidean(agent_i, agents, params, mode)

    if mode == "belief":
        mu_field    = agent_i.mu_q_field
        sigma_field = agent_i.sigma_q_field
        grad_mu     = "grad_mu_q"
        grad_sigma  = "grad_sigma_q"
    elif mode == "model":
        mu_field    = agent_i.mu_p_field
        sigma_field = agent_i.sigma_p_field
        grad_mu     = "grad_mu_p"
        grad_sigma  = "grad_sigma_p"
    else:
        raise ValueError(f"Unsupported mode: {mode}")


    # Natural gradient projection
    delta_mu, delta_sigma = apply_natural_gradient_batch(
        mu_field,
        sigma_field,
        dmu,
        dsigma,
        mask=agent_i.mask,
    )

    # Accumulate
    setattr(agent_i, grad_mu, getattr(agent_i, grad_mu) + delta_mu)
    setattr(agent_i, grad_sigma, getattr(agent_i, grad_sigma) + delta_sigma)





def compute_mu_sigma_gradient_euclidean(agent_i, agents, params, mode):
    eps = config.support_cutoff_eps

    if mode == "belief":
        alpha = params.get("alpha", config.alpha)
        beta = params.get("beta", config.beta)
        lambd = params.get("feedback_weight", config.feedback_weight)

        mu_q = agent_i.mu_q_field
        sigma_q = sanitize_sigma(agent_i.sigma_q_field, eps=eps)
        mu_p = agent_i.mu_p_field
        sigma_p = sanitize_sigma(agent_i.sigma_p_field, eps=eps)

        Phi = agent_i.bundle_morphism_q_to_p
        Phi_tilde = agent_i.bundle_morphism_p_to_q

        Omega_attr = "Omega_cache"
        mu_key = "mu_q_field"
        sigma_key = "sigma_q_field"

        # Pushforwards
        mu_p_push, sigma_p_push, sigma_p_push_inv = gaussian_pushforward(mu_p, sigma_p, Phi_tilde, eps=eps)
        mu_q_push, sigma_q_push, sigma_q_push_inv = gaussian_pushforward(mu_q, sigma_q, Phi, eps=eps)

        grad_self_mu, grad_self_sigma = grad_self_energy_belief(mu_q, sigma_q, mu_p_push, sigma_p_push_inv, eps=eps)
        grad_fb_mu, grad_fb_sigma = grad_feedback_energy_belief(mu_q, sigma_q, mu_p, mu_q_push, sigma_q_push, sigma_q_push_inv, sigma_p, Phi, eps=eps)

    elif mode == "model":
        alpha = params.get("alpha", config.alpha)
        beta = params.get("beta_model", config.beta_model)
        lambd = params.get("feedback_weight", config.feedback_weight)

        mu_p = agent_i.mu_p_field
        sigma_p = sanitize_sigma(agent_i.sigma_p_field, eps=eps)
        mu_q = agent_i.mu_q_field
        sigma_q = sanitize_sigma(agent_i.sigma_q_field, eps=eps)

        Phi = agent_i.bundle_morphism_q_to_p
        Phi_tilde = agent_i.bundle_morphism_p_to_q

        Omega_attr = "Omega_tilde_cache"
        mu_key = "mu_p_field"
        sigma_key = "sigma_p_field"

        # Pushforwards
        mu_p_push, sigma_p_push, sigma_p_push_inv = gaussian_pushforward(mu_p, sigma_p, Phi_tilde, eps=eps)
        mu_q_push, sigma_q_push, sigma_q_push_inv = gaussian_pushforward(mu_q, sigma_q, Phi, eps=eps)

        grad_self_mu, grad_self_sigma = grad_self_energy_model(mu_q, sigma_q, mu_p_push, sigma_p_push_inv, Phi_tilde, eps=eps)
        grad_fb_mu, grad_fb_sigma = grad_feedback_energy_model(
            mu_p, sigma_p,
            mu_q_push, sigma_q_push, sigma_q_push_inv,
            Phi,
            eps=eps
        )

    else:
        raise ValueError(f"Unsupported mode: {mode}")

    # Alignment
    dmu_align = 0
    dsigma_align = 0
    for neighbor in agent_i.neighbors:
        agent_j = agents[neighbor["id"]]
        Omega_ij = getattr(agent_i, Omega_attr)[agent_j.id]
        mu_j = getattr(agent_j, mu_key)
        sigma_j = sanitize_sigma(getattr(agent_j, sigma_key), eps=eps)

        mu_i = mu_p if mode == "model" else mu_q
        sigma_i = sigma_p if mode == "model" else sigma_q

        dmu_i, dsigma_i = grad_alignment_energy_source(
            mu_i,
            sigma_i,
            mu_j,
            sigma_j,
            Omega_ij,
            eps=eps
        )

        dmu_align += dmu_i
        dsigma_align += dsigma_i

    dmu_total = alpha * grad_self_mu + lambd * grad_fb_mu + beta * dmu_align
    dsigma_total = alpha * grad_self_sigma + lambd * grad_fb_sigma + beta * dsigma_align

    return dmu_total, dsigma_total





#==============================================================================
#
#                    FEEDBACK TERMS
#             everything validated below
#==============================================================================

# PATCHED grad_alignment_energy_source and grad_feedback_energy_belief to assume precomputed pushforwards

from numerical_utils import safe_inv, sanitize_sigma
import numpy as np


def grad_alignment_energy_source(mu_i, sigma_i, mu_j_t, sigma_j_t_inv, Omega_ij, eps=1e-8):
    """
    Compute ∇_{μᵢ} and ∇_{Σᵢ} of D_KL(qᵢ ‖ Ω qⱼ) or D_KL(pᵢ ‖ Ω̃ pⱼ)

    Args:
        mu_i         : (..., K)
        sigma_i      : (..., K, K)
        mu_j_t       : (..., K)      — transported mean Ω μⱼ
        sigma_j_t_inv: (..., K, K)   — inverse transported covariance (Ω Σⱼ Ωᵀ)⁻¹
        Omega_ij     : (..., K, K)
        eps          : regularization

    Returns:
        grad_mu_i     : (..., K)
        grad_sigma_i  : (..., K, K)
    """
    delta_mu = mu_i - mu_j_t
    grad_mu = np.einsum("...ij,...j->...i", sigma_j_t_inv, delta_mu)

    sigma_i_inv = safe_inv(sanitize_sigma(sigma_i, eps=eps), eps=eps)
    grad_sigma = 0.5 * (sigma_j_t_inv - sigma_i_inv)
    return grad_mu, grad_sigma



def grad_feedback_energy_belief(mu_q, sigma_q, mu_p, mu_q_push, sigma_q_push, sigma_q_push_inv, sigma_p, Phi, eps=1e-8):
    """
    Compute gradients ∂/∂μ_q and ∂/∂Σ_q of KL(p || Φ·q)

    Args:
        mu_q              : (..., K_q)
        sigma_q           : (..., K_q, K_q)
        mu_p              : (..., K_p)
        mu_q_push         : (..., K_p)
        sigma_q_push      : (..., K_p, K_p)
        sigma_q_push_inv  : (..., K_p, K_p)
        sigma_p           : (..., K_p, K_p)
        Phi               : (..., K_p, K_q)
        eps               : regularization constant

    Returns:
        grad_mu_q     : (..., K_q)
        grad_sigma_q  : (..., K_q, K_q)
    """
    delta_mu = mu_p - mu_q_push
    tmp = np.einsum("...ij,...j->...i", sigma_q_push_inv, delta_mu)
    grad_mu = -np.einsum("...ji,...j->...i", Phi, tmp)

    A = np.einsum("...i,...j->...ij", delta_mu, delta_mu)
    
    term1 = sigma_q_push_inv
    term2 = np.einsum("...ik,...kl,...lj->...ij", sigma_q_push_inv, A, sigma_q_push_inv)
    term3 = np.einsum("...ik,...kl,...lj->...ij", sigma_q_push_inv, sigma_p, sigma_q_push_inv)
    M = term1 - term2 - term3

    grad_sigma = 0.5 * np.einsum("...ki,...kl,...lj->...ij", Phi, M, Phi)
    return grad_mu, grad_sigma



def grad_feedback_energy_model(mu_p, sigma_p, mu_q_push, sigma_q_push, sigma_q_push_inv, Phi, eps=1e-8):
    """
    Compute gradients ∂/∂μ_p and ∂/∂Σ_p of KL(p || Φ·q)

    Args:
        mu_p              : (..., K_p)
        sigma_p           : (..., K_p, K_p)
        mu_q_push         : (..., K_p)
        sigma_q_push      : (..., K_p, K_p)
        sigma_q_push_inv  : (..., K_p, K_p)
        Phi               : (..., K_p, K_q)
        eps               : regularization epsilon

    Returns:
        grad_mu_p     : (..., K_p)
        grad_sigma_p  : (..., K_p, K_p)
    """
    delta_mu = mu_p - mu_q_push
    grad_mu = np.einsum("...ij,...j->...i", sigma_q_push_inv, delta_mu)

    sigma_p_inv = safe_inv(sigma_p, eps=eps)
    grad_sigma = 0.5 * (sigma_q_push_inv - sigma_p_inv)
    return grad_mu, grad_sigma





def grad_self_energy_belief(mu_q, sigma_q, mu_p_push, sigma_p_push_inv, eps=1e-8):
    """
    Compute gradients ∂/∂μ_q and ∂/∂Σ_q of KL(q || Φ̃·p)

    Args:
        mu_q             : (..., K_q)
        sigma_q          : (..., K_q, K_q)
        mu_p_push        : (..., K_q)        — Φ̃ μ_p
        sigma_p_push_inv : (..., K_q, K_q)   — (Φ̃ Σ_p Φ̃ᵀ)⁻¹
        eps              : regularization

    Returns:
        grad_mu_q      : (..., K_q)
        grad_sigma_q   : (..., K_q, K_q)
    """
    delta_mu = mu_q - mu_p_push
    grad_mu = np.einsum("...ij,...j->...i", sigma_p_push_inv, delta_mu)

    sigma_q_inv = safe_inv(sanitize_sigma(sigma_q, eps=eps), eps=eps)
    grad_sigma = 0.5 * (sigma_p_push_inv - sigma_q_inv)

    return grad_mu, grad_sigma





def grad_self_energy_model(mu_q, sigma_q, mu_p_push, sigma_p_push_inv, Phi_tilde, eps=1e-8):
    """
    Compute gradients ∂/∂μ_p and ∂/∂Σ_p of KL(q || Φ̃·p)

    Args:
        mu_q             : (..., K_q)
        sigma_q          : (..., K_q, K_q)
        mu_p_push        : (..., K_q)        — Φ̃ μ_p
        sigma_p_push_inv : (..., K_q, K_q)   — (Φ̃ Σ_p Φ̃ᵀ)⁻¹
        Phi_tilde        : (..., K_q, K_p)
        eps              : regularization

    Returns:
        grad_mu_p     : (..., K_p)
        grad_sigma_p  : (..., K_p, K_p)
    """
    delta_mu = mu_q - mu_p_push
    tmp = np.einsum("...ij,...j->...i", sigma_p_push_inv, delta_mu)
    grad_mu = -np.einsum("...ji,...j->...i", Phi_tilde, tmp)

    delta_mu_outer = np.einsum("...i,...j->...ij", delta_mu, delta_mu)
   
    M = sigma_p_push_inv
    G = M - np.einsum("...ik,...kl,...lj->...ij", M, delta_mu_outer, M) \
          - np.einsum("...ik,...kl,...lj->...ij", M, sigma_q, M)

    Phi_tilde_T = np.swapaxes(Phi_tilde, -1, -2)
    grad_sigma = 0.5 * np.einsum("...ki,...ij,...jl->...kl", Phi_tilde_T, G, Phi_tilde)

    return grad_mu, grad_sigma




def transport_pushforward(mu, sigma, Omega, inverse=False, eps=1e-8):
    """
    Compute gauge-transported mean and covariance under Ω:

        μ_t      = Ω μ
        Σ_t      = Ω Σ Ωᵀ
        Σ_t_inv  = (Ω Σ Ωᵀ)⁻¹  if inverse=True
                 = Ω Σ⁻¹ Ωᵀ    if inverse=False

    Args:
        mu       : (..., K)
        sigma    : (..., K, K)
        Omega    : (..., K, K)
        inverse  : bool — if True, computes (Ω Σ Ωᵀ)⁻¹, else Ω Σ⁻¹ Ωᵀ
        eps      : regularization for inversion

    Returns:
        mu_t         : (..., K)
        sigma_push   : (..., K, K)
    """
    Omega_T = np.swapaxes(Omega, -1, -2)
    mu_t = np.einsum("...ij,...j->...i", Omega, mu)

    if inverse:
        # pushforward of inverse: Ω Σ⁻¹ Ωᵀ
        sigma_inv = safe_inv(sanitize_sigma(sigma, eps=eps), eps=eps)
        sigma_push = np.einsum("...ik,...kl,...jl->...ij", Omega, sigma_inv, Omega)
    else:
        # pushforward then inverse: (Ω Σ Ωᵀ)⁻¹
        sigma_t = np.einsum("...ik,...kl,...jl->...ij", Omega, sanitize_sigma(sigma, eps=eps), Omega_T)
        sigma_push = safe_inv(sigma_t, eps=eps)

    return mu_t, sigma_push


def gaussian_pushforward(mu, sigma, Phi, eps=1e-8):
    """
    Compute the pushforward of a multivariate Gaussian under linear map Φ,
    including the inverse of the pushforward covariance.

    Given:
        q = N(μ, Σ)
        Φ·q := N(Φ μ, Φ Σ Φᵀ)

    Args:
        mu    : (..., K_in)
        sigma : (..., K_in, K_in)
        Phi   : (..., K_out, K_in)
        eps   : small regularization for inversion

    Returns:
        mu_push      : (..., K_out)
        sigma_push   : (..., K_out, K_out) — sanitized
        sigma_inv    : (..., K_out, K_out) — sanitized inverse of sigma_push
    """
    # Pushforward mean
    mu_push = np.einsum("...ij,...j->...i", Phi, mu)

    # Pushforward covariance
    sigma_push = np.einsum("...ik,...kl,...jl->...ij", Phi, sigma, Phi)

    # Symmetrize and sanitize
    sigma_push = 0.5 * (sigma_push + np.swapaxes(sigma_push, -1, -2))
    sigma_push = sanitize_sigma(sigma_push, eps=eps)

    # Inverse covariance
    sigma_inv = safe_inv(sigma_push, eps=eps)

    return mu_push, sigma_push, sigma_inv




#================================================================
#
#           FOR FUTURE CONSIDERATION (GLOBAL ENERGY DESCENT)
#
#==============================================================


def grad_alignment_energy_target(mu_i, sigma_i, mu_j, sigma_j, Omega_ij, eps=1e-8):
    """
    Compute ∇_{μⱼ} and ∇_{Σⱼ} of D_KL(qᵢ ‖ Ω qⱼ) or D_KL(pᵢ ‖ Ω̃ pⱼ)

    This computes the gradient of KL divergence with respect to the
    target distribution (j), where:
        qᵢ = N(μᵢ, Σᵢ)
        Ω qⱼ = N(Ω μⱼ, Ω Σⱼ Ωᵀ)

    Args:
        mu_i     : (..., K)
        sigma_i  : (..., K, K)
        mu_j     : (..., K)
        sigma_j  : (..., K, K)
        Omega_ij : (..., K, K) — transport from j → i
        eps      : small regularization constant

    Returns:
        grad_mu_j     : (..., K)
        grad_sigma_j  : (..., K, K)
    """
    Omega_T = np.swapaxes(Omega_ij, -1, -2)

    
    mu_j_t, sigma_j_inv = transport_pushforward(mu_j, sigma_j, Omega_ij, inverse=False, eps=eps)
    delta_mu = mu_i - mu_j_t


    # ∇_{μⱼ} = -Ωᵀ Σ_j^t⁻¹ (μᵢ − Ω μⱼ)
    tmp = np.einsum("...ij,...j->...i", sigma_j_inv, delta_mu)
    grad_mu = -np.einsum("...ji,...i->...j", Omega_ij, tmp)

    # ∇_{Σⱼ} = ½ Ωᵀ [ M A M − M Σᵢ M − M ] Ω
    A = np.einsum("...i,...j->...ij", delta_mu, delta_mu)
    term1 = np.einsum("...ik,...kl,...lj->...ij", sigma_j_inv, A, sigma_j_inv)
    term2 = np.einsum("...ik,...kl,...lj->...ij", sigma_j_inv, sanitize_sigma(sigma_i, eps=eps), sigma_j_inv)
    term3 = sigma_j_inv
    core = term1 - term2 - term3
    grad_sigma = 0.5 * np.einsum("...ik,...kl,...lj->...ij", Omega_T, core, Omega_ij)

    return grad_mu, grad_sigma
