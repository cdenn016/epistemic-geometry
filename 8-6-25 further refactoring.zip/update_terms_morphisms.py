# -*- coding: utf-8 -*-
"""
Created on Wed Jul 23 06:38:37 2025

@author: chris and christine
"""
import numpy as np

from numerical_utils import safe_inv, sanitize_sigma

from natural_gradient import dexpinv_operator
from omega import d_exp_phi_exact, d_exp_phi_tilde_exact

import config   
#==============================================================================
#
#                    Apply Natural Gradient to Bundle Morphism
#
#==============================================================================

def clip_gradient_norm(grad, max_norm=5.0, eps=1e-8):
    norm = np.linalg.norm(grad, axis=-1, keepdims=True)
    scale = np.minimum(1.0, max_norm / (norm + eps))
    return grad * scale


def accumulate_phi_gradient_from_morphism_self_and_feedback(agent_i, generators_p, generators_q, params, debug=False):
    """
    Accumulate ∇_φ from:
      - KL(q || Φ̃·p)    ← self-energy (belief)
      - KL(p || Φ·q)     ← feedback (model)
    into:
      - agent_i.grad_phi
    """
   

    alpha   = params.get("alpha", config.alpha)
    lambda_ = params.get("feedback_weight", config.feedback_weight)
    if alpha <= 0 and lambda_ <= 0:
        return

    eps  = config.support_cutoff_eps
    mask = (agent_i.mask > eps)[..., None]  # (H, W, 1)

    mu_q, sigma_q = agent_i.mu_q_field, agent_i.sigma_q_field
    mu_p, sigma_p = agent_i.mu_p_field, agent_i.sigma_p_field
    phi, phi_tilde = agent_i.phi, agent_i.phi_model

   
        # ───── Self-energy gradient: ∇_φ KL(q || Φ̃·p) ← direct method ─────
    if alpha > 0:
        grad_phi_self = grad_kl_self_phi_direct(
            mu_q=mu_q, sigma_q=sigma_q,
            mu_p=mu_p, sigma_p=sigma_p,
            Phi_tilde_0=agent_i.Phi_tilde_0,
            phi=phi,
            phi_tilde=phi_tilde,
            generators_q=generators_q,
            generators_p=generators_p,
            exp_phi=agent_i._exp_phi,
            exp_phi_tilde=agent_i._exp_phi_model,
            eps=eps
        )
       #@ print(f"[phi grad] raw ∇_φ̃ KL(q ‖ Φ̃p) = {np.linalg.norm(grad_phi_self):.2e}", flush=True)
        G_inv = agent_i.inverse_fisher_phi
        grad_phi_self = np.einsum("...ab,...b->...a", G_inv, grad_phi_self)
        grad_phi_self = dexpinv_operator(phi, grad_phi_self, generators_q)
        grad_phi_self = clip_gradient_norm(grad_phi_self, config.phi_grad_clip)

        grad_phi_self *= mask
        agent_i.grad_phi += alpha * grad_phi_self
        #print(f"[phi grad] after nat + dexpinv = {np.linalg.norm(grad_phi_self):.2e}", flush=True)


        # ───── Feedback gradient: ∇_φ KL(p || Φ·q) ← use direct method ─────
    if lambda_ > 0:
        grad_phi_feedback = grad_kl_feedback_phi_direct(
            mu_p=mu_p, sigma_p=sigma_p,
            mu_q=mu_q, sigma_q=sigma_q,
            Phi_0=agent_i.Phi_0,
            phi=phi, phi_tilde=phi_tilde,
            generators_q=generators_q,
            exp_phi=agent_i._exp_phi,
            exp_phi_tilde=agent_i._exp_phi_model,
            eps=eps
        )

        # Apply natural gradient (F⁻¹), dexp⁻¹, clipping, masking
       # print(f"[phi grad] raw ∇_φ KL(p ‖ Φq) = {np.linalg.norm(grad_phi_feedback):.2e}", flush=True)
        
        grad_phi_feedback = np.einsum("...ab,...b->...a", G_inv, grad_phi_feedback)
        grad_phi_feedback = dexpinv_operator(phi, grad_phi_feedback, generators_q)
    
        grad_phi_feedback = clip_gradient_norm(grad_phi_feedback, config.phi_grad_clip)
        grad_phi_feedback *= mask
        
        
        agent_i.grad_phi += lambda_ * grad_phi_feedback



def accumulate_phi_tilde_gradient_from_morphism_self_and_feedback(agent_i, generators_p, generators_q, params, debug=False):
    """
    Accumulate ∇_{φ̃} from:
      - KL(q || Φ̃·p)    ← self-energy (belief)
      - KL(p || Φ·q)     ← feedback (model)
    into:
      - agent_i.grad_phi_tilde
    """
    

    alpha   = params.get("alpha", config.alpha)
    lambda_ = params.get("feedback_weight", config.feedback_weight)
    if alpha <= 0 and lambda_ <= 0:
        return

    eps  = config.support_cutoff_eps
    mask = (agent_i.mask > eps)[..., None]  # (H, W, 1)

    mu_q, sigma_q = agent_i.mu_q_field, agent_i.sigma_q_field
    mu_p, sigma_p = agent_i.mu_p_field, agent_i.sigma_p_field
    phi, phi_tilde = agent_i.phi, agent_i.phi_model



       # ───── Self-energy gradient: ∇_{φ̃} KL(q || Φ̃·p) ← direct method ─────
    if alpha > 0:
        grad_phi_tilde_self = grad_kl_self_phi_tilde_direct(
            mu_q=mu_q, sigma_q=sigma_q,
            mu_p=mu_p, sigma_p=sigma_p,
            Phi_tilde_0=agent_i.Phi_tilde_0,
            phi=phi,
            phi_tilde=phi_tilde,
            generators_q=generators_q,
            generators_p=generators_p,
            exp_phi=agent_i._exp_phi,
            exp_phi_tilde=agent_i._exp_phi_model,
            eps=eps
        )
       # print(f"[phi_tilde grad] raw ∇_φ̃ KL(q ‖ Φ̃p) = {np.linalg.norm(grad_phi_tilde_self):.2e}", flush=True)
        G_inv_tilde = agent_i.inverse_fisher_phi_model
        grad_phi_tilde_self = np.einsum("...ab,...b->...a", G_inv_tilde, grad_phi_tilde_self)
        grad_phi_tilde_self = dexpinv_operator(phi_tilde, grad_phi_tilde_self, generators_p)
        grad_phi_tilde_self = clip_gradient_norm(grad_phi_tilde_self, config.phi_grad_clip)
        grad_phi_tilde_self *= mask
        agent_i.grad_phi_tilde += alpha * grad_phi_tilde_self
       # print(f"[phi_tilde grad] after nat + dexpinv = {np.linalg.norm(grad_phi_tilde_self):.2e}\n\n", flush=True)


        # ───── Feedback gradient: ∇_{φ̃} KL(p || Φ·q) ← direct method ─────
    if lambda_ > 0:
        grad_phi_tilde_feedback = grad_kl_feedback_phi_tilde_direct(
            mu_p=mu_p, sigma_p=sigma_p,
            mu_q=mu_q, sigma_q=sigma_q,
            Phi_0=agent_i.Phi_0,
            phi=phi,
            phi_tilde=phi_tilde,
            generators_p=generators_p,
            generators_q=generators_q,
            exp_phi=agent_i._exp_phi,
            exp_phi_tilde=agent_i._exp_phi_model,
            eps=eps
        )

       # print(f"[phi grad] raw ∇_φ KL(p ‖ Φq) = {np.linalg.norm(grad_phi_tilde_feedback):.2e}", flush=True)

        G_inv_tilde = agent_i.inverse_fisher_phi_model
        grad_phi_tilde_feedback = np.einsum("...ab,...b->...a", G_inv_tilde, grad_phi_tilde_feedback)
        grad_phi_tilde_feedback = dexpinv_operator(phi_tilde, grad_phi_tilde_feedback, generators_p)
        grad_phi_tilde_feedback = clip_gradient_norm(grad_phi_tilde_feedback, config.phi_grad_clip)

        grad_phi_tilde_feedback *= mask
       
        agent_i.grad_phi_tilde += lambda_ * grad_phi_tilde_feedback



def grad_kl_feedback_phi_direct(
    mu_p, sigma_p,
    mu_q, sigma_q,
    Phi_0,
    phi,                # (..., d)
    phi_tilde,          # (..., d)
    generators_q,       # (d, K_q, K_q)
    exp_phi,            # (..., K_q, K_q)
    exp_phi_tilde,      # (..., K_p, K_p)
    eps=1e-8
):
    """
    Compute ∂/∂φ^a D_KL(p || Φ·q), where the bundle morphism is defined as:
        Φ = e^{φ̃} · Φ₀ · e^{-φ}

    and the gradient is taken with respect to φ (the belief-side Lie algebra field),
    using the identity:
        ∂Φ/∂φ^a = - e^{φ̃} · Φ₀ · Q^a,
    where Q^a = ∂ e^φ / ∂ φ^a.

    This evaluates:
        ∂/∂φ^a D_KL(p || Φ q)
        = − (∂Φ μ_q)ᵀ A⁻¹ Δμ
          − ½ Tr(A⁻¹ ∂A)
          + ½ Δμᵀ A⁻¹ ∂A A⁻¹ Δμ

    with:
        Δμ = μ_p − Φ μ_q,
        A = Φ Σ_q Φᵀ,
        ∂A = ∂Φ Σ_q Φᵀ + Φ Σ_q ∂Φᵀ.

    Args:
        mu_p         : (..., K_p) model mean
        sigma_p      : (..., K_p, K_p) model covariance
        mu_q         : (..., K_q) belief mean
        sigma_q      : (..., K_q, K_q) belief covariance
        Phi_0        : (..., K_p, K_q) static bundle morphism
        phi          : (..., d) Lie algebra parameters on the belief side
        phi_tilde    : (..., d) Lie algebra parameters on the model side
        generators_q : (d, K_q, K_q) Lie algebra generators for q
        exp_phi      : (..., K_q, K_q), e^{φ}
        exp_phi_tilde: (..., K_p, K_p), e^{φ̃}
        eps          : regularization constant

    Returns:
        grad_phi     : (..., d) gradient of KL divergence with respect to φ
    """
  

    d, K_q, _ = generators_q.shape
    K_p = mu_p.shape[-1]
    shape = mu_p.shape[:-1]

    # Compute full Φ = exp(φ̃) · Φ₀ · exp(−φ)
    exp_mphi = exp_phi.swapaxes(-1, -2)
    Phi = exp_phi_tilde @ Phi_0 @ exp_mphi        # (..., K_p, K_q)

    # A = Φ Σ_q Φᵀ
    A = Phi @ sigma_q @ np.swapaxes(Phi, -1, -2)
    A = sanitize_sigma(A, eps)
    A_inv = safe_inv(A, eps)

    delta_mu = mu_p - np.einsum("...ij,...j->...i", Phi, mu_q)

    # Compute Q^a = ∂e^φ / ∂φ^a
    d_exp_phi_all = d_exp_phi_exact(phi, generators_q)

    grad = np.zeros((*shape, d), dtype=mu_p.dtype)

    for a in range(d):
        Q_a = d_exp_phi_all[a]                          # (..., K_q, K_q)

        # ∂Φ = - e^{φ̃} Φ₀ Q^a
        dPhi = -Phi @ Q_a @ exp_mphi
         # (..., K_p, K_q)
        dPhi_T = np.swapaxes(dPhi, -1, -2)

        # ∂A = dΦ Σ_q Φᵀ + Φ Σ_q dΦᵀ
        dA = dPhi @ sigma_q @ np.swapaxes(Phi, -1, -2) + Phi @ sigma_q @ dPhi_T  # (..., K_p, K_p)

        # Term 1: −(dΦ μ_q)ᵀ A⁻¹ Δμ
        tmp1 = dPhi @ mu_q[..., None]                   # (..., K_p, 1)
        term1 = -np.einsum("...i,...i->...", tmp1[..., 0], (A_inv @ delta_mu[..., None])[..., 0])


        # Term 2: −½ Tr(A⁻¹ dA)
        term2 = -0.5 * np.einsum("...ij,...ji->...", A_inv, dA)

        # Term 3: ½ Δμᵀ A⁻¹ dA A⁻¹ Δμ
        AdA = A_inv @ dA @ A_inv
        term3 = 0.5 * np.einsum("...i,...ij,...j->...", delta_mu, AdA, delta_mu)

        grad[..., a] = term1 + term2 + term3


    return grad



def grad_kl_feedback_phi_tilde_direct(
    mu_p, sigma_p,
    mu_q, sigma_q,
    Phi_0,
    phi, phi_tilde,
    generators_p, generators_q,
    exp_phi, exp_phi_tilde,
    eps=1e-8
):
    """
    Compute ∂/∂φ̃^a D_KL(p || Φ q) where Φ = e^{φ̃} · Φ₀ · e^{-φ},
    with ∂Φ/∂φ̃^a = Q̃^a · Φ and Q̃^a = ∂ e^{φ̃} / ∂ φ̃^a.

    Specifically computes:

        ∂/∂φ̃^a D_KL(p || Φ q)
        = - (∂Φ μ_q)ᵀ A⁻¹ Δμ
          - ½ Tr(A⁻¹ ∂A)
          + ½ Δμᵀ A⁻¹ ∂A A⁻¹ Δμ
          - ½ Tr(A⁻¹ ∂A A⁻¹ Σ_p)

    where:
        Δμ = μ_p − Φ μ_q
        A = Φ Σ_q Φᵀ
        ∂Φ = Q̃^a · Φ
        ∂A = ∂Φ Σ_q Φᵀ + Φ Σ_q ∂Φᵀ

    Args:
        mu_p       : (..., K_p) model mean
        sigma_p    : (..., K_p, K_p) model covariance
        mu_q       : (..., K_q) belief mean
        sigma_q    : (..., K_q, K_q) belief covariance
        Phi_0      : (..., K_p, K_q) initial bundle morphism
        phi        : (..., d) belief Lie algebra φ
        phi_tilde  : (..., d) model Lie algebra φ̃
        generators_p: (d, K_p, K_p) Lie algebra basis for model fiber
        generators_q: (d, K_q, K_q) Lie algebra basis for belief fiber
        exp_phi    : (..., K_q, K_q) = e^{φ}
        exp_phi_tilde: (..., K_p, K_p) = e^{φ̃}
        eps        : regularization constant

    Returns:
        grad_phi_tilde: (..., d) gradient of KL with respect to φ̃
    """
    

    d, K_p, _ = generators_p.shape
    K_q = mu_q.shape[-1]
    shape = mu_p.shape[:-1]

    # Φ = e^{φ̃} Φ₀ e^{-φ}
    exp_mphi = np.swapaxes(exp_phi, -1, -2)
    Phi = exp_phi_tilde @ Phi_0 @ exp_mphi  # (..., K_p, K_q)

    # A = Φ Σ_q Φᵀ
    A = Phi @ sigma_q @ np.swapaxes(Phi, -1, -2)
    A = sanitize_sigma(A, eps)
    A_inv = safe_inv(A, eps)

    delta_mu = mu_p - np.einsum("...ij,...j->...i", Phi, mu_q)

    # Get all ∂e^{φ̃}/∂φ̃^a
    d_exp_phi_tilde_all = d_exp_phi_tilde_exact(phi_tilde, generators_p)

    grad = np.zeros((*shape, d), dtype=mu_p.dtype)

    for a in range(d):
        Q_tilde_a = d_exp_phi_tilde_all[a]         # (..., K_p, K_p)

        # ∂Φ = Q̃^a · Φ
        dPhi = Q_tilde_a @ Phi_0 @ exp_mphi
                    # (..., K_p, K_q)
        dPhi_T = np.swapaxes(dPhi, -1, -2)

        # ∂A = dΦ Σ_q Φᵀ + Φ Σ_q dΦᵀ
        dA = dPhi @ sigma_q @ np.swapaxes(Phi, -1, -2) + Phi @ sigma_q @ dPhi_T  # (..., K_p, K_p)

        # Term 1: −(∂Φ μ_q)ᵀ A⁻¹ Δμ
        tmp1 = dPhi @ mu_q[..., None]                           # (..., K_p, 1)
        term1 = -np.einsum("...i,...i->...", tmp1[..., 0], (A_inv @ delta_mu[..., None])[..., 0])


        # Term 2: −½ Tr(A⁻¹ dA)
        term2 = -0.5 * np.einsum("...ij,...ji->...", A_inv, dA)

        # Term 3: +½ Δμᵀ A⁻¹ dA A⁻¹ Δμ
        AdA = A_inv @ dA @ A_inv
        term3 = 0.5 * np.einsum("...i,...ij,...j->...", delta_mu, AdA, delta_mu)

        # Term 4: −½ Tr(A⁻¹ dA A⁻¹ Σ_p)
        AdA_Sp = AdA @ sigma_p
        term4 = -0.5 * np.einsum("...ij,...ji->...", A_inv, AdA_Sp)

        grad[..., a] = term1 + term2 + term3 + term4

    return grad





def grad_kl_self_phi_direct(
    mu_q, sigma_q,
    mu_p, sigma_p,
    Phi_tilde_0,
    phi, phi_tilde,
    generators_q, generators_p,
    exp_phi, exp_phi_tilde,
    eps=1e-8
):

    """
    Compute ∂/∂φ^a D_KL(q || Φ̃·p) where Φ̃ = e^{φ} Φ̃₀ e^{φ̃},
    with ∂Φ̃/∂φ^a = Q^a · Φ̃ and Q^a = ∂ e^{φ} / ∂ φ^a.

    Specifically computes:

        ∂/∂φ^a D_KL(q || Φ̃·p)
        = - (∂Φ̃ μ_p)^T A⁻¹ Δμ
          - ½ Tr(A⁻¹ ∂A)
          + ½ Δμᵀ A⁻¹ ∂A A⁻¹ Δμ
          - ½ Tr(A⁻¹ ∂A A⁻¹ Σ_q)

    where:
        Δμ = μ_q − Φ̃ μ_p
        A = Φ̃ Σ_p Φ̃ᵀ
        ∂Φ̃ = Q^a · Φ̃ e^phi~
        ∂A = ∂Φ̃ Σ_p Φ̃ᵀ + Φ̃ Σ_p ∂Φ̃ᵀ

    Args:
        mu_q       : (..., K_q) belief mean
        sigma_q    : (..., K_q, K_q) belief covariance
        mu_p       : (..., K_p) model mean
        sigma_p    : (..., K_p, K_p) model covariance
        Phi_tilde_0: (..., K_q, K_p) static morphism
        phi        : (..., d) belief-side Lie algebra
        phi_tilde  : (..., d) model-side Lie algebra
        generators_q: (d, K_q, K_q) Lie algebra generators for belief
        generators_p: (d, K_p, K_p) Lie algebra generators for model
        exp_phi    : (..., K_q, K_q), e^{φ}
        exp_phi_tilde: (..., K_p, K_p), e^{φ̃}
        eps        : regularization epsilon

    Returns:
        grad_phi: (..., d) gradient of KL divergence with respect to φ
    """
  

    d, K_q, _ = generators_q.shape
    K_p = mu_p.shape[-1]
    shape = mu_q.shape[:-1]

    # Φ̃ = e^{φ} Φ̃₀ e^{-φ̃}
    exp_mphi_tilde = exp_phi_tilde.swapaxes(-1, -2)
    Phi_tilde = exp_phi @ Phi_tilde_0 @ exp_mphi_tilde


    # A = Φ̃ Σ_p Φ̃ᵀ
    A = Phi_tilde @ sigma_p @ np.swapaxes(Phi_tilde, -1, -2)  # (..., K_q, K_q)
    A = sanitize_sigma(A, eps)
    A_inv = safe_inv(A, eps)

    delta_mu = mu_q - np.einsum("...ij,...j->...i", Phi_tilde, mu_p)  # (..., K_q)

    # Get ∂e^φ/∂φ^a
    d_exp_phi_all = d_exp_phi_exact(phi, generators_q)

    grad = np.zeros((*shape, d), dtype=mu_q.dtype)

    for a in range(d):
        Q_a = d_exp_phi_all[a]                       # (..., K_q, K_q)

        # ∂Φ̃ = Q^a · Φ̃
        dPhi = Q_a @ Phi_tilde_0 @ exp_mphi_tilde                      # (..., K_q, K_p)
        dPhi_T = np.swapaxes(dPhi, -1, -2)

        # ∂A = dΦ̃ Σ_p Φ̃ᵀ + Φ̃ Σ_p dΦ̃ᵀ
        dA = dPhi @ sigma_p @ Phi_tilde.swapaxes(-1, -2) + Phi_tilde @ sigma_p @ dPhi_T

        # Term 1: −(∂Φ̃ μ_p)^T A⁻¹ Δμ
        tmp1 = dPhi @ mu_p[..., None]                # (..., K_q, 1)
        tmp2 = A_inv @ delta_mu[..., None]        # (..., K_q, 1)
        term1 = -np.einsum("...i,...i->...", tmp1[..., 0], tmp2[..., 0])


        # Term 2: −½ Tr(A⁻¹ dA)
        term2 = -0.5 * np.einsum("...ij,...ji->...", A_inv, dA)

        # Term 3: ½ Δμᵀ A⁻¹ dA A⁻¹ Δμ
        AdA = A_inv @ dA @ A_inv
        term3 = 0.5 * np.einsum("...i,...ij,...j->...", delta_mu, AdA, delta_mu)

        # Term 4: −½ Tr(A⁻¹ dA A⁻¹ Σ_q)
        AdA_Sq = AdA @ sigma_q
        term4 = -0.5 * np.einsum("...ij,...ji->...", A_inv, AdA_Sq)

        grad[..., a] = term1 + term2 + term3 + term4

    return grad


def grad_kl_self_phi_tilde_direct(
    mu_q, sigma_q,
    mu_p, sigma_p,
    Phi_tilde_0,
    phi, phi_tilde,
    generators_q, generators_p,
    exp_phi, exp_phi_tilde,
    eps=1e-8
):
    """
    Compute ∂/∂φ̃^a D_KL(q || Φ̃·p) where Φ̃ = e^{φ} Φ̃₀ e^{φ̃},
    with ∂Φ̃/∂φ̃^a = -Φ̃ · Q̃^a, and Q̃^a = ∂ e^{φ̃} / ∂ φ̃^a.

    Specifically computes:

        ∂/∂φ̃^a D_KL(q || Φ̃·p)
        = - (∂Φ̃ μ_p)^T A⁻¹ Δμ
          - ½ Tr(A⁻¹ ∂A)
          + ½ Δμᵀ A⁻¹ ∂A A⁻¹ Δμ
          - ½ Tr(A⁻¹ ∂A A⁻¹ Σ_q)

    where:
        Δμ = μ_q − Φ̃ μ_p
        A = Φ̃ Σ_p Φ̃ᵀ
        ∂Φ̃ = -Φ̃ · Q̃^a
        ∂A = ∂Φ̃ Σ_p Φ̃ᵀ + Φ̃ Σ_p ∂Φ̃ᵀ

    Args:
        mu_q       : (..., K_q) belief mean
        sigma_q    : (..., K_q, K_q) belief covariance
        mu_p       : (..., K_p) model mean
        sigma_p    : (..., K_p, K_p) model covariance
        Phi_tilde_0: (..., K_q, K_p) static morphism
        phi        : (..., d) belief-side Lie algebra
        phi_tilde  : (..., d) model-side Lie algebra
        generators_q: (d, K_q, K_q) Lie algebra generators for belief
        generators_p: (d, K_p, K_p) Lie algebra generators for model
        exp_phi    : (..., K_q, K_q), e^{φ}
        exp_phi_tilde: (..., K_p, K_p), e^{φ̃}
        eps        : regularization epsilon

    Returns:
        grad_phi_tilde: (..., d) gradient of KL divergence with respect to φ̃
    """
   

    d, K_p, _ = generators_p.shape
    K_q = mu_q.shape[-1]
    shape = mu_q.shape[:-1]

    # Φ̃ = e^{φ} Φ̃₀ e^{-φ̃}
    exp_mphi_tilde = exp_phi_tilde.swapaxes(-1, -2)
    Phi_tilde = exp_phi @ Phi_tilde_0 @ exp_mphi_tilde


    # A = Φ̃ Σ_p Φ̃ᵀ
    A = Phi_tilde @ sigma_p @ np.swapaxes(Phi_tilde, -1, -2)  # (..., K_q, K_q)
    A = sanitize_sigma(A, eps)
    A_inv = safe_inv(A, eps)

    delta_mu = mu_q - np.einsum("...ij,...j->...i", Phi_tilde, mu_p)  # (..., K_q)

    # Get ∂e^{φ̃}/∂φ̃^a = Q̃^a
    d_exp_phi_tilde_all = d_exp_phi_tilde_exact(phi_tilde, generators_p)

    grad = np.zeros((*shape, d), dtype=mu_q.dtype)

    for a in range(d):
        Q_tilde_a = d_exp_phi_tilde_all[a]              # (..., K_p, K_p)

        # ∂Φ̃ = Φ̃ · Q̃^a
        
        dPhi = -Phi_tilde @ Q_tilde_a @ exp_mphi_tilde
    # (..., K_q, K_p)
        dPhi_T = np.swapaxes(dPhi, -1, -2)


        # ∂A = dΦ Σ_p Φ̃ᵀ + Φ̃ Σ_p dΦᵀ
        dA = dPhi @ sigma_p @ Phi_tilde.swapaxes(-1, -2) + Phi_tilde @ sigma_p @ dPhi_T

        # Term 1: −(∂Φ μ_p)^T A⁻¹ Δμ
        tmp1 = dPhi @ mu_p[..., None]                   # (..., K_q, 1)
        tmp2 = A_inv @ delta_mu[..., None]
        term1 = -np.einsum("...i,...i->...", tmp1[..., 0], tmp2[..., 0])


        # Term 2: −½ Tr(A⁻¹ dA)
        term2 = -0.5 * np.einsum("...ij,...ji->...", A_inv, dA)

        # Term 3: +½ Δμᵀ A⁻¹ dA A⁻¹ Δμ
        AdA = A_inv @ dA @ A_inv
        term3 = 0.5 * np.einsum("...i,...ij,...j->...", delta_mu, AdA, delta_mu)

        # Term 4: −½ Tr(A⁻¹ dA A⁻¹ Σ_q)
        AdA_Sq = AdA @ sigma_q
        term4 = -0.5 * np.einsum("...ij,...ji->...", A_inv, AdA_Sq)

        grad[..., a] = term1 + term2 + term3 + term4

    return grad






















