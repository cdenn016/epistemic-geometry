# -*- coding: utf-8 -*-
"""
Created on Wed Jul 23 11:36:43 2025

@author: chris and christine
"""

import numpy as np
import config
from numerical_utils import sanitize_sigma, safe_inv
from natural_gradient import apply_natural_gradient_batch




#==============================================================================
#
#                    APPLY NATURAL GRADIENT
#
#==============================================================================
def accumulate_mu_sigma_gradient_model(agent_i, agents, params):
    """
    Accumulate ∇μ_p and ∇Σ_p from all model energy terms:
      - Self:     KL(p_i || Φ q_i)
      - Feedback: KL(q_i || Φ̃ p_i)
      - Alignment: KL(p_i || Ω_ij p_j) and KL(p_k || Ω_kj p_j) for i == j
    """
    dmu, dsigma = compute_mu_sigma_gradient_model_euclidean(agent_i, agents, params)
   

    delta_mu, delta_sigma = apply_natural_gradient_batch(
        agent_i.mu_p_field,
        agent_i.sigma_p_field,
        dmu,
        dsigma,
        mask=agent_i.mask,
    )

    agent_i.grad_mu_p    += delta_mu
    agent_i.grad_sigma_p += delta_sigma


def compute_mu_sigma_gradient_model_euclidean(agent_i, agents, params):
    """
    Compute ∇_μ and ∇_Σ model gradients for agent_i from:
    - Self:     KL(p_i ‖ Φ q_i)
    - Feedback: KL(q_i ‖ Φ̃ p_i)
    - Alignment: both source and target in KL(p ‖ Ω̃ p)
    """
    eps   = config.support_cutoff_eps
    alpha = params.get("alpha", config.alpha)
    beta  = params.get("beta_model", config.beta_model)
    lambd = params.get("feedback_weight", config.feedback_weight)

    mu_q    = agent_i.mu_q_field
    sigma_q = sanitize_sigma(agent_i.sigma_q_field, eps=eps)
    mu_p    = agent_i.mu_p_field
    sigma_p = sanitize_sigma(agent_i.sigma_p_field, eps=eps)

    Phi       = agent_i.bundle_morphism_q_to_p
    Phi_tilde = agent_i.bundle_morphism_p_to_q

    dmu_self    = grad_self_energy_mu_p(mu_q, sigma_q, mu_p, sigma_p, Phi_tilde, eps=eps)
    dsigma_self = grad_self_energy_sigma_p(mu_q, sigma_q, mu_p, sigma_p, Phi_tilde, eps=eps)

    dmu_fb      = grad_feedback_mu_p(mu_p, sigma_p, mu_q, sigma_q, Phi, eps=eps)
    dsigma_fb   = grad_feedback_sigma_p(mu_p, sigma_p, mu_q, sigma_q, Phi, eps=eps)

    dmu_align = 0
    dsigma_align = 0
    for neighbor in agent_i.neighbors:
        agent_j = agents[neighbor["id"]]
        Omega_ij = agent_i.Omega_tilde_cache[agent_j.id]

        sigma_j = sanitize_sigma(agent_j.sigma_p_field, eps=eps)

        dmu_align += grad_model_align_mu_i(
            mu_p, sigma_p,
            agent_j.mu_p_field, sigma_j,
            Omega_ij, eps=eps
        )
        dsigma_align += grad_model_align_sigma_i(
            mu_p, sigma_p,
            agent_j.mu_p_field, sigma_j,
            Omega_ij, eps=eps
        )

    dmu_total = (
        alpha * dmu_self +
        lambd * dmu_fb +
        beta * dmu_align
    )

    dsigma_total = (
        alpha * dsigma_self +
        lambd * dsigma_fb +
        beta * dsigma_align
    )
   # print(f"[grad mu_q] norm from model = {np.linalg.norm(dmu_total):.2e}")
   # print(f"[grad Sigma_q] norm from model = {np.linalg.norm(dsigma_total):.2e}\n\n")
    return dmu_total, dsigma_total


#==============================================================================
#
#                 MODEL FEEDBACK TERMS
#              all validated below
#==============================================================================

def grad_feedback_mu_p(mu_p_field, sigma_p_field,
                       mu_q_field, sigma_q_field, Phi, eps=1e-8):
    """
    Compute ∂/∂μ_p D_KL(p || Φ·q) over a spatial field (..., K_p)

    This computes the gradient of the KL divergence between:
        p        = N(μ_p, Σ_p)
        Φ·q      = N(Φ μ_q, Φ Σ_q Φᵀ)

    Let:
        μ_q^push := Φ μ_q
        Σ_q^push := Φ Σ_q Φᵀ
        Δμ       := μ_p − Φ μ_q
        M        := (Σ_q^push)^(-1)

    The closed-form gradient is:
        ∂/∂μ_p D_KL(p || Φ q) = M · (μ_p − Φ μ_q)

    Args:
        mu_p_field     : (..., K_p)       — model mean μ_p
        sigma_p_field  : (..., K_p, K_p)  — model covariance Σ_p (unused here)
        mu_q_field     : (..., K_q)       — belief mean μ_q
        sigma_q_field  : (..., K_q, K_q)  — belief covariance Σ_q
        Phi            : (..., K_p, K_q)  — bundle morphism Φ: B_q → B_p
        eps            : regularization epsilon for inversion

    Returns:
        grad_mu_p      : (..., K_p)       — gradient w.r.t. μ_p
    """
    mu_q_push = np.einsum("...ij,...j->...i", Phi, mu_q_field)

    sigma_q_field = sanitize_sigma(sigma_q_field, eps=eps)
    sigma_q_push = np.einsum("...ik,...kl,...jl->...ij", Phi, sigma_q_field, Phi)

    sigma_q_push_inv = safe_inv(sigma_q_push, eps=eps)
    delta_mu = mu_p_field - mu_q_push

    grad_mu_p = np.einsum("...ij,...j->...i", sigma_q_push_inv, delta_mu)
    return grad_mu_p


def grad_feedback_sigma_p(mu_p_field, sigma_p_field,
                          mu_q_field, sigma_q_field, Phi, eps=1e-8):
    """
    Compute ∂/∂Σ_p D_KL(p || Φ·q) over a spatial field (..., K_p, K_p)

    This is the gradient of the KL divergence between:
        p        = N(μ_p, Σ_p)
        Φ·q      = N(Φ μ_q, Φ Σ_q Φᵀ)

    Let:
        Σ_q^push := Φ Σ_q Φᵀ

    The closed-form expression is:
        ∂/∂Σ_p D_KL(p || Φ·q) = ½ [ (Σ_q^push)^(-1) − Σ_p^(-1) ]

    Args:
        mu_p_field     : (..., K_p)
        sigma_p_field  : (..., K_p, K_p)
        mu_q_field     : (..., K_q)
        sigma_q_field  : (..., K_q, K_q)
        Phi            : (..., K_p, K_q)
        eps            : regularization epsilon for inversion

    Returns:
        grad_sigma_p   : (..., K_p, K_p)
    """
    Phi_T = np.swapaxes(Phi, -1, -2)

    sigma_q_field = sanitize_sigma(sigma_q_field, eps=eps)
    sigma_q_push = np.einsum("...ik,...kl,...lj->...ij", Phi, sigma_q_field, Phi_T)

    sigma_q_push = sanitize_sigma(sigma_q_push, eps=eps)
    sigma_p_field = sanitize_sigma(sigma_p_field, eps=eps)

    sigma_inv_qpush = safe_inv(sigma_q_push, eps=eps)
    sigma_inv_p     = safe_inv(sigma_p_field, eps=eps)

    grad_sigma_p = 0.5 * (sigma_inv_qpush - sigma_inv_p)
    return grad_sigma_p



#==============================================================================
#
#                    SELF-ENERGY TERMS
#
#==============================================================================

def grad_self_energy_mu_p(mu_q_field, sigma_q_field,
                          mu_p_field, sigma_p_field, Phi_tilde, eps=1e-8):
    """
    Compute ∂/∂μ_p D_KL(q || Φ̃·p) over a spatial field (..., K_p)

    This is the gradient of the KL divergence between:
        q         = N(μ_q, Σ_q)
        Φ̃·p      = N(Φ̃ μ_p, Φ̃ Σ_p Φ̃ᵀ)

    Let:
        μ_p^push := Φ̃ μ_p
        Σ_p^push := Φ̃ Σ_p Φ̃ᵀ
        Δμ       := μ_q − Φ̃ μ_p
        M        := (Σ_p^push)^(-1)

    The closed-form expression is:
        ∂/∂μ_p D_KL(q || Φ̃·p) = − Φ̃ᵀ · M · (μ_q − Φ̃ μ_p)

    Args:
        mu_q_field     : (..., K_q)
        sigma_q_field  : (..., K_q, K_q)
        mu_p_field     : (..., K_p)
        sigma_p_field  : (..., K_p, K_p)
        Phi_tilde      : (..., K_q, K_p) — bundle morphism Φ̃: B_p → B_q
        eps            : small regularization epsilon

    Returns:
        grad_mu_p      : (..., K_p)
    """
    mu_p_push = np.einsum("...qk,...k->...q", Phi_tilde, mu_p_field)
    sigma_p_field = sanitize_sigma(sigma_p_field, eps=eps)
    sigma_p_push = np.einsum("...qi,...ij,...kj->...qk", Phi_tilde, sigma_p_field, Phi_tilde)

    sigma_p_push = sanitize_sigma(sigma_p_push, eps=eps)
    sigma_p_push_inv = safe_inv(sigma_p_push, eps=eps)

    delta_mu = mu_q_field - mu_p_push
    tmp = np.einsum("...ij,...j->...i", sigma_p_push_inv, delta_mu)
    grad_mu_p = -np.einsum("...qk,...q->...k", Phi_tilde, tmp)

    return grad_mu_p


def grad_self_energy_sigma_p(mu_q_field, sigma_q_field, mu_p_field,
                              sigma_p_field, Phi_tilde, eps=1e-8):
    """
    Compute ∂/∂Σ_p D_KL(q || Φ̃·p) over a spatial field (..., K_p, K_p)

    This is the gradient of the KL divergence between:
        q         = N(μ_q, Σ_q)
        Φ̃·p      = N(Φ̃ μ_p, Φ̃ Σ_p Φ̃ᵀ)

    Let:
        μ_p^push := Φ̃ μ_p
        Σ_p^push := Φ̃ Σ_p Φ̃ᵀ
        Δμ       := μ_q − Φ̃ μ_p
        M        := (Σ_p^push)^(-1)

    The closed-form expression is:
        ∂/∂Σ_p D_KL(q || Φ̃·p) = ½ · Φ̃ᵗ · [ M − M Δμ Δμᵀ M − M Σ_q M ] · Φ̃

    Args:
        mu_q_field     : (..., K_q)
        sigma_q_field  : (..., K_q, K_q)
        mu_p_field     : (..., K_p)
        sigma_p_field  : (..., K_p, K_p)
        Phi_tilde      : (..., K_q, K_p) — bundle morphism Φ̃: B_p → B_q
        eps            : small regularization epsilon

    Returns:
        grad_sigma_p   : (..., K_p, K_p)
    """
    sigma_p_field = sanitize_sigma(sigma_p_field, eps=eps)
    sigma_q_field = sanitize_sigma(sigma_q_field, eps=eps)

    Phi_tilde_T = np.swapaxes(Phi_tilde, -1, -2)

    sigma_proj = np.einsum("...ik,...kl,...jl->...ij", Phi_tilde, sigma_p_field, Phi_tilde)
    sigma_proj_inv = safe_inv(sigma_proj, eps=eps)

    mu_proj = np.einsum("...ij,...j->...i", Phi_tilde, mu_p_field)
    delta_mu = mu_q_field - mu_proj
    delta_mu_outer = np.einsum("...i,...j->...ij", delta_mu, delta_mu)

    term1 = sigma_proj_inv
    term2 = np.einsum("...ik,...kl,...lj->...ij", sigma_proj_inv, delta_mu_outer, sigma_proj_inv)
    term3 = np.einsum("...ik,...kl,...lj->...ij", sigma_proj_inv, sigma_q_field, sigma_proj_inv)

    M = term1 - term2 - term3
    grad_sigma_p = 0.5 * np.einsum("...ki,...ij,...jl->...kl", Phi_tilde_T, M, Phi_tilde)

    return grad_sigma_p






#==============================================================================
#
#                    ALIGNMENT TERMS - NOT VALIDATED
#
#==============================================================================

def grad_model_align_mu_i(mu_p_i, sigma_p_i, mu_p_j, sigma_p_j, Omega_ij, eps=1e-8):
    """
    Compute ∂/∂μ_i D_KL(p_i || Ω~ p_j) for model fibers.

    Let:
        μ_j^t := Ω~ μ_j
        Σ_j^t := Ω~ Σ_j Ω~ᵀ
        Δμ    := μ_i − μ_j^t
        M     := (Σ_j^t)^(-1)

    The closed-form gradient is:
        ∂/∂μ_i D_KL(p_i || Ω p_j) = M · (μ_i − Ω~ μ_j)

    Args:
        mu_p_i    : (..., K_p)       — mean of p_i
        sigma_p_i : (..., K_p, K_p) — covariance of p_i
        mu_p_j    : (..., K_p)       — mean of p_j
        sigma_p_j : (..., K_p, K_p) — covariance of p_j
        Omega_ij  : (..., K_p, K_p) — gauge transport operator from j to i
        eps       : regularization constant for inversion

    Returns:
        grad_mu_p_i : (..., K_p) — gradient w.r.t. μ_i
    """
    mu_j_t = np.einsum("...ij,...j->...i", Omega_ij, mu_p_j)
    delta_mu = mu_p_i - mu_j_t

    Omega_T = np.swapaxes(Omega_ij, -1, -2)
    sigma_j_t = np.einsum("...ik,...kl,...lj->...ij", Omega_ij, sigma_p_j, Omega_T)

    sigma_j_t = sanitize_sigma(sigma_j_t, eps=eps)
    sigma_inv = safe_inv(sigma_j_t, eps=eps)

    grad = np.einsum("...ij,...j->...i", sigma_inv, delta_mu)
    return grad


def grad_model_align_sigma_i(mu_p_i, sigma_p_i, mu_p_j, sigma_p_j, Omega_ij, eps=1e-8):
    """
    Compute ∂/∂Σ_i D_KL(p_i || Ω~ p_j) for model fibers.

    Let:
        M := Ω~ Σ_j Ω~ᵀ

    The closed-form gradient is:
        ∂/∂Σ_i D_KL(p_i || Ω~ p_j) = ½ [ (M)^(-1) − Σ_i^(-1) ]

    Args:
        mu_p_i        : (..., K_p)
        sigma_p_i     : (..., K_p, K_p)
        mu_p_j        : (..., K_p)
        sigma_p_j     : (..., K_p, K_p)
        Omega_ij      : (..., K_p, K_p) — gauge transport operator from j to i
        eps           : regularization constant

    Returns:
        grad_sigma_p_i : (..., K_p, K_p) — gradient w.r.t. Σ_i
    """
    Omega_T = np.swapaxes(Omega_ij, -1, -2)
    sigma_j_t = np.einsum("...ik,...kl,...lj->...ij", Omega_ij, sigma_p_j, Omega_T)

    sigma_j_t = sanitize_sigma(sigma_j_t, eps=eps)
    inv_j = safe_inv(sigma_j_t, eps=eps)
    inv_i = safe_inv(sigma_p_i, eps=eps)

    grad = 0.5 * (inv_j - inv_i)
    return grad



def grad_model_align_mu_j(mu_p_i, sigma_p_i, mu_p_j, sigma_p_j, Omega_ij, eps=1e-8):
    """
    Compute ∇_{μ_j} D_KL(p_i || Ω~ p_j)

    Let:
        μ_j^t  := Ω μ_j
        Σ_j^t  := Ω Σ_j Ωᵀ
        Δμ     := μ_i − μ_j^t
        M      := (Σ_j^t)^(-1)

    Then:
        ∇_{μ_j} D_KL = − Ωᵀ · M · (μ_i − Ω μ_j)

    Args:
        mu_p_i    : (..., K_p)
        sigma_p_i : (..., K_p, K_p)
        mu_p_j    : (..., K_p)
        sigma_p_j : (..., K_p, K_p)
        Omega_ij  : (..., K_p, K_p)
        eps       : regularization epsilon

    Returns:
        grad_mu_p_j : (..., K_p)
    """
   
    # μ_j^t = Ω μ_j
    mu_j_t = np.einsum("...ij,...j->...i", Omega_ij, mu_p_j)
    delta_mu = mu_p_i - mu_j_t

    # Σ_j^t = Ω Σ_j Ωᵀ
    Omega_T = np.swapaxes(Omega_ij, -1, -2)
    sigma_j_t = np.einsum("...ik,...kl,...jl->...ij", Omega_ij, sigma_p_j, Omega_T)
    sigma_j_t = sanitize_sigma(sigma_j_t, eps=eps)
    sigma_j_inv = safe_inv(sigma_j_t, eps=eps)

    # grad = -Ωᵀ M Δμ
    tmp = np.einsum("...ij,...j->...i", sigma_j_inv, delta_mu)
    grad = -np.einsum("...ji,...i->...j", Omega_ij, tmp)
    return grad


def grad_model_align_sigma_j(mu_p_i, sigma_p_i, mu_p_j, sigma_p_j, Omega_ij, eps=1e-8):
    """
    Compute ∇_{Σ_j} D_KL(p_i || Ω~ p_j)

    Let:
        μ_j^t := Ω μ_j
        Σ_j^t := Ω Σ_j Ωᵀ
        Δμ    := μ_i − μ_j^t
        M     := (Σ_j^t)^(-1)

    The closed-form expression is:
        ∇_{Σ_j} D_KL(p_i || Ω~ p_j)
        = ½ Ωᵗ · [ M − M Σ_i M − M Δμ Δμᵗ M ] · Ω

    Args:
        mu_p_i    : (..., K)
        sigma_p_i : (..., K, K)
        mu_p_j    : (..., K)
        sigma_p_j : (..., K, K)
        Omega_ij  : (..., K, K)
        eps       : regularization constant

    Returns:
        grad_sigma_p_j : (..., K, K)
    """
    

    Omega_T = np.swapaxes(Omega_ij, -1, -2)

    # Pushforward quantities
    mu_j_t = np.einsum("...ij,...j->...i", Omega_ij, mu_p_j)
    delta_mu = mu_p_i - mu_j_t
    outer = np.einsum("...i,...j->...ij", delta_mu, delta_mu)

    sigma_j_t = np.einsum("...ik,...kl,...jl->...ij", Omega_ij, sigma_p_j, Omega_T)
    sigma_j_t = sanitize_sigma(sigma_j_t, eps=eps)
    sigma_j_inv = safe_inv(sigma_j_t, eps=eps)

    # Core gradient terms
    term1 = sigma_j_inv
    term2 = np.einsum("...ik,...kl,...lj->...ij", sigma_j_inv, sigma_p_i, sigma_j_inv)
    term3 = np.einsum("...ik,...kl,...lj->...ij", sigma_j_inv, outer, sigma_j_inv)

    grad_core = term1 - term2 - term3
    grad_sigma_p_j = 0.5 * np.einsum("...ki,...ij,...jl->...kl", Omega_ij, grad_core, Omega_T)

    return -grad_sigma_p_j
