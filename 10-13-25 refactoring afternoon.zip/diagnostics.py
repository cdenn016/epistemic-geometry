
from __future__ import annotations
from typing import Any, Dict
import numpy as np
from utils import mask_hw
from runtime_context import energy_acc_get
from joblib import Parallel, delayed
from threadpoolctl import threadpool_limits





# --- diagnostics.py ---

def total_energy(ctx, agents, *, return_breakdown=False, precomputed_metrics=None):
    M = precomputed_metrics if precomputed_metrics is not None else compute_global_metrics(ctx, agents)
    E = float(M.get("E_total", 0.0))
    if not return_breakdown:
        return E

    breakdown = {
        "self":       float(M.get("self_sum_w",     M.get("self_sum", 0.0))),
        "feedback":   float(M.get("feedback_sum_w", M.get("feedback_sum", 0.0))),
        "align_q":    float(M.get("align_q_sum_w",  M.get("align_q_sum",  0.0))),
        "align_p":    float(M.get("align_p_sum_w",  M.get("align_p_sum",  0.0))),
        
        "gamma_A":    float(M.get("gamma_A_sum_w",  M.get("gamma_A_sum",  0.0))),
        "gamma_B":    float(M.get("gamma_B_sum_w",  M.get("gamma_B_sum",  0.0))),
        "mean_total": float(M.get("mean_total",     0.0)),
    }

    return E, breakdown



def _get_edge_maps_compat(ctx, which: str):
    """
    Return (beta_map, kl_map) for a fiber 'q'|'p', supporting both legacy
    per-fiber dicts (_edge_beta_q/_p, _edge_kl_q/_p) and the new unified
    dicts keyed as (which, i_id, j_id): _edge_beta, _edge_kl1/_edge_kl.
    """
    if which not in ("q", "p"):
        raise ValueError(f"_get_edge_maps_compat: which must be 'q' or 'p', got {which!r}")

    # 1) Legacy per-fiber maps
    beta_legacy = getattr(ctx, "_edge_beta_q" if which == "q" else "_edge_beta_p", None)
    kl_legacy   = getattr(ctx, "_edge_kl_q"   if which == "q" else "_edge_kl_p", None)
    if beta_legacy:
        return dict(beta_legacy), dict(kl_legacy or {})

    # 2) New unified maps keyed like (which, i, j)
    beta_uni = getattr(ctx, "_edge_beta", {}) or {}
    # KL′ might be stored in _edge_kl1 (preferred) or _edge_kl (fallback)
    kl_uni1  = getattr(ctx, "_edge_kl1", {}) or {}
    kl_uni   = getattr(ctx, "_edge_kl",  {}) or {}
    kl_src   = kl_uni1 if kl_uni1 else kl_uni

    beta_map, kl_map = {}, {}
    for key, B in beta_uni.items():
        try:
            w, i_id, j_id = key
        except Exception:
            continue
        if str(w) == which:
            beta_map[(int(i_id), int(j_id))] = B
    for key, K in kl_src.items():
        try:
            w, i_id, j_id = key
        except Exception:
            continue
        if str(w) == which:
            kl_map[(int(i_id), int(j_id))] = K
    return beta_map, kl_map



def _sum_beta_KL_from_ctx(ctx, which: str) -> float:
    """
    Sum_x,sum_(i<-j) beta_{ij}(x) * KL_{ij}(x) for a fiber ('q' or 'p').
    Assumes ctx._edge_beta_{q,p} and ctx._edge_kl_{q,p} are filled for this step.
    Returns a scalar float (sum over all receivers/edges/pixels).
    """
    beta_map, kl_map = _get_edge_maps_compat(ctx, which)

    total = 0.0
    for key, B in beta_map.items():
        K = kl_map.get(key, None)
        if K is None:
            # If a KL is missing for a β that exists, treat as zero contribution
            # (alternatively: raise RuntimeError to hard-enforce completeness)
            continue
        b = np.asarray(B, np.float32)
        k = np.asarray(K, np.float32)
        if b.shape != k.shape:
            raise ValueError(f"_sum_beta_KL_from_ctx: β shape {b.shape} != KL shape {k.shape} for edge {key}")
        total += float((b * k).sum())
    return float(total)



def _sum_gamma_KL_from_ctx(
    ctx,
    which_case: str,
    *,
    kappa: float | None = None,
    corrected: bool = False,
) -> float:
    """
    Sum_x,sum_edges gamma_case(x) * [ KL  or  KL - KL^2/(2κ) ].
    which_case: "A" or "B".
    Uses ctx._edge_gamma and ctx._edge_klX, respects gamma_*_off.
    If corrected=True, uses κ. If kappa is None, infers sensible default from cfg.
    """
    import numpy as np
    off = bool(getattr(ctx, "config", {}).get(f"gamma_{which_case}_off", False)) \
          or bool(getattr(ctx, "step_cfg", None) and getattr(ctx.step_cfg, f"gamma_{which_case}_off", False))
    if off:
        return 0.0

    # infer κ if not provided: A→use q’s κ, B→use p’s κ (matches how grads fetch κ)
    if corrected and (kappa is None):
        from runtime_context import cfg_get
        if which_case == "A":
            kappa = float(cfg_get(ctx, "kappa_gamma_q", 1.0))
        else:  # "B"
            kappa = float(cfg_get(ctx, "kappa_gamma_p", 1.0))
    kap = max(float(kappa) if kappa is not None else 1.0, 1e-12)

    G = getattr(ctx, "_edge_gamma", {}) or {}
    K = getattr(ctx, "_edge_klX",   {}) or {}

    tot = 0.0
    for key, g in G.items():
        try:
            case, a, b = key
        except Exception:
            continue
        if str(case) != which_case:
            continue
        k = K.get(key)
        if k is None:
            continue
        gg = np.asarray(g, np.float32)
        kk = np.asarray(k, np.float32)
        if gg.shape != kk.shape:
            raise ValueError(f"_sum_gamma_KL_from_ctx: gamma shape {gg.shape} != KL shape {kk.shape} for edge {key}")
        if corrected:
            tot += float((gg * (kk - 0.5 * (kk * kk) / kap)).sum())
        else:
            tot += float((gg * kk).sum())
    return float(tot)






def print_action_breakdown(ctx, action_dict, *, stream=None):
    step = int(getattr(ctx, "global_step", -1))
    lines = []
    lines.append(f"[Action @ step {step}]")
    lines.append(f"  Action_total = {action_dict.get('Action_total', 0.0):.6e}")
    lines.append("  ---------------------------------------")
    lines.append(f"  Geom_total   = {action_dict.get('Geom_total', 0.0):.6e}")
   
    lines.append(f"  A_curv       = {action_dict.get('A_curv', 0.0):.6e}  ")
    lines.append(f"  A_cov        = {action_dict.get('A_cov', 0.0):.6e}")
   
    print("\n".join(lines), flush=True)


def print_energy_breakdown(ctx, metrics, *, hide_zero_weight=True):
       
    rows = [
        ("self(α)",      metrics.get("self_sum_w", 0.0),      metrics.get("self_mean", 0.0),      1.0),
        ("align_q(β)",   metrics.get("align_q_sum_w", 0.0),   metrics.get("align_q_mean", 0.0),   1.0),
        ("align_p(β)",   metrics.get("align_p_sum_w", 0.0),   metrics.get("align_p_mean", 0.0),   1.0),
        ("feedback(λ)",  metrics.get("feedback_sum_w", 0.0),  metrics.get("feedback_mean", 0.0),  1.0),
        # NEW
        ("gamma_A",      metrics.get("gamma_A_sum_w", 0.0),   metrics.get("gamma_A_mean", 0.0),   1.0),
        ("gamma_B",      metrics.get("gamma_B_sum_w", 0.0),   metrics.get("gamma_B_mean", 0.0),   1.0),
    ]


    print("\n[Energy Totals @ step {}]".format(int(getattr(ctx, "global_step", -1))))
    print("  E_total = {: .6e}  |  mean_total = {: .6e}".format(
        float(metrics.get("E_total", 0.0)),
        float(metrics.get("mean_total", 0.0)),
    ))
    print("  " + "-"*60)
    print("  {:<14} {:>14} {:>18} {:>8}   {:>14}".format(
        "term", "contrib_sum", "mean_per_px", "weight", "contrib_sum"))
    for name, contrib, mean_px, w in rows:
        if hide_zero_weight and (w == 0.0):
            continue
        print("  {:<14} {:>14.6e} {:>18.6e} {:>8g}   {:>14.6e}".format(
            name, float(contrib), float(mean_px), w, float(contrib)
        ))

    # Optional diagnostics: show *raw* ungated alignments (not used in action)
    aq_raw = float(metrics.get("align_q_sum_raw", 0.0))
    ap_raw = float(metrics.get("align_p_sum_raw", 0.0))
    if abs(aq_raw) + abs(ap_raw) > 0:
        print("  (diagnostic, not in action) align_q_raw = {: .6e} | align_p_raw = {: .6e}".format(aq_raw, ap_raw))
    print()



def compute_agent_metrics(ctx: Any, agent: Any) -> Dict[str, float]:
    """
    Returns per-agent RAW (unweighted) energy components.
    We keep self/feedback unweighted here to mirror alignment’s convention.
    Mass/curv are also raw; weighting (if any) is applied in compute_global_metrics.
    """
    cfg = getattr(ctx, "step_cfg", None)
    tau = float(getattr(cfg, "support_tau", 1e-6)) if cfg is not None else 1e-6
    m = mask_hw(getattr(agent, "mask", None), tau=tau, mode="bool2")
    if (m is None) or (not np.any(m)):
        return {
            "self_sum": 0.0, "self_mean": 0.0,
            "feedback_sum": 0.0, "feedback_mean": 0.0,
           
        }

    S = int(np.count_nonzero(m)) or 1

    # Prefer per-agent accumulators populated earlier (raw, unweighted)
    aid = getattr(agent, "id", None)
    self_sum = fb_sum = 0.0
    if aid is not None:
        v = energy_acc_get(ctx, f"self_sum[{aid}]", None)

        if v is not None: self_sum = float(v)
        v = energy_acc_get(ctx, f"feedback_sum[{aid}]", None)
        if v is not None: fb_sum = float(v)

    self_mean = self_sum / S
    fb_mean   = fb_sum   / S

    
    return {
        "self_sum": self_sum, "self_mean": self_mean,
        "feedback_sum": fb_sum, "feedback_mean": fb_mean,
        
    }



def compute_global_metrics(ctx, agents):
    

    cfg     = getattr(ctx, "step_cfg", None)
    tau     = cfg.support_tau
    n_jobs  = int(getattr(cfg, "metrics_n_jobs", 1))

    # Weights & options used in both grads and energy
    alpha   = float(getattr(cfg, "alpha", 0.0))
    lambd   = float(getattr(cfg, "feedback_weight", 0.0))

    def _one(a):
        m = mask_hw(a.mask, tau=tau, mode="bool2")
        S = int(np.count_nonzero(m))
        if S <= 0:
            return None
        d = compute_agent_metrics(ctx, a)  # RAW component pieces (self/feedback/mass/curv)
        return d, S

    with threadpool_limits(1):
        outs = Parallel(n_jobs=max(1, n_jobs), backend="threading", batch_size="auto")(
            delayed(_one)(a) for a in agents
        )

    totals = {"self_sum":0.0,"feedback_sum":0.0,"_S":0}

    for res in outs:
        if res is None:
            continue
        d, S = res
        for k in ("self_sum","feedback_sum"):
            totals[k] += float(d[k])
        totals["_S"] += int(S)

    S_tot = max(totals["_S"], 1)

    # Means (diagnostic)
    out = dict(totals)
    out["self_mean"]     = out["self_sum"]     / S_tot
    out["feedback_mean"] = out["feedback_sum"] / S_tot
   

    # === Alignment: use β-weighted sums (variational) ===
    align_q_sum_beta = _sum_beta_KL_from_ctx(ctx, "q")
    align_p_sum_beta = _sum_beta_KL_from_ctx(ctx, "p")

    # Store the β-weighted alignment as the canonical alignment energy
    out["align_q_sum"]  = align_q_sum_beta
    out["align_p_sum"]  = align_p_sum_beta
    out["align_q_mean"] = align_q_sum_beta / S_tot
    out["align_p_mean"] = align_p_sum_beta / S_tot

    # === Build weighted contributions actually used in the action ===
    self_w     = alpha * out["self_sum"]
    feedback_w = lambd * out["feedback_sum"]
    align_q_w  = out["align_q_sum"]    # β already included
    align_p_w  = out["align_p_sum"]    # β already included
    

    # existing weighted pieces:
    out["E_total"] = float(
        self_w + feedback_w +
        align_q_w + align_p_w
    )
    
    # NEW: gamma contributions (already weighted by gamma in the product)
    gamma_A_sum = _sum_gamma_KL_from_ctx(ctx, "A", corrected=True)  # κ inferred from cfg
    gamma_B_sum = _sum_gamma_KL_from_ctx(ctx, "B", corrected=True)
    out["gamma_A_sum"] = float(gamma_A_sum)
    out["gamma_B_sum"] = float(gamma_B_sum)
    
    # include γ-terms in the action energy:
    out["E_total"] = float(out["E_total"] + gamma_A_sum + gamma_B_sum)
    
    # means (per active pixel); these are diagnostic means, not extra weights
    S_tot = float(out.get("active_pixels", 0.0) or 1.0)
    out["gamma_A_mean"] = float(gamma_A_sum / S_tot)
    out["gamma_B_mean"] = float(gamma_B_sum / S_tot)
    
    # expose “weighted” pieces for breakdown (γ already applied, so just pass through)
    out.update({
        "self_sum_w": self_w, "feedback_sum_w": feedback_w,
        "align_q_sum_w": align_q_w, "align_p_sum_w": align_p_w,
        "gamma_A_sum_w": float(gamma_A_sum), "gamma_B_sum_w": float(gamma_B_sum),
    })


    # (Optional) keep raw ungated alignment sums ONLY as clearly-labeled diagnostics
    # NOTE: not used in E_total; shown only if you explicitly print them
    out["align_q_sum_raw"] = float(getattr(ctx, "energy_acc", {}).get("align_q_sum", 0.0))
    out["align_p_sum_raw"] = float(getattr(ctx, "energy_acc", {}).get("align_p_sum", 0.0))

    return out


def compute_total_action(ctx, agents, precomputed_metrics=None):
    
    # 1) Geometric piece
    M_geom = precomputed_metrics if (precomputed_metrics is not None) \
             else compute_global_metrics(ctx, agents)
    A_geom = float(M_geom.get("E_total", 0.0))

    
    # 4) A terms (unchanged)
    fields = getattr(ctx, "fields", {}) or {}
    A_cov = float(fields.get("A_cov_energy_last", 0.0))
    A_curv = float(fields.get("A_curv_energy", 0.0))
    A_tot = float(A_geom + A_curv + A_cov )

    return {
        "Action_total": A_tot,
        "Geom_total":   A_geom,
        "A_curv":       A_curv,
        "A_cov":        A_cov,
        "self_sum":     float(M_geom.get("self_sum", 0.0)),
        "feedback_sum": float(M_geom.get("feedback_sum", 0.0)),
        "align_q_sum":  float(M_geom.get("align_q_sum", 0.0)),
        "align_p_sum":  float(M_geom.get("align_p_sum", 0.0)),
        # NEW:
        "gamma_A_sum":  float(M_geom.get("gamma_A_sum", 0.0)),
        "gamma_B_sum":  float(M_geom.get("gamma_B_sum", 0.0)),
    }





def summarize_beta_fiber(ctx, agents, *, which: str = "q") -> dict:
    """
    Collect β and KL stats for a fiber ('q' or 'p') and run a per-pixel softmax consistency check.
    Compatible with both legacy per-fiber maps and the new unified maps keyed as (which, i, j).
    """
    if which not in ("q", "p"):
        raise ValueError(f"summarize_beta_fiber: which must be 'q' or 'p', got {which!r}")

    # ---- Resolve config (supports {"q": {...}, "p": {...}} or flat dict) ----
    cfg = getattr(ctx, "beta_cfg", {}) or {}
    sub = cfg.get(which, cfg)
    mode   = str(sub.get("mode", "")).lower()
    kappa  = float(sub.get("kappa", 1.0))
    detach = bool(sub.get("detach", True))

    # ---- Gather edge maps (prefer unified; fallback to legacy) ----
    beta_map, kl_map = {}, {}

    # 1) New unified maps
    beta_uni = getattr(ctx, "_edge_beta", {}) or {}
    kl1_uni  = getattr(ctx, "_edge_kl1", {}) or {}
    kl_uni   = getattr(ctx, "_edge_kl",  {}) or {}
    kl_src   = kl1_uni if kl1_uni else kl_uni

    for key, B in beta_uni.items():
        try:
            w, i_id, j_id = key
        except Exception:
            continue
        if str(w) == which:
            beta_map[(int(i_id), int(j_id))] = B
    for key, K in kl_src.items():
        try:
            w, i_id, j_id = key
        except Exception:
            continue
        if str(w) == which:
            kl_map[(int(i_id), int(j_id))] = K

    # 2) Legacy per-fiber maps (only if we didn't get any from unified)
    if not beta_map:
        beta_legacy = getattr(ctx, "_edge_beta_q" if which == "q" else "_edge_beta_p", {}) or {}
        for (i_id, j_id), B in beta_legacy.items():
            beta_map[(int(i_id), int(j_id))] = B
    if not kl_map:
        kl_legacy = getattr(ctx, "_edge_kl_q" if which == "q" else "_edge_kl_p", {}) or {}
        for (i_id, j_id), K in (kl_legacy or {}).items():
            kl_map[(int(i_id), int(j_id))] = K

    # ---- Collect values ----
    if not beta_map:
        raise RuntimeError(f"[β/{which}] no valid β values collected")

    beta_vals, kl_vals = [], []
    recv_to_edges = {}  # i_id -> list of β_ij arrays (keep full arrays for per-pixel checks)
    for (i_id, j_id), B in beta_map.items():
        b = np.asarray(B, dtype=np.float64)
        beta_vals.append(b)
        if (i_id, j_id) in kl_map:
            kl_vals.append(np.asarray(kl_map[(i_id, j_id)], dtype=np.float64))
        recv_to_edges.setdefault(int(i_id), []).append(b)

    if not kl_vals:
        raise RuntimeError(f"[β/{which}] no valid KL values collected")

    beta_flat = np.concatenate([v.ravel() for v in beta_vals])
    kl_flat   = np.concatenate([v.ravel() for v in kl_vals])

    summary = {
        "which": which,
        "mode": mode,
        "kappa": kappa,
        "detach": detach,
        "edges": len(beta_map),
        "recv": len(recv_to_edges),
        "beta_min": float(np.nanmin(beta_flat)),
        "beta_mean": float(np.nanmean(beta_flat)),
        "beta_max": float(np.nanmax(beta_flat)),
        "kl_min": float(np.nanmin(kl_flat)),
        "kl_med": float(np.nanmedian(kl_flat)),
        "kl_mean": float(np.nanmean(kl_flat)),
        "kl_max": float(np.nanmax(kl_flat)),
    }

    # ---- Per-pixel softmax consistency check ----
    if mode in ("softmax", "sm", "normexp"):
        worst_dev = 0.0
        worst_i   = None
        for i_id, bmaps in recv_to_edges.items():
            # Stack sender maps: (J, *S)
            B = np.stack([np.asarray(x, dtype=np.float64) for x in bmaps], axis=0)
            # Only check pixels where at least one sender overlaps for this receiver
            overlap_any = np.any(B > 0, axis=0)
            if not np.any(overlap_any):
                continue
            sumB = np.sum(B, axis=0)
            dev_map = np.abs(sumB - 1.0)
            dev = float(np.nanmax(dev_map[overlap_any]))
            if dev > worst_dev:
                worst_dev = dev
                worst_i = i_id
        summary["softmax_worst_dev"] = worst_dev
        summary["softmax_worst_recv"] = int(worst_i) if worst_i is not None else None
        # Reasonable tolerance for fp32-heavy paths
        if worst_dev > 5e-3:
            raise RuntimeError(f"[β/{which}] worst softmax deviation {worst_dev:.3e} at receiver i={worst_i}")

    return summary



def print_beta_summary(ctx, agents):
    q = summarize_beta_fiber(ctx, agents, which="q")
    p = summarize_beta_fiber(ctx, agents, which="p")
    step = int(getattr(ctx, "global_step", -1))

    def _fmt(f):
        return (
            f"\n[β/{f['which']} | step {step}] "
            f"mode={f['mode']} κ={f['kappa']:.3g} detach={f['detach']} "
            f"| edges={f['edges']} recv={f['recv']}\n"
            f"β[min/mean/max] = {f['beta_min']:.3g} / {f['beta_mean']:.3g} / {f['beta_max']:.3g}\n"
            f"KL[min/med/mean/max] = {f['kl_min']:.3g} / {f['kl_med']:.3g} / "
            f"{f['kl_mean']:.3g} / {f['kl_max']:.3g}\n"
        )

    print(_fmt(q))
    print(_fmt(p))

    # Softmax consistency (use the precomputed worst from summarize_beta_fiber)
    for f in (q, p):
        if f["mode"] not in ("softmax", "sm", "normexp"):
            continue
        worst_dev  = float(f.get("softmax_worst_dev", 0.0))
        worst_recv = f.get("softmax_worst_recv", None)
        if worst_dev > 1e-3:
            raise RuntimeError(
                f"[β/{f['which']}] worst softmax deviation {worst_dev:.3e} "
                f"at receiver i={worst_recv}"
            )




