# -*- coding: utf-8 -*-
"""
Created on Thu Jul 24 17:54:26 2025

@author: chris and christine
"""
from scipy.ndimage import gaussian_filter
import core.config as config
import numpy as np
from core.agent_schema import Agent
from numpy.random import default_rng  
from core.bundle_morphism_utils import build_intertwiner_bases
from core.omega import retract_phi_principal
from core.numerical_utils import sanitize_sigma  
from utils import make_soft_mask, _ensure_q_to_p_shape, _ensure_p_to_q_shape, zero_all_gradients


def create_agent_mask_and_center(domain_size, rng, radius_range, fixed_center=None):
    radius = rng.uniform(*radius_range)
    center = fixed_center or tuple(rng.integers(0, s) for s in domain_size)
    # Return both float mask and a bool mask derived from the same cutoff rule
    mask, mask_bool = make_soft_mask(center, radius, domain_size, return_bool=True)
    return center, radius, mask, mask_bool



def initialize_agents(
    seed: int,
    domain_size: tuple[int, int],
    N: int,
    lie_algebra_dim: int,
    visualize: bool = False,
    fixed_location: bool = True,
    generators_q=None,
    generators_p=None,
) -> list:
    """
    Initialize N agents over the given domain.

    Guarantees
    ----------
    * If generators are provided (shape (3,K,K)), we enforce K_q/K_p from them.
    * Φ0 (Kp×Kq) and Φ̃0 (Kq×Kp) are built from intertwiners and shape-checked.
    * Covariances remain SPD both inside and outside masks.
    * φ/φ̃ are initialized with masked-normalized blur for L-invariance.
    """
    import numpy as np
    

    rng   = default_rng(seed)
    dtype = getattr(config, "dtype", np.float32)
    cfg   = {k: getattr(config, k) for k in dir(config) if not k.startswith("__")}

    # --- config / knobs ---
    phi_init         = cfg.get("phi_init")
    phi_model_offset = float(cfg.get("phi_model_offset", 0.1))
    max_neighbors    = int(cfg.get("max_neighbors", 8))
    overlap_eps      = float(cfg.get("overlap_eps", 1e-6))
    diagonal_sigma   = bool(cfg.get("diagonal_sigma", False))
    sigma_out_val    = float(cfg.get("sigma_outside_val", 1000.0))
    init_smooth_sig  = float(cfg.get("init_smooth_sigma", 2.0))

    # ---------------- Generators ----------------
    G_q = generators_q
    G_p = generators_p
    if (G_q is None) or (G_p is None):
        raise ValueError("initialize_agents requires both generators_q and generators_p.")

    G_q = np.asarray(G_q, dtype=np.float32)
    G_p = np.asarray(G_p, dtype=np.float32)

    if not (G_q.ndim == 3 and G_q.shape[0] == 3 and G_q.shape[1] == G_q.shape[2]):
        raise AssertionError(f"G_q must be (3,Kq,Kq), got {G_q.shape}")
    if not (G_p.ndim == 3 and G_p.shape[0] == 3 and G_p.shape[1] == G_p.shape[2]):
        raise AssertionError(f"G_p must be (3,Kp,Kp), got {G_p.shape}")

    K_q = int(G_q.shape[1])
    K_p = int(G_p.shape[1])

    # ---------------- Per-agent initialization ----------------
    fixed_center = (domain_size[0] // 2, domain_size[1] // 2) if fixed_location else None
    agents: list = []

    for n in range(N):
        center, radius, mask, _ = create_agent_mask_and_center(
            domain_size, rng,
            radius_range=cfg.get("agent_radius_range", (5, 10)),
            fixed_center=fixed_center,
        )

        # --- Belief (Q-fiber) fields (masked + masked-normalized smoothing inside generate_*) ---
        mu_q, sigma_q = generate_mu_sigma_fields(
            domain_size=domain_size, rng=rng, K=K_q,
            mu_range=config.q_mu_range, sigma_range=config.q_sigma_range,
            mask=mask, sigma_outside_val=sigma_out_val,
            dtype=dtype, smooth_sigma=init_smooth_sig,
            diagonal_sigma=diagonal_sigma,
        )
        # Keep Σ in float64 for numerical stability
        sigma_q = np.asarray(sigma_q, dtype=np.float64)

        # --- Model (P-fiber) fields ---
        mu_p, sigma_p = generate_mu_sigma_fields(
            domain_size=domain_size, rng=rng, K=K_p,
            mu_range=config.p_mu_range, sigma_range=config.p_sigma_range,
            mask=mask, sigma_outside_val=sigma_out_val,
            dtype=dtype, smooth_sigma=init_smooth_sig,
            diagonal_sigma=diagonal_sigma,
        )
        
        sigma_p = np.asarray(sigma_p, dtype=np.float64)

        # --- so(3) algebra fields (masked-normalized blur = True for L-invariance) ---
        phi, phi_model = initialize_phi_pair(
            domain_size, lie_algebra_dim, rng, phi_init, phi_model_offset, mask,
            smooth_sigma=getattr(config, "phi_init_smooth_sigma", 0.5),
            use_masked_blur=True,
        )
        phi       = retract_phi_principal(phi,       margin=1e-6)
        phi_model = retract_phi_principal(phi_model, margin=1e-6)

        # --- Construct agent object ---
        agent = construct_agent_object(
            agent_id=int(n),
            center=center,
            radius=radius,
            mask=mask.astype(dtype, copy=False),
            mu_q=mu_q.astype(dtype, copy=False),
            sigma_q=sigma_q,                     # keep float64
            mu_p=mu_p.astype(dtype, copy=False),
            sigma_p=sigma_p,                     # keep float64
            phi=phi.astype(dtype, copy=False),
            phi_model=phi_model.astype(dtype, copy=False),
            dtype=dtype,
        )

        # Attach generators (float32, (3,K,K))
        agent.generators_q = G_q
        agent.generators_p = G_p

        # Intertwiner bases (Φ0: Kp×Kq, Φ̃0: Kq×Kp)
        Phi_0_raw, Phi_tilde_0_raw, _ = build_intertwiner_bases(G_q, G_p, method="auto", return_meta=True)
        Phi_0       = _ensure_q_to_p_shape(Phi_0_raw, K_p, K_q).astype(np.float32, copy=False)
        Phi_tilde_0 = _ensure_p_to_q_shape(Phi_tilde_0_raw, K_q, K_p).astype(np.float32, copy=False)

        agent.Phi_0       = Phi_0
        agent.Phi_tilde_0 = Phi_tilde_0

        agent.morphisms_dirty = False
        zero_all_gradients(agent)

        agents.append(agent)

    # --- Neighbors (IoU metric; symmetric optional) ---
    assign_neighbors_simple(
        agents,
        overlap_eps=overlap_eps,
        max_neighbors=max_neighbors,
        symmetric=bool(cfg.get("neighbors_symmetric", False)),
    )
    return agents



def construct_agent_object(
    agent_id,
    center,
    radius,
    mask,
    mu_q, sigma_q,
    mu_p, sigma_p,
    phi, phi_model,
    dtype=np.float32
) -> Agent:
    """
    Build a level-0 Agent (no parents, no cross-scale maps yet).
    """
    a = Agent(
        id=agent_id,
        center=center,
        radius=radius,
        mask=mask.astype(dtype),

        mu_q_field=mu_q.astype(dtype),
        sigma_q_field=sigma_q.astype(np.float64),
        mu_p_field=mu_p.astype(dtype),
        sigma_p_field=sigma_p.astype(np.float64),

        phi=phi.astype(dtype),
        phi_model=phi_model.astype(dtype),

        neighbors=[],
    )
    # Ensure level-0 & empty relations
    a.level = 0
    a.parent_ids = []
    a.child_ids = []
        
    return a


def _logm_spd(S, eps=1e-12):
    """Symmetric log for SPD matrices; vectorized over leading dims."""
    import numpy as np
    S = 0.5 * (S + np.swapaxes(S, -1, -2))
    # float64 for stability
    w, V = np.linalg.eigh(S.astype(np.float64, copy=False))
    w = np.maximum(w, eps)
    L = (V * np.log(w)[..., None, :]) @ np.swapaxes(V, -1, -2)
    # keep symmetric
    return 0.5 * (L + np.swapaxes(L, -1, -2))

def _expm_spd(L):
    """Symmetric exp for SPD matrices in log domain; vectorized."""
    import numpy as np
    L = 0.5 * (L + np.swapaxes(L, -1, -2))
    w, V = np.linalg.eigh(L.astype(np.float64, copy=False))
    S = (V * np.exp(w)[..., None, :]) @ np.swapaxes(V, -1, -2)
    return 0.5 * (S + np.swapaxes(S, -1, -2))



def generate_mu_sigma_fields(
    domain_size,
    rng,
    K,
    mu_range,
    sigma_range,
    mask=None,
    sigma_outside_val=None,   # <- retained for compatibility; not used directly below
    dtype=np.float32,
    smooth_sigma=None,
    diagonal_sigma=None,
    eps=None,
    floor=None,
    *,
    cond0: float = 10,
    trace_match: bool = False,
):
    import numpy as np
    from scipy.ndimage import gaussian_filter

    # --- helpers (as you had) ---
    def blur_scalar_or_channels(arr, sigma):
        if mask is None:
            if arr.ndim == len(S):
                return gaussian_filter(arr, sigma=sigma, mode="wrap")
            out = np.empty_like(arr)
            tail = int(np.prod(arr.shape[len(S):])) or 1
            flat = arr.reshape(S + (tail,))
            for c in range(tail):
                out.reshape(S + (tail,))[..., c] = gaussian_filter(
                    flat[..., c], sigma=sigma, mode="wrap"
                )
            return out
        else:
            return masked_normalized_blur(arr, mask, sigma=sigma)

    # --- defaults ---
    eps = 1e-6 if eps is None else float(eps)
    smooth_sigma = 2.0 if smooth_sigma is None else float(smooth_sigma)
    diagonal_sigma = bool(False if diagonal_sigma is None else diagonal_sigma)

    # --- shapes / targets ---
    S = tuple(int(s) for s in domain_size)
    D = len(S)
    lo_s, hi_s = float(sigma_range[0]), float(sigma_range[1])
    target_scale = 0.5 * (lo_s + hi_s)
    target_trace = K * target_scale

    # --- μ field ---
    mu = rng.uniform(*mu_range, size=S + (K,)).astype(dtype)
    mu = blur_scalar_or_channels(mu, smooth_sigma)

    # --- build Σ_in (your existing logic) ---
    if diagonal_sigma:
        diag_raw = rng.uniform(lo_s, hi_s, size=S + (K,)).astype(dtype)
        diag_raw = blur_scalar_or_channels(diag_raw, smooth_sigma)
        lam_min = np.maximum(eps, diag_raw.min(axis=-1, keepdims=True))
        lam_min = np.maximum(lam_min, target_scale / max(cond0, 1.0))
        diag = np.clip(diag_raw, lam_min, lam_min * max(cond0, 1.0))
        if trace_match:
            tr_now = np.sum(diag, axis=-1, keepdims=True)
            diag = diag * (target_trace / np.maximum(tr_now, eps))
        sigma_in = np.zeros(S + (K, K), dtype=np.float64)
        for k in range(K):
            sigma_in[..., k, k] = diag[..., k].astype(np.float64, copy=False)
    else:
        B = rng.normal(0.0, 1.0, size=S + (K, K)).astype(dtype)
        for i in range(K):
            for j in range(K):
                B[..., i, j] = blur_scalar_or_channels(B[..., i, j], smooth_sigma)
        # polar / orthogonalize
        U, _, Vt = np.linalg.svd(B, full_matrices=False)
        Q = (U @ Vt).astype(np.float64, copy=False)
        detQ = np.linalg.det(Q)
        neg = detQ < 0
        if np.any(neg):
            U = U.copy()
            U[neg, :, -1] *= -1.0
            Q = (U @ Vt).astype(np.float64, copy=False)

        lam_min_base = rng.uniform(
            max(eps, lo_s / max(cond0, 1.0)),
            max(target_scale / max(cond0, 1.0), hi_s / max(cond0, 1.0)),
            size=S,
        ).astype(dtype)
        lam_min = blur_scalar_or_channels(lam_min_base, smooth_sigma)[..., None]
        lam_min = np.clip(lam_min, eps, None)
        u = rng.uniform(0.0, 1.0, size=S + (K,)).astype(dtype)
        r = (max(cond0, 1.0)) ** u
        lam = (lam_min * r).astype(np.float64, copy=False)
        if trace_match:
            tr_now = np.sum(lam, axis=-1, keepdims=True)
            lam = lam * (target_trace / np.maximum(tr_now, eps))
        sigma_in = (Q * lam[..., None, :]) @ np.swapaxes(Q, -1, -2)
        sigma_in = 0.5 * (sigma_in + np.swapaxes(sigma_in, -1, -2))

    # --- SPD sanitization inside (just in case) ---
    sigma_in = sanitize_sigma(sigma_in, eps=eps).astype(np.float64, copy=False)

    # --- PRINCIPLED OUTSIDE BEHAVIOR: log-Euclidean blend ---
    if mask is not None:
        # soft weight in [0,1]; if your mask is hard/binary, it's still fine
        w = mask.astype(np.float64)
        W = w.reshape(S + (1, 1))

        # choose a neutral outside SPD: scaled identity with target scale
        # (you can change sigma0 if you prefer a different neutral outside variance)
        sigma0 = float(target_scale)
        # log( sigma0 * I ) = (log sigma0) * I
        log_sigma0 = np.log(max(sigma0, eps))
        eyeK64 = np.eye(K, dtype=np.float64).reshape((1,) * D + (K, K))

        # log Σ_in per pixel
        Lin = _logm_spd(sigma_in, eps=max(eps, 1e-12))
        # convex combination in log domain
        L = (1.0 - W) * (log_sigma0 * eyeK64) + W * Lin
        # back to SPD
        sigma_field = _expm_spd(L)
        sigma_field = sanitize_sigma(sigma_field, eps=eps)  # final safety

        # μ “nonexistence” outside: taper by the same soft mask if desired
        mu = (w[..., None] * mu).astype(dtype, copy=False)
    else:
        sigma_field = sigma_in  # full-domain init, no blending

    # keep Σ in float64 for downstream Fisher/natural grads
    return mu.astype(dtype, copy=False), sigma_field












def OLDgenerate_mu_sigma_fields(
    domain_size,
    rng,
    K,
    mu_range,
    sigma_range,
    mask=None,
    sigma_outside_val=None,
    dtype=np.float32,
    smooth_sigma=None,
    diagonal_sigma=None,
    eps=None,
    floor=None,
    *,
    cond0: float = 10,
    trace_match: bool = False,
):
    """
    Generate spatially varying (μ, Σ) on an N-D periodic grid.

    Shapes:
      mu_field    : (*S, K)
      sigma_field : (*S, K, K)

    Uses masked-normalized blur when `mask` is given to prevent leakage from outside
    (i.e., blur(x*mask)/blur(mask) with periodic 'wrap' boundaries).
    """
    import numpy as np
    from scipy.ndimage import gaussian_filter
    
   
    # ---------------- helpers ----------------
    
    def blur_scalar_or_channels(arr, sigma):
        if mask is None:
            # fast path: standard periodic blur
            if arr.ndim == len(S):  # scalar field (*S,)
                return gaussian_filter(arr, sigma=sigma, mode="wrap")
            # channel last (*S, C...)
            out = np.empty_like(arr)
            # flatten trailing channels to loop
            tail = int(np.prod(arr.shape[len(S):])) or 1
            flat = arr.reshape(S + (tail,))
            for c in range(tail):
                out.reshape(S + (tail,))[..., c] = gaussian_filter(
                    flat[..., c], sigma=sigma, mode="wrap"
                )
            return out
        else:
            # mask-aware path
            return masked_normalized_blur(arr, mask, sigma=sigma)

    # --------------- defaults / guards ---------------
    eps = 1e-6 if eps is None else float(eps)
    sigma_outside_val = 1e3 if sigma_outside_val is None else float(sigma_outside_val)
    smooth_sigma = 2.0 if smooth_sigma is None else float(smooth_sigma)
    diagonal_sigma = bool(False if diagonal_sigma is None else diagonal_sigma)

    # --------------- spatial shape -------------------
    S = tuple(int(s) for s in domain_size)
    D = len(S)

    lo_s, hi_s = float(sigma_range[0]), float(sigma_range[1])
    target_scale = 0.5 * (lo_s + hi_s)
    target_trace = K * target_scale

    # --------------- μ field -------------------------
    mu = rng.uniform(*mu_range, size=S + (K,)).astype(dtype)
    mu = blur_scalar_or_channels(mu, smooth_sigma)  # vector-friendly blur

    # --- helper: per-pixel orthogonal projection via SVD (polar factor) ---
    def _orthogonalize_field(B):
        # B: (*S, K, K) -> Q with Q^T Q = I and det(Q) = +1 (per pixel)
        U, _, Vt = np.linalg.svd(B, full_matrices=False)
        Q = U @ Vt
        detQ = np.linalg.det(Q)
        neg = detQ < 0
        if np.any(neg):
            U = U.copy()
            U[neg, :, -1] *= -1.0
            Q = U @ Vt
        return Q.astype(dtype, copy=False)

    # --------------- Σ initialization ----------------
    if diagonal_sigma:
        # Smooth random diagonal, then clamp to [lam_min, lam_min*cond0]
        diag_raw = rng.uniform(lo_s, hi_s, size=S + (K,)).astype(dtype)
        diag_raw = blur_scalar_or_channels(diag_raw, smooth_sigma)

        lam_min = np.maximum(eps, diag_raw.min(axis=-1, keepdims=True))
        lam_min = np.maximum(lam_min, target_scale / max(cond0, 1.0))

        diag = np.clip(diag_raw, lam_min, lam_min * max(cond0, 1.0))

        # Optional: trace_match for diagonal case (keeps scale consistent)
        if trace_match:
            tr_now = np.sum(diag, axis=-1, keepdims=True)  # (*S,1)
            diag = diag * (target_trace / np.maximum(tr_now, eps))

        sigma_field = np.zeros(S + (K, K), dtype=dtype)
        for k in range(K):
            sigma_field[..., k, k] = diag[..., k]

    else:
        # --- Controlled spectrum full covariance ---
        # Optional clean isotropic shortcut
        if cond0 == 1 and trace_match:
            eyeK = np.eye(K, dtype=dtype).reshape((1,) * D + (K, K))
            sigma_field = (target_scale * eyeK).copy()
        else:
            # 1) Smooth random field B -> orthogonal Q
            B = rng.normal(0.0, 1.0, size=S + (K, K)).astype(dtype)
            # blur each (i,j) channel without leakage (vectorized loop)
            for i in range(K):
                for j in range(K):
                    B[..., i, j] = blur_scalar_or_channels(B[..., i, j], smooth_sigma)
            Q = _orthogonalize_field(B)  # (*S, K, K)

            # 2) Smooth per-pixel λ_min field, around target_scale/cond0
            lam_min_base = rng.uniform(
                max(eps, lo_s / max(cond0, 1.0)),
                max(target_scale / max(cond0, 1.0), hi_s / max(cond0, 1.0)),
                size=S,
            ).astype(dtype)
            lam_min = blur_scalar_or_channels(lam_min_base, smooth_sigma)[..., None]
            lam_min = np.clip(lam_min, eps, None)  # (*S, 1)

            # 3) Per-pixel eigenvalue ratios r_k ∈ [1, cond0] (log-uniform)
            u = rng.uniform(0.0, 1.0, size=S + (K,)).astype(dtype)
            r = (max(cond0, 1.0)) ** u  # (*S, K)

            # 4) Build eigenvalues and (optional) trace matching
            lam = lam_min * r  # (*S, K)
            if trace_match:
                tr_now = np.sum(lam, axis=-1, keepdims=True)  # (*S, 1)
                lam = lam * (target_trace / np.maximum(tr_now, eps))

            # 5) Σ = Q diag(lam) Q^T
            sigma_field = (Q * lam[..., None, :]) @ np.swapaxes(Q, -1, -2)

    # --------------- SPD sanitization ----------------
    sigma_field = sanitize_sigma(sigma_field, eps=eps)

    # --------------- Mask application ----------------
    if mask is not None:
        m = mask.astype(dtype)
        # μ outside → 0
        mu = m[..., None] * mu
        # Σ outside → sigma_outside * I
        eyeK = np.eye(K, dtype=dtype).reshape((1,) * D + (K, K))
        sigma_outside = sigma_outside_val * eyeK
        m_expand = m.reshape(S + (1, 1))
        sigma_field = m_expand * sigma_field + (1.0 - m_expand) * sigma_outside

    return mu, sigma_field





def masked_normalized_blur(x, m, sigma, eps_local=1e-6, mode="wrap"):
    """
    Soft-mask version (taper via m):
      y = [ blur(x*m) / blur(m) ] * m
    - Blur only over spatial axes, NOT across channels.
    - Uses float64 internally for stability, casts back to x.dtype at the end.
    - Final soft multiply is wrapped in errstate(under='ignore') so global
      seterr(under='raise') won't trip when m has tiny values.
    """
    import numpy as np
    from scipy.ndimage import gaussian_filter

    x = np.asarray(x)
    m = np.asarray(m)

    S_nd = m.ndim
    trailing = x.ndim - S_nd
    if trailing < 0:
        raise ValueError("mask must not have more dims than x")

    # Build sigma over all axes: blur spatial, no blur on channels
    if np.isscalar(sigma):
        sigma_full    = (float(sigma),) * S_nd + (0.0,) * trailing
        sigma_spatial = (float(sigma),) * S_nd
    else:
        sigma = tuple(float(s) for s in sigma)
        if len(sigma) != S_nd:
            raise ValueError(f"sigma length {len(sigma)} must match spatial dims {S_nd}")
        sigma_full    = sigma + (0.0,) * trailing
        sigma_spatial = sigma

    # Promote to float64 for stable filtering & masking
    x64 = x.astype(np.float64, copy=False)
    m64 = m.astype(np.float64, copy=False)

    m_expand64 = m64[(...,) + (None,) * trailing] if trailing > 0 else m64

    # Blur with periodic boundaries; guard divisions
    with np.errstate(under='ignore', over='ignore', invalid='ignore', divide='ignore'):
        num = gaussian_filter(x64 * m_expand64, sigma=sigma_full,    mode=mode)
        den = gaussian_filter(m64,               sigma=sigma_spatial, mode=mode)
        den_expand = den[(...,) + (None,) * trailing] if trailing > 0 else den
        y = num / np.maximum(den_expand, eps_local)

    # Soft taper via mask (in float64); ignore underflow on purpose here
    with np.errstate(under='ignore'):
        y = y * m_expand64

    return y.astype(x.dtype, copy=False)





# --- main initializers ---

def initialize_phi_field(
    domain_size: tuple[int, ...],
    lie_algebra_dim: int,
    rng: np.random.Generator,
    init_scale: float,
    mask: np.ndarray,
    smooth_sigma: float | tuple[float, ...] | None = None,
    *,
    use_masked_blur: bool = False,
) -> np.ndarray:
    """
    Initialize and smooth a φ field with Gaussian noise and apply mask.
    Uses periodic blur by default for toroidal domains.
    """
    if lie_algebra_dim != 3:
        raise ValueError(f"SO(3) frames expect lie_algebra_dim=3, got {lie_algebra_dim}")

    dtype = getattr(config, "dtype", mask.dtype)
    sigma = smooth_sigma if (smooth_sigma is not None) else getattr(config, "phi_init_smooth_sigma", 0.5)

    phi_raw = rng.normal(scale=init_scale, size=(*domain_size, lie_algebra_dim)).astype(dtype)
    if use_masked_blur:
        phi_smooth = masked_normalized_blur(phi_raw, mask, sigma)
        # masked_normalized_blur already zeroes outside, so nothing else needed.
    else:
        phi_smooth = gaussian_filter(phi_raw, sigma=sigma, mode="wrap")
        phi_smooth *= mask[..., None]
    return phi_smooth
    
    return phi_smooth


def initialize_phi_pair(
    domain_size: tuple[int, ...],
    lie_algebra_dim: int,
    rng: np.random.Generator,
    phi_init: float,
    phi_model_offset: float,
    mask: np.ndarray,
    *,
    smooth_sigma: float | tuple[float, ...] | None = None,
    use_masked_blur: bool = False,
) -> tuple[np.ndarray, np.ndarray]:
    """
    Initialize φ (belief) and φ̃ (model).
      - If config.identical_models: φ̃ = 0
      - Else: φ̃ = Smooth[ φ + R·ξ ], where R ~ SO(3) (adjoint) and ξ ~ N(0, φ_model_offset^2 I)
    """
    phi = initialize_phi_field(
        domain_size, lie_algebra_dim, rng, phi_init, mask,
        smooth_sigma=smooth_sigma, use_masked_blur=use_masked_blur
    )

    if getattr(config, "identical_models", False) or phi_model_offset == 0.0:
        print("USING IDENTITICAL model phi~")
        phi_model = np.zeros_like(phi)
        return phi, phi_model

    # perturb in the Lie algebra using a single adjoint rotation (global frame twist)
    delta = rng.normal(scale=phi_model_offset, size=(*domain_size, lie_algebra_dim)).astype(phi.dtype)

    # Adjoint action of SO(3) on so(3) ≅ R^3 is an ordinary rotation
    from scipy.spatial.transform import Rotation
    R = Rotation.random(random_state=rng).as_matrix()  # (3, 3)
    delta_rot = np.einsum("ab,...b->...a", R, delta)   # (...,3)

    phi_model_raw = phi + delta_rot

    if use_masked_blur:
        phi_model = masked_normalized_blur(
            phi_model_raw,
            mask,
            smooth_sigma or getattr(config, "phi_init_smooth_sigma", 0.5),
        )  # already zero outside
    else:
        phi_model = gaussian_filter(
            phi_model_raw,
            sigma=smooth_sigma or getattr(config, "phi_init_smooth_sigma", 0.5),
            mode="wrap",
        )
        phi_model *= mask[..., None]

    return phi, phi_model


def assign_neighbors_simple(
    agents,
    overlap_eps: float = 1e-6,
    *,
    symmetric: bool = True,
    max_neighbors: int | None = None,
    topk_margin: int = 8,
) -> None:
    """
    Two agents are neighbors iff their supports overlap at any site:
      support_i(x) = (mask_i(x) > overlap_eps), x ∈ *S (N-D grid)

    Builds: a.neighbors = [{"id": <neighbor_id>, "overlap": <count>}, ...]
    If max_neighbors is set, keep the top-K by overlap (ties broken by id).
    Note: with symmetric=True we require mutual nonzero overlap, but the
    top-K selection is still performed per-receiver (lists need not be identical).
    """
    import numpy as np
    from utils import mask_hw  # project-local

    if not agents:
        return

    # Flattened boolean supports once (N-D → 1-D)
    mvecs = []
    ids   = []
    HW = None
    for i, a in enumerate(agents):
        mv = mask_hw(a, tau=overlap_eps, mode="vec")  # (HW,) bool
        if HW is None:
            HW = mv.shape[0]
        elif mv.shape[0] != HW:
            raise ValueError(f"All masks must share the same flattened size; got {mv.shape[0]} vs {HW}.")
        mvecs.append(mv.astype(np.int32, copy=False))  # int32 to avoid overflow in dot
        ids.append(int(getattr(a, "id", i)))

    ids = np.asarray(ids, dtype=np.int64)
    M = np.stack(mvecs, axis=0)              # (N, HW) int32
    inter = M @ M.T                          # (N, N) int32, safe accumulation
    inter = inter.astype(np.int64, copy=False)
    np.fill_diagonal(inter, 0)

    N = len(agents)
    for i in range(N):
        row = inter[i]
        js = np.flatnonzero(row > 0)
        if js.size == 0:
            agents[i].neighbors = []
            continue

        if symmetric:
            # keep only mutual overlaps (row>0 already; also require col>0)
            js = js[inter[js, i] > 0]
            if js.size == 0:
                agents[i].neighbors = []
                continue

        if (max_neighbors is not None) and (js.size > max_neighbors):
            counts = row[js]
            # Overfetch to soften tie bias, then stable sort by (-overlap, id)
            k_fetch = min(js.size, max_neighbors + max(1, int(topk_margin)))
            part = np.argpartition(-counts, kth=k_fetch - 1)[:k_fetch]
            cands = js[part]
            counts_c = row[cands]
            ids_c    = ids[cands]
            order = np.lexsort((ids_c, -counts_c))
            chosen = cands[order][:max_neighbors]
        else:
            counts = row[js]
            order = np.lexsort((ids[js], -counts))
            chosen = js[order]

        agents[i].neighbors = [
            {"id": int(ids[j]), "overlap": int(row[j])} for j in chosen.tolist()
        ]











        
