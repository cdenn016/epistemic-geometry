# -*- coding: utf-8 -*-
"""
Created on Wed Aug  6 12:27:32 2025

@author: chris and christine
"""
 
import numpy as np
import core.config as config
from core.transport_cache import Omega, Phi_cached, Phi
from runtime_context import cfg_get

from utils import (_fiber_keys_from_mode, _iter_overlap_pairs, _accumulate_into_agent,
                   _drain_inbox_into_dalign, _add_to_inbox)

from core.numerical_utils import (kl_gaussian,sanitize_sigma, safe_inv, push_gaussian,
                                  softmax_align_rule_receiver, softmax_align_rule_sender, 
                                  plain_rule)
from beta import gamma_maps
from runtime_context import energy_acc_add    
from utils import push_neighbor_stats, _assert_finite
from updates.accumulators import GradBuckets



# -------------------------------------------------------------------------
#                          PUBLIC ENTRYPOINTS
# -------------------------------------------------------------------------


def _bucket(dmu, dS, *, dphi=None, notes=None):
    # dmu/dS already float32 in our pipeline; cast defensively.
    return GradBuckets(
        dmu=np.asarray(dmu, np.float32),
        dS =np.asarray(dS,  np.float32),
        dphi=(None if dphi is None else np.asarray(dphi, np.float32)),
        notes=(None if notes is None else dict(notes)),
    )



def _zeros_mu_S_like(mu):
    mu = np.asarray(mu, np.float32)
    S  = mu.shape[:-1]
    K  = mu.shape[-1]
    return (np.zeros(S + (K,),    np.float32),
            np.zeros(S + (K, K), np.float32))



def grad_gamma_mu_sigma_dispatch(
    ctx, agent_i, agent_j, *, basis,
    Omega_ij=None, Phi_i=None, Phi_tilde_i=None,
    eps: float = 1e-8,
):
    

    b = str(basis).lower()

    # ---- trivial align_* bases: no cross-fiber grads here
    if b in {"align", "align_q", "align_p"}:
        mu_i_any = getattr(agent_i, "mu_p_field", None)
        if mu_i_any is None:
            mu_i_any = getattr(agent_i, "mu_q_field", None)

        mu_j_q = getattr(agent_j, "mu_q_field", None)
        if mu_j_q is None:
            mu_j_q = getattr(agent_j, "mu_p_field", None)

        mu_rec_0, S_rec_0   = _zeros_mu_S_like(mu_i_any)
        mu_send_0, S_send_0 = _zeros_mu_S_like(mu_j_q)
        return {"mu_rec": mu_rec_0, "S_rec": S_rec_0,
                "mu_send": mu_send_0, "S_send": S_send_0}

   
    # ---- full A/B need Ω (and Φ/Φ̃ for A/B or C/D)
    if Omega_ij is None:
        raise ValueError("grad_beta_mu_sigma_dispatch: Omega_ij is required for bases A/B/C/D")

    if Phi_i is None and b in {"a","b"}:
        from core.transport_cache import Phi as _Phi
        Phi_i = _Phi(ctx, agent_i, kind="q_to_p")
    if Phi_tilde_i is None and b in {"c","d"}:
        from core.transport_cache import Phi as _Phi
        Phi_tilde_i = _Phi(ctx, agent_i, kind="p_to_q")

    mu_q_j  = np.asarray(agent_j.mu_q_field,    np.float32, order="C")
    Sig_q_j = np.asarray(agent_j.sigma_q_field, np.float32, order="C")
    mu_p_i  = np.asarray(agent_i.mu_p_field,    np.float32, order="C")
    Sig_p_i = np.asarray(agent_i.sigma_p_field, np.float32, order="C")

    if b == "a":
        dmu_rec, dS_rec = grad_gamma_A_mu_sigma_i(ctx, agent_i, agent_j, Omega_ij=Omega_ij, eps=eps)
        dmu_send, dS_send = grad_gamma_A_mu_sigma_j(
            mu_j=mu_q_j, Sigma_j=Sig_q_j,
            mu_p_i=mu_p_i, Sigma_p_i=Sig_p_i,
            Omega_ij=Omega_ij, Phi_i=Phi_i, eps=eps,
        )
        _assert_finite(f"beta_grads[{basis}]",
                       dmu_rec, dS_rec, dmu_send, dS_send)
    elif b == "b":
        dmu_rec, dS_rec = grad_gamma_B_mu_sigma_i(ctx, agent_i, agent_j, Omega_ij=Omega_ij, eps=eps)
        dmu_send, dS_send = grad_gamma_B_mu_sigma_j(
            mu_j=mu_q_j, Sigma_j=Sig_q_j,
            mu_p_i=mu_p_i, Sigma_p_i=Sig_p_i,
            Omega_ij=Omega_ij, Phi_i=Phi_i, eps=eps,
        )
    
    else:
        raise ValueError(f"Unknown beta basis: {basis}")

    dS_rec  = 0.5 * (dS_rec  + np.swapaxes(dS_rec,  -1, -2)).astype(np.float32, copy=False)
    dS_send = 0.5 * (dS_send + np.swapaxes(dS_send, -1, -2)).astype(np.float32, copy=False)
    return {
        "mu_rec":  np.asarray(dmu_rec,  np.float32),
        "S_rec":   dS_rec,
        "mu_send": np.asarray(dmu_send, np.float32),
        "S_send":  dS_send,
    }


def _run_mu_sigma_pipeline(
    *,
    ctx,
    agent_i,
    which: str,                 # "q" or "p"
    dmu_self=None, dS_self=None,
    dmu_feedback=None, dS_feedback=None,
    dmu_align=None, dS_align=None,
    dmu_gamma=None, dS_gamma=None,
    natural_project: bool = True,
):
    """
    Canonical μ/Σ post-processing and (optionally) accumulation for one fiber.

    Steps:
      1) Sum all provided buckets (treat missing as zeros).
      2) Symmetrize Σ-gradient.
      3) Natural-gradient projection (uses apply_natural_gradient_batch).
      4) Return (delta_mu, delta_S); caller can accumulate.
    """
    import numpy as np

    # Fiber-specific keys
    mu_key  = "mu_q_field"    if which == "q" else "mu_p_field"
    S_key   = "sigma_q_field" if which == "q" else "sigma_p_field"

    # Shapes / zeros
    mu_i = np.asarray(getattr(agent_i, mu_key), np.float32)
    S_i  = np.asarray(getattr(agent_i, S_key),  np.float32)
    S    = mu_i.shape[:-1]
    K    = mu_i.shape[-1]

    def _zmu(x): return np.zeros(S + (K,),   np.float32) if x is None else np.asarray(x, np.float32, order="C")
    def _zS (x): return np.zeros(S + (K,K),  np.float32) if x is None else np.asarray(x, np.float32, order="C")

    # 1) sum buckets
    dmu_total = _zmu(dmu_self) + _zmu(dmu_feedback) + _zmu(dmu_align) + _zmu(dmu_gamma)
    dS_total  = _zS (dS_self)  + _zS (dS_feedback)  + _zS (dS_align)  + _zS (dS_gamma)

    # 2) symmetrize
    dS_total = 0.5 * (dS_total + np.swapaxes(dS_total, -1, -2))

    if not natural_project:
        return dmu_total, dS_total

    # 3) natural projection (correct signature — no Sigma/Sigma_inv kwargs)
    delta_mu, delta_S = apply_natural_gradient_batch(
        ctx,
        getattr(agent_i, mu_key),
        getattr(agent_i, S_key),
        dmu_total,
        dS_total,
        mask=getattr(agent_i, "mask", None),
        assume_sanitized=True,
        grad_sigma_is_symmetric=True,
        use_float64=True,
    )

    # 4) return to caller; accumulation can be handled outside
    return delta_mu, delta_S



def accumulate_mu_sigma_gradient(ctx, agent_i, agents, mode):
    """
    Accumulate natural gradients (μ, Σ) for belief or model.

    Structure:
      1) Resolve fiber + keys (q/p)
      2) Pull Φ, Φ̃ from cache and push (q,p) once
      3) Self & feedback grads (receiver-only)
      4) Pairwise alignment block (β·ALIGN) + γ(A/B)
      5) Combine -> natural projection via _run_mu_sigma_pipeline -> accumulate to agent
    """
    if ctx is None:
        raise RuntimeError("accumulate_mu_sigma_gradient: ctx required.")

  
    from runtime_context import cfg_get
    
    eps   = float(cfg_get(ctx, "eps", 1e-6))
    tau   = float(cfg_get(ctx, "support_tau", 1e-6))
    alpha = float(cfg_get(ctx, "alpha", 0.0))
    lambd = float(cfg_get(ctx, "feedback_weight", 0.0))
    accum_send_cfg = bool(cfg_get(ctx, "accumulate_sender_grads", False))

    which, field, mu_key, S_key, gmu_key, gS_key = _fiber_keys_from_mode(mode)

    # 2) Φ/Φ̃ pushes once
    Phi  = Phi_cached(ctx, agent_i, kind="q_to_p")
    Phit = Phi_cached(ctx, agent_i, kind="p_to_q")

    mu_q = getattr(agent_i, "mu_q_field"); S_q = getattr(agent_i, "sigma_q_field")
    mu_p = getattr(agent_i, "mu_p_field"); S_p = getattr(agent_i, "sigma_p_field")

    mu_q_push, S_q_push, inv_q_push = push_gaussian(
        mu_q, S_q, Phi, eps=eps, return_inv=True,
        Sigma_inv=getattr(agent_i, "sigma_q_inv", None),
        assume_orthogonal=False
    )
    mu_p_push, S_p_push, inv_p_push = push_gaussian(
        mu_p, S_p, Phit, eps=eps, return_inv=True,
        Sigma_inv=getattr(agent_i, "sigma_p_inv", None),
        assume_orthogonal=False
    )

    # (optional) energy accounting
    accumulate_self_feedback_energies(
        ctx, agent_i,
        mu_q=mu_q, S_q=S_q,
        mu_p=mu_p, S_p=S_p,
        mu_q_push=mu_q_push, S_q_push=S_q_push,
        mu_p_push=mu_p_push, S_p_push=S_p_push,
    )

    # 3) self + feedback grads
    g_self_mu, g_self_S, g_fb_mu, g_fb_S = _self_and_feedback_grads(
        mode,
        mu_q, S_q, mu_p, S_p,
        mu_q_push, S_q_push, inv_q_push,
        mu_p_push, S_p_push, inv_p_push,
        Phi, Phit, eps,
        sigma_q_inv=getattr(agent_i, "sigma_q_inv", None),
        sigma_p_inv=getattr(agent_i, "sigma_p_inv", None),
        mask=getattr(agent_i, "mask", None),
    )

    # 4) β·ALIGN and γ
    dmu_align, dS_align = _accum_alignment_block_mu_sigma(
        ctx, agent_i, agents,
        which=which, mu_key=mu_key, S_key=S_key,
        eps=eps, tau=tau, accum_send=accum_send_cfg,
    )
    dmu_gamma, dS_gamma = _accum_gamma_block_mu_sigma(
        ctx, agent_i, agents,
        which=which, mu_key=mu_key, S_key=S_key,
        eps=eps, tau=tau, accum_send=accum_send_cfg,
        Phi=Phi, Phit=Phit,
        use_gamma_A=None, use_gamma_B=None,
    )

    # 5) combine → natural projection → accumulate
    delta_mu, delta_S = _run_mu_sigma_pipeline(
        ctx=ctx, agent_i=agent_i, which=which,
        dmu_self=alpha * g_self_mu,    dS_self=alpha * g_self_S,
        dmu_feedback=lambd * g_fb_mu,  dS_feedback=lambd * g_fb_S,
        dmu_align=dmu_align,           dS_align=dS_align,
        dmu_gamma=dmu_gamma,           dS_gamma=dS_gamma,
        natural_project=True,
    )

    _accumulate_into_agent(agent_i, gmu_key, gS_key, delta_mu, delta_S)
    return delta_mu, delta_S






def _accum_alignment_block_mu_sigma(
    ctx,
    agent_i,
    agents,
    *,
    which: str,             # 'q' or 'p'
    mu_key: str,
    S_key: str,
    eps: float,
    tau: float,
    accum_send: bool,
):
    """
    β-align only. Computes pairwise ALIGN β-weighted μ/Σ gradients for receiver i
    (and enqueues sender j) using the exact softmax product rule with KL1 := ALIGN KL.
    """
    from beta import beta_align_maps

    # Precompute receiver stats once
    mu_i_arr = np.asarray(getattr(agent_i, mu_key), np.float32, order="C")
    S_i_arr  = sanitize_sigma(np.asarray(getattr(agent_i, S_key), np.float64), eps=eps)\
                  .astype(np.float32, copy=False)

    dmu_align = np.zeros_like(mu_i_arr, dtype=np.float32)
    dS_align  = np.zeros_like(S_i_arr,  dtype=np.float32)

    Sshape = tuple(mu_i_arr.shape[:-1])
    Ki = int(mu_i_arr.shape[-1])
    gbar_mu_i = np.zeros(Sshape + (Ki,),    np.float32)
    gbar_S_i  = np.zeros(Sshape + (Ki, Ki), np.float32)

    pairs = []

    for agent_j, overlap in _iter_overlap_pairs(agent_i, agents, tau=tau, which=which, mu_key=mu_key, ctx = ctx):
        if not np.any(overlap):
            continue

        
        KL1_map, beta_map = beta_align_maps(ctx, agent_i, agent_j, which=which)

        
        m        = overlap.astype(np.float32, copy=False)
        beta_ij  = beta_map * m
        KL1      = KL1_map  * m
        if not np.any(beta_ij > 0):
            continue

        Om_align = Omega(ctx, agent_i, agent_j, which=which)

        mu_j_arr = np.asarray(getattr(agent_j, mu_key), np.float32, order="C")
        S_j_arr  = sanitize_sigma(np.asarray(getattr(agent_j, S_key), np.float64), eps=eps)\
                      .astype(np.float32, copy=False)

        mu_j_t, S_j_t, inv_j_t = push_gaussian(
            mu_j_arr, S_j_arr, Om_align, eps=eps, return_inv=True, sanitize_input=False
        )
     
        gmu_align, gS_align = grad_alignment_energy_source(
            mu_i_arr, S_i_arr, mu_j_t, inv_j_t, eps=eps, sigma_i_inv=None, assume_sanitized=True
        )
        
       
        gmu_align_j, gS_align_j = grad_alignment_energy_target(
            mu_i=mu_i_arr, sigma_i=S_i_arr,
            mu_j_t=mu_j_t, sigma_j_t_inv=inv_j_t,
            Omega_ij=Om_align, eps=eps, assume_sanitized=True
        )
        
        # shape guards
        assert beta_ij.shape == KL1.shape
        assert gmu_align.shape[:-1] == KL1.shape
        assert gS_align.shape[:-2] == KL1.shape

        # β-averages for softmax rule
        gbar_mu_i += beta_ij[..., None]       * gmu_align
        gbar_S_i  += beta_ij[..., None, None] * gS_align

        pairs.append(dict(
            j=agent_j, overlap=overlap,
            beta_ij=beta_ij, KL1=KL1,
            gmu_align=gmu_align, gS_align=gS_align,
            gmu_align_j=gmu_align_j, gS_align_j=gS_align_j,
        ))

    # second pass: exact softmax product rule
    for P in pairs:
        agent_j     = P["j"]
        overlap     = P["overlap"]
        beta_ij     = P["beta_ij"]
        KL1         = P["KL1"]
        gmu_align   = P["gmu_align"]
        gS_align    = P["gS_align"]
        gmu_align_j = P["gmu_align_j"]
        gS_align_j  = P["gS_align_j"]

       
        kappa  = max(float(cfg_get(ctx, f"beta_kappa_{which}", 1.0)), 1e-12)

        add_mu_i = softmax_align_rule_receiver(beta_ij, KL1, kappa, gmu_align, gbar_mu_i)
        add_S_i  = softmax_align_rule_receiver(beta_ij, KL1, kappa, gS_align,  gbar_S_i)
        add_mu_j = softmax_align_rule_sender  (beta_ij, KL1, kappa, gmu_align_j)
        add_S_j  = softmax_align_rule_sender  (beta_ij, KL1, kappa, gS_align_j)

        dmu_align[overlap] += add_mu_i[overlap]
        dS_align [overlap] += add_S_i [overlap]
        
        if accum_send:
            _add_to_inbox(agent_j, which, add_mu_j, add_S_j, overlap)
            
    # final guards
    assert np.all(np.isfinite(dmu_align)) and np.all(np.isfinite(dS_align)), "β-align NaN/Inf"
    return dmu_align, dS_align





def _accum_gamma_block_mu_sigma(
    ctx,
    agent_i,
    agents,
    *,
    which: str,             # 'q' or 'p'
    mu_key: str,
    S_key: str,
    eps: float,
    tau: float,
    accum_send: bool,
    Phi=None,
    Phit=None,
    use_gamma_A: bool | None = None,
    use_gamma_B: bool | None = None,
):
    """
    γ-only block. Uses gamma_maps + centralized product rule:
      ∂(γ KL) = γ (1 - KL/κ_γ) ∂KL   (no softmax here)
    """
    

    if use_gamma_A is None:
        use_gamma_A = bool(cfg_get(ctx, f"use_gamma_A_{which}", True))
    if use_gamma_B is None:
        use_gamma_B = bool(cfg_get(ctx, f"use_gamma_B_{which}", True))

    mu_i_arr0 = np.asarray(getattr(agent_i, mu_key), np.float32, order="C")
    S_i_arr0  = np.asarray(getattr(agent_i, S_key),  np.float32, order="C")
    dmu_G = np.zeros_like(mu_i_arr0, dtype=np.float32)
    dS_G  = np.zeros_like(S_i_arr0,  dtype=np.float32)

    kap = max(float(cfg_get(ctx, f"kappa_gamma_{which}", 1.0)), 1e-12)

    for agent_j, overlap in _iter_overlap_pairs(agent_i, agents, tau=tau, which=which, mu_key=mu_key, ctx=ctx):
        if not np.any(overlap):
            continue

        # raw ∂KL for A/B (masked)
        g_mu_i_raw, g_S_i_raw, g_mu_j_raw, g_S_j_raw, _ = _accum_gamma_mu_sigma_for_pair(
            ctx,
            agent_i, agent_j,
            mu_key=mu_key, S_key=S_key,
            overlap_mask=overlap, eps=eps,
            Phi_i=Phi, Phi_tilde_i=Phit,
            Omega_q_ij=Omega(ctx, agent_i, agent_j, which="q"),
        )

        gam = gamma_maps(ctx, agent_i, agent_j)   # {"A": (KL_A, γ_A), "B": (KL_B, γ_B)}
        if not gam:
            continue

        for case in ("A", "B"):
            if (case == "A" and not use_gamma_A) or (case == "B" and not use_gamma_B):
                continue
            if case not in gam:
                continue
            KLc, Gc = gam[case]     # (*S,), (*S,)

            m = overlap.astype(np.float32, copy=False)
            w = (np.asarray(Gc, np.float32) * m).astype(np.float32)
            K = (np.asarray(KLc, np.float32) * m).astype(np.float32)

            add_mu_i = plain_rule(w, K, kap, g_mu_i_raw)
            add_S_i  = plain_rule(w, K, kap, g_S_i_raw)
            dmu_G[overlap] += add_mu_i[overlap]
            dS_G [overlap] += add_S_i [overlap]
           

            if accum_send:
                add_mu_j = plain_rule(w, K, kap, g_mu_j_raw)
                add_S_j  = plain_rule(w, K, kap, g_S_j_raw)
                _add_to_inbox(agent_j, which, add_mu_j, add_S_j, overlap)
                
    # If you prefer to drain here too (optional):
    if accum_send:
        dmu_G, dS_G = _drain_inbox_into_dalign(agent_i, which, dmu_G, dS_G)

    assert np.all(np.isfinite(dmu_G)) and np.all(np.isfinite(dS_G)), "γ NaN/Inf"
    return dmu_G, dS_G




def _accum_gamma_mu_sigma_for_pair(
    ctx,
    agent_i, agent_j,
    *,
    mu_key: str,
    S_key: str,
    overlap_mask: np.ndarray,
    eps: float,
    Phi_i,            # Φ_i (Q→P)
    Phi_tilde_i,      # Φ̃_i (P→Q) (kept for signature symmetry)
    Omega_q_ij,       # Ω^q_ij (reused; no recompute)
):
    """
    Return *raw* ∂KL tensors (masked to overlap) for γ Cases A/B, summed:
      (g_mu_i_raw, g_S_i_raw, g_mu_j_raw, g_S_j_raw, {"A": KL_A, "B": KL_B})
    Weighting by γ and (1 - KL/κ) is applied by the caller.
    """
    import numpy as np

    i_id = int(getattr(agent_i, "id", -1))
    j_id = int(getattr(agent_j, "id", -1))

    Sshape = tuple(overlap_mask.shape)
    Ki = int(getattr(agent_i, mu_key).shape[-1])
    Kj = int(getattr(agent_j, mu_key).shape[-1])

    g_mu_i = np.zeros(Sshape + (Ki,),    np.float32)
    g_S_i  = np.zeros(Sshape + (Ki, Ki), np.float32)
    g_mu_j = np.zeros(Sshape + (Kj,),    np.float32)
    g_S_j  = np.zeros(Sshape + (Kj, Kj), np.float32)

    if not np.any(overlap_mask):
        return g_mu_i, g_S_i, g_mu_j, g_S_j, {}

    m = overlap_mask.astype(np.float32, copy=False)

    # --- Use EdgeMaps: always returns arrays (zeros if missing) ---
    # Keys are (case, i_id, j_id) with i <- j
    gA_map, KL_A = ctx.edge.get_gamma(ctx, "A", i_id, j_id, shape=Sshape)
    gB_map, KL_B = ctx.edge.get_gamma(ctx, "B", i_id, j_id, shape=Sshape)
    
    # Case A raw grads
    if np.any(gA_map) or np.any(KL_A):
        outA = grad_gamma_mu_sigma_dispatch(
            ctx, agent_i, agent_j,
            basis="a",
            Omega_ij=Omega_q_ij,
            Phi_i=Phi_i,
            eps=eps,
        )
        g_mu_i += m[..., None]       * np.asarray(outA["mu_rec"],  np.float32)
        g_S_i  += m[..., None, None] * np.asarray(outA["S_rec"],   np.float32)
        g_mu_j += m[..., None]       * np.asarray(outA["mu_send"], np.float32)
        g_S_j  += m[..., None, None] * np.asarray(outA["S_send"],  np.float32)

    # Case B raw grads
    if np.any(gB_map) or np.any(KL_B):
        outB = grad_gamma_mu_sigma_dispatch(
            ctx, agent_i, agent_j,
            basis="b",
            Omega_ij=Omega_q_ij,
            Phi_i=Phi_i,
            eps=eps,
        )
        g_mu_i += m[..., None]       * np.asarray(outB["mu_rec"],  np.float32)
        g_S_i  += m[..., None, None] * np.asarray(outB["S_rec"],   np.float32)
        g_mu_j += m[..., None]       * np.asarray(outB["mu_send"], np.float32)
        g_S_j  += m[..., None, None] * np.asarray(outB["S_send"],  np.float32)

    KLs = {}
    if np.any(KL_A): KLs["A"] = KL_A.astype(np.float32, copy=False)
    if np.any(KL_B): KLs["B"] = KL_B.astype(np.float32, copy=False)

    return g_mu_i, g_S_i, g_mu_j, g_S_j, KLs




# --- Self / Feedback energy accumulation (shared with diagnostics) ---


def accumulate_self_feedback_energies(
    ctx,
    agent_i,
    *,
    mu_q, S_q,
    mu_p, S_p,
    mu_q_push, S_q_push,
    mu_p_push, S_p_push,
):
    """
    Accumulate UNWEIGHTED pixel-summed KLs into the per-step accumulator:
      self_sum     += sum_px KL(q || p')
      feedback_sum += sum_px KL(p || q')

    Keep α, λ application outside (e.g., in compute_global_metrics/total_energy),
    just like alignment stores unweighted KL. Returns (self_raw, feedback_raw).
    """
    

    eps = float(cfg_get(ctx, "eps", 1e-8))
    tau = float(cfg_get(ctx, "support_tau", 1e-6))

    # common support mask
    m = np.asarray(getattr(agent_i, "mask", 1.0), np.float32)
    mm = (m > tau) if (m.dtype != bool) else m
    if not np.any(mm):
        return 0.0, 0.0

    # slice active pixels
    μq  = np.asarray(mu_q[mm],      np.float64, order="C")
    Σq  = sanitize_sigma(np.asarray(S_q[mm],    np.float64, order="C"), eps=eps)
    μp  = np.asarray(mu_p[mm],      np.float64, order="C")
    Σp  = sanitize_sigma(np.asarray(S_p[mm],    np.float64, order="C"), eps=eps)
    μqʹ = np.asarray(mu_q_push[mm], np.float64, order="C")
    Σqʹ = sanitize_sigma(np.asarray(S_q_push[mm], np.float64, order="C"), eps=eps)
    μpʹ = np.asarray(mu_p_push[mm], np.float64, order="C")
    Σpʹ = sanitize_sigma(np.asarray(S_p_push[mm], np.float64, order="C"), eps=eps)

    # pixelwise KLs (unweighted)
    self_px     = kl_gaussian(μq, Σq, μpʹ, Σpʹ, eps=eps)   # KL(q || p')
    feedback_px = kl_gaussian(μp, Σp, μqʹ, Σqʹ, eps=eps)   # KL(p || q')

    self_raw = float(np.sum(self_px))
    fb_raw   = float(np.sum(feedback_px))

    # Accumulate UNWEIGHTED totals (match alignment convention)
    energy_acc_add(ctx, "self_sum",     self_raw)
    energy_acc_add(ctx, "feedback_sum", fb_raw)

    # Optional per-agent buckets (mirrors your alignment helper)
    aid = getattr(agent_i, "id", None)
    if aid is not None:
        energy_acc_add(ctx, f"self_sum[{aid}]",     self_raw)
        energy_acc_add(ctx, f"feedback_sum[{aid}]", fb_raw)

    return self_raw, fb_raw





def _self_and_feedback_grads(
    mode: str,
    mu_q, sigma_q, mu_p, sigma_p,
    mu_q_push, Sigma_q_push, inv_q_push,
    mu_p_push, Sigma_p_push, inv_p_push,
    Phi_mat, Phi_tilde_mat, eps: float,
    *, sigma_q_inv=None, sigma_p_inv=None, mask=None
):
    if mode == "belief":
        g_self_mu, g_self_S = grad_self_energy_belief(
            mu_q, sigma_q, mu_p_push, inv_p_push,
            sigma_q_inv=sigma_q_inv, mask=mask
        )
        g_fb_mu, g_fb_S = grad_feedback_energy_belief(
            mu_q, sigma_q, mu_p, mu_q_push,
            Sigma_q_push, inv_q_push, sigma_p, Phi_mat
        )
    elif mode == "model":
        g_self_mu, g_self_S = grad_self_energy_model(
            mu_q, sigma_q, mu_p_push, inv_p_push, Phi_tilde_mat, mask=mask
        )
        g_fb_mu, g_fb_S = grad_feedback_energy_model(
            mu_p, sigma_p, mu_q_push, Sigma_q_push, inv_q_push,
            sigma_p_inv=sigma_p_inv
        )
    else:
        raise ValueError(f"Unsupported mode: {mode}")
    return g_self_mu, g_self_S, g_fb_mu, g_fb_S




#==============================================================================
#
#                    FEEDBACK / SELF TERMS (unchanged math, safer numerics)
#==============================================================================

def grad_alignment_energy_source(
    mu_i, sigma_i, mu_j_t, sigma_j_t_inv, eps=1e-8,
    *, sigma_i_inv=None, assume_sanitized=True
):
    """
    Faster: reuse precomputed sigma_i_inv if provided; optionally skip sanitize.
    """
    mu_i       = np.asarray(mu_i,       dtype=np.float32, order="C")
    mu_j_t     = np.asarray(mu_j_t,     dtype=np.float32, order="C")
    sigma_j_t_inv = np.asarray(sigma_j_t_inv, dtype=np.float32, order="C")

    dmu = mu_i - mu_j_t
    # grad_mu_i = S'^-1 (μ_i - μ_j')
    grad_mu = np.einsum("...ij,...j->...i", sigma_j_t_inv, dmu, optimize=True)

    if sigma_i_inv is None:
        Si = np.asarray(sigma_i, dtype=np.float32, order="C")
        if not assume_sanitized:
            Si = sanitize_sigma(Si, eps=eps)
        sigma_i_inv = safe_inv(Si)   # batched cholesky-inv

    grad_sigma = 0.5 * (sigma_j_t_inv - sigma_i_inv)
    # symmetrize
    grad_sigma = 0.5 * (grad_sigma + np.swapaxes(grad_sigma, -1, -2))

    return grad_mu.astype(np.float32, copy=False), grad_sigma.astype(np.float32, copy=False)


def grad_alignment_energy_target(
    mu_i, sigma_i, mu_j_t, sigma_j_t_inv, Omega_ij, eps: float = 1e-8,
    *, assume_sanitized=True
):
    """
    Faster: use v = S'^-1 dμ  ->  v vᵀ for the middle term; skip repeated sanitize.
    """
    mu_i       = np.asarray(mu_i,       dtype=np.float32, order="C")
    mu_j_t     = np.asarray(mu_j_t,     dtype=np.float32, order="C")
    Omega_ij   = np.asarray(Omega_ij,   dtype=np.float32, order="C")
    sigma_jinv = np.asarray(sigma_j_t_inv, dtype=np.float32, order="C")

    dmu = mu_i - mu_j_t

    # ∂_{μ_j'} KL = - S'^-1 dμ  ;  map back with Ωᵀ
    gmu_jp    = -np.einsum("...ij,...j->...i", sigma_jinv, dmu, optimize=True)
    grad_mu_j = np.einsum("...ji,...j->...i", Omega_ij, gmu_jp, optimize=True)

    # Σ_i only appears (not inverted); assume sanitized upstream
    Si = np.asarray(sigma_i, dtype=np.float32, order="C")
    if not assume_sanitized:
        Si = sanitize_sigma(Si)

    # v = S'^-1 dμ  ->  v vᵀ
    v   = np.einsum("...ij,...j->...i", sigma_jinv, dmu, optimize=True)
    vvT = np.einsum("...i,...j->...ij", v, v, optimize=True)

    # gΣ' = 1/2( -S'^-1 Σ_i S'^-1 - vvᵀ + S'^-1 )
    t0 = -np.einsum("...ij,...jk,...kl->...il", sigma_jinv, Si, sigma_jinv, optimize=True)
    gSp = 0.5 * (t0 - vvT + sigma_jinv)

    # map back: Ωᵀ gΣ' Ω, then symmetrize
    grad_sigma_j = np.einsum("...ji,...jk,...kl->...il",
                             Omega_ij, gSp, np.swapaxes(Omega_ij, -1, -2), optimize=True)
    grad_sigma_j = 0.5 * (grad_sigma_j + np.swapaxes(grad_sigma_j, -1, -2))

    return grad_mu_j.astype(np.float32, copy=False), grad_sigma_j.astype(np.float32, copy=False)



def grad_feedback_energy_belief(
    mu_q, sigma_q, mu_p, mu_q_push,
    sigma_q_push, sigma_q_push_inv, sigma_p, Phi, eps=1e-8, *,
    assume_sanitized=True,
):
    """
    ∂ wrt (μ_q, Σ_q) of KL(p || Φ·q), evaluated in q-fiber.
    Uses v = S'^-1 Δ and v v^T instead of S'^-1 ΔΔ^T S'^-1 to cut temps.
    """
    # Δ = μ_p - μ_q'
    delta = (mu_p - mu_q_push).astype(np.float32, copy=False)

    # v = S'^-1 Δ  (matvec)
    v = np.matmul(sigma_q_push_inv, delta[..., None])[..., 0]  # (...,K)

    # grad_μ = - Φ^T v
    Phi_T = np.swapaxes(Phi, -1, -2)
    grad_mu = -np.matmul(Phi_T, v[..., None])[..., 0]

    # M = S'^-1  - v v^T  - S'^-1 Σ_p S'^-1
    term1 = sigma_q_push_inv
    term2 = np.matmul(v[..., :, None], v[..., None, :])        # v v^T
    term3 = np.matmul(np.matmul(sigma_q_push_inv, sigma_p), sigma_q_push_inv)

    M = term1 - term2 - term3

    # grad_Σ = 1/2 Φ^T M Φ (symmetrized)
    grad_sigma = 0.5 * np.matmul(np.matmul(Phi_T, M), Phi)
    grad_sigma = 0.5 * (grad_sigma + np.swapaxes(grad_sigma, -1, -2))

    return grad_mu.astype(np.float32, copy=False), grad_sigma.astype(np.float32, copy=False)


def grad_feedback_energy_model(
    mu_p, sigma_p, mu_q_push,
    sigma_q_push, sigma_q_push_inv, Phi=None, eps=1e-8, *,
    sigma_p_inv=None, assume_sanitized=True,
):
    """
    ∂ wrt (μ_p, Σ_p) of KL(p || q'), evaluated in p-fiber.
    Avoids inverting Σ_p if sigma_p_inv is provided.
    """
    delta = (mu_p - mu_q_push).astype(np.float32, copy=False)

    # grad_μ = S'^-1 Δ
    grad_mu = np.matmul(sigma_q_push_inv, delta[..., None])[..., 0]

    # grad_Σ = 1/2 (S'^-1 - Σ_p^{-1})
    if sigma_p_inv is None:
        # assume Σ_p already sanitized upstream; we only invert if caller didn’t pass inv
        sigma_p_inv = safe_inv(sigma_p.astype(np.float32, copy=False))
    grad_sigma = 0.5 * (sigma_q_push_inv - sigma_p_inv)
    grad_sigma = 0.5 * (grad_sigma + np.swapaxes(grad_sigma, -1, -2))

    return grad_mu.astype(np.float32, copy=False), grad_sigma.astype(np.float32, copy=False)


def grad_self_energy_belief(
    mu_q, sigma_q, mu_p_push, sigma_p_push_inv, eps=1e-8, *,
    sigma_q_inv=None, mask=None, assume_sanitized=True,
):
    """
    ∂ wrt (μ_q, Σ_q) of KL(q || p'), evaluated in q-fiber.
    Reuses sigma_q_inv if provided.
    """
    delta = (mu_q - mu_p_push).astype(np.float32, copy=False)

    # grad_μ = S_p'^-1 Δ
    grad_mu = np.matmul(sigma_p_push_inv, delta[..., None])[..., 0]

    # grad_Σ = 1/2 (S_p'^-1 - Σ_q^{-1})
    if sigma_q_inv is None:
        sigma_q_inv = safe_inv(sigma_q.astype(np.float32, copy=False))
    
    grad_sigma = 0.5 * (sigma_p_push_inv - sigma_q_inv)
    grad_sigma = 0.5 * (grad_sigma + np.swapaxes(grad_sigma, -1, -2))

    if mask is not None:
        m = (np.asarray(mask) > float(getattr(config, "support_tau", 0.0)))
        grad_mu    = grad_mu * m[..., None]
        grad_sigma = grad_sigma * m[..., None, None]

    return grad_mu.astype(np.float32, copy=False), grad_sigma.astype(np.float32, copy=False)


def grad_self_energy_model(
    mu_q, sigma_q, mu_p_push, sigma_p_push_inv, Phi_tilde, eps=1e-8, *,
    assume_sanitized=True, mask=None,
):
    """
    ∂ wrt (μ_p, Σ_p) of KL(q || p'), evaluated in p-fiber.
    Uses v = M Δ and v v^T to avoid an extra large einsum.
    """
    delta = (mu_q - mu_p_push).astype(np.float32, copy=False)

    # tmp = M Δ
    v = np.matmul(sigma_p_push_inv, delta[..., None])[..., 0]

    # grad_μ = - Φ̃^T v
    Phi_tilde_T = np.swapaxes(Phi_tilde, -1, -2)
    grad_mu = -np.matmul(Phi_tilde_T, v[..., None])[..., 0]

    # G = M - v v^T - M Σ_q M
    vvT = np.matmul(v[..., :, None], v[..., None, :])
    M_Sq = np.matmul(sigma_p_push_inv, sigma_q.astype(np.float32, copy=False))
    G = sigma_p_push_inv - vvT - np.matmul(M_Sq, sigma_p_push_inv)

    # grad_Σ = 1/2 Φ̃^T G Φ̃  (symmetrized)
    grad_sigma = 0.5 * np.matmul(np.matmul(Phi_tilde_T, G), Phi_tilde)
    grad_sigma = 0.5 * (grad_sigma + np.swapaxes(grad_sigma, -1, -2))

    if mask is not None:
        m = (np.asarray(mask) > float(getattr(config, "support_tau", 0.0)))
        grad_mu    = grad_mu * m[..., None]
        grad_sigma = grad_sigma * m[..., None, None]

    return grad_mu.astype(np.float32, copy=False), grad_sigma.astype(np.float32, copy=False)
















def grad_gamma_A_mu_sigma_i(ctx, agent_i, agent_j, *, Omega_ij=None, eps: float = 1e-8,
                           use_identity: bool = False):
    """
    ∂ KL_gamma / ∂(μ_{p_i}, Σ_{p_i}) for Case A using the dual form:
        KL_gamma = KL( q_j || Ω^q_{ji}[ Φ̃_i p_i ] )  in Q_j frame.

    If use_identity == True: use the simple (stable) limit KL(q_j || p_i).
    """
    import numpy as np
    from core.numerical_utils import sanitize_sigma, safe_inv
    from core.transport_cache import Omega, Phi

    # Receiver stats (work in float64 for stability)
    mu_p = np.asarray(agent_i.mu_p_field,  np.float64, order="C")
    S_p  = sanitize_sigma(np.asarray(agent_i.sigma_p_field, np.float64), eps=eps)

    if use_identity:
        # KL(q_j || p_i), gradients w.r.t. p_i
        mu_j = np.asarray(agent_j.mu_q_field,    np.float64, order="C")
        S_j  = sanitize_sigma(np.asarray(agent_j.sigma_q_field, np.float64), eps=eps)
        # ∂/∂μ_Q KL(P||Q) = Σ_Q^{-1}(μ_Q-μ_P)
        S_p_inv = safe_inv(S_p, eps=max(eps, 1e-12))
        dmu = np.einsum("...ij,...j->...i", S_p_inv, (mu_p - mu_j), optimize=True)
        # ∂/∂Σ_Q KL(P||Q) = 1/2(-Σ_Q^{-1} Σ_P Σ_Q^{-1} - Σ_Q^{-1}(μ_Q-μ_P)(μ_Q-μ_P)^T Σ_Q^{-1} + Σ_Q^{-1})
        d = mu_p - mu_j
        v = np.einsum("...ij,...j->...i", S_p_inv, d, optimize=True)
        vvT = np.einsum("...i,...j->...ij", v, v, optimize=True)
        term = np.einsum("...ij,...jk->...ik", S_p_inv, np.einsum("...jk,...kl->...jl", S_j, S_p_inv, optimize=True), optimize=True)
        gS  = 0.5 * (-term - vvT + S_p_inv)
        gS  = 0.5 * (gS + np.swapaxes(gS, -1, -2))
        return dmu.astype(np.float32, copy=False), gS.astype(np.float32, copy=False)

    # --- Dual path: KL(q_j || Ω_ji[ Φ̃_i p_i ]) ---
    Phit_i = np.asarray(Phi(ctx, agent_i, kind="p_to_q"), np.float64)         # Φ̃_i : P_i→Q_i
    Om_ji  = np.asarray(Omega(ctx, agent_j, agent_i, which="q"), np.float64)  # Ω_ji^q : Q_i→Q_j

    # q̂_i = Φ̃_i p_i  (in Q_i)
    mu_qhat = np.einsum("...ij,...j->...i", Phit_i, mu_p, optimize=True)
    S_qhat  = np.einsum("...ij,...jk,...lk->...il", Phit_i, S_p, Phit_i, optimize=True)

    # Landing stats in Q_j via Ω_ji
    mu_L = np.einsum("...ij,...j->...i", Om_ji, mu_qhat, optimize=True)
    S_L  = np.einsum("...ij,...jk,...lk->...il", Om_ji, S_qhat, Om_ji, optimize=True)
    S_L  = sanitize_sigma(S_L, eps=eps)
    S_L_inv = safe_inv(S_L, eps=max(eps, 1e-12))

    # Sender (fixed) stats
    mu_j = np.asarray(agent_j.mu_q_field,    np.float64, order="C")
    S_j  = sanitize_sigma(np.asarray(agent_j.sigma_q_field, np.float64), eps=eps)

    # KL(q_j || N(mu_L,S_L)) partials wrt (mu_L, S_L)
    # g_muL = Σ_L^{-1}(μ_L - μ_j)
    dL   = mu_L - mu_j
    g_muL = np.einsum("...ij,...j->...i", S_L_inv, dL, optimize=True)

    # g_SL = 1/2(-Σ_L^{-1} Σ_j Σ_L^{-1} - Σ_L^{-1} dL dL^T Σ_L^{-1} + Σ_L^{-1})
    v    = np.einsum("...ij,...j->...i", S_L_inv, dL, optimize=True)
    vvT  = np.einsum("...i,...j->...ij", v, v, optimize=True)
    term = np.einsum("...ij,...jk->...ik", S_L_inv,
                     np.einsum("...jk,...kl->...jl", S_j, S_L_inv, optimize=True),
                     optimize=True)
    g_SL = 0.5 * (-term - vvT + S_L_inv)
    g_SL = 0.5 * (g_SL + np.swapaxes(g_SL, -1, -2))

    # Backprop through Ω_ji: μ_L = Ω_ji μ_qhat, Σ_L = Ω_ji Σ_qhat Ω_ji^T
    g_mu_qhat = np.einsum("...ji,...j->...i", Om_ji, g_muL, optimize=True)                         # Ω_ji^T g_muL
    g_S_qhat  = np.einsum("...ji,...jk,...kl->...il", Om_ji, g_SL, Om_ji, optimize=True)           # Ω_ji^T g_SL Ω_ji

    # Backprop through Φ̃_i: μ_qhat = Φ̃_i μ_p, Σ_qhat = Φ̃_i Σ_p Φ̃_i^T
    dmu_p = np.einsum("...ji,...j->...i", Phit_i, g_mu_qhat, optimize=True)                        # Φ̃_i^T g_mu_qhat
    dS_p  = np.einsum("...ji,...jk,...kl->...il", Phit_i, g_S_qhat, Phit_i, optimize=True)         # Φ̃_i^T g_S_qhat Φ̃_i
    dS_p  = 0.5 * (dS_p + np.swapaxes(dS_p, -1, -2))

    return dmu_p.astype(np.float32, copy=False), dS_p.astype(np.float32, copy=False)



# ---------------- A: KL( Φ_i[Ω q_j]  ||  p_i )  — target in P_i


    
def grad_gamma_A_mu_sigma_j(
    mu_j, Sigma_j,                  # (...,K), (...,K,K)  sender q_j
    mu_p_i, Sigma_p_i,              # (...,K), (...,K,K)  receiver p_i
    Omega_ij, Phi_i,                # (...,K,K), (...,K,K)
    *,
    R=None,                         # ignored in dual path
    mu_L=None,                      # ignored in dual path
    Sigma_L=None,                   # ignored in dual path
    Sigma_L_inv=None,               # ignored in dual path
    Sigma_p_inv=None,               # optional (used for identity fallback only)
    mask=None,
    eps: float = 1e-8,
    assume_sanitized: bool = True,
    use_identity: bool = False,     # ΦΩ → Id : KL(q_j || p_i)
):
    """
    Sender-side ∂KL/∂(μ_j, Σ_j) for Case A using the dual:
        KL_A = KL( q_j || Ω^q_{ji}[ Φ̃_i p_i ] ).

    If use_identity == True, use KL(q_j || p_i).
    """
    

    # ---- as float64 for stability ----
    mu_j  = np.asarray(mu_j,      np.float64, order="C")
    Sj    = np.asarray(Sigma_j,   np.float64, order="C")
    mu_pi = np.asarray(mu_p_i,    np.float64, order="C")
    Sp    = np.asarray(Sigma_p_i, np.float64, order="C")
    Phi_i = np.asarray(Phi_i,     np.float64, order="C")
    Om_ij = np.asarray(Omega_ij,  np.float64, order="C")

    # sanitize covariances
    Sj = sanitize_sigma(Sj, eps=eps) if not assume_sanitized else Sj
    Sp = sanitize_sigma(Sp, eps=eps) if not assume_sanitized else Sp

    if use_identity:
        # KL(q_j || p_i)
        Sp_inv = Sigma_p_inv if Sigma_p_inv is not None else safe_inv(Sp, eps=max(eps, 1e-12))
        Sp_inv = np.asarray(Sp_inv, np.float64, order="C")
        dmu = np.einsum("...ij,...j->...i", Sp_inv, (mu_j - mu_pi), optimize=True)
        Sj_inv = safe_inv(Sj, eps=max(eps, 1e-12))
        dS  = 0.5 * (Sp_inv - Sj_inv)
        dS  = 0.5 * (dS + np.swapaxes(dS, -1, -2))
        if mask is not None:
            m = (np.asarray(mask) > 0).astype(np.float64, copy=False)
            dmu = dmu * m[..., None]
            dS  = dS  * m[..., None, None]
        return dmu.astype(np.float32, copy=False), dS.astype(np.float32, copy=False)

    # ---- dual path: build q̂_j = Ω_ji[ Φ̃_i p_i ] in Q_j ----
    Phit_i = np.asarray(Phi(None, None, kind="p_to_q") if Phi_i is None else Phi_i, np.float64)
    # If you have ctx/agents here, prefer cache: Phit_i = Phi(ctx, agent_i, kind="p_to_q")
    Om_ji  = np.asarray(Omega(None, None, which="q") if Om_ij is None else np.swapaxes(Om_ij, -1, -2), np.float64)
    # Prefer cache as well: Om_ji = Omega(ctx, agent_j, agent_i, which="q")

    # q̂_i = Φ̃_i p_i (in Q_i)
    mu_qhat_i = np.einsum("...ij,...j->...i", Phit_i, mu_pi, optimize=True)
    S_qhat_i  = np.einsum("...ij,...jk,...lk->...il", Phit_i, Sp, Phit_i, optimize=True)

    # push to Q_j via Ω_ji
    mu_hat = np.einsum("...ij,...j->...i", Om_ji, mu_qhat_i, optimize=True)
    S_hat  = np.einsum("...ij,...jk,...lk->...il", Om_ji, S_qhat_i, Om_ji, optimize=True)
    S_hat  = sanitize_sigma(S_hat, eps=eps)
    S_hat_inv = safe_inv(S_hat, eps=max(eps, 1e-12))

    # ---- KL(q_j || N(mu_hat, S_hat)) grads wrt (μ_j, Σ_j) ----
    dmu = np.einsum("...ij,...j->...i", S_hat_inv, (mu_j - mu_hat), optimize=True)
    Sj_inv = safe_inv(Sj, eps=max(eps, 1e-12))
    dS  = 0.5 * (S_hat_inv - Sj_inv)
    dS  = 0.5 * (dS + np.swapaxes(dS, -1, -2))

    # ---- optional mask ----
    if mask is not None:
        m = (np.asarray(mask) > 0).astype(np.float64, copy=False)
        dmu = dmu * m[..., None]
        dS  = dS  * m[..., None, None]

    return dmu.astype(np.float32, copy=False), dS.astype(np.float32, copy=False)










# ---------------- B: KL( p_i  ||  Φ_i[Ω q_j] )  — source in P_i
def grad_gamma_B_mu_sigma_i(ctx, agent_i, agent_j, *, Omega_ij=None, eps: float = 1e-8):
    r"""
    ∂ KL_gamma / ∂(μ_{p_i}, Σ_{p_i}) for **Case B**.

    Definition
    ----------
      KL_gamma := KL( p_i  ||  Φ_i[ Ω^q_{ij} q_j ] ), evaluated in P_i-frame.

    Let
      • (μ_p, Σ_p) := (μ_{p_i}, Σ_{p_i})
      • Ω^q_{ij}: Q_j→Q_i,  Φ_i: Q_i→P_i
      • (μ_L, Σ_L) = Φ_i( Ω^q_{ij}(μ_{q_j}, Σ_{q_j}) )    # landed target in P_i

    Gaussian KL:
      KL = KL( 𝒩(μ_p, Σ_p)  ||  𝒩(μ_L, Σ_L) ).

    Source-form gradients in P_i:
      ∂KL/∂μ_p =  Σ_L^{-1} (μ_p − μ_L)
      ∂KL/∂Σ_p =  ½( Σ_p^{-1} − Σ_L^{-1} )

    Returns
    -------
      gμ_p : (*S, Kp)
      gΣ_p : (*S, Kp, Kp)
    """
   
    # -- p_i stats (sanitize once)
    mu_p = np.asarray(agent_i.mu_p_field,  np.float32, order="C")
    S_p  = sanitize_sigma(np.asarray(agent_i.sigma_p_field, np.float64)).astype(np.float32, copy=False)

    # -- maps
    Om_q  = np.asarray(Omega_ij if Omega_ij is not None else Omega(ctx, agent_i, agent_j, which="q"), np.float32)
    Phi_i = np.asarray(Phi(ctx, agent_i, kind="q_to_p"), np.float32)   # Φ_i: Q→P

    # -- q_j → Q_i (fast precision-push if cached), then Q_i → P_i via Φ_i
    mu_qj_t, S_qj_t, _ = push_neighbor_stats(agent_j, "sigma_q_field", Om_q, eps=eps)
    mu_L, S_L          = push_gaussian(mu_qj_t, S_qj_t, Phi_i, eps=eps)  # landed target in P_i :contentReference[oaicite:2]{index=2}

    # -- source-form KL grads in P_i
    S_L_inv = safe_inv(S_L, eps=max(eps, 1e-12))                        # Σ_L^{-1}         :contentReference[oaicite:3]{index=3}
    S_p_inv = safe_inv(S_p,  eps=max(eps, 1e-12))                        # Σ_p^{-1}

    dmu   = (mu_p - mu_L)
    gmu_p = np.einsum("...ij,...j->...i", S_L_inv, dmu, optimize=True)   # Σ_L^{-1}(μ_p−μ_L)

    gS_p  = 0.5 * (S_p_inv - S_L_inv)
    gS_p  = 0.5 * (gS_p + np.swapaxes(gS_p, -1, -2))                     # symmetrize for safety

    return gmu_p.astype(np.float32, copy=False), gS_p.astype(np.float32, copy=False)




def grad_gamma_B_mu_sigma_j(
    mu_j, Sigma_j,                  # sender q_j stats (...,K), (...,K,K)
    mu_p_i, Sigma_p_i,              # receiver p_i stats (...,K), (...,K,K)  (KL's N0)
    Omega_ij, Phi_i,                # linear maps: Ω_ij (...,K,K), Φ_i (...,K,K)
    *,
    R=None,                         # optional precomputed R = Φ_i @ Ω_ij
    mu_1=None,                      # optional landing mean:  μ_1 = R μ_j
    Sigma_1=None,                   # optional landing cov:   Σ_1 = R Σ_j R^T
    Sigma_1_inv=None,               # optional Σ_1^{-1}
    Sigma_p_inv=None,               # optional Σ_p_i^{-1}
    mask=None,                      # optional boolean mask broadcastable to (...,)
    eps: float = 1e-8,
    assume_sanitized: bool = True,
):
    """
    Sender-side μ/Σ gradients for Case B gating:
        KL_B = KL( p_i || Φ_i[Ω_ij q_j] ).
    Returns (dμ_j, dΣ_j) in the *sender q_j* frame.

    Landing-frame partials for KL(N0||N1) with N0=(μ_p,Σ_p), N1=(μ_1,Σ_1):
        ∂KL/∂μ_1 = - Σ_1^{-1} (μ_p - μ_1)
        ∂KL/∂Σ_1 =  1/2 ( -Σ_1^{-1} + Σ_1^{-1} Σ_p Σ_1^{-1} )

    Chain rule:
        ∂KL/∂μ_j = R^T ∂KL/∂μ_1
        ∂KL/∂Σ_j = R^T (∂KL/∂Σ_1) R
    """
    # ---- cast to f32 for suite consistency ----
    mu_j      = np.asarray(mu_j,      np.float32, order="C")
    Sigma_j   = np.asarray(Sigma_j,   np.float32, order="C")
    mu_p_i    = np.asarray(mu_p_i,    np.float32, order="C")
    Sigma_p_i = np.asarray(Sigma_p_i, np.float32, order="C")
    Phi_i     = np.asarray(Phi_i,     np.float32, order="C")
    Omega_ij  = np.asarray(Omega_ij,  np.float32, order="C")

    # ---- R = Φ_i Ω_ij ----
    if R is None:
        R = np.einsum("...ik,...kj->...ij", Phi_i, Omega_ij, optimize=True)  # (...,K,K)
    Rt = np.swapaxes(R, -1, -2)

    # ---- landing stats (μ_1, Σ_1) ----
    if mu_1 is None:
        mu_1 = np.einsum("...ij,...j->...i", R, mu_j, optimize=True)         # (...,K)
    if Sigma_1 is None and Sigma_1_inv is None:
        Sigma_1 = np.einsum("...ik,...kl,...jl->...ij", R, Sigma_j, R, optimize=True)

    # ---- inverses with sanitation (once) ----
    if Sigma_p_inv is None:
        Sp = Sigma_p_i if assume_sanitized else sanitize_sigma(Sigma_p_i, eps=eps)
        Sigma_p_inv = safe_inv(Sp)                                           # (...,K,K)

    if Sigma_1_inv is None:
        S1 = Sigma_1 if assume_sanitized else sanitize_sigma(Sigma_1, eps=eps)
        Sigma_1_inv = safe_inv(S1)                                           # (...,K,K)

    # ---- landing-frame KL partials (N0 = p_i, N1 = landing) ----
    # ∂μ_1 = - Σ_1^{-1} (μ_p - μ_1)
    dmu_1 = -np.einsum("...ij,...j->...i", Sigma_1_inv, (mu_p_i - mu_1), optimize=True)

    # ∂Σ_1 = 1/2 ( -Σ_1^{-1} + Σ_1^{-1} Σ_p Σ_1^{-1} )
    dS_1  = -Sigma_1_inv
    dS_1 += np.einsum("...ij,...jk,...kl->...il", Sigma_1_inv, Sigma_p_i, Sigma_1_inv, optimize=True)
    dS_1 *= 0.5
    dS_1  = 0.5 * (dS_1 + np.swapaxes(dS_1, -1, -2))                          # symmetrize

    # ---- map back to sender frame ----
    dmu_j = np.einsum("...ij,...j->...i", Rt, dmu_1, optimize=True)           # (...,K)
    dS_j  = np.einsum("...ik,...kl,...jl->...ij", Rt, dS_1, R, optimize=True) # (...,K,K)
    dS_j  = 0.5 * (dS_j + np.swapaxes(dS_j, -1, -2))                          # symmetrize

    # ---- optional masking ----
    if mask is not None:
        m = (np.asarray(mask) > 0).astype(np.float32, copy=False)
        dmu_j = dmu_j * m[..., None]
        dS_j  = dS_j  * m[..., None, None]

    return dmu_j.astype(np.float32, copy=False), dS_j.astype(np.float32, copy=False)







def apply_natural_gradient_batch(
    ctx,
    mu_field,
    sigma_field,
    grad_mu_field,
    grad_sigma_field,
    mask=None,
    *,
    use_float64: bool = True,
    assume_sanitized: bool = True,
    grad_sigma_is_symmetric: bool = False,
    assert_finite: bool = False,
):
    """
    Vectorized natural gradient for Gaussian fields on an N-D periodic grid:
        δμ = -Σ ∇_μ L
        δΣ = -2 Σ sym(∇_Σ L) Σ

    Inputs:
      mu_field          : (*S, K)
      sigma_field       : (*S, K, K)   [SPD]
      grad_mu_field     : (*S, K)
      grad_sigma_field  : (*S, K, K)
      mask (optional)   : (*S,) bool or float weights

    Returns:
      delta_mu          : (*S, K)
      delta_sigma       : (*S, K, K)
    """
    import numpy as np
    from runtime_context import cfg_get

    # ---- config ----
    eps         = float(cfg_get(ctx, "eps", 1e-10))
    support_tau = float(cfg_get(ctx, "support_tau", 1e-6))
    dtype_work  = np.float64 if use_float64 else np.float32
    dtype_out   = np.float32 if not use_float64 else dtype_work

    # ---- infer spatial shape S, fiber dim K ----
    mu = np.asarray(mu_field)
    Sig = np.asarray(sigma_field)
    gmu = np.asarray(grad_mu_field)
    gSig = np.asarray(grad_sigma_field)

    if mu.ndim < 2 or Sig.ndim < 3:
        raise ValueError(f"Bad shapes: mu {mu.shape}, Sigma {Sig.shape}")

    S = mu.shape[:-1]               # *S
    K = mu.shape[-1]
    if Sig.shape[:-2] != S or Sig.shape[-2:] != (K, K):
        raise ValueError(f"sigma_field shape {Sig.shape} incompatible with mu_field {mu.shape}")

    # ---- flatten spatial for batched einsum ----
    N = int(np.prod(S, dtype=int))
    mu  = mu.astype(dtype_work, copy=False).reshape(N, K)
    Sig = Sig.astype(dtype_work, copy=False).reshape(N, K, K)
    gmu  = gmu.astype(dtype_work, copy=False).reshape(N, K)
    gSig = gSig.astype(dtype_work, copy=False).reshape(N, K, K)

    # ---- SPD sanitize Σ and symmetrize ∇Σ ----
    if not assume_sanitized:
        Sig = sanitize_sigma(Sig, eps=eps)  # must return symmetric SPD in dtype_work
    if not grad_sigma_is_symmetric:
        gSig = 0.5 * (gSig + np.swapaxes(gSig, -1, -2))

    # ---- natural steps ----
    # δμ = -Σ ∇_μ
    dmu = -np.einsum("nik,nk->ni", Sig, gmu, optimize=True)
    # δΣ = -2 Σ sym(∇_Σ) Σ
    tmp =  np.einsum("nij,njk->nik", Sig, gSig, optimize=True)
    dS  = -2.0 * np.einsum("nij,njk->nik", tmp, Sig, optimize=True)
    dS  = 0.5 * (dS + np.swapaxes(dS, -1, -2))  # symmetry guard

    # ---- mask / weights ----
    if mask is not None:
        m = np.asarray(mask)

        m_flat = m.reshape(N)
        if m.dtype == bool:
            active = m_flat
            wts = None
        else:
            wts = m_flat.astype(dtype_work, copy=False)
            active = wts > support_tau
            # soft weights
            dmu *= wts[:, None]
            dS  *= wts[:, None, None]

        # zero outside support
        if not np.all(active):
            ia = ~active
            dmu[ia] = 0.0
            dS[ia]  = 0.0


    if assert_finite:
        if not (np.isfinite(dmu).all() and np.isfinite(dS).all()):
            raise FloatingPointError("Nonfinite natural gradient (μ or Σ).")

    # ---- restore shapes / cast ----
    return (
        dmu.reshape(S + (K,)).astype(dtype_out, copy=False),
        dS.reshape(S + (K, K)).astype(dtype_out, copy=False),
    )







