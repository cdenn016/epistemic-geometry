# -*- coding: utf-8 -*-
"""
Created on Mon Sep  8 16:26:26 2025

@author: chris and christine
"""

import numpy as np
from core.numerical_utils import safe_inv, sanitize_sigma  
from core.omega import inverse_fisher_metric_field

# --- Unified dirty manager ----------------------------------------------------
class DirtyManager:
    """
    Single source of truth for 'dirty' state.

    Responsibilities:
      - Track dirty agents across categories: fields, kl, morphisms
      - Provide stable IDs (no object-id fallbacks)
      - Materialize a target agent subset by category
      - Clear agent-side flags only after successful processing
      - Bump ctx cache_version exactly when work happened
    """
    __slots__ = ("_fields", "_kl", "_morph",)

    def __init__(self):
        self._fields: set[int] = set()
        self._kl: set[int] = set()
        self._morph: set[int] = set()

    # ---- Stable ID helpers -------------------------------------------------
    @staticmethod
    def _aid(agent) -> int:
        aid = getattr(agent, "id", None)
        if aid is None:
            raise ValueError("DirtyManager: agent has no stable `id` attribute")
        return int(aid)

    # ---- Marking -----------------------------------------------------------
    def mark(self, *agents: object, kl: bool = False, morphism: bool = False) -> None:
        for a in agents:
            if a is None:
                continue
            aid = self._aid(a)
            # Always mark fields when any aspect of the agent changed
            self._fields.add(aid)
            setattr(a, "_dirty_fields", True)
            if kl:
                self._kl.add(aid)
                setattr(a, "_dirty_kl", True)
            if morphism:
                self._morph.add(aid)
                setattr(a, "morphisms_dirty", True)

    def mark_morphism_only(self, *agents: object) -> None:
        self.mark(*agents, morphism=True)

    def mark_kl_only(self, *agents: object) -> None:
        self.mark(*agents, kl=True)

    # ---- Selection ---------------------------------------------------------
    def take(self, all_agents: list, category: str = "fields") -> list:
        if   category == "fields": bag = self._fields
        elif category == "kl":     bag = self._kl
        elif category == "morph":  bag = self._morph
        else:
            raise ValueError(f"DirtyManager.take: unknown category {category!r}")

        if not bag:
            return []
        wanted = {int(x) for x in bag}
        subset = [a for a in (all_agents or []) if a is not None and self._aid(a) in wanted]
        bag.clear()
        return subset

    # ---- Post-processing cleanup ------------------------------------------
    def clear_agent_flags(self, *agents: object) -> None:
        for a in agents:
            if a is None:
                continue
            if hasattr(a, "_dirty_fields"): a._dirty_fields = False
            if hasattr(a, "_dirty_kl"):     a._dirty_kl = False
            if hasattr(a, "morphisms_dirty"): a.morphisms_dirty = False


# Attach/get from ctx (one per runtime context)
def dirty_manager(ctx) -> DirtyManager:
    d = getattr(ctx, "_dirty_manager", None)
    if d is None:
        d = DirtyManager()
        setattr(ctx, "_dirty_manager", d)
    return d



def ensure_dirty(ctx, generators_q, generators_p, scope="all"):
    """
    Resolve and process dirty agents for the given scope.

    Performs, in order:
      1) Select dirty targets via dirty_manager (category='kl' to match step mark).
      2) Ensure global intertwiner bases (Φ0, Φ̃0) exist in cache.
      3) Refresh dirty agents' Gaussian stats (sanitize Σ, compute inverses).
      4) Ensure Fisher information tensors exist for q/p fibers.
      5) Warm per-agent caches needed by edge/gradient code:
         - Local energy Hessians E and their inverses Jinv (q/p).
         - Per-agent morphisms Φ_i and Φ̃_i (q/p).
      6) Clear dirty flags and bump ctx.cache_version iff work happened.

    Returns
    -------
    targets : list[Agent]
        The list of agents that were processed (possibly empty).
    """
    DM = dirty_manager(ctx)

    # --- 1) Select targets by scope ---
    if scope not in ("all", "children"):
        raise ValueError(f"[ensure_dirty] unknown scope={scope!r}")

    all_children = list(getattr(ctx, "children_latest", []))
    # NOTE: match category with the mark() in synchronous_step (kl=True)
    targets = DM.take(all_children, category="kl")
    targets = [t for t in targets if t is not None]
    if not targets:
        return []

    # Whether any agent had flags set prior to processing (for version bump)
    had_flags = any(
        getattr(a, "_dirty_fields", False)
        or getattr(a, "_dirty_kl", False)
        or getattr(a, "morphisms_dirty", False)
        for a in targets
    )

    did_any = False

    # --- 2) Ensure global intertwiner bases in cache (Φ0, Φ̃0) ---
    try:
        from core.transport_cache import get_morphism_bases
        _ = get_morphism_bases(ctx, generators_q, generators_p)
        did_any = True
    except Exception:
        pass

    # --- 3) Refresh dirty agents' Gaussian stats (sanitize/invert) ---
    try:
        refresh_agents(targets, generators_q, generators_p, ctx=ctx)
        did_any = True
    except Exception:
        pass

    # --- 4) Ensure Fisher information tensors (q/p) ---
    eps = 1e-8
    try:
        eps = float(getattr(getattr(ctx, "step_cfg", None), "eps", eps))
    except Exception:
        eps = float(getattr(ctx, "eps", eps))

    for a in targets:
        try:
            _ensure_fisher(a, which="q", generators=generators_q, ctx=ctx, eps=eps)
            _ensure_fisher(a, which="p", generators=generators_p, ctx=ctx, eps=eps)
            did_any = True
        except Exception:
            continue

    # --- 5) Warm per-agent caches needed downstream ---
    try:
        from core.transport_cache import warm_E, warm_Jinv, Phi
        warm_E(ctx, targets, fibers=("q", "p"))
        warm_Jinv(ctx, targets, fibers=("q", "p"))
        for a in targets:
            try:
                _ = Phi(ctx, a, which="q")
            except Exception:
                pass
            try:
                _ = Phi(ctx, a, which="p")
            except Exception:
                pass
        did_any = True
    except Exception:
        pass

    # --- 6) Clear dirty flags & bump cache version if work happened ---
    if did_any:
        DM.clear_agent_flags(*targets)

    if did_any and had_flags:
        setattr(ctx, "cache_version", int(getattr(ctx, "cache_version", 0)) + 1)

    return targets




# ---------------------------------------------------------------------
# Per-agent preprocessing
# ---------------------------------------------------------------------


def refresh_agents(agents, Gq, Gp, *, ctx=None):
    """
    Lightweight, permissive preprocessing for a batch of agents.
    No strict shape policing—just make fields usable this step.

    Per agent (idempotent per-step):
      • ensure a mask exists (soft or binary), broadcast if needed
      • sanitize Σ_q / Σ_p to SPD and compute Σ^{-1}
      • refresh Fisher preconditioners (q/p)
      • tag `_preprocessed_step` to skip repeated work this step
    """
    import numpy as np
    from runtime_context import cfg_get
    from core.numerical_utils import sanitize_sigma, safe_inv
    from updates.update_helpers import _ensure_fisher  # uses inverse_fisher_metric_field under the hood

    if not agents:
        return []

    eps = float(cfg_get(ctx, "eps", 1e-8))
    step_tag = int(getattr(ctx, "global_step", -1))

    # Trust generator shapes; no hard assertions
    Gq = np.asarray(Gq);  Kq = int(Gq.shape[-1])
    Gp = np.asarray(Gp);  Kp = int(Gp.shape[-1])

    for a in agents:
        # Idempotent within the step
        if getattr(a, "_preprocessed_step", None) == step_tag and step_tag >= 0:
            continue

        # ---- spatial shape S (best-effort, no strict checks) ----
        S = ()
        if getattr(a, "sigma_q_field", None) is not None:
            S = np.asarray(a.sigma_q_field).shape[:-2]
        elif getattr(a, "mu_q_field", None) is not None:
            S = np.asarray(a.mu_q_field).shape[:-1]
        elif getattr(a, "sigma_p_field", None) is not None:
            S = np.asarray(a.sigma_p_field).shape[:-2]
        elif getattr(a, "mu_p_field", None) is not None:
            S = np.asarray(a.mu_p_field).shape[:-1]
        elif getattr(a, "mask", None) is not None:
            m0 = np.asarray(a.mask)
            if m0.ndim >= 1 and m0.shape[-1] == 1:
                m0 = m0[..., 0]
            S = m0.shape

        # ---- mask: ensure exists, float32 in [0,1] ----
        m = getattr(a, "mask", None)
        if m is None:
            a.mask = (np.ones(S, np.float32) if len(S) > 0 else np.array(1.0, np.float32))
        else:
            m = np.asarray(m)
            if m.ndim == len(S) + 1 and m.shape[-1] == 1:
                m = m[..., 0]
            if m.dtype == np.bool_:
                m = m.astype(np.float32, copy=False)
            else:
                m = np.clip(m.astype(np.float32, copy=False), 0.0, 1.0)
            a.mask = m

        # ---- μ fields: just coerce dtype to float32 if present ----
        if getattr(a, "mu_q_field", None) is not None:
            a.mu_q_field = np.asarray(a.mu_q_field, np.float32, order="C")
        if getattr(a, "mu_p_field", None) is not None:
            a.mu_p_field = np.asarray(a.mu_p_field, np.float32, order="C")

        # ---- Σ_q: sanitize → inverse (fallback to eye if missing) ----
        if getattr(a, "sigma_q_field", None) is not None:
            Sq64 = sanitize_sigma(np.asarray(a.sigma_q_field, np.float64), eps=eps)
            a.sigma_q_field = Sq64.astype(np.float32, copy=False)
            inv_q64 = safe_inv(Sq64, eps=eps)
            a.sigma_q_inv = inv_q64.astype(np.float32, copy=False)
        else:
            eye_q = np.eye(Kq, dtype=np.float32)
            a.sigma_q_field = np.broadcast_to(eye_q, tuple(S) + (Kq, Kq)).copy()
            a.sigma_q_inv   = np.broadcast_to(eye_q, tuple(S) + (Kq, Kq)).copy()

        # ---- Σ_p: sanitize → inverse (fallback to eye if missing) ----
        if getattr(a, "sigma_p_field", None) is not None:
            Sp64 = sanitize_sigma(np.asarray(a.sigma_p_field, np.float64), eps=eps)
            a.sigma_p_field = Sp64.astype(np.float32, copy=False)
            inv_p64 = safe_inv(Sp64, eps=eps)
            a.sigma_p_inv = inv_p64.astype(np.float32, copy=False)
        else:
            eye_p = np.eye(Kp, dtype=np.float32)
            a.sigma_p_field = np.broadcast_to(eye_p, tuple(S) + (Kp, Kp)).copy()
            a.sigma_p_inv   = np.broadcast_to(eye_p, tuple(S) + (Kp, Kp)).copy()

        # ---- Fisher preconditioners (q/p) ----
        try:
            _ensure_fisher(a, which="q", generators=Gq, ctx=ctx, eps=eps)
        except Exception:
            pass
        try:
            _ensure_fisher(a, which="p", generators=Gp, ctx=ctx, eps=eps)
        except Exception:
            pass

        # mark preprocessed
        a._preprocessed_step = step_tag

    return agents



def _ensure_fisher(agent, *, which, generators, ctx, eps):
    # choose field names by fiber
    if which == "q":
        attr = "inverse_fisher_phi"
    else:
        attr = "inverse_fisher_phi_model"

    Finv = getattr(agent, attr, None)
    if Finv is not None:
        return  # already present

    # Optional: central cache by (agent_id, which) to avoid recompute in parallel
    cache_key = ("fisher", which, int(getattr(agent, "id", -1)))
    try:
        cache = ctx._cache  # if you have a context cache dict
    except AttributeError:
        cache = None

    if cache is not None and cache_key in cache:
        setattr(agent, attr, cache[cache_key])
        return

    Finv = inverse_fisher_metric_field(ctx, agent, generators, which=which, eps=eps)
    setattr(agent, attr, Finv)
    if cache is not None:
        cache[cache_key] = Finv




