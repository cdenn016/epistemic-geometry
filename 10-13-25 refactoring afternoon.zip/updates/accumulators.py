# accumulators.py
from __future__ import annotations
from dataclasses import dataclass
from typing import Optional, Iterable
import numpy as np
from utils import _to32_no_underflow as _to32

# ---------- helpers (numeric stability, notes merge) ----------
def _add64(a, b):
    if a is None and b is None:
        return None
    if a is None:
        return np.asarray(b, np.float64).copy()
    if b is None:
        return np.asarray(a, np.float64).copy()
    return np.asarray(a, np.float64) + np.asarray(b, np.float64)




def _merge_notes(dst, src):
    if not src:
        return dst
    if dst is None:
        dst = {}
    for k, v in src.items():
        if k in dst and not isinstance(dst[k], list):
            dst[k] = [dst[k]]
        if k in dst:
            dst[k].append(v)
        else:
            dst[k] = v
    return dst


# ---------- bucket type ----------
@dataclass(slots=True)
class GradBuckets:
    dmu:  np.ndarray
    dS:   np.ndarray
    dphi: Optional[np.ndarray] = None
    notes: Optional[dict] = None

    @staticmethod
    def zeros_like_agent(agent, *, with_phi: bool = None, with_A: bool = False) -> "GradBuckets":
        """Build zero-shaped buckets that match an agent's fields (φ or φ̃)."""
        import numpy as np
    
        # Prefer phi if present, else phi_model
        if with_phi is None:
            with_phi = hasattr(agent, "phi") or hasattr(agent, "phi_model")
    
        dphi = None
        if with_phi:
            if hasattr(agent, "phi") and agent.phi is not None:
                dphi = np.zeros_like(np.asarray(agent.phi, dtype=np.float32))
            elif hasattr(agent, "phi_model") and agent.phi_model is not None:
                dphi = np.zeros_like(np.asarray(agent.phi_model, dtype=np.float32))
            else:
                # Fallback: assume (*S,3)
                dphi = np.zeros((*(np.asarray(getattr(agent, "mask", np.zeros((1,), np.float32))).shape), 3), dtype=np.float32)
    
        dA = None
        if with_A:
            A = getattr(getattr(agent, "ctx", None), "fields", {}).get("A", None)
            if A is not None:
                dA = np.zeros_like(np.asarray(A, dtype=np.float32))
    
        return GradBuckets(dphi=dphi, dA=dA, notes=None)


    def add_(self, other: "GradBuckets") -> "GradBuckets":
        # accumulate in float64 to reduce drift, then cast back to float32
        dmu64  = _add64(self.dmu,  other.dmu)
        dS64   = _add64(self.dS,   other.dS)
        dphi64 = _add64(self.dphi, other.dphi)

        self.dmu  = _to32(dmu64)
        self.dS   = _to32(dS64)
        self.dphi = _to32(dphi64)

        self.notes = _merge_notes(self.notes, other.notes)
        return self

    def __add__(self, other: "GradBuckets") -> "GradBuckets":
        # create a fresh bucket with 64-bit accumulation then cast to 32-bit
        dmu32  = _to32(_add64(self.dmu,  other.dmu))
        dS32   = _to32(_add64(self.dS,   other.dS))
        dphi32 = _to32(_add64(self.dphi, other.dphi))
        notes  = None
        if self.notes or other.notes:
            notes = {}
            if self.notes:
                notes = _merge_notes(notes, self.notes)
            if other.notes:
                notes = _merge_notes(notes, other.notes)
        return GradBuckets(dmu=dmu32, dS=dS32, dphi=dphi32, notes=notes)


def reduce_buckets(items: Iterable[GradBuckets]) -> GradBuckets:
    items = list(items)
    if not items:
        raise ValueError("reduce_buckets: empty iterable")
    while len(items) > 1:
        nxt = []
        it = iter(items)
        for a in it:
            try:
                b = next(it)
            except StopIteration:
                nxt.append(a)
                break
            nxt.append(a + b)
        items = nxt
    return items[0]



@dataclass(slots=True)
class ABucket:
    dA: np.ndarray           # (*S, M, 3)
    notes: dict | None = None

    @staticmethod
    def zeros_like(A, notes=None):
        return ABucket(dA=np.zeros_like(np.asarray(A, np.float32)), notes=(None if notes is None else dict(notes)))

    def add_(self, other: "ABucket") -> "ABucket":
        # 64-bit accumulation to minimize drift; return in fp32
        self.dA = (np.asarray(self.dA, np.float64) + np.asarray(other.dA, np.float64)).astype(np.float32, copy=False)
        if other.notes:
            self.notes = (self.notes or {}) | other.notes
        return self

    def __add__(self, other: "ABucket") -> "ABucket":
        out = ABucket(dA=np.asarray(self.dA, np.float32).copy(), notes=(None if self.notes is None else dict(self.notes)))
        return out.add_(other)

def reduce_A_buckets(buckets: list[ABucket]) -> ABucket:
    if not buckets:
        raise ValueError("reduce_A_buckets: empty list")
    out = buckets[0]
    for b in buckets[1:]:
        out = out + b
    return out

