# -*- coding: utf-8 -*-
"""
Created on Wed Sep 10 12:40:31 2025

@author: chris and christine
"""

import numpy as np
from core.transport_cache import ensure_global_A
from runtime_context import cfg_get
from utils import _to32_no_underflow



def _safe_mul_mask(Dm, m3):
    # Works for boolean or float masks; suppresses underflow on multiply and cast
    if m3.dtype == np.bool_:
        return np.where(m3, Dm, 0.0).astype(np.float32, copy=False)
    with np.errstate(under='ignore'):
        prod = Dm.astype(np.float64) * np.asarray(m3, np.float64)
    return _to32_no_underflow(prod)


_TINY32 = np.finfo(np.float32).tiny  # ~1.1754944e-38

def _sqnorm64(x) -> float:
    x64 = np.asarray(x, dtype=np.float64).ravel()
    return float(np.dot(x64, x64))



def _cross64(a, b):
    a64 = np.asarray(a, dtype=np.float64)
    b64 = np.asarray(b, dtype=np.float64)
    with np.errstate(under='ignore'):
        c64 = np.cross(a64, b64)
    return _to32_no_underflow(c64)



# --- safe centered difference and its adjoint (periodic) ---

def _cdiff_centered(x, *, axis: int, h: float):
    """
    Periodic centered difference: (roll-1 - roll+1) / (2h)
    Computed in float64; underflow-suppressed; cast with subnormals zeroed.
    """
    import numpy as np
    x64   = np.asarray(x, dtype=np.float64)
    inv2h = 0.5 / float(h)  # float64
    with np.errstate(under='ignore'):
        diff64 = (np.roll(x64, -1, axis=axis) - np.roll(x64, +1, axis=axis)) * inv2h
    return _to32_no_underflow(diff64)


def _cdiff_centered_adj(y, *, axis: int, h: float):
    """
    Adjoint of centered difference under periodic BCs.
    For the periodic centered stencil, adjoint = - centered difference.
    """
    import numpy as np
    y64   = np.asarray(y, dtype=np.float64)
    inv2h = 0.5 / float(h)  # float64
    with np.errstate(under='ignore'):
        # minus sign makes this the adjoint of _cdiff_centered under the standard inner product
        adj64 = -(np.roll(y64, -1, axis=axis) - np.roll(y64, +1, axis=axis)) * inv2h
    return _to32_no_underflow(adj64)



def step_global_A(ctx, agents, A_buckets=None):
    """
    One gradient step on global A:
      - curvature (lambda_A_curv),
      - optional extra coupling grad via A_buckets (preferred) or ctx.fields["A_grad_accum"] (fallback).
    Returns: total A-related energy = A_curv + A_cov.
    """
    import numpy as np

    init_scale = float(cfg_get(ctx, "A_init_scale", 0.0))

    # Infer spatial shape from an agent (robust for resume)
    a0 = agents[0]
    S  = tuple(np.asarray(a0.mu_q_field).shape[:-1])  # (*S, Kq)
    A  = ensure_global_A(ctx, spatial_shape=S, init_scale=init_scale)  # (*S, M, 3)

    # --- curvature term ---
    lam_A = float(cfg_get(ctx, "lambda_A_curv", 0.0))
    if lam_A > 0.0:
        E_curv, F, g_curv = curvature_energy_and_grad(A, weight=lam_A)
        if not hasattr(ctx, "fields"):
            ctx.fields = {}
        ctx.fields["A_curv_raw"]    = 0.5 * float(np.sum(F * F))  # unweighted
        ctx.fields["A_curv_energy"] = float(E_curv)               # weighted
        ctx.fields["A_curv_weight"] = float(lam_A)
    else:
        E_curv = 0.0
        F      = np.zeros(S + (3,), dtype=np.float32)    # for diagnostics
        g_curv = np.zeros_like(A, dtype=np.float32)

    # --- extra coupling grad (preferred: buckets; fallback: ctx.fields) ---
    E_cov   = 0.0
    g_extra = None

    if A_buckets:  # new path
        acc64 = np.zeros_like(A, dtype=np.float64)
        for b in A_buckets:
            if b is None:  # allow None entries
                continue
            acc64 += np.asarray(b.dA, np.float64)
            if getattr(b, "notes", None):
                E_cov += float(b.notes.get("energy", 0.0))
        g_extra = np.asarray(acc64, np.float32)
    else:
        # backward-compat: read any legacy accumulators
        if hasattr(ctx, "fields"):
            g_extra = ctx.fields.pop("A_grad_accum", None)
            E_cov   = float(ctx.fields.pop("A_cov_energy", 0.0))

    g_total = g_curv if g_extra is None else (g_curv + np.asarray(g_extra, np.float32))

    # --- step (clip + lr) ---
    lr   = float(cfg_get(ctx, "A_lr", 1e-2))
    gcap = float(cfg_get(ctx, "A_grad_clip", -1))
    n    = float(np.linalg.norm(g_total.reshape(-1))) if g_total.size else 0.0

    if n > 0.0 and lr > 0.0:
        s = 1.0 if gcap <= 0.0 else min(1.0, gcap / (n + 1e-9))
        A[...] = A - (lr * s) * g_total

    # --- diagnostics ---
    if not hasattr(ctx, "fields"):
        ctx.fields = {}
    ctx.fields["A_curv_energy"]     = float(E_curv)
    ctx.fields["A_cov_energy_last"] = float(E_cov)
    ctx.fields["A_grad_norm"]       = float(n)
    ctx.fields["A_curv_normF"]      = float(np.sqrt(np.mean(F * F))) if lam_A > 0.0 else 0.0

    return float(E_curv + E_cov)



def curvature_energy_and_grad(A, weight=1.0):
    """
    Non-Abelian curvature on an M-D periodic grid (SO(3) frame):
      F_{ab} = ∂_a A_b − ∂_b A_a + A_a × A_b,  for 0 ≤ a < b < M
      E = 1/2 * weight * sum_{a<b} ||F_{ab}||^2

    Shapes:
      A : (*S, M, 3)
      F : (*S, M, M, 3)   (antisymmetric: F[...,a,b,:] = -F[...,b,a,:])
      grad w.r.t A: (*S, M, 3)

    Notes:
      - Uses centered differences with unit spacing (h=1.0). If you need anisotropic
        spacings, wrap this with a version that passes h per-axis to the stencils.
      - All potentially-underflowing ops are performed in float64 under a local
        np.errstate(under='ignore'), then safely cast back to float32 using
        _to32_no_underflow to zero subnormals.
    """
    import numpy as np

    A = np.asarray(A, np.float32)
    if not (A.ndim >= 2 and A.shape[-2] >= 1 and A.shape[-1] == 3):
        raise AssertionError(f"A must be (*S, M, 3), got {A.shape}")
    S = A.shape[:-2]
    M = int(A.shape[-2])

    # --- compute all pairwise curvatures F_{ab} ---
    F = np.zeros(S + (M, M, 3), dtype=np.float32)
    for a in range(M):
        for b in range(a + 1, M):
            Aa = A[..., a, :]                       # (*S, 3)
            Ab = A[..., b, :]
            # centered differences with h=1.0 (safe implementations)
            d_a_Ab = _cdiff_centered(Ab, axis=a, h=1.0)   # ∂_a A_b
            d_b_Aa = _cdiff_centered(Aa, axis=b, h=1.0)   # ∂_b A_a
            # non-abelian term A_a × A_b (safe cross)
            Fab = d_a_Ab - d_b_Aa + _cross64(Aa, Ab)      # (*S, 3)
            F[..., a, b, :] = Fab
            F[..., b, a, :] = -Fab

    # --- energy (float64 accumulation; underflow-suppressed) ---
    with np.errstate(under='ignore'):
        E = 0.5 * float(weight) * _sqnorm64(F)

    # Scale F for gradient seed in float64 then safe-cast to float32
    with np.errstate(under='ignore'):
        G = _to32_no_underflow(np.asarray(weight, np.float64) * F.astype(np.float64, copy=False))

    # --- gradient wrt A: accumulate contributions from all pairs ---
    grad = np.zeros_like(A, dtype=np.float32)       # (*S, M, 3)
    for a in range(M):
        for b in range(a + 1, M):
            Gab = G[..., a, b, :]                   # (*S, 3)
            Aa  = A[..., a, :]
            Ab  = A[..., b, :]

            # from ∂_a A_b: + bwd_a(Gab) goes to A_b
            grad[..., b, :] += _cdiff_centered_adj(Gab, axis=a, h=1.0)

            # from −∂_b A_a: − bwd_b(Gab) goes to A_a
            grad[..., a, :] += -_cdiff_centered_adj(Gab, axis=b, h=1.0)

            # from A_a × A_b:  d/dA_a -> (A_b × Gab),  d/dA_b -> (Gab × A_a)
            grad[..., a, :] += _cross64(Ab, Gab)
            grad[..., b, :] += _cross64(Gab, Aa)

    if not (np.isfinite(E) and np.all(np.isfinite(grad)) and np.all(np.isfinite(F))):
        raise FloatingPointError("curvature_energy_and_grad produced non-finite outputs")

    return float(E), F, grad


def covariant_frame_energy_and_grads(phi, A, *, weight=1.0, mask=None, dx=1.0):
    """
    Gauge-covariant φ smoothness on an arbitrary-D periodic grid.

      E_cov = (weight/2) * sum_{m=0}^{M-1} || D_m φ ||^2
      D_m φ = ∂_m φ - A_m × φ        (SO(3): × is cross product)

    Args:
      phi   : (*S, 3)        Lie-algebra coords at each site (agent frame)
      A     : (*S, M, 3)     global connection components along each spatial axis
      weight: float          scalar weight for this term (already included in grads)
      mask  : (*S,) or (*S,1) or None   spatial mask (1=active); not differentiated
      dx    : float or tuple length M   grid spacing(s) per axis

    Returns:
      E_cov : float
      g_phi : (*S, 3)
      g_A   : (*S, M, 3)
    """
    import numpy as np

    # --- validate shapes/dtypes ---
    phi = np.asarray(phi, np.float32)      # (*S, 3)
    A   = np.asarray(A,   np.float32)      # (*S, M, 3)
    if phi.ndim < 2 or A.ndim < 3 or A.shape[-1] != 3:
        raise ValueError(f"bad inputs: phi {phi.shape}, A {A.shape}")
    if phi.shape[:-1] != A.shape[:-2]:
        raise ValueError(f"shape mismatch: phi {phi.shape}, A {A.shape}")

    S = phi.shape[:-1]
    M = int(A.shape[-2])

    # --- spacings (anisotropic allowed) ---
    if isinstance(dx, (tuple, list, np.ndarray)):
        if len(dx) != M:
            raise ValueError(f"dx length ({len(dx)}) must match spatial rank M={M}")
        hs = tuple(float(v) for v in dx)
    else:
        h = float(dx)
        if not (h > 0):
            raise ValueError("dx must be positive")
        hs = (h,) * M
    for h in hs:
        if not (h > 0):
            raise ValueError("all dx entries must be positive")

    # --- mask normalize to (*S,) bool; defer broadcast until use ---
    if mask is not None:
        m = np.asarray(mask)
        # squeeze optional last singleton
        if m.ndim == len(S) + 1 and m.shape[-1] == 1:
            m = m[..., 0]
        # broadcast/reshape to S
        if m.shape != S:
            pad = (1,) * max(0, len(S) - m.ndim)
            try:
                m = np.broadcast_to(m.reshape(pad + m.shape), S)
            except Exception as e:
                raise ValueError(f"mask shape {mask.shape} not broadcastable to {S}") from e
        mb = (m != 0)  # boolean support
    else:
        mb = None

    # --- D_m φ and energy (safe math) ---
    D_list = []
    for ax in range(M):
        Am = A[..., ax, :]                                  # (*S,3)
        # D_m φ = ∂_m φ − A_m × φ
        Dm_raw = _cdiff_centered(phi, axis=ax, h=hs[ax]) - _cross64(Am, phi)   # (*S,3)
        # apply mask without multiply (avoid underflow)
        if mb is not None:
            Dm = np.where(mb[..., None], Dm_raw, 0.0).astype(np.float32, copy=False)
        else:
            Dm = Dm_raw.astype(np.float32, copy=False)
        D_list.append(Dm)

    # energy accumulation in float64 (underflow-safe)
    with np.errstate(under='ignore'):
        E_acc = 0.0
        for Dm in D_list:
            E_acc += _sqnorm64(Dm)
        E = 0.5 * float(weight) * E_acc

    # --- gradients ---
    g_phi = np.zeros_like(phi, dtype=np.float32)
    g_A   = np.zeros_like(A,   dtype=np.float32)

    for ax in range(M):
        Dm = D_list[ax]
        # Scale in float64, suppress underflow, then cast without subnormals
        with np.errstate(under='ignore'):
            Gm = _to32_no_underflow(np.asarray(weight, np.float64) * Dm.astype(np.float64, copy=False))

        # φ-grad: adjoint of ∂_m is centered-adjoint; adjoint of (−A_m×·) is +(A_m×·)
        g_phi += -_cdiff_centered_adj(Gm, axis=ax, h=hs[ax]) + _cross64(A[..., ax, :], Gm)

        # A-grad from −A_m×φ term: − (φ × Gm)
        g_A[..., ax, :] += -_cross64(phi, Gm)

    # final mask on grads (no multiply)
    if mb is not None:
        g_phi = np.where(mb[..., None], g_phi, 0.0)
        g_A   = np.where(mb[..., None, None], g_A, 0.0)

    # safe downcast (zero subnormals before cast)
    g_phi = _to32_no_underflow(g_phi)
    g_A   = _to32_no_underflow(g_A)

    if not (np.isfinite(E) and np.all(np.isfinite(g_phi)) and np.all(np.isfinite(g_A))):
        raise FloatingPointError("covariant_frame_energy_and_grads produced non-finite outputs")

    return float(E), g_phi, g_A



