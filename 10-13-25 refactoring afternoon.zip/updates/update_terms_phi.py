# -*- coding: utf-8 -*-
"""
Created on Tue Oct 14 12:06:54 2025

@author: chris and christine
"""

import numpy as np
from core.numerical_utils import safe_inv, sanitize_sigma, safe_omega_inv
from core.transport_cache import (build_dexpinv_matrix , Jinv_grid, E_grid, Omega, 
                                  exp_and_jinv_single, Phi_cached )
from core.omega import d_exp_exact
from runtime_context import cfg_get
from utils import push_neighbor_stats, mask_hw, joint_masks
from core.numerical_utils import push_gaussian
from updates.update_helpers import _ensure_fisher

from updates.accumulators import GradBuckets, reduce_buckets  # new
from beta import beta_align_maps
#==============================================================================
#
#                    GATHER PHI GAUGE FIELD GRADIENT TERMS
#                          Beliefs and Models
#==============================================================================
def _phi_bucket(step_dphi, *, notes=None):
    step_dphi = np.asarray(step_dphi, np.float32)
    # Placeholders with zero trailing dims
    zeros_mu = np.zeros(step_dphi.shape[:-1] + (0,),  np.float32)       # (*S, 0)
    zeros_S  = np.zeros(step_dphi.shape[:-1] + (0,0), np.float32)       # (*S, 0, 0)
    return GradBuckets(
        dmu=zeros_mu,
        dS=zeros_S,
        dphi=step_dphi,
        notes=None if notes is None else dict(notes),
    )


def gather_phi_buckets_and_apply(
    ctx, agent_i, neighbors,
    generators_q, generators_p, *,
    field: str,                  # "phi" or "phi_tilde"
    fisher_inv_key: str,         # "fisher_inv_q" or "fisher_inv_p"
    grad_key: str,               # "grad_phi" or "grad_phi_tilde"
    phi_self_func=None,
    phi_feedback_func=None,
):
    gens = generators_q if field == "phi" else generators_p

    b_align = build_phi_align_bucket(ctx, agent_i, neighbors, gens,
                                     field=field, fisher_inv_key=fisher_inv_key)
    
    b_gamma = build_phi_gamma_bucket(ctx, agent_i, neighbors, gens,
                                     field=field, fisher_inv_key=fisher_inv_key)
   
    b_selfb = build_phi_self_feedback_bucket(ctx, agent_i, generators_q, generators_p,
                                             field=field, fisher_inv_key=fisher_inv_key,
                                             phi_self_func=phi_self_func,
                                             phi_feedback_func=phi_feedback_func)

    b_total = reduce_buckets([b_align, b_gamma, b_selfb])
   
    
    # Apply to agent grad slot (preserving existing contents)
    prev = getattr(agent_i, grad_key, None)
    setattr(agent_i, grad_key, (np.zeros_like(b_total.dphi) if prev is None else prev) + b_total.dphi)

    # Optional: store notes for diagnostics
    if b_total.notes is not None:
        if not hasattr(agent_i, "_last_phi_notes") or agent_i._last_phi_notes is None:
            agent_i._last_phi_notes = []
        agent_i._last_phi_notes.append(b_total.notes)

    return b_total.dphi



# --- tiny applier for sender buckets (list of pairs) -----------------------------
def apply_sender_phi_buckets(sender_pairs: list, *, grad_key: str):
    for agent_j, bucket in sender_pairs:
        prev = getattr(agent_j, grad_key, None)
        setattr(agent_j, grad_key, (np.zeros_like(bucket.dphi) if prev is None else prev) + bucket.dphi)



def compute_gbar_align_cov_recv(
    ctx, agent_i, neighbors, generators, *,
    field: str = "phi",          # "phi" (q) or "phi_tilde" (p)
    fisher_inv_key: str,         # e.g., "fisher_inv_q" / "fisher_inv_p"
):
    """
    β-weighted receiver-average ALIGN covector ḡ_i (in the receiver frame).

    Uses canonical joint mask handling and the same ALIGN covector used for
    receiver updates. Returns an array shaped like agent_i.<field> (*S, Dphi).
    """
   
    which = "q" if field == "phi" else "p"
    eps   = float(cfg_get(ctx, "eps", 1e-8))

    mu_key  = "mu_q_field"    if which == "q" else "mu_p_field"
    sg_key  = "sigma_q_field" if which == "q" else "sigma_p_field"

    # Receiver shapes
    mu_i   = np.asarray(getattr(agent_i, mu_key),  np.float32)
    phi_i  = np.asarray(getattr(agent_i, field),   np.float32)
    Sshape = mu_i.shape[:-1]
    Dphi   = int(phi_i.shape[-1])

    i_id = int(getattr(agent_i, "id", -1))

    # Ensure receiver Fisher/preconds once (also yields E_i)
    _ensure_fisher(agent_i, which=which, generators=generators, ctx=ctx, eps=eps)
    E_i, _, _ = get_preconds(ctx, agent_i, which, fisher_inv_key=fisher_inv_key)

    # Receiver exp differential (shared across neighbors)
    Q_all_i = d_exp_exact(phi_i, generators)

    gbar = np.zeros(Sshape + (Dphi,), dtype=np.float32)
    any_contrib = False

    for agent_j in (neighbors or []):
        # Canonical joint masks
        mbool, mvec = joint_masks(ctx, agent_i, agent_j)  # mbool: (*S,), mvec: (*S,1)
        if not np.any(mbool):
            continue
        mflat = mvec[..., 0]  # (*S,)

        j_id = int(getattr(agent_j, "id", -1))
        beta_map, _ = ctx.edge.get_align(ctx, which, i_id, j_id, shape=Sshape)
        beta_eff = beta_map * mflat
        if not np.any(beta_eff > 0.0):
            continue

        # Transport and neighbor stats in receiver frame
        Om  = np.asarray(Omega(ctx, agent_i, agent_j, which=which), np.float32)
        E_j = np.asarray(E_grid(ctx, agent_j, which=which),       np.float32)
        exp_neg_phi_j = safe_omega_inv(E_j)

        mu_j_t, S_j_t, S_j_t_inv = push_neighbor_stats(agent_j, sg_key, Om, eps)

        # ALIGN covector wrt receiver φ_i (receiver frame, unprojected)
        g_align_cov_recv = grad_kl_wrt_phi_i(
            getattr(agent_i, mu_key), getattr(agent_i, sg_key),
            None, None,
            phi_i, None,
            Om, generators, E_i, E_j,
            mu_j_t, S_j_t_inv, eps,
            exp_neg_phi_j=exp_neg_phi_j,
            Q_all=Q_all_i,
        ).astype(np.float32, copy=False)  # (*S, Dphi)

        gbar += beta_eff[..., None] * g_align_cov_recv
        any_contrib = True

    if not any_contrib:
        return gbar  # zeros
    return gbar





def _build_phi_sender_buckets_template(
    ctx, agent_i, neighbors, generators, *,
    field: str,              # "phi" or "phi_model"
    fisher_inv_key: str,     # "fisher_inv_q" or "fisher_inv_p"
    make_scales_and_covs,    # fn(ctx, agent_i, agent_j, joint_mask, ...) -> list[(scale_map, sender_cov, note_tag)]
) -> list:
    """
    Generic 'sender = scale * project(sender_cov)' builder.

    Uses canonical joint mask handling via utils.joint_masks, and projects each
    sender covector with the sender's Fisher/J-inverse preconditioners.

    Returns:
        list[(agent_j, GradBuckets)] where each bucket.dphi holds the summed
        sender contribution for j→i on the selected fiber.
    """
   

    which = "q" if field in ("phi", "phi_q") else "p"

    
    i_id = int(getattr(agent_i, "id", -1))
    out_pairs = []

    for agent_j in (neighbors or []):
        # Canonical joint masks (bool and broadcastable float forms)
        mbool, mvec = joint_masks(ctx, agent_i, agent_j)   # mbool: (*S,), mvec: (*S,1)
        if not np.any(mbool):
            continue
        mflat = mvec[..., 0]  # (*S,)

        # Ask the strategy for (scale_map, covector_in_sender_param, note_tag) triples
        triples = make_scales_and_covs(ctx, agent_i, agent_j, mflat, generators, field, fisher_inv_key)
        if not triples:
            continue

        # Preconds for the *sender* agent_j
        _, Jinv_j, Finv_j = get_preconds(ctx, agent_j, which=which, fisher_inv_key=fisher_inv_key)

        # Sum all terms for this sender into a single step
        step_send = None
        for scale_map, cov_sender, note_tag in triples:
            if scale_map is None or not np.any(scale_map):
                continue
            proj = project_phi_covector_to_step(np.asarray(cov_sender, np.float32), Jinv_j, Finv_j)  # (*S, Dphi)
            term = (np.asarray(scale_map, np.float32)[..., None] * proj).astype(np.float32, copy=False)
            step_send = term if step_send is None else (step_send + term)

        if step_send is None:
            continue

        bucket = GradBuckets(
            dmu=np.zeros(step_send.shape[:-1] + (0,),  np.float32),
            dS = np.zeros(step_send.shape[:-1] + (0,0), np.float32),
            dphi=step_send,
            notes={"term": f"send_{which}", "recv_id": i_id, "send_id": int(getattr(agent_j, "id", -1))},
        )
        out_pairs.append((agent_j, bucket))

    return out_pairs


def _make_align_sender_triples(ctx, agent_i, agent_j, m32, generators, field, fisher_inv_key):
    

    which = "q" if field in ("phi", "phi_q") else "p"
    eps   = float(cfg_get(ctx, "eps", 1e-8))

    mu_key  = "mu_q_field"    if which == "q" else "mu_p_field"
    sg_key  = "sigma_q_field" if which == "q" else "sigma_p_field"

    i_id = int(getattr(agent_i, "id", -1))
    j_id = int(getattr(agent_j, "id", -1))

    # Read via unified edge API
    beta_map, KL1_map = ctx.edge.get_align(ctx, which, i_id, j_id, shape=np.asarray(getattr(agent_i, mu_key)).shape[:-1])
    kappa    = max(float(cfg_get(ctx, f"beta_kappa_{which}", 1.0)), eps)

    beta_eff = beta_map * m32
    KL1_eff  = KL1_map  * m32
    scale    = beta_eff * (1.0 + (KL1_eff / kappa) * (beta_eff - 1.0))  # legacy combine

    # transport & sender covector
    Om   = np.asarray(Omega(ctx, agent_i, agent_j, which=which), np.float32)
    E_i, _, _ = get_preconds(ctx, agent_i, which, fisher_inv_key=fisher_inv_key)
    E_j = np.asarray(E_grid(ctx, agent_j, which=which), np.float32)
    exp_neg_phi_j = safe_omega_inv(E_j)
    mu_j_t, _, S_j_t_inv = push_neighbor_stats(agent_j, sg_key, Om, eps)

    attr = "phi" if which == "q" else "phi_model"
    phi_j   = np.asarray(getattr(agent_j, attr), np.float32)
    R_all_j = d_exp_exact(phi_j, generators)
    g_s_ij  = grad_kl_wrt_phi_j(
        getattr(agent_i, mu_key), getattr(agent_i, sg_key),
        getattr(agent_j, mu_key), getattr(agent_j, sg_key),
        mu_j_t, phi_j, Om, generators, E_i, E_j,
        mu_j_t, S_j_t_inv, eps,
        exp_neg_phi_j=exp_neg_phi_j, R_all=R_all_j,
    ).astype(np.float32, copy=False)

    return [(scale, g_s_ij, "align")]


def _make_gamma_sender_triples(ctx, agent_i, agent_j, m32, generators, field, fisher_inv_key):
    """
    Build Γ sender triples using unified edge maps (ctx.edge).
    Returns a list of (scale_map[*S], cov_sender[*S,Dphi], note_tag).
    """
    
    which = "q" if field in ("phi", "phi_q") else "p"
    eps   = float(cfg_get(ctx, "eps", 1e-8))
    kap   = float(cfg_get(ctx, f"kappa_gamma_{which}", 1.0))
    use_A = bool(cfg_get(ctx, f"use_gamma_A_{which}", True))
    use_B = bool(cfg_get(ctx, f"use_gamma_B_{which}", True))
    if not (use_A or use_B):
        return []

    i_id = int(getattr(agent_i, "id", -1))
    j_id = int(getattr(agent_j, "id", -1))

    # transport in q (matches legacy)
    Om_q_ij = np.asarray(Omega(ctx, agent_i, agent_j, which="q"), np.float32)

    Sshape = tuple(np.asarray(m32).shape)
    m32 = np.asarray(m32, np.float32)

    triples = []

    # helper: read gamma & optional KL via unified API, then build scale
    def _scale_from(case: str, aid: int, bid: int):
        g_map, K_map = ctx.edge.get_gamma(ctx, case, aid, bid, shape=Sshape)
        if g_map is None:
            return None
        s = np.asarray(g_map, np.float32) * m32
        if K_map is not None:
            s = s * (1.0 - np.asarray(K_map, np.float32) / max(kap, eps))
        return s

    # A-basis sender term (uses ("A", j->i))
    if use_A:
        scale_A = _scale_from("A", j_id, i_id)
        if scale_A is not None and np.any(scale_A):
            cov_iq_A, cov_jq_A, cov_ip_A = grad_gamma_phi_covectors(
                ctx, agent_i, agent_j, basis="a",
                Omega_ij=Om_q_ij, generators_irrep=generators, eps=eps
            )
            # sender covector is index [1]
            triples.append((scale_A, cov_jq_A, "gammaA"))

    # B-basis sender term (uses ("B", i->j))
    if use_B:
        scale_B = _scale_from("B", i_id, j_id)
        if scale_B is not None and np.any(scale_B):
            cov_iq_B, cov_jq_B, cov_ip_B = grad_gamma_phi_covectors(
                ctx, agent_i, agent_j, basis="b",
                Omega_ij=Om_q_ij, generators_irrep=generators, eps=eps
            )
            triples.append((scale_B, cov_jq_B, "gammaB"))

    return triples


def build_phi_gamma_bucket(
    ctx, agent_i, neighbors, generators, *,
    field: str,               # "phi" or "phi_tilde"
    fisher_inv_key: str,
) -> GradBuckets:
    

    which = "q" if field == "phi" else "p"
    use_A = bool(cfg_get(ctx, f"use_gamma_A_{which}", True))
    use_B = bool(cfg_get(ctx, f"use_gamma_B_{which}", True))
    if not (use_A or use_B):
        zeros = np.zeros_like(getattr(agent_i, field), np.float32)
        return _phi_bucket(zeros, notes={"term": f"gamma_{which}", "skipped": True})

    E_i, Jinv_i, Finv_i = get_preconds(ctx, agent_i, which=which, fisher_inv_key=fisher_inv_key)
    eps   = float(cfg_get(ctx,"eps",1e-8))
    kap   = float(cfg_get(ctx, f"kappa_gamma_{which}", 1.0))

    Sshape = np.asarray(getattr(agent_i, "mu_q_field" if which=="q" else "mu_p_field")).shape[:-1]
    Dphi   = int(np.asarray(getattr(agent_i, field)).shape[-1])

    step_recv_total = np.zeros(Sshape + (Dphi,), np.float32)
    i_id = int(getattr(agent_i,"id",-1))

    for agent_j in (neighbors or []):
        # canonical joint overlap
        mbool, mvec = joint_masks(ctx, agent_i, agent_j)  # (*S,), (*S,1)
        if not np.any(mbool): 
            continue
        m32 = mvec[..., 0]  # (*S,)

        j_id = int(getattr(agent_j,"id",-1))

        # read via unified API (zeros if missing)
        gA, KA = ctx.edge.get_gamma(ctx, "A", j_id, i_id, shape=Sshape) if use_A else (None, None)
        gB, KB = ctx.edge.get_gamma(ctx, "B", i_id, j_id, shape=Sshape) if use_B else (None, None)

        # transport on q-grid (legacy parity)
        Om_q_ij = np.asarray(Omega(ctx, agent_i, agent_j, which="q"), np.float32)

        cov_a = cov_b = None

        if use_A and gA is not None:
            scale = np.asarray(gA, np.float32) * m32
            if KA is not None:
                scale = scale * (1.0 - np.asarray(KA, np.float32) / max(kap, eps))
            if np.any(scale):
                if cov_a is None:
                    cov_iq_A, cov_jq_A, cov_ip_A = grad_gamma_phi_covectors(
                        ctx, agent_i, agent_j, basis="a", Omega_ij=Om_q_ij,
                        generators_irrep=generators, eps=eps
                    )
                    cov_a = (cov_iq_A, cov_jq_A, cov_ip_A)
                cov_i_A = cov_a[0] if field=="phi" else cov_a[2]
                step_recv_total += scale[...,None] * project_phi_covector_to_step(cov_i_A, Jinv_i, Finv_i)

        if use_B and gB is not None:
            scale = np.asarray(gB, np.float32) * m32
            if KB is not None:
                scale = scale * (1.0 - np.asarray(KB, np.float32) / max(kap, eps))
            if np.any(scale):
                if cov_b is None:
                    cov_iq_B, cov_jq_B, cov_ip_B = grad_gamma_phi_covectors(
                        ctx, agent_i, agent_j, basis="b", Omega_ij=Om_q_ij,
                        generators_irrep=generators, eps=eps
                    )
                    cov_b = (cov_iq_B, cov_jq_B, cov_ip_B)
                cov_i_B = cov_b[0] if field=="phi" else cov_b[2]
                step_recv_total += scale[...,None] * project_phi_covector_to_step(cov_i_B, Jinv_i, Finv_i)

    return _phi_bucket(step_recv_total, notes={"term": f"gamma_{which}"})










def build_phi_align_bucket(
    ctx, agent_i, neighbors, generators, *,
    field: str,                 # "phi" (q) or "phi_tilde" (p)
    fisher_inv_key: str,        # "fisher_inv_q" or "fisher_inv_p"
) -> GradBuckets:
    """
    Receiver-only ALIGN φ bucket for agent_i.
    Uses canonical joint mask handling and β-softmax correction with ḡ_i.
    Accumulates in float64 for stability; returns fp32.
    """
   
    which = "q" if field == "phi" else "p"
    eps   = float(cfg_get(ctx, "eps", 1e-8))
    kappa = max(float(cfg_get(ctx, f"beta_kappa_{which}", 1.0)), eps)

    mu_key  = "mu_q_field"    if which == "q" else "mu_p_field"
    sg_key  = "sigma_q_field" if which == "q" else "sigma_p_field"

    mu_i   = np.asarray(getattr(agent_i, mu_key),   np.float32)
    phi_i  = np.asarray(getattr(agent_i, field),    np.float32)   # (*S, Dphi)
    Sshape = mu_i.shape[:-1]
    Dphi   = int(phi_i.shape[-1])

    # β-weighted receiver-average covector ḡ_i (already in receiver frame)
    gbar_cov = compute_gbar_align_cov_recv(
        ctx, agent_i, neighbors, generators, field=field, fisher_inv_key=fisher_inv_key
    )
    if gbar_cov is None:
        gbar_cov = np.zeros(Sshape + (Dphi,), np.float32)
    else:
        gbar_cov = np.asarray(gbar_cov, np.float32)

    # Receiver preconditions (once)
    E_i, Jinv_i, Finv_i = get_preconds(ctx, agent_i, which, fisher_inv_key=fisher_inv_key)
    Q_all_i = d_exp_exact(phi_i, generators)

    step_total64 = np.zeros(Sshape + (Dphi,), np.float64)
    
    for agent_j in (neighbors or []):
        # Canonical joint masks
        mbool, mvec = joint_masks(ctx, agent_i, agent_j)  # mbool: (*S,), mvec: (*S,1)
        if not np.any(mbool):
            continue
        mflat = mvec[..., 0]  # (*S,)

        # β and KL1 via unified EdgeMaps (returns arrays; zeros if missing)
        # Uses the same orientation i ← j as the rest of EdgeMaps
       
        KL1_map, beta_map = beta_align_maps(ctx, agent_i, agent_j, which=which)
        beta_eff = (beta_map * mflat).astype(np.float32, copy=False)   # (*S,)
        KL1_eff  = (KL1_map  * mflat).astype(np.float32, copy=False)   # (*S,)
        if not np.any(beta_eff):
            continue

        # Transports / sender stats in receiver frame
        Om   = np.asarray(Omega(ctx, agent_i, agent_j, which=which), np.float32)
        E_j  = np.asarray(E_grid(ctx, agent_j, which=which),        np.float32)
        exp_neg_phi_j = safe_omega_inv(E_j)

        mu_j_t, S_j_t, S_j_t_inv = push_neighbor_stats(agent_j, sg_key, Om, eps)

        # ALIGN covector wrt receiver φ_i (receiver frame)
        g_align_cov_recv = grad_kl_wrt_phi_i(
            getattr(agent_i, mu_key), getattr(agent_i, sg_key),
            None, None,
            phi_i, None,
            Om, generators, E_i, E_j,
            mu_j_t, S_j_t_inv, eps,
            exp_neg_phi_j=exp_neg_phi_j, Q_all=Q_all_i,
        ).astype(np.float32, copy=False)  # (*S, Dphi)

        # Project receiver covector to BODY step
        step_align_recv = project_phi_covector_to_step(g_align_cov_recv, Jinv_i, Finv_i)  # (*S, Dphi)

        # Softmax correction using ḡ_i − g_ij
        factor   = (beta_eff * (KL1_eff / kappa)).astype(np.float32, copy=False)          # (*S,)
        corr_cov = (gbar_cov - g_align_cov_recv).astype(np.float32, copy=False)           # (*S, Dphi)
        step_corr = project_phi_covector_to_step(corr_cov, Jinv_i, Finv_i)                # (*S, Dphi)

        # Accumulate (broadcast last dim)
        step_total64 += (
            beta_eff[..., None].astype(np.float64)  * np.asarray(step_align_recv, np.float64) +
            factor  [..., None].astype(np.float64)  * np.asarray(step_corr,       np.float64)
        )

    step_total = np.asarray(step_total64, np.float32)
    return _phi_bucket(step_total, notes={"term": f"align_{which}"})



def build_phi_gamma_sender_buckets(ctx, agent_i, neighbors, generators, *, field: str, fisher_inv_key: str) -> list:
    return _build_phi_sender_buckets_template(
        ctx, agent_i, neighbors, generators,
        field=field, fisher_inv_key=fisher_inv_key,
        make_scales_and_covs=_make_gamma_sender_triples,
    )


# --- sender buckets: per-sender Δφ_j to match legacy --------------------------------
def build_phi_align_sender_buckets(ctx, agent_i, neighbors, generators, *, field: str, fisher_inv_key: str) -> list:
    return _build_phi_sender_buckets_template(
        ctx, agent_i, neighbors, generators,
        field=field, fisher_inv_key=fisher_inv_key,
        make_scales_and_covs=_make_align_sender_triples,
    )




def build_phi_self_feedback_bucket(
    ctx, agent_i, generators_q, generators_p, *,
    field: str,                 # "phi" or "phi_tilde"
    fisher_inv_key: str,        # "fisher_inv_q" / "fisher_inv_p"
    phi_self_func=None,
    phi_feedback_func=None,
) -> GradBuckets:
    which = "q" if field == "phi" else "p"
    eps   = float(cfg_get(ctx, "eps", 1e-8))
    tau   = float(cfg_get(ctx, "support_tau", 1e-6))
    alpha = float(cfg_get(ctx, "alpha", 0.0))
    fbw   = float(cfg_get(ctx, "feedback_weight", 0.0))

    mask3 = mask_hw(agent_i, tau=tau, mode="float3")
    if not np.any(mask3):
        return _phi_bucket(np.zeros_like(getattr(agent_i, field), np.float32), notes={"term": f"self_fb_{which}", "skipped": True})

    mu_q,  sigma_q  = agent_i.mu_q_field,  agent_i.sigma_q_field
    mu_p,  sigma_p  = agent_i.mu_p_field,  agent_i.sigma_p_field
    phi     = np.asarray(agent_i.phi,       np.float32)
    phi_t   = np.asarray(agent_i.phi_model, np.float32)

    base_phi = phi if field == "phi" else phi_t

    exp_this, exp_other, Jinv, _, G_q, G_p = exp_and_jinv_single(
        ctx, agent_i, field, base_phi, generators_q, generators_p
    )

    Phi_tilde = Phi_cached(ctx, agent_i, kind="p_to_q")
    mu_p_push  = getattr(agent_i, "_mu_p_push",         None)
    A_inv_push = getattr(agent_i, "_Sigma_p_push_inv",  None)
    if (mu_p_push is None) or (A_inv_push is None):
        mu_p_push, _, A_inv_push = push_gaussian(
            mu=mu_p, Sigma=sigma_p, M=Phi_tilde,
            eps=eps, return_inv=True, assume_orthogonal=False
        )
        setattr(agent_i, "_mu_p_push",        mu_p_push.astype(np.float32, copy=False))
        setattr(agent_i, "_Sigma_p_push_inv", A_inv_push.astype(np.float32, copy=False))

    Fi = getattr(agent_i, fisher_inv_key, None)
    if Fi is None:
        Fi = np.eye(base_phi.shape[-1], dtype=np.float32)
    else:
        Fi = np.asarray(Fi, np.float32, order="C")

    total = np.zeros_like(base_phi, dtype=np.float32)

    if alpha > 0.0 and phi_self_func is not None:
        g_param = phi_self_func(
            mu_q=mu_q, sigma_q=sigma_q,
            mu_p=mu_p, sigma_p=sigma_p,
            Phi_tilde_0=getattr(agent_i, "Phi_tilde_0", None),
            phi=phi, phi_tilde=phi_t,
            generators_q=G_q, generators_p=G_p,
            exp_phi=exp_this if field == "phi" else exp_other,
            exp_phi_tilde=exp_other if field == "phi" else exp_this,
            Phi_tilde=Phi_tilde,
            A_inv_cached=A_inv_push,
            mu_t_cached=mu_p_push,
            eps=eps,
        )
        g_body = np.einsum("...ji,...j->...i", Jinv, g_param, optimize=True)
        v_body = np.einsum("...ab,...b->...a", Fi, g_body,      optimize=True)
        v_param= np.einsum("...ab,...b->...a", Jinv, v_body,    optimize=True)
        total += (alpha * v_param * mask3)

    if fbw > 0.0 and phi_feedback_func is not None:
        g_param = phi_feedback_func(
            mu_p=mu_p, sigma_p=sigma_p,
            mu_q=mu_q, sigma_q=sigma_q,
            Phi_0=getattr(agent_i, "Phi_0", None),
            phi=phi, phi_tilde=phi_t,
            exp_phi=exp_this if field == "phi" else exp_other,
            exp_phi_tilde=exp_other if field == "phi" else exp_this,
            eps=eps,
            generators_q=G_q, generators_p=G_p,
        )
        g_body = np.einsum("...ji,...j->...i", Jinv, g_param, optimize=True)
        v_body = np.einsum("...ab,...b->...a", Fi, g_body,      optimize=True)
        v_param= np.einsum("...ab,...b->...a", Jinv, v_body,    optimize=True)
        total += (fbw * v_param * mask3)

    return _phi_bucket(total, notes={"term": f"self_fb_{which}"})







#==============================================================================
#
#                    WITH RESPECT TO phi_i TERMS
#                       VALIDATED
#==============================================================================



def grad_kl_wrt_phi_i(
    mu_i, sigma_i,
    mu_j, sigma_j,                 
    phi_i, phi_j,                  
    Omega_ij,
    generators,
    exp_phi_i,
    exp_phi_j,
    mu_j_t,                        
    sigma_j_t_inv,                 
    eps=1e-8,
    exp_neg_phi_j=None,
    Q_all=None,
):
        
    # ---- cast to f64 for internal math ----
    mu_i   = np.asarray(mu_i,   np.float64)
    mu_j_t = np.asarray(mu_j_t, np.float64)

    Sigma_i = sanitize_sigma(np.asarray(sigma_i, np.float64), eps=eps)
   
    # Q_all → (..., a, K, K)
    if Q_all is None:
        Q_all = d_exp_exact(np.asarray(phi_i, np.float64), generators)
    
    Q = np.stack([np.asarray(x, np.float64) for x in Q_all], axis=-3)

    # exp(-phi_j) broadcast to Q lead dims
    if exp_neg_phi_j is None:
        exp_neg_phi_j = safe_omega_inv(np.asarray(exp_phi_j, np.float64))
   
    # Ω and Ω^{-1}
    Om   = np.asarray(Omega_ij, np.float64)
    Oinv = safe_omega_inv(Om).astype(np.float64, copy=False)

    # Sanity on provided precision
    Sj_inv = np.asarray(sigma_j_t_inv, np.float64)
    
    Sj_inv = 0.5 * (Sj_inv + np.swapaxes(Sj_inv, -1, -2))
    
    # Core pieces
    delta_mu = (mu_i - mu_j_t)                     # (..., K)
    mu_j_src = np.einsum("...ij,...j->...i", Oinv, mu_j_t, optimize=True)  # (..., K)

    # dΩ/dφ_i^a = Q[a] @ e^{-φ_j}
    Q = np.einsum("...aik,...kj->...aij", Q, exp_neg_phi_j, optimize=True)
    Q_T = np.swapaxes(Q, -1, -2)
   
    # dΩ Ω^{-1}
    Q_tilde   = np.einsum("...aik,...kj->...aij", Q, Oinv, optimize=True)  
    Qtilde_T  = np.swapaxes(Q_tilde, -1, -2)
    
    # ---- precision (trace) term:  -1/2 * ⟨ A, Q̃ Σ_i + Σ_i Q̃^T ⟩
    t1 = np.einsum("...ij,...ajk,...ki->...a", Sj_inv, Q_tilde,  Sigma_i, optimize=True)
    t2 = np.einsum("...aij,...jk, ...ki->...a", Qtilde_T, Sj_inv, Sigma_i, optimize=True)
    trace_term = -0.5 * (t1 + t2)
    
    # mean term
    tmp1 = np.einsum("...aij,...j->...ai", Q_T,    delta_mu, optimize=True)
    tmp2 = np.einsum("...ij,...aj->...ai", Sj_inv, tmp1,     optimize=True)
    mean_term = -np.einsum("...i,...ai->...a", mu_j_src, tmp2, optimize=True)
    
    # ---- Mahalanobis (through ∂A) term: +1/2 * Δμ^T ( A Q̃ + Q̃^T A ) Δμ
    v1 = np.einsum("...ij,...j->...i", Sj_inv, delta_mu, optimize=True)          # A Δμ
    part1 = np.einsum("...aij,...j->...ai", Qtilde_T, v1, optimize=True)         # Q̃^T A Δμ
    v2    = np.einsum("...aij,...j->...ai", Q_tilde,  delta_mu, optimize=True)   # Q̃ Δμ
    part2 = np.einsum("...ij,...aj->...ai", Sj_inv,   v2, optimize=True)         # A Q̃ Δμ
    mahal_term = 0.5 * np.einsum("...i,...ai->...a", delta_mu, part1 + part2, optimize=True)

    grad = (trace_term + mean_term + mahal_term)

    return grad


def grad_kl_wrt_phi_j(
    mu_i, sigma_i,
    mu_j, sigma_j,                  # not used directly; kept for parity
    phi_i, phi_j,                   # not used directly here; we use exp(phi_*)
    Omega_ij,
    generators,
    exp_phi_i,
    exp_phi_j,
    mu_j_t,                         # μ_j' = Ω_ij μ_j
    sigma_j_t_inv,                  # Σ_j'^(-1) (already pushed)
    eps=1e-8,
    exp_neg_phi_j=None,
    R_all=None,                     # d exp(φ_j)/d φ_j^b (list/array of matrices); if None, we compute
):
    """
    ∂/∂φ_j KL(q_i || Ω_ij q_j). Mirrors grad_kl_wrt_phi_i but with:
      dΩ/dφ_j^b = - Ω  * ( R_j[b] @ e^{-φ_j} ).
    We work with U := dΩ and Ũ := (dΩ) Ω^{-1} = - Ω R̃ Ω^{-1}.
    """
    import numpy as np
    mu_i   = np.asarray(mu_i,   np.float64)
    mu_j_t = np.asarray(mu_j_t, np.float64)

    # sanitize Σ_i only once here
    Sigma_i = sanitize_sigma(np.asarray(sigma_i, np.float64), eps=eps)

    Om   = np.asarray(Omega_ij, np.float64)
    Oinv = safe_omega_inv(Om).astype(np.float64, copy=False)

    Sj_inv = np.asarray(sigma_j_t_inv, np.float64)
    Sj_inv = 0.5 * (Sj_inv + np.swapaxes(Sj_inv, -1, -2))

    # Δμ and μ_j in source coords
    delta_mu = (mu_i - mu_j_t)                                     # (..., K)
    mu_j_src = np.einsum("...ij,...j->...i", Oinv, mu_j_t, optimize=True)

    # exp(-φ_j)
    if exp_neg_phi_j is None:
        exp_neg_phi_j = safe_omega_inv(np.asarray(exp_phi_j, np.float64))

    # R_all: d exp(φ_j)/d φ_j^b  → stack as (..., b, K, K)
    if R_all is None:
        R_all = d_exp_exact(np.asarray(phi_j, np.float64), generators)
    R = np.stack([np.asarray(x, np.float64) for x in R_all], axis=-3)   # (..., b, K, K)

    # R̃_b = R_b @ e^{-φ_j}
    R_tilde = np.einsum("...bik,...kj->...bij", R, exp_neg_phi_j, optimize=True)  # (..., b, K, K)

    # U := dΩ = - Ω R̃ ;   U^T;  and Ũ := (dΩ) Ω^{-1} = - Ω R̃ Ω^{-1}
    U       = -np.einsum("...ik,...bkj->...bij", Om, R_tilde, optimize=True)      # (..., b, K, K)
    U_T     = np.swapaxes(U, -1, -2)
    U_tilde = -np.einsum("...ik,...bkj,...jl->...bil", Om, R_tilde, Oinv, optimize=True)
    Utilde_T= np.swapaxes(U_tilde, -1, -2)

    # -------- precision (trace) term:  -1/2 ⟨ A, Ũ Σ_i + Σ_i Ũ^T ⟩
    t1 = np.einsum("...ij,...bij,...jk->...b", Sj_inv, U_tilde, Sigma_i, optimize=True)
    t2 = np.einsum("...bij,...jk,...ki->...b", Utilde_T, Sj_inv, Sigma_i, optimize=True)
    trace_term = -0.5 * (t1 + t2)

    # -------- mean term (through dμ' = U μ_j_src)
    # tmp1_bi = U^T_bij Δμ_j'^j
    tmp1 = np.einsum("...bij,...j->...bi", U_T, delta_mu, optimize=True)
    # tmp2_bi = A_{ik} tmp1_bk
    tmp2 = np.einsum("...ij,...bj->...bi", Sj_inv, tmp1, optimize=True)
    mean_term = -np.einsum("...i,...bi->...b", mu_j_src, tmp2, optimize=True)

    # -------- Mahalanobis term: +1/2 Δμ^T ( A Ũ + Ũ^T A ) Δμ
    v1 = np.einsum("...ij,...j->...i", Sj_inv, delta_mu, optimize=True)            # A Δμ
    part1 = np.einsum("...bij,...j->...bi", Utilde_T, v1, optimize=True)           # Ũ^T A Δμ
    v2    = np.einsum("...bij,...j->...bi", U_tilde,  delta_mu, optimize=True)     # Ũ Δμ
    part2 = np.einsum("...ij,...bj->...bi", Sj_inv,   v2, optimize=True)           # A Ũ Δμ
    mahal_term = 0.5 * np.einsum("...i,...bi->...b", delta_mu, part1 + part2, optimize=True)

    grad = (trace_term + mean_term + mahal_term)    # (..., b)
    return grad




def grad_self_phi_direct(
    mu_q, sigma_q, mu_p, sigma_p, Phi_tilde_0,
    phi, phi_tilde, generators_q, generators_p,
    exp_phi, exp_phi_tilde, *,
    eps=1e-8,
    
    Phi_tilde=None,          # (H,W,K_q,K_p) from cache
    A_inv_cached=None,       # (H,W,K_q,K_q)  inverse of Φ̃ Σ_p Φ̃ᵀ
    mu_t_cached=None,        # (H,W,K_q)      Φ̃ μ_p
    Q_all=None,
    exp_neg_phi_tilde=None
):
    d, K_q, _ = generators_q.shape

    # Inverse of exp_phi_tilde if needed for dΦ̃
    if exp_neg_phi_tilde is None:
        #print("exp-phi~ is none\n\n\n")
        exp_neg_phi_tilde = safe_omega_inv(exp_phi_tilde)

    # Derivative blocks (still need these)
    if Q_all is None:
        #print("q-all is none\n\n\n")
        Q_all = np.stack(d_exp_exact(phi, generators_q), axis=-3)  # (..., d, K_q, K_q)

    # Pull Φ̃ from cache (or build only if missing)
    if Phi_tilde is None:
        #print("Phi~ is none\n\n\n")
        Phi_tilde = np.einsum("...ik,...kj,...jl->...il",
                              exp_phi, Phi_tilde_0, exp_neg_phi_tilde, optimize=True)

    Phi_tilde_T = np.swapaxes(Phi_tilde, -1, -2)

    # A^{-1} and Φ̃ μ_p: reuse when provided
    if (A_inv_cached is None) or (mu_t_cached is None):
        #print("pushes are none\n\n\n")
        mu_t, _, A_inv = push_gaussian(
            mu=mu_p, Sigma=sigma_p, M=Phi_tilde,
            eps=eps, return_inv=True, assume_orthogonal=False
        )
    else:
        mu_t, A_inv = mu_t_cached, A_inv_cached

    delta_mu = mu_q - mu_t

    # ∂Φ̃_a = Q_a Φ̃₀ e^{-φ̃}
    dPhi = np.einsum("...aik,...kj,...jl->...ail", Q_all, Phi_tilde_0, exp_neg_phi_tilde, optimize=True)
    dPhi_T = np.swapaxes(dPhi, -1, -2)

    # dA = dΦ̃ Σ_p Φ̃ᵀ + Φ̃ Σ_p dΦ̃ᵀ
    dA = (
        np.einsum("...aik,...kl,...lj->...aij", dPhi,       sigma_p, Phi_tilde_T, optimize=True) +
        np.einsum("...ik, ...kl,...alj->...aij", Phi_tilde, sigma_p, dPhi_T,      optimize=True)
    )

    # term1: - (∂Φ̃ μ_p)^T A^{-1} Δμ
    dPhi_mu_p = np.einsum("...aij,...j->...ai", dPhi, mu_p, optimize=True)
    term1 = -np.einsum("...ai,...i->...a",
                       dPhi_mu_p,
                       np.einsum("...ij,...j->...i", A_inv, delta_mu, optimize=True),
                       optimize=True)

    # term2: + 1/2 tr(A^{-1} dA)
    term2 = 0.5 * np.einsum("...ij,...aij->...a", A_inv, dA, optimize=True)

    # M = A^{-1} dA A^{-1}
    M = np.einsum("...ij,...ajk,...kl->...ail", A_inv, dA, A_inv, optimize=True)

    # term3: - 1/2 Δμ^T M Δμ
    term3 = -0.5 * np.einsum("...i,...aij,...j->...a", delta_mu, M, delta_mu, optimize=True)

    # term4: - 1/2 tr(M Σ_q)
    term4 = -0.5 * np.einsum("...aij,...ji->...a", M, sigma_q, optimize=True)

    return (term1 + term2 + term3 + term4).astype(np.float32, copy=False)


def grad_self_phi_tilde_direct(
    mu_q, sigma_q, mu_p, sigma_p, Phi_tilde_0,
    phi, phi_tilde, generators_q, generators_p,
    exp_phi, exp_phi_tilde, *,
    eps=1e-8,
    Phi_tilde=None,          # cached (S*,K_q,K_p)
    A_inv_cached=None,       # cached (S*,K_q,K_q)
    mu_t_cached=None,        # cached Φ̃ μ_p
    Q_tilde_all=None,
    exp_neg_phi_tilde=None
):
    d, K_p, _ = generators_p.shape

    if exp_neg_phi_tilde is None:
        #print("e^-phi~ is none\n\n\n")
        exp_neg_phi_tilde = safe_omega_inv(exp_phi_tilde)

    if Q_tilde_all is None:
        #print("Q~-all is none\n\n\n")
        Q_tilde_all = np.stack(d_exp_exact(phi_tilde, generators_p), axis=-3)

    if Phi_tilde is None:
        #print("Phi~ is none\n\n\n")
        Phi_tilde = np.einsum("...ik,...kj,...jl->...il",
                              exp_phi, Phi_tilde_0, exp_neg_phi_tilde, optimize=True)
    Phi_tilde_T = np.swapaxes(Phi_tilde, -1, -2)

    if (A_inv_cached is None) or (mu_t_cached is None):
        mu_t, _, A_inv = push_gaussian(
            mu=mu_p, Sigma=sigma_p, M=Phi_tilde,
            eps=eps, return_inv=True, assume_orthogonal=False
        )
    else:
        mu_t, A_inv = mu_t_cached, A_inv_cached

    delta_mu = mu_q - mu_t

    # R_a = Q̃_a e^{-φ̃}, dΦ̃_a = - Φ̃ R_a
    R    = np.einsum("...aik,...kj->...aij", Q_tilde_all, exp_neg_phi_tilde, optimize=True)
    dPhi = -np.einsum("...ik,...akj->...aij", Phi_tilde, R, optimize=True)
    dPhi_T = np.swapaxes(dPhi, -1, -2)

    dA = (
        np.einsum("...aik,...kl,...lj->...aij", dPhi,       sigma_p, Phi_tilde_T, optimize=True) +
        np.einsum("...ik, ...kl,...alj->...aij", Phi_tilde, sigma_p, dPhi_T,      optimize=True)
    )

    dPhi_mu_p = np.einsum("...aij,...j->...ai", dPhi, mu_p, optimize=True)
    term1 = -np.einsum("...ai,...i->...a",
                       dPhi_mu_p,
                       np.einsum("...ij,...j->...i", A_inv, delta_mu, optimize=True),
                       optimize=True)

    term2 = 0.5 * np.einsum("...ij,...aij->...a", A_inv, dA, optimize=True)

    M = np.einsum("...ij,...ajk,...kl->...ail", A_inv, dA, A_inv, optimize=True)

    term3 = -0.5 * np.einsum("...i,...aij,...j->...a", delta_mu, M, delta_mu, optimize=True)
    term4 = -0.5 * np.einsum("...aij,...ji->...a", M, sigma_q, optimize=True)

    return (term1 + term2 + term3 + term4).astype(np.float32, copy=False)







def grad_feedback_phi_direct(
    mu_p, sigma_p,
    mu_q, sigma_q,
    Phi_0,
    phi,                # (..., d)
    phi_tilde,          # (..., d)
    generators_q,       # (d, K_q, K_q)
    generators_p,
    exp_phi,            # (..., K_q, K_q)
    exp_phi_tilde,      # (..., K_p, K_p)
    eps=1e-8,
    Q_all=None,         # (..., d, K_q, K_q) = d_exp_exact(phi, generators_q)
    exp_neg_phi=None    # (..., K_q, K_q) = e^{-φ}
):
    """
    Vectorized over 'a': returns (..., d)
    Φ = e^{φ̃} Φ₀ e^{-φ}, ∂Φ = - Φ · (e^{-φ} (∂ e^{φ}) e^{-φ})
    """
    
    d, K_q, _ = generators_q.shape

    if exp_neg_phi is None:
        exp_neg_phi = safe_omega_inv(exp_phi)
    if Q_all is None:
        # stack as (..., d, K_q, K_q)
        Q_list = d_exp_exact(phi, generators_q)
        Q_all = np.stack(Q_list, axis=-3)  # assuming list of d arrays

    # Φ and Φᵀ
    Phi = np.einsum("...ik,...kj,...jl->...il", exp_phi_tilde, Phi_0, exp_neg_phi)
    Phi_T = np.swapaxes(Phi, -1, -2)

    # A, A^{-1}
    A = np.einsum("...ik,...kl,...lj->...ij", Phi, sigma_q, Phi_T)
    A = sanitize_sigma(A, eps=eps)
    A_inv = safe_inv(A, eps=eps)

    # Δμ and v
    Phi_mu_q = np.einsum("...ij,...j->...i", Phi, mu_q)
    delta_mu = mu_p - Phi_mu_q
    v = np.einsum("...ij,...j->...i", A_inv, delta_mu)  # (..., K_p)

    # Q̄_a = e^{-φ} Q_a e^{-φ}
    Q_bar = np.einsum("...ik,...akl,...lj->...aij", exp_neg_phi, Q_all, exp_neg_phi)

    # dΦ_a = - Φ Q̄_a
    dPhi = -np.einsum("...ik,...akj->...aij", Phi, Q_bar)
    dPhi_T = np.swapaxes(dPhi, -1, -2)

    # dA_a
    dA = (
        np.einsum("...aik,...kl,...lj->...aij", dPhi, sigma_q, Phi_T) +
        np.einsum("...ik,...kl,...alj->...aij", Phi,  sigma_q, dPhi_T)
    )

    # Term 1
    dPhi_mu = np.einsum("...aij,...j->...ai", dPhi, mu_q)       # (..., a, K_p)
    term1 = -np.einsum("...ai,...i->...a", dPhi_mu, v)

    # Term 2
    term2 = 0.5 * np.einsum("...ij,...aij->...a", A_inv, dA)

    # M_a = A^{-1} dA_a A^{-1}
    M = np.einsum("...ij,...ajk,...kl->...ail", A_inv, dA, A_inv)

    # Term 3
    term3 = -0.5 * np.einsum("...i,...aij,...j->...a", delta_mu, M, delta_mu)

    # Term 4
    term4 = -0.5 * np.einsum("...aij,...ji->...a", M, sigma_p)

    grad = (term1 + term2 + term3 + term4).astype(np.float32, copy=False)
    return grad




def grad_feedback_phi_tilde_direct(
    mu_p, sigma_p,
    mu_q, sigma_q,
    Phi_0,
    phi, 
    phi_tilde,
    generators_q, 
    generators_p,
    exp_phi, 
    exp_phi_tilde,
    eps=1e-8,
    Q_tilde_all=None,       # (..., d, K_p, K_p) = d_exp_exact(phi_tilde, generators_p)
    exp_neg_phi_tilde=None  # (..., K_p, K_p) = e^{-φ̃}
):
    """
    Vectorized over 'a': returns (..., d)
    Left-trivialize: dΦ_a = L_a Φ,  L_a = (∂e^{φ̃}/∂φ̃^a) e^{-φ̃}.
    """
    
    d, K_p, _ = generators_p.shape
    
    if exp_neg_phi_tilde is None:
        exp_neg_phi_tilde = safe_omega_inv(exp_phi_tilde)
    if Q_tilde_all is None:
        Q_list = d_exp_exact(phi_tilde, generators_p)
        Q_tilde_all = np.stack(Q_list, axis=-3)

    # Φ
    exp_neg_phi = safe_omega_inv(exp_phi)
    Phi   = np.einsum("...ik,...kj,...jl->...il", exp_phi_tilde, Phi_0, exp_neg_phi)
    Phi_T = np.swapaxes(Phi, -1, -2)

    
    A = np.einsum("...ik,...kl,...lj->...ij", Phi, sigma_q, Phi_T)
    A = sanitize_sigma(A, eps=eps)
    A_inv = safe_inv(A, eps=eps)

    Phi_mu_q = np.einsum("...ij,...j->...i", Phi, mu_q)
    delta_mu = mu_p - Phi_mu_q
    v = np.einsum("...ij,...j->...i", A_inv, delta_mu)

    # L_a = Q̃_a e^{-φ̃}
    L = np.einsum("...aik,...kj->...aij", Q_tilde_all, exp_neg_phi_tilde)

    # dΦ_a = L_a Φ
    dPhi = np.einsum("...aik,...kj->...aij", L, Phi)
    dPhi_T = np.swapaxes(dPhi, -1, -2)

    dA = (
        np.einsum("...aik,...kl,...lj->...aij", dPhi, sigma_q, Phi_T) +
        np.einsum("...ik,...kl,...alj->...aij", Phi,  sigma_q, dPhi_T)
    )

    dPhi_mu = np.einsum("...aij,...j->...ai", dPhi, mu_q)
    term1 = -np.einsum("...ai,...i->...a", dPhi_mu, v)

    term2 = 0.5 * np.einsum("...ij,...aij->...a", A_inv, dA)

    M = np.einsum("...ij,...ajk,...kl->...ail", A_inv, dA, A_inv)

    term3 = -0.5 * np.einsum("...i,...aij,...j->...a", delta_mu, M, delta_mu)
    term4 = -0.5 * np.einsum("...aij,...ji->...a", M, sigma_p)

    grad = term1 + term2 + term3 + term4
    return grad



def grad_gamma_A_phi_covectors(
    ctx, agent_i, agent_j,
    *,
    Omega_ij=None,                 # <— added back for compatibility (ignored)
    generators_irrep=None,
    eps: float = 1e-8,
    **_ignored,                    # <— eat any other legacy kwargs
):
    """
    Case A : KL_gamma = KL( q_j || Ω^q_{ji} Φ̃_i p_i ) in Q_j.

    Returns covectors (NO projection here):
      g_phi_i_q_cov : (*S, 3)   # for E_q(i) — exactly 0
      g_phi_j_q_cov : (*S, 3)   # for E_q(j)
      g_phi_i_p_cov : (*S, 3)   # for E_p(i)
    """
    

    # Frames
    Eqi = np.asarray(E_grid(ctx, agent_i, which="q"), np.float64)  # (*S,Kq,Kq) @ i
    Eqj = np.asarray(E_grid(ctx, agent_j, which="q"), np.float64)  # (*S,Kq,Kq) @ j
    Epi = np.asarray(E_grid(ctx, agent_i, which="p"), np.float64)  # (*S,Kp,Kp) @ i

    # Stats
    mu_j = np.asarray(agent_j.mu_q_field,    np.float64, order="C")
    Sj   = sanitize_sigma(np.asarray(agent_j.sigma_q_field, np.float64), eps=eps)
    mu_p = np.asarray(agent_i.mu_p_field,    np.float64, order="C")
    Sp   = sanitize_sigma(np.asarray(agent_i.sigma_p_field, np.float64), eps=eps)

    # Dual composite: R_dual = Ω_ji Φ̃_i = Eq(j) Ep(i)^T  (Eq(i) cancels)
    Rt = np.swapaxes
    R  = np.einsum("...ik,...jk->...ij", Eqj, Rt(Epi, -1, -2), optimize=True)       # (*S,Kq,Kp)

    # Landing model in Q_j
    mu_Q = np.einsum("...ij,...j->...i", R, mu_p, optimize=True)                    # (*S,Kq)
    S_Q  = np.einsum("...ij,...jk,...lk->...il", R, Sp, R, optimize=True)           # (*S,Kq,Kq)
    S_Q  = sanitize_sigma(S_Q, eps=eps)
    S_Qi = safe_inv(S_Q, eps=max(eps, 1e-12))

    # KL(P||Q) with P=N(mu_j,Sj), Q=N(mu_Q,S_Q):
    # ∂/∂μ_Q = Σ_Q^{-1}(μ_Q-μ_j)
    # ∂/∂Σ_Q = 1/2(-Σ_Q^{-1} Σ_j Σ_Q^{-1} - Σ_Q^{-1} d d^T Σ_Q^{-1} + Σ_Q^{-1})
    d     = (mu_Q - mu_j)
    dmuQ  = np.einsum("...ij,...j->...i", S_Qi, d, optimize=True)
    v     = np.einsum("...ij,...j->...i", S_Qi, d, optimize=True)
    vvT   = np.einsum("...i,...j->...ij", v, v, optimize=True)
    term  = np.einsum("...ij,...jk->...ik", S_Qi,
                      np.einsum("...jk,...kl->...jl", Sj, S_Qi, optimize=True),
                      optimize=True)
    dSQ   = 0.5 * (-term - vvT + S_Qi)
    dSQ   = 0.5 * (dSQ + Rt(dSQ, -1, -2))  # sym

    # ∂KL/∂R = (∂KL/∂μ_Q) μ_p^T + 2(∂KL/∂Σ_Q) R Σ_p
    G_R = np.einsum("...i,...j->...ij", dmuQ, mu_p, optimize=True) \
        + 2.0 * np.einsum("...ij,...jk,...kl->...il", dSQ, R, Sp, optimize=True)   # (*S,Kq,Kp)

    # Split via dR = dEq(j) Ep^T + Eq(j) dEp^T  ⇒
    #   <G_R, dR> = <G_R Ep, dEq(j)> + <G_R^T Eq, dEp>, with G_Eq(i) = 0.
    G_Eqj = np.einsum("...ij,...jk->...ik", G_R, Epi, optimize=True)               # (*S,Kq,Kq)
    G_Epi = np.einsum("...ji,...jk->...ik", Rt(G_R, -1, -2), Eqj, optimize=True)   # (*S,Kp,Kp)
    G_Eqi = np.zeros_like(Eqi, dtype=np.float64)

    # Matrix co-grads → parameter covectors
    g_phi_i_q_cov = matrix_cograd_to_param_covector_irrep(Eqi, G_Eqi, generators_irrep)  # zeros
    g_phi_j_q_cov = matrix_cograd_to_param_covector_irrep(Eqj, G_Eqj, generators_irrep)
    g_phi_i_p_cov = matrix_cograd_to_param_covector_irrep(Epi, G_Epi, generators_irrep)

    return (np.asarray(g_phi_i_q_cov, np.float32, order="C"),
            np.asarray(g_phi_j_q_cov, np.float32, order="C"),
            np.asarray(g_phi_i_p_cov, np.float32, order="C"))

def grad_gamma_B_phi_covectors(
    ctx, agent_i, agent_j,
    *,
    Omega_ij=None,                # kept for backward-compat; unused
    generators_irrep=None,        # (3,K,K) for active irrep
    eps: float = 1e-8,
    **_ignored,
):
    """
    Case B (P_i frame):
        KL_gamma = KL( p_i || Φ_i[Ω^q_ij q_j] )

    Returns covectors (NO projection here):
      g_phi_i_q_cov : (*S, 3)   # for E_q(i) — exactly 0 (R = E_p(i) E_q(j)^T)
      g_phi_j_q_cov : (*S, 3)   # for E_q(j)
      g_phi_i_p_cov : (*S, 3)   # for E_p(i)
    """
    

    # --- frames (float64) ---
    Eqi = np.asarray(E_grid(ctx, agent_i, which="q"), np.float64)   # (*S,Kq,Kq) @ i
    Eqj = np.asarray(E_grid(ctx, agent_j, which="q"), np.float64)   # (*S,Kq,Kq) @ j
    Epi = np.asarray(E_grid(ctx, agent_i, which="p"), np.float64)   # (*S,Kp,Kp) @ i

    # Optional hygiene: enforce exact orthogonality to kill drift jitter
    # (uncomment if you still see noise)
    # def _orth(X):
    #     # project to nearest O(K): X = USV^T -> U V^T (per voxel)
    #     U, _, Vt = np.linalg.svd(X, full_matrices=False)
    #     return np.einsum("...ik,...kj->...ij", U, Vt, optimize=True)
    # Eqj = _orth(Eqj); Epi = _orth(Epi)

    # --- stats (float64) ---
    mu_p = np.asarray(agent_i.mu_p_field,    np.float64, order="C")
    Sp   = sanitize_sigma(np.asarray(agent_i.sigma_p_field, np.float64), eps=eps)
    mu_j = np.asarray(agent_j.mu_q_field,    np.float64, order="C")
    Sj   = sanitize_sigma(np.asarray(agent_j.sigma_q_field, np.float64), eps=eps)

    # -------------------------------------------------------------------------
    # Exact factorization for Case B:
    # Φ_i = E_p(i) E_q(i)^T,  Ω_ij = E_q(i) E_q(j)^T  ⇒  R = Φ_i Ω_ij = E_p(i) E_q(j)^T
    # Landing in P_i:  μ_L = R μ_j,  Σ_L = R Σ_j R^T
    # KL: KL( N(μ_p,Σ_p) || N(μ_L,Σ_L) )
    # Target-form partials:
    #   v = Σ_L^{-1}(μ_p - μ_L)
    #   ∂KL/∂μ_L = -v
    #   ∂KL/∂Σ_L = 1/2( -Σ_L^{-1} Σ_p Σ_L^{-1} - v v^T + Σ_L^{-1} )
    # Chain rule:
    #   ∂KL/∂R = (∂KL/∂μ_L) μ_j^T + 2 (∂KL/∂Σ_L) R Σ_j
    # Split:
    #   dR = dE_p E_q(j)^T + E_p dE_q(j)^T  ⇒
    #   <G_R, dR> = <G_R E_q(j), dE_p> + <G_R^T E_p, dE_q(j)> ;  G_Eq(i) = 0 exactly.
    # -------------------------------------------------------------------------

    Rt = np.swapaxes
    R  = np.einsum("...ik,...jk->...ij", Epi, Rt(Eqj, -1, -2), optimize=True)        # (*S,Kp,Kq)

    # ---- (1) Build Σ_L carefully; avoid the common index flip ----
    # Safer 2-step version avoids accidental "...lk" vs "...kl" swaps
    RS   = np.einsum("...ij,...jk->...ik", R, Sj, optimize=True)                     # (*,Kp,Kq)
    S_L  = np.einsum("...ik,...jk->...ij", RS, R, optimize=True)                     # (*,Kp,Kp)  (R Σ_j R^T)
    S_L  = 0.5 * (S_L + Rt(S_L, -1, -2))
    S_L  = sanitize_sigma(S_L, eps=eps)
    S_L_inv = safe_inv(S_L, eps=max(eps, 1e-12))

    # ---- (2) Target-form partials ----
    mu_L = np.einsum("...ij,...j->...i", R, mu_j, optimize=True)
    delta = (mu_p - mu_L)
    v     = np.einsum("...ij,...j->...i", S_L_inv, delta, optimize=True)
    dmuL  = -v

    vvT   = np.einsum("...i,...j->...ij", v, v, optimize=True)
    t0    = -np.einsum("...ij,...jk,...kl->...il", S_L_inv, Sp, S_L_inv, optimize=True)
    dSL   = 0.5 * (t0 - vvT + S_L_inv)
    dSL   = 0.5 * (dSL + Rt(dSL, -1, -2))

    # ---- (3) ∂KL/∂R ----
    G_R = np.einsum("...i,...j->...ij", dmuL, mu_j, optimize=True) \
        + 2.0 * np.einsum("...ij,...jk,...kl->...il", dSL, R, Sj, optimize=True)    # (*,Kp,Kq)

    # ---- (4) Split to site-frame matrix co-grads (index-safe) ----
    # G_Ep = G_R E_q(j)     (Kp,Kp)
    # G_Eqj = (G_R^T) E_p   (Kq,Kq)
    G_Epi = np.einsum("...ij,...jk->...ik", G_R, Eqj, optimize=True)                 # (*,Kp,Kp)
    G_Eqj = np.einsum("...ji,...jk->...ik", Rt(G_R, -1, -2), Epi, optimize=True)     # (*,Kq,Kq)
    G_Eqi = np.zeros_like(Eqi, dtype=np.float64)                                     # exact 0

    # ---- (5) Matrix co-grads → param covectors ----
    g_phi_i_q_cov = matrix_cograd_to_param_covector_irrep(Eqi, G_Eqi, generators_irrep)  # zeros
    g_phi_j_q_cov = matrix_cograd_to_param_covector_irrep(Eqj, G_Eqj, generators_irrep)
    g_phi_i_p_cov = matrix_cograd_to_param_covector_irrep(Epi, G_Epi, generators_irrep)

    return (np.asarray(g_phi_i_q_cov, np.float32, order="C"),
            np.asarray(g_phi_j_q_cov, np.float32, order="C"),
            np.asarray(g_phi_i_p_cov, np.float32, order="C"))

def grad_gamma_phi_covectors(
    ctx, agent_i, agent_j,
    *,
    basis: str,
    Omega_ij=None,
    generators_irrep=None,   # (3,K,K) or None if K==3
    eps: float = 1e-8,
):
    """
    β-basis A/B dispatcher (covector-first).
    Returns param-space *covectors* (∂KL_beta/∂φ)_param per site/fiber:
        (g_phi_i_q_cov, g_phi_j_q_cov, g_phi_i_p_cov)  each (*S,3).

    For basis in {"align", "align_q", "align_p"}, returns zeros (product-rule handled elsewhere).
    """
    b = str(basis).lower()
    

    if b == "a":
        return grad_gamma_A_phi_covectors(
            ctx, agent_i, agent_j,
            Omega_ij=Omega_ij,
            generators_irrep=generators_irrep,
            eps=eps,
        )
    if b == "b":
        return grad_gamma_B_phi_covectors(
            ctx, agent_i, agent_j,
            Omega_ij=Omega_ij,
            generators_irrep=generators_irrep,
            eps=eps,
        )
    
    # Unknown basis → zeros
    S = tuple(agent_i.mu_p_field.shape[:-1])
    z = np.zeros(S + (3,), np.float32)
    return z, z, z


# 1) keep this utility as-is (optional: add finite checks inside)
def project_phi_covector_to_step(param_cograd, Jinv, Finv):
    """
    param-covector (∂L/∂φ)_param → param-step via:
        g_body = Jinv^T @ param_cograd
        v_body = Finv   @ g_body
        v_param= Jinv   @ v_body
    Shapes: grad: (*S,3), Jinv/Finv: (*S,3,3) → step: (*S,3)
    """
    g_body = np.einsum("...ji,...j->...i", Jinv, param_cograd, optimize=True)
    v_body = np.einsum("...ab,...b->...a", Finv, g_body,      optimize=True)
    return np.einsum("...ab,...b->...a",   Jinv, v_body,      optimize=True)


def get_preconds(ctx, agent, which, fisher_inv_key: str):
    """
    Fetch (E, Jinv, Finv) for the given fiber `which` using an explicit
    Fisher^{-1} attribute name. No identity fallback.
    """
    E    = np.asarray(E_grid(ctx, agent, which=which), np.float32)

    Jinv = Jinv_grid(ctx, agent, which=which)
    if Jinv is None:
        base_phi = np.asarray(getattr(agent, "phi" if which == "q" else "phi_model"), np.float32)
        Jinv = build_dexpinv_matrix(base_phi)

    Finv = getattr(agent, fisher_inv_key, None)
    if Finv is None:
        aid = getattr(agent, "id", "?")
        raise AttributeError(
            f"Agent(id={aid}) missing required Fisher inverse '{fisher_inv_key}' "
            f"for which='{which}'. Populate this field before calling the accumulator."
        )

    Finv = np.asarray(Finv, np.float32)
    if Finv.shape != Jinv.shape:
        raise ValueError(f"Finv shape {Finv.shape} mismatches Jinv shape {Jinv.shape}")
    if not (np.isfinite(E).all() and np.isfinite(Jinv).all() and np.isfinite(Finv).all()):
        raise FloatingPointError("non-finite values in E/Jinv/Finv")
    return E, Jinv, Finv


def matrix_cograd_to_param_covector_irrep(E, G_E, generators_irrep=None):
    """
    Map a matrix co-gradient G_E (same rep as E) to a parameter-space covector (*S,3).

    If generators_irrep is provided (shape (3,K,K)), use the general irrep path:
        α_a = tr( E^T G_E  · G_a^T )
    Otherwise, if K==3, use the adjoint fast-path (no generators required).

    Args:
      E:    (*S, K, K)  frame in some SO(3) rep
      G_E:  (*S, K, K)  matrix co-gradient w.r.t. E
      generators_irrep: optional (3,K,K)

    Returns:
      covector: (*S, 3)  in parameter coordinates (right-trivialized)
    """
    Rt = np.swapaxes
   
    # General irrep path when generators are given
    if generators_irrep is not None:
        H = np.einsum("...ij,...jk->...ik", Rt(E, -1, -2), G_E, optimize=True)  # H = E^T G_E
        # α_a = tr(H G_a^T)
        cov = np.stack(
            [np.einsum("...ij,ij->...", H, generators_irrep[a], optimize=True) for a in range(3)],
            axis=-1
        )
        return cov.astype(np.float32, copy=False)

    raise ValueError(
        "matrix_cograd_to_param_covector_irrep: either provide generators_irrep "
        "or ensure K==3 for the adjoint fast-path."
    )



