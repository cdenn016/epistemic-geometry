# Standard library
import os
# Third-party libraries
import numpy as np
from omega import (exp_lie_algebra_irrep, batch_apply_omega,
                              compute_field_strength)
from get_generators import get_generators 
from joblib import Parallel, delayed
import config
from pathlib import Path
from scipy.ndimage import laplace
from mask_utils import threshold_mask
from bundle_morphism_utils import safe_batch_apply_morphism_nat
from numerical_utils import sanitize_sigma, safe_inv,safe_logdet
from gaussian_core import kl_gaussians
import numpy as np
import config
from omega import batch_apply_omega, compute_inter_omega_fieldwise
from numerical_utils import sanitize_sigma, _invert_matrix_field

#==================================================================================
#
#                  Fields
#
#==================================================================================

import numpy as np

# ----------------------- tiny helpers: per-agent Ω caches -----------------------

def _omega_cache_get(agent, fiber: str):
    """fiber: 'q' or 'p'."""
    key = "Omega_cache_q" if fiber == "q" else "Omega_cache_p"
    d = getattr(agent, key, None)
    if d is None:
        d = {}
        setattr(agent, key, d)
    return d

def _omega_cache_lookup(A, j: int, K: int, fiber: str):
    """Return (H,W,K,K) Ωᵢⱼ if cached; else None."""
    cache = _omega_cache_get(A, fiber)
    return cache.get((j, K), None)

def _omega_cache_store(A, j: int, K: int, fiber: str, Omega_full: np.ndarray):
    cache = _omega_cache_get(A, fiber)
    cache[(j, K)] = Omega_full




def kl_divergence(mu1, sigma1, mu2, sigma2, mask=None, eps=1e-6):
    """
    KL[𝒩(μ₁, Σ₁) || 𝒩(μ₂, Σ₂)] — batched over N points.

    Args:
        mu1     : (N, K)       — mean of first Gaussian
        sigma1  : (N, K, K)    — cov of first Gaussian
        mu2     : (N, K)       — mean of second Gaussian
        sigma2  : (N, K, K)    — cov of second Gaussian
        mask    : (N,) or (N, 1), optional — multiplies KL values
        eps     : regularization constant for logdet and inverse

    Returns:
        kl_vals : (N,) — KL divergence values
    """
    mu1 = np.asarray(mu1)
    mu2 = np.asarray(mu2)
    sigma1 = np.asarray(sigma1)
    sigma2 = np.asarray(sigma2)

    assert mu1.shape == mu2.shape
    assert sigma1.shape == sigma2.shape
    N, K = mu1.shape

    sigma1 = sanitize_sigma(sigma1, eps=eps)
    sigma2 = sanitize_sigma(sigma2, eps=eps)

    sigma2_inv = safe_inv(sigma2, eps=eps)
    logdet1 = safe_logdet(sigma1, eps=eps)
    logdet2 = safe_logdet(sigma2, eps=eps)

    trace_term = np.einsum("nij,njk->nik", sigma2_inv, sigma1)
    trace_term = np.trace(trace_term, axis1=-2, axis2=-1)  # (N,)

    diff = mu2 - mu1
    mahal = np.einsum("ni,nij,nj->n", diff, sigma2_inv, diff)

    kl_vals = 0.5 * (trace_term + mahal - K + logdet2 - logdet1)

    if mask is not None:
        mask = np.asarray(mask)
        if mask.ndim == 2:
            mask = np.squeeze(mask, axis=-1)
        kl_vals *= mask

    if np.any(np.isnan(kl_vals)) or np.any(np.isinf(kl_vals)):
        raise ValueError("[KL Divergence] NaN or Inf detected in KL output")

    return kl_vals



def robust_aggregate_kl(
    kl_field, mask,
    *, 
    cap=100.0,          # hard per-pixel cap (use your signal_kl_cap)
    trim_hi=0.995,     # trim top 0.5% after capping
    area_norm=True,    # normalize by support area
    nan_policy="zero"  # {zero, drop}
):
    """
    Robust scalar from a per-pixel KL field.
    Returns (energy_scalar, stats).
    """
    m = np.asarray(mask, bool)
    if kl_field is None or not np.any(m):
        return 0.0, {"n":0}

    vals = np.asarray(kl_field, dtype=np.float64)[m]

    # Stabilize crazy values first
    vals = np.nan_to_num(vals, nan=(0.0 if nan_policy=="zero" else np.nan),
                         posinf=cap, neginf=0.0)

    # Hard cap (prevents single-pixel blow-ups)
    if cap is not None:
        vals = np.minimum(vals, cap)

    # High-end trim (guards even further)
    if trim_hi is not None:
        hi = np.quantile(vals, trim_hi)
        vals = vals[vals <= hi]

    n = max(len(vals), 1)
    total = float(np.sum(vals))
    if area_norm:
        area = float(np.count_nonzero(m))
        total = total / max(area, 1.0)

    stats = {
        "n": n,
        "mean": float(np.mean(vals)) if n else 0.0,
        "median": float(np.median(vals)) if n else 0.0,
        "p99": float(np.quantile(vals, 0.99)) if n>1 else 0.0,
        "max": float(np.max(vals)) if n else 0.0,
    }
    return total, stats


def _try_get_cached_omega(agent, j, K, fiber_key, H, W):
    """
    Return a full-field Ω cache (H,W,K,K) for neighbor j if it matches the requested fiber K.
    fiber_key: 'q' for belief, 'p' for model
    """
    # Preferred: separate caches per fiber
    attr_name = "Omega_cache_q" if fiber_key == "q" else "Omega_cache_p"
    cache = getattr(agent, attr_name, None)
    if isinstance(cache, dict):
        Om = cache.get(j, None)
        if Om is not None and Om.shape == (H, W, K, K):
            return Om

    # Alt: unified dict-of-dicts
    caches = getattr(agent, "Omega_caches", None)
    if isinstance(caches, dict) and fiber_key in caches and isinstance(caches[fiber_key], dict):
        Om = caches[fiber_key].get(j, None)
        if Om is not None and Om.shape == (H, W, K, K):
            return Om

    # Legacy: single cache dict[int -> (H,W,k,k)] — accept only if k==K
    legacy = getattr(agent, "Omega_cache", None)
    if isinstance(legacy, dict):
        Om = legacy.get(j, None)
        if Om is not None and Om.shape[:2] == (H, W) and Om.shape[-2:] == (K, K):
            return Om

    return None


def compute_alignment_field_general(
    agents, i, field_type="belief",
    eps=config.support_cutoff_eps,
    log_eps=config.log_eps
) -> np.ndarray:
    """
    Fiber-aware version: belief uses K_q, model uses K_p. Tries a matching-Κ cached Ω,
    else recomputes Ω on the overlap without erroring on cache mismatches.
    """
    A = agents[i]
    mask_i = threshold_mask(A.mask, eps)
    if not np.any(mask_i) or not getattr(A, "neighbors", None):
        return np.zeros_like(mask_i, dtype=np.float32)

    H, W = A.mask.shape
    kl_accum = np.zeros((H, W), dtype=np.float32)
    n_nb_at  = np.zeros((H, W), dtype=np.int32)
    kl_cap   = float(getattr(config, "signal_kl_cap", 5.0))

    if field_type == "belief":
        mu_i, sigma_i, phi_i, K, fiber_key = A.mu_q_field, A.sigma_q_field, A.phi, int(config.K_q), "q"
    elif field_type == "model":
        mu_i, sigma_i, phi_i, K, fiber_key = A.mu_p_field, A.sigma_p_field, A.phi_model, int(config.K_p), "p"
    else:
        raise ValueError(f"[compute_alignment_field_general] Invalid field_type: '{field_type}'")

    # strict SPD shape check for field-level covariance
    if sigma_i.ndim != 4 or sigma_i.shape[-2:] != (K, K):
        raise ValueError(f"Expected full SPD Σ_i with shape (H,W,{K},{K}); got {sigma_i.shape}")

    generators = get_generators(config.group_name, K)

    for nb in A.neighbors:
        j = nb["id"]
        B = agents[j]
        mask_j = threshold_mask(B.mask, eps)
        overlap = mask_i & mask_j
        if not np.any(overlap):
            continue

        if field_type == "belief":
            mu_j, sigma_j, phi_j = B.mu_q_field, B.sigma_q_field, B.phi
        else:
            mu_j, sigma_j, phi_j = B.mu_p_field, B.sigma_p_field, B.phi_model

        # strict SPD shape for neighbor
        if sigma_j.ndim != 4 or sigma_j.shape[-2:] != (K, K):
            raise ValueError(f"Expected full SPD Σ_j with shape (H,W,{K},{K}); got {sigma_j.shape}")

        idx = np.argwhere(overlap)
        r, c = idx[:, 0], idx[:, 1]

        mu_i_pts    = mu_i[overlap]        # (M,K)
        sigma_i_pts = sigma_i[overlap]     # (M,K,K)
        mu_j_pts    = mu_j[overlap]        # (M,K)
        sigma_j_pts = sigma_j[overlap]     # (M,K,K)

        sigma_i_pts = sanitize_sigma(sigma_i_pts, eps=log_eps)
        sigma_j_pts = sanitize_sigma(sigma_j_pts, eps=log_eps)

        # Try a cache that matches THIS fiber's K; else recompute
        Omega_full = _try_get_cached_omega(A, j, K, fiber_key, H, W)
        if Omega_full is not None:
            Omega = Omega_full[overlap]    # (M,K,K)
        else:
            O_i     = exp_lie_algebra_irrep(phi_i[overlap], generators)    # (M,K,K)
            O_j_inv = exp_lie_algebra_irrep(-phi_j[overlap], generators)   # (M,K,K)
            Omega   = np.matmul(O_i, O_j_inv)

        if not np.all(np.isfinite(Omega)):
            print(f"[WARNING] non-finite Ω({fiber_key}) for agent {i} ↔ neighbor {j}")

        mu_j_t    = np.einsum("mab,mb->ma", Omega, mu_j_pts)
        Omega_T   = np.swapaxes(Omega, -1, -2)
        sigma_j_t = np.matmul(np.matmul(Omega, sigma_j_pts), Omega_T)
        sigma_j_t = sanitize_sigma(sigma_j_t, eps=log_eps)

        kl_vals = kl_divergence(mu_i_pts, sigma_i_pts, mu_j_t, sigma_j_t, eps=log_eps)
        kl_vals = np.where(np.isfinite(kl_vals), kl_vals, 0.0)
        kl_vals = np.maximum(kl_vals, 0.0)
        if kl_cap is not None:
            kl_vals = np.minimum(kl_vals, kl_cap)

        np.add.at(kl_accum, (r, c), kl_vals.astype(np.float32, copy=False))
        np.add.at(n_nb_at,  (r, c), 1)

    out = np.zeros_like(kl_accum, dtype=np.float32)
    valid = n_nb_at > 0
    out[valid] = kl_accum[valid] / n_nb_at[valid]
    return out * mask_i.astype(np.float32, copy=False)





# ----------------------- cached pairwise KL: belief fiber -----------------------

def compute_pairwise_kl_belief(
    agents, generators_q, params, return_pointwise: bool = False, *, only_neighbors: bool = True
):
    log_eps = float(params.get("log_eps", 1e-8))
    eps     = float(params.get("overlap_eps", 1e-6))
    kl_cap  = float(params.get("kl_cap", getattr(config, "signal_kl_cap", 5.0)))

    N = len(agents)
    kl_matrix = np.full((N, N), np.nan, dtype=np.float32)
    pointwise = {} if return_pointwise else None

    for i, A in enumerate(agents):
        mask_i = (np.asarray(A.mask) > eps)
        H, W   = mask_i.shape

        # pre-sanitize Σᵢ once; we’ll slice later
        Sigma_i_full = sanitize_sigma(np.asarray(A.sigma_q_field), eps=log_eps)
        Mu_i_full    = np.asarray(A.mu_q_field)

        js_iter = [nb["id"] for nb in getattr(A, "neighbors", [])] if (only_neighbors and getattr(A, "neighbors", None)) else range(N)

        for j in js_iter:
            if i == j:
                kl_matrix[i, j] = 0.0
                continue

            B = agents[j]
            mask_j = (np.asarray(B.mask) > eps)
            overlap = mask_i & mask_j
            if not np.any(overlap):
                continue

            # Extract overlapped slices
            mu_i  = Mu_i_full[overlap]
            sig_i = Sigma_i_full[overlap]

            Mu_j_full    = np.asarray(B.mu_q_field)
            Sigma_j_full = sanitize_sigma(np.asarray(B.sigma_q_field), eps=log_eps)
            mu_j  = Mu_j_full[overlap]
            sig_j = Sigma_j_full[overlap]

            Kq = sig_i.shape[-1]
            if (sig_i.ndim != 3 or sig_i.shape[-2:] != (Kq, Kq) or
                sig_j.ndim != 3 or sig_j.shape[-2:] != (Kq, Kq)):
                raise ValueError("Belief Σ slices must be (M,K_q,K_q) full SPD")

            # ---------- Ω cache (full grid), then slice ----------
            Omega_full = _omega_cache_lookup(A, j, Kq, "q")
            if Omega_full is None:
                # compute once on FULL grid, then cache
                # (use full phi fields so Ω can be reused for other overlaps)
                phi_i_full = np.asarray(A.phi)
                phi_j_full = np.asarray(B.phi)
                Omega_full = compute_inter_omega_fieldwise(phi_i_full, phi_j_full, generators_q, config.group_name)
                Omega_full = Omega_full.astype(np.float32, copy=False)
                _omega_cache_store(A, j, Kq, "q", Omega_full)

                # also store inverse into B’s cache as Ωⱼᵢ (optional but fast)
                Omega_inv = _invert_matrix_field(Omega_full)
                if Omega_inv is not None:
                    _omega_cache_store(B, i, Kq, "q", Omega_inv)

            Omega_ij = Omega_full[overlap]

            # pushforward B→A
            mu_j_t, sig_j_t = batch_apply_omega(mu_j, sig_j, Omega_ij, eps=log_eps)
            sig_j_t = sanitize_sigma(sig_j_t, eps=log_eps)

            # KL with robust caps
            kl_vals = kl_divergence(mu_i, sig_i, mu_j_t, sig_j_t, eps=log_eps)
            kl_vals = np.where(np.isfinite(kl_vals), kl_vals, 0.0)
            kl_vals = np.maximum(kl_vals, 0.0)
            if kl_cap is not None:
                kl_vals = np.minimum(kl_vals, kl_cap)

            kl_matrix[i, j] = np.float32(np.mean(kl_vals))
            if return_pointwise:
                pw = np.zeros((H, W), dtype=np.float32)
                pw[overlap] = kl_vals.astype(np.float32, copy=False)
                pointwise[(i, j)] = pw

    return (kl_matrix, pointwise) if return_pointwise else kl_matrix


# ----------------------- cached pairwise KL: model fiber -----------------------

def compute_pairwise_kl_model(
    agents, generators_p, params, return_pointwise: bool = False, *, only_neighbors: bool = True
):
    log_eps = float(params.get("log_eps", 1e-8))
    eps     = float(params.get("overlap_eps", 1e-6))
    kl_cap  = float(params.get("kl_cap", getattr(config, "signal_kl_cap", 5.0)))

    N = len(agents)
    kl_matrix = np.full((N, N), np.nan, dtype=np.float32)
    pointwise = {} if return_pointwise else None

    for i, A in enumerate(agents):
        mask_i = (np.asarray(A.mask) > eps)
        H, W   = mask_i.shape

        Sigma_i_full = sanitize_sigma(np.asarray(A.sigma_p_field), eps=log_eps)
        Mu_i_full    = np.asarray(A.mu_p_field)

        js_iter = [nb["id"] for nb in getattr(A, "neighbors", [])] if (only_neighbors and getattr(A, "neighbors", None)) else range(N)

        for j in js_iter:
            if i == j:
                kl_matrix[i, j] = 0.0
                continue

            B = agents[j]
            mask_j = (np.asarray(B.mask) > eps)
            overlap = mask_i & mask_j
            if not np.any(overlap):
                continue

            mu_i  = Mu_i_full[overlap]
            sig_i = Sigma_i_full[overlap]

            Mu_j_full    = np.asarray(B.mu_p_field)
            Sigma_j_full = sanitize_sigma(np.asarray(B.sigma_p_field), eps=log_eps)
            mu_j  = Mu_j_full[overlap]
            sig_j = Sigma_j_full[overlap]

            Kp = sig_i.shape[-1]
            if (sig_i.ndim != 3 or sig_i.shape[-2:] != (Kp, Kp) or
                sig_j.ndim != 3 or sig_j.shape[-2:] != (Kp, Kp)):
                raise ValueError("Model Σ slices must be (M,K_p,K_p) full SPD")

            # ---------- Ω̃ cache (full grid), then slice ----------
            Omega_full = _omega_cache_lookup(A, j, Kp, "p")
            if Omega_full is None:
                phi_i_full = np.asarray(A.phi_model)
                phi_j_full = np.asarray(B.phi_model)
                Omega_full = compute_inter_omega_fieldwise(phi_i_full, phi_j_full, generators_p, config.group_name)
                Omega_full = Omega_full.astype(np.float32, copy=False)
                _omega_cache_store(A, j, Kp, "p", Omega_full)

                Omega_inv = _invert_matrix_field(Omega_full)
                if Omega_inv is not None:
                    _omega_cache_store(B, i, Kp, "p", Omega_inv)

            Omega_ij = Omega_full[overlap]

            mu_j_t, sig_j_t = batch_apply_omega(mu_j, sig_j, Omega_ij, eps=log_eps)
            sig_j_t = sanitize_sigma(sig_j_t, eps=log_eps)

            kl_vals = kl_divergence(mu_i, sig_i, mu_j_t, sig_j_t, eps=log_eps)
            kl_vals = np.where(np.isfinite(kl_vals), kl_vals, 0.0)
            kl_vals = np.maximum(kl_vals, 0.0)
            if kl_cap is not None:
                kl_vals = np.minimum(kl_vals, kl_cap)

            kl_matrix[i, j] = np.float32(np.mean(kl_vals))
            if return_pointwise:
                pw = np.zeros((H, W), dtype=np.float32)
                pw[overlap] = kl_vals.astype(np.float32, copy=False)
                pointwise[(i, j)] = pw

    return (kl_matrix, pointwise) if return_pointwise else kl_matrix




# ------------------------------ robust cross-scale KLs ------------------------------

def compute_crossscale_kl_q_single(child, parent, *, eps=1e-8, support_thr=1e-3, return_field=False):
    """
    Cross-scale belief KL:
        KL( q_child ||  Λ_q · q_parent )

    where Λ_q maps parent q-fiber → child q-fiber (shape broadcastable to (H,W,Kc,Kp)).

    Returns:
        scalar mean KL over overlap; optionally the per-pixel KL field.
    """
    # overlap mask
    m = _masked_overlap(child.mask, parent.mask, thr=support_thr)
    if not m.any():
        return (np.nan, np.zeros_like(child.mask, dtype=np.float32)) if return_field else np.nan

    # gather fields on overlap
    mu_c  = _as_float32(child.mu_q_field)[m]
    S_c   = _as_float32(child.sigma_q_field)[m]
    mu_p  = _as_float32(parent.mu_q_field)[m]
    S_p   = _as_float32(parent.sigma_q_field)[m]

    # Λ_q can be per-pixel (H,W,Kc,Kp) or global (Kc,Kp)
    L_q = getattr(parent, "Lambda_dn_q", None)
    if L_q is not None:
        L_q = _as_float32(L_q)
        L_qm = L_q[m] if (L_q.ndim >= 3 and L_q.shape[:2] == child.mask.shape) else L_q
    else:
        L_qm = None  # identity (shouldn't happen, but robust)

    # transform parent → child space
    mu_p_t, S_p_t = _apply_linear_morphism(mu_p, S_p, L_qm, eps=eps)

    # sanitize child Σ as well
    S_c = sanitize_sigma(S_c, eps=eps)

    # pointwise KL
    kl_vals = kl_divergence(mu_c, S_c, mu_p_t, S_p_t, eps=eps)
    kl_vals = np.where(np.isfinite(kl_vals), kl_vals, 0.0).astype(np.float32, copy=False)

    if return_field:
        out = np.zeros_like(child.mask, dtype=np.float32)
        out[m] = kl_vals
        return _finite_mean(kl_vals), out
    return _finite_mean(kl_vals)


def compute_crossscale_kl_p_single(child, parent, *, eps=1e-8, support_thr=1e-3, return_field=False):
    """
    Cross-scale model KL:
        KL( p_child ||  Λ_p · p_parent )

    where Λ_p maps parent p-fiber → child p-fiber (shape broadcastable to (H,W,Kc,Kp)).

    Returns:
        scalar mean KL over overlap; optionally the per-pixel KL field.
    """
    m = _masked_overlap(child.mask, parent.mask, thr=support_thr)
    if not m.any():
        return (np.nan, np.zeros_like(child.mask, dtype=np.float32)) if return_field else np.nan

    mu_c  = _as_float32(child.mu_p_field)[m]
    S_c   = _as_float32(child.sigma_p_field)[m]
    mu_p  = _as_float32(parent.mu_p_field)[m]
    S_p   = _as_float32(parent.sigma_p_field)[m]

    L_p = getattr(parent, "Lambda_dn_p", None)
    if L_p is not None:
        L_p = _as_float32(L_p)
        L_pm = L_p[m] if (L_p.ndim >= 3 and L_p.shape[:2] == child.mask.shape) else L_p
    else:
        L_pm = None

    mu_p_t, S_p_t = _apply_linear_morphism(mu_p, S_p, L_pm, eps=eps)
    S_c = sanitize_sigma(S_c, eps=eps)

    kl_vals = kl_divergence(mu_c, S_c, mu_p_t, S_p_t, eps=eps)
    kl_vals = np.where(np.isfinite(kl_vals), kl_vals, 0.0).astype(np.float32, copy=False)

    if return_field:
        out = np.zeros_like(child.mask, dtype=np.float32)
        out[m] = kl_vals
        return _finite_mean(kl_vals), out
    return _finite_mean(kl_vals)








#====================================================================
#
#                 Energy Fields
#
#====================================================================





def _auto_support(mask: np.ndarray,
                  morphism: np.ndarray | None,
                  thresh: float = 0.5,
                  dist_frac: float = 0.05,
                  morph_pct: float = 5.0) -> np.ndarray:
    """
    Automatic interior support:
      1) distance gate: keep points with distance-to-boundary >= dist_frac * inradius
      2) morphism gate: keep points with ||morphism||_F >= morph_pct percentile (on support)

    Args:
        mask        : (H,W) in [0,1] or bool
        morphism    : (H,W,*,*) array for Φ or Φ̃; if None, only distance gate used
        thresh      : threshold to binarize mask
        dist_frac   : fraction of inradius (0.05 = 5%)
        morph_pct   : lower percentile (e.g., 5.0) for morphism Frobenius norm

    Returns:
        (H,W) boolean interior mask
    """
    H, W = mask.shape
    m = (mask > thresh)
    if not m.any():
        return np.zeros((H, W), dtype=bool)

    # --- distance-from-boundary via EDT if available ---
    try:
        from scipy.ndimage import distance_transform_edt
        dist = distance_transform_edt(m)
    except Exception:
        # Fallback: a single binary erosion ≈ distance >= 1
        try:
            # try scipy binary_erosion if edt missing
            from scipy.ndimage import binary_erosion
            dist = binary_erosion(m, structure=np.ones((3,3), bool))
            dist = dist.astype(np.int32)
        except Exception:
            # pure NumPy sliding window min (cheap 1px erosion)
            from numpy.lib.stride_tricks import sliding_window_view as swv
            pad = np.pad(m.astype(np.uint8), 1, mode="edge")
            eroded = (swv(pad, (3,3)).min(axis=(-2,-1)) == 1)
            dist = eroded.astype(np.int32)

    maxd = int(dist[m].max()) if dist[m].size else 0
    d_cut = max(1, int(round(dist_frac * maxd))) if maxd > 0 else 0
    core = dist >= d_cut

    # --- morphism gate (optional/robust) ---
    if morphism is None:
        return core & m

    # Frobenius norm per pixel, tolerate NaNs/Infs
    M = np.asarray(morphism, dtype=np.float32).reshape(H, W, -1)
    phi_norm = np.linalg.norm(np.nan_to_num(M, nan=0.0, posinf=0.0, neginf=0.0), axis=-1)

    norms_on_support = phi_norm[m]
    if norms_on_support.size:
        n_cut = float(np.nanpercentile(norms_on_support, morph_pct))
    else:
        n_cut = 0.0

    strong = phi_norm >= n_cut
    return core & strong & m


# -------------------- KL field on auto support --------------------

def kl_divergence_field_auto(mu1: np.ndarray, S1: np.ndarray,
                             mu2: np.ndarray, S2: np.ndarray,
                             mask: np.ndarray,
                             morphism: np.ndarray | None,
                             eps: float = 1e-8) -> np.ndarray:
    """
    D_KL( N(mu1,S1) || N(mu2,S2) ) on an automatic interior support.
    S1, S2 are full SPD fields (H,W,K,K). Returns an (H,W) map.
    """
    supp = _auto_support(mask, morphism, thresh=0.5)
    if not supp.any():
        return np.zeros(mask.shape, dtype=np.float32)

    S1s = sanitize_sigma(S1, eps=eps)
    S2s = sanitize_sigma(S2, eps=eps)

    vals = kl_divergence(mu1[supp], S1s[supp], mu2[supp], S2s[supp], eps=eps)
    vals = np.where(np.isfinite(vals), vals, 0.0).astype(np.float32, copy=False)

    out = np.zeros(mask.shape, dtype=np.float32)
    out[supp] = vals
    return out


# -------------------- Energy fields (per-pixel) --------------------

def compute_self_energy(agent, eps, cfg):
    """
    α * KL(q_i || Φ̃ · p_i) on automatic interior support (gated by Φ̃).
    Returns an (H,W) field.
    """
    Phi_tilde = getattr(agent, "bundle_morphism_p_to_q", None)  # Φ̃: p→q
    mu_pq, S_pq = safe_batch_apply_morphism_nat(
        agent.mu_p_field, agent.sigma_p_field, Phi_tilde, eps=eps
    )
    field = kl_divergence_field_auto(
        mu1=agent.mu_q_field, S1=agent.sigma_q_field,
        mu2=mu_pq,          S2=S_pq,
        mask=agent.mask,    morphism=Phi_tilde,
        eps=eps,
    )
    alpha = float(cfg.get("alpha", 1.0))
    return alpha * field


def compute_feedback_energy(agent, eps, cfg):
    """
    λ * KL(p_i || Φ · q_i) on automatic interior support (gated by Φ).
    Returns an (H,W) field.
    """
    Phi = getattr(agent, "bundle_morphism_q_to_p", None)  # Φ: q→p
    mu_qp, S_qp = safe_batch_apply_morphism_nat(
        agent.mu_q_field, agent.sigma_q_field, Phi, eps=eps
    )
    field = kl_divergence_field_auto(
        mu1=agent.mu_p_field, S1=agent.sigma_p_field,
        mu2=mu_qp,           S2=S_qp,
        mask=agent.mask,     morphism=Phi,
        eps=eps,
    )
    lam = float(cfg.get("feedback_weight", 1.0))
    return lam * field




def compute_entropy_field(sigma_field, mask, log_eps=1e-8):
    m = np.asarray(mask, bool)
    if sigma_field.ndim == 3:
        var = np.clip(sigma_field**2, log_eps, None)
        log_det = np.sum(np.log(var), axis=-1)
        K = sigma_field.shape[-1]
        out = 0.5 * (K * np.log(2*np.pi*np.e) + log_det)
        out[~m] = 0.0
        return out
    H, W, K, _ = sigma_field.shape
    idx = np.flatnonzero(m.ravel())
    if idx.size == 0:
        return np.zeros((H, W), dtype=float)
    S = sigma_field.reshape(H*W, K, K)[idx]
    S = 0.5 * (S + np.swapaxes(S, -1, -2)) + log_eps * np.eye(K)[None, ...]
    sign, logdet = np.linalg.slogdet(S)
    out = np.zeros((H, W), dtype=float)
    out.reshape(-1)[idx] = 0.5 * (K * np.log(2*np.pi*np.e) + logdet)
    out[~m] = 0.0
    return out




#===================================================================
#
#            Scalar Energies
#
#===================================================================

# -------------------- Scalar energies (masked sums) --------------------

def _masked_finite_sum(arr: np.ndarray, mask: np.ndarray, thr: float) -> float:
    m = (mask > thr)
    if not m.any():
        return 0.0
    a = np.where(m, arr, 0.0)
    a = np.where(np.isfinite(a), a, 0.0)
    return float(np.sum(a, dtype=np.float64))

def compute_self_energy_scalar(agent, log_eps, cfg) -> float:
    """
    Weighted sum of KL(q_i || Φ̃·p_i) over valid support.
    """
    field = compute_self_energy(agent, log_eps, cfg)
    agent.e_self_field = field  # optional cache
    thr = float(cfg.get("support_cutoff_eps", 1e-3))
    return _masked_finite_sum(field, agent.mask, thr)

def compute_feedback_energy_scalar(agent, log_eps, cfg) -> float:
    """
    Weighted sum of KL(p_i || Φ·q_i) over valid support.
    """
    field = compute_feedback_energy(agent, log_eps, cfg)
    agent.e_feedback_field = field  # optional cache
    thr = float(cfg.get("support_cutoff_eps", 1e-3))
    return _masked_finite_sum(field, agent.mask, thr)


# -------------------- Regularizers --------------------

def compute_mass_energy(phi: np.ndarray, mask: np.ndarray, weight: float) -> float:
    """
    Mass regularization: E = weight * ∑_{mask} ||phi||^2
    phi: (H,W,d), mask: (H,W) in [0,1] or bool
    """
    m = (mask > 0)
    if not m.any():
        return 0.0
    norms_sq = np.sum(phi.astype(np.float32, copy=False)**2, axis=-1)
    return float(weight) * float(np.sum(np.where(m, norms_sq, 0.0), dtype=np.float64))




def compute_curvature_energy(phi_field, mask, weight, lie_gens, support_eps=1e-4, debug=False):
    F = compute_field_strength(phi_field, lie_gens)  # or named arg per your API
    support = mask > support_eps
    total = 0.0
    for val in F.values():
        if val.ndim == 2:   total += val**2
        elif val.ndim == 3: total += np.sum(val**2, axis=-1)
        elif val.ndim == 4: total += np.sum(val**2, axis=(-2,-1))
        else: raise ValueError(f"Unexpected F shape: {val.shape}")
    raw = float(np.sum(total[support]))
    if debug: print(f"[φ_curv] Raw: {raw:.4f} | Weighted: {weight*raw:.4f}")
    return weight*raw, raw






#==========================================================================
#
#                                Logging
#
#===========================================================================






# ============================================================
# Metrics (strict-SPD): per-agent + parent/morphism/Λ logging
# ============================================================



# ---------- base schema row ----------
def zero_agent_metrics() -> dict:
    return {
        # energies (unnormalized; divide by support when logging)
        "e_self": 0.0, "e_feedback": 0.0,
        "e_align": 0.0, "e_mod_align": 0.0,
        "e_curv": 0.0, "e_curv_mod": 0.0,
        "e_mass": 0.0, "e_mass_mod": 0.0,

        # support / graph
        "support": 0, "overlap_deg": 0,

        # field norms (sum over support)
        "phi_norm": 0.0, "phi_model_norm": 0.0,

        # curvature summaries (sum of pointwise Fro-norms on support)
        "F_norm_q_sum": 0.0, "F_norm_p_sum": 0.0,

        # covariance conditioning (on support)
        "min_eig_q": np.nan, "max_eig_q": np.nan, "cond_q": np.nan, "clipped_q": 0,
        "min_eig_p": np.nan, "max_eig_p": np.nan, "cond_p": np.nan, "clipped_p": 0,

        # gradients (if available)
        "grad_phi_norm": np.nan, "grad_phi_model_norm": np.nan,
        "grad_eta1_norm": np.nan, "grad_eta2_norm": np.nan,

        # numerical/debug counters (optional)
        "clips_applied": 0, "dexpinv_calls": 0,

        # caches (sizes)
        "omega_cache": 0, "omega_tilde_cache": 0,

        # morphisms / Λ (counts; parent-specific rows logged separately)
        "lambda_q_parents": 0, "lambda_p_parents": 0,
    }




# ---------- per-agent energy + stats ----------
def compute_all_agent_metrics(i, agent, Q_list, P_list, Mask_list, cfg, gens, log_eps) -> dict:
    """
    Returns a dict compatible with zero_agent_metrics().
    Uses strict full-SPD fields and the robust alignment field functions.
    """
    stats = zero_agent_metrics()
    mask  = Mask_list[i]
    if not np.any(mask):
        return stats

    # unpack fields (strict SPD: (H,W,K,K))
    (mu_q, Sig_q) = Q_list[i]
    (mu_p, Sig_p) = P_list[i]
    Kq = Sig_q.shape[-1]
    Kp = Sig_p.shape[-1]

    
    # Self / feedback (try dedicated scalars; else fall back to in-place KL over support)
    try:
        
        stats["e_self"]     = float(compute_self_energy_scalar(agent, log_eps, cfg))
        stats["e_feedback"] = float(compute_feedback_energy_scalar(agent, log_eps, cfg))
    except Exception:
        # fallback KLs: KL(q || p) and KL(p || q) on support
        kl_qp = kl_divergence(mu_q[mask], Sig_q[mask], mu_p[mask], Sig_p[mask], eps=log_eps)
        kl_pq = kl_divergence(mu_p[mask], Sig_p[mask], mu_q[mask], Sig_q[mask], eps=log_eps)
        stats["e_self"]     = float(np.sum(np.clip(kl_qp, 0.0, getattr(config, "signal_kl_cap", 5.0))))
        stats["e_feedback"] = float(np.sum(np.clip(kl_pq, 0.0, getattr(config, "signal_kl_cap", 5.0))))

    # Alignment (belief/model): compute per-pixel KL fields → sum on support
    try:
        KLq = compute_alignment_field_general(agents=cfg["agents_ref"], i=i, field_type="belief",
                                              eps=cfg.get("overlap_eps", config.overlap_eps), log_eps=log_eps)
    except Exception:
        # if no agents_ref available, compute within a local closure
        KLq = compute_alignment_field_general(agents=cfg.get("agents_ref_fallback", []), i=i,
                                              field_type="belief", eps=cfg.get("overlap_eps", config.overlap_eps),
                                              log_eps=log_eps)
    KLp = compute_alignment_field_general(agents=cfg["agents_ref"], i=i, field_type="model",
                                          eps=cfg.get("overlap_eps", config.overlap_eps), log_eps=log_eps)
    stats["e_align"]     = _sum_over_mask(KLq, mask)
    stats["e_mod_align"] = _sum_over_mask(KLp, mask)

    # Curvature (q/p): weighted energy + raw Fro-norm sums for visibility
    try:
        e_q, Fq = compute_curvature_energy(agent.phi, agent.mask, cfg.get("curvature_weight", 0.0), gens[0],
                                           support_eps=cfg.get("support_cutoff_eps", config.support_cutoff_eps),
                                           return_field=True)
        e_p, Fp = compute_curvature_energy(agent.phi_model, agent.mask, cfg.get("model_curvature_weight", 0.0), gens[1],
                                           support_eps=cfg.get("support_cutoff_eps", config.support_cutoff_eps),
                                           return_field=True)
        stats["e_curv"]      = float(e_q)
        stats["e_curv_mod"]  = float(e_p)
        stats["F_norm_q_sum"]= _sum_over_mask(np.linalg.norm(Fq, axis=(-2,-1)), mask) if Fq is not None else 0.0
        stats["F_norm_p_sum"]= _sum_over_mask(np.linalg.norm(Fp, axis=(-2,-1)), mask) if Fp is not None else 0.0
    except Exception:
        pass

    # Mass terms (q/p)
    try:
        stats["e_mass"]     = float(compute_mass_energy(agent.phi, agent.mask, cfg.get("phi_mass_weight", 0.0)))
        stats["e_mass_mod"] = float(compute_mass_energy(agent.phi_model, agent.mask, cfg.get("phi_model_mass_weight", 0.0)))
    except Exception:
        pass

    # ---- summary stats ----
    stats["support"]         = _support_size(mask)
    stats["overlap_deg"]     = len(getattr(agent, "neighbors", []) or [])
    stats["phi_norm"]        = _norm_over_mask(agent.phi, mask)
    stats["phi_model_norm"]  = _norm_over_mask(agent.phi_model, mask)

    # covariance conditioning
    try:
        sQ = _eig_stats(Sig_q, mask, eps=log_eps)
        sP = _eig_stats(Sig_p, mask, eps=log_eps)
        stats["min_eig_q"], stats["max_eig_q"], stats["cond_q"], stats["clipped_q"] = \
            sQ["min_eig"], sQ["max_eig"], sQ["cond"], sQ["clipped"]
        stats["min_eig_p"], stats["max_eig_p"], stats["cond_p"], stats["clipped_p"] = \
            sP["min_eig"], sP["max_eig"], sP["cond"], sP["clipped"]
    except Exception:
        pass

    # gradient norms if present
    if hasattr(agent, "grad_phi") and agent.grad_phi is not None:
        stats["grad_phi_norm"] = _norm_over_mask(agent.grad_phi, mask)
    if hasattr(agent, "grad_phi_tilde") and agent.grad_phi_tilde is not None:
        stats["grad_phi_model_norm"] = _norm_over_mask(agent.grad_phi_tilde, mask)

    # cache / cross-scale counts
    stats["omega_cache"]       = int(len(getattr(agent, "Omega_cache", {}) or {}))
    stats["omega_tilde_cache"] = int(len(getattr(agent, "Omega_tilde_cache", {}) or {}))
    stats["lambda_q_parents"]  = int(len(getattr(agent, "Lambda_up_q_map", {}) or {}))
    stats["lambda_p_parents"]  = int(len(getattr(agent, "Lambda_up_p_map", {}) or {}))

    return stats

# ---------- per-agent wrapper (runs the above + zero fallback) ----------
def compute_agent_metrics(i: int, agent, Q_list, P_list, Mask_list, cfg, gens, log_eps) -> tuple[int, dict]:
    mask = Mask_list[i]
    if not np.any(mask):
        return i, zero_agent_metrics()
    stats = compute_all_agent_metrics(i, agent, Q_list, P_list, Mask_list, cfg, gens, log_eps)
    return i, stats

# ---------- adapter: write scaled values into Agent.metrics_log ----------
def log_agent_metrics(agent, step: int, stats: dict, normalize=True):
    S = float(stats.get("support", 0) or 1.0)
    if not normalize: S = 1.0
    row = {
        # normalized energies
        "kl_self":            stats["e_self"]      / S,
        "kl_feedback":        stats["e_feedback"]  / S,
        "kl_align":           stats["e_align"]     / S,
        "kl_mod_align":       stats["e_mod_align"] / S,
        "curv_energy":        stats["e_curv"]      / S,
        "curv_model_energy":  stats["e_curv_mod"]  / S,
        "mass_energy":        stats["e_mass"]      / S,
        "mass_model_energy":  stats["e_mass_mod"]  / S,
        # raw support + norms
        "support":            stats["support"],
        "overlap_deg":        stats["overlap_deg"],
        "phi_norm":           stats["phi_norm"],
        "phi_model_norm":     stats["phi_model_norm"],
        # covariance conditioning
        "min_eig_q":          stats["min_eig_q"], "max_eig_q": stats["max_eig_q"],
        "cond_q":             stats["cond_q"],    "clipped_q": stats["clipped_q"],
        "min_eig_p":          stats["min_eig_p"], "max_eig_p": stats["max_eig_p"],
        "cond_p":             stats["cond_p"],    "clipped_p": stats["clipped_p"],
        # curvature summaries
        "F_norm_q_sum":       stats["F_norm_q_sum"] / S,
        "F_norm_p_sum":       stats["F_norm_p_sum"] / S,
        # grads + debug counters
        "grad_phi_norm":      stats["grad_phi_norm"],
        "grad_phi_model_norm":stats["grad_phi_model_norm"],
        "grad_eta1_norm":     stats["grad_eta1_norm"],
        "grad_eta2_norm":     stats["grad_eta2_norm"],
        "clips_applied":      stats["clips_applied"],
        "dexpinv_calls":      stats["dexpinv_calls"],
        # caches / Λ counts
        "omega_cache":        stats["omega_cache"],
        "omega_tilde_cache":  stats["omega_tilde_cache"],
        "lambda_q_parents":   stats["lambda_q_parents"],
        "lambda_p_parents":   stats["lambda_p_parents"],
        # schema tag
        "schema": (config.logging.get("schema_version", "v3") if hasattr(config, "logging") else "v3"),
    }
    agent.log_metrics(step, row)




# ---------- global logging driver ----------
def log_all_metrics(
    agents, step: int, params=None,
    q_field: str = "q", p_field: str = "p",
    phi_belief_field: str = "phi", phi_model_field: str = "phi_model",
    mask_field: str = "mask", n_jobs: int = -1
) -> dict:
    cfg = config if params is None else {**vars(config), **params}
    logcfg  = cfg.get("logging", {})
    log_eps = cfg.get("log_eps", 1e-10)

    K_q, K_p = cfg.get("K_q", 5), cfg.get("K_p", 5)
    name     = cfg.get("group_name", "so3")
    gen_q    = get_generators(name, K_q)
    gen_p    = get_generators(name, K_p)
    gens     = (gen_q, gen_p)

    # Precompute once
    Q_list    = [(A.mu_q_field, A.sigma_q_field) for A in agents]
    P_list    = [(A.mu_p_field, A.sigma_p_field) for A in agents]
    Mask_list = [_support_mask(getattr(A, mask_field), cfg.get("support_cutoff_eps", config.support_cutoff_eps))
                 for A in agents]

    # Store agents ref for alignment functions
    cfg = dict(cfg)
    cfg["agents_ref"] = agents

    # Parallel per-agent metrics
    results = Parallel(n_jobs=n_jobs, backend="threading", batch_size=1)(
        delayed(compute_agent_metrics)(i, agents[i], Q_list, P_list, Mask_list, cfg, gens, log_eps)
        for i in range(len(agents))
    )

    # Accumulate + write per-agent logs
    energy_keys = ["e_self","e_feedback","e_align","e_mod_align","e_curv","e_curv_mod","e_mass","e_mass_mod"]
    total_support, accum = 0, {k: 0.0 for k in energy_keys}
    for i, stats in results:
        total_support += stats.get("support", 0)
        for k in energy_keys: accum[k] += stats[k]
        log_agent_metrics(agents[i], step, stats, normalize=logcfg.get("normalize_by_support", True))

    S = float(total_support if total_support > 0 else 1.0)
    metrics = {k: accum[k] / S for k in energy_keys}
    metrics["total_energy"]  = sum(metrics[k] for k in energy_keys)
    metrics["support_total"] = total_support
    metrics["step"]          = step
    metrics["schema"]        = logcfg.get("schema_version", "v3")

    if logcfg.get("print_total_energy", True):
        print(f"[STEP {step:04d}] Total Energy = {metrics['total_energy']:.6f}")

    # Optional: parent/morphism/Λ CSV rows
    if logcfg.get("log_parent_rows", True):
        # If you have a list of parent agents separate from children, pass that list here.
        # Otherwise, treat all as potential parents (rows will contain child counts etc.)
        rows = log_parent_metrics(agents, step=step, cfg=cfg, generators=gens)
        # You can write 'rows' to disk here if desired; or return alongside metrics.
        metrics["parent_rows"] = rows

    return metrics

# ---------- parent rows (enriched: Λ, morphisms, overlap coverage) ----------
def compute_parent_metrics(P, children=None, thr=0.30, cfg=None, generators=None) -> dict:
    """
    Returns a dict summarizing one parent agent, including Λ stats and cross-scale KLs if available.
    """
    stats = {
        "support_px": int(np.sum((np.asarray(P.mask) > thr).astype(np.int64))),
        "level": int(getattr(P, "level", 0)),
        "n_children": int(len(getattr(P, "child_ids", []) or [])),
        # morphisms present?
        "has_Phi_q_to_p": bool(getattr(P, "bundle_morphism_q_to_p", None) is not None),
        "has_Phi_p_to_q": bool(getattr(P, "bundle_morphism_p_to_q", None) is not None),
        # Λ maps present?
        "lambda_q_parents": int(len(getattr(P, "Lambda_up_q_map", {}) or {})),
        "lambda_p_parents": int(len(getattr(P, "Lambda_up_p_map", {}) or {})),
    }

    # quick φ norms
    m = np.asarray(P.mask) > thr
    stats["phi_norm"]       = _norm_over_mask(getattr(P, "phi", None), m)
    stats["phi_model_norm"] = _norm_over_mask(getattr(P, "phi_model", None), m)

    # global Λ determinants if present (primary parent globals)
    for key, store in (("Lambda_up_q_global", getattr(P, "Lambda_up_q_global", {})),
                       ("Lambda_up_p_global", getattr(P, "Lambda_up_p_global", {}))):
        if store:
            # pick first entry determinent and Fro-norm as a proxy
            M = next(iter(store.values()))
            try:
                stats[f"{key}_det"]  = float(np.linalg.det(M))
            except Exception:
                stats[f"{key}_det"]  = np.nan
            stats[f"{key}_norm"] = float(np.linalg.norm(M))

    # Optional cross-scale KL summaries (child → parent alignment), if helpers exist
    kid_ids = getattr(P, "child_ids", []) or []
    try:
        if kid_ids and hasattr(P, "Lambda_dn_q") and P.Lambda_dn_q is not None:
            vals = []
            for cid in kid_ids:
                v = compute_crossscale_kl_q_single(children[cid], P, eps=1e-6)
                if np.isfinite(v): vals.append(v)
            if vals: stats["kl_q_mean"] = float(np.mean(vals))
    except Exception:
        pass

    try:
        if kid_ids and hasattr(P, "Lambda_dn_p") and P.Lambda_dn_p is not None:
            vals = []
            for cid in kid_ids:
                v = compute_crossscale_kl_p_single(children[cid], P, eps=1e-6)
                if np.isfinite(v): vals.append(v)
            if vals: stats["kl_p_mean"] = float(np.mean(vals))
    except Exception:
        pass

    return stats

def log_parent_metrics(parents, step: int, cfg=None, generators=None, thr=0.3) -> list[dict]:
    rows = []
    # Optional external indexable child list can be attached as P._children_ref
    for pid, P in enumerate(parents):
        s = compute_parent_metrics(P, children=(P.child_ids and getattr(P, "_children_ref", None)), thr=thr, cfg=cfg, generators=generators)
        s["step"] = step
        s["parent"] = pid
        rows.append(s)
    return rows

def log_parent_metrics_with_children(parents, children, step: int, cfg=None, generators=None, thr=0.3) -> list[dict]:
    rows = []
    for pid, P in enumerate(parents):
        s = compute_parent_metrics(P, children=children, thr=thr, cfg=cfg, generators=generators)
        s["step"] = step
        s["parent"] = pid
        rows.append(s)
    return rows





def dump_snapshot_npz(
    agents,
    step: int,
    outdir: str,
    *,
    include=("mu_q","sigma_q","phi","mu_p","sigma_p","phi_model","mask"),
    compute_alignment: bool = False,
    compute_curvature: bool = False,
    fp16: bool = True,
    params: dict | None = None,
) -> str:
    """
    Lightweight, fiber-aware snapshot of fields for debugging/analysis.

    - Always strict SPD (no diagonal covariance).
    - Fiber-aware (belief uses K_q, model uses K_p).
    - Alignment/curvature are optional (off by default) to keep it cheap.
    - Honors config.logging.schema_version if present.
    """
    dtype = np.float16 if fp16 else np.float32
    H, W = agents[0].mu_q_field.shape[:2]
    N    = len(agents)
    K_q  = int(getattr(config, "K_q", agents[0].sigma_q_field.shape[-1]))
    K_p  = int(getattr(config, "K_p", agents[0].sigma_p_field.shape[-1]))
    schema = "v3"
    if hasattr(config, "logging") and isinstance(config.logging, dict):
        schema = config.logging.get("schema_version", schema)
    if params and isinstance(params, dict):
        schema = params.get("logging", {}).get("schema_version", schema)

    # Allocate only what is requested
    out = {"schema": schema}
    if "mu_q"    in include: out["mu_q"]    = np.zeros((N,H,W,K_q), dtype=dtype)
    if "sigma_q" in include: out["sigma_q"] = np.zeros((N,H,W,K_q,K_q), dtype=dtype)
    if "phi"     in include: out["phi"]     = np.zeros((N,H,W,agents[0].phi.shape[-1]), dtype=dtype)

    if "mu_p"       in include: out["mu_p"]       = np.zeros((N,H,W,K_p), dtype=dtype)
    if "sigma_p"    in include: out["sigma_p"]    = np.zeros((N,H,W,K_p,K_p), dtype=dtype)
    if "phi_model"  in include: out["phi_model"]  = np.zeros((N,H,W,agents[0].phi_model.shape[-1]), dtype=dtype)

    if "mask"       in include: out["mask"]       = np.zeros((N,H,W), dtype=dtype)

    # Optional alignment / curvature outputs (off by default)
    if compute_alignment:
        out["belief_align"] = np.zeros((N,H,W), dtype=dtype)
        out["model_align"]  = np.zeros((N,H,W), dtype=dtype)
    if compute_curvature:
        out["Fq_norm"] = np.zeros((N,H,W), dtype=dtype)
        out["Fp_norm"] = np.zeros((N,H,W), dtype=dtype)

    # Fill
    for idx, A in enumerate(agents):
        if "mu_q"    in include: out["mu_q"][idx]    = A.mu_q_field
        if "sigma_q" in include:
            _require_spd_field(A.sigma_q_field, K_q, "Σ_q")
            out["sigma_q"][idx] = A.sigma_q_field
        if "phi"     in include: out["phi"][idx]     = A.phi

        if "mu_p"    in include: out["mu_p"][idx]    = A.mu_p_field
        if "sigma_p" in include:
            _require_spd_field(A.sigma_p_field, K_p, "Σ_p")
            out["sigma_p"][idx] = A.sigma_p_field
        if "phi_model" in include: out["phi_model"][idx] = A.phi_model

        if "mask" in include: out["mask"][idx] = A.mask.astype(dtype)

        if compute_alignment:
            # fiber-aware Ω (uses cache or recompute, strict SPD inside)
            out["belief_align"][idx] = compute_alignment_field_general(agents, idx, field_type="belief")
            out["model_align"][idx]  = compute_alignment_field_general(agents, idx, field_type="model")

        if compute_curvature:
            # minimal scalar norm maps for quick visuals
            dx = getattr(config, "dx", 1.0)
            # Resolve generators without boolean short-circuit on arrays
            Gq_attr = getattr(A, "generators_q", None)
            if Gq_attr is None:
                ret = get_generators(config.group_name, K_q)
                Gq = ret[0] if isinstance(ret, (tuple, list)) else ret
            else:
                Gq = Gq_attr
            Gp_attr = getattr(A, "generators_p", None)
            if Gp_attr is None:
                ret = get_generators(config.group_name, K_p)
                Gp = ret[0] if isinstance(ret, (tuple, list)) else ret
            else:
                Gp = Gp_attr
            if isinstance(Gq, dict) and "generators" in Gq: Gq = Gq["generators"]
            if isinstance(Gp, dict) and "generators" in Gp: Gp = Gp["generators"]
            Fq = compute_field_strength(A.phi, generators=Gq, dx=dx)["xy"]          # (H,W,K_q,K_q)
            Fp = compute_field_strength(A.phi_model, generators=Gp, dx=dx)["xy"]    # (H,W,K_p,K_p)
            out["Fq_norm"][idx] = np.linalg.norm(Fq, axis=(-2,-1)).astype(dtype, copy=False)
            out["Fp_norm"][idx] = np.linalg.norm(Fp, axis=(-2,-1)).astype(dtype, copy=False)
   # Save
    Path(outdir).mkdir(parents=True, exist_ok=True)
    
    fname = str(Path(outdir) / f"step{step:05d}.npz")
    np.savez_compressed(fname, **out)
    print(f"[SNAPSHOT] step={step} → {fname}  (schema={schema}, fp16={fp16}, "
          f"align={compute_alignment}, curv={compute_curvature})")
    return fname









#=============================================================================
#
# ------------------------------Helper Utils ------------------------------
#
#=============================================================================

def _as_float32(x):
    return None if x is None else np.asarray(x, dtype=np.float32)

def _safe_symmetrize(S):
    return 0.5 * (S + np.swapaxes(S, -1, -2))

def _apply_linear_morphism(mu, Sigma, L, eps=1e-8):
    """
    Apply y = L x for Gaussian fields:
      μ' = L μ
      Σ' = L Σ L^T

    Args:
        mu    : (..., K_in)
        Sigma : (..., K_in, K_in) SPD (will be sanitized)
        L     : (..., K_out, K_in) linear map (broadcastable to mu/Sigma)
    Returns:
        mu_t  : (..., K_out)
        S_t   : (..., K_out, K_out) SPD (sanitized)
    """
    mu = _as_float32(mu)
    Sigma = _as_float32(Sigma)
    L = _as_float32(L)

    if L is None:
        # identity: out dims == in dims
        return mu, sanitize_sigma(Sigma, eps=eps)

    # μ' = L μ
    mu_t = np.einsum("...oi,...i->...o", L, mu, optimize=True)

    # Σ' = L Σ L^T
    # einsum path keeps batch dims and handles broadcasting
    S_mid = np.einsum("...oi,...ij->...oj", L, Sigma, optimize=True)
    S_t   = np.einsum("...oj,...kj->...ok", S_mid, L, optimize=True)  # (… , K_out, K_out)

    # numerical safety
    S_t = _safe_symmetrize(S_t)
    S_t = sanitize_sigma(S_t, eps=eps)
    return mu_t, S_t


def _masked_overlap(child_mask, parent_mask, thr=1e-3):
    m = (np.asarray(child_mask) > thr) & (np.asarray(parent_mask) > thr)
    return m


def _finite_mean(x):
    x = np.asarray(x, dtype=np.float64)
    x = x[np.isfinite(x)]
    return float(np.mean(x)) if x.size else np.nan



def _require_spd_field(S, K, name="Σ"):
    if S.ndim != 4 or S.shape[-2:] != (K, K):
        raise ValueError(f"{name} must be full SPD (H,W,{K},{K}); got {S.shape}")
    return S

def _require_full_spd_field(S, name="Σ"):
    if S.ndim != 4 or S.shape[-2] != S.shape[-1]:
        raise ValueError(f"{name} must be full SPD with shape (H,W,K,K); got {S.shape}")
    return S

def _prep_fields_for_alignment(agents, *, which="belief", log_eps=1e-8):
    from numerical_utils import sanitize_sigma
    field_list, mask_list = [], []
    for A in agents:
        if which == "belief":
            mu, S = A.mu_q_field, A.sigma_q_field
        else:
            mu, S = A.mu_p_field, A.sigma_p_field
        S_full = _require_full_spd_field(S, name="Σ_field")
        S_full = sanitize_sigma(S_full, eps=log_eps)
        field_list.append((mu, S_full))
        mask_list.append(A.mask)
    return field_list, mask_list


def _support_mask(a, tau=None):
    tau = float(config.support_cutoff_eps if tau is None else tau)
    return (np.asarray(a, np.float32) > tau)

def _support_size(mask): return int(np.sum(mask.astype(np.int64)))

def _sum_over_mask(x, m):
    if x is None: return 0.0
    return float(np.sum(np.where(m, x, 0.0), dtype=np.float64))





def _norm_over_mask(v, m):
    if v is None: return 0.0
    vn = np.linalg.norm(v, axis=-1)
    return _sum_over_mask(vn, m)

def _eig_stats(SIG, mask, eps=0.0):
    H,W,K,_ = SIG.shape
    idx = np.flatnonzero(mask.ravel())
    if idx.size == 0:
        return dict(min_eig=np.nan, max_eig=np.nan, clipped=0, cond=np.nan)
    mats = SIG.reshape(H*W, K, K)[idx]
    # symmetrize + jitter
    I = np.eye(K, dtype=mats.dtype)
    mats = 0.5*(mats + np.swapaxes(mats, -1, -2)) + eps * I
    w = np.linalg.eigvalsh(mats)
    w_min = np.min(w, axis=1)
    w_max = np.max(w, axis=1)
    cond = w_max / np.maximum(w_min, 1e-30)
    return dict(
        min_eig = float(np.nanmin(w_min)),
        max_eig = float(np.nanmax(w_max)),
        cond    = float(np.nanmean(cond)),
        clipped = int(np.sum(w_min < config.sigma_eig_floor) if hasattr(config, "sigma_eig_floor") else 0),
    )


















