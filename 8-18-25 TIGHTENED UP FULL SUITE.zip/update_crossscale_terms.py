

from __future__ import annotations
import numpy as np
import config

# exp/log on the group and their differentials
from omega import d_exp_phi_exact, d_exp_phi_tilde_exact, exp_lie_algebra_irrep

# SPD helpers
from numerical_utils import sanitize_sigma, safe_inv, safe_omega_inv

"""
Cross-scale (child ↔ parent) energy and gradients, gauge-covariant.

- Belief side (q):   Λ = exp(φ_child) · exp(-φ_parent) = E_c · E_p^T
- Model  side (p):  Λ̃ = exp(φ̃_child) · exp(-φ̃_parent) = Ê_c · Ê_p^T

Child gradients are always accumulated.
Parent gradients are accumulated only if child_only=False.

Config knobs (expected in `config.py` or params):
  lambda_xscale_q: float   # strength on belief side
  lambda_xscale_p: float   # strength on model side
  eps: float               # numerical floor for masks / inverses
"""





def _accumulate_xscale_up_core(parent, child, *, bundle, generators,
                               lam=1.0, eps=1e-6, mask_tau=0.30):
    """
    Child → Parent (UP) cross-scale accumulation, gauge-covariant.
    bundle: "q" (belief φ) or "p" (model  φ̃).
    Accumulates into the PARENT's grads (and pushes φ/φ̃ via dexp).
    """
    assert bundle in ("q", "p")

    # --- pick fields for the chosen bundle ---
    if bundle == "q":
        mu_src   = child.mu_q_field.astype(np.float64)
        Sig_src  = child.sigma_q_field.astype(np.float64)
        mu_dst   = parent.mu_q_field.astype(np.float64)
        Sig_dst  = parent.sigma_q_field.astype(np.float64)
        phi_src  = child.phi
        phi_dst  = parent.phi
        d_exp_fn = d_exp_phi_exact           # ∂Ω/∂φ^a
        grad_mu_name = "grad_mu_q_field"
        grad_S_name  = "grad_sigma_q_field"
        grad_phi_name_dst = "grad_phi"
        grad_phi_name_src = "grad_phi"
    else:
        mu_src   = child.mu_p_field.astype(np.float64)
        Sig_src  = child.sigma_p_field.astype(np.float64)
        mu_dst   = parent.mu_p_field.astype(np.float64)
        Sig_dst  = parent.sigma_p_field.astype(np.float64)
        phi_src  = child.phi_model
        phi_dst  = parent.phi_model
        d_exp_fn = d_exp_phi_tilde_exact     # ∂Ω̃/∂φ̃^a
        grad_mu_name = "grad_mu_p_field"
        grad_S_name  = "grad_sigma_p_field"
        grad_phi_name_dst = "grad_phi_tilde"
        grad_phi_name_src = "grad_phi_tilde"

    # --- supports ---
    look = (np.asarray(child.mask, np.float32) > mask_tau) & \
           (np.asarray(parent.mask, np.float32) > mask_tau)
    if not np.any(look):
        return

    # --- relative transport: E_rel = E_dst @ E_src^{-1} ---
    E_src = exp_lie_algebra_irrep(phi_src, generators)
    E_dst = exp_lie_algebra_irrep(phi_dst, generators)         # :contentReference[oaicite:3]{index=3}
    E_src_inv = safe_omega_inv(E_src)
    E_rel = E_dst @ E_src_inv

    # push child stats to parent frame
    mu_hat = (E_rel @ mu_src[..., None])[..., 0]
    S_hat  = E_rel @ Sig_src @ np.swapaxes(E_rel, -1, -2)

    # parent precision (SPD-safe)
    Prec_dst = safe_inv(Sig_dst, eps=max(eps, 1e-10))

    # quadratic form (same structure as downscale; just roles swapped)
    diff = (mu_hat - mu_dst)
    outer = diff[..., None] @ diff[..., None].swapaxes(-1, -2)

    # grads wrt μ_dst and Σ_dst
    g_mu_dst = -2.0 * lam * (Prec_dst @ diff[..., None])[..., 0]
    A = S_hat + outer
    g_S_dst  = lam * (-Prec_dst @ A @ Prec_dst + Prec_dst)

    # accumulate on parent (destination)
    for name, arr in ((grad_mu_name, g_mu_dst), (grad_S_name, g_S_dst)):
        buf = getattr(parent, name, None)
        if buf is None: buf = np.zeros_like(arr, dtype=arr.dtype)
        buf[look] += arr[look]
        setattr(parent, name, buf)

    # ---- matrix gradient for φ on dst & src via product rule ----
    # Build a per-pixel matrix gradient G for E_rel
    K = mu_src.shape[-1]
    I = np.eye(K, dtype=np.float64)

    term_mu = (Prec_dst @ diff[..., None]) @ mu_src[..., None, :]          # (H,W,K,K)
    PS = Prec_dst @ S_hat
    term_S = 0.5 * (PS - I)
    E_rel_inv_T = np.swapaxes(safe_omega_inv(E_rel), -1, -2)
    G = lam * (term_mu + term_S @ E_rel_inv_T)                              # (H,W,K,K)

    # split to dst/src using E_rel = E_dst · E_src^{-1}
    E_dst_inv = safe_omega_inv(E_dst)
    E_src_inv_T = np.swapaxes(E_src_inv, -1, -2)
    G_dst = G
    G_src = -(E_dst_inv @ G @ E_src_inv_T)

    # map matrix-grad → φ-grad with your exact dexp:
    # ∂L/∂φ^a = ⟨G_part, ∂E/∂φ^a⟩_F
    dE_dst = d_exp_fn(phi_dst, generators, exp_phi_tilde_all=E_dst if bundle=="p" else E_dst)  # list len d  # :contentReference[oaicite:4]{index=4}
    dE_src = d_exp_fn(phi_src, generators, exp_phi_tilde_all=E_src if bundle=="p" else E_src)  # list len d  # :contentReference[oaicite:5]{index=5}

    def _accum_phi(agent, name, Gpart, dE_list):
        d = len(dE_list)
        gphi = getattr(agent, name, None)
        if gphi is None: gphi = np.zeros_like(agent.phi if "tilde" not in name else agent.phi_model)
        for a in range(d):
            # trace Frobenius inner product per-pixel
            contrib = np.einsum("...ij,...ij->...", Gpart, dE_list[a])
            gphi[..., a][look] += contrib[look]
        setattr(agent, name, gphi)

    _accum_phi(parent, grad_phi_name_dst, G_dst, dE_dst)
    _accum_phi(child,  grad_phi_name_src, G_src, dE_src)




def accumulate_xscale_q_up_gaugecovNEW(parent, child, generators_q, lam_q: float, eps=1e-6, mask_tau=0.30):
    _accumulate_xscale_up_core(parent, child, bundle="q", generators=generators_q,
                               lam=float(lam_q), eps=eps, mask_tau=mask_tau)

def accumulate_xscale_p_up_gaugecovNEW(parent, child, generators_p, lam_p: float, eps=1e-6, mask_tau=0.30):
    _accumulate_xscale_up_core(parent, child, bundle="p", generators=generators_p,
                               lam=float(lam_p), eps=eps, mask_tau=mask_tau)







def accumulate_crossscale_gradients(agent_i, all_agents, generators_q, generators_p, params):
    """Accumulate child↔parent cross-scale gradients.
    - Accepts either `agent_i.parent_ids` or a single `agent_i.parent_id`.
    - If `params['xscale_child_only']` is False, also write gradients into the parent.
    - Performs a robust mask-overlap check before doing any heavy math.
    """
    lam_x_q = params.get("lambda_xscale_q", getattr(config, "lambda_xscale_q", 0.0))
    lam_x_p = params.get("lambda_xscale_p", getattr(config, "lambda_xscale_p", 0.0))
    eps     = getattr(config, "eps", 1e-6)
    child_only = params.get("xscale_child_only", True)
    mask_tau = params.get("xscale_mask_tau", 1e-3)

    # Build id -> agent map once
    id2A = {int(A.id): A for A in all_agents}
    kl_out = {"kl_q": [], "kl_p": []}

    # Accept parent_ids OR parent_id
    pids = getattr(agent_i, "parent_ids", None)
    if not pids:
        pid = int(getattr(agent_i, "parent_id", -1))
        pids = [pid] if pid >= 0 else []
    if not pids:
        return kl_out

    # Normalize per-child weight if multiple parents
    n_parents = max(1, len(pids))

    # Child mask (float32); allow scalar fallback
    m_c = np.asarray(getattr(agent_i, "mask", 0.0), dtype=np.float32)

    for pid in pids:
        parent = id2A.get(int(pid))
    
        if parent is None:
            continue

        # Parent mask; require same shape for now
        m_p = np.asarray(getattr(parent, "mask", 0.0), dtype=np.float32)
        if m_c.shape != m_p.shape:
            # TODO: resample parent mask to child grid if you support multi-res
            continue
        overlap = (m_c > mask_tau) & (m_p > mask_tau)
        if not np.any(overlap):
            continue

        # per-parent ramped weights (normalized by number of parents)
        eff_lam_q = float(getattr(parent, "lambda_q_weight", lam_x_q)) / n_parents
        eff_lam_p = float(getattr(parent, "lambda_p_weight", lam_x_p)) / n_parents

        
        age   = int(getattr(parent, "_age", 0))
        grace = int(getattr(parent, "_grace", params.get("parent_freeze_steps", 0)))
        ramp  = int(params.get("parent_ramp_steps", 10))
        
        if age < grace:
            ramp_factor = 0.0
        else:
            ramp_factor = min(1.0, (age - grace + 1) / max(1, ramp))
        
        eff_lam_q *= ramp_factor
        eff_lam_p *= ramp_factor


        if eff_lam_q > 0.0 and agent_i.mu_q_field.shape[-1] == parent.mu_q_field.shape[-1]:
            kl_q = accumulate_xscale_q_dn_gaugecov(
                child=agent_i, parent=parent, generators_q=generators_q,
                lam_q=eff_lam_q, eps=eps, child_only=child_only
            )
            if not (np.isnan(kl_q) or np.isinf(kl_q)):
                kl_out["kl_q"].append(kl_q)

        if eff_lam_p > 0.0 and agent_i.mu_p_field.shape[-1] == parent.mu_p_field.shape[-1]:
            kl_p = accumulate_xscale_p_dn_gaugecov(
                child=agent_i, parent=parent, generators_p=generators_p,
                lam_p=eff_lam_p, eps=eps, child_only=child_only
            )
            if not (np.isnan(kl_p) or np.isinf(kl_p)):
                kl_out["kl_p"].append(kl_p)

    return kl_out




def accumulate_xscale_q_dn_gaugecov(
    child, parent, generators_q, lam_q: float, eps: float = 1e-6,
    use_cached_exp: bool = True, child_only: bool = True,
) -> float:
    """
    Cross-scale belief KL with gauge-covariant Λ. Returns masked-mean KL (float).
    """
    if lam_q <= 0.0:
        return 0.0

    # --- exp(φ) caches (child & parent) ---
    if use_cached_exp and getattr(child, "_exp_phi", None) is not None:
        E_c = child._exp_phi
    else:
        E_c = exp_lie_algebra_irrep(child.phi, generators_q)
        child._exp_phi = E_c

    if use_cached_exp and getattr(parent, "_exp_phi", None) is not None:
        E_p = parent._exp_phi
    else:
        E_p = exp_lie_algebra_irrep(parent.phi, generators_q)
        parent._exp_phi = E_p

    E_p_T = np.swapaxes(E_p, -1, -2)
    Lambda = np.einsum("...ik,...kj->...ij", E_c, E_p_T)  # (...,Kq,Kq)

    # --- fields ---
    muP = parent.mu_q_field
    SP  = sanitize_sigma(parent.sigma_q_field, eps=eps)
    mu  = child.mu_q_field
    S   = sanitize_sigma(child.sigma_q_field, eps=eps)

    # --- push down parent to child frame ---
    mu_t = np.einsum("...ij,...j->...i", Lambda, muP)
    S_t  = np.einsum("...ik,...kl,...jl->...ij", Lambda, SP, Lambda)
    S_t  = sanitize_sigma(_sym(S_t), eps=eps)

    S_t_inv = safe_inv(S_t, eps=eps)
    S_inv   = safe_inv(S,   eps=eps)

    # --- masks ---
    m, m1, m4 = _masked_bools(child, parent, eps)

    # --- child μ, Σ grads ---
    g_mu_child = (S_t_inv @ (mu - mu_t)[..., None])[..., 0]
    g_S_child  = _sym(0.5 * (S_t_inv - S_inv))

    if getattr(child, "grad_mu_q", None) is None:
        child.grad_mu_q = np.zeros_like(mu)
    if getattr(child, "grad_sigma_q", None) is None:
        child.grad_sigma_q = np.zeros_like(S)

    child.grad_mu_q    += lam_q * g_mu_child * m1
    child.grad_sigma_q += lam_q * g_S_child  * m4

    # --- shared helpers for Λ backprop ---
    dmu    = (mu - mu_t)
    dmu_t  = - (S_t_inv @ dmu[..., None])[..., 0]      # ∂KL/∂μ_t
    outer  = dmu[..., None] @ np.swapaxes(dmu[..., None], -1, -2)
    dKL_dA = 0.5 * (S + outer - S_t)
    dS_t   = _sym(- np.einsum("...ik,...kl,...lj->...ij", S_t_inv, dKL_dA, S_t_inv))

    # --- φ grads: child always; parent only if enabled ---
    term_mean = dmu_t[..., None] @ muP[..., None, :]
    term_cov  = 2.0 * np.einsum("...ij,...jk,...kl->...il", dS_t, Lambda, SP)
    GΛ = (term_mean + term_cov) * m4  # (...,K,K)

    T_child   = np.einsum("...ij,...jk->...ik", GΛ, E_p)
    D_child   = d_exp_phi_exact(child.phi, generators_q, exp_phi_all=E_c)  # list of 3 (...,K,K)
    g_phi_ch  = np.stack([np.einsum("...ij,...ij->...", T_child, D_child[a])
                          for a in range(3)], axis=-1) * m1  # (...,3)

    if getattr(child, "grad_phi", None) is None:
        child.grad_phi = np.zeros_like(child.phi)
    child.grad_phi += lam_q * g_phi_ch

    if not child_only:
        T_parent  = - np.einsum("...ij,...jk,...kl->...il", np.swapaxes(Lambda, -1, -2), GΛ, E_p)
        D_parent  = d_exp_phi_exact(parent.phi, generators_q, exp_phi_all=E_p)
        g_phi_pa  = np.stack([np.einsum("...ij,...ij->...", T_parent, D_parent[a])
                              for a in range(3)], axis=-1) * m1
        if getattr(parent, "grad_phi", None) is None:
            parent.grad_phi = np.zeros_like(parent.phi)
        parent.grad_phi += lam_q * g_phi_pa

        # parent μ, Σ grads
        g_muP = (np.swapaxes(Lambda, -1, -2) @ dmu_t[..., None])[..., 0]
        g_SP  = _sym(np.einsum("...ik,...kl,...jl->...ij",
                               np.swapaxes(Lambda, -1, -2), dS_t, Lambda))
        if getattr(parent, "grad_mu_q", None) is None:
            parent.grad_mu_q = np.zeros_like(muP)
        if getattr(parent, "grad_sigma_q", None) is None:
            parent.grad_sigma_q = np.zeros_like(SP)
        parent.grad_mu_q    += lam_q * g_muP * m1
        parent.grad_sigma_q += lam_q * g_SP  * m4

    # --- scalar KL (masked mean) ---
    diff = (mu_t - mu)[..., None]
    quad = (np.swapaxes(diff, -1, -2) @ S_t_inv @ diff)[..., 0, 0]
    tr_term = np.einsum("...ij,...ji->...", S_t_inv, S)
    sign_t, logdet_t = np.linalg.slogdet(S_t)
    sign_c, logdet_c = np.linalg.slogdet(S)
    logdet_t = np.where(sign_t > 0, logdet_t, np.nan)
    logdet_c = np.where(sign_c > 0, logdet_c, np.nan)
    kl_point = 0.5 * (tr_term + quad - S.shape[-1] + (logdet_t - logdet_c))

    valid = np.isfinite(kl_point) & m
    return float(np.nanmean(kl_point[valid])) if np.any(valid) else 0.0


def accumulate_xscale_p_dn_gaugecov(
    child, parent, generators_p, lam_p: float, eps: float = 1e-6,
    use_cached_exp: bool = True, child_only: bool = True,
) -> float:
    """
    Cross-scale model KL with gauge-covariant Λ̃. Returns masked-mean KL (float).
    """
    if lam_p <= 0.0:
        return 0.0

    # --- exp(φ̃) caches (child & parent) ---
    if use_cached_exp and getattr(child, "_exp_phi_model", None) is not None:
        Ec = child._exp_phi_model
    else:
        Ec = exp_lie_algebra_irrep(child.phi_model, generators_p)
        child._exp_phi_model = Ec

    if use_cached_exp and getattr(parent, "_exp_phi_model", None) is not None:
        Ep = parent._exp_phi_model
    else:
        Ep = exp_lie_algebra_irrep(parent.phi_model, generators_p)
        parent._exp_phi_model = Ep

    Ep_T  = np.swapaxes(Ep, -1, -2)
    Lambda = np.einsum("...ik,...kj->...ij", Ec, Ep_T)  # (...,Kp,Kp)

    # --- fields (model side) ---
    muP = parent.mu_p_field
    SP  = sanitize_sigma(parent.sigma_p_field, eps=eps)
    mu  = child.mu_p_field
    S   = sanitize_sigma(child.sigma_p_field, eps=eps)

    # --- push down parent to child frame ---
    mu_t = np.einsum("...ij,...j->...i", Lambda, muP)
    S_t  = np.einsum("...ik,...kl,...jl->...ij", Lambda, SP, Lambda)
    S_t  = sanitize_sigma(_sym(S_t), eps=eps)

    S_t_inv = safe_inv(S_t, eps=eps)
    S_inv   = safe_inv(S,   eps=eps)

    # --- masks ---
    m, m1, m4 = _masked_bools(child, parent, eps)

    # --- child μ, Σ grads (model side) ---
    g_mu_child = (S_t_inv @ (mu - mu_t)[..., None])[..., 0]
    g_S_child  = _sym(0.5 * (S_t_inv - S_inv))

    if getattr(child, "grad_mu_p", None) is None:
        child.grad_mu_p = np.zeros_like(mu)
    if getattr(child, "grad_sigma_p", None) is None:
        child.grad_sigma_p = np.zeros_like(S)

    child.grad_mu_p    += lam_p * g_mu_child * m1
    child.grad_sigma_p += lam_p * g_S_child  * m4

    # --- φ̃ grads (model gauge): child always; parent only if enabled ---
    dmu    = (mu - mu_t)
    dmu_t  = - (S_t_inv @ dmu[..., None])[..., 0]
    outer  = dmu[..., None] @ np.swapaxes(dmu[..., None], -1, -2)
    dKL_dA = 0.5 * (S + outer - S_t)
    dS_t   = _sym(- np.einsum("...ik,...kl,...lj->...ij", S_t_inv, dKL_dA, S_t_inv))

    term_mean = dmu_t[..., None] @ muP[..., None, :]
    term_cov  = 2.0 * np.einsum("...ij,...jk,...kl->...il", dS_t, Lambda, SP)
    GΛ = (term_mean + term_cov) * m4

    T_child    = np.einsum("...ij,...jk->...ik", GΛ, Ep)
    D_child    = d_exp_phi_exact(child.phi_model, generators_p, exp_phi_all=Ec)
    g_phi_m_ch = np.stack([np.einsum("...ij,...ij->...", T_child, D_child[a])
                           for a in range(3)], axis=-1) * m1

    if getattr(child, "grad_phi_tilde", None) is None:
        child.grad_phi_tilde = np.zeros_like(child.phi_model)
    child.grad_phi_tilde += lam_p * g_phi_m_ch

    if not child_only:
        T_parent   = - np.einsum("...ij,...jk,...kl->...il",
                                 np.swapaxes(Lambda, -1, -2), GΛ, Ep)
        D_parent   = d_exp_phi_exact(parent.phi_model, generators_p, exp_phi_all=Ep)
        g_phi_m_pa = np.stack([np.einsum("...ij,...ij->...", T_parent, D_parent[a])
                               for a in range(3)], axis=-1) * m1
        if getattr(parent, "grad_phi_tilde", None) is None:
            parent.grad_phi_tilde = np.zeros_like(parent.phi_model)
        parent.grad_phi_tilde += lam_p * g_phi_m_pa

        g_muP = (np.swapaxes(Lambda, -1, -2) @ dmu_t[..., None])[..., 0]
        g_SP  = _sym(np.einsum("...ik,...kl,...jl->...ij",
                               np.swapaxes(Lambda, -1, -2), dS_t, Lambda))
        if getattr(parent, "grad_mu_p", None) is None:
            parent.grad_mu_p = np.zeros_like(muP)
        if getattr(parent, "grad_sigma_p", None) is None:
            parent.grad_sigma_p = np.zeros_like(SP)
        parent.grad_mu_p    += lam_p * g_muP * m1
        parent.grad_sigma_p += lam_p * g_SP  * m4

    # --- scalar KL (masked mean) ---
    diff = (mu_t - mu)[..., None]
    quad = (np.swapaxes(diff, -1, -2) @ S_t_inv @ diff)[..., 0, 0]
    tr_term = np.einsum("...ij,...ji->...", S_t_inv, S)
    sign_t, logdet_t = np.linalg.slogdet(S_t)
    sign_c, logdet_c = np.linalg.slogdet(S)
    logdet_t = np.where(sign_t > 0, logdet_t, np.nan)
    logdet_c = np.where(sign_c > 0, logdet_c, np.nan)
    kl_point = 0.5 * (tr_term + quad - S.shape[-1] + (logdet_t - logdet_c))

    valid = np.isfinite(kl_point) & m
    return float(np.nanmean(kl_point[valid])) if np.any(valid) else 0.0




def _sym(A):
    return 0.5 * (A + np.swapaxes(A, -1, -2))


def _masked_bools(child, parent, eps):
    H, W = child.mu_q_field.shape[-3], child.mu_q_field.shape[-2]
    m = ((np.asarray(child.mask) > eps) & (np.asarray(parent.mask) > eps))
    m = np.broadcast_to(np.asarray(m, dtype=bool), (H, W))
    m1 = m[..., None].astype(child.mu_q_field.dtype)
    m4 = m[..., None, None].astype(child.mu_q_field.dtype)
    return m, m1, m4
