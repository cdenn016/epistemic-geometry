# -*- coding: utf-8 -*-
"""
Created on Thu Aug 14 09:17:47 2025

@author: chris and christine
"""

import numpy as np
import config                        
from bundle_morphism_utils import (init_parent_morphisms, have_parent_morphisms, compute_direct_morphisms)
from agent_initialization import initialize_agent_gradients
from bundle_coarsegrain_init import coarsegrain_parent_from_children
from parent_utils import (norm_active_regions, dedup_peaks_by_childset, spawn_spacing_radius )
from gaussian_core import ( _prep_A, _overlap_pairs, directed_kl_weight_after_transport,apply_evidence_modulators,
    curvature_boltzmann_from_children )



def _apply_spawn_from_regions(ctx, active_regions, agents, Gq, Gp, params):
    """
    The ONLY place that mutates parents:
      - spawn/update parents for active regions (PIXELWISE proposals path)
      - coarse-grain new/updated parents (μ, Σ) — only for those changed
    No preprocess()/omega/lambda cache builds here.
    """
    import numpy as np, config

    if not agents:
        return []

    H, W = np.asarray(agents[0].mask, np.float32).shape[:2]

    # ensure registry exists as a dict
    if not hasattr(ctx, "parents_by_region") or ctx.parents_by_region is None:
        ctx.parents_by_region = {}
    existing = ctx.parents_by_region
    if not isinstance(existing, dict):
        d = {}
        for P in (existing or []):
            pid = int(getattr(P, "id", len(d)))
            d[pid] = P
        existing = ctx.parents_by_region = d

    if not hasattr(ctx, "next_parent_id"):
        ctx.next_parent_id = 0
    next_parent_id = int(ctx.next_parent_id)

    prev_ids = set(existing.keys())

    # ---------------- PRE-FILTER: evidence + novelty/NMS ----------------
    regions_to_spawn = list(active_regions or [])

    # cover>=2 map (child_support_tau)
    cover2 = None
    try:
        tau_sup = float(getattr(config, "child_support_tau", 0.08))
        Ms = np.stack([(np.asarray(ch.mask, np.float32) >= tau_sup).astype(np.uint8) for ch in agents], axis=0)
        cover2 = (Ms.sum(0) >= 2)
    except Exception:
        cover2 = None

    spawn_min_cover2_px = int(getattr(config, "spawn_min_cover2_px", 2))
    spawn_nms_iou       = float(getattr(config, "spawn_nms_iou", 0.25))
    spawn_min_dist_px   = float(getattr(config, "spawn_min_dist_px", 2.0))

    # cores of existing parents (use same core semantics as assignment)
    abs_core = float(getattr(config, "parent_growth_core_tau", 0.20))
    rel_core = float(getattr(config, "parent_assign_core_tau_rel", 0.50))
    existing_cores = []
    for P in existing.values():
        pm = np.asarray(getattr(P, "mask", 0.0), np.float32)
        mmax = float(pm.max()) if pm.size else 0.0
        thr  = max(abs_core, rel_core * mmax)
        existing_cores.append(pm > thr)

    def _iou_bool(a, b):
        a = np.asarray(a, bool); b = np.asarray(b, bool)
        if not a.any() and not b.any(): return 0.0
        inter = int((a & b).sum()); union = int(a.sum() + b.sum() - inter)
        return inter / max(1, union)

    def _centroid(mbool):
        yyx = np.argwhere(np.asarray(mbool, bool))
        if yyx.size == 0: return None
        yx = yyx.mean(0)
        return float(yx[0]), float(yx[1])

    filtered = []
    for R in regions_to_spawn:
        m = np.asarray(getattr(R, "mask", 0.0), np.float32) > 0.0
        if not m.any():
            continue

        # (1) evidence: must include some ≥2-child pixels
        if isinstance(cover2, np.ndarray):
            if int((m & cover2).sum()) < spawn_min_cover2_px:
                continue

        # (2) novelty: NMS IoU + centroid separation vs existing cores
        cyx = _centroid(m)
        novel = True
        for ec in existing_cores:
            if not np.asarray(ec).any():
                continue
            if _iou_bool(m, ec) >= spawn_nms_iou:
                novel = False; break
            if cyx is not None:
                c0 = _centroid(ec)
                if c0 is not None:
                    if (abs(cyx[0] - c0[0]) + abs(cyx[1] - c0[1])) < spawn_min_dist_px:
                        novel = False; break
        if not novel:
            continue

        filtered.append(R)

    regions_to_spawn = filtered

    # ---- spawn/update using ONLY in-scope args (no globals) -----------------
    parents_changed, next_pid = spawn_or_update_parents(
        regions_to_spawn, agents, existing, next_parent_id,
        field_generators=(Gq, Gp),
        agree_map=(getattr(ctx, "Aq_agg", None), getattr(ctx, "Ap_agg", None)),
    )

    # normalize to dict (callee may return list)
    def _as_parent_dict(pars):
        if isinstance(pars, dict):
            return pars
        d = {}
        for P in (pars or []):
            pid = int(getattr(P, "id", len(d)))
            d[pid] = P
        return d

    parents_changed = _as_parent_dict(parents_changed)

    # merge into registry + init bookkeeping
    for pid, P in parents_changed.items():
        existing[int(getattr(P, "id", pid))] = P
        # seed/freeze bookkeeping
        pm = np.asarray(getattr(P, "mask", 0.0), np.float32)
        P.seed_mask = pm.copy()
        if not hasattr(P, "_age"):   P._age = 0
        # born/freeze
        step_now = int(getattr(ctx, "global_step", 0))
        freeze_steps = int(getattr(config, "parent_freeze_steps", 3))
        P._born_step  = step_now
        P.freeze_until = step_now + freeze_steps
        if not hasattr(P, "_grace"): P._grace = freeze_steps

    # --------- coarse-grain ONLY changed/new parents (μ, Σ) -----------------
    for pid, P in parents_changed.items():
        try:
            cg_eps = float(getattr(config, "cg_eps", 1e-6))
            cg_tau = float(getattr(config, "parent_cover_support_eps", 0.30))
            coarsegrain_parent_from_children(P, agents, eps=cg_eps, mask_tau=cg_tau)
            if getattr(config, "debug_strict", True):
                for name in ("sigma_q_field", "sigma_p_field"):
                    S = getattr(P, name, None)
                    if S is None:
                        continue
                    S = np.asarray(S)
                    assert S.ndim == 4 and S.shape[-1] == S.shape[-2], \
                        f"[CG->ASSIGN] {name} bad shape {S.shape} for parent {getattr(P,'id','?')}"
        except Exception as e:
            print(f"[WARN] coarsegrain/init failed for parent {getattr(P,'id','?')}: {e}")
            if getattr(config, "debug_parent_masks", False):
                print("  parent.mask", np.asarray(getattr(P, 'mask', None)).shape)
                print("  child0.mask", np.asarray(agents[0].mask).shape)

    # registry bookkeeping
    ctx.parents_by_region = existing
    ctx.next_parent_id = max(
        int(ctx.next_parent_id),
        int(next_pid),
        (max(existing.keys()) + 1) if existing else 1,
    )

    # visibility: log newborns
    new_ids = sorted(set(existing.keys()) - prev_ids)
    if new_ids:
        areas = [int((np.asarray(existing[i].mask) > 0.5).sum()) for i in new_ids]
        print(f"[SPAWN] +{len(new_ids)} (detector): ids={new_ids} areas={areas}")

    # return newborn objects so caller can mark them dirty
    return [ctx.parents_by_region[i] for i in new_ids]


def spawn_or_update_parents(active_regions,
                            agents,
                            parents_by_id,
                            next_parent_id,
                            *,
                            field_generators,
                            agree_map=None):   # may be None, a single map, (Aq,Ap), or {"q":Aq,"p":Ap}
    """
    Build pixelwise proposals (dual-fiber, directed-KL only), restrict to active regions,
    dedup, then match/spawn. Returns (list(parents_by_id.values()), next_parent_id).

    Cache policy:
      - Build child→child Ω caches once here (cheap einsums) before proposals.
      - proposals_from_dual_fibers is encouraged to consume Ω or exp(φ) caches if present.
      - Restrict heavy work to the active-region union domain when possible.
    """
    import numpy as np, config

    if not agents:
        return list(parents_by_id.values()), next_parent_id

    H, W = np.asarray(agents[0].mask, np.float32).shape[:2]
    dtype = agents[0].mu_q_field.dtype
    Kq   = int(agents[0].mu_q_field.shape[-1])
    Kp   = int(agents[0].mu_p_field.shape[-1])
    Gq, Gp = field_generators

    # --- normalize detector regions → union mask to restrict spawn area -----
    region_masks = norm_active_regions(active_regions, (H, W))
    region_or = None
    if region_masks:
        region_or = np.zeros((H, W), np.float32)
        for R in region_masks:
            region_or = np.maximum(region_or, np.asarray(R, np.float32))
        region_or = (region_or > 0.5)

    # --- parse agree_map and combine Aq/Ap with geometric blend -------------
    Aq = Ap = None
    if agree_map is not None:
        if isinstance(agree_map, (tuple, list)) and len(agree_map) >= 1:
            Aq = agree_map[0]
            if len(agree_map) >= 2:
                Ap = agree_map[1]
        elif isinstance(agree_map, dict):
            Aq = agree_map.get("q")
            Ap = agree_map.get("p")
        else:
            Aq = agree_map  # single map → use as-is

    alpha = float(getattr(config, "blend_qp_alpha", 0.50))
    A = None
    if (Aq is not None) or (Ap is not None):
        def _prep_A(a, H, W):
            if a is None: return None
            a = np.asarray(a, np.float32)
            if a.shape != (H, W):
                # light NN-ish resize w/o deps
                if a.shape[0] >= H and a.shape[1] >= W:
                    a = a[:H, :W]
                else:
                    py, px = max(0, H - a.shape[0]), max(0, W - a.shape[1])
                    a = np.pad(a, ((0, py), (0, px)), mode="edge")[:H, :W]
            return np.clip(a, 0.0, 1.0).astype(np.float32, copy=False)

        Aq_ = _prep_A(Aq, H, W) if Aq is not None else None
        Ap_ = _prep_A(Ap, H, W) if Ap is not None else None
        if (Aq_ is not None) and (Ap_ is not None):
            eps = 1e-12
            A = np.exp((1.0 - alpha) * np.log(np.maximum(Aq_, eps)) +
                       alpha * np.log(np.maximum(Ap_, eps)))
        else:
            A = Aq_ if Aq_ is not None else Ap_

    # --- ensure child→child Ω caches exist (cheap; uses exp(φ) fields) ------
    try:
        from update_rules_utils import build_all_omega_caches
        build_all_omega_caches(agents, strict=False, debug=False)
    except Exception:
        # best-effort; proposals can still fall back to exp(φ) per-pixel if needed
        pass

    # --- dual-fiber, directed-KL proposals (cache-friendly path) ------------
    # Prefer to pass domain mask to reduce work. If proposals fn doesn't accept it, fall back.
    proposals = None
    kwargs = dict(
        mask_tau=float(getattr(config, "child_support_tau", 0.10)),
        tau_q=float(getattr(config, "tau_align_q", 0.30)),
        tau_p=float(getattr(config, "tau_align_p", 0.30)),
        alpha=alpha,
        min_pair_px=int(getattr(config, "pxspawn_min_pair_px", 4)),
        agree_map=A,
        agree_power=float(getattr(config, "pxspawn_agree_power", 1.0)),
        min_component_px=int(getattr(config, "parent_min_area", 10)),
        smooth_sigma=float(getattr(config, "pxspawn_smooth_sigma", 0.0)),
        per_pixel_norm=bool(getattr(config, "pxspawn_per_pixel_norm", False)),
        debug=bool(getattr(config, "debug_spawn_log", False)),
        # cache hints (ignored if function doesn't support them):
        use_cached_omega=True,
        domain_mask=region_or,   # restrict computations to active domain
    )
    try:
        proposals = proposals_from_dual_fibers(agents, H, W, **kwargs)
    except TypeError:
        # older signature: retry without the new kwargs
        kwargs.pop("use_cached_omega", None)
        kwargs.pop("domain_mask", None)
        proposals = proposals_from_dual_fibers(agents, H, W, **kwargs)

    # --- restrict proposals to active regions (safety, even if domain_mask used)
    if region_or is not None and proposals:
        rim = region_or.astype(np.float32)
        for p in proposals:
            m = np.asarray(p["mask"], np.float32) * rim
            p["mask"] = np.clip(m, 0.0, 1.0)

    # --- dedup near-identical child sets / spatial near-dupes ----------------
    if proposals:
        try:
            proposals = dedup_peaks_by_childset(
                proposals,
                radius_px=int(getattr(config, "parent_peak_dedup_radius_px", 3)),
                j_thr=float(getattr(config, "parent_peak_dedup_child_jaccard", 0.92)),
                subset_thr=float(getattr(config, "parent_peak_dedup_subset_thr", 0.90)),
                H=H, W=W,
                per_x=bool(getattr(config, "periodic_x", False)),
                per_y=bool(getattr(config, "periodic_y", False)),
            )
        except Exception:
            pass

    if not proposals and not parents_by_id:
        return list(parents_by_id.values()), next_parent_id

    # --- shim proposals → legacy "peaks" (matcher expects 'proposal') --------
    peaks = []
    for p in (proposals or []):
        q = dict(p)
        if "proposal" not in q and "mask" in q:
            q["proposal"] = np.asarray(q["mask"], np.float32)
        peaks.append(q)

    # --- match or spawn ------------------------------------------------------
    allow_overlap = True
    min_interseed_px = spawn_spacing_radius(
        allow_overlap, int(getattr(config, "parent_min_interseed_px", 1))
    )
    next_parent_id = _match_or_spawn(
        peaks, parents_by_id, next_parent_id, agents,
        (H, W, dtype, Kq, Kp), field_generators,
        match_iou_thr=float(getattr(config, "parent_match_iou_existing", 0.10)),
        child_jac_thr=float(getattr(config, "parent_match_child_jaccard_thr", 0.85)),
        support_tau=float(getattr(config, "parent_support_tau", 0.08)),
        max_new_per_step=int(getattr(config, "parent_max_new_per_step", 50)),
        min_interseed_px=min_interseed_px,
    )

    # --- ensure morphisms (parents must have φ/φ̃ generators) ----------------
    for P in parents_by_id.values():
        if not have_parent_morphisms(P):
            init_parent_morphisms(P, generators_q=Gq, generators_p=Gp)

    return list(parents_by_id.values()), next_parent_id



def proposals_from_dual_fibers(children, H, W, *,
                               mask_tau=0.10,
                               tau_q=0.30,
                               tau_p=0.30,
                               alpha=0.5,
                               min_pair_px=8,
                               agree_map=None,
                               agree_power=1.0,
                               min_component_px=20,
                               smooth_sigma=0.0,
                               per_pixel_norm=False,
                               debug=False,
                               # optional hints; safely ignored by callers that don't set them
                               use_cached_omega=True,
                               domain_mask=None):
    """
    Gauge-covariant proposals using ONLY directed KL after transport:
      d_q = KL( N_i(q) || N_j^T(q) ),  d_p = KL( N_i(p) || N_j^T(p) )
      w   = exp(-d_q/tau_q)^(1-alpha) * exp(-d_p/tau_p)^alpha
      E(x)= Σ_{(i,j)} m_i m_j  w  1_{overlap}

    Cache policy is delegated to directed_kl_weight_after_transport (Ω/exp caches first).
    """
    import numpy as _np
    try:
        import config as _cfg
    except Exception:
        class _C: pass
        _cfg = _C()

    if not children:
        return []

    # collect per-child fields
    M   = [_np.asarray(getattr(c, "mask", 0.0), _np.float32) for c in children]
    muq = [_np.asarray(c.mu_q_field, _np.float32) for c in children]
    Sq  = [_np.asarray(c.sigma_q_field, _np.float32) for c in children]
    mup = [_np.asarray(c.mu_p_field, _np.float32) for c in children]
    Sp  = [_np.asarray(c.sigma_p_field, _np.float32) for c in children]
    Kq  = muq[0].shape[-1]
    Kp  = mup[0].shape[-1]

    # pairs by overlap at mask_tau
    pairs = _overlap_pairs(children, H, W, tau=mask_tau, min_pair_px=min_pair_px)
    if not pairs:
        return []

    # spatial priors
    A  = _prep_A(agree_map, H, W)
    BF = curvature_boltzmann_from_children(
        children, H, W,
        gamma=float(getattr(_cfg, "curvature_gamma", 0.0)),
        fiber=str(getattr(_cfg, "curvature_fiber", "q")),
        curvature_map=getattr(_cfg, "curvature_map", None) if hasattr(_cfg, "curvature_map") else None,
    )

    # domain: (optional) detector mask ∧ (cover≥2) — avoid useless work early
    cover2 = _np.zeros((H, W), _np.int16)
    for m in M:
        cover2 += (m >= float(mask_tau)).astype(_np.int16)
    D = (cover2 >= 2)
    if domain_mask is not None:
        D = D & _np.asarray(domain_mask, bool)

    E = _np.zeros((H, W), _np.float32)
    pair_contribs = []

    t_q = max(1e-6, float(tau_q))
    t_p = max(1e-6, float(tau_p))
    a   = float(alpha)

    # ------------------- main pair loop (cache-first via directed_kl_*) -------------------
   
    for (i, j, ov_raw) in pairs:
        if not ov_raw.any():
            continue
        Ai, Aj = children[i], children[j]
        # restrict to domain
        ov = ov_raw & D
        if not ov.any():
            continue

        # directed KL weights after transport on each fiber (cache-first inside the callee)
        wq = directed_kl_weight_after_transport(
            Ai, Aj, muq[i], Sq[i], muq[j], Sq[j],
            fiber="q", H=H, W=W, K=Kq, ov=ov, tau=t_q,
            use_cached_omega=use_cached_omega
        )
        wp = directed_kl_weight_after_transport(
            Ai, Aj, mup[i], Sp[i], mup[j], Sp[j],
            fiber="p", H=H, W=W, K=Kp, ov=ov, tau=t_p,
            use_cached_omega=use_cached_omega
        )

        # α weights the MODEL (p) fiber
        w = (wq ** (1.0 - a)) * (wp ** a)
        w = _np.nan_to_num(w, nan=0.0, posinf=0.0, neginf=0.0)
        w *= ov.astype(_np.float32)

        # apply spatial prior / curvature (cannot create support)
        wij = apply_evidence_modulators(w, M[i], M[j], ov, A=A, agree_power=agree_power, BF=BF)
        if float(wij.max()) <= 0.0:
            continue

        E += wij
        pair_contribs.append((i, j, wij))

    # enforce multi-child domain & exit early if empty
    E *= D.astype(_np.float32)
    if float(E.max()) <= 0.0:
        return []

    # componentize on adaptive threshold
    try:
        from scipy.ndimage import label, gaussian_filter
        use_scipy = True
    except Exception:
        use_scipy = False
        label = gaussian_filter = None

    thr = float(_np.quantile(E[E > 0.0], 0.20)) if (E > 0.0).any() else 0.0
    B = (E > thr).astype(_np.uint8)

    if use_scipy:
        comp_ids, n_comp = label(B)
    else:
        comp_ids = _np.zeros_like(B, _np.int32); n_comp = 0
        ys, xs = _np.where(B > 0)
        from collections import deque
        seen = set()
        for y, x in zip(ys, xs):
            if (y, x) in seen: continue
            n_comp += 1; q = deque([(y, x)]); seen.add((y, x)); comp_ids[y, x] = n_comp
            while q:
                cy, cx = q.popleft()
                for ny, nx in ((cy-1,cx),(cy+1,cx),(cy,cx-1),(cy,cx+1)):
                    if 0 <= ny < H and 0 <= nx < W and B[ny, nx] and (ny, nx) not in seen:
                        seen.add((ny, nx)); comp_ids[ny, nx] = n_comp; q.append((ny, nx))

    proposals = []
    for cid in range(1, int(n_comp) + 1):
        comp = (comp_ids == cid)
        area = int(comp.sum())
        if area < int(min_component_px):
            continue

        m = (E * comp.astype(_np.float32))
        mmax = float(m.max())
        if mmax > 0.0:
            m = (m / mmax).astype(_np.float32)
        if smooth_sigma and use_scipy and gaussian_filter is not None:
            m = gaussian_filter(m, sigma=float(smooth_sigma)).astype(_np.float32)
            m = _np.clip(m, 0.0, 1.0)

        ys, xs = _np.nonzero(comp)
        cy = float(ys.mean()) if ys.size else 0.0
        cx = float(xs.mean()) if xs.size else 0.0

        # child weights from contributions over this component
        weights = {}
        for (ii, jj, wij) in pair_contribs:
            wloc = float(wij[comp].sum())
            if wloc <= 0.0: continue
            ci = int(getattr(children[ii], "id", ii))
            cj = int(getattr(children[jj], "id", jj))
            weights[ci] = weights.get(ci, 0.0) + wloc
            weights[cj] = weights.get(cj, 0.0) + wloc
        totw = sum(weights.values()) or 1.0
        weights = {int(k): float(v / totw) for k, v in weights.items()}
        child_ids = tuple(sorted(weights.keys()))

        proposals.append({
            "cy": cy, "cx": cx,
            "mask": m,
            "child_ids": child_ids,
            "child_weights": weights,
            "score": float(E[comp].sum()) / max(1.0, area),
        })

    if per_pixel_norm and proposals:
        stack = _np.stack([p["mask"] for p in proposals], axis=0)
        denom = _np.maximum(1e-6, stack.sum(axis=0))
        for p in proposals:
            p["mask"] = (p["mask"] / denom).astype(_np.float32)

    if debug:
        print(f"[PX-SPAWN/DKL] proposals={len(proposals)} comps={int(n_comp)} "
              f"Emax={E.max():.3f} alpha={a} gamma={float(getattr(_cfg,'curvature_gamma',0.0))}")
        for p in sorted(proposals, key=lambda d: -d.get('score', 0.0))[:min(8, len(proposals))]:
            print(f"  - kids={tuple(sorted(p.get('child_ids', ())))} "
                  f"area={(p['mask']>0.01).sum()} peak={float(p['mask'].max()):.3f} score={p['score']:.4f}")

    return proposals
# parent_spawn.py  — slimmer _match_or_spawn using helpers

def _match_or_spawn(
    peaks,
    parents_by_id,
    next_parent_id,
    agents,
    shape_info,
    generators,
    *,
    match_iou_thr,
    child_jac_thr,
    support_tau,
    max_new_per_step,
    min_interseed_px,
):
    import numpy as np, config
    from parent_utils import (
        append_center_from_mask, centroid_toroidal, dist2_toroidal,
        respect_spawn_spacing, conservative_child_set_from_seed,
    )
    # NEW helpers:
    from parent_utils import (
        prepare_parent_match_state, gate_and_seed_proposal,
        novelty_gate_ok, continuity_match_pid, match_score_for_parent,
    )

    _RC = globals().get("runtime_ctx", None)
    try:
        step_now = int(getattr(_RC, "global_step", 0))
    except Exception:
        step_now = 0

    H, W, dtype, Kq, Kp = shape_info
    Gq, Gp = generators
    per_x = bool(getattr(config, "periodic_x", True))
    per_y = bool(getattr(config, "periodic_y", True))

    exists_support, exists_kids = prepare_parent_match_state(parents_by_id, support_tau)

    chosen_centers = []
    for pid, supp in exists_support.items():
        # 1) seeding chosen_centers from existing parents
        append_center_from_mask(
            chosen_centers, supp, pid, H, W, per_x=per_x, per_y=per_y
        )

    # thresholds (unchanged)
    local_tau      = float(getattr(config, "parent_proposal_local_tau", 0.01))
    min_local_px   = int(getattr(config, "parent_min_seed_area_px", 1))
    mask_tau_child = float(getattr(config, "detector_mask_tau", 1e-3))
    min_overlap_px = int(getattr(config, "parent_assign_min_overlap_px", 8))
    min_seed_px    = int(getattr(config, "parent_min_seed_px", max(4, min_overlap_px // 2)))

    keep_thr_cont  = float(getattr(config, "parent_continuity_child_jacc_keep_thr", 0.60))
    replace_thr    = float(getattr(config, "parent_match_childset_replace_thr", 0.75))
    weight_ema     = float(getattr(config, "parent_child_weight_ema", 0.20))

    # NEW novelty knobs
    min_novel_px   = int(getattr(config, "parent_min_novel_seed_px", 6))
    min_novel_frac = float(getattr(config, "parent_min_novel_seed_frac", 0.20))

    updated = spawned = 0
    dropped_local = dropped_spacing = dropped_budget = 0
    dropped_childov = dropped_seed = 0

    new_spawned = 0
    for peak in sorted(peaks or [], key=lambda d: -d.get("score", 0.0)):
        if new_spawned >= max_new_per_step:
            dropped_budget += 1
            break

        prop = peak.get("proposal", peak.get("mask"))
        cy = float(peak.get("cy", 0.0))
        cx = float(peak.get("cx", 0.0))

        gated, reason = gate_and_seed_proposal(
            prop, H=H, W=W, local_tau=local_tau, min_local_px=min_local_px,
            agents=agents, mask_tau_child=mask_tau_child,
            support_tau=support_tau, min_seed_px=min_seed_px
        )
        if gated is None:
            if reason == "local": dropped_local += 1
            else:                 dropped_seed  += 1
            continue

        prop, seed_bool, seed_px = gated

        # novelty (NEW)
        ok, novel_px, novel_frac = novelty_gate_ok(
            seed_bool, exists_support, H=H, W=W,
            min_novel_px=min_novel_px, min_novel_frac=min_novel_frac
        )
        if not ok:
            if bool(getattr(config, "debug_spawn_log_details", True)):
                print(f"  -> DROP (not novel) novel_px={novel_px} "
                      f"seed_px={seed_px} frac={novel_frac:.2f} "
                      f"min_px={min_novel_px} min_frac={min_novel_frac}")
            dropped_spacing += 1
            continue

        # continuity rescue (unchanged logic, now via helper)
        cont_r2      = float(getattr(config, "parent_continuity_radius_px", max(1, min_interseed_px))) ** 2
        cont_iou_thr = float(getattr(config, "parent_continuity_iou_thr", 0.15))
        cont_best = continuity_match_pid(
            cy, cx, seed_bool, exists_support,
            H=H, W=W, per_x=per_x, per_y=per_y,
            cont_r2=cont_r2, cont_iou_thr=cont_iou_thr
        )
        if cont_best is not None:
            _, best_pid = cont_best
            P = parents_by_id[int(best_pid)]
            P.mask = np.clip(prop, 0.0, 1.0).astype(dtype, copy=False)
            cw = peak.get("child_weights", None)
            if isinstance(cw, dict) and cw:
                old = set(getattr(P, "child_ids", ()))
                new = set(int(k) for k in cw.keys())
                from parent_utils import jaccard_sets
                j = jaccard_sets(old, new) if old else 1.0
                if j >= keep_thr_cont:
                    P.child_weights = {int(k): float(v) for k, v in cw.items()}
                    P.child_ids     = tuple(sorted(P.child_weights.keys()))
            P._region_proposal = prop
            exists_support[best_pid] = (P.mask > support_tau)
            supp = (np.asarray(P.mask, np.float32) > float(support_tau))
            append_center_from_mask(
                chosen_centers, supp, best_pid, H, W,
                per_x=per_x, per_y=per_y, fallback=(cy, cx)
            )

            updated += 1
            if bool(getattr(config, "debug_spawn_log_details", True)):
                print(f"  -> CONT-MATCH pid={best_pid} seed_px={seed_px}")
            continue

        # conservative kid set (unchanged)
        gkids_seed = set(conservative_child_set_from_seed(
            agents, seed_bool, mask_tau=mask_tau_child, min_overlap_px=min_overlap_px
        ))
        gkids_peak = set(peak.get("child_ids", ()))
        gkids = gkids_seed if not gkids_peak else (gkids_seed & gkids_peak)
        if len(gkids) < 2:
            if bool(getattr(config, "debug_spawn_log_details", True)):
                print(f"  -> DROP (child overlap) |kids|={len(gkids)} < 2 (ov_px≥{min_overlap_px})")
            dropped_childov += 1
            continue

        # (1) MATCH
        best_pid, best_sc = None, (-1.0, -1.0)
        R2 = float(max(1, min_interseed_px)) ** 2
        for pid, supp in exists_support.items():
            py, px = centroid_toroidal(supp, H, W, per_y=per_y, per_x=per_x)
            close  = (dist2_toroidal(cy, cx, py, px, H, W, per_y, per_x) <= R2)
            sc = match_score_for_parent(seed_bool, gkids, supp, exists_kids[pid],
                                        close=close,
                                        match_iou_thr=match_iou_thr,
                                        child_jac_thr=child_jac_thr)
            if sc is not None and sc > best_sc:
                best_sc, best_pid = sc, pid

        if best_pid is not None:
            P = parents_by_id[int(best_pid)]
            P.mask = np.clip(prop, 0.0, 1.0).astype(dtype, copy=False)
            cw = peak.get("child_weights")
            if isinstance(cw, dict) and cw:
                old = set(getattr(P, "child_ids", ()))
                new = set(int(k) for k in cw.keys())
                from parent_utils import jaccard_sets
                j   = jaccard_sets(old, new) if old else 1.0
                if j >= float(replace_thr):
                    P.child_weights = {int(k): float(v) for k, v in cw.items()}
                    P.child_ids     = tuple(sorted(P.child_weights.keys()))
                else:
                    # NEW
                    weights = dict(getattr(P, "child_weights", {}))
                    if not weights and old:
                        weights = {int(k): 1.0 / len(old) for k in old}
                    tot = 0.0
                    for k in set(weights.keys()) | set(int(x) for x in cw.keys()):
                        v_old = float(weights.get(k, 0.0))
                        v_new = float(cw.get(k, 0.0))
                        weights[k] = (1.0 - float(weight_ema)) * v_old + float(weight_ema) * v_new
                        tot += weights[k]
                    if tot > 0:
                        for k in weights:
                            weights[k] /= tot
                    P.child_weights = weights
                    P.child_ids     = tuple(sorted(weights.keys()))
            else:
                P.child_ids = tuple(sorted(gkids))
                P.child_weights = {int(cid): 1.0 / len(gkids) for cid in gkids}

            P._region_proposal = prop
            P.emerged = True
            exists_support[best_pid] = (P.mask > support_tau)
            exists_kids[best_pid]    = set(P.child_ids)
            append_center_from_mask(
                    chosen_centers, (P.mask > support_tau), best_pid, H, W,
                    per_x=per_x, per_y=per_y, fallback=(cy, cx)
                )
            updated += 1
            if bool(getattr(config, "debug_spawn_log_details", True)):
                print(f"  -> MATCH pid={best_pid} iou={best_sc[0]:.3f} "
                      f"jacc={(best_sc[1]-1.0) if best_sc[1] > 1 else best_sc[1]:.3f} "
                      f"seed_px={seed_px}")
            continue

        # (2) SPAWN
        if not respect_spawn_spacing(
            cy, cx, gkids, chosen_centers, exists_kids,
            H, W, per_x, per_y,
            min_interseed_px=min_interseed_px,
            jac_thr=float(getattr(config, "spacing_child_jaccard_thr", 0.90)),
            subset_thr=float(getattr(config, "spacing_child_subset_thr", 0.90)),
        ):
            if bool(getattr(config, "debug_spawn_log_details", True)):
                print("  -> DROP (spacing/child-set near-duplicate)")
            dropped_spacing += 1
            continue

        pid = int(next_parent_id); next_parent_id += 1
        try:
            from parent_spawn import _make_parent_template
        except Exception:
            from parent_utils import _make_parent_template

        P = _make_parent_template(_RC, agents[0], pid=pid, H=H, W=W, Kq=Kq, Kp=Kp,
                                  generators_q=Gq, generators_p=Gp)
        P.mask = np.clip(prop, 0.0, 1.0).astype(dtype, copy=False)
        cw = peak.get("child_weights")
        if isinstance(cw, dict) and cw:
            P.child_weights = {int(k): float(v) for k, v in cw.items()}
            P.child_ids = tuple(sorted(P.child_weights.keys()))
        else:
            P.child_ids = tuple(sorted(gkids))
            P.child_weights = {int(cid): 1.0 / len(gkids) for cid in gkids}
        P._region_proposal = prop
        P.emerged = True

        P.birth_step = step_now
        P._age = 0
        P._grace = int(getattr(config, "parent_freeze_steps", 0))

        parents_by_id[pid]  = P
        exists_support[pid] = (P.mask > support_tau)
        exists_kids[pid]    = set(P.child_ids)
        append_center_from_mask(
            chosen_centers, (P.mask > support_tau), pid, H, W,
            per_x=per_x, per_y=per_y, fallback=(cy, cx)
        )
        spawned += 1
        new_spawned += 1

    print(f"[SPAWN] updated={updated} spawned={spawned} "
          f"d_local={dropped_local} d_space={dropped_spacing} "
          f"d_childov={dropped_childov} d_seed={dropped_seed} d_budget={dropped_budget}")
    return next_parent_id







def _make_parent_template(ctx, tmpl, *, pid: int, H: int, W: int, Kq: int, Kp: int,
                          generators_q, generators_p):
    """Construct a brand-new level-1 parent with safe defaults and gradient buffers."""
   
    AgentCls = tmpl.__class__
    dtype = tmpl.mu_q_field.dtype

    # identities, broadcasted then materialized
    eye_q = np.broadcast_to(np.eye(Kq, dtype=dtype), (H, W, Kq, Kq)).copy()
    eye_p = np.broadcast_to(np.eye(Kp, dtype=dtype), (H, W, Kp, Kp)).copy()

    P = AgentCls(
        id=pid, center=(0, 0), radius=0.0,
        mask=np.zeros((H, W), np.float32),
        mu_q_field=np.zeros((H, W, Kq), dtype=dtype), sigma_q_field=eye_q,
        mu_p_field=np.zeros((H, W, Kp), dtype=dtype), sigma_p_field=eye_p,
        phi=np.zeros((H, W, 3), dtype=dtype), phi_model=np.zeros((H, W, 3), dtype=dtype),
        neighbors=[]
    )

    # level/lifecycle
    P.level = 1
    P.emerged = True
    P._age = 0
    P._grace = int(getattr(config, "parent_grace_steps", 2))
    P._shrink_strikes = 0
    P.birth_step = int(getattr(ctx, "global_step", 0))

    # coalition/weights placeholders expected by assign/prune
    P.child_ids = ()
    P.child_weights = {}

    # transport caches & exp(φ) caches
    P.Omega_cache = {}
    P.Omega_tilde_cache = {}
    P._exp_phi = None
    P._exp_neg_phi = None
    P._exp_phi_model = None
    P._exp_neg_phi_model = None

    # stash generators (respect existing if already set)
    P.generators_q = P.generators_q if getattr(P, "generators_q", None) is not None else generators_q
    P.generators_p = P.generators_p if getattr(P, "generators_p", None) is not None else generators_p

    # Base morphisms (cross-fiber shims)
    P.Phi_0       = np.eye(Kp, Kq, dtype=dtype)
    P.Phi_tilde_0 = np.eye(Kq, Kp, dtype=dtype)

    # Compute default bundle morphisms (fallback to identity-like if unavailable)
    try:
    
        P.bundle_morphism_q_to_p, P.bundle_morphism_p_to_q = compute_direct_morphisms(
            phi=P.phi, phi_model=P.phi_model,
            generators_q=P.generators_q, generators_p=P.generators_p,
            Phi_0=P.Phi_0, Phi_tilde_0=P.Phi_tilde_0,
        )
    except Exception:
        P.bundle_morphism_q_to_p = np.broadcast_to(P.Phi_0, (H, W, Kp, Kq)).copy()
        P.bundle_morphism_p_to_q = np.broadcast_to(P.Phi_tilde_0, (H, W, Kq, Kp)).copy()

    # Initialize gradient buffers (suite helper)
   
    initialize_agent_gradients(P)

    # SPD tidy (symmetrize + jitter) — enforce 4D SPD shapes
    def _spd_tidy(S):
        S = 0.5 * (S + np.swapaxes(S, -1, -2))
        K = S.shape[-1]
        return S + (1e-8 * np.eye(K, dtype=S.dtype))
    assert P.sigma_q_field.ndim == 4 and P.sigma_q_field.shape[-1] == P.sigma_q_field.shape[-2], \
        f"sigma_q_field bad shape {P.sigma_q_field.shape}"
    assert P.sigma_p_field.ndim == 4 and P.sigma_p_field.shape[-1] == P.sigma_p_field.shape[-2], \
        f"sigma_p_field bad shape {P.sigma_p_field.shape}"
    P.sigma_q_field = _spd_tidy(P.sigma_q_field)
    P.sigma_p_field = _spd_tidy(P.sigma_p_field)

    # scratch used by detector/matcher
    P._region_proposal = None

    return P







