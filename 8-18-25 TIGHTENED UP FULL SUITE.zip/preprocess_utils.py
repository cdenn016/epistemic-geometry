# -*- coding: utf-8 -*-
"""
Created on Mon Aug 11 16:05:57 2025

@author: chris and christine
"""

import numpy as np
import config
from natural_gradient import (compute_inverse_fisher_field_natural,
                              )
from get_generators import get_generators
from omega import exp_lie_algebra_irrep
             
from numerical_utils import sanitize_sigma, safe_omega_inv, safe_inv, masked_cond_proxy    



from runtime_context import RuntimeCtx



# --- 1) preprocess all agents once per outer step ----------------------------

def preprocess_all_agents(agents, params, G_q=None, G_p=None):
    """
    Build/refresh: generators, Σ sanitization + inverses, exp(φ)/exp(−φ),
    Fisher caches (optional), and reset per-step transport caches.
    Call this ONCE per step BEFORE you build Ω and Λ caches.
    """
    for a in agents:
        preprocess_agent_fields(a, params, G_q=G_q, G_p=G_p)

# preprocess_utils.py  (inside build_all_lambda_caches)
def build_all_lambda_caches(agents):
    import numpy as np

    # --- ensure dicts exist even for legacy/partially-initialized agents
    for a in agents:
        if getattr(a, "Lambda_up_q_map", None) is None: a.Lambda_up_q_map = {}
        if getattr(a, "Lambda_dn_q_map", None) is None: a.Lambda_dn_q_map = {}
        if getattr(a, "Lambda_up_p_map", None) is None: a.Lambda_up_p_map = {}
        if getattr(a, "Lambda_dn_p_map", None) is None: a.Lambda_dn_p_map = {}

    id2agent = {a.id: a for a in agents}

    # require exp caches
    for a in agents:
        if a._exp_phi is None or a._exp_neg_phi is None:
            raise RuntimeError(f"Agent {a.id} missing exp(phi) caches. Call preprocess_all_agents() first.")
        if a._exp_phi_model is None or a._exp_neg_phi_model is None:
            raise RuntimeError(f"Agent {a.id} missing exp(phi_model) caches. Call preprocess_all_agents() first.")

    # (optional) clear per-parent maps to avoid stale entries if topology changed
    for a in agents:
        a.Lambda_up_q_map.clear(); a.Lambda_dn_q_map.clear()
        a.Lambda_up_p_map.clear(); a.Lambda_dn_p_map.clear()

    # build per child->parent
    for child in agents:
        if not getattr(child, "parent_ids", []):
            continue
        for pid in child.parent_ids:
            parent = id2agent.get(pid)
            if parent is None:
                continue
            child.Lambda_up_q_map[pid] = np.einsum("...ik,...kj->...ij", parent._exp_phi, child._exp_neg_phi)
            child.Lambda_dn_q_map[pid] = np.einsum("...ik,...kj->...ij", child._exp_phi, parent._exp_neg_phi)
            child.Lambda_up_p_map[pid] = np.einsum("...ik,...kj->...ij", parent._exp_phi_model, child._exp_neg_phi_model)
            child.Lambda_dn_p_map[pid] = np.einsum("...ik,...kj->...ij", child._exp_phi_model, parent._exp_neg_phi_model)


# --- 2) cross-scale Λ caches (per child->parent), gauge-covariant ------------

def QQbuild_all_lambda_caches(
    agents,
    *,
    compute_globals: bool = True,
    use_log_euclidean: bool = True,
    max_global_samples: int = 4096,
    mirror_to_ctx: "RuntimeCtx" = None,
    low_level: int = None,
    high_level: int = None,
    reference_not_copy: bool = True,
):
    """
    Robust Λ builder: tolerates None agents and partially-initialized objects.
    """

    import numpy as _np

    # --- 0) Filter out None early
    agents = [a for a in agents if a is not None]

    # --- 1) id -> agent (skip any objects missing id)
    id2agent = {int(getattr(a, "id")): a for a in agents if hasattr(a, "id")}

    # --- 2) Sanity: require exp-caches
    for a in agents:
        if getattr(a, "_exp_phi", None) is None or getattr(a, "_exp_neg_phi", None) is None:
            raise RuntimeError(f"Agent {getattr(a, 'id', '?')} missing exp(phi) caches. Call preprocess_all_agents() first.")
        if getattr(a, "_exp_phi_model", None) is None or getattr(a, "_exp_neg_phi_model", None) is None:
            raise RuntimeError(f"Agent {getattr(a, 'id', '?')} missing exp(phi_model) caches. Call preprocess_all_agents() first.")

    # --- 3) Clear or create Λ dicts
    for a in agents:
        if not hasattr(a, "Lambda_up_q_map"): a.Lambda_up_q_map = {}
        if not hasattr(a, "Lambda_dn_q_map"): a.Lambda_dn_q_map = {}
        if not hasattr(a, "Lambda_up_p_map"): a.Lambda_up_p_map = {}
        if not hasattr(a, "Lambda_dn_p_map"): a.Lambda_dn_p_map = {}
        a.Lambda_up_q_map.clear()
        a.Lambda_dn_q_map.clear()
        a.Lambda_up_p_map.clear()
        a.Lambda_dn_p_map.clear()
        if compute_globals:
            if not hasattr(a, "Lambda_up_q_global"): a.Lambda_up_q_global = {}
            if not hasattr(a, "Lambda_up_p_global"): a.Lambda_up_p_global = {}
            a.Lambda_up_q_global.clear()
            a.Lambda_up_p_global.clear()

    # --- 4) Build Λ maps
    for child in agents:
        pids = getattr(child, "parent_ids", None) or []
        if not pids:
            continue

        Hc, Wc = child.hw
        Kq = int(child.mu_q_field.shape[-1])
        Kp = int(child.mu_p_field.shape[-1])

        for pid in pids:
            parent = id2agent.get(int(pid))
            if parent is None:
                continue

            Hp, Wp = parent.hw
            if (Hc, Wc) != (Hp, Wp):
                raise ValueError(
                    f"Λ build requires identical grids; child[{child.id}] {(Hc,Wc)} vs parent[{pid}] {(Hp,Wp)}."
                )
            if int(parent.mu_q_field.shape[-1]) != Kq:
                raise ValueError(f"q-fiber K mismatch child {child.id} vs parent {pid}: {Kq} vs {int(parent.mu_q_field.shape[-1])}")
            if int(parent.mu_p_field.shape[-1]) != Kp:
                raise ValueError(f"p-fiber K mismatch child {child.id} vs parent {pid}: {Kp} vs {int(parent.mu_p_field.shape[-1])}")

            dq = _np.result_type(child._exp_phi.dtype,       parent._exp_phi.dtype)
            dp = _np.result_type(child._exp_phi_model.dtype, parent._exp_phi_model.dtype)

            Lu_q = _np.einsum("...ik,...kj->...ij",
                              parent._exp_phi.astype(dq, copy=False),
                              child._exp_neg_phi.astype(dq, copy=False),
                              optimize=True)
            Ld_q = _np.einsum("...ik,...kj->...ij",
                              child._exp_phi.astype(dq, copy=False),
                              parent._exp_neg_phi.astype(dq, copy=False),
                              optimize=True)
            Lu_p = _np.einsum("...ik,...kj->...ij",
                              parent._exp_phi_model.astype(dp, copy=False),
                              child._exp_neg_phi_model.astype(dp, copy=False),
                              optimize=True)
            Ld_p = _np.einsum("...ik,...kj->...ij",
                              child._exp_phi_model.astype(dp, copy=False),
                              parent._exp_neg_phi_model.astype(dp, copy=False),
                              optimize=True)

            child.Lambda_up_q_map[int(pid)] = Lu_q
            child.Lambda_dn_q_map[int(pid)] = Ld_q
            child.Lambda_up_p_map[int(pid)] = Lu_p
            child.Lambda_dn_p_map[int(pid)] = Ld_p

            if compute_globals:
                m = (child.mask > 0) & (parent.mask > 0)
                if m.any():
                    idx = _np.flatnonzero(m.ravel())
                    if idx.size > max_global_samples:
                        sel = idx[_np.linspace(0, idx.size - 1, max_global_samples, dtype=int)]
                    else:
                        sel = idx
                    try:
                        if use_log_euclidean:
                            try:
                                import scipy.linalg as la
                                Lq_sel = Lu_q.reshape(-1, Kq, Kq)[sel]
                                Lp_sel = Lu_p.reshape(-1, Kp, Kp)[sel]
                                Lq_logs = _np.stack([la.logm(X) for X in Lq_sel], axis=0)
                                Lp_logs = _np.stack([la.logm(X) for X in Lp_sel], axis=0)
                                child.Lambda_up_q_global[int(pid)] = la.expm(Lq_logs.mean(axis=0))
                                child.Lambda_up_p_global[int(pid)] = la.expm(Lp_logs.mean(axis=0))
                            except Exception:
                                child.Lambda_up_q_global[int(pid)] = Lu_q.reshape(-1, Kq, Kq)[sel].mean(axis=0)
                                child.Lambda_up_p_global[int(pid)] = Lu_p.reshape(-1, Kp, Kp)[sel].mean(axis=0)
                        else:
                            child.Lambda_up_q_global[int(pid)] = Lu_q.reshape(-1, Kq, Kq)[sel].mean(axis=0)
                            child.Lambda_up_p_global[int(pid)] = Lu_p.reshape(-1, Kp, Kp)[sel].mean(axis=0)
                    except Exception:
                        child.Lambda_up_q_global[int(pid)] = Lu_q[m].mean(axis=0)
                        child.Lambda_up_p_global[int(pid)] = Lu_p[m].mean(axis=0)

    # --- 5) Optional: mirror into RuntimeCtx snapshot (zero-copy by default)
    if mirror_to_ctx is not None:
        if low_level is None or high_level is None:
            raise ValueError("When mirror_to_ctx is provided, low_level and high_level must be set.")
        children = [a for a in agents if getattr(a, "level", None) == low_level]
        parents  = [a for a in agents if getattr(a, "level", None) == high_level]
        mirror_to_ctx.register_agents(low_level, children)
        mirror_to_ctx.register_agents(high_level, parents)
        mirror_to_ctx.mirror_agent_lambdas_into_link(
            low_level, high_level, children, parents,
            attach_labels=True, label_policy="primary",
            attach_lambda=True, reference_not_copy=reference_not_copy
        )






def attach_parent_lambda_views(agents):
    """
    Robust parent-side views: skips None, ensures dicts exist.
    """
    agents = [a for a in agents if a is not None]
    # Clear stale views first
    for A in agents:
        if not hasattr(A, "Lambda_from_child_q_map"): A.Lambda_from_child_q_map = {}
        if not hasattr(A, "Lambda_to_child_q_map"):   A.Lambda_to_child_q_map   = {}
        if not hasattr(A, "Lambda_from_child_p_map"): A.Lambda_from_child_p_map = {}
        if not hasattr(A, "Lambda_to_child_p_map"):   A.Lambda_to_child_p_map   = {}
        A.Lambda_from_child_q_map.clear()
        A.Lambda_to_child_q_map.clear()
        A.Lambda_from_child_p_map.clear()
        A.Lambda_to_child_p_map.clear()

    id2agent = {int(a.id): a for a in agents if hasattr(a, "id")}
    for child in agents:
        pids = getattr(child, "parent_ids", None) or []
        for pid in pids:
            parent = id2agent.get(int(pid))
            if parent is None:
                continue
            up_q  = getattr(child, "Lambda_up_q_map",   {})
            dn_q  = getattr(child, "Lambda_dn_q_map",   {})
            up_p  = getattr(child, "Lambda_up_p_map",   {})
            dn_p  = getattr(child, "Lambda_dn_p_map",   {})
            if pid in up_q:
                parent.Lambda_from_child_q_map[int(child.id)] = up_q[int(pid)]
            if pid in dn_q:
                parent.Lambda_to_child_q_map[int(child.id)]   = dn_q[int(pid)]
            if pid in up_p:
                parent.Lambda_from_child_p_map[int(child.id)] = up_p[int(pid)]
            if pid in dn_p:
                parent.Lambda_to_child_p_map[int(child.id)]   = dn_p[int(pid)]




def zero_all_gradients(agent):
    """
    Zero (and if missing, create) all gradient buffers,
    keeping legacy aliases in sync and ensuring arrays are writeable.
    """
    def ensure_buf(name, like):
        arr = getattr(agent, name, None)
        if arr is None and like is not None:
            arr = np.zeros_like(like)
        elif arr is not None and not arr.flags.writeable:
            arr = np.array(arr, copy=True)
        setattr(agent, name, arr)
        return arr

    # Canonical grads (create from fields if needed)
    g_mu_q   = ensure_buf("grad_mu_q",    getattr(agent, "mu_q_field", None))
    g_sg_q   = ensure_buf("grad_sigma_q", getattr(agent, "sigma_q_field", None))
    g_mu_p   = ensure_buf("grad_mu_p",    getattr(agent, "mu_p_field", None))
    g_sg_p   = ensure_buf("grad_sigma_p", getattr(agent, "sigma_p_field", None))
    g_phi    = ensure_buf("grad_phi",       getattr(agent, "phi", None))
    g_phit   = ensure_buf("grad_phi_tilde", getattr(agent, "phi_model", None))
    g_Phi    = ensure_buf("grad_Phi",       getattr(agent, "bundle_morphism_q_to_p", None))
    g_Phit   = ensure_buf("grad_Phi_tilde", getattr(agent, "bundle_morphism_p_to_q", None))

    # Keep legacy aliases in sync (as references, not copies)
    if g_mu_q is not None:
        agent.grad_mu_q_field = g_mu_q
    if g_sg_q is not None:
        agent.grad_sigma_q_field = g_sg_q
    if g_mu_p is not None:
        agent.grad_mu_p_field = g_mu_p
    if g_sg_p is not None:
        agent.grad_sigma_p_field = g_sg_p

    # Zero safely
    for arr in (g_mu_q, g_sg_q, g_mu_p, g_sg_p, g_phi, g_phit, g_Phi, g_Phit):
        if isinstance(arr, np.ndarray):
            arr.fill(0)


    

def build_all_omega_caches(agents, *, strict=False, debug=False):
    """
    Build Ω and Ω̃ caches for each agent using their precomputed exp(φ) fields.
    Safe to call on *subsets* of agents (no global indexing).
      - agents: list[Agent] or dict[id->Agent]
      - requires agent._exp_phi/_exp_neg_phi and *_model to be ready (preprocess step)
    """
    import numpy as np

    # Normalize agents -> iterable + id->agent map (subset-aware)
    if isinstance(agents, dict):
        agent_list = list(agents.values())
        id_map = {int(getattr(a, "id", i)): a for i, a in enumerate(agent_list)}
    else:
        agent_list = list(agents or [])
        id_map = {int(getattr(a, "id", i)): a for i, a in enumerate(agent_list)}

    for agent_i in agent_list:
        # reset caches
        agent_i.Omega_cache = {}
        agent_i.Omega_tilde_cache = {}

        neigh = getattr(agent_i, "neighbors", ()) or ()
        for nb in neigh:
            try:
                j_id = int(nb.get("id"))
            except Exception:
                if strict:
                    raise
                if debug:
                    print(f"[omega] skip neighbor with bad id: {nb!r}")
                continue

            agent_j = id_map.get(j_id)
            if agent_j is None:
                # neighbor not in this subset; skip quietly
                if debug:
                    print(f"[omega] neighbor {j_id} not in subset, skipping")
                continue

            E_phi_i      = getattr(agent_i, "_exp_phi", None)
            E_neg_phi_j  = getattr(agent_j, "_exp_neg_phi", None)
            E_phi_i_m    = getattr(agent_i, "_exp_phi_model", None)
            E_neg_phi_jm = getattr(agent_j, "_exp_neg_phi_model", None)

            # Require caches to exist (built in preprocess). Skip or error.
            if (E_phi_i is None) or (E_neg_phi_j is None) or (E_phi_i_m is None) or (E_neg_phi_jm is None):
                if strict:
                    raise RuntimeError(f"Missing exp(phi) fields for i={getattr(agent_i,'id','?')} or j={j_id}")
                if debug:
                    print(f"[omega] missing exp-phi caches for pair (i={getattr(agent_i,'id','?')}, j={j_id}); skipping")
                continue

            # Shapes: (...,K,K) x (...,K,K) -> (...,K,K)
            Omega_ij       = np.einsum("...ik,...kj->...ij", E_phi_i,     E_neg_phi_j,  optimize=True)
            Omega_tilde_ij = np.einsum("...ik,...kj->...ij", E_phi_i_m,   E_neg_phi_jm, optimize=True)

            agent_i.Omega_cache[j_id]        = Omega_ij
            agent_i.Omega_tilde_cache[j_id]  = Omega_tilde_ij

 
            
 
def preprocess_agent_fields(agent, params, G_q=None, G_p=None):
    eps        = getattr(config, "eps", 1e-8)
    group_name = config.group_name
    strict     = params.get("sanitize_strict", True) if params else True
    exp_jobs   = params.get("exp_n_jobs", 1)

    # ── Generators: prefer provided -> cached -> compute
    if G_q is not None:
        agent.generators_q = G_q
    if G_p is not None:
        agent.generators_p = G_p

    G_q = getattr(agent, "generators_q", None)
    if G_q is None or (isinstance(G_q, np.ndarray) and G_q.size == 0):
        G_q = get_generators(group_name, config.K_q)
        agent.generators_q = G_q

    G_p = getattr(agent, "generators_p", None)
    if G_p is None or (isinstance(G_p, np.ndarray) and G_p.size == 0):
        G_p = get_generators(group_name, config.K_p)
        agent.generators_p = G_p

    # SPD sanitize
    agent.sigma_q_field = sanitize_sigma(agent.sigma_q_field, strict=strict)
    agent.sigma_p_field = sanitize_sigma(agent.sigma_p_field, strict=strict)

    # Cache inverses
    agent.sigma_q_inv = safe_inv(agent.sigma_q_field, eps=eps)
    agent.sigma_p_inv = safe_inv(agent.sigma_p_field, eps=eps)

    # Condition proxies (masked, robust)
    agent._cond_proxy_q = masked_cond_proxy(agent.sigma_q_field, agent.mask)
    agent._cond_proxy_p = masked_cond_proxy(agent.sigma_p_field, agent.mask)

    # exp(φ), exp(φ̃)
    agent._exp_phi = exp_lie_algebra_irrep(
        agent.phi, G_q, group_name=group_name,
        max_norm=config.phi_exp_clip,
        threshold=getattr(config, "phi_exp_threshold", 1e-3),
        n_jobs=exp_jobs, verbose=False
    )
    agent._exp_phi_model = exp_lie_algebra_irrep(
        agent.phi_model, G_p, group_name=group_name,
        max_norm=config.phi_exp_clip,
        threshold=getattr(config, "phi_exp_threshold", 1e-3),
        n_jobs=exp_jobs, verbose=False
    )

    # exp(−φ), exp(−φ̃): transpose for orthogonal reps
    if getattr(config, "so3_irreps_are_orthogonal", True):
        agent._exp_neg_phi       = np.swapaxes(agent._exp_phi,      -1, -2)
        agent._exp_neg_phi_model = np.swapaxes(agent._exp_phi_model,-1, -2)
    else:
        agent._exp_neg_phi       = safe_omega_inv(agent._exp_phi, debug=False)
        agent._exp_neg_phi_model = safe_omega_inv(agent._exp_phi_model, debug=False)

    # Reset per-step transport caches
    agent.Omega_cache = {}
    agent.Omega_tilde_cache = {}

    # Optional Fisher metric caches for φ updates
    agent.inverse_fisher_phi        = compute_inverse_fisher_field_natural(agent, G_q, field="phi")
    agent.inverse_fisher_phi_model  = compute_inverse_fisher_field_natural(agent, G_p, field="phi_model")

    # Dev-only assert
    if getattr(config, "assert_spd_after_sanitize", False):
        wq = np.linalg.eigvalsh(0.5*(agent.sigma_q_field + np.swapaxes(agent.sigma_q_field,-1,-2)))
        wp = np.linalg.eigvalsh(0.5*(agent.sigma_p_field + np.swapaxes(agent.sigma_p_field,-1,-2)))
        floor = getattr(config, "sigma_eig_floor", 1e-6)
        if (wq <= floor).any() or (wp <= floor).any():
            raise RuntimeError("Non-SPD Σ after sanitize.")

