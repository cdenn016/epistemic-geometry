# -*- coding: utf-8 -*-
"""
Created on Wed Jul 16 18:18:11 2025

@author: chris and christine
"""

import numpy as np
from typing import Optional, Tuple
from scipy.ndimage import gaussian_filter
import config
from numerical_utils import sanitize_sigma, safe_inv
from omega import exp_lie_algebra_irrep



def pushforward_gaussian(mu, sigma, morphism, eps=1e-6):
    """
    Push-forward a Gaussian (μ, Σ) under a linear map M:
        μ' = M μ
        Σ' = M Σ Mᵀ
    Returns (mu_push, sigma_push, sigma_push_inv).

    Robust to missing/degenerate M:
      - If M is None or scalar-like, tries identity fallback of size K = mu.shape[-1]
        when Σ is (K,K). Otherwise raises a clear error suggesting a morphism rebuild.
    """
    mu = np.asarray(mu); sigma = np.asarray(sigma)
    K = int(mu.shape[-1])

    # Normalize/symmetrize Σ in case the caller passed a slightly non-SPD matrix
    sigma = 0.5 * (sigma + np.swapaxes(sigma, -1, -2))
    sigma = sigma + eps * np.eye(sigma.shape[-1], dtype=sigma.dtype)

    # Handle missing/degenerate M
    M = morphism
    if M is None:
        M = np.array(())  # normalize to ndarray path
    M = np.asarray(M)

    if M.ndim < 2:
        # Try identity fallback only if square push is valid
        if sigma.shape[-2:] == (K, K):
            M = np.eye(K, dtype=sigma.dtype)
        else:
            raise ValueError(
                "pushforward_gaussian: morphism missing/degenerate and cannot infer an identity "
                f"of correct shape. Got Σ shape {sigma.shape[-2:]}; expected square (K,K). "
                "Recompute agent morphisms (Φ/Φ̃) before calling this function."
            )

    # Basic shape checks
    if M.shape[-1] != K:
        raise ValueError(f"pushforward_gaussian: morphism last dim {M.shape[-1]} != μ dim {K}")
    if sigma.shape[-1] != K or sigma.shape[-2] != K:
        raise ValueError(f"pushforward_gaussian: Σ dims {sigma.shape[-2:]} incompatible with μ dim {K}")

    # Compute push-forward
    mu_push = np.einsum("...ik,...k->...i", M, mu, optimize=True)                       # M μ
    sigma_push = np.einsum("...ik,...kl,...jl->...ij", M, sigma, M, optimize=True)       # M Σ Mᵀ
    sigma_push = 0.5 * (sigma_push + np.swapaxes(sigma_push, -1, -2)) + eps * np.eye(sigma_push.shape[-1], dtype=sigma_push.dtype)
    sigma_push_inv = safe_inv(sigma_push, eps=1e-8)
    return mu_push, sigma_push, sigma_push_inv



def compute_direct_morphisms(phi, phi_model, generators_q, generators_p, Phi_0, Phi_tilde_0):
    """
    Build rectangular morphisms with gauge transport:
        Φ       = exp(φ̃) · Φ₀ · exp(φ)^T      (SO(3): ^T = inverse)
        Φ̃      = exp(φ) · Φ̃₀ · exp(φ̃)^T
    Accepts Φ₀/Φ̃₀ as 2D (Kx,K) or field-shaped (H,W,Kx,K).
    """
    Omega_q = exp_lie_algebra_irrep(phi, generators_q)         # (..., Kq, Kq)
    Omega_p = exp_lie_algebra_irrep(phi_model, generators_p)   # (..., Kp, Kp)
    Kq = Omega_q.shape[-1]; Kp = Omega_p.shape[-1]

    # Broadcast Φ0/Φ̃0 to field if needed
    if not isinstance(Phi_0, np.ndarray) or Phi_0.shape[-2:] != (Kp, Kq):
        Phi_0 = np.eye(Kp, Kq, dtype=Omega_p.dtype)
    if not isinstance(Phi_tilde_0, np.ndarray) or Phi_tilde_0.shape[-2:] != (Kq, Kp):
        Phi_tilde_0 = np.eye(Kq, Kp, dtype=Omega_q.dtype)

    # If 2D, add leading dims of ones for broadcast
    if Phi_0.ndim == 2:
        Phi_0 = np.broadcast_to(Phi_0, Omega_p.shape[:-2] + (Kp, Kq))
    if Phi_tilde_0.ndim == 2:
        Phi_tilde_0 = np.broadcast_to(Phi_tilde_0, Omega_q.shape[:-2] + (Kq, Kp))

    Omega_q_T = np.swapaxes(Omega_q, -1, -2)
    Omega_p_T = np.swapaxes(Omega_p, -1, -2)

    Phi       = np.einsum("...ik,...kj,...jl->...il", Omega_p, Phi_0,       Omega_q_T, optimize=True)
    Phi_tilde = np.einsum("...ik,...kj,...jl->...il", Omega_q, Phi_tilde_0, Omega_p_T, optimize=True)
    return Phi, Phi_tilde


def have_parent_morphisms(P) -> bool:
    """
    True iff base morphisms exist with correct rectangular shapes:
      Phi_0       : (Kp, Kq)
      Phi_tilde_0 : (Kq, Kp)
    and generators are present.
    """
    import numpy as np
    if not hasattr(P, "mu_q_field") or not hasattr(P, "mu_p_field"):
        return False
    Kq = int(getattr(P.mu_q_field, "shape", (0,))[-1])
    Kp = int(getattr(P.mu_p_field, "shape", (0,))[-1])
    if Kq <= 0 or Kp <= 0:
        return False

    ok_gen = hasattr(P, "generators_q") and hasattr(P, "generators_p")

    A = getattr(P, "Phi_0", None)
    B = getattr(P, "Phi_tilde_0", None)
    ok_A = isinstance(A, np.ndarray) and A.ndim == 2 and A.shape == (Kp, Kq)
    ok_B = isinstance(B, np.ndarray) and B.ndim == 2 and B.shape == (Kq, Kp)

    return bool(ok_gen and ok_A and ok_B)


# --- in bundle_morphism_utils.py ---

def init_parent_morphisms(P, generators_q, generators_p):
    """
    Ensure a newly spawned parent has base morphisms and computed bundle morphisms.
    - Sets identity Φ₀, Φ̃₀ with correct shapes (Kp×Kq and Kq×Kp).
    - Stores generators on the parent (for later recomputes).
    - Computes bundle_morphism_q_to_p and bundle_morphism_p_to_q once.
    """
    # infer dims from parent's fields
    Kq = int(getattr(P.mu_q_field, "shape", (0,))[-1])
    Kp = int(getattr(P.mu_p_field, "shape", (0,))[-1])
    if Kq <= 0 or Kp <= 0:
        return

    # grid and algebra dims
    HW = getattr(P.mu_q_field, "shape", None)
    H, W = (int(HW[0]), int(HW[1])) if (HW is not None and len(HW) >= 2) else (1, 1)
    d_q = int(getattr(generators_q, "shape", (3,))[0]) if generators_q is not None else 3
    d_p = int(getattr(generators_p, "shape", (3,))[0]) if generators_p is not None else 3

    P.Phi_0       = np.eye(Kp, Kq, dtype=getattr(P.mu_q_field, "dtype", np.float32))
    P.Phi_tilde_0 = np.eye(Kq, Kp, dtype=getattr(P.mu_q_field, "dtype", np.float32))
    P.generators_q = generators_q
    P.generators_p = generators_p

    # make sure phi fields exist (H,W,d)
    if not hasattr(P, "phi") or P.phi is None or P.phi.ndim < 3:
        P.phi = np.zeros((H, W, d_q), dtype=P.Phi_tilde_0.dtype)
    if not hasattr(P, "phi_model") or P.phi_model is None or P.phi_model.ndim < 3:
        P.phi_model = np.zeros((H, W, d_p), dtype=P.Phi_0.dtype)

    # compute initial transported morphisms (broadcast Φ0 if 2D)
    try:
        P.bundle_morphism_q_to_p, P.bundle_morphism_p_to_q = compute_direct_morphisms(
            phi=P.phi, phi_model=P.phi_model,
            generators_q=P.generators_q, generators_p=P.generators_p,
            Phi_0=P.Phi_0, Phi_tilde_0=P.Phi_tilde_0,
        )
    except Exception:
        P.bundle_morphism_q_to_p = np.broadcast_to(P.Phi_0, (H, W, Kp, Kq)).copy()
        P.bundle_morphism_p_to_q = np.broadcast_to(P.Phi_tilde_0, (H, W, Kq, Kp)).copy()




def safe_batch_apply_morphism_nat(mu, sigma, morphism, eps=1e-8):
    """
    Apply morphism Φ to Gaussian parameters (μ, Σ):
        μ'     = Φ μ
        Σ'     = Φ Σ Φᵀ

    Args:
        mu       : (..., K_in)
        sigma    : (..., K_in, K_in)
        morphism : (..., K_out, K_in)

    Returns:
        mu_out   : (..., K_out)
        sigma_out: (..., K_out, K_out), symmetrized and sanitized
    """
    

    # ── Shape validation ──────────────────────────────
    K_in_mu     = mu.shape[-1]
    K_in_sigma1 = sigma.shape[-2]
    K_in_sigma2 = sigma.shape[-1]
    K_in_phi    = morphism.shape[-1]
    K_out_phi   = morphism.shape[-2]

    if not (K_in_mu == K_in_sigma1 == K_in_sigma2 == K_in_phi):
        raise ValueError(
            f"[safe_batch_apply_morphism_nat] Input dimension mismatch:\n"
            f"  mu.shape[-1]      = {K_in_mu}\n"
            f"  sigma.shape[-2:]  = ({K_in_sigma1}, {K_in_sigma2})\n"
            f"  morphism.shape[-1]= {K_in_phi} (expected K_in)"
        )

    # ── Morphism application ──────────────────────────
    mu_out = np.einsum("...ij,...j->...i", morphism, mu)
    sigma_out = np.einsum("...ik,...kl,...jl->...ij", morphism, sigma, morphism)

    # ── Symmetrize and sanitize ───────────────────────
    sigma_out = 0.5 * (sigma_out + np.swapaxes(sigma_out, -1, -2))
    sigma_out = sanitize_sigma(sigma_out, eps=eps)

    return mu_out, sigma_out






#======================================================================
#
#                    Initialization
#
#======================================================================



def generate_smooth_morphism_fieldID(
    H, W,
    K_src, K_tgt,
    sigma=config.gaussian_blur_range_morphism,
    low_rank=None,
    seed=None,
    normalize=False,
    mask=None,
):
    """
    Generate a morphism field Φ(x) ∈ ℝ^{K_tgt × K_src} that approximates an identity
    map on a shared subspace of dim `shared_rank = min(K_src, K_tgt)`.

    Outside the shared rank, remaining components are set to zero.

    Args:
        H, W         : spatial domain
        K_src, K_tgt : source and target fiber dimensions
        shared_rank  : optional, default = min(K_src, K_tgt)
        smooth_sigma : smoothing for blending (e.g. 1.0)
        seed         : RNG seed

    Returns:
        field : (H, W, K_tgt, K_src) array, smooth identity-like map
    """
    
    
    shared_rank = None
    rng = np.random.default_rng(seed)
    R = shared_rank if shared_rank is not None else min(K_src, K_tgt)

    field = np.zeros((H, W, K_tgt, K_src), dtype=np.float32)

    for i in range(R):
        coeff = np.ones((H, W), dtype=np.float32)
        coeff = gaussian_filter(coeff, sigma=1.5, mode="wrap")
        field[..., i, i] = coeff

    return field




def generate_smooth_morphism_field(
    H, W,
    K_src, K_tgt,
    sigma=config.gaussian_blur_range_morphism,
    low_rank=None,
    seed=None,
    normalize=False,
    mask=None,
):
    """
    Generate a smooth spatial field of K_tgt × K_src morphisms,
    optionally low-rank and softly masked to identity outside support.
    """
    from scipy.ndimage import gaussian_filter

    eps = 1e-8
    rng = np.random.default_rng(seed)
    rank = low_rank if low_rank is not None else min(K_src, K_tgt)

    field = np.zeros((H, W, K_tgt, K_src), dtype=np.float32)

    for r in range(rank):
        basis = rng.standard_normal((K_tgt, K_src)).astype(np.float32)
        coeff = rng.standard_normal((H, W)).astype(np.float32)
        coeff = gaussian_filter(coeff, sigma=sigma, mode="wrap")
        field += coeff[..., None, None] * basis[None, None, :, :]

    if normalize:
        norm = np.linalg.norm(field, axis=(-2, -1), keepdims=True)
        norm_safe = np.where(norm > eps, norm, eps)
        field = field / norm_safe

    # ─── Soft blend to identity outside mask ───
    if mask is not None:
        soft_mask = gaussian_filter(mask.astype(np.float32), sigma=1.0)
        soft_mask = np.clip(soft_mask, 0.0, 1.0)[..., None, None]

        I = np.eye(K_tgt, K_src, dtype=np.float32)[None, None, :, :]
        field = soft_mask * field + (1.0 - soft_mask) * I

    return field




def clip_operator_norm(field: np.ndarray, max_norm: float = 1.0, eps: float = 1e-8) -> np.ndarray:
    """
    Enforce operator norm ≤ max_norm for each Φ(x) in (H,W,Kp,Kq)
    """
    H, W, Kp, Kq = field.shape
    field_out = np.empty_like(field)
    for i in range(H):
        for j in range(W):
            Phi = field[i, j]
            u, s, vh = np.linalg.svd(Phi, full_matrices=False)
            s_clipped = np.clip(s, 0, max_norm)
            Phi_clipped = (u @ np.diag(s_clipped) @ vh).astype(field.dtype)
            field_out[i, j] = Phi_clipped
    return field_out




def initialize_morphism_pair( 
    domain_size: Tuple[int, int],
    K_q: int,
    K_p: int,
    rng: np.random.Generator,
    morphism_type: str = "identity",
    mask: Optional[np.ndarray] = None,
    config_tag: str = "",
    phi_q_field: Optional[np.ndarray] = None,
    phi_p_field: Optional[np.ndarray] = None,
    G_q: Optional[np.ndarray] = None,
    G_p: Optional[np.ndarray] = None,
) -> Tuple[np.ndarray, np.ndarray]:
    """
    Initialize bundle morphisms Φ (q→p) and Φ̃ (p→q), optionally with
    full SO(3)-gauge covariance via:
        Φ(x) = exp(φ_p(x)) · Φ₀(x) · exp(−φ_q(x))
    """
    
    H, W = domain_size

    if morphism_type == "identity":
        if K_q != K_p:
            raise ValueError(f"Cannot use identity morphism with mismatched K_q={K_q} and K_p={K_p}")
        eye = np.eye(K_q, dtype=np.float32)
        phi_q_to_p = np.broadcast_to(eye, (H, W, K_q, K_q)).copy()
        phi_p_to_q = np.broadcast_to(eye, (H, W, K_q, K_q)).copy()
        if mask is not None:
            # keep identity outside; (optionally) you could feather to identity,
            # but never zero out.
            soft_mask = gaussian_filter(mask.astype(np.float32), sigma=1.0)
            soft_mask = np.clip(soft_mask, 0.0, 1.0)[..., None, None]
            phi_q_to_p = soft_mask * phi_q_to_p + (1.0 - soft_mask) * phi_q_to_p
            phi_p_to_q = soft_mask * phi_p_to_q + (1.0 - soft_mask) * phi_p_to_q
        return phi_q_to_p, phi_p_to_q


    if morphism_type == "gauge_covariant":
        assert phi_q_field is not None and phi_p_field is not None, "φ_q and φ_p fields required"
        assert G_q is not None and G_p is not None, "SO(3) generators G_q and G_p required"

        sigma = getattr(config, f"morphism_sigma{config_tag}", 1.5)
        rank  = getattr(config, f"morphism_rank{config_tag}", min(K_q, K_p))
        seed  = rng.integers(0, 1e9)

        # Base morphisms
        Phi_0_q_to_p = generate_smooth_morphism_field(
            H, W, K_src=K_q, K_tgt=K_p,
            sigma=sigma, low_rank=rank,
            normalize=False, mask=mask, seed=seed
        )
        Phi_0_p_to_q = generate_smooth_morphism_field(
            H, W, K_src=K_p, K_tgt=K_q,
            sigma=sigma, low_rank=rank,
            normalize=False, mask=mask, seed=seed + 1
        )

        # Apply gauge covariance
        phi_q_to_p = gauge_covariant_transform_phi(
            phi_p_field, phi_q_field, Phi_0_q_to_p,
            G_q=G_q, G_p=G_p
        )
        phi_p_to_q = gauge_covariant_transform_phi(
            phi_q_field, phi_p_field, Phi_0_p_to_q,
            G_q=G_p, G_p=G_q  # flipped
        )
        print(f"[INIT Φ] Φ_q→p stats: mean = {np.mean(phi_q_to_p):.4g}, std = {np.std(phi_q_to_p):.4g}")
        idx = np.random.randint(0, H * W)
        print("[Φ_q→p sample]", phi_q_to_p.reshape(-1, K_p, K_q)[idx])

        # ─── Soft masking via identity fallback ───
        if mask is not None:
            soft_mask = gaussian_filter(mask.astype(np.float32), sigma=1.0)
            soft_mask = np.clip(soft_mask, 0.0, 1.0)[..., None, None]

            I_qp = np.eye(K_p, K_q, dtype=np.float32)[None, None, :, :]
            I_pq = np.eye(K_q, K_p, dtype=np.float32)[None, None, :, :]

            phi_q_to_p = soft_mask * phi_q_to_p + (1.0 - soft_mask) * I_qp
            phi_p_to_q = soft_mask * phi_p_to_q + (1.0 - soft_mask) * I_pq

        return phi_q_to_p, phi_p_to_q

    # Else: generic smooth/lowrank morphism
    sigma     = getattr(config, f"morphism_sigma{config_tag}", 1.5)
    rank      = getattr(config, f"morphism_rank{config_tag}", min(K_q, K_p))
    normalize = getattr(config, f"morphism_normalize{config_tag}", True)
    seed      = rng.integers(0, 1e9)

    phi_q_to_p = generate_smooth_morphism_field(
        H, W, K_src=K_q, K_tgt=K_p,
        sigma=sigma, low_rank=rank,
        normalize=False, mask=mask, seed=seed
    )
    phi_p_to_q = np.swapaxes(phi_q_to_p, -1, -2)

    if normalize:
        phi_q_to_p = clip_operator_norm(phi_q_to_p, max_norm=1.0)
        phi_p_to_q = clip_operator_norm(phi_p_to_q, max_norm=1.0)

    return phi_q_to_p, phi_p_to_q



def generate_morphism_pair(
    H, W,
    K_q, K_p,
    rank=None,
    sigma=1.5,
    seed=None,
    mask=None,
    s_floor=0.05,
    s_scale=0.25,
    dtype=np.float32,
):
    """
    Build a *paired* rectangular morphism field (Φ0, Φ̃0) with shared low-rank frames:
        Φ0(x)   = U  S(x) Vᵀ   ∈ ℝ^{K_p × K_q}
        Φ̃0(x)  = V  S(x) Uᵀ   ∈ ℝ^{K_q × K_p}

    - U ∈ ℝ^{K_p×r}, V ∈ ℝ^{K_q×r} are global orthonormal frames (fixed across space).
    - S(x) = diag(s_1(x),...,s_r(x)) are *positive*, *smooth* per-pixel singular values.
    - If `mask` is provided, we softly zero S(x) outside support.

    Returns:
        Phi_0        : (H, W, K_p, K_q)
        Phi_tilde_0  : (H, W, K_q, K_p)
    """
    rng = np.random.default_rng(seed)
    r = rank if rank is not None else min(K_q, K_p)

    # Global orthonormal frames (fixed across space)
    U0, _ = np.linalg.qr(rng.standard_normal((K_p, r)))
    V0, _ = np.linalg.qr(rng.standard_normal((K_q, r)))

    # Smooth positive singular spectra per pixel
    # Start with r random fields, smooth them, then enforce positivity and floor
    S_fields = []
    for _ in range(r):
        f = rng.standard_normal((H, W)).astype(dtype)
        f = gaussian_filter(f, sigma=sigma, mode="wrap")
        f = np.abs(f) * s_scale + s_floor  # positive, bounded away from 0
        if mask is not None:
            f = f * mask  # softly suppress outside support
        S_fields.append(f)
    # Stack to (H, W, r)
    S_stack = np.stack(S_fields, axis=-1)  # (H, W, r)

    
    # Build diag S(x) explicitly as (H,W,r,r) but efficiently
    S_diag = np.zeros((H, W, r, r), dtype=dtype)
    idx = np.arange(r)
    S_diag[..., idx, idx] = S_stack

    # Φ0: (H,W,K_p,K_q) = U0 (K_p,r) · S(x) (r,r) · V0ᵀ (r,K_q)
    Phi_0 = np.einsum("pr,hwrs,sq->hwpq", U0.astype(dtype), S_diag, V0.T.astype(dtype))

    # Φ̃0: (H,W,K_q,K_p) = V0 (K_q,r) · S(x) (r,r) · U0ᵀ (r,K_p)
    Phi_tilde_0 = np.einsum("qr,hwrs,sp->hwqp", V0.astype(dtype), S_diag, U0.T.astype(dtype))

    return Phi_0, Phi_tilde_0


def gauge_covariant_transform_phi(
    phi_p, phi_q, Phi0, G_q, G_p, group_name="so3", eps=1e-8
):
    """
    Φ(x) = exp(φ_p(x)) · Φ₀(x) · exp(−φ_q(x))
    """
    exp_phi_p = exp_lie_algebra_irrep(phi_p, G_p, group_name=group_name)  # (..., Kp,Kp)
    exp_phi_q = exp_lie_algebra_irrep(phi_q, G_q, group_name=group_name)  # (..., Kq,Kq)

    if group_name.lower() == "so3":
        exp_neg_phi_q = np.swapaxes(exp_phi_q, -1, -2)
    else:
        # safer default for non-orthogonal reps
        exp_neg_phi_q = exp_lie_algebra_irrep(-np.asarray(phi_q), G_q, group_name=group_name)

    return np.einsum("...ik,...kj,...jl->...il", exp_phi_p, Phi0, exp_neg_phi_q, optimize=True)




def recompute_agent_morphisms(
    agent,
    *,
    generators_q: Optional[np.ndarray] = None,
    generators_p: Optional[np.ndarray] = None,
    allow_make_bases: bool = True,
) -> None:
    """
    Rebuild agent.bundle_morphism_q_to_p and agent.bundle_morphism_p_to_q
    from current (phi, phi_model, Phi_0, Phi_tilde_0) with gauge transport.

    Side effects:
      - Ensures generators on agent if provided (agent.ensure_generators).
      - Creates identity Φ₀/Φ̃₀ if absent (when allow_make_bases=True).
      - Sets agent.morphisms_dirty = False on success.

    Requirements:
      - agent.mu_q_field (..., Kq), agent.mu_p_field (..., Kp) exist.
      - agent.phi, agent.phi_model are (H,W,3) for SO(3) (your schema).
    """
    # 0) Ensure generators are set on the agent (uses your schema helper)
    if hasattr(agent, "ensure_generators"):
        agent.ensure_generators(generators_q, generators_p)
    Gq = getattr(agent, "generators_q", generators_q)
    Gp = getattr(agent, "generators_p", generators_p)

    if Gq is None or Gp is None:
        raise ValueError("recompute_agent_morphisms: generators_q/p required or must be present on agent")

    # 1) Infer fiber sizes
    try:
        Kq = int(agent.mu_q_field.shape[-1])
        Kp = int(agent.mu_p_field.shape[-1])
    except Exception as e:
        raise ValueError("recompute_agent_morphisms: agent.mu_q_field / mu_p_field missing or malformed") from e

    # 2) Ensure base morphisms Φ₀, Φ̃₀ exist (identities if missing)
    if getattr(agent, "Phi_0", None) is None:
        if not allow_make_bases:
            raise ValueError("recompute_agent_morphisms: Phi_0 missing and allow_make_bases=False")
        agent.Phi_0 = np.eye(Kp, Kq, dtype=agent.mu_q_field.dtype)
    if getattr(agent, "Phi_tilde_0", None) is None:
        if not allow_make_bases:
            raise ValueError("recompute_agent_morphisms: Phi_tilde_0 missing and allow_make_bases=False")
        agent.Phi_tilde_0 = np.eye(Kq, Kp, dtype=agent.mu_q_field.dtype)

    # 3) Compute transported rectangular morphisms with broadcasting
    Phi, Phi_tilde = compute_direct_morphisms(
        phi=agent.phi,
        phi_model=agent.phi_model,
        generators_q=Gq,
        generators_p=Gp,
        Phi_0=agent.Phi_0,
        Phi_tilde_0=agent.Phi_tilde_0,
    )

    # 4) Store & mark clean
    agent.bundle_morphism_q_to_p = Phi
    agent.bundle_morphism_p_to_q = Phi_tilde
    if hasattr(agent, "morphisms_dirty"):
        agent.morphisms_dirty = False


def mark_morphism_dirty(agent) -> None:
    """
    Convenience function to invalidate an agent's Φ/Φ̃ caches.
    Calls Agent.mark_morphism_dirty() when present; otherwise performs a safe fallback.
    """
    if hasattr(agent, "mark_morphism_dirty"):
        agent.mark_morphism_dirty()
        return
    # Fallback if method not attached yet
    setattr(agent, "morphisms_dirty", True)
    agent.bundle_morphism_q_to_p = None
    agent.bundle_morphism_p_to_q = None


