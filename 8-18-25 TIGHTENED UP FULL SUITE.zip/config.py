import numpy as np
import sys

# ===========================
# DEBUGGING AND UTILITIES
# ===========================


def set_config_from_params(params):
    """Dynamically override config attributes from a dictionary."""
    this_module = sys.modules[__name__]
    for k, v in params.items():
        setattr(this_module, k, v)

epsilon_model      = 1      # Threshold to classify meta-agents (can sweep)

# config.py
phi_morphism_type       = "gauge_covariant"         # identity  gauge_covariant 
phi_model_morphism_type = "gauge_covariant"

morphism_normalize    = True
coarsegrain_each_step = True


agent_seed    = 426558 

# Toggle between diagonal and full Σ initialization
diagonal_sigma = False



# ===========================
# DOMAIN / SPATIAL SETTINGS
# ===========================
K_q           = 5
K_p           = 7       # Fiber dimension of belief/model space (depends on representation)
                 
D             = 2           #dimension of base manifold - d=2 validated

L             = 50         #length of hypercubic base-manifold - PBCs

steps         = 100

N             = 10                       # Number of agents
max_neighbors = 10        # Max number of agent neighbors

n_jobs = N

agent_radius_range = (6,6)         #agent radii
fixed_location = False 

     
# ===========================
# COUPLINGS & PENALTIES
# ===========================

alpha                  = 0.25
beta                   = 1
belief_mass            = 1
curvature_weight       = 1

feedback_weight         = 0
beta_model              = 1
model_mass              = 1
model_curvature_weight  = 1

entropy_weight          = 0


#==========================
#    IF NEEDED/CURIOUS
#==========================
exp_n_jobs = 12

phi_coupling_weight           = 0             # set > 0 to enable
phi_coupling_mode             = "projection"  # or "conjugation"


fisher_geometry_weight        = 0      
fisher_model_geometry_weight  = 0

# ===========================
# INITIALIZATION
# ===========================

# ─── Belief Bundle (q) Parameters ───
q_mu_range                     = (-1.0, 1.0)              # Range for μ_q
q_sigma_range                  = (0.2, 1.0)           # Diagonal Σ_q entries

belief_noise_scale_mu          = 0.01         # Additive noise for μ_q
belief_noise_scale_sigma       = 0.01      # Additive noise for Σ_q


# ─── Model Bundle (p) Parameters ───
p_mu_range                     = (-1.0, 1.0)             # Range for μ_p
p_sigma_range                  = (0.2, 1.0)           # Diagonal Σ_p entries

model_noise_scale_mu           = 0.01          # Additive noise for μ_p
model_noise_scale_sigma        = 0.01       # Additive noise for Σ_p

sigma_outside_val              = 1e3  # large uncertainty outside support




#===========================================================================
#
#                            EMERGENCE
#
#============================================================================
# ===== CORE EMERGENCE (Priority 0) =====
detector_period       = 1     # steps between detector passes (higher = less frequent updates)
seed_min_kids         = 2     # ≥ this many children must cover a pixel to be a candidate
emerge_min_area       = 3     # minimum connected-component area (px) to keep a region
parent_weight_tau     = None   # interior-weight gate for candidates; None disables (higher = stricter)
emerge_tau            = None  # optional per-pixel agreement/KL floor inside a region; None disables

# Global agree gate: choose ONE path
detector_agree_auto       = True   # if True, compute a moving gate from global agreement aggregates
detector_agree_percentile = 65.0   # percentile used for the auto gate (e.g., 65th pct of A_agg)
detector_agree_ema        = 0.2    # EMA smoothing factor for the auto gate (0=no memory, 1=very slow)
agree_gate_tau            = None   # fixed global floor if auto is False; set a float to force a manual gate

# Agreement temps used by detector KL mapping
blend_qp_alpha = 0.5  # blend of model vs belief evidence: 0=belief-only, 1=model-only
tau_align_q    = 0.3  # temperature for belief-KL→agreement mapping (smaller = harsher penalty)
tau_align_p    = 0.3  # temperature for model-KL→agreement mapping (smaller = harsher penalty)

# Support floors
detector_mask_tau = 1e-3  # child support floor when building activity/regions (lower = more permissive)
child_support_tau = 1e-4  # min child support to count pairwise overlap (higher = stricter)

# Spawn evidence/novelty & cap
spawn_min_cover2_px = 2    # min pixels where ≥2 kids overlap to even consider a parent spawn
spawn_nms_iou       = 0.25 # NMS IoU to deduplicate new seeds (lower = more aggressive dedup)
spawn_min_dist_px   = 2.0  # min manhattan/centroid distance between new seeds (spreads them out)
parent_max_new_per_step = 2  # hard cap on new parents per step (controls growth rate)

# ===== OFTEN TUNED (Priority 1) =====
# Soft-mask dynamics
parent_eta_up        = 1e-2  # growth step size for parent soft mask (smaller = slower, stabler growth)
parent_eta_down      = 1e-2 # shrink step size for parent soft mask (smaller = slower decay)
parent_delta_cap     = 0.05  # per-step absolute cap on mask change (limits flicker)
parent_feather_sigma = 0.5   # gaussian feathering on mask edges (higher = softer boundaries)

# Seeds / validity / continuity
parent_support_tau            = 1e-1 # support τ used when validating/matching seeds smaller values merge parents
parent_proposal_local_tau     = 1e-1 # local evidence floor within a proposed region (filters weak blobs)
parent_min_seed_area_px       = 2    # min area for a seed after clamping
parent_min_seed_px            = 2    # min nonzero pixels to keep a seed
parent_assign_min_overlap_px  = 2    # min child↔parent overlap (px) to allow assignment
parent_continuity_radius_px   = 3    # search window around prior center to retain the same parent ID
parent_continuity_iou_thr     = 0.45 # IoU threshold to treat a candidate as the same region across steps
parent_continuity_child_jacc_keep_thr = 0.75 # keep prior child_ids if Jaccard(child-set) ≥ this

# Matching / spacing / dedup
parent_match_iou_existing       = 0.25 # if IoU with an existing parent ≥ this, treat as match (not a new parent)
parent_match_child_jaccard_thr  = 0.85 # require high child-set similarity to match (guards against ID churn)
spacing_child_jaccard_thr       = 0.90 # block seeds that are too similar in child-set to an existing one
spacing_child_subset_thr        = 0.90 # block seeds whose child-set is mostly a subset of an existing one
parent_peak_dedup_radius_px     = 3    # radius for peak-level NMS to avoid multiple seeds in one blob
parent_peak_dedup_child_jaccard = 0.92 # merge peaks if their child-sets are nearly identical
parent_peak_dedup_subset_thr    = 0.90 # merge peaks if one peak's child-set is mostly contained in another

# Assignment (child→parent)
parent_assign_core_tau     = 0.1 # absolute floor to define a parent's “core” mask for assignment anchoring
parent_assign_core_tau_rel = 0.1 # relative-to-max floor for the core (fraction of parent.max())
parent_assign_core_dilate  = 1    # morphological dilation (iters) applied to the core (stability)
parent_soft_assign_tau     = 1e-4 # prune tiny assignment weights below this floor
parent_soft_assign_temp    = 0.5 # temperature for (entmax/sparsemax/softmax): lower = peakier assignments
parent_soft_assign_topk    = 3    # limit to top-k parents per child (sparsifies links)

parent_assign_activation   = "entmax" # assignment normalizer: 'entmax' (sparse), 'sparsemax', or 'softmax'

parent_assign_null_enabled = True  # include a “null parent” option when assigning children
parent_assign_null_logit   = 0.0   # baseline logit for the null parent (bias toward/against null)
parent_assign_null_tau     = 0.5   # temperature shaping competitiveness of the null parent

parent_assign_use_agreement = False # if True, modulate assignment logits by agreement A(x)
parent_assign_agree_weight  = 1.0   # exponent/weight for A(x) when the above is True
parent_assign_iou_add_thr   = 0.5   # IoU needed to add a child→parent link
parent_assign_iou_keep_thr  = 0.3   # IoU needed to keep an existing child→parent link


# ===== ADVANCED / RARE (Priority 2) =====
parent_freeze_steps       = 4
parent_active_level       = None
parent_active_level_q     = 60.0
parent_active_level_rel   = 0.60
parent_active_level_min   = 0.06
parent_active_min_cc_px   = 2
parent_active_iou_min     = 0.5
parent_hysteresis_keep_frac = 0.50
parent_seed_erode_iters   = 1
signal_kl_cap             = 5
coalition_cover_n         = 2
coalition_high_tau        = 0.18
coalition_low_tau         = 0.06

# ===== DEBUG / EXPERIMENTAL (Priority 3) =====
debug_detector_log     = True
debug_spawn_log        = False
debug_spawn_log_details= True
debug_strict           = True

detector_multiscale        = True
detector_multiscale_scales = (1.0, 0.5, 0.25)

spawn_confidence_tau   = None   #none for auto below
spawn_conf_auto        = True
spawn_conf_ema         = 0.30



#======================
#
#   LEARNING RATES
#
#======================
tau_phi                 = 1e-4
tau_phi_model           = 1e-4    
tau_mu_belief           = 1e-5       # update rate for η₁_q
tau_sigma_belief        = 1e-5       # update rate for η₂_q
tau_mu_model            = 1e-5      # update rate for η₁_p
tau_sigma_model         = 1e-5       # update rate for η₂_p

phi_init_smooth_sigma   = 1.5
phi_init                = 0.1
phi_model_offset        = 0.1

eta_ema_alpha                   = 0.6          # try 0.4–0.8
eta_phi_adaptive_scaling        = 1.0
eta_phi_model_adaptive_scaling  = 1.0
eta_sigma_condition_scaling     = 0.1   # start small
sigma_eig_floor                 = 1e-6
sigma_cond_cap                  = 1e4

sigma_eig_cap                   = None          # usually None
sigma_trace_target              = None     # or K if you want trace control

eta_phi_min           = 1e-6
eta_phi_model_min     = 1e-6

#==========================================
#
#       META-AGENTS
#
#==========================================
# Cross-scale toggles
enable_crossscale = True

# Weights (q-fiber)
beta_up_q = 0.30   # child → parent
beta_dn_q = 0.10   # parent → children (smaller at first)

# Weights (p-fiber) — off for now; turn on later
beta_up_p = 0.2
beta_dn_p = 0.2

# Cross-bundle Θ terms — not implemented yet, keep 0
gamma_theta_up = 0.00
gamma_theta_dn = 0.00

# Functorial penalties (intertwining) — not implemented yet, keep 0
lambda_functor_q = 0.00
lambda_functor_p = 0.00

# Clustering / aggregation
overlap_eps = 1e-3

# Logging & seeding
xscale_log_every = 1
xscale_seed_lambda_dn_q = True      # good instant KL drop
xscale_lambda_ridge     = 1e-3      # for the Procrustes seed

# Cross-scale (model side)
enable_crossscale_p      = True
lambda_xscale_q = 0.05

xscale_lr_mu_p_up        = 0.01
xscale_lr_sigma_p_up     = 0.005
xscale_lr_mu_p_dn        = 0.01
xscale_lr_sigma_p_dn     = 0.005


# ===========================
# AGENT GEOMETRY
# ===========================
gaussian_blur_range_morphism = (1,2)
mu_clip = 3.0

#================================
#
#  INITIALIZE GLOBAL FIELDS 
#      WITH GENTLE NOISE
#================================
use_global_belief_template = False
use_global_model_template  = False

identical_models = False         # If True, all agents share the same p, mu_p_field, sigma_p_field


# ===========================
# STABILITY AND CLIPPING
# ===========================
                                # Gradient clipping magnitudes (optional; set to None to disable)
phi_grad_clip             = 1e5    # Max L2 norm per-point for φ update
phi_model_grad_clip       = 1e5    # Max L2 norm per-point for φ̃ update

                                     # Optional: norm type (future-proofing, L2 is default)
gradient_clip_norm_type   = 2           # Use 2 for L2 norm; 1 for L1, np.inf for max-norm
phi_exp_clip              = np.pi  # or 2π if you're okay with aliasing


mask_sharpness        = 1.5
# ===========================
# EPSILONS & NUMERICAL STABILITY
# ===========================

log_eps            = 1e-6     # Stabilize log(x)
eps                = 1e-5
# ===========================
# MASK & INTERACTION THRESHOLDS
# ===========================

support_cutoff_eps = 1e-3    # Mask threshold to include point in agent support
overlap_eps        = 1e-3     # Threshold for computing inter-agent overlap


# ===========================
# CHECKPOINTING
# ===========================

checkpoint_dir      = "checkpoints"
precision = np.float32

checkpoint_interval = 1

domain_size = (L,) * D
num_cores = 1  # or however many threads you want to use
group_name = 'so3'               # Options: "u1", "so3", "so3", 'su2'.

phi_bch_max_norm = 25.0
# Enable numerical safety logging
debug = True  # Global debug flag for extra logging inside φ updates                       
fail_on_fallback = False                # Allow recovery rather than crashing


#=================
#    LOGDET
#=================
# ── Numerical Safeguards ─────────────────────────────
max_fisher_condition = 1e5   # Maximum allowed condition number before fallback


# Control fallback thresholds (optional)
max_safe_inv_fallbacks = 1000
max_safe_logdet_fallbacks = 1000

# ─────────────────────────────────────────────────────────
# Logging / dump toggles (matches new logger + field dumper)
# ─────────────────────────────────────────────────────────
logging = dict(
    enable_fields=True,
    fields_every=1,
    compute_alignment=True,   # if you want KL fields
    compute_curvature=True,   # if you want curvature norms
    compute_morphisms=True,   # <— this turns on Φ/Φ̃/Λ norms
    fp16_snapshot=True,
    full_field_outdir="fields",
)


# Keep this True if any legacy gate still checks it (safe to include)
log_full_fields = True
periodic_x = True          # set per your sim
periodic_y = True