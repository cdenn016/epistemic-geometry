# -*- coding: utf-8 -*-
"""
Created on Tue Aug 12 18:56:28 2025

@author: chris and christine
"""

from agent_initialization import initialize_agent_gradients
import numpy as np
import config
from numerical_utils import resize_nn

def _coarsegrain_gaussian_basic(parent, children, *, which="belief",
                                mask_tau=0.3, use_rotation=False,
                                eps=1e-8, shrink_to_I=0.05, cond_cap=1e6):
    """
    Coarse-grain per-pixel Gaussians from children into a parent (H,W,K)/(H,W,K,K).
    Modes:
      - "precision" (default): precision-pooled Σ and μ (natural-parameter average)
      - "log": log-Euclidean mean for Σ, arithmetic mean for μ (both with the same weights)
    Optional morphism-based rotation transport (child→parent frame).
    SPD ridge + condition capping applied at the end.
    """
    
    from numerical_utils import resize_nn

    gamma    = float(getattr(config, "cg_consensus_gamma", 1.0))
    use_rot  = bool(getattr(config, "cg_use_morphisms", use_rotation))
    sigma_mode = str(getattr(config, "cg_sigma_mode", "precision")).lower()
    dbg      = bool(getattr(config, "cg_debug_shapes", False))

    pid = getattr(parent, "id", "?")
    def D(msg):
        if dbg: print(f"[CG/DBG p={pid} {which[0]}] {msg}")

    # field selectors
    if which == "belief":
        get_mu = lambda A: np.asarray(A.mu_q_field, dtype=np.float64)
        get_S  = lambda A: np.asarray(A.sigma_q_field, dtype=np.float64)
        out_dtype = getattr(getattr(parent, "mu_q_field", None), "dtype", np.float32)
        get_Om = (lambda A: _get_omega(A, "phi", A.generators_q,
                                       fallback_dim=get_mu(A).shape[-1]).astype(np.float64)
                  ) if use_rot else None
    else:
        get_mu = lambda A: np.asarray(A.mu_p_field, dtype=np.float64)
        get_S  = lambda A: np.asarray(A.sigma_p_field, dtype=np.float64)
        out_dtype = getattr(getattr(parent, "mu_p_field", None), "dtype", np.float32)
        get_Om = (lambda A: _get_omega(A, "phi_model", A.generators_p,
                                       fallback_dim=get_mu(A).shape[-1]).astype(np.float64)
                  ) if use_rot else None

    # shapes / support
    mP = np.asarray(parent.mask, np.float32).squeeze()
    if mP.ndim != 2: raise RuntimeError(f"Parent mask shape {mP.shape} (expected (H,W)).")
    H, W = mP.shape
    muP0 = get_mu(parent)
    if muP0.ndim != 3 or muP0.shape[:2] != (H, W):
        raise RuntimeError(f"Parent mu field shape {muP0.shape} (expected (H,W,K)).")
    K = int(muP0.shape[-1])
    I = np.eye(K, dtype=np.float64)
    support = (mP > mask_tau)

    if dbg:
        try:
            D(f"HW={(H,W)} K={K} use_rot={use_rot} mode={sigma_mode}")
            D(f"parent.mu {np.asarray(get_mu(parent)).shape}")
            D(f"parent.S  {np.asarray(get_S(parent)).shape}")
        except Exception as e:
            D(f"parent probe err: {e}")

    # parent rotation (or identity)
    Rp = cg_ensure_rot_4d(get_Om(parent), H, W, K, I) if use_rot else np.broadcast_to(I, (H, W, K, K))

    # accumulators
    # common
    Wsum      = np.zeros((H, W),      dtype=np.float64)
    # for "precision" mode
    Psum      = np.zeros((H, W, K, K), dtype=np.float64)  # sum of weighted precisions
    h_sum     = np.zeros((H, W, K),    dtype=np.float64)  # sum of weighted precision*mu
    # for "log" mode
    sum_logS  = np.zeros((H, W, K, K), dtype=np.float64)  # sum of w*log Σ
    mu_sum    = np.zeros((H, W, K),    dtype=np.float64)  # sum of w*mu (arithmetic)

    # accumulate from children
    for C in children:
        mC = np.asarray(getattr(C, "mask", 0.0), np.float32).squeeze()
        if mC.shape != (H, W): mC = resize_nn(mC, (H, W)).astype(np.float32)
        w = cg_mask_weight(mC, support, mask_tau, gamma)    # (H,W) in [0,1]
        if not np.any(w > 0):
            if dbg: D(f"child {getattr(C,'id','?')}: no overlap")
            continue

        muC, SC = get_mu(C), get_S(C)
        if muC.shape != (H, W, K) or SC.shape != (H, W, K, K):
            raise RuntimeError(f"Child fields must match (H,W,K)/(H,W,K,K). "
                               f"Got mu{muC.shape} S{SC.shape} vs {(H,W,K)}.")

        # rotate into parent frame if requested
        if use_rot:
            try:
                Rc   = cg_ensure_rot_4d(get_Om(C), H, W, K, I)
                Rrel = Rp @ Rc.swapaxes(-1, -2)            # parent <- child
            except Exception:
                Rrel = np.broadcast_to(I, (H, W, K, K))
        else:
            Rrel = np.broadcast_to(I, (H, W, K, K))

        muT = (Rrel @ muC[..., None])[..., 0]              # (H,W,K)
        ST  = Rrel @ SC @ Rrel.swapaxes(-1, -2)            # (H,W,K,K)
        ST  = 0.5 * (ST + ST.swapaxes(-1, -2)) + eps * I   # SPD guard

        # eigonce for ST
        wS, VS = cg_eigh_sym(ST)
        invS   = cg_spd_from_eig(wS, VS, lambda x: 1.0/x, eps)     # Σ^{-1}

        w4 = w[..., None, None]
        w3 = w[..., None]

        # precision mode accumulators
        Psum  += w4 * invS
        h_sum += w3 * (invS @ muT[..., None])[..., 0]

        # log mode accumulators
        sum_logS += w4 * cg_spd_from_eig(wS, VS, np.log, eps)      # log Σ
        mu_sum   += w3 * muT

        Wsum += w

    # finalize
    mu_out = np.zeros((H, W, K),   dtype=np.float64)
    S_out  = np.broadcast_to(I, (H, W, K, K)).copy()

    active = (Wsum > 0)
    if np.any(active):
        Wsafe = np.maximum(Wsum, 1.0)

        if sigma_mode == "precision":
            # normalized natural-parameter pooling
            P = Psum / Wsafe[..., None, None]                       # (H,W,K,K)
            wP, VP = cg_eigh_sym(P)
            # invert with floor
            Sigma = cg_spd_from_eig(np.clip(wP, eps, None), VP, lambda x: 1.0/x, eps)
            rhs   = (h_sum / Wsafe[..., None])[..., None]           # (H,W,K,1)
            mu_cons = (Sigma @ rhs)[..., 0]
        else:  # "log"
            M    = sum_logS / Wsafe[..., None, None]                # mean log Σ
            wM, VM = cg_eigh_sym(M)
            Sigma  = cg_spd_from_eig(np.clip(wM, np.log(eps), None), VM, np.exp, eps)
            mu_cons = (mu_sum / Wsafe[..., None])                   # arithmetic

        # shrink & cap
        Sigma = (1.0 - shrink_to_I) * Sigma + shrink_to_I * I
        Sigma = cg_cap_condition(Sigma, eps, cond_cap)

        # write into support only
        mu_out[active & support, :]      = mu_cons[active & support, :]
        S_out[active & support, :, :]    = Sigma[active & support, :, :]

    # strict shapes (remove only singleton leading dims if present)
    if mu_out.ndim == 4 and 1 in mu_out.shape[:3]:
        mu_out = np.squeeze(mu_out, axis=tuple(i for i in range(3) if mu_out.shape[i] == 1))
    if S_out.ndim == 5 and 1 in S_out.shape[:3]:
        S_out = np.squeeze(S_out, axis=tuple(i for i in range(3) if S_out.shape[i] == 1))

    if S_out.shape != (H, W, K, K) or mu_out.shape != (H, W, K):
        raise RuntimeError(f"Bad shapes after coarsegrain: mu{mu_out.shape} S{S_out.shape}")

    return mu_out.astype(out_dtype), S_out.astype(out_dtype)


def coarsegrain_parent_from_children(parent, children, *, eps=1e-6, mask_tau=0.3):
    """
    Populate parent's μ/Σ (belief & model) by coarse-graining children's aligned Gaussians.
    - Uses per-parent child weights if available:
        * preferred: parent.child_weights = {child_id: w_ij}
        * fallback : child.labels = {parent_id: w_ij}
      Otherwise defaults to 1.0.
    - Weights are applied by scaling each child's effective mask within the parent region.
    - Λ-free, SPD-safe, rotation-only transport (delegated to _coarsegrain_gaussian_basic).
    """
    import numpy as np
    

    # --- shape contracts ---------------------------------------------------
    parent.mask = np.asarray(parent.mask, np.float32)
    if parent.mask.ndim != 2:
        parent.mask = np.squeeze(parent.mask)
    if parent.mask.ndim != 2:
        raise RuntimeError(f"Parent mask has bad shape {parent.mask.shape} (expected (H,W)).")
    H, W = parent.mask.shape

    def _chk_field(name, arr, nd):
        if arr is None: return
        A = np.asarray(arr)
        if A.ndim != nd:
            raise RuntimeError(f"{name} has bad shape {A.shape} (expected {nd}D).")

    _chk_field("parent.mu_q_field",    getattr(parent, "mu_q_field", None),    3)
    _chk_field("parent.sigma_q_field", getattr(parent, "sigma_q_field", None), 4)
    _chk_field("parent.mu_p_field",    getattr(parent, "mu_p_field", None),    3)
    _chk_field("parent.sigma_p_field", getattr(parent, "sigma_p_field", None), 4)

    for C in children:
        m = np.asarray(getattr(C, "mask", 0.0))
        if m.ndim != 2:
            mm = np.squeeze(m)
            if mm.ndim != 2:
                raise RuntimeError(f"Child {getattr(C,'id','?')} mask shape {m.shape} (expected (H,W)).")
        _chk_field("child.mu_q_field",    getattr(C, "mu_q_field", None),    3)
        _chk_field("child.sigma_q_field", getattr(C, "sigma_q_field", None), 4)
        _chk_field("child.mu_p_field",    getattr(C, "mu_p_field", None),    3)
        _chk_field("child.sigma_p_field", getattr(C, "sigma_p_field", None), 4)

    # --- build weighted child views (mask scaled by assignment weight × overlap) ----
    pid = int(getattr(parent, "id", -1))
    has_weights = isinstance(getattr(parent, "child_weights", None), dict)

    # parent support gate
    Pcore = (parent.mask > float(mask_tau))

    weighted_children = []
    for C in children:
        # find weight for this parent
        w = None
        if has_weights:
            w = getattr(parent, "child_weights", {}).get(int(getattr(C, "id", -1)), None)
        if w is None:
            labs = getattr(C, "labels", {}) or {}
            if isinstance(labs, dict) and pid in labs:
                w = labs[pid]
        if w is None:
            w = 1.0
        w = float(max(0.0, w))
        if w <= 0.0:
            continue

        Cm = np.asarray(getattr(C, "mask", 0.0), np.float32)
        if Cm.shape != (H, W):
            # simple nearest resize; prefer your existing util if available
            try:
                
                Cm = resize_nn(Cm, (H, W)).astype(np.float32)
            except Exception:
                # fallback: broadcast or pad/trim naïvely
                Cm = np.asarray(Cm, np.float32)
                if Cm.ndim != 2:
                    Cm = np.squeeze(Cm)
                if Cm.shape != (H, W):
                    raise RuntimeError(f"Cannot resize child mask from {Cm.shape} to {(H,W)}")
        # gate by parent core region to avoid far-field bleed
        eff_mask = w * np.where(Pcore, Cm, 0.0).astype(np.float32)

        # create a lightweight view object with scaled mask (other fields shared)
        class _ChildView:
            __slots__ = ("id", "mask", "mu_q_field", "sigma_q_field", "mu_p_field", "sigma_p_field")
            pass
        V = _ChildView()
        V.id = int(getattr(C, "id", -1))
        V.mask = eff_mask
        V.mu_q_field    = getattr(C, "mu_q_field", None)
        V.sigma_q_field = getattr(C, "sigma_q_field", None)
        V.mu_p_field    = getattr(C, "mu_p_field", None)
        V.sigma_p_field = getattr(C, "sigma_p_field", None)

        # skip if nothing overlaps after gating
        if np.count_nonzero(V.mask > float(eps)) == 0:
            continue

        weighted_children.append(V)

    if not weighted_children:
        # nothing to coarse-grain; keep existing fields if present
        return

    # --- run coarse-graining (rotation-only transport) ---------------------
    mu_q, Sig_q = _coarsegrain_gaussian_basic(
        parent, weighted_children, which="belief", mask_tau=mask_tau,
        use_rotation=True,  eps=max(eps, 1e-8),
        shrink_to_I=float(getattr(config, "cg_shrink_I", 0.05)),
        cond_cap=float(getattr(config, "cg_cond_cap", 1e6)),
    )
    parent.mu_q_field    = mu_q
    parent.sigma_q_field = Sig_q

    mu_p, Sig_p = _coarsegrain_gaussian_basic(
        parent, weighted_children, which="model", mask_tau=mask_tau,
        use_rotation=True,  eps=max(eps, 1e-8),
        shrink_to_I=float(getattr(config, "cg_shrink_I", 0.05)),
        cond_cap=float(getattr(config, "cg_cond_cap", 1e6)),
    )
    parent.mu_p_field    = mu_p
    parent.sigma_p_field = Sig_p

    # --- sanitize SPD ------------------------------------------------------
    try:
        from numerical_utils import sanitize_sigma
        parent.sigma_q_field = sanitize_sigma(parent.sigma_q_field)
        parent.sigma_p_field = sanitize_sigma(parent.sigma_p_field)
    except Exception:
        pass

    # --- ensure gradient buffers exist (best-effort) -----------------------
    try:
        initialize_agent_gradients(parent)
    except Exception:
        pass







def coarsen_phi_from_children(parent, children, *, field: str = "phi",
                              weight_mode: str = "mask", max_norm: float = np.pi, eps: float = 1e-6) -> None:
    """
    Build parent.{phi or phi_model} by weighted average of child fields in algebra (H,W,3).
    field: "phi" or "phi_model"
    weight_mode: "mask" | "mask*overlap" | callable(child)->(H,W,1)
    """
    if not getattr(parent, "child_ids", None):
        return
    C = len(parent.child_ids)

    phi_stack, w_stack = [], []
    for cid in parent.child_ids:
        ch = children[cid]
        phi_c = getattr(ch, field)               # (H,W,3)
        phi_stack.append(phi_c[..., :3][None, ...])
        if callable(weight_mode):
            w = weight_mode(ch)
        else:
            if weight_mode == "mask":
                w = ch.mask[..., None]
            elif weight_mode == "mask*overlap":
                w = (ch.mask * parent.mask)[..., None]
            else:
                w = ch.mask[..., None]
        w_stack.append(w[None, ...])

    phi_stack = np.concatenate(phi_stack, axis=0)   # (C,H,W,3)
    w_stack   = np.concatenate(w_stack,   axis=0)   # (C,H,W,1)

    phi_parent = weighted_mean_field(phi_stack, w_stack, eps=eps)  # (H,W,3)

    # clip radius for safety
    norms = np.linalg.norm(phi_parent, axis=-1, keepdims=True) + 1e-12
    scale = np.minimum(1.0, max_norm / norms)
    phi_parent = phi_parent * scale
    setattr(parent, field, phi_parent.astype(children[0].mu_q_field.dtype))

































# ---- cg helpers ---------------------------------------------------------------
import numpy as np

def cg_eigh_sym(A):
    """Eigen-decomp of symmetric A with tiny symmetrization."""
    A = 0.5 * (A + A.swapaxes(-1, -2))
    return np.linalg.eigh(A)

def cg_spd_from_eig(w, V, f, eps):
    """Recompose V f(w) V^T; f is elementwise; clamps w >= eps."""
    w = np.clip(w, eps, None)
    return (V * f(w)[..., None, :]) @ V.swapaxes(-1, -2)

def cg_cap_condition(S, eps, cond_cap):
    """Cap per-pixel condition number of SPD S via eigen squeezing."""
    w, V = cg_eigh_sym(S)
    w = np.clip(w, eps, None)
    wmin = w.min(axis=-1, keepdims=True)
    wmax = w.max(axis=-1, keepdims=True)
    kappa = wmax / np.maximum(wmin, eps)
    need = (kappa > cond_cap)[..., 0]
    if np.any(need):
        lo = wmax / cond_cap
        w = np.where(need[..., None], np.maximum(w, lo), w)
    return (V * w[..., None, :]) @ V.swapaxes(-1, -2)

def cg_ensure_rot_4d(R, H, W, K, I):
    """Accept (K,K) or (H,W,K,K); else Identity broadcast."""
    R = np.asarray(R, np.float64)
    if R.ndim == 2 and R.shape == (K, K):
        return np.broadcast_to(R, (H, W, K, K))
    if R.ndim == 4 and R.shape[:2] == (H, W) and R.shape[-2:] == (K, K):
        return R
    return np.broadcast_to(I, (H, W, K, K))

def cg_mask_weight(mC, support, mask_tau, gamma):
    """Return mask-based weight field w(x) for child: overlap ∩ mask^gamma."""
    mC = np.asarray(mC, np.float32)
    overlap = (mC > mask_tau) & support
    if gamma == 1.0:
        return overlap.astype(np.float64)
    return np.where(overlap, np.asarray(mC, np.float64) ** max(0.0, gamma), 0.0)




def rg_weight(step, born_step, freeze=0, ramp=10, base=1.0):
    if step < born_step + freeze:
        return 0.0
    t = max(0, step - (born_step + freeze))
    if ramp <= 0:
        return float(base)
    return float(base) * min(1.0, t / ramp)


def build_child_weights(parent, child, *, mode="overlap", mask_tau=0.30):
    pm = (np.asarray(parent.mask, np.float32) > mask_tau)
    cm = (np.asarray(child.mask,  np.float32) > mask_tau)
    if callable(mode):
        w = mode(child).astype(np.float64)
    elif mode == "mask":
        w = cm[..., None].astype(np.float64)
    elif mode == "overlap":
        w = (pm & cm)[..., None].astype(np.float64)
    elif mode == "precision":
        # 1 / average variance proxy: K / trace(Σ)
        S = getattr(child, "sigma_q_field", None) or getattr(child, "sigma_p_field")
        tr = np.trace(S, axis1=-2, axis2=-1)
        K  = S.shape[-1]
        score = (K / (1e-12 + tr)).astype(np.float64)
        w = ((pm & cm)[..., None] * score[..., None]).astype(np.float64)
    else:
        w = (pm & cm)[..., None].astype(np.float64)
    # zero strictly outside parent support
    w[~pm, :] = 0.0
    return w






def _mm(A, B): return np.matmul(A, B)
def _mt(A):    return np.swapaxes(A, -1, -2)



def _get_omega(agent, field_name, generators, fallback_dim=None):
    if field_name == "phi" and getattr(agent, "_exp_phi", None) is not None:
        return agent._exp_phi
    if field_name == "phi_model" and getattr(agent, "_exp_phi_model", None) is not None:
        return agent._exp_phi_model
    # fallback: compute or broadcast I
    try:
        from omega import exp_lie_algebra_irrep
        phi = getattr(agent, field_name)
        return exp_lie_algebra_irrep(phi, generators)
    except Exception:
        K = fallback_dim or int(getattr(agent, "mu_q_field" if field_name=="phi" else "mu_p_field").shape[-1])
        H, W = agent.mask.shape
        eye = np.eye(K, dtype=np.float64)
        return np.broadcast_to(eye, (H, W, K, K)).copy()

# --- PATCH: robust, Λ-free coarse-grain with rotation-only transport and SPD-safe aggregation ---

def _nearest_orthogonal(E):
    # Polar orthogonal factor of E (...,K,K)
    U, _, Vt = np.linalg.svd(E, full_matrices=False)
    return U @ Vt

def _spd_project_higham(S, eps=1e-8):
    # Project to SPD via Higham (eigen clip)
    S = 0.5 * (S + S.swapaxes(-1, -2))
    w, V = np.linalg.eigh(S)
    w = np.clip(w, eps, None)
    return (V * w[..., None, :]) @ V.swapaxes(-1, -2)

def _chol_apply_prec(S, X, ridge=1e-6):
    # Return S^{-1} X without explicit inverse (Cholesky solves)
    K = S.shape[-1]
    S = 0.5*(S + S.swapaxes(-1,-2)) + ridge*np.eye(K, dtype=S.dtype)
    L = np.linalg.cholesky(S)
    Y = np.linalg.solve(L, X)
    return np.linalg.solve(L.swapaxes(-1,-2), Y)




def weighted_mean_field(stack: np.ndarray, weights: np.ndarray, eps: float = 1e-8) -> np.ndarray:
    """
    stack:   (C, H, W, D)
    weights: (C, H, W, 1)  nonnegative
    return:  (H, W, D)
    """
    num = np.sum(weights * stack, axis=0)
    den = np.sum(weights, axis=0) + eps
    return num / den











