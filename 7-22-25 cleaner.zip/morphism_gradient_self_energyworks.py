# -*- coding: utf-8 -*-
"""
Created on Sun Jul 20 11:03:58 2025

@author: chris and christine
"""

# -*- coding: utf-8 -*-
"""
Created on Sun Jul 20 10:47:49 2025

@author: chris and christine
"""

import numpy as np
from scipy.linalg import inv
import numpy as np
import config
from joblib import Parallel, delayed

from natural_gradient_utils import (
    apply_natural_gradient_batch,
    apply_lie_natural_gradient,
    compute_inverse_fisher_field
)

from numerical_utils import sanitize_sigma
from mask_utils import clip_and_mask_gradient, clip_and_mask_morphism
from numerical_utils import safe_inv

from get_generators import get_generators
from generalized_math_utils import unpack_phi_update_params
from generalized_omega import compute_curvature_gradient_analytical, exp_lie_algebra_irrep

from generalized_omega import dexpinv_operator, dexpinv_operator_covariance
from natural_gradient_utils import compute_fisher_geometry_gradient, kl_gradient_mu_sigma
from generalized_math_utils import ( 
        zero_mu_sigma_like, apply_mask_to_mu_sigma
        )
from natural_gradient_utils import transport_gaussian
from bundle_morphism_utils import safe_batch_apply_morphism
from generalized_math_utils import ( 
        zero_mu_sigma_like, compute_mu_sigma_diff,
        apply_mask_to_mu_sigma
        )



def grad_morphism_self_energy(agent_i, alpha, mask=None, eps=1e-8):
    """
    Return only ∇Φ̃ for KL(q || Φ̃ p), compatible with older np.clip() logic.
    """
    mu_q    = agent_i.mu_q_field
    sigma_q = agent_i.sigma_q_field
    mu_p    = agent_i.mu_p_field
    sigma_p = agent_i.sigma_p_field
    Phi_tilde = agent_i.bundle_morphism_p_to_q

    grads = compute_morphism_kl_gradient_batched(
        Phi_tilde, mu_q, sigma_q, mu_p, sigma_p, eps=eps
    )

    grad_Phi = grads["grad_Phi"]

    if mask is not None:
        grad_Phi *= mask[..., None, None]

    return alpha * grad_Phi



def compute_morphism_kl_gradient_batched(Phi_tilde, mu_q, Sigma_q, mu_p, Sigma_p, eps=1e-8):
    """
    Batched version of ∂/∂Φ̃ D_KL(q || Φ̃·p) over a spatial grid.

    Args:
        Phi_tilde : (H, W, K_q, K_p)
        mu_q      : (H, W, K_q)
        Sigma_q   : (H, W, K_q, K_q)
        mu_p      : (H, W, K_p)
        Sigma_p   : (H, W, K_p, K_p)
        eps       : float, SPD regularization

    Returns:
        Dictionary with 5 gradient fields:
            - grad_Phi        : (H, W, K_q, K_p)
            - grad_mu_q       : (H, W, K_q)
            - grad_sigma_q    : (H, W, K_q, K_q)
            - grad_mu_p       : (H, W, K_p)
            - grad_sigma_p    : (H, W, K_p, K_p)
    """
    H, W, K_q, K_p = Phi_tilde.shape

    grad_Phi      = np.zeros((H, W, K_q, K_p))
    grad_mu_q     = np.zeros((H, W, K_q))
    grad_sigma_q  = np.zeros((H, W, K_q, K_q))
    grad_mu_p     = np.zeros((H, W, K_p))
    grad_sigma_p  = np.zeros((H, W, K_p, K_p))

    for i in range(H):
        for j in range(W):
            out = compute_morphism_kl_gradient_self(
                Phi_tilde[i, j], mu_q[i, j], Sigma_q[i, j],
                mu_p[i, j], Sigma_p[i, j], eps=eps
            )
            grad_Phi[i, j]     = out["grad_Phi"]
            grad_mu_q[i, j]    = out["grad_mu_q"]
            grad_sigma_q[i, j] = out["grad_sigma_q"]
            grad_mu_p[i, j]    = out["grad_mu_p"]
            grad_sigma_p[i, j] = out["grad_sigma_p"]

    return {
        "grad_Phi": grad_Phi,
        "grad_mu_q": grad_mu_q,
        "grad_sigma_q": grad_sigma_q,
        "grad_mu_p": grad_mu_p,
        "grad_sigma_p": grad_sigma_p,
    }




#validated
def compute_morphism_kl_gradient_primitives(Phi_tilde, mu_q, Sigma_q, mu_p, Sigma_p, eps=1e-8):
    """
    Compute shared intermediates needed to evaluate ∂/∂Φ~ D_KL(q || Φ~·p)
    
    Args:
        Phi~      : (K_q, K_p) linear morphism matrix Φ~
        mu_q     : (K_q,)     mean of belief q
        Sigma_q  : (K_q, K_q) covariance of belief q
        mu_p     : (K_p,)     mean of model p
        Sigma_p  : (K_p, K_p) covariance of model p
        eps      : stabilizer for SPD inverse

    Returns:
        dict containing:
            - Delta_mu     : (K_q,)     = mu_q - Φ~·mu_p
            - Sigma_q_inv  : (K_q, K_q)
            - M            : (K_q, K_q) = Φ~ Σ_q Φ~ᵀ
            - M_inv        : (K_q, K_q)
            - term_trace   : (K_q, K_q) = M⁻¹ Σ_q M⁻¹
            - term_logdet  : (K_q, K_p) = M⁻¹ Φ~ Σ_p
    """
    K_q, K_p = Phi_tilde.shape

    # Compute Δμ = μ_p - Φ·μ_q
    Delta_mu = mu_q - Phi_tilde @ mu_p

    # Inverse of Σ_q
    Sigma_p_inv = safe_inv(Sigma_p, eps=eps)

    # M = Φ~ Σ_p Φ~ᵀ
    M = Phi_tilde @ Sigma_p @ Phi_tilde.T

    # Inverse of M
    M_inv = safe_inv(M, eps=eps)

    # Precompute reusable trace/logdet gradient terms
    term_trace = 0.5*M_inv @ Sigma_q @ M_inv  # (K_p, K_p)
    term_logdet = 0.5*M_inv @ Phi_tilde @ Sigma_p  # (K_p, K_q)

    return {
        "Delta_mu": Delta_mu,
        "Sigma_p_inv": Sigma_p_inv,
        "M": M,
        "M_inv": M_inv,
        "term_trace": term_trace,
        "term_logdet": term_logdet
    }









def compute_morphism_kl_gradient_self(Phi_tilde, mu_q, Sigma_q, mu_p, Sigma_p, eps=1e-8):
    """
    Compute full variational derivatives for D_KL(q || Φ̃·p):
      - ∇Φ̃  (main return)
      - Also computes ∇_{μ_q}, ∇_{Σ_q}, ∇_{μ_p}, ∇_{Σ_p} (returned in dict)

    Returns:
        result : dict with keys:
            - "grad_Phi"
            - "grad_mu_q"
            - "grad_sigma_q"
            - "grad_mu_p"
            - "grad_sigma_p"
    """
    # Shared intermediates
    primitives = compute_morphism_kl_gradient_primitives(
        Phi_tilde, mu_q, Sigma_q, mu_p, Sigma_p, eps=eps
    )

    Delta_mu = primitives["Delta_mu"]
    M_inv = primitives["M_inv"]
    term_trace = primitives["term_trace"]
    term_logdet = primitives["term_logdet"]

    # ∇Φ̃ = Mahalanobis + logdet - trace
    term_mahal = M_inv @ np.outer(Delta_mu, Delta_mu) @ M_inv @ Phi_tilde @ Sigma_p
    grad_Phi = term_mahal + term_logdet - term_trace @ Phi_tilde @ Sigma_p

    # ∇μ_q
    grad_mu_q = grad_self_energy_mu_q(mu_q, Sigma_q, mu_p, Sigma_p, Phi_tilde, eps)

    # ∇Σ_q
    grad_sigma_q = grad_self_energy_sigma_q(mu_q, Sigma_q, mu_p, Sigma_p, Phi_tilde, eps)

    # ∇μ_p
    grad_mu_p = grad_self_energy_mu_p(mu_q, Sigma_q, mu_p, Sigma_p, Phi_tilde, eps)

    # ∇Σ_p
    grad_sigma_p = grad_self_energy_sigma_p(mu_q, Sigma_q, mu_p, Sigma_p, Phi_tilde, eps)

    return {
        "grad_Phi": grad_Phi,
        "grad_mu_q": grad_mu_q,
        "grad_sigma_q": grad_sigma_q,
        "grad_mu_p": grad_mu_p,
        "grad_sigma_p": grad_sigma_p,
    }



#unwired below
def grad_self_energy_mu_q(mu_q_field, sigma_q_field, mu_p_field, sigma_p_field, Phi_tilde, eps=1e-8):
    """
    Compute ∂/∂μ_q D_KL(q || Φ̃ p) over spatial field (H, W, K_q)
    """
    # Pushforwarded mean: Φ̃ μ_p
    mu_p_push = np.einsum("...ij,...j->...i", Phi_tilde, mu_p_field)  # (..., K_q)

    # Pushforwarded covariance: Φ̃ Σ_p Φ̃^T
    sigma_p_push = np.einsum("...iq,...qr,...jr->...ij", Phi_tilde, sigma_p_field, Phi_tilde)

    sigma_p_push_inv = safe_inv(sigma_p_push, eps=eps)

    # Δμ = μ_q − Φ̃ μ_p
    delta_mu = mu_q_field - mu_p_push

    # Gradient
    grad_mu_q = np.einsum("...ij,...j->...i", sigma_p_push_inv, delta_mu)

    return grad_mu_q

def grad_self_energy_sigma_q(mu_q_field, sigma_q_field, mu_p_field, sigma_p_field, Phi_tilde, eps=1e-8):
    """
    Compute ∂/∂Σ_q D_KL(q || Φ̃ p) over spatial field (H, W, K_q, K_q)
    """
    # Pushforwarded covariance: Φ̃ Σ_p Φ̃^T
    sigma_p_push = np.einsum("...iq,...qr,...jr->...ij", Phi_tilde, sigma_p_field, Phi_tilde)

    sigma_p_push_inv = safe_inv(sigma_p_push, eps=eps)  # (..., K_q, K_q)

    return 0.5 * sigma_p_push_inv

def grad_self_energy_mu_p(mu_q_field, sigma_q_field,
                          mu_p_field, sigma_p_field, Phi_tilde, eps=1e-8):
    """
    Compute ∂/∂μ_p D_KL(q || Φ̃ p) over spatial field (H, W, K_p)
    """
    # Pushforwarded model mean
    mu_p_push = np.einsum("...ij,...j->...i", Phi_tilde, mu_p_field)  # (..., K_q)

    # Pushforwarded model covariance
    sigma_p_push = np.einsum("...iq,...qr,...jr->...ij", Phi_tilde, sigma_p_field, Phi_tilde)

    sigma_p_push_inv = safe_inv(sigma_p_push, eps=eps)

    # Δμ = μ_q − Φ̃ μ_p
    delta_mu = mu_q_field - mu_p_push  # (..., K_q)

    # Gradient
    tmp = np.einsum("...ij,...j->...i", sigma_p_push_inv, delta_mu)  # (..., K_q)
    grad_mu_p = -np.einsum("...ji,...j->...i", Phi_tilde, tmp)  # (..., K_p)

    return grad_mu_p



def grad_self_energy_sigma_p(mu_q_field, sigma_q_field, mu_p_field, 
                              sigma_p_field, Phi_tilde, eps=1e-8):
    """
    Compute ∂/∂Σ_p D_KL(q || Φ̃·p) ≡ 1/2 · Φ̃ᵗ [ ... ] Φ̃

    Args:
        mu_q_field     : (..., K_q)
        sigma_q_field  : (..., K_q, K_q)
        mu_p_field     : (..., K_p)
        sigma_p_field  : (..., K_p, K_p)
        Phi_tilde      : (..., K_q, K_p)
        eps            : regularization for inversion

    Returns:
        grad_sigma_p   : (..., K_p, K_p)
    """
    # Φ̃ᵗ for convenience
    Phi_tilde_T = np.swapaxes(Phi_tilde, -1, -2)  # (..., K_p, K_q)

    # Σ_p' = Φ̃ Σ_p Φ̃ᵗ ∈ (..., K_q, K_q)
    sigma_proj = Phi_tilde @ sigma_p_field @ Phi_tilde.T

    sigma_proj_inv = safe_inv(sigma_proj, eps=eps)

    # μ_p' = Φ̃ μ_p ∈ (..., K_q)
    mu_proj = np.einsum("...ij,...j->...i", Phi_tilde, mu_p_field)

    # Δμ = μ_q - Φ̃ μ_p
    delta_mu = mu_q_field - mu_proj  # (..., K_q)

    # Δμ Δμᵗ
    delta_mu_outer = np.einsum("...i,...j->...ij", delta_mu, delta_mu)  # (..., K_q, K_q)

    # Each of the three terms in the bracket
    term1 = sigma_proj_inv

    term2 = np.einsum("...ik,...kl,...lj->...ij",
                      sigma_proj_inv, delta_mu_outer, sigma_proj_inv)

    term3 = np.einsum("...ik,...kl,...lj->...ij",
                      sigma_proj_inv, sigma_q_field, sigma_proj_inv)

    # Combined bracket
    M = term1 - term2 - term3  # (..., K_q, K_q)

    # Final gradient: Φ̃ᵗ M Φ̃ ∈ (..., K_p, K_p)
    grad_sigma_p = 0.5 * np.einsum("...ki,...ij,...jl->...kl", Phi_tilde_T, M, Phi_tilde)

    return grad_sigma_p






def grad_self_energy_sigma_ppppppppp(mu_q_field, sigma_q_field,
                             mu_p_field, sigma_p_field, Phi_tilde, eps=1e-8):
    """
    Compute ∂/∂Σ_p D_KL(q || Φ̃ p) over spatial field (..., K_p, K_p)
    """

    # Pushforwarded covariance Σ̃_p = Φ̃ Σ_p Φ̃ᵀ
    sigma_p_push = np.einsum("...iq,...qr,...jr->...ij", Phi_tilde, sigma_p_field, Phi_tilde)

    sigma_p_push_inv = safe_inv(sigma_p_push, eps=eps)

    # Δμ = μ_q − Φ̃ μ_p
    mu_p_push = np.einsum("...ij,...j->...i", Phi_tilde, mu_p_field)
    delta_mu = mu_q_field - mu_p_push
    A = np.einsum("...i,...j->...ij", delta_mu, delta_mu)  # (..., K_q, K_q)

    # M = Σ̃_p⁻¹ (ΔμΔμᵀ − Σ_q − I) Σ̃_p⁻¹
    term1 = np.einsum("...ik,...kl,...lj->...ij", sigma_p_push_inv, A, sigma_p_push_inv)
    term2 = np.einsum("...ik,...kl,...lj->...ij", sigma_p_push_inv, sigma_q_field, sigma_p_push_inv)
    M = term1 - term2 - sigma_p_push_inv  # (..., K_q, K_q)

    # ∂Σ_p: ½ Φ̃ M Φ̃ᵀ, no need to transpose explicitly
    grad_sigma_p = 0.5 * np.einsum("...ki,...kl,...lj->...ij", np.swapaxes(Phi_tilde, -1, -2), M, np.swapaxes(Phi_tilde, -1, -2))


    return grad_sigma_p

