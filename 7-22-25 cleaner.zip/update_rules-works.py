# -*- coding: utf-8 -*-
"""
Created on Sat Jul 19 08:23:33 2025

@author: chris and christine
"""


# === generalized_update_rules.py (refactor patch) ===
import numpy as np
import config
from joblib import Parallel, delayed

from natural_gradient_utils import (
    apply_natural_gradient_batch,
    apply_lie_natural_gradient,
    compute_inverse_fisher_field
)
from generalized_diagnostics_metrics import compute_alignment_field_general
from update_terms_belief import  compute_phi_update_belief, grad_morphism_self_energy
from update_terms_model import  compute_phi_update_model
from numerical_utils import sanitize_sigma

from generalized_omega import exp_lie_algebra_irrep
from scipy.linalg import solve_triangular  # or np.linalg.solve per batch
from generalized_math_utils import batch_matrix_inverse, safe_batch_inverse, preprocess_agent_fields
from get_generators import RhoFunction  # or however you're loading rho
from update_terms_belief import grad_self_field, alignment_gradient_field_belief
from update_terms_model import grad_feedback_field, alignment_gradient_field_model, grad_variance_penalty_field
from generalized_math_utils import ( 
        zero_mu_sigma_like, compute_mu_sigma_diff,
        apply_mask_to_mu_sigma
        )

from morphism_gradient_self_energy import grad_morphism_self_energy
from morphism_gradient_feedback_energy import grad_morphism_feedback_energy


def combine_field_gradients_model(agent_i, agents, params, field_type="model"):
    """
    Compute and combine gradients for model fields only (KL(p || Φ·q)).
    This includes feedback and model alignment terms.

    Args:
        agent_i  : Agent whose gradients are being computed
        agents   : List of all agents (used for alignment)
        params   : Dictionary of parameters controlling the gradients
        field_type: Specifies whether to handle "model" or "belief" fields

    Returns:
        delta_mu : Gradient for the means (H, W, K_p)
        delta_sigma : Gradient for the covariances (H, W, K_p, K_p)
    """
    
    if field_type == "model" and getattr(config, "identical_models", False):
        return zero_mu_sigma_like(agent_i)

    # Load all parameters
    β  = params.get("model_align_weight", config.model_align_weight)
    fb = params.get("model_feedback_weight", config.model_feedback_weight)
    λ  = params.get("variance_penalty_model_weight", config.variance_penalty_model_weight)
    eps = params.get("support_cutoff_eps", config.support_cutoff_eps)
    debug = getattr(config, "debug_gradients", False)

    # Mask
    mask = agent_i.mask > eps
    if not np.any(mask):
        return zero_mu_sigma_like(agent_i)

    # Select fields (model field here)
    mu_field    = agent_i.mu_p_field
    sigma_field = agent_i.sigma_p_field

    # --- Natural-gradient components ---
    grad_mu_nat    = np.zeros_like(mu_field)
    grad_sigma_nat = np.zeros_like(sigma_field)

    if fb > 0:
        # Gradient for feedback term (KL(p || Φ·q))
        dμ, dΣ = grad_feedback_field(agent_i, fb, mask=mask)
        grad_mu_nat += dμ
        grad_sigma_nat += dΣ
        #if debug:
           #W print(f"[MODEL] Feedback grad |mu|={np.linalg.norm(dμ):.2e}, |Sigma|={np.linalg.norm(dΣ):.2e}")

    if β > 0:
        # Gradient for model alignment (KL(p_i || Ω̃_ij p_j))
        dμ, dΣ = alignment_gradient_field_model(agent_i, agents, params, mask=mask)
        grad_mu_nat += dμ
        grad_sigma_nat += dΣ
        #if debug:
          #  print(f"[MODEL] Align grad |mu|={np.linalg.norm(dμ):.2e}, |Sigma|={np.linalg.norm(dΣ):.2e}")

    # --- Apply Fisher preconditioner only to KL terms ---
    delta_mu, delta_sigma = apply_natural_gradient_batch(mu_field, sigma_field, grad_mu_nat, grad_sigma_nat)
   # if debug:
     #   print(f"[MODEL] delta mu nat grad ={np.linalg.norm(delta_mu):.2e}, Delta Sigma nat grad={np.linalg.norm(delta_sigma):.2e}")

    # --- Add regularization (coordinate) terms AFTER natural gradient ---
    if λ > 0:
        # Variance penalty regularization
        dμ_reg, dΣ_reg = grad_variance_penalty_field(agent_i, λ, field_type="model", mask=mask)
        delta_mu    += dμ_reg
        delta_sigma += dΣ_reg
        #if debug:
         #   print(f"[MODEL] Reg grad mu={np.linalg.norm(dμ_reg):.2e}, Sigma Reg={np.linalg.norm(dΣ_reg):.2e}")

    # Final nan sanitization
    delta_mu    = np.nan_to_num(delta_mu, nan=0.0, posinf=1e5, neginf=-1e5)
    delta_sigma = np.nan_to_num(delta_sigma, nan=0.0, posinf=1e5, neginf=-1e5)

    return delta_mu, delta_sigma






def combine_field_gradients_belief(agent_i, agents, params, field_type="belief"):
    """
    Compute and combine gradients for belief fields only (KL(q || Φ̃·p)) and KL(qi || Omega_ij qj)) .
    This includes self-alignment, belief alignment terms, and regularization.

    Args:
        agent_i  : Agent whose gradients are being computed
        agents   : List of all agents (used for alignment)
        params   : Dictionary of parameters controlling the gradients
        field_type: Specifies whether to handle "belief" or "model" fields

    Returns:
        delta_mu : Gradient for the means (H, W, K_q)
        delta_sigma : Gradient for the covariances (H, W, K_q, K_q)
    """
    
    if field_type == "belief" and getattr(config, "identical_beliefs", False):
        return zero_mu_sigma_like(agent_i)

    # Load all parameters
    α = params.get("alpha", config.alpha)
    β = params.get("beta", config.beta)
    λ = params.get("variance_penalty_belief_weight", getattr(config, "variance_penalty_belief_weight", 0.0))
    eps = params.get("support_cutoff_eps", config.support_cutoff_eps)
    debug = getattr(config, "debug_gradients", False)

    # Mask
    mask = agent_i.mask > eps
    if not np.any(mask):
        return zero_mu_sigma_like(agent_i)

    # Select belief fields (q)
    mu_field = agent_i.mu_q_field
    sigma_field = agent_i.sigma_q_field

    # --- Natural-gradient components ---
    grad_mu_nat = np.zeros_like(mu_field)
    grad_sigma_nat = np.zeros_like(sigma_field)

    # Self-alignment gradient (KL(q || Φ̃·p))
    if α > 0:
        dμ, dΣ = grad_self_field(agent_i, α, field_type="belief", mask=mask)
        grad_mu_nat += dμ
        grad_sigma_nat += dΣ
        #if debug:
           # print(f"[BELIEF] Self grad |mu|={np.linalg.norm(dμ):.2e}, |Sigma|={np.linalg.norm(dΣ):.2e}")

    # Alignment gradient (KL(qi || Omega_ij qj))
    if β > 0:
        dμ, dΣ = alignment_gradient_field_belief(agent_i, agents, params, mask=mask)
        grad_mu_nat += dμ
        grad_sigma_nat += dΣ
        #if debug:
           # print(f"[BELIEF] Align grad |mu|={np.linalg.norm(dμ):.2e}, |Sigma|={np.linalg.norm(dΣ):.2e}")

    # --- Apply Fisher preconditioner only to KL terms ---
    delta_mu, delta_sigma = apply_natural_gradient_batch(mu_field, sigma_field, grad_mu_nat, grad_sigma_nat)
    #if debug:
        #print(f"[BELIEF] delta mu nat grad ={np.linalg.norm(delta_mu):.2e}, Delta Sigma nat grad={np.linalg.norm(delta_sigma):.2e}")

    # --- Add regularization (coordinate) terms AFTER natural gradient ---
    if λ > 0:
        dμ_reg, dΣ_reg = grad_variance_penalty_field(agent_i, λ, field_type="belief", mask=mask)
        delta_mu += dμ_reg
        delta_sigma += dΣ_reg
       # if debug:
         #   print(f"[BELIEF] Reg grad mu={np.linalg.norm(dμ_reg):.2e}, Sigma Reg={np.linalg.norm(dΣ_reg):.2e}")

    # Final nan sanitization
    delta_mu = np.nan_to_num(delta_mu, nan=0.0, posinf=1e5, neginf=-1e5)
    delta_sigma = np.nan_to_num(delta_sigma, nan=0.0, posinf=1e5, neginf=-1e5)

    return delta_mu, delta_sigma





def compute_all_gradients(i, agents, params):
    ai = agents[i]

    # Field gradients
    dq_mu, dq_sigma = combine_field_gradients_belief(ai, agents, params, field_type="belief")
    dp_mu, dp_sigma = combine_field_gradients_model(ai, agents, params, field_type="model")

    # Gauge fields (phi and phi_model)
    dphi = compute_phi_update_belief(ai, agents, params, field="phi")
    dphi_m = compute_phi_update_model(ai, agents, params, field="phi_model")

    # Bundle morphism gradient (only compute, no update)
    dPhi = grad_morphism_feedback_energy(ai, params.get("model_feedback_weight", config.model_feedback_weight), mask=ai.mask)  # Only compute gradient
    dPhi_tilde = grad_morphism_self_energy(ai, params.get("alpha", config.alpha), mask=ai.mask)  # Correct gradient computation

    # Fallback to zero if the gradient is skipped (although it should always be computed)
    if dPhi is None:
        dPhi = np.zeros_like(ai.bundle_morphism_q_to_p)
    if dPhi_tilde is None:
        dPhi_tilde = np.zeros_like(ai.bundle_morphism_p_to_q)

    return (dq_mu, dq_sigma), (dp_mu, dp_sigma), dphi, dphi_m, dPhi, dPhi_tilde


# --- Shared η scaling helper ---
def compute_adaptive_eta(base_eta, grad, cached_kl, sigma_field, scaling_kl, scaling_cond, eta_min):
    """
    Computes adaptive step size η based on KL alignment and condition number of Σ.
    """
    kl_term = (
        np.mean(cached_kl)
        if cached_kl is not None and np.isfinite(np.mean(cached_kl))
        else np.mean(np.abs(grad))
    )

    try:
        conds = np.linalg.cond(sigma_field.reshape(-1, sigma_field.shape[-2], sigma_field.shape[-1]))
        cond_avg = np.mean(conds)
    except Exception:
        cond_avg = 1.0

    denom = 1.0 + scaling_kl * kl_term + scaling_cond * cond_avg
    eta_scaled = base_eta / denom
    return np.clip(eta_scaled, eta_min, base_eta)



def apply_phi_updates(agent, grad_phi, grad_phi_m, mask, params):
    mask_exp = mask[..., None]

    def clip_lie_update(delta, threshold):
        if threshold <= 0:
            return delta
        norm = np.linalg.norm(delta, axis=-1, keepdims=True)
        factor = np.minimum(1.0, threshold / (norm + 1e-8))
        return delta * factor

    # Extract config safely
    cfg = vars(config) if params is None else {**vars(config), **params}

    # φ adaptive update
    eta_phi_tuned = compute_adaptive_eta(
        cfg["eta_base_phi"],
        grad_phi,
        getattr(agent, "cached_alignment_kl", None),
        agent.sigma_q_field,
        cfg["eta_phi_adaptive_scaling"],
        cfg["eta_sigma_condition_scaling"],
        cfg["eta_phi_min"],
    )
    delta_phi = eta_phi_tuned * grad_phi
    delta_phi = clip_lie_update(delta_phi, cfg.get("phi_grad_clip_threshold", 0.0))
    delta_phi = np.nan_to_num(delta_phi, nan=0.0, posinf=1e5, neginf=-1e5)
    agent.phi -= delta_phi * mask_exp

    # φ̃ adaptive update
    eta_phi_m_tuned = compute_adaptive_eta(
        cfg["eta_base_phi_model"],
        grad_phi_m,
        getattr(agent, "cached_model_alignment_kl", None),
        agent.sigma_p_field,
        cfg["eta_phi_model_adaptive_scaling"],
        cfg["eta_sigma_condition_scaling"],
        cfg["eta_phi_model_min"],
    )
    delta_phi_m = eta_phi_m_tuned * grad_phi_m
    delta_phi_m = clip_lie_update(delta_phi_m, cfg.get("phi_model_grad_clip_threshold", 0.0))
    delta_phi_m = np.nan_to_num(delta_phi_m, nan=0.0, posinf=1e5, neginf=-1e5)
    agent.phi_model -= delta_phi_m * mask_exp


def clip_morphism_gradients(grad, clip_value):
    if isinstance(grad, dict):
        return {
            k: np.clip(v, -clip_value, clip_value)
            for k, v in grad.items()
        }
    else:
        return np.clip(grad, -clip_value, clip_value)





def synchronous_step(agents, generators_q, generators_p, params=None, n_jobs=1):
    params = params or {}
    N = len(agents)
    print(f"[DEBUG] Using {n_jobs} workers in synchronous_step")

    # Step 1: Preprocess Fisher, exp(φ), etc.
    Parallel(n_jobs=n_jobs, backend="threading", batch_size=1)(
        delayed(preprocess_agent_fields)(A, params) for A in agents
    )

    # Step 2: Refresh KL alignment caches
    for A in agents:
        A.cached_alignment_kl       = compute_alignment_field_general(agents, A.id, field_type="belief", log_eps=config.eps)
        A.cached_model_alignment_kl = compute_alignment_field_general(agents, A.id, field_type="model",  log_eps=config.eps)

    # Step 3: Compute all gradients (including morphism gradients)
    grads = Parallel(n_jobs=n_jobs, backend="loky", batch_size=2)(  # Parallelize gradient computations
        delayed(compute_all_gradients)(i, agents, params) for i in range(N)
    )
    q_updates, p_updates, phi_grads, phi_m_grads, morphism_grads, morphism_tilde_grads = zip(*grads)
    mask_list = [A.mask for A in agents]

    eta_q = params.get("eta_q", config.eta_q)
    eta_p = params.get("eta_p", config.eta_p)
    lr_phi     = params.get("phi_morphism_lr", getattr(config, "phi_morphism_lr", 1e-3))
    lr_phi_til = params.get("phi_tilde_morphism_lr", getattr(config, "phi_tilde_morphism_lr", 1e-3))

    # Step 4: Apply all updates
    def apply_agent_updates(i):
        agent = agents[i]
        mask = mask_list[i]

        Δμ_q, ΔΣ_q = q_updates[i]
        Δμ_p, ΔΣ_p = p_updates[i]
        dPhi       = morphism_grads[i]
        dPhi_tilde = morphism_tilde_grads[i]

        mask_mu    = mask[..., None]
        mask_sigma = mask[..., None, None]

    # Apply updates for belief and model fields
        agent.mu_q_field    -= eta_q * Δμ_q * mask_mu
        agent.sigma_q_field -= eta_q * ΔΣ_q * mask_sigma
        agent.mu_p_field    -= eta_p * Δμ_p * mask_mu
        agent.sigma_p_field -= eta_p * ΔΣ_p * mask_sigma

        agent.sigma_q_field = sanitize_sigma(agent.sigma_q_field)
        agent.sigma_p_field = sanitize_sigma(agent.sigma_p_field)

    # Apply phi field updates
        apply_phi_updates(agent, phi_grads[i], phi_m_grads[i], mask, params)

    # Apply gradient clipping to prevent overflow
        clip_value = 1e7

    # Clip and extract morphism gradient terms
        def clip_grad(g):
            if isinstance(g, dict):
                return {k: np.clip(v, -clip_value, clip_value) for k, v in g.items()}
            return np.clip(g, -clip_value, clip_value)

        dPhi_tilde = clip_grad(dPhi_tilde)
        dPhi       = clip_grad(dPhi)

    # Extract and apply only Φ and Φ̃ updates
        dPhi_tilde_matrix = dPhi_tilde["grad_Phi"] if isinstance(dPhi_tilde, dict) else dPhi_tilde
        dPhi_matrix       = dPhi["grad_Phi"]       if isinstance(dPhi, dict) else dPhi

        agent.bundle_morphism_p_to_q -= lr_phi_til * dPhi_tilde_matrix  # Φ̃ : P → Q
        agent.bundle_morphism_q_to_p -= lr_phi      * dPhi_matrix        # Φ : Q → P

        return agent


    agents = Parallel(n_jobs=n_jobs, backend="threading", batch_size=1)(  # Apply updates in parallel
        delayed(apply_agent_updates)(i) for i in range(N)
    )

    return agents


