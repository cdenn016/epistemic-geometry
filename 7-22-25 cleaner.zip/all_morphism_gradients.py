import config
from morphism_gradient_feedback_energy import (
    compute_morphism_kl_gradient_feedback,
    grad_feedback_wrt_mu_q_field,
    grad_feedback_wrt_sigma_q_field,
    grad_feedback_mu_p,
    grad_feedback_sigma_p
)

from morphism_gradient_self_energy import (
    compute_morphism_kl_gradient_self,
    grad_self_energy_mu_q,
    grad_self_energy_sigma_q,
    grad_self_energy_mu_p,
    grad_self_energy_sigma_p
)

def compute_all_morphism_gradients(agent_i, params, eps=1e-8):
    """
    Compute all morphism-related gradients for a single agent:
        - Feedback: KL(p || Φ·q)
        - Self    : KL(q || Φ̃·p)
    Returns:
        Dictionary of 10 gradient fields.
    """

    # Extract fields
    mu_q    = agent_i.mu_q_field
    sigma_q = agent_i.sigma_q_field
    mu_p    = agent_i.mu_p_field
    sigma_p = agent_i.sigma_p_field
    Phi     = agent_i.bundle_morphism_q_to_p       # (H, W, K_p, K_q)
    Phi_tilde = agent_i.bundle_morphism_p_to_q     # (H, W, K_q, K_p)
    mask = agent_i.mask

    alpha = params.get("alpha", config.alpha)
    feedback_weight = params.get("model_align_weight", config.model_align_weight)

    # -------- Feedback term: KL(p || Φ·q) --------
    grad_Phi = feedback_weight * compute_morphism_kl_gradient_feedback(
        Phi, mu_q, sigma_q, mu_p, sigma_p, eps=eps
    )
    grad_mu_q_feedback = grad_feedback_wrt_mu_q_field(mu_q, sigma_q, mu_p, Phi, eps=eps)
    grad_sigma_q_feedback = grad_feedback_wrt_sigma_q_field(mu_q, sigma_q, mu_p, sigma_p, Phi, eps=eps)
    grad_mu_p_feedback = grad_feedback_mu_p(mu_p, sigma_p, mu_q, sigma_q, Phi, eps=eps)
    grad_sigma_p_feedback = grad_feedback_sigma_p(mu_p, sigma_p, mu_q, sigma_q, Phi, eps=eps)

    # -------- Self term: KL(q || Φ̃·p) --------
    grad_Phi_tilde = alpha * compute_morphism_kl_gradient_self(
        Phi_tilde, mu_q, sigma_q, mu_p, sigma_p, eps=eps
    )
    grad_mu_q_self = grad_self_energy_mu_q(mu_q, sigma_q, mu_p, sigma_p, Phi_tilde, eps=eps)
    grad_sigma_q_self = grad_self_energy_sigma_q(mu_q, sigma_q, mu_p, sigma_p, Phi_tilde, eps=eps)
    grad_mu_p_self = grad_self_energy_mu_p(mu_q, sigma_q, mu_p, sigma_p, Phi_tilde, eps=eps)
    grad_sigma_p_self = grad_self_energy_sigma_p(mu_q, sigma_q, mu_p, sigma_p, Phi_tilde, eps=eps)

    return {
        # Φ gradients
        "grad_Phi": grad_Phi,
        "grad_Phi_tilde": grad_Phi_tilde,

        # Belief (q) gradients
        "grad_mu_q_feedback": grad_mu_q_feedback,
        "grad_sigma_q_feedback": grad_sigma_q_feedback,
        "grad_mu_q_self": grad_mu_q_self,
        "grad_sigma_q_self": grad_sigma_q_self,

        # Model (p) gradients
        "grad_mu_p_feedback": grad_mu_p_feedback,
        "grad_sigma_p_feedback": grad_sigma_p_feedback,
        "grad_mu_p_self": grad_mu_p_self,
        "grad_sigma_p_self": grad_sigma_p_self,
    }
