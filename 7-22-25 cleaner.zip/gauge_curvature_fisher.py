import numpy as np
import matplotlib.pyplot as plt
import os
from numpy.linalg import inv
from generalized_io_utils import load_all_checkpoints, load_latest_checkpoint  # From uploaded file

# Function to compute Fisher pullback metric G_{μν}(c)
def compute_fisher_pullback(mu_q, sigma_q):
    """
    Computes the Fisher information metric for Gaussian distributions at each point.
    """
    G_inv = np.linalg.inv(sigma_q)
    return G_inv

# Function to compute the curvature F_{μν} at each grid point (simple numerical approximation)
def compute_curvature(phi_field, grid_shape):
    """
    Computes the curvature (F_{μν}) using finite difference approximation.
    """
    F = np.zeros_like(phi_field)
    for i in range(1, grid_shape[0]-1):
        for j in range(1, grid_shape[1]-1):
            F[i, j] = (phi_field[i+1, j] - phi_field[i-1, j] + phi_field[i, j+1] - phi_field[i, j-1]) / 2
    return F

# Function to compute the curl (antisymmetrized derivative) of the pullback Fisher information
def compute_pullback_curl(G_pullback):
    """
    Computes the curl of the pullback Fisher metric (antisymmetric part of the derivative).
    """
    curl_G = np.zeros_like(G_pullback)
    for i in range(1, G_pullback.shape[0]-1):
        for j in range(1, G_pullback.shape[1]-1):
            curl_G[i, j] = (G_pullback[i+1, j] - G_pullback[i-1, j] - G_pullback[i, j+1] + G_pullback[i, j-1]) / 2
    return curl_G

# Function to compare the curvature and the curl of the pullback metric
def compare_curvature_to_pullback(F, curl_G):
    """
    Compares the curvature and the curl of the pullback metric by computing their norms and correlation.
    """
    norm_F = np.linalg.norm(F, axis=(0, 1))
    norm_curl_G = np.linalg.norm(curl_G, axis=(0, 1))
    
    # Compute correlation
    correlation = np.corrcoef(norm_F.flatten(), norm_curl_G.flatten())[0, 1]
    
    return norm_F, norm_curl_G, correlation

# Main function to run the diagnostics
def run_diagnostics(checkpoint_path, load_latest=True):
    """
    Runs the diagnostics, loads the checkpoint data, computes curvature, pullback Fisher metrics, and compares them.
    """
    if load_latest:
        # Load the latest checkpoint data
        data = load_latest_checkpoint(checkpoint_path)
    else:
        # Load all checkpoints
        data = load_all_checkpoints(checkpoint_path)
    
    # Extract fields from the latest checkpoint or the first one (if using all checkpoints)
    mu_q_field = data['mu_q_field']
    sigma_q_field = data['sigma_q_field']
    phi_field = data['phi_field']
    
    # Compute the pullback Fisher metric
    G_pullback = compute_fisher_pullback(mu_q_field, sigma_q_field)
    
    # Compute curvature (F_{μν})
    curvature = compute_curvature(phi_field, mu_q_field.shape)
    
    # Compute the curl of the pullback Fisher metric
    curl_G = compute_pullback_curl(G_pullback)
    
    # Compare curvature and pullback curl
    norm_F, norm_curl_G, correlation = compare_curvature_to_pullback(curvature, curl_G)
    
    # Plot results
    plt.figure(figsize=(12, 6))
    
    # Curvature heatmap
    plt.subplot(1, 2, 1)
    plt.imshow(norm_F, cmap='hot', interpolation='nearest')
    plt.title('Norm of Curvature (F_{μν})')
    plt.colorbar()
    
    # Curl heatmap
    plt.subplot(1, 2, 2)
    plt.imshow(norm_curl_G, cmap='hot', interpolation='nearest')
    plt.title('Norm of Curl of Pullback Metric (∇_{[μ} G_{ν]})')
    plt.colorbar()
    
    plt.tight_layout()
    plt.show()
    
    print(f"Correlation between curvature and pullback curl: {correlation:.4f}")

# Run the diagnostics when this script is executed directly
if __name__ == "__main__":
    checkpoint_path = "checkpoints"  # Replace with the actual path
    run_diagnostics(checkpoint_path, load_latest=True)  # Set load_latest=True to use the latest checkpoint
