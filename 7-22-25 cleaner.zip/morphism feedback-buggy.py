# -*- coding: utf-8 -*-
"""
Created on Sun Jul 20 10:47:49 2025

@author: chris and christine
"""

import numpy as np
from scipy.linalg import inv

import numpy as np
from scipy.linalg import inv
import numpy as np
import config
from joblib import Parallel, delayed

from natural_gradient_utils import (
    apply_natural_gradient_batch,
    apply_lie_natural_gradient,
    compute_inverse_fisher_field
)

from numerical_utils import sanitize_sigma
from mask_utils import clip_and_mask_gradient, clip_and_mask_morphism
from numerical_utils import safe_inv

from get_generators import get_generators
from generalized_math_utils import unpack_phi_update_params
from generalized_omega import compute_curvature_gradient_analytical, exp_lie_algebra_irrep

from generalized_omega import dexpinv_operator, dexpinv_operator_covariance
from natural_gradient_utils import compute_fisher_geometry_gradient, kl_gradient_mu_sigma
from generalized_math_utils import ( 
        zero_mu_sigma_like, apply_mask_to_mu_sigma
        )
from natural_gradient_utils import transport_gaussian
from bundle_morphism_utils import safe_batch_apply_morphism
from generalized_math_utils import ( 
        zero_mu_sigma_like, compute_mu_sigma_diff,
        apply_mask_to_mu_sigma
        )


import numpy as np


def grad_morphism_feedback_energy(agent_i, feedback_weight, mask=None, eps=1e-8):
    """
    Compute full gradient ∂/∂Φ KL(p || Φ·q) over spatial grid (H, W)
    """
    mu_q    = agent_i.mu_q_field
    sigma_q = agent_i.sigma_q_field
    mu_p    = agent_i.mu_p_field
    sigma_p = agent_i.sigma_p_field
    Phi     = agent_i.bundle_morphism_q_to_p

    grads = compute_morphism_kl_gradient_batched(
        Phi, mu_q, sigma_q, mu_p, sigma_p, eps=eps
    )
    grad_Phi = grads["grad_Phi"]

    if mask is not None:
        grad_Phi *= mask[..., None, None]

    return feedback_weight * grad_Phi  # Or return `grads` dict if you want all







def compute_morphism_kl_gradient_batched(Phi_field, mu_q_field, Sigma_q_field, mu_p_field, Sigma_p_field, eps=1e-8):
    """
    Compute all gradient components of KL(p || Φ·q) over spatial grid (H, W)
    
    Returns dict with keys:
        - grad_Phi         : (H, W, K_p, K_q)
        - grad_mu_q        : (H, W, K_q)
        - grad_sigma_q     : (H, W, K_q, K_q)
        - grad_mu_p        : (H, W, K_p)
        - grad_sigma_p     : (H, W, K_p, K_p)
    """
    H, W, K_q = mu_q_field.shape
    K_p = mu_p_field.shape[-1]

    grad_Phi_field     = np.zeros((H, W, K_p, K_q))
    grad_mu_q_field    = np.zeros((H, W, K_q))
    grad_sigma_q_field = np.zeros((H, W, K_q, K_q))
    grad_mu_p_field    = np.zeros((H, W, K_p))
    grad_sigma_p_field = np.zeros((H, W, K_p, K_p))

    for i in range(H):
        for j in range(W):
            out = compute_morphism_kl_gradient_feedback(
                Phi_field[i, j],
                mu_q_field[i, j],
                Sigma_q_field[i, j],
                mu_p_field[i, j],
                Sigma_p_field[i, j],
                eps=eps
            )
            grad_Phi_field[i, j]     = out["grad_Phi"]
            grad_mu_q_field[i, j]    = out["grad_mu_q"]
            grad_sigma_q_field[i, j] = out["grad_sigma_q"]
            grad_mu_p_field[i, j]    = out["grad_mu_p"]
            grad_sigma_p_field[i, j] = out["grad_sigma_p"]

    return {
        "grad_Phi": grad_Phi_field,
        "grad_mu_q": grad_mu_q_field,
        "grad_sigma_q": grad_sigma_q_field,
        "grad_mu_p": grad_mu_p_field,
        "grad_sigma_p": grad_sigma_p_field
    }






def compute_morphism_kl_gradient_primitives(Phi, mu_q, Sigma_q, mu_p, Sigma_p, eps=1e-8):
    """
    Compute shared intermediates needed to evaluate ∂/∂Φ D_KL(p || Φ·q)
    
    Args:
        Phi      : (K_p, K_q) linear morphism matrix Φ
        mu_q     : (K_q,)     mean of belief q
        Sigma_q  : (K_q, K_q) covariance of belief q
        mu_p     : (K_p,)     mean of model p
        Sigma_p  : (K_p, K_p) covariance of model p
        eps      : stabilizer for SPD inverse

    Returns:
        dict containing:
            - Delta_mu     : (K_p,)     = mu_p - Φ·mu_q
            - Sigma_q_inv  : (K_q, K_q)
            - M            : (K_p, K_p) = Φ Σ_q Φᵀ
            - M_inv        : (K_p, K_p)
            - term_trace   : (K_p, K_p) = M⁻¹ Σ_p M⁻¹
            - term_logdet  : (K_p, K_q) = M⁻¹ Φ Σ_q
    """
    K_p, K_q = Phi.shape

    # Compute Δμ = μ_p - Φ·μ_q
    Delta_mu = mu_p - Phi @ mu_q

    # Inverse of Σ_q
    Sigma_q_inv = safe_inv(Sigma_q, eps=eps)

    # M = Φ Σ_q Φᵀ
    M = Phi @ Sigma_q @ Phi.T

    # Inverse of M
    M_inv = safe_inv(M, eps=eps)

    # Precompute reusable trace/logdet gradient terms
    term_trace = 0.5*M_inv @ Sigma_p @ M_inv  # (K_p, K_p)
    term_logdet = 0.5* M_inv @ Phi @ Sigma_q  # (K_p, K_q)

    return {
        "Delta_mu": Delta_mu,
        "Sigma_q_inv": Sigma_q_inv,
        "M": M,
        "M_inv": M_inv,
        "term_trace": term_trace,
        "term_logdet": term_logdet
    }


def compute_morphism_kl_gradient_feedback(Phi, mu_q, Sigma_q, mu_p, Sigma_p, eps=1e-8):
    """
    Compute ∇_Φ KL(p || Φ·q), plus ∇_{μ_q}, ∇_{Σ_q}, ∇_{μ_p}, ∇_{Σ_p}
    
    Args:
        Phi      : (K_p, K_q) morphism matrix Φ
        mu_q     : (K_q,)     belief mean
        Sigma_q  : (K_q, K_q) belief covariance
        mu_p     : (K_p,)     model mean
        Sigma_p  : (K_p, K_p) model covariance
        eps      : small regularizer for inverse ops
        
    Returns:
        dict of gradients:
            - "grad_Phi"     : (K_p, K_q)
            - "grad_mu_q"    : (K_q,)
            - "grad_sigma_q" : (K_q, K_q)
            - "grad_mu_p"    : (K_p,)
            - "grad_sigma_p" : (K_p, K_p)
    """
    # Shared terms
    primitives = compute_morphism_kl_gradient_primitives(
        Phi, mu_q, Sigma_q, mu_p, Sigma_p, eps=eps
    )

    Delta_mu    = primitives["Delta_mu"]
    M_inv       = primitives["M_inv"]
    term_logdet = primitives["term_logdet"]
    term_trace  = primitives["term_trace"]

    # Gradient w.r.t. Φ (three terms: Mahalanobis, logdet, trace)
    term_mahal = M_inv @ np.outer(Delta_mu, Delta_mu) @ M_inv @ Phi @ Sigma_q
    grad_Phi = term_mahal + term_logdet - term_trace @ Phi @ Sigma_q

    # Other gradients
    grad_mu_q    = grad_feedback_wrt_mu_q_field(mu_q, Sigma_q, mu_p, Phi, eps)
    grad_sigma_q = grad_feedback_wrt_sigma_q_field(mu_q, Sigma_q, mu_p, Sigma_p, Phi, eps)
    grad_mu_p    = grad_feedback_mu_p(mu_p, Sigma_p, mu_q, Sigma_q, Phi, eps)
    grad_sigma_p = grad_feedback_sigma_p(mu_p, Sigma_p, mu_q, Sigma_q, Phi, eps)

    return {
        "grad_Phi": grad_Phi,
        "grad_mu_q": grad_mu_q,
        "grad_sigma_q": grad_sigma_q,
        "grad_mu_p": grad_mu_p,
        "grad_sigma_p": grad_sigma_p
    }






#unwired below
def grad_feedback_wrt_mu_q_field(mu_q_field, sigma_q_field, mu_p_field, Phi, eps=1e-8):
    """
    Compute ∂/∂μ_q D_KL(p || Φ q) over a spatial field (H, W, K_q).
    
    Args:
        mu_q_field    : (..., K_q)
        sigma_q_field : (..., K_q, K_q)
        mu_p_field    : (..., K_p)
        Phi           : (..., K_p, K_q)
        eps           : regularization for inversion
        
    Returns:
        grad_mu_q     : (..., K_q), gradient field
    """
    # Compute pushforward mean: Φ μ_q
    mu_q_push = np.einsum("...ij,...j->...i", Phi, mu_q_field)  # (..., K_p)

    # Compute pushforward covariance: Φ Σ_q Φ^T
    sigma_push = np.einsum("...ik,...kl,...jl->...ij", Phi, sigma_q_field, Phi)


    # Safe inverse
    sigma_push_inv = safe_inv(sigma_push, eps=eps)  # (..., K_p, K_p)

    # Δμ = μ_p − Φ μ_q
    delta_mu = mu_p_field - mu_q_push  # (..., K_p)

    # Compute gradient: - Φ^T (Φ Σ_q Φ^T)^{-1} (μ_p - Φ μ_q)
    tmp = np.einsum("...ij,...j->...i", sigma_push_inv, delta_mu)  # (..., K_p)
    grad_mu_q = -np.einsum("...ji,...j->...i", Phi, tmp)  # (..., K_q)

    return grad_mu_q



def grad_feedback_wrt_sigma_q_field(mu_q_field, sigma_q_field, mu_p_field,
                               sigma_p_field, Phi, eps=1e-8):
    """
    Compute ∂/∂Σ_q D_KL(p || Φ q) over spatial field (H, W, K_q, K_q)

    Args:
        mu_q_field     : (..., K_q)
        sigma_q_field  : (..., K_q, K_q)
        mu_p_field     : (..., K_p)
        sigma_p_field  : (..., K_p, K_p)
        Phi            : (..., K_p, K_q)
        eps            : regularization epsilon

    Returns:
        grad_sigma_q   : (..., K_q, K_q)
    """
    # Φ μ_q
    mu_q_push = np.einsum("...ij,...j->...i", Phi, mu_q_field)  # (..., K_p)

    # Pushforwarded covariance: Φ Σ_q Φ^T
    Phi_T = np.swapaxes(Phi, -1, -2)  # (..., K_q, K_p)
    sigma_q_push = np.einsum("...ik,...kl,...jl->...ij", Phi, sigma_q_field, Phi)

    sigma_q_push_inv = safe_inv(sigma_q_push, eps=eps)

    # Δμ = μ_p - Φ μ_q
    delta_mu = mu_p_field - mu_q_push  # (..., K_p)

    # Mahalanobis term: A = Δμ Δμᵀ
    A = np.einsum("...i,...j->...ij", delta_mu, delta_mu)  # (..., K_p, K_p)

    # Terms
    inv_term     = sigma_q_push_inv
    mahal_term   = np.einsum("...ik,...kl,...lj->...ij",
                             sigma_q_push_inv, A, sigma_q_push_inv)
    trace_term   = np.einsum("...ik,...kl,...lj->...ij",
                             sigma_q_push_inv, sigma_p_field, sigma_q_push_inv)

    # Combine: M = [inv - mahal - trace]
    M = inv_term - mahal_term - trace_term  # (..., K_p, K_p)

    # Final gradient: Φᵀ M Φ
    grad_sigma_q = 0.5 * np.einsum("...ki,...kl,...lj->...ij", Phi, M, Phi)


    return grad_sigma_q



def grad_feedback_mu_p(mu_p_field, sigma_p_field,
                       mu_q_field, sigma_q_field, Phi, eps=1e-8):
    """
    Compute ∂/∂μ_p D_KL(p || Φ q) over spatial field (H, W, K_p)
    """
    # Pushforward belief mean
    mu_q_push = np.einsum("...ij,...j->...i", Phi, mu_q_field)  # (..., K_p)

    # Pushforward belief covariance: Φ Σ_q Φ^T
    sigma_q_push = np.einsum("...ik,...kl,...jl->...ij", Phi, sigma_q_field, Phi)

    sigma_q_push_inv = safe_inv(sigma_q_push, eps=eps)

    delta_mu = mu_p_field - mu_q_push  # (..., K_p)
    grad_mu_p = np.einsum("...ij,...j->...i", sigma_q_push_inv, delta_mu)

    return grad_mu_p


def grad_feedback_sigma_p(mu_p_field, sigma_p_field,
                          mu_q_field, sigma_q_field, Phi, eps=1e-8):
    """
    Compute ∂/∂Σ_p D_KL(p || Φ q) over spatial field (H, W, K_p, K_p)
    """
    # Pushforward belief covariance
    sigma_q_push = np.einsum("...ik,...kl,...jl->...ij", Phi, sigma_q_field, Phi)

    sigma_q_push_inv = safe_inv(sigma_q_push, eps=eps)

    sigma_p_inv = safe_inv(sigma_p_field, eps=eps)

    grad_sigma_p = 0.5 * (sigma_q_push_inv - sigma_p_inv)  # (..., K_p, K_p)
    return grad_sigma_p











