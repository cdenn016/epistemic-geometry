# -*- coding: utf-8 -*-
"""
Created on Sun Jul 13 18:54:27 2025

@author: chris and christine
"""

# === meta_agent_plots.py ===
# Visualization utilities for meta-agent condensation and clustering

from generalized_diagnostics_metrics import compute_pairwise_kl_belief, compute_pairwise_kl_model

from generalized_diagnostics_metrics import kl_divergence
from bundle_morphism_utils import safe_batch_apply_morphism_nat

from meta_gauge_fields import _field_norm
import os
from pathlib import Path
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import networkx as nx

import config  # only if you reference config.support_cutoff_eps










def _post_build_summaries(meta_agents):
    for P in meta_agents:
        n_phi = _field_norm(P.phi, P.mask)
        n_phim = _field_norm(P.phi_model, P.mask)
        print(f"[META] parent {P.id}: ⟨‖φ‖⟩={n_phi:.4f}  ⟨‖φ̃‖⟩={n_phim:.4f}")



def _snapshot_parents_npz(parents, path):
    """Plain, safe snapshot of parents for diagnostics."""
    
    os.makedirs(os.path.dirname(path), exist_ok=True)
    masks, phi, phi_model = [], [], []
    for P in parents:
        masks.append(np.asarray(getattr(P, "mask", 0), dtype=np.float32))
        phi.append(np.asarray(getattr(P, "phi", 0), dtype=np.float32))
        phi_model.append(np.asarray(getattr(P, "phi_model", 0), dtype=np.float32))
    np.savez_compressed(path,
                        masks=np.stack(masks, 0),
                        phi=np.stack(phi, 0),
                        phi_model=np.stack(phi_model, 0))


def _append_parent_metrics_csv(outdir, step, parents):
   
    rows = []
    for pid, P in enumerate(parents):
        m = np.asarray(getattr(P, "mask", 0), dtype=np.float32)
        area = float((m > 0.3).sum())
        # A couple of simple, universal summaries:
        n_phi = np.sqrt(np.maximum((np.asarray(P.phi)**2).sum(axis=-1), 0.0)) if hasattr(P, "phi") else 0.0
        n_mod = np.sqrt(np.maximum((np.asarray(P.phi_model)**2).sum(axis=-1), 0.0)) if hasattr(P, "phi_model") else 0.0
        e_phi_in = float((n_phi * (m > 0.3)).sum()) if hasattr(P, "phi") else 0.0
        e_phi_all = float(n_phi.sum()) if hasattr(P, "phi") else 0.0
        rows.append({
            "step": step,
            "parent": pid,
            "mask_area_thr0p3": area,
            "Ephi_in": e_phi_in,
            "Ephi_all": e_phi_all,
            "Ephi_frac_in": (e_phi_in / (e_phi_all + 1e-9)) if e_phi_all else 0.0,
        })
    df = pd.DataFrame(rows)
    path = os.path.join(outdir, "parent_metrics.csv")
    if os.path.exists(path):
        df.to_csv(path, mode="a", header=False, index=False)
    else:
        df.to_csv(path, index=False)



def save_parents_snapshot(parents, out_path):
    """
    Save just what we need for diagnostics in a plain .npz (no fancy pickling).
    """
    
    os.makedirs(os.path.dirname(out_path), exist_ok=True)

    masks, phi, phi_model = [], [], []
    for P in parents:
        masks.append(np.asarray(getattr(P, "mask", 0), dtype=np.float32))
        phi.append(np.asarray(getattr(P, "phi", 0), dtype=np.float32))
        phi_model.append(np.asarray(getattr(P, "phi_model", 0), dtype=np.float32))
    np.savez_compressed(out_path,
                        masks=np.stack(masks, 0),
                        phi=np.stack(phi, 0),
                        phi_model=np.stack(phi_model, 0))









def plot_cluster_size_hist(labels, outpath):
    labels = np.asarray(labels)
    labs = labels[labels >= 0]
    if labs.size == 0:
        return
    counts = np.bincount(labs)
    plt.figure()
    plt.bar(np.arange(len(counts)), counts)
    plt.xlabel("Cluster id")
    plt.ylabel("# children")
    plt.title("Meta-agent cluster sizes")
    plt.tight_layout()
    plt.savefig(outpath, dpi=150)
    plt.close()

def plot_child_parent_overlay(children, parents, labels, outpath, max_examples=12):
    """
    Show child masks and the parent's mask/centroid on small panels.
    Assumes each child has exactly one parent.
    """
    labels = np.asarray(labels)
    idx = np.where(labels >= 0)[0]
    n = min(idx.size, max_examples)
    if n == 0:
        return
    cols = min(4, n)
    rows = int(np.ceil(n / cols))
    fig, axes = plt.subplots(rows, cols, figsize=(3.5*cols, 3.5*rows))
    axes = np.atleast_1d(axes).ravel()

    for k, ci in enumerate(idx[:n]):
        ax = axes[k]
        c = children[ci]
        pid = int(labels[ci])
        p = parents[pid]

        # child mask
        ax.imshow(c.mask, origin="lower", interpolation="nearest", alpha=0.9)
        # parent mask outline (simple threshold)
        pm = (p.mask > 1e-6).astype(float)
        ax.contour(pm, levels=[0.5], linewidths=1.2)

        # centroid marker if available
        if hasattr(p, "center") and p.center is not None:
            y, x = p.center
            ax.plot(x, y, "o", ms=4)

        ax.set_title(f"child {ci} → parent {pid}")
        ax.set_xticks([]); ax.set_yticks([])

    for j in range(n, rows*cols):
        axes[j].axis("off")

    plt.tight_layout()
    plt.savefig(outpath, dpi=150)
    plt.close()





def plot_crossscale_kl_hist(vals, outpath):
    a = np.array([v for v in vals if np.isfinite(v)])
    if a.size == 0:
        return
    plt.figure()
    plt.hist(a, bins=20)
    plt.xlabel("KL(q_child || Λ_dn_q q_parent)")
    plt.ylabel("count")
    plt.title("Cross-scale KL (q) — child → parent")
    plt.tight_layout()
    plt.savefig(outpath, dpi=150)
    plt.close()


def plot_generic_alignment_network(
    kl_matrix: np.ndarray,
    cluster_labels: np.ndarray,
    threshold: float,
    outpath: str = "alignment_output/alignment_network.png",
    title: str = "Epistemic Alignment Network",
    node_size: int = 500,
    show_labels: bool = True
):
    """
    Visualize agent alignment as a network.
    Edges connect agents with KL < threshold.
    Nodes are colored by cluster_labels.
    """


    N = kl_matrix.shape[0]
    G = nx.Graph()

    # 1) Add nodes with cluster labels
    for i in range(N):
        G.add_node(i, cluster=cluster_labels[i])

    # 2) Add edges for D_KL(i,j) < threshold
    for i in range(N):
        for j in range(i + 1, N):
            d = kl_matrix[i, j]
            if np.isfinite(d) and d < threshold:
                G.add_edge(i, j, weight=np.exp(-d))  # similarity weight

    # 3) Node positions and colors
    pos = nx.spring_layout(G, seed=42)  # deterministic layout
    unique_labels = sorted(set(cluster_labels))
    color_map = {label: plt.cm.tab10(i % 10) for i, label in enumerate(unique_labels)}
    node_colors = [color_map.get(cluster_labels[i], "gray") for i in range(N)]

    # 4) Plot
    plt.figure(figsize=(8, 6))
    nx.draw_networkx_nodes(
        G, pos,
        node_color=node_colors,
        node_size=node_size,
        edgecolors="black"
    )
    nx.draw_networkx_edges(G, pos, alpha=0.5)

    if show_labels:
        nx.draw_networkx_labels(G, pos, font_size=10, font_color="white")

    plt.title(f"{title} (ε = {threshold:.3f})")
    plt.axis("off")

    # 5) Save
    Path(outpath).parent.mkdir(parents=True, exist_ok=True)
    plt.savefig(outpath, dpi=150)
    plt.close()


def plot_matrix(kl_matrix, labels=None, outdir="alignment_output", fname="alignment_matrix.png",
                label="D_KL(q_i || Ω q_j)", title="Pairwise Alignment Matrix", cmap="viridis"):
    Path(outdir).mkdir(parents=True, exist_ok=True)
    N = kl_matrix.shape[0]

    plt.figure(figsize=(8, 6))
    im = plt.imshow(kl_matrix, cmap=cmap, interpolation="nearest")
    cbar = plt.colorbar(im)
    cbar.set_label(label)

    plt.title(title)
    plt.xlabel("Agent j")
    plt.ylabel("Agent i")

    if labels is not None and len(labels) == N:
        ticks = np.arange(N)
        plt.xticks(ticks)
        plt.yticks(ticks)
        ax = plt.gca()
        for axis, tick_labels in zip([ax.xaxis, ax.yaxis], [ax.get_xticklabels(), ax.get_yticklabels()]):
            for k, lbl in enumerate(tick_labels):
                color = f"C{labels[k] % 10}" if labels[k] >= 0 else "gray"
                lbl.set_color(color)

    savepath = Path(outdir) / fname
    plt.tight_layout()
    plt.savefig(savepath, dpi=150)
    plt.close()
    print(f"[\u2713] Saved matrix → {savepath}")


def plot_cluster_order_parameters(cluster_R, outpath=None):
    labs = sorted(cluster_R.keys())
    R_vals = [cluster_R[l][0] for l in labs]
    sigma_vals = [cluster_R[l][1] for l in labs]

    fig, ax = plt.subplots(figsize=(6, 4))
    bars = ax.bar([str(l) for l in labs], R_vals, color="tab:blue")
    ax.set_xlabel("Cluster")
    ax.set_ylabel(r"$R_C$")
    ax.set_title("Local Order Parameter per Meta-Agent")

    for bar, σ in zip(bars, sigma_vals):
        ax.text(bar.get_x() + bar.get_width() / 2, bar.get_height(), f"σ={σ:.1e}",
                ha='center', va='bottom', fontsize=8)

    plt.tight_layout()
    if outpath:
        Path(outpath).parent.mkdir(parents=True, exist_ok=True)
        fig.savefig(outpath, dpi=150)
    plt.close()


def plot_intra_kl_distribution(cluster_stats, outpath, show_fliers=False):
    labels, data = [], []
    for lab in sorted(cluster_stats):
        vals = cluster_stats[lab]['intra_vals']
        if vals.size:
            labels.append(str(lab))
            data.append(vals)

    if not data:
        print("[!] No intra-cluster KL values to plot.")
        return

    fig, ax = plt.subplots(figsize=(6, 4))
    ax.boxplot(data, vert=True, showfliers=show_fliers)
    ax.set_xticklabels(labels)
    ax.set_ylabel("Pointwise D_KL")
    ax.set_title("Intra-cluster KL Distributions")
    ax.grid(True, linestyle='--', alpha=0.4)

    fig.tight_layout()
    fig.savefig(outpath, dpi=150)
    plt.close(fig)


def plot_inter_vs_intra(cluster_stats, outpath=None):
    labels = sorted(cluster_stats)
    intra = [cluster_stats[l]['intra_mean'] for l in labels]
    extra = [cluster_stats[l]['extra_mean'] for l in labels]
    x = np.arange(len(labels))

    fig, ax = plt.subplots(figsize=(6, 4))
    width = 0.35
    ax.bar(x - width/2, intra, width=width, label='Intra-cluster KL')
    ax.bar(x + width/2, extra, width=width, label='Extra-cluster KL')

    ax.set_xticks(x)
    ax.set_xticklabels([str(l) for l in labels])
    ax.set_ylabel('Mean D_KL')
    ax.set_title('Mean KL Divergence: Intra vs Extra per Cluster')
    ax.legend()
    ax.grid(True, linestyle='--', alpha=0.4)

    fig.tight_layout()
    if outpath:
        Path(outpath).parent.mkdir(parents=True, exist_ok=True)
        fig.savefig(outpath, dpi=150)
    plt.close(fig)


def plot_spatial_cluster_map(agents, labels, outpath=None):
    from matplotlib import cm
    cmap = cm.get_cmap('tab10')
    fig, ax = plt.subplots(figsize=(5, 5))

    for i, ag in enumerate(agents):
        lab = labels[i]
        if lab < 0:
            continue
        mask_bool = ag.mask > getattr(config, "support_cutoff_eps", 0.0)
        color = cmap(lab % cmap.N)
        ax.contour(mask_bool, levels=[0.5], colors=[color], linewidths=1)
        if hasattr(ag, "center") and ag.center is not None:
            cx, cy = ag.center
            ax.text(cy, cx, str(i), color=color, ha='center', va='center', fontsize=7)

    ax.set_title('Spatial Cluster Map')
    ax.axis('off')
    fig.tight_layout()

    if outpath:
        Path(outpath).parent.mkdir(parents=True, exist_ok=True)
        fig.savefig(outpath, dpi=150, bbox_inches='tight')
        print(f"[\u2713] Saved cluster map → {outpath}")
    plt.close(fig)


def plot_curvature_heatmap(agents, labels, generators, outpath=None):
    from omega import compute_field_strength

    if not agents:
        print("[WARN] Empty agent list. Aborting curvature heatmap.")
        return

    grid_shape = agents[0].phi.shape[:2]
    curvature_sum = np.zeros(grid_shape, dtype=float)

    for i, ag in enumerate(agents):
        if labels[i] < 0:
            continue
        try:
            F_dict = compute_field_strength(ag.phi, generators)
            F_vals = list(F_dict.values())
            if all(F.ndim == 4 for F in F_vals):
                norm_per_dir = [np.linalg.norm(F, axis=(-2, -1)) for F in F_vals]
                norm_F = np.sum(norm_per_dir, axis=0)
            else:
                raise ValueError(f"Unexpected F shapes {[F.shape for F in F_vals]}")
            curvature_sum += norm_F
        except Exception as e:
            print(f"[!] Agent {i} curvature error: {e}")

    fig, ax = plt.subplots(figsize=(5, 5))
    im = ax.imshow(curvature_sum, origin='lower', cmap='plasma')
    ax.set_title('Curvature Norm Heatmap (‖F‖)')
    ax.axis('off')
    for i, ag in enumerate(agents):
        if labels[i] < 0:
            continue
        ax.contour(ag.mask > config.support_cutoff_eps, levels=[0.5], colors='white', linewidths=0.5)

    if curvature_sum.max() > curvature_sum.min():
        fig.colorbar(im, ax=ax, label='‖F‖')

    fig.tight_layout()
    if outpath:
        Path(outpath).parent.mkdir(parents=True, exist_ok=True)
        fig.savefig(outpath, dpi=150, bbox_inches='tight')
        print(f"[\u2713] Saved curvature heatmap → {outpath}")
    plt.close(fig)
    
def plot_support_phi_summary(
    agents,
    per_df,
    phi_attr="phi",
    kl_col="kl_align",
    color="red",
    phi_title="Φ Norms",
    kl_title="Alignment per Agent",
    text="No per-agent metrics"
):
    """
    Plot:
    1. Agent support masks
    2. Spatial heatmap of ‖φ‖ or ‖φ̃‖ over domain
    3. Per-agent bar chart of final KL values

    Args:
        agents    : list of Agent objects
        per_df    : DataFrame with per-agent metrics
        phi_attr  : "phi" or "phi_model"
        kl_col    : Column name in per_df for alignment KL
        color     : Bar color for panel 3
        phi_title : Title for φ panel
        kl_title  : Title for alignment panel
        text      : Message if per_df is missing
    """
    

    fig, axes = plt.subplots(1, 3, figsize=(18, 6))

    # ───── Panel 1: Agent support masks with indices ─────
    ax0 = axes[0]
    for idx, agent in enumerate(agents):
        mask = agent.mask
        ax0.contour(mask, levels=[getattr(config, "support_cutoff_eps", 1e-3)],
                    colors='black', linewidths=1)
        cx, cy = agent.center
        ax0.text(cy, cx, str(idx), color=color,
                 ha='center', va='center', fontsize=9, weight='bold')
    ax0.set_title("Agent Support Contours")
    ax0.axis('off')

    # ───── Panel 2: Φ or Φ̃ Norm Spatial Sum ─────
    ax1 = axes[1]
    domain_shape = getattr(config, "domain_size", agents[0].phi.shape[:2])
    combined = np.zeros(domain_shape, dtype=float)
    for agent in agents:
        phi = getattr(agent, phi_attr)  # (H, W, d)
        combined += np.linalg.norm(phi, axis=-1)
    im = ax1.imshow(combined, origin='lower', cmap='viridis')
    ax1.set_title(f"Sum of {phi_title}")
    ax1.axis('off')
    fig.colorbar(im, ax=ax1, fraction=0.046, pad=0.04)

    # ───── Panel 3: Per-agent KL bar chart ─────
    ax2 = axes[2]
    if per_df is not None and kl_col in per_df.columns:
        last_vals = per_df.groupby('agent')[kl_col].last()
        ax2.bar(last_vals.index, last_vals.values, color=color)
        ax2.set_xlabel("Agent Index")
        ax2.set_ylabel(kl_col)
        ax2.set_title(kl_title)
    else:
        ax2.text(0.5, 0.5, text, ha='center', va='center', fontsize=10)
        ax2.set_title(kl_title)
        ax2.axis('off')

    plt.tight_layout()
    plt.show()


def plot_pairwise_pointwise_heatmap(
    agents, generators, params,
    i: int, j: int,
    mode: str,
    outdir: str = "alignment_output"
):
    """
    Compute and plot the per-point KL divergence heatmap between agents i and j.
    
    Args:
        agents     : list of Agent objects
        generators : Lie algebra basis
        params     : dict with simulation params (must include 'overlap_eps')
        i, j       : agent indices
        mode       : "belief" or "model"
        outdir     : output root directory
    """
    
    # Select KL function
    if mode == "belief":
        fn = compute_pairwise_kl_belief
        subdir = "belief_pointwise"
    elif mode == "model":
        fn = compute_pairwise_kl_model
        subdir = "model_pointwise"
    else:
        raise ValueError(f"Invalid mode: {mode}. Must be 'belief' or 'model'.")

    kl_mat, pw_dict = fn(agents, generators, params, return_pointwise=True)

    if (i, j) not in pw_dict:
        if len(pw_dict) == 0:
            raise RuntimeError("No overlapping agent pairs found for pointwise KL.")
        alt = next(iter(pw_dict))
        print(f"[WARN] No overlap for ({i}, {j}); using fallback pair {alt}")
        i, j = alt
        pw = pw_dict[alt]
    else:
        pw = pw_dict[(i, j)]

    # Build full heatmap
    mask_i = agents[i].mask > params["overlap_eps"]
    mask_j = agents[j].mask > params["overlap_eps"]
    heat = np.zeros_like(mask_i, dtype=float)
    heat[mask_i & mask_j] = pw

    # Plot
    fig, ax = plt.subplots(figsize=(5, 5))
    im = ax.imshow(heat, origin='lower', cmap='magma')
    fig.colorbar(im, ax=ax, label=f"Pointwise D_KL ({mode})")
    ax.set_title(f"{mode.capitalize()} Pointwise KL: agents {i} ↔ {j}")
    ax.axis('off')

    # Save
    outpath = Path(outdir) / subdir
    outpath.mkdir(parents=True, exist_ok=True)
    fpath = outpath / f"pointwise_{mode}_{i}_{j}.png"
    fig.savefig(fpath, dpi=150)
    plt.close(fig)


def _mask_area(m, thr=0.3):
    return int((m > thr).sum())

def plot_parent_masks_grid(parents, children=None, outdir="meta_agent_analysis/parent_masks",
                           max_parents=12, thr=0.3, cmap="tab20"):
    """
    Shows the largest `max_parents` parent masks as a grid.
    If `children` is provided, outlines child supports (thin white).
    """
    Path(outdir).mkdir(parents=True, exist_ok=True)
    H, W = parents[0].mask.shape
    areas = [(_mask_area(P.mask, thr), i) for i, P in enumerate(parents)]
    areas.sort(reverse=True)
    idx = [i for _, i in areas[:max_parents]]
    n = len(idx)
    cols = min(4, max(1, n))
    rows = int(np.ceil(n / cols))

    fig, axes = plt.subplots(rows, cols, figsize=(4*cols, 4*rows), squeeze=False)
    axes = axes.ravel()

    cmap_obj = plt.get_cmap(cmap)
    for k, ax in enumerate(axes[:n]):
        pid = idx[k]
        P = parents[pid]
        # parent heat (soft mask as alpha)
        color = cmap_obj(pid % cmap_obj.N)
        rgb = np.array(color[:3])[None, None, :]
        alpha = np.clip(P.mask, 0, 1)
        img = np.ones((H, W, 3), dtype=float)
        img = (1 - alpha[..., None]) * img + alpha[..., None] * rgb
        ax.imshow(img, origin="upper", interpolation="nearest")

        # parent boundary at threshold
        cs = ax.contour(P.mask, levels=[thr], colors=[color], linewidths=2)
        ax.clabel(cs, inline=True, fontsize=8, fmt={thr: f"P{pid}"})

        # optional: outline children
        if children is not None:
            for c in getattr(P, "child_ids", []):
                cmask = (children[c].mask > 1e-6).astype(float)
                ax.contour(cmask, levels=[0.5], colors="w", linewidths=0.5, alpha=0.7)

        ax.set_xticks([]); ax.set_yticks([])
        ax.set_title(f"P{pid} | area≈{_mask_area(P.mask, thr)}")

    for ax in axes[n:]:
        ax.axis("off")

    fig.tight_layout()
    out = os.path.join(outdir, "parent_masks_grid.png")
    plt.savefig(out, dpi=160)
    plt.close(fig)
    print(f"[PLOT] Grid → {out}")

def plot_parent_child_overlay(agents, parents, parent_id, outpath,
                              thr=0.3, show_centers=True, cmap="tab20"):
    """
    One parent: soft mask background, boundary, all its children outlined.
    """
    P = parents[parent_id]
    H, W = P.mask.shape
    cmap_obj = plt.get_cmap(cmap)
    color = cmap_obj(parent_id % cmap_obj.N)

    fig, ax = plt.subplots(figsize=(6, 6))
    # parent fill
    rgb = np.array(color[:3])[None, None, :]
    alpha = np.clip(P.mask, 0, 1)
    img = (1 - alpha[..., None]) * np.ones((H, W, 3)) + alpha[..., None] * rgb
    ax.imshow(img, origin="upper", interpolation="nearest")

    # parent boundary
    ax.contour(P.mask, levels=[thr], colors=[color], linewidths=2)

    # children outlines
    for c in getattr(P, "child_ids", []):
        cmask = (agents[c].mask > 1e-6).astype(float)
        ax.contour(cmask, levels=[0.5], colors="w", linewidths=0.8, alpha=0.8)

    # centers
    if show_centers:
        if hasattr(P, "center"):
            cx, cy = P.center
            ax.plot(cx, cy, marker="x", ms=8, mew=2, color=color)
        for c in getattr(P, "child_ids", []):
            if hasattr(agents[c], "center"):
                cx, cy = agents[c].center
                ax.plot(cx, cy, marker=".", ms=4, color="w", alpha=0.7)

    ax.set_title(f"Parent P{parent_id} (thr={thr})")
    ax.set_xticks([]); ax.set_yticks([])
    fig.tight_layout()
    Path(Path(outpath).parent).mkdir(parents=True, exist_ok=True)
    plt.savefig(outpath, dpi=180)
    plt.close(fig)
    print(f"[PLOT] Overlay P{parent_id} → {outpath}")




def plot_parent_iou(parents, outpath, thr=0.3):
    M = len(parents)
    hard = [(P.mask > thr).astype(np.uint8) for P in parents]
    areas = np.array([m.sum() for m in hard], dtype=float) + 1e-12
    iou = np.zeros((M, M), dtype=float)
    for i in range(M):
        for j in range(M):
            inter = np.logical_and(hard[i], hard[j]).sum()
            union = np.logical_or(hard[i], hard[j]).sum() + 1e-12
            iou[i, j] = inter / union
    fig, ax = plt.subplots(figsize=(6,5))
    im = ax.imshow(iou, vmin=0, vmax=1, interpolation="nearest")
    fig.colorbar(im, ax=ax, fraction=0.046, pad=0.04, label="IoU")
    ax.set_title("Parent–Parent IoU")
    ax.set_xlabel("Parent j"); ax.set_ylabel("Parent i")
    plt.tight_layout()
    Path(Path(outpath).parent).mkdir(parents=True, exist_ok=True)
    plt.savefig(outpath, dpi=160)
    plt.close(fig)
    print(f"[PLOT] IoU → {outpath}")




def render_parent_masks(meta_agents, agents, basedir, level="L0", thr=0.3):
    # Headless-safe
    import matplotlib
    matplotlib.use("Agg")
    from pathlib import Path
    from importlib import reload
    import numpy as np
    import meta_agent_plots as MAP
    MAP = reload(MAP)

    level_dir = Path(basedir) / level
    plots_dir = level_dir / "parent_masks"
    plots_dir.mkdir(parents=True, exist_ok=True)

    areas = [int((getattr(P, "mask", 0) > thr).sum()) for P in meta_agents]
    print(f"[PLOT] parents={len(meta_agents)}  nonzero_masks={sum(a > 0 for a in areas)}  top_areas={sorted(areas, reverse=True)[:6]}")

    if not any(a > 0 for a in areas):
        # fallback: union so you still see something
        for P in meta_agents:
            if not hasattr(P, "child_ids"):
                continue
            # ensure boolean mask for OR ops
            um = np.zeros_like(agents[0].mask, dtype=bool)
            for cid in getattr(P, "child_ids", []):
                um |= (agents[cid].mask > 1e-6)
            # store as float32 for compatibility with plotting
            P.mask = um.astype(np.float32)

    MAP.plot_parent_masks_grid(meta_agents, children=agents,
                               outdir=str(plots_dir), max_parents=12, thr=thr)

    # overlays for biggest
    top_by_area = sorted(
        range(len(meta_agents)),
        key=lambda pid: int((meta_agents[pid].mask > thr).sum()),
        reverse=True
    )[:min(6, len(meta_agents))]

    for pid in top_by_area:
        MAP.plot_parent_child_overlay(
            agents, meta_agents, pid,
            outpath=str(plots_dir / f"parent_{pid:03d}_overlay.png"),
            thr=thr
        )

    MAP.plot_parent_iou(meta_agents, outpath=str(plots_dir / "parent_iou.png"), thr=thr)
    print(f"[PLOT] Outputs → {plots_dir}")

