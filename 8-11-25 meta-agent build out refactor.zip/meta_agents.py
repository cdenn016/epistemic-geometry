# ────────────────────────
# Standard libs
# ────────────────────────
import json
from pathlib import Path

# ────────────────────────
# Scientific
# ────────────────────────
import numpy as np

# ────────────────────────
# Project
# ────────────────────────
import config
from generalized_simulation import run_simulation
from generalized_io_utils import (
    load_final_step,
    save_meta_agents,
    save_meta_labels,
)

from meta_agent_utils import (
    _prepare_generators,
    
    _ensure_parent_slots,
    _kl_plateau,
    wire_child_parent_links,
    initialize_parents_from_children,
    build_runtime_params_for_xscale,
    
)
from xscale_helpers import compute_avg_crossscale_kl_q
from meta_gauge_fields import coarsen_phi_from_children

from meta_agent_plots import (
    render_parent_masks,
    plot_cluster_size_hist,
    plot_child_parent_overlay,
    plot_crossscale_kl_hist,
    _post_build_summaries
    
)
from meta_alignment import ( 
    _run_alignment_suite, build_meta_agents_from_clusters,_choose_best_clustering
    
    )



def _run_child_with_steps(params, steps: int | None, outdir: str):
    # lightweight steps override without touching your run loop internals
    old_steps = config.steps
    if steps is not None:
        config.steps = int(steps)
    try:
        agents_after, metric_log = run_simulation(
            outdir=outdir,
            params=params,
            resume=False,         # <<< force fresh run
            fresh_outdir=True,    # <<< rotate old checkpoints_Lk if they exist
            clear_agent_logs=True # <<< clear per_agent_metrics.csv
        )
    finally:
        config.steps = old_steps
    return agents_after, metric_log



def run_meta_recursion(
    *,
    levels: int = 2,
    base_ckpt: str = "checkpoints",
    out_root: str = "meta_agent_analysis",

    # alignment/logging
    log_eps: float = 1e-6,
    overlap_eps: float = 1e-6,

    # simulation control
    steps_per_level: list[int] | tuple[int, ...] | None = None,
    do_sim: bool = True,
    plateau_window: int = 15,
    plateau_tol: float = 1e-4,

    # plotting & saving
    do_plots: bool = True,
    save_artifacts: bool = True,

    # agreement-mask knobs (passed to initializer)
    tau_align: float = 0.30,
    m_core: int = 2,
    A_min: int = 10,
    soft: bool = True,
    smooth_iters: int = 1,

    # support gating after agreement
    support_mode: str = "kofn",   # "none" | "all" | "kofn"
    k_support: int | None = None, # if "kofn": require ≥k kids; None→ceil(0.5*C)

    # safety: skip XSCALE if parents have no support
    skip_when_empty: bool = True,
):
    """
    One-call meta recursion. No CLI. Returns a manifest dict.

    Typical call:
        manifest = run_meta_recursion(levels=3, base_ckpt="checkpoints",
                                      tau_align=0.3, m_core=2, support_mode="kofn")

    Notes:
    - Uses strict agreement masks (no union fallback).
    - Applies optional support gating (intersection / k-of-n / none) AFTER agreement.
    - Coarse-grains φ fields inside the agreed mask.
    - Optionally runs XSCALE at each level and checks for plateau stopping.
    """
  
    out_root = Path(out_root)
    out_root.mkdir(parents=True, exist_ok=True)

    manifest = {"base_ckpt": base_ckpt, "levels": []}

    for L in range(levels):
        print(f"\n========== META-RECURSION: LEVEL {L} ==========")
        level_dir = out_root / f"L{L}"
        level_dir.mkdir(parents=True, exist_ok=True)

        # 1) load agents + generators for this level
        ckpt = base_ckpt if L == 0 else f"{base_ckpt}_L{L}"
        agents = load_final_step(ckpt)
        if agents is None:
            raise FileNotFoundError(f"No step_XXXX.pkl found in {ckpt}/")
        Gq, Gp, generators = _prepare_generators()

        # 2) run alignment analyses and pick best clustering
        _run_alignment_suite(agents, generators, level_dir, log_eps, overlap_eps)
        best = _choose_best_clustering(agents, Gq, Gp, basedir=level_dir)

        # 3) build parents, wire links
        chosen_G = Gq if best["prefix"] == "kl" else Gp
        parents = build_meta_agents_from_clusters(agents, best["labels"], chosen_G)
        _ensure_parent_slots(parents, Kq=config.K_q, Kp=config.K_p)
        wire_child_parent_links(agents, parents, best["labels"])

        # 4) STRICT agreement masks via initializer (no union fallback)
        initialize_parents_from_children(
            parents, agents, best["labels"],
            use_agreement_masks=True,
            tau_align=tau_align, m_core=m_core, A_min=A_min,
            soft=soft, smooth_iters=smooth_iters,
            generators=Gq, field="q",
        )

        # 5) Optional support gating AFTER agreement (prevents union leakage)
        for pid, P in enumerate(parents):
            kid_ids = list(getattr(P, "child_ids", []))
            if not kid_ids:
                P.mask = np.zeros_like(agents[0].mask, dtype=np.float32)
                print(f"[MASK DEBUG L{L} P{pid}] no children", flush=True)
                continue

            if support_mode.lower() != "none":
                stack_bool = np.stack([(agents[cid].mask > 1e-6) for cid in kid_ids], axis=0)  # (C,H,W)
                if support_mode.lower() == "all":
                    gate = stack_bool.all(axis=0)  # strict intersection
                    k_dbg = f"all/{stack_bool.shape[0]}"
                else:  # "kofn"
                    Cg = stack_bool.shape[0]
                    k  = k_support if (k_support is not None) else int(np.ceil(0.5 * Cg))
                    gate = (stack_bool.sum(axis=0) >= k)
                    k_dbg = f"{k}/{Cg}"
                P.mask = (P.mask * gate.astype(np.float32)).astype(np.float32)
            else:
                k_dbg = "none"

            # Diagnostics (IoU vs union/intersection)
            stack_bool = np.stack([(agents[cid].mask > 1e-6) for cid in kid_ids], axis=0)
            union_bool = stack_bool.any(axis=0)
            inter_bool = stack_bool.all(axis=0)
            Pm = (P.mask > 0.3)
            def _iou(a,b):
                u = (a | b).sum()
                return float((a & b).sum()) / (u if u else 1.0)
            print(f"[MASK DEBUG L{L} P{pid}] area={int(Pm.sum())}  "
                  f"IoU(union)={_iou(Pm, union_bool):.3f}  IoU(inter)={_iou(Pm, inter_bool):.3f}  support={support_mode}({k_dbg})",
                  flush=True)

        # 6) Coarse-grain gauge fields (skip empty parents to avoid NaNs)
        for P in parents:
            if getattr(P, "mask", None) is not None and (P.mask > 0.0).any():
                coarsen_phi_from_children(
                    P, agents, field="phi",
                    weight_mode=lambda ch, P=P: ch.mask[..., None] * P.mask[..., None]
                )
                coarsen_phi_from_children(
                    P, agents, field="phi_model",
                    weight_mode=lambda ch, P=P: ch.mask[..., None] * P.mask[..., None]
                )
            else:
                P.phi       = np.zeros_like(agents[0].phi,       dtype=np.float32)
                P.phi_model = np.zeros_like(agents[0].phi_model, dtype=np.float32)

        _post_build_summaries(parents)

        # 7) quick visualization before any sim
        if do_plots:
            try:
                render_parent_masks(parents, agents, basedir=out_root, level=f"L{L}", thr=0.3)
            except Exception as e:
                print(f"[PLOTS] Skipped mask plots: {e}")

        # 8) persist meta artifacts
        if save_artifacts:
            save_meta_agents(parents, output_dir=str(level_dir / "meta_agent_fields"))
            save_meta_labels(best["labels"], path=str(level_dir / "meta_labels.csv"))

        # 9) run child simulation with XSCALE context
        plateau_mean = float("nan")
        hit_plateau = False
        metric_log = None

        if do_sim:
            # Bail if all parents are empty (optional)
            if skip_when_empty and not any((getattr(P, "mask", np.zeros_like(agents[0].mask)) > 0.0).any()
                                           for P in parents):
                print(f"[ABORT L{L}] No parent support after agreement gating; skipping XSCALE.", flush=True)
            else:
                runtime_params = build_runtime_params_for_xscale(Gq, Gp, parents, best["labels"])
                outdir = f"{base_ckpt}_L{L+1}"
                steps = None
                if steps_per_level is not None:
                    steps = steps_per_level[L] if L < len(steps_per_level) else steps_per_level[-1]
                _, metric_log = _run_child_with_steps(runtime_params, steps=steps, outdir=outdir)

                # plateau check
                if not metric_log:
                    print("[XSCALE] No metrics recorded; skipping plateau check.")
                else:
                    hit_plateau, plateau_mean = _kl_plateau(metric_log, window=plateau_window, tol=plateau_tol)

        # 10) plots of KL/overlay (best-effort)
        if do_plots:
            plots_dir = level_dir / "agent_plots"
            plots_dir.mkdir(exist_ok=True)
            try:
                plot_cluster_size_hist(best["labels"], outpath=plots_dir / "cluster_sizes.png")
                plot_child_parent_overlay(agents, parents, best["labels"],
                                          outpath=plots_dir / "child_parent_overlay.png",
                                          max_examples=12)
                vals = compute_avg_crossscale_kl_q(agents, parents, best["labels"], eps=1e-6)
                plot_crossscale_kl_hist(vals, outpath=plots_dir / "crossscale_kl_q_hist.png")
            except Exception as e:
                print(f"[PLOTS] Skipped agent plots: {e}")

        # 11) record level summary
        level_summary = {
            "level": L,
            "in_ckpt": ckpt,
            "out_ckpt": (f"{base_ckpt}_L{L+1}" if do_sim else None),
            "best_prefix": best["prefix"],
            "best_score": float(best["score"]),
            "plateau_mean": float(plateau_mean) if np.isfinite(plateau_mean) else None,
            "hit_plateau": bool(hit_plateau),
            # keep space for seed info if you re-enable procrustes later
            "seed_base_mean": None,
            "seed_after_mean": None,
            "seed_reverted": None,
            "seed_error": None,
        }
        manifest["levels"].append(level_summary)

        if save_artifacts:
            with open(out_root / "recursion_manifest.json", "w") as f:
                json.dump(manifest, f, indent=2)

        # 12) stopping rule
        if do_sim and hit_plateau:
            print(f"[STOP] Plateau at level {L+1} (Δ<{plateau_tol}).")
            break

    print("\n[✓] Meta-recursion complete.")
    return manifest


# ===== RUN THIS FILE DIRECTLY =====
if __name__ == "__main__":
    manifest = run_meta_recursion(
        levels=1,
        base_ckpt="checkpoints",
        out_root="meta_agent_analysis",

        # logging / analysis
        log_eps=1e-6,
        overlap_eps=1e-6,

        # plotting & saving
        do_plots=True,
        save_artifacts=True,

        # simulation
        do_sim=True,
        steps_per_level=None,   # or e.g. [150, 120, 120]
        plateau_window=15,
        plateau_tol=1e-4,
        skip_when_empty=True,

        # agreement-mask knobs
        tau_align=0.30,
        m_core=2,
        A_min=10,
        soft=True,
        smooth_iters=1,

        # support gating AFTER agreement
        support_mode="kofn",    # "none" | "all" | "kofn"
        k_support=None,         # None → auto majority ceil(0.5*C)
    )
    print("\n[DONE] Meta-recursion finished.")
    if manifest.get("levels"):
        print("[SUMMARY]", manifest["levels"][-1])
