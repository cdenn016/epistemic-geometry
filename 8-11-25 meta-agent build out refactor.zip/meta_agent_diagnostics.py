# -*- coding: utf-8 -*-
"""
Created on Sun Aug 10 21:26:55 2025

@author: chris and christine
"""

import numpy as np
import matplotlib.pyplot as plt
from pathlib import Path

from meta_agents import run_meta_recursion as meta_main




def load_parents_snapshot(path):
    import numpy as np
    d = np.load(path)
    return d["masks"], d["phi"], d["phi_model"]

# -------- Plot coarse-grained gauge vs parent masks --------
# -------- Plot coarse-grained gauge vs parent masks (from level checkpoint) --------
def plot_phi_mask_consistency(
    *,
    out_root="meta_agent_analysis",
    level_idx=None,            # None => last level from manifest
    field="phi",               # "phi" or "phi_model"
    mask_thr=0.3,              # contour threshold for mask
    support_quantile=0.80,     # threshold for φ support IoU (e.g., top 20% norm)
    max_parents=12,
    eps=1e-9
):
    import json, numpy as np
    from pathlib import Path
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    # 1) Read manifest and choose level
    out_root = Path(out_root)
    man_path = out_root / "recursion_manifest.json"
    if not man_path.exists():
        raise FileNotFoundError(f"Manifest not found: {man_path}")
    manifest = json.loads(man_path.read_text())
    if not manifest.get("levels"):
        raise RuntimeError("Manifest has no levels; run recursion first.")
    if level_idx is None:
        level_idx = len(manifest["levels"]) - 1
    level_info = manifest["levels"][level_idx]

    # 2) Load the level's agents from its checkpoint dir
    ckpt_dir = level_info.get("out_ckpt")
    if not ckpt_dir:
        raise RuntimeError(f"Level {level_idx} has no 'out_ckpt' in manifest; set do_sim=True or specify a level with checkpoints.")
    try:
        from meta_agent_utils import load_final_step
    except ImportError:
        from utils import load_final_step  # if your loader lives elsewhere
    parents = load_final_step(ckpt_dir)
    if parents is None or len(parents) == 0:
        raise RuntimeError(f"No agents found in checkpoint dir: {ckpt_dir}")

    H, W = parents[0].mask.shape
    out_dir = out_root / f"L{level_idx}" / "phi_mask_diagnostics"
    out_dir.mkdir(parents=True, exist_ok=True)

    def _safe_norm(phi):
        n = np.sqrt(np.maximum((phi**2).sum(axis=-1), 0.0))
        return n

    def _iou(a, b):
        u = (a | b).sum()
        return float((a & b).sum()) / (u if u else 1.0)

    metrics = []
    N = min(max_parents, len(parents))
    for pid in range(N):
        P = parents[pid]
        m = np.asarray(getattr(P, "mask", np.zeros((H, W), np.float32)))
        phi = np.asarray(getattr(P, field))        # (H,W,K)
        nrm = _safe_norm(phi)                      # (H,W)

        E_tot = float(nrm.sum() + eps)
        E_in  = float((nrm * (m > mask_thr)).sum())
        frac_in = E_in / E_tot

        thr_val = np.quantile(nrm, support_quantile)
        supp = (nrm >= max(thr_val, nrm.min()))
        iou_supp = _iou(supp, (m > mask_thr))

        metrics.append((pid, frac_in, iou_supp, E_tot))

        fig, ax = plt.subplots(1, 1, figsize=(4.6, 4.2))
        im = ax.imshow(nrm, origin="upper")
        ax.contour(m, levels=[mask_thr], colors="cyan", linewidths=1.0)
        ax.set_title(f"P{pid}  E_in/E={frac_in:.3f}  IoU={iou_supp:.3f}")
        ax.set_xticks([]); ax.set_yticks([])
        fig.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
        fig.tight_layout()
        fig.savefig(out_dir / f"parent_{pid:03d}_{field}_vs_mask.png", dpi=150)
        plt.close(fig)

    # Grid
    import math
    cols = min(4, max(1, N))
    rows = int(math.ceil(N / cols))
    fig, axes = plt.subplots(rows, cols, figsize=(4.6*cols, 4.2*rows), squeeze=False)
    axes = axes.ravel()
    for k in range(rows*cols):
        ax = axes[k]
        if k >= N:
            ax.axis("off"); continue
        P = parents[k]
        m = np.asarray(getattr(P, "mask", np.zeros((H, W), np.float32)))
        nrm = _safe_norm(np.asarray(getattr(P, field)))
        im = ax.imshow(nrm, origin="upper")
        ax.contour(m, levels=[mask_thr], colors="cyan", linewidths=1.0)
        mi = [t for t in metrics if t[0] == k][0]
        ax.set_title(f"P{k}  Ein/E={mi[1]:.2f} IoU={mi[2]:.2f}")
        ax.set_xticks([]); ax.set_yticks([])
    fig.tight_layout()
    fig.savefig(out_dir / f"grid_{field}_vs_mask.png", dpi=160)
    plt.close(fig)

    with open(out_dir / f"metrics_{field}.txt", "w") as f:
        for pid, frac_in, iou_supp, E_tot in metrics:
            f.write(f"P{pid:03d}  E_in/E={frac_in:.5f}  IoU_support={iou_supp:.5f}  E_tot={E_tot:.3f}\n")
    print(f"[DIAG] wrote → {out_dir}  ({N} parents)")

# ---------- Parent/Child init diagnostics (no CLI) ----------
def _try_load_meta(out_root, level_idx):
    """Load parents and labels from out_root/L{level_idx}."""
    import os, glob, pickle, numpy as np
    from pathlib import Path

    level_dir = Path(out_root) / f"L{level_idx}"
    fields_dir = level_dir / "meta_agent_fields"

    # Try helper loaders if you have them
    try:
        from meta_agent_utils import load_meta_agents, load_meta_labels
        parents = load_meta_agents(fields_dir)
        labels  = load_meta_labels(level_dir / "meta_labels.csv")
        return parents, labels
    except Exception:
        pass

    # Fallback: pickle/glob loader
    parents = []
    for pkl in sorted(glob.glob(str(fields_dir / "meta_agent_*.pkl"))):
        with open(pkl, "rb") as f:
            parents.append(pickle.load(f))
    # labels csv (single column or with header 'label')
    lab_path = level_dir / "meta_labels.csv"
    if lab_path.exists():
        import csv
        labels = []
        with open(lab_path, newline="") as f:
            rdr = csv.reader(f)
            # try skip header if it’s non-numeric
            first = next(rdr)
            try:
                _ = int(first[0]); labels.append(int(first[0]))
            except Exception:
                pass  # header
            for row in rdr:
                if row: labels.append(int(row[0]))
        labels = np.array(labels, dtype=int)
    else:
        labels = None
    return parents, labels


def run_parent_init_diagnostics(
    *,
    base_ckpt="checkpoints",
    out_root="meta_agent_analysis",
    level_idx=None,       # None => use last level in manifest
    field_key="mu_q_field",
    thr=0.3
):
    """
    Creates quick sanity plots + numbers:
      - parent mask vs union of children masks (overlay)
      - IoU(parent, union), IoU(parent, intersection)
      - relative L2 error between parent μ and child-averaged μ (within parent mask)
    """
    import os, json, numpy as np
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from pathlib import Path

    # Load children from the checkpoint used at that level
    def _load_children(ckpt_dir):
        try:
            from meta_agent_utils import load_final_step
        except Exception:
            from utils import load_final_step  # if you keep it elsewhere
        return load_final_step(ckpt_dir)

    out_root = Path(out_root)
    man_path = out_root / "recursion_manifest.json"
    if not man_path.exists():
        raise FileNotFoundError(f"Manifest not found: {man_path}")

    manifest = json.loads(man_path.read_text())
    if not manifest.get("levels"):
        raise RuntimeError("Manifest has no levels; run recursion first.")

    if level_idx is None:
        level_idx = len(manifest["levels"]) - 1  # last level

    level_info = manifest["levels"][level_idx]
    in_ckpt  = level_info["in_ckpt"]  # children checkpoint for this level

    children = _load_children(in_ckpt)
    if children is None or len(children) == 0:
        raise RuntimeError(f"No children found in {in_ckpt}")

    parents, labels = _try_load_meta(out_root, level_idx)
    if parents is None or len(parents) == 0:
        raise RuntimeError(f"No parents found in {out_root}/L{level_idx}/meta_agent_fields")

    H, W = children[0].mask.shape
    diag_dir = out_root / f"L{level_idx}" / "parent_init_diagnostics"
    diag_dir.mkdir(parents=True, exist_ok=True)

    def _iou(a, b):
        u = (a | b).sum()
        return float((a & b).sum()) / (u if u else 1.0)

    # Go over parents
    for pid, P in enumerate(parents):
        kid_ids = list(getattr(P, "child_ids", []))
        if not kid_ids:
            continue

        # Boolean masks
        kid_stack = np.stack([(children[cid].mask > 1e-6) for cid in kid_ids], axis=0)  # (C,H,W)
        union_b = kid_stack.any(axis=0)
        inter_b = kid_stack.all(axis=0)
        parent_b = (getattr(P, "mask", np.zeros((H,W), np.float32)) > thr)

        # IoU numbers
        iou_union = _iou(parent_b, union_b)
        iou_inter = _iou(parent_b, inter_b)

        # Child-averaged μ inside parent mask (weights = child masks * parent mask)
        if hasattr(P, field_key):
            parent_mu = getattr(P, field_key)   # (H,W,D)
            D = parent_mu.shape[-1]
            wsum = np.zeros((H,W,1), dtype=np.float32)
            mu_sum = np.zeros((H,W,D), dtype=np.float32)
            for cid in kid_ids:
                w = (children[cid].mask * parent_b.astype(np.float32))[..., None]  # (H,W,1)
                mu_c = getattr(children[cid], field_key)
                mu_sum += w * mu_c
                wsum  += w
            wsum = np.clip(wsum, 1e-8, None)
            mu_bar = mu_sum / wsum

            # Relative L2 error over parent support
            supp = parent_b
            if supp.any():
                diff = parent_mu[supp] - mu_bar[supp]
                num = np.sqrt((diff**2).sum())
                den = max(1e-8, np.sqrt((mu_bar[supp]**2).sum()))
                rel_err = float(num / den)
            else:
                rel_err = float("nan")
        else:
            rel_err = float("nan")

        # Plot
        fig, axes = plt.subplots(1, 3, figsize=(12, 4))
        # 1) Overlay: parent (cyan contour) on union of kids (red)
        axes[0].imshow(union_b, cmap="Reds", vmin=0, vmax=1)
        axes[0].contour(parent_b, levels=[0.5], colors="cyan", linewidths=1)
        axes[0].set_title(f"P{pid} mask (cyan) over children union")
        axes[0].set_xticks([]); axes[0].set_yticks([])

        # 2) IoU numbers
        axes[1].axis("off")
        axes[1].text(0.05, 0.7, f"IoU(parent, union) = {iou_union:.3f}", fontsize=11)
        axes[1].text(0.05, 0.5, f"IoU(parent, inter) = {iou_inter:.3f}", fontsize=11)
        axes[1].text(0.05, 0.3, f"Rel L2({field_key}) = {rel_err:.3e}", fontsize=11)
        axes[1].set_title("Numbers")

        # 3) Quick look at parent μ channel-0 (masked)
        if hasattr(P, field_key):
            im = axes[2].imshow(getattr(P, field_key)[..., 0] * parent_b, cmap="coolwarm")
            axes[2].set_title(f"{field_key}[...,0] × mask")
            fig.colorbar(im, ax=axes[2], fraction=0.046, pad=0.04)
        else:
            axes[2].axis("off")
            axes[2].set_title(f"{field_key} missing")

        fig.suptitle(f"Parent {pid} — kids={kid_ids}")
        fig.tight_layout()
        fig.savefig(diag_dir / f"parent_{pid:03d}_init.png", dpi=150)
        plt.close(fig)

    print(f"[DIAG] Wrote → {diag_dir}")

def plot_phi_mask_from_snapshot(snapshot_path, field="phi", mask_thr=0.3,
                                support_quantile=0.80, max_parents=12):
    import numpy as np, matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    import os

    masks, phi, phi_model = load_parents_snapshot(snapshot_path)
    F = phi if field == "phi" else phi_model
    N, H, W, K = F.shape

    def _norm(x): return np.sqrt(np.maximum((x**2).sum(axis=-1), 0.0))
    def _iou(a, b):
        u = (a | b).sum()
        return float((a & b).sum()) / (u if u else 1.0)

    out_dir = os.path.join(os.path.dirname(snapshot_path), "phi_mask_diagnostics")
    os.makedirs(out_dir, exist_ok=True)

    n_show = min(max_parents, N)
    cols = min(4, max(1, n_show))
    rows = int(np.ceil(n_show / cols))
    fig, axes = plt.subplots(rows, cols, figsize=(4.6*cols, 4.2*rows), squeeze=False)
    axes = axes.ravel()

    for i in range(rows*cols):
        ax = axes[i]
        if i >= n_show:
            ax.axis("off"); continue
        m = masks[i] > mask_thr
        n = _norm(F[i])
        Ein = float((n*m).sum()); Etot = float(n.sum() + 1e-9)
        frac = Ein / Etot

        thr = np.quantile(n, support_quantile)
        supp = (n >= thr)
        iou = _iou(supp, m)

        im = ax.imshow(n, origin="upper")
        ax.contour(m, levels=[0.5], colors="cyan", linewidths=1.0)
        ax.set_title(f"P{i}  Ein/E={frac:.2f} IoU={iou:.2f}")
        ax.set_xticks([]); ax.set_yticks([])
    fig.tight_layout()
    fig.savefig(os.path.join(out_dir, f"grid_{field}_vs_mask.png"), dpi=160)
    plt.close(fig)
    print(f"[DIAG] wrote → {out_dir}")




if __name__ == "__main__":
    # assuming you already ran run_meta_recursion() earlier in the same file
    plot_phi_mask_consistency(
        out_root="meta_agent_analysis",
        level_idx=None,      # auto last level
        field="phi",         # try "phi_model" too
        mask_thr=0.3,
        support_quantile=0.80,
        max_parents=12
    )
