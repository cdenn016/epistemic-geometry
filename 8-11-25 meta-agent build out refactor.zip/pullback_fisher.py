import numpy as np
from typing import Dict, Tuple, Optional

# Optional omega import (for curvature helpers if present)
try:
    import omega as _omega
except Exception:
    _omega = None

# ---------- Linear algebra utilities ----------

def _symmetrize(M):
    return 0.5 * (M + np.swapaxes(M, -1, -2))

def sanitize_sigma_and_inv(S: np.ndarray, eps: float = 1e-6) -> Tuple[np.ndarray, np.ndarray]:
    """
    Symmetrize Σ, clip eigenvalues, and return (Σ_sanitized, Σ_inv).
    Shapes:
        S: (..., K, K)
    """
    S = _symmetrize(S)
    *batch, K, _ = S.shape
    R = np.prod(batch, dtype=int) if batch else 1
    S2 = S.reshape((R, K, K))
    S_sane = np.empty_like(S2)
    S_inv  = np.empty_like(S2)
    for i in range(R):
        Si = S2[i]
        w, V = np.linalg.eigh(Si)
        w = np.clip(w, eps, None)
        Si_s = (V * w) @ V.T
        Si_i = (V * (1.0 / w)) @ V.T
        S_sane[i] = _symmetrize(Si_s)
        S_inv[i]  = _symmetrize(Si_i)
    return S_sane.reshape((*batch, K, K)), S_inv.reshape((*batch, K, K))

# ---------- Finite differences (periodic by default) ----------

def grad2(field: np.ndarray, periodic: bool = True) -> np.ndarray:
    """
    Central differences with unit spacing on a 2D grid.
    Returns ∇field with shape (..., 2), where [..., 0]=∂/∂y (rows), [...,1]=∂/∂x (cols).
    """
    if field.ndim < 2:
        raise ValueError("field must have at least 2 dims (H, W, ...)")
    def diff_axis(arr, axis, periodic):
        if periodic:
            plus  = np.roll(arr, -1, axis=axis)
            minus = np.roll(arr,  1, axis=axis)
        else:
            idx = np.arange(arr.shape[axis])
            plus  = np.take(arr, np.clip(idx+1, 0, arr.shape[axis]-1), axis=axis)
            minus = np.take(arr, np.clip(idx-1, 0, arr.shape[axis]-1), axis=axis)
        return 0.5 * (plus - minus)
    dy = diff_axis(field, 0, periodic)
    dx = diff_axis(field, 1, periodic)
    return np.stack([dy, dx], axis=-1)   # last axis = (∂y, ∂x)

# ==========================================================
#              Pullback Fisher (MVG; (μ, Σ))
# ==========================================================

def fisher_pullback_mu_sigma(mu: np.ndarray,
                             Sigma: np.ndarray,
                             mask: Optional[np.ndarray] = None,
                             periodic: bool = True,
                             eps: float = 1e-6) -> Dict[str, np.ndarray]:
    """
    G_{αβ} = (∂_α μ)^T Σ^{-1} (∂_β μ) + 1/2 Tr[ Σ^{-1} (∂_α Σ) Σ^{-1} (∂_β Σ) ]
    α,β ∈ {y,x} = {0,1}
    """
    H, W, K = mu.shape
    if Sigma.shape != (H, W, K, K):
        raise ValueError("Sigma shape must be (H, W, K, K)")

    Sigma_sane, Sigma_inv = sanitize_sigma_and_inv(Sigma, eps=eps)
    dmu    = grad2(mu, periodic=periodic)            # (H,W,K,2)
    dSigma = grad2(Sigma_sane, periodic=periodic)    # (H,W,K,K,2)

    G = np.zeros((H, W, 2, 2), dtype=mu.dtype)

    # μ-term
    for a in range(2):
        v_a = np.einsum("...ij,...j->...i", Sigma_inv, dmu[..., a])
        for b in range(2):
            G[..., a, b] += np.einsum("...i,...i->...", dmu[..., b], v_a)

    # Σ-term
    for a in range(2):
        M_a = np.einsum("...ik,...kj->...ij", Sigma_inv, dSigma[..., a])
        for b in range(2):
            M_b = np.einsum("...ik,...kj->...ij", Sigma_inv, dSigma[..., b])
            G[..., a, b] += 0.5 * np.einsum("...ij,...ji->...", M_a, M_b)

    G = 0.5 * (G + np.swapaxes(G, -1, -2))

    # Eigen stuff per-pixel
    G_rs = G.reshape(-1, 2, 2)
    lmax = np.empty(G_rs.shape[0], dtype=mu.dtype)
    lmin = np.empty(G_rs.shape[0], dtype=mu.dtype)
    eigvecs = np.empty_like(G_rs)
    for i in range(G_rs.shape[0]):
        Gi = 0.5*(G_rs[i] + G_rs[i].T)
        w, V = np.linalg.eigh(Gi)
        idx = np.argsort(w)[::-1]
        w, V = w[idx], V[:, idx]
        lmax[i], lmin[i] = w[0], w[-1]
        eigvecs[i] = V
    lmax   = lmax.reshape(H, W)
    lmin   = lmin.reshape(H, W)
    eigvecs= eigvecs.reshape(H, W, 2, 2)

    tr  = G[..., 0, 0] + G[..., 1, 1]
    det = G[..., 0, 0]*G[..., 1, 1] - G[..., 0, 1]*G[..., 1, 0]
    aniso = (lmax - lmin) / (lmax + 1e-12)

    if mask is not None:
        m = (mask > 0)
        nan = np.nan
        for a in range(2):
            for b in range(2):
                G[..., a, b] = np.where(m, G[..., a, b], nan)
        tr   = np.where(m, tr,   nan)
        det  = np.where(m, det,  nan)
        lmax = np.where(m, lmax, nan)
        lmin = np.where(m, lmin, nan)
        aniso= np.where(m, aniso,nan)
        for c in range(2):
            for d in range(2):
                eigvecs[..., c, d] = np.where(m, eigvecs[..., c, d], nan)

    return dict(G=G, tr=tr, det=det, lmax=lmax, lmin=lmin, aniso=aniso, eigvecs=eigvecs)

# ---------- Agent helpers ----------

def compute_agent_fisher_pullback(agent,
                                  mode: str = "belief",
                                  periodic: bool = True,
                                  eps: float = 1e-6) -> Dict[str, np.ndarray]:
    """
    mode ∈ {"belief", "model"}
    Uses fields:
        belief: μ_q_field, Σ_q_field, mask
        model : μ_p_field, Σ_p_field, mask
    """
    if mode == "belief":
        mu = agent.mu_q_field
        S  = agent.sigma_q_field
    elif mode == "model":
        mu = agent.mu_p_field
        S  = agent.sigma_p_field
    else:
        raise ValueError("mode must be 'belief' or 'model'")
    return fisher_pullback_mu_sigma(mu, S, getattr(agent, "mask", None), periodic=periodic, eps=eps)

def summarize_scalar_fields(pb: Dict[str, np.ndarray]) -> Dict[str, float]:
    out = {}
    for k in ["tr", "det", "lmax", "lmin", "aniso"]:
        arr = pb[k]
        finite = np.isfinite(arr)
        if finite.any():
            out[f"{k}_mean"] = float(arr[finite].mean())
            out[f"{k}_max"]  = float(arr[finite].max())
            out[f"{k}_min"]  = float(arr[finite].min())
        else:
            out[f"{k}_mean"] = float("nan")
            out[f"{k}_max"]  = float("nan")
            out[f"{k}_min"]  = float("nan")
    return out

# ==========================================================
#                  Base Riemannian geometry
# ==========================================================

def base_metric_derivatives(G: np.ndarray, periodic: bool = True) -> np.ndarray:
    """dG[a,b,α] = ∂_α G_{ab}.  Shapes: G:(H,W,2,2) -> dG:(H,W,2,2,2)"""
    return grad2(G, periodic=periodic)

def christoffel_2d(G: np.ndarray, dG: Optional[np.ndarray] = None, periodic: bool = True) -> np.ndarray:
    """Christoffel symbols Γ^γ_{αβ} on the 2D base. Returns (H,W,2,2,2)."""
    if dG is None:
        dG = base_metric_derivatives(G, periodic=periodic)
    H, W = G.shape[:2]
    Ginv = np.linalg.inv(G.reshape(-1,2,2)).reshape(H,W,2,2)
    Gamma = np.zeros((H,W,2,2,2), dtype=G.dtype)
    # Γ^γ_{αβ} = 1/2 G^{γδ} (∂_α G_{βδ} + ∂_β G_{αδ} - ∂_δ G_{αβ})
    for g in range(2):
        for a in range(2):
            for b in range(2):
                term = np.zeros((H,W), dtype=G.dtype)
                for d in range(2):
                    term += Ginv[..., g, d] * ( dG[..., b, d, a] + dG[..., a, d, b] - dG[..., a, b, d] )
                Gamma[..., g, a, b] = 0.5 * term
    return Gamma

def riemann_scalar_K_2d(G: np.ndarray, Gamma: Optional[np.ndarray] = None,
                        periodic: bool = True) -> np.ndarray:
    """Gaussian curvature K on 2D base: K = R_{0101}/det(G) with (0,1)=(y,x)."""
    if Gamma is None:
        Gamma = christoffel_2d(G, periodic=periodic)
    dGamma = grad2(Gamma, periodic=periodic)  # (..., γ, α, β, μ) last μ is ∂_μ
    H, W = G.shape[:2]
    detG = G[...,0,0]*G[...,1,1] - G[...,0,1]*G[...,1,0]
    # R^ρ_{σμν}
    R_up = np.zeros((H,W,2,2,2,2), dtype=G.dtype)
    for rho in range(2):
        for sig in range(2):
            for mu in range(2):
                for nu in range(2):
                    R_up[..., rho, sig, mu, nu] = dGamma[..., rho, nu, sig, mu] - dGamma[..., rho, mu, sig, nu]
                    for lam in range(2):
                        R_up[..., rho, sig, mu, nu] += (
                            Gamma[..., rho, mu, lam] * Gamma[..., lam, nu, sig]
                            - Gamma[..., rho, nu, lam] * Gamma[..., lam, mu, sig]
                        )
    # Lower first index
    R_low = np.zeros((H,W,2,2,2,2), dtype=G.dtype)
    for a in range(2):
        for b in range(2):
            for g in range(2):
                for d in range(2):
                    for rho in range(2):
                        R_low[..., a,b,g,d] += G[..., a, rho] * R_up[..., rho, b, g, d]
    K = R_low[..., 0,1,0,1] / (detG + 1e-12)
    return K

# ==========================================================
#        Principal-field geometry (divergence / curl)
# ==========================================================

def principal_vector(pb: Dict[str,np.ndarray]) -> np.ndarray:
    """Eigenvector (H,W,2) corresponding to λ_max from a pullback dict."""
    return pb["eigvecs"][..., :, 0]

def div_curl_of_principal(pb: Dict[str,np.ndarray], periodic: bool = True) -> Dict[str,np.ndarray]:
    """Divergence and 2D scalar curl of the λ_max eigenvector field."""
    v = principal_vector(pb)                 # (H,W,2)
    dv = grad2(v, periodic=periodic)         # (H,W,2,2) [component, deriv]
    div  = dv[..., 0, 0] + dv[..., 1, 1]
    curl = dv[..., 1, 0] - dv[..., 0, 1]     # ∂y v_x - ∂x v_y
    return dict(div=div, curl=curl, v=v)

# ==========================================================
#     Belief vs Model alignment diagnostics
# ==========================================================

def geom_gap_metrics(pb_belief: Dict[str,np.ndarray],
                     pb_model:  Dict[str,np.ndarray]) -> Dict[str,np.ndarray]:
    """
    Pixelwise diagnostics comparing belief vs model pullbacks:
      - Δtr, Δsqrt_det
      - log-ratio of λmax, λmin
      - eigenvector cosine between principal directions
    """
    q, p = pb_belief, pb_model
    vq = principal_vector(q); vp = principal_vector(p)
    num = vq[...,0]*vp[...,0] + vq[...,1]*vp[...,1]
    den = (np.linalg.norm(vq, axis=-1) * np.linalg.norm(vp, axis=-1) + 1e-12)
    cos = num / den
    return dict(
        delta_tr = q["tr"] - p["tr"],
        delta_sqrt_det = np.sqrt(np.maximum(q["det"],0)) - np.sqrt(np.maximum(p["det"],0)),
        log_lambda_max_ratio = np.log((q["lmax"] + 1e-12) / (p["lmax"] + 1e-12)),
        log_lambda_min_ratio = np.log((q["lmin"] + 1e-12) / (p["lmin"] + 1e-12)),
        cos_principal = cos
    )

# ==========================================================
#     Approximate Killing direction (local LS)
# ==========================================================

def approximate_killing_direction(Gamma: np.ndarray) -> np.ndarray:
    """
    Local least-squares 'approximate Killing' direction field V(y,x)∈R^2.

    Constant-field ansatz in a small neighborhood:
      S_{αβ}(X) = ∇_α X_β + ∇_β X_α ≈ - (Γ^γ_{αβ} + Γ^γ_{βα}) X_γ
    We build a 3×2 linear map A: X → [S_00, S_11, S_01+S_10] and
    take the right singular vector with the smallest singular value.
    Returns V of shape (H,W,2), unit-norm where possible.
    """
    H,W = Gamma.shape[:2]
    V = np.zeros((H,W,2), dtype=Gamma.dtype)
    for i in range(H):
        for j in range(W):
            C = np.zeros((2,2,2), dtype=Gamma.dtype)
            for a in range(2):
                for b in range(2):
                    for g in range(2):
                        C[g,a,b] = Gamma[i,j,g,a,b] + Gamma[i,j,g,b,a]
            A = np.array([
                [-C[0,0,0], -C[1,0,0]],                       # S_00
                [-C[0,1,1], -C[1,1,1]],                       # S_11
                [-(C[0,0,1]+C[0,1,0]), -(C[1,0,1]+C[1,1,0])]  # S_01+S_10
            ], dtype=Gamma.dtype)
            try:
                u, s, vh = np.linalg.svd(A, full_matrices=False)
                x = vh[-1]
            except np.linalg.LinAlgError:
                x = np.array([1.0, 0.0], dtype=Gamma.dtype)
            n = np.linalg.norm(x) + 1e-12
            V[i,j] = x / n
    return V

# ==========================================================
#     Lie derivative of G along a vector field
# ==========================================================

def lie_derivative_norm(G: np.ndarray, Gamma: np.ndarray, V: np.ndarray,
                        periodic: bool = True) -> np.ndarray:
    """
    ||L_V G||_F per pixel using covariant symmetric gradient:
      (L_V G)_{ab} = ∇_a V_b + ∇_b V_a,  with V_b = G_{bμ} V^μ
      ∇_a V_b = ∂_a V_b - Γ^μ_{ab} V_μ
    Returns: Frobenius norm (H,W)
    """
    H,W = G.shape[:2]
    # Lower index: V_b = G_{bμ} V^μ
    Vb = np.zeros((H,W,2), dtype=G.dtype)
    for b in range(2):
        for mu in range(2):
            Vb[..., b] += G[..., b, mu] * V[..., mu]
    dVb = grad2(Vb, periodic=periodic)  # (H,W,2,2): comp b, deriv a
    L = np.zeros((H,W,2,2), dtype=G.dtype)
    for a in range(2):
        for b in range(2):
            term = dVb[..., b, a]
            # - Γ^μ_{ab} V_μ   (lowered μ index)
            corr = np.zeros((H,W), dtype=G.dtype)
            for mu in range(2):
                # V_μ = Vb[..., μ]
                corr += Gamma[..., mu, a, b] * Vb[..., mu]
            L[..., a, b] = term - corr
    # symmetrize L_ab + L_ba
    L = L + np.swapaxes(L, -1, -2)
    # Frobenius norm
    return np.sqrt(np.maximum(0.0, np.sum(L*L, axis=(-1,-2))))

# ==========================================================
#           Gauge curvature F_yx from phi / omega.py
# ==========================================================

def _try_get_generators(agent):
    for attr in ["generators", "G", "so3_generators", "irrep_generators"]:
        if hasattr(agent, attr):
            return getattr(agent, attr)
    return None  # must be provided explicitly then

def gauge_curvature_from_phi(phi: np.ndarray,
                             generators: Optional[np.ndarray] = None,
                             periodic: bool = True) -> Tuple[np.ndarray, np.ndarray]:
    """
    Compute F_{yx} from a φ field and SO(3) generators G_a:
        A_y = ∂_y φ^a G_a,  A_x = ∂_x φ^a G_a
        F_{yx} = ∂_y A_x - ∂_x A_y + [A_y, A_x]
    Returns (F, ||F||_F) with shapes (H,W,K,K) and (H,W).
    If omega.py exposes a more exact curvature, we prefer that.
    """
    # If omega module exposes a curvature helper, try it first
    if _omega is not None:
        for name in ["curvature_from_phi", "compute_curvature", "gauge_curvature_from_phi"]:
            if hasattr(_omega, name):
                try:
                    F = getattr(_omega, name)(phi, generators, periodic=periodic)
                    Fn = np.linalg.norm(F.reshape(*F.shape[:2], -1), axis=-1)
                    return F, Fn
                except Exception:
                    pass

    # Fallback: direct construction from φ and generators
    if phi.ndim != 3 or phi.shape[-1] != 3:
        raise ValueError("phi must be (H,W,3) SO(3) Lie coords.")
    if generators is None:
        raise ValueError("generators must be provided (3,K,K) when omega helper is unavailable.")

    dphi = grad2(phi, periodic=periodic)  # (H,W,3,2)
    Ay = np.einsum("...a,akl->...kl", dphi[..., 0], generators)  # ∂y φ^a G_a
    Ax = np.einsum("...a,akl->...kl", dphi[..., 1], generators)  # ∂x φ^a G_a

    dAy = grad2(Ay, periodic=periodic)  # (H,W,K,K,2)
    dAx = grad2(Ax, periodic=periodic)  # (H,W,K,K,2)
    comm = np.einsum("...ik,...kj->...ij", Ay, Ax) - np.einsum("...ik,...kj->...ij", Ax, Ay)
    F = dAx[..., 0] - dAy[..., 1] + comm     # ∂y A_x - ∂x A_y + [A_y, A_x]
    Fn = np.linalg.norm(F.reshape(F.shape[0], F.shape[1], -1), axis=-1)
    return F, Fn

def compute_agent_gauge_curvature(agent,
                                  generators: Optional[np.ndarray] = None,
                                  periodic: bool = True) -> Dict[str,np.ndarray]:
    """Convenience wrapper to compute gauge curvature from agent.phi."""
    if not hasattr(agent, "phi"):
        raise AttributeError("agent.phi not found.")
    if generators is None:
        generators = _try_get_generators(agent)
    F, Fn = gauge_curvature_from_phi(agent.phi, generators, periodic=periodic)
    return dict(F=F, F_norm=Fn)

# ==========================================================
#                Convenience / Reports
# ==========================================================

def compute_Gamma_and_K(pb: Dict[str,np.ndarray], periodic: bool = True) -> Dict[str,np.ndarray]:
    """From a pullback dict with G, return Γ and scalar curvature K."""
    G = pb["G"]
    dG = base_metric_derivatives(G, periodic=periodic)
    Gamma = christoffel_2d(G, dG=dG, periodic=periodic)
    K = riemann_scalar_K_2d(G, Gamma=Gamma, periodic=periodic)
    return dict(Gamma=Gamma, K=K)

def full_geometric_report(pb_belief: Dict[str,np.ndarray],
                          pb_model: Optional[Dict[str,np.ndarray]] = None,
                          periodic: bool = True) -> Dict[str,np.ndarray]:
    """
    Bundle of geometric diagnostics from one (and optionally two) pullbacks.
    Includes:
      - Gamma, K
      - principal field v, div, curl
      - belief/model geometry gap (if pb_model provided)
      - approximate local Killing direction (from Gamma)
      - ||L_V G|| for the Killing guess
    """
    out = {}
    # Base curvature & connection (belief by default)
    rep = compute_Gamma_and_K(pb_belief, periodic=periodic)
    out.update(rep)
    # Principal field analysis (belief)
    pc = div_curl_of_principal(pb_belief, periodic=periodic)
    out.update(pc)
    # Belief-vs-model gap if provided
    if pb_model is not None:
        out.update(geom_gap_metrics(pb_belief, pb_model))
    # Approx Killing direction & Lie derivative norm
    Vkill = approximate_killing_direction(out["Gamma"])
    out["killing_dir"] = Vkill
    out["lie_norm_killing"] = lie_derivative_norm(pb_belief["G"], out["Gamma"], Vkill, periodic=periodic)
    return out

# ==========================================================
#                     No-arg runner (Spyder)
# ==========================================================

if __name__ == "__main__":
    import os, pickle, glob
    import numpy as np
    import pandas as pd

    # ==== CONFIG ====
    STEPS_DIR = "checkpoints"   # folder with step_*.pkl
    OUTDIR    = "pullbacks"     # NPZs + summary CSV
    PERIODIC  = True
    EPS       = 1e-6
    MODES     = ["belief", "model"]
    # ===============

    os.makedirs(OUTDIR, exist_ok=True)
    all_summaries = []

    step_files = sorted(glob.glob(os.path.join(STEPS_DIR, "step_*.pkl")))
    if not step_files:
        raise FileNotFoundError(f"No step_*.pkl files found in {STEPS_DIR}")

    for step_path in step_files:
        step_name = os.path.splitext(os.path.basename(step_path))[0]
        print(f"[INFO] Processing {step_name} ...")
        with open(step_path, "rb") as f:
            step_data = pickle.load(f)

        if isinstance(step_data, dict) and "agents" in step_data:
            agents = step_data["agents"]
        elif isinstance(step_data, list):
            agents = step_data
        elif hasattr(step_data, "agents"):
            agents = step_data.agents
        else:
            raise RuntimeError(f"Could not locate agents in {step_path}")

        for idx, agent in enumerate(agents):
            for mode in MODES:
                try:
                    pb = compute_agent_fisher_pullback(agent, mode=mode,
                                                       periodic=PERIODIC, eps=EPS)
                    # save core pullback
                    tag = f"{step_name}_agent{idx}_{mode}"
                    npz_path = os.path.join(OUTDIR, f"{tag}.npz")
                    np.savez_compressed(npz_path, **pb)

                    # geometry report (Γ, K, principal div/curl, killing dir, ||L_V G||)
                    geom = full_geometric_report(pb, periodic=PERIODIC)
                    np.savez_compressed(os.path.join(OUTDIR, f"{tag}_geom.npz"), **geom)

                    # gauge curvature (if possible) — belief mode usually relevant
                    if hasattr(agent, "phi"):
                        try:
                            gc = compute_agent_gauge_curvature(agent, periodic=PERIODIC)
                            np.savez_compressed(os.path.join(OUTDIR, f"{tag}_gauge.npz"), **gc)
                        except Exception as e:
                            # Non-fatal; continue
                            pass

                    s = summarize_scalar_fields(pb)
                    s.update(dict(step=step_name, agent_index=idx, mode=mode))
                    all_summaries.append(s)
                except Exception as e:
                    all_summaries.append(dict(step=step_name, agent_index=idx, mode=mode, error=str(e)))

    pd.DataFrame(all_summaries).to_csv(os.path.join(OUTDIR, "fisher_pullback_summary.csv"), index=False)
    print(f"[INFO] Wrote {len(all_summaries)} rows → {os.path.join(OUTDIR, 'fisher_pullback_summary.csv')}")
