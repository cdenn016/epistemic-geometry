import numpy as np

from pathlib import Path
import json

# --- Project-specific imports ---
import config
from config import K_q, K_p, group_name

from omega import (
    
    compute_inter_omega,
   
   )
from numerical_utils import sanitize_sigma
#from generalized_diagnostics_metrics import kl_divergence
from agent_initialization import attach_crossscale_fields
# meta_agent_utils.py

from get_generators import get_generators

from gaussian_core import kl_gaussians, gaussian_pushforward_linear



def compute_pairwise_agreement_maps(children, tau=0.10, eps=1e-6, tcap=10.0,
                                    field="q", generators=None):
    """
    Build per-pair, per-pixel soft agreement maps among overlapping agents.

    `field`: "q" (belief) uses agents' 'phi'; "p" (model) uses 'phi_model'.
    `generators`: pass the irrep generators to use (e.g., Gq or Gp).
    """
    import numpy as _np

    H, W = children[0].mask.shape
    pairs, A, joint = [], {}, {}

    def _get_mu(c): return getattr(c, f"mu_{field}_field")
    def _get_S(c): return sanitize_sigma(getattr(c, f"sigma_{field}_field"), eps=eps)
    phi_field = "phi" if field == "q" else "phi_model"

    N = len(children)
    for i in range(N):
        ci = children[i]; mi = (ci.mask > eps)
        if not mi.any(): continue
        for j in range(i + 1, N):
            cj = children[j]; mj = (cj.mask > eps)
            J = (mi & mj)
            if not J.any(): continue

            ys, xs = _np.nonzero(J)
            y = int(_np.median(ys)); x = int(_np.median(xs))

            # Ω_ij at a representative overlap pixel; broadcast across (H,W)
            Ω = compute_inter_omega(ci, cj, (y, x), field=phi_field, generators=generators)  # (K,K)
            K = Ω.shape[0]
            Omega_ij = _np.broadcast_to(Ω, (H, W, K, K))
            Omega_ji = _np.swapaxes(Omega_ij, -1, -2)

            mu_i, S_i = _get_mu(ci), _get_S(ci)
            mu_j, S_j = _get_mu(cj), _get_S(cj)

            mu_j_t, S_j_t = gaussian_pushforward_linear(mu_j, S_j, Omega_ij)
            mu_i_t, S_i_t = gaussian_pushforward_linear(mu_i, S_i, Omega_ji)

            s_ij = kl_gaussians(mu_i, S_i, mu_j_t, S_j_t, eps=eps)
            s_ji = kl_gaussians(mu_j, S_j, mu_i_t, S_i_t, eps=eps)
            s_sym = 0.5 * (s_ij + s_ji)

            a = _np.zeros((H, W), dtype=_np.float32)
            s_cap = _np.minimum(s_sym[J], tcap)
            a[J] = _np.exp(-s_cap / float(tau))

            key = (i, j)
            pairs.append(key)
            A[key] = a
            joint[key] = J

    return pairs, A, joint



def build_parent_mask_from_group(children,
                                 child_ids,
                                 A_maps,          # from compute_pairwise_agreement_maps
                                 joint_maps,      # from compute_pairwise_agreement_maps
                                 tau=0.2,
                                 m_core=3,
                                 A_min=200,
                                 soft=True,
                                 smooth_iters=0):
    """
    STRICT agreement mask (no union, no averaging of child masks).
    A pixel is IN only if at least m_core children mutually agree there
    (each has >= m_core-1 agreeing neighbors at that pixel).
    Soft value = mean agreement over agreeing pairs at that pixel.
    Returns (H,W) float32 in [0,1].
    """
    import numpy as np

    if len(child_ids) == 0:
        return None

    H, W = children[child_ids[0]].mask.shape
    Cg   = len(child_ids)

    # Pairwise "agree" mats and degrees
    A_sum = np.zeros((H, W), dtype=np.float32)   # sum of A over agreeing pairs
    pairN = np.zeros((H, W), dtype=np.int32)     # number of agreeing pairs
    deg   = np.zeros((Cg, H, W), dtype=np.int16) # per-child degree

    # agreement threshold: A = exp(-KL/tau); choose KL<tau → A>=e^-1
    a_thresh = np.exp(-1.0)

    # Build agreement graph per pixel (implicit via deg + counts)
    for a in range(Cg):
        ia = child_ids[a]
        for b in range(a + 1, Cg):
            ib = child_ids[b]
            key = (ia, ib) if ia < ib else (ib, ia)
            if key not in A_maps:
                continue
            A_ij = A_maps[key]       # (H,W) in [0,1]
            J    = joint_maps[key]   # (H,W) bool where both masks>0
            agree = (A_ij >= a_thresh) & J

            if not agree.any():
                continue

            A_add = np.zeros_like(A_ij, dtype=np.float32)
            A_add[agree] = A_ij[agree]
            A_sum += A_add
            pairN += agree.astype(np.int32)
            deg[a][agree] += 1
            deg[b][agree] += 1

    # If no agreeing pairs anywhere → empty mask (NO union fallback)
    if pairN.sum() == 0:
        return np.zeros((H, W), dtype=np.float32)

    # Core condition: at least m_core children each with ≥(m_core-1) agreeing neighbors
    core_children = (deg >= (m_core - 1))          # (Cg,H,W)
    core_count    = core_children.sum(axis=0)      # (H,W)
    in_core       = (core_count >= m_core)         # (H,W) bool

    # Soft value = mean of A over agreeing pairs, gated by in_core
    A_mean = np.zeros((H, W), dtype=np.float32)
    nz = pairN > 0
    A_mean[nz] = A_sum[nz] / pairN[nz]

    soft_mask = np.where(in_core, A_mean, 0.0).astype(np.float32)

    # optional smoothing (small)
    if smooth_iters > 0:
        k = np.array([[1,1,1],[1,2,1],[1,1,1]], dtype=np.float32); k /= k.sum()
        for _ in range(smooth_iters):
            pad = np.pad(soft_mask, 1, mode="edge")
            sm  = (
                k[0,0]*pad[:-2, :-2] + k[0,1]*pad[:-2,1:-1] + k[0,2]*pad[:-2,2:] +
                k[1,0]*pad[1:-1, :-2] + k[1,1]*pad[1:-1,1:-1] + k[1,2]*pad[1:-1,2:] +
                k[2,0]*pad[2:,  :-2] + k[2,1]*pad[2:, 1:-1] + k[2,2]*pad[2:,  2:]
            )
            soft_mask = np.clip(sm, 0.0, 1.0).astype(np.float32)

    # Area guard
    if soft_mask.sum() < A_min:
        return np.zeros((H, W), dtype=np.float32)

    return soft_mask if soft else (soft_mask > 0.5).astype(np.float32)
















def _labels_from_overlap_connected_components(agents, eps=1e-6, min_group_size=2):
    """
    Build labels from connected components of the overlap graph.
    Small components (< min_group_size) get their own labels too (so parents can still form),
    but you can change that to -1 to drop them if you want.
    """
    import numpy as np

    N = len(agents)
    # adjacency: edge if masks overlap by >0 pixels
    A = np.zeros((N, N), dtype=np.uint8)
    masks = [(a.mask > eps) for a in agents]
    for i in range(N):
        A[i, i] = 0
        mi = masks[i]
        if not mi.any(): 
            continue
        for j in range(i + 1, N):
            mj = masks[j]
            if mi.any() and mj.any() and np.logical_and(mi, mj).any():
                A[i, j] = A[j, i] = 1

    # BFS components (pure numpy, no SciPy)
    labels = -np.ones(N, dtype=int)
    comp_id = 0
    for s in range(N):
        if labels[s] != -1:
            continue
        # start new component at s
        stack = [s]
        comp = []
        labels[s] = comp_id
        while stack:
            v = stack.pop()
            comp.append(v)
            nbrs = np.nonzero(A[v])[0]
            for u in nbrs:
                if labels[u] == -1:
                    labels[u] = comp_id
                    stack.append(u)
        # If you want to drop tiny comps, set them to -1 here; else keep.
        # if len(comp) < min_group_size:
        #     for idx in comp: labels[idx] = -1
        comp_id += 1

    return labels







def _moment_aggregate_gaussians(children, labels, pid, field="p", eps=1e-6, ridge=1e-3):
    """
    Aggregates child Gaussians into a parent via masked, variance-aware moments:
      μ_parent = Σ w_i μ_i / Σ w_i
      Σ_parent = Σ w_i (Σ_i + (μ_i - μ_parent)(μ_i - μ_parent)^T) / Σ w_i
    """
    kids = [c for ci, c in enumerate(children) if int(labels[ci]) == pid]
    if not kids:
        return None, None

    H, W, K = getattr(kids[0], f"mu_{field}_field").shape
    w_sum = np.zeros((H, W, 1), dtype=np.float32)
    mu_acc = np.zeros((H, W, K), dtype=np.float32)

    # 1) mean
    for c in kids:
        w = c.mask[..., None].astype(np.float32)
        mu = getattr(c, f"mu_{field}_field").astype(np.float32)
        mu_acc += w * mu
        w_sum += w
    w_safe = np.maximum(w_sum, eps)
    mu_par = mu_acc / w_safe

    # 2) covariance
    S_acc = np.zeros((H, W, K, K), dtype=np.float32)
    for c in kids:
        w = c.mask[..., None, None].astype(np.float32)
        mu = getattr(c, f"mu_{field}_field").astype(np.float32)
        S  = sanitize_sigma(getattr(c, f"sigma_{field}_field"), eps=eps).astype(np.float32)
        d  = (mu - mu_par)[..., None]                 # (H,W,K,1)
        outer = np.matmul(d, np.swapaxes(d, -1, -2))  # (H,W,K,K)
        S_acc += w * (S + outer)
    S_par = S_acc / w_safe[..., None]

    # ridge for stability
    I = np.eye(K, dtype=np.float32)
    S_par = sanitize_sigma(S_par + ridge * I, eps=eps)
    return mu_par, S_par


def initialize_parents_from_children(
    parents, children, labels,
    *,
    # agreement mask toggles
    use_agreement_masks=True,
    tau_align=0.30,          # larger ⇒ easier agreement (A = exp(-KL/τ))
    m_core=2,                # children per-pixel that each have ≥(m_core-1) agreeing neighbors
    A_min=10,                # area guard (in pixels) for a parent
    soft=True,               # return soft mask; if False → binarize at 0.5
    smooth_iters=1,          # 0/1/2 blur passes on the soft mask

    # support gating toggles
    support_mode="kofn",     # "none" | "all" (strict intersection) | "kofn"
    k_support=None,          # if support_mode=="kofn": require ≥k children covering each pixel

    # which fiber to align in agreement KLs
    field="q",               # "q" uses phi / belief; "p" would use phi_model
    generators=None,         # pass Gq or Gp explicitly

    # numerics
    eps=1e-6,
    ridge_q=1e-3, ridge_p=1e-3,

    # legacy / unused here but kept for signature compatibility
    use_disk=True,
):
    """
    Initialize each parent's mask strictly from *agreement* (no union fallback),
    then aggregate q/p fields. Optional support gating ensures masks only live
    where ≥k (or all) children actually have coverage at that pixel.

    Debug prints: IoU vs union/intersection after mask is set on each parent.
    """
    import numpy as np

    labels = np.asarray(labels)
    H, W = children[0].mask.shape

    # 1) Pairwise soft agreements once (for the chosen fiber)
    A_maps = {}; joint_maps = {}
    if use_agreement_masks:
        pairs, A_maps, joint_maps = compute_pairwise_agreement_maps(
            children, tau=tau_align, eps=eps, field=field, generators=generators
        )
        A_maps = A_maps if isinstance(A_maps, dict) else {}
        joint_maps = joint_maps if isinstance(joint_maps, dict) else {}

    for pid, P in enumerate(parents):
        kid_ids = [ci for ci, lab in enumerate(labels) if int(lab) == pid]
        print(f"[INIT MASK] pid={pid} kids={kid_ids} use_agree={use_agreement_masks}", flush=True)

        # 2) Agreement mask (strict; returns zeros if no agreement)
        if use_agreement_masks and kid_ids:
            maskP = build_parent_mask_from_group(
                children, kid_ids, A_maps, joint_maps,
                tau=tau_align, m_core=m_core, A_min=A_min,
                soft=soft, smooth_iters=smooth_iters
            )
            if maskP is None:
                maskP = np.zeros((H, W), dtype=np.float32)
        else:
            maskP = np.zeros((H, W), dtype=np.float32)

        # 3) Optional support gating AFTER agreement (prevents union leakage)
        if kid_ids and support_mode.lower() != "none":
            stack_bool = np.stack([(children[cid].mask > eps) for cid in kid_ids], axis=0)  # (Cg,H,W)
            if support_mode.lower() == "all":
                gate = stack_bool.all(axis=0)                        # strict intersection
            else:  # "kofn"
                Cg = stack_bool.shape[0]
                k = k_support if (k_support is not None) else max(2, int(np.ceil(0.5 * Cg)))
                gate = (stack_bool.sum(axis=0) >= k)
            maskP = (maskP * gate.astype(np.float32)).astype(np.float32)

        # 4) Commit the mask, then DEBUG IoU vs union/intersection
        P.mask = maskP.astype(np.float32)

        if kid_ids:
            union_b = np.zeros((H, W), dtype=bool)
            inter_b = np.ones((H, W), dtype=bool)
            for cid in kid_ids:
                m = (children[cid].mask > eps)
                union_b |= m
                inter_b &= m
            Pm = (P.mask > 0.3)
            def _iou(a,b):
                u = (a | b).sum()
                return float((a & b).sum()) / (u if u else 1.0)
            print(
                f"[MASK DEBUG] pid={pid} area={int(Pm.sum())} "
                f"IoU(union)={_iou(Pm, union_b):.3f} IoU(inter)={_iou(Pm, inter_b):.3f} "
                f"support={support_mode}{'' if support_mode!='kofn' else f'({k})'}",
                flush=True
            )

        # 5) Aggregate Gaussian fields (does NOT modify P.mask)
        if not hasattr(P, "mu_q_field") or not hasattr(P, "sigma_q_field"):
            mu_q, S_q = _moment_aggregate_gaussians(children, labels, pid, field="q", eps=eps, ridge=ridge_q)
            if mu_q is not None:
                P.mu_q_field, P.sigma_q_field = mu_q, S_q

        if not hasattr(P, "mu_p_field") or not hasattr(P, "sigma_p_field"):
            mu_p, S_p = _moment_aggregate_gaussians(children, labels, pid, field="p", eps=eps, ridge=ridge_p)
            if mu_p is not None:
                P.mu_p_field, P.sigma_p_field = mu_p, S_p





def set_parent_neighbors(parents, mode="overlap", k=2, overlap_thresh=0.10):
    """
    Set P.neighbors for meta-agents.
    mode="overlap": connect parents whose masks overlap by >= overlap_thresh
    mode="knn":     connect k nearest by center distance
    """
    M = len(parents)
    # ensure centers exist
    centers = []
    for P in parents:
        if not hasattr(P, "center"):
            # fallback: mask centroid
            yy, xx = np.mgrid[:P.mask.shape[0], :P.mask.shape[1]]
            w = (P.mask > 1e-6).astype(float)
            s = w.sum() or 1.0
            cx = float((w*xx).sum()/s); cy = float((w*yy).sum()/s)
            P.center = (cx, cy)
        centers.append(P.center)

    for i, Pi in enumerate(parents):
        neigh = []
        if mode == "overlap":
            Ai = (Pi.mask > 1e-6)
            ai = Ai.sum() or 1
            for j, Pj in enumerate(parents):
                if j == i: continue
                Aj = (Pj.mask > 1e-6)
                inter = (Ai & Aj).sum()
                frac = inter / min(ai, Aj.sum() or 1)
                if frac >= overlap_thresh:
                    neigh.append(j)
        else:  # knn
            di = []
            cx, cy = centers[i]
            for j, (cxj, cyj) in enumerate(centers):
                if j == i: continue
                di.append((j, (cx - cxj)**2 + (cy - cyj)**2))
            di.sort(key=lambda t: t[1])
            neigh = [j for j,_ in di[:k]]
        Pi.neighbors = neigh



def _stack_axis_angles(children, parent, field):
    # helper to gather (C,H,W,3) axis-angle stack for the seed
    out = []
    for cid in parent.child_ids:
        out.append(getattr(children[cid], field)[..., :3][None, ...])
    return np.concatenate(out, axis=0)






def compute_cluster_kl_stats(kl_matrix, labels, verbose=False):
    """
    Compute intra-/extra-cluster KL stats for each cluster.
    Returns dict[cluster_id] = {intra_vals, extra_vals, means, stds}
    """
    stats = {}
    for lab in np.unique(labels):
        if lab < 0:
            continue
        idx = np.where(labels == lab)[0]
        others = np.where(labels != lab)[0]

        # Intra-cluster KL
        intra_vals = kl_matrix[np.ix_(idx, idx)]
        iu = np.triu_indices(len(idx), k=1)
        intra = intra_vals[iu][np.isfinite(intra_vals[iu])]

        # Extra-cluster KL
        extra = kl_matrix[np.ix_(idx, others)].ravel()
        extra = extra[np.isfinite(extra)]

        stats[int(lab)] = {
            'intra_vals': intra,
            'extra_vals': extra,
            'intra_mean': float(np.mean(intra)) if intra.size else np.nan,
            'extra_mean': float(np.mean(extra)) if extra.size else np.nan,
            'intra_std': float(np.std(intra)) if intra.size else np.nan,
            'extra_std': float(np.std(extra)) if extra.size else np.nan,
        }

        if verbose:
            print(f"[cluster {lab}] N={len(idx)}  KL_intra={stats[lab]['intra_mean']:.3f}  KL_extra={stats[lab]['extra_mean']:.3f}")

    return stats













































def build_runtime_params_for_xscale(generators_q, generators_p, parents, labels):
    return {
        "generators_q": generators_q,
        "generators_p": generators_p,
        "enable_crossscale": getattr(config, "enable_crossscale", False),

        # weights from config
        "beta_up_q":  getattr(config, "beta_up_q", 0.0),
        "beta_dn_q":  getattr(config, "beta_dn_q", 0.0),
        "beta_up_p":  getattr(config, "beta_up_p", 0.0),
        "beta_dn_p":  getattr(config, "beta_dn_p", 0.0),

        # lrs + logging
        "xscale_lr_mu_q_up":    getattr(config, "xscale_lr_mu_q_up", 0.12),
        "xscale_lr_sigma_q_up": getattr(config, "xscale_lr_sigma_q_up", 0.05),
        "xscale_lr_mu_q_dn":    getattr(config, "xscale_lr_mu_q_dn", 0.08),
        "xscale_lr_sigma_q_dn": getattr(config, "xscale_lr_sigma_q_dn", 0.04),
        "xscale_log_every":     getattr(config, "xscale_log_every", 10),

        # dynamic context stays here (not in config)
        "xscale": {
            "parents": parents,
            "labels":  np.asarray(labels),
        },
    }





def save_meta_agent_summary(meta_agents, path="meta_agent_analysis/meta_agent_summary.json"):
    out = []
    for P in meta_agents:
        # center as tuple[int,int] or None
        center = getattr(P, "center", None)
        if center is not None:
            try:
                center = (int(center[0]), int(center[1]))
            except Exception:
                center = None

        row = {
            "id": _as_int_or_none(getattr(P, "id", None)),
            "level": _as_int_or_none(getattr(P, "level", None)),
            "center": center,
            "radius": _as_float_or_nan(getattr(P, "radius", None)),

            "mask_shape": _shape_or_none(getattr(P, "mask", None)),
            "K_q": (int(getattr(P, "mu_q_field").shape[-1]) 
                    if getattr(P, "mu_q_field", None) is not None else None),
            "K_p": (int(getattr(P, "mu_p_field").shape[-1]) 
                    if getattr(P, "mu_p_field", None) is not None else None),

            "Lambda_dn_q_shape": _shape_or_none(getattr(P, "Lambda_dn_q", None)),
            "Lambda_dn_p_shape": _shape_or_none(getattr(P, "Lambda_dn_p", None)),

            "child_ids": _to_py_list_int(getattr(P, "child_ids", [])),
            "parent_ids": _to_py_list_int(getattr(P, "parent_ids", [])),
        }
        out.append(row)

    Path(path).parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w") as f:
        json.dump(out, f, indent=2)




def _prepare_generators():
    Gq = get_generators(group_name, K_q)
    Gp = get_generators(group_name, K_p)
    return Gq, Gp, {"q": Gq, "p": Gp}


def wire_child_parent_links(children, parents, labels):
    for P in parents:
        P.child_ids = []
        P.level = getattr(P, "level", 1)
    for cid, child in enumerate(children):
        pid = int(labels[cid])
        child.parent_ids = [pid]
        parents[pid].child_ids.append(cid)


def _kl_plateau(metric_log, window=15, tol=1e-3):
    vals = [m.get("xscale_kl_q_mean") for m in metric_log if "xscale_kl_q_mean" in m]
    vals = [v for v in vals if v is not None and np.isfinite(v)]
    if len(vals) < 2*window:
        return False, np.nan
    a, b = np.nanmean(vals[-2*window:-window]), np.nanmean(vals[-window:])
    return (abs(a - b) < tol), b

def _ensure_parent_slots(meta_agents, Kq=None, Kp=None):
    """Ensure parents have Λ/Θ slots and a level tag."""
    Kq = getattr(config, "K_q") if Kq is None else Kq
    Kp = getattr(config, "K_p") if Kp is None else Kp
    for P in meta_agents:
        attach_crossscale_fields(P, Kq, Kp)  # no-op if present
        P.level = getattr(P, "level", 1)




def _shape_or_none(x):
    try:
        return None if x is None else tuple(int(s) for s in x.shape)
    except Exception:
        return None

def _as_int_or_none(x):
    if x is None:
        return None
    return int(x) if isinstance(x, (int, np.integer)) else int(x)

def _as_float_or_nan(x):
    if x is None:
        return float("nan")
    return float(x) if isinstance(x, (float, np.floating)) else float(x)

def _to_py_list_int(xs):
    return [int(v) for v in xs] if xs is not None else []


def transport_covariance_batch(Sigma, Omega):
    """
    Transport a batch of covariance matrices: Σ → Ω Σ Ωᵀ

    Parameters:
        Sigma: (N, K, K) — batch of covariance matrices
        Omega: (N, K, K) — batch of transport operators

    Returns:
        Sigma_t: (N, K, K) — transported covariances
    """
    return Omega @ Sigma @ np.transpose(Omega, (0, 2, 1))




def overlap_area_matrix(agents, eps: float = 1e-6) -> np.ndarray:
    """
    Compute N x N matrix where entry (i, j) is the area of overlap between agent i and j.
    """
    N = len(agents)
    area = np.zeros((N, N), dtype=float)
    for i in range(N):
        mask_i = agents[i].mask > eps
        for j in range(i, N):
            if i == j:
                area[i, j] = np.sum(mask_i)
            else:
                mask_j = agents[j].mask > eps
                area_ij = np.sum(np.logical_and(mask_i, mask_j))
                area[i, j] = area[j, i] = area_ij
    return area


def _union_mask_from_children(children, labels, pid, H, W, center=None, radius=None):
    m = np.zeros((H, W), dtype=bool)
    for ci, lab in enumerate(labels):
        if int(lab) == pid:
            m |= (children[ci].mask > 1e-6)
    if (center is not None) and (radius is not None):
        yy, xx = np.mgrid[:H, :W]
        cx, cy = int(center[0]), int(center[1])
        disk = (xx - cx) ** 2 + (yy - cy) ** 2 <= (radius ** 2)
        m |= disk
    return m.astype(np.float32)

def aggregate_mask(agent_list, eps: float = 1e-3):
    """Compute union of support masks across agents."""
    masks = [(ag.mask > eps).astype(float) for ag in agent_list]
    return np.clip(np.sum(masks, axis=0), 0, 1)
