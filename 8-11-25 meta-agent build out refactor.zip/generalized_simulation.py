
import os
os.environ["OMP_NUM_THREADS"] = "1"
os.environ["MKL_NUM_THREADS"] = "1"
os.environ["NUMEXPR_NUM_THREADS"] = "1"  # Optional: just in case
os.environ["OPENBLAS_NUM_THREADS"]= "1"

# Print to confirm they are set
print("[THREADING] Thread limits set:")
print(f"  OMP_NUM_THREADS      = {os.environ.get('OMP_NUM_THREADS')}")
print(f"  MKL_NUM_THREADS      = {os.environ.get('MKL_NUM_THREADS')}")
print(f"  NUMEXPR_NUM_THREADS  = {os.environ.get('NUMEXPR_NUM_THREADS')}")
print(f"  OPENBLAS_NUM_THREADS = {os.environ.get('OPENBLAS_NUM_THREADS')}")

# Standard library
import os
import time
import config
# Third-party
import pickle
import pandas as pd
from update_rules import synchronous_step, step_telemetry,_masked_unit, energy_diff_for_phi, energy_diff_for_phi_model
# Local configuration & utilities

from config_utils import set_config_from_params
from get_generators import get_generators
# run_simulation.py (cleaner entrypoint)
import sys

# add near other imports
import numpy as np
from update_crossscale_terms import ( xscale_q_up_step, xscale_q_dn_step, 
                                    xscale_p_dn_step, xscale_p_up_step,
                                    estimate_fisher_metric_from_field,
                                    fisher_adjoint
                                    )
from xscale_helpers import compute_avg_crossscale_kl_p
from meta_agent_plots import _snapshot_parents_npz, _append_parent_metrics_csv
# I/O helpers
from generalized_io_utils import (
    save_step,
    load_checkpoint,
    find_resume_step,
    save_config_to_readme,
)

# Agent construction
from agent_initialization import initialize_agents, initialize_agent_gradients

from generalized_diagnostics_metrics import log_all_metrics, full_field_logger
from xscale_helpers import procrustes_seed_lambda_dn_q, compute_avg_crossscale_kl_q
from agent_initialization import attach_crossscale_fields

# ─────────────────────────────────────────────────────────────────────────────
# LOGGING HELPERS & DEFAULTS (drop near your imports)
# ─────────────────────────────────────────────────────────────────────────────



LOGGING_DEFAULTS = dict(
    # master switches
    enable_scalar=True,          # run log_all_metrics
    enable_fields=False,          # run full_field_logger
    enable_max_overlap=True,     # (unused if you've removed that feature)
    print_total_energy=True,

    # cost-control cadence
    fields_every=1,              # dump full fields every k steps
    max_overlap_every=1,         # (unused if you've removed that feature)

    # misc schema & outdirs
    schema_version="v3",
    full_field_outdir="fields",
    pair_outdir="max_overlap",
)

def _merge_logging_cfg(params_or_cfg):
    """Return a logging dict with sane defaults even if missing."""
    logcfg = {}
    if hasattr(params_or_cfg, "get"):  # dict-like
        logcfg = params_or_cfg.get("logging", {}) or {}
    elif hasattr(params_or_cfg, "__dict__"):
        logcfg = getattr(params_or_cfg, "logging", {}) or {}
    out = dict(LOGGING_DEFAULTS)
    out.update(logcfg)
    return out


# ─────────────────────────────────────────────────────────────────────────────
# UPDATED run_simulation WITH NEW LOGGING
# ─────────────────────────────────────────────────────────────────────────────
def run_simulation(
    outdir="checkpoints",
    resume=False,
    log_metrics=True,   # function-level switches still honored
    log_fields=True,
    num_cores=None,
    params=None,
    fresh_outdir=False,       # NEW: rotate outdir if not resuming
    clear_agent_logs=True,    # NEW: clear per-agent logs on fresh init
):
    import os, shutil, time, pickle
    
    # Fresh run directory (only if not resuming)
    if not resume and fresh_outdir and os.path.isdir(outdir):
        ts = time.strftime("%Y%m%d_%H%M%S")
        shutil.move(outdir, f"{outdir}_old_{ts}")

    os.makedirs(outdir, exist_ok=True)
    save_config_to_readme(outdir)

    num_cores = 18 if num_cores is None else num_cores
    params = {} if params is None else params

    # --- config helper: prefer params[...] then fall back to config.key
    def _cfg(key, default=None):
        if isinstance(params, dict) and key in params:
            return params[key]
        return getattr(config, key, default)

    # --- generators (ensure present + stash in params for downstream)
    def _prepare_generators():
        Gq = params.get("generators_q")
        Gp = params.get("generators_p")
        if Gq is None:
            Gq, _ = get_generators(config.group_name, config.K_q, return_meta=True)
            params["generators_q"] = Gq
        if Gp is None:
            Gp, _ = get_generators(config.group_name, config.K_p, return_meta=True)
            params["generators_p"] = Gp
        return Gq, Gp

    G_q, G_p = _prepare_generators()

    # --- merge logging cfg and honor function gates
    logcfg = _merge_logging_cfg(params if isinstance(params, dict) else vars(config))
    if not log_metrics:
        logcfg["enable_scalar"] = False
    if not log_fields:
        logcfg["enable_fields"] = False

    # --- init / resume
    if resume:
        agents, _ = load_checkpoint(outdir)
        step_start = find_resume_step(outdir)
    else:
        agents = initialize_agents(
            seed=getattr(config, "seed", None),
            domain_size=config.domain_size,
            N=config.N,
            K_q=config.K_q,
            K_p=config.K_p,
            lie_algebra_dim=3,
            visualize=False,
            fixed_location=False,
        )
        step_start = 0
        for A in agents:
            initialize_agent_gradients(A, config)
        # NEW: clear any lingering per-agent logs from previous sessions in memory
        if clear_agent_logs:
            for A in agents:
                if hasattr(A, "metrics_log"):
                    A.metrics_log.clear()

    # make sure agents carry generators
    for A in agents:
        A.generators_q = G_q
        A.generators_p = G_p

    # --- cross-scale context (optional)
    xscale_ctx = params.get("xscale")
    parents, labels = (None, None)
    if xscale_ctx:
        parents = xscale_ctx["parents"]
        labels  = np.asarray(xscale_ctx["labels"])

        # parents must also carry generators and Λ/Θ slots
        for P in parents:
            P.generators_q = G_q
            P.generators_p = G_p
            try:
                attach_crossscale_fields(P, config.K_q, config.K_p)
                P.level = getattr(P, "level", 1)
            except NameError:
                pass

        # ensure children expose cross-scale slots
        for C in agents:
            try:
                attach_crossscale_fields(C, config.K_q, config.K_p)
            except NameError:
                pass

    xscale_enabled    = bool(_cfg("enable_crossscale", False) and (parents is not None) and (labels is not None))
    xscale_log_every  = int(_cfg("xscale_log_every", 10))

    # seed Λ_dn_q once (optional)
    if xscale_enabled and _cfg("xscale_seed_lambda_dn_q", False):
        try:
            
            procrustes_seed_lambda_dn_q(parents, agents, labels)
            print("[XSCALE] Procrustes seeded Λ_dn_q")
        except Exception as e:
            print(f"[XSCALE] Λ seed skipped: {e}")

    # --- ensure output dirs if needed
    if logcfg.get("enable_fields", False):
        os.makedirs(os.path.join(outdir, logcfg["full_field_outdir"]), exist_ok=True)
    if logcfg.get("enable_max_overlap", False):
        os.makedirs(os.path.join(outdir, logcfg["pair_outdir"]), exist_ok=True)

    metric_log = []
    print(f"[RUN] Starting simulation at step {step_start} with {num_cores} cores")

    # =================== main loop ===================
    for step in range(step_start, config.steps):
        print(f"\n[STEP {step}] -----------------------------")

        
        t0 = time.perf_counter()
        step_params = {**params, "step": step, "sanitize_strict_pre": False}
        agents = synchronous_step(agents, G_q, G_p, params=step_params, n_jobs=num_cores)
        print(f"[TIMER] synchronous update: {time.perf_counter() - t0:.3f}s")

        # --- cross-scale updates (q)
        if xscale_enabled:
            beta_up = _cfg("beta_up_q", 0.0)
            if beta_up > 0.0:
                xscale_q_up_step(
                    agents, parents, labels,
                    beta=beta_up,
                    lr_mu=_cfg("xscale_lr_mu_q_up", 0.12),
                    lr_sigma=_cfg("xscale_lr_sigma_q_up", 0.05),
                    eps=1e-6, clip_mu=0.5, clip_S=0.25
                )
            beta_dn = _cfg("beta_dn_q", 0.0)
            if beta_dn > 0.0:
                xscale_q_dn_step(
                    agents, parents, labels,
                    beta=beta_dn,
                    lr_mu=_cfg("xscale_lr_mu_q_dn", 0.08),
                    lr_sigma=_cfg("xscale_lr_sigma_q_dn", 0.04),
                    eps=1e-6
                )

            if (step % xscale_log_every) == 0:
                vals = compute_avg_crossscale_kl_q(agents, parents, labels, eps=1e-6)
                print(f"[XSCALE] step {step}: mean KL(child||Λ_dn_q·parent) = {np.nanmean(vals):.5f}  n={np.isfinite(vals).sum()}")
                _append_parent_metrics_csv(outdir, step, parents)
        # --- cross-scale updates (p)
        if xscale_enabled and _cfg("enable_crossscale_p", False):
            beta_up_p = _cfg("beta_up_p", 0.0)
            if beta_up_p > 0.0:
                xscale_p_up_step(
                    agents, parents, labels,
                    beta=beta_up_p,
                    lr_mu=_cfg("xscale_lr_mu_p_up", 0.10),
                    lr_sigma=_cfg("xscale_lr_sigma_p_up", 0.05),
                    eps=1e-6, clip_mu=0.5, clip_S=0.25
                )
            beta_dn_p = _cfg("beta_dn_p", 0.0)
            if beta_dn_p > 0.0:
                for P in parents:
                    if getattr(P, "Lambda_dn_p", None) is not None and getattr(P, "Lambda_up_p", None) is None:
                        try:
                            G_child = estimate_fisher_metric_from_field(P.sigma_p_field, P.mask)
                            Gp      = estimate_fisher_metric_from_field(P.sigma_p_field, P.mask)
                            if P.Lambda_dn_p.shape[-2] == G_child.shape[-1] and P.Lambda_dn_p.shape[-1] == Gp.shape[-1]:
                                P.Lambda_up_p = fisher_adjoint(P.Lambda_dn_p, G_child, Gp)
                        except Exception:
                            pass
                        
                xscale_p_dn_step(
                    agents, parents, labels,
                    beta=beta_dn_p,
                    lr_mu=_cfg("xscale_lr_mu_p_dn", 0.08),
                    lr_sigma=_cfg("xscale_lr_sigma_p_dn", 0.04),
                    eps=1e-6
                )

            if (step % xscale_log_every) == 0:
                vals_p = compute_avg_crossscale_kl_p(agents, parents, labels, eps=1e-6)
                print(f"[XSCALE:P] step {step}: mean KL(child||Λ̃_dn_p·parent) = {np.nanmean(vals_p):.5f}  n={np.isfinite(vals_p).sum()}")

        # --- scalar metrics
        if logcfg.get("enable_scalar", False):
            t1 = time.perf_counter()
            m = log_all_metrics(agents, step=step, params=params, n_jobs=num_cores)

            if xscale_enabled:
                vals = compute_avg_crossscale_kl_q(agents, parents, labels, eps=1e-6)
                m["xscale_kl_q_mean"] = float(np.nanmean(vals))
                m["xscale_kl_q_n"]    = int(np.isfinite(vals).sum())

            if xscale_enabled and _cfg("enable_crossscale_p", False):
                vals_p = compute_avg_crossscale_kl_p(agents, parents, labels, eps=1e-6)
                m["xscale_kl_p_mean"] = float(np.nanmean(vals_p))
                m["xscale_kl_p_n"]    = int(np.isfinite(vals_p).sum())

            m["schema"] = logcfg["schema_version"]
            m["compute_ms"] = int((time.perf_counter() - t1) * 1000)
            metric_log.append(m)

            if logcfg.get("print_total_energy", False):
                print(f"[Energy Totals @ step {step}]")
                print(f"  Self belief      = {m['e_self']:.4e}")
                print(f"  Feedback model   = {m['e_feedback']:.4e}")
                print(f"  Belief alignment = {m['e_align']:.4e}")
                print(f"  Model alignment  = {m['e_mod_align']:.4e}")
                print(f"  Model Mass       = {m['e_mass_mod']:.4e}")
                print(f"  Belief Mass      = {m['e_mass']:.4e}")
                print(f"  Belief Curvature = {m['e_curv']:.4e}")
                print(f"  Model Curvature  = {m['e_curv_mod']:.4e}")
                print(f"[TIMER] log_all_metrics: {time.perf_counter() - t1:.3f}s")

        # --- full fields (cadence)
        if logcfg.get("enable_fields", False) and (step % logcfg["fields_every"] == 0):
            tF = time.perf_counter()
            field_dir = os.path.join(outdir, logcfg["full_field_outdir"])
            full_field_logger(agents, step, field_dir, params=params)
            print(f"[TIMER] full_field_logger: {time.perf_counter() - tF:.3f}s")

        # --- checkpoint
        for A in agents:
            if hasattr(A, "clear_omega_cache"):   A.clear_omega_cache()
            if hasattr(A, "clear_fisher_caches"): A.clear_fisher_caches()
        save_step(agents, outdir, step)
        print(f"[SAVE] Checkpoint --> {outdir}/step_{step:04d}.pkl")

    # =================== epilogue ===================
    if logcfg.get("enable_scalar", False):
        with open(os.path.join(outdir, "metric_log.pkl"), "wb") as f:
            pickle.dump(metric_log, f)
        print(f"[SAVE] Metrics log --> {outdir}/metric_log.pkl")

        rows = [
            {"agent": A.id, **entry}
            for A in agents
            for entry in getattr(A, "metrics_log", [])
        ]
        if rows:
            pd.DataFrame(rows).to_csv(os.path.join(outdir, "per_agent_metrics.csv"), index=False)
            print("[SAVE] Per-agent metrics --> per_agent_metrics.csv")

    if xscale_enabled:
        _snapshot_parents_npz(parents, os.path.join(outdir, "parents_end.npz"))


    print("[DONE] Simulation completed.")
    return agents, metric_log


if __name__ == "__main__":
    

    # ─────────────────────────────────────────────
    # 1. Optional param override
    # ─────────────────────────────────────────────
    if len(sys.argv) > 1:
        with open(sys.argv[1], "rb") as f:
            param_override = pickle.load(f)
        set_config_from_params(param_override)
    else:
        param_override = {}

    # ─────────────────────────────────────────────
    # 2. Load SO(3) generators for q and p fibers
    # ─────────────────────────────────────────────
    G_q, meta_q = get_generators(config.group_name, config.K_q, return_meta=True)
    G_p, meta_p = get_generators(config.group_name, config.K_p, return_meta=True)

    # ─────────────────────────────────────────────
    # 3. Bundle runtime-only params
    # ─────────────────────────────────────────────
    runtime_params = {
        "generators_q": G_q,
        "generators_p": G_p,
    }

    # ─────────────────────────────────────────────
    # 4. Run the simulation
    # ─────────────────────────────────────────────
    run_simulation(
        outdir="checkpoints",
        resume=False,
        log_metrics = True,
        log_fields  = False ,
        params=runtime_params,
    )
