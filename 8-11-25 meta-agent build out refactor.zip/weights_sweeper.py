
"""
weights_sweeper_api.py
Programmatic (non-CLI) API to sweep weight parameters and run your simulation.

Example:
    from weights_sweeper_api import sweep_weights

    df = sweep_weights(
        weight_values={
            "alpha": [0.0, 0.5, 1.0],
            "beta": [0.0, 1.0],
            "feedback_weight": [0.0, 0.2],
        },
        steps=50,
        base_outdir="sweeps/alpha_beta_fb",
        per_run_cores=4,
        outer_jobs=1,       # run sequentially; set >1 to parallelize runs
        log_fields=False,   # speeds things up
        log_metrics=True,
        seed=1234,
    )
    print(df.head())
"""

from __future__ import annotations

import json
import math
import os
import sys
import time
from dataclasses import dataclass
from itertools import product
from pathlib import Path
from typing import Any, Callable, Dict, Iterable, List, Optional, Tuple

import numpy as np
import pandas as pd


# ------------------------------ utils ------------------------------

def _short_tag(val: float) -> str:
    """Short stable tag for floats (avoid long paths on Windows)."""
    if val == 0:
        return "0"
    exp = int(math.floor(math.log10(abs(val)))) if val != 0 else 0
    if -3 <= exp <= 3:
        return f"{val:.3g}".replace('.', 'p').replace('-', 'm')
    else:
        return f"{val:.1e}".replace('.', 'p').replace('+', '').replace('-', 'm')

def _slug_params(d: Dict[str, float], keys: List[str]) -> str:
    parts = []
    for k in keys:
        if k in d:
            parts.append(f"{k[:3]}{_short_tag(d[k])}")
    return "_".join(parts) if parts else "base"

def _flatten_metric_log(metric_log: List[dict]) -> dict:
    """Return last entry + some aggregates if present."""
    if not metric_log:
        return {}
    last = metric_log[-1].copy()
    # add simple aggregates if present
    for k in ("total_energy", "self_energy", "feedback_energy", "alignment_energy", "curvature_energy"):
        if k in last:
            last[f"final_{k}"] = last.pop(k)
    return last


# ------------------------------ API ------------------------------

@dataclass
class SweepConfig:
    weight_values: Dict[str, Iterable[float]]
    steps: Optional[int] = None
    base_outdir: str = "sweeps/weights"
    per_run_cores: int = 4
    outer_jobs: int = 1
    log_fields: bool = False
    log_metrics: bool = True
    seed: Optional[int] = None
    # Optional: add extra params to pass through to run_simulation (e.g., N agents, domain size, etc.)
    params_extra: Optional[Dict[str, Any]] = None
    # Optional: provide your project root if imports need help
    project_root: Optional[str] = None
    # Optional callback for per-run inspection: fn(summary_dict, run_outdir, agents, metric_log) -> None
    per_run_callback: Optional[Callable[[Dict[str, Any], Path, Any, List[dict]], None]] = None


def sweep_weights(
    weight_values: Dict[str, Iterable[float]],
    steps: Optional[int] = None,
    base_outdir: str = "sweeps/weights",
    per_run_cores: int = 4,
    outer_jobs: int = 1,
    log_fields: bool = False,
    log_metrics: bool = True,
    seed: Optional[int] = None,
    params_extra: Optional[Dict[str, Any]] = None,
    project_root: Optional[str] = None,
    per_run_callback: Optional[Callable[[Dict[str, Any], Path, Any, List[dict]], None]] = None,
) -> pd.DataFrame:
    """
    Run a sweep over combinations of weights. Returns a pandas DataFrame
    of per-run summaries (also written to base_outdir/sweep_summary.csv).

    Args:
        weight_values: dict of {weight_name: iterable_of_values}
        steps: override number of steps per run (None -> use your config default)
        base_outdir: folder for all runs
        per_run_cores: inner parallelism per simulation
        outer_jobs: number of simulations to run in parallel (processes)
        log_fields: enable/disable field dumps
        log_metrics: enable/disable scalar metric logging
        seed: deterministic seed
        params_extra: extra params to pass directly to run_simulation
        project_root: if not None, prepend to sys.path for imports
        per_run_callback: optional function called after each run

    Returns:
        pandas.DataFrame with one row per sweep combo.
    """
    cfg = SweepConfig(
        weight_values=weight_values,
        steps=steps,
        base_outdir=base_outdir,
        per_run_cores=per_run_cores,
        outer_jobs=outer_jobs,
        log_fields=log_fields,
        log_metrics=log_metrics,
        seed=seed,
        params_extra=params_extra or {},
        project_root=project_root,
        per_run_callback=per_run_callback,
    )
    return _sweep_impl(cfg)
# =========================
# Ratio-based sweep + Morris
# =========================

def _weights_from_rho(rho: Dict[str, float],
                      ref_weight: str = "alpha",
                      ref_value: float = 1.0,
                      base_scales: Optional[Dict[str, float]] = None) -> Dict[str, float]:
    """
    Convert log10-ratio dictionary rho into actual weights.
      w_ref = ref_value
      w_k   = (base_scales.get(k, 1.0) * ref_value) * 10**rho[k]
    Example: rho = {"beta": -1, "curvature_weight": 2}  => beta=0.1*ref, curvature=100*ref
    """
    w = {ref_weight: float(ref_value)}
    base_scales = base_scales or {}
    for k, v in rho.items():
        if k == ref_weight:
            # allow explicit override via rho[ref] meaning 10**rho * ref_value
            w[k] = float(ref_value) * (10.0 ** float(v))
        else:
            w[k] = float(base_scales.get(k, 1.0)) * float(ref_value) * (10.0 ** float(v))
    return w


def _latin_hypercube(n_samples: int,
                     bounds: Dict[str, Tuple[float, float]],
                     seed: Optional[int] = None) -> List[Dict[str, float]]:
    """
    Simple Latin Hypercube in log10-ratio space.
    bounds: dict param -> (low, high) in log10-ratio units.
    Returns list of dicts {param: value}.
    """
    rng = np.random.default_rng(seed)
    params = list(bounds.keys())
    samples = []
    # stratify each dimension into n bins and permute
    bins = {p: rng.permutation(n_samples) for p in params}
    jitter = rng.random((len(params), n_samples))
    for i in range(n_samples):
        rho = {}
        for d, p in enumerate(params):
            lo, hi = bounds[p]
            # pick the i-th stratum for this param according to a permutation
            k = bins[p][i]
            u = (k + jitter[d, i]) / n_samples
            rho[p] = float(lo + u * (hi - lo))
        samples.append(rho)
    return samples


def sweep_ratios_lhs(ratio_bounds: Dict[str, Tuple[float, float]],
                     n_samples: int,
                     ref_weight: str = "alpha",
                     ref_value: float = 1.0,
                     base_scales: Optional[Dict[str, float]] = None,
                     steps: Optional[int] = None,
                     base_outdir: str = "sweeps/ratio_lhs",
                     per_run_cores: int = 4,
                     outer_jobs: int = 1,
                     log_fields: bool = False,
                     log_metrics: bool = True,
                     seed: Optional[int] = None,
                     params_extra: Optional[Dict[str, Any]] = None,
                     project_root: Optional[str] = None,
                     per_run_callback: Optional[Callable[[Dict[str, Any], Path, Any, List[dict]], None]] = None
) -> pd.DataFrame:
    """
    Latin Hypercube sweep in **log10-ratio space**.
      - You specify bounds like {"beta": (-3, +3), "curvature_weight": (-2, +2), ...}
      - We sample n points in that box via LHS, convert to actual weights with _weights_from_rho
      - ref_weight is fixed to ref_value (others are ratios to it)
    """
    # Build concrete weight sets
    rho_samples = _latin_hypercube(n_samples, ratio_bounds, seed=seed)
    weight_values_list = [
        _weights_from_rho(rho, ref_weight=ref_weight, ref_value=ref_value, base_scales=base_scales)
        for rho in rho_samples
    ]

    # Use existing machinery by calling _sweep_impl with one-combo-at-a-time
    cfg = SweepConfig(
        weight_values={},  # unused here
        steps=steps,
        base_outdir=base_outdir,
        per_run_cores=per_run_cores,
        outer_jobs=outer_jobs,
        log_fields=log_fields,
        log_metrics=log_metrics,
        seed=seed,
        params_extra=params_extra or {},
        project_root=project_root,
        per_run_callback=per_run_callback,
    )

    # Optional sys.path inject
    if cfg.project_root and cfg.project_root not in sys.path:
        sys.path.insert(0, cfg.project_root)

    from generalized_simulation import run_simulation
    try:
        from generalized_diagnostics_metrics import compute_total_energy
    except Exception:
        compute_total_energy = None

    base = Path(cfg.base_outdir).resolve()
    base.mkdir(parents=True, exist_ok=True)

    summaries = []

    def _run_one(combo: Dict[str, float], idx: int) -> Dict[str, Any]:
        # Prepare params for a single run
        params: Dict[str, Any] = {}
        params.update(combo)
        params.update(cfg.params_extra or {})
        if cfg.steps is not None:
            params["steps"] = int(cfg.steps)
        params["logging"] = {
            "enable_scalar": bool(cfg.log_metrics),
            "enable_fields": bool(cfg.log_fields),
            "full_field_outdir": "fields",
            "pair_outdir": "pairs",
        }
        if cfg.seed is not None:
            params["seed"] = int(cfg.seed)

        # tag encodes ratios compactly (e.g., r0, r1, ...)
        tag = f"lhs_{idx:04d}"
        outdir = base / tag
        outdir.mkdir(parents=True, exist_ok=True)

        t0 = time.perf_counter()
        agents, metric_log = run_simulation(
            outdir=str(outdir),
            resume=False,
            log_metrics=bool(cfg.log_metrics),
            log_fields=bool(cfg.log_fields),
            num_cores=int(cfg.per_run_cores),
            params=params,
        )
        dt = time.perf_counter() - t0

        summary = {**combo, "run_outdir": str(outdir), "elapsed_sec": dt}
        # flatten last metrics if present
        if metric_log:
            last = metric_log[-1].copy()
            for k in ("total_energy", "self_energy", "feedback_energy", "alignment_energy", "curvature_energy"):
                if k in last:
                    summary[f"final_{k}"] = last[k]
        if compute_total_energy is not None and "final_total_energy" not in summary:
            try:
                E_final = float(np.sum([
                    np.nanmean(compute_total_energy(a, agents, params=params))
                    for a in agents
                ]))
                summary["final_total_energy"] = E_final
            except Exception:
                pass

        with open(outdir / "sweep_summary.json", "w") as f:
            json.dump(summary, f, indent=2)

        if per_run_callback is not None:
            try:
                per_run_callback(summary, outdir, agents, metric_log)
            except Exception as e:
                print(f"[WARN] per_run_callback raised: {e}")

        return summary

    if outer_jobs <= 1:
        for i, combo in enumerate(weight_values_list):
            summaries.append(_run_one(combo, i))
    else:
        from joblib import Parallel, delayed
        results = Parallel(n_jobs=int(outer_jobs), backend="loky", verbose=10)(
            delayed(_run_one)(combo, i) for i, combo in enumerate(weight_values_list)
        )
        summaries = list(results)

    df = pd.DataFrame(summaries)
    df.to_csv(base / "sweep_summary.csv", index=False)
    return df


def morris_screening(ratio_bounds: Dict[str, Tuple[float, float]],
                     trajectories: int = 10,
                     step: float = 1.0,  # Δ in log10 units (e.g., 1.0 = ×10)
                     ref_weight: str = "alpha",
                     ref_value: float = 1.0,
                     base_scales: Optional[Dict[str, float]] = None,
                     steps: Optional[int] = None,
                     base_outdir: str = "sweeps/morris",
                     per_run_cores: int = 4,
                     log_fields: bool = False,
                     log_metrics: bool = True,
                     seed: Optional[int] = None,
                     params_extra: Optional[Dict[str, Any]] = None,
                     project_root: Optional[str] = None,
                     metric_key: str = "final_total_energy",
) -> pd.DataFrame:
    """
    Cheap sensitivity via one-at-a-time finite differences in **log10-ratio** space.
    For each trajectory:
      - sample a base rho within bounds
      - run base
      - for each param k, bump rho_k by ±step (clamped to bounds) and re-run
      - EE_k = (f(rho_bumped) - f(rho_base)) / step
    Returns a DataFrame with μ* (mean abs EE) and σ (std of EE) per param.
    Total runs ≈ trajectories × (1 + k)
    """
    rng = np.random.default_rng(seed)
    params = list(ratio_bounds.keys())
    k = len(params)

    # Make sure outdir exists
    base = Path(base_outdir).resolve()
    base.mkdir(parents=True, exist_ok=True)

    # Minimal runner that returns the chosen metric
    def run_metric(rho: Dict[str, float], tag: str) -> float:
        weights = _weights_from_rho(rho, ref_weight=ref_weight, ref_value=ref_value, base_scales=base_scales)
        # reuse LHS runner logic
        df = sweep_ratios_lhs(
            ratio_bounds={},  # unused
            n_samples=0,      # unused
            ref_weight=ref_weight,
            ref_value=ref_value,
            base_scales=base_scales,
            steps=steps,
            base_outdir=str(base / tag),
            per_run_cores=per_run_cores,
            outer_jobs=1,
            log_fields=log_fields,
            log_metrics=log_metrics,
            seed=seed,
            params_extra=params_extra,
            project_root=project_root,
            per_run_callback=None,
        )
        # The call above writes nothing if n_samples==0; do a direct single run instead:
        # So we directly replicate a one-off using generalized_simulation here:
        from generalized_simulation import run_simulation
        params_dict = dict(weights)
        if steps is not None: params_dict["steps"] = int(steps)
        params_dict["logging"] = {"enable_scalar": bool(log_metrics), "enable_fields": bool(log_fields),
                                  "full_field_outdir": "fields", "pair_outdir": "pairs"}
        if seed is not None: params_dict["seed"] = int(seed)
        outdir = base / tag
        outdir.mkdir(parents=True, exist_ok=True)
        agents, metric_log = run_simulation(
            outdir=str(outdir), resume=False, log_metrics=bool(log_metrics),
            log_fields=bool(log_fields), num_cores=int(per_run_cores), params=params_dict
        )
        # pick metric
        val = np.nan
        if metric_log:
            last = metric_log[-1]
            if metric_key in last:
                val = float(last[metric_key])
            elif "total_energy" in last:
                val = float(last["total_energy"])
        return val

    effects = {p: [] for p in params}

    for t in range(trajectories):
        # sample a base rho inside bounds with margin for a ±step move
        base_rho = {}
        for p in params:
            lo, hi = ratio_bounds[p]
            margin = max(0.0, step * 0.5)
            lo2 = lo + margin
            hi2 = hi - margin
            if hi2 < lo2:
                lo2, hi2 = lo, hi  # fall back if step > range
            base_rho[p] = float(rng.uniform(lo2, hi2))
        f0 = run_metric(base_rho, tag=f"morris_t{t:03d}_base")

        for p in params:
            lo, hi = ratio_bounds[p]
            # choose direction to stay within bounds
            if base_rho[p] + step <= hi:
                rho_b = dict(base_rho); rho_b[p] += step
            elif base_rho[p] - step >= lo:
                rho_b = dict(base_rho); rho_b[p] -= step
            else:
                # clamp to closest boundary
                rho_b = dict(base_rho); rho_b[p] = float(np.clip(base_rho[p] + step, lo, hi))
            f1 = run_metric(rho_b, tag=f"morris_t{t:03d}_{p}")
            ee = (f1 - f0) / step if (np.isfinite(f1) and np.isfinite(f0)) else np.nan
            effects[p].append(ee)

    rows = []
    for p in params:
        arr = np.asarray(effects[p], dtype=float)
        arr = arr[np.isfinite(arr)]
        mu_star = float(np.nanmean(np.abs(arr))) if arr.size else np.nan
        sigma   = float(np.nanstd(arr)) if arr.size else np.nan
        rows.append({"param": p, "mu_star": mu_star, "sigma": sigma, "n": int(arr.size)})

    df = pd.DataFrame(rows).sort_values("mu_star", ascending=False)
    df.to_csv(Path(base_outdir) / "morris_summary.csv", index=False)
    return df


def _sweep_impl(cfg: SweepConfig) -> pd.DataFrame:
    # optional project root for imports
    if cfg.project_root and cfg.project_root not in sys.path:
        sys.path.insert(0, cfg.project_root)

    # Imports here so the user can call this API from anywhere
    from generalized_simulation import run_simulation
    try:
        from generalized_diagnostics_metrics import compute_total_energy
    except Exception:
        compute_total_energy = None

    base = Path(cfg.base_outdir).resolve()
    base.mkdir(parents=True, exist_ok=True)

    keys = list(cfg.weight_values.keys())
    values_lists = [list(v) for v in cfg.weight_values.values()]
    combos = [dict(zip(keys, vals)) for vals in product(*values_lists)] if keys else [dict()]

    # Save manifest
    manifest = {"keys": keys, "values": {k: list(v) for k, v in cfg.weight_values.items()}, "steps": cfg.steps}
    with open(base / "sweep_manifest.json", "w") as f:
        json.dump(manifest, f, indent=2)

    def run_one(combo: Dict[str, float]) -> Dict[str, Any]:
        # params for a single run
        params: Dict[str, Any] = {}
        params.update(combo)
        params.update(cfg.params_extra or {})
        if cfg.steps is not None:
            params["steps"] = int(cfg.steps)

        params["logging"] = {
            "enable_scalar": bool(cfg.log_metrics),
            "enable_fields": bool(cfg.log_fields),
            "full_field_outdir": "fields",
            "pair_outdir": "pairs",
        }
        if cfg.seed is not None:
            params["seed"] = int(cfg.seed)

        tag = _slug_params(combo, keys)
        outdir = base / tag
        outdir.mkdir(parents=True, exist_ok=True)

        t0 = time.perf_counter()
        agents, metric_log = run_simulation(
            outdir=str(outdir),
            resume=False,
            log_metrics=bool(cfg.log_metrics),
            log_fields=bool(cfg.log_fields),
            num_cores=int(cfg.per_run_cores),
            params=params,
        )
        dt = time.perf_counter() - t0

        summary = {
            **combo,
            "run_outdir": str(outdir),
            "elapsed_sec": dt,
        }
        summary.update(_flatten_metric_log(metric_log))

        # compute final energy as a fallback
        if compute_total_energy is not None and "final_total_energy" not in summary:
            try:
                E_final = float(np.sum([
                    np.nanmean(compute_total_energy(a, agents, params=params))
                    for a in agents
                ]))
                summary["final_total_energy"] = E_final
            except Exception:
                pass

        # persist
        with open(outdir / "sweep_summary.json", "w") as f:
            json.dump(summary, f, indent=2)

        # optional callback
        if cfg.per_run_callback is not None:
            try:
                cfg.per_run_callback(summary, outdir, agents, metric_log)
            except Exception as e:
                print(f"[WARN] per_run_callback raised: {e}")

        return summary

    # Run
    if cfg.outer_jobs <= 1:
        summaries = [run_one(c) for c in combos]
    else:
        from joblib import Parallel, delayed
        summaries = Parallel(n_jobs=int(cfg.outer_jobs), backend="loky", verbose=10)(
            delayed(run_one)(c) for c in combos
        )

    df = pd.DataFrame(summaries)
    df.to_csv(base / "sweep_summary.csv", index=False)
    return df

if __name__ == "__main__":
    # Quick-start entry point for ratio-based experiments.
    # Set SWEEP_MODE to "lhs" (default) or "morris".
    import os
    from pathlib import Path

    MODE = os.environ.get("SWEEP_MODE", "morris").lower()

    # Reference weight and value (others are ratios to this in log10 space)
    REF_WEIGHT = "alpha"
    REF_VALUE  = 1.0

    ratio_bounds = {
    "beta": (-1.2, -0.3),              # ≈ 10^-1.2..10^-0.3 → 0.06..0.5   (zoom where your winners clustered)
    "beta_model": (-1.2, -0.3),         # 0.01..10          (broad, secondary)
    "entropy_weight": (-2.0, 3.0),     # 0.01..10          (broad, secondary)
    "model_curvature_weight": (-1.0, 4.0),  # 0.1..100     (broad, secondary)
    "curvature_weight": (-1.0, 4.0),  # 0.1..100     (broad, secondary)
    "model_mass": (-1.0, 3.0),       # 0.1..10
    "belief_mass": (-1.0, 3.0),       # 0.1..10
}  

    # Optional per-parameter base scale multipliers BEFORE applying ratios (usually leave as 1.0)
    base_scales = {
        # e.g., "curvature_weight": 0.1
    }

    # Common sim knobs
    steps         = 60
    per_run_cores = 8
    log_fields    = False
    log_metrics   = True
    seed          = 1234

    if MODE == "morris":
        outdir = "sweeps/morris_quick"
        Path(outdir).mkdir(parents=True, exist_ok=True)
        print(f"[INFO] Running Morris screening → {outdir}")

        # A light sensitivity pass: total runs ≈ trajectories × (1 + #params)
        sens = morris_screening(
            ratio_bounds   = ratio_bounds,
            trajectories   = 10,          # ~8*(k+1) runs; raise to 10–20 for more stability
            step           = 1.0,        # Δ = 1 decade
            ref_weight     = REF_WEIGHT,
            ref_value      = REF_VALUE,
            base_scales    = base_scales,
            steps          = steps,
            base_outdir    = outdir,
            per_run_cores  = per_run_cores,
            log_fields     = log_fields,
            log_metrics    = log_metrics,
            seed           = seed,
            params_extra   = {},         # e.g., {"N": 6}
            project_root   = None,
            metric_key     = "final_total_energy",
        )
        print(sens)
        print(f"[DONE] Morris summary → {Path(outdir) / 'morris_summary.csv'}")

    else:
        outdir = "sweeps/ratio_lhs_quick"
        Path(outdir).mkdir(parents=True, exist_ok=True)
        print(f"[INFO] Running ratio LHS sweep → {outdir}")

        # Latin hypercube in log10-ratio space (use 32–128 for serious runs)
        df = sweep_ratios_lhs(
            ratio_bounds   = ratio_bounds,
            n_samples      = 32,
            ref_weight     = REF_WEIGHT,
            ref_value      = REF_VALUE,
            base_scales    = base_scales,
            steps          = steps,
            base_outdir    = outdir,
            per_run_cores  = per_run_cores,
            outer_jobs     = 1,          # set >1 to parallelize runs (process-based)
            log_fields     = log_fields,
            log_metrics    = log_metrics,
            seed           = seed,
            params_extra   = {},         # e.g., {"N": 6}
            project_root   = None,
            per_run_callback = None,
        )
        print(df.head())
        print(f"[DONE] LHS sweep summary → {Path(outdir) / 'sweep_summary.csv'}")
