# -*- coding: utf-8 -*-
"""
Created on Sun Aug 10 13:33:30 2025

@author: chris and christine
"""
# --- top of file: remove duplicate imports and unused kl_divergence ---
import numpy as np
from bundle_morphism_utils import safe_batch_apply_morphism_nat
from numerical_utils import sanitize_sigma, safe_inv
from xscale_helpers import gaussian_pushforward_linear, compute_avg_crossscale_kl_p, compute_avg_crossscale_kl_q
from meta_gauge_fields import _hat3, so3_exp


def apply_crossscale_updates(agents, parents, labels, _cfg, step, log_every=10):
    """
    Run ALL cross-scale gradient updates (q + optional p) and do optional per-step logging.
    Returns a tiny dict of last-step CS metrics you can reuse in your metrics block.
    """
    cs = {}

    if parents is None or labels is None:
        return cs

    # --------- Q side (beliefs): Stage-1/2 ----------
    beta_up_q = _cfg("beta_up_q", 0.0)
    if beta_up_q > 0.0:
        xscale_q_up_step(
            agents, parents, labels,
            beta=beta_up_q,
            lr_mu=_cfg("xscale_lr_mu_q_up", 0.12),
            lr_sigma=_cfg("xscale_lr_sigma_q_up", 0.05),
            eps=1e-6, clip_mu=0.5, clip_S=0.25
        )

    beta_dn_q = _cfg("beta_dn_q", 0.0)
    if beta_dn_q > 0.0:
        xscale_q_dn_step(
            agents, parents, labels,
            beta=beta_dn_q,
            lr_mu=_cfg("xscale_lr_mu_q_dn", 0.08),
            lr_sigma=_cfg("xscale_lr_sigma_q_dn", 0.04),
            eps=1e-6
        )

    if (step % log_every) == 0:
        vals_q = compute_avg_crossscale_kl_q(agents, parents, labels, eps=1e-6)
        mean_q = float(np.nanmean(vals_q)) if np.size(vals_q) else float("nan")
        n_q = int(np.isfinite(vals_q).sum()) if np.size(vals_q) else 0
        print(f"[XSCALE] step {step}: mean KL(child||Λ_dn_q·parent) = {mean_q:.5f}  n={n_q}")
        cs["xscale_kl_q_mean"] = mean_q
        cs["xscale_kl_q_n"] = n_q

    # --------- P side (models): Stage-1/2 (optional) ----------
    if _cfg("enable_crossscale_p", False):
        beta_up_p = _cfg("beta_up_p", 0.0)
        if beta_up_p > 0.0:
            xscale_p_up_step(
                agents, parents, labels,
                beta=beta_up_p,
                lr_mu=_cfg("xscale_lr_mu_p_up", 0.10),
                lr_sigma=_cfg("xscale_lr_sigma_p_up", 0.05),
                eps=1e-6, clip_mu=0.5, clip_S=0.25
            )

        beta_dn_p = _cfg("beta_dn_p", 0.0)
        if beta_dn_p > 0.0:
            # ensure Λ_up_p exists (Fisher adjoint of Λ_dn_p) where dimensions match
            for P in parents:
                try:
                    Ldn = getattr(P, "Lambda_dn_p", None)
                    Lup = getattr(P, "Lambda_up_p", None)
                    if Ldn is not None and Lup is None:
                        Gc = estimate_fisher_metric_from_field(P.sigma_p_field, P.mask)  # child-side metric (approx.)
                        Gp = estimate_fisher_metric_from_field(P.sigma_p_field, P.mask)  # parent-side metric (approx.)
                        if Ldn.shape[-2] == Gc.shape[-1] and Ldn.shape[-1] == Gp.shape[-1]:
                            P.Lambda_up_p = fisher_adjoint(Ldn, Gc, Gp)
                except Exception:
                    pass

            xscale_p_dn_step(
                agents, parents, labels,
                beta=beta_dn_p,
                lr_mu=_cfg("xscale_lr_mu_p_dn", 0.08),
                lr_sigma=_cfg("xscale_lr_sigma_p_dn", 0.04),
                eps=1e-6
            )

        if (step % log_every) == 0:
            vals_p = compute_avg_crossscale_kl_p(agents, parents, labels, eps=1e-6)
            mean_p = float(np.nanmean(vals_p)) if np.size(vals_p) else float("nan")
            n_p = int(np.isfinite(vals_p).sum()) if np.size(vals_p) else 0
            print(f"[XSCALE:P] step {step}: mean KL(child||Λ̃_dn_p·parent) = {mean_p:.5f}  n={n_p}")
            cs["xscale_kl_p_mean"] = mean_p
            cs["xscale_kl_p_n"] = n_p

    return cs


def left_jacobian_so3(phi, eps=1e-8):
    # phi: (...,3)
    theta = np.linalg.norm(phi, axis=-1, keepdims=True)
    K = _hat3(phi / np.maximum(theta, eps))
    th  = theta[...,0]
    th2 = th*th
    A = np.where(th < 1e-4, 1 - th2/6 + th2*th2/120, np.sin(th)/th)
    B = np.where(th < 1e-4, 0.5 - th2/24 + th2*th2/720, (1 - np.cos(th))/(th2 + eps))
    I = np.eye(3, dtype=phi.dtype)
    return I + B[...,None,None]*K + ((1 - A)[...,None,None]/(th2[...,None,None] + eps)) * (K @ K)

def left_jacobian_so3_inv(phi, eps=1e-8):
    # closed form inverse of J_l
    theta = np.linalg.norm(phi, axis=-1, keepdims=True)
    K = _hat3(phi / np.maximum(theta, eps))
    th = theta[...,0]
    half = 0.5
    cot = np.where(th < 1e-4, 1/th - th/3 - th**3/45, 0.5*th/np.tan(0.5*th))
    I = np.eye(3, dtype=phi.dtype)
    return I - half*K + ((1 - cot*2/ th)[...,None,None]) * (K @ K)  # numerically safe form



# --- Fisher-adjoint utilities (p- and q- side) ---

def estimate_fisher_metric_from_field(S_field, mask, eps=1e-6):
    """
    G ≈ E[Σ^{-1}] over the mask. Returns (K,K).
    """
    S = sanitize_sigma(S_field, eps=eps)
    S_inv = safe_inv(S, eps=eps)                            # (H,W,K,K)
    w = mask[..., None, None].astype(S.dtype)               # (H,W,1,1)
    num = np.sum(w * S_inv, axis=(0, 1))                    # (K,K)
    den = np.sum(w, axis=(0, 1)) + eps                      # (1,1)
    G = num / den
    return sanitize_sigma(G, eps=eps)

def fisher_adjoint(L_dn, G_child, G_parent, eps=1e-6):
    """
    Λ_up = G_parent^{-1} Λ_dn^T G_child  (works for q or p side)
    Shapes:
      L_dn: (K_child, K_parent)
      G_child: (K_child, K_child)
      G_parent: (K_parent, K_parent)
    """
    return safe_inv(G_parent, eps=eps) @ L_dn.swapaxes(-1, -2) @ G_child




def xscale_q_up_step(children, parents, labels,
                     beta=0.2, lr_mu=0.1, lr_sigma=0.05, eps=1e-6,
                     clip_mu=None, clip_S=None):
    """
    One gradient step: minimize KL(q_child || Λ_dn_q · q_parent).
    Updates CHILD (μ_q, Σ_q) only. Λ fields are treated as fixed.
    """
    labels = np.asarray(labels)
    for ci, c in enumerate(children):
        pid = int(labels[ci]) if labels[ci] >= 0 else -1
        if pid < 0:
            continue
        p = parents[pid]

        Kq = c.mu_q_field.shape[-1]
        L = getattr(p, "Lambda_dn_q", None)
        if L is None:
            L_field = np.broadcast_to(np.eye(Kq, dtype=c.mu_q_field.dtype),
                                      c.mu_q_field.shape[:2] + (Kq, Kq))
        else:
            L = np.asarray(L)
            L_field = np.broadcast_to(L, c.mu_q_field.shape[:2] + L.shape) if L.ndim == 2 else L

        mu_t, S_t = safe_batch_apply_morphism_nat(p.mu_q_field, p.sigma_q_field, L_field, eps=eps)
        mu_c, S_c = c.mu_q_field, sanitize_sigma(c.sigma_q_field, eps=eps)
        S_t = sanitize_sigma(S_t, eps=eps)

        S_t_inv = safe_inv(S_t, eps=eps)
        S_c_inv = safe_inv(S_c, eps=eps)

        # grads: KL(N(μc,Sc) || N(μt,St))
        g_mu = np.einsum('...ij,...j->...i', S_t_inv, (mu_c - mu_t))
        g_S  = 0.5 * (S_t_inv - S_c_inv)

        m = ((c.mask > eps) & (p.mask > eps))[..., None]        # (H,W,1)
        mS = m[..., None]                                       # (H,W,1,1)
        dmu = -beta * lr_mu    * g_mu * m
        dS  = -beta * lr_sigma * g_S  * mS

        if clip_mu is not None: dmu = np.clip(dmu, -clip_mu, clip_mu)
        if clip_S  is not None: dS  = np.clip(dS,  -clip_S,  clip_S)

        S_new = sanitize_sigma(0.5*(S_c + dS + np.swapaxes(S_c + dS, -1, -2)), eps=eps)

        c.mu_q_field    = mu_c + dmu
        c.sigma_q_field = S_new



def xscale_q_dn_step(children, parents, labels,
                     beta=0.2, lr_mu=0.08, lr_sigma=0.04, eps=1e-6):
    """
    Parent step: push children UP via Λ_up_q, average (mask-weighted),
    then descend KL(q_parent || target).
    """
    labels = np.asarray(labels)

    # group child indices by parent id
    parent_to_kids = {}
    for ci, pid in enumerate(labels):
        if pid >= 0:
            parent_to_kids.setdefault(int(pid), []).append(ci)

    for pid, kid_ids in parent_to_kids.items():
        if not kid_ids:
            continue
        p = parents[pid]
        H, W, K = p.mu_q_field.shape

        L = getattr(p, "Lambda_up_q", None)
        if L is None:
            L_field = np.broadcast_to(np.eye(K, dtype=p.mu_q_field.dtype), (H, W, K, K))
        else:
            L = np.asarray(L)
            L_field = np.broadcast_to(L, (H, W) + L.shape) if L.ndim == 2 else L

        mu_acc = np.zeros((H, W, K),   dtype=p.mu_q_field.dtype)
        S_acc  = np.zeros((H, W, K, K), dtype=p.sigma_q_field.dtype)
        w_sum  = np.zeros((H, W, 1),    dtype=p.mu_q_field.dtype)

        for ci in kid_ids:
            c = children[ci]
            mu_u, S_u = safe_batch_apply_morphism_nat(c.mu_q_field, c.sigma_q_field, L_field, eps=eps)
            w = c.mask[..., None]
            mu_acc += w * mu_u
            S_acc  += w[..., None] * S_u
            w_sum  += w

        w_safe = np.maximum(w_sum, eps)
        mu_t = mu_acc / w_safe
        S_t  = sanitize_sigma(S_acc / w_safe[..., None], eps=eps)

        mu_p = p.mu_q_field
        S_p  = sanitize_sigma(p.sigma_q_field, eps=eps)
        S_t_inv = safe_inv(S_t, eps=eps)
        S_p_inv = safe_inv(S_p, eps=eps)

        g_mu = np.einsum('...ij,...j->...i', S_t_inv, (mu_p - mu_t))
        g_S  = 0.5 * (S_t_inv - S_p_inv)

        m  = (p.mask > eps)[..., None]
        mS = m[..., None]
        dmu = -beta * lr_mu    * g_mu * m
        dS  = -beta * lr_sigma * g_S  * mS

        S_new = sanitize_sigma(0.5*(S_p + dS + np.swapaxes(S_p + dS, -1, -2)), eps=eps)

        p.mu_q_field    = mu_p + dmu
        p.sigma_q_field = S_new



def xscale_p_up_step(children, parents, labels,
                     beta=0.2, lr_mu=0.1, lr_sigma=0.05,
                     eps=1e-6, clip_mu=None, clip_S=None):
    """
    Child update toward Λ_dn_p · parent.p  (Stage-1, model side).
    """
    labels = np.asarray(labels)
    for ci, c in enumerate(children):
        pid = int(labels[ci]) if labels[ci] >= 0 else -1
        if pid < 0: continue
        p = parents[pid]

        Kp = c.mu_p_field.shape[-1]
        L = getattr(p, "Lambda_dn_p", None)
        if L is None:
            L_field = np.broadcast_to(np.eye(Kp, dtype=c.mu_p_field.dtype),
                                      c.mu_p_field.shape[:2] + (Kp, Kp))
        else:
            L = np.asarray(L)
            L_field = np.broadcast_to(L, c.mu_p_field.shape[:2] + L.shape) if L.ndim == 2 else L

        mu_t, S_t = gaussian_pushforward_linear(p.mu_p_field, sanitize_sigma(p.sigma_p_field, eps=eps), L_field)
        mu_c, S_c = c.mu_p_field, sanitize_sigma(c.sigma_p_field, eps=eps)
        S_t = sanitize_sigma(S_t, eps=eps)

        S_t_inv = safe_inv(S_t, eps=eps)
        S_c_inv = safe_inv(S_c, eps=eps)

        g_mu = np.einsum('...ij,...j->...i', S_t_inv, (mu_c - mu_t))
        g_S  = 0.5 * (S_t_inv - S_c_inv)

        m  = ((c.mask > eps) & (p.mask > eps))[..., None]
        mS = m[..., None]
        dmu = -beta * lr_mu    * g_mu * m
        dS  = -beta * lr_sigma * g_S  * mS

        if clip_mu is not None: dmu = np.clip(dmu, -clip_mu, clip_mu)
        if clip_S  is not None: dS  = np.clip(dS,  -clip_S,  clip_S)

        S_new = sanitize_sigma(0.5*(S_c + dS + np.swapaxes(S_c + dS, -1, -2)), eps=eps)
        c.mu_p_field    = mu_c + dmu
        c.sigma_p_field = S_new


def xscale_p_dn_step(children, parents, labels,
                     beta=0.2, lr_mu=0.08, lr_sigma=0.04, eps=1e-6):
    """
    Parent update toward masked average of Λ_up_p · child.p (Stage-2, model side).
    """
    labels = np.asarray(labels)
    parent_to_kids = {}
    for ci, pid in enumerate(labels):
        if pid >= 0:
            parent_to_kids.setdefault(int(pid), []).append(ci)

    for pid, kid_ids in parent_to_kids.items():
        if not kid_ids: continue
        p = parents[pid]
        H, W, K = p.mu_p_field.shape

        L = getattr(p, "Lambda_up_p", None)
        if L is None:
            L_field = np.broadcast_to(np.eye(K, dtype=p.mu_p_field.dtype), (H, W, K, K))
        else:
            L = np.asarray(L)
            L_field = np.broadcast_to(L, (H, W) + L.shape) if L.ndim == 2 else L

        mu_acc = np.zeros((H, W, K),   dtype=p.mu_p_field.dtype)
        S_acc  = np.zeros((H, W, K, K), dtype=p.sigma_p_field.dtype)
        w_sum  = np.zeros((H, W, 1),    dtype=p.mu_p_field.dtype)

        for ci in kid_ids:
            c = children[ci]
            mu_u, S_u = gaussian_pushforward_linear(c.mu_p_field, sanitize_sigma(c.sigma_p_field, eps=eps), L_field)
            w = c.mask[..., None]
            mu_acc += w * mu_u
            S_acc  += w[..., None] * S_u
            w_sum  += w

        w_safe = np.maximum(w_sum, eps)
        mu_t = mu_acc / w_safe
        S_t  = sanitize_sigma(S_acc / w_safe[..., None], eps=eps)

        mu_p = p.mu_p_field
        S_p  = sanitize_sigma(p.sigma_p_field, eps=eps)
        S_t_inv = safe_inv(S_t, eps=eps)
        S_p_inv = safe_inv(S_p, eps=eps)

        g_mu = np.einsum('...ij,...j->...i', S_t_inv, (mu_p - mu_t))
        g_S  = 0.5 * (S_t_inv - S_p_inv)

        m  = (p.mask > eps)[..., None]
        mS = m[..., None]
        dmu = -beta * lr_mu    * g_mu * m
        dS  = -beta * lr_sigma * g_S  * mS

        S_new = sanitize_sigma(0.5*(S_p + dS + np.swapaxes(S_p + dS, -1, -2)), eps=eps)
        p.mu_p_field    = mu_p + dmu
        p.sigma_p_field = S_new



def vee3(S):
    # S ~ skew; returns (3,)
    return np.array([S[2,1], S[0,2], S[1,0]], dtype=S.dtype)

def grad_step_parent_phi_from_crossscale_p(children, parents, labels, lr_phi=0.02, eps=1e-6):
    """
    One gradient step on the parent gauge field φ_{i+1} (model side) to reduce
    KL( p_child || (Λ̃)_# p_parent ), with Λ̃ = exp(φ_child) exp(-φ_parent).
    """
    labels = np.asarray(labels)
    for pid, P in enumerate(parents):
        pmask = getattr(P, "mask", None)
        if pmask is None:
            continue

        # accumulate Lie-algebra gradient across overlap pixels and assigned children
        G_alg = np.zeros((3,), dtype=np.float64)
        count = 0

        for ci, lab in enumerate(labels):
            if int(lab) != pid: 
                continue
            c = children[ci]

            M = (c.mask > eps) & (pmask > eps)
            if not np.any(M): 
                continue

            # fields on overlap (sanitize covs)
            mu_c = c.mu_p_field[M]
            S_c  = sanitize_sigma(c.sigma_p_field, eps=eps)[M]
            mu_p = P.mu_p_field[M]
            S_p  = sanitize_sigma(P.sigma_p_field, eps=eps)[M]

            # rotations
            Rc = so3_exp(c.phi_model.reshape(-1,3)).reshape(*c.phi_model.shape[:2],3,3)[M]
            Rp = so3_exp(P.phi_model.reshape(-1,3)).reshape(*P.phi_model.shape[:2],3,3)[M]
            L  = Rc @ np.swapaxes(Rp, -1, -2)

            # pushforward stats
            mu_t = np.einsum('nij,nj->ni', L, mu_p)
            S_t  = np.einsum('nik,nkl,njl->nij', L, S_p, L)

            S_t  = sanitize_sigma(S_t, eps=eps)
            S_ti = safe_inv(S_t, eps=eps)

            dmu   = (mu_t - mu_c)
            dKL_dmt = np.einsum('nij,nj->ni', S_ti, dmu)
            term = np.einsum('nij,njk,nkl->nil', S_ti, S_c, S_ti) + \
                   np.einsum('ni,nj->nij', dmu, dmu)
            dKL_dSt = 0.5 * (S_ti - np.einsum('nij,njk->nik', S_ti, term) @ S_ti)

            G_L = np.einsum('ni,nj->ij', dKL_dmt, mu_p) + \
                  2.0 * np.einsum('nij,jk,nkl->il', dKL_dSt, np.mean(L,axis=0), np.mean(S_p,axis=0))

            # B = R_c^T G_L R_p (average Rc/Rp over this overlap)
            Rc_mean = np.mean(Rc, axis=0)
            Rp_mean = np.mean(Rp, axis=0)
            B = Rc_mean.T @ G_L @ Rp_mean

            Sskew = 0.5 * (B - B.T)
            G_alg += vee3(Sskew)
            count += 1

        if count == 0:
            continue

        g = (G_alg / max(count,1)).astype(np.float64)
        JinvT = left_jacobian_so3_inv(P.phi_model.mean(axis=(0,1)))[..., :,:].T  # coarse proxy
        # update: φ_parent ← φ_parent - lr * J_l^{-T} * g  (broadcast to field; mask it)
        delta = (JinvT @ g).astype(np.float32)
        P.phi_model[pmask] = P.phi_model[pmask] - delta  # simple masked update; or spread per-pixel if you computed per-pixel g



