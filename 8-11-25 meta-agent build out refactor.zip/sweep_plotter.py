
from __future__ import annotations
from pathlib import Path
from typing import Dict, List, Optional

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

def load_sweep(base_outdir: str | Path) -> pd.DataFrame:
    base = Path(base_outdir)
    df = pd.read_csv(base / "sweep_summary.csv")
    df = df.replace([np.inf, -np.inf], np.nan)
    if "final_total_energy" in df.columns:
        df = df.dropna(subset=["final_total_energy"])
    return df

def _ensure_outdir(p: str | Path) -> Path:
    p = Path(p)
    p.mkdir(parents=True, exist_ok=True)
    return p

def plot_scatter_energy_vs_runtime(df: pd.DataFrame, outdir: str | Path, metric: str = "final_total_energy") -> Path:
    outdir = _ensure_outdir(outdir)
    if metric not in df.columns or "elapsed_sec" not in df.columns:
        return outdir / "scatter_energy_runtime_skipped.txt"
    plt.figure()
    x = df[metric].to_numpy()
    y = df["elapsed_sec"].to_numpy()
    plt.scatter(x, y, s=12, alpha=0.8)
    plt.xlabel(metric)
    plt.ylabel("elapsed_sec")
    plt.title("Energy vs Runtime (all runs)")
    plt.tight_layout()
    fp = outdir / "scatter_energy_vs_runtime.png"
    plt.savefig(fp, dpi=150)
    plt.close()
    return fp

def plot_topk_table(df: pd.DataFrame, outdir: str | Path, metric: str = "final_total_energy", k: int = 25) -> Path:
    outdir = _ensure_outdir(outdir)
    cols = [c for c in df.columns if c in (
        "alpha","beta","beta_model","feedback_weight",
        "curvature_weight","model_curvature_weight",
        "fisher_geometry_weight","fisher_model_geometry_weight",
        "belief_mass","model_mass","phi_coupling_weight",
        "entropy_weight",
        metric,"elapsed_sec","run_outdir"
    )]
    dff = df.replace([np.inf, -np.inf], np.nan).dropna(subset=[metric]).sort_values(metric, kind="mergesort").head(k)
    dff[cols].to_csv(outdir / "topk_runs.csv", index=False)
    return outdir / "topk_runs.csv"

def plot_parallel_coordinates(df: pd.DataFrame, outdir: str | Path, weight_keys: List[str],
                              metric: str = "final_total_energy", max_lines: int = 1000) -> Path:
    outdir = _ensure_outdir(outdir)
    dff = df.dropna(subset=[metric]).copy()
    cols = [k for k in weight_keys if k in dff.columns] + [metric]
    if len(cols) < 2:
        return outdir / "parallel_coords_skipped.txt"
    X = dff[cols].to_numpy(dtype=float)
    mins = np.nanmin(X, axis=0); maxs = np.nanmax(X, axis=0)
    denom = np.maximum(maxs - mins, 1e-12)
    Xn = (X - mins) / denom
    order = np.argsort(X[:, -1]); Xn = Xn[order]
    if Xn.shape[0] > max_lines:
        stride = int(np.ceil(Xn.shape[0] / max_lines)); Xn = Xn[::stride]
    plt.figure()
    for row in Xn:
        plt.plot(range(len(cols)), row, linewidth=0.6, alpha=0.6)
    plt.xticks(range(len(cols)), cols, rotation=30, ha="right")
    plt.yticks([0,0.5,1], ["min","mid","max"])
    plt.title("Parallel Coordinates (normalized)")
    plt.tight_layout()
    fp = outdir / "parallel_coordinates.png"
    plt.savefig(fp, dpi=150)
    plt.close()
    return fp

def _pivot_agg(df: pd.DataFrame, x: str, y: str, metric: str, agg: str = "median") -> pd.DataFrame:
    dff = df[[x, y, metric]].dropna(subset=[metric]).copy()
    func = {"min": np.nanmin, "max": np.nanmax, "mean": np.nanmean, "median": np.nanmedian}.get(agg, np.nanmedian)
    vals = dff.groupby([x, y])[metric].agg(func).reset_index()
    piv = vals.pivot(index=y, columns=x, values=metric)
    return piv

def plot_pair_heatmap(df: pd.DataFrame, outdir: str | Path, x: str, y: str,
                      metric: str = "final_total_energy", agg: str = "median",
                      filters: Optional[Dict[str, float]] = None) -> Path:
    outdir = _ensure_outdir(outdir)
    dff = df.copy()
    if filters:
        for k,v in filters.items():
            if k in dff.columns:
                dff = dff[dff[k] == v]
    if x not in dff.columns or y not in dff.columns or metric not in dff.columns:
        return outdir / f"heatmap_{y}_vs_{x}_skipped.txt"
    piv = _pivot_agg(dff, x, y, metric, agg=agg)
    if piv.size == 0:
        return outdir / f"heatmap_{y}_vs_{x}_empty.txt"
    Xvals = np.array(piv.columns.tolist()); Yvals = np.array(piv.index.tolist()); Z = piv.to_numpy()
    plt.figure()
    im = plt.imshow(Z, aspect="auto", origin="lower",
                    extent=[Xvals.min(), Xvals.max(), Yvals.min(), Yvals.max()])
    plt.colorbar(im)
    plt.xlabel(x); plt.ylabel(y)
    plt.title(f"{metric} ({agg}) — {y} vs {x}")
    plt.tight_layout()
    fp = outdir / f"heatmap_{y}_vs_{x}.png"
    plt.savefig(fp, dpi=150); plt.close()
    return fp

def generate_default_report(base_outdir: str | Path,
                            weight_keys: List[str],
                            metric: str = "final_total_energy") -> List[Path]:
    base = Path(base_outdir)
    outdir = _ensure_outdir(base / "sweep_reports")
    df = load_sweep(base)
    paths = []
    paths.append(plot_scatter_energy_vs_runtime(df, outdir, metric=metric))
    paths.append(plot_topk_table(df, outdir, metric=metric, k=25))
    paths.append(plot_parallel_coordinates(df, outdir, weight_keys=weight_keys, metric=metric, max_lines=1500))
    candidate_pairs = [
        ("alpha", "beta"),
        ("alpha", "beta_model"),
        ("beta", "entropy_weight"),
        ("alpha", "entropy_weight"),
        ("curvature_weight", "alpha"),
        ("model_curvature_weight", "beta"),
        ("belief_mass", "alpha"),
        ("model_mass", "beta"),
    ]
    for x,y in candidate_pairs:
        if x in df.columns and y in df.columns:
            try:
                paths.append(plot_pair_heatmap(df, outdir, x=x, y=y, metric=metric, agg="median", filters=None))
            except Exception:
                pass
    return [p for p in paths if isinstance(p, Path)]

if __name__ == "__main__":
    # CHANGE this path to point to your sweep output directory
    BASE = "sweeps/_quick_run"

    # List the weights you want in the parallel coordinates plot
    WEIGHT_KEYS = [
        "alpha", "beta", "beta_model", "curvature_weight",
        "belief_mass", "model_mass", "model_curvature_weight", "entropy_weight"
    ]

    print(f"[INFO] Generating report for sweep at {BASE}...")
    paths = generate_default_report(BASE, WEIGHT_KEYS, metric="final_total_energy")
    print(f"[DONE] Generated {len(paths)} report files:")
    for p in paths:
        print(f" - {p}")
