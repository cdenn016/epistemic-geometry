from dataclasses import dataclass, field
from typing import Any, Dict, List, Tuple, Optional
import numpy as np

@dataclass
class Agent:
    id: int
    center: Tuple[int, ...]
    radius: float
    mask: np.ndarray

    # Lie fields
    phi: np.ndarray
    phi_model: np.ndarray

    # Belief/model fields
    mu_q_field: np.ndarray
    sigma_q_field: np.ndarray
    mu_p_field: np.ndarray
    sigma_p_field: np.ndarray

    # Inverses (filled in preprocess)
    sigma_q_inv: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    sigma_p_inv: Optional[np.ndarray] = field(default=None, init=False, repr=False)

    # Neighborhood & logging
    neighbors: List[Dict[str, Any]] = field(default_factory=list)
    metrics_log: List[Dict[str, Any]] = field(default_factory=list)

    # Gradient caches
    grad_mu_q: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    grad_sigma_q: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    grad_mu_p: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    grad_sigma_p: Optional[np.ndarray] = field(default=None, init=False, repr=False)

    # Generators (prefer set once and reused)
    generators_q: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    generators_p: Optional[np.ndarray] = field(default=None, init=False, repr=False)

    # exp(φ) caches
    _exp_phi: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    _exp_neg_phi: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    _exp_phi_model: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    _exp_neg_phi_model: Optional[np.ndarray] = field(default=None, init=False, repr=False)

    # Inter-agent transport caches
    Omega_cache: Dict[str, Any] = field(default_factory=dict, init=False, repr=False)
    Omega_tilde_cache: Dict[str, Any] = field(default_factory=dict, init=False, repr=False)

    # Morphisms
    bundle_morphism_q_to_p: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    bundle_morphism_p_to_q: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    Phi_0: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    Phi_tilde_0: Optional[np.ndarray] = field(default=None, init=False, repr=False)

    # φ/φ̃ grads (field-shaped)
    grad_phi: np.ndarray = field(init=False, repr=False)
    grad_phi_tilde: np.ndarray = field(init=False, repr=False)

    # Morphism grads (optional)
    grad_Phi: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    grad_Phi_tilde: Optional[np.ndarray] = field(default=None, init=False, repr=False)

    # Fisher caches for φ/φ̃ or morphisms
    inverse_fisher_phi: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    inverse_fisher_phi_model: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    inverse_fisher_Phi: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    inverse_fisher_Phi_tilde: Optional[np.ndarray] = field(default=None, init=False, repr=False)

    # Diagnostics / pullbacks (optional)
    fisher_I: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    pull_M_vis: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    pull_Delta: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    pull_M_dark: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    spatial_G: Optional[np.ndarray] = field(default=None, init=False, repr=False)

    # NEW: adaptive-η & KL caches
    _cond_proxy_q: Optional[float] = field(default=None, init=False, repr=False)
    _cond_proxy_p: Optional[float] = field(default=None, init=False, repr=False)
    _eta_phi_prev: Optional[float]   = field(default=None, init=False, repr=False)
    _eta_phi_m_prev: Optional[float] = field(default=None, init=False, repr=False)
    cached_alignment_kl: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    cached_model_alignment_kl: Optional[np.ndarray] = field(default=None, init=False, repr=False)


        # Cross-scale metadata
    level: int = 0
    parent_ids: List[int] = field(default_factory=list)
    child_ids: List[int] = field(default_factory=list)
    
    # Cross-scale same-fiber maps (Λ). Optional; attach at runtime or seed here.
    Lambda_up_q: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    Lambda_dn_q: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    Lambda_up_p: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    Lambda_dn_p: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    
    # Cross-scale cross-bundle maps (Θ)
    Theta_up: Optional[np.ndarray] = field(default=None, init=False, repr=False)   # (K_p, K_q)
    Theta_dn: Optional[np.ndarray] = field(default=None, init=False, repr=False)   # (K_q, K_p)
    
    # Optional gradients for cross-scale maps (only if/when you learn them)
    grad_Lambda_up_q: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    grad_Lambda_dn_q: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    grad_Lambda_up_p: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    grad_Lambda_dn_p: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    grad_Theta_up: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    grad_Theta_dn: Optional[np.ndarray] = field(default=None, init=False, repr=False)




    def __post_init__(self):
        self.grad_phi = np.zeros_like(self.phi)
        self.grad_phi_tilde = np.zeros_like(self.phi_model)
        if self.bundle_morphism_q_to_p is not None:
            self.grad_Phi = np.zeros_like(self.bundle_morphism_q_to_p)
        if self.bundle_morphism_p_to_q is not None:
            self.grad_Phi_tilde = np.zeros_like(self.bundle_morphism_p_to_q)

    @property
    def grid_shape(self) -> Tuple[int, ...]:
        return self.mu_q_field.shape[:-1]

    @property
    def Omega(self) -> np.ndarray:
        K = self.mu_q_field.shape[-1]
        return self._exp_phi.reshape(*self.grid_shape, K, K)

    @property
    def Omega_inv(self) -> np.ndarray:
        K = self.mu_q_field.shape[-1]
        return self._exp_neg_phi.reshape(*self.grid_shape, K, K)

    @property
    def Omega_model(self) -> np.ndarray:
        K = self.mu_p_field.shape[-1]
        return self._exp_phi_model.reshape(*self.grid_shape, K, K)

    @property
    def Omega_model_inv(self) -> np.ndarray:
        K = self.mu_p_field.shape[-1]
        return self._exp_neg_phi_model.reshape(*self.grid_shape, K, K)

    def log_metrics(self, step: int, stats: Dict[str, Any]) -> None:
        import copy
        self.metrics_log.append(copy.deepcopy({'step': step, **stats}))

    def clear_omega_cache(self) -> None:
        self._exp_phi = None
        self._exp_neg_phi = None
        self._exp_phi_model = None
        self._exp_neg_phi_model = None
        self.Omega_cache.clear()
        self.Omega_tilde_cache.clear()

    def clear_diagnostics(self) -> None:
        self.fisher_I = None
        self.pull_M_vis = None
        self.pull_Delta = None
        self.pull_M_dark = None
        self.spatial_G = None

    def clear_fisher_caches(self) -> None:
        self.inverse_fisher_phi = None
        self.inverse_fisher_phi_model = None
        self.inverse_fisher_Phi = None
        self.inverse_fisher_Phi_tilde = None

    def ensure_crossscale_defaults(self, Kq: int, Kp: int) -> None:
        if self.Lambda_up_q is None:
            self.Lambda_up_q = np.eye(Kq)
            self.Lambda_dn_q = np.eye(Kq)
        if self.Lambda_up_p is None:
            self.Lambda_up_p = np.eye(Kp)
            self.Lambda_dn_p = np.eye(Kp)
        if self.Theta_up is None:
            self.Theta_up = np.zeros((Kp, Kq))
            self.Theta_dn = np.zeros((Kq, Kp))

    def ensure_crossscale_grad_buffers(self) -> None:
        if self.Lambda_up_q is not None and self.grad_Lambda_up_q is None:
            self.grad_Lambda_up_q = np.zeros_like(self.Lambda_up_q)
            self.grad_Lambda_dn_q = np.zeros_like(self.Lambda_dn_q)
        if self.Lambda_up_p is not None and self.grad_Lambda_up_p is None:
            self.grad_Lambda_up_p = np.zeros_like(self.Lambda_up_p)
            self.grad_Lambda_dn_p = np.zeros_like(self.Lambda_dn_p)
        if self.Theta_up is not None and self.grad_Theta_up is None:
            self.grad_Theta_up = np.zeros_like(self.Theta_up)
            self.grad_Theta_dn = np.zeros_like(self.Theta_dn)
