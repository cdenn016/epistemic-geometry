
"""
promote_sweep_winners.py
Utilities to:
  1) Load a sweep_summary.csv.
  2) Select Pareto-efficient winners (final_total_energy vs elapsed_sec).
  3) Promote top-K winners into a longer, higher-fidelity sweep (with optional GIFs).

No CLI. Import and call from your notebook or script.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Tuple

import numpy as np
import pandas as pd

# Local import (programmatic sweeper)
from weights_sweeper import sweep_weights


# ------------------------------ Load & filter ------------------------------

def load_sweep_df(base_outdir: str | Path) -> pd.DataFrame:
    """Load <base_outdir>/sweep_summary.csv and basic-clean it."""
    base = Path(base_outdir)
    df = pd.read_csv(base / "sweep_summary.csv")
    # standard tidy-up
    df = df.replace([np.inf, -np.inf], np.nan)
    # prefer to keep rows that have final_total_energy
    if "final_total_energy" in df.columns:
        df = df.dropna(subset=["final_total_energy"])
    return df


def pareto_front(df: pd.DataFrame, x: str = "final_total_energy", y: str = "elapsed_sec") -> pd.DataFrame:
    """
    Return Pareto-efficient rows (minimize x and y).
    Complexity O(n^2) but fine for small sweeps.
    """
    if x not in df.columns or y not in df.columns:
        return df.copy()

    vals = df[[x, y]].to_numpy()
    keep = np.ones(len(df), dtype=bool)
    for i, p in enumerate(vals):
        if not keep[i]:
            continue
        dominates = (vals[:, 0] <= p[0]) & (vals[:, 1] <= p[1])
        strictly_better = (vals[:, 0] < p[0]) | (vals[:, 1] < p[1])
        keep = keep & ~(dominates & strictly_better)
        keep[i] = True  # keep current point
    return df[keep].copy()


# ------------------------------ Promotion runner ------------------------------

WEIGHT_KEYS = [
    "alpha", "beta", "feedback_weight",
    "curvature_weight", "model_curvature_weight",
    "fisher_geometry_weight", "fisher_model_geometry_weight",
    "belief_mass", "model_mass",
    "phi_coupling_weight",
]

def _weights_from_rows(df: pd.DataFrame) -> Dict[str, List[float]]:
    """
    Build weight_values dict from a small subset of rows (unique values per key).
    Only includes keys present in df columns.
    """
    vals: Dict[str, List[float]] = {}
    for k in WEIGHT_KEYS:
        if k in df.columns:
            uniq = sorted(set(df[k].dropna().tolist()))
            if len(uniq) > 0:
                vals[k] = uniq
    return vals


def promote_top_k(
    base_outdir: str | Path,
    top_k: int = 3,
    long_steps: int = 200,
    per_run_cores: int = 4,
    outer_jobs: int = 1,
    log_fields: bool = True,
    log_metrics: bool = True,
    seed: Optional[int] = 1234,
    use_pareto: bool = True,
    params_extra: Optional[dict] = None,
    do_gifs: bool = False,
) -> pd.DataFrame:
    """
    Promote the best K weight combos from a sweep into a longer run.

    - Uses Pareto front by default (energy vs runtime), then takes the K lowest-energy rows.
    - Re-runs those unique weight combinations with more steps and (optionally) field dumps.
    - If do_gifs=True and an animator module is available, attempts to create GIFs per run.

    Returns:
        DataFrame of promoted runs' summaries.
    """
    base = Path(base_outdir).resolve()
    df = load_sweep_df(base)

    if df.empty:
        raise FileNotFoundError(f"No rows in {base/'sweep_summary.csv'}")

    # Filter to Pareto-efficient if requested
    if use_pareto:
        pdf = pareto_front(df)
    else:
        pdf = df.copy()

    # Now sort by energy and take top_k
    if "final_total_energy" in pdf.columns:
        winners = pdf.sort_values("final_total_energy", kind="mergesort").head(top_k).copy()
    else:
        # fallback: sort by elapsed_sec
        winners = pdf.sort_values("elapsed_sec", kind="mergesort").head(top_k).copy()

    # Build weight grid from these top rows
    weight_values = _weights_from_rows(winners)

    # Promote dir
    promoted_out = base / "promoted"
    promoted_out.mkdir(parents=True, exist_ok=True)

    # Run promoted
    df2 = sweep_weights(
        weight_values=weight_values,
        steps=long_steps,
        base_outdir=str(promoted_out),
        per_run_cores=per_run_cores,
        outer_jobs=outer_jobs,
        log_fields=log_fields,
        log_metrics=log_metrics,
        seed=seed,
        params_extra=params_extra or {},
    )

    # Optional: try to make GIFs for each promoted run
    if do_gifs:
        try:
            from animator import run_gif_suite  # user-provided module
            for _, row in df2.iterrows():
                run_dir = Path(row["run_outdir"])
                try:
                    run_gif_suite(checkpoints_dir=str(run_dir / "checkpoints"), outdir=str(run_dir / "gifs"))
                except TypeError:
                    # Different signature; try minimal form
                    run_gif_suite(str(run_dir / "checkpoints"), str(run_dir / "gifs"))
                except Exception as e:
                    print(f"[WARN] GIFs failed for {run_dir}: {e}")
        except Exception:
            print("[INFO] animator.run_gif_suite not available; skipping GIFs.")

    return df2


if __name__ == "__main__":
    # Minimal non-CLI entry point: promote top-K winners from a previous sweep.
    BASE = "sweeps/_quick_run"  # change to your sweep outdir root

    try:
        df = load_sweep_df(BASE)
    except Exception as e:
        print(f"[ERR] Could not load {BASE}/sweep_summary.csv: {e}")
        print("Tip: run a sweep first (e.g., the __main__ block in weights_sweeper_api.py).")
        raise SystemExit(1)

    print(f"[INFO] Loaded {len(df)} rows from {BASE}/sweep_summary.csv")
    pareto = pareto_front(df)
    print(f"[INFO] Pareto kept {len(pareto)} rows")

    df_promoted = promote_top_k(
        base_outdir=BASE,
        top_k=3,
        long_steps=200,
        per_run_cores=4,
        outer_jobs=1,
        log_fields=True,      # dump fields for inspection
        log_metrics=True,
        seed=1234,
        use_pareto=True,
        params_extra={},      # e.g., {"N": 6}
        do_gifs=False,        # set True if animator.run_gif_suite is available
    )

    from pathlib import Path as _P
    out_csv = _P(BASE) / "promoted" / "sweep_summary.csv"
    print(df_promoted.head())
    print(f"[DONE] Promoted summary → {out_csv}")
