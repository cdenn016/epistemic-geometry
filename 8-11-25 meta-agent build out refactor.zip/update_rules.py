# -*- coding: utf-8 -*-
"""
Created on Wed Jul 23 10:32:58 2025

@author: chris and christine
"""
import time
from joblib import Parallel, delayed
import numpy as np
import config
from natural_gradient import (compute_inverse_fisher_field_natural,
                              )
from get_generators import get_generators
from omega import exp_lie_algebra_irrep, d_exp_phi_exact, d_exp_phi_tilde_exact
             
from numerical_utils import sanitize_sigma, safe_omega_inv, safe_inv, soft_clip_phi_norm, masked_cond_proxy, masked_stat        
from generalized_diagnostics_metrics import compute_alignment_field_general

from update_terms_phi import ( 
    accumulate_phi_morphism_self_feedback, accumulate_phi_alignment_gradient,
    grad_feedback_phi_direct, grad_feedback_phi_tilde_direct, grad_self_phi_direct,
    grad_self_phi_tilde_direct)

from update_terms_mu_sigma import accumulate_mu_sigma_gradient
from bundle_morphism_utils import compute_direct_morphisms


def zero_all_gradients(agent_i):
    import numpy as np

    def ensure_writeable(arr):
        if arr is None:
            return None
        if not arr.flags.writeable:
            return np.copy(arr)
        return arr

    # μ and Σ gradients (belief)
    agent_i.grad_mu_q_field = ensure_writeable(agent_i.grad_mu_q_field)
    agent_i.grad_sigma_q_field = ensure_writeable(agent_i.grad_sigma_q_field)
    agent_i.grad_mu_q = agent_i.grad_mu_q_field
    agent_i.grad_sigma_q = agent_i.grad_sigma_q_field

    # μ and Σ gradients (model)
    agent_i.grad_mu_p_field = ensure_writeable(agent_i.grad_mu_p_field)
    agent_i.grad_sigma_p_field = ensure_writeable(agent_i.grad_sigma_p_field)
    agent_i.grad_mu_p = agent_i.grad_mu_p_field
    agent_i.grad_sigma_p = agent_i.grad_sigma_p_field

    # Gauge field gradients
    agent_i.grad_phi = ensure_writeable(agent_i.grad_phi)
    agent_i.grad_phi_tilde = ensure_writeable(agent_i.grad_phi_tilde)

    # Morphism gradients
    agent_i.grad_Phi = ensure_writeable(agent_i.grad_Phi)
    agent_i.grad_Phi_tilde = ensure_writeable(agent_i.grad_Phi_tilde)

    
    # Zero everything else
    agent_i.grad_mu_q_field.fill(0)
    agent_i.grad_sigma_q_field.fill(0)
    agent_i.grad_mu_p_field.fill(0)
    agent_i.grad_sigma_p_field.fill(0)
    agent_i.grad_phi.fill(0)
    agent_i.grad_phi_tilde.fill(0)
    if agent_i.grad_Phi is not None:
        agent_i.grad_Phi.fill(0)
    if agent_i.grad_Phi_tilde is not None:
        agent_i.grad_Phi_tilde.fill(0)

        

def build_all_omega_caches(agents):
    """
    Build Ω and Ω̃ caches for each agent using their precomputed exp(φ).
    Should be called AFTER preprocess_agent_fields for all agents.
    """
    for agent_i in agents:
        agent_i.Omega_cache = {}
        agent_i.Omega_tilde_cache = {}

        for nb in agent_i.neighbors:
            j = nb["id"]
            agent_j = agents[j]

            Omega_ij = np.einsum("...ik,...kj->...ij", agent_i._exp_phi, agent_j._exp_neg_phi)
            Omega_tilde_ij = np.einsum("...ik,...kj->...ij", agent_i._exp_phi_model, agent_j._exp_neg_phi_model)

            agent_i.Omega_cache[j] = Omega_ij
            agent_i.Omega_tilde_cache[j] = Omega_tilde_ij
            
def preprocess_agent_fields(agent, params, G_q=None, G_p=None):
    eps        = getattr(config, "eps", 1e-8)
    group_name = config.group_name
    strict     = params.get("sanitize_strict", True) if params else True
    exp_jobs   = params.get("exp_n_jobs", 1)

    # ── Generators: prefer provided -> cached -> compute
    if G_q is not None:
        agent.generators_q = G_q
    if G_p is not None:
        agent.generators_p = G_p

    G_q = getattr(agent, "generators_q", None)
    if G_q is None or (isinstance(G_q, np.ndarray) and G_q.size == 0):
        G_q = get_generators(group_name, config.K_q)
        agent.generators_q = G_q

    G_p = getattr(agent, "generators_p", None)
    if G_p is None or (isinstance(G_p, np.ndarray) and G_p.size == 0):
        G_p = get_generators(group_name, config.K_p)
        agent.generators_p = G_p

    # SPD sanitize
    agent.sigma_q_field = sanitize_sigma(agent.sigma_q_field, strict=strict)
    agent.sigma_p_field = sanitize_sigma(agent.sigma_p_field, strict=strict)

    # Cache inverses
    agent.sigma_q_inv = safe_inv(agent.sigma_q_field, eps=eps)
    agent.sigma_p_inv = safe_inv(agent.sigma_p_field, eps=eps)

    # Condition proxies (masked, robust)
    agent._cond_proxy_q = masked_cond_proxy(agent.sigma_q_field, agent.mask)
    agent._cond_proxy_p = masked_cond_proxy(agent.sigma_p_field, agent.mask)

    # exp(φ), exp(φ̃)
    agent._exp_phi = exp_lie_algebra_irrep(
        agent.phi, G_q, group_name=group_name,
        max_norm=config.phi_exp_clip,
        threshold=getattr(config, "phi_exp_threshold", 1e-3),
        n_jobs=exp_jobs, verbose=False
    )
    agent._exp_phi_model = exp_lie_algebra_irrep(
        agent.phi_model, G_p, group_name=group_name,
        max_norm=config.phi_exp_clip,
        threshold=getattr(config, "phi_exp_threshold", 1e-3),
        n_jobs=exp_jobs, verbose=False
    )

    # exp(−φ), exp(−φ̃): transpose for orthogonal reps
    if getattr(config, "so3_irreps_are_orthogonal", True):
        agent._exp_neg_phi       = np.swapaxes(agent._exp_phi,      -1, -2)
        agent._exp_neg_phi_model = np.swapaxes(agent._exp_phi_model,-1, -2)
    else:
        agent._exp_neg_phi       = safe_omega_inv(agent._exp_phi, debug=False)
        agent._exp_neg_phi_model = safe_omega_inv(agent._exp_phi_model, debug=False)

    # Reset per-step transport caches
    agent.Omega_cache = {}
    agent.Omega_tilde_cache = {}

    # Optional Fisher metric caches for φ updates
    agent.inverse_fisher_phi        = compute_inverse_fisher_field_natural(agent, G_q, field="phi")
    agent.inverse_fisher_phi_model  = compute_inverse_fisher_field_natural(agent, G_p, field="phi_model")

    # Dev-only assert
    if getattr(config, "assert_spd_after_sanitize", False):
        wq = np.linalg.eigvalsh(0.5*(agent.sigma_q_field + np.swapaxes(agent.sigma_q_field,-1,-2)))
        wp = np.linalg.eigvalsh(0.5*(agent.sigma_p_field + np.swapaxes(agent.sigma_p_field,-1,-2)))
        floor = getattr(config, "sigma_eig_floor", 1e-6)
        if (wq <= floor).any() or (wp <= floor).any():
            raise RuntimeError("Non-SPD Σ after sanitize.")



def compute_all_gradients(agent_i, agents, generators_q, generators_p, params):
    zero_all_gradients(agent_i)

    timings = {}

    # ─── Belief μ, Σ ───
    t0 = time.perf_counter()
    accumulate_mu_sigma_gradient(agent_i, agents, params, mode="belief")
    timings["mu_sigma_belief"] = time.perf_counter() - t0

    # ─── Model μ, Σ ───
    t0 = time.perf_counter()
    accumulate_mu_sigma_gradient(agent_i, agents, params, mode="model")
    timings["mu_sigma_model"] = time.perf_counter() - t0

    # ─── Belief alignment: φᵢ ───
    t0 = time.perf_counter()
    # Precompute once per i
    Q_all_belief_i = d_exp_phi_exact(agent_i.phi, generators_q)
    exp_neg_cache_belief = {}  # j.id -> e^{-φ_j}
    for nb in agent_i.neighbors:
        agent_j = agents[nb["id"]]
        exp_neg_phi_j = exp_neg_cache_belief.get(agent_j.id)
        if exp_neg_phi_j is None:
            exp_neg_phi_j = safe_omega_inv(agent_j._exp_phi, eps=config.eps, debug=False)
            exp_neg_cache_belief[agent_j.id] = exp_neg_phi_j

        accumulate_phi_alignment_gradient(
            agent_i, agent_j, generators_q, params,
            field="phi",
            beta_key="beta",
            omega_cache_key="Omega_cache",
            mu_key="mu_q_field",
            sigma_key="sigma_q_field",
            fisher_inv_key="inverse_fisher_phi",
            grad_key="grad_phi",
            # precomputes:
            Q_all_i=Q_all_belief_i,
            exp_neg_phi_j=exp_neg_phi_j,
        )
    timings["phi_alignment"] = time.perf_counter() - t0

    # ─── Model alignment: φ̃ᵢ ───
    t0 = time.perf_counter()
    Q_all_model_i = d_exp_phi_tilde_exact(agent_i.phi_model, generators_p)
    exp_neg_cache_model = {}  # j.id -> e^{-φ̃_j}
    for nb in agent_i.neighbors:
        agent_j = agents[nb["id"]]
        exp_neg_phi_j = exp_neg_cache_model.get(agent_j.id)
        if exp_neg_phi_j is None:
            exp_neg_phi_j = safe_omega_inv(agent_j._exp_phi_model, eps=config.eps, debug=False)
            exp_neg_cache_model[agent_j.id] = exp_neg_phi_j

        accumulate_phi_alignment_gradient(
            agent_i, agent_j, generators_p, params,
            field="phi_model",
            beta_key="beta_model",
            omega_cache_key="Omega_tilde_cache",
            mu_key="mu_p_field",
            sigma_key="sigma_p_field",
            fisher_inv_key="inverse_fisher_phi_model",
            grad_key="grad_phi_tilde",
            # precomputes:
            Q_all_i=Q_all_model_i,
            exp_neg_phi_j=exp_neg_phi_j,
        )
    timings["phi_tilde_alignment"] = time.perf_counter() - t0

    # ─── Morphism feedback/self: φᵢ ───
    t0 = time.perf_counter()
    accumulate_phi_morphism_self_feedback(
        agent_i, generators_p, generators_q, params,
        field="phi",
        fisher_inv_key="inverse_fisher_phi",
        grad_key="grad_phi",
        phi_self_func=grad_self_phi_direct,               # vectorized version OK
        phi_feedback_func=grad_feedback_phi_direct,       # vectorized version OK
    )
    timings["phi_morphism"] = time.perf_counter() - t0

    # ─── Morphism feedback/self: φ̃ᵢ ───
    t0 = time.perf_counter()
    accumulate_phi_morphism_self_feedback(
        agent_i, generators_p, generators_q, params,
        field="phi_model",
        fisher_inv_key="inverse_fisher_phi_model",
        grad_key="grad_phi_tilde",
        phi_self_func=grad_self_phi_tilde_direct,         # vectorized version OK
        phi_feedback_func=grad_feedback_phi_tilde_direct, # vectorized version OK
    )
    timings["phi_tilde_morphism"] = time.perf_counter() - t0

    if getattr(config, "debug_grad_timing", False):
        print(f"\n[GRAD TIMINGS] Agent {agent_i.id}")
        for k, v in timings.items():
            print(f"  {k:22s} : {v*1e3:7.2f} ms")

    return (
        (agent_i.grad_mu_q, agent_i.grad_sigma_q),
        (agent_i.grad_mu_p, agent_i.grad_sigma_p),
        agent_i.grad_phi,
        agent_i.grad_phi_tilde,
        agent_i.grad_Phi,
        agent_i.grad_Phi_tilde,
    )


def compute_adaptive_eta(base_eta, kl_scalar, cond_scalar,
                         grad=None, scaling_kl=1.0, scaling_cond=1.0,
                         eta_min=0.0, ema_prev=None, ema_alpha=None):
    """
    Returns η in [eta_min, base_eta].
    kl_scalar, cond_scalar: robust, precomputed scalars.
    If kl_scalar is None/NaN, fallback to grad norm.
    Optional EMA smoothing via ema_prev/ema_alpha.
    """
    # KL or fallback
    if kl_scalar is None or not np.isfinite(kl_scalar):
        kl_term = float(np.mean(np.abs(grad))) if grad is not None else 0.0
    else:
        kl_term = float(kl_scalar)

    cond_term = float(cond_scalar) if np.isfinite(cond_scalar) else 1.0
    denom = 1.0 + scaling_kl * kl_term + scaling_cond * cond_term
    eta = np.clip(base_eta / denom, eta_min, base_eta)

    if ema_prev is not None and ema_alpha is not None and 0.0 < ema_alpha < 1.0:
        eta = ema_alpha * eta + (1.0 - ema_alpha) * ema_prev
    return eta



def apply_phi_updates(agent, grad_phi, grad_phi_m, mask, params):
    
    agent.grad_phi = np.array(grad_phi, copy=True)
    agent.grad_phi_tilde = np.array(grad_phi_m, copy=True)
    mask_exp = mask[..., None]
    mexp = mask[..., None]
    # config pulls
    tau_phi       = params.get("tau_phi",        config.tau_phi)
    tau_phi_model = params.get("tau_phi_model",  config.tau_phi_model)
    s_eta_phi     = params.get("eta_phi_adaptive_scaling",        config.eta_phi_adaptive_scaling)
    s_eta_cond    = params.get("eta_sigma_condition_scaling",     config.eta_sigma_condition_scaling)
    eta_phi_min   = params.get("eta_phi_min",    config.eta_phi_min)
    eta_phi_m_min = params.get("eta_phi_model_min", config.eta_phi_model_min)

    # robust, masked KL scalars (precompute once per step if you like)
    kl_q = masked_stat(getattr(agent, "cached_alignment_kl", None), mask, default=0.0)
    kl_p = masked_stat(getattr(agent, "cached_model_alignment_kl", None), mask, default=0.0)

    # condition proxies cached from sanitized Σ in preprocess
    cond_q = getattr(agent, "_cond_proxy_q", 1.0)
    cond_p = getattr(agent, "_cond_proxy_p", 1.0)

    # optional EMA on η
    ema_a  = getattr(config, "eta_ema_alpha", None)
    prev_eta_phi  = getattr(agent, "_eta_phi_prev", None)
    prev_eta_phi_m= getattr(agent, "_eta_phi_m_prev", None)

    eta_phi = compute_adaptive_eta(tau_phi, kl_q, cond_q, grad=grad_phi,
                                   scaling_kl=s_eta_phi, scaling_cond=s_eta_cond,
                                   eta_min=eta_phi_min, ema_prev=prev_eta_phi, ema_alpha=ema_a)
    eta_phi_m = compute_adaptive_eta(tau_phi_model, kl_p, cond_p, grad=grad_phi_m,
                                     scaling_kl=params.get("eta_phi_model_adaptive_scaling", s_eta_phi),
                                     scaling_cond=s_eta_cond, eta_min=eta_phi_m_min,
                                     ema_prev=prev_eta_phi_m, ema_alpha=ema_a)

    delta_phi   = np.nan_to_num(eta_phi   * grad_phi,   nan=0.0, posinf=0.0, neginf=0.0)
    delta_phi_m = np.nan_to_num(eta_phi_m * grad_phi_m, nan=0.0, posinf=0.0, neginf=0.0)

    agent.phi       -= delta_phi   * mexp
    agent.phi_model += delta_phi_m * mexp # += validated by energy diff step

    agent._eta_phi_prev   = eta_phi
    agent._eta_phi_m_prev = eta_phi_m



def synchronous_step(agents, generators_q, generators_p, params=None, n_jobs=1):
    params = params or {}
    N = len(agents)

    tau_mu_belief    = params.get("tau_mu_belief",  config.tau_mu_belief)
    tau_sigma_belief = params.get("tau_sigma_belief", config.tau_sigma_belief)
    tau_mu_model     = params.get("tau_mu_model",   config.tau_mu_model)
    tau_sigma_model  = params.get("tau_sigma_model", config.tau_sigma_model)
    eps = config.eps

    # ── Step 1: preprocess caches (light sanitize, avoid nested threads in exp())
    pre_params = dict(params)
    pre_params["sanitize_strict"] = pre_params.get("sanitize_strict_pre", False)
    pre_params["exp_n_jobs"] = 1
    
    Parallel(n_jobs=n_jobs, backend="threading", batch_size="auto")(
        delayed(preprocess_agent_fields)(A, pre_params, generators_q, generators_p) for A in agents
    )

    # ── Step 2: build Ω/Ω̃ caches for current φ/φ̃
    build_all_omega_caches(agents)

    # ── Step 3: compute all gradients
    grads = Parallel(n_jobs=n_jobs, backend="loky", batch_size="auto")(
        delayed(compute_all_gradients)(agent_i, agents, generators_q, generators_p, params)
        for agent_i in agents
    )
    q_updates, p_updates, phi_grads, phi_m_grads, morphism_grads, morphism_tilde_grads = zip(*grads)
    mask_list = [A.mask for A in agents]

    # ── Step 4: apply η and φ updates
    def apply_agent_updates(i):
        agent = agents[i]
        mask  = mask_list[i]

        Δη1_q, Δη2_q = q_updates[i]
        Δη1_p, Δη2_p = p_updates[i]

        # Fallback safeguards
        if Δη1_q is None: Δη1_q = np.zeros_like(agent.mu_q_field)
        if Δη2_q is None: Δη2_q = np.zeros_like(agent.sigma_q_field)
        if Δη1_p is None: Δη1_p = np.zeros_like(agent.mu_p_field)
        if Δη2_p is None: Δη2_p = np.zeros_like(agent.sigma_p_field)

        mask_mu    = mask[..., None]
        mask_sigma = mask[..., None, None]

        # μ updates
        agent.mu_q_field += tau_mu_belief   * Δη1_q * mask_mu
        agent.mu_p_field += tau_mu_model    * Δη1_p * mask_mu

        # Σ updates (assign; sanitize later in preprocess)
        agent.sigma_q_field = agent.sigma_q_field + tau_sigma_belief * Δη2_q * mask_sigma
        agent.sigma_p_field = agent.sigma_p_field + tau_sigma_model  * Δη2_p * mask_sigma

        # φ, φ̃ updates
        apply_phi_updates(agent, phi_grads[i], phi_m_grads[i], mask, params)
        
        #agent.phi       = soft_clip_phi_norm(agent.phi,       max_norm=np.pi)
        #agent.phi_model = soft_clip_phi_norm(agent.phi_model, max_norm=np.pi)

        # Update morphisms from new φ/φ̃
        agent.bundle_morphism_q_to_p, agent.bundle_morphism_p_to_q = compute_direct_morphisms(
            phi=agent.phi,
            phi_model=agent.phi_model,
            generators_q=agent.generators_q,
            generators_p=agent.generators_p,
            Phi_0=agent.Phi_0,
            Phi_tilde_0=agent.Phi_tilde_0,
        )

    Parallel(n_jobs=n_jobs, backend="threading", batch_size="auto")(
        delayed(apply_agent_updates)(i) for i in range(N)
    )

    # ── Step 4.5: POST-UPDATE REFRESH (MANDATORY)
    # Recompute exp(φ), exp(−φ), Fisher caches, and rebuild Ω/Ω̃
    post_params = dict(params)
    post_params["sanitize_strict"] = True
    post_params["exp_n_jobs"] = 1
    
    Parallel(n_jobs=n_jobs, backend="threading", batch_size="auto")(
        delayed(preprocess_agent_fields)(A, post_params, generators_q, generators_p) for A in agents
    )
    build_all_omega_caches(agents)

    # ── Step 5: recompute cached KL fields using *fresh* Ω/Ω̃
    for A in agents:
        A.cached_alignment_kl       = compute_alignment_field_general(agents, A.id, field_type="belief", log_eps=eps)
        A.cached_model_alignment_kl = compute_alignment_field_general(agents, A.id, field_type="model",  log_eps=eps)

    # ── Step 6: telemetry (optional)
    if params.get("log_step_telemetry", False):
        step_telemetry(agents, params.get("step", -1))

    return agents



def step_telemetry(agents, step):
    floor = getattr(config, "sigma_eig_floor", 1e-6)
    eps   = 1e-12
    vals = []
    for A in agents:
        # SPD stats
        wq = np.linalg.eigvalsh(0.5*(A.sigma_q_field + np.swapaxes(A.sigma_q_field,-1,-2)))
        wp = np.linalg.eigvalsh(0.5*(A.sigma_p_field + np.swapaxes(A.sigma_p_field,-1,-2)))
        min_eig_q = float(wq.min(initial=1e9))
        min_eig_p = float(wp.min(initial=1e9))
        # η and KL
        eta_phi   = getattr(A, "_eta_phi_prev", None)
        eta_phi_m = getattr(A, "_eta_phi_m_prev", None)
        kl_q_med  = masked_stat(getattr(A, "cached_alignment_kl", None), A.mask, default=np.nan)
        kl_p_med  = masked_stat(getattr(A, "cached_model_alignment_kl", None), A.mask, default=np.nan)
        vals.append(dict(
            min_eig_q=min_eig_q, min_eig_p=min_eig_p,
            cond_q=A._cond_proxy_q, cond_p=A._cond_proxy_p,
            eta_phi=eta_phi, eta_phi_m=eta_phi_m,
            kl_q_med=kl_q_med, kl_p_med=kl_p_med
        ))
        # per-agent log for later plots
        #A.log_metrics(step, vals[-1])
        
    # quick console summary
    mq = min(v["min_eig_q"] for v in vals)
    mp = min(v["min_eig_p"] for v in vals)
    print(f"[STEP {step}] min_eig(q)={mq:.2e}\n  min_eig(p)={mp:.2e}\n  "
          f"ηφ~{np.nanmedian([v['eta_phi'] for v in vals]):.3g}\n  "
          f"KLb~{np.nanmedian([v['kl_q_med'] for v in vals]):.3g}\n\n")
    


def _masked_unit(v, mask):
    v = np.nan_to_num(v, copy=True)
    v *= (mask > getattr(config, "support_cutoff_eps", 0.0))[..., None].astype(v.dtype)
    n = float(np.linalg.norm(v))
    return (v / (n + 1e-12), n)



# diagnostics.py (or wherever you put them)
def energy_diff_for_phi(agent_i, agent_j, agents_all,
                        eps_list=(1e-4, 3e-4, 1e-3, 3e-3),
                        rel_tol=1e-8, abs_tol=1e-10,
                        expect="minus"):  # "minus" for φ (φ -= η∇E), "plus" if you ever flip
    import numpy as np, config

    def E():
        build_all_omega_caches(agents_all)
        KLi = compute_alignment_field_general(agents_all, agent_i.id, field_type="belief", log_eps=config.eps)
        m = (agent_i.mask > getattr(config, "support_cutoff_eps", 0.0)) & \
            (agent_j.mask  > getattr(config, "support_cutoff_eps", 0.0))
        return float(np.nanmean(KLi[m]))

    try:
        E0 = E()
    except Exception:
        E0 = float("nan")

    g = getattr(agent_i, "grad_phi", None)
    if g is None:
        return {"ok": None, "reason": "no_grad", "E0": E0, "gnorm": float("nan"), "rows": [], "used_eps": None}

    v = np.nan_to_num(g, copy=True)
    v *= (agent_i.mask > getattr(config, "support_cutoff_eps", 0.0))[..., None].astype(v.dtype)
    gnorm = float(np.linalg.norm(v))
    if not np.isfinite(gnorm) or gnorm == 0.0:
        return {"ok": None, "reason": "zero_or_nonfinite_grad", "E0": E0, "gnorm": gnorm, "rows": [], "used_eps": None}
    ghat = v / (gnorm + 1e-12)

    preprocess_agent_fields(agent_i, {"sanitize_strict": True})
    preprocess_agent_fields(agent_j, {"sanitize_strict": True})

    rows, used_eps = [], None
    saved = agent_i.phi.copy()
    tol = max(abs_tol, abs(E0) * rel_tol) if np.isfinite(E0) else abs_tol

    for eps in eps_list:
        deltas = []
        for sgn in (+1.0, -1.0):
            agent_i.phi = saved + sgn * eps * ghat
            preprocess_agent_fields(agent_i, {"sanitize_strict": True})
            dE = E() - E0
            rec = {"eps": float(eps), "sign": int(np.sign(sgn)), "dE": float(dE)}
            rows.append(rec); deltas.append(rec)
        if used_eps is None and any(abs(r["dE"]) > tol for r in deltas):
            used_eps = eps

    agent_i.phi = saved
    preprocess_agent_fields(agent_i, {"sanitize_strict": True})
    build_all_omega_caches(agents_all)

    ok = None
    if used_eps is not None:
        small = [r for r in rows if np.isclose(r["eps"], used_eps)]
        want = -1 if expect == "minus" else +1
        chosen = next((r for r in small if r["sign"] == want), None)
        ok = (chosen is not None and chosen["dE"] < 0.0)

    return {"ok": ok, "E0": E0, "gnorm": float(gnorm), "rows": rows, "used_eps": used_eps}



def energy_diff_for_phi_model(agent_i, agent_j, agents_all,
                              eps_list=(1e-4, 3e-4, 1e-3, 3e-3),
                              rel_tol=1e-8, abs_tol=1e-10,
                              expect="plus"):  # φ̃ += η∇E now
    import numpy as np, config

    def _masked_unit(v, mask):
        v = np.nan_to_num(v, copy=True)
        v *= (mask > getattr(config, "support_cutoff_eps", 0.0))[..., None].astype(v.dtype)
        n = float(np.linalg.norm(v))
        return (v / (n + 1e-12), n)

    def E():
        build_all_omega_caches(agents_all)
        KLm = compute_alignment_field_general(agents_all, agent_i.id, field_type="model", log_eps=config.eps)
        m = ((agent_i.mask > getattr(config, "support_cutoff_eps", 0.0)) &
             (agent_j.mask  > getattr(config, "support_cutoff_eps", 0.0)))
        return float(np.nanmean(KLm[m]))

    try:
        E0 = E()
    except Exception:
        E0 = float("nan")

    g = getattr(agent_i, "grad_phi_tilde", None)
    if g is None:
        return {"ok": None, "reason": "no_grad", "E0": E0, "gnorm": float("nan"), "rows": [], "used_eps": None}

    ĝ, gnorm = _masked_unit(g, agent_i.mask)
    if (not np.isfinite(gnorm)) or gnorm == 0.0:
        return {"ok": None, "reason": "zero_or_nonfinite_grad", "E0": E0, "gnorm": float(gnorm), "rows": [], "used_eps": None}

    preprocess_agent_fields(agent_i, {"sanitize_strict": True})
    preprocess_agent_fields(agent_j, {"sanitize_strict": True})

    rows, used_eps = [], None
    saved = agent_i.phi_model.copy()
    tol = max(abs_tol, abs(E0) * rel_tol) if np.isfinite(E0) else abs_tol

    for eps in eps_list:
        deltas = []
        for sgn in (+1.0, -1.0):
            agent_i.phi_model = saved + sgn * eps * ĝ
            preprocess_agent_fields(agent_i, {"sanitize_strict": True})
            dE = E() - E0
            rec = {"eps": float(eps), "sign": int(np.sign(sgn)), "dE": float(dE)}
            rows.append(rec); deltas.append(rec)
        if used_eps is None and any(abs(r["dE"]) > tol for r in deltas):
            used_eps = eps

    agent_i.phi_model = saved
    preprocess_agent_fields(agent_i, {"sanitize_strict": True})
    build_all_omega_caches(agents_all)

    ok = None
    if used_eps is not None:
        small = [r for r in rows if np.isclose(r["eps"], used_eps)]
        want = -1 if expect == "minus" else +1
        chosen = next((r for r in small if r["sign"] == want), None)
        ok = (chosen is not None and chosen["dE"] < 0.0)

    return {"ok": ok, "E0": E0, "gnorm": float(gnorm), "rows": rows, "used_eps": used_eps}
