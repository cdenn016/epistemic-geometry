
from __future__ import annotations
import numpy as np
from generalized_agent_schema import Agent
import config



# meta_recursion.py

from pathlib import Path
import json, math
import numpy as np

# relies on your existing codebase
import config
from meta_agents import (
    run_generic_alignment_analysis, load_meta_data, compute_cluster_kl_stats,
    compute_order_parameter, plot_intra_kl_distribution, plot_inter_vs_intra,
    compute_cluster_order_parameters, plot_cluster_order_parameters,
    plot_spatial_cluster_map, plot_curvature_heatmap, condensation_score,
    build_meta_agents_from_clusters, wire_child_parent_links,
    coarsen_phi_from_children, compute_avg_crossscale_kl_q,
    procrustes_seed_lambda_dn_q, save_meta_agents, save_meta_labels,
    build_runtime_params_for_xscale, plot_cluster_size_hist,
    plot_child_parent_overlay, plot_crossscale_kl_hist,
)
from generalized_simulation import run_simulation
from agent_initialization import attach_crossscale_fields
from io_utils import load_final_step  # whatever you use to load last step
from get_generators import get_generators  # your canonical generator fetcher


# ---------- small helpers ----------

def _prepare_generators():
    Gq = get_generators(config.group_name, config.K_q)
    Gp = get_generators(config.group_name, config.K_p)
    return Gq, Gp, {"q": Gq, "p": Gp}


def _run_alignment_suite(agents, generators, basedir: Path, log_eps: float, overlap_eps: float):
    params = {"log_eps": log_eps, "overlap_eps": overlap_eps}
    for mode in ("belief", "model"):
        outdir = basedir / f"{mode}_alignment_output"
        outdir.mkdir(parents=True, exist_ok=True)
        print(f"\n[INFO] Running alignment analysis for mode: {mode}")
        run_generic_alignment_analysis(agents, generators, params, mode, outdir=outdir)


def _evaluate_prefix(agents, align_dir: Path, prefix: str, curvature_generators, outdir_root: Path):
    kl_matrix, labels, rankings = load_meta_data(str(align_dir), prefix)
    if len(labels) != len(agents):
        print(f"[ERROR] Label count {len(labels)} != agent count {len(agents)}")
        return None

    print(f"[INFO] Cluster label histogram: {np.bincount(labels[labels >= 0])}")
    stats = compute_cluster_kl_stats(kl_matrix, labels)
    if not stats:
        print(f"[!] No clusters detected for {prefix}; skipping.")
        return None

    R_global, sigma_global = compute_order_parameter(kl_matrix)

    outdir = outdir_root / prefix
    outdir.mkdir(parents=True, exist_ok=True)
    plot_intra_kl_distribution(stats, outpath=outdir / "intra_kl.png")
    plot_inter_vs_intra(stats, outpath=outdir / "inter_vs_intra.png")
    cluster_R = compute_cluster_order_parameters(kl_matrix, labels)
    plot_cluster_order_parameters(cluster_R, outpath=outdir / "cluster_order_params.png")
    plot_spatial_cluster_map(agents, labels, outpath=outdir / "spatial_clusters.png")
    plot_curvature_heatmap(agents, labels, curvature_generators, outpath=outdir / "curvature_heatmap.png")

    score = condensation_score(stats, R_global, sigma_global, kl_matrix=kl_matrix, labels=labels)
    print(f"[INFO] {prefix} condensation score = {score:.4f}")

    return {"prefix": prefix, "score": float(score), "labels": labels, "kl_matrix": kl_matrix}


def _choose_best_clustering(agents, Gq, Gp, basedir: Path):
    specs = {
        "kl":       (basedir / "belief_alignment_output", Gq),
        "kl_model": (basedir / "model_alignment_output",  Gp),
    }
    best = {"prefix": None, "score": -math.inf, "labels": None, "kl_matrix": None}
    for prefix, (adir, curv_G) in specs.items():
        print(f"\n[INFO] Evaluating '{prefix}' clusters @ {adir}")
        res = _evaluate_prefix(agents, adir, prefix, curv_G, outdir_root=basedir / "condensation_output")
        if res and res["score"] > best["score"]:
            best = res
    if best["prefix"] is None:
        raise RuntimeError("No valid clustering found to build meta-agents.")
    print(f"\n[INFO] Selected clustering: {best['prefix']} (score={best['score']:.4f})")
    return best


def _ensure_parent_slots(meta_agents):
    for P in meta_agents:
        attach_crossscale_fields(P, config.K_q, config.K_p)  # no-op if present
        P.level = getattr(P, "level", 1)


def _seed_or_revert_procrustes(meta_agents, agents, labels):
    vals_base = compute_avg_crossscale_kl_q(agents, meta_agents, labels, eps=1e-6)
    base_mean = float(np.nanmean(vals_base))

    procrustes_seed_lambda_dn_q(meta_agents, agents, labels)

    vals_seed = compute_avg_crossscale_kl_q(agents, meta_agents, labels, eps=1e-6)
    seed_mean = float(np.nanmean(vals_seed))
    print(f"[XSCALE] KL base {base_mean:.4f} → after seed {seed_mean:.4f}")

    reverted = False
    if not np.isfinite(seed_mean) or seed_mean > 2.0 * base_mean:
        Kq = meta_agents[0].mu_q_field.shape[-1]
        for P in meta_agents:
            P.Lambda_dn_q = np.eye(Kq, dtype=P.mu_q_field.dtype)
            P.Lambda_up_q = np.eye(Kq, dtype=P.mu_q_field.dtype)
        print("[XSCALE] Procrustes seed increased KL — reverted to identity.")
        reverted = True
    return {"base_mean": base_mean, "seed_mean": seed_mean, "reverted": reverted}


def _coarse_grain_gauge_fields(meta_agents, agents):
    for P in meta_agents:
        coarsen_phi_from_children(P, agents, field="phi",       weight_mode="mask")
        coarsen_phi_from_children(P, agents, field="phi_model", weight_mode="mask")


def _field_norm(a, m=None):
    v = np.linalg.norm(a, axis=-1) if a.ndim == 3 else np.linalg.norm(a, axis=(-1, -2))
    if m is not None:
        v = v[m > 1e-6]
    return float(np.nanmean(v)) if v.size else float("nan")


def _post_build_summaries(meta_agents):
    for P in meta_agents:
        n_phi  = _field_norm(P.phi,       P.mask)
        n_phim = _field_norm(P.phi_model, P.mask)
        print(f"[META] parent {P.id}: ⟨‖φ‖⟩={n_phi:.4f}  ⟨‖φ̃‖⟩={n_phim:.4f}")


def _run_child_with_steps(params, steps: int|None, outdir: str):
    # lightweight steps override without touching your run loop internals
    old_steps = config.steps
    if steps is not None:
        config.steps = int(steps)
    try:
        agents_after, metric_log = run_simulation(outdir=outdir, params=params)
    finally:
        config.steps = old_steps
    return agents_after, metric_log


def _kl_plateau(metric_log, window=15, tol=1e-3):
    vals = [m.get("xscale_kl_q_mean") for m in metric_log if "xscale_kl_q_mean" in m]
    vals = [v for v in vals if v is not None and np.isfinite(v)]
    if len(vals) < 2*window:
        return False, np.nan
    a, b = np.nanmean(vals[-2*window:-window]), np.nanmean(vals[-window:])
    return (abs(a - b) < tol), b


# ---------- public API ----------

def run_meta_recursion(
    levels=2,
    base_ckpt="checkpoints",
    steps_per_level: list[int] | tuple[int, ...] | None = None,
    log_eps=1e-6,
    overlap_eps=1e-6,
    plateau_window=15,
    plateau_tol=1e-3,
    out_root="meta_agent_analysis",
):
    """
    Build parents from a checkpoint, run child simulation with XSCALE,
    then repeat for multiple levels until plateau or `levels` exhausted.

    Returns: dict manifest with per-level summaries and output dirs.
    """
    out_root = Path(out_root)
    manifest = {"base_ckpt": base_ckpt, "levels": []}
    prev_plateau_mean = None

    for L in range(levels):
        print(f"\n========== META-RECURSION: LEVEL {L} ==========")
        level_dir = out_root / f"L{L}"
        level_dir.mkdir(parents=True, exist_ok=True)

        # 1) load agents + generators for this level
        ckpt = base_ckpt if L == 0 else f"{base_ckpt}_L{L}"
        agents = load_final_step(ckpt)
        if agents is None:
            raise FileNotFoundError(f"No step_XXXX.pkl found in {ckpt}/")
        Gq, Gp, generators = _prepare_generators()

        # 2) run alignment analyses and pick best clustering
        _run_alignment_suite(agents, generators, level_dir, log_eps, overlap_eps)
        best = _choose_best_clustering(agents, Gq, Gp, basedir=level_dir)

        # 3) build parents, wire links, coarse-grain gauge, seed Λ (with revert)
        chosen_G = Gq if best["prefix"] == "kl" else Gp
        parents = build_meta_agents_from_clusters(agents, best["labels"], chosen_G)
        _ensure_parent_slots(parents)
        wire_child_parent_links(agents, parents, best["labels"])
        _coarse_grain_gauge_fields(parents, agents)
        _post_build_summaries(parents)
        seed_info = _seed_or_revert_procrustes(parents, agents, best["labels"])

        # 4) persist meta artifacts
        save_meta_agents(parents, output_dir=str(level_dir / "meta_agent_fields"))
        save_meta_labels(best["labels"], path=str(level_dir / "meta_labels.csv"))

        # 5) run child simulation with XSCALE context
        runtime_params = build_runtime_params_for_xscale(Gq, Gp, parents, best["labels"])
        outdir = f"{base_ckpt}_L{L+1}"
        steps = None
        if steps_per_level is not None:
            steps = steps_per_level[L] if L < len(steps_per_level) else steps_per_level[-1]
        _, metric_log = _run_child_with_steps(runtime_params, steps=steps, outdir=outdir)

        # 6) plateau check on cross-scale KL
        hit_plateau, plateau_mean = _kl_plateau(metric_log, window=plateau_window, tol=plateau_tol)

        # 7) quick plots for this level
        plots_dir = level_dir / "agent_plots"
        plots_dir.mkdir(exist_ok=True)
        plot_cluster_size_hist(best["labels"], outpath=plots_dir / "cluster_sizes.png")
        plot_child_parent_overlay(agents, parents, best["labels"], outpath=plots_dir / "child_parent_overlay.png", max_examples=12)
        vals = compute_avg_crossscale_kl_q(agents, parents, best["labels"], eps=1e-6)
        plot_crossscale_kl_hist(vals, outpath=plots_dir / "crossscale_kl_q_hist.png")

        # 8) record level summary
        level_summary = {
            "level": L,
            "in_ckpt": ckpt,
            "out_ckpt": outdir,
            "best_prefix": best["prefix"],
            "best_score": best["score"],
            "seed_base_mean": seed_info["base_mean"],
            "seed_after_mean": seed_info["seed_mean"],
            "seed_reverted": seed_info["reverted"],
            "plateau_mean": float(plateau_mean) if np.isfinite(plateau_mean) else None,
            "hit_plateau": bool(hit_plateau),
        }
        manifest["levels"].append(level_summary)

        # save running manifest
        with open(out_root / "recursion_manifest.json", "w") as f:
            json.dump(manifest, f, indent=2)

        # 9) stopping rule
        if hit_plateau:
            print(f"[STOP] Plateau at level {L+1} (Δ<{plateau_tol}).")
            break
        prev_plateau_mean = plateau_mean

    print("\n[✓] Meta-recursion complete.")
    return manifest
