# -*- coding: utf-8 -*-
"""
Created on Sat Aug  9 21:34:22 2025

@author: chris and christine
"""

# diagnostics_gif_maker.py
# Produce colorful GIFs from fields/step*.npz produced by your logger.
# No CLI. Run directly:  python diagnostics_gif_maker.py
# Outputs to "reports_gifs" by default.

import os
import math
from pathlib import Path
from dataclasses import dataclass
from typing import Optional, List, Dict, Sequence, Callable

import numpy as np
import imageio.v2 as imageio
from PIL import Image, ImageDraw, ImageFont
from matplotlib import cm

from concurrent.futures import ProcessPoolExecutor, as_completed
import os

# add at the top near imports
from concurrent.futures import ThreadPoolExecutor, as_completed
import os

# ─────────────────────────────────────────────────────────────────────────────
# Helpers (IO, color, geometry)
# ─────────────────────────────────────────────────────────────────────────────

def safe_mkdir(p: str):
    Path(p).mkdir(parents=True, exist_ok=True)

def downsample(arr: np.ndarray, ds: Optional[int]):
    if not ds or ds <= 1 or arr is None:
        return arr
    H, W = arr.shape[:2]
    H2, W2 = H // ds, W // ds
    return arr[:H2*ds, :W2*ds].reshape(H2, ds, W2, ds, *arr.shape[2:]).mean(axis=(1, 3))

def colorize_scalar(f: np.ndarray, vmin: float, vmax: float, cmap_name: str = "turbo") -> np.ndarray:
    f = np.asarray(f, dtype=float)
    if not np.isfinite(vmin): vmin = np.nanmin(f)
    if not np.isfinite(vmax): vmax = np.nanmax(f)
    if vmax <= vmin: vmax = vmin + 1e-9
    x = np.clip((f - vmin) / (vmax - vmin), 0.0, 1.0)
    rgb = cm.get_cmap(cmap_name)(x)[..., :3]
    return (rgb * 255.0 + 0.5).astype(np.uint8)

def pclip_global(values: List[np.ndarray], lo=1.0, hi=99.0) -> tuple[float, float]:
    a = [v[np.isfinite(v)] for v in values if v is not None and v.size]
    if not a:
        return 0.0, 1.0
    a = np.concatenate([x.ravel() for x in a if x.size], axis=0)
    lo_v, hi_v = np.percentile(a, [lo, hi])
    if not np.isfinite(lo_v): lo_v = float(np.min(a))
    if not np.isfinite(hi_v): hi_v = float(np.max(a))
    if hi_v <= lo_v: hi_v = lo_v + 1e-9
    return float(lo_v), float(hi_v)

def overlay_mask_outline(rgb: np.ndarray, mask_bool: Optional[np.ndarray], thickness: int = 1) -> np.ndarray:
    """Draw white outline of mask onto rgb (numpy only)."""
    if mask_bool is None:
        return rgb
    if rgb.ndim == 2:
        rgb = np.stack([rgb] * 3, axis=-1)
    m = mask_bool.astype(np.uint8)
    mp = np.pad(m, 1, mode="edge")
    s = (
        mp[0:-2,0:-2] + mp[0:-2,1:-1] + mp[0:-2,2:] +
        mp[1:-1,0:-2] + mp[1:-1,1:-1] + mp[1:-1,2:] +
        mp[2:  ,0:-2] + mp[2:  ,1:-1] + mp[2:  ,2:]
    )
    dil = (s > 0)
    edge = dil ^ (m > 0)
    out = rgb.copy()
    out[edge] = [255, 255, 255]
    if thickness > 1:
        # simple second pass
        return overlay_mask_outline(out, dil, thickness=1)
    return out

def center_pad(rgb: np.ndarray, target_h: int, target_w: int, pad_val: int = 0) -> np.ndarray:
    h, w = rgb.shape[:2]
    canvas = np.full((target_h, target_w, 3), pad_val, dtype=np.uint8)
    oy = (target_h - h) // 2
    ox = (target_w - w) // 2
    canvas[oy:oy+h, ox:ox+w] = rgb
    return canvas

def caption_top(rgb: np.ndarray, text: str, banner_px: int = 28) -> np.ndarray:
    H, W = rgb.shape[:2]
    canvas = np.zeros((H + banner_px, W, 3), dtype=np.uint8)
    canvas[banner_px:] = rgb
    img = Image.fromarray(canvas, mode="RGB")
    draw = ImageDraw.Draw(img)
    try:
        font = ImageFont.load_default()
    except Exception:
        font = None
    y = (banner_px - 12) // 2
    # shadow
    for dx, dy in ((1,1),(0,1),(1,0)):
        draw.text((6 + dx, y + dy), text, fill=(0, 0, 0), font=font)
    draw.text((6, y), text, fill=(255, 255, 255), font=font)
    return np.array(img, dtype=np.uint8)

def auto_scale(rgb: np.ndarray, min_side: int = 256) -> np.ndarray:
    h, w = rgb.shape[:2]
    s = max(1, int(np.floor(min_side / max(1, min(h, w)))))
    if s <= 1: return rgb
    return np.repeat(np.repeat(rgb, s, axis=0), s, axis=1)

from PIL import Image, ImageDraw, ImageFont
import numpy as np
from matplotlib import colormaps as mpl_cmaps  # ✅ modern API

def draw_colorbar_h(
    rgb: np.ndarray,
    vmin: float,
    vmax: float,
    cmap_name: str = "turbo",
    bar_height: int = 14,
    pad: int = 6,
    bg_alpha: int = 0,
):
    H, W = rgb.shape[:2]

    # font
    try:
        font = ImageFont.load_default()
    except Exception:
        font = None

    txt_min = f"{vmin:.3g}"
    txt_max = f"{vmax:.3g}"

    # measure text sizes
    tmp_img = Image.new("RGB", (10, 10))
    draw_tmp = ImageDraw.Draw(tmp_img)
    try:
        bbox_min = draw_tmp.textbbox((0, 0), txt_min, font=font)
        bbox_max = draw_tmp.textbbox((0, 0), txt_max, font=font)
        text_h = max(bbox_min[3] - bbox_min[1], bbox_max[3] - bbox_max[1])
        text_w_max = bbox_max[2] - bbox_max[0]
    except Exception:
        text_h, text_w_max = 10, 24

    extra_h = pad + bar_height + pad + text_h + pad

    # gradient bar
    bar_w = max(W - 2*pad, 10)
    x = np.linspace(0, 1, bar_w, dtype=float)
    cmap = mpl_cmaps.get_cmap(cmap_name)          # ✅ no deprecation warning
    bar = cmap(x)[..., :3]
    bar = (bar * 255.0 + 0.5).astype(np.uint8)
    bar = np.repeat(bar[None, :, :], bar_height, axis=0)

    out = np.zeros((H + extra_h, W, 3), dtype=np.uint8)
    out[:H] = rgb

    if bg_alpha > 0:
        overlay = np.zeros_like(out)
        y0_bg = H
        out[y0_bg:] = (out[y0_bg:] * (255 - bg_alpha) // 255) + (overlay[y0_bg:] * bg_alpha // 255)

    y0 = H + pad
    x0 = (W - bar_w) // 2
    out[y0:y0 + bar_height, x0:x0 + bar_w] = bar

    img = Image.fromarray(out, mode="RGB")
    draw = ImageDraw.Draw(img)
    draw.text((x0, y0 + bar_height + pad), txt_min, fill=(255,255,255), font=font)
    draw.text((x0 + bar_w - text_w_max, y0 + bar_height + pad), txt_max, fill=(255,255,255), font=font)

    return np.array(img, dtype=np.uint8)



# ─────────────────────────────────────────────────────────────────────────────
# Data index + loaders
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class RunIndex:
    root: Path
    fields_dir: Path
    steps: List[int]
    field_paths: Dict[int, Path]

def build_index(checkpoints_dir: str) -> RunIndex:
    root = Path(checkpoints_dir)
    fields_dir = root / "fields"
    field_paths: Dict[int, Path] = {}
    if fields_dir.exists():
        for p in sorted(fields_dir.glob("step*.npz")):
            try:
                s = int(p.stem.replace("step", ""))
                field_paths[s] = p
            except Exception:
                pass
    steps = sorted(field_paths.keys())
    return RunIndex(root=root, fields_dir=fields_dir, steps=steps, field_paths=field_paths)

def load_field_npz(idx: RunIndex, step: int) -> Optional[dict]:
    p = idx.field_paths.get(step)
    if p is None or not p.exists():
        return None
    return dict(np.load(p, allow_pickle=False))


# ─────────────────────────────────────────────────────────────────────────────
# Field accessors / summaries
# ─────────────────────────────────────────────────────────────────────────────

def get_mask(npz: dict, agent_idx: int) -> Optional[np.ndarray]:
    if "mask" in npz and npz["mask"].ndim == 3 and npz["mask"].shape[0] > agent_idx:
        return npz["mask"][agent_idx].astype(bool)
    return None

def mu_component(npz: dict, key: str, agent_idx: int, k: int) -> Optional[np.ndarray]:
    if key not in npz: return None
    MU = npz[key]  # (N,H,W,K)
    if MU.ndim != 4 or MU.shape[0] <= agent_idx or MU.shape[-1] <= k:
        return None
    return MU[agent_idx, ..., k]

def sigma_summary(npz: dict, key: str, agent_idx: int, how: str) -> Optional[np.ndarray]:
    if key not in npz: return None
    S = npz[key]  # (N,H,W,K,K)
    if S.ndim != 5 or S.shape[0] <= agent_idx:
        return None
    A = S[agent_idx]
    H, W, K, _ = A.shape
    M = A.reshape(-1, K, K)
    M = 0.5 * (M + np.transpose(M, (0, 2, 1)))  # symmetrize
    if how == "trace":
        vals = np.trace(M, axis1=1, axis2=2)
    elif how == "logdet":
        sign, logd = np.linalg.slogdet(M)
        vals = np.where(sign > 0, logd, -np.inf)
    elif how in ("min_eig", "max_eig", "cond"):
        eigvals = np.linalg.eigvalsh(M)
        if how == "min_eig":
            vals = eigvals[:, 0]
        elif how == "max_eig":
            vals = eigvals[:, -1]
        else:  # cond
            vals = np.where(eigvals[:, 0] > 0, eigvals[:, -1] / eigvals[:, 0], np.inf)
    else:
        return None
    return vals.reshape(H, W)

def frob_norm(npz: dict, key: str, agent_idx: int) -> Optional[np.ndarray]:
    if key not in npz: return None
    M = npz[key]  # (N,H,W,Kp,Kq) or (N,H,W,K,K)
    if M.ndim < 5 or M.shape[0] <= agent_idx:
        return None
    A = M[agent_idx]
    return np.sqrt(np.sum(A * A, axis=(-2, -1)))

def vec_norm(npz: dict, key: str, agent_idx: int) -> Optional[np.ndarray]:
    if key not in npz: return None
    V = npz[key]  # (N,H,W,D)
    if V.ndim != 4 or V.shape[0] <= agent_idx:
        return None
    A = V[agent_idx]
    return np.linalg.norm(A, axis=-1)

def scalar_from_key(npz: dict, key: str, agent_idx: int) -> Optional[np.ndarray]:
    """Generic: (N,H,W) -> pick agent; (H,W) -> as-is; unknown -> None."""
    if key not in npz:
        return None
    A = npz[key]
    if A.ndim == 3 and A.shape[0] > agent_idx:
        return A[agent_idx]
    if A.ndim == 2:
        return A
    return None

def load_all_npz(idx: RunIndex, steps: Optional[List[int]] = None, mmap: bool = True) -> Dict[int, dict]:
    """Return {step: npz_dict}, using mmap to avoid copying."""
    steps = steps or idx.steps
    out = {}
    for s in steps:
        p = idx.field_paths.get(s)
        if p is None: 
            continue
        # mmap keeps arrays on disk-backed pages; low RAM cost
        npz = np.load(p, allow_pickle=False, mmap_mode="r") if mmap else np.load(p, allow_pickle=False)
        # wrap as a dict of arrays; keep the NpzFile open by holding reference
        out[s] = {k: npz[k] for k in npz.files}
    return out

def sampled_steps(idx: RunIndex, stride: int = 1, max_frames: Optional[int] = None) -> List[int]:
    steps = idx.steps[::max(1, stride)]
    if max_frames is not None and len(steps) > max_frames:
        steps = steps[:max_frames]
    return steps

# ─────────────────────────────────────────────────────────────────────────────
# Core animation primitive
# ─────────────────────────────────────────────────────────────────────────────

def animate_scalar_supplier(
    idx: RunIndex,
    out_gif: str,
    supplier: Callable[[dict], Optional[np.ndarray]],
    *,
    title: str,
    agent_idx: int,
    percentile: tuple[float, float] = (1, 99),
    ds_factor: Optional[int] = None,
    add_mask_outline: bool = True,
    cmap: str = "turbo",
    min_side: int = 256,
    duration: float = 0.14,
    normalize: str = "global",            # "global" or "per_frame"
    show_colorbar: bool = True,
    step_stride: int = 1,                 # frame sampling
    max_frames: Optional[int] = None,     # frame cap
    npz_cache: Optional[Dict[int, dict]] = None,  # preloaded {step: dict}
):
    """Build colorful GIF frames from a scalar supplier(npz)->(H,W)."""
    safe_mkdir(Path(out_gif).parent.as_posix())

    # Choose which steps we’ll animate
    steps = sampled_steps(idx, stride=step_stride, max_frames=max_frames)

    # Global vmin/vmax (used for normalize="global")
    samples = []
    for s in steps:
        npz = (npz_cache or {}).get(s) or load_field_npz(idx, s)
        if npz is None:
            continue
        f = supplier(npz)
        if f is None:
            continue
        if ds_factor:
            f = downsample(f, ds_factor)
        v = f[np.isfinite(f)]
        if v.size:
            samples.append(v)
    vmin, vmax = pclip_global(samples, *percentile)

    frames = []
    for s in steps:
        npz = (npz_cache or {}).get(s) or load_field_npz(idx, s)
        if npz is None:
            continue

        mask = get_mask(npz, agent_idx)
        f = supplier(npz)
        if f is None:
            continue

        if ds_factor:
            f = downsample(f, ds_factor)
            if mask is not None:
                mask = downsample(mask.astype(float), ds_factor) > 0.5

        # Per-frame normalization if requested
        if normalize == "per_frame":
            vv = f[np.isfinite(f)]
            if vv.size:
                lo, hi = np.percentile(vv, list(percentile))
                vfmin = float(lo) if np.isfinite(lo) else float(np.min(vv))
                vfmax = float(hi) if np.isfinite(hi) else float(np.max(vv))
                if vfmax <= vfmin:
                    vfmax = vfmin + 1e-9
            else:
                vfmin, vfmax = vmin, vmax
        else:
            vfmin, vfmax = vmin, vmax

        # Colorize + overlay + layout
        rgb = colorize_scalar(f, vfmin, vfmax, cmap_name=cmap)
        if add_mask_outline and mask is not None:
            rgb = overlay_mask_outline(rgb, mask)
        rgb = auto_scale(rgb, min_side=min_side)

        # Pad to friendly size
        h, w = rgb.shape[:2]
        pad_h = ((h + 31) // 32) * 32
        pad_w = ((w + 31) // 32) * 32
        rgb = center_pad(rgb, pad_h, pad_w, pad_val=0)

        # Caption + colorbar
        frame = caption_top(rgb, f"{title} | step={s}", banner_px=28)
        if show_colorbar:
            frame = draw_colorbar_h(frame, vfmin, vfmax, cmap_name=cmap, bar_height=12, pad=6)

        frames.append(frame.astype(np.uint8))

    if not frames:
        print(f"[WARN] No frames for {title} (agent {agent_idx}).")
        return

    with imageio.get_writer(out_gif, mode="I", loop=0, duration=duration) as wr:
        for fr in frames:
            wr.append_data(fr)
    print(f"[GIF] {out_gif}")




# ─────────────────────────────────────────────────────────────────────────────
# High-level GIF makers
# ─────────────────────────────────────────────────────────────────────────────
def make_mu_gifs(idx: RunIndex, outdir: str, agent_idx: int,
                 comps: Sequence[int] = (0,1,2), ds: Optional[int] = None,
                 *, step_stride: int = 1, max_frames: Optional[int] = None,
                 npz_cache: Optional[Dict[int, dict]] = None):
    for key in ("mu_q", "mu_p"):
        npz0 = load_field_npz(idx, idx.steps[0]) if idx.steps else None
        if npz0 is None or key not in npz0:
            continue
        K = npz0[key].shape[-1]
        use_comps = [k for k in comps if k < K]
        for k in use_comps:
            out_gif = os.path.join(outdir, f"{key}_c{k}_a{agent_idx}.gif")
            animate_scalar_supplier(
                idx, out_gif,
                supplier=lambda Z, k=k: mu_component(Z, key, agent_idx, k),
                title=f"{key}[{k}]",
                agent_idx=agent_idx, ds_factor=ds,
                normalize="per_frame", show_colorbar=True,
                step_stride=step_stride, max_frames=max_frames, npz_cache=npz_cache,
            )

def make_sigma_gifs(idx: RunIndex, outdir: str, agent_idx: int,
                    summaries: Sequence[str] = ("trace","logdet","min_eig","max_eig","cond"),
                    ds: Optional[int] = None,
                    *, step_stride: int = 1, max_frames: Optional[int] = None,
                    npz_cache: Optional[Dict[int, dict]] = None):
    for key in ("sigma_q", "sigma_p"):
        npz0 = load_field_npz(idx, idx.steps[0]) if idx.steps else None
        if npz0 is None or key not in npz0:
            continue
        for how in summaries:
            out_gif = os.path.join(outdir, f"{key}_{how}_a{agent_idx}.gif")
            animate_scalar_supplier(
                idx, out_gif,
                supplier=lambda Z, how=how: sigma_summary(Z, key, agent_idx, how),
                title=f"{key} {how}",
                agent_idx=agent_idx, ds_factor=ds,
                normalize="global", show_colorbar=True,
                step_stride=step_stride, max_frames=max_frames, npz_cache=npz_cache,
            )

def make_morphism_gifs(idx: RunIndex, outdir: str, agent_idx: int,
                       ds: Optional[int] = None,
                       *, step_stride: int = 1, max_frames: Optional[int] = None,
                       npz_cache: Optional[Dict[int, dict]] = None):
    for key in ("phi_q_to_p", "phi_p_to_q"):
        npz0 = load_field_npz(idx, idx.steps[0]) if idx.steps else None
        if npz0 is None or key not in npz0:
            continue
        out_gif = os.path.join(outdir, f"{key}_fro_a{agent_idx}.gif")
        animate_scalar_supplier(
            idx, out_gif,
            supplier=lambda Z: frob_norm(Z, key, agent_idx),
            title=f"{key} ||·||_F",
            agent_idx=agent_idx, ds_factor=ds,
            normalize="global", show_colorbar=True,
            step_stride=step_stride, max_frames=max_frames, npz_cache=npz_cache,
        )

def make_vector_norm_gifs(idx: RunIndex, outdir: str, agent_idx: int,
                          ds: Optional[int] = None,
                          *, step_stride: int = 1, max_frames: Optional[int] = None,
                          npz_cache: Optional[Dict[int, dict]] = None):
    for key in ("phi", "phi_model"):
        npz0 = load_field_npz(idx, idx.steps[0]) if idx.steps else None
        if npz0 is None or key not in npz0:
            continue
        out_gif = os.path.join(outdir, f"{key}_norm_a{agent_idx}.gif")
        animate_scalar_supplier(
            idx, out_gif,
            supplier=lambda Z: vec_norm(Z, key, agent_idx),
            title=f"{key} norm",
            agent_idx=agent_idx, ds_factor=ds,
            normalize="per_frame", show_colorbar=True,
            step_stride=step_stride, max_frames=max_frames, npz_cache=npz_cache,
        )

def make_alignment_kl_gifs(idx: RunIndex, outdir: str, agent_idx: int,
                           ds: Optional[int] = None,
                           *, step_stride: int = 1, max_frames: Optional[int] = None,
                           npz_cache: Optional[Dict[int, dict]] = None):
    keys = ["belief_align","model_align","kl_self","kl_feedback"]
    npz0 = load_field_npz(idx, idx.steps[0]) if idx.steps else None
    for key in keys:
        if npz0 is None or key not in npz0:
            continue
        out_gif = os.path.join(outdir, f"{key}_a{agent_idx}.gif")
        animate_scalar_supplier(
            idx, out_gif,
            supplier=lambda Z, key=key: scalar_from_key(Z, key, agent_idx),
            title=key,
            agent_idx=agent_idx, ds_factor=ds,
            normalize="global", show_colorbar=True,
            step_stride=step_stride, max_frames=max_frames, npz_cache=npz_cache,
        )

def make_curvature_norm_gifs(idx: RunIndex, outdir: str, agent_idx: int,
                             ds: Optional[int] = None,
                             *, step_stride: int = 1, max_frames: Optional[int] = None,
                             npz_cache: Optional[Dict[int, dict]] = None):
    keys = ["Fq_norm","Fp_norm"]
    npz0 = load_field_npz(idx, idx.steps[0]) if idx.steps else None
    for key in keys:
        if npz0 is None or key not in npz0:
            continue
        out_gif = os.path.join(outdir, f"{key}_a{agent_idx}.gif")
        animate_scalar_supplier(
            idx, out_gif,
            supplier=lambda Z, key=key: scalar_from_key(Z, key, agent_idx),
            title=key,
            agent_idx=agent_idx, ds_factor=ds,
            normalize="global", show_colorbar=True,
            step_stride=step_stride, max_frames=max_frames, npz_cache=npz_cache,
        )

# ─────────────────────────────────────────────────────────────────────────────
# Orchestrator (no CLI)
# ─────────────────────────────────────────────────────────────────────────────

# at top if not already:
from concurrent.futures import ThreadPoolExecutor, as_completed
import os

# helper stubs (only include if you don't already have them)
# def sampled_steps(idx: RunIndex, stride: int = 1, max_frames: Optional[int] = None) -> List[int]: ...
# def load_all_npz(idx: RunIndex, steps: Optional[List[int]] = None, mmap: bool = True) -> Dict[int, dict]: ...

def _make_all_for_agent_worker(
    checkpoints_dir: str,
    outdir_agent: str,
    agent_idx: int,
    ds_factor: Optional[int],
    step_stride: int,
    max_frames: Optional[int],
):
    """Thread worker: preload NPZ once and render the whole suite for one agent."""
    safe_mkdir(outdir_agent)
    idx = build_index(checkpoints_dir)
    if not idx.steps:
        return f"agent {agent_idx}: no steps"

    steps = sampled_steps(idx, stride=step_stride, max_frames=max_frames)
    npz_cache = load_all_npz(idx, steps=steps, mmap=True)

    make_mu_gifs(idx, os.path.join(outdir_agent, "mu"), agent_idx, comps=(0,1,2),
                 ds=ds_factor, step_stride=step_stride, max_frames=max_frames, npz_cache=npz_cache)
    make_sigma_gifs(idx, os.path.join(outdir_agent, "sigma"), agent_idx,
                    summaries=("trace","logdet","min_eig","max_eig","cond"),
                    ds=ds_factor, step_stride=step_stride, max_frames=max_frames, npz_cache=npz_cache)
    make_morphism_gifs(idx, os.path.join(outdir_agent, "morphisms"), agent_idx,
                       ds=ds_factor, step_stride=step_stride, max_frames=max_frames, npz_cache=npz_cache)
    make_vector_norm_gifs(idx, os.path.join(outdir_agent, "phi"), agent_idx,
                          ds=ds_factor, step_stride=step_stride, max_frames=max_frames, npz_cache=npz_cache)
    make_alignment_kl_gifs(idx, os.path.join(outdir_agent, "alignment"), agent_idx,
                           ds=ds_factor, step_stride=step_stride, max_frames=max_frames, npz_cache=npz_cache)
    make_curvature_norm_gifs(idx, os.path.join(outdir_agent, "curvature"), agent_idx,
                             ds=ds_factor, step_stride=step_stride, max_frames=max_frames, npz_cache=npz_cache)
    return f"agent {agent_idx}: done"

def run_gif_suite(
    checkpoints_dir: str = "checkpoints",
    outdir: str = "reports_gifs",
    n_agents_preview: int = 2,
    ds_factor: Optional[int] = None,       # e.g., 2 or 3 for speed
    max_workers: Optional[int] = None,     # None → sensible default
    step_stride: int = 2,                  # sample every k steps
    max_frames: Optional[int] = 150,       # cap frames per GIF
):
    safe_mkdir(outdir)
    idx = build_index(checkpoints_dir)
    if not idx.steps:
        print(f"[WARN] No field dumps in {checkpoints_dir}/fields")
        return

    if max_workers is None:
        max_workers = max(1, min(n_agents_preview, (os.cpu_count() or 2)))

    futures = []
    with ThreadPoolExecutor(max_workers=max_workers) as ex:
        for a in range(n_agents_preview):
            agent_dir = os.path.join(outdir, f"agent_{a}")
            futures.append(ex.submit(
                _make_all_for_agent_worker,
                checkpoints_dir, agent_dir, a, ds_factor, step_stride, max_frames
            ))
        for fut in as_completed(futures):
            try:
                print("[GIF]", fut.result())
            except Exception as e:
                print(f"[ERR] worker failed: {e}")

    print(f"[DONE] GIFs → {Path(outdir).resolve()}")

# name==main call, no CLI
if __name__ == "__main__":
    run_gif_suite(
        checkpoints_dir="checkpoints",
        outdir="reports_gifs",
        n_agents_preview=2,
        ds_factor=2,          # ← quick wins: downsample
        max_workers=None,
        step_stride=2,        # ← skip every other step
        max_frames=400,       # ← cap length
    )
