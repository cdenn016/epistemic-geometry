# -*- coding: utf-8 -*-
"""
Created on Sun Aug 10 13:08:53 2025

@author: chris and christine
"""
import numpy as np


def init_crossscale_maps(parents, children, Kq, Kp):
    # Identity / zero seeds already attached; here we just sanity-check
    for P in parents:
        # Optional: make Λ_dn the (clipped) inverse of Λ_up if you later update Λ_up
        # For now they’re both I, so nothing to do.
        pass

def check_maps_sanity(parents, atol=1e-6):
    ok = True
    for P in parents:
        Iq = P.Lambda_dn_q @ P.Lambda_up_q
        Ip = P.Lambda_dn_p @ P.Lambda_up_p
        ok &= np.allclose(Iq, np.eye(Iq.shape[0]), atol=atol)
        ok &= np.allclose(Ip, np.eye(Ip.shape[0]), atol=atol)
    return ok
