# -*- coding: utf-8 -*-
"""
Created on Sun Aug 10 16:41:39 2025

@author: chris and 
christine
"""

import numpy as np
# --- so(3) exp/log, numerically stable ---
def _hat3(w):
    wx, wy, wz = w[...,0], w[...,1], w[...,2]
    O = np.zeros(w.shape[:-1] + (3,3), dtype=w.dtype)
    O[...,0,1], O[...,0,2] = -wz,  wy
    O[...,1,0], O[...,1,2] =  wz, -wx
    O[...,2,0], O[...,2,1] = -wy,  wx
    return O

def so3_exp(w, eps=1e-8):
    theta = np.linalg.norm(w, axis=-1, keepdims=True)  # (...,1)
    K = _hat3(w / np.maximum(theta, eps))
    th = theta[...,0]
    th2 = th*th
    A = np.where(th < 1e-4, 1 - th2/6 + th2*th2/120, np.sin(th)/th)
    B = np.where(th < 1e-4, 0.5 - th2/24 + th2*th2/720, (1 - np.cos(th))/(th2 + eps))
    I = np.eye(3, dtype=w.dtype)
    return I + A[...,None,None]*K + B[...,None,None] @ (K @ K)

def so3_log(R, eps=1e-8):
    # clamp trace for numeric stability
    tr = np.clip((np.trace(R, axis1=-2, axis2=-1) - 1)*0.5, -1.0, 1.0)
    th = np.arccos(tr)  # (...,)
    # avoid division by zero at small angle
    denom = np.where(th < 1e-4, 1.0, (2*np.sin(th)+eps)/th)
    w = np.stack([R[...,2,1]-R[...,1,2],
                  R[...,0,2]-R[...,2,0],
                  R[...,1,0]-R[...,0,1]], axis=-1) / denom[...,None]
    return w





def coarsen_phi_from_children(parent, children, field="phi", weight_mode="mask", max_norm=np.pi, eps=1e-6):
    """
    Build parent.{phi or phi_model} by weighted average of children fields.
    - field: "phi" or "phi_model"
    - weight_mode: "mask" (default), or "mask*overlap", or a callable(child)->(H,W,1)
    """
    if not getattr(parent, "child_ids", None):
        return  # nothing to do
    C = len(parent.child_ids)

    # gather child fields
    phi_stack = []
    w_stack   = []
    for cid in parent.child_ids:
        ch = children[cid]
        phi_c = getattr(ch, field)                 # (H, W, 3)
        phi_stack.append(phi_c[..., :3][None, ...])  # ensure shape (1,H,W,3)

        if callable(weight_mode):
            w = weight_mode(ch)  # (H,W,1)
        else:
            if weight_mode == "mask":
                w = ch.mask[..., None]
            elif weight_mode == "mask*overlap":
                w = (ch.mask * parent.mask)[..., None]
            else:
                w = ch.mask[..., None]
        w_stack.append(w[None, ...])

    phi_stack = np.concatenate(phi_stack, axis=0)  # (C,H,W,3)
    w_stack   = np.concatenate(w_stack,   axis=0)  # (C,H,W,1)

    # algebra-space weighted average
    phi_parent = _weighted_mean_field(phi_stack, w_stack, eps=eps)  # (H,W,3)

    # clip to stay in safe radius & sanitize
    # (same style as your existing soft clip; fallback to simple norm clip)
    norms = np.linalg.norm(phi_parent, axis=-1, keepdims=True) + 1e-12
    scale = np.minimum(1.0, max_norm / norms)
    phi_parent = phi_parent * scale

    setattr(parent, field, phi_parent.astype(children[0].mu_q_field.dtype))


def _coarse_grain_gauge_fields(meta_agents, agents):
    for P in meta_agents:
        coarsen_phi_from_children(P, agents, field="phi",       weight_mode="mask")
        coarsen_phi_from_children(P, agents, field="phi_model", weight_mode="mask")


def _field_norm(a, m=None):
    v = np.linalg.norm(a, axis=-1) if a.ndim == 3 else np.linalg.norm(a, axis=(-1, -2))
    if m is not None:
        v = v[m > 1e-6]
    return float(np.nanmean(v)) if v.size else float("nan")


def aggregate_fields(agent_list, attr: str):
    """Average a tensor field (e.g., mu_q_field) over agents."""
    return np.mean([getattr(ag, attr) for ag in agent_list], axis=0)




def _weighted_mean_field(stack, weights, eps=1e-8):
    """
    stack: (C, H, W, D)
    weights: (C, H, W, 1) nonnegative
    returns (H, W, D)
    """
    num = np.sum(weights * stack, axis=0)
    den = np.sum(weights, axis=0) + eps
    return num / den


def seed_lambda_from_phi(children, parents, labels, field="phi", mode="parent_mean", eps=1e-6):
    """
    Λ_dn_* from gauge fields: Λ(x) = exp(φ_child(x)) @ exp(-φ_parent(x)).
    Averages on SO(3) over the overlap mask to get a single 3x3 per parent.
    field: "phi" (q-side) or "phi_model" (p-side)
    mode:  "parent_mean" (default) or "pixel" (store per-pixel Λ field as well)
    """
    labels = np.asarray(labels)
    for pid, P in enumerate(parents):
        # shapes + overlap mask: (child union) ∩ (parent mask, if present)
        if hasattr(P, "mask") and P.mask is not None:
            H, W = P.mask.shape
            M = (P.mask > eps).copy()
        else:
            H, W = children[0].mask.shape
            M = np.zeros((H, W), dtype=bool)

        child_ids = []
        for ci, lab in enumerate(labels):
            if int(lab) == pid:
                child_ids.append(ci)
                M |= (children[ci].mask > eps)

        if not np.any(M):
            # no overlap: leave previous Λ or set identity
            name = "Lambda_dn_q" if field == "phi" else "Lambda_dn_p"
            if getattr(P, name, None) is None:
                setattr(P, name, np.eye(3, dtype=np.float32))
                setattr(P, name.replace("dn", "up"), np.eye(3, dtype=np.float32))
            continue

        # parent gauge field (per-pixel); fallback: average child φ on the overlap
        phi_p = getattr(P, field, None)
        if phi_p is None:
            vals = []
            for ci in child_ids:
                ph = getattr(children[ci], field, None)
                if ph is not None:
                    vals.append(ph[M])  # only where overlapping
            if not vals:
                # as above: keep prior or identity
                name = "Lambda_dn_q" if field == "phi" else "Lambda_dn_p"
                if getattr(P, name, None) is None:
                    setattr(P, name, np.eye(3, dtype=np.float32))
                    setattr(P, name.replace("dn", "up"), np.eye(3, dtype=np.float32))
                continue
            phi_p_mean = np.nanmean(np.concatenate(vals, axis=0), axis=0)  # (3,)
            Rp = so3_exp(phi_p_mean[None, ...])[0]  # (3,3)
        else:
            Rp_field = so3_exp(phi_p.reshape(-1, 3)).reshape(H, W, 3, 3)
            Rp = Rp_field[M]                                   # (N,3,3)
            # average parent rotations over overlap
            # (log–exp mean for stability)
            if Rp.shape[0] > 1:
                w_p = so3_log(Rp)                              # (N,3)
                Rp = so3_exp(np.nanmean(w_p, axis=0, keepdims=True))[0]  # (3,3)
            else:
                Rp = Rp[0]

        # build per-child Λ at overlap: L = Rc @ Rp^T
        L_chunks = []
        for ci in child_ids:
            phi_c = getattr(children[ci], field, None)
            if phi_c is None:
                continue
            Rc = so3_exp(phi_c.reshape(-1, 3)).reshape(H, W, 3, 3)
            Lpix = Rc[M] @ Rp.T                               # (N,3,3)
            if Lpix.size:
                L_chunks.append(Lpix)

        if not L_chunks:
            name = "Lambda_dn_q" if field == "phi" else "Lambda_dn_p"
            if getattr(P, name, None) is None:
                setattr(P, name, np.eye(3, dtype=np.float32))
                setattr(P, name.replace("dn", "up"), np.eye(3, dtype=np.float32))
            continue

        L_all = np.concatenate(L_chunks, axis=0)              # (N_total,3,3)
        # log–exp (Karcher/log-Euclidean) mean on SO(3)
        w = so3_log(L_all)                                    # (N_total,3)
        if not np.isfinite(w).any():
            L_mean = np.eye(3, dtype=np.float32)
        else:
            w_mean = np.nanmean(w, axis=0)                    # (3,)
            L_mean = so3_exp(w_mean[None, ...])[0]            # (3,3)

        # optional: also store per-pixel Λ field if requested
        if mode == "pixel":
            # Note: storing only overlap pixels; expand to full (H,W,3,3) if your code expects that
            setattr(P, "Lambda_dn_q_field" if field == "phi" else "Lambda_dn_p_field", L_all)

        # finalize + set up-map
        # (you can rely on _finalize_lambdas_from_phi, or do it inline)
        U, _, Vt = np.linalg.svd(L_mean)
        R = U @ Vt
        if np.linalg.det(R) < 0:
            U[:, -1] *= -1
            R = U @ Vt

        if field == "phi":
            P.Lambda_dn_q = R.astype(np.float32)
            P.Lambda_up_q = R.T.astype(np.float32)
        else:
            P.Lambda_dn_p = R.astype(np.float32)
            P.Lambda_up_p = R.T.astype(np.float32)


def _finalize_lambdas_from_phi(parents):
    """Project Λ to SO(3) and set 'up' maps as transposes."""
    for P in parents:
        for name in ("Lambda_dn_q", "Lambda_dn_p"):
            L = getattr(P, name, None)
            if L is None: 
                continue
            # SVD projection to nearest rotation
            U, _, Vt = np.linalg.svd(L)
            R = U @ Vt
            # fix potential reflection
            if np.linalg.det(R) < 0:
                U[:, -1] *= -1
                R = U @ Vt
            setattr(P, name, R.astype(np.float32))
            setattr(P, name.replace("dn", "up"), R.T.astype(np.float32))
