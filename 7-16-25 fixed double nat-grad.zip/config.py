import os

# force single‐threaded BLAS/OpenMP everywhere
os.environ["MKL_NUM_THREADS"]     = "1"
os.environ["OMP_NUM_THREADS"]     = "1"
os.environ["OPENBLAS_NUM_THREADS"]= "1"
os.environ["NUMEXPR_NUM_THREADS"] = "1"


import numpy as np
import sys

# ===========================
# DEBUGGING AND UTILITIES
# ===========================

# 1) define at top of your script/module
def scaled_eta(base, *weights, min_den=1.0):
    """
    If all weights sum to zero, return base.
    Otherwise return base / max(sum(weights), min_den).
    """
    total = sum(weights)
    if total <= 0:
        return base
    return base / max(total, min_den)

def set_config_from_params(params):
    """Dynamically override config attributes from a dictionary."""
    this_module = sys.modules[__name__]
    for k, v in params.items():
        setattr(this_module, k, v)

identical_models = False         # If True, all agents share the same p, mu_p_field, sigma_p_field
similar_p_models = False
diagonal_covariance = False  # Toggle: if True, Σ is diagonal; if False, use full MVN
agent_seed    = 141
     

# ===========================
# DOMAIN / SPATIAL SETTINGS
# ===========================
K = 9         # Fiber dimension of belief/model space (depends on representation)
                 # Fast up to K=15 then slow
D = 2            #dimension of base manifold - d=2 validated

L = 20         #length of hypercubic base-manifold - PBCs

steps = 250

N = 2                         # Number of agents
max_neighbors = 2             # Max number of agent neighbors

psi_radius_range = (4,4)         #agent radii
             

# ===========================
# COUPLINGS & PENALTIES
# ===========================

e_belief               = 1
e_model                = 1

alpha                  = 1         # OK as is
beta                   = 1           # scale down with K
gauge_weight           = 1          # down for stability
curvature_weight       = 1

model_feedback_weight  = 0               # OK as is
model_align_weight     = 1
model_mass_weight      = 1
model_curvature_weight = 1

# ===========================
# INITIALIZATION
# ===========================
phi_init_smooth_sigma = 1.5
phi_init              = 0.2
phi_model_offset      = 0.1



eta_base_q         = 4e-6    
eta_base_p         = 4e-6    
eta_base_phi       = 4e-5
eta_base_phi_model = 4e-5    

eta_phi_min        = 1e-3
eta_phi_model_min = 1e-3



# ===========================
# AGENT GEOMETRY
# ===========================
q_mu_range    = (0, K - 1)        # Mean of q
q_sigma_range = (0.1, 4)         # Eigenvalues of Σ_q

p_mu_range    = (0, K - 1)        # Mean of p
p_sigma_range = (0.5, 4)         # Eigenvalues of Σ_p

mu_field_smooth_range    = (3, 4)   # lower = noisier
sigma_field_smooth_range = (0.1, 3)  #alignment is VERY sensitive smaller values => bigger swings

# Sigma field eigenvalue range
sigma_min_eig = 0.4     # minimum eigenvalue of Σ (lower bound on uncertainty)
sigma_max_eig = 4.0     # maximum eigenvalue of Σ (upper bound on uncertainty)

# Controls how sharply uncertainty grows away from support
sigma_decay_sharpness = 1.0  # passed as sigma to gaussian_filter
sigma_outside_mask_value = 1000.0  # or any large value you prefer
                                        
                                        #Controls how much randomness is added after masking, 
                                      #to avoid wiping out variation. Large for texture
mu_anisotropy_range  = (1, 3)       # 1 = round, 3 = stretched
mu_orientation_range = (0.1, np.pi)     # full angle range
mask_sharpness       = 1.5

# ===========================
# STABILITY AND CLIPPING
# ===========================

alignment_grad_clip           = 1e3

gradient_clip                 = 1e3  # You can tune this per experiment

phi_max_norm                  = 6.0
phi_model_max_norm            = 6.0

phi_grad_clip_threshold       = 1e3
phi_model_grad_clip_threshold = 1e3

phi_clip_threshold            = 50  # Optional: to bound exp(φ)
phi_model_clip_threshold      = 50

eta_phi_adaptive_scaling       = 5.0
eta_phi_model_adaptive_scaling = 5.0

eta_sigma_condition_scaling    = 0.01  # dampen updates if cond(Σ) is large


# ===========================
# EPSILONS & PRECISION
# ===========================

log_eps            = 1e-6  #for logs
support_cutoff_eps = 1e-2           #agent and mask overlap = at 1e-1
overlap_eps        = 1e-3   #where to consider computing overlap computations
eps                = 1e-3   #for SPD clipping

epsilon_model                 = 1.0    #detecting meta agents

spd_eps = 1e-6
debug_sanitize_sigma = True

precision = np.float32


# =====if needed/curious ======= #
phi_phi_tilde_coupling = 0
phi_damping            = 0                # leave 0 unless blowup occurs

variance_penalty_model_weight = 0
variance_penalty_weight       = 0

fisher_geometry_weight        = 0
fisher_model_geometry_weight  = 0

# ===========================
# CHECKPOINTING
# ===========================

checkpoint_dir      = "checkpoints"

checkpoint_interval = 1

domain_size = (L,) * D

# 3) replace all the old eta_* calculations with calls to scaled_eta
eta_q = scaled_eta(eta_base_q, alpha, beta)

eta_p = scaled_eta(eta_base_p,
                   alpha,
                   model_align_weight,
                   model_feedback_weight,
                  
                   model_mass_weight)

eta_phi = scaled_eta(eta_base_phi,
                     gauge_weight,
                     
                     curvature_weight,
                     phi_phi_tilde_coupling)

eta_model_phi = scaled_eta(eta_base_phi_model,
                           model_align_weight,
                          
                           model_mass_weight,
                           phi_phi_tilde_coupling
                           )



num_cores = 1  # or however many threads you want to use
log_full_fields = True  # default off
debug = True  # Global debug flag for extra logging inside φ updates


group_name = 'sl2r'               # Options: "u1", "so3", "sl2r", 'su2'.
representation_type = 'irrep'     # Options: 'irrep', 'fundamental', 'adjoint'
from get_generators import get_generators
generators = get_generators(group_name, K)
lie_dim = generators.shape[0]

fail_on_fallback = False
fallback_warn_threshold = 10  # max silent fallbacks before raising
# Maximum allowed safe_inv fallbacks per run before error
max_safe_inv_fallbacks = 10

# Maximum allowed safe_logdet fallbacks per run before error
max_safe_logdet_fallbacks = 10

sanitize_sigma_before_kl = True



debug_sanitize_sigma = True  # Or False by default
debug_gradients = True

