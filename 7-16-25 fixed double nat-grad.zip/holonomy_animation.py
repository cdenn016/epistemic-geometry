import numpy as np
import matplotlib.pyplot as plt
from matplotlib.patches import Ellipse
import matplotlib.animation as animation
from pathlib import Path
import pickle
import re
from sklearn.decomposition import PCA

TRANSPORT_LOG_DIR = Path("holonomy_experiments/transport_logs")
SAVE_DIR_SPATIAL = Path("Holonomy_Visualizations/transport_spatial")
SAVE_DIR_MU      = Path("Holonomy_Visualizations/transport_mu")

def extract_step(fname):
    match = re.search(r"step(\d+)", fname)
    return int(match.group(1)) if match else -1


def animate_mu_pca(mu_seq, save_path):
    """
    Animate μ(t) projected into PCA space over time.
    """
    mu_seq = np.asarray(mu_seq)
    pca = PCA(n_components=2)
    xy_seq = pca.fit_transform(mu_seq)

    xmin, xmax = np.min(xy_seq[:, 0]), np.max(xy_seq[:, 0])
    ymin, ymax = np.min(xy_seq[:, 1]), np.max(xy_seq[:, 1])
    pad = 0.1 * max(xmax - xmin, ymax - ymin)

    fig, ax = plt.subplots(figsize=(5, 5))
    ax.set_xlim(xmin - pad, xmax + pad)
    ax.set_ylim(ymin - pad, ymax + pad)
    ax.set_aspect('equal')

    def update(i):
        ax.clear()
        ax.set_xlim(xmin - pad, xmax + pad)
        ax.set_ylim(ymin - pad, ymax + pad)
        ax.set_title(f"μ PCA — Frame {i+1}/{len(mu_seq)}")

        ax.plot(xy_seq[:i+1, 0], xy_seq[:i+1, 1], 'k-', lw=1, alpha=0.3)
        # Plot start and end points with correct layering
        ax.plot(xy_seq[-1, 0], xy_seq[-1, 1], 'ro', label='End', zorder=1)
        ax.plot(xy_seq[0, 0], xy_seq[0, 1], 'go', label='Start', zorder=2)  # Ensure start is on top

        ax.plot(xy_seq[i, 0], xy_seq[i, 1], 'ro')

        ax.legend()

    ani = animation.FuncAnimation(fig, update, frames=len(mu_seq), interval=250, blit=False)
    Path(save_path).parent.mkdir(parents=True, exist_ok=True)
    ani.save(save_path, writer="pillow")
    plt.close()

def plot_sigma_diagnostics(sigma_seq, save_dir, base_name="sigma"):
    """
    Generate scalar and matrix-entry visualizations of Σ along a transport path.
    - Frobenius norm over path
    - log(det(Σ)) over path
    - Individual Σ[i,j](step) entries if K ≤ 5
    """
    sigma_seq = np.asarray(sigma_seq)
    K = sigma_seq.shape[-1]
    Path(save_dir).mkdir(parents=True, exist_ok=True)

    # ── Frobenius norm ‖Σ‖ over path ──
    fro_norms = [np.linalg.norm(S, ord='fro') for S in sigma_seq]
    plt.figure(figsize=(6, 4))
    plt.plot(fro_norms, 'b-o', lw=1.5)
    plt.title("‖Σ‖_F over Path")
    plt.xlabel("Path Step")
    plt.ylabel("Frobenius Norm")
    plt.tight_layout()
    plt.savefig(Path(save_dir) / f"{base_name}_fro_norm.png")
    plt.close()

    # ── log(det(Σ)) over path ──
    logdets = [np.log(np.linalg.det(S) + 1e-12) for S in sigma_seq]
    plt.figure(figsize=(6, 4))
    plt.plot(logdets, 'g-o', lw=1.5)
    plt.title("log det(Σ) over Path")
    plt.xlabel("Path Step")
    plt.ylabel("log det Σ")
    plt.tight_layout()
    plt.savefig(Path(save_dir) / f"{base_name}_logdet.png")
    plt.close()

    # ── Component-wise Σ[i,j] over path ──
    if K <= 5:
        fig, axs = plt.subplots(K, K, figsize=(3*K, 3*K), sharex=True)
        for i in range(K):
            for j in range(K):
                axs[i, j].plot([S[i, j] for S in sigma_seq], lw=1.2)
                axs[i, j].set_title(f"Σ[{i},{j}] over Path")
        plt.tight_layout()
        plt.savefig(Path(save_dir) / f"{base_name}_components.png")
        plt.close()

def plot_holonomy_vs_step(files_by_step, save_dir, label):
    norms = []
    steps = []

    for fpath in files_by_step:
        step = extract_step(fpath.name)
        try:
            with open(fpath, "rb") as f:
                data = pickle.load(f)

            logH = data.get("logH", None)
            H    = data.get("holonomy", None)

            #print(f"[DEBUG] {fpath.name}: logH={logH is not None}, H={H is not None}")

            if logH is not None:
                norm = np.linalg.norm(logH, ord='fro')
            elif H is not None:
                norm = np.linalg.norm(H - np.eye(H.shape[-1]), ord='fro')
            else:
                continue

            norms.append(norm)
            steps.append(step)
        except Exception as e:
            print(f"[WARN] Failed to load holonomy from {fpath.name}: {e}")

    if not norms:
        print(f"[SKIP] No holonomy data found for label: {label}")
        return

    plt.figure(figsize=(6, 4))
    plt.plot(steps, norms, 'r-o', lw=1.5)
    plt.title(f"‖Holonomy‖ vs Step — {label}")
    plt.xlabel("Simulation Step")
    plt.ylabel("‖log H‖ (Frobenius)")
    plt.tight_layout()

    save_path = Path(save_dir) / f"{label}_holonomy_norm.png"
    plt.savefig(save_path)
    plt.close()
    print(f"[SAVED] {save_path}")



def main():
    all_files = list(TRANSPORT_LOG_DIR.glob("*.pkl"))
    grouped = {}

    for f in all_files:
        label = re.sub(r"step\d+_", "", f.name)
        grouped.setdefault(label, []).append(f)

    SAVE_DIR_SPATIAL.mkdir(parents=True, exist_ok=True)
    SAVE_DIR_MU.mkdir(parents=True, exist_ok=True)

    for label, files in grouped.items():
        if len(files) < 2:
            continue

        files_by_step = sorted(files, key=lambda f: extract_step(f.name))
        f_initial = files_by_step[0]
        f_final   = files_by_step[-1]

        for fpath in [f_initial, f_final]:
            step = extract_step(fpath.name)
            with open(fpath, "rb") as f:
                data = pickle.load(f)

            mu_seq = np.array(data["mu_seq"])
            sigma_seq = np.array(data["sigma_seq"])
            path_coords = np.array(data["transport_path"])
            base_name = fpath.stem

            print(f"[VISUALIZING] {base_name} (length={len(mu_seq)})")

            try:
                animate_mu_pca(
                    mu_seq,
                    save_path=SAVE_DIR_MU / f"{base_name}_pca.gif"
                )
            except Exception as e:
                print(f"[WARN] PCA animation failed for {base_name}: {e}")

            try:
                plot_sigma_diagnostics(
                    sigma_seq,
                    save_dir=SAVE_DIR_MU / f"{base_name}_sigma_diag",
                    base_name=base_name
                )
            except Exception as e:
                print(f"[WARN] Σ diagnostic plot failed for {base_name}: {e}")
            
        try:
            plot_holonomy_vs_step(
                files_by_step,
                save_dir=SAVE_DIR_SPATIAL,
                label=label
                )
        except Exception as e:
            print(f"[WARN] Holonomy plot failed for {label}: {e}")


if __name__ == "__main__":
    main()
