# -*- coding: utf-8 -*-
"""
Created on Tue Jul 15 20:35:20 2025

@author: chris and christine
"""


# Standard library
import os
import time
import multiprocessing
# Third-party
import pickle
import pandas as pd
from update_rules import synchronous_step
# Local configuration & utilities
from pullback_utils import compute_agent_pullback_blocks
from config_utils import set_config_from_params
from get_generators import get_generators

# I/O helpers
from generalized_io_utils import (
    save_step,
    load_checkpoint,
    find_resume_step,
    save_config_to_readme,
)
# 3.5) Compute Lie metrics for φ and φ_model
from natural_gradient_utils import compute_lie_metric
# Agent construction
from generalized_agents import initialize_agents
from generalized_diagnostics_metrics import log_all_metrics_fused, full_field_logger
import config
from generalized_agent_schema import Agent
import numpy as np
from numpy.random import multivariate_normal
from generalized_math_utils import kl_divergence



class ConceptWorld:
    def __init__(self, K=3):
        self.K = K
        self.signals = [f"sig_{i}" for i in range(10)]

from generalized_agents import initialize_agents  # uses your μ, Σ, φ init

from generalized_agents import initialize_agents

def create_agent(world, agent_id, generators):
    """
    Create and return a single agent using initialize_agents(N=1).
    """
    import config
    shape = config.domain_size
    lie_algebra_dim = len(generators)

    agent_list = initialize_agents(
        seed=np.random.randint(0, 1e6),   # new random seed per agent
        domain_size=shape,
        N=1,
        K=config.K,
        lie_algebra_dim=lie_algebra_dim,
        visualize=False,
        fixed_location=False,
    )

    agent = agent_list[0]
    agent.id = agent_id
    return agent

import numpy as np
import config
from generalized_omega import compute_inter_omega

def update_omega_caches(agent_list_i, agent_list_j, generators):
    """
    Populate the internal _exp_phi and _exp_neg_phi caches
    used to compute Omega = exp(φ) and Omega⁻¹ = exp(−φ).
    """
    from generalized_omega import exp_lie_algebra_irrep

    for agent_i in agent_list_i:
        φ_i = agent_i.phi
        agent_i._exp_phi = exp_lie_algebra_irrep(φ_i, generators)
        agent_i._exp_neg_phi = exp_lie_algebra_irrep(-φ_i, generators)

    for agent_j in agent_list_j:
        φ_j = agent_j.phi
        agent_j._exp_phi = exp_lie_algebra_irrep(φ_j, generators)
        agent_j._exp_neg_phi = exp_lie_algebra_irrep(-φ_j, generators)



def emit_signal_and_infer(agent_A, agent_B, generators, params, coord=None, steps=30, verbose=True):
    """
    Emit a signal from agent A's model at a chosen coord,
    inject it into agent B's model field, and let B infer the concept by minimizing KL(q‖p).
    """
    from update_rules import compute_all_gradients
    from numerical_utils import sanitize_sigma
    eps = 1e-8

    eta_q     = params.get("eta_q", 1e-5)
    eta_sigma = params.get("eta_sigma", 1e-6)
    eta_phi   = params.get("eta_phi", 1e-4)

    print(f"[INFO] η_μ = {eta_q}, η_Σ = {eta_sigma}, η_φ = {eta_phi}")

    if coord is None:
        coord = agent_A.center  # (i, j) tuple

    # === 1. Agent A emits a concept (signal) ===
    mu_p_A = agent_A.mu_p_field[coord]
    sigma_p_A = agent_A.sigma_p_field[coord]
    signal = multivariate_normal(mu_p_A, sigma_p_A)

    if verbose:
        print(f"[SIGNAL] Emitted signal from Agent A @ {coord}:")
        print("μ_p =", mu_p_A)
        print("→ sample =", signal)

    # === 2. Inject into Agent B's model at same coord ===
    agent_B.mu_p_field[coord] = signal
    agent_B.sigma_p_field[coord] = np.eye(signal.shape[0]) * 0.1  # sharp model

    update_omega_caches([agent_B], [agent_A], generators)

    # === 3. Run update loop on B ===
    agents = [agent_A, agent_B]
    full_params = {**params, "generators": generators}

    for step in range(steps):
        (dmu, dsigma), _, dphi, _ = compute_all_gradients(1, agents, full_params)

        # DESCENT
        agent_B.mu_q_field -= eta_q * np.einsum("...ij,...j->...i", agent_B.sigma_q_field, dmu)

        agent_B.sigma_q_field -= eta_sigma * 2 * np.einsum("...ik,...kl,...lj->...ij",
                                                   agent_B.sigma_q_field,
                                                   dsigma,
                                                   agent_B.sigma_q_field)

        agent_B.sigma_q_field = sanitize_sigma(agent_B.sigma_q_field)
        agent_B.phi            -= eta_phi   * dphi

        # Sanitize after update
        agent_B.sigma_q_field = sanitize_sigma(agent_B.sigma_q_field)

        if verbose:
            norm_mu = np.linalg.norm(dmu)
            norm_sigma = np.linalg.norm(dsigma)
            print(f"‖Δμ_q‖ = {norm_mu:.4e}, ‖ΔΣ_q‖ = {norm_sigma:.4e}")

            if step % 10 == 0:
                mu_q = agent_B.mu_q_field[coord]
                sigma_q = agent_B.sigma_q_field[coord]
                eigvals = np.linalg.eigvalsh(sigma_q)
                kl = kl_divergence(
                    mu_q[None, :], sigma_q[None, :, :],
                    signal[None, :], np.eye(signal.shape[0])[None, :, :] * 0.1
                )
                print(f"[STEP {step}] KL(q‖signal) = {kl.item():.4f}, Σ eigvals ∈ [{eigvals.min():.2e}, {eigvals.max():.2e}]")

    return signal


# config.py
log_pullback = True  # set True to re-enable pullback logging
num_cores = 18

def run_simulation(
    outdir="checkpoints",
    resume=False,
    log_metrics=True,
    log_fields=True,
    num_cores=None,
    params=None,
):
    import config
    from numerical_utils import reset_fallback_counters
    reset_fallback_counters()

    if num_cores is None:
        num_cores = 18

    if params:
        set_config_from_params(params)

    os.makedirs(outdir, exist_ok=True)
    save_config_to_readme(outdir)

    generators = get_generators(config.group_name, config.K)
    _, G_inv = compute_lie_metric(generators)
    params = params or {}
    params["G_inv_phi"] = G_inv
    params["G_inv_phi_model"] = G_inv    
    vis_inds, dark_inds = [0, 1], [2]

    if resume:
        agents, _ = load_checkpoint(outdir)
        step_start = find_resume_step(outdir)
    else:
        lie_dim = generators.shape[0]
        agents = initialize_agents(
            seed=getattr(config, "seed", None),
            domain_size=config.domain_size,
            N=config.N,
            K=config.K,
            lie_algebra_dim=lie_dim,
            visualize=False,
            fixed_location=False,
        )
        step_start = 0

    metric_log = []
    print(f"[RUN] Starting simulation at step {step_start} with {num_cores} cores")

    for step in range(step_start, config.steps):
        print(f"\n[STEP {step}] -----------------------------")

        # 5a) Gradient update
        t0 = time.perf_counter()
        step_params = dict(params)
        step_params["step"] = step
        agents = synchronous_step(
            agents, generators, params=step_params, n_jobs=num_cores
        )
        t1 = time.perf_counter()
        print(f"[TIMER] synchronous update: {t1 - t0:.3f}s")

        # 5b) Scalar diagnostics
        if log_metrics:
            t0 = time.perf_counter()
            m = log_all_metrics_fused(
                agents, step=step, params=params, n_jobs=num_cores
            )
            metric_log.append({"step": step, **m})
            t1 = time.perf_counter()
            print(f"[TIMER] log_all_metrics_fused: {t1 - t0:.3f}s")

        # 5b.5) Optional pullback blocks (attach to agents)
        if log_fields and getattr(config, "log_pullback", False):
            for A in agents:
                pull = compute_agent_pullback_blocks(A, vis_inds, dark_inds)
                A.pullback_I      = pull["I"]
                A.pullback_G      = pull["G"]
                A.pullback_M_vis  = pull["M_vis"]
                A.pullback_M_dark = pull["M_dark"]
                A.pullback_Delta  = pull["Delta"]

        # 5c) Full-step field dumps only
        if log_fields and getattr(config, "log_full_fields", False):
            t0_fields = time.perf_counter()
            field_dir = os.path.join(outdir, "fields")
            full_field_logger(agents, step, field_dir)
            t1_fields = time.perf_counter()
            print(f"[TIMER] full_step_field_logger: {t1_fields - t0_fields:.3f}s")

        # 5d) Save checkpoint
        for A in agents:
            A.clear_omega_cache()
        save_step(agents, outdir, step)
        print(f"[SAVE] Checkpoint → {outdir}/step_{step:04d}.pkl")

    # 6) Final logs
    if log_metrics:
        with open(os.path.join(outdir, "metric_log.pkl"), "wb") as f:
            pickle.dump(metric_log, f)
        print(f"[SAVE] Metrics log → {outdir}/metric_log.pkl")

        rows = []
        for A in agents:
            for entry in A.metrics_log:
                rows.append({"agent": A.id, **entry})
        df_agents = pd.DataFrame(rows)
        df_agents.to_csv(
            os.path.join(outdir, "per_agent_metrics.csv"), index=False
        )
        print("[SAVE] Per-agent metrics → per_agent_metrics.csv")

    print("[DONE] Simulation completed.")

    from numerical_utils import report_and_maybe_fail
    report_and_maybe_fail()

    return agents, metric_log



# ————— Your emit_signal_and_infer definition goes above —————

if __name__ == "__main__":
    from get_generators import get_generators
    import config
    eta_sigma = 2e-7
    world = ConceptWorld(K=config.K)
    generators = get_generators(config.group_name, config.K)
    agents = [create_agent(world, i, generators) for i in range(config.N)]

    params = {
        "alpha": config.alpha,
        "beta": 1,
        "eta_phi": config.eta_phi,
        "eta_q": config.eta_q,
        "eta_sigma": eta_sigma,
    }

    emit_signal_and_infer(agents[0], agents[1], generators, params, steps=300)
