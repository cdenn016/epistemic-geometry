import numpy as np
from scipy.linalg import expm
from update_transport_gradients import compute_phi_gradient_via_transport
from update_phi_terms import compute_phi_update
from update_field_terms import combine_field_gradients
from natural_gradient_utils import apply_natural_gradient_batch
from get_generators import get_generators
import config
from update_rules import apply_phi_updates

def kl_divergence_mvg(mu_q, sigma_q, mu_p, sigma_p, eps=1e-8, reduce="mean"):
    """
    KL divergence between MVGs: KL(q || p) where both are N(mu, Sigma).
    """
    mu_q = np.atleast_2d(mu_q)
    mu_p = np.atleast_2d(mu_p)
    sigma_q = np.atleast_3d(sigma_q)
    sigma_p = np.atleast_3d(sigma_p)

    K = mu_q.shape[-1]
    eye = np.eye(K)[None, :, :]  # broadcastable identity
    sigma_p_inv = np.linalg.inv(sigma_p + eps * eye)

    diff = mu_p - mu_q              # (..., K)
    diff = diff[..., None]         # (..., K, 1)

    term1 = np.einsum("...ij,...jk->...ik", sigma_p_inv, sigma_q)         # Tr(Σ⁻¹Σ_q)
    term1 = np.trace(term1, axis1=-2, axis2=-1)

    term2 = np.einsum("...ij,...jk,...ki->...", diff.transpose(0,2,1), sigma_p_inv, diff)  # (μ_p−μ_q)ᵀ Σ⁻¹ (μ_p−μ_q)

    det_q = np.linalg.det(sigma_q + eps * eye)
    det_p = np.linalg.det(sigma_p + eps * eye)
    term4 = np.log(det_p / det_q)

    kl = 0.5 * (term1 + term2 - K + term4)

    if reduce == "mean":
        return np.mean(kl)
    elif reduce == "sum":
        return np.sum(kl)
    else:
        return kl



class ConceptWorld:
    def __init__(self, K=3):
        self.K = K
        self.signals = [f"sig_{i}" for i in range(10)]

def exp_lie_algebra_irrep(phi, generators):
    from scipy.linalg import expm
    return np.array([expm(np.tensordot(p, generators, axes=1)) for p in phi])

def compute_omega(agent_i, agent_j, generators):
    # use flat phase vectors so exp_lie_algebra_irrep yields a (K,K) matrix
    phi_i = agent_i.phi_vec[None, :]
    phi_j = agent_j.phi_vec[None, :]
    Omega_i = exp_lie_algebra_irrep(phi_i, generators)[0]
    Omega_j = exp_lie_algebra_irrep(phi_j, generators)[0]
    return Omega_i @ np.linalg.inv(Omega_j)

class Agent:
    def __init__(self, world, agent_id, generators):
        self.id = agent_id
        self.world = world
        self.K = world.K
        self.generators = generators

        # Belief & model fields
        self.mu_q = np.random.randn(self.K)
        self.sigma_q = np.eye(self.K)
        self.mu_p = np.random.randn(len(world.signals), self.K)
        self.sigma_p = np.tile(
            np.eye(self.K)[None, :, :],
            (len(world.signals), 1, 1)
        )

        # 3D phase fields (H=1, W=1, d) for gradient routines
        d = generators.shape[0]
        self.phi       = 0.01 * np.random.randn(1, 1, d)
        self.phi_model = 0.01 * np.random.randn(1, 1, d)

        # Flat phase vectors for compute_omega
        self.phi_vec       = self.phi.reshape(-1, d).mean(axis=0)
        self.phi_model_vec = self.phi_model.reshape(-1, d).mean(axis=0)

        # Gradient placeholders
        self.grad_phi       = np.zeros_like(self.phi)
        self.grad_phi_model = np.zeros_like(self.phi_model)

        # Transport caches
        self.Omega = np.eye(self.K)
        self.Phi   = np.eye(self.K) + 0.01 * np.random.randn(self.K, self.K)

        #––– compatibility for core update modules –––#
        self.mask = np.ones((1, 1))         # so mask[...,None] works
        self.neighbors = []                 # empty by default

        # field aliases; ensure mu_*_field is 3D and sigma_*_field is 4D
        # q‑fields
        self.mu_q_field    = self.mu_q[None, None, :]
        self.sigma_q_field = self.sigma_q[None, None, :, :]
        # p‑fields
        # shape: (N_signals, H=1, W=1, K)
        self.mu_p_field    = self.mu_p[:, None, None, :]
        # shape: (N_signals, H=1, W=1, K, K)
        self.sigma_p_field = self.sigma_p[:, None, None, :, :]

    def emit_signal(self):
        scores = []
        for s in range(len(self.world.signals)):
            kl = kl_divergence_mvg(
                self.mu_q, self.sigma_q,
                self.mu_p[s], self.sigma_p[s]
            )
            scores.append(-kl)
        probs = np.exp(scores - np.max(scores))
        probs /= probs.sum()
        return np.random.choice(len(probs), p=probs)

    def update_belief(self, signal_idx):
        mu_p = self.mu_p[signal_idx]
        sigma_p = self.sigma_p[signal_idx]
        sigma_q_inv = np.linalg.inv(self.sigma_q)
        sigma_p_inv = np.linalg.inv(sigma_p)
        sigma_new_inv = sigma_q_inv + sigma_p_inv
        sigma_new = np.linalg.inv(sigma_new_inv)
        mu_new = sigma_new @ (
            sigma_q_inv @ self.mu_q + sigma_p_inv @ mu_p
        )
        self.mu_q = mu_new
        self.sigma_q = sigma_new



def run_communication_sim(world, agents, generators, steps=10):
    log = []
    eta_q = getattr(config, "eta_q", 0.005)
    eta_sigma = getattr(config, "eta_sigma", 0.001)
    params = {
    # Semantic inference terms
    "alpha": 1,
    "belief_feedback_weight":1,
    "variance_penalty_belief_weight": 0,   # optionally add

    # Epistemic gauge alignment
    "beta": 1,

    # φ regularizers
    "gauge_weight": 100,
    "curvature_weight": 100,

    # Lie group generators
    "generators": generators,

    # φ learning control
    "phi_lr": 1e-5,
    "phi_update_bound": 10.0,
}

    for t in range(steps):
        A, B = agents[0], agents[1]
        signal = A.emit_signal()

        # 1) Bayesian belief update
        mu_q_prev = B.mu_q.copy()
        B.update_belief(signal)

        # 2) Compute Omegas
        A.Omega = compute_omega(A, B, generators)
        B.Omega = compute_omega(B, A, generators)

        # 3) Diagnostics
        kl_qp = kl_divergence_mvg(B.mu_q, B.sigma_q,
                                  B.mu_p[signal], B.sigma_p[signal])
        mu_align = B.Omega @ A.mu_q
        sigma_align = B.Omega @ A.sigma_q @ B.Omega.T
        kl_align = kl_divergence_mvg(B.mu_q, B.sigma_q,
                                     mu_align, sigma_align)
        delta_mu = np.linalg.norm(B.mu_q - mu_q_prev)
        entropy = 0.5 * np.log(np.linalg.det(B.sigma_q) + 1e-8)
        phi_norm = np.linalg.norm(B.phi)

        log.append({
            'step': t,
            'signal': signal,
            'KL(q||p)': kl_qp,
            'KL(q||Ωq)': kl_align,
            '||Δμ_q||': delta_mu,
            'H[q]': entropy,
            '||φ||': phi_norm
        })

        # 5) φ‐gradient + update for B
        grad_phi_B = compute_phi_gradient_via_transport(
            B, agents, generators, field="phi", params=params
        )
        if grad_phi_B is None:
            grad_phi_B = np.zeros_like(B.phi)
        B.grad_phi = grad_phi_B
        # apply φ updates (no model‐φ in this loop)
        apply_phi_updates(B, grad_phi_B, np.zeros_like(B.phi_model), B.mask, params)

      

        # 6) φ‐gradient + update for A
        grad_phi_A = compute_phi_gradient_via_transport(
            A, agents, generators, field="phi", params=params
        )
        if grad_phi_A is None:
            grad_phi_A = np.zeros_like(A.phi)
        A.grad_phi = grad_phi_A
        apply_phi_updates(A, grad_phi_A, np.zeros_like(A.phi_model), A.mask, params)

        # ── cache exp(phi) for alignment gradients ──
        # (only if φ changed significantly to save cost)
        B._exp_phi       = exp_lie_algebra_irrep(B.phi,       generators)
        A._exp_phi       = exp_lie_algebra_irrep(A.phi,       generators)
        # φ_model isn’t updated in this loop, but keep for consistency
        B._exp_phi_model = exp_lie_algebra_irrep(B.phi_model, generators)
        A._exp_phi_model = exp_lie_algebra_irrep(A.phi_model, generators)

        # — temporarily override p–fields so self‐KL uses only the current signal — 
        mu_p_saved    = B.mu_p_field
        sigma_p_saved = B.sigma_p_field
        B.mu_p_field    = B.mu_p[signal][None, None, :]
        B.sigma_p_field = B.sigma_p[signal][None, None, :, :]
        
        # assign gradient to agent before update
        A.grad_phi = grad_phi_A
        # 7) μ/Σ gradients (may include a signal dimension at axis=0)
        mu_grad, sigma_grad = combine_field_gradients(
            B, agents, params, field_type="belief"
        )
        # if there's a signal axis (e.g. shape (Nsig,1,1,K)), sum over it
        if mu_grad.ndim == 4:
            mu_grad = mu_grad.sum(axis=0)        # -> (1,1,K)
        if sigma_grad.ndim == 5:
            sigma_grad = sigma_grad.sum(axis=0)  # -> (1,1,K,K)

        # 8) lift to 4D for natural gradient
        mu_grad_field    = mu_grad    # already (1,1,K)
        sigma_grad_field = sigma_grad # already (1,1,K,K)
        # apply natural gradient on the (1,1,K) and (1,1,K,K) fields
        delta_mu_field, delta_sigma_field = apply_natural_gradient_batch(
           B.mu_q_field, B.sigma_q_field,
            mu_grad_field, sigma_grad_field
        )
        # collapse back to 1D for storage
        delta_mu_vec    = delta_mu_field.squeeze()
        delta_sigma_mat = delta_sigma_field.squeeze()
        # use norms for scalar logging
        delta_mu    = np.linalg.norm(delta_mu_vec)
        delta_sigma = np.linalg.norm(delta_sigma_mat)
        B.mu_q    -= eta_q    * delta_mu_vec
        B.sigma_q -= eta_sigma * delta_sigma_mat

        # restore original p_fields for next iteration
        B.mu_p_field    = mu_p_saved
        B.sigma_p_field = sigma_p_saved
        print(
            f"Step {t:02d}: KL(q||p)={kl_qp:.4f}, "
            f"Align={kl_align:.4f}, Δμ_norm={delta_mu:.4f}, "
            f"H={entropy:.4f}, ||φ||={phi_norm:.4f}"
        )

    return log

import matplotlib.pyplot as plt

def plot_log_timeseries(log, outdir="comms_plots"):
    import os
    os.makedirs(outdir, exist_ok=True)

    steps = [entry["step"] for entry in log]
    keys = [k for k in log[0] if k != "step" and k != "signal"]

    for key in keys:
        values = [entry[key] for entry in log]
        plt.figure(figsize=(6, 4))
        plt.plot(steps, values, label=key)
        plt.xlabel("Step")
        plt.ylabel(key)
        plt.title(f"{key} over time")
        plt.grid(True)
        plt.tight_layout()
        plt.savefig(f"{outdir}/{key.replace('|', '')}.png")
        plt.close()


if __name__ == "__main__":
    world = ConceptWorld(K=3)
    
    generators = get_generators("sl2r", world.K)
    agents = [Agent(world, i, generators) for i in range(2)]
    run_communication_sim(world, agents, generators, steps=150)
    
    log = run_communication_sim(world, agents, generators, steps=150)
    plot_log_timeseries(log)