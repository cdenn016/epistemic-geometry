
"""
Gradient terms for belief and model fibers (μ, Σ).
Handles KL(q‖p), KL(p‖q), alignment, and regularizers.
"""

import numpy as np
import config

from natural_gradient_utils import apply_natural_gradient_batch, sanitize_sigma
from mask_utils import clip_and_mask_gradient
from numerical_utils import safe_inv
from natural_gradient_utils import compute_alignment_kl_gradient
from get_generators import get_generators
from natural_gradient_utils import apply_lie_natural_gradient, compute_inverse_fisher_field
from mask_utils import clip_and_mask_gradient
from generalized_math_utils import unpack_phi_update_params
from generalized_omega import compute_curvature_gradient_analytical
from numerical_utils import safe_inv
import numpy as np
import config

from numerical_utils import sanitize_sigma
import config
import numpy as np
from generalized_omega import compute_omega_pair, dexpinv_operator
from numerical_utils import sanitize_sigma, safe_inv


from natural_gradient_utils import compute_fisher_geometry_gradient

def zero_mu_sigma_like(agent_i, field="model"):
    mu_attr = f"mu_{'p' if field == 'model' else 'q'}_field"
    sigma_attr = f"sigma_{'p' if field == 'model' else 'q'}_field"
    return np.zeros_like(getattr(agent_i, mu_attr)), np.zeros_like(getattr(agent_i, sigma_attr))

def compute_mu_sigma_diff(mu_a, sigma_a, mu_b, sigma_b, direction="a_minus_b"):
    if direction == "a_minus_b":
        d_mu = mu_a - mu_b
        d_sigma = 0.5 * (sigma_a - sigma_b)
    elif direction == "b_minus_a":
        d_mu = mu_b - mu_a
        d_sigma = 0.5 * (sigma_b - sigma_a)
    else:
        raise ValueError(f"Unknown direction: {direction}")
    return d_mu, d_sigma

def apply_mask_to_mu_sigma(mu, sigma, mask):
    mu = np.where(mask[..., None], mu, 0)
    sigma = np.where(mask[..., None, None], sigma, 0)
    return mu, sigma

# --- Individual Gradient Terms ---

def grad_self_field(agent_i, alpha, field_type="model", mask=None):
    """
    Raw Euclidean gradient of KL(q || p) or KL(p || q), depending on field_type.
    Natural gradient is applied centrally in combine_field_gradients.

    Args:
        agent_i   : Agent object with belief/model fields
        alpha     : Scalar weight on self-consistency
        field_type: "model" for KL(p || q), "belief" for KL(q || p)
        mask      : Optional spatial mask

    Returns:
        (dμ, dΣ) : Euclidean gradients of the self-alignment term
    """
    if alpha <= 0:
        return zero_mu_sigma_like(agent_i)

    if field_type == "model":
        μ_self, Σ_self = agent_i.mu_p_field, agent_i.sigma_p_field
        μ_other, Σ_other = agent_i.mu_q_field, agent_i.sigma_q_field
    elif field_type == "belief":
        μ_self, Σ_self = agent_i.mu_q_field, agent_i.sigma_q_field
        μ_other, Σ_other = agent_i.mu_p_field, agent_i.sigma_p_field
    else:
        raise ValueError(f"[grad_self_field] Unknown field_type: {field_type}")

    Σ_other = sanitize_sigma(Σ_other, eps=config.eps)
    dμ, dΣ = compute_mu_sigma_diff(μ_self, Σ_self, μ_other, Σ_other, direction="a_minus_b")

    dμ = np.nan_to_num(dμ)
    dΣ = np.nan_to_num(dΣ)

    if mask is not None:
        dμ, dΣ = apply_mask_to_mu_sigma(dμ, dΣ, mask)

    return alpha * dμ, alpha * dΣ



def grad_feedback_field(agent_i, feedback_weight, field_type="model", mask=None):
    """
    Raw Euclidean gradient of KL(other || self), i.e. ∇_self KL(p || q).
    Preconditioning (natural gradient) should be applied centrally.

    Args:
        agent_i        : focal agent
        feedback_weight: scalar multiplier
        field_type     : "model" or "belief"
        mask           : optional spatial mask

    Returns:
        (dμ, dΣ) : Euclidean gradients
    """
    if feedback_weight <= 0:
        return zero_mu_sigma_like(agent_i, field=field_type)

    if field_type == "model":
        μ_self, Σ_self = agent_i.mu_p_field, agent_i.sigma_p_field
        μ_other, Σ_other = agent_i.mu_q_field, agent_i.sigma_q_field
    elif field_type == "belief":
        μ_self, Σ_self = agent_i.mu_q_field, agent_i.sigma_q_field
        μ_other, Σ_other = agent_i.mu_p_field, agent_i.sigma_p_field
    else:
        raise ValueError(f"[grad_feedback_field] Unknown field_type: {field_type}")

    Σ_self  = sanitize_sigma(Σ_self, eps=config.eps)
    Σ_other = sanitize_sigma(Σ_other, eps=config.eps)

    dμ, dΣ = compute_mu_sigma_diff(μ_self, Σ_self, μ_other, Σ_other, direction="b_minus_a")

    dμ = np.nan_to_num(dμ)
    dΣ = np.nan_to_num(dΣ)

    if mask is not None:
        dμ, dΣ = apply_mask_to_mu_sigma(dμ, dΣ, mask)

    return feedback_weight * dμ, feedback_weight * dΣ



def grad_variance_penalty_field(agent_i, lambda_, field_type="model", mask=None):
    """
    Gradient of Tr(Σ⁻¹) penalty:
        ∇_Σ = -λ Σ⁻¹

    Returns:
        (Δμ, ΔΣ): where Δμ = 0, ΔΣ = -λ Σ⁻¹ (masked if needed)
    """
    if lambda_ <= 0:
        return zero_mu_sigma_like(agent_i, field=field_type)

    sigma = agent_i.sigma_p_field if field_type == "model" else agent_i.sigma_q_field
    mu_shape = agent_i.mu_p_field.shape if field_type == "model" else agent_i.mu_q_field.shape

    H, W, K, _ = sigma.shape
    d_sigma = np.zeros_like(sigma)
    fallback = np.eye(K)

    for i in range(H):
        for j in range(W):
            try:
                inv_ij = np.linalg.inv(sigma[i, j])
            except np.linalg.LinAlgError:
                if getattr(config, "debug", False):
                    print(f"[WARN] grad_variance_penalty_field: Σ⁻¹ fallback at ({i},{j})")
                inv_ij = np.linalg.pinv(sigma[i, j])  # fallback to pseudo-inverse

            d_sigma[i, j] = -lambda_ * inv_ij

    d_sigma = np.nan_to_num(d_sigma)

    if mask is not None:
        _, d_sigma = apply_mask_to_mu_sigma(None, d_sigma, mask)

    d_mu = np.zeros(mu_shape, dtype=d_sigma.dtype)
    return d_mu, d_sigma

def alignment_gradient_field(agent_i, agents, params, field_type="model", mask=None):
    """
    Raw Euclidean gradient of alignment KL divergence:
        KL(q_i || Ω_ij q_j) or KL(p_i || Ω̃_ij p_j)

    Natural gradient is applied centrally in combine_field_gradients.

    Args:
        agent_i   : focal agent
        agents    : list of agents
        params    : dict of parameters (must contain 'generators')
        field_type: "model" or "belief"
        mask      : optional spatial mask to restrict update region

    Returns:
        (dμ, dΣ): Euclidean gradients
    """
    if field_type == "model":
        weight = params.get("model_align_weight", config.model_align_weight)
    elif field_type == "belief":
        weight = params.get("beta", config.beta)
    else:
        raise ValueError(f"[alignment_gradient_field] Unknown field_type: {field_type}")

    if weight <= 0:
        return zero_mu_sigma_like(agent_i, field=field_type)

    generators = params["generators"]
    dμ, dΣ = compute_alignment_kl_gradient(agent_i, agents, generators, params, field_type=field_type)

    dμ = np.nan_to_num(dμ)
    dΣ = np.nan_to_num(dΣ)

    if mask is not None:
        dμ, dΣ = apply_mask_to_mu_sigma(dμ, dΣ, mask)

    return weight * dμ, weight * dΣ


def combine_field_gradients(agent_i, agents, params, field_type="model"):
    if field_type == "model" and getattr(config, "identical_models", False):
        return zero_mu_sigma_like(agent_i)

    # Load all parameters
    α  = params.get("alpha", config.alpha)
    β  = params.get("model_align_weight", config.model_align_weight) if field_type == "model" else params.get("beta", config.beta)
    fb = params.get("model_feedback_weight", config.model_feedback_weight) if field_type == "model" else params.get("belief_feedback_weight", getattr(config, "belief_feedback_weight", 0.0))
    λ  = params.get("variance_penalty_model_weight", getattr(config, "variance_penalty_model_weight", 0.0)) if field_type == "model" else params.get("variance_penalty_belief_weight", getattr(config, "variance_penalty_belief_weight", 0.0))
    eps = params.get("support_cutoff_eps", config.support_cutoff_eps)

    # Mask
    mask = agent_i.mask > eps
    if not np.any(mask):
        return zero_mu_sigma_like(agent_i)

    # Select fields
    mu_field    = agent_i.mu_p_field if field_type == "model" else agent_i.mu_q_field
    sigma_field = agent_i.sigma_p_field if field_type == "model" else agent_i.sigma_q_field

    # --- Natural-gradient components ---
    grad_mu_nat    = np.zeros_like(mu_field)
    grad_sigma_nat = np.zeros_like(sigma_field)

    if α > 0:
        dμ, dΣ = grad_self_field(agent_i, α, field_type, mask)
        grad_mu_nat += dμ
        grad_sigma_nat += dΣ
    if fb > 0:
        dμ, dΣ = grad_feedback_field(agent_i, fb, field_type, mask)
        grad_mu_nat += dμ
        grad_sigma_nat += dΣ
    if β > 0:
        dμ, dΣ = alignment_gradient_field(agent_i, agents, params, field_type=field_type, mask=mask)

        grad_mu_nat += dμ
        grad_sigma_nat += dΣ

    # --- Apply Fisher preconditioner only to KL terms ---
    delta_mu, delta_sigma = apply_natural_gradient_batch(
        mu_field, sigma_field, grad_mu_nat, grad_sigma_nat
    )

    # --- Add regularization (coordinate) terms AFTER natural gradient ---
    if λ > 0:
        dμ_reg, dΣ_reg = grad_variance_penalty_field(agent_i, λ, field_type, mask)
        delta_mu    += dμ_reg
        delta_sigma += dΣ_reg

    # Final nan sanitization
    delta_mu    = np.nan_to_num(delta_mu, nan=0.0, posinf=1e5, neginf=-1e5)
    delta_sigma = np.nan_to_num(delta_sigma, nan=0.0, posinf=1e5, neginf=-1e5)

    return delta_mu, delta_sigma

def compute_phi_update(agent_i, agents, params, field="phi"):
    """
    Unified update for φ (belief alignment) and φ̃ (model alignment).
    Applies Lie-natural gradient to alignment + optional regularizers.
    """
    if field == "phi_model" and getattr(config, "identical_models", False):
        return np.zeros_like(agent_i.phi_model)

    # --- Unpack core parameters ---
    unpacked  = unpack_phi_update_params(params, field=field)
    β         = params.get("beta", config.beta) if field == "phi" else params.get("model_align_weight", config.model_align_weight)
    κ         = unpacked["κ"]
    gw        = unpacked["gw"]
    curv_w    = unpacked["curv_weight"]
    clip_th   = unpacked["grad_clip_threshold"]
    eps       = unpacked["overlap_eps"]
    debug     = unpacked["debug"]

    phi       = agent_i.phi if field == "phi" else agent_i.phi_model
    phi_tilde = agent_i.phi_model if field == "phi" else agent_i.phi
    soft_mask = agent_i.mask[..., None]
    generators = params.get("generators", get_generators(config.group_name, config.K))

    if not np.any(soft_mask > eps):
        return np.zeros_like(phi)

    grad = np.zeros_like(phi)

    G_inv = compute_inverse_fisher_field(agent_i, generators, field=field)

    # --- 1. Alignment gradient (Lie-natural, variationally consistent) ---
    if β > 0:
        grad_align = np.zeros_like(phi)
        for neighbor in agent_i.neighbors:
            agent_j = agents[neighbor["id"]]
            accumulate_phi_gradient(agent_i, agent_j, generators, params, field=field)
        grad_align = agent_i.grad_phi.copy()
        agent_i.grad_phi[:] = 0.0  # Clear after use

        grad += apply_lie_natural_gradient(phi, grad_align, G_inv=G_inv)

    # --- 2. Curvature gradient ---
    if curv_w > 0:
        grad_curv = compute_curvature_gradient_analytical(phi, generators)
        grad += curv_w * grad_curv

    # --- 3. Mass term: 2γ φ ---
    if gw > 0:
        grad += 2 * gw * phi

    # --- 4. φ–φ̃ coupling ---
    if κ > 0:
        grad += 2 * κ * (phi - phi_tilde)

    # --- 5. Optional Fisher geometry term ---
    fisher_key = "fisher_geometry_weight" if field == "phi" else "fisher_model_geometry_weight"
    fisher_weight = params.get(fisher_key, getattr(config, fisher_key, 0.0))
    if fisher_weight > 0:
        fisher_fn = compute_fisher_geometry_gradient if field == "phi" else compute_fisher_geometry_gradient
        fisher_grad = fisher_fn(agent_i, agents, params)
        grad += fisher_weight * fisher_grad

    # --- Final clip + mask ---
    return clip_and_mask_gradient(grad, soft_mask, clip_th, eps)




def accumulate_phi_gradient(agent_i, agent_j, generators, params, field="phi"):
    """
    Compute and accumulate both variational gradients:
        ∂/∂φ_i KL(q_i ‖ Ω_ij q_j)
        ∂/∂φ_j KL(q_i ‖ Ω_ij q_j)
    where Ω_ij = exp(φ_i) · exp(−φ_j)
    """
    assert field in ("phi", "phi_model")
    beta = params.get("beta", config.beta) if field == "phi" else params.get("model_align_weight", config.model_align_weight)
    if beta <= 0:
        return

    eps = config.support_cutoff_eps
    mask_i = agent_i.mask[..., None] > eps
    mask_j = agent_j.mask[..., None] > eps
    joint_mask = mask_i & mask_j

    # Select fibers
    mu_i = agent_i.mu_q_field if field == "phi" else agent_i.mu_p_field
    mu_j = agent_j.mu_q_field if field == "phi" else agent_j.mu_p_field
    sigma_i = agent_i.sigma_q_field if field == "phi" else agent_i.sigma_p_field
    sigma_j = agent_j.sigma_q_field if field == "phi" else agent_j.sigma_p_field

    phi_i = agent_i.phi if field == "phi" else agent_i.phi_model
    phi_j = agent_j.phi if field == "phi" else agent_j.phi_model

    Omega_ij = agent_i.Omega if field == "phi" else agent_i.Omega_model
    Omega_T = np.swapaxes(Omega_ij, -1, -2)

    # Transport fiber_j to i
    mu_trans = np.einsum("...kl,...l->...k", Omega_ij, mu_j)
    sigma_trans = np.einsum("...km,...mn,...nl->...kl", Omega_ij, sigma_j, Omega_T)
    sigma_trans = sanitize_sigma(sigma_trans, eps=config.eps)
    sigma_inv = safe_inv(sigma_trans, eps=config.eps)

    delta_mu = mu_i - mu_trans
    d_mu = -np.einsum("...ij,...j->...i", sigma_inv, delta_mu)

    delta_sigma = sigma_i - sigma_trans
    d_sigma = -0.5 * np.einsum("...ik,...kl,...lj->...ij", sigma_inv, delta_sigma, sigma_inv)

    d = generators.shape[0]
    grad_phi_i = np.zeros_like(phi_i)
    grad_phi_j = np.zeros_like(phi_j)

    for a in range(d):
        G = generators[a]

        # ∂Ω/∂φ_i = Ω G
        OG = np.einsum("...ij,jk->...ik", Omega_ij, G)
        dphi_i_mu = np.einsum("...ij,...j->...i", OG, mu_j)

        OG_sigma = np.einsum("...ij,...jk->...ik", OG, sigma_j)
        dphi_sigma_1 = np.einsum("...ij,...jk->...ik", OG_sigma, Omega_T)

        sigma_GT = np.einsum("...ij,jk->...ik", sigma_j, G.T)
        O_sigma_GT = np.einsum("...ij,...jk->...ik", Omega_ij, sigma_GT)
        dphi_sigma_2 = np.einsum("...ij,...jk->...ik", O_sigma_GT, Omega_T)

        dphi_i_sigma = dphi_sigma_1 + dphi_sigma_2

        delta_a = (
            np.sum(d_mu * dphi_i_mu, axis=-1) +
            np.einsum("...ij,...ij->...", d_sigma, dphi_i_sigma)
        )

        grad_phi_i[..., a] += delta_a
        grad_phi_j[..., a] -= delta_a

    # ✅ Always apply Lie-covariant natural gradient (no conditionals)
    grad_phi_i = dexpinv_operator(phi_i, grad_phi_i, generators)
    grad_phi_j = dexpinv_operator(phi_j, grad_phi_j, generators)

    if not hasattr(agent_i, "grad_phi"):
        agent_i.grad_phi = np.zeros_like(phi_i)
    if not hasattr(agent_j, "grad_phi"):
        agent_j.grad_phi = np.zeros_like(phi_j)

    agent_i.grad_phi += beta * grad_phi_i * joint_mask
    agent_j.grad_phi += beta * grad_phi_j * joint_mask


