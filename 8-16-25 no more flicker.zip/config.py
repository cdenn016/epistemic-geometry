import numpy as np
import sys

# ===========================
# DEBUGGING AND UTILITIES
# ===========================


def set_config_from_params(params):
    """Dynamically override config attributes from a dictionary."""
    this_module = sys.modules[__name__]
    for k, v in params.items():
        setattr(this_module, k, v)

epsilon_model      = 1      # Threshold to classify meta-agents (can sweep)

# config.py
phi_morphism_type       = "gauge_covariant"         # identity  gauge_covariant 
phi_model_morphism_type = "gauge_covariant"

morphism_normalize    = True
coarsegrain_each_step = True


agent_seed    = 111 

# Toggle between diagonal and full Σ initialization
diagonal_sigma = False

# ===========================
# DOMAIN / SPATIAL SETTINGS
# ===========================
K_q           = 3
K_p           = 5       # Fiber dimension of belief/model space (depends on representation)
                 
D             = 2           #dimension of base manifold - d=2 validated

L             = 25         #length of hypercubic base-manifold - PBCs

steps         = 100

N             = 8                       # Number of agents
max_neighbors = 8        # Max number of agent neighbors

n_jobs = N

agent_radius_range = (3,3)         #agent radii
fixed_location = False      
# ===========================
# COUPLINGS & PENALTIES
# ===========================

alpha                  = 0.25
beta                   = 1
belief_mass            = 1
curvature_weight       = 1

feedback_weight         = 0
beta_model              = 1
model_mass              = 1
model_curvature_weight  = 1

entropy_weight          = 1


#==========================
#    IF NEEDED/CURIOUS
#==========================
exp_n_jobs = 12

phi_coupling_weight           = 0             # set > 0 to enable
phi_coupling_mode             = "projection"  # or "conjugation"


fisher_geometry_weight        = 0      
fisher_model_geometry_weight  = 0

# ===========================
# INITIALIZATION
# ===========================

# ─── Belief Bundle (q) Parameters ───
q_mu_range                     = (-1.0, 1.0)              # Range for μ_q
q_sigma_range                  = (0.2, 1.0)           # Diagonal Σ_q entries

belief_noise_scale_mu          = 0.01         # Additive noise for μ_q
belief_noise_scale_sigma       = 0.01      # Additive noise for Σ_q


# ─── Model Bundle (p) Parameters ───
p_mu_range                     = (-1.0, 1.0)             # Range for μ_p
p_sigma_range                  = (0.2, 1.0)           # Diagonal Σ_p entries

model_noise_scale_mu           = 0.01          # Additive noise for μ_p
model_noise_scale_sigma        = 0.01       # Additive noise for Σ_p

sigma_outside_val              = 1e3  # large uncertainty outside support






# ───────── Activity field (detector input) ────────────────────────────────────
activity_mix_mode      = "weighted_or"   # 'weighted_or'|'and'|'or'|'model_only'|'belief_only'
activity_model_weight  = 0.5
activity_belief_weight = 0.5
activity_score_tau     = 0.25
activity_mu_tau        = 1e-3
activity_trsig_tau     = 1e-3

# ───────── Agreement / alignment temps (shared) ───────────────────────────────
blend_qp_alpha = 0.5
tau_align_q    = 0.6
tau_align_p    = 0.6

# ───────── Detection / emergence (regions) ────────────────────────────────────
detector_period      = 1            # steps between detector passes
detector_mask_tau    = 1e-4         # child support floor inside detector
detector_edge_erode  = 0            # optional erosion of region cores
seed_min_kids        = 2            # ≥ kids per pixel to enter candidate set
emerge_min_area      = 8            # CC area floor (pixels)
parent_weight_tau    = 0.001         # interior weight gate
emerge_tau           = 0.25        # KL/agree local gate (None disables)

# Global agreement auto-gate
detector_agree_auto       = True
detector_agree_percentile = 50.0     # percentile from Aq/Ap aggregates
detector_agree_ema        = 0.2      # smoothing of that percentile
agree_gate_tau            = None     # explicit floor if auto disabled

# ───────── Pixelwise proposals (spawn) ────────────────────────────────────────
child_support_tau      = 0.10        # pair overlap mask τ within proposals
pxspawn_min_pair_px    = 4           # overlap pixels per (i,j)
pxspawn_agree_power    = 1.0         # multiply by A^power
pxspawn_smooth_sigma   = 0.0         # optional gaussian smoothing of components
pxspawn_per_pixel_norm = False       # optional normalization across proposals
debug_spawn_log        = False
debug_spawn_log_details= True

# matching / spacing / dedup


parent_match_iou_existing       = 0.10
parent_match_child_jaccard_thr  = 0.85
spacing_child_jaccard_thr       = 0.90
spacing_child_subset_thr        = 0.90
parent_peak_dedup_radius_px     = 3
parent_peak_dedup_child_jaccard = 0.92
parent_peak_dedup_subset_thr    = 0.90

# proposal validity / seeds
parent_proposal_local_tau       = 0.01
parent_min_seed_area_px         = 1      # basic local area before clamping
parent_assign_min_overlap_px    = 8      # used in multiple places
parent_min_seed_px              = 4      # seed after clamping (≥ support_tau)
parent_support_tau              = 0.08   # seed support τ for matching/spacing

# continuity (keep stable IDs when a close proposal arrives)
parent_continuity_radius_px           = 3     # search window around proposal center
parent_continuity_iou_thr             = 0.15  # IoU(seed,existing) to consider
parent_continuity_child_jacc_keep_thr = 0.60  # if overwriting child_ids via cw

# caps
parent_max_new_per_step = 4

# ───────── Parent mask rebuild & alignment evidence (when used) ──────────────
signal_kl_cap = 10.0          # cap KL in evidence accumulation

# ───────── Child→Parent soft assignment (IoU + softmax) ──────────────────────
parent_soft_assign_tau       = 0.10
parent_soft_assign_temp      = 0.40
parent_soft_assign_topk      = 3
parent_assign_core_tau       = 0.20     # absolute floor for parent “core”
parent_assign_core_tau_rel   = 0.50     # relative to parent.max()
parent_assign_core_dilate    = 1
parent_assign_bootstrap      = 2        # relax core for very young parents
parent_assign_use_agreement  = False    # multiply by A^agree_weight if True
parent_assign_agree_weight   = 1.0

# ───────── Parent mask semantics / dynamics (reconcile) ───────────────────────
parent_active_level         = 0.5
parent_assign_iou_add_thr   = 0.05
parent_assign_iou_keep_thr  = 0.03
parent_active_min_cc_px     = 8
parent_active_iou_min       = 0.30
parent_hysteresis_keep_frac = 0.50
parent_seed_erode_iters     = 1

# feathered continuous mask update
parent_eta_up        = 0.25
parent_eta_down      = 0.20
parent_feather_sigma = 1.0
parent_delta_cap     = 0.20

# life-cycle
parent_freeze_steps       = 0    # cannot shrink under seed during this window
parent_orphan_grace_steps = 10000    # used in reconcile
orphan_patience_steps     = 5    # used by prune() helper
orphan_min_total_weight   = 1e-6
orphan_min_area_nz        = 2

# ───────── Coarse-grain init / stats (used when seeding Σ) ────────────────────
cg_eps                    = 1e-6
parent_cover_support_eps  = 0.30

# ───────── Curvature Boltzmann prior (optional) ───────────────────────────────
curvature_gamma = 0.0
curvature_fiber = "q"    # "q" or "p"
curvature_map   = None

# ───────── Viz / debug ────────────────────────────────────────────────────────
debug_detector_log = True
debug_strict       = True


#======================
#
#   LEARNING RATES
#
#======================
tau_phi                 = 1e-4
tau_phi_model           = 1e-4    
tau_mu_belief           = 1e-4       # update rate for η₁_q
tau_sigma_belief        = 1e-4       # update rate for η₂_q
tau_mu_model            = 1e-4      # update rate for η₁_p
tau_sigma_model         = 1e-4       # update rate for η₂_p



phi_init_smooth_sigma   = 1.5
phi_init                = 0.1
phi_model_offset        = 0.1


eta_ema_alpha                   = 0.6          # try 0.4–0.8
eta_phi_adaptive_scaling        = 1.0
eta_phi_model_adaptive_scaling  = 1.0
eta_sigma_condition_scaling     = 0.1   # start small
sigma_eig_floor                 = 1e-6
sigma_cond_cap                  = 1e4

sigma_eig_cap                   = None          # usually None
sigma_trace_target              = None     # or K if you want trace control




eta_phi_min           = 1e-6
eta_phi_model_min     = 1e-6



#==========================================
#
#       META-AGENTS
#
#==========================================
# Cross-scale toggles
enable_crossscale = True

# Weights (q-fiber)
beta_up_q = 0.30   # child → parent
beta_dn_q = 0.10   # parent → children (smaller at first)

# Weights (p-fiber) — off for now; turn on later
beta_up_p = 0.2
beta_dn_p = 0.2

# Cross-bundle Θ terms — not implemented yet, keep 0
gamma_theta_up = 0.00
gamma_theta_dn = 0.00

# Functorial penalties (intertwining) — not implemented yet, keep 0
lambda_functor_q = 0.00
lambda_functor_p = 0.00

# Clustering / aggregation
overlap_eps = 1e-3

# Logging & seeding
xscale_log_every = 1
xscale_seed_lambda_dn_q = True      # good instant KL drop
xscale_lambda_ridge     = 1e-3      # for the Procrustes seed

# Cross-scale (model side)
enable_crossscale_p      = True




lambda_xscale_q = 0.05




frozen_levels = [1]
frozen_phi_levels = [1]










xscale_lr_mu_p_up        = 0.01
xscale_lr_sigma_p_up     = 0.005
xscale_lr_mu_p_dn        = 0.01
xscale_lr_sigma_p_dn     = 0.005


# ===========================
# AGENT GEOMETRY
# ===========================


gaussian_blur_range_morphism = (1,2)
mu_clip = 3.0



#================================
#
#  INITIALIZE GLOBAL FIELDS 
#      WITH GENTLE NOISE
#================================
use_global_belief_template = False
use_global_model_template  = False



identical_models = False         # If True, all agents share the same p, mu_p_field, sigma_p_field




# ===========================
# STABILITY AND CLIPPING
# ===========================


                                    # Gradient clipping magnitudes (optional; set to None to disable)
phi_grad_clip             = 1e5    # Max L2 norm per-point for φ update
phi_model_grad_clip       = 1e5    # Max L2 norm per-point for φ̃ update

                                     # Optional: norm type (future-proofing, L2 is default)
gradient_clip_norm_type   = 2           # Use 2 for L2 norm; 1 for L1, np.inf for max-norm
phi_exp_clip              = np.pi  # or 2π if you're okay with aliasing


mask_sharpness        = 1.5
# ===========================
# EPSILONS & NUMERICAL STABILITY
# ===========================

log_eps            = 1e-6     # Stabilize log(x)
eps                = 1e-5
# ===========================
# MASK & INTERACTION THRESHOLDS
# ===========================

support_cutoff_eps = 1e-3    # Mask threshold to include point in agent support
overlap_eps        = 1e-3     # Threshold for computing inter-agent overlap

# ===========================
# SIMULATION THRESHOLDS
# ===========================



# ===========================
# CHECKPOINTING
# ===========================

checkpoint_dir      = "checkpoints"
precision = np.float32

checkpoint_interval = 1

domain_size = (L,) * D

# 3) replace all the old eta_* calculations with calls to scaled_eta


num_cores = 1  # or however many threads you want to use



group_name = 'so3'               # Options: "u1", "so3", "so3", 'su2'.

phi_bch_max_norm = 25.0


# Enable numerical safety logging
debug = True  # Global debug flag for extra logging inside φ updates                       

  
fail_on_fallback = False                # Allow recovery rather than crashing


#=================
#    LOGDET
#==================


# ── Numerical Safeguards ─────────────────────────────
max_fisher_condition = 1e5   # Maximum allowed condition number before fallback


# Control fallback thresholds (optional)
max_safe_inv_fallbacks = 1000
max_safe_logdet_fallbacks = 1000

# ─────────────────────────────────────────────────────────
# Logging / dump toggles (matches new logger + field dumper)
# ─────────────────────────────────────────────────────────
logging = dict(
    # master switches
    enable_scalar=True,          # run log_all_metrics (global + per-agent scalars)
    enable_fields=True,          # run full_field_logger (NPZ field dumps)

    # compute-time guards (controls what goes into NPZ)
    compute_alignment=True,      # belief/model alignment maps + KL(p→q, q→p)
    compute_curvature=True,      # curvature tensors + Fq_norm/Fp_norm
    compute_pairwise_overlap=False,  # optional: builds overlap matrix (debug)

    # summaries (affects per-agent CSV rows)
    log_support_stats=True,
    log_overlap_stats=True,
    log_gradient_stats=True,     # needs *_grad or debug counters on Agent
    log_conditioning=True,       # min/max eigs, cond numbers

    # normalization / console
    normalize_by_support=True,
    print_total_energy=True,     # console print of global energies

    # cadence + outdirs
    fields_every=20,              # dump fields every step (turn up if disk heavy)
    max_overlap_every= 10,        # only used if you keep overlap logging on
    full_field_outdir="fields",
    pair_outdir="max_overlap",

    # schema
    schema_version="v3",
)

# Keep this True if any legacy gate still checks it (safe to include)
log_full_fields = False

# Finite-difference checks (optional diagnostics cadence)
fd_check_every = 1000
fd_pairs_per_step = 1
periodic_x = True          # set per your sim
periodic_y = True