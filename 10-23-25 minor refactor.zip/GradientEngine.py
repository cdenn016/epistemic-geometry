# -*- coding: utf-8 -*-
"""
Created on Thu Oct 23 12:51:34 2025

@author: chris and christine
"""

"""
GradientEngine: Core gradient computation and orchestration engine

This module provides the central engine for computing and managing gradients
across all fields (φ, μ, σ, A) with proper caching, transport, and optimization.
"""

import numpy as np
from typing import Dict, List, Tuple, Optional, Any
from dataclasses import dataclass, field
import logging

# Assuming these imports from your project structure

from update_compute_all_gradients import compute_all_gradients
from update_terms_phi import compute_phi_gradient_terms
from update_terms_mu_sigma import compute_mu_gradient_terms, compute_sigma_gradient_terms
from update_terms_curvature_A import compute_A_gradient_terms
from transport_cache import TransportCache
from holonomy import compute_holonomy_correction
from numerical_utils import safe_normalize, check_convergence
from shared_cache import SharedCache
from config import CONFIG


logger = logging.getLogger(__name__)


@dataclass
class GradientConfig:
    """Configuration for gradient engine behavior"""
    learning_rate_phi: float = 0.001
    learning_rate_mu: float = 0.0005
    learning_rate_sigma: float = 0.0005
    learning_rate_A: float = 0.0001
    
    use_adaptive_lr: bool = True
    lr_decay_rate: float = 0.95
    lr_min: float = 1e-6
    
    gradient_clip_threshold: float = 10.0
    use_holonomy_correction: bool = True
    use_parallel_transport: bool = True
    
    convergence_tolerance: float = 1e-6
    max_gradient_norm: float = 100.0
    
    cache_gradients: bool = True
    cache_max_size: int = 1000


@dataclass
class GradientStats:
    """Statistics for gradient computations"""
    phi_grad_norm: float = 0.0
    mu_grad_norm: float = 0.0
    sigma_grad_norm: float = 0.0
    A_grad_norm: float = 0.0
    
    total_grad_norm: float = 0.0
    max_component_norm: float = 0.0
    
    num_clipped: int = 0
    convergence_metric: float = float('inf')
    
    learning_rates: Dict[str, float] = field(default_factory=dict)


class GradientEngine:
    """
    Core engine for computing, managing, and applying gradients across all fields.
    
    This engine:
    - Computes gradients for φ, μ, σ, and A fields
    - Manages transport and holonomy corrections
    - Implements adaptive learning rates
    - Handles gradient clipping and normalization
    - Provides caching for efficiency
    - Tracks convergence metrics
    """
    
    def __init__(self, 
                 config: Optional[GradientConfig] = None,
                 transport_cache: Optional['TransportCache'] = None,
                 shared_cache: Optional['SharedCache'] = None):
        """
        Initialize the gradient engine.
        
        Args:
            config: Configuration for gradient behavior
            transport_cache: Cache for parallel transport computations
            shared_cache: Shared cache for reusable computations
        """
        self.config = config or GradientConfig()
        self.transport_cache = transport_cache
        self.shared_cache = shared_cache
        
        # Learning rate tracking
        self.current_lrs = {
            'phi': self.config.learning_rate_phi,
            'mu': self.config.learning_rate_mu,
            'sigma': self.config.learning_rate_sigma,
            'A': self.config.learning_rate_A
        }
        
        # Gradient history for momentum/adaptive methods
        self.gradient_history: Dict[str, List[np.ndarray]] = {
            'phi': [],
            'mu': [],
            'sigma': [],
            'A': []
        }
        
        # Statistics tracking
        self.stats_history: List[GradientStats] = []
        self.iteration = 0
        
        # Convergence tracking
        self.prev_gradients: Optional[Dict[str, np.ndarray]] = None
        
        logger.info("GradientEngine initialized")
    
    def compute_gradients(self, 
                         agents: np.ndarray,
                         context: Any,
                         fields: Optional[Dict[str, np.ndarray]] = None) -> Dict[str, np.ndarray]:
        """
        Compute gradients for all fields.
        
        Args:
            agents: Agent state array
            context: Runtime context with system state
            fields: Optional explicit field values (otherwise extracted from agents)
            
        Returns:
            Dictionary mapping field names to gradient arrays
        """
        logger.debug(f"Computing gradients at iteration {self.iteration}")
        
        # Extract fields if not provided
        if fields is None:
            fields = self._extract_fields(agents)
        
        # Compute base gradients
        gradients = {}
        
        # φ gradients
        phi_grad = compute_phi_gradient_terms(
            agents, 
            context,
            use_cache=self.config.cache_gradients,
            cache=self.shared_cache
        )
        gradients['phi'] = phi_grad
        
        # μ gradients
        mu_grad = compute_mu_gradient_terms(
            agents,
            context,
            use_cache=self.config.cache_gradients,
            cache=self.shared_cache
        )
        gradients['mu'] = mu_grad
        
        # σ gradients
        sigma_grad = compute_sigma_gradient_terms(
            agents,
            context,
            use_cache=self.config.cache_gradients,
            cache=self.shared_cache
        )
        gradients['sigma'] = sigma_grad
        
        # A (curvature) gradients
        A_grad = compute_A_gradient_terms(
            agents,
            context,
            use_cache=self.config.cache_gradients,
            cache=self.shared_cache
        )
        gradients['A'] = A_grad
        
        # Apply corrections if enabled
        if self.config.use_holonomy_correction:
            gradients = self._apply_holonomy_corrections(gradients, agents, context)
        
        if self.config.use_parallel_transport:
            gradients = self._apply_parallel_transport(gradients, agents, context)
        
        # Clip gradients if needed
        gradients = self._clip_gradients(gradients)
        
        # Store for convergence tracking
        self.prev_gradients = gradients
        
        # Update history
        for field_name, grad in gradients.items():
            if len(self.gradient_history[field_name]) >= self.config.cache_max_size:
                self.gradient_history[field_name].pop(0)
            self.gradient_history[field_name].append(grad.copy())
        
        return gradients
    
    
    
    def apply_gradients(self,
                       agents: np.ndarray,
                       gradients: Dict[str, np.ndarray],
                       learning_rates: Optional[Dict[str, float]] = None) -> np.ndarray:
        """
        Apply computed gradients to update agent fields.
        
        Args:
            agents: Current agent state
            gradients: Computed gradients for each field
            learning_rates: Optional override for learning rates
            
        Returns:
            Updated agent array
        """
        if learning_rates is None:
            learning_rates = self.current_lrs
        
        updated_agents = agents.copy()
        
        # Apply each gradient with its learning rate
        for field_name, grad in gradients.items():
            lr = learning_rates.get(field_name, self.current_lrs[field_name])
            
            # Update the corresponding field in agents
            if field_name == 'phi':
                updated_agents['φ'] -= lr * grad
            elif field_name == 'mu':
                updated_agents['μ'] -= lr * grad
            elif field_name == 'sigma':
                updated_agents['σ'] -= lr * grad
            elif field_name == 'A':
                updated_agents['A'] -= lr * grad
        
        # Ensure physical constraints
        updated_agents = self._enforce_constraints(updated_agents)
        
        return updated_agents
    
    def step(self,
             agents: np.ndarray,
             context: Any,
             compute_stats: bool = True) -> Tuple[np.ndarray, GradientStats]:
        """
        Perform one complete gradient step: compute + apply + adapt.
        
        Args:
            agents: Current agent state
            context: Runtime context
            compute_stats: Whether to compute and return statistics
            
        Returns:
            Tuple of (updated_agents, statistics)
        """
        # Compute gradients
        gradients = self.compute_gradients(agents, context)
        
        # Adapt learning rates if enabled
        if self.config.use_adaptive_lr:
            self._adapt_learning_rates(gradients)
        
        # Apply gradients
        updated_agents = self.apply_gradients(agents, gradients)
        
        # Compute statistics
        stats = None
        if compute_stats:
            stats = self._compute_stats(gradients, agents, updated_agents)
            self.stats_history.append(stats)
        
        self.iteration += 1
        
        return updated_agents, stats
    
    def _extract_fields(self, agents: np.ndarray) -> Dict[str, np.ndarray]:
        """Extract field arrays from structured agent array."""
        return {
            'phi': agents['φ'],
            'mu': agents['μ'],
            'sigma': agents['σ'],
            'A': agents['A']
        }
    
    def _apply_holonomy_corrections(self,
                                   gradients: Dict[str, np.ndarray],
                                   agents: np.ndarray,
                                   context: Any) -> Dict[str, np.ndarray]:
        """Apply holonomy-based corrections to gradients."""
        corrected = {}
        
        for field_name, grad in gradients.items():
            # Compute holonomy correction for this field
            correction = compute_holonomy_correction(
                grad,
                agents,
                context,
                field_name=field_name,
                cache=self.transport_cache
            )
            
            corrected[field_name] = grad + correction
        
        return corrected
    
    def _apply_parallel_transport(self,
                                 gradients: Dict[str, np.ndarray],
                                 agents: np.ndarray,
                                 context: Any) -> Dict[str, np.ndarray]:
        """Apply parallel transport to maintain geometric consistency."""
        transported = {}
        
        for field_name, grad in gradients.items():
            # Use transport cache for efficiency
            if self.transport_cache is not None:
                transported_grad = self.transport_cache.parallel_transport(
                    grad,
                    agents,
                    field_name=field_name
                )
            else:
                transported_grad = grad
            
            transported[field_name] = transported_grad
        
        return transported
    
    def _clip_gradients(self, gradients: Dict[str, np.ndarray]) -> Dict[str, np.ndarray]:
        """Clip gradients to prevent instability."""
        clipped = {}
        num_clipped = 0
        
        for field_name, grad in gradients.items():
            grad_norm = np.linalg.norm(grad)
            
            if grad_norm > self.config.gradient_clip_threshold:
                clipped[field_name] = grad * (self.config.gradient_clip_threshold / grad_norm)
                num_clipped += 1
            else:
                clipped[field_name] = grad
        
        if num_clipped > 0:
            logger.debug(f"Clipped {num_clipped} gradients")
        
        return clipped
    
    def _adapt_learning_rates(self, gradients: Dict[str, np.ndarray]):
        """Adapt learning rates based on gradient history."""
        for field_name, grad in gradients.items():
            history = self.gradient_history[field_name]
            
            if len(history) < 2:
                continue
            
            # Simple adaptive scheme: decrease if gradient direction changes
            prev_grad = history[-1]
            direction_alignment = np.dot(grad.flatten(), prev_grad.flatten())
            direction_alignment /= (np.linalg.norm(grad) * np.linalg.norm(prev_grad) + 1e-10)
            
            if direction_alignment < 0:  # Gradients oppose each other
                self.current_lrs[field_name] *= self.config.lr_decay_rate
            else:  # Gradients align
                self.current_lrs[field_name] *= (1.0 / self.config.lr_decay_rate)
            
            # Enforce bounds
            self.current_lrs[field_name] = max(
                self.config.lr_min,
                min(self.current_lrs[field_name], getattr(self.config, f'learning_rate_{field_name}'))
            )
    
    def _enforce_constraints(self, agents: np.ndarray) -> np.ndarray:
        """Enforce physical/mathematical constraints on agent fields."""
        constrained = agents.copy()
        
        # σ must be positive
        constrained['σ'] = np.maximum(constrained['σ'], 1e-6)
        
        # Normalize certain fields if needed
        # φ normalization (if it represents a phase or direction)
        # This depends on your specific physics
        
        return constrained
    
    def _compute_stats(self,
                      gradients: Dict[str, np.ndarray],
                      old_agents: np.ndarray,
                      new_agents: np.ndarray) -> GradientStats:
        """Compute statistics about the gradient step."""
        stats = GradientStats()
        
        # Gradient norms
        stats.phi_grad_norm = np.linalg.norm(gradients['phi'])
        stats.mu_grad_norm = np.linalg.norm(gradients['mu'])
        stats.sigma_grad_norm = np.linalg.norm(gradients['sigma'])
        stats.A_grad_norm = np.linalg.norm(gradients['A'])
        
        stats.total_grad_norm = np.sqrt(
            stats.phi_grad_norm**2 + 
            stats.mu_grad_norm**2 + 
            stats.sigma_grad_norm**2 + 
            stats.A_grad_norm**2
        )
        
        stats.max_component_norm = max(
            stats.phi_grad_norm,
            stats.mu_grad_norm,
            stats.sigma_grad_norm,
            stats.A_grad_norm
        )
        
        # Convergence metric
        if self.prev_gradients is not None:
            changes = []
            for field_name in gradients.keys():
                change = np.linalg.norm(gradients[field_name] - self.prev_gradients[field_name])
                changes.append(change)
            stats.convergence_metric = np.mean(changes)
        
        # Learning rates
        stats.learning_rates = self.current_lrs.copy()
        
        return stats
    
    def get_convergence_status(self) -> Tuple[bool, float]:
        """
        Check if gradients have converged.
        
        Returns:
            Tuple of (has_converged, convergence_metric)
        """
        if len(self.stats_history) < 2:
            return False, float('inf')
        
        recent_metric = self.stats_history[-1].convergence_metric
        converged = recent_metric < self.config.convergence_tolerance
        
        return converged, recent_metric
    
    def reset(self):
        """Reset the engine state."""
        self.gradient_history = {k: [] for k in self.gradient_history.keys()}
        self.stats_history = []
        self.prev_gradients = None
        self.iteration = 0
        
        # Reset learning rates
        self.current_lrs = {
            'phi': self.config.learning_rate_phi,
            'mu': self.config.learning_rate_mu,
            'sigma': self.config.learning_rate_sigma,
            'A': self.config.learning_rate_A
        }
        
        logger.info("GradientEngine reset")
    
    def get_stats_summary(self, last_n: int = 10) -> Dict[str, Any]:
        """Get summary statistics over recent iterations."""
        if not self.stats_history:
            return {}
        
        recent = self.stats_history[-last_n:]
        
        return {
            'mean_total_grad_norm': np.mean([s.total_grad_norm for s in recent]),
            'mean_convergence_metric': np.mean([s.convergence_metric for s in recent]),
            'current_lrs': self.current_lrs.copy(),
            'iterations': self.iteration,
            'last_phi_norm': recent[-1].phi_grad_norm,
            'last_mu_norm': recent[-1].mu_grad_norm,
            'last_sigma_norm': recent[-1].sigma_grad_norm,
            'last_A_norm': recent[-1].A_grad_norm
        }


def create_gradient_engine(config_dict: Optional[Dict[str, Any]] = None,
                          transport_cache: Optional['TransportCache'] = None,
                          shared_cache: Optional['SharedCache'] = None) -> GradientEngine:
    """
    Factory function to create a configured GradientEngine.
    
    Args:
        config_dict: Dictionary of configuration parameters
        transport_cache: Optional transport cache instance
        shared_cache: Optional shared cache instance
        
    Returns:
        Configured GradientEngine instance
    """
    if config_dict:
        config = GradientConfig(**config_dict)
    else:
        config = GradientConfig()
    
    return GradientEngine(
        config=config,
        transport_cache=transport_cache,
        shared_cache=shared_cache
    )