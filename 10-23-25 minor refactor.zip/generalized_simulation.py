# generalized_simulation.py
import os
os.environ["OMP_NUM_THREADS"] = "1"
os.environ["MKL_NUM_THREADS"] = "1"
os.environ["NUMEXPR_NUM_THREADS"] = "1"
os.environ["OPENBLAS_NUM_THREADS"] = "1"
import sys
ROOT = os.path.dirname(os.path.abspath(__file__))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

from pathlib import Path
import sys, shutil, numpy as np
import config as config
from updates.update_rules import synchronous_step
from updates.update_terms_curvature_A import ensure_global_A

from diagnostics import ( compute_total_action, print_action_breakdown, save_all_series_npz,
                         compute_global_metrics, log_phi_vectors, log_mu_vectors)
from metrics_viz import VizConfig, MetricsViz

from core.get_generators import casimir_scalar
from core.runtime_context import ensure_runtime_defaults, cfg_get 

from core.utils import ( mean_norm, _aid, prepare_generators, initialize_or_resume,
    log_and_viz_after_step, wrap_epilogue, save_step )

from core.shared_cache import SharedDiskCache
from contextlib import contextmanager
from time import perf_counter
from core.runtime_context import cfg_set_override, ensure_shared_cache_attached




@contextmanager
def section_timer(ctx, name, step=None):
    """
    Simple wall-clock timer. Prints and records duration into ctx.timings.
    step: optional step index (int) for per-step timings.
    """
    t0 = perf_counter()
    try:
        yield
    finally:
        dt = perf_counter() - t0
        # Record
        ts = getattr(ctx, "timings", None)
        if ts is None:
            ctx.timings = {}
            ts = ctx.timings
        bucket = "init" if step is None else f"step_{int(step)}"
        ts.setdefault(bucket, []).append((name, dt))
        # Print
        where = f"[t:{bucket}]"
        print(f"{where} {name}: {dt:.3f}s")

def _dt_ms(dt):
    return f"{dt*1000.0:.1f} ms"





def post_step_io(
    runtime_ctx,
    agents,
    metrics,           # precomputed from run_one_step
    action,            # precomputed from run_one_step
    step: int,
    outdir: str,
    mv,                # MetricsViz instance
    parent_metrics: list,
    metric_log: list,
):
    """
    All step side effects in one place:
      - print breakdown
      - run existing log/viz helper
      - log global & per-agent rows
      - flush/plot/snapshot
      - save checkpoint

    Pure consumers: relies ONLY on inputs; no recomputation of metrics/action.
    """
    
    # 1) console output
    print_action_breakdown(runtime_ctx, action)

    # 2) reuse your consolidated logger/plotter (keeps previous behavior)
    log_and_viz_after_step(
        runtime_ctx, agents, step, outdir,
        parent_metrics, metric_log,
        getattr(runtime_ctx, "config", {}).get("n_jobs", 1),
        precomputed_metrics=metrics,
        precomputed_Q=action,
    )

    # 3) global row (reuse precomputed values)
    E_tot = action.get("Action_total", np.nan)
    gmetrics = {
        "E_total": float(E_tot) if np.isfinite(E_tot) else np.nan,
        "mean_total": float(metrics.get("mean_total", np.nan)),
        **action,  # includes Geom_total, A_curv, A_cov, align*, gamma*, etc.
    }
    mv.log_global(step, gmetrics)

    # 4) per-agent rows (cheap norms; robust to missing fields)
    for a in agents:
        mv.log_agent(step, _aid(a), {
            "phi_norm_mean":       mean_norm(getattr(a, "phi", None)),
            "phi_model_norm_mean": mean_norm(getattr(a, "phi_model", None)),
            "mu_q_norm_mean":      mean_norm(getattr(a, "mu_q_field", None)),
            "mu_p_norm_mean":      mean_norm(getattr(a, "mu_p_field", None)),
        })

    # 5) plots + snapshots (cadence inside MetricsViz)
    mv.maybe_flush(step)
    mv.maybe_plot(step)
    mv.maybe_snapshot(step, runtime_ctx, agents)

    # 6) checkpoint
    save_step(agents, outdir, step)


def run_one_step(runtime_ctx, agents, G_q, G_p, n_jobs=1):
    """
    Perform ONE pure simulation step:
      - refresh per-step settings from config + runtime overrides
      - ensure a shared, disk-backed cache (memmapped) usable by loky workers
      - run synchronous child update (parallel if n_jobs > 1)
      - compute per-step metrics and action
    """
    # Ensure cache is attached (idempotent; safe if already set)
    ensure_shared_cache_attached(runtime_ctx)

    # Per-step resets (pure, in-memory)
    runtime_ctx.timings = {}
    runtime_ctx.energy_acc = {}   # fresh per-step accumulator dict (master-only)

    # (A) pre-step snapshot = t_k
    log_phi_vectors(runtime_ctx, agents)
    log_mu_vectors(runtime_ctx, agents)

    # Run updates. Parallel section writes results; master reducer fills energy_acc.
    agents = synchronous_step(
        agents, G_q, G_p,
        n_jobs=int(n_jobs),
        runtime_ctx=runtime_ctx,
    )
    runtime_ctx.children_latest = agents

    # (B) post-step snapshot = t_{k+1}
    log_phi_vectors(runtime_ctx, agents)
    log_mu_vectors(runtime_ctx, agents)

    # Metrics & action (these read from runtime_ctx.energy_acc populated above)
    metrics = compute_global_metrics(runtime_ctx, agents)
    action  = compute_total_action(runtime_ctx, agents, precomputed_metrics=metrics)

    return agents, metrics, action





def run_simulation(
    outdir="_checkpoints",
    resume=False,
    log_metrics=True,
    log_fields=True,
    num_cores=None,
    fresh_outdir=False,
    clear_agent_logs=True,
    runtime_ctx=None,
):
    t0_all = perf_counter()

    # ---------- core selection ----------
    # If num_cores not provided, default to config.n_jobs; otherwise honor the parameter
    if num_cores is None:
        num_cores = int(getattr(config, "n_jobs", 1))
    else:
        num_cores = max(1, int(num_cores))

    # ---------- runtime ctx ----------
    runtime_ctx = ensure_runtime_defaults(runtime_ctx)
    runtime_ctx.timings = {}

    # Frozen gradient config (for multiprocessing-safe gradients)
    

    # Initialize shared disk cache (for caching expensive pushes)
    cache_dir = cfg_get(runtime_ctx, "shared_cache_dir", "./_shared_cache")
    runtime_ctx.cache = SharedDiskCache(cache_dir)
    print(f"[CACHE] Initialized SharedDiskCache at {cache_dir}")

    # Use ctx.overrides for explicit runtime changes only
    runtime_ctx.overrides = {}

    # Reflect chosen n_jobs into cfg so downstream uses it consistently
    cfg_set_override(runtime_ctx, "n_jobs", num_cores)
    print("[CONFIG] Using config.py as single source of truth")
    n_jobs_val = cfg_get(runtime_ctx, "n_jobs", 1)
    print(f"[CONFIG] n_jobs = {n_jobs_val}")
    if runtime_ctx.overrides:
        print(f"[CONFIG] Active overrides: {list(runtime_ctx.overrides.keys())}")


    

    # ---------- generators (ctx-driven) ----------
    G_q, G_p = prepare_generators(runtime_ctx)
    Kq, Kp = int(np.asarray(G_q).shape[1]), int(np.asarray(G_p).shape[1])
    


    # ---------- init or resume ----------
    if fresh_outdir and not resume and os.path.isdir(outdir):
        shutil.rmtree(outdir, ignore_errors=True)
    os.makedirs(outdir, exist_ok=True)

    with section_timer(runtime_ctx, "initialize_or_resume"):
        agents, step_start = initialize_or_resume(
            outdir, resume, runtime_ctx, clear_agent_logs=clear_agent_logs
        )

    # ---------- runtime ctx bootstrapping ----------
    runtime_ctx.global_step = step_start
    runtime_ctx.children_latest = agents

    vizcfg = VizConfig(
            outdir=Path(outdir),
            run_name="runs",
            legend_label=f"l_q={cfg_get(runtime_ctx, 'ell_q', 3)}",
            plot_every_steps=1,
            snapshot_every_steps=99,
        )
    mv = MetricsViz(vizcfg)
    meta_generators = {
            "Kq": Kq, "Kp": Kp,
            "casimir_total_q": casimir_scalar(G_q),
            "casimir_total_p": casimir_scalar(G_p),
        }
    mv.start_run(meta=meta_generators)
    runtime_ctx.viz = mv    
    
    # ---------- global A (M-D) ----------
    S_agents = agents[0].spatial_shape
    A_init_scale = cfg_get(runtime_ctx, "A_init_scale", getattr(config, "A_init_scale", 0.0))
    ensure_global_A(runtime_ctx, spatial_shape=S_agents, init_scale=A_init_scale, smooth_sigma=2.0)

    # ---------- step range ----------
    total_steps = int(cfg_get(runtime_ctx, "steps", getattr(config, "steps", 0)))
    if step_start >= total_steps:
        with section_timer(runtime_ctx, "epilogue_noop"):
            wrap_epilogue(runtime_ctx, agents, outdir, [], [])
            mv.end_run()
        print("[DONE] Nothing to do: resume step >= total steps.")
        print(f"[TOTAL] {_dt_ms(perf_counter() - t0_all)}")
        return agents, []

    # ---------- loop ----------
    parent_metrics, metric_log = [], []
    print(f"[RUN] Starting simulation at step {step_start} with {num_cores} cores")

    for step in range(step_start, total_steps):
        runtime_ctx.global_step = step
        print(f"\n[STEP {step}] -----------------------------\n")
        t_step0 = perf_counter()

        # One step (compute)
        with section_timer(runtime_ctx, "run_one_step", step=step):
            agents, metrics, action = run_one_step(
                runtime_ctx, agents, G_q, G_p, n_jobs=n_jobs_val
            )

        # IO / logging
        with section_timer(runtime_ctx, "post_step_io", step=step):
            post_step_io(runtime_ctx, agents, metrics, action, step, outdir, mv, parent_metrics, metric_log)

        # Step summary
        dt_step = perf_counter() - t_step0
        print(f"[t:step_{step}] total: {dt_step:.3f}s")

    # ---------- epilogue ----------
    wrap_epilogue(runtime_ctx, agents, outdir, parent_metrics, metric_log)
    save_all_series_npz(runtime_ctx, os.path.join(outdir, "phi_series.npz"))
    mv.end_run()

    dt_all = perf_counter() - t0_all
    print("[DONE] Simulation completed.")
    print(f"[TOTAL] {dt_all}")
    return agents, metric_log




if __name__ == "__main__":
    
    run_simulation()



