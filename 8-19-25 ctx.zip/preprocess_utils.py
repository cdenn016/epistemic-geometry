# -*- coding: utf-8 -*-
"""
Created on Mon Aug 11 16:05:57 2025

@author: chris and christine
"""

import numpy as np
import config
from natural_gradient import (compute_inverse_fisher_field_natural,
                              )
from get_generators import get_generators
from omega import exp_lie_algebra_irrep
             
from numerical_utils import sanitize_sigma, safe_omega_inv, safe_inv, masked_cond_proxy    
import numpy as np
from typing import Optional
from omega import omega_field_cached, exp_grid_cached

from typing import Optional
import copy


# preprocess_utils.py (or wherever ensure_transforms lives)



def ensure_transforms(objs, G_q, G_p, params=None, ctx: Optional[object] = None):
    """
    Single-sourced refresh: exp(φ/φ̃) → Ω → Λ → parent views → Φ/Φ̃.
    CacheHub-aware: threads ctx to functions that accept it; otherwise falls back.
    """
    if not objs:
        return

    # Make a shallow copy so we can safely augment params
    params = copy.copy(params) if params is not None else {}
    if ctx is None:
        ctx = params.get("runtime_ctx")
    else:
        params["runtime_ctx"] = ctx

    # Small helper: try calling with ctx; if signature doesn't accept it, retry without.
    def _call_with_ctx(fn, *args, **kwargs):
        kwargs_ctx = dict(kwargs)
        kwargs_ctx["ctx"] = ctx
        try:
            return fn(*args, **kwargs_ctx)
        except TypeError:
            kwargs_ctx.pop("ctx", None)
            return fn(*args, **kwargs_ctx)

    # 1) Local preprocess (Σ sanitize, inverses, exp caches, optional Fisher)
    from preprocess_utils import preprocess_all_agents  # existing
    _call_with_ctx(preprocess_all_agents, objs, params, G_q=G_q, G_p=G_p)

    # 2) Same-level Ω caches (optional; neighbors outside objs may be skipped)
    try:
        from update_rules_utils import build_all_omega_caches
        _call_with_ctx(build_all_omega_caches, objs)
    except Exception:
        pass

    # 3) Cross-scale Λ (child-side authoritative maps)
    try:
        from update_rules_utils import build_all_lambda_caches
        _call_with_ctx(build_all_lambda_caches, objs)
    except Exception:
        pass

    # 4) Parent back-views (read-only wiring; usually no ctx needed)
    try:
        from update_rules_utils import attach_parent_lambda_views
        attach_parent_lambda_views(objs)
    except Exception:
        pass

    # 5) Φ/Φ̃ for any dirty or missing (uses compute_direct_morphisms under the hood)
    from bundle_morphism_utils import recompute_agent_morphisms
    for a in objs:
        if a is None:
            continue
        need = (
            getattr(a, "morphisms_dirty", False)
            or getattr(a, "bundle_morphism_q_to_p", None) is None
            or getattr(a, "bundle_morphism_p_to_q", None) is None
        )
        if need:
            _call_with_ctx(
                recompute_agent_morphisms,
                a,
                generators_q=G_q,
                generators_p=G_p,
            )
            if hasattr(a, "morphisms_dirty"):
                a.morphisms_dirty = False






# preprocess_utils.py

from typing import Optional

def preprocess_all_agents(agents, params=None, G_q=None, G_p=None, *, ctx: Optional[object] = None):
    """
    Build/refresh: generators, Σ sanitization + inverses, exp(φ)/exp(−φ),
    Fisher caches (optional), and reset per-step transport caches.
    Call this ONCE per step BEFORE you build Ω and Λ caches.
    """
    params = params or {}
    # also stash ctx in params so downstream code can read it if needed
    if ctx is not None:
        params = dict(params)
        params["runtime_ctx"] = ctx

    for a in (agents or []):
        if a is None:
            continue
        preprocess_agent_fields(a, params, G_q=G_q, G_p=G_p, ctx=ctx)


# preprocess_utils.py  (inside build_all_lambda_caches)
# update_rules_utils.py (or wherever these live)



def build_all_lambda_caches(agents, *, ctx: Optional[object] = None):
    """
    Populate child-side Λ maps:
        Λ_up^q[pid]   = E_parent(φ)      · E_child(−φ)
        Λ_dn^q[pid]   = E_child(φ)       · E_parent(−φ)
        Λ_up^p[pid]   = E_parent(φ̃)     · E_child(−φ̃)
        Λ_dn^p[pid]   = E_child(φ̃)      · E_parent(−φ̃)
    Uses CacheHub to build exp grids if missing; clears stale entries each call.
    """
    if not agents:
        return

    # Ensure dicts exist (legacy-safe) and clear stale
    for a in agents:
        if a is None: 
            continue
        if getattr(a, "Lambda_up_q_map",   None) is None: a.Lambda_up_q_map   = {}
        if getattr(a, "Lambda_dn_q_map",   None) is None: a.Lambda_dn_q_map   = {}
        if getattr(a, "Lambda_up_p_map",   None) is None: a.Lambda_up_p_map   = {}
        if getattr(a, "Lambda_dn_p_map",   None) is None: a.Lambda_dn_p_map   = {}
        a.Lambda_up_q_map.clear(); a.Lambda_dn_q_map.clear()
        a.Lambda_up_p_map.clear(); a.Lambda_dn_p_map.clear()

    id2agent = {int(getattr(a, "id")): a for a in agents if a is not None and hasattr(a, "id")}

    # Helper: get exp(±φ) using hub; reuse on-agent if already present
    def _exp_cached(agent, fiber: str, sign: int):
        assert fiber in ("q","p")
        if fiber == "q":
            G = getattr(agent, "generators_q", None)
            if sign == +1:
                E = getattr(agent, "_exp_phi", None)
                return E if E is not None else exp_grid_cached(ctx, np.asarray(agent.phi), G, group="so3", sign=+1)
            else:
                En = getattr(agent, "_exp_neg_phi", None)
                if En is not None: return En
                # orthogonal SO(3): inverse = transpose; if you keep that invariant, this is fine
                E = _exp_cached(agent, "q", +1)
                return np.swapaxes(E, -1, -2)
        else:
            G = getattr(agent, "generators_p", None)
            if sign == +1:
                E = getattr(agent, "_exp_phi_model", None)
                return E if E is not None else exp_grid_cached(ctx, np.asarray(agent.phi_model), G, group="so3", sign=+1)
            else:
                En = getattr(agent, "_exp_neg_phi_model", None)
                if En is not None: return En
                E = _exp_cached(agent, "p", +1)
                return np.swapaxes(E, -1, -2)

    # Build per child→parent
    for child in agents:
        if child is None:
            continue
        pids = getattr(child, "parent_ids", None) or []
        if not pids:
            continue

        # prefetch child exps once
        Ec_q  = _exp_cached(child, "q", +1)
        Ecn_q = _exp_cached(child, "q", -1)
        Ec_p  = _exp_cached(child, "p", +1)
        Ecn_p = _exp_cached(child, "p", -1)

        for pid in pids:
            parent = id2agent.get(int(pid))
            if parent is None:
                continue

            # parent exps (lazy via hub)
            Ep_q  = _exp_cached(parent, "q", +1)
            Epn_q = _exp_cached(parent, "q", -1)
            Ep_p  = _exp_cached(parent, "p", +1)
            Epn_p = _exp_cached(parent, "p", -1)

            # Λ_up = E_parent · E_child^{-1},  Λ_dn = E_child · E_parent^{-1}
            child.Lambda_up_q_map[pid] = np.einsum("...ik,...kj->...ij", Ep_q,  Ecn_q, optimize=True).astype(np.float32, copy=False)
            child.Lambda_dn_q_map[pid] = np.einsum("...ik,...kj->...ij", Ec_q,  Epn_q, optimize=True).astype(np.float32, copy=False)
            child.Lambda_up_p_map[pid] = np.einsum("...ik,...kj->...ij", Ep_p,  Ecn_p, optimize=True).astype(np.float32, copy=False)
            child.Lambda_dn_p_map[pid] = np.einsum("...ik,...kj->...ij", Ec_p,  Epn_p, optimize=True).astype(np.float32, copy=False)


def attach_parent_lambda_views(agents):
    """
    Robust parent-side views: skips None, ensures dicts exist.
    Mirrors child Λ maps onto the parent for convenient read-only access.
    """
    agents = [a for a in (agents or []) if a is not None]
    if not agents:
        return

    # Clear/create parent-side maps
    for A in agents:
        if not hasattr(A, "Lambda_from_child_q_map"): A.Lambda_from_child_q_map = {}
        if not hasattr(A, "Lambda_to_child_q_map"):   A.Lambda_to_child_q_map   = {}
        if not hasattr(A, "Lambda_from_child_p_map"): A.Lambda_from_child_p_map = {}
        if not hasattr(A, "Lambda_to_child_p_map"):   A.Lambda_to_child_p_map   = {}
        A.Lambda_from_child_q_map.clear()
        A.Lambda_to_child_q_map.clear()
        A.Lambda_from_child_p_map.clear()
        A.Lambda_to_child_p_map.clear()

    id2agent = {int(getattr(a, "id")): a for a in agents if hasattr(a, "id")}
    for child in agents:
        pids = getattr(child, "parent_ids", None) or []
        for pid in pids:
            parent = id2agent.get(int(pid))
            if parent is None:
                continue
            up_q  = getattr(child, "Lambda_up_q_map",   {})
            dn_q  = getattr(child, "Lambda_dn_q_map",   {})
            up_p  = getattr(child, "Lambda_up_p_map",   {})
            dn_p  = getattr(child, "Lambda_dn_p_map",   {})
            if pid in up_q:
                parent.Lambda_from_child_q_map[int(child.id)] = up_q[int(pid)]
            if pid in dn_q:
                parent.Lambda_to_child_q_map[int(child.id)]   = dn_q[int(pid)]
            if pid in up_p:
                parent.Lambda_from_child_p_map[int(child.id)] = up_p[int(pid)]
            if pid in dn_p:
                parent.Lambda_to_child_p_map[int(child.id)]   = dn_p[int(pid)]


# update_rules_utils.py



def zero_all_gradients(agent):
    """
    Zero (and if missing, create) all gradient buffers,
    keeping legacy aliases in sync and ensuring arrays are writeable/contiguous.
    """
    def ensure_buf(name, like):
        arr = getattr(agent, name, None)
        if like is None:
            # nothing to mirror; leave as None
            setattr(agent, name, None)
            return None
        if arr is None:
            arr = np.zeros_like(like, dtype=np.float32)
        else:
            # ensure writeable and contiguous
            if not arr.flags.writeable or not arr.flags.c_contiguous or arr.shape != like.shape:
                arr = np.array(arr, copy=True).astype(np.float32, copy=False)
            # zero in-place
            arr.fill(0)
        setattr(agent, name, arr)
        return arr

    # Canonical grads (create from fields if needed)
    g_mu_q   = ensure_buf("grad_mu_q",    getattr(agent, "mu_q_field", None))
    g_sg_q   = ensure_buf("grad_sigma_q", getattr(agent, "sigma_q_field", None))
    g_mu_p   = ensure_buf("grad_mu_p",    getattr(agent, "mu_p_field", None))
    g_sg_p   = ensure_buf("grad_sigma_p", getattr(agent, "sigma_p_field", None))
    g_phi    = ensure_buf("grad_phi",       getattr(agent, "phi", None))
    g_phit   = ensure_buf("grad_phi_tilde", getattr(agent, "phi_model", None))
    g_Phi    = ensure_buf("grad_Phi",       getattr(agent, "bundle_morphism_q_to_p", None))
    g_Phit   = ensure_buf("grad_Phi_tilde", getattr(agent, "bundle_morphism_p_to_q", None))

    # Keep legacy aliases in sync (as references, not copies)
    if g_mu_q is not None:
        agent.grad_mu_q_field = g_mu_q
    if g_sg_q is not None:
        agent.grad_sigma_q_field = g_sg_q
    if g_mu_p is not None:
        agent.grad_mu_p_field = g_mu_p
    if g_sg_p is not None:
        agent.grad_sigma_p_field = g_sg_p


def build_all_omega_caches(
    agents,
    *,
    ctx: Optional[object] = None,
    strict: bool = False,
    debug: bool = False,
    store_per_agent: bool = True,   # keep legacy dicts in sync for old callers
):
    """
    Build Ω and Ω̃ neighbor caches per agent using the central CacheHub.

    - Uses omega_field_cached(ctx, ...) so the heavy work lives in CacheHub,
      which is per-step cleared via ctx.cache.clear_on_step(...).
    - Optionally stores results in agent.Omega_cache / Omega_tilde_cache for
      legacy code that reads them directly (set store_per_agent=False to skip).
    - Safe on subsets of agents (works from local id map).
    """
    if not agents:
        return

    # Normalize agents -> iterable + id->agent map (subset-aware)
    if isinstance(agents, dict):
        agent_list = list(agents.values())
        id_map = {int(getattr(a, "id", i)): a for i, a in enumerate(agent_list)}
    else:
        agent_list = list(agents or [])
        id_map = {int(getattr(a, "id", i)): a for i, a in enumerate(agent_list)}

    for agent_i in agent_list:
        if agent_i is None:
            continue

        # Reset/ensure legacy dicts (optional)
        if store_per_agent:
            agent_i.Omega_cache = {}
            agent_i.Omega_tilde_cache = {}

        neigh = getattr(agent_i, "neighbors", ()) or ()
        for nb in neigh:
            try:
                j_id = int(nb.get("id"))
            except Exception:
                if strict:
                    raise
                if debug:
                    print(f"[omega] skip neighbor with bad id: {nb!r}")
                continue

            agent_j = id_map.get(j_id)
            if agent_j is None:
                # neighbor not in this subset; skip quietly
                if debug:
                    print(f"[omega] neighbor {j_id} not in subset, skipping")
                continue

            # Generators: try agents first, otherwise fallback to shapes
            Gq_i = getattr(agent_i, "generators_q", None)
            Gp_i = getattr(agent_i, "generators_p", None)
            if Gq_i is None or Gp_i is None:
                # light fallback (build-by-size) if needed
                from get_generators import get_generators
                if Gq_i is None:
                    Kq = int(getattr(agent_i, "mu_q_field").shape[-1])
                    Gq_i, _ = get_generators("so3", Kq, return_meta=True)
                if Gp_i is None:
                    Kp = int(getattr(agent_i, "mu_p_field").shape[-1])
                    Gp_i, _ = get_generators("so3", Kp, return_meta=True)

            # Compute Ω via cache (no reliance on _exp_* being present)
            try:
                Omega_ij = omega_field_cached(ctx, agent_i.phi,       agent_j.phi,       Gq_i, group="so3", invert_j=False)
                Omega_t  = omega_field_cached(ctx, agent_i.phi_model, agent_j.phi_model, Gp_i, group="so3", invert_j=False)
            except Exception as e:
                if strict:
                    raise
                if debug:
                    print(f"[omega] failed pair (i={getattr(agent_i,'id','?')}, j={j_id}): {e}")
                continue

            if store_per_agent:
                agent_i.Omega_cache[j_id]       = Omega_ij.astype(np.float32, copy=False)
                agent_i.Omega_tilde_cache[j_id] = Omega_t.astype(np.float32, copy=False)

            
 # preprocess_utils.py




from omega import exp_grid_cached  # CacheHub-backed exp(±φ)

# preprocess_utils.py


from typing import Optional




def preprocess_agent_fields(agent, params=None, G_q=None, G_p=None, *, ctx: Optional[object] = None):
    """
    Prepare per-agent fields (generators, Σ sanitize/inv, cond proxies, exp(±φ), Fisher).
    CacheHub-backed via ctx for exp grids. Safe to call repeatedly per step.
    """
    params     = params or {}
    eps        = float(getattr(config, "eps", 1e-8))
    group_name = str(getattr(config, "group_name", "so3"))
    strict     = bool(params.get("sanitize_strict", True))
    step_tag   = int(params.get("step", getattr(ctx, "global_step", -1) or -1))

    # ---------- fast idempotency (per step) ----------
    if getattr(agent, "_preprocessed_step", None) == step_tag and step_tag >= 0:
        return

    # ---------- infer K & ensure mask ----------
    try:
        Kq = int(agent.mu_q_field.shape[-1])
        Kp = int(agent.mu_p_field.shape[-1])
    except Exception as e:
        raise ValueError("preprocess_agent_fields: agent.mu_q_field / mu_p_field missing or malformed") from e

    if not hasattr(agent, "mask") or agent.mask is None:
        H, W = agent.mu_q_field.shape[:2]
        agent.mask = np.ones((H, W), np.float32)

    # ---------- generators: provided → on-agent → build ----------
    if G_q is not None: agent.generators_q = G_q
    if G_p is not None: agent.generators_p = G_p

    G_q = getattr(agent, "generators_q", None)
    if G_q is None or (isinstance(G_q, np.ndarray) and G_q.size == 0):
        G_q, _ = get_generators(group_name, Kq, return_meta=True)
        agent.generators_q = G_q

    G_p = getattr(agent, "generators_p", None)
    if G_p is None or (isinstance(G_p, np.ndarray) and G_p.size == 0):
        G_p, _ = get_generators(group_name, Kp, return_meta=True)
        agent.generators_p = G_p

    # ---------- SPD sanitize & inverses ----------
    agent.sigma_q_field = sanitize_sigma(agent.sigma_q_field, strict=strict, eps=eps)
    agent.sigma_p_field = sanitize_sigma(agent.sigma_p_field, strict=strict, eps=eps)
    agent.sigma_q_inv   = safe_inv(agent.sigma_q_field, eps=eps)
    agent.sigma_p_inv   = safe_inv(agent.sigma_p_field, eps=eps)

    # ---------- condition proxies ----------
    agent._cond_proxy_q = masked_cond_proxy(agent.sigma_q_field, agent.mask)
    agent._cond_proxy_p = masked_cond_proxy(agent.sigma_p_field, agent.mask)

    # ---------- exp(φ), exp(φ̃) via CacheHub ----------
    agent._exp_phi       = exp_grid_cached(ctx, np.asarray(agent.phi),       agent.generators_q, group=group_name, sign=+1).astype(np.float32, copy=False)
    agent._exp_phi_model = exp_grid_cached(ctx, np.asarray(agent.phi_model), agent.generators_p, group=group_name, sign=+1).astype(np.float32, copy=False)

    # exp(−φ), exp(−φ̃): transpose for orthogonal SO(3), else cached -sign
    if bool(getattr(config, "so3_irreps_are_orthogonal", True)) and group_name.lower() == "so3":
        agent._exp_neg_phi       = np.swapaxes(agent._exp_phi,       -1, -2)
        agent._exp_neg_phi_model = np.swapaxes(agent._exp_phi_model, -1, -2)
    else:
        agent._exp_neg_phi       = exp_grid_cached(ctx, np.asarray(agent.phi),       agent.generators_q, group=group_name, sign=-1).astype(np.float32, copy=False)
        agent._exp_neg_phi_model = exp_grid_cached(ctx, np.asarray(agent.phi_model), agent.generators_p, group=group_name, sign=-1).astype(np.float32, copy=False)

    # ---------- legacy per-agent Ω dicts kept empty (central cache is authoritative) ----------
    agent.Omega_cache = {}
    agent.Omega_tilde_cache = {}

    # ---------- optional Fisher (ctx-aware if available) ----------
    try:
        from natural_gradient import compute_inverse_fisher_field_natural
        try:
            agent.inverse_fisher_phi = compute_inverse_fisher_field_natural(agent, agent.generators_q, field="phi", ctx=ctx)
        except TypeError:
            agent.inverse_fisher_phi = compute_inverse_fisher_field_natural(agent, agent.generators_q, field="phi")
        try:
            agent.inverse_fisher_phi_model = compute_inverse_fisher_field_natural(agent, agent.generators_p, field="phi_model", ctx=ctx)
        except TypeError:
            agent.inverse_fisher_phi_model = compute_inverse_fisher_field_natural(agent, agent.generators_p, field="phi_model")
    except Exception:
        # leave existing values if present
        agent.inverse_fisher_phi        = getattr(agent, "inverse_fisher_phi", None)
        agent.inverse_fisher_phi_model  = getattr(agent, "inverse_fisher_phi_model", None)

    # ---------- dev assert ----------
    if bool(getattr(config, "assert_spd_after_sanitize", False)):
        wq = np.linalg.eigvalsh(0.5 * (agent.sigma_q_field + np.swapaxes(agent.sigma_q_field, -1, -2)))
        wp = np.linalg.eigvalsh(0.5 * (agent.sigma_p_field + np.swapaxes(agent.sigma_p_field, -1, -2)))
        floor = float(getattr(config, "sigma_eig_floor", 1e-6))
        if (wq <= floor).any() or (wp <= floor).any():
            raise RuntimeError("Non-SPD Σ after sanitize.")

    # mark done for this step
    agent._preprocessed_step = step_tag


