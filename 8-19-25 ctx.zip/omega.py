
import numpy as np
import config
from scipy.linalg import expm
from joblib import Parallel, delayed, parallel_backend
from numerical_utils import sanitize_sigma
from numerical_utils import safe_omega_inv
import warnings




def _arr_key(a):
    a = np.asarray(a)
    return (int(a.__array_interface__['data'][0]), a.shape, a.dtype.str)

def exp_grid_cached(ctx, phi, generators, *, group="so3", sign=+1, clip=None, thr=1e-3):
    """
    Cached wrapper for exp(±φ) grid. Uses ctx.cache.ns('exp') if available.
    Falls back to raw compute if no ctx/cache is provided.
    """
    hub = getattr(ctx, "cache", None) if ctx is not None else None
    ns = hub.ns("exp") if hub is not None else None
    k = None
    if ns is not None:
        k = (_arr_key(phi), _arr_key(generators), str(group), int(sign),
             None if clip is None else float(clip), float(thr))
        hit = ns.get(k)
        if hit is not None:
            return hit

    # === call your existing implementation ===
    # Rename if your function name differs:
    E = get_E_grid_from_phi(phi, generators, group_name=group, sign=sign, clip=clip, threshold=thr)

    if ns is not None:
        ns[k] = E
    return E

def omega_field_cached(ctx, phi_i, phi_j, generators, *, group="so3", invert_j=True):
    """
    Cached wrapper for Ω_{ij} field. Uses ctx.cache.ns('omega').
    """
    hub = getattr(ctx, "cache", None) if ctx is not None else None
    ns = hub.ns("omega") if hub is not None else None
    k = None
    if ns is not None:
        k = (_arr_key(phi_i), _arr_key(phi_j), _arr_key(generators), str(group), bool(invert_j))
        hit = ns.get(k)
        if hit is not None:
            return hit

    # === call your exact Ω builder ===
    Om = compute_inter_omega_fieldwise(phi_i, phi_j, generators, group_name=group, invert_j=invert_j)  # existing

    if ns is not None:
        ns[k] = Om
    return Om



def get_E_grid_from_phi(
    phi: np.ndarray,
    generators: np.ndarray,
    group_name: str = "so3",
    sign: int = +1,
    clip: float | None = None,
    threshold: float = 1e-3,
) -> np.ndarray:
    """
    Compute exp(±φ) for each pixel / point.

    Args
    ----
    phi         : (H,W,d) grid OR (M,d) flat batch
    generators  : (..., K, K) irrep generators for the group
    group_name  : e.g. "so3"
    sign        : +1 → exp(+φ), -1 → exp(-φ)
    clip        : optional max_norm / clipping for the algebra vector
    threshold   : series/expm threshold forwarded to exp_lie_algebra_irrep

    Returns
    -------
    E           : (H,W,K,K) if grid input, else (M,K,K) for flat input
    dtype       : float32
    """
    v = np.asarray(phi)
    if sign < 0:
        v = -v

    # flat compute
    if v.ndim == 2:  # (M, d)
        M, d = v.shape
        E_flat = exp_lie_algebra_irrep(
            v.reshape(M, d),
            generators,
            group_name=group_name,
            max_norm=clip,
            threshold=threshold,
            parallelize_expm=False,
        )
        return E_flat.astype(np.float32, copy=False)

    # grid compute → flatten, compute, reshape back
    if v.ndim == 3:  # (H, W, d)
        H, W, d = v.shape
        E_flat = exp_lie_algebra_irrep(
            v.reshape(-1, d),
            generators,
            group_name=group_name,
            max_norm=clip,
            threshold=threshold,
            parallelize_expm=False,
        )
        K = E_flat.shape[-1]
        return E_flat.reshape(H, W, K, K).astype(np.float32, copy=False)

    raise ValueError(f"get_E_grid_from_phi: expected (H,W,d) or (M,d), got shape {phi.shape}")


# ------------------------ Ω_ij with cache (grid or batched points) ------------------------

def compute_inter_omega_fieldwise(
    phi_i: np.ndarray,
    phi_j: np.ndarray,
    generators: np.ndarray,
    *,
    ctx=None,
    group_name: str = "so3",
    invert_j: bool = False,
    clip_norm=None,
    threshold: float = 1e-3,
) -> np.ndarray:
    """
    Ω_ij(x) = exp(φ_i(x)) · exp(−φ_j(x))      (default, invert_j=False)
           = exp(φ_i(x)) · inv(exp(φ_j(x)))   (invert_j=True, solved without forming inv)

    - Uses the central CacheHub:
        - Stores Ω in ns('omega') keyed by (phi_i, phi_j, G, group, invert flag, dims)
        - Reuses exp(±φ) grids via ns('exp') through exp_grid_cached(...)
    - Supports grid inputs (H,W,d) and flat batches (M,d).
    """
    import numpy as np

    def _arr_key(a):
        a = np.asarray(a)
        return (int(a.__array_interface__["data"][0]), a.shape, a.dtype.str)

    phi_i = np.asarray(phi_i)
    phi_j = np.asarray(phi_j)
    if phi_i.shape != phi_j.shape:
        raise ValueError(f"[compute_inter_omega_fieldwise] shape mismatch: {phi_i.shape} vs {phi_j.shape}")

    # ---- cache key in the 'omega' namespace --------------------------------
    hub = getattr(ctx, "cache", None) if ctx is not None else None
    ns_omega = hub.ns("omega") if hub is not None else None
    omega_key = None
    if ns_omega is not None:
        omega_key = (
            _arr_key(phi_i), _arr_key(phi_j), _arr_key(generators),
            str(group_name), bool(invert_j),
            "grid" if phi_i.ndim == 3 else "flat",
        )
        hit = ns_omega.get(omega_key)
        if hit is not None:
            return hit

    # ---- grid path: (H,W,d) using cached exp grids --------------------------
    if phi_i.ndim == 3:
        # Require exp grid cache wrapper (must be defined in omega.py)
        from omega import exp_grid_cached

        Ei = exp_grid_cached(ctx, phi_i, generators, group=group_name, sign=+1)

        if invert_j:
            # Solve per-pixel: Ω = Ei @ inv(Ej) = ((solve(Ej^T, Ei^T))^T)
            Ej = exp_grid_cached(ctx, phi_j, generators, group=group_name, sign=+1)
            K = Ej.shape[-1]
            N = Ei.shape[0] * Ei.shape[1]
            EjT = Ej.reshape(N, K, K).transpose(0, 2, 1)
            EiT = Ei.reshape(N, K, K).transpose(0, 2, 1)
            X_T = np.linalg.solve(EjT, EiT)           # (N,K,K)
            Omega = X_T.transpose(0, 2, 1).reshape(Ei.shape)
        else:
            Emj = exp_grid_cached(ctx, phi_j, generators, group=group_name, sign=-1)
            Omega = np.einsum("...ik,...kj->...ij", Ei, Emj, optimize=True)

        Omega = Omega.astype(np.float32, copy=False)
        if ns_omega is not None:
            ns_omega[omega_key] = Omega
        return Omega

    # ---- flat path: (M,d), compute directly (small batches; no grid cache) --
    d = phi_i.shape[-1]
    Ei = exp_lie_algebra_irrep(
        phi_i.reshape(-1, d), generators,
        group_name=group_name, max_norm=clip_norm, threshold=threshold,
        parallelize_expm=False,
    )

    if invert_j:
        Ej = exp_lie_algebra_irrep(
            phi_j.reshape(-1, d), generators,
            group_name=group_name, max_norm=clip_norm, threshold=threshold,
            parallelize_expm=False,
        )
        # Ω = Ei @ inv(Ej)  →  solve(Ej^T, Ei^T)^T
        EjT = np.transpose(Ej, (0, 2, 1))
        EiT = np.transpose(Ei, (0, 2, 1))
        Omega_flat_T = np.linalg.solve(EjT, EiT)
        Omega_flat = np.transpose(Omega_flat_T, (0, 2, 1))
    else:
        Emj = exp_lie_algebra_irrep(
            (-phi_j).reshape(-1, d), generators,
            group_name=group_name, max_norm=clip_norm, threshold=threshold,
            parallelize_expm=False,
        )
        Omega_flat = np.einsum("nik,nkj->nij", Ei, Emj, optimize=True)

    Omega = Omega_flat.reshape(*phi_i.shape[:-1], Ei.shape[-2], Ei.shape[-1]).astype(np.float32, copy=False)
    if ns_omega is not None:
        ns_omega[omega_key] = Omega
    return Omega














def bch(A, B, max_norm=10.0, inf_tol=1e6, verbose=False):
    """
    4th-order BCH approximation with clipping and numerical guards.

    Computes:
        log(exp(A) @ exp(B)) ≈ A + B + ½[A,B] + 1/12 [A,[A,B]] - 1/12 [B,[B,A]] - 1/24 [B,[A,[A,B]]]

    Args:
        A, B       : (K, K) real matrices (Lie algebra elements)
        max_norm   : clip input matrices if ||M|| > max_norm (for stability)
        inf_tol    : if output norm > inf_tol, emit warning
        verbose    : if True, print norm diagnostics

    Returns:
        Real matrix (K, K) — safe approximation to log(exp(A) @ exp(B))
    """
    
    # Defensive copy
    A = np.array(A, dtype=np.float64, copy=True)
    B = np.array(B, dtype=np.float64, copy=True)

    # ─── Clip A and B to max_norm ───
    for name, M in zip(("A", "B"), (A, B)):
        norm = np.linalg.norm(M, ord=np.inf)
        if not np.isfinite(norm) or norm > max_norm:
            scale = max_norm / (norm + 1e-10)
            M *= scale
            if verbose:
                print(f"[bch] Clipped {name} norm {norm:.2e} → {max_norm:.2f}")

    # ─── Commutators ───
    AB   = A @ B - B @ A
    AAB  = A @ AB - AB @ A
    BAB  = B @ AB - AB @ B
    BAAB = B @ AAB - AAB @ B

    # ─── BCH Expansion ───
    out = A + B
    out += 0.5 * AB
    out += (1.0 / 12.0) * AAB
    out -= (1.0 / 12.0) * BAB
    out -= (1.0 / 24.0) * BAAB

    # ─── Final Safety Guard ───
    out = np.nan_to_num(out, nan=0.0, posinf=max_norm, neginf=-max_norm)

    out_norm = np.linalg.norm(out, ord="fro")
    if not np.isfinite(out_norm) or out_norm > inf_tol:
        warnings.warn(f"[bch] Large or invalid BCH result ‖out‖ = {out_norm:.2e}", RuntimeWarning)

    return out


def safe_bch_exact(A, B, max_norm=5.0, verbose=False):
    """
    BCH approximation with norm clipping for safety.
    No use of logm or expm. Always returns real-valued BCH result.
    """
    A = np.array(A, dtype=np.float64, copy=True)
    B = np.array(B, dtype=np.float64, copy=True)

    for name, M in zip(("A", "B"), (A, B)):
        norm = np.linalg.norm(M, ord=np.inf)
        if norm > max_norm:
            M *= max_norm / (norm + 1e-10)
            if verbose:
                warnings.warn(f"[safe_bch] Clipped {name} norm {norm:.2e} → {max_norm}", RuntimeWarning)

    C = bch(A, B)
    return np.nan_to_num(C, nan=0.0, posinf=max_norm, neginf=-max_norm)



def adaptive_expm(G, clip_norm=None, max_norm=None, threshold=1e-3):
    """
    Numerically robust expm(G) with optional scaling and Taylor fallback.
    Used for small individual matrices.
    """
    if not np.all(np.isfinite(G)):
        raise ValueError("[adaptive_expm] Input G contains NaN or Inf")

    norm_G = np.linalg.norm(G, ord=np.inf) + 1e-16

    if max_norm is not None and norm_G > max_norm:
        G = G * (max_norm / norm_G)
        norm_G = max_norm
    elif clip_norm is not None and norm_G > clip_norm:
        G = G * (clip_norm / norm_G)
        norm_G = clip_norm

    if norm_G < threshold:
        I = np.eye(G.shape[0], dtype=G.dtype)
        G2 = G @ G
        G3 = G2 @ G
        G4 = G3 @ G
        out = I + G + 0.5 * G2 + (1/6) * G3 + (1/24) * G4
    else:
        out = expm(G)

    return np.nan_to_num(out, nan=0.0, posinf=1e6, neginf=-1e6)





def adaptive_expm_batch(G_batch, n_jobs=-1, clip_norm=None, max_norm=None, threshold=1e-3, parallel_threshold=64):
    """
    Batched expm(G). Uses joblib only when N >= parallel_threshold.
    """
    G_batch = np.asarray(G_batch)
    N = G_batch.shape[0]
    if N == 0:
        return G_batch
    if N < parallel_threshold:
        return np.stack([adaptive_expm(G_batch[i], clip_norm, max_norm, threshold) for i in range(N)], axis=0)

    from joblib import Parallel, delayed, parallel_backend
    with parallel_backend("threading"):
        results = Parallel(n_jobs=n_jobs, batch_size=8)(
            delayed(adaptive_expm)(G_batch[i], clip_norm, max_norm, threshold) for i in range(N)
        )
    return np.stack(results, axis=0)




def exp_lie_algebra_irrep(
    v_batch,
    generators,
    use_expm=True,
    threshold=1e-3,
    max_norm=None,
    group_name="so3",
    n_jobs=-1,
    verbose=False,
    parallelize_expm=False,  # NEW toggle to control internal parallelism
):
    """
    Compute batch of exp(sum_a v[a] * T_a) using Taylor or expm depending on norm.

    Parameters:
        v_batch    : (..., dim_G) Lie algebra coefficients
        generators : (dim_G, K, K) Lie algebra generators
        use_expm   : if True, fallback to expm for large-norm elements
        threshold  : Taylor cutoff norm
        max_norm   : optional clip threshold (default from config.phi_exp_clip)
        group_name : used for antisymmetrization ("so3", "su2", etc)
        n_jobs     : number of parallel workers for expm fallback (only if parallelize_expm=True)
        verbose    : whether to print clipping info
        parallelize_expm : bool, whether to parallelize expm fallback internally

    Returns:
        (..., K, K) exponentiated matrices
    """

    *batch_shape, dim_G = v_batch.shape
    v_flat = v_batch.reshape(-1, dim_G)
    N = v_flat.shape[0]
    _, K, _ = generators.shape
    dtype = np.result_type(v_batch, generators)

    clip_norm = max_norm if max_norm is not None else getattr(config, "phi_exp_clip", np.pi)
    norm_type = getattr(config, "gradient_clip_norm_type", 2)

    eps = 1e-16

    norms = np.linalg.norm(v_flat, axis=1, ord=norm_type)
    scale_factors = np.minimum(1.0, clip_norm / (norms + eps))
    v_scaled = v_flat * scale_factors[:, None]
    norms_scaled = np.linalg.norm(v_scaled, axis=1, ord=norm_type)

    if verbose and np.any(scale_factors < 1.0):
        print(f"[Ω] Clipped {np.sum(scale_factors < 1)} / {N} φ vectors to ‖φ‖ ≤ {clip_norm}")

    G_batch = np.einsum("na,aij->nij", v_scaled, generators)

    if group_name == "so3":
        G_batch = 0.5 * (G_batch - np.transpose(G_batch, axes=(0, 2, 1)))
    elif group_name == "su2":
        G_batch = 0.5 * (G_batch - np.transpose(G_batch, axes=(0, 2, 1)).conj())
    elif group_name is None:
        import warnings
        warnings.warn("[exp_lie_algebra_irrep] group_name not set — antisymmetrization skipped", stacklevel=2)

    result = np.empty((N, K, K), dtype=dtype)
    approx_mask = norms_scaled < threshold

    if np.any(approx_mask):
        G_approx = G_batch[approx_mask]
        I = np.eye(K, dtype=dtype)[None, :, :]
        G2 = np.matmul(G_approx, G_approx)
        G3 = np.matmul(G2, G_approx)
        G4 = np.matmul(G2, G2)
        result[approx_mask] = (
            I + G_approx + 0.5 * G2 + (1.0 / 6.0) * G3 + (1.0 / 24.0) * G4
        )

    if np.any(~approx_mask):
        G_heavy = G_batch[~approx_mask]
        if parallelize_expm:
            
            with parallel_backend("threading"):
                expm_results = Parallel(n_jobs=n_jobs)(
                    delayed(adaptive_expm)(G, clip_norm=None, max_norm=clip_norm, threshold=0.0)
                    for G in G_heavy
                )
        else:
            # Sequential fallback to avoid nested parallelism
            expm_results = [adaptive_expm(G, clip_norm=None, max_norm=clip_norm, threshold=0.0) for G in G_heavy]

        result[~approx_mask] = np.stack(expm_results, axis=0)

    result = np.nan_to_num(result, nan=0.0, posinf=1e6, neginf=-1e6)
    return result.reshape(*batch_shape, K, K)




def d_exp_phi_exact(phi_vec, generators, exp_phi_all=None, eps=1e-12):
    """
    Fast ∂/∂φ^a e^{φ} for SO(3) in any K×K matrix irrep.

    Uses e^{Φ} · ( G_a - c1 ad_Φ(G_a) + c2 ad_Φ^2(G_a) ),
    with c1(θ) = (1 - cos θ)/θ^2, c2(θ) = (θ - sin θ)/θ^3.

    Args:
        phi_vec     : (..., 3)
        generators  : (3, K, K)
        exp_phi_all : (..., K, K) optional precomputed e^{Φ}
        eps         : small guard

    Returns:
        list of length 3: each (..., K, K)
    """
    phi_vec = np.asarray(phi_vec, dtype=np.float32)
    generators = np.asarray(generators, dtype=np.float32)
    *shape, d = phi_vec.shape
    assert d == 3, "This QUICK path assumes SO(3) (d=3)."
    K = generators.shape[-1]
    N = int(np.prod(shape)) if shape else 1

    # Flatten to (N, 3)
    phi_flat = phi_vec.reshape(N, 3)

    # Φ = Σ_a φ^a G_a  → (N, K, K)
    Phi = np.einsum("na,aij->nij", phi_flat, generators, optimize=True)

    # θ = ||φ||
    theta = np.linalg.norm(phi_flat, axis=1)
    theta2 = theta * theta
    theta3 = theta2 * theta

    # c1, c2 with small-θ series
    c1 = np.empty_like(theta, dtype=np.float32)
    c2 = np.empty_like(theta, dtype=np.float32)
    small = theta < 1e-4
    if np.any(small):
        t = theta[small]
        t2 = t * t
        t4 = t2 * t2
        c1[small] = 0.5 - t2/24.0 + t4/720.0
        c2[small] = 1.0/6.0 - t2/120.0 + t4/5040.0
    big = ~small
    if np.any(big):
        tb = theta[big]
        c1[big] = (1.0 - np.cos(tb)) / np.maximum(tb*tb, eps)
        c2[big] = (tb - np.sin(tb)) / np.maximum(tb*tb*tb, eps)

    # Ensure e^{Φ} available: (N, K, K)
    if exp_phi_all is None:
        E = exp_lie_algebra_irrep(phi_flat, generators, group_name="so3", parallelize_expm=False)
    else:
        E = np.asarray(exp_phi_all, dtype=np.float32).reshape(N, K, K)

    # Broadcast mats
    # PhiN:  (1,N,K,K), G_A: (A,1,K,K)
    PhiN = Phi[None, ...]
    G_A  = generators[:, None, :, :]  # A=3

    # comm1[a,n] = [Φ_n, G_a] = Φ G - G Φ  → (A,N,K,K)
    comm1 = (PhiN @ G_A) - (G_A @ PhiN)

    # comm2[a,n] = [Φ_n, [Φ_n, G_a]] = Φ·comm1 - comm1·Φ  → (A,N,K,K)
    comm2 = (PhiN @ comm1) - (comm1 @ PhiN)

    # Q_a = G_a - c1 ad_Φ(G_a) + c2 ad_Φ^2(G_a)
    c1b = c1[None, :, None, None]      # (1,N,1,1)
    c2b = c2[None, :, None, None]      # (1,N,1,1)
    G_b = G_A                          # (A,1,K,K)
    Q   = G_b - c1b * comm1 + c2b * comm2  # (A,N,K,K)

    # ∂ e^{φ} / ∂ φ^a = e^{Φ} @ Q_a  → (A,N,K,K)
    d_exp = np.einsum("nij,anjk->anik", E, Q, optimize=True)

    # Reshape back and split list
    d_exp = d_exp.reshape(3, *shape, K, K).astype(np.float32, copy=False)
    return [d_exp[i] for i in range(3)]


def d_exp_phi_tilde_exact(phi_tilde_vec, generators, exp_phi_tilde_all=None, eps=1e-12):
    """
    Fast ∂/∂φ̃^a e^{φ̃} for SO(3) in any K×K matrix irrep.

    Uses: ∂ e^{φ̃} / ∂ φ̃^a = e^{Φ̃} · ( G_a - c1 ad_{Φ̃}(G_a) + c2 ad_{Φ̃}^2(G_a) )
    where c1(θ) = (1-cosθ)/θ^2, c2(θ) = (θ - sinθ)/θ^3, θ = ||φ̃||.

    Args:
        phi_tilde_vec     : (..., 3)
        generators        : (3, K, K) basis
        exp_phi_tilde_all : (..., K, K) optional precomputed e^{Φ̃}
        eps               : small denom guard

    Returns:
        list of length 3 with arrays of shape (..., K, K)
    """
    phi_tilde_vec = np.asarray(phi_tilde_vec, dtype=np.float32)
    generators = np.asarray(generators, dtype=np.float32)
    *shape, d = phi_tilde_vec.shape
    assert d == 3, "This QUICK path assumes SO(3) (d=3)."
    K = generators.shape[-1]
    N = int(np.prod(shape)) if shape else 1

    phi_flat = phi_tilde_vec.reshape(N, 3)
    Phi = np.einsum("na,aij->nij", phi_flat, generators, optimize=True)

    theta = np.linalg.norm(phi_flat, axis=1)
    c1 = np.empty_like(theta, dtype=np.float32)
    c2 = np.empty_like(theta, dtype=np.float32)

    small = theta < 1e-4
    if np.any(small):
        t  = theta[small]
        t2 = t * t
        t4 = t2 * t2
        c1[small] = 0.5 - t2/24.0 + t4/720.0
        c2[small] = 1.0/6.0 - t2/120.0 + t4/5040.0
    big = ~small
    if np.any(big):
        tb = theta[big]
        c1[big] = (1.0 - np.cos(tb)) / np.maximum(tb*tb, eps)
        c2[big] = (tb - np.sin(tb))  / np.maximum(tb*tb*tb, eps)

    if exp_phi_tilde_all is None:
        E = exp_lie_algebra_irrep(phi_flat, generators, group_name="so3", parallelize_expm=False)
    else:
        E = np.asarray(exp_phi_tilde_all, dtype=np.float32).reshape(N, K, K)

    PhiN = Phi[None, ...]
    G_A  = generators[:, None, :, :]

    comm1 = (PhiN @ G_A) - (G_A @ PhiN)        # (A,N,K,K)
    comm2 = (PhiN @ comm1) - (comm1 @ PhiN)    # (A,N,K,K)

    c1b = c1[None, :, None, None]
    c2b = c2[None, :, None, None]
    Q   = G_A - c1b*comm1 + c2b*comm2          # (A,N,K,K)

    d_exp = np.einsum("nij,anjk->anik", E, Q, optimize=True)
    d_exp = d_exp.reshape(3, *shape, K, K).astype(np.float32, copy=False)
    return [d_exp[i] for i in range(3)]



def batch_apply_omega(mu_batch, sigma_batch, omega_batch, eps=1e-8):
    """
    μ' = Ω μ,  Σ' = Ω Σ Ωᵀ  (broadcast-safe, SPD-sanitized)
    """
    mu_batch    = np.asarray(mu_batch)
    sigma_batch = np.asarray(sigma_batch)
    omega_batch = np.asarray(omega_batch)

    # shape checks
    if mu_batch.shape[:-1] != omega_batch.shape[:-2]:
        raise ValueError(f"[Ω] Batch shape mismatch: mu {mu_batch.shape}, omega {omega_batch.shape}")
    if mu_batch.shape[-1] != omega_batch.shape[-1]:
        raise ValueError(f"[Ω] Fiber dim mismatch: mu {mu_batch.shape[-1]}, omega {omega_batch.shape[-1]}")
    if sigma_batch.shape[-2:] != (mu_batch.shape[-1], mu_batch.shape[-1]):
        raise ValueError(f"[Ω] Sigma shape mismatch: got {sigma_batch.shape[-2:]} vs mu dim {mu_batch.shape[-1]}")

    # SPD guard
    S = 0.5 * (sigma_batch + np.swapaxes(sigma_batch, -1, -2))
    S = sanitize_sigma(S, eps=eps)

    mu_out = np.einsum("...ij,...j->...i", omega_batch, mu_batch, optimize=True)
    # Ω Σ Ωᵀ
    sigma_out = np.einsum("...ik,...kl,...jl->...ij", omega_batch, S, omega_batch, optimize=True)
    sigma_out = 0.5 * (sigma_out + np.swapaxes(sigma_out, -1, -2))  # symmetry drift guard
    return mu_out, sigma_out



#==========================================================
#
#                Curvature Ops
#
#==========================================================
def compute_gauge_potential(phi, dx=1.0):
    """
    Compute gauge potential A_μ^a = ∂_μ φ^a using central differences
    with periodic boundary conditions.

    Args:
        phi : np.ndarray, shape (..., d)
            Lie algebra field over a D-dimensional spatial grid.
        dx  : float
            Grid spacing of the base manifold.

    Returns:
        A : tuple of D arrays, each of shape (..., d),
            containing ∂_μ φ^a for μ=0..D−1.
    """
    if phi.ndim < 2:
        raise ValueError("phi must have at least one spatial and one Lie algebra dimension.")

    D = phi.ndim - 1
    return tuple(
        (np.roll(phi, -1, axis=μ) - np.roll(phi, 1, axis=μ)) / (2.0 * dx)
        for μ in range(D)
    )


def compute_field_strength(phi: np.ndarray, generators: np.ndarray, dx: float = 1.0):
    """
    Compute field strength F_{xy} = ∂_x Φ_y − ∂_y Φ_x + [Φ_x, Φ_y],
    treating Φ = φ^a G_a as a Lie-algebra–valued gauge potential.

    Args:
        phi        : (H, W, d) Lie algebra coefficients φ^a(x)
        generators : (d, K, K) Lie algebra basis (e.g. SO(3) or SL(2,R))
        dx         : float, lattice spacing

    Returns:
        dict {"xy": F_xy} where F_xy is (H, W, K, K) curvature tensor
    """
    H, W, d = phi.shape
    K = generators.shape[1]

    phi = np.asarray(phi)
    generators = np.asarray(generators)

    # Φ(x) = φ^a(x) G_a
    phi_matrix = np.einsum("ijk,klm->ijlm", phi, generators)  # (H, W, K, K)

    # A_μ = ∂_μ Φ
    A_x = (np.roll(phi_matrix, -1, axis=0) - np.roll(phi_matrix, 1, axis=0)) / (2 * dx)
    A_y = (np.roll(phi_matrix, -1, axis=1) - np.roll(phi_matrix, 1, axis=1)) / (2 * dx)

    # ∂_μ A_ν
    dAy_dx = (np.roll(A_y, -1, axis=0) - np.roll(A_y, 1, axis=0)) / (2 * dx)
    dAx_dy = (np.roll(A_x, -1, axis=1) - np.roll(A_x, 1, axis=1)) / (2 * dx)

    # [A_x, A_y]
    comm = np.einsum("ijkl,ijln->ijkn", A_x, A_y) - np.einsum("ijkl,ijln->ijkn", A_y, A_x)

    # F_{xy} = ∂_x A_y - ∂_y A_x + [A_x, A_y]
    F_xy = dAy_dx - dAx_dy + comm

    return {"xy": F_xy}

def compute_field_strength_general(phi: np.ndarray, generators: np.ndarray, dx: float = 1.0):
    """
    Compute all nonabelian curvature components F_{μν} = ∂_μ A_ν - ∂_ν A_μ + [A_μ, A_ν].

    Args:
        phi        : (..., d) Lie algebra coordinates
        generators : (d, K, K) Lie algebra basis
        dx         : lattice spacing

    Returns:
        Dictionary {(μ, ν): F_mn} for all μ < ν
    """
    phi_matrix = np.einsum("...a,akl->...kl", phi, generators)
    D = phi.ndim - 1  # spatial dimension
    F = {}

    # Compute A_μ = ∂_μ φ
    A = [
        (np.roll(phi_matrix, -1, axis=mu) - np.roll(phi_matrix, 1, axis=mu)) / (2 * dx)
        for mu in range(D)
    ]

    for mu in range(D):
        for nu in range(mu+1, D):
            dA_nu_mu = (np.roll(A[nu], -1, axis=mu) - np.roll(A[nu], 1, axis=mu)) / (2 * dx)
            dA_mu_nu = (np.roll(A[mu], -1, axis=nu) - np.roll(A[mu], 1, axis=nu)) / (2 * dx)
            comm = np.einsum("...ij,...jk->...ik", A[mu], A[nu]) - np.einsum("...ij,...jk->...ik", A[nu], A[mu])
            F[(mu, nu)] = dA_nu_mu - dA_mu_nu + comm

    return F




def compute_curvature_gradient_analytical(phi, generators, dx: float = 1.0, metric_ab: np.ndarray | None = None):
    """
    ∇_φ Tr(F^2). If generators aren't trace-orthonormal, pass metric_ab = [Tr(G^a G^b)].
    """
    H, W, d = phi.shape
    A_x = (np.roll(phi, -1, 0) - np.roll(phi, 1, 0)) / (2 * dx)
    A_y = (np.roll(phi, -1, 1) - np.roll(phi, 1, 1)) / (2 * dx)

    A_x_mat = np.einsum("ijk,klm->ijlm", A_x, generators)
    A_y_mat = np.einsum("ijk,klm->ijlm", A_y, generators)

    dAy_dx = (np.roll(A_y_mat, -1, 0) - np.roll(A_y_mat, 1, 0)) / (2 * dx)
    dAx_dy = (np.roll(A_x_mat, -1, 1) - np.roll(A_x_mat, 1, 1)) / (2 * dx)
    comm_xy = A_x_mat @ A_y_mat - A_y_mat @ A_x_mat
    F_xy = dAy_dx - dAx_dy + comm_xy

    dF_dx = (np.roll(F_xy, -1, 0) - np.roll(F_xy, 1, 0)) / (2 * dx)
    dF_dy = (np.roll(F_xy, -1, 1) - np.roll(F_xy, 1, 1)) / (2 * dx)
    comm1 = A_x_mat @ F_xy - F_xy @ A_x_mat
    comm2 = A_y_mat @ F_xy - F_xy @ A_y_mat
    divF = dF_dx + dF_dy + comm1 + comm2

    if metric_ab is None:
        # assume Tr(G^a G^b) = δ^{ab}
        grad = 2.0 * np.stack([np.einsum("...ij,ij->...", divF, generators[a]) for a in range(d)], axis=-1)
    else:
        # project with metric inverse
        Ginvs = safe_omega_inv(metric_ab.astype(np.float64, copy=False))
        comps = np.array([np.einsum("...ij,ij->...", divF, generators[a]) for a in range(d)])  # (d,H,W)
        grad = 2.0 * np.einsum("ab,b...->a...", Ginvs, comps).transpose(1,2,0)
    return grad.astype(phi.dtype, copy=False)





#==================================================================
#
#                Holonomy And Transport Utils
#
#==================================================================


def compute_intra_omega(agent, coord_from, coord_to, generators=None, *, fiber="q"):
    """
    Ω(p_to ← p_from) = exp(φ(to)) · exp(−φ(from)) for the given fiber ('q' or 'p').
    """
    if coord_from == coord_to:
        # Identity transport
        K = (generators.shape[-1] if generators is not None 
             else getattr(agent, "generators_q" if fiber=="q" else "generators_p").shape[-1])
        return np.eye(K, dtype=np.float32)

    if generators is None:
        generators = getattr(agent, "generators_q" if fiber=="q" else "generators_p")

    phi_field = agent.phi if fiber == "q" else agent.phi_model
    φ_from = phi_field[coord_from]
    φ_to   = phi_field[coord_to]

    Ei  = exp_lie_algebra_irrep(φ_to[None],   generators, parallelize_expm=False)[0]
    Emj = exp_lie_algebra_irrep((-φ_from)[None], generators, parallelize_expm=False)[0]
    return Ei @ Emj





def compute_inter_omega(*args, **kwargs):
    """
    DEPRECATED in compute paths. Use per_pixel_transport.omega_at(...) for a specific (y,x),
    or per_pixel_transport.apply_transport_gaussian_field(...) for full fields.

    This function remains ONLY for logging at a specified pixel.
    """
    yx = kwargs.get("yx", None)
    if yx is None:
        raise RuntimeError(
            "compute_inter_omega is deprecated without explicit yx. "
            "For computation, use per_pixel_transport.apply_transport_gaussian_field "
            "or per_pixel_transport.omega_at for diagnostics."
        )
    i = kwargs["i"]; j = kwargs["j"]; G = kwargs["generators"]; agents = kwargs["agents"]
    y, x = yx
    phi_i_xy = np.asarray(agents[i].phi[y, x], dtype=float)
    phi_j_xy = np.asarray(agents[j].phi[y, x], dtype=float)
    from per_pixel_transport import omega_at
    return omega_at(phi_i_xy, phi_j_xy, G)





def _curvature_scalar_from_children(children, H, W, *, fiber="q", eps=1e-6):
    """
    Build F(x) ≥ 0 using your curvature: mask-weighted Frobenius norm of F_xy,
    averaged across children on the selected fiber ("q" or "p").
    """
    import numpy as _np
    num = _np.zeros((H, W), _np.float32)
    den = _np.zeros((H, W), _np.float32)

    # pick an irrep basis per-child (preferred) or fall back to the first one that exists
    for c in children:
        M = _np.asarray(getattr(c, "mask", 0.0), _np.float32)
        if M.shape[:2] != (H, W) or float(M.max()) <= 0.0:
            continue

        phi_name = "phi_q_field" if fiber == "q" else "phi_p_field"
        phi = getattr(c, phi_name, None)
        G   = getattr(c, "generators", None)
        if phi is None or G is None:
            continue

        phi = _np.asarray(phi, _np.float32)
        if phi.shape[:2] != (H, W):
            continue  # skip shape mismatches

        # F_xy is (H, W, K, K)
        F = compute_field_strength(phi, _np.asarray(G, _np.float32))["xy"]  # your robust routine
        # scalarize: Frobenius norm per pixel
        Fx = _np.sqrt(_np.clip(_np.sum(F * F, axis=(-2, -1)), 0.0, _np.finfo(_np.float32).max)).astype(_np.float32)

        num += (M * Fx)
        den += _np.maximum(M, 0.0)

    out = _np.zeros((H, W), _np.float32)
    sel = den > eps
    out[sel] = (num[sel] / _np.maximum(den[sel], eps)).astype(_np.float32)
    return out




            # (N, K, K)

