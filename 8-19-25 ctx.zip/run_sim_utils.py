# -*- coding: utf-8 -*-
"""
Created on Tue Aug 12 20:36:43 2025

@author: chris and christine
"""

# run_sim_utils.py
import os, time, shutil, pickle
import numpy as np
import config

from config_utils import set_config_from_params  # re-exported for __main__ use
from get_generators import get_generators

from agent_initialization import initialize_agents, initialize_agent_gradients
from runtime_context import ensure_runtime_defaults
from generalized_diagnostics_metrics import log_all_metrics, dump_snapshot_npz

from viz_parent_masks import save_parent_mask_frame, save_alignment_vs_parents, plot_parent_masks_grid
from update_rules import synchronous_step
from viz_parent_masks import save_parent_mask_delta

# ------------------------------- Logging defaults ----------------------------

LOGGING_DEFAULTS = dict(
    enable_scalar=True,
    enable_fields=True,
       # snapshot knobs (for dump_snapshot_npz)
    compute_alignment=True,   # off by default (heavy)
    compute_curvature=True,   # off by default (heavy)
    fp16_snapshot=True,        # smaller files
    normalize_by_support=True, # used by per-agent logger
    enable_max_overlap=True,    # kept for backwards-compat
    print_total_energy=True,
    fields_every=1,
    max_overlap_every=1,
    schema_version="v3",
    full_field_outdir="fields",
    pair_outdir="max_overlap",
)

def load_checkpoint(outdir):
    """
    Load latest checkpoint.pkl or fallback to latest step_XXXX.pkl in outdir.
    Returns (agents, filename) or (None, None) if none found.
    """
    ckpt_path = os.path.join(outdir, "checkpoint.pkl")
    if os.path.exists(ckpt_path):
        with open(ckpt_path, "rb") as f:
            return pickle.load(f), "checkpoint.pkl"

    step_files = sorted(
        [f for f in os.listdir(outdir) if f.startswith("step_") and f.endswith(".pkl")]
    )
    if not step_files:
        return None, None

    last_step = step_files[-1]
    with open(os.path.join(outdir, last_step), "rb") as f:
        return pickle.load(f), last_step


def find_resume_step(outdir):
    """
    Determine the next step to resume from based on existing saved steps.
    Returns 0 if none found.
    """
    step_files = sorted(
        [f for f in os.listdir(outdir) if f.startswith("step_") and f.endswith(".pkl")]
    )
    if not step_files:
        return 0
    last_step = step_files[-1]
    return int(last_step.replace("step_", "").replace(".pkl", "")) + 1



def save_step(agents, outdir, step):
    """
    Save agent state to step_{step:04d}.pkl and update checkpoint.pkl atomically.
    """
    os.makedirs(outdir, exist_ok=True)
    step_path = os.path.join(outdir, f"step_{step:04d}.pkl")
    ckpt_path = os.path.join(outdir, "checkpoint.pkl")

    with open(step_path, "wb") as f:
        pickle.dump(agents, f)
    with open(ckpt_path, "wb") as f:
        pickle.dump(agents, f)



def merge_logging_cfg(params_or_cfg):
    cfg = {}
    if hasattr(params_or_cfg, "get"):       # dict-like
        cfg = params_or_cfg.get("logging", {}) or {}
    elif hasattr(params_or_cfg, "__dict__"): # module-like (config)
        cfg = getattr(params_or_cfg, "logging", {}) or {}
    out = dict(LOGGING_DEFAULTS)
    out.update(cfg)
    return out


# ------------------------------ Generator prep ------------------------------

def prepare_generators(params):
    Gq = params.get("generators_q")
    Gp = params.get("generators_p")
    if Gq is None:
        Gq, _ = get_generators(config.group_name, config.K_q, return_meta=True)
        params["generators_q"] = Gq
    if Gp is None:
        Gp, _ = get_generators(config.group_name, config.K_p, return_meta=True)
        params["generators_p"] = Gp
    return Gq, Gp


# -------------------------- Init / resume helpers ---------------------------

def initialize_or_resume(outdir, resume, params, clear_agent_logs=True):
    """Return (agents, step_start)."""
    if resume:
        agents, _ = load_checkpoint(outdir)
        step_start = find_resume_step(outdir)
    else:
        agents = initialize_agents(
            seed=getattr(config, "seed", None),
            domain_size=config.domain_size,
            N=config.N,
            K_q=config.K_q,
            K_p=config.K_p,
            lie_algebra_dim=3,
            visualize=False,
            fixed_location=getattr(config, "fixed_location", False),  # <-- config toggle
        )
        step_start = 0
        for A in agents:
            initialize_agent_gradients(A, config)
        if clear_agent_logs:
            for A in agents:
                if hasattr(A, "metrics_log"):
                    A.metrics_log.clear()
    return agents, step_start



def attach_generators_to_agents(agents, Gq, Gp):
    for A in agents:
        A.generators_q = Gq
        A.generators_p = Gp


def ensure_runtime(params):
    ctx = ensure_runtime_defaults(params.get("runtime_ctx", None))
    ctx.mount_level(1)  # legacy lvl-1 view
    return ctx



# --- add near top of file (imports) ---
from typing import Dict, List

# ... keep existing imports ...

# --- add this helper anywhere above log_and_viz_after_step ---
def _log_metrics_by_levels(runtime_ctx, *, children_level0: List, step: int, params: dict, n_jobs: int) -> Dict:
    """
    Compute scalar metrics separately for:
      - level 0 (children_level0 list)
      - each parent level L present in runtime_ctx.parents_by_level
    Returns a dict: {"levels": {0: m0, 1: m1, 2: m2, ...}, "flat": m0} where "flat" preserves legacy total.
    """
    from generalized_diagnostics_metrics import log_all_metrics  # local import to avoid cycles

    out = {"levels": {}}

    # lvl-0 (children)
    m0 = log_all_metrics(children_level0, step=step, params=params, n_jobs=n_jobs)
    out["levels"][0] = m0
    out["flat"] = m0  # preserve old behavior for downstream consumers

    # parents per level
    parents_levels = getattr(runtime_ctx, "parents_by_level", {}) or {}
    for L, bucket in sorted(parents_levels.items()):
        if not bucket:
            continue
        parents_L = list(bucket.values())
        if not parents_L:
            continue
        mL = log_all_metrics(parents_L, step=step, params=params, n_jobs=n_jobs)
        out["levels"][int(L)] = mL

    return out




# --------------------------- Per-step side effects --------------------------

def log_and_viz_after_step(runtime_ctx, agents, step, outdir, params, logcfg,
                           parent_metrics, metric_log, num_cores):
    import os
    import time
    import numpy as np
    import config
    # lightweight, local parent snapshot (no parent_telemetry dependency)
    def _snapshot_parents_npz_simple(parents, save_path):
        """
        Minimal parent snapshot:
          - ids: (P,)
          - masks: (P,H,W) if all shapes equal, else masks_obj: array(object) of HxW
        """
        ids = []
        masks = []
        for idx, P in enumerate(parents):
            ids.append(getattr(P, "id", idx))
            masks.append(np.asarray(getattr(P, "mask", None)))
        out = {"ids": np.asarray(ids, dtype=np.int32)}
        # If masks are same shape we store a dense stack; otherwise store ragged object array
        shapes = {m.shape for m in masks if m is not None}
        if len(shapes) == 1 and len(masks) > 0:
            out["masks"] = np.stack([m.astype(np.float32) for m in masks], axis=0)
        else:
            out["masks_obj"] = np.array([m.astype(np.float32) for m in masks], dtype=object)
        os.makedirs(os.path.dirname(save_path), exist_ok=True)
        np.savez_compressed(save_path, **out)

    # lightweight, local child snapshot (mask-only, small)
    def _snapshot_children_npz_simple(children, save_path):
        """
        Minimal child snapshot:
          - ids:   (N,)
          - masks: (N,H,W)
        """
        ids, masks = [], []
        for idx, C in enumerate(children):
            ids.append(getattr(C, "id", idx))
            masks.append(np.asarray(getattr(C, "mask", None)))
        out = {"ids": np.asarray(ids, dtype=np.int32)}
        shapes = {m.shape for m in masks if m is not None}
        if len(shapes) == 1 and len(masks) > 0:
            out["masks"] = np.stack([m.astype(np.float32) for m in masks], axis=0)
        else:
            out["masks_obj"] = np.array([m.astype(np.float32) for m in masks], dtype=object)
        os.makedirs(os.path.dirname(save_path), exist_ok=True)
        np.savez_compressed(save_path, **out)


    # ── per-step parent field snapshot (throttled via config) ───────────────
    snap_every = int(getattr(config, "parent_snapshot_every", 0))  # 0 = disabled
    snap_dir   = getattr(config, "parent_snapshot_dir", "parents")
    # ── per-step child mask snapshot (throttled via config) ───────────────────
    child_snap_every = int(getattr(config, "child_snapshot_every", 0))  # 0 = disabled
    child_snap_dir   = getattr(config, "child_snapshot_dir", "children")



    def _collect_all_parents(ctx):
        # prefer multi-level sources of truth
        if hasattr(ctx, "parents_by_level") and isinstance(ctx.parents_by_level, dict):
            return [P for d in ctx.parents_by_level.values() for P in (d.values() if isinstance(d, dict) else d)]
        # legacy alias
        if hasattr(ctx, "parents_by_region_L") and isinstance(ctx.parents_by_region_L, dict):
            return [P for d in ctx.parents_by_region_L.values() for P in (d.values() if isinstance(d, dict) else d)]
        return list((getattr(ctx, "parents_by_region", {}) or {}).values())


    if snap_every > 0 and (step % snap_every) == 0:
        parents_now = _collect_all_parents(runtime_ctx)
        if parents_now:
            os.makedirs(os.path.join(outdir, snap_dir), exist_ok=True)
            snap_path = os.path.join(outdir, snap_dir, f"parents_step_{step:04d}.npz")
            try:
                _snapshot_parents_npz_simple(parents_now, snap_path)
                if getattr(config, "debug_parent_masks", False):
                    print(f"[SNAP] saved {len(parents_now)} parents → {snap_path}")
            except Exception as e:
                print(f"[SNAP][ERROR] step {step}: {e}")

    if child_snap_every > 0 and (step % child_snap_every) == 0:
        if agents:
            os.makedirs(os.path.join(outdir, child_snap_dir), exist_ok=True)
            child_snap_path = os.path.join(outdir, child_snap_dir, f"children_step_{step:04d}.npz")
            try:
                _snapshot_children_npz_simple(agents, child_snap_path)
                if getattr(config, "debug_child_masks", False):
                    print(f"[SNAP] saved {len(agents)} children → {child_snap_path}")
            except Exception as e:
                print(f"[SNAP][CHILD][ERROR] step {step}: {e}")

    
    save_parent_mask_delta(runtime_ctx, step, outdir)
    save_parent_mask_frame(runtime_ctx, step, outdir, draw_per_parent=True)
   # save_alignment_vs_parents(runtime_ctx, step, outdir, mode="alignment")

    
    # Debug: show where we intend to write snapshots
    try:
        print("[LOGGING]",
              dict(enable_fields=logcfg.get("enable_fields"),
                   fields_every=logcfg.get("fields_every"),
                   full_field_outdir=logcfg.get("full_field_outdir"),
                   snapshot_dir=os.path.join(outdir, logcfg.get("full_field_outdir","fields")),
                   step=step))
    except Exception:
        pass

    # scalar metrics


    # --- replace the scalar metrics block in log_and_viz_after_step ---
    if logcfg.get("enable_scalar", False):
        t1 = time.perf_counter()

        # NEW: level-aware logging (children + each parent level)
        levels_metrics = _log_metrics_by_levels(runtime_ctx,
                                                children_level0=agents,
                                                step=step, params=params,
                                                n_jobs=num_cores)
        m = dict(levels_metrics.get("flat", {}))  # keep legacy 'm' (lvl-0) for old code paths

        # Attach parent counters (unchanged)
        try:
            parents_now = _collect_all_parents(runtime_ctx)
            m["parents_active"] = len(parents_now)
            if parents_now:
                H, W = agents[0].mask.shape
                union = np.zeros((H, W), dtype=bool)
                for P in parents_now:
                    union |= (np.asarray(P.mask) > 0.3)
                m["parent_coverage_frac"] = float(union.mean())
            else:
                m["parent_coverage_frac"] = 0.0
        except Exception:
            m["parents_active"] = 0
            m["parent_coverage_frac"] = 0.0

        m["schema"] = logcfg.get("schema_version", "unknown")
        m["compute_ms"] = int((time.perf_counter() - t1) * 1000)
        m["levels"] = levels_metrics["levels"]     # <-- persist per-level metrics in the record
        metric_log.append(m)


        def _count_parent_pairs_with_overlap(ctx, tau=0.2, min_px=8):
            parents_levels = getattr(ctx, "parents_by_level", {}) or {}
            out = {}
            for L, bucket in sorted(parents_levels.items()):
                Ps = list(bucket.values()) if isinstance(bucket, dict) else list(bucket)
                masks = [np.asarray(getattr(P, "mask", None)) for P in Ps if getattr(P, "mask", None) is not None]
                n = len(masks)
                pairs = 0
                passed = 0
                for i in range(n):
                    for j in range(i+1, n):
                        pairs += 1
                        inter = (masks[i] > tau) & (masks[j] > tau)
                        if int(inter.sum()) >= min_px:
                            passed += 1
                out[int(L)] = (passed, pairs)
            return out
        
        pairs = _count_parent_pairs_with_overlap(runtime_ctx,
                                                 tau=float(getattr(config, "parent_area_threshold", 0.20)),
                                                 min_px=int(getattr(config, "min_pair_px", 8)))
        for L, (passed, total) in pairs.items():
            print(f"[diag] lvl-{L} parent pairs passing overlap gate: {passed}/{total}")


        # Pretty print: per-level energy breakdown
        if logcfg.get("print_total_energy", True):
            print(f"[Energy Totals @ step {step}]\n\n")

            # lvl-0 (children)
            m0 = levels_metrics["levels"].get(0, {})
            print(f"  [lvl-0 children]")
            print(f"    Self belief      = {m0.get('e_self', 0.0):.4e}")
            print(f"    Feedback model   = {m0.get('e_feedback', 0.0):.4e}")
            print(f"    Belief alignment = {m0.get('e_align', 0.0):.4e}")
            print(f"    Model alignment  = {m0.get('e_mod_align', 0.0):.4e}")
            print(f"    Belief curvature = {m0.get('e_curv', 0.0):.4e}")
            print(f"    Model curvature  = {m0.get('e_curv_mod', 0.0):.4e}")
            print(f"    Belief mass      = {m0.get('e_mass', 0.0):.4e}")
            print(f"    Model mass       = {m0.get('e_mass_mod', 0.0):.4e}")
            if "total_energy" in m0:
                print(f"    ----")
                print(f"    TOTAL            = {m0['total_energy']:.4e}\n\n")

            # parents per level
            for L in sorted(k for k in levels_metrics["levels"].keys() if k != 0):
                mL = levels_metrics["levels"][L]
                print(f"  [lvl-{L} parents]")
                print(f"    Self belief      = {mL.get('e_self', 0.0):.4e}")
                print(f"    Feedback model   = {mL.get('e_feedback', 0.0):.4e}")
                print(f"    Belief alignment = {mL.get('e_align', 0.0):.4e}")
                print(f"    Model alignment  = {mL.get('e_mod_align', 0.0):.4e}")
                print(f"    Belief curvature = {mL.get('e_curv', 0.0):.4e}")
                print(f"    Model curvature  = {mL.get('e_curv_mod', 0.0):.4e}")
                print(f"    Belief mass      = {mL.get('e_mass', 0.0):.4e}")
                print(f"    Model mass       = {mL.get('e_mass_mod', 0.0):.4e}")
                if "total_energy" in mL:
                    print(f"    ----")
                    print(f"    TOTAL            = {mL['total_energy']:.4e}\n\n")

 
    # field dumps
    do_fields = bool(logcfg.get("enable_fields", False))
    cadence   = int(logcfg.get("fields_every", 1) or 1)
    field_dir = os.path.join(outdir, logcfg.get("full_field_outdir", "fields"))

    # Always write a bootstrap snapshot at step 0 (cheap: no align/curv) to prime viz
    if step == 0:
        os.makedirs(field_dir, exist_ok=True)
        try:
            tF0 = time.perf_counter()
            dump_snapshot_npz(agents, step, field_dir,
                              compute_alignment=False,
                              compute_curvature=False,
                              fp16=bool(logcfg.get("fp16_snapshot", True)),
                              params=params)
            print(f"[TIMER] dump_snapshot_npz (bootstrap): {time.perf_counter() - tF0:.3f}s")
        except Exception as e:
            print(f"[SNAPSHOT][ERROR bootstrap] {e}")

    if do_fields and (step % cadence == 0):
        os.makedirs(field_dir, exist_ok=True)
        try:
            tF = time.perf_counter()
            dump_snapshot_npz(
                agents, step, field_dir,
                compute_alignment=bool(logcfg.get("compute_alignment", False)),
                compute_curvature=bool(logcfg.get("compute_curvature", False)),
                fp16=bool(logcfg.get("fp16_snapshot", True)),
                params=params,
            )
            print(f"[TIMER] dump_snapshot_npz: {time.perf_counter() - tF:.3f}s")
        except Exception as e:
            print(f"[SNAPSHOT][ERROR] {e}")



def checkpoint_step(agents, outdir):
    # clear heavy caches then save
    for A in agents:
        if hasattr(A, "clear_omega_cache"):   A.clear_omega_cache()
        if hasattr(A, "clear_fisher_caches"): A.clear_fisher_caches()
    save_step(agents, outdir, runtime_step=None)  # filename is handled downstream


def wrap_epilogue(runtime_ctx, agents, outdir, parent_metrics, metric_log):
    import pandas as pd
   
    # local snapshot helper (same as above) for the final save
    def _snapshot_parents_npz_simple(parents, save_path):
        ids = []
        masks = []
        for idx, P in enumerate(parents):
            ids.append(getattr(P, "id", idx))
            masks.append(np.asarray(getattr(P, "mask", None)))
        out = {"ids": np.asarray(ids, dtype=np.int32)}
        shapes = {m.shape for m in masks if m is not None}
        if len(shapes) == 1 and len(masks) > 0:
            out["masks"] = np.stack([m.astype(np.float32) for m in masks], axis=0)
        else:
            out["masks_obj"] = np.array([m.astype(np.float32) for m in masks], dtype=object)
        os.makedirs(os.path.dirname(save_path), exist_ok=True)
        np.savez_compressed(save_path, **out)

    # metrics log
    if metric_log:
        with open(os.path.join(outdir, "metric_log.pkl"), "wb") as f:
            pickle.dump(metric_log, f)
        print(f"[SAVE] Metrics log --> {os.path.join(outdir, 'metric_log.pkl')}")
        rows = [{"agent": A.id, **e} for A in agents for e in getattr(A, "metrics_log", [])]
        if rows:
            pd.DataFrame(rows).to_csv(os.path.join(outdir, "per_agent_metrics.csv"), index=False)
            print("[SAVE] Per-agent metrics --> per_agent_metrics.csv")

    # parents snapshot
    parents_now = list(runtime_ctx.parents_by_region.values())
    if parents_now:
        try:
            _snapshot_parents_npz_simple(parents_now, os.path.join(outdir, "parents_end.npz"))
        except Exception as e:
            print(f"[SNAP][ERROR] final: {e}")
    # parent metrics csv
    if parent_metrics:
        pd = __import__("pandas")
        pd.DataFrame(parent_metrics).to_csv(os.path.join(outdir, "parent_metrics.csv"), index=False)
        print("[SAVE] Parent metrics --> parent_metrics.csv")
