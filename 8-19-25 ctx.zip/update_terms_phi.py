# -*- coding: utf-8 -*-
"""
Created on Mon Aug 18 09:18:10 2025

@author: chris and christine
"""

# -*- coding: utf-8 -*-
"""
Created on Wed Jul 23 06:38:17 2025

@author: chris and christine
"""
import numpy as np
import config
from omega import compute_curvature_gradient_analytical, d_exp_phi_exact, d_exp_phi_tilde_exact
from natural_gradient import dexpinv_operator, compute_fisher_geometry_gradient
from numerical_utils import safe_inv, sanitize_sigma, safe_omega_inv



#==============================================================================
#
#                    GATHER PHI GAUGE FIELD GRADIENT TERMS
#                          Beliefs and Models
#==============================================================================
def accumulate_phi_alignment_gradient(
    agent_i, agent_j, generators, params,
    field="phi", beta_key=None, omega_cache_key=None,
    mu_key=None, sigma_key=None,
    fisher_inv_key=None, grad_key=None,
    Q_all_i=None,           # list/array (d, ..., K, K)
    exp_neg_phi_j=None,     # (..., K, K)
    agents=None,            # NEW: for Fisher regularizer
):
    """
    Uses ctx.cache (if provided via params['runtime_ctx']) to memoize Ω_{ij}.
    Falls back to legacy per-agent caches (omega_cache_key) for compatibility.
    """
    import numpy as np, config

    beta = params.get(beta_key, getattr(config, beta_key))
    if beta <= 0:
        return

    eps = config.support_cutoff_eps
    joint_mask = ((agent_i.mask > eps) & (agent_j.mask > eps)).astype(np.float32)[..., None]
    if not np.any(joint_mask):
        return

    mu_i    = getattr(agent_i, mu_key)
    sigma_i = getattr(agent_i, sigma_key)
    mu_j    = getattr(agent_j, mu_key)

    phi_i      = getattr(agent_i, field)
    exp_phi_i  = getattr(agent_i, f"_exp_{field}")
    exp_phi_j  = getattr(agent_j, f"_exp_{field}")

    # --- Ω_{ij} via new hub (preferred), else legacy cache ------------------
    Omega_ij = None
    ctx = params.get("runtime_ctx", None)
    if ctx is not None and getattr(ctx, "cache", None) is not None:
        # local import to avoid module-level cycles
        try:
            from omega import omega_field_cached
            Omega_ij = omega_field_cached(ctx, phi_i, getattr(agent_j, field), generators,
                                          group="so3", invert_j=True)
        except Exception:
            Omega_ij = None  # fall through to legacy path on any error

    if Omega_ij is None:
        # Legacy per-agent cache path (kept for backward compatibility)
        if omega_cache_key is None:
            raise RuntimeError("omega_cache_key is required when runtime_ctx cache is unavailable.")
        cache = getattr(agent_i, omega_cache_key, None) or {}
        if agent_j.id not in cache:
            # As a last resort, compute directly using your existing routine.
            # We try to import lazily to avoid cycles; adapt the name if different in your codebase.
            from omega import compute_inter_omega_fieldwise
            cache[agent_j.id] = compute_inter_omega_fieldwise(
                phi_i, getattr(agent_j, field), generators, group_name="so3", invert_j=True
            )
            setattr(agent_i, omega_cache_key, cache)
        Omega_ij = cache[agent_j.id]

    Omega_T  = np.swapaxes(Omega_ij, -1, -2)

    # Push-forward mu_j
    mu_j_t = np.einsum("...ij,...j->...i", Omega_ij, mu_j, optimize=True)

    # Build Sj_t^{-1} via rotation of cached Σ_j^{-1} (orthogonal rep)
    inv_key = sigma_key.replace("_field", "_inv")  # 'sigma_q_field'→'sigma_q_inv'
    sigma_j_inv = getattr(agent_j, inv_key, None)
    if sigma_j_inv is not None:
        sigma_j_t_inv = np.einsum("...ik,...kl,...lj->...ij", Omega_ij, sigma_j_inv, Omega_T, optimize=True)
    else:
        sigma_j = getattr(agent_j, sigma_key)
        sigma_j_t = np.einsum("...ik,...kl,...lj->...ij", Omega_ij, sigma_j, Omega_T, optimize=True)
        sigma_j_t = sanitize_sigma(sigma_j_t, eps=config.eps)
        sigma_j_t_inv = safe_inv(sigma_j_t, eps=config.eps)

    # Precompute Q_all_i and e^{-φ_j} if caller didn’t
    if Q_all_i is None:
        Q_all_i = d_exp_phi_exact(phi_i, generators)
    if exp_neg_phi_j is None:
        cached = f"_exp_neg_{field}"
        exp_neg_phi_j = getattr(agent_j, cached, None)
        if exp_neg_phi_j is None:
            exp_neg_phi_j = safe_omega_inv(exp_phi_j, eps=config.eps, debug=False)

    # Fully vectorized grad over 'a'
    grad_phi_raw = grad_kl_wrt_phi_i(
        mu_i, sigma_i, None, None,   # mu_j/sigma_j unused by the function now
        phi_i=phi_i, phi_j=None,
        Omega_ij=Omega_ij,
        generators=generators,
        exp_phi_i=exp_phi_i,
        exp_phi_j=exp_phi_j,
        mu_j_t=mu_j_t,
        sigma_j_t_inv=sigma_j_t_inv,
        exp_neg_phi_j=exp_neg_phi_j,
        Q_all=Q_all_i,
        eps=config.eps,
    )

    F_inv = getattr(agent_i, fisher_inv_key)
    grad_phi_nat = np.einsum("...ab,...b->...a", F_inv, grad_phi_raw, optimize=True)
    grad_phi = dexpinv_operator(phi_i, grad_phi_nat, generators)

    # Regularizers (fixed Fisher call)
    reg_grad = apply_regularization_terms_lie_natural(
        agent=agent_i,
        phi_field=phi_i,
        generators=generators,
        field=field,
        params=params,
        agents=agents,   # NEW
    ) * joint_mask

    grad_accum = getattr(agent_i, grad_key)
    setattr(agent_i, grad_key, grad_accum + (beta * grad_phi + reg_grad) * joint_mask)

def accumulate_phi_morphism_self_feedback(
    agent_i,
    generators_src, generators_tgt,
    params,
    field="phi",                # or "phi_model"
    fisher_inv_key=None,
    grad_key=None,
    phi_self_func=None,         # e.g. grad_kl_self_phi_direct
    phi_feedback_func=None,     # e.g. grad_kl_feedback_phi_direct
):
    """
    Accumulate ∇_{φ} or ∇_{φ̃} from:
      - KL(q || Φ̃·p)    ← self-energy
      - KL(p || Φ·q)     ← feedback
    into:
      - agent_i.grad_phi or grad_phi_tilde

    Uses params['runtime_ctx'] (if present) to:
      - fetch/cache exp(φ) / exp(φ̃) via the central CacheHub
      - (optionally) compute inverse Fisher via a cached helper if not provided
    """
    import numpy as np, config

    alpha   = params.get("alpha", config.alpha)
    lambda_ = params.get("feedback_weight", config.feedback_weight)
    if alpha <= 0 and lambda_ <= 0:
        return

    eps  = config.support_cutoff_eps
    mask = (agent_i.mask > eps)[..., None]

    mu_q, sigma_q = agent_i.mu_q_field, agent_i.sigma_q_field
    mu_p, sigma_p = agent_i.mu_p_field, agent_i.sigma_p_field
    phi           = agent_i.phi
    phi_tilde     = agent_i.phi_model

    # --- ensure exp grids via hub if available (fallback to existing fields) ---
    ctx = params.get("runtime_ctx", None)
    if ctx is not None:
        try:
            from omega import exp_grid_cached
            if getattr(agent_i, "_exp_phi", None) is None:
                agent_i._exp_phi = exp_grid_cached(ctx, phi, generators_tgt, group="so3", sign=+1)
            if getattr(agent_i, "_exp_phi_model", None) is None:
                agent_i._exp_phi_model = exp_grid_cached(ctx, phi_tilde, generators_src, group="so3", sign=+1)
        except Exception:
            # fall back silently; existing _exp_* fields (or downstream callers) will handle it
            pass

    # Inverse Fisher (prefer precomputed; else optional cached compute)
    F_inv = getattr(agent_i, fisher_inv_key)
    if F_inv is None and ctx is not None:
        try:
            # Optional helper you may add (as discussed): inverse_fisher_cached(ctx, σ, G, field_tag)
            from some_metrics_or_utils import inverse_fisher_cached
            if field == "phi":
                F_inv = inverse_fisher_cached(ctx, sigma_q, generators_tgt, field_tag="phi")
            else:
                F_inv = inverse_fisher_cached(ctx, sigma_p, generators_tgt, field_tag="phi_model")
            setattr(agent_i, fisher_inv_key, F_inv)
        except Exception:
            # if no helper is available, leave as None and let downstream raise if required
            pass

    if alpha > 0:
        grad_self = phi_self_func(
            mu_q=mu_q, sigma_q=sigma_q,
            mu_p=mu_p, sigma_p=sigma_p,
            Phi_tilde_0=agent_i.Phi_tilde_0,
            phi=phi, phi_tilde=phi_tilde,
            generators_q=generators_tgt,
            generators_p=generators_src,
            exp_phi=agent_i._exp_phi,
            exp_phi_tilde=agent_i._exp_phi_model,
            eps=eps,
        )
        grad_self = np.einsum("...ab,...b->...a", F_inv, grad_self)
        grad_self = dexpinv_operator(getattr(agent_i, field), grad_self, generators_tgt)
        setattr(agent_i, grad_key, getattr(agent_i, grad_key) + alpha * grad_self * mask)

    if lambda_ > 0:
        grad_feedback = phi_feedback_func(
            mu_p=mu_p, sigma_p=sigma_p,
            mu_q=mu_q, sigma_q=sigma_q,
            Phi_0=agent_i.Phi_0,
            phi=phi, phi_tilde=phi_tilde,
            generators_q=generators_tgt,
            exp_phi=agent_i._exp_phi,
            exp_phi_tilde=agent_i._exp_phi_model,
            eps=eps,
        )
        grad_feedback = np.einsum("...ab,...b->...a", F_inv, grad_feedback)
        grad_feedback = dexpinv_operator(getattr(agent_i, field), grad_feedback, generators_tgt)
        setattr(agent_i, grad_key, getattr(agent_i, grad_key) + lambda_ * grad_feedback * mask)






#==============================================================================
#
#                    WITH RESPECT TO phi_i TERMS
#                       VALIDATED
#==============================================================================
def grad_kl_wrt_phi_i(
    mu_i, sigma_i,
    mu_j, sigma_j,
    phi_i, phi_j,
    Omega_ij,
    generators,
    exp_phi_i,
    exp_phi_j,
    mu_j_t,
    sigma_j_t_inv,
    eps=1e-8,
    exp_neg_phi_j=None,
    Q_all=None,
):
    """
    Vectorized over Lie index a. Returns (..., d).
    Robustly handles Q_all stacking/broadcasting so that:
        Q_all.shape == (..., a, K, K)
        exp_neg_phi_j.shape == (..., K, K) broadcastable to Q_all's leading dims
    """
    import numpy as _np

    # ---- helpers -------------------------------------------------------------
    def _stack_Q_all_right_before_KK(Q_list_or_array, K_expected=None):
        """
        Ensure Q has shape (..., a, K, K), i.e., Lie axis 'a' is the -3 axis.
        Accepts:
          - list/tuple of length d with arrays shaped (..., K, K)
          - array with 'a' axis anywhere before the trailing K,K
        """
        if isinstance(Q_list_or_array, (list, tuple)):
            # assume each item has shape (..., K, K); insert 'a' right before K,K
            sample = Q_list_or_array[0]
            nd = sample.ndim
            # position for 'a' axis is nd-2 (just before the final two matrix dims)
            Q_arr = _np.stack(Q_list_or_array, axis=nd - 2)
        else:
            Q_arr = _np.asarray(Q_list_or_array)

        # Now move the axis of size d (excluding the last two K,K) to -3 if needed
        if Q_arr.ndim < 3:
            raise ValueError(f"Q_all has too few dims: {Q_arr.shape}")
        K1, K2 = Q_arr.shape[-2], Q_arr.shape[-1]
        if K_expected is not None and (K1 != K_expected or K2 != K_expected):
            raise ValueError(f"Q_all trailing dims {K1}x{K2} != expected {K_expected}x{K_expected}")
        # Find an axis (not in the last two) that equals d = generators.shape[0]
        d = int(generators.shape[0])
        if Q_arr.shape[-3] != d:
            # locate the 'a' axis
            a_axis = None
            for ax in range(Q_arr.ndim - 2):
                if Q_arr.shape[ax] == d:
                    a_axis = ax
                    break
            if a_axis is None:
                raise ValueError(f"Could not locate Lie axis of size d={d} in Q_all shape {Q_arr.shape}")
            if a_axis != Q_arr.ndim - 3:
                Q_arr = _np.moveaxis(Q_arr, a_axis, Q_arr.ndim - 3)
        return Q_arr

    def _broadcast_KK_to_leading(mat, lead_shape, K):
        """
        Ensure 'mat' ends with (K,K) and is broadcastable to 'lead_shape' + (K,K).
        """
        M = _np.asarray(mat)
        if M.ndim < 2 or M.shape[-2:] != (K, K):
            raise ValueError(f"Expected a (...,{K},{K}) matrix; got {M.shape}")
        need_leads = len(lead_shape)
        if M.ndim == 2:
            # add leading singleton axes
            M = M.reshape((1,) * need_leads + (K, K))
        else:
            # if M has some leads, let numpy broadcasting handle it,
            # but sanity-check compatibility
            if M.shape[-2:] != (K, K):
                raise ValueError(f"Matrix trailing dims mismatch {M.shape[-2:]} vs {(K,K)}")
        # broadcast (no copy) to target leading shape if necessary
        if M.shape[:-2] != tuple(lead_shape):
            # try broadcasting by expanding singleton dims
            target = tuple(lead_shape) + (K, K)
            M = _np.broadcast_to(M, target)
        return M
    
    def _broadcast_vec_to_leading(vec, lead_shape, K):
        """
        Ensure 'vec' ends with (K,) and is broadcastable to 'lead_shape' + (K,).
        """
        v = _np.asarray(vec)
        if v.ndim == 1:
            v = v.reshape((1,) * len(lead_shape) + (K,))
        elif v.shape[-1] != K:
            raise ValueError(f"Vector trailing dim mismatch {v.shape[-1]} vs {K}")
        if v.shape[:-1] != tuple(lead_shape):
            v = _np.broadcast_to(v, tuple(lead_shape) + (K,))
        return v

    # ---- inputs & shapes -----------------------------------------------------
    d = int(generators.shape[0])
    sigma_i = sanitize_sigma(sigma_i, eps=eps)
    Omega_T = _np.swapaxes(Omega_ij, -1, -2)

    # Q_all: d Jacobians of exp(phi_i); ensure (..., a, K, K)
    if Q_all is None:
        Q_all = d_exp_phi_exact(phi_i, generators)  # list of length d
    # figure K from sigma_i
    K = int(sigma_i.shape[-1])
    Q = _stack_Q_all_right_before_KK(Q_all, K_expected=K)  # (..., a, K, K)
    # exp(-phi_j): prefer cached; broadcast to Q's leading dims (excluding a,K,K)
    if exp_neg_phi_j is None:
        exp_neg_phi_j = safe_omega_inv(exp_phi_j, eps=eps, debug=False)
    exp_neg_phi_j = _broadcast_KK_to_leading(exp_neg_phi_j, lead_shape=Q.shape[:-3], K=K)

    # push-forward pieces
    delta_mu = mu_i - mu_j_t  # (..., K)

    # ---- terms ---------------------------------------------------------------
    # dΩ/dφ_i^a = Q[a] @ e^{-φ_j}
    # Q: (..., a, K, K), exp_neg_phi_j: (..., K, K) -> (..., a, K, K)
    Q = _np.einsum("...aik,...kj->...aij", Q, exp_neg_phi_j, optimize=True)
    Q_T = _np.swapaxes(Q, -1, -2)  # (..., a, K, K)

    # trace term: -0.5 * [ Tr(Sj_inv Q Σi) + Tr(Q^T Sj_inv Σi) ]
    t1 = _np.einsum("...ij,...ajk,...ki->...a", sigma_j_t_inv, Q, sigma_i, optimize=True)
    t2 = _np.einsum("...aij,...jk,...ki->...a", Q_T,           sigma_j_t_inv, sigma_i, optimize=True)
    trace_term = -0.5 * (t1 + t2)  # (..., a)

    # mean term (use pushed-forward mean):  - (μ_j_t)^T (Sj_inv (Q^T Δμ))
    tmp1 = _np.einsum("...aij,...j->...ai", Q_T, delta_mu, optimize=True)          # Q^T Δμ
    tmp2 = _np.einsum("...ij,...aj->...ai", sigma_j_t_inv, tmp1, optimize=True)    # Sj_inv (...)
    mean_term = -_np.einsum("...i,...ai->...a", mu_j_t, tmp2, optimize=True)


    # Mahalanobis term: 0.5 Δμ^T ( Q^T Sj_inv + Sj_inv Q ) Δμ
    v1 = _np.einsum("...ij,...j->...i", sigma_j_t_inv, delta_mu, optimize=True)   # Sj_inv Δμ
    part1 = _np.einsum("...aij,...j->...ai", Q_T, v1, optimize=True)              # Q^T Sj_inv Δμ
    v2 = _np.einsum("...aij,...j->...ai", Q,  delta_mu, optimize=True)            # Q Δμ
    part2 = _np.einsum("...ij,...aj->...ai", sigma_j_t_inv, v2, optimize=True)    # Sj_inv Q Δμ
    mahal_term = 0.5 * _np.einsum("...i,...ai->...a", delta_mu, part1 + part2, optimize=True)

    grad = trace_term + mean_term + mahal_term  # (..., a)
    return grad





def grad_feedback_phi_direct(
    mu_p, sigma_p,
    mu_q, sigma_q,
    Phi_0,
    phi,                # (..., d)
    phi_tilde,          # (..., d)
    generators_q,       # (d, K_q, K_q)
    exp_phi,            # (..., K_q, K_q)
    exp_phi_tilde,      # (..., K_p, K_p)
    eps=1e-8,
    # NEW optional precomputes:
    Q_all=None,         # (..., d, K_q, K_q) = d_exp_phi_exact(phi, generators_q)
    exp_neg_phi=None    # (..., K_q, K_q) = e^{-φ}
):
    """
    Vectorized over 'a': returns (..., d)
    Φ = e^{φ̃} Φ₀ e^{-φ}, ∂Φ = - Φ · (e^{-φ} (∂ e^{φ}) e^{-φ})
    """
    d, K_q, _ = generators_q.shape
    shape = mu_p.shape[:-1]

    if exp_neg_phi is None:
        exp_neg_phi = safe_omega_inv(exp_phi, eps=eps, debug=False)
    if Q_all is None:
        # stack as (..., d, K_q, K_q)
        Q_list = d_exp_phi_exact(phi, generators_q)
        Q_all = np.stack(Q_list, axis=-3)  # assuming list of d arrays

    # Φ and Φᵀ
    Phi = np.einsum("...ik,...kj,...jl->...il", exp_phi_tilde, Phi_0, exp_neg_phi)
    Phi_T = np.swapaxes(Phi, -1, -2)


    # A, A^{-1}
    A = np.einsum("...ik,...kl,...lj->...ij", Phi, sigma_q, Phi_T)
    A = sanitize_sigma(A, eps=eps)
    A_inv = safe_inv(A, eps=eps)

    # Δμ and v
    Phi_mu_q = np.einsum("...ij,...j->...i", Phi, mu_q)
    delta_mu = mu_p - Phi_mu_q
    v = np.einsum("...ij,...j->...i", A_inv, delta_mu)  # (..., K_p)

    # Q̄_a = e^{-φ} Q_a e^{-φ}
    Q_bar = np.einsum("...ik,...akl,...lj->...aij", exp_neg_phi, Q_all, exp_neg_phi)

    # dΦ_a = - Φ Q̄_a
    dPhi = -np.einsum("...ik,...akj->...aij", Phi, Q_bar)
    dPhi_T = np.swapaxes(dPhi, -1, -2)

    # dA_a
    dA = (
        np.einsum("...aik,...kl,...lj->...aij", dPhi, sigma_q, Phi_T) +
        np.einsum("...ik,...kl,...alj->...aij", Phi,  sigma_q, dPhi_T)
    )

    # Term 1
    dPhi_mu = np.einsum("...aij,...j->...ai", dPhi, mu_q)       # (..., a, K_p)
    term1 = -np.einsum("...ai,...i->...a", dPhi_mu, v)

    # Term 2
    term2 = 0.5 * np.einsum("...ij,...aij->...a", A_inv, dA)

    # M_a = A^{-1} dA_a A^{-1}
    M = np.einsum("...ij,...ajk,...kl->...ail", A_inv, dA, A_inv)

    # Term 3
    term3 = -0.5 * np.einsum("...i,...aij,...j->...a", delta_mu, M, delta_mu)

    # Term 4
    term4 = -0.5 * np.einsum("...aij,...ji->...a", M, sigma_p)

    grad = term1 + term2 + term3 + term4  # (..., d)
    return grad


def grad_feedback_phi_tilde_direct(
    mu_p, sigma_p,
    mu_q, sigma_q,
    Phi_0,
    phi, phi_tilde,
    generators_p, generators_q,
    exp_phi, exp_phi_tilde,
    eps=1e-8,
    # NEW optional precomputes:
    Q_tilde_all=None,       # (..., d, K_p, K_p) = d_exp_phi_tilde_exact(phi_tilde, generators_p)
    exp_neg_phi_tilde=None  # (..., K_p, K_p) = e^{-φ̃}
):
    """
    Vectorized over 'a': returns (..., d)
    Left-trivialize: dΦ_a = L_a Φ,  L_a = (∂e^{φ̃}/∂φ̃^a) e^{-φ̃}.
    """
    d, K_p, _ = generators_p.shape
    shape = mu_p.shape[:-1]

    if exp_neg_phi_tilde is None:
        exp_neg_phi_tilde = safe_omega_inv(exp_phi_tilde, eps=eps, debug=False)
    if Q_tilde_all is None:
        Q_list = d_exp_phi_tilde_exact(phi_tilde, generators_p)
        Q_tilde_all = np.stack(Q_list, axis=-3)

    # Φ
    exp_neg_phi = safe_omega_inv(exp_phi, eps=eps, debug=False)
    Phi   = np.einsum("...ik,...kj,...jl->...il", exp_phi_tilde, Phi_0, exp_neg_phi)
    Phi_T = np.swapaxes(Phi, -1, -2)

  
    A = np.einsum("...ik,...kl,...lj->...ij", Phi, sigma_q, Phi_T)
    A = sanitize_sigma(A, eps=eps)
    A_inv = safe_inv(A, eps=eps)

    Phi_mu_q = np.einsum("...ij,...j->...i", Phi, mu_q)
    delta_mu = mu_p - Phi_mu_q
    v = np.einsum("...ij,...j->...i", A_inv, delta_mu)

    # L_a = Q̃_a e^{-φ̃}
    L = np.einsum("...aik,...kj->...aij", Q_tilde_all, exp_neg_phi_tilde)

    # dΦ_a = L_a Φ
    dPhi = np.einsum("...aik,...kj->...aij", L, Phi)
    dPhi_T = np.swapaxes(dPhi, -1, -2)

    dA = (
        np.einsum("...aik,...kl,...lj->...aij", dPhi, sigma_q, Phi_T) +
        np.einsum("...ik,...kl,...alj->...aij", Phi,  sigma_q, dPhi_T)
    )

    dPhi_mu = np.einsum("...aij,...j->...ai", dPhi, mu_q)
    term1 = -np.einsum("...ai,...i->...a", dPhi_mu, v)

    term2 = 0.5 * np.einsum("...ij,...aij->...a", A_inv, dA)

    M = np.einsum("...ij,...ajk,...kl->...ail", A_inv, dA, A_inv)

    term3 = -0.5 * np.einsum("...i,...aij,...j->...a", delta_mu, M, delta_mu)
    term4 = -0.5 * np.einsum("...aij,...ji->...a", M, sigma_p)

    grad = term1 + term2 + term3 + term4
    return grad



def grad_self_phi_direct(
    mu_q, sigma_q,
    mu_p, sigma_p,
    Phi_tilde_0,
    phi, phi_tilde,
    generators_q, generators_p,
    exp_phi, exp_phi_tilde,
    eps=1e-8,
    # NEW optional precomputes:
    Q_all=None,               # (..., d, K_q, K_q)
    exp_neg_phi_tilde=None    # (..., K_p, K_p)
):
    """
    Vectorized over 'a': returns (..., d)
    Φ̃ = e^{φ} Φ̃₀ e^{-φ̃},  ∂Φ̃_a = (∂e^{φ}/∂φ^a) Φ̃₀ e^{-φ̃}.
    """
    d, K_q, _ = generators_q.shape
    shape = mu_q.shape[:-1]

    if exp_neg_phi_tilde is None:
        exp_neg_phi_tilde = safe_omega_inv(exp_phi_tilde, eps=eps, debug=False)
    if Q_all is None:
        Q_list = d_exp_phi_exact(phi, generators_q)
        Q_all = np.stack(Q_list, axis=-3)

    # Φ̃ and A
    Phi_tilde = np.einsum("...ik,...kj,...jl->...il", exp_phi, Phi_tilde_0, exp_neg_phi_tilde)
    Phi_tilde_T = np.swapaxes(Phi_tilde, -1, -2)


    A = np.einsum("...ik,...kl,...lj->...ij", Phi_tilde, sigma_p, Phi_tilde_T)
    A = sanitize_sigma(A, eps=eps)
    A_inv = safe_inv(A, eps=eps)

    delta_mu = mu_q - np.einsum("...ij,...j->...i", Phi_tilde, mu_p)

    # ∂Φ̃_a = Q_a Φ̃₀ e^{-φ̃}
    dPhi = np.einsum("...aik,...kj,...jl->...ail", Q_all, Phi_tilde_0, exp_neg_phi_tilde)
    dPhi_T = np.swapaxes(dPhi, -1, -2)

    dA = (
        np.einsum("...aik,...kl,...lj->...aij", dPhi, sigma_p, Phi_tilde_T) +
        np.einsum("...ik,...kl,...alj->...aij", Phi_tilde, sigma_p, dPhi_T)
    )

    # Term 1
    dPhi_mu_p = np.einsum("...aij,...j->...ai", dPhi, mu_p)
    term1 = -np.einsum("...ai,...i->...a", dPhi_mu_p, np.einsum("...ij,...j->...i", A_inv, delta_mu))

    # Term 2   (note: your earlier self/feedback sign conventions differ; keeping your current one)
    term2 = 0.5 * np.einsum("...ij,...aij->...a", A_inv, dA)

    # M = A^{-1} dA A^{-1}
    M = np.einsum("...ij,...ajk,...kl->...ail", A_inv, dA, A_inv)

    # Term 3
    term3 = -0.5 * np.einsum("...i,...aij,...j->...a", delta_mu, M, delta_mu)

    # Term 4
    term4 = -0.5 * np.einsum("...aij,...ji->...a", M, sigma_q)

    grad = term1 + term2 + term3 + term4
    return grad


def grad_self_phi_tilde_direct(
    mu_q, sigma_q,
    mu_p, sigma_p,
    Phi_tilde_0,
    phi, phi_tilde,
    generators_q, generators_p,
    exp_phi, exp_phi_tilde,
    eps=1e-8,
    # NEW optional precomputes:
    Q_tilde_all=None,         # (..., d, K_p, K_p)
    exp_neg_phi_tilde=None    # (..., K_p, K_p)
):
    """
    Vectorized over 'a': returns (..., d)
    Right-trivialize on model: R_a = (∂e^{φ̃}/∂φ̃^a) e^{-φ̃},  ∂Φ̃_a = - Φ̃ R_a.
    """
    d, K_p, _ = generators_p.shape
    shape = mu_q.shape[:-1]

    if exp_neg_phi_tilde is None:
        exp_neg_phi_tilde = safe_omega_inv(exp_phi_tilde, eps=eps, debug=False)
    if Q_tilde_all is None:
        Q_list = d_exp_phi_tilde_exact(phi_tilde, generators_p)
        Q_tilde_all = np.stack(Q_list, axis=-3)

    Phi_tilde = np.einsum("...ik,...kj,...jl->...il", exp_phi, Phi_tilde_0, exp_neg_phi_tilde)
    Phi_tilde_T = np.swapaxes(Phi_tilde, -1, -2)

    
    A = np.einsum("...ik,...kl,...lj->...ij", Phi_tilde, sigma_p, Phi_tilde_T)
    A = sanitize_sigma(A, eps=eps)
    A_inv = safe_inv(A, eps=eps)

    mu_t = np.einsum("...ij,...j->...i", Phi_tilde, mu_p)
    delta_mu = mu_q - mu_t

    # R_a = Q̃_a e^{-φ̃}
    R = np.einsum("...aik,...kj->...aij", Q_tilde_all, exp_neg_phi_tilde)

    # dΦ̃_a = - Φ̃ R_a
    dPhi = -np.einsum("...ik,...akj->...aij", Phi_tilde, R)
    dPhi_T = np.swapaxes(dPhi, -1, -2)

    dA = (
        np.einsum("...aik,...kl,...lj->...aij", dPhi, sigma_p, Phi_tilde_T) +
        np.einsum("...ik,...kl,...alj->...aij", Phi_tilde, sigma_p, dPhi_T)
    )

    dPhi_mu_p = np.einsum("...aij,...j->...ai", dPhi, mu_p)
    term1 = -np.einsum("...ai,...i->...a", dPhi_mu_p, np.einsum("...ij,...j->...i", A_inv, delta_mu))

    term2 = 0.5 * np.einsum("...ij,...aij->...a", A_inv, dA)

    M = np.einsum("...ij,...ajk,...kl->...ail", A_inv, dA, A_inv)

    term3 = -0.5 * np.einsum("...i,...aij,...j->...a", delta_mu, M, delta_mu)
    term4 = -0.5 * np.einsum("...aij,...ji->...a", M, sigma_q)

    grad = term1 + term2 + term3 + term4
    return grad


# =========================
# Helpers (cached, lightweight)
# =========================

def _algebra_matrix_from_coeffs(phi_coeffs, generators):
    """
    phi_coeffs: (..., d)
    generators: (d, K, K)
    returns: (..., K, K) matrix in the algebra
    """
    # sum_a phi^a G^a
    # reshape phi to broadcast over K,K
    return np.einsum("...a,aij->...ij", phi_coeffs, generators)


def _gram_inv_cached(agent, key_name, generators, eps=1e-8):
    """
    Cache and return Gram^{-1} for the given generator set under Frobenius inner product.
    key_name: str attribute name on agent (e.g., "_Gram_q_inv" / "_Gram_p_inv")
    """
    G_inv = getattr(agent, key_name, None)
    if G_inv is not None:
        return G_inv
    d = generators.shape[0]
    Gram = np.empty((d, d), dtype=generators.dtype)
    for a in range(d):
        for b in range(d):
            Gram[a, b] = np.tensordot(generators[a], generators[b])
    Gram += eps * np.eye(d, dtype=Gram.dtype)
    G_inv = safe_inv(Gram)
    setattr(agent, key_name, G_inv)
    return G_inv


def _project_mat_to_algebra_coeffs(M, generators, G_inv):
    """
    Project matrix M (..., K, K) to algebra coefficients (..., d)
    by solving coeffs = G_inv @ h, where h_b = <G^b, M>_F.
    """
    d = generators.shape[0]
    # h_b = tr((G^b)^T M)
    h = np.stack([np.tensordot(generators[b], M) for b in range(d)], axis=-1)
    # coeffs = h @ G_inv^T (since last dim is basis index)
    # both ways are fine; using right-multiply for (..., d)
    coeffs = np.einsum("...b,bc->...c", h, G_inv)
    return coeffs


# --- helper: build C once and cache on agent ---
def _build_c_mapping_q2p(Phi_tilde_0, generators_q, generators_p, eps=1e-8):
    """
    Build linear map C (d_p x d_q) so that Ad_{Phi_tilde_0}(G_q^a) ≈ sum_b C_{ba} G_p^b,
    using Frobenius inner-product projection onto p-basis.
    """
    d_q, Kq, _ = generators_q.shape
    d_p, Kp, _ = generators_p.shape
    assert Phi_tilde_0.shape[-2:] == (Kq, Kp), "Phi_tilde_0 must be (K_q, K_p)"

    # Gram matrix of p-basis under Frobenius product
    Gp = np.zeros((d_p, d_p), dtype=generators_p.dtype)
    for b in range(d_p):
        for c in range(d_p):
            Gp[b, c] = np.tensordot(generators_p[b], generators_p[c])
    Gp += eps * np.eye(d_p, dtype=Gp.dtype)
    Gp_inv = safe_inv(Gp)

    # Conjugate each q-generator: H_a = Phi0 G_q^a Phi0^{-1}
    Phi0    = Phi_tilde_0
    Phi0_inv = safe_inv(Phi0, eps=eps)

    C = np.zeros((d_p, d_q), dtype=generators_p.dtype)
    for a in range(d_q):
        H_a = np.einsum("ik,kl,lj->ij", Phi0, generators_q[a], Phi0_inv)
        h = np.array([np.tensordot(generators_p[b], H_a) for b in range(d_p)], dtype=H_a.dtype)
        C[:, a] = Gp_inv @ h
    return C




# =========================
# Regularization (with toggleable φ–φ̃ coupling)
# =========================
def apply_regularization_terms_lie_natural(agent, phi_field, generators, field, params, agents=None, eps=1e-8):
    grad_nat = np.zeros_like(phi_field)

    curv_weight   = params.get("curvature_weight", 0.0)
    fisher_weight = params.get("fisher_geometry_weight", 0.0)
    mass_weight   = params.get("mass_weight", 0.0)
    lam_cpl       = params.get("phi_coupling_weight", 0.0)

    if curv_weight == 0.0 and fisher_weight == 0.0 and mass_weight == 0.0 and lam_cpl == 0.0:
        # fast exit
        return grad_nat

    # per-field overrides...
    if field == "phi":
        curv_weight   = getattr(config, "curvature_weight", curv_weight)
        fisher_weight = getattr(config, "fisher_geometry_weight", fisher_weight)
        mass_weight   = getattr(config, "belief_mass", mass_weight)
        lam_cpl       = getattr(config, "phi_coupling_weight", lam_cpl)
    elif field == "phi_model":
        curv_weight   = getattr(config, "model_curvature_weight", curv_weight)
        fisher_weight = getattr(config, "fisher_model_geometry_weight", fisher_weight)
        mass_weight   = getattr(config, "model_mass", mass_weight)
        lam_cpl       = getattr(config, "phi_coupling_weight", lam_cpl)
    else:
        raise ValueError(f"Invalid field: {field}")

    if curv_weight > 0.0:
        grad_nat += curv_weight * compute_curvature_gradient_analytical(phi_field, generators)

    if fisher_weight > 0.0 and agents is not None:
        grad_nat += fisher_weight * compute_fisher_geometry_gradient(agent, agents, params, field=field)

    if mass_weight > 0.0:
        grad_nat += mass_weight * phi_field

    if lam_cpl > 0.0:
        # one-time build of C (q→p coupling)
        if not hasattr(agent, "_C_q2p"):
            agent._C_q2p = _build_c_mapping_q2p(agent.Phi_tilde_0, agent.generators_q, agent.generators_p, eps=eps)
        C = agent._C_q2p
        phi_q = agent.phi
        phi_p = agent.phi_model
        r = phi_p - np.einsum("ab,...b->...a", C, phi_q, optimize=True)

        if field == "phi":
            grad_eucl = -np.einsum("ab,...b->...a", C.T, r, optimize=True)
            grad_nat += dexpinv_operator(phi_q, grad_eucl, agent.generators_q) * lam_cpl
        else:
            grad_nat += dexpinv_operator(phi_p, r, agent.generators_p) * lam_cpl

    return grad_nat




