# lambda_viz_stable.py
import os, numpy as np
import matplotlib.pyplot as plt

# ---------------- basics ----------------
def _ensure_dir(d):
    os.makedirs(d, exist_ok=True); return d

def _fro_field(L):
    A = np.asarray(L)
    if A.ndim >= 4:
        H, W = A.shape[:2]
        M = A.reshape(H, W, -1).astype(np.float32, copy=False)
        M = np.nan_to_num(M, nan=0.0, posinf=0.0, neginf=0.0)
        return np.linalg.norm(M, axis=-1)
    return None

def _mean_matrix(L):
    A = np.asarray(L)
    if A.ndim == 2:
        return A
    if A.ndim >= 4:
        M = A.reshape(-1, *A.shape[-2:]).astype(np.float64, copy=False)
        M = np.nan_to_num(M, nan=0.0, posinf=0.0, neginf=0.0)
        return M.mean(axis=0)
    return None

def _robust_lims(im, mask=None, lo=2.0, hi=98.0):
    v = im[np.isfinite(im)]
    if mask is not None:
        v = im[(mask.astype(bool)) & np.isfinite(im)]
    if v.size == 0:
        return (None, None)
    lo_v, hi_v = np.percentile(v, lo), np.percentile(v, hi)
    if not np.isfinite(hi_v) or hi_v <= lo_v:
        return (None, None)
    return float(lo_v), float(hi_v)

# ---------------- mask helpers ----------------
def _get_overlap_mask(rtctx, cid, pid, low_level=0, high_level=1):
    kids = (getattr(rtctx, "agents_by_level", {}) or {}).get(low_level, {}) or {}
    pars = (getattr(rtctx, "agents_by_level", {}) or {}).get(high_level, {}) or {}
    c = kids.get(int(cid)); p = pars.get(int(pid))
    if c is None or p is None:
        return None
    cm = np.asarray(getattr(c, "mask"), bool)
    pm = np.asarray(getattr(p, "mask"), bool)
    if cm.shape != pm.shape:
        return None
    return cm & pm

def _baseline_from_background(img, overlap_mask):
    if overlap_mask is None:
        # fall back to global median for stability
        v = img[np.isfinite(img)]
        return float(np.median(v)) if v.size else 0.0
    bg = (~overlap_mask) & np.isfinite(img)
    if np.any(bg):
        return float(np.median(img[bg]))
    # if no background, use overall median
    v = img[np.isfinite(img)]
    return float(np.median(v)) if v.size else 0.0

# ---------------- drawing ----------------
def _save_heat(img, title, path, *, mask=None, normalize="background", draw_contours=True):
    _ensure_dir(os.path.dirname(path))

    # 1) normalize to make p/q comparable
    adj = img.copy()
    if normalize == "background":
        base = _baseline_from_background(adj, mask)
        adj = adj - base
        adj = np.where(np.isfinite(adj), np.maximum(adj, 0.0), 0.0)
    elif normalize == "zscore":
        if mask is not None and mask.any():
            v = adj[mask & np.isfinite(adj)]
        else:
            v = adj[np.isfinite(adj)]
        mu = float(np.mean(v)) if v.size else 0.0
        sd = float(np.std(v)) if v.size else 1.0
        sd = sd if sd > 1e-12 else 1.0
        adj = (adj - mu) / sd
        adj = np.where(np.isfinite(adj), adj, 0.0)
    else:
        adj = np.where(np.isfinite(adj), adj, 0.0)

    # 2) limits over the in-mask region if provided (better contrast)
    vmin, vmax = _robust_lims(adj, mask, lo=2.0, hi=98.0)

    plt.figure(figsize=(5.2, 4.8))
    im = plt.imshow(adj, vmin=vmin, vmax=vmax, interpolation="nearest")
    plt.title(title)
    plt.xticks([]); plt.yticks([])

    if draw_contours and mask is not None and mask.any():
        try:
            # thin white contour around the overlap
            cs = plt.contour(mask.astype(float), levels=[0.5], linewidths=1.2, colors="w")
            for c in cs.collections:
                c.set_alpha(0.8)
        except Exception:
            pass

    plt.colorbar(im, fraction=0.046, pad=0.04)
    plt.tight_layout()
    plt.savefig(path, dpi=150, bbox_inches="tight")
    plt.close()
    return path

def _save_mat(M, title, path):
    _ensure_dir(os.path.dirname(path))
    plt.figure(figsize=(4.8, 4.0))
    plt.imshow(M, interpolation="nearest")
    plt.title(title); plt.xlabel("parent (Kp)"); plt.ylabel("child (Kc)")
    plt.colorbar(fraction=0.046, pad=0.04)
    plt.tight_layout(); plt.savefig(path, dpi=170, bbox_inches="tight"); plt.close()
    return path

# ---------------- link iterators ----------------
def _iter_link_lambdas(rtctx, low_level=0, high_level=1):
    link = getattr(rtctx, "xlinks", {}).get((low_level, high_level))
    if not link:
        return
    ldq = getattr(link, "Lambda_dn_q", {}) or {}
    ldp = getattr(link, "Lambda_dn_p", {}) or {}
    luq = getattr(link, "Lambda_up_q", {}) or {}
    lup = getattr(link, "Lambda_up_p", {}) or {}
    keys = set().union(ldq.keys(), ldp.keys(), luq.keys(), lup.keys())
    for (cid, pid) in sorted(keys):
        yield (cid, pid, "q", "dn", ldq.get((cid, pid)))
        yield (cid, pid, "p", "dn", ldp.get((cid, pid)))
        yield (cid, pid, "q", "up", luq.get((cid, pid)))
        yield (cid, pid, "p", "up", lup.get((cid, pid)))

def _agent_map_fallback(rtctx, low_level=0, high_level=1):
    kids = (getattr(rtctx, "agents_by_level", {}) or {}).get(low_level, {}) or {}
    pars = (getattr(rtctx, "agents_by_level", {}) or {}).get(high_level, {}) or {}
    for cid, c in kids.items():
        for pid, p in pars.items():
            Lq_dn = (getattr(p, "Lambda_from_child_q_map", {}) or {}).get(cid)
            Lp_dn = (getattr(p, "Lambda_from_child_p_map", {}) or {}).get(cid)
            Lq_up = (getattr(c, "Lambda_up_q_map", {}) or {}).get(pid)
            Lp_up = (getattr(c, "Lambda_up_p_map", {}) or {}).get(pid)
            yield (cid, pid, "q", "dn", Lq_dn)
            yield (cid, pid, "p", "dn", Lp_dn)
            yield (cid, pid, "q", "up", Lq_up)
            yield (cid, pid, "p", "up", Lp_up)

# ---------------- public API ----------------
def save_lambda_images_from_ctx(
    runtime_ctx,
    step,
    outdir="artifacts/lambda_viz",
    low_level=0,
    high_level=1,
    also_save_npy=False,
    normalize="background",      # "background" | "zscore" | "none"
    draw_contours=True
):
    """
    Save Frobenius heatmaps and mean matrices with mask-aware normalization.
    Returns {(cid,pid,fiber,dir): {"fro": str|None, "mean": str|None, "npy": str|None}}
    """
    outdir = _ensure_dir(outdir)
    written = {}
    found_any = False

    # Prefer link snapshot
    for cid, pid, fiber, direction, L in _iter_link_lambdas(runtime_ctx, low_level, high_level):
        if L is None:
            continue
        found_any = True
        key = (int(cid), int(pid), fiber, direction)
        L = np.asarray(L)
        tag = f"step_{int(step):04d}/Lambda_{fiber}_{direction}_{cid}-{pid}"
        fro = _fro_field(L)
        meanM = _mean_matrix(L)
        ov = _get_overlap_mask(runtime_ctx, cid, pid, low_level, high_level)

        fro_path = _save_heat(
            fro, f"Λ_{fiber} {direction} Fro (c{cid}↔p{pid})",
            os.path.join(outdir, f"{tag}_fro.png"),
            mask=ov, normalize=normalize, draw_contours=draw_contours
        ) if fro is not None else None

        mean_path = _save_mat(
            meanM, f"Mean Λ_{fiber} {direction} (c{cid}↔p{pid})",
            os.path.join(outdir, f"{tag}_mean.png")
        ) if meanM is not None else None

        npy_path = None
        if also_save_npy:
            npy_path = os.path.join(outdir, f"{tag}.npy")
            np.save(npy_path, L)

        written[key] = {"fro": fro_path, "mean": mean_path, "npy": npy_path}

    # Fallback to per-agent maps if link empty
    if not found_any:
        for cid, pid, fiber, direction, L in _agent_map_fallback(runtime_ctx, low_level, high_level):
            if L is None:
                continue
            key = (int(cid), int(pid), fiber, direction)
            L = np.asarray(L)
            tag = f"step_{int(step):04d}/Lambda_{fiber}_{direction}_{cid}-{pid}"
            fro = _fro_field(L)
            meanM = _mean_matrix(L)
            ov = _get_overlap_mask(runtime_ctx, cid, pid, low_level, high_level)

            fro_path = _save_heat(
                fro, f"Λ_{fiber} {direction} Fro (c{cid}↔p{pid})",
                os.path.join(outdir, f"{tag}_fro.png"),
                mask=ov, normalize=normalize, draw_contours=draw_contours
            ) if fro is not None else None

            mean_path = _save_mat(
                meanM, f"Mean Λ_{fiber} {direction} (c{cid}↔p{pid})",
                os.path.join(outdir, f"{tag}_mean.png")
            ) if meanM is not None else None

            npy_path = None
            if also_save_npy:
                npy_path = os.path.join(outdir, f"{tag}.npy")
                np.save(npy_path, L)

            written[key] = {"fro": fro_path, "mean": mean_path, "npy": npy_path}

    return written
