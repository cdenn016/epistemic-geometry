# -*- coding: utf-8 -*-
"""
Created on Mon Aug 11 10:07:56 2025

@author: chris and christine
"""
import numpy as np
from numerical_utils import sanitize_sigma, safe_inv, safe_logdet
from typing import Optional, Tuple
from omega import exp_lie_algebra_irrep



def kl_gaussians(mu1, S1, mu2, S2, eps=1e-6):
    """KL(N(μ1,Σ1) || N(μ2,Σ2)) — batch-safe, no fragile squeezes."""
    S1 = sanitize_sigma(S1, eps=eps)
    S2 = sanitize_sigma(S2, eps=eps)
    K = S1.shape[-1]
    S2_inv = safe_inv(S2, eps=eps)
    dmu = (mu2 - mu1)                                       # (..., K)
    term_trace = np.einsum('...ij,...ji->...', S2_inv, S1)  # tr(S2^{-1} Σ1)
    term_quad  = np.einsum('...i,...ij,...j->...', dmu, S2_inv, dmu)  # (μ2-μ1)^T S2^{-1} (μ2-μ1)
    s1, logdet1 = np.linalg.slogdet(S1)
    s2, logdet2 = np.linalg.slogdet(S2)
    logdet_ratio = logdet2 - logdet1
    return 0.5 * (term_trace + term_quad - K + logdet_ratio)





def _overlap_pairs(children, H, W, *, tau=0.10, min_pair_px=8):
    """
    Return list of (i,j, overlap_bool_mask) for child pairs whose supports overlap.
    Uses (mask > tau) as support for overlap detection.
    """
    Ms_bool = [(np.asarray(c.mask, np.float32) > float(tau)) for c in children]
    pairs = []
    n = len(children)
    for i in range(n):
        mi = Ms_bool[i]
        if not mi.any(): continue
        for j in range(i+1, n):
            ov = (mi & Ms_bool[j])
            if int(ov.sum()) >= int(min_pair_px):
                pairs.append((i, j, ov))
    return pairs




def curvature_boltzmann_from_children(children, H, W, *, gamma=0.0, fiber="q", curvature_map=None):
    """
    Build a curvature Boltzmann factor BF(x) = exp(-gamma * F(x)).
    If curvature_map is provided (H×W), use it directly.
    Else compute F(x) as mask-weighted Frobenius norm of F_xy from omega.compute_field_strength.
    Returns: BF ∈ ℝ^{H×W} (float32) or None if gamma<=0 or computation unavailable.
    """
    if float(gamma) <= 0.0:
        return None

    if curvature_map is not None:
        F = np.asarray(curvature_map, np.float32)
        if F.shape == (H, W):
            return np.exp(-float(gamma) * np.clip(F, 0.0, np.finfo(np.float32).max)).astype(np.float32)

    try:
        from omega import compute_field_strength
    except Exception:
        return None  # fail-open

    num = np.zeros((H, W), np.float32)
    den = np.zeros((H, W), np.float32)
    phi_name = "phi" if str(fiber)=="q" else "phi_model"
    gen_name = "generators_q" if str(fiber)=="q" else "generators_p"

    for c in children:
        m = np.asarray(getattr(c, "mask", 0.0), np.float32)
        if m.shape[:2] != (H, W) or float(m.max()) <= 0.0:
            continue
        phi = getattr(c, phi_name, None)
        G   = getattr(c, gen_name, None)
        if phi is None or G is None:
            continue
        phi = np.asarray(phi, np.float32)
        Fdict = compute_field_strength(phi, np.asarray(G, np.float32))
        Fxy = np.asarray(Fdict.get("xy", 0.0), np.float32)  # (H,W,K,K)
        if Fxy.shape[:2] != (H, W):
            continue
        Fx = np.sqrt(np.clip(np.sum(Fxy * Fxy, axis=(-2, -1)), 0.0, np.finfo(np.float32).max)).astype(np.float32)
        num += (m * Fx)
        den += np.maximum(m, 0.0)

    F = np.zeros((H, W), np.float32)
    sel = den > 1e-6
    F[sel] = (num[sel] / np.maximum(den[sel], 1e-6)).astype(np.float32)
    return np.exp(-float(gamma) * np.clip(F, 0.0, np.finfo(np.float32).max)).astype(np.float32)





import config

from omega import omega_field_cached  # central-cache Ω wrapper

def directed_kl_weight_after_transport(
    Ai, Aj,
    mu_i, S_i, mu_j, S_j,
    *, fiber, H, W, K, ov, tau,
    assume_diag_is_stddev: bool = True,
    debug: bool = False,
    use_cached_omega: bool = True,
    store_omega: Optional[bool] = None,
    ctx: Optional[object] = None,   # NEW: CacheHub entry point
):
    """
    w(x) = exp(- KL( N_i || T_{j->i}(N_j) ) / tau ) on overlap 'ov'.
    Transport is Ω_ij = exp(φ_i) · exp(−φ_j) on the chosen fiber ('q' or 'p').

    Cache policy:
      • Ω computed once on full grid via omega_field_cached(ctx, ...) and sliced to overlap.
      • omega_field_cached internally uses ctx.cache.ns('omega') and exp-grid caches.

    Args:
      Ai, Aj : agent objects (must expose phi / phi_model and generators_q / generators_p)
      mu_*, S_* : full fields (H,W,K) and (H,W,K,K) or (H,W,K) diag (stddev if assume_diag_is_stddev)
      ov : boolean overlap mask (H,W)
    """
    if not np.any(ov):
        return np.zeros((H, W), np.float32)

    # --- config + generators -------------------------------------------------
    if store_omega is None:
        store_omega = bool(getattr(config, "cache_omega_fields", False))
    group_name = getattr(config, "group_name", "so3")

    gens = getattr(Ai, "generators_q" if fiber == "q" else "generators_p", None)
    if gens is None:
        from get_generators import get_generators  # falls back by K
        gens = get_generators(group_name, int(K))

    # --- index overlap once --------------------------------------------------
    iy, ix = np.nonzero(ov)

    # Slice means/covs on overlap (accept diagonal Σ as stddev if requested)
    mui = np.asarray(mu_i, np.float32)[iy, ix]            # (M, K)
    muj = np.asarray(mu_j, np.float32)[iy, ix]            # (M, K)

    Si  = np.asarray(S_i,  np.float32)[iy, ix]            # (M, K,K) or (M,K)
    Sj  = np.asarray(S_j,  np.float32)[iy, ix]

    if Si.ndim == 2:  # diagonal
        diag = Si if not assume_diag_is_stddev else Si * Si
        Si = np.einsum("mk,ij->mij", diag, np.eye(K, dtype=np.float32), optimize=True)
    if Sj.ndim == 2:
        diag = Sj if not assume_diag_is_stddev else Sj * Sj
        Sj = np.einsum("mk,ij->mij", diag, np.eye(K, dtype=np.float32), optimize=True)

    # Sanitize (SPD) before transport
    Si = sanitize_sigma(Si,  eps=getattr(config, "log_eps", 1e-8))
    Sj = sanitize_sigma(Sj,  eps=getattr(config, "log_eps", 1e-8))

    # --- Ω_ij: compute once on full grid via CacheHub, then slice ------------
    if fiber == "q":
        phi_i_full = np.asarray(Ai.phi,       np.float32)
        phi_j_full = np.asarray(Aj.phi,       np.float32)
    else:
        phi_i_full = np.asarray(Ai.phi_model, np.float32)
        phi_j_full = np.asarray(Aj.phi_model, np.float32)

    # Full-field Ω cache (ctx-aware); invert_j=False gives E_i @ E_{-j}
    Omega_full = omega_field_cached(ctx, phi_i_full, phi_j_full, gens, group=group_name, invert_j=False)
    Omega_ij   = Omega_full[iy, ix]  # (M, K, K)

    if debug:
        RtR = np.einsum("mab,mac->mbc", Omega_ij, Omega_ij, optimize=True)
        I   = np.broadcast_to(np.eye(K, dtype=np.float32), RtR.shape)
        if not np.allclose(RtR, I, atol=1e-4):
            print(f"[DKL] non-orthogonal Ω on fiber='{fiber}' (max dev {np.abs(RtR-I).max():.2e})")

    # --- transport neighbor j → i on the overlap -----------------------------
    muj_t = np.einsum("mab,mb->ma", Omega_ij, muj, optimize=True)
    OmT   = np.swapaxes(Omega_ij, -1, -2)
    Sj_t  = np.einsum("mab,mbc,mdc->mad", Omega_ij, Sj, OmT, optimize=True)

    Sj_t  = sanitize_sigma(Sj_t, eps=getattr(config, "log_eps", 1e-8))

    # --- per-pixel KL and weights --------------------------------------------
    d = kl_gaussians(mui, Si, muj_t, Sj_t, eps=getattr(config, "log_eps", 1e-8)).astype(np.float32)  # (M,)
    d = np.clip(np.nan_to_num(d, nan=0.0, posinf=1e6, neginf=0.0), 0.0, 1e6)

    invT = 1.0 / max(1e-8, float(tau))
    wvec = np.exp(-d * invT).astype(np.float32)

    w = np.zeros((H, W), np.float32)
    w[iy, ix] = wvec
    return w





def apply_evidence_modulators(w, Mi, Mj, ov, *, A=None, agree_power=1.0, BF=None):
    """
    Combine per-pair alignment weight with spatial terms:
      wij = Mi * Mj * w * 1_ov * (BF if provided) * (A^agree_power if provided)
    """
    wij = (Mi * Mj) * w
    wij *= ov.astype(np.float32)
    if BF is not None:
        wij *= BF
    if (A is not None) and (float(agree_power) != 0.0):
        wij *= (np.asarray(A, np.float32) ** float(agree_power))
    return wij.astype(np.float32, copy=False)




