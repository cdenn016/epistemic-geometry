# -*- coding: utf-8 -*-
"""
Created on Tue Aug 12 18:56:28 2025

@author: chris and christine
"""

from __future__ import annotations
import numpy as np
import config

from numerical_utils import safe_inv
from omega import exp_lie_algebra_irrep  
from omega import safe_bch_exact
from preprocess_utils import build_all_lambda_caches, preprocess_all_agents
from bundle_morphism_utils import compute_direct_morphisms


# --- Periodic RG coarse-graining for ALL parents (outside spawn) ------------
def _periodic_parent_coarsegrain(ctx, children, Gq, Gp, params):
    """
    Run canonical coarse-graining for every existing parent, on a fixed period.
    - Preprocesses ONLY children (parents may be newborns with uninitialized fields).
    - (Optionally) builds Λ_up caches from children; parents are ensured lazily in CG.
    - Calls coarsegrain_parent_from_children(P, children, ...) for each parent.
    """
    
    # coarsegrain_parent_from_children is expected to be in this module; if not, import it:
    # from bundle_coarsegrain_init import coarsegrain_parent_from_children

    parents = [p for p in (getattr(ctx, "parents_by_region", {}) or {}).values() if p is not None]
    if not parents:
        return

    # schedule
    step_now = int(getattr(ctx, "global_step", 0))
    period = int(getattr(config, "parent_cg_period", params.get("parent_cg_period", 50)))
    if period <= 0 or (step_now % period) != 0:
        return

    cg_eps = float(getattr(config, "cg_eps", 1e-6))
    cg_tau = float(getattr(config, "parent_cover_support_eps", 0.30))

    # 1) preprocess only children (they always have valid fields)
    child_only = [c for c in (children or []) if c is not None]
    if child_only:
        preprocess_all_agents(child_only, params, G_q=Gq, G_p=Gp)
        # 2) build Λ caches from children only (parents' views are attached lazily in CG)
        try:
            build_all_lambda_caches(child_only)
        except Exception as e:
            print(f"[CG] lambda-cache (children-only) build warning: {e}")

    # 3) now coarse-grain per-parent; this function calls _ensure_parent_fields(...)
    for P in parents:
        try:
            # Pass generators so CG never guesses the irrep (Kq×Kq, Kp×Kp)
            coarsegrain_parent_from_children(
                P, children,
                eps=cg_eps,
                mask_tau=cg_tau,
                G_q=Gq,
                G_p=Gp,
            )
        except Exception as e:
            pid = getattr(P, 'id', '?')
            print(f"[CG] periodic coarsegrain failed for parent {pid}: {e}")

    # bump cache version so downstream can refresh Ω/Λ next step
    if hasattr(ctx, "cache_version"):
        ctx.cache_version = int(getattr(ctx, "cache_version", 0)) + 1





# =========================
# main coarsegrainer
# =========================
import numpy as np, time
import config

def coarsegrain_parent_from_children(
    P, children, *, eps=1e-6, mask_tau=None, G_q=None, G_p=None, ctx=None
):
    """
    Fast RG coarse-grain (exact math) — uses Λ_up maps and sparse tiles.
    CacheHub:
      - ns('misc') caches: parent core mask, per-(parent,child) effective mask,
        and flattened views (mu/Σ/Λ) to cut repeated reshape/index work.
    Timings recorded into P._last_cg_timings and also returned.
    Keys:
      parent_cg_total, parent_cg_setup, parent_cg_accum, parent_cg_finalize,
      parent_cg_karcher, parent_cg_morph_init, parent_cg_children, parent_cg_tiles
    """
    _t = {}
    def _tick(name, t0):
        _t[name] = _t.get(name, 0.0) + (time.perf_counter() - t0)
        return time.perf_counter()

    hub = getattr(ctx, "cache", None) if ctx is not None else None
    ns_misc = (hub.ns("misc") if hub is not None else {})

    t_all0 = time.perf_counter()
    t0 = t_all0

    # --- sizes, support, defaults ---
    H, W = P.mask.shape[:2]
    Kq = int(P.mu_q_field.shape[-1]); Kp = int(P.mu_p_field.shape[-1])

    # parent "core" (cache per parent id + current peak)
    pid = int(getattr(P, "id", -1))
    core_key = ("cg_core", pid, float(getattr(config, "parent_growth_core_tau", 0.20)),
                float(P.mask.max() if P.mask.size else 0.0), H, W)
    core = ns_misc.get(core_key)
    if core is None:
        core = (np.asarray(P.mask, np.float32) > max(
            float(getattr(config, "parent_growth_core_tau", 0.20)),
            0.5 * float(np.max(P.mask) if P.mask.size else 0.0)
        ))
        if hub is not None:
            ns_misc[core_key] = core

    if not np.any(core):
        _tick("parent_cg_total", t_all0)
        P._last_cg_timings = _t
        return _t

    tau = float(mask_tau if mask_tau is not None else getattr(config, "support_cutoff_eps", 1e-4))

    # contributing children (+weights)
    wmap = getattr(P, "child_weights", {}) or {}
    pairs = [(c, float(wmap.get(int(getattr(c, "id", -1)), 0.0))) for c in (children or []) if c is not None]
    pairs = [(c, w) for (c, w) in pairs if w > 0.0]
    if not pairs:
        _tick("parent_cg_total", t_all0)
        P._last_cg_timings = _t
        return _t

    # --- accumulators (q/p) ---
    Wsum_q  = np.zeros((H, W), np.float32)
    mu_acc  = np.zeros((H, W, Kq), np.float32)
    Sig_acc = np.zeros((H, W, Kq, Kq), np.float32)

    Wsum_p    = np.zeros((H, W), np.float32)
    mu_acc_p  = np.zeros((H, W, Kp), np.float32)
    Sig_acc_p = np.zeros((H, W, Kp, Kp), np.float32)

    # lists for Karcher
    phi_list_q, w_list_q = [], []
    phi_list_p, w_list_p = [], []

    # --- helpers ---
    def _indices(mask_bool):
        return np.flatnonzero(mask_bool.reshape(-1))

    def _tile_slices(idx, tile=65536):
        for s in range(0, idx.size, tile):
            yield idx[s:s+tile]

    TILE = int(getattr(config, "cg_tile_pixels", 32768))

    t0 = _tick("parent_cg_setup", t0)

    # --- loop over children (sparse & tiled) ---
    n_children_used = 0
    n_tiles = 0

    for c, w in pairs:
        child_t0 = time.perf_counter()
        cid = int(getattr(c, "id", -1))

        # effective mask eff = core & (child.mask > tau)  (cache per (P,c,tau))
        eff_key = ("cg_eff", pid, cid, float(tau), H, W)
        eff = ns_misc.get(eff_key)
        if eff is None:
            c_mask = (np.asarray(c.mask, np.float32) > tau)
            eff = (core & c_mask)
            if hub is not None:
                ns_misc[eff_key] = eff

        if not np.any(eff):
            _tick("parent_cg_children", child_t0)
            continue

        # Λ_up maps (exact transport already built in preprocess)
        Lq = getattr(c, "Lambda_up_q_map", {}).get(pid, None)  # (H,W,Kq,Kq)
        Lp = getattr(c, "Lambda_up_p_map", {}).get(pid, None)  # (H,W,Kp,Kp)
        if (Kq > 0 and Lq is None) or (Kp > 0 and Lp is None):
            _tick("parent_cg_children", child_t0)
            continue

        # cache flattened views per (P,c)
        flat_key = ("cg_flat", pid, cid, Kq, Kp, H, W)
        cached = ns_misc.get(flat_key)
        if cached is None:
            mu_q_f = c.mu_q_field.reshape(-1, Kq) if Kq else None
            sg_q_f = c.sigma_q_field.reshape(-1, Kq, Kq) if Kq else None
            mu_p_f = c.mu_p_field.reshape(-1, Kp) if Kp else None
            sg_p_f = c.sigma_p_field.reshape(-1, Kp, Kp) if Kp else None
            Lq_f   = Lq.reshape(-1, Kq, Kq) if Kq else None
            Lp_f   = Lp.reshape(-1, Kp, Kp) if Kp else None
            cached = (mu_q_f, sg_q_f, mu_p_f, sg_p_f, Lq_f, Lp_f)
            if hub is not None:
                ns_misc[flat_key] = cached
        else:
            mu_q_f, sg_q_f, mu_p_f, sg_p_f, Lq_f, Lp_f = cached

        w_sp = (w * eff.astype(np.float32)).reshape(-1)
        idx = _indices(eff)
        if idx.size == 0:
            _tick("parent_cg_children", child_t0)
            continue

        for ids in _tile_slices(idx, tile=TILE):
            tile_t0 = time.perf_counter()
            n_tiles += 1

            wv = w_sp[ids][:, None]          # (T,1)
            if Kq:
                L = Lq_f[ids]                # (T,Kq,Kq)
                mu = mu_q_f[ids]             # (T,Kq)
                sg = sg_q_f[ids]             # (T,Kq,Kq)

                muT = np.einsum("tij,tj->ti", L, mu, optimize=True)
                ST  = np.einsum("tij,tjk,tlk->til", L, sg, L, optimize=True)

                mu_acc.reshape(-1, Kq)[ids]       += (wv * muT).astype(np.float32, copy=False)
                Sig_acc.reshape(-1, Kq, Kq)[ids]  += (wv[:, None] * ST).astype(np.float32, copy=False)
                Wsum_q.reshape(-1)[ids]           += w_sp[ids]

            if Kp:
                L = Lp_f[ids]                # (T,Kp,Kp)
                mu = mu_p_f[ids]             # (T,Kp)
                sg = sg_p_f[ids]             # (T,Kp,Kp)

                muT = np.einsum("tij,tj->ti", L, mu, optimize=True)
                ST  = np.einsum("tij,tjk,tlk->til", L, sg, L, optimize=True)

                mu_acc_p.reshape(-1, Kp)[ids]     += (wv * muT).astype(np.float32, copy=False)
                Sig_acc_p.reshape(-1, Kp, Kp)[ids] += (wv[:, None] * ST).astype(np.float32, copy=False)
                Wsum_p.reshape(-1)[ids]           += w_sp[ids]

            _tick("parent_cg_tiles", tile_t0)

        # collect φ lists only where there is contribution
        if getattr(c, "phi", None) is not None and Kq:
            phi_list_q.append(np.asarray(c.phi, np.float64))
            w_list_q.append(eff.astype(np.float32)[..., None])
        if getattr(c, "phi_model", None) is not None and Kp:
            phi_list_p.append(np.asarray(c.phi_model, np.float64))
            w_list_p.append(eff.astype(np.float32)[..., None])

        n_children_used += 1
        _tick("parent_cg_children", child_t0)

    _t["parent_cg_children_used"] = n_children_used
    _t["parent_cg_tiles_count"] = n_tiles
    _t["parent_cg_accum"] = _t.get("parent_cg_tiles", 0.0)

    # --- finalize q/p fibers ---
    t0 = time.perf_counter()
    valid_q = (Wsum_q > 0)
    if np.any(valid_q) and Kq:
        den = np.maximum(Wsum_q[..., None, None], 1e-12).astype(np.float64)
        muP = np.zeros_like(P.mu_q_field, dtype=np.float64)
        Sig = (Sig_acc.astype(np.float64) / den)
        Sig = 0.5 * (Sig + np.swapaxes(Sig, -1, -2)) + eps * np.eye(Kq, dtype=np.float64)
        muP[valid_q] = (mu_acc.astype(np.float64)[valid_q] / Wsum_q[valid_q, None])
        P.mu_q_field[valid_q]    = muP[valid_q].astype(np.float32)
        P.sigma_q_field[valid_q] = Sig[valid_q].astype(np.float32)

    valid_p = (Wsum_p > 0)
    if np.any(valid_p) and Kp:
        den = np.maximum(Wsum_p[..., None, None], 1e-12).astype(np.float64)
        muP = np.zeros_like(P.mu_p_field, dtype=np.float64)
        Sig = (Sig_acc_p.astype(np.float64) / den)
        Sig = 0.5 * (Sig + np.swapaxes(Sig, -1, -2)) + eps * np.eye(Kp, dtype=np.float64)
        muP[valid_p] = (mu_acc_p.astype(np.float64)[valid_p] / Wsum_p[valid_p, None])
        P.mu_p_field[valid_p]    = muP[valid_p].astype(np.float32)
        P.sigma_p_field[valid_p] = Sig[valid_p].astype(np.float32)
    _tick("parent_cg_finalize", t0)

    # --- Karcher means (φ/φ̃) on weighted support only ---
    t0 = time.perf_counter()
    def _karcher(phi_list, w_list, G):
        if not phi_list:
            return None
        # If your CGH_karcher_mean_phi_irrep supports ctx, thread it here.
        return CGH_karcher_mean_phi_irrep(
            phi_list, w_list, H, W, G,
            iters=int(getattr(config, "cg_phi_iters", 6)),
            eta=float(getattr(config, "cg_phi_eta", 0.5)),
            tol=float(getattr(config, "cg_phi_tol", 1e-7)),
            step_clip=float(getattr(config, "cg_phi_step_clip", 1.5)),
            abs_clip=float(getattr(config, "cg_phi_abs_clip", 4.0)),
        )

    if Kq and phi_list_q:
        phi_mean_q = _karcher(phi_list_q, w_list_q, getattr(P, "generators_q", G_q))
        if phi_mean_q is not None:
            P.phi = phi_mean_q.astype(np.float32)

    if Kp and phi_list_p:
        phi_mean_p = _karcher(phi_list_p, w_list_p, getattr(P, "generators_p", G_p))
        if phi_mean_p is not None:
            P.phi_model = phi_mean_p.astype(np.float32)
    _tick("parent_cg_karcher", t0)

    # ensure morphisms exist once for newborns
    t0 = time.perf_counter()
    try:
        from bundle_morphism_utils import have_parent_morphisms, init_parent_morphisms
        if not have_parent_morphisms(P):
            init_parent_morphisms(P, getattr(P, "generators_q", G_q), getattr(P, "generators_p", G_p), ctx=ctx)
    except Exception:
        pass
    _tick("parent_cg_morph_init", t0)

    # remember generators on the parent for downstream φ work
    if G_q is not None: P.generators_q = G_q
    if G_p is not None: P.generators_p = G_p

    _tick("parent_cg_total", t_all0)
    P._last_cg_timings = _t
    return _t







from omega import exp_grid_cached


def CGH_build_morphisms(P, Gq=None, Gp=None, *, ctx=None):
    """
    Ensure P has bundle morphisms Φ: q→p and Φ̃: p→q set.
    Uses CacheHub-backed exponentials and compute_direct_morphisms(...).

    Φ       = exp(φ̃) · Φ₀ · exp(φ)^T
    Φ̃      = exp(φ)  · Φ̃₀ · exp(φ̃)^T
    """
    # --- dims / generators ---------------------------------------------------
    H, W = P.mu_q_field.shape[:2]
    Kq = int(np.asarray(P.mu_q_field).shape[-1])
    Kp = int(np.asarray(P.mu_p_field).shape[-1])

    if Gq is None:
        Gq = getattr(P, "generators_q", None)
    if Gp is None:
        Gp = getattr(P, "generators_p", None)

    # Fallback: build generators by size if missing
    if Gq is None or Gp is None:
        from get_generators import get_generators
        if Gq is None:
            Gq, _ = get_generators(getattr(config, "group_name", "so3"), Kq, return_meta=True)
        if Gp is None:
            Gp, _ = get_generators(getattr(config, "group_name", "so3"), Kp, return_meta=True)

    # --- bases: try parent attrs → config → rectangular identity -------------
    Phi0 = getattr(P, "bundle_morphism_q_to_p_base", None)
    if Phi0 is None:
        Phi0 = getattr(P, "Phi0_q_to_p", None)
    if Phi0 is None:
        Phi0 = getattr(config, "Phi0_q_to_p", None)
    if Phi0 is None:
        Phi0 = CGH_rect_identity(Kp, Kq, dtype=np.float32)

    PhiT0 = getattr(P, "bundle_morphism_p_to_q_base", None)
    if PhiT0 is None:
        PhiT0 = getattr(P, "Phi0_p_to_q", None)
    if PhiT0 is None:
        PhiT0 = getattr(config, "Phi0_p_to_q", None)
    if PhiT0 is None:
        PhiT0 = CGH_rect_identity(Kq, Kp, dtype=np.float32)

    # --- exp(φ) / exp(φ̃) via CacheHub (also warms hub.ns('exp')) -----------
    # we keep these around on P for compatibility with any downstream callers
    Eq = exp_grid_cached(ctx, np.asarray(P.phi,       np.float32), Gq, group=getattr(config, "group_name", "so3"), sign=+1)
    Ep = exp_grid_cached(ctx, np.asarray(P.phi_model, np.float32), Gp, group=getattr(config, "group_name", "so3"), sign=+1)
    P._exp_phi = Eq.astype(np.float32, copy=False)
    P._exp_phi_model = Ep.astype(np.float32, copy=False)

    # --- build Φ / Φ̃ using the helper (handles broadcasting/base shapes) ---
    Phi_field, PhiT_field = compute_direct_morphisms(
        P.phi, P.phi_model, Gq, Gp, Phi0, PhiT0, ctx=ctx, group=getattr(config, "group_name", "so3")
    )

    P.bundle_morphism_q_to_p = Phi_field.astype(np.float32, copy=False)
    P.bundle_morphism_p_to_q = PhiT_field.astype(np.float32, copy=False)



#==============================================================================
#
#
#
#===============================================================================



# =========================
# coarsegrain helpers (CGH)
# =========================
# --- add near the other CGH helpers ---

def CGH_rect_identity(K_to: int, K_from: int, dtype=np.float32):
    """
    Rectangular identity-like linear map of shape (K_to, K_from):
    maps the first r = min(K_to, K_from) axes; zeros elsewhere.
    """
    r = min(K_to, K_from)
    M = np.zeros((K_to, K_from), dtype=dtype)
    M[:r, :r] = 1.0
    return M




# ---- generator plumbing ----
def CGH_need_generators(P, which: str, K: int, hint):
    """Return (3,K,K) generators for 'q' or 'p' fiber, preferring hint or cached on parent."""
    if hint is not None:
        return hint
    cached = getattr(P, "_G_q" if which == "q" else "_G_p", None)
    if cached is not None:
        return cached
    try:
        from get_generators import get_generators
        return get_generators(getattr(config, "group_name", "SO(3)"), K)
    except Exception as e:
        raise RuntimeError(f"Missing generators for {which}-fiber (K={K}). Pass G_{which}.") from e

# ---- small linear-algebra helpers ----
def CGH_Igrid(H, W, K):
    I = np.eye(K, dtype=np.float64)
    return np.broadcast_to(I, (H, W, K, K)).copy()

def CGH_rot_from_phi(phi_field, H, W, G):
    K = G.shape[-1]
    if phi_field is None:
        return CGH_Igrid(H, W, K)
    phi = np.asarray(phi_field, np.float64).reshape(H * W, 3)
    return exp_lie_algebra_irrep(phi, G).reshape(H, W, K, K)

def CGH_gram(G):
    # M_ab = Tr(G_a^T G_b)
    return np.array([[np.einsum("ij,ij->", G[a].T, G[b]) for b in range(3)] for a in range(3)],
                    dtype=np.float64)

def CGH_as_mat(phi_hw3, G):
    # Φ(y,x) = Σ_a φ^a(y,x) G_a
    return np.einsum("...a,aij->...ij", phi_hw3, G, optimize=True)

def CGH_coeffs_from_mat(X_hwKK, G, Minv=None):
    if Minv is None:
        Minv = safe_inv(CGH_gram(G).astype(np.float64))
    b = np.stack([np.einsum("...ij,ij->...", X_hwKK, G[a].T, optimize=True) for a in range(3)], axis=-1)
    return np.einsum("ab,...b->...a", Minv, b, optimize=True)

# ---- Karcher mean in arbitrary irrep, with trust-region ----
def CGH_karcher_mean_phi_irrep(phi_list, w_list, H, W, G,
                               *, iters=6,
                               eta=None,          # step size in algebra
                               tol=1e-7,
                               step_clip=None,    # per-iteration Δ clamp (L2 in R^3)
                               abs_clip=None):    # clamp ||φ|| after update
    """
    Computes the Karcher (Frechet) mean on the group by iterating in the algebra
    using BCH in the supplied irrep. Stabilized with step/absolute trust regions.
    """
    assert len(phi_list) == len(w_list) and len(phi_list) >= 1
    N = H * W
    PHIS = [np.asarray(p, np.float64).reshape(N, 3) for p in phi_list]
    WTS  = [np.asarray(w, np.float64).reshape(N, 1) for w in w_list]
    Wsum = np.maximum(np.sum(WTS, axis=0), 1e-12)  # (N,1)

    # defaults from config, with safe fallbacks
    if eta is None:
        eta = float(getattr(config, "cg_phi_eta", 0.5))
    if step_clip is None:
        step_clip = float(getattr(config, "cg_phi_step_clip", 1.5))
    if abs_clip is None:
        abs_clip = float(getattr(config, "cg_phi_abs_clip", 4.0))

    # init: weighted Euclidean mean (good in small-angle regime)
    phi = (np.sum([w * p for p, w in zip(PHIS, WTS)], axis=0) / Wsum).reshape(N, 3)
    K   = G.shape[-1]
    Minv = safe_inv(CGH_gram(G).astype(np.float64))

    for _ in range(int(iters)):
        Phi_mat = CGH_as_mat(phi.reshape(N, 3), G).reshape(N, K, K)

        # accumulate Δ
        Delta = np.zeros((N, 3), np.float64)
        for p, w in zip(PHIS, WTS):
            Phi_i = CGH_as_mat(p, G).reshape(N, K, K)
            Di = np.stack([safe_bch_exact(-Phi_mat[i], Phi_i[i]) for i in range(N)], axis=0)
            delta_i = CGH_coeffs_from_mat(Di, G, Minv=Minv)  # (N,3)
            Delta += w * delta_i
        Delta /= Wsum  # weighted mean increment

        # step trust-region
        nrm = np.linalg.norm(Delta, axis=-1, keepdims=True)
        scl = np.minimum(1.0, step_clip / np.maximum(nrm, 1e-12))
        Delta = Delta * scl

        # convergence
        if np.all(nrm < tol):
            break

        # update via BCH on the group
        D_mat   = CGH_as_mat(eta * Delta, G).reshape(N, K, K)
        Phi_new = np.stack([safe_bch_exact(Phi_mat[i], D_mat[i]) for i in range(N)], axis=0)
        phi     = CGH_coeffs_from_mat(Phi_new, G, Minv=Minv)

        # absolute trust-region
        nrm_phi = np.linalg.norm(phi, axis=-1, keepdims=True)
        scl_abs = np.minimum(1.0, abs_clip / np.maximum(nrm_phi, 1e-12))
        phi     = phi * scl_abs

    return phi.reshape(H, W, 3)






def _infer_hwk_from_children(children, which="q"):
    """
    Find (H,W,K) from the first child that has the requested bundle.
    which: "q" -> (mu_q_field), "p" -> (mu_p_field)
    """
    for c in children:
        mu = getattr(c, "mu_q_field" if which=="q" else "mu_p_field", None)
        if mu is not None:
            mu = np.asarray(mu)
            if mu.ndim >= 3:
                H, W, K = mu.shape[:3]
                return int(H), int(W), int(K)
    return None



def _ensure_parent_fields(P, children, *, eps=1e-6):
    dims_q = _infer_hwk_from_children(children, "q")
    dims_p = _infer_hwk_from_children(children, "p")

    if dims_q is None and dims_p is None:
        # Nothing to infer from yet — let caller skip CG this step
        raise ValueError("no child fields to infer dims")

    # Prefer q dims; fall back to p dims
    if dims_q is None:
        H, W, _ = dims_p
        Kq = _ = _infer_hwk_from_children(children, "q")[2] if _infer_hwk_from_children(children, "q") else None
        if Kq is None:
            # If truly no q K yet, pick Kq = 3 as a placeholder only if your code accepts it,
            # otherwise bail and let next step handle it.
            raise ValueError("no q-dims")
    else:
        H, W, Kq = dims_q

    if getattr(P, "mu_q_field", None) is None:
        P.mu_q_field = np.zeros((H, W, Kq), dtype=np.float32)
    if getattr(P, "sigma_q_field", None) is None:
        Iq = np.eye(Kq, dtype=np.float32)
        P.sigma_q_field = np.broadcast_to(Iq, (H, W, Kq, Kq)).copy()

    if dims_p is None:
        # Try to reuse H,W and set a minimal Kp from existing parent or skip
        mup = getattr(P, "mu_p_field", None)
        if mup is None:
            # Can't infer Kp → skip CG this round
            return H, W, Kq, getattr(P, "mu_p_field", np.zeros((H, W, 0), np.float32)).shape[-1]
        Kp = int(np.asarray(mup).shape[-1])
    else:
        H2, W2, Kp = dims_p
        if (H2, W2) != (H, W):
            H, W = H2, W2  # keep grids aligned (your framework assumes same grid)
            # also resize q fields if needed (optional; or bail out and wait next step)

    if getattr(P, "mu_p_field", None) is None:
        P.mu_p_field = np.zeros((H, W, Kp), dtype=np.float32)
    if getattr(P, "sigma_p_field", None) is None:
        Ip = np.eye(Kp, dtype=np.float32)
        P.sigma_p_field = np.broadcast_to(Ip, (H, W, Kp, Kp)).copy()

    return H, W, Kq, Kp


def _identity_rot_grid(H, W, K):
    """Return an (H,W,K,K) identity rotation grid for the given irrep size."""
    I = np.eye(K, dtype=np.float64)
    return np.broadcast_to(I, (H, W, K, K)).copy()








def _parent_mask_core(P) -> np.ndarray:
    M = np.asarray(getattr(P, "mask", None), np.float32)
    if M is None:
        return None
    thr_abs = float(getattr(config, "parent_growth_core_tau", 0.20))
    thr_rel = 0.50
    thr = max(thr_abs, thr_rel * float(np.max(M) if M.size else 0.0))
    return (M > thr)







