# -*- coding: utf-8 -*-
"""
Created on Wed Jul 23 09:23:50 2025

@author: chris and christine
"""
import numpy as np
import config
from numerical_utils import safe_inv
from get_generators import get_generators
from numerical_utils import sanitize_sigma
from omega import safe_bch_exact



def apply_natural_gradient_batch(mu_field, sigma_field, grad_mu_field, grad_sigma_field, mask=None):
    """
    Vectorized natural gradient for Gaussian fields:
      δμ = -Σ ∇_μ L
      δΣ = -2 Σ sym(∇_Σ L) Σ

    Args:
        mu_field         : (H,W,K)
        sigma_field      : (H,W,K,K) SPD (will be sanitized)
        grad_mu_field    : (H,W,K)
        grad_sigma_field : (H,W,K,K)
        mask             : (H,W) bool or float weights

    Returns:
        delta_mu   : (H,W,K)
        delta_sigma: (H,W,K,K)
    """
    H, W, K = mu_field.shape
    N = H * W
    eps = float(getattr(config, "eps", 1e-8))
    clip_sigma = getattr(config, "gradient_clip_sigma", None)
    clip_mu    = getattr(config, "gradient_clip_mu",    None)

    mu   = np.asarray(mu_field, dtype=np.float32).reshape(N, K)
    Sig  = np.asarray(sigma_field, dtype=np.float32).reshape(N, K, K)
    gmu  = np.asarray(grad_mu_field, dtype=np.float32).reshape(N, K)
    gSig = np.asarray(grad_sigma_field, dtype=np.float32).reshape(N, K, K)

    # SPD sanitize once (vectorized)
    Sig = sanitize_sigma(Sig, strict=True)

    # Symmetrize gradient wrt Σ
    gSig = 0.5 * (gSig + np.swapaxes(gSig, -1, -2))

    # Natural steps
    dmu = -np.einsum("nik,nk->ni", Sig, gmu, optimize=True)
    tmp = np.einsum("nij,njk->nik", Sig, gSig, optimize=True)
    dS  = -2.0 * np.einsum("nij,njk->nik", tmp, Sig, optimize=True)
    dS  = 0.5 * (dS + np.swapaxes(dS, -1, -2))  # symmetry guard

    # Mask / weights
    if mask is None:
        active = np.ones(N, dtype=bool)
        wts = None
    else:
        m = np.asarray(mask).reshape(N)
        if m.dtype == bool:
            active = m
            wts = None
        else:
            active = m > float(getattr(config, "support_cutoff_eps", 0.0))
            wts = m.astype(np.float32, copy=False)

    # Norm clipping
    if clip_sigma is not None:
        ns = np.linalg.norm(dS.reshape(N, -1), axis=1)
        cm = (ns > clip_sigma) & active
        scale = np.ones(N, dtype=np.float32)
        scale[cm] = clip_sigma / np.maximum(ns[cm], eps)
        dS *= scale[:, None, None]

    if clip_mu is not None:
        nm = np.linalg.norm(dmu, axis=1)
        cm = (nm > clip_mu) & active
        scale = np.ones(N, dtype=np.float32)
        scale[cm] = clip_mu / np.maximum(nm[cm], eps)
        dmu *= scale[:, None]

    if wts is not None:
        dmu *= wts[:, None]
        dS  *= wts[:, None, None]

    # Zero outside support
    if not active.all():
        ia = ~active
        dmu[ia] = 0.0
        dS[ia]  = 0.0

    dmu = np.nan_to_num(dmu, nan=0.0, posinf=0.0, neginf=0.0).reshape(H, W, K)
    dS  = np.nan_to_num(dS,  nan=0.0, posinf=0.0, neginf=0.0).reshape(H, W, K, K)
    return dmu, dS





def clip_gradient_field(grad_field, threshold=None, norm_type=2, verbose=False, label="∇φ"):
    """
    Optionally clips a gradient field to a maximum norm (global across all entries).

    Args:
        grad_field : (..., d) array of gradients
        threshold  : float or None — if None, no clipping is applied
        norm_type  : int or float — 1, 2, or np.inf
        verbose    : bool — print when clipping happens
        label      : str — name for diagnostics

    Returns:
        clipped gradient field of same shape
    """
    if threshold is None:
        return grad_field

    norm = np.linalg.norm(grad_field.ravel(), ord=norm_type)
    if norm > threshold:
        scale = threshold / (norm + 1e-12)
        if verbose:
            print(f"[Clipping {label}] norm {norm:.2e} → {threshold} (scale {scale:.2e})")
        return grad_field * scale
    return grad_field


def cache_fisher_inverse_morphisms(agent_i, eps=1e-8):
    agent_i.fisher_inv_phi_model = compute_inverse_fisher_field_natural(
        agent_i.Phi,
        agent_i.generators_q_to_p,
        eps=eps
    )
    agent_i.fisher_inv_phi = compute_inverse_fisher_field_natural(
        agent_i.Phi_tilde,
        agent_i.generators_p_to_q,
        eps=eps
    )




def compute_inverse_fisher_field_natural(agent, generators, field="phi"):
    """
    G_ab(x) = Tr[ Σ(x)^{-1} G^a Σ(x)^{-1} G^b ], returns per-point G^{-1}(x).
    """
    sigma_field = agent.sigma_q_field if field == "phi" else agent.sigma_p_field
    mask = (np.asarray(agent.mask) > float(getattr(config, "support_cutoff_eps", 1e-4)))

    Sigma = sanitize_sigma(np.asarray(sigma_field, dtype=np.float32), strict=True)
    H, W, K, _ = Sigma.shape
    d = int(generators.shape[0])

    out = np.zeros((H, W, d, d), dtype=np.float32)
    if not np.any(mask):
        return out

    # Batched inverse then per-point metric
    from numerical_utils import safe_batch_inverse
    Sinv = safe_batch_inverse(Sigma)  # (H,W,K,K)

    # T_a = Σ^{-1} G^a Σ^{-1}  → (H,W,d,K,K)
    T = np.einsum("...ij,ajk->...aik", Sinv, generators, optimize=True)
    T = np.einsum("...aik,...kl->...ail", T, Sinv, optimize=True)

    # G_ab = Tr(T_a G^b)  (H,W,d,d)
    G_ab = np.einsum("...aij,bji->...ab", T, generators, optimize=True)
    G_ab = 0.5 * (G_ab + np.swapaxes(G_ab, -1, -2))

    # Invert small d×d per point (masked)
    eye_d = np.eye(d, dtype=np.float32)
    flat_G = G_ab.reshape(-1, d, d)
    flat_out = out.reshape(-1, d, d)
    flat_mask = mask.reshape(-1)
    idx = np.flatnonzero(flat_mask)

    for m in idx:
        M = flat_G[m]
        # Regularize a touch
        try:
            flat_out[m] = np.linalg.inv(M + float(getattr(config, "eps", 1e-8)) * eye_d)
        except np.linalg.LinAlgError:
            flat_out[m] = eye_d
    return out








def dexpinv_operator(phi, delta, generators, order=3, threshold=0.25):
    """
    Vectorized inverse exponential pushforward (dexp⁻¹) on a Lie algebra grid.

    Given:
        φ     : (..., d) Lie algebra coordinates φ^a G_a
        δ     : (..., d) tangent perturbations δ^a G_a
        generators : (d, K, K) Lie algebra basis matrices
        order      : truncation order for BCH/commutator expansion (if using series)
        threshold  : norm cutoff for switching between series and exact

    Returns:
        corrected_delta : (..., d) array after applying dexpinv_φ to δ
    """
    # Shapes
    *grid_shape, d = phi.shape
    K = generators.shape[-1]

    # Metric coefficients for projection
    gen_norms = np.array([np.trace(G @ G) for G in generators], dtype=phi.dtype)

    # Matrix forms
    phi_mat   = np.einsum("...a,akl->...kl", phi,   generators)
    delta_mat = np.einsum("...a,akl->...kl", delta, generators)

    # Norm proxy: Frobenius norm of [φ, δ]
    ad1 = phi_mat @ delta_mat - delta_mat @ phi_mat
    ad_norm = np.linalg.norm(ad1, axis=(-2, -1))

    # ── Small φ: use commutator expansion ─────────────────────────────
    small_mask = ad_norm <= threshold
    if np.any(small_mask):
        out_small = delta_mat.copy()
        if order >= 1:
            out_small -= 0.5 * ad1
        if order >= 2:
            ad2 = phi_mat @ ad1 - ad1 @ phi_mat
            out_small += (1.0 / 12.0) * ad2
        if order >= 3:
            ad3 = phi_mat @ ad2 - ad2 @ phi_mat
            out_small -= (1.0 / 24.0) * ad3
    else:
        out_small = None

        # ── Large φ: use your safe BCH/logm wrapper ─────────────────────────
    large_mask = ~small_mask
    if np.any(large_mask):
        
        phi_large   = phi_mat[large_mask]
        delta_large = delta_mat[large_mask]
        composed = []
        for A, B in zip(phi_large, delta_large):
            # safe_bch_exact should already handle clipping & NaN guards
            C = safe_bch_exact(A, B)
            composed.append(C - A)
        out_large = np.stack(composed, axis=0)
    else:
        out_large = None


    # ── Combine back into full matrix field ───────────────────────────
    out_mat = np.zeros_like(phi_mat)
    if out_small is not None:
        out_mat[small_mask] = out_small[small_mask]
    if out_large is not None:
        out_mat[large_mask] = out_large

    # ── Project back to coefficients: δ^a = Tr(M·G_a) / Tr(G_a G_a) ───
    corrected = np.empty_like(phi)
    for a in range(d):
        G = generators[a]
        corrected[..., a] = np.einsum("...ij,ij->...", out_mat, G) / gen_norms[a]

    return corrected



def compute_fisher_geometry_gradient(agent_i, agents, params, field="phi", *, step_tag=None):
    """
    ∇_{φ_i} ∑_j ‖G_i - Ω_ij G_j Ω_ijᵀ‖_F^2  with Ω_ij = exp(Φ_i) exp(-Φ_j),
    G = Σ^{-1} (use q/p fiber accordingly). Uses exact d/dφ exp(Φ_i).
    """
    # Select fiber fields and generators
    if field == "phi":
        phi_i      = np.asarray(agent_i.phi, dtype=np.float32)
        Sigma_i    = np.asarray(agent_i.sigma_q_field, dtype=np.float32)
        gen        = getattr(agent_i, "generators_q", None)
        fisher_w   = float(params.get("fisher_geometry_weight", getattr(config, "fisher_geometry_weight", 0.0)))
        sigma_name = "sigma_q_field"
        phi_name   = "phi"
        Kfiber     = Sigma_i.shape[-1]
    else:
        phi_i      = np.asarray(agent_i.phi_model, dtype=np.float32)
        Sigma_i    = np.asarray(agent_i.sigma_p_field, dtype=np.float32)
        gen        = getattr(agent_i, "generators_p", None)
        fisher_w   = float(params.get("fisher_model_geometry_weight", getattr(config, "fisher_model_geometry_weight", 0.0)))
        sigma_name = "sigma_p_field"
        phi_name   = "phi_model"
        Kfiber     = Sigma_i.shape[-1]

    if fisher_w <= 0.0:
        return np.zeros_like(phi_i, dtype=np.float32)

    if gen is None:
        # Fallback to getting generators for this fiber
        from get_generators import get_generators
        gen, _ = get_generators(config.group_name, Kfiber, return_meta=True)

    mask_i = (np.asarray(agent_i.mask) > float(getattr(config, "support_cutoff_eps", 1e-4)))
    if not np.any(mask_i):
        return np.zeros_like(phi_i, dtype=np.float32)

    H, W, d = phi_i.shape
    K = Kfiber

    # Precompute E_i and E_{-i} once (cache by step)
    from omega import get_E_grid_from_phi
    E_i  = get_E_grid_from_phi(phi_i, gen, group_name=config.group_name, sign=+1, cache_tag=step_tag)  # (H,W,K,K)

    # Exact derivative d exp(Φ_i)/d φ_i^a as list of A=3 tensors (H,W,K,K)
    from omega import d_exp_phi_exact
    dE_list = d_exp_phi_exact(phi_i, gen, exp_phi_all=E_i)  # list length d

    # Σ_i^{-1}
    from numerical_utils import safe_batch_inverse, sanitize_sigma
    Sigma_i = sanitize_sigma(Sigma_i, strict=True)
    Sigma_i_inv = safe_batch_inverse(Sigma_i)  # (H,W,K,K)

    G_i = Sigma_i_inv  # proportional; for weighting use the exact scale you prefer

    grad = np.zeros_like(phi_i, dtype=np.float32)
    Ei_flat   = E_i.reshape(-1, K, K)
    G_i_flat  = G_i.reshape(-1, K, K)
    mask_flat = mask_i.reshape(-1)

    # Iterate neighbors (keeps memory bounded)
    nb_list = getattr(agent_i, "neighbors", []) or []
    for nb in nb_list:
        j = nb["id"]
        agent_j = agents[j]
        mask_j = (np.asarray(agent_j.mask) > float(getattr(config, "support_cutoff_eps", 1e-4)))
        overlap = (mask_i & mask_j)
        if not np.any(overlap):
            continue

        idx = np.flatnonzero(overlap.reshape(-1))
        if idx.size == 0:
            continue

        # E_{-j}
        phi_j = np.asarray(getattr(agent_j, phi_name), dtype=np.float32)
        E_mj  = get_E_grid_from_phi(phi_j, gen, group_name=config.group_name, sign=-1, cache_tag=step_tag).reshape(-1, K, K)[idx]

        # Ω_ij = E_i E_{-j}
        Ei_idx = Ei_flat[idx]
        Omega  = np.einsum("mik,mkj->mij", Ei_idx, E_mj, optimize=True)
        Omega_T= np.transpose(Omega, (0,2,1))

        # G_j = Σ_j^{-1}
        Sigma_j = sanitize_sigma(np.asarray(getattr(agent_j, sigma_name), dtype=np.float32), strict=True)
        G_j     = safe_batch_inverse(Sigma_j.reshape(-1, K, K))[idx]

        # Δ = G_i - Ω G_j Ωᵀ
        G_i_idx = G_i_flat[idx]
        Gj_rot  = np.einsum("mik,mkl,mlj->mij", Omega, G_j, Omega_T, optimize=True)
        Delta   = G_i_idx - Gj_rot  # (M,K,K)

        # dΩ/dφ_i^a = (dE_i^a) E_{-j}
        for a in range(d):
            dEi = np.asarray(dE_list[a], dtype=np.float32).reshape(-1, K, K)[idx]
            dOm = np.einsum("mik,mkj->mij", dEi, E_mj, optimize=True)

            dOm_T = np.transpose(dOm, (0,2,1))
            dGj_rot = (np.einsum("mik,mkl,mlj->mij", dOm, G_j, Omega_T, optimize=True) +
                       np.einsum("mik,mkl,mlj->mij", Omega, G_j, dOm_T, optimize=True))

            # dL/dφ_i^a = 2 ⟨Δ, -dG_rot⟩ = -2 ⟨Δ, dG_rot⟩  (since L = ||Δ||²)
            dL_a = -2.0 * np.einsum("mij,mij->m", Delta, dGj_rot, optimize=True).astype(np.float32, copy=False)
            grad.reshape(-1, d)[idx, a] += dL_a

    grad[~mask_flat.reshape(H, W)] = 0.0
    grad *= np.float32(fisher_w)
    return grad


