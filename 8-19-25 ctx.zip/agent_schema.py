from dataclasses import dataclass, field
from typing import Any, Dict, List, Tuple, Optional
import numpy as np
from numerical_utils import safe_omega_inv

@dataclass
class Agent:
    id: int
    center: Tuple[int, ...]
    radius: float
    mask: np.ndarray

    #============================================================================
    #                                FIELDS
    #============================================================================

    # Lie fields (SO(3) algebra, last dim = 3)
    phi: np.ndarray
    phi_model: np.ndarray

    # Belief/model fields (μ/Σ)
    mu_q_field: np.ndarray            # (..., Kq)
    sigma_q_field: np.ndarray         # (..., Kq, Kq)
    mu_p_field: np.ndarray            # (..., Kp)
    sigma_p_field: np.ndarray         # (..., Kp, Kp)

    # Inverses (filled in preprocess)
    sigma_q_inv: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    sigma_p_inv: Optional[np.ndarray] = field(default=None, init=False, repr=False)

    #============================================================================
    #                        CONNECTIONS / MORPHISMS
    #============================================================================

    # Bundle morphisms (transported Φ fields)
    bundle_morphism_q_to_p: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    bundle_morphism_p_to_q: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    
    Phi_0: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    Phi_tilde_0: Optional[np.ndarray] = field(default=None, init=False, repr=False)

    # Authoritative per-parent Λ fields (field-shaped per pixel): (H, W, K, K)
    Lambda_up_q_map: Dict[int, np.ndarray] = field(default_factory=dict, init=False, repr=False)
    Lambda_dn_q_map: Dict[int, np.ndarray] = field(default_factory=dict, init=False, repr=False)
    Lambda_up_p_map: Dict[int, np.ndarray] = field(default_factory=dict, init=False, repr=False)
    Lambda_dn_p_map: Dict[int, np.ndarray] = field(default_factory=dict, init=False, repr=False)

    # Optional global (coarse) Λ per parent id (Log–Euclidean mean): (K, K)
    Lambda_up_q_global: Dict[int, np.ndarray] = field(default_factory=dict, init=False, repr=False)
    Lambda_up_p_global: Dict[int, np.ndarray] = field(default_factory=dict, init=False, repr=False)

    # Cross-scale inference maps (Θ) — placeholders for future work
    Theta_up: Optional[np.ndarray] = field(default=None, init=False, repr=False)   # (Kp, Kq)
    Theta_dn: Optional[np.ndarray] = field(default=None, init=False, repr=False)   # (Kq, Kp)

    # Mark transported Φ/Φ̃ dirty when φ/φ̃ or bases change
    morphisms_dirty: bool = field(default=True, init=False, repr=False)

    #============================================================================
    #                               GRADIENTS
    #============================================================================

    # Gradient caches (μ/Σ)
    grad_mu_q: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    grad_sigma_q: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    grad_mu_p: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    grad_sigma_p: Optional[np.ndarray] = field(default=None, init=False, repr=False)

    # φ/φ̃ grads (field-shaped)
    grad_phi: np.ndarray = field(init=False, repr=False)
    grad_phi_tilde: np.ndarray = field(init=False, repr=False)

    # Morphism grads (optional)
    grad_Phi: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    grad_Phi_tilde: Optional[np.ndarray] = field(default=None, init=False, repr=False)

    # (optional) gradient buffers for Λ globals (allocate on demand if you actually use them)
    grad_Lambda_up_q: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    grad_Lambda_dn_q: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    grad_Lambda_up_p: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    grad_Lambda_dn_p: Optional[np.ndarray] = field(default=None, init=False, repr=False)

    grad_Theta_up: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    grad_Theta_dn: Optional[np.ndarray] = field(default=None, init=False, repr=False)

    #============================================================================
    #                                 CACHES
    #============================================================================

    # Generators (set once and reused)
    generators_q: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    generators_p: Optional[np.ndarray] = field(default=None, init=False, repr=False)

    # exp(φ) caches (filled in preprocess; shape (..., K, K))
    _exp_phi: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    _exp_neg_phi: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    _exp_phi_model: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    _exp_neg_phi_model: Optional[np.ndarray] = field(default=None, init=False, repr=False)

    # Inter-agent transport caches
    Omega_cache: Dict[str, Any] = field(default_factory=dict, init=False, repr=False)
    Omega_tilde_cache: Dict[str, Any] = field(default_factory=dict, init=False, repr=False)

    cached_alignment_kl: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    cached_model_alignment_kl: Optional[np.ndarray] = field(default=None, init=False, repr=False)

    #============================================================================
    #                                   MISC
    #============================================================================

    # Fisher caches for φ/φ̃ or morphisms
    inverse_fisher_phi: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    inverse_fisher_phi_model: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    inverse_fisher_Phi: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    inverse_fisher_Phi_tilde: Optional[np.ndarray] = field(default=None, init=False, repr=False)

    # adaptive-η & KL caches
    _cond_proxy_q: Optional[float] = field(default=None, init=False, repr=False)
    _cond_proxy_p: Optional[float] = field(default=None, init=False, repr=False)
    _eta_phi_prev: Optional[float] = field(default=None, init=False, repr=False)
    _eta_phi_m_prev: Optional[float] = field(default=None, init=False, repr=False)

    # Neighborhood & logging
    neighbors: List[Dict[str, Any]] = field(default_factory=list)
    metrics_log: List[Dict[str, Any]] = field(default_factory=list)

    # Cross-scale metadata
    level: int = 0
    parent_ids: List[int] = field(default_factory=list)
    child_ids: List[int] = field(default_factory=list)

    # Lifecycle & level helpers (safe defaults)
    birth_step: int = 0
    emerged: bool = False
    _age: int = 0
    _grace: int = 0
    _shrink_strikes: int = 0

    # Detection/growth scratch
    _core_map: Optional[np.ndarray] = field(default=None, init=False, repr=False)           # (H,W) bool/float
    _region_proposal: Optional[np.ndarray] = field(default=None, init=False, repr=False)    # (H,W) float

    # Multi-level parent routing (optional)
    parent_id_by_level: Dict[int, int] = field(default_factory=dict, init=False, repr=False)

    #============================== METHODS =====================================

    def __post_init__(self):
        self.grad_phi = np.zeros_like(self.phi)
        self.grad_phi_tilde = np.zeros_like(self.phi_model)
        if self.bundle_morphism_q_to_p is not None:
            self.grad_Phi = np.zeros_like(self.bundle_morphism_q_to_p)
        if self.bundle_morphism_p_to_q is not None:
            self.grad_Phi_tilde = np.zeros_like(self.bundle_morphism_p_to_q)

    @property
    def hw(self) -> Tuple[int, int]:
        return (int(self.mask.shape[0]), int(self.mask.shape[1]))

    def support(self, tau: float = 0.30) -> np.ndarray:
        """Boolean support mask (H,W) with a standard cutoff."""
        return (np.asarray(self.mask, np.float32) > float(tau))

    def mark_omega_dirty(self) -> None:
        """Invalidate exp(phi) caches after mask/phi edits."""
        self._exp_phi = self._exp_neg_phi = None
        self._exp_phi_model = self._exp_neg_phi_model = None
        self.Omega_cache.clear()
        self.Omega_tilde_cache.clear()

    def ensure_generators(self, generators_q: Optional[np.ndarray], generators_p: Optional[np.ndarray]) -> None:
        if self.generators_q is None and generators_q is not None:
            self.generators_q = generators_q
        if self.generators_p is None and generators_p is not None:
            self.generators_p = generators_p

    def link_parent_for_level(self, level: int, pid: int) -> None:
        self.parent_id_by_level[int(level)] = int(pid)
        if pid not in self.parent_ids:
            self.parent_ids.append(int(pid))

    def mark_morphism_dirty(self) -> None:
        """Invalidate Φ/Φ̃ caches after φ/φ̃ or Φ₀/Φ̃₀ changes."""
        self.morphisms_dirty = True
        self.bundle_morphism_q_to_p = None
        self.bundle_morphism_p_to_q = None

    @property
    def grid_shape(self) -> Tuple[int, ...]:
        return self.mu_q_field.shape[:-1]

    @property
    def Omega(self) -> np.ndarray:
        K = self.mu_q_field.shape[-1]
        return self._exp_phi.reshape(*self.grid_shape, K, K)

    @property
    def Omega_inv(self) -> np.ndarray:
        K = self.mu_q_field.shape[-1]
        return self._exp_neg_phi.reshape(*self.grid_shape, K, K)

    @property
    def Omega_model(self) -> np.ndarray:
        K = self.mu_p_field.shape[-1]
        return self._exp_phi_model.reshape(*self.grid_shape, K, K)

    @property
    def Omega_model_inv(self) -> np.ndarray:
        K = self.mu_p_field.shape[-1]
        return self._exp_neg_phi_model.reshape(*self.grid_shape, K, K)

    def log_metrics(self, step: int, stats: Dict[str, Any]) -> None:
        import copy
        self.metrics_log.append(copy.deepcopy({'step': step, **stats}))

    def clear_omega_cache(self) -> None:
        self._exp_phi = None
        self._exp_neg_phi = None
        self._exp_phi_model = None
        self._exp_neg_phi_model = None
        self.Omega_cache.clear()
        self.Omega_tilde_cache.clear()

    def clear_diagnostics(self) -> None:
        # keep placeholders if you write to these elsewhere
        self.fisher_I = None
        self.pull_M_vis = None
        self.pull_Delta = None
        self.pull_M_dark = None
        self.spatial_G = None

    def clear_fisher_caches(self) -> None:
        self.inverse_fisher_phi = None
        self.inverse_fisher_phi_model = None
        self.inverse_fisher_Phi = None
        self.inverse_fisher_Phi_tilde = None

    #------------------------------ Λ helpers -----------------------------------

    def ensure_crossscale_defaults(self, Kq: int, Kp: int) -> None:
        """
        Keep only Θ defaults here; Λ maps are built in preprocess.
        """
        if self.Theta_up is None:
            self.Theta_up = np.zeros((Kp, Kq))
            self.Theta_dn = np.zeros((Kq, Kp))

    def ensure_crossscale_grad_buffers(self) -> None:
        """
        Allocate grads for Θ and (optionally) for a selected global Λ if you use them.
        """
        if self.Theta_up is not None and self.grad_Theta_up is None:
            self.grad_Theta_up = np.zeros_like(self.Theta_up)
            self.grad_Theta_dn = np.zeros_like(self.Theta_dn)

        # If you rely on Λ global grads, pick a parent (e.g., primary) and allocate from globals
        pid = self.primary_parent()
        if pid is not None:
            if pid in self.Lambda_up_q_global and self.grad_Lambda_up_q is None:
                Lq = self.Lambda_up_q_global[pid]
                self.grad_Lambda_up_q = np.zeros_like(Lq)
                self.grad_Lambda_dn_q = np.zeros_like(Lq)
            if pid in self.Lambda_up_p_global and self.grad_Lambda_up_p is None:
                Lp = self.Lambda_up_p_global[pid]
                self.grad_Lambda_up_p = np.zeros_like(Lp)
                self.grad_Lambda_dn_p = np.zeros_like(Lp)

    def clear_crossscale_maps(self) -> None:
        """
        Clear all Λ/Θ structures (authoritative maps + optional globals + grads).
        """
        self.grad_Lambda_up_q = None
        self.grad_Lambda_dn_q = None
        self.grad_Lambda_up_p = None
        self.grad_Lambda_dn_p = None
        self.Lambda_up_q_map.clear()
        self.Lambda_dn_q_map.clear()
        self.Lambda_up_p_map.clear()
        self.Lambda_dn_p_map.clear()
        self.Lambda_up_q_global.clear()
        self.Lambda_up_p_global.clear()
        self.Theta_up = None
        self.Theta_dn = None
        self.grad_Theta_up = None
        self.grad_Theta_dn = None

    def build_lambda_q_to(self, parent: "Agent", parent_id: Optional[int] = None) -> np.ndarray:
        """
        Gauge-covariant cross-scale map for the belief fiber:
            Λ_{c→P}^q(c) = exp(φ_P(c)) · exp(−φ_c(c))
            Λ_{P→c}^q(c) = exp(φ_c(c)) · exp(−φ_P(c))
        Uses cached exponentials; stores per-parent fields and a global mean (in *_global).
        """
        E_c = getattr(self, "_exp_phi", None)
        E_c_inv = getattr(self, "_exp_neg_phi", None)
        E_P = getattr(parent, "_exp_phi", None)
        E_P_inv = getattr(parent, "_exp_neg_phi", None)
        if E_c is None or E_c_inv is None or E_P is None or E_P_inv is None:
            raise RuntimeError("Missing exp(phi) caches; build exponentials before build_lambda_q_to().")

        # Field-shaped Λ (H,W,Kq,Kq)
        Lambda_up_field = E_P @ E_c_inv
        Lambda_dn_field = E_c @ E_P_inv

        pid = parent_id if parent_id is not None else parent.id
        self.Lambda_up_q_map[pid] = Lambda_up_field
        self.Lambda_dn_q_map[pid] = Lambda_dn_field

        # Optional global mean (Log–Euclidean) for convenience
        m = (self.mask > 0) & (parent.mask > 0)
        if m.any():
            try:
                import scipy.linalg as la
                L = Lambda_up_field[m]  # (M, K, K)
                logs = np.stack([la.logm(X) for X in L], axis=0)
                self.Lambda_up_q_global[pid] = la.expm(logs.mean(axis=0))
            except Exception:
                # Fallback: arithmetic mean (not group-correct, but stable)
                self.Lambda_up_q_global[pid] = np.mean(Lambda_up_field[m], axis=0)
        return self.Lambda_up_q_map[pid]

    def build_lambda_p_to(self, parent: "Agent", parent_id: Optional[int] = None) -> np.ndarray:
        """
        Gauge-covariant cross-scale map for the model fiber:
            Λ_{c→P}^p(c) = exp(φ̃_P(c)) · exp(−φ̃_c(c))
            Λ_{P→c}^p(c) = exp(φ̃_c(c)) · exp(−φ̃_P(c))
        Uses cached exponentials; stores per-parent fields and a global mean (in *_global).
        """
        E_c = getattr(self, "_exp_phi_model", None)
        E_c_inv = getattr(self, "_exp_neg_phi_model", None)
        E_P = getattr(parent, "_exp_phi_model", None)
        E_P_inv = getattr(parent, "_exp_neg_phi_model", None)
        if E_c is None or E_c_inv is None or E_P is None or E_P_inv is None:
            raise RuntimeError("Missing exp(phi_tilde) caches; build exponentials before build_lambda_p_to().")

        # Field-shaped Λ (H,W,Kp,Kp)
        Lambda_up_field = E_P @ E_c_inv
        Lambda_dn_field = E_c @ E_P_inv

        pid = parent_id if parent_id is not None else parent.id
        self.Lambda_up_p_map[pid] = Lambda_up_field
        self.Lambda_dn_p_map[pid] = Lambda_dn_field

        # Optional global mean
        m = (self.mask > 0) & (parent.mask > 0)
        if m.any():
            try:
                import scipy.linalg as la
                L = Lambda_up_field[m]
                logs = np.stack([la.logm(X) for X in L], axis=0)
                self.Lambda_up_p_global[pid] = la.expm(logs.mean(axis=0))
            except Exception:
                self.Lambda_up_p_global[pid] = np.mean(Lambda_up_field[m], axis=0)
        return self.Lambda_up_p_map[pid]

    def primary_parent(self) -> Optional[int]:
        """Return the first parent id if present, else None."""
        pids = getattr(self, "parent_ids", None)
        return pids[0] if pids else None
