# -*- coding: utf-8 -*-
"""
Created on Sun Jul 13 13:06:16 2025

@author: chris and christine
"""
import sys
import numpy as np
import warnings
from collections import defaultdict
from joblib import Parallel, delayed
from numpy.linalg import LinAlgError, slogdet  # ✅ Needed for exception handling
import config
from scipy.linalg import logm  # Only if safe_logm is used
import io
import contextlib


# Global counters
fallback_counter = defaultdict(int)

#=======================================
#
#         Reporting/Logging
#
#======================================


# ----- geometry / morphology -----
def resize_nn(a: np.ndarray, shape: tuple[int, int]) -> np.ndarray:
    H, W = shape; h, w = a.shape[:2]
    if (h, w) == (H, W): return a
    yi = np.clip(np.rint(np.linspace(0, h - 1, H)).astype(int), 0, h - 1)
    xi = np.clip(np.rint(np.linspace(0, w - 1, W)).astype(int), 0, w - 1)
    return a[yi][:, xi]


def project_spd(S, eig_floor=1e-6, eig_cap=None, cond_cap=None, trace_target=None):
    """
    Project symmetric matrices S[...,K,K] onto SPD by eigen clipping (not inversion).
    """
    S = 0.5 * (S + np.swapaxes(S, -1, -2))
    w, V = np.linalg.eigh(S)
    # floor
    w = np.maximum(w, eig_floor)
    # condition number cap
    if cond_cap is not None:
        w_min = w.min(axis=-1, keepdims=True)
        w = np.minimum(w, w_min * cond_cap)
    # absolute cap
    if eig_cap is not None:
        w = np.minimum(w, eig_cap)
    # rebuild S = V diag(w) V^T
    S_proj = (V * w[..., None, :]) @ np.swapaxes(V, -1, -2)
    if trace_target is not None:
        tr = np.trace(S_proj, axis1=-2, axis2=-1)[..., None, None]
        S_proj = S_proj * (trace_target / np.clip(tr, 1e-12, None))
    return 0.5 * (S_proj + np.swapaxes(S_proj, -1, -2))




def safe_inv(Sigma, eps=1e-10, max_eig=None, debug=False):
    """
    Batch-safe inverse of SPD matrices with eigenvalue clipping.
    Supports input shape (..., K, K).

    Returns inverse of Sigma with clipped eigenvalues from below (and optionally from above).
    """
    shape = Sigma.shape
    K = shape[-1]
    flat_S = Sigma.reshape(-1, K, K)

    # Step 1: eigen-decomposition (batch)
    eigvals, eigvecs = np.linalg.eigh(flat_S)

    if debug:
        print(f"[safe_inv] eigvals min={eigvals.min(axis=1).min():.2e}, max={eigvals.max(axis=1).max():.2e}")

    # Step 2: clip eigenvalues
    if max_eig is not None:
        eigvals_clipped = np.clip(eigvals, eps, max_eig)
    else:
        eigvals_clipped = np.maximum(eigvals, eps)

    inv_eigvals = 1.0 / eigvals_clipped

    # Step 3: reconstruct inverse matrices
    Sigma_inv = (eigvecs * inv_eigvals[..., None, :]) @ np.swapaxes(eigvecs, -2, -1)

    # Symmetrize for numerical safety
    Sigma_inv = 0.5 * (Sigma_inv + np.swapaxes(Sigma_inv, -1, -2))

    # Handle NaN / Inf
    Sigma_inv = np.nan_to_num(Sigma_inv, nan=eps, posinf=eps, neginf=eps)

    Sigma_inv = Sigma_inv.reshape(shape)

    return Sigma_inv


def safe_batch_inverse(S, name="Σ", mask=None):
    """
    Vectorized batch matrix inverse with mask & robust fallback.
    Inputs:
        S: (..., K, K)
        mask: optional (...,) boolean; False → returns identity for that slice
    """
    S = np.asarray(S)
    *batch, K, _ = S.shape
    eye = np.eye(K, dtype=S.dtype)
    if mask is not None:
        mask = np.asarray(mask, dtype=bool)
        # Fill masked positions with I to avoid pointless work
        S = S.copy()
        S[~mask] = eye

    # Try a one-shot vectorized inverse
    try:
        invS = np.linalg.inv(S)
        # Re-symmetrize for safety
        invS = 0.5 * (invS + np.swapaxes(invS, -1, -2))
    except np.linalg.LinAlgError:
        # Rare: do per-slice fallback only for the failing ones
        invS = np.empty_like(S)
        S_flat = S.reshape(-1, K, K)
        for i, A in enumerate(S_flat):
            try:
                invA = np.linalg.inv(A)
            except np.linalg.LinAlgError:
                log_fallback("safe_batch_inverse", f"{name}: singular slice {i}", count_key="safe_batch_inverse")
                invA = eye
            invS.reshape(-1, K, K)[i] = 0.5 * (invA + invA.T)
    return invS



# safe inverse of a matrix field (H,W,K,K)
def _invert_matrix_field(Omega_full: np.ndarray) -> np.ndarray | None:
    try:
        H, W, K, _ = Omega_full.shape
        M = Omega_full.reshape(-1, K, K)
        Minv = np.linalg.inv(M)
        return Minv.reshape(H, W, K, K).astype(np.float32, copy=False)
    except Exception:
        return None




def soft_clip_phi_norm(phi: np.ndarray, max_norm: float = np.pi, eps: float = 1e-8) -> np.ndarray:
    """
    Smoothly compress φ ∈ ℝᵈ to have norm ≤ max_norm, with soft decay and stable transition.

    Args:
        phi:      (..., d) Lie algebra field at each point
        max_norm: float, maximum allowed norm
        eps:      float, safety margin for zero division

    Returns:
        φ_clipped: (..., d) compressed φ with ‖φ‖ ≤ max_norm
    """
    norm = np.linalg.norm(phi, axis=-1, keepdims=True)  # (..., 1)
    scale = np.where(norm > max_norm, max_norm / (norm + eps), 1.0)  # (..., 1)
    return phi * scale  # (..., d)




def log_fallback(tag: str, msg: str, count_key: str = None, error: bool = False):
    """
    Standardized fallback logger.

    Args:
        tag       : str — context tag (e.g. 'safe_inv', 'logm', etc.)
        msg       : str — fallback message
        count_key : str — key for fallback_counter increment
        error     : bool — whether to raise RuntimeError (if fail_on_fallback)

    Behavior:
        - Increments fallback counter
        - Warns or raises
        - Flushes stdout
    """
    full_msg = f"[{tag}] {msg}"

    if count_key:
        fallback_counter[count_key] += 1
        full_msg = f"[{tag}] Fallback #{fallback_counter[count_key]}: {msg}"

    if getattr(config, "fail_on_fallback", False) or error:
        raise RuntimeError(full_msg)
    else:
        warnings.warn(full_msg, RuntimeWarning)
        sys.stdout.flush()


        
#====================================================
#
#                 Safety Ops
#
#=====================================================

def safe_omega_inv(M, eps=1e-10, debug=False):
    """
    Safely invert an orthogonal matrix field via transpose, with validation & batch fallback.
    """
    M = np.asarray(M)
    assert M.shape[-1] == M.shape[-2], "Matrix is not square"
    K = M.shape[-1]
    M_T = np.swapaxes(M, -1, -2)

    if not np.all(np.isfinite(M)):
        log_fallback("safe_omega_inv", "non-finite entries", count_key="omega_inv")
        I = np.eye(K, dtype=M.dtype)
        return np.broadcast_to(I, M.shape)

    approx_I = M @ M_T
    I = np.eye(K, dtype=M.dtype)
    dev = np.linalg.norm(approx_I - I, axis=(-2, -1))
    if np.any(dev > eps):
        if debug:
            print(f"[safe_omega_inv] max deviation {dev.max():.3e} > {eps:.3e}")
        log_fallback("safe_omega_inv", f"orthogonality deviation > {eps}", count_key="omega_inv")
        I = np.eye(K, dtype=M.dtype)
        return np.broadcast_to(I, M.shape)

    return M_T


def _sanitize_one_sigma(S, eps=1e-4, debug=False):
    """
    Ensure a single Σ is symmetric positive-definite (SPD).
    Returns: (Σ_sanitized, clipped_flag)
    """
    S = 0.5 * (S + S.T)  # enforce symmetry

    if not np.all(np.isfinite(S)):
        if debug:
            print("[sanitize_sigma] NaNs or Infs detected — replacing with eps*I")
        # fallback to scaled identity but warn heavily
        fallback = np.eye(S.shape[0]) * eps
        return fallback, True

    try:
        eigvals, eigvecs = np.linalg.eigh(S)
    except np.linalg.LinAlgError:
        if debug:
            print("[sanitize_sigma] Eigendecomposition failed — replacing with eps*I")
        fallback = np.eye(S.shape[0]) * eps
        return fallback, True

    clipped = np.any(eigvals < eps)
    if clipped:
        if debug:
            print(f"[sanitize_sigma] Minimum eigenvalue {eigvals.min():.3e} below eps {eps:.3e}, clipping...")
        # Clip eigenvalues to eps floor
        eigvals_clipped = np.clip(eigvals, eps, None)
        S = eigvecs @ np.diag(eigvals_clipped) @ eigvecs.T
        S = 0.5 * (S + S.T)  # re-symmetrize

    return S, clipped


def sanitize_sigma(
    Sigma,
    debug=True,
    strict=True,
    eig_floor=None,
    cond_cap=None,
    eig_cap=None,
    trace_target=None,
    eps = config.eps
):
    """
    Ensure Σ is SPD. Vectorized:
      - strict=True: project all (most robust).
      - strict=False: detect abuses and project only those.
    """
    eig_floor   = eig_floor   if eig_floor   is not None else getattr(config, "sigma_eig_floor", 1e-6)
    cond_cap    = cond_cap    if cond_cap    is not None else getattr(config, "sigma_cond_cap", 1e4)
    eig_cap     = eig_cap     if eig_cap     is not None else getattr(config, "sigma_eig_cap", None)
    trace_target= trace_target if trace_target is not None else getattr(config, "sigma_trace_target", None)

    S = 0.5 * (Sigma + np.swapaxes(Sigma, -1, -2))
    bad_finite = ~np.isfinite(S).all(axis=(-2, -1))
    if np.any(bad_finite):
        if debug:
            print(f"[sanitize_sigma] {int(bad_finite.sum())} matrices had NaN/Inf; replaced with floor*I")
        K = S.shape[-1]
        eye = np.eye(K, dtype=S.dtype)
        S = S.copy()
        S[bad_finite] = eig_floor * eye

    if strict:
        return project_spd(S, eig_floor=eig_floor, eig_cap=eig_cap, cond_cap=cond_cap, trace_target=trace_target)

    # Light path
    w = np.linalg.eigvalsh(S)
    too_small = (w <= eig_floor).any(axis=-1)
    too_cond  = (w.max(axis=-1) > np.maximum(w.min(axis=-1), eig_floor) * (cond_cap if cond_cap else np.inf))
    bad = bad_finite | too_small | too_cond
    if not np.any(bad):
        return S
    S = S.copy()
    S[bad] = project_spd(S[bad], eig_floor=eig_floor, eig_cap=eig_cap, cond_cap=cond_cap, trace_target=trace_target)
    if debug:
        total = int(np.prod(S.shape[:-2]))
        print(f"[sanitize_sigma] projected {int(bad.sum())}/{total} matrices")
    return S



def _spd_project_batch(A, eig_floor=1e-6, eig_cap=None, cond_cap=None, trace_target=None, eps=1e-12):
    """
    Project a stack of symmetric matrices A[..., K, K] onto SPD via eigen clipping.
    Returns A_proj with guaranteed SPD (up to eps).
    """
    A = 0.5 * (A + np.swapaxes(A, -1, -2))
    w, V = np.linalg.eigh(A)                           # batched
    # floor
    w = np.maximum(w, eig_floor)
    # condition number cap
    if cond_cap is not None:
        w_min = w.min(axis=-1, keepdims=True)
        w = np.minimum(w, w_min * cond_cap)
    # absolute cap (rarely needed)
    if eig_cap is not None:
        w = np.minimum(w, eig_cap)
    A_proj = (V * w[..., None, :]) @ np.swapaxes(V, -1, -2)
    if trace_target is not None:
        tr = np.trace(A_proj, axis1=-2, axis2=-1)[..., None, None]
        A_proj = A_proj * (trace_target / np.clip(tr, eps, None))
    return 0.5 * (A_proj + np.swapaxes(A_proj, -1, -2))







def safe_logm(M, fallback_value=None, imag_tol=1e-10, context="Ω"):
    """
    Suppress logm's internal stderr output and check imag part manually.
    """
    from numerical_utils import log_fallback  # Ensure this exists

    try:
        # Suppress logm's stderr output
        with io.StringIO() as buf, contextlib.redirect_stderr(buf):
            logM = logm(M)

        imag_norm = np.linalg.norm(np.imag(logM), ord="fro")
        if imag_norm > imag_tol:
            log_fallback("safe_logm", f"{context}: ‖Im(logm)‖={imag_norm:.2e} > tol={imag_tol}")
        return np.real_if_close(logM, tol=imag_tol)

    except Exception as e:
        log_fallback("safe_logm", f"{context}: logm failed ({e})", count_key="safe_logm")
        K = M.shape[-1]
        return fallback_value if fallback_value is not None else np.zeros((K, K), dtype=M.dtype)




def safe_logdet(Sigma, eps=1e-8, alpha=1e-2, clip_range=(-1e3, 1e3)):
    """
    Safe logdet for (stacked) SPD-ish matrices with eps*I stabilization
    and a trace-based fallback. Casts to float32 for linalg.
    """
    Sigma = np.asarray(Sigma, dtype=np.float32)
    K = Sigma.shape[-1]
    batch_shape = Sigma.shape[:-2]

    eye = np.eye(K, dtype=Sigma.dtype) * eps
    Sigma_reg = Sigma + eye

    try:
        sign, ld = np.linalg.slogdet(Sigma_reg)
        bad = (sign <= 0) | ~np.isfinite(ld)
        if not np.any(bad):
            return np.clip(ld, *clip_range)
    except np.linalg.LinAlgError:
        bad = np.ones(batch_shape, dtype=bool)

    trace = np.trace(Sigma, axis1=-2, axis2=-1).astype(np.float32, copy=False)
    surrogate = alpha * (trace / K + eps)
    fallback_ld = K * np.log(np.clip(surrogate, eps, None))

    log_fallback("safe_logdet", "fallback triggered", count_key="safe_logdet")
    ld_final = np.where(bad, fallback_ld, ld)
    return np.clip(ld_final, *clip_range)





def masked_cond_proxy(S, mask, eps=1e-12):
    # S: (H,W,K,K) already sanitized here
    H,W,K = S.shape[:3]
    S2 = S.reshape(-1, K, K)
    m  = mask.reshape(-1).astype(bool)

    tr  = np.trace(S2, axis1=-2, axis2=-1)[m]                 # (M,)
    sign, logdet = np.linalg.slogdet(S2[m])                   # (M,), (M,)
    # For SPD, sign should be +1; guard anyway
    logdet = np.where(sign > 0, logdet, np.log(eps))
    cond_proxy = tr * np.exp(-logdet / K)                     # scale-invariant

    # robust aggregate over support
    if cond_proxy.size == 0:
        return 1.0
    return float(np.median(cond_proxy))


def masked_stat(x, mask, default=0.0):
    if x is None: return default
    xx = x[mask > getattr(config, "support_cutoff_eps", 0.0)]
    if xx.size == 0 or not np.isfinite(xx).any(): return default
    return float(np.median(xx[np.isfinite(xx)]))
   