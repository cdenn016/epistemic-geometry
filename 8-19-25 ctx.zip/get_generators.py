import numpy as np
from scipy.linalg import expm

import numpy as np
from scipy.linalg import expm

#=======================================================
#
#           Generators
#
#=========================================================


_generator_cache = {}  # Already declared

def get_generators(group_name, K, return_meta=False):
    group_name = group_name.lower()
    if group_name not in ["sl2r", "so3"]:
        raise ValueError(f"Unsupported group: {group_name}")

    if isinstance(K, int):
        key = (group_name, K)
    elif isinstance(K, list):
        key = (group_name, tuple(K))
    else:
        raise TypeError(f"[get_generators] Invalid type for K: {type(K)}")

    if key in _generator_cache:
        G, meta = _generator_cache[key]
    else:
        if isinstance(K, int):
            if group_name == "sl2r":
                G_dict = sl2r_irrep(K)
            else:  # SO(3)
                G_dict = so3_irrep(K)

            for name in ["E", "F", "H"]:
                Gmat = G_dict[name]
                assert Gmat.ndim == 2 and Gmat.shape[0] == Gmat.shape[1]

            G = np.stack([G_dict["E"], G_dict["F"], G_dict["H"]], axis=0)
            meta = {"blocks": [K]}
        else:
            G, meta = _get_reducible_sl2r(K)  # You can also later define `_get_reducible_so3`

        _generator_cache[key] = (G, meta)

    return (G, meta) if return_meta else G



def so3_irrep(K: int) -> dict:
    """
    Construct the real-valued irreducible SO(3) generators E, F, H for dimension K = 2ℓ + 1.
    These are antisymmetric, compact generators of so(3), suitable for angular momentum.
    """
    if K % 2 == 0:
        raise ValueError("K must be odd for SO(3) irreps (K = 2ℓ + 1).")
    ℓ = (K - 1) // 2
    Jx = np.zeros((K, K), dtype=float)
    Jy = np.zeros((K, K), dtype=float)
    Jz = np.zeros((K, K), dtype=float)

    for m in range(-ℓ, ℓ + 1):
        i = m + ℓ
        if i < K - 1:
            a = 0.5 * np.sqrt((ℓ - m) * (ℓ + m + 1))
            Jx[i, i+1] = a
            Jx[i+1, i] = a
            Jy[i, i+1] = a
            Jy[i+1, i] = -a
        Jz[i, i] = m

    # Antisymmetric real basis
    E = Jy  # ∼ L_y
    F = -Jx  # ∼ -L_x
    H = Jz   # ∼ L_z
    return {"E": E, "F": F, "H": H}



def sl2r_irrep(K: int) -> dict:
    """
    Return the real irreducible SL(2,R) generators E, F, H for dimension K = 2ℓ + 1.
    """
    if K % 2 == 0:
        raise ValueError("K must be odd for SL(2,R) irreps (K = 2ℓ + 1).")
    ℓ = (K - 1) // 2
    E = np.zeros((K, K), dtype=float)
    F = np.zeros((K, K), dtype=float)
    H = np.zeros((K, K), dtype=float)

    for m in range(-ℓ, ℓ + 1):
        i = m + ℓ
        H[i, i] = m
        if i < K - 1:
            a = np.sqrt((ℓ - m) * (ℓ + m + 1))
            E[i, i + 1] = a
            E[i + 1, i] = a
            F[i, i + 1] = -a
            F[i + 1, i] = a
    return {"E": E, "F": F, "H": H}



#==========================================
#
#    Build Reducible Representations
#
#==========================================


def block_diag_generators(blocks: list[dict[str, np.ndarray]]) -> dict[str, np.ndarray]:
    """
    Combine a list of irreducible generator sets {E,F,H} into a block-diagonal reducible set.

    Args:
        blocks: list of dicts, each with {"E", "F", "H"} generators of shape (Ki, Ki)

    Returns:
        dict with:
            "E" : (K_total, K_total) ndarray
            "F" : (K_total, K_total) ndarray
            "H" : (K_total, K_total) ndarray
    """
    def block_diag(gen_list):
        sizes = [g.shape[0] for g in gen_list]
        total = sum(sizes)
        out = np.zeros((total, total), dtype=np.float64)
        offset = 0
        for g in gen_list:
            k = g.shape[0]
            out[offset:offset+k, offset:offset+k] = g
            offset += k
        return out

    return {
        "E": block_diag([b["E"] for b in blocks]),
        "F": block_diag([b["F"] for b in blocks]),
        "H": block_diag([b["H"] for b in blocks])
    }



def _get_reducible_sl2r(K_list):
    """
    Construct reducible SL(2,R) representation from list of irreducible blocks.

    Args:
        K_list : list[int] — sizes of each irreducible block

    Returns:
        G      : ndarray (3, K_total, K_total) — stacked [E, F, H]
        meta   : dict {"blocks": K_list}
    """
    irreps = [sl2r_irrep(K) for K in K_list]  # each returns {"E", "F", "H"}
    G_dict = block_diag_generators(irreps)    # builds block-diagonal E/F/H
    G = np.stack([G_dict["E"], G_dict["F"], G_dict["H"]], axis=0)
    return G, {"blocks": K_list}
