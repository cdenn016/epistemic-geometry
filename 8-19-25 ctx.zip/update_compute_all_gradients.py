# -*- coding: utf-8 -*-
"""
Created on Tue Aug 12 20:15:47 2025

@author: chris and christine
"""
import time
from joblib import Parallel, delayed
import numpy as np
import config
from omega import d_exp_phi_exact, d_exp_phi_tilde_exact

from numerical_utils import safe_omega_inv, masked_stat        
from bundle_morphism_utils import mark_morphism_dirty

from update_terms_phi import ( 
    accumulate_phi_morphism_self_feedback, accumulate_phi_alignment_gradient,
    grad_feedback_phi_direct, grad_feedback_phi_tilde_direct, grad_self_phi_direct,
    grad_self_phi_tilde_direct)

from update_terms_mu_sigma import accumulate_mu_sigma_gradient
from preprocess_utils import zero_all_gradients
from update_crossscale_terms import accumulate_crossscale_gradients



# NEW: accept runtime_ctx and pass it through params so inner helpers can use the CacheHub
def compute_all_gradients(agent_i, agents, all_agents, generators_q, generators_p, params, runtime_ctx=None):
    """
    Role-aware gradient accumulator:
      - level 0: unchanged behavior (child intra-scale + cross-scale)
      - level 1: does intra-parent alignment + morphism + cross-scale (upward)

    Notes:
      - If runtime_ctx is provided, it's inserted into params["runtime_ctx"] so
        downstream functions can route Ω/exp/Fisher through ctx.cache.
    """
    import time
    import config

    # --- thread ctx into params (non-destructive) ---------------------------
    params = {} if params is None else dict(params)
    if runtime_ctx is not None:
        params["runtime_ctx"] = runtime_ctx  # downstream can opt-in to hub via params

    level = getattr(agent_i, "level", 0)
    is_parent = (level >= 1)

    # toggles (all default True)
    enable_intrascale_belief  = params.get("enable_intrascale_belief",  True)
    enable_intrascale_model   = params.get("enable_intrascale_model",   True)
    enable_morphism_terms     = params.get("enable_morphism_terms",     True)
    enable_crossscale         = params.get("enable_crossscale",         True)
    enable_parent_intrascale  = params.get("enable_parent_intrascale",  True)  # parents vs parents
    enable_parent_morphism    = params.get("enable_parent_morphism",    True)

    # parent update ramp/freeze can be handled in the optimizer phase; here we just build grads.

    zero_all_gradients(agent_i)
    timings = {}

    # ─── Belief μ, Σ (intra-scale) ───
    if enable_intrascale_belief and (not is_parent or enable_parent_intrascale):
        t0 = time.perf_counter()
        accumulate_mu_sigma_gradient(agent_i, agents, params, mode="belief")
        timings["mu_sigma_belief"] = time.perf_counter() - t0

    # ─── Model μ, Σ (intra-scale) ───
    if enable_intrascale_model and (not is_parent or enable_parent_intrascale):
        t0 = time.perf_counter()
        accumulate_mu_sigma_gradient(agent_i, agents, params, mode="model")
        timings["mu_sigma_model"] = time.perf_counter() - t0

    # Choose which neighbor list to use:
    same_level_neighbors = getattr(agent_i, "neighbors", [])

    # ─── Belief alignment: φᵢ vs same-level neighbors ───
    if enable_intrascale_belief and (not is_parent or enable_parent_intrascale) and same_level_neighbors:
        t0 = time.perf_counter()

        # NOTE: Q_all_* could be routed through a cache-aware wrapper later.
        Q_all_belief_i = d_exp_phi_exact(agent_i.phi, generators_q)
        exp_neg_cache_belief = {}

        for nb in same_level_neighbors:
            agent_j = agents[nb["id"]]

            exp_neg_phi_j = exp_neg_cache_belief.get(agent_j.id)
            if exp_neg_phi_j is None:
                exp_neg_phi_j = getattr(agent_j, "_exp_neg_phi", None)
                if exp_neg_phi_j is None:
                    exp_neg_phi_j = safe_omega_inv(agent_j._exp_phi, eps=config.eps, debug=False)
                exp_neg_cache_belief[agent_j.id] = exp_neg_phi_j

            # Pass through params (now contains "runtime_ctx" if provided)
            accumulate_phi_alignment_gradient(
                agent_i, agent_j, generators_q, params,
                field="phi",
                beta_key="beta",
                omega_cache_key="Omega_cache",              # legacy key still supported downstream
                mu_key="mu_q_field",
                sigma_key="sigma_q_field",
                fisher_inv_key="inverse_fisher_phi",
                grad_key="grad_phi",
                Q_all_i=Q_all_belief_i,
                exp_neg_phi_j=exp_neg_phi_j,
                agents=agents,  # existing addition
            )

        timings["phi_alignment"] = time.perf_counter() - t0

    # ─── Model alignment: φ̃ᵢ vs same-level neighbors ───
    if enable_intrascale_model and (not is_parent or enable_parent_intrascale) and same_level_neighbors:
        t0 = time.perf_counter()

        Q_all_model_i = d_exp_phi_tilde_exact(agent_i.phi_model, generators_p)
        exp_neg_cache_model = {}

        for nb in same_level_neighbors:
            agent_j = agents[nb["id"]]

            exp_neg_phi_j = exp_neg_cache_model.get(agent_j.id)
            if exp_neg_phi_j is None:
                exp_neg_phi_j = getattr(agent_j, "_exp_neg_phi_model", None)
                if exp_neg_phi_j is None:
                    exp_neg_phi_j = safe_omega_inv(agent_j._exp_phi_model, eps=config.eps, debug=False)
                exp_neg_cache_model[agent_j.id] = exp_neg_phi_j

            accumulate_phi_alignment_gradient(
                agent_i, agent_j, generators_p, params,
                field="phi_model",
                beta_key="beta_model",
                omega_cache_key="Omega_tilde_cache",        # legacy key still supported downstream
                mu_key="mu_p_field",
                sigma_key="sigma_p_field",
                fisher_inv_key="inverse_fisher_phi_model",
                grad_key="grad_phi_tilde",
                Q_all_i=Q_all_model_i,
                exp_neg_phi_j=exp_neg_phi_j,
                agents=agents,  # existing addition
            )

        timings["phi_tilde_alignment"] = time.perf_counter() - t0

    # ─── Cross-scale (child pass writes UP; parent pass runs child_only) ───
    if enable_crossscale:
        xparams = dict(params)
        xparams["xscale_child_only"] = (True if is_parent else False)
        accumulate_crossscale_gradients(agent_i, all_agents, generators_q, generators_p, xparams)

    # ─── Morphism self + feedback terms (belief/model) ───
    if enable_morphism_terms and (not is_parent or enable_parent_morphism):
        t0 = time.perf_counter()
        accumulate_phi_morphism_self_feedback(
            agent_i, generators_p, generators_q, params,
            field="phi",
            fisher_inv_key="inverse_fisher_phi",
            grad_key="grad_phi",
            phi_self_func=grad_self_phi_direct,
            phi_feedback_func=grad_feedback_phi_direct,
        )
        timings["phi_morphism"] = time.perf_counter() - t0

        t0 = time.perf_counter()
        accumulate_phi_morphism_self_feedback(
            agent_i, generators_p, generators_q, params,
            field="phi_model",
            fisher_inv_key="inverse_fisher_phi_model",
            grad_key="grad_phi_tilde",
            phi_self_func=grad_self_phi_tilde_direct,
            phi_feedback_func=grad_feedback_phi_tilde_direct,
        )
        timings["phi_tilde_morphism"] = time.perf_counter() - t0

    if getattr(config, "debug_grad_timing", False):
        print(f"\n[GRAD TIMINGS] Agent {agent_i.id} (lvl={level})")
        for k, v in timings.items():
            print(f"  {k:22s} : {v*1e3:7.2f} ms")

    return (
        (agent_i.grad_mu_q, agent_i.grad_sigma_q),
        (agent_i.grad_mu_p, agent_i.grad_sigma_p),
        agent_i.grad_phi,
        agent_i.grad_phi_tilde,
        agent_i.grad_Phi,
        agent_i.grad_Phi_tilde,
    )



# update_rules_utils.py (or wherever these live)

import numpy as np
import config
from joblib import Parallel, delayed
from numerical_utils import sanitize_sigma
# masked_stat, compute_adaptive_eta, mark_morphism_dirty assumed already imported elsewhere

def _safe_symmetrize(S):
    return 0.5 * (S + np.swapaxes(S, -1, -2))

def _clear_cache_ns(ctx, names=("exp", "omega")):
    hub = getattr(ctx, "cache", None)
    if hub is None:
        return
    for n in names:
        try:
            hub.ns(n).clear()
        except Exception:
            pass


def _apply_children(agents, grads, params, frozen_levels, frozen_phi_levels, Gq, Gp, n_jobs, *, ctx=None):
    tau_mu_belief    = params.get("tau_mu_belief",    config.tau_mu_belief)
    tau_sigma_belief = params.get("tau_sigma_belief", config.tau_sigma_belief)
    tau_mu_model     = params.get("tau_mu_model",     config.tau_mu_model)
    tau_sigma_model  = params.get("tau_sigma_model",  config.tau_sigma_model)

    (q_updates, p_updates, phi_grads, phi_m_grads, _, _) = grads
    masks = [A.mask for A in agents]

    def _one(i):
        A = agents[i]; mask = masks[i]
        dmu_q, dsg_q = q_updates[i]
        dmu_p, dsg_p = p_updates[i]
        if dmu_q is None: dmu_q = np.zeros_like(A.mu_q_field)
        if dsg_q is None: dsg_q = np.zeros_like(A.sigma_q_field)
        if dmu_p is None: dmu_p = np.zeros_like(A.mu_p_field)
        if dsg_p is None: dsg_p = np.zeros_like(A.sigma_p_field)

        mask_mu    = mask[..., None]
        mask_sigma = mask[..., None, None]

        # --- field updates (μ, Σ) ---
        if getattr(A, "level", 0) not in frozen_levels:
            A.mu_q_field = A.mu_q_field + tau_mu_belief * dmu_q * mask_mu
            A.mu_p_field = A.mu_p_field + tau_mu_model  * dmu_p * mask_mu

            # Σ: update, symmetrize, light sanitize on masked region
            Sq = A.sigma_q_field + tau_sigma_belief * dsg_q * mask_sigma
            Sp = A.sigma_p_field + tau_sigma_model  * dsg_p * mask_sigma
            A.sigma_q_field = sanitize_sigma(_safe_symmetrize(Sq), eps=getattr(config, "eps", 1e-8))
            A.sigma_p_field = sanitize_sigma(_safe_symmetrize(Sp), eps=getattr(config, "eps", 1e-8))

        # --- φ updates ---
        if getattr(A, "level", 0) not in frozen_phi_levels:
            gp  = phi_grads[i]
            gpm = phi_m_grads[i]
            gp  = np.zeros_like(A.phi)       if gp  is None else gp
            gpm = np.zeros_like(A.phi_model) if gpm is None else gpm
            apply_phi_updates(A, gp, gpm, mask, params, ctx=ctx)

            # invalidate per-agent legacy caches (central CacheHub cleared once below)
            A._exp_phi = A._exp_neg_phi = None
            A._exp_phi_model = A._exp_neg_phi_model = None
            if hasattr(A, "Omega_cache"):        A.Omega_cache.clear()
            if hasattr(A, "Omega_tilde_cache"):  A.Omega_tilde_cache.clear()

        # mark Φ/Φ̃ stale
        mark_morphism_dirty(A)

    Parallel(n_jobs=n_jobs, backend="threading", batch_size="auto")(
        delayed(_one)(i) for i in range(len(agents))
    )

    # After all children changed φ, clear central exp/omega caches once
    _clear_cache_ns(ctx, names=("exp", "omega"))


def apply_phi_updates(agent, grad_phi, grad_phi_m, mask, params, *, ctx=None):
    # capture grads for debugging/diags
    agent.grad_phi       = np.array(grad_phi,   copy=True)
    agent.grad_phi_tilde = np.array(grad_phi_m, copy=True)

    mexp = mask[..., None]

    # config pulls
    tau_phi       = params.get("tau_phi",        config.tau_phi)
    tau_phi_model = params.get("tau_phi_model",  config.tau_phi_model)
    s_eta_phi     = params.get("eta_phi_adaptive_scaling",    config.eta_phi_adaptive_scaling)
    s_eta_cond    = params.get("eta_sigma_condition_scaling", config.eta_sigma_condition_scaling)
    eta_phi_min   = params.get("eta_phi_min",                 config.eta_phi_min)
    eta_phi_m_min = params.get("eta_phi_model_min",           config.eta_phi_model_min)

    # robust, masked KL scalars (if present)
    kl_q = masked_stat(getattr(agent, "cached_alignment_kl", None), mask, default=0.0)
    kl_p = masked_stat(getattr(agent, "cached_model_alignment_kl", None), mask, default=0.0)

    # condition proxies (from preprocess)
    cond_q = getattr(agent, "_cond_proxy_q", 1.0)
    cond_p = getattr(agent, "_cond_proxy_p", 1.0)

    # EMA memory
    ema_a          = getattr(config, "eta_ema_alpha", None)
    prev_eta_phi   = getattr(agent, "_eta_phi_prev", None)
    prev_eta_phi_m = getattr(agent, "_eta_phi_m_prev", None)

    # adaptive step sizes
    eta_phi = compute_adaptive_eta(
        tau_phi, kl_q, cond_q, grad=grad_phi,
        scaling_kl=s_eta_phi, scaling_cond=s_eta_cond,
        eta_min=eta_phi_min, ema_prev=prev_eta_phi, ema_alpha=ema_a
    )
    eta_phi_m = compute_adaptive_eta(
        tau_phi_model, kl_p, cond_p, grad=grad_phi_m,
        scaling_kl=params.get("eta_phi_model_adaptive_scaling", s_eta_phi),
        scaling_cond=s_eta_cond, eta_min=eta_phi_m_min,
        ema_prev=prev_eta_phi_m, ema_alpha=ema_a
    )

    delta_phi   = np.nan_to_num(eta_phi   * grad_phi,   nan=0.0, posinf=0.0, neginf=0.0)
    delta_phi_m = np.nan_to_num(eta_phi_m * grad_phi_m, nan=0.0, posinf=0.0, neginf=0.0)

    # IMPORTANT: avoid in-place writes to change array identity,
    # so CacheHub's pointer-keyed exp cache won't return stale results.
    agent.phi       = (agent.phi       - delta_phi   * mexp).astype(np.float32, copy=False)
    agent.phi_model = (agent.phi_model + delta_phi_m * mexp).astype(np.float32, copy=False)

    agent._eta_phi_prev   = eta_phi
    agent._eta_phi_m_prev = eta_phi_m








def _apply_parent_updates(parents, step, params, *, ctx=None):
    """
    Apply parent μ/Σ and φ/φ̃ updates with ramping; invalidate central caches
    when gauge fields change; and mark objects dirty for downstream rebuilds.
    """
    freeze = int(params.get("parent_freeze_steps", 0))
    ramp   = max(1, int(params.get("parent_ramp_steps", 1)))
    if step < freeze:
        return
    s = min(1.0, (step - freeze + 1) / ramp)

    tau_mu_belief    = params.get("tau_mu_belief",    0.0)
    tau_sigma_belief = params.get("tau_sigma_belief", 0.0)
    tau_mu_model     = params.get("tau_mu_model",     0.0)
    tau_sigma_model  = params.get("tau_sigma_model",  0.0)

    # small helper: nuke central transport namespaces (exp/omega)
    def _bust_ctx_transport_cache(_ctx):
        hub = getattr(_ctx, "cache", None)
        if hub is None:
            return
        try: hub.ns("exp").clear()
        except Exception: pass
        try: hub.ns("omega").clear()
        except Exception: pass

    for P in parents:
        pmask = np.asarray(getattr(P, "mask", 0.0), dtype=np.float32)
        mask_mu    = pmask[..., None]
        mask_sigma = pmask[..., None, None]

        # q-bundle
        if getattr(P, "grad_mu_q", None) is not None:
            P.mu_q_field   += s * tau_mu_belief * P.grad_mu_q * mask_mu
        if getattr(P, "grad_sigma_q", None) is not None:
            P.sigma_q_field = P.sigma_q_field + s * tau_sigma_belief * P.grad_sigma_q * mask_sigma

        # p-bundle
        if getattr(P, "grad_mu_p", None) is not None:
            P.mu_p_field   += s * tau_mu_model * P.grad_mu_p * mask_mu
        if getattr(P, "grad_sigma_p", None) is not None:
            P.sigma_p_field = P.sigma_p_field + s * tau_sigma_model * P.grad_sigma_p * mask_sigma

        # φ / φ̃ updates, then invalidate caches coherently
        if getattr(P, "grad_phi", None) is not None or getattr(P, "grad_phi_tilde", None) is not None:
            apply_phi_updates(
                P,
                getattr(P, "grad_phi", None),
                getattr(P, "grad_phi_tilde", None),
                pmask,
                params,
            )

            # Legacy per-agent caches (keep for compatibility)
            P._exp_phi = P._exp_neg_phi = None
            P._exp_phi_model = P._exp_neg_phi_model = None
            if hasattr(P, "Omega_cache"):       P.Omega_cache.clear()
            if hasattr(P, "Omega_tilde_cache"): P.Omega_tilde_cache.clear()

            # Central caches (VERY IMPORTANT since φ updated in-place)
            if ctx is not None:
                _bust_ctx_transport_cache(ctx)

            # mark dirty so downstream phases rebuild Λ / Φ
            try:
                from update_rules_utils import mark_dirty
                mark_dirty(ctx, P, kl=True) if ctx is not None else None
            except Exception:
                # best-effort: set a flag others can check
                setattr(P, "morphisms_dirty", True)












def _parent_intrascale_grad_pass(agents, parents, Gq, Gp, params, accum_into=True, *, ctx=None):
    if not parents:
        return
    params_par = dict(params)
    params_par["enable_crossscale"] = False  # keep x-scale grads from child pass intact
    all_agents_par = agents + parents
    parents_by_id = {int(getattr(p, "id", i)): p for i, p in enumerate(parents)}

    def _safe_add(a, b):
        if a is None: return b
        if b is None: return a
        return a + b

    results = Parallel(n_jobs=config.n_jobs, backend="threading", batch_size="auto")(
        delayed(compute_all_gradients)(P, parents_by_id, all_agents_par, Gq, Gp, params_par)
        for P in parents
    )

    for P, res in zip(parents, results):
        (dmuq, dsgq), (dmup, dsgp), gphi, gphit, *_ = res

        # ensure grad slots exist
        if not hasattr(P, "grad_mu_q"):      P.grad_mu_q = None
        if not hasattr(P, "grad_sigma_q"):   P.grad_sigma_q = None
        if not hasattr(P, "grad_mu_p"):      P.grad_mu_p = None
        if not hasattr(P, "grad_sigma_p"):   P.grad_sigma_p = None
        if not hasattr(P, "grad_phi") or P.grad_phi is None:
            P.grad_phi = (np.zeros_like(P.phi, dtype=np.float32)
                          if getattr(P, "phi", None) is not None else None)
        if not hasattr(P, "grad_phi_tilde") or P.grad_phi_tilde is None:
            P.grad_phi_tilde = (np.zeros_like(P.phi_model, dtype=np.float32)
                                if getattr(P, "phi_model", None) is not None else None)

        # accumulate or overwrite
        if accum_into:
            P.grad_mu_q      = _safe_add(P.grad_mu_q,    dmuq)
            P.grad_sigma_q   = _safe_add(P.grad_sigma_q, dsgq)
            P.grad_mu_p      = _safe_add(P.grad_mu_p,    dmup)
            P.grad_sigma_p   = _safe_add(P.grad_sigma_p, dsgp)
            if gphi  is not None and P.grad_phi is not None:
                P.grad_phi       = P.grad_phi       + gphi
            if gphit is not None and P.grad_phi_tilde is not None:
                P.grad_phi_tilde = P.grad_phi_tilde + gphit
        else:
            P.grad_mu_q, P.grad_sigma_q = dmuq, dsgq
            P.grad_mu_p, P.grad_sigma_p = dmup, dsgp
            if gphi is not None:
                if P.grad_phi is None and getattr(P, "phi", None) is not None:
                    P.grad_phi = np.zeros_like(P.phi, dtype=np.float32)
                if P.grad_phi is not None:
                    P.grad_phi[...] = gphi
            if gphit is not None:
                if P.grad_phi_tilde is None and getattr(P, "phi_model", None) is not None:
                    P.grad_phi_tilde = np.zeros_like(P.phi_model, dtype=np.float32)
                if P.grad_phi_tilde is not None:
                    P.grad_phi_tilde[...] = gphit





def _compute_child_grads(agents, all_agents, Gq, Gp, params):
    params_x = dict(params or {})
    params_x["xscale_child_only"] = False  # allow x-scale to write into parents' grad buffers
    
    results = Parallel(n_jobs=config.n_jobs, backend="threading", batch_size="auto")(
        delayed(compute_all_gradients)(Ai, agents, all_agents, Gq, Gp, params_x)
        for Ai in agents
    )
    q_updates, p_updates, phi_grads, phi_m_grads, morphism_grads, morphism_tilde_grads = zip(*results)
    return (q_updates, p_updates, phi_grads, phi_m_grads, morphism_grads, morphism_tilde_grads)


def compute_adaptive_eta(base_eta, kl_scalar, cond_scalar,
                         grad=None, scaling_kl=1.0, scaling_cond=1.0,
                         eta_min=0.0, ema_prev=None, ema_alpha=None):
    """
    Returns η in [eta_min, base_eta]. Robust to array/None/object inputs.
    - kl_scalar: if bad → falls back to mean |grad| (or 0)
    - cond_scalar: if bad → 1.0
    """
    def _to_scalar(x, default):
        try:
            a = np.asarray(x, dtype=float)
            v = float(a) if a.ndim == 0 else float(np.nanmedian(a))
            if not np.isfinite(v):
                return float(default)
            return v
        except Exception:
            return float(default)

    # KL term (fallback to grad norm if needed)
    default_kl = float(np.mean(np.abs(grad))) if grad is not None else 0.0
    kl_term = _to_scalar(kl_scalar, default_kl)

    # Condition term (fallback to 1.0)
    cond_term = _to_scalar(cond_scalar, 1.0)

    denom = 1.0 + scaling_kl * kl_term + scaling_cond * cond_term
    eta = np.clip(base_eta / denom, eta_min, base_eta)

    if ema_prev is not None and ema_alpha is not None and 0.0 < ema_alpha < 1.0:
        eta = ema_alpha * eta + (1.0 - ema_alpha) * ema_prev
    return eta



def _final_apply_parents(ctx, params):
    parents = list(ctx.parents_by_region.values())
    if parents:
        _apply_parent_updates(parents, getattr(ctx, "global_step", 0), params)





