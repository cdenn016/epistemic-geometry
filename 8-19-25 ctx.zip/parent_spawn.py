# -*- coding: utf-8 -*-
"""
Created on Thu Aug 14 09:17:47 2025

@author: chris and christine
"""

import numpy as np
import config                        
from bundle_morphism_utils import (init_parent_morphisms, have_parent_morphisms, compute_direct_morphisms)
from agent_initialization import initialize_agent_gradients
from parent_utils import (norm_active_regions, dedup_peaks_by_childset, spawn_spacing_radius )
from gaussian_core import ( _overlap_pairs, directed_kl_weight_after_transport,apply_evidence_modulators,
    curvature_boltzmann_from_children )

from joblib import Parallel, delayed
import hashlib

from bundle_coarsegrain_init import coarsegrain_parent_from_children

from parent_utils import (
    prepare_parent_match_state, append_center_from_mask,
    centroid_toroidal, dist2_toroidal, jaccard_sets,
    match_score_for_parent, respect_spawn_spacing,
)
import os

# --- parent_utils.py (additions) ---------------------------------------------
import numpy as _np
import hashlib as _hashlib


from parent_utils import conservative_child_set_from_seed
from parent_utils import gate_and_seed_proposal
from parent_utils import novelty_gate_ok


from update_rules_utils import build_all_omega_caches



import time

class PhaseTimer:
    """Context-manager timer that aggregates per-phase wall time on runtime_ctx."""
    def __init__(self, ctx):
        self.ctx = ctx
        if not hasattr(ctx, "timings") or getattr(ctx, "timings") is None:
            ctx.timings = {}

    def __call__(self, name: str):
        ctx = self.ctx
        class _T:
            def __enter__(_s):
                _s.t0 = time.perf_counter()
                return _s
            def __exit__(_s, *_):
                dt = time.perf_counter() - _s.t0
                ctx.timings[name] = ctx.timings.get(name, 0.0) + dt
        return _T()

def bump_counter(ctx, key: str, inc: int = 1):
    """Optional: simple per-step counters."""
    if not hasattr(ctx, "counters") or getattr(ctx, "counters") is None:
        ctx.counters = {}
    ctx.counters[key] = ctx.counters.get(key, 0) + inc




# --- helper worker (place near other small helpers) ---




def _apply_spawn_from_regions(ctx, active_regions, agents, Gq, Gp, params):
    """
    Mutates parents:
      - spawn/update parents for active regions (PIXELWISE proposals path)
      - coarse-grain μ,Σ only for **stable** (pre-existing) parents that actually need it
    """
    

    T = PhaseTimer(ctx)
    if not agents:
        return []

    # init + stable snapshot
    with T("spawn_init"):
        existing, next_parent_id, prev_ids, H, W = ensure_parent_registry(ctx, agents)

    # prefilter
    with T("spawn_prefilter_setup"):
        regions_to_spawn = list(active_regions or [])
        bump_counter(ctx, "spawn_regions_in", len(regions_to_spawn))

        cover2 = None
        try:
            with T("spawn_cover2"):
                cover2 = compute_cover2_map(agents, float(getattr(config, "child_support_tau", 0.08)))
        except Exception:
            cover2 = None

        spawn_min_cover2_px = int(getattr(config, "spawn_min_cover2_px", 2))
        spawn_nms_iou       = float(getattr(config, "spawn_nms_iou", 0.25))
        spawn_min_dist_px   = float(getattr(config, "spawn_min_dist_px", 2.0))
        abs_core            = float(getattr(config, "parent_growth_core_tau", 0.20))
        rel_core            = float(getattr(config, "parent_assign_core_tau_rel", 0.50))

        with T("spawn_existing_cores"):
            existing_cores, existing_centroids = existing_cores_and_centroids(existing, abs_core, rel_core)

    with T("spawn_filter_loop"):
        kept = filter_spawn_regions(
            regions_to_spawn, cover2, spawn_min_cover2_px,
            existing_cores, existing_centroids, spawn_nms_iou, spawn_min_dist_px
        )
        bump_counter(ctx, "spawn_regions_kept", len(kept))
        bump_counter(ctx, "spawn_regions_reject_evidence",
                     int(len(regions_to_spawn) - len(kept)) if cover2 is not None else 0)

    # spawn/update (ctx-aware)
    with T("spawn_call_spawn_or_update"):
        parents_changed, next_pid = spawn_or_update_parents(
            kept,
            agents,
            existing,
            next_parent_id,
            field_generators=(Gq, Gp),
            agree_map=(getattr(ctx, "Aq_agg", None), getattr(ctx, "Ap_agg", None)),
            ctx=ctx,  # <<< pass runtime context to enable CacheHub usage downstream
        )

    # registry merge + bookkeeping
    with T("spawn_registry_merge"):
        parents_changed, step_now = merge_parents_into_registry(ctx, parents_changed)

    # CG only on stable parents that need it
    with T("spawn_cg_changed"):
        min_core_px = int(getattr(config, "cg_min_core_px", 3))
        cg_tau      = float(getattr(config, "parent_cover_support_eps", 0.30))
        items_all, cg_items = select_cg_targets_stable(
            parents_changed, prev_ids,
            step_now=step_now, abs_core=abs_core, rel_core=rel_core,
            min_core_px=min_core_px, mask_tau=cg_tau
        )

        bump_counter(ctx, "spawn_cg_candidates", len(items_all))
        bump_counter(ctx, "spawn_cg_targets",    len(cg_items))
        bump_counter(ctx, "spawn_cg_skipped",    max(0, len(items_all) - len(cg_items)))
        bump_counter(ctx, "spawn_cg_stable_only", len(items_all))

        if not cg_items:
            bump_counter(ctx, "spawn_cg_ok", 0)
            bump_counter(ctx, "spawn_cg_fail", 0)
            return list(existing.values())

        # backend knobs
        _cfg_backend = str(getattr(config, "cg_backend", "threading")).lower()
        if _cfg_backend in ("threads", "threading"):
            backend, prefer = "threading", "threads"
        elif _cfg_backend in ("process", "processes", "loky", "multiprocessing"):
            backend, prefer = "loky", "processes"
        elif _cfg_backend in ("seq", "sequential"):
            backend, prefer = "sequential", None
        else:
            backend, prefer = "threading", "threads"

        n_jobs       = int(getattr(config, "cg_n_jobs", -1))
        batch_size   = getattr(config, "cg_batch_size", "auto")
        omp_thr      = int(getattr(config, "cg_omp_threads", 1))
        cg_eps       = float(getattr(config, "cg_eps", 1e-6))
        auto_seq_cut = int(getattr(config, "cg_auto_seq_cutoff", 2))
        if len(cg_items) <= auto_seq_cut:
            backend, prefer = "sequential", None

        cg_ok, cg_fail = run_cg_for_parents(
            ctx, cg_items, agents, Gq, Gp,
            eps=cg_eps, mask_tau=cg_tau, backend=backend,
            n_jobs=n_jobs, batch_size=batch_size, prefer=prefer, omp_thr=omp_thr
        )
        bump_counter(ctx, "spawn_cg_ok", cg_ok)
        bump_counter(ctx, "spawn_cg_fail", cg_fail)

    return list(existing.values())







def spawn_or_update_parents(active_regions,
                            agents,
                            parents_by_id,
                            next_parent_id,
                            *,
                            field_generators,
                            agree_map=None,
                            ctx=None):   # ← accept ctx
    """
    Build pixelwise proposals (dual-fiber, directed-KL only), restrict to active regions,
    dedup, then match/spawn. Returns (list(parents_by_id.values()), next_parent_id).
    """
    

    if not agents:
        return list(parents_by_id.values()), next_parent_id

    H, W = np.asarray(agents[0].mask, np.float32).shape[:2]
    dtype = agents[0].mu_q_field.dtype
    Kq   = int(agents[0].mu_q_field.shape[-1])
    Kp   = int(agents[0].mu_p_field.shape[-1])
    Gq, Gp = field_generators

    # --- normalize detector regions → union mask to restrict spawn area -----
    region_masks = norm_active_regions(active_regions, (H, W))
    region_or = None
    if region_masks:
        region_or = np.zeros((H, W), np.float32)
        for R in region_masks:
            region_or = np.maximum(region_or, np.asarray(R, np.float32))
        region_or = (region_or > 0.5)

    # --- parse agree_map and combine Aq/Ap with geometric blend -------------
    Aq = Ap = None
    if agree_map is not None:
        if isinstance(agree_map, (tuple, list)) and len(agree_map) >= 1:
            Aq = agree_map[0]
            if len(agree_map) >= 2:
                Ap = agree_map[1]
        elif isinstance(agree_map, dict):
            Aq = agree_map.get("q")
            Ap = agree_map.get("p")
        else:
            Aq = agree_map

    alpha = float(getattr(config, "blend_qp_alpha", 0.50))
    A = None
    if (Aq is not None) or (Ap is not None):
        def _prep_A(a, H, W):
            if a is None: return None
            a = np.asarray(a, np.float32)
            if a.shape != (H, W):
                if a.shape[0] >= H and a.shape[1] >= W:
                    a = a[:H, :W]
                else:
                    py, px = max(0, H - a.shape[0]), max(0, W - a.shape[1])
                    a = np.pad(a, ((0, py), (0, px)), mode="edge")[:H, :W]
            return np.clip(a, 0.0, 1.0).astype(np.float32, copy=False)

        Aq_ = _prep_A(Aq, H, W) if Aq is not None else None
        Ap_ = _prep_A(Ap, H, W) if Ap is not None else None
        if (Aq_ is not None) and (Ap_ is not None):
            eps = 1e-12
            A = np.exp((1.0 - alpha) * np.log(np.maximum(Aq_, eps)) +
                       alpha * np.log(np.maximum(Ap_, eps)))
        else:
            A = Aq_ if Aq_ is not None else Ap_

    # --- ensure child→child Ω caches exist (cheap; uses exp(φ) fields) ------
    try:
        from update_rules_utils import build_all_omega_caches
        build_all_omega_caches(agents, strict=False, debug=False)
    except Exception:
        pass

        # --- dual-fiber, directed-KL proposals (cache-friendly path) ------------
    kwargs = dict(
        mask_tau=float(getattr(config, "child_support_tau", 0.10)),
        tau_q=float(getattr(config, "tau_align_q", 0.30)),
        tau_p=float(getattr(config, "tau_align_p", 0.30)),
        alpha=alpha,
        min_pair_px=int(getattr(config, "pxspawn_min_pair_px", 4)),
        agree_map=A,
        agree_power=float(getattr(config, "pxspawn_agree_power", 1.0)),
        min_component_px=int(getattr(config, "parent_min_area", 10)),
        smooth_sigma=float(getattr(config, "pxspawn_smooth_sigma", 0.0)),
        per_pixel_norm=bool(getattr(config, "pxspawn_per_pixel_norm", False)),
        debug=bool(getattr(config, "debug_spawn_log", False)),
        use_cached_omega=True,
        domain_mask=region_or,
    )
    try:
        # NEW: ctx-first signature
        proposals = proposals_from_dual_fibers(ctx, agents, H, W, **kwargs)
    except TypeError:
        # Fallback for older signature (no ctx, no domain/cache hints)
        kwargs.pop("use_cached_omega", None)
        kwargs.pop("domain_mask", None)
        proposals = proposals_from_dual_fibers(agents, H, W, **kwargs)


    if region_or is not None and proposals:
        rim = region_or.astype(np.float32)
        for p in proposals:
            p["mask"] = np.clip(np.asarray(p["mask"], np.float32) * rim, 0.0, 1.0)

    if proposals:
        try:
            proposals = dedup_peaks_by_childset(
                proposals,
                radius_px=int(getattr(config, "parent_peak_dedup_radius_px", 3)),
                j_thr=float(getattr(config, "parent_peak_dedup_child_jaccard", 0.92)),
                subset_thr=float(getattr(config, "parent_peak_dedup_subset_thr", 0.90)),
                H=H, W=W,
                per_x=bool(getattr(config, "periodic_x", False)),
                per_y=bool(getattr(config, "periodic_y", False)),
            )
        except Exception:
            pass

    if not proposals and not parents_by_id:
        return list(parents_by_id.values()), next_parent_id

    peaks = []
    for p in (proposals or []):
        q = dict(p)
        if "proposal" not in q and "mask" in q:
            q["proposal"] = np.asarray(q["mask"], np.float32)
        peaks.append(q)

    # --- match or spawn (PASS ctx AS KEYWORD) --------------------------------
    min_interseed_px = spawn_spacing_radius(
        True, int(getattr(config, "parent_min_interseed_px", 1))
    )
    next_parent_id = _match_or_spawn(
        peaks, parents_by_id, next_parent_id, agents,
        (H, W, dtype, Kq, Kp), field_generators,
        match_iou_thr=float(getattr(config, "parent_match_iou_existing", 0.10)),
        child_jac_thr=float(getattr(config, "parent_match_child_jaccard_thr", 0.85)),
        support_tau=float(getattr(config, "parent_support_tau", 0.08)),
        max_new_per_step=int(getattr(config, "parent_max_new_per_step", 50)),
        min_interseed_px=min_interseed_px,
        ctx=ctx,  # ← fix: kw-only arg
    )

    for P in parents_by_id.values():
        if not have_parent_morphisms(P):
            init_parent_morphisms(P, generators_q=Gq, generators_p=Gp)

    return list(parents_by_id.values()), next_parent_id




def proposals_from_dual_fibers(
    ctx,
    children,
    H,
    W,
    *,
    mask_tau=0.10,
    tau_q=0.30,
    tau_p=0.30,
    alpha=0.5,
    min_pair_px=8,
    agree_map=None,
    agree_power=1.0,
    min_component_px=20,
    smooth_sigma=0.0,
    per_pixel_norm=False,
    debug=False,
    # cache policy / domain
    use_cached_omega=True,
    domain_mask=None,
):
    """
    Gauge-covariant proposals using ONLY directed KL after transport:
      d_q = KL( N_i(q) || T_{j->i}(N_j) ),  d_p = KL( N_i(p) || T_{j->i}(N_j) )
      w   = exp(-d_q/tau_q)^(1-alpha) * exp(-d_p/tau_p)^alpha
      E(x)= Σ_{(i,j)} m_i m_j  w  1_{overlap}

    Notes
    -----
    - Uses ctx-aware transport/KL via directed_kl_weight_after_transport(..., ctx=ctx).
    - Ω/exp caching is handled inside that helper (CacheHub first, then agent caches).
    - Pair enumeration & modulators come from parent_utils helpers.
    """
    import numpy as _np
    import config as _cfg

    if not children:
        return []

    # --- pull helpers (attached files) --------------------------------------
    
    try:
        # optional smoothing
        from scipy.ndimage import gaussian_filter as _gauss_filter
    except Exception:
        _gauss_filter = None

    from numerical_utils import resize_nn

    # --- quick fields & sizes ------------------------------------------------
    M   = [_np.asarray(getattr(c, "mask", 0.0), _np.float32) for c in children]
    muq = [_np.asarray(c.mu_q_field, _np.float32) for c in children]
    Sq  = [_np.asarray(c.sigma_q_field, _np.float32) for c in children]
    mup = [_np.asarray(c.mu_p_field, _np.float32) for c in children]
    Sp  = [_np.asarray(c.sigma_p_field, _np.float32) for c in children]
    Kq  = int(muq[0].shape[-1])
    Kp  = int(mup[0].shape[-1])

    # --- candidate pairs by overlap -----------------------------------------
    pairs = _overlap_pairs(children, H, W, tau=float(mask_tau), min_pair_px=int(min_pair_px))
    if not pairs:
        return []

    # --- agreement / curvature priors ---------------------------------------
    def _prep_A(A):
        if A is None:
            return None
        A = _np.asarray(A, _np.float32)
        if A.shape[:2] != (H, W):
            try:
                A = resize_nn(A, (H, W)).astype(_np.float32)
            except Exception:
                return None
        return _np.clip(A, 0.0, 1.0)

    A  = _prep_A(agree_map)
    BF = curvature_boltzmann_from_children(
        children, H, W,
        gamma=float(getattr(_cfg, "curvature_gamma", 0.0)),
        fiber=str(getattr(_cfg, "curvature_fiber", "q")),
        curvature_map=getattr(_cfg, "curvature_map", None) if hasattr(_cfg, "curvature_map") else None,
    )

    # --- domain: detector mask ∧ (cover ≥ 2) --------------------------------
    cover2 = _np.zeros((H, W), _np.int16)
    for m in M:
        cover2 += (m >= float(mask_tau)).astype(_np.int16)
    D = (cover2 >= 2)
    if domain_mask is not None:
        D = D & _np.asarray(domain_mask, bool)

    E = _np.zeros((H, W), _np.float32)
    pair_contribs = []

    t_q = max(1e-6, float(tau_q))
    t_p = max(1e-6, float(tau_p))
    a   = float(alpha)

    # --- main pair loop: ctx-aware KL weights after transport ----------------
    for (i, j, ov_raw) in pairs:
        if not ov_raw.any():
            continue
        Ai, Aj = children[i], children[j]
        ov = (ov_raw & D)
        if not ov.any():
            continue

        # These call the helper that uses CacheHub/ctx internally (Ω/exp grids)
        wq = directed_kl_weight_after_transport(
            Ai, Aj, muq[i], Sq[i], muq[j], Sq[j],
            fiber="q", H=H, W=W, K=Kq, ov=ov, tau=t_q,
            use_cached_omega=use_cached_omega,
            ctx=ctx,                                        # <-- new
        )
        wp = directed_kl_weight_after_transport(
            Ai, Aj, mup[i], Sp[i], mup[j], Sp[j],
            fiber="p", H=H, W=W, K=Kp, ov=ov, tau=t_p,
            use_cached_omega=use_cached_omega,
            ctx=ctx,                                        # <-- new
        )

        w = (wq ** (1.0 - a)) * (wp ** a)
        w = _np.nan_to_num(w, nan=0.0, posinf=0.0, neginf=0.0)
        w *= ov.astype(_np.float32)

        # evidence modulators (agreement prior & curvature); respects support
        wij = apply_evidence_modulators(
            w, M[i], M[j], ov, A=A, agree_power=agree_power, BF=BF
        )
        if float(wij.max()) <= 0.0:
            continue

        E += wij
        pair_contribs.append((i, j, wij))

    # enforce domain & early exit
    E *= D.astype(_np.float32)
    if float(E.max()) <= 0.0:
        return []

    # --- components on adaptive threshold -----------------------------------
    # (use 20th percentile of positive mass; robust on heavy tails)
    pos = E[E > 0.0]
    thr = float(_np.quantile(pos, 0.20)) if pos.size else 0.0
    B = (E > thr).astype(_np.uint8)

    comp_ids, n_comp = cc_label(B)  # parent_utils.cc_label handles (H,W)->(labels, n)

    proposals = []
    for cid in range(1, int(n_comp) + 1):
        comp = (comp_ids == cid)
        area = int(comp.sum())
        if area < int(min_component_px):
            continue

        m = (E * comp.astype(_np.float32))
        mmax = float(m.max())
        if mmax > 0.0:
            m = (m / mmax).astype(_np.float32)

        if smooth_sigma and _gauss_filter is not None:
            m = _gauss_filter(m, sigma=float(smooth_sigma)).astype(_np.float32)
            m = _np.clip(m, 0.0, 1.0)

        ys, xs = _np.nonzero(comp)
        cy = float(ys.mean()) if ys.size else 0.0
        cx = float(xs.mean()) if xs.size else 0.0

        # child weights from pair contributions over this component
        weights = {}
        for (ii, jj, wij) in pair_contribs:
            wloc = float(wij[comp].sum())
            if wloc <= 0.0:
                continue
            ci = int(getattr(children[ii], "id", ii))
            cj = int(getattr(children[jj], "id", jj))
            weights[ci] = weights.get(ci, 0.0) + wloc
            weights[cj] = weights.get(cj, 0.0) + wloc
        totw = sum(weights.values()) or 1.0
        weights = {int(k): float(v / totw) for k, v in weights.items()}

        proposals.append({
            "cy": cy, "cx": cx,
            "mask": m,
            "child_ids": tuple(sorted(weights.keys())),
            "child_weights": weights,
            "score": float(E[comp].sum()) / max(1.0, area),
        })

    # optional per-pixel normalization across proposals
    if per_pixel_norm and proposals:
        stack = _np.stack([p["mask"] for p in proposals], axis=0)
        denom = _np.maximum(1e-6, stack.sum(axis=0))
        for p in proposals:
            p["mask"] = (p["mask"] / denom).astype(_np.float32)

    if debug:
        print(f"[PX-SPAWN/DKL] proposals={len(proposals)} comps={int(n_comp)} "
              f"Emax={E.max():.3f} alpha={a} gamma={float(getattr(_cfg,'curvature_gamma',0.0))}")
        for p in sorted(proposals, key=lambda d: -d.get('score', 0.0))[:min(8, len(proposals))]:
            print(f"  - kids={tuple(sorted(p.get('child_ids', ())))} "
                  f"area={(p['mask']>0.01).sum()} peak={float(p['mask'].max()):.3f} score={p['score']:.4f}")

    return proposals



# ----------------------------- refactor entry -----------------------------
def _match_or_spawn(
    peaks,
    parents_by_id,
    next_parent_id,
    agents,
    shape_info,
    generators,
    *,
    match_iou_thr,
    child_jac_thr,
    support_tau,
    max_new_per_step,
    min_interseed_px,
    ctx=None,  # optional runtime_ctx
):
    """
    Match proposals to existing parents or spawn new ones.
    Thread-safe w.r.t. ctx (for CacheHub-backed spawns).
    """

    # runtime context
    _RC = ctx if ctx is not None else globals().get("runtime_ctx", None)
    step_now = int(getattr(_RC, "global_step", 0)) if _RC is not None else 0

    # shapes, generators, periodicity
    H, W, dtype, Kq, Kp = shape_info
    Gq, Gp = generators
    per_x = bool(getattr(config, "periodic_x", True))
    per_y = bool(getattr(config, "periodic_y", True))

    # existing parent state
    exists_support, exists_kids = prepare_parent_match_state(parents_by_id, support_tau)

    # start chosen-centers with existing parents
    chosen_centers = []
    for pid, supp in exists_support.items():
        append_center_from_mask(chosen_centers, supp, pid, H, W, per_x=per_x, per_y=per_y)

    # thresholds / knobs
    local_tau      = float(getattr(config, "parent_proposal_local_tau", 0.01))
    min_local_px   = int(getattr(config, "parent_min_seed_area_px", 1))
    mask_tau_child = float(getattr(config, "detector_mask_tau", 1e-3))
    min_overlap_px = int(getattr(config, "parent_assign_min_overlap_px", 8))
    min_seed_px    = int(getattr(config, "parent_min_seed_px", max(4, min_overlap_px // 2)))

    keep_thr_cont  = float(getattr(config, "parent_continuity_child_jacc_keep_thr", 0.60))
    replace_thr    = float(getattr(config, "parent_match_childset_replace_thr", 0.75))
    weight_ema     = float(getattr(config, "parent_child_weight_ema", 0.20))

    min_novel_px   = int(getattr(config, "parent_min_novel_seed_px", 6))
    min_novel_frac = float(getattr(config, "parent_min_novel_seed_frac", 0.20))

    # counters
    updated = spawned = 0
    dropped_local = dropped_spacing = dropped_budget = 0
    dropped_childov = dropped_seed = 0

    new_spawned = 0
    # highest-score-first
    for peak in sorted(peaks or [], key=lambda d: -float(d.get("score", 0.0))):
        if new_spawned >= int(max_new_per_step):
            dropped_budget += 1
            break

        prop = peak.get("proposal", peak.get("mask"))
        cy = float(peak.get("cy", 0.0)); cx = float(peak.get("cx", 0.0))

        # 1) gate + seed
        gated, reason = seed_proposal_or_skip(
            peak, H=H, W=W, agents=agents, local_tau=local_tau, min_local_px=min_local_px,
            mask_tau_child=mask_tau_child, support_tau=support_tau, min_seed_px=min_seed_px
        )
        if gated is None:
            if reason == "local": dropped_local += 1
            else:                 dropped_seed  += 1
            continue
        prop, seed_bool, seed_px = gated

        # 2) novelty
        ok, novel_px, novel_frac = novelty_or_skip(
            seed_bool, exists_support=exists_support, H=H, W=W,
            min_novel_px=min_novel_px, min_novel_frac=min_novel_frac
        )
        if not ok:
            if bool(getattr(config, "debug_spawn_log_details", True)):
                print(f"  -> DROP (not novel) novel_px={novel_px} "
                      f"seed_px={seed_px} frac={novel_frac:.2f} "
                      f"min_px={min_novel_px} min_frac={min_novel_frac}")
            dropped_spacing += 1
            continue

        # 3) continuity rescue (attach to nearby prior parent if consistent)
        cont_r2      = float(getattr(config, "parent_continuity_radius_px", max(1, min_interseed_px))) ** 2
        cont_iou_thr = float(getattr(config, "parent_continuity_iou_thr", 0.15))
        cont_pid = continuity_try_rescue(
            cy, cx, seed_bool, exists_support=exists_support, H=H, W=W,
            per_x=per_x, per_y=per_y, cont_r2=cont_r2, cont_iou_thr=cont_iou_thr
        )
        if cont_pid is not None:
            P = parents_by_id[int(cont_pid)]
            supp = apply_mask_and_centroid(
                P, prop, dtype=dtype, support_tau=support_tau, H=H, W=W,
                chosen_centers=chosen_centers, pid=cont_pid,
                per_x=per_x, per_y=per_y, fallback_cyx=(cy, cx)
            )
            # keep/refresh child weights conservatively
            cw = peak.get("child_weights", None)
            if isinstance(cw, dict) and cw:
                old = set(getattr(P, "child_ids", ()))
                new = set(int(k) for k in cw.keys())
                try:
                    j = jaccard_sets(old, new) if old else 1.0
                except Exception:
                    j = 1.0 if not old else 0.0
                if j >= keep_thr_cont:
                    P.child_weights = {int(k): float(v) for k, v in cw.items()}
                    P.child_ids = tuple(sorted(P.child_weights.keys()))
            P._region_proposal = prop
            exists_support[cont_pid] = (P.mask > support_tau)
            updated += 1
            if bool(getattr(config, "debug_spawn_log_details", True)):
                print(f"  -> CONT-MATCH pid={cont_pid} seed_px={seed_px}")
            continue

        # 4) conservative kid set
        gkids_seed = conservative_child_set(
            agents, seed_bool, mask_tau_child=mask_tau_child, min_overlap_px=min_overlap_px
        )
        gkids_peak = set(peak.get("child_ids", ()))
        gkids = gkids_seed if not gkids_peak else (gkids_seed & gkids_peak)
        if len(gkids) < 2:
            if bool(getattr(config, "debug_spawn_log_details", True)):
                print(f"  -> DROP (child overlap) |kids|={len(gkids)} < 2 (ov_px≥{min_overlap_px})")
            dropped_childov += 1
            continue

        # 5) MATCH existing (nearby radius + joint score: IoU × child-Jaccard)
        R2 = float(max(1, min_interseed_px)) ** 2
        best_pid, best_sc = None, (-1.0, -1.0)
        for pid, supp in exists_support.items():
            cy0, cx0 = centroid_toroidal(supp, H, W, per_y=per_y, per_x=per_x)
            close = (dist2_toroidal(cy, cx, cy0, cx0, H, W, per_y, per_x) <= R2)
            sc = match_score_for_parent(seed_bool, gkids, supp, exists_kids[pid],
                                        close=close,
                                        match_iou_thr=match_iou_thr,
                                        child_jac_thr=child_jac_thr)
            if sc is not None and sc > best_sc:
                best_sc, best_pid = sc, pid

        if best_pid is not None:
            P = parents_by_id[int(best_pid)]
            supp = apply_mask_and_centroid(
                P, prop, dtype=dtype, support_tau=support_tau, H=H, W=W,
                chosen_centers=chosen_centers, pid=best_pid,
                per_x=per_x, per_y=per_y, fallback_cyx=(cy, cx)
            )
            cw = peak.get("child_weights")
            if isinstance(cw, dict) and cw:
                # weighted replace with EMA or init uniform over gkids if empty
                replaced = _update_parent_weights(P, cw,
                                                  replace_thr=float(getattr(config, "parent_match_childset_replace_thr", 0.75)),
                                                  weight_ema=float(getattr(config, "parent_child_weight_ema", 0.20)))
                if not replaced and not getattr(P, "child_weights", {}):
                    P.child_ids = tuple(sorted(gkids))
                    P.child_weights = {int(cid): 1.0 / len(gkids) for cid in gkids}
            else:
                P.child_ids = tuple(sorted(gkids))
                P.child_weights = {int(cid): 1.0 / len(gkids) for cid in gkids}

            P._region_proposal = prop
            P.emerged = True
            exists_support[best_pid] = (P.mask > support_tau)
            exists_kids[best_pid]    = set(P.child_ids)
            updated += 1
            if bool(getattr(config, "debug_spawn_log_details", True)):
                print(f"  -> MATCH pid={best_pid} iou={best_sc[0]:.3f} "
                      f"jacc={(best_sc[1]-1.0) if best_sc[1] > 1 else best_sc[1]:.3f} "
                      f"seed_px={seed_px}")
            continue

        # 6) SPAWN new (respect spacing and kid-set duplicates)
        if not respect_spawn_spacing(
            cy, cx, gkids, chosen_centers, exists_kids,
            H, W, per_x, per_y,
            min_interseed_px=min_interseed_px,
            jac_thr=float(getattr(config, "spacing_child_jaccard_thr", 0.90)),
            subset_thr=float(getattr(config, "spacing_child_subset_thr", 0.90)),
        ):
            if bool(getattr(config, "debug_spawn_log_details", True)):
                print("  -> DROP (spacing/child-set near-duplicate)")
            dropped_spacing += 1
            continue

        pid = int(next_parent_id); next_parent_id += 1

        # ctx-aware spawn (threads CacheHub via _RC)
        P, supp = _spawn_parent(
            _RC, agents, pid=pid, H=H, W=W, Kq=Kq, Kp=Kp, Gq=Gq, Gp=Gp,
            prop=prop, dtype=dtype, support_tau=support_tau,
            gkids=gkids, peak_child_weights=peak.get("child_weights"),
            step_now=step_now, per_x=per_x, per_y=per_y, chosen_centers=chosen_centers
        )

        # register new parent locally
        parents_by_id[pid] = P
        if not _assert_parent_invariants(P, H, W):
            raise RuntimeError(f"New parent {pid} failed invariants at spawn")
        exists_support[pid] = supp
        exists_kids[pid]    = set(P.child_ids)
        spawned += 1
        new_spawned += 1

    print(f"[SPAWN] updated={updated} spawned={spawned} "
          f"d_local={dropped_local} d_space={dropped_spacing} "
          f"d_childov={dropped_childov} d_seed={dropped_seed} d_budget={dropped_budget}")
    return next_parent_id






def _make_parent_template(ctx, tmpl, *, pid: int, H: int, W: int, Kq: int, Kp: int,
                          generators_q, generators_p):
    """Construct a brand-new level-1 parent with safe defaults and gradient buffers."""
    import numpy as np
    import config

    AgentCls = tmpl.__class__
    dtype = tmpl.mu_q_field.dtype

    eye_q = np.broadcast_to(np.eye(Kq, dtype=dtype), (H, W, Kq, Kq)).copy()
    eye_p = np.broadcast_to(np.eye(Kp, dtype=dtype), (H, W, Kp, Kp)).copy()

    P = AgentCls(
        id=pid, center=(0, 0), radius=0.0,
        mask=np.zeros((H, W), np.float32),
        mu_q_field=np.zeros((H, W, Kq), dtype=dtype), sigma_q_field=eye_q,
        mu_p_field=np.zeros((H, W, Kp), dtype=dtype), sigma_p_field=eye_p,
        phi=np.zeros((H, W, 3), dtype=dtype), phi_model=np.zeros((H, W, 3), dtype=dtype),
        neighbors=[]
    )

    # level/lifecycle
    P.level = 1
    P.emerged = True
    P._age = 0
    P._grace = int(getattr(config, "parent_grace_steps", 2))
    P._shrink_strikes = 0
    P.birth_step = int(getattr(ctx, "global_step", 0))

    # coalition/weights placeholders
    P.child_ids = ()
    P.child_weights = {}

    # transport caches (left empty; CacheHub will serve exp/Ω)
    P.Omega_cache = {}
    P.Omega_tilde_cache = {}
    P._exp_phi = None; P._exp_neg_phi = None
    P._exp_phi_model = None; P._exp_neg_phi_model = None

    # stash generators if missing
    P.generators_q = P.generators_q if getattr(P, "generators_q", None) is not None else generators_q
    P.generators_p = P.generators_p if getattr(P, "generators_p", None) is not None else generators_p

    # Base morphisms
    P.Phi_0       = np.eye(Kp, Kq, dtype=dtype)
    P.Phi_tilde_0 = np.eye(Kq, Kp, dtype=dtype)

    # Compute default bundle morphisms (ctx-aware)
    try:
        
        P.bundle_morphism_q_to_p, P.bundle_morphism_p_to_q = compute_direct_morphisms(
            phi=P.phi,
            phi_model=P.phi_model,
            generators_q=P.generators_q,
            generators_p=P.generators_p,
            Phi_0=P.Phi_0,
            Phi_tilde_0=P.Phi_tilde_0,
            ctx=ctx,  # <-- pass CacheHub-aware runtime context
        )
        P.morphisms_dirty = False
    except Exception:
        P.bundle_morphism_q_to_p = np.broadcast_to(P.Phi_0, (H, W, Kp, Kq)).copy()
        P.bundle_morphism_p_to_q = np.broadcast_to(P.Phi_tilde_0, (H, W, Kq, Kp)).copy()
        P.morphisms_dirty = False  # still treat as initialized

    # Initialize gradient buffers
    initialize_agent_gradients(P)

    # SPD tidy
    def _spd_tidy(S):
        S = 0.5 * (S + np.swapaxes(S, -1, -2))
        K = S.shape[-1]
        return S + (1e-8 * np.eye(K, dtype=S.dtype))

    assert P.sigma_q_field.ndim == 4 and P.sigma_q_field.shape[-1] == P.sigma_q_field.shape[-2]
    assert P.sigma_p_field.ndim == 4 and P.sigma_p_field.shape[-1] == P.sigma_p_field.shape[-2]
    P.sigma_q_field = _spd_tidy(P.sigma_q_field)
    P.sigma_p_field = _spd_tidy(P.sigma_p_field)

    P._region_proposal = None

    try:
        import traceback, time
        P._created_where = "parent_spawn._make_parent_template"
        P._created_when  = time.time()
        P._created_stack = "".join(traceback.format_stack(limit=12))
    except Exception:
        P._created_where = "parent_spawn._make_parent_template"
        P._created_when  = None
        P._created_stack = None

    return P











def _assert_parent_invariants(P, H, W):
    import numpy as _np
    def _shp(x):
        try: return tuple(_np.asarray(x).shape)
        except: return None
    ok = True
    msg = []
    for name in ("mu_q_field","sigma_q_field","mu_p_field","sigma_p_field","phi","phi_model","mask"):
        val = getattr(P, name, None)
        if val is None:
            ok = False; msg.append(f"{name}=None")
    if ok:
        mq, sq = _shp(P.mu_q_field), _shp(P.sigma_q_field)
        mp, sp = _shp(P.mu_p_field), _shp(P.sigma_p_field)
        if (mq is None or len(mq)!=3 or mq[0]!=H or mq[1]!=W): ok=False; msg.append(f"mu_q_field{mq}")
        if (sq is None or len(sq)!=4 or sq[0]!=H or sq[1]!=W or sq[-1]!=sq[-2]): ok=False; msg.append(f"sigma_q_field{sq}")
        if (mp is None or len(mp)!=3 or mp[0]!=H or mp[1]!=W): ok=False; msg.append(f"mu_p_field{mp}")
        if (sp is None or len(sp)!=4 or sp[0]!=H or sp[1]!=W or sp[-1]!=sp[-2]): ok=False; msg.append(f"sigma_p_field{sp}")
    if not ok:
        where = getattr(P, "_created_where", "?")
        print(f"[PARENT_INVARIANT_FAIL] pid={getattr(P,'id','?')} where={where} details={';'.join(msg)}")
        stk = getattr(P, "_created_stack", None)
        if stk: print(stk)
    return ok






#============================================
#
#      MATCH OR SPAWN HELPERS
#
#===========================================

# ------------------------- helpers tucked locally -------------------------

def _seed_proposal_or_skip(peak, *, H, W, agents, local_tau, min_local_px,
                           mask_tau_child, support_tau, min_seed_px):
    """Gate + seed proposal; return (prop, seed_bool, seed_px) or (None, reason)."""
    
    prop = peak.get("proposal", peak.get("mask"))
    gated, reason = gate_and_seed_proposal(
        prop, H=H, W=W, local_tau=local_tau, min_local_px=min_local_px,
        agents=agents, mask_tau_child=mask_tau_child,
        support_tau=support_tau, min_seed_px=min_seed_px
    )
    if gated is None:
        return None, reason
    return gated, None  # (prop, seed_bool, seed_px)

def _novelty_or_skip(seed_bool, *, exists_support, H, W, min_novel_px, min_novel_frac):
    """Novelty gate over existing supports; returns (ok, novel_px, novel_frac)."""
    
    return novelty_gate_ok(
        seed_bool, exists_support, H=H, W=W,
        min_novel_px=min_novel_px, min_novel_frac=min_novel_frac
    )

def _continuity_try_rescue(cy, cx, seed_bool, *, exists_support, H, W,
                           per_x, per_y, cont_r2, cont_iou_thr):
    """Return best_pid or None for continuity-rescue."""
    from parent_utils import continuity_match_pid
    cont = continuity_match_pid(
        cy, cx, seed_bool, exists_support,
        H=H, W=W, per_x=per_x, per_y=per_y,
        cont_r2=cont_r2, cont_iou_thr=cont_iou_thr
    )
    return (cont[1] if cont is not None else None)

def _conservative_child_set(agents, seed_bool, *, mask_tau_child, min_overlap_px):
    """Intersection-based kid set from seed (conservative)."""
    
    return set(conservative_child_set_from_seed(
        agents, seed_bool, mask_tau=mask_tau_child, min_overlap_px=min_overlap_px
    ))

def _update_parent_weights(P, peak_child_weights, *,
                           replace_thr, weight_ema):
    """
    Update P.child_weights (+ids) using either hard replace (if J>=replace_thr)
    or EMA blend; returns True if overwrite in place, False if blended.
    """
    cw = peak_child_weights
    if not (isinstance(cw, dict) and cw):
        return False  # handled by caller (use gkids uniform)
    old = set(getattr(P, "child_ids", ()))
    new = set(int(k) for k in cw.keys())

    # jaccard on ids (only for decision)
    try:
        
        j = jaccard_sets(old, new) if old else 1.0
    except Exception:
        j = 1.0 if not old else 0.0

    if j >= float(replace_thr):
        P.child_weights = {int(k): float(v) for k, v in cw.items()}
        P.child_ids = tuple(sorted(P.child_weights.keys()))
        return True

    # EMA blend
    weights = dict(getattr(P, "child_weights", {}))
    if not weights and old:
        # bootstrap to uniform if we had old ids but no weights
        weights = {int(k): 1.0 / len(old) for k in old}
    keys = set(weights.keys()) | set(int(x) for x in cw.keys())
    tot = 0.0
    for k in keys:
        v_old = float(weights.get(k, 0.0))
        v_new = float(cw.get(k, 0.0))
        weights[k] = (1.0 - float(weight_ema)) * v_old + float(weight_ema) * v_new
        tot += weights[k]
    if tot > 0.0:
        inv = 1.0 / tot
        for k in weights:
            weights[k] *= inv
    P.child_weights = weights
    P.child_ids = tuple(sorted(weights.keys()))
    return False

def _match_best_parent(seed_bool, gkids, *, exists_support, exists_kids,
                       H, W, per_x, per_y, R2, match_iou_thr, child_jac_thr):
    """Return (best_pid, best_score_tuple) or (None, (-1,-1))."""
    
    best_pid, best_sc = None, (-1.0, -1.0)
    for pid, supp in exists_support.items():
        py, px = centroid_toroidal(supp, H, W, per_y=per_y, per_x=per_x)
        close = (dist2_toroidal(py, px, seed_bool.cy, seed_bool.cx, H, W, per_y, per_x) <= R2) \
                if hasattr(seed_bool, "cy") else False
        sc = match_score_for_parent(
            seed_bool, gkids, supp, exists_kids[pid],
            close=close, match_iou_thr=match_iou_thr, child_jac_thr=child_jac_thr
        )
        if sc is not None and sc > best_sc:
            best_sc, best_pid = sc, pid
    return best_pid, best_sc

def _apply_mask_and_centroid(P, prop, *, dtype, support_tau, H, W, chosen_centers, pid,
                             per_x, per_y, fallback_cyx):
    """Set mask, update exists_support center list."""
    
    P.mask = _np.clip(prop, 0.0, 1.0).astype(dtype, copy=False)
    supp = (_np.asarray(P.mask, _np.float32) > float(support_tau))
    append_center_from_mask(
        chosen_centers, supp, pid, H, W,
        per_x=per_x, per_y=per_y, fallback=fallback_cyx
    )
    return supp




def mask_hash_bool(mask_bool: _np.ndarray) -> int:
    """Small, stable hash for boolean masks."""
    mv = _np.packbits(mask_bool.astype(_np.uint8), bitorder="little")
    return int(hashlib.blake2b(mv, digest_size=8).hexdigest(), 16)


# ---------- small primitives ----------
def as_parent_dict(pars):
    if isinstance(pars, dict):
        return pars
    d = {}
    for P in (pars or []):
        pid = int(getattr(P, "id", len(d)))
        d[pid] = P
    return d

def iou_bool(a, b):
    a = _np.asarray(a, bool); b = _np.asarray(b, bool)
    if not a.any() and not b.any(): return 0.0
    inter = int((a & b).sum()); union = int(a.sum() + b.sum() - inter)
    return inter / max(1, union)

def centroid_bool(mask_bool):
    yyx = _np.argwhere(_np.asarray(mask_bool, bool))
    if yyx.size == 0: return None
    yx = yyx.mean(0)
    return float(yx[0]), float(yx[1])

def _mask_hash_bool(mask_bool: _np.ndarray) -> int:
    mv = _np.packbits(_np.asarray(mask_bool, bool).astype(_np.uint8), bitorder="little")
    return int(_hashlib.blake2b(mv, digest_size=8).hexdigest(), 16)

def need_cg_now(P, *, step_now, abs_core, rel_core, min_core_px, mask_tau):
    if getattr(P, "freeze_until", -1) > step_now:
        return False
    pm = _np.asarray(getattr(P, "mask", 0.0), _np.float32)
    if pm.size == 0: return False
    thr  = max(abs_core, rel_core * float(pm.max()))
    core = (pm > thr)
    if int(core.sum()) < int(min_core_px):
        return False
    last_h = getattr(P, "_last_cg_core_hash", None)
    cur_h  = _mask_hash_bool(core)
    changed_core = (last_h != cur_h)
    explicit_dirty = bool(getattr(P, "morphisms_dirty", False) or getattr(P, "_needs_cg", False))
    if changed_core or explicit_dirty:
        P._pending_core_hash = cur_h
        return True
    return False

# ---------- orchestrator helpers ----------
def ensure_parent_registry(ctx, agents):
    
    H, W = _np.asarray(agents[0].mask, _np.float32).shape[:2]
    if not hasattr(ctx, "parents_by_region") or ctx.parents_by_region is None:
        ctx.parents_by_region = {}
    existing = ctx.parents_by_region
    if not isinstance(existing, dict):
        existing = ctx.parents_by_region = as_parent_dict(existing)
    if not hasattr(ctx, "next_parent_id"):
        ctx.next_parent_id = 0
    next_parent_id = int(ctx.next_parent_id)
    prev_ids = set(existing.keys())
    return existing, next_parent_id, prev_ids, H, W

def compute_cover2_map(agents, tau_sup):
    Ms = _np.stack(
        [(_np.asarray(ch.mask, _np.float32) >= float(tau_sup)).astype(_np.uint8) for ch in agents],
        axis=0
    )
    return (Ms.sum(0) >= 2)

def existing_cores_and_centroids(existing, abs_core, rel_core):
    cores, cents = [], []
    for P in existing.values():
        pm = _np.asarray(getattr(P, "mask", 0.0), _np.float32)
        mmax = float(pm.max()) if pm.size else 0.0
        thr  = max(float(abs_core), float(rel_core) * mmax)
        core = (pm > thr)
        cores.append(core)
        yyx = _np.argwhere(core)
        if yyx.size == 0: cents.append(None)
        else:
            yx = yyx.mean(0); cents.append((float(yx[0]), float(yx[1])))
    return cores, cents

def filter_spawn_regions(regions, cover2, min_cover2_px, existing_cores, existing_centroids, spawn_nms_iou, spawn_min_dist_px):
    kept = []
    for R in (regions or []):
        m = _np.asarray(getattr(R, "mask", 0.0), _np.float32) > 0.0
        if not m.any(): continue
        if isinstance(cover2, _np.ndarray):
            if int((m & cover2).sum()) < int(min_cover2_px): continue
        cyx = centroid_bool(m)
        novel = True
        for ec, c0 in zip(existing_cores, existing_centroids):
            if not _np.asarray(ec).any(): continue
            if iou_bool(m, ec) >= float(spawn_nms_iou):
                novel = False; break
            if cyx is not None and c0 is not None:
                if (abs(cyx[0]-c0[0]) + abs(cyx[1]-c0[1])) < float(spawn_min_dist_px):
                    novel = False; break
        if novel: kept.append(R)
    return kept

def merge_parents_into_registry(ctx, parents_changed):
    
    parents_changed = as_parent_dict(parents_changed)
    existing = ctx.parents_by_region
    step_now = int(getattr(ctx, "global_step", 0))
    freeze_steps = int(getattr(config, "parent_freeze_steps", 3))
    for pid, P in parents_changed.items():
        existing[int(getattr(P, "id", pid))] = P
        pm = _np.asarray(getattr(P, "mask", 0.0), _np.float32)
        P.seed_mask = pm.copy()
        if not hasattr(P, "_age"):   P._age = 0
        P._born_step   = step_now
        P.freeze_until = step_now + freeze_steps
        if not hasattr(P, "_grace"): P._grace = freeze_steps
        setattr(P, "_needs_cg", True)
    return parents_changed, step_now

def select_cg_targets_stable(parents_changed, prev_ids, *, step_now, abs_core, rel_core, min_core_px, mask_tau):
    # stable = existed before this spawn call
    items_all = [(pid, P) for (pid, P) in parents_changed.items() if int(pid) in prev_ids]
    cg_items  = []
    for pid, P in items_all:
        if need_cg_now(P, step_now=step_now, abs_core=abs_core, rel_core=rel_core,
                       min_core_px=min_core_px, mask_tau=mask_tau):
            cg_items.append(P)
    return items_all, cg_items

def run_cg_for_parents(ctx, cg_items, agents, Gq, Gp, *, eps, mask_tau, backend, n_jobs, batch_size, prefer, omp_thr):
    
    # oversub throttle for processes
    if backend == "loky":
        os.environ.setdefault("OMP_NUM_THREADS", str(int(omp_thr)))
        os.environ.setdefault("OPENBLAS_NUM_THREADS", str(int(omp_thr)))
        os.environ.setdefault("MKL_NUM_THREADS", str(int(omp_thr)))
        os.environ.setdefault("NUMEXPR_NUM_THREADS", str(int(omp_thr)))

    results = Parallel(n_jobs=n_jobs, backend=backend, batch_size=batch_size, **({"prefer": prefer} if prefer else {}))(
        delayed(_cg_worker_apply_or_prepare)(
            P, agents, eps=float(eps), mask_tau=float(mask_tau), Gq=Gq, Gp=Gp, backend=backend
        )
        for P in cg_items
    )

    cg_ok, cg_fail = 0, 0
    for (status, pid, payload), P in zip(results, cg_items):
        if status == "ok":
            if backend == "loky" and isinstance(payload, dict):
                for name, val in payload.items():
                    if val is not None:
                        setattr(P, name, val)
            if getattr(config, "debug_strict", True):
                for name in ("sigma_q_field","sigma_p_field"):
                    S = getattr(P, name, None)
                    if S is not None:
                        S = _np.asarray(S)
                        assert S.ndim == 4 and S.shape[-1] == S.shape[-2], \
                            f"[CG->ASSIGN] {name} bad shape {S.shape} for parent {getattr(P,'id','?')}"
            setattr(P, "morphisms_dirty", True)
            if hasattr(P, "_pending_core_hash"):
                P._last_cg_core_hash = P._pending_core_hash
                delattr(P, "_pending_core_hash")
            setattr(P, "_needs_cg", False)
            cg_ok += 1
        else:
            print(f"[WARN] coarsegrain/init failed for parent {pid}: {payload}")
            cg_fail += 1
    return cg_ok, cg_fail

# --- top-level import (once) ---




def _need_cg_now(P, *, step_now, abs_core, rel_core, min_core_px, mask_tau):
    """
    Decide if parent P needs coarse-graining this step.
    Criteria:
      - newborn freeze window passed
      - core area >= min_core_px
      - mask core changed since last CG beyond threshold
      - flagged dirty (P.morphisms_dirty or P._need_cg)
    """
    # freeze window
    if getattr(P, "freeze_until", -1) > step_now:
        return False

    pm = np.asarray(getattr(P, "mask", 0.0), np.float32)
    if pm.size == 0:
        return False

    # compute core by same semantics used elsewhere
    thr = max(abs_core, rel_core * float(pm.max()))
    core = (pm > thr)
    core_px = int(core.sum())
    if core_px < int(min_core_px):
        return False

    # changed core?
    last_h = getattr(P, "_last_cg_core_hash", None)
    cur_h  = _mask_hash_bool(core)
    changed_core = (last_h != cur_h)

    # explicit dirty flags
    explicit_dirty = bool(getattr(P, "morphisms_dirty", False) or getattr(P, "_need_cg", False))

    # If either core changed or explicit dirty, do it
    if changed_core or explicit_dirty:
        # stash for post-commit
        P._pending_core_hash = cur_h
        return True
    return False

# --- worker stays as previously sent (threading mutates, loky returns updates) ---




def _spawn_parent(_RC, agents, *, pid, H, W, Kq, Kp, Gq, Gp, prop, dtype,
                  support_tau, gkids, peak_child_weights, step_now,
                  per_x, per_y, chosen_centers):
    """Create & initialize a brand-new parent, return (P, support_bool)."""
    
    P = _make_parent_template(_RC, agents[0], pid=pid, H=H, W=W, Kq=Kq, Kp=Kp,
                              generators_q=Gq, generators_p=Gp)

    # post-create invariants (kept minimal)
    P._region_proposal = prop
    P.emerged = True
    P.birth_step = step_now
    P._age = 0
    P._grace = int(getattr(config, "parent_freeze_steps", 0))

    # ids/weights
    cw = peak_child_weights
    if isinstance(cw, dict) and cw:
        P.child_weights = {int(k): float(v) for k, v in cw.items()}
        P.child_ids = tuple(sorted(P.child_weights.keys()))
    else:
        P.child_ids = tuple(sorted(gkids))
        if len(gkids) == 0:
            P.child_weights = {}
        else:
            P.child_weights = {int(cid): 1.0 / len(gkids) for cid in gkids}

    supp = _apply_mask_and_centroid(
        P, prop, dtype=dtype, support_tau=support_tau,
        H=H, W=W, chosen_centers=chosen_centers, pid=pid,
        per_x=per_x, per_y=per_y, fallback_cyx=(None, None)
    )
    return P, supp

# Connected-components labeling (robust import + neutral name)
try:
    from scipy.ndimage import label as cc_label        # preferred
except Exception:
    try:
        from skimage.measure import label as cc_label  # fallback
    except Exception:
        # ultra-slow fallback (4-connectivity) so code still runs
        def cc_label(B):
            import numpy as np
            H, W = B.shape
            labels = np.zeros((H, W), dtype=np.int32)
            n = 0
            for y in range(H):
                for x in range(W):
                    if B[y, x] and labels[y, x] == 0:
                        n += 1
                        stk = [(y, x)]
                        labels[y, x] = n
                        while stk:
                            yy, xx = stk.pop()
                            for dy, dx in ((1,0),(-1,0),(0,1),(0,-1)):
                                ny, nx = yy+dy, xx+dx
                                if 0 <= ny < H and 0 <= nx < W and B[ny, nx] and labels[ny, nx] == 0:
                                    labels[ny, nx] = n
                                    stk.append((ny, nx))
            return labels, n


def _cg_worker_apply_or_prepare(P, children, *, eps, mask_tau, Gq, Gp, backend):
    """
    Wrapper for coarsegrain_parent_from_children.

    threading: mutate P in place, return ("ok", pid, None) or ("fail", pid, msg)
    loky:      compute into a shell, return ("ok", pid, updates_dict) or ("fail", pid, msg)
    """
    try:
        if backend == "threading":
            coarsegrain_parent_from_children(P, children, eps=eps, mask_tau=mask_tau, G_q=Gq, G_p=Gp)
            return ("ok", int(getattr(P, "id", -1)), None)

        # --- loky: compute on a lightweight shell; send arrays back ---
        class _PShell: pass
        Ps = _PShell()
        for name in ("id", "mask", "mu_q_field", "sigma_q_field", "mu_p_field", "sigma_p_field", "phi", "phi_model"):
            setattr(Ps, name, getattr(P, name, None))

        coarsegrain_parent_from_children(Ps, children, eps=eps, mask_tau=mask_tau, G_q=Gq, G_p=Gp)

        updates = {k: getattr(Ps, k, None) for k in ("mu_q_field","sigma_q_field","mu_p_field","sigma_p_field","phi","phi_model")}
        return ("ok", int(getattr(P, "id", -1)), updates)
    except Exception as e:
        return ("fail", int(getattr(P, "id", -1)), f"{e}")

# --- parent_utils.py (additions) ---------------------------------------------
import numpy as _np

# Thin wrappers so parent_spawn stays slim and declarative

def seed_proposal_or_skip(peak, *, H, W, agents, local_tau, min_local_px,
                          mask_tau_child, support_tau, min_seed_px):
    """
    Gate + seed proposal; return (prop, seed_bool, seed_px) or (None, reason).
    """
    prop = peak.get("proposal", peak.get("mask"))
    gated, reason = gate_and_seed_proposal(
        prop, H=H, W=W, local_tau=local_tau, min_local_px=min_local_px,
        agents=agents, mask_tau_child=mask_tau_child,
        support_tau=support_tau, min_seed_px=min_seed_px
    )
    if gated is None:
        return None, reason
    return gated, None  # (prop, seed_bool, seed_px), None

def novelty_or_skip(seed_bool, *, exists_support, H, W, min_novel_px, min_novel_frac):
    """
    Novelty gate over existing supports; returns (ok, novel_px, novel_frac).
    """
    return novelty_gate_ok(
        seed_bool, exists_support, H=H, W=W,
        min_novel_px=min_novel_px, min_novel_frac=min_novel_frac
    )


from parent_utils import continuity_match_pid

def continuity_try_rescue(cy, cx, seed_bool, *, exists_support, H, W,
                          per_x, per_y, cont_r2, cont_iou_thr):
    """
    Return best_pid or None for continuity-rescue.
    """
    cont = continuity_match_pid(
        cy, cx, seed_bool, exists_support,
        H=H, W=W, per_x=per_x, per_y=per_y,
        cont_r2=cont_r2, cont_iou_thr=cont_iou_thr
    )
    return (cont[1] if cont is not None else None)

def conservative_child_set(agents, seed_bool, *, mask_tau_child, min_overlap_px):
    """
    Intersection-based kid set from seed (conservative).
    """
    return set(conservative_child_set_from_seed(
        agents, seed_bool, mask_tau=mask_tau_child, min_overlap_px=min_overlap_px
    ))

def apply_mask_and_centroid(P, prop, *, dtype, support_tau, H, W,
                            chosen_centers, pid, per_x, per_y, fallback_cyx):
    """
    Set mask, return support_bool; also appends centroid to chosen_centers.
    """
    P.mask = _np.clip(prop, 0.0, 1.0).astype(dtype, copy=False)
    supp = (_np.asarray(P.mask, _np.float32) > float(support_tau))
    append_center_from_mask(
        chosen_centers, supp, pid, H, W,
        per_x=per_x, per_y=per_y, fallback=fallback_cyx
    )
    return supp
