# -*- coding: utf-8 -*-
"""
Created on Sat Sep 27 15:19:10 2025

@author: chris and christine

Case A:  L( q_j] ||Ω^q_ji Φ̃_i p_i )
Case B:  KL( p_i || Φ_i Ω^q_ij[q_j] )  

Case C: KL( Φ̃_i p_i  ||  Ω^q_ij q_j )  is dual to case B
Case D: KL( Ω^q_ij  q_j || Φ̃_i  p_i )  is dual to case A

Default Q:  KL( q_i || Ω^q_ij q_j )
Default P:  KL( p_i || Ω^p_ij p_j ) 

"""

import numpy as np
from runtime_context import cfg_get
from core.numerical_utils import sanitize_sigma, kl_gaussian, push_gaussian, safe_inv
from core.transport_cache import Omega, E_grid, Phi
import matplotlib.pyplot as plt


_TINY32 = np.finfo(np.float32).tiny
_LOG_TINY64 = np.log(np.finfo(np.float64).tiny)

def _to32_no_underflow(x):
    x64 = np.asarray(x, dtype=np.float64)
    with np.errstate(under='ignore'):
        x64 = np.where(np.abs(x64) < _TINY32, 0.0, x64)
        return x64.astype(np.float32, copy=False)


def get_edge_fields(ctx, which: str, i: int, j: int):
    """Return (beta_ij, KL1_ij) arrays stored by compute_edge_betas."""
    try:
        b = ctx._edge_beta[(which, i, j)]
        k = ctx._edge_kl1 [(which, i, j)]
    except KeyError as e:
        raise RuntimeError(f"get_edge_fields: missing {(which,i,j)}: {e}")
    return b, k



def assert_finite(tag, *arrs):
    for a in arrs:
        if not np.all(np.isfinite(a)):
            raise FloatingPointError(f"[{tag}] non-finite in beta grads")




def _compose_R_and_assert(Phi_i: np.ndarray, Om: np.ndarray, *, i_id: int, j_id: int):
    import numpy as np
    # 1) shape sanity
    assert Phi_i.shape[-1] == Om.shape[-2], \
        f"shape mismatch: Phi_i{Phi_i.shape} @ Om{Om.shape} (i={i_id}, j={j_id})"

    # 2) compose
    R = np.einsum("...ik,...kj->...ij", Phi_i, Om, optimize=True)

    # 3) hard fail *before* any norms if non-finite
    _assert_finite("R", R, f"(i={i_id}, j={j_id})")

    # 4) batch opnorm for logging
    A = np.asarray(R, np.float64)
    *batch, m, n = A.shape
    Ar = A.reshape(-1, m, n)
    smax = []
    for k in range(Ar.shape[0]):
        s = np.linalg.svd(Ar[k], compute_uv=False)
        if s.size:
            smax.append(float(s[0]))
    op_R = float(np.mean(smax)) if smax else float("nan")
    return R, op_R



# ──────────────────────────────────────────────────────────────────────────────
# Small utilities (kept private)
# ──────────────────────────────────────────────────────────────────────────────

def _first_bad_idx(X: np.ndarray):
    bad = ~np.isfinite(np.asarray(X))
    if not bad.any():
        return None
    # drop last two dims which are matrix axes when present
    idx = tuple(np.argwhere(bad)[0])
    if len(idx) >= 2:
        return tuple(idx[:-2])
    return tuple(idx)


def _assert_finite(name: str, X: np.ndarray, ctx_str: str = ""):
    if not np.isfinite(np.asarray(X)).all():
        idx = _first_bad_idx(X)
        raise RuntimeError(f"[{name}] non-finite at voxel={idx} {ctx_str}")


def _safe_mask(arr, mask):
    # Broadcast mask to arr.shape, return float mask
    m = np.asarray(mask)
    if m.shape != arr.shape:
        m = np.broadcast_to(m, arr.shape)
    return m.astype(np.float32, copy=False)


def _softmax_over_senders(logits: np.ndarray, mask: np.ndarray, tiny: float = 1e-12):
    """
    Masked softmax over axis 0 (senders). Shapes (J,*S).
    - Zero weights where no sender is valid at a pixel.
    - NaN/±inf-safe under strict np.seterr.
    - Underflow-safe when casting to float32: clamp subnormals to 0 then renormalize.
    """
    import numpy as np

    L = np.asarray(logits, np.float64)
    M = np.asarray(mask, dtype=bool)

    # valid := on-mask AND finite
    valid = M & np.isfinite(L)
    any_valid = np.any(valid, axis=0, keepdims=True)  # (1,*S)

    # Max over valid entries; -inf where none are valid
    L_masked = np.where(valid, L, -np.inf)
    Lmax = np.max(L_masked, axis=0, keepdims=True)
    Lmax_safe = np.where(np.isfinite(Lmax), Lmax, 0.0)  # avoid (-inf)-(-inf)

    with np.errstate(invalid='ignore', over='ignore', under='ignore'):
        shifted = L - Lmax_safe
        shifted = np.where(valid, shifted, -np.inf)
        expL = np.exp(shifted)
        expL = np.where(valid, expL, 0.0)

    Z = np.sum(expL, axis=0, keepdims=True)
    Z = np.where(any_valid, np.maximum(Z, tiny), 1.0)

    W = expL / Z
    W = np.where(any_valid, W, 0.0)

    # ---- Underflow-safe cast to float32 ----
    # Clamp subnormals to zero, then renormalize across senders.
    tiny32 = np.finfo(np.float32).tiny  # ~1.1754944e-38
    W = np.where(W < tiny32, 0.0, W)

    sumW = np.sum(W, axis=0, keepdims=True)
    # If we zeroed some tiny entries, re-normalize to keep sum=1 where valid
    sumW_safe = np.where(any_valid, np.maximum(sumW, 1.0), 1.0)
    W = np.where(any_valid, W / sumW_safe, 0.0)

    # Now casting cannot underflow (we only have zeros or >= tiny32)
    return W.astype(np.float32, copy=False)



# ──────────────────────────────────────────────────────────────────────────────
# Accessors / config helpers
# ──────────────────────────────────────────────────────────────────────────────

def _fiber_accessors(which: str):
    """Return closures to get μ, Σ, and mask for active fiber, plus q/p helpers."""
    if which not in ("q", "p"):
        raise ValueError("_fiber_accessors: which must be 'q' or 'p'")

    def _mu(a):
        return np.asarray(getattr(a, "mu_q_field" if which == "q" else "mu_p_field"), np.float32)

    def _S(a):
        base = getattr(a, "sigma_q_field" if which == "q" else "sigma_p_field")
        return sanitize_sigma(np.asarray(base, np.float64))

    def _mask(a):
        m = np.asarray(getattr(a, "mask"), np.float32)
        if m.ndim >= 1 and m.shape[-1] == 1:
            m = m[..., 0]
        return m

    # helpers for the "other" fiber (used by A–D bases)
    def _mu_q(a): return np.asarray(getattr(a, "mu_q_field"), np.float32)
    def _S_q(a):  return sanitize_sigma(np.asarray(getattr(a, "sigma_q_field"), np.float64))
    def _mu_p(a): return np.asarray(getattr(a, "mu_p_field"), np.float32)
    def _S_p(a):  return sanitize_sigma(np.asarray(getattr(a, "sigma_p_field"), np.float64))

    return _mu, _S, _mask, _mu_q, _S_q, _mu_p, _S_p


def _beta_cfg(ctx, which: str):
    basis = str(cfg_get(ctx, f"beta_{which}", "align_q" if which == "q" else "align_p")).lower()
    kappa = float(cfg_get(ctx, f"beta_kappa_{which}", 1.0))
    eps   = float(cfg_get(ctx, "obs_beta_eps", 1e-12))
    tau   = float(cfg_get(ctx, "support_tau", 1e-6))
    return basis, max(kappa, 1e-12), eps, tau


# ──────────────────────────────────────────────────────────────────────────────
# KL builders
# ──────────────────────────────────────────────────────────────────────────────

def _kl_alignment(ctx, which: str, ai, aj, *, eps: float):
    """KL used for alignment updates (KL1). Computes Ω_{ij} on the requested fiber."""
    if which == "q":
        Om = Omega(ctx=ai.ctx if hasattr(ai, 'ctx') else None, agent_i=ai, agent_j=aj, which="q")
        mu_j_t, S_j_t = push_gaussian(aj.mu_q_field, aj.sigma_q_field, Om, eps=eps)[:2]
        return kl_gaussian(ai.mu_q_field, ai.sigma_q_field, mu_j_t, S_j_t), Om
    else:
        Om = Omega(ctx=ai.ctx if hasattr(ai, 'ctx') else None, agent_i=ai, agent_j=aj, which="p")
        mu_j_t, S_j_t = push_gaussian(aj.mu_p_field, aj.sigma_p_field, Om, eps=eps)[:2]
        return kl_gaussian(ai.mu_p_field, ai.sigma_p_field, mu_j_t, S_j_t), Om


def _kl2_per_basis(ctx, basis: str, ai, aj, *, Om_q, Phi_i, Phit_i, eps: float):
    b = basis
    mu_q_i, S_q_i = ai.mu_q_field, ai.sigma_q_field
    mu_p_i, S_p_i = ai.mu_p_field, ai.sigma_p_field
    mu_q_j, S_q_j = aj.mu_q_field, aj.sigma_q_field

    if b == "align_q":
        mu_j_t, S_j_t = push_gaussian(mu_q_j, S_q_j, Om_q, eps=eps)[:2]
        return kl_gaussian(mu_q_i, S_q_i, mu_j_t, S_j_t)

    if b == "align_p":
        Om_p = Omega(ctx, ai, aj, which="p")
        mu_j_t, S_j_t = push_gaussian(aj.mu_p_field, aj.sigma_p_field, Om_p, eps=eps)[:2]
        return kl_gaussian(mu_p_i, S_p_i, mu_j_t, S_j_t)

    if b == "a":
        # Dual form: KL( Φ_i[Ω_ij q_j] || p_i ) == KL( q_j || Ω_ji[ Φ̃_i p_i ] )
        Om_q_ji = Omega(ctx, aj, ai, which="q")  # <— use the passed-in ctx
        # Φ̃_i p_i in Q_i, then push to Q_j
        mu_pi_in_qi, S_pi_in_qi = push_gaussian(
            np.asarray(mu_p_i, np.float64), np.asarray(S_p_i, np.float64), Phit_i, eps=eps
        )[:2]
        mu_pi_in_qj, S_pi_in_qj = push_gaussian(
            mu_pi_in_qi, S_pi_in_qi, Om_q_ji, eps=eps
        )[:2]
        return kl_gaussian(
            np.asarray(mu_q_j, np.float64), np.asarray(S_q_j, np.float64),
            mu_pi_in_qj, S_pi_in_qj
        )

    if b == "b":
        mu_qj_t, S_qj_t = push_gaussian(mu_q_j, S_q_j, Om_q, eps=eps)[:2]
        mu_L, S_L = push_gaussian(mu_qj_t, S_qj_t, Phi_i, eps=eps)[:2]
        return kl_gaussian(mu_p_i, S_p_i, mu_L, S_L)


    raise ValueError(f"unknown beta basis {basis!r}")



# ──────────────────────────────────────────────────────────────────────────────
# Main entry
# ──────────────────────────────────────────────────────────────────────────────

def compute_edge_betas(ctx, agents, *, which="q"):
    """
    Unified per-edge maps for a single fiber ('q' or 'p'):

        ctx._edge_kl1[(which,i,j)]  = KL1_ij  (alignment KL for updates)
        ctx._edge_kl2[(which,i,j)]  = KL2_ij  (β-basis KL; 0 off-overlap)
        ctx._edge_beta[(which,i,j)] = β_ij    (per-pixel attention; softmax over senders)

    β construction (NO external builders required):
      1) For each receiver i, compute per-sender KL2_ij(x) according to the basis:
         A: KL( Φ_i[Ω^q_ij q_j] || p_i )      (P_i frame)
         B: KL( p_i || Φ_i[Ω^q_ij q_j] )      (P_i frame)
         C: KL( Φ̃_i p_i || Ω^q_ij q_j )      (Q_i frame)
         D: KL( Ω^q_ij q_j || Φ̃_i p_i )      (Q_i frame)
         align_q: KL(q_i || Ω^q_ij q_j)       (Q_i frame)
         align_p: KL(p_i || Ω^p_ij p_j)       (P_i frame)
      2) Mask off-overlap pixels (logits=-inf → weight 0 there).
      3) Softmax over senders j for each pixel x: β_ij(x) = softmax_j( -KL2_ij(x) / κ ).

    Notes:
      • KL2 stored in ctx._edge_kl2 is zeroed off-overlap (useful for gradient weighting).
      • Softmax is per-pixel and only over senders with overlap at that pixel.
    """
    if which not in ("q", "p"):
        raise ValueError("compute_edge_betas: which must be 'q' or 'p'")

    if not hasattr(ctx, "cache") or ctx.cache is None:
        raise RuntimeError("compute_edge_betas: ctx.cache missing (ensure runtime_ctx was initialized this step)")


    # ensure maps
    ctx._edge_kl1  = getattr(ctx, "_edge_kl1",  {})
    ctx._edge_kl2  = getattr(ctx, "_edge_kl2",  {})
    ctx._edge_beta = getattr(ctx, "_edge_beta", {})

    basis, kappa, eps, tau = _beta_cfg(ctx, which)
    _mu, _S, _mask, _mu_q, _S_q, _mu_p, _S_p = _fiber_accessors(which)

    ids = [int(getattr(a, "id", i)) for i, a in enumerate(agents)]

    for i_idx, ai in enumerate(agents):
        i_id = ids[i_idx]
        Sshape = _mu(ai).shape[:-1]

        # cache-backed per-receiver frames/morphisms
        Eq_i = E_grid(ctx, ai, which="q"); Ep_i = E_grid(ctx, ai, which="p")
        Phi_i  = np.asarray(Phi(ctx, ai, kind="q_to_p"), np.float64)
        Phit_i = np.asarray(Phi(ctx, ai, kind="p_to_q"), np.float64)
        _assert_finite("E_q", Eq_i, f"(i={i_id})"); _assert_finite("E_p", Ep_i, f"(i={i_id})")
        _assert_finite("Phi_i", Phi_i, f"(i={i_id})"); _assert_finite("Phi_tilde_i", Phit_i, f"(i={i_id})")

        # receiver stats (both fibers available)
        mu_q_i, S_q_i = _mu_q(ai), _S_q(ai)
        mu_p_i, S_p_i = _mu_p(ai), _S_p(ai)

        logits_list, mask_list, send_ids = [], [], []
        kl2_store, kl1_store = {}, {}

        mi = _mask(ai)
        for j_idx, aj in enumerate(agents):
            if j_idx == i_idx:
                continue
            j_id = ids[j_idx]

            mj = _mask(aj)
            joint = (mi > tau) & (mj > tau)
            try:
                joint = np.broadcast_to(joint, Sshape)
            except Exception as e:
                raise ValueError(f"mask broadcast failed (i={i_id}, j={j_id})") from e
            if not np.any(joint):
                continue

            # KL1 (alignment) always uses Ω on the active fiber
            if which == "q":
                Om_q = Omega(ctx, ai, aj, which="q")
                mu_j_t, S_j_t = push_gaussian(_mu_q(aj), _S_q(aj), Om_q, eps=eps)[:2]
                KL1_ij = kl_gaussian(mu_q_i, S_q_i, mu_j_t, S_j_t)
            else:
                Om_p = Omega(ctx, ai, aj, which="p")
                mu_j_t, S_j_t = push_gaussian(_mu_p(aj), _S_p(aj), Om_p, eps=eps)[:2]
                KL1_ij = kl_gaussian(mu_p_i, S_p_i, mu_j_t, S_j_t)
            kl1_store[(i_id, j_id)] = np.asarray(KL1_ij, np.float32)

            # KL2 (β-basis)
            # For any basis that touches Q, we need Ω^q_ij; compute once
            Om_q = Omega(ctx, ai, aj, which="q")
            KL2_ij = _kl2_per_basis(ctx, basis, ai, aj, Om_q=Om_q, Phi_i=Phi_i, Phit_i=Phit_i, eps=eps)

            # Force scalar-per-pixel by summing any trailing dims
            if KL2_ij.shape != Sshape:
                if KL2_ij.shape[:len(Sshape)] == Sshape and KL2_ij.ndim > len(Sshape):
                    KL2_ij = KL2_ij.reshape(Sshape + (-1,)).sum(axis=-1)
                else:
                    raise ValueError(f"KL2 dims {KL2_ij.shape} incompatible with {Sshape}")

            # logits / storage
            logit = np.where(joint, -KL2_ij / kappa, -np.inf)
            logits_list.append(logit)
            mask_list.append(joint)
            send_ids.append(j_id)
            kl2_store[(which, i_id, j_id)] = np.where(joint, KL2_ij, 0.0).astype(np.float32, copy=False)

        if not send_ids:
            continue

        L = np.stack(logits_list, axis=0)  # (J,*S)
        M = np.stack(mask_list,   axis=0)  # (J,*S)
        W = _softmax_over_senders(L, M, tiny=1e-12)      # (J,*S)

        # write back per sender
        for s, j_id in enumerate(send_ids):
            beta_ij = np.where(mask_list[s], W[s], 0.0).astype(np.float32, order="C")
            _assert_finite("beta", beta_ij, f"(i={i_id}, j={j_id})")
            ctx._edge_beta[(which, i_id, j_id)] = beta_ij
            ctx._edge_kl2[(which, i_id, j_id)]  = kl2_store[(which, i_id, j_id)]
            ctx._edge_kl1[(which, i_id, j_id)]  = kl1_store[(i_id, j_id)]

    return ctx  # convenient for chaining/tests













