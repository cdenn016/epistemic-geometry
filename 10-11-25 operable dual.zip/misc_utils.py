# -*- coding: utf-8 -*-
"""
Created on Fri Oct 10 09:49:37 2025

@author: chris and christine
"""



def _mu_mag(x: np.ndarray) -> float:
    # mean L2 over spatial sites
    xr = x.reshape(-1, x.shape[-1])
    return float(np.mean(np.linalg.norm(xr, axis=-1)))

def _S_mag(S: np.ndarray) -> float:
    # mean Frobenius over spatial sites
    Sr = S.reshape(-1, S.shape[-2]*S.shape[-1])
    return float(np.mean(np.linalg.norm(Sr, axis=-1)))

def _assert_finite(tag, *arrs):
    for a in arrs:
        if not np.all(np.isfinite(a)):
            raise FloatingPointError(f"[{tag}] non-finite in beta grads")



def _print_vec(label: str, dmu: np.ndarray, dS: np.ndarray):
    
    dbg = False
    if not dbg: 
        return
    print(f"[μΣ MAG] {label:<18} | μ_meanL2={_mu_mag(dmu):.3e}  Σ_meanF={_S_mag(dS):.3e}", flush=True)




_TINY32 = np.finfo(np.float32).tiny
_LOG_TINY64 = np.log(np.finfo(np.float64).tiny)

def _to32_no_underflow(x):
    x64 = np.asarray(x, dtype=np.float64)
    with np.errstate(under='ignore'):
        x64 = np.where(np.abs(x64) < _TINY32, 0.0, x64)
        return x64.astype(np.float32, copy=False)


def get_edge_fields(ctx, which: str, i: int, j: int):
    """Return (beta_ij, KL1_ij) arrays stored by compute_edge_betas."""
    try:
        b = ctx._edge_beta[(which, i, j)]
        k = ctx._edge_kl1 [(which, i, j)]
    except KeyError as e:
        raise RuntimeError(f"get_edge_fields: missing {(which,i,j)}: {e}")
    return b, k



def assert_finite(tag, *arrs):
    for a in arrs:
        if not np.all(np.isfinite(a)):
            raise FloatingPointError(f"[{tag}] non-finite in beta grads")




def _compose_R_and_assert(Phi_i: np.ndarray, Om: np.ndarray, *, i_id: int, j_id: int):
    import numpy as np
    # 1) shape sanity
    assert Phi_i.shape[-1] == Om.shape[-2], \
        f"shape mismatch: Phi_i{Phi_i.shape} @ Om{Om.shape} (i={i_id}, j={j_id})"

    # 2) compose
    R = np.einsum("...ik,...kj->...ij", Phi_i, Om, optimize=True)

    # 3) hard fail *before* any norms if non-finite
    _assert_finite("R", R, f"(i={i_id}, j={j_id})")

    # 4) batch opnorm for logging
    A = np.asarray(R, np.float64)
    *batch, m, n = A.shape
    Ar = A.reshape(-1, m, n)
    smax = []
    for k in range(Ar.shape[0]):
        s = np.linalg.svd(Ar[k], compute_uv=False)
        if s.size:
            smax.append(float(s[0]))
    op_R = float(np.mean(smax)) if smax else float("nan")
    return R, op_R



# ──────────────────────────────────────────────────────────────────────────────
# Small utilities (kept private)
# ──────────────────────────────────────────────────────────────────────────────

def _first_bad_idx(X: np.ndarray):
    bad = ~np.isfinite(np.asarray(X))
    if not bad.any():
        return None
    # drop last two dims which are matrix axes when present
    idx = tuple(np.argwhere(bad)[0])
    if len(idx) >= 2:
        return tuple(idx[:-2])
    return tuple(idx)


def _assert_finite(name: str, X: np.ndarray, ctx_str: str = ""):
    if not np.isfinite(np.asarray(X)).all():
        idx = _first_bad_idx(X)
        raise RuntimeError(f"[{name}] non-finite at voxel={idx} {ctx_str}")


def _safe_mask(arr, mask):
    # Broadcast mask to arr.shape, return float mask
    m = np.asarray(mask)
    if m.shape != arr.shape:
        m = np.broadcast_to(m, arr.shape)
    return m.astype(np.float32, copy=False)



def _zeros_mu_S_like(mu):
    mu = np.asarray(mu, np.float32)
    S  = mu.shape[:-1]
    K  = mu.shape[-1]
    return (np.zeros(S + (K,),    np.float32),
            np.zeros(S + (K, K), np.float32))





def _assert_finite(tag, *arrs):
    for a in arrs:
        if not np.all(np.isfinite(a)):
            raise FloatingPointError(f"[{tag}] non-finite in beta grads")




def _fiber_accessors(which: str):
    """Return closures to get μ, Σ, and mask for active fiber, plus q/p helpers."""
    if which not in ("q", "p"):
        raise ValueError("_fiber_accessors: which must be 'q' or 'p'")

    def _mu(a):
        return np.asarray(getattr(a, "mu_q_field" if which == "q" else "mu_p_field"), np.float32)

    def _S(a):
        base = getattr(a, "sigma_q_field" if which == "q" else "sigma_p_field")
        return sanitize_sigma(np.asarray(base, np.float64))

    def _mask(a):
        m = np.asarray(getattr(a, "mask"), np.float32)
        if m.ndim >= 1 and m.shape[-1] == 1:
            m = m[..., 0]
        return m

    # helpers for the "other" fiber (used by A–D bases)
    def _mu_q(a): return np.asarray(getattr(a, "mu_q_field"), np.float32)
    def _S_q(a):  return sanitize_sigma(np.asarray(getattr(a, "sigma_q_field"), np.float64))
    def _mu_p(a): return np.asarray(getattr(a, "mu_p_field"), np.float32)
    def _S_p(a):  return sanitize_sigma(np.asarray(getattr(a, "sigma_p_field"), np.float64))

    return _mu, _S, _mask, _mu_q, _S_q, _mu_p, _S_p


def _beta_cfg(ctx, which: str):
    basis = str(cfg_get(ctx, f"beta_{which}", "align_q" if which == "q" else "align_p")).lower()
    kappa = float(cfg_get(ctx, f"beta_kappa_{which}", 1.0))
    eps   = float(cfg_get(ctx, "obs_beta_eps", 1e-12))
    tau   = float(cfg_get(ctx, "support_tau", 1e-6))
    return basis, max(kappa, 1e-12), eps, tau
