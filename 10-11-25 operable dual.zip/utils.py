from __future__ import annotations
"""
Created on Sun Sep 14 14:24:12 2025

@author: chris and christine
"""

import numpy as np
from core.numerical_utils import safe_inv, sanitize_sigma, push_gaussian, safe_omega_inv
from typing import Any
import os, pickle
import json, pathlib


def _add_to_inbox(agent, which, add_mu, add_S, mask):
    """Enqueue sender-side alignment grads into agent's inbox (no projection)."""
    mu_key = "inbox_align_mu_q" if which == "q" else "inbox_align_mu_p"
    S_key  = "inbox_align_S_q"  if which == "q" else "inbox_align_S_p"

    # lazy init on first use
    if getattr(agent, mu_key, None) is None:
        base_mu = getattr(agent, "mu_q_field" if which == "q" else "mu_p_field")
        setattr(agent, mu_key, np.zeros_like(base_mu, dtype=np.float32))
    if getattr(agent, S_key, None) is None:
        base_S = getattr(agent, "sigma_q_field" if which == "q" else "sigma_p_field")
        setattr(agent, S_key, np.zeros_like(base_S, dtype=np.float32))

    # scatter-add only where overlap is true
    inbox_mu = getattr(agent, mu_key)
    inbox_S  = getattr(agent, S_key)
    inbox_mu[mask] += add_mu[mask]
    inbox_S [mask] += add_S [mask]

def _drain_inbox_into_dalign(agent, which, dmu_align, dS_align):
    """Pull any queued sender grads into receiver's running align grads, then clear."""
    mu_key = "inbox_align_mu_q" if which == "q" else "inbox_align_mu_p"
    S_key  = "inbox_align_S_q"  if which == "q" else "inbox_align_S_p"
    have_mu = getattr(agent, mu_key, None)
    have_S  = getattr(agent, S_key, None)
    if have_mu is not None:
        dmu_align += have_mu.astype(np.float32, copy=False)
        setattr(agent, mu_key, None)    # clear
    if have_S is not None:
        dS_align  += have_S.astype(np.float32, copy=False)
        setattr(agent, S_key, None)     # clear
    return dmu_align, dS_align



def _pre_checkpoint_cleanup(agents):
    """
    Drop/clear large transient caches so checkpoints stay small.
    Calls common methods if present; otherwise clears known attributes.
    Safe no-ops if attributes/methods don't exist.
    """
    for A in agents:
        # Try explicit compactors first
        for meth in (
            "compact_for_checkpoint",
            "clear_omega_cache",
            "clear_fisher_caches",
            "clear_transport_cache",
            "clear_theta_cache",
            "clear_misc_cache",
        ):
            if hasattr(A, meth):
                try:
                    getattr(A, meth)()
                except Exception:
                    pass

        # Then try to clear/delete typical cache attributes
        for attr in (
            "omega_cache",
            "fisher_cache",
            "transport_cache",
            "theta_cache",
            "misc_cache",
        ):
            if hasattr(A, attr):
                try:
                    obj = getattr(A, attr)
                    if hasattr(obj, "clear"):
                        obj.clear()
                    else:
                        setattr(A, attr, None)
                except Exception:
                    pass




def _extract_global_from_Q(Q) -> dict:
    """
    Accepts a dict-like or object 'Q' from compute_total_action(...) and
    returns ONLY numeric fields for logging. Skips strings/bools and metadata.
    Also supports tiny dicts like {'value': 1.23, 'w': 1, 'src': 'cached'}.
    """
   
    import numbers as _numbers

    def _is_num(x):
        # true for Python/NumPy numbers, false for bools
        if isinstance(x, (bool, np.bool_)):
            return False
        return isinstance(x, _numbers.Number) or (isinstance(x, np.generic) and np.issubdtype(type(x), np.number))

    def _coerce_num(x):
        # dict with 'value' → extract; tuple/list → first numeric element; else None
        if _is_num(x):
            return float(x)
        if isinstance(x, dict) and "value" in x and _is_num(x["value"]):
            return float(x["value"])
        if isinstance(x, (list, tuple)) and len(x) > 0 and _is_num(x[0]):
            return float(x[0])
        return None

    out = {}
    if Q is None:
        return out

    if isinstance(Q, dict):
        for k, v in Q.items():
            val = _coerce_num(v)
            if val is not None:
                out[k] = val
        return out

    # object-like fallback: pick common attributes if numeric
    for k in ("Action_total","Geom_total","VFE_acc","A_curv","A_cov","ModelPrior","Curv","Frame","Comm_KL","Transp_KL"):
        if hasattr(Q, k):
            val = _coerce_num(getattr(Q, k))
            if val is not None:
                out[k] = val
    return out





def log_and_viz_after_step(runtime_ctx, agents, step, outdir,
                           parent_metrics, metric_log, num_cores,
                           precomputed_metrics=None,     # <-- NEW
                           precomputed_Q=None):          # <-- NEW
    
    ctx = runtime_ctx
    from diagnostics import compute_global_metrics, print_energy_breakdown, total_energy
    cfg = getattr(ctx, "step_cfg", None)
    print_energy_every = int(getattr(cfg, "print_energy_every", 1) or 1)
    log_metrics_every  = int(getattr(cfg, "log_metrics_every", 1) or 1)

    rid   = int(getattr(ctx, "run_id", 1))
    rname = str(getattr(ctx, "run_label", f"run {rid}"))

    # ---- 1) reuse precomputed metrics OR compute once ----
    mg = precomputed_metrics
    if mg is None:
        mg = compute_global_metrics(ctx, agents)

    # optional formatted breakdown
    if (step % print_energy_every) == 0:
        print_energy_breakdown(ctx, mg)

    # ---- 2) reuse precomputed Q OR compute from metrics (no recompute of metrics) ----
    if precomputed_Q is None:
        E, terms = total_energy(ctx, agents, return_breakdown=True,
                                precomputed_metrics=mg)
        Q = {"Action_total": float(E), **terms}
    else:
        Q = dict(precomputed_Q)

    # ---- 3) append to metric_log (throttled) ----
# ---- 3) append to metric_log (throttled) ----
    if (step % log_metrics_every) == 0:
        metric_log.append({
            "run_id": rid,
            "run_name": rname,
            "run_label": rname,
            "step": int(getattr(ctx, "global_step", step)),
    
            "E_total":    float(Q.get("Action_total", 0.0)),
            "mean_total": float(mg.get("mean_total", 0.0)),
    
            # Weighted sums actually used in the action:
            "self_sum":       float(mg.get("self_sum_w",     mg.get("self_sum", 0.0))),
            "feedback_sum":   float(mg.get("feedback_sum_w", mg.get("feedback_sum", 0.0))),
            "align_q_sum":    float(mg.get("align_q_sum_w",  mg.get("align_q_sum", 0.0))),
            "align_p_sum":    float(mg.get("align_p_sum_w",  mg.get("align_p_sum", 0.0))),
            
        })





def load_checkpoint(outdir: str):
    # prefer compressed if present
    for name in ("checkpoint.pkl.xz", "checkpoint.pkl.gz", "checkpoint.pkl"):
        p = os.path.join(outdir, name)
        if os.path.exists(p):
            if name.endswith(".xz"):
                import lzma
                with lzma.open(p, "rb") as f:
                    return pickle.load(f), name
            if name.endswith(".gz"):
                import gzip
                with gzip.open(p, "rb") as f:
                    return pickle.load(f), name
            with open(p, "rb") as f:
                return pickle.load(f), name

    # fall back to last step_XXXX
    step_files = sorted(
        f for f in os.listdir(outdir)
        if f.startswith("step_") and (f.endswith(".pkl") or f.endswith(".pkl.xz") or f.endswith(".pkl.gz"))
    )
    if not step_files:
        return (None, None)
    last = step_files[-1]
    p = os.path.join(outdir, last)
    if last.endswith(".xz"):
        import lzma
        with lzma.open(p, "rb") as f:
            return pickle.load(f), last
    if last.endswith(".gz"):
        import gzip
        with gzip.open(p, "rb") as f:
            return pickle.load(f), last
    with open(p, "rb") as f:
        return pickle.load(f), last


def find_resume_step(outdir: str) -> int:
    step_files = sorted(
        f for f in os.listdir(outdir)
        if f.startswith("step_") and (f.endswith(".pkl") or f.endswith(".pkl.xz") or f.endswith(".pkl.gz"))
    )
    if not step_files:
        return 0
    last = step_files[-1]
    num = (last.replace("step_", "")
               .replace(".pkl.xz", "")
               .replace(".pkl.gz", "")
               .replace(".pkl", ""))
    try:
        return int(num) + 1
    except Exception:
        return 0





# ------------------------------ Generator prep ------------------------------

# ------------------------------ Generator prep ------------------------------
def prepare_generators(ctx):
    """
    Resolve (Gq, Gp) in canonical shape (3, K, K), float32.

    Priority:
     
      1) SO(3) specs:    spec_q / spec_p (+ optional mix_generators_q / mix_generators_p)

    Side effect: writes K_q, K_p into ctx.config (runtime-scoped).
    """
    from core.get_generators import make_reducible_generators
    from runtime_context import cfg_get
    spec_q = cfg_get(ctx, "spec_q", None)
    spec_p = cfg_get(ctx, "spec_p", None)
        
    if (spec_q is None) or (spec_p is None):
        raise ValueError(
            "prepare_generators: provide either "
            "generators_q/generators_p, or so3_spec_q/so3_spec_p, "
            "or spec_q/spec_p in ctx/config."
        )
    mix_q = bool(cfg_get(ctx, "mix_generators_q", False))
    mix_p = bool(cfg_get(ctx, "mix_generators_p", False))
    
    Gq = make_reducible_generators(spec_q, mix=mix_q).astype(np.float32, copy=False)
    Gp = make_reducible_generators(spec_p, mix=mix_p).astype(np.float32, copy=False)
   
    # ---- record K into ctx.config (runtime-scoped) ----
    Kq, Kp = int(Gq.shape[1]), int(Gp.shape[1])
    rcfg = dict(getattr(ctx, "config", {}) or {})
    rcfg["K_q"] = Kq
    rcfg["K_p"] = Kp
    ctx.config = rcfg

    return Gq, Gp



# -------------------------- Init / resume helpers ---------------------------
def initialize_or_resume(outdir: str, resume: bool, runtime_ctx, clear_agent_logs: bool = True):
    """
    Initialize a fresh run or resume from checkpoints.
    Returns: (agents, step_start)
    """
    from core.agent_initialization import initialize_agents
    import core.config as config
    from runtime_context import cfg_get
    
    if resume:
        agents, _ = load_checkpoint(outdir)
        step_start = find_resume_step(outdir)
        return agents, int(step_start)

    # ---------- fresh init ----------
    if clear_agent_logs and os.path.isdir(outdir):
        # optional: wipe agent logs or temp dirs specific to a fresh start
        pass

    # Generators must be available; prefer those already persisted on ctx
    G_q = cfg_get(runtime_ctx, "generators_q", None)
    G_p = cfg_get(runtime_ctx, "generators_p", None)
    if (G_q is None) or (G_p is None):
        # compute from ctx-config and persist
        G_q, G_p = prepare_generators(runtime_ctx)
        rcfg = dict(getattr(runtime_ctx, "config", {}) or {})
        rcfg["generators_q"] = G_q
        rcfg["generators_p"] = G_p
        runtime_ctx.config = rcfg

    # ---- N-D domain size ----
    
    S_run = cfg_get(runtime_ctx, "domain_size", 0)
    # coerce to tuple of ints
   
    agents = initialize_agents(
        seed=cfg_get(runtime_ctx, "agent_seed", 0),
        domain_size=S_run,                     
        N=cfg_get(runtime_ctx, "N", config.N),
        lie_algebra_dim=cfg_get(runtime_ctx, "lie_algebra_dim", 3),
        fixed_location=cfg_get(runtime_ctx, "fixed_location", True),
        generators_q=G_q,
        generators_p=G_p,
    )

    step_start = 0
    return agents, step_start



def save_step(agents, outdir, step, *, save_every=1, compress=True):
    import os, pickle
    os.makedirs(outdir, exist_ok=True)
    if step is not None and (step % int(save_every)) != 0:
        return

    # prune big transient state before serializing
    try:
        _pre_checkpoint_cleanup(agents)
    except Exception:
        pass

    base = os.path.join(outdir, f"step_{(step if step is not None else 0):04d}.pkl")

    if compress:
        # Try LZMA first (lower preset for smaller working set), then fall back to gzip.
        try:
            import lzma
            with lzma.open(base + ".xz", "wb", preset=2) as f:  # preset=2 keeps memory modest
                pickle.dump(agents, f, protocol=pickle.HIGHEST_PROTOCOL)
            return
        except MemoryError:
            # Fall back to gzip (much smaller memory overhead) and still continue the run.
            import gzip
            with gzip.open(base + ".gz", "wb", compresslevel=1) as f:
                pickle.dump(agents, f, protocol=pickle.HIGHEST_PROTOCOL)
            return

    # Uncompressed as last resort
    with open(base, "wb") as f:
        pickle.dump(agents, f, protocol=pickle.HIGHEST_PROTOCOL)


  

def _write_metric_artifacts(outdir: str, metric_log: list[dict]):
    if not metric_log: return
    out = pathlib.Path(outdir)
    out.mkdir(parents=True, exist_ok=True)
    # pickle (legacy) + jsonl (human/tooling-friendly)
    with open(out / "metric_log.pkl", "wb") as f:
        pickle.dump(metric_log, f, protocol=pickle.HIGHEST_PROTOCOL)
    with open(out / "metrics.jsonl", "w", encoding="utf-8") as f:
        for rec in metric_log:
            f.write(json.dumps(rec, ensure_ascii=False) + "\n")

def wrap_epilogue(runtime_ctx, agents, outdir, parent_metrics, metric_log):
    # flush metrics & a lightweight “run.json” context stub
    try:
        _write_metric_artifacts(outdir, metric_log or [])
        with open(os.path.join(outdir, "run.json"), "w", encoding="utf-8") as f:
            json.dump({
                "steps": int(getattr(getattr(runtime_ctx, "config", {}), "steps", len(metric_log)) 
                             if hasattr(runtime_ctx, "config") else len(metric_log)),
                "global_step": int(getattr(runtime_ctx, "global_step", -1)),
            }, f)
    except Exception as e:
        print(f"[WRAP] failed to write artifacts: {e}")










# =========================
# Basic, stable miscellany
# =========================


def _aid(a: Any) -> int:
    """Stable agent id (required)."""
    aid = getattr(a, "id", None)
    if aid is None:
        raise ValueError("[transport_cache] agent is missing a stable `id`")
    return int(aid)



def _safe_vector_norm(x: np.ndarray) -> np.ndarray:
    """
    Robust vector 2-norm along the last axis, tolerant to underflow.
    Uses float64 and hypot (when small last-dim) to avoid tiny* tiny raises.
    Returns an array of norms (same shape as x without the last axis).
    """
    x = np.asarray(x)
    if x.ndim == 0:
        return np.abs(x.astype(np.float64))

    # Prefer hypot for 2D/3D vectors (most common in your fields)
    with np.errstate(under='ignore', over='ignore', invalid='ignore'):
        if x.shape[-1] == 2:
            a = x[..., 0].astype(np.float64, copy=False)
            b = x[..., 1].astype(np.float64, copy=False)
            return np.hypot(a, b)
        elif x.shape[-1] == 3:
            a = x[..., 0].astype(np.float64, copy=False)
            b = x[..., 1].astype(np.float64, copy=False)
            c = x[..., 2].astype(np.float64, copy=False)
            return np.hypot(np.hypot(a, b), c)
        else:
            # General case: float64 accumulation; safe underflow handling
            x64 = x.astype(np.float64, copy=False)
            # sum(..., dtype=float64) keeps the accumulator wide
            return np.sqrt(np.sum(x64 * x64, axis=-1, dtype=np.float64))


def mean_norm(x) -> float:
    """
    Mean 2-norm along the last axis, NaN-safe, and underflow-safe.
    Returns 0.0 if there are no finite entries (so plots don’t disappear).
    """
    if x is None:
        return 0.0
    n = _safe_vector_norm(x)
    n = np.asarray(n, dtype=np.float64)
    m = np.isfinite(n)
    if not np.any(m):
        
        return 0.0
    return float(np.mean(n[m]))



def _check_finite(name, x):
    if not np.all(np.isfinite(x)):
        n_nan = int(np.isnan(x).sum())
        n_inf = int(np.isinf(x).sum())
        raise FloatingPointError(f"[vfe_mu_sigma_grads] {name} has non-finite values "
                                 f"(nan={n_nan}, inf={n_inf}).")



# =========================
#         Masks
# =========================




# --- MASKS ---------------------------------------------------------------

def make_soft_mask(
    center: tuple[int, ...] | int | None,
    radius: float | tuple[float, ...],
    domain_size: tuple[int, ...],
    *,
    cutoff: float | None = None,       # interpreted as support_tau (0<τ<1)
    dtype: np.dtype | None = None,
    return_bool: bool = False,
    feather: float | None = None,      # optional smooth ramp half-width in px
    soft_cut: bool = True,             # use smooth ramp instead of hard zeroing
):
    """
    N-D soft (Gaussian-like) mask on a periodic hypercube.
    m(x) = exp( - sum_d (δ_d / r_d)^2 ), with periodic min-image δ_d.

    radius semantics:
      - r_d is the 1/e falloff radius along axis d, i.e. m=exp(-1) at |δ_d|=r_d.
      - If you want m=cutoff at |δ|=R, pass r = R / sqrt(log(1/cutoff)).

    If soft_cut=True and feather>0, a smoothstep is used around 'cutoff' to avoid kinks.
    """
    import numpy as np
    import core.config as _config

    S = tuple(int(s) for s in domain_size)
    D = len(S)

    if dtype is None:
        dtype = getattr(_config, "dtype", np.float64)

    if cutoff is None:
        cutoff = float(getattr(_config, "support_tau", 1e-6))
    cutoff = float(cutoff)

    # ---- normalize center (periodic) ----
    if center is None:
        c = tuple(s // 2 for s in S)
    elif np.isscalar(center):
        c = (int(center),) * D
    else:
        c = tuple(int(x) for x in center)
        if len(c) < D:
            c = tuple(c) + tuple(S[i] // 2 for i in range(len(c), D))
        elif len(c) > D:
            c = tuple(c[:D])
    c = tuple((ci % si) for ci, si in zip(c, S))

    # ---- normalize radius ----
    if np.isscalar(radius):
        r = (float(radius),) * D
    else:
        r = tuple(float(x) for x in radius)
        if len(r) < D:
            r = tuple(r) + (float(r[-1]),) * (D - len(r))
        elif len(r) > D:
            r = tuple(r[:D])
    eps = np.finfo(dtype).eps
    r = tuple(max(abs(x), eps) for x in r)

    # ---- build min-image squared distance in scaled coords ----
    grids = np.ogrid[tuple(slice(0, s) for s in S)]
    rho2 = 0.0
    for d in range(D):
        g = grids[d]
        sz = S[d]
        delta = np.abs(g - c[d])
        delta = np.minimum(delta, sz - delta)   # periodic min-image
        rho2 = rho2 + (delta / r[d])**2

    m = np.exp(-rho2, dtype=dtype).astype(dtype, copy=False)

    # ---- soft or hard cutoff ----
    if soft_cut and cutoff > 0.0:
        # Smoothly push values below cutoff towards 0 over a 'feather' band.
        # If feather is None, pick a default so that the 10–90% transition spans ~feather px.
        # Use a smoothstep on the *value* axis (not distance) for simplicity:
        #   t = clamp((m - (cutoff - δ)) / (2δ), 0, 1); m <- m * (3t^2 - 2t^3)
        # Choose δ so transition width is gentle in value-space.
        delta_val = 0.5 * (1.0 - cutoff) if feather is None else min(0.49, float(feather))
        lo = max(0.0, cutoff - delta_val)
        hi = min(1.0, cutoff + delta_val)
        # normalize to [0,1]
        t = (m - lo) / max(1e-12, (hi - lo))
        t = np.clip(t, 0.0, 1.0)
        smooth = t*t*(3.0 - 2.0*t)   # C1 smoothstep
        m = m * smooth
    elif (not soft_cut) and cutoff > 0.0:
        m = np.where(m < cutoff, 0.0, m)

    m = m.astype(dtype, copy=False)

    if return_bool:
        # boolean support relative to cutoff
        return m, (m > cutoff)
    return m




def _joint_mask(a, b, *, tau: float, as_vector: bool = True):
    """
    Joint support of two agents' masks (broadcast-safe, N-D).
    Returns:
      - (*S,1) float32 if as_vector=True  (legacy "float3"-style channel)
      - (*S,)  bool    if as_vector=False
    """
    ma = mask_hw(a, tau=tau, mode="bool2")   # (*S_a,) bool
    mb = mask_hw(b, tau=tau, mode="bool2")   # (*S_b,) bool

    # Broadcast to common spatial shape S
    try:
        S = np.broadcast(ma, mb).shape
    except Exception as e:
        raise ValueError(f"_joint_mask: shapes not broadcastable: {ma.shape} vs {mb.shape}") from e

    if ma.shape != S:
        ma = np.broadcast_to(ma, S)
    if mb.shape != S:
        mb = np.broadcast_to(mb, S)

    m = ma & mb
    return (m[..., None].astype(np.float32, copy=False)) if as_vector else m


def mask_hw(x, *, tau: float, mode: str = "float3"):
    """
    N-D mask normalizer (broadcast- & dtype-safe).

    Accepts:
      - x.mask or x (array-like), any shape that's per-site or per-site with a singleton channel
        e.g. (*S,), (*S,1). (Legacy name kept for compatibility.)

    Modes:
      - "bool2"  -> (*S,)   bool
      - "float3" -> (*S,1)  float32  (good for broadcasting with per-site vectors)
      - "vec"    -> (|S|,)  bool (raveled)
    """
    m = getattr(x, "mask", x)
    m = np.asarray(m)

    # Squeeze a singleton channel if present
    if m.ndim >= 1 and m.shape[-1] == 1:
        m = m[..., 0]

    # Scalar fallback (rare): promote to 1-D
    if m.ndim == 0:
        m = m.reshape(1)

    # Validate finiteness if float/integers
    if np.issubdtype(m.dtype, np.floating) or np.issubdtype(m.dtype, np.integer):
        if not np.isfinite(m).all():
            n_bad = int(m.size - np.isfinite(m).sum())
            raise FloatingPointError(f"mask_hw: non-finite values in mask ({n_bad} cells).")

    # Threshold to bool support if not already boolean
    mb = m if (m.dtype == bool) else (m.astype(np.float32, copy=False) > float(tau))

    if mode == "bool2":
        return mb.astype(bool, copy=False)
    if mode == "float3":
        return mb.astype(np.float32, copy=False)[..., None]
    if mode == "vec":
        return mb.astype(bool, copy=False).ravel()

    raise ValueError(f"mask_hw: unknown mode={mode!r}")



def get_neighbors(agent_i, agents, *, dedup=True, exclude_self=True):
    """
    Resolve agent_i.neighbors -> list[Agent].
    Supports neighbors as dicts with 'id' or raw ints.
    Works with `agents` as a list (id taken from agent.id or index)
    or as a dict keyed by id.
    """
    raw = getattr(agent_i, "neighbors", []) or []

    # Build lookup once
    if isinstance(agents, dict):
        lookup = {int(k): v for k, v in agents.items()}
    else:
        lookup = {int(getattr(a, "id", i)): a for i, a in enumerate(agents)}

    out, seen = [], set()
    self_id = int(getattr(agent_i, "id", -1))

    for nb in raw:
        # accept {"id": ...} or int id
        try:
            j = int(nb["id"]) if isinstance(nb, dict) else int(nb)
        except Exception:
            continue

        if exclude_self and j == self_id:
            continue
        if dedup and j in seen:
            continue

        a = lookup.get(j)
        if a is not None:
            out.append(a)
            if dedup:
                seen.add(j)

    return out



def push_stats_qj_to_qi(ctx, agent_i, agent_j, *, Omega_ij=None, eps=1e-8):
    from core.transport_cache import Omega
    Om_q = np.asarray(Omega_ij if Omega_ij is not None else Omega(ctx, agent_i, agent_j, which="q"), np.float32)
    return push_neighbor_stats(agent_j, "sigma_q_field", Om_q, eps)

def push_stats_pj_to_pi(ctx, agent_i, agent_j, *, Omega_ij=None, eps=1e-8):
    from core.transport_cache import Omega
    Om_p = np.asarray(Omega_ij if Omega_ij is not None else Omega(ctx, agent_i, agent_j, which="p"), np.float32)
    return push_neighbor_stats(agent_j, "sigma_p_field", Om_p, eps)


def push_neighbor_stats(agent_j, sigma_key: str, Omega_ij: np.ndarray, eps: float):
    """
    Returns (mu_j_t, Sigma_j_t, Sigma_j_t_inv) in agent-i frame.
    Fast-path tries inverse-push of precision; fallback pushes covariance.
    """
    mu_j = np.asarray(getattr(agent_j, sigma_key.replace("sigma", "mu")), np.float32)

    inv_key = sigma_key.replace("_field", "_inv")
    S_inv = getattr(agent_j, inv_key, None)

    # Try inverse-push of precision first
    if S_inv is not None:
        S_inv = np.asarray(S_inv, np.float32)
        if S_inv.size and np.all(np.isfinite(S_inv)):
            Oinv   = safe_omega_inv(Omega_ij, eps=1e-6)
            Oinv_T = np.swapaxes(Oinv, -1, -2)
            S_inv_t = np.einsum("...ik,...kl,...jl->...ij", Oinv_T, S_inv, Oinv, optimize=True)

            # Build Σ_j→i once (stable): (S_inv_t)^{-1}
            Sigma_t = safe_inv(sanitize_sigma(S_inv_t), eps=max(eps, 1e-12))

            mu_t = np.einsum("...ij,...j->...i", Omega_ij, mu_j, optimize=True)
            return mu_t.astype(np.float32, copy=False), Sigma_t.astype(np.float32, copy=False), S_inv_t.astype(np.float32, copy=False)

    # Fallback: push covariance then invert once
    Sigma_j = sanitize_sigma(np.asarray(getattr(agent_j, sigma_key), np.float32), eps=eps)
    mu_t, Sigma_t, Sigma_t_inv = push_gaussian(
        mu=mu_j, Sigma=Sigma_j, M=Omega_ij, eps=eps,
        return_inv=True, assume_orthogonal=True, sanitize_input=False
    )
    return mu_t.astype(np.float32, copy=False), Sigma_t.astype(np.float32, copy=False), Sigma_t_inv.astype(np.float32, copy=False)




def zero_all_gradients(agent):
    """
    Zero (and if missing, create) all gradient buffers,
    keeping legacy aliases in sync and ensuring arrays are writeable.
    """
    def ensure_buf(name, like):
        arr = getattr(agent, name, None)
        if arr is None and like is not None:
            arr = np.zeros_like(like)
        elif arr is not None and not arr.flags.writeable:
            arr = np.array(arr, copy=True)
        setattr(agent, name, arr)
        return arr

    # Canonical grads (create from fields if needed)
    g_mu_q   = ensure_buf("grad_mu_q",    getattr(agent, "mu_q_field", None))
    g_sg_q   = ensure_buf("grad_sigma_q", getattr(agent, "sigma_q_field", None))
    g_mu_p   = ensure_buf("grad_mu_p",    getattr(agent, "mu_p_field", None))
    g_sg_p   = ensure_buf("grad_sigma_p", getattr(agent, "sigma_p_field", None))
    g_phi    = ensure_buf("grad_phi",       getattr(agent, "phi", None))
    g_phit   = ensure_buf("grad_phi_tilde", getattr(agent, "phi_model", None))
 
    # Keep legacy aliases in sync (as references, not copies)
    if g_mu_q is not None:
        agent.grad_mu_q_field = g_mu_q
    if g_sg_q is not None:
        agent.grad_sigma_q_field = g_sg_q
    if g_mu_p is not None:
        agent.grad_mu_p_field = g_mu_p
    if g_sg_p is not None:
        agent.grad_sigma_p_field = g_sg_p

    # Zero safely
    for arr in (g_mu_q, g_sg_q, g_mu_p, g_sg_p, g_phi, g_phit):
        if isinstance(arr, np.ndarray):
            arr.fill(0)




# =========================
# Linear algebra helpers
# =========================


def _ensure_q_to_p_shape(X, Kp, Kq):
    """Φ0: q→p must be (Kp, Kq). Auto-transpose if (Kq, Kp)."""
    X = np.asarray(X, np.float32)
    if X.shape == (Kp, Kq): return X
    if X.shape == (Kq, Kp): return X.T
    raise ValueError(f"Φ0 wrong shape {X.shape}; expected {(Kp, Kq)} or {(Kq, Kp)}")

def _ensure_p_to_q_shape(X, Kq, Kp):
    """Φ̃0: p→q must be (Kq, Kp). Auto-transpose if (Kp, Kq)."""
    X = np.asarray(X, np.float32)
    if X.shape == (Kq, Kp): return X
    if X.shape == (Kp, Kq): return X.T
    raise ValueError(f"Φ̃0 wrong shape {X.shape}; expected {(Kq, Kp)} or {(Kp, Kq)}")


def _fiber_keys_from_mode(mode: str):
    """Map 'belief'/'model' → fiber and attribute names (q/p)."""
    which = "q" if mode == "belief" else "p"
    field = "phi" if which == "q" else "phi_model"
    mu_key = "mu_q_field" if which == "q" else "mu_p_field"
    S_key  = "sigma_q_field" if which == "q" else "sigma_p_field"
    gmu_key= "grad_mu_q" if which == "q" else "grad_mu_p"
    gS_key = "grad_sigma_q" if which == "q" else "grad_sigma_p"
    return which, field, mu_key, S_key, gmu_key, gS_key


def _iter_overlap_pairs(agent_i, agents, *, tau: float):
    """Yield (agent_j, overlap_mask) for unique undirected neighbors (i<j)."""
    i_id = int(getattr(agent_i, "id", -1))
    for agent_j in get_neighbors(agent_i, agents, dedup=True, exclude_self=True):
        j_id = int(getattr(agent_j, "id", -1))
        if i_id >= j_id:
            continue
        overlap = _joint_mask(agent_i, agent_j, tau=tau, as_vector=False)
        yield agent_j, overlap


def _accumulate_into_agent(agent, gmu_attr: str, gS_attr: str, dmu: np.ndarray, dS: np.ndarray):
    """Create grad buffers if missing and add in-place."""
    if getattr(agent, gmu_attr, None) is None:
        setattr(agent, gmu_attr, np.zeros_like(dmu, dtype=np.float32))
    if getattr(agent, gS_attr, None) is None:
        setattr(agent, gS_attr, np.zeros_like(dS, dtype=np.float32))
    setattr(agent, gmu_attr, getattr(agent, gmu_attr) + dmu.astype(np.float32, copy=False))
    setattr(agent, gS_attr,  getattr(agent, gS_attr)  + dS.astype(np.float32, copy=False))




# =========================
# Logging
# =========================

def log_phi_grad_like(aid, field, tag, arr):
    """Compact sign/mean/|g| logging for φ/φ̃ terms."""
    if arr is None: return
    spatial_axes = tuple(range(arr.ndim - 1))
    g_mean = np.mean(arr, axis=spatial_axes)
    sign = "".join("+" if x > 0 else "-" if x < 0 else "0" for x in g_mean.tolist())
    g_abs_mean = float(np.mean(np.abs(arr)))
    print(f"[PHI] field={field} ai={aid} term={tag} "
          f"sign={sign} mean={np.array2string(g_mean, precision=3, suppress_small=True)} "
          f"|g|_mean={g_abs_mean:.3e}", flush=True)







