# -*- coding: utf-8 -*-
"""
Created on Mon Jul 14 13:12:11 2025

@author: chris and christine
"""

# update_transport_terms.py

"""
Gradient of KL(q_i ‖ Ω q_j) or KL(p_i ‖ Ω̃ p_j) w.r.t. φ_i or φ_j
via Lie group backpropagation through Ω = exp(φ).
Used by φ/φ̃ update routines in update_phi_terms.py.
"""

import numpy as np
import config

from generalized_omega import compute_omega_pair, dexpinv_operator, dexpinv_operator_covariance
from numerical_utils import sanitize_sigma, safe_inv


def compute_phi_gradient_via_transport(agent_i, agents, generators, field="phi", params=None):
    """
    Computes the analytic variational gradient ∂KL(fiber_i ‖ Ω_ij fiber_j) / ∂φ^a
    using backprop through Ω = exp(φ), for either belief or model fibers.
    """
    assert field in ("phi", "phi_model")
    d = generators.shape[0]
    K = agent_i.mu_q_field.shape[-1]
    grad_phi = np.zeros_like(agent_i.phi if field == "phi" else agent_i.phi_model)
    soft_mask = agent_i.mask[..., None] > config.support_cutoff_eps

    # Extract options
    if params is None:
        params = {}
    use_dexpinv = params.get("use_dexpinv", getattr(config, "use_dexpinv", False))
    dexpinv_order = params.get("dexpinv_order", getattr(config, "dexpinv_order", 2))
    use_exact = params.get("use_dexpinv_exact", getattr(config, "use_dexpinv_exact", False))

    # Choose fiber and Ω cache
    if field == "phi":
        mu_i = agent_i.mu_q_field
        sigma_i = agent_i.sigma_q_field
        Omega_ij = agent_i.Omega
        β = params.get("beta", getattr(config, "beta", 1.0))
        phi = agent_i.phi
    else:
        mu_i = agent_i.mu_p_field
        sigma_i = agent_i.sigma_p_field
        Omega_ij = agent_i.Omega_model
        β = params.get("model_align_weight", getattr(config, "model_align_weight", 1.0))
        phi = agent_i.phi_model

    Omega_T = np.swapaxes(Omega_ij, -1, -2)  # precompute once

    for neighbor in agent_i.neighbors:
        agent_j = agents[neighbor["id"]]

        if field == "phi":
            mu_j = agent_j.mu_q_field
            sigma_j = agent_j.sigma_q_field
        else:
            mu_j = agent_j.mu_p_field
            sigma_j = agent_j.sigma_p_field

        # Transport neighbor distribution
        mu_trans = np.einsum("...kl,...l->...k", Omega_ij, mu_j)
        sigma_trans = np.einsum("...km,...mn,...nl->...kl", Omega_ij, sigma_j, Omega_T)
        sigma_trans = sanitize_sigma(sigma_trans, eps=config.eps)
        sigma_inv = safe_inv(sigma_trans, eps=config.eps)

        delta_mu = mu_i - mu_trans
        d_mu = -np.einsum("...ij,...j->...i", sigma_inv, delta_mu)

        delta_sigma = sigma_i - sigma_trans
        d_sigma = -0.5 * np.einsum("...ik,...kl,...lj->...ij", sigma_inv, delta_sigma, sigma_inv)

        # Precompute OG = Ω G_a
        OG_all = np.einsum("...ij,ajk->...aik", Omega_ij, generators)  # (..., d, K)

        # μ term: d(Ω μ_j)/dφ^a = Ω G μ_j
        dφ_mu = np.einsum("...aij,...j->...ai", OG_all, mu_j)  # (..., d)

        # Σ term part 1: Ω G Σ Ωᵀ
        OG_sigma = np.einsum("...aij,...jk->...aik", OG_all, sigma_j)
        dφ_sigma_1 = np.einsum("...aij,...jk->...aik", OG_sigma, Omega_T)

        # Σ term part 2: Ω Σ Gᵀ Ωᵀ
        sigma_G_T = np.einsum("...ij,ajk->...aik", sigma_j, np.transpose(generators, (0,2,1)))
        O_sigma_GT = np.einsum("...ij,...ajk->...aik", Omega_ij, sigma_G_T)
        dφ_sigma_2 = np.einsum("...aij,...jk->...aik", O_sigma_GT, Omega_T)

        dφ_sigma = dφ_sigma_1 + dφ_sigma_2  # (..., d, K, K)

        # Final sum
        delta_a = (
            np.einsum("...i,...ai->...a", d_mu, dφ_mu) +
            np.einsum("...ij,...aij->...a", d_sigma, dφ_sigma)
        )
        grad_phi += delta_a

    if use_dexpinv:
        grad_phi = dexpinv_operator(
            phi=phi,
            delta=grad_phi,
            generators=generators,
            order=dexpinv_order,
            use_exact=use_exact,
        )

    grad_phi *= soft_mask
    grad_phi *= β
    return grad_phi



def compute_phi_gradient_via_transport_old(agent_i, agents, generators, field="phi", params=None):
    """
    Computes the analytic variational gradient ∂KL(fiber_i ‖ Ω_ij fiber_j) / ∂φ^a
    using backprop through Ω = exp(φ), for either belief or model fibers.

    Supports Lie-covariant pushback via dexpinv().

    Args:
        agent_i    : focal agent
        agents     : list of all agents
        generators : (d, K, K) Lie algebra basis
        field      : "phi" (belief) or "phi_model" (model)
        params     : optional dict with overrides:
                     {
                         "use_dexpinv": bool,
                         "dexpinv_order": int,
                         "use_dexpinv_exact": bool
                     }

    Returns:
        grad_phi : (H, W, d) gradient of KL w.r.t. φ^a
    """
    assert field in ("phi", "phi_model")
    d = generators.shape[0]
    K = agent_i.mu_q_field.shape[-1]
    grad_phi = np.zeros_like(agent_i.phi if field == "phi" else agent_i.phi_model)
    soft_mask = agent_i.mask[..., None] > config.support_cutoff_eps

    # Extract options
    if params is None:
        params = {}
    use_dexpinv = params.get("use_dexpinv", getattr(config, "use_dexpinv", False))
    dexpinv_order = params.get("dexpinv_order", getattr(config, "dexpinv_order", 2))
    use_exact = params.get("use_dexpinv_exact", getattr(config, "use_dexpinv_exact", False))

    # Choose fiber and Ω cache
    if field == "phi":
        mu_i = agent_i.mu_q_field
        sigma_i = agent_i.sigma_q_field
        Omega_ij = agent_i.Omega
        β = params.get("beta", getattr(config, "beta", 1.0))
        phi = agent_i.phi
    else:
        mu_i = agent_i.mu_p_field
        sigma_i = agent_i.sigma_p_field
        Omega_ij = agent_i.Omega_model
        β = params.get("model_align_weight", getattr(config, "model_align_weight", 1.0))
        phi = agent_i.phi_model

    for neighbor in agent_i.neighbors:
        agent_j = agents[neighbor["id"]]

        # Select source fiber
        if field == "phi":
            mu_j = agent_j.mu_q_field
            sigma_j = agent_j.sigma_q_field
        else:
            mu_j = agent_j.mu_p_field
            sigma_j = agent_j.sigma_p_field

        # Transport q_j → Ω q_j
        mu_trans = np.einsum("...kl,...l->...k", Omega_ij, mu_j)
        Omega_T = np.swapaxes(Omega_ij, -1, -2)
        sigma_trans = np.einsum("...km,...mn,...nl->...kl", Omega_ij, sigma_j, Omega_T)
        sigma_trans = sanitize_sigma(sigma_trans, eps=config.eps)

        # Invert Σ_trans
        sigma_inv = np.linalg.inv(sigma_trans)

        # KL gradients w.r.t. transported parameters
        delta_mu = mu_i - mu_trans
        d_mu = -np.einsum("...ij,...j->...i", sigma_inv, delta_mu)

        delta_sigma = sigma_i - sigma_trans
        d_sigma = -0.5 * np.einsum("...ik,...kl,...lj->...ij", sigma_inv, delta_sigma, sigma_inv)

        for a in range(d):
            G = generators[a]

            # d(Ω μ_j)/dφ^a = Ω G μ_j
            OG = np.einsum("...ij,jk->...ik", Omega_ij, G)
            dφ_mu = np.einsum("...ij,...j->...i", OG, mu_j)

            # d(Ω Σ_j Ωᵀ)/dφ^a = Ω G Σ Ωᵀ + Ω Σ Gᵀ Ωᵀ
            OG_sigma = np.einsum("...ij,...jk->...ik", OG, sigma_j)
            dφ_sigma_1 = np.einsum("...ij,...jk->...ik", OG_sigma, Omega_T)

            sigma_G_T = np.einsum("...ij,jk->...ik", sigma_j, G.T)
            O_sigma_GT = np.einsum("...ij,...jk->...ik", Omega_ij, sigma_G_T)
            dφ_sigma_2 = np.einsum("...ij,...jk->...ik", O_sigma_GT, Omega_T)

            dφ_sigma = dφ_sigma_1 + dφ_sigma_2

            # Raw Lie gradient
            delta_a = (
                np.sum(d_mu * dφ_mu, axis=-1) +
                np.einsum("...ij,...ij->...", d_sigma, dφ_sigma)
            )

            grad_phi[..., a] += delta_a

    # Apply Lie-backprop correction
    if use_dexpinv:
        grad_phi = dexpinv_operator(
            phi=phi,
            delta=grad_phi,
            generators=generators,
            order=dexpinv_order,
            use_exact=use_exact,
        )

    grad_phi *= soft_mask
    grad_phi *= β
    return grad_phi

def accumulate_phi_gradient(agent_i, agent_j, generators, params, field="phi"):
    """
    Compute and accumulate both variational gradients:
        ∂/∂φ_i KL(q_i ‖ Ω_ij q_j)
        ∂/∂φ_j KL(q_i ‖ Ω_ij q_j)
    where Ω_ij = exp(φ_i) · exp(-φ_j)

    Supports both "phi" (belief) and "phi_model" (model) fields.
    Accumulates gradients directly to agent_i.grad_phi and agent_j.grad_phi.
    """
    from generalized_omega import compute_omega_pair
    from natural_gradient_utils import dexpinv_operator_covariance
    import config
    import numpy as np

    assert field in ("phi", "phi_model")

    # --- Params ---
    beta = params.get("beta", config.beta) if field == "phi" else params.get("model_align_weight", config.model_align_weight)
    if beta <= 0:
        return

    eps = params.get("support_cutoff_eps", config.support_cutoff_eps)
    mask_i = agent_i.mask[..., None] > eps
    mask_j = agent_j.mask[..., None] > eps
    joint_mask = mask_i & mask_j

    # --- Choose fields ---
    mu_i = agent_i.mu_q_field if field == "phi" else agent_i.mu_p_field
    mu_j = agent_j.mu_q_field if field == "phi" else agent_j.mu_p_field
    sigma_i = agent_i.sigma_q_field if field == "phi" else agent_i.sigma_p_field
    sigma_j = agent_j.sigma_q_field if field == "phi" else agent_j.sigma_p_field

    phi_i = agent_i.phi if field == "phi" else agent_i.phi_model
    phi_j = agent_j.phi if field == "phi" else agent_j.phi_model

    # --- Transport operator ---
    Omega_ij = compute_omega_pair(phi_i, phi_j, generators)

    # --- Transport q_j to i ---
    mu_trans = np.einsum("...kl,...l->...k", Omega_ij, mu_j)
    Omega_T = np.swapaxes(Omega_ij, -1, -2)
    sigma_trans = np.einsum("...km,...mn,...nl->...kl", Omega_ij, sigma_j, Omega_T)
    sigma_trans = sanitize_sigma(sigma_trans, eps=config.eps)

    sigma_inv = np.linalg.inv(sigma_trans)
    delta_mu = mu_i - mu_trans
    d_mu = -np.einsum("...ij,...j->...i", sigma_inv, delta_mu)

    delta_sigma = sigma_i - sigma_trans
    d_sigma = -0.5 * np.einsum("...ik,...kl,...lj->...ij", sigma_inv, delta_sigma, sigma_inv)

    d = generators.shape[0]
    grad_phi_i = np.zeros_like(phi_i)
    grad_phi_j = np.zeros_like(phi_j)

    for a in range(d):
        G = generators[a]

        # For phi_i (Ω = exp(φ_i) · exp(-φ_j)) → ∂Ω/∂φ_i = Ω · G
        OG = np.einsum("...ij,jk->...ik", Omega_ij, G)
        dphi_i_mu = np.einsum("...ij,...j->...i", OG, mu_j)

        OG_sigma = np.einsum("...ij,...jk->...ik", OG, sigma_j)
        dphi_i_sigma = np.einsum("...ij,...jk->...ik", OG_sigma, Omega_T) + \
                       np.einsum("...ij,...jk->...ik", Omega_ij, np.einsum("...ij,jk->...ik", sigma_j, G.T)) @ Omega_T

        grad_i_a = (
            np.sum(d_mu * dphi_i_mu, axis=-1) +
            np.einsum("...ij,...ij->...", d_sigma, dphi_i_sigma)
        )

        grad_phi_i[..., a] += grad_i_a

        # For phi_j (∂Ω/∂φ_j = -Ω · G) → same G, flipped sign
        grad_phi_j[..., a] -= grad_i_a

    # Apply (dexp⁻¹)^T operator
    if getattr(config, "use_dexpinv", False):
        grad_phi_i = np.einsum("...ab,...b->...a", dexpinv_operator_covariance(phi_i, transpose=True), grad_phi_i)
        grad_phi_j = np.einsum("...ab,...b->...a", dexpinv_operator_covariance(phi_j, transpose=True), grad_phi_j)

    # Accumulate to agents
    if not hasattr(agent_i, "grad_phi"):
        agent_i.grad_phi = np.zeros_like(phi_i)
    if not hasattr(agent_j, "grad_phi"):
        agent_j.grad_phi = np.zeros_like(phi_j)

    agent_i.grad_phi += beta * grad_phi_i * joint_mask
    agent_j.grad_phi += beta * grad_phi_j * joint_mask