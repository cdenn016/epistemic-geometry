# -*- coding: utf-8 -*-
"""
Created on Thu Jul 17 15:43:25 2025

@author: chris and christine
"""

def compute_phi_update_belief(agent_i, agents, params):
    return _compute_phi_update_core(agent_i, agents, params, field="phi")

def compute_generator_gradients_belief(
    generators, Omega_ij, Phi_ij, mu_j, sigma_j,
    T, T_T, d_mu, d_sigma, shape
):
    """
    Compute ∂/∂φ_i and ∂/∂φ_j of KL[q_i ‖ Ω_ij Φ_ij q_j] in belief space.

    Args:
        generators : (d, K_q, K_q)
        Omega_ij   : (H, W, K_q, K_q)
        Phi_ij     : (H, W, K_p, K_q)
        mu_j       : (H, W, K_p)
        sigma_j    : (H, W, K_p, K_p)
        T, T_T     : (H, W, K_p, K_q), (H, W, K_q, K_p)
        d_mu       : (H, W, K_q)
        d_sigma    : (H, W, K_q, K_q)
        shape      : (H, W, d)

    Returns:
        grad_i, grad_j : (H, W, d)
    """
    d = generators.shape[0]
    grad_i = np.zeros(shape)
    grad_j = np.zeros(shape)

    # Transpose Φ from (K_p, K_q) to (K_q, K_p)
    Phi_T = np.transpose(Phi_ij, (0, 1, 3, 2))  # (H, W, K_q, K_p)

    for a in range(d):
        G = generators[a]  # (K_q, K_q)

        OG = np.einsum("...ij,jk->...ik", Omega_ij, G)             # (H, W, K_q, K_q)
        OG_Phi = np.einsum("...ik,...kj->...ij", OG, Phi_T)        # (H, W, K_q, K_p)

        dphi_mu = np.einsum("...ij,...j->...i", OG_Phi, mu_j)      # (H, W, K_q)

        OG_sigma = np.einsum("...ij,...jk->...ik", OG_Phi, sigma_j)       # (H, W, K_q, K_p)
        dphi_sigma_1 = np.einsum("...ij,...jk->...ik", OG_sigma, T_T)     # (H, W, K_q, K_q)

        sigma_GT = np.einsum("...ij,jk->...ik", sigma_j, G.T)             # (H, W, K_p, K_p)
        O_sigma_GT = np.einsum("...ij,...jk->...ik", T, sigma_GT)         # (H, W, K_q, K_p)
        dphi_sigma_2 = np.einsum("...ij,...jk->...ik", O_sigma_GT, T_T)   # (H, W, K_q, K_q)

        dphi_sigma = dphi_sigma_1 + dphi_sigma_2

        delta_a = (
            np.sum(d_mu * dphi_mu, axis=-1) +
            np.einsum("...ij,...ij->...", d_sigma, dphi_sigma)
        )

        grad_i[..., a] += delta_a
        grad_j[..., a] -= delta_a

    return grad_i, grad_j


def accumulate_phi_gradient_belief(agent_i, agent_j, generators, params):
    """
    Accumulate φ gradient for belief alignment: ∂KL(q_i ‖ Ω_ij Φ_ij q_j)
    """
    beta = params.get("beta", config.beta)
    if beta <= 0:
        return

    joint_mask = compute_joint_mask(agent_i, agent_j, config.support_cutoff_eps)

    mu_i, sigma_i = agent_i.mu_q_field, agent_i.sigma_q_field
    mu_j, sigma_j = agent_j.mu_q_field_original, agent_j.sigma_q_field_original

    phi_i, phi_j, Omega_ij = extract_phi_and_omega(agent_i, agent_j, field="phi")
    Phi_ij = get_bundle_morphism(agent_i, agent_j, params, field="phi")

    # Defensive assertions
    K_in = Phi_ij.shape[-1]
    assert sigma_j.shape[-2:] == (K_in, K_in), \
        f"[accumulate_phi_gradient_belief] σ_j shape={sigma_j.shape}, expected {(K_in, K_in)}"

    transport_op, mu_trans, sigma_trans = transport_fields(mu_j, sigma_j, Omega_ij, Phi_ij)
    sigma_trans = sanitize_sigma(sigma_trans, eps=config.eps)
    sigma_inv = safe_inv(sigma_trans, eps=config.eps)

    mu_proj, sigma_proj = safe_batch_apply_morphism(mu_i, sigma_i, Phi_ij, eps=config.eps)
    delta_mu = mu_proj - mu_trans
    delta_sigma = sigma_proj - sigma_trans

    d_mu = -np.einsum("...ij,...j->...i", sigma_inv, delta_mu)
    d_sigma = -0.5 * np.einsum("...ik,...kl,...lj->...ij", sigma_inv, delta_sigma, sigma_inv)

    grad_phi_i, grad_phi_j = compute_generator_gradients_belief(
        generators, Omega_ij, Phi_ij, mu_j, sigma_j,
        transport_op, transport_op.transpose(0, 1, 3, 2),
        d_mu, d_sigma, phi_i.shape
    )

    grad_phi_i = dexpinv_operator(phi_i, grad_phi_i, generators) + dexpinv_operator_covariance(phi_i, d_sigma, generators)
    grad_phi_j = dexpinv_operator(phi_j, grad_phi_j, generators) + dexpinv_operator_covariance(phi_j, -d_sigma, generators)

    accumulate_into_agent(agent_i, grad_phi_i, beta, joint_mask)
    accumulate_into_agent(agent_j, grad_phi_j, beta, joint_mask)
