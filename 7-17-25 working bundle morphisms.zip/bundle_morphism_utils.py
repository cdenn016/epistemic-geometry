# -*- coding: utf-8 -*-
"""
Created on Wed Jul 16 18:18:11 2025

@author: chris and christine
"""

# bundle_morphism_utils.py
import numpy as np
from typing import Optional, Tuple, List, Dict, Any, Union
import numpy as np
from scipy.ndimage import gaussian_filter
import config
from numerical_utils import sanitize_sigma

from get_generators import RhoFunction
from generalized_math_utils import to_natural_params, from_natural_params

def apply_morphism(mu, sigma, Phi):
    """
    Apply bundle morphism Φ to mean/covariance:
        μ' = Φ μ
        Σ' = Φ Σ Φᵀ

    Args:
        mu   : (..., K_q)       source mean
        sigma: (..., K_q, K_q)  source covariance
        Phi  : (..., K_p, K_q)  morphism from source to target space

    Returns:
        (mu_tgt, sigma_tgt): (..., K_p), (..., K_p, K_p)
    """
    mu_tgt = np.einsum("...ij,...j->...i", Phi, mu)
    sigma_tgt = np.einsum("...ik,...kl,...jl->...ij", Phi, sigma, Phi)
    return mu_tgt, sigma_tgt

def rho_batch(phi_field: np.ndarray, generators: np.ndarray) -> np.ndarray:
    """
    Apply exp(φᵢ·Gᵢ) to a (H, W, d) field using a generator set of shape (d, K, K).
    Returns: (H, W, K, K)
    """
    H, W, d = phi_field.shape
    out = np.zeros((H, W, generators.shape[1], generators.shape[2]), dtype=phi_field.dtype)
    for i in range(H):
        for j in range(W):
            G = sum(phi_field[i,j,k] * generators[k] for k in range(d))
            out[i,j] = expm(G)
    return out


def safe_batch_apply_morphism_nat(mu, sigma, Phi, eps=1e-8):
    """
    Project (mu, Sigma) through a bundle morphism Φ using **natural parameters**.
    Args:
        mu:    (H, W, K_src)
        sigma: (H, W, K_src, K_src)
        Phi:   (H, W, K_tgt, K_src)
    Returns:
        mu_out:    (H, W, K_tgt)
        sigma_out: (H, W, K_tgt, K_tgt)
    """
    theta1, theta2 = to_natural_params(mu, sigma, eps)
    theta1_out = np.einsum("...ij,...j->...i", Phi, theta1)
    theta2_out = np.einsum("...ij,...jk,...lk->...il", Phi, theta2, Phi)
    theta2_out = 0.5 * (theta2_out + theta2_out.transpose(0, 1, 3, 2))  # symmetrize

    mu_out, sigma_out = from_natural_params(theta1_out, theta2_out, eps)
    return mu_out, sigma_out



def safe_batch_apply_morphism(mu, sigma, Phi, eps=1e-8):
    """
    Apply a bundle morphism Φ: K_src → K_tgt to mean and covariance.

    Args:
        mu    : (..., K_src)
        sigma : (..., K_src, K_src)
        Phi   : (..., K_tgt, K_src)
        eps   : float, stabilizer for SPD output

    Returns:
        mu_tgt     : (..., K_tgt)
        sigma_tgt  : (..., K_tgt, K_tgt)
    """
    if Phi.shape[-1] != mu.shape[-1]:
        raise ValueError(
            f"[safe_batch_apply_morphism] Mismatch: Φ maps K_src={Phi.shape[-1]} → K_tgt={Phi.shape[-2]}, "
            f"but mu has shape {mu.shape}"
        )

    try:
        mu_tgt = np.einsum("...ij,...j->...i", Phi, mu)
        sigma_tgt = np.einsum("...ik,...kl,...jl->...ij", Phi, sigma, Phi)
    except Exception as e:
        print(f"[ERROR] einsum failed: mu={mu.shape}, sigma={sigma.shape}, Phi={Phi.shape}")
        raise

    eye = np.eye(Phi.shape[-2], dtype=sigma.dtype)
    sigma_tgt += eps * eye.reshape((1,) * (sigma_tgt.ndim - 2) + eye.shape)
    return mu_tgt, sigma_tgt


def identity_morphism(agent_i, agent_j):
    """
    Returns Φ = Id for all spatial points.
    """
    H, W, K = agent_i.mu_q_field.shape  # works for both q and p
    return np.broadcast_to(np.eye(K, dtype=np.float32), (H, W, K, K))

def get_morphism_fn(name, generators_q=None, generators_p=None):
    """
    Returns a morphism function: (agent_i, agent_j) → Φ_{ij}

    Args:
        name         : str, e.g., "identity", "gauge_covariant"
        generators_q : (3, K_q, K_q) array for belief bundle (domain)
        generators_p : (3, K_p, K_p) array for model bundle (codomain)

    Returns:
        function(agent_i, agent_j) → (H, W, K_p, K_q)
    """
    name = name.lower()

    if name == "identity":
        return identity_morphism

    elif name == "gauge_covariant":
        if generators_q is None or generators_p is None:
            raise ValueError("[get_morphism_fn] 'gauge_covariant' requires both generators_q and generators_p")
        rho_q_func = RhoFunction(generators_q)
        rho_p_func = RhoFunction(generators_p)
        return make_morphism_fn(rho_q_func, rho_p_func)

    else:
        raise ValueError(f"[get_morphism_fn] Unknown morphism type: '{name}'")


def assign_default_morphisms(agent, K_q, K_p):
    shape = agent.grid_shape
    mask  = agent.mask[..., None, None]  # (H, W, 1, 1)

    Φ       = np.zeros((*shape, K_p, K_q), dtype=np.float32)
    Φ_tilde = np.zeros((*shape, K_q, K_p), dtype=np.float32)

    min_dim = min(K_q, K_p)

    for i in range(min_dim):
        Φ[..., i, i]       = mask[..., 0, 0]
        Φ_tilde[..., i, i] = mask[..., 0, 0]

    agent.bundle_morphism_phi       = Φ
    agent.bundle_morphism_phi_tilde = Φ_tilde


def generate_smooth_morphism_field(
    H, W,
    K_src, K_tgt,
    sigma=config.sigma_field_smooth_range,
    low_rank=None,
    seed=None,
    normalize=False,
    mask=None,
):
    """
    Generate a smooth spatial field of K_tgt × K_src morphisms.

    Args:
        H, W       : spatial domain
        K_src      : input dimension (e.g. q)
        K_tgt      : output dimension (e.g. p)
        sigma      : Gaussian blur σ (scalar or tuple)
        low_rank   : optional int ≤ min(K_src, K_tgt) for low-rank morphism
        seed       : optional random seed
        normalize  : if True, normalize each matrix to unit Frobenius norm
        mask       : (H, W) optional mask to apply (multiply per point)

    Returns:
        morphism_field : (H, W, K_tgt, K_src)
    """
    if seed is not None:
        rng = np.random.default_rng(seed)
    else:
        rng = np.random.default_rng()

    field = np.zeros((H, W, K_tgt, K_src), dtype=np.float32)

    # Create low-rank if desired
    rank = low_rank if low_rank is not None else min(K_src, K_tgt)

    for r in range(rank):
        outer = rng.standard_normal((K_tgt, K_src)).astype(np.float32)

        # Apply blur per entry
        coeffs = rng.standard_normal((H, W)).astype(np.float32)
        coeffs = gaussian_filter(coeffs, sigma=sigma, mode="wrap")

        field += coeffs[..., None, None] * outer[None, None, :, :]

    # Optional normalization
    if normalize:
        norm = np.linalg.norm(field, axis=(-2, -1), keepdims=True)
        field = np.divide(field, norm + 1e-8)

    # Optional masking
    if mask is not None:
        field *= mask[..., None, None]

    return field

def initialize_morphism_pair( 
    domain_size: tuple[int, int],
    K_q: int,
    K_p: int,
    rng: np.random.Generator,
    morphism_type: str = "identity",
    mask: Optional[np.ndarray] = None,
    config_tag: str = "",
) -> tuple[np.ndarray, np.ndarray]:
    """
    Initialize bundle morphisms Φ (q→p) and Φ̃ (p→q).

    Args:
        domain_size    : (H, W)
        K_q, K_p       : belief and model fiber dims
        rng            : np.random.Generator
        morphism_type  : "identity", "smooth", "lowrank", or "gauge_covariant"
        mask           : agent support mask
        config_tag     : optional suffix to use e.g. config.phi_sigma_tagname

    Returns:
        (Phi_field, Phi_tilde_field)
    """
    H, W = domain_size

    if morphism_type == "identity":
        if K_q != K_p:
            raise ValueError(f"Cannot use identity morphism with mismatched K_q={K_q} and K_p={K_p}")
        eye = np.eye(K_q, dtype=np.float32)
        phi_q_to_p = np.broadcast_to(eye, (H, W, K_q, K_q)).copy()
        phi_p_to_q = np.broadcast_to(eye, (H, W, K_q, K_q)).copy()
        return phi_q_to_p, phi_p_to_q

    if morphism_type == "gauge_covariant":
        # Initialize with identity morphisms; equivariance will be handled later
        phi_q_to_p = np.broadcast_to(np.eye(K_p, K_q, dtype=np.float32), (H, W, K_p, K_q)).copy()
        phi_p_to_q = np.broadcast_to(np.eye(K_q, K_p, dtype=np.float32), (H, W, K_q, K_p)).copy()
        return phi_q_to_p, phi_p_to_q

    # Otherwise: generate two smooth morphism fields (for "smooth" or "lowrank")
    sigma = getattr(config, f"morphism_sigma{config_tag}", 1.5)
    rank = getattr(config, f"morphism_rank{config_tag}", min(K_q, K_p))
    normalize = getattr(config, f"morphism_normalize{config_tag}", True)

    phi_q_to_p = generate_smooth_morphism_field(
        H, W, K_src=K_q, K_tgt=K_p,
        sigma=sigma, low_rank=rank,
        normalize=normalize, mask=mask, seed=None
    )

    phi_p_to_q = generate_smooth_morphism_field(
        H, W, K_src=K_p, K_tgt=K_q,
        sigma=sigma, low_rank=rank,
        normalize=normalize, mask=mask, seed=None
    )

    return phi_q_to_p, phi_p_to_q




from scipy.linalg import expm

def build_rho(phi_vec: np.ndarray, generators: dict[str, np.ndarray]) -> np.ndarray:
    """
    phi_vec : (3,) Lie algebra coefficients [θ_H, θ_E, θ_F]
    generators : dict with 'H', 'E', 'F' matrices

    returns ρ(exp(φ)) ∈ SL(2,R)^K
    """
    phi_matrix = phi_vec[0] * generators['H'] + phi_vec[1] * generators['E'] + phi_vec[2] * generators['F']
    return expm(phi_matrix)


def gauge_covariant_transform_phi(phi_field, Phi_field, rho_q_func, rho_p_func):
    """
    Apply Φ(x) ↦ ρ_p(exp(φ(x))) · Φ(x) · ρ_q(exp(φ(x)))⁻¹ for each point.

    Args:
        phi_field:  (H, W, 3)
        Phi_field:  (H, W, K_p, K_q)
        rho_q_func: φ → ρ_q(exp(φ)) (returns (K_q, K_q))
        rho_p_func: φ → ρ_p(exp(φ)) (returns (K_p, K_p))

    Returns:
        Transformed Phi_field: (H, W, K_p, K_q)
    """
    H, W = phi_field.shape[:2]
    K_p, K_q = Phi_field.shape[-2:]

    out = np.zeros_like(Phi_field)
    for i in range(H):
        for j in range(W):
            phi = phi_field[i, j]
            rho_q = rho_q_func(phi)      # (K_q, K_q)
            rho_p = rho_p_func(phi)      # (K_p, K_p)
            Phi = Phi_field[i, j]        # (K_p, K_q)

            out[i, j] = rho_p @ Phi @ np.linalg.inv(rho_q)

    return out

def make_morphism_fn(rho_q_func, rho_p_func):
    """
    Returns a function that performs the gauge-covariant transformation:
        Φ ↦ ρ_p(exp(φ)) · Φ · ρ_q(exp(φ))⁻¹
    for a given agent_j's Φ and φ, evaluated in agent_i's frame.

    Args:
        rho_q_func : function mapping φ → ρ_q(exp(φ))
        rho_p_func : function mapping φ → ρ_p(exp(φ))

    Returns:
        morphism(agent_i, agent_j) → (H, W, K_p, K_q) transformed Φ
    """
    def morphism(agent_i, agent_j):
        phi_field  = agent_j.phi            # φ_j
        Phi_field = agent_j.bundle_morphism_q_to_p

        return gauge_covariant_transform_phi(phi_field, Phi_field, rho_q_func, rho_p_func)

    return morphism

def get_cross_morphism(agent_i, agent_j, field="phi", gauge_covariant=True):
    """
    Return the bundle morphism Φ_ij between agent_i and agent_j.
    
    Args:
        agent_i          : source agent (has Φ field)
        agent_j          : target agent
        field            : "phi" or "phi_model"
        gauge_covariant  : whether to apply Φ_ij = ρ_p(φ_i) · Φ_i · ρ_q(φ_j)⁻¹

    Returns:
        Φ_ij : (H, W, K_p, K_q) morphism field from agent_j.q to agent_i.p
    """
    Phi_i = agent_i.bundle_morphism if field == "phi" else agent_i.bundle_morphism_model

    if not gauge_covariant:
        return Phi_i

    rho_q_func = agent_j.rho_q_func if field == "phi" else agent_j.rho_p_func
    rho_p_func = agent_i.rho_p_func if field == "phi" else agent_i.rho_q_func

    phi_i = agent_i.phi if field == "phi" else agent_i.phi_model
    phi_j = agent_j.phi if field == "phi" else agent_j.phi_model

    # Gauge transform: Φ_ij = ρ_p(φ_i) · Φ_i · ρ_q(φ_j)⁻¹
    Phi_transformed = np.zeros_like(Phi_i)
    H, W = phi_i.shape[:2]
    for i in range(H):
        for j in range(W):
            rho_q = rho_q_func(phi_j[i, j])
            rho_p = rho_p_func(phi_i[i, j])
            Phi   = Phi_i[i, j]
            Phi_transformed[i, j] = rho_p @ Phi @ np.linalg.inv(rho_q)

    return Phi_transformed
