# Standard library
import os
# Third-party libraries
import numpy as np
from scipy.ndimage import laplace
from generalized_omega import (exp_lie_algebra_irrep, batch_apply_omega,
                              compute_field_strength)
from get_generators import get_generators 
from joblib import Parallel, delayed
from generalized_math_utils import (
    laplacian_field,
   )
import config
from pathlib import Path
from pullback_utils import compute_agent_pullback_blocks, compute_pullback_metric
from generalized_math_utils import kl_divergence  # ← make sure this is imported
from mask_utils import (
    get_support_mask,
    get_overlap_mask,
    expand_mask_for_mu,
    expand_mask_for_sigma,
    apply_mask_mu,
    apply_mask_sigma,
    apply_mask_phi,
    norm_over_mask,
    masked_norm,
    threshold_mask
)
from bundle_morphism_utils import safe_batch_apply_morphism_nat


def compute_alignment_kl_general(agent_i, agents, field_type="belief", log_eps=config.eps):
    """
    Computes mean KL divergence KL(fiber_i || Ω_ij fiber_j) over neighbors j.
    Supports field_type = "belief" or "model".

    Args:
        agent_i: agent whose KL we compute
        agents:  list of all agents
        field_type: "belief" or "model"
        log_eps: numerical stabilizer for KL

    Returns:
        Mean KL divergence (float)
    """
    if field_type == "belief":
        mu_i     = agent_i.mu_q_field
        sigma_i  = agent_i.sigma_q_field
        Omega    = agent_i.Omega
        Omega_inv= agent_i.Omega_inv
        mu_j_f   = lambda j: agents[j].mu_q_field
        sigma_j_f= lambda j: agents[j].sigma_q_field
    elif field_type == "model":
        mu_i     = agent_i.mu_p_field
        sigma_i  = agent_i.sigma_p_field
        Omega    = agent_i.Omega_model
        Omega_inv= agent_i.Omega_model_inv
        mu_j_f   = lambda j: agents[j].mu_p_field
        sigma_j_f= lambda j: agents[j].sigma_p_field
    else:
        raise ValueError(f"Invalid field_type: {field_type}")

    mask_i = agent_i.mask > config.support_cutoff_eps
    kl_vals = []

    for neighbor in agent_i.neighbors:
        j = neighbor["id"]
        agent_j = agents[j]
        mask_j = agent_j.mask > config.support_cutoff_eps
        overlap = mask_i & mask_j

        if not np.any(overlap):
            continue

        Ω_ij = np.einsum("mab,mbc->mac", Omega[overlap], Omega_inv[overlap])

        mu_j = mu_j_f(j)[overlap]
        sigma_j = sigma_j_f(j)[overlap]
        mu_j_t, sigma_j_t = batch_apply_omega(mu_j, sigma_j, Ω_ij)

        mu_i_pts = mu_i[overlap]
        sigma_i_pts = sigma_i[overlap]

        kl = kl_divergence(mu_i_pts, sigma_i_pts, mu_j_t, sigma_j_t, log_eps=log_eps)
        kl_vals.append(np.mean(kl))

    return np.mean(kl_vals) if kl_vals else 0.0


def compute_kl_qp_field(mu_q_field, sigma_q_field, mu_p_field, sigma_p_field, mask, log_eps=1e-8):
    """
    Compute the per‐cell KL divergence KL[ N(mu_q,Σ_q) || N(mu_p,Σ_p) ].
    Returns an array of shape (H, W) with zero outside the mask.
    """
    H, W = mask.shape
    K = mu_q_field.shape[-1]

    # flatten the masked points only
    indices = np.flatnonzero(mask.ravel())
    mu_q_flat    = mu_q_field.reshape(-1, K)[indices]
    mu_p_flat    = mu_p_field.reshape(-1, K)[indices]
    # ensure Σ_q and Σ_p are full K×K
    sig_q_raw = sigma_q_field.reshape(-1, K, K)[indices]
    sig_p_raw = sigma_p_field.reshape(-1, K, K)[indices]

    # apply numerical stabilizer to Σ_p
    sig_p_flat = sig_p_raw + log_eps * np.eye(K)[None, ...]
    # compute KL only on the flattened support
    kl_vals = kl_divergence(
        mu_q_flat, sig_q_raw,
        mu_p_flat, sig_p_flat,
        log_eps=log_eps
    )

    # re‐scatter into an H×W field
    kl_field = np.zeros((H*W,), dtype=kl_vals.dtype)
    kl_field[indices] = kl_vals
    return kl_field.reshape(H, W)

def compute_self_energy(agent, log_eps, cfg):
    """Compute KL(q_i || Φ̃ · p_i), projecting p into q-fiber"""
    mu_q     = agent.mu_q_field
    sigma_q  = agent.sigma_q_field
    mu_p     = agent.mu_p_field
    sigma_p  = agent.sigma_p_field
    Phi_q_to_p = agent.bundle_morphism_q_to_p        # shape (H, W, 3, 5)
    Phi_tilde  = np.transpose(Phi_q_to_p, (0, 1, 3, 2))  # shape (H, W, 5, 3) = Φᵀ : p → q


    mu_p_in_q, sigma_p_in_q = safe_batch_apply_morphism_nat(mu_p, sigma_p, Phi_tilde)

    return compute_kl_energy_fieldwise(
        mu1=mu_q, sigma1=sigma_q,
        mu2=mu_p_in_q, sigma2=sigma_p_in_q,
        mask=agent.mask,
        weight=cfg["alpha"],
        log_eps=log_eps,
        direction="forward"
    )


def compute_feedback_energy(agent, log_eps, cfg):
    """Compute KL(p_i || Φ · q_i), projecting q into p-fiber"""
    mu_q    = agent.mu_q_field
    sigma_q = agent.sigma_q_field
    mu_p    = agent.mu_p_field
    sigma_p = agent.sigma_p_field
    Phi     = agent.bundle_morphism_q_to_p  # Φ : q → p

    mu_q_in_p, sigma_q_in_p = safe_batch_apply_morphism_nat(mu_q, sigma_q, Phi)

    return compute_kl_energy_fieldwise(
        mu1=mu_p, sigma1=sigma_p,
        mu2=mu_q_in_p, sigma2=sigma_q_in_p,
        mask=agent.mask,
        weight=cfg["model_feedback_weight"],
        log_eps=log_eps,
        direction="feedback"
    )




def compute_fisher_from_gaussian(mu, sigma, mask, log_eps=1e-8):
    """
    Approximate scalar Fisher information via ∇μᵀ Σ⁻¹ ∇μ

    Args:
        mu   : (H, W, K) — mean field
        sigma: (H, W, K, K) — covariance field
        mask : (H, W) — valid support
        log_eps: float — numerical stabilizer

    Returns:
        scalar_fisher: float
    """
    H, W, K = mu.shape
    fisher = 0.0
    eye = np.eye(K)
    debug = getattr(config, "debug", False)

    # ∇μ shape: (H, W, K)
    mu_grad = np.stack(np.gradient(mu, axis=(0, 1)), axis=-1)  # (H, W, K, 2)

    for i in range(H):
        for j in range(W):
            if mask[i, j] < log_eps:
                continue

            sigma_ij = sigma[i, j]
            sigma_ij = 0.5 * (sigma_ij + sigma_ij.T) + log_eps * eye

            try:
                sigma_inv = np.linalg.inv(sigma_ij)
            except np.linalg.LinAlgError:
                sigma_inv = eye
                if debug:
                    print(f"[WARN] compute_fisher_from_gaussian: Σ⁻¹ failed at ({i},{j})")

            # grad_mu: (K, 2), grad_mu.T: (2, K)
            grad_mu_ij = mu_grad[i, j]  # shape (K, 2)
            for d in range(grad_mu_ij.shape[-1]):
                g = grad_mu_ij[:, d]  # gradient along axis-d
                fisher += g.T @ sigma_inv @ g

    return float(np.nan_to_num(fisher))


#fiber-veritical holonomy
def fisher_information_matrix(mu, sigma, eps=1e-8, approx_sigma_block=True):
    """
    Compute the Fisher information matrix for MVG parameters (μ, Σ).

    Supports:
        - Diagonal sigma: shape (..., K)
        - Full covariance: shape (..., K, K)

    Args:
        mu:     (..., K) mean vector
        sigma:  (..., K) if diagonal, (..., K, K) if full SPD
        eps:    Regularization for SPD stability
        approx_sigma_block: if True, use 2·Σ⁻¹ approximation for Σ–Σ block

    Returns:
        G:      (..., 2K, 2K) Fisher block matrix
    """
    K = mu.shape[-1]
    eye = np.eye(K)

    if sigma.ndim == mu.ndim:
        # Diagonal case
        sigma_diag = np.clip(sigma, eps, None)
        inv_var = 1.0 / (sigma_diag ** 2)

        F_mu = np.einsum('...k,kl->...kl', inv_var, eye)              # diag(1/σ²)
        F_sigma = np.einsum('...k,kl->...kl', 2.0 * inv_var, eye)     # diag(2/σ²)

    elif sigma.ndim == mu.ndim + 1:
        # Full covariance case
        sigma_reg = sigma + eps * eye
        sigma_inv = np.linalg.inv(sigma_reg)

        F_mu = sigma_inv

        if approx_sigma_block:
            # Approximate Σ–Σ block with 2·Σ⁻¹ (trace-style)
            F_sigma = 2.0 * sigma_inv
        else:
            # Exact Σ–Σ block: Σ⁻¹ ⊗ Σ⁻¹
            # Note: for efficiency this is usually flattened
            kron = np.einsum('...ij,...kl->...ikjl', sigma_inv, sigma_inv)
            F_sigma = kron.reshape(*kron.shape[:-4], K*K, K*K)

    else:
        raise ValueError(f"Invalid sigma shape: {sigma.shape}")

    zeros = np.zeros_like(F_mu)

    top    = np.concatenate([F_mu, zeros], axis=-1)      # (..., K, 2K)
    bottom = np.concatenate([zeros, F_sigma], axis=-1)   # (..., K, 2K)
    G = np.concatenate([top, bottom], axis=-2)           # (..., 2K, 2K)

    return G



def compute_alignment_field_general(
    agents, i, field_type="belief",
    eps=config.support_cutoff_eps,
    log_eps=config.log_eps
) -> np.ndarray:
    """
    Compute spatial field of average KL divergence between agent i and its neighbors,
    using gauge transport of either beliefs (q) or models (p).

    Args:
        agents: list of all agents
        i: index of agent A
        field_type: "belief" or "model"
        eps: support threshold
        log_eps: stabilizer for KL divergence

    Returns:
        (H, W) spatial KL field
    """
    A = agents[i]
    mask_i = threshold_mask(A.mask, eps)
    if not np.any(mask_i) or not A.neighbors:
        return np.zeros_like(mask_i, dtype=np.float32)

    H, W = A.mask.shape
    kl_accum = np.zeros((H, W), dtype=np.float32)
    n_nb_at = np.zeros((H, W), dtype=np.int32)

    # Select fields and Lie algebra generators
    if field_type == "belief":
        mu_i     = A.mu_q_field
        sigma_i  = A.sigma_q_field
        phi_i    = A.phi
        K        = config.K_q
    elif field_type == "model":
        mu_i     = A.mu_p_field
        sigma_i  = A.sigma_p_field
        phi_i    = A.phi_model
        K        = config.K_p
    else:
        raise ValueError(f"Invalid field_type: {field_type}")

    generators = get_generators(config.group_name, K)

    for nb in A.neighbors:
        B = agents[nb["id"]]
        mask_j = threshold_mask(B.mask, eps)
        overlap = mask_i & mask_j
        if not np.any(overlap):
            continue

        idx = np.argwhere(overlap)
        i_idx, j_idx = idx[:, 0], idx[:, 1]

        mu_j    = B.mu_q_field if field_type == "belief" else B.mu_p_field
        sigma_j = B.sigma_q_field if field_type == "belief" else B.sigma_p_field
        phi_j   = B.phi         if field_type == "belief" else B.phi_model

        mu_j_ov    = mu_j[overlap]
        sigma_j_ov = sigma_j[overlap]

        # Promote σ_j to full Σ if needed
        if sigma_j_ov.ndim == 2:
            sigma_j_full = np.einsum("mk,ij->mij", sigma_j_ov**2, np.eye(K))
        else:
            sigma_j_full = sigma_j_ov

        # Transport via Ω_ij = exp(φ_i) · exp(−φ_j)
        O_i     = exp_lie_algebra_irrep(phi_i[overlap], generators)         # (M, K, K)
        O_j_inv = exp_lie_algebra_irrep(-phi_j[overlap], generators)        # (M, K, K)
        Omega   = np.einsum("mab,mbc->mac", O_i, O_j_inv)                   # (M, K, K)

        mu_j_t     = np.einsum("mab,mb->ma", Omega, mu_j_ov)                # (M, K)
        sigma_j_t  = np.einsum("mab,mbc,mcd->mad", Omega, sigma_j_full, Omega)  # (M, K, K)

        mu_i_ov    = mu_i[overlap]
        sigma_i_ov = sigma_i[overlap]
        if sigma_i_ov.ndim == 2:
            sigma_i_full = np.einsum("mk,ij->mij", sigma_i_ov**2, np.eye(K))
        else:
            sigma_i_full = sigma_i_ov

        kl_vals = kl_divergence(mu_i_ov, sigma_i_full, mu_j_t, sigma_j_t, log_eps=log_eps)

        np.add.at(kl_accum, (i_idx, j_idx), kl_vals)
        np.add.at(n_nb_at,  (i_idx, j_idx), 1)

    out = np.zeros_like(kl_accum)
    valid = n_nb_at > 0
    out[valid] = kl_accum[valid] / n_nb_at[valid]
    return out * mask_i




#used?
def compute_entropy_field(sigma_field, mask, log_eps=1e-8):
    """
    Compute per‑cell entropy H[q(c)] for a Gaussian at each grid point.
    Returns an array shape (L, L) with zeros outside mask.
    """
    L = mask.shape[0]
    if sigma_field.ndim == 3:
        # diagonal σ: shape (L,L,K)
        var      = np.clip(sigma_field**2, log_eps, None)            # (L,L,K)
        log_det  = np.sum(np.log(var), axis=-1)                      # (L,L)
    else:
        # full Σ: shape (L,L,K,K)
        K        = sigma_field.shape[-1]
        log_det = np.zeros((L, L), dtype=float)
        for i in range(L):
            for j in range(L):
                if not mask[i,j]: continue
                Σ = sigma_field[i,j] + log_eps*np.eye(K)
                sign, ld = np.linalg.slogdet(Σ)
                log_det[i,j] = ld if sign>0 else -np.inf

    H = 0.5*(sigma_field.shape[-1]*np.log(2*np.pi*np.e) + log_det)
    H[~mask] = 0.0
    return H

def entropy_total(sigma_field, mask, log_eps=1e-8):
    H = compute_entropy_field(sigma_field, mask, log_eps)
    return float(H.sum())


#can remove?
def compute_alignment_field_pairwise(
    agents,
    i,
    j,
    eps: float = config.support_cutoff_eps,
    log_eps: float = config.log_eps
) -> np.ndarray:
    """
    Compute spatial KL alignment field D_KL(q_i || Ω_ij q_j) using MVG fields.

    Supports both diagonal (Σ shape: (..., K)) and full (Σ shape: (..., K, K)) covariance.

    Returns:
        2D array with KL divergence at overlap points, zero elsewhere.
    """
   
    A, B = agents[i], agents[j]
    mask_i = A.mask > eps
    mask_j = B.mask > eps
    overlap = mask_i & mask_j

    if not np.any(overlap):
        return np.zeros_like(A.mask, dtype=float)

    μ_i = A.mu_q_field[overlap]       # (M, K)
    μ_j = B.mu_q_field[overlap]
    Σ_i = A.sigma_q_field[overlap]    # (M, K) or (M, K, K)
    Σ_j = B.sigma_q_field[overlap]

    Ω_i     = A.Omega[overlap]        # (M, K, K)
    Ω_j_inv = B.Omega_inv[overlap]
    Ω_ij    = np.einsum("mab,mbc->mac", Ω_i, Ω_j_inv)  # (M, K, K)

    μ_j_t = np.einsum("mab,mb->ma", Ω_ij, μ_j)         # (M, K)

    if Σ_j.ndim == 2:
        # Diagonal: σ² → rotate elementwise
        Σ_j_t = np.einsum("mab,mb->ma", Ω_ij**2, Σ_j)   # crude approx
    else:
        Σ_j_t = np.einsum("mab,mbc,mdc->mad", Ω_ij, Σ_j, Ω_ij)

    kl_vals = kl_divergence(μ_i, Σ_i, μ_j_t, Σ_j_t, eps=log_eps)

    field = np.zeros_like(A.mask, dtype=float)
    field[overlap] = kl_vals
    return field


def compute_kl_energy_fieldwise(mu1, sigma1, mu2, sigma2, mask, weight, log_eps, direction="forward"):
    """
    Compute weighted KL divergence energy over an agent's mask.

    Args:
        mu1, sigma1 : (H, W, K), (H, W, K, K) — source distribution
        mu2, sigma2 : (H, W, K), (H, W, K, K) — target distribution
        mask        : (H, W)                  — binary support mask
        weight      : float                   — energy coefficient
        log_eps     : float                   — numerical regularization
        direction   : "forward" or "feedback" — KL(q || p) or KL(p || q)

    Returns:
        Scalar: weighted total KL over the support
    """
    support = mask > config.support_cutoff_eps
    if not np.any(support):
        return 0.0

    μ_1 = mu1[support]
    Σ_1 = sigma1[support]
    μ_2 = mu2[support]
    Σ_2 = sigma2[support]

    kl_vals = kl_divergence(μ_1, Σ_1, μ_2, Σ_2, log_eps=log_eps)
    return weight * float(np.sum(kl_vals))


def compute_alignment_energy_general(
    i,
    agent_i,
    field_list,
    mask_list,
    Omega_list,
    Omega_inv_list,
    weight,
    log_eps=config.log_eps,
    field_type="belief"
):
    """
    Generalized alignment energy:
        weight * ∑_j D_KL(field_i || Ω_{ij} field_j)
    where field = q (belief) or p (model).

    Args:
        i               : index of current agent
        agent_i         : the i-th Agent object
        field_list      : list of (μ, Σ) field tuples
        mask_list       : list of spatial masks (bool)
        Omega_list      : list of Ω = exp(φ) per agent
        Omega_inv_list  : list of Ω⁻¹ = exp(−φ) per agent
        weight          : β or model_align_weight
        log_eps         : log stabilizer
        field_type      : "belief" or "model"

    Returns:
        total_energy: float
    """
    mu_i, sigma_i = field_list[i]
    mask_i = mask_list[i]

    total_energy = 0.0
    for nb in agent_i.neighbors:
        j = nb["id"]
        mu_j, sigma_j = field_list[j]
        mask_j = mask_list[j]
        overlap = mask_i & mask_j
        if not np.any(overlap):
            continue

        # Compute Ω_{ij} = Ω_i · Ω_j⁻¹
        Omega_ij = np.einsum("mab,mbc->mac", Omega_list[i][overlap], Omega_inv_list[j][overlap])

        # Transport μ_j and Σ_j
        mu_j_t, sigma_j_t = batch_apply_omega(mu_j[overlap], sigma_j[overlap], Omega_ij)

        # KL(field_i || Ω·field_j)
        kl_vals = kl_divergence(mu_i[overlap], sigma_i[overlap], mu_j_t, sigma_j_t, log_eps=log_eps)
        total_energy += weight * float(np.sum(kl_vals))

    return total_energy


def compute_laplacian_energy(phi, mask, weight):
    """
    Computes ∫ ‖Δφ‖ over the mask. Used as a smoothing regularizer.
    """
    lap = laplacian_field(phi)  # shape: (H, W, d)
    return weight * np.sum(np.linalg.norm(lap[mask], axis=-1))**2

def compute_mass_energy(phi, mask, weight):
    """
    Computes ∫ ‖φ‖² over the mask — a mass-like prior.
    """
    return weight * np.sum(np.linalg.norm(phi[mask], axis=-1)**2)

def compute_phi_coupling_energy(phi, phi_model, mask, weight):
    """
    Coupling term ∫ ‖φ - φ̃‖² between belief and model gauge fields.
    """
    if phi.shape[:2] != mask.shape:
        H, W = mask.shape
        d = phi.shape[-1]
        phi = phi.reshape(H, W, d)
        phi_model = phi_model.reshape(H, W, d)

    diff = (phi - phi_model)[mask > 0]
    return weight * float(np.sum(np.linalg.norm(diff, axis=-1)**2))

def compute_curvature_energy(phi_field, mask, weight, lie_gens, support_eps=1e-4, debug=False):
    """
    Compute curvature energy: weight × ∑_x Tr[F_{μν}(x)^2] over valid mask.

    Args:
        phi_field   : (H, W, d)     — φ or φ_model field in Lie algebra coords
        mask        : (H, W)        — agent support mask
        weight      : float         — energy weight coefficient
        lie_gens    : (d, K, K)     — Lie algebra generators
        support_eps : float         — minimum support threshold
        debug       : bool          — optional print/debug info

    Returns:
        energy      : float         — weighted curvature energy
        raw_total   : float         — ∑ Tr[F²] over support (unweighted)
    """
    F_dict = compute_field_strength(phi_field, lie_gens)  # dict of F_xy, F_yz, etc.
    support = mask > support_eps

    total = 0.0
    for key, val in F_dict.items():
        if val.ndim == 2:
            total += val**2
        elif val.ndim == 3:
            total += np.sum(val**2, axis=-1)  # vector norm²
        elif val.ndim == 4:
            total += np.sum(val**2, axis=(-2, -1))  # Frobenius norm²
        else:
            raise ValueError(f"[ERROR] Unexpected F_{key} shape: {val.shape}")

    raw_total = float(np.sum(total[support]))
    if debug:
        print(f"[φ_curv] Raw: {raw_total:.4f} | Weighted: {weight * raw_total:.4f}")

    return weight * raw_total, raw_total





def compute_agent_metrics(
    i, A, Q_list, P_list, Mask_list,
    O_bel, O_inv, O_mod, O_mod_inv,
    cfg, gens, log_eps
):
    mask = Mask_list[i]
    if not mask.any():
        return i, zero_agent_metrics(len(Q_list))

    stats = compute_all_agent_metrics(
        i, A, Q_list, P_list, Mask_list,
        O_bel, O_inv, O_mod, O_mod_inv,
        cfg, gens, log_eps
    )
    return i, stats

def zero_agent_metrics(N: int) -> dict:
    return {
        "e_self": 0.0,
        "e_feedback": 0.0,
        "e_align": 0.0,
        "e_mod_align": 0.0,
        "e_curv": 0.0,
        "e_curv_mod": 0.0,
        "phi_norm": 0.0,
        "phi_model_norm": 0.0
    }



def accumulate_and_log_metrics(results, agents, step, Q_list, Mask_list):
    keys = ["e_self", "e_feedback", "e_align", "e_mod_align", "e_curv", "e_curv_mod"]

    accum = {k: 0.0 for k in keys}
    total_support = 0

    for i, s in enumerate(results):
        support = int(Mask_list[i].sum())
        total_support += support
        for k in keys:
            accum[k] += s[k]

        agents[i].log_metrics(step, {
            "kl_self":           s["e_self"]      / support,
            "kl_feedback":       s["e_feedback"]  / support,
            "kl_align":          s["e_align"]     / support,
            "kl_mod_align":      s["e_mod_align"] / support,
            "curv_energy":       s["e_curv"]      / support,
            "curv_model_energy": s["e_curv_mod"]  / support,
            "phi_norm":          s["phi_norm"],
            "phi_model_norm":    s["phi_model_norm"],
            })

    S = max(total_support, 1)
    metrics = {k: accum[k] / S for k in keys}
    metrics = {k: accum[k] / S for k in keys}
    metrics["total_energy"] = sum(accum[k] for k in keys) / S

    metrics["step"] = step
    return metrics


from bundle_morphism_utils import safe_batch_apply_morphism

from bundle_morphism_utils import safe_batch_apply_morphism

def compute_all_agent_metrics(i, A, Q_list, P_list, Mask_list,
                               O_bel, O_inv, O_mod, O_mod_inv,
                               cfg, generators_q, generators_p, log_eps):

    mask = Mask_list[i]

    stats = {
        "e_self": compute_self_energy(A, log_eps, cfg),
        "e_feedback": compute_feedback_energy(A, log_eps, cfg),

        "e_align": compute_alignment_energy_general(
            i=i,
            agent_i=A,
            field_list=Q_list,
            mask_list=Mask_list,
            Omega_list=O_bel,
            Omega_inv_list=O_inv,
            weight=cfg["beta"],
            log_eps=log_eps,
            field_type="belief"
        ),

        "e_mod_align": compute_alignment_energy_general(
            i=i,
            agent_i=A,
            field_list=P_list,
            mask_list=Mask_list,
            Omega_list=O_mod,
            Omega_inv_list=O_mod_inv,
            weight=cfg["model_align_weight"],
            log_eps=log_eps,
            field_type="model"
        ),

        "e_curv": 0.0,
        "e_curv_mod": 0.0,
        "phi_norm": np.linalg.norm(A.phi[mask], axis=-1).sum(),
        "phi_model_norm": np.linalg.norm(A.phi_model[mask], axis=-1).sum()
    }

    if cfg["curvature_weight"] > 0:
        stats["e_curv"], _ = compute_curvature_energy(
            A.phi, mask, cfg["curvature_weight"], generators_q
        )
        stats["e_curv_mod"], _ = compute_curvature_energy(
            A.phi_model, mask, cfg["curvature_weight"], generators_p
        )

    return stats





def log_all_metrics_fused(
    agents,
    step,
    params=None,
    q_field="q",
    p_field="p",
    phi_belief_field="phi",
    phi_model_field="phi_model",
    mask_field="mask",
    n_jobs=-1
):
    cfg = config if params is None else {**vars(config), **params}
    log_eps = cfg.get("log_eps", 1e-10)

    N = len(agents)  # ← FIX: number of agents
    K_q = cfg.get("K_q", 5)
    K_p = cfg.get("K_p", 5)
    group_name = cfg.get("group_name", "sl2r")

    gen_q = get_generators(group_name, K_q)
    gen_p = get_generators(group_name, K_p)


    # Precompute fields
    Q_list     = [(A.mu_q_field, A.sigma_q_field) for A in agents]
    P_list     = [(A.mu_p_field, A.sigma_p_field) for A in agents]
    Mask_list = [np.asarray(getattr(A, mask_field), dtype=bool) for A in agents]

    O_bel      = [A.Omega for A in agents]
    O_inv      = [A.Omega_inv for A in agents]
    O_mod      = [A.Omega_model for A in agents]
    O_mod_inv  = [A.Omega_model_inv for A in agents]

    results = Parallel(n_jobs=n_jobs, backend="threading")(
        delayed(compute_all_agent_metrics)(
            i, agents[i], Q_list, P_list, Mask_list,
            O_bel, O_inv, O_mod, O_mod_inv,
            cfg, gen_q, gen_p, log_eps
        )
        for i in range(N)
    )
    return accumulate_and_log_metrics(results, agents, step, Q_list, Mask_list)



def log_max_overlap_fields(agents, step, outdir, eps=config.support_cutoff_eps):
    """
    Logs full diagnostics from the max-overlap pair:
    - μ/Σ for q and p
    - belief/model alignment fields
    - KL fields
    - Spatial pullback metric M_ab = ∂μᵗ Σ⁻¹ ∂μ
    - Lie-algebra pullbacks: I, G, M_vis, Delta, M_dark
    """
    os.makedirs(outdir, exist_ok=True)

    # 1) Find most overlapping pair
    max_overlap = 0
    best_pair = None
    for i, A in enumerate(agents):
        mask_i = A.mask > eps
        if not mask_i.any():
            continue
        for nb in A.neighbors:
            j = nb["id"]
            mask_j = agents[j].mask > eps
            ov = mask_i & mask_j
            if (cnt := int(ov.sum())) > max_overlap:
                max_overlap = cnt
                best_pair = (i, j)

    if best_pair is None:
        print(f"[DEBUG] No overlapping pair at step {step}")
        return

    i, j = best_pair
    A = agents[i]

    # 2) Ensure Ω caches populated
    gens = get_generators(config.group_name, config.K)
    for B in [agents[i], agents[j]]:
        if B._exp_phi is None:
            B._exp_phi = exp_lie_algebra_irrep(B.phi, gens, group_name=config.group_name)
        if B._exp_neg_phi is None:
            B._exp_neg_phi = exp_lie_algebra_irrep(-B.phi, gens, group_name=config.group_name)
        if B._exp_phi_model is None:
            B._exp_phi_model = exp_lie_algebra_irrep(B.phi_model, gens, group_name=config.group_name)
        if B._exp_neg_phi_model is None:
            B._exp_neg_phi_model = exp_lie_algebra_irrep(-B.phi_model, gens, group_name=config.group_name)

        # 3) Fields
    mu_q    = A.mu_q_field                              # (H, W, K)
    sigma_q = A.sigma_q_field                           # (H, W, K) or (H, W, K, K)
    mu_p    = A.mu_p_field
    sigma_p = A.sigma_p_field
    mask_i  = (A.mask > eps).astype(np.float32)

        # Promote diagonal sigma fields to full (H, W, K, K)
    if sigma_q.ndim == 3:
        # Assume sigma_q is standard deviation → square to get variance
        sigma_q = np.einsum("...k,kl->...kl", sigma_q**2, np.eye(sigma_q.shape[-1], dtype=sigma_q.dtype))
    if sigma_p.ndim == 3:
        sigma_p = np.einsum("...k,kl->...kl", sigma_p**2, np.eye(sigma_p.shape[-1], dtype=sigma_p.dtype))


        # Flatten mu and sigma to (N, K) and (N, K, K)
    H, W, K = mu_q.shape
    mu_q_flat = mu_q.reshape(-1, K)
    mu_p_flat = mu_p.reshape(-1, K)
    sigma_q_flat = sigma_q.reshape(-1, K, K)
    sigma_p_flat = sigma_p.reshape(-1, K, K)

    # 4) Alignment and KL fields
    belief_align_field = compute_alignment_field_general(agents, i, field_type="belief")
    model_align_field  = compute_alignment_field_general(agents, i, field_type="model")


    agent = agents[i]
    mean_kl = np.mean(belief_align_field[agent.mask > config.support_cutoff_eps])
    print(f"[KL alignment] Agent {i}: mean KL(q_i ‖ Ω q_j) = {mean_kl:.4e}")

    kl_self_vals     = kl_divergence(mu_q_flat, sigma_q_flat, mu_p_flat, sigma_p_flat)
    kl_self_field    = kl_self_vals.reshape(H, W)

    kl_feedback_vals = kl_divergence(mu_p_flat, sigma_p_flat, mu_q_flat, sigma_q_flat)
    kl_feedback_field = kl_feedback_vals.reshape(H, W)

    # 5) Spatial pullback M_ab = ∂μᵗ Σ⁻¹ ∂μ
    M = compute_pullback_metric(mu_p, sigma_p)  # shape (H, W, 2, 2)
    tr_vis     = M[..., 0, 0] + M[..., 1, 1]
    delta      = M - np.transpose(M, (0, 1, 3, 2))
    delta_norm = np.linalg.norm(delta, axis=(2, 3))

    pullback_trace_vis   = float(np.mean(tr_vis * mask_i))
    pullback_trace_dark  = 0.0  # unused
    pullback_delta_norm  = float(np.mean(delta_norm * mask_i))

    # 6) Lie-algebra pullbacks from φ_model
    vis_inds  = [0, 1]
    dark_inds = [2]
    pull = compute_agent_pullback_blocks(A, vis_inds, dark_inds)

    # 7) Save all
    fname = os.path.join(outdir, f"step{step:05d}_pair_{i}_{j}.npz")
    np.savez_compressed(
        fname,
        agent_i             = i,
        agent_j             = j,
        overlap             = max_overlap,
        mask_i              = mask_i,
        belief_alignment    = belief_align_field,
        model_alignment     = model_align_field,
        mu_q                = mu_q,
        sigma_q             = sigma_q,
        mu_p                = mu_p,
        sigma_p             = sigma_p,
        kl_self             = kl_self_field,
        kl_feedback         = kl_feedback_field,
        pullback_metric     = M,
        pullback_trace_vis  = pullback_trace_vis,
        pullback_trace_dark = pullback_trace_dark,
        pullback_delta_norm = pullback_delta_norm,
        pullback_I          = pull["I"],
        pullback_G          = pull["G"],
        pullback_M_vis      = pull["M_vis"],
        pullback_M_dark     = pull["M_dark"],
        pullback_Delta      = pull["Delta"],
        phi                 = agents[i].phi,
        phi_model           = agents[i].phi_model,
)


def full_field_logger(agents, step: int, outdir: str):
    """
    Save one .npz per step containing per-agent fields and diagnostics:
      - mu_q, sigma_q, phi
      - mu_p, sigma_p, phi_model
      - belief_align, model_align
      - kl_self, kl_feedback
      - pullback_metric
      - curv_tensor, curv_model_tensor
      - pullback blocks: I, G, M_vis, M_dark, Delta
    """
    cfg  = vars(config)
    K_q  = cfg["K_q"]
    K_p  = cfg["K_p"]
    gens_q = get_generators(cfg["group_name"], K_q)
    gens_p = get_generators(cfg["group_name"], K_p)

    dx   = cfg.get("dx", 1.0)

    N = len(agents)
    H, W = agents[0].mu_q_field.shape[:2]
    d = agents[0].phi.shape[-1]

    # Allocate per-agent field arrays
    mu_q     = np.zeros((N, H, W, K_q), dtype=np.float32)
    sigma_q  = np.zeros((N, H, W, K_q, K_q), dtype=np.float32)
    phi      = np.zeros((N, H, W, d), dtype=np.float32)

    mu_p     = np.zeros((N, H, W, K_p), dtype=np.float32)
    sigma_p  = np.zeros((N, H, W, K_p, K_p), dtype=np.float32)
    phi_model = np.zeros((N, H, W, d), dtype=np.float32)

    belief_align      = np.zeros((N, H, W), dtype=np.float32)
    model_align       = np.zeros((N, H, W), dtype=np.float32)
    kl_self_field     = np.zeros((N, H, W), dtype=np.float32)
    kl_feedback_field = np.zeros((N, H, W), dtype=np.float32)
    pullback_metric   = np.zeros((N, H, W, 2, 2), dtype=np.float32)

    curv_tensor        = np.zeros((N, H, W, K_q, K_q), dtype=np.float32)
    curv_model_tensor  = np.zeros((N, H, W, K_p, K_p), dtype=np.float32)

    pb_I_list      = []
    pb_G_list      = []
    pb_M_vis_list  = []
    pb_M_dark_list = []
    pb_Delta_list  = []

    for idx, A in enumerate(agents):
        mu_q[idx]    = A.mu_q_field
        sigma_q[idx] = A.sigma_q_field
        phi[idx]     = A.phi

        mu_p[idx]    = A.mu_p_field
        sigma_p[idx] = A.sigma_p_field
        phi_model[idx] = A.phi_model

        # Alignment fields
        align_field = compute_alignment_field_general(agents, idx, field_type="belief")
        belief_align[idx] = align_field

        print(f"[DEBUG] Step {step:04d} • Agent {idx}: align mean={align_field.mean():.4f}, min={align_field.min():.4f}, max={align_field.max():.4f}")

        model_align[idx] = compute_alignment_field_general(agents, idx, field_type="model")

        # KL(q || Φᵀ·p)
        flat_q_mu  = A.mu_q_field.reshape(-1, K_q)
        flat_q_sig = A.sigma_q_field.reshape(-1, K_q, K_q)
        flat_p_mu  = A.mu_p_field.reshape(-1, K_p)
        flat_p_sig = A.sigma_p_field.reshape(-1, K_p, K_p)

        # Project p → q using Φᵀ
        Phi_q_to_p = A.bundle_morphism_q_to_p  # (H, W, K_p, K_q)
        Phi_p_to_q = np.transpose(Phi_q_to_p, (0, 1, 3, 2))  # (H, W, K_q, K_p)
        mu_p_in_q, sigma_p_in_q = safe_batch_apply_morphism(A.mu_p_field, A.sigma_p_field, Phi_p_to_q)
        flat_mu_p_in_q = mu_p_in_q.reshape(-1, K_q)
        flat_sig_p_in_q = sigma_p_in_q.reshape(-1, K_q, K_q)

        kl_self_field[idx] = kl_divergence(flat_q_mu, flat_q_sig, flat_mu_p_in_q, flat_sig_p_in_q).reshape(H, W)

        # KL(p || Φ·q)
        mu_q_in_p, sigma_q_in_p = safe_batch_apply_morphism(A.mu_q_field, A.sigma_q_field, Phi_q_to_p)
        flat_mu_q_in_p = mu_q_in_p.reshape(-1, K_p)
        flat_sig_q_in_p = sigma_q_in_p.reshape(-1, K_p, K_p)

        kl_feedback_field[idx] = kl_divergence(flat_p_mu, flat_p_sig, flat_mu_q_in_p, flat_sig_q_in_p).reshape(H, W)

        # Pullback metric (q)
        pullback_metric[idx] = compute_pullback_metric(A.mu_q_field, A.sigma_q_field)

        # Curvature tensors
        F_q = compute_field_strength(A.phi, generators=gens_q, dx=dx)["xy"]
        F_p = compute_field_strength(A.phi_model, generators=gens_p, dx=dx)["xy"]

        curv_tensor[idx] = F_q
        curv_model_tensor[idx] = F_p

        # Pullback blocks
        pb = compute_agent_pullback_blocks(A, vis_inds=[0, 1], dark_inds=[2])
        pb_I_list.append(pb["I"])
        pb_G_list.append(pb["G"])
        pb_M_vis_list.append(pb["M_vis"])
        pb_M_dark_list.append(pb["M_dark"])
        pb_Delta_list.append(pb["Delta"])

    # Stack pullback blocks
    pb_I       = np.stack(pb_I_list,      axis=0)
    pb_G       = np.stack(pb_G_list,      axis=0)
    pb_M_vis   = np.stack(pb_M_vis_list,  axis=0)
    pb_M_dark  = np.stack(pb_M_dark_list, axis=0)
    pb_Delta   = np.stack(pb_Delta_list,  axis=0)

    os.makedirs(outdir, exist_ok=True)
    fname = Path(outdir) / f"step{step:05d}.npz"
    np.savez_compressed(
        fname,
        mu_q=mu_q,
        sigma_q=sigma_q,
        phi=phi,
        mu_p=mu_p,
        sigma_p=sigma_p,
        phi_model=phi_model,
        belief_align=belief_align,
        model_align=model_align,
        kl_self=kl_self_field,
        kl_feedback=kl_feedback_field,
        pullback_metric=pullback_metric,
        curv_tensor=curv_tensor,
        curv_model_tensor=curv_model_tensor,
        pullback_I=pb_I,
        pullback_G=pb_G,
        pullback_M_vis=pb_M_vis,
        pullback_M_dark=pb_M_dark,
        pullback_Delta=pb_Delta
    )
    print(f"[DUMP] step={step} → {fname}")

