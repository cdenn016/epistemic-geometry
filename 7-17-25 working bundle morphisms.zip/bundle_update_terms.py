# === generalized_update_rules.py (refactor patch) ===
import numpy as np
import config
from joblib import Parallel, delayed

from natural_gradient_utils import (
    apply_natural_gradient_batch,
    apply_lie_natural_gradient,
    compute_inverse_fisher_field
)

from numerical_utils import sanitize_sigma
from mask_utils import clip_and_mask_gradient
from numerical_utils import safe_inv
from natural_gradient_utils import compute_alignment_kl_gradient
from get_generators import get_generators
from generalized_math_utils import unpack_phi_update_params
from generalized_omega import compute_curvature_gradient_analytical

from generalized_omega import dexpinv_operator, dexpinv_operator_covariance

from bundle_morphism_utils import safe_batch_apply_morphism, gauge_covariant_transform_phi

from natural_gradient_utils import compute_fisher_geometry_gradient
from generalized_math_utils import ( 
        zero_mu_sigma_like, compute_mu_sigma_diff,
        apply_mask_to_mu_sigma
        )

def grad_variance_penalty_field(agent_i, lambda_, field_type="model", mask=None):
    """
    Gradient of Tr(Σ⁻¹) penalty:
        ∇_Σ = -λ Σ⁻¹

    Returns:
        (Δμ, ΔΣ): where Δμ = 0, ΔΣ = -λ Σ⁻¹ (masked if needed)
    """
    if lambda_ <= 0:
        return zero_mu_sigma_like(agent_i, field=field_type)

    sigma = agent_i.sigma_p_field if field_type == "model" else agent_i.sigma_q_field
    mu_shape = agent_i.mu_p_field.shape if field_type == "model" else agent_i.mu_q_field.shape

    H, W, K, _ = sigma.shape
    d_sigma = np.zeros_like(sigma)
    fallback = np.eye(K)

    for i in range(H):
        for j in range(W):
            try:
                inv_ij = np.linalg.inv(sigma[i, j])
            except np.linalg.LinAlgError:
                if getattr(config, "debug", False):
                    print(f"[WARN] grad_variance_penalty_field: Σ⁻¹ fallback at ({i},{j})")
                inv_ij = np.linalg.pinv(sigma[i, j])  # fallback to pseudo-inverse

            d_sigma[i, j] = -lambda_ * inv_ij

    d_sigma = np.nan_to_num(d_sigma)

    if mask is not None:
        _, d_sigma = apply_mask_to_mu_sigma(None, d_sigma, mask)

    d_mu = np.zeros(mu_shape, dtype=d_sigma.dtype)
    return d_mu, d_sigma

def grad_self_field(agent_i, alpha, field_type="model", mask=None,
                             phi_morphism=None, phi_tilde_morphism=None):
    """
    Compute raw Euclidean gradient of morphism-aware self-alignment:
      - field_type="belief" → ∂KL(q || Φ·p)
      - field_type="model"  → ∂KL(p || Φ̃·q)

    The morphism acts as:
      - Φ   : p → q
      - Φ̃  : q → p

    Natural gradient is applied downstream.

    Args:
        agent_i   : Agent object
        alpha     : Scalar coefficient
        field_type: "belief" or "model"
        mask      : Optional spatial mask (H, W)
        phi_morphism        : Φ   (H, W, K_p, K_q) or None = identity
        phi_tilde_morphism  : Φ̃  (H, W, K_q, K_p) or None = identity

    Returns:
        (dμ, dΣ): Euclidean gradients of self-alignment term
    """
    if alpha <= 0:
        return zero_mu_sigma_like(agent_i)

    H, W = agent_i.grid_shape

    if field_type == "belief":
        mu_q, sigma_q = agent_i.mu_q_field, agent_i.sigma_q_field  # q-space
        mu_p, sigma_p = agent_i.mu_p_field, agent_i.sigma_p_field  # p-space
        K_q = mu_q.shape[-1]
        K_p = mu_p.shape[-1]

        if phi_morphism is not None:
            Phi = phi_morphism  # should be (..., K_q, K_p)
        else:
            eye = np.eye(K_q, K_p, dtype=mu_q.dtype)  # p → q maps from K_p to K_q
            Phi = np.broadcast_to(eye, (H, W, K_q, K_p))

        mu_p_trans, sigma_p_trans = safe_batch_apply_morphism(mu_p, sigma_p, Phi, eps=config.eps)
        dμ, dΣ = compute_mu_sigma_diff(mu_q, sigma_q, mu_p_trans, sigma_p_trans, direction="a_minus_b")

    elif field_type == "model":
        mu_q, sigma_q = agent_i.mu_q_field, agent_i.sigma_q_field
        mu_p, sigma_p = agent_i.mu_p_field, agent_i.sigma_p_field
        K_q = mu_q.shape[-1]
        K_p = mu_p.shape[-1]

        if phi_tilde_morphism is not None:
            Phi_tilde = phi_tilde_morphism  # should be (..., K_p, K_q)
        else:
            eye = np.eye(K_p, K_q, dtype=mu_q.dtype)  # q → p maps from K_q to K_p
            Phi_tilde = np.broadcast_to(eye, (H, W, K_p, K_q))

        mu_q_trans, sigma_q_trans = safe_batch_apply_morphism(mu_q, sigma_q, Phi_tilde, eps=config.eps)
        dμ, dΣ = compute_mu_sigma_diff(mu_p, sigma_p, mu_q_trans, sigma_q_trans, direction="a_minus_b")

    else:
        raise ValueError(f"[grad_self_field_morphism] Unknown field_type: {field_type}")

    dμ = np.nan_to_num(dμ)
    dΣ = np.nan_to_num(dΣ)

    if mask is not None:
        dμ, dΣ = apply_mask_to_mu_sigma(dμ, dΣ, mask)

    return alpha * dμ, alpha * dΣ


def grad_feedback_field(agent_i, feedback_weight, field_type="model", mask=None,
                                 phi_morphism=None, phi_tilde_morphism=None):
    """
    Compute raw Euclidean gradient of feedback term:
      - field_type="belief" → ∂_q KL(Φ·p || q)
      - field_type="model"  → ∂_p KL(Φ̃·q || p)

    This is the gradient of KL(transformed other || self).

    Args:
        agent_i        : focal agent
        feedback_weight: scalar
        field_type     : "belief" or "model"
        mask           : optional (H, W)
        phi_morphism   : Φ   ∈ Hom(p → q), or None = identity
        phi_tilde_morphism: Φ̃ ∈ Hom(q → p), or None = identity

    Returns:
        (dμ, dΣ): Euclidean gradients of feedback term
    """
    if feedback_weight <= 0:
        return zero_mu_sigma_like(agent_i, field=field_type)

    H, W = agent_i.grid_shape

    if field_type == "belief":
        mu_self, sigma_self = agent_i.mu_q_field, agent_i.sigma_q_field
        mu_p, sigma_p = agent_i.mu_p_field, agent_i.sigma_p_field
        K_q = mu_self.shape[-1]
        K_p = mu_p.shape[-1]
        if phi_morphism is not None:
            Phi = phi_morphism
        else:
            eye = np.eye(K_q, K_p, dtype=mu_self.dtype)
            Phi = np.broadcast_to(eye, (H, W, K_q, K_p))
        # Pull p into q-space
        mu_p_trans, sigma_p_trans = safe_batch_apply_morphism(mu_p, sigma_p, Phi, eps=config.eps)
        dμ, dΣ = compute_mu_sigma_diff(mu_self, sigma_self, mu_p_trans, sigma_p_trans, direction="b_minus_a")

    elif field_type == "model":
        mu_self, sigma_self = agent_i.mu_p_field, agent_i.sigma_p_field
        mu_q, sigma_q = agent_i.mu_q_field, agent_i.sigma_q_field
        K_q = mu_q.shape[-1]
        K_p = mu_self.shape[-1]
        if phi_tilde_morphism is not None:
            Phi_tilde = phi_tilde_morphism
        else:
            eye = np.eye(K_p, K_q, dtype=mu_self.dtype)
            Phi_tilde = np.broadcast_to(eye, (H, W, K_p, K_q))
        # Pull q into p-space
        mu_q_trans, sigma_q_trans = safe_batch_apply_morphism(mu_q, sigma_q, Phi_tilde, eps=config.eps)
        dμ, dΣ = compute_mu_sigma_diff(mu_self, sigma_self, mu_q_trans, sigma_q_trans, direction="b_minus_a")

    else:
        raise ValueError(f"[grad_feedback_field_morphism] Unknown field_type: {field_type}")

    dμ = np.nan_to_num(dμ)
    dΣ = np.nan_to_num(dΣ)

    if mask is not None:
        dμ, dΣ = apply_mask_to_mu_sigma(dμ, dΣ, mask)

    return feedback_weight * dμ, feedback_weight * dΣ


def alignment_gradient_field(agent_i, agents, params, field_type="model", mask=None):
    """
    Raw Euclidean gradient of alignment KL divergence:
        KL(q_i || Ω_ij q_j) or KL(p_i || Ω̃_ij p_j)

    Natural gradient is applied centrally in combine_field_gradients.

    Args:
        agent_i    : focal agent
        agents     : list of agents
        params     : dict of parameters
        field_type : "model" or "belief"
        mask       : optional spatial mask to restrict update region

    Returns:
        dμ, dΣ : raw Euclidean gradients (H, W, K), (H, W, K, K)
    """
    if field_type == "model":
        weight = params.get("model_align_weight", config.model_align_weight)
        K_fiber = agent_i.mu_p_field.shape[-1]
    elif field_type == "belief":
        weight = params.get("beta", config.beta)
        K_fiber = agent_i.mu_q_field.shape[-1]
    else:
        raise ValueError(f"[alignment_gradient_field] Unknown field_type: {field_type}")

    if weight <= 0:
        return zero_mu_sigma_like(agent_i, field=field_type)

    # Load or generate the appropriate representation generators
    generators = params.get("generators", get_generators(config.group_name, K_fiber))

    # Compute raw KL alignment gradients
    dμ, dΣ = compute_alignment_kl_gradient(agent_i, agents, generators, params, field_type=field_type)

    # Ensure numerical stability
    dμ = np.nan_to_num(dμ)
    dΣ = np.nan_to_num(dΣ)

    # Apply optional mask
    if mask is not None:
        dμ, dΣ = apply_mask_to_mu_sigma(dμ, dΣ, mask)

    return weight * dμ, weight * dΣ



def combine_field_gradients(agent_i, agents, params, field_type="model"):
    if field_type == "model" and getattr(config, "identical_models", False):
        return zero_mu_sigma_like(agent_i)

    # Load all parameters
    α  = params.get("alpha", config.alpha)
    β  = params.get("model_align_weight", config.model_align_weight) if field_type == "model" else params.get("beta", config.beta)
    fb = params.get("model_feedback_weight", config.model_feedback_weight) if field_type == "model" else params.get("belief_feedback_weight", getattr(config, "belief_feedback_weight", 0.0))
    λ  = params.get("variance_penalty_model_weight", getattr(config, "variance_penalty_model_weight", 0.0)) if field_type == "model" else params.get("variance_penalty_belief_weight", getattr(config, "variance_penalty_belief_weight", 0.0))
    eps = params.get("support_cutoff_eps", config.support_cutoff_eps)

    # Mask
    mask = agent_i.mask > eps
    if not np.any(mask):
        return zero_mu_sigma_like(agent_i)

    # Select fields
    mu_field    = agent_i.mu_p_field if field_type == "model" else agent_i.mu_q_field
    sigma_field = agent_i.sigma_p_field if field_type == "model" else agent_i.sigma_q_field

    # --- Natural-gradient components ---
    grad_mu_nat    = np.zeros_like(mu_field)
    grad_sigma_nat = np.zeros_like(sigma_field)

    if α > 0:
        dμ, dΣ = grad_self_field(agent_i, α, field_type, mask)
        grad_mu_nat += dμ
        grad_sigma_nat += dΣ
    if fb > 0:
        dμ, dΣ = grad_feedback_field(agent_i, fb, field_type, mask)
        grad_mu_nat += dμ
        grad_sigma_nat += dΣ
    if β > 0:
        dμ, dΣ = alignment_gradient_field(agent_i, agents, params, field_type=field_type, mask=mask)

        grad_mu_nat += dμ
        grad_sigma_nat += dΣ

    # --- Apply Fisher preconditioner only to KL terms ---
    delta_mu, delta_sigma = apply_natural_gradient_batch(
        mu_field, sigma_field, grad_mu_nat, grad_sigma_nat
    )

    # --- Add regularization (coordinate) terms AFTER natural gradient ---
    if λ > 0:
        dμ_reg, dΣ_reg = grad_variance_penalty_field(agent_i, λ, field_type, mask)
        delta_mu    += dμ_reg
        delta_sigma += dΣ_reg

    # Final nan sanitization
    delta_mu    = np.nan_to_num(delta_mu, nan=0.0, posinf=1e5, neginf=-1e5)
    delta_sigma = np.nan_to_num(delta_sigma, nan=0.0, posinf=1e5, neginf=-1e5)

    return delta_mu, delta_sigma

def compute_phi_update_belief(agent_i, agents, params):
    return compute_phi_update_core(agent_i, agents, params, field="phi")

def compute_phi_update_model(agent_i, agents, params):
    return compute_phi_update_core(agent_i, agents, params, field="phi_model")

def compute_phi_update_core(agent_i, agents, params, field):
    """
    Core φ update shared by belief and model alignment.

    Args:
        agent_i  : current agent
        agents   : list of all agents
        params   : dictionary of parameters
        field    : "phi" or "phi_model"
    Returns:
        gradient update ∂L/∂φ (same shape as φ)
    """
    if field == "phi_model" and getattr(config, "identical_models", False):
        return np.zeros_like(agent_i.phi_model)

    # --- Unpack parameters ---
    unpacked   = unpack_phi_update_params(params, field=field)
    β          = params.get("beta", config.beta) if field == "phi" else params.get("model_align_weight", config.model_align_weight)
    κ          = unpacked["κ"]
    γ          = unpacked["gw"]
    curv_w     = unpacked["curv_weight"]
    clip_th    = unpacked["grad_clip_threshold"]
    eps        = unpacked["overlap_eps"]
    debug      = unpacked["debug"]

    phi        = agent_i.phi if field == "phi" else agent_i.phi_model
    phi_tilde  = agent_i.phi_model if field == "phi" else agent_i.phi
    soft_mask  = agent_i.mask[..., None]

    # --- Dynamically load generators based on fiber dimension ---
    K_fiber = agent_i.mu_q_field.shape[-1] if field == "phi" else agent_i.mu_p_field.shape[-1]
    generators = params.get("generators", get_generators(config.group_name, K_fiber))

    if not np.any(soft_mask > eps):
        return np.zeros_like(phi)

    grad = np.zeros_like(phi)
    G_inv = compute_inverse_fisher_field(agent_i, generators, field=field)

    # --- 1. Alignment gradient ---
    if β > 0:
        grad_align = np.zeros_like(phi)
        for neighbor in agent_i.neighbors:
            agent_j = agents[neighbor["id"]]

            expected_K_in = agent_j.mu_q_field.shape[-1] if field == "phi" else agent_j.mu_p_field.shape[-1]
            assert expected_K_in == generators.shape[-1], \
                f"[alignment] K mismatch: expected {expected_K_in}, but generators have dim {generators.shape[-1]}"

            if field == "phi":
                accumulate_phi_gradient_belief(agent_i, agent_j, generators, params)
            else:
                accumulate_phi_gradient_model(agent_i, agent_j, generators, params)

        grad_align = agent_i.grad_phi.copy()
        agent_i.grad_phi[:] = 0.0  # reset cache

        grad += apply_lie_natural_gradient(phi, grad_align, G_inv=G_inv)

    # --- 2. Curvature term ∇_μ F^μ ---
    if curv_w > 0:
        grad += curv_w * compute_curvature_gradient_analytical(phi, generators)

    # --- 3. Mass term: 2γ φ ---
    if γ > 0:
        grad += 2 * γ * phi

    # --- 4. Coupling term: 2κ (φ − φ̃) ---
    if κ > 0:
        grad += 2 * κ * (phi - phi_tilde)

    return clip_and_mask_gradient(grad, soft_mask, clip_th, eps)




def compute_joint_mask(agent_i, agent_j, eps):
    mask_i = agent_i.mask[..., None] > eps
    mask_j = agent_j.mask[..., None] > eps
    return mask_i & mask_j

def extract_belief_fields(agent_i, agent_j):
    mu_i = agent_i.mu_q_field
    sigma_i = agent_i.sigma_q_field
    mu_j = agent_j.mu_q_field
    sigma_j = agent_j.sigma_q_field
    return mu_i, sigma_i, mu_j, sigma_j

def extract_model_fields(agent_i, agent_j):
    mu_i = agent_i.mu_p_field
    sigma_i = agent_i.sigma_p_field
    mu_j = agent_j.mu_p_field
    sigma_j = agent_j.sigma_p_field
    return mu_i, sigma_i, mu_j, sigma_j


def extract_phi_and_omega(agent_i, agent_j, field):
    phi_i = getattr(agent_i, field)
    phi_j = getattr(agent_j, field)
    omega_name = f"Omega{'' if field == 'phi' else '_model'}"
    Omega_ij = getattr(agent_i, omega_name)
    return phi_i, phi_j, Omega_ij

def get_bundle_morphism(agent_i, agent_j, params, field):
    key = "bundle_morphism_q_to_p_fn" if field == "phi" else "bundle_morphism_p_to_q_fn"
    morphism_fn = params.get(key, None)
    return morphism_fn(agent_i, agent_j)

def transport_fields(mu_j, sigma_j, Omega_ij, Phi_ij):
    """
    Transport μ_j and Σ_j from agent_j to agent_i using the gauge-covariant operator:
        T = Φ_ij @ Ω_ij

    Inputs:
        mu_j      : (..., K_q)         – belief mean of agent_j
        sigma_j   : (..., K_q, K_q)    – belief covariance of agent_j
        Omega_ij  : (..., K_q, K_q)    – gauge transport operator from j to i
        Phi_ij    : (..., K_p, K_q)    – bundle morphism from q-fiber to p-fiber

    Returns:
        T             : (..., K_p, K_q) – total transport operator
        mu_trans      : (..., K_p)
        sigma_trans   : (..., K_p, K_p)
    """
    # Transport operator: Φ @ Ω
    T = np.einsum("...ik,...kj->...ij", Phi_ij, Omega_ij)   # (H,W,K_p,K_q)

    # Sanity checks
    assert T.shape[-1] == sigma_j.shape[-1], \
        f"Mismatch in inner dim: T={T.shape}, sigma_j={sigma_j.shape}"
    assert sigma_j.shape[-2] == sigma_j.shape[-1], \
        f"sigma_j must be square: got {sigma_j.shape}"

    # Transport mean: μ' = T · μ_j
    mu_trans = np.einsum("...ij,...j->...i", T, mu_j)       # (H,W,K_p)

    # Transport covariance: Σ' = T · Σ · Tᵀ
    sigma_trans = np.einsum("...ik,...kl,...jl->...ij", T, sigma_j, T)

    return T, mu_trans, sigma_trans


def compute_generator_gradients_belief(
    generators, Omega_ij, Phi_ij, mu_j, sigma_j,
    T, T_T, d_mu, d_sigma, shape
):
    """
    Compute ∂/∂φ_i and ∂/∂φ_j of KL[q_i ‖ Ω_ij Φ_ij q_j] in belief space.

    Args:
        generators : (d, K_q, K_q)
        Omega_ij   : (H, W, K_q, K_q)
        Phi_ij     : (H, W, K_q, K_p)  # Φ : ℝ^{K_p} → ℝ^{K_q}
        mu_j       : (H, W, K_p)
        sigma_j    : (H, W, K_p, K_p)
        T, T_T     : (H, W, K_q, K_p), (H, W, K_p, K_q)
        d_mu       : (H, W, K_q)
        d_sigma    : (H, W, K_q, K_q)
        shape      : (H, W, d)

    Returns:
        grad_i, grad_j : (H, W, d)
    """
    d = generators.shape[0]
    grad_i = np.zeros(shape)
    grad_j = np.zeros(shape)

    # Validate input shapes
    H, W = shape[:2]
    K_q = generators.shape[-1]
    K_p = mu_j.shape[-1]

    assert Omega_ij.shape == (H, W, K_q, K_q)
    assert Phi_ij.shape == (H, W, K_q, K_p)
    assert mu_j.shape   == (H, W, K_p)
    assert sigma_j.shape == (H, W, K_p, K_p)
    assert T.shape      == (H, W, K_q, K_p)
    assert T_T.shape    == (H, W, K_p, K_q)
    assert d_mu.shape   == (H, W, K_q)
    assert d_sigma.shape == (H, W, K_q, K_q)

    for a in range(d):
        G = generators[a]  # (K_q, K_q)

        # Compute OG = Ω @ G
        OG = np.einsum("...ij,jk->...ik", Omega_ij, G)  # (H, W, K_q, K_q)

        # Apply OG to Φᵀ: (K_q, K_q) @ (K_q, K_p) → (K_q, K_p)
        OG_Phi = np.einsum("...ik,...kj->...ij", OG, Phi_ij)  # (H, W, K_q, K_p)

        # First-order term from μ
        dphi_mu = np.einsum("...ij,...j->...i", OG_Phi, mu_j)  # (H, W, K_q)

        # Second-order terms from σ
        OG_sigma = np.einsum("...ij,...jk->...ik", OG_Phi, sigma_j)     # (H, W, K_q, K_p)
        dphi_sigma_1 = np.einsum("...ij,...jk->...ik", OG_sigma, T_T)   # (H, W, K_q, K_q)

        sigma_GT = np.einsum("...ij,jk->...ik", sigma_j, G.T)           # (H, W, K_p, K_p)
        O_sigma_GT = np.einsum("...ij,...jk->...ik", T, sigma_GT)       # (H, W, K_q, K_p)
        dphi_sigma_2 = np.einsum("...ij,...jk->...ik", O_sigma_GT, T_T) # (H, W, K_q, K_q)

        dphi_sigma = dphi_sigma_1 + dphi_sigma_2  # (H, W, K_q, K_q)

        # Project into Lie algebra gradient via ⟨δμ, ∂μ⟩ + ⟨δΣ, ∂Σ⟩
        delta_a = (
            np.sum(d_mu * dphi_mu, axis=-1) +
            np.einsum("...ij,...ij->...", d_sigma, dphi_sigma)
        )

        grad_i[..., a] += delta_a
        grad_j[..., a] -= delta_a

    return grad_i, grad_j



def compute_generator_gradients_model(
    generators, Omega_ij, Phi_ij, mu_j, sigma_j,
    T, T_T, d_mu, d_sigma, shape
):
    """
    Compute ∂/∂φ̃_i and ∂/∂φ̃_j of KL[p_i ‖ Ω̃_ij Φ̃_ij p_j] in model space.

    Shapes and logic mirror the belief version but use model fields.
  
    Args:
        generators : (d, K_q, K_q)
        Omega_ij   : (H, W, K_q, K_q)
        Phi_ij     : (H, W, K_p, K_q)
        mu_j       : (H, W, K_p)
        sigma_j    : (H, W, K_p, K_p)
        T, T_T     : (H, W, K_p, K_q), (H, W, K_q, K_p)
        d_mu       : (H, W, K_q)
        d_sigma    : (H, W, K_q, K_q)
        shape      : (H, W, d)

    Returns:
        grad_i, grad_j : (H, W, d)
    """
    d = generators.shape[0]
    grad_i = np.zeros(shape)
    grad_j = np.zeros(shape)

    # Transpose Φ from (K_p, K_q) to (K_q, K_p)
    Phi_T = np.transpose(Phi_ij, (0, 1, 3, 2))  # (H, W, K_q, K_p)

    for a in range(d):
        G = generators[a]  # (K_q, K_q)

        OG = np.einsum("...ij,jk->...ik", Omega_ij, G)             # (H, W, K_q, K_q)
        OG_Phi = np.einsum("...ik,...kj->...ij", OG, Phi_T)        # (H, W, K_q, K_p)

        dphi_mu = np.einsum("...ij,...j->...i", OG_Phi, mu_j)      # (H, W, K_q)

        OG_sigma = np.einsum("...ij,...jk->...ik", OG_Phi, sigma_j)       # (H, W, K_q, K_p)
        dphi_sigma_1 = np.einsum("...ij,...jk->...ik", OG_sigma, T_T)     # (H, W, K_q, K_q)

        sigma_GT = np.einsum("...ij,jk->...ik", sigma_j, G.T)             # (H, W, K_p, K_p)
        O_sigma_GT = np.einsum("...ij,...jk->...ik", T, sigma_GT)         # (H, W, K_q, K_p)
        dphi_sigma_2 = np.einsum("...ij,...jk->...ik", O_sigma_GT, T_T)   # (H, W, K_q, K_q)

        dphi_sigma = dphi_sigma_1 + dphi_sigma_2

        delta_a = (
            np.sum(d_mu * dphi_mu, axis=-1) +
            np.einsum("...ij,...ij->...", d_sigma, dphi_sigma)
        )

        grad_i[..., a] += delta_a
        grad_j[..., a] -= delta_a

    return grad_i, grad_j


def accumulate_into_agent(agent, grad_phi, beta, mask):
    if not hasattr(agent, "grad_phi"):
        agent.grad_phi = np.zeros_like(grad_phi)
    agent.grad_phi += beta * grad_phi * mask



def accumulate_phi_gradient_belief(agent_i, agent_j, generators, params):
    """
    Accumulate φ gradient for belief alignment: ∂KL(q_i ‖ Ω_ij Φ_ij q_j)
    """
    beta = params.get("beta", config.beta)
    if beta <= 0:
        return

    joint_mask = compute_joint_mask(agent_i, agent_j, config.support_cutoff_eps)

    mu_i, sigma_i = agent_i.mu_q_field, agent_i.sigma_q_field
    mu_j, sigma_j = agent_j.mu_q_field_original, agent_j.sigma_q_field_original

    phi_i, phi_j, Omega_ij = extract_phi_and_omega(agent_i, agent_j, field="phi")
    # [TEMP] Skip inter-agent Φ_ij morphism — use identity
    K_q = mu_i.shape[-1]
    Phi_ij = np.broadcast_to(np.eye(K_q, dtype=mu_i.dtype), (mu_i.shape[0], mu_i.shape[1], K_q, K_q))

    transport_op, mu_trans, sigma_trans = transport_fields(mu_j, sigma_j, Omega_ij, Phi_ij)
    sigma_trans = sanitize_sigma(sigma_trans, eps=config.eps)
    sigma_inv = safe_inv(sigma_trans, eps=config.eps)

    mu_proj, sigma_proj = safe_batch_apply_morphism(mu_i, sigma_i, Phi_ij, eps=config.eps)
    delta_mu = mu_proj - mu_trans
    delta_sigma = sigma_proj - sigma_trans

    d_mu = -np.einsum("...ij,...j->...i", sigma_inv, delta_mu)
    d_sigma = -0.5 * np.einsum("...ik,...kl,...lj->...ij", sigma_inv, delta_sigma, sigma_inv)

    grad_phi_i, grad_phi_j = compute_generator_gradients_belief(
        generators, Omega_ij, Phi_ij, mu_j, sigma_j,
        transport_op, transport_op.transpose(0, 1, 3, 2),
        d_mu, d_sigma, phi_i.shape
    )

    grad_phi_i = dexpinv_operator(phi_i, grad_phi_i, generators) + dexpinv_operator_covariance(phi_i, d_sigma, generators)
    grad_phi_j = dexpinv_operator(phi_j, grad_phi_j, generators) + dexpinv_operator_covariance(phi_j, -d_sigma, generators)

    accumulate_into_agent(agent_i, grad_phi_i, beta, joint_mask)
    accumulate_into_agent(agent_j, grad_phi_j, beta, joint_mask)

def accumulate_phi_gradient_model(agent_i, agent_j, generators, params):
    """
    Accumulate φ̃ gradient for model alignment: ∂KL(p_i ‖ Ω̃_ij Φ̃_ij p_j)
    """
    beta = params.get("model_align_weight", config.model_align_weight)
    if beta <= 0:
        return

    joint_mask = compute_joint_mask(agent_i, agent_j, config.support_cutoff_eps)

    mu_i, sigma_i = agent_i.mu_p_field, agent_i.sigma_p_field
    mu_j, sigma_j = agent_j.mu_p_field_original, agent_j.sigma_p_field_original

    phi_i, phi_j, Omega_ij = extract_phi_and_omega(agent_i, agent_j, field="phi_model")
    # [TEMP] Skip inter-agent Φ̃_ij morphism — use identity
    K_p = mu_i.shape[-1]
    Phi_ij = np.broadcast_to(np.eye(K_p, dtype=mu_i.dtype), (mu_i.shape[0], mu_i.shape[1], K_p, K_p))

    transport_op, mu_trans, sigma_trans = transport_fields(mu_j, sigma_j, Omega_ij, Phi_ij)
    sigma_trans = sanitize_sigma(sigma_trans, eps=config.eps)
    sigma_inv = safe_inv(sigma_trans, eps=config.eps)

    mu_proj, sigma_proj = safe_batch_apply_morphism(mu_i, sigma_i, Phi_ij, eps=config.eps)
    delta_mu = mu_proj - mu_trans
    delta_sigma = sigma_proj - sigma_trans

    d_mu = -np.einsum("...ij,...j->...i", sigma_inv, delta_mu)
    d_sigma = -0.5 * np.einsum("...ik,...kl,...lj->...ij", sigma_inv, delta_sigma, sigma_inv)

    grad_phi_i, grad_phi_j = compute_generator_gradients_model(
        generators, Omega_ij, Phi_ij, mu_j, sigma_j,
        transport_op, transport_op.transpose(0, 1, 3, 2),
        d_mu, d_sigma, phi_i.shape
    )

    grad_phi_i = dexpinv_operator(phi_i, grad_phi_i, generators) + dexpinv_operator_covariance(phi_i, d_sigma, generators)
    grad_phi_j = dexpinv_operator(phi_j, grad_phi_j, generators) + dexpinv_operator_covariance(phi_j, -d_sigma, generators)

    accumulate_into_agent(agent_i, grad_phi_i, beta, joint_mask)
    accumulate_into_agent(agent_j, grad_phi_j, beta, joint_mask)




def compute_phi_morphism_gradient(agent_i, agent_j, Phi_field, rho_q_func, rho_p_func, field="phi"):
    """
    Compute the variational gradient ∂/∂Φ of KL[q_i || Φ ∘ Ω_ij(q_j)].

    Args:
        agent_i     : receiving agent (reference belief)
        agent_j     : sending agent (to be transported)
        Phi_field   : (H, W, K_p, K_q) current bundle morphism Φ
        rho_q_func  : φ → ρ_q(exp(φ)) (returns (K_q, K_q))
        rho_p_func  : φ → ρ_p(exp(φ)) (returns (K_p, K_p))
        field       : "phi" (belief) or "phi_model" (model)

    Returns:
        dPhi_field  : (H, W, K_p, K_q) gradient of KL wrt Φ
    """
    eps = 1e-8
    mu_i     = agent_i.mu_q_field     if field == "phi" else agent_i.mu_p_field
    mu_j     = agent_j.mu_q_field     if field == "phi" else agent_j.mu_p_field
    sigma_i  = agent_i.sigma_q_field  if field == "phi" else agent_i.sigma_p_field
    sigma_j  = agent_j.sigma_q_field  if field == "phi" else agent_j.sigma_p_field
    Omega_ij = agent_i.Omega          if field == "phi" else agent_i.Omega_model

    mask_i = agent_i.mask[..., None] > eps
    mask_j = agent_j.mask[..., None] > eps
    joint_mask = (mask_i & mask_j)[..., 0]

    H, W, K_p, K_q = Phi_field.shape
    dPhi_field = np.zeros((H, W, K_p, K_q), dtype=Phi_field.dtype)

    for i in range(H):
        for j in range(W):
            if not joint_mask[i, j]:
                continue

            phi = agent_i.phi[i, j] if field == "phi" else agent_i.phi_model[i, j]
            rho_q = rho_q_func(phi)                     # (K_q, K_q)
            rho_p = rho_p_func(phi)                     # (K_p, K_p)
            inv_rho_q = safe_inv(rho_q, eps=eps)        # (K_q, K_q)

            Omega = Omega_ij[i, j]                      # (K_q, K_q)
            mu_j_ = mu_j[i, j]                          # (K_q,)
            sigma_j_ = sigma_j[i, j]                    # (K_q, K_q)
            mu_i_ = mu_i[i, j]                          # (K_p,)
            sigma_i_ = sigma_i[i, j]                    # (K_p, K_p)

            mu_omega = Omega @ mu_j_                    # (K_q,)
            sigma_omega = Omega @ sigma_j_ @ Omega.T    # (K_q, K_q)
            sigma_omega = sanitize_sigma(sigma_omega, eps)

            Phi = Phi_field[i, j]                       # (K_p, K_q)
            total_map = rho_p @ Phi @ inv_rho_q         # (K_p, K_q)

            mu_trans = total_map @ mu_omega             # (K_p,)
            sigma_trans = total_map @ sigma_omega @ total_map.T  # (K_p, K_p)
            sigma_trans = sanitize_sigma(sigma_trans, eps)

            delta_mu = mu_i_ - mu_trans
            sigma_inv = safe_inv(sigma_trans, eps=eps)

            d_mu = -sigma_inv @ delta_mu                # (K_p,)

            delta_sigma = sigma_i_ - sigma_trans
            d_sigma = -0.5 * (sigma_inv @ delta_sigma @ sigma_inv)
            d_sigma = 0.5 * (d_sigma + d_sigma.T)       # symmetrize

            # Chain rule: ∂KL/∂Φ = ∂KL/∂μ × ∂μ/∂Φ + ∂KL/∂Σ × ∂Σ/∂Φ
            x = inv_rho_q @ mu_omega                    # (K_q,)
            dPhi_mu = np.outer(d_mu, x)                 # (K_p, K_q)

            S = inv_rho_q @ sigma_omega @ inv_rho_q.T   # (K_q, K_q)
            temp = d_sigma @ rho_p @ Phi                # (K_p, K_q)
            dPhi_sigma = 2 * (temp @ S)                 # (K_p, K_q)

            dPhi_field[i, j] = rho_p.T @ (dPhi_mu + dPhi_sigma)

    return dPhi_field


def gradient_step_phi_morphism(agent_i, agents, generators, params, rho_q_func, rho_p_func):
    """
    Compute the natural gradient step for φ̃ (phi_morphism), governing bundle morphism Φ.

    This enforces alignment between agent_i.p and Φ_{ij}·agent_j.p for all neighbors j.
    """
    beta = params.get("model_align_weight", config.model_align_weight)
    eps  = params.get("support_cutoff_eps", config.support_cutoff_eps)

    if beta <= 0 or not np.any(agent_i.mask > eps):
        return np.zeros_like(agent_i.phi_model)

    phi_i = agent_i.phi_model
    grad_phi = np.zeros_like(phi_i)

    for neighbor in agent_i.neighbors:
        agent_j = agents[neighbor["id"]]

        phi_j = agent_j.phi_model  # φ̃_j — Lie algebra coordinates of j
        Phi   = agent_j.bundle_morphism_q_to_p  # raw Φ_j field

        # Compute Φ_ij = ρ_p(exp(φ_i)) · Φ_j · ρ_q(exp(−φ_j))
        Phi_transformed = gauge_covariant_transform_phi(phi_i, Phi, rho_q_func, rho_p_func)

        # Compute transported model fields
        mu_j = agent_j.mu_p_field
        sigma_j = agent_j.sigma_p_field

        mu_trans = np.einsum("...ij,...j->...i", Phi_transformed, mu_j)
        sigma_trans = np.einsum("...ik,...kl,...jl->...ij", Phi_transformed, sigma_j, Phi_transformed)

        mu_i = agent_i.mu_p_field
        sigma_i = agent_i.sigma_p_field
        delta_mu = mu_i - mu_trans
        delta_sigma = sigma_i - sigma_trans
        sigma_inv = safe_inv(sanitize_sigma(sigma_trans), eps=config.eps)

        # === Compute φ̃ gradient w.r.t. transport error ===
        d_mu = -np.einsum("...ij,...j->...i", sigma_inv, delta_mu)
        d_sigma = -0.5 * np.einsum("...ik,...kl,...lj->...ij", sigma_inv, delta_sigma, sigma_inv)

        # === Project to Lie algebra coordinates ===
        d_mu_proj = np.einsum("...ij,ajk->...a", np.expand_dims(d_mu, -1), generators)  # (..., a)

        d_phi_mu = dexpinv_operator(phi_i, d_mu_proj, generators)
        d_phi_sigma = dexpinv_operator_covariance(phi_i, d_sigma, generators)
        grad = d_phi_mu + d_phi_sigma

        # Masked contribution
        joint_mask = (agent_i.mask > eps) & (agent_j.mask > eps)
        grad_phi += beta * grad * joint_mask[..., None]

    return grad_phi


