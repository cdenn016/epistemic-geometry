# -*- coding: utf-8 -*-
"""
Created on Sun Jul 13 13:06:16 2025

@author: chris and christine
"""

# numerical_utils.py
import numpy as np
import config
from joblib import Parallel, delayed
from numpy.linalg import LinAlgError
import warnings

# numerical_utils.py

import warnings
from collections import defaultdict
import config

# Global counters
fallback_counter = defaultdict(int)

def reset_fallback_counters():
    """Call this at the start of each simulation/run."""
    fallback_counter.clear()

def report_and_maybe_fail():
    """Inspect counters against config thresholds."""
    invs = fallback_counter.get("safe_inv", 0)
    logs = fallback_counter.get("safe_logdet", 0)
    if invs or logs:
        msg = (
            f"[Fallback Summary] safe_inv: {invs}, safe_logdet: {logs}"
            f"{', raising error' if config.fail_on_fallback else ''}"
        )
        # Always log
        print(msg)
    # Fail if configured
    if config.fail_on_fallback:
        if invs > 0 or logs > 0:
            raise RuntimeError("Numerical fallback occurred under strict mode.")
    # Or threshold-based
    if invs > config.max_safe_inv_fallbacks:
        raise RuntimeError(f"Exceeded max_safe_inv_fallbacks ({invs})")
    if logs > config.max_safe_logdet_fallbacks:
        raise RuntimeError(f"Exceeded max_safe_logdet_fallbacks ({logs})")

def safe_omega_inv(M):
    """
    Invert Ω with condition‑number checks and robust fallback.
    """
    # 1. Check conditioning
    cond = np.linalg.cond(M)
    if cond > 1e8:
        msg = f"[safe_omega_inv] High condition number: {cond:.2e}"
        if config.fail_on_fallback:
            raise RuntimeError(msg)
        warnings.warn(msg, RuntimeWarning)

    # 2. Attempt inversion
    try:
        return np.linalg.inv(M)
    except np.linalg.LinAlgError as e:
        fallback_counter["omega_inv"] += 1
        msg = f"[safe_omega_inv] Inversion failed (fallback #{fallback_counter['omega_inv']}), returning identity"
        if config.fail_on_fallback:
            raise RuntimeError(msg) from e
        warnings.warn(msg, RuntimeWarning)
        K = M.shape[-1]
        return np.eye(K)


def safe_inv(Sigma, eps=1e-8, fallback_identity=True):
    K = Sigma.shape[-1]
    try:
        return np.linalg.inv(Sigma + eps * np.eye(K))
    except np.linalg.LinAlgError as e:
        fallback_counter["safe_inv"] += 1
        msg = f"[safe_inv] Fallback #{fallback_counter['safe_inv']}: returning identity*{config.sanitize_fallback_value}"
        if config.fail_on_fallback:
            raise RuntimeError(msg) from e
        warnings.warn(msg, RuntimeWarning)
        return np.eye(K) * config.sanitize_fallback_value

import numpy as np
import warnings
from collections import defaultdict
import config



def _sanitize_one_sigma(S, eps=1e-6):
    """
    Sanitize a single covariance matrix to ensure it's symmetric positive-definite (SPD).

    Returns:
        (S_sanitized, clipped): sanitized matrix and boolean flag indicating if it was modified
    """
    S = 0.5 * (S + S.T)  # ensure symmetry

    # First line of defense: handle invalid or pathological cases
    if not np.all(np.isfinite(S)) or np.trace(S) < eps or np.any(np.diag(S) <= 0):
        return np.eye(S.shape[0]) * eps, True

    try:
        eigvals, eigvecs = np.linalg.eigh(S)
    except np.linalg.LinAlgError:
        return np.eye(S.shape[0]) * eps, True

    clipped = np.any(eigvals < eps)
    eigvals_clipped = np.clip(eigvals, eps, None)

    if clipped:
        S = eigvecs @ np.diag(eigvals_clipped) @ eigvecs.T
        S = 0.5 * (S + S.T)  # re-symmetrize

    return S, clipped


def sanitize_sigma(Sigma, eps=1e-6, debug=False, n_jobs=None, parallel_threshold=50):
    """
    Sanitize a batch of covariance matrices to ensure SPD.

    Parameters:
        Sigma: (..., K, K) ndarray — batch of covariances
        eps: minimum eigenvalue threshold
        debug: if True, prints a summary if any matrices are clipped
        n_jobs: number of parallel workers (default: config.num_cores or 1)
        parallel_threshold: min number of matrices before enabling parallelization

    Returns:
        Sanitized SPD matrices with same shape as input.
    """
    shape = Sigma.shape
    flat_sigma = Sigma.reshape(-1, shape[-2], shape[-1])
    n_total = flat_sigma.shape[0]
    n_jobs = n_jobs or getattr(config, "num_cores", 1)

    if n_total < parallel_threshold or n_jobs == 1:
        results = [_sanitize_one_sigma(S, eps) for S in flat_sigma]
    else:
        from joblib import parallel_backend
        with parallel_backend("threading"):
            results = Parallel(n_jobs=n_jobs)(
                delayed(_sanitize_one_sigma)(S, eps) for S in flat_sigma
            )

    Sigma_out, clipped_flags = zip(*results)
    if debug:
        n_clipped = sum(clipped_flags)
        if n_clipped > 0:
            print(f"[SPD sanitize] Clipped {n_clipped} / {n_total} matrices to eps={eps:.1e}")

    out = np.stack(Sigma_out, axis=0).astype(Sigma.dtype).reshape(shape)
    return out

def check_matrix_validity(S, eps=1e-6):
    eigvals = np.linalg.eigvalsh(S)
    return np.all(np.isfinite(S)) and np.all(eigvals > eps)


import numpy as np
import config
import warnings



def check_spd_field(field: np.ndarray, tol=1e-8) -> bool:
    """
    Verifies whether a full field (H, W, K, K) is SPD everywhere.
    Returns True if all matrices pass, False otherwise.
    """
    H, W, K, _ = field.shape
    
    for i in range(H):
        for j in range(W):
            if not is_spd_matrix(field[i, j], tol=tol):
                return False
    return True


def is_spd_matrix(A: np.ndarray, tol=1e-8) -> bool:
    """
    Check whether a matrix A is symmetric positive definite (SPD).
    """
    if not np.allclose(A, A.T, atol=tol):
        return False
    try:
        np.linalg.cholesky(A)
        return True
    except LinAlgError:
        return False

def safe_log(x, eps: float = 1e-12):
    """
    Numerically stable natural log.

    Parameters
    ----------
    x : float | np.ndarray
        Input value(s). Can be scalar or array-like.
    eps : float, optional
        Values below `eps` are clipped up to `eps` before taking log,
        preventing -inf.  Default is 1e-12.

    Returns
    -------
    np.ndarray | float
        np.log( max(x, eps) ), broadcast over x.
    """
    return np.log(np.clip(x, eps, None))

from scipy.linalg import logm

def safe_logm(M, fallback_value=None, imag_tol=1e-10, context="Ω"):
    """
    Compute logm(M) safely:
      - Warn on imaginary part
      - Raise or fallback on failure

    Args:
        M : (K, K) matrix
        fallback_value : optional fallback (e.g., np.zeros_like(M))
        imag_tol : acceptable ‖Im(logM)‖ (Frobenius norm)
        context : str, name for warnings

    Returns:
        real logm(M) if stable, fallback if not
    """
    try:
        logM = logm(M)
        imag_norm = np.linalg.norm(np.imag(logM), ord="fro")

        if imag_norm > imag_tol:
            msg = f"[safe_logm] {context}: ‖Im(logm)‖={imag_norm:.2e} > tol={imag_tol}"
            if config.fail_on_fallback:
                raise RuntimeError(msg)
            warnings.warn(msg, RuntimeWarning)

        return np.real_if_close(logM, tol=imag_tol)
    
    except Exception as e:
        fallback_counter["safe_logm"] += 1
        msg = f"[safe_logm] {context}: logm failed ({str(e)}), fallback #{fallback_counter['safe_logm']}"
        if config.fail_on_fallback:
            raise RuntimeError(msg) from e
        warnings.warn(msg, RuntimeWarning)
        if fallback_value is not None:
            return fallback_value
        else:
            K = M.shape[0]
            return np.zeros((K, K))


fallback_counter = defaultdict(int)

def safe_logdet(Sigma, eps=1e-8):
    """
    Compute log|Σ| robustly, with fallback on failure.
    Supports both scalar and batched input. Always returns a float or array.
    """
    K = Sigma.shape[-1]
    try:
        # Use slogdet for numerical stability
        sign, ld = np.linalg.slogdet(Sigma + eps * np.eye(K))
        if np.any(sign <= 0):
            raise np.linalg.LinAlgError("Non-positive determinant(s)")
        return ld
    except np.linalg.LinAlgError as e:
        fallback_counter["safe_logdet"] += 1
        msg = (
            f"[safe_logdet] Fallback #{fallback_counter['safe_logdet']}: "
            f"returning {K} * log({config.sanitize_fallback_value})"
        )
        if config.fail_on_fallback:
            raise RuntimeError(msg) from e
        warnings.warn(msg, RuntimeWarning)
        fallback_val = K * np.log(config.sanitize_fallback_value)
        return np.full(Sigma.shape[:-2], fallback_val)




fallback_counter = {"condition_check": 0}  # Optional global tracker

def condition_check_and_fallback(sigma, max_cond=1e6):
    """
    Checks condition number of matrix and falls back to scaled identity if ill-conditioned.

    Args:
        sigma:   (K, K) SPD matrix to validate
        max_cond: maximum allowed condition number before fallback

    Returns:
        Safe sigma matrix (original or fallback)
    """
    K = sigma.shape[-1]
    try:
        cond = np.linalg.cond(sigma)
        if not np.isfinite(cond) or cond > max_cond:
            raise np.linalg.LinAlgError
        return sigma
    except np.linalg.LinAlgError as e:
        fallback_counter["condition_check"] += 1
        msg = f"[condition_check] Fallback triggered: cond={cond:.2e} > {max_cond} → using {config.sanitize_fallback_value} · I"

        if getattr(config, "fail_on_fallback", False):
            raise RuntimeError(msg) from e
        else:
            warnings.warn(msg, RuntimeWarning)
            return np.eye(K) * config.sanitize_fallback_value

def report_fallback_summary():
    print("\n──── Fallback Summary ────")
    for key, count in fallback_counter.items():
        print(f"{key:<25} → {count} fallback(s)")
    print("──────────────────────────\n")


def is_bad_matrix(S):
    try:
        eigs = np.linalg.eigvalsh(S)
        return (not np.all(np.isfinite(eigs))) or np.min(eigs) <= 0
    except Exception:
        return True
    
    