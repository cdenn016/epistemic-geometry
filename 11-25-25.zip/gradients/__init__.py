# -*- coding: utf-8 -*-
"""
Created on Sat Nov  8 17:50:05 2025

@author: chris and christine
"""

