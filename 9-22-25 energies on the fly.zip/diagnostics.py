
from __future__ import annotations
from typing import Any, Sequence, Dict, Tuple
import numpy as np

from core.transport_cache import plaquette_product  

from core.numerical_utils import sanitize_sigma, kl_gaussian, push_gaussian, expected_nll_gaussian
from core.transport_cache import Omega as tc_Omega  
from runtime_context import ensure_theta, cfg_get
from core.get_generators import get_generators
from utils import mask_hw, fiber_view


def _reduce_sum(x, mask):  # x, mask both float32 with mask in {0,1}
    return float(np.sum(x * mask, dtype=np.float64))


def _reduce(field: np.ndarray, mask: np.ndarray, kind: str) -> float:
    f = np.asarray(field, np.float32)
    m = np.asarray(mask, bool)
    if f.shape != m.shape:
        raise ValueError(f"reduce mismatch: field {f.shape} vs mask {m.shape}")
    if not m.any():
        return 0.0
    if kind == "sum":
        return float(f[m].sum())
    if kind == "mean":
        return float(f[m].mean())
    raise ValueError(f"unknown reduce kind {kind}")



def compute_alignment_field(
    agents, i, *, which="q", ctx=None,
    eps=None, log_eps=None, kl_cap=None, neighbor_tau=None
):
    """
    Energy-faithful alignment field for agent i:
      out(y,x) = sum_{j in N(i)} KL( N_i || Ω_ij · N_j ) over overlapping neighbors,
    with NO averaging and NO caps. Pixelwise neighbors: a single overlapping pixel qualifies.
    """
    if ctx is None:
        raise ValueError("compute_alignment_field requires ctx for transport/cache")

    which_norm = str(which).strip().lower()
    if which_norm not in ("q", "p"):
        raise ValueError(f"which must be 'q' or 'p', got {which!r}")
    field_name = "phi" if which_norm == "q" else "phi_model"

    cfg = getattr(ctx, "step_cfg", None)
    if cfg is None:
        raise ValueError("ctx.step_cfg is missing")

    A = agents[i]

    # unified eps for SPD / KL
    eps_val = float(cfg.eps) if eps is None else float(eps)

    # thresholds
    support_tau  = float(cfg.support_tau)
    neighbor_tau = float(cfg.overlap_eps) if neighbor_tau is None else float(neighbor_tau)

    # support mask for agent i
    mask_i = mask_hw(getattr(A, "mask", None), tau=support_tau, mode = "bool2")
    if mask_i is None or not np.any(mask_i):
        base = getattr(A, "mask", None)
        base_arr = np.asarray(base, np.float32) if base is not None else np.zeros((1, 1), np.float32)
        return np.zeros_like(base_arr, np.float32)

    # choose fiber view (inline replacement for _fiber_views)
    _fv_i = fiber_view(A, field_name)
    mu_i_full, S_i_full = _fv_i["mu"], _fv_i["Sigma"]
    K =  _fv_i["K"]

    H, W = mask_i.shape
    kl_sum = np.zeros((H, W), np.float32)

    # neighbor list: if precomputed, use it; otherwise consider all j != i
    nb_list = getattr(A, "neighbors", None)
    if not nb_list:
        nb_list = [{"id": j} for j in range(len(agents)) if j != i]

    for nb in nb_list:
        j = int(nb["id"])
        if j == i:
            continue
        B = agents[j]

        mask_j = mask_hw(getattr(B, "mask", None), tau=support_tau, mode = "bool2")
        if mask_j is None or not np.any(mask_j):
            continue

        # pixelwise neighbor criterion: any overlap pixel qualifies
        overlap = (
            (np.asarray(A.mask, np.float32) > neighbor_tau)
            & (np.asarray(B.mask, np.float32) > neighbor_tau)
        )
        overlap &= mask_i & mask_j
        if not np.any(overlap):
            continue

        # neighbor fiber view (use B here!)
        _fv_j = fiber_view(B, field_name)
        
        mu_j_full, S_j_full = _fv_j["mu"], _fv_j["Sigma"]
        K_j = _fv_j["K"]

        if K_j != K:
            raise ValueError(f"fiber dim mismatch for which='{which_norm}': Ai K={K}, Aj K={K_j}")

        # slice to overlap (M pixels)
        mu_i = np.asarray(mu_i_full, np.float32)[overlap]                             # (M,K)
        S_i  = sanitize_sigma(np.asarray(S_i_full, np.float32)[overlap], eps=eps_val) # (M,K,K)
        mu_j = np.asarray(mu_j_full, np.float32)[overlap]
        S_j  = sanitize_sigma(np.asarray(S_j_full, np.float32)[overlap], eps=eps_val)

        # Ω from transport cache → slice to overlap
        Om_full = tc_Omega(ctx, A, B, which=which_norm)         # (H,W,K,K) or broadcastable
        Omega   = np.asarray(Om_full, np.float32)[overlap]      # (M,K,K)

        # exact push; SPD sanitize only
        mu_j_t, S_j_t = push_gaussian(
            mu=mu_j, Sigma=S_j, M=Omega,
            eps=eps_val)

        # per-pixel KL; clamp to [0, ∞)
        kl_vals = kl_gaussian(mu_i, S_i, mu_j_t, S_j_t, eps=eps_val)
        kl_vals = np.where(np.isfinite(kl_vals), kl_vals, 0.0).astype(np.float32)
        kl_vals = np.maximum(kl_vals, 0.0)

        # scatter-add SUM over neighbors (no averaging)
        r, c = np.nonzero(overlap)
        np.add.at(kl_sum, (r, c), kl_vals)

    # zero outside Ai support; return SUM over neighbors
    return kl_sum * mask_i.astype(np.float32, copy=False)



def _energy_alignment(ctx, agents):
    """
    Returns (align_q_sum, align_q_mean, align_p_sum, align_p_mean), already weight-scaled.
    Uses:
      - beta       (q-side coupling)
      - beta_model (p-side coupling)
    """
    if compute_alignment_field is None:
        return 0.0, 0.0, 0.0, 0.0
    
    cfg = getattr(ctx, "step_cfg", None)
    

    tau = cfg.support_tau
    wq  = cfg.beta
    wp  = cfg.beta_model

    if wq == 0.0 and wp == 0.0:
        return 0.0, 0.0, 0.0, 0.0

    sum_q = 0.0
    sum_p = 0.0
    S_tot = 0

    for i, A in enumerate(agents):
        mask = mask_hw(A.mask, tau=tau, mode = "bool2")
        if not mask.any():
            continue
        S_tot += int(mask.sum())

        if wq != 0.0:
            fq = np.asarray(compute_alignment_field(agents, i, which="q", ctx=ctx), np.float32)
            if fq.shape != mask.shape:
                raise ValueError(f"align(q) shape {fq.shape} != mask {mask.shape}")
            sum_q += float(fq[mask].sum())

        if wp != 0.0:
            fp = np.asarray(compute_alignment_field(agents, i, which="p", ctx=ctx), np.float32)
            if fp.shape != mask.shape:
                raise ValueError(f"align(p) shape {fp.shape} != mask {mask.shape}")
            sum_p += float(fp[mask].sum())

    if S_tot <= 0:
        return 0.0, 0.0, 0.0, 0.0

    return (
        wq * sum_q,
        wq * (sum_q / S_tot),
        wp * sum_p,
        wp * (sum_p / S_tot),
    )



def _energy_self_feedback(ctx: Any, agent: Any) -> Tuple[float, float, float, float]:
    """
    Returns (self_sum, self_mean, fb_sum, fb_mean), weight-scaled.
    Robust to Φ̃≈0 by adding a self-term covariance floor and norm-guarding the mean push.
    """
    
    from core.transport_cache import Phi as tc_Phi
    cfg = getattr(ctx, "step_cfg", None)

    eps    = cfg.eps
    tau    = cfg.support_tau
    w_self = cfg.alpha
    w_fb   = cfg.feedback_weight

   
    mask = mask_hw(agent.mask, tau=tau, mode = "bool2")
    if not mask.any():
        return 0.0, 0.0, 0.0, 0.0

    mu_q = np.asarray(agent.mu_q_field,    np.float32)   # (H,W,Kq)
    S_q  = np.asarray(agent.sigma_q_field, np.float32)   # (H,W,Kq,Kq)
    mu_p = np.asarray(agent.mu_p_field,    np.float32)   # (H,W,Kp)
    S_p  = np.asarray(agent.sigma_p_field, np.float32)   # (H,W,Kp,Kp)
    H, W, Kq = mu_q.shape
    _, _, Kp = mu_p.shape
    if S_q.shape != (H, W, Kq, Kq) or S_p.shape != (H, W, Kp, Kp):
        raise ValueError("Sigma shapes do not match mu shapes")

    # Morphisms (global or per-pixel)
    Phi_q_to_p = tc_Phi(ctx, agent, kind="q_to_p")   # (Kp,Kq) or (H,W,Kp,Kq)
    Phi_p_to_q = tc_Phi(ctx, agent, kind="p_to_q")   # (Kq,Kp) or (H,W,Kq,Kp)

    # Active pixels (gather)
    rrcc = np.argwhere(mask)
    r, c = rrcc[:, 0], rrcc[:, 1]
    mu_q_m = mu_q[r, c]                 # (M,Kq)
    S_q_m  = S_q[r, c]                  # (M,Kq,Kq)  (let push_gaussian sanitize)
    mu_p_m = mu_p[r, c]
    S_p_m  = S_p[r, c]
    M = mu_q_m.shape[0]
    
    # Morphisms (global or per-pixel → slice if field; otherwise broadcast in push)
    M_p_to_q = Phi_p_to_q if Phi_p_to_q.ndim == 2 else Phi_p_to_q[r, c]
    M_q_to_p = Phi_q_to_p if Phi_q_to_p.ndim == 2 else Phi_q_to_p[r, c]
    
    # SELF: KL(q || Φ̃·p)
    mu_pt, S_pt = push_gaussian(mu_p_m, S_p_m, M_p_to_q, eps=eps)
    
    # Norm guard on mean push
    Fn = (np.linalg.norm(M_p_to_q, axis=(-2, -1)) if M_p_to_q.ndim == 3
          else np.full((M,), np.linalg.norm(M_p_to_q), dtype=np.float32))
    tiny = (Fn < 1e-3)  # or scale-aware threshold as suggested
    if tiny.any():
        mu_pt[tiny] = 0.0
    
    # Covariance floor using var(Σ_q)
    var_q  = np.trace(S_q_m, axis1=-2, axis2=-1) / float(Kq)  # (M,)
    sigma2 = (var_q + 1e-10).astype(np.float32)
    Iq     = np.eye(Kq, dtype=np.float32)
    S_pt   = S_pt + sigma2[:, None, None] * Iq
    S_pt   = sanitize_sigma(S_pt, eps)  # keep final SPD
    
    kl_self   = kl_gaussian(mu_q_m, S_q_m, mu_pt, S_pt, eps=eps)
    self_sum  = w_self * float(kl_self.sum())
    self_mean = w_self * (float(kl_self.mean()) if kl_self.size else 0.0)
    
    # FEEDBACK: KL(p || Φ·q)
    if w_fb > 0.0:
        mu_qt, S_qt = push_gaussian(mu_q_m, S_q_m, M_q_to_p, eps=eps)
        kl_fb       = kl_gaussian(mu_p_m, S_p_m, mu_qt, S_qt, eps=eps)
        fb_sum      = w_fb * float(kl_fb.sum())
        fb_mean     = w_fb * (float(kl_fb.mean()) if kl_fb.size else 0.0)
    else:
        fb_sum, fb_mean = 0.0, 0.0
    return self_sum, self_mean, fb_sum, fb_mean





def _energy_mass(ctx: Any, agent: Any) -> Tuple[float, float, float, float]:
    """Returns (mass_q_sum, mass_q_mean, mass_p_sum, mass_p_mean)."""
    
    cfg = getattr(ctx, "step_cfg", None)

    tau = cfg.support_tau
    wq  = cfg.belief_mass
    wp  = cfg.model_mass
    
    mask = mask_hw(agent.mask, tau=tau, mode = "bool2")
    if not mask.any():
        return 0.0, 0.0, 0.0, 0.0

    phi_q = np.asarray(agent.phi, np.float32)       # (H,W,3)
    phi_p = np.asarray(agent.phi_model, np.float32) # (H,W,3)
    if phi_q.ndim != 3 or phi_q.shape[-1] != 3 or phi_p.ndim != 3 or phi_p.shape[-1] != 3:
        raise ValueError("phi_field/phi_model_field must be (H,W,3)")

    m_q = (phi_q ** 2).sum(axis=-1)  # ||Ï†||Â²
    m_p = (phi_p ** 2).sum(axis=-1)
    return (
        wq * _reduce(m_q, mask, "sum"),
        wq * _reduce(m_q, mask, "mean"),
        wp * _reduce(m_p, mask, "sum"),
        wp * _reduce(m_p, mask, "mean"),
    )



def _energy_curvature(ctx: Any, agent: Any) -> Tuple[float, float, float, float]:
    """
    Returns (curv_q_sum, curv_q_mean, curv_p_sum, curv_p_mean).

    Backend: lattice plaquette via transport_cache.plaquette_product(...)
      P ∈ ℝ^{H×W×K×K}, site magnitude = ||P - I||_F^2
    """
    import numpy as np
    cfg = getattr(ctx, "step_cfg", None)

    tau = cfg.support_tau
    wq  = cfg.curvature_weight
    wp  = cfg.model_curvature_weight

    mask = mask_hw(agent.mask, tau=tau, mode = "bool2")
    if not mask.any():
        return 0.0, 0.0, 0.0, 0.0

    
    # ---- belief side (q-fiber) ----
    Gq = get_generators(agent, "q")
   
    Pq = plaquette_product(ctx, agent.phi, Gq, split_edge=True)
        
    if Pq.ndim != 4 or Pq.shape[-1] != Pq.shape[-2]:
        raise ValueError(f"Invalid plaquette (q) shape {Pq.shape}")
        
    Kq = int(Pq.shape[-1])
    Iq = np.eye(Kq, dtype=np.float32)
    Dq = Pq - Iq
    fq = np.einsum("...ij,...ij->...", Dq, Dq, optimize=True)
   


    # ---- model side (p-fiber) ----
    Gp = get_generators(agent, "p")
       
    Pp = plaquette_product(ctx, agent.phi_model, Gp, split_edge=True)

    if Pp.ndim != 4 or Pp.shape[-1] != Pp.shape[-2]:
        raise ValueError(f"Invalid plaquette (p) shape {Pp.shape}")
    
    Kp = int(Pp.shape[-1])
    Ip = np.eye(Kp, dtype=np.float32)
    Dp = Pp - Ip
    fp = np.einsum("...ij,...ij->...", Dp, Dp, optimize=True)

    return (
        wq * _reduce(fq, mask, "sum"),
        wq * _reduce(fq, mask, "mean"),
        wp * _reduce(fp, mask, "sum"),
        wp * _reduce(fp, mask, "mean"),
    )


# --- diagnostics.py ---

def total_energy(ctx: Any,
                 agents: Any,
                 *,
                 return_breakdown: bool = False,
                 precomputed_metrics: Dict[str, float] | None = None
                 ) -> float | Tuple[float, Dict[str, float]]:
    """
    Variational energy minimized by the suite.

    If precomputed_metrics is provided, it should be the dict returned by
    compute_global_metrics(ctx, agents); we will skip recomputing it.
    """
    M = precomputed_metrics if precomputed_metrics is not None else compute_global_metrics(ctx, agents)
    E = float(M.get("E_total", 0.0))

    if not return_breakdown:
        return E

    breakdown = {
        "self":       float(M.get("self_sum",     0.0)),
        "feedback":   float(M.get("feedback_sum", 0.0)),
        "align_q":    float(M.get("align_q_sum",  0.0)),
        "align_p":    float(M.get("align_p_sum",  0.0)),
        "mass_q":     float(M.get("mass_q_sum",   0.0)),
        "mass_p":     float(M.get("mass_p_sum",   0.0)),
        "curv_q":     float(M.get("curv_q_sum",   0.0)),
        "curv_p":     float(M.get("curv_p_sum",   0.0)),
        "mean_total": float(M.get("mean_total",   0.0)),
    }
    return E, breakdown





def print_action_breakdown(ctx, action_dict, *, stream=None):
    step = int(getattr(ctx, "global_step", -1))
    lines = []
    lines.append(f"[Action @ step {step}]")
    lines.append(f"  Action_total = {action_dict.get('Action_total', 0.0):.6e}")
    lines.append("  ---------------------------------------")
    lines.append(f"  Geom_total   = {action_dict.get('Geom_total', 0.0):.6e}")
    lines.append(f"  VFE_acc      = {action_dict.get('VFE_acc', 0.0):.6e}")
    lines.append(f"  A_curv       = {action_dict.get('A_curv', 0.0):.6e}  ")
    lines.append(f"  A_cov        = {action_dict.get('A_cov', 0.0):.6e}")
    lines.append(f"  ModelPrior   = {action_dict.get('ModelPrior', 0.0):.6e}")
    print("\n".join(lines), flush=True)


def print_energy_breakdown(ctx, metrics_global, *, stream=None) -> None:
    step = int(getattr(ctx, "global_step", -1))
    cfg = getattr(ctx, "step_cfg", None)


    # SAFE reads with defaults (don’t explode if a key is absent)
    w_self = float(cfg.alpha)
    w_fb   = float(cfg.feedback_weight)
    w_mq   = float(cfg.belief_mass)
    w_mp   = float(cfg.model_mass)
    w_cq   = float(cfg.curvature_weight)
    w_cp   = float(cfg.model_curvature_weight)
    w_aq   = float(cfg.beta)
    w_ap   = float(cfg.beta_model)

    lines = []
    lines.append(f"[Energy Totals @ step {step}]")
    lines.append(f"  E_total = {metrics_global.get('E_total', 0.0):.6e}  |  mean_total = {metrics_global.get('mean_total', 0.0):.6e}")
    lines.append("  ----------------------------------------------------")
    lines.append("  term         weighted_sum            mean_per_px        weight")
    lines.append(f"  self         {metrics_global.get('self_sum', 0.0):>14.6e}    {metrics_global.get('self_mean', 0.0):>14.6e}    {w_self:g}")
    lines.append(f"  align_q      {metrics_global.get('align_q_sum', 0.0):>14.6e}    {metrics_global.get('align_q_mean', 0.0):>14.6e}    {w_aq:g}")
    lines.append(f"  align_p      {metrics_global.get('align_p_sum', 0.0):>14.6e}    {metrics_global.get('align_p_mean', 0.0):>14.6e}    {w_ap:g}")
    lines.append(f"  feedback     {metrics_global.get('feedback_sum', 0.0):>14.6e}    {metrics_global.get('feedback_mean', 0.0):>14.6e}    {w_fb:g}")
    lines.append(f"  mass_q       {metrics_global.get('mass_q_sum', 0.0):>14.6e}    {metrics_global.get('mass_q_mean', 0.0):>14.6e}    {w_mq:g}")
    lines.append(f"  mass_p       {metrics_global.get('mass_p_sum', 0.0):>14.6e}    {metrics_global.get('mass_p_mean', 0.0):>14.6e}    {w_mp:g}")
    # ——— curvature rows restored ———
    lines.append(f"  curv_q       {metrics_global.get('curv_q_sum', 0.0):>14.6e}    {metrics_global.get('curv_q_mean', 0.0):>14.6e}    {w_cq:g}")
    lines.append(f"  curv_p       {metrics_global.get('curv_p_sum', 0.0):>14.6e}    {metrics_global.get('curv_p_mean', 0.0):>14.6e}    {w_cp:g}")

    print("\n".join(lines), flush=True)


def compute_agent_metrics(ctx: Any, agent: Any) -> Dict[str, float]:
    """
    Returns per-agent energy components. Prefers per-agent accumulators
    (self_sum[aid], feedback_sum[aid]) if they were filled during the μ/Σ
    gradient pass; otherwise falls back to computing them here.

    Mass and curvature terms are always computed here (unchanged).
    """
    # fast exit if agent has no support
    cfg = getattr(ctx, "step_cfg", None)
    tau = float(getattr(cfg, "support_tau", 1e-6)) if cfg is not None else 1e-6
    m = mask_hw(getattr(agent, "mask", None), tau=tau, mode="bool2")
    if (m is None) or (not np.any(m)):
        return {
            "self_sum": 0.0, "self_mean": 0.0,
            "feedback_sum": 0.0, "feedback_mean": 0.0,
            "mass_q_sum": 0.0, "mass_q_mean": 0.0,
            "mass_p_sum": 0.0, "mass_p_mean": 0.0,
            "curv_q_sum": 0.0, "curv_q_mean": 0.0,
            "curv_p_sum": 0.0, "curv_p_mean": 0.0,
        }

    S = int(np.count_nonzero(m)) or 1  # pixel count for means

    # ---- self / feedback: prefer per-agent accumulators if present ----
    aid = getattr(agent, "id", None)
    self_sum = None
    fb_sum   = None
    if aid is not None:
        # energy_acc_get supports a default, so we can detect absence
        self_sum = energy_acc_get(ctx, f"self_sum[{aid}]", None)
        fb_sum   = energy_acc_get(ctx, f"feedback_sum[{aid}]", None)

    if (self_sum is not None) and (fb_sum is not None):
        self_sum  = float(self_sum)
        fb_sum    = float(fb_sum)
        self_mean = self_sum / S
        fb_mean   = fb_sum / S
    else:
        print("FALLBACK IN SELF-ENERGY COMP[UTATION\n\n\n\n\n\n")
        self_sum, self_mean, fb_sum, fb_mean = _energy_self_feedback(ctx, agent)

    # ---- mass / curvature (unchanged) ----
    mass_q_sum, mass_q_mean, mass_p_sum, mass_p_mean = _energy_mass(ctx, agent)
    curv_q_sum, curv_q_mean, curv_p_sum, curv_p_mean = _energy_curvature(ctx, agent)

    return {
        "self_sum": self_sum, "self_mean": self_mean,
        "feedback_sum": fb_sum, "feedback_mean": fb_mean,
        "mass_q_sum": mass_q_sum, "mass_q_mean": mass_q_mean,
        "mass_p_sum": mass_p_sum, "mass_p_mean": mass_p_mean,
        "curv_q_sum": curv_q_sum, "curv_q_mean": curv_q_mean,
        "curv_p_sum": curv_p_sum, "curv_p_mean": curv_p_mean,
    }



# diagnostics.py

from joblib import Parallel, delayed
from threadpoolctl import threadpool_limits

from runtime_context import energy_acc_get



def compute_global_metrics(ctx: Any, agents: Sequence[Any]) -> Dict[str, float]:
    cfg   = getattr(ctx, "step_cfg", None)
    tau   = cfg.support_tau
    n_jobs = int(getattr(cfg, "metrics_n_jobs", 1))  # <= add this knob in your cfg

    # map: compute each agent's metrics (self/mass/curv) and pixel count S
    def _one(a):
        m = mask_hw(a.mask, tau=tau, mode="bool2")
        S = int(np.count_nonzero(m))
        if S <= 0:
            return None
        d = compute_agent_metrics(ctx, a)  # unchanged function
        return d, S

    with threadpool_limits(1):
        outs = Parallel(n_jobs=max(1, n_jobs), backend="threading", batch_size="auto")(
            delayed(_one)(a) for a in agents
        )

    totals = {"self_sum":0.0,"feedback_sum":0.0,"mass_q_sum":0.0,"mass_p_sum":0.0,
              "curv_q_sum":0.0,"curv_p_sum":0.0,"_S":0}
    
    
    for res in outs:
        if res is None:
            continue
        d, S = res
        for k in ("self_sum","feedback_sum","mass_q_sum","mass_p_sum","curv_q_sum","curv_p_sum"):
            totals[k] += float(d[k])
        totals["_S"] += int(S)

    
    aq = energy_acc_get(ctx, "align_q_sum", None)
    ap = energy_acc_get(ctx, "align_p_sum", None)
    
    
    if (aq is not None) and (ap is not None):
        
        align_q_sum  = float(aq)
        align_p_sum  = float(ap)
        
        S_tot = sum(int(np.count_nonzero(mask_hw(a.mask, tau=ctx.step_cfg.support_tau, mode="bool2")))
                    for a in agents) or 1
        align_q_mean = align_q_sum / S_tot
        align_p_mean = align_p_sum / S_tot
        
    else:
        # fallback to the old (slow) path
        align_q_sum, align_q_mean, align_p_sum, align_p_mean = _energy_alignment(ctx, agents)
    


    S_tot = max(totals["_S"], 1)
    out   = dict(totals)

    # base means
    out["self_mean"]     = out["self_sum"]     / S_tot
    out["feedback_mean"] = out["feedback_sum"] / S_tot
    out["mass_q_mean"]   = out["mass_q_sum"]   / S_tot
    out["mass_p_mean"]   = out["mass_p_sum"]   / S_tot
    out["curv_q_mean"]   = out["curv_q_sum"]   / S_tot
    out["curv_p_mean"]   = out["curv_p_sum"]   / S_tot

    # alignment terms
    out["align_q_sum"]  = align_q_sum
    out["align_q_mean"] = align_q_mean
    out["align_p_sum"]  = align_p_sum
    out["align_p_mean"] = align_p_mean

    # totals including alignment
    out["E_total"] = float(
        out["self_sum"] + out["feedback_sum"] +
        out["mass_q_sum"] + out["mass_p_sum"] +
        out["curv_q_sum"] + out["curv_p_sum"] +
        out["align_q_sum"] + out["align_p_sum"]
    )
    out["mean_total"] = float(
        out["self_mean"] + out["feedback_mean"] +
        out["mass_q_mean"] + out["mass_p_mean"] +
        out["curv_q_mean"] + out["curv_p_mean"] +
        out["align_q_mean"] + out["align_p_mean"]
    )
    return out




def compute_total_action(ctx, agents, precomputed_metrics=None):
    cfg = getattr(ctx, "step_cfg", None)

    # 1) Geometric piece
    M_geom = precomputed_metrics if (precomputed_metrics is not None) \
             else compute_global_metrics(ctx, agents)
    A_geom = float(M_geom.get("E_total", 0.0))

    # 2) VFE accuracy (q-fiber)
    w_vfe   = float(cfg.vfe_weight)
    vfe_raw = 0.0
    num_y   = 0

    if w_vfe != 0.0 and expected_nll_gaussian is not None:
        y_agents = [a for a in agents if getattr(a, "observation_field", None) is not None]
        if y_agents:
            a0 = y_agents[0]
            D  = int(np.asarray(a0.observation_field).shape[-1])
            Kq = int(np.asarray(a0.mu_q_field).shape[-1])
            th = ensure_theta(ctx, D_obs=D, K_latent=Kq)

            def _nll_one(a):
                y  = np.asarray(a.observation_field, np.float32)
                mu = np.asarray(a.mu_q_field,       np.float32)
                S  = np.asarray(a.sigma_q_field,    np.float32)
                W  = np.asarray(th.W,               np.float32)
                b  = np.asarray(th.b,               np.float32)
                s2 = float(th.sigma2)
                m  = np.asarray(getattr(a, "mask", 1.0), np.float32)
                total_nll, _ = expected_nll_gaussian(y=y, mu=mu, Sigma=S, W=W, b=b, sigma2=s2, mask=m)
                return float(total_nll)

            n_jobs = int(getattr(cfg, "vfe_n_jobs", 1))
            with threadpool_limits(1):
                vals = Parallel(n_jobs=max(1, n_jobs), backend="threading", batch_size="auto")(
                    delayed(_nll_one)(a) for a in y_agents
                )
            vfe_raw = float(np.sum(vals))
            num_y   = len(vals)

    A_vfe = float(w_vfe * vfe_raw)

    # 3) Optional θ prior (unchanged)
    lam_th = float(cfg_get(ctx, "lambda_theta", 1))
    theta_prior_scale_W      = float(cfg_get(ctx, "theta_prior_scale_W", 1.0))
    theta_prior_scale_b      = float(cfg_get(ctx, "theta_prior_scale_b", 1.0))
    theta_prior_scale_logsig = float(cfg_get(ctx, "theta_prior_scale_logsigma", 1.0))

    model_prior_raw = 0.0
    if lam_th != 0.0 and (num_y > 0):
        W = np.asarray(th.W, np.float32)
        b = np.asarray(th.b, np.float32)
        s2 = float(th.sigma2)
        logs = float(np.log(max(s2, 1e-12)))
        model_prior_raw = (
            0.5 * theta_prior_scale_W * float(np.sum(W * W)) +
            0.5 * theta_prior_scale_b * float(np.sum(b * b)) +
            0.5 * theta_prior_scale_logsig * (logs * logs)
        )
    A_th = float(lam_th * model_prior_raw)

    # 4) A terms (unchanged)
    fields = getattr(ctx, "fields", {}) or {}
    A_cov = float(fields.get("A_cov_energy_last", 0.0))
    A_curv = float(fields.get("A_curv_energy", 0.0))
    A_tot = float(A_geom + A_vfe + A_curv + A_cov + A_th)

    if A_vfe == 0.0:
        reason = ("no VFE fn" if expected_nll_gaussian is None
                  else ("no agents with y" if num_y == 0 else "vfe_weight=0 or nll=0"))
        print(f"[VFE] {reason}  (num_y={num_y}, w={w_vfe}, raw={vfe_raw:.3e})")

    return {
        "Action_total": A_tot,
        "Geom_total":   A_geom,
        "VFE_acc":      A_vfe,
        "A_curv":       A_curv,
        "A_cov":        A_cov,
        "ModelPrior":   A_th,
        "self_sum":     float(M_geom.get("self_sum", 0.0)),
        "feedback_sum": float(M_geom.get("feedback_sum", 0.0)),
        "align_q_sum":  float(M_geom.get("align_q_sum", 0.0)),
        "align_p_sum":  float(M_geom.get("align_p_sum", 0.0)),
        "mass_q_sum":   float(M_geom.get("mass_q_sum", 0.0)),
        "mass_p_sum":   float(M_geom.get("mass_p_sum", 0.0)),
        "curv_q_sum":   float(M_geom.get("curv_q_sum", 0.0)),
        "curv_p_sum":   float(M_geom.get("curv_p_sum", 0.0)),
    }




