# -*- coding: utf-8 -*-
"""
Created on Wed Sep 10 12:40:31 2025

@author: chris and christine
"""

import numpy as np
from core.transport_cache import ensure_global_A
from runtime_context import cfg_get



def _fwd_dx(X):  # forward diff along x (W/cols), periodic BC
    return np.roll(X, -1, axis=1) - X

def _fwd_dy(X):  # forward diff along y (H/rows), periodic BC
    return np.roll(X, -1, axis=0) - X

def _bwd_dx(H):  # adjoint of _fwd_dx
    return H - np.roll(H, 1, axis=1)

def _bwd_dy(H):  # adjoint of _fwd_dy
    return H - np.roll(H, 1, axis=0)

def _cross(a, b):
    # a,b: (..., 3)
    return np.stack([
        a[...,1]*b[...,2] - a[...,2]*b[...,1],
        a[...,2]*b[...,0] - a[...,0]*b[...,2],
        a[...,0]*b[...,1] - a[...,1]*b[...,0]
    ], axis=-1)



def step_global_A(ctx, agents):
    """
    Apply one gradient step on the global A using:
      - curvature energy (weight: lambda_A_curv), and
      - optional covariant A–phi coupling grad accumulated in ctx.fields["A_grad_accum"].

    Returns the total A-related energy = A_curv + A_cov (if any).
    """
    import numpy as np
    
    init_scale=float(cfg_get(ctx,"A_init_scale", 0.0))
    # infer grid from any agent's latent field
    a0 = agents[0]
    H, W = int(np.asarray(a0.mu_q_field).shape[0]), int(np.asarray(a0.mu_q_field).shape[1])
    
    A = ensure_global_A(ctx, (H, W), init_scale=init_scale)

    # --- curvature term ---
    lam_A = float(cfg_get(ctx,"lambda_A_curv", 0.0))
    
    if lam_A > 0.0:
        
        E_curv, F, g_curv = curvature_energy_and_grad(A, weight=lam_A)
        # store raw 1/2||F||^2 and the weight actually used
        raw_curv = 0.5 * float(np.sum(F * F))  # unweighted
        #print(f"[step global a] curvature energy = {raw_curv}!!!\n\n\n\n\n")
        if not hasattr(ctx, "fields"):
            ctx.fields = {}
        ctx.fields["A_curv_raw"]    = raw_curv
        ctx.fields["A_curv_energy"] = float(E_curv)  # already weighted by lam_A
        ctx.fields["A_curv_weight"] = float(lam_A)
    else:
        print("[step global a] curvature energy and grads FAIL!!!\n\n\n\n\n")
        E_curv = 0.0
        F      = np.zeros((H, W, 3), dtype=np.float32)
        g_curv = np.zeros_like(A, dtype=np.float32)

    # --- coupling grad (accumulated in the child pass) ---
    E_cov = 0.0
    g_extra = None
    
    if hasattr(ctx, "fields"):
        # Pop so we don't reuse across steps
        g_extra = ctx.fields.pop("A_grad_accum", None)
        E_cov   = float(ctx.fields.pop("A_cov_energy", 0.0))

    if g_extra is None:
        g_total = g_curv
    else:
        g_total = g_curv + np.asarray(g_extra, np.float32)

    # --- step (clip + lr) ---
    lr   = float(cfg_get(ctx,"A_lr", 1e-2))
    gcap = float(cfg_get(ctx,"A_grad_clip", -1))
    
    n = float(np.linalg.norm(g_total.reshape(-1))) if g_total.size else 0.0
    if n > 0.0 and lr > 0.0:
        s = 1.0 if gcap <= 0.0 else min(1.0, gcap / (n + 1e-9))
        A[...] = A - (lr * s) * g_total

    # --- diagnostics ---
    if not hasattr(ctx, "fields"):
        ctx.fields = {}
    ctx.fields["A_curv_energy"]     = float(E_curv)
    ctx.fields["A_cov_energy_last"] = float(E_cov)
    ctx.fields["A_grad_norm"]       = float(n)
    ctx.fields["A_curv_normF"]      = float(np.sqrt(np.mean(F * F))) if lam_A > 0.0 else 0.0

    return float(E_curv + E_cov)

def curvature_energy_and_grad(A, weight=1.0):
    """
    Non-Abelian curvature on a 2D grid:
      F = dx(Ay) - dy(Ax) + Ax × Ay
      E = 1/2 * weight * sum ||F||^2

    Returns:
      E (scalar), F (H,W,3), grad (H,W,2,3) w.r.t. A
    """
    A = np.asarray(A, np.float32)
    assert A.ndim == 4 and A.shape[-2:] == (2,3), f"A must be (H,W,2,3), got {A.shape}"
    Ax = A[..., 0, :]  # (H,W,3)
    Ay = A[..., 1, :]  # (H,W,3)

    Fx = _fwd_dx(Ay)   # ∂x Ay
    Fy = _fwd_dy(Ax)   # ∂y Ax
    F  = Fx - Fy + _cross(Ax, Ay)  # (H,W,3)

    E  = 0.5 * float(weight) * float(np.sum(F*F))
    G  = (weight * F).astype(np.float32)  # dE/dF

    # dE/dAx = ( + backdiff_y(G) ) + Ay × G
    grad_Ax = _bwd_dy(G) + _cross(Ay, G)

    # dE/dAy = ( - backdiff_x(G) ) + G × Ax
    grad_Ay = -_bwd_dx(G) + _cross(G, Ax)

    grad = np.zeros_like(A, dtype=np.float32)
    grad[..., 0, :] = grad_Ax
    grad[..., 1, :] = grad_Ay
    return E, F, grad

def covariant_frame_energy_and_grads(phi, A, *, weight=1.0, mask=None):
    """
    E_cov = (weight/2) * sum( ||Dx φ||^2 + ||Dy φ||^2 ),
      Dx φ = ∂x φ - A_x × φ,   Dy φ = ∂y φ - A_y × φ.
    Returns: (E_cov: float, g_phi: (H,W,3), g_A: (H,W,2,3))
    """
    phi = np.asarray(phi, np.float32)        # (H,W,3)
    A   = np.asarray(A,   np.float32)        # (H,W,2,3)
    Ax, Ay = A[..., 0, :], A[..., 1, :]      # (H,W,3), (H,W,3)

    Dx_phi = _fwd_dx(phi) - _cross(Ax, phi)
    Dy_phi = _fwd_dy(phi) - _cross(Ay, phi)

    if mask is not None:
        m  = np.asarray(mask, np.float32)
        m3 = m[..., None]
        Dx_phi *= m3
        Dy_phi *= m3

    E = 0.5 * float(weight) * (np.sum(Dx_phi*Dx_phi) + np.sum(Dy_phi*Dy_phi))

    Gx = float(weight) * Dx_phi
    Gy = float(weight) * Dy_phi

    g_phi = -_bwd_dx(Gx) - _bwd_dy(Gy) + _cross(Ax, Gx) + _cross(Ay, Gy)

    g_Ax  = -_cross(phi, Gx)
    g_Ay  = -_cross(phi, Gy)

    g_A = np.zeros_like(A, dtype=np.float32)
    g_A[..., 0, :] = g_Ax
    g_A[..., 1, :] = g_Ay

    return float(E), g_phi.astype(np.float32), g_A






