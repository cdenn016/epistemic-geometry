# -*- coding: utf-8 -*-
"""
Created on Wed Aug  6 12:27:32 2025

@author: chris and christine
"""
 
import time
import numpy as np
import core.config as config
from core.numerical_utils import sanitize_sigma, safe_inv, push_gaussian
from core.transport_cache import Omega
from utils import iter_overlapping_neighbors, _check_finite, _aid
from runtime_context import ensure_theta, cfg_get
from core.transport_cache import Phi_cached
# -------------------------------------------------------------------------
#                          PUBLIC ENTRYPOINTS
# -------------------------------------------------------------------------



def accumulate_mu_sigma_gradient(ctx, agent_i, agents, mode):
    """
    Accumulate natural gradient ∇μ and ∇Σ for belief or model using cache-owned Φ, Φ̃, Ω.
    Adds fine-grained timing (printed only if cfg debug_mu_sigma_timing=True).
    """
    if ctx is None:
        raise RuntimeError("accumulate_mu_sigma_gradient: ctx required.")

    # -------- profiling setup (cheap when disabled) --------
    prof = bool(cfg_get(ctx, "debug_mu_sigma_timing", False))
    t = {}                      # sub-timings
    def _tic():  return time.perf_counter()
    def _tock(s, key): t[key] = time.perf_counter() - s

    PRINT_SIGN  = False

    eps         = float(cfg_get(ctx, "eps", 1e-6))
    tau         = float(cfg_get(ctx, "support_tau", 1e-6))
    alpha       = float(cfg_get(ctx, "alpha", 0))
    lambd       = float(cfg_get(ctx, "feedback_weight", 0))

    field = "phi" if mode == "belief" else "phi_model"
    if field == "phi":
        beta_like = float(cfg_get(ctx, "beta", 0))
    else:
        beta_like = float(cfg_get(ctx, "beta_model", 0))

    which = "q" if field == "phi" else "p"
    mu_key    = "mu_q_field"    if which == "q" else "mu_p_field"
    sigma_key = "sigma_q_field" if which == "q" else "sigma_p_field"

    # (unchanged) direct field access if you need them later
    mu_q, S_q = agent_i.mu_q_field, agent_i.sigma_q_field
    mu_p, S_p = agent_i.mu_p_field, agent_i.sigma_p_field

    # -------- pushes (Φ, Φ̃) --------
    t0 = _tic()
    Phi_mat       = Phi_cached(ctx, agent_i, kind="q_to_p")
    Phi_tilde_mat = Phi_cached(ctx, agent_i, kind="p_to_q")
    _tock(t0, "Phi_fetch")

    t0 = _tic()
    mu_q_push, S_q_push, inv_q_push = push_gaussian(
        mu_q, S_q, Phi_mat, eps=eps, return_inv=True,
        Sigma_inv=getattr(agent_i, "sigma_q_inv", None),   # precomputed in refresh_agents
        assume_orthogonal=False                             # Φ is generally not orthogonal
    )

    mu_p_push, S_p_push, inv_p_push = push_gaussian(
        mu_p, S_p, Phi_tilde_mat, eps=eps, return_inv=True,
        Sigma_inv=getattr(agent_i, "sigma_p_inv", None),   # precomputed in refresh_agents
        assume_orthogonal=False                             # Φ is generally not orthogonal
    )

    _tock(t0, "push_gaussians")

    # -------- self/feedback energy accumulation (cheap; reuse pushes) --------
    t0 = _tic()
    accumulate_self_feedback_energies(
        ctx, agent_i,
        mu_q=mu_q, S_q=S_q,
        mu_p=mu_p, S_p=S_p,
        mu_q_push=mu_q_push, S_q_push=S_q_push,
        mu_p_push=mu_p_push, S_p_push=S_p_push,
    )
    _tock(t0, "accumulate self/feedback energies")
    # -------- self + feedback (Euclid-gradients) --------
    t0 = _tic()
    g_self_mu, g_self_S, g_fb_mu, g_fb_S = _self_and_feedback_grads(
        mode,
        mu_q, S_q, mu_p, S_p,
        mu_q_push, S_q_push, inv_q_push,
        mu_p_push, S_p_push, inv_p_push,
        Phi_mat, Phi_tilde_mat, eps,
        sigma_q_inv=getattr(agent_i, "sigma_q_inv", None),
        sigma_p_inv=getattr(agent_i, "sigma_p_inv", None),
        mask=getattr(agent_i, "mask", None),
    )

    _tock(t0, "self_feedback")

    mu_field = getattr(agent_i, mu_key)
    S_field  = getattr(agent_i, sigma_key)

    dmu_align = np.zeros_like(mu_field, dtype=np.float32)
    dS_align  = np.zeros_like(S_field,  dtype=np.float32)

    # -------- alignment (pairwise) --------
    n_pairs = 0
    align_px = 0  # total active overlap pixels across pairs
    if beta_like != 0.0:
        
        t0_align = _tic()
        for j_idx, agent_j, overlap in iter_overlapping_neighbors(
            agent_i, agents, support_eps=tau, symmetric=True
        ):
            n_pairs += 1
            align_px += int(np.count_nonzero(overlap))
            t1 = _tic()
            add_mu_i, add_S_i = _accum_align_for_pair(
                ctx, agent_i, agent_j,
                fiber=which,
                mu_key=mu_key, sigma_key=sigma_key,
                overlap_mask=overlap, beta_like=beta_like,
                eps=eps
            )
            if prof:
                # accumulate per-pair time (sum)
                t["align_pair_sum"] = t.get("align_pair_sum", 0.0) + (time.perf_counter() - t1)

            # scatter-add on the overlap
            dmu_align[overlap] += add_mu_i[overlap]
            dS_align[overlap]  += add_S_i[overlap]
        _tock(t0_align, "align_total")
        if n_pairs > 0 and "align_pair_sum" in t:
            t["align_pair_avg"] = t["align_pair_sum"] / float(n_pairs)

    # -------- VFE block (belief only) --------
    g_vfe_mu = None
    g_vfe_S  = None

    if mode == "belief" and bool(cfg_get(ctx, "enable_vfe_mu_sigma", True)):
        want_acc   = bool(cfg_get(ctx, "enable_vfe", True))
        want_prior = bool(cfg_get(ctx, "vfe_use_prior", float(alpha) == 0.0))

        if want_acc or want_prior:
            y = getattr(agent_i, "observation_field", None)
            K_latent = int(mu_q.shape[-1])
            D_obs    = int(np.asarray(y).shape[-1]) if y is not None else int(cfg_get(ctx, "D_obs_default", K_latent))
            theta    = ensure_theta(ctx, D_obs=D_obs, K_latent=K_latent)

            vfe_prior_source = str(cfg_get(ctx, "vfe_prior_source", "push")).lower()
            if vfe_prior_source == "push" and want_prior and float(alpha) > 0.0:
                if bool(cfg_get(ctx, "warn_vfe_push_doublecount", True)):
                    print("[warn] vfe_prior_source='push' + alpha>0 -> potential double counting. Consider turning off one of them.", flush=True)

            t0 = _tic()
            try:
                g_vfe_mu, g_vfe_S = vfe_mu_sigma_grads(
                    y=(None if not want_acc else np.asarray(y, np.float32)),
                    mu=np.asarray(mu_q, np.float32),
                    Sigma=np.asarray(S_q, np.float32),
                    W=np.asarray(theta.W, np.float32),
                    b=np.asarray(theta.b, np.float32),
                    sigma2=float(theta.sigma2),
                    mask=np.asarray(agent_i.mask, np.float32),
                    ctx=ctx,
                    vfe_prior_source=(None if not want_prior else vfe_prior_source),
                    mu_p_push=mu_p_push,
                    Sigma_p_push_inv=inv_p_push,
                )
            except Exception:
                print("[mu-sigma vfe branch] FAIL", flush=True)
                g_vfe_mu, g_vfe_S = None, None
            _tock(t0, "vfe_mu_sigma")

    # -------- combine & natural gradient projection --------
    t0 = _tic()
    dmu_total = alpha * g_self_mu + lambd * g_fb_mu + dmu_align
    dS_total  = alpha * g_self_S  + lambd * g_fb_S  + dS_align
    if g_vfe_mu is not None and g_vfe_S is not None:
        w_vfe = float(cfg_get(ctx, "vfe_weight", 1.0))
        dmu_total = dmu_total + w_vfe * g_vfe_mu
        dS_total  = dS_total  + w_vfe * g_vfe_S
    dS_total = 0.5 * (dS_total + np.swapaxes(dS_total, -1, -2))
    _tock(t0, "combine_totals")

    t0 = _tic()
       
    delta_mu, delta_S = apply_natural_gradient_batch(
        ctx,
        getattr(agent_i, mu_key), getattr(agent_i, sigma_key),
        dmu_total.astype(np.float32, copy=False),
        dS_total.astype(np.float32,  copy=False),
        mask=agent_i.mask,
        assume_sanitized=True,          # since you sanitize Σ in refresh_agents
        grad_sigma_is_symmetric=True,   # if you already symmetrized upstream
        use_float64=False 
    )
    
    _tock(t0, "natural_project")

    # -------- accumulate to agent --------
    if which == "q":
        gmu_attr, gsig_attr = "grad_mu_q", "grad_sigma_q"
    else:
        gmu_attr, gsig_attr = "grad_mu_p", "grad_sigma_p"

    if getattr(agent_i, gmu_attr, None) is None:
        setattr(agent_i, gmu_attr,  np.zeros_like(getattr(agent_i, mu_key),    dtype=np.float32))
    if getattr(agent_i, gsig_attr, None) is None:
        setattr(agent_i, gsig_attr, np.zeros_like(getattr(agent_i, sigma_key), dtype=np.float32))

    setattr(agent_i, gmu_attr,  getattr(agent_i, gmu_attr)  + delta_mu)
    setattr(agent_i, gsig_attr, getattr(agent_i, gsig_attr) + delta_S)

    if PRINT_SIGN:
        aid = _aid(agent_i)
        ax = tuple(range(delta_mu.ndim - 1))
        mu_mean = np.mean(delta_mu, axis=ax)
        S_tr = np.mean(np.trace(delta_S, axis1=-2, axis2=-1), axis=ax)
        def sgns(vec): return "".join("+" if v>0 else "-" if v<0 else "0" for v in vec.tolist())
        

        print(f"[MU/SIG] mode={mode} ai={aid} "
              f"μ_sign={sgns(mu_mean)} μ_mean={np.array2string(mu_mean, precision=3, suppress_small=True)} "
              f"|μ|_mean={float(np.mean(np.abs(delta_mu))):.3e} "
              f"|Σ|_F_mean={float(np.mean(np.linalg.norm(delta_S.reshape(*delta_S.shape[:-2], -1), axis=-1))):.3e} "
              f"tr(ΔΣ)_mean={float(S_tr):.3e}", flush=True)

    # -------- print timings (only when profiling is enabled) --------
    if prof:
        aid = _aid(agent_i)
        npairs = n_pairs if beta_like != 0.0 else 0
        apx = align_px if beta_like != 0.0 else 0
        # stable pretty print
        ordered = [
            "Phi_fetch", "push_gaussians", "self_feedback",
            "align_total", "align_pair_sum", "align_pair_avg",
            "vfe_mu_sigma", "combine_totals", "natural_project"
        ]
        print(f"[μΣ PROF] Agent {aid} ({mode}) pairs={npairs} align_px={apx}")
        for k in ordered:
            if k in t:
                print(f"  {k:18s}: {t[k]*1e3:7.2f} ms")

    return delta_mu, delta_S


# --- Self / Feedback energy accumulation (shared with diagnostics) ---

def accumulate_self_feedback_energies(
    ctx,
    agent_i,
    *,
    mu_q, S_q,
    mu_p, S_p,
    mu_q_push, S_q_push,
    mu_p_push, S_p_push,
):
    """
    Reuses the already-computed pushes to accumulate
      self_sum  += alpha * sum_px KL(q || p')
      feedback += lambda * sum_px KL(p || q')
    into the per-step accumulator (global + per-agent buckets).
    """
    import numpy as np
    from runtime_context import cfg_get, energy_acc_add
    from core.numerical_utils import sanitize_sigma, safe_inv

    eps   = float(cfg_get(ctx, "eps", 1e-8))
    tau   = float(cfg_get(ctx, "support_tau", 1e-6))
    alpha = float(cfg_get(ctx, "alpha", 0.0))
    lambd = float(cfg_get(ctx, "feedback_weight", 0.0))

    # boolean support mask (same rule everywhere)
    m = np.asarray(getattr(agent_i, "mask", 1.0), np.float32)
    mm = (m > tau) if (m.dtype != bool) else m
    if not np.any(mm):
        return 0.0, 0.0

    def _kl_sum(mu0, S0, mu1, S1):
        # KL(N0 || N1) with a single inversion of S1
        mu0 = np.asarray(mu0, np.float64, order="C")
        mu1 = np.asarray(mu1, np.float64, order="C")
        S0  = sanitize_sigma(np.asarray(S0, np.float64, order="C"), eps=eps)
        S1  = sanitize_sigma(np.asarray(S1, np.float64, order="C"), eps=eps)
        A   = safe_inv(S1)  # (K,K) per-pixel
        d   = (mu0 - mu1)
        trA_S0 = np.einsum("...ij,...ji->...", A, S0, optimize=True)
        Ad     = np.einsum("...ij,...j->...i", A, d,  optimize=True)
        quad   = np.einsum("...i,...i->...", d, Ad,   optimize=True)
        _, logS1 = np.linalg.slogdet(S1)
        _, logS0 = np.linalg.slogdet(S0)
        K = S0.shape[-1]
        kl = 0.5 * (trA_S0 + quad - K + (logS1 - logS0))
        return kl

    # slice by mask and accumulate weighted sums
    self_kl     = _kl_sum(mu_q[mm], S_q[mm], mu_p_push[mm], S_p_push[mm])
    feedback_kl = _kl_sum(mu_p[mm], S_p[mm], mu_q_push[mm], S_q_push[mm])

    self_val = alpha * float(np.sum(self_kl))
    fb_val   = lambd * float(np.sum(feedback_kl))

    # global totals
    energy_acc_add(ctx, "self_sum",     self_val)
    energy_acc_add(ctx, "feedback_sum", fb_val)

    # per-agent totals (what compute_agent_metrics() prefers when present)
    aid = getattr(agent_i, "id", None)
    if aid is not None:
        energy_acc_add(ctx, f"self_sum[{aid}]",     self_val)
        energy_acc_add(ctx, f"feedback_sum[{aid}]", fb_val)

    return self_val, fb_val


def _accum_align_for_pair(
    ctx,
    agent_i,
    agent_j,
    *,
    fiber: str,
    mu_key: str,
    sigma_key: str,
    overlap_mask: np.ndarray,
    beta_like: float,
    eps: float,
):
    if beta_like == 0.0 or not np.any(overlap_mask):
        return 0.0, 0.0
    
    beta_like = 0.5 * beta_like
    # Transport j -> i in the given fiber
    Omega_ij = Omega(ctx, agent_i, agent_j, which=fiber)

    # Fields
    mu_i = getattr(agent_i, mu_key)
    S_i  = getattr(agent_i, sigma_key)
    mu_j = getattr(agent_j, mu_key)
    S_j  = getattr(agent_j, sigma_key)

    if not (np.isfinite(mu_i).all() and np.isfinite(mu_j).all()):
        raise FloatingPointError("Non-finite μ in alignment pair")
    if not (np.isfinite(S_i).all() and np.isfinite(S_j).all()):
        raise FloatingPointError("Non-finite Σ in alignment pair")

    # Fast push j -> i (reuse Σ_j^{-1} if you have it)
    inv_j_full = getattr(agent_j, "sigma_q_inv" if fiber == "q" else "sigma_p_inv", None)
    mu_j_t, S_j_t, inv_j_t = push_gaussian(
        mu_j, S_j, Omega_ij, eps=eps, return_inv=True,
        Sigma_inv=inv_j_full,
        assume_orthogonal=False,   # set True only if Ω is truly orthogonal
        sanitize_input=False
    )

    # i-side Euclidean grads only (reuse Σ_i^{-1} to avoid per-call inversion)
    inv_i_full = getattr(agent_i, "sigma_q_inv" if fiber == "q" else "sigma_p_inv", None)
    gμ_i, gΣ_i = grad_alignment_energy_source(
        mu_i, S_i, mu_j_t, inv_j_t, eps=eps,
        sigma_i_inv=inv_i_full,
        assume_sanitized=True
    )

    return (beta_like * gμ_i), (beta_like * gΣ_i)


def _self_and_feedback_grads(
    mode: str,
    mu_q, sigma_q, mu_p, sigma_p,
    mu_q_push, Sigma_q_push, inv_q_push,
    mu_p_push, Sigma_p_push, inv_p_push,
    Phi_mat, Phi_tilde_mat, eps: float,
    *, sigma_q_inv=None, sigma_p_inv=None, mask=None
):
    if mode == "belief":
        g_self_mu, g_self_S = grad_self_energy_belief(
            mu_q, sigma_q, mu_p_push, inv_p_push,
            sigma_q_inv=sigma_q_inv, mask=mask
        )
        g_fb_mu, g_fb_S = grad_feedback_energy_belief(
            mu_q, sigma_q, mu_p, mu_q_push,
            Sigma_q_push, inv_q_push, sigma_p, Phi_mat
        )
    elif mode == "model":
        g_self_mu, g_self_S = grad_self_energy_model(
            mu_q, sigma_q, mu_p_push, inv_p_push, Phi_tilde_mat, mask=mask
        )
        g_fb_mu, g_fb_S = grad_feedback_energy_model(
            mu_p, sigma_p, mu_q_push, Sigma_q_push, inv_q_push,
            sigma_p_inv=sigma_p_inv
        )
    else:
        raise ValueError(f"Unsupported mode: {mode}")
    return g_self_mu, g_self_S, g_fb_mu, g_fb_S




#==============================================================================
#
#                    FEEDBACK / SELF TERMS (unchanged math, safer numerics)
#==============================================================================

def grad_alignment_energy_source(
    mu_i, sigma_i, mu_j_t, sigma_j_t_inv, eps=1e-8,
    *, sigma_i_inv=None, assume_sanitized=True
):
    """
    Faster: reuse precomputed sigma_i_inv if provided; optionally skip sanitize.
    """
    mu_i       = np.asarray(mu_i,       dtype=np.float32, order="C")
    mu_j_t     = np.asarray(mu_j_t,     dtype=np.float32, order="C")
    sigma_j_t_inv = np.asarray(sigma_j_t_inv, dtype=np.float32, order="C")

    dmu = mu_i - mu_j_t
    # grad_mu_i = S'^-1 (μ_i - μ_j')
    grad_mu = np.einsum("...ij,...j->...i", sigma_j_t_inv, dmu, optimize=True)

    if sigma_i_inv is None:
        Si = np.asarray(sigma_i, dtype=np.float32, order="C")
        if not assume_sanitized:
            Si = sanitize_sigma(Si, eps=eps)
        sigma_i_inv = safe_inv(Si)   # batched cholesky-inv

    grad_sigma = 0.5 * (sigma_j_t_inv - sigma_i_inv)
    # symmetrize
    grad_sigma = 0.5 * (grad_sigma + np.swapaxes(grad_sigma, -1, -2))

    return grad_mu.astype(np.float32, copy=False), grad_sigma.astype(np.float32, copy=False)


def grad_alignment_energy_target(
    mu_i, sigma_i, mu_j_t, sigma_j_t_inv, Omega_ij, eps: float = 1e-8,
    *, assume_sanitized=True
):
    """
    Faster: use v = S'^-1 dμ  ->  v vᵀ for the middle term; skip repeated sanitize.
    """
    mu_i       = np.asarray(mu_i,       dtype=np.float32, order="C")
    mu_j_t     = np.asarray(mu_j_t,     dtype=np.float32, order="C")
    Omega_ij   = np.asarray(Omega_ij,   dtype=np.float32, order="C")
    sigma_jinv = np.asarray(sigma_j_t_inv, dtype=np.float32, order="C")

    dmu = mu_i - mu_j_t

    # ∂_{μ_j'} KL = - S'^-1 dμ  ;  map back with Ωᵀ
    gmu_jp    = -np.einsum("...ij,...j->...i", sigma_jinv, dmu, optimize=True)
    grad_mu_j = np.einsum("...ji,...j->...i", Omega_ij, gmu_jp, optimize=True)

    # Σ_i only appears (not inverted); assume sanitized upstream
    Si = np.asarray(sigma_i, dtype=np.float32, order="C")
    if not assume_sanitized:
        Si = sanitize_sigma(Si)

    # v = S'^-1 dμ  ->  v vᵀ
    v   = np.einsum("...ij,...j->...i", sigma_jinv, dmu, optimize=True)
    vvT = np.einsum("...i,...j->...ij", v, v, optimize=True)

    # gΣ' = 1/2( -S'^-1 Σ_i S'^-1 - vvᵀ + S'^-1 )
    t0 = -np.einsum("...ij,...jk,...kl->...il", sigma_jinv, Si, sigma_jinv, optimize=True)
    gSp = 0.5 * (t0 - vvT + sigma_jinv)

    # map back: Ωᵀ gΣ' Ω, then symmetrize
    grad_sigma_j = np.einsum("...ji,...jk,...kl->...il",
                             Omega_ij, gSp, np.swapaxes(Omega_ij, -1, -2), optimize=True)
    grad_sigma_j = 0.5 * (grad_sigma_j + np.swapaxes(grad_sigma_j, -1, -2))

    return grad_mu_j.astype(np.float32, copy=False), grad_sigma_j.astype(np.float32, copy=False)



def grad_feedback_energy_belief(
    mu_q, sigma_q, mu_p, mu_q_push,
    sigma_q_push, sigma_q_push_inv, sigma_p, Phi, eps=1e-8, *,
    assume_sanitized=True,
):
    """
    ∂ wrt (μ_q, Σ_q) of KL(p || Φ·q), evaluated in q-fiber.
    Uses v = S'^-1 Δ and v v^T instead of S'^-1 ΔΔ^T S'^-1 to cut temps.
    """
    # Δ = μ_p - μ_q'
    delta = (mu_p - mu_q_push).astype(np.float32, copy=False)

    # v = S'^-1 Δ  (matvec)
    v = np.matmul(sigma_q_push_inv, delta[..., None])[..., 0]  # (...,K)

    # grad_μ = - Φ^T v
    Phi_T = np.swapaxes(Phi, -1, -2)
    grad_mu = -np.matmul(Phi_T, v[..., None])[..., 0]

    # M = S'^-1  - v v^T  - S'^-1 Σ_p S'^-1
    term1 = sigma_q_push_inv
    term2 = np.matmul(v[..., :, None], v[..., None, :])        # v v^T
    term3 = np.matmul(np.matmul(sigma_q_push_inv, sigma_p), sigma_q_push_inv)

    M = term1 - term2 - term3

    # grad_Σ = 1/2 Φ^T M Φ (symmetrized)
    grad_sigma = 0.5 * np.matmul(np.matmul(Phi_T, M), Phi)
    grad_sigma = 0.5 * (grad_sigma + np.swapaxes(grad_sigma, -1, -2))

    return grad_mu.astype(np.float32, copy=False), grad_sigma.astype(np.float32, copy=False)


def grad_feedback_energy_model(
    mu_p, sigma_p, mu_q_push,
    sigma_q_push, sigma_q_push_inv, Phi=None, eps=1e-8, *,
    sigma_p_inv=None, assume_sanitized=True,
):
    """
    ∂ wrt (μ_p, Σ_p) of KL(p || q'), evaluated in p-fiber.
    Avoids inverting Σ_p if sigma_p_inv is provided.
    """
    delta = (mu_p - mu_q_push).astype(np.float32, copy=False)

    # grad_μ = S'^-1 Δ
    grad_mu = np.matmul(sigma_q_push_inv, delta[..., None])[..., 0]

    # grad_Σ = 1/2 (S'^-1 - Σ_p^{-1})
    if sigma_p_inv is None:
        # assume Σ_p already sanitized upstream; we only invert if caller didn’t pass inv
        sigma_p_inv = safe_inv(sigma_p.astype(np.float32, copy=False))
    grad_sigma = 0.5 * (sigma_q_push_inv - sigma_p_inv)
    grad_sigma = 0.5 * (grad_sigma + np.swapaxes(grad_sigma, -1, -2))

    return grad_mu.astype(np.float32, copy=False), grad_sigma.astype(np.float32, copy=False)


def grad_self_energy_belief(
    mu_q, sigma_q, mu_p_push, sigma_p_push_inv, eps=1e-8, *,
    sigma_q_inv=None, mask=None, assume_sanitized=True,
):
    """
    ∂ wrt (μ_q, Σ_q) of KL(q || p'), evaluated in q-fiber.
    Reuses sigma_q_inv if provided.
    """
    delta = (mu_q - mu_p_push).astype(np.float32, copy=False)

    # grad_μ = S_p'^-1 Δ
    grad_mu = np.matmul(sigma_p_push_inv, delta[..., None])[..., 0]

    # grad_Σ = 1/2 (S_p'^-1 - Σ_q^{-1})
    if sigma_q_inv is None:
        sigma_q_inv = safe_inv(sigma_q.astype(np.float32, copy=False))
    
    grad_sigma = 0.5 * (sigma_p_push_inv - sigma_q_inv)
    grad_sigma = 0.5 * (grad_sigma + np.swapaxes(grad_sigma, -1, -2))

    if mask is not None:
        m = (np.asarray(mask) > float(getattr(config, "support_tau", 0.0)))
        grad_mu    = grad_mu * m[..., None]
        grad_sigma = grad_sigma * m[..., None, None]

    return grad_mu.astype(np.float32, copy=False), grad_sigma.astype(np.float32, copy=False)


def grad_self_energy_model(
    mu_q, sigma_q, mu_p_push, sigma_p_push_inv, Phi_tilde, eps=1e-8, *,
    assume_sanitized=True, mask=None,
):
    """
    ∂ wrt (μ_p, Σ_p) of KL(q || p'), evaluated in p-fiber.
    Uses v = M Δ and v v^T to avoid an extra large einsum.
    """
    delta = (mu_q - mu_p_push).astype(np.float32, copy=False)

    # tmp = M Δ
    v = np.matmul(sigma_p_push_inv, delta[..., None])[..., 0]

    # grad_μ = - Φ̃^T v
    Phi_tilde_T = np.swapaxes(Phi_tilde, -1, -2)
    grad_mu = -np.matmul(Phi_tilde_T, v[..., None])[..., 0]

    # G = M - v v^T - M Σ_q M
    vvT = np.matmul(v[..., :, None], v[..., None, :])
    M_Sq = np.matmul(sigma_p_push_inv, sigma_q.astype(np.float32, copy=False))
    G = sigma_p_push_inv - vvT - np.matmul(M_Sq, sigma_p_push_inv)

    # grad_Σ = 1/2 Φ̃^T G Φ̃  (symmetrized)
    grad_sigma = 0.5 * np.matmul(np.matmul(Phi_tilde_T, G), Phi_tilde)
    grad_sigma = 0.5 * (grad_sigma + np.swapaxes(grad_sigma, -1, -2))

    if mask is not None:
        m = (np.asarray(mask) > float(getattr(config, "support_tau", 0.0)))
        grad_mu    = grad_mu * m[..., None]
        grad_sigma = grad_sigma * m[..., None, None]

    return grad_mu.astype(np.float32, copy=False), grad_sigma.astype(np.float32, copy=False)


def vfe_mu_sigma_grads(
    y, mu, Sigma, W, b, sigma2, *,
    mask=None,
    sigma2_min: float = 1e-6,
    grad_mu_clip: float | None = 0.0,
    grad_S_clip: float | None = 0.0,
    sanitize_eps: float = 1e-8,
    ctx=None,
    vfe_prior_source: str | None = None,   # "push" | None
    mu_p_push=None,
    Sigma_p_push_inv=None,
):
    """
    If y is None -> skip accuracy and only compute prior if enabled.
    If vfe_prior_source == "push" -> use (mu_p_push, Sigma_p_push_inv)
    else if "euclid" -> use (m0, S0_inv) from cfg.
    """
    
    # --- to-arrays ---
    y     = np.asarray(y,     np.float32)
    mu    = np.asarray(mu,    np.float32)
    Sigma = np.asarray(Sigma, np.float32)
    W     = np.asarray(W,     np.float32)
    b     = np.asarray(b,     np.float32)

    # --- numeric guardrails (fail fast) ---
    
    _check_finite("y", y); _check_finite("mu", mu); _check_finite("Sigma", Sigma)
    _check_finite("W", W); _check_finite("b", b)
    if mask is not None:
        _check_finite("mask", np.asarray(mask))

    # --- scalar handling ---
    sigma2 = float(max(float(sigma2), float(sigma2_min)))
    if (not np.isfinite(sigma2)):
        raise FloatingPointError("[vfe_mu_sigma_grads] sigma2 is non-finite.")
    
    inv_s2 = 1.0 / sigma2

    # --- mask helpers ---
    if mask is None:
        print("[vfe mu-sig] mask is None!!!\n\n\n\n")
        m1 = 1.0  # (..., 1) logically
        m2 = 1.0  # (..., 1, 1)
    else:
        m  = np.asarray(mask, np.float32)
        m1 = m[..., None]
        m2 = m[..., None, None]

    # === q-fiber only ===
    mu_q = mu
    S_q  = sanitize_sigma(Sigma, eps=sanitize_eps)  # SPD projection only

    # --- residuals (apply mask BEFORE multiplies to avoid NaN*0) ---
    # r = (W μ_q + b) - y
    r = (mu_q @ W.T) + b - y              # (..., D)
    if mask is not None:
        r = np.where(m1.astype(bool), r, 0.0)

    # --- grads: Accuracy term (likelihood) in q-fiber ---
    WT   = W.T                             # (Kq, D)
    WT_W = (WT @ W).astype(np.float32)     # (Kq, Kq) symmetric

    # ∂F_acc/∂μ_q = (1/σ²) W^T r
    g_mu_q = (inv_s2 * (WT @ r[..., None]).squeeze(-1)).astype(np.float32)      # (..., Kq)
    # ∂F_acc/∂Σ_q = (1/2σ²) W^T W   (broadcast to Σ shape)
    g_S_q  = (0.5 * inv_s2 * WT_W).astype(np.float32)                           # (Kq, Kq)
    g_S_q  = np.broadcast_to(g_S_q, S_q.shape)

    # --- complexity: Prior in q-fiber ---
    use_prior = bool(cfg_get(ctx, "vfe_use_prior", False))
    
    if use_prior:
        print("this should not print if use_prior = False {use_prior = {use_prior}\n\n\n\n")
        source = vfe_prior_source or str(cfg_get(ctx, "vfe_prior_source", "push")).lower()
    
        if source == "push":
            # Use the transported model prior: KL(q || N(mu_p^t, A)), A = Phi_tilde Σ_p Phi_tilde^T
            # => grads wrt q are identical to your self-energy-belief grads.
            if (mu_p_push is None) or (Sigma_p_push_inv is None):
                raise ValueError(
                    "[vfe_mu_sigma_grads] vfe_prior_source='push' requires mu_p_push and Sigma_p_push_inv."
                )    
            # Reuse the canonical implementation to avoid formula drift:
            g_mu_prior, g_S_prior = grad_self_energy_belief(
                mu_q, S_q, mu_p_push, Sigma_p_push_inv,
                eps=sanitize_eps, mask=mask
            )
            
        else:
            raise ValueError(f"[vfe_mu_sigma_grads] Unknown vfe_prior_source={source!r}. Use 'push' or 'euclid'.")
    
        # accumulate into VFE grads (still in q-fiber)
        g_mu_q = g_mu_q + g_mu_prior
        g_S_q  = g_S_q  + g_S_prior

    # --- gate grads by mask (return fiber = q) ---
    if mask is None:
        g_mu, g_S = g_mu_q, g_S_q
    else:
        g_mu = g_mu_q * m1
        g_S  = g_S_q  * m2


    # --- single final symmetry projection (grads only) ---
    g_S = 0.5 * (g_S + np.swapaxes(g_S, -1, -2))

   
    _check_finite("g_mu", g_mu)
    _check_finite("g_S", g_S)

    return g_mu, g_S


def apply_natural_gradient_batch(
    ctx,
    mu_field,            # (H,W,K)
    sigma_field,         # (H,W,K,K) SPD
    grad_mu_field,       # (H,W,K)
    grad_sigma_field,    # (H,W,K,K) (sym or not)
    mask=None,
    *,
    use_float64=None,
    assume_sanitized=True,       # True if Σ already sanitized upstream
    grad_sigma_is_symmetric=False, # True if caller already symmetrized ∇Σ
    assert_finite=False           # set True only when debugging
):
    eps         = float(cfg_get(ctx, "eps", 1e-10))
    support_tau = float(cfg_get(ctx, "support_tau", 1e-6))

    H, W, K = mu_field.shape
    N = H * W

    # Default dtype policy: prefer f32 unless explicitly asked for f64
    if use_float64 is None:
        use_float64 = bool(cfg_get(ctx, "natgrad_use_float64", False))
    dtype = np.float64 if use_float64 else np.float32
    out_dtype = np.float32 if not use_float64 else np.float64

    # Contiguous, batched views
    Sig  = np.ascontiguousarray(sigma_field,      dtype=dtype).reshape(N, K, K)
    gmu  = np.ascontiguousarray(grad_mu_field,    dtype=dtype).reshape(N, K)
    gSig = np.ascontiguousarray(grad_sigma_field, dtype=dtype).reshape(N, K, K)

    # Sanitize Σ only if we can't trust upstream
    if not assume_sanitized:
        Sig = sanitize_sigma(Sig, eps=eps)

    # Symmetrize ∇Σ only if needed
    if not grad_sigma_is_symmetric:
        gSig = 0.5 * (gSig + np.swapaxes(gSig, -1, -2))

    # ---- Build active set from mask (compute work only where needed) ----
    if mask is None:
        active_idx = None
        wts = None
    else:
        m = np.asarray(mask)
        if m.shape != (H, W):
            raise ValueError(f"mask shape {m.shape} != {(H, W)}")
        m_flat = m.reshape(N)
        if m.dtype == bool:
            active_idx = np.flatnonzero(m_flat)
            wts = None
        else:
            act = m_flat > support_tau
            active_idx = np.flatnonzero(act)
            wts = m_flat[active_idx].astype(dtype, copy=False)

    if active_idx is not None:
        Sig_c  = Sig[active_idx]
        gmu_c  = gmu[active_idx]
        gSig_c = gSig[active_idx]
    else:
        Sig_c, gmu_c, gSig_c = Sig, gmu, gSig

    # ---- Natural steps (batched BLAS) ----
    # δμ = -Σ ∇μ
    dmu_c = -(Sig_c @ gmu_c[..., None])[..., 0]                     # (nA,K)

    # δΣ = -2 Σ sym(∇Σ) Σ  (gSig_c is already symmetrized if requested)
    tmp   = Sig_c @ gSig_c                                         # (nA,K,K)
    dS_c  = -2.0 * (tmp @ Sig_c)                                   # (nA,K,K)
    dS_c  = 0.5 * (dS_c + np.swapaxes(dS_c, -1, -2))               # symmetry guard

    # Optional soft weights
    if wts is not None:
        dmu_c *= wts[:, None]
        dS_c  *= wts[:, None, None]

    # ---- Scatter back (if we computed on a subset) ----
    if active_idx is not None:
        dmu = np.zeros((N, K), dtype=out_dtype)
        dS  = np.zeros((N, K, K), dtype=out_dtype)
        dmu[active_idx] = dmu_c.astype(out_dtype, copy=False)
        dS [active_idx] = dS_c.astype(out_dtype,  copy=False)
    else:
        dmu = dmu_c.astype(out_dtype, copy=False)
        dS  = dS_c.astype(out_dtype,  copy=False)

    if assert_finite:
        if not (np.isfinite(dmu).all() and np.isfinite(dS).all()):
            raise FloatingPointError("Nonfinite natural gradient (μ or Σ).")

    return dmu.reshape(H, W, K), dS.reshape(H, W, K, K)




def Qapply_natural_gradient_batch(
    ctx,
    mu_field,
    sigma_field,
    grad_mu_field,
    grad_sigma_field,
    mask=None,
    *,    
    use_float64: bool = True,
    assume_sanitized=True,       # True if Σ already sanitized upstream
    grad_sigma_is_symmetric=False, # True if caller already symmetrized ∇Σ
    assert_finite=False           # set True only when debugging
):
    """
    Vectorized natural gradient for Gaussian fields:
        δμ = -Σ ∇_μ L
        δΣ = -2 Σ sym(∇_Σ L) Σ

    Args
    ----
    mu_field         : (H,W,K)
    sigma_field      : (H,W,K,K) SPD (full)
    grad_mu_field    : (H,W,K)
    grad_sigma_field : (H,W,K,K)
    mask             : (H,W) bool or float weights (optional)

    Returns
    -------
    delta_mu   : (H,W,K)
    delta_sigma: (H,W,K,K)
    """
    
    eps          = float(cfg_get(ctx, "eps", 1e-10))
    support_tau  = float(cfg_get(ctx, "support_tau", 1e-6))

    # ---- shapes / dtypes ----
    H, W, K = mu_field.shape
    N = H * W
    dtype = np.float64 if use_float64 else np.float32
   
    Sig  = np.asarray(sigma_field,      dtype=dtype).reshape(N, K, K)
    gmu  = np.asarray(grad_mu_field,    dtype=dtype).reshape(N, K)
    gSig = np.asarray(grad_sigma_field, dtype=dtype).reshape(N, K, K)

    # ---- SPD sanitize Σ and symmetrize ∇Σ ----
    Sig = sanitize_sigma(Sig, eps=eps)  # must return symmetric SPD in dtype
    gSig = 0.5 * (gSig + np.swapaxes(gSig, -1, -2))

    # ---- natural steps ----
    dmu = -np.einsum("nik,nk->ni", Sig, gmu, optimize=True)
    tmp =  np.einsum("nij,njk->nik", Sig, gSig, optimize=True)
    dS  = -2.0 * np.einsum("nij,njk->nik", tmp, Sig, optimize=True)
    dS  = 0.5 * (dS + np.swapaxes(dS, -1, -2))  # symmetry guard

    # ---- mask / weights ----
    if mask is None:
        print("[nat grad] mask is none!!\n\n\n")
        active = np.ones(N, dtype=bool)
        wts = None
    else:
        m = np.asarray(mask)
        if m.shape != (H, W):
            raise ValueError(f"mask shape {m.shape} != {(H, W)}")
        m = m.reshape(N)
        if m.dtype == bool:
            active = m
            wts = None
        else:
            active = m > support_tau
            wts = m.astype(dtype, copy=False)

    # ---- soft weights (if provided) ----
    if wts is not None:
        dmu *= wts[:, None]
        dS  *= wts[:, None, None]

    # ---- zero outside support ----
    if not np.all(active):
        ia = ~active
        dmu[ia] = 0.0
        dS[ia]  = 0.0

    
    finite = np.isfinite(dmu).all() and np.isfinite(dS).all()
    
    if not finite:
        raise FloatingPointError("Nonfinite natural gradient (μ or Σ).")
    
    # ---- restore shapes / cast ----
    out_dtype = np.float32 if not use_float64 else dtype
    return dmu.reshape(H, W, K).astype(out_dtype), dS.reshape(H, W, K, K).astype(out_dtype)







