# -*- coding: utf-8 -*-
"""
Created on Sat Aug 23 14:44:39 2025

@author: chris and christine
"""

"""
descent_check.py — Drop-in utilities to validate that your update directions
actually descend the total energy.

Two complementary checks:

1) Algebraic sign tests (no recompute of energy; super fast)
   - For natural-gradient updates (μ, Σ), check that <∇E, Δ> ≤ 0 per pixel.
   - For gauge fields φ, φ̃:
       If you provide the NATURAL gradient g_nat = dexp^{-1}(F^{-1} ∇E),
       the condition for a subtractive update (φ ← φ − τ g_nat) is
           ⟨∇E, −g_nat⟩ ≤ 0   (approximate, projected check)

2) Empirical energy test (optional, requires callables):
   - Give us an `energy_fn(ctx)` that returns a scalar and an `apply_fn(scale)`
     that applies a *scaled* version of the CURRENT step (without committing),
     and we’ll evaluate E(0) vs E(ε) with backoff.

You can call `run_descent_report(...)` from `synchronous_step` after gradients
are computed, before committing updates.
"""

from typing import Dict, Optional, Callable, Any, Tuple
import numpy as np
import json, os

Array = np.ndarray


def _masked_flat(a: Array, mask: Optional[Array]) -> Array:
    if mask is None:
        return a.reshape(-1, a.shape[-1]) if a.ndim >= 2 else a.reshape(-1, 1)
    m = np.asarray(mask, bool)
    if a.ndim == m.ndim + 1:
        return a[m]
    while a.ndim > m.ndim:
        m = m[..., None]
    return a[m[..., 0]]


def _inner(grad: Array, delta: Array, mask: Optional[Array]) -> Tuple[float, Dict[str, float]]:
    g = np.asarray(grad, np.float32)
    d = np.asarray(delta, np.float32)
    if g.shape != d.shape:
        raise ValueError(f"shape mismatch: grad {g.shape} vs delta {d.shape}")
    if g.ndim == 1:
        ip = float(np.dot(g, d))
        return ip, {"mean": ip, "min": ip, "max": ip, "viol_frac": float(ip > 0.0)}
    G = _masked_flat(g, mask)
    D = _masked_flat(d, mask)
    ip = np.einsum("nk,nk->n", G, D)
    mean = float(np.mean(ip)) if ip.size else 0.0
    viol_frac = float(np.mean(ip > 0.0)) if ip.size else 0.0
    return mean, {
        "mean": mean,
        "min": float(np.min(ip)) if ip.size else 0.0,
        "max": float(np.max(ip)) if ip.size else 0.0,
        "p50": float(np.percentile(ip, 50)) if ip.size else 0.0,
        "p90": float(np.percentile(ip, 90)) if ip.size else 0.0,
        "viol_frac": viol_frac,
        "count": int(ip.size),
    }


def check_mu_sigma_signs(grads: Dict[str, Array], deltas: Dict[str, Array], mask: Optional[Array] = None) -> Dict[str, Any]:
    out = {}
    for k in ["mu_q", "sigma_q", "mu_p", "sigma_p"]:
        if k in grads and k in deltas and grads[k] is not None and deltas[k] is not None:
            mean_ip, stats = _inner(grads[k], deltas[k], mask)
            out[k] = {"ok": (stats["mean"] <= 0.0), "ip_stats": stats}
    return out


def check_phi_signs(euclid_grads: Dict[str, Array], nat_grads: Dict[str, Array], mask: Optional[Array] = None) -> Dict[str, Any]:
    out = {}
    for k in ["phi", "phi_model"]:
        if k in nat_grads and nat_grads[k] is not None:
            gnat = np.asarray(nat_grads[k], np.float32)
            qnorm = float(np.mean(np.sum(gnat * gnat, axis=-1))) if gnat.ndim >= 2 else float(np.dot(gnat, gnat))
        else:
            gnat, qnorm = None, float("nan")
        approx = None
        if k in euclid_grads and k in nat_grads and euclid_grads[k] is not None and nat_grads[k] is not None:
            mean_ip, stats = _inner(euclid_grads[k], -nat_grads[k], mask)
            approx = {"ok": (stats["mean"] <= 0.0), "ip_stats": stats}
        out[k] = {"gnat_sq_mean": qnorm, "approx_proj": approx}
    return out


def empirical_energy_test(energy_fn: Callable[[], float], apply_trial_step_fn: Callable[[float], None], revert_fn: Callable[[], None], step_scales=(0.5, 0.25, 0.1, 0.05)) -> Dict[str, Any]:
    E0 = float(energy_fn())
    trials = []
    good_scale = None
    for s in step_scales:
        apply_trial_step_fn(float(s))
        E1 = float(energy_fn())
        trials.append((s, E1))
        revert_fn()
        if np.isfinite(E1) and E1 <= E0:
            good_scale = float(s)
            break
    return {"E0": E0, "trials": trials, "good_scale": good_scale}


def run_descent_report(mu_sigma_grads: Dict[str, Array], mu_sigma_deltas: Dict[str, Array], phi_euclid_grads: Dict[str, Array], phi_nat_grads: Dict[str, Array], mask: Optional[Array] = None, energy_probe: Optional[Dict[str, Callable]] = None, save_path: Optional[str] = None) -> Dict[str, Any]:
    report = {
        "algebraic": {
            "mu_sigma": check_mu_sigma_signs(mu_sigma_grads, mu_sigma_deltas, mask),
            "phi": check_phi_signs(phi_euclid_grads, phi_nat_grads, mask),
        },
        "empirical": None,
    }
    if energy_probe is not None:
        emp = empirical_energy_test(
            energy_probe["energy_fn"],
            energy_probe["apply_trial_step_fn"],
            energy_probe["revert_fn"],
        )
        report["empirical"] = emp
    if save_path:
        try: os.makedirs(os.path.dirname(save_path), exist_ok=True)
        except Exception: pass
        with open(save_path, "w", encoding="utf-8") as f:
            json.dump(report, f, indent=2)
    return report


def _fmt_stats(stats: Dict[str, float]) -> str:
    return (
        f"mean={stats.get('mean', 0):+.3e}  "
        f"min={stats.get('min', 0):+.3e}  "
        f"p50={stats.get('p50', 0):+.3e}  "
        f"p90={stats.get('p90', 0):+.3e}  "
        f"max={stats.get('max', 0):+.3e}  "
        f"viol%={100*stats.get('viol_frac', 0):.1f}%  "
        f"count={int(stats.get('count', 0))}"
    )


def print_descent_report(report: Dict[str, Any]) -> None:
    print("=== Descent Validation Report ===")
    alg = report["algebraic"]
    print("\n[μ/Σ algebraic inner-products] (expect ≤ 0):")
    for k, v in alg["mu_sigma"].items():
        flag = "OK " if v["ok"] else "BAD"
        print(f"  {k:9s}: {flag} | {_fmt_stats(v['ip_stats'])}")
    print("\n[φ algebraic projected check] (expect ≤ 0 on ⟨∇E, −g_nat⟩):")
    for k, v in alg["phi"].items():
        approx = v["approx_proj"]
        qn = v["gnat_sq_mean"]
        if approx is None:
            print(f"  {k:9s}: (no grads provided)  ||  ⟨g_nat,g_nat⟩ mean={qn:+.3e}")
        else:
            flag = "OK " if approx["ok"] else "BAD"
            print(f"  {k:9s}: {flag} | {_fmt_stats(approx['ip_stats'])} || ⟨g_nat,g_nat⟩ mean={qn:+.3e}")
    emp = report.get("empirical", None)
    if emp is not None:
        print("\n[Empirical energy probe] (E(ε) ≤ E(0) expected)")
        print(f"  E0 = {emp['E0']:+.6e}")
        for s, e1 in emp["trials"]:
            print(f"  scale={s:>5.2f} → E={e1:+.6e}")
        print(f"  first_good_scale = {emp['good_scale']}")
