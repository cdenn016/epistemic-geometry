
import numpy as np
import config
from omega import compute_curvature_gradient_analytical, d_exp_phi_exact, d_exp_phi_tilde_exact
from natural_gradient import compute_fisher_geometry_gradient
from numerical_utils import safe_inv, sanitize_sigma, safe_omega_inv
 
from transport_cache import E_grid, Lambda_dn, Lambda_up, Jinv_grid,Theta_dn, Theta_up, Omega

#==============================================================================
#
#                    GATHER PHI GAUGE FIELD GRADIENT TERMS
#                          Beliefs and Models
#==============================================================================

def accumulate_phi_alignment_gradient(
    agent_i, agent_j, generators, params,
    field="phi", beta_key=None, omega_cache_key=None,
    mu_key=None, sigma_key=None,
    fisher_inv_key=None, grad_key=None,
    Q_all_i=None,           # list/array (d, ..., K, K)
    exp_neg_phi_j=None,     # (..., K, K)
    agents=None,            # for Fisher regularizer
):
    """
    Compute and accumulate ∇_φ alignment term for agent_i against agent_j,
    plus regularizers. Uses central transport cache when ctx is provided.
    """
    import numpy as np, config

    assert mu_key and sigma_key and fisher_inv_key and grad_key, "mu_key/sigma_key/fisher_inv_key/grad_key are required"

    # --- weights & context
    beta = params.get(beta_key, getattr(config, beta_key, 0.0)) if beta_key else float(params.get("beta", 0.0))
    if beta <= 0.0:
        return
    ctx = params.get("runtime_ctx", None) or params.get("ctx", None)

    # --- overlap / joint mask
    eps = float(getattr(config, "support_cutoff_eps", 1e-6))
    joint_mask = ((np.asarray(agent_i.mask) > eps) & (np.asarray(agent_j.mask) > eps)).astype(np.float32)[..., None]
    if not np.any(joint_mask):
        return

    # --- fields
    mu_i    = np.asarray(getattr(agent_i, mu_key),    np.float32)
    sigma_i = np.asarray(getattr(agent_i, sigma_key), np.float32)
    mu_j    = np.asarray(getattr(agent_j, mu_key),    np.float32)

    # Choose fiber from field name
    which = "q" if field == "phi" else "p"

    # --- transports: cache fast path
    if ctx is not None:
        E_i = E_grid(ctx, agent_i, which=which)                 # (...,K,K)
        E_j = E_grid(ctx, agent_j, which=which)                 # (...,K,K)
        Omega_ij = Omega(ctx, agent_i, agent_j, which=which)    # (...,K,K)
    else:
        from omega import exp_lie_algebra_irrep
        from numerical_utils import safe_omega_inv
        phi_i = np.asarray(getattr(agent_i, field), np.float32)
        phi_j = np.asarray(getattr(agent_j, field), np.float32)
        E_i = exp_lie_algebra_irrep(phi_i, generators)
        E_j = exp_lie_algebra_irrep(phi_j, generators)
        Omega_ij = np.matmul(E_i, safe_omega_inv(E_j, eps=float(getattr(config, "eps", 1e-6))))

    Omega_T = np.swapaxes(Omega_ij, -1, -2)

    # μ_j pushed to i
    mu_j_t = np.einsum("...ij,...j->...i", Omega_ij, mu_j, optimize=True)

    # Σ_j^{-1} push
    inv_key = sigma_key.replace("_field", "_inv")
    sigma_j_inv = getattr(agent_j, inv_key, None)
    if sigma_j_inv is not None:
        sigma_j_t_inv = np.einsum("...ik,...kl,...lj->...ij", Omega_ij, sigma_j_inv, Omega_T, optimize=True)
    else:
        from numerical_utils import sanitize_sigma, safe_inv
        sigma_j = sanitize_sigma(np.asarray(getattr(agent_j, sigma_key), np.float32), eps=float(getattr(config, "eps", 1e-6)))
        sigma_j_t = np.einsum("...ik,...kl,...lj->...ij", Omega_ij, sigma_j, Omega_T, optimize=True)
        sigma_j_t = sanitize_sigma(sigma_j_t, eps=float(getattr(config, "eps", 1e-6)))
        sigma_j_t_inv = safe_inv(sigma_j_t, eps=float(getattr(config, "eps", 1e-6)))

    # Jacobians for exp(φ_i) and exp(-φ_j) if not provided
    from omega import d_exp_phi_exact
    if Q_all_i is None:
        Q_all_i = d_exp_phi_exact(np.asarray(getattr(agent_i, field), np.float32), generators)
    if exp_neg_phi_j is None:
        from numerical_utils import safe_omega_inv
        exp_neg_phi_j = safe_omega_inv(E_j, eps=float(getattr(config, "eps", 1e-6)), debug=False)

    # ---------- raw Euclidean gradient wrt φ_i (…a) ----------
    grad_phi_raw = grad_kl_wrt_phi_i(
        mu_i, sigma_i,
        None, None,
        phi_i=np.asarray(getattr(agent_i, field), np.float32),
        phi_j=None,
        Omega_ij=Omega_ij,
        generators=generators,
        exp_phi_i=E_i,
        exp_phi_j=E_j,
        mu_j_t=mu_j_t,
        sigma_j_t_inv=sigma_j_t_inv,
        eps=float(getattr(config, "eps", 1e-6)),
        exp_neg_phi_j=exp_neg_phi_j,
        Q_all=Q_all_i,
    )

    # ---------- apply Fisher^{-1} ONCE (natural frame) ----------
    F_inv = getattr(agent_i, fisher_inv_key, None)
    if F_inv is None:
        d = grad_phi_raw.shape[-1]
        F_inv = np.broadcast_to(np.eye(d, dtype=np.float32), grad_phi_raw.shape[:-1] + (d, d))
    grad_nat = np.einsum("...ab,...b->...a", F_inv, grad_phi_raw, optimize=True)

    # ---------- add regularizers in NATURAL frame ----------
    reg_nat = apply_regularization_terms_lie_natural(
        agent=agent_i,
        phi_field=np.asarray(getattr(agent_i, field), np.float32),
        generators=generators,
        field=field,
        params={**params, "step_tag": getattr(ctx, "global_step", None) if ctx is not None else None},
        agents=agents,
        ctx=ctx,
    ).astype(np.float32, copy=False)

    grad_nat_total = grad_nat + reg_nat

    # ---------- map through cached Jinv(phi) ONCE ----------
    Jinv = Jinv_grid(ctx, agent_i, which=which) if ctx is not None else None
    if Jinv is None:
        # fallback: local build if no ctx
        from transport_cache import build_dexpinv_matrix
        Jinv = build_dexpinv_matrix(np.asarray(getattr(agent_i, field), np.float32))
    grad_phi = np.einsum("...ab,...b->...a", Jinv, grad_nat_total, optimize=True)

    # ---------- accumulate ----------
    grad_accum = getattr(agent_i, grad_key, None)
    if grad_accum is None:
        grad_accum = np.zeros_like(grad_phi, dtype=np.float32)
    setattr(agent_i, grad_key, grad_accum + (beta * grad_phi) * joint_mask)



def accumulate_phi_morphism_self_feedback(
    agent_i,
    generators_src, generators_tgt,
    params,
    field="phi",                # or "phi_model"
    fisher_inv_key=None,
    grad_key=None,
    phi_self_func=None,         # e.g. grad_self_phi_direct / grad_self_phi_tilde_direct
    phi_feedback_func=None,     # e.g. grad_feedback_phi_direct / grad_feedback_phi_tilde_direct
):
    import numpy as np, config, inspect
    from transport_cache import E_grid, Jinv_grid

    def _call_sig_aware(fn, **kwargs):
        if fn is None:
            return None
        try:
            sig = inspect.signature(fn).parameters
            return fn(**{k:v for k,v in kwargs.items() if k in sig})
        except Exception:
            return fn(**kwargs)

    alpha   = float(params.get("alpha",           getattr(config, "alpha",           1.0)))
    lambda_ = float(params.get("feedback_weight", getattr(config, "feedback_weight", 0.0)))
    if alpha <= 0.0 and lambda_ <= 0.0:
        return

    eps  = float(getattr(config, "support_cutoff_eps", 1e-6))
    mask = (np.asarray(agent_i.mask) > eps)[..., None]

    mu_q, sigma_q = agent_i.mu_q_field, agent_i.sigma_q_field
    mu_p, sigma_p = agent_i.mu_p_field, agent_i.sigma_p_field
    phi           = agent_i.phi
    phi_tilde     = agent_i.phi_model

    ctx = params.get("runtime_ctx", None)
    if ctx is not None:
        exp_phi       = E_grid(ctx, agent_i, which="q")
        exp_phi_tilde = E_grid(ctx, agent_i, which="p")
    else:
        from omega import exp_lie_algebra_irrep
        exp_phi       = exp_lie_algebra_irrep(phi,       generators_tgt)  # q
        exp_phi_tilde = exp_lie_algebra_irrep(phi_tilde, generators_src)  # p

    # Fisher^{-1} application helper
    F_inv = getattr(agent_i, fisher_inv_key, None)
    def _apply_metric(F_inv_, vec):
        if F_inv_ is None:
            return vec
        Fi = np.asarray(F_inv_)
        v  = np.asarray(vec)
        K  = v.shape[-1]
        if Fi.ndim == 1 and Fi.shape[-1] == K:
            return v * Fi
        if Fi.ndim == 2 and Fi.shape == (K, K):
            return np.einsum("...ab,...b->...a", Fi, v, optimize=True)
        if Fi.ndim >= 3 and Fi.shape[-2:] == (K, K):
            return np.einsum("...ab,...b->...a", Fi, v, optimize=True)
        return v

    # choose field + Jinv
    if field == "phi":
        base_field = phi
        Jinv = Jinv_grid(ctx, agent_i, which="q") if ctx is not None else None
        if Jinv is None:
            from transport_cache import build_dexpinv_matrix
            Jinv = build_dexpinv_matrix(np.asarray(base_field, np.float32))
    else:
        base_field = phi_tilde
        Jinv = Jinv_grid(ctx, agent_i, which="p") if ctx is not None else None
        if Jinv is None:
            from transport_cache import build_dexpinv_matrix
            Jinv = build_dexpinv_matrix(np.asarray(base_field, np.float32))

    # ---------- SELF term ----------
    if alpha > 0.0 and phi_self_func is not None:
        args = dict(
            mu_q=mu_q, sigma_q=sigma_q,
            mu_p=mu_p, sigma_p=sigma_p,
            Phi_0=getattr(agent_i, "Phi_0", None),
            Phi_tilde_0=getattr(agent_i, "Phi_tilde_0", None),
            phi=phi, phi_tilde=phi_tilde,
            exp_phi=exp_phi, exp_phi_tilde=exp_phi_tilde,
            eps=float(getattr(config, "eps", 1e-6)),
            generators_q=generators_tgt,  # target
            generators_p=generators_src,  # source
        )
        grad_self_eucl = _call_sig_aware(phi_self_func, **args)                  # (..., d)
        grad_self_nat  = _apply_metric(F_inv, grad_self_eucl).astype(np.float32)
        grad_self_man  = np.einsum("...ab,...b->...a", Jinv, grad_self_nat, optimize=True)
        setattr(agent_i, grad_key, getattr(agent_i, grad_key) + alpha * grad_self_man * mask)

    # ---------- FEEDBACK term ----------
    if lambda_ > 0.0 and phi_feedback_func is not None:
        args = dict(
            mu_p=mu_p, sigma_p=sigma_p,
            mu_q=mu_q, sigma_q=sigma_q,
            Phi_0=getattr(agent_i, "Phi_0", None),
            Phi_tilde_0=getattr(agent_i, "Phi_tilde_0", None),
            phi=phi, phi_tilde=phi_tilde,
            exp_phi=exp_phi, exp_phi_tilde=exp_phi_tilde,
            eps=float(getattr(config, "eps", 1e-6)),
            generators_q=generators_tgt,
            generators_p=generators_src,
        )
        grad_fb_eucl = _call_sig_aware(phi_feedback_func, **args)
        grad_fb_nat  = _apply_metric(F_inv, grad_fb_eucl).astype(np.float32)
        grad_fb_man  = np.einsum("...ab,...b->...a", Jinv, grad_fb_nat, optimize=True)
        setattr(agent_i, grad_key, getattr(agent_i, grad_key) + lambda_ * grad_fb_man * mask)


#==============================================================================
#
#                    WITH RESPECT TO phi_i TERMS
#                       VALIDATED
#==============================================================================
def grad_kl_wrt_phi_i(
    mu_i, sigma_i,
    mu_j, sigma_j,
    phi_i, phi_j,
    Omega_ij,
    generators,
    exp_phi_i,
    exp_phi_j,
    mu_j_t,
    sigma_j_t_inv,
    eps=1e-8,
    exp_neg_phi_j=None,
    Q_all=None,
):
    """
    Vectorized over Lie index a. Returns (..., d).
    Robustly handles Q_all stacking/broadcasting so that:
        Q_all.shape == (..., a, K, K)
        exp_neg_phi_j.shape == (..., K, K) broadcastable to Q_all's leading dims
    """
    import numpy as _np

    # ---- helpers -------------------------------------------------------------
    def _stack_Q_all_right_before_KK(Q_list_or_array, K_expected=None):
        """
        Ensure Q has shape (..., a, K, K), i.e., Lie axis 'a' is the -3 axis.
        Accepts:
          - list/tuple of length d with arrays shaped (..., K, K)
          - array with 'a' axis anywhere before the trailing K,K
        """
        if isinstance(Q_list_or_array, (list, tuple)):
            # assume each item has shape (..., K, K); insert 'a' right before K,K
            sample = Q_list_or_array[0]
            nd = sample.ndim
            # position for 'a' axis is nd-2 (just before the final two matrix dims)
            Q_arr = _np.stack(Q_list_or_array, axis=nd - 2)
        else:
            Q_arr = _np.asarray(Q_list_or_array)

        # Now move the axis of size d (excluding the last two K,K) to -3 if needed
        if Q_arr.ndim < 3:
            raise ValueError(f"Q_all has too few dims: {Q_arr.shape}")
        K1, K2 = Q_arr.shape[-2], Q_arr.shape[-1]
        if K_expected is not None and (K1 != K_expected or K2 != K_expected):
            raise ValueError(f"Q_all trailing dims {K1}x{K2} != expected {K_expected}x{K_expected}")
        # Find an axis (not in the last two) that equals d = generators.shape[0]
        d = int(generators.shape[0])
        if Q_arr.shape[-3] != d:
            # locate the 'a' axis
            a_axis = None
            for ax in range(Q_arr.ndim - 2):
                if Q_arr.shape[ax] == d:
                    a_axis = ax
                    break
            if a_axis is None:
                raise ValueError(f"Could not locate Lie axis of size d={d} in Q_all shape {Q_arr.shape}")
            if a_axis != Q_arr.ndim - 3:
                Q_arr = _np.moveaxis(Q_arr, a_axis, Q_arr.ndim - 3)
        return Q_arr

    def _broadcast_KK_to_leading(mat, lead_shape, K):
        """
        Ensure 'mat' ends with (K,K) and is broadcastable to 'lead_shape' + (K,K).
        """
        M = _np.asarray(mat)
        if M.ndim < 2 or M.shape[-2:] != (K, K):
            raise ValueError(f"Expected a (...,{K},{K}) matrix; got {M.shape}")
        need_leads = len(lead_shape)
        if M.ndim == 2:
            # add leading singleton axes
            M = M.reshape((1,) * need_leads + (K, K))
        else:
            # if M has some leads, let numpy broadcasting handle it,
            # but sanity-check compatibility
            if M.shape[-2:] != (K, K):
                raise ValueError(f"Matrix trailing dims mismatch {M.shape[-2:]} vs {(K,K)}")
        # broadcast (no copy) to target leading shape if necessary
        if M.shape[:-2] != tuple(lead_shape):
            # try broadcasting by expanding singleton dims
            target = tuple(lead_shape) + (K, K)
            M = _np.broadcast_to(M, target)
        return M
    
    def _broadcast_vec_to_leading(vec, lead_shape, K):
        """
        Ensure 'vec' ends with (K,) and is broadcastable to 'lead_shape' + (K,).
        """
        v = _np.asarray(vec)
        if v.ndim == 1:
            v = v.reshape((1,) * len(lead_shape) + (K,))
        elif v.shape[-1] != K:
            raise ValueError(f"Vector trailing dim mismatch {v.shape[-1]} vs {K}")
        if v.shape[:-1] != tuple(lead_shape):
            v = _np.broadcast_to(v, tuple(lead_shape) + (K,))
        return v

    # ---- inputs & shapes -----------------------------------------------------
   
    sigma_i = sanitize_sigma(sigma_i, eps=eps)
   

    # Q_all: d Jacobians of exp(phi_i); ensure (..., a, K, K)
    if Q_all is None:
        Q_all = d_exp_phi_exact(phi_i, generators)  # list of length d
    # figure K from sigma_i
    K = int(sigma_i.shape[-1])
    Q = _stack_Q_all_right_before_KK(Q_all, K_expected=K)  # (..., a, K, K)
    # exp(-phi_j): prefer cached; broadcast to Q's leading dims (excluding a,K,K)
    if exp_neg_phi_j is None:
        exp_neg_phi_j = safe_omega_inv(exp_phi_j, eps=eps, debug=False)
    exp_neg_phi_j = _broadcast_KK_to_leading(exp_neg_phi_j, lead_shape=Q.shape[:-3], K=K)

    # push-forward pieces
    delta_mu = mu_i - mu_j_t  # (..., K)

    # ---- terms ---------------------------------------------------------------
    # dΩ/dφ_i^a = Q[a] @ e^{-φ_j}
    # Q: (..., a, K, K), exp_neg_phi_j: (..., K, K) -> (..., a, K, K)
    Q = _np.einsum("...aik,...kj->...aij", Q, exp_neg_phi_j, optimize=True)
    Q_T = _np.swapaxes(Q, -1, -2)  # (..., a, K, K)

    # trace term: -0.5 * [ Tr(Sj_inv Q Σi) + Tr(Q^T Sj_inv Σi) ]
    t1 = _np.einsum("...ij,...ajk,...ki->...a", sigma_j_t_inv, Q, sigma_i, optimize=True)
    t2 = _np.einsum("...aij,...jk,...ki->...a", Q_T,           sigma_j_t_inv, sigma_i, optimize=True)
    trace_term = -0.5 * (t1 + t2)  # (..., a)

    # mean term (use pushed-forward mean):  - (μ_j_t)^T (Sj_inv (Q^T Δμ))
    tmp1 = _np.einsum("...aij,...j->...ai", Q_T, delta_mu, optimize=True)          # Q^T Δμ
    tmp2 = _np.einsum("...ij,...aj->...ai", sigma_j_t_inv, tmp1, optimize=True)    # Sj_inv (...)
    mean_term = -_np.einsum("...i,...ai->...a", mu_j_t, tmp2, optimize=True)


    # Mahalanobis term: 0.5 Δμ^T ( Q^T Sj_inv + Sj_inv Q ) Δμ
    v1 = _np.einsum("...ij,...j->...i", sigma_j_t_inv, delta_mu, optimize=True)   # Sj_inv Δμ
    part1 = _np.einsum("...aij,...j->...ai", Q_T, v1, optimize=True)              # Q^T Sj_inv Δμ
    v2 = _np.einsum("...aij,...j->...ai", Q,  delta_mu, optimize=True)            # Q Δμ
    part2 = _np.einsum("...ij,...aj->...ai", sigma_j_t_inv, v2, optimize=True)    # Sj_inv Q Δμ
    mahal_term = 0.5 * _np.einsum("...i,...ai->...a", delta_mu, part1 + part2, optimize=True)

    grad = trace_term + mean_term + mahal_term  # (..., a)
    return grad





def grad_feedback_phi_direct(
    mu_p, sigma_p,
    mu_q, sigma_q,
    Phi_0,
    phi,                # (..., d)
    phi_tilde,          # (..., d)
    generators_q,       # (d, K_q, K_q)
    exp_phi,            # (..., K_q, K_q)
    exp_phi_tilde,      # (..., K_p, K_p)
    eps=1e-8,
    # NEW optional precomputes:
    Q_all=None,         # (..., d, K_q, K_q) = d_exp_phi_exact(phi, generators_q)
    exp_neg_phi=None    # (..., K_q, K_q) = e^{-φ}
):
    """
    Vectorized over 'a': returns (..., d)
    Φ = e^{φ̃} Φ₀ e^{-φ}, ∂Φ = - Φ · (e^{-φ} (∂ e^{φ}) e^{-φ})
    """
    d, K_q, _ = generators_q.shape
    

    if exp_neg_phi is None:
        exp_neg_phi = safe_omega_inv(exp_phi, eps=eps, debug=False)
    if Q_all is None:
        # stack as (..., d, K_q, K_q)
        Q_list = d_exp_phi_exact(phi, generators_q)
        Q_all = np.stack(Q_list, axis=-3)  # assuming list of d arrays

    # Φ and Φᵀ
    Phi = np.einsum("...ik,...kj,...jl->...il", exp_phi_tilde, Phi_0, exp_neg_phi)
    Phi_T = np.swapaxes(Phi, -1, -2)


    # A, A^{-1}
    A = np.einsum("...ik,...kl,...lj->...ij", Phi, sigma_q, Phi_T)
    A = sanitize_sigma(A, eps=eps)
    A_inv = safe_inv(A, eps=eps)

    # Δμ and v
    Phi_mu_q = np.einsum("...ij,...j->...i", Phi, mu_q)
    delta_mu = mu_p - Phi_mu_q
    v = np.einsum("...ij,...j->...i", A_inv, delta_mu)  # (..., K_p)

    # Q̄_a = e^{-φ} Q_a e^{-φ}
    Q_bar = np.einsum("...ik,...akl,...lj->...aij", exp_neg_phi, Q_all, exp_neg_phi)

    # dΦ_a = - Φ Q̄_a
    dPhi = -np.einsum("...ik,...akj->...aij", Phi, Q_bar)
    dPhi_T = np.swapaxes(dPhi, -1, -2)

    # dA_a
    dA = (
        np.einsum("...aik,...kl,...lj->...aij", dPhi, sigma_q, Phi_T) +
        np.einsum("...ik,...kl,...alj->...aij", Phi,  sigma_q, dPhi_T)
    )

    # Term 1
    dPhi_mu = np.einsum("...aij,...j->...ai", dPhi, mu_q)       # (..., a, K_p)
    term1 = -np.einsum("...ai,...i->...a", dPhi_mu, v)

    # Term 2
    term2 = 0.5 * np.einsum("...ij,...aij->...a", A_inv, dA)

    # M_a = A^{-1} dA_a A^{-1}
    M = np.einsum("...ij,...ajk,...kl->...ail", A_inv, dA, A_inv)

    # Term 3
    term3 = -0.5 * np.einsum("...i,...aij,...j->...a", delta_mu, M, delta_mu)

    # Term 4
    term4 = -0.5 * np.einsum("...aij,...ji->...a", M, sigma_p)

    grad = term1 + term2 + term3 + term4  # (..., d)
    return grad


def grad_feedback_phi_tilde_direct(
    mu_p, sigma_p,
    mu_q, sigma_q,
    Phi_0,
    phi, phi_tilde,
    generators_p, generators_q,
    exp_phi, exp_phi_tilde,
    eps=1e-8,
    # NEW optional precomputes:
    Q_tilde_all=None,       # (..., d, K_p, K_p) = d_exp_phi_tilde_exact(phi_tilde, generators_p)
    exp_neg_phi_tilde=None  # (..., K_p, K_p) = e^{-φ̃}
):
    """
    Vectorized over 'a': returns (..., d)
    Left-trivialize: dΦ_a = L_a Φ,  L_a = (∂e^{φ̃}/∂φ̃^a) e^{-φ̃}.
    """
    d, K_p, _ = generators_p.shape
    

    if exp_neg_phi_tilde is None:
        exp_neg_phi_tilde = safe_omega_inv(exp_phi_tilde, eps=eps, debug=False)
    if Q_tilde_all is None:
        Q_list = d_exp_phi_tilde_exact(phi_tilde, generators_p)
        Q_tilde_all = np.stack(Q_list, axis=-3)

    # Φ
    exp_neg_phi = safe_omega_inv(exp_phi, eps=eps, debug=False)
    Phi   = np.einsum("...ik,...kj,...jl->...il", exp_phi_tilde, Phi_0, exp_neg_phi)
    Phi_T = np.swapaxes(Phi, -1, -2)

  
    A = np.einsum("...ik,...kl,...lj->...ij", Phi, sigma_q, Phi_T)
    A = sanitize_sigma(A, eps=eps)
    A_inv = safe_inv(A, eps=eps)

    Phi_mu_q = np.einsum("...ij,...j->...i", Phi, mu_q)
    delta_mu = mu_p - Phi_mu_q
    v = np.einsum("...ij,...j->...i", A_inv, delta_mu)

    # L_a = Q̃_a e^{-φ̃}
    L = np.einsum("...aik,...kj->...aij", Q_tilde_all, exp_neg_phi_tilde)

    # dΦ_a = L_a Φ
    dPhi = np.einsum("...aik,...kj->...aij", L, Phi)
    dPhi_T = np.swapaxes(dPhi, -1, -2)

    dA = (
        np.einsum("...aik,...kl,...lj->...aij", dPhi, sigma_q, Phi_T) +
        np.einsum("...ik,...kl,...alj->...aij", Phi,  sigma_q, dPhi_T)
    )

    dPhi_mu = np.einsum("...aij,...j->...ai", dPhi, mu_q)
    term1 = -np.einsum("...ai,...i->...a", dPhi_mu, v)

    term2 = 0.5 * np.einsum("...ij,...aij->...a", A_inv, dA)

    M = np.einsum("...ij,...ajk,...kl->...ail", A_inv, dA, A_inv)

    term3 = -0.5 * np.einsum("...i,...aij,...j->...a", delta_mu, M, delta_mu)
    term4 = -0.5 * np.einsum("...aij,...ji->...a", M, sigma_p)

    grad = term1 + term2 + term3 + term4
    return grad



def grad_self_phi_direct(
    mu_q, sigma_q,
    mu_p, sigma_p,
    Phi_tilde_0,
    phi, phi_tilde,
    generators_q, generators_p,
    exp_phi, exp_phi_tilde,
    eps=1e-8,
    # NEW optional precomputes:
    Q_all=None,               # (..., d, K_q, K_q)
    exp_neg_phi_tilde=None    # (..., K_p, K_p)
):
    """
    Vectorized over 'a': returns (..., d)
    Φ̃ = e^{φ} Φ̃₀ e^{-φ̃},  ∂Φ̃_a = (∂e^{φ}/∂φ^a) Φ̃₀ e^{-φ̃}.
    """
    d, K_q, _ = generators_q.shape
    

    if exp_neg_phi_tilde is None:
        exp_neg_phi_tilde = safe_omega_inv(exp_phi_tilde, eps=eps, debug=False)
    if Q_all is None:
        Q_list = d_exp_phi_exact(phi, generators_q)
        Q_all = np.stack(Q_list, axis=-3)

    # Φ̃ and A
    Phi_tilde = np.einsum("...ik,...kj,...jl->...il", exp_phi, Phi_tilde_0, exp_neg_phi_tilde)
    Phi_tilde_T = np.swapaxes(Phi_tilde, -1, -2)


    A = np.einsum("...ik,...kl,...lj->...ij", Phi_tilde, sigma_p, Phi_tilde_T)
    A = sanitize_sigma(A, eps=eps)
    A_inv = safe_inv(A, eps=eps)

    delta_mu = mu_q - np.einsum("...ij,...j->...i", Phi_tilde, mu_p)

    # ∂Φ̃_a = Q_a Φ̃₀ e^{-φ̃}
    dPhi = np.einsum("...aik,...kj,...jl->...ail", Q_all, Phi_tilde_0, exp_neg_phi_tilde)
    dPhi_T = np.swapaxes(dPhi, -1, -2)

    dA = (
        np.einsum("...aik,...kl,...lj->...aij", dPhi, sigma_p, Phi_tilde_T) +
        np.einsum("...ik,...kl,...alj->...aij", Phi_tilde, sigma_p, dPhi_T)
    )

    # Term 1
    dPhi_mu_p = np.einsum("...aij,...j->...ai", dPhi, mu_p)
    term1 = -np.einsum("...ai,...i->...a", dPhi_mu_p, np.einsum("...ij,...j->...i", A_inv, delta_mu))

    # Term 2   (note: your earlier self/feedback sign conventions differ; keeping your current one)
    term2 = 0.5 * np.einsum("...ij,...aij->...a", A_inv, dA)

    # M = A^{-1} dA A^{-1}
    M = np.einsum("...ij,...ajk,...kl->...ail", A_inv, dA, A_inv)

    # Term 3
    term3 = -0.5 * np.einsum("...i,...aij,...j->...a", delta_mu, M, delta_mu)

    # Term 4
    term4 = -0.5 * np.einsum("...aij,...ji->...a", M, sigma_q)

    grad = term1 + term2 + term3 + term4
    return grad


def grad_self_phi_tilde_direct(
    mu_q, sigma_q,
    mu_p, sigma_p,
    Phi_tilde_0,
    phi, phi_tilde,
    generators_q, generators_p,
    exp_phi, exp_phi_tilde,
    eps=1e-8,
    # NEW optional precomputes:
    Q_tilde_all=None,         # (..., d, K_p, K_p)
    exp_neg_phi_tilde=None    # (..., K_p, K_p)
):
    """
    Vectorized over 'a': returns (..., d)
    Right-trivialize on model: R_a = (∂e^{φ̃}/∂φ̃^a) e^{-φ̃},  ∂Φ̃_a = - Φ̃ R_a.
    """
    d, K_p, _ = generators_p.shape
    
    if exp_neg_phi_tilde is None:
        exp_neg_phi_tilde = safe_omega_inv(exp_phi_tilde, eps=eps, debug=False)
    if Q_tilde_all is None:
        Q_list = d_exp_phi_tilde_exact(phi_tilde, generators_p)
        Q_tilde_all = np.stack(Q_list, axis=-3)

    Phi_tilde = np.einsum("...ik,...kj,...jl->...il", exp_phi, Phi_tilde_0, exp_neg_phi_tilde)
    Phi_tilde_T = np.swapaxes(Phi_tilde, -1, -2)

    
    A = np.einsum("...ik,...kl,...lj->...ij", Phi_tilde, sigma_p, Phi_tilde_T)
    A = sanitize_sigma(A, eps=eps)
    A_inv = safe_inv(A, eps=eps)

    mu_t = np.einsum("...ij,...j->...i", Phi_tilde, mu_p)
    delta_mu = mu_q - mu_t

    # R_a = Q̃_a e^{-φ̃}
    R = np.einsum("...aik,...kj->...aij", Q_tilde_all, exp_neg_phi_tilde)

    # dΦ̃_a = - Φ̃ R_a
    dPhi = -np.einsum("...ik,...akj->...aij", Phi_tilde, R)
    dPhi_T = np.swapaxes(dPhi, -1, -2)

    dA = (
        np.einsum("...aik,...kl,...lj->...aij", dPhi, sigma_p, Phi_tilde_T) +
        np.einsum("...ik,...kl,...alj->...aij", Phi_tilde, sigma_p, dPhi_T)
    )

    dPhi_mu_p = np.einsum("...aij,...j->...ai", dPhi, mu_p)
    term1 = -np.einsum("...ai,...i->...a", dPhi_mu_p, np.einsum("...ij,...j->...i", A_inv, delta_mu))

    term2 = 0.5 * np.einsum("...ij,...aij->...a", A_inv, dA)

    M = np.einsum("...ij,...ajk,...kl->...ail", A_inv, dA, A_inv)

    term3 = -0.5 * np.einsum("...i,...aij,...j->...a", delta_mu, M, delta_mu)
    term4 = -0.5 * np.einsum("...aij,...ji->...a", M, sigma_q)

    grad = term1 + term2 + term3 + term4
    return grad

# ---------------------------------------------------------------------------
# φ / φ̃ cross-scale "environment" terms (Λ and Θ, up & down)
# ---------------------------------------------------------------------------
def accumulate_crossscale_phi_env(
    agent_i,
    *,
    generators_q,
    generators_p,
    params,
):
    """
    Add φ/φ̃ env grads for cross-scale interactions:
      - belief (φ):    use Λ on q (same-fiber) and Θ.q (p→q) from parents/children
      - model  (φ̃):   use Λ on p (same-fiber) and Θ.p (q→p) from parents/children

    Each path has an independent weight; all default to 0.0 (no behavior change).
    """
  
    from bundle_morphism_utils import pushforward_gaussian as _push_gauss

    ctx = params.get("runtime_ctx", None)

    # --- weights (separate Λ vs Θ, down vs up) -------------------------------
    # φ (belief; q-fiber)
    lam_dn_q      = float(params.get("lambda_phi_env_down_q",       getattr(config, "lambda_phi_env_down_q",       0.0)))
    lam_up_q      = float(params.get("lambda_phi_env_up_q",         getattr(config, "lambda_phi_env_up_q",         0.0)))
    lam_dn_theta_q= float(params.get("lambda_phi_env_down_theta_q", getattr(config, "lambda_phi_env_down_theta_q", 0.0)))
    lam_up_theta_q= float(params.get("lambda_phi_env_up_theta_q",   getattr(config, "lambda_phi_env_up_theta_q",   0.0)))
    # φ̃ (model; p-fiber)
    lam_dn_p      = float(params.get("lambda_phi_env_down_p",       getattr(config, "lambda_phi_env_down_p",       0.0)))
    lam_up_p      = float(params.get("lambda_phi_env_up_p",         getattr(config, "lambda_phi_env_up_p",         0.0)))
    lam_dn_theta_p= float(params.get("lambda_phi_env_down_theta_p", getattr(config, "lambda_phi_env_down_theta_p", 0.0)))
    lam_up_theta_p= float(params.get("lambda_phi_env_up_theta_p",   getattr(config, "lambda_phi_env_up_theta_p",   0.0)))

    # quick exit if all zero
    if max(lam_dn_q, lam_up_q, lam_dn_theta_q, lam_up_theta_q,
           lam_dn_p, lam_up_p, lam_dn_theta_p, lam_up_theta_p) == 0.0:
        return

    # --- basic fields & masks ------------------------------------------------
    eps_tau = float(getattr(config, "support_cutoff_eps", 1e-6))
    mask_i  = (np.asarray(agent_i.mask) > eps_tau)[..., None]

    mu_q_i, Si_q_i = agent_i.mu_q_field, agent_i.sigma_q_field
    mu_p_i, Si_p_i = agent_i.mu_p_field, agent_i.sigma_p_field

    # exp grids (for Ω = E_i E_j^{-1}); for cross-scale we set E_j = I so Ω=E_i
    E_q_i = E_grid(ctx, agent_i, which="q") if ctx is not None else None
    E_p_i = E_grid(ctx, agent_i, which="p") if ctx is not None else None

    # Jacobians
    Q_all_q = d_exp_phi_exact(np.asarray(agent_i.phi,       np.float32), generators_q)
    Q_all_p = d_exp_phi_tilde_exact(np.asarray(agent_i.phi_model, np.float32), generators_p)

    def _sigma_inv(S):
        S = sanitize_sigma(np.asarray(S, np.float32), eps=float(getattr(config, "eps", 1e-6)))
        return safe_inv(S, eps=float(getattr(config, "eps", 1e-6)))

    # Ω, E_j, exp(-φ_j) choices for cross-scale:
    # we already feed μ_t and Σ_t^{-1}, so we can take:
    #   Ω_ij = E_i,  E_j = I,  exp(-φ_j) = I
    def _phi_env_grad_q(mu_t, Si_t_inv):
        Omega_ij   = E_q_i if E_q_i is not None else np.eye(Si_q_i.shape[-1], dtype=np.float32)
        exp_phi_i  = Omega_ij
        exp_phi_j  = np.eye(Si_q_i.shape[-1], dtype=np.float32)
        exp_neg_j  = exp_phi_j  # I
        return grad_kl_wrt_phi_i(
            mu_i=mu_q_i, sigma_i=Si_q_i,
            mu_j=None, sigma_j=None,
            phi_i=np.asarray(agent_i.phi, np.float32), phi_j=None,
            Omega_ij=Omega_ij,
            generators=generators_q,
            exp_phi_i=exp_phi_i, exp_phi_j=exp_phi_j,
            mu_j_t=mu_t, sigma_j_t_inv=Si_t_inv,
            eps=float(getattr(config, "eps", 1e-6)),
            exp_neg_phi_j=exp_neg_j,
            Q_all=Q_all_q,
        )

    def _phi_env_grad_p(mu_t, Si_t_inv):
        Omega_ij   = E_p_i if E_p_i is not None else np.eye(Si_p_i.shape[-1], dtype=np.float32)
        exp_phi_i  = Omega_ij
        exp_phi_j  = np.eye(Si_p_i.shape[-1], dtype=np.float32)
        exp_neg_j  = exp_phi_j
        return grad_kl_wrt_phi_i(
            mu_i=mu_p_i, sigma_i=Si_p_i,
            mu_j=None, sigma_j=None,
            phi_i=np.asarray(agent_i.phi_model, np.float32), phi_j=None,
            Omega_ij=Omega_ij,
            generators=generators_p,
            exp_phi_i=exp_phi_i, exp_phi_j=exp_phi_j,
            mu_j_t=mu_t, sigma_j_t_inv=Si_t_inv,
            eps=float(getattr(config, "eps", 1e-6)),
            exp_neg_phi_j=exp_neg_j,
            Q_all=Q_all_p,
        )

    # ----- collect hierarchy from ctx or agent (same approach as μ/Σ) --------
    parents  = []
    children = []
    if ctx is not None:
        aid = int(getattr(agent_i, "id", -1))
        parents  = list((getattr(ctx, "parents_for_agent", {}) or {}).get(aid, []))
        children = list((getattr(ctx, "children_for_agent", {}) or {}).get(aid, []))
    else:
        parents  = list(getattr(agent_i, "parents",  [])) if hasattr(agent_i, "parents")  else []
        children = list(getattr(agent_i, "children", [])) if hasattr(agent_i, "children") else []

    # ========================= DOWNWARD: parents → i ==========================
    for P in parents:
        # Λ↓ on q (parent q → child q) → φ env on q
        if lam_dn_q != 0.0:
            Lq = Lambda_dn(ctx, agent_i, P, which="q")
            mu_q_t, Si_q_t, _ = _push_gauss(getattr(P, "mu_q_field"), getattr(P, "sigma_q_field"), Lq)
            g = _phi_env_grad_q(mu_q_t, _sigma_inv(Si_q_t))
            agent_i.grad_phi = (getattr(agent_i, "grad_phi", 0.0) + lam_dn_q * g * mask_i).astype(np.float32, copy=False)
            # --- debug print
            
         #   print(f"[Λ↓_q φ] child {getattr(agent_i,'id',-1)} <- parent {getattr(P,'id',-1)} "
          #        f"λ={lam_dn_q:.3f} ‖grad‖={np.linalg.norm(g):.3e}\n")

        # Θ↓.q (parent p → child q) → φ env on q
        if lam_dn_theta_q != 0.0:
            Th_q = Theta_dn(ctx, agent_i, P)["q"]
            mu_qp, Si_qp, _ = _push_gauss(getattr(P, "mu_p_field"), getattr(P, "sigma_p_field"), Th_q)
            g = _phi_env_grad_q(mu_qp, _sigma_inv(Si_qp))
            agent_i.grad_phi = (getattr(agent_i, "grad_phi", 0.0) + lam_dn_theta_q * g * mask_i).astype(np.float32, copy=False)
            # --- debug print
            
           # print(f"[Θ↓_q φ] child {getattr(agent_i,'id',-1)} <- parent {getattr(P,'id',-1)} "
           #       f"λ={lam_dn_theta_q:.3f} ‖grad‖={np.linalg.norm(g):.3e}\n")

        # Λ↓ on p (parent p → child p) → φ̃ env
        if lam_dn_p != 0.0:
            Lp = Lambda_dn(ctx, agent_i, P, which="p")
            mu_p_t, Si_p_t, _ = _push_gauss(getattr(P, "mu_p_field"), getattr(P, "sigma_p_field"), Lp)
            g = _phi_env_grad_p(mu_p_t, _sigma_inv(Si_p_t))
            agent_i.grad_phi_tilde = (getattr(agent_i, "grad_phi_tilde", 0.0) + lam_dn_p * g * mask_i).astype(np.float32, copy=False)
            # --- debug print
            
         #   print(f"[Λ↓_p φ̃] child {getattr(agent_i,'id',-1)} <- parent {getattr(P,'id',-1)} "
         #         f"λ={lam_dn_p:.3f} ‖grad‖={np.linalg.norm(g):.3e}\n")

        # Θ↓.p (parent q → child p) → φ̃ env
        if lam_dn_theta_p != 0.0:
            Th_p = Theta_dn(ctx, agent_i, P)["p"]
            mu_pp, Si_pp, _ = _push_gauss(getattr(P, "mu_q_field"), getattr(P, "sigma_q_field"), Th_p)
            g = _phi_env_grad_p(mu_pp, _sigma_inv(Si_pp))
            agent_i.grad_phi_tilde = (getattr(agent_i, "grad_phi_tilde", 0.0) + lam_dn_theta_p * g * mask_i).astype(np.float32, copy=False)
            # --- debug print
           
         #   print(f"[Θ↓_p φ̃] child {getattr(agent_i,'id',-1)} <- parent {getattr(P,'id',-1)} "
         #         f"λ={lam_dn_theta_p:.3f} ‖grad‖={np.linalg.norm(g):.3e}\n\n\n")

    # ========================== UPWARD: children → i ==========================
    for C in children:
        # Λ↑ on q (child q → parent q) → φ env on q
        if lam_up_q != 0.0:
            Lq = Lambda_up(ctx, C, agent_i, which="q")
            mu_q_t, Si_q_t, _ = _push_gauss(getattr(C, "mu_q_field"), getattr(C, "sigma_q_field"), Lq)
            g = _phi_env_grad_q(mu_q_t, _sigma_inv(Si_q_t))
            agent_i.grad_phi = (getattr(agent_i, "grad_phi", 0.0) + lam_up_q * g * mask_i).astype(np.float32, copy=False)

        # Θ↑.q (child p → parent q) → φ env on q
        if lam_up_theta_q != 0.0:
            Th_q = Theta_up(ctx, C, agent_i)["q"]
            mu_qp, Si_qp, _ = _push_gauss(getattr(C, "mu_p_field"), getattr(C, "sigma_p_field"), Th_q)
            g = _phi_env_grad_q(mu_qp, _sigma_inv(Si_qp))
            agent_i.grad_phi = (getattr(agent_i, "grad_phi", 0.0) + lam_up_theta_q * g * mask_i).astype(np.float32, copy=False)

        # Λ↑ on p (child p → parent p) → φ̃ env
        if lam_up_p != 0.0:
            Lp = Lambda_up(ctx, C, agent_i, which="p")
            mu_p_t, Si_p_t, _ = _push_gauss(getattr(C, "mu_p_field"), getattr(C, "sigma_p_field"), Lp)
            g = _phi_env_grad_p(mu_p_t, _sigma_inv(Si_p_t))
            agent_i.grad_phi_tilde = (getattr(agent_i, "grad_phi_tilde", 0.0) + lam_up_p * g * mask_i).astype(np.float32, copy=False)

        # Θ↑.p (child q → parent p) → φ̃ env
        if lam_up_theta_p != 0.0:
            Th_p = Theta_up(ctx, C, agent_i)["p"]
            mu_pp, Si_pp, _ = _push_gauss(getattr(C, "mu_q_field"), getattr(C, "sigma_q_field"), Th_p)
            g = _phi_env_grad_p(mu_pp, _sigma_inv(Si_pp))
            agent_i.grad_phi_tilde = (getattr(agent_i, "grad_phi_tilde", 0.0) + lam_up_theta_p * g * mask_i).astype(np.float32, copy=False)


# =========================
# Regularization (with toggleable φ–φ̃ coupling)
# =========================
def apply_regularization_terms_lie_natural(
    agent,
    phi_field,
    generators,
    field,
    params,
    agents=None,
    eps=1e-8,
    *,
    ctx=None,
):
    """
    Natural regularizers for a Lie-algebra field (φ or φ̃).

    Weights come from `params` with config fallbacks.
    - Curvature:    ∂/∂φ  ||F(φ)||^2
    - Fisher geom:  ∇ from compute_fisher_geometry_gradient(...)
    - Mass:         λ * φ
    - Coupling:     λ_cpl * || φ_p - C φ_q ||^2 with dexp^{-1} back to algebra
    """
    import numpy as np

    grad_nat = np.zeros_like(phi_field, dtype=np.float32)

    # weights (params override config)
    curv_w   = float(params.get("curvature_weight", 0.0))
    fisher_w = float(params.get("fisher_geometry_weight", 0.0))
    mass_w   = float(params.get("mass_weight", 0.0))
    cpl_w    = float(params.get("phi_coupling_weight", 0.0))

    if field == "phi":
        curv_w   = float(getattr(config, "curvature_weight", curv_w))
        fisher_w = float(getattr(config, "fisher_geometry_weight", fisher_w))
        mass_w   = float(getattr(config, "belief_mass", mass_w))
        cpl_w    = float(getattr(config, "phi_coupling_weight", cpl_w))
        gen_q = generators
        gen_p = getattr(agent, "generators_p", None)
    elif field == "phi_model":
        curv_w   = float(getattr(config, "model_curvature_weight", curv_w))
        fisher_w = float(getattr(config, "fisher_model_geometry_weight", fisher_w))
        mass_w   = float(getattr(config, "model_mass", mass_w))
        cpl_w    = float(getattr(config, "phi_coupling_weight", cpl_w))
        gen_p = generators
        gen_q = getattr(agent, "generators_q", None)
    else:
        raise ValueError(f"Invalid field: {field}")

    # early exit
    if (curv_w == 0.0) and (fisher_w == 0.0) and (mass_w == 0.0) and (cpl_w == 0.0):
        return grad_nat

    # curvature term
    if curv_w > 0.0:
        grad_nat += curv_w * compute_curvature_gradient_analytical(
            np.asarray(phi_field, np.float32), generators
        )

    # Fisher-geometry term (explicit ctx + optional step tag)
    if fisher_w > 0.0 and agents is not None:
        step_tag = params.get("step_tag", getattr(ctx, "global_step", None) if ctx is not None else None)
        grad_nat += fisher_w * compute_fisher_geometry_gradient(
            agent, agents, params, field=field, step_tag=step_tag, ctx=ctx
        )

    # mass term
    if mass_w > 0.0:
        grad_nat += mass_w * np.asarray(phi_field, np.float32)

    # q↔p coupling (no per-agent cache; compute mapping on the fly)
    # q↔p coupling
    if cpl_w > 0.0:
        try:
            C = _build_c_mapping_q2p(
                getattr(agent, "Phi_tilde_0", None),
                gen_q, gen_p, eps=eps,
            )
            phi_q = np.asarray(getattr(agent, "phi", None), np.float32)
            phi_p = np.asarray(getattr(agent, "phi_model", None), np.float32)
            if phi_q is None or phi_p is None or C is None:
                raise RuntimeError("Missing fields for coupling term")

            r = phi_p - np.einsum("ab,...b->...a", C, phi_q, optimize=True)

            if field == "phi":
                g_eucl = -np.einsum("ab,...b->...a", C.T, r, optimize=True)
                # map to NATURAL via Jinv(phi_q)
                Jinv_q = Jinv_grid(ctx, agent, which="q") if ctx is not None else None
                if Jinv_q is None:
                    from transport_cache import build_dexpinv_matrix
                    Jinv_q = build_dexpinv_matrix(phi_q)
                grad_nat += cpl_w * np.einsum("...ab,...b->...a", Jinv_q, g_eucl, optimize=True)
            else:
                Jinv_p = Jinv_grid(ctx, agent, which="p") if ctx is not None else None
                if Jinv_p is None:
                    from transport_cache import build_dexpinv_matrix
                    Jinv_p = build_dexpinv_matrix(phi_p)
                grad_nat += cpl_w * np.einsum("...ab,...b->...a", Jinv_p, r, optimize=True)
        except Exception:
            pass


    return np.nan_to_num(grad_nat, nan=0.0, posinf=0.0, neginf=0.0).astype(np.float32, copy=False)





# =========================
# Helpers (cached, lightweight)
# =========================

def _algebra_matrix_from_coeffs(phi_coeffs, generators):
    """
    phi_coeffs: (..., d)
    generators: (d, K, K)
    returns: (..., K, K) matrix in the algebra
    """
    # sum_a phi^a G^a
    # reshape phi to broadcast over K,K
    return np.einsum("...a,aij->...ij", phi_coeffs, generators)


def _gram_inv_cached(agent, key_name, generators, eps=1e-8):
    """
    Cache and return Gram^{-1} for the given generator set under Frobenius inner product.
    key_name: str attribute name on agent (e.g., "_Gram_q_inv" / "_Gram_p_inv")
    """
    G_inv = getattr(agent, key_name, None)
    if G_inv is not None:
        return G_inv
    d = generators.shape[0]
    Gram = np.empty((d, d), dtype=generators.dtype)
    for a in range(d):
        for b in range(d):
            Gram[a, b] = np.tensordot(generators[a], generators[b])
    Gram += eps * np.eye(d, dtype=Gram.dtype)
    G_inv = safe_inv(Gram)
    setattr(agent, key_name, G_inv)
    return G_inv


def _project_mat_to_algebra_coeffs(M, generators, G_inv):
    """
    Project matrix M (..., K, K) to algebra coefficients (..., d)
    by solving coeffs = G_inv @ h, where h_b = <G^b, M>_F.
    """
    d = generators.shape[0]
    # h_b = tr((G^b)^T M)
    h = np.stack([np.tensordot(generators[b], M) for b in range(d)], axis=-1)
    # coeffs = h @ G_inv^T (since last dim is basis index)
    # both ways are fine; using right-multiply for (..., d)
    coeffs = np.einsum("...b,bc->...c", h, G_inv)
    return coeffs


# --- helper: build C once and cache on agent ---
def _build_c_mapping_q2p(Phi_tilde_0, generators_q, generators_p, eps=1e-8):
    """
    Build linear map C (d_p x d_q) so that Ad_{Phi_tilde_0}(G_q^a) ≈ sum_b C_{ba} G_p^b,
    using Frobenius inner-product projection onto p-basis.
    """
    d_q, Kq, _ = generators_q.shape
    d_p, Kp, _ = generators_p.shape
    assert Phi_tilde_0.shape[-2:] == (Kq, Kp), "Phi_tilde_0 must be (K_q, K_p)"

    # Gram matrix of p-basis under Frobenius product
    Gp = np.zeros((d_p, d_p), dtype=generators_p.dtype)
    for b in range(d_p):
        for c in range(d_p):
            Gp[b, c] = np.tensordot(generators_p[b], generators_p[c])
    Gp += eps * np.eye(d_p, dtype=Gp.dtype)
    Gp_inv = safe_inv(Gp)

    # Conjugate each q-generator: H_a = Phi0 G_q^a Phi0^{-1}
    Phi0    = Phi_tilde_0
    Phi0_inv = safe_inv(Phi0, eps=eps)

    C = np.zeros((d_p, d_q), dtype=generators_p.dtype)
    for a in range(d_q):
        H_a = np.einsum("ik,kl,lj->ij", Phi0, generators_q[a], Phi0_inv)
        h = np.array([np.tensordot(generators_p[b], H_a) for b in range(d_p)], dtype=H_a.dtype)
        C[:, a] = Gp_inv @ h
    return C


