# -*- coding: utf-8 -*-
"""
Created on Mon Aug 11 10:07:56 2025

@author: chris and christine
"""
import numpy as np
from numerical_utils import sanitize_sigma, safe_inv, safe_logdet
from typing import Optional, Tuple
from omega import exp_lie_algebra_irrep
import config

from omega import omega_field_cached  # central-cache Ω wrapper



def push_mu_sigma_exact(mu: np.ndarray, Sigma: np.ndarray, L: np.ndarray):
    """
    Exact pushforward of Gaussian moments through linear map x' = L x.
    mu:    (T, K)
    Sigma: (T, K, K)
    L:     (T, K, K)
    Returns:
      (mu', Sigma') with shapes (T, K), (T, K, K)
    """
    # μ' = L μ
    mu_p = (L @ mu[..., None])[..., 0]
    # Σ' = L Σ L^T   (vectorized via einsum)
    Sig_p = np.einsum("tij, tjk, tlk -> til", L, Sigma, L, optimize=True)
    return mu_p, Sig_p


def push_mu_sigma_first_order(mu: np.ndarray, Sigma: np.ndarray, L: np.ndarray):
    """
    First-order push for near-identity L = I + A (small A):
      μ'   ≈ μ + A μ
      Σ'   ≈ Σ + A Σ + Σ A^T
    Shapes like the exact version.
    """
    T, K = mu.shape
    I = np.eye(K, dtype=L.dtype)
    A = L - I
    mu_p = mu + (A @ mu[..., None])[..., 0]
    # A Σ + Σ A^T
    A_S  = np.einsum("tij, tjk -> tik", A, Sigma, optimize=True)
    S_AT = np.einsum("tij, tik -> tjk", A, Sigma, optimize=True)  # (A Σ)^T wrt last two dims
    Sig_p = Sigma + A_S + np.swapaxes(S_AT, -1, -2)
    return mu_p, Sig_p



def kl_gaussians(mu1, S1, mu2, S2, eps=1e-6):
    """KL(N(μ1,Σ1) || N(μ2,Σ2)) — batch-safe, no fragile squeezes."""
    S1 = sanitize_sigma(S1, eps=eps)
    S2 = sanitize_sigma(S2, eps=eps)
    K = S1.shape[-1]
    S2_inv = safe_inv(S2, eps=eps)
    dmu = (mu2 - mu1)                                       # (..., K)
    term_trace = np.einsum('...ij,...ji->...', S2_inv, S1)  # tr(S2^{-1} Σ1)
    term_quad  = np.einsum('...i,...ij,...j->...', dmu, S2_inv, dmu)  # (μ2-μ1)^T S2^{-1} (μ2-μ1)
    s1, logdet1 = np.linalg.slogdet(S1)
    s2, logdet2 = np.linalg.slogdet(S2)
    logdet_ratio = logdet2 - logdet1
    return 0.5 * (term_trace + term_quad - K + logdet_ratio)





def _overlap_pairs(children, H, W, *, tau=0.10, min_pair_px=8):
    """
    Return list of (i,j, overlap_bool_mask) for child pairs whose supports overlap.
    Uses (mask > tau) as support for overlap detection.
    """
    Ms_bool = [(np.asarray(c.mask, np.float32) > float(tau)) for c in children]
    pairs = []
    n = len(children)
    for i in range(n):
        mi = Ms_bool[i]
        if not mi.any(): continue
        for j in range(i+1, n):
            ov = (mi & Ms_bool[j])
            if int(ov.sum()) >= int(min_pair_px):
                pairs.append((i, j, ov))
    return pairs


def curvature_boltzmann_from_children(
    children, H, W, *, gamma=0.0, fiber="q", curvature_map=None,
    ctx: Optional[object] = None, G: Optional[np.ndarray] = None
):
    """
    Build BF(x) = exp(-gamma * F(x)).
    If curvature_map given, use it. Else compute F from compute_field_strength(phi, G).
    """
    if float(gamma) <= 0.0:
        return None

    if curvature_map is not None:
        F = np.asarray(curvature_map, np.float32)
        if F.shape == (H, W):
            return np.exp(-float(gamma) * np.clip(F, 0.0, np.finfo(np.float32).max)).astype(np.float32)

    try:
        from omega import compute_field_strength
    except Exception:
        return None  # fail-open

    # Require generators if we need to compute F; don't read from agents
    if G is None:
        return None

    num = np.zeros((H, W), np.float32)
    den = np.zeros((H, W), np.float32)
    phi_name = "phi" if str(fiber) == "q" else "phi_model"

    for c in children:
        m = np.asarray(getattr(c, "mask", 0.0), np.float32)
        if m.shape[:2] != (H, W) or float(m.max()) <= 0.0:
            continue
        phi = getattr(c, phi_name, None)
        if phi is None:
            continue
        Fdict = compute_field_strength(np.asarray(phi, np.float32), np.asarray(G, np.float32))
        Fxy = np.asarray(Fdict.get("xy", 0.0), np.float32)  # (H,W,K,K)
        if Fxy.shape[:2] != (H, W):
            continue
        Fx = np.sqrt(np.clip(np.sum(Fxy * Fxy, axis=(-2, -1)), 0.0, np.finfo(np.float32).max)).astype(np.float32)
        num += (m * Fx)
        den += np.maximum(m, 0.0)

    F = np.zeros((H, W), np.float32)
    sel = den > 1e-6
    F[sel] = (num[sel] / np.maximum(den[sel], 1e-6)).astype(np.float32)
    return np.exp(-float(gamma) * np.clip(F, 0.0, np.finfo(np.float32).max)).astype(np.float32)






def directed_kl_weight_after_transport(
    Ai, Aj,
    mu_i, S_i, mu_j, S_j,
    *,
    fiber, H, W, K, ov, tau,
    assume_diag_is_stddev: bool = True,
    debug: bool = False,
    ctx: Optional[object] = None,   # CacheHub entry point
    G: Optional[np.ndarray] = None, # <-- NEW: irrep generators (K×K stack expected by omega_field_cached)
):
    """
    w(x) = exp(- KL( N_i || T_{j->i}(N_j) ) / tau ) on overlap 'ov'.
    Transport is Ω_ij = exp(φ_i) · exp(−φ_j) on 'q' or 'p' fiber.
    Uses ctx.transport_cache for both exp-grids and Ω fields.
    """
    if not np.any(ov):
        return np.zeros((H, W), np.float32)

    # --- eps, overlap indices
    eps_log = float(getattr(config, "log_eps", 1e-8))
    iy, ix = np.nonzero(ov)

    # Slice means/covs on overlap (accept diagonal Σ as stddev if requested)
    mui = np.asarray(mu_i, np.float32)[iy, ix]            # (M, K)
    muj = np.asarray(mu_j, np.float32)[iy, ix]            # (M, K)

    Si  = np.asarray(S_i,  np.float32)[iy, ix]            # (M, K,K) or (M,K)
    Sj  = np.asarray(S_j,  np.float32)[iy, ix]

    if Si.ndim == 2:  # diagonal
        diag = Si if not assume_diag_is_stddev else Si * Si
        Si = np.einsum("mk,ij->mij", diag, np.eye(K, dtype=np.float32), optimize=True)
    if Sj.ndim == 2:
        diag = Sj if not assume_diag_is_stddev else Sj * Sj
        Sj = np.einsum("mk,ij->mij", diag, np.eye(K, dtype=np.float32), optimize=True)

    # Sanitize (SPD) before transport
    Si = sanitize_sigma(Si, eps=eps_log)
    Sj = sanitize_sigma(Sj, eps=eps_log)

    # --- choose φ fields
    if fiber == "q":
        phi_i_full = np.asarray(Ai.phi,       np.float32)
        phi_j_full = np.asarray(Aj.phi,       np.float32)
    else:
        phi_i_full = np.asarray(Ai.phi_model, np.float32)
        phi_j_full = np.asarray(Aj.phi_model, np.float32)

    # --- require generators via arg (no per-agent fallback)
    if G is None:
        raise ValueError("directed_kl_weight_after_transport: missing G (generators) for fiber "
                         f"'{fiber}' with K={K}")

    # Warm exp-grids for stability/perf, then pull Ω via ctx-aware cache
    if ctx is not None:
        try:
            from transport_cache import warm_E
            warm_E(ctx, [Ai, Aj], whiches=(fiber,))
        except Exception:
            pass

    Omega_full = omega_field_cached(ctx, phi_i_full, phi_j_full, np.asarray(G, np.float32),
                                    group=getattr(config, "group_name", "so3"),
                                    invert_j=False)
    Omega_ij   = Omega_full[iy, ix]  # (M, K, K)

    if debug:
        RtR = np.einsum("mab,mac->mbc", Omega_ij, Omega_ij, optimize=True)
        I   = np.broadcast_to(np.eye(K, dtype=np.float32), RtR.shape)
        dev = np.max(np.abs(RtR - I))
        if dev > 1e-4:
            print(f"[DKL] non-orthogonal Ω on fiber='{fiber}' (max dev {dev:.2e})")

    # --- transport j → i on overlap
    muj_t = np.einsum("mab,mb->ma", Omega_ij, muj, optimize=True)
    OmT   = np.swapaxes(Omega_ij, -1, -2)
    Sj_t  = np.einsum("mab,mbc,mdc->mad", Omega_ij, Sj, OmT, optimize=True)
    Sj_t  = sanitize_sigma(Sj_t, eps=eps_log)

    # --- per-pixel KL and weights
    d = kl_gaussians(mui, Si, muj_t, Sj_t, eps=eps_log).astype(np.float32)  # (M,)
    d = np.clip(np.nan_to_num(d, nan=0.0, posinf=1e6, neginf=0.0), 0.0, 1e6)

    invT = 1.0 / max(1e-8, float(tau))
    wvec = np.exp(-d * invT).astype(np.float32)

    w = np.zeros((H, W), np.float32)
    w[iy, ix] = wvec
    return w


def blended_spawn_metrics_child_vs_parents(
    ctx, child, parents, *, Gq=None, Gp=None,
    tau_q=0.45, tau_p=0.45, alpha=0.5, sm_tau=0.40, mask_tau=1e-3
):
    """
    Compute spawn caches for a child against many parents using
    omega_child_to_parents_batched (overlap-cropped, batched Ω).
    Returns dict with HxW fields:
      nb_count, min_kl_q/p, softmin_kl_q/p, cover_weight, A_final, KL_blend
    """
    import numpy as np
    import config as _cfg
    from transport_cache import omega_child_to_parents_batched

    from gaussian_core import kl_gaussians as _kl_field
    

    def _sanitize_sigma(S):
        try:
            from numerical_utils import sanitize_sigma as _ss
            return _ss(S, eps=float(getattr(_cfg, "log_eps", 1e-8)))
        except Exception:
            try:
                from numerical_utils import project_spd as _proj
                return _proj(S, eps=float(getattr(_cfg, "log_eps", 1e-8)))
            except Exception:
                return S

    # --- shapes & init ------------------------------------------------------------
    H, W = np.asarray(child.mask, np.float32).shape[:2]
    present_i   = (np.asarray(child.mask, np.float32) > float(mask_tau))
    nb_count     = np.zeros((H, W), np.int32)
    min_kl_q     = np.full((H, W), np.inf, np.float32)
    min_kl_p     = np.full((H, W), np.inf, np.float32)
    sumexp_q     = np.zeros((H, W), np.float32)
    sumexp_p     = np.zeros((H, W), np.float32)
    cover_weight = np.zeros((H, W), np.float32)
    tiny = 1e-9

    # child fields / availability
    mu_q_i = getattr(child, "mu_q_field", None)
    sg_q_i = getattr(child, "sigma_q_field", None)
    mu_p_i = getattr(child, "mu_p_field", None)
    sg_p_i = getattr(child, "sigma_p_field", None)
    have_q = (mu_q_i is not None) and (sg_q_i is not None) and (Gq is not None)
    have_p = (mu_p_i is not None) and (sg_p_i is not None) and (Gp is not None)

    # quick parent id map
    id2p = {int(getattr(p, "id", -1)): p for p in (parents or []) if p is not None}

    # --- Q fiber (batched Ω with overlap bboxes) ----------------------------------
    if have_q:
        packs_q = omega_child_to_parents_batched(ctx, child, parents, Gq, invert_j=True, mask_tau=mask_tau)
        for pid, (y0, y1, x0, x1), Ω in packs_q:
            p = id2p.get(int(pid))
            if p is None:
                continue
            jmask = np.asarray(getattr(p, "mask", 0.0), np.float32)[y0:y1, x0:x1]
            valid = present_i[y0:y1, x0:x1] & (jmask > float(mask_tau))
            if not np.any(valid):
                continue
            vy, vx = np.nonzero(valid)

            mu_i_win = np.asarray(mu_q_i, np.float32)[y0:y1, x0:x1, :]          # (h,w,K)
            S_i_win  = np.asarray(sg_q_i, np.float32)[y0:y1, x0:x1, :, :]
            mu_j_win = np.asarray(getattr(p, "mu_q_field"), np.float32)[y0:y1, x0:x1, :]
            S_j_win  = np.asarray(getattr(p, "sigma_q_field"), np.float32)[y0:y1, x0:x1, :, :]

            muj_t = np.einsum("...ab,...b->...a", Ω, mu_j_win, optimize=True)
            ΩT    = np.swapaxes(Ω, -1, -2)
            Sj_t  = np.einsum("...ab,...bc,...dc->...ad", Ω, S_j_win, ΩT, optimize=True)
            Sj_t  = _sanitize_sigma(Sj_t)

            kq_win = _kl_field(mu_i_win, S_i_win, muj_t, Sj_t).astype(np.float32)  # (h,w)

            np.add.at(nb_count[y0:y1, x0:x1], (vy, vx), 1)
            np.minimum.at(min_kl_q[y0:y1, x0:x1], (vy, vx), kq_win[vy, vx])
            np.add.at(sumexp_q[y0:y1, x0:x1], (vy, vx),
                      np.exp(-kq_win[vy, vx] / max(sm_tau, tiny)).astype(np.float32))
            np.add.at(cover_weight[y0:y1, x0:x1], (vy, vx), jmask[vy, vx])

    # --- P fiber (batched Ω with overlap bboxes) ----------------------------------
    if have_p:
        packs_p = omega_child_to_parents_batched(ctx, child, parents, Gp, invert_j=True, mask_tau=mask_tau)
        for pid, (y0, y1, x0, x1), Ω in packs_p:
            p = id2p.get(int(pid))
            if p is None:
                continue
            jmask = np.asarray(getattr(p, "mask", 0.0), np.float32)[y0:y1, x0:x1]
            valid = present_i[y0:y1, x0:x1] & (jmask > float(mask_tau))
            if not np.any(valid):
                continue
            vy, vx = np.nonzero(valid)

            mu_i_win = np.asarray(mu_p_i, np.float32)[y0:y1, x0:x1, :]
            S_i_win  = np.asarray(sg_p_i, np.float32)[y0:y1, x0:x1, :, :]
            mu_j_win = np.asarray(getattr(p, "mu_p_field"), np.float32)[y0:y1, x0:x1, :]
            S_j_win  = np.asarray(getattr(p, "sigma_p_field"), np.float32)[y0:y1, x0:x1, :, :]

            muj_t = np.einsum("...ab,...b->...a", Ω, mu_j_win, optimize=True)
            ΩT    = np.swapaxes(Ω, -1, -2)
            Sj_t  = np.einsum("...ab,...bc,...dc->...ad", Ω, S_j_win, ΩT, optimize=True)
            Sj_t  = _sanitize_sigma(Sj_t)

            kp_win = _kl_field(mu_i_win, S_i_win, muj_t, Sj_t).astype(np.float32)

            np.add.at(nb_count[y0:y1, x0:x1], (vy, vx), 1)
            np.minimum.at(min_kl_p[y0:y1, x0:x1], (vy, vx), kp_win[vy, vx])
            np.add.at(sumexp_p[y0:y1, x0:x1], (vy, vx),
                      np.exp(-kp_win[vy, vx] / max(sm_tau, tiny)).astype(np.float32))
            np.add.at(cover_weight[y0:y1, x0:x1], (vy, vx), jmask[vy, vx])

    # --- finalize softmins --------------------------------------------------------
    valid_any = (nb_count > 0)
    softmin_q = np.zeros_like(sumexp_q, np.float32)
    softmin_p = np.zeros_like(sumexp_p, np.float32)
    if np.any(valid_any):
        if np.any(sumexp_q):
            softmin_q[valid_any] = (-sm_tau * np.log(np.maximum(sumexp_q[valid_any], tiny))).astype(np.float32)
        if np.any(sumexp_p):
            softmin_p[valid_any] = (-sm_tau * np.log(np.maximum(sumexp_p[valid_any], tiny))).astype(np.float32)

    # --- blend and agreement ------------------------------------------------------
    have_q_any = np.isfinite(min_kl_q).any()
    have_p_any = np.isfinite(min_kl_p).any()
    if have_q_any and have_p_any:
        tau_blend = float(alpha) * float(tau_q) + (1.0 - float(alpha)) * float(tau_p)
        KL_blend  = (float(alpha) * softmin_q + (1.0 - float(alpha)) * softmin_p).astype(np.float32)
    elif have_q_any:
        tau_blend = float(tau_q)
        KL_blend  = softmin_q.astype(np.float32)
    elif have_p_any:
        tau_blend = float(tau_p)
        KL_blend  = softmin_p.astype(np.float32)
    else:
        tau_blend = 1.0
        KL_blend  = np.zeros((H, W), np.float32)

    A_final = np.zeros_like(KL_blend, np.float32)
    if np.any(valid_any):
        A_final[valid_any] = np.exp(-KL_blend[valid_any] / max(tau_blend, tiny)).astype(np.float32)
    A_final = np.clip(A_final, 0.0, 1.0)

    # --- NaN guards + min-KL invalid regions to +inf ------------------------------
    KL_blend  = np.nan_to_num(KL_blend,  copy=False, nan=0.0, posinf=0.0, neginf=0.0)
    A_final   = np.nan_to_num(A_final,   copy=False, nan=0.0, posinf=1.0, neginf=0.0)
    softmin_q = np.nan_to_num(softmin_q, copy=False, nan=0.0, posinf=0.0, neginf=0.0)
    softmin_p = np.nan_to_num(softmin_p, copy=False, nan=0.0, posinf=0.0, neginf=0.0)
    min_kl_q  = np.where(valid_any, min_kl_q, np.inf).astype(np.float32)
    min_kl_p  = np.where(valid_any, min_kl_p, np.inf).astype(np.float32)

    return dict(
        nb_count=nb_count,
        min_kl_q=min_kl_q, min_kl_p=min_kl_p,
        softmin_q=softmin_q, softmin_p=softmin_p,
        cover_weight=cover_weight,
        A_final=A_final, KL_blend=KL_blend,
    )


def apply_evidence_modulators(w, Mi, Mj, ov, *, A=None, agree_power=1.0, BF=None):
    """
    Combine per-pair alignment weight with spatial terms:
      wij = Mi * Mj * w * 1_ov * (BF if provided) * (A^agree_power if provided)
    """
    wij = (Mi * Mj) * w
    wij *= ov.astype(np.float32)
    if BF is not None:
        wij *= BF
    if (A is not None) and (float(agree_power) != 0.0):
        wij *= (np.asarray(A, np.float32) ** float(agree_power))
    return wij.astype(np.float32, copy=False)




