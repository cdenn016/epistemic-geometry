# -*- coding: utf-8 -*-
"""
Module: lhs_analysis_module.py

Provides command-line utilities to load, summarize, and visualize results from Latin Hypercube sweeps.

Usage:
    python lhs_analysis_module.py [csv_path] [--outdir OUTDIR]
    If `csv_path` is omitted, auto-detects a single CSV in the working directory.
"""
import sys
import os
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import argparse

# ——— pick your columns here ———————————————
PARAMS = [
    "alpha", "beta", "gamma", "gauge_weight",
    "model_align_weight", "model_mass_weight",
    "model_feedback_weight", "curvature_weight",
    "phi_phi_tilde_coupling", "phi_init"
]

METRICS = [
    "kl_self_raw", "kl_align_raw", "kl_model_align_raw",
    "total_energy", "phi_norm", "phi_model_norm"
]
# ——————————————————————————————

def load_results(csv_path: str) -> pd.DataFrame:
    """
    Load LHS sweep results from a CSV file into a DataFrame.
    """
    return pd.read_csv(csv_path)


def summary_stats(df: pd.DataFrame) -> pd.DataFrame:
    """
    Compute descriptive statistics for each found parameter/metric column.
    Returns a DataFrame with mean, std, min, max for each.
    """
    # Filter for existing columns
    cols = [c for c in PARAMS + METRICS if c in df.columns]
    if not cols:
        print("Warning: no expected PARAMS or METRICS columns found in CSV.")
        return pd.DataFrame()
    stats = df[cols].agg(['mean', 'std', 'min', 'max']).T
    stats.columns = ['Mean', 'Std', 'Min', 'Max']
    return stats


def plot_correlations(df: pd.DataFrame, output_path: str = None):
    """
    Plot a heatmap of correlations for found PARAMS–METRICS columns.
    """
    cols = [c for c in PARAMS + METRICS if c in df.columns]
    if len(cols) < 2:
        print("Not enough columns to plot correlations.")
        return
    corr = df[cols].corr()
    plt.figure(figsize=(10, 8))
    sns.heatmap(corr, annot=True, fmt='.2f', cmap='coolwarm')
    plt.title('Parameter-Metric Correlations')
    if output_path:
        os.makedirs(os.path.dirname(output_path), exist_ok=True)
        plt.savefig(output_path, bbox_inches='tight')
    else:
        plt.show(block=False)


def pairwise_scatter(df: pd.DataFrame, variables: list = None, output_path: str = None):
    """
    Create a pairplot of selected variables.
    """
    vars_list = variables or [c for c in PARAMS + METRICS if c in df.columns]
    if len(vars_list) < 2:
        print("Not enough columns for pairwise scatter.")
        return
    sns.pairplot(df[vars_list])
    if output_path:
        os.makedirs(os.path.dirname(output_path), exist_ok=True)
        plt.savefig(output_path, bbox_inches='tight')
    else:
        plt.show(block=False)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(
        description='Analyze LHS sweep CSV results.'
    )
    parser.add_argument(
        'csv_path', nargs='?', default=None,
        help='Path to LHS results CSV'
    )
    parser.add_argument(
        '--outdir', default=None,
        help='Optional output directory for plots'
    )
    args = parser.parse_args()

    # Auto-detect or validate CSV path
    csv_path = args.csv_path
    if csv_path is None:
        csv_files = [f for f in os.listdir('.') if f.lower().endswith('.csv')]
        if len(csv_files) == 1:
            csv_path = csv_files[0]
            print(f"Auto-detected CSV: {csv_path}")
        else:
            print("CSV file path not provided and auto-detect found none or multiple CSVs")
            print("Please run with: python lhs_analysis_module.py path/to/your.csv")
            sys.exit(1)
    elif not os.path.isfile(csv_path):
        print(f"CSV file not found: {csv_path}")
        sys.exit(1)

    # Load and analyze
    df = load_results(csv_path)
    stats = summary_stats(df)
    print("\nSummary Statistics:\n", stats)

    corr_path = args.outdir and os.path.join(args.outdir, 'param_metric_correlation.png')
    plot_correlations(df, output_path=corr_path)
    print(f"Correlation plot {'saved to ' + corr_path if corr_path else 'shown interactively' }.")

    scatter_path = args.outdir and os.path.join(args.outdir, 'pairwise_scatter.png')
    pairwise_scatter(df, output_path=scatter_path)
    print(f"Pairwise scatter {'saved to ' + scatter_path if scatter_path else 'shown interactively' }.")
