import os
import pickle
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestRegressor

# Optional: adjust number of parallel jobs
N_JOBS = -1

def train_surrogate(df: pd.DataFrame, target_metric: str = "total_energy"):
    """
    Trains a RandomForest surrogate to predict a given target_metric.

    Parameters:
        df: DataFrame of LHS parameters (from lhs_samples.csv)
        target_metric: which final_metrics field to predict

    Returns:
        rf: trained RandomForestRegressor
        importances: sorted Series of feature importances
        y: target values
    """
    run_dirs = sorted([
        d for d in os.listdir("lhs_results")
        if os.path.isdir(os.path.join("lhs_results", d)) and d.startswith("run_")
    ])

    targets = []
    for i, run in enumerate(run_dirs):
        path = os.path.join("lhs_results", run, "final_metrics.pkl")
        if not os.path.exists(path):
            print(f"[WARN] Missing: {path}")
            targets.append(np.nan)
            continue
        with open(path, "rb") as f:
            metrics = pickle.load(f)
            if isinstance(metrics, list):
                metrics = metrics[-1]
            targets.append(metrics.get(target_metric, np.nan))

    if len(targets) != len(df):
        raise ValueError("Mismatch: lhs_samples.csv vs lhs_results/*")

    X = df.select_dtypes(include=[np.number])
    mask = ~np.isnan(targets)
    X = X[mask]
    y = np.array(targets)[mask]

    rf = RandomForestRegressor(
        n_estimators=300, max_features='sqrt', random_state=0,
        n_jobs=N_JOBS
    )
    rf.fit(X.values, y)
    importances = pd.Series(rf.feature_importances_, index=X.columns)
    return rf, importances.sort_values(ascending=False), y

def main():
    # Load sampled parameter inputs
    try:
        df = pd.read_csv("lhs_samples.csv")
    except FileNotFoundError:
        raise FileNotFoundError("Missing 'lhs_samples.csv'. Please generate or move it to the working directory.")

    metrics_to_check = [
        'total_energy',
        'e_self',
        'e_feedback',
        'e_align',
        'e_mod_align',
        'e_curv',
        'e_curv_mod',
    ]

    for metric in metrics_to_check:
        print(f"\n[INFO] Training surrogate for: {metric}")
        try:
            rf, importances, y = train_surrogate(df, target_metric=metric)
            print(importances.head(5))
        except Exception as e:
            print(f"[ERROR] Failed to train on {metric}: {e}")

if __name__ == "__main__":
    main()
