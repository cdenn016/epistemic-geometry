# -*- coding: utf-8 -*-
"""
Created on Wed Jul 16 20:22:01 2025

@author: chris and christine
"""

