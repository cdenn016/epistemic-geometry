# -*- coding: utf-8 -*-
"""
Created on Wed Jul 16 19:39:52 2025

@author: chris and christine
"""

import numpy as np
from generalized_math_utils import kl_divergence  # assumes this is your MVG KL implementation

# Standard library
import os
# Third-party libraries
import numpy as np
from scipy.ndimage import laplace
from generalized_omega import (exp_lie_algebra_irrep, batch_apply_omega,
                              compute_field_strength)
from get_generators import get_generators 
from joblib import Parallel, delayed
from generalized_math_utils import (
    laplacian_field,
   )
import config
from pathlib import Path
from pullback_utils import compute_agent_pullback_blocks, compute_pullback_metric
from generalized_math_utils import kl_divergence  # ← make sure this is imported
from mask_utils import (
    get_support_mask,
    get_overlap_mask,
    expand_mask_for_mu,
    expand_mask_for_sigma,
    apply_mask_mu,
    apply_mask_sigma,
    apply_mask_phi,
    norm_over_mask,
    masked_norm,
    threshold_mask
)



def compute_alignment_kl_general(agent_i, agents, field_type="belief", log_eps=config.eps):
    """
    Computes mean KL divergence KL(fiber_i || Ω_ij fiber_j) over neighbors j.
    Supports field_type = "belief" or "model".

    Args:
        agent_i: agent whose KL we compute
        agents:  list of all agents
        field_type: "belief" or "model"
        log_eps: numerical stabilizer for KL

    Returns:
        Mean KL divergence (float)
    """
    if field_type == "belief":
        mu_i     = agent_i.mu_q_field
        sigma_i  = agent_i.sigma_q_field
        Omega    = agent_i.Omega
        Omega_inv= agent_i.Omega_inv
        mu_j_f   = lambda j: agents[j].mu_q_field
        sigma_j_f= lambda j: agents[j].sigma_q_field
    elif field_type == "model":
        mu_i     = agent_i.mu_p_field
        sigma_i  = agent_i.sigma_p_field
        Omega    = agent_i.Omega_model
        Omega_inv= agent_i.Omega_model_inv
        mu_j_f   = lambda j: agents[j].mu_p_field
        sigma_j_f= lambda j: agents[j].sigma_p_field
    else:
        raise ValueError(f"Invalid field_type: {field_type}")

    mask_i = agent_i.mask > config.support_cutoff_eps
    kl_vals = []

    for neighbor in agent_i.neighbors:
        j = neighbor["id"]
        agent_j = agents[j]
        mask_j = agent_j.mask > config.support_cutoff_eps
        overlap = mask_i & mask_j

        if not np.any(overlap):
            continue

        Ω_ij = np.einsum("mab,mbc->mac", Omega[overlap], Omega_inv[overlap])

        mu_j = mu_j_f(j)[overlap]
        sigma_j = sigma_j_f(j)[overlap]
        mu_j_t, sigma_j_t = batch_apply_omega(mu_j, sigma_j, Ω_ij)

        mu_i_pts = mu_i[overlap]
        sigma_i_pts = sigma_i[overlap]

        kl = kl_divergence(mu_i_pts, sigma_i_pts, mu_j_t, sigma_j_t, log_eps=log_eps)
        kl_vals.append(np.mean(kl))

    return np.mean(kl_vals) if kl_vals else 0.0




def compute_kl_qp_field(mu_q_field, sigma_q_field,
                        mu_p_field, sigma_p_field,
                        phi_morphism=None, phi_tilde_morphism=None,
                        mask=None, log_eps=1e-8):
    """
    Compute per-cell KL divergences:
      - KL(q || Φ·p)
      - KL(p || Φ̃·q)

    Args:
        mu_q_field, sigma_q_field     : (H, W, K), (H, W, K, K) — belief field
        mu_p_field, sigma_p_field     : (H, W, K), (H, W, K, K) — model field
        phi_morphism                  : Φ   ∈ Hom(p → q), shape (H, W, K, K), or None = Identity
        phi_tilde_morphism           : Φ̃  ∈ Hom(q → p), shape (H, W, K, K), or None = Identity
        mask                          : (H, W) boolean mask (True = active region)
        log_eps                       : numerical stabilizer

    Returns:
        kl_q_phi_p_field : (H, W) KL[ q || Φ p ]
        kl_p_phi_q_field : (H, W) KL[ p || Φ̃ q ]
    """
    H, W, K = mu_q_field.shape
    N = H * W
    identity = np.eye(K)

    if mask is None:
        mask = np.ones((H, W), dtype=bool)
    indices = np.flatnonzero(mask.ravel())

    # Reshape inputs
    mu_q = mu_q_field.reshape(N, K)[indices]
    mu_p = mu_p_field.reshape(N, K)[indices]
    sig_q = sigma_q_field.reshape(N, K, K)[indices]
    sig_p = sigma_p_field.reshape(N, K, K)[indices]

    if phi_morphism is None:
        Phi = np.tile(identity, (len(indices), 1, 1))
    else:
        Phi = phi_morphism.reshape(N, K, K)[indices]

    if phi_tilde_morphism is None:
        Phi_tilde = np.tile(identity, (len(indices), 1, 1))
    else:
        Phi_tilde = phi_tilde_morphism.reshape(N, K, K)[indices]

    # --- KL(q || Φ·p) ---
    mu_p_trans = np.einsum("nij,nj->ni", Phi, mu_p)
    sig_p_trans = np.einsum("nij,njk,nlk->nil", Phi, sig_p, Phi.transpose(0, 2, 1))
    sig_p_trans += log_eps * identity[None, ...]
    kl_q_phi_p = kl_divergence(mu_q, sig_q, mu_p_trans, sig_p_trans, log_eps=log_eps)

    # --- KL(p || Φ̃·q) ---
    mu_q_trans = np.einsum("nij,nj->ni", Phi_tilde, mu_q)
    sig_q_trans = np.einsum("nij,njk,nlk->nil", Phi_tilde, sig_q, Phi_tilde.transpose(0, 2, 1))
    sig_q_trans += log_eps * identity[None, ...]
    kl_p_phi_q = kl_divergence(mu_p, sig_p, mu_q_trans, sig_q_trans, log_eps=log_eps)

    # Scatter to full (H, W) fields
    kl_q_phi_p_field = np.zeros((N,), dtype=kl_q_phi_p.dtype)
    kl_p_phi_q_field = np.zeros((N,), dtype=kl_p_phi_q.dtype)
    kl_q_phi_p_field[indices] = kl_q_phi_p
    kl_p_phi_q_field[indices] = kl_p_phi_q

    return kl_q_phi_p_field.reshape(H, W), kl_p_phi_q_field.reshape(H, W)

