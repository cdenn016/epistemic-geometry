import argparse
import pickle
import pathlib
import re
from typing import Sequence

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt


def load_metric_log_pkl(path: pathlib.Path) -> pd.DataFrame:
    """Load metric_log.pkl → DataFrame (one row per step)."""
    if not path.exists():
        raise FileNotFoundError(f"Metric log not found: {path}")
    with open(path, "rb") as f:
        log = pickle.load(f)
    return pd.DataFrame(log)


def load_per_agent_csv(path: pathlib.Path) -> pd.DataFrame:
    """Load per_agent_metrics.csv if present, else empty DF."""
    if path.exists():
        return pd.read_csv(path)
    return pd.DataFrame()


def numeric_columns(df: pd.DataFrame, skip: Sequence[str] = ()) -> list[str]:
    """Return numeric columns excluding 'step' and skip."""
    cols = []
    for c in df.columns:
        if c == 'step' or c in skip:
            continue
        if pd.api.types.is_numeric_dtype(df[c]):
            cols.append(c)
    return cols


def plot_scalar_series(steps, values, ylabel: str, title: str, save_path: pathlib.Path):
    plt.figure()
    plt.plot(steps, values, linewidth=1.5)
    plt.xlabel("Simulation step")
    plt.ylabel(ylabel)
    plt.title(title)
    plt.tight_layout()
    plt.savefig(save_path, dpi=150)
    plt.close()


def main(
    outdir: pathlib.Path,
    figs_dir: pathlib.Path,
    *,
    energy_regex: str = r"^e_",
    aggregate: str = "mean",
):
    figs_dir.mkdir(parents=True, exist_ok=True)

    # 1. Global metrics
    df_global = load_metric_log_pkl(outdir / "metric_log.pkl")
    if df_global.empty:
        print("[WARN] metric_log.pkl is empty or missing.")
    else:
        num_cols_g = numeric_columns(df_global)
        for col in num_cols_g:
            plot_scalar_series(
                df_global['step'], df_global[col],
                ylabel=col, title=f"{col} (global)",
                save_path=figs_dir / f"{col}_global.png",
            )

    # 2. Per-agent metrics
    df_agent = load_per_agent_csv(outdir / "per_agent_metrics.csv")
    if df_agent.empty:
        print("[INFO] per_agent_metrics.csv not found – skipping per-agent plots.")
        print(f"[DONE] Figures → {figs_dir.resolve()}")
        return

    num_cols_a = numeric_columns(df_agent, skip=('agent',))
    # 2a. Aggregated per-agent
    grouped = df_agent.groupby('step')
    agg_df = getattr(grouped, aggregate)()
    for col in num_cols_a:
        plot_scalar_series(
            agg_df.index, agg_df[col],
            ylabel=f"{aggregate}({col})",
            title=f"{col} ({aggregate} across agents)",
            save_path=figs_dir / f"{col}_{aggregate}.png",
        )
    # stacked energy
    energy_cols = [c for c in num_cols_a if re.match(energy_regex, c)]
    if energy_cols:
        plt.figure(figsize=(8,5))
        bottom = np.zeros(len(agg_df))
        for col in energy_cols:
            plt.bar(
                agg_df.index, agg_df[col],
                bottom=bottom, label=col, width=1.0
            )
            bottom += agg_df[col].values
        plt.xlabel("Simulation step")
        plt.ylabel(f"{aggregate} energy per agent")
        plt.title("Energy budget decomposition")
        plt.legend(fontsize=7, frameon=False)
        plt.tight_layout()
        plt.savefig(figs_dir / "energy_budget_stacked.png", dpi=150)
        plt.close()

    # 2b. Individual agent plots
    agents = sorted(df_agent['agent'].unique())
    for col in num_cols_a:
        plt.figure(figsize=(8,4))
        for ag in agents:
            sub = df_agent[df_agent['agent'] == ag]
            plt.plot(sub['step'], sub[col], label=f"agent {ag}", linewidth=1)
        plt.xlabel("Simulation step")
        plt.ylabel(col)
        plt.title(f"{col} by agent")
        plt.legend(ncol=4, fontsize="small", frameon=False)
        plt.tight_layout()
        plt.savefig(figs_dir / f"{col}_by_agent.png", dpi=150)
        plt.close()

    print(f"[DONE] Figures → {figs_dir.resolve()}")


if __name__ == '__main__':
    parser = argparse.ArgumentParser(
        description="Plot simulation metrics",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    parser.add_argument("--outdir", default="checkpoints",
                        help="Simulation output directory")
    parser.add_argument("--figdir", default="Holonomy_Visualizations",
                        help="Where to write PNGs")
    parser.add_argument("--aggregate", choices=("mean","sum"), default="mean",
                        help="How to combine per-agent values at each step")
    args = parser.parse_args()

    main(
        pathlib.Path(args.outdir),
        pathlib.Path(args.figdir),
        aggregate=args.aggregate,
    )
