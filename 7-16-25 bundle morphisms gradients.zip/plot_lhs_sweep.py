# -*- coding: utf-8 -*-
"""
Plot LHS sweep results:
  1) scatter‐matrix of each PARAM vs each METRIC
  2) heatmap of PARAM–METRIC correlations
  3) boxplots of each METRIC across quantiles of each PARAM

Usage in Spyder: just hit “Run file” (no args needed).
"""
import sys
import os
import pickle
from pathlib import Path

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# ——— pick your columns here ———————————————
PARAMS = [
    "alpha", "beta", "gamma", "gauge_weight",
    "model_align_weight", "model_mass_weight",
    "model_feedback_weight", "curvature_weight",
    "phi_phi_tilde_coupling", "phi_init"
]

METRICS = [
    "kl_self_raw", "kl_align_raw", "kl_model_align_raw",
    "total_energy", "phi_norm", "phi_model_norm"
]
# ——————————————————————————————

def load_pickle(path):
    with open(path, "rb") as f:
        return pickle.load(f)


def build_df(root_dir="."):
    recs = []
    root = Path(root_dir)
    # search for lhs_results* folders
    lhs_dirs = [p for p in sorted(root.glob("lhs_results*")) if p.is_dir()]
    if root.name.startswith("lhs_results") and root.is_dir():
        lhs_dirs.insert(0, root)

    for lhs_dir in lhs_dirs:
        for run in sorted(lhs_dir.iterdir()):
            if not run.is_dir(): continue
            pfile, mfile = run/"params.pkl", run/"final_metrics.pkl"
            if not (pfile.exists() and mfile.exists()): continue
            try:
                params = load_pickle(pfile)
                metrics = load_pickle(mfile)
                if isinstance(metrics, list) and metrics and isinstance(metrics[-1], dict):
                    metrics = metrics[-1]
            except Exception:
                continue

            flat = {}
            for d in (params, metrics):
                for k,v in d.items():
                    flat[k] = v.get('value', v) if isinstance(v, dict) else v
            recs.append(flat)

    df = pd.DataFrame(recs)
    # drop non-scalars
    for c in df.columns:
        if df[c].apply(lambda x: isinstance(x, (dict,list,set))).any():
            df.drop(columns=[c], inplace=True)

    # compute raw KLs
    if "kl_self" in df and "alpha" in df:
        df["kl_self_raw"] = df["kl_self"]/df["alpha"].replace(0, np.nan)
    if "kl_align" in df and "beta" in df:
        df["kl_align_raw"] = df["kl_align"]/df["beta"].replace(0, np.nan)
    if "kl_model_align" in df and "model_align_weight" in df:
        df["kl_model_align_raw"] = df["kl_model_align"]/df["model_align_weight"].replace(0, np.nan)

    # drop rows missing required fields
    existing_params  = [c for c in PARAMS  if c in df]
    existing_metrics = [c for c in METRICS if c in df]
    req = existing_params + existing_metrics
    if req:
        df = df.dropna(subset=req)

    print(f"[INFO] {len(df)} runs loaded.")
    return df


def plot_scatter_matrix(df, outdir="lhs_plots"):
    os.makedirs(outdir, exist_ok=True)
    P = [c for c in PARAMS  if c in df]
    M = [c for c in METRICS if c in df]
    if not P or not M:
        print("[ERROR] No matching PARAM or METRIC columns.")
        return

    sub = df[P+M].dropna()
    sns.set(style="whitegrid")
    g = sns.PairGrid(sub, x_vars=P, y_vars=M, height=2.5, aspect=1.2)
    g.map(sns.scatterplot, s=20, alpha=0.6)
    g.fig.suptitle("Parameter vs Metric scatter matrix", y=1.02)
    plt.tight_layout()
    path = Path(outdir)/"scatter_matrix.png"
    g.savefig(path)
    plt.close()
    print(f"[SAVE] {path}")


def plot_heatmap(df, outdir="lhs_plots"):
    os.makedirs(outdir, exist_ok=True)
    P = [c for c in PARAMS  if c in df]
    M = [c for c in METRICS if c in df]
    sub = df[P+M].dropna()

    corr = sub.corr().loc[P, M]
    plt.figure(figsize=(len(M)*1.2, len(P)*0.6+1))
    sns.heatmap(corr, annot=True, fmt=".2f", cmap="vlag", center=0,
                cbar_kws={"shrink":0.5})
    plt.title("Param–Metric Correlation")
    plt.tight_layout()
    path = Path(outdir)/"correlation_heatmap.png"
    plt.savefig(path)
    plt.close()
    print(f"[SAVE] {path}")


def plot_boxplots(df, outdir="lhs_plots", bins=5):
    os.makedirs(outdir, exist_ok=True)
    for param in PARAMS:
        if param not in df: continue
        # quantile bins
        df[f"{param}_bin"] = pd.qcut(df[param], bins, duplicates="drop")
        for metric in METRICS:
            if metric not in df: continue
            plt.figure(figsize=(6,4))
            sns.boxplot(
                data=df, x=f"{param}_bin", y=metric,
                showcaps=True, showfliers=False)
            plt.xticks(rotation=30, ha="right")
            plt.title(f"{metric} by {param} bins")
            plt.tight_layout()
            path = Path(outdir)/f"box_{param}_{metric}.png"
            plt.savefig(path)
            plt.close()
            print(f"[SAVE] {path}")

if __name__ == "__main__":
    import sys
    root = sys.argv[1] if len(sys.argv)>1 else "."
    df = build_df(root)
    if df.empty:
        print("[ERROR] No data found.")
        sys.exit(0)

    out = "lhs_plots"
    plot_scatter_matrix(df, out)
    plot_heatmap(df, out)
    plot_boxplots(df, out)
    print("[DONE] All plots in 'lhs_plots/'")
