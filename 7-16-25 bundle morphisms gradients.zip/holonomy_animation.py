import numpy as np
import matplotlib.pyplot as plt
from matplotlib.patches import Ellipse
import matplotlib.animation as animation
from pathlib import Path
import pickle
import re
from sklearn.decomposition import PCA
import config


TRANSPORT_LOG_DIR = Path("holonomy_experiments/transport_logs")
SAVE_DIR_SPATIAL = Path("Holonomy_Visualizations/transport_spatial")
SAVE_DIR_MU      = Path("Holonomy_Visualizations/transport_mu")

def extract_step(fname):
    match = re.search(r"step(\d+)", fname)
    return int(match.group(1)) if match else -1


def animate_mu_pca(mu_seq, save_path):
    """
    Animate μ(t) projected into PCA space over time.
    """
    mu_seq = np.asarray(mu_seq)
    pca = PCA(n_components=2)
    xy_seq = pca.fit_transform(mu_seq)

    xmin, xmax = np.min(xy_seq[:, 0]), np.max(xy_seq[:, 0])
    ymin, ymax = np.min(xy_seq[:, 1]), np.max(xy_seq[:, 1])
    pad = 0.1 * max(xmax - xmin, ymax - ymin)

    fig, ax = plt.subplots(figsize=(5, 5))
    ax.set_xlim(xmin - pad, xmax + pad)
    ax.set_ylim(ymin - pad, ymax + pad)
    ax.set_aspect('equal')

    def update(i):
        ax.clear()
        ax.set_xlim(xmin - pad, xmax + pad)
        ax.set_ylim(ymin - pad, ymax + pad)
        ax.set_title(f"μ PCA — Frame {i+1}/{len(mu_seq)}")

        ax.plot(xy_seq[:i+1, 0], xy_seq[:i+1, 1], 'k-', lw=1, alpha=0.3)
        # Plot start and end points with correct layering
        ax.plot(xy_seq[-1, 0], xy_seq[-1, 1], 'ro', label='End', zorder=1)
        ax.plot(xy_seq[0, 0], xy_seq[0, 1], 'go', label='Start', zorder=2)  # Ensure start is on top

        ax.plot(xy_seq[i, 0], xy_seq[i, 1], 'ro')

        ax.legend()

    ani = animation.FuncAnimation(fig, update, frames=len(mu_seq), interval=250, blit=False)
    Path(save_path).parent.mkdir(parents=True, exist_ok=True)
    ani.save(save_path, writer="pillow")
    plt.close()

def plot_sigma_diagnostics(sigma_seq, save_dir, base_name="sigma"):
    """
    Generate scalar and matrix-entry visualizations of Σ along a transport path.
    - Frobenius norm over path
    - log(det(Σ)) over path
    - Individual Σ[i,j](step) entries if K ≤ 5
    """
    sigma_seq = np.asarray(sigma_seq)
    K = sigma_seq.shape[-1]
    Path(save_dir).mkdir(parents=True, exist_ok=True)

    # ── Frobenius norm ‖Σ‖ over path ──
    fro_norms = [np.linalg.norm(S, ord='fro') for S in sigma_seq]
    plt.figure(figsize=(6, 4))
    plt.plot(fro_norms, 'b-o', lw=1.5)
    plt.title("‖Σ‖_F over Path")
    plt.xlabel("Path Step")
    plt.ylabel("Frobenius Norm")
    plt.tight_layout()
    plt.savefig(Path(save_dir) / f"{base_name}_fro_norm.png")
    plt.close()

    # ── log(det(Σ)) over path ──
    logdets = [np.log(np.linalg.det(S) + 1e-12) for S in sigma_seq]
    plt.figure(figsize=(6, 4))
    plt.plot(logdets, 'g-o', lw=1.5)
    plt.title("log det(Σ) over Path")
    plt.xlabel("Path Step")
    plt.ylabel("log det Σ")
    plt.tight_layout()
    plt.savefig(Path(save_dir) / f"{base_name}_logdet.png")
    plt.close()

    # ── Component-wise Σ[i,j] over path ──
    if K <= 5:
        fig, axs = plt.subplots(K, K, figsize=(3*K, 3*K), sharex=True)
        for i in range(K):
            for j in range(K):
                axs[i, j].plot([S[i, j] for S in sigma_seq], lw=1.2)
                axs[i, j].set_title(f"Σ[{i},{j}] over Path")
        plt.tight_layout()
        plt.savefig(Path(save_dir) / f"{base_name}_components.png")
        plt.close()

def plot_holonomy_vs_step(files_by_step, save_dir, label):
    norms = []
    steps = []

    for fpath in files_by_step:
        step = extract_step(fpath.name)
        try:
            with open(fpath, "rb") as f:
                data = pickle.load(f)

            logH = data.get("logH", None)
            H    = data.get("holonomy", None)

            #print(f"[DEBUG] {fpath.name}: logH={logH is not None}, H={H is not None}")

            if logH is not None:
                norm = np.linalg.norm(logH, ord='fro')
            elif H is not None:
                norm = np.linalg.norm(H - np.eye(H.shape[-1]), ord='fro')
            else:
                continue

            norms.append(norm)
            steps.append(step)
        except Exception as e:
            print(f"[WARN] Failed to load holonomy from {fpath.name}: {e}")

    if not norms:
        print(f"[SKIP] No holonomy data found for label: {label}")
        return

    plt.figure(figsize=(6, 4))
    plt.plot(steps, norms, 'r-o', lw=1.5)
    plt.title(f"‖Holonomy‖ vs Step — {label}")
    plt.xlabel("Simulation Step")
    plt.ylabel("‖log H‖ (Frobenius)")
    plt.tight_layout()

    save_path = Path(save_dir) / f"{label}_holonomy_norm.png"
    plt.savefig(save_path)
    plt.close()
    print(f"[SAVED] {save_path}")

def plot_transport_on_agents(agents, transport_path, save_path, title=None):
    """
    Plot all agents’ masks and overlay the transport path.

    Args:
        agents         : list of agent objects with .mask and .center
        transport_path : list or array of (i, j) tuples
        save_path      : where to save the plot
        title          : optional plot title
    """
    from matplotlib import cm

    H, W = agents[0].mask.shape
    N = len(agents)
    agent_map = np.zeros((H, W))

    for idx, agent in enumerate(agents):
        agent_map += (idx + 1) * (agent.mask > config.support_cutoff_eps)

    # Plot agents with colormap
    plt.figure(figsize=(6, 6))
    plt.imshow(agent_map.T, origin="lower", cmap=cm.tab20, alpha=0.3)

    # Overlay agent centers
    for agent in agents:
        x, y = agent.center
        plt.plot(x, y, 'ko', markersize=4)

    # Overlay transport path
    path_array = np.asarray(transport_path)
    if path_array.size > 0:
        xs, ys = path_array[:, 0], path_array[:, 1]
        plt.plot(xs, ys, 'r-o', lw=2, label="Transport Path")
        plt.scatter(xs[0], ys[0], color='green', label="Start", zorder=5)
        plt.scatter(xs[-1], ys[-1], color='red', label="End", zorder=5)

    plt.title(title or "Transport Path Over Agent Map")
    plt.axis("equal")
    plt.xlim(0, H)
    plt.ylim(0, W)
    plt.legend()
    Path(save_path).parent.mkdir(parents=True, exist_ok=True)
    plt.savefig(save_path)
    plt.close()
    print(f"[SAVED] Transport overlay to {save_path}")

from sklearn.decomposition import PCA
from matplotlib.patches import Ellipse

def plot_projected_belief_ellipses(path_coords, mu_seq, sigma_seq, save_path, agent_map=None, title=None):
    """
    Project (μ, Σ) to 2D via PCA and plot ellipses along the 2D transport path.

    Args:
        path_coords : list of (i, j) transport positions on 2D grid
        mu_seq      : list of (K,) mean vectors
        sigma_seq   : list of (K, K) covariance matrices
        save_path   : output image path
        agent_map   : optional (H, W) array of agent mask overlay
        title       : plot title
    """
    mu_seq = np.asarray(mu_seq)
    sigma_seq = np.asarray(sigma_seq)
    assert mu_seq.ndim == 2 and sigma_seq.ndim == 3, "Invalid input shape"

    # PCA projection to 2D
    pca = PCA(n_components=2)
    mu_proj = pca.fit_transform(mu_seq)
    V = pca.components_  # (2, K)

    # Project covariances: Σ_proj = V Σ Vᵀ for each Σ
    sigma_proj = np.einsum("ij,njk,lk->nil", V, sigma_seq, V)

    fig, ax = plt.subplots(figsize=(6, 6))
    if agent_map is not None:
        ax.imshow(agent_map.T, origin="lower", cmap="Greys", alpha=0.2)

    for (x, y), μ, Σ in zip(path_coords, mu_proj, sigma_proj):
        try:
            vals, vecs = np.linalg.eigh(Σ)
            width, height = 2 * np.sqrt(np.clip(vals, 1e-6, None))
            angle = np.degrees(np.arctan2(vecs[1, 0], vecs[0, 0]))
            e = Ellipse((x, y), width, height, angle=angle,
                        edgecolor="blue", facecolor="none", lw=1)
            ax.add_patch(e)
        except Exception as e:
            print(f"[WARN] Ellipse failed at ({x},{y}): {e}")

    ax.plot(*zip(*path_coords), 'ro-', lw=1, label="Transport Path")
    ax.scatter(*path_coords[0], color='green', label="Start", zorder=5)
    ax.scatter(*path_coords[-1], color='red', label="End", zorder=5)
    ax.set_aspect('equal')
    ax.set_xlim(0, agent_map.shape[0] if agent_map is not None else 50)
    ax.set_ylim(0, agent_map.shape[1] if agent_map is not None else 50)
    ax.legend()
    ax.set_title(title or "Projected Belief Ellipses")
    Path(save_path).parent.mkdir(parents=True, exist_ok=True)
    plt.savefig(save_path)
    plt.close()
    print(f"[SAVED] belief ellipse overlay → {save_path}")

def animate_projected_belief_ellipses(path_coords, mu_seq, sigma_seq, save_path, agent_map=None, title=None):
    """
    Animate 2D PCA-projected belief ellipses evolving over the transport path.

    Args:
        path_coords : (T, 2) grid coordinates
        mu_seq      : (T, K) belief means
        sigma_seq   : (T, K, K) belief covariances
        save_path   : output .gif path
        agent_map   : optional (H, W) mask field
        title       : optional title
    """
    from sklearn.decomposition import PCA
    from matplotlib.patches import Ellipse

    mu_seq = np.asarray(mu_seq)
    sigma_seq = np.asarray(sigma_seq)
    path_coords = np.asarray(path_coords)
    T = len(mu_seq)

    pca = PCA(n_components=2)
    mu_proj = pca.fit_transform(mu_seq)
    V = pca.components_
    sigma_proj = np.einsum("ij,njk,lk->nil", V, sigma_seq, V)

    fig, ax = plt.subplots(figsize=(6, 6))
    agent_img = None

    def update(t):
        ax.clear()
        if agent_map is not None:
            ax.imshow(agent_map.T, origin="lower", cmap="Greys", alpha=0.2)

        x, y = path_coords[t]
        μ = mu_proj[t]
        Σ = sigma_proj[t]
        try:
            vals, vecs = np.linalg.eigh(Σ)
            width, height = 2 * np.sqrt(np.clip(vals, 1e-6, None))
            angle = np.degrees(np.arctan2(vecs[1, 0], vecs[0, 0]))
            e = Ellipse((x, y), width, height, angle=angle,
                        edgecolor="blue", facecolor="none", lw=2)
            ax.add_patch(e)
        except Exception as e:
            print(f"[WARN] ellipse frame {t}: {e}")

        ax.plot(*zip(*path_coords[:t+1]), 'ro-', lw=1)
        ax.scatter(*path_coords[0], color='green', label='Start')
        ax.scatter(*path_coords[-1], color='red', label='End')
        ax.set_xlim(0, agent_map.shape[0])
        ax.set_ylim(0, agent_map.shape[1])
        ax.set_aspect('equal')
        ax.set_title(title or f"Belief Ellipses — Frame {t+1}/{T}")

    ani = animation.FuncAnimation(fig, update, frames=T, interval=300)
    Path(save_path).parent.mkdir(parents=True, exist_ok=True)
    ani.save(save_path, writer="pillow")
    plt.close()
    print(f"[SAVED] animated ellipse overlay → {save_path}")

from generalized_io_utils import load_all_checkpoints

def animate_transport_ellipses(mu_seq, sigma_seq, path_coords, agents, save_path, title=None):
    """
    Animate belief ellipses along transport path overlaid on agent domains.

    Args:
        mu_seq      : list of (K,) μ vectors
        sigma_seq   : list of (K,K) Σ matrices
        path_coords : list of (i,j) tuples
        agents      : list of agent objects with .mask
        save_path   : output .gif
        title       : optional string
    """
    import numpy as np
    from matplotlib.patches import Ellipse
    from matplotlib import cm
    import matplotlib.pyplot as plt
    import matplotlib.animation as animation
    from pathlib import Path
    import config

    mu_seq = np.asarray(mu_seq)
    sigma_seq = np.asarray(sigma_seq)
    path_coords = np.asarray(path_coords)

    H, W = agents[0].mask.shape
    fig, ax = plt.subplots(figsize=(6, 6))

    # Precompute agent support map
    agent_map = np.zeros((H, W))
    for idx, agent in enumerate(agents):
        agent_map += (idx + 1) * (agent.mask > config.support_cutoff_eps)

    def draw_ellipse(ax, mu, sigma, center, color="blue", scale=1.5):
        vals, vecs = np.linalg.eigh(sigma)
        order = vals.argsort()[::-1]
        vals = vals[order]
        vecs = vecs[:, order]
        angle = np.degrees(np.arctan2(*vecs[:, 0][::-1]))
        width, height = 2 * scale * np.sqrt(np.maximum(vals, 0))
        ell = Ellipse(xy=center, width=width, height=height, angle=angle,
                      edgecolor=color, facecolor='none', lw=1.0)
        ax.add_patch(ell)

    def update(frame):
        ax.clear()
        ax.imshow(agent_map.T, origin="lower", cmap=cm.Greys, alpha=0.25)
        ax.set_xlim(0, H)
        ax.set_ylim(0, W)
        ax.set_aspect("equal")
        ax.set_title(f"{title or 'Transport'} — Belief Ellipses — Step {frame+1}/{len(mu_seq)}")

        # Draw ellipses up to current frame
        for t in range(frame + 1):
            center = path_coords[t]
            draw_ellipse(ax, mu_seq[t], sigma_seq[t], center, color="blue")

        # Draw transport path
        xs, ys = path_coords[:frame + 1].T
        ax.plot(xs, ys, 'r-o', lw=2, markersize=3, label="Transport Path")
        ax.scatter(xs[0], ys[0], color="green", label="Start", zorder=5)
        ax.scatter(xs[-1], ys[-1], color="red", label="End", zorder=5)
        ax.legend()

    ani = animation.FuncAnimation(fig, update, frames=len(mu_seq), interval=350)
    Path(save_path).parent.mkdir(parents=True, exist_ok=True)
    ani.save(save_path, writer="pillow")
    plt.close()
    print(f"[SAVED] Animated transport overlay: {save_path}")


def main(agents=None, checkpoint_path=None):
    all_files = list(TRANSPORT_LOG_DIR.glob("*.pkl"))
    grouped = {}

    for f in all_files:
        label = re.sub(r"step\d+_", "", f.name)
        grouped.setdefault(label, []).append(f)

    SAVE_DIR_SPATIAL.mkdir(parents=True, exist_ok=True)
    SAVE_DIR_MU.mkdir(parents=True, exist_ok=True)

    if agents is None and checkpoint_path:
        agents_dict = load_all_checkpoints(checkpoint_path)
        agents = agents_dict[min(agents_dict.keys())]

    for label, files in grouped.items():
        if len(files) < 2:
            continue

        files_by_step = sorted(files, key=lambda f: extract_step(f.name))
        f_initial = files_by_step[0]
        f_final   = files_by_step[-1]

        for fpath in [f_initial, f_final]:
            step = extract_step(fpath.name)
            with open(fpath, "rb") as f:
                data = pickle.load(f)

            mu_seq = np.array(data["mu_seq"])
            sigma_seq = np.array(data["sigma_seq"])
            path_coords = np.array(data["transport_path"])
            base_name = fpath.stem

            print(f"[VISUALIZING] {base_name} (length={len(mu_seq)})")

            try:
                animate_mu_pca(
                    mu_seq,
                    save_path=SAVE_DIR_MU / f"{base_name}_pca.gif"
                )
            except Exception as e:
                print(f"[WARN] PCA animation failed for {base_name}: {e}")

            try:
                plot_sigma_diagnostics(
                    sigma_seq,
                    save_dir=SAVE_DIR_MU / f"{base_name}_sigma_diag",
                    base_name=base_name
                )
            except Exception as e:
                print(f"[WARN] Σ diagnostic plot failed for {base_name}: {e}")

            try:
                if agents is not None:
                    agent_map = np.sum([a.mask for a in agents], axis=0)
                    plot_projected_belief_ellipses(
                        path_coords,
                        mu_seq,
                        sigma_seq,
                        save_path=SAVE_DIR_SPATIAL / f"{base_name}_ellipses.png",
                        agent_map=agent_map,
                        title=f"{base_name} — Belief Ellipses"
                    )
            except Exception as e:
                print(f"[WARN] Static ellipse overlay failed for {base_name}: {e}")

            try:
                if agents is not None:
                    agent_map = np.sum([a.mask for a in agents], axis=0)
                    animate_projected_belief_ellipses(
                        path_coords,
                        mu_seq,
                        sigma_seq,
                        save_path=SAVE_DIR_SPATIAL / f"{base_name}_ellipses.gif",
                        agent_map=agent_map,
                        title=f"{base_name} — Belief Ellipses"
                    )
            except Exception as e:
                print(f"[WARN] Animated ellipse overlay failed for {base_name}: {e}")

            try:
                if agents is not None:
                    save_path = SAVE_DIR_SPATIAL / f"{base_name}_transport_overlay.png"
                    plot_transport_on_agents(
                        agents=agents,
                        transport_path=path_coords,
                        save_path=save_path,
                        title=f"{base_name} — Step {step}"
                    )
            except Exception as e:
                print(f"[WARN] Transport overlay failed for {base_name}: {e}")

        try:
            plot_holonomy_vs_step(
                files_by_step,
                save_dir=SAVE_DIR_SPATIAL,
                label=label
            )
        except Exception as e:
            print(f"[WARN] Holonomy plot failed for {label}: {e}")

        # === HANDLE SPATIAL-ONLY TRANSPORT LOGS ===
    for fpath in all_files:
        if "_spatial_radius" not in fpath.name:
            continue  # Skip non-spatial paths

        base_name = fpath.stem
        step = extract_step(fpath.name)

        try:
            with open(fpath, "rb") as f:
                data = pickle.load(f)

            mu_seq = np.array(data["mu_seq"])
            sigma_seq = np.array(data["sigma_seq"])
            path_coords = np.array(data["transport_path"])

            # ✅ Check consistent length
            if not (len(mu_seq) == len(sigma_seq) == len(path_coords)):
                print(f"[SKIP] Mismatched lengths in {base_name}: μ={len(mu_seq)}, Σ={len(sigma_seq)}, path={len(path_coords)}")
                continue

            # 🌀 Animate transport overlay
            animate_transport_ellipses(
                mu_seq,
                sigma_seq,
                path_coords,
                agents,
                save_path=SAVE_DIR_SPATIAL / f"{base_name}_ellipses.gif",
                title=f"{base_name} — Spatial Holonomy"
            )
            print(f"[✓] Animated spatial transport: {base_name}")

        except Exception as e:
            print(f"[WARN] animate_transport_ellipses failed for {base_name}: {e}")



if __name__ == "__main__":
    main(checkpoint_path="checkpoints")

