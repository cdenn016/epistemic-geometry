import numpy as np
from scipy.linalg import expm


_generator_cache = {}

# get_generators.py

import numpy as np

class GeneratorSet(dict):
    def __init__(self, E, F, H, block_dims, labels):
        super().__init__(E=E, F=F, H=H)
        self.blocks = []
        self.labels = labels

        start = 0
        for dim, label in zip(block_dims, labels):
            end = start + dim
            self.blocks.append((start, end))
            start = end
import numpy as np

def _get_irrep_sl2r(K):
    """
    Return the K×K real irreducible representation of sl(2,R) for odd K.
    Output: array of shape (3, K, K) corresponding to [E, F, H].
    """
    assert K % 2 == 1, f"Only odd K supported, got K={K}"
    j = (K - 1) / 2
    m_vals = np.arange(-j, j + 1)
    E = np.zeros((K, K))
    F = np.zeros((K, K))
    H = np.diag(2 * m_vals)

    for i, m in enumerate(m_vals):
        if i + 1 < K:
            E[i, i + 1] = np.sqrt((j - m) * (j + m + 1))
        if i - 1 >= 0:
            F[i, i - 1] = np.sqrt((j + m) * (j - m + 1))

    return np.stack([E, F, H])


def sl2r_irrep(K: int) -> dict:
    """
    Return the real irreducible SL(2,R) generators E, F, H for dimension K = 2ℓ + 1.
    """
    if K % 2 == 0:
        raise ValueError("K must be odd for SL(2,R) irreps (K = 2ℓ + 1).")
    ℓ = (K - 1) // 2
    E = np.zeros((K, K), dtype=float)
    F = np.zeros((K, K), dtype=float)
    H = np.zeros((K, K), dtype=float)

    for m in range(-ℓ, ℓ + 1):
        i = m + ℓ
        H[i, i] = m
        if i < K - 1:
            a = np.sqrt((ℓ - m) * (ℓ + m + 1))
            E[i, i + 1] = a
            E[i + 1, i] = a
            F[i, i + 1] = -a
            F[i + 1, i] = a
    return {"E": E, "F": F, "H": H}

def block_diag_generators(blocks: list[dict]) -> dict:
    """
    Given a list of irrep generator dicts, return block-diagonal combined generators.
    """
    E_blocks = [b["E"] for b in blocks]
    F_blocks = [b["F"] for b in blocks]
    H_blocks = [b["H"] for b in blocks]

    E = np.block([[e if i == j else np.zeros((e.shape[0], f.shape[1]))
                   for j, f in enumerate(E_blocks)] for i, e in enumerate(E_blocks)])
    F = np.block([[e if i == j else np.zeros((e.shape[0], f.shape[1]))
                   for j, f in enumerate(F_blocks)] for i, e in enumerate(F_blocks)])
    H = np.block([[e if i == j else np.zeros((e.shape[0], f.shape[1]))
                   for j, f in enumerate(H_blocks)] for i, e in enumerate(H_blocks)])

    return {"E": E, "F": F, "H": H}

def get_generators(group_name, K, return_meta=False):
    """
    Return generator matrices for a given group and representation dimension K.

    Args:
        group_name   : string, e.g. 'sl2r'
        K            : int, fiber dimension (for irreps, must be odd)
        return_meta  : if True, returns (generators, meta_dict)

    Returns:
        generators   : (d, K, K) array of Lie algebra generators
        meta_dict    : (optional) contains block info: {"blocks": [K1, K2, ...]}
    """
    if group_name.lower() == "sl2r":
        if isinstance(K, int):
            G = _get_irrep_sl2r(K)  # legacy behavior
            meta = {"blocks": [K]}
        else:  # assume it's a list of irreducible block sizes
            G, meta = _get_reducible_sl2r(K)
    else:
        raise ValueError(f"Unsupported group: {group_name}")

    return (G, meta) if return_meta else G



# sl2r_utils.py


class RhoFunction:
    def __init__(self, generators: np.ndarray):
        assert generators.shape[0] == 3, "Expecting 3 generators [E, F, H]"
        self.E = generators[0]
        self.F = generators[1]
        self.H = generators[2]

    def __call__(self, phi_vec: np.ndarray) -> np.ndarray:
        return expm(phi_vec[0] * self.E +
                    phi_vec[1] * self.F +
                    phi_vec[2] * self.H)




def infer_lie_algebra_dim(group_name: str, K: int) -> int:
    """
    Return the dimension of the Lie algebra for the given group and rep-dimension K.
    Accepts two args so calls like infer_lie_algebra_dim(name, K) work.
    """
    name = group_name.lower()
    if name == "so3":
        return 3
    if name == "su2":
        return 3
    if name == "u1":
        return 1
    if name == "sl2r":
        return 3
    raise ValueError(f"Unknown group '{group_name}' for infer_lie_algebra_dim")
