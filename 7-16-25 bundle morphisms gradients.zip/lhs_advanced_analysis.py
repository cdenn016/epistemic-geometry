# -*- coding: utf-8 -*-
"""
Module: lhs_advanced_analysis.py

Standalone analysis tool for Latin Hypercube Sweep (LHS) experiments.

Runable script: click "Run" to execute a full analysis pipeline.

It supports two data layouts:
  1) Flat pickles: metric_log.pkl & params.pkl
  2) Folder layout: --root lhs_results/ where each run_X_tryX has params.pkl and field_dumps/step_*/metrics.pkl

Features:
  1. Merge parameters & metrics across runs/steps
  2. Summary stats & correlations
  3. PCA dimensionality reduction
  4. Surrogate modeling (RF/GPR)
  5. Hyperparameter tuning (Optuna)
  6. Publication-quality plots

Usage:
    # Flat pickles:
    python lhs_advanced_analysis.py --metrics /path/metric_log.pkl --params /path/params.pkl

    # Folder layout:
    python lhs_advanced_analysis.py --root   /path/to/lhs_results

    Optional flags:
      --target      metric name to model (default total_energy)
      --components  PCA components (default 5)
      --trials      Optuna trials    (default 50)
"""
import os
import pickle
import argparse
import numpy as np
import pandas as pd
from glob import glob
from sklearn.decomposition import PCA
from sklearn.model_selection import cross_val_score, train_test_split
from sklearn.ensemble import RandomForestRegressor
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.gaussian_process.kernels import Matern, WhiteKernel
import optuna
import matplotlib.pyplot as plt

def load_from_flat(metrics_pkl: str, params_pkl: str) -> pd.DataFrame:
    with open(metrics_pkl, 'rb') as f:
        metric_log = pickle.load(f)
    with open(params_pkl, 'rb') as f:
        params = pickle.load(f)
    records = []
    for run_id, metrics in metric_log.items():
        param_dict = params.get(run_id, {})
        for step_str, step_data in metrics.items():
            row = {'run_id': run_id, 'step': int(step_str.replace('step_', ''))}
            row.update(param_dict)
            row.update(step_data)
            records.append(row)
    df = pd.DataFrame(records)
    return df.sort_values(['run_id','step']).reset_index(drop=True)


import re


def load_from_folder(root: str) -> pd.DataFrame:
    """Recursively walk `root` for any step*/.pkl metrics and build a DataFrame."""
    records = []
    for run_dir in sorted(os.listdir(root)):
        run_path = os.path.join(root, run_dir)
        if not os.path.isdir(run_path):
            continue

        # load per-run params if present
        params_pkl = os.path.join(run_path, 'params.pkl')
        param_dict = {}
        if os.path.exists(params_pkl):
            with open(params_pkl, 'rb') as f:
                param_dict = pickle.load(f)

        # first, try loading final_metrics.pkl if it exists
        final_pkl = os.path.join(run_path, 'final_metrics.pkl')
        if os.path.exists(final_pkl):
            with open(final_pkl, 'rb') as f:
                metric_log = pickle.load(f)
            for step_idx, step_data in enumerate(metric_log):
                row = {'run_id': run_dir, 'step': step_idx}
                row.update(param_dict)
                if isinstance(step_data, dict):
                    row.update(step_data)
                records.append(row)
            continue

        # otherwise, descend into field_dumps
        fd = os.path.join(run_path, 'field_dumps')
        if not os.path.isdir(fd):
            continue
        for dirpath, _, filenames in os.walk(fd):
            base = os.path.basename(dirpath)
            if not base.lower().startswith('step') or not filenames:
                continue
            # parse step number
            m = re.search(r"\d+", base)
            step = int(m.group()) if m else None
            # load every .pkl here
            for fn in filenames:
                if not fn.lower().endswith('.pkl'):
                    continue
                path = os.path.join(dirpath, fn)
                try:
                    with open(path, 'rb') as f:
                        data = pickle.load(f)
                except:
                    continue
                row = {'run_id': run_dir, 'step': step}
                row.update(param_dict)
                if isinstance(data, dict):
                    row.update(data)
                records.append(row)

    if not records:
        raise ValueError(f"No .pkl metrics found under: {root}")

    df = pd.DataFrame(records)
    return df.sort_values(['run_id', 'step']).reset_index(drop=True)



def load_sweep_data(metrics: str = None, params: str = None, root: str = None) -> pd.DataFrame:
    if root:
        return load_from_folder(root)
    elif metrics and params:
        return load_from_flat(metrics, params)
    else:
        raise ValueError('Provide either --root or both --metrics and --params')


def summary_stats(df: pd.DataFrame) -> pd.DataFrame:
    return df.describe().T[['mean','std','min','max']]


def correlation_matrix(df: pd.DataFrame, metrics_only: bool = True) -> pd.DataFrame:
    data = df.select_dtypes(include=float) if metrics_only else df.select_dtypes(include=[np.number])
    return data.corr()


def pca_analysis(df: pd.DataFrame, n_components: int = 3) -> dict:
    pca = PCA(n_components=n_components)
    comps = pca.fit_transform(df.values)
    comp_df = pd.DataFrame(comps, columns=[f'PC{i+1}' for i in range(n_components)])
    return {'pca': pca, 'components': comp_df, 'explained_variance': pca.explained_variance_ratio_}


from joblib import parallel_backend

def fit_surrogate_model(df: pd.DataFrame, features: list, target: str,
                        model_type: str = 'rf', cv: int = 5) -> tuple:
    X, y = df[features].values, df[target].values
    if model_type == 'rf':
        model = RandomForestRegressor(n_estimators=100, random_state=42, n_jobs=-1)
        # use all cores for cross‐val as well
        scores = cross_val_score(model, X, y, cv=cv, scoring='r2', n_jobs=-1)
    elif model_type == 'gp':
        kernel = Matern(nu=2.5) + WhiteKernel(noise_level=1.0)
        model = GaussianProcessRegressor(kernel=kernel, random_state=42)
        # GPR is inherently single‐threaded; wrap in joblib if desired
        with parallel_backend('threading', n_jobs=-1):
            scores = cross_val_score(model, X, y, cv=cv, scoring='r2', n_jobs=1)
    else:
        raise ValueError(f"Unknown model_type: {model_type}")

    # finally, fit on full data
    model.fit(X, y)
    return model, scores


def run_optuna_study(df: pd.DataFrame, features: list, target: str,
                     n_trials: int = 50, direction: str = 'maximize') -> optuna.Study:
    def objective(trial):
        params = {
            'n_estimators': trial.suggest_int('n_estimators', 50, 500),
            'max_depth': trial.suggest_int('max_depth', 2, 20),
            'min_samples_split': trial.suggest_int('min_samples_split', 2, 20)
        }
        model = RandomForestRegressor(**params, random_state=42, n_jobs=-1)
        X_train, X_test, y_train, y_test = train_test_split(
            df[features], df[target], test_size=0.2, random_state=42)
        model.fit(X_train, y_train)
        return model.score(X_test, y_test)

    study = optuna.create_study(direction=direction)
    # parallelize trials across all cores
    study.optimize(objective, n_trials=n_trials, n_jobs=-1)
    return study



def plot_pca_variance(ev: np.ndarray):
    plt.figure(); plt.plot(np.arange(1,len(ev)+1), ev, 'o-')
    plt.xlabel('PC'); plt.ylabel('Variance Ratio'); plt.title('PCA Variance'); plt.tight_layout(); plt.show()


import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
import pandas as pd

def plot_corr_matrix(df: pd.DataFrame, target: str = 'total_energy'):
    """
    From a raw DataFrame, compute a cleaned correlation matrix, sorted by
    absolute correlation with `target`, and display it as a heatmap.
    """
    # 1) select only numeric columns
    num = df.select_dtypes(include=[np.number]).copy()
    # 2) drop any columns with zero variance
    nonconst = num.loc[:, num.std(axis=0) > 0]
    # 3) compute correlations
    corr = nonconst.corr()
    # 4) re‑order so the highest |corr| with target come first
    order = corr[target].abs().sort_values(ascending=False).index
    corr = corr.loc[order, order]

    # 5) plot
    plt.figure(figsize=(10, 8))
    sns.heatmap(
        corr,
        cmap='viridis',
        center=0,
        vmin=-1,
        vmax=1,
        xticklabels=True,
        yticklabels=True
    )
    plt.xticks(rotation=90)
    plt.yticks(rotation=0)
    plt.title(f'Correlation Matrix (sorted by |corr| with {target})')
    plt.tight_layout()
    plt.show()

def print_key_summary_and_top_correlations(df: pd.DataFrame,
                                           metrics: list[str],
                                           target: str = 'total_energy',
                                           top_n: int = 10):
    """
    Prints mean/std for `metrics`, then shows the top_n variables
    most correlated with `target`.
    """
    # 1) Key‑metrics summary
    summary = summary_stats(df)[['mean','std']].loc[metrics]
    print('=== Key Metrics Summary ===')
    print(summary)

    # 2) Top correlations with target
    num      = df.select_dtypes(include=[np.number])
    nonconst = num.loc[:, num.std()>0]
    corr     = nonconst.corr()[target].sort_values(ascending=False)

    print(f'\n=== Top {top_n} correlations with {target} ===')
    print(corr.head(top_n))

def build_and_save_final_surrogate(df, features, target, best_params, fname):
    rf = RandomForestRegressor(
        n_estimators=best_params['n_estimators'],
        max_depth=best_params['max_depth'],
        min_samples_split=best_params['min_samples_split'],
        random_state=42,
        n_jobs=-1
    )
    rf.fit(df[features], df[target])
    import joblib
    joblib.dump(rf, fname)
    return rf



if __name__ == '__main__':
    try:
        import tkinter as tk
        from tkinter import filedialog
    except ImportError:
        tk, filedialog = None, None

    parser = argparse.ArgumentParser(description='Run LHS advanced analysis')
    parser.add_argument('--root',      default='./lhs_results', help='Path to lhs_results folder')
    parser.add_argument('--metrics',   help='Path to metric_log.pkl (flat mode)')
    parser.add_argument('--params',    help='Path to params.pkl (flat mode)')
    parser.add_argument('--target',    default='total_energy', help='Metric to model')
    parser.add_argument('--components',type=int, default=5, help='PCA components')
    parser.add_argument('--trials',    type=int, default=50, help='Optuna trials')
    args = parser.parse_args()

    # Resolve root path
    root_path = args.root
    if not os.path.isdir(root_path):
        if filedialog:
            print(f"Default root not found: {root_path}\nPlease select your lhs_results folder:")
            sel = filedialog.askdirectory(title='Select lhs_results directory')
            if sel:
                root_path = sel
            else:
                print("No directory selected. Exiting.")
                exit(1)
        else:
            print(f"Error: lhs_results folder not found at {root_path}")
            exit(1)

    # Load data
    if args.metrics and args.params:
        df = load_sweep_data(metrics=args.metrics, params=args.params)
    else:
        if not os.path.basename(root_path).lower().startswith('lhs_results'):
            alt = os.path.join(root_path, 'lhs_results')
            if os.path.isdir(alt):
                print(f"Detected inner 'lhs_results' folder at {alt}, switching to it.")
                root_path = alt
        df = load_sweep_data(root=root_path)

    # --- Key summary & top correlations ---
    key_metrics = ['total_energy', 'e_feedback', 'e_align', 'e_mod_align', 'e_curv', 'e_curv_mod']
    print_key_summary_and_top_correlations(df, key_metrics, target=args.target, top_n=10)

    # --- PCA analysis ---
    print(f"\n=== PCA ({args.components} comps) ===")
    pca_res = pca_analysis(df.select_dtypes(include=float), n_components=args.components)
    print('Explained variance:', pca_res['explained_variance'])
    plot_pca_variance(pca_res['explained_variance'])

    # --- Surrogate model ---
    numeric_cols = df.select_dtypes(include=[np.number]).columns.tolist()
    features = [c for c in numeric_cols if c not in ('step', args.target)]
    print(f"\n=== Surrogate Model for {args.target} (RF) ===")
    model, scores = fit_surrogate_model(df, features, target=args.target)
    print('CV R2 scores:', scores)

    # --- Optuna tuning ---
    print(f"\n=== Running Optuna ({args.trials} trials) ===")
    study = run_optuna_study(df, features, args.target, n_trials=args.trials)
    print('Best params:', study.best_params)
    print('Best R2:', study.best_value)

    # after Optuna:
    best = study.best_params
    final_rf = build_and_save_final_surrogate(df, features, args.target, best, 'surrogate_total_energy.joblib')

    # --- Print all 8 feature importances ---
    importances = pd.Series(final_rf.feature_importances_, index=features)
    importances_sorted = importances.sort_values(ascending=False)
    print("\nAll parameter importances (sorted):")
    for param, imp in importances_sorted.items():
        print(f"  {param}: {imp:.3f}")