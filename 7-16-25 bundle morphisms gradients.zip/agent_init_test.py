import numpy as np
import matplotlib.pyplot as plt

import config
from generalized_agents import create_smooth_fields

def main():
    # ——— Parameters —————————————————————————————
    H, W = 50, 50      # spatial grid size
    K    = 3           # fiber dimension
    seed = 42
    rng  = np.random.default_rng(seed)
    mask = np.ones((H, W), dtype=float)  # full support

    # ——— Generate fields —————————————————————————————
    mu_q, sigma_q, _, _ = create_smooth_fields(
        domain_size=(H, W),
        rng=rng,
        K=K,
        mask=mask
    )
    # mu_q: (H, W, K)
    # sigma_q: (H, W, K, K)

    # ——— Compute scalar summaries ————————————————————————
    det_sigma = np.linalg.det(sigma_q)  # (H, W)
    # differential entropy field
    h_field = 0.5 * np.log((2 * np.pi * np.e)**K * det_sigma + 1e-12)

    # ——— Plot everything —————————————————————————————
    fig, axes = plt.subplots(2, K+1, figsize=(4*(K+1), 8))

    # row 0: μ dims + det(Σ)
    for d in range(K):
        ax = axes[0, d]
        im = ax.imshow(mu_q[..., d], cmap="viridis")
        ax.set_title(f"μ_q dim {d}")
        fig.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
    ax = axes[0, K]
    im = ax.imshow(det_sigma, cmap="plasma")
    ax.set_title("det(Σ_q)")
    fig.colorbar(im, ax=ax, fraction=0.046, pad=0.04)

    # row 1: entropy and its histogram
    ax = axes[1, 0]
    im = ax.imshow(h_field, cmap="inferno",
                   vmin=h_field.min(), vmax=h_field.max())
    ax.set_title("differential entropy h(c)")
    fig.colorbar(im, ax=ax, fraction=0.046, pad=0.04)

    ax = axes[1, 1]
    ax.hist(h_field.ravel(), bins=50)
    ax.set_title("histogram of h(c)")
    ax.set_xlabel("h value")
    ax.set_ylabel("count")

    # hide unused subplots
    for j in range(2, K+1):
        axes[1, j].axis("off")

    plt.tight_layout()
    plt.show()

if __name__ == "__main__":
    main()
