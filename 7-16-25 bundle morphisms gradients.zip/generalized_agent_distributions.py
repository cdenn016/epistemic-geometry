# === generalized_agent_distributions.py ===
import numpy as np
import config


def get_fiber_basis(K: int) -> np.ndarray:
    """
    Return standard basis vectors for the fiber space ℝ^K.
    Output shape: (K, K)
    """
    return np.eye(K, dtype=np.float32)


def initialize_multivariate_gaussian_distribution(
    x_coords: np.ndarray,
    mu_field: np.ndarray,
    sigma_field: np.ndarray,
    mask: np.ndarray,
    log_eps: float = 1e-8
) -> np.ndarray:
    """
    Evaluate multivariate Gaussian distribution q(x) over fiber points,
    defined by spatially varying (μ, Σ), producing a probability field (H, W, K).

    Args:
        x_coords:    (K, D) fiber coordinates
        mu_field:    (H, W, D) spatial mean
        sigma_field: (H, W, D, D) spatial covariance
        mask:        (H, W) support mask
        log_eps:     small stabilizer

    Returns:
        dist:        (H, W, K) probability distribution
    """
    H, W, D = mu_field.shape
    K = x_coords.shape[0]

    # Broadcast to compute deltas
    x = x_coords[None, None, :, :]    # (1, 1, K, D)
    mu = mu_field[:, :, None, :]      # (H, W, 1, D)
    delta = x - mu                    # (H, W, K, D)

    # Regularize Σ
    eps_eye = log_eps * np.eye(D)
    sigma_reg = sigma_field + eps_eye[None, None, :, :]

    # Inverse Σ
    sigma_inv = np.zeros_like(sigma_reg)
    for i in range(H):
        for j in range(W):
            try:
                sigma_inv[i, j] = np.linalg.inv(sigma_reg[i, j])
            except np.linalg.LinAlgError:
                sigma_inv[i, j] = np.eye(D) * (1.0 / log_eps)
                print(f"[WARN] Σ⁻¹ fallback at ({i},{j})")

    # Mahalanobis distance
    mahal_sq = np.einsum("...kd,...de,...ke->...k", delta, sigma_inv, delta)  # (H, W, K)
    exponent = -0.5 * mahal_sq
    exponent -= np.max(exponent, axis=-1, keepdims=True)

    exp_vals = np.exp(exponent) * mask[..., None]
    norm = np.clip(np.sum(exp_vals, axis=-1, keepdims=True), log_eps, None)

    return exp_vals / norm


def initialize_uniform_distribution(
    x: np.ndarray = None,
    mask: np.ndarray = None,
    dtype=np.float32
) -> np.ndarray:
    """
    Initialize uniform distribution over K fiber points, with optional spatial mask.

    Args:
        x:     optional array to infer spatial shape
        mask:  optional support mask (H, W)
        dtype: float32 or float64

    Returns:
        base: (H, W, K) uniform distribution
    """
    K = config.K
    if mask is not None:
        shape = mask.shape
    elif x is not None and x.ndim >= 2:
        shape = x.shape[:-1]
    else:
        shape = config.domain_size

    base = np.full((*shape, K), 1.0 / K, dtype=dtype)
    return base * mask[..., None] if mask is not None else base
