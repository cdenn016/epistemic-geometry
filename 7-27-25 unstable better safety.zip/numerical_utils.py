# -*- coding: utf-8 -*-
"""
Created on Sun Jul 13 13:06:16 2025

@author: chris and christine
"""
import sys
import numpy as np
import warnings
from collections import defaultdict

from joblib import Parallel, delayed
from numpy.linalg import LinAlgError  # ✅ Needed for exception handling

import config
from scipy.linalg import logm  # Only if safe_logm is used



# Global counters
fallback_counter = defaultdict(int)

#=======================================
#
#         Reporting/Logging
#
#======================================

def clip_phi_field(phi, threshold=None, norm_type=2, verbose=False, label="φ"):
    """
    Clips φ values before applying exp(φ), to avoid numerical instability.

    Args:
        phi       : (..., d) Lie algebra field
        threshold : float or None — clip if norm > threshold
        norm_type : int or float — L2 (2), L1 (1), or ∞
        verbose   : bool — print clipping info
        label     : str — for diagnostics

    Returns:
        clipped φ
    """
    if threshold is None:
        return phi

    norm = np.linalg.norm(phi.ravel(), ord=norm_type)
    if norm > threshold:
        scale = threshold / (norm + 1e-12)
        if verbose:
            print(f"[Clipping {label}] norm phi = {norm:.2e} → {threshold} (scale = {scale:.2e})")
        return phi * scale
    return phi



import numpy as np

def sanitize_eta2(eta2, eps=1e-6):
    """
    Symmetrize and ensure η₂ is SPD by clipping eigenvalues and normalizing trace.

    Args:
        eta2 : (..., K, K) matrix (batchable)
        eps  : minimum eigenvalue (default: 1e-6)

    Returns:
        eta2_sanitized : (..., K, K) safe SPD matrix with Tr = K
    """
    # 1. Symmetrize
    eta2_sym = 0.5 * (eta2 + np.swapaxes(eta2, -1, -2))

    # 2. Eigendecomposition
    eigvals, eigvecs = np.linalg.eigh(eta2_sym)

    # 3. Clip eigenvalues
    eigvals_clipped = np.clip(eigvals, eps, None)

    # 4. Normalize trace to K (dimensionality)
    K_dim = eta2.shape[-1]
    trace_clipped = np.sum(eigvals_clipped, axis=-1, keepdims=True)
    eigvals_scaled = eigvals_clipped * (K_dim / trace_clipped)

    # 5. Reconstruct sanitized η₂
    eta2_sanitized = np.matmul(eigvecs * eigvals_scaled[..., None, :], np.swapaxes(eigvecs, -1, -2))

    return eta2_sanitized


def safe_transport_eta2(eta2_src, Omega, eps=1e-8, clip_trace=10.0):
    """
    Transport η₂ via η₂^t = Ω η₂ Ωᵀ, then symmetrize and sanitize.

    Args:
        eta2_src   : (..., K, K) source η₂ (should be neg-definite)
        Omega      : (..., K, K) gauge transport operator
        eps        : regularization constant for sanitize_eta2
        clip_trace : max allowed |trace| after transport (optional)

    Returns:
        eta2_t     : (..., K, K) safely transported η₂
    """
    # Transport: η₂^t = Ω η₂ Ωᵀ
    eta2_t = np.einsum("...ik,...kl,...jl->...ij", Omega, eta2_src, Omega)

    # Symmetrize to fix numeric drift
    eta2_t = 0.5 * (eta2_t + np.swapaxes(eta2_t, -1, -2))

    # Optional trace clipping (keeps belief mass finite)
    tr = np.trace(eta2_t, axis1=-2, axis2=-1)[..., None, None]
    if clip_trace is not None:
        scale = np.minimum(1.0, clip_trace / (np.abs(tr) + eps))
        eta2_t *= scale

    # Sanitize: ensure SPD after symmetrization
    eta2_t = sanitize_eta2(eta2_t, eps=eps)

    return eta2_t


def log_fallback(tag: str, msg: str, count_key: str = None, error: bool = False):
    """
    Standardized fallback logger.

    Args:
        tag       : str — context tag (e.g. 'safe_inv', 'logm', etc.)
        msg       : str — fallback message
        count_key : str — key for fallback_counter increment
        error     : bool — whether to raise RuntimeError (if fail_on_fallback)

    Behavior:
        - Increments fallback counter
        - Warns or raises
        - Flushes stdout
    """
    full_msg = f"[{tag}] {msg}"

    if count_key:
        fallback_counter[count_key] += 1
        full_msg = f"[{tag}] Fallback #{fallback_counter[count_key]}: {msg}"

    if getattr(config, "fail_on_fallback", False) or error:
        raise RuntimeError(full_msg)
    else:
        warnings.warn(full_msg, RuntimeWarning)
        sys.stdout.flush()


def reset_fallback_counters():
    """Call this at the start of each simulation/run."""
    fallback_counter.clear()

def report_and_maybe_fail():
    """Inspect counters against config thresholds."""
    invs = fallback_counter.get("safe_inv", 0)
    logs = fallback_counter.get("safe_logdet", 0)
    if invs or logs:
        msg = (
            f"[Fallback Summary] safe_inv: {invs}, safe_logdet: {logs}"
            f"{', raising error' if config.fail_on_fallback else ''}"
        )
        # Always log
        print(msg)
    # Fail if configured
    if config.fail_on_fallback:
        if invs > 0 or logs > 0:
            raise RuntimeError("Numerical fallback occurred under strict mode.")
    # Or threshold-based
    if invs > config.max_safe_inv_fallbacks:
        raise RuntimeError(f"Exceeded max_safe_inv_fallbacks ({invs})")
    if logs > config.max_safe_logdet_fallbacks:
        raise RuntimeError(f"Exceeded max_safe_logdet_fallbacks ({logs})")

def report_fallback_summary():
    print("\n──── Fallback Summary ────")
    for key, count in fallback_counter.items():
        print(f"{key:<25} → {count} fallback(s)")
    print("──────────────────────────\n")


#===============================================
#
#        Checks 
#
#===============================================

def check_shape_consistency(mu_q, sigma_q, mu_p, sigma_p, Phi, Phi_tilde):
    assert mu_q.shape[:-1] == sigma_q.shape[:-2], f"Shape mismatch: mu_q {mu_q.shape} vs. sigma_q {sigma_q.shape}"
    assert mu_p.shape[:-1] == sigma_p.shape[:-2], f"Shape mismatch: mu_p {mu_p.shape} vs. sigma_p {sigma_p.shape}"
    assert Phi.shape[-1] == mu_q.shape[-1], f"Shape mismatch: Phi {Phi.shape} vs. mu_q {mu_q.shape}"
    assert Phi_tilde.shape[-1] == mu_p.shape[-1], f"Shape mismatch: Phi_tilde {Phi_tilde.shape} vs. mu_p {mu_p.shape}"


def check_spd_field(field: np.ndarray, tol=1e-8) -> bool:
    """
    Verifies whether a full field (H, W, K, K) is SPD everywhere.
    Returns True if all matrices pass, False otherwise.
    """
    H, W, K, _ = field.shape
    
    for i in range(H):
        for j in range(W):
            if not is_spd_matrix(field[i, j], tol=tol):
                return False
    return True


def is_spd_matrix(A: np.ndarray, tol=1e-8) -> bool:
    """
    Check whether a matrix A is symmetric positive definite (SPD).
    """
    if not np.allclose(A, A.T, atol=tol):
        return False
    try:
        np.linalg.cholesky(A)
        return True
    except LinAlgError:
        return False
    
def condition_check_and_fallback(sigma, max_cond=1e6):
    """
    Checks condition number of matrix and falls back to scaled identity if ill-conditioned.

    Args:
        sigma   : (K, K) SPD matrix to validate
        max_cond: float, maximum allowed condition number before fallback

    Returns:
        (K, K) ndarray — safe matrix (original or fallback)
    """
    assert sigma.shape[-2] == sigma.shape[-1], "[condition_check] Matrix must be square"
    K = sigma.shape[-1]

    try:
        cond = np.linalg.cond(sigma)
        if not np.isfinite(cond) or cond > max_cond:
            raise LinAlgError(f"Condition number {cond:.2e} exceeds max_cond {max_cond}")
        return sigma

    except LinAlgError as e:
        log_fallback(
            tag="condition_check",
            msg=f"{str(e)} → using {config.sanitize_fallback_value} · I",
            count_key="condition_check"
        )
        return np.eye(K) * config.sanitize_fallback_value



   
        
#====================================================
#
#                 Safety Ops
#
#=====================================================

def safe_omega_inv(M):
    """
    Safely compute the inverse of Omega with condition check and fallback.
    Returns the inverse matrix or a regularized identity matrix if the inversion fails.
    """
    try:
        # Ensure that Omega has the correct shape before inversion
        return condition_check_and_fallback(M, max_cond=1e8)
    except RuntimeError as e:
        log_fallback("safe_omega_inv", str(e), count_key="omega_inv")
        # Ensure fallback identity matches the dimensionality of M
        return np.eye(M.shape[-1])  # This assumes M is square and invertible.

import numpy as np
from numpy.linalg import LinAlgError

def safe_inv(Sigma, eps=1e-8, max_eig=1e3):
    """
    Safely invert Sigma by clipping eigenvalues to avoid instability.
    Adds stabilizer `eps` and clips large/small eigenvalues to prevent explosion.
    """
    K = Sigma.shape[-1]
    try:
        # Eigendecomposition
        eigvals, eigvecs = np.linalg.eigh(Sigma)
        eigvals_clipped = np.clip(eigvals, eps, max_eig)

        # Reconstruct inverse: V Λ⁻¹ Vᵀ
        inv_eigvals = 1. / eigvals_clipped
        inv = np.einsum("...ik,...k,...jk->...ij", eigvecs, inv_eigvals, eigvecs)
        inv = 0.5 * (inv + np.swapaxes(inv, -1, -2))

        return inv

    except LinAlgError as e:
        log_fallback("safe_inv", f"returning identity * {config.sanitize_fallback_value}", count_key="safe_inv")
        return np.eye(K) * config.sanitize_fallback_value




def _sanitize_one_sigma(S, eps=1e-6):
    """
    Sanitize a single covariance matrix to ensure it's symmetric positive-definite (SPD).

    Returns:
        (S_sanitized, clipped): sanitized matrix and boolean flag indicating if it was modified
    """
    S = 0.5 * (S + S.T)  # ensure symmetry

    # First line of defense: handle invalid or pathological cases
    if not np.all(np.isfinite(S)) or np.trace(S) < eps or np.any(np.diag(S) <= 0):
        return np.eye(S.shape[0]) * eps, True

    try:
        eigvals, eigvecs = np.linalg.eigh(S)
    except np.linalg.LinAlgError:
        return np.eye(S.shape[0]) * eps, True

    clipped = np.any(eigvals < eps)
    eigvals_clipped = np.clip(eigvals, eps, None)

    if clipped:
        S = eigvecs @ np.diag(eigvals_clipped) @ eigvecs.T
        S = 0.5 * (S + S.T)  # re-symmetrize

    return S, clipped


def sanitize_sigma(Sigma, eps=1e-6, debug=False, n_jobs=None, parallel_threshold=50):
    """
    Sanitize a batch of covariance matrices to ensure SPD.

    Parameters:
        Sigma: (..., K, K) ndarray — batch of covariances
        eps: minimum eigenvalue threshold
        debug: if True, prints a summary if any matrices are clipped
        n_jobs: number of parallel workers (default: config.num_cores or 1)
        parallel_threshold: min number of matrices before enabling parallelization

    Returns:
        Sanitized SPD matrices with same shape as input.
    """
    shape = Sigma.shape
    flat_sigma = Sigma.reshape(-1, shape[-2], shape[-1])
    n_total = flat_sigma.shape[0]
    n_jobs = n_jobs or getattr(config, "num_cores", 1)

    if n_total < parallel_threshold or n_jobs == 1:
        results = [_sanitize_one_sigma(S, eps) for S in flat_sigma]
    else:
        from joblib import parallel_backend
        with parallel_backend("threading"):
            results = Parallel(n_jobs=n_jobs)(
                delayed(_sanitize_one_sigma)(S, eps) for S in flat_sigma
            )

    Sigma_out, clipped_flags = zip(*results)
    if debug:
        n_clipped = sum(clipped_flags)
        if n_clipped > 0:
            print(f"[SPD sanitize] Clipped {n_clipped} / {n_total} matrices to eps={eps:.1e}")

    out = np.stack(Sigma_out, axis=0).astype(Sigma.dtype).reshape(shape)
    return out

def safe_log(x, eps: float = 1e-12):
    """
    Numerically stable log(x), clipping to avoid -inf.

    Args:
        x   : float or np.ndarray — input value(s)
        eps : float — minimum threshold to avoid log(0)

    Returns:
        float or np.ndarray — log(max(x, eps)), preserving dtype
    """
    x = np.asarray(x)
    clipped = np.clip(x, eps, None).astype(x.dtype, copy=False)
    return np.log(clipped)


def safe_logm(M, fallback_value=None, imag_tol=1e-10, context="Ω"):
    try:
        logM = logm(M)
        imag_norm = np.linalg.norm(np.imag(logM), ord="fro")
        if imag_norm > imag_tol:
            log_fallback("safe_logm", f"{context}: ‖Im(logm)‖={imag_norm:.2e} > tol={imag_tol}")
        return np.real_if_close(logM, tol=imag_tol)
    except Exception as e:
        log_fallback("safe_logm", f"{context}: logm failed ({e})", count_key="safe_logm")
        K = M.shape[-1]
        return fallback_value if fallback_value is not None else np.zeros((K, K), dtype=M.dtype)



from numpy.linalg import LinAlgError

def safe_logdet(Sigma, eps=1e-8, alpha=1e-2):
    K = Sigma.shape[-1]
    eye = eps * np.eye(K, dtype=Sigma.dtype)
    eye = eye.reshape((1,) * (Sigma.ndim - 2) + (K, K))
    Sigma_reg = Sigma + eye

    try:
        sign, ld = np.linalg.slogdet(Sigma_reg)
        if np.any(sign <= 0):
            raise LinAlgError("Non-positive determinant(s)")
        return ld
    except LinAlgError:
        # Dynamic fallback using trace
        trace = np.trace(Sigma, axis1=-2, axis2=-1)  # (...,)
        fallback_value = alpha * (trace / K + eps)   # avoid zero
        fallback_logdet = K * np.log(fallback_value)
        log_fallback("safe_logdet", "dynamic trace fallback", count_key="safe_logdet")
        return fallback_logdet



    