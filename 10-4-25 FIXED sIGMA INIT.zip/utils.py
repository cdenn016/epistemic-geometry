# -*- coding: utf-8 -*-
"""
Created on Sun Sep 14 14:24:12 2025

@author: chris and christine
"""

import numpy as np

from core.numerical_utils import safe_inv, sanitize_sigma, push_gaussian, safe_omega_inv
from typing import Any


# =========================
# Basic, stable miscellany
# =========================


def _aid(a: Any) -> int:
    """Stable agent id (required)."""
    aid = getattr(a, "id", None)
    if aid is None:
        raise ValueError("[transport_cache] agent is missing a stable `id`")
    return int(aid)


def mean_norm(arr):
    if arr is None:
        return np.nan
    x = np.asarray(arr)
    if x.ndim >= 3:
        return float(np.nanmean(np.linalg.norm(x, axis=-1)))
    if x.ndim == 2:
        return float(np.nanmean(np.abs(x)))
    return np.nan

def _check_finite(name, x):
    if not np.all(np.isfinite(x)):
        n_nan = int(np.isnan(x).sum())
        n_inf = int(np.isinf(x).sum())
        raise FloatingPointError(f"[vfe_mu_sigma_grads] {name} has non-finite values "
                                 f"(nan={n_nan}, inf={n_inf}).")



# =========================
#         Masks
# =========================




# --- MASKS ---------------------------------------------------------------

def make_soft_mask(
    center: tuple[int, ...] | int | None,
    radius: float | tuple[float, ...],
    domain_size: tuple[int, ...],
    *,
    cutoff: float | None = None,       # interpreted as support_tau (0<τ<1)
    dtype: np.dtype | None = None,
    return_bool: bool = False,
    feather: float | None = None,      # optional smooth ramp half-width in px
    soft_cut: bool = True,             # use smooth ramp instead of hard zeroing
):
    """
    N-D soft (Gaussian-like) mask on a periodic hypercube.
    m(x) = exp( - sum_d (δ_d / r_d)^2 ), with periodic min-image δ_d.

    radius semantics:
      - r_d is the 1/e falloff radius along axis d, i.e. m=exp(-1) at |δ_d|=r_d.
      - If you want m=cutoff at |δ|=R, pass r = R / sqrt(log(1/cutoff)).

    If soft_cut=True and feather>0, a smoothstep is used around 'cutoff' to avoid kinks.
    """
    import numpy as np
    import core.config as _config

    S = tuple(int(s) for s in domain_size)
    D = len(S)

    if dtype is None:
        dtype = getattr(_config, "dtype", np.float64)

    if cutoff is None:
        cutoff = float(getattr(_config, "support_tau", 1e-6))
    cutoff = float(cutoff)

    # ---- normalize center (periodic) ----
    if center is None:
        c = tuple(s // 2 for s in S)
    elif np.isscalar(center):
        c = (int(center),) * D
    else:
        c = tuple(int(x) for x in center)
        if len(c) < D:
            c = tuple(c) + tuple(S[i] // 2 for i in range(len(c), D))
        elif len(c) > D:
            c = tuple(c[:D])
    c = tuple((ci % si) for ci, si in zip(c, S))

    # ---- normalize radius ----
    if np.isscalar(radius):
        r = (float(radius),) * D
    else:
        r = tuple(float(x) for x in radius)
        if len(r) < D:
            r = tuple(r) + (float(r[-1]),) * (D - len(r))
        elif len(r) > D:
            r = tuple(r[:D])
    eps = np.finfo(dtype).eps
    r = tuple(max(abs(x), eps) for x in r)

    # ---- build min-image squared distance in scaled coords ----
    grids = np.ogrid[tuple(slice(0, s) for s in S)]
    rho2 = 0.0
    for d in range(D):
        g = grids[d]
        sz = S[d]
        delta = np.abs(g - c[d])
        delta = np.minimum(delta, sz - delta)   # periodic min-image
        rho2 = rho2 + (delta / r[d])**2

    m = np.exp(-rho2, dtype=dtype).astype(dtype, copy=False)

    # ---- soft or hard cutoff ----
    if soft_cut and cutoff > 0.0:
        # Smoothly push values below cutoff towards 0 over a 'feather' band.
        # If feather is None, pick a default so that the 10–90% transition spans ~feather px.
        # Use a smoothstep on the *value* axis (not distance) for simplicity:
        #   t = clamp((m - (cutoff - δ)) / (2δ), 0, 1); m <- m * (3t^2 - 2t^3)
        # Choose δ so transition width is gentle in value-space.
        delta_val = 0.5 * (1.0 - cutoff) if feather is None else min(0.49, float(feather))
        lo = max(0.0, cutoff - delta_val)
        hi = min(1.0, cutoff + delta_val)
        # normalize to [0,1]
        t = (m - lo) / max(1e-12, (hi - lo))
        t = np.clip(t, 0.0, 1.0)
        smooth = t*t*(3.0 - 2.0*t)   # C1 smoothstep
        m = m * smooth
    elif (not soft_cut) and cutoff > 0.0:
        m = np.where(m < cutoff, 0.0, m)

    m = m.astype(dtype, copy=False)

    if return_bool:
        # boolean support relative to cutoff
        return m, (m > cutoff)
    return m




def _joint_mask(a, b, *, tau: float, as_vector: bool = True):
    """
    Joint support of two agents' masks (broadcast-safe, N-D).
    Returns:
      - (*S,1) float32 if as_vector=True  (legacy "float3"-style channel)
      - (*S,)  bool    if as_vector=False
    """
    ma = mask_hw(a, tau=tau, mode="bool2")   # (*S_a,) bool
    mb = mask_hw(b, tau=tau, mode="bool2")   # (*S_b,) bool

    # Broadcast to common spatial shape S
    try:
        S = np.broadcast(ma, mb).shape
    except Exception as e:
        raise ValueError(f"_joint_mask: shapes not broadcastable: {ma.shape} vs {mb.shape}") from e

    if ma.shape != S:
        ma = np.broadcast_to(ma, S)
    if mb.shape != S:
        mb = np.broadcast_to(mb, S)

    m = ma & mb
    return (m[..., None].astype(np.float32, copy=False)) if as_vector else m


def mask_hw(x, *, tau: float, mode: str = "float3"):
    """
    N-D mask normalizer (broadcast- & dtype-safe).

    Accepts:
      - x.mask or x (array-like), any shape that's per-site or per-site with a singleton channel
        e.g. (*S,), (*S,1). (Legacy name kept for compatibility.)

    Modes:
      - "bool2"  -> (*S,)   bool
      - "float3" -> (*S,1)  float32  (good for broadcasting with per-site vectors)
      - "vec"    -> (|S|,)  bool (raveled)
    """
    m = getattr(x, "mask", x)
    m = np.asarray(m)

    # Squeeze a singleton channel if present
    if m.ndim >= 1 and m.shape[-1] == 1:
        m = m[..., 0]

    # Scalar fallback (rare): promote to 1-D
    if m.ndim == 0:
        m = m.reshape(1)

    # Validate finiteness if float/integers
    if np.issubdtype(m.dtype, np.floating) or np.issubdtype(m.dtype, np.integer):
        if not np.isfinite(m).all():
            n_bad = int(m.size - np.isfinite(m).sum())
            raise FloatingPointError(f"mask_hw: non-finite values in mask ({n_bad} cells).")

    # Threshold to bool support if not already boolean
    mb = m if (m.dtype == bool) else (m.astype(np.float32, copy=False) > float(tau))

    if mode == "bool2":
        return mb.astype(bool, copy=False)
    if mode == "float3":
        return mb.astype(np.float32, copy=False)[..., None]
    if mode == "vec":
        return mb.astype(bool, copy=False).ravel()

    raise ValueError(f"mask_hw: unknown mode={mode!r}")





def push_neighbor_stats(agent_j, sigma_key: str, Omega_ij: np.ndarray, eps: float):
    """
    Returns (mu_j_t, Sigma_j_t, Sigma_j_t_inv) in agent-i frame.
    Fast-path tries inverse-push of precision; fallback pushes covariance.
    """
    mu_j = np.asarray(getattr(agent_j, sigma_key.replace("sigma", "mu")), np.float32)

    inv_key = sigma_key.replace("_field", "_inv")
    S_inv = getattr(agent_j, inv_key, None)

    # Try inverse-push of precision first
    if S_inv is not None:
        S_inv = np.asarray(S_inv, np.float32)
        if S_inv.size and np.all(np.isfinite(S_inv)):
            Oinv   = safe_omega_inv(Omega_ij, eps=1e-6)
            Oinv_T = np.swapaxes(Oinv, -1, -2)
            S_inv_t = np.einsum("...ik,...kl,...jl->...ij", Oinv_T, S_inv, Oinv, optimize=True)

            # Build Σ_j→i once (stable): (S_inv_t)^{-1}
            Sigma_t = safe_inv(sanitize_sigma(S_inv_t), eps=max(eps, 1e-12))

            mu_t = np.einsum("...ij,...j->...i", Omega_ij, mu_j, optimize=True)
            return mu_t.astype(np.float32, copy=False), Sigma_t.astype(np.float32, copy=False), S_inv_t.astype(np.float32, copy=False)

    # Fallback: push covariance then invert once
    Sigma_j = sanitize_sigma(np.asarray(getattr(agent_j, sigma_key), np.float32), eps=eps)
    mu_t, Sigma_t, Sigma_t_inv = push_gaussian(
        mu=mu_j, Sigma=Sigma_j, M=Omega_ij, eps=eps,
        return_inv=True, assume_orthogonal=True, sanitize_input=False
    )
    return mu_t.astype(np.float32, copy=False), Sigma_t.astype(np.float32, copy=False), Sigma_t_inv.astype(np.float32, copy=False)




def zero_all_gradients(agent):
    """
    Zero (and if missing, create) all gradient buffers,
    keeping legacy aliases in sync and ensuring arrays are writeable.
    """
    def ensure_buf(name, like):
        arr = getattr(agent, name, None)
        if arr is None and like is not None:
            arr = np.zeros_like(like)
        elif arr is not None and not arr.flags.writeable:
            arr = np.array(arr, copy=True)
        setattr(agent, name, arr)
        return arr

    # Canonical grads (create from fields if needed)
    g_mu_q   = ensure_buf("grad_mu_q",    getattr(agent, "mu_q_field", None))
    g_sg_q   = ensure_buf("grad_sigma_q", getattr(agent, "sigma_q_field", None))
    g_mu_p   = ensure_buf("grad_mu_p",    getattr(agent, "mu_p_field", None))
    g_sg_p   = ensure_buf("grad_sigma_p", getattr(agent, "sigma_p_field", None))
    g_phi    = ensure_buf("grad_phi",       getattr(agent, "phi", None))
    g_phit   = ensure_buf("grad_phi_tilde", getattr(agent, "phi_model", None))
 
    # Keep legacy aliases in sync (as references, not copies)
    if g_mu_q is not None:
        agent.grad_mu_q_field = g_mu_q
    if g_sg_q is not None:
        agent.grad_sigma_q_field = g_sg_q
    if g_mu_p is not None:
        agent.grad_mu_p_field = g_mu_p
    if g_sg_p is not None:
        agent.grad_sigma_p_field = g_sg_p

    # Zero safely
    for arr in (g_mu_q, g_sg_q, g_mu_p, g_sg_p, g_phi, g_phit):
        if isinstance(arr, np.ndarray):
            arr.fill(0)


# =========================
# Regularization & morphism aids
# =========================


def reg_weights(field: str, *, ctx=None, config=None) -> tuple[float, float, float, float]:
    """
    Return (curv_w, fisher_w, mass_w, cpl_w) for the given field ('phi' or 'phi_model').

    Precedence for each weight:
        1) ctx.step_cfg[name]
        2) ctx.config[name]
        3) module-level config.<name>
        4) 0.0
    """
    
    from runtime_context import cfg_get
    
    if field == "phi":
        curv_w   = float(cfg_get(ctx, "curvature_weight", 0))
        fisher_w = float(cfg_get(ctx, "fisher_geometry_weight", 0.0))
        # allow legacy "belief_mass" alias
        mass_w   = float(cfg_get(ctx, "belief_mass", 0.0))
        cpl_w    = float(cfg_get(ctx, "phi_coupling_weight", 0.0))

    elif field == "phi_model":
        curv_w   = float(cfg_get(ctx, "model_curvature_weight", 0.0))
        fisher_w = float(cfg_get(ctx, "fisher_model_geometry_weight", 0.0))
        
        mass_w   = float(cfg_get(ctx, "model_mass", 0.0))
        cpl_w    = float(cfg_get(ctx, "phi_coupling_weight", 0))
    else:
        raise ValueError(f"Invalid field: {field}")
    
    return curv_w, fisher_w, mass_w, cpl_w



# === fiber view =============================================================

def fiber_view(agent, field: str, *, require_generators: bool = False):
    """
    Unified access to a fiber (N-D safe).

    Returns a dict:
      {
        "which": "q"|"p",
        "mu":     S+(K,),
        "Sigma":  S+(K,K),
        "phi":    S+(3,)  or (3,) if stored globally,
        "G":      (3,K,K) or None,
        "K":      int,
        "S":      tuple  # spatial shape
      }

    Accepts legacy attribute names and validates shapes/finiteness.
    """
    import numpy as np

    if field not in ("phi", "phi_model"):
        raise ValueError(f"fiber_view: unknown field {field!r} (expected 'phi' or 'phi_model')")

    which = "q" if field == "phi" else "p"

    # --- spatial shape S from mask (fail-fast) ---
    if not hasattr(agent, "mask") or agent.mask is None:
        raise AttributeError("fiber_view: agent.mask is missing or None")
    S = tuple(np.asarray(agent.mask).shape)
    if len(S) == 0:
        raise ValueError("fiber_view: agent.mask must be at least 1-D (per-site mask)")

    # --- pull fields with legacy fallbacks ---
    mu   = getattr(agent, "mu_q_field"   if which == "q" else "mu_p_field",   None)
    Sig  = getattr(agent, "sigma_q_field"if which == "q" else "sigma_p_field",None)

    # allow either *.phi_field or *.phi
    phi_attr_main = "phi" if which == "q" else "phi_model"
    phi = getattr(agent, f"{phi_attr_main}_field", getattr(agent, phi_attr_main, None))

    G = getattr(agent, "generators_q" if which == "q" else "generators_p", None)
    if G is None:
        G = getattr(agent, "G_q" if which == "q" else "G_p", None)

    if mu is None or Sig is None or phi is None:
        raise AttributeError(f"fiber_view: agent missing fields for fiber '{which}'")

    mu  = np.asarray(mu,  np.float32)
    Sig = np.asarray(Sig, np.float32)
    phi = np.asarray(phi, np.float32)

    # --- shape checks for μ, Σ ---
    if mu.ndim < 1 or mu.shape[-1] <= 0:
        raise ValueError(f"fiber_view: bad mu shape {mu.shape}")
    if tuple(mu.shape[:-1]) != S:
        raise ValueError(f"fiber_view: mu spatial shape {mu.shape[:-1]} != mask shape {S}")
    K = int(mu.shape[-1])

    if Sig.ndim < 2 or tuple(Sig.shape[:-2]) != S or Sig.shape[-2:] != (K, K):
        raise ValueError(f"fiber_view: Sigma shape {Sig.shape} incompatible with mu (expects {S+(K,K)})")

    # --- phi may be S+(3,) or global (3,) ---
    if phi.shape[-1] != 3:
        raise ValueError(f"fiber_view: phi last dim must be 3, got {phi.shape}")
    if not (tuple(phi.shape[:-1]) == S or phi.ndim == 1):
        raise ValueError(f"fiber_view: phi spatial shape {phi.shape[:-1]} incompatible with {S} (or global (3,))")

    # --- finiteness checks ---
    if not np.isfinite(mu).all():   raise FloatingPointError("fiber_view: non-finite values in mu")
    if not np.isfinite(Sig).all():  raise FloatingPointError("fiber_view: non-finite values in Sigma")
    if not np.isfinite(phi).all():  raise FloatingPointError("fiber_view: non-finite values in phi")

    # --- generators (optional) ---
    G_arr = None
    if G is not None:
        G_arr = np.asarray(G, np.float32)
        if G_arr.shape != (3, K, K):
            raise ValueError(f"fiber_view: generators shape {G_arr.shape} must be (3,{K},{K})")
        if not np.isfinite(G_arr).all():
            raise FloatingPointError("fiber_view: non-finite values in generators")
    elif require_generators:
        raise AttributeError(f"fiber_view: generators missing for fiber '{which}'")

    return {
        "which": which,
        "mu": mu,
        "Sigma": Sig,
        "phi": phi,
        "G": G_arr,
        "K": K,
        "S": S,
    }


# =========================
# Linear algebra helpers
# =========================


def _ensure_q_to_p_shape(X, Kp, Kq):
    """Φ0: q→p must be (Kp, Kq). Auto-transpose if (Kq, Kp)."""
    X = np.asarray(X, np.float32)
    if X.shape == (Kp, Kq): return X
    if X.shape == (Kq, Kp): return X.T
    raise ValueError(f"Φ0 wrong shape {X.shape}; expected {(Kp, Kq)} or {(Kq, Kp)}")

def _ensure_p_to_q_shape(X, Kq, Kp):
    """Φ̃0: p→q must be (Kq, Kp). Auto-transpose if (Kp, Kq)."""
    X = np.asarray(X, np.float32)
    if X.shape == (Kq, Kp): return X
    if X.shape == (Kp, Kq): return X.T
    raise ValueError(f"Φ̃0 wrong shape {X.shape}; expected {(Kq, Kp)} or {(Kp, Kq)}")

def build_c_mapping_q2p(Phi_tilde_0, generators_q, generators_p, eps=1e-8):
    """
    Build linear map C (d_p x d_q) so that Ad_{Φ̃0}(G_q^a) ≈ sum_b C_{ba} G_p^b
    under Frobenius projection onto p-basis.
    """
    d_q, Kq, _ = generators_q.shape
    d_p, Kp, _ = generators_p.shape
    assert Phi_tilde_0.shape[-2:] == (Kq, Kp), "Phi_tilde_0 must be (K_q, K_p)"

    # Gram of p-basis
    Gp = np.zeros((d_p, d_p), dtype=generators_p.dtype)
    for b in range(d_p):
        for c in range(d_p):
            Gp[b, c] = np.tensordot(generators_p[b], generators_p[c])
    Gp += eps * np.eye(d_p, dtype=Gp.dtype)
    Gp_inv = safe_inv(Gp)

    Phi0    = Phi_tilde_0
    Phi0_inv = safe_inv(Phi0, eps=eps)

    C = np.zeros((d_p, d_q), dtype=generators_p.dtype)
    for a in range(d_q):
        H_a = np.einsum("ik,kl,lj->ij", Phi0, generators_q[a], Phi0_inv)
        h = np.array([np.tensordot(generators_p[b], H_a) for b in range(d_p)], dtype=H_a.dtype)
        C[:, a] = Gp_inv @ h
    return C



#===================================
# 
#         MU/SIGMA GRADIENT ACCUMULATE
# 
#=====================================


def _build_id_index_map(agents):
    """Map unique agent IDs -> indices; fail if duplicates/missing IDs."""
    ids = []
    for i, a in enumerate(agents):
        try:
            ids.append(int(getattr(a, "id", i)))
        except Exception as e:
            raise ValueError(f"_build_id_index_map: agent {i} has non-integer id") from e
    if len(set(ids)) != len(ids):
        # find duplicates for a clearer error
        seen, dups = set(), set()
        for x in ids:
            (dups if x in seen else seen).add(x)
        raise ValueError(f"_build_id_index_map: duplicate agent ids: {sorted(dups)}")
    return {ids[i]: i for i in range(len(agents))}


def iter_overlapping_neighbors(agent_i, agents, *, support_eps: float, symmetric: bool = True):
    """
    Yield (j_idx, agent_j, overlap_mask_bool[*S]) for neighbors of agent_i whose masks overlap.
    *S is the N-D spatial shape (e.g., (X,Y) for 2D, (X,Y,Z) for 3D, etc).

    If symmetric=True, emit each undirected edge once using ID order (i_id < j_id).
    Requires agent_i.neighbors = [{ "id": <neighbor id>, "overlap": <count> }, ...]
    """
    import numpy as np

    nb_list = getattr(agent_i, "neighbors", None) or ()
    # Stop iteration early if there are no neighbors
    if not nb_list:
        return

    id_index = _build_id_index_map(agents)
    n_agents = len(agents)

    try:
        i_id = int(getattr(agent_i, "id"))
    except Exception as e:
        raise ValueError("iter_overlapping_neighbors: agent_i must have an integer-like `id`.") from e

    # N-D boolean mask for i
    mask_i = mask_hw(agent_i, tau=support_eps, mode="bool2")  # (*S,) bool

    for nb in nb_list:
        if not isinstance(nb, dict) or "id" not in nb:
            raise ValueError("iter_overlapping_neighbors: neighbor entries must be dicts with key 'id'.")

        try:
            j_id = int(nb["id"])
        except Exception as e:
            raise ValueError(f"iter_overlapping_neighbors: neighbor id {nb['id']!r} is not integer-like.") from e

        if j_id == i_id:
            continue  # skip self

        if symmetric and not (i_id < j_id):
            continue  # enforce one directed emission per undirected pair

        # Resolve j index via the ID map
        j_idx = id_index.get(j_id)
        if j_idx is None or not (0 <= j_idx < n_agents):
            raise ValueError(f"iter_overlapping_neighbors: neighbor id {j_id} not found among agents.")

        agent_j = agents[j_idx]
        mask_j = mask_hw(agent_j, tau=support_eps, mode="bool2")  # (*S,) bool

        # Fail-fast on shape mismatches (avoid silent broadcasting)
        if mask_i.shape != mask_j.shape:
            raise ValueError(
                f"iter_overlapping_neighbors: mask shape mismatch for ids {i_id} vs {j_id}: "
                f"{mask_i.shape} != {mask_j.shape}"
            )

        # Overlap in N-D
        overlap = (mask_i & mask_j)
        if not np.any(overlap):
            continue

        yield j_idx, agent_j, overlap




# =========================
# Logging
# =========================

def log_phi_grad_like(aid, field, tag, arr):
    """Compact sign/mean/|g| logging for φ/φ̃ terms."""
    if arr is None: return
    spatial_axes = tuple(range(arr.ndim - 1))
    g_mean = np.mean(arr, axis=spatial_axes)
    sign = "".join("+" if x > 0 else "-" if x < 0 else "0" for x in g_mean.tolist())
    g_abs_mean = float(np.mean(np.abs(arr)))
    print(f"[PHI] field={field} ai={aid} term={tag} "
          f"sign={sign} mean={np.array2string(g_mean, precision=3, suppress_small=True)} "
          f"|g|_mean={g_abs_mean:.3e}", flush=True)


def get_neighbors(agent_i, agents, *, dedup=True, exclude_self=True):
    """
    Resolve agent_i.neighbors -> list[Agent].
    Supports neighbors as dicts with 'id' or raw ints.
    Works with `agents` as a list (id taken from agent.id or index)
    or as a dict keyed by id.
    """
    raw = getattr(agent_i, "neighbors", []) or []

    # Build lookup once
    if isinstance(agents, dict):
        lookup = {int(k): v for k, v in agents.items()}
    else:
        lookup = {int(getattr(a, "id", i)): a for i, a in enumerate(agents)}

    out, seen = [], set()
    self_id = int(getattr(agent_i, "id", -1))

    for nb in raw:
        # accept {"id": ...} or int id
        try:
            j = int(nb["id"]) if isinstance(nb, dict) else int(nb)
        except Exception:
            continue

        if exclude_self and j == self_id:
            continue
        if dedup and j in seen:
            continue

        a = lookup.get(j)
        if a is not None:
            out.append(a)
            if dedup:
                seen.add(j)

    return out






