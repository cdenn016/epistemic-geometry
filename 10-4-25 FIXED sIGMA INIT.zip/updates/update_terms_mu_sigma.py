# -*- coding: utf-8 -*-
"""
Created on Wed Aug  6 12:27:32 2025

@author: chris and christine
"""
 
import time
import numpy as np
import core.config as config
from core.numerical_utils import sanitize_sigma, safe_inv, push_gaussian
from core.transport_cache import Omega
from utils import iter_overlapping_neighbors, _aid
from core.transport_cache import Phi_cached
from beta import beta_effective_weight

# -------------------------------------------------------------------------
#                          PUBLIC ENTRYPOINTS
# -------------------------------------------------------------------------



def accumulate_mu_sigma_gradient(ctx, agent_i, agents, mode):
    """
    Accumulate natural gradient ∇μ and ∇Σ for belief or model using cache-owned Φ, Φ̃, Ω.
    Adds fine-grained timing (printed only if cfg debug_mu_sigma_timing=True).
    """
    
    from runtime_context import cfg_get
    
    if ctx is None:
        raise RuntimeError("accumulate_mu_sigma_gradient: ctx required.")

    # -------- profiling setup (cheap when disabled) --------
    prof = bool(cfg_get(ctx, "debug_mu_sigma_timing", False))
    t = {}                      # sub-timings
    def _tic():  return time.perf_counter()
    def _tock(s, key): t[key] = time.perf_counter() - s

    PRINT_SIGN  = False

    eps         = float(cfg_get(ctx, "eps", 1e-6))
    tau         = float(cfg_get(ctx, "support_tau", 1e-6))
    alpha       = float(cfg_get(ctx, "alpha", 0))
    lambd       = float(cfg_get(ctx, "feedback_weight", 0))

    field = "phi" if mode == "belief" else "phi_model"
    
    if field == "phi":
        beta_like = float(cfg_get(ctx, "beta", 1))
    else:
        beta_like = float(cfg_get(ctx, "beta_model", 1))

    which = "q" if field == "phi" else "p"
    mu_key    = "mu_q_field"    if which == "q" else "mu_p_field"
    sigma_key = "sigma_q_field" if which == "q" else "sigma_p_field"

    # (unchanged) direct field access if you need them later
    mu_q, S_q = agent_i.mu_q_field, agent_i.sigma_q_field
    mu_p, S_p = agent_i.mu_p_field, agent_i.sigma_p_field

    # -------- pushes (Φ, Φ̃) --------
    t0 = _tic()
    Phi_mat       = Phi_cached(ctx, agent_i, kind="q_to_p")
    Phi_tilde_mat = Phi_cached(ctx, agent_i, kind="p_to_q")
    _tock(t0, "Phi_fetch")

    t0 = _tic()
    mu_q_push, S_q_push, inv_q_push = push_gaussian(
        mu_q, S_q, Phi_mat, eps=eps, return_inv=True,
        Sigma_inv=getattr(agent_i, "sigma_q_inv", None),   # precomputed in refresh_agents
        assume_orthogonal=False                             # Φ is generally not orthogonal
    )

    mu_p_push, S_p_push, inv_p_push = push_gaussian(
        mu_p, S_p, Phi_tilde_mat, eps=eps, return_inv=True,
        Sigma_inv=getattr(agent_i, "sigma_p_inv", None),   # precomputed in refresh_agents
        assume_orthogonal=False                             # Φ is generally not orthogonal
    )

    _tock(t0, "push_gaussians")

    # -------- self/feedback energy accumulation (cheap; reuse pushes) --------
    t0 = _tic()
    accumulate_self_feedback_energies(
        ctx, agent_i,
        mu_q=mu_q, S_q=S_q,
        mu_p=mu_p, S_p=S_p,
        mu_q_push=mu_q_push, S_q_push=S_q_push,
        mu_p_push=mu_p_push, S_p_push=S_p_push,
    )
    _tock(t0, "accumulate self/feedback energies")
    # -------- self + feedback (Euclid-gradients) --------
    t0 = _tic()
    g_self_mu, g_self_S, g_fb_mu, g_fb_S = _self_and_feedback_grads(
        mode,
        mu_q, S_q, mu_p, S_p,
        mu_q_push, S_q_push, inv_q_push,
        mu_p_push, S_p_push, inv_p_push,
        Phi_mat, Phi_tilde_mat, eps,
        sigma_q_inv=getattr(agent_i, "sigma_q_inv", None),
        sigma_p_inv=getattr(agent_i, "sigma_p_inv", None),
        mask=getattr(agent_i, "mask", None),
    )

    _tock(t0, "self_feedback")

    mu_field = getattr(agent_i, mu_key)
    S_field  = getattr(agent_i, sigma_key)

    dmu_align = np.zeros_like(mu_field, dtype=np.float32)
    dS_align  = np.zeros_like(S_field,  dtype=np.float32)

    # -------- alignment (pairwise) --------
    n_pairs = 0
    align_px = 0  # total active overlap pixels across pairs
    if beta_like != 0.0:
        
        t0_align = _tic()
        for j_idx, agent_j, overlap in iter_overlapping_neighbors(
            agent_i, agents, support_eps=tau, symmetric=True
        ):
            n_pairs += 1
            align_px += int(np.count_nonzero(overlap))
            t1 = _tic()
            add_mu_i, add_S_i = _accum_align_for_pair(
                ctx, agent_i, agent_j,
                fiber=which,
                mu_key=mu_key, sigma_key=sigma_key,
                overlap_mask=overlap, beta_like=beta_like,
                eps=eps
            )
            if prof:
                # accumulate per-pair time (sum)
                t["align_pair_sum"] = t.get("align_pair_sum", 0.0) + (time.perf_counter() - t1)

            # scatter-add on the overlap
            dmu_align[overlap] += add_mu_i[overlap]
            dS_align[overlap]  += add_S_i[overlap]
        _tock(t0_align, "align_total")
        if n_pairs > 0 and "align_pair_sum" in t:
            t["align_pair_avg"] = t["align_pair_sum"] / float(n_pairs)


# -------- combine & natural gradient projection --------
    t0 = _tic()
    dmu_total = alpha * g_self_mu + lambd * g_fb_mu + dmu_align
    dS_total  = alpha * g_self_S  + lambd * g_fb_S  + dS_align
        
    dS_total = 0.5 * (dS_total + np.swapaxes(dS_total, -1, -2))
    _tock(t0, "combine_totals")

    t0 = _tic()
       
    delta_mu, delta_S = apply_natural_gradient_batch(
        ctx,
        getattr(agent_i, mu_key), getattr(agent_i, sigma_key),
        dmu_total.astype(np.float32, copy=False),
        dS_total.astype(np.float32,  copy=False),
        mask=agent_i.mask,
        assume_sanitized=True,          # since you sanitize Σ in refresh_agents
        grad_sigma_is_symmetric=True,   # if you already symmetrized upstream
        use_float64=False 
    )
    
    _tock(t0, "natural_project")

    # -------- accumulate to agent --------
    if which == "q":
        gmu_attr, gsig_attr = "grad_mu_q", "grad_sigma_q"
    else:
        gmu_attr, gsig_attr = "grad_mu_p", "grad_sigma_p"

    if getattr(agent_i, gmu_attr, None) is None:
        setattr(agent_i, gmu_attr,  np.zeros_like(getattr(agent_i, mu_key),    dtype=np.float32))
    if getattr(agent_i, gsig_attr, None) is None:
        setattr(agent_i, gsig_attr, np.zeros_like(getattr(agent_i, sigma_key), dtype=np.float32))

    setattr(agent_i, gmu_attr,  getattr(agent_i, gmu_attr)  + delta_mu)
    setattr(agent_i, gsig_attr, getattr(agent_i, gsig_attr) + delta_S)

    if PRINT_SIGN:
        aid = _aid(agent_i)
        ax = tuple(range(delta_mu.ndim - 1))
        mu_mean = np.mean(delta_mu, axis=ax)
        S_tr = np.mean(np.trace(delta_S, axis1=-2, axis2=-1), axis=ax)
        def sgns(vec): return "".join("+" if v>0 else "-" if v<0 else "0" for v in vec.tolist())
        

        print(f"[MU/SIG] mode={mode} ai={aid} "
              f"μ_sign={sgns(mu_mean)} μ_mean={np.array2string(mu_mean, precision=3, suppress_small=True)} "
              f"|μ|_mean={float(np.mean(np.abs(delta_mu))):.3e} "
              f"|Σ|_F_mean={float(np.mean(np.linalg.norm(delta_S.reshape(*delta_S.shape[:-2], -1), axis=-1))):.3e} "
              f"tr(ΔΣ)_mean={float(S_tr):.3e}", flush=True)

    # -------- print timings (only when profiling is enabled) --------
    if prof:
        aid = _aid(agent_i)
        npairs = n_pairs if beta_like != 0.0 else 0
        apx = align_px if beta_like != 0.0 else 0
        # stable pretty print
        ordered = [
            "Phi_fetch", "push_gaussians", "self_feedback",
            "align_total", "align_pair_sum", "align_pair_avg",
            "vfe_mu_sigma", "combine_totals", "natural_project"
        ]
        print(f"[μΣ PROF] Agent {aid} ({mode}) pairs={npairs} align_px={apx}")
        for k in ordered:
            if k in t:
                print(f"  {k:18s}: {t[k]*1e3:7.2f} ms")

    return delta_mu, delta_S




# --- Self / Feedback energy accumulation (shared with diagnostics) ---


def accumulate_self_feedback_energies(
    ctx,
    agent_i,
    *,
    mu_q, S_q,
    mu_p, S_p,
    mu_q_push, S_q_push,
    mu_p_push, S_p_push,
):
    """
    Accumulate UNWEIGHTED pixel-summed KLs into the per-step accumulator:
      self_sum     += sum_px KL(q || p')
      feedback_sum += sum_px KL(p || q')

    Keep α, λ application outside (e.g., in compute_global_metrics/total_energy),
    just like alignment stores unweighted KL. Returns (self_raw, feedback_raw).
    """
    import numpy as np
    from runtime_context import cfg_get, energy_acc_add
    from core.numerical_utils import sanitize_sigma, kl_gaussian

    eps = float(cfg_get(ctx, "eps", 1e-8))
    tau = float(cfg_get(ctx, "support_tau", 1e-6))

    # common support mask
    m = np.asarray(getattr(agent_i, "mask", 1.0), np.float32)
    mm = (m > tau) if (m.dtype != bool) else m
    if not np.any(mm):
        return 0.0, 0.0

    # slice active pixels
    μq  = np.asarray(mu_q[mm],      np.float64, order="C")
    Σq  = sanitize_sigma(np.asarray(S_q[mm],    np.float64, order="C"), eps=eps)
    μp  = np.asarray(mu_p[mm],      np.float64, order="C")
    Σp  = sanitize_sigma(np.asarray(S_p[mm],    np.float64, order="C"), eps=eps)
    μqʹ = np.asarray(mu_q_push[mm], np.float64, order="C")
    Σqʹ = sanitize_sigma(np.asarray(S_q_push[mm], np.float64, order="C"), eps=eps)
    μpʹ = np.asarray(mu_p_push[mm], np.float64, order="C")
    Σpʹ = sanitize_sigma(np.asarray(S_p_push[mm], np.float64, order="C"), eps=eps)

    # pixelwise KLs (unweighted)
    self_px     = kl_gaussian(μq, Σq, μpʹ, Σpʹ, eps=eps)   # KL(q || p')
    feedback_px = kl_gaussian(μp, Σp, μqʹ, Σqʹ, eps=eps)   # KL(p || q')

    self_raw = float(np.sum(self_px))
    fb_raw   = float(np.sum(feedback_px))

    # Accumulate UNWEIGHTED totals (match alignment convention)
    energy_acc_add(ctx, "self_sum",     self_raw)
    energy_acc_add(ctx, "feedback_sum", fb_raw)

    # Optional per-agent buckets (mirrors your alignment helper)
    aid = getattr(agent_i, "id", None)
    if aid is not None:
        energy_acc_add(ctx, f"self_sum[{aid}]",     self_raw)
        energy_acc_add(ctx, f"feedback_sum[{aid}]", fb_raw)

    return self_raw, fb_raw





def _accum_align_for_pair(
    ctx,
    agent_i,
    agent_j,
    *,
    fiber: str,
    mu_key: str,
    sigma_key: str,
    overlap_mask: np.ndarray,
    beta_like: float,   # unused now; kept for signature compatibility
    eps: float,
):
    """
    Alignment contribution from j→i on fiber ("q" or "p").
    Now supports arbitrary spatial shape S (not just 2D).
    Returns (gmu_i, gS_i) with shapes S+(Ki,) and S+(Ki,Ki).
    """
    import numpy as np

    # ---- overlap mask: S bool/float ----
    w_mask = np.asarray(overlap_mask)
    if w_mask.ndim < 1:
        raise ValueError(f"_accum_align_for_pair: overlap_mask must be >=1-D, got {w_mask.shape}")
    S = tuple(w_mask.shape)
    w_mask = w_mask.astype(np.float32, copy=False)

    # ---- effective weight s_ij(x) ----
    i_id = int(getattr(agent_i, "id", -1))
    j_id = int(getattr(agent_j, "id", -1))
    if fiber not in ("q", "p"):
        raise ValueError(f"_accum_align_for_pair: fiber must be 'q' or 'p', got {fiber!r}")

    #if Ka = Kg use beta_eff_weight.  else use beta_raw
    w = beta_effective_weight(ctx, i_id, j_id, which=fiber, joint_mask=w_mask)   
    #w = beta_raw_weight(ctx, i_id, j_id, which=fiber, joint_mask=w_mask)
    w = np.asarray(w, np.float32)
    if w.shape != S:
        raise ValueError(f"_accum_align_for_pair: weight shape {w.shape} != overlap {S}")

    # Early exit: nothing to add
    if not np.any(w > 1e-8):
        mu_i = getattr(agent_i, mu_key)
        Ki   = int(mu_i.shape[-1])
        return (np.zeros(S + (Ki,),    dtype=np.float32),
                np.zeros(S + (Ki, Ki), dtype=np.float32))

    # ---- Transport j → i in the given fiber ----
    Omega_ij = Omega(ctx, agent_i, agent_j, which=fiber)

    # Fields (validate shapes vs S)
    mu_i = np.asarray(getattr(agent_i, mu_key),  np.float32)
    S_i  = np.asarray(getattr(agent_i, sigma_key), np.float32)
    mu_j = np.asarray(getattr(agent_j, mu_key),  np.float32)
    S_j  = np.asarray(getattr(agent_j, sigma_key), np.float32)

    if mu_i.shape[:-1] != S or mu_j.shape[:-1] != S:
        raise ValueError(f"_accum_align_for_pair: μ shapes {mu_i.shape}, {mu_j.shape} not compatible with {S}")
    if S_i.shape[:-2] != S or S_j.shape[:-2] != S:
        raise ValueError(f"_accum_align_for_pair: Σ shapes {S_i.shape}, {S_j.shape} not compatible with {S}")

    if not (np.isfinite(mu_i).all() and np.isfinite(mu_j).all()):
        raise FloatingPointError("Non-finite μ in alignment pair")
    if not (np.isfinite(S_i).all() and np.isfinite(S_j).all()):
        raise FloatingPointError("Non-finite Σ in alignment pair")

    # ---- Fast push j → i (reuse Σ_j^{-1} if available) ----
    inv_j_full = getattr(agent_j, "sigma_q_inv" if fiber == "q" else "sigma_p_inv", None)
    mu_j_t, S_j_t, inv_j_t = push_gaussian(
        mu_j, S_j, Omega_ij, eps=eps, return_inv=True,
        Sigma_inv=inv_j_full,
        assume_orthogonal=False,
        sanitize_input=False
    )

    # ---- i-side Euclidean grads (reuse Σ_i^{-1}) ----
    inv_i_full = getattr(agent_i, "sigma_q_inv" if fiber == "q" else "sigma_p_inv", None)
    gmu_i, gS_i = grad_alignment_energy_source(
        mu_i, S_i, mu_j_t, inv_j_t, eps=eps,
        sigma_i_inv=inv_i_full,
        assume_sanitized=True
    )

    # ---- scale by effective weight (broadcast-safe over S) ----
    gmu_i = w[..., None]       * gmu_i      # S+(Ki,)
    gS_i  = w[..., None, None] * gS_i       # S+(Ki,Ki)

    return gmu_i, gS_i


def _self_and_feedback_grads(
    mode: str,
    mu_q, sigma_q, mu_p, sigma_p,
    mu_q_push, Sigma_q_push, inv_q_push,
    mu_p_push, Sigma_p_push, inv_p_push,
    Phi_mat, Phi_tilde_mat, eps: float,
    *, sigma_q_inv=None, sigma_p_inv=None, mask=None
):
    if mode == "belief":
        g_self_mu, g_self_S = grad_self_energy_belief(
            mu_q, sigma_q, mu_p_push, inv_p_push,
            sigma_q_inv=sigma_q_inv, mask=mask
        )
        g_fb_mu, g_fb_S = grad_feedback_energy_belief(
            mu_q, sigma_q, mu_p, mu_q_push,
            Sigma_q_push, inv_q_push, sigma_p, Phi_mat
        )
    elif mode == "model":
        g_self_mu, g_self_S = grad_self_energy_model(
            mu_q, sigma_q, mu_p_push, inv_p_push, Phi_tilde_mat, mask=mask
        )
        g_fb_mu, g_fb_S = grad_feedback_energy_model(
            mu_p, sigma_p, mu_q_push, Sigma_q_push, inv_q_push,
            sigma_p_inv=sigma_p_inv
        )
    else:
        raise ValueError(f"Unsupported mode: {mode}")
    return g_self_mu, g_self_S, g_fb_mu, g_fb_S




#==============================================================================
#
#                    FEEDBACK / SELF TERMS (unchanged math, safer numerics)
#==============================================================================

def grad_alignment_energy_source(
    mu_i, sigma_i, mu_j_t, sigma_j_t_inv, eps=1e-8,
    *, sigma_i_inv=None, assume_sanitized=True
):
    """
    Faster: reuse precomputed sigma_i_inv if provided; optionally skip sanitize.
    """
    mu_i       = np.asarray(mu_i,       dtype=np.float32, order="C")
    mu_j_t     = np.asarray(mu_j_t,     dtype=np.float32, order="C")
    sigma_j_t_inv = np.asarray(sigma_j_t_inv, dtype=np.float32, order="C")

    dmu = mu_i - mu_j_t
    # grad_mu_i = S'^-1 (μ_i - μ_j')
    grad_mu = np.einsum("...ij,...j->...i", sigma_j_t_inv, dmu, optimize=True)

    if sigma_i_inv is None:
        Si = np.asarray(sigma_i, dtype=np.float32, order="C")
        if not assume_sanitized:
            Si = sanitize_sigma(Si, eps=eps)
        sigma_i_inv = safe_inv(Si)   # batched cholesky-inv

    grad_sigma = 0.5 * (sigma_j_t_inv - sigma_i_inv)
    # symmetrize
    grad_sigma = 0.5 * (grad_sigma + np.swapaxes(grad_sigma, -1, -2))

    return grad_mu.astype(np.float32, copy=False), grad_sigma.astype(np.float32, copy=False)


def grad_alignment_energy_target(
    mu_i, sigma_i, mu_j_t, sigma_j_t_inv, Omega_ij, eps: float = 1e-8,
    *, assume_sanitized=True
):
    """
    Faster: use v = S'^-1 dμ  ->  v vᵀ for the middle term; skip repeated sanitize.
    """
    mu_i       = np.asarray(mu_i,       dtype=np.float32, order="C")
    mu_j_t     = np.asarray(mu_j_t,     dtype=np.float32, order="C")
    Omega_ij   = np.asarray(Omega_ij,   dtype=np.float32, order="C")
    sigma_jinv = np.asarray(sigma_j_t_inv, dtype=np.float32, order="C")

    dmu = mu_i - mu_j_t

    # ∂_{μ_j'} KL = - S'^-1 dμ  ;  map back with Ωᵀ
    gmu_jp    = -np.einsum("...ij,...j->...i", sigma_jinv, dmu, optimize=True)
    grad_mu_j = np.einsum("...ji,...j->...i", Omega_ij, gmu_jp, optimize=True)

    # Σ_i only appears (not inverted); assume sanitized upstream
    Si = np.asarray(sigma_i, dtype=np.float32, order="C")
    if not assume_sanitized:
        Si = sanitize_sigma(Si)

    # v = S'^-1 dμ  ->  v vᵀ
    v   = np.einsum("...ij,...j->...i", sigma_jinv, dmu, optimize=True)
    vvT = np.einsum("...i,...j->...ij", v, v, optimize=True)

    # gΣ' = 1/2( -S'^-1 Σ_i S'^-1 - vvᵀ + S'^-1 )
    t0 = -np.einsum("...ij,...jk,...kl->...il", sigma_jinv, Si, sigma_jinv, optimize=True)
    gSp = 0.5 * (t0 - vvT + sigma_jinv)

    # map back: Ωᵀ gΣ' Ω, then symmetrize
    grad_sigma_j = np.einsum("...ji,...jk,...kl->...il",
                             Omega_ij, gSp, np.swapaxes(Omega_ij, -1, -2), optimize=True)
    grad_sigma_j = 0.5 * (grad_sigma_j + np.swapaxes(grad_sigma_j, -1, -2))

    return grad_mu_j.astype(np.float32, copy=False), grad_sigma_j.astype(np.float32, copy=False)



def grad_feedback_energy_belief(
    mu_q, sigma_q, mu_p, mu_q_push,
    sigma_q_push, sigma_q_push_inv, sigma_p, Phi, eps=1e-8, *,
    assume_sanitized=True,
):
    """
    ∂ wrt (μ_q, Σ_q) of KL(p || Φ·q), evaluated in q-fiber.
    Uses v = S'^-1 Δ and v v^T instead of S'^-1 ΔΔ^T S'^-1 to cut temps.
    """
    # Δ = μ_p - μ_q'
    delta = (mu_p - mu_q_push).astype(np.float32, copy=False)

    # v = S'^-1 Δ  (matvec)
    v = np.matmul(sigma_q_push_inv, delta[..., None])[..., 0]  # (...,K)

    # grad_μ = - Φ^T v
    Phi_T = np.swapaxes(Phi, -1, -2)
    grad_mu = -np.matmul(Phi_T, v[..., None])[..., 0]

    # M = S'^-1  - v v^T  - S'^-1 Σ_p S'^-1
    term1 = sigma_q_push_inv
    term2 = np.matmul(v[..., :, None], v[..., None, :])        # v v^T
    term3 = np.matmul(np.matmul(sigma_q_push_inv, sigma_p), sigma_q_push_inv)

    M = term1 - term2 - term3

    # grad_Σ = 1/2 Φ^T M Φ (symmetrized)
    grad_sigma = 0.5 * np.matmul(np.matmul(Phi_T, M), Phi)
    grad_sigma = 0.5 * (grad_sigma + np.swapaxes(grad_sigma, -1, -2))

    return grad_mu.astype(np.float32, copy=False), grad_sigma.astype(np.float32, copy=False)


def grad_feedback_energy_model(
    mu_p, sigma_p, mu_q_push,
    sigma_q_push, sigma_q_push_inv, Phi=None, eps=1e-8, *,
    sigma_p_inv=None, assume_sanitized=True,
):
    """
    ∂ wrt (μ_p, Σ_p) of KL(p || q'), evaluated in p-fiber.
    Avoids inverting Σ_p if sigma_p_inv is provided.
    """
    delta = (mu_p - mu_q_push).astype(np.float32, copy=False)

    # grad_μ = S'^-1 Δ
    grad_mu = np.matmul(sigma_q_push_inv, delta[..., None])[..., 0]

    # grad_Σ = 1/2 (S'^-1 - Σ_p^{-1})
    if sigma_p_inv is None:
        # assume Σ_p already sanitized upstream; we only invert if caller didn’t pass inv
        sigma_p_inv = safe_inv(sigma_p.astype(np.float32, copy=False))
    grad_sigma = 0.5 * (sigma_q_push_inv - sigma_p_inv)
    grad_sigma = 0.5 * (grad_sigma + np.swapaxes(grad_sigma, -1, -2))

    return grad_mu.astype(np.float32, copy=False), grad_sigma.astype(np.float32, copy=False)


def grad_self_energy_belief(
    mu_q, sigma_q, mu_p_push, sigma_p_push_inv, eps=1e-8, *,
    sigma_q_inv=None, mask=None, assume_sanitized=True,
):
    """
    ∂ wrt (μ_q, Σ_q) of KL(q || p'), evaluated in q-fiber.
    Reuses sigma_q_inv if provided.
    """
    delta = (mu_q - mu_p_push).astype(np.float32, copy=False)

    # grad_μ = S_p'^-1 Δ
    grad_mu = np.matmul(sigma_p_push_inv, delta[..., None])[..., 0]

    # grad_Σ = 1/2 (S_p'^-1 - Σ_q^{-1})
    if sigma_q_inv is None:
        sigma_q_inv = safe_inv(sigma_q.astype(np.float32, copy=False))
    
    grad_sigma = 0.5 * (sigma_p_push_inv - sigma_q_inv)
    grad_sigma = 0.5 * (grad_sigma + np.swapaxes(grad_sigma, -1, -2))

    if mask is not None:
        m = (np.asarray(mask) > float(getattr(config, "support_tau", 0.0)))
        grad_mu    = grad_mu * m[..., None]
        grad_sigma = grad_sigma * m[..., None, None]

    return grad_mu.astype(np.float32, copy=False), grad_sigma.astype(np.float32, copy=False)


def grad_self_energy_model(
    mu_q, sigma_q, mu_p_push, sigma_p_push_inv, Phi_tilde, eps=1e-8, *,
    assume_sanitized=True, mask=None,
):
    """
    ∂ wrt (μ_p, Σ_p) of KL(q || p'), evaluated in p-fiber.
    Uses v = M Δ and v v^T to avoid an extra large einsum.
    """
    delta = (mu_q - mu_p_push).astype(np.float32, copy=False)

    # tmp = M Δ
    v = np.matmul(sigma_p_push_inv, delta[..., None])[..., 0]

    # grad_μ = - Φ̃^T v
    Phi_tilde_T = np.swapaxes(Phi_tilde, -1, -2)
    grad_mu = -np.matmul(Phi_tilde_T, v[..., None])[..., 0]

    # G = M - v v^T - M Σ_q M
    vvT = np.matmul(v[..., :, None], v[..., None, :])
    M_Sq = np.matmul(sigma_p_push_inv, sigma_q.astype(np.float32, copy=False))
    G = sigma_p_push_inv - vvT - np.matmul(M_Sq, sigma_p_push_inv)

    # grad_Σ = 1/2 Φ̃^T G Φ̃  (symmetrized)
    grad_sigma = 0.5 * np.matmul(np.matmul(Phi_tilde_T, G), Phi_tilde)
    grad_sigma = 0.5 * (grad_sigma + np.swapaxes(grad_sigma, -1, -2))

    if mask is not None:
        m = (np.asarray(mask) > float(getattr(config, "support_tau", 0.0)))
        grad_mu    = grad_mu * m[..., None]
        grad_sigma = grad_sigma * m[..., None, None]

    return grad_mu.astype(np.float32, copy=False), grad_sigma.astype(np.float32, copy=False)




def apply_natural_gradient_batch(
    ctx,
    mu_field,
    sigma_field,
    grad_mu_field,
    grad_sigma_field,
    mask=None,
    *,
    use_float64: bool = True,
    assume_sanitized: bool = True,
    grad_sigma_is_symmetric: bool = False,
    assert_finite: bool = False,
):
    """
    Vectorized natural gradient for Gaussian fields on an N-D periodic grid:
        δμ = -Σ ∇_μ L
        δΣ = -2 Σ sym(∇_Σ L) Σ

    Inputs:
      mu_field          : (*S, K)
      sigma_field       : (*S, K, K)   [SPD]
      grad_mu_field     : (*S, K)
      grad_sigma_field  : (*S, K, K)
      mask (optional)   : (*S,) bool or float weights

    Returns:
      delta_mu          : (*S, K)
      delta_sigma       : (*S, K, K)
    """
    import numpy as np
    from runtime_context import cfg_get

    # ---- config ----
    eps         = float(cfg_get(ctx, "eps", 1e-10))
    support_tau = float(cfg_get(ctx, "support_tau", 1e-6))
    dtype_work  = np.float64 if use_float64 else np.float32
    dtype_out   = np.float32 if not use_float64 else dtype_work

    # ---- infer spatial shape S, fiber dim K ----
    mu = np.asarray(mu_field)
    Sig = np.asarray(sigma_field)
    gmu = np.asarray(grad_mu_field)
    gSig = np.asarray(grad_sigma_field)

    if mu.ndim < 2 or Sig.ndim < 3:
        raise ValueError(f"Bad shapes: mu {mu.shape}, Sigma {Sig.shape}")

    S = mu.shape[:-1]               # *S
    K = mu.shape[-1]
    if Sig.shape[:-2] != S or Sig.shape[-2:] != (K, K):
        raise ValueError(f"sigma_field shape {Sig.shape} incompatible with mu_field {mu.shape}")

    # ---- flatten spatial for batched einsum ----
    N = int(np.prod(S, dtype=int))
    mu  = mu.astype(dtype_work, copy=False).reshape(N, K)
    Sig = Sig.astype(dtype_work, copy=False).reshape(N, K, K)
    gmu  = gmu.astype(dtype_work, copy=False).reshape(N, K)
    gSig = gSig.astype(dtype_work, copy=False).reshape(N, K, K)

    # ---- SPD sanitize Σ and symmetrize ∇Σ ----
    if not assume_sanitized:
        Sig = sanitize_sigma(Sig, eps=eps)  # must return symmetric SPD in dtype_work
    if not grad_sigma_is_symmetric:
        gSig = 0.5 * (gSig + np.swapaxes(gSig, -1, -2))

    # ---- natural steps ----
    # δμ = -Σ ∇_μ
    dmu = -np.einsum("nik,nk->ni", Sig, gmu, optimize=True)
    # δΣ = -2 Σ sym(∇_Σ) Σ
    tmp =  np.einsum("nij,njk->nik", Sig, gSig, optimize=True)
    dS  = -2.0 * np.einsum("nij,njk->nik", tmp, Sig, optimize=True)
    dS  = 0.5 * (dS + np.swapaxes(dS, -1, -2))  # symmetry guard

    # ---- mask / weights ----
    if mask is not None:
        m = np.asarray(mask)

        m_flat = m.reshape(N)
        if m.dtype == bool:
            active = m_flat
            wts = None
        else:
            wts = m_flat.astype(dtype_work, copy=False)
            active = wts > support_tau
            # soft weights
            dmu *= wts[:, None]
            dS  *= wts[:, None, None]

        # zero outside support
        if not np.all(active):
            ia = ~active
            dmu[ia] = 0.0
            dS[ia]  = 0.0


    if assert_finite:
        if not (np.isfinite(dmu).all() and np.isfinite(dS).all()):
            raise FloatingPointError("Nonfinite natural gradient (μ or Σ).")

    # ---- restore shapes / cast ----
    return (
        dmu.reshape(S + (K,)).astype(dtype_out, copy=False),
        dS.reshape(S + (K, K)).astype(dtype_out, copy=False),
    )







