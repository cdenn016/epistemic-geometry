# -*- coding: utf-8 -*-
"""
Created on Wed Jul 23 10:32:58 2025

@author: chris and christine
"""

import time
from runtime_context import ensure_runtime_defaults
from core.gaussian_core import resolve_support_tau
from updates.update_compute_all_gradients import _apply_children, _compute_child_grads
from updates.update_refresh_utils import (
    refresh_agents_light,    
    mark_dirty, ensure_dirty, list_nonnull,
    
)



class PhaseTimer:
    """Context-manager timer that aggregates per-phase wall time on runtime_ctx."""
    def __init__(self, ctx):
        self.ctx = ctx
        if not hasattr(ctx, "timings") or getattr(ctx, "timings") is None:
            ctx.timings = {}

    def __call__(self, name: str):
        ctx = self.ctx
        class _T:
            def __enter__(_s):
                _s.t0 = time.perf_counter()
                return _s
            def __exit__(_s, *_):
                dt = time.perf_counter() - _s.t0
                ctx.timings[name] = ctx.timings.get(name, 0.0) + dt
        return _T()





# --- synchronous step (simplified, timed) ------------------------------------
def synchronous_step(agents, generators_q, generators_p, params=None, n_jobs=1, runtime_ctx=None):
    """
    Single-scale (children-only) synchronous update step.
    Evolves child agents, enforces caches, warms pairwise transport (KL refresh),
    and registers children. No parents/detection/spawn/xscale.
    """
    
    import core.config as config

    def CFG(key, default=None):
        return (params or {}).get(key, getattr(config, key, default))

    assert runtime_ctx is not None, "synchronous_step: pass runtime_ctx"
    assert agents and (len(agents) > 0), "synchronous_step: no agents"

    params = dict(params or {})
    params["runtime_ctx"] = runtime_ctx

    _ = resolve_support_tau(runtime_ctx, params, default=1e-3, name="support_tau")
    runtime_ctx = ensure_runtime_defaults(runtime_ctx)

    if not hasattr(runtime_ctx, "cache") or runtime_ctx.cache is None:
        try:
            from runtime_context import CacheHub
            runtime_ctx.cache = CacheHub()
        except Exception:
            class _NoopCache:
                def clear_on_step(self, *_args, **_kw): pass
                def ns(self, *_args, **_kw):
                    class _D(dict):
                        def clear(self): super().clear()
                    return _D()
            runtime_ctx.cache = _NoopCache()

    step_now = int(getattr(runtime_ctx, "global_step", 0))
    runtime_ctx.cache.clear_on_step(step_now)

    d = getattr(runtime_ctx, "dirty", None)
    if hasattr(d, "reset_step"):
        d.reset_step(step_now)
    try:
        d.agents.clear(); d.kl.clear()
    except Exception:
        pass

    T = PhaseTimer(runtime_ctx)

    # ---------------- Phase 0: pre ----------------
    with T("pre"):
        children = list_nonnull(agents)
        if not children:
            runtime_ctx.register_agents(0, [])
            runtime_ctx.global_step += 1
            return agents
        refresh_agents_light(children, params, generators_q, generators_p, ctx=runtime_ctx)

    

    # ---------------- Phase 1: child grads/apply ---
    with T("child_grad"):
        grads = _compute_child_grads(children, children, generators_q, generators_p, params)

    with T("child_apply"):
        frozen_levels     = set(params.get("frozen_levels", []))
        frozen_phi_levels = set(params.get("frozen_phi_levels", []))
        _apply_children(children, grads, params, frozen_levels, frozen_phi_levels,
                        generators_q, generators_p, n_jobs, ctx=runtime_ctx)
        for a in children:
            mark_dirty(runtime_ctx, a, kl=True)  # signal pairwise caches to warm
        runtime_ctx.children_latest = children

    # ---------------- Phase 2: ensure/caches -------
    with T("ensure_children"):
        ensure_dirty(runtime_ctx, generators_q, generators_p, params, scope="children")

    # ---------------- Phase 3: KL refresh (single-scale) ----------
    with T("refresh_child_kl"):
        refresh_kl_for_dirty_children(runtime_ctx, universe=children,
                                      eps=CFG("eps", 1e-6), Gq=generators_q, Gp=generators_p)

    # ---------------- Phase 4: register/step -------
    with T("register"):
        runtime_ctx.register_agents(0, children)
        runtime_ctx.children_latest = children
        runtime_ctx.global_step    += 1

    # ---------------- Phase 5: timing --------------
    if bool(CFG("debug_phase_timing", True)):
        print("[timings]")
        for name, dt in sorted(getattr(runtime_ctx, "timings", {}).items()):
            print(f"  {name:20s} {dt:8.3f}s")
        if getattr(runtime_ctx, "counters", None):
            print("[counts]", runtime_ctx.counters)

    return agents





def refresh_kl_for_dirty_children(ctx, universe, eps, Gq=None, Gp=None):
    """
    Single-scale KL/transport warm-up for CHILDREN ONLY.
    Warms exactly the caches gradient code depends on:
      - E (site exponentials), Jinv (dexp^{-1})
      - Φ (q->p and p->q) for each agent
      - Ω_ij for same-level neighbors (both q and p fibers)

    No parents, no spawn/alignment aggregates, no heavy fields stored on agents.
    Idempotent per step via ctx.cache.clear_on_step(step).
    """
    import numpy as np
    from transport.transport_cache import E_grid as tc_E, Jinv_grid as tc_Jinv, Phi as tc_Phi, Omega as tc_Omega
    from updates.update_refresh_utils import take_dirty
    # 1) which agents are dirty for KL/transport?
    targets = take_dirty(ctx, universe, which="kl")
    if not targets:
        return

    # 2) warm per-agent site primitives (E, Jinv) and morphisms (Φ)
    for a in targets:
        try:
            _ = tc_E(ctx, a, which="q"); _ = tc_E(ctx, a, which="p")
            _ = tc_Jinv(ctx, a, which="q"); _ = tc_Jinv(ctx, a, which="p")
        except Exception as e:
            print(f"[KL-refresh] E/Jinv warm failed (aid={getattr(a,'id',None)}): {e}")

        try:
            _ = tc_Phi(ctx, a, kind="q_to_p")
            _ = tc_Phi(ctx, a, kind="p_to_q")
        except Exception as e:
            print(f"[KL-refresh] Φ warm failed (aid={getattr(a,'id',None)}): {e}")

    # 3) warm pairwise Ω for neighbors (same level only)
    #    Many gradient paths expect Ω_{ij} cached; keep it local to 'universe'.
    #    If you have neighbor lists on agents, use them; else do a cheap local ring.
    def neighbors_of(A):
        nb = getattr(A, "neighbors", None)
        if nb:
            # neighbors as [{'id': j}, ...]
            return [universe[int(item["id"])] for item in nb if int(item["id"]) < len(universe)]
        return []  # if none defined, skip; grads will compute Ω on-demand

    for Ai in targets:
        nbs = neighbors_of(Ai)
        for Aj in nbs:
            try:
                _ = tc_Omega(ctx, Ai, Aj, which="q")
                _ = tc_Omega(ctx, Ai, Aj, which="p")
            except Exception as e:
                ii = getattr(Ai, "id", None); jj = getattr(Aj, "id", None)
                print(f"[KL-refresh] Ω warm failed (i={ii}, j={jj}): {e}")

    # 4) done; nothing to return. caches are warm for this step.
    return




# update_refresh_utils.py
def invalidate_all_after_update(ctx):
    # clear everything that depends on φ/μ/Σ
    for ns in (
        "exp",       # E-grid e^{Φ}
        "omega",     # exp/log helpers (if any)
        "jinv",      # dexp^{-1}
        "morphism",  # Φ, Φ̃
        "fisher",    # natgrad
        "kl",        # if you cache KLs
        "align",     # alignment aggregates
        "spawn",     # spawn/detector caches
        "aggregates",
        "misc",
    ):
        try:
            ctx.cache.invalidate_ns(ns)
        except AttributeError:
            try:
                ctx.cache.ns(ns).clear()
            except Exception:
                pass






