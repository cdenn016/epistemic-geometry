import numpy as np
import sys


def set_config_from_params(params):
    """Dynamically override config attributes from a dictionary."""
    this_module = sys.modules[__name__]
    for k, v in params.items():
        setattr(this_module, k, v)

morphism_normalize    = True

agent_seed    = 2435 

# Toggle between diagonal and full Σ initialization
diagonal_sigma = False
identical_models = False         # If True, all agents share the same p, mu_p_field, sigma_p_field


# ===========================
# DOMAIN / SPATIAL SETTINGS
# ===========================
K_q           = 7
K_p           = 7      # Fiber dimension of belief/model space (depends on representation)
                 
D             = 2           #dimension of base manifold - d=2 validated

L             = 25         #length of hypercubic base-manifold - PBCs

steps         = 250

N             = 3                      # Number of agents
max_neighbors = 3        # Max number of agent neighbors

n_jobs = N

agent_radius_range = (4,4)         #agent radii
fixed_location = True 


 
# ===========================
# COUPLINGS & PENALTIES
# ===========================

alpha                  = 1
beta                   = 1
belief_mass            = 1
curvature_weight       = 1

feedback_weight         = 0
beta_model              = 1
model_mass              = 1
model_curvature_weight  = 1

#==========================
#    IF NEEDED/CURIOUS
#==========================
entropy_weight          = 0

phi_coupling_weight           = 0             # set > 0 to enable
phi_coupling_mode             = "projection"  # or "conjugation"


fisher_geometry_weight        = 0      
fisher_model_geometry_weight  = 0

#======================
#
#   LEARNING RATES
#
#======================
tau_phi                 = 1e-6
tau_phi_model           = 1e-6    
tau_mu_belief           = 1e-5       # update rate for η₁_q
tau_sigma_belief        = 1e-6       # update rate for η₂_q
tau_mu_model            = 1e-5      # update rate for η₁_p
tau_sigma_model         = 1e-6       # update rate for η₂_p



# ===========================
# INITIALIZATION
# ===========================

# ─── Belief Bundle (q) Parameters ───
q_mu_range                     = (-1.0, 1.0)              # Range for μ_q
q_sigma_range                  = (0.2, 1.0)           # Diagonal Σ_q entries

belief_noise_scale_mu          = 0.01         # Additive noise for μ_q
belief_noise_scale_sigma       = 0.01      # Additive noise for Σ_q


# ─── Model Bundle (p) Parameters ───
p_mu_range                     = (-1.0, 1.0)             # Range for μ_p
p_sigma_range                  = (0.2, 1.0)           # Diagonal Σ_p entries

model_noise_scale_mu           = 0.01          # Additive noise for μ_p
model_noise_scale_sigma        = 0.01       # Additive noise for Σ_p

sigma_outside_val              = 1e3  # large uncertainty outside support


phi_init_smooth_sigma   = 1.5
phi_init                = 0.1
phi_model_offset        = 0.05


# ===========================
# MASK & INTERACTION THRESHOLDS
# ===========================

support_cutoff_eps = 1e-3    # Mask threshold to include point in agent support################################
overlap_eps        = 1e-3     # Threshold for computing inter-agent overlap
support_tau = 1e-3            # universal floor for mask->bool


# ===== DEBUG / DIAGNOSTICS =====

debug_phase_timing = False
debug_grad_timing = False

# ===========================
# AGENT GEOMETRY
# ===========================
gaussian_blur_range_morphism = (1,2)
mu_clip = 3.0

#================================
#
#  INITIALIZE GLOBAL FIELDS 
#      WITH GENTLE NOISE
#================================
use_global_belief_template = False
use_global_model_template  = False

# ===========================
# STABILITY AND CLIPPING
# ===========================
   
gradient_clip_phi         = -1     # clip ‖∇φ‖ per pixel to ≤ 1.0
gradient_clip_phi_model   = -1     # same for φ̃

energy_eps = 1e-6
grid_dx = 1
# ===========================
# EPSILONS & NUMERICAL STABILITY
# ===========================

log_eps            = 1e-6     # Stabilize log(x)
eps                = 1e-5


checkpoint_interval = 1

domain_size = (L,) * D
num_cores = 1  # or however many threads you want to use
group_name = 'so3'               # Options: "u1", "so3", "so3", 'su2'.


