# -*- coding: utf-8 -*-
"""
Created on Mon Aug 11 10:07:56 2025

@author: chris and christine
"""
import numpy as np
from core.numerical_utils import sanitize_sigma, safe_inv, safe_logdet
from typing import Optional, Tuple
from transport.transport_cache import Omega
from core.omega import exp_lie_algebra_irrep


# -*- coding: utf-8 -*-
"""
Linear pushforward of Gaussian parameters under a matrix M:
  μ' = M μ
  Σ' = M Σ Mᵀ

One canonical entry-point:
  push_gaussian(mu, Sigma, M, *, approx="auto"| "exact" | "first_order", ...)

- Cache-agnostic; pure math.
- Works for square (Ω) and rectangular (Φ) maps.
- Broadcast-safe over leading dims.

Use this from transport/updates/energies; DO NOT re-implement locally.
"""

def _as_float(x):
    return np.asarray(x, dtype=float)


def _expand_diag(diag_or_full: np.ndarray, *, assume_stddev: bool) -> np.ndarray:
    """Convert (...,K) or (...,K,K) to full SPD (...,K,K)."""
    S = np.asarray(diag_or_full)
    if S.ndim >= 2 and S.shape[-2] == S.shape[-1]:
        return S
    if S.ndim == 1:
        S = S[None]
    diag = S
    if assume_stddev:
        diag = diag * diag
    K = int(diag.shape[-1])
    I = np.eye(K, dtype=diag.dtype)
    return np.einsum("...k,ij->...ij", diag, I, optimize=True)




def kl_gaussian(
    mu1: np.ndarray,
    S1: np.ndarray,
    mu2: np.ndarray,
    S2: np.ndarray,
    *,
    eps: float = 1e-6,
    allow_diag: bool = True,
    diag_is_stddev: bool = True,
    sanitize: bool = True,
    strict_numerics: bool = True,
    recover: str | None = None,
    return_terms: bool = False,
) -> np.ndarray | tuple[np.ndarray, dict]:
    mu1 = _as_float(mu1)
    mu2 = _as_float(mu2)
    S1 = np.asarray(S1)
    S2 = np.asarray(S2)

    if allow_diag:
        S1 = _expand_diag(S1, assume_stddev=diag_is_stddev)  # (..., K, K)
        S2 = _expand_diag(S2, assume_stddev=diag_is_stddev)

    # Symmetrize
    S1 = 0.5 * (S1 + np.swapaxes(S1, -1, -2))
    S2 = 0.5 * (S2 + np.swapaxes(S2, -1, -2))

    if sanitize:
        S1 = sanitize_sigma(S1, eps=eps)  # ensure SPD (prefer float64)
        S2 = sanitize_sigma(S2, eps=eps)

    def _chol_logdet(S):
        L = np.linalg.cholesky(S)  # (..., K, K)
        diag = np.diagonal(L, axis1=-2, axis2=-1)
        logdet = 2.0 * np.sum(np.log(np.clip(diag, 1e-300, None)), axis=-1)
        return L, logdet

    try:
        L2, logdet2 = _chol_logdet(S2)
        _,  logdet1 = _chol_logdet(S1)
    except Exception:
        if strict_numerics:
            raise
        return _recover_like(mu1[..., 0], recover)

    K = mu1.shape[-1]
    dmu = mu2 - mu1                                     # (..., K)

    # --- FIXED SHAPES BELOW ---
    # Solve L2 * y = dmu  -> y shape (..., K, 1)
    y = np.linalg.solve(L2, dmu[..., None])             # (..., K, 1)
    # Solve L2^T * z = y
    z = np.linalg.solve(np.swapaxes(L2, -1, -2), y)     # (..., K, 1)
    term_quad = np.sum(dmu * np.squeeze(z, axis=-1), axis=-1)  # (...,)

    # term_trace = tr(S2^{-1} S1) via two triangular solves (no explicit inverse)
    Y = np.linalg.solve(L2, S1)                         # (..., K, K)
    X = np.linalg.solve(np.swapaxes(L2, -1, -2), Y)     # (..., K, K)
    term_trace = np.trace(X, axis1=-2, axis2=-1)        # (...,)

    kl = 0.5 * (term_trace + term_quad - K + (logdet2 - logdet1))
    # Only shave tiny negatives from roundoff; do NOT clamp or nan_to_num here.
    kl = np.where(kl < 0, np.maximum(kl, -1e-12), kl)

    if strict_numerics:
        if not np.all(np.isfinite(kl)):
            raise FloatingPointError("Nonfinite KL encountered (NaN/Inf).")
    else:
        if not np.all(np.isfinite(kl)):
            return _recover_like(kl, recover)

    if return_terms:
        return kl, {"term_trace": term_trace, "term_quad": term_quad,
                    "logdet1": logdet1, "logdet2": logdet2}
    return kl

def _recover_like(x: np.ndarray, recover: str | None):
    if recover is None or recover == "nan":
        return np.full_like(x, np.nan, dtype=np.float64)
    if recover == "zero":
        return np.zeros_like(x, dtype=np.float64)
    raise ValueError(f"Unknown recover policy: {recover}")


# Back-compat wrapper (keeps "mask" arg and N×K convention)

def kl_divergence(mu1, sigma1, mu2, sigma2, mask: Optional[np.ndarray] = None, eps: float = 1e-6):
    """Legacy name. Returns KL per batch; optional elementwise mask multiply."""
    vals = kl_gaussian(mu1, sigma1, mu2, sigma2, eps=eps)
    if mask is not None:
        m = np.asarray(mask)
        if m.ndim == 2 and m.shape[-1] == 1:
            m = np.squeeze(m, axis=-1)
        vals = vals * m
    if np.any(~np.isfinite(vals)):
        raise ValueError("[kl_divergence] NaN/Inf in output")
    return vals




def _validate_dims(mu: np.ndarray, Sigma: np.ndarray, M: np.ndarray) -> Tuple[int,int,int]:
    mu = np.asarray(mu); Sigma = np.asarray(Sigma); M = np.asarray(M)
    K_in = int(mu.shape[-1])
    if Sigma.shape[-2:] != (K_in, K_in):
        raise ValueError(f"[push_gaussian] Σ dims {Sigma.shape[-2:]} incompatible with μ dim {K_in}")
    if M.shape[-1] != K_in:
        raise ValueError(f"[push_gaussian] M last dim {M.shape[-1]} != μ dim {K_in}")
    K_out = int(M.shape[-2])
    return K_in, K_out, mu.ndim

def _near_identity_ok(M: np.ndarray, tau: float) -> bool:
    # Only meaningful if square; Frobenius norm check on (M - I)
    M = np.asarray(M)
    if M.shape[-2] != M.shape[-1]:
        return False
    K = M.shape[-1]
    I = np.eye(K, dtype=M.dtype)
    A = M - I
    # Compute per-batch Frobenius with broadcasting
    Anorm = np.sqrt(np.square(A).sum(axis=(-2, -1)))
    # “All” batches near identity: keep the rule strict to avoid mixed modes
    return bool(np.all(Anorm <= tau))

def push_gaussian(
    mu: np.ndarray,
    Sigma: np.ndarray,
    M: np.ndarray,
    *,
    eps: float = 1e-8,
    symmetrize: bool = True,
    sanitize: bool = True,
    approx: str = "auto",     # "auto" | "exact" | "first_order"
    near_identity_tau: Optional[float] = None,
    return_inv: bool = False,
):
    """
    Canonical Gaussian pushforward under a linear map.

    Args
    ----
    mu, Sigma : (..., K_in), (..., K_in, K_in)
    M        : (..., K_out, K_in)  (square for Ω; rectangular for Φ)
    eps      : jitter to keep Σ SPD
    symmetrize: force symmetry guards (recommended)
    sanitize : run sanitize_sigma at the end
    approx   : "exact", "first_order", or "auto"
    near_identity_tau: threshold for "auto" mode (Frobenius ||M-I|| ≤ tau) when square
    return_inv : also return Σ'^{-1} (exact path or first-order inverse if used)

    Returns
    -------
    (mu_out, Sigma_out) or (mu_out, Sigma_out, Sigma_out_inv)
    """
    mu = np.asarray(mu); Sigma = np.asarray(Sigma); M = np.asarray(M)
    K_in, K_out, _ = _validate_dims(mu, Sigma, M)

    # Symmetrize & pre-jitter once
    if symmetrize:
        Sigma = 0.5 * (Sigma + np.swapaxes(Sigma, -1, -2))
    Sigma = Sigma + eps * np.eye(K_in, dtype=Sigma.dtype)

    # Decide mode
    mode = approx
    if approx == "auto":
        tau = 5e-2 if near_identity_tau is None else float(near_identity_tau)
        mode = "first_order" if _near_identity_ok(M, tau) else "exact"
    elif approx not in ("exact", "first_order"):
        raise ValueError(f"[push_gaussian] unknown approx='{approx}'")

    # ---- FIRST-ORDER (only valid for square maps) ----------------------------
    if mode == "first_order":
        if K_in != K_out:
            # Can't do first-order on rectangular maps safely; fall back to exact
            mode = "exact"
        else:
            I = np.eye(K_in, dtype=M.dtype)
            A = M - I
            mu_out = np.einsum("...ik,...k->...i", A, mu, optimize=True) + mu
            A_S   = np.einsum("...ik,...kl->...il", A, Sigma, optimize=True)
            S_AT  = np.einsum("...ik,...jk->...ij", Sigma, A, optimize=True)  # ΣAᵀ
            Sigma_out = Sigma + A_S + S_AT
            if symmetrize:
                Sigma_out = 0.5 * (Sigma_out + np.swapaxes(Sigma_out, -1, -2))
            Sigma_out = Sigma_out + eps * np.eye(K_in, dtype=Sigma_out.dtype)
            if sanitize:
                Sigma_out = sanitize_sigma(Sigma_out, eps=eps)
            if return_inv:
                # First-order inverse: (Σ + AΣ + ΣAᵀ)^{-1} ≈ Σ^{-1} - Σ^{-1}A - AᵀΣ^{-1}
                Sigma_inv = safe_inv(Sigma, eps=1e-8)
                left  = np.einsum("...ij,...jk->...ik", Sigma_inv, A, optimize=True)
                right = np.einsum("...ij,...jk->...ik", np.swapaxes(A, -1, -2), Sigma_inv, optimize=True)
                Sigma_out_inv = Sigma_inv - left - right
                return mu_out.astype(mu.dtype), Sigma_out.astype(Sigma.dtype), Sigma_out_inv.astype(Sigma.dtype)
            return mu_out.astype(mu.dtype), Sigma_out.astype(Sigma.dtype)

    # ---- EXACT ---------------------------------------------------------------
    mu_out = np.einsum("...ik,...k->...i", M, mu, optimize=True)
    Sigma_out = np.einsum("...ik,...kl,...jl->...ij", M, Sigma, M, optimize=True)
    if symmetrize:
        Sigma_out = 0.5 * (Sigma_out + np.swapaxes(Sigma_out, -1, -2))
    Sigma_out = Sigma_out + eps * np.eye(K_out, dtype=Sigma_out.dtype)
    if sanitize:
        Sigma_out = sanitize_sigma(Sigma_out, eps=eps)
    if return_inv:
        Sigma_out_inv = safe_inv(Sigma_out, eps=1e-8)
        return mu_out.astype(mu.dtype), Sigma_out.astype(Sigma.dtype), Sigma_out_inv.astype(Sigma.dtype)
    return mu_out.astype(mu.dtype), Sigma_out.astype(Sigma.dtype)




# --- unified threshold resolver ---------------------------------------------------
def resolve_support_tau(ctx=None, params=None, default=1e-3, name="support_tau"):
    """
    Resolve a single support threshold used everywhere (detect/spawn/CG/viz).
    Order: params[name] > config.name > default. Persist into ctx for this step.
    """
    import core.config as CFG
    val = None
    if params and (name in params):
        val = float(params[name])
    elif hasattr(CFG, name):
        val = float(getattr(CFG, name))
    else:
        val = float(default)
    if ctx is not None:
        setattr(ctx, "_resolved_"+name, val)
    return val














