import numpy as np
import config


from get_generators import get_generators


def compute_self_gradient(
    agent_i,
    params: dict,
    mode: str = "q",                    # "q" for D_KL(q||p), "p" for D_KL(p||q)
    morphism: callable = None           # optional: (fam_other) -> ExponentialFamily
) -> np.ndarray:
    """
    Generic IG self-KL gradient:
      if mode=="q": grad w.r.t. θ_q of α_belief·D_KL(q || p or morphism(p))
      if mode=="p": grad w.r.t. θ_p of α_model·D_KL(p || q or morphism(q))
      
    morphism: a function that takes the 'other' family and returns
              an ExponentialFamily in the same coordinates as the 'self' family.
    """
    # select KL‐weight based on bundle
    if mode == "q":
        α = params.get("alpha_belief", config.alpha_belief)
    elif mode == "p":
        α = params.get("alpha_model", config.alpha_model)
    else:
        raise ValueError(f"Unknown mode: {mode!r}, expected 'q' or 'p'")

    support_eps = params.get("support_cutoff_eps", config.support_cutoff_eps)

    # select which fibers we work on
    if mode == "q":
        fam_self, fam_other = agent_i.q_fam, agent_i.p_fam
    else:  # mode == "p"
        fam_self, fam_other = agent_i.p_fam, agent_i.q_fam

    # optional morphism (e.g. bundle map)
    if morphism is not None:
        fam_other = morphism(fam_other)

    mask = agent_i.mask > support_eps
    if α <= 0 or not mask.any():
        # nothing to do if weight is zero or no support
        return np.zeros_like(fam_self.theta)

    # expectation coords (shape: (*domain, dim_theta))
    η_self  = fam_self.expectation
    η_other = fam_other.expectation

    # gradient = α·(η_self - η_other)
    grad = α * (η_self - η_other)

    # zero out gradient outside the agent’s support
    support = mask[..., None]
    grad *= support

    return grad



def compute_theta_gradient(agent_i, agents: list, params: dict, mode: str) -> np.ndarray:
    """
    Generic θ‐gradient for either belief‐ or model‐fibers.

    mode = "belief":
      ∇_{θ_q}[ α_belief·D_KL(q||p) + Σ_j β_belief·D_KL(q||Ω q_j) ]
    mode = "model":
      ∇_{θ_p}[ α_model·D_KL(p||q) + Σ_j β_model·D_KL(p||Ω̃ p_j) ]
    """
    overlap_eps = params.get("support_cutoff_eps", config.support_cutoff_eps)

    # Select family, weights, and transport builder based on mode
    if mode == "belief":
        fam_self  = agent_i.q_fam
        fam_other = agent_i.p_fam
        α         = params.get("alpha_belief", config.alpha_belief)
        β         = params.get("beta_belief",  config.beta_belief)
        # closure to transport neighbor's belief into i's coordinates
        def push_align(nbr_agent):
            Ω_ij = agent_i.Omega_belief @ nbr_agent.Omega_belief_inv
            return fam_self.push_forward(Ω_ij)

    elif mode == "model":
        fam_self  = agent_i.p_fam
        fam_other = agent_i.q_fam
        α         = params.get("alpha_model", config.alpha_model)
        β         = params.get("beta_model",  config.beta_model)
        # closure to transport neighbor's model into i's coordinates
        def push_align(nbr_agent):
            Ωt_ij = agent_i.Omega_model @ nbr_agent.Omega_model_inv
            return fam_self.push_forward(Ωt_ij)

    else:
        raise ValueError(f"Invalid mode: {mode!r}; expected 'belief' or 'model'")

    mask = agent_i.mask > overlap_eps
    if not mask.any():
        return np.zeros_like(fam_self.theta)

    grad = np.zeros_like(fam_self.theta)
    support = mask[..., None]

    # 1) Self‐KL gradient term
    if α > 0:
        η_self  = fam_self.expectation
        η_other = fam_other.expectation
        grad_self = α * (η_self - η_other)
        grad += grad_self * support

    # 2) Neighbor‐alignment gradient term
    if β > 0:
        η_self = fam_self.expectation
        nbs = max(len(agent_i.neighbors), 1)
        for j in agent_i.neighbors:
            nbr = agents[j]
            transported = push_align(nbr)
            η_nb = transported.expectation
            grad += (β / nbs) * (η_self - η_nb) * support

    return grad



def compute_phi_gradient(agent_i, agents: list, params: dict, mode: str = "belief") -> np.ndarray:
    """
    Generic φ‐gradient for either φ_belief or φ_model.

    mode = "belief":
      Σ_j β_belief·D_KL(q||Ω q_j)
      + γ_belief·Δφ_belief
      + mass_belief·φ_belief
      + gauge_coupling·φ_model

    mode = "model":
      Σ_j β_model·D_KL(p||Ω̃ p_j)
      + γ_model·Δφ_model
      + mass_model·φ_model
      + gauge_coupling·φ_belief
    """
    import numpy as np
    from get_generators import get_generators
    import config

    # 1) select fields & parameters
    if mode == "belief":
        phi           = agent_i.phi_belief
        fam           = agent_i.q_fam
        K = fam.K

        beta          = params.get("beta_belief",  config.beta_belief)
        gamma         = params.get("gamma_belief", config.gamma_belief)
        mass_coeff    = params.get("mass_belief",  config.mass_belief)
        other_phi     = agent_i.phi_model

        def push_fn(nbr):
            Ω = agent_i.Omega_belief @ nbr.Omega_belief_inv
            return fam.push_forward(Ω)

    elif mode == "model":
        phi           = agent_i.phi_model
        fam           = agent_i.p_fam
        K = fam.K

        beta          = params.get("beta_model",  config.beta_model)
        gamma         = params.get("gamma_model", config.gamma_model)
        mass_coeff    = params.get("mass_model",  config.mass_model)
        other_phi     = agent_i.phi_belief

        def push_fn(nbr):
            Ωt = agent_i.Omega_model @ nbr.Omega_model_inv
            return fam.push_forward(Ωt)

    else:
        raise ValueError(f"Unknown mode: {mode!r}")

    support_eps   = params.get("support_cutoff_eps", config.support_cutoff_eps)
    coupling      = params.get("gauge_coupling",     config.gauge_coupling)

    mask          = agent_i.mask > support_eps
    base          = np.zeros_like(phi)
    grid_pts      = mask.size
    # φ lives in the Lie‐algebra dimension, i.e. number of generators
    Gs            = get_generators(config.group_name, fam.K)
    G_count       = len(Gs)

    # Pre-slice out the K‐length mean from the 2K‐vector expectation
    eta_self_full = fam.expectation.reshape(grid_pts, 2*K)
    eta_self_mu   = eta_self_full[:, :K]    # (grid_pts, K)

    # ----------------------------------------------------------
    # 2) Neighbor-alignment KL term
    # ----------------------------------------------------------
    if beta > 0 and mask.any():
        flat_mask = mask.ravel()
        nbs       = max(len(agent_i.neighbors), 1)
        # now reshape to (grid_pts, #generators) = (400,3) in your case
        base_flat = base.reshape(grid_pts, G_count)

        for j in agent_i.neighbors:
            transported   = push_fn(agents[j])
            eta_nb_full   = transported.expectation.reshape(grid_pts, 2*fam.K)
            eta_nb_mu     = eta_nb_full[:, :K]
            delta_mu      = eta_self_mu - eta_nb_mu

            idxs = np.nonzero(flat_mask)[0]
            if idxs.size == 0:
                continue

            # stat_nb is just the neighbor means again
            stat_nb = eta_nb_mu[idxs]  # (n_pts, K)

            # for each Lie-generator direction a=0..G_count-1
            for a in range(G_count):
                G = Gs[a]  # G is a (K×K) matrix
                # stat_nb: (n_pts,K), G.T: (K,K) → (n_pts,K)
                Gs_stat = stat_nb @ G.T
                contrib = (delta_mu[idxs] * Gs_stat).sum(axis=1)
                base_flat[idxs, a] += (beta / nbs) * contrib

        base = base_flat.reshape(*mask.shape, G_count)

    # ----------------------------------------------------------
    # 3) Laplacian penalty
    # ----------------------------------------------------------
    if gamma > 0:
        from IG_math_utils import laplacian_field
        base += gamma * laplacian_field(phi)

    # ----------------------------------------------------------
    # 4) Mass term
    # ----------------------------------------------------------
    if mass_coeff > 0:
        base += mass_coeff * phi

    # ----------------------------------------------------------
    # 5) Cross-coupling φ ↔ other_phi
    # ----------------------------------------------------------
    if coupling > 0:
        base += coupling * other_phi

    return base


