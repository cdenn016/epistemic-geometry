# smoke_gaussian.py

import numpy as np
from families import GaussianFamily

# 1D test (length 8)
mu     = np.linspace(-1, 1, num=8)
sigma2 = np.full((8,), 0.5)

# Natural parameters θ = [η₁, η₂] at each point
theta = np.stack([mu / sigma2, -0.5 / sigma2], axis=-1)  # shape (8,2)
fam   = GaussianFamily(theta)

# 1) Gradient of log partition
grad = fam.grad_log_partition()
assert grad.shape == theta.shape, f"Gradient shape {grad.shape} != {theta.shape}"
assert np.all(np.isfinite(grad)), "Gradient contains non-finite entries"

# 2) Entropy non-negative
H = fam.entropy()
assert H.shape == mu.shape, f"Entropy shape {H.shape} != {mu.shape}"
assert np.all(H >= 0), f"Entropy has negative entries: {H}"

print("✓ GaussianFamily basic smoke tests passed")
