import numpy as np
from numpy.random import default_rng
from typing import List, Tuple
import matplotlib.pyplot as plt
from scipy.ndimage import gaussian_filter

import config
from families import GaussianFamily
from IG_agent_schema import Agent





# --- Mask and field generation utilities ---

def scale_to_range(field: np.ndarray, value_range: Tuple[float, float]) -> np.ndarray:
    lo, hi = value_range
    fmin, fmax = field.min(), field.max()
    dtype = getattr(config, 'dtype', field.dtype)
    if fmax <= fmin:
        return np.full_like(field, (lo + hi) / 2, dtype=dtype)
    norm = (field - fmin) / (fmax - fmin)
    return (norm * (hi - lo) + lo).astype(dtype)


def generate_soft_mask(center: Tuple[int, ...], radius: float, domain_size: Tuple[int, ...]) -> np.ndarray:
    """
    Generate a smooth radial mask for an agent centered at `center` with given `radius`.
    Uses periodic wrap in each dimension.
    """
    # Create coordinate grids for each dimension
    grids = np.ogrid[tuple(slice(0, s) for s in domain_size)]
    # Initialize squared distance array in full domain shape
    dist_sq = np.zeros(domain_size, dtype=float)
    # Compute squared distance with periodic boundaries
    for d, size in enumerate(domain_size):
        delta = np.abs(grids[d] - center[d])
        # periodic wrap-around
        delta = np.minimum(delta, size - delta)
        # Add squared contribution
        dist_sq += delta ** 2
    # Compute radial mask
    dist = np.sqrt(dist_sq)
    r = max(radius, np.finfo(float).eps)
    mask = np.exp(-(dist / r)**2)
    cutoff = getattr(config, 'support_cutoff_eps', 1e-3)
    mask[mask < cutoff] = 0.0
    return mask.astype(getattr(config, 'dtype', mask.dtype))



def create_smooth_fields(domain_size: Tuple[int, ...], rng: default_rng, K: int):
    mu_q_range = config.q_mu_range
    sigma_q_range = config.q_sigma_range
    mu_smooth = rng.uniform(*config.mu_field_smooth_range)
    sig_smooth = rng.uniform(*config.sigma_field_smooth_range)
    if config.similar_p_models:
        base_mu = rng.uniform(*mu_q_range)
        base_sig = rng.uniform(*sigma_q_range)
        mu_p = np.full(domain_size, base_mu)
        sigma_p = np.full(domain_size, base_sig)
    else:
        mu_p = scale_to_range(rng.standard_normal(domain_size) * mu_smooth, config.p_mu_range)
        sigma_p = scale_to_range(rng.standard_normal(domain_size) * sig_smooth, config.p_sigma_range)
    mu_q = scale_to_range(rng.standard_normal(domain_size) * mu_smooth, mu_q_range)
    sigma_q = scale_to_range(rng.standard_normal(domain_size) * sig_smooth, sigma_q_range)
    return mu_q, sigma_q, mu_p, sigma_p


def initialize_phi_fields(domain_size: Tuple[int, ...], lie_dim: int,
                           rng: default_rng, phi_init: float,
                           phi_model_offset: float, mask: np.ndarray):
    sigma = config.phi_init_smooth_sigma
    phi = rng.normal(scale=phi_init, size=(*domain_size, lie_dim))
    phi = gaussian_filter(phi, sigma=sigma) * mask[..., None]
    delta = rng.normal(scale=phi_model_offset, size=(*domain_size, lie_dim))
    phi_model = gaussian_filter(phi + delta, sigma=sigma) * mask[..., None]
    return phi, phi_model

# --- Core agent initialization ---

def initialize_agents(
    seed: int,
    domain_size: Tuple[int, ...],
    N: int,
    K: int,
    lie_algebra_dim: int,
    visualize: bool = False,
    fixed_location: bool = True
) -> List[Agent]:
    rng = default_rng(seed)
    phi_init = config.phi_init
    phi_model_offset = config.phi_model_offset
    max_neighbors = config.max_neighbors

    fixed_center = tuple(s // 2 for s in domain_size) if fixed_location else None
    agents: List[Agent] = []

    for i in range(N):
        center = fixed_center or tuple(rng.integers(0, s) for s in domain_size)
        radius = rng.uniform(*config.psi_radius_range)
        mask = generate_soft_mask(center, radius, domain_size)
        mu_q, sigma_q, mu_p, sigma_p = create_smooth_fields(domain_size, rng, K)

        theta_q = np.stack([mu_q / sigma_q, -0.5 / sigma_q], axis=-1)
        theta_p = np.stack([mu_p / sigma_p, -0.5 / sigma_p], axis=-1)

        q_fam = GaussianFamily(theta_q)
        p_fam = GaussianFamily(theta_p)

        phi_belief, phi_model = initialize_phi_fields(
            domain_size, lie_algebra_dim, rng,
            phi_init, phi_model_offset, mask
        )

        agent = Agent(
            id=i,
            mask=mask,
            q_fam=q_fam,
            p_fam=p_fam,
            phi_belief=phi_belief,
            phi_model=phi_model,
            center=center,
            radius=radius,
            neighbors=[],
        )
        agents.append(agent)

    # assign neighbors based on overlap
    assign_neighbors(agents, max_neighbors)
    return agents

# --- Neighbor utilities ---

def assign_neighbors(agents: List[Agent], max_neighbors: int) -> None:
    masks = np.stack([a.mask.flatten() for a in agents])
    overlap = masks @ masks.T
    np.fill_diagonal(overlap, 0)
    for idx, agent in enumerate(agents):
        neigh = np.argsort(-overlap[idx])[:max_neighbors]
        agent.neighbors = list(neigh)


def adjacency_matrix(agents: List[Agent], threshold: float = 1e-6) -> np.ndarray:
    N = len(agents)
    adj = np.zeros((N, N), dtype=int)
    for i, a in enumerate(agents):
        for j, b in enumerate(agents):
            if i != j and a.is_neighbor(b, threshold):
                adj[i, j] = 1
    return adj


def plot_overlap_heatmap(agents: List[Agent], idx1: int, idx2: int) -> None:
    a, b = agents[idx1], agents[idx2]
    ov = a.overlap_region(b)
    fig, axs = plt.subplots(1, 3, figsize=(12, 4))
    axs[0].imshow(a.mask, origin='lower', cmap='Blues'); axs[0].set_title(f"Agent {idx1} Mask")
    axs[1].imshow(b.mask, origin='lower', cmap='Greens'); axs[1].set_title(f"Agent {idx2} Mask")
    axs[2].imshow(ov, origin='lower', cmap='Reds'); axs[2].set_title("Overlap Region")
    plt.tight_layout()
    plt.show()
