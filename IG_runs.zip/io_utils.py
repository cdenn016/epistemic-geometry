import os
import pickle
import hashlib
import csv
import re
import config
import omega
import run_simulation
import spatial_utils
import families
import IG_agent_schema
import IG_agents
import IG_math_utils
import IG_metrics
import IG_update_rules
import IG_update_terms





def hash_q(agent):
    """
    Compute a SHA256 hash of the belief field `q` of an agent to detect changes.
    """
    return hashlib.sha256(agent.q.tobytes()).hexdigest()



def save_config_to_readme(outdir="checkpoints"):
    """
    Save current config parameters into a README.txt file inside the output directory.
    This makes simulation runs reproducible by logging all config values used.
    """
    readme_path = os.path.join(outdir, "README.txt")
    with open(readme_path, "w") as f:
        f.write("Simulation Configuration Parameters\n")
        f.write("===================================\n\n")
        for key in dir(config):
            if key.startswith("__"):
                continue
            val = getattr(config, key)
            if callable(val):
                continue
            f.write(f"{key} = {val}\n")



def save_metrics_csv(metrics_list, filepath):
    """
    Save a list of dictionaries (metrics) as a CSV file.
    Handles UTF-8 encoding for special characters.
    """
    if not metrics_list:
        print("[WARNING] No metrics to save.")
        return

    fieldnames = list(metrics_list[0].keys())

    with open(filepath, mode="w", newline="", encoding="utf-8") as csvfile:
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(metrics_list)


def save_step(agents, outdir, step):
    """
    Save agent state to step_{step:04d}.pkl and update checkpoint.pkl atomically.
    """
    os.makedirs(outdir, exist_ok=True)
    step_path = os.path.join(outdir, f"step_{step:04d}.pkl")
    ckpt_path = os.path.join(outdir, "checkpoint.pkl")

    with open(step_path, "wb") as f:
        pickle.dump(agents, f)
    with open(ckpt_path, "wb") as f:
        pickle.dump(agents, f)


def load_checkpoint(outdir):
    """
    Load latest checkpoint.pkl or fallback to latest step_XXXX.pkl in outdir.
    Returns (agents, filename) or (None, None) if none found.
    """
    ckpt_path = os.path.join(outdir, "checkpoint.pkl")
    if os.path.exists(ckpt_path):
        with open(ckpt_path, "rb") as f:
            return pickle.load(f), "checkpoint.pkl"

    step_files = sorted(
        [f for f in os.listdir(outdir) if f.startswith("step_") and f.endswith(".pkl")]
    )
    if not step_files:
        return None, None

    last_step = step_files[-1]
    with open(os.path.join(outdir, last_step), "rb") as f:
        return pickle.load(f), last_step


def find_resume_step(outdir):
    """
    Determine the next step to resume from based on existing saved steps.
    Returns 0 if none found.
    """
    step_files = sorted(
        [f for f in os.listdir(outdir) if f.startswith("step_") and f.endswith(".pkl")]
    )
    if not step_files:
        return 0
    last_step = step_files[-1]
    return int(last_step.replace("step_", "").replace(".pkl", "")) + 1


def load_all_steps(outdir):
    """
    Load all step_*.pkl files as a list of agent states.
    """
    step_files = sorted(
        [f for f in os.listdir(outdir) if f.startswith("step_") and f.endswith(".pkl")]
    )
    state_log = []
    for fname in step_files:
        with open(os.path.join(outdir, fname), "rb") as f:
            state_log.append(pickle.load(f))
    return state_log


def list_step_files(run_path):
    """
    Return sorted list of (step_number, filepath) tuples for step files.
    """
    step_files = []
    for fname in os.listdir(run_path):
        match = re.match(r"step_(\d+)\.pkl", fname)
        if match:
            step_num = int(match.group(1))
            step_files.append((step_num, os.path.join(run_path, fname)))
    return sorted(step_files)


def load_final_step(run_path):
    """
    Load the agent state from the final step file in a run directory.
    Returns None if no step files found.
    """
    step_files = list_step_files(run_path)
    if not step_files:
        return None
    _, last_file = step_files[-1]
    with open(last_file, "rb") as f:
        return pickle.load(f)
