# -*- coding: utf-8 -*-
"""
Created on Thu Jun 26 15:39:37 2025

@author: chris and christine
"""

import numpy as np
import pytest
from families import GaussianFamily

def test_from_mu_sigma_and_expectation_roundtrip():
    # choose random mean and variance fields
    rng = np.random.default_rng(0)
    mu      = rng.uniform(-1, 1, size=(10,))    # 1D K=10
    sigma2  = rng.uniform(0.1, 2.0, size=(10,))
    
    # build from (μ, σ²)
    fam1 = GaussianFamily.from_mu_sigma(mu, sigma2)
    # compute η = E[T(X)] = [mean, second moment]
    eta  = fam1.expectation
    
    # rebuild from expectation
    fam2 = GaussianFamily.from_expectation(eta)
    
    # their θ vectors should match
    assert np.allclose(fam1.theta, fam2.theta), "Round-trip θ mismatch"

def test_log_partition_and_grad_consistency():
    # small K
    K = 3
    # natural params θ = [θ1, θ2]
    # θ2 must be negative
    theta1 = np.array([0.5, -1.0, 2.0])
    theta2 = np.array([-1.0, -0.8, -0.5])
    theta  = np.concatenate([theta1, theta2])
    
    fam = GaussianFamily(theta)
    A   = fam.log_partition()
    grad = fam.grad_log_partition()
    
    # finite values
    assert np.isfinite(A),     "log_partition returned non-finite"
    assert grad.shape == (2*K,), "grad shape wrong"
    assert np.all(np.isfinite(grad)), "grad has non-finite entries"

def test_kl_divergence_zero_and_push_forward_invariance():
    # create two identical families
    mu = np.zeros(5)
    sig2 = np.ones(5)
    fam = GaussianFamily.from_mu_sigma(mu, sig2)
    
    # KL[p||p] should be zero
    assert pytest.approx(0.0, abs=1e-8) == fam.kl(fam)
    
    # test push_forward by an identity Omega
    # Omega needs shape (...,K,K). Here no spatial dims.
    K = 5
    Omega = np.eye(K)
    fam_rot = fam.push_forward(Omega)
    
    # identical θ under identity rotation
    assert np.allclose(fam.theta, fam_rot.theta), "push_forward with I changed θ"

def test_entropy_nonnegative():
    mu = np.random.normal(size=4)
    sig2 = np.random.uniform(0.2, 2.0, size=4)
    fam = GaussianFamily.from_mu_sigma(mu, sig2)
    H = fam.entropy()
    # Shannon entropy of a Gaussian ≥ 0
    assert np.all(H >= 0), "entropy negative"

if __name__ == "__main__":
    import pytest
    pytest.main([__file__])
