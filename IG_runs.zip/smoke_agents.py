# -*- coding: utf-8 -*-
"""
Created on Thu Jun 26 15:44:26 2025

@author: chris and christine
"""

# smoke_agents.py
from IG_agents import initialize_agents
import config

# minimal config overrides
config.N = 2
config.domain_size = (8,8)
config.K = 3
config.psi_radius_range = (2, 4)
config.q_mu_range = (1, 2)
config.q_sigma_range = (0.5, 1.0)
# also ensure any other required config fields are set...

agents = initialize_agents(
    seed=0,
    domain_size=config.domain_size,
    N=config.N,
    K=config.K,
    lie_algebra_dim=3,
    visualize=False,
    fixed_location=True
)

assert len(agents) == 2, "Expected 2 agents"
for A in agents:
    assert A.mask.shape == config.domain_size, "Mask shape wrong"
    assert A.mask.sum() > 0, "Mask empty"
    # each GaussianFamily is univariate ⇒ θ has 2 components (η₁, η₂) per point
    assert A.q_fam.theta.shape[-1] == 2, f"Expected θ last‐dim = 2, got {A.q_fam.theta.shape[-1]}"


print("✓ Agent initialization smoke tests passed")
