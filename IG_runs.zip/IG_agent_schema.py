# ig_agent_schema.py
from dataclasses import dataclass, field
from typing import Tuple, List, Dict, Any
from families import ExponentialFamily
from agent_chains import construct_spatial_path_nd as find_spatial_paths

import numpy as np


@dataclass
class Agent:
    """
    Information-Geometry Agent schema: holds compact exponential-family fibers
    and gauge phases for beliefs and models, plus spatial mask and topology.
    """
    id: int
    mask: np.ndarray                     # spatial support mask (bool or float)
    q_fam: "ExponentialFamily"         # belief fiber in natural-parameter space
    p_fam: "ExponentialFamily"         # model fiber in natural-parameter space
    phi_belief: np.ndarray               # gauge phase field for belief transport
    phi_model: np.ndarray                # gauge phase field for model transport
    center: Tuple[int, ...]              # spatial grid center
    radius: float                        # effective support radius
    neighbors: List[int]                 # list of neighbor agent IDs

    metrics_log: List[Dict[str, Any]] = field(default_factory=list)

    def log_metrics(self, step: int, stats: Dict[str, Any]) -> None:
        """
        Record diagnostic stats for this agent at a given step.
        """
        entry = {'step': step}
        entry.update(stats)
        self.metrics_log.append(entry)

    def clear_phi_cache(self) -> None:
        """
        Reset any cached exponentials of phi fields.
        """
        self._exp_phi_belief = None
        self._exp_phi_model = None

    @property
    def Omega_belief(self) -> np.ndarray:
        """
        At each spatial point c, compute Ω(c) = expm( Σ_a φ_belief(c,a)·G_a )
        where {G_a} are the lie‐algebra generators.
        """
        if getattr(self, '_exp_phi_belief', None) is None:
            from get_generators import get_generators
            from scipy.linalg import expm
            import config

            # φ_belief.shape == (*grid_shape, dim), and we need K = q_fam.K
            Gs = get_generators(config.group_name, self.q_fam.K)
            grid_shape = self.phi_belief.shape[:-1]
            K = self.q_fam.K
            # allocate ( *grid_shape, K, K )
            O = np.zeros(grid_shape + (K, K))

            # for each spatial index, form H = Σ_a φ(c,a) Gs[a], then expm(H)
            for idx in np.ndindex(*grid_shape):
                H = sum(self.phi_belief[idx + (a,)] * Gs[a] for a in range(len(Gs)))
                O[idx] = expm(H)

            self._exp_phi_belief = O
        return self._exp_phi_belief

    @property
    def Omega_belief_inv(self) -> np.ndarray:
        # now that Omega_belief is (...,K,K), np.linalg.inv will invert each K×K
        return np.linalg.inv(self.Omega_belief)

    @property
    def Omega_model(self) -> np.ndarray:
        """
        At each spatial point c, compute Ω_model(c) = expm( Σ_a φ_model(c,a)·G_a )
        where {G_a} are the lie‐algebra generators.
        """
        if getattr(self, '_exp_phi_model', None) is None:
            from get_generators import get_generators
            from scipy.linalg import expm
            import config

            # φ_model.shape == (*grid_shape, dim), need K = p_fam.K
            Gs = get_generators(config.group_name, self.p_fam.K)
            grid_shape = self.phi_model.shape[:-1]
            K = self.p_fam.K
            # allocate (*grid_shape, K, K)
            O_model = np.zeros(grid_shape + (K, K))

            # for each spatial index, form H = Σ_a φ_model(c,a) Gs[a], then expm(H)
            for idx in np.ndindex(*grid_shape):
                H = sum(self.phi_model[idx + (a,)] * Gs[a] for a in range(len(Gs)))
                O_model[idx] = expm(H)

            self._exp_phi_model = O_model
        return self._exp_phi_model

    @property
    def Omega_model_inv(self) -> np.ndarray:
        return np.linalg.inv(self.Omega_model)

    # --- Topology / spatial methods ---
    def is_neighbor(self, other: 'Agent', overlap_threshold: float = 1e-6) -> bool:
        """
        Return True if this agent overlaps with `other` by at least `overlap_threshold`.
        """
        overlap = np.sum(self.mask * other.mask)
        return overlap > overlap_threshold

    def overlap_region(self, other: 'Agent') -> np.ndarray:
        """
        Return the spatial mask of points where both agents' supports overlap.
        """
        return self.mask * other.mask

    def distance_to(self, other: 'Agent') -> float:
        """
        Euclidean distance between this agent's center and another's.
        """
        return float(np.linalg.norm(np.array(self.center) - np.array(other.center)))

    def find_spatial_paths(self, max_length=None) -> List[List[int]]:
        """
        Find all simple spatial paths within this agent's mask up to max_length.
        Returns a list of paths (lists of linear indices or coordinates).
        """
        # delegate to external utility, passing mask and length constraint
        return find_spatial_paths(self.mask, max_length)
