import config
import sys

def set_config_from_params(params):
    """Safely override known config attributes from a dictionary
    and then recompute all dependent quantities."""
    # 1) Override raw params into config.py
    valid_keys = {
        k for k in dir(config)
        if not k.startswith("__") and not callable(getattr(config, k))
    }

    for k, v in params.items():
        if k in valid_keys:
            setattr(config, k, v)
        else:
            print(f"[WARNING] Ignored unknown config key: '{k}'")

    # 2) Notice keys you didn’t touch
    unused = valid_keys - set(params.keys())
    for k in sorted(unused):
        print(f"[NOTICE] Config key '{k}' not set by params — using default or previous value.")

    # ── Recompute all dependent learning rates using scaled_eta ──────────────────
    config.eta_q = config.scaled_eta(
        config.eta_base_q,
        config.alpha_belief,
        config.beta_belief
    )
    config.eta_p = config.scaled_eta(
        config.eta_base_p,
        config.alpha_model,
        config.beta_model,
        config.alpha_belief,
        config.gauge_coupling
    )
    config.eta_phi_belief = config.scaled_eta(
        config.eta_base_phi_belief,
        config.gamma_belief,
        config.mass_belief,
        config.gauge_coupling,
        config.curv_coupling_belief
    )
    config.eta_phi_model = config.scaled_eta(
        config.eta_base_phi_model,
        config.gamma_model,
        config.mass_model,
        config.gauge_coupling,
        config.curv_coupling_model
    )
    # ───────────────────────────────────────────────────────────────────────────

    # ── Recompute spatial sizing & any K-dependent ranges ───────────────────────
    config.domain_size = (config.L,) * config.D
    config.q_mu_range = (2, config.K - 2)
    config.p_mu_range = (2, config.K - 2)
    # ───────────────────────────────────────────────────────────────────────────

    # ── DEBUG: show that params were loaded and η’s updated ─────────────────────
    print(f"[DEBUG] set_config_from_params: "
          f"eta_q={config.eta_q:.3e}, "
          f"eta_p={config.eta_p:.3e}, "
          f"eta_phi_belief={config.eta_phi_belief:.3e}, "
          f"eta_phi_model={config.eta_phi_model:.3e}, "
          f"domain_size={config.domain_size}")
    # ───────────────────────────────────────────────────────────────────────────
