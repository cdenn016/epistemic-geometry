# -*- coding: utf-8 -*-
"""
Created on Wed Jun 25 21:12:47 2025

@author: chris and christine
"""



from IG_update_rules import synchronous_step

# Build two overlapping Gaussian agents on a tiny grid
from IG_agents import initialize_agents
import config
from get_generators import get_generators   # or however you pull in your lie‐algebra dim

# decide on a fixed seed and get the algebra dimension
seed = config.agent_seed
lie_algebra_dim = len(get_generators(config.group_name, config.K))

# build two agents on a 20×20 grid
agents = initialize_agents(
    seed          = seed,
    domain_size   = (20, 20),
    N             = 2,
    K             = config.K,
    lie_algebra_dim = lie_algebra_dim,
    visualize     = False,
    fixed_location= False
)

# Run one synchronous update
agents = synchronous_step(agents, params={}, n_jobs=1)
print("Step completed; θ and φ have shapes:")
print(" q θ-shape:", agents[0].q_fam.theta.shape,
      " φ-shape:", agents[0].phi_belief.shape)
