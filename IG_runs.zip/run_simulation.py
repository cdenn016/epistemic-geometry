import os
import pandas as pd

from get_generators import get_generators
from config_utils import set_config_from_params
from IG_agents import initialize_agents
from IG_update_rules import synchronous_step
from IG_metrics import log_all_metrics_IG

import config


def run_simulation(outdir="checkpoints"):
    # (re)load any overrides you want into config
    set_config_from_params({})

    # prep output dir
    os.makedirs(outdir, exist_ok=True)

    # precompute your Lie‑algebra generators
    gens = get_generators(config.group_name, config.K)

    # initialize fresh agents
    lie_dim = gens.shape[0]
    agents = initialize_agents(
        seed            = getattr(config, "agent_seed", None),
        domain_size     = config.domain_size,
        N               = config.N,
        K               = config.K,
        lie_algebra_dim = lie_dim,
        visualize       = False,
        fixed_location  = False
    )

    # container for per‑agent logs (filled during synchronous_step)
    # ensure each agent has an empty metrics_log
    for ag in agents:
        ag.metrics_log = []

    print("Using learning rates:")
    print("  eta_q          ", config.eta_q)
    print("  eta_p          ", config.eta_p)
    print("  eta_phi_belief ", config.eta_phi_belief)
    print("  eta_phi_model  ", config.eta_phi_model)

    # run the Euler‑step loop
# run the Euler-step loop and collect global summaries
    all_metrics = []
    for step in range(config.steps):
        print(f"[STEP {step+1}/{config.steps}]")
        agents = synchronous_step(
            agents,
            params=None,  # all rates & weights come from config
            n_jobs=config.num_cores
            )
    # log global metrics summary this step
        summary = log_all_metrics_IG(
            agents,
            step,
            weights=None,
            support_eps=None,
            n_jobs=config.num_cores
            )
        all_metrics.append(summary)

# assemble into DataFrame of global summaries
    metrics_df = pd.DataFrame(all_metrics)
    return agents, metrics_df



if __name__ == "__main__":
    # Short parameterized simulation run
    from config_utils import set_config_from_params

    # apply custom learning rates
    test_params = {
        'eta_q':            0.1,
        'eta_p':            0.1,
        'eta_phi_belief':   0.05,
        'eta_phi_model':    0.05,
    }
    set_config_from_params(test_params)

    # override simulation parameters
    set_config_from_params({
        'agent_seed':    config.agent_seed,
        'domain_size':   (20, 20),
        'N':             2,
        'K':             5,
        'steps':         5,
        'num_cores':     1,
    })

    agents, metrics_df = run_simulation(outdir="checkpoints")
    print(metrics_df.head())
    print("Final θ mean:", agents[0].q_fam.theta.mean(), agents[1].q_fam.theta.mean())
    print("Final φ std:", agents[0].phi_belief.std(), agents[1].phi_belief.std())
