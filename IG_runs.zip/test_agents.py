import numpy as np
from IG_agents import initialize_agents
import config

def test_initialize_agents_minimal():
    # minimal overrides
    config.N = 2
    config.domain_size = (8,8)
    config.K = 3
    config.psi_radius_range = (2, 4)
    config.q_mu_range = (1, 2)
    config.q_sigma_range = (0.5, 1.0)
    config.p_mu_range = (1, 2)
    config.p_sigma_range = (0.5, 1.0)
    # ensure any other required config fields are set here...

    agents = initialize_agents(
        seed=0,
        domain_size=config.domain_size,
        N=config.N,
        K=config.K,
        lie_algebra_dim=3,
        visualize=False,
        fixed_location=True
    )

    assert len(agents) == 2
    for A in agents:
        assert A.mask.shape == config.domain_size
        assert A.mask.sum() > 0
        assert A.q_fam.theta.shape[-1] == 2, \
            f"Expected univariate Gaussian θ dimension = 2, got {A.q_fam.theta.shape[-1]}"


if __name__ == "__main__":
    import pytest
    pytest.main(["-vv", __file__])
