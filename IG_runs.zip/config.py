import numpy as np
import sys

# ===========================
# DEBUGGING AND UTILITIES
# ===========================

# 1) define at top of your script/module
def scaled_eta(base, *weights, min_den=1.0):
    """
    If all weights sum to zero, return base.
    Otherwise return base / max(sum(weights), min_den).
    """
    total = sum(weights)
    if total <= 0:
        return base
    return base / max(total, min_den)



def set_config_from_params(params):
    """Dynamically override config attributes from a dictionary."""
    this_module = sys.modules[__name__]
    for k, v in params.items():
        setattr(this_module, k, v)


# ===========================
# GROUP & REPRESENTATION SETTINGS
# ===========================

group_name = 'sl2r'               # Options: "u1", "so3", "sl2r", 'su2'.
representation_type = 'irrep'     # Options: 'irrep', 'fundamental', 'adjoint'
use_commutator = False            # use "false" to use the general exp.exp multiplication
debug = True  # Global debug flag for extra logging inside φ updates
                      

# ===========================
# DOMAIN / SPATIAL SETTINGS
# ===========================
K = 39          # Fiber dimension of belief/model space (depends on representation)
D = 2            #dimension of base manifold

L = 50           #length of hypercubic base-manifold

steps = 100

N = 5                          # Number of agents
max_neighbors = 4                # Max number of agent neighbors
agent_seed = 23


# ===========================
# COUPLINGS & PENALTIES
# ===========================


e_belief = 1                           #belief gauge charge how credulous or sensitive an agent is when aligning its beliefs to the social field.
e_model = 1                            #model gauge charge  how prone it is to adjust its internal model when “reading” others.

alpha_belief = 1                     # KL(q || p) self-energy
beta_belief = 5                    # KL(q || Ω q) belief coupling
gamma_belief = 1                    # Laplacian penalty on φ
mass_belief = 1           # φ² mass term

beta_model = 5      # KL(p || Ω̃ p) analogous to beta
gamma_model = 1       # Laplacian penalty on φ_model
mass_model = 1     # φ_model² mass term
alpha_model = 3     # KL feedback p || q analogous to alpha

gauge_coupling = 3   # Coupling φ ↔ φ̃

curv_coupling_belief = 0
curv_coupling_model  = 0


# alias for curvature coupling
curvature_belief = curv_coupling_belief
curvature_model  = curv_coupling_model

# ---------------------------------------------------------------------
# placeholder weights for future bundle‐morphism KL terms
# ---------------------------------------------------------------------
cross_kl_belief_weight = 0.0   # weight on D_KL(qᵢ‖Φ_model Ω̃ pⱼ)
cross_kl_model_weight  = 0.0   # weight on D_KL(pᵢ‖Φ_belief Ω qⱼ)

psi_radius_range = (5, 7)         #agent radii

# ===========================
# DISTRIBUTION SETTINGS
# ===========================
spatial_resolution = 1
distribution_family = 'gaussian'   # Options: "gaussian", "exponential", "beta". "uniform", etc.


#=================================
# TRANSPORT DISTRIBUTION INJECTION
#=================================
injection_mode = "from_q"  # or "gaussian", "from_q", "from_p, "delta", etc

num_cores = -1


# ===========================
# AGENT GEOMETRY
# ===========================
q_mu_range = (2, K-2)
q_sigma_range = (1, 4)
p_mu_range = (2, K-2)
p_sigma_range = (1, 3)
similar_p_models = False


mu_sigma_scale_range = (2, 6)

mask_sharpness = 1.5
mu_field_smooth_range = (2, 6)
sigma_field_smooth_range = (2,6)

# ===========================
# INITIALIZATION
# ===========================



phi_init_smooth_sigma = 2
phi_init = 0.2
phi_model_offset = 0.1



# 2) keep your base‐rate definitions
eta_base_q                = 1e-5    # Leaves Δq ≃ 0.02 per step
eta_base_p                = 1e-5    # Similarly for p
eta_base_phi_belief       = 4e-3    # Δφ ≃ 0.02–0.05 per step
eta_base_phi_model        = 4e-3  # Δφ̃ ≃ 0.02 per step

# scaled learning rates
eta_q = scaled_eta(
    eta_base_q,
    alpha_belief,
    beta_belief
)

eta_p = scaled_eta(
    eta_base_p,
    alpha_model,
    beta_model,
    alpha_belief,    # if you want p||q feedback
    gauge_coupling
)

eta_phi_belief = scaled_eta(
    eta_base_phi_belief,
    gamma_belief,
    mass_belief,
    gauge_coupling,
    curv_coupling_belief
)

eta_phi_model = scaled_eta(
    eta_base_phi_model,
    gamma_model,
    mass_model,
    gauge_coupling,
    curv_coupling_model
)


# ===========================
# STABILITY AND CLIPPING
# ===========================

phi_clip_threshold = 4000       # scale down large φ shifts
phi_max_norm       = 100       # keep φ in a reasonable reference frame
gradient_clip      = 1e4      # if also applied to φ gradients
blowup_threshold   = 4000.0      # skip updates that are clearly unstable
phi_diff_clip = 3.0            # or experiment with values like 2.0 or 5.0


# ===========================
# EPSILONS & PRECISION
# ===========================

log_eps = 1e-10
support_cutoff_eps = 1e-2           #agent and mask overlap = at 1e-1
overlap_eps = 1e-5
eps = 1e-10

precision = np.float64

# ===========================
# CHECKPOINTING
# ===========================

checkpoint_dir = "checkpoints"
save_checkpoints = True
checkpoint_interval = 1

domain_size = (L,) * D

if __name__ == "__main__":
    # Print out the key computed rates to verify everything loaded
    print(f"psi_radius_range   = {psi_radius_range}")
    print(f"eta_q              = {eta_q:.2e}")
    print(f"eta_p              = {eta_p:.2e}")
    print(f"eta_phi_belief     = {eta_phi_belief:.2e}")
    print(f"eta_phi_model      = {eta_phi_model:.2e}")
