from __future__ import annotations
"""
Created on Tue Aug 12 20:36:43 2025

@author: chris and christine
"""
# -*- coding: utf-8 -*-
"""run_sim_utils — streamlined"""

import os, pickle

import numpy as np
import core.config as config

from core.get_generators import make_reducible_generators
from diagnostics import compute_global_metrics, print_energy_breakdown
from core.agent_initialization import initialize_agents
from dataclasses import asdict

from runtime_context import build_step_settings_from_overrides  # already in your file
from diagnostics import total_energy
import json, pathlib

from runtime_context import cfg_get
# ------------------------------- Logging defaults ----------------------------

STEP_KEYS = set(asdict(build_step_settings_from_overrides(config, {})).keys())



def _pre_checkpoint_cleanup(agents):
    """
    Drop/clear large transient caches so checkpoints stay small.
    Calls common methods if present; otherwise clears known attributes.
    Safe no-ops if attributes/methods don't exist.
    """
    for A in agents:
        # Try explicit compactors first
        for meth in (
            "compact_for_checkpoint",
            "clear_omega_cache",
            "clear_fisher_caches",
            "clear_transport_cache",
            "clear_theta_cache",
            "clear_misc_cache",
        ):
            if hasattr(A, meth):
                try:
                    getattr(A, meth)()
                except Exception:
                    pass

        # Then try to clear/delete typical cache attributes
        for attr in (
            "omega_cache",
            "fisher_cache",
            "transport_cache",
            "theta_cache",
            "misc_cache",
        ):
            if hasattr(A, attr):
                try:
                    obj = getattr(A, attr)
                    if hasattr(obj, "clear"):
                        obj.clear()
                    else:
                        setattr(A, attr, None)
                except Exception:
                    pass




def _extract_global_from_Q(Q) -> dict:
    """
    Accepts a dict-like or object 'Q' from compute_total_action(...) and
    returns ONLY numeric fields for logging. Skips strings/bools and metadata.
    Also supports tiny dicts like {'value': 1.23, 'w': 1, 'src': 'cached'}.
    """
   
    import numbers as _numbers

    def _is_num(x):
        # true for Python/NumPy numbers, false for bools
        if isinstance(x, (bool, np.bool_)):
            return False
        return isinstance(x, _numbers.Number) or (isinstance(x, np.generic) and np.issubdtype(type(x), np.number))

    def _coerce_num(x):
        # dict with 'value' → extract; tuple/list → first numeric element; else None
        if _is_num(x):
            return float(x)
        if isinstance(x, dict) and "value" in x and _is_num(x["value"]):
            return float(x["value"])
        if isinstance(x, (list, tuple)) and len(x) > 0 and _is_num(x[0]):
            return float(x[0])
        return None

    out = {}
    if Q is None:
        return out

    if isinstance(Q, dict):
        for k, v in Q.items():
            val = _coerce_num(v)
            if val is not None:
                out[k] = val
        return out

    # object-like fallback: pick common attributes if numeric
    for k in ("Action_total","Geom_total","VFE_acc","A_curv","A_cov","ModelPrior","Curv","Frame","Comm_KL","Transp_KL"):
        if hasattr(Q, k):
            val = _coerce_num(getattr(Q, k))
            if val is not None:
                out[k] = val
    return out






def log_and_viz_after_step(runtime_ctx, agents, step, outdir,
                           parent_metrics, metric_log, num_cores):
    ctx = runtime_ctx

    # 0) cheap throttle knobs (defaults keep current behavior)
    cfg = getattr(ctx, "step_cfg", None)
    print_energy_every = int(getattr(cfg, "print_energy_every", 1))   # e.g. 5
    log_metrics_every  = int(getattr(cfg, "log_metrics_every", 1))    # e.g. 1

    # 1) compute ONCE
    metrics_global = compute_global_metrics(ctx, agents)

    # 2) optionally print heavy, formatted breakdown
    if (step % print_energy_every) == 0:
        print_energy_breakdown(ctx, metrics_global)

    # 3) get total + breakdown WITHOUT recomputing metrics
    E, terms = total_energy(ctx, agents, return_breakdown=True,
                            precomputed_metrics=metrics_global)
    metrics_global = dict(terms); metrics_global["E_total"] = E

    # 4) optionally append to metric_log less frequently (still accurate)
    if (step % log_metrics_every) == 0:
        metric_log.append({
            "step": int(getattr(ctx, "global_step", step)),
            "E_total":      float(metrics_global.get("E_total", 0.0)),
            "mean_total":   float(metrics_global.get("mean_total", 0.0)),
            "self_sum":     float(metrics_global.get("self", 0.0)),
            "feedback_sum": float(metrics_global.get("feedback", 0.0)),
            "mass_q_sum":   float(metrics_global.get("mass_q", 0.0)),
            "mass_p_sum":   float(metrics_global.get("mass_p", 0.0)),
            "curv_q_sum":   float(metrics_global.get("curv_q", 0.0)),
            "curv_p_sum":   float(metrics_global.get("curv_p", 0.0)),
            "align_q_sum":  float(metrics_global.get("align_q", 0.0)),
            "align_p_sum":  float(metrics_global.get("align_p", 0.0)),
        })






def load_checkpoint(outdir: str):
    # prefer compressed if present
    for name in ("checkpoint.pkl.xz", "checkpoint.pkl.gz", "checkpoint.pkl"):
        p = os.path.join(outdir, name)
        if os.path.exists(p):
            if name.endswith(".xz"):
                import lzma
                with lzma.open(p, "rb") as f:
                    return pickle.load(f), name
            if name.endswith(".gz"):
                import gzip
                with gzip.open(p, "rb") as f:
                    return pickle.load(f), name
            with open(p, "rb") as f:
                return pickle.load(f), name

    # fall back to last step_XXXX
    step_files = sorted(
        f for f in os.listdir(outdir)
        if f.startswith("step_") and (f.endswith(".pkl") or f.endswith(".pkl.xz") or f.endswith(".pkl.gz"))
    )
    if not step_files:
        return (None, None)
    last = step_files[-1]
    p = os.path.join(outdir, last)
    if last.endswith(".xz"):
        import lzma
        with lzma.open(p, "rb") as f:
            return pickle.load(f), last
    if last.endswith(".gz"):
        import gzip
        with gzip.open(p, "rb") as f:
            return pickle.load(f), last
    with open(p, "rb") as f:
        return pickle.load(f), last


def find_resume_step(outdir: str) -> int:
    step_files = sorted(
        f for f in os.listdir(outdir)
        if f.startswith("step_") and (f.endswith(".pkl") or f.endswith(".pkl.xz") or f.endswith(".pkl.gz"))
    )
    if not step_files:
        return 0
    last = step_files[-1]
    num = (last.replace("step_", "")
               .replace(".pkl.xz", "")
               .replace(".pkl.gz", "")
               .replace(".pkl", ""))
    try:
        return int(num) + 1
    except Exception:
        return 0





# ------------------------------ Generator prep ------------------------------

# ------------------------------ Generator prep ------------------------------
def prepare_generators(ctx):
    """
    Resolve (Gq, Gp) in canonical shape (3, K, K), float32.

    Priority:
     
      1) SO(3) specs:    spec_q / spec_p (+ optional mix_generators_q / mix_generators_p)

    Side effect: writes K_q, K_p into ctx.config (runtime-scoped).
    """

    spec_q = cfg_get(ctx, "spec_q", None)
    spec_p = cfg_get(ctx, "spec_p", None)
        
    if (spec_q is None) or (spec_p is None):
        raise ValueError(
            "prepare_generators: provide either "
            "generators_q/generators_p, or so3_spec_q/so3_spec_p, "
            "or spec_q/spec_p in ctx/config."
        )
    mix_q = bool(cfg_get(ctx, "mix_generators_q", False))
    mix_p = bool(cfg_get(ctx, "mix_generators_p", False))
    
    Gq = make_reducible_generators(spec_q, mix=mix_q).astype(np.float32, copy=False)
    Gp = make_reducible_generators(spec_p, mix=mix_p).astype(np.float32, copy=False)
   
    # ---- record K into ctx.config (runtime-scoped) ----
    Kq, Kp = int(Gq.shape[1]), int(Gp.shape[1])
    rcfg = dict(getattr(ctx, "config", {}) or {})
    rcfg["K_q"] = Kq
    rcfg["K_p"] = Kp
    ctx.config = rcfg

    return Gq, Gp



# -------------------------- Init / resume helpers ---------------------------

def initialize_or_resume(outdir: str, resume: bool, runtime_ctx, clear_agent_logs: bool = True):
    """
    Initialize a fresh run or resume from checkpoints.
    Returns: (agents, step_start)
    """
        
    if resume:
        agents, _ = load_checkpoint(outdir)
        step_start = find_resume_step(outdir)
        return agents, int(step_start)

    # ---------- fresh init ----------
    if clear_agent_logs and os.path.isdir(outdir):
        # optional: wipe agent logs or temp dirs specific to a fresh start
        # (keep if you had this policy before; otherwise remove)
        pass

    # Generators must be available; prefer those already persisted on ctx
    G_q = cfg_get(runtime_ctx, "generators_q", None)
    G_p = cfg_get(runtime_ctx, "generators_p", None)
    if (G_q is None) or (G_p is None):
        # compute from ctx-config and persist
        G_q, G_p = prepare_generators(runtime_ctx)
        rcfg = dict(getattr(runtime_ctx, "config", {}) or {})
        rcfg["generators_q"] = G_q
        rcfg["generators_p"] = G_p
        runtime_ctx.config = rcfg

    agents = initialize_agents(
        seed=cfg_get(runtime_ctx, "agent_seed", 0),
        domain_size=cfg_get(runtime_ctx, "domain_size", (config.L, config.L)),
        N=cfg_get(runtime_ctx, "N", config.N),
        lie_algebra_dim=cfg_get(runtime_ctx, "lie_algebra_dim", 3),
        fixed_location=cfg_get(runtime_ctx, "fixed_location", True),
        
        generators_q=G_q,
        generators_p=G_p,
    )

    step_start = 0
    return agents, step_start


def save_step(agents, outdir, step, *, save_every=1, compress=True):
    import os, pickle
    os.makedirs(outdir, exist_ok=True)
    if step is not None and (step % int(save_every)) != 0:
        return

    # prune big transient state before serializing
    try:
        _pre_checkpoint_cleanup(agents)
    except Exception:
        pass

    base = os.path.join(outdir, f"step_{(step if step is not None else 0):04d}.pkl")

    if compress:
        # Try LZMA first (lower preset for smaller working set), then fall back to gzip.
        try:
            import lzma
            with lzma.open(base + ".xz", "wb", preset=2) as f:  # preset=2 keeps memory modest
                pickle.dump(agents, f, protocol=pickle.HIGHEST_PROTOCOL)
            return
        except MemoryError:
            # Fall back to gzip (much smaller memory overhead) and still continue the run.
            import gzip
            with gzip.open(base + ".gz", "wb", compresslevel=1) as f:
                pickle.dump(agents, f, protocol=pickle.HIGHEST_PROTOCOL)
            return

    # Uncompressed as last resort
    with open(base, "wb") as f:
        pickle.dump(agents, f, protocol=pickle.HIGHEST_PROTOCOL)


  

def _write_metric_artifacts(outdir: str, metric_log: list[dict]):
    if not metric_log: return
    out = pathlib.Path(outdir)
    out.mkdir(parents=True, exist_ok=True)
    # pickle (legacy) + jsonl (human/tooling-friendly)
    with open(out / "metric_log.pkl", "wb") as f:
        pickle.dump(metric_log, f, protocol=pickle.HIGHEST_PROTOCOL)
    with open(out / "metrics.jsonl", "w", encoding="utf-8") as f:
        for rec in metric_log:
            f.write(json.dumps(rec, ensure_ascii=False) + "\n")

def wrap_epilogue(runtime_ctx, agents, outdir, parent_metrics, metric_log):
    # flush metrics & a lightweight “run.json” context stub
    try:
        _write_metric_artifacts(outdir, metric_log or [])
        with open(os.path.join(outdir, "run.json"), "w", encoding="utf-8") as f:
            json.dump({
                "steps": int(getattr(getattr(runtime_ctx, "config", {}), "steps", len(metric_log)) 
                             if hasattr(runtime_ctx, "config") else len(metric_log)),
                "global_step": int(getattr(runtime_ctx, "global_step", -1)),
            }, f)
    except Exception as e:
        print(f"[WRAP] failed to write artifacts: {e}")
