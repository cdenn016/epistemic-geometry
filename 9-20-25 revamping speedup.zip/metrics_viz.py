# -*- coding: utf-8 -*-
"""
Created on Thu Sep 11 10:54:04 2025

@author: chris and christine
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Tuple, Optional, Any
import time
import csv
from utils import _aid
import numpy as np
import matplotlib.pyplot as plt
import numbers as _numbers
# =============================================================
# MetricsViz: one-stop logging + plotting for SO(3) Suite
# =============================================================
# Goals
#  - Single API to record GLOBAL and PER-AGENT metrics every step
#  - Lightweight CSV/JSONL logs for analysis
#  - Quick timeseries plots (energies, norms, drift)
#  - Snapshot heatmaps & step GIFs using robust percentile scaling
#  - Representation-aware annotations (reads casimir_total from meta)
#
# Notes
#  - No seaborn; pure matplotlib, as requested.
#  - Animations saved as GIFs (user preference) not MP4s.
#  - Designed to be imported by your run loop; no tight coupling.
# =============================================================


# ------------------------------
# Config
# ------------------------------
@dataclass
class VizConfig:
    outdir: Path
    run_name: str = "run"

    # Logging cadence
    save_every_steps: int = 100000           # write CSV/JSONL every N steps
    plot_every_steps: int = 1           # render timeseries every N steps
    snapshot_every_steps: int = 100       # save per-agent field PNGs every N steps
    

    # Visualization settings
    dpi: int = 100
    cmap: str = "viridis"
    robust_low: float = 1.0              # robust percentile lower bound
    robust_high: float = 99.0            # robust percentile upper bound

    # Downsample for large fields when snapshotting
    max_side: int = 256                  # downsample larger H/W to this

    # File names
    global_csv: str = "global_metrics.csv"
    agent_csv: str = "agent_metrics.csv"
    global_jsonl: str = "global_metrics.jsonl"
    agent_jsonl: str = "agent_metrics.jsonl"

    # Toggles
    enable_jsonl: bool     = False
    enable_csv: bool       = False
    enable_plots: bool     = True
    enable_snapshots: bool = True
    


# ------------------------------
# Utility helpers
# ------------------------------




def _load_jsonl(path: Path) -> list[dict]:
    if not path.exists():
        return []
    rows = []
    with path.open("r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                rows.append(json.loads(line))
            except Exception:
                # skip malformed lines
                pass
    return rows


def _is_num(x) -> bool:
    if isinstance(x, (bool, np.bool_)):
        return False
    return isinstance(x, _numbers.Number) or (isinstance(x, np.generic) and np.issubdtype(type(x), np.number))

def _to_num(x):
    try:
        if _is_num(x):
            return float(x)
        # try string→float
        return float(x)
    except Exception:
        return np.nan



def _ensure_dir(p: Path):
    p.mkdir(parents=True, exist_ok=True)


def _ts() -> str:
    return time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())


def _robust_min_max(x: np.ndarray, low=1.0, high=99.0) -> Tuple[float, float]:
    lo = float(np.nanpercentile(x, low))
    hi = float(np.nanpercentile(x, high))
    if not np.isfinite(lo):
        lo = float(np.nanmin(x))
    if not np.isfinite(hi):
        hi = float(np.nanmax(x))
    if hi <= lo:
        hi = lo + 1e-6
    return lo, hi


def _downsample(img: np.ndarray, max_side: int) -> np.ndarray:
    H, W = img.shape[:2]
    s = max(H, W)
    if s <= max_side:
        return img
    scale = max_side / s
    newH = max(1, int(round(H * scale)))
    newW = max(1, int(round(W * scale)))
    # simple area-ish resize via slicing; keep dependencies light
    # For better quality, users can swap to skimage.transform.resize.
    y_idx = (np.linspace(0, H - 1, newH)).astype(int)
    x_idx = (np.linspace(0, W - 1, newW)).astype(int)
    return img[np.ix_(y_idx, x_idx)]


def _save_csv_row(csv_path: Path, header: List[str], row: List[Any]):
    exists = csv_path.exists()
    with csv_path.open("a", newline="") as f:
        writer = csv.writer(f)
        if not exists:
            writer.writerow(header)
        writer.writerow(row)


def _append_jsonl(path: Path, obj: Dict[str, Any]):
    with path.open("a", encoding="utf-8") as f:
        f.write(json.dumps(obj) + "\n")


def _safe_fig(figsize=(8,4), dpi=120):
    fig = plt.figure(figsize=figsize, dpi=dpi)
    ax = fig.add_subplot(111)
    return fig, ax


def _safe_savefig(fig: plt.Figure, path: Path, *, run_id: int | None = None, attempts: int = 2):
    fig.tight_layout()
    try:
        fig.savefig(path)
    except PermissionError:
        # Windows often locks the file if it's open in an image viewer.
        # Fall back to a per-run unique filename to avoid overwriting a locked file.
        stem, suf = path.stem, path.suffix
        alt = path.with_name(f"{stem}_r{run_id or 0}{suf}")
        try:
            fig.savefig(alt)
        except PermissionError:
            # last-ditch: add a numeric suffix
            alt2 = path.with_name(f"{stem}_r{run_id or 0}_alt{suf}")
            fig.savefig(alt2)
    finally:
        plt.close(fig)


# --- tiny local helpers for A/curvature/covariant derivatives ---
def _fwd_dx(X):  # periodic forward diff along x (cols)
    X = np.asarray(X, np.float32)
    return np.roll(X, -1, axis=1) - X

def _fwd_dy(X):  # periodic forward diff along y (rows)
    X = np.asarray(X, np.float32)
    return np.roll(X, -1, axis=0) - X

def _cross(a, b):
    a = np.asarray(a, np.float32); b = np.asarray(b, np.float32)
    return np.stack([
        a[...,1]*b[...,2] - a[...,2]*b[...,1],
        a[...,2]*b[...,0] - a[...,0]*b[...,2],
        a[...,0]*b[...,1] - a[...,1]*b[...,0]
    ], axis=-1)



def _curvature_from_A(A):
    # Non-Abelian curvature: F = ∂x Ay − ∂y Ax + Ax × Ay
    Ax, Ay = A[..., 0, :], A[..., 1, :]
    Fx = _fwd_dx(Ay)
    Fy = _fwd_dy(Ax)
    F  = Fx - Fy + _cross(Ax, Ay)
    F2 = np.sum(F * F, axis=-1)
    return F, 0.5 * F2

def _covariant_phi_terms(phi, A):
    # Dφ = (∂x φ − Ax×φ, ∂y φ − Ay×φ) → per-pixel norms and energy
    Ax, Ay = A[..., 0, :], A[..., 1, :]
    Dx = _fwd_dx(phi) - _cross(Ax, phi)
    Dy = _fwd_dy(phi) - _cross(Ay, phi)
    Dx2 = np.sum(Dx * Dx, axis=-1)
    Dy2 = np.sum(Dy * Dy, axis=-1)
    return np.sqrt(Dx2), np.sqrt(Dy2), 0.5 * (Dx2 + Dy2)



# ------------------------------
# Main class
# ------------------------------
class MetricsViz:
    """
    Central logger/plotter. Create once per run, call from your step loop.

    API summary:
      mv = MetricsViz(VizConfig(Path(outdir), run_name="trial1"))
      mv.start_run(meta={"casimir_total": 2.0})
      for step in range(steps):
          mv.log_global(step, {...})
          for aid in agents:
              mv.log_agent(step, aid, {...})
          mv.maybe_flush(step)
          mv.maybe_plot(step)
          mv.maybe_snapshot(step, ctx, agents)
          mv.maybe_gif(step)
      mv.end_run()
    """

    def __init__(self, cfg: VizConfig):
        self.cfg = cfg
        self.root = Path(cfg.outdir)
        _ensure_dir(self.root)
        self.dir_run = self.root / cfg.run_name
        _ensure_dir(self.dir_run)
        # --- in MetricsViz.__init__ ---
        self.dir_plots = self.dir_run / "plots"
        self.dir_snapshots = self.dir_run / "snapshots"
        
        _ensure_dir(self.dir_plots)
        _ensure_dir(self.dir_snapshots)
        
        # In-memory timeseries (small; mirrors CSV/JSONL)
        self.global_rows: List[Dict[str, Any]] = []
        self.agent_rows: List[Dict[str, Any]] = []

        # Headers will be discovered from first row
        self._global_header: Optional[List[str]] = None
        self._agent_header: Optional[List[str]] = None

       
        # Meta
        self.meta: Dict[str, Any] = {}
        self.run_started = False
        
        self.run_id: int | None = None
        self._counter_path = self.dir_run / "run_counter.txt"

            # metrics_viz.py (add to MetricsViz.__init__)
        self._global_history = []   # rows from prior runs
        self._agent_history  = []
        self._plot_cache = self.dir_run / "plot_cache.jsonl"  # lightweight rows for plotting only

    # --------------------------
    # Lifecycle
    # --------------------------
# replace start_run()
    def start_run(self, meta: Optional[Dict[str, Any]] = None):
        _ensure_dir(self.dir_run); _ensure_dir(self.dir_plots); _ensure_dir(self.dir_snapshots)
        # allocate run_id etc... (keep your existing code)
    
        # Load prior rows exactly once (enables multi-run overlays)
        self._global_history = []
        self._agent_history  = []
        try:
            # prefer JSONL if enabled & exists
            gjson = self.dir_run / getattr(self.cfg, "global_jsonl", "global.jsonl")
            ajson = self.dir_run / getattr(self.cfg, "agent_jsonl",  "agents.jsonl")
            used_any = False
            if gjson.exists() and ajson.exists():
                self._global_history = _load_jsonl(gjson) or []
                self._agent_history  = _load_jsonl(ajson) or []
                used_any = True
            # fallback to plot cache
            if not used_any and self._plot_cache.exists():
                self._global_history = []
                self._agent_history  = []
                for row in _load_jsonl(self._plot_cache) or []:
                    if row.get("__kind__") == "global":
                        self._global_history.append({k:v for k,v in row.items() if k!="__kind__"})
                    elif row.get("__kind__") == "agent":
                        self._agent_history.append({k:v for k,v in row.items() if k!="__kind__"})
        except Exception:
            # ignore; we’ll just plot current run
            self._global_history, self._agent_history = [], []
    
        # fresh buffers for the new run
        self.global_rows = []
        self.agent_rows  = []



    
    # --------------------------
    # Logging
    # --------------------------
    def log_global(self, step: int, metrics: Dict[str, Any]):
        """Add a single global metrics row (merged with step & timestamp)."""
        row = {"step": int(step), "ts": _ts(), "run_id": self.run_id}
        row.update(metrics)
        self.global_rows.append(row)
        # Persist JSONL immediately for crash safety
        if self.cfg.enable_jsonl:
            _append_jsonl(self.dir_run / self.cfg.global_jsonl, row)
        # Remember header ordering
        if self._global_header is None:
            self._global_header = list(row.keys())

    def log_agent(self, step: int, agent_id: int | str, metrics: Dict[str, Any]):
        """Add a per-agent metrics row."""
        row = {"step": int(step), "agent": agent_id, "ts": _ts(), "run_id": self.run_id}
        row.update(metrics)
        self.agent_rows.append(row)
        if self.cfg.enable_jsonl:
            _append_jsonl(self.dir_run / self.cfg.agent_jsonl, row)
        if self._agent_header is None:
            self._agent_header = list(row.keys())

    # --------------------------
    # Periodic persistence & plots
    # --------------------------
    def maybe_flush(self, step: int):
        if (step % self.cfg.save_every_steps) != 0:
            return
        if self.cfg.enable_csv:
            if self.global_rows:
                self._flush_csv(self.dir_run / self.cfg.global_csv, self.global_rows, self._global_header)
            if self.agent_rows:
                self._flush_csv(self.dir_run / self.cfg.agent_csv, self.agent_rows, self._agent_header)

    def _flush_csv(self, path: Path, rows: List[Dict[str, Any]], header: Optional[List[str]]):
        if not rows:
            return
        if header is None:
            header = list(rows[0].keys())
        for r in rows:
            _save_csv_row(path, header, [r.get(h, "") for h in header])
        rows.clear()

    def maybe_plot(self, step: int):
        if not self.cfg.enable_plots or (step % self.cfg.plot_every_steps) != 0:
            return
        # Timeseries plots for a few core metrics
        self._plot_global_timeseries()
        self._plot_agent_timeseries()

    # replace _plot_global_timeseries() entirely
    def _plot_global_timeseries(self):
        rows = (self._global_history or []) + (self.global_rows or [])
        if not rows:
            return
    
        # use current run_id (or 1) as default for legacy rows with no run_id
        default_rid = int(self.run_id or 1)
    
        # group rows by normalized run_id
        groups = {}
        for r in rows:
            rid = _safe_run_id(r.get("run_id"), default=default_rid)
            groups.setdefault(rid, []).append(r)
    
        run_ids = sorted(groups.keys())
    
        # candidate fields
        preferred = ["E_total", "mean_total", "Action_total",
                     "VFE_acc", "A_curv", "A_cov"]  # keep the real ones you want
        all_keys = set().union(*[r.keys() for r in rows])
    
        # REMOVE these duplicates explicitly
        skip_fields = {"Geom_total", "global_ModelPrior_raw", "global_VFE_acc_raw", "_raw"}
    
        # numeric-only, preserving preferred order first
        fields = [k for k in preferred if k in all_keys] + [
            k for k in sorted(all_keys)
            if k not in preferred
            and k not in ("step", "ts", "run_id")
            and k not in skip_fields
            and any(_is_num(rr.get(k)) for rr in rows)
        ]
    
        # FILTER: remove constant/disabled/unwanted
        fields = [f for f in fields if not _should_skip_field_global(f, rows, self.meta)]
        if not fields:
            return
    
        for field in fields:
            fig, ax = _safe_fig(figsize=(8,3), dpi=self.cfg.dpi)
            plotted_any = False
            for rid in run_ids:
                rs = sorted(groups[rid], key=lambda r: _to_num(r.get("step")))
                steps = np.array([_to_num(r.get("step")) for r in rs], dtype=float)
                vals  = np.array([_to_num(r.get(field))   for r in rs], dtype=float)
    
                # break on step reset to avoid diagonal artifacts across runs
                breaks = np.where(np.diff(steps) < 0)[0] + 1
                segs = np.split(np.arange(len(steps)), breaks)
                for idx in segs:
                    s = steps[idx]; y = vals[idx]
                    m = np.isfinite(s) & np.isfinite(y)
                    if np.any(m):
                        ax.plot(s[m], y[m], label=f"run {rid}")
                        plotted_any = True
    
            if not plotted_any:
                plt.close(fig); continue
            ax.set_xlabel("step"); ax.set_ylabel(field); ax.set_title(field)
            ax.legend(loc="best", fontsize=8, ncols=min(len(run_ids), 3))
            _safe_savefig(fig, self.dir_plots / f"global_{field}.png")
           
    def _snapshot_agent_fields(self, step, agent, runtime_ctx, skip_fields=frozenset()):
        """Back-compat shim: defer to _snapshot_agent and ignore skip_fields."""
        dstep = self.dir_snapshots / f"step_{step:04d}"
        dstep.mkdir(parents=True, exist_ok=True)
        if agent is not None:
            self._snapshot_agent(step, dstep, agent, runtime_ctx)

    # replace _plot_agent_timeseries() entirely
    def _plot_agent_timeseries(self):
        rows = (self._agent_history or []) + (self.agent_rows or [])
        if not rows:
            return
    
        default_rid = int(self.run_id or 1)
    
        # assign run_id for legacy rows, then group
        for r in rows:
            if "run_id" not in r or r["run_id"] is None:
                r["run_id"] = default_rid
    
        from collections import defaultdict
        by_ra = defaultdict(list)
        for r in rows:
            rid = _safe_run_id(r.get("run_id"), default=default_rid)
            aid = r.get("agent")
            if aid is None:
                continue
            by_ra[(rid, aid)].append(r)
    
        run_ids = sorted({rid for (rid, _aid) in by_ra.keys()})
    
        # union fields (numeric), with mild preferences
        all_keys = set().union(*[r.keys() for r in rows])
        preferred = ["E_self","mask_sum","phi_norm_mean","phi_model_norm_mean"]
        fields = [k for k in preferred if k in all_keys] + [
            k for k in sorted(all_keys)
            if k not in ("step","agent","ts","run_id") and any(_is_num(rr.get(k)) for rr in rows)
        ]
    
        # FILTER: constant across all (agent,run)
        def _const_across_agents(field: str) -> bool:
            vals = np.array([_to_num(r.get(field)) for r in rows], dtype=float)
            return _is_effectively_constant(vals)
    
        fields = [f for f in fields if not _const_across_agents(f)]
        if not fields:
            return
    
        from collections import defaultdict
        by_ra = defaultdict(list)
        for r in rows:
            aid = r.get("agent")
            rid = r.get("run_id", 1)
            if aid is None:
                continue
            by_ra[(rid, aid)].append(r)
    
        for field in fields:
            fig, ax = _safe_fig(figsize=(8,3), dpi=self.cfg.dpi)
            plotted_any = False
            for (rid, aid), lst in by_ra.items():
                lst = sorted(lst, key=lambda r: _to_num(r.get("step")))
                s = np.array([_to_num(r.get("step")) for r in lst], dtype=float)
                y = np.array([_to_num(r.get(field)) for r in lst], dtype=float)
                breaks = np.where(np.diff(s) < 0)[0] + 1
                segs = np.split(np.arange(len(s)), breaks)
                for idx in segs:
                    ss = s[idx]; yy = y[idx]
                    m = np.isfinite(ss) & np.isfinite(yy)
                    if np.any(m):
                        ax.plot(ss[m], yy[m], label=f"{aid}@r{rid}")
                        plotted_any = True
            if not plotted_any:
                plt.close(fig); continue
            ax.set_xlabel("step"); ax.set_ylabel(field); ax.set_title(field)
            ax.legend(loc="best", fontsize=7, ncols=min(len(run_ids), 4))
            _safe_savefig(fig, self.dir_plots / f"agent_{field}.png")
            
    def maybe_snapshot(self, step, runtime_ctx, agents):
        """Save per-step snapshots. Render global A once; then per-agent fields."""
        # honor cadence
        try:
            every = int(getattr(self.cfg, "snapshot_every_steps", 100))
        except Exception:
            every = 50
        if every <= 0 or (step % every) != 0:
            return
    
        # step dir
        dstep = self.dir_snapshots / f"step_{step:04d}"
        dstep.mkdir(parents=True, exist_ok=True)
    
        # --- (1) Global A once ---
        try:
            self._snapshot_global_A_once(step, dstep, runtime_ctx)
        except Exception as e:
            print(f"[SNAPSHOT] global A failed: {e}")
    
        # --- (2) Per-agent (no A here) ---
        for a in (agents or []):
            if a is None:
                continue
            try:
                self._snapshot_agent(step, dstep, a, runtime_ctx)
            except Exception as e:
                # keep run alive; log minimal context
                try:
                    aid = _aid(a)
                except Exception:
                    aid = None
                print(f"[SNAPSHOT] agent {aid} failed: {e}")
    
    def _snapshot_global_A_once(self, step: int, dstep: Path, ctx: any):
        """
        Render ONE image set for the global connection A at this step.
        No-ops if already snapped this step or A is missing.
        """
        try:
            if not hasattr(ctx, "fields") or ctx.fields is None:
                return
            # guard: once per step
            if ctx.fields.get("_A_snap_step") == step:
                return
    
            A = _get_A_from_ctx_fields_for_snapshot(ctx)
            if A is None:
                return  # nothing to draw yet on step 0, etc.
    
            Ax, Ay = A[..., 0, :], A[..., 1, :]
            self._save_heatmap(_field_norm(Ax), dstep / f"A_x_norm_step_{step:04d}.png")
            self._save_heatmap(_field_norm(Ay), dstep / f"A_y_norm_step_{step:04d}.png")
    
            # Curvature panels (fast; skip if you prefer)
            try:
                F, E_F = _curvature_from_A(A)
                self._save_heatmap(np.linalg.norm(F, axis=-1), dstep / f"Curv_A_norm_step_{step:04d}.png")
                self._save_heatmap(E_F,                      dstep / f"Curv_A_energy_step_{step:04d}.png")
            except Exception:
                pass
    
            ctx.fields["_A_snap_step"] = step
        except Exception:
            pass

    def _snapshot_agent(self, step: int, dstep: Path, a: any, ctx: any):
        # Robust: never throw—snapshots must not crash the run.
        try:
            aid = _aid(a)
        except Exception:
            aid = "?"
    
        def _maybe(name: str, getter, *, is_cov: bool = False):
            try:
                arr = getter()
                if arr is None:
                    return
                if is_cov:
                    # FAST: batched slogdet instead of Python loop
                    arr = np.asarray(arr, np.float32)  # (H,W,K,K)
                    H, W, K = arr.shape[0], arr.shape[1], arr.shape[-1]
                    M = arr.reshape(H * W, K, K)
                    sign, logabsdet = np.linalg.slogdet(M)
                    logabsdet = np.where(sign > 0, logabsdet.astype(np.float32), np.nan)
                    img = logabsdet.reshape(H, W)
                else:
                    img = np.asarray(arr, np.float32)
                if np.any(np.isfinite(img)):
                    self._save_heatmap(img, dstep / f"Agent {aid}_{name}.png")
            except Exception:
                pass
    
        # per-agent fields only (no A)
        _maybe("phi_norm",        lambda: _field_norm(getattr(a, "phi", None)))
        _maybe("phi_model_norm",  lambda: _field_norm(getattr(a, "phi_model", None)))
        _maybe("mu_q_norm",       lambda: _field_norm(getattr(a, "mu_q_field", None)))
        _maybe("mu_p_norm",       lambda: _field_norm(getattr(a, "mu_p_field", None)))
        _maybe("sigma_q_logdet",  lambda: np.asarray(getattr(a, "sigma_q_field", None)), is_cov=True)
        _maybe("sigma_p_logdet",  lambda: np.asarray(getattr(a, "sigma_p_field", None)), is_cov=True)
    
    def _save_heatmap(self, img: np.ndarray, path: Path):
        img = np.asarray(img)
        if img.ndim == 3 and img.shape[-1] in (3, 4):
            # RGB or RGBA image—save directly
            plt.imsave(path, _downsample(img, self.cfg.max_side))
            return
        if img.ndim > 2:
            # reduce via norm across channels
            img = np.linalg.norm(img, axis=-1)
        img = np.nan_to_num(img, nan=0.0, posinf=0.0, neginf=0.0)
        img = _downsample(img, self.cfg.max_side)
        lo, hi = _robust_min_max(img, self.cfg.robust_low, self.cfg.robust_high)
        fig, ax = _safe_fig(figsize=(4, 4), dpi=self.cfg.dpi)
        im = ax.imshow(img, cmap=self.cfg.cmap, vmin=lo, vmax=hi, origin="lower")
        ax.set_xticks([]); ax.set_yticks([])
        fig.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
        _safe_savefig(fig, path)

    def end_run(self):
        # write/update compact plot cache with history + this run
        try:
            all_rows = []
            for r in (self._global_history or []):
                rr = dict(r); rr["__kind__"] = "global"; all_rows.append(rr)
            for r in (self._agent_history or []):
                rr = dict(r); rr["__kind__"] = "agent";  all_rows.append(rr)
            for r in (self.global_rows or []):
                rr = dict(r); rr["__kind__"] = "global"; all_rows.append(rr)
            for r in (self.agent_rows or []):
                rr = dict(r); rr["__kind__"] = "agent";  all_rows.append(rr)
            # rewrite plot_cache.jsonl once (small, append-only lines)
            if all_rows:
                self._plot_cache.unlink(missing_ok=True)
                for rr in all_rows:
                    _append_jsonl(self._plot_cache, rr)
        except Exception:
            pass
        # (optional) any other teardown you already have



# ------------------------------
# small utility used by _snapshot_global_A_once
# ------------------------------
def _get_A_from_ctx_fields_for_snapshot(ctx_obj):
    try:
        A = getattr(ctx_obj, "fields", {}).get("A", None)
        if A is None:
            return None
        A = np.asarray(A, np.float32)
        if A.ndim == 4 and A.shape[-2:] == (2, 3):
            return A
        if A.ndim == 3 and A.shape[-1] == 3:
            H, W = A.shape[:2]
            A_up = np.zeros((H, W, 2, 3), dtype=np.float32)
            A_up[..., 0, :] = A
            return A_up
        return None
    except Exception:
        return None
#----------------------
# Convenience feature extractors
# ------------------------------

def _field_norm(field: Optional[np.ndarray]) -> Optional[np.ndarray]:
    if field is None:
        return None
    arr = np.asarray(field)
    if arr.ndim >= 3:
        return np.linalg.norm(arr, axis=-1)
    elif arr.ndim == 2:
        return np.abs(arr)
    else:
        return None

# --- plotting filters (constants / skips) ---
def _is_effectively_constant(vals: np.ndarray, rtol=1e-6, atol=1e-12) -> bool:
    """True if all finite vals are (almost) the same (incl. all-zero)."""
    if vals.size == 0:
        return True
    vals = vals[np.isfinite(vals)]
    if vals.size <= 1:
        return True
    return np.allclose(vals, vals[0], rtol=rtol, atol=atol)

def _safe_run_id(v, default: int) -> int:
    """Coerce any run_id-ish value to an int; fall back to default when missing/None/blank."""
    try:
        if v is None:
            return default
        if isinstance(v, str):
            v = v.strip()
            if v == "":
                return default
        return int(float(v))
    except Exception:
        return default



def _should_skip_field_global(field: str, rows: list[dict], meta: dict) -> bool:
    """Heuristics to skip boring or disabled series."""
    # 1) obvious boilerplate keys
    if field in {"num_agents", "Kq", "Kp"}:
        return True

    # 2) meta-driven weights (optional)
    #    If you pass mv.start_run(meta={"weights": {"feedback": 0.0, ...}}),
    #    we skip fields mapped to zero-weighted terms.
    weights = (meta or {}).get("weights", {}) or {}
    zero_terms = {k for k,v in weights.items() if isinstance(v, (int,float,np.floating)) and abs(v) < 1e-12}
    # common mapping from term name -> metric keys
    term_to_fields = {
        "self":     {"self_sum", "E_self", "self"},
        "feedback": {"feedback_sum", "E_feedback", "feedback"},
        "align_q":  {"align_q_sum", "E_align_q", "align_q"},
        "align_p":  {"align_p_sum", "E_align_p", "align_p"},
        "mass_q":   {"mass_q_sum", "mass_q"},
        "mass_p":   {"mass_p_sum", "mass_p"},
        "curv_q":   {"curv_q_sum", "curv_q"},
        "curv_p":   {"curv_p_sum", "curv_p"},
        "A_curv":   {"A_curv"},
        "A_cov":    {"A_cov"},
        "VFE":      {"VFE_acc", "VFE"},
        "ModelPrior": {"ModelPrior"},
    }
    for term in zero_terms:
        if field in term_to_fields.get(term, set()):
            return True

    # 3) meta-driven explicit lists (optional)
    only = set((meta or {}).get("plot_only_fields", []) or [])
    if only and field not in only:
        return True
    skip = set((meta or {}).get("plot_skip_fields", []) or [])
    if field in skip:
        return True

    # 4) constant detection across all rows
    vals = np.array([_to_num(r.get(field)) for r in rows], dtype=float)
    return _is_effectively_constant(vals)

