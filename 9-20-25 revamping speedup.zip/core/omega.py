# -*- coding: utf-8 -*-
"""
omega.py — Lie-group exponentials, transports, BCH helpers, and curvature ops.
CacheHub-ready: uses ctx.cache namespaces 'exp' and 'omega' when provided.

Author: c&c
"""
from __future__ import annotations
from typing import Optional
import numpy as np
import math
from joblib import Parallel, delayed, parallel_backend
from utils import _aid




# -----------------------------------------------------------------------------
# Principal-ball retraction (axis–angle)
# -----------------------------------------------------------------------------



def retract_phi_principal(
    phi,
    *,
    margin: Optional[float] = 1e-6,
    use_float64: bool = False,
):
    """
    Project axis–angle φ onto the SO(3) principal ball (‖φ‖ ≤ π − margin),
    with stable handling of small norms and 2π wrap/reflection.

    Key differences from the old version:
      - No explicit 1/t path with zeros → no small-angle collapse to 0.
      - Scale original vector directly by a safe factor (target_norm / max(t, eps)).
      - Axis flip applied only when t mod 2π exceeds π (the “reflection” branch).
    """
 
    
    

    dtype = np.float64 if use_float64 else np.float32
    
    v = np.asarray(phi, dtype=dtype)
    if v.shape == () or v.shape[-1] != 3:
        return v.astype(np.float32, copy=False)

    if not np.all(np.isfinite(v)):
        raise FloatingPointError("retract_phi_principal: nonfinite input detected.")

    pi = math.pi
    two_pi = 2.0 * pi
    eps = np.finfo(dtype).eps

    # norms and 2π wrapping
    t = np.linalg.norm(v, axis=-1, keepdims=True)        # (...,1)
    t_scalar = t[..., 0]                                  # (...,)
    t_mod = np.remainder(t_scalar, two_pi)                # [0, 2π)
    over = (t_mod > pi)                                   # reflect region

    # reflected target magnitude in [0, π]
    t_ref = np.where(over, (two_pi - t_mod), t_mod)       # (...,)
    # clamp to principal ball
    t_target = np.minimum(t_ref, (pi - margin))           # (...,)

    # stable scale factor: target / max(current, eps)
    denom = np.maximum(t_scalar, eps)                     # (...,)
    scale = (t_target / denom)[..., None]                 # (...,1)

    # scale the original vector; flip axis if in the reflected branch
    out = v * scale                                       # (...,3)
    out = np.where(over[..., None], -out, out)

    out = out.astype(np.float32, copy=False)


    return out




# =============================================================================
#                          Exponentials / Transports
# =============================================================================



def exp_lie_algebra_irrep(
    v_batch: np.ndarray,
    generators: np.ndarray,
    *,
    threshold: float = 1e-3,
    max_norm: Optional[float] = None,
    parallelize_expm: bool = False,
    n_jobs: int = -1,
    reproject_ortho: bool = False,          # NEW: optional SVD projection to nearest orthogonal (costly)
    use_float64: bool = True,               # NEW: do math in float64, return float32
    **_legacy,                              
) -> np.ndarray:
    """
    Compute exp(Σ v^a G_a) in an arbitrary K×K irrep for a batch of v.

    v_batch:    (..., 3) axis–angle coefficients in the chosen basis
    generators: (3, K, K) irrep generators (typically skew for SO(3))
    Returns:    (..., K, K) float32

    Notes:
      - 'threshold' controls small-angle Taylor cutoff.
      - 'max_norm' clips ||v|| radially for stability.
      - No in-kernel masking;
    """
    # --- shape & dtype checks
    v = np.asarray(v_batch, dtype=(np.float64 if use_float64 else np.float32))
    G = np.asarray(generators, dtype=v.dtype)

    if v.ndim == 0 or v.shape[-1] != 3:
        raise ValueError(f"exp_lie_algebra_irrep: expected (...,3) v_batch, got {v.shape}")
    if G.ndim != 3 or G.shape[0] != 3 or G.shape[-1] != G.shape[-2]:
        raise ValueError(f"exp_lie_algebra_irrep: generators must be (3,K,K), got {G.shape}")

    
    if not (np.all(np.isfinite(v)) and np.all(np.isfinite(G))):
        raise FloatingPointError("exp_lie_algebra_irrep: nonfinite v/generators.")

    batch_shape = v.shape[:-1]
    d = 3
    K = int(G.shape[-1])

    # Optional global norm clip (safe at 0)
    if max_norm is not None:
        vv = v.reshape(-1, d)
        n = np.linalg.norm(vv, axis=1)
        scale = np.minimum(1.0, float(max_norm) / np.maximum(n, 1e-16)).astype(v.dtype)
        v = (vv * scale[:, None]).reshape(batch_shape + (d,))

    # Algebra element: Xi = v·G, then enforce skew numerically
    Xi = np.einsum("...a,aij->...ij", v, G, optimize=True)          # (...,K,K)
    X = 0.5 * (Xi - np.swapaxes(Xi, -1, -2))                        # (...,K,K)

    # Flatten for batch processing
    flat = X.reshape(-1, K, K)
    out  = np.empty_like(flat)

    # Small-angle mask
    norms = np.linalg.norm(v.reshape(-1, d), axis=1)                # (N,)
    mask_small = norms < float(threshold)
    mask_big   = ~mask_small

    # Taylor (order 4) near identity
    if np.any(mask_small):
        Xs = flat[mask_small]
        I = np.eye(K, dtype=flat.dtype)[None, ...]
        X2 = Xs @ Xs
        X3 = X2 @ Xs
        X4 = X2 @ X2
        out[mask_small] = I + Xs + 0.5*X2 + (1.0/6.0)*X3 + (1.0/24.0)*X4

    # Exact expm elsewhere
    if np.any(mask_big):
        Xh = flat[mask_big]

        # Local expm with SciPy if available; minimal fallback otherwise
        def _expm(A):
            try:
                from scipy.linalg import expm as _scipy_expm   # prefer SciPy
                return _scipy_expm(A)
            except Exception:
                # Minimal Pade(13) + scaling & squaring (batched via loop)
                return _expm_pade13(A)

        if parallelize_expm and Xh.shape[0] >= 64:
            try:
               
                with parallel_backend("threading"):
                    res = Parallel(n_jobs=n_jobs, batch_size=8)(
                        delayed(_expm)(X_i) for X_i in Xh
                    )
            except Exception:
                res = [_expm(X_i) for X_i in Xh]
        else:
            res = [_expm(X_i) for X_i in Xh]
        out[mask_big] = np.stack(res, axis=0)

    # Optional SVD reprojection to nearest orthogonal (use for fundamental or if drift bothers you)
    if reproject_ortho:
        U, _, Vt = np.linalg.svd(out, full_matrices=False)
        out = U @ Vt

    # Final finite check — no in-kernel masking
    if not np.all(np.isfinite(out)):
        raise FloatingPointError("exp_lie_algebra_irrep: nonfinite exp result.")
   

    return out.reshape(batch_shape + (K, K)).astype(np.float32, copy=False)


# ------- Minimal fallback: Pade(13) + scaling & squaring for a single matrix -------
def _expm_pade13(A: np.ndarray) -> np.ndarray:
    """
    Minimal, dependency-free expm fallback for a single (K,K) matrix.
    Good enough for skew-symmetric inputs typically seen here.
    """
    # Scaling
    A = np.asarray(A, dtype=np.float64)
    n_squarings = max(0, int(np.ceil(max(0.0, np.log2(np.linalg.norm(A, ord=np.inf))) - 1)))
    As = A / (2 ** n_squarings)

    # Pade(13) coefficients
    b = [64764752532480000., 32382376266240000., 7771770303897600., 1187353796428800.,
         129060195264000., 10559470521600., 670442572800., 33522128640., 1323241920.,
         40840800., 960960., 16380., 182., 1.]

    I = np.eye(A.shape[0], dtype=As.dtype)
    A2 = As @ As
    A4 = A2 @ A2
    A6 = A2 @ A4

    U = As @ (A6@(b[13]*A6 + b[11]*A4 + b[9]*A2) + b[7]*A6 + b[5]*A4 + b[3]*A2 + b[1]*I)
    V =      (A6@(b[12]*A6 + b[10]*A4 + b[8]*A2) + b[6]*A6 + b[4]*A4 + b[2]*A2 + b[0]*I)

    # (V - U)^{-1} (V + U)
    X = np.linalg.solve(V - U, V + U)

    # Squaring
    for _ in range(n_squarings):
        X = X @ X
    return X




# =============================================================================
#                       Exact dexp derivatives for SO(3)
# =============================================================================


def d_exp_exact(
    phi_vec: np.ndarray,
    generators: np.ndarray,
    *,
    exp_phi_all: Optional[np.ndarray] = None,
    eps: float = 1e-12,
) -> list[np.ndarray]:
    """
    For Φ = Σ_a φ^a G_a (SO(3) left-trivialized), compute
      dE/dφ^a = E · Q_a,
    where Q_a = G_a - c1 ad_Φ(G_a) + c2 ad_Φ^2(G_a),
    c1 = (1 - cos θ)/θ^2, c2 = (θ - sin θ)/θ^3, θ = ||φ||.
    Returns a list [dE/dφ^0, dE/dφ^1, dE/dφ^2], each (...,K,K).
    """

    φ = np.asarray(phi_vec, dtype=np.float32)
    G = np.asarray(generators, dtype=np.float32)

    # Validate generators as (3,K,K)
    if not (G.ndim == 3 and G.shape[0] == 3 and G.shape[1] == G.shape[2]):
        raise ValueError(f"d_exp_exact: generators must be (3,K,K), got {G.shape}")
    K = int(G.shape[-1])

    *lead, d = φ.shape
    if d != 3:
        raise ValueError(f"d_exp_exact: expected d=3 (SO(3)), got d={d}")
    N = int(np.prod(lead)) if lead else 1

    # Flatten sites
    φN = φ.reshape(N, 3)                                  # (N,3)
    Φ  = np.einsum("na,aij->nij", φN, G, optimize=True)   # (N,K,K)

    # Coefficients c1, c2
    θ  = np.linalg.norm(φN, axis=1).astype(np.float32)    # (N,)
    c1 = np.empty_like(θ)
    c2 = np.empty_like(θ)
    
    small = θ < 1e-4
    
    if np.any(small):
        t  = θ[small]; t2 = t*t; t4 = t2*t2
        c1[small] = 0.5 - t2/24.0 + t4/720.0
        c2[small] = 1.0/6.0 - t2/120.0 + t4/5040.0
    
    big = ~small
    
    if np.any(big):
        tb = θ[big]
        tb2 = np.maximum(tb*tb, eps)
        tb3 = np.maximum(tb2*tb, eps)
        c1[big] = (1.0 - np.cos(tb)) / tb2
        c2[big] = (tb - np.sin(tb)) / tb3

    # E(φ)
    if exp_phi_all is None:
        E = exp_lie_algebra_irrep(φN, G)                  # (N,K,K)
    else:
        E = np.asarray(exp_phi_all, dtype=np.float32).reshape(N, K, K)

    # Commutators: ad_Φ(G_a) and its square
    ΦB = Φ[None, ...]            # (1,N,K,K)
    GA = G[:, None, :, :]        # (3,1,K,K)
    ad1 = (ΦB @ GA) - (GA @ ΦB)  # (3,N,K,K)
    ad2 = (ΦB @ ad1) - (ad1 @ ΦB)# (3,N,K,K)

    # Q_a and dE/dφ^a
    Q  = GA - c1[None, :, None, None]*ad1 + c2[None, :, None, None]*ad2  # (3,N,K,K)
    dE = np.einsum("nij,anjk->anik", E, Q, optimize=True)                # (3,N,K,K)

    dE = dE.reshape(3, *lead, K, K).astype(np.float32, copy=False)
    return [dE[a] for a in range(3)]



def inverse_fisher_metric_field(ctx, agent, generators, *, which="q", eps=1e-8, tol=None):
    """
    Per-pixel inverse Fisher metric for algebra coords (φ or φ̃).
    Computes F_ab = tr(Σ^{-1} G_a Σ^{-1} G_b), then returns (F + λ I)^{-1} per pixel,
    with λ chosen from absolute and relative floors, optional normalization and capping.
    Fail-fast on invalid inputs.
    """
    from runtime_context import cfg_get
    from core.transport_cache import Fisher_blocks
    
   
    # --- inputs / shapes ----------------------------------------------------
    tau = float(cfg_get(ctx, "support_tau", 1e-6)) 
    
    Sig = np.asarray(agent.sigma_q_field if which == "q" else agent.sigma_p_field, np.float64)
    if not np.all(np.isfinite(Sig)):
        raise FloatingPointError("inverse_fisher_metric_field: non-finite Σ")

    Gens = np.asarray(generators, np.float64)  # (d,K,K)
    if Gens.ndim != 3 or Gens.shape[1] != Gens.shape[2]:
        raise ValueError(f"inverse_fisher_metric_field: generators must be (d,K,K); got {Gens.shape}")
    if not np.all(np.isfinite(Gens)):
        raise FloatingPointError("inverse_fisher_metric_field: non-finite generators")

    H, W, K, _ = Sig.shape
    d = int(Gens.shape[0])

    mask = (np.asarray(agent.mask) > tau).reshape(H, W)

    # --- cache lookup -------------------------------------------------------
    C    = getattr(ctx, "cache", None)
    step = int(getattr(ctx, "global_step", -1))
    aid  = _aid(agent)
    key  = ("FisherMetricInv_v2", which, aid, step, (H, W, K, d))
    if C is not None:
        cached = C.get("fisher", key)
        if cached is not None:
            return cached

    # --- Fisher blocks: precision ------------------------------------------
    Fb   = Fisher_blocks(ctx, agent, which=which, tol=tol)
    Prec = np.asarray(Fb["precision"], np.float64)  # (H,W,K,K)
    if not np.all(np.isfinite(Prec)):
        raise FloatingPointError("inverse_fisher_metric_field: non-finite precision from Fisher_blocks")

    # --- build T_a = Σ^{-1} G_a Σ^{-1}  and F_ab = tr(T_a G_b) --------------
    T = np.einsum("...ij,ajk->...aik", Prec, Gens, optimize=True)
    T = np.einsum("...aik,...kl->...ail", T,   Prec, optimize=True)
    F = np.einsum("...aij,bji->...ab", T, Gens, optimize=True)
    F = 0.5 * (F + np.swapaxes(F, -1, -2))  # symmetry guard
    
    if not np.all(np.isfinite(F)):
        raise FloatingPointError("inverse_fisher_metric_field: non-finite Fisher matrix")

    # --- regularized inverse per pixel: (F + λI)^-1 via Cholesky -----------
    # λ = max(abs_floor, rel_floor * trace(F)/d). This avoids exploding scale when F≈0.
    abs_floor = float(cfg_get(ctx, "fisher_abs_floor", 1e-6))
    rel_floor = float(cfg_get(ctx, "fisher_rel_floor", 1e-3))

    Fflat   = F.reshape(-1, d, d)
    mflat   = mask.reshape(-1)
    Finv_f  = np.zeros_like(Fflat)

    I_d = np.eye(d, dtype=np.float64)

    # Optional post-inversion normalization & cap
    do_norm   = bool(cfg_get(ctx, "fisher_normalize", True))  # make average eig ≈ 1
    cap_fro   = float(cfg_get(ctx, "fisher_cap_fro", 0.0))    # 0 = off

    # small constant for safe divides
    tiny = 1e-12

    if np.any(mflat):
        M  = Fflat[mflat]  # (M,d,d)
        tr = np.trace(M, axis1=-2, axis2=-1)  # (M,)
        lam = np.maximum(abs_floor, rel_floor * np.maximum(tr / float(d), 0.0))  # (M,)

        # Add λI and invert with Cholesky; if that fails, grow λ (ladder)
        M_reg = M + lam[:, None, None] * I_d  # broadcast (M,1,1)

        # Try Cholesky; if it fails for any pixel, escalate lambda there
        ok = np.ones(M.shape[0], dtype=bool)
        Minv = np.empty_like(M_reg)
        tries = 4
        for t in range(tries):
            try_ids = np.where(ok)[0]
            if try_ids.size == 0:
                break
            # do batches one-by-one to keep it simple and robust
            for idx in try_ids:
                Mi = M_reg[idx]
                try:
                    L = np.linalg.cholesky(Mi)
                    # inv via chol solve: inv(M) = (L^{-1})^T L^{-1}
                    X = np.linalg.solve(L, I_d)
                    Minv[idx] = X.T @ X
                    ok[idx] = False  # solved
                except np.linalg.LinAlgError:
                    # escalate λ and retry this pixel
                    lam[idx] *= 10.0
                    M_reg[idx] = M[idx] + lam[idx] * I_d
            # loop continues until all pixels solved or tries exhausted

        if np.any(ok):
            # As a last resort, use np.linalg.pinv on the remaining few
            for idx in np.where(ok)[0]:
                Minv[idx] = np.linalg.pinv(M[idx], rcond=1e-12)

        # Optional normalization: scale Finv so average eig scale ~ 1
        if do_norm:
            # avg eig(F) ~ tr(F)/d ; enforce Finv *= avg_eig(F) to keep scale consistent
            scale = np.maximum(tr, tiny) / float(d)  # (M,)
            Minv = Minv * scale[:, None, None]

        # Optional Frobenius cap to avoid extreme preconditioning
        if cap_fro and cap_fro > 0.0:
            fn = np.linalg.norm(Minv.reshape(Minv.shape[0], -1), axis=1)  # (M,)
            s  = np.minimum(1.0, cap_fro / (fn + tiny))
            Minv = Minv * s[:, None, None]

        # symmetry guard & store
        Minv = 0.5 * (Minv + np.swapaxes(Minv, -1, -2))
        Finv_f[mflat] = Minv

    Finv = Finv_f.reshape(H, W, d, d).astype(np.float32, copy=False)

    if C is not None:
        C.put("fisher", key, Finv)
    return Finv

# =============================================================================
#                       Holonomy / transport helpers
# =============================================================================





