# -*- coding: utf-8 -*-
"""
Unified Animation Module — All Visualizations
"""

import os
import re
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation
from pathlib import Path
import pickle
from scipy.ndimage import laplace

import config
from generalized_omega import compute_field_strength
from generalized_math_utils import kl_divergence
from get_generators import get_generators
from generalized_diagnostics_metrics import compute_entropy_field, compute_kl_qp_field
# === GLOBAL CONFIG ===
# Now reading from per-step .npz dumps
FIELDS_DIR     = Path("checkpoints/fields")
CHECKPOINT_DIR = Path("checkpoints")
OUTDIR         = Path("Animations/all_outputs")
OUTDIR.mkdir(parents=True, exist_ok=True)

FPS        = 25
INTERVAL   = 1000 // FPS
CMAP       = "viridis"
LOG_EPS    = 1e-8
DOWNSAMPLE = 1


# === UTILITIES ===
def safe_masked(arr):
    return np.ma.masked_where(arr == 0, arr)

def compute_mean_entropy_field(sigma_stack, mask_stack, log_eps=1e-8):
    """
    sigma_stack: shape (N, H, W, K) or (N, H, W, K, K)
    mask_stack : shape (N, H, W)  (boolean per-agent support)
    Returns: (H, W) array = mean_i [ entropy_i(c) ], zero outside union(mask_i).
    """
    N, H, W = mask_stack.shape
    # 1) compute each agent's field
    ent = np.zeros((N, H, W), dtype=float)
    for i in range(N):
        ent[i] = compute_entropy_field(sigma_stack[i], mask_stack[i], log_eps)
    # 2) zero out cells no one supports
    union_mask = mask_stack.any(axis=0)
    # 3) mean only over agents that actually cover each cell
    #    so we don’t dilute with zeros where an agent had no support
    counts = mask_stack.sum(axis=0).astype(float)
    counts[counts == 0] = np.nan  # avoid div0
    Hmean = np.nansum(ent, axis=0) / counts
    Hmean[~union_mask] = 0.0
    return Hmean

def compute_mean_kl_field(mu_q_stack, sigma_q_stack, mu_p_stack, sigma_p_stack, mask_stack, log_eps=1e-8):
    """
    Computes the spatial mean of KL[q_i ‖ p_i] across agents at each pixel.

    Args:
        mu_q_stack    : (N, H, W, K_q)
        sigma_q_stack : (N, H, W, K_q, K_q)
        mu_p_stack    : (N, H, W, K_p)
        sigma_p_stack : (N, H, W, K_p, K_p)
        mask_stack    : (N, H, W)
        log_eps       : float, stabilizer

    Returns:
        KLmean: (H, W) array
    """
    N, H, W = mask_stack.shape
    kl = np.zeros((N, H, W), dtype=float)

    for i in range(N):
        kl[i] = compute_kl_qp_field(
            mu_q_stack[i], sigma_q_stack[i],
            mu_p_stack[i], sigma_p_stack[i],
            mask_stack[i],                   # ✅ FIXED: now included
            log_eps=log_eps
        )

    counts = mask_stack.sum(axis=0).astype(float)
    counts[counts == 0] = np.nan  # avoid div0
    KLmean = np.nansum(kl, axis=0) / counts
    KLmean[~np.isfinite(KLmean)] = 0.0
    return KLmean


def animate_per_agent_entropy():
    files = sorted(FIELDS_DIR.glob("step*.npz"))
    N = None
    # prepare one list of frames per agent
    frames = None
    steps = []

    for f in files:
        data = np.load(f)
        sigma_stack = data['sigma_q']  # (N, H, W, K) or (N, H, W, K, K)
        if N is None:
            N = sigma_stack.shape[0]
            frames = [[] for _ in range(N)]
        # mask for each agent
        mu_stack = data['mu_q']  # (N,H,W,K)
        mask_stack = np.linalg.norm(mu_stack, axis=-1) > config.support_cutoff_eps

        # compute each agent's entropy field
        for i in range(N):
            efield = compute_entropy_field(sigma_stack[i], mask_stack[i], log_eps=LOG_EPS)
            frames[i].append(efield)

        steps.append(int(f.stem.replace('step','')))

    # now animate per agent
    for i in range(N):
        animate_scalar_sequence(
            frames[i], steps,
            title=f"Entropy(q) — Agent {i}",
            fname=f"entropy_q_agent{i}"
        )


def compute_phi_norm(phi): 
    return np.linalg.norm(phi, axis=-1)

def compute_phi_laplacian_norm(phi):
    return np.linalg.norm(
        np.stack([laplace(phi[..., d]) for d in range(phi.shape[-1])], axis=-1),
        axis=-1
    )

def animate_scalar_sequence(field_seq, steps, title, fname):
    if len(field_seq) == 0:
        print(f"[WARN] No data for {title}, skipping animation.")
        return
    vmin = np.nanmin(field_seq)
    vmax = np.nanpercentile(field_seq, 99)
    fig, ax = plt.subplots()
    im = ax.imshow(field_seq[0], cmap=CMAP, vmin=vmin, vmax=vmax)
    ax.set_title(f"{title} — Step {steps[0]}")
    plt.colorbar(im, ax=ax)

    def update(i):
        im.set_data(field_seq[i])
        ax.set_title(f"{title} — Step {steps[i]}")
        return [im]

    ani = animation.FuncAnimation(
        fig, update, frames=len(steps), interval=INTERVAL, blit=True
    )
    ani.save(OUTDIR / f"{fname}.gif", writer=animation.PillowWriter(fps=FPS))
    plt.close()


# === GLOBAL FIELD ANIMATIONS ===
from generalized_diagnostics_metrics import compute_self_energy

from generalized_diagnostics_metrics import compute_self_energy

def animate_global_fields():
    files = sorted(FIELDS_DIR.glob("step*.npz"))
    print(f"[INFO] animate_global_fields: found {len(files)} .npz files in {FIELDS_DIR}")

    if not files:
        print("[WARN] No field files found!")
        return

    entropy_seq, self_energy_seq, phi_norm_seq, phi_model_seq, lap_phi_seq = [], [], [], [], []
    steps = []

    for f in files:
        print(f"[INFO] Processing: {f.name}")
        data = np.load(f)

        mu_q_stack = data['mu_q']
        N = mu_q_stack.shape[0]
        print(f"[INFO] File {f.name} has {N} agents")

        mu_q    = mu_q_stack.mean(axis=0)
        sigma_q = data['sigma_q'].mean(axis=0)
        mu_p    = data['mu_p'].mean(axis=0)
        sigma_p = data['sigma_p'].mean(axis=0)
        phi     = data['phi'].mean(axis=0)
        phi_m   = data['phi_model'].mean(axis=0)

        mask = data.get('mask_sum', None)
        if mask is None:
            mask = np.linalg.norm(mu_q, axis=-1) > config.support_cutoff_eps
        else:
            mask = mask > config.support_cutoff_eps

        sigma_q_stack = data['sigma_q']
        mu_p_stack    = data['mu_p']
        sigma_p_stack = data['sigma_p']

        # Check for both morphisms
        if 'phi_q_to_p' in data and 'phi_p_to_q' in data:
            morphism_q_to_p = data['phi_q_to_p']
            morphism_p_to_q = data['phi_p_to_q']
        else:
            K_q = mu_q_stack.shape[-1]
            K_p = mu_p_stack.shape[-1]
            print(f"[WARN] Missing phi_q_to_p and/or phi_p_to_q. Using identity if K_q == K_p.")
            if K_q != K_p:
                raise ValueError("[animate_global_fields] Cannot use identity morphism when K_q ≠ K_p.")
            identity = np.eye(K_q, dtype=np.float32)
            morphism_q_to_p = np.broadcast_to(identity[None, None, None, :, :],
                                              (N, *mu_q_stack.shape[1:3], K_q, K_q))
            morphism_p_to_q = morphism_q_to_p  # identity in both directions

        if 'mask_sum' in data:
            union = data['mask_sum'] > config.support_cutoff_eps
            mask_stack = np.broadcast_to(union[None, ...], mu_q_stack.shape[:3])
        else:
            mask_stack = np.linalg.norm(mu_q_stack, axis=-1) > config.support_cutoff_eps

        entropy_seq.append(
            compute_mean_entropy_field(sigma_q_stack, mask_stack, log_eps=LOG_EPS)
        )

        self_energy_fields = []
        for i in range(N):
            dummy = type("Agent", (), {})()
            dummy.mu_q_field = mu_q_stack[i]
            dummy.sigma_q_field = sigma_q_stack[i]
            dummy.mu_p_field = mu_p_stack[i]
            dummy.sigma_p_field = sigma_p_stack[i]
            dummy.mask = mask_stack[i]
            dummy.bundle_morphism_q_to_p = morphism_q_to_p[i]
            dummy.bundle_morphism_p_to_q = morphism_p_to_q[i]  # ✅ not transposed!
            kl_q_phi_p = compute_self_energy(dummy, log_eps=LOG_EPS, cfg=vars(config))

            self_energy_fields.append(kl_q_phi_p)

        mean_self_energy = np.nanmean(self_energy_fields, axis=0)

        if mean_self_energy.ndim != 2:
            print(f"[WARN] Invalid mean_self_energy shape: {mean_self_energy.shape}, skipping frame.")
            continue

        self_energy_seq.append(mean_self_energy)

        phi_norm_seq.append(compute_phi_norm(phi) * mask)
        phi_model_seq.append(compute_phi_norm(phi_m) * mask)
        lap_phi_seq.append(compute_phi_laplacian_norm(phi) * mask)
        steps.append(int(f.stem.replace('step', '')))

    print(f"[INFO] Animating {len(steps)} time steps...")
    animate_scalar_sequence(entropy_seq,      steps, "Entropy(q)",      "entropy_q")
    animate_scalar_sequence(self_energy_seq,  steps, "KL(q ‖ Φ·p)",     "kl_q_phi_p")
    animate_scalar_sequence(phi_norm_seq,     steps, "‖φ‖",             "phi_norm")
    animate_scalar_sequence(phi_model_seq,    steps, "‖φ_model‖",       "phi_model_norm")
    animate_scalar_sequence(lap_phi_seq,      steps, "‖Δφ‖",            "lap_phi")
    print("[✓] animate_global_fields completed.")


def animate_per_agent_kl_qp():
    files = sorted(FIELDS_DIR.glob("step*.npz"))
    N = None
    frames = None
    steps = []

    for f in files:
        data = np.load(f)
        mu_q_stack = data["mu_q"]
        sigma_q_stack = data["sigma_q"]
        mu_p_stack = data["mu_p"]
        sigma_p_stack = data["sigma_p"]

        if N is None:
            N = mu_q_stack.shape[0]
            frames = [[] for _ in range(N)]

        mask_stack = np.linalg.norm(mu_q_stack, axis=-1) > config.support_cutoff_eps

        for i in range(N):
            kl = compute_kl_qp_field(
                mu_q_stack[i], sigma_q_stack[i],
                mu_p_stack[i], sigma_p_stack[i],
                mask_stack[i], log_eps=LOG_EPS
            )
            frames[i].append(kl)

        steps.append(int(f.stem.replace("step", "")))

    for i in range(N):
        animate_scalar_sequence(
            frames[i], steps,
            title=f"KL(q‖p) — Agent {i}",
            fname=f"kl_qp_agent{i}"
        )
    

# === AGENT-LEVEL PHI & CURVATURE ===
def load_checkpoints():
    files = sorted(CHECKPOINT_DIR.glob("step_*.pkl"))
    return [(pickle.load(open(f, 'rb')), int(f.stem.split('_')[1])) for f in files]


def compute_field(agent, metric):
    mask = agent.mask > config.support_cutoff_eps
    if metric == "phi_norm":
        return compute_phi_norm(agent.phi) * mask
    elif metric == "curvature_norm":
        gens = get_generators(config.group_name, config.K)
       
        dx = getattr(config, 'dx', 1.0)
        F = compute_field_strength(agent.phi, gens, dx=dx)['xy']
        return np.linalg.norm(F, axis=(-2, -1)) * mask
    else:
        return np.zeros_like(agent.mask, dtype=float)
        return np.zeros_like(agent.mask, dtype=float)


def animate_agent_fields():
    agent_data = load_checkpoints()
    if not agent_data:
        print("[WARN] No checkpoints found for agent animations.")
        return
    # assume same agent IDs each step
    agents0, _ = agent_data[0]
    agent_ids = [A.id for A in agents0]

    for metric in ["phi_norm", "curvature_norm"]:
        for aid in agent_ids:
            frames, steps = [], []
            for agents, step in agent_data[::DOWNSAMPLE]:
                agent = next((a for a in agents if a.id == aid), None)
                if agent is None: continue
                frames.append(compute_field(agent, metric))
                steps.append(step)
            animate_scalar_sequence(
                frames, steps,
                f"{metric} agent {aid}",
                f"{metric}_agent{aid}"
            )


# === MAIN ===
if __name__ == "__main__":
    print("[Run] Global field animations...")
    animate_global_fields()

    print("[Run] Agent-level φ and curvature...")
    #animate_agent_fields()
    print("[Run] Per-agent entropy animations...")
    #animate_per_agent_entropy()
    print("[✓] All animations completed.")
