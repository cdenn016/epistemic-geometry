
from __future__ import annotations
from typing import Any
import numpy as np

# Your existing utilities
from core.omega import exp_lie_algebra_irrep, retract_phi_principal
from core.numerical_utils import safe_omega_inv
from joblib import Parallel, delayed
import hashlib
from core.get_generators import get_generators



"""
Cache Policy — Rule of One
1) One cache hub: runtime_ctx.cache (cleared once per step).
2) One facade to read/write: this file (E_grid, Omega, Jinv_grid, Phi, Phi_tilde, Lambda_*).
3) One warm point per step: ensure_dirty(...) — nowhere else.
Consumers must never pre-warm; they just call the facade.
"""



def _get_phi(agent: Any, which: str) -> np.ndarray:
    if which == "q":
        phi = getattr(agent, "phi", None)
    else:
        phi = getattr(agent, "phi_model", None)
    if phi is None:
        raise ValueError(f"[transport_cache] phi field ({which}) missing")
    return phi


def orthogonalize_intertwiner(Phi0: np.ndarray) -> np.ndarray:
    """
    If Phi0 is square, project to the nearest orthogonal matrix via polar decomposition.
    For rectangular maps, returns Phi0 unchanged.
    """
    Kp, Kq = Phi0.shape
    if Kp != Kq:
        return Phi0
    U, _, Vt = np.linalg.svd(Phi0.astype(np.float64, copy=False), full_matrices=False)
    return (U @ Vt).astype(Phi0.dtype, copy=False)





# ---------------------------------------------------------------------------
#                              Caches
# ---------------------------------------------------------------------------
def ensure_global_A(ctx, spatial_shape, *, init_scale=0.0, smooth_sigma=2.0,
                    dtype=np.float32, seed=0):
    """
    Ensure a smooth global gauge field A on an M-D periodic grid:
      shape: (*S, M, 3)
      - trailing axis -2: spatial direction index (0..M-1)
      - trailing axis -1: so(3) algebra components (3)

    Uses periodic Gaussian smoothing to enforce spatial continuity.
    """
    import numpy as np
    from scipy.ndimage import gaussian_filter

    if not hasattr(ctx, "fields"):
        raise RuntimeError("ctx.fields missing; update RuntimeCtx to include a fields dict.")

    S = tuple(int(s) for s in spatial_shape)
    M = len(S)
    want = S + (M, 3)

    A = ctx.fields.get("A", None)
    if A is not None:
        A = np.asarray(A)
        if A.shape == want:
            ctx.fields["A"] = A.astype(dtype, copy=False)
            return ctx.fields["A"]
        ctx.fields["A"] = None  # reinit if wrong shape

    # --- initialize ---
    if init_scale > 0.0:
        rng = np.random.default_rng(seed)
        A = rng.normal(0.0, init_scale, size=want).astype(np.float64)

        # Smooth each algebra component per spatial direction
        for m in range(M):
            for c in range(3):
                A[..., m, c] = gaussian_filter(
                    A[..., m, c], sigma=smooth_sigma, mode="wrap"
                )
    else:
        A = np.zeros(want, dtype=np.float64)

    # --- optional normalization: keep local magnitudes ~ init_scale ---
    mag = np.sqrt(np.sum(A**2, axis=-1, keepdims=True))
    target = init_scale * np.sqrt(3.0)
    A = np.where(mag > 0, A * (target / (mag + 1e-12)), A)

    ctx.fields["A"] = A.astype(dtype, copy=False)
    return ctx.fields["A"]




def _expA_generic(ctx, agent, which: str):
    
    from core.get_generators import get_generators
    from core.omega import exp_lie_algebra_irrep, retract_phi_principal
    from runtime_context import cfg_get

    C        = ctx.cache
    step_tag = int(getattr(ctx, "global_step", -1))
    G        = get_generators(agent, which).astype(np.float32, copy=False)
    gsig     = stable_sig(G)
    max_norm = float(cfg_get(ctx, "exp_clip_max_norm", 1e4))

    A = np.asarray(getattr(ctx, "fields", {}).get("A", None), np.float32)
    if A is None: raise RuntimeError("Global A not initialized. Call ensure_global_A(...) first.")
    if A.ndim == 1 and A.shape == (3,):
        key = (f"expA_{which}_scalar", step_tag, gsig)
        U = C.get("exp", key)
        if U is None:
            a = retract_phi_principal(A, margin=1e-6, use_float64=False)
            U = exp_lie_algebra_irrep(a, G, max_norm=max_norm).astype(np.float32, copy=False)
            C.put("exp", key, U)
        return U  # (K,K)

    # A is (*S, M, 3)
    if not (A.ndim >= 2 and A.shape[-1] == 3):
        raise ValueError(f"expA: expected (*S,M,3) or (3,), got {A.shape}")
    M = int(A.shape[-2])
    S = A.shape[:-2]

    key = (f"expA_{which}_split", step_tag, gsig, S, M)
    U = C.get("exp", key)
    if U is not None:
        return U

    Aproj = retract_phi_principal(A, margin=1e-6, use_float64=False).astype(np.float32, copy=False)
    # Exponentiate per spatial direction:
    mats = []
    for m in range(M):
        Am = Aproj[..., m, :]                              # (*S, 3)
        Um = exp_lie_algebra_irrep(Am, G, max_norm=max_norm)  # (*S, K, K)
        mats.append(Um)
    U = np.stack(mats, axis=-3).astype(np.float32, copy=False)   # (*S, M, K, K)
    C.put("exp", key, U)
    return U

def expA_q(ctx, agent): return _expA_generic(ctx, agent, "q")
def expA_p(ctx, agent): return _expA_generic(ctx, agent, "p")




def _so3_log_matrix(R: np.ndarray, eps: float = 1e-12) -> np.ndarray:
    """
    Log map for SO(3) rotation matrices.
    Input:
      R: (..., 3, 3)
    Output:
      phi: (..., 3)  such that exp([phi]_×) ≈ R
    Handles small angles and π-neighborhood robustly.
    """
    import numpy as np
    R = np.asarray(R, np.float64)
    if R.shape[-2:] != (3, 3):
        raise ValueError(f"_so3_log_matrix expects (...,3,3), got {R.shape}")

    # Symmetrize numerically and clamp trace to [-1,3]
    tr = np.trace(R, axis1=-2, axis2=-1)
    tr = np.clip(tr, -1.0, 3.0)
    # angle
    cos_theta = (tr - 1.0) * 0.5
    cos_theta = np.clip(cos_theta, -1.0, +1.0)
    theta = np.arccos(cos_theta)  # in [0,pi]

    # Skew part S = (R - R^T)/2
    S = 0.5 * (R - np.swapaxes(R, -1, -2))
    # For generic case (not tiny/singular): axis = vee(S) / sinθ
    v = np.stack([S[..., 2, 1], S[..., 0, 2], S[..., 1, 0]], axis=-1)  # (...,3)

    # Small angle: use series θ ≈ ||v|| (since sinθ ≈ θ), fall back to S
    small = (theta < 1e-6)
    phi = np.empty_like(v)

    # Regular branch
    s = np.sin(theta)
    denom = s + eps
    phi_reg = v * (theta / denom)[..., None]

    # Small-angle branch: use first-order approx phi ≈ vee(S)
    phi_small = v  # already ~ θ u when θ→0

    # Near π: numerical issues—recover axis from R+I
    near_pi = (np.abs(theta - np.pi) < 1e-5)
    if np.any(near_pi):
        # From Hartley/Zisserman trick: use principal eigenvector of (R + I)
        RpI = R + np.eye(3)[None, None, ...]
        # pick the column with largest norm
        # But that’s messy for batch; instead, compute axis component-wise:
        ux = np.sqrt(np.maximum(RpI[..., 0, 0] / 2.0, 0.0))
        uy = np.sqrt(np.maximum(RpI[..., 1, 1] / 2.0, 0.0))
        uz = np.sqrt(np.maximum(RpI[..., 2, 2] / 2.0, 0.0))
        # fix signs using off-diagonals
        ux = np.copysign(ux, S[..., 2, 1])
        uy = np.copysign(uy, S[..., 0, 2])
        uz = np.copysign(uz, S[..., 1, 0])
        u = np.stack([ux, uy, uz], axis=-1)
        # normalize axis and set phi = θ u
        n = np.linalg.norm(u, axis=-1, keepdims=True) + eps
        u = u / n
        phi_pi = u * theta[..., None]
    else:
        phi_pi = phi_reg  # unused where not near π

    # Blend
    phi = np.where(small[..., None], phi_small, phi_reg)
    phi = np.where(near_pi[..., None], phi_pi, phi)

    return phi.astype(np.float32, copy=False)


def E_grid(ctx, agent, which: str = "q") -> np.ndarray:
    """
    Frame map E = exp(phi · G) optionally composed with global geometry A.

    Returns: (*S, K, K)
    """
    import numpy as np
    from runtime_context import cfg_get
    from utils import _aid

    if getattr(ctx, "cache", None) is None:
        raise RuntimeError("E_grid: ctx.cache missing")

    C        = ctx.cache
    step_tag = int(getattr(ctx, "global_step", -1))

    use_A       = bool(cfg_get(ctx, "use_global_A", False))
    compose_ord = cfg_get(ctx, "A_compose_order", None)
    th_small    = float(cfg_get(ctx, "phi_small_threshold", 1e-3))
    max_norm    = float(cfg_get(ctx, "exp_clip_max_norm",   1e4))

    phi = _get_phi(agent, which)                     # (*S,3)
    G   = get_generators(agent, which)               # (3,K,K)
    G32 = np.asarray(G, np.float32, order="C")
    if not (G32.ndim == 3 and G32.shape[0] == 3 and G32.shape[1] == G32.shape[2]):
        raise ValueError(f"E_grid[{which}]: generators must be (3,K,K); got {G32.shape}")
    K = int(G32.shape[1])

    gsig   = stable_sig(("G", G32))
    phisig = stable_sig(("phi", np.asarray(phi, np.float32, order="C")))
    cfgsig = stable_sig(("useA", use_A), ("ord", compose_ord),
                        ("thr", th_small), ("clip", max_norm))
    key = ("E_grid", step_tag, _aid(agent), which, gsig, phisig, cfgsig)
    E_cached = C.get("exp", key)
    if E_cached is not None:
        return E_cached

    # sanitize φ
    phi32 = retract_phi_principal(np.asarray(phi, np.float32, order="C"),
                                  margin=1e-6, use_float64=False)

    # small-angle fast path: E ≈ I
    if phi32.shape[-1] == 3:
        th = np.linalg.norm(phi32, axis=-1)
        if float(np.max(th)) < th_small:
            E = np.broadcast_to(np.eye(K, dtype=np.float32), phi32.shape[:-1] + (K, K)).copy()
            if use_A:
                U_geom_raw = expA_q(ctx, agent) if which == "q" else expA_p(ctx, agent)
                U_geom = _compose_geom_if_split(U_geom_raw, order=compose_ord)  # (*S,?,?)
                # LIFT to K×K if needed
                if U_geom.ndim >= 2 and U_geom.shape[-1] != K:
                    # Expect adjoint 3×3 → compute φ_A = log_SO3(U_geom) then lift via G
                    phi_A = _so3_log_matrix(U_geom)                               # (*S,3)
                    U_geom = exp_lie_algebra_irrep(phi_A.astype(np.float32), G32, max_norm=max_norm)
                E = np.einsum("...ik,...kj->...ij", U_geom, E, optimize=True)
            C.put("exp", key, E)
            return E

    # main: local site exponential
    E_local = exp_lie_algebra_irrep(phi32, G32, max_norm=max_norm)  # (*S, K, K)

    if not use_A:
        C.put("exp", key, E_local)
        return E_local

    # compose geometry
    U_geom_raw = expA_q(ctx, agent) if which == "q" else expA_p(ctx, agent)
    U_geom = _compose_geom_if_split(U_geom_raw, order=compose_ord)  # (*S,?,?)

    # LIFT to K×K if needed
    if U_geom.ndim >= 2 and U_geom.shape[-1] != K:
        # Expect adjoint 3×3; compute axis–angle then lift via generators G
        phi_A = _so3_log_matrix(U_geom)                                # (*S,3)
        U_geom = exp_lie_algebra_irrep(phi_A.astype(np.float32), G32, max_norm=max_norm)

    # final composition
    E = np.einsum("...ik,...kj->...ij", U_geom, E_local, optimize=True)
    E = E.astype(np.float32, copy=False)
    C.put("exp", key, E)
    return E



def _compose_geom_if_split(U_geom: np.ndarray, order=None) -> np.ndarray:
    """
    Normalize geometry shapes and compose per-axis links if provided.

    Accepts:
      - (K, K)              → uniform (returns (K,K))
      - (*S, K, K)          → already composed (returns (*S,K,K))
      - (*S, M, K, K)       → split per spatial axis; composed by `order` → (*S,K,K)
    """
    import numpy as np
    U = np.asarray(U_geom, np.float32)

    # Split per axis: (*S, M, K, K)  -- HANDLE THIS FIRST
    if U.ndim >= 4 and U.shape[-1] == U.shape[-2]:
        M = int(U.shape[-3])
        K = int(U.shape[-1])

        # If there are exactly 4 dims and the penultimate is square K, it might
        # still be (*S,K,K) (already composed). Distinguish by comparing sizes:
        # For split, U.shape[-3] (M) is the number of spatial directions; that is
        # usually != K. Even if M==K by coincidence, we still treat as split when
        # there is a distinct "direction" axis of length M.
        if U.ndim > 3 and (U.shape[-3] != K or U.ndim > 4):
            # resolve order
            if order is None:
                ord_idx = list(range(M))
            elif isinstance(order, str):
                o = order.lower()
                if o in ("yx", "zyx"):
                    ord_idx = list(range(M - 1, -1, -1))
                else:
                    ord_idx = list(range(M))
            else:
                ord_idx = list(int(x) for x in order)
                if len(set(ord_idx)) != len(ord_idx) or not all(0 <= x < M for x in ord_idx):
                    raise ValueError(f"_compose_geom_if_split: bad order {order} for M={M}")

            S = U.shape[:-3]
            I = np.broadcast_to(np.eye(K, dtype=np.float32), S + (K, K)).copy()
            Acc = I
            for m in ord_idx:
                Um = U[..., m, :, :]
                Acc = np.einsum("...ik,...kj->...ij", Um, Acc, optimize=True)
            return Acc.astype(np.float32, copy=False)

    # Already composed: (*S, K, K)
    if U.ndim >= 3 and U.shape[-1] == U.shape[-2]:
        return U

    # Uniform: (K, K)
    if U.ndim == 2 and U.shape[0] == U.shape[1]:
        return U

    raise ValueError(f"_compose_geom_if_split: unrecognized geometry shape {U.shape}")



def Omega(ctx: Any, ai: Any, aj: Any, which: str = "q") -> np.ndarray:
    """
    Neighbor transport Ω_{ij} with optional freeze modes.

    config.freeze_omega_mode:
      - "none"     : default behavior (cached per step & φ)
      - "identity" : return per-site identity (*S, K, K) (shape taken from ai)
    """
    import numpy as np
    from runtime_context import cfg_get
    from utils import _aid

    if getattr(ctx, "cache", None) is None:
        raise RuntimeError("Omega: ctx.cache missing")
    C        = ctx.cache
    step_tag = int(getattr(ctx, "global_step", -1))
    mode     = str(cfg_get(ctx, "freeze_omega_mode", "none")).lower()

    # ---------- IDENTITY mode (N-D safe) ----------
    if mode == "identity":
        # Use reps from ai/aj and ensure same K
        Gi = get_generators(ai, which)
        Gj = get_generators(aj, which)
        Gi32 = np.asarray(Gi, np.float32, order="C")
        Gj32 = np.asarray(Gj, np.float32, order="C")
        if not (Gi32.ndim == 3 and Gi32.shape[0] == 3 and Gi32.shape[1] == Gi32.shape[2]):
            raise ValueError(f"Omega[{which}]: generators_i must be (3,K,K); got {Gi32.shape}")
        if not (Gj32.ndim == 3 and Gj32.shape[0] == 3 and Gj32.shape[1] == Gj32.shape[2]):
            raise ValueError(f"Omega[{which}]: generators_j must be (3,K,K); got {Gj32.shape}")
        Ki, Kj = int(Gi32.shape[1]), int(Gj32.shape[1])
        if Ki != Kj:
            raise ValueError(f"Omega[{which}]-identity: Ki ({Ki}) != Kj ({Kj}); no identity transport defined")

        # Derive spatial shape *S from φ_i if present, else from mask (squeezing a trailing channel)
        try:
            S = np.asarray(_get_phi(ai, which)).shape[:-1]  # (*S,)
        except Exception:
            m = np.asarray(getattr(ai, "mask"))
            if m.ndim >= 1 and m.shape[-1] == 1:
                m = m[..., 0]
            S = m.shape

        keyI = ("Omega_identity", step_tag, _aid(ai), _aid(aj), which, S, Ki)
        OmI = C.get("omega", keyI)
        if OmI is None:
            OmI = np.broadcast_to(np.eye(Ki, dtype=np.float32), tuple(S) + (Ki, Ki)).copy()
            C.put("omega", keyI, OmI)
        return OmI

    # ---------- Default mode ----------
    # Pull fields/generators and validate
    phi_i = _get_phi(ai, which)
    phi_j = _get_phi(aj, which)

    Gi = get_generators(ai, which)
    Gj = get_generators(aj, which)

    Gi32 = np.asarray(Gi, np.float32, order="C")
    Gj32 = np.asarray(Gj, np.float32, order="C")
    if not (Gi32.ndim == 3 and Gi32.shape[0] == 3 and Gi32.shape[1] == Gi32.shape[2]):
        raise ValueError(f"Omega[{which}]: generators_i must be (3,K,K); got {Gi32.shape}")
    if not (Gj32.ndim == 3 and Gj32.shape[0] == 3 and Gj32.shape[1] == Gj32.shape[2]):
        raise ValueError(f"Omega[{which}]: generators_j must be (3,K,K); got {Gj32.shape}")

    # Stable, shape-aware signatures
    gensig_i = getattr(ai, f"_gensig_{which}", None)
    if gensig_i is None:
        gensig_i = stable_sig(("G", Gi32))
        setattr(ai, f"_gensig_{which}", gensig_i)

    gensig_j = getattr(aj, f"_gensig_{which}", None)
    if gensig_j is None:
        gensig_j = stable_sig(("G", Gj32))
        setattr(aj, f"_gensig_{which}", gensig_j)

    phisig_i = stable_sig(("phi", np.asarray(phi_i, np.float32, order="C")))
    phisig_j = stable_sig(("phi", np.asarray(phi_j, np.float32, order="C")))

    # Cache key (per step, agent pair, rep, gens, phis)
    key = ("Omega", step_tag, _aid(ai), _aid(aj), which, gensig_i, gensig_j, phisig_i, phisig_j)
    Om = C.get("omega", key)
    if Om is not None:
        return Om

    # Build frames (E_grid caches internally with its own keys)
    Ei = E_grid(ctx, ai, which)   # (*S, K, K)
    Ej = E_grid(ctx, aj, which)   # (*S, K, K)
    if not (np.isfinite(Ei).all() and np.isfinite(Ej).all()):
        raise FloatingPointError("Omega: non-finite frame exponentials")

    Ej_inv = safe_omega_inv(Ej)    # robust inverse suitable for transport
    Om = np.matmul(Ei, Ej_inv)     # (*S, K, K)
    if not np.isfinite(Om).all():
        raise FloatingPointError("Omega: non-finite Ω")

    C.put("omega", key, Om.astype(np.float32, copy=False))
    return Om


def Jinv_grid(ctx, agent, which="q", bbox=None):
    import numpy as np
    from utils import _aid

    if getattr(ctx, "cache", None) is None:
        raise RuntimeError("Jinv_grid: ctx.cache missing")
    C        = ctx.cache
    step_tag = int(getattr(ctx, "global_step", -1))

    # ---- pull & sanitize phi once (the value we’ll actually use)
    phi = np.asarray(_get_phi(agent, which), order="C")  # keep dtype (float32/64) as-is

    # ---- cache key (per step, agent, rep, sanitized phi)
    key = ("Jinv_grid", step_tag, _aid(agent), which, stable_sig(("phi", np.asarray(phi, np.float32, order="C"))))

    J = C.get("jinv", key)
    if J is None:
        # build_dexpinv_matrix accepts (...,3) and returns (...,3,3)
        # preserve dtype chosen inside build_dexpinv_matrix
        J = build_dexpinv_matrix(phi, use_float64=(phi.dtype == np.float64))
        if not np.all(np.isfinite(J)):
            raise FloatingPointError("Jinv_grid: non-finite J")
        C.put("jinv", key, J)

    if bbox is None:
        return J

    # ---- N-D spatial crop
    # Expect J shape (*S, 3, 3). We'll support a legacy 2-D bbox (y0,y1,x0,x1)
    # by center-slicing extra spatial dims until 2 remain, then cropping those.
    J = np.asarray(J)
    if J.ndim < 3 or J.shape[-2:] != (3, 3):
        # Not a spatial field; ignore bbox gracefully
        return J

    S = J.shape[:-2]          # spatial shape
    M = len(S)
    if M == 0:
        return J  # scalar site

    # legacy bbox must be 4 ints
    if not (isinstance(bbox, (tuple, list)) and len(bbox) == 4):
        # If you later add N-D bbox formats, handle them here. For now, ignore.
        return J

    y0, y1, x0, x1 = map(int, bbox)

    # If spatial rank > 2, center-slice the leading M-2 axes
    idx = []
    if M > 2:
        for ax in range(M - 2):
            mid = S[ax] // 2
            idx.append(slice(mid, mid + 1))
    # For the last two spatial axes, apply bbox (check bounds)
    H, W = S[-2], S[-1]
    if not (0 <= y0 < y1 <= H and 0 <= x0 < x1 <= W):
        raise ValueError(f"Jinv_grid: bbox {bbox} out of bounds for ({H},{W})")
    idx.extend([slice(y0, y1), slice(x0, x1)])
    # Add the trailing (3,3) matrix axes
    idx.extend([slice(None), slice(None)])

    Jc = J[tuple(idx)]
    # squeeze any singleton spatial axes we introduced
    Jc = np.squeeze(Jc, axis=tuple(range(max(0, M - 2))))
    return Jc




def Phi(ctx, agent, kind: str = "q_to_p"):
    """
    Bundle morphisms:
      q_to_p: Φ  = E_p  Φ₀   (E_q)^{-1}
      p_to_q: Φ̃ = E_q  Φ̃₀  (E_p)^{-1}
    Caches both directions per agent/rep/fields/geometry knobs.
    """
    import numpy as np
    from runtime_context import cfg_get
    from utils import _aid
    
    if getattr(ctx, "cache", None) is None:
        raise RuntimeError("Phi: ctx.cache required")
    if kind not in ("q_to_p", "p_to_q"):
        raise ValueError(f"Phi: unknown kind={kind!r}")

    C        = ctx.cache
    step_tag = int(getattr(ctx, "global_step", -1))
    aid      = _aid(agent)

    # --- Generators (validate early)
    Gq = np.asarray(get_generators(agent, "q"), np.float32, order="C")
    Gp = np.asarray(get_generators(agent, "p"), np.float32, order="C")
    if not (Gq.ndim == 3 and Gq.shape[0] == 3 and Gq.shape[1] == Gq.shape[2]):
        raise ValueError(f"Phi[q]: generators must be (3,Kq,Kq); got {Gq.shape}")
    if not (Gp.ndim == 3 and Gp.shape[0] == 3 and Gp.shape[1] == Gp.shape[2]):
        raise ValueError(f"Phi[p]: generators must be (3,Kp,Kp); got {Gp.shape}")
    Kq, Kp  = int(Gq.shape[1]), int(Gp.shape[1])
    sigGq   = stable_sig(("Gq", Gq))
    sigGp   = stable_sig(("Gp", Gp))

    # --- Bases (Φ0, Φ̃0)
    Phi0, Phit0 = get_morphism_bases(ctx, agent)  # already checked & shaped
    sigB        = stable_sig(("Phi0", Phi0), ("Phit0", Phit0))

    # --- Geometry knobs that affect E_grid -> Φ
    use_A    = bool(cfg_get(ctx, "use_global_A", False))
    ord_raw  = cfg_get(ctx, "A_compose_order", "yx")
    
    # Map to axis tokens if you added the mapper; else keep raw string:
    axis_ord = str(ord_raw).lower()
    th_small = float(cfg_get(ctx, "phi_small_threshold", 0.0))
    max_norm = float(cfg_get(ctx, "exp_clip_max_norm", 1e4))
    

    geom_sig = stable_sig(("useA", use_A), ("ord", axis_ord),
                          ("thr", th_small), ("clip", max_norm))

    # --- Sign sanitized fields (same values E_grid uses)
    phi_q = np.asarray(_get_phi(agent, "q"), np.float32, order="C")
    phi_p = np.asarray(_get_phi(agent, "p"), np.float32, order="C")
    
    
    sigPh = stable_sig(("phi_q", phi_q), ("phi_p", phi_p))

    # --- Keys (cache both directions)
    key_qp = ("morphism_full", aid, (Kq, Kp), "q_to_p", sigGq, sigGp, sigB, geom_sig, sigPh, step_tag)
    key_pq = ("morphism_full", aid, (Kq, Kp), "p_to_q", sigGq, sigGp, sigB, geom_sig, sigPh, step_tag)

    M_qp = C.get("morphism", key_qp)
    M_pq = C.get("morphism", key_pq)
    if M_qp is not None and M_pq is not None:
        return M_qp if kind == "q_to_p" else M_pq

    # --- Build frames (E_grid caches internally)
    Eq = E_grid(ctx, agent, "q")  # (...,Kq,Kq) or (Kq,Kq)
    Ep = E_grid(ctx, agent, "p")  # (...,Kp,Kp) or (Kp,Kp)
    
    inv_Eq = safe_omega_inv(Eq)
    inv_Ep = safe_omega_inv(Ep) 

    # Broadcast-safe multiplies (handles spatial or scalar reps)
    Phi_full  = Ep @ Phi0  @ inv_Eq   # q -> p
    Phit_full = Eq @ Phit0 @ inv_Ep   # p -> q

    if not (np.isfinite(Phi_full).all() and np.isfinite(Phit_full).all()):
        raise FloatingPointError("Phi: non-finite result")

    Phi_full  = np.asarray(Phi_full,  np.float32, order="C")
    Phit_full = np.asarray(Phit_full, np.float32, order="C")
    C.put("morphism", key_qp, Phi_full)
    C.put("morphism", key_pq, Phit_full)
    return Phi_full if kind == "q_to_p" else Phit_full


def get_morphism_bases(ctx, agent):
    """
    Fetch (or build+cache) intertwiner bases Φ0, Φ̃0 for this agent.
    Prefers agent-initialized bases, supports identity-if-square, and
    rebuilds only on generator digest change.
    """
    import numpy as np
    from runtime_context import cfg_get
    from utils import (
        _ensure_q_to_p_shape, _ensure_p_to_q_shape, _aid,
        
    )
    from core.bundle_morphism_utils import build_intertwiner_bases

    ns = ctx.cache.nsp("morph_base")

    # --- Generators & sizes ---
    Gq = get_generators(agent, "q")   # (3, Kq, Kq)
    Gp = get_generators(agent, "p")   # (3, Kp, Kp)
    if not (isinstance(Gq, np.ndarray) and Gq.ndim == 3 and Gq.shape[0] == 3 and Gq.shape[1] == Gq.shape[2]):
        raise ValueError(f"[morph] Gq must be (3,Kq,Kq); got {None if Gq is None else Gq.shape}")
    if not (isinstance(Gp, np.ndarray) and Gp.ndim == 3 and Gp.shape[0] == 3 and Gp.shape[1] == Gp.shape[2]):
        raise ValueError(f"[morph] Gp must be (3,Kp,Kp); got {None if Gp is None else Gp.shape}")

    Kq, Kp = int(Gq.shape[1]), int(Gp.shape[1])
    aid    = _aid(agent)
    key    = (aid, Kq, Kp)

    # --- Digest guards rebuilds if gens/policy change ---
    dig_now = stable_sig(
        ("Gq", Gq), ("Gp", Gp),
        ("Kq", Kq), ("Kp", Kp),
        ("impl", "build_intertwiner_bases@v1"),
        ("method", "auto"),
        ("orth_if_square", bool(cfg_get(ctx, "morphism_orthogonalize_if_square", True))),
    )

    # --- 1) Cache hit with matching digest ---
    entry = ns.get(key)
    if entry is not None and entry.get("digest") == dig_now:
        return entry["Phi0"], entry["Phit0"]

    # Helper to validate & store into cache
    def _finalize(Phi0_in, Phit0_in):
        Phi0  = _ensure_q_to_p_shape(np.asarray(Phi0_in),  Kp, Kq).astype(np.float32, copy=False)  # (Kp,Kq)
        Phit0 = _ensure_p_to_q_shape(np.asarray(Phit0_in), Kq, Kp).astype(np.float32, copy=False)  # (Kq,Kp)

        if not (np.isfinite(Phi0).all() and np.isfinite(Phit0).all()):
            raise ValueError("[morph] Φ0/Φ̃0 contain non-finite values")
        if max(np.linalg.norm(Phi0, 'fro'), np.linalg.norm(Phit0, 'fro')) == 0.0:
            raise ValueError("[morph] Φ0/Φ̃0 are zero")

        ns[key] = {"Phi0": Phi0, "Phit0": Phit0, "digest": dig_now, "warned": False}

        # Optional residual check (once)
        tol_rel = float(cfg_get(ctx, "intertwiner_rel_tol", 1e-7))
        if not ns[key]["warned"]:
            try:
                r1 = _intertwining_resid(Gp, Gq, Phi0)    # || Gp Φ0 - Φ0 Gq ||
                r2 = _intertwining_resid(Gq, Gp, Phit0)   # || Gq Φ̃0 - Φ̃0 Gp ||
                scale = max(np.linalg.norm(Gq, 'fro'), np.linalg.norm(Gp, 'fro'), 1.0)
                rel = (r1 + r2) / (1e-6 + scale)
                if rel > tol_rel:
                    print(f"[morph] note: relative intertwiner residual ≈ {rel:.2e}")
                    ns[key]["warned"] = True
            except Exception:
                ns[key]["warned"] = False

        return ns[key]["Phi0"], ns[key]["Phit0"]

    # --- 2) Prefer agent-initialized bases (single source of truth) ---
    Phi0_agent  = getattr(agent, "Phi0_base",  None)
    Phit0_agent = getattr(agent, "Phit0_base", None)
    if Phi0_agent is None or Phit0_agent is None:
        # legacy field names for back-compat
        Phi0_agent  = getattr(agent, "Phi_0",        Phi0_agent)
        Phit0_agent = getattr(agent, "Phi_tilde_0",  Phit0_agent)
    if isinstance(Phi0_agent, np.ndarray) and isinstance(Phit0_agent, np.ndarray):
        
        return _finalize(Phi0_agent, Phit0_agent)


    # --- 4) Build once (no agent bases & not identity case) ---
    Phi0_new, Phit0_new, _ = build_intertwiner_bases(Gq, Gp, method="auto", return_meta=True)
    print("Phi0 is being built!!\n\n")
    return _finalize(Phi0_new, Phit0_new)






def Phi_cached(ctx, agent, *, kind: str):
    """
    Cache Φ / Φ̃ per agent per step. Requires CacheHub.get(ns, key) / put(ns, key, val).
    """
    C = getattr(ctx, "cache", None)
    if C is None:
        # no cache hub, compute directly
        return Phi(ctx, agent, kind=kind)

    step_tag = int(getattr(ctx, "global_step", -1))
    ns = "Phi"  # namespace for morphisms
    # keep key small but unique; add kind + step
    key = (id(agent), kind, step_tag)

    val = C.get(ns, key)
    if val is not None:
        return val

    M = Phi(ctx, agent, kind=kind)
    C.put(ns, key, M)
    return M



def E_grid_field(ctx, phi_field, generators, *, sign=+1):
    """
    Exponential from a *field* (not from agent): E = exp(sign * φ) under the given generators.
    Uses the same sanitization as E_grid. Accepts φ of shape (..., 3).
    Returns (..., K, K).
    """
    import numpy as np
    from runtime_context import cfg_get
    # sanitize φ to principal ball
    phi = retract_phi_principal(
        np.asarray(phi_field, np.float32),
        margin=1e-6, use_float64=False
    ).astype(np.float32, copy=False)

    if sign not in (+1, -1):
        raise ValueError(f"E_grid_field: sign must be +1 or -1, got {sign!r}")
    if sign == -1:
        phi = -phi

    # validate generators (3, K, K)
    G = np.asarray(generators, np.float32, order="C")
    if not (G.ndim == 3 and G.shape[0] == 3 and G.shape[1] == G.shape[2]):
        raise ValueError(f"E_grid_field: generators must be (3,K,K); got {G.shape}")

    max_norm = float(cfg_get(ctx, "exp_clip_max_norm", 1e4))
    return exp_lie_algebra_irrep(phi, G, max_norm=max_norm)



def exp_and_jinv_single(ctx, agent, field: str, base_field, generators_q, generators_p):
    """
    Resolve exp(field) and Jinv for one agent/fiber, with cache-first lookups.
    Returns:
      exp_this, exp_other, Jinv, which, G_q, G_p
    where:
      which ∈ {"q","p"}; exp_this matches 'which'.
    """

    which = "q" if field == "phi" else "p"

    # --- exp grids (cache first; fallback to local compute) ---
    exp_q = E_grid(ctx, agent, which="q")   
    exp_p = E_grid(ctx, agent, which="p")
    Jinv = Jinv_grid(ctx, agent, which=which)

    exp_this  = exp_q if which == "q" else exp_p
    exp_other = exp_p if which == "q" else exp_q

    # IMPORTANT: keep the generators aligned to their fibers
    G_q = generators_q
    G_p = generators_p

    return exp_this, exp_other, Jinv, which, G_q, G_p






def Fisher_blocks(ctx, agent, which="q", *, tol=None):
    
    from utils import _aid
    C = getattr(ctx, "cache", None)
    step_tag = int(getattr(ctx, "global_step", -1))
    Sig = np.asarray(getattr(agent, "sigma_q_field" if which == "q" else "sigma_p_field"),
                     np.float32, order="C")
    if Sig.shape[-1] != Sig.shape[-2]:
        raise ValueError(f"Sigma must be (...,K,K); got {Sig.shape}")

    key = None
    if C is not None:
        sigsig = hashlib.sha1(Sig.view(np.uint8)).hexdigest()  # faster than sha256
        key = ("Fisher_blocks", step_tag, _aid(agent), which, Sig.shape[-1], sigsig, tol)
        cached = C.get("fisher", key)
        if cached is not None:
            return cached

    Sig = 0.5 * (Sig + Sig.swapaxes(-1, -2))

    try:
        L = np.linalg.cholesky(Sig)
    except np.linalg.LinAlgError:
        raise np.linalg.LinAlgError("Σ not SPD even after symmetrization")

    I = np.eye(Sig.shape[-1], dtype=np.float32)
    I_b = np.broadcast_to(I, Sig.shape[:-2] + I.shape).copy()
    X = np.linalg.solve(L, I_b)
    Prec = np.swapaxes(X, -1, -2) @ X
    Prec = 0.5 * (Prec + Prec.swapaxes(-1, -2))

    diagL = np.diagonal(L, axis1=-2, axis2=-1)
    logdet = (2.0 * np.log(np.clip(diagL, 1e-30, None)).sum(axis=-1)).astype(np.float32)

    out = {"precision": Prec.astype(np.float32, copy=False), "logdet": logdet}
    
    if C is not None:
        C.put("fisher", key, out)
    return out



# ---------------------------------------------------------------------------
# Cached dexpinv matrices Jinv(phi)  (SO(3) axis-angle principal ball)
# ---------------------------------------------------------------------------

def build_dexpinv_matrix(
    phi: np.ndarray,
    eps: float = 1e-12,
    *,
    margin: float = 1e-6,     # principal-ball margin (π - margin)
    use_float64: bool = False,
) -> np.ndarray:
    """
    Stable SO(3) right-Jacobian inverse J^{-1}(φ).
    Returns array of shape (..., 3, 3).

    Formula (kept from your convention):
      J^{-1}(φ) = I - (θ/2) ad(u) + (1 - h) ad(u)^2,
      h(θ) = (θ/2) cot(θ/2),  φ = θ u,  ad(u) = [u]_×.
    """
    
    dtype = np.float64 if use_float64 else np.float32

    # ---- validate & retract ----
    phi = np.asarray(phi, dtype=dtype)
    if phi.shape[-1] != 3:
        raise ValueError(f"build_dexpinv_matrix: last dim must be 3, got {phi.shape}")
    phi_r = retract_phi_principal(phi, margin=margin, use_float64=use_float64).astype(dtype, copy=False)

    # ---- axis/angle pieces ----
    th   = np.linalg.norm(phi_r, axis=-1)               # (...,)
    u    = np.divide(phi_r, th[..., None] + eps, dtype=dtype)  # (...,3)

    ux, uy, uz = u[..., 0], u[..., 1], u[..., 2]
    z = np.zeros_like(ux, dtype=dtype)
    adu = np.stack([
        np.stack([ z,  -uz,  uy], axis=-1),
        np.stack([ uz,   z, -ux], axis=-1),
        np.stack([-uy,  ux,   z], axis=-1),
    ], axis=-2).astype(dtype, copy=False)               # (...,3,3)

    # ---- h(θ) = (θ/2) cot(θ/2) with small-θ series ----
    half = 0.5 * th
    small = th < 1e-3
    # series in θ (not half): 1 - θ^2/12 - θ^4/720 + O(θ^6)
    t2 = th * th
    h_series = 1.0 - (t2 / 12.0) - ((t2 * t2) / 720.0)

    # safe half-angle for non-small branch
    half_ns = np.clip(half, 1e-6, np.pi/2 - 1e-6)
    h_closed = half_ns / np.tan(half_ns)

    # piecewise combine without extra passes
    h = np.where(small, h_series, h_closed)

    # ---- build J^{-1} ----
    I = np.eye(3, dtype=dtype)
    uuT  = u[..., :, None] * u[..., None, :]           # (...,3,3)
    adu2 = (uuT - I)                                   # (...,3,3)

    Jinv = I - half[..., None, None] * adu + (1.0 - h)[..., None, None] * adu2
    if not np.all(np.isfinite(Jinv)):
        raise FloatingPointError("build_dexpinv_matrix produced non-finite values")

    return Jinv.astype(np.float32, copy=False)






#==============================================================================
#
#
#
#==============================================================================




def _intertwining_resid(G_left, G_right, X):
    """
    Residual || G_left[a] X - X G_right[a] ||_F summed over a=0..2.
    Shapes: G_left(Kout,Kout,3), G_right(Kin,Kin,3), X(Kout,Kin)
    """
    
    X  = np.asarray(X, np.float32)
    Kout = G_left.shape[0]; Kin = G_right.shape[0]
    if X.shape != (Kout, Kin):
        raise ValueError(f"X has shape {X.shape}, expected {(Kout, Kin)}")
    r = 0.0
    for a in range(3):
        r += float(np.linalg.norm(G_left[..., a] @ X - X @ G_right[..., a]))
    return r



#==============================================================================
#
#                  Gauge Curvature
#
#==============================================================================


def _roll_spatial_axis(a: np.ndarray, axis_m: int, shift: int, *, trailing: int = 2) -> np.ndarray:
    """
    Periodic roll along the m-th spatial axis (0-based among spatial axes).
    trailing: number of non-spatial trailing dims (e.g., 2 for (...,K,K), 1 for (...,3)).
    """
    axes = list(range(a.ndim - trailing))  # all spatial axes are the leading dims before trailing
    if not axes:
        return a
    if not (0 <= axis_m < len(axes)):
        raise IndexError(f"axis_m={axis_m} out of range for spatial rank {len(axes)} (shape {a.shape}, trailing={trailing})")
    return np.roll(a, shift=shift, axis=axes[axis_m])




def plaquette_from_A(ctx, agent, which: str = "q", pair: tuple[int,int] | None = None):
    """
    P_ab(i) = U_a(i) · U_b(i+ê_a) · U_a(i+ê_b)^{-1} · U_b(i)^{-1}
    using per-axis links from expA_q/expA_p.
    """
    import numpy as np

    Ugeom = expA_q(ctx, agent) if which == "q" else expA_p(ctx, agent)  # (*S,M,K,K) or (K,K)
    Ugeom = np.asarray(Ugeom, np.float32)

    # Broadcast scalar/uniform A to grid
    if Ugeom.ndim == 2:
        S = tuple(np.asarray(agent.mask).shape)
        Ugeom = np.broadcast_to(Ugeom, S + Ugeom.shape)  # (*S,K,K)
        Ugeom = Ugeom[..., None, :, :]                   # (*S,1,K,K)

    if not (Ugeom.ndim >= 4 and Ugeom.shape[-3] >= 1 and Ugeom.shape[-2] == Ugeom.shape[-1]):
        raise ValueError(f"expA_* must return (*S,M,K,K) or (K,K); got {Ugeom.shape}")

    S = Ugeom.shape[:-3]
    M = int(Ugeom.shape[-3])

    if M < 2 and (pair is None or pair[0] == pair[1]):
        raise ValueError("plaquette_from_A: need at least two spatial axes (M>=2) to form a plaquette")

    if pair is None:
        pair = (0, 1)
    a, b = pair
    if not (0 <= a < M and 0 <= b < M and a != b):
        raise ValueError(f"bad plaquette pair {pair} for M={M}")

    Ua = Ugeom[..., a, :, :]       # (*S,K,K)
    Ub = Ugeom[..., b, :, :]

    # neighbor-shifted links
    Ub_a1 = _roll_spatial_axis(Ub, a, +1, trailing=2)  # U_b(i+ê_a)
    Ua_b1 = _roll_spatial_axis(Ua, b, +1, trailing=2)  # U_a(i+ê_b)

    # SO(3) inverse is transpose; safe_omega_inv is fine if U may be slightly non-orthogonal
    P = Ua @ Ub_a1 @ safe_omega_inv(Ua_b1) @ safe_omega_inv(Ub)

    if not np.isfinite(P).all():
        raise FloatingPointError("plaquette_from_A: non-finite entries in P")

    return P.astype(np.float32, copy=False)


def plaquette_product(ctx, phi_field, generators, *,
                      split_edge=False, sign=+1,
                      pair: tuple[int, int] | None = None):
    """
    Compute local plaquette product:
      P_ab(i) = U_a(i) · U_b(i+ê_a) · U_a(i+ê_b)^T · U_b(i)^T

    phi_field : (*S, 3)
    generators: (3,K,K) or (K,K,3)
    pair      : (a,b) spatial axes (default (0,1))
    Returns   : (*S, K, K)
    """
    import numpy as np

    # Normalize generators to (3,K,K)
    G = np.asarray(generators, np.float32)
    if G.ndim != 3:
        raise ValueError(f"generators must be rank-3, got {G.shape}")
    G3 = G if G.shape[0] == 3 else np.moveaxis(G, -1, 0)

    # Site exponentials
    E  = E_grid_field(ctx, phi_field, G3, sign=sign)   # (*S,K,K)
    Et = np.swapaxes(E, -1, -2)

    S = E.shape[:-2]
    M = len(S)
    if pair is None:
        pair = (0, 1 if M > 1 else 0)
    a, b = pair
    if not (0 <= a < M and 0 <= b < M and a != b):
        raise ValueError(f"bad plaquette pair {pair} for spatial rank {M}")

    if not split_edge:
        # Shifted exponentials
        E_a1 = _roll_spatial_axis(E, a, +1, trailing=2)  # E(i+ê_a)
        E_b1 = _roll_spatial_axis(E, b, +1, trailing=2)  # E(i+ê_b)

        # Links: U_a(i) = E(i+ê_a) E(i)^T, U_b(i) = E(i+ê_b) E(i)^T
        Ua_ij = np.matmul(E_a1, Et)
        Ub_ij = np.matmul(E_b1, Et)

        # Shifted links: U_a(i+ê_b), U_b(i+ê_a)
        Ua_b1 = _roll_spatial_axis(Ua_ij, b, +1, trailing=2)
        Ub_a1 = _roll_spatial_axis(Ub_ij, a, +1, trailing=2)
    else:
        half = 0.5
        Ehalf_here = E_grid_field(ctx, half * phi_field, G3, sign=sign)
        Ehalf_a1   = _roll_spatial_axis(Ehalf_here, a, +1, trailing=2)
        Ehalf_b1   = _roll_spatial_axis(Ehalf_here, b, +1, trailing=2)
        Eh_t       = np.swapaxes(Ehalf_here, -1, -2)
        Ua_ij = np.matmul(Ehalf_a1, Eh_t)
        Ub_ij = np.matmul(Ehalf_b1, Eh_t)
        Ua_b1 = _roll_spatial_axis(Ua_ij, b, +1, trailing=2)
        Ub_a1 = _roll_spatial_axis(Ub_ij, a, +1, trailing=2)

    # Final plaquette: P_ab = U_a · U_b(i+ê_a) · U_a(i+ê_b)^T · U_b(i)^T
    P = Ua_ij @ Ub_a1 @ np.swapaxes(Ua_b1, -1, -2) @ np.swapaxes(Ub_ij, -1, -2)
    return P.astype(np.float32, copy=False)



# ---------------------------------------------------------------------------
# Warming & invalidation
# ---------------------------------------------------------------------------



def warm_E(ctx, agents, whiches=("q","p"), n_jobs=None):
    from runtime_context import cfg_get
    n = max(1, n_jobs or int(cfg_get(ctx, "n_jobs", 1)))
    def _one(a):
        for w in whiches:
            try: _ = E_grid(ctx, a, which=w)
            except Exception as e:
                print(f"warm-e fail ({getattr(a,'id',None)} {w}): {type(e).__name__}: {e}")
    Parallel(n_jobs=n, backend="threading", batch_size="auto")(
        delayed(_one)(a) for a in agents
    )



def warm_Jinv(ctx, agents, whiches=("q","p"), n_jobs=None):
    """Precompute Jinv for many agents (idempotent)."""
    from runtime_context import cfg_get
    n = max(1, n_jobs or int(cfg_get(ctx, "n_jobs", 1)))

    def _one(a):
        for w in whiches:
            try:
                _ = Jinv_grid(ctx, a, which=w)
            except Exception as e:
                print(f"warm-jinv fail (agent={getattr(a,'id',None)} {w}): {type(e).__name__}: {e}")

    Parallel(n_jobs=n, backend="threading", batch_size="auto")(
        delayed(_one)(a) for a in agents
    )





def stable_sig(*parts, float_dtype=np.float32, order="C") -> str:
    """
    Deterministic SHA256 over heterogeneous inputs.
    - Arrays: cast to float_dtype, force C-order, include shape bytes
    - Numbers/strings/bytes: tagged
    - dicts: sorted by key; lists/tuples: include length and order
    - None: tagged
    Falls back to repr(...) for unknown types.
    """
    h = hashlib.sha256()

    def _upd(x):
        if isinstance(x, np.ndarray):
            a = np.asarray(x, dtype=float_dtype, order=order)
            h.update(b"A"); h.update(str(a.shape).encode()); h.update(a.tobytes())
        elif isinstance(x, (float, np.floating)):
            h.update(b"f"); h.update(np.asarray(x, float_dtype).tobytes())
        elif isinstance(x, (int, np.integer, bool, np.bool_)):
            # 8-byte little-endian signed for stability
            h.update(b"i"); h.update(int(x).to_bytes(8, "little", signed=True))
        elif isinstance(x, (bytes, bytearray, memoryview)):
            h.update(b"B"); h.update(bytes(x))
        elif isinstance(x, str):
            h.update(b"S"); h.update(x.encode("utf-8"))
        elif isinstance(x, dict):
            h.update(b"D")
            for k in sorted(x.keys()):
                _upd(k); _upd(x[k])
        elif isinstance(x, (list, tuple)):
            h.update(b"L"); h.update(len(x).to_bytes(8, "little"))
            for y in x: _upd(y)
        elif x is None:
            h.update(b"N")
        else:
            h.update(b"R"); h.update(repr(x).encode("utf-8"))

    for p in parts: _upd(p)
    return h.hexdigest()

