# -*- coding: utf-8 -*-
"""
Created on Mon Sep  8 16:26:26 2025

@author: chris and christine
"""

import numpy as np
from core.numerical_utils import safe_inv, sanitize_sigma  
from core.omega import inverse_fisher_metric_field

# --- Unified dirty manager ----------------------------------------------------
class DirtyManager:
    """
    Single source of truth for 'dirty' state.

    Responsibilities:
      - Track dirty agents across categories: fields, kl, morphisms
      - Provide stable IDs (no object-id fallbacks)
      - Materialize a target agent subset by category
      - Clear agent-side flags only after successful processing
      - Bump ctx cache_version exactly when work happened
    """
    __slots__ = ("_fields", "_kl", "_morph",)

    def __init__(self):
        self._fields: set[int] = set()
        self._kl: set[int] = set()
        self._morph: set[int] = set()

    # ---- Stable ID helpers -------------------------------------------------
    @staticmethod
    def _aid(agent) -> int:
        aid = getattr(agent, "id", None)
        if aid is None:
            raise ValueError("DirtyManager: agent has no stable `id` attribute")
        return int(aid)

    # ---- Marking -----------------------------------------------------------
    def mark(self, *agents: object, kl: bool = False, morphism: bool = False) -> None:
        for a in agents:
            if a is None:
                continue
            aid = self._aid(a)
            # Always mark fields when any aspect of the agent changed
            self._fields.add(aid)
            setattr(a, "_dirty_fields", True)
            if kl:
                self._kl.add(aid)
                setattr(a, "_dirty_kl", True)
            if morphism:
                self._morph.add(aid)
                setattr(a, "morphisms_dirty", True)

    def mark_morphism_only(self, *agents: object) -> None:
        self.mark(*agents, morphism=True)

    def mark_kl_only(self, *agents: object) -> None:
        self.mark(*agents, kl=True)

    # ---- Selection ---------------------------------------------------------
    def take(self, all_agents: list, category: str = "fields") -> list:
        if   category == "fields": bag = self._fields
        elif category == "kl":     bag = self._kl
        elif category == "morph":  bag = self._morph
        else:
            raise ValueError(f"DirtyManager.take: unknown category {category!r}")

        if not bag:
            return []
        wanted = {int(x) for x in bag}
        subset = [a for a in (all_agents or []) if a is not None and self._aid(a) in wanted]
        bag.clear()
        return subset

    # ---- Post-processing cleanup ------------------------------------------
    def clear_agent_flags(self, *agents: object) -> None:
        for a in agents:
            if a is None:
                continue
            if hasattr(a, "_dirty_fields"): a._dirty_fields = False
            if hasattr(a, "_dirty_kl"):     a._dirty_kl = False
            if hasattr(a, "morphisms_dirty"): a.morphisms_dirty = False


# Attach/get from ctx (one per runtime context)
def dirty_manager(ctx) -> DirtyManager:
    d = getattr(ctx, "_dirty_manager", None)
    if d is None:
        d = DirtyManager()
        setattr(ctx, "_dirty_manager", d)
    return d


def ensure_dirty(ctx, generators_q, generators_p, scope="all"):
    """
    Resolve and process dirty agents for the given scope.
    Does: inline φ/φ̃ projection, build/ensure morphism bases in cache,
         pre-warm caches (E, Jinv, Φ/Φ̃), clear flags, bump cache when work happened.
    """
    DM = dirty_manager(ctx)

    # 1) Select targets by scope
    if scope not in ("all", "children"):
        raise ValueError(f"[ensure_dirty] unknown scope={scope!r}")

    all_children = list(getattr(ctx, "children_latest", []))
    targets = DM.take(all_children, category="fields")
    targets = [t for t in targets if t is not None]
    if not targets:
        return []

    # Record whether anything *was* marked dirty (for bump decision)
    had_flags = any(
        getattr(a, "_dirty_fields", False)
        or getattr(a, "_dirty_kl", False)
        or getattr(a, "morphisms_dirty", False)
        for a in targets
    )

    did_any = False

    # 5) Clear flags only if we actually processed them
    if did_any:
        DM.clear_agent_flags(*targets)

    # 6) Bump cache exactly when we had flags and did work
    if did_any and had_flags:
        setattr(ctx, "cache_version", int(getattr(ctx, "cache_version", 0)) + 1)

    return targets


# ---------------------------------------------------------------------
# Per-agent preprocessing
# ---------------------------------------------------------------------


def refresh_agents(agents, Gq, Gp, *, ctx=None):
    """
    Lightweight preprocessing for a batch of agents, fail-fast + idempotent per step.

    Per agent:
      • ensure mask exists and matches spatial shape *S*
      • verify field shapes; sanitize Σ_q / Σ_p to SPD
      • compute Σ^{-1} (precision) via Cholesky solve
      • mark per-step preprocessed
    """
    
    from runtime_context import cfg_get
    
    eps = float(cfg_get(ctx, "eps", 1e-8))

    if not agents:
        raise ValueError("refresh_agents: empty `agents` list")
    if any(a is None for a in agents):
        raise ValueError("refresh_agents: `agents` contains None entries")
    if Gq is None or Gp is None:
        raise ValueError("refresh_agents: generators_q/p must be provided")

    # Validate generator shapes early
    Gq = np.asarray(Gq)
    Gp = np.asarray(Gp)
    if not (Gq.ndim == 3 and Gq.shape[0] == 3 and Gq.shape[1] == Gq.shape[2]):
        raise ValueError(f"refresh_agents: Gq must be (3,Kq,Kq); got {Gq.shape}")
    if not (Gp.ndim == 3 and Gp.shape[0] == 3 and Gp.shape[1] == Gp.shape[2]):
        raise ValueError(f"refresh_agents: Gp must be (3,Kp,Kp); got {Gp.shape}")
    Kq = int(Gq.shape[1])
    Kp = int(Gp.shape[1])

    step_tag = int(getattr(ctx, "global_step", -1))

    def _spatial_shape_from_agent(a):
        # Prefer covariance shapes (*S, K, K); fallback to μ field (*S, K)
        if hasattr(a, "sigma_q_field"):
            S = np.asarray(a.sigma_q_field).shape[:-2]
            if len(S) > 0:
                return S
        if hasattr(a, "mu_q_field"):
            S = np.asarray(a.mu_q_field).shape[:-1]
            if len(S) > 0:
                return S
        # last resort: from mask
        if hasattr(a, "mask") and a.mask is not None:
            m = np.asarray(a.mask)
            if m.ndim >= 1 and m.shape[-1] == 1:
                m = m[..., 0]
            return m.shape
        raise ValueError("refresh_agents: cannot infer spatial shape *S* from agent fields")

    # Establish canonical spatial shape *S* from the first agent
    S0 = _spatial_shape_from_agent(agents[0])

    for a in agents:
        # idempotence per step
        if getattr(a, "_preprocessed_step", None) == step_tag and step_tag >= 0:
            continue

        # ---- infer & validate spatial shape *S* for this agent
        S = _spatial_shape_from_agent(a)
        if tuple(S) != tuple(S0):
            raise ValueError(f"refresh_agents: spatial shape mismatch: {S} vs canonical {S0}")

        # ---- mask: must exist and match *S* (no padding/cropping)
        if not hasattr(a, "mask") or a.mask is None:
            # create full support mask explicitly
            a.mask = np.ones(S0, dtype=np.float32)
        else:
            m = np.asarray(a.mask)
            # squeeze trailing 1-channel if present
            if m.ndim == len(S0) + 1 and m.shape[-1] == 1:
                m = m[..., 0]
            if m.shape != S0:
                raise ValueError(f"refresh_agents: mask shape {m.shape} != spatial shape {S0}")
            if not np.isfinite(m).all():
                raise FloatingPointError("refresh_agents: non-finite values in mask")
            a.mask = m.astype(np.float32, copy=False)

        # ---- q-fields: shape checks and SPD sanitize
        Sq = np.asarray(a.sigma_q_field, np.float64)
        if Sq.shape != tuple(S0) + (Kq, Kq):
            raise ValueError(f"refresh_agents: sigma_q_field shape {Sq.shape} != {tuple(S0)+(Kq,Kq)}")
        Sq = sanitize_sigma(Sq, eps=eps).astype(np.float32, copy=False)
        if not np.isfinite(Sq).all():
            raise FloatingPointError("refresh_agents: non-finite values in sigma_q_field after sanitize")
        a.sigma_q_field = Sq

        Sp = np.asarray(a.sigma_p_field, np.float64)
        if Sp.shape != tuple(S0) + (Kp, Kp):
            raise ValueError(f"refresh_agents: sigma_p_field shape {Sp.shape} != {tuple(S0)+(Kp,Kp)}")
        Sp = sanitize_sigma(Sp, eps=eps).astype(np.float32, copy=False)
        if not np.isfinite(Sp).all():
            raise FloatingPointError("refresh_agents: non-finite values in sigma_p_field after sanitize")
        a.sigma_p_field = Sp

        # ---- inverses via Cholesky solves (robust precision)
        a.sigma_q_inv = safe_inv(a.sigma_q_field.astype(np.float64, copy=False), eps=eps).astype(np.float32, copy=False)
        a.sigma_p_inv = safe_inv(a.sigma_p_field.astype(np.float64, copy=False), eps=eps).astype(np.float32, copy=False)
        if not (np.isfinite(a.sigma_q_inv).all() and np.isfinite(a.sigma_p_inv).all()):
            raise FloatingPointError("refresh_agents: non-finite values in sigma inverses")

        # mark preprocessed
        a._preprocessed_step = step_tag



def _ensure_fisher(agent, *, which, generators, ctx, eps):
    # choose field names by fiber
    if which == "q":
        attr = "inverse_fisher_phi"
    else:
        attr = "inverse_fisher_phi_model"

    Finv = getattr(agent, attr, None)
    if Finv is not None:
        return  # already present

    # Optional: central cache by (agent_id, which) to avoid recompute in parallel
    cache_key = ("fisher", which, int(getattr(agent, "id", -1)))
    try:
        cache = ctx._cache  # if you have a context cache dict
    except AttributeError:
        cache = None

    if cache is not None and cache_key in cache:
        setattr(agent, attr, cache[cache_key])
        return

    Finv = inverse_fisher_metric_field(ctx, agent, generators, which=which, eps=eps)
    setattr(agent, attr, Finv)
    if cache is not None:
        cache[cache_key] = Finv




