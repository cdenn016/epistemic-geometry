# -*- coding: utf-8 -*-
"""
Created on Wed Aug  6 12:27:32 2025

@author: chris and christine
"""
 
import time
import numpy as np
import core.config as config
from core.numerical_utils import sanitize_sigma, safe_inv, push_gaussian
from core.transport_cache import Omega
from core.transport_cache import Phi_cached
from runtime_context import cfg_get
from core.numerical_utils import kl_gaussian
from beta_grads import grad_beta_mu_sigma_dispatch

from utils import (_aid, _fiber_keys_from_mode, _iter_overlap_pairs, _accumulate_into_agent,
                   _drain_inbox_into_dalign, _add_to_inbox )

# -------------------------------------------------------------------------
#                          PUBLIC ENTRYPOINTS
# -------------------------------------------------------------------------


def _mu_mag(x: np.ndarray) -> float:
    # mean L2 over spatial sites
    xr = x.reshape(-1, x.shape[-1])
    return float(np.mean(np.linalg.norm(xr, axis=-1)))

def _S_mag(S: np.ndarray) -> float:
    # mean Frobenius over spatial sites
    Sr = S.reshape(-1, S.shape[-2]*S.shape[-1])
    return float(np.mean(np.linalg.norm(Sr, axis=-1)))

def _print_vec(label: str, dmu: np.ndarray, dS: np.ndarray):
    
    dbg = False
    if not dbg: 
        return
    print(f"[μΣ MAG] {label:<18} | μ_meanL2={_mu_mag(dmu):.3e}  Σ_meanF={_S_mag(dS):.3e}", flush=True)


def accumulate_mu_sigma_gradient(ctx, agent_i, agents, mode):
    """
    Accumulate natural gradients (μ, Σ) for belief or model.

    Structure:
      1) Resolve fiber + keys (q/p)
      2) Pull Φ, Φ̃ from cache and push (q,p) once
      3) Self & feedback grads (receiver-only)
      4) Pairwise alignment grads (β ⊙ align  −  (β/κ) KL1 ⊙ β-basis)
      5) Combine -> natural projection -> accumulate to agent_i

    Inputs:
      ctx       : runtime context (required)
      agent_i   : receiver agent
      agents    : full list (for neighbors)
      mode      : {"belief","model"}
    """
    if ctx is None:
        raise RuntimeError("accumulate_mu_sigma_gradient: ctx required.")

    from runtime_context import cfg_get
    prof = bool(cfg_get(ctx, "debug_mu_sigma_timing", False))
    eps  = float(cfg_get(ctx, "eps", 1e-6))
    tau  = float(cfg_get(ctx, "support_tau", 1e-6))
    alpha = float(cfg_get(ctx, "alpha", 0.0))
    lambd = float(cfg_get(ctx, "feedback_weight", 0.0))

    accum_send = bool(cfg_get(ctx, "accumulate_sender_grads", False))
    dbg = bool(cfg_get(ctx, "debug_mu_sigma_mags", False))

    which, field, mu_key, S_key, gmu_key, gS_key = _fiber_keys_from_mode(mode)

    # ---------------- 1) timings bucket ----------------
    _t = {}
    _tic = lambda: time.perf_counter()
    def _tock(t0, name): _t[name] = _t.get(name, 0.0) + (time.perf_counter() - t0)

    # ---------------- 2) Φ/Φ̃ pushes once ----------------
    t0 = _tic()
    Phi  = Phi_cached(ctx, agent_i, kind="q_to_p")   # Φ: Q→P
    Phit = Phi_cached(ctx, agent_i, kind="p_to_q")   # Φ̃: P→Q
    _tock(t0, "Phi_fetch")

    mu_q = getattr(agent_i, "mu_q_field")
    S_q  = getattr(agent_i, "sigma_q_field")
    mu_p = getattr(agent_i, "mu_p_field")
    S_p  = getattr(agent_i, "sigma_p_field")

    t0 = _tic()
    mu_q_push, S_q_push, inv_q_push = push_gaussian(
        mu_q, S_q, Phi, eps=eps, return_inv=True,
        Sigma_inv=getattr(agent_i, "sigma_q_inv", None),
        assume_orthogonal=False
    )
    mu_p_push, S_p_push, inv_p_push = push_gaussian(
        mu_p, S_p, Phit, eps=eps, return_inv=True,
        Sigma_inv=getattr(agent_i, "sigma_p_inv", None),
        assume_orthogonal=False
    )
    _tock(t0, "push_gaussians")

    # ---------------- 3) self + feedback grads ----------------
    t0 = _tic()
    
    # --- self/feedback ENERGY accounting (unweighted, float64-safe) ---
    accumulate_self_feedback_energies(
        ctx, agent_i,
        mu_q=mu_q, S_q=S_q,
        mu_p=mu_p, S_p=S_p,
        mu_q_push=mu_q_push, S_q_push=S_q_push,
        mu_p_push=mu_p_push, S_p_push=S_p_push,
    )

    
    g_self_mu, g_self_S, g_fb_mu, g_fb_S = _self_and_feedback_grads(
        mode,
        mu_q, S_q, mu_p, S_p,
        mu_q_push, S_q_push, inv_q_push,
        mu_p_push, S_p_push, inv_p_push,
        Phi, Phit, eps,
        sigma_q_inv=getattr(agent_i, "sigma_q_inv", None),
        sigma_p_inv=getattr(agent_i, "sigma_p_inv", None),
        mask=getattr(agent_i, "mask", None),
    )
    _tock(t0, "self_feedback")
    
    _print_vec("self",     g_self_mu, g_self_S)
    _print_vec("feedback", g_fb_mu,   g_fb_S)
    
    
    # Target buffers (shape-safe, prezeroed)
    mu_i = np.asarray(getattr(agent_i, mu_key), np.float32, order="C")
    S_i  = np.asarray(getattr(agent_i, S_key),  np.float32, order="C")
    dmu_align = np.zeros_like(mu_i, dtype=np.float32)
    dS_align  = np.zeros_like(S_i,  dtype=np.float32)

    if accum_send:
        dmu_align, dS_align = _drain_inbox_into_dalign(agent_i, which, dmu_align, dS_align)
        _print_vec("inbox(j→i)", dmu_align, dS_align)
    # -------- 4) alignment (pairwise) --------
    # modern path: per-edge β maps; optional sender accumulation via toggle
    
    n_pairs = align_px = 0
    
    t0_all = _tic()
    for agent_j, overlap in _iter_overlap_pairs(agent_i, agents, tau=tau):
        if not np.any(overlap):
            continue
    
        n_pairs += 1
        align_px += int(np.count_nonzero(overlap))
    
        t1 = _tic()
        add_mu_i, add_S_i, add_mu_j, add_S_j = _accum_align_for_pair_clean(
            ctx, agent_i, agent_j,
            fiber=which,
            mu_key=mu_key, S_key=S_key,
            overlap_mask=overlap,
            eps=eps,
            Phi=Phi,                 # Φ for A/B
            Phi_tilde=Phit,          # Φ̃ for C/D
        )
        _tock(t1, "align_pair_sum")
    
        # scatter receiver (i) where overlapping
        dmu_align[overlap] += add_mu_i[overlap]
        dS_align [overlap] += add_S_i [overlap]
    
        # enqueue sender (j) — j will drain and project on its turn
        if accum_send:
            _add_to_inbox(agent_j, which, add_mu_j, add_S_j, overlap)
    
    _tock(t0_all, "align_total")
    
    if n_pairs:
        _t["align_pair_avg"] = _t["align_pair_sum"] / float(n_pairs)


    # -------- 5) combine + natural projection --------
    t0 = _tic()
    dmu_total = (alpha * g_self_mu + lambd * g_fb_mu + dmu_align).astype(np.float32, copy=False)
    dS_total  = (alpha * g_self_S  + lambd * g_fb_S  + dS_align ).astype(np.float32, copy=False)
    dS_total  = 0.5 * (dS_total + np.swapaxes(dS_total, -1, -2))
    _tock(t0, "combine_totals")

    _print_vec("total(pre-proj)", dmu_total, dS_total)


    t0 = _tic()
    delta_mu, delta_S = apply_natural_gradient_batch(
        ctx,
        getattr(agent_i, mu_key), getattr(agent_i, S_key),
        dmu_total, dS_total,
        mask=getattr(agent_i, "mask", None),
        assume_sanitized=True,
        grad_sigma_is_symmetric = True,
        use_float64 = True,
    )
    _tock(t0, "natural_project")

    _print_vec("delta(projected)", delta_mu, delta_S)

    # -------- 6) accumulate to agent --------
    _accumulate_into_agent(agent_i, gmu_key, gS_key, delta_mu, delta_S)

    # -------- timings (opt) --------
    if prof:
        aid = _aid(agent_i)
        print(f"[μΣ PROF] Agent {aid} ({mode}) pairs={n_pairs} align_px={align_px}")
        for k in ("Phi_fetch","push_gaussians","self_feedback",
                  "align_total","align_pair_sum","align_pair_avg",
                  "combine_totals","natural_project"):
            if k in _t:
                print(f"  {k:18s}: {_t[k]*1e3:7.2f} ms")

    return delta_mu, delta_S


# ---------------------------------------------------------------------------
# Small helpers (file-local)
# ---------------------------------------------------------------------------

def _accum_align_for_pair_clean(
    ctx,
    agent_i, agent_j,
    *,
    fiber: str,          # 'q' or 'p'
    mu_key: str,
    S_key: str,
    overlap_mask: np.ndarray,
    eps: float,
    Phi: np.ndarray,            # <-- new: Φ_i (Q->P)
    Phi_tilde: np.ndarray,      # <-- new: Φ̃_i (P->Q)
):
    """
    Clean alignment contribution from j→i on a given fiber.
    Uses per-edge β/KL1 and the μ/Σ β-dispatch (A/B/C/D).
    """
    
    dbg_pair = False
    
    i_id = int(getattr(agent_i, "id", -1))
    j_id = int(getattr(agent_j, "id", -1))
    beta_ij = np.asarray(ctx._edge_beta[(fiber, i_id, j_id)], np.float32)
    KL1_map = np.asarray(ctx._edge_kl1 [(fiber, i_id, j_id)], np.float32)
    if beta_ij.shape != overlap_mask.shape or KL1_map.shape != overlap_mask.shape:
        raise ValueError("β/KL1 map shape mismatch vs overlap")

    m = overlap_mask.astype(np.float32, copy=False)
    beta_ij = beta_ij * m
    KL1_map = KL1_map * m
    if not np.any(beta_ij > 0):
        Ki = int(getattr(agent_i, mu_key).shape[-1])
        S  = tuple(overlap_mask.shape)
        return (np.zeros(S + (Ki,),    np.float32),
                np.zeros(S + (Ki, Ki), np.float32))

    # transports & pushes (keep as you have)
    Om = Omega(ctx, agent_i, agent_j, which=fiber)
    mu_i = np.asarray(getattr(agent_i, mu_key), np.float32, order="C")
    S_i  = sanitize_sigma(np.asarray(getattr(agent_i, S_key), np.float64), eps=eps).astype(np.float32, copy=False)
    mu_j = np.asarray(getattr(agent_j, mu_key), np.float32, order="C")
    S_j  = sanitize_sigma(np.asarray(getattr(agent_j, S_key), np.float64), eps=eps).astype(np.float32, copy=False)

    mu_j_t, S_j_t, inv_j_t = push_gaussian(mu_j, S_j, Om, eps=eps, return_inv=True, sanitize_input=False)

    # Receiver ALIGN grads (i), fresh inverse for parity
    gmu_align, gS_align = grad_alignment_energy_source(
        mu_i, S_i, mu_j_t, inv_j_t, eps=eps, sigma_i_inv=None, assume_sanitized=True
    )

    # β grads dict
    basis = str(cfg_get(ctx, f"beta_{fiber}", "align_q" if fiber=="q" else "align_p")).lower()
    d = grad_beta_mu_sigma_dispatch(
        ctx, agent_i, agent_j, basis=basis,
        Omega_ij=Om, Phi_i=Phi, Phi_tilde_i=Phi_tilde, eps=eps,
    )
    gmu_beta_i, gS_beta_i = d["mu_rec"],  d["S_rec"]

    if gmu_beta_i.shape != gmu_align.shape or gS_beta_i.shape != gS_align.shape:
        raise ValueError("β-grad vs align-grad shape mismatch (receiver)")

    # --- product rule scale (you can keep KL1_map or use local; you already tried both)
    kappa = max(float(cfg_get(ctx, f"beta_kappa_{fiber}", 1.0)), 1e-12)
    sc    = -(beta_ij * (KL1_map / kappa)).astype(np.float32, copy=False)

    # Receiver contribution (i)
    term1_mu = beta_ij[..., None]       * gmu_align
    term1_S  = beta_ij[..., None, None] * gS_align
    term2_mu = sc[..., None]            * gmu_beta_i
    term2_S  = sc[..., None, None]      * gS_beta_i
    gmu_i = (term1_mu + term2_mu).astype(np.float32, copy=False)
    gS_i  = (term1_S  + term2_S ).astype(np.float32, copy=False)

    if dbg_pair:
        print(f"[PAIR MAG i] fiber={fiber} i={i_id} j={j_id} \n"
              f"| align μ={_mu_mag(term1_mu):.3e} Σ={_S_mag(term1_S):.3e} ;\n "
              f"beta μ={_mu_mag(term2_mu):.3e} Σ={_S_mag(term2_S):.3e} ; \n"
              f"total μ={_mu_mag(gmu_i):.3e} Σ={_S_mag(gS_i):.3e}\n\n", flush=True)

    # ---------------- NEW (sender) ----------------
    # Sender ALIGN grads (j) in j-frame
    gmu_align_j, gS_align_j = grad_alignment_energy_target(
        mu_i=mu_i, sigma_i=S_i,
        mu_j_t=mu_j_t, sigma_j_t_inv=inv_j_t,
        Omega_ij=Om, eps=eps, assume_sanitized=True
    )
    # Sender β grads from dispatcher
    gmu_beta_j, gS_beta_j = d["mu_send"], d["S_send"]

    

    # Same product rule on j
    term1_mu_j = beta_ij[..., None]       * gmu_align_j
    term1_S_j  = beta_ij[..., None, None] * gS_align_j
    term2_mu_j = sc[..., None]            * gmu_beta_j
    term2_S_j  = sc[..., None, None]      * gS_beta_j
    gmu_j = (term1_mu_j + term2_mu_j).astype(np.float32, copy=False)
    gS_j  = (term1_S_j  + term2_S_j ).astype(np.float32, copy=False)


    if dbg_pair:
        print(f"[PAIR MAG j] fiber={fiber} i={i_id} j={j_id} "
              f"| align μ={_mu_mag(term1_mu_j):.3e} Σ={_S_mag(term1_S_j):.3e} ; "
              f"beta μ={_mu_mag(term2_mu_j):.3e} Σ={_S_mag(term2_S_j):.3e} ; "
              f"total μ={_mu_mag(gmu_j):.3e} Σ={_S_mag(gS_j):.3e}", flush=True)

    return gmu_i, gS_i, gmu_j, gS_j


# --- Self / Feedback energy accumulation (shared with diagnostics) ---


def accumulate_self_feedback_energies(
    ctx,
    agent_i,
    *,
    mu_q, S_q,
    mu_p, S_p,
    mu_q_push, S_q_push,
    mu_p_push, S_p_push,
):
    """
    Accumulate UNWEIGHTED pixel-summed KLs into the per-step accumulator:
      self_sum     += sum_px KL(q || p')
      feedback_sum += sum_px KL(p || q')

    Keep α, λ application outside (e.g., in compute_global_metrics/total_energy),
    just like alignment stores unweighted KL. Returns (self_raw, feedback_raw).
    """
    import numpy as np
    from runtime_context import cfg_get, energy_acc_add
    from core.numerical_utils import sanitize_sigma

    eps = float(cfg_get(ctx, "eps", 1e-8))
    tau = float(cfg_get(ctx, "support_tau", 1e-6))

    # common support mask
    m = np.asarray(getattr(agent_i, "mask", 1.0), np.float32)
    mm = (m > tau) if (m.dtype != bool) else m
    if not np.any(mm):
        return 0.0, 0.0

    # slice active pixels
    μq  = np.asarray(mu_q[mm],      np.float64, order="C")
    Σq  = sanitize_sigma(np.asarray(S_q[mm],    np.float64, order="C"), eps=eps)
    μp  = np.asarray(mu_p[mm],      np.float64, order="C")
    Σp  = sanitize_sigma(np.asarray(S_p[mm],    np.float64, order="C"), eps=eps)
    μqʹ = np.asarray(mu_q_push[mm], np.float64, order="C")
    Σqʹ = sanitize_sigma(np.asarray(S_q_push[mm], np.float64, order="C"), eps=eps)
    μpʹ = np.asarray(mu_p_push[mm], np.float64, order="C")
    Σpʹ = sanitize_sigma(np.asarray(S_p_push[mm], np.float64, order="C"), eps=eps)

    # pixelwise KLs (unweighted)
    self_px     = kl_gaussian(μq, Σq, μpʹ, Σpʹ, eps=eps)   # KL(q || p')
    feedback_px = kl_gaussian(μp, Σp, μqʹ, Σqʹ, eps=eps)   # KL(p || q')

    self_raw = float(np.sum(self_px))
    fb_raw   = float(np.sum(feedback_px))

    # Accumulate UNWEIGHTED totals (match alignment convention)
    energy_acc_add(ctx, "self_sum",     self_raw)
    energy_acc_add(ctx, "feedback_sum", fb_raw)

    # Optional per-agent buckets (mirrors your alignment helper)
    aid = getattr(agent_i, "id", None)
    if aid is not None:
        energy_acc_add(ctx, f"self_sum[{aid}]",     self_raw)
        energy_acc_add(ctx, f"feedback_sum[{aid}]", fb_raw)

    return self_raw, fb_raw







def _self_and_feedback_grads(
    mode: str,
    mu_q, sigma_q, mu_p, sigma_p,
    mu_q_push, Sigma_q_push, inv_q_push,
    mu_p_push, Sigma_p_push, inv_p_push,
    Phi_mat, Phi_tilde_mat, eps: float,
    *, sigma_q_inv=None, sigma_p_inv=None, mask=None
):
    if mode == "belief":
        g_self_mu, g_self_S = grad_self_energy_belief(
            mu_q, sigma_q, mu_p_push, inv_p_push,
            sigma_q_inv=sigma_q_inv, mask=mask
        )
        g_fb_mu, g_fb_S = grad_feedback_energy_belief(
            mu_q, sigma_q, mu_p, mu_q_push,
            Sigma_q_push, inv_q_push, sigma_p, Phi_mat
        )
    elif mode == "model":
        g_self_mu, g_self_S = grad_self_energy_model(
            mu_q, sigma_q, mu_p_push, inv_p_push, Phi_tilde_mat, mask=mask
        )
        g_fb_mu, g_fb_S = grad_feedback_energy_model(
            mu_p, sigma_p, mu_q_push, Sigma_q_push, inv_q_push,
            sigma_p_inv=sigma_p_inv
        )
    else:
        raise ValueError(f"Unsupported mode: {mode}")
    return g_self_mu, g_self_S, g_fb_mu, g_fb_S




#==============================================================================
#
#                    FEEDBACK / SELF TERMS (unchanged math, safer numerics)
#==============================================================================

def grad_alignment_energy_source(
    mu_i, sigma_i, mu_j_t, sigma_j_t_inv, eps=1e-8,
    *, sigma_i_inv=None, assume_sanitized=True
):
    """
    Faster: reuse precomputed sigma_i_inv if provided; optionally skip sanitize.
    """
    mu_i       = np.asarray(mu_i,       dtype=np.float32, order="C")
    mu_j_t     = np.asarray(mu_j_t,     dtype=np.float32, order="C")
    sigma_j_t_inv = np.asarray(sigma_j_t_inv, dtype=np.float32, order="C")

    dmu = mu_i - mu_j_t
    # grad_mu_i = S'^-1 (μ_i - μ_j')
    grad_mu = np.einsum("...ij,...j->...i", sigma_j_t_inv, dmu, optimize=True)

    if sigma_i_inv is None:
        Si = np.asarray(sigma_i, dtype=np.float32, order="C")
        if not assume_sanitized:
            Si = sanitize_sigma(Si, eps=eps)
        sigma_i_inv = safe_inv(Si)   # batched cholesky-inv

    grad_sigma = 0.5 * (sigma_j_t_inv - sigma_i_inv)
    # symmetrize
    grad_sigma = 0.5 * (grad_sigma + np.swapaxes(grad_sigma, -1, -2))

    return grad_mu.astype(np.float32, copy=False), grad_sigma.astype(np.float32, copy=False)


def grad_alignment_energy_target(
    mu_i, sigma_i, mu_j_t, sigma_j_t_inv, Omega_ij, eps: float = 1e-8,
    *, assume_sanitized=True
):
    """
    Faster: use v = S'^-1 dμ  ->  v vᵀ for the middle term; skip repeated sanitize.
    """
    mu_i       = np.asarray(mu_i,       dtype=np.float32, order="C")
    mu_j_t     = np.asarray(mu_j_t,     dtype=np.float32, order="C")
    Omega_ij   = np.asarray(Omega_ij,   dtype=np.float32, order="C")
    sigma_jinv = np.asarray(sigma_j_t_inv, dtype=np.float32, order="C")

    dmu = mu_i - mu_j_t

    # ∂_{μ_j'} KL = - S'^-1 dμ  ;  map back with Ωᵀ
    gmu_jp    = -np.einsum("...ij,...j->...i", sigma_jinv, dmu, optimize=True)
    grad_mu_j = np.einsum("...ji,...j->...i", Omega_ij, gmu_jp, optimize=True)

    # Σ_i only appears (not inverted); assume sanitized upstream
    Si = np.asarray(sigma_i, dtype=np.float32, order="C")
    if not assume_sanitized:
        Si = sanitize_sigma(Si)

    # v = S'^-1 dμ  ->  v vᵀ
    v   = np.einsum("...ij,...j->...i", sigma_jinv, dmu, optimize=True)
    vvT = np.einsum("...i,...j->...ij", v, v, optimize=True)

    # gΣ' = 1/2( -S'^-1 Σ_i S'^-1 - vvᵀ + S'^-1 )
    t0 = -np.einsum("...ij,...jk,...kl->...il", sigma_jinv, Si, sigma_jinv, optimize=True)
    gSp = 0.5 * (t0 - vvT + sigma_jinv)

    # map back: Ωᵀ gΣ' Ω, then symmetrize
    grad_sigma_j = np.einsum("...ji,...jk,...kl->...il",
                             Omega_ij, gSp, np.swapaxes(Omega_ij, -1, -2), optimize=True)
    grad_sigma_j = 0.5 * (grad_sigma_j + np.swapaxes(grad_sigma_j, -1, -2))

    return grad_mu_j.astype(np.float32, copy=False), grad_sigma_j.astype(np.float32, copy=False)



def grad_feedback_energy_belief(
    mu_q, sigma_q, mu_p, mu_q_push,
    sigma_q_push, sigma_q_push_inv, sigma_p, Phi, eps=1e-8, *,
    assume_sanitized=True,
):
    """
    ∂ wrt (μ_q, Σ_q) of KL(p || Φ·q), evaluated in q-fiber.
    Uses v = S'^-1 Δ and v v^T instead of S'^-1 ΔΔ^T S'^-1 to cut temps.
    """
    # Δ = μ_p - μ_q'
    delta = (mu_p - mu_q_push).astype(np.float32, copy=False)

    # v = S'^-1 Δ  (matvec)
    v = np.matmul(sigma_q_push_inv, delta[..., None])[..., 0]  # (...,K)

    # grad_μ = - Φ^T v
    Phi_T = np.swapaxes(Phi, -1, -2)
    grad_mu = -np.matmul(Phi_T, v[..., None])[..., 0]

    # M = S'^-1  - v v^T  - S'^-1 Σ_p S'^-1
    term1 = sigma_q_push_inv
    term2 = np.matmul(v[..., :, None], v[..., None, :])        # v v^T
    term3 = np.matmul(np.matmul(sigma_q_push_inv, sigma_p), sigma_q_push_inv)

    M = term1 - term2 - term3

    # grad_Σ = 1/2 Φ^T M Φ (symmetrized)
    grad_sigma = 0.5 * np.matmul(np.matmul(Phi_T, M), Phi)
    grad_sigma = 0.5 * (grad_sigma + np.swapaxes(grad_sigma, -1, -2))

    return grad_mu.astype(np.float32, copy=False), grad_sigma.astype(np.float32, copy=False)


def grad_feedback_energy_model(
    mu_p, sigma_p, mu_q_push,
    sigma_q_push, sigma_q_push_inv, Phi=None, eps=1e-8, *,
    sigma_p_inv=None, assume_sanitized=True,
):
    """
    ∂ wrt (μ_p, Σ_p) of KL(p || q'), evaluated in p-fiber.
    Avoids inverting Σ_p if sigma_p_inv is provided.
    """
    delta = (mu_p - mu_q_push).astype(np.float32, copy=False)

    # grad_μ = S'^-1 Δ
    grad_mu = np.matmul(sigma_q_push_inv, delta[..., None])[..., 0]

    # grad_Σ = 1/2 (S'^-1 - Σ_p^{-1})
    if sigma_p_inv is None:
        # assume Σ_p already sanitized upstream; we only invert if caller didn’t pass inv
        sigma_p_inv = safe_inv(sigma_p.astype(np.float32, copy=False))
    grad_sigma = 0.5 * (sigma_q_push_inv - sigma_p_inv)
    grad_sigma = 0.5 * (grad_sigma + np.swapaxes(grad_sigma, -1, -2))

    return grad_mu.astype(np.float32, copy=False), grad_sigma.astype(np.float32, copy=False)


def grad_self_energy_belief(
    mu_q, sigma_q, mu_p_push, sigma_p_push_inv, eps=1e-8, *,
    sigma_q_inv=None, mask=None, assume_sanitized=True,
):
    """
    ∂ wrt (μ_q, Σ_q) of KL(q || p'), evaluated in q-fiber.
    Reuses sigma_q_inv if provided.
    """
    delta = (mu_q - mu_p_push).astype(np.float32, copy=False)

    # grad_μ = S_p'^-1 Δ
    grad_mu = np.matmul(sigma_p_push_inv, delta[..., None])[..., 0]

    # grad_Σ = 1/2 (S_p'^-1 - Σ_q^{-1})
    if sigma_q_inv is None:
        sigma_q_inv = safe_inv(sigma_q.astype(np.float32, copy=False))
    
    grad_sigma = 0.5 * (sigma_p_push_inv - sigma_q_inv)
    grad_sigma = 0.5 * (grad_sigma + np.swapaxes(grad_sigma, -1, -2))

    if mask is not None:
        m = (np.asarray(mask) > float(getattr(config, "support_tau", 0.0)))
        grad_mu    = grad_mu * m[..., None]
        grad_sigma = grad_sigma * m[..., None, None]

    return grad_mu.astype(np.float32, copy=False), grad_sigma.astype(np.float32, copy=False)


def grad_self_energy_model(
    mu_q, sigma_q, mu_p_push, sigma_p_push_inv, Phi_tilde, eps=1e-8, *,
    assume_sanitized=True, mask=None,
):
    """
    ∂ wrt (μ_p, Σ_p) of KL(q || p'), evaluated in p-fiber.
    Uses v = M Δ and v v^T to avoid an extra large einsum.
    """
    delta = (mu_q - mu_p_push).astype(np.float32, copy=False)

    # tmp = M Δ
    v = np.matmul(sigma_p_push_inv, delta[..., None])[..., 0]

    # grad_μ = - Φ̃^T v
    Phi_tilde_T = np.swapaxes(Phi_tilde, -1, -2)
    grad_mu = -np.matmul(Phi_tilde_T, v[..., None])[..., 0]

    # G = M - v v^T - M Σ_q M
    vvT = np.matmul(v[..., :, None], v[..., None, :])
    M_Sq = np.matmul(sigma_p_push_inv, sigma_q.astype(np.float32, copy=False))
    G = sigma_p_push_inv - vvT - np.matmul(M_Sq, sigma_p_push_inv)

    # grad_Σ = 1/2 Φ̃^T G Φ̃  (symmetrized)
    grad_sigma = 0.5 * np.matmul(np.matmul(Phi_tilde_T, G), Phi_tilde)
    grad_sigma = 0.5 * (grad_sigma + np.swapaxes(grad_sigma, -1, -2))

    if mask is not None:
        m = (np.asarray(mask) > float(getattr(config, "support_tau", 0.0)))
        grad_mu    = grad_mu * m[..., None]
        grad_sigma = grad_sigma * m[..., None, None]

    return grad_mu.astype(np.float32, copy=False), grad_sigma.astype(np.float32, copy=False)




def apply_natural_gradient_batch(
    ctx,
    mu_field,
    sigma_field,
    grad_mu_field,
    grad_sigma_field,
    mask=None,
    *,
    use_float64: bool = True,
    assume_sanitized: bool = True,
    grad_sigma_is_symmetric: bool = False,
    assert_finite: bool = False,
):
    """
    Vectorized natural gradient for Gaussian fields on an N-D periodic grid:
        δμ = -Σ ∇_μ L
        δΣ = -2 Σ sym(∇_Σ L) Σ

    Inputs:
      mu_field          : (*S, K)
      sigma_field       : (*S, K, K)   [SPD]
      grad_mu_field     : (*S, K)
      grad_sigma_field  : (*S, K, K)
      mask (optional)   : (*S,) bool or float weights

    Returns:
      delta_mu          : (*S, K)
      delta_sigma       : (*S, K, K)
    """
    import numpy as np
    from runtime_context import cfg_get

    # ---- config ----
    eps         = float(cfg_get(ctx, "eps", 1e-10))
    support_tau = float(cfg_get(ctx, "support_tau", 1e-6))
    dtype_work  = np.float64 if use_float64 else np.float32
    dtype_out   = np.float32 if not use_float64 else dtype_work

    # ---- infer spatial shape S, fiber dim K ----
    mu = np.asarray(mu_field)
    Sig = np.asarray(sigma_field)
    gmu = np.asarray(grad_mu_field)
    gSig = np.asarray(grad_sigma_field)

    if mu.ndim < 2 or Sig.ndim < 3:
        raise ValueError(f"Bad shapes: mu {mu.shape}, Sigma {Sig.shape}")

    S = mu.shape[:-1]               # *S
    K = mu.shape[-1]
    if Sig.shape[:-2] != S or Sig.shape[-2:] != (K, K):
        raise ValueError(f"sigma_field shape {Sig.shape} incompatible with mu_field {mu.shape}")

    # ---- flatten spatial for batched einsum ----
    N = int(np.prod(S, dtype=int))
    mu  = mu.astype(dtype_work, copy=False).reshape(N, K)
    Sig = Sig.astype(dtype_work, copy=False).reshape(N, K, K)
    gmu  = gmu.astype(dtype_work, copy=False).reshape(N, K)
    gSig = gSig.astype(dtype_work, copy=False).reshape(N, K, K)

    # ---- SPD sanitize Σ and symmetrize ∇Σ ----
    if not assume_sanitized:
        Sig = sanitize_sigma(Sig, eps=eps)  # must return symmetric SPD in dtype_work
    if not grad_sigma_is_symmetric:
        gSig = 0.5 * (gSig + np.swapaxes(gSig, -1, -2))

    # ---- natural steps ----
    # δμ = -Σ ∇_μ
    dmu = -np.einsum("nik,nk->ni", Sig, gmu, optimize=True)
    # δΣ = -2 Σ sym(∇_Σ) Σ
    tmp =  np.einsum("nij,njk->nik", Sig, gSig, optimize=True)
    dS  = -2.0 * np.einsum("nij,njk->nik", tmp, Sig, optimize=True)
    dS  = 0.5 * (dS + np.swapaxes(dS, -1, -2))  # symmetry guard

    # ---- mask / weights ----
    if mask is not None:
        m = np.asarray(mask)

        m_flat = m.reshape(N)
        if m.dtype == bool:
            active = m_flat
            wts = None
        else:
            wts = m_flat.astype(dtype_work, copy=False)
            active = wts > support_tau
            # soft weights
            dmu *= wts[:, None]
            dS  *= wts[:, None, None]

        # zero outside support
        if not np.all(active):
            ia = ~active
            dmu[ia] = 0.0
            dS[ia]  = 0.0


    if assert_finite:
        if not (np.isfinite(dmu).all() and np.isfinite(dS).all()):
            raise FloatingPointError("Nonfinite natural gradient (μ or Σ).")

    # ---- restore shapes / cast ----
    return (
        dmu.reshape(S + (K,)).astype(dtype_out, copy=False),
        dS.reshape(S + (K, K)).astype(dtype_out, copy=False),
    )







