# -*- coding: utf-8 -*-
"""
Created on Sat Sep 27 15:19:10 2025

@author: chris and christine

Case A:  KL( Φ_i[Ω^q_ij q_j] || p_i )
Case B:  KL( p_i || Φ_i Ω^q_ij[q_j] )

Case C: KL( Φ̃_i p_i  ||  Ω^q_ij q_j )
Case D: KL( Ω^q_ij  q_j || Φ̃_i  p_i )

Default Q:  KL( q_i || Ω^q_ij q_j )
Default P:  KL( p_i || Ω^p_ij p_j ) 

"""

import numpy as np
from runtime_context import cfg_get
from core.numerical_utils import sanitize_sigma, kl_gaussian, push_gaussian, safe_inv
from core.transport_cache import Omega, E_grid
import matplotlib.pyplot as plt


_TINY32 = np.finfo(np.float32).tiny
_LOG_TINY64 = np.log(np.finfo(np.float64).tiny)

def _to32_no_underflow(x):
    x64 = np.asarray(x, dtype=np.float64)
    with np.errstate(under='ignore'):
        x64 = np.where(np.abs(x64) < _TINY32, 0.0, x64)
        return x64.astype(np.float32, copy=False)


def get_edge_fields(ctx, which: str, i: int, j: int):
    """Return (beta_ij, KL1_ij) arrays stored by compute_edge_betas."""
    try:
        b = ctx._edge_beta[(which, i, j)]
        k = ctx._edge_kl1 [(which, i, j)]
    except KeyError as e:
        raise RuntimeError(f"get_edge_fields: missing {(which,i,j)}: {e}")
    return b, k

def _first_bad_idx(X: np.ndarray):
    bad = ~np.isfinite(X)
    if not bad.any():
        return None
    # drop last 2 matrix dims to get the voxel prefix index
    return tuple(np.argwhere(bad)[0][:-2])

def _assert_finite(name: str, X: np.ndarray, ctx_str: str):
    if not np.isfinite(X).all():
        idx = _first_bad_idx(X)
        raise RuntimeError(f"[{name}] non-finite at voxel={idx} {ctx_str}")



def _compose_R_and_assert(Phi_i: np.ndarray, Om: np.ndarray, *, i_id: int, j_id: int):
    import numpy as np
    # 1) shape sanity
    assert Phi_i.shape[-1] == Om.shape[-2], \
        f"shape mismatch: Phi_i{Phi_i.shape} @ Om{Om.shape} (i={i_id}, j={j_id})"

    # 2) compose
    R = np.einsum("...ik,...kj->...ij", Phi_i, Om, optimize=True)

    # 3) hard fail *before* any norms if non-finite
    _assert_finite("R", R, f"(i={i_id}, j={j_id})")

    # 4) batch opnorm for logging
    A = np.asarray(R, np.float64)
    *batch, m, n = A.shape
    Ar = A.reshape(-1, m, n)
    smax = []
    for k in range(Ar.shape[0]):
        s = np.linalg.svd(Ar[k], compute_uv=False)
        if s.size:
            smax.append(float(s[0]))
    op_R = float(np.mean(smax)) if smax else float("nan")
    return R, op_R



def _mean_opnorm_batch(A):
    # A: (*S, m, n)
    A = np.asarray(A, np.float64)
    *batch, m, n = A.shape
    A = A.reshape(-1, m, n)
    # guard empty
    if A.shape[0] == 0:
        return float("nan")
    smax = []
    for k in range(A.shape[0]):
        s = np.linalg.svd(A[k], compute_uv=False)
        if s.size:
            smax.append(float(s[0]))
    return float(np.mean(smax)) if smax else float("nan")





def compute_edge_betas(ctx, agents, *, which="q"):
    """
    Unified per-edge maps for a single fiber ('q' or 'p'):

        ctx._edge_kl1[(which,i,j)]  = KL1_ij  (alignment KL for updates)
        ctx._edge_kl2[(which,i,j)]  = KL2_ij  (β-basis KL; 0 off-overlap)
        ctx._edge_beta[(which,i,j)] = β_ij    (per-pixel attention; softmax over senders)

    β construction (NO external builders required):
      1) For each receiver i, compute per-sender KL2_ij(x) according to the basis:
         A: KL( Φ_i[Ω^q_ij q_j] || p_i )      (P_i frame)
         B: KL( p_i || Φ_i[Ω^q_ij q_j] )      (P_i frame)
         C: KL( Φ̃_i p_i || Ω^q_ij q_j )      (Q_i frame)
         D: KL( Ω^q_ij q_j || Φ̃_i p_i )      (Q_i frame)
         align_q: KL(q_i || Ω^q_ij q_j)       (Q_i frame)
         align_p: KL(p_i || Ω^p_ij p_j)       (P_i frame)
      2) Mask off-overlap pixels (logits=-inf → weight 0 there).
      3) Softmax over senders j for each pixel x: β_ij(x) = softmax_j( -KL2_ij(x) / κ ).

    Config keys used:
      beta_{which}        : selector in {'a','b','c','d','align_q','align_p'}
      beta_kappa_{which}  : κ (float)
      obs_beta_eps        : numeric epsilon for pushes/inverses
      support_tau         : overlap threshold for masks

    Notes:
      • KL2 stored in ctx._edge_kl2 is zeroed off-overlap (useful for gradient weighting).
      • Softmax is per-pixel and only over senders with overlap at that pixel.
    """
   
    if which not in ("q", "p"):
        raise ValueError("compute_edge_betas: which must be 'q' or 'p'")

    # ensure caches exist
    ctx._edge_kl1  = getattr(ctx, "_edge_kl1",  {})   # (which,i,j)->(*S,)
    ctx._edge_kl2  = getattr(ctx, "_edge_kl2",  {})   # (which,i,j)->(*S,)
    ctx._edge_beta = getattr(ctx, "_edge_beta", {})   # (which,i,j)->(*S,)

    # config
    kappa = float(cfg_get(ctx, f"beta_kappa_{which}", 1.0))
    eps   = float(cfg_get(ctx, "obs_beta_eps", 1e-12))
    tau   = float(cfg_get(ctx, "support_tau", 1e-6))
    basis = str(cfg_get(ctx, f"beta_{which}", "align_q" if which == "q" else "align_p")).lower()
    kappa = max(kappa, 1e-12)

    # convenience accessors
    def _mu(a):  return np.asarray(getattr(a, "mu_q_field" if which=="q" else "mu_p_field"),  np.float32)
    def _S(a):   return sanitize_sigma(np.asarray(getattr(a, "sigma_q_field" if which=="q" else "sigma_p_field"), np.float64))
    def _mask(a): 
        m = np.asarray(getattr(a, "mask"), np.float32)
        if m.ndim >= 1 and m.shape[-1] == 1: m = m[..., 0]
        return m

    # light wrappers for the “other” fiber (used by A–D)
    def _mu_q(a): return np.asarray(a.mu_q_field, np.float32)
    def _S_q(a):  return sanitize_sigma(np.asarray(a.sigma_q_field, np.float64))
    def _mu_p(a): return np.asarray(a.mu_p_field, np.float32)
    def _S_p(a):  return sanitize_sigma(np.asarray(a.sigma_p_field, np.float64))

    # KL choice for β-basis
    use_align_q = (basis == "align_q")
    use_align_p = (basis == "align_p")

    # iterate receivers
    ids = [int(getattr(a, "id", i)) for i, a in enumerate(agents)]
    for i_idx, ai in enumerate(agents):
        i_id = ids[i_idx]

        # authoritative spatial shape from active fiber
        Sshape = _mu(ai).shape[:-1]

        # per-receiver frames (cache-backed)
        Eqi = E_grid(ctx, ai, which="q")
        Epi = E_grid(ctx, ai, which="p")
        # Φ_i : Q_i→P_i,  Φ̃_i : P_i→Q_i
        Phi_i  = np.einsum("...ik,...jk->...ij", Epi, np.swapaxes(Eqi, -1, -2), optimize=True)
        
        # frames must be finite
        if not np.isfinite(Eqi).all() or not np.isfinite(Epi).all():
            idx = _first_bad_idx(Eqi) or _first_bad_idx(Epi)
            raise RuntimeError(
                f"[frames] non-finite E-frame at voxel={idx} for receiver i={getattr(ai,'id',-1)}; "
                f"isfinite(Eq)={np.isfinite(Eqi).all()} isfinite(Ep)={np.isfinite(Epi).all()}"
            )
        
        if not np.isfinite(Phi_i).all():
            idx = _first_bad_idx(Phi_i)
            ph_q = np.asarray(ai.phi)[idx] if ai.phi.ndim>=1 else ai.phi
            ph_p = np.asarray(ai.phi_model)[idx] if ai.phi_model.ndim>=1 else ai.phi_model
            raise RuntimeError(
                f"[Phi] non-finite Phi_i at voxel={idx} for i={getattr(ai,'id',-1)} "
                f"(||phi_q||={np.linalg.norm(ph_q):.3g}, ||phi_p||={np.linalg.norm(ph_p):.3g})"
            )
        
        Phit_i = np.einsum("...ik,...jk->...ij", Eqi, np.swapaxes(Epi, -1, -2), optimize=True)

        # receiver stats (both fibers available)
        mu_q_i, S_q_i = _mu_q(ai), _S_q(ai)
        mu_p_i, S_p_i = _mu_p(ai), _S_p(ai)

        # collect logits per sender for this receiver
        logits_list, mask_list, js = [], [], []
        kl2_store, kl1_store = {}, {}

        mi = _mask(ai)
        for j_idx, aj in enumerate(agents):
            if j_idx == i_idx:
                continue
            j_id = ids[j_idx]
            mj   = _mask(aj)

            # overlap mask
            joint = (mi > tau) & (mj > tau)
            try:
                joint = np.broadcast_to(joint, Sshape)
            except Exception as e:
                raise ValueError(f"mask broadcast failed for (i={i_id}, j={j_id})") from e
            if not np.any(joint):
                continue

            # ---------- KL1 (alignment) ----------
            if which == "q":
                Om = Omega(ctx, ai, aj, which="q")
                _assert_finite("Omega_q", Om, f"(i={i_id}, j={j_id})")
                _ = _compose_R_and_assert(Phi_i, Om, i_id=i_id, j_id=j_id)  # <-- assert R here
                mu_j_t, S_j_t = push_gaussian(_mu_q(aj), _S_q(aj), Om, eps=eps)[:2]
                KL1_ij = kl_gaussian(mu_q_i, S_q_i, mu_j_t, S_j_t)
            else:
                Om = Omega(ctx, ai, aj, which="p")
                _assert_finite("Omega_p", Om, f"(i={i_id}, j={j_id})")
                mu_j_t, S_j_t = push_gaussian(_mu_p(aj), _S_p(aj), Om, eps=eps)[:2]
                KL1_ij = kl_gaussian(mu_p_i, S_p_i, mu_j_t, S_j_t)

            kl1_store[(i_id, j_id)] = KL1_ij.astype(np.float32, copy=False)

            # ---------- KL2 (β-basis) ----------
            if use_align_q:
                KL2_ij = KL1_ij
            
            elif use_align_p:
                # compute “align_p” regardless of active which
                Om_p = Omega(ctx, ai, aj, which="p")
                mu_jp_t, S_jp_t = push_gaussian(_mu_p(aj), _S_p(aj), Om_p, eps=eps)[:2]
                KL2_ij = kl_gaussian(mu_p_i, S_p_i, mu_jp_t, S_jp_t)
            
            elif basis == "a":
                # KL( Φ_i[Ω q_j] || p_i ) in P_i
                Om_q = Omega(ctx, ai, aj, which="q")
                _assert_finite("Omega_q", Om_q, f"(i={i_id}, j={j_id})")
                R_ij, op_R = _compose_R_and_assert(Phi_i, Om_q, i_id=i_id, j_id=j_id)
                # optional: print once
                #print(f"[R-opnorm] i={i_id} j={j_id} ||R||₂≈{op_R:.3g}")

                mu_qj_t, S_qj_t = push_gaussian(_mu_q(aj), _S_q(aj), Om_q, eps=eps)[:2]
                mu_L, S_L = push_gaussian(mu_qj_t, S_qj_t, Phi_i, eps=eps)[:2]
                
                
                
                KL2_ij = kl_gaussian(mu_L, S_L, mu_p_i, S_p_i)
                
               
                
                
            elif basis == "b":
                # KL( p_i || Φ_i[Ω q_j] ) in P_i
                Om_q = Omega(ctx, ai, aj, which="q")
                _assert_finite("Omega_q", Om_q, f"(i={i_id}, j={j_id})")
                
                R_ij, op_R = _compose_R_and_assert(Phi_i, Om_q, i_id=i_id, j_id=j_id)
                # optional: print once
                #print(f"[R-opnorm] i={i_id} j={j_id} ||R||₂≈{op_R:.3g}")
                
                mu_qj_t, S_qj_t = push_gaussian(_mu_q(aj), _S_q(aj), Om_q, eps=eps)[:2]
                mu_L, S_L = push_gaussian(mu_qj_t, S_qj_t, Phi_i, eps=eps)[:2]
                KL2_ij = kl_gaussian(mu_p_i, S_p_i, mu_L, S_L)
            
            
            elif basis == "c":
                # KL( Φ̃_i p_i || Ω q_j ) in Q_i
                Om_q = Omega(ctx, ai, aj, which="q")
                _assert_finite("Omega_q", Om_q, f"(i={i_id}, j={j_id})")
                _ = _compose_R_and_assert(Phi_i, Om_q, i_id=i_id, j_id=j_id)  # optional for C/D
                mu_qj_t, S_qj_t = push_gaussian(_mu_q(aj), _S_q(aj), Om_q, eps=eps)[:2]
                mu_ph,  S_ph  = push_gaussian(mu_p_i, S_p_i, Phit_i, eps=eps)[:2]
                KL2_ij = kl_gaussian(mu_ph, S_ph, mu_qj_t, S_qj_t)
            
            
            elif basis == "d":
                # KL( Ω q_j || Φ̃_i p_i ) in Q_i
                Om_q = Omega(ctx, ai, aj, which="q")
                _assert_finite("Omega_q", Om_q, f"(i={i_id}, j={j_id})")
                _ = _compose_R_and_assert(Phi_i, Om_q, i_id=i_id, j_id=j_id)  # optional for C/D
                mu_qj_t, S_qj_t = push_gaussian(_mu_q(aj), _S_q(aj), Om_q, eps=eps)[:2]
                mu_ph,  S_ph  = push_gaussian(mu_p_i, S_p_i, Phit_i, eps=eps)[:2]
                KL2_ij = kl_gaussian(mu_qj_t, S_qj_t, mu_ph, S_ph)
            
            
            else:
                raise ValueError(f"unknown beta basis {basis!r}")

            KL2_ij = np.asarray(KL2_ij, np.float64)
            if KL2_ij.shape != Sshape:
                # allow trailing sums (e.g., batched K) though we expect scalars per pixel
                if KL2_ij.shape[:len(Sshape)] == Sshape and KL2_ij.ndim > len(Sshape):
                    KL2_ij = KL2_ij.reshape(Sshape + (-1,)).sum(axis=-1)
                else:
                    raise ValueError(f"KL2 dims {KL2_ij.shape} incompatible with {Sshape}")

            logit = np.where(joint, -KL2_ij / kappa, -np.inf)
            logits_list.append(logit)
            mask_list.append(joint)
            js.append(j_id)
            kl2_store[(which, i_id, j_id)] = np.where(joint, KL2_ij, 0.0).astype(np.float32, copy=False)

        if not js:
            continue

        L = np.stack(logits_list, axis=0)  # (J,*S)
        M = np.stack(mask_list,   axis=0)  # (J,*S)
        W = safe_softmax_over_senders(L, mask=M, tiny=1e-12)  # (J,*S)

      
        for s, j_id in enumerate(js):
            beta_ij = np.where(mask_list[s], W[s], 0.0).astype(np.float32, order="C")
            ctx._edge_beta[(which, i_id, j_id)] = beta_ij
            ctx._edge_kl2[(which, i_id, j_id)]  = kl2_store[(which, i_id, j_id)]
            ctx._edge_kl1[(which, i_id, j_id)]  = kl1_store[(i_id, j_id)].astype(np.float32, copy=False)



def safe_softmax_over_senders(logits, *, mask=None, tiny=1e-12):
    """
    Numerically safe softmax across senders (axis=0), for per-pixel weighting.

    Args
    ----
    logits : (J, *S) float array, may contain -inf where you want zero weight
    mask   : optional (J, *S) bool; True = valid sender at pixel. If None, uses np.isfinite(logits).
    tiny   : small positive epsilon to avoid division by zero

    Returns
    -------
    (J, *S) float32 with per-pixel sums over senders == 1 on overlap pixels, 0 elsewhere.
    """
    L = np.asarray(logits, dtype=np.float64)

    # boolean validity mask
    if mask is None:
        M = np.isfinite(L)
    else:
        M = np.asarray(mask, dtype=bool)

    # Replace invalid entries with -inf so they never contribute
    Lmasked = np.where(M, L, -np.inf)

    # Max over senders per pixel (shape (1,*S)); -inf when no sender is valid
    Lmax = np.max(Lmasked, axis=0, keepdims=True)

    # Pixels with at least one valid sender and finite Lmax
    valid_pix = np.isfinite(Lmax[0]) & np.any(M, axis=0)     # (*S,)
    valid_pix_b = np.expand_dims(valid_pix, axis=0)          # (1,*S)

    # Prepare output; default to -inf so exp→0 off valid pixels
    Lsafe = np.full_like(Lmasked, -np.inf, dtype=np.float64)

    # Safe, masked subtraction (no invalid warning)
    np.subtract(Lmasked, Lmax, out=Lsafe, where=np.broadcast_to(valid_pix_b, Lmasked.shape))

    # Clamp super-negative values to avoid exp underflow and suppress it locally anyway
    with np.errstate(under='ignore', over='ignore', invalid='ignore'):
        Lsafe = np.maximum(Lsafe, _LOG_TINY64)
        # Use where (not multiply) to avoid underflow in x * mask
        exps = np.where(M, np.exp(Lsafe), 0.0)               # (J,*S)

    # Normalize per pixel
    Z = np.sum(exps, axis=0, keepdims=True)                  # (1,*S)
    Z = np.maximum(Z, tiny)                                   # avoid /0 on empty pixels
    W = exps / Z

    # Clean any residual non-finites (shouldn’t happen) and cast safely
    W = np.where(np.isfinite(W), W, 0.0)
    return _to32_no_underflow(W)





def _collect_beta_tensor(ctx, agents, which="q"):
    """
    Returns:
      ids: [N] agent ids
      B:   (N, N, *S) tensor where B[i,j,...] = β_{ij}(...) (0 if missing)
    Assumes ctx._edge_beta[(which, i_id, j_id)] exists for populated edges.
    """
    ids = [int(getattr(a, "id", k)) for k, a in enumerate(agents)]
    id_to_idx = {aid: k for k, aid in enumerate(ids)}
    # discover spatial shape *S from any beta map present
    sample = None
    for (w,i_id,j_id), arr in getattr(ctx, "_edge_beta", {}).items():
        if w == which:
            sample = np.asarray(arr, np.float32); break
    if sample is None:
        raise RuntimeError(f"No _edge_beta entries for which={which!r}. Did you call compute_edge_betas?")
    Sshape = sample.shape
    N = len(ids)
    B = np.zeros((N, N) + Sshape, dtype=np.float32)
    for (w, i_id, j_id), arr in ctx._edge_beta.items():
        if w != which: 
            continue
        i = id_to_idx.get(i_id, None); j = id_to_idx.get(j_id, None)
        if i is None or j is None: 
            continue
        B[i, j] = np.asarray(arr, np.float32)
    return ids, B




def _pick_beta_voxel(B, how="max", quantile=0.5):
    """
    Pick a voxel index from B (N,N,*S) by aggregating over (i,j).
      how: 'max' | 'mean' | 'median' | 'quantile'
      quantile: used when how == 'quantile' (e.g., 0.5 for median)
    Returns:
      index: tuple for *S (e.g., (y,x) or (z,y,x))
    """
    # aggregate β over edge matrix dims (i,j) -> A with shape *S
    A = B.sum(axis=(0,1)) / max(B.shape[0] * B.shape[1], 1)

    if how == "max":
        flat = np.argmax(A.ravel())
    elif how == "mean":
        # choose voxel whose value is closest to the global mean
        target = float(A.mean())
        flat = int(np.abs(A.ravel() - target).argmin())
    elif how == "median":
        # choose voxel whose value is closest to the global median
        target = float(np.median(A))
        flat = int(np.abs(A.ravel() - target).argmin())
    elif how == "quantile":
        # pick closest voxel to the chosen quantile
        target = float(np.quantile(A, quantile))
        flat = int(np.abs(A.ravel() - target).argmin())
    else:
        raise ValueError("how must be 'max','mean','median','quantile'")

    return np.unravel_index(flat, A.shape)

def show_beta_heatmap_at(ctx, agents, which="q", how="median", quantile=0.5,
                             title=None, vmax=None, annotate=False, figsize=(6,5)):
    """
    Choose voxel by aggregate over (i,j) edges, then draw heatmap at that voxel.
      how: 'max'|'mean'|'median'|'quantile'
    """
    ids, B = _collect_beta_tensor(ctx, agents, which)
    index = _pick_beta_voxel(B, how=how, quantile=quantile)
    M = B[(slice(None), slice(None)) + index]  # (N,N)

    fig, ax = plt.subplots(1,1, figsize=figsize)
    im = ax.imshow(M, vmin=0.0, vmax=(vmax or float(M.max()) or 1.0))
    ax.set_xticks(range(len(ids))); ax.set_yticks(range(len(ids)))
    ax.set_xticklabels(ids, rotation=45, ha="right"); ax.set_yticklabels(ids)
    ax.set_xlabel("sender j"); ax.set_ylabel("receiver i")
    ax.set_title(title or f"β (which={which}) at {how} voxel {index}")
    fig.colorbar(im, ax=ax, fraction=0.046, pad=0.04, label="β weight")

    if annotate and M.size <= 20_000:
        for i in range(M.shape[0]):
            for j in range(M.shape[1]):
                ax.text(j, i, f"{M[i,j]:.2f}", ha="center", va="center", fontsize=8)

    plt.tight_layout()
    return fig, ax, (ids, M, index)

def show_beta_network_at(ctx, agents, which="q", how="median", quantile=0.5,
                             threshold=1e-3, scale=6.0, layout="circular", figsize=(6,6)):
    """
    Choose voxel by aggregate over (i,j), then draw network at that voxel.
    """
    import networkx as nx

    ids, B = _collect_beta_tensor(ctx, agents, which)
    index = _pick_beta_voxel(B, how=how, quantile=quantile)
    M = B[(slice(None), slice(None)) + index]  # (N,N)

    G = nx.DiGraph()
    for aid in ids: G.add_node(aid)
    for i, ri in enumerate(ids):
        for j, sj in enumerate(ids):
            w = float(M[i,j])
            if w > threshold:
                G.add_edge(sj, ri, weight=w)

    pos = nx.spring_layout(G, seed=0) if layout == "spring" else nx.circular_layout(G)
    widths = [scale * G[u][v]["weight"] for u,v in G.edges()]

    plt.figure(figsize=figsize)
    nx.draw_networkx_nodes(G, pos, node_size=600)
    nx.draw_networkx_labels(G, pos, font_size=10)
    nx.draw_networkx_edges(G, pos, arrows=True, width=widths, arrowstyle="-|>", arrowsize=16)
    plt.title(f"β network (which={which}) at {how} voxel {index}")
    plt.axis("off"); plt.tight_layout()
    return G, pos, (ids, M, index)


def summarize_beta(ctx, agents, which="q", reduce="mean"):
    """
    Aggregates β across space → (N,N) matrix.
      reduce in {'mean','max','sum'}
    """
    ids, B = _collect_beta_tensor(ctx, agents, which)
    if reduce == "mean":
        M = B.mean(axis=tuple(range(2, B.ndim)))
    elif reduce == "max":
        M = B.max(axis=tuple(range(2, B.ndim)))
    elif reduce == "sum":
        M = B.sum(axis=tuple(range(2, B.ndim)))
    else:
        raise ValueError("reduce must be 'mean','max','sum'")
    return ids, M







