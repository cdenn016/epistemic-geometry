# -*- coding: utf-8 -*-
"""
Gauge-aligned KL attention vs dot-product attention
Clean reporting + cleaner plots
"""

import torch
import torch.nn.functional as F
import numpy as np
from transformers import AutoModel, AutoTokenizer
import matplotlib.pyplot as plt

############################################
# Config
############################################

############################################
# Helpers
############################################
# -*- coding: utf-8 -*-
"""
Gauge-aligned KL attention vs dot-product attention
Flat vs gauge-transport β
"""



############################################
# Config
############################################

MODEL_NAME = "bert-base-uncased"
TEXT = (
    "The gauge field aligns attention between agents that agree about the world. "
    "When multiple observers exchange beliefs through a shared connection, their "
    "posteriors become consistent under parallel transport. This mechanism mirrors "
    "how transformer attention distributes context across tokens. "
    "In both cases, interactions are weighted by a soft measure of compatibility, "
    "which in our framework is the gauge-aligned KL divergence."
)

TAU = 1           # temperature for KL attention
DEVICE = "cpu"       # CPU safe
HEATMAP_LAYER = 2    # which layer/head to deep-inspect
HEATMAP_HEAD  = 0


############################################
# Utility fns
############################################

def cosine(u, v, eps=1e-9):
    un = np.linalg.norm(u) + eps
    vn = np.linalg.norm(v) + eps
    return float(np.dot(u, v) / (un * vn))

def get_qkv_for_layer(model, hidden_states, layer_idx, head_idx):
    """
    Extract Q_h, K_h, V_h for a given layer/head.
    Returns tensors of shape [seq_len, head_dim].
    """
    # In BERT: layer[k].attention.self.query is applied to hidden_states[k]
    h = hidden_states[layer_idx][0]  # [seq_len, hidden_dim]

    attn_self = model.encoder.layer[layer_idx].attention.self
    Q_all = attn_self.query(h)  # [seq_len, hidden_dim]
    K_all = attn_self.key(h)
    V_all = attn_self.value(h)

    num_heads = attn_self.num_attention_heads
    head_dim = attn_self.attention_head_size
    seq_len, hidden_dim = Q_all.shape

    def split_heads(x):
        # [seq_len, hidden_dim] -> [seq_len, num_heads, head_dim]
        return x.view(seq_len, num_heads, head_dim)

    Q = split_heads(Q_all)
    K = split_heads(K_all)
    V = split_heads(V_all)

    Qh = Q[:, head_idx, :]
    Kh = K[:, head_idx, :]
    Vh = V[:, head_idx, :]

    return Qh, Kh, Vh

def compute_alpha_beta_metrics(Qh, Kh, Vh, tau):
    """
    Compute α (dot-product attention) and flat β (no explicit Ω),
    then summary metrics.
    """
    seq_len, d = Qh.shape

    # α scores = Q_i K_j^T / sqrt(d)
    scores_dot = (Qh @ Kh.T) / np.sqrt(d)     # [seq, seq]
    alpha = F.softmax(scores_dot, dim=1)      # [seq, seq]

    # flat β scores = -||Q_i - K_j||^2 / tau
    Qi = Qh.unsqueeze(1)                      # [seq,1,d]
    Kj = Kh.unsqueeze(0)                      # [1,seq,d]
    diff = Qi - Kj                            # [seq,seq,d]
    sqdist = torch.sum(diff * diff, dim=-1)   # [seq,seq]
    scores_kl = -sqdist / tau
    beta = F.softmax(scores_kl, dim=1)        # [seq,seq]

    alpha_np = alpha.detach().cpu().numpy()
    beta_np  = beta.detach().cpu().numpy()
    V_np     = Vh.detach().cpu().numpy()

    per_token_corr = []
    per_token_match = []
    per_token_cos = []

    for i in range(seq_len):
        a = alpha_np[i, :]
        b = beta_np[i, :]

        # Pearson corr between rows
        a_mean = a.mean()
        b_mean = b.mean()
        num = np.sum((a - a_mean)*(b - b_mean))
        den = np.sqrt(np.sum((a - a_mean)**2) * np.sum((b - b_mean)**2) + 1e-12)
        corr = num / den
        per_token_corr.append(float(corr))

        # peak match?
        per_token_match.append(int(np.argmax(a) == np.argmax(b)))

        # message cosine
        z_alpha = a @ V_np
        z_beta  = b @ V_np
        per_token_cos.append(cosine(z_alpha, z_beta))

    avg_corr  = float(np.mean(per_token_corr))
    avg_match = float(np.mean(per_token_match))
    avg_cos   = float(np.mean(per_token_cos))

    return {
        "avg_corr": avg_corr,
        "avg_match": avg_match,
        "avg_cos": avg_cos,
        "per_token_corr": per_token_corr,
        "per_token_match": per_token_match,
        "per_token_cos": per_token_cos,
        "alpha_np": alpha_np,
        "beta_np": beta_np,
    }

def pretty_print_summary(results_table):
    """
    Fixed-width layer/head summary for appendix.
    """
    header = (
        f"{'layer':>5} | {'head':>4} | "
        f"{'corr(alpha,beta)':>17} | "
        f"{'argmax%':>8} | "
        f"{'cos(zα,zβ)':>9}"
    )
    bar = "-" * len(header)
    print("Summary over all layers / heads")
    print(bar)
    print(header)
    print(bar)
    for (layer_idx, head_idx, corr, match, cos_sim) in results_table:
        print(
            f"{layer_idx:5d} | {head_idx:4d} | "
            f"{corr:17.3f} | "
            f"{100*match:8.1f} | "
            f"{cos_sim:9.3f}"
        )
    print(bar)

def pretty_print_per_token(tokens, metrics):
    """
    Clean per-token listing.
    """
    print("Per-token breakdown:")
    print(f"{'idx':>3}  {'tok':>12}  {'corr':>8}  {'cos(z)':>8}  {'peak?':>6}")
    print("-" * 50)
    for i, tok in enumerate(tokens):
        disp_tok = tok
        if len(disp_tok) > 12:
            disp_tok = disp_tok[:11] + "…"

        c  = metrics["per_token_corr"][i]
        cz = metrics["per_token_cos"][i]
        pm = bool(metrics["per_token_match"][i])

        print(f"{i:3d}  {disp_tok:>12}  {c:8.3f}  {cz:8.3f}  {str(pm):>6}")
    print("-" * 50)

def plot_head_heatmaps(alpha_np, beta_np, tokens,
                       layer_idx, head_idx,
                       every_n_tick=4,
                       dpi=200):
    """
    Side-by-side α vs β heatmaps with rowwise normalization for readability.
    """
    def row_norm(x):
        xmax = x.max(axis=1, keepdims=True) + 1e-9
        return x / xmax

    alpha_disp = row_norm(alpha_np)
    beta_disp  = row_norm(beta_np)

    fig, axes = plt.subplots(1, 2, figsize=(10, 4), dpi=dpi)

    im0 = axes[0].imshow(alpha_disp, aspect='auto', vmin=0.0, vmax=1.0)
    axes[0].set_title(f"Dot-Product α\n(layer {layer_idx}, head {head_idx})", fontsize=10)
    axes[0].set_xlabel("Key token j", fontsize=9)
    axes[0].set_ylabel("Query token i", fontsize=9)
    plt.colorbar(im0, ax=axes[0], fraction=0.046, pad=0.04)

    im1 = axes[1].imshow(beta_disp, aspect='auto', vmin=0.0, vmax=1.0)
    axes[1].set_title(f"Gauge/KL β (flat)\n(layer {layer_idx}, head {head_idx})", fontsize=10)
    axes[1].set_xlabel("Key token j", fontsize=9)
    axes[1].set_ylabel("Query token i", fontsize=9)
    plt.colorbar(im1, ax=axes[1], fraction=0.046, pad=0.04)

    idxs = list(range(0, len(tokens), every_n_tick))
    ticklabels = [tokens[i] for i in idxs]

    for ax in axes:
        ax.set_xticks(idxs)
        ax.set_yticks(idxs)
        ax.set_xticklabels(ticklabels, rotation=90, fontsize=6)
        ax.set_yticklabels(ticklabels, fontsize=6)

    plt.tight_layout()
    plt.show()


############################################
# Gauge-frame extraction helpers
############################################

def orthonormal_frame_from_vector(vec):
    """
    Build an orthonormal frame R \in SO(d) whose first column aligns with vec.
    """
    v = vec.detach().cpu().numpy()
    d = v.shape[0]

    basis = []
    vn = np.linalg.norm(v)
    if vn < 1e-9:
        R = np.eye(d)
        return torch.tensor(R, dtype=torch.float32)

    basis.append(v / vn)

    rng = np.random.default_rng(0)
    while len(basis) < d:
        cand = rng.standard_normal(d)
        for b in basis:
            cand = cand - np.dot(cand, b) * b
        cn = np.linalg.norm(cand)
        if cn < 1e-9:
            continue
        basis.append(cand / cn)

    R = np.stack(basis, axis=1)  # d x d
    if np.linalg.det(R) < 0:
        R[:, -1] *= -1.0
    return torch.tensor(R, dtype=torch.float32)

def build_token_frames(Qh, Kh):
    """
    A_i from Q_i, B_i from K_i, per token.
    Returns:
      A: [seq, d, d], B: [seq, d, d]
    """
    seq_len, d = Qh.shape
    A_list = []
    B_list = []
    for i in range(seq_len):
        A_i = orthonormal_frame_from_vector(Qh[i])
        B_i = orthonormal_frame_from_vector(Kh[i])
        A_list.append(A_i.unsqueeze(0))
        B_list.append(B_i.unsqueeze(0))
    A = torch.cat(A_list, dim=0)
    B = torch.cat(B_list, dim=0)
    return A, B

def compute_beta_gauge(Qh, Kh, A, B, tau):
    """
    β_gauge using transported keys:
      Ω_ij = A_i B_j^T
      dist_ij^2 = || Q_i - Ω_ij K_j ||^2
    """
    seq_len, d = Qh.shape
    Q_np = Qh.detach().cpu().numpy()
    K_np = Kh.detach().cpu().numpy()
    A_np = A.detach().cpu().numpy()
    B_np = B.detach().cpu().numpy()

    dist_sq = np.zeros((seq_len, seq_len), dtype=np.float32)

    for i in range(seq_len):
        A_i = A_np[i]      # [d,d]
        Qi  = Q_np[i]      # [d]
        for j in range(seq_len):
            Omega_ij = A_i @ B_np[j].T   # [d,d]
            Kj_in_i = Omega_ij @ K_np[j]
            diff = Qi - Kj_in_i
            dist_sq[i, j] = np.dot(diff, diff)

    # row-wise softmax over -dist^2/tau
    scores = -dist_sq / tau
    scores = scores - scores.max(axis=1, keepdims=True)
    exp_scores = np.exp(scores)
    beta_gauge = exp_scores / exp_scores.sum(axis=1, keepdims=True)
    return beta_gauge

def fit_global_rotation(Qh, Kh):
    """
    Fit a single linear map R (dxd) that maps K -> Q in least squares:
        minimize || Q - K R^T ||_F^2
    We'll solve R = argmin_R ||Q - K R^T||, i.e. R^T = K^+ Q.
    """
    Q_np = Qh.detach().cpu().numpy()  # [seq,d]
    K_np = Kh.detach().cpu().numpy()  # [seq,d]

    # Solve K_np @ R^T ≈ Q_np  -> R^T ≈ pinv(K_np) @ Q_np
    K_pinv = np.linalg.pinv(K_np)     # [d,seq]
    R_T = K_pinv @ Q_np               # [d,d]
    R = R_T.T                         # [d,d]
    return R

def compute_beta_globalR(Qh, Kh, R, tau):
    """
    β_R with a *single* learned global map R:
       dist_ij^2 = || Q_i - R K_j ||^2
    """
    Q_np = Qh.detach().cpu().numpy()  # [seq,d]
    K_np = Kh.detach().cpu().numpy()  # [seq,d]
    seq_len, d = Q_np.shape

    dist_sq = np.zeros((seq_len, seq_len), dtype=np.float32)
    for i in range(seq_len):
        Qi = Q_np[i]  # [d]
        for j in range(seq_len):
            Kj_rot = R @ K_np[j]  # [d]
            diff = Qi - Kj_rot
            dist_sq[i, j] = np.dot(diff, diff)

    scores = -dist_sq / tau
    scores = scores - scores.max(axis=1, keepdims=True)
    exp_scores = np.exp(scores)
    beta_R = exp_scores / exp_scores.sum(axis=1, keepdims=True)
    return beta_R

def analyze_key_salience(Kh, alpha_np, tokens, layer_idx, head_idx, dpi=200):
    """
    Measure 'global salience' of each key j in a head.

    For each key j:
      - key_norm_sq[j] = ||K_j||^2
      - win_count[j]   = # of query tokens i for which j is argmax_j alpha[i,j]

    We'll plot win_count vs key_norm_sq, and print a tiny table.
    """
    # Kh: [seq_len, head_dim] (torch)
    # alpha_np: [seq_len, seq_len] (numpy), softmaxed over j

    seq_len, d = Kh.shape

    # ||K_j||^2 for each token j
    key_norm_sq = torch.sum(Kh * Kh, dim=-1).detach().cpu().numpy()  # [seq_len]

    # argmax_j alpha[i,j] for each query i
    winners = np.argmax(alpha_np, axis=1)  # [seq_len] each entry is a j index

    # count how often each key j wins
    win_count = np.bincount(winners, minlength=seq_len)  # [seq_len]

    # normalized popularity (fraction of queries that peak at j)
    win_frac = win_count / np.sum(win_count)

    # ----- Print a little table -----
    print("Per-key salience analysis (layer {}, head {})".format(layer_idx, head_idx))
    print("{:>3}  {:>12}  {:>10}  {:>10}".format("j","token","||K_j||^2","win_frac"))
    print("-"*45)
    for j in range(seq_len):
        tok = tokens[j]
        tok_disp = tok if len(tok) <= 12 else tok[:11]+"…"
        print("{:3d}  {:>12}  {:10.4f}  {:10.4f}".format(
            j, tok_disp, key_norm_sq[j], win_frac[j]
        ))
    print("-"*45)

    # ----- Scatter plot -----
    plt.figure(figsize=(4,3), dpi=dpi)
    plt.scatter(key_norm_sq, win_frac)
    plt.xlabel(r"$\|K_j\|^2$ (key norm squared)")
    plt.ylabel("attention peak frequency")
    plt.title(f"Per-key salience\nlayer {layer_idx}, head {head_idx}")
    # annotate a few interesting tokens (top 3 by win_frac)
    top_idx = np.argsort(-win_frac)[:3]
    for j in top_idx:
        plt.annotate(tokens[j], (key_norm_sq[j], win_frac[j]),
                     fontsize=6, xytext=(3,3), textcoords="offset points")
    plt.tight_layout()
    plt.show()

    return key_norm_sq, win_frac


def compare_alpha_beta(alpha_np, beta_np, Vh):
    """
    Compute corr / argmax / cos(z) for arbitrary beta_np.
    """
    V_np = Vh.detach().cpu().numpy()
    seq_len = alpha_np.shape[0]

    per_token_corr = []
    per_token_match = []
    per_token_cos = []

    for i in range(seq_len):
        a = alpha_np[i, :]
        b = beta_np[i, :]

        a_mean = a.mean()
        b_mean = b.mean()
        num = np.sum((a - a_mean)*(b - b_mean))
        den = np.sqrt(np.sum((a - a_mean)**2) * np.sum((b - b_mean)**2) + 1e-12)
        corr = num / den
        per_token_corr.append(float(corr))

        per_token_match.append(int(np.argmax(a) == np.argmax(b)))

        z_alpha = a @ V_np
        z_beta  = b @ V_np
        un = np.linalg.norm(z_alpha) + 1e-9
        vn = np.linalg.norm(z_beta) + 1e-9
        per_token_cos.append(float(np.dot(z_alpha, z_beta) / (un * vn)))

    avg_corr  = float(np.mean(per_token_corr))
    avg_match = float(np.mean(per_token_match))
    avg_cos   = float(np.mean(per_token_cos))

    return {
        "avg_corr": avg_corr,
        "avg_match": avg_match,
        "avg_cos": avg_cos,
        "per_token_corr": per_token_corr,
        "per_token_match": per_token_match,
        "per_token_cos": per_token_cos,
    }


############################################
# 1. Run model forward
############################################

tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)
model = AutoModel.from_pretrained(
    MODEL_NAME,
    output_attentions=False,
    output_hidden_states=True
)
model.eval().to(DEVICE)

inputs = tokenizer(TEXT, return_tensors="pt").to(DEVICE)

with torch.no_grad():
    out = model(**inputs)

hidden_states = out.hidden_states
tokens = tokenizer.convert_ids_to_tokens(inputs["input_ids"][0])
num_layers = len(model.encoder.layer)
num_heads  = model.encoder.layer[0].attention.self.num_attention_heads


############################################
# 2. Sweep all layer/head (flat β only)
############################################

results_table = []
for layer_idx in range(num_layers):
    for head_idx in range(num_heads):
        Qh, Kh, Vh = get_qkv_for_layer(model, hidden_states, layer_idx, head_idx)
        metrics_flat = compute_alpha_beta_metrics(Qh, Kh, Vh, TAU)
        results_table.append((
            layer_idx,
            head_idx,
            metrics_flat["avg_corr"],
            metrics_flat["avg_match"],
            metrics_flat["avg_cos"]
        ))

pretty_print_summary(results_table)


############################################
# 3. Detailed look at one head
############################################

layer_idx = HEATMAP_LAYER
head_idx  = HEATMAP_HEAD

Qh, Kh, Vh = get_qkv_for_layer(model, hidden_states, layer_idx, head_idx)
metrics_flat = compute_alpha_beta_metrics(Qh, Kh, Vh, TAU)

print("\nDetailed analysis for layer {}, head {}".format(layer_idx, head_idx))
print("Sequence length:", len(tokens))
print("FLAT β (no gauge rotation):")
print("  Avg corr(alpha,beta_flat): {:.3f}".format(metrics_flat["avg_corr"]))
print("  Argmax match %          : {:.1f}%".format(100*metrics_flat["avg_match"]))
print("  Avg cos(zα,zβ_flat)     : {:.3f}".format(metrics_flat["avg_cos"]))
print()

pretty_print_per_token(tokens, metrics_flat)

# Gauge frames:
A, B = build_token_frames(Qh, Kh)
R = fit_global_rotation(Qh, Kh)
beta_np_R = compute_beta_globalR(Qh, Kh, R, TAU)
metrics_R = compare_alpha_beta(metrics_flat["alpha_np"], beta_np_R, Vh)

print("Global-R β results (single fitted R K→Q):")
print("  Avg corr(alpha,beta_R): {:.3f}".format(metrics_R["avg_corr"]))
print("  Argmax match %        : {:.1f}%".format(100*metrics_R["avg_match"]))
print("  Avg cos(zα,zβ_R)      : {:.3f}".format(metrics_R["avg_cos"]))


############################################
# 4. Heatmaps for flat β (you can also add gauge β if you want)
############################################

plot_head_heatmaps(
    metrics_flat["alpha_np"],
    metrics_flat["beta_np"],        # flat β
    tokens,
    layer_idx,
    head_idx,
    every_n_tick=4,
    dpi=200
)

# 6. Per-key salience vs key norm^2 (this tests the bias term prediction)

key_norm_sq, win_frac = analyze_key_salience(
    Kh,                    # keys [seq_len, head_dim]
    metrics_flat["alpha_np"],   # we use the model's actual alpha here
    tokens,
    layer_idx,
    head_idx,
    dpi=200
)


# If you also want to visualize gauge β instead of flat β:
# plot_head_heatmaps(
#     metrics_flat["alpha_np"],
#     beta_np_gauge,                # gauge β
#     tokens,
#     layer_idx,
#     head_idx,
#     every_n_tick=4,
#     dpi=200
# )
