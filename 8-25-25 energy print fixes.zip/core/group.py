# -*- coding: utf-8 -*-
"""
Pure SO(3) math utilities — single place for group/algebra helpers used across the
codebase. No caches, no runtime context. Import here from transport/omega.py,
updates, energies, coarsegrain, etc.

Provided primitives (batch-friendly):
  - hat / vee / skew
  - axis-angle helpers: norm, retract to principal ball
  - exp_lie_algebra_irrep: exp(Σ φ^a G_a) for any K×K irrep (stable near 0)
  - log_irrep: project log(R) back to algebra coeffs (…→ 3)
  - project_to_algebra: Frobenius-orthogonal projection using Gram correction
  - BCH on matrices: bch, safe_bch_exact
  - d_exp_phi_exact: exact left-trivialized derivative of exp at φ in any irrep
  - Left Jacobian J(φ) and its inverse for SO(3) (hat-space, 3×3)

Notes
-----
* Keep ALL SO(3) math here. Other modules should import from this file rather
  than duplicating implementations.
* Functions avoid touching config/ctx. Callers control clipping/logging.
* Shapes follow numpy broadcasting semantics.
"""
from __future__ import annotations

from typing import Optional, Tuple, Iterable
import warnings
import numpy as np
from scipy.linalg import expm, logm

__all__ = [
    "hat","vee","skew",
    "axis_angle_norm","retract_so3_principal",
    "gram_matrix","project_to_algebra",
    "exp_lie_algebra_irrep","log_irrep",
    "bch","safe_bch_exact",
    "d_exp_phi_exact",
    "left_jacobian","left_jacobian_inv",
    "dexp_apply_left_right",
    "retract_phi_principal"  # <-- add this
]


# -----------------------------------------------------------------------------
# Basic algebra helpers
# -----------------------------------------------------------------------------

def skew(v: np.ndarray) -> np.ndarray:
    """Alias for hat()."""
    return hat(v)


def hat(v: np.ndarray) -> np.ndarray:
    """Map ℝ³ → so(3) (batch OK).
    v: (..., 3) → (..., 3, 3)
    """
    v = np.asarray(v, dtype=np.float64)
    *batch, d = v.shape
    assert d == 3, "hat: expected (...,3)"
    x, y, z = v[..., 0], v[..., 1], v[..., 2]
    O = np.zeros(batch + (3, 3), dtype=v.dtype)
    O[..., 0, 1] = -z; O[..., 0, 2] =  y
    O[..., 1, 0] =  z; O[..., 1, 2] = -x
    O[..., 2, 0] = -y; O[..., 2, 1] =  x
    return O


def vee(W: np.ndarray) -> np.ndarray:
    """Map so(3) → ℝ³ (batch OK).
    W: (..., 3, 3) → (..., 3)
    """
    W = np.asarray(W, dtype=np.float64)
    assert W.shape[-2:] == (3, 3), "vee: expected (...,3,3)"
    return np.stack([W[..., 2, 1], W[..., 0, 2], W[..., 1, 0]], axis=-1)


def axis_angle_norm(phi: np.ndarray) -> np.ndarray:
    """‖φ‖ with keepdims over last axis."""
    phi = np.asarray(phi)
    return np.linalg.norm(phi, axis=-1, keepdims=True)


# -----------------------------------------------------------------------------
# Principal-ball retraction (axis–angle)
# -----------------------------------------------------------------------------

def retract_so3_principal(phi: np.ndarray, *, margin: float = 1e-3) -> np.ndarray:
    """Project axis–angle φ onto the SO(3) principal ball (‖φ‖ ≤ π − margin).

    Stable handling of wrap-around: first wrap to [0, 2π), reflect > π back,
    then clamp to (π - margin). Works batched.
    """
    v = np.asarray(phi, np.float32)
    v = np.nan_to_num(v, nan=0.0, posinf=0.0, neginf=0.0)
    eps = 1e-12
    twopi = np.float32(2.0 * np.pi)
    t = axis_angle_norm(v)                      # (...,1)
    t = np.nan_to_num(t, nan=0.0, posinf=0.0, neginf=0.0)
    u = v / np.maximum(t, eps)
    t_mod = np.mod(t, twopi)                    # [0, 2π)
    over = (t_mod > np.pi)
    t_ref = np.where(over, (twopi - t_mod), t_mod)
    u_ref = np.where(over, -u, u)
    t_clamped = np.minimum(t_ref, (np.pi - float(margin)))
    return (u_ref * t_clamped).astype(np.float32)

# public alias used everywhere else
def retract_phi_principal(phi, *, margin=None):
    if margin is None:
        try:
            import core.config as config
            margin = float(getattr(config, "phi_principal_margin", 1e-4))
        except Exception:
            margin = 1e-4
    return retract_so3_principal(phi, margin=margin)

# -----------------------------------------------------------------------------
# Irrep-agnostic projection and (exp, log) on SO(3)
# -----------------------------------------------------------------------------

def gram_matrix(generators: np.ndarray) -> np.ndarray:
    """Compute the 3×3 Gram matrix M_ab = 0.5·tr(G_a^T G_b) for an irrep basis.
    generators: (3,K,K) real antisymmetric basis
    returns: (3,3)
    """
    G = np.asarray(generators, np.float64)
    assert G.shape[0] == 3 and G.shape[-1] == G.shape[-2], "generators must be (3,K,K)"
    G_flat = G.reshape(3, -1)
    M = 0.5 * (G_flat @ G_flat.T)
    # tiny regularization in case of near-singularity
    M += 1e-12 * np.eye(3)
    return M


def project_to_algebra(L: np.ndarray, generators: np.ndarray, M_inv: Optional[np.ndarray] = None) -> np.ndarray:
    """Project a matrix (or field of matrices) onto the algebra basis using Frobenius inner product.

    L: (...,K,K) real matrix (e.g., log(R))
    generators: (3,K,K)
    M_inv: optional precomputed inverse Gram matrix
    returns: (...,3) coefficients c with 0.5·tr(G_a^T L) → b_a and c = M^{-1} b
    """
    G = np.asarray(generators, np.float64)
    L = np.asarray(L, np.float64)
    if M_inv is None:
        M_inv = np.linalg.inv(gram_matrix(G))
    # ensure skew part (so(3)) numerically
    L = 0.5 * (L - np.swapaxes(L, -1, -2))
    # b_a = 0.5 tr(G_a^T L)
    b = 0.5 * np.einsum("aij,...ij->...a", G, L, optimize=True)
    # c = M^{-1} b
    c = np.einsum("ab,...b->...a", M_inv, b, optimize=True)
    return c.astype(np.float64)


def exp_lie_algebra_irrep(
    v_batch: np.ndarray,
    generators: np.ndarray,
    *,
    threshold: float = 1e-3,
    max_norm: Optional[float] = None,
    parallelize_expm: bool = False,
    n_jobs: int = -1,
) -> np.ndarray:
    """Compute exp(Σ v^a G_a) in an arbitrary K×K irrep for a batch of v.

    v_batch: (...,3) axis–angle coefficients in the chosen basis
    generators: (3,K,K) antisymmetric basis
    Returns: (...,K,K)
    """
    v = np.asarray(v_batch, np.float64)
    batch_shape = v.shape[:-1]           # <-- tuple (safe for + (K,K))
    d = v.shape[-1]
    assert d == 3, "exp_lie_algebra_irrep expects (...,3)"
    G = np.asarray(generators, np.float64)
    K = int(G.shape[-1])

    # Optional global norm clipping (keep stable far from 0)
    if max_norm is not None:
        n = np.linalg.norm(v.reshape(-1, d), axis=1)
        scale = np.minimum(1.0, max_norm / (n + 1e-16)).astype(v.dtype)
        v = (v.reshape(-1, d) * scale[:, None]).reshape(batch_shape + (d,))  # <-- use batch_shape

    # Build algebra element Xi = v·G (square K×K)
    Xi = np.einsum("...a,aij->...ij", v, G, optimize=True)
    # enforce skew (SO(3)) numerically
    X = 0.5 * (Xi - np.swapaxes(Xi, -1, -2))

    # Small-angle 4th-order Taylor near identity; else SciPy expm per-slice
    flat = X.reshape(-1, K, K)
    out = np.empty_like(flat)

    norms = np.linalg.norm(v.reshape(-1, d), axis=1)
    mask_small = norms < float(threshold)
    
    if np.any(mask_small):
        Xs = flat[mask_small]
        I = np.eye(K, dtype=X.dtype)[None]
        X2 = Xs @ Xs
        X3 = X2 @ Xs
        X4 = X2 @ X2
        out[mask_small] = I + Xs + 0.5*X2 + (1.0/6.0)*X3 + (1.0/24.0)*X4
    if np.any(~mask_small):
        Xh = flat[~mask_small]
        if parallelize_expm and Xh.shape[0] >= 64:
            from joblib import Parallel, delayed, parallel_backend
            with parallel_backend("threading"):
                res = Parallel(n_jobs=n_jobs, batch_size=8)(delayed(expm)(X_i) for X_i in Xh) 
        else:
            res = [expm(X_i) for X_i in Xh]
        out[~mask_small] = np.stack(res, axis=0)

    out = np.nan_to_num(out, nan=0.0, posinf=1e6, neginf=-1e6)
    return out.reshape(batch_shape + (K, K)).astype(np.float32)


def log_irrep(R: np.ndarray, generators: np.ndarray, *, force_skew: bool = True) -> np.ndarray:
    """Compute algebra coefficients φ (…→3) such that exp(Σ φ^a G_a) ≈ R.

    R: (...,K,K); generators: (3,K,K)
    Returns: (...,3)
    """
    R = np.asarray(R, np.float64)
    G = np.asarray(generators, np.float64)
    *batch, K, K2 = R.shape
    assert K == K2, "log_irrep expects square matrices"
    M_inv = np.linalg.inv(gram_matrix(G))
    flat = R.reshape(-1, K, K)
    coeffs = np.empty((flat.shape[0], 3), dtype=np.float64)
    for i, Ri in enumerate(flat):
        L = logm(Ri)
        L = np.real_if_close(L, tol=1e-9)
        if force_skew:
            L = 0.5 * (L - L.T)
        coeffs[i] = project_to_algebra(L, G, M_inv=M_inv)
    return coeffs.reshape(batch + (3,)).astype(np.float32)


# -----------------------------------------------------------------------------
# BCH on matrices (generic, but kept here for SO(3) consumers)
# -----------------------------------------------------------------------------

def bch(A: np.ndarray, B: np.ndarray, *, max_norm: float = 10.0, inf_tol: float = 1e6, verbose: bool = False) -> np.ndarray:
    """4th-order Baker–Campbell–Hausdorff approximation: log(exp(A) exp(B))."""
    A = np.array(A, dtype=np.float64, copy=True); B = np.array(B, dtype=np.float64, copy=True)
    for name, M in (("A", A), ("B", B)):
        n = np.linalg.norm(M, ord=np.inf)
        if not np.isfinite(n) or n > max_norm:
            M *= max_norm / (n + 1e-10)
            if verbose:
                print(f"[bch] clip {name}: {n:.2e} → {max_norm}")
    AB   = A @ B - B @ A
    AAB  = A @ AB - AB @ A
    BAB  = B @ AB - AB @ B
    BAAB = B @ AAB - AAB @ B
    out = A + B + 0.5 * AB + (1.0/12.0) * AAB - (1.0/12.0) * BAB - (1.0/24.0) * BAAB
    out = np.nan_to_num(out, nan=0.0, posinf=max_norm, neginf=-max_norm)
    n_out = np.linalg.norm(out, ord="fro")
    if not np.isfinite(n_out) or n_out > inf_tol:
        warnings.warn(f"[bch] Large/invalid result ‖out‖={n_out:.2e}", RuntimeWarning)
    return out


def safe_bch_exact(A: np.ndarray, B: np.ndarray, *, max_norm: float = 5.0, verbose: bool = False) -> np.ndarray:
    """BCH with input clipping; always returns a real matrix."""
    A = np.array(A, dtype=np.float64, copy=True); B = np.array(B, dtype=np.float64, copy=True)
    for name, M in (("A", A), ("B", B)):
        n = np.linalg.norm(M, ord=np.inf)
        if n > max_norm:
            M *= max_norm / (n + 1e-10)
            if verbose:
                warnings.warn(f"[safe_bch] clipped {name}: {n:.2e} → {max_norm}", RuntimeWarning)
    C = bch(A, B, max_norm=max_norm, verbose=verbose)
    return np.nan_to_num(C, nan=0.0, posinf=max_norm, neginf=-max_norm)


# -----------------------------------------------------------------------------
# Exact derivative of exp at φ (irrep-aware)
# -----------------------------------------------------------------------------

def d_exp_phi_exact(phi_vec: np.ndarray, generators: np.ndarray, *, exp_phi_all: Optional[np.ndarray] = None, eps: float = 1e-12) -> Iterable[np.ndarray]:
    """∂/∂φ^a exp(Σ φ^b G_b) in any K×K irrep (returns a list of 3 arrays).

    phi_vec: (...,3)
    generators: (3,K,K)
    exp_phi_all: optional precomputed exp(Σ φ G) with shape (...,K,K)

    Returns: [dE_dφ0, dE_dφ1, dE_dφ2], each with shape (...,K,K)
    """
    # NOTE: lowercase φ (gauge field), NOT the rectangular bundle morphism Φ
    phi_vec = np.asarray(phi_vec, dtype=np.float32)
    G = np.asarray(generators, dtype=np.float32)
    *shape, d = phi_vec.shape
    assert d == 3, "d_exp_phi_exact assumes SO(3) (d=3)."
    K = int(G.shape[-1])
    N = int(np.prod(shape)) if shape else 1

    phi_flat = phi_vec.reshape(N, 3)
    # Ξ = Σ_a φ^a G_a  (use Xi to avoid confusion with bundle morphism Φ)
    Xi = np.einsum("na,aij->nij", phi_flat, G, optimize=True)

    theta = np.linalg.norm(phi_flat, axis=1)  # (N,)
    c1 = np.empty_like(theta, dtype=np.float32)
    c2 = np.empty_like(theta, dtype=np.float32)
    small = theta < 1e-4
    if np.any(small):
        t = theta[small]; t2 = t * t; t4 = t2 * t2
        c1[small] = 0.5 - t2/24.0 + t4/720.0
        c2[small] = 1.0/6.0 - t2/120.0 + t4/5040.0
    big = ~small
    if np.any(big):
        tb = theta[big]
        c1[big] = (1.0 - np.cos(tb)) / np.maximum(tb*tb, eps)
        c2[big] = (tb - np.sin(tb)) / np.maximum(tb*tb*tb, eps)

    if exp_phi_all is None:
        E = exp_lie_algebra_irrep(phi_flat, G, threshold=0.0)  # (N,K,K)
    else:
        E = np.asarray(exp_phi_all, dtype=np.float32)
        if E.size != N * K * K:
            raise ValueError(f"exp_phi_all size {E.size} != N*K*K={N*K*K}")
        E = E.reshape(N, K, K)

    # Build commutators ad_Φ^k(G_a)
    XiN = Xi[None, ...]                              # (1,N,K,K)
    # [Φ, G_a]
    ad1 = np.einsum("nijk,akl->naij", Xi, G) - np.einsum("aik,nkjl->naij", G, XiN)
    # [Φ, [Φ, G_a]]
    ad2 = (
        np.einsum("nijk,nakl->naij", Xi, ad1) -
        np.einsum("naik,nkjl->naij", ad1, XiN)
    )

    # d exp(Φ) / dφ^a = E · (G_a + c1 ad1_a + c2 ad2_a)
    base = G[None, ...] + c1[:, None, None, None] * ad1 + c2[:, None, None, None] * ad2
    dE = np.einsum("nij,naij->naij", E, base, optimize=True)   # (N,3,K,K)

    # reshape back
    dE = dE.reshape(shape + (3, K, K))
    # return python list along a=0,1,2 for caller convenience
    return [dE[..., i, :, :].astype(np.float32, copy=False) for i in range(3)]


# -----------------------------------------------------------------------------
# Left Jacobian and its inverse on so(3) vectors (3×3)
# -----------------------------------------------------------------------------

def _series_left_jacobian_terms(theta: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
    """Return (A, B) where
        J(φ) = I - A·[φ]_× + B·[φ]_×²  for left Jacobian,
    with series-safe evaluation for small θ.
    """
    t = np.asarray(theta, np.float64)
    A = np.empty_like(t)
    B = np.empty_like(t)
    small = t < 1e-6
    if np.any(small):
        ts = t[small]; ts2 = ts*ts; ts4 = ts2*ts2
        A[small] = 0.5 - ts2/24.0 + ts4/720.0
        B[small] = 1.0/6.0 - ts2/120.0 + ts4/5040.0
    big = ~small
    if np.any(big):
        tb = t[big]
        A[big] = (1.0 - np.cos(tb)) / (tb*tb)
        B[big] = (tb - np.sin(tb)) / (tb*tb*tb)
    return A, B


def left_jacobian(phi: np.ndarray) -> np.ndarray:
    """Left Jacobian J(φ) ∈ ℝ^{3×3} for SO(3), acting on algebra vectors.
    Formula: J = I - A·[φ]_× + B·[φ]_×², where A,B depend on θ=‖φ‖.
    """
    phi = np.asarray(phi, np.float64)
    *batch, d = phi.shape
    assert d == 3
    th = axis_angle_norm(phi)[..., 0]
    A, B = _series_left_jacobian_terms(th)
    W = hat(phi)
    I = np.eye(3, dtype=np.float64)
    J = I - A[..., None, None] * W + B[..., None, None] * (W @ W)
    return J.astype(np.float64)


def left_jacobian_inv(phi: np.ndarray) -> np.ndarray:
    """Inverse of left Jacobian J(φ) for SO(3), numerically stable near 0.
    Closed form: J^{-1} = I + 0.5·[φ]_× + C·[φ]_×²,
    where C = (1/θ²)·(1 - (1/2)·θ·cot(θ/2)).
    """
    phi = np.asarray(phi, np.float64)
    *batch, d = phi.shape
    assert d == 3
    th = axis_angle_norm(phi)[..., 0]
    W = hat(phi)
    I = np.eye(3, dtype=np.float64)

    # C(θ) with safe series near 0
    C = np.empty_like(th)
    small = th < 1e-6
    if np.any(small):
        ts = th[small]; ts2 = ts*ts; ts4 = ts2*ts2
        # series of C around 0: 1/12 + θ²/720 + O(θ⁴)
        C[small] = 1.0/12.0 + ts2/720.0 + ts4/30240.0
    big = ~small
    if np.any(big):
        tb = th[big]
        C[big] = (1.0/(tb*tb)) * (1.0 - 0.5*tb/np.tan(0.5*tb))

    Jinv = I + 0.5 * W + C[..., None, None] * (W @ W)
    return Jinv.astype(np.float64)


def dexp_apply_left_right(phi_left: np.ndarray, G_left: np.ndarray,
                           M: np.ndarray,
                           phi_right: np.ndarray, G_right: np.ndarray,
                           *, exp_left: Optional[np.ndarray] = None,
                           exp_right: Optional[np.ndarray] = None) -> Tuple[list[np.ndarray], list[np.ndarray]]:
    """Convenience for bundle morphism contexts: d/dφ̃ and d/dφ of
    E_L(φ̃) · M · E_R(φ), where E_L = exp(Σ φ̃^a G_left[a]) ∈ ℝ^{Kp×Kp},
    E_R = exp(Σ φ^a  G_right[a]) ∈ ℝ^{Kq×Kq}, and M is rectangular (Kp×Kq).

    Returns
    -------
    (dLeft, dRight)
        dLeft[a]  = (dE_L/dφ̃^a) · M · E_R
        dRight[a] =  E_L · M · (dE_R/dφ^a)
    """
    # Left side
    dEL = d_exp_phi_exact(phi_left, G_left, exp_phi_all=exp_left)   # list of 3 (…Kp,Kp)
    ER  = exp_lie_algebra_irrep(phi_right, G_right) if exp_right is None else exp_right

    # Right side
    dER = d_exp_phi_exact(phi_right, G_right, exp_phi_all=exp_right)
    EL  = exp_lie_algebra_irrep(phi_left, G_left) if exp_left is None else exp_left

    # Contract per-a
    dL = [d @ M @ ER for d in dEL]
    dR = [EL @ M @ d for d in dER]
    return dL, dR
