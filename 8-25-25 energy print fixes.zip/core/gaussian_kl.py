# -*- coding: utf-8 -*-
"""
Canonical Gaussian KL utilities (cache-agnostic).

This module consolidates all KL-related math in one place and provides thin
wrappers for legacy call-sites. Anything that needs Ω/Λ/Θ or Φ should live in a
transport-facing module and call into these pure functions.

Exports
-------
- kl_gaussian         : KL(N(μ1,Σ1) || N(μ2,Σ2)) (batched, robust)
- kl_divergence       : Back-compat wrapper (mask support)
- kl_field            : Per-pixel KL map with either explicit mask or auto support
- robust_reduce_kl    : Robust scalar reduction (cap/trim/area-norm)

Notes
-----
* No ctx/cache access here. For transported KLs, push the second Gaussian with
  your cached map (Ω/Λ/Φ) first, then call kl_gaussian.
* SPD sanitization + symmetry guards are centralized here.
"""

from __future__ import annotations
from typing import Optional, Tuple
import numpy as np

# Expect these helpers in your codebase
from core.numerical_utils import sanitize_sigma, safe_inv, safe_logdet

__all__ = [
    "kl_gaussian",
    "kl_divergence",
    "kl_field",
    "robust_reduce_kl",
]

# ----------------------------------------------------------------------------
# Core KL for Gaussians (batched)
# ----------------------------------------------------------------------------

def _as_float(x):
    return np.asarray(x, dtype=float)


def _expand_diag(diag_or_full: np.ndarray, *, assume_stddev: bool) -> np.ndarray:
    """Convert (...,K) or (...,K,K) to full SPD (...,K,K)."""
    S = np.asarray(diag_or_full)
    if S.ndim >= 2 and S.shape[-2] == S.shape[-1]:
        return S
    if S.ndim == 1:
        S = S[None]
    diag = S
    if assume_stddev:
        diag = diag * diag
    K = int(diag.shape[-1])
    I = np.eye(K, dtype=diag.dtype)
    return np.einsum("...k,ij->...ij", diag, I, optimize=True)


def kl_gaussian(
    mu1: np.ndarray,
    S1: np.ndarray,
    mu2: np.ndarray,
    S2: np.ndarray,
    *,
    eps: float = 1e-6,
    allow_diag: bool = True,
    diag_is_stddev: bool = True,
    sanitize: bool = True,
) -> np.ndarray:
    """KL(N(μ1,Σ1) || N(μ2,Σ2)) in closed form; broadcast-safe.

    Accepts diagonal covariances if allow_diag=True (interprets as stddevs if
    diag_is_stddev=True), otherwise requires full SPD.
    """
    mu1 = _as_float(mu1)
    mu2 = _as_float(mu2)
    S1 = np.asarray(S1)
    S2 = np.asarray(S2)

    if allow_diag:
        S1 = _expand_diag(S1, assume_stddev=diag_is_stddev)
        S2 = _expand_diag(S2, assume_stddev=diag_is_stddev)

    if sanitize:
        S1 = sanitize_sigma(0.5 * (S1 + np.swapaxes(S1, -1, -2)), eps=eps)
        S2 = sanitize_sigma(0.5 * (S2 + np.swapaxes(S2, -1, -2)), eps=eps)

    K = int(mu1.shape[-1])
    S2_inv = safe_inv(S2, eps=eps)

    # tr(S2^{-1} S1)
    term_trace = np.einsum("...ij,...ji->...", S2_inv, S1, optimize=True)
    # (μ2-μ1)^T S2^{-1} (μ2-μ1)
    dmu = mu2 - mu1
    term_quad = np.einsum("...i,...ij,...j->...", dmu, S2_inv, dmu, optimize=True)

    # log|Σ2|/|Σ1|
    sign1, logdet1 = np.linalg.slogdet(S1)
    sign2, logdet2 = np.linalg.slogdet(S2)
    # If sanitize_sigma succeeded, signs should be +1; fall back to safe_logdet
    bad = (sign1 < 0) | (sign2 < 0)
    if np.any(bad):
        logdet1 = safe_logdet(S1, eps=eps)
        logdet2 = safe_logdet(S2, eps=eps)
    logdet_ratio = logdet2 - logdet1

    kl = 0.5 * (term_trace + term_quad - K + logdet_ratio)
    return np.clip(np.nan_to_num(kl, nan=0.0, posinf=1e6, neginf=0.0), 0.0, 1e6)


# Back-compat wrapper (keeps "mask" arg and N×K convention)

def kl_divergence(mu1, sigma1, mu2, sigma2, mask: Optional[np.ndarray] = None, eps: float = 1e-6):
    """Legacy name. Returns KL per batch; optional elementwise mask multiply."""
    vals = kl_gaussian(mu1, sigma1, mu2, sigma2, eps=eps)
    if mask is not None:
        m = np.asarray(mask)
        if m.ndim == 2 and m.shape[-1] == 1:
            m = np.squeeze(m, axis=-1)
        vals = vals * m
    if np.any(~np.isfinite(vals)):
        raise ValueError("[kl_divergence] NaN/Inf in output")
    return vals


# ----------------------------------------------------------------------------
# Field-level helpers
# ----------------------------------------------------------------------------

def _auto_support(mask: np.ndarray,
                  morphism: Optional[np.ndarray] = None,
                  *, thresh: float = 1e-3,
                  dist_frac: float = 0.01,
                  morph_pct: float = 5.0) -> np.ndarray:
    """Heuristic interior support selector (no config knobs).
    Mirrors previous behavior but avoids raising on missing SciPy.
    """
    H, W = np.asarray(mask).shape[:2]
    if H == 0 or W == 0:
        return np.zeros((H, W), dtype=bool)

    mvals = np.asarray(mask, dtype=np.float32)
    finite = np.isfinite(mvals)
    if not np.any(finite):
        return np.zeros((H, W), dtype=bool)

    vals = mvals[finite]
    vals_nz = vals[vals > thresh]
    if vals_nz.size == 0:
        return np.zeros((H, W), dtype=bool)

    try:
        high_mass_frac = float((vals_nz >= 0.5).mean())
        spread = float(vals_nz.std())
        if high_mass_frac > 0.5 or spread < 0.1:
            tau = float(np.percentile(vals_nz, 60))
        else:
            tau = float(np.percentile(vals_nz, 70))
    except Exception:
        tau = max(thresh, float(np.median(vals_nz)))
    tau = float(np.clip(tau, thresh, 0.95))

    m = (mvals > tau)
    if not m.any():
        return np.zeros((H, W), dtype=bool)

    # interior via EDT if available, else fallback erosions
    try:
        from scipy.ndimage import distance_transform_edt
        dist = distance_transform_edt(m)
        maxd = int(dist[m].max()) if dist[m].size else 0
        d_cut = max(1, int(round(dist_frac * maxd))) if maxd > 0 else 0
        core = (dist >= d_cut)
    except Exception:
        try:
            from scipy.ndimage import binary_erosion
            core = binary_erosion(m, structure=np.ones((3, 3), bool))
        except Exception:
            from numpy.lib.stride_tricks import sliding_window_view as swv
            pad = np.pad(m.astype(np.uint8), 1, mode="edge")
            core = (swv(pad, (3, 3)).min(axis=(-2, -1)) == 1)

    if morphism is None:
        return core & m

    M = np.asarray(morphism, dtype=np.float32).reshape(H, W, -1)
    phi_norm = np.linalg.norm(np.nan_to_num(M, nan=0.0, posinf=0.0, neginf=0.0), axis=-1)
    norms_on_support = phi_norm[m]
    n_cut = float(np.nanpercentile(norms_on_support, morph_pct)) if norms_on_support.size else 0.0
    strong = (phi_norm >= n_cut)
    return core & strong & m


def kl_field(
    mu1: np.ndarray, S1: np.ndarray,
    mu2: np.ndarray, S2: np.ndarray,
    *,
    mask: Optional[np.ndarray] = None,
    morphism: Optional[np.ndarray] = None,
    support: str = "mask",  # "mask" | "auto"
    eps: float = 1e-8,
) -> np.ndarray:
    """Per-pixel KL map: D_KL(N1 || N2) over a chosen support.

    If support="auto", an interior mask is computed from `mask` (and optionally
    gated by `morphism` magnitude) using _auto_support.
    """
    H, W = np.asarray(mu1).shape[:2]
    out = np.zeros((H, W), dtype=np.float32)

    if support == "auto":
        if mask is None:
            return out
        supp = _auto_support(mask, morphism)
    elif support == "mask":
        supp = np.asarray(mask, bool) if mask is not None else np.ones((H, W), bool)
    else:
        raise ValueError("support must be 'mask' or 'auto'")

    if not np.any(supp):
        return out

    idx = np.where(supp)
    vals = kl_gaussian(mu1[idx], S1[idx], mu2[idx], S2[idx], eps=eps)
    out[idx] = vals.astype(np.float32, copy=False)
    return out


# ----------------------------------------------------------------------------
# Robust scalar reduction
# ----------------------------------------------------------------------------

def robust_reduce_kl(
    kl_field: np.ndarray,
    mask: np.ndarray,
    *,
    cap: Optional[float] = 100.0,
    trim_hi: Optional[float] = 0.995,
    area_norm: bool = True,
    nan_policy: str = "zero",  # {"zero","drop"}
) -> Tuple[float, dict]:
    """Robust scalar from a per-pixel KL field (with stats)."""
    m = np.asarray(mask, bool)
    if kl_field is None or not np.any(m):
        return 0.0, {"n": 0}

    vals = np.asarray(kl_field, dtype=np.float64)[m]

    vals = np.nan_to_num(vals,
                         nan=(0.0 if nan_policy == "zero" else np.nan),
                         posinf=(cap if cap is not None else np.finfo(np.float64).max),
                         neginf=0.0)

    if cap is not None:
        vals = np.minimum(vals, cap)

    if trim_hi is not None and vals.size:
        try:
            hi = np.quantile(vals, trim_hi)
            vals = vals[vals <= hi]
        except Exception:
            pass

    n = max(len(vals), 1)
    total = float(np.sum(vals))
    if area_norm:
        area = float(np.count_nonzero(m))
        total = total / max(area, 1.0)

    stats = {
        "n": n,
        "mean": float(np.mean(vals)) if n else 0.0,
        "median": float(np.median(vals)) if n else 0.0,
        "p99": float(np.quantile(vals, 0.99)) if n > 1 else 0.0,
        "max": float(np.max(vals)) if n else 0.0,
    }
    return total, stats
