# -*- coding: utf-8 -*-
"""
omega.py — Lie-group exponentials, transports, BCH helpers, and curvature ops.
CacheHub-ready: uses ctx.cache namespaces 'exp' and 'omega' when provided.

Author: c&c
"""
from __future__ import annotations

from typing import Tuple, Dict

import warnings
import numpy as np
from scipy.linalg import expm

import core.config as config
from core.numerical_utils import sanitize_sigma, safe_omega_inv
# omega.py (top of file)

# NEW: import pure math from core
from core.group import (
    exp_lie_algebra_irrep as _exp_irrep_core,
    d_exp_phi_exact as _dexp_core,
    bch as _bch_core,
    safe_bch_exact as _safe_bch_core,
)



# Public API
__all__ = [
    "exp_lie_algebra_irrep",
    "get_E_grid_from_phi",
    "exp_grid_cached",
    "compute_inter_omega_fieldwise",
    "batch_apply_omega",
    "bch",
    "safe_bch_exact",
    "adaptive_expm",
    "adaptive_expm_batch",
    "d_exp_phi_exact",
    "d_exp_phi_tilde_exact",
    "compute_gauge_potential",
    "compute_field_strength",
    "compute_field_strength_general",
    "compute_curvature_gradient_analytical",
    "compute_intra_omega",
]


# =============================================================================
#                               Cache helpers
# =============================================================================

def _arr_key(a):
    a = np.asarray(a)
    # (data pointer, shape, dtype) — stable and cheap
    return (int(a.__array_interface__['data'][0]), a.shape, a.dtype.str)


def exp_grid_cached(ctx, phi, generators, *, group="so3", sign=+1, clip=None, thr=1e-3):
    """
    Cached wrapper for exp(±φ) grids. Uses ctx.cache.ns('exp') if available.
    """
    hub = getattr(ctx, "cache", None) if ctx is not None else None
    ns = hub.ns("exp") if hub is not None else None
    key = None
    if ns is not None:
        key = (_arr_key(phi), _arr_key(generators), str(group), int(sign),
               None if clip is None else float(clip), float(thr))
        hit = ns.get(key)
        if hit is not None:
            return hit

    E = get_E_grid_from_phi(phi, generators, group_name=group, sign=sign, clip=clip, threshold=thr)

    if ns is not None:
        ns[key] = E
    return E


def omega_field_cached(ctx, phi_i, phi_j, generators, *, group="so3", invert_j=True):
    """
    Cached wrapper for Ω_{ij} using ctx.cache.ns('omega').
    """
    hub = getattr(ctx, "cache", None) if ctx is not None else None
    ns = hub.ns("omega") if hub is not None else None
    key = None
    if ns is not None:
        key = (_arr_key(phi_i), _arr_key(phi_j), _arr_key(generators), str(group), bool(invert_j))
        hit = ns.get(key)
        if hit is not None:
            return hit

    Om = compute_inter_omega_fieldwise(phi_i, phi_j, generators, ctx=ctx, group_name=group, invert_j=invert_j)

    if ns is not None:
        ns[key] = Om
    return Om


# =============================================================================
#                          Exponentials / Transports
# =============================================================================

def get_E_grid_from_phi(
    phi: np.ndarray,
    generators: np.ndarray,
    group_name: str = "so3",
    sign: int = +1,
    clip: float | None = None,
    threshold: float = 1e-3,
) -> np.ndarray:
    """
    Compute exp(±φ) per pixel.

    phi         : (H,W,d) or (N,d)
    generators  : (d,K,K)
    returns     : (H,W,K,K) or (N,K,K)
    """
    v = np.asarray(phi, dtype=np.float32)
    if sign < 0:
        v = -v

    if v.ndim == 2:  # (N,d)
        N, d = v.shape
        E = exp_lie_algebra_irrep(
            v.reshape(N, d),
            generators,
            group_name=group_name,
            max_norm=clip,
            threshold=threshold,
            parallelize_expm=False,
        )
        return E.astype(np.float32, copy=False)

    if v.ndim == 3:  # (H,W,d)
        H, W, d = v.shape
        E = exp_lie_algebra_irrep(
            v.reshape(-1, d),
            generators,
            group_name=group_name,
            max_norm=clip,
            threshold=threshold,
            parallelize_expm=False,
        )
        K = E.shape[-1]
        return E.reshape(H, W, K, K).astype(np.float32, copy=False)

    raise ValueError(f"get_E_grid_from_phi: expected (H,W,d) or (N,d), got {phi.shape}")


def compute_inter_omega_fieldwise(
    phi_i: np.ndarray,
    phi_j: np.ndarray,
    generators: np.ndarray,
    *,
    ctx=None,
    group_name: str = "so3",
    invert_j: bool = False,
    clip_norm=None,
    threshold: float = 1e-3,
) -> np.ndarray:
    """
    Ω_ij(x) = exp(φ_i(x)) · exp(−φ_j(x))   (default)
            or exp(φ_i(x)) · inv(exp(φ_j(x))) with invert_j=True using solves.

    Supports grid (H,W,d) and flat (N,d). Uses CacheHub for exp grids when ctx provided.
    """
    phi_i = np.asarray(phi_i, dtype=np.float32)
    phi_j = np.asarray(phi_j, dtype=np.float32)
    if phi_i.shape != phi_j.shape:
        raise ValueError(f"[Ω] phi_i shape {phi_i.shape} != phi_j shape {phi_j.shape}")

    # Cache key for Ω
    hub = getattr(ctx, "cache", None) if ctx is not None else None
    ns = hub.ns("omega") if hub is not None else None
    key = None
    if ns is not None:
        key = (_arr_key(phi_i), _arr_key(phi_j), _arr_key(generators),
               str(group_name), bool(invert_j),
               "grid" if phi_i.ndim == 3 else "flat")
        hit = ns.get(key)
        if hit is not None:
            return hit

    # Grid path
    if phi_i.ndim == 3:
        Ei = exp_grid_cached(ctx, phi_i, generators, group=group_name, sign=+1)
        if invert_j:
            Ej = exp_grid_cached(ctx, phi_j, generators, group=group_name, sign=+1)
            K = Ej.shape[-1]
            N = Ei.shape[0] * Ei.shape[1]
            EjT = Ej.reshape(N, K, K).transpose(0, 2, 1)
            EiT = Ei.reshape(N, K, K).transpose(0, 2, 1)
            X_T = np.linalg.solve(EjT, EiT)      # solves are more stable than forming inv(Ej)
            Omega = X_T.transpose(0, 2, 1).reshape(Ei.shape)
        else:
            Emj = exp_grid_cached(ctx, phi_j, generators, group=group_name, sign=-1)
            Omega = np.einsum("...ik,...kj->...ij", Ei, Emj, optimize=True)
        Omega = Omega.astype(np.float32, copy=False)
        if ns is not None:
            ns[key] = Omega
        return Omega

    # Flat path
    d = phi_i.shape[-1]
    Ei = exp_lie_algebra_irrep(phi_i.reshape(-1, d), generators,
                               group_name=group_name, max_norm=clip_norm,
                               threshold=threshold, parallelize_expm=False)

    if invert_j:
        Ej = exp_lie_algebra_irrep(phi_j.reshape(-1, d), generators,
                                   group_name=group_name, max_norm=clip_norm,
                                   threshold=threshold, parallelize_expm=False)
        EjT = np.transpose(Ej, (0, 2, 1))
        EiT = np.transpose(Ei, (0, 2, 1))
        Omega_flat_T = np.linalg.solve(EjT, EiT)
        Omega_flat = np.transpose(Omega_flat_T, (0, 2, 1))
    else:
        Emj = exp_lie_algebra_irrep((-phi_j).reshape(-1, d), generators,
                                    group_name=group_name, max_norm=clip_norm,
                                    threshold=threshold, parallelize_expm=False)
        Omega_flat = np.einsum("nik,nkj->nij", Ei, Emj, optimize=True)

    Omega = Omega_flat.reshape(*phi_i.shape[:-1], Ei.shape[-2], Ei.shape[-1]).astype(np.float32, copy=False)
    if ns is not None:
        ns[key] = Omega
    return Omega


# =============================================================================
#                  Algebra exponentials — Taylor / expm hybrid
# =============================================================================

def adaptive_expm(G, clip_norm=None, max_norm=None, threshold=1e-3):
    """
    Robust expm(G) with optional norm clipping and 4th-order Taylor near identity.
    """
    if not np.all(np.isfinite(G)):
        raise ValueError("[adaptive_expm] Input contains NaN/Inf")
    nG = np.linalg.norm(G, ord=np.inf) + 1e-16
    if max_norm is not None and nG > max_norm:
        G = G * (max_norm / nG)
        nG = max_norm
    elif clip_norm is not None and nG > clip_norm:
        G = G * (clip_norm / nG)
        nG = clip_norm
    if nG < threshold:
        I = np.eye(G.shape[0], dtype=G.dtype)
        G2, G3, G4 = G @ G, None, None
        G3 = G2 @ G
        G4 = G2 @ G2
        out = I + G + 0.5 * G2 + (1/6) * G3 + (1/24) * G4
    else:
        out = expm(G)
    return np.nan_to_num(out, nan=0.0, posinf=1e6, neginf=-1e6)


def adaptive_expm_batch(G_batch, n_jobs=-1, clip_norm=None, max_norm=None, threshold=1e-3, parallel_threshold=64):
    """
    Batched expm with optional threading for large batches.
    """
    G_batch = np.asarray(G_batch)
    N = G_batch.shape[0]
    if N == 0:
        return G_batch
    if N < parallel_threshold:
        return np.stack([adaptive_expm(G_batch[i], clip_norm, max_norm, threshold) for i in range(N)], axis=0)
    from joblib import Parallel, delayed, parallel_backend
    with parallel_backend("threading"):
        results = Parallel(n_jobs=n_jobs, batch_size=8)(
            delayed(adaptive_expm)(G_batch[i], clip_norm, max_norm, threshold) for i in range(N)
        )
    return np.stack(results, axis=0)

def QQexp_lie_algebra_irrep(
    v_batch,
    generators,
    use_expm=True,
    threshold=1e-3,
    max_norm=None,
    group_name="so3",
    n_jobs=-1,
    verbose=False,
    parallelize_expm=False,
):
    """
    exp( Σ_a v^a T_a ) over a batch.
    v_batch    : (..., d)
    generators : (d,K,K)
    returns    : (..., K, K)
    """
    *batch, d = v_batch.shape
    v_flat = np.asarray(v_batch, dtype=np.float32).reshape(-1, d)
    N = v_flat.shape[0]
    _, K, _ = generators.shape
    dtype = np.result_type(v_batch, generators)

    clip_norm = max_norm if max_norm is not None else getattr(config, "phi_exp_clip", np.pi)
    ord_type = getattr(config, "gradient_clip_norm_type", 2)
    eps = 1e-16

    norms = np.linalg.norm(v_flat, axis=1, ord=ord_type)
    scale = np.minimum(1.0, clip_norm / (norms + eps))
    v_scaled = v_flat * scale[:, None]
    norms_scaled = np.linalg.norm(v_scaled, axis=1, ord=ord_type)

    if verbose and np.any(scale < 1.0):
        print(f"[Ω] Clipped {np.sum(scale < 1)} / {N} φ to ≤ {clip_norm}")

    G = np.einsum("nd,dij->nij", v_scaled, generators)
    if group_name == "so3":
        G = 0.5 * (G - np.transpose(G, (0, 2, 1)))
    elif group_name == "su2":
        G = 0.5 * (G - np.transpose(G, (0, 2, 1)).conj())

    out = np.empty((N, K, K), dtype=dtype)
    mask_small = norms_scaled < threshold
    if np.any(mask_small):
        Gs = G[mask_small]
        I = np.eye(K, dtype=dtype)[None]
        G2 = Gs @ Gs
        G3 = G2 @ Gs
        G4 = G2 @ G2
        out[mask_small] = I + Gs + 0.5 * G2 + (1/6) * G3 + (1/24) * G4

    if np.any(~mask_small):
        Gh = G[~mask_small]
        if parallelize_expm:
            from joblib import Parallel, delayed, parallel_backend
            with parallel_backend("threading"):
                res = Parallel(n_jobs=n_jobs)(delayed(adaptive_expm)(Gi, max_norm=clip_norm, threshold=0.0) for Gi in Gh)
        else:
            res = [adaptive_expm(Gi, max_norm=clip_norm, threshold=0.0) for Gi in Gh]
        out[~mask_small] = np.stack(res, axis=0)

    out = np.nan_to_num(out, nan=0.0, posinf=1e6, neginf=-1e6)
    return out.reshape(*batch, K, K)



# keep public names stable
def exp_lie_algebra_irrep(v_batch, generators, *, group_name="so3", max_norm=None, threshold=1e-3, parallelize_expm=False, n_jobs=-1):
    # transport-layer knobs stay here; math delegated to core
    return _exp_irrep_core(v_batch, generators, max_norm=max_norm, threshold=threshold,
                           parallelize_expm=parallelize_expm, n_jobs=n_jobs)

def QQd_exp_phi_exact(phi_vec, generators, *, exp_phi_all=None, eps=1e-12):
    return _dexp_core(phi_vec, generators, exp_phi_all=exp_phi_all, eps=eps)

def bch(A, B, max_norm=10.0, inf_tol=1e6, verbose=False):
    return _bch_core(A, B, max_norm=max_norm, inf_tol=inf_tol, verbose=verbose)

def safe_bch_exact(A, B, max_norm=5.0, verbose=False):
    return _safe_bch_core(A, B, max_norm=max_norm, verbose=verbose)




# =============================================================================
#                       Exact dexp derivatives for SO(3)
# =============================================================================
def d_exp_phi_exact(phi_vec, generators, exp_phi_all=None, eps=1e-12):
    """
    ∂/∂φ^a e^{φ}: SO(3) left-trivialized derivative in any K×K irrep.
    Returns a list of length 3 with arrays shaped (..., K, K) for a=0,1,2.
    """
    
    phi_vec = np.asarray(phi_vec, dtype=np.float32)
    generators = np.asarray(generators, dtype=np.float32)
    *shape, d = phi_vec.shape
    assert d == 3, "d_exp_phi_exact assumes SO(3) (d=3)."
    K = int(generators.shape[-1])
    N = int(np.prod(shape)) if shape else 1

    phi_flat = phi_vec.reshape(N, 3)
    # Φ = Σ_a φ^a G_a
    Phi = np.einsum("na,aij->nij", phi_flat, generators, optimize=True)

    theta = np.linalg.norm(phi_flat, axis=1)  # (N,)
    c1 = np.empty_like(theta, dtype=np.float32)
    c2 = np.empty_like(theta, dtype=np.float32)
    small = theta < 1e-4
    if np.any(small):
        t = theta[small]; t2 = t * t; t4 = t2 * t2
        c1[small] = 0.5 - t2/24.0 + t4/720.0
        c2[small] = 1.0/6.0 - t2/120.0 + t4/5040.0
    big = ~small
    if np.any(big):
        tb = theta[big]
        c1[big] = (1.0 - np.cos(tb)) / np.maximum(tb*tb, eps)
        c2[big] = (tb - np.sin(tb)) / np.maximum(tb*tb*tb, eps)

    if exp_phi_all is None:
        E = exp_lie_algebra_irrep(phi_flat, generators, group_name="so3", parallelize_expm=False)  # (N,K,K)
    else:
        E = np.asarray(exp_phi_all, dtype=np.float32)
        if E.size != N * K * K:
            raise ValueError(f"exp_phi_all size {E.size} != N*K*K={N*K*K}")
        E = E.reshape(N, K, K)

    # Build commutators ad_Φ^k(G_a)
    PhiN = Phi[None, ...]               # (1,N,K,K)
    G_A  = generators[:, None, :, :]    # (3,1,K,K)
    comm1 = (PhiN @ G_A) - (G_A @ PhiN)                      # (3,N,K,K)
    comm2 = (PhiN @ comm1) - (comm1 @ PhiN)                  # (3,N,K,K)
    Q = G_A - c1[None, :, None, None] * comm1 + c2[None, :, None, None] * comm2  # (3,N,K,K)

    # ∂e^Φ/∂φ^a = E · Q_a
    d_exp = np.einsum("nij,anjk->anik", E, Q, optimize=True)  # (3,N,K,K)
    d_exp = d_exp.reshape(3, *shape, K, K).astype(np.float32, copy=False)
    return [d_exp[i] for i in range(3)]


def d_exp_phi_tilde_exact(phi_tilde_vec, generators, exp_phi_tilde_all=None, eps=1e-12):
    """
    ∂/∂φ̃^a e^{φ̃}: SO(3) companion of d_exp_phi_exact.
    Returns a list of length 3 with arrays shaped (..., K, K).
    """
   

    phi_tilde_vec = np.asarray(phi_tilde_vec, dtype=np.float32)
    generators = np.asarray(generators, dtype=np.float32)
    *shape, d = phi_tilde_vec.shape
    assert d == 3, "d_exp_phi_tilde_exact assumes SO(3) (d=3)."
    K = int(generators.shape[-1])
    N = int(np.prod(shape)) if shape else 1

    phi_flat = phi_tilde_vec.reshape(N, 3)
    Phi = np.einsum("na,aij->nij", phi_flat, generators, optimize=True)

    theta = np.linalg.norm(phi_flat, axis=1)
    c1 = np.empty_like(theta, dtype=np.float32)
    c2 = np.empty_like(theta, dtype=np.float32)
    small = theta < 1e-4
    if np.any(small):
        t = theta[small]; t2 = t*t; t4 = t2*t2
        c1[small] = 0.5 - t2/24.0 + t4/720.0
        c2[small] = 1.0/6.0 - t2/120.0 + t4/5040.0
    big = ~small
    if np.any(big):
        tb = theta[big]
        c1[big] = (1.0 - np.cos(tb)) / np.maximum(tb*tb, eps)
        c2[big] = (tb - np.sin(tb)) / np.maximum(tb*tb*tb, eps)

    if exp_phi_tilde_all is None:
        E = exp_lie_algebra_irrep(phi_flat, generators, group_name="so3", parallelize_expm=False)
    else:
        E = np.asarray(exp_phi_tilde_all, dtype=np.float32)
        if E.size != N * K * K:
            raise ValueError(f"exp_phi_tilde_all size {E.size} != N*K*K={N*K*K}")
        E = E.reshape(N, K, K)

    PhiN = Phi[None, ...]
    G_A  = generators[:, None, :, :]
    comm1 = (PhiN @ G_A) - (G_A @ PhiN)
    comm2 = (PhiN @ comm1) - (comm1 @ PhiN)
    Q = G_A - c1[None, :, None, None] * comm1 + c2[None, :, None, None] * comm2

    d_exp = np.einsum("nij,anjk->anik", E, Q, optimize=True)
    d_exp = d_exp.reshape(3, *shape, K, K).astype(np.float32, copy=False)
    return [d_exp[i] for i in range(3)]


# =============================================================================
#                         Apply Ω to Gaussian fields
# =============================================================================

def batch_apply_omega(mu_batch, sigma_batch, omega_batch, eps=1e-8):
    """
    Legacy alias: μ' = Ω μ,  Σ' = Ω Σ Ωᵀ
    """
    from core.gaussian_core import push_gaussian
    return push_gaussian(mu_batch, sigma_batch, omega_batch,
                         eps=eps, symmetrize=True, sanitize=True,
                         approx="exact", return_inv=False)


# =============================================================================
#                             Curvature operators
# =============================================================================

def compute_gauge_potential(phi, dx=1.0):
    """
    A_μ^a = ∂_μ φ^a using central differences (periodic BC). Returns a tuple over μ.
    """
    if phi.ndim < 2:
      raise ValueError("phi must have at least one spatial and one Lie algebra dimension.")
    D = phi.ndim - 1
    return tuple((np.roll(phi, -1, axis=μ) - np.roll(phi, 1, axis=μ)) / (2.0 * dx) for μ in range(D))


def compute_field_strength(phi: np.ndarray, generators: np.ndarray, dx: float = 1.0) -> Dict[str, np.ndarray]:
    """
    2D nonabelian field strength F_{xy} from φ^a and generators.
    Returns {"xy": F_xy} with shape (H,W,K,K).
    """
    H, W, d = phi.shape
    phi = np.asarray(phi, np.float32)
    G   = np.asarray(generators, np.float32)

    Phi = np.einsum("hwd,dkm->hwkm", phi, G)  # (H,W,K,K)

    A_x = (np.roll(Phi, -1, 0) - np.roll(Phi, 1, 0)) / (2 * dx)
    A_y = (np.roll(Phi, -1, 1) - np.roll(Phi, 1, 1)) / (2 * dx)

    dAy_dx = (np.roll(A_y, -1, 0) - np.roll(A_y, 1, 0)) / (2 * dx)
    dAx_dy = (np.roll(A_x, -1, 1) - np.roll(A_x, 1, 1)) / (2 * dx)

    comm = np.einsum("...ij,...jk->...ik", A_x, A_y) - np.einsum("...ij,...jk->...ik", A_y, A_x)
    F_xy = dAy_dx - dAx_dy + comm
    return {"xy": F_xy.astype(np.float32, copy=False)}


def compute_field_strength_general(phi: np.ndarray, generators: np.ndarray, dx: float = 1.0) -> Dict[Tuple[int,int], np.ndarray]:
    """
    All nonabelian curvature components F_{μν} for φ on a D-dim grid.
    """
    phi = np.asarray(phi, np.float32)
    G   = np.asarray(generators, np.float32)
    Phi = np.einsum("...d,dkm->...km", phi, G)
    D = phi.ndim - 1
    F: Dict[Tuple[int,int], np.ndarray] = {}

    A = [(np.roll(Phi, -1, mu) - np.roll(Phi, 1, mu)) / (2 * dx) for mu in range(D)]

    for mu in range(D):
        for nu in range(mu + 1, D):
            dA_nu_mu = (np.roll(A[nu], -1, mu) - np.roll(A[nu], 1, mu)) / (2 * dx)
            dA_mu_nu = (np.roll(A[mu], -1, nu) - np.roll(A[mu], 1, nu)) / (2 * dx)
            comm = np.einsum("...ij,...jk->...ik", A[mu], A[nu]) - np.einsum("...ij,...jk->...ik", A[nu], A[mu])
            F[(mu, nu)] = (dA_nu_mu - dA_mu_nu + comm).astype(np.float32, copy=False)
    return F


def compute_curvature_gradient_analytical(phi, generators, dx: float = 1.0, metric_ab: np.ndarray | None = None):
    """
    ∇_φ Tr(F^2). If generators aren't trace-orthonormal, pass metric_ab = [Tr(G^a G^b)].
    """
    H, W, d = phi.shape
    phi = np.asarray(phi, np.float32)
    G   = np.asarray(generators, np.float32)

    A_x = (np.roll(phi, -1, 0) - np.roll(phi, 1, 0)) / (2 * dx)
    A_y = (np.roll(phi, -1, 1) - np.roll(phi, 1, 1)) / (2 * dx)

    A_x_mat = np.einsum("hwd,dkm->hwkm", A_x, G)
    A_y_mat = np.einsum("hwd,dkm->hwkm", A_y, G)

    dAy_dx = (np.roll(A_y_mat, -1, 0) - np.roll(A_y_mat, 1, 0)) / (2 * dx)
    dAx_dy = (np.roll(A_x_mat, -1, 1) - np.roll(A_x_mat, 1, 1)) / (2 * dx)
    comm_xy = A_x_mat @ A_y_mat - A_y_mat @ A_x_mat
    F_xy = dAy_dx - dAx_dy + comm_xy

    dF_dx = (np.roll(F_xy, -1, 0) - np.roll(F_xy, 1, 0)) / (2 * dx)
    dF_dy = (np.roll(F_xy, -1, 1) - np.roll(F_xy, 1, 1)) / (2 * dx)
    comm1 = A_x_mat @ F_xy - F_xy @ A_x_mat
    comm2 = A_y_mat @ F_xy - F_xy @ A_y_mat
    divF = dF_dx + dF_dy + comm1 + comm2

    if metric_ab is None:
        grad = 2.0 * np.stack([np.einsum("...ij,ij->...", divF, G[a]) for a in range(d)], axis=-1)
    else:
        Ginvs = safe_omega_inv(metric_ab.astype(np.float64, copy=False))
        comps = np.array([np.einsum("...ij,ij->...", divF, G[a]) for a in range(d)])  # (d,H,W)
        grad = 2.0 * np.einsum("ab,b...->a...", Ginvs, comps).transpose(1, 2, 0)
    return grad.astype(np.float32, copy=False)


# =============================================================================
#                       Holonomy / transport helpers
# =============================================================================

def compute_intra_omega(agent, coord_from, coord_to, generators=None, *, fiber="q"):
    """
    Ω(p_to ← p_from) within a single agent: exp(φ(to)) · exp(−φ(from)).
    """
    if coord_from == coord_to:
        K = (generators.shape[-1] if generators is not None
             else getattr(agent, "generators_q" if fiber == "q" else "generators_p").shape[-1])
        return np.eye(K, dtype=np.float32)

    if generators is None:
        generators = getattr(agent, "generators_q" if fiber == "q" else "generators_p")

    phi_field = agent.phi if fiber == "q" else agent.phi_model
    φ_from = np.asarray(phi_field[coord_from], np.float32)
    φ_to   = np.asarray(phi_field[coord_to],   np.float32)

    Ei  = exp_lie_algebra_irrep(φ_to[None], generators, parallelize_expm=False)[0]
    Emj = exp_lie_algebra_irrep((-φ_from)[None], generators, parallelize_expm=False)[0]
    return (Ei @ Emj).astype(np.float32, copy=False)
