# -*- coding: utf-8 -*-
"""
runtime_context.py
Lightweight, level-aware run context for emergent parents & detectors.
Keeps heavy imports out to avoid cycles; DetectorState is created lazily.
"""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np
from typing import Any, Callable, Dict, Iterable, List, Optional, Tuple



# ─────────────────────────────────────────────────────────────────────────────
# Small helpers (kept local to avoid import cycles)
# ─────────────────────────────────────────────────────────────────────────────
# add near the top, with the other small helpers
class _Dirty:
    __slots__ = ("agents", "kl")
    def __init__(self):
        self.agents = set()  # ids whose Ω/Λ/fields are stale
        self.kl     = set()  # ids whose KL fields need refresh


def _agent_id(a: Any) -> int:
    """Robustly get an integer id for an agent/parent object."""
    return int(getattr(a, "id", id(a)))

def _collect_by_ids(all_agents: Iterable[Any], ids: Iterable[int]) -> List[Any]:
    """
    Return the subset of objects from `all_agents` whose _agent_id is in `ids`.
    Ignores ids not present. Order follows the order of `all_agents`.
    """
    if not ids:
        return []
    wanted = {int(i) for i in ids}
    out: List[Any] = []
    for a in all_agents:
        try:
            if _agent_id(a) in wanted:
                out.append(a)
        except Exception:
            continue
    return out


# ─────────────────────────────────────────────────────────────────────────────
# Central cache hub (per-step invalidation, namespaced)
# ─────────────────────────────────────────────────────────────────────────────

# ─────────────────────────────────────────────────────────────────────────────
# Central cache hub (per-step invalidation, namespaced)
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class CacheHub:
    step_tag: int = -1
    spaces: Dict[str, Dict[Any, Any]] = field(default_factory=lambda: {
        # exp/omega/lambda existed; add morphism/theta for Φ/Φ̃ and Θ
        "exp": {}, "omega": {}, "lambda": {}, "morphism": {}, "theta": {}, "fisher": {}, "misc": {}
    })

    def ns(self, name: str) -> Dict[Any, Any]:
        return self.spaces.setdefault(name, {})

    def clear_on_step(self, step: int) -> None:
        if step != self.step_tag:
            for d in self.spaces.values():
                d.clear()
            self.step_tag = step

    def stats(self) -> Dict[str, int]:
        return {k: len(v) for k, v in self.spaces.items()}


# --- add this helper in runtime_context.py ---

def resolve_cache_ns(ctx, name: str = "misc"):
    """
    Return a mutable mapping to use as a cache namespace.
    Guarantees a cache object on ctx, and a dict-like ns.
    Works even if CacheHub is absent.
    """
    if ctx is None:
        return {}

    cache = getattr(ctx, "cache", None)
    if cache is None:
        # Try to instantiate your CacheHub if present; else fall back to a dict with .ns()
        try:
            # If CacheHub is defined in this module, this is a no-op import
            CacheHubClass = globals().get("CacheHub", None)
            if CacheHubClass is not None:
                cache = CacheHubClass()
            else:
                raise RuntimeError("No CacheHub available")
        except Exception:
            class _DictNS(dict):
                def ns(self, n):
                    return self.setdefault(n, {})
            cache = _DictNS()
        setattr(ctx, "cache", cache)

    # Provide/normalize .ns(name) API
    ns_func = getattr(cache, "ns", None)
    if callable(ns_func):
        return cache.ns(name)

    # If cache is a plain dict (or unknown), emulate ns()
    if isinstance(cache, dict):
        return cache.setdefault(name, {})

    # Last resort: attach a tiny ns() adapter
    if not hasattr(cache, "_ns_store"):
        cache._ns_store = {}
    def _ns_adapter(n):
        return cache._ns_store.setdefault(n, {})
    setattr(cache, "ns", _ns_adapter)
    return cache.ns(name)


# ─────────────────────────────────────────────────────────────────────────────
# Graph/link carriers
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class LevelGraph:
    level: int
    agent_ids: List[int]                                     # ordered ids at this level
    neighbors: Dict[int, List[int]] = field(default_factory=dict)  # id -> [neighbor ids]



@dataclass
class CrossScaleLink:
    low_level: int
    high_level: int
    child_ids: List[int]                                     # ids at low_level
    parent_ids: List[int]                                    # ids at high_level
    labels: np.ndarray                                       # shape (len(child_ids),), parent id or -1



def _lazy_detector_factory() -> Any:
    """
    Lazily import and construct a DetectorState to avoid import cycles.
    You can replace this with a different factory if needed.
    """
    try:
        from detector import DetectorState  # local import to avoid cycle at module load
        return DetectorState()
    except Exception:
        class _Stub:
            pass
        return _Stub()


# ─────────────────────────────────────────────────────────────────────────────
# Unified Runtime Context (legacy views + level-graphs + cross-scale links)
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class RuntimeCtx:
    # ---- Legacy lvl-1 views (kept for backward compat) ---------------------
    parents_by_region: Dict[int, Any] = field(default_factory=dict)  # pid -> parent Agent (mounted level)
    next_parent_id: int = 1
    global_step: int = 0
    detector_state: Optional[Any] = None  # set by detector on first use (lazy)

    # ---- Multi-level stores (sources of truth) -----------------------------
    parents_by_level: Dict[int, Dict[int, Any]] = field(default_factory=dict)       # L -> {pid: Agent}
    next_parent_id_by_level: Dict[int, int] = field(default_factory=dict)           # L -> next pid
    detector_state_by_level: Dict[int, Any] = field(default_factory=dict)           # L -> DetectorState
    children_latest_by_level: Dict[int, Any] = field(default_factory=dict)          # (L-1) -> list[Agent] for viz

    # New, level-agnostic registries
    agents_by_level: Dict[int, Dict[int, Any]] = field(default_factory=dict)        # L -> {id: Agent}
    graphs: Dict[int, LevelGraph] = field(default_factory=dict)                     # L -> LevelGraph
    xlinks: Dict[Tuple[int, int], CrossScaleLink] = field(default_factory=dict)     # (L_lo, L_hi) -> link

    # Central cache hub
    cache: CacheHub = field(default_factory=CacheHub)
    dirty: _Dirty = field(default_factory=_Dirty)
    # ---- Mounted level bookkeeping (legacy exposure) -----------------------
    _mounted_level: Optional[int] = None

    # -----------------------------------------------------------------------
    # Registration & graph utilities
    # -----------------------------------------------------------------------
    def register_agents(self, level: int, agents: List[Any]) -> None:
        """Install/refresh the agent registry for a level."""
        lvl = self.agents_by_level.setdefault(level, {})
        lvl.clear()
        for a in agents:
            aid = int(getattr(a, "id"))
            lvl[aid] = a

    def build_neighbors(self, level: int, neighbor_map: Dict[int, List[int]]) -> None:
        """Install a neighbor graph for a level. IDs must be in agents_by_level[level]."""
        ids = list(self.agents_by_level.get(level, {}).keys())
        nm: Dict[int, List[int]] = {i: [j for j in neighbor_map.get(i, []) if j in ids] for i in ids}
        self.graphs[level] = LevelGraph(level=level, agent_ids=ids, neighbors=nm)

    def neighbors_of(self, level: int, agent_id: int) -> List[int]:
        """Return same-level neighbor ids (fallback to empty list)."""
        g = self.graphs.get(level)
        if not g:
            return []
        return g.neighbors.get(agent_id, [])

    def agent(self, level: int, agent_id: int) -> Any:
        """Fetch agent by (level, id)."""
        return self.agents_by_level[level][agent_id]

    def agents(self, level: int) -> List[Any]:
        """Ordered list of agents at a level."""
        if level not in self.graphs:
            return list(self.agents_by_level.get(level, {}).values())
        g = self.graphs[level]
        return [self.agents_by_level[level][aid] for aid in g.agent_ids]

    # -----------------------------------------------------------------------
    # Cross-scale: labels & Λ fields
    # -----------------------------------------------------------------------
    def set_crossscale_labels(
        self, low_level: int, high_level: int,
        child_ids: List[int], parent_ids: List[int], labels: np.ndarray
    ) -> None:
        """Create/refresh the cross-scale link with labeling."""
        labels = np.asarray(labels).astype(int)
        self.xlinks[(low_level, high_level)] = CrossScaleLink(
            low_level=low_level, high_level=high_level,
            child_ids=[int(x) for x in child_ids],
            parent_ids=[int(x) for x in parent_ids],
            labels=labels,
        )

    

    def crossscale_link_touching(self, level: int) -> List[CrossScaleLink]:
        """Return all links where this level participates (as low or high)."""
        out: List[CrossScaleLink] = []
        for (lo, hi), lk in self.xlinks.items():
            if lo == level or hi == level:
                out.append(lk)
        return out

    def parent_of_child(self, low_level: int, high_level: int, child_id: int) -> int:
        """Return parent id for child or -1 if unlabeled."""
        lk = self.xlinks.get((low_level, high_level))
        if not lk:
            return -1
        try:
            idx = lk.child_ids.index(int(child_id))
        except ValueError:
            return -1
        return int(lk.labels[idx]) if 0 <= idx < len(lk.labels) else -1

    def clear_lambda_fields_for_link(self, low_level: int, high_level: int) -> None:
        """Remove Λ fields from the cross-scale link snapshot (if present)."""
        lk = self.xlinks.get((low_level, high_level))
        if lk:
            lk.Lambda_up_q = None
            lk.Lambda_dn_q = None
            lk.Lambda_up_p = None
            lk.Lambda_dn_p = None

    def get_lambda(
        self, low_level: int, high_level: int,
        child_id: int, parent_id: int, *,
        fiber: str = "q", direction: str = "up",
    ) -> Optional[np.ndarray]:
        """
        Fetch Λ(child→parent) directly from the central transport cache.
        Returns an (H,W,K,K) array or None.
        """
        try:
            from transport_cache import Lambda_up, Lambda_dn
        except Exception:
            return None
        child = self.agents_by_level.get(low_level, {}).get(int(child_id))
        parent = self.agents_by_level.get(high_level, {}).get(int(parent_id))
        if child is None or parent is None:
            return None
        fn = Lambda_up if direction == "up" else Lambda_dn
        which = "q" if fiber == "q" else "p"
        return fn(self, child, parent, which=which)



    # ---- Cache helpers -----------------------------------------------------
    def cache_clear(self, *names: str) -> None:
        """Clear selected namespaces ('exp','omega','lambda','fisher','misc')."""
        if not hasattr(self, "cache") or self.cache is None: 
            return
        if not names:
            self.cache.clear_on_step(self.global_step)  # no-op if same step
            return
        for n in names:
            try:
                self.cache.ns(n).clear()
            except Exception:
                pass

    def cache_stats(self) -> dict:
        """Return sizes by namespace for debugging."""
        return {} if not getattr(self, "cache", None) else self.cache.stats()
    
    
    def cache_invalidate_agent(self, agent: Any) -> None:
        """Drop all exp/omega/lambda/morphism/theta entries touching this agent."""
        if not getattr(self, "cache", None):
            return
        aid = int(getattr(agent, "id", id(agent)))
        for ns_name in ("exp", "omega", "lambda", "morphism", "theta"):
            ns = self.cache.ns(ns_name)
            to_kill = [k for k in list(ns.keys()) if isinstance(k, tuple) and (aid in k)]
            for k in to_kill:
                ns.pop(k, None)



    # -----------------------------------------------------------------------
    # Legacy mount (kept for detector & old code)
    # -----------------------------------------------------------------------
    def mount_level(
        self,
        L: int,
        detector_factory: Optional[Callable[[], Any]] = None,
    ) -> None:
        """
        Expose level-L stores through legacy attributes:
          parents_by_region, next_parent_id, detector_state.
        Creates missing level buckets on demand.
        """
        if detector_factory is None:
            detector_factory = _lazy_detector_factory

        if L not in self.parents_by_level:
            self.parents_by_level[L] = {}
        if L not in self.next_parent_id_by_level:
            self.next_parent_id_by_level[L] = 1
        if L not in self.detector_state_by_level or self.detector_state_by_level[L] is None:
            self.detector_state_by_level[L] = detector_factory()

        # mount the legacy views
        self.parents_by_region = self.parents_by_level[L]
        self.next_parent_id = self.next_parent_id_by_level[L]
        self.detector_state = self.detector_state_by_level[L]
        self._mounted_level = L

    def persist_mounted_level(self) -> None:
        """Persist legacy-attribute edits back into the mounted level store."""
        L = self._mounted_level
        if L is None:
            return
        self.parents_by_level[L] = self.parents_by_region or {}
        self.next_parent_id_by_level[L] = int(self.next_parent_id or 1)
        self.detector_state_by_level[L] = self.detector_state

    def with_level(self, L: int, detector_factory: Optional[Callable[[], Any]] = None) -> "RuntimeCtx":
        self.mount_level(L, detector_factory=detector_factory)
        return self


# ─────────────────────────────────────────────────────────────────────────────
# Convenience
# ─────────────────────────────────────────────────────────────────────────────

def ensure_runtime_defaults(ctx: Optional[RuntimeCtx]) -> RuntimeCtx:
    """Ensure a valid RuntimeCtx with sane defaults. Does not mount a level."""
    if ctx is None:
        ctx = RuntimeCtx()
    if ctx.parents_by_region is None:
        ctx.parents_by_region = {}
    if ctx.next_parent_id is None:
        ctx.next_parent_id = 1
    if ctx.global_step is None:
        ctx.global_step = 0
    if not hasattr(ctx, "dirty") or ctx.dirty is None:
        ctx.dirty = _Dirty()
    return ctx



# Optional module-level singleton
runtime_ctx = RuntimeCtx()

__all__ = [
    "CacheHub",
    "LevelGraph",
    "CrossScaleLink",
    "RuntimeCtx",
    "runtime_ctx",
    "ensure_runtime_defaults",
]
