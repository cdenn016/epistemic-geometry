# -*- coding: utf-8 -*-
"""
Created on Mon Aug 11 16:05:57 2025

@author: chris and christine
"""

import numpy as np
import core.config
from core.natural_gradient import compute_inverse_fisher_field_natural  
from core.get_generators import get_generators            
from core.numerical_utils import sanitize_sigma, safe_inv, masked_cond_proxy    
from typing import Optional
from transport.transport_cache import warm_E, Omega, Lambda_up, Lambda_dn

# add near the top
try:
    from core.gauusian_core import retract_phi_principal
except Exception:
    retract_phi_principal = None

def _pre_retract_fields(objs):
    if retract_phi_principal is None:
        return
    for a in (objs or []):
        if a is None: continue
        if hasattr(a, "phi_field") and a.phi_field is not None:
            a.phi_field = retract_phi_principal(a.phi_field)
        if hasattr(a, "phi_model_field") and a.phi_model_field is not None:
            a.phi_model_field = retract_phi_principal(a.phi_model_field)



def _rect_eye(Kdest: int, Ksrc: int, dtype=np.float32):
    M = np.zeros((Kdest, Ksrc), dtype=dtype)
    m = min(Kdest, Ksrc)
    M[np.arange(m), np.arange(m)] = 1.0
    return M

def _as_hw_block(M, H, W):
    """Broadcast (Kd,Ks) or (H,W,Kd,Ks) to (H,W,Kd,Ks)."""
    M = np.asarray(M)
    if M.ndim == 4 and M.shape[0] == H and M.shape[1] == W:
        return M
    if M.ndim == 2:
        return np.broadcast_to(M, (H, W, M.shape[0], M.shape[1])).astype(np.float32, copy=False)
    raise ValueError(f"Expected (Kd,Ks) or (H,W,Kd,Ks); got {M.shape}")

def ensure_transforms(targets, generators_q=None, generators_p=None, params=None, *, ctx=None):
    """
    Ensure each agent has well-shaped bundle morphisms:
      - bundle_morphism_q_to_p : (H,W,Kp,Kq)
      - bundle_morphism_p_to_q : (H,W,Kq,Kp)
    Also seeds Phi_0 / Phi_tilde_0 if missing.
    """
    if not targets:
        return

    for a in targets:
        if a is None:
            continue

        # infer H,W and bundle sizes
        try:
            H, W = np.asarray(a.mask).shape[:2]
        except Exception:
            H = getattr(a, "mu_q_field").shape[0]
            W = getattr(a, "mu_q_field").shape[1]

        try:
            Kq = int(a.mu_q_field.shape[-1])
            Kp = int(a.mu_p_field.shape[-1])
        except Exception as e:
            raise ValueError("ensure_transforms: agent missing mu_q_field/mu_p_field with trailing K") from e

        # q -> p  (Kp x Kq)
        qp = getattr(a, "bundle_morphism_q_to_p", None)
        if qp is None or (qp.shape[-2:] != (Kp, Kq)):
            qp = _rect_eye(Kp, Kq)
        qp = _as_hw_block(qp, H, W)

        # p -> q  (Kq x Kp)
        pq = getattr(a, "bundle_morphism_p_to_q", None)
        if pq is None or (pq.shape[-2:] != (Kq, Kp)):
            pq = _rect_eye(Kq, Kp)
        pq = _as_hw_block(pq, H, W)

        a.bundle_morphism_q_to_p = qp.astype(np.float32, copy=False)
        a.bundle_morphism_p_to_q = pq.astype(np.float32, copy=False)

        # seed baselines if absent (used by morphism self/feedback terms)
        if getattr(a, "Phi_0", None) is None:
            a.Phi_0 = a.bundle_morphism_q_to_p.copy()
        if getattr(a, "Phi_tilde_0", None) is None:
            a.Phi_tilde_0 = a.bundle_morphism_p_to_q.copy()






# ---------------------------------------------------------------------
# Public entry points
# ---------------------------------------------------------------------

def preprocess_all_agents(agents, params=None, G_q=None, G_p=None, *, ctx: Optional[object] = None):
    """
    Build/refresh: generators, Σ sanitize + inverses, condition proxies,
    (optionally) Fisher. Also pre-warms exp grids via transport cache.
    Safe to call repeatedly; idempotent per step.
    """
    params = params or {}
    if ctx is not None:
        params = dict(params)
        params["runtime_ctx"] = ctx

    agents = [a for a in (agents or []) if a is not None]
    if not agents:
        return

    # preprocess structural fields per agent
    for a in agents:
        preprocess_agent_fields(a, params, G_q=G_q, G_p=G_p, ctx=ctx)

    # pre-warm exp(φ) / exp(φ̃) once for all provided agents
    try:
        if ctx is not None:
            warm_E(ctx, agents, whiches=("q", "p"))
    except Exception:
        pass


# kept for callers, but now a light pre-warmer (no per-agent maps)
def build_all_lambda_caches(agents, *, ctx: Optional[object] = None):
    """
    Pre-warm Λ caches in the central hub for all child↔parent pairs found in `agents`.
    Does not store per-agent Lambda_*_map anymore.
    """
    if not agents or ctx is None:
        return
    id2A = {int(getattr(a, "id", i)): a for i, a in enumerate(agents) if a is not None}
    for child in agents:
        if child is None:
            continue
        pids = getattr(child, "parent_ids", None) or []
        for pid in pids:
            parent = id2A.get(int(pid))
            if parent is None:
                continue
            # idempotent cache fills
            try:
                _ = Lambda_up(ctx, child, parent, which="q")
                _ = Lambda_dn(ctx, child, parent, which="q")
                _ = Lambda_up(ctx, child, parent, which="p")
                _ = Lambda_dn(ctx, child, parent, which="p")
            except Exception:
                # cache is best-effort; skip on error
                pass


# legacy compatibility: still populates per-agent Ω dicts if requested by old code
def build_all_omega_caches(
    agents,
    *,
    ctx: Optional[object] = None,
    strict: bool = False,
    debug: bool = False,
    store_per_agent: bool = True,
):
    """
    Build neighbor Ω and Ω̃ using the central cache; optionally mirror into
    agent.Omega_cache / Omega_tilde_cache for legacy readers.
    """
    if not agents:
        return

    if isinstance(agents, dict):
        agent_list = list(agents.values())
        id_map = {int(getattr(a, "id", i)): a for i, a in enumerate(agent_list)}
    else:
        agent_list = list(agents or [])
        id_map = {int(getattr(a, "id", i)): a for i, a in enumerate(agent_list)}

    for ai in agent_list:
        if ai is None:
            continue

        if store_per_agent:
            ai.Omega_cache = {}
            ai.Omega_tilde_cache = {}

        for nb in (getattr(ai, "neighbors", ()) or ()):
            try:
                j_id = int(nb.get("id"))
            except Exception:
                if strict:
                    raise
                if debug:
                    print(f"[omega] skip neighbor with bad id: {nb!r}")
                continue

            aj = id_map.get(j_id)
            if aj is None:
                if debug:
                    print(f"[omega] neighbor {j_id} not in subset, skipping")
                continue

            try:
                Om_q = Omega(ctx, ai, aj, which="q") if ctx is not None else None
                Om_p = Omega(ctx, ai, aj, which="p") if ctx is not None else None
            except Exception as e:
                if strict:
                    raise
                if debug:
                    print(f"[omega] failed pair (i={getattr(ai,'id','?')}, j={j_id}): {e}")
                continue

            if store_per_agent:
                if Om_q is not None:
                    ai.Omega_cache[j_id] = Om_q.astype(np.float32, copy=False)
                if Om_p is not None:
                    ai.Omega_tilde_cache[j_id] = Om_p.astype(np.float32, copy=False)


# ---------------------------------------------------------------------
# Per-agent preprocessing
# ---------------------------------------------------------------------

def preprocess_agent_fields(agent, params=None, G_q=None, G_p=None, *, ctx: Optional[object] = None):
    """
    Prepare per-agent fields (generators, Σ sanitize/inv, cond proxies, Fisher).
    Also warms exp grids in the central cache. No per-agent exp/omega fields.
    """
    
    import core.config as config
    
    params     = params or {}
    eps        = float(getattr(config, "eps", 1e-8))
    group_name = str(getattr(config, "group_name", "so3"))
    strict     = bool(params.get("sanitize_strict", True))
    step_tag   = int(params.get("step", getattr(ctx, "global_step", -1) or -1))

    # idempotency per step
    if getattr(agent, "_preprocessed_step", None) == step_tag and step_tag >= 0:
        return

    # infer sizes & ensure mask
    try:
        Kq = int(agent.mu_q_field.shape[-1])
        Kp = int(agent.mu_p_field.shape[-1])
    except Exception as e:
        raise ValueError("preprocess_agent_fields: agent.mu_q_field / mu_p_field missing or malformed") from e

    if not hasattr(agent, "mask") or agent.mask is None:
        H, W = agent.mu_q_field.shape[:2]
        agent.mask = np.ones((H, W), np.float32)

    # generators: prefer provided, else build
    if G_q is not None: agent.generators_q = G_q
    if G_p is not None: agent.generators_p = G_p

    G_q_eff = getattr(agent, "generators_q", None)
    if G_q_eff is None or (isinstance(G_q_eff, np.ndarray) and G_q_eff.size == 0):
        G_q_eff, _ = get_generators(group_name, Kq, return_meta=True)
        agent.generators_q = G_q_eff

    G_p_eff = getattr(agent, "generators_p", None)
    if G_p_eff is None or (isinstance(G_p_eff, np.ndarray) and G_p_eff.size == 0):
        G_p_eff, _ = get_generators(group_name, Kp, return_meta=True)
        agent.generators_p = G_p_eff

    # SPD sanitize & inverses
    agent.sigma_q_field = sanitize_sigma(agent.sigma_q_field, strict=strict, eps=eps)
    agent.sigma_p_field = sanitize_sigma(agent.sigma_p_field, strict=strict, eps=eps)
    agent.sigma_q_inv   = safe_inv(agent.sigma_q_field, eps=eps)
    agent.sigma_p_inv   = safe_inv(agent.sigma_p_field, eps=eps)

    # condition proxies
    agent._cond_proxy_q = masked_cond_proxy(agent.sigma_q_field, agent.mask)
    agent._cond_proxy_p = masked_cond_proxy(agent.sigma_p_field, agent.mask)

    # pre-warm exp grids in central cache (no per-agent _exp_* fields)
    try:
        if ctx is not None:
            warm_E(ctx, [agent], whiches=("q", "p"))
    except Exception:
        pass

    # optional Fisher (ctx-aware if available)
    try:
        try:
            agent.inverse_fisher_phi = compute_inverse_fisher_field_natural(
                agent, agent.generators_q, field="phi", ctx=ctx
            )
        except TypeError:
            agent.inverse_fisher_phi = compute_inverse_fisher_field_natural(
                agent, agent.generators_q, field="phi"
            )
        try:
            agent.inverse_fisher_phi_model = compute_inverse_fisher_field_natural(
                agent, agent.generators_p, field="phi_model", ctx=ctx
            )
        except TypeError:
            agent.inverse_fisher_phi_model = compute_inverse_fisher_field_natural(
                agent, agent.generators_p, field="phi_model"
            )
    except Exception:
        # leave existing values if present
        agent.inverse_fisher_phi        = getattr(agent, "inverse_fisher_phi", None)
        agent.inverse_fisher_phi_model  = getattr(agent, "inverse_fisher_phi_model", None)

    # optional SPD assert
    if bool(getattr(config, "assert_spd_after_sanitize", False)):
        wq = np.linalg.eigvalsh(0.5 * (agent.sigma_q_field + np.swapaxes(agent.sigma_q_field, -1, -2)))
        wp = np.linalg.eigvalsh(0.5 * (agent.sigma_p_field + np.swapaxes(agent.sigma_p_field, -1, -2)))
        floor = float(getattr(config, "sigma_eig_floor", 1e-6))
        if (wq <= floor).any() or (wp <= floor).any():
            raise RuntimeError("Non-SPD Σ after sanitize.")

    agent._preprocessed_step = step_tag






def zero_all_gradients(agent):
    """
    Zero (and if missing, create) all gradient buffers,
    keeping legacy aliases in sync and ensuring arrays are writeable.
    """
    def ensure_buf(name, like):
        arr = getattr(agent, name, None)
        if arr is None and like is not None:
            arr = np.zeros_like(like)
        elif arr is not None and not arr.flags.writeable:
            arr = np.array(arr, copy=True)
        setattr(agent, name, arr)
        return arr

    # Canonical grads (create from fields if needed)
    g_mu_q   = ensure_buf("grad_mu_q",    getattr(agent, "mu_q_field", None))
    g_sg_q   = ensure_buf("grad_sigma_q", getattr(agent, "sigma_q_field", None))
    g_mu_p   = ensure_buf("grad_mu_p",    getattr(agent, "mu_p_field", None))
    g_sg_p   = ensure_buf("grad_sigma_p", getattr(agent, "sigma_p_field", None))
    g_phi    = ensure_buf("grad_phi",       getattr(agent, "phi", None))
    g_phit   = ensure_buf("grad_phi_tilde", getattr(agent, "phi_model", None))
    g_Phi    = ensure_buf("grad_Phi",       getattr(agent, "bundle_morphism_q_to_p", None))
    g_Phit   = ensure_buf("grad_Phi_tilde", getattr(agent, "bundle_morphism_p_to_q", None))

    # Keep legacy aliases in sync (as references, not copies)
    if g_mu_q is not None:
        agent.grad_mu_q_field = g_mu_q
    if g_sg_q is not None:
        agent.grad_sigma_q_field = g_sg_q
    if g_mu_p is not None:
        agent.grad_mu_p_field = g_mu_p
    if g_sg_p is not None:
        agent.grad_sigma_p_field = g_sg_p

    # Zero safely
    for arr in (g_mu_q, g_sg_q, g_mu_p, g_sg_p, g_phi, g_phit, g_Phi, g_Phit):
        if isinstance(arr, np.ndarray):
            arr.fill(0)



