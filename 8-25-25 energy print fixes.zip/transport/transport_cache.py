
from __future__ import annotations
from typing import Any, Dict, Iterable, Optional, Sequence, Tuple
import numpy as np

# Your existing utilities
from core.omega import exp_lie_algebra_irrep
from core.numerical_utils import safe_omega_inv
import math
import core.config as CFG

from transport.bundle_morphism_utils import compute_direct_morphisms
"""
Created on Tue Aug 19 20:19:10 2025

@author: chris and christine
"""

# -*- coding: utf-8 -*-
"""
transport_cache.py
Centralized facade for cached transports: exp(φ), Ω_{ij}, Λ (hooks).
Backed by runtime_ctx.cache (CacheHub). One source of truth, cleared per step.
"""


def _sanitize_axis_angle(phi, *, max_theta=None):
    """
    Make axis–angle safe for exp:
      - replace NaN/Inf with 0
      - clamp ‖phi‖ into principal ball (<= pi - margin)
    """
    
    phi = np.asarray(phi, np.float32)
    # replace invalids
    phi = np.nan_to_num(phi, nan=0.0, posinf=0.0, neginf=0.0)
    # only clamp 3-vectors
    if phi.shape[-1] != 3:
        return phi
    if max_theta is None:
        margin = float(getattr(CFG, "so3_principal_ball_margin", 1e-4))
        max_theta = float(math.pi - margin)
    th2 = np.einsum("...i,...i->...", phi, phi)
    th  = np.sqrt(th2, dtype=np.float32)
    overflow = th > max_theta
    if np.any(overflow):
        scale = (max_theta / np.maximum(th, 1e-12)).astype(np.float32)
        phi = phi * scale[..., None]
    return phi


# ---------------------------------------------------------------------------
# Internal helpers (keys, accessors)
# ---------------------------------------------------------------------------

def _aid(a: Any) -> int:
    """Robust agent id (falls back to object's id if missing)."""
    return int(getattr(a, "id", id(a)))

def _exp_key(agent: Any, which: str) -> Tuple[str, int, str]:
    # which ∈ {'q','p'}
    return ("exp", _aid(agent), which)

def _omega_key(ai: Any, aj: Any, which: str) -> Tuple[str, int, int, str]:
    return ("omega", _aid(ai), _aid(aj), which)

def _lambda_key(child: Any, parent: Any, which: str, up: bool) -> Tuple[str, int, int, str, str]:
    return ("lambda", _aid(child), _aid(parent), which, "up" if up else "dn")

def _get_generators(agent: Any, which: str) -> np.ndarray:
    if which == "q":
        G = getattr(agent, "generators_q", None)
    else:
        G = getattr(agent, "generators_p", None)
    if G is None:
        raise ValueError(f"[transport_cache] generators ({which}) missing on agent id={_aid(agent)}")
    return G

def _get_phi(agent: Any, which: str) -> np.ndarray:
    if which == "q":
        phi = getattr(agent, "phi", None)
    else:
        phi = getattr(agent, "phi_model", None)
    if phi is None:
        raise ValueError(f"[transport_cache] phi field ({which}) missing on agent id={_aid(agent)}")
    return phi


# ---------------------------------------------------------------------------
# Public API: exp(φ) and Ω_{ij}
# ---------------------------------------------------------------------------

def E_grid(ctx: Any, agent: Any, which: str = "q") -> np.ndarray:
    """
    Cached exp(φ) grid for an agent in fiber 'q' or 'p'.
    Shape: (..., K, K), broadcasts over spatial dims.
    """
    cache: Dict[Any, Any] = ctx.cache.ns("exp")
    key = _exp_key(agent, which)
    E = cache.get(key)
    if E is None:
        G = _get_generators(agent, which)
        phi = _get_phi(agent, which)

        # --- NEW: sanitize φ and handle tiny-φ fast path -------------------------
        phi = _sanitize_axis_angle(phi)
        
        small_thr = float(getattr(CFG, "phi_small_threshold", 1e-6))
        if phi.shape[-1] == 3:
            # if all tiny, return identity tiles (skip exp)
            th = np.linalg.norm(phi, axis=-1)
            if np.all(th < small_thr):
                K = int(G.shape[-2])
                I = np.eye(K, dtype=np.float32)
                E = np.broadcast_to(I, phi.shape[:-1] + (K, K)).copy()
                cache[key] = E
                return E

        # optional clipping guard for very large reps
        max_norm = float(getattr(CFG, "exp_clip_max_norm", 10.0))
        E = exp_lie_algebra_irrep(phi, G, max_norm=max_norm)  # (..., K, K)
        cache[key] = E
    return E



def Omega(ctx: Any, ai: Any, aj: Any, which: str = "q") -> np.ndarray:
    """
    Cached Ω_{ij} = exp(φ_i) @ inv(exp(φ_j)) for fiber 'q' or 'p'.
    Uses safe_omega_inv for general irreps (not assuming orthogonality).
    """
    om_cache = ctx.cache.ns("omega")
    key = _omega_key(ai, aj, which)
    Om = om_cache.get(key)
    if Om is None:
        Ei = E_grid(ctx, ai, which)   # (..., K, K)
        Ej = E_grid(ctx, aj, which)   # (..., K, K)
        Ej_inv = safe_omega_inv(Ej)   # (..., K, K)
        Om = np.matmul(Ei, Ej_inv)    # (..., K, K)
        om_cache[key] = Om
    return Om

def omega_child_to_parents_batched(ctx, child, parents, G, *, invert_j=True, mask_tau=1e-3):
    """
    Compute Ω_{i->j} on overlap windows for one child vs many parents, in batch.

    Returns:
      list[(parent_id: int, bbox: (y0,y1,x0,x1), Omega_win: (h,w,K,K) float32)]

    Notes:
      - Infers fiber ('q' or 'p') from the shape of G vs child's generators.
      - Crops to the tight overlap bbox per parent to avoid full-frame work.
      - Uses a batched linear solve for Ej^{-1} (stable & faster than forming inv).
    """
    

    # -------- infer fiber from G's shape (must match child's generators) ---------
    which = None
    G = np.asarray(G, np.float32)
    if getattr(child, "generators_q", None) is not None and \
       tuple(np.shape(child.generators_q)) == tuple(G.shape):
        which = "q"
    elif getattr(child, "generators_p", None) is not None and \
         tuple(np.shape(child.generators_p)) == tuple(G.shape):
        which = "p"
    else:
        raise ValueError(
            f"[omega_child_to_parents_batched] cannot infer fiber from G.shape={G.shape}; "
            f"child.gen_q={getattr(child,'generators_q',None) and np.shape(child.generators_q)}, "
            f"child.gen_p={getattr(child,'generators_p',None) and np.shape(child.generators_p)}"
        )

    # -------- build Ei once; share memory when cropping --------------------------
    Ei_full = E_grid(ctx, child, which=which)  # (H,W,K,K)
    H, W, K, _ = Ei_full.shape

    out = []
    cmask = np.asarray(getattr(child, "mask", 0.0), np.float32)

    for p in (parents or []):
        if p is None:
            continue

        pmask = np.asarray(getattr(p, "mask", 0.0), np.float32)
        ov, bbox = _overlap_and_bbox(cmask, pmask, mask_tau)  # tight bbox
        if bbox is None:
            continue

        y0, y1, x0, x1 = bbox
        h, w = (y1 - y0), (x1 - x0)
        if h <= 0 or w <= 0:
            continue

        # crop Ei/Ej once per parent
        Ei_win = Ei_full[y0:y1, x0:x1, :, :]                          # (h,w,K,K)
        Ej_win = E_grid(ctx, p, which=which)[y0:y1, x0:x1, :, :]       # (h,w,K,K)

        # build Ω_{ij} window
        if invert_j:
            # Solve Ej^T * X^T = Ei^T  ⇒ X = (solve(Ej^T, Ei^T))^T
            N  = h * w
            A  = Ej_win.reshape(N, K, K).transpose(0, 2, 1)  # A = Ej^T
            B  = Ei_win.reshape(N, K, K).transpose(0, 2, 1)  # B = Ei^T
            Xt = np.linalg.solve(A, B)                       # (N,K,K)
            X  = Xt.transpose(0, 2, 1).reshape(h, w, K, K)   # (h,w,K,K)
        else:
            # Convention w/o inversion if you ever need it: Ω = Ei @ Ej^T
            X = np.einsum("...ab,...cb->...ac", Ei_win, Ej_win, optimize=True)

        out.append((int(getattr(p, "id", id(p))), bbox, X.astype(np.float32, copy=False)))

    return out


# ---------------------------------------------------------------------------
# Optional Λ hooks (centralize later; stubs return cached value if present)
# ---------------------------------------------------------------------------

# transport_cache.py — add/replace these definitions

def _lambda_key(child: Any, parent: Any, which: str, up: bool) -> Tuple[str, int, int, str, str]:
    return ("lambda", _aid(child), _aid(parent), which, "up" if up else "dn")

# transport_cache.py

def Lambda_dn(ctx: Any, child: Any, parent: Any, which: str = "q") -> np.ndarray:
    """
    Cached Λ↓ (parent → child): Λ↓ = E_child @ inv(E_parent)
    """
    lam_ns = ctx.cache.ns("lambda")
    key = _lambda_key(child, parent, which, up=False)
    Lam = lam_ns.get(key)
    if Lam is None:
        E_c = E_grid(ctx, child, which=which)
        E_p = E_grid(ctx, parent, which=which)
        E_p_inv = safe_omega_inv(E_p)             # <-- inverse, not transpose
        Lam = np.einsum("...ik,...kj->...ij", E_c, E_p_inv, optimize=True)
        lam_ns[key] = Lam
    return Lam

def Lambda_up(ctx: Any, child: Any, parent: Any, which: str = "q") -> np.ndarray:
    """
    Cached Λ↑ (child → parent): Λ↑ = E_parent @ inv(E_child)
    """
    lam_ns = ctx.cache.ns("lambda")
    key = _lambda_key(child, parent, which, up=True)
    Lam = lam_ns.get(key)
    if Lam is None:
        E_c = E_grid(ctx, child, which=which)
        E_p = E_grid(ctx, parent, which=which)
        E_c_inv = safe_omega_inv(E_c)             # <-- inverse, not transpose
        Lam = np.einsum("...ik,...kj->...ij", E_p, E_c_inv, optimize=True)
        lam_ns[key] = Lam
    return Lam



# ---------------------------------------------------------------------------
# Cached dexpinv matrices Jinv(phi)  (SO(3) axis-angle principal ball)
# ---------------------------------------------------------------------------

def _overlap_and_bbox(mask_i, mask_j, thr):
    """
    Return (ov, (y0,y1,x0,x1)) where ov is boolean overlap on full grid,
    and bbox tightly crops to the minimal rectangle that contains ov==True.
    If no overlap, returns (ov, None).
    """
    
    mi = np.asarray(mask_i, np.float32) > float(thr)
    mj = np.asarray(mask_j, np.float32) > float(thr)
    ov = (mi & mj)
    if not np.any(ov):
        return ov, None
    ys, xs = np.nonzero(ov)
    y0, y1 = int(ys.min()), int(ys.max()) + 1
    x0, x1 = int(xs.min()), int(xs.max()) + 1
    return ov, (y0, y1, x0, x1)


def _jinv_key(agent: Any, which: str) -> Tuple[str, int, str]:
    # which in {"q","p"}
    return ("jinv", _aid(agent), which)

def _alpha_theta(theta: np.ndarray, theta2: np.ndarray) -> np.ndarray:
    """
    Your existing LUT/Taylor alpha(θ) helper. If you already have one
    (e.g., in natural_gradient.py), import and call that instead.
    """
    # Minimal stable version (feel free to swap for your LUT):
    eps = 1e-12
    out = np.empty_like(theta, dtype=np.float32)
    small = theta < 1e-3
    # Taylor: alpha ≈ 1/12 + θ²/720
    out[small] = (1.0/12.0 + theta2[small] * (1.0/720.0)).astype(np.float32)
    # General: alpha = (1/θ²)(1 - (θ/2)cot(θ/2))
    t = theta[~small]
    t2 = theta2[~small]
    half = 0.5 * t
    out[~small] = ((1.0 / np.maximum(t2, eps)) * (1.0 - half * (np.cos(half) / np.maximum(np.sin(half), eps)))).astype(np.float32)
    return out

def build_dexpinv_matrix(phi):
    """
    Vectorized Jinv(phi) for last-dim=3 axis-angle.
    Uses small-φ fast path: if all ‖φ‖ < 1e-6 on a tile, Jinv ≈ I (skip math).
    """
    
    phi = np.asarray(phi, np.float32)
    if phi.shape[-1] != 3:
        raise ValueError(f"build_dexpinv_matrix: phi last dim must be 3, got {phi.shape}")
    th2 = np.einsum("...i,...i->...", phi, phi)
    th  = np.sqrt(th2)
    I = np.eye(3, dtype=np.float32)

    # all-small fast path
    if np.all(th < 1e-6):
        return np.broadcast_to(I, phi.shape[:-1] + (3, 3)).copy()

    alpha = _alpha_theta(th, th2)

    # skew(φ)
    K = np.zeros(phi.shape[:-1] + (3, 3), np.float32)
    K[..., 0, 1], K[..., 0, 2] = -phi[..., 2],  phi[..., 1]
    K[..., 1, 0], K[..., 1, 2] =  phi[..., 2], -phi[..., 0]
    K[..., 2, 0], K[..., 2, 1] = -phi[..., 1],  phi[..., 0]

    outer = phi[..., :, None] * phi[..., None, :]
    c0 = (1.0 - alpha * th2)[..., None, None]
    c1 = -0.5
    c2 = alpha[..., None, None]
    return (c0 * I) + (c1 * K) + (c2 * outer)


def Jinv_grid(ctx, agent, which="q", bbox=None):
    """
    Cached Jinv(phi) per pixel (3x3). If bbox=(y0,y1,x0,x1) is given,
    compute/cache only that window (and store the full grid lazily).
    """
    ns = ctx.cache.ns("jinv")
    key = ("jinv", int(getattr(agent, "id", id(agent))), which)
    J = ns.get(key)
    if J is None:
        phi = _get_phi(agent, which)  # (...,3)
        phi = np.where(np.isfinite(phi), phi, 0.0).astype(np.float32)
        J = build_dexpinv_matrix(phi)  # (...,3,3)
        ns[key] = J
        if bbox is None:
            return J
    if bbox is None:
        return J
    y0,y1,x0,x1 = bbox
    return J[y0:y1, x0:x1, :, :]


def warm_Jinv(ctx: Any, agents: Sequence[Any], whiches: Iterable[str] = ("q", "p")) -> None:
    """Precompute Jinv for many agents (idempotent)."""
    for a in agents:
        for w in whiches:
            try:
                _ = Jinv_grid(ctx, a, which=w)
            except Exception:
                pass

# ---------------------------------------------------------------------------
# Bundle morphisms (same-level) and cross-scale morphisms (Θ)
# Cached per-step in "morphism" and "theta" namespaces
# ---------------------------------------------------------------------------

def _morphism_key(agent: Any, kind: str) -> Tuple[str, int, str]:
    # kind in {"q_to_p", "p_to_q"}
    return ("morphism", _aid(agent), kind)

def _theta_key(child: Any, parent: Any, direction: str) -> Tuple[str, int, int, str]:
    # direction in {"down", "up"}
    return ("theta", _aid(child), _aid(parent), direction)


def _get_phi0(agent: Any, kind: str) -> np.ndarray:
    """
    Fetch the base (static) morphism matrices from the agent:
      - kind="q_to_p" -> agent.bundle_morphism_q_to_p (Φ_0), shape (..., Kp, Kq)
      - kind="p_to_q" -> agent.bundle_morphism_p_to_q (Φ̃_0), shape (..., Kq, Kp)
    """
    if kind == "q_to_p":
        M = getattr(agent, "bundle_morphism_q_to_p", None)
        name = "bundle_morphism_q_to_p"
    else:
        M = getattr(agent, "bundle_morphism_p_to_q", None)
        name = "bundle_morphism_p_to_q"
    if M is None:
        raise ValueError(f"[transport_cache] missing {name} on agent id={_aid(agent)}")
    return M


def Phi(ctx, agent, kind: str = "q_to_p"):
    ns  = ctx.cache.ns("morphism")
    key = _morphism_key(agent, kind)
    M = ns.get(key)
    if M is not None:
        return M

    # Delegate to the unified builder (ctx-aware, uses exp_grid_cached)
    
    Gq = getattr(agent, "generators_q", None)
    Gp = getattr(agent, "generators_p", None)
    Phi_0 = getattr(agent, "Phi_0", None)
    Phi_tilde_0 = getattr(agent, "Phi_tilde_0", None)

    # Build both once; cache both
    Phi_full, Phit_full = compute_direct_morphisms(
        phi=getattr(agent, "phi"),
        phi_model=getattr(agent, "phi_model"),
        generators_q=Gq,
        generators_p=Gp,
        Phi_0=(np.asarray(Phi_0)       if Phi_0       is not None else np.eye(agent.mu_p_field.shape[-1], agent.mu_q_field.shape[-1], dtype=np.float32)),
        Phi_tilde_0=(np.asarray(Phi_tilde_0) if Phi_tilde_0 is not None else np.eye(agent.mu_q_field.shape[-1], agent.mu_p_field.shape[-1], dtype=np.float32)),
        ctx=ctx,
    )

    ns[_morphism_key(agent, "q_to_p")] = Phi_full
    ns[_morphism_key(agent, "p_to_q")] = Phit_full

    return Phi_full if kind == "q_to_p" else Phit_full


def Phi_tilde(ctx: Any, agent: Any) -> np.ndarray:
    """Shortcut for kind='p_to_q'."""
    return Phi(ctx, agent, kind="p_to_q")


def Theta_dn(ctx, child, parent):
    Lq = Lambda_dn(ctx, child, parent, which="q")  # (..., Kq_c, Kq_p)
    Lp = Lambda_dn(ctx, child, parent, which="p")  # (..., Kp_c, Kp_p)
    Phi_c   = Phi(ctx, child, kind="q_to_p")       # (..., Kp_c, Kq_c)
    Phit_c  = Phi(ctx, child, kind="p_to_q")       # (..., Kq_c, Kp_c)
    _assert_chain("Theta_dn.q", Phit_c, Lp)        # (Kq_c×Kp_c) @ (Kp_c×Kp_p)
    _assert_chain("Theta_dn.p", Phi_c,  Lq)        # (Kp_c×Kq_c) @ (Kq_c×Kq_p)
    Theta_q = np.einsum("...ik,...kj->...ij", Phit_c, Lp, optimize=True)  # (..., Kq_c, Kp_p)
    Theta_p = np.einsum("...ik,...kj->...ij", Phi_c,  Lq, optimize=True)  # (..., Kp_c, Kq_p)
    out = {"q": Theta_q, "p": Theta_p}
    ctx.cache.ns("theta")[_theta_key(child, parent, "down")] = out
    return out

def Theta_up(ctx, child, parent):
    Lq = Lambda_up(ctx, child, parent, which="q")  # (..., Kq_p, Kq_c)
    Lp = Lambda_up(ctx, child, parent, which="p")  # (..., Kp_p, Kp_c)
    Phi_p   = Phi(ctx, parent, kind="q_to_p")      # (..., Kp_p, Kq_p)
    Phit_p  = Phi(ctx, parent, kind="p_to_q")      # (..., Kq_p, Kp_p)
    _assert_chain("Theta_up.q",  Phit_p, Lp)       # (Kq_p×Kp_p) @ (Kp_p×Kp_c)
    _assert_chain("Theta_up.p",  Phi_p,  Lq)       # (Kp_p×Kq_p) @ (Kq_p×Kq_c)
    Theta_q = np.einsum("...ik,...kj->...ij", Phit_p, Lp, optimize=True)  # (..., Kq_p, Kp_c)
    Theta_p = np.einsum("...ik,...kj->...ij", Phi_p,  Lq, optimize=True)  # (..., Kp_p, Kq_c)
    out = {"q": Theta_q, "p": Theta_p}
    ctx.cache.ns("theta")[_theta_key(child, parent, "up")] = out
    return out




# ---------------------------------------------------------------------------
# Warming & invalidation
# ---------------------------------------------------------------------------

def warm_E(ctx: Any, agents: Sequence[Any], whiches: Iterable[str] = ("q", "p")) -> None:
    """Precompute exp(φ) for many agents (idempotent)."""
    for a in agents:
        for w in whiches:
            try:
                _ = E_grid(ctx, a, which=w)
            except Exception:
                # Keep warm-up best-effort; avoid failing the whole pass.
                pass

def warm_Omega(ctx: Any, pairs: Sequence[Tuple[Any, Any]], which: str = "q") -> None:
    """Precompute Ω_{ij} for (i, j) pairs (idempotent)."""
    for (ai, aj) in pairs:
        try:
            _ = Omega(ctx, ai, aj, which=which)
        except Exception:
            pass

def invalidate_agent(ctx: Any, agent: Any) -> None:
    aid = _aid(agent)
    for ns_name in ("exp", "omega", "lambda", "jinv"):  # <-- added "jinv"
        ns = ctx.cache.ns(ns_name)
        to_kill = [k for k in list(ns.keys())
                   if isinstance(k, tuple) and (aid in k)]
        for k in to_kill:
            ns.pop(k, None)



# ---------------------------------------------------------------------------
# Transitional compatibility helpers (optional)
# ---------------------------------------------------------------------------

def get_or_build_E(ctx: Optional[Any], agent: Any, which: str = "q") -> np.ndarray:
    """
    Transitional shim: if ctx given, returns E_grid(ctx,...); else computes
    exp_lie_algebra_irrep on the fly (no caching). Useful for gradual adoption.
    """
    if ctx is None:
        G = _get_generators(agent, which)
        phi = _get_phi(agent, which)
        return exp_lie_algebra_irrep(phi, G)
    return E_grid(ctx, agent, which=which)

def _matmul_shapes_ok(A, B):
    # A(..., i, k) @ B(..., k, j) -> (..., i, j)
    if A is None or B is None:
        return False
    if A.ndim < 2 or B.ndim < 2:
        return False
    return A.shape[-1] == B.shape[-2]

def _assert_chain(name, *mats):
    # Ensure M1@M2@... is dimensionally valid
    for idx in range(len(mats) - 1):
        if not _matmul_shapes_ok(mats[idx], mats[idx+1]):
            a = mats[idx].shape if mats[idx] is not None else None
            b = mats[idx+1].shape if mats[idx+1] is not None else None
            raise ValueError(f"[{name}] shape mismatch at link {idx}: {a} @ {b}")


