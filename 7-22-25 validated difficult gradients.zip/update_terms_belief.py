# -*- coding: utf-8 -*-
"""
Created on Sat Jul 19 08:12:50 2025

@author: chris and christine
"""
import numpy as np
import config
from joblib import Parallel, delayed

from natural_gradient_utils import (
    apply_natural_gradient_batch,
    apply_lie_natural_gradient,
    compute_inverse_fisher_field
)

from numerical_utils import sanitize_sigma
from mask_utils import clip_and_mask_gradient, clip_and_mask_morphism
from numerical_utils import safe_inv

from get_generators import get_generators
from generalized_math_utils import unpack_phi_update_params
from generalized_omega import compute_curvature_gradient_analytical, exp_lie_algebra_irrep

from generalized_omega import dexpinv_operator, dexpinv_operator_covariance
from natural_gradient_utils import compute_fisher_geometry_gradient, kl_gradient_mu_sigma
from generalized_math_utils import ( 
        zero_mu_sigma_like, apply_mask_to_mu_sigma
        )
from natural_gradient_utils import transport_gaussian
from bundle_morphism_utils import safe_batch_apply_morphism
from generalized_math_utils import ( 
        zero_mu_sigma_like, compute_mu_sigma_diff,
        apply_mask_to_mu_sigma
        )
#from update_terms_model import grad_self_field, grad_variance_penalty_field
from morphism_gradient_self_energy import grad_morphism_self_energy
from grad_phi_belief_alignment import grad_kl_wrt_phi_i, grad_kl_wrt_phi_j



def grad_self_field(agent_i, alpha, field_type="belief", mask=None,
                             phi_morphism=None, phi_tilde_morphism=None):
    """
    Compute raw Euclidean gradient of morphism-aware self-alignment:
  - field_type="belief" → ∂KL(q || Φ̃·p)
  - field_type="model" → ∂KL(p || Φ·q)

    The morphism acts as:
  - Φ   : q → p  (for feedback, model side)
  - Φ̃  : p → q  (for self-alignment, belief side)

    Notes:
    - For field="belief", p is pulled into q-space using Φ̃.
    - For field="model", q is pulled into p-space using Φ.
"""

    if alpha <= 0:
        return zero_mu_sigma_like(agent_i)

    H, W = agent_i.grid_shape

    if field_type == "belief":
        mu_q, sigma_q = agent_i.mu_q_field, agent_i.sigma_q_field  # q-space
        mu_p, sigma_p = agent_i.mu_p_field, agent_i.sigma_p_field  # p-space
        K_q = mu_q.shape[-1]
        K_p = mu_p.shape[-1]

        if phi_morphism is not None:
            Phi = phi_morphism  # should be (..., K_q, K_p)
        else:
            eye = np.eye(K_q, K_p, dtype=mu_q.dtype)  # p → q maps from K_p to K_q
            Phi = np.broadcast_to(eye, (H, W, K_q, K_p))

        mu_p_trans, sigma_p_trans = safe_batch_apply_morphism(mu_p, sigma_p, Phi, eps=config.eps)
        dμ, dΣ = compute_mu_sigma_diff(mu_q, sigma_q, mu_p_trans, sigma_p_trans, direction="a_minus_b")

    elif field_type == "model":
        mu_q, sigma_q = agent_i.mu_q_field, agent_i.sigma_q_field
        mu_p, sigma_p = agent_i.mu_p_field, agent_i.sigma_p_field
        K_q = mu_q.shape[-1]
        K_p = mu_p.shape[-1]

        if phi_tilde_morphism is not None:
            Phi_tilde = phi_tilde_morphism  # should be (..., K_p, K_q)
        else:
            eye = np.eye(K_p, K_q, dtype=mu_q.dtype)  # q → p maps from K_q to K_p
            Phi_tilde = np.broadcast_to(eye, (H, W, K_p, K_q))

        mu_q_trans, sigma_q_trans = safe_batch_apply_morphism(mu_q, sigma_q, Phi_tilde, eps=config.eps)
        dμ, dΣ = compute_mu_sigma_diff(mu_p, sigma_p, mu_q_trans, sigma_q_trans, direction="a_minus_b")

    else:
        raise ValueError(f"[grad_self_field_morphism] Unknown field_type: {field_type}")

    dμ = np.nan_to_num(dμ)
    dΣ = np.nan_to_num(dΣ)

    if mask is not None:
        dμ, dΣ = apply_mask_to_mu_sigma(dμ, dΣ, mask)

    return alpha * dμ, alpha * dΣ



#refactor into future below
def compute_alignment_kl_gradient_belief(agent_i, agents, generators, params):
    """
    Compute the covariant natural gradient of KL(q_i || Ω_ij q_j) for beliefs.
    """
    beta = params.get("beta", config.beta)
    if beta <= 0:
        return np.zeros_like(agent_i.mu_q_field), np.zeros_like(agent_i.sigma_q_field)

    mu_i = agent_i.mu_q_field
    sigma_i = agent_i.sigma_q_field
    Omega_i = agent_i._exp_phi
    Omega_i = Omega_i.reshape(*mu_i.shape[:-1], mu_i.shape[-1], mu_i.shape[-1])

    delta_mu = np.zeros_like(mu_i)
    delta_sigma = np.zeros_like(sigma_i)

    for nb in agent_i.neighbors:
        agent_j = agents[nb["id"]]

        mu_j = agent_j.mu_q_field
        sigma_j = agent_j.sigma_q_field
        Omega_j_inv = agent_j._exp_neg_phi
        Omega_j_inv = Omega_j_inv.reshape(*mu_j.shape[:-1], mu_j.shape[-1], mu_j.shape[-1])

        mask_overlap = (agent_i.mask * agent_j.mask) > config.support_cutoff_eps
        if not np.any(mask_overlap):
            continue

        Omega_ij = np.einsum("...ik,...kj->...ij", Omega_i, Omega_j_inv)

        # Transport the Gaussian
        mu_j_t, sigma_j_t = transport_gaussian(mu_j, sigma_j, Omega_ij)

        sigma_j_t = sanitize_sigma(sigma_j_t, eps=config.eps)

        delta_mu_step, delta_sigma_step = kl_gradient_mu_sigma(
            mu_i, sigma_i, mu_j_t, sigma_j_t, mask=mask_overlap
        )

        delta_mu += delta_mu_step
        delta_sigma += delta_sigma_step

    return delta_mu, beta * delta_sigma
#refactor into future
def alignment_gradient_field_belief(agent_i, agents, params, mask=None):
    """
    Raw Euclidean gradient of alignment KL divergence for beliefs:
        KL(q_i || Ω_ij q_j)

    Args:
        agent_i    : focal agent
        agents     : list of agents
        params     : dict of parameters
        mask       : optional spatial mask to restrict update region

    Returns:
        dμ, dΣ : raw Euclidean gradients (H, W, K), (H, W, K, K)
    """
    weight = params.get("beta", config.beta)

    if weight <= 0:
        return zero_mu_sigma_like(agent_i, field="belief")

    K_fiber = agent_i.mu_q_field.shape[-1]

    # Load or generate the appropriate representation generators
    generators = params.get("generators", get_generators(config.group_name, K_fiber))

    # Compute raw KL alignment gradients for beliefs
    dμ, dΣ = compute_alignment_kl_gradient_belief(agent_i, agents, generators, params)

    # Ensure numerical stability
    dμ = np.nan_to_num(dμ)
    dΣ = np.nan_to_num(dΣ)

    # Apply optional mask
    if mask is not None:
        dμ, dΣ = apply_mask_to_mu_sigma(dμ, dΣ, mask)

    return weight * dμ, weight * dΣ

#Future
def alignment_kl_natgrad_belief(agent_i, agents, params, mask=None):
    """
    Compute the covariant natural gradient of KL(q_i || Ω_ij q_j) over neighbors.

    Args:
        agent_i : focal agent
        agents  : list of all agents
        params  : dict of hyperparameters (must contain "beta")
        mask    : optional mask to restrict update region

    Returns:
        delta_mu     : natural gradient for μ_q, shape (H, W, K)
        delta_sigma  : natural gradient for Σ_q, shape (H, W, K, K)
    """
    beta = params.get("beta", config.beta)
    if beta <= 0:
        return zero_mu_sigma_like(agent_i, field="belief")

    mu_i = agent_i.mu_q_field
    sigma_i = sanitize_sigma(agent_i.sigma_q_field, eps=config.eps)
    Omega_i = agent_i._exp_phi.reshape(*mu_i.shape[:-1], mu_i.shape[-1], mu_i.shape[-1])

    delta_mu = np.zeros_like(mu_i)
    delta_sigma = np.zeros_like(sigma_i)

    for nb in agent_i.neighbors:
        agent_j = agents[nb["id"]]
        mu_j = agent_j.mu_q_field
        sigma_j = agent_j.sigma_q_field
        Omega_j_inv = agent_j._exp_neg_phi.reshape(*mu_j.shape[:-1], mu_j.shape[-1], mu_j.shape[-1])

        # Ω_ij = Ω_i · Ω_j⁻¹
        Omega_ij = np.einsum("...ik,...kj->...ij", Omega_i, Omega_j_inv)

        # Overlap region
        overlap = (agent_i.mask * agent_j.mask) > config.support_cutoff_eps
        if not np.any(overlap):
            continue

        # Transport q_j into q_i’s frame
        mu_j_t, sigma_j_t = transport_gaussian(mu_j, sigma_j, Omega_ij)
        sigma_j_t = sanitize_sigma(sigma_j_t, eps=config.eps)

        # Compute natural gradient
        dμ, dΣ = kl_gradient_mu_sigma(mu_i, sigma_i, mu_j_t, sigma_j_t, mask=overlap)
        delta_mu += dμ
        delta_sigma += dΣ

    # Final optional mask (global constraint)
    if mask is not None:
        delta_mu, delta_sigma = apply_mask_to_mu_sigma(delta_mu, delta_sigma, mask)

    return beta * delta_mu, beta * delta_sigma


def accumulate_phi_gradient_belief(agent_i, agent_j, generators, params, field="phi"):
    """
    Compute and accumulate the variational gradient:
        ∂/∂φ_i KL(q_i ‖ Ω_ij q_j)
    where Ω_ij = exp(φ_i) · exp(−φ_j) for beliefs.
    """
    assert field == "phi", f"Expected field='phi', got {field}"
    assert generators.ndim == 3, f"Expected generators shape (d, K, K), got {generators.shape}"
    d, K1, K2 = generators.shape
    assert K1 == K2, f"Generators must be square: got {K1}×{K2}"

    beta = params.get("beta", config.beta)
    if beta <= 0:
        return

    eps = config.support_cutoff_eps
    mask_i = agent_i.mask[..., None] > eps
    mask_j = agent_j.mask[..., None] > eps
    joint_mask = mask_i & mask_j

    mu_i, sigma_i = agent_i.mu_q_field, agent_i.sigma_q_field
    mu_j, sigma_j = agent_j.mu_q_field, agent_j.sigma_q_field
    phi_i, phi_j = agent_i.phi, agent_j.phi

    exp_phi_i = exp_lie_algebra_irrep(phi_i, generators)
    exp_phi_j = exp_lie_algebra_irrep(phi_j, generators)
    exp_neg_phi_j = exp_lie_algebra_irrep(-phi_j, generators)

    Omega_ij = np.einsum("...ik,...kj->...ij", exp_phi_i, exp_neg_phi_j)
    Omega_T = np.swapaxes(Omega_ij, -1, -2)

    mu_trans = np.einsum("...ij,...j->...i", Omega_ij, mu_j)
    sigma_trans = np.einsum("...ik,...kl,...jl->...ij", Omega_ij, sigma_j, Omega_T)
    sigma_trans = sanitize_sigma(sigma_trans, eps=config.eps)
    sigma_inv = safe_inv(sigma_trans, eps=config.eps)

    delta_mu = mu_i - mu_trans
    d_mu = -np.einsum("...ij,...j->...i", sigma_inv, delta_mu)
    delta_sigma = sigma_i - sigma_trans
    d_sigma = -0.5 * np.einsum("...ik,...kl,...lj->...ij", sigma_inv, delta_sigma, sigma_inv)

    # Batched gradients over all Lie algebra directions
    grad_phi_i_raw = grad_kl_wrt_phi_i(
        mu_i, sigma_i, mu_j, sigma_j, Omega_ij, generators, eps=config.eps
    )  # shape (H, W, d)

    grad_phi_j_raw = grad_kl_wrt_phi_j(
        mu_i, sigma_i, mu_j, sigma_j, Omega_ij,
        generators, exp_phi_j, exp_neg_phi_j, eps=config.eps
    )  # shape (H, W, d)

    assert grad_phi_i_raw.shape[-1] == d, f"Expected grad_phi_i[..., d={d}], got {grad_phi_i_raw.shape}"
    assert grad_phi_j_raw.shape[-1] == d, f"Expected grad_phi_j[..., d={d}], got {grad_phi_j_raw.shape}"

    # Natural gradients
    grad_phi_mu_i = dexpinv_operator(phi_i, grad_phi_i_raw, generators)
    grad_phi_mu_j = dexpinv_operator(phi_j, grad_phi_j_raw, generators)
    grad_phi_sigma_i = dexpinv_operator_covariance(phi_i, d_sigma, generators)
    grad_phi_sigma_j = dexpinv_operator_covariance(phi_j, -d_sigma, generators)

    grad_phi_i = grad_phi_mu_i + grad_phi_sigma_i
    grad_phi_j = grad_phi_mu_j + grad_phi_sigma_j

    agent_i.grad_phi += beta * grad_phi_i * joint_mask
    agent_j.grad_phi += beta * grad_phi_j * joint_mask





def compute_phi_update_belief(agent_i, agents, params, field="phi"):
    """
    Unified update for φ (belief alignment).
    Applies Lie-natural gradient to alignment + optional regularizers for beliefs.
    """
    if field == "phi" and getattr(config, "identical_beliefs", False):
        return np.zeros_like(agent_i.phi)

    # --- Unpack core parameters ---
    unpacked  = unpack_phi_update_params(params, field=field)
    β         = params.get("beta", config.beta)
    κ         = unpacked["κ"]
    gw        = unpacked["gw"]
    curv_w    = unpacked["curv_weight"]
    clip_th   = unpacked["grad_clip_threshold"]
    eps       = unpacked["overlap_eps"]
    debug     = unpacked["debug"]

    phi       = agent_i.phi  # Belief field
    phi_tilde = agent_i.phi_model  # Model field
    soft_mask = agent_i.mask[..., None]
    generators_q = params.get("generators_q", get_generators(config.group_name, config.K_q))

    if not np.any(soft_mask > eps):
        return np.zeros_like(phi)

    grad = np.zeros_like(phi)

    # --- 1. Alignment gradient (Lie-natural, variationally consistent) ---
    grad_align = np.zeros_like(phi)
    if β > 0:
        for neighbor in agent_i.neighbors:
            agent_j = agents[neighbor["id"]]
            accumulate_phi_gradient_belief(agent_i, agent_j, generators_q, params, field=field)
        grad_align = agent_i.grad_phi.copy()
        agent_i.grad_phi[:] = 0.0

        grad += apply_lie_natural_gradient(phi, grad_align, G_inv=compute_inverse_fisher_field(agent_i, generators_q, field=field))

    # --- 2. Curvature gradient ---
    if curv_w > 0:
        grad_curv = compute_curvature_gradient_analytical(phi, generators_q)
        grad += curv_w * grad_curv

    # --- 3. Mass term: 2γ φ ---
    if gw > 0:
        grad += 2 * gw * phi

    # --- 4. φ–φ̃ coupling ---
    if κ > 0:
        grad += 2 * κ * (phi - phi_tilde)

    # --- 5. Optional Fisher geometry term ---
    fisher_key = "fisher_geometry_weight"
    fisher_weight = params.get(fisher_key, getattr(config, fisher_key, 0.0))
    if fisher_weight > 0:
        fisher_grad = compute_fisher_geometry_gradient(agent_i, agents, params)
        grad += fisher_weight * fisher_grad

    # --- Final clip + mask ---
    return clip_and_mask_gradient(grad, soft_mask, clip_th, eps)


