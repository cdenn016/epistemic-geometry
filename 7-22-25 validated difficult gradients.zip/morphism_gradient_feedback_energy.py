# -*- coding: utf-8 -*-
"""
Created on Sun Jul 20 10:47:49 2025

@author: chris and christine
"""

import numpy as np
from scipy.linalg import inv

import numpy as np
from scipy.linalg import inv
import numpy as np
import config
from joblib import Parallel, delayed

from natural_gradient_utils import (
    apply_natural_gradient_batch,
    apply_lie_natural_gradient,
    compute_inverse_fisher_field
)

from numerical_utils import sanitize_sigma
from mask_utils import clip_and_mask_gradient, clip_and_mask_morphism
from numerical_utils import safe_inv

from get_generators import get_generators
from generalized_math_utils import unpack_phi_update_params
from generalized_omega import compute_curvature_gradient_analytical, exp_lie_algebra_irrep

from generalized_omega import dexpinv_operator, dexpinv_operator_covariance
from natural_gradient_utils import compute_fisher_geometry_gradient, kl_gradient_mu_sigma
from generalized_math_utils import ( 
        zero_mu_sigma_like, apply_mask_to_mu_sigma
        )
from natural_gradient_utils import transport_gaussian
from bundle_morphism_utils import safe_batch_apply_morphism
from generalized_math_utils import ( 
        zero_mu_sigma_like, compute_mu_sigma_diff,
        apply_mask_to_mu_sigma
        )


import numpy as np


def grad_morphism_feedback_energy(agent_i, feedback_weight, mask=None, eps=1e-8):
    """
    Compute full gradient ∂/∂Φ KL(p || Φ·q) over spatial grid (H, W)
    """
    mu_q    = agent_i.mu_q_field
    sigma_q = agent_i.sigma_q_field
    mu_p    = agent_i.mu_p_field
    sigma_p = agent_i.sigma_p_field
    Phi     = agent_i.bundle_morphism_q_to_p

    grad = compute_morphism_kl_gradient_batched(
        Phi, mu_q, sigma_q, mu_p, sigma_p, eps=eps
    )

    if mask is not None:
        grad *= mask[..., None, None]  # shape (H, W, 1, 1)

    return feedback_weight * grad


def compute_morphism_kl_gradient_batched(Phi, mu_q, Sigma_q, mu_p, Sigma_p, eps=1e-8):
    """
    Batched version of ∂/∂Φ D_KL(p || Φ·q) for spatial grid.
    
    Args:
        Phi      : (H, W, K_p, K_q)
        mu_q     : (H, W, K_q)
        Sigma_q  : (H, W, K_q, K_q)
        mu_p     : (H, W, K_p)
        Sigma_p  : (H, W, K_p, K_p)
        eps      : float, SPD regularization
    
    Returns:
        grad     : (H, W, K_p, K_q) KL gradient w.r.t. Φ at each spatial location
    """
    H, W, K_p, K_q = Phi.shape
    grad = np.zeros_like(Phi)

    for i in range(H):
        for j in range(W):
            grad[i, j] = compute_morphism_kl_gradient_feedback(
                Phi[i, j], mu_q[i, j], Sigma_q[i, j],
                mu_p[i, j], Sigma_p[i, j], eps=eps
            )

    return grad


def compute_morphism_kl_gradient_primitives(Phi, mu_q, Sigma_q, mu_p, Sigma_p, eps=1e-8):
    """
    Compute shared intermediates needed to evaluate ∂/∂Φ D_KL(p || Φ·q)
    
    Args:
        Phi      : (K_p, K_q) linear morphism matrix Φ
        mu_q     : (K_q,)     mean of belief q
        Sigma_q  : (K_q, K_q) covariance of belief q
        mu_p     : (K_p,)     mean of model p
        Sigma_p  : (K_p, K_p) covariance of model p
        eps      : stabilizer for SPD inverse

    Returns:
        dict containing:
            - Delta_mu     : (K_p,)     = mu_p - Φ·mu_q
            - Sigma_q_inv  : (K_q, K_q)
            - M            : (K_p, K_p) = Φ Σ_q Φᵀ
            - M_inv        : (K_p, K_p)
            - term_trace   : (K_p, K_p) = M⁻¹ Σ_p M⁻¹
            - term_logdet  : (K_p, K_q) = M⁻¹ Φ Σ_q
    """
    K_p, K_q = Phi.shape

    # Compute Δμ = μ_p - Φ·μ_q
    Delta_mu = mu_p - Phi @ mu_q

    # Inverse of Σ_q
    Sigma_q_inv = safe_inv(Sigma_q, eps=eps)

    # M = Φ Σ_q Φᵀ
    M = Phi @ Sigma_q @ Phi.T

    # Inverse of M
    M_inv = safe_inv(M, eps=eps)

    # Precompute reusable trace/logdet gradient terms
    term_trace = 0.5*M_inv @ Sigma_p @ M_inv  # (K_p, K_p)
    term_logdet = 0.5* M_inv @ Phi @ Sigma_q  # (K_p, K_q)

    return {
        "Delta_mu": Delta_mu,
        "Sigma_q_inv": Sigma_q_inv,
        "M": M,
        "M_inv": M_inv,
        "term_trace": term_trace,
        "term_logdet": term_logdet
    }


def compute_morphism_kl_gradient_feedback(Phi, mu_q, Sigma_q, mu_p, Sigma_p, eps=1e-8):
    """
    Compute ∂/∂Φ D_KL(p || Φ·q) using decomposed analytic form.

    Args:
        Phi      : (K_p, K_q) morphism matrix Φ
        mu_q     : (K_q,)     mean of q
        Sigma_q  : (K_q, K_q) covariance of q
        mu_p     : (K_p,)     mean of p
        Sigma_p  : (K_p, K_p) covariance of p
        eps      : regularization for safe inverse

    Returns:
        grad_Phi : (K_p, K_q) gradient of KL divergence w.r.t. Φ
    """
    # Get all shared quantities
    primitives = compute_morphism_kl_gradient_primitives(
        Phi, mu_q, Sigma_q, mu_p, Sigma_p, eps=eps
    )

    Delta_mu     = primitives["Delta_mu"]        # (K_p,)
    Sigma_q_inv  = primitives["Sigma_q_inv"]     # (K_q, K_q)
    M_inv        = primitives["M_inv"]           # (K_p, K_p)
    term_trace   = primitives["term_trace"]      # (K_p, K_p)
    term_logdet  = primitives["term_logdet"]     # (K_p, K_q)

    
    # Term 1:  M⁻¹ ΔμΔμ^TM⁻¹ Φ Σ_q
  
    term2 =  M_inv @ np.outer(Delta_mu, Delta_mu) @ M_inv @ Phi @ Sigma_q


    # Term 3: + M⁻¹ Φ Σ_q
    term3 = term_logdet

    # Term 4: - M⁻¹ Σ_p M⁻¹ Φ Σ_q
    term4 = - term_trace @ Phi @ Sigma_q

    # Total gradient
    grad_Phi =  term2 + term3 + term4

    return grad_Phi



















