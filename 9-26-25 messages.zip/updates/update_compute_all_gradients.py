from __future__ import annotations

"""
Created on Tue Aug 12 20:15:47 2025

@author: chris and christine
"""
import time

from threadpoolctl import threadpool_limits

import numpy as np
from core.numerical_utils import safe_omega_inv, sanitize_sigma
from core.omega import (retract_phi_principal, exp_lie_algebra_irrep, 
                        d_exp_exact, inverse_fisher_metric_field )

from updates.update_terms_phi import ( 
    accumulate_phi_morphism_self_feedback, accumulate_phi_alignment_gradient,
    grad_feedback_phi_direct, grad_feedback_phi_tilde_direct, grad_self_phi_direct,
    grad_self_phi_tilde_direct )

from updates.update_terms_mu_sigma import accumulate_mu_sigma_gradient
from updates.update_helpers import dirty_manager
from updates.update_terms_VFE import _theta_stats_from_children, theta_gradients_for_agent

from joblib import Parallel, delayed
from runtime_context import cfg_get
from utils import get_neighbors, zero_all_gradients, _aid
from core.transport_cache import E_grid, ensure_global_A
from updates.update_terms_curvature_A import covariant_frame_energy_and_grads

from core.transport_cache import build_dexpinv_matrix , Jinv_grid
from utils import _joint_mask

# unified metadata for phi vs phi_tilde blocks
_FIELD_META = {
    "phi": {
        "which": "q",
        "beta_key": "beta",
        "mu_key": "mu_q_field",
        "sigma_key": "sigma_q_field",
        "fisher_inv_key": "inverse_fisher_phi",
        "grad_key": "grad_phi",
        "phi_attr": "phi",
        "qall_func": d_exp_exact,
    },
    "phi_model": {
        "which": "p",
        "beta_key": "beta_model",
        "mu_key": "mu_p_field",
        "sigma_key": "sigma_p_field",
        "fisher_inv_key": "inverse_fisher_phi_model",
        "grad_key": "grad_phi_tilde",
        "phi_attr": "phi_model",
        "qall_func": d_exp_exact,
    },
}



def _alignment_block(agent_i, neighbors, generators,  *, field: str, ctx):
    """
    Compute same-level alignment gradients for 'phi' or 'phi_model'.
    """
    if not neighbors:
        return 0.0

    meta = _FIELD_META[field]
    t0 = time.perf_counter()

    # Q_all for agent_i once
    phi_i = getattr(agent_i, meta["phi_attr"])
    Q_all_i = meta["qall_func"](phi_i, generators)

    # loop neighbors
    for agent_j in neighbors:

        # Build exp(-φ_j) from central cache if available, else local
        if ctx is not None:
            Ej = E_grid(ctx, agent_j, which=meta["which"])
            exp_neg_phi_j = safe_omega_inv(Ej)
        else:
            phi_j = getattr(agent_j, meta["phi_attr"])
            Ej = exp_lie_algebra_irrep(phi_j, generators)
            exp_neg_phi_j = safe_omega_inv(Ej)

        # accumulate alignment grad
        accumulate_phi_alignment_gradient(ctx,
            agent_i, agent_j, generators,
            field=field,
            beta_key=meta["beta_key"],
            omega_cache_key=None,                   # ctx handles caching centrally
            mu_key=meta["mu_key"],
            sigma_key=meta["sigma_key"],
            fisher_inv_key=meta["fisher_inv_key"],
            grad_key=meta["grad_key"],
            Q_all_i=Q_all_i,
            exp_neg_phi_j=exp_neg_phi_j,
            agents=None,                            # pass if your impl needs it; else None is fine
        )
        
    return time.perf_counter() - t0





def _morphism_block(agent_i, generators_q, generators_p, *, field: str, ctx):
    meta = _FIELD_META[field]
    t0 = time.perf_counter()

    if field == "phi":
        accumulate_phi_morphism_self_feedback(
            ctx, agent_i, generators_q, generators_p,  # q, p (fixed)
            field="phi",
            fisher_inv_key=meta["fisher_inv_key"],
            grad_key=meta["grad_key"],
            phi_self_func=grad_self_phi_direct,
            phi_feedback_func=grad_feedback_phi_direct,
        )
    else:
        accumulate_phi_morphism_self_feedback(
            ctx, agent_i, generators_q, generators_p,  # q, p (fixed)
            field="phi_model",
            fisher_inv_key=meta["fisher_inv_key"],
            grad_key=meta["grad_key"],
            phi_self_func=grad_self_phi_tilde_direct,
            phi_feedback_func=grad_feedback_phi_tilde_direct,
        )

    return time.perf_counter() - t0



# -----------------------------------
# Disentangled gradient orchestrator
# -----------------------------------


def compute_all_gradients(agent_i, agents, all_agents, generators_q, generators_p, runtime_ctx=None):
    """
    Single-scale gradient orchestrator (no parents / no cross-scale).

      Phase 0: thread runtime ctx
      Phase 1: μ, Σ (belief/model) — same-level only
      Phase 2: (optional) warm local caches for agent_i + neighbors
      Phase 3: φ alignment (belief + model), same-level only
      Phase 4: morphism self + feedback (φ, φ̃), same-level
      Phase 5: return gradients (+ per-agent θ grads; DO NOT APPLY HERE)
    """
    ctx = runtime_ctx

    # reset grads, timers
    zero_all_gradients(agent_i)
    timings = {}

    # -------- Phase 1 — μ, Σ (same-level only) --------
    t0 = time.perf_counter()
    accumulate_mu_sigma_gradient(ctx, agent_i, agents, mode="belief")
    timings["mu_sigma_belief"] = time.perf_counter() - t0

    t0 = time.perf_counter()
    accumulate_mu_sigma_gradient(ctx, agent_i, agents, mode="model")
    timings["mu_sigma_model"] = time.perf_counter() - t0

    # -------- Phase 2a — neighbors --------
    t0 = time.perf_counter()
    neighbors = get_neighbors(agent_i, agents)
    timings["neighbors"] = time.perf_counter() - t0
    timings["neighbors_count"] = len(neighbors) if neighbors else 0  # handy context

    # -------- Phase 2b — Fisher preconditioners (q/p) --------
    eps_val = float(cfg_get(ctx, "eps", 1e-8))

    t0 = time.perf_counter()
    agent_i.inverse_fisher_phi = inverse_fisher_metric_field(
        ctx, agent_i, generators_q, which="q", eps=eps_val
    )
    timings["fisher_q"] = time.perf_counter() - t0

    t0 = time.perf_counter()
    agent_i.inverse_fisher_phi_model = inverse_fisher_metric_field(
        ctx, agent_i, generators_p, which="p", eps=eps_val
    )
    timings["fisher_p"] = time.perf_counter() - t0

    # -------- Phase 3 — φ alignment (same-level only) --------
    if neighbors:
        dt = _alignment_block(agent_i, neighbors, generators_q, field="phi", ctx=ctx)
        timings["phi_alignment"] = dt

        dt = _alignment_block(agent_i, neighbors, generators_p, field="phi_model", ctx=ctx)
        timings["phi_tilde_alignment"] = dt

    # -------- Phase 4 — morphism self + feedback (same-level) --------
    dt = _morphism_block(agent_i, generators_q, generators_p, field="phi", ctx=ctx)
    timings["phi_morphism"] = dt

    dt = _morphism_block(agent_i, generators_q, generators_p, field="phi_model", ctx=ctx)
    timings["phi_tilde_morphism"] = dt

    # -------- Phase 5 — per-agent θ gradients (do NOT apply here) --------
    inbox_nonempty = False
    if getattr(ctx, "obs_bus", None) is not None:
        inbox_nonempty = bool(ctx.obs_bus.take(int(getattr(agent_i, "id", -1))))
    
    disable_theta = bool(cfg_get(ctx, "obs_disable_theta_with_msgs", True))
    
    if disable_theta and inbox_nonempty:
        # Skip theta grads when the agent is message-driven this step
        dtheta_i = None  # or an appropriate zero-like structure if your caller expects it
    else:
        #dtheta_i = None
        dtheta_i = theta_gradients_for_agent(agent_i, ctx)


    if bool(cfg_get(ctx, "debug_grad_timing", False)):
        aid = _aid(agent_i)
        print(f"\n[GRAD TIMINGS] Agent {aid}")
        # pretty print in a stable order
        for k in ("neighbors","neighbors_count",
                  "mu_sigma_belief","mu_sigma_model",
                  "fisher_q","fisher_p",
                  "phi_alignment","phi_tilde_alignment",
                  "phi_morphism","phi_tilde_morphism"):
            if k in timings:
                v = timings[k]
                if k.endswith("_count"):
                    print(f"  {k:22s} : {int(v)}")
                else:
                    print(f"  {k:22s} : {v*1e3:7.2f} ms")

    return (
        (agent_i.grad_mu_q, agent_i.grad_sigma_q),
        (agent_i.grad_mu_p, agent_i.grad_sigma_p),
        agent_i.grad_phi,
        agent_i.grad_phi_tilde,
        dtheta_i,
    )


def apply_phi_updates(agent, grad_phi, grad_phi_m, mask,  *, ctx=None):
                                         
    """
    Constant-step φ / φ̃ update 
         
    """       
    mexp =mask.astype(np.float32)[..., None]  # (H,W,1)

    # --- fixed learning rates
    eta_phi   = float(cfg_get(ctx, "tau_phi", 1e-2))
    eta_phi_m = float(cfg_get(ctx, "tau_phi_model", 1e-2))

    phi      = np.asarray(getattr(agent, "phi"),       np.float32)
    phi_m    = np.asarray(getattr(agent, "phi_model"), np.float32)
    H, W, D  = phi.shape
    assert D == 3, f"agent.phi last dim must be 3, got {phi.shape}"
   
    agent.grad_phi       = np.array(grad_phi,  copy=True)
    agent.grad_phi_tilde = np.array(grad_phi_m, copy=True)

    # --- apply fixed steps (mask-aware); 
    delta_phi   = (eta_phi   * grad_phi ).astype(np.float32, copy=False) * mexp
    delta_phi_m = (eta_phi_m * grad_phi_m).astype(np.float32, copy=False) * mexp

    phi_new  = phi   - delta_phi
    phim_new = phi_m - delta_phi_m

    #print(f"phi new {phi_new}")
    #print(f"phim new {phim_new}")
    # --- retract to principal SO(3) chart   
    agent.phi       = retract_phi_principal(phi_new,  margin=1e-6)
    agent.phi_model = retract_phi_principal(phim_new, margin=1e-6)

    # --- notify runtime that transports/metrics are dirty; no direct warming here
    if cfg_get(ctx,"DEBUG_APPLY", False):
        mean_gphi  = float(np.nanmean(np.linalg.norm(grad_phi,  axis=-1)))
        mean_gphim = float(np.nanmean(np.linalg.norm(grad_phi_m, axis=-1)))
        print(f"[APPLY φ-step] id={getattr(agent,'id',None)} "
              f"τφ={eta_phi:g}, τφ̃={eta_phi_m:g}, "
              f"|gφ|_mean={mean_gphi:.3e}, |gφ̃|_mean={mean_gphim:.3e}\n\n",
              flush=True)
    
    if ctx is not None:
        dirty_manager(ctx).mark(agent, kl = True)



def _apply_sigma_masked(ctx, old_S, dS, tau, mask_bool):
    """
    SPD-safe masked Sigma update:
      S_new = sanitize( S + Δ_scaled ), applied only where mask_bool is True.
    Uses relative trust region ||R||_F <= rho with R = S^{-1/2} Δ S^{-1/2}.
    """
    from runtime_context import cfg_get
    
    # Early exit: nothing active
    if not np.any(mask_bool):
        return old_S

    step_tau = float(tau)                                    # step size for Δ
    eps_tau  = float(cfg_get(ctx, "support_tau", 1e-8))      # SPD floor
    rho      = float(cfg_get(ctx, "sigma_rel_step_max", 0.25))

    # Enforce symmetry once (cheap, avoids drift)
    dS = 0.5 * (dS + np.swapaxes(dS, -1, -2))

    # Work mostly in f32; cast to f64 just for eigh
    S  = old_S.astype(np.float32, copy=False)
    Δ  = (step_tau * dS).astype(np.float32, copy=False)

    # (Optional micro-opt) short-circuit when the step is tiny everywhere
    # if np.max(np.abs(Δ)) < 1e-12: return old_S

    # Eigendecomp per pixel (use f64 for stability)
    w, Q = np.linalg.eigh(S.astype(np.float64, copy=False))
    w = np.clip(w, eps_tau, None)
    Winvhalf = 1.0 / np.sqrt(w)

    # Map Δ to relative coords: R = Σ^{-1/2} Δ Σ^{-1/2}
    # Q^T Δ Q in eig basis, then scale by Winvhalf
    Δeig = np.einsum("...ik,...kl,...jl->...ij",
                     np.swapaxes(Q, -1, -2), Δ, Q, optimize=True)
    R = (Winvhalf[..., :, None] * Δeig) * Winvhalf[..., None, :]

    # Trust region on ||R||_F (per pixel)
    # R: (H,W,K,K)  ->  Rnorm: (H,W,1,1)
    Rnorm = np.sqrt(np.sum(R * R, axis=(-2, -1), keepdims=True))
       
    # Per-pixel scalar, with dims kept to (H,W,1,1)
    scale = np.minimum(1.0, rho / np.maximum(Rnorm, eps_tau))
    
    # No broadcasting tricks needed now; shapes match
    R *= scale

    # Map back: Δ_scaled = Σ^{1/2} R Σ^{1/2}
    Winhalf = np.sqrt(w)
    Δeig_scaled = (Winhalf[..., :, None] * R) * Winhalf[..., None, :]
    Δ_scaled = np.einsum("...ik,...kl,...jl->...ij",
                         Q, Δeig_scaled, np.swapaxes(Q, -1, -2), optimize=True).astype(np.float32, copy=False)

    S_new = sanitize_sigma(S + Δ_scaled, eps=eps_tau)

    # Apply mask last (preserve old_S off-mask)
    mask3 = mask_bool[..., None, None]
    
    return np.where(mask3, S_new, old_S)



def _apply_children(agents, grads, n_jobs, *, ctx=None):
    """
    Apply per-agent updates for μ/Σ (belief+model) and φ/φ̃.
    Frozen levels are no longer used; updates are always applied where mask > 0.
    """
 
    # τ with defensive fallbacks
    tau_mu_belief    = cfg_get(ctx, "tau_mu_belief",    1e-2)
    tau_sigma_belief = cfg_get(ctx, "tau_sigma_belief", 1e-2)
    tau_mu_model     = cfg_get(ctx, "tau_mu_model",     1e-2)
    tau_sigma_model  = cfg_get(ctx, "tau_sigma_model",  1e-2)

    (q_updates, p_updates, phi_grads, phi_m_grads) = grads
    masks = [A.mask for A in agents]
   
    DEBUG_APPLY = cfg_get(ctx,"DEBUG_APPLY", False)

    def _one(i):
        A = agents[i]
        mask = np.asarray(masks[i], np.float32)
        mask_mu = mask[..., None]
    
        dmu_q, dsg_q = q_updates[i]
        dmu_p, dsg_p = p_updates[i]
    
        # ---- old values for Δ diagnostics ----
        mu_q_old = A.mu_q_field
        mu_p_old = A.mu_p_field
        sig_q_old = A.sigma_q_field
        sig_p_old = A.sigma_p_field
    
        # ---- μ updates (masked) ----
        A.mu_q_field = mu_q_old + (tau_mu_belief * dmu_q * mask_mu).astype(np.float32, copy=False)
        A.mu_p_field = mu_p_old + (tau_mu_model  * dmu_p * mask_mu).astype(np.float32, copy=False)
    
        # ---- Σ updates (masked) ----
        A.sigma_q_field = _apply_sigma_masked(ctx, sig_q_old, dsg_q, tau_sigma_belief, mask > 0.0)
        A.sigma_p_field = _apply_sigma_masked(ctx, sig_p_old, dsg_p, tau_sigma_model,  mask > 0.0)
    
        if DEBUG_APPLY:
            dmuq_mean = float(np.mean(np.abs(A.mu_q_field - mu_q_old)))
            dmup_mean = float(np.mean(np.abs(A.mu_p_field - mu_p_old)))
            dsigq_mean = float(np.mean(np.abs(A.sigma_q_field - sig_q_old)))
            dsigp_mean = float(np.mean(np.abs(A.sigma_p_field - sig_p_old)))
            print(
                f"[APPLY] id={getattr(A, 'id', i)} "
                f"|Δμ_q|={dmuq_mean:.3e} |Δμ_p|={dmup_mean:.3e} "
                f"|ΔΣ_q|={dsigq_mean:.3e} |ΔΣ_p|={dsigp_mean:.3e} "
                f"(τμ_q={tau_mu_belief:g}, τμ_p={tau_mu_model:g}, "
                f"τσ_q={tau_sigma_belief:g}, τσ_p={tau_sigma_model:g})",
                flush=True,
            )

        # ---- φ updates (masked inside) ----
        gp  = phi_grads[i];   gp  = np.zeros_like(A.phi,       dtype=np.float32) if gp  is None else gp
        gpm = phi_m_grads[i]; gpm = np.zeros_like(A.phi_model, dtype=np.float32) if gpm is None else gpm

        apply_phi_updates(A, gp, gpm, mask,  ctx=ctx)

        dirty_manager(ctx).mark_morphism_only(A)

    Parallel(n_jobs=n_jobs, backend="threading", batch_size="auto")(
        [delayed(_one)(i) for i in range(len(agents))]
    )





def _compute_child_grads(ctx, agents, all_agents, Gq, Gp):
    """
    Batch-compute child gradients.
    Returns 5 lists:
      - belief μ/Σ updates
      - model  μ/Σ updates
      - φ grads
      - φ̃ grads
      - per-agent θ grads (or None entries)
    """
    if not agents:
        return ([], [], [], [], [])

    n_jobs = max(1, min(int(cfg_get(ctx, "n_jobs", 1)), len(agents)))

    # Config knobs (no parallel_config; pass to Parallel directly)
    prefer      = str(cfg_get(ctx, "joblib_prefer", "threads"))   # "processes" or "threads"
    max_nbytes  = cfg_get(ctx, "joblib_memmap_threshold", "10M")  # only used by loky
    blas_threads = int(cfg_get(ctx, "blas_threads_per_worker",
                               2 if prefer == "threads" else 1))

    with threadpool_limits(blas_threads):
        results = Parallel(
            n_jobs=n_jobs,
            prefer=prefer,          # choose backend via preference
            max_nbytes=max_nbytes,  # memmap threshold for process backend
            batch_size="auto",
        )(
            delayed(compute_all_gradients)(Ai, agents, all_agents, Gq, Gp, runtime_ctx=ctx)
            for Ai in agents
        )

    # unzip -> 5 lists
    q_updates, p_updates, phi_grads, phi_m_grads, dtheta_parts = zip(*results)
    q_updates    = list(q_updates)
    p_updates    = list(p_updates)
    phi_grads    = list(phi_grads)
    phi_m_grads  = list(phi_m_grads)
    dtheta_parts = list(dtheta_parts)

    # optional coupling
    phi_grads = apply_A_phi_covariant_coupling(ctx, agents, phi_grads)

    return (q_updates, p_updates, phi_grads, phi_m_grads, dtheta_parts)





def apply_A_phi_covariant_coupling(ctx, agents, phi_grads):
    """
    Optional A–φ covariant coupling:
      - Adds covariant frame gradient to each child's φ-grad
      - Accumulates a single global A gradient
      - Records A_cov_energy for logging
    Side effects:
      - ctx.fields["A_grad_accum"], ctx.fields["A_cov_energy"]
    Returns:
      updated_phi_grads
    """
    if ctx is None:
        return phi_grads

    use_A   = bool(cfg_get(ctx, "use_global_A", False))
    lam_cov = float(cfg_get(ctx, "lambda_A_cov", 0.0))
    if not (use_A and lam_cov > 0.0):
        return phi_grads

    # Allow the module to be missing without crashing
    cov_fn = covariant_frame_energy_and_grads

    
    if cov_fn is None:
        print("[A-φ] covariant_frame_energy_and_grads not found; skipping.")
        return phi_grads

    # Ensure A lives on ctx and has the right shape
    H, W = agents[0].mask.shape[:2]
    A = ensure_global_A(ctx, (H, W), init_scale=float(cfg_get(ctx, "A_init_scale", 0.0)))

    A_grad_accum = None
    E_cov_total  = 0.0

    # Make a local, writable copy of φ-grads (list)
    out_phi_grads = list(phi_grads)

    for i, a in enumerate(agents):
        E_cov, g_phi_cov, gA_cov = cov_fn(
            phi=np.asarray(a.phi, np.float32),
            A=A,
            weight=lam_cov,
            mask=getattr(a, "mask", None),
        )
        #print(f"cov_fn {E_cov} \n\n\n\n\n\n\n\n")
        # Add onto child's φ grad (handle None/NaN placeholders)
        cur_g = out_phi_grads[i]
        if cur_g is None or (isinstance(cur_g, float) and np.isnan(cur_g)):
            out_phi_grads[i] = g_phi_cov
        else:
            out_phi_grads[i] = np.asarray(cur_g, np.float32) + g_phi_cov

        # Accumulate global A grad
        if A_grad_accum is None:
            A_grad_accum = np.asarray(gA_cov, np.float32).copy()
        else:
            A_grad_accum += np.asarray(gA_cov, np.float32)

        E_cov_total += float(E_cov)

    # Stash for the global A step to consume once per iteration
    if not hasattr(ctx, "fields") or ctx.fields is None:
        ctx.fields = {}
    ctx.fields["A_grad_accum"] = A_grad_accum
    ctx.fields["A_cov_energy"] = float(E_cov_total)

    return out_phi_grads




def apply_theta_updates(runtime_ctx, dtheta_or_parts):
    """
    Apply global θ update.
    Accepts either a single (dW, db, dS) tuple, or an iterable of such tuples
    (with None entries allowed). Handles:
      - aggregation (sum) + optional global clipping
      - Fisher preconditioning (Sxx + λI)^-1 for dW, db/=N
      - EMA and row/global clipping
      - log-σ² update normalized by N
    """
    import numpy as np

    theta = getattr(runtime_ctx, "theta", None)
    if theta is None:
        return

    # -------- accept single tuple or iterable-of-tuples
    if isinstance(dtheta_or_parts, tuple):
        parts = [dtheta_or_parts]
    else:
        parts = list(dtheta_or_parts)

    # -------- aggregate (skip None)
    dW_sum = db_sum = None
    dS_sum = 0.0
    any_part = False
    for part in parts:
        if part is None:
            continue
        dW, db, dS = part
        if dW_sum is None:
            dW_sum = np.array(dW, np.float32)
            db_sum = np.array(db, np.float32)
        else:
            dW_sum += dW
            db_sum += db
        dS_sum += float(dS)
        any_part = True

    if not any_part:
        return  # nothing to apply

    # -------- preconditioning + apply (your previous logic, cleaned)
    W, b, sigma2 = theta.W, theta.b, float(theta.sigma2)
    lrW       = float(cfg_get(runtime_ctx,"theta_lr_W",        1e-2))
    lrb       = float(cfg_get(runtime_ctx,"theta_lr_b",        1e-2))
    lrs       = float(cfg_get(runtime_ctx,"theta_lr_sigma2",   1e-2))
    ridge     = float(cfg_get(runtime_ctx,"theta_ridge",       1e-2))
  
    s2_min    = float(cfg_get(runtime_ctx,"sigma2_min",  1e-3))
    s2_max    = float(cfg_get(runtime_ctx,"sigma2_max",  1e+2))

    # Fisher stats (per-step, from children)
    Sxx, Sx, N, K = _theta_stats_from_children(runtime_ctx)
    if Sxx is not None and K is not None and N > 0:
        I = np.eye(K, dtype=np.float32)
        Sxx_r = (Sxx + ridge * I).astype(np.float32)
        Sxx_r = 0.5 * (Sxx_r + Sxx_r.T)  # symmetry guard
        try:
            X = np.linalg.solve(Sxx_r, np.asarray(dW_sum, np.float32).T)
            dW_sum = X.T
        except np.linalg.LinAlgError:
            print("[theta apply] LINALG ERROR!!!\n\n\n\n\n")
            denom = np.clip(np.diag(Sxx_r), 1e-6, np.inf)
            dW_sum = (np.asarray(dW_sum, np.float32) / denom[None, :]).astype(np.float32)
        db_sum = (np.asarray(db_sum, np.float32) / max(float(N), 1.0)).astype(np.float32)


    # SGD/EMA update
    W = W - lrW * dW_sum
    b = b - lrb * db_sum
  
    # σ^2 update in log-space, normalized by N and scaled by σ^2 (chain rule)
    s_log  = float(np.log(max(sigma2, s2_min)))
    ds     = float(-lrs * (dS_sum / max(float(N), 1.0)) * max(sigma2, s2_min))
    s_log  = float(np.clip(s_log + ds, np.log(s2_min), np.log(s2_max)))
    sigma2 = float(np.exp(s_log))

    # write back
    runtime_ctx.theta.W = W.astype(np.float32, copy=False)
    runtime_ctx.theta.b = b.astype(np.float32, copy=False)
    runtime_ctx.theta.sigma2 = sigma2

    # optional debug print
    if bool(cfg_get(runtime_ctx, "theta_debug_apply", True)):
        step = int(getattr(runtime_ctx, "global_step", 0))
        print(
            f"[θ-APPLY] step={step}  \n"
            f"|ΔW| = {np.linalg.norm(dW_sum):.2e}\n"
            f"|Δb| = {np.linalg.norm(db_sum):.2e}\n"
            f"Δσ2  = {dS_sum:.2e}\n"
            f"|W|_F= {np.linalg.norm(W):.2e} σ2={sigma2:.2e}\n\n",
            flush=True
        )

