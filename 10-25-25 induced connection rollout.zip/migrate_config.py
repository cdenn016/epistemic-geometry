# -*- coding: utf-8 -*-
"""
Created on Fri Oct 24 09:44:55 2025

@author: chris and christine
"""

#!/usr/bin/env python3
"""
Migration Script: Wire in sim_config.py

This script performs automated refactoring to replace:
  - Old: import config / from config import X
  - New: from sim_config import SimulationConfig (dependency injection)

Usage:
    python migrate_to_sim_config.py --dry-run   # Preview changes
    python migrate_to_sim_config.py --apply     # Apply changes
    python migrate_to_sim_config.py --validate  # Run tests after

Strategy:
    1. Create config at simulation entry point (generalized_simulation.py)
    2. Thread config through function signatures
    3. Replace config.X with cfg.Y.X using field mapping
    4. Keep config.py with deprecation warning during transition
"""

import re
import sys
from pathlib import Path
from typing import Dict, List, Tuple

# ============================================================================
# FIELD MAPPING: old config.X → new cfg.Y.X
# ============================================================================

FIELD_MAP = {
    # Geometry
    'D': 'geometry.dimension',
    'L': 'geometry.domain_length',
    'N': 'geometry.n_agents',
    'agent_radius_range': 'geometry.agent_radius_range',
    'fixed_location': 'geometry.fixed_location',
    'max_neighbors': 'geometry.max_neighbors',
    'domain_size': 'geometry.domain_size',
    
    # Bundle
    'ell_q': 'bundle.ell_q',
    'ell_p': 'bundle.ell_p',
    'spec_q': 'bundle.spec_q',
    'spec_p': 'bundle.spec_p',
    'mix_generators_q': 'bundle.mix_generators_q',
    'mix_generators_p': 'bundle.mix_generators_p',
    'diagonal_sigma': 'bundle.diagonal_sigma',
    'identical_models': 'bundle.identical_models',
    
    # Physics
    'alpha': 'physics.alpha',
    'feedback_weight': 'physics.feedback_weight',
    'beta_kappa_q': 'physics.beta_kappa_q',
    'beta_kappa_p': 'physics.beta_kappa_p',
    'kappa_gamma_q': 'physics.kappa_gamma_q',
    'kappa_gamma_p': 'physics.kappa_gamma_p',
    'lambda_A_curv': 'physics.lambda_A_curv',
    'lambda_A_cov': 'physics.lambda_A_cov',
    'A_init_scale': 'physics.A_init_scale',
    'use_global_A': 'physics.use_global_A',
    
    # Numerical
    'eps': 'numerical.eps',
    'sigma_rel_step_max': 'numerical.sigma_rel_step_max',
    'sigma_retraction_mode': 'numerical.sigma_retraction_mode',
    'overlap_eps': 'numerical.overlap_eps',
    'support_tau': 'numerical.support_tau',
    
    # Learning rates
    'tau_phi': 'learning_rates.tau_phi',
    'tau_phi_model': 'learning_rates.tau_phi_model',
    'tau_mu_belief': 'learning_rates.tau_mu_belief',
    'tau_sigma_belief': 'learning_rates.tau_sigma_belief',
    'tau_mu_model': 'learning_rates.tau_mu_model',
    'tau_sigma_model': 'learning_rates.tau_sigma_model',
    'A_lr': 'learning_rates.A_lr',
    
    # Gradient clipping
    'gradient_clip_phi': 'gradient_clipping.clip_phi',
    'gradient_clip_phi_model': 'gradient_clipping.clip_phi_model',
    'A_grad_clip': 'gradient_clipping.clip_A',
    
    # Initialization
    'q_mu_range': 'initialization.q_mu_range',
    'q_sigma_range': 'initialization.q_sigma_range',
    'p_mu_range': 'initialization.p_mu_range',
    'p_sigma_range': 'initialization.p_sigma_range',
    'phi_init': 'initialization.phi_init',
    'phi_init_smooth_sigma': 'initialization.phi_init_smooth_sigma',
    'phi_model_offset': 'initialization.phi_model_offset',
    'agent_seed': 'initialization.agent_seed',
    
    # Compute
    'n_jobs': 'compute.n_jobs',
    'joblib_prefer': 'compute.joblib_prefer',
    'shared_cache_dir': 'compute.shared_cache_dir',
    'transport_backend': 'compute.transport_backend',
    
    # Diagnostics
    'debug_phase_timing': 'diagnostics.debug_phase_timing',
    'debug_grad_timing': 'diagnostics.debug_grad_timing',
    
    # Top-level
    'steps': 'steps',
}


# ============================================================================
# MIGRATION RULES PER FILE
# ============================================================================

class MigrationRule:
    """Describes how to migrate a single file"""
    
    def __init__(
        self,
        filepath: str,
        import_change: str,
        add_cfg_param_to: List[str] = None,
        manual_review: List[str] = None,
    ):
        self.filepath = filepath
        self.import_change = import_change
        self.add_cfg_param_to = add_cfg_param_to or []
        self.manual_review = manual_review or []


MIGRATION_RULES = [
    # 1. Entry point - creates config
    MigrationRule(
        filepath='generalized_simulation.py',
        import_change='from sim_config import SimulationConfig',
        add_cfg_param_to=[],  # Creates config, doesn't receive it
        manual_review=[
            'Line 43: Replace `import config` with SimulationConfig creation',
            'Line 300: Update config comment',
        ]
    ),
    
    # 2. Agent initialization - receives config
    MigrationRule(
        filepath='agent_initialization.py',
        import_change='from sim_config import SimulationConfig',
        add_cfg_param_to=[
            'initialize_agents',
            'initialize_agent_bundle_frames',
        ],
        manual_review=[
            'Replace all config.X with cfg.Y.X using FIELD_MAP',
        ]
    ),
    
    # 3. Gradient terms - heavy config usage
    MigrationRule(
        filepath='gradient_terms.py',
        import_change='from sim_config import SimulationConfig',
        add_cfg_param_to=[
            'compute_phi_gradient_belief',
            'compute_phi_gradient_model',
            'compute_belief_mu_gradient',
            # ... add more as needed
        ],
        manual_review=[
            'Many functions use config - add cfg parameter systematically',
            'Use FIELD_MAP for all config.X → cfg.Y.X replacements',
        ]
    ),
    
    # 4. Runtime context - config wrapper
    MigrationRule(
        filepath='runtime_context.py',
        import_change='from sim_config import SimulationConfig',
        add_cfg_param_to=[
            'ensure_runtime_defaults',
        ],
        manual_review=[
            'This file wraps config - major refactor needed',
            'Consider making RuntimeContext take SimulationConfig in __init__',
        ]
    ),
    
    # 5. Tests - use test config fixture
    MigrationRule(
        filepath='test_validation.py',
        import_change='from sim_config import SimulationConfig, create_test_config',
        add_cfg_param_to=[],
        manual_review=[
            'Replace config with create_test_config()',
            'Use cfg fixture in pytest',
        ]
    ),
]


# ============================================================================
# AUTOMATED REFACTORING FUNCTIONS
# ============================================================================

def replace_config_references(content: str, var_name: str = 'cfg') -> Tuple[str, int]:
    """
    Replace config.X with cfg.Y.X using FIELD_MAP.
    
    Returns:
        (modified_content, num_replacements)
    """
    modified = content
    count = 0
    
    for old_field, new_path in FIELD_MAP.items():
        # Match config.X but not config.X.Y (avoid partial matches)
        pattern = rf'\bconfig\.{old_field}\b'
        replacement = f'{var_name}.{new_path}'
        
        modified, n = re.subn(pattern, replacement, modified)
        count += n
        
        if n > 0:
            print(f"  Replaced config.{old_field} -- {replacement} ({n} occurrences)")
    
    return modified, count


def update_import_statement(content: str, new_import: str) -> str:
    """Replace old config import with new sim_config import"""
    
    # Remove old imports
    content = re.sub(r'^import config\s*$', '', content, flags=re.MULTILINE)
    content = re.sub(r'^import config as config\s*$', '', content, flags=re.MULTILINE)
    content = re.sub(r'^import config as CONFIG_MODULE\s*$', '', content, flags=re.MULTILINE)
    content = re.sub(r'^from config import .*$', '', content, flags=re.MULTILINE)
    
    # Add new import at top of file (after docstring)
    lines = content.split('\n')
    
    # Find insertion point (after first """ or ''' block)
    insert_idx = 0
    in_docstring = False
    for i, line in enumerate(lines):
        if '"""' in line or "'''" in line:
            if not in_docstring:
                in_docstring = True
            else:
                insert_idx = i + 1
                break
        if not in_docstring and line.strip() and not line.startswith('#'):
            insert_idx = i
            break
    
    lines.insert(insert_idx, new_import)
    return '\n'.join(lines)


def add_cfg_parameter_to_function(content: str, func_name: str) -> str:
    """Add cfg: SimulationConfig parameter to function signature"""
    
    # Match function definition
    pattern = rf'(def {func_name}\s*\([^)]*)\)'
    
    def add_param(match):
        params = match.group(1)
        if 'cfg:' in params or 'cfg,' in params:
            return match.group(0)  # Already has cfg
        if params.endswith('('):
            return f"{params}cfg: SimulationConfig)"
        else:
            return f"{params}, cfg: SimulationConfig)"
    
    return re.sub(pattern, add_param, content)


# ============================================================================
# MAIN MIGRATION LOGIC
# ============================================================================

def migrate_file(rule: MigrationRule, dry_run: bool = True) -> bool:
    """
    Migrate a single file according to its rule.
    
    Returns:
        True if migration successful, False otherwise
    """
    filepath = Path(rule.filepath)
    
    if not filepath.exists():
        print(f" File not found: {filepath}")
        return False
    
    print(f"\n{'='*70}")
    print(f" Migrating: {filepath}")
    print(f"{'='*70}")
    
    # Read original content (force UTF-8 so Windows doesn't choke on smart quotes)
    content = filepath.read_text(encoding="utf-8", errors="replace")
    original_lines = len(content.split('\n'))

        
    print("\n[1] Updating imports...")
    content = update_import_statement(content, rule.import_change)
    
    print("\n[2] Replacing config.X -> cfg.Y.X...")
    content, num_replaced = replace_config_references(content)
    
    print(f"\n[2] {num_replaced} field references updated")
    
    if rule.add_cfg_param_to:
        print("\n[3] Adding cfg parameters to functions...")
        for func_name in rule.add_cfg_param_to:
            content = add_cfg_parameter_to_function(content, func_name)
            print(f"    added cfg: SimulationConfig to {func_name}(...)")

    # Manual review items
    if rule.manual_review:
        print("\n  MANUAL REVIEW REQUIRED:")
        for item in rule.manual_review:
            print(f"   - {item}")
    
    # Save or preview
    if dry_run:
        print("\n DRY RUN - Would write to:", filepath)
        print(f"   Lines: {original_lines} -- {len(content.split('\\n'))}")
        
        # Show diff preview (first 20 changes)
        print("\n   Preview of changes:")
        original_lines_list = filepath.read_text(encoding="utf-8", errors="replace").split('\n')

        new_lines = content.split('\n')
        changes_shown = 0
        for i, (old, new) in enumerate(zip(original_lines_list, new_lines)):
            if old != new and changes_shown < 20:
                print(f"   Line {i+1}:")
                print(f"     - {old[:80]}")
                print(f"     + {new[:80]}")
                changes_shown += 1
    else:
        # Backup original
        backup_path = filepath.with_suffix(filepath.suffix + '.backup')
        filepath.rename(backup_path)
        
        # Write migrated version using UTF-8
        filepath.write_text(content, encoding="utf-8")

        print(f" Migrated version written to: {filepath}")
    
    return True


def main():
    """Main migration script"""
    import argparse
    
    parser = argparse.ArgumentParser(description='Migrate from config.py to sim_config.py')
    parser.add_argument('--dry-run', action='store_true', help='Preview changes without modifying files')
    parser.add_argument('--apply', action='store_true', help='Apply changes to files')
    parser.add_argument('--validate', action='store_true', help='Run tests after migration')
    parser.add_argument('--file', type=str, help='Migrate single file only')
    
    args = parser.parse_args()
    
    if not (args.dry_run or args.apply or args.validate):
        parser.print_help()
        return
    
    print("="*70)
    print(" CONFIG.PY  SIM_CONFIG.PY MIGRATION SCRIPT")
    print("="*70)
    
    # Filter rules if single file specified
    rules_to_apply = MIGRATION_RULES
    if args.file:
        rules_to_apply = [r for r in MIGRATION_RULES if r.filepath == args.file]
        if not rules_to_apply:
            print(f" No migration rule found for: {args.file}")
            return
    
    # Apply migrations
    if args.dry_run or args.apply:
        success_count = 0
        for rule in rules_to_apply:
            if migrate_file(rule, dry_run=args.dry_run):
                success_count += 1
        
        print(f"\n{'='*70}")
        print(f" Successfully processed {success_count}/{len(rules_to_apply)} files")
        print(f"{'='*70}")
        
        if args.dry_run:
            print("\nINFO: This was a DRY RUN. No files were modified.")
            print("Run with --apply to make changes.")

    
    # Run validation
    if args.validate:
        print("\n" + "="*70)
        print(" RUNNING VALIDATION TESTS")
        print("="*70)
        
        import subprocess
        result = subprocess.run(['pytest', 'test_validation.py', '-v'], 
                                capture_output=True, text=True)
        print(result.stdout)
        if result.returncode != 0:
            print(" Tests failed!")
            print(result.stderr)
        else:
            print(" All tests passed!")


if __name__ == '__main__':
    main()