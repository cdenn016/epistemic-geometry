# -*- coding: utf-8 -*-
"""
Created on Thu Oct 23 18:04:53 2025

@author: chris and christine
"""

# -*- coding: utf-8 -*-
"""
gradient_config.py - Centralized gradient configuration

This module provides a single source of truth for all gradient-related configuration.
Replaces scattered cfg_get() calls throughout the codebase.

ALL gradient computations should use these config functions instead of cfg_get() directly.
"""

from core.runtime_context import cfg_get


# ═════════════════════════════════════════════════════════════════════════════
# Core Configuration Getters
# ═════════════════════════════════════════════════════════════════════════════

def get_numerical_config(ctx):
    """
    Core numerical stability parameters used across all gradients.
    
    Returns:
        dict with keys: eps, tau
    """
    return {
        'eps': float(cfg_get(ctx, "eps", 1e-8)),
        'tau': float(cfg_get(ctx, "support_tau", 1e-6)),
    }


def get_energy_weights(ctx):
    """
    Energy term coupling weights.
    
    Returns:
        dict with keys: alpha, feedback_weight
    """
    return {
        'alpha': float(cfg_get(ctx, "alpha", 0.0)),
        'feedback_weight': float(cfg_get(ctx, "feedback_weight", 0.0)),
    }


def get_learning_rates(ctx):
    """
    Learning rates for all field updates.
    
    Returns:
        dict with tau values for each field
    """
    return {
        'tau_phi': float(cfg_get(ctx, "tau_phi", 1e-1)),
        'tau_phi_model': float(cfg_get(ctx, "tau_phi_model", 1e-1)),
        'tau_mu_belief': float(cfg_get(ctx, "tau_mu_belief", 1e-2)),
        'tau_sigma_belief': float(cfg_get(ctx, "tau_sigma_belief", 1e-2)),
        'tau_mu_model': float(cfg_get(ctx, "tau_mu_model", 1e-2)),
        'tau_sigma_model': float(cfg_get(ctx, "tau_sigma_model", 1e-2)),
        'A_lr': float(cfg_get(ctx, "A_lr", 1e-2)),
    }


# ═════════════════════════════════════════════════════════════════════════════
# μ/Σ Gradient Configuration
# ═════════════════════════════════════════════════════════════════════════════

def get_mu_sigma_config(ctx):
    """
    Configuration for μ/Σ gradient computation (both belief and model).
    
    Used by:
        - accumulate_mu_sigma_gradient()
        - _accum_alignment_block_mu_sigma()
        - _accum_gamma_block_mu_sigma()
    
    Returns:
        dict with all μ/Σ gradient parameters
    """
    num_cfg = get_numerical_config(ctx)
    energy_cfg = get_energy_weights(ctx)
    
    return {
        # Numerical
        'eps': num_cfg['eps'],
        'tau': num_cfg['tau'],
        
        # Energy weights
        'alpha': energy_cfg['alpha'],
        'feedback_weight': energy_cfg['feedback_weight'],
        
        # Behavior flags
        'accumulate_sender_grads': bool(cfg_get(ctx, "accumulate_sender_grads", False)),
    }


# ═════════════════════════════════════════════════════════════════════════════
# φ Gradient Configuration
# ═════════════════════════════════════════════════════════════════════════════

def get_phi_config(ctx, which: str):
    """
    Configuration for φ gradient computation (fiber-specific).
    
    Args:
        ctx: Runtime context
        which: Fiber identifier ('q' for belief, 'p' for model)
    
    Used by:
        - _phi_term_align_recv()
        - _phi_term_gamma_recv()
        - phi_send_align()
        - phi_send_gamma()
    
    Returns:
        dict with all φ gradient parameters for specified fiber
    """
    num_cfg = get_numerical_config(ctx)
    energy_cfg = get_energy_weights(ctx)
    eps = num_cfg['eps']
    
    return {
        # Numerical
        'eps': eps,
        'tau': num_cfg['tau'],
        
        # Energy weights
        'alpha': energy_cfg['alpha'],
        'feedback_weight': energy_cfg['feedback_weight'],
        
        # Fiber-specific kappa values
        'beta_kappa': max(float(cfg_get(ctx, f"beta_kappa_{which}", 1.0)), eps),
        'gamma_kappa': float(cfg_get(ctx, f"kappa_gamma_{which}", 1.0)),
        
        # Gamma case flags (which gamma terms to use)
        'use_gamma_A': bool(cfg_get(ctx, f"use_gamma_A_{which}", True)),
        'use_gamma_B': bool(cfg_get(ctx, f"use_gamma_B_{which}", True)),
    }


def get_phi_config_global(ctx):
    """
    Global φ configuration (not fiber-specific).
    
    Used by:
        - build_phi_self_feedback_bucket()
        - Functions that don't need fiber-specific parameters
    
    Returns:
        dict with global φ parameters
    """
    num_cfg = get_numerical_config(ctx)
    energy_cfg = get_energy_weights(ctx)
    
    return {
        'eps': num_cfg['eps'],
        'tau': num_cfg['tau'],
        'alpha': energy_cfg['alpha'],
        'feedback_weight': energy_cfg['feedback_weight'],
    }


# ═════════════════════════════════════════════════════════════════════════════
# Curvature Gradient Configuration
# ═════════════════════════════════════════════════════════════════════════════

def get_curvature_config(ctx):
    """
    Configuration for curvature (A-field) gradient computation.
    
    Used by:
        - step_global_A()
        - covariant_frame_energy_and_grads()
    
    Returns:
        dict with curvature gradient parameters
    """
    num_cfg = get_numerical_config(ctx)
    
    return {
        'eps': num_cfg['eps'],
        'lambda_A_curv': float(cfg_get(ctx, "lambda_A_curv", 1e-2)),
        'lambda_A_cov': float(cfg_get(ctx, "lambda_A_cov", 1e-2)),
        'A_lr': float(cfg_get(ctx, "A_lr", 1e-2)),
        'A_grad_clip': float(cfg_get(ctx, "A_grad_clip", -1)),
        'use_global_A': bool(cfg_get(ctx, "use_global_A", True)),
    }


# ═════════════════════════════════════════════════════════════════════════════
# Gradient Clipping Configuration
# ═════════════════════════════════════════════════════════════════════════════

def get_gradient_clip_config(ctx):
    """
    Gradient clipping thresholds for all fields.
    
    Returns:
        dict with clip thresholds (-1 = no clipping)
    """
    return {
        'gradient_clip_phi': float(cfg_get(ctx, "gradient_clip_phi", -1)),
        'gradient_clip_phi_model': float(cfg_get(ctx, "gradient_clip_phi_model", -1)),
        'A_grad_clip': float(cfg_get(ctx, "A_grad_clip", -1)),
    }


# ═════════════════════════════════════════════════════════════════════════════
# Parallel Execution Configuration
# ═════════════════════════════════════════════════════════════════════════════

def get_parallel_config(ctx):
    """
    Configuration for parallel gradient computation.
    
    Returns:
        dict with parallel execution parameters
    """
    return {
        'n_jobs': max(1, int(cfg_get(ctx, "n_jobs", 1))),
        'joblib_prefer': str(cfg_get(ctx, "joblib_prefer", "threads")),
        'joblib_memmap_threshold': cfg_get(ctx, "joblib_memmap_threshold", "10M"),
        'blas_threads_per_worker': int(cfg_get(ctx, "blas_threads_per_worker", 1)),
    }


# ═════════════════════════════════════════════════════════════════════════════
# Complete Configuration
# ═════════════════════════════════════════════════════════════════════════════

def get_all_gradient_config(ctx):
    """
    Get complete gradient configuration for all fields.
    
    Useful for debugging or when you need access to everything at once.
    
    Returns:
        dict with all gradient-related configuration
    """
    return {
        'numerical': get_numerical_config(ctx),
        'energy_weights': get_energy_weights(ctx),
        'learning_rates': get_learning_rates(ctx),
        'mu_sigma': get_mu_sigma_config(ctx),
        'phi_q': get_phi_config(ctx, 'q'),
        'phi_p': get_phi_config(ctx, 'p'),
        'phi_global': get_phi_config_global(ctx),
        'curvature': get_curvature_config(ctx),
        'gradient_clip': get_gradient_clip_config(ctx),
        'parallel': get_parallel_config(ctx),
    }


# ═════════════════════════════════════════════════════════════════════════════
# Validation
# ═════════════════════════════════════════════════════════════════════════════

def validate_gradient_config(ctx, verbose=True):
    """
    Validate that all gradient configuration is readable and sane.
    
    Args:
        ctx: Runtime context
        verbose: Print detailed validation results
    
    Returns:
        True if validation passes, False otherwise
    """
    try:
        cfg = get_all_gradient_config(ctx)
        
        # Check numerical sanity
        if cfg['numerical']['eps'] <= 0:
            if verbose:
                print(f"❌ eps must be > 0, got {cfg['numerical']['eps']}")
            return False
        
        if cfg['numerical']['tau'] < 0:
            if verbose:
                print(f"❌ tau must be >= 0, got {cfg['numerical']['tau']}")
            return False
        
        # Check learning rates are positive
        for key, val in cfg['learning_rates'].items():
            if val < 0:
                if verbose:
                    print(f"❌ {key} must be >= 0, got {val}")
                return False
        
        # Check kappa values are positive
        for fiber in ['q', 'p']:
            phi_cfg = cfg[f'phi_{fiber}']
            if phi_cfg['beta_kappa'] <= 0:
                if verbose:
                    print(f"❌ beta_kappa_{fiber} must be > 0, got {phi_cfg['beta_kappa']}")
                return False
            if phi_cfg['gamma_kappa'] < 0:
                if verbose:
                    print(f"❌ gamma_kappa_{fiber} must be >= 0, got {phi_cfg['gamma_kappa']}")
                return False
        
        if verbose:
            print("✅ Gradient configuration validation PASSED\n")
            print("Configuration summary:")
            print(f"  eps = {cfg['numerical']['eps']}")
            print(f"  tau = {cfg['numerical']['tau']}")
            print(f"  alpha = {cfg['energy_weights']['alpha']}")
            print(f"  feedback_weight = {cfg['energy_weights']['feedback_weight']}")
            print(f"  n_jobs = {cfg['parallel']['n_jobs']}")
            print(f"  beta_kappa_q = {cfg['phi_q']['beta_kappa']}")
            print(f"  beta_kappa_p = {cfg['phi_p']['beta_kappa']}")
        
        return True
        
    except Exception as e:
        if verbose:
            print(f"❌ Gradient configuration validation FAILED: {e}")
            import traceback
            traceback.print_exc()
        return False


