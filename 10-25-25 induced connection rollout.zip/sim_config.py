# -*- coding: utf-8 -*-
"""
Created on Thu Oct 23 23:09:32 2025

@author: chris and christine
"""

"""
Refactored Simulation Configuration with Validation

Replaces global config.py with immutable, validated configuration objects.
Enables:
- Multiple configs in same process
- Automatic validation at construction
- Clear dependency injection
- Easy testing with config fixtures
"""

from dataclasses import dataclass, field, asdict
from typing import Tuple, List, Dict, Any
from enum import Enum
import warnings


class SigmaRetractionMode(Enum):
    """Retraction method for covariance updates"""
    EXPONENTIAL = "exp"
    LINEAR = "linear"


class TransportBackend(Enum):
    """Parallel transport computation backend"""
    PURE = "pure"  # Pure Python/NumPy
    CTX = "ctx"    # Context-cached


class FreezeOmegaMode(Enum):
    """Omega freezing strategy"""
    NONE = "none"
    IDENTITY = "identity"


@dataclass(frozen=True)
class NumericalConfig:
    """
    Numerical stability and precision settings.
    All epsilon values must be positive and appropriately scaled.
    """
    
    # General purpose epsilon
    eps: float = 1e-8
    
    # Linear algebra epsilon (for matrix operations)
    eps_linalg: float = 1e-10
    
    # Eigenvalue floor for SPD projection
    eig_floor: float = 1e-6
    
    # Condition number cap (MANDATORY for stability)
    cond_cap: float = 1e6
    
    # Relative step size limit for Sigma retraction
    sigma_rel_step_max: float = 0.1
    
    # Retraction mode
    sigma_retraction_mode: SigmaRetractionMode = SigmaRetractionMode.EXPONENTIAL
    
    # Overlap/support thresholds
    overlap_eps: float = 1e-6
    support_tau: float = 1e-6
    
    def __post_init__(self):
        """Validate at construction"""
        if self.eps <= 0:
            raise ValueError(f"eps must be positive, got {self.eps}")
        if self.eps_linalg <= 0:
            raise ValueError(f"eps_linalg must be positive, got {self.eps_linalg}")
        if self.eig_floor <= 0:
            raise ValueError(f"eig_floor must be positive, got {self.eig_floor}")
        if self.cond_cap <= 1:
            raise ValueError(f"cond_cap must be > 1, got {self.cond_cap}")
        if not (0 < self.sigma_rel_step_max <= 1.0):
            raise ValueError(f"sigma_rel_step_max must be in (0,1], got {self.sigma_rel_step_max}")
        
        # Warn on unsafe settings
        if self.cond_cap > 1e8:
            warnings.warn(f"Very high condition cap {self.cond_cap:.2e} may cause instability")


@dataclass(frozen=True)
class LearningRates:
    """
    Learning rate schedule for all update rules.
    All rates must be positive. Warns on potentially unstable settings.
    """
    
    # Gauge fields
    tau_phi: float = 1e-1
    tau_phi_model: float = 1e-1
    
    # Belief bundle (q)
    tau_mu_belief: float = 1e-2
    tau_sigma_belief: float = 1e-2
    
    # Model bundle (p)
    tau_mu_model: float = 1e-2
    tau_sigma_model: float = 1e-2
    
    # Global curvature field A
    A_lr: float = 1e-2
    
    def __post_init__(self):
        """Validate and warn"""
        rates = asdict(self)
        for name, rate in rates.items():
            if rate <= 0:
                raise ValueError(f"{name} must be positive, got {rate}")
            if rate > 0.5:
                warnings.warn(f"Large learning rate {name}={rate} may cause instability")


@dataclass(frozen=True)
class GradientClipping:
    """
    Gradient clipping to prevent exploding gradients.
    Set to None or ≤0 to disable (NOT RECOMMENDED).
    """
    
    # Gauge field gradients
    clip_phi: float = 1.0
    clip_phi_model: float = 1.0
    
    # Global A field gradients
    clip_A: float = 0.5
    
    def __post_init__(self):
        """Warn if clipping disabled"""
        if self.clip_phi <= 0:
            warnings.warn("φ gradient clipping DISABLED - risk of instability!")
        if self.clip_phi_model <= 0:
            warnings.warn("φ_model gradient clipping DISABLED - risk of instability!")
        if self.clip_A <= 0:
            warnings.warn("A gradient clipping DISABLED - risk of instability!")


@dataclass(frozen=True)
class GeometryConfig:
    """
    Base manifold geometry and agent spatial configuration.
    """
    
    # Spatial dimension
    dimension: int = 2
    
    # Domain size (length in each dimension)
    domain_length: int = 20
    
    # Number of agents
    n_agents: int = 15
    
    # Agent radius range (min, max)
    agent_radius_range: Tuple[float, float] = (4.0, 4.0)
    
    # Fixed locations (vs. mobile agents)
    fixed_location: bool = True
    
    # Maximum neighbors per agent
    max_neighbors: int = 15
    
    @property
    def domain_size(self) -> Tuple[int, ...]:
        """Compute domain size tuple from dimension and length"""
        return tuple([self.domain_length] * self.dimension)
    
    def __post_init__(self):
        """Validate geometry"""
        if self.dimension < 1 or self.dimension > 3:
            raise ValueError(f"dimension must be 1, 2, or 3, got {self.dimension}")
        if self.domain_length < 5:
            raise ValueError(f"domain too small: {self.domain_length} < 5")
        if self.n_agents < 1:
            raise ValueError(f"Must have at least 1 agent, got {self.n_agents}")
        
        r_min, r_max = self.agent_radius_range
        if r_min <= 0 or r_max < r_min:
            raise ValueError(f"Invalid radius range: {self.agent_radius_range}")
        if r_max > self.domain_length / 2:
            warnings.warn(f"Agent radius {r_max} large compared to domain {self.domain_length}")


@dataclass(frozen=True)
class BundleConfig:
    """
    Configuration for belief (q) and model (p) fiber bundles.
    Defines representation theory (ℓ values and multiplicities).
    """
    
    # Belief bundle ℓ value
    ell_q: int = 4
    
    # Model bundle ℓ value  
    ell_p: int = 4
    
    # Spectral decomposition: [(ℓ, multiplicity), ...]
    spec_q: List[Tuple[int, int]] = field(default_factory=lambda: [(4, 1)])
    spec_p: List[Tuple[int, int]] = field(default_factory=lambda: [(4, 1)])
    
    # Mix generators (experimental)
    mix_generators_q: bool = False
    mix_generators_p: bool = False
    
    # Diagonal covariance matrices only
    diagonal_sigma: bool = False
    
    # Identical models across agents
    identical_models: bool = False
    
    def __post_init__(self):
        """Validate representation theory"""
        if self.ell_q < 0:
            raise ValueError(f"ell_q must be non-negative, got {self.ell_q}")
        if self.ell_p < 0:
            raise ValueError(f"ell_p must be non-negative, got {self.ell_p}")
        
        # Validate spectral decomposition
        for spec, name in [(self.spec_q, "spec_q"), (self.spec_p, "spec_p")]:
            for ell, mult in spec:
                if ell < 0:
                    raise ValueError(f"{name}: ℓ={ell} must be non-negative")
                if mult < 0:
                    raise ValueError(f"{name}: multiplicity={mult} must be non-negative")
    
    @property
    def dim_q(self) -> int:
        """Total dimension of q bundle"""
        return sum(mult * (2*ell + 1) for ell, mult in self.spec_q)
    
    @property
    def dim_p(self) -> int:
        """Total dimension of p bundle"""
        return sum(mult * (2*ell + 1) for ell, mult in self.spec_p)


@dataclass(frozen=True)
class PhysicsConfig:
    """
    Physical coupling constants and energy weights.
    """
    
    # Overall coupling strength
    alpha: float = 1.0
    
    # Feedback weight (typically 0)
    feedback_weight: float = 0.0
    
    # Alignment temperature parameters
    beta_kappa_q: float = 1.0
    beta_kappa_p: float = 1.0
    
    # Gamma temperature parameters
    kappa_gamma_q: float = 1.0
    kappa_gamma_p: float = 1.0
    
    # Curvature field regularization
    lambda_A_curv: float = 5e-2
    lambda_A_cov: float = 5e-2
    A_init_scale: float = 5e-2
    
    # Gamma term gates (experimental)
    use_gamma_A_q: bool = False
    use_gamma_B_q: bool = True
    use_gamma_A_p: bool = True
    use_gamma_B_p: bool = False
    
    gamma_A_off: bool = False
    gamma_B_off: bool = False
    
    # Global A field
    use_global_A: bool = True
    
    def __post_init__(self):
        """Validate physics parameters"""
        if self.alpha < 0:
            raise ValueError(f"alpha must be non-negative, got {self.alpha}")
        
        for kappa, name in [(self.beta_kappa_q, "beta_kappa_q"),
                            (self.beta_kappa_p, "beta_kappa_p"),
                            (self.kappa_gamma_q, "kappa_gamma_q"),
                            (self.kappa_gamma_p, "kappa_gamma_p")]:
            if kappa <= 0:
                raise ValueError(f"{name} must be positive, got {kappa}")
        
        # Warn on potentially problematic gamma settings
        if self.use_gamma_A_q:
            warnings.warn("gamma_A_q enabled - known to cause instability in some configs")
        if self.use_gamma_B_p:
            warnings.warn("gamma_B_p enabled - known to cause instability in some configs")


@dataclass(frozen=True)
class InitializationConfig:
    """
    Initial condition settings for fields.
    """
    
    # Belief bundle (q) initialization
    q_mu_range: Tuple[float, float] = (-1.0, 1.0)
    q_sigma_range: Tuple[float, float] = (0.2, 1.0)
    
    # Model bundle (p) initialization
    p_mu_range: Tuple[float, float] = (-1.0, 1.0)
    p_sigma_range: Tuple[float, float] = (0.2, 1.0)
    
    # Gauge field initialization
    phi_init: float = 0.25
    phi_init_smooth_sigma: float = 2.0
    phi_model_offset: float = 0.15
    
    # Random seed for reproducibility
    agent_seed: int = 241
    
    def __post_init__(self):
        """Validate initialization ranges"""
        for range_val, name in [(self.q_mu_range, "q_mu_range"),
                                (self.p_mu_range, "p_mu_range"),
                                (self.q_sigma_range, "q_sigma_range"),
                                (self.p_sigma_range, "p_sigma_range")]:
            if range_val[1] < range_val[0]:
                raise ValueError(f"{name} invalid: max < min")
        
        # Sigma ranges must be positive
        if self.q_sigma_range[0] <= 0:
            raise ValueError("q_sigma_range must be positive")
        if self.p_sigma_range[0] <= 0:
            raise ValueError("p_sigma_range must be positive")


@dataclass(frozen=True)
class ComputeConfig:
    """
    Computational backend and parallelization settings.
    """
    
    # Number of parallel workers
    n_jobs: int = 1
    
    # Joblib backend
    joblib_prefer: str = "threads"
    
    # Memory mapping threshold
    joblib_memmap_threshold: str = "10G"
    
    # BLAS threads per worker (prevent oversubscription)
    blas_threads_per_worker: int = 1
    
    # Transport backend
    transport_backend: TransportBackend = TransportBackend.PURE
    
    # Cache directory
    shared_cache_dir: str = "./_checkpoints"
    
    # Omega freezing
    freeze_omega_mode: FreezeOmegaMode = FreezeOmegaMode.NONE
    
    # Sender gradient accumulation
    accumulate_sender_grads: bool = True
    
    def __post_init__(self):
        """Validate compute settings"""
        if self.n_jobs < 1:
            raise ValueError(f"n_jobs must be ≥ 1, got {self.n_jobs}")
        
        if self.joblib_prefer not in ["threads", "processes"]:
            raise ValueError(f"joblib_prefer must be 'threads' or 'processes', got {self.joblib_prefer}")
        
        if self.n_jobs > 1 and self.blas_threads_per_worker != 1:
            warnings.warn(f"Parallel execution with blas_threads_per_worker={self.blas_threads_per_worker} may cause CPU oversubscription")


@dataclass(frozen=True)
class DiagnosticsConfig:
    """
    Debugging and profiling settings.
    """
    
    debug_phase_timing: bool = False
    debug_grad_timing: bool = False
    
    # Logging intervals
    log_every_n_steps: int = 1
    plot_every_n_steps: int = 1
    snapshot_every_n_steps: int = 99


# ============================================================================
# MASTER CONFIGURATION
# ============================================================================

@dataclass(frozen=True)
class SimulationConfig:
    """
    Complete simulation configuration.
    
    Immutable, validated at construction, and dependency-injected.
    Replaces global config.py entirely.
    
    Usage:
        config = SimulationConfig(
            geometry=GeometryConfig(dimension=3, n_agents=50),
            physics=PhysicsConfig(alpha=2.0),
        )
        
        ctx = RuntimeContext(config=config)
        agents = run_simulation(config=config)
    """
    
    # Simulation parameters
    steps: int = 1000
    
    # Grouped configs
    geometry: GeometryConfig = field(default_factory=GeometryConfig)
    bundle: BundleConfig = field(default_factory=BundleConfig)
    physics: PhysicsConfig = field(default_factory=PhysicsConfig)
    numerical: NumericalConfig = field(default_factory=NumericalConfig)
    learning_rates: LearningRates = field(default_factory=LearningRates)
    gradient_clipping: GradientClipping = field(default_factory=GradientClipping)
    initialization: InitializationConfig = field(default_factory=InitializationConfig)
    compute: ComputeConfig = field(default_factory=ComputeConfig)
    diagnostics: DiagnosticsConfig = field(default_factory=DiagnosticsConfig)
    
    def __post_init__(self):
        """Cross-validate configuration consistency"""
        if self.steps < 1:
            raise ValueError(f"steps must be ≥ 1, got {self.steps}")
        
        # Check geometry vs bundle dimensions
        expected_dim_q = self.bundle.dim_q
        expected_dim_p = self.bundle.dim_p
        
        # Validate agent radius vs domain size
        r_max = self.geometry.agent_radius_range[1]
        if r_max * self.geometry.n_agents > 0.5 * self.geometry.domain_length**self.geometry.dimension:
            warnings.warn("Agents may be too large/numerous for domain - high overlap expected")
    
    def to_dict(self) -> Dict[str, Any]:
        """
        Convert to flat dictionary for backwards compatibility.
        Useful when migrating from old config.py.
        """
        result = {'steps': self.steps}
        
        for attr_name in ['geometry', 'bundle', 'physics', 'numerical', 
                         'learning_rates', 'gradient_clipping', 'initialization',
                         'compute', 'diagnostics']:
            sub_config = getattr(self, attr_name)
            result.update(asdict(sub_config))
        
        return result
    
    @classmethod
    def from_legacy_config(cls, config_module) -> 'SimulationConfig':
        """
        Create from old config.py module.
        
        Usage:
            import config
            new_config = SimulationConfig.from_legacy_config(config)
        """
        return cls(
            steps=getattr(config_module, 'steps', 1000),
            
            geometry=GeometryConfig(
                dimension=getattr(config_module, 'D', 2),
                domain_length=getattr(config_module, 'L', 20),
                n_agents=getattr(config_module, 'N', 15),
                agent_radius_range=getattr(config_module, 'agent_radius_range', (4.0, 4.0)),
                fixed_location=getattr(config_module, 'fixed_location', True),
                max_neighbors=getattr(config_module, 'max_neighbors', 15),
            ),
            
            bundle=BundleConfig(
                ell_q=getattr(config_module, 'ell_q', 4),
                ell_p=getattr(config_module, 'ell_p', 4),
                spec_q=getattr(config_module, 'spec_q', [(4, 1)]),
                spec_p=getattr(config_module, 'spec_p', [(4, 1)]),
                mix_generators_q=getattr(config_module, 'mix_generators_q', False),
                mix_generators_p=getattr(config_module, 'mix_generators_p', False),
                diagonal_sigma=getattr(config_module, 'diagonal_sigma', False),
                identical_models=getattr(config_module, 'identical_models', False),
            ),
            
            physics=PhysicsConfig(
                alpha=getattr(config_module, 'alpha', 1.0),
                feedback_weight=getattr(config_module, 'feedback_weight', 0.0),
                beta_kappa_q=getattr(config_module, 'beta_kappa_q', 1.0),
                beta_kappa_p=getattr(config_module, 'beta_kappa_p', 1.0),
                kappa_gamma_q=getattr(config_module, 'kappa_gamma_q', 1.0),
                kappa_gamma_p=getattr(config_module, 'kappa_gamma_p', 1.0),
                lambda_A_curv=getattr(config_module, 'lambda_A_curv', 5e-2),
                lambda_A_cov=getattr(config_module, 'lambda_A_cov', 5e-2),
                A_init_scale=getattr(config_module, 'A_init_scale', 5e-2),
                use_global_A=getattr(config_module, 'use_global_A', True),
            ),
            
            numerical=NumericalConfig(
                eps=getattr(config_module, 'eps', 1e-8),
                sigma_rel_step_max=getattr(config_module, 'sigma_rel_step_max', 0.1),
                sigma_retraction_mode=SigmaRetractionMode(getattr(config_module, 'sigma_retraction_mode', 'exp')),
            ),
            
            learning_rates=LearningRates(
                tau_phi=getattr(config_module, 'tau_phi', 1e-1),
                tau_phi_model=getattr(config_module, 'tau_phi_model', 1e-1),
                tau_mu_belief=getattr(config_module, 'tau_mu_belief', 1e-2),
                tau_sigma_belief=getattr(config_module, 'tau_sigma_belief', 1e-2),
                tau_mu_model=getattr(config_module, 'tau_mu_model', 1e-2),
                tau_sigma_model=getattr(config_module, 'tau_sigma_model', 1e-2),
                A_lr=getattr(config_module, 'A_lr', 1e-2),
            ),
            
            gradient_clipping=GradientClipping(
                clip_phi=max(0.01, getattr(config_module, 'gradient_clip_phi', 1.0)),
                clip_phi_model=max(0.01, getattr(config_module, 'gradient_clip_phi_model', 1.0)),
                clip_A=max(0.01, getattr(config_module, 'A_grad_clip', 0.5)),
            ),
            
            initialization=InitializationConfig(
                q_mu_range=getattr(config_module, 'q_mu_range', (-1.0, 1.0)),
                q_sigma_range=getattr(config_module, 'q_sigma_range', (0.2, 1.0)),
                p_mu_range=getattr(config_module, 'p_mu_range', (-1.0, 1.0)),
                p_sigma_range=getattr(config_module, 'p_sigma_range', (0.2, 1.0)),
                phi_init=getattr(config_module, 'phi_init', 0.25),
                phi_init_smooth_sigma=getattr(config_module, 'phi_init_smooth_sigma', 2.0),
                phi_model_offset=getattr(config_module, 'phi_model_offset', 0.15),
                agent_seed=getattr(config_module, 'agent_seed', 241),
            ),
            
            compute=ComputeConfig(
                n_jobs=getattr(config_module, 'n_jobs', 1),
                joblib_prefer=getattr(config_module, 'joblib_prefer', 'threads'),
                shared_cache_dir=getattr(config_module, 'shared_cache_dir', './_checkpoints'),
                transport_backend=TransportBackend(getattr(config_module, 'transport_backend', 'pure')),
            ),
            
            diagnostics=DiagnosticsConfig(
                debug_phase_timing=getattr(config_module, 'debug_phase_timing', False),
                debug_grad_timing=getattr(config_module, 'debug_grad_timing', False),
            ),
        )


# ============================================================================
# CONVENIENCE FUNCTIONS
# ============================================================================

def create_test_config(**overrides) -> SimulationConfig:
    """
    Create configuration for testing.
    Fast, deterministic, small scale.
    """
    defaults = {
        'steps': 10,
        'geometry': GeometryConfig(
            dimension=2,
            domain_length=10,
            n_agents=5,
            agent_radius_range=(2.0, 2.0),
        ),
        'compute': ComputeConfig(n_jobs=1),
    }
    defaults.update(overrides)
    return SimulationConfig(**defaults)


def create_production_config(**overrides) -> SimulationConfig:
    """
    Create configuration for production runs.
    Robust settings with all safety features enabled.
    """
    return SimulationConfig(**overrides)


# ============================================================================
# USAGE EXAMPLES
# ============================================================================

if __name__ == "__main__":
    print("=== Example 1: Create config with validation ===")
    try:
        config = SimulationConfig(
            steps=1000,
            geometry=GeometryConfig(dimension=2, n_agents=20),
            physics=PhysicsConfig(alpha=2.0),
        )
        print("✓ Config created successfully")
        print(f"  Domain: {config.geometry.domain_size}")
        print(f"  Bundle dims: q={config.bundle.dim_q}, p={config.bundle.dim_p}")
    except Exception as e:
        print(f"✗ Config validation failed: {e}")
    
    print("\n=== Example 2: Detect invalid config ===")
    try:
        bad_config = SimulationConfig(
            geometry=GeometryConfig(dimension=0),  # Invalid!
        )
    except ValueError as e:
        print(f"✓ Caught invalid config: {e}")
    
    print("\n=== Example 3: Test config fixture ===")
    test_config = create_test_config()
    print(f"✓ Test config: {test_config.steps} steps, {test_config.geometry.n_agents} agents")
    
    print("\n=== Example 4: Migration from old config.py ===")
    # Simulating old config module
    class OldConfig:
        D = 3
        L = 30
        N = 50
        alpha = 1.5
    
    new_config = SimulationConfig.from_legacy_config(OldConfig)
    print(f"✓ Migrated config: dim={new_config.geometry.dimension}, alpha={new_config.physics.alpha}")