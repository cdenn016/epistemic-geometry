# -*- coding: utf-8 -*-
"""
Created on Mon Jun 23 17:22:53 2025

@author: chris and christine
"""

import os
import pickle
import optuna
from generalized_simulation import run_simulation as gs_run

# Number of Optuna trials
N_TRIALS = 50
N_JOBS = 1  # run 1 sim at a time (each is expensive)

# Your selected parameter search space
sweep_params = {
     "alpha":                (0,    100),
     "beta":                 (0,    100),
     "gamma":                (0,    100),
     "gauge_weight":         (0,    100),
     #"model_align_weight":   (0,    100),
     #"model_gauge_weight":   (0,    100),
     #"model_mass_weight":    (0,    100),
     #"model_feedback_weight":(0,    100),
     #"phi_phi_tilde_coupling":(0,   100),
     #"phi_init":             (0,    1.0),
     # Base learning-rate ranges
     #"eta_base_q":           (1e-8,   1e-2),
     #"eta_base_p":           (1e-8,   1e-2),
     #"eta_base_phi":         (1e-8,   1e-2),
     #"eta_base_phi_model":   (1e-8,   1e-2),
 }


def run_simulation(params: dict) -> float:
    """
    Run your full simulator with the given params and return total_energy.
    """
    outdir = "optuna_tmp"
    agents, metric_log = gs_run(
        outdir=outdir,
        resume=False,
        log_metrics=True,
        num_cores=1,
        params=params
    )
    final = metric_log[-1]
    return final.get("total_energy", float("inf"))

def objective(trial):
    params = {
        name: trial.suggest_float(name, lo, hi)
        for name, (lo, hi) in sweep_params.items()
    }
    print(f"[OPTUNA] Trial params: {params}")
    return run_simulation(params)

def main():
    study = optuna.create_study(direction='minimize')
    study.optimize(objective, n_trials=N_TRIALS, n_jobs=N_JOBS)

    print("\n[RESULT] Best parameters:")
    for k, v in study.best_params.items():
        print(f"  {k}: {v:.4f}")
    print(f"\n[RESULT] Best energy: {study.best_value:.6f}")

if __name__ == "__main__":
    main()
