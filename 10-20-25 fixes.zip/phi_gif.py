"""
make_phi_sphere_from_npz.py
---------------------------------
Builds 3-D sphere GIFs for φ and φ̃ using Matplotlib directly
from the NPZ produced by save_phi_series_npz().
No command-line interface required—just run the file.
"""

import os
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation, PillowWriter
from matplotlib.colors import Normalize
from mpl_toolkits.mplot3d import Axes3D  # noqa: F401
# put this near the top with other imports
from joblib import Parallel, delayed
import multiprocessing as mp
from mpl_toolkits.mplot3d.art3d import Line3DCollection



# ---------- configuration ----------
NPZ_PATH = "./checkpoints/phi_series.npz"                # input
OUT_DIR  = "phi_sphere_gifs"               # output directory
FPS = 25
SUBSAMPLE = 1
MAX_FRAMES = 10000000
DPI = 120
WHICH = ("phi", "phi_model")              # render both
# ------------------------------------




def load_phi_series_npz(path):
    data = np.load(path, allow_pickle=True)
    phi_dict, phim_dict = {}, {}

    if "agent_ids" in data and ("phi_series" in data or "phim_series" in data or "phi_model_series" in data):
        agent_ids = np.asarray(data["agent_ids"]).astype(int).tolist()
        phi_arr   = data.get("phi_series", None)
        phim_arr  = data.get("phim_series", data.get("phi_model_series", None))
        if phi_arr is not None:
            for i, aid in enumerate(agent_ids):
                arr = phi_arr[i]
                phi_dict[int(aid)] = np.asarray(arr, dtype=np.float32) if arr is not None else np.empty((0,3))
        if phim_arr is not None:
            for i, aid in enumerate(agent_ids):
                arr = phim_arr[i]
                phim_dict[int(aid)] = np.asarray(arr, dtype=np.float32) if arr is not None else np.empty((0,3))
        return phi_dict, phim_dict

    for k in data.files:
        if "phi_series" in k and data[k].dtype == object:
            for aid, arr in data[k].item().items():
                phi_dict[int(aid)] = np.asarray(arr, dtype=np.float32)
        if "phi_model_series" in k or "phim_series" in k:
            for aid, arr in data[k].item().items():
                phim_dict[int(aid)] = np.asarray(arr, dtype=np.float32)
    return phi_dict, phim_dict


def sanitize(X):
    X = np.asarray(X, np.float64).reshape(-1, 3)
    X = X[np.all(np.isfinite(X), axis=1)]
    if X.size == 0:
        return X
    n = np.linalg.norm(X, axis=1)
    X = X[n > 1e-12]
    if X.size == 0:
        return X
    U = X / np.linalg.norm(X, axis=1, keepdims=True)
    keep = [0]
    for i in range(1, len(U)):
        if not np.allclose(U[i], U[i-1], rtol=1e-6, atol=1e-8):
            keep.append(i)
    return X[keep]


def to_unit(v):
    v = np.asarray(v, np.float64)
    n = np.linalg.norm(v, axis=-1, keepdims=True)
    return v / np.maximum(n, 1e-12)


def _make_sphere_wire(ax, r=1.0, n=40, alpha=0.15):
    u = np.linspace(0, 2*np.pi, n)
    v = np.linspace(0, np.pi, n//2)
    x = r*np.outer(np.cos(u), np.sin(v))
    y = r*np.outer(np.sin(u), np.sin(v))
    z = r*np.outer(np.ones_like(u), np.cos(v))
    ax.plot_wireframe(x, y, z, linewidth=0.4, alpha=alpha)



 


def render_phi_sphere_gif(ctx, agent_id: int, *, which: str = "phi",
                          outpath: str = None, show_model_too: bool = True,
                          fps: int = 12, use_colorbar: bool = True):
    if which not in ("phi", "phi_model"):
        raise ValueError("which must be 'phi' or 'phi_model'")

    series_phi  = ctx.__dict__.get("_phi_series", {}).get(agent_id, [])
    series_phim = ctx.__dict__.get("_phi_model_series", {}).get(agent_id, [])
    if (which == "phi" and len(series_phi) < 2) or (which == "phi_model" and len(series_phim) < 2):
        raise RuntimeError(f"Not enough samples recorded for agent {agent_id} ({which}).")

    prim_list = series_phi if which == "phi" else series_phim
    aux_list  = series_phim if which == "phi" else series_phi

    prim = np.asarray(prim_list, dtype=np.float64).reshape(-1, 3)  # <-- FIXED
    aux  = np.asarray(aux_list,  dtype=np.float64).reshape(-1, 3) if len(aux_list) else None

    def _clean(X):
        X = np.asarray(X, np.float64).reshape(-1, 3)
        if X.size == 0: return X
        m = np.all(np.isfinite(X), axis=1); X = X[m]
        if X.size == 0: return X
        n = np.linalg.norm(X, axis=1); X = X[n > 1e-12]
        if X.size == 0: return X
        U = X / np.linalg.norm(X, axis=1, keepdims=True)
        keep = [0]
        for i in range(1, len(U)):
            if not np.allclose(U[i], U[i-1], rtol=1e-6, atol=1e-8):
                keep.append(i)
        return X[keep]

    prim = _clean(prim)
    if prim.shape[0] < 2:
        raise RuntimeError("Not enough valid samples after cleaning.")
    if aux is not None:
        aux = _clean(aux)
        if aux.shape[0] < 2:
            aux = None

    T = prim.shape[0]

    prim_norms = np.linalg.norm(prim, axis=-1, keepdims=True)
    prim_u = prim / (prim_norms + 1e-12)
    mags   = np.linalg.norm(prim, axis=-1)

    # Antipodal unwrapping to avoid bounce at π
    def _unwrap_antipodes(U):
        U = np.asarray(U, np.float64).copy()
        for t in range(1, U.shape[0]):
            if float(np.dot(U[t], U[t-1])) < 0.0:
                U[t:] *= -1.0
        return U
    prim_u = _unwrap_antipodes(prim_u)

    vmin, vmax = float(np.min(mags)), float(np.max(mags))
    if not np.isfinite(vmin) or not np.isfinite(vmax):
        vmin, vmax = 0.0, 1.0
    if vmin == vmax:
        pad = 1e-6 if vmax == 0.0 else 1e-6 * abs(vmax)
        vmin -= pad; vmax += pad

    mag_norm = Normalize(vmin=vmin, vmax=vmax)
    cmap = plt.get_cmap('viridis')

    # Optional aux (independent unwrap; length match)
    aux_u = None
    if show_model_too and aux is not None:
        if aux.shape[0] != T:
            L = min(T, aux.shape[0])
            prim_u = prim_u[:L]; mags = mags[:L]; T = L
            aux = aux[:L]
        aux_norms = np.linalg.norm(aux, axis=-1, keepdims=True)
        aux_u = aux / (aux_norms + 1e-12)
        aux_u = _unwrap_antipodes(aux_u)

    # Segments (as list for mpl robustness)
    all_segs = np.stack([prim_u[:-1], prim_u[1:]], axis=1)
    all_segs_list = [all_segs[i] for i in range(all_segs.shape[0])]

    if outpath is None:
        outpath = f"phi_sphere_agent{agent_id}_{which}.gif"

    fig = plt.figure(figsize=(5.8, 5.8), dpi=120)
    ax  = fig.add_subplot(111, projection='3d')

    # Hard-lock scaling; disable autoscale
    ax.set_autoscale_on(False)
    ax._autoscaleXon = ax._autoscaleYon = ax._autoscaleZon = False  # type: ignore
    
    # IMPORTANT: keep the signature that add_collection3d expects
    def _noautoscale(X=None, Y=None, Z=None, *args, **kwargs):
        return
    ax.auto_scale_xyz = _noautoscale  # type: ignore[attr-defined]

    ax.set_box_aspect([1, 1, 1])
    ax.set_xlim([-1.05, 1.05]); ax.set_ylim([-1.05, 1.05]); ax.set_zlim([-1.05, 1.05])
    ax.set_xticks([]); ax.set_yticks([]); ax.set_zticks([])
    ax.set_title(f"Agent {agent_id} — {'φ' if which=='phi' else 'φ̃'} on S²")
    try: _make_sphere_wire(ax)
    except Exception: pass

    trail = Line3DCollection([], cmap=cmap, norm=mag_norm, linewidths=2.0)
    ax.add_collection3d(trail)
    tip_dot = ax.plot([], [], [], marker='o', markersize=5)[0]
    aux_line = None
    if show_model_too and aux_u is not None:
        aux_line, = ax.plot([], [], [], lw=1.0, alpha=0.35, color='k')

    if use_colorbar:
        mappable = plt.cm.ScalarMappable(norm=mag_norm, cmap=cmap)
        mappable.set_array(mags)
        try:
            cbar = plt.colorbar(mappable, ax=ax, fraction=0.046, pad=0.04)
            cbar.set_label("|φ|")
        except Exception:
            pass

    def init():
        dummy = [np.zeros((2, 3), dtype=float)]
        trail.set_segments(dummy)
        trail.set_array(np.array([mags[0]], dtype=float))
        tip_dot.set_data([], []); tip_dot.set_3d_properties([])
        if aux_line is not None:
            aux_line.set_data([], []); aux_line.set_3d_properties([])
        return (trail, tip_dot) if aux_line is None else (trail, tip_dot, aux_line)

    def update(frame):
        t = frame + 1  # 1..T-1
        segs_t = all_segs_list[:t]
        cols_t = mags[:t]
        trail.set_segments(segs_t)
        trail.set_array(cols_t.astype(float))

        x, y, z = prim_u[t]
        tip_dot.set_data([x], [y])
        tip_dot.set_3d_properties([z])
        tip_dot.set_color(cmap(mag_norm(mags[t])))

        if aux_line is not None and aux_u is not None:
            Xa = aux_u[:t+1]
            aux_line.set_data(Xa[:, 0], Xa[:, 1])
            aux_line.set_3d_properties(Xa[:, 2])

        return (trail, tip_dot) if aux_line is None else (trail, tip_dot, aux_line)

    anim = FuncAnimation(fig, update, init_func=init, frames=T-1,
                         interval=int(1000 / fps), blit=False)
    try:
        anim.save(outpath, writer=PillowWriter(fps=fps))
    finally:
        plt.close(fig)
    return outpath


def _to_T3(a):
    """Coerce input to float32 array of shape [T,3]."""
    arr = np.asarray(a)
    if arr.ndim == 1:
        if arr.size % 3 != 0:
            raise ValueError(f"Series length {arr.size} is not divisible by 3")
        arr = arr.reshape(-1, 3)
    elif arr.ndim >= 2:
        if arr.shape[-1] != 3:
            raise ValueError(f"Last dim must be 3, got {arr.shape}")
        arr = arr.reshape(-1, 3)
    return arr.astype(np.float32, copy=False)



class new_MiniCtx:
    __slots__ = ("_phi_series", "_phi_model_series")
    def __init__(self, aid, prim, aux):
        self._phi_series = {aid: _to_T3(prim)}
        self._phi_model_series = {aid: _to_T3(aux)} if aux is not None else {}



# --- tiny ctx wrapper so we can reuse render_phi_sphere_gif(ctx, agent_id, ...) ---
class _MiniCtx:
    __slots__ = ("_phi_series", "_phi_model_series")
    def __init__(self, aid, prim, aux):
        # renderer looks up ctx.__dict__['_phi_series'][aid]
        self._phi_series = {aid: np.asarray(prim, dtype=np.float32).reshape(-1, 3)}
        self._phi_model_series = {aid: np.asarray(aux,  dtype=np.float32).reshape(-1, 3)} if aux is not None else {}




def _render_task(aid, kind, prim, aux, outp):
    """Isolated worker: renders one GIF and returns out path or None."""
    try:
        ctx = _MiniCtx(aid, prim if kind == "phi" else aux,
                            aux  if kind == "phi" else prim)
        # call your preferred renderer EXACTLY as defined
        return render_phi_sphere_gif(
            ctx, aid, which=kind, outpath=outp,
            show_model_too=True, fps=FPS
        )
    except Exception as e:
        print(f"[phi_sphere 3D] Skip agent {aid}/{kind}: {e}")
        return None




def main():
    if not os.path.exists(NPZ_PATH):
        raise FileNotFoundError(f"Cannot find {NPZ_PATH}")
    os.makedirs(OUT_DIR, exist_ok=True)

    # Load & snapshot to plain arrays (avoid shared state in workers)
    phi_dict, phim_dict = load_phi_series_npz(NPZ_PATH)
    phi_dict  = {int(k): np.asarray(v, dtype=np.float32).copy() for k, v in phi_dict.items()}
    phim_dict = {int(k): np.asarray(v, dtype=np.float32).copy() for k, v in phim_dict.items()}

    all_ids = sorted(set(phi_dict.keys()) | set(phim_dict.keys()))
    print(f"Found {len(all_ids)} agents")

    # Build tasks
    tasks = []
    for aid in all_ids:
        # "phi"
        prim = phi_dict.get(aid)
        if prim is not None and len(prim) >= 2:
            aux = phim_dict.get(aid)
            outp = os.path.join(OUT_DIR, f"agent{aid}_phi.gif")
            tasks.append((aid, "phi", prim, aux, outp))
        # "phi_model"
        primm = phim_dict.get(aid)
        if primm is not None and len(primm) >= 2:
            auxp = phi_dict.get(aid)
            outp = os.path.join(OUT_DIR, f"agent{aid}_phim.gif")
            tasks.append((aid, "phi_model", primm, auxp, outp))

    if not tasks:
        print("No eligible series to render.")
        return

    n_jobs = min(os.cpu_count() or 1, len(tasks))
    print(f"Rendering {len(tasks)} GIFs with {n_jobs} workers...")

    try:
        mp.set_start_method("spawn", force=False)
    except RuntimeError:
        pass

    results = Parallel(n_jobs=n_jobs, backend="loky", prefer="processes")(
        delayed(_render_task)(aid, kind, prim, aux, outp) for (aid, kind, prim, aux, outp) in tasks
    )

    written = [p for p in results if p]
    print(f"Wrote {len(written)}/{len(tasks)} GIFs to: {OUT_DIR}")


if __name__ == "__main__":
    main()
