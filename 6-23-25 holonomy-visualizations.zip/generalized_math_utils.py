import numpy as np
from scipy.ndimage import laplace

def sanitize_q(q, eps=1e-9):
    """Clip probabilities to [eps,1] and renormalize along the last axis."""
    q = np.clip(q, eps, 1.0)
    q /= np.sum(q, axis=-1, keepdims=True) + eps
    return q

def kl_divergence(p, q, eps=1e-9):
    """Pointwise D_KL(p || q) along the last axis."""
    p = sanitize_q(p, eps)
    q = sanitize_q(q, eps)
    return np.sum(p * (np.log(p) - np.log(q)), axis=-1)

def laplacian_field(field):
    """Compute component‐wise Laplacian over the last (fiber) axis."""
    return np.stack([laplace(field[..., i]) for i in range(field.shape[-1])], axis=-1)

def masked_norm(field, mask, ord=2):
    """
    Compute the mean over support of ‖field(x)‖ᵒʳᵈ, i.e.
      ∑ₓ ‖field(x)‖ * mask(x)  /  (∑ₓ mask(x))
    """
    norm_vals = np.linalg.norm(field, ord=ord, axis=-1)
    return np.sum(norm_vals * mask) / (np.sum(mask) + 1e-9)

def even_range(min_val, max_val, num_samples):
    """
    Return a list of `num_samples` evenly spaced even integers
    between `min_val` and `max_val`, inclusive if possible.
    """
    # Ensure min and max are even
    if min_val % 2 != 0:
        min_val += 1
    if max_val % 2 != 0:
        max_val -= 1

    # Generate linearly spaced values and round to nearest even
    lin = np.linspace(min_val, max_val, num_samples)
    even_vals = [int(round(x / 2) * 2) for x in lin]

    # Remove duplicates and return sorted list
    return sorted(set(even_vals))