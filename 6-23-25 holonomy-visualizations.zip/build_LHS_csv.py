# -*- coding: utf-8 -*-
"""
Created on Mon Jun 23 17:31:47 2025

@author: chris and christine
"""

import os
import pickle
import pandas as pd

def rebuild_lhs_samples(output_path="lhs_samples.csv", base_dir="lhs_results"):
    run_dirs = sorted([
        d for d in os.listdir(base_dir)
        if os.path.isdir(os.path.join(base_dir, d)) and d.startswith("run_")
    ])

    all_params = []
    for run in run_dirs:
        path = os.path.join(base_dir, run, "params.pkl")
        if os.path.exists(path):
            with open(path, "rb") as f:
                params = pickle.load(f)
                all_params.append(params)
        else:
            print(f"[WARN] Missing: {path}")

    df = pd.DataFrame(all_params)
    df.to_csv(output_path, index=False)
    print(f"[DONE] Rebuilt {len(df)} entries → {output_path}")

if __name__ == "__main__":
    rebuild_lhs_samples()
