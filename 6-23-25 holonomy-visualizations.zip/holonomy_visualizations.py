# -*- coding: utf-8 -*-
"""
Created on Tue Jun 24 17:48:20 2025

@author: chris and christine
"""

import os
import pandas as pd
import matplotlib.pyplot as plt

# Load metrics from holonomy experiments
CSV_PATH = "holonomy_experiments/master_summary.csv"
OUTPUT_DIR = "Holonomy_Visualizations"
os.makedirs(OUTPUT_DIR, exist_ok=True)

# Define which metrics to plot
PLOT_METRICS = [
    "curvature_norm",
    #"trace_H",
    #"det_H",
    "condition_H",
    "fro_H_minus_I",
    "max_deviation",
    "mean_deviation",
    "min_deviation",
]

def plot_metric_over_time(df, cycle_id, label, metric, experiment):
    plt.figure(figsize=(8, 5))
    plt.plot(df["step"], df[metric], marker='o')
    plt.title(f"{metric} over time\n{experiment}: {label}")
    plt.xlabel("Step")
    plt.ylabel(metric)
    plt.tight_layout()

    # Save with a unique filename
    filename = f"{experiment}_{label}_{metric}.png".replace(" ", "").replace(":", "_")
    plt.savefig(os.path.join(OUTPUT_DIR, filename))
    plt.close()

def main():
    df = pd.read_csv(CSV_PATH)
    if "step" not in df.columns:
        print("[ERROR] No step column in CSV.")
        return

    # Handle each experiment type
    for exp_type in df["experiment"].unique():
        exp_df = df[df["experiment"] == exp_type]

        # Identify individual cycles by 'param'
        cycle_keys = exp_df["param"].unique()
        for cycle in cycle_keys:
            cycle_df = exp_df[exp_df["param"] == cycle]

            for metric in PLOT_METRICS:
                if metric in cycle_df.columns:
                    plot_metric_over_time(cycle_df, cycle, cycle, metric, exp_type)


        # After per-cycle plots
    plot_spatial_holonomy_vs_radius(df)

    print(f"[DONE] Plots saved to: {OUTPUT_DIR}/")
    
    
def plot_spatial_holonomy_vs_radius(df):
    df_spatial = df[df["experiment"] == "spatial"]
    if "radius" not in df_spatial.columns:
        print("[SKIP] No radius column found in spatial experiments.")
        return

    # Average over all steps per radius
    grouped = df_spatial.groupby("radius").agg({
        "curvature_norm": "mean",
        "fro_H_minus_I": "mean",
        "trace_H": "mean",
        "condition_H": "mean"
    }).reset_index()

    for metric in ["curvature_norm", "fro_H_minus_I", "trace_H", "condition_H"]:
        plt.figure(figsize=(6, 4))
        plt.plot(grouped["radius"], grouped[metric], marker='o')
        plt.title(f"{metric} vs. Spatial Loop Radius")
        plt.xlabel("Loop Radius")
        plt.ylabel(metric)
        plt.grid(True)
        plt.tight_layout()
        fname = f"spatial_holonomy_vs_radius_{metric}.png"
        plt.savefig(os.path.join(OUTPUT_DIR, fname))
        plt.close()


if __name__ == "__main__":
    main()
