import os
import re
import time
import pickle
import logging
import random

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from numpy.linalg import norm
from scipy.linalg import logm
from functools import partial


from config import (
    checkpoint_dir,
    domain_size,
    support_cutoff_eps,
    agent_seed,
    group_name,
    K,
)
from get_generators import get_generators
from find_agent_chains import get_agent_cycles, get_overlap_centroid
from holonomy_module import (
    compute_spatial_loop_holonomy,
    compute_agent_cycle_holonomy,
    sample_self_avoiding_loop_within_mask,
)

from generalized_math_utils import even_range

# ----------------------------
# Experiment parameters
# ----------------------------
max_agent_cycles = 8          # None = all cycles
spatial_sizes = even_range(2, 20, 10)


# ----------------------------
# Logging setup
# ----------------------------
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s %(levelname)s %(message)s'
)


def summarize_holonomy(H):
    """
    Given a holonomy matrix H (K×K), return a dict of common diagnostics.
    """
    I = np.eye(H.shape[0])
    # deviation from identity
    dev_norm   = norm(H - I)
    # trace and determinant metrics
    tr         = np.trace(H)
    det_minus1 = np.linalg.det(H) - 1.0
    # condition number
    cond_num   = np.linalg.cond(H)
    # optional: interpret curve type/value if 2×2, e.g. rotation angle
    curve_type = None
    curve_val  = None
    if H.shape == (2, 2):
        # for SO(2)-like rotations: cos⁻¹(tr/2)
        curve_type = 'rotation_angle'
        curve_val  = np.arccos(tr / 2.0)

    return {
        'deviation_norm': dev_norm,
        'trace':          tr,
        'det_minus1':     det_minus1,
        'cond':           cond_num,
        'curve_type':     curve_type,
        'curve_value':    curve_val,
    }


def parse_step(filename):
    """
    Extract integer step from filenames like 'step_0001.pkl'.
    """
    match = re.match(r'step_(\d+)\.pkl$', filename)
    if not match:
        raise ValueError(f"Filename '{filename}' does not match expected pattern")
    return int(match.group(1))


def load_all_checkpoints():
    """
    Load and cache all checkpoint files from checkpoint_dir.
    Returns a dict mapping step -> unpickled data.
    """
    files = [f for f in os.listdir(checkpoint_dir)
             if f.startswith('step_') and f.endswith('.pkl')]
    if not files:
        raise RuntimeError(f"No checkpoint files found in {checkpoint_dir}")

    # sort by parsed step number
    files_sorted = sorted(files, key=lambda f: parse_step(f))
    cache = {}
    for fname in files_sorted:
        step = parse_step(fname)
        path = os.path.join(checkpoint_dir, fname)
        with open(path, 'rb') as f:
            cache[step] = pickle.load(f)
        logging.info(f"Loaded checkpoint step={step}")
    return cache


def run_spatial_experiments(
    data_cache,
    steps,
    spatial_sizes,
    generators,
    use_commutator=False,
    phi_key="phi"
):
    """
    For each radius r in spatial_sizes:
      1. Sample one self-avoiding loop on the first step's mask.
      2. Replay that loop across all steps.
      3. Log holonomy diagnostics and metrics inline.
    """
    records = []

    # Base mask for spatial loop
    first_agents = data_cache[steps[0]][0] if isinstance(data_cache[steps[0]], tuple) else data_cache[steps[0]]
    first_agent  = first_agents[0]
    center       = tuple(first_agent.center)
    mask         = first_agent.mask

    for r in spatial_sizes:
        # Compute path length bounds
        circ  = 2 * np.pi * r
        min_L = max(4, int(0.5 * circ))
        max_L = max(min_L, int(1.2 * circ))

        # Sample loop only once
        coords_loop = sample_self_avoiding_loop_within_mask(
            center,
            mask,
            min_length = min_L,
            max_length = max_L,
            seed       = agent_seed
        )

        # Get initial belief from first agent at loop start
        b0 = first_agent.q[center].copy()

        for step in steps:
            agents = data_cache[step][0] if isinstance(data_cache[step], tuple) else data_cache[step]
            agent  = agents[0]

            # Run holonomy computation
            H, deviations, belief_seq, path_coords = compute_spatial_loop_holonomy(
                agent,
                coords_loop,
                generators,
                use_commutator=use_commutator,
                return_deviations=True,
                return_beliefs=True,
                return_path=True,
                initial_belief=b0,
                use_log_accumulation=True
            )

            # Matrix diagnostics
            logH            = logm(H)
            curvature_norm  = np.linalg.norm(logH)
            delta_H         = H - np.eye(H.shape[0])
            trace_H         = np.trace(H)
            det_H           = np.linalg.det(H)
            cond_H          = np.linalg.cond(H)

            records.append({
                'experiment':      'spatial',
                'param':           r,
                'radius':          r,
                'step':            step,
                'loop_length':     len(coords_loop) - 1,
                'max_deviation':   np.max(deviations),
                'mean_deviation':  np.mean(deviations),
                'min_deviation':   np.min(deviations),
                'curvature_norm':  curvature_norm,
                'trace_H':         trace_H,
                'det_H':           det_H,
                'condition_H':     cond_H,
                'fro_H_minus_I':   np.linalg.norm(delta_H),
                'path_coords':     path_coords,
                'deviations':      deviations,
                'logH':            logH,
                'holonomy':        H,
                'belief_seq':      belief_seq,
            })

    return records

def run_agent_cycle_experiments(
    data_cache,
    steps,
    agents_at_first_step,
    cycles,
    generators,
    use_commutator=False,
    phi_key="phi"
):
    records = []

    # Precompute overlap centroids once
    all_overlaps = {
        tuple(cycle): [
            get_overlap_centroid(
                agents_at_first_step[i],
                agents_at_first_step[j],
                domain_size,
                support_cutoff_eps
            ) or (np.nan,)
            for i, j in zip(cycle[:-1], cycle[1:])
        ]
        for cycle in cycles
    }

    for cycle in cycles:
        label = '_'.join(map(str, cycle))
        overlaps = all_overlaps[tuple(cycle)]

        for step in steps:
            agents = data_cache[step][0] if isinstance(data_cache[step], tuple) else data_cache[step]
            start_agent = cycle[0]
            start_pos = tuple(agents[start_agent].center)
            b0 = agents[start_agent].q[start_pos]

            H, deviations, belief_seq, transport_path = compute_agent_cycle_holonomy(
                agents,
                cycle,
                overlaps,
                generators,
                initial_belief=b0,
                return_deviations=True,
                return_beliefs=True,
                return_path=True,
                use_commutator=use_commutator,
                use_log_accumulation=True
            )

            try:
                logH = logm(H)
                curvature_norm = np.linalg.norm(logH)
            except Exception:
                logH = np.full_like(H, np.nan)
                curvature_norm = np.nan

            delta_H = H - np.eye(H.shape[0])
            trace_H = np.trace(H)
            det_H   = np.linalg.det(H)
            cond_H  = np.linalg.cond(H)

            metrics = {
                'curvature_norm':  curvature_norm,
                'trace_H':         trace_H,
                'det_H':           det_H,
                'condition_H':     cond_H,
                'fro_H_minus_I':   np.linalg.norm(delta_H),
            }

            records.append({
                'experiment':      'agent_cycle',
                'param':           label,
                'step':            step,
                'loop_length':     len(cycle),
                'max_deviation':   np.max(deviations),
                'mean_deviation':  np.mean(deviations),
                'min_deviation':   np.min(deviations),
                **metrics,
                'cycle':           cycle,
                'overlaps':        overlaps,
                'transport_path':  transport_path,
                'deviations':      deviations,
                'logH':            logH,
                'holonomy':        H,
                'belief_seq':      belief_seq,
            })

    return records


def main():
    # Load all checkpoints
    data_cache = load_all_checkpoints()
    steps = sorted(data_cache.keys())

    global max_agent_cycles, spatial_sizes

    # Extract first-step agents and sample agent cycles
    first_agents = data_cache[steps[0]][0] if isinstance(data_cache[steps[0]], tuple) else data_cache[steps[0]]
    all_cycles = get_agent_cycles(first_agents, max_length=20)

    random.seed(42)
    cycles = random.sample(all_cycles, min(len(all_cycles), max_agent_cycles or len(all_cycles))) if all_cycles else []

    # Shared config
    phi_key = "phi"
    use_commutator = False
    generators = get_generators(group_name, K)
    records = []

    # Run spatial experiments
    records += run_spatial_experiments(
        data_cache, steps, spatial_sizes, generators,
        use_commutator=use_commutator,
        phi_key=phi_key,
    )

    # Run agent-cycle experiments
    if cycles:
        records += run_agent_cycle_experiments(
            data_cache, steps, first_agents, cycles, generators,
            use_commutator=use_commutator,
            phi_key=phi_key,
        )
    else:
        logging.warning("No agent cycles found; skipping agent_cycle experiments.")

    # Save master summary CSV
    df = pd.DataFrame(records)
    if 'curvature_norm' not in df.columns and 'deviation_norm' in df.columns:
        df['curvature_norm'] = df['deviation_norm']

    os.makedirs('holonomy_experiments', exist_ok=True)
    master_csv = os.path.join('holonomy_experiments', 'master_summary.csv')
    df.to_csv(master_csv, index=False)
    logging.info(f"Master summary written to {master_csv}")

    # Summary plots
    for metric in ['curvature_norm']:
        plt.figure(figsize=(10, 6))
        for exp in df['experiment'].unique():
            sub = df[df['experiment'] == exp]
            mean_vals = sub.groupby('param')[metric].mean()
            plt.plot(mean_vals.index, mean_vals.values, marker='o', label=exp)
        plt.xlabel('Parameter')
        plt.ylabel(metric)
        plt.title(f'Average {metric} vs. Parameter')
        plt.xticks(rotation=45, ha='right')
        plt.legend()
        plt.tight_layout()
        plt.savefig(os.path.join('holonomy_experiments', f'{metric}_vs_param.png'))
        plt.close()
    logging.info("Plots saved.")


if __name__ == '__main__':
    main()

