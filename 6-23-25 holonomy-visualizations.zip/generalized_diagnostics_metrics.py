# diagnostics_metrics.py

import numpy as np
import config
from scipy.ndimage import laplace
from typing import Dict, List, Any

from joblib import Parallel, delayed

from generalized_math_utils import sanitize_q, masked_norm, laplacian_field

from generalized_omega import (
    exp_lie_algebra_irrep,
    batch_apply_omega,
    repair_if_forgotten_batch,
    compute_field_strength,
    build_inter_agent_omega
)

_DEFAULT_CUTOFF = getattr(config, "support_cutoff_eps", 1e-3)

def kl_divergence(p, q, eps=1e-9):
    """Pointwise D_KL(p || q) along the last axis."""
    p = sanitize_q(p, eps)
    q = sanitize_q(q, eps)
    return np.sum(p * (np.log(p) - np.log(q)), axis=-1)

def support_mask(mask, cutoff=_DEFAULT_CUTOFF):
    return (mask > cutoff)

def overlap_mask(mask_i, mask_j, cutoff=_DEFAULT_CUTOFF):
    return support_mask(mask_i, cutoff) & support_mask(mask_j, cutoff)

def compute_kl_field(agents, i):
    q = sanitize_q(agents[i].q)
    p = sanitize_q(agents[i].p)
    kl = kl_divergence(q, p)
    return kl * agents[i].mask

def compute_phi_norm_field(agents, i, phi_field="phi"):
    phi = getattr(agents[i], phi_field)
    return np.linalg.norm(phi, axis=-1) * agents[i].mask


def threshold_mask(mask: np.ndarray) -> np.ndarray:
    """
    Turn a float support field into a boolean support region.
    Works for any dimensionality of mask.
    """
    eps = getattr(config, "support_cutoff_eps", 1e-3)
    return mask > eps  # same shape, but boolean


def compute_coherence(phi: np.ndarray, mask: np.ndarray) -> float:
    # use the same threshold for boolean selection
    mask_bool = threshold_mask(mask)
    phis = phi[mask_bool]         # shape (n_points,)
    return np.abs(np.mean(np.exp(1j * phis)))


def compute_free_energy(agent) -> float:
    q = agent.q   # shape (..., K)
    p = agent.p   # same shape

    # 1) threshold to boolean
    mask_bool = threshold_mask(agent.mask)    # shape (...), dtype=bool

    # 2) index out all K-vectors at masked points
    #    This works whether ... is 1D, 2D, 3D, etc.
    q_vals = q[mask_bool]     # shape (n_points, K)
    p_vals = p[mask_bool]

    # 3) compute per-point KL and average
    tiny = 1e-12
    ratio = (q_vals + tiny) / (p_vals + tiny)
    kl_per_point = np.sum(q_vals * np.log(ratio), axis=-1)
    return float(np.mean(kl_per_point))


def compute_avg_kl_self(agent: Any, agents: List[Any], support_eps: float = 1e-3) -> float:
    """
    Average the self-KL field D_KL(q||p) over the agent's support.
    """
    mask = agent.mask > support_eps
    field = compute_kl_field(agents, agent.id)
    values = field[mask]
    return float(values.sum() / (mask.sum() or 1))


def compute_avg_kl_align(
    agent: Any,
    agents: List[Any],
    support_eps: float = config.support_cutoff_eps,
    log_eps: float    = config.log_eps
) -> float:
    """
    Average the KL(q||Omega q) alignment field over the agent's support.
    """
    mask = agent.mask > support_eps
    # compute_alignment_field now only needs (agents, index, eps, log_eps)
    field = compute_alignment_field(
        agents,
        agent.id,
        eps    = support_eps,
        log_eps= log_eps
    )
    vals = field[mask]
    return float(vals.sum() / (mask.sum() or 1))


def compute_avg_kl_model_align(
    agent: Any,
    agents: List[Any],
    support_eps: float = config.support_cutoff_eps,
    log_eps: float    = config.log_eps
) -> float:
    """
    Average the KL(p||~Ω p) model-alignment field over the agent's support.
    """
    mask = agent.mask > support_eps
    # compute_model_alignment_field now expects (agents, index, eps, log_eps)
    field = compute_model_alignment_field(
        agents,
        agent.id,
        eps    = support_eps,
        log_eps= log_eps
    )
    values = field[mask]
    return float(values.sum() / (mask.sum() or 1))



def _batch_alignment_energy(pairs, weight, log_eps):
    """
    Batch-compute non-abelian alignment energy for pairs of
    (qi_patch, qj_patch, Omega_i_patch, Omega_j_inv_patch).
    Returns weighted sum of D_KL(qi || Ωij qj), where
      Ωij = Omega_i @ Omega_j_inv.
    """
    if not pairs:
        return 0.0

    # Unpack & stack
    qi_all         = np.vstack([qi        for qi, qj, Oi, Oj_inv in pairs])   # (M, K)
    qj_all         = np.vstack([qj        for qi, qj, Oi, Oj_inv in pairs])   # (M, K)
    Omega_i_all    = np.stack([Oi        for qi, qj, Oi, Oj_inv in pairs], 0)  # (M, K, K)
    Omega_j_inv_all= np.stack([Oj_inv    for qi, qj, Oi, Oj_inv in pairs], 0)  # (M, K, K)

    # Build inter-agent Ω_ij = Omega_i @ Omega_j_inv
    # (we use einsum to batch‐matmul efficiently)
    Omegas_all = np.einsum('mab,mbc->mac', Omega_i_all, Omega_j_inv_all)

    # Apply Ω to qj_all
    qj_rot_all = batch_apply_omega(qj_all, Omegas_all)  # (M, K)
    qj_rot_all = sanitize_q(qj_rot_all, eps=log_eps)

    # Compute KL per overlap pixel
    kl_vals = np.sum(
        qi_all * (np.log(qi_all) - np.log(qj_rot_all)),
        axis=-1
    )

    return weight * float(np.sum(kl_vals))


def compute_alignment_error(
    agents,
    q_field: str = "q",
    mask_field: str = "mask",
    support_cutoff_eps: float = 1e-3,
    log_eps: float = 1e-8,
    n_jobs: int = 1,
) -> float:
    """
    Compute average KL divergence alignment error D_KL(q_i || Ω_{ij} q_j)
    over overlapping neighbors, using each Agent's cached Omega & Omega_inv.
    """

    def _pair_error(i, j):
        A_i = agents[i]
        A_j = agents[j]

        # 1) find overlap region
        mask_i  = getattr(A_i, mask_field) > support_cutoff_eps
        mask_j  = getattr(A_j, mask_field) > support_cutoff_eps
        overlap = mask_i & mask_j
        if not overlap.any():
            return 0.0, 0.0

        # 2) extract q-values over overlap
        qi_vals = sanitize_q(getattr(A_i, q_field)[overlap], eps=log_eps)
        qj_vals = sanitize_q(getattr(A_j, q_field)[overlap], eps=log_eps)

        # 3) grab cached Omegas
        #    shape (M, K, K)
        Omega_i_patch    = A_i.Omega[overlap]
        Omega_j_inv_patch= A_j.Omega_inv[overlap]

        # 4) build Ω_ij = Omega_i @ Omega_j_inv  for each pixel
        Omegas_ij = np.einsum("mab,mbc->mac",
                              Omega_i_patch,
                              Omega_j_inv_patch)

        # 5) rotate qj
        qj_rot = batch_apply_omega(qj_vals, Omegas_ij)
        qj_rot = sanitize_q(qj_rot, eps=log_eps)

        # 6) compute pointwise KL and weight by pixel count
        D_kl = kl_divergence(qi_vals, qj_rot)   # shape (M,)
        return float(D_kl.sum()), float(overlap.sum())

    # build all unique i<j neighbor pairs
    pairs = [
        (i, nb["id"])
        for i, A in enumerate(agents)
        for nb in A.neighbors
        if nb["id"] > i
    ]

    # run in parallel
    results = Parallel(n_jobs=n_jobs, backend="threading")(
        delayed(_pair_error)(i, j) for i, j in pairs
    )

    total_err = sum(err for err, w in results)
    total_w   = sum(w   for err, w in results)
    return float(total_err / (total_w + log_eps))

def compute_alignment_field(
    agents,
    i,
    eps: float = config.support_cutoff_eps,
    log_eps: float = config.log_eps
) -> np.ndarray:
    """
    Compute per‐pixel KL alignment D_KL(q_i || Ω_{ij} q_j) averaged over neighbors,
    using each Agent’s cached Omega & Omega_inv fields.
    """
    A = agents[i]
    mask_i = A.mask > eps

    # no support or no neighbors
    if not mask_i.any() or not A.neighbors:
        return np.zeros_like(mask_i, float)

    # sanitize once
    q_i_full = sanitize_q(A.q, eps=log_eps)

    # accumulators
    kl_accum = np.zeros_like(mask_i, float)
    n_nb_at  = np.zeros_like(mask_i, int)

    for nb in A.neighbors:
        B = agents[nb["id"]]
        mask_j  = B.mask > eps
        overlap = mask_i & mask_j
        if not overlap.any():
            continue

        # slice out overlapping values
        qi_pts = q_i_full[overlap]                               # (M, K)
        qj_pts = sanitize_q(B.q, eps=log_eps)[overlap]           # (M, K)

        # grab cached Ω and Ω⁻¹ for each pixel
        Oi_patch    = A.Omega[overlap]       # (M, K, K)
        Oj_inv_patch= B.Omega_inv[overlap]   # (M, K, K)

        # build inter‐agent Ω_ij(x) = Oi @ Oj_inv
        Omegas_ij = np.einsum("mab,mbc->mac", Oi_patch, Oj_inv_patch)

        # rotate q_j and sanitize
        qj_trans = batch_apply_omega(qj_pts, Omegas_ij)
        qj_trans = sanitize_q(qj_trans, eps=log_eps)

        # accumulate KL at these pixels
        kl_vals = kl_divergence(qi_pts, qj_trans)  # shape (M,)
        kl_accum[overlap] += kl_vals
        n_nb_at [overlap] += 1

    # avoid divide‐by‐zero
    denom = np.where(n_nb_at > 0, n_nb_at, 1)

    # return per‐pixel average KL inside support, zero outside
    return (kl_accum / denom) * mask_i


def compute_model_alignment_kl(
    agents,
    support_eps: float   = config.support_cutoff_eps,
    log_eps: float       = config.log_eps,
    n_jobs: int          = 1,
) -> float:
    """
    Compute average KL divergence D_KL(p_i || Ω_ij p_j) over unique overlapping agent pairs,
    using each Agent’s cached Omega & Omega_inv, parallelized.
    """

    def _pair_kl(i, j):
        A_i = agents[i]
        A_j = agents[j]

        # overlap mask
        mi = A_i.mask > support_eps
        mj = A_j.mask > support_eps
        ov = mi & mj
        if not ov.any():
            return 0.0, 0.0

        # slice out p-values
        pi = sanitize_q(A_i.p[ov], eps=log_eps)    # (M, K)
        pj = sanitize_q(A_j.p[ov], eps=log_eps)    # (M, K)

        # grab cached Ω and Ω⁻¹ patches
        Oi = A_i.Omega    [ov]   # (M, K, K)
        Oj_inv = A_j.Omega_inv [ov]  # (M, K, K)

        # build inter-agent Ω_ij = Oi @ Oj_inv
        Omegas = np.einsum("mab,mbc->mac", Oi, Oj_inv)

        # transport p_j and clamp
        pj_rot = batch_apply_omega(pj, Omegas)
        pj_rot = repair_if_forgotten_batch(pj_rot, eps=log_eps)
        pj_rot = np.clip(pj_rot, log_eps, 1.0)

        # pointwise KL
        kl = np.sum(pi * (np.log(pi) - np.log(pj_rot)), axis=-1)
        return float(kl.sum()), float(ov.sum())

    # unique i<j neighbors
    pairs = [
        (i, nb["id"])
        for i, A in enumerate(agents)
        for nb in A.neighbors
        if nb["id"] > i
    ]

    # parallel compute
    results = Parallel(n_jobs=n_jobs, backend="threading")(
        delayed(_pair_kl)(i, j) for i, j in pairs
    )

    total_kl    = sum(k for k, w in results)
    total_count = sum(w for k, w in results)
    return float(total_kl / (total_count + log_eps))


def compute_model_alignment_field(
    agents,
    i,
    eps: float = config.support_cutoff_eps,
    log_eps: float = config.log_eps
) -> np.ndarray:
    """
    Exactly like compute_alignment_field, but uses each agent's p & phi_model.
    Returns the per‐pixel model‐alignment field for agent i.
    """
    A = agents[i]
    # swap in p & phi_model
    q_saved, phi_saved = A.q, A.phi
    A.q, A.phi = A.p, A.phi_model

    try:
        # now call without generators
        field = compute_alignment_field(agents, i, eps=eps, log_eps=log_eps)
    finally:
        # restore q & phi
        A.q, A.phi = q_saved, phi_saved

    return field


def compute_phi_model_alignment_field(agents, i):
   
    q        = sanitize_q(agents[i].q)
    p_model  = sanitize_q(agents[i].p)
    mask     = agents[i].mask > config.support_cutoff_eps
    kl       = kl_divergence(q, p_model)      # shape (...,)
    return kl * mask                          # zeroed outside support


def compute_phi_delta_norm(
    agents,
    params: dict | None = None,
    delta_phi_field_name: str = "delta_phi",
    mask_field: str = "mask",
) -> float:
    """
    Compute the maximum update‐step norm of delta_phi across all agents.
    Hyperparameter support_cutoff_eps is pulled from params or config.
    Returns 0.0 if no valid values are found.
    """
    src = params or {}
    dphi_name = src.get("delta_phi_field_name", delta_phi_field_name)
    mask_name = src.get("mask_field",          mask_field)
    cutoff    = src.get("support_cutoff_eps", _DEFAULT_CUTOFF)

    norms = []
    for agent in agents:
        delta = getattr(agent, dphi_name, None)
        mask  = getattr(agent, mask_name, None)
        if delta is None or mask is None:
            continue

        support = mask > cutoff
        if not support.any():
            continue

        delta_norm = np.linalg.norm(delta, axis=-1)
        norms.append(np.max(delta_norm[support]))

    return float(max(norms)) if norms else 0.0


def compute_transport_strength(
    agent_i: Any,
    agent_j: Any,
    q_field: str        = "q",
    mask_field: str     = "mask",
    overlap_eps: float  = config.support_cutoff_eps,
    log_eps: float      = config.log_eps,
) -> float:
    """
    Compute average per-point transport error between two agents:
      ||q_j(c) - Ω_{ij}(c)·q_j(c)||_2 averaged over their overlap,
    using each Agent’s cached Omega & Omega_inv.
    """

    # 1) masks and overlap
    mi = getattr(agent_i, mask_field) > overlap_eps
    mj = getattr(agent_j, mask_field) > overlap_eps
    overlap = mi & mj
    if not overlap.any():
        return 0.0

    # 2) extract q_j values over overlap
    qj_vals = sanitize_q(getattr(agent_j, q_field)[overlap], eps=log_eps)  # (M, K)

    # 3) grab cached Omega patches
    Oi_patch    = agent_i.Omega    [overlap]   # (M, K, K)
    Oj_inv_patch= agent_j.Omega_inv[overlap]   # (M, K, K)

    # 4) form inter-agent Ω_ij = Oi @ Oj_inv
    Omegas_ij = np.einsum("mab,mbc->mac", Oi_patch, Oj_inv_patch)

    # 5) rotate qj and sanitize
    qj_rot = batch_apply_omega(qj_vals, Omegas_ij)  # (M, K)
    qj_rot = sanitize_q(qj_rot, eps=log_eps)

    # 6) compute pointwise L2 norm error and return mean
    diffs = qj_vals - qj_rot                       # (M, K)
    norms = np.linalg.norm(diffs, axis=-1)         # (M,)
    return float(norms.mean())

def compute_network_transport_strength(
    agents,
    q_field: str       = "q",
    mask_field: str    = "mask",
    overlap_eps: float = config.support_cutoff_eps,
    log_eps: float     = config.log_eps,
) -> float:
    """
    Average transport strength over all unordered agent pairs,
    using each Agent’s cached Omega & Omega_inv.
    """
    total = 0.0
    count = 0

    for i, agent_i in enumerate(agents):
        for nb in agent_i.neighbors:
            j = nb["id"]
            if j <= i:
                continue

            ts = compute_transport_strength(
                agent_i,
                agent_j      = agents[j],
                q_field      = q_field,
                mask_field   = mask_field,
                overlap_eps  = overlap_eps,
                log_eps      = log_eps
            )
            total += ts
            count += 1

    # avoid division by zero
    return float(total / (count or 1))


def compute_average_entropy(
    agents,
    q_field="q",
    mask_field="mask",
    support_cutoff_eps=1e-3,
    log_eps=1e-8,
):
    entropies = []
    for agent in agents:
        q    = sanitize_q(getattr(agent, q_field), eps=log_eps)
        mask = getattr(agent, mask_field) > support_cutoff_eps

        # pointwise entropy
        ent  = -np.sum(q * np.log(q), axis=-1)

        # mean over support
        n = mask.sum()
        if n > 0:
            entropies.append(ent[mask].sum() / n)

    return float(np.mean(entropies)) if entropies else 0.0


def compute_phi_norm(
    agents,
    phi_field="phi",
    mask_field="mask",
    support_cutoff_eps=1e-3,
):
    norms = []
    for agent in agents:
        phi  = getattr(agent, phi_field)
        mask = getattr(agent, mask_field) > support_cutoff_eps
        n    = mask.sum()
        if n > 0:
            norms.append(masked_norm(phi, mask) / n)
    return float(np.mean(norms)) if norms else 0.0


def compute_entropy_field(agents, i, q_field="q", mask_field="mask", support_cutoff_eps=1e-3, log_eps=1e-8):
    q     = sanitize_q(getattr(agents[i], q_field), eps=log_eps)
    mask  = getattr(agents[i], mask_field) > support_cutoff_eps
    ent   = -np.sum(q * np.log(q), axis=-1)
    return ent * mask


def compute_curvature_field(
    agents,
    i,
    phi_field: str = "phi",
    mask_field: str = "mask",
    generators=None,
    support_cutoff_eps: float | None = None,
) -> np.ndarray:
    """
    Compute pointwise mean curvature F(x) = average over |F_{μν}(x)|,
    masked by support.

    Returns array of shape same as agent mask.
    """
    if generators is None:
        raise ValueError("`generators` must be provided to compute curvature field.")
    # determine support cutoff
    if support_cutoff_eps is None:
        support_cutoff_eps = _DEFAULT_CUTOFF

    agent = agents[i]
    phi   = getattr(agent, phi_field)
    mask  = getattr(agent, mask_field)
    support = mask > support_cutoff_eps

    # compute dict of Frobenius norms F_{μν}(x)
    F_dict = compute_field_strength(phi, generators)
    if not F_dict:
        return np.zeros_like(mask, dtype=float)

    # stack norms and average over pairs
    F_stack = np.stack(list(F_dict.values()), axis=-1)  # shape (..., n_pairs)
    mean_F  = np.mean(F_stack, axis=-1)                 # shape (...)

    return mean_F * support.astype(float)


def compute_curvature_norm(
    agents,
    phi_field: str = "phi",
    mask_field: str = "mask",
    generators=None,
    support_cutoff_eps: float | None = None,
    log_eps: float = 1e-8,
) -> float:
    """
    Compute the agent-averaged mean curvature norm:
      1) For each agent, compute pointwise mean_F(x) and mask by support
      2) Spatially average mean_F over support
      3) Finally, average over agents
    """
    if generators is None:
        raise ValueError("`generators` must be provided to compute curvature norm.")
    if support_cutoff_eps is None:
        support_cutoff_eps = _DEFAULT_CUTOFF

    norms = []
    for agent in agents:
        phi  = getattr(agent, phi_field)
        mask = getattr(agent, mask_field)
        support = mask > support_cutoff_eps
        if not support.any():
            continue

        F_dict = compute_field_strength(phi, generators)
        if not F_dict:
            continue

        F_stack = np.stack(list(F_dict.values()), axis=-1)
        mean_F   = np.mean(F_stack, axis=-1)

        # spatial average over support
        spatial_avg = np.sum(mean_F[support]) / (np.count_nonzero(support) + log_eps)
        norms.append(spatial_avg)

    return float(np.mean(norms)) if norms else 0.0



def compute_phi_laplacian_norm_field(agents, i):
    """
    Returns pointwise Frobenius norm of the Laplacian of phi_i, masked by support.
    """
    phi = agents[i].phi  # shape (..., dim_G)
    mask = agents[i].mask > 0
    # compute componentwise Laplacian
    lap_phi = np.stack([laplace(phi[..., d]) for d in range(phi.shape[-1])], axis=-1)
    # Frobenius norm over Lie-algebra components
    norm = np.linalg.norm(lap_phi, axis=-1)
    return norm * mask



def compute_phi_laplacian_norm(
    agents,
    phi_field: str = "phi",
    mask_field: str = "mask",
    support_cutoff_eps: float | None = None,
    log_eps: float = 1e-8,
) -> float:
    """
    Compute the average per-agent RMS norm of the Laplacian of the φ field.
    1) Threshold mask by support_cutoff_eps.
    2) Compute componentwise Laplacian via scipy.ndimage.laplace.
    3) Compute masked_norm over support and normalize by support size.
    4) Return the mean over all agents.
    """
    if support_cutoff_eps is None:
        support_cutoff_eps = _DEFAULT_CUTOFF

    norms = []
    for agent in agents:
        phi = getattr(agent, phi_field)
        mask = getattr(agent, mask_field) > support_cutoff_eps
        if not np.any(mask):
            continue

        # componentwise Laplacian
        lap_phi = np.stack([laplace(phi[..., d]) for d in range(phi.shape[-1])], axis=-1)
        # RMS norm over support
        val = masked_norm(lap_phi, mask) / (np.count_nonzero(mask) + log_eps)
        norms.append(val)

    return float(np.mean(norms)) if norms else 0.0



def compute_fisher_information_norm(
    agents,
    q_field: str = "q",
    mask_field: str = "mask",
    support_cutoff_eps: float | None = None,
    log_eps: float = 1e-8,
) -> float:
    
    """
    Compute the mean Fisher information norm across all agents:
      I = ∫ (∑_μ ||∇_μ q||^2 / q) over support
    Returns the average over agents of (spatially averaged I).
    """
    if support_cutoff_eps is None:
        support_cutoff_eps = _DEFAULT_CUTOFF

    norms = []
    for agent in agents:
        q      = sanitize_q(getattr(agent, q_field), eps=log_eps)  # (..., K)
        mask   = getattr(agent, mask_field) > support_cutoff_eps    # boolean mask
        if not mask.any():
            continue

        # compute spatial gradient list over spatial axes
        D       = q.ndim - 1
        grads   = np.gradient(q, axis=tuple(range(D)))            # list of (..., K)

        # Fisher integrand: sum over μ of (||∇_μ q||^2 / q)
        fisher = np.zeros_like(mask, dtype=float)
        for g in grads:
            # g has shape (..., K)
            fisher += np.sum((g**2) / (q + log_eps), axis=-1)

        # spatial average over support
        val = np.sum(fisher[mask]) / (np.count_nonzero(mask) + log_eps)
        norms.append(val)

    return float(np.mean(norms)) if norms else 0.0


def compute_cross_model_kl(
    agents,
    support_eps: float = config.support_cutoff_eps,
    log_eps: float     = config.log_eps,
    n_jobs: int        = 1,
) -> float:
    """
    Compute average D_KL(q_i || ~Ω_{ij} p_j) over unique overlapping agent pairs,
    where ~Ω_{ij}(x) = exp(φ_i(x)) @ exp(-φ_model_j(x)), by re-using cached Omegas.
    """

    def _pair_kl(i, j):
        Ai = agents[i]
        Aj = agents[j]

        # 1) overlap mask
        mi = Ai.mask > support_eps
        mj = Aj.mask > support_eps
        ov = mi & mj
        if not ov.any():
            return 0.0, 0.0

        # 2) extract & sanitize distributions
        qi = sanitize_q(Ai.q[ov], eps=log_eps)       # (M, K)
        pj = sanitize_q(Aj.p[ov], eps=log_eps)       # (M, K)

        # 3) grab cached transports
        #    - belief transport at i:     (M, K, K)
        #    - model transport inverse at j: (M, K, K)
        Oi_belief     = Ai.Omega       [ov]
        Oj_model_inv  = Aj.Omega_model_inv[ov]

        # 4) build ~Ω_ij = Oi_belief @ Oj_model_inv
        Omegas_tilde = np.einsum("mab,mbc->mac",
                                 Oi_belief,
                                 Oj_model_inv)

        # 5) transport p_j into q-space
        pj_rot = batch_apply_omega(pj, Omegas_tilde)     # (M, K)
        pj_rot = repair_if_forgotten_batch(pj_rot, eps=log_eps)
        # re-normalize just in case
        pj_rot /= (pj_rot.sum(axis=-1, keepdims=True) + log_eps)

        # 6) pointwise KL
        kl_vals = np.sum(qi * (np.log(qi) - np.log(pj_rot + log_eps)), axis=-1)
        return float(kl_vals.sum()), float(ov.sum())

    # unique i<j neighbor pairs
    pairs = [
        (i, nb["id"])
        for i, A in enumerate(agents)
        for nb in A.neighbors
        if nb["id"] > i
    ]

    # parallel compute
    results = Parallel(n_jobs=n_jobs, backend="threading")(
        delayed(_pair_kl)(i, j) for i, j in pairs
    )

    total_kl    = sum(k for k, w in results)
    total_count = sum(w for k, w in results)
    return float(total_kl / (total_count + log_eps)) if total_count > 0 else 0.0


def compute_information_update_norm(
    agent,
    delta_q_field="delta_q",
    mask_field="mask",
    support_cutoff_eps: float | None = None,
    log_eps: float = 1e-8
) -> float:
    """
    Compute RMS norm of information update delta_q for a single agent over its support.

    Returns 0.0 if no support or delta_q missing.
    """
    if support_cutoff_eps is None:
        support_cutoff_eps = _DEFAULT_CUTOFF

    dq = getattr(agent, delta_q_field, None)
    mask = getattr(agent, mask_field)
    if dq is None or mask is None:
        return 0.0

    support = mask > support_cutoff_eps
    if not np.any(support):
        return 0.0

    # per-point norm of delta_q
    perpt_norm = np.linalg.norm(dq, axis=-1)
    # mean over support
    return float(np.sum(perpt_norm[support]) / (np.count_nonzero(support) + log_eps))

def log_all_metrics_fused(
    agents,
    step: int,
    params: dict | None = None,
    q_field: str            = "q",
    p_field: str            = "p",
    phi_belief_field: str   = "phi",
    phi_model_field: str    = "phi_model",
    mask_field: str         = "mask",
    overlap_eps: float | None = None,
    log_eps: float          = 1e-8,
    n_jobs: int             = 1,
    generators = None                      # <- ADDED: required for curvature computation
) -> dict:
    """
    Single‐pass diagnostics: energy + all per-agent norms in one Parallel loop.
    """
    import numpy as np
    from joblib import Parallel, delayed
    from generalized_math_utils import sanitize_q, laplacian_field
    from generalized_omega import batch_apply_omega, compute_field_strength
    from generalized_diagnostics_metrics import compute_coherence, compute_free_energy, compute_curvature_field

    cfg = params or {k: getattr(config, k) for k in dir(config) if not k.startswith("__")}
    if overlap_eps is None:
        overlap_eps = cfg.get("support_cutoff_eps", config.support_cutoff_eps)

    alpha      = cfg.get("alpha",           config.alpha)
    beta       = cfg.get("beta",            config.beta)
    model_align_weight     = cfg.get("model_align_weight", config.model_align_weight)
    model_gauge_weight     = cfg.get("model_gauge_weight", config.model_gauge_weight)
    model_mass_weight      = cfg.get("model_mass_weight", config.model_mass_weight)
    model_feedback_weight  = cfg.get("model_feedback_weight", config.model_feedback_weight)
    phi_phi_tilde_coupling = cfg.get("phi_phi_tilde_coupling", config.phi_phi_tilde_coupling)
    cur_w      = cfg.get("curvature_weight", config.curvature_weight)

    from get_generators import get_generators
    lie_gens = get_generators(config.group_name, config.K) if cur_w > 0 else None

    Q_list, P_list, Mask_list = [], [], []
    O_bel, O_inv, O_mod, O_mod_inv = [], [], [], []
    for A in agents:
        mask = getattr(A, mask_field) > overlap_eps
        Mask_list.append(mask)
        Q_list.append(sanitize_q(getattr(A, q_field), eps=log_eps))
        P_list.append(sanitize_q(getattr(A, p_field), eps=log_eps))
        O_bel.append(A.Omega)
        O_inv.append(A.Omega_inv)
        O_mod.append(A.Omega_model)
        O_mod_inv.append(A.Omega_model_inv)

    N = len(agents)

    def _agent_stats(
    i,
    A,
    step,
    q_field,
    p_field,
    phi_belief_field,
    phi_model_field,
    mask_field,
    cfg,
    generators
):


        A    = agents[i]
        mask = Mask_list[i]
        curvature_model_norm = 0.0
        curvature_norm = 0.0
        e_curv = 0.0
        if not mask.any():
            return i, {
                "e_kl":0,"e_lap":0,"e_lap_m":0,"e_curv":0,"e_align":0,
                "e_mass":0,"e_feedback":0,"e_cross":0,
                "phi_norm":0,"phi_model_norm":0,"entropy":0,
                "lap_phi_norm":0,"delta_phi_norm":0,
                "curvature_norm":0,"fisher_information":0,
                "model_arr": np.zeros(N)
            }

        qi = Q_list[i]
        pi = P_list[i]

        e_kl = alpha * np.sum(kl_divergence(qi, pi)[mask])
        e_feedback = model_feedback_weight * np.sum(kl_divergence(pi, qi)[mask])

        e_lap   = model_gauge_weight * np.linalg.norm(laplacian_field(A.phi_model)[mask], axis=-1).sum()
        e_lap_m = 0  # kept for compatibility (used to be γ̃)

        e_mass  = model_mass_weight * np.sum(np.linalg.norm(A.phi_model[mask], axis=-1)**2)
        e_cross = phi_phi_tilde_coupling * np.sum(np.sum(A.phi[mask] * A.phi_model[mask], axis=-1))

        # --- Always compute φ curvature norm ---
        Fdict = compute_field_strength(A.phi, lie_gens)
        Fstack = np.stack(list(Fdict.values()), axis=-1)
        mean_F = np.mean(Fstack, axis=-1)
        curvature_norm = float(np.sum(mean_F[mask]))

        if cur_w > 0:
            e_curv = cur_w * np.sum(mean_F[mask])
        else:
            e_curv = 0.0

# --- Always compute φ_model curvature norm ---
        if hasattr(A, "phi_model") and A.phi_model is not None:
            Fdict_model = compute_field_strength(A.phi_model, lie_gens)
            Fstack_model = np.stack(list(Fdict_model.values()), axis=-1)
            mean_F_model = np.mean(Fstack_model, axis=-1)
            curvature_model_norm = float(np.sum(mean_F_model[mask]))
        else:
            curvature_model_norm = 0.0

        e_align = 0.0
        model_arr = np.zeros(N, dtype=float)

        for nb in A.neighbors:
            j = nb["id"]
            ov = mask & Mask_list[j]
            if not ov.any():
                continue

            q_i_ov = qi[ov]
            q_j_ov = Q_list[j][ov]
            Oi     = O_bel[i][ov]
            Oj_inv = O_inv[j][ov]
            Ω      = np.einsum("mab,mbc->mac", Oi, Oj_inv)
            qj_t   = batch_apply_omega(q_j_ov, Ω)
            e_align += beta * kl_divergence(q_i_ov, sanitize_q(qj_t, eps=log_eps)).sum()

            p_i_ov = P_list[i][ov]
            p_j_ov = P_list[j][ov]
            Oim    = O_mod[i][ov]
            Oj_mi  = O_mod_inv[j][ov]
            Ωm     = np.einsum("mab,mbc->mac", Oim, Oj_mi)
            pj_t   = batch_apply_omega(p_j_ov, Ωm)
            pj_t   = sanitize_q(pj_t, eps=log_eps)
            klp    = model_align_weight * kl_divergence(p_i_ov, pj_t).sum()
            model_arr[i] += klp
            model_arr[j] += klp

        q_s      = sanitize_q(getattr(A, q_field), eps=log_eps)[mask]
        phi_s    = getattr(A, phi_belief_field)[mask]
        phi_m_s  = getattr(A, phi_model_field)[mask]

        phi_norm       = np.linalg.norm(phi_s, axis=-1).sum()
        phi_model_norm = np.linalg.norm(phi_m_s, axis=-1).sum()
        entropy        = float(-np.sum(q_s * np.log(q_s + log_eps)))

        lap_phi_norm   = np.linalg.norm(laplacian_field(A.phi)[mask], axis=-1).sum()
        delta_phi_norm = float(np.linalg.norm(getattr(A, "delta_phi", 0.0), axis=-1)[mask].max()) if hasattr(A, "delta_phi") else 0.0

        D = q_s.ndim - 1
        grads = np.gradient(q_s, axis=tuple(range(D)))
        fisher_information = float(sum((g**2)/(q_s + log_eps) for g in grads).sum())

        return i, {
            "e_kl": e_kl, "e_lap": e_lap, "e_lap_m": e_lap_m,
            "e_curv": e_curv, "e_align": e_align,
            "e_mass": e_mass, "e_feedback": e_feedback, "e_cross": e_cross,
            "phi_norm": phi_norm, "phi_model_norm": phi_model_norm,
            "entropy": entropy,
            "lap_phi_norm": lap_phi_norm,
            "delta_phi_norm": delta_phi_norm,
            "fisher_information": fisher_information,
            "curvature_norm": curvature_norm,
            "curvature_model_norm": curvature_model_norm,

            "model_arr": model_arr
        }
    from get_generators import get_generators
    lie_gens = get_generators(config.group_name, config.K)  # ← Always generate!
    results = Parallel(n_jobs=n_jobs, backend="threading")(
    delayed(_agent_stats)(
        i, agents[i], step, q_field, p_field,
        phi_belief_field, phi_model_field, mask_field,
        cfg, lie_gens  # ✅ pass the actual generators, not the unused argument
    ) for i in range(N)
)


    accum = {
        "KL(q||p)":0, "KL(q||Ωq)":0, "Curvature(F²)":0,
        "Laplacian(φ_model)":0, "Mass(φ_model)":0,
        "Feedback KL(p||q)":0, "Cross(φ·φ̃)":0,
    }
    total_support = 0
    model_align_sum = np.zeros(N)
    phi_norm = phi_model_norm = entropy = lap_phi_norm = delta_phi_norm = curvature_norm = curvature_model_norm = fisher_info = 0.0
    for i, s in results:
        mask = Mask_list[i]
        support = int(mask.sum())
        total_support += support

        accum["KL(q||p)"]           += s["e_kl"]
        accum["KL(q||Ωq)"]          += s["e_align"]
        accum["Curvature(F²)"]      += s["e_curv"]
        accum["Laplacian(φ_model)"] += s["e_lap"]
        accum["Mass(φ_model)"]      += s["e_mass"]
        accum["Feedback KL(p||q)"]  += s["e_feedback"]
        accum["Cross(φ·φ̃)"]         += s["e_cross"]
        model_align_sum             += s["model_arr"]

        phi_norm       += s["phi_norm"]
        phi_model_norm += s["phi_model_norm"]
        entropy        += s["entropy"]
        lap_phi_norm   += s["lap_phi_norm"]
        delta_phi_norm += s["delta_phi_norm"]
        curvature_norm += s["curvature_norm"]
        curvature_model_norm += s["curvature_model_norm"]
        fisher_info    += s["fisher_information"]

        agents[i].log_metrics(step, {
            "kl_self": s["e_kl"]/support,
            "kl_align": s["e_align"]/support,
            "free_energy": compute_free_energy(agents[i]),
            "coherence": compute_coherence(agents[i].phi, agents[i].mask),
            "model_coherence": compute_coherence(agents[i].phi_model, agents[i].mask),
            "phi_norm": s["phi_norm"],
            "phi_model_norm": s["phi_model_norm"],
            "entropy": s["entropy"],
            "lap_phi_norm": s["lap_phi_norm"],
            "delta_phi_norm": s["delta_phi_norm"],
            "curvature_norm": s["curvature_norm"],
            "curvature_model_norm": s["curvature_model_norm"],
            "fisher_information": s["fisher_information"],
            "e_mass": s["e_mass"],
            "e_feedback": s["e_feedback"],
            "e_cross": s["e_cross"],
        } | {f"kl_model_align_agent{j}": val / support for j, val in enumerate(s["model_arr"])})

    S = max(total_support, 1)
    metrics = {
        "step": step,
        "kl_self":         accum["KL(q||p)"]/S,
        "kl_align":        accum["KL(q||Ωq)"]/S,
        "phi_norm":        phi_norm/S,
        "phi_model_norm":  phi_model_norm/S,
        "entropy":         entropy/N,
        "lap_phi_norm":    lap_phi_norm/S,
        "delta_phi_norm":  delta_phi_norm/S,
        "curvature_norm":  curvature_norm/S,
        "fisher_information": fisher_info/S,
        "lap_phi_model_norm": accum["Laplacian(φ_model)"]/S,
        "mass_phi_model":      accum["Mass(φ_model)"]/S,
        "kl_feedback":         accum["Feedback KL(p||q)"]/S,
        "phi_phi_model_dot":   accum["Cross(φ·φ̃)"]/S,
        "curvature_model_norm": curvature_model_norm / S,

        "total_energy": (
            accum["KL(q||p)"] +
            accum["KL(q||Ωq)"] +
            model_align_sum.sum() +
            accum["Laplacian(φ_model)"] +
            accum["Mass(φ_model)"] +
            accum["Feedback KL(p||q)"] +
            accum["Cross(φ·φ̃)"] +
            accum["Curvature(F²)"]
        ) / S,
    }
    for idx, val in enumerate(model_align_sum):
        metrics[f"kl_model_align_agent{idx}"] = val / S

    return metrics
