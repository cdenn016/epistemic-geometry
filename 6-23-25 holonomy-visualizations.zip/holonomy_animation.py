# -*- coding: utf-8 -*-
"""
Created on Tue Jun 24 17:57:53 2025

@author: chris and christine
"""

import os
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation, PillowWriter

CSV_PATH = "holonomy_experiments/master_summary.csv"
OUT_DIR = "Holonomy_Visualizations"
os.makedirs(OUT_DIR, exist_ok=True)

def animate_belief_sequence(belief_seq, param, exp_type, outname=None):
    K = len(belief_seq[0])
    frames = len(belief_seq)

    initial_belief = belief_seq[0]
    y_max = max(np.max(b) for b in belief_seq) * 1.1

    fig, ax = plt.subplots(figsize=(6, 4))
    x = np.arange(K)
    line_current, = ax.plot(x, belief_seq[0], label="b_t", color="blue")
    line_initial, = ax.plot(x, initial_belief, linestyle="--", color="black", label="initial b₀")
    ax.set_ylim(0, y_max)
    ax.set_title(f"Step 1/{frames}\n{exp_type}: {param}")
    ax.set_xlabel("Fiber index k")
    ax.set_ylabel("b[k]")
    ax.legend(loc="upper right")

    def update(frame):
        b = belief_seq[frame]
        line_current.set_ydata(b)
        ax.set_title(f"Step {frame+1}/{frames}\n{exp_type}: {param}")
        return line_current,

    anim = FuncAnimation(fig, update, frames=frames, blit=False)

    if outname is None:
        fname = f"{exp_type}_{param}_belief_transport.gif".replace(" ", "")
        outname = os.path.join(OUT_DIR, fname)

    anim.save(outname, writer=PillowWriter(fps=5))
    plt.close()
    print(f"[SAVED] {outname}")


import numpy as np
import pandas as pd
import os

def main():
    df = pd.read_csv(CSV_PATH)

    for exp_type in df["experiment"].unique():
        df_exp = df[df["experiment"] == exp_type]
        for param in df_exp["param"].unique():
            df_cycle = df_exp[df_exp["param"] == param].sort_values("step")
            first_row = df_cycle.iloc[0]
            belief_seq_raw = first_row.get("belief_seq", None)
            if not belief_seq_raw:
                print(f"[SKIP] No belief_seq for {exp_type} {param}")
                continue
            try:
                # Patch: define safe scope for array parsing
                scope = {
                    "array": np.array,
                    "float32": np.float32,
                    "float64": np.float64,
                    "np": np,
                }
                belief_seq = eval(belief_seq_raw, scope)
                belief_seq = [np.array(b) for b in belief_seq]
                animate_belief_sequence(belief_seq, param, exp_type)
            except Exception as e:
                print(f"[ERROR] Failed parsing belief_seq for {param}: {e}")

if __name__ == "__main__":
    main()

