import numpy as np
import config
from scipy.linalg import expm
from joblib import Parallel, delayed, parallel_backend

from generalized_math_utils import kl_divergence

from scipy.ndimage import gaussian_filter
from numerical_utils import sanitize_sigma

# Add this near the top or bottom of generalized_omega.py

import numpy as np

def get_generators(group_name, K):
    """
    Returns the Lie algebra generators for a supported group and representation dimension K.

    Args:
        group_name: str, e.g. "so3", "sl2r"
        K: dimension of the representation (e.g. 3 for fundamental SO(3))

    Returns:
        generators: (d, K, K) numpy array where d = Lie algebra dimension
    """
    if group_name.lower() == "so3":
        return so3_generators(K)
    elif group_name.lower() == "sl2r":
        return sl2r_generators(K)
    else:
        raise ValueError(f"[get_generators] Unsupported group: {group_name}")


def so3_generators(K):
    if K != 3:
        raise NotImplementedError(f"Only SO(3) fundamental (K=3) supported")
    Jx = np.array([[0, 0, 0], [0, 0, -1], [0, 1, 0]])
    Jy = np.array([[0, 0, 1], [0, 0, 0], [-1, 0, 0]])
    Jz = np.array([[0, -1, 0], [1, 0, 0], [0, 0, 0]])
    return np.stack([Jx, Jy, Jz])


def sl2r_generators(K):
    if K != 3:
        raise NotImplementedError(f"Only SL(2,R) 3D rep supported for now")
    H = np.array([[1, 0, 0], [0, 0, 0], [0, 0, -1]])
    E = np.array([[0, 1, 0], [0, 0, 1], [0, 0, 0]])
    F = np.array([[0, 0, 0], [1, 0, 0], [0, 1, 0]])
    return np.stack([H, E, F])


import numpy as np

def compute_omega_pair(phi_i, phi_j, generators, group_name=None):
    """
    Computes the inter-agent gauge transport operator Ω_ij = exp(φ_i) · exp(−φ_j)

    Args:
        phi_i: (..., d) Lie algebra field for agent i
        phi_j: (..., d) Lie algebra field for agent j
        generators: (d, K, K) Lie algebra generators
        group_name: optional, e.g., "so3", "sl2r", used for antisymmetrization

    Returns:
        Omega_ij: (..., K, K) matrix field
    """
    assert phi_i.shape == phi_j.shape, \
        f"[Ω] Shape mismatch: phi_i {phi_i.shape}, phi_j {phi_j.shape}"

    d = generators.shape[0]
    assert phi_i.shape[-1] == d, \
        f"[Ω] phi_i last dim {phi_i.shape[-1]} ≠ generator dim {d}"

    # Exponentiate
    exp_phi_i = exp_lie_algebra_irrep(phi_i, generators, group_name=group_name)
    exp_neg_phi_j = exp_lie_algebra_irrep(-phi_j, generators, group_name=group_name)

    # Compose Ω_ij = exp(φ_i) · exp(−φ_j)
    Omega_ij = np.matmul(exp_phi_i, exp_neg_phi_j)
    return Omega_ij


def compute_curvature_gradient_analytical(phi: np.ndarray, generators: np.ndarray, dx: float = 1.0, smoothing_sigma: float = 1.0) -> np.ndarray:
    """
    Compute the variational gradient of the curvature energy ∇_φ Tr[F^2] in a Lie-covariant and numerically stable way.

    Args:
        phi:        (H, W, d) Lie algebra coordinates φ^a(x)
        generators: (d, K, K) Lie algebra basis G^a (should be trace-orthonormal)
        dx:         lattice spacing
        smoothing_sigma: Gaussian smoothing sigma for finite difference stabilization

    Returns:
        grad:       (H, W, d) curvature gradient in Lie algebra basis
    """
    H, W, d = phi.shape
    K = generators.shape[1]

    # Smooth φ to stabilize finite differences
    phi_smooth = np.stack([gaussian_filter(phi[..., a], sigma=smoothing_sigma, mode='wrap') for a in range(d)], axis=-1)

    # Compute A_x and A_y using central differences
    A_x = (np.roll(phi_smooth, -1, axis=0) - np.roll(phi_smooth, 1, axis=0)) / (2 * dx)
    A_y = (np.roll(phi_smooth, -1, axis=1) - np.roll(phi_smooth, 1, axis=1)) / (2 * dx)

    # Project A_μ = φ^a G^a
    A_x_mat = np.einsum("ijk,klm->ijlm", A_x, generators)
    A_y_mat = np.einsum("ijk,klm->ijlm", A_y, generators)

    # Compute F_{xy} = dA_y/dx - dA_x/dy + [A_x, A_y]
    dAy_dx = (np.roll(A_y_mat, -1, axis=0) - np.roll(A_y_mat, 1, axis=0)) / (2 * dx)
    dAx_dy = (np.roll(A_x_mat, -1, axis=1) - np.roll(A_x_mat, 1, axis=1)) / (2 * dx)

    comm_xy = np.einsum("...ij,...jk->...ik", A_x_mat, A_y_mat) - np.einsum("...ij,...jk->...ik", A_y_mat, A_x_mat)
    F_xy = dAy_dx - dAx_dy + comm_xy

    # Lie-covariant divergence D_μ F^{μν}
    dF_dx = (np.roll(F_xy, -1, axis=0) - np.roll(F_xy, 1, axis=0)) / (2 * dx)
    dF_dy = (np.roll(F_xy, -1, axis=1) - np.roll(F_xy, 1, axis=1)) / (2 * dx)

    # Commutators for covariant derivative
    comm1 = np.einsum("...ij,...jk->...ik", A_x_mat, F_xy) - np.einsum("...ij,...jk->...ik", F_xy, A_x_mat)
    comm2 = np.einsum("...ij,...jk->...ik", A_y_mat, F_xy) - np.einsum("...ij,...jk->...ik", F_xy, A_y_mat)

    divF_covariant = dF_dx + dF_dy + comm1 + comm2

    # Project back to Lie algebra basis using trace (assuming orthonormal basis)
    grad = np.zeros((H, W, d), dtype=phi.dtype)
    for a in range(d):
        G = generators[a]
        grad[..., a] = 2.0 * np.einsum("...ij,ij->...", divF_covariant, G)

    return grad


def compute_gauge_potential(phi, dx=1.0):
    """
    Compute gauge potentials A_μ^a = ∂_μ φ^a using central differences with periodic boundaries.

    Args:
        phi: np.ndarray, shape (..., d), where
             ... represents spatial dimensions (S_1,...,S_D),
             d = dim Lie algebra.
        dx: float, lattice spacing

    Returns:
        A: tuple of length D, each entry np.ndarray of shape (..., d),
           spatial derivatives of phi along each base manifold dimension.
    """
    D = phi.ndim - 1  # subtract Lie algebra dimension axis
    A = tuple(
        (np.roll(phi, -1, axis=axis) - np.roll(phi, 1, axis=axis)) / (2 * dx)
        for axis in range(D)
    )
    return A



def adaptive_expm(G, clip_norm=None, max_norm=None, threshold=1e-3):
    """
    Rescales G to prevent instability, then exponentiates using:
      - 4th-order Taylor for small ‖G‖
      - expm(G) otherwise

    Parameters:
        G: (K, K) Lie algebra element
        clip_norm: soft cap — rescales G if ‖G‖ > clip_norm
        max_norm: hard cap — forcibly rescales if ‖G‖ > max_norm
        threshold: below this, use 4th-order Taylor

    Returns:
        exp(G) ∈ Lie group
    """
    norm_G = np.linalg.norm(G) + 1e-16

    if clip_norm is not None and norm_G > clip_norm:
        G = G * (clip_norm / norm_G)

    if max_norm is not None and norm_G > max_norm:
        G = G * (max_norm / norm_G)

    if norm_G < threshold:
        I = np.eye(G.shape[0], dtype=G.dtype)
        G2 = G @ G
        G3 = G2 @ G
        G4 = G3 @ G
        return I + G + 0.5 * G2 + (1/6) * G3 + (1/24) * G4
    else:
        return expm(G)


def exp_lie_algebra_irrep(
    v_batch,
    generators,
    use_expm=True,
    threshold=1e-3,
    max_norm=10,
    group_name=None,
    n_jobs=-1
):
    """
    Compute batch of exp(sum_a v[a] * T_a) using Taylor or expm depending on norm.

    Parameters:
        v_batch: (..., dim_G) Lie algebra coefficients
        generators: (dim_G, K, K) Lie algebra generators
        use_expm: fallback to expm if large-norm
        threshold: Taylor cutoff
        max_norm: clamp Lie vector norms
        group_name: used for antisymmetrization ("so3", "su2", etc)
        n_jobs: parallel expm if large batch

    Returns:
        (..., K, K) exponentiated matrices
    """
    *batch_shape, dim_G = v_batch.shape
    v_flat = v_batch.reshape(-1, dim_G)
    N = v_flat.shape[0]
    _, K, _ = generators.shape
    dtype = v_batch.dtype

    # Clip large φ vectors
    norms = np.linalg.norm(v_flat, axis=1)
    eps = 1e-16
    scale_factors = np.minimum(1.0, max_norm / (norms + eps))
    v_scaled = v_flat * scale_factors[:, None]

    if np.any(scale_factors < 1.0):
        print(f"[Ω] Clipped {np.sum(scale_factors < 1)} / {N} φ vectors to ‖φ‖ ≤ {max_norm}")

    # Build algebra elements
    G_batch = np.einsum("na,aij->nij", v_scaled, generators)

    # Antisymmetrize if applicable
    if group_name == "so3":
        G_batch = 0.5 * (G_batch - np.transpose(G_batch, axes=(0, 2, 1)))
    elif group_name == "su2":
        G_batch = 0.5 * (G_batch - np.transpose(G_batch, axes=(0, 2, 1)).conj())

    result = np.empty((N, K, K), dtype=dtype)
    approx_mask = norms * scale_factors < threshold

    # 4th-order Taylor expansion for small-norm matrices
    if np.any(approx_mask):
        G_approx = G_batch[approx_mask]
        I = np.eye(K, dtype=dtype)[None, :, :]
        G2 = G_approx @ G_approx
        G3 = G2 @ G_approx
        G4 = G2 @ G2
        result[approx_mask] = (
            I + G_approx + 0.5 * G2 + (1.0 / 6.0) * G3 + (1.0 / 24.0) * G4
        )

    # Fallback expm with NaN/Inf protection
    if np.any(~approx_mask):
        idxs = np.flatnonzero(~approx_mask)
        G_heavy = [G_batch[i] for i in idxs]
        with parallel_backend("threading"):
            expm_results = Parallel(n_jobs=n_jobs)(
                delayed(adaptive_expm)(
                    G, clip_norm=None, max_norm=max_norm, threshold=threshold
                    ) for G in G_heavy
                )
        for i, res in zip(idxs, expm_results):
            result[i] = res
            
    return result.reshape(*batch_shape, K, K)


def batch_apply_omega(mu_batch, sigma_batch, omega_batch, n_jobs=None, parallel_threshold=1000):
    """
    Applies Ω to MVGs using Cholesky transport:
        μ' = Ω μ
        Σ' = (Ω L)(Ω L)ᵀ  where Σ = LLᵀ (Cholesky)

    Returns:
        μ', Σ' with same shapes
    """
    mu_batch     = np.asarray(mu_batch)
    sigma_batch  = np.asarray(sigma_batch)
    omega_batch  = np.asarray(omega_batch)

    assert mu_batch.shape[:-1] == omega_batch.shape[:-2], "Shape mismatch in batch dims"
    assert mu_batch.shape[-1] == omega_batch.shape[-1], "Fiber dim mismatch"

    n_jobs = n_jobs or getattr(config, "num_cores", 1)
    flat_mu     = mu_batch.reshape(-1, mu_batch.shape[-1])
    flat_omega  = omega_batch.reshape(-1, omega_batch.shape[-2], omega_batch.shape[-1])
    flat_sigma  = sigma_batch.reshape(-1, sigma_batch.shape[-2], sigma_batch.shape[-1])
    N, K = flat_mu.shape[0], flat_mu.shape[1]

    # Step 1: sanitize
    flat_sigma = sanitize_sigma(flat_sigma, eps=config.eps)

    # Step 2: transport means
    if N < parallel_threshold:
        mu_t = np.einsum("...ij,...j->...i", omega_batch, mu_batch)
    else:
        with parallel_backend("threading"):
            mu_t_flat = Parallel(n_jobs=n_jobs)(
                delayed(lambda μ, Ω: Ω @ μ)(μ, Ω) for μ, Ω in zip(flat_mu, flat_omega)
            )
        mu_t = np.stack(mu_t_flat, axis=0).reshape(mu_batch.shape)

    # Step 3: transport covariances
    def robust_cholesky(Σ, eps=1e-6):
        try:
            return np.linalg.cholesky(Σ), False, False
        except:
            try:
                eigvals, eigvecs = np.linalg.eigh(Σ)
                eigvals = np.clip(eigvals, eps, None)
                Σ_fixed = eigvecs @ np.diag(eigvals) @ eigvecs.T
                Σ_fixed = 0.5 * (Σ_fixed + Σ_fixed.T)
                return np.linalg.cholesky(Σ_fixed), True, False
            except:
                return np.eye(K), True, True

    sigma_t = np.zeros_like(flat_sigma)
    repaired = 0
    fallbacks = 0

    for i in range(N):
        L, was_repaired, was_fallback = robust_cholesky(flat_sigma[i], eps=config.eps)
        if was_repaired: repaired += 1
        if was_fallback: fallbacks += 1
        L_t = flat_omega[i] @ L
        sigma_t[i] = L_t @ L_t.T

    if repaired > 0:
        print(f"[Ω SPD-repair] Repaired {repaired} / {N}")
    if fallbacks > 0:
        print(f"[Ω FINAL fallback] Used identity for {fallbacks} / {N}")

    return mu_t, sigma_t.reshape(sigma_batch.shape)

#not used??
def compute_covariant_derivative_phi(phi, generators, dx=1.0):
    """
    Compute covariant derivative D_μ φ = ∂_μ φ + [A_μ, φ] with periodic BCs.

    Args:
        phi:        (H, W, d) array of Lie algebra coordinates
        generators: (d, K, K) Lie algebra basis
        dx:         lattice spacing

    Returns:
        D_phi: list of length D (spatial dims), each (H, W, K, K) matrix field
               representing D_μ φ(x) as a matrix at each point
    """
    D = phi.ndim - 1  # number of spatial dimensions
    H, W, d = phi.shape
    K = generators.shape[1]

    # Step 1: φ(x) as matrix field: (H, W, K, K)
    phi_matrix = np.einsum("ijk,klm->ijlm", phi, generators)

    # Step 2: naive derivatives of φ: (H, W, d) per axis
    dphi = [
        (np.roll(phi, -1, axis=axis) - np.roll(phi, 1, axis=axis)) / (2 * dx)
        for axis in range(D)
    ]

    # Step 3: A_μ = ∂_μ φ as matrix field
    A_mu_matrices = [np.einsum("ijk,klm->ijlm", dphi[axis], generators) for axis in range(D)]

    # Step 4: [A_μ, φ]
    commutators = [np.einsum("...ij,...jk->...ik", A, phi_matrix) -
                   np.einsum("...ij,...jk->...ik", phi_matrix, A)
                   for A in A_mu_matrices]

    # Step 5: D_μ φ = ∂_μ φ + [A_μ, φ]
    D_phi = [A_mu + comm for A_mu, comm in zip(A_mu_matrices, commutators)]

    return D_phi  # List of (H, W, K, K)


def compute_field_strength(phi: np.ndarray, generators: np.ndarray, dx: float = 1.0):
    """
    Compute curvature F_{xy} = ∂_x A_y - ∂_y A_x + [A_x, A_y]
    where A_μ = ∂_μ Φ, and Φ = φ^a G_a.

    Args:
        phi:        (H, W, d) — Lie algebra coordinates φ^a(x)
        generators: (d, K, K) — Lie algebra basis
        dx:         lattice spacing

    Returns:
        Dictionary with keys ("xy", ...) → array of shape (H, W, K, K)
    """
    H, W, d = phi.shape
    K = generators.shape[1]

    # Step 1: φ(x) as matrix field: Φ(x) = φ^a(x) G_a
    phi_matrix = np.einsum("ijk,klm->ijlm", phi, generators)  # (H, W, K, K)

    # Step 2: A_x = ∂_x Φ, A_y = ∂_y Φ  — central difference w/ PBCs
    A_x = (np.roll(phi_matrix, -1, axis=0) - np.roll(phi_matrix, 1, axis=0)) / (2 * dx)  # ∂_x Φ
    A_y = (np.roll(phi_matrix, -1, axis=1) - np.roll(phi_matrix, 1, axis=1)) / (2 * dx)  # ∂_y Φ

    # Step 3: Derivatives of A
    dAy_dx = (np.roll(A_y, -1, axis=0) - np.roll(A_y, 1, axis=0)) / (2 * dx)  # ∂_x A_y
    dAx_dy = (np.roll(A_x, -1, axis=1) - np.roll(A_x, 1, axis=1)) / (2 * dx)  # ∂_y A_x

    # Step 4: Commutator [A_x, A_y]
    comm = np.einsum("ijkl,ijln->ijkn", A_x, A_y) - np.einsum("ijkl,ijln->ijkn", A_y, A_x)

    # Step 5: Curvature
    F_xy = dAy_dx - dAx_dy + comm  # shape (H, W, K, K)

    return {"xy": F_xy}



def build_inter_agent_omega(phi_i, phi_j, generators, config=None, use_commutator=False):
    """
    Compute the inter-agent gauge transport operator field Ω_{ij}(x).

    Parameters:
        phi_i: np.ndarray shape (..., d) — φ_i field over spatial domain
        phi_j: np.ndarray shape (..., d) — φ_j field over spatial domain
        generators: np.ndarray shape (d, K, K) — Lie algebra generators
        config: optional config object to override use_commutator
        use_commutator: bool —
            if False, do non-abelian exp(φ_i) @ exp(-φ_j);
            if True,  do abelian exp(φ_i - φ_j)

    Returns:
        omega_ij: np.ndarray shape (..., K, K) — inter-agent transport operator
    """
    # allow config to override the flag
    if config is not None:
        use_commutator = getattr(config, "use_commutator", use_commutator)

    # difference field (..., d)
    delta = phi_i - phi_j

    if not use_commutator:
        # non-abelian: exp(φ_i) @ exp(-φ_j)
        g_i     = exp_lie_algebra_irrep(phi_i, generators, group_name=getattr(config, "group_name", None))
        g_j_inv = exp_lie_algebra_irrep(-phi_j, generators, group_name=getattr(config, "group_name", None))
        return np.matmul(g_i, g_j_inv)

    # abelian shortcut: exp(φ_i - φ_j)
    return exp_lie_algebra_irrep(delta, generators, group_name=getattr(config, "group_name", None))

def compute_intra_omega(agent, coord_from, coord_to, generators=None):
    """
    Compute intra-agent transport operator Ω(p₁ ← p₀) = exp(φ(p₁)) @ exp(−φ(p₀)).

    Parameters
    ----------
    agent : Agent
        The agent whose φ field defines the frame.
    coord_from : tuple
        Starting coordinate (p₀).
    coord_to : tuple
        Destination coordinate (p₁).
    generators : np.ndarray, optional
        Lie algebra generators. Defaults to agent.generators if None.

    Returns
    -------
    Ω : np.ndarray
        (K, K) matrix representing the intra-agent transport from p₀ to p₁.
    """
    if generators is None:
        generators = agent.generators  # Assumes agent carries its group

    phi_from = agent.phi[coord_from]
    phi_to   = agent.phi[coord_to]

    exp_phi_from = exp_lie_algebra_irrep(phi_from[None], generators)[0]
    exp_phi_to   = exp_lie_algebra_irrep(phi_to[None],   generators)[0]

    return exp_phi_to @ np.linalg.inv(exp_phi_from)

import numpy as np  # if not already imported

def compute_inter_omega(agent_i, agent_j, generators):
    """
    Compute full-grid Ω_ij = exp(φ_i) · exp(−φ_j)
    """
    from generalized_omega import exp_lie_algebra_irrep
    from numerical_utils import batch_matrix_inverse  # includes safe fallback

    φi_flat = agent_i.phi.reshape(-1, agent_i.phi.shape[-1])
    φj_flat = agent_j.phi.reshape(-1, agent_j.phi.shape[-1])

    Ωi_flat = exp_lie_algebra_irrep(φi_flat, generators)     # (N, K, K)
    Ωj_flat = exp_lie_algebra_irrep(φj_flat, generators)     # (N, K, K)
    Ωj_inv = batch_matrix_inverse(Ωj_flat)                   # Safe inverse

    Ωij_flat = np.matmul(Ωi_flat, Ωj_inv)                    # (N, K, K)
    Ωij = Ωij_flat.reshape(agent_i.phi.shape[:-1] + (Ωij_flat.shape[-2], Ωij_flat.shape[-1]))
    return Ωij



def bch(A, B, max_norm=10.0):
    """
    4th-order Baker–Campbell–Hausdorff (BCH) expansion with stability guards.

    Computes log(exp(A) @ exp(B)) ≈ A + B + ...
    """
    # Clip if too large
    for M in (A, B):
        norm = np.linalg.norm(M, ord=np.inf)
        if norm > max_norm:
            M *= max_norm / norm

    # Commutators
    AB = A @ B - B @ A
    AAB = A @ AB - AB @ A
    BAB = B @ AB - AB @ B
    BAAB = B @ AAB - AAB @ B

    # Assemble 4th-order BCH
    out = A + B
    out += 0.5 * AB
    out += (1.0 / 12.0) * AAB
    out -= (1.0 / 12.0) * BAB
    out -= (1.0 / 24.0) * BAAB

    return np.nan_to_num(out, nan=0.0, posinf=max_norm, neginf=-max_norm)

from scipy.linalg import logm, expm

def bch_exact(A, B, max_norm=10.0):
    """
    Exact BCH using: log(exp(A) @ exp(B)).

    More accurate but ~10× slower.
    """
    # Optional: clip
    for M in (A, B):
        norm = np.linalg.norm(M, ord=np.inf)
        if norm > max_norm:
            M *= max_norm / norm

    return logm(expm(A) @ expm(B))

import numpy as np
from scipy.ndimage import gaussian_filter

def compute_curvature_form(phi_x, phi_y, generators, dx=1.0, smoothing_sigma=1.0):
    """
    Computes F = dφ + 1/2 [φ ∧ φ] in discrete 2D form.

    Args:
        phi_x, phi_y: (H, W, d) components of Lie-algebra-valued 1-form φ = φ_x dx + φ_y dy
        generators:   (d, K, K) Lie algebra basis (trace-orthonormal)
        dx:           Lattice spacing
        smoothing_sigma: Optional Gaussian smoothing for stability

    Returns:
        F_xy_mat: (H, W, K, K) — curvature 2-form as Lie-algebra-valued matrix field
    """
    H, W, d = phi_x.shape
    K = generators.shape[1]

    # Optional smoothing
    phi_x_smooth = np.stack([gaussian_filter(phi_x[..., a], smoothing_sigma, mode="wrap") for a in range(d)], axis=-1)
    phi_y_smooth = np.stack([gaussian_filter(phi_y[..., a], smoothing_sigma, mode="wrap") for a in range(d)], axis=-1)

    # Compute dφ: antisymmetrized derivatives
    dphi_x = (np.roll(phi_y_smooth, -1, axis=0) - np.roll(phi_y_smooth, 1, axis=0)) / (2 * dx)
    dphi_y = (np.roll(phi_x_smooth, -1, axis=1) - np.roll(phi_x_smooth, 1, axis=1)) / (2 * dx)

    dphi_term = dphi_x - dphi_y  # Approximates ∂_x φ_y - ∂_y φ_x

    # Reconstruct φ_x, φ_y as matrices: (H, W, K, K)
    Ax = np.einsum("ijk,klm->ijlm", phi_x_smooth, generators)
    Ay = np.einsum("ijk,klm->ijlm", phi_y_smooth, generators)

    # Compute [A_x, A_y]
    commutator_term = np.einsum("...ij,...jk->...ik", Ax, Ay) - np.einsum("...ij,...jk->...ik", Ay, Ax)

    # Total curvature 2-form
    F_xy_mat = np.einsum("ijk,klm->ijlm", dphi_term, generators) + 0.5 * commutator_term

    return F_xy_mat  # shape (H, W, K, K)

def lie_bracket(A, B):
    """[A, B] = AB − BA"""
    return A @ B - B @ A

def dexpinv_operator(phi, delta, generators, order=2, use_exact=False):
    """
    Applies inverse of exp pushforward: dexpinv(phi, delta) ∈ 𝔤

    Args:
        phi: (..., d) Lie-algebra coords
        delta: (..., d) Lie-algebra variation (∂L/∂Ω projected back)
        generators: (d, K, K)
        order: int (1 or 2 for now)
        use_exact: if True, uses log(exp(φ) @ exp(Δ)) - φ

    Returns:
        corrected_delta: (..., d)
    """
    H, W, d = phi.shape
    corrected = np.zeros_like(delta)

    # Precompute φ matrix
    phi_mat = np.einsum("...a,akl->...kl", phi, generators)
    delta_mat = np.einsum("...a,akl->...kl", delta, generators)

    if use_exact:
        composed = np.zeros_like(phi_mat)
        for i in range(H):
            for j in range(W):
                A = phi_mat[i, j]
                B = delta_mat[i, j]
                C = bch_exact(A, B)
                composed[i, j] = C - A
    else:
        composed = np.zeros_like(phi_mat)
        for i in range(H):
            for j in range(W):
                A = phi_mat[i, j]
                B = delta_mat[i, j]
                AB = lie_bracket(A, B)
                if order == 1:
                    C = B - 0.5 * AB
                elif order >= 2:
                    AAB = lie_bracket(A, AB)
                    C = B - 0.5 * AB + (1.0 / 12.0) * AAB
                composed[i, j] = C

    # Project back to Lie-algebra coords
    for a in range(d):
        G = generators[a]
        corrected[..., a] = 2.0 * np.einsum("...ij,ij->...", composed, G)

    return corrected

def dexpinv_operator_covariance(phi, delta_sigma, generators, order=2, use_exact=False, transpose=False):
    """
    Applies dexpinv operator to ∂L/∂Σ through transported covariance Ω Σ Ωᵀ.
    Projects gradient back into Lie-algebra coordinates via generator basis.

    Args:
        phi:          (H, W, d)  current φ field
        delta_sigma:  (H, W, K, K) ∂KL/∂Σ_transport
        generators:   (d, K, K)
        order:        expansion order (1, 2)
        use_exact:    whether to use exact logm-based BCH
        transpose:    if True, transpose the final Lie gradient (right-action)

    Returns:
        corrected_grad: (H, W, d)
    """
    H, W, d = phi.shape
    K = generators.shape[1]
    corrected = np.zeros((H, W, d), dtype=phi.dtype)

    # Construct φ matrix at each (i, j)
    phi_mat = np.einsum("...a,akl->...kl", phi, generators)

    for i in range(H):
        for j in range(W):
            A = phi_mat[i, j]
            dΣ = delta_sigma[i, j]

            # Compute commutators: dexpinv(dΣ) = dΣ - 0.5[φ, dΣ] + 1/12[φ, [φ, dΣ]]
            if use_exact:
                B = bch_exact(A, dΣ)
                C = B - A
            else:
                comm1 = A @ dΣ - dΣ @ A
                if order == 1:
                    C = dΣ - 0.5 * comm1
                elif order >= 2:
                    comm2 = A @ comm1 - comm1 @ A
                    C = dΣ - 0.5 * comm1 + (1.0 / 12.0) * comm2

            # Project result back to Lie algebra using trace
            for a in range(d):
                G = generators[a]
                corrected[i, j, a] += 2.0 * np.trace(C @ G)

    if transpose:
        corrected = np.swapaxes(corrected, -1, -1)  # dummy-op, shape is (H, W, d)
        # In practice, this might be skipped unless correction is frame-sensitive

    return corrected



#not used?
def log_lie_group_element(Omega, generators, group_name="sl2r"):
    """
    Project logm(Omega) back to Lie algebra coordinates φ^a using generators G^a.
    """
    from scipy.linalg import logm

    try:
        log_Omega = logm(Omega)
    except Exception as e:
        print(f"[WARN] logm failed: {e}")
        return np.zeros((generators.shape[0],))

    if group_name in {"so3", "su2"}:
        log_Omega = 0.5 * (log_Omega - log_Omega.T.conj())

    d = generators.shape[0]
    phi_vec = np.zeros(d)

    for a in range(d):
        G = generators[a]
        phi_vec[a] = np.trace(G.T @ log_Omega).real

    return phi_vec
