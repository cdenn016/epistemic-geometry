
"""
Gradient terms for belief and model fibers (μ, Σ).
Handles KL(q‖p), KL(p‖q), alignment, and regularizers.
"""

import numpy as np
import config

from natural_gradient_utils import apply_natural_gradient_batch, sanitize_sigma
from mask_utils import clip_and_mask_gradient
from numerical_utils import safe_inv


def zero_mu_sigma_like(agent_i, field="model"):
    mu_attr = f"mu_{'p' if field == 'model' else 'q'}_field"
    sigma_attr = f"sigma_{'p' if field == 'model' else 'q'}_field"
    return np.zeros_like(getattr(agent_i, mu_attr)), np.zeros_like(getattr(agent_i, sigma_attr))

def compute_mu_sigma_diff(mu_a, sigma_a, mu_b, sigma_b, direction="a_minus_b"):
    if direction == "a_minus_b":
        d_mu = mu_a - mu_b
        d_sigma = 0.5 * (sigma_a - sigma_b)
    elif direction == "b_minus_a":
        d_mu = mu_b - mu_a
        d_sigma = 0.5 * (sigma_b - sigma_a)
    else:
        raise ValueError(f"Unknown direction: {direction}")
    return d_mu, d_sigma

def apply_mask_to_mu_sigma(mu, sigma, mask):
    mu = np.where(mask[..., None], mu, 0)
    sigma = np.where(mask[..., None, None], sigma, 0)
    return mu, sigma

# --- Individual Gradient Terms ---

def grad_self_field(agent_i, alpha, field_type="model", mask=None):
    """
    Gradient of KL(q || p) or KL(p || q), depending on field_type.
    Computes natural gradient ∇_μ, ∇_Σ for the chosen self field.

    Args:
        agent_i   : Agent object with belief/model fields
        alpha     : Scalar weight on self-consistency
        field_type: "model" for KL(p || q), "belief" for KL(q || p)
        mask      : Optional spatial mask

    Returns:
        (Δμ, ΔΣ) : Fisher-natural gradient of the self-alignment term
    """
    if alpha <= 0:
        return zero_mu_sigma_like(agent_i)

    if field_type == "model":
        μ_self, Σ_self = agent_i.mu_p_field, agent_i.sigma_p_field
        μ_other, Σ_other = agent_i.mu_q_field, agent_i.sigma_q_field
    elif field_type == "belief":
        μ_self, Σ_self = agent_i.mu_q_field, agent_i.sigma_q_field
        μ_other, Σ_other = agent_i.mu_p_field, agent_i.sigma_p_field
    else:
        raise ValueError(f"[grad_self_field] Unknown field_type: {field_type}")

    # Optional SPD sanitization of Σ_other (used in KL)
    if config.sanitize_sigma_before_kl:
        Σ_other = sanitize_sigma(Σ_other, eps=config.eps)

    # Direction: ∇ KL(self || other)
    dμ, dΣ = compute_mu_sigma_diff(μ_self, Σ_self, μ_other, Σ_other, direction="a_minus_b")

    # Remove NaNs/infs if any
    dμ = np.nan_to_num(dμ)
    dΣ = np.nan_to_num(dΣ)

    Δμ_nat, ΔΣ_nat = apply_natural_gradient_batch(μ_self, Σ_self, dμ, dΣ)

    # Optional masking
    if mask is not None:
        Δμ_nat, ΔΣ_nat = apply_mask_to_mu_sigma(Δμ_nat, ΔΣ_nat, mask)

    return alpha * Δμ_nat, alpha * ΔΣ_nat


def grad_feedback_field(agent_i, feedback_weight, field_type="model", mask=None):
    """
    Raw Euclidean gradient of KL(other || self), i.e. ∇_self KL(p || q).
    Preconditioning (natural gradient) should be applied centrally.
    """
    if feedback_weight <= 0:
        return zero_mu_sigma_like(agent_i, field=field_type)

    if field_type == "model":
        μ_self, Σ_self = agent_i.mu_p_field, agent_i.sigma_p_field
        μ_other, Σ_other = agent_i.mu_q_field, agent_i.sigma_q_field
    elif field_type == "belief":
        μ_self, Σ_self = agent_i.mu_q_field, agent_i.sigma_q_field
        μ_other, Σ_other = agent_i.mu_p_field, agent_i.sigma_p_field
    else:
        raise ValueError(f"[grad_feedback_field] Unknown field_type: {field_type}")

    Σ_self  = sanitize_sigma(Σ_self, eps=config.eps)
    Σ_other = sanitize_sigma(Σ_other, eps=config.eps)

    dμ, dΣ = compute_mu_sigma_diff(μ_self, Σ_self, μ_other, Σ_other, direction="b_minus_a")

    if mask is not None:
        dμ, dΣ = apply_mask_to_mu_sigma(dμ, dΣ, mask)

    return feedback_weight * dμ, feedback_weight * dΣ


def grad_variance_penalty_field(agent_i, lambda_, field_type="model", mask=None):
    """
    Gradient of Tr(Σ⁻¹) penalty:
        ∇_Σ = -λ Σ⁻¹

    Returns:
        (Δμ, ΔΣ): where Δμ = 0, ΔΣ = -λ Σ⁻¹ (masked if needed)
    """
    if lambda_ <= 0:
        return zero_mu_sigma_like(agent_i, field=field_type)

    sigma = agent_i.sigma_p_field if field_type == "model" else agent_i.sigma_q_field
    mu_shape = agent_i.mu_p_field.shape if field_type == "model" else agent_i.mu_q_field.shape

    H, W, K, _ = sigma.shape
    d_sigma = np.zeros_like(sigma)
    fallback = np.eye(K)

    for i in range(H):
        for j in range(W):
            try:
                inv_ij = np.linalg.inv(sigma[i, j])
            except np.linalg.LinAlgError:
                if getattr(config, "debug", False):
                    print(f"[WARN] grad_variance_penalty_field: Σ⁻¹ fallback at ({i},{j})")
                inv_ij = np.linalg.pinv(sigma[i, j])  # fallback to pseudo-inverse

            d_sigma[i, j] = -lambda_ * inv_ij

    d_sigma = np.nan_to_num(d_sigma)

    if mask is not None:
        _, d_sigma = apply_mask_to_mu_sigma(None, d_sigma, mask)

    d_mu = np.zeros(mu_shape, dtype=d_sigma.dtype)
    return d_mu, d_sigma

def alignment_gradient_field(agent_i, agents, params, field_type="model", mask=None):
    """
    Computes Fisher-natural gradient ∇μ, ∇Σ of alignment KL divergence:
        KL(q_i || Ω_ij q_j) or KL(p_i || Ω̃_ij p_j)

    Args:
        agent_i   : focal agent
        agents    : list of agents
        params    : dict of parameters (must contain 'generators')
        field_type: "model" or "belief"
        mask      : optional spatial mask to restrict update region

    Returns:
        (Δμ_nat, ΔΣ_nat): natural gradient updates (H, W, K), (H, W, K, K)
    """
    from alignment_pullback_gradients import compute_alignment_kl_gradient

    if field_type == "model":
        weight = params.get("model_align_weight", config.model_align_weight)
    elif field_type == "belief":
        weight = params.get("beta", config.beta)
    else:
        raise ValueError(f"[alignment_gradient_field] Unknown field_type: {field_type}")

    if weight <= 0:
        return zero_mu_sigma_like(agent_i, field=field_type)

    generators = params["generators"]
    Δμ_nat, ΔΣ_nat = compute_alignment_kl_gradient(agent_i, agents, generators, params, field_type=field_type)

    if mask is not None:
        Δμ_nat, ΔΣ_nat = apply_mask_to_mu_sigma(Δμ_nat, ΔΣ_nat, mask)

    return weight * Δμ_nat, weight * ΔΣ_nat



def combine_field_gradients(agent_i, agents, params, field_type="model"):
    if field_type == "model" and getattr(config, "identical_models", False):
        return zero_mu_sigma_like(agent_i)

    # Load all parameters
    α  = params.get("alpha", config.alpha)
    β  = params.get("model_align_weight", config.model_align_weight) if field_type == "model" else params.get("beta", config.beta)
    fb = params.get("model_feedback_weight", config.model_feedback_weight) if field_type == "model" else params.get("belief_feedback_weight", getattr(config, "belief_feedback_weight", 0.0))
    λ  = params.get("variance_penalty_model_weight", getattr(config, "variance_penalty_model_weight", 0.0)) if field_type == "model" else params.get("variance_penalty_belief_weight", getattr(config, "variance_penalty_belief_weight", 0.0))
    eps = params.get("support_cutoff_eps", config.support_cutoff_eps)

    # Mask
    mask = agent_i.mask > eps
    if not np.any(mask):
        return zero_mu_sigma_like(agent_i)

    # Select fields
    mu_field    = agent_i.mu_p_field if field_type == "model" else agent_i.mu_q_field
    sigma_field = agent_i.sigma_p_field if field_type == "model" else agent_i.sigma_q_field

    # --- Natural-gradient components ---
    grad_mu_nat    = np.zeros_like(mu_field)
    grad_sigma_nat = np.zeros_like(sigma_field)

    if α > 0:
        dμ, dΣ = grad_self_field(agent_i, α, field_type, mask)
        grad_mu_nat += dμ
        grad_sigma_nat += dΣ
    if fb > 0:
        dμ, dΣ = grad_feedback_field(agent_i, fb, field_type, mask)
        grad_mu_nat += dμ
        grad_sigma_nat += dΣ
    if β > 0:
        dμ, dΣ = alignment_gradient_field(agent_i, agents, params, field_type=field_type, mask=mask)

        grad_mu_nat += dμ
        grad_sigma_nat += dΣ

    # --- Apply Fisher preconditioner only to KL terms ---
    delta_mu, delta_sigma = apply_natural_gradient_batch(
        mu_field, sigma_field, grad_mu_nat, grad_sigma_nat
    )

    # --- Add regularization (coordinate) terms AFTER natural gradient ---
    if λ > 0:
        dμ_reg, dΣ_reg = grad_variance_penalty_field(agent_i, λ, field_type, mask)
        delta_mu    += dμ_reg
        delta_sigma += dΣ_reg

    # Final nan sanitization
    delta_mu    = np.nan_to_num(delta_mu, nan=0.0, posinf=1e5, neginf=-1e5)
    delta_sigma = np.nan_to_num(delta_sigma, nan=0.0, posinf=1e5, neginf=-1e5)

    return delta_mu, delta_sigma
