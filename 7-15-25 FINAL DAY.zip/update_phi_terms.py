# -*- coding: utf-8 -*-
"""
Created on Mon Jul 14 13:11:51 2025

@author: chris and christine
"""

# update_phi_terms.py

"""
Variational φ and φ̃ gradient updates.
Handles alignment, curvature, mass, coupling, and Fisher terms.
"""

import numpy as np
import config

from get_generators import get_generators
from natural_gradient_utils import apply_lie_natural_gradient, compute_inverse_fisher_field
from mask_utils import clip_and_mask_gradient
from generalized_math_utils import unpack_phi_update_params
from generalized_omega import compute_curvature_gradient_analytical
from numerical_utils import safe_inv
from update_transport_gradients import compute_phi_gradient_via_transport, accumulate_phi_gradient
from natural_gradient_utils import compute_fisher_geometry_gradient

# NOTE: alignment terms are delegated to update_transport_terms.py

def compute_local_phi_metric(agent, generators=None, field="phi"):
    """
    Compute spatial average of pointwise Fisher metric over Lie algebra:
        G^{ab} = mean_x [ Tr[Σ⁻¹ G^a Σ⁻¹ G^b] ] on support

    Returns:
        G_inv: (d, d) inverse Fisher metric over the Lie algebra
        
    Computes global (averaged) Fisher metric over the Lie algebra directions.
    ⚠️ Use only for global preconditioning — not for per-point natural gradients.
        
    """
    eps = getattr(config, "eps", 1e-8)
    support_eps = getattr(config, "support_cutoff_eps", 1e-4)
    K = agent.mu_q_field.shape[-1]
    d = config.lie_dim
    mask = agent.mask > support_eps

    sigma_field = agent.sigma_q_field if field == "phi" else agent.sigma_p_field
    if not np.any(mask):
        return np.eye(d)

    if generators is None:
        generators = get_generators(config.group_name, K)

    # Flatten valid points
    sigma_subset = sigma_field[mask]  # (N, K, K)
    N = sigma_subset.shape[0]

    # Precompute inverses safely
    sigma_inv_subset = np.array([
        safe_inv(S, eps=eps) for S in sigma_subset
    ])  # (N, K, K)

    # Accumulate Fisher contributions
    G_phi = np.zeros((d, d))
    for a in range(d):
        G_a = generators[a]
        for b in range(d):
            G_b = generators[b]
            traces = np.einsum("nij,jk,nkl,lm->n", sigma_inv_subset, G_a, sigma_inv_subset, G_b)
            G_phi[a, b] = np.mean(traces)

    G_phi = 0.5 * (G_phi + G_phi.T)  # ensure symmetry

    # Safe inverse
    try:
        G_inv = np.linalg.inv(G_phi + eps * np.eye(d))
    except np.linalg.LinAlgError:
        if config.debug:
            print("[WARN] compute_local_phi_metric: G^ab not invertible, using identity")
        G_inv = np.eye(d)

    return G_inv


def compute_phi_alignment_grad(agent_i, agents, params, field="phi"):
    """
    Computes analytic gradient ∇_φ or ∇_{φ̃} KL(q_i || Ω q_j) or KL(p_i || Ω̃ p_j),
    using the unified transport-based gradient routine.
    """
    weight = params.get("beta", config.beta) if field == "phi" else params.get("model_align_weight", config.model_align_weight)
    if weight <= 0:
        return np.zeros_like(agent_i.phi if field == "phi" else agent_i.phi_model)

    generators = params.get("generators", get_generators(config.group_name, config.K))
    return compute_phi_gradient_via_transport(agent_i, agents, generators, field=field)



def compute_phi_model_alignment_gradient(agent_i, agents, params, field="model"):
    """
    Computes the analytic variational gradient ∇_{φ̃} KL(fiber_i ‖ Ω̃_{ij} fiber_j),
    using the unified backpropagation routine through Ω̃ = exp(φ̃).

    Args:
        agent_i: focal agent
        agents : list of all agents
        params : runtime and config dict
        field  : "model" (or optionally "belief")

    Returns:
        grad: (H, W, d) Lie-algebra-valued update
    """
    β = params.get("model_align_weight", config.model_align_weight)
    if β <= 0:
        return np.zeros_like(agent_i.phi_model)

    generators = params.get("generators", get_generators(config.group_name, config.K))
    return compute_phi_gradient_via_transport(agent_i, agents, generators, field="phi_model")



def compute_phi_update(agent_i, agents, params, field="phi"):
    """
    Unified update for φ (belief alignment) and φ̃ (model alignment).
    Applies Lie-natural gradient to alignment + optional regularizers.
    """
    if field == "phi_model" and getattr(config, "identical_models", False):
        return np.zeros_like(agent_i.phi_model)

    # --- Unpack core parameters ---
    unpacked  = unpack_phi_update_params(params, field=field)
    β         = params.get("beta", config.beta) if field == "phi" else params.get("model_align_weight", config.model_align_weight)
    κ         = unpacked["κ"]
    gw        = unpacked["gw"]
    curv_w    = unpacked["curv_weight"]
    clip_th   = unpacked["grad_clip_threshold"]
    eps       = unpacked["overlap_eps"]
    debug     = unpacked["debug"]

    phi       = agent_i.phi if field == "phi" else agent_i.phi_model
    phi_tilde = agent_i.phi_model if field == "phi" else agent_i.phi
    soft_mask = agent_i.mask[..., None]
    generators = params.get("generators", get_generators(config.group_name, config.K))

    if not np.any(soft_mask > eps):
        return np.zeros_like(phi)

    grad = np.zeros_like(phi)

    # --- Fisher metric (spatial or global) ---
    if field == "phi" and getattr(config, "use_spatial_fisher_phi", False):
        G_inv = compute_inverse_fisher_field(agent_i, generators, field=field)
    else:
        G_inv = params.get("G_inv_phi", None) if field == "phi" else params.get("G_inv_phi_model", None)
        if G_inv is None and getattr(config, "adaptive_phi_metric", True):
            G_inv = compute_inverse_fisher_field(agent_i, generators, field=field)

    # --- 1. Alignment gradient (Lie-natural, variationally consistent) ---
    if β > 0:
        if config.variational_alignment_exact:
            grad_align = np.zeros_like(phi)
            for neighbor in agent_i.neighbors:
                agent_j = agents[neighbor["id"]]
                accumulate_phi_gradient(agent_i, agent_j, generators, params, field=field)
            grad_align = agent_i.grad_phi.copy()
            agent_i.grad_phi[:] = 0.0  # Clear after use
        else:
            align_fn = compute_phi_alignment_grad if field == "phi" else compute_phi_model_alignment_gradient
            grad_align = align_fn(agent_i, agents, params, field=field)

        grad += apply_lie_natural_gradient(phi, grad_align, G_inv=G_inv)


    # --- 2. Curvature gradient ---
    if curv_w > 0:
        grad_curv = compute_curvature_gradient_analytical(phi, generators)
        grad += curv_w * grad_curv

    # --- 3. Mass term: 2γ φ ---
    if gw > 0:
        grad += 2 * gw * phi

    # --- 4. φ–φ̃ coupling ---
    if κ > 0:
        grad += 2 * κ * (phi - phi_tilde)

    # --- 5. Optional Fisher geometry term ---
    fisher_key = "fisher_geometry_weight" if field == "phi" else "fisher_model_geometry_weight"
    fisher_weight = params.get(fisher_key, getattr(config, fisher_key, 0.0))
    if fisher_weight > 0:
        fisher_fn = compute_fisher_geometry_gradient if field == "phi" else compute_fisher_geometry_gradient
        fisher_grad = fisher_fn(agent_i, agents, params)
        grad += fisher_weight * fisher_grad

    # --- Final clip + mask ---
    return clip_and_mask_gradient(grad, soft_mask, clip_th, eps)

