# -*- coding: utf-8 -*-
"""
Created on Sat Jul 19 08:14:25 2025

@author: chris and christine
"""
import numpy as np
import config
from joblib import Parallel, delayed

from natural_gradient_utils import (
    apply_natural_gradient_batch,
    apply_lie_natural_gradient,
    compute_inverse_fisher_field
)

from numerical_utils import sanitize_sigma
from mask_utils import clip_and_mask_gradient, clip_and_mask_morphism
from numerical_utils import safe_inv

from get_generators import get_generators
from generalized_math_utils import unpack_phi_update_params
from generalized_omega import compute_curvature_gradient_analytical, exp_lie_algebra_irrep

from generalized_omega import dexpinv_operator, dexpinv_operator_covariance
from natural_gradient_utils import compute_fisher_geometry_gradient, kl_gradient_mu_sigma
from generalized_math_utils import ( 
        zero_mu_sigma_like, apply_mask_to_mu_sigma
        )
from natural_gradient_utils import transport_gaussian

from bundle_morphism_utils import safe_batch_apply_morphism
from generalized_math_utils import ( 
        zero_mu_sigma_like, compute_mu_sigma_diff,
        apply_mask_to_mu_sigma
        )



def grad_self_field(agent_i, alpha, field_type="model", mask=None,
                             phi_morphism=None, phi_tilde_morphism=None):
    """
    Compute raw Euclidean gradient of morphism-aware self-alignment:
  - field_type="belief" → ∂KL(q || Φ̃·p)
  - field_type="model" → ∂KL(p || Φ·q)

    The morphism acts as:
  - Φ   : q → p  (for feedback, model side)
  - Φ̃  : p → q  (for self-alignment, belief side)

    Notes:
    - For field="belief", p is pulled into q-space using Φ̃.
    - For field="model", q is pulled into p-space using Φ.
"""

    if alpha <= 0:
        return zero_mu_sigma_like(agent_i)

    H, W = agent_i.grid_shape

    if field_type == "belief":
        mu_q, sigma_q = agent_i.mu_q_field, agent_i.sigma_q_field  # q-space
        mu_p, sigma_p = agent_i.mu_p_field, agent_i.sigma_p_field  # p-space
        K_q = mu_q.shape[-1]
        K_p = mu_p.shape[-1]

        if phi_morphism is not None:
            Phi = phi_morphism  # should be (..., K_q, K_p)
        else:
            eye = np.eye(K_q, K_p, dtype=mu_q.dtype)  # p → q maps from K_p to K_q
            Phi = np.broadcast_to(eye, (H, W, K_q, K_p))

        mu_p_trans, sigma_p_trans = safe_batch_apply_morphism(mu_p, sigma_p, Phi, eps=config.eps)
        dμ, dΣ = compute_mu_sigma_diff(mu_q, sigma_q, mu_p_trans, sigma_p_trans, direction="a_minus_b")

    elif field_type == "model":
        mu_q, sigma_q = agent_i.mu_q_field, agent_i.sigma_q_field
        mu_p, sigma_p = agent_i.mu_p_field, agent_i.sigma_p_field
        K_q = mu_q.shape[-1]
        K_p = mu_p.shape[-1]

        if phi_tilde_morphism is not None:
            Phi_tilde = phi_tilde_morphism  # should be (..., K_p, K_q)
        else:
            eye = np.eye(K_p, K_q, dtype=mu_q.dtype)  # q → p maps from K_q to K_p
            Phi_tilde = np.broadcast_to(eye, (H, W, K_p, K_q))

        mu_q_trans, sigma_q_trans = safe_batch_apply_morphism(mu_q, sigma_q, Phi_tilde, eps=config.eps)
        dμ, dΣ = compute_mu_sigma_diff(mu_p, sigma_p, mu_q_trans, sigma_q_trans, direction="a_minus_b")

    else:
        raise ValueError(f"[grad_self_field_morphism] Unknown field_type: {field_type}")

    dμ = np.nan_to_num(dμ)
    dΣ = np.nan_to_num(dΣ)

    if mask is not None:
        dμ, dΣ = apply_mask_to_mu_sigma(dμ, dΣ, mask)

    return alpha * dμ, alpha * dΣ


def grad_morphism_self_energy(agent_i, alpha, mask=None):
    """
    Compute gradient ∂/∂Φ̃ of KL[q || Φ̃·p], where Φ̃ : P → Q is a bundle morphism.
    This is the canonical gauge-covariant self-energy gradient on the morphism Φ̃.

    Args:
        agent_i        : Agent object
        alpha          : weight of the self-alignment term
        mask           : optional (H, W) spatial mask

    Returns:
        grad    : gradient of shape (H, W, K_q, K_p)
    """
    # Extract the fields
    mu_q    = agent_i.mu_q_field             # (H, W, K_q)
    sigma_q = agent_i.sigma_q_field          # (H, W, K_q, K_q)
    mu_p    = agent_i.mu_p_field             # (H, W, K_p)
    sigma_p = agent_i.sigma_p_field          # (H, W, K_p, K_p)
    Phi_tilde = agent_i.bundle_morphism_p_to_q  # Φ̃ : P → Q, shape (H, W, K_q, K_p)

    # Project p into q-fiber using Φ̃ : P → Q
    mu_p_proj, sigma_p_proj = safe_batch_apply_morphism(mu_p, sigma_p, Phi_tilde, eps=config.eps)

    # Inverse of projected sigma_q
    sigma_q_inv = safe_inv(sigma_q, eps=config.eps)

    # Compute the gradient of the covariance term
    term_sigma = 2 * np.einsum("...ij,...jl,...kl->...ik", sigma_q_inv, Phi_tilde, sigma_p)

    # Compute the gradient of the mean term
    delta_mu = mu_p_proj - mu_q
    term_mu  = 2 * np.einsum("...ij,...j,...k->...ik", sigma_q_inv, delta_mu, mu_p)

    # Combine both terms to get the total gradient
    grad_total = term_mu + term_sigma

    # Apply the mask if provided
    if mask is not None:
        grad_total *= mask[..., None, None]

    # Return the scaled gradient
    return alpha * grad_total



def compute_alignment_kl_gradient_model(agent_i, agents, generators, params):
    """
    Compute the covariant natural gradient of KL(p_i || Ω̃_ij p_j) for models.
    """
    beta = params.get("model_align_weight", config.model_align_weight)
    if beta <= 0:
        return np.zeros_like(agent_i.mu_p_field), np.zeros_like(agent_i.sigma_p_field)

    mu_i = agent_i.mu_p_field
    sigma_i = agent_i.sigma_p_field
    Omega_i = agent_i._exp_phi_model
    Omega_i = Omega_i.reshape(*mu_i.shape[:-1], mu_i.shape[-1], mu_i.shape[-1])

    delta_mu = np.zeros_like(mu_i)
    delta_sigma = np.zeros_like(sigma_i)

    for nb in agent_i.neighbors:
        agent_j = agents[nb["id"]]

        mu_j = agent_j.mu_p_field
        sigma_j = agent_j.sigma_p_field
        Omega_j_inv = agent_j._exp_neg_phi_model
        Omega_j_inv = Omega_j_inv.reshape(*mu_j.shape[:-1], mu_j.shape[-1], mu_j.shape[-1])

        mask_overlap = (agent_i.mask * agent_j.mask) > config.support_cutoff_eps
        if not np.any(mask_overlap):
            continue

        Omega_ij = np.einsum("...ik,...kj->...ij", Omega_i, Omega_j_inv)

        # Transport the Gaussian
        mu_j_t, sigma_j_t = transport_gaussian(mu_j, sigma_j, Omega_ij)

        sigma_j_t = sanitize_sigma(sigma_j_t, eps=config.eps)

        delta_mu_step, delta_sigma_step = kl_gradient_mu_sigma(
            mu_i, sigma_i, mu_j_t, sigma_j_t, mask=mask_overlap
        )

        delta_mu += delta_mu_step
        delta_sigma += delta_sigma_step

    return delta_mu, beta * delta_sigma

def alignment_gradient_field_model(agent_i, agents, params, mask=None):
    """
    Raw Euclidean gradient of alignment KL divergence for models:
        KL(p_i || Ω̃_ij p_j)

    Args:
        agent_i    : focal agent
        agents     : list of agents
        params     : dict of parameters
        mask       : optional spatial mask to restrict update region

    Returns:
        dμ, dΣ : raw Euclidean gradients (H, W, K), (H, W, K, K)
    """
    weight = params.get("model_align_weight", config.model_align_weight)

    if weight <= 0:
        return zero_mu_sigma_like(agent_i, field="model")

    K_fiber = agent_i.mu_p_field.shape[-1]

    # Load or generate the appropriate representation generators
    generators = params.get("generators", get_generators(config.group_name, K_fiber))

    # Compute raw KL alignment gradients for models
    dμ, dΣ = compute_alignment_kl_gradient_model(agent_i, agents, generators, params)

    # Ensure numerical stability
    dμ = np.nan_to_num(dμ)
    dΣ = np.nan_to_num(dΣ)

    # Apply optional mask
    if mask is not None:
        dμ, dΣ = apply_mask_to_mu_sigma(dμ, dΣ, mask)

    return weight * dμ, weight * dΣ




def accumulate_phi_gradient_model(agent_i, agent_j, generators, params, field="phi"):
    """
    Compute and accumulate the variational gradient:
        ∂/∂φ_i KL(p_i ‖ Ω̃_ij p_j)
    where Ω̃_ij = exp(φ~_i) · exp(−φ~_j) for model fields.
    """
    # Ensure the correct field type
    assert field == "phi_model", f"Expected field='phi_model', got {field}"

    beta = params.get("model_align_weight", config.model_align_weight)
    if beta <= 0:
        return

    eps = config.support_cutoff_eps
    mask_i = agent_i.mask[..., None] > eps
    mask_j = agent_j.mask[..., None] > eps
    joint_mask = mask_i & mask_j  # Overlapping region between agents

    # Select fibers and fields for model calculations
    mu_i = agent_i.mu_p_field
    mu_j = agent_j.mu_p_field
    sigma_i = agent_i.sigma_p_field
    sigma_j = agent_j.sigma_p_field
    phi_i = agent_i.phi_model
    phi_j = agent_j.phi_model

    # Compute Ω̃_ij = exp(φ_i) @ exp(-φ_j) for model fields
    exp_phi_i = exp_lie_algebra_irrep(phi_i, generators)
    exp_neg_phi_j = exp_lie_algebra_irrep(-phi_j, generators)
    Omega_ij = np.einsum("...ik,...kj->...ij", exp_phi_i, exp_neg_phi_j)
    Omega_T = np.swapaxes(Omega_ij, -1, -2)  # Transpose of Ω̃_ij

    # Transport p_j to i
    mu_trans = np.einsum("...ij,...j->...i", Omega_ij, mu_j)
    sigma_trans = np.einsum("...ik,...kl,...jl->...ij", Omega_ij, sigma_j, Omega_T)
    sigma_trans = sanitize_sigma(sigma_trans, eps=config.eps)
    sigma_inv = safe_inv(sigma_trans, eps=config.eps)

    delta_mu = mu_i - mu_trans
    d_mu = -np.einsum("...ij,...j->...i", sigma_inv, delta_mu)

    delta_sigma = sigma_i - sigma_trans
    d_sigma = -0.5 * np.einsum("...ik,...kl,...lj->...ij", sigma_inv, delta_sigma, sigma_inv)

    # Gradient initialization for φ_i and φ_j
    d = generators.shape[0]  # Number of generators
    grad_phi_i = np.zeros_like(phi_i)
    grad_phi_j = np.zeros_like(phi_j)

    # Compute the variational gradients for each generator
    for a in range(d):
        G = generators[a]

        # ∂Ω̃/∂φ_i = Ω̃ G
        OG = np.einsum("...ij,jk->...ik", Omega_ij, G)
        dphi_i_mu = np.einsum("...ij,...j->...i", OG, mu_j)

        OG_sigma = np.einsum("...ij,...jk->...ik", OG, sigma_j)
        dphi_sigma_1 = np.einsum("...ij,...jk->...ik", OG_sigma, Omega_T)

        sigma_GT = np.einsum("...ij,jk->...ik", sigma_j, G.T)
        O_sigma_GT = np.einsum("...ij,...jk->...ik", Omega_ij, sigma_GT)
        dphi_sigma_2 = np.einsum("...ij,...jk->...ik", O_sigma_GT, Omega_T)

        dphi_i_sigma = dphi_sigma_1 + dphi_sigma_2

        # ∂Ω̃/∂φ_j = -Ω̃ G_right, where G_right = exp(φ_j) @ G @ exp(−φ_j)
        G_batch = np.broadcast_to(G, exp_phi_i.shape)
        G_right = np.einsum("...ij,...jk,...kl->...il", exp_phi_i, G_batch, exp_neg_phi_j)

        dphi_j_mu = -np.einsum("...ij,...j->...i", G_right, mu_j)

        G_right_sigma = np.einsum("...ij,...jk->...ik", G_right, sigma_j)
        dphi_j_sigma_1 = np.einsum("...ij,...jk->...ik", G_right_sigma, Omega_T)

        sigma_GT_j = np.einsum("...ij,jk->...ik", sigma_j, G.T)
        O_sigma_GT_j = np.einsum("...ij,...jk->...ik", Omega_ij, sigma_GT_j)
        dphi_j_sigma_2 = np.einsum("...ij,...jk->...ik", O_sigma_GT_j, Omega_T)

        dphi_j_sigma = dphi_j_sigma_1 + dphi_j_sigma_2

        # Accumulate the gradients
        delta_a_i = (
            np.sum(d_mu * dphi_i_mu, axis=-1) +
            np.einsum("...ij,...ij->...", d_sigma, dphi_i_sigma)
        )
        delta_a_j = (
            np.sum(d_mu * dphi_j_mu, axis=-1) +
            np.einsum("...ij,...ij->...", d_sigma, dphi_j_sigma)
        )

        grad_phi_i[..., a] += delta_a_i
        grad_phi_j[..., a] += delta_a_j

    # Apply natural gradient (μ + Σ terms separately)
    grad_phi_mu_i = dexpinv_operator(phi_i, grad_phi_i, generators)
    grad_phi_mu_j = dexpinv_operator(phi_j, grad_phi_j, generators)

    grad_phi_sigma_i = dexpinv_operator_covariance(phi_i, d_sigma, generators)
    grad_phi_sigma_j = dexpinv_operator_covariance(phi_j, -d_sigma, generators)

    grad_phi_i = grad_phi_mu_i + grad_phi_sigma_i
    grad_phi_j = grad_phi_mu_j + grad_phi_sigma_j

    # Accumulate the gradients into the agent's gradient field
    agent_i.grad_phi_tilde += beta * grad_phi_i * joint_mask
    agent_j.grad_phi_tilde += beta * grad_phi_j * joint_mask


def compute_phi_update_model(agent_i, agents, params, field="phi"):
    """
    Unified update for φ̃ (model alignment).
    Applies Lie-natural gradient to alignment + optional regularizers for models.
    """
    if field == "phi_model" and getattr(config, "identical_models", False):
        return np.zeros_like(agent_i.phi_model)

    # --- Unpack core parameters ---
    unpacked  = unpack_phi_update_params(params, field=field)
    β         = params.get("model_align_weight", config.model_align_weight)
    κ         = unpacked["κ"]
    gw        = unpacked["gw"]
    curv_w    = unpacked["curv_weight"]
    clip_th   = unpacked["grad_clip_threshold"]
    eps       = unpacked["overlap_eps"]
    debug     = unpacked["debug"]

    phi       = agent_i.phi_model  # Model field
    phi_tilde = agent_i.phi  # Belief field
    soft_mask = agent_i.mask[..., None]
    generators_p = params.get("generators_p", get_generators(config.group_name, config.K_p))

    if not np.any(soft_mask > eps):
        return np.zeros_like(phi)

    grad = np.zeros_like(phi)

    # --- 1. Alignment gradient (Lie-natural, variationally consistent) ---
    grad_align = np.zeros_like(phi)
    if β > 0:
        for neighbor in agent_i.neighbors:
            agent_j = agents[neighbor["id"]]
            accumulate_phi_gradient_model(agent_i, agent_j, generators_p, params, field=field)
        grad_align = agent_i.grad_phi_tilde.copy()
        agent_i.grad_phi_tilde[:] = 0.0

        grad += apply_lie_natural_gradient(phi, grad_align, G_inv=compute_inverse_fisher_field(agent_i, generators_p, field=field))

    # --- 2. Curvature gradient ---
    if curv_w > 0:
        grad_curv = compute_curvature_gradient_analytical(phi, generators_p)
        grad += curv_w * grad_curv

    # --- 3. Mass term: 2γ φ ---
    if gw > 0:
        grad += 2 * gw * phi

    # --- 4. φ–φ̃ coupling ---
    if κ > 0:
        grad += 2 * κ * (phi - phi_tilde)

    # --- 5. Optional Fisher geometry term ---
    fisher_key = "fisher_model_geometry_weight"
    fisher_weight = params.get(fisher_key, getattr(config, fisher_key, 0.0))
    if fisher_weight > 0:
        fisher_grad = compute_fisher_geometry_gradient(agent_i, agents, params)
        grad += fisher_weight * fisher_grad

    # --- Final clip + mask ---
    return clip_and_mask_gradient(grad, soft_mask, clip_th, eps)

def grad_variance_penalty_field(agent_i, lambda_, field_type="model", mask=None):
    """
    Gradient of Tr(Σ⁻¹) penalty:
        ∇_Σ = -λ Σ⁻¹

    Returns:
        (Δμ, ΔΣ): where Δμ = 0, ΔΣ = -λ Σ⁻¹ (masked if needed)
    """
    if lambda_ <= 0:
        return zero_mu_sigma_like(agent_i, field=field_type)

    sigma = agent_i.sigma_p_field if field_type == "model" else agent_i.sigma_q_field
    mu_shape = agent_i.mu_p_field.shape if field_type == "model" else agent_i.mu_q_field.shape

    H, W, K, _ = sigma.shape
    d_sigma = np.zeros_like(sigma)
    fallback = np.eye(K)

    for i in range(H):
        for j in range(W):
            try:
                inv_ij = np.linalg.inv(sigma[i, j])
            except np.linalg.LinAlgError:
                if getattr(config, "debug", False):
                    print(f"[WARN] grad_variance_penalty_field: Σ⁻¹ fallback at ({i},{j})")
                inv_ij = np.linalg.pinv(sigma[i, j])  # fallback to pseudo-inverse

            d_sigma[i, j] = -lambda_ * inv_ij

    d_sigma = np.nan_to_num(d_sigma)

    if mask is not None:
        _, d_sigma = apply_mask_to_mu_sigma(None, d_sigma, mask)

    d_mu = np.zeros(mu_shape, dtype=d_sigma.dtype)
    return d_mu, d_sigma

