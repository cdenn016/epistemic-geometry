# -*- coding: utf-8 -*-
"""
Created on Sat Jul 19 08:12:50 2025

@author: chris and christine
"""
import numpy as np
import config
from joblib import Parallel, delayed

from natural_gradient_utils import (
    apply_natural_gradient_batch,
    apply_lie_natural_gradient,
    compute_inverse_fisher_field
)

from numerical_utils import sanitize_sigma
from mask_utils import clip_and_mask_gradient, clip_and_mask_morphism
from numerical_utils import safe_inv

from get_generators import get_generators
from generalized_math_utils import unpack_phi_update_params
from generalized_omega import compute_curvature_gradient_analytical, exp_lie_algebra_irrep

from generalized_omega import dexpinv_operator, dexpinv_operator_covariance
from natural_gradient_utils import compute_fisher_geometry_gradient, kl_gradient_mu_sigma
from generalized_math_utils import ( 
        zero_mu_sigma_like, apply_mask_to_mu_sigma
        )
from natural_gradient_utils import transport_gaussian
from bundle_morphism_utils import safe_batch_apply_morphism
from generalized_math_utils import ( 
        zero_mu_sigma_like, compute_mu_sigma_diff,
        apply_mask_to_mu_sigma
        )
from update_terms_model import grad_self_field, grad_variance_penalty_field




def grad_feedback_field(agent_i, feedback_weight, mask=None, phi_morphism=None):
    """
    Compute the raw Euclidean gradient of the feedback term:
        ∂_Φ KL(p || Φ·q)
    
    This is the gradient of KL(self || transformed other), with gradients taken w.r.t. self (model space p).
    """

    if feedback_weight <= 0:
        return zero_mu_sigma_like(agent_i, field="model")  # Default to model for feedback

    H, W = agent_i.grid_shape

    # Only handle the "belief" field, which computes the gradient for KL(p || Φ·q)
    mu_self, sigma_self = agent_i.mu_p_field, agent_i.sigma_p_field  # Model field
    mu_q, sigma_q = agent_i.mu_q_field, agent_i.sigma_q_field      # Belief field

    K_q = mu_q.shape[-1]
    K_p = mu_self.shape[-1]

    # If phi_morphism is provided, use it, otherwise use the identity morphism
    if phi_morphism is not None:
        Phi = phi_morphism
    else:
        # Default: identity transformation between belief and model
        eye = np.eye(K_p, K_q, dtype=mu_self.dtype)
        Phi = np.broadcast_to(eye, (H, W, K_p, K_q))

    # Pull q into p-space using the morphism
    mu_q_trans, sigma_q_trans = safe_batch_apply_morphism(mu_q, sigma_q, Phi, eps=config.eps)

    # Compute the difference between the self-field and the transformed belief field
    dμ, dΣ = compute_mu_sigma_diff(mu_self, sigma_self, mu_q_trans, sigma_q_trans, direction="b_minus_a")

    # Ensure numerical stability by converting NaN or Inf values
    dμ = np.nan_to_num(dμ)
    dΣ = np.nan_to_num(dΣ)

    # Apply the optional mask if provided
    if mask is not None:
        dμ, dΣ = apply_mask_to_mu_sigma(dμ, dΣ, mask)

    # Return the scaled gradient for the feedback update
    return feedback_weight * dμ, feedback_weight * dΣ


def grad_morphism_feedback_energy(agent_i, feedback_weight, mask=None):
    """
    Compute gradient ∂KL(p || Φ·q) / ∂Φ where Φ : Q → P.
    This is the gauge-covariant feedback term.

    Args:
        agent_i        : Agent object
        feedback_weight: scalar β controlling the feedback term
        mask           : optional (H, W) spatial mask

    Returns:
        ∂F/∂Φ : (H, W, K_p, K_q)
    """
    if feedback_weight <= 0:
        return np.zeros_like(agent_i.bundle_morphism_q_to_p)

    mu_q     = agent_i.mu_q_field        # (H, W, K_q)
    sigma_q  = agent_i.sigma_q_field     # (H, W, K_q, K_q)
    mu_p     = agent_i.mu_p_field        # (H, W, K_p)
    sigma_p  = agent_i.sigma_p_field     # (H, W, K_p, K_p)
    Phi_q_to_p = agent_i.bundle_morphism_q_to_p  # Φ : Q → P

    # Project q into p-fiber via Φ
    mu_q_proj, sigma_q_proj = safe_batch_apply_morphism(mu_q, sigma_q, Phi_q_to_p)

    sigma_proj_inv = safe_inv(sigma_q_proj, eps=config.eps)
    delta_mu = mu_p - mu_q_proj

    # Gradient of Tr[Σ_proj⁻¹ Σ_p]
    grad_sigma = -2 * np.einsum("...ij,...jl,...kl->...ik", sigma_proj_inv, Phi_q_to_p, sigma_q)

    # Gradient of (μ_p - μ_proj)ᵀ Σ_proj⁻¹ ∂μ_proj/∂Φ
    grad_mu = -2 * np.einsum("...ij,...j,...k->...ik", sigma_proj_inv, delta_mu, mu_q)

    grad_total = grad_mu + grad_sigma

    if mask is not None:
        grad_total *= mask[..., None, None]

    return feedback_weight * grad_total

def compute_alignment_kl_gradient_belief(agent_i, agents, generators, params):
    """
    Compute the covariant natural gradient of KL(q_i || Ω_ij q_j) for beliefs.
    """
    beta = params.get("beta", config.beta)
    if beta <= 0:
        return np.zeros_like(agent_i.mu_q_field), np.zeros_like(agent_i.sigma_q_field)

    mu_i = agent_i.mu_q_field
    sigma_i = agent_i.sigma_q_field
    Omega_i = agent_i._exp_phi
    Omega_i = Omega_i.reshape(*mu_i.shape[:-1], mu_i.shape[-1], mu_i.shape[-1])

    delta_mu = np.zeros_like(mu_i)
    delta_sigma = np.zeros_like(sigma_i)

    for nb in agent_i.neighbors:
        agent_j = agents[nb["id"]]

        mu_j = agent_j.mu_q_field
        sigma_j = agent_j.sigma_q_field
        Omega_j_inv = agent_j._exp_neg_phi
        Omega_j_inv = Omega_j_inv.reshape(*mu_j.shape[:-1], mu_j.shape[-1], mu_j.shape[-1])

        mask_overlap = (agent_i.mask * agent_j.mask) > config.support_cutoff_eps
        if not np.any(mask_overlap):
            continue

        Omega_ij = np.einsum("...ik,...kj->...ij", Omega_i, Omega_j_inv)

        # Transport the Gaussian
        mu_j_t, sigma_j_t = transport_gaussian(mu_j, sigma_j, Omega_ij)

        sigma_j_t = sanitize_sigma(sigma_j_t, eps=config.eps)

        delta_mu_step, delta_sigma_step = kl_gradient_mu_sigma(
            mu_i, sigma_i, mu_j_t, sigma_j_t, mask=mask_overlap
        )

        delta_mu += delta_mu_step
        delta_sigma += delta_sigma_step

    return delta_mu, beta * delta_sigma

def alignment_gradient_field_belief(agent_i, agents, params, mask=None):
    """
    Raw Euclidean gradient of alignment KL divergence for beliefs:
        KL(q_i || Ω_ij q_j)

    Args:
        agent_i    : focal agent
        agents     : list of agents
        params     : dict of parameters
        mask       : optional spatial mask to restrict update region

    Returns:
        dμ, dΣ : raw Euclidean gradients (H, W, K), (H, W, K, K)
    """
    weight = params.get("beta", config.beta)

    if weight <= 0:
        return zero_mu_sigma_like(agent_i, field="belief")

    K_fiber = agent_i.mu_q_field.shape[-1]

    # Load or generate the appropriate representation generators
    generators = params.get("generators", get_generators(config.group_name, K_fiber))

    # Compute raw KL alignment gradients for beliefs
    dμ, dΣ = compute_alignment_kl_gradient_belief(agent_i, agents, generators, params)

    # Ensure numerical stability
    dμ = np.nan_to_num(dμ)
    dΣ = np.nan_to_num(dΣ)

    # Apply optional mask
    if mask is not None:
        dμ, dΣ = apply_mask_to_mu_sigma(dμ, dΣ, mask)

    return weight * dμ, weight * dΣ




def accumulate_phi_gradient_belief(agent_i, agent_j, generators, params, field="phi"):
    """
    Compute and accumulate the variational gradient:
        ∂/∂φ_i KL(q_i ‖ Ω_ij q_j)
    where Ω_ij = exp(φ_i) · exp(−φ_j) for beliefs.
    """
    # Ensure the correct field type
    assert field == "phi", f"Expected field='phi', got {field}"

    beta = params.get("beta", config.beta)
    if beta <= 0:
        return

    eps = config.support_cutoff_eps
    mask_i = agent_i.mask[..., None] > eps
    mask_j = agent_j.mask[..., None] > eps
    joint_mask = mask_i & mask_j  # Overlapping region between agents

    # Select fibers and fields for belief calculations
    mu_i = agent_i.mu_q_field
    mu_j = agent_j.mu_q_field
    sigma_i = agent_i.sigma_q_field
    sigma_j = agent_j.sigma_q_field
    phi_i = agent_i.phi
    phi_j = agent_j.phi

    # Compute Ω_ij = exp(φ_i) @ exp(-φ_j) for belief fields
    exp_phi_i = exp_lie_algebra_irrep(phi_i, generators)
    exp_neg_phi_j = exp_lie_algebra_irrep(-phi_j, generators)
    Omega_ij = np.einsum("...ik,...kj->...ij", exp_phi_i, exp_neg_phi_j)
    Omega_T = np.swapaxes(Omega_ij, -1, -2)  # Transpose of Ω_ij

    # Transport q_j to i
    mu_trans = np.einsum("...ij,...j->...i", Omega_ij, mu_j)
    sigma_trans = np.einsum("...ik,...kl,...jl->...ij", Omega_ij, sigma_j, Omega_T)
    sigma_trans = sanitize_sigma(sigma_trans, eps=config.eps)
    sigma_inv = safe_inv(sigma_trans, eps=config.eps)

    delta_mu = mu_i - mu_trans
    d_mu = -np.einsum("...ij,...j->...i", sigma_inv, delta_mu)

    delta_sigma = sigma_i - sigma_trans
    d_sigma = -0.5 * np.einsum("...ik,...kl,...lj->...ij", sigma_inv, delta_sigma, sigma_inv)

    # Gradient initialization for φ_i and φ_j
    d = generators.shape[0]  # Number of generators
    grad_phi_i = np.zeros_like(phi_i)
    grad_phi_j = np.zeros_like(phi_j)

    # Compute the variational gradients for each generator
    for a in range(d):
        G = generators[a]

        # ∂Ω/∂φ_i = Ω G
        OG = np.einsum("...ij,jk->...ik", Omega_ij, G)
        dphi_i_mu = np.einsum("...ij,...j->...i", OG, mu_j)

        OG_sigma = np.einsum("...ij,...jk->...ik", OG, sigma_j)
        dphi_sigma_1 = np.einsum("...ij,...jk->...ik", OG_sigma, Omega_T)

        sigma_GT = np.einsum("...ij,jk->...ik", sigma_j, G.T)
        O_sigma_GT = np.einsum("...ij,...jk->...ik", Omega_ij, sigma_GT)
        dphi_sigma_2 = np.einsum("...ij,...jk->...ik", O_sigma_GT, Omega_T)

        dphi_i_sigma = dphi_sigma_1 + dphi_sigma_2

        # ∂Ω/∂φ_j = -Ω G_right, where G_right = exp(φ_j) @ G @ exp(−φ_j)
        G_batch = np.broadcast_to(G, exp_phi_i.shape)
        G_right = np.einsum("...ij,...jk,...kl->...il", exp_phi_i, G_batch, exp_neg_phi_j)

        dphi_j_mu = -np.einsum("...ij,...j->...i", G_right, mu_j)

        G_right_sigma = np.einsum("...ij,...jk->...ik", G_right, sigma_j)
        dphi_j_sigma_1 = np.einsum("...ij,...jk->...ik", G_right_sigma, Omega_T)

        sigma_GT_j = np.einsum("...ij,jk->...ik", sigma_j, G.T)
        O_sigma_GT_j = np.einsum("...ij,...jk->...ik", Omega_ij, sigma_GT_j)
        dphi_j_sigma_2 = np.einsum("...ij,...jk->...ik", O_sigma_GT_j, Omega_T)

        dphi_j_sigma = dphi_j_sigma_1 + dphi_j_sigma_2

        # Accumulate the gradients
        delta_a_i = (
            np.sum(d_mu * dphi_i_mu, axis=-1) +
            np.einsum("...ij,...ij->...", d_sigma, dphi_i_sigma)
        )
        delta_a_j = (
            np.sum(d_mu * dphi_j_mu, axis=-1) +
            np.einsum("...ij,...ij->...", d_sigma, dphi_j_sigma)
        )

        grad_phi_i[..., a] += delta_a_i
        grad_phi_j[..., a] += delta_a_j

    # Apply natural gradient (μ + Σ terms separately)
    grad_phi_mu_i = dexpinv_operator(phi_i, grad_phi_i, generators)
    grad_phi_mu_j = dexpinv_operator(phi_j, grad_phi_j, generators)

    grad_phi_sigma_i = dexpinv_operator_covariance(phi_i, d_sigma, generators)
    grad_phi_sigma_j = dexpinv_operator_covariance(phi_j, -d_sigma, generators)

    grad_phi_i = grad_phi_mu_i + grad_phi_sigma_i
    grad_phi_j = grad_phi_mu_j + grad_phi_sigma_j

    # Accumulate the gradients into the agent's gradient field
    agent_i.grad_phi += beta * grad_phi_i * joint_mask
    agent_j.grad_phi += beta * grad_phi_j * joint_mask


def compute_phi_update_belief(agent_i, agents, params, field="phi"):
    """
    Unified update for φ (belief alignment).
    Applies Lie-natural gradient to alignment + optional regularizers for beliefs.
    """
    if field == "phi" and getattr(config, "identical_beliefs", False):
        return np.zeros_like(agent_i.phi)

    # --- Unpack core parameters ---
    unpacked  = unpack_phi_update_params(params, field=field)
    β         = params.get("beta", config.beta)
    κ         = unpacked["κ"]
    gw        = unpacked["gw"]
    curv_w    = unpacked["curv_weight"]
    clip_th   = unpacked["grad_clip_threshold"]
    eps       = unpacked["overlap_eps"]
    debug     = unpacked["debug"]

    phi       = agent_i.phi  # Belief field
    phi_tilde = agent_i.phi_model  # Model field
    soft_mask = agent_i.mask[..., None]
    generators_q = params.get("generators_q", get_generators(config.group_name, config.K_q))

    if not np.any(soft_mask > eps):
        return np.zeros_like(phi)

    grad = np.zeros_like(phi)

    # --- 1. Alignment gradient (Lie-natural, variationally consistent) ---
    grad_align = np.zeros_like(phi)
    if β > 0:
        for neighbor in agent_i.neighbors:
            agent_j = agents[neighbor["id"]]
            accumulate_phi_gradient_belief(agent_i, agent_j, generators_q, params, field=field)
        grad_align = agent_i.grad_phi.copy()
        agent_i.grad_phi[:] = 0.0

        grad += apply_lie_natural_gradient(phi, grad_align, G_inv=compute_inverse_fisher_field(agent_i, generators_q, field=field))

    # --- 2. Curvature gradient ---
    if curv_w > 0:
        grad_curv = compute_curvature_gradient_analytical(phi, generators_q)
        grad += curv_w * grad_curv

    # --- 3. Mass term: 2γ φ ---
    if gw > 0:
        grad += 2 * gw * phi

    # --- 4. φ–φ̃ coupling ---
    if κ > 0:
        grad += 2 * κ * (phi - phi_tilde)

    # --- 5. Optional Fisher geometry term ---
    fisher_key = "fisher_geometry_weight"
    fisher_weight = params.get(fisher_key, getattr(config, fisher_key, 0.0))
    if fisher_weight > 0:
        fisher_grad = compute_fisher_geometry_gradient(agent_i, agents, params)
        grad += fisher_weight * fisher_grad

    # --- Final clip + mask ---
    return clip_and_mask_gradient(grad, soft_mask, clip_th, eps)


