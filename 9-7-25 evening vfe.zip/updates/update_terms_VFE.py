# -*- coding: utf-8 -*-
"""
Created on Mon Sep  8 17:40:08 2025

@author: chris and christine
"""

# updates/update_terms_vfe.py
from __future__ import annotations
import numpy as np
from runtime_context import ensure_theta




def accumulate_theta_from_vfe(ctx, agents, params):
    if not params.get("enable_vfe", True):
        return None
    theta = ensure_theta(ctx, D_obs=params["obs_dim"], K_latent=agents[0].mu_q_field.shape[-1])
    W, b, sigma2 = theta.W, theta.b, theta.sigma2

    dW = np.zeros_like(W)
    db = np.zeros_like(b)
    dS = 0.0

    for A in agents:
        y = A.observation_field
        mu = A.mu_q_field
        S  = A.sigma_q_field
        m  = A.mask
        _dW, _db, _dS = vfe_theta_grads(y, mu, S, W, b, sigma2, mask=m)
        dW += _dW
        db += _db
        dS += _dS

    w = float(params.get("vfe_weight", 1.0))
    return (w * dW, w * db, w * dS)




def expected_nll_gaussian(y, mu, Sigma, W, b, sigma2, *, mask=None):
    """
    E_q[-log p(y|x)] for y|x ~ N(Wx + b, sigma2 I)
    Shapes:
      y: (..., D), mu: (..., K), Sigma: (..., K, K)
      W: (D, K), b: (D,), sigma2: scalar
    Returns scalar total and tuple of per-location pieces if needed.
    """
    y = np.asarray(y, np.float32)
    mu = np.asarray(mu, np.float32)
    Sigma = np.asarray(Sigma, np.float32)
    W = np.asarray(W, np.float32)
    b = np.asarray(b, np.float32)
    sigma2 = float(sigma2)

    D = y.shape[-1]
    r = (mu @ W.T) + b - y             # (..., D)
    r2 = np.sum(r * r, axis=-1)        # (...)
    # tr(W Σ W^T) = tr(Σ W^T W)
    WT_W = W.T @ W                      # (K, K)
    tr_term = np.einsum("...ij,ij->...", Sigma, WT_W, optimize=True)  # (...)

    const = 0.5 * D * np.log(2.0 * np.pi * sigma2)
    quad  = 0.5 * (r2 + tr_term) / max(sigma2, 1e-12)
    nll = const + quad                  # (...)

    if mask is not None:
        nll = nll * np.asarray(mask, np.float32)

    total = float(np.sum(nll))
    return total, (r, WT_W, r2, tr_term)

def vfe_mu_sigma_grads(y, mu, Sigma, W, b, sigma2, *, mask=None):
    """
    Euclidean grads wrt mu, Sigma for the accuracy term.
    Returns (grad_mu, grad_Sigma) with same shapes as inputs.
    """
    y = np.asarray(y, np.float32)
    mu = np.asarray(mu, np.float32)
    Sigma = np.asarray(Sigma, np.float32)
    W = np.asarray(W, np.float32)
    b = np.asarray(b, np.float32)
    sigma2 = float(sigma2)

    r = (mu @ W.T) + b - y                   # (..., D)
    WT = W.T
    inv_s2 = 1.0 / max(sigma2, 1e-12)

    g_mu = inv_s2 * (WT @ r[..., None]).squeeze(-1)                 # (..., K)
    WT_W = WT @ W                                                   # (K, K)
    g_S  = 0.5 * inv_s2 * WT_W                                      # (K, K)
    # broadcast g_S across batch:
    g_S  = np.broadcast_to(g_S, Sigma.shape)

    if mask is not None:
        m1 = np.asarray(mask, np.float32)[..., None]
        m2 = m1[..., None]  # for (K,K)
        g_mu = g_mu * m1
        g_S  = g_S  * m2

    # symmetrize Σ-grad
    g_S = 0.5 * (g_S + np.swapaxes(g_S, -1, -2))
    return g_mu.astype(np.float32, copy=False), g_S.astype(np.float32, copy=False)

def vfe_theta_grads(y, mu, Sigma, W, b, sigma2, *, mask=None):
    """
    Euclidean grads wrt theta = {W, b, sigma2}.
    Returns (dW, db, d_sigma2) aggregated (sum) over batch/pixels/agents.
    """
    y = np.asarray(y, np.float32)
    mu = np.asarray(mu, np.float32)
    Sigma = np.asarray(Sigma, np.float32)
    W = np.asarray(W, np.float32)
    b = np.asarray(b, np.float32)
    sigma2 = float(sigma2)

    inv_s2 = 1.0 / max(sigma2, 1e-12)
    r = (mu @ W.T) + b - y                         # (..., D)

    # dW: sum over examples of (r mu^T + W Σ)
    # shape handling:
    dW = np.einsum("...d,...k->dk", r, mu, optimize=True)          # (D,K)
    # add sum over Σ term:
    # sum_over_batch( W Σ ) = W * sum_over_batch(Σ) along appropriate dims
    Sigma_sum = np.sum(Sigma, axis=tuple(range(Sigma.ndim-2)))     # (K,K)
    dW += W @ Sigma_sum
    dW *= inv_s2

    # db: sum r
    db = np.sum(r, axis=tuple(range(r.ndim-1))) * inv_s2            # (D,)

    # d sigma2:
    D = y.shape[-1]
    r2 = np.sum(r*r, axis=-1)                                       # (...)
    WT_W = W.T @ W                                                  # (K,K)
    tr_term = np.einsum("...ij,ij->...", Sigma, WT_W, optimize=True)  # (...)
    num = np.sum(r2 + tr_term)                                      # scalar
    N  = r2.size                                                    # count of examples
    d_sigma2 = 0.5 * ( num / (sigma2**2 * max(sigma2, 1e-12)) - (D * N) / sigma2 )

    if mask is not None:
        m = np.asarray(mask, np.float32)
        # Recompute with masking to be precise:
        dW = np.einsum("...d,...k->dk", r*m[...,None], mu, optimize=True)
        Sigma_sum = np.sum(Sigma * m[...,None,None], axis=tuple(range(Sigma.ndim-2)))
        dW += W @ Sigma_sum
        dW *= inv_s2

        db = np.sum(r*m[...,None], axis=tuple(range(r.ndim-1))) * inv_s2

        r2m = np.sum((r*r) * m[...,None], axis=-1)
        trm = np.einsum("...ij,ij->...", Sigma*m[...,None,None], WT_W, optimize=True)
        num = float(np.sum(r2m + trm))
        N   = int(np.sum(m))
        d_sigma2 = 0.5 * ( num / (sigma2**2 * max(sigma2, 1e-12)) - (D * N) / sigma2 )

    return dW.astype(np.float32), db.astype(np.float32), float(d_sigma2)
