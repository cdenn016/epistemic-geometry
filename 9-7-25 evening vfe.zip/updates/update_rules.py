# -*- coding: utf-8 -*-
"""
Created on Wed Jul 23 10:32:58 2025

@author: chris and christine
"""

import time
from runtime_context import ensure_runtime_defaults
from core.gaussian_core import resolve_support_tau
from updates.update_compute_all_gradients import _apply_children, _compute_child_grads
from updates.update_refresh_utils import (
    refresh_agents_light,    
    mark_dirty, ensure_dirty, list_nonnull,
    
)



class PhaseTimer:
    """Context-manager timer that aggregates per-phase wall time on runtime_ctx."""
    def __init__(self, ctx):
        self.ctx = ctx
        if not hasattr(ctx, "timings") or getattr(ctx, "timings") is None:
            ctx.timings = {}

    def __call__(self, name: str):
        ctx = self.ctx
        class _T:
            def __enter__(_s):
                _s.t0 = time.perf_counter()
                return _s
            def __exit__(_s, *_):
                dt = time.perf_counter() - _s.t0
                ctx.timings[name] = ctx.timings.get(name, 0.0) + dt
        return _T()





# --- synchronous step (simplified, timed) ------------------------------------
def synchronous_step(agents, generators_q, generators_p, params=None, n_jobs=1, runtime_ctx=None):
    """
    Single-scale (children-only) synchronous update step.
    Evolves child agents, enforces caches, warms pairwise transport (KL refresh),
    and registers children. No parents/detection/spawn/xscale.
    """
    
    import core.config as config

    def CFG(key, default=None):
        return (params or {}).get(key, getattr(config, key, default))

    assert runtime_ctx is not None, "synchronous_step: pass runtime_ctx"
    assert agents and (len(agents) > 0), "synchronous_step: no agents"

    params = dict(params or {})
    params["runtime_ctx"] = runtime_ctx

    _ = resolve_support_tau(runtime_ctx, params, default=1e-3, name="support_tau")
    runtime_ctx = ensure_runtime_defaults(runtime_ctx)

    if not hasattr(runtime_ctx, "cache") or runtime_ctx.cache is None:
        try:
            from runtime_context import CacheHub
            runtime_ctx.cache = CacheHub()
        except Exception:
            class _NoopCache:
                def clear_on_step(self, *_args, **_kw): pass
                def ns(self, *_args, **_kw):
                    class _D(dict):
                        def clear(self): super().clear()
                    return _D()
            runtime_ctx.cache = _NoopCache()

    step_now = int(getattr(runtime_ctx, "global_step", 0))
    runtime_ctx.cache.clear_on_step(step_now)

    d = getattr(runtime_ctx, "dirty", None)
    if hasattr(d, "reset_step"):
        d.reset_step(step_now)
    try:
        d.agents.clear(); d.kl.clear()
    except Exception:
        pass

    T = PhaseTimer(runtime_ctx)

    # ---------------- Phase 0: pre ----------------
    with T("pre"):
        children = list_nonnull(agents)
        if not children:
            runtime_ctx.register_agents(0, [])
            runtime_ctx.global_step += 1
            return agents
        refresh_agents_light(children, params, generators_q, generators_p, ctx=runtime_ctx)

    

    # ---------------- Phase 1: child grads/apply ---
    with T("child_grad"):
        grads = _compute_child_grads(children, children, generators_q, generators_p, params)

    with T("child_apply"):
        frozen_levels     = set(params.get("frozen_levels", []))
        frozen_phi_levels = set(params.get("frozen_phi_levels", []))
        _apply_children(children, grads, params, frozen_levels, frozen_phi_levels,
                        generators_q, generators_p, n_jobs, ctx=runtime_ctx)
        for a in children:
            mark_dirty(runtime_ctx, a, kl=True)  # signal pairwise caches to warm
        runtime_ctx.children_latest = children

    # ---------------- Phase 2: ensure/caches -------
    with T("ensure_children"):
        ensure_dirty(runtime_ctx, generators_q, generators_p, params, scope="children")



    # ---------------- Phase 4: register/step -------
    with T("register"):
        runtime_ctx.register_agents(0, children)
        runtime_ctx.children_latest = children
        runtime_ctx.global_step    += 1

    # ---------------- Phase 5: timing --------------
    if bool(CFG("debug_phase_timing", True)):
        print("[timings]")
        for name, dt in sorted(getattr(runtime_ctx, "timings", {}).items()):
            print(f"  {name:20s} {dt:8.3f}s")
        if getattr(runtime_ctx, "counters", None):
            print("[counts]", runtime_ctx.counters)

    return agents













