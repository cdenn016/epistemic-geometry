import os
import numpy as np
import multiprocessing
import importlib
import config
import matplotlib.pyplot as plt
import pickle
from datetime import datetime
from joblib import Parallel, delayed
from scipy.spatial.distance import pdist, squareform

# --- Reload config early ---
importlib.reload(config)

# --- Config variables ---
from config import agent_seed, steps, N, eta_phi, set_config_from_params, support_cutoff_eps, domain_size

# --- Agent logic ---
from agent_init_phi_smoothed import initialize_agents
from agent_schema import Agent
from update_rules import update_beliefs, update_phi

# --- Omega operator (transport math) ---
from omega_operator import (
    kl_divergence,
    exp_so3_irrep_approx,
    batch_exp_so3_irrep_approx,
    apply_omega,
    batch_apply_omega,
    exp_so3_operator,
    compute_gauge_potential,
    compute_field_strength,
    compute_so3_commutator,
    compute_so3_curvature
)

# --- SO(3) representation ---
from so3_generators import get_generators

# --- Graph + path planning ---
from chain_transport import build_overlap_graph, find_agent_chain

# --- Core belief transport ---
from generalized_transport import transport_belief_along_path

# --- Diagnostics ---
from diagnostics_metrics import (
    compute_total_energy,
    compute_alignment_error,
    log_phi_diagnostics,
    compute_transport_strength,
    compute_network_transport_strength,
    compute_average_entropy,
    compute_kl_divergences,
    compute_phi_norm,
    compute_curvature_norm,
    compute_phi_laplacian_norm,
    compute_phi_delta_norm,
    log_all_metrics
)

from diagnostics_plot import (
    plot_alignment_over_time,
    plot_phi_diagnostics,
    plot_energy_over_time
)

# --- Save/load utils ---
from io_utils import load_checkpoint, find_resume_step, save_step


def list_all_step_files(checkpoints_dir="checkpoints"):
    step_files = sorted([
        f for f in os.listdir(checkpoints_dir)
        if f.startswith("step_") and f.endswith(".pkl")
    ])
    return [int(f[5:-4]) for f in step_files]


def load_agents(step, checkpoints_dir="checkpoints"):
    path = os.path.join(checkpoints_dir, f"step_{step:04d}.pkl")
    if not os.path.exists(path):
        raise FileNotFoundError(f"[ERROR] Missing checkpoint: {path}")
    with open(path, "rb") as f:
        return pickle.load(f)


def run_transport_for_step(step, checkpoints_dir, save_dir, fixed_path, fixed_start, fixed_end):
    print(f"[STEP {step}] Loading agents...")
    agents = load_agents(step, checkpoints_dir)
    G = build_overlap_graph(agents)
    K = agents[0].q.shape[-1]

    # --- Validate agent-to-agent overlap along fixed_path ---
    valid = True
    for i in range(len(fixed_path) - 1):
        a, b = fixed_path[i], fixed_path[i + 1]
        mask_a = agents[a].mask
        mask_b = agents[b].mask
        overlap = (mask_a * mask_b) > support_cutoff_eps
        if not np.any(overlap):
            print(f"[INVALID] Step {step}: No overlap between agent {a} and agent {b}")
            valid = False

    if not valid:
        print(f"[SKIP] Step {step} skipped due to invalid fixed path: {fixed_path}")
        return False

    agents_before = pickle.loads(pickle.dumps(agents))  # Deep copy for q_initial logging

    # --- Attempt transport ---
    try:
        agents, diagnostics = transport_belief_along_path(
            agents, fixed_path, domain_size, support_cutoff_eps, K,
            fixed_start=fixed_start,
            fixed_end=fixed_end
        )
    except Exception as e:
        print(f"[ERROR] Transport failed at step {step}: {type(e).__name__}: {e}")
        return False

    # --- Determine spatial points associated with each agent in the path ---
    full_path = diagnostics["full_path"]
    path_indices = diagnostics["path_indices"]
    path_coords = []

    for agent_idx in path_indices:
        agent = agents[agent_idx]
        overlap_candidates = [c for c in full_path if agent.mask[c] > 0]
        if overlap_candidates:
            best_point = max(overlap_candidates, key=lambda c: agent.mask[c])
        else:
            best_point = agent.center  # fallback

        path_coords.append(best_point)

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    outdir = os.path.join(save_dir, f"transport_from_step{step:04d}_{timestamp}")
    os.makedirs(outdir, exist_ok=True)

    log = {
        "step": step,
        "path_indices": path_indices,
        "full_path": full_path,
        "path_coords": path_coords,
        "c_start": diagnostics["c_start"],
        "c_final": diagnostics["c_final"],
        "kl_path": diagnostics.get("kl_path"),
        "kl_path_fine": diagnostics.get("kl_path_fine"),
        "q_initial": agents_before[path_indices[0]].q[diagnostics["c_start"]],
        "q_final": agents[path_indices[-1]].q[diagnostics["c_final"]],
        "q_target": agents[path_indices[-1]].p[diagnostics["c_final"]],
    }

    with open(os.path.join(outdir, "transport_log.pkl"), "wb") as f:
        pickle.dump(log, f)
    with open(os.path.join(outdir, "agents_before.pkl"), "wb") as f:
        pickle.dump(agents_before, f)
    with open(os.path.join(outdir, "agents_after.pkl"), "wb") as f:
        pickle.dump(agents, f)

    print(f"[✓] Transport for step {step} saved to: {outdir}")
    return True

if __name__ == "__main__":
    
    from chain_transport import build_overlap_graph, find_agent_chain
    from scipy.spatial.distance import pdist, squareform

    checkpoints_dir = "checkpoints"
    save_dir = "transport_runs"
    os.makedirs(save_dir, exist_ok=True)

    # === DYNAMIC CONFIG ===
    reference_step = 0

    try:
        agents = load_agents(reference_step, checkpoints_dir)
    except FileNotFoundError as e:
        print(f"[ERROR] Failed to load reference step {reference_step}: {e}")
        exit(1)

    # --- Build overlap graph ---
    G = build_overlap_graph(agents)

    # --- Choose source and target agents by max spatial separation ---
    centers = np.array([a.center for a in agents])
    dist_matrix = squareform(pdist(centers))
    i, j = np.unravel_index(np.argmax(dist_matrix), dist_matrix.shape)
    source_id, target_id = int(i), int(j)

    # --- Find a valid chain between them with minimum length ---
    fixed_path = find_agent_chain(G, source_id, target_id, min_length=3)
    
    if fixed_path is None:
        print(f"[ERROR] Could not find path of at least 4 agents between {source_id} and {target_id}")
        exit(1)

    print(f"[CONFIG] fixed_path = {fixed_path}")

    # --- Select injection points in source and target ---
    mask_start = agents[fixed_path[0]].mask
    mask_end = agents[fixed_path[-1]].mask
    try:
        fixed_start = tuple(np.argwhere(mask_start > 0.9 * mask_start.max())[0])
        fixed_end = tuple(np.argwhere(mask_end > 0.9 * mask_end.max())[0])
    except IndexError:
        print("[ERROR] No valid injection points found in fixed_path endpoints.")
        exit(1)

    print(f"[CONFIG] fixed_start = {fixed_start}, fixed_end = {fixed_end}")

    # --- Load available steps ---
    steps = list_all_step_files(checkpoints_dir)
    print(f"[INFO] Found {len(steps)} step files: {steps}")

    # --- Run transport at each step ---
    for step in steps:
        success = run_transport_for_step(
            step,
            checkpoints_dir,
            save_dir,
            fixed_path,
            fixed_start,
            fixed_end
        )
        if not success:
            print(f"[WARNING] Skipped step {step} due to validation or transport failure.")

