# update_rules.py

from config import (
    eta_q, log_eps, overlap_eps, support_cutoff_eps, K,
    phi_clip_threshold
)

from scipy.ndimage import laplace
from agent_schema import Agent  # <-- dataclass
import numpy as np
from scipy.linalg import expm
import numpy as np
import config  # Access dynamic alpha, beta, etc. here
from so3_generators import get_generators

from omega_operator import (
    get_generators,
    kl_divergence,
    exp_so3_irrep_approx,
    batch_exp_so3_irrep_approx,
    apply_omega,
    batch_apply_omega,
    exp_so3_operator,
    compute_gauge_potential,
    compute_field_strength,
    compute_so3_commutator,
    compute_so3_curvature
)

_, _, _, generators = get_generators(K)  # ✅ safely extracts (3, K, K)


def update_beliefs(i: int, agents: list[Agent], params: dict) -> Agent:
    from config import set_config_from_params
    from omega_operator import repair_if_forgotten_batch
    set_config_from_params(params)

    agent_i = agents[i]
    q_i = agent_i.q
    p_i = agent_i.p
    mask_i = agent_i.mask

    grad = np.zeros_like(q_i, dtype=np.float32)
    support_i = mask_i > config.support_cutoff_eps

    # --- Self-model term: D_KL(q || p) ---
    if config.alpha > 0 and np.any(support_i):
        kl_self = kl_divergence(q_i[support_i], p_i[support_i])
        grad[support_i] += config.alpha * kl_self[..., None]

    # --- Communication term: D_KL(q || Ω q_j) ---
    if config.beta > 0:
        for neighbor in agent_i.neighbors:
            j = neighbor["id"]
            agent_j = agents[j]
            q_j = agent_j.q
            mask_j = agent_j.mask
            phi_i = agent_i.phi
            phi_j = agent_j.phi

            overlap = (mask_i * mask_j) > config.overlap_eps
            if not np.any(overlap):
                continue

            r = phi_i - phi_j
            xy_indices = np.argwhere(overlap)
            if len(xy_indices) == 0:
                continue

            r_vecs = r[overlap]
            qj_vecs = q_j[overlap]

            # --- Optional φ clipping ---
            phi_max = 10.0
            r_vecs = np.clip(r_vecs, -phi_max, phi_max)

            omega_batch = batch_exp_so3_irrep_approx(r_vecs, generators)
            if omega_batch is None:
                continue

            qj_rot_batch = batch_apply_omega(qj_vecs, omega_batch)
            qj_rot_batch = repair_if_forgotten_batch(qj_rot_batch, eps=config.log_eps)

            # Fill into a full spatial field
            qj_rot = np.zeros_like(q_j)
            for idx, (x, y) in enumerate(xy_indices):
                qj_rot[x, y] = qj_rot_batch[idx]

            kl_align = kl_divergence(q_i, qj_rot)
            grad += config.beta * kl_align[..., None] * overlap[..., None]

               # --- Update q ---
    q_new = q_i - config.eta_q * grad
    q_new[~support_i] = q_i[~support_i]
    q_new = np.clip(q_new, config.log_eps, 1.0)
    q_new = repair_if_forgotten_batch(q_new, eps=config.log_eps)

    agent_i.q = q_new
    return agent_i


def update_phi(i: int, agents: list[Agent], eta_phi: float, params: dict) -> Agent:
    from config import set_config_from_params
    set_config_from_params(params)

    agent_i = agents[i]
    phi_i = agent_i.phi.astype(np.float64)
    q_i = agent_i.q
    mask_i = agent_i.mask

    delta_phi = np.zeros_like(phi_i, dtype=np.float64)

    # --- Communication-induced φ gradient (only if beta > 0) ---
    if config.beta > 0:
        for neighbor in agent_i.neighbors:
            j = neighbor["id"]
            agent_j = agents[j]
            phi_j = agent_j.phi
            q_j = agent_j.q
            mask_j = agent_j.mask

            overlap = (mask_i * mask_j) > config.overlap_eps
            if not np.any(overlap):
                continue

            r = phi_i - phi_j
            xy_indices = np.argwhere(overlap)
            if len(xy_indices) == 0:
                continue

            r_vecs = r[overlap]

            # --- Optional safety clamp to prevent overflow ---
            phi_max = np.pi
            r_vecs = np.clip(r_vecs, -phi_max, phi_max)

            qj_vecs = q_j[overlap]
            mask_vals = mask_i[overlap]

            omega_batch = batch_exp_so3_irrep_approx(r_vecs, generators)
            if omega_batch is None:
                continue

            qj_rot_batch = batch_apply_omega(qj_vecs, omega_batch)
            qj_rot_batch = np.nan_to_num(qj_rot_batch, nan=0.0, posinf=0.0, neginf=0.0)

            norms = np.sum(qj_rot_batch, axis=-1, keepdims=True)
            if np.any(norms < config.log_eps):
                print(f"[WARNING] φ-induced qj_rot has near-zero norm in agent {i}")
            norms = np.where(norms > config.log_eps, norms, 1.0)
            qj_rot_batch /= norms

            qi_vecs = q_i[overlap]
            for idx, (x, y) in enumerate(xy_indices):
                qi = qi_vecs[idx]
                qj_rot = qj_rot_batch[idx]
                dkl = kl_divergence(qi, qj_rot)

                for a in range(3):
                    Ta = generators[a]
                    Ta_qj = qj_rot @ Ta.T
                    grad_a = np.sum((qi - qj_rot) * Ta_qj)
                    grad_a = grad_a if np.isfinite(grad_a) else 0.0
                    grad_a = np.clip(grad_a, -1e3, 1e3)
                    delta_phi[x, y, a] += config.beta * grad_a * mask_vals[idx]

    # --- Curvature-induced term ---
    #if config.curvature_weight > 0:
        #F2 = compute_field_strength(phi_i)
        #lap_F2 = np.stack([laplace(F2) for _ in range(3)], axis=-1)
        #delta_phi -= config.curvature_weight * lap_F2 * mask_i[..., None]

    # --- φ Laplacian smoothing ---
    if config.gamma > 0:
        lap_phi = np.stack([laplace(phi_i[..., d]) for d in range(3)], axis=-1)
        delta_phi -= config.gamma * lap_phi * mask_i[..., None]

    # --- φ gauge potential (frame consistency) ---
    if config.gauge_weight > 0:
        delta_phi -= config.gauge_weight * phi_i * mask_i[..., None]

    # --- φ epistemic damping ---
    if hasattr(config, "phi_damping") and config.phi_damping > 0:
        delta_phi -= config.phi_damping * phi_i * mask_i[..., None]

    # --- Final stabilization ---
    delta_phi = np.nan_to_num(delta_phi, nan=0.0, posinf=0.0, neginf=0.0)

# Optional clamp on the update step to avoid runaway growth
    max_step = np.pi  # or something smaller if φ becomes unstable
    delta_phi = np.clip(delta_phi, -max_step, max_step)

    agent_i.phi += eta_phi * delta_phi
    agent_i.delta_phi = delta_phi
    return agent_i



