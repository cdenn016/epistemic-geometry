# -*- coding: utf-8 -*-
"""
Created on Mon Jun  9 14:22:11 2025

@author: chris and christine
"""

import os
import pickle
import numpy as np
import matplotlib.pyplot as plt

def plot_q_evolution(transport_dir, agent_id=0, coord=None, after=True, max_steps=100):
    q_series = []
    steps = []

    step_dirs = sorted(
        [f for f in os.listdir(transport_dir) if f.startswith("transport_from_step")],
        key=lambda s: int(s.split("step")[1].split("_")[0])
    )

    for folder in step_dirs:
        step = int(folder.split("step")[1].split("_")[0])
        if step > max_steps:
            continue

        subdir = os.path.join(transport_dir, folder)
        agents_path = os.path.join(subdir, "agents_after.pkl" if after else "agents_before.pkl")
        log_path = os.path.join(subdir, "transport_log.pkl")

        if not os.path.exists(agents_path) or not os.path.exists(log_path):
            continue

        with open(agents_path, "rb") as f:
            agents = pickle.load(f)
        with open(log_path, "rb") as f:
            log = pickle.load(f)

        # Default: use logged injection point
        if coord is None:
            coord = log["c_start"]

        q = agents[agent_id].q[coord]
        q_series.append(q)
        steps.append(step)

    # --- Plot ---
    q_series = np.array(q_series)
    plt.figure(figsize=(10, 4))
    for q in q_series:
        plt.plot(q, alpha=0.4)
    plt.title("Evolution of Source Belief $q_0$ Over Time")
    plt.xlabel("Fiber Index")
    plt.ylabel("Probability")
    plt.grid(True)
    plt.tight_layout()
    plt.show()

    return steps, q_series
if __name__ == "__main__":
    plot_q_evolution("transport_runs", agent_id=0)
