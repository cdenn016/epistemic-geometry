
import os
os.environ["OMP_NUM_THREADS"] = "1"



import numpy as np
import matplotlib.pyplot as plt
from sklearn.decomposition import PCA
from sklearn.cluster import KMeans, DBSCAN
from config import log_eps
import pickle

import glob
from matplotlib.animation import FuncAnimation

os.makedirs("animations", exist_ok=True)


def detect_meta_agents(state_log, step=-1, n_components=3, n_clusters=5):
    agents = state_log[step]
    features = []

    for a in agents:
        valid = a.mask > 0.1
        if not np.any(valid):
            continue
        q_flat = a.q[valid].mean(axis=0)
        phi_flat = a.phi[valid].mean(axis=0)
        features.append(np.concatenate([q_flat, phi_flat]))

    features = np.array(features)
    if len(features) == 0:
        raise ValueError("No valid agents found for meta-agent analysis.")

    n_components = min(n_components, features.shape[0], features.shape[1])
    Z = PCA(n_components=n_components).fit_transform(features)
    kmeans = KMeans(n_clusters=min(n_clusters, len(features)), random_state=0).fit(Z)
    return Z, kmeans.labels_



def plot_coarse_grained_fields(state_log, step=-1):
    os.makedirs("animations", exist_ok=True)

    agents = state_log[step]
    q_shape = agents[0].q.shape[:2]
    K = agents[0].q.shape[-1]
    q_avg = np.zeros((*q_shape, K))
    phi_avg = np.zeros((*q_shape, 3))
    mask_total = np.zeros(q_shape)

    for a in agents:
        mask = a.mask
        q_avg += a.q * mask[..., None]
        phi_avg += a.phi * mask[..., None]
        mask_total += mask

    q_avg /= (mask_total[..., None] + log_eps)
    phi_avg /= (mask_total[..., None] + log_eps)
    q_avg[mask_total == 0] = 0
    phi_avg[mask_total == 0] = 0

    for k in range(K):
        plt.imshow(q_avg[..., k], cmap='viridis')
        plt.title(f"q_avg[..., {k}]")
        plt.colorbar()
        plt.savefig(f"animations/coarse_q_k{k}.png")
        plt.close()

    for d in range(3):
        plt.imshow(phi_avg[..., d], cmap='RdBu')
        plt.title(f"phi_avg[..., {d}]")
        plt.colorbar()
        plt.savefig(f"animations/coarse_phi_d{d}.png")
        plt.close()
        
if __name__ == "__main__":
    os.makedirs("animations", exist_ok=True)

    step_files = sorted(glob.glob("checkpoints/step_*.pkl"))
    state_log = []
    for fpath in step_files:
        try:
            with open(fpath, "rb") as f:
                state_log.append(pickle.load(f))
        except Exception as e:
            print(f"[WARNING] Skipping {fpath} due to error: {e}")

    if not state_log:
        print("[ERROR] No valid step files found in checkpoints/")
        exit(1)
    else:
        print(f"[INFO] Loaded {len(state_log)} steps from step_*.pkl files.")

    
    try:
        plot_coarse_grained_fields(state_log)
        print("[INFO] Coarse-grained field plots saved.")
    except Exception as e:
       print(f"[ERROR] Failed to plot coarse-grained fields: {e}")
