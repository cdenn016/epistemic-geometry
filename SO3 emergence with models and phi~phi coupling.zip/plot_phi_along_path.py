# -*- coding: utf-8 -*-
"""
Created on Sun Jun  8 20:13:09 2025

@author: chris and christine
"""

import os
import pickle
import numpy as np
import matplotlib.pyplot as plt
import re

def extract_step(foldername):
    match = re.search(r"step(\d+)", foldername)
    return int(match.group(1)) if match else -1

def load_phi_path_vectors(path, fixed_path, fixed_coords):
    """
    fixed_path: list of agent indices like [0, 1, 2, 3]
    fixed_coords: list of (x, y) positions along the path (e.g. overlap points)
    """
    phi_traces = [[] for _ in fixed_coords]  # one per position
    steps = []

    for folder in sorted(os.listdir(path)):
        step = extract_step(folder)
        agents_path = os.path.join(path, folder, "agents_before.pkl")
        if not os.path.exists(agents_path):
            continue
        try:
            with open(agents_path, "rb") as f:
                agents = pickle.load(f)
            for i, (agent_idx, coord) in enumerate(zip(fixed_path, fixed_coords)):
                phi = agents[agent_idx].phi[coord]
                phi_traces[i].append(phi)
            steps.append(step)
        except Exception as e:
            print(f"[SKIP] {folder}: {e}")
    return steps, phi_traces

def plot_phi_traces(steps, phi_traces, labels=None):
    fig, axs = plt.subplots(len(phi_traces), 1, figsize=(8, 2 * len(phi_traces)))
    if len(phi_traces) == 1:
        axs = [axs]

    for i, trace in enumerate(phi_traces):
        trace = np.array(trace)  # (T, 3)
        for d in range(3):
            axs[i].plot(steps, trace[:, d], label=f"$phi_{d}$")
        label = labels[i] if labels else f"Point {i}"
        axs[i].set_title(f"φ-field at {label}")
        axs[i].set_xlabel("Step")
        axs[i].legend()
        axs[i].grid(True)
    plt.tight_layout()
    plt.savefig("phi_along_path.png")
    plt.show()
    print("[✓] Saved φ evolution plot to phi_along_path.png")


if __name__ == "__main__":
    transport_dir = "transport_runs"
    
    # Manually specify or load from one of the logs
    with open(os.path.join(transport_dir, sorted(os.listdir(transport_dir))[-1], "transport_log.pkl"), "rb") as f:
        log = pickle.load(f)
    
    fixed_path = log["path_indices"]
    fixed_coords = log["path_coords"]

    steps, phi_traces = load_phi_path_vectors(transport_dir, fixed_path, fixed_coords)
    plot_phi_traces(steps, phi_traces)
