# -*- coding: utf-8 -*-
"""
Created on Sun Jun  8 12:51:47 2025

@author: chris and christine
"""

# agent_schema.py

from dataclasses import dataclass
import numpy as np
from typing import Tuple, List

@dataclass
class Agent:
    id: int
    mask: np.ndarray
    q: np.ndarray
    p: np.ndarray
    phi: np.ndarray
    phi_model: np.ndarray
    center: Tuple[int, int]
    radius: float
    mu_q_field: np.ndarray
    sigma_q_field: np.ndarray
    mu_p_field: np.ndarray
    sigma_p_field: np.ndarray
    neighbors: List[dict]
    delta_phi_model: np.ndarray = None  # Optional


    @staticmethod
    def from_dict(d: dict) -> "Agent":
        return Agent(**d)

    def to_dict(self) -> dict:
        return self.__dict__
