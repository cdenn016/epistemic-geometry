# -*- coding: utf-8 -*-
"""
Created on Thu Jun 12 21:44:06 2025

@author: chris and christine
"""

import os
import pickle
import numpy as np
import matplotlib.pyplot as plt
from io_utils import list_all_step_files, load_agents
from diagnostics_metrics import compute_curvature_norm

def plot_curvature_time_series(run_dir, outdir="curvature_plots"):
    os.makedirs(outdir, exist_ok=True)

    step_files = list_all_step_files(run_dir)
    steps = []
    curvature_vals = []

    for step in step_files:
        try:
            agents = load_agents(step, run_dir)
            curv = compute_curvature_norm(agents)
            steps.append(step)
            curvature_vals.append(curv)
        except Exception as e:
            print(f"[WARN] Skipping step {step}: {e}")
            continue

    if not steps:
        print(f"[SKIP] No valid steps in {run_dir}")
        return

    label = os.path.basename(run_dir)
    plt.figure(figsize=(6, 4))
    plt.plot(steps, curvature_vals, marker='o')
    plt.xlabel("Step")
    plt.ylabel("Curvature Norm")
    plt.title(f"Curvature vs Time — {label}")
    plt.grid(True)
    plt.tight_layout()
    plt.savefig(os.path.join(outdir, f"curvature_vs_time_{label}.png"))
    plt.close()


def batch_plot_all(lhs_dir="lhs_runs"):
    for subdir in sorted(os.listdir(lhs_dir)):
        run_path = os.path.join(lhs_dir, subdir)
        if not os.path.isdir(run_path):
            continue
        plot_curvature_time_series(run_path)


if __name__ == "__main__":
    batch_plot_all()
    print("[DONE] Time-series curvature plots saved.")
