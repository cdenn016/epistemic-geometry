import os
import pickle
import matplotlib.pyplot as plt
from glob import glob
import imageio
import numpy as np
from scipy.optimize import curve_fit
import csv

def exp_decay(t, A, r, C):
    return A * np.exp(-r * t) + C

def main():
    param = "beta"
    folders = sorted(glob(f"sweeps_{param}/*/"))
    frames_dir = f"energy_frames_{param}"
    os.makedirs(frames_dir, exist_ok=True)

    frame_paths = []
    fit_results = []
    all_totals = []

    for folder in folders:
        path = os.path.join(folder, "energy_log.pkl")
        if not os.path.isfile(path):
            print(f"[SKIP] No energy_log.pkl in {folder}")
            continue

        try:
            with open(path, "rb") as f:
                energy_log = pickle.load(f)
            if not energy_log:
                print(f"[SKIP] Empty log in {folder}")
                continue

            steps = np.array([e[0] for e in energy_log])
            totals = np.array([e[1]["Total"] for e in energy_log])
            all_totals.extend(totals)

            val = float(os.path.basename(os.path.normpath(folder)).split("_")[-1])

            try:
                popt, _ = curve_fit(exp_decay, steps, totals, p0=(totals[0], 0.01, min(totals)))
                A, r, C = popt
            except Exception as e:
                print(f"[WARN] Fit failed for {param}={val:.2f}: {e}")
                A = r = C = np.nan

            fit_results.append((val, A, r, C))

            plt.figure(figsize=(6, 4))
            plt.plot(steps, totals, label="Total Energy", color="black")
            if not np.isnan(r):
                fit_vals = exp_decay(steps, *popt)
                plt.plot(steps, fit_vals, "--", label=f"Fit: A={A:.2f}, r={r:.3f}, C={C:.2f}", color="red")
            plt.xlabel("Step")
            plt.ylabel("Total Energy")
            plt.title(f"{param} = {val:.2f}", fontsize=12)
            plt.grid(True)
            plt.ylim(0, max(all_totals) * 1.1)
            plt.legend()
            plt.tight_layout()

            frame_path = os.path.join(frames_dir, f"frame_{param}_{val:.2f}.png")
            plt.savefig(frame_path)
            frame_paths.append(frame_path)
            plt.close()

        except Exception as e:
            print(f"[ERROR] Failed on {folder}: {e}")

    # Save CSV
    with open(f"{param}_energy_fit.csv", "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow([param, "A", "r", "C"])
        writer.writerows(fit_results)
    print(f"[DONE] Saved fit results to {param}_energy_fit.csv")

    # Make GIF
    if frame_paths:
        output_gif = f"energy_sweep_{param}.gif"
        images = [imageio.imread(p) for p in sorted(frame_paths, key=lambda x: float(x.split("_")[-1][:-4]))]
        imageio.mimsave(output_gif, images, fps=2)
        print(f"[DONE] Saved animation with {len(images)} frames to {output_gif}")
    else:
        print("[WARN] No frames to animate.")

if __name__ == "__main__":
    main()
