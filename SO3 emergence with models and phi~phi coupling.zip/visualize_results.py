import os
import numpy as np
import matplotlib.pyplot as plt
import imageio.v2 as imageio
from matplotlib import cm

from omega_operator import (
    get_generators,
    kl_divergence,
    exp_so3_irrep_approx,
    batch_exp_so3_irrep_approx,
    apply_omega,
    batch_apply_omega,
    exp_so3_operator,
    compute_gauge_potential,
    compute_field_strength,
    compute_so3_commutator,
    compute_so3_curvature
)

import imageio


# Create output directory if it doesn't exist
os.makedirs("animations", exist_ok=True)



def plot_energy_log(energy_log):
    if not energy_log:
        print("[WARNING] Empty energy_log — skipping plot.")
        return None

    os.makedirs("animations", exist_ok=True)

    # Extract keys from the first non-empty record
    keys = sorted(energy_log[0][1].keys())
    steps = [step for step, _ in energy_log]
    curves = {k: [entry[k] for _, entry in energy_log] for k in keys}

    plt.figure(figsize=(10, 6))
    for k in keys:
        plt.plot(steps, curves[k], label=k)
    plt.xlabel("Step")
    plt.ylabel("Energy")
    plt.title("Energy Components Over Time")
    plt.legend()
    plt.grid(True)
    plt.tight_layout()
    path = os.path.join("animations", "energy_over_time.png")
    plt.savefig(path)
    plt.close()
    return path




def animate_field_over_time(state_log, field_key, agent_index=0, cmap='viridis', vmin=None, vmax=None, title_prefix=''):
    os.makedirs("animations", exist_ok=True)

    # Auto compute global vmin/vmax if not provided
    if vmin is None or vmax is None:
        all_vals = []
        for agents in state_log:
            agent = agents[agent_index]
            field = getattr(agent, field_key) * agent.mask
            all_vals.append(field.ravel())
        full = np.concatenate(all_vals)
        vmin, vmax = 0, np.percentile(full, 99)

    frames = []
    for t, agents in enumerate(state_log):
        agent = agents[agent_index]
        field = getattr(agent, field_key)
        field_masked = field * agent.mask

        fig, ax = plt.subplots(figsize=(5, 5))
        im = ax.imshow(field_masked, cmap=cmap, vmin=vmin, vmax=vmax)
        ax.set_title(f"{title_prefix} (Step {t})")
        plt.colorbar(im, ax=ax)
        fig.canvas.draw()

        frame = np.asarray(fig.canvas.buffer_rgba())
        frames.append(frame)
        plt.close()

    gif_path = os.path.join("animations", f"{field_key}_agent{agent_index}.gif")
    imageio.mimsave(gif_path, frames, fps=10)
    return gif_path


def animate_mu_sigma_fields(state_log, agent_index=0):
    mu_vals = []
    sigma_vals = []
    for agents in state_log:
        mu_vals.append(agents[agent_index].mu_q_field.ravel())
        sigma_vals.append(agents[agent_index].sigma_q_field.ravel())
    mu_all = np.concatenate(mu_vals)
    sigma_all = np.concatenate(sigma_vals)
    mu_min, mu_max = 0, np.percentile(mu_all, 99)
    sigma_min, sigma_max = 0, np.percentile(sigma_all, 99)

    mu_gif = animate_field_over_time(state_log, 'mu_q_field', agent_index, 'plasma', mu_min, mu_max, 'μ_q field')
    sigma_gif = animate_field_over_time(state_log, 'sigma_q_field', agent_index, 'cividis', sigma_min, sigma_max, 'σ_q field')
    return mu_gif, sigma_gif


def animate_phi_norm(state_log, agent_index=0):
    os.makedirs("animations", exist_ok=True)

    # Compute global vmin/vmax for stable colorbar
    phi_norms = []
    for agents in state_log:
        phi = agents[agent_index].phi
        mask = agents[agent_index].mask
        norm = np.linalg.norm(phi, axis=-1) * mask
        phi_norms.append(norm.ravel())
    full = np.concatenate(phi_norms)
    vmin, vmax = 0, np.percentile(full, 99)

    frames = []
    for t, agents in enumerate(state_log):
        phi = agents[agent_index].phi
        mask = agents[agent_index].mask
        phi_norm = np.linalg.norm(phi, axis=-1) * mask

        fig, ax = plt.subplots(figsize=(5, 5))
        im = ax.imshow(phi_norm, cmap='magma', vmin=vmin, vmax=vmax)
        ax.set_title(f"‖ϕ‖ (Step {t})")
        plt.colorbar(im, ax=ax)
        fig.canvas.draw()

        frame = np.asarray(fig.canvas.buffer_rgba())
        frames.append(frame)
        plt.close()

    gif_path = os.path.join("animations", f"phi_norm_agent{agent_index}.gif")
    imageio.mimsave(gif_path, frames, fps=10)
    return gif_path



def animate_kl_divergence(state_log, agent_index=0):
   
    os.makedirs("animations", exist_ok=True)

    # Global color scale
    kl_vals = []
    for agents in state_log:
        agent = agents[agent_index]
        q = agent.q
        p = agent.p
        mask = agent.mask
        kl_map = np.zeros_like(mask, dtype=np.float32)

        # Compute scalar KL at each (x, y)
        for x in range(q.shape[0]):
            for y in range(q.shape[1]):
                if mask[x, y] > 0:
                    kl_map[x, y] = kl_divergence(q[x, y], p[x, y]) * mask[x, y]
        kl_vals.append(kl_map.ravel())

    full = np.concatenate(kl_vals)
    vmin, vmax = 0, np.percentile(full, 99)

    frames = []
    for t, agents in enumerate(state_log):
        agent = agents[agent_index]
        q = agent.q
        p = agent.p
        mask = agent.mask
        kl_map = np.zeros_like(mask, dtype=np.float32)

        for x in range(q.shape[0]):
            for y in range(q.shape[1]):
                if mask[x, y] > 0:
                    kl_map[x, y] = kl_divergence(q[x, y], p[x, y]) * mask[x, y]

        fig, ax = plt.subplots(figsize=(5, 5))
        im = ax.imshow(kl_map, cmap='inferno', vmin=vmin, vmax=vmax)
        ax.set_title(f"KL(q‖p) (Step {t})")
        plt.colorbar(im, ax=ax)
        fig.canvas.draw()

        frame = np.asarray(fig.canvas.buffer_rgba())
        frames.append(frame)
        plt.close()

    gif_path = os.path.join("animations", f"kl_divergence_agent{agent_index}.gif")
    imageio.mimsave(gif_path, frames, fps=10)
    return gif_path


def animate_gauge_curvature(state_log, agent_index=0):
    os.makedirs("animations", exist_ok=True)

    # Compute global color scale
    curv_vals = []
    for agents in state_log:
        phi = agents[agent_index].phi
        mask = agents[agent_index].mask
        curvature = compute_field_strength(phi) * mask
        curv_vals.append(curvature.ravel())
    full = np.concatenate(curv_vals)
    vmin, vmax = 0, np.percentile(full, 99)

    frames = []
    for t, agents in enumerate(state_log):
        phi = agents[agent_index].phi
        mask = agents[agent_index].mask
        curvature = compute_field_strength(phi) * mask

        fig, ax = plt.subplots(figsize=(5, 5))
        im = ax.imshow(curvature, cmap='hot', vmin=vmin, vmax=vmax)
        ax.set_title(f"Gauge Curvature ∥F∥² (Step {t})")
        plt.colorbar(im, ax=ax)
        fig.canvas.draw()

        frame = np.asarray(fig.canvas.buffer_rgba())
        frames.append(frame)
        plt.close()

    gif_path = os.path.join("animations", f"curvature_agent{agent_index}.gif")
    imageio.mimsave(gif_path, frames, fps=10)
    return gif_path


def animate_q_distribution(state_log, agent_index=0, k_idx=None):
    os.makedirs("animations", exist_ok=True)

    if k_idx is None:
        K = state_log[0][agent_index].q.shape[-1]
        k_idx = K // 2

    # Compute global color scale
    q_vals = []
    for agents in state_log:
        q_k = agents[agent_index].q[..., k_idx]
        mask = agents[agent_index].mask
        q_vals.append((q_k * mask).ravel())
    full = np.concatenate(q_vals)
    vmin, vmax = 0, np.percentile(full, 99)

    frames = []
    for t, agents in enumerate(state_log):
        q = agents[agent_index].q[..., k_idx]
        mask = agents[agent_index].mask
        q_slice = q * mask

        fig, ax = plt.subplots(figsize=(5, 5))
        im = ax.imshow(q_slice, cmap='viridis', vmin=vmin, vmax=vmax)
        ax.set_title(f"q[..., {k_idx}] (Step {t})")
        plt.colorbar(im, ax=ax)
        fig.canvas.draw()

        frame = np.asarray(fig.canvas.buffer_rgba())
        frames.append(frame)
        plt.close()

    gif_path = os.path.join("animations", f"q_k{k_idx}_agent{agent_index}.gif")
    imageio.mimsave(gif_path, frames, fps=10)
    return gif_path

if __name__ == "__main__":
    import pickle
    import os
    import glob

    

    os.makedirs("animations", exist_ok=True)

    # Load individual step files instead of state_log.pkl
    step_files = sorted(glob.glob("checkpoints/step_*.pkl"))
    state_log = []
    for fpath in step_files:
        try:
            with open(fpath, "rb") as f:
                state_log.append(pickle.load(f))
        except Exception as e:
            print(f"[WARNING] Skipping {fpath} due to error: {e}")

    if not state_log:
        print("[ERROR] No valid step files found in checkpoints/")
        exit(1)
    else:
        print(f"[INFO] Loaded {len(state_log)} steps from step_*.pkl files.")

    agent = 0

    try:
        with open("checkpoints/energy_log.pkl", "rb") as f:
            energy_log = pickle.load(f)
        print("[INFO] Plotting energy log...")
        plot_energy_log(energy_log)
    except FileNotFoundError:
        print("[WARNING] Skipping energy log — checkpoints/energy_log.pkl not found")

    print(f"[INFO] Running animations for agent {agent}...")
    #animate_mu_sigma_fields(state_log, agent)
    animate_phi_norm(state_log, agent)
    #animate_kl_divergence(state_log, agent)
    animate_gauge_curvature(state_log, agent)
    #animate_q_distribution(state_log, agent)
