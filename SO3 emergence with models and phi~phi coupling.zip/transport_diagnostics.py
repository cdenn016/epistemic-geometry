# transport_diagnostics.py

import os
import pickle
import numpy as np
import matplotlib.pyplot as plt

from omega_operator import compute_so3_curvature, apply_omega
from transport_operator import compute_path_operator, compute_full_transport_operator
from analyze_transport_log import find_latest_log
from agent_schema import Agent  # NEW
from config import domain_size


# === 1. Curvature Field Visualization ===
def plot_phi_curvature(agent: Agent, save_path=None):
    phi = agent.phi
    curvature = compute_so3_curvature(phi)

    plt.figure(figsize=(6, 5))
    plt.imshow(curvature, cmap='magma')
    plt.colorbar(label=r"$\|F_{xy}\|$")
    plt.title(f"SO(3) Curvature ‖Fₓᵧ‖ — Agent {agent.id}")
    plt.tight_layout()
    if save_path:
        plt.savefig(save_path)
    plt.show()


# === 2. φ-Field Quiver Visualization ===
def plot_phi_quiver(agent: Agent):
    phi = agent.phi
    H, W, _ = phi.shape
    X, Y = np.meshgrid(np.arange(W), np.arange(H))
    u, v = phi[..., 0], phi[..., 1]

    plt.figure(figsize=(6, 6))
    plt.quiver(X, Y, u, v, angles='xy', scale_units='xy', scale=1, color='cyan')
    plt.title(f"φ Field Vector Flow — Agent {agent.id}")
    plt.gca().invert_yaxis()
    plt.axis('equal')
    plt.tight_layout()
    plt.show()


# === 3. Transport Around Loop Diagnostic ===
def split_loop_by_agent_segments(loop_path, agent_path, log, agents):
    segments = []
    overlaps = []

    forward_agents = agent_path
    backward_agents = agent_path[::-1][1:]
    full_agent_path = forward_agents + backward_agents

    N = len(full_agent_path)
    L = len(loop_path)
    assert L >= N, "Loop path must be at least as long as agent path."

    path_per_agent = L // N
    remainder = L % N

    start = 0
    for i in range(N):
        seg_len = path_per_agent + (1 if i < remainder else 0)
        end = start + seg_len
        segments.append(loop_path[start:end])
        start = end

    for i in range(N - 1):
        c = loop_path[path_per_agent * (i + 1)]
        overlaps.append((c, c))

    return segments, overlaps, full_agent_path


# === 4. Visualize Transport Operator ===
def plot_operator_matrix(Omega, title="Transport Operator Ω"):
    plt.figure(figsize=(6, 5))
    plt.imshow(Omega, cmap='seismic', vmin=-1, vmax=1)
    plt.colorbar()
    plt.title(title)
    plt.tight_layout()
    plt.show()


# === 5. SVD and Eigendecomposition ===
def analyze_operator_spectrum(Omega):
    print("[SVD] ‖Ω‖_F =", np.linalg.norm(Omega, ord='fro'))
    U, S, Vh = np.linalg.svd(Omega)
    print("[SVD] Singular values:", np.round(S, 4))

    eigvals = np.linalg.eigvals(Omega)
    print("[Eig] Eigenvalues:", np.round(eigvals, 4))

    plt.figure()
    plt.scatter(eigvals.real, eigvals.imag, c='orange')
    plt.axhline(0, color='gray')
    plt.axvline(0, color='gray')
    plt.title("Eigenvalues of Ω in Complex Plane")
    plt.xlabel("Re(λ)")
    plt.ylabel("Im(λ)")
    plt.grid(True)
    plt.axis('equal')
    plt.tight_layout()
    plt.show()


# === MAIN ===
def compute_loop_from_transport(log):
    full_path = log["full_path"]
    if len(full_path) < 2:
        raise ValueError("Transport path too short for loop.")
    forward = full_path
    backward = list(reversed(full_path))
    return forward + backward[1:]

def main():
    log_path = find_latest_log()
    if not log_path:
        print("[ERROR] No transport log found.")
        return

    with open(log_path, "rb") as f:
        log = pickle.load(f)

    step_dir = os.path.dirname(log_path)
    step_file = os.path.join(step_dir, "agents_before.pkl")
    if not os.path.exists(step_file):
        print("[ERROR] agents_before.pkl not found in:", step_dir)
        return

    with open(step_file, "rb") as f:
        raw_agents = pickle.load(f)
        agents = [Agent.from_dict(a) if isinstance(a, dict) else a for a in raw_agents]

    agent_path = log["path_indices"]
    A = agents[agent_path[0]]
    B = agents[agent_path[-1]]
    print("[INFO] Running diagnostics on path:", agent_path)

    # 1. Curvature
    plot_phi_curvature(A)
    plot_phi_curvature(B)

    # 2. φ Quiver
    plot_phi_quiver(A)
    plot_phi_quiver(B)

    # 3. Loop Path
    loop_path = compute_loop_from_transport(log)
    segments, overlaps, full_agent_path = split_loop_by_agent_segments(loop_path, agent_path, log, agents)

    path_agents = [agents[i] for i in full_agent_path]
    Omega_loop, _ = compute_full_transport_operator(path_agents, segments, overlaps, domain_size)

    q0 = agents[full_agent_path[0]].q[log["c_start"]].copy()
    qT = apply_omega(q0, Omega_loop)
    kl_err = np.sum(q0 * (np.log(np.clip(q0, 1e-8, 1)) - np.log(np.clip(qT, 1e-8, 1))))
    print(f"[Loop Transport] KL(q || Ω·q) around composite loop: {kl_err:.4e}")

    plot_operator_matrix(Omega_loop, title="Ω_loop from full transport path")
    analyze_operator_spectrum(Omega_loop)

if __name__ == "__main__":
    main()
