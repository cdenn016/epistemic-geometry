# chain_transport.py

import numpy as np
import networkx as nx
from scipy.ndimage import gaussian_filter
from agent_schema import Agent  # NEW

def build_overlap_graph(agents: list[Agent], eps=1e-8):
    import networkx as nx
    G = nx.Graph()
    for i, agent_i in enumerate(agents):
        mask_i = agent_i.mask
        G.add_node(i)
        for j, agent_j in enumerate(agents):
            if i >= j:
                continue
            mask_j = agent_j.mask
            overlap = (mask_i * mask_j) > eps
            if np.any(overlap):
                num_overlap = np.sum(overlap)
                print(f"[GRAPH] Agent {i} ↔ Agent {j} has {num_overlap} overlap points")
                G.add_edge(i, j)
    return G

def find_agent_chain(graph, source, target, min_length=None, exact_length=None, max_paths=10):
    """
    Finds a simple path between source and target agents with optional length constraints.
    Returns the first valid path found (shortest or matching length), or None if no valid path.

    Args:
        graph         : NetworkX graph built from agent overlaps
        source        : agent index (start)
        target        : agent index (end)
        min_length    : minimum path length (inclusive)
        exact_length  : exact path length required
        max_paths     : optional cap to avoid long enumeration

    Returns:
        List of agent indices [i0, i1, ..., in] if valid path is found; else None.
    """
    import networkx as nx

    try:
        all_paths = list(nx.all_simple_paths(graph, source=source, target=target, cutoff=10))
        count = 0
        for path in all_paths:
            count += 1
            if exact_length and len(path) != exact_length:
                continue
            if min_length and len(path) < min_length:
                continue
            return path
            if count >= max_paths:
                break
        return None
    except nx.NetworkXNoPath:
        return None


def find_agent_path(graph, source, target):
    try:
        return nx.shortest_path(graph, source=source, target=target)
    except nx.NetworkXNoPath:
        return None

def visualize_path_on_graph(G, path, save_path=None):
    import matplotlib.pyplot as plt
    pos = nx.spring_layout(G, seed=42)
    plt.figure(figsize=(6, 6))
    nx.draw(G, pos, node_color='lightblue', with_labels=True, edge_color='gray')
    if path:
        path_edges = list(zip(path[:-1], path[1:]))
        nx.draw_networkx_edges(G, pos, edgelist=path_edges, edge_color='red', width=2)
    if save_path:
        plt.savefig(save_path)
    plt.title("Path Through Overlap Graph")
    plt.tight_layout()
    plt.show()

def find_transport_path(G, source_id, target_id):
    if not nx.has_path(G, source_id, target_id):
        raise ValueError(f"No path from agent {source_id} to agent {target_id}.")
    return nx.shortest_path(G, source=source_id, target=target_id)

def get_overlap_centroid(agent_i: Agent, agent_j: Agent, threshold=0.01):
    overlap = (agent_i.mask > threshold) & (agent_j.mask > threshold)
    coords = np.argwhere(overlap)
    if coords.shape[0] == 0:
        overlap = (agent_i.mask > threshold / 10) & (agent_j.mask > threshold / 10)
        coords = np.argwhere(overlap)
    if coords.shape[0] == 0:
        return None
    return tuple(coords[len(coords) // 2])

def build_routed_centroids(agents: list[Agent], path):
    centroids = []
    for i in range(len(path) - 1):
        a = agents[path[i]]
        b = agents[path[i + 1]]
        centroid = get_overlap_centroid(a, b)
        if centroid is None:
            raise ValueError(f"No overlap between agents {path[i]} and {path[i+1]}")
        centroids.append(centroid)
    return centroids
