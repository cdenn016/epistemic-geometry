# sweep_alignment_plotter.py

import os
import pickle
import matplotlib.pyplot as plt
from glob import glob
import imageio
import numpy as np
from scipy.optimize import curve_fit
import csv

def exp_decay(t, A, r, C):
    return A * np.exp(-r * t) + C

def plot_alignment_sweep(param_name="phi_init", sweep_root="sweeps_phi_init", out_prefix="phi"):
    folders = sorted(glob(os.path.join(sweep_root, "*/")))
    frames_dir = f"alignment_static_frames_{param_name}"
    os.makedirs(frames_dir, exist_ok=True)

    frame_paths = []
    param_vals = []
    all_errors = []
    log_data = []
    rate_results = []

    # --- First pass: gather logs and collect error range ---
    for folder in folders:
        path = os.path.join(folder, "alignment_log.pkl")
        if not os.path.isfile(path):
            print(f"[SKIP] No alignment_log.pkl in {folder}")
            continue
        try:
            with open(path, "rb") as f:
                log = pickle.load(f)
            if len(log) == 0:
                print(f"[SKIP] Empty log in {folder}")
                continue
            steps, errors = zip(*log)
            val = float(os.path.basename(os.path.normpath(folder)).split("_")[-1])
            param_vals.append(val)
            all_errors.extend(errors)
            log_data.append((val, np.array(steps), np.array(errors)))
        except Exception as e:
            print(f"[ERROR] {folder}: {e}")

    if not log_data:
        raise RuntimeError("No alignment logs found.")

    global_ymax = max(all_errors) * 1.1

    # --- Second pass: fit and plot ---
    for val, steps, errors in sorted(log_data):
        try:
            popt, _ = curve_fit(exp_decay, steps, errors, p0=(errors[0], 0.01, min(errors)))
            A_fit, r_fit, C_fit = popt
        except Exception as e:
            print(f"[WARN] Fit failed for {param_name}={val:.4f}: {e}")
            A_fit = r_fit = C_fit = np.nan

        rate_results.append((val, A_fit, r_fit, C_fit))

        # Plot
        plt.figure(figsize=(6, 4))
        plt.plot(steps, errors, label="Alignment Error", color="black")
        if not np.isnan(r_fit):
            fit_vals = exp_decay(steps, *popt)
            plt.plot(steps, fit_vals, '--', color='red',
                     label=f"Exp Fit: A={A_fit:.3f}, r={r_fit:.3f}, C={C_fit:.3f}")
        plt.xlabel("Step")
        plt.ylabel("Alignment Error")
        plt.title(f"Alignment vs Step — {param_name} = {val:.4f}")
        plt.grid(True)
        plt.ylim(0, global_ymax)
        plt.legend()
        plt.tight_layout()

        frame_path = os.path.join(frames_dir, f"frame_{out_prefix}_{val:.4f}.png")
        plt.savefig(frame_path)
        frame_paths.append((val, frame_path))
        plt.close()

    # --- Write CSV ---
    csv_name = f"{out_prefix}_alignment_rates.csv"
    with open(csv_name, "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow([param_name, "A", "r", "C"])
        writer.writerows(rate_results)
    print(f"[DONE] Saved fit results to {csv_name}")

    # --- Generate GIF ---
    output_gif = f"alignment_static_{out_prefix}_sweep.gif"
    images = [imageio.imread(p) for _, p in sorted(frame_paths, key=lambda x: x[0])]
    imageio.mimsave(output_gif, images, fps=2)
    print(f"[DONE] Saved animation with {len(images)} frames to {output_gif}")

    
######CHOOSE PARAMETER BELOW##########


if __name__ == "__main__":
    plot_alignment_sweep(param_name="phi_init", sweep_root="sweeps_phi_init", out_prefix="phi")
