
import os
import pickle
import hashlib


def hash_q(agent):
    """
    Hash the belief field q to detect changes or identify duplicates.
    """
    return hashlib.sha256(agent.q.tobytes()).hexdigest()

import csv

import csv

def save_metrics_csv(metrics_list, filepath):
    """
    Save a list of metric dictionaries to a CSV file.
    Each entry in metrics_list should be a dict with consistent keys.
    """
    if not metrics_list:
        print("[WARNING] No metrics to save.")
        return

    fieldnames = list(metrics_list[0].keys())

    # Ensure UTF-8 encoding to handle Unicode characters (e.g., Ω, φ)
    with open(filepath, mode="w", newline="", encoding="utf-8") as csvfile:
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(metrics_list)

def save_step(agents, outdir, step):
    """
    Save agent state to step_{step:04d}.pkl and update checkpoint.pkl
    """
    os.makedirs(outdir, exist_ok=True)
    step_path = os.path.join(outdir, f"step_{step:04d}.pkl")
    ckpt_path = os.path.join(outdir, "checkpoint.pkl")
    with open(step_path, "wb") as f:
        pickle.dump(agents, f)
    with open(ckpt_path, "wb") as f:
        pickle.dump(agents, f)


def load_checkpoint(outdir):
    """
    Try to load the latest checkpoint.pkl or most recent step_XXXX.pkl
    """
    ckpt_path = os.path.join(outdir, "checkpoint.pkl")
    if os.path.exists(ckpt_path):
        with open(ckpt_path, "rb") as f:
            agents = pickle.load(f)
        return agents, "checkpoint.pkl"

    # fallback to latest step file
    step_files = sorted([
        f for f in os.listdir(outdir)
        if f.startswith("step_") and f.endswith(".pkl")
    ])
    if not step_files:
        return None, None

    last_step = step_files[-1]
    with open(os.path.join(outdir, last_step), "rb") as f:
        agents = pickle.load(f)
    return agents, last_step


def find_resume_step(outdir):
    """
    Determine which step to resume from based on saved step files.
    """
    step_files = sorted([
        f for f in os.listdir(outdir)
        if f.startswith("step_") and f.endswith(".pkl")
    ])
    if not step_files:
        return 0

    last_step = step_files[-1]
    return int(last_step.replace("step_", "").replace(".pkl", "")) + 1


def load_all_steps(outdir):
    """
    Load all step files as a list of agent states.
    """
    step_files = sorted([
        f for f in os.listdir(outdir)
        if f.startswith("step_") and f.endswith(".pkl")
    ])
    state_log = []
    for fname in step_files:
        with open(os.path.join(outdir, fname), "rb") as f:
            agents = pickle.load(f)
        state_log.append(agents)
    return state_log

import os
import pickle
import re


def list_step_files(run_path):
    """Returns sorted list of (step_number, filepath) tuples."""
    step_files = []
    for fname in os.listdir(run_path):
        match = re.match(r"step_(\d+)\.pkl", fname)
        if match:
            step_num = int(match.group(1))
            step_files.append((step_num, os.path.join(run_path, fname)))
    return sorted(step_files)


def load_final_step(run_path):
    """Loads the final step_*.pkl from a run directory."""
    step_files = list_step_files(run_path)
    if not step_files:
        return None
    last_step_num, last_file = step_files[-1]
    with open(last_file, "rb") as f:
        return pickle.load(f)





