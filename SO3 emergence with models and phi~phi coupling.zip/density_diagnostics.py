# -*- coding: utf-8 -*-
"""
Created on Thu Jun 12 21:07:17 2025

@author: chris and christine
"""

import numpy as np
import matplotlib.pyplot as plt
import os

def compute_agent_density(agent_masks):
    """
    Computes the spatial density of agents across the base space.

    Parameters:
    - agent_masks: np.ndarray of shape (N, H, W), where each [i, :, :] is agent i's soft mask χ_i(c)

    Returns:
    - density_map: np.ndarray of shape (H, W), summing all agent masks at each point
    - mean_density: float, average number of agents overlapping each point
    """
    density_map = np.sum(agent_masks, axis=0)
    mean_density = np.mean(density_map)
    return density_map, mean_density

def plot_density_map(density_map, outdir="diagnostics", filename="agent_density_map.png"):
    """
    Saves a heatmap of the agent density map.

    Parameters:
    - density_map: np.ndarray of shape (H, W)
    """
    os.makedirs(outdir, exist_ok=True)
    plt.figure(figsize=(6, 5))
    plt.imshow(density_map, cmap="viridis")
    plt.colorbar(label="Agent Overlap Count")
    plt.title("Spatial Agent Density Map")
    plt.xlabel("x")
    plt.ylabel("y")
    plt.tight_layout()
    plt.savefig(os.path.join(outdir, filename))
    plt.close()

def summarize_density(density_map):
    """
    Prints a summary of agent density statistics.

    Parameters:
    - density_map: np.ndarray of shape (H, W)
    """
    print("[DENSITY SUMMARY]")
    print(f"Mean overlap per point: {np.mean(density_map):.2f}")
    print(f"Max overlap: {np.max(density_map)}")
    print(f"Min overlap: {np.min(density_map)}")
    print(f"Std dev: {np.std(density_map):.2f}")

def run_density_diagnostics(agents, outdir="diagnostics"):
    """
    High-level wrapper to compute, plot, and summarize agent density from a list of Agent objects.

    Parameters:
    - agents: list of Agent objects (must have .mask attribute)
    - outdir: directory to save plots
    """
    agent_masks = np.array([agent.mask for agent in agents])
    density_map, mean_density = compute_agent_density(agent_masks)
    summarize_density(density_map)
    plot_density_map(density_map, outdir=outdir)
    return density_map, mean_density
