# -*- coding: utf-8 -*-
"""
Created on Sat Jun  7 12:05:38 2025

@author: chris and christine
"""

import os
import numpy as np
import matplotlib.pyplot as plt
import imageio
from numpy.linalg import eigvalsh
from config import log_eps
from sklearn.decomposition import PCA
from scipy.ndimage import gaussian_filter


os.makedirs("animations", exist_ok=True)

# Set manually to a valid point within an agent’s support
inspect_point = (20, 50)

def sanitize_q(q):
    q = np.clip(q, log_eps, 1.0)
    q /= np.sum(q, axis=-1, keepdims=True) + log_eps
    return q

def compute_fisher_metric_tensor(q):
    q = sanitize_q(q)
    log_q = np.log(q)
    dq_dx = np.gradient(log_q, axis=0)
    dq_dy = np.gradient(log_q, axis=1)
    g_xx = np.sum(dq_dx**2, axis=-1)
    g_yy = np.sum(dq_dy**2, axis=-1)
    g_xy = np.sum(dq_dx * dq_dy, axis=-1)
    return g_xx, g_yy, g_xy

def animate_fisher_eigenvalue_fields(state_log, agent_index=0):
    lambda_max_all = []

    for agents in state_log:
        agent = agents[agent_index]
        q = sanitize_q(agent.q)
        g_xx, g_yy, g_xy = compute_fisher_metric_tensor(q)
        H, W = q.shape[:2]
        λmax = np.zeros((H, W))
        for i in range(H):
            for j in range(W):
                G = np.array([[g_xx[i, j], g_xy[i, j]], [g_xy[i, j], g_yy[i, j]]])
                eigvals = eigvalsh(G)
                λmax[i, j] = eigvals[1]  # largest eigenvalue
        lambda_max_all.append(λmax)

    all_vals = np.concatenate([f.ravel() for f in lambda_max_all if np.isfinite(f).any()])
    vmin, vmax = 0, np.percentile(all_vals, 99)

    frames = []
    for t, agents in enumerate(state_log):
        agent = agents[agent_index]
        mask = agent.mask
        λmax = lambda_max_all[t]
        eigval_field = λmax * mask
        eigval_field[mask < 0.1] = np.nan

        fig, ax = plt.subplots(figsize=(5, 5))
        im = ax.imshow(eigval_field, cmap='viridis', vmin=vmin, vmax=vmax)
        ax.set_title(f"Max Eigenvalue of g (Step {t})")
        plt.colorbar(im, ax=ax)
        fig.canvas.draw()

        frame = np.asarray(fig.canvas.buffer_rgba())
        frames.append(frame)
        plt.close()

    gif_path = f"animations/fisher_eigen_agent{agent_index}.gif"
    imageio.mimsave(gif_path, frames, fps=10)
    return gif_path

def animate_fisher_vector_field(state_log, agent_index=0, step_interval=5):
    for t in range(0, len(state_log), step_interval):
        q = state_log[t][agent_index].q
        mask = state_log[t][agent_index].mask
        q = sanitize_q(q)
        log_q = np.log(q)

        dq_dx = np.gradient(log_q, axis=0)
        dq_dy = np.gradient(log_q, axis=1)
        U = np.sum(dq_dx, axis=-1) * mask
        V = np.sum(dq_dy, axis=-1) * mask

        mag = np.sqrt(U**2 + V**2)
        scale = np.percentile(mag[mask > 0], 95)
        U /= (scale + log_eps)
        V /= (scale + log_eps)

        fig, ax = plt.subplots(figsize=(6, 6))
        ax.quiver(U[::5, ::5], V[::5, ::5], scale=20, pivot='mid', color='red')
        ax.set_title(f"Fisher Gradient Flow (Step {t})")
        fig.tight_layout()
        plt.savefig(f"animations/fisher_vector_step{t:03d}.png")
        plt.close()

def plot_belief_trajectory_at_point(state_log, agent_index=0, c=None):
    if c is None:
        c = inspect_point
    
    traj = []
    for agents in state_log:
        q = sanitize_q(agents[agent_index].q[c[0], c[1]])
        traj.append(q)
    traj = np.array(traj)

    pca = PCA(n_components=2)
    coords = pca.fit_transform(traj)

    plt.figure(figsize=(6, 6))
    plt.plot(coords[:, 0], coords[:, 1], marker='o', linewidth=1)
    plt.title(f"Belief Trajectory at c = {c}")
    plt.xlabel("PC1")
    plt.ylabel("PC2")
    plt.grid(True)
    path = f"animations/belief_trajectory_c{c[0]}_{c[1]}.png"
    plt.savefig(path)
    plt.close()
    return path


def plot_fisher_curvature_at_point(state_log, agent_index=0, c=None):
    if c is None:
        c = inspect_point

    curvature = []
    for agents in state_log:
        q = agents[agent_index].q
        g_xx, g_yy, g_xy = compute_fisher_metric_tensor(q)
        G = np.array([[g_xx[c], g_xy[c]], [g_xy[c], g_yy[c]]])
        eigvals = eigvalsh(G)
        curvature.append(np.sum(eigvals))

    plt.figure()
    plt.plot(curvature, label='Tr(g)')
    plt.title(f"Belief Space Curvature at c = {c}")
    plt.xlabel("Step")
    plt.ylabel("Tr(g)")
    plt.grid(True)
    plt.legend()
    path = f"animations/fisher_curvature_c{c[0]}_{c[1]}.png"
    plt.savefig(path)
    plt.close()
    return path


def animate_fisher_norm(state_log, agent_index=0):
    fisher_all = []
    for agents in state_log:
        q = sanitize_q(agents[agent_index].q)
        mask = agents[agent_index].mask
        log_q = np.log(q)
        grad_log_q = np.gradient(log_q, axis=(0, 1))
        fisher = np.sum(grad_log_q[0]**2 + grad_log_q[1]**2, axis=-1) * mask
        fisher_all.append(gaussian_filter(fisher, sigma=1.0))

    all_vals = np.concatenate([f.ravel() for f in fisher_all])
    vmin, vmax = 0, np.percentile(all_vals, 99)

    frames = []
    for t, fisher in enumerate(fisher_all):
        fig, ax = plt.subplots(figsize=(5, 5))
        im = ax.imshow(fisher, cmap='viridis', vmin=vmin, vmax=vmax)
        ax.set_title(f"Fisher Metric Norm (Step {t})")
        plt.colorbar(im, ax=ax)
        fig.canvas.draw()
        frames.append(np.asarray(fig.canvas.buffer_rgba()))
        plt.close()

    gif_path = f"animations/fisher_norm_agent{agent_index}.gif"
    imageio.mimsave(gif_path, frames, fps=10)
    return gif_path


def animate_fisher_velocity(state_log, agent_index=0):
    v_all = []
    for t in range(1, len(state_log)):
        q_prev = sanitize_q(state_log[t - 1][agent_index].q)
        q_next = sanitize_q(state_log[t][agent_index].q)
        mask = state_log[t][agent_index].mask

        v = np.log(q_next) - np.log(q_prev)
        v_norm = np.sum(v**2, axis=-1) * mask
        v_all.append(v_norm)

    all_vals = np.concatenate([v.ravel() for v in v_all])
    vmin, vmax = 0, np.percentile(all_vals, 99)

    frames = []
    for t, v_norm in enumerate(v_all):
        fig, ax = plt.subplots(figsize=(5, 5))
        im = ax.imshow(v_norm, cmap='plasma', vmin=vmin, vmax=vmax)
        ax.set_title(f"Fisher Velocity Norm (Step {t + 1})")
        plt.colorbar(im, ax=ax)
        fig.canvas.draw()
        frames.append(np.asarray(fig.canvas.buffer_rgba()))
        plt.close()

    gif_path = f"animations/fisher_velocity_agent{agent_index}.gif"
    imageio.mimsave(gif_path, frames, fps=10)
    return gif_path


if __name__ == "__main__":
    import pickle
    import glob

    step_files = sorted(glob.glob("checkpoints/step_*.pkl"))
    state_log = []
    for fpath in step_files:
        with open(fpath, "rb") as f:
            state_log.append(pickle.load(f))
    print(f"[INFO] Loaded {len(state_log)} steps from checkpoint folder.")

    agent = 0
    animate_fisher_norm(state_log, agent)
    animate_fisher_velocity(state_log, agent)
    animate_fisher_eigenvalue_fields(state_log, agent)
    animate_fisher_vector_field(state_log, agent)
    plot_belief_trajectory_at_point(state_log, agent)
    plot_fisher_curvature_at_point(state_log, agent)
