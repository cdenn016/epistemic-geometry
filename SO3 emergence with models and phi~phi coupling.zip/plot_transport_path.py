

import os
import pickle
import numpy as np
import matplotlib.pyplot as plt
import re

def extract_step(foldername):
    import re
    match = re.search(r"step(\d+)", foldername)
    return int(match.group(1)) if match else -1

def load_latest_transport_log(parent_dir="transport_runs"):
    folders = sorted(os.listdir(parent_dir), key=extract_step)
    for folder in reversed(folders):
        log_path = os.path.join(parent_dir, folder, "transport_log.pkl")
        agent_path = os.path.join(parent_dir, folder, "agents_before.pkl")
        if os.path.exists(log_path) and os.path.exists(agent_path):
            with open(log_path, "rb") as f:
                log = pickle.load(f)
            with open(agent_path, "rb") as f:
                agents = pickle.load(f)
            return agents, log
    raise FileNotFoundError("No transport logs found.")

def plot_transport_path(agents, log, outpath="transport_path.png"):
    H, W = agents[0].mask.shape
    fig, ax = plt.subplots(figsize=(8, 8))

    # --- Plot agent masks ---
    for i, agent in enumerate(agents):
        mask = agent.mask
        ax.imshow(mask, alpha=0.15, cmap='gray')
        y, x = agent.center
        ax.text(x, y, f"A{i}", color="blue", fontsize=10, ha="center", va="center")

    # --- Path and points ---
    path = log["full_path"]
    c_start = log["c_start"]
    c_final = log["c_final"]
    path = np.array(path)

    if len(path) > 0:
        ax.plot(path[:,1], path[:,0], color="orange", linewidth=2, label="Transport Path")

    ax.scatter(c_start[1], c_start[0], color="black", s=50, label="Start")
    ax.scatter(c_final[1], c_final[0], color="red", s=50, label="Final")

    # --- Optional: mark overlaps between agents ---
    if "path_indices" in log:
        overlap_pts = []
        for i in range(len(log["path_indices"]) - 1):
            a_i = agents[log["path_indices"][i]]
            a_j = agents[log["path_indices"][i+1]]
            overlap = a_i.mask * a_j.mask
            if np.any(overlap):
                yx = np.argwhere(overlap > 0.1)
                center = np.mean(yx, axis=0)
                overlap_pts.append(center)
        if overlap_pts:
            overlap_pts = np.array(overlap_pts)
            ax.scatter(overlap_pts[:,1], overlap_pts[:,0], s=30, c="white", edgecolor="k", label="Overlap Points")

    ax.set_title("Belief Transport Path and Agent Regions")
    ax.set_xlim(0, W)
    ax.set_ylim(H, 0)
    ax.set_aspect("equal")
    ax.legend()
    plt.tight_layout()
    plt.savefig(outpath)
    plt.show()
    print(f"[✓] Saved transport path visualization to {outpath}")

# ============================ MAIN ============================
if __name__ == "__main__":
    agents, log = load_latest_transport_log()
    plot_transport_path(agents, log)
