
import os
import pickle
import numpy as np
import matplotlib.pyplot as plt

from agent_schema import Agent  # Needed to unpickle agents
import config
from omega_operator import batch_exp_so3_irrep_approx, batch_apply_omega, repair_if_forgotten_batch
from so3_generators import get_generators

_, _, _, generators = get_generators(config.K)

def sanitize(dist, eps):
    dist = np.clip(dist, eps, 1.0)
    return dist / (np.sum(dist, axis=-1, keepdims=True) + eps)


def load_agents_at_step(checkpoint_dir, step):
    filename = os.path.join(checkpoint_dir, f"step_{step:04d}.pkl")
    if not os.path.exists(filename):
        print(f"[SKIP] File not found: {filename}")
        return None
    with open(filename, "rb") as f:
        agents = pickle.load(f)
    return agents


def compute_phi_model_norm(agent):
    phi = agent.phi_model
    mask = agent.mask
    norm = np.sqrt(np.sum(phi**2, axis=-1))
    avg_norm = np.sum(norm * mask) / (np.sum(mask) + 1e-8)
    return avg_norm


def compute_kl_model_alignment(agent_i, agents):
    p_i, phi_i, mask_i = agent_i.p, agent_i.phi_model, agent_i.mask
    kl_total = 0.0
    count = 0

    if not agent_i.neighbors:
        return 0.0

    for neighbor in agent_i.neighbors:
        agent_j = agents[neighbor["id"]]
        p_j, phi_j, mask_j = agent_j.p, agent_j.phi_model, agent_j.mask
        overlap = (mask_i * mask_j) > config.overlap_eps
        if not np.any(overlap):
            continue

        r_vecs = np.clip(phi_i[overlap] - phi_j[overlap], -10.0, 10.0)
        pj_vecs = p_j[overlap]
        pi_vecs = p_i[overlap]

        omega_batch = batch_exp_so3_irrep_approx(r_vecs, generators)
        pj_rot_batch = batch_apply_omega(pj_vecs, omega_batch)
        pj_rot_batch = repair_if_forgotten_batch(pj_rot_batch, eps=config.eps)

        pi_vecs = sanitize(pi_vecs, config.eps)
        pj_rot_batch = sanitize(pj_rot_batch, config.eps)

        kl = np.sum(pi_vecs * (np.log(pi_vecs) - np.log(pj_rot_batch)), axis=-1)
        kl_total += np.sum(kl)
        count += np.sum(overlap)

    return kl_total / (count + config.eps)



def plot_phi_model_and_kl(checkpoint_dir="checkpoints", max_steps=100):
    step_values = []
    phi_norms_per_agent = []
    kl_alignments_per_agent = []

    for step in range(max_steps):
        agents = load_agents_at_step(checkpoint_dir, step)
        if agents is None or not agents:
            continue

        norms = [compute_phi_model_norm(agent) for agent in agents]
        kls = [compute_kl_model_alignment(agent, agents) for agent in agents]

        step_values.append(step)
        phi_norms_per_agent.append(norms)
        kl_alignments_per_agent.append(kls)

        if step == 0:
            print(f"[DEBUG] Step 0 KL values: {kls}")

    if not phi_norms_per_agent:
        print("[ERROR] No data to plot.")
        return

    step_values = np.array(step_values)
    phi_norms = np.array(phi_norms_per_agent)
    kl_aligns = np.array(kl_alignments_per_agent)

    print(f"[DEBUG] KL shape: {kl_aligns.shape}, steps: {len(step_values)}")

    fig, axs = plt.subplots(2, 1, figsize=(10, 8), sharex=True)

    for i in range(phi_norms.shape[1]):
        axs[0].plot(step_values, phi_norms[:, i], label=f"Agent {i}")
    axs[0].set_ylabel("‖φ_model‖")
    axs[0].set_title("Model φ Norm Over Time")
    axs[0].legend()

    if kl_aligns.ndim == 2:
        for i in range(kl_aligns.shape[1]):
            axs[1].plot(step_values, kl_aligns[:, i], label=f"Agent {i}")
    else:
        axs[1].plot(step_values, kl_aligns, label="Avg KL (all agents)")

    axs[1].set_xlabel("Step")
    axs[1].set_ylabel("KL(pᵢ ‖ Ω̃ pⱼ)")
    axs[1].set_title("Model Alignment (KL Divergence) Over Time")
    axs[1].legend()

    plt.tight_layout()
    plt.show()


if __name__ == "__main__":
    plot_phi_model_and_kl(checkpoint_dir="checkpoints", max_steps=100)
