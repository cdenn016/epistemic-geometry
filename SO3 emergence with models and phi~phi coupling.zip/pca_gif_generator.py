# -*- coding: utf-8 -*-
"""
Created on Sun Jun  8 15:45:55 2025

@author: chris and christine
"""

# pca_gif_generator.py

import os
os.environ["OMP_NUM_THREADS"] = "1"
import glob
import pickle
import numpy as np
import matplotlib.pyplot as plt
from sklearn.decomposition import PCA
from sklearn.cluster import KMeans
from matplotlib.animation import FuncAnimation, PillowWriter


os.makedirs("animations", exist_ok=True)


def extract_features(agents):
    features = []
    for a in agents:
        valid = a.mask > 0.1
        if not np.any(valid):
            continue
        q_flat = a.q[valid].mean(axis=0)
        phi_flat = a.phi[valid].mean(axis=0)
        features.append(np.concatenate([q_flat, phi_flat]))
    if not features:
        return None
    return np.array(features)


def animate_meta_agent_embedding(state_log, n_components=2, n_clusters=5):
    fig, ax = plt.subplots(figsize=(6, 6))

    # --- Find valid step for PCA basis ---
    features0 = None
    for t, agents in enumerate(state_log):
        features0 = extract_features(agents)
        if features0 is not None:
            print(f"[INFO] Using step {t} as PCA basis")
            break

    if features0 is None or len(features0) == 0:
        print("[ERROR] No valid PCA basis found.")
        return

    pca = PCA(n_components=n_components)
    pca.fit(features0)

    # --- Determine fixed axis limits ---
    all_Z = []
    for t in range(len(state_log)):
        features = extract_features(state_log[t])
        if features is None or len(features) == 0:
            continue
        try:
            Z = pca.transform(features)
            all_Z.append(Z)
        except Exception as e:
            print(f"[SKIP] Frame {t} PCA error: {e}")

    if not all_Z:
        print("[ERROR] No valid PCA projections.")
        return

    all_Z = np.vstack(all_Z)
    x_min, x_max = all_Z[:, 0].min(), all_Z[:, 0].max()
    y_min, y_max = all_Z[:, 1].min(), all_Z[:, 1].max()

    ax.set_xlim(x_min, x_max)
    ax.set_ylim(y_min, y_max)
    ax.set_xlabel("PC1")
    ax.set_ylabel("PC2")
    ax.set_title("Meta-Agent Embedding")
    ax.grid(True)

    def update(frame):
    # Clear entire axes contents safely for all versions
        ax.cla()

        features = extract_features(state_log[frame])
        if features is None or len(features) == 0:
            print(f"[SKIP] No valid agents at frame {frame}")
            return

        try:
            Z = pca.transform(features)
            kmeans = KMeans(n_clusters=min(n_clusters, len(Z)), random_state=0).fit(Z)
            labels = kmeans.labels_

            for i, label in enumerate(labels):
                ax.scatter(Z[i, 0], Z[i, 1], c=f"C{label}", s=50, edgecolor='k')
                ax.text(Z[i, 0], Z[i, 1], str(i), fontsize=8, ha='center', va='center')

        # Restore consistent view and labels
            ax.set_xlim(x_min, x_max)
            ax.set_ylim(y_min, y_max)
            ax.set_xlabel("PC1")
            ax.set_ylabel("PC2")
            ax.set_title(f"Meta-Agent Embedding — Step {frame}")
            ax.grid(True)

        except Exception as e:
            print(f"[WARNING] Skipping frame {frame} due to: {e}")

    anim = FuncAnimation(fig, update, frames=len(state_log), interval=300)
    anim.save("animations/meta_agent_embedding.gif", dpi=120, writer=PillowWriter(fps=10))
    plt.close()
    print("[DONE] Saved animations/meta_agent_embedding.gif")


if __name__ == "__main__":
    step_files = sorted(glob.glob("checkpoints/step_*.pkl"))
    state_log = []
    for fpath in step_files:
        try:
            with open(fpath, "rb") as f:
                state_log.append(pickle.load(f))
        except Exception as e:
            print(f"[WARNING] Failed to load {fpath}: {e}")

    if not state_log:
        print("[ERROR] No valid step files found.")
    else:
        animate_meta_agent_embedding(state_log)
