# -*- coding: utf-8 -*-
"""
Created on Thu Jun 12 15:48:36 2025

@author: chris and christine
"""

import os
import pickle
import matplotlib.pyplot as plt
from diagnostics_metrics import compute_total_energy, compute_alignment_error
from io_utils import load_checkpoint

def list_all_steps(checkpoints_dir):
    return sorted([
        int(fname.split("_")[1].split(".")[0])
        for fname in os.listdir(checkpoints_dir)
        if fname.startswith("step_") and fname.endswith(".pkl")
    ])

def load_agents(step, checkpoints_dir):
    path = os.path.join(checkpoints_dir, f"step_{step:04d}.pkl")
    with open(path, "rb") as f:
        return pickle.load(f)

def collect_metrics(checkpoints_dir="checkpoints"):
    steps = list_all_steps(checkpoints_dir)
    alignment_log = []
    energy_log = []

    for step in steps:
        print(f"[LOADING] Step {step}")
        agents = load_agents(step, checkpoints_dir)
        alignment = compute_alignment_error(agents)
        energy = compute_total_energy(agents)

        alignment_log.append((step, alignment))
        energy_log.append((step, energy))

    return alignment_log, energy_log

def plot_alignment_over_time(alignment_log):
    steps, errs = zip(*alignment_log)
    plt.figure(figsize=(8, 4))
    plt.plot(steps, errs, label="Alignment Error", color="black")
    plt.xlabel("Step")
    plt.ylabel("KL(q || Ωq)")
    plt.title("Alignment Error Over Time")
    plt.grid(True)
    plt.tight_layout()
    plt.legend()
    plt.show()

def plot_energy_over_time(energy_log):
    steps = [step for step, _ in energy_log]
    keys = list(energy_log[0][1].keys())
    curves = {k: [e[k] for _, e in energy_log] for k in keys}

    plt.figure(figsize=(10, 6))
    for k in keys:
        plt.plot(steps, curves[k], label=k)
    plt.xlabel("Step")
    plt.ylabel("Energy")
    plt.title("Energy Components Over Time")
    plt.legend()
    plt.grid(True)
    plt.tight_layout()
    plt.show()

if __name__ == "__main__":
    alignment_log, energy_log = collect_metrics("checkpoints")
    plot_alignment_over_time(alignment_log)
    plot_energy_over_time(energy_log)
