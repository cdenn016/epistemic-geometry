import os
import numpy as np
import matplotlib.pyplot as plt
import imageio
from config import log_eps
from scipy.ndimage import laplace

os.makedirs("animations", exist_ok=True)

def clip_and_normalize_q(q, clip_floor=1e-6):  # <-- changed here
    q = np.clip(q, clip_floor, 1.0)
    q /= np.sum(q, axis=-1, keepdims=True) + clip_floor
    return q


def compute_entropy(q):
    q = clip_and_normalize_q(q)
    return -np.sum(q * np.log(q + log_eps), axis=-1)

def compute_center_and_variance(q, mask=None, clip_floor=1e-6):
    q = clip_and_normalize_q(q, clip_floor=clip_floor)
    K = q.shape[-1]
    x = np.arange(K)
    mu = np.sum(q * x, axis=-1)
    var = np.sum(q * (x - mu[..., None])**2, axis=-1)
    if mask is not None:
        mu[mask < 0.1] = 0.0
        var[mask < 0.1] = 0.0

    return mu, var


def animate_entropy(state_log, agent_index=0):
    entropies = []
    for agents in state_log:
        a = agents[agent_index]
        entropy = compute_entropy(a.q) * a.mask
        entropies.append(entropy)

    vmin = min(e.min() for e in entropies)
    vmax = max(e.max() for e in entropies)

    frames = []
    for t, entropy in enumerate(entropies):
        fig, ax = plt.subplots(figsize=(5, 5))
        im = ax.imshow(entropy, cmap='magma', vmin=vmin, vmax=vmax)
        ax.set_title(f"Entropy H[q] (Step {t})")
        plt.colorbar(im, ax=ax)
        fig.canvas.draw()
        frames.append(np.asarray(fig.canvas.buffer_rgba()))
        plt.close()

    gif_path = f"animations/entropy_agent{agent_index}.gif"
    imageio.mimsave(gif_path, frames, fps=10)
    return gif_path


def animate_mu_variance(state_log, agent_index=0):
    from matplotlib import pyplot as plt
    import numpy as np
    import imageio.v2 as imageio
    import os

    os.makedirs("animations", exist_ok=True)

    mu_frames, var_frames = [], []
    mu_all, var_all = [], []

    for agents in state_log:
        agent = agents[agent_index]
        q = agent.q
        mask = agent.mask
        mu, var = compute_center_and_variance(q, mask)
        mu_all.append(mu)
        var_all.append(var)

    mu_vmin, mu_vmax = np.min(mu_all), np.max(mu_all)
    var_vmin, var_vmax = np.min(var_all), np.max(var_all)

    for t, (mu, var) in enumerate(zip(mu_all, var_all)):
        for arr, frames, label, vmin, vmax in zip(
            [mu, var], [mu_frames, var_frames], ['μ_q', 'σ²_q'],
            [mu_vmin, var_vmin], [mu_vmax, var_vmax]
        ):
            fig, ax = plt.subplots(figsize=(5, 5))
            im = ax.imshow(arr, cmap='plasma', vmin=vmin, vmax=vmax)
            ax.set_title(f"{label} (Step {t})")
            plt.colorbar(im, ax=ax)
            fig.canvas.draw()
            frames.append(np.asarray(fig.canvas.buffer_rgba()))
            plt.close()

    mu_path = f"animations/mu_agent{agent_index}.gif"
    var_path = f"animations/var_agent{agent_index}.gif"
    imageio.mimsave(mu_path, mu_frames, fps=10)
    imageio.mimsave(var_path, var_frames, fps=10)
    return mu_path, var_path

def plot_total_energy_vs_time(energy_log):
    import matplotlib.pyplot as plt
    import os
    os.makedirs("animations", exist_ok=True)

    steps = [step for step, _ in energy_log]
    totals = [e["Total"] for _, e in energy_log]

    plt.figure()
    plt.plot(steps, totals)
    plt.xlabel("Step")
    plt.ylabel("Total Energy")
    plt.title("Total Energy Over Time")
    plt.grid(True)
    path = "animations/total_energy_time.png"
    plt.savefig(path)
    plt.close()
    return path


def compute_geodesic_length(state_log, agent_index=0, c=(23, 90)):
    from numpy import log, sum, sqrt, clip
    cx, cy = clip(c[0], 0, state_log[0][agent_index].q.shape[0] - 1), clip(c[1], 0, state_log[0][agent_index].q.shape[1] - 1)

    v_sq_sum = 0.0
    for t in range(1, len(state_log)):
        q_prev = clip_and_normalize_q(state_log[t - 1][agent_index].q[cx, cy])
        q_next = clip_and_normalize_q(state_log[t][agent_index].q[cx, cy])
        delta = log(q_next + log_eps) - log(q_prev + log_eps)
        v_sq = np.sum(delta**2)
        v_sq_sum += np.sqrt(v_sq)

    return v_sq_sum


def animate_laplacian_of_entropy(state_log, agent_index=0):
    frames = []
    lap_all = []
    for agents in state_log:
        q = agents[agent_index].q
        mask = agents[agent_index].mask
        entropy = compute_entropy(q) * mask
        lap_entropy = laplace(entropy)
        lap_entropy[mask < 0.1] = 0  # mask out invalid regions
        lap_all.append(lap_entropy)

    vmin = min(l.min() for l in lap_all)
    vmax = max(l.max() for l in lap_all)

    for t, lap_entropy in enumerate(lap_all):
        fig, ax = plt.subplots(figsize=(5, 5))
        im = ax.imshow(lap_entropy, cmap='seismic', vmin=vmin, vmax=vmax)
        ax.set_title(f"∇²H[q] (Step {t})")
        plt.colorbar(im, ax=ax)
        fig.canvas.draw()
        frames.append(np.asarray(fig.canvas.buffer_rgba()))
        plt.close()

    gif_path = f"animations/lap_entropy_agent{agent_index}.gif"
    imageio.mimsave(gif_path, frames, fps=10)
    return gif_path

if __name__ == "__main__":
    import pickle
    import glob

    step_files = sorted(glob.glob("checkpoints/step_*.pkl"))
    state_log = []
    for fpath in step_files:
        try:
            with open(fpath, "rb") as f:
                state_log.append(pickle.load(f))
        except Exception as e:
            print(f"[WARNING] Failed to load {fpath}: {e}")

    if not state_log:
        print("[ERROR] No valid step files found in checkpoints/")
        exit(1)
    else:
        print(f"[INFO] Loaded {len(state_log)} steps from checkpoint folder.")

    agent = 0
    animate_entropy(state_log, agent)
    animate_mu_variance(state_log, agent)
    compute_geodesic_length(state_log, agent, c=(23, 90))
    animate_laplacian_of_entropy(state_log, agent)

