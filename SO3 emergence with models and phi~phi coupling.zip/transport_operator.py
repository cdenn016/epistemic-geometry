# transport_operator.py

import numpy as np
from so3_generators import get_generators
from omega_operator import exp_so3_operator

from agent_schema import Agent  # NEW

def construct_spatial_path(c_from, c_to, domain_size, mask=None, eps=1e-3, allow_soft_pixels=True, soft_pixel_tolerance=2, verbose=False):
    """
    Computes a straight-line spatial path from c_from to c_to over a torus (with PBC).
    If a mask is provided, ensures the entire path lies within mask > eps.
    Optionally allows a few soft pixels below eps to tolerate numerical edge issues.
    """
    H, W = domain_size
    x0, y0 = c_from
    x1, y1 = c_to

    # Toroidal displacements
    dx = ((x1 - x0 + H // 2) % H) - H // 2
    dy = ((y1 - y0 + W // 2) % W) - W // 2

    steps = max(abs(dx), abs(dy))
    if steps == 0:
        return [c_from]

    path = []
    soft_pixel_count = 0

    for i in range(steps + 1):
        x = int(round((x0 + dx * i / steps))) % H
        y = int(round((y0 + dy * i / steps))) % W

        if mask is not None:
            value = mask[x, y]
            if value <= eps:
                soft_pixel_count += 1
                if not allow_soft_pixels or soft_pixel_count > soft_pixel_tolerance:
                    if verbose:
                        print(f"[FAIL] Path aborted at {(x, y)}: mask={value:.3e} (soft_pixel_count={soft_pixel_count})")
                    return []
        path.append((x, y))

    if verbose and soft_pixel_count > 0:
        print(f"[WARN] Used {soft_pixel_count} soft pixels in path from {c_from} to {c_to}")

    return path


def compute_base_transport_operator(path, K):
    return np.eye(K)

def apply_transport(q_B_at_cB, spatial_operator, omega_AB):
    transported = spatial_operator @ q_B_at_cB
    return omega_AB @ transported

def kl_divergence(q1, q2, eps=1e-12):
    q1 = np.clip(q1, eps, 1.0)
    q2 = np.clip(q2, eps, 1.0)
    return np.sum(q1 * (np.log(q1) - np.log(q2)))

def compute_connection_delta(phi_field, x0, x1, generators):
    """
    Computes the group-valued connection operator Ω_{x0 → x1} = exp(φ(x0)) · inv(exp(φ(x1)))
    """
    omega_x0 = exp_so3_operator(phi_field[x0], generators)
    omega_x1 = exp_so3_operator(phi_field[x1], generators)
    return omega_x0 @ np.linalg.inv(omega_x1)

def compute_path_operator(phi_field, path, generators):
    """
    Computes the cumulative SO(3) transport operator along a path using gauge-covariant group composition.
    """
    K = generators.shape[-1]
    omega = np.eye(K)
    for i in range(len(path) - 1):
        x0, x1 = path[i], path[i + 1]
        d_omega = compute_connection_delta(phi_field, x0, x1, generators)
        omega = d_omega @ omega
    return omega

def compute_full_transport_operator(agent_list: list[Agent], path_segments, overlap_points, domain_size):
    """
    Computes full SO(3) transport operator from source to destination agent.
    Accumulates intra-agent path operators and inter-agent jumps via group composition.
    
    Arguments:
        agent_list      : List of agents involved in transport path
        path_segments   : List of spatial paths (1 per agent)
        overlap_points  : List of (c_i, c_{i+1}) spatial handoff coordinates between agents
        domain_size     : (H, W) size of spatial domain

    Returns:
        omega_total     : Full composed SO(3) transport operator
        operator_steps  : List of tuples ('within', i, Ω_path) or ('jump', (i, i+1), Ω_jump)
    """
    K = agent_list[0].q.shape[-1]
    _, _, _, generators = get_generators(K)


    omega_total = np.eye(K)
    operator_steps = []

    for seg_idx in range(len(path_segments)):
        agent = agent_list[seg_idx]
        phi = agent.phi
        path = path_segments[seg_idx]

        # Intra-agent path transport
        omega_path = compute_path_operator(phi, path, generators)
        omega_total = omega_path @ omega_total
        operator_steps.append(('within', seg_idx, omega_path))

        # Inter-agent jump (if applicable)
        if seg_idx < len(overlap_points):
            c_a, c_b = overlap_points[seg_idx]
            phi_a = agent_list[seg_idx].phi[c_a]
            phi_b = agent_list[seg_idx + 1].phi[c_b]

            # Proper gauge-covariant jump: Ω = exp(φ_a) · inv(exp(φ_b))
            omega_a = exp_so3_operator(phi_a, generators)
            omega_b_inv = np.linalg.inv(exp_so3_operator(phi_b, generators))
            omega_jump = omega_a @ omega_b_inv

            omega_total = omega_jump @ omega_total
            operator_steps.append(('jump', (seg_idx, seg_idx + 1), omega_jump))

    return omega_total, operator_steps

