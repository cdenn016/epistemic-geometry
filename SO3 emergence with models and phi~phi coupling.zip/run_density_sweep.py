# -*- coding: utf-8 -*-
"""
Created on Thu Jun 12 21:09:04 2025

@author: chris and christine
"""

import numpy as np
import os
from agent_init_phi_smoothed import initialize_agents
from density_diagnostics import run_density_diagnostics
import config


def run_density_sweep(
    N_values=[20, 40, 60, 80, 100],
    radius_values=[4, 6, 8, 10],
    outdir="density_sweep"
):
    """
    Runs a sweep over agent count (N) and support radius, logging density statistics.

    Parameters:
    - N_values: list of agent counts to try
    - radius_values: list of radii to try
    - outdir: base directory to save all outputs
    """
    os.makedirs(outdir, exist_ok=True)
    results = []

    for N in N_values:
        for radius in radius_values:
            print(f"\n[RUN] N={N}, radius={radius}")
            # Override config for controlled initialization
            config.N = N
            config.agent_radius_range = (radius, radius)
            config.agent_seed = 42  # fixed seed for reproducibility

            agents = initialize_agents()
            tag = f"N{N}_R{radius}"
            run_density_diagnostics(agents, outdir=os.path.join(outdir, tag))

            # Collect mean density
            masks = np.array([a.mask for a in agents])
            density_map = np.sum(masks, axis=0)
            mean_density = np.mean(density_map)
            std_density = np.std(density_map)
            results.append((N, radius, mean_density, std_density))

    return results


if __name__ == "__main__":
    sweep_results = run_density_sweep()
    print("\n[DONE] Sweep complete. Results:")
    for N, r, mean, std in sweep_results:
        print(f"N={N:3d}, radius={r:2d} -> mean density={mean:.2f}, std={std:.2f}")
