# lhs_sweep.py

import numpy as np
import os
import time
import pickle
from run_simulation_parallel import run_simulation
from io_utils import save_metrics_csv
from config import set_config_from_params
from diagnostics_metrics import log_all_metrics


# --- LHS Parameter Ranges (editable) ---
param_ranges = {
    "alpha": (0.1, 1000),
    "beta": (0.1, 1000),
    "gamma": (0.1, 1000),
    "gauge_weight": (10, 10000),
    "phi_init": (0, 0.3),
    "phi_model_init": (0.0, 0.3),
    "model_align_weight": (0.1, 1000),
    }


n_samples = 50
steps_per_run = 100
outdir_base = "lhs_runs"
os.makedirs(outdir_base, exist_ok=True)


def generate_lhs_samples(param_ranges, n_samples):
    from scipy.stats.qmc import LatinHypercube
    keys = list(param_ranges.keys())
    bounds = np.array([param_ranges[k] for k in keys])
    sampler = LatinHypercube(d=len(keys))
    unit_samples = sampler.random(n=n_samples)
    scaled_samples = bounds[:, 0] + unit_samples * (bounds[:, 1] - bounds[:, 0])
    scaled_samples = np.round(scaled_samples, 4)
    return [dict(zip(keys, vals)) for vals in scaled_samples]


def run_lhs_sim(index, param_set):
    tag = f"run_{index:03d}"
    run_dir = os.path.join(outdir_base, tag)
    metrics_path = os.path.join(run_dir, "final_metrics.pkl")
    os.makedirs(run_dir, exist_ok=True)

    steps = param_set.get("steps", steps_per_run)
    final_step_path = os.path.join(run_dir, f"step_{steps - 1:04d}.pkl")

    print(f"[LHS {index}] Starting: {param_set}")
    start_time = time.time()

    try:
        # Save config for downstream plotters
        with open(os.path.join(run_dir, "params.pkl"), "wb") as f:
            pickle.dump(param_set, f)

        run_simulation(outdir=run_dir, resume=False, **param_set)

        if not os.path.exists(final_step_path):
            print(f"[LHS {index}] [ERROR] Missing final step file: {final_step_path}")
            return None

        with open(final_step_path, "rb") as f:
            agents = pickle.load(f)

        metrics = log_all_metrics(agents, step=steps - 1)
        metrics["run_id"] = index
        for k, v in param_set.items():
            metrics[k] = v

        with open(metrics_path, "wb") as f:
            pickle.dump(metrics, f)

        elapsed = time.time() - start_time
        print(f"[LHS {index}] Completed in {elapsed:.2f} seconds")
        return metrics

    except Exception as e:
        print(f"[LHS {index}] [EXCEPTION] {type(e).__name__}: {e}")
        return None


def run_lhs_batch():
    samples = generate_lhs_samples(param_ranges, n_samples)
    metrics_all = []

    for i, param_set in enumerate(samples):
        param_set["steps"] = steps_per_run
        set_config_from_params(param_set)
        metrics = run_lhs_sim(i, param_set)
        if metrics is not None:
            metrics_all.append(metrics)
        else:
            print(f"[LHS {i}] Skipped due to failure.")

    csv_path = os.path.join(outdir_base, "lhs_metrics.csv")
    save_metrics_csv(metrics_all, csv_path)
    print(f"[LHS DONE] Saved {len(metrics_all)} runs to: {csv_path}")


if __name__ == "__main__":
    run_lhs_batch()
