# -*- coding: utf-8 -*-
"""
Created on Thu Jun 12 21:09:17 2025

@author: chris and christine
"""

import numpy as np
import os
from run_simulation_parallel import run_simulation
from io_utils import load_all_steps
from diagnostics_metrics import log_all_metrics
from io_utils import save_metrics_csv

def run_criticality_sweep(
    N_values=[20, 40, 60],
    radius_values=[4, 6, 8],
    beta_values=[0.1, 0.3, 0.6, 1.0],
    steps=50,
    base_outdir="criticality_sweep"
):
    """
    Sweeps over agent count, support radius, and beta (coupling strength),
    and logs critical metrics (φ norm, KL divergence, curvature) for each config.
    """
    results = []
    os.makedirs(base_outdir, exist_ok=True)

    for N in N_values:
        for radius in radius_values:
            for beta in beta_values:
                tag = f"N{N}_R{radius}_B{beta:.2f}"
                outdir = os.path.join(base_outdir, tag)
                print(f"\n[SWEEP] {tag}")

                params = dict(N=N, beta=beta, agent_radius_range=(radius, radius), steps=steps)
                run_simulation(outdir=outdir, resume=False, **params)

                # After simulation, load all steps and compute final metrics
                state_log = load_all_steps(outdir)
                metric_log = [log_all_metrics(agents, step) for step, agents in enumerate(state_log)]

                # Save metrics as CSV
                save_metrics_csv(metric_log, os.path.join(outdir, "metrics.csv"))

                # Append summary result (e.g., final step metrics)
                if metric_log:
                    final = metric_log[-1]
                    results.append({
                        "N": N,
                        "radius": radius,
                        "beta": beta,
                        **final
                    })

    # Save summary CSV
    save_metrics_csv(results, os.path.join(base_outdir, "summary.csv"))
    return results

if __name__ == "__main__":
    summary = run_criticality_sweep()
    print("\n[COMPLETE] Sweep finished. Summary saved.")