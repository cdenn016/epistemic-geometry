# -*- coding: utf-8 -*-
"""
Created on Thu Jun 12 21:14:41 2025

@author: chris and christine
"""

import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import os

def plot_criticality_metrics(summary_csv="criticality_sweep/summary.csv", outdir="criticality_sweep/plots"):
    """
    Plots criticality diagnostics from summary.csv across beta, N, and radius.
    
    Parameters:
    - summary_csv: path to the summary CSV file
    - outdir: directory to save plots
    """
    os.makedirs(outdir, exist_ok=True)
    df = pd.read_csv(summary_csv)

    metric_keys = [
        "phi_norm", "kl_self", "kl_align",
        "curvature", "entropy", "total_energy"
    ]

    for metric in metric_keys:
        plt.figure(figsize=(8, 6))
        sns.lineplot(
            data=df,
            x="beta",
            y=metric,
            hue="N",
            style="radius",
            markers=True,
            dashes=False,
            palette="tab10"
        )
        plt.title(f"{metric} vs Beta")
        plt.xlabel("Beta (coupling strength)")
        plt.ylabel(metric)
        plt.grid(True)
        plt.tight_layout()
        plt.savefig(os.path.join(outdir, f"{metric}_vs_beta.png"))
        plt.close()

    print(f"[DONE] Plots saved to: {outdir}")

if __name__ == "__main__":
    plot_criticality_metrics()
