# diagnostics_plot.py

import matplotlib.pyplot as plt
import numpy as np

def plot_alignment_over_time(alignment_log):
    """
    Plot KL(q || Ωq) alignment error over simulation steps.
    """
    steps, errs = zip(*alignment_log)
    plt.figure(figsize=(8, 4))
    plt.plot(steps, errs, label="Alignment Error")
    plt.xlabel("Step")
    plt.ylabel("KL(q || Ωq)")
    plt.title("Alignment Error Over Time")
    plt.grid(True)
    plt.tight_layout()
    plt.legend()
    plt.show()

def plot_phi_diagnostics(phi_diagnostic_log):
    """
    Plot φ field norms, Laplacians, and update deltas over time.
    """
    steps = [entry["step"] for entry in phi_diagnostic_log]
    phi_norms = [entry["phi_norm"] for entry in phi_diagnostic_log]
    lap_norms = [entry["lap_phi_norm"] for entry in phi_diagnostic_log]
    delta_norms = [entry["delta_phi_norm"] for entry in phi_diagnostic_log]

    plt.figure(figsize=(10, 5))
    plt.plot(steps, phi_norms, label="‖φ‖")
    plt.plot(steps, lap_norms, label="‖Δφ‖")
    plt.plot(steps, delta_norms, label="‖δφ‖")
    plt.xlabel("Step")
    plt.ylabel("Norms")
    plt.title("φ Diagnostics Over Time")
    plt.legend()
    plt.grid(True)
    plt.tight_layout()
    plt.show()

def plot_energy_over_time(energy_log):
    """
    Plot total and component energy terms over time.
    """
    steps = [step for step, _ in energy_log]
    keys = list(energy_log[0][1].keys())
    curves = {k: [e[k] for _, e in energy_log] for k in keys}

    plt.figure(figsize=(10, 6))
    for k in keys:
        plt.plot(steps, curves[k], label=k)
    plt.xlabel("Simulation step")
    plt.ylabel("Energy")
    plt.title("Energy Components vs Time")
    plt.legend()
    plt.grid(True)
    plt.tight_layout()
    plt.show()
