# generalized_transport.py

import numpy as np
from scipy.ndimage import gaussian_filter
from scipy.special import rel_entr
from transport_operator import construct_spatial_path, compute_path_operator
from chain_transport import get_overlap_centroid
from omega_operator import apply_omega, exp_so3_operator
from so3_generators import get_generators

from agent_schema import Agent  # NEW

def kl_divergence(p, q):
    p = np.clip(p, 1e-8, 1)
    q = np.clip(q, 1e-8, 1)
    return np.sum(rel_entr(p, q))

def find_agent_chain(agents, i, j, support_cutoff_eps):
    """
    Finds a valid chain of agents linking i to j via overlapping masks.
    Returns a list of agent indices representing the path, or None if not found.
    """
    import networkx as nx
    from chain_transport import build_overlap_graph
    G = build_overlap_graph(agents, support_cutoff_eps)
    try:
        return nx.shortest_path(G, i, j)
    except nx.NetworkXNoPath:
        return None



def transport_belief_along_path(
    agents: list[Agent],
    path,
    domain_size,
    support_cutoff_eps,
    K,
    fixed_start=None,
    fixed_end=None
):
    H, W = domain_size
    A = agents[path[0]]
    B = agents[path[-1]]

    # --- Select injection point in A ---
    if fixed_start is not None:
        c_0 = fixed_start
    else:
        candidates = np.argwhere(A.mask > 0.5)
        if len(candidates) == 0:
            raise RuntimeError("No candidate points found with sufficient mask support in source agent.")
        candidates = sorted(candidates, key=lambda c: -np.sum(A.q[tuple(c)]))
        c_0 = tuple(candidates[0])

    q = A.q[c_0].copy()

    if np.sum(q) < 1e-3:
        print(f"[WARNING] Selected point {c_0} has very low belief mass: ∑q = {np.sum(q):.3e}")

    full_path = []
    kl_path = []           # KL at coarse hops
    kl_path_fine = []      # KL at each pixel step

    _, _, _, generators = get_generators(K)


    for i in range(len(path) - 1):
        id_a, id_b = path[i], path[i + 1]
        agent_a, agent_b = agents[id_a], agents[id_b]

        c_overlap = get_overlap_centroid(agent_a, agent_b)
        if c_overlap is None:
            raise RuntimeError(f"No centroid found between agents {id_a} and {id_b}")

        path_segment = construct_spatial_path(c_0, c_overlap, (H, W), mask=agent_a.mask)
        if not path_segment:
            raise RuntimeError(f"Path {id_a}->{id_b} leaves agent {id_a}'s support.")

        # --- Intra-agent transport ---
        for x0, x1 in zip(path_segment[:-1], path_segment[1:]):
            delta_phi = agent_a.phi[x0] - agent_a.phi[x1]
            d_omega = exp_so3_operator(delta_phi, generators)
            q = d_omega @ q
            target_q = agent_a.q[x1]
            kl_path_fine.append(kl_divergence(q, target_q))

        # --- Inter-agent jump ---
        phi_a = agent_a.phi[c_overlap]
        phi_b = agent_b.phi[c_overlap]
        r = phi_a - phi_b
        r_norm = np.linalg.norm(r)

        omega_jump = exp_so3_operator(r, generators)


        q = apply_omega(q, omega_jump)

        target_q = agent_b.q[c_overlap]
        kl_path.append(kl_divergence(q, target_q))

        full_path += path_segment
        c_0 = c_overlap
        
        if not path_segment or path_segment[-1] != c_overlap:
            full_path.append(c_overlap)


# --- Final injection ---
    if fixed_end is not None:
        c_final = fixed_end
    else:
        c_final = full_path[-1] if full_path else c_overlap

# Normalize q one last time before writing into B.q
    q = np.clip(q, 1e-8, 1.0)
    q /= np.sum(q)

    delta_mask = np.zeros((H, W), dtype=np.float32)
    delta_mask[c_final] = 1.0
    smoothed = gaussian_filter(delta_mask, sigma=2)

    for k in range(K):
        B.q[..., k] += q[k] * smoothed

# Normalize full B.q
    B.q = np.clip(B.q, 1e-8, 1.0)
    B.q /= np.sum(B.q, axis=-1, keepdims=True) + 1e-8

# Update B.mask
    mask_patch = gaussian_filter(delta_mask, sigma=0.8)
    B.mask = np.maximum(B.mask, mask_patch)

# --- Ensure c_final is part of full_path ---
    if c_final not in full_path:
        full_path.append(c_final)


    return agents, {
        "full_path": full_path,
        "c_start": fixed_start if fixed_start is not None else full_path[0],
        "c_final": c_final,
        "path_indices": path,
        "kl_path": kl_path,
        "kl_path_fine": kl_path_fine
    }
