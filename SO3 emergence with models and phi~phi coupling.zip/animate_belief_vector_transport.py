# -*- coding: utf-8 -*-
"""
Created on Sun Jun  8 20:07:54 2025

@author: chris and christine
"""

import os
import pickle
import matplotlib.pyplot as plt
import imageio
import numpy as np
import re

def extract_step(foldername):
    match = re.search(r"step(\d+)", foldername)
    return int(match.group(1)) if match else -1

def load_belief_pairs(parent_dir="transport_runs"):
    records = []
    for folder in sorted(os.listdir(parent_dir)):
        log_path = os.path.join(parent_dir, folder, "transport_log.pkl")
        if not os.path.exists(log_path):
            continue
        try:
            with open(log_path, "rb") as f:
                log = pickle.load(f)
            q0 = log["q_initial"]
            qT = log["q_final"]
            step = extract_step(folder)
            records.append((step, q0, qT))
        except Exception as e:
            print(f"[SKIP] {folder}: {e}")
    return sorted(records)

def animate_belief_trajectory(records, outpath="animations/belief_transport.gif"):
    os.makedirs(os.path.dirname(outpath), exist_ok=True)
    K = len(records[0][1])
    frames = []

    # --- Fix y-axis to global max for smooth animation ---
    global_max = max(max(q0.max(), qT.max()) for _, q0, qT in records)

    for step, q0, qT in records:
        fig, ax = plt.subplots(figsize=(6, 4))
        x = np.arange(K)
        ax.plot(x, q0, color="black", label="Initial $q_0$", linewidth=2)
        ax.plot(x, qT, color="orange", linestyle="--", label="Final $q_T$")
        ax.set_title(f"Belief Transport at Step {step}")
        ax.set_xlabel("Fiber Index")
        ax.set_ylabel("Probability")
        ax.set_ylim(0, global_max * 1.2)  # <-- fixed scale
        ax.legend()
        ax.grid(True)
        plt.tight_layout()

        fig.canvas.draw()
        frame = np.frombuffer(fig.canvas.tostring_rgb(), dtype=np.uint8)
        frame = frame.reshape(fig.canvas.get_width_height()[::-1] + (3,))
        frames.append(frame)
        plt.close()

    imageio.mimsave(outpath, frames, fps=5)
    print(f"[✓] Saved belief transport animation to {outpath}")


if __name__ == "__main__":
    records = load_belief_pairs()
    if records:
        animate_belief_trajectory(records)
    else:
        print("[ERROR] No transport logs found.")
