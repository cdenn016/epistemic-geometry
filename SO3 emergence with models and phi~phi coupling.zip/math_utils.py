# -*- coding: utf-8 -*-
"""
Created on Thu Jun 12 13:09:19 2025

@author: chris and christine
"""
import numpy as np

def sanitize_q(q, eps=1e-9):
    q = np.clip(q, eps, 1.0)
    q /= np.sum(q, axis=-1, keepdims=True) + eps
    return q


def sanitize(dist, eps):
    dist = np.clip(dist, eps, 1.0)
    return dist / (np.sum(dist, axis=-1, keepdims=True) + eps)
