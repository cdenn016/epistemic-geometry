import numpy as np

import sys

def set_config_from_params(params):
    this_module = sys.modules[__name__]
    for k, v in params.items():
        setattr(this_module, k, v)

agent_seed =18

# --- Simulation Parameters ---
steps = 75
domain_size = (50, 50)

N = 3  # number of agents
max_neighbors = 2

K = 25 # dimension of belief fiber

#couplings
alpha = 1
beta = 5
gamma = 0

# Model gauge connection (Ω̃) strength
model_align_weight = 15  # or any value ≥ 0
model_gauge_weight = 10
#belief gauge weight
gauge_weight = 0



# Energy weights


curvature_weight = 0
phi_damping = 0  # Epistemic prior: only if we want forgetfullness 
epsilon = 0

# --- Agent Geometry ---
psi_radius_range = (9,14)
mask_sharpness = 1.5

# Belief (q) distribution parameters
q_mu_range = (2, K-2)
q_sigma_range = (2, 5)
q_sigma_init = 0.5

# Model (p) distribution parameters
p_mu_range = (2, K-2)
p_sigma_range = (1, 8)
p_sigma_init = 1  # or whatever default you want

similar_p_models = False  # if True, all p-models are similar

mu_field_smooth_range = (4, 8)
sigma_field_smooth_range = (3,6)

#q_mu_range = (2, K//2)
#p_mu_range = (K//2 + 1, K - 2)


# --- Dynamics Parameters ---
eta_q = 0.0002
eta_phi = 0.0001
eta_p = 0.0001  # Learning rate for model update (smaller than eta_q)




# φ update tuning
phi_clip_threshold = 0.5  # whether or not to use expm(G) norms<threshold

phi_init = 0.1

# --- Numerical Thresholds ---
log_eps = 1e-10
support_cutoff_eps = 1e-3  #larger reduces agent's masks
overlap_eps = 1e-5
eps = 1e-10

# --- Output & Precision ---
checkpoint_dir = "checkpoints"
save_checkpoints = True
checkpoint_interval = 1
precision = np.float32
