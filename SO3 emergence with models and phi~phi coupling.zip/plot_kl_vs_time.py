# -*- coding: utf-8 -*-
"""
Created on Sun Jun  8 20:05:00 2025

@author: chris and christine
"""

# plot_kl_vs_time.py

import os
import pickle
import re
import matplotlib.pyplot as plt
import numpy as np

def extract_step(foldername):
    match = re.search(r"step(\d+)", foldername)
    return int(match.group(1)) if match else -1

def load_kl_logs(parent_dir="transport_runs"):
    logs = []
    for subdir in os.listdir(parent_dir):
        path = os.path.join(parent_dir, subdir, "transport_log.pkl")
        if os.path.exists(path):
            try:
                with open(path, "rb") as f:
                    log = pickle.load(f)
                    step = extract_step(subdir)
                    if log.get("kl_path"):
                        avg_kl = np.mean(log["kl_path"])
                    elif log.get("kl_path_fine"):
                        avg_kl = np.mean(log["kl_path_fine"])
                    else:
                        continue
                    logs.append((step, avg_kl))
            except Exception as e:
                print(f"[SKIP] {subdir}: {e}")
    return sorted(logs)

def plot_kl_over_time(logs):
    steps, kl_values = zip(*logs)
    plt.figure(figsize=(8, 4))
    plt.plot(steps, kl_values, marker='o', linewidth=2)
    plt.xlabel("Step")
    plt.ylabel("Long-Range KL Divergence")
    plt.title("KL Divergence Along Fixed Transport Path Over Time")
    plt.grid(True)
    plt.tight_layout()
    plt.savefig("kl_vs_time.png")
    plt.show()
    print("[✓] Saved plot to kl_vs_time.png")

if __name__ == "__main__":
    logs = load_kl_logs()
    if logs:
        plot_kl_over_time(logs)
    else:
        print("[ERROR] No transport logs found.")
