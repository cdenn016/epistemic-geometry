# -*- coding: utf-8 -*-
"""
Created on Thu Jun 12 19:01:57 2025

@author: chris and christine
"""

import os
import pickle
import numpy as np
from scipy.stats.qmc import LatinHypercube

# --- Match your LHS sweep config ---
param_ranges = {
    "alpha": (0.0, 20),
    "beta": (0.0, 50),
    "gamma": (0.0, 200.0),
    "gauge_weight": (0, 3000),
    "curvature_weight": (0, 3000),
    "phi_init": (0.00001, 0.00005),
}

n_samples = 50
steps_per_run = 75
outdir_base = "lhs_runs"

# --- Rebuild the same LHS samples ---
def generate_lhs_samples(param_ranges, n_samples):
    keys = list(param_ranges.keys())
    bounds = np.array([param_ranges[k] for k in keys])
    sampler = LatinHypercube(d=len(keys), seed=0)  # Ensure deterministic!
    unit_samples = sampler.random(n=n_samples)
    scaled_samples = bounds[:, 0] + unit_samples * (bounds[:, 1] - bounds[:, 0])
    scaled_samples = np.round(scaled_samples, 4)
    return [dict(zip(keys, vals)) for vals in scaled_samples]

# --- Rebuild params.pkl for each run ---
def rebuild_params_files():
    samples = generate_lhs_samples(param_ranges, n_samples)
    for i, param_set in enumerate(samples):
        run_dir = os.path.join(outdir_base, f"run_{i:03d}")
        if not os.path.exists(run_dir):
            continue
        filepath = os.path.join(run_dir, "params.pkl")
        if not os.path.exists(filepath):
            with open(filepath, "wb") as f:
                pickle.dump(param_set, f)
            print(f"[REBUILT] {filepath}")
        else:
            print(f"[EXISTS]  {filepath}")

if __name__ == "__main__":
    rebuild_params_files()
