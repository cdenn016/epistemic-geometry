# Modular update_rules.py
from config import eta_q, log_eps, K
from agent_schema import Agent
import numpy as np
from update_terms_modular import (
    compute_self_model_gradient,
    compute_alignment_gradient,
    compute_phi_alignment_gradient
)
from math_utils import sanitize_q
from update_terms_modular import compute_model_alignment_gradient  # add to your import block

from update_terms_modular import compute_phi_model_update
import config

def update_beliefs(i: int, agents: list[Agent], params: dict) -> Agent:
    from config import set_config_from_params
    set_config_from_params(params)

    agent_i = agents[i]
    q_i = agent_i.q
    mask_i = agent_i.mask

    grad = compute_self_model_gradient(agent_i)
    grad += compute_alignment_gradient(agent_i, agents)

    # Apply gradient update
    q_new = q_i - eta_q * grad

    # Keep q fixed outside support
    q_new[mask_i < config.support_cutoff_eps] = q_i[mask_i < config.support_cutoff_eps]

    # Normalize after full update
    q_new = sanitize_q(q_new, eps=log_eps)

    agent_i.q = q_new
    return agent_i


def update_phi(i: int, agents: list[Agent], eta_phi: float, params: dict) -> Agent:
    from config import set_config_from_params
    set_config_from_params(params)

    agent_i = agents[i]
    phi_i = agent_i.phi
    mask_i = agent_i.mask

    delta_phi = compute_phi_alignment_gradient(agent_i, agents)

    # φ Laplacian smoothing
    if config.gamma > 0:
        from scipy.ndimage import laplace
        lap_phi = np.stack([laplace(phi_i[..., d]) for d in range(3)], axis=-1)
        delta_phi -= config.gamma * lap_phi * mask_i[..., None]

    if config.gauge_weight > 0:
        delta_phi -= config.gauge_weight * phi_i * mask_i[..., None]

    if hasattr(config, "phi_damping") and config.phi_damping > 0:
        delta_phi -= config.phi_damping * phi_i * mask_i[..., None]

    # Debugging: detect nan or explosive φ updates
    if np.any(np.isnan(delta_phi)) or np.any(np.abs(delta_phi) > 1e2):
        print(f"[WARNING] phi update unstable in agent {i}: max delta phi-belief = {np.max(np.abs(delta_phi)):.2e}")

    # Safety guards
    delta_phi = np.nan_to_num(delta_phi, nan=0.0, posinf=0.0, neginf=0.0)

    # 🔒 Safe rescaling to ensure ∥Δφ∥ ≤ π
    norm = np.linalg.norm(delta_phi, axis=-1, keepdims=True)
    scaling = np.where(norm > np.pi, np.pi / (norm + config.log_eps), 1.0)
    delta_phi *= scaling  # broadcast-safe per-vector rescaling

    agent_i.phi += eta_phi * delta_phi
    agent_i.delta_phi = delta_phi
    return agent_i


def update_phi_model(i: int, agents: list[Agent], eta_phi: float, params: dict) -> Agent:
    from config import set_config_from_params
    set_config_from_params(params)

    agent_i = agents[i]
    phi_model = agent_i.phi_model
    mask_i = agent_i.mask

    delta_phi = compute_phi_model_update(agent_i, agents)
    # --- Optional DEBUG: log magnitude of delta_phi_model ---
    if hasattr(config, "debug") and config.debug:
        delta_norm = np.linalg.norm(delta_phi, axis=-1)
        print(f"[φ̃ DEBUG] Agent {i} — delta phi max: {np.max(delta_norm):.4f}, mean: {np.mean(delta_norm):.4f}")

    # Debugging: check for instability
    if np.any(np.isnan(delta_phi)) or np.any(np.abs(delta_phi) > 1e2):
        print(f"[WARNING] phi-model update unstable in agent {i}: max delta phi-model = {np.max(np.abs(delta_phi)):.2e}")

    # Safety guards
    delta_phi = np.nan_to_num(delta_phi, nan=0.0, posinf=0.0, neginf=0.0)

    # 🔒 Rescale step to ensure ∥Δφ̃∥ ≤ π
    norm = np.linalg.norm(delta_phi, axis=-1, keepdims=True)  # (H, W, 1)
    scaling = np.where(norm > np.pi, np.pi / (norm + config.log_eps), 1.0)
    delta_phi *= scaling  # broadcast-safe rescale

    agent_i.phi_model += eta_phi * delta_phi
    agent_i.delta_phi_model = delta_phi

    return agent_i

def update_models(i: int, agents: list[Agent], params: dict) -> Agent:
    from config import set_config_from_params, eta_p, log_eps, support_cutoff_eps
    set_config_from_params(params)

    agent_i = agents[i]
    p_i = agent_i.p
    mask_i = agent_i.mask

    grad = compute_model_alignment_gradient(agent_i, agents)

    # Apply gradient update
    p_new = p_i - eta_p * grad

    # Keep model fixed outside support
    p_new[mask_i < support_cutoff_eps] = p_i[mask_i < support_cutoff_eps]

    # Normalize only after full update
    p_new = sanitize_q(p_new, eps=log_eps)

    agent_i.p = p_new
    return agent_i

