# -*- coding: utf-8 -*-
"""
Created on Thu Jun 12 21:47:04 2025

@author: chris and christine
"""

import os
import pickle
import numpy as np
import matplotlib.pyplot as plt
from io_utils import list_all_step_files, load_agents
from diagnostics_metrics import compute_alignment_error

def detect_critical_slowness(lhs_dir="lhs_runs", outdir="slowness_plots"):
    os.makedirs(outdir, exist_ok=True)
    results = []

    for subdir in sorted(os.listdir(lhs_dir)):
        run_path = os.path.join(lhs_dir, subdir)
        if not os.path.isdir(run_path):
            continue

        step_files = list_all_step_files(run_path)
        alignments = []
        steps = []

        for step in step_files:
            try:
                agents = load_agents(step, run_path)
                err = compute_alignment_error(agents)
                alignments.append(err)
                steps.append(step)
            except Exception as e:
                print(f"[WARN] Failed at step {step} in {subdir}: {e}")
                continue

        if len(steps) < 5:
            continue

        alignments = np.array(alignments)
        steps = np.array(steps)
        log_err = np.log(alignments + 1e-12)
        slope, _ = np.polyfit(steps, log_err, 1)
        rate = -slope

        # Save decay plot
        plt.figure(figsize=(6, 4))
        plt.plot(steps, alignments, marker='o')
        plt.yscale("log")
        plt.xlabel("Step")
        plt.ylabel("Alignment Error (log)")
        plt.title(f"Alignment Convergence — {subdir}\nRate = {rate:.4f}")
        plt.grid(True)
        plt.tight_layout()
        plot_path = os.path.join(outdir, f"alignment_decay_{subdir}.png")
        plt.savefig(plot_path)
        plt.close()

        params_path = os.path.join(run_path, "params.pkl")
        if os.path.exists(params_path):
            with open(params_path, "rb") as f:
                params = pickle.load(f)
        else:
            params = {}

        results.append({
            "run": subdir,
            "convergence_rate": rate,
            **params
        })

    return results
