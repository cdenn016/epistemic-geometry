# so3_generators.py

import numpy as np

_generator_cache = {}

def get_generators(K):
    """
    Return cached or freshly computed SO(3) real-valued generators:
    (Jx, Jy, Jz, generators) where generators has shape (3, K, K)
    """
    if K in _generator_cache:
        return _generator_cache[K]

    l = (K - 1) // 2
    m = np.arange(-l, l + 1)

    Jx = np.zeros((K, K))
    Jy = np.zeros((K, K))
    Jz = np.diag(m)

    for i in range(K - 1):
        c = 0.5 * np.sqrt((l - m[i]) * (l + m[i] + 1))
        Jx[i, i+1] = Jx[i+1, i] = c
        Jy[i, i+1] = -c
        Jy[i+1, i] = c

    generators = np.stack([Jx, Jy, Jz], axis=0)  # shape (3, K, K)
    _generator_cache[K] = (Jx, Jy, Jz, generators)
    return _generator_cache[K]
