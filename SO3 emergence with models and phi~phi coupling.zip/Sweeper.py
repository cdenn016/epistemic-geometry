import os
import numpy as np
from run_simulation_parallel import run_simulation

def param_range(start, end, num_points):
    return np.linspace(start, end, num_points)

def main():
    param = "phi_init"  # ← you can change this to any valid config param, e.g. "alpha", "beta"
    values = param_range(0, 1, 11)

    for val in values:
        outdir = f"sweeps_{param}/{param}_{val:.4f}"  # more precision for small values
        os.makedirs(outdir, exist_ok=True)

        if os.path.exists(os.path.join(outdir, "alignment_log.pkl")):
            print(f"[SKIP] {outdir} already exists")
            continue

        print(f"[RUN] {param} = {val:.4f}")
        run_simulation(outdir=outdir, resume=False, **{param: val})

if __name__ == "__main__":
    main()
