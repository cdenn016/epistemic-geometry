import os
import numpy as np
import matplotlib.pyplot as plt
import imageio
from numpy.linalg import eigvalsh
from config import log_eps
import pickle

os.makedirs("animations", exist_ok=True)

def sanitize_q(q):
    q = np.clip(q, log_eps, 1.0)
    q /= np.sum(q, axis=-1, keepdims=True) + log_eps
    return q

def compute_fisher_metric_tensor(q):
    q = sanitize_q(q)
    log_q = np.log(q)
    dq_dx = np.gradient(log_q, axis=0)
    dq_dy = np.gradient(log_q, axis=1)
    g_xx = np.sum(dq_dx**2, axis=-1)
    g_yy = np.sum(dq_dy**2, axis=-1)
    g_xy = np.sum(dq_dx * dq_dy, axis=-1)
    return g_xx, g_yy, g_xy

def compute_fisher_curvature(q):
    g_xx, g_yy, g_xy = compute_fisher_metric_tensor(q)
    H, W = q.shape[:2]
    curvature = np.zeros((H, W))
    for i in range(H):
        for j in range(W):
            G = np.array([[g_xx[i,j], g_xy[i,j]], [g_xy[i,j], g_yy[i,j]]])
            eigvals = eigvalsh(G)
            curvature[i,j] = np.sum(eigvals)
    return curvature

def load_step_log(folder="checkpoints", max_steps=1000):
    files = sorted([
        f for f in os.listdir(folder)
        if f.startswith("step_") and f.endswith(".pkl")
    ], key=lambda x: int(x.split("_")[1].split(".")[0]))
    files = files[:max_steps]
    state_log = []
    for fname in files:
        with open(os.path.join(folder, fname), "rb") as f:
            agents = pickle.load(f)
            state_log.append(agents)
    return state_log

def animate_fisher_curvature_from_steps(folder="checkpoints", agent_index=0):
    state_log = load_step_log(folder)
    curv_all = []

    for agents in state_log:
        q = agents[agent_index].q
        mask = agents[agent_index].mask

        curv = compute_fisher_curvature(q)
        curv[mask < 0.1] = np.nan
        curv_all.append(curv)

    all_vals = np.concatenate([c[np.isfinite(c)] for c in curv_all])
    vmin, vmax = 0, np.percentile(all_vals, 99)

    frames = []
    for t, curv in enumerate(curv_all):
        fig, ax = plt.subplots(figsize=(5, 5))
        im = ax.imshow(curv, cmap='inferno', vmin=vmin, vmax=vmax)
        ax.set_title(f"Fisher Curvature (Step {t})")
        plt.colorbar(im, ax=ax)
        fig.canvas.draw()

        frame = np.asarray(fig.canvas.buffer_rgba())
        frames.append(frame)
        plt.close()

    gif_path = f"animations/fisher_curvature_agent{agent_index}.gif"
    imageio.mimsave(gif_path, frames, fps=10)
    return gif_path

if __name__ == "__main__":
    animate_fisher_curvature_from_steps(agent_index=0)
