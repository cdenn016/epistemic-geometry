# -*- coding: utf-8 -*-
"""
Created on Thu Jun 12 21:15:44 2025

@author: chris and christine
"""

import pandas as pd
import numpy as np
import os
import matplotlib.pyplot as plt
import seaborn as sns
from glob import glob

def load_metrics_from_runs(base_dir="criticality_sweep"):
    """
    Load metrics.csv files from all sweep runs and attach metadata (N, radius, beta).
    """
    all_data = []
    for path in sorted(glob(os.path.join(base_dir, "N*_R*_B*/metrics.csv"))):
        parts = os.path.basename(os.path.dirname(path)).split("_")
        N = int(parts[0][1:])
        R = int(parts[1][1:])
        B = float(parts[2][1:])
        df = pd.read_csv(path)
        df["N"] = N
        df["radius"] = R
        df["beta"] = B
        all_data.append(df)
    return pd.concat(all_data, ignore_index=True)

def detect_criticality_by_variance(df, metric="phi_norm", groupby=["N", "radius"]):
    """
    Computes the variance over time of a given metric for each (N, radius, beta) config.
    Returns a DataFrame of variances as a function of beta.
    """
    grouped = df.groupby(groupby + ["beta"])
    summary = grouped[metric].agg(["mean", "var"]).reset_index()
    summary.rename(columns={"mean": f"{metric}_mean", "var": f"{metric}_var"}, inplace=True)
    return summary

def plot_metric_variance(summary_df, metric="phi_norm", outdir="criticality_sweep/critical_points"):
    """
    Plots the variance of a metric vs beta to highlight peaks.
    """
    os.makedirs(outdir, exist_ok=True)
    var_col = f"{metric}_var"

    plt.figure(figsize=(9, 6))
    sns.lineplot(
        data=summary_df,
        x="beta",
        y=var_col,
        hue="N",
        style="radius",
        markers=True,
        dashes=False
    )
    plt.xlabel("Beta (Coupling Strength)")
    plt.ylabel(f"Variance of {metric}")
    plt.title(f"Critical Variance Peaks — {metric}")
    plt.grid(True)
    plt.tight_layout()
    plt.savefig(os.path.join(outdir, f"{metric}_variance_vs_beta.png"))
    plt.close()

    print(f"[PLOT SAVED] {metric}_variance_vs_beta.png")

if __name__ == "__main__":
    df = load_metrics_from_runs()
    summary = detect_criticality_by_variance(df, metric="phi_norm")
    plot_metric_variance(summary, metric="phi_norm")
