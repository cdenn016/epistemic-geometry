import numpy as np
import config
from scipy.linalg import expm
from joblib import Parallel, delayed, parallel_backend
from natural_gradient_utils import sanitize_sigma  # assumes sanitize_sigma is in your utils
from generalized_math_utils import is_spd_matrix
from generalized_math_utils import kl_divergence

def transport_covariance_batch(Sigma, Omega):
    """
    Transport a batch of covariance matrices: Σ → Ω Σ Ωᵀ

    Parameters:
        Sigma: (N, K, K) — batch of covariance matrices
        Omega: (N, K, K) — batch of transport operators

    Returns:
        Sigma_t: (N, K, K) — transported covariances
    """
    return Omega @ Sigma @ np.transpose(Omega, (0, 2, 1))


def compute_inter_agent_omega(
    phi_i: np.ndarray,
    phi_j: np.ndarray,
    coords: list[tuple[int, ...]],
    generators: np.ndarray,
    use_commutator: bool = False,
    phi_key: str = "phi",
) -> np.ndarray:
    """
    Compute Ω_{ij}(c) = exp(φᵢ(c)) @ exp(−φⱼ(c)) for a batch of coordinates.

    Args:
        phi_i: φᵢ field, shape (..., d)
        phi_j: φⱼ field, shape (..., d)
        coords: list of coordinate tuples
        generators: (d, K, K) array of Lie algebra generators
        use_commutator: optional abelian shortcut
        phi_key: "phi" or "phi_model" — controls scaling (e_belief or e_model)

    Returns:
        Omega_batch: (B, K, K) transport operators
    """
    from config import e_belief, e_model
    e = e_belief if phi_key == "phi" else e_model

    # Extract φᵢ(c), φⱼ(c) at all coords → shape (B, d)
    φi_vecs = np.stack([phi_i[c] for c in coords]) / e
    φj_vecs = np.stack([phi_j[c] for c in coords]) / e

    Ω = build_inter_agent_omega(
        φi_vecs,
        φj_vecs,
        generators,
        config=config,
        use_commutator=use_commutator
    )  # shape (B, K, K)

    return Ω



def adaptive_expm(G, clip_norm=None, max_norm=None, threshold=1e-3):
    """
    Rescales G to prevent instability, then exponentiates.

    Parameters:
    - G: (K, K) Lie algebra element
    - clip_norm: soft norm cap — rescales if norm exceeds this
    - max_norm: hard norm cap — forcibly rescales if exceeded
    - threshold: below this, use 2nd-order Taylor

    Returns:
    - exp(G) ∈ Lie group
    """
    norm_G = np.linalg.norm(G) + 1e-16

    if clip_norm is not None and norm_G > clip_norm:
        G = G * (clip_norm / norm_G)

    if max_norm is not None and norm_G > max_norm:
        G = G * (max_norm / norm_G)

    if norm_G < threshold:
        I = np.eye(G.shape[0], dtype=G.dtype)
        return I + G + 0.5 * (G @ G)
    else:
        return expm(G)


def exp_lie_algebra_irrep(
    v_batch,
    generators,
    use_expm=True,
    threshold=1e-3,
    max_norm=20,
    group_name=None,
    n_jobs=-1  # Optional parallelism for large-norm cases
):
    """
    Compute batch of exp(sum_a v[a] * T_a) using Taylor or expm depending on norm.

    Parameters:
    - v_batch: (..., dim_G) Lie algebra coefficients
    - generators: (dim_G, K, K) Lie algebra generators
    - use_expm: use adaptive_expm or scipy.expm for large-norm cases
    - threshold: Taylor cutoff for small norms
    - max_norm: clamp large-norm vectors
    - group_name: (optional) cleanup: "so3", "su2", etc.
    - n_jobs: parallel jobs for large-norm exponentials

    Returns:
    - (..., K, K): batch of exponentiated matrices
    """

    # Fallback definition if adaptive_expm is not available
    def adaptive_expm(A, **kwargs):
        return expm(A)

    *batch_shape, dim_G = v_batch.shape
    v_flat = v_batch.reshape(-1, dim_G)
    N = v_flat.shape[0]
    _, K, _ = generators.shape
    dtype = v_batch.dtype

    # --- Normalize ---
    norms = np.linalg.norm(v_flat, axis=1)
    eps = 1e-16
    scale_factors = np.minimum(1.0, max_norm / (norms + eps))
    v_scaled = v_flat * scale_factors[:, None]

    # --- Construct algebra elements ---
    G_batch = np.einsum("na,aij->nij", v_scaled, generators)

    # --- Group-specific antisymmetrization ---
    if group_name == "so3":
        G_batch = 0.5 * (G_batch - np.transpose(G_batch, axes=(0, 2, 1)))
    elif group_name == "su2":
        G_batch = 0.5 * (G_batch - np.transpose(G_batch, axes=(0, 2, 1)).conj())

    # --- Initialize result buffer ---
    result = np.empty((N, K, K), dtype=dtype)
    approx_mask = norms * scale_factors < threshold

    # --- Taylor expansion for small-norm matrices ---
    if np.any(approx_mask):
        G_approx = G_batch[approx_mask]
        I = np.eye(K, dtype=dtype)[None, :, :]
        G2 = G_approx @ G_approx
        result[approx_mask] = I + G_approx + 0.5 * G2

    # --- Parallel expm fallback for large-norm matrices ---
    if np.any(~approx_mask):
        idxs = np.flatnonzero(~approx_mask)
        G_heavy = [G_batch[i] for i in idxs]

        expm_results = Parallel(n_jobs=n_jobs, backend="threading")(
            delayed(adaptive_expm)(G) for G in G_heavy
        )

        for i, res in zip(idxs, expm_results):
            result[i] = res

    return result.reshape(*batch_shape, K, K)



def batch_apply_omega(mu_batch, sigma_batch, omega_batch, n_jobs=None, parallel_threshold=1000):
    """
    Applies Ω to multivariate Gaussians using Cholesky transport:
      - μ' = Ω μ
      - Σ' = (Ω L)(Ω L)ᵀ  where Σ = LLᵀ, sanitized in advance

    Parameters:
        mu_batch:     (..., K) array of mean vectors
        sigma_batch:  (..., K, K) array of covariance matrices
        omega_batch:  (..., K, K) array of group matrices
        n_jobs:       number of threads (default: config.num_cores)
        parallel_threshold: use parallel only if batch size ≥ this

    Returns:
        μ', Σ' — same shape as input
    """
    mu_batch = np.asarray(mu_batch)
    sigma_batch = np.asarray(sigma_batch)
    omega_batch = np.asarray(omega_batch)

    assert mu_batch.shape[:-1] == omega_batch.shape[:-2], "Shape mismatch in batch dimensions"
    assert mu_batch.shape[-1] == omega_batch.shape[-1], "Mismatch in fiber dimension K"

    n_jobs = n_jobs or config.num_cores
    flat_mu = mu_batch.reshape(-1, mu_batch.shape[-1])
    flat_omega = omega_batch.reshape(-1, omega_batch.shape[-2], omega_batch.shape[-1])
    flat_sigma = sigma_batch.reshape(-1, sigma_batch.shape[-2], sigma_batch.shape[-1])
    N = flat_mu.shape[0]
    K = flat_mu.shape[-1]

    # Step 1: sanitize Σ to ensure SPD
    flat_sigma = sanitize_sigma(flat_sigma, eps=1e-6, debug=config.debug_sanitize_sigma)

    # Step 2: μ' = Ω μ
    if N < parallel_threshold:
        mu_t = np.einsum("...ij,...j->...i", omega_batch, mu_batch)
    else:
        with parallel_backend("threading"):
            mu_t_flat = Parallel(n_jobs=n_jobs)(
                delayed(lambda μ, Ω: Ω @ μ)(μ, Ω) for μ, Ω in zip(flat_mu, flat_omega)
            )
        mu_t = np.stack(mu_t_flat, axis=0).reshape(mu_batch.shape)

    # Step 3: Σ' = (Ω L)(Ω L)ᵀ
    sigma_t = np.zeros_like(flat_sigma)
    repaired = 0

    for i in range(N):
        Σ = flat_sigma[i]
        Ω = flat_omega[i]
        try:
            L = np.linalg.cholesky(Σ)
            L_t = Ω @ L
            sigma_t[i] = L_t @ L_t.T
        except np.linalg.LinAlgError:
            sigma_t[i] = np.eye(K)
            repaired += 1

    if repaired > 0:
        print(f"[Ω̃ Cholesky SPD-fix] Fallback to I for {repaired} / {N} matrices")

    return mu_t, sigma_t.reshape(sigma_batch.shape)



def batch_apply_omega_old(mu_batch, sigma_batch, omega_batch, n_jobs=None, parallel_threshold=1000):
    """
    Applies Ω to either:
      - Just mean vectors:        μ' = Ω μ        (if sigma_batch is None)
      - Full Gaussians:           μ' = Ω μ,  Σ' = Ω Σ Ωᵀ

    Parameters:
        mu_batch:     (..., K) array of mean vectors
        sigma_batch:  (..., K, K) array of covariance matrices or None
        omega_batch:  (..., K, K) array of group matrices
        n_jobs:       number of threads (default: config.num_cores)
        parallel_threshold: use parallel only if batch size ≥ this

    Returns:
        - If sigma_batch is None:         μ'
        - Else:                            (μ', Σ')
    """
    mu_batch = np.asarray(mu_batch)
    omega_batch = np.asarray(omega_batch)
    assert mu_batch.shape[:-1] == omega_batch.shape[:-2], "Shape mismatch in batch dimensions"
    assert mu_batch.shape[-1] == omega_batch.shape[-1], "Mismatch in fiber dimension K"

    n_jobs = n_jobs or config.num_cores
    flat_mu = mu_batch.reshape(-1, mu_batch.shape[-1])
    flat_omega = omega_batch.reshape(-1, omega_batch.shape[-2], omega_batch.shape[-1])

    # Fast einsum for small batches
    if flat_mu.shape[0] < parallel_threshold:
        mu_t = np.einsum("...ij,...j->...i", omega_batch, mu_batch)
    else:
        with parallel_backend("threading"):
            mu_t_flat = Parallel(n_jobs=n_jobs)(
                delayed(lambda μ, Ω: Ω @ μ)(μ, Ω) for μ, Ω in zip(flat_mu, flat_omega)
            )
        mu_t = np.stack(mu_t_flat, axis=0).reshape(mu_batch.shape)

    # If no covariance provided, return just transformed μ
    if sigma_batch is None:
        return mu_t

    # Otherwise, transform Σ as Σ' = Ω Σ Ωᵀ
    sigma_batch = np.asarray(sigma_batch)
    flat_sigma = sigma_batch.reshape(-1, *sigma_batch.shape[-2:])
    if flat_sigma.shape[0] < parallel_threshold:
        sigma_t = omega_batch @ sigma_batch @ np.transpose(omega_batch, (0, 2, 1))
    else:
        with parallel_backend("threading"):
            sigma_t_flat = Parallel(n_jobs=n_jobs)(
                delayed(lambda Σ, Ω: Ω @ Σ @ Ω.T)(Σ, Ω) for Σ, Ω in zip(flat_sigma, flat_omega)
            )
        sigma_t = np.stack(sigma_t_flat, axis=0).reshape(sigma_batch.shape)

    # ── Optional: ensure Σ' is SPD ──
    if getattr(config, "ensure_spd", True):
        eps = getattr(config, "spd_eps", 1e-4)
        flat_sigma_t = sigma_t.reshape(-1, sigma_t.shape[-2], sigma_t.shape[-1])
        bad_count = 0
        for i in range(flat_sigma_t.shape[0]):
            if not is_spd_matrix(flat_sigma_t[i]):
                flat_sigma_t[i] += eps * np.eye(flat_sigma_t.shape[-1])
                bad_count += 1
        if bad_count > 0:
            print(f"[Ω SPD-fix] Repaired {bad_count} non-SPD Σ out of {flat_sigma_t.shape[0]}")
        sigma_t = flat_sigma_t.reshape(sigma_batch.shape)

    return mu_t, sigma_t


def compute_spatial_gradient_matrix_field(A_field, axis=0):
    """
    Compute the spatial gradient ∂_axis A(x) of a matrix-valued field.

    A_field shape: (..., K, K) where the first dimensions index spatial positions.
    axis: which spatial axis to differentiate along.

    Returns:
        grad: same shape as A_field, gradient taken elementwise over (..., K, K)
    """
    edge_order = 2 if A_field.shape[axis] >= 3 else 1
    return np.gradient(A_field, axis=axis, edge_order=edge_order)


def compute_gauge_potential(phi):
    """
    Compute gauge potentials A_μ^a = ∂_μ φ^a for arbitrary Lie algebra and base dimension D.
        BE CAREFUL! CANNOT PASS THIS OUTPUT INTO COMMUTATOR WITHOUT CONVERTING
    Args:
        phi: np.ndarray, shape (..., d), where
             ... represents spatial dimensions (S_1,...,S_D),
             d = dim Lie algebra.

    Returns:
        A: tuple of length D, each entry np.ndarray of shape (..., d),
           spatial derivatives of phi along each base manifold dimension.
    """
    D = phi.ndim - 1  # subtract Lie algebra dimension axis
    spatial_axes = tuple(range(D))
    A = tuple(np.gradient(phi, axis=axis) for axis in spatial_axes)
    return A


def compute_commutator(A_mu, A_nu):
    """
    Compute matrix commutator [A_μ, A_ν] = A_μ A_ν - A_ν A_μ for batch matrices.

    Args:
        A_mu, A_nu: np.ndarray with shape (..., K, K)

    Returns:
        commutator: np.ndarray with shape (..., K, K)
    """
    return np.matmul(A_mu, A_nu) - np.matmul(A_nu, A_mu)


def compute_field_strength(phi: np.ndarray, generators: np.ndarray, dx: float = 1.0):
    """
    Compute curvature F_{μν} = ∂_μ φ_ν - ∂_ν φ_μ + [φ_μ, φ_ν] from Lie algebra-valued φ field.

    Args:
        phi:        (H, W, d) Lie-algebra field
        generators: (d, K, K) array of basis generators of Lie algebra
        dx:         finite difference spacing

    Returns:
        Dictionary with keys ("xy", ...) → array of shape (H, W, K, K)
    """
    H, W, d = phi.shape
    assert generators.shape[0] == d, f"Expected {d} generators but got {generators.shape[0]}"
    K = generators.shape[1]

    # 1) Expand φ into matrix-valued field
    phi_matrix = np.einsum("ijk,klm->ijlm", phi, generators)  # (H, W, K, K)

    # 2) Compute derivatives ∂_x φ and ∂_y φ
    dphi_dx = (np.roll(phi_matrix, -1, axis=0) - np.roll(phi_matrix, 1, axis=0)) / (2 * dx)
    dphi_dy = (np.roll(phi_matrix, -1, axis=1) - np.roll(phi_matrix, 1, axis=1)) / (2 * dx)

    # 3) Compute commutator [φ_x, φ_y]
    commutator = np.einsum("ijkl,ijmn->ijkn", dphi_dx, dphi_dy) - np.einsum("ijmn,ijkl->ijkn", dphi_dy, dphi_dx)

    # 4) Total curvature tensor
    F_xy = dphi_dx[..., :, :] - dphi_dy[..., :, :] + commutator

    return {"xy": F_xy}


def build_inter_agent_omega(phi_i, phi_j, generators, config=None, use_commutator=False):
    """
    Compute the inter-agent gauge transport operator field Ω_{ij}(x).

    Parameters:
        phi_i: np.ndarray shape (..., d) — φ_i field over spatial domain
        phi_j: np.ndarray shape (..., d) — φ_j field over spatial domain
        generators: np.ndarray shape (d, K, K) — Lie algebra generators
        config: optional config object to override use_commutator
        use_commutator: bool —
            if False, do non-abelian exp(φ_i) @ exp(-φ_j);
            if True,  do abelian exp(φ_i - φ_j)

    Returns:
        omega_ij: np.ndarray shape (..., K, K) — inter-agent transport operator
    """
    # allow config to override the flag
    if config is not None:
        use_commutator = getattr(config, "use_commutator", use_commutator)

    # difference field (..., d)
    delta = phi_i - phi_j

    if not use_commutator:
        # non-abelian: exp(φ_i) @ exp(-φ_j)
        g_i     = exp_lie_algebra_irrep(phi_i, generators, group_name=getattr(config, "group_name", None))
        g_j_inv = exp_lie_algebra_irrep(-phi_j, generators, group_name=getattr(config, "group_name", None))
        return np.matmul(g_i, g_j_inv)

    # abelian shortcut: exp(φ_i - φ_j)
    return exp_lie_algebra_irrep(delta, generators, group_name=getattr(config, "group_name", None))


def compute_pairwise_kl(agents, generators, params, return_pointwise=False):
    """
    Computes KL(q_i || Ω_ij q_j) using full MVG belief transport.
    """
    from generalized_omega import batch_apply_omega
    from natural_gradient_utils import sanitize_sigma
    from generalized_math_utils import kl_divergence

    log_eps = params.get("log_eps", 1e-8)
    overlap_eps = params.get("overlap_eps", 1e-6)
    N = len(agents)
    kl_matrix = np.full((N, N), np.nan)
    pointwise = {} if return_pointwise else None

    for i in range(N):
        A = agents[i]
        mu_i = A.mu_q_field
        sigma_i = A.sigma_q_field
        mask_i = A.mask > overlap_eps

        for j in range(N):
            if i == j:
                kl_matrix[i, j] = 0.0
                continue

            B = agents[j]
            mu_j = B.mu_q_field
            sigma_j = B.sigma_q_field
            mask_j = B.mask > overlap_eps

            overlap = mask_i & mask_j
            if not np.any(overlap):
                continue

            # Extract overlap data
            mu_i_ov = mu_i[overlap]
            sigma_i_ov = sigma_i[overlap]
            mu_j_ov = mu_j[overlap]
            sigma_j_ov = sigma_j[overlap]

            # Compute Ω_ij at each overlap point
            Omega_ij = build_inter_agent_omega(
                phi_i=A.phi[overlap],
                phi_j=B.phi[overlap],
                generators=generators,
                config=params,
            )  # shape (M, K, K)

            # Transport (μ_j, Σ_j) under Ω_ij
            mu_j_t, sigma_j_t = batch_apply_omega(mu_j_ov, sigma_j_ov, Omega_ij)

            # Sanitize for stability
            sigma_i_ov = sanitize_sigma(sigma_i_ov, eps=log_eps)
            sigma_j_t = sanitize_sigma(sigma_j_t, eps=log_eps)

            # Compute KL(q_i || Ω q_j)
            kl_vals = kl_divergence(mu_i_ov, sigma_i_ov, mu_j_t, sigma_j_t)
            kl_matrix[i, j] = float(np.mean(kl_vals))

            if return_pointwise:
                pw_field = np.zeros(mask_i.shape)
                pw_field[overlap] = kl_vals
                pointwise[(i, j)] = pw_field

    return (kl_matrix, pointwise) if return_pointwise else kl_matrix



def compute_pairwise_model_kl(agents, generators, params, return_pointwise=False):
    
    log_eps = params.get("log_eps", 1e-8)
    overlap_eps = params.get("overlap_eps", 1e-6)
    N = len(agents)
    kl_matrix = np.full((N, N), np.inf)
    pointwise = {} if return_pointwise else None

    for i in range(N):
        A = agents[i]
        mu_i = A.mu_p_field
        sigma_i = A.sigma_p_field
        mask_i = A.mask > overlap_eps

        for j in range(N):
            if i == j:
                kl_matrix[i, j] = 0.0
                continue

            B = agents[j]
            mu_j = B.mu_p_field
            sigma_j = B.sigma_p_field
            mask_j = B.mask > overlap_eps

            overlap = mask_i & mask_j
            if not np.any(overlap):
                continue

            # Get transported μ_j and Σ_j under φ_model
            Omega_ij = build_inter_agent_omega(
                phi_i = A.phi_model[overlap],
                phi_j = B.phi_model[overlap],
                generators = generators,
                config = params
            )  # (M, K, K)

            mu_j_ov = mu_j[overlap]
            sigma_j_ov = sigma_j[overlap]
            mu_j_t = np.einsum("mab,mb->ma", Omega_ij, mu_j_ov)
            sigma_j_t = transport_covariance_batch(sigma_j_ov, Omega_ij)

            mu_i_ov = mu_i[overlap]
            sigma_i_ov = sigma_i[overlap]

            kl_vals = kl_divergence(mu_i_ov, sigma_i_ov, mu_j_t, sigma_j_t)
            kl_matrix[i, j] = float(np.mean(kl_vals))

            if return_pointwise:
                pw_field = np.zeros(mask_i.shape)
                pw_field[overlap] = kl_vals
                pointwise[(i, j)] = pw_field

    return (kl_matrix, pointwise) if return_pointwise else kl_matrix


def compute_pairwise_Omega(phi_i, phi_j, mask_i, mask_j, log_eps, n_jobs, generators):
    """
    Computes Omega_ij(c) = exp(phi_i(c)) @ exp(-phi_j(c)) at all points in the overlap mask.

    Returns:
        Omega_ij   : (H, W, K, K)
        Omega_ij⁻¹ : (H, W, K, K)
    """
    mask_i = mask_i.astype(bool)
    mask_j = mask_j.astype(bool)
    overlap = mask_i & mask_j

    H, W = mask_i.shape
    K = generators.shape[1]
    full_shape = (H, W, K, K)

    if not np.any(overlap):
        return np.zeros(full_shape), np.zeros(full_shape)

    # Extract overlap φ fields
    phi_i_ov = phi_i[overlap]
    phi_j_ov = phi_j[overlap]

    # Compute batched transport operator
    Omega_ij = build_inter_agent_omega(phi_i_ov, phi_j_ov, generators)

    # Compute inverse (optional: stabilize)
    Omega_inv = np.linalg.inv(Omega_ij)

    # Fill into full spatial arrays
    Omega_full = np.zeros(full_shape)
    Omega_inv_full = np.zeros(full_shape)
    Omega_full[overlap] = Omega_ij
    Omega_inv_full[overlap] = Omega_inv

    return Omega_full, Omega_inv_full


def get_all_Omega_fields(agents, phi_belief_field, phi_model_field, mask_field, log_eps, n_jobs, generators):
    """
    Compute all belief and model Ω_{ij} and their inverses, per point and per pair (i, j).
    Returns 4 lists: Ω_bel, Ω_bel⁻¹, Ω_model, Ω_model⁻¹, each of length N.
    """
    N = len(agents)
    O_bel, O_inv, O_mod, O_mod_inv = [], [], [], []

    for i, A in enumerate(agents):
        phi_i_bel  = getattr(A, phi_belief_field)
        phi_i_mod  = getattr(A, phi_model_field)
        mask_i     = getattr(A, mask_field)

        Omega_bel_i, Omega_inv_bel_i = {}, {}
        Omega_mod_i, Omega_inv_mod_i = {}, {}

        for nb in A.neighbors:
            j = nb["id"]
            B = agents[j]

            phi_j_bel = getattr(B, phi_belief_field)
            phi_j_mod = getattr(B, phi_model_field)
            mask_j    = getattr(B, mask_field)

            Omega_bel, Omega_bel_inv = compute_pairwise_Omega(
                phi_i_bel, phi_j_bel, mask_i, mask_j, log_eps, n_jobs, generators
            )
            Omega_mod, Omega_mod_inv = compute_pairwise_Omega(
                phi_i_mod, phi_j_mod, mask_i, mask_j, log_eps, n_jobs, generators
            )

            Omega_bel_i[j]     = Omega_bel
            Omega_inv_bel_i[j] = Omega_bel_inv
            Omega_mod_i[j]     = Omega_mod
            Omega_inv_mod_i[j] = Omega_mod_inv

        O_bel.append(Omega_bel_i)
        O_inv.append(Omega_inv_bel_i)
        O_mod.append(Omega_mod_i)
        O_mod_inv.append(Omega_inv_mod_i)

    return O_bel, O_inv, O_mod, O_mod_inv

