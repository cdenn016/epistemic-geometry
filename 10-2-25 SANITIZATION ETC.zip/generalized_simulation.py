# generalized_simulation.py
import os
os.environ["OMP_NUM_THREADS"] = "1"
os.environ["MKL_NUM_THREADS"] = "1"
os.environ["NUMEXPR_NUM_THREADS"] = "1"
os.environ["OPENBLAS_NUM_THREADS"] = "1"
import sys
ROOT = os.path.dirname(os.path.abspath(__file__))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)
from pathlib import Path
import sys, time, shutil, multiprocessing as _mp, numpy as np
import core.config as config

from updates.update_rules import synchronous_step
from core.transport_cache import ensure_global_A
from diagnostics import compute_total_action, print_action_breakdown, compute_global_metrics, print_beta_summary
from metrics_viz import VizConfig, MetricsViz
from core.get_generators import casimir_scalar
from runtime_context import ensure_runtime_defaults,build_step_settings_from_overrides, cfg_get 
from utils import mean_norm, _aid
from run_sim_utils import (
    prepare_generators, initialize_or_resume,
    log_and_viz_after_step,
    wrap_epilogue, save_step
)
from runtime_context import energy_acc_reset



def run_simulation(
    outdir="checkpoints",
    resume=False,
    log_metrics=True,
    log_fields=True,
    num_cores=None,
    fresh_outdir=False,
    clear_agent_logs=True,
    runtime_ctx=None,
):
    

    # ---------- cores ----------
    _avail = max(1, (_mp.cpu_count() or 1) - 1)
    num_cores = max(1, _avail if num_cores is None else int(num_cores))

    # ---------- runtime ctx ----------
    runtime_ctx = ensure_runtime_defaults(runtime_ctx)

    # AFTER ctx exists, it's safe to read cfg:
    print_action_every = int(cfg_get(runtime_ctx, "print_action_every", 1))

    # Seed ctx.config from module config once, then layer runtime entries
    base_cfg = {k: getattr(config, k) for k in dir(config) if not k.startswith("_")}
    rcfg = dict(base_cfg)
    rcfg["n_jobs"] = num_cores
    runtime_ctx.config = rcfg

    # ---------- generators (ctx-driven) ----------
    # prepare_generators should read sizes/irreps from ctx/config
    G_q, G_p = prepare_generators(runtime_ctx)
    Kq, Kp = int(np.asarray(G_q).shape[1]), int(np.asarray(G_p).shape[1])

    # ---------- init or resume ----------
    t0 = time.perf_counter()

    if fresh_outdir and not resume and os.path.isdir(outdir):
        shutil.rmtree(outdir, ignore_errors=True)
    os.makedirs(outdir, exist_ok=True)

    
    agents, step_start = initialize_or_resume(outdir, resume, runtime_ctx,
                                              clear_agent_logs=clear_agent_logs)
    print(f"[TIMER] initialize_or_resume: {time.perf_counter() - t0:.3f}s")

    # ---------- runtime ctx bootstrapping ----------
    runtime_ctx.global_step = step_start
    runtime_ctx.children_latest = agents

    vizcfg = VizConfig(
        outdir=Path(outdir),
        run_name="runs",
        legend_label=f"ell_q={cfg_get(runtime_ctx, 'ell_q', 3)}",
        plot_every_steps=1,
        snapshot_every_steps=100,
    )

    mv = MetricsViz(vizcfg)
    meta_generators = {
        "Kq": Kq, "Kp": Kp,
        "casimir_total_q": casimir_scalar(G_q),
        "casimir_total_p": casimir_scalar(G_p),
    }
    mv.start_run(meta=meta_generators)
    runtime_ctx.viz = mv

    # ---------- global A (M-D) ----------
    # Prefer the actual agent shape (robust on resume), else fall back to config:
    S_agents = agents[0].spatial_shape
    
    # assert tuple(S_agents) == tuple(S_cfg), "Agent grid != config grid?"
    A_init_scale = cfg_get(runtime_ctx, "A_init_scale", getattr(config, "A_init_scale", 0.0))
    ensure_global_A(runtime_ctx, spatial_shape=S_agents, init_scale=A_init_scale)

    # ---------- step range ----------
    total_steps = int(cfg_get(runtime_ctx, "steps", getattr(config, "steps", 0)))
    if step_start >= total_steps:
        wrap_epilogue(runtime_ctx, agents, outdir, [], [])
        print("[DONE] Nothing to do: resume step >= total steps.")
        return agents, []

    # ---------- loop ----------
    parent_metrics, metric_log = [], []
    print(f"[RUN] Starting simulation at step {step_start} with {num_cores} cores")

    for step in range(step_start, total_steps):
        runtime_ctx.global_step = step
        energy_acc_reset(runtime_ctx, "align_q_sum", "align_p_sum")
        runtime_ctx.timings = {}

        # pull fresh per-step settings by overlaying ctx.config on module defaults
        runtime_ctx.step_cfg = build_step_settings_from_overrides(
            config, getattr(runtime_ctx, "config", {})
        )

        print(f"\n[STEP {step}] -----------------------------\n")

        # core synchronous update (ctx-driven)
        t0 = time.perf_counter()
        agents = synchronous_step(
            agents, G_q, G_p,
            n_jobs=num_cores,
            runtime_ctx=runtime_ctx,
        )
        print(f"\n[TIMER] synchronous_step: {time.perf_counter() - t0:.3f}s")

        # viz & metrics
        runtime_ctx.children_latest = agents

        t0 = time.perf_counter()
        M_geom = compute_global_metrics(runtime_ctx, agents)
        Q = compute_total_action(runtime_ctx, agents, precomputed_metrics=M_geom)
        print_beta_summary(runtime_ctx, agents)
        print(f"[TIMER] compute_total_action/global metrics: {time.perf_counter() - t0:.3f}s\n")

        if (step % print_action_every) == 0:
            print_action_breakdown(runtime_ctx, Q)

        t0 = time.perf_counter()
        log_and_viz_after_step(runtime_ctx, agents, step, outdir,
                               parent_metrics, metric_log, num_cores,
                               precomputed_metrics=M_geom,
                               precomputed_Q=Q)
        print(f"\n[TIMER] log_and_viz_after_step: {time.perf_counter() - t0:.3f}s")

        # global row (reuse the same precomputed values)
        E_tot = Q.get("Action_total", np.nan)
        gmetrics = {
            "E_total": float(E_tot) if np.isfinite(E_tot) else np.nan,
            "mean_total": float(M_geom.get("mean_total", np.nan)),
            **Q,
        }
        mv.log_global(step, gmetrics)

        # per-agent rows
        for a in agents:
            mv.log_agent(step, _aid(a), {
                "phi_norm_mean":       mean_norm(getattr(a, "phi", None)),
                "phi_model_norm_mean": mean_norm(getattr(a, "phi_model", None)),
            })

        # persist + visualize
        t0 = time.perf_counter()
        mv.maybe_flush(step)
        mv.maybe_plot(step)
        mv.maybe_snapshot(step, runtime_ctx, agents)
        print(f"[TIMER] viz_flush/plot/snapshot: {time.perf_counter() - t0:.3f}s")

        t0 = time.perf_counter()
        save_step(agents, outdir, step)
        print(f"[TIMER] save_step: {time.perf_counter() - t0:.3f}s")
        print(f"\n[SAVE] Checkpoint --> {outdir}/step_{step:04d}.pkl")

    # ---------- epilogue ----------
    wrap_epilogue(runtime_ctx, agents, outdir, parent_metrics, metric_log)
    mv.end_run()

    print("[DONE] Simulation completed.")
    return agents, metric_log


if __name__ == "__main__":
    
    run_simulation()



