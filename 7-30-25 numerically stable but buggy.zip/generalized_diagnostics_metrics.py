# Standard library
import os
# Third-party libraries
import numpy as np
from generalized_omega import (exp_lie_algebra_irrep, batch_apply_omega,
                              compute_field_strength)
from get_generators import get_generators 
from joblib import Parallel, delayed

import config
from pathlib import Path

from generalized_math_utils import kl_divergence, laplacian_field  # ← make sure this is imported
from mask_utils import (
    get_support_mask,
    get_overlap_mask,
    expand_mask_for_mu,
    expand_mask_for_sigma,
    apply_mask_mu,
    apply_mask_sigma,
    apply_mask_phi,
    norm_over_mask,
    masked_norm,
    threshold_mask
)
from bundle_morphism_utils import safe_batch_apply_morphism_nat


#==================================================================================
#
#                  Fields
#
#==================================================================================
def compute_kl_qp_field(mu_q_field, sigma_q_field,
                        mu_p_field, sigma_p_field,
                        morphism_p_to_q, mask, log_eps=1e-8):
    """
    Compute KL[q || Φ̃·p] over a spatial grid with fibers K_q ≠ K_p.

    Args:
        mu_q_field:      (H, W, K_q)
        sigma_q_field:   (H, W, K_q, K_q)
        mu_p_field:      (H, W, K_p)
        sigma_p_field:   (H, W, K_p, K_p)
        morphism_p_to_q: (H, W, K_q, K_p)
        mask:            (H, W) — support mask
        log_eps:         ε for numerical stability

    Returns:
        kl_field:        (H, W) — pointwise KL[q || Φ̃·p]
    """
    H, W = mask.shape
    K_q = mu_q_field.shape[-1]
    K_p = mu_p_field.shape[-1]

    assert morphism_p_to_q.shape == (H, W, K_q, K_p)

    # Step 1: Project p → q fiber via Φ̃
    mu_p_proj, sigma_p_proj = safe_batch_apply_morphism_nat(
        mu_p_field, sigma_p_field, morphism_p_to_q, eps=log_eps
    )  # → (H, W, K_q), (H, W, K_q, K_q)

    # Step 2: Build valid support mask
    support = mask > config.support_cutoff_eps
    if not np.any(support):
        return np.zeros((H, W), dtype=np.float32)

    # Step 3: Extract valid points
    mu_q = mu_q_field[support]
    Σ_q  = sigma_q_field[support]
    mu_p = mu_p_proj[support]
    Σ_p  = sigma_p_proj[support]

    # Step 4: Sanitize
    Σ_q = sanitize_sigma(Σ_q, eps=log_eps)
    Σ_p = sanitize_sigma(Σ_p, eps=log_eps)

    # Step 5: Compute KL[q || Φ̃·p]
    kl_vals = kl_divergence(mu_q, Σ_q, mu_p, Σ_p, log_eps=log_eps)
    kl_vals = np.where(np.isfinite(kl_vals), kl_vals, 0.0)

    # Step 6: Reconstruct full field
    kl_field = np.zeros((H, W), dtype=kl_vals.dtype)
    kl_field[support] = kl_vals
    return kl_field




def compute_kl_pq_field(mu_p_field, sigma_p_field,
                        mu_q_field, sigma_q_field,
                        morphism_q_to_p,  # Φ : B_q → B_p
                        mask, log_eps=1e-8):
    """
    Compute KL[p || Φ·q] per point by projecting q into the model fiber via Φ.

    Args:
        mu_p_field:      (H, W, K_p)
        sigma_p_field:   (H, W, K_p, K_p)
        mu_q_field:      (H, W, K_q)
        sigma_q_field:   (H, W, K_q, K_q)
        morphism_q_to_p: (H, W, K_p, K_q) — Φ
        mask:            (H, W)
        log_eps:         numerical stabilizer

    Returns:
        kl_field:        (H, W) — KL divergence at each valid grid point
    """
    H, W = mask.shape
    K_p = mu_p_field.shape[-1]
    K_q = mu_q_field.shape[-1]

    assert morphism_q_to_p.shape == (H, W, K_p, K_q), \
        f"[compute_kl_pq_field] morphism shape mismatch: got {morphism_q_to_p.shape}, expected {(H, W, K_p, K_q)}"

    # Step 1: Project q → p via Φ
    mu_q_proj, sigma_q_proj = safe_batch_apply_morphism_nat(
        mu_q_field, sigma_q_field, morphism_q_to_p, eps=log_eps
    )  # → (H, W, K_p), (H, W, K_p, K_p)

    # Step 2: Restrict to supported region
    support = mask > config.support_cutoff_eps
    if not np.any(support):
        return np.zeros((H, W), dtype=np.float32)

    mu_p_flat     = mu_p_field[support]
    sigma_p_flat  = sigma_p_field[support]
    mu_q_flat     = mu_q_proj[support]
    sigma_q_flat  = sigma_q_proj[support]

    # Step 3: Sanitize
    sigma_p_flat = sanitize_sigma(sigma_p_flat, eps=log_eps)
    sigma_q_flat = sanitize_sigma(sigma_q_flat, eps=log_eps)

    # Step 4: KL[p || Φ·q]
    kl_vals = kl_divergence(mu_p_flat, sigma_p_flat, mu_q_flat, sigma_q_flat, log_eps=log_eps)
    kl_vals = np.where(np.isfinite(kl_vals), kl_vals, 0.0)

    # Step 5: Reconstruct KL field
    kl_field = np.zeros((H, W), dtype=kl_vals.dtype)
    kl_field[support] = kl_vals
    return kl_field




def compute_alignment_field_general(
    agents, i, field_type="belief",
    eps=config.support_cutoff_eps,
    log_eps=config.log_eps
) -> np.ndarray:
    """
    Compute spatial KL field KL[q_i(c) || Ω_ij · q_j(c)] for agent i.

    Projects neighbor fields into i's gauge frame using Ω = exp(φ_i) · exp(−φ_j),
    applies to either belief (q) or model (p) fields. KL is computed at each spatial
    overlap point with neighbors, and averaged across neighbors.

    Note: This version uses moment (μ, Σ) frame transport — not natural geometry.
    Use for visualization or spatial diagnostics, not variational gradients.

    Returns:
        (H, W) array — per-pixel average KL divergence field
    """
    A = agents[i]
    mask_i = threshold_mask(A.mask, eps)
    if not np.any(mask_i) or not A.neighbors:
        return np.zeros_like(mask_i, dtype=np.float32)

    H, W = A.mask.shape
    kl_accum = np.zeros((H, W), dtype=np.float32)
    n_nb_at = np.zeros((H, W), dtype=np.int32)

    # Select fields and generators
    if field_type == "belief":
        mu_i     = A.mu_q_field
        sigma_i  = A.sigma_q_field
        phi_i    = A.phi
        K        = config.K_q
    elif field_type == "model":
        mu_i     = A.mu_p_field
        sigma_i  = A.sigma_p_field
        phi_i    = A.phi_model
        K        = config.K_p
    else:
        raise ValueError(f"[compute_alignment_field_general] Invalid field_type: '{field_type}'")

    generators = get_generators(config.group_name, K)

    def to_full(σ):
        return np.einsum("mk,ij->mij", σ**2, np.eye(K)) if σ.ndim == 2 else σ

    for nb in A.neighbors:
        B = agents[nb["id"]]
        mask_j = threshold_mask(B.mask, eps)
        overlap = mask_i & mask_j
        if not np.any(overlap):
            continue

        idx = np.argwhere(overlap)
        i_idx, j_idx = idx[:, 0], idx[:, 1]

        mu_j    = B.mu_q_field if field_type == "belief" else B.mu_p_field
        sigma_j = B.sigma_q_field if field_type == "belief" else B.sigma_p_field
        phi_j   = B.phi if field_type == "belief" else B.phi_model

        mu_i_pts    = mu_i[overlap]
        sigma_i_pts = to_full(sigma_i[overlap])
        mu_j_pts    = mu_j[overlap]
        sigma_j_pts = to_full(sigma_j[overlap])

        O_i     = exp_lie_algebra_irrep(phi_i[overlap], generators)
        O_j_inv = exp_lie_algebra_irrep(-phi_j[overlap], generators)
        Omega   = np.einsum("mab,mbc->mac", O_i, O_j_inv)

        mu_j_t = np.einsum("mab,mb->ma", Omega, mu_j_pts)
        sigma_j_t = np.einsum("mab,mbc,mcd->mad", Omega, sigma_j_pts, Omega)

        # After transporting σ_j:
       
        sigma_j_t = sanitize_sigma(sigma_j_t, eps=log_eps)

        kl_vals = kl_divergence(mu_i_pts, sigma_i_pts, mu_j_t, sigma_j_t, log_eps=log_eps)
        kl_vals = np.where(np.isfinite(kl_vals), kl_vals, 0.0)

        np.add.at(kl_accum, (i_idx, j_idx), kl_vals)
        np.add.at(n_nb_at,  (i_idx, j_idx), 1)

    out = np.zeros_like(kl_accum, dtype=np.float32)
    valid = n_nb_at > 0
    out[valid] = kl_accum[valid] / n_nb_at[valid]
    return out * mask_i




def compute_pairwise_kl_belief(agents, generators_q, params, return_pointwise=False):
    """
    Compute KL[q_i || Ω_ij · q_j] for all (i, j) pairs.

    Args:
        agents           : list of Agent objects
        generators_q     : (d, K_q, K_q) Lie algebra basis for beliefs
        params           : dict with 'log_eps' and 'overlap_eps'
        return_pointwise : if True, returns full per-point KL maps

    Returns:
        kl_matrix        : (N, N)
        pointwise        : (optional) {(i,j): KL_field}
    """
    from generalized_omega import batch_apply_omega, compute_inter_omega_fieldwise
    from numerical_utils import sanitize_sigma

    log_eps = params.get("log_eps", 1e-8)
    eps     = params.get("overlap_eps", 1e-6)
    N       = len(agents)
    kl_matrix = np.full((N, N), np.nan)
    pointwise = {} if return_pointwise else None

    for i, A in enumerate(agents):
        mask_i = A.mask > eps
        for j, B in enumerate(agents):
            if i == j:
                kl_matrix[i, j] = 0.0
                continue

            mask_j = B.mask > eps
            overlap = mask_i & mask_j
            if not np.any(overlap):
                continue

            mu_i = A.mu_q_field[overlap]
            sigma_i = A.sigma_q_field[overlap]
            mu_j = B.mu_q_field[overlap]
            sigma_j = B.sigma_q_field[overlap]

            phi_i = A.phi[overlap]
            phi_j = B.phi[overlap]

            Omega_ij = compute_inter_omega_fieldwise(phi_i, phi_j, generators_q, group_name=params.get("group_name", "sl2r"))

            mu_j_t, sigma_j_t = batch_apply_omega(mu_j, sigma_j, Omega_ij)

            sigma_i = sanitize_sigma(sigma_i, eps=log_eps)
            sigma_j_t = sanitize_sigma(sigma_j_t, eps=log_eps)
            kl_vals = kl_divergence(mu_i, sigma_i, mu_j_t, sigma_j_t)

            kl_matrix[i, j] = float(np.mean(kl_vals))
            if return_pointwise:
                pw_field = np.zeros(mask_i.shape)
                pw_field[overlap] = kl_vals
                pointwise[(i, j)] = pw_field

    return (kl_matrix, pointwise) if return_pointwise else kl_matrix


def compute_pairwise_kl_model(agents, generators_p, params, return_pointwise=False):
    """
    Compute KL[p_i || Ω̃_ij · p_j] for all (i, j) pairs.

    Args:
        agents           : list of Agent objects
        generators_p     : (d, K_p, K_p) Lie algebra basis for models
        params           : dict with 'log_eps' and 'overlap_eps'
        return_pointwise : if True, returns full per-point KL maps

    Returns:
        kl_matrix        : (N, N)
        pointwise        : (optional) {(i,j): KL_field}
    """
    from generalized_omega import batch_apply_omega, compute_inter_omega_fieldwise
    from numerical_utils import sanitize_sigma

    log_eps = params.get("log_eps", 1e-8)
    eps     = params.get("overlap_eps", 1e-6)
    N       = len(agents)
    kl_matrix = np.full((N, N), np.nan)
    pointwise = {} if return_pointwise else None

    for i, A in enumerate(agents):
        mask_i = A.mask > eps
        for j, B in enumerate(agents):
            if i == j:
                kl_matrix[i, j] = 0.0
                continue

            mask_j = B.mask > eps
            overlap = mask_i & mask_j
            if not np.any(overlap):
                continue

            mu_i = A.mu_p_field[overlap]
            sigma_i = A.sigma_p_field[overlap]
            mu_j = B.mu_p_field[overlap]
            sigma_j = B.sigma_p_field[overlap]

            phi_i = A.phi_model[overlap]
            phi_j = B.phi_model[overlap]

            Omega_ij = compute_inter_omega_fieldwise(phi_i, phi_j, generators_p, group_name=params.get("group_name", "sl2r"))

            mu_j_t, sigma_j_t = batch_apply_omega(mu_j, sigma_j, Omega_ij)

            sigma_i = sanitize_sigma(sigma_i, eps=log_eps)
            sigma_j_t = sanitize_sigma(sigma_j_t, eps=log_eps)
            kl_vals = kl_divergence(mu_i, sigma_i, mu_j_t, sigma_j_t)

            kl_matrix[i, j] = float(np.mean(kl_vals))
            if return_pointwise:
                pw_field = np.zeros(mask_i.shape)
                pw_field[overlap] = kl_vals
                pointwise[(i, j)] = pw_field

    return (kl_matrix, pointwise) if return_pointwise else kl_matrix

def compute_entropy_field(sigma_field, mask, log_eps=1e-8):
    """
    Compute per-cell entropy H[q(c)] for Gaussian fields over space.

    Args:
        sigma_field : (H, W, K) or (H, W, K, K) — stddev or full covariance
        mask        : (H, W) bool — support region
        log_eps     : stabilizer for log and inverse

    Returns:
        H_field     : (H, W) entropy values, 0 outside mask
    """
    H, W = mask.shape
    if sigma_field.ndim == 3:
        # Diagonal Σ (σ²)
        var = np.clip(sigma_field**2, log_eps, None)     # (H,W,K)
        log_det = np.sum(np.log(var), axis=-1)           # (H,W)
        K = sigma_field.shape[-1]
    else:
        # Full Σ
        K = sigma_field.shape[-1]
        log_det = np.zeros((H, W), dtype=float)
        for i in range(H):
            for j in range(W):
                if not mask[i, j]:
                    continue
                Σ = sigma_field[i, j] + log_eps * np.eye(K)
                sign, ld = safe_logdet(Σ)
                log_det[i, j] = ld if sign > 0 else np.nan

    H_field = 0.5 * (K * np.log(2 * np.pi * np.e) + log_det)
    H_field[~mask] = 0.0
    return H_field

from numerical_utils import safe_logdet
#====================================================================
#
#                 Energy Fields
#
#====================================================================



def compute_self_energy(agent, log_eps, cfg):
    """
    Compute KL(q_i || Φ̃ · p_i) as a spatial field by applying the morphism
    and computing KL directly, all in one go.
    """
    return cfg["alpha"] * compute_kl_qp_field(
        mu_q_field    = agent.mu_q_field,
        sigma_q_field = agent.sigma_q_field,
        mu_p_field    = agent.mu_p_field,
        sigma_p_field = agent.sigma_p_field,
        morphism_p_to_q = agent.bundle_morphism_p_to_q,
        mask          = agent.mask,
        log_eps       = log_eps
    )

def compute_feedback_energy(agent, log_eps, cfg):
    """
    Compute KL(p_i || Φ · q_i) as a spatial field via morphism projection.
    """
    return cfg["feedback_weight"] * compute_kl_pq_field(
        mu_p_field     = agent.mu_p_field,
        sigma_p_field  = agent.sigma_p_field,
        mu_q_field     = agent.mu_q_field,
        sigma_q_field  = agent.sigma_q_field,
        morphism_q_to_p = agent.bundle_morphism_q_to_p,
        mask           = agent.mask,
        log_eps        = log_eps
    )

def compute_curvature_energy_field(phi_field, mask, weight, lie_gens, support_eps=1e-4, debug=False):
    """
    Compute curvature energy: weight × ∑_x Tr[F_{μν}(x)^2] over valid mask.

    Args:
        phi_field   : (H, W, d)     — φ or φ_model field in Lie algebra coords
        mask        : (H, W)        — agent support mask
        weight      : float         — energy weight coefficient
        lie_gens    : (d, K, K)     — Lie algebra generators
        support_eps : float         — minimum support threshold
        debug       : bool          — optional print/debug info

    Returns:
        energy      : float         — weighted curvature energy
        raw_total   : float         — ∑ Tr[F²] over support (unweighted)
    """
    F_dict = compute_field_strength(phi_field, lie_gens)  # dict of F_xy, F_yz, etc.
    support = mask > support_eps

    total = 0.0
    for key, val in F_dict.items():
        if val.ndim == 2:
            total += val**2
        elif val.ndim == 3:
            total += np.sum(val**2, axis=-1)  # vector norm²
        elif val.ndim == 4:
            total += np.sum(val**2, axis=(-2, -1))  # Frobenius norm²
        else:
            raise ValueError(f"[ERROR] Unexpected F_{key} shape: {val.shape}")

    raw_total = float(np.sum(total[support]))
    if debug:
        print(f"[φ_curv] Raw: {raw_total:.4f} | Weighted: {weight * raw_total:.4f}")

    return weight * raw_total, raw_total

def compute_laplacian_field_energy(phi):
    """
    Return the Laplacian energy density ‖Δφ(x)‖² at each point.

    Args:
        phi : (H, W, d) — Lie algebra field

    Returns:
        (H, W) — spatial energy density field
    """
    lap = laplacian_field(phi)  # (H, W, d)
    return np.sum(lap**2, axis=-1)  # (H, W)

def compute_mass_field_energy(phi):
    """
    Return the mass energy density ‖φ(x)‖² at each point.

    Args:
        phi : (H, W, d)

    Returns:
        (H, W) — spatial energy density field
    """
    return np.sum(phi**2, axis=-1)

def compute_phi_coupling_field_energy(phi_q, phi_p, morphism_q_to_p):
    """
    Return pointwise coupling energy ‖Φ φ_q Φ⁻¹ − φ_p‖² at each point.

    Args:
        phi_q           : (H, W, d_q)
        phi_p           : (H, W, d_p)
        morphism_q_to_p : (H, W, K_p, K_q)

    Returns:
        (H, W) — spatial coupling energy field
    """
    from bundle_morphism_utils import gauge_covariant_transform_phi

    phi_q_trans = gauge_covariant_transform_phi(phi_q, morphism_q_to_p)
    assert phi_q_trans.shape == phi_p.shape, "Shape mismatch after morphism transform"

    return np.sum((phi_q_trans - phi_p)**2, axis=-1)




#===================================================================
#
#            Scalar Energies
#
#===================================================================

def compute_self_energy_scalar(agent, log_eps, cfg):
    """
    Compute total weighted KL(q_i || Φ̃ · p_i), scalar output for energy.
    """
    kl_field = compute_self_energy(agent, log_eps, cfg)
    agent.e_self_field = kl_field  # Optional: store for diagnostics

    # Mask invalid or zero-support regions
    valid_mask = (agent.mask > cfg.get("support_cutoff_eps", 1e-3)) & np.isfinite(kl_field)
    total_energy = float(np.sum(kl_field[valid_mask]))

    return total_energy

def compute_feedback_energy_scalar(agent, log_eps, cfg):
    """
    Compute total weighted KL(p_i || Φ · q_i) — returns scalar feedback energy.
    """
    kl_field = compute_feedback_energy(agent, log_eps, cfg)
    agent.e_feedback_field = kl_field  # Optional caching

    valid_mask = (agent.mask > cfg.get("support_cutoff_eps", 1e-3)) & np.isfinite(kl_field)
    total_energy = float(np.sum(kl_field[valid_mask]))

    return total_energy


def compute_alignment_energy_general(
    i, agent_i, field_list, mask_list,
    Omega_list, Omega_inv_list,
    weight,
    log_eps=config.log_eps,
    field_type="belief"
) -> float:
    """
    Compute ∑_j weight * D_KL(field_i || Ω_ij · field_j), with safety and natural gradient compatibility.

    Args:
        i              : index of agent_i
        agent_i        : agent_i object
        field_list     : list of (mu, sigma) tuples for each agent
        mask_list      : list of masks for each agent
        Omega_list     : list of Ω fields for each agent
        Omega_inv_list : list of Ω⁻¹ fields for each agent
        weight         : scalar weight coefficient
        log_eps        : stabilizer for log det
        field_type     : "belief" or "model" (for debugging only)

    Returns:
        total_energy   : ∑_j weight · D_KL(μ_i, Σ_i || Ω_ij·(μ_j, Σ_j))
    """
    μ_i, Σ_i = field_list[i]
    mask_i = mask_list[i]
    support_i = mask_i > config.support_cutoff_eps

    total_energy = 0.0
    for nb in agent_i.neighbors:
        j = nb["id"]
        μ_j, Σ_j = field_list[j]
        mask_j   = mask_list[j]
        support_j = mask_j > config.support_cutoff_eps

        overlap = support_i & support_j
        if not np.any(overlap):
            continue

        Ω_ij = np.einsum("mab,mbc->mac", Omega_list[i][overlap], Omega_inv_list[j][overlap])
        μ_j_t, Σ_j_t = batch_apply_omega(μ_j[overlap], Σ_j[overlap], Ω_ij)

        μ_i_pts = μ_i[overlap]
        Σ_i_pts = Σ_i[overlap]

        kl_vals = kl_divergence(μ_i_pts, Σ_i_pts, μ_j_t, Σ_j_t, log_eps=log_eps)
        kl_vals = np.where(np.isfinite(kl_vals), kl_vals, 0.0)

        total_energy += weight * float(np.sum(kl_vals))

    return total_energy



def entropy_total(sigma_field, mask, log_eps=1e-8):
    """
    Total entropy ∑ H[q(c)] over the masked domain.
    """
    H = compute_entropy_field(sigma_field, mask, log_eps)
    return float(np.nansum(H))



def compute_laplacian_energy(phi, mask, weight):
    """
    Compute Laplacian regularization energy:
        E = weight * ∫_mask ‖Δφ‖²

    Args:
        phi   : (H, W, d) Lie algebra field
        mask  : (H, W) bool array
        weight: float

    Returns:
        float — scalar energy term
    """
    lap = laplacian_field(phi)  # (H, W, d)
    norms_sq = np.sum(lap**2, axis=-1)  # (H, W)
    return float(weight * np.sum(norms_sq[mask > 0]))


def compute_mass_energy(phi, mask, weight):
    """
    Compute mass regularization energy:
        E = weight * ∫_mask ‖φ‖²

    Args:
        phi   : (H, W, d) Lie algebra field
        mask  : (H, W) bool array
        weight: float

    Returns:
        float — scalar energy term
    """
    norms_sq = np.sum(phi**2, axis=-1)
    return float(weight * np.sum(norms_sq[mask > 0]))


def compute_phi_coupling_energy(
    phi_q, phi_p, morphism_q_to_p, mask, weight
):
    """
    Compute coupling energy ∫ ‖dΦ · φ_q · dΦ⁻¹ − φ_p‖² over the mask.

    Args:
        phi_q         : (H, W, d_q)
        phi_p         : (H, W, d_p)
        morphism_q_to_p : (H, W, K_p, K_q) — bundle morphism Φ: B_q → B_p
        mask          : (H, W)
        weight        : float

    Returns:
        float — scalar coupling energy
    """
    from bundle_morphism_utils import gauge_covariant_transform_phi

    # Transform phi_q into model frame
    phi_q_trans = gauge_covariant_transform_phi(phi_q, morphism_q_to_p)

    # Match shape
    assert phi_q_trans.shape == phi_p.shape, "Shape mismatch after morphism transform"

    diff_sq = np.sum((phi_q_trans - phi_p)**2, axis=-1)
    return float(weight * np.sum(diff_sq[mask > 0]))


def compute_curvature_energy(phi_field, mask, weight, lie_gens, support_eps=1e-4, debug=False):
    """
    Compute curvature energy: weight × ∑_x Tr[F_{μν}(x)^2] over valid mask.

    Args:
        phi_field   : (H, W, d)     — φ or φ_model field in Lie algebra coords
        mask        : (H, W)        — agent support mask
        weight      : float         — energy weight coefficient
        lie_gens    : (d, K, K)     — Lie algebra generators
        support_eps : float         — minimum support threshold
        debug       : bool          — optional print/debug info

    Returns:
        energy      : float         — weighted curvature energy
        raw_total   : float         — ∑ Tr[F²] over support (unweighted)
    """
    F_dict = compute_field_strength(phi_field, lie_gens)  # dict of F_xy, F_yz, etc.
    support = mask > support_eps

    total = 0.0
    for key, val in F_dict.items():
        if val.ndim == 2:
            total += val**2
        elif val.ndim == 3:
            total += np.sum(val**2, axis=-1)  # vector norm²
        elif val.ndim == 4:
            total += np.sum(val**2, axis=(-2, -1))  # Frobenius norm²
        else:
            raise ValueError(f"[ERROR] Unexpected F_{key} shape: {val.shape}")

    raw_total = float(np.sum(total[support]))
    if debug:
        print(f"[φ_curv] Raw: {raw_total:.4f} | Weighted: {weight * raw_total:.4f}")

    return weight * raw_total, raw_total


#==========================================================================
#
#               Logging
#
#===========================================================================



def zero_agent_metrics() -> dict:
    return {
        "e_self": 0.0,
        "e_feedback": 0.0,
        "e_align": 0.0,
        "e_mod_align": 0.0,
        "e_curv": 0.0,
        "e_curv_mod": 0.0,
        "e_mass": 0.0,
        "e_mass_mod": 0.0,
        "phi_norm": 0.0,
        "phi_model_norm": 0.0,
    }


def compute_all_agent_metrics(
    i, A, Q_list, P_list, Mask_list,
    O_bel, O_inv, O_mod, O_mod_inv,
    cfg, generators, log_eps
):
    gen_q, gen_p = generators
    mask = Mask_list[i]

    stats = {
        "e_self": compute_self_energy_scalar(A, log_eps, cfg),
        "e_feedback": compute_feedback_energy_scalar(A, log_eps, cfg),

        "e_align": compute_alignment_energy_general(
            i=i,
            agent_i=A,
            field_list=Q_list,
            mask_list=Mask_list,
            Omega_list=O_bel,
            Omega_inv_list=O_inv,
            weight=cfg["beta"],
            log_eps=log_eps,
            field_type="belief"
        ),

        "e_mod_align": compute_alignment_energy_general(
            i=i,
            agent_i=A,
            field_list=P_list,
            mask_list=Mask_list,
            Omega_list=O_mod,
            Omega_inv_list=O_mod_inv,
            weight=cfg["beta_model"],
            log_eps=log_eps,
            field_type="model"
        ),

        "e_curv": 0.0,
        "e_curv_mod": 0.0,
        "e_mass":0.0,
        "e_mass_mod": 0.0,
        "phi_norm": np.linalg.norm(A.phi[mask], axis=-1).sum(),
        "phi_model_norm": np.linalg.norm(A.phi_model[mask], axis=-1).sum()
    }
    if cfg["belief_mass"] > 0:
        stats["e_mass"] = cfg["belief_mass"] * np.sum(np.sum(A.phi[mask]**2, axis=-1))
       # print(f"[belief] mass energy = {stats['e_mass']:.6f}")

    if cfg["model_mass"] > 0:
        stats["e_mass_mod"] = cfg["model_mass"] * np.sum(np.sum(A.phi_model[mask]**2, axis=-1))
       # print(f"[model]  mass energy = {stats['e_mass_mod']:.6f}")

    if cfg["curvature_weight"] > 0:
        stats["e_curv"], _ = compute_curvature_energy(A.phi, mask, cfg["curvature_weight"], gen_q)
       # print(f"[belief] curvature energy = {stats['e_curv']:.6f}")

    if cfg["curvature_weight"] > 0:
        stats["e_curv_mod"], _ = compute_curvature_energy(A.phi_model, mask, cfg["model_curvature_weight"], gen_p)
       # print(f"[model]  curvature energy = {stats['e_curv_mod']:.6f}")


    return stats


def compute_agent_metrics(
    i: int,
    agent,
    Q_list, P_list, Mask_list,
    O_bel, O_inv, O_mod, O_mod_inv,
    cfg, gens, log_eps
) -> tuple[int, dict]:
    """
    Compute all variational energy terms and norms for a single agent.

    Returns:
        (i, stats) where stats is a dict of per-agent scalar metrics.
    """
    mask = Mask_list[i]
    if not np.any(mask):
        return i, zero_agent_metrics()

    stats = compute_all_agent_metrics(
        i, agent, Q_list, P_list, Mask_list,
        O_bel, O_inv, O_mod, O_mod_inv,
        cfg, gens, log_eps
    )
    return i, stats


def log_agent_metrics(agent, step: int, stats: dict, support: float):
    """
    Log normalized metrics to a single agent.
    """
    S = support if support > 0 else 1.0
    log_dict = {
        "kl_self":           stats["e_self"]      / S,
        "kl_feedback":       stats["e_feedback"]  / S,
        "kl_align":          stats["e_align"]     / S,
        "kl_mod_align":      stats["e_mod_align"] / S,
        "curv_energy":       stats["e_curv"]      / S,
        "curv_model_energy": stats["e_curv_mod"]  / S,
        "phi_norm":          stats["phi_norm"],
        "phi_model_norm":    stats["phi_model_norm"],
        "mass_energy":       stats["e_mass"] / S,
        "mass_model_energy": stats["e_mass_mod"] / S
    }

    agent.log_metrics(step, log_dict)



def accumulate_and_log_metrics(results, agents, step: int, Q_list, Mask_list) -> dict:
    """
    Aggregate per-agent metrics into a global scalar dictionary, logging each agent’s metrics.

    Args:
        results    : list of (i, stats) tuples
        agents     : list of Agent objects
        step       : int step number
        Q_list     : list of (mu, sigma) for beliefs
        Mask_list  : list of (H, W) binary masks

    Returns:
        metrics    : global summary dict (unnormalized total energies)
    """
    keys = [
    "e_self", "e_feedback", "e_align", "e_mod_align",
    "e_curv", "e_curv_mod", "e_mass", "e_mass_mod"
]

    accum = {k: 0.0 for k in keys}

    for i, stats in results:
        support = float(np.sum(Mask_list[i]))
        for k in keys:
            accum[k] += stats[k]
        log_agent_metrics(agents[i], step, stats, support)

    S = np.sum([np.sum(m) for m in Mask_list])
    S = S if S > 0 else 1.0
    metrics = {k: accum[k] / S for k in keys}
    metrics["total_energy"] = sum(metrics[k] for k in keys)
    metrics["step"] = step
    

    return metrics


def log_all_metrics(
    agents,
    step: int,
    params=None,
    q_field: str = "q",
    p_field: str = "p",
    phi_belief_field: str = "phi",
    phi_model_field: str = "phi_model",
    mask_field: str = "mask",
    n_jobs: int = -1
) -> dict:
    """
    Compute and log all per-agent metrics, and return global aggregated metrics.

    Args:
        agents          : list of Agent objects
        step            : int, current timestep
        params          : optional override dict for config
        q_field         : attribute name for q field (μ_q, Σ_q)
        p_field         : attribute name for p field (μ_p, Σ_p)
        phi_belief_field: attribute name for φ field
        phi_model_field : attribute name for φ̃ field
        mask_field      : attribute name for support mask
        n_jobs          : parallelism level

    Returns:
        metrics         : dict with total KL energies and phi norms
    """
    cfg = config if params is None else {**vars(config), **params}
    log_eps = cfg.get("log_eps", 1e-10)

    N    = len(agents)
    K_q  = cfg.get("K_q", 5)
    K_p  = cfg.get("K_p", 5)
    name = cfg.get("group_name", "sl2r")

    gen_q = get_generators(name, K_q)
    gen_p = get_generators(name, K_p)

    # ───── Precompute agent fields ─────
    Q_list     = [(A.mu_q_field, A.sigma_q_field) for A in agents]
    P_list     = [(A.mu_p_field, A.sigma_p_field) for A in agents]
    Mask_list  = [np.asarray(getattr(A, mask_field), dtype=bool) for A in agents]
    O_bel      = [A.Omega           for A in agents]
    O_inv      = [A.Omega_inv       for A in agents]
    O_mod      = [A.Omega_model     for A in agents]
    O_mod_inv  = [A.Omega_model_inv for A in agents]

    # ───── Compute all metrics in parallel ─────
    results = Parallel(n_jobs=n_jobs, backend="threading", batch_size=1)(
        delayed(compute_agent_metrics)(
            i, agents[i], Q_list, P_list, Mask_list,
            O_bel, O_inv, O_mod, O_mod_inv,
            cfg, (gen_q, gen_p), log_eps
        )
        for i in range(N)
    )

    # ───── Accumulate and return summary ─────
    metrics = accumulate_and_log_metrics(results, agents, step, Q_list, Mask_list)

    # ───── Print energy to console ─────
    total_energy = np.sum(metrics['total_energy'])  # reduces to scalar
    print(f"\n[STEP {step:04d}] Total Energy = {total_energy:.6f}\n")


    return metrics

def get_max_overlap_pair(agents, eps):
    max_overlap, best_pair = 0, None
    for i, A in enumerate(agents):
        mask_i = A.mask > eps
        for nb in A.neighbors:
            j = nb["id"]
            mask_j = agents[j].mask > eps
            overlap = mask_i & mask_j
            if (cnt := int(overlap.sum())) > max_overlap:
                max_overlap, best_pair = cnt, (i, j)
    return best_pair, max_overlap

from generalized_math_utils import preprocess_agent_fields
from numerical_utils import sanitize_sigma

def log_max_overlap_fields(agents, step, outdir, eps=config.support_cutoff_eps):
    """
    Logs full diagnostics from the max-overlap pair:
    - μ/Σ for q and p
    - belief/model alignment fields
    - KL(q ‖ Φ̃·p), KL(p ‖ Φ·q)
    """
    os.makedirs(outdir, exist_ok=True)

    # [1] Find most overlapping agent pair
    max_overlap, best_pair = 0, None
    for i, A in enumerate(agents):
        mask_i = A.mask > eps
        if not mask_i.any():
            continue
        for nb in A.neighbors:
            j = nb["id"]
            mask_j = agents[j].mask > eps
            overlap = mask_i & mask_j
            if (count := int(overlap.sum())) > max_overlap:
                max_overlap, best_pair = count, (i, j)

    if best_pair is None:
        print(f"[DEBUG] No overlapping pair at step {step}")
        return

    i, j = best_pair
    A = agents[i]
    B = agents[j]

    # [2] Preprocess φ caches
    preprocess_agent_fields(A, {})
    preprocess_agent_fields(B, {})

    # [3] Load fields
    mu_q, sigma_q = A.mu_q_field, sanitize_sigma(A.sigma_q_field)
    mu_p, sigma_p = A.mu_p_field, sanitize_sigma(A.sigma_p_field)
    mask_i = (A.mask > eps).astype(np.float32)
    H, W = mask_i.shape

    # [4] KL fields with bundle morphisms
    kl_qp = compute_kl_qp_field(mu_q, sigma_q, mu_p, sigma_p, A.Phi_tilde, mask_i)
    kl_pq = compute_kl_pq_field(mu_p, sigma_p, mu_q, sigma_q, A.Phi, mask_i)

    # [5] Alignment fields
    belief_align = compute_alignment_field_general(agents, i, field_type="belief")
    model_align  = compute_alignment_field_general(agents, i, field_type="model")

    # [6] Save output
    fname = os.path.join(outdir, f"step{step:05d}_pair_{i}_{j}.npz")
    np.savez_compressed(
        fname,
        agent_i          = i,
        agent_j          = j,
        overlap          = max_overlap,
        mask_i           = mask_i,
        mu_q             = mu_q,
        sigma_q          = sigma_q,
        mu_p             = mu_p,
        sigma_p          = sigma_p,
        kl_self          = kl_qp,
        kl_feedback      = kl_pq,
        belief_alignment = belief_align,
        model_alignment  = model_align,
        phi              = A.phi,
        phi_model        = A.phi_model,
    )



def full_field_logger(agents, step: int, outdir: str):
    """
    Save one .npz per step containing per-agent fields and diagnostics:
      - mu_q, sigma_q, phi
      - mu_p, sigma_p, phi_model
      - belief_align, model_align
      - kl_self, kl_feedback
      - curvature tensors
      - bundle morphisms Φ, Φ̃
    """
    cfg  = vars(config)
    K_q  = cfg["K_q"]
    K_p  = cfg["K_p"]
    gens_q = get_generators(cfg["group_name"], K_q)
    gens_p = get_generators(cfg["group_name"], K_p)
    dx   = cfg.get("dx", 1.0)

    N = len(agents)
    H, W = agents[0].mu_q_field.shape[:2]

    # Allocate per-agent field arrays
    mu_q     = np.zeros((N, H, W, K_q), dtype=np.float32)
    sigma_q  = np.zeros((N, H, W, K_q, K_q), dtype=np.float32)
    phi      = np.zeros((N, H, W, agents[0].phi.shape[-1]), dtype=np.float32)

    mu_p     = np.zeros((N, H, W, K_p), dtype=np.float32)
    sigma_p  = np.zeros((N, H, W, K_p, K_p), dtype=np.float32)
    phi_model = np.zeros((N, H, W, agents[0].phi_model.shape[-1]), dtype=np.float32)

    belief_align      = np.zeros((N, H, W), dtype=np.float32)
    model_align       = np.zeros((N, H, W), dtype=np.float32)
    kl_self_field     = np.zeros((N, H, W), dtype=np.float32)
    kl_feedback_field = np.zeros((N, H, W), dtype=np.float32)

    curv_tensor        = np.zeros((N, H, W, K_q, K_q), dtype=np.float32)
    curv_model_tensor  = np.zeros((N, H, W, K_p, K_p), dtype=np.float32)

    for idx, A in enumerate(agents):
        mu_q[idx]    = A.mu_q_field
        sigma_q[idx] = A.sigma_q_field
        phi[idx]     = A.phi

        mu_p[idx]    = A.mu_p_field
        sigma_p[idx] = A.sigma_p_field
        phi_model[idx] = A.phi_model

        belief_align[idx] = compute_alignment_field_general(agents, idx, field_type="belief")
        model_align[idx]  = compute_alignment_field_general(agents, idx, field_type="model")

        kl_self_field[idx] = compute_kl_qp_field(
            A.mu_q_field, A.sigma_q_field,
            A.mu_p_field, A.sigma_p_field,
            A.dynamic_morphism_p_to_q,
            A.mask
        )

        kl_feedback_field[idx] = compute_kl_pq_field(
            A.mu_p_field, A.sigma_p_field,
            A.mu_q_field, A.sigma_q_field,
            A.dynamic_morphism_q_to_p,
            A.mask
        )

        curv_tensor[idx]       = compute_field_strength(A.phi, generators=gens_q, dx=dx)["xy"]
        curv_model_tensor[idx] = compute_field_strength(A.phi_model, generators=gens_p, dx=dx)["xy"]

    # Stack bundle morphisms
    phi_q_to_p_stack = np.stack([A.bundle_morphism_q_to_p for A in agents], axis=0)
    phi_p_to_q_stack = np.stack([A.bundle_morphism_p_to_q for A in agents], axis=0)

    # Save
    os.makedirs(outdir, exist_ok=True)
    fname = Path(outdir) / f"step{step:05d}.npz"
    np.savez_compressed(
        fname,
        mu_q=mu_q,
        sigma_q=sigma_q,
        phi=phi,
        mu_p=mu_p,
        sigma_p=sigma_p,
        phi_model=phi_model,
        belief_align=belief_align,
        model_align=model_align,
        kl_self=kl_self_field,
        kl_feedback=kl_feedback_field,
        curv_tensor=curv_tensor,
        curv_model_tensor=curv_model_tensor,
        phi_q_to_p=phi_q_to_p_stack,
        phi_p_to_q=phi_p_to_q_stack,
    )
    print(f"[DUMP] step={step} → {fname}")


