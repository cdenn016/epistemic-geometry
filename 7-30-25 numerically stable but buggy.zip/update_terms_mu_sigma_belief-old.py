# -*- coding: utf-8 -*-
"""
Created on Wed Jul 23 06:37:51 2025

@author: chris and christine
"""


import numpy as np
import config
from numerical_utils import sanitize_sigma, safe_inv

from natural_params_utils import natural_to_mu_sigma_batch, convert_mu_sigma_grads_to_eta_grads, convert_eta_grads_to_mu_sigma



#==============================================================================
#
#                    APPLY NATURAL GRADIENT
#
#==============================================================================


def accumulate_eta_gradient_belief(agent_i, agents, params):
    """
    Accumulate ∇_{η₁_q}, ∇_{η₂_q} for agent_i from belief energy terms:
      - Self:     KL(q_i || Φ̃ p_i)
      - Feedback: KL(p_i || Φ q_i)
      - Alignment: KL(q_i || Ω_ij q_j) and KL(q_k || Ω_kj q_j) for i == j

    Stores into:
        agent_i.grad_eta1_q_field
        agent_i.grad_eta2_q_field
    """
    eps = config.eps
    clip_eta2 = 1e3

    eta1_q = agent_i.eta1_q_field
    eta2_q = agent_i.eta2_q_field

    # Step 1: Convert η → μ, Σ
    mu_q, sigma_q = natural_to_mu_sigma_batch(eta1_q, eta2_q, eps=eps)

    # Step 2: Compute ∇μ and ∇Σ from all belief terms
    dmu, dsigma = compute_mu_sigma_gradient_belief_euclidean(agent_i, agents, params)

   
    # Step 3: Convert to ∇η₁ and ∇η₂
    grad_eta1, grad_eta2 = convert_mu_sigma_grads_to_eta_grads(
        mu_q, sigma_q, dmu, dsigma, eps=config.support_cutoff_eps,
    )

    # ── Step 4: Print η₁ and η₂ gradient norms after conversion ──
    eta1_norm = np.mean(np.linalg.norm(grad_eta1, axis=-1))
    eta2_norm = np.mean(np.linalg.norm(grad_eta2.reshape(grad_eta2.shape[:-2] + (-1,)), axis=-1))
    print("Converted eta1 grad norm:", eta1_norm)
    print("Converted eta2 grad norm (before clip):", eta2_norm)

    
    # Step 5: Clip ∇η₂ (optional safety)
    grad_eta2 = np.clip(grad_eta2, -clip_eta2, clip_eta2)

    # Step 6: Masked accumulation
    mask = np.squeeze(agent_i.mask)[..., None]  # shape (..., 1)
    agent_i.grad_eta1_q_field += grad_eta1 * mask
    agent_i.grad_eta2_q_field += grad_eta2 * mask[..., None]






#==============================================================================
#
#                    ACCUMULATE FIELD GRADS EUCLIDEAN
#
#==============================================================================

def compute_mu_sigma_gradient_belief_euclidean(agent_i, agents, params):
    """
    Accumulate ∇_μ and ∇_Σ belief gradients for agent_i from:
    - Self-energy:     KL(q_i ‖ Φ̃ p_i)
    - Feedback:        KL(p_i ‖ Φ q_i)
    - Alignment (μ_i): KL(q_i ‖ Ω_ij q_j)
    - Alignment (μ_j): KL(q_k ‖ Ω_kj q_j) if i == j

    Returns:
        dmu_q:    (..., K_q)
        dsigma_q: (..., K_q, K_q)
    """
    eps   = config.support_cutoff_eps
    alpha = params.get("alpha", config.alpha)
    beta  = params.get("beta", config.beta)
    lambd = params.get("lambda", config.feedback_weight)

    mu_q    = agent_i.mu_q_field
    sigma_q = agent_i.sigma_q_field
    mu_p    = agent_i.mu_p_field
    sigma_p = agent_i.sigma_p_field
    Phi         = agent_i.dynamic_morphism_q_to_p
    Phi_tilde   = agent_i.dynamic_morphism_p_to_q

    dmu_self    = grad_self_energy_mu_q(mu_q, sigma_q, mu_p, sigma_p, Phi_tilde, eps=eps)
    dsigma_self = grad_self_energy_sigma_q(mu_q, sigma_q, mu_p, sigma_p, Phi_tilde, eps=eps)

    # After computing dmu_self and dsigma_self
    norm_mu_self = np.mean(np.linalg.norm(dmu_self, axis=-1))
    norm_sigma_self = np.mean(np.linalg.norm(dsigma_self.reshape(dsigma_self.shape[:-2] + (-1,)), axis=-1))
    print("Self-energy mu grad norm:", norm_mu_self)
    print("Self-energy sigma grad norm:", norm_sigma_self)


    dmu_fb    = grad_feedback_mu_q(mu_q, sigma_q, mu_p, Phi, eps=eps)
    dsigma_fb = grad_feedback_sigma_q(mu_q, sigma_q, mu_p, sigma_p, Phi, eps=eps)

    # After computing dmu_fb and dsigma_fb
    norm_mu_fb = np.mean(np.linalg.norm(dmu_fb, axis=-1))
    norm_sigma_fb = np.mean(np.linalg.norm(dsigma_fb.reshape(dsigma_fb.shape[:-2] + (-1,)), axis=-1))
    print("Feedback mu grad norm:", norm_mu_fb)
    print("Feedback sigma grad norm:", norm_sigma_fb)


    # Alignment terms where agent_i is the *source* q_i
    dmu_align = 0
    dsigma_align = 0
    for neighbor in agent_i.neighbors:
        agent_j = agents[neighbor["id"]]
        Omega_ij = agent_i.Omega @ agent_j.Omega_inv

        dmu_align += grad_belief_align_mu_i(
            mu_q, sigma_q, agent_j.mu_q_field, agent_j.sigma_q_field, Omega_ij, eps=eps
        )
        dsigma_align += grad_belief_align_sigma_i(
            mu_q, sigma_q, agent_j.mu_q_field, agent_j.sigma_q_field, Omega_ij, eps=eps
        )

    # Alignment (forward)
    mu_align_norm = np.mean(np.linalg.norm(dmu_align, axis=-1))
    sigma_align_norm = np.mean(np.linalg.norm(dsigma_align.reshape(dsigma_align.shape[:-2] + (-1,)), axis=-1))
    print("Alignment mu grad norm:", mu_align_norm)
    print("Alignment sigma grad norm:", sigma_align_norm)

    # Alignment terms where agent_i is the *target* q_j in q_k ‖ Ω_kj q_j
    dmu_align_rev = 0
    dsigma_align_rev = 0
    for agent_k in agents:
        for neighbor in agent_k.neighbors:
            if neighbor.get("id") == agent_i.id:
                Omega_kj = agent_k.Omega @ agent_i.Omega_inv

                dmu_align_rev += grad_belief_align_mu_j(
                    agent_k.mu_q_field, agent_k.sigma_q_field,
                    mu_q, sigma_q, Omega_kj, eps=eps
                )
                dsigma_align_rev += grad_belief_align_sigma_j(
                    agent_k.mu_q_field, agent_k.sigma_q_field,
                    mu_q, sigma_q, Omega_kj, eps=eps
                )

    # Alignment (reverse)
    mu_align_rev_norm = np.mean(np.linalg.norm(dmu_align_rev, axis=-1))
    sigma_align_rev_norm = np.mean(np.linalg.norm(dsigma_align_rev.reshape(dsigma_align_rev.shape[:-2] + (-1,)), axis=-1))
    print("Alignment rev mu grad norm:", mu_align_rev_norm)
    print("Alignment rev sigma grad norm:", sigma_align_rev_norm)

    # Combine all
    dmu_total = (
        alpha * dmu_self +
        0*lambd * dmu_fb +
        beta * (dmu_align + dmu_align_rev)
    )

    dsigma_total = (
        alpha * dsigma_self +
        0*lambd * dsigma_fb +
        beta * (dsigma_align + dsigma_align_rev)
    )
    mu_total_norm = np.mean(np.linalg.norm(dmu_total, axis=-1))
    sigma_total_norm = np.mean(np.linalg.norm(dsigma_total.reshape(dsigma_total.shape[:-2] + (-1,)), axis=-1))
    print("Total mu grad norm:", mu_total_norm)
    print("Total sigma grad norm:", sigma_total_norm)

    return dmu_total, dsigma_total





#==============================================================================
#
#                    FEEDBACK TERMS
#      everything validated below
#==============================================================================



def grad_feedback_mu_q(mu_q_field, sigma_q_field, mu_p_field, Phi, eps=1e-8):
    """
    Compute ∂/∂μ_q D_KL(p || Φ q) over a spatial field (H, W, K_q).
    
    Args:
        mu_q_field    : (..., K_q)
        sigma_q_field : (..., K_q, K_q)
        mu_p_field    : (..., K_p)
        Phi           : (..., K_p, K_q)
        eps           : regularization for inversion
        
    Returns:
        grad_mu_q     : (..., K_q), gradient field
    """
    # Compute pushforward mean: Φ μ_q
    mu_q_push = np.einsum("...ij,...j->...i", Phi, mu_q_field)  # (..., K_p)
    sigma_q_field = sanitize_sigma(sigma_q_field, eps=eps)

    # Compute pushforward covariance: Φ Σ_q Φ^T
    sigma_push = np.einsum("...ik,...kl,...jl->...ij", Phi, sigma_q_field, Phi)


    # Safe inverse
    sigma_push_inv = safe_inv(sigma_push, eps=eps)  # (..., K_p, K_p)

    # Δμ = μ_p − Φ μ_q
    delta_mu = mu_p_field - mu_q_push  # (..., K_p)

    # Compute gradient: - Φ^T (Φ Σ_q Φ^T)^{-1} (μ_p - Φ μ_q)
    tmp = np.einsum("...ij,...j->...i", sigma_push_inv, delta_mu)  # (..., K_p)
    grad_mu_q = -np.einsum("...ji,...j->...i", Phi, tmp)  # (..., K_q)

    return grad_mu_q



def grad_feedback_sigma_q(mu_q_field, sigma_q_field, mu_p_field,
                               sigma_p_field, Phi, eps=1e-8):
    """
    Compute ∂/∂Σ_q D_KL(p || Φ q) over spatial field (H, W, K_q, K_q)

    Args:
        mu_q_field     : (..., K_q)
        sigma_q_field  : (..., K_q, K_q)
        mu_p_field     : (..., K_p)
        sigma_p_field  : (..., K_p, K_p)
        Phi            : (..., K_p, K_q)
        eps            : regularization epsilon

    Returns:
        grad_sigma_q   : (..., K_q, K_q)
    """
    # Φ μ_q
    mu_q_push = np.einsum("...ij,...j->...i", Phi, mu_q_field)  # (..., K_p)

    # Pushforwarded covariance: Φ Σ_q Φ^T
    Phi_T = np.swapaxes(Phi, -1, -2)  # (..., K_q, K_p)
    
    sigma_q_field = sanitize_sigma(sigma_q_field, eps=eps)

    sigma_q_push = np.einsum("...ik,...kl,...jl->...ij", Phi, sigma_q_field, Phi)

    sigma_q_push_inv = safe_inv(sigma_q_push, eps=eps)

    # Δμ = μ_p - Φ μ_q
    delta_mu = mu_p_field - mu_q_push  # (..., K_p)

    # Mahalanobis term: A = Δμ Δμᵀ
    A = np.einsum("...i,...j->...ij", delta_mu, delta_mu)  # (..., K_p, K_p)

    # Terms
    inv_term     = sigma_q_push_inv
    mahal_term   = np.einsum("...ik,...kl,...lj->...ij",
                             sigma_q_push_inv, A, sigma_q_push_inv)
    trace_term   = np.einsum("...ik,...kl,...lj->...ij",
                             sigma_q_push_inv, sigma_p_field, sigma_q_push_inv)

    # Combine: M = [inv - mahal - trace]
    M = inv_term - mahal_term - trace_term  # (..., K_p, K_p)

    # Final gradient: Φᵀ M Φ
    grad_sigma_q = 0.5 * np.einsum("...ki,...kl,...lj->...ij", Phi, M, Phi)


    return grad_sigma_q






#==============================================================================
#
#                    SELF-ENERGY TERMS
#
#==============================================================================

def grad_self_energy_mu_q(mu_q_field, sigma_q_field, mu_p_field, sigma_p_field, Phi_tilde, eps=1e-8):
    """
    Compute ∂/∂μ_q D_KL(q || Φ̃ p) over spatial field (H, W, K_q)
    """
    # Pushforwarded mean: Φ̃ μ_p
    mu_p_push = np.einsum("...ij,...j->...i", Phi_tilde, mu_p_field)  # (..., K_q)
    sigma_p_field = sanitize_sigma(sigma_p_field, eps=eps)

    # Pushforwarded covariance: Φ̃ Σ_p Φ̃^T
    sigma_p_push = np.einsum("...iq,...qr,...jr->...ij", Phi_tilde, sigma_p_field, Phi_tilde)

    sigma_p_push_inv = safe_inv(sigma_p_push, eps=eps)

    # Δμ = μ_q − Φ̃ μ_p
    delta_mu = mu_q_field - mu_p_push

    # Gradient
    grad_mu_q = np.einsum("...ij,...j->...i", sigma_p_push_inv, delta_mu)

    return grad_mu_q

def grad_self_energy_sigma_q(mu_q_field, sigma_q_field, mu_p_field, sigma_p_field, Phi_tilde, eps=1e-8):
    """
    ∇_{Σ_q} D_KL(q || Φ̃ p) = ½ [ Σ_q⁻¹ − (Φ̃ Σ_p Φ̃ᵀ)⁻¹ ]
    Returns shape (H, W, K_q, K_q)
    """
    sigma_q_inv = safe_inv(sigma_q_field, eps=eps)
    sigma_p_field = sanitize_sigma(sigma_p_field, eps=eps)
    sigma_p_push = np.einsum("...iq,...qr,...jr->...ij", Phi_tilde, sigma_p_field, Phi_tilde)
    sigma_p_push_inv = safe_inv(sigma_p_push, eps=eps)

    grad = 0.5 * (sigma_q_inv - sigma_p_push_inv)
    return grad




#==============================================================================
#
#                    ALIGNMENT TERMS - NOT VALIDATED
#
#==============================================================================


def grad_belief_align_mu_i(mu_i, sigma_i, mu_j, sigma_j, Omega_ij, eps=1e-8):
    """
    ∇_{μ_i} D_KL(q_i || Ω q_j) = (Ω Σ_j Ωᵀ)^(-1) (μ_i − Ω μ_j)
    """
    # ── Shape validation ─────────────────────────────────────────────
    if Omega_ij.ndim != 4:
        raise ValueError(f"Expected Omega_ij shape (..., K_q, K_q), got {Omega_ij.shape}")
    if sigma_j.shape != Omega_ij.shape:
        raise ValueError(f"Shape mismatch: sigma_j {sigma_j.shape} vs Omega_ij {Omega_ij.shape}")
    if mu_i.shape != mu_j.shape or mu_i.shape != Omega_ij.shape[:-1]:
        raise ValueError(f"mu_i, mu_j shape mismatch: mu_i {mu_i.shape}, mu_j {mu_j.shape}, expected {..., config.K_q}")

    # ── Transport mean: Ω μ_j ────────────────────────────────────────
    mu_j_t = np.einsum("...ij,...j->...i", Omega_ij, mu_j)
    delta_mu = mu_i - mu_j_t

    # ── Transport covariance: Ω Σ_j Ωᵀ ───────────────────────────────
    Omega_T = np.swapaxes(Omega_ij, -1, -2)
    sigma_j_t = np.matmul(Omega_ij, np.matmul(sigma_j, Omega_T))  # safer than einsum
    sigma_j_t = sanitize_sigma(sigma_j_t, eps=eps)
    sigma_inv = safe_inv(sigma_j_t, eps=eps)

    # ── Final gradient: Σ⁻¹ Δμ ───────────────────────────────────────
    grad = np.einsum("...ij,...j->...i", sigma_inv, delta_mu)
    return grad


def grad_belief_align_sigma_i(mu_i, sigma_i, mu_j, sigma_j, Omega_ij, eps=1e-8):
    """
    ∇_{Σ_i} D_KL(q_i || Ω q_j) = ½ [ (Ω Σ_j Ωᵀ)^(-1) − Σ_i^(-1) ]
    """
    Omega_T = np.swapaxes(Omega_ij, -1, -2)  # shape (..., K, K)
    sigma_j_t = np.einsum("...ik,...kl,...lj->...ij", Omega_ij, sigma_j, Omega_T)  # Ω Σ_j Ωᵀ

    sigma_j_t = sanitize_sigma(sigma_j_t, eps=eps)
    inv_j = safe_inv(sigma_j_t, eps=eps)
    inv_i = safe_inv(sigma_i, eps=eps)

    grad = 0.5 * (inv_j - inv_i)
    return grad

def grad_belief_align_mu_j(mu_i, sigma_i, mu_j, sigma_j, Omega_ij, eps=1e-8):
    """
    ∇_{μ_j} D_KL(q_i || Ω q_j) = -Ωᵀ (Ω Σ_j Ωᵀ)^(-1) (μ_i − Ω μ_j)
    """
    mu_j_t = np.einsum("...ij,...j->...i", Omega_ij, mu_j)
    delta_mu = mu_i - mu_j_t

    # Fix: change last einsum index from ...jl to ...lj to match the axes
    Omega_T = np.swapaxes(Omega_ij, -1, -2)
    sigma_j_t = np.einsum("...ik,...kl,...lj->...ij", Omega_ij, sigma_j, Omega_T)

    sigma_j_t = sanitize_sigma(sigma_j_t, eps=eps)
    sigma_inv = safe_inv(sigma_j_t, eps=eps)

    tmp = np.einsum("...ij,...j->...i", sigma_inv, delta_mu)
    grad = -np.einsum("...ji,...i->...j", Omega_ij, tmp)
    return grad


def grad_belief_align_sigma_j(mu_i, sigma_i, mu_j, sigma_j, Omega_ij, eps=1e-8):
    """
    ∇_{Σ_j} D_KL(q_i || Ω q_j)
    = ½ Ωᵀ [ M⁻¹ Δμ Δμᵀ M⁻¹ − M⁻¹ Σ_i M⁻¹ − M⁻¹ ] Ω
    where M = Ω Σ_j Ωᵀ
    """
    mu_j_t = np.einsum("...ij,...j->...i", Omega_ij, mu_j)
    delta_mu = mu_i - mu_j_t

    Omega_T = np.swapaxes(Omega_ij, -1, -2)  # <-- Fix here
    sigma_j_t = np.einsum("...ik,...kl,...lj->...ij", Omega_ij, sigma_j, Omega_T)
    sigma_j_t = sanitize_sigma(sigma_j_t, eps=eps)
    sigma_inv = safe_inv(sigma_j_t, eps=eps)

    # First term: M⁻¹ Δμ Δμᵀ M⁻¹
    tmp = np.einsum("...i,...j->...ij", delta_mu, delta_mu)
    term1 = np.einsum("...ik,...kl,...lj->...ij", sigma_inv, tmp, sigma_inv)

    # Second term: M⁻¹ Σ_i M⁻¹
    term2 = np.einsum("...ik,...kl,...lj->...ij", sigma_inv, sigma_i, sigma_inv)

    # Third term: M⁻¹
    term3 = sigma_inv

    # Combine and project back
    diff = term1 - term2 - term3
    grad = 0.5 * np.einsum("...ik,...kl,...lj->...ij", Omega_T, diff, Omega_ij)
    return grad


