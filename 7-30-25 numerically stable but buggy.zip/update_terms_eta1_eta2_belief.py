# -*- coding: utf-8 -*-
"""
Created on Sat Jul 26 08:43:30 2025

@author: chris and christine
"""

import numpy as np
import config
from natural_params_utils import compute_bar_eta2_qj, compute_delta_eta
from numerical_utils import safe_inv
from natural_params_utils import ( grad_eta2_from_sigma_mu, 
                                  compute_bar_eta2_q_morphed,
                                  compute_bar_eta2_p_morphed,
                                  compute_delta_eta_p_Phi_q,
                                  compute_delta_eta_q_PhiTilde_p, 
                                  natural_to_mu_sigma, apply_natural_gradient_batch_eta
                                  )

from natural_params_utils import convert_eta_grads_to_mu_sigma, convert_mu_sigma_grads_to_eta_grads
from omega import compute_exp_field

#=======================================================================
#
#                 Accumulate - need to also accum p-terms
#
#===========================================================================

def accumulate_eta_gradient_belief(agent_i, agents, params):
    """
    Accumulate ∇_{η₁_q}, ∇_{η₂_q} for agent_i directly in natural parameter space
    using variational gradients:

      - Self:     KL(q_i || Φ̃ p_i)
      - Feedback: KL(p_i || Φ q_i)
      - Alignment: KL(q_i || Ω_ij q_j)   and   KL(q_k || Ω_kj q_j) for i == j

    Updates:
        agent_i.grad_eta1_q_field
        agent_i.grad_eta2_q_field
    """
    eps = config.support_cutoff_eps
    alpha = params.get("alpha", config.alpha)
    beta  = params.get("beta", config.beta)
    lambd = params.get("lambda", config.feedback_weight)

    # ── Mask and fields ──
    mask     = agent_i.mask > eps
    mask1    = mask[..., None]
    mask2    = mask[..., None, None]

    eta1_q   = agent_i.eta1_q_field
    eta2_q   = agent_i.eta2_q_field
    eta1_p   = agent_i.eta1_p_field
    eta2_p   = agent_i.eta2_p_field
    Phi       = agent_i.bundle_morphism_q_to_p
    Phi_tilde = agent_i.bundle_morphism_p_to_q

    # ── Self-energy ──
    grad_eta1_self = grad_eta1_q_morphism_self(eta1_q, eta2_q, eta1_p, eta2_p, Phi_tilde, eps=eps)
    grad_eta2_self = grad_eta2_q_morphism_self(eta1_q, eta2_q, eta1_p, eta2_p, Phi_tilde, eps=eps)

    # ── Feedback ──
    grad_eta1_fb = grad_eta1_q_morphism_feedback(eta1_p, eta2_p, eta1_q, eta2_q, Phi, eps=eps)
    grad_eta2_fb = grad_eta2_q_morphism_feedback(eta1_p, eta2_p, eta1_q, eta2_q, Phi, eps=eps)

    # ── Alignment (i is source) ──
    grad_eta1_align = np.zeros_like(eta1_q)
    grad_eta2_align = np.zeros_like(eta2_q)

    for neighbor in agent_i.neighbors:
        agent_j = agents[neighbor["id"]]
        Omega_ij = np.einsum("...ik,...kj->...ij", agent_i._exp_phi, agent_j._exp_neg_phi)

        grad_eta1_align += grad_eta1_qi_alignment(
            eta1_q, eta2_q,
            agent_j.eta1_q_field,
            agent_j.eta2_q_field,
            Omega_ij, eps=eps,
        )
        grad_eta2_align += grad_eta2_qi_alignment(
            eta1_q, eta2_q,
            agent_j.eta1_q_field,
            agent_j.eta2_q_field,
            Omega_ij, eps=eps,
        )

    # ── Alignment (i is target) ──
    grad_eta1_align_rev = np.zeros_like(eta1_q)
    grad_eta2_align_rev = np.zeros_like(eta2_q)
    count = 0

    for agent_k in agents:
        for neighbor in agent_k.neighbors:
            if neighbor.get("id") == agent_i.id:
                Omega_kj = np.einsum("...ik,...kj->...ij", agent_k._exp_phi, agent_i._exp_neg_phi)

                grad_eta1_align_rev += grad_eta1_qj_alignment(
                    agent_k.eta1_q_field,
                    agent_k.eta2_q_field,
                    eta1_q, eta2_q, Omega_kj, eps=eps
                )
                grad_eta2_align_rev += grad_eta2_qj_alignment(
                    agent_k.eta1_q_field,
                    agent_k.eta2_q_field,
                    eta1_q, eta2_q, Omega_kj, eps=eps
                )
                count += 1

    if count > 0:
        grad_eta1_align_rev /= count
        grad_eta2_align_rev /= count

    # ── Combine and clip ──
    grad_eta1_total = (
        alpha * grad_eta1_self +
        0*lambd * grad_eta1_fb +
        beta * (grad_eta1_align + grad_eta1_align_rev)
    )
    grad_eta2_total = (
        alpha * grad_eta2_self +
        0*lambd * grad_eta2_fb +
        beta * (grad_eta2_align + grad_eta2_align_rev)
    )

    # Optional mask before clipping
    grad_eta1_total *= mask1
    grad_eta2_total *= mask2

    grad_eta1_total = np.clip(grad_eta1_total, -config.grad_eta1_clip, config.grad_eta1_clip)
    grad_eta2_total = np.clip(grad_eta2_total, -config.grad_eta2_clip, config.grad_eta2_clip)

    # ── Apply natural gradient step ──
    delta_eta1, delta_eta2 = apply_natural_gradient_batch_eta(
        eta1_q, eta2_q,
        grad_eta1_total, grad_eta2_total,
        mask1, eps=eps
    )

    agent_i.grad_eta1_q_field += delta_eta1
    agent_i.grad_eta2_q_field += delta_eta2


def accumulate_eta_gradient_belief_old(agent_i, agents, params):
    """
    Accumulate ∇_{η₁_q}, ∇_{η₂_q} for agent_i directly in natural parameter space
    using variational gradients:

      - Self:     KL(q_i || Φ̃ p_i)
      - Feedback: KL(p_i || Φ q_i)
      - Alignment: KL(q_i || Ω_ij q_j)   and   KL(q_k || Ω_kj q_j) for i == j

    Stores into:
        agent_i.grad_eta1_q_field
        agent_i.grad_eta2_q_field
    """
    eps = config.support_cutoff_eps
    alpha = params.get("alpha", config.alpha)
    beta  = params.get("beta", config.beta)
    lambd = params.get("lambda", config.feedback_weight)

    # ── Masked inputs ──
    mask     = agent_i.mask > eps
    mask1    = mask[..., None]
    mask2    = mask[..., None, None]

    eta1_q   = agent_i.eta1_q_field * mask1
    eta2_q   = agent_i.eta2_q_field * mask2
    eta1_p   = agent_i.eta1_p_field * mask1
    eta2_p   = agent_i.eta2_p_field * mask2
    Phi      = agent_i.bundle_morphism_q_to_p * mask2
    Phi_tilde = agent_i.bundle_morphism_p_to_q * mask2

    # ── Self-energy ──
    grad_eta1_self = grad_eta1_q_morphism_self(eta1_q, eta2_q, eta1_p, eta2_p, Phi_tilde, eps=eps)
    grad_eta2_self = grad_eta2_q_morphism_self(eta1_q, eta2_q, eta1_p, eta2_p, Phi_tilde, eps=eps)

    # ── Feedback ──
    grad_eta1_fb = grad_eta1_q_morphism_feedback(eta1_p, eta2_p, eta1_q, eta2_q, Phi, eps=eps)
    grad_eta2_fb = grad_eta2_q_morphism_feedback(eta1_p, eta2_p, eta1_q, eta2_q, Phi, eps=eps)

    # ── Alignment (i = source) ──
    grad_eta1_align = np.zeros_like(eta1_q)
    grad_eta2_align = np.zeros_like(eta2_q)
    for neighbor in agent_i.neighbors:
        agent_j = agents[neighbor["id"]]
        Omega_ij = np.einsum("...ik,...kj->...ij", agent_i._exp_phi, agent_j._exp_neg_phi)

        grad_eta1_align += grad_eta1_qi_alignment(
            eta1_q, eta2_q,
            agent_j.eta1_q_field * mask1,
            agent_j.eta2_q_field * mask2,
            Omega_ij, eps=eps,
        )
        grad_eta2_align += grad_eta2_qi_alignment(
            eta1_q, eta2_q,
            agent_j.eta1_q_field * mask1,
            agent_j.eta2_q_field * mask2,
            Omega_ij, eps=eps,
        )

    # ── Alignment (i = target) ──
    grad_eta1_align_rev = np.zeros_like(eta1_q)
    grad_eta2_align_rev = np.zeros_like(eta2_q)
    for agent_k in agents:
        for neighbor in agent_k.neighbors:
            if neighbor.get("id") == agent_i.id:
                Omega_kj = np.einsum("...ik,...kj->...ij", agent_k._exp_phi, agent_i._exp_neg_phi)

                grad_eta1_align_rev += grad_eta1_qj_alignment(
                    agent_k.eta1_q_field * mask1,
                    agent_k.eta2_q_field * mask2,
                    eta1_q, eta2_q, Omega_kj, eps=eps,
                )
                grad_eta2_align_rev += grad_eta2_qj_alignment(
                    agent_k.eta1_q_field * mask1,
                    agent_k.eta2_q_field * mask2,
                    eta1_q, eta2_q, Omega_kj, eps=eps,
                )

    # ── Combine ──
    grad_eta1_total = (
        alpha * grad_eta1_self +
        0 * lambd * grad_eta1_fb +
        beta * (grad_eta1_align + grad_eta1_align_rev)
    )
    grad_eta2_total = (
        alpha * grad_eta2_self +
        0 * lambd * grad_eta2_fb +
        beta * (grad_eta2_align + grad_eta2_align_rev)
    )

    grad_eta1_total *= mask1
    grad_eta2_total *= mask2

    grad_eta1_total = np.clip(grad_eta1_total, -config.grad_eta1_clip, config.grad_eta1_clip)
    grad_eta2_total = np.clip(grad_eta2_total, -config.grad_eta2_clip, config.grad_eta2_clip)

    delta_eta1, delta_eta2 = apply_natural_gradient_batch_eta(
        eta1_q, eta2_q, grad_eta1_total, grad_eta2_total, mask1, eps=eps
    )

    agent_i.grad_eta1_q_field += delta_eta1
    agent_i.grad_eta2_q_field += delta_eta2




#========================================================
#
#          Alignment Gradients wrt to eta1, eta2
#
#==========================================================

def grad_eta1_qi_alignment(eta1_qi, eta2_qi, eta1_qj, eta2_qj, Omega_ij, eps=1e-8):
    """
    ∇_{η₁_qi} D_KL(q_i || Ω_ij q_j)
    = -½ · η2_qi⁻¹ · bar_eta2_qj · Δη
    """
    bar_eta2_qj = compute_bar_eta2_qj(eta2_qj, Omega_ij, eps=eps)
    delta_eta   = compute_delta_eta(eta1_qi, eta2_qi, eta1_qj, eta2_qj, Omega_ij, eps=eps)
    eta2_inv_qi = safe_inv(eta2_qi, eps=eps)

    intermediate = np.einsum("...ij,...j->...i", bar_eta2_qj, delta_eta)
    grad = -0.5 * np.einsum("...ij,...j->...i", eta2_inv_qi, intermediate)

    # ───── Debug ─────
   

    return grad

def grad_eta1_qj_alignment(eta1_qi, eta2_qi, eta1_qj, eta2_qj, Omega_ij, eps=1e-8):
    """
    ∇_{η₁_qj} D_KL(q_i || Ω_ij q_j)
    = -½ · η2_qj⁻¹ · Ω_ijᵀ · bar_eta2_qj · Δη
    """
    bar_eta2_qj = compute_bar_eta2_qj(eta2_qj, Omega_ij, eps=eps)
    delta_eta   = compute_delta_eta(eta1_qi, eta2_qi, eta1_qj, eta2_qj, Omega_ij, eps=eps)
    eta2_inv_qj = safe_inv(eta2_qj, eps=eps)

    intermediate = np.einsum("...ij,...j->...i", bar_eta2_qj, delta_eta)
    Omega_T = np.swapaxes(Omega_ij, -1, -2)
    projected = np.einsum("...ij,...j->...i", Omega_T, intermediate)

    grad = -0.5 * np.einsum("...ij,...j->...i", eta2_inv_qj, projected)

    

    return grad







#===================================================================
#
#               alignment gradients with respect to eta2
#
#==================================================================






import numpy as np
from numerical_utils import safe_inv

def grad_eta2_qi_alignment(
    eta1_qi, eta2_qi,
    eta1_qj, eta2_qj,
    Omega_ij,
    eps=1e-8
):
    """
    Compute ∇_{η₂_qi} D_KL(q_i || Ω_ij q_j) using natural parameters,
    via the boxed expression:
    
        -1/8 · η₂_qi⁻¹ · [2η₂_qi − bar_η₂_qj − ½ bar_η₂_qj Λ_qi] · η₂_qi⁻¹

    where:
        bar_η₂_qj = (Ω η₂_qj⁻¹ Ωᵀ)⁻¹
        Λ_qi = Δη ⊗ (η₂_qi⁻¹ η₁_qi)
    """
    # Inverses
    eta2_qi_inv = safe_inv(eta2_qi, eps=eps)
    eta2_qj_inv = safe_inv(eta2_qj, eps=eps)

    # bar_η₂_qj = (Ω η₂_qj⁻¹ Ωᵀ)⁻¹
    Omega_eta2inv_OmegaT = np.einsum("...ik,...kl,...jl->...ij",
                                     Omega_ij, eta2_qj_inv, Omega_ij)
    bar_eta2_qj = safe_inv(Omega_eta2inv_OmegaT, eps=eps)

    # Δη = η₂_qi⁻¹ η₁_qi − Ω η₂_qj⁻¹ η₁_qj
    term1 = np.einsum("...ij,...j->...i", eta2_qi_inv, eta1_qi)
    term2 = np.einsum("...ij,...jk,...k->...i", Omega_ij, eta2_qj_inv, eta1_qj)
    delta_eta = term1 - term2  # (..., K_q)

    # v = η₂_qi⁻¹ η₁_qi
    v = term1  # (..., K_q)

    # Λ_qi = delta_eta ⊗ v = outer product
    Lambda_qi = np.einsum("...i,...j->...ij", delta_eta, v)

    # Symmetrize bar_eta2_qj
    bar_eta2_qj_sym = 0.5 * (bar_eta2_qj + np.swapaxes(bar_eta2_qj, -1, -2))

    # Middle bracket term: [2η₂_qi − bar_η₂_qj − ½ bar_η₂_qj Λ_qi]
    term_middle = (
        2.0 * eta2_qi
        - bar_eta2_qj_sym
        - 0.5 * np.einsum("...ik,...kl->...il", bar_eta2_qj_sym, Lambda_qi)
    )

    # Final: -1/8 η₂_qi⁻¹ · term_middle · η₂_qi⁻¹
    grad = -0.125 * np.einsum(
        "...ik,...kl,...lj->...ij",
        eta2_qi_inv, term_middle, eta2_qi_inv
    )

    return grad

def grad_eta2_qj_alignment(
    eta1_qi, eta2_qi,
    eta1_qj, eta2_qj,
    Omega_ij,
    eps=1e-8
):
    """
    Compute ∇_{η₂_qj} D_KL(q_i || Ω_ij q_j) in natural parameter space using:
    
        -1/8 η₂_qj⁻¹ · [ Ωᵀ (bar + bar η₂_qi⁻¹ bar + ½ bar Δη Δηᵀ bar) Ω
                         − ½ bar Λ_j ] · η₂_qj⁻¹

    where:
        bar = (Ω η₂_qj⁻¹ Ωᵀ)⁻¹
        Δη = η₂_qi⁻¹ η₁_qi − Ω η₂_qj⁻¹ η₁_qj
        Λ_j = Δη ⊗ (η₂_qj⁻¹ η₁_qj)
    """
    # Inverses
    eta2_qi_inv = safe_inv(eta2_qi, eps=eps)
    eta2_qj_inv = safe_inv(eta2_qj, eps=eps)

    # v_j = η₂_qj⁻¹ η₁_qj
    vj = np.einsum("...ij,...j->...i", eta2_qj_inv, eta1_qj)

    # Δη = η₂_qi⁻¹ η₁_qi − Ω η₂_qj⁻¹ η₁_qj
    term1 = np.einsum("...ij,...j->...i", eta2_qi_inv, eta1_qi)
    term2 = np.einsum("...ij,...jk,...k->...i", Omega_ij, eta2_qj_inv, eta1_qj)
    delta_eta = term1 - term2  # (..., K_q)

    # Λ_j = delta_eta ⊗ (η₂_qj⁻¹ η₁_qj)
    Lambda_j = np.einsum("...i,...j->...ij", delta_eta, vj)

    # bar_eta2_qj = (Ω η₂_qj⁻¹ Ωᵀ)⁻¹
    Omega_eta2inv_OmegaT = np.einsum("...ik,...kl,...jl->...ij",
                                     Omega_ij, eta2_qj_inv, Omega_ij)
    bar_eta2_qj = safe_inv(Omega_eta2inv_OmegaT, eps=eps)
    bar_eta2_qj_sym = 0.5 * (bar_eta2_qj + np.swapaxes(bar_eta2_qj, -1, -2))

    # Subterms
    term_A = bar_eta2_qj_sym
    term_B = np.einsum("...ik,...kl->...il", bar_eta2_qj_sym, eta2_qi_inv)
    term_B = np.einsum("...il,...lj->...ij", term_B, bar_eta2_qj_sym)

    tmp = np.einsum("...i,...j->...ij", delta_eta, delta_eta)
    term_C = np.einsum("...ik,...kl->...il", bar_eta2_qj_sym, tmp)
    term_C = np.einsum("...il,...lj->...ij", term_C, bar_eta2_qj_sym)

    # Full bracket:
    full_inner = (
        term_A
        + term_B
        + 0.5 * term_C
    )

    term_D = 0.5 * np.einsum("...ik,...kj->...ij", bar_eta2_qj_sym, Lambda_j)

    # Now wrap with Ωᵀ and Ω
    term_ABC = np.einsum("...ki,...ij,...jl->...kl",
                         Omega_ij, full_inner, Omega_ij)
    
    bracket = term_ABC - term_D

    # Final contraction
    eta2_qj_inv_sym = 0.5 * (eta2_qj_inv + np.swapaxes(eta2_qj_inv, -1, -2))
    grad = -0.125 * np.einsum(
        "...ik,...kl,...lj->...ij",
        eta2_qj_inv_sym, bracket, eta2_qj_inv_sym
    )

    return grad




#===================================================================
#
#               feedback gradients with respect to eta1
#
#==================================================================

def grad_eta1_q_morphism_feedback(eta1_p, eta2_p, eta1_q, eta2_q, Phi, eps=1e-8):
    """
    Compute:
        ∂KL/∂η1_q = -½ η2_q⁻¹ · (Φᵀ · bar_eta2^Φ_q · Δη)

    Inputs:
        eta1_p, eta2_p : (..., K_p), (..., K_p, K_p)
        eta1_q, eta2_q : (..., K_q), (..., K_q, K_q)
        Phi            : (..., K_p, K_q)

    Returns:
        grad_eta1_q : (..., K_q)
    """
    from numerical_utils import safe_inv
    eta2_inv_q = safe_inv(eta2_q, eps=eps)

    bar_eta2_Phi_q = compute_bar_eta2_q_morphed(eta2_q, Phi, eps=eps)
    bar_eta2_Phi_q = 0.5 * (bar_eta2_Phi_q + np.swapaxes(bar_eta2_Phi_q, -1, -2))  # Ensure symmetry

    delta_eta = compute_delta_eta_p_Phi_q(eta1_p, eta2_p, eta1_q, eta2_q, Phi, eps=eps)

    tmp = np.einsum("...ij,...j->...i", bar_eta2_Phi_q, delta_eta)     # (..., K_p)
    tmp2 = np.einsum("...ij,...i->...j", Phi, tmp)                     # (..., K_q)

    grad_eta1_q = -0.5 * np.einsum("...ij,...j->...i", eta2_inv_q, tmp2)
    return grad_eta1_q


def grad_eta1_p_morphism_feedback(eta1_p, eta2_p, eta1_q, eta2_q, Phi, eps=1e-8):
    """
    Compute:
        ∇_{η1_p} D_KL(p || Φ q)
        = -½ · η2_p⁻¹ · bar_eta2^Φ_q · Δη

    Inputs:
        eta1_p : (..., K_p)
        eta2_p : (..., K_p, K_p)
        eta1_q : (..., K_q)
        eta2_q : (..., K_q, K_q)
        Phi    : (..., K_p, K_q)

    Returns:
        grad_eta1_p : (..., K_p)
    """
    from numerical_utils import safe_inv
    eta2_inv_p = safe_inv(eta2_p, eps=eps)

    bar_eta2_Phi_q = compute_bar_eta2_q_morphed(eta2_q, Phi, eps=eps)
    bar_eta2_Phi_q = 0.5 * (bar_eta2_Phi_q + np.swapaxes(bar_eta2_Phi_q, -1, -2))  # Ensure symmetry

    delta_eta = compute_delta_eta_p_Phi_q(eta1_p, eta2_p, eta1_q, eta2_q, Phi, eps=eps)

    tmp = np.einsum("...ij,...j->...i", bar_eta2_Phi_q, delta_eta)
    grad_eta1_p = -0.5 * np.einsum("...ij,...j->...i", eta2_inv_p, tmp)
    return grad_eta1_p



#===================================================================
#
#               feedback gradients with respect to eta2
#
#==================================================================

def grad_eta2_q_morphism_feedback(eta1_p, eta2_p, eta1_q, eta2_q, Phi, eps=1e-8):
    """
    ∇_{η₂_q} KL(p || Φ q) using only η₁, η₂ in natural parameter space.
    """
    from numerical_utils import safe_inv
    from natural_params_utils import compute_bar_eta2_q_morphed

    # Safe inverses and μ_q
    eta2_inv_q = safe_inv(eta2_q, eps=eps)
    mu_q = -0.5 * np.einsum("...ij,...j->...i", eta2_inv_q, eta1_q)

    # bar_eta2 = Φ η2_q Φᵀ
    bar_eta2 = compute_bar_eta2_q_morphed(eta2_q, Phi, eps=eps)
    bar_eta2 = 0.5 * (bar_eta2 + np.swapaxes(bar_eta2, -1, -2))

    # Δη = η1_p − Φ η1_q
    eta1_q_morphed = np.einsum("...ij,...j->...i", Phi, eta1_q)
    delta_eta = eta1_p - eta1_q_morphed

    # (1) Triple term: bar_eta2 η2_p⁻¹ bar_eta2
    eta2_inv_p = safe_inv(eta2_p, eps=eps)
    triple = np.einsum("...ik,...kl,...lj->...ij", bar_eta2, eta2_inv_p, bar_eta2)

    # (2) Mahalanobis term: ½ bar_eta2 Δη Δηᵀ bar_eta2
    delta_outer = np.einsum("...i,...j->...ij", delta_eta, delta_eta)
    mahal = 0.5 * np.einsum("...ik,...kl,...lj->...ij", bar_eta2, delta_outer, bar_eta2)

    # (3) ∇Σ = Φᵀ [ triple − bar_eta2 − mahal ] Φ
    grad_sigma = np.einsum(
        "...ik,...kl,...lj->...ij",
        Phi.swapaxes(-1, -2),
        triple - bar_eta2 - mahal,
        Phi
    )

    # (4) grad_mu = Φᵀ bar_eta2 Δη
    grad_mu = np.einsum("...ji,...j->...i", Phi, np.einsum("...ij,...j->...i", bar_eta2, delta_eta))

    # (5) grad_mu ⊗ μ_q
    outer = np.einsum("...i,...j->...ij", grad_mu, mu_q)

    # Total bracket
    bracket = grad_sigma + outer

    # Final projection to η₂_q: +⅛ η₂⁻¹ [bracket] η₂⁻¹
    tmp = np.einsum("...ik,...kj->...ij", eta2_inv_q, bracket)
    grad_eta2 = 0.125 * np.einsum("...ik,...kj->...ij", tmp, eta2_inv_q)

    return grad_eta2



def grad_eta2_p_morphism_feedback(eta1_p, eta2_p, eta1_q, eta2_q, Phi, eps=1e-8):
    """
    ∇_{η₂_p} KL(p || Φ q) in natural parameter space.

    Uses:
        ∇_{η₂_p} = -⅛ η₂_p⁻¹ [2η₂_p - Φ η₂_q Φᵀ - ½ (Φ η₂_q Φᵀ ⊗ μ_p) Δη] η₂_p⁻¹
    """
    from numerical_utils import safe_inv
    from natural_params_utils import compute_bar_eta2_q_morphed

    # η₂_p⁻¹
    eta2_inv_p = safe_inv(eta2_p, eps=eps)

    # μ_p = -½ η₂⁻¹ η₁
    mu_p = -0.5 * np.einsum("...ij,...j->...i", eta2_inv_p, eta1_p)

    # Δη = η₁_p - Φ η₁_q
    eta1_q_morphed = np.einsum("...ij,...j->...i", Phi, eta1_q)
    delta_eta = eta1_p - eta1_q_morphed

    # Pushforward η₂_q → bar_eta2_Phi_q = Φ η₂_q Φᵀ
    bar_eta2_Phi_q = compute_bar_eta2_q_morphed(eta2_q, Phi, eps=eps)
    bar_eta2_Phi_q = 0.5 * (bar_eta2_Phi_q + np.swapaxes(bar_eta2_Phi_q, -1, -2))  # ensure symmetry

    # Delta_Lambda = μ_p ⊗ Δη
    delta_Lambda = np.einsum("...i,...j->...ij", mu_p, delta_eta)

    # Bracket term inside sandwich
    bracket = 2.0 * eta2_p - bar_eta2_Phi_q - 0.5 * np.einsum("...ik,...kj->...ij", bar_eta2_Phi_q, delta_Lambda)

    # η₂⁻¹ [bracket] η₂⁻¹
    tmp = np.einsum("...ik,...kj->...ij", eta2_inv_p, bracket)
    grad_eta2 = -0.125 * np.einsum("...ik,...kj->...ij", tmp, eta2_inv_p)

    return grad_eta2








#===============================================
#
#                   SELF ENERGY TERMS
#
#=======================================
def grad_eta1_q_morphism_self(eta1_q, eta2_q, eta1_p, eta2_p, Phi_tilde, eps=1e-8):
    """
    ∇_{η1_q} D_KL(q || Φ̃ p)
    = -½ η2_q⁻¹ · bar_eta2^Φ̃_p · Δη
    """
    from numerical_utils import safe_inv

    eta2_inv_q = safe_inv(eta2_q, eps=eps)
    bar_eta2 = compute_bar_eta2_p_morphed(eta2_p, Phi_tilde, eps=eps)
    bar_eta2 = 0.5 * (bar_eta2 + np.swapaxes(bar_eta2, -1, -2))

    delta_eta = compute_delta_eta_q_PhiTilde_p(eta1_q, eta2_q, eta1_p, eta2_p, Phi_tilde, eps=eps)

    bar_eta_dot_delta = np.einsum("...ij,...j->...i", bar_eta2, delta_eta)
    return -0.5 * np.einsum("...ij,...j->...i", eta2_inv_q, bar_eta_dot_delta)




def grad_eta2_q_morphism_self(
    eta1_q, eta2_q,
    eta1_p, eta2_p,
    Phi_tilde,
    eps=1e-8
):
    """
    ∇_{η₂_q} KL(q || Φ̃ p) in natural coordinates (entirely in η₁, η₂).

    Uses:
        ∇_{η₂_q} = -1/8 η₂⁻¹ [η̂₂^{Φ̃}_p - η₂_q - 1/2 (η̂₂^{Φ̃}_p Δη ⊗ η₂⁻¹ η₁)] η₂⁻¹
    """
    from numerical_utils import safe_inv
    from natural_params_utils import (
        compute_bar_eta2_p_morphed,
        compute_delta_eta_q_PhiTilde_p,
    )

    # Symmetrized morphed η₂_p
    bar_eta2 = compute_bar_eta2_p_morphed(eta2_p, Phi_tilde, eps=eps)
    bar_eta2 = 0.5 * (bar_eta2 + np.swapaxes(bar_eta2, -1, -2))

    # Δη = η₁_q - Φ̃ η₁_p
    delta_eta = compute_delta_eta_q_PhiTilde_p(
        eta1_q, eta2_q, eta1_p, eta2_p, Phi_tilde, eps=eps
    )

    # Compute η₂_q⁻¹
    eta2_q_inv = safe_inv(eta2_q, eps=eps)

    # μ_q = -½ η₂⁻¹ η₁
    mu_q = -0.5 * np.einsum("...ij,...j->...i", eta2_q_inv, eta1_q)

    # Δη ⊗ μ_q: (..., i, j) = Δη_i * μ_q_j
    delta_Lambda = np.einsum("...i,...j->...ij", delta_eta, mu_q)

    # Full term inside sandwich
    bracket_term = bar_eta2 - eta2_q - 0.5 * np.einsum("...ik,...kj->...ij", bar_eta2, delta_Lambda)

    # Sandwich: η₂⁻¹ [⋯] η₂⁻¹
    tmp = np.einsum("...ik,...kj->...ij", eta2_q_inv, bracket_term)
    grad_eta2 = -0.125 * np.einsum("...ik,...kj->...ij", tmp, eta2_q_inv)

    return grad_eta2

def grad_eta1_p_morphism_self(eta1_q, eta2_q, eta1_p, eta2_p, Phi_tilde, eps=1e-8):
    """
    ∇_{η1_p} D_KL(q || Φ̃ p)
    = +½ η2_p⁻¹ · Φ̃ᵀ · bar_eta2^Φ̃_p · Δη
    """
    from numerical_utils import safe_inv

    eta2_inv_p = safe_inv(eta2_p, eps=eps)
    bar_eta2 = compute_bar_eta2_p_morphed(eta2_p, Phi_tilde, eps=eps)
    bar_eta2 = 0.5 * (bar_eta2 + np.swapaxes(bar_eta2, -1, -2))

    delta_eta = compute_delta_eta_q_PhiTilde_p(eta1_q, eta2_q, eta1_p, eta2_p, Phi_tilde, eps=eps)

    bar_eta_dot_delta = np.einsum("...ij,...j->...i", bar_eta2, delta_eta)
    Phi_T = np.swapaxes(Phi_tilde, -1, -2)
    push_term = np.einsum("...ij,...j->...i", Phi_T, bar_eta_dot_delta)

    return 0.5 * np.einsum("...ij,...j->...i", eta2_inv_p, push_term)

def grad_eta2_p_morphism_self(eta1_q, eta2_q, eta1_p, eta2_p, Phi_tilde, eps=1e-8):
    """
    ∇_{η₂_p} KL(q || Φ̃ p) using full natural parameter chain rule.
    All terms are expressed directly in η₁, η₂ space (no μ or Σ).

    Uses:
        ∇_{η₂_p} = -⅛ η₂_p⁻¹ [Φ̃ᵀ (⋯) Φ̃ + Φ̃ᵀ bar_eta₂_p Δη ⊗ μ_p Φ̃] η₂_p⁻¹
    """
    from numerical_utils import safe_inv
    from natural_params_utils import compute_bar_eta2_p_morphed

    # η₂_p⁻¹ and μ_p = -½ η₂⁻¹ η₁
    eta2_inv_p = safe_inv(eta2_p, eps=eps)
    mu_p = -0.5 * np.einsum("...ij,...j->...i", eta2_inv_p, eta1_p)

    # Pushforward η₂_p → bar_eta2 = Φ̃ η₂_p Φ̃ᵀ
    bar_eta2 = compute_bar_eta2_p_morphed(eta2_p, Phi_tilde, eps=eps)
    bar_eta2 = 0.5 * (bar_eta2 + np.swapaxes(bar_eta2, -1, -2))  # ensure symmetry

    # Δη = η₁_q − Φ̃ η₁_p
    eta1_p_morphed = np.einsum("...ij,...j->...i", Phi_tilde, eta1_p)
    delta_eta = eta1_q - eta1_p_morphed

    # (1) triple term: bar_eta2 η₂_p⁻¹ bar_eta2
    triple_term = np.einsum("...ik,...kl,...lj->...ij", bar_eta2, eta2_inv_p, bar_eta2)

    # (2) Mahalanobis term: ½ bar_eta2 Δη Δηᵀ bar_eta2
    delta_outer = np.einsum("...i,...j->...ij", delta_eta, delta_eta)
    mahal_term = 0.5 * np.einsum("...ik,...kl,...lj->...ij", bar_eta2, delta_outer, bar_eta2)

    # (3) Gradient of Σ: Φ̃ᵀ [ triple − bar_eta2 − mahal ] Φ̃
    grad_sigma = np.einsum(
        "...ik,...kl,...lj->...ij",
        Phi_tilde.swapaxes(-1, -2),
        triple_term - bar_eta2 - mahal_term,
        Phi_tilde
    )

    # (4) Gradient of μ: −Φ̃ᵀ bar_eta2 Δη
    grad_mu = -np.einsum("...ji,...j->...i", Phi_tilde, np.einsum("...ij,...j->...i", bar_eta2, delta_eta))

    # (5) Tensor product: grad_mu ⊗ μ_p
    outer = np.einsum("...i,...j->...ij", grad_mu, mu_p)

    # (6) Total bracket: grad_sigma + outer
    bracket = grad_sigma + outer

    # Final sandwich: −⅛ η₂⁻¹ [bracket] η₂⁻¹
    tmp = np.einsum("...ik,...kj->...ij", eta2_inv_p, bracket)
    grad_eta2 = -0.125 * np.einsum("...ik,...kj->...ij", tmp, eta2_inv_p)

    return grad_eta2





