# -*- coding: utf-8 -*-
"""
Created on Thu Jul 24 17:48:40 2025

@author: chris and christine
"""

import numpy as np
from numerical_utils import safe_inv, sanitize_sigma, safe_logdet, sanitize_eta2

def natural_to_expectation(eta1, eta2, eps=1e-8):
    """
    Convert natural parameters (η₁, η₂) to expectation parameters (θ₁, θ₂)
    where:
      η₁ = Σ⁻¹ μ
      η₂ = -½ Σ⁻¹
    so:
      μ = Σ η₁
      θ₁ = μ
      θ₂ = μ μᵀ + Σ = E[xxᵀ]
    """
    mu = mean_from_natural(eta1, eta2, eps=eps)        # (..., K)
    sigma = cov_from_natural(eta1, eta2, eps=eps)       # (..., K, K)

    theta1 = mu
    theta2 = np.einsum("...i,...j->...ij", mu, mu) + sigma
    return theta1, theta2


def mean_from_natural(eta1, eta2, eps=1e-8):
    """
    Compute μ from natural parameters: η₁ = Σ⁻¹ μ, η₂ = −½ Σ⁻¹
    """
    eta2_safe = eta2 + eps * np.eye(eta2.shape[-1])  # ensure SPD
    sigma_inv = -2.0 * eta2_safe
    sigma = safe_inv(sigma_inv, eps=eps)
    mu = np.einsum("...ij,...j->...i", sigma, eta1)
    return mu

def cov_from_natural(eta1, eta2, eps=1e-8):
    """
    Compute Σ from η₂ = −½ Σ⁻¹
    """
    eta2_safe = eta2 - eps * np.eye(eta2.shape[-1])
    sigma_inv = -2.0 * eta2_safe
    sigma = safe_inv(sigma_inv, eps=eps)
    return sigma

def log_partition_function(eta1, eta2, eps=1e-8):
    """
    Compute log-partition A(η₁, η₂) for a multivariate Gaussian in natural form.
    η₂ = -½ Σ⁻¹ → -2η₂ = Σ⁻¹ must be SPD.
    """
    from numpy.linalg import LinAlgError
    from numerical_utils import sanitize_eta2, safe_logdet

    # Sanitize η₂ to ensure it is strictly negative definite
    eta2 = sanitize_eta2(eta2, eps=eps)

    if np.any(np.isnan(eta1)) or np.any(np.isnan(eta2)):
        print("[NaN] Detected in η₁ or η₂ BEFORE inverse")
        raise ValueError("NaNs in eta1 or eta2")

    eta2_inv = safe_inv(eta2, eps=eps)

    # Step 1: Quadratic term
    quad = 0.25 * np.einsum("...i,...ij,...j->...", eta1, eta2_inv, eta1)

    # Step 2: Compute Σ⁻¹ = -2η₂, which must now be SPD
    Sigma_inv = -2.0 * eta2

    # Diagnostic
    eigvals = np.linalg.eigvalsh(Sigma_inv)
    #if np.any(eigvals <= 0):
       # print("❌ Invalid Σ⁻¹: not SPD")
      #  print("→ min eigval:", eigvals.min())
    #else:
   #     print("log_partition_function: eigvals(Σ⁻¹) →", eigvals.min(), eigvals.max())

    # Step 3: Compute log det via Cholesky or fallback
    try:
        chol = np.linalg.cholesky(Sigma_inv)
        diag = np.clip(np.diagonal(chol, axis1=-2, axis2=-1), eps, None)
        logdet = 2.0 * np.sum(np.log(diag), axis=-1)
    except LinAlgError:
        logdet = safe_logdet(Sigma_inv, eps=eps)
    #print("[DEBUG] quad term =", quad)
    #print("[DEBUG] logdet term =", logdet)

    result = quad - 0.5 * logdet
    return np.nan_to_num(result, nan=0.0, posinf=1e6, neginf=0.0)



#Validated 7-26-25
def compute_bar_eta2_qj(eta2_qj, Omega_ij, eps=1e-8):
    """
    Compute:
        bar_eta2_qj = (Omega_ij · eta2_qj⁻¹ · Omega_ijᵀ)⁻¹
    Shape:
        eta2_qj   : (..., K, K)
        Omega_ij  : (..., K, K)
    Returns:
        bar_eta2_qj : (..., K, K)
    """
    eta2_inv = safe_inv(eta2_qj, eps=eps)                           # (..., K, K)
    tmp = np.einsum("...ik,...kl->...il", Omega_ij, eta2_inv)       # Ω η2⁻¹
    pushed = np.einsum("...ij,...jk->...ik", tmp, Omega_ij.swapaxes(-1, -2))
    bar_eta2_qj = safe_inv(pushed, eps=eps)
    return bar_eta2_qj

#VALIDATED 7-26-25
def compute_delta_eta(eta1_qi, eta2_qi, eta1_qj, eta2_qj, Omega_ij, eps=1e-8):
    """
    Compute:
        Δη = η2_qi⁻¹ · η1_qi − Ω · η2_qj⁻¹ · η1_qj
    Shape:
        eta1_qi, eta1_qj : (..., K)
        eta2_qi, eta2_qj : (..., K, K)
        Omega_ij         : (..., K, K)
    Returns:
        delta_eta : (..., K)
    """
    eta2_inv_qi = safe_inv(eta2_qi, eps=eps)                        # (..., K, K)
    eta2_inv_qj = safe_inv(eta2_qj, eps=eps)                        # (..., K, K)

    term_i = np.einsum("...ij,...j->...i", eta2_inv_qi, eta1_qi)    # η2_qi⁻¹ · η1_qi
    term_j = np.einsum("...ij,...j->...i", eta2_inv_qj, eta1_qj)    # η2_qj⁻¹ · η1_qj
    term_j_push = np.einsum("...ij,...j->...i", Omega_ij, term_j)   # Ω · η2_qj⁻¹ · η1_qj

    return term_i - term_j_push                                     # (..., K)




#==================================================
#
#
#$
#===============================================

def grad_eta2_from_sigma_mu(
    grad_sigma,  # ∂L/∂Σ — shape (..., K, K)
    grad_mu,     # ∂L/∂μ — shape (..., K)
    mu,          # μ     — shape (..., K)
    sigma,       # Σ     — shape (..., K, K)
):
    """
    Compute:
        ∂L/∂η₂ = -½ Σ [∂L/∂Σ + (∂L/∂μ ⊗ μ)] Σ

    Returns:
        grad_eta2 : (..., K, K), symmetric
    """
    outer = np.einsum("...i,...j->...ij", grad_mu, mu)
    total = grad_sigma + outer
    grad_eta2 = -0.5 * np.einsum("...ik,...kl,...lj->...ij", sigma, total, sigma)
    return symmetrize(grad_eta2)


def symmetrize(mat):
    return 0.5 * (mat + np.swapaxes(mat, -1, -2))

def convert_eta_grads_to_mu_sigma(mu, sigma, grad_eta1, grad_eta2, eps=1e-8):
    """
    Convert gradients from natural parameters (η₁, η₂) to (μ, Σ) space.
    
    η₁ = Σ⁻¹ μ
    η₂ = −½ Σ⁻¹

    So:
        ∂L/∂μ    = Σ⁻¹ ∂L/∂η₁
        ∂L/∂Σ    = −2 Σ⁻¹ ∂L/∂η₂ Σ⁻¹

    Returns:
        grad_mu    : (..., K)
        grad_sigma : (..., K, K)
    """
    sigma_inv = safe_inv(sigma, eps=eps)

    grad_mu = np.einsum("...ij,...j->...i", sigma_inv, grad_eta1)

    grad_sigma = -2.0 * np.einsum("...ik,...kl,...lj->...ij",
                                  sigma_inv, grad_eta2, sigma_inv)

    return grad_mu, symmetrize(grad_sigma)



def convert_mu_sigma_grads_to_eta_grads(
    mu, sigma, grad_mu, grad_sigma, eps=1e-8,
    scale_eta2_by_K=True, clip_eta2_norm=1e4
):
    """
    Convert gradients ∂KL/∂μ and ∂KL/∂Σ to ∂KL/∂η₁ and ∂KL/∂η₂.
    """
    from numerical_utils import sanitize_sigma

    sigma = sanitize_sigma(sigma, eps=eps)

    # ∇_{η₁} = Σ ∇_μ
    grad_eta1 = np.einsum("...ij,...j->...i", sigma, grad_mu)

    # ∇_{η₂} = −½ Σ [∇_Σ + ∇_μ ⊗ μ] Σ
    mu_outer = np.einsum("...i,...j->...ij", grad_mu, mu)
    symmetric_term = grad_sigma + mu_outer

    grad_eta2 = -0.5 * np.einsum("...ik,...kl,...lj->...ij", sigma, symmetric_term, sigma)

    # Optional normalization
    if scale_eta2_by_K:
        K = mu.shape[-1]
        grad_eta2 /= K

    # Clip
    flat_norm = np.linalg.norm(grad_eta2.reshape(grad_eta2.shape[:-2] + (-1,)), axis=-1)
    factor = np.minimum(1.0, clip_eta2_norm / (flat_norm + eps))
    grad_eta2 *= factor[..., None, None]

    # Enforce symmetry after clipping
    grad_eta2 = 0.5 * (grad_eta2 + np.swapaxes(grad_eta2, -1, -2))

    return grad_eta1, grad_eta2





def mu_sigma_to_natural(mu, sigma, eps=1e-8):
    sigma_inv = safe_inv(sigma, eps)
    eta1 = np.einsum('...ij,...j->...i', sigma_inv, mu)
    eta2 = -0.5 * sigma_inv
    return eta1, eta2

def natural_to_mu_sigma(eta1, eta2, eps=1e-8):
    sigma_inv = -2.0 * eta2
    sigma = safe_inv(sigma_inv, eps)
    mu = np.einsum('...ij,...j->...i', sigma, eta1)
    return mu, sigma

def mu_sigma_to_natural_batch(mu, sigma, eps=1e-8):
    """
    Convert (μ, Σ) → (η₁, η₂) in batch.

    η₁ = Σ⁻¹ μ
    η₂ = −½ Σ⁻¹

    Args:
        mu     : (..., K)
        sigma  : (..., K, K)
        eps    : SPD stabilizer for inverse

    Returns:
        eta1   : (..., K)
        eta2   : (..., K, K)
    """
    sigma_inv = safe_inv(sigma, eps=eps)
    eta1 = np.einsum('...ij,...j->...i', sigma_inv, mu)
    eta2 = -0.5 * sigma_inv
    return eta1, eta2


def natural_to_mu_sigma_batch(eta1, eta2, eps=1e-8):
    """
    Convert natural parameters (η₁, η₂) to (μ, Σ) in batch.

    η₁ = Σ⁻¹ μ
    η₂ = −½ Σ⁻¹

    Args:
        eta1 : (..., K)
        eta2 : (..., K, K) — symmetric
        eps  : float, SPD regularization

    Returns:
        mu    : (..., K)
        sigma : (..., K, K)
    """
    # Invert: η₂ = −½ Σ⁻¹  ⇒  Σ = (−½ η₂)⁻¹
    sigma_inv = -2.0 * eta2
    sigma = safe_inv(sigma_inv, eps=eps)

    # μ = Σ η₁
    mu = np.einsum("...ij,...j->...i", sigma, eta1)
    return mu, sigma


def compute_mu_sigma_from_natural(eta1: np.ndarray, eta2: np.ndarray, eps: float = 1e-8):
    """
    Convert natural parameters (η₁, η₂) to mean (μ) and covariance (Σ).
    """
    sigma_inv = -2.0 * eta2
    sigma = safe_inv(sigma_inv, eps=eps)
    sigma = 0.5 * (sigma + np.swapaxes(sigma, -1, -2))  # enforce symmetry

    mu = np.einsum("...ij,...j->...i", sigma, eta1)
    return mu, sigma


def apply_natural_gradient_batch_eta(
    eta1, eta2, d_eta1, d_eta2, mask, eps=1e-8, eta2_scale=None
):
    """
    Apply natural gradient preconditioning for η₁ and η₂:
        δη₁ = Σ ⋅ ∇η₁
        δη₂ = η2_scale · 4 Σ ⋅ ∇η₂ ⋅ Σ
    """
    _, sigma = natural_to_mu_sigma_batch(eta1, eta2, eps=eps)

    delta_eta1 = np.einsum("...ij,...j->...i", sigma, d_eta1)

    K = eta1.shape[-1]
    if eta2_scale is None:
        eta2_scale = 1.0 / K

    tmp = np.einsum("...ij,...jk->...ik", sigma, d_eta2)
    delta_eta2 = eta2_scale * 4.0 * np.einsum("...ij,...jk->...ik", tmp, sigma)
    delta_eta2 = 0.5 * (delta_eta2 + np.swapaxes(delta_eta2, -1, -2))  # enforce symmetry

    mask_eta1 = np.broadcast_to(mask, eta1.shape)
    mask_eta2 = np.broadcast_to(mask[..., None], eta2.shape)

    delta_eta1 *= mask_eta1
    delta_eta2 *= mask_eta2

    return delta_eta1, delta_eta2


def compute_bar_eta2_q_morphed(eta2_q, Phi, eps=1e-8):
    """
    Compute bar_eta2^Φ_q = (Φ η2_q⁻¹ Φᵀ)⁻¹

    Shapes:
        eta2_q : (..., K_q, K_q)
        Phi    : (..., K_p, K_q)

    Returns:
        bar_eta2_q_Phi : (..., K_p, K_p)
    """
    eta2_inv = safe_inv(eta2_q, eps=eps)
    pushed = np.einsum("...ik,...kl,...jl->...ij", Phi, eta2_inv, Phi)
    return safe_inv(pushed, eps=eps)


def compute_delta_eta_p_Phi_q(eta1_p, eta2_p, eta1_q, eta2_q, Phi, eps=1e-8):
    """
    Compute Δη = η2_p⁻¹ η1_p − Φ η2_q⁻¹ η1_q

    Returns:
        delta_eta : (..., K_p)
    """
    eta2_inv_p = safe_inv(eta2_p, eps=eps)
    eta2_inv_q = safe_inv(eta2_q, eps=eps)

    term_p = np.einsum("...ij,...j->...i", eta2_inv_p, eta1_p)
    term_q = np.einsum("...ij,...j->...i", eta2_inv_q, eta1_q)
    term_q_push = np.einsum("...ij,...j->...i", Phi, term_q)

    return term_p - term_q_push


def compute_bar_eta2_p_morphed(eta2_p, Phi_tilde, eps=1e-8):
    """
    Compute bar_eta2^Φ~_p = (Φ~ η2_p⁻¹ Φ~ᵀ)⁻¹

    Shapes:
        eta2_p     : (..., K_p, K_p)
        Phi_tilde  : (..., K_q, K_p)

    Returns:
        bar_eta2_p_PhiTilde : (..., K_q, K_q)
    """
    eta2_inv = safe_inv(eta2_p, eps=eps)
    pushed = np.einsum("...ik,...kl,...jl->...ij", Phi_tilde, eta2_inv, Phi_tilde)
    return safe_inv(pushed, eps=eps)


def compute_delta_eta_q_PhiTilde_p(eta1_q, eta2_q, eta1_p, eta2_p, Phi_tilde, eps=1e-8):
    """
    Compute Δη = η2_q⁻¹ η1_q − Φ~ η2_p⁻¹ η1_p

    Returns:
        delta_eta : (..., K_q)
    """
    eta2_inv_q = safe_inv(eta2_q, eps=eps)
    eta2_inv_p = safe_inv(eta2_p, eps=eps)

    term_q = np.einsum("...ij,...j->...i", eta2_inv_q, eta1_q)
    term_p = np.einsum("...ij,...j->...i", eta2_inv_p, eta1_p)
    term_p_push = np.einsum("...ij,...j->...i", Phi_tilde, term_p)

    return term_q - term_p_push
