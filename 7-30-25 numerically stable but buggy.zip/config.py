import numpy as np
import sys

# ===========================
# DEBUGGING AND UTILITIES
# ===========================

# 1) define at top of your script/module
def scaled_eta(base, *weights, min_den=1.0):
    """
    If all weights sum to zero, return base.
    Otherwise return base / max(sum(weights), min_den).
    """
    total = sum(weights)
    if total <= 0:
        return base
    return base / max(total, min_den)

def set_config_from_params(params):
    """Dynamically override config attributes from a dictionary."""
    this_module = sys.modules[__name__]
    for k, v in params.items():
        setattr(this_module, k, v)



agent_seed    = 42

# Enable or disable gradient updates for morphisms
use_dynamic_morphisms = False
identical_models = False         # If True, all agents share the same p, mu_p_field, sigma_p_field

# config.py
phi_morphism_type = "identity"         # identity  gauge_covariant
phi_model_morphism_type = "identity"

# Toggle between diagonal and full Σ initialization
diagonal_eta2_init = True

# ===========================
# DOMAIN / SPATIAL SETTINGS
# ===========================
K_q           = 7
K_p           = 7        # Fiber dimension of belief/model space (depends on representation)
                 
D             = 2           #dimension of base manifold - d=2 validated

L             = 10         #length of hypercubic base-manifold - PBCs

steps         = 150

N             = 4                       # Number of agents
max_neighbors = 4           # Max number of agent neighbors

agent_radius_range = (2,2)         #agent radii
             
# ===========================
# COUPLINGS & PENALTIES
# ===========================
e_belief               = 1
e_model                = 1

alpha                  = 0.01     
beta                   = 0.25  
belief_mass            = 1000
curvature_weight       = 10000

feedback_weight         = 0
beta_model              = 0.1
model_mass              = 1000
model_curvature_weight  = 10000

#==========================
#    IF NEEDED/CURIOUS
#==========================
phi_phi_tilde_coupling        = 0
phi_damping                   = 0                

fisher_geometry_weight        = 0
fisher_model_geometry_weight  = 0

# ===========================
# INITIALIZATION
# ===========================

eta_base_q            = 1e-5    
eta_base_p            = 1e-5    


eta_base_phi          = 1e-7
eta_base_phi_model    = 1e-8    

# Learning rates for natural parameters
eta1_belief           = 3e-5       # update rate for η₁_q
eta2_belief           = 1e-6       # update rate for η₂_q
eta1_model            = 3e-7       # update rate for η₁_p
eta2_model            = 1e-8       # update rate for η₂_p


phi_scale             = 1
phi_init_smooth_sigma = 1.5
phi_init              = 0.1
phi_model_offset      = 0.1

eta_phi_min           = 1e-6
eta_phi_model_min     = 1e-6



eta_phi_max = 1.0
eta_phi_model_max = 1.0


# ===========================
# AGENT GEOMETRY
# ===========================
# Natural parameter ranges
q_eta1_range = (-2.0, 2.0)
q_eta2_range = (-2.0, -1.0)  # ensures Σ ∈ [0.05, 1.0]

p_eta1_range = (-2.0, 2.0)
p_eta2_range = (-2.0, -1.0)

# ─── η₂ Sanitization Parameters ───
eta2_min_eigval    = -1e-1       # ensure SPD with margin
eta2_target_trace = -0.5 * K_q
        # normalize to fiber dim (e.g. K=5)
eta2_max_norm      = 5

                                   # optional: limit large η₂ matrices
eta2_floor          = -0.25
eta2_outside_val    = -1
eta2_smooth_sigma   = 2

mask_sharpness        = 1.5

gaussian_blur_range_morphism = (1,2)
# ===========================
# STABILITY AND CLIPPING
# ===========================

clip_morphism_grad = True
clip_mu = True
clip_sigma = True

                                    # Gradient clipping magnitudes (optional; set to None to disable)
phi_grad_clip             = 1e4    # Max L2 norm per-point for φ update
phi_model_grad_clip       = 1e4    # Max L2 norm per-point for φ̃ update

grad_eta1_clip            = 1e3
grad_eta2_clip            = 1e2


                                        # Optional: norm type (future-proofing, L2 is default)
gradient_clip_norm_type       = 2           # Use 2 for L2 norm; 1 for L1, np.inf for max-norm
phi_exp_clip                  = 20.0  # or None to disable



eta_phi_adaptive_scaling       = 1.0
eta_phi_model_adaptive_scaling = 1.0

eta_sigma_condition_scaling    = 0.05  # dampen updates if cond(Σ) is large

# Max allowed condition number for Omega matrix
max_omega_condition            = 1e6  # Adjust as needed

# ===========================
# EPSILONS & NUMERICAL STABILITY
# ===========================

log_eps            = 1e-6     # Stabilize log(x)
spd_eps            = 1e-5     # Ensure SPD in eta2 and Sigma
eta2_eps           = spd_eps  # Alias for clarity
eps                = 1e-5
# ===========================
# MASK & INTERACTION THRESHOLDS
# ===========================

support_cutoff_eps = 1e-3     # Mask threshold to include point in agent support
overlap_eps        = 1e-3     # Threshold for computing inter-agent overlap

# ===========================
# SIMULATION THRESHOLDS
# ===========================

epsilon_model      = 1.0      # Threshold to classify meta-agents (can sweep)

# ===========================
# CHECKPOINTING
# ===========================

checkpoint_dir      = "checkpoints"
precision = np.float32

checkpoint_interval = 1

domain_size = (L,) * D

# 3) replace all the old eta_* calculations with calls to scaled_eta
eta_q = scaled_eta(eta_base_q, alpha, beta)

eta_p = scaled_eta(eta_base_p,
                   alpha,
                   beta_model,
                   feedback_weight,
                  
                   model_mass)

eta_phi = scaled_eta(eta_base_phi,
                     belief_mass,
                     
                     curvature_weight,
                     phi_phi_tilde_coupling)

eta_model_phi = scaled_eta(eta_base_phi_model,
                           beta_model,
                          
                           model_mass,
                           phi_phi_tilde_coupling
                           )

num_cores = 1  # or however many threads you want to use

log_full_fields = True  # default off

group_name = 'sl2r'               # Options: "u1", "so3", "sl2r", 'su2'.
representation_type = 'irrep'     # Options: 'irrep', 'fundamental', 'adjoint'


# Enable numerical safety logging
debug = True  # Global debug flag for extra logging inside φ updates                       
debug_gradients = True                  # Log gradient-related issues
debug_sanitize_sigma = True             # Show SPD sanitization messages
fail_on_fallback = False                # Allow recovery rather than crashing


#=================
#    LOGDET
#==================
sanitize_fallback_mode = "dynamic_trace"
sanitize_fallback_alpha = 1e-2
sanitize_fallback_value = 1e-5           # Value used for fallback matrices


# ── Numerical Safeguards ─────────────────────────────
max_fisher_condition = 1e5   # Maximum allowed condition number before fallback


# Control fallback thresholds (optional)
max_safe_inv_fallbacks = 1000
max_safe_logdet_fallbacks = 1000

