# Standard library
import os

# Third-party libraries
import numpy as np
from scipy.ndimage import laplace
from joblib import Parallel, delayed
from numba import njit
from scipy.stats import linregress


# Local project modules
import config
from get_generators import get_generators
from generalized_math_utils import (
    sanitize_q,
    masked_norm,
    laplacian_field,
    zipf_frequencies_from_q
)
from generalized_omega import (
    exp_lie_algebra_irrep,
    batch_apply_omega,
    repair_if_forgotten_batch,
    compute_field_strength,
    )
from powerlaw_suite import (
    zipf_slope,
    )

# Constants
_DEFAULT_CUTOFF = getattr(config, "support_cutoff_eps", 1e-3)
ZIPF_RMIN       = 3
ZIPF_RMAX_FRAC  = 0.5


def kl_divergence(p, q, axis=-1, eps=1e-8):
    """
    Compute KL divergence D_KL(p || q), fully vectorized.

    Args:
        p: np.ndarray (..., K)
        q: np.ndarray (..., K)
        axis: axis over which to compute KL (default: last)
        eps: small constant to prevent log(0)

    Returns:
        kl: np.ndarray of shape broadcasted over all but `axis`
    """
    p_safe = np.clip(p, eps, 1.0)
    q_safe = np.clip(q, eps, 1.0)
    return np.sum(p_safe * (np.log(p_safe) - np.log(q_safe)), axis=axis)



@njit
def jit_sanitize_q(q, eps=1e-8):
    """
    Ensure q is positive and normalized. Works on (M, K)
    """
    M, K = q.shape
    out = np.maximum(q, eps)
    for i in range(M):
        total = 0.0
        for j in range(K):
            total += out[i, j]
        for j in range(K):
            out[i, j] /= total + eps
    return out


def support_mask(mask, cutoff=_DEFAULT_CUTOFF):
    return (mask > cutoff)

def overlap_mask(mask_i, mask_j, cutoff=_DEFAULT_CUTOFF):
    return support_mask(mask_i, cutoff) & support_mask(mask_j, cutoff)


def threshold_mask(mask: np.ndarray) -> np.ndarray:
    """
    Turn a float support field into a boolean support region.
    Works for any dimensionality of mask.
    """
    eps = getattr(config, "support_cutoff_eps", 1e-3)
    return mask > eps  # same shape, but boolean



def compute_kl_field(agents, i):
    q = sanitize_q(agents[i].q)
    p = sanitize_q(agents[i].p)
    kl = kl_divergence(q, p)
    return kl * agents[i].mask

def compute_coherence(phi: np.ndarray, mask: np.ndarray) -> float:
    mask_bool = threshold_mask(mask)
    if not np.any(mask_bool):
        return 0.0
    return np.abs(np.mean(np.exp(1j * phi[mask_bool])))


#USED OPNLY IN RUNSIM
def compute_phi_norm_field(agents, i, phi_field="phi"):
    phi = getattr(agents[i], phi_field)
    mask = threshold_mask(agents[i].mask)
    return np.linalg.norm(phi, axis=-1) * mask


def compute_alignment_field(agents, i, eps=config.support_cutoff_eps, log_eps=config.log_eps) -> np.ndarray:
    A = agents[i]
    mask_i = A.mask > eps
    if not mask_i.any() or not A.neighbors:
        return np.zeros_like(mask_i, dtype=np.float32)

    q_i_full = sanitize_q(A.q, eps=log_eps)
    shape = A.mask.shape
    kl_accum = np.zeros(shape, dtype=np.float32)
    n_nb_at = np.zeros(shape, dtype=np.int32)

    for nb in A.neighbors:
        B = agents[nb["id"]]
        mask_j = B.mask > eps
        overlap = mask_i & mask_j
        if not overlap.any():
            continue

        qi_pts = q_i_full[overlap]
        qj_pts = B.q[overlap]  # ← skip sanitize here

        Oi_patch = A.Omega[overlap]
        Oj_inv = B.Omega_inv[overlap]
        Omegas_ij = np.einsum("mab,mbc->mac", Oi_patch, Oj_inv)

        qj_trans = sanitize_q(batch_apply_omega(qj_pts, Omegas_ij), eps=log_eps)
        kl_vals = kl_divergence(qi_pts, qj_trans)

        kl_accum[overlap] += kl_vals
        n_nb_at[overlap] += 1

    out = np.zeros_like(kl_accum)
    valid = n_nb_at > 0
    out[valid] = kl_accum[valid] / n_nb_at[valid]
    return out * mask_i

def compute_model_alignment_field(
    agents,
    i,
    eps: float = config.support_cutoff_eps,
    log_eps: float = config.log_eps
) -> np.ndarray:
    """
    Compute D_KL(p_i || Ω̃_{ij} p_j) by temporarily overriding q and φ with p and φ̃.
    """
    from copy import deepcopy
    A_tmp = deepcopy(agents[i])
    A_tmp.q = A_tmp.p
    A_tmp.phi = A_tmp.phi_model

    agents_tmp = agents[:]
    agents_tmp[i] = A_tmp

    try:
        out = compute_alignment_field(agents_tmp, i, eps=eps, log_eps=log_eps)
    except Exception as e:
        print(f"[DEBUG] Model alignment failed for agent {i}: {e}")
        out = None

    if out is None or not np.any(out):
        print(f"[DEBUG] compute_model_alignment_field: returning zeros for agent {i}")
        return np.zeros_like(A_tmp.mask, dtype=config.precision)

    return out


#USED ONLY IN RUN_SIM AND LOG_ALL_METRICS
def compute_phi_norm(
    agents,
    phi_field="phi",
    mask_field="mask",
    support_cutoff_eps=1e-3,
):
    norms = []
    for agent in agents:
        phi  = getattr(agent, phi_field)
        mask = getattr(agent, mask_field) > support_cutoff_eps
        n    = mask.sum()
        if n > 0:
            norms.append(masked_norm(phi, mask) / n)
    return float(np.mean(norms)) if norms else 0.0

#USED ONLY IN RUN SIM
def compute_entropy_field(agents, i, q_field="q", mask_field="mask", support_cutoff_eps=1e-3, log_eps=1e-8):
    q     = sanitize_q(getattr(agents[i], q_field), eps=log_eps)
    mask  = getattr(agents[i], mask_field) > support_cutoff_eps
    ent   = -np.sum(q * np.log(q), axis=-1)
    return ent * mask


#USED IN LOG_ALL_METRICS
def compute_phi_laplacian_norm(
    agents,
    phi_field: str = "phi",
    mask_field: str = "mask",
    support_cutoff_eps: float | None = None,
    log_eps: float = 1e-8,
) -> float:
    """
    Compute the average per-agent RMS norm of the Laplacian of the φ field.
    1) Threshold mask by support_cutoff_eps.
    2) Compute componentwise Laplacian via scipy.ndimage.laplace.
    3) Compute masked_norm over support and normalize by support size.
    4) Return the mean over all agents.
    """
    if support_cutoff_eps is None:
        support_cutoff_eps = getattr(config, "support_cutoff_eps", 1e-3)


    norms = []
    for agent in agents:
        phi = getattr(agent, phi_field)
        mask = getattr(agent, mask_field) > support_cutoff_eps
        if not np.any(mask):
            continue

        # componentwise Laplacian
        lap_phi = np.stack([laplace(phi[..., d]) for d in range(phi.shape[-1])], axis=-1)
        # RMS norm over support
        val = masked_norm(lap_phi, mask) / (np.count_nonzero(mask) + log_eps)
        norms.append(val)

    return float(np.mean(norms)) if norms else 0.0


def _agent_stats(
    i,
    A,
    step,
    q_field,
    p_field,
    phi_belief_field,
    phi_model_field,
    mask_field,
    cfg,
    generators,
    Q_list,
    P_list,
    Mask_list,
    O_bel,
    O_inv,
    O_mod,
    O_mod_inv,
    n_jobs
):
    mask = Mask_list[i]
    support = int(mask.sum())

    if not support:
        return i, {k: 0.0 for k in [
            "e_self", "e_align", "e_feedback", "e_mod_align",
            "e_lap_bel", "e_mass_bel", "e_lap_mod", "e_mass_mod",
            "e_couple", "e_curv", "e_curv_mod",
            "phi_norm", "phi_model_norm", "entropy",
            "lap_phi_norm", "delta_phi_norm",
            "curvature_norm", "curvature_model_norm",
            "fisher_information", "zipf_slope", "zipf_r2",
            "kl_align_total", "kl_align_avg_per_point",
        ]} | {"model_arr": np.zeros(len(Mask_list), dtype=float)}

    # field slices
    qi, pi = Q_list[i], P_list[i]
    lie_gens = generators
    log_eps = cfg["log_eps"]

    # KL Terms
    e_self        = compute_self_energy(qi, pi, mask, cfg["alpha"], log_eps)
    e_feedback    = compute_feedback_energy(pi, qi, mask, cfg["model_feedback_weight"], log_eps)
    e_align       = compute_alignment_energy(i, A, Q_list, Mask_list, O_bel, O_inv, cfg["beta"], log_eps, n_jobs)
    e_mod_align   = compute_model_alignment_energy(i, A, P_list, Mask_list, O_mod, O_mod_inv,
                                                   cfg["model_align_weight"], log_eps, n_jobs)

    # Laplacian + mass
    e_lap_bel     = compute_laplacian_energy(A.phi, mask, cfg["gamma"])
    e_mass_bel    = compute_mass_energy(A.phi, mask, cfg["gauge_weight"])
    e_lap_mod     = compute_laplacian_energy(A.phi_model, mask, cfg["model_gauge_weight"])
    e_mass_mod    = compute_mass_energy(A.phi_model, mask, cfg["model_mass_weight"])

    # Coupling + curvature
    e_couple      = compute_phi_coupling_energy(A.phi, A.phi_model, mask, cfg["phi_phi_tilde_coupling"])
    e_curv, curv_norm_bel = compute_curvature_energy(A.phi, mask, cfg["curvature_weight"], lie_gens)
    e_curv_mod, curv_norm_mod = compute_curvature_energy(A.phi_model, mask, cfg["curvature_weight"], lie_gens)

    # Scalar diagnostics
    entropy        = compute_entropy(qi, mask, log_eps)
    phi_norm       = np.linalg.norm(A.phi[mask], axis=-1).sum()
    phi_model_norm = np.linalg.norm(A.phi_model[mask], axis=-1).sum()
    lap_phi_norm   = np.linalg.norm(laplacian_field(A.phi)[mask], axis=-1).sum()
    delta_phi_norm = float(np.linalg.norm(getattr(A, "delta_phi", 0.0), axis=-1)[mask].max()) if hasattr(A, "delta_phi") else 0.0

    # Fisher info
    q_s = sanitize_q(qi, eps=log_eps)[mask]
    grads = np.gradient(q_s, axis=tuple(range(q_s.ndim - 1)))
    fisher_information = float(sum((g**2 / (q_s + log_eps)).sum() for g in grads))

    # Zipf
    freqs = zipf_frequencies_from_q(qi, mask)
    slope, r2 = zipf_slope(freqs, rmin=ZIPF_RMIN, rmax=int(len(freqs) * ZIPF_RMAX_FRAC))

    # Overlap stats
    total_overlap_points = sum((mask & Mask_list[nb["id"]]).sum() for nb in A.neighbors if (mask & Mask_list[nb["id"]]).any())

    stats = {
        "e_self":        e_self,
        "e_align":       e_align,
        "e_feedback":    e_feedback,
        "e_mod_align":   e_mod_align,
        "e_lap_bel":     e_lap_bel,
        "e_mass_bel":    e_mass_bel,
        "e_lap_mod":     e_lap_mod,
        "e_mass_mod":    e_mass_mod,
        "e_couple":      e_couple,
        "e_curv":        e_curv,
        "e_curv_mod":    e_curv_mod,
        "phi_norm":      phi_norm,
        "phi_model_norm":phi_model_norm,
        "entropy":       entropy,
        "lap_phi_norm":  lap_phi_norm,
        "delta_phi_norm":delta_phi_norm,
        "curvature_norm":       curv_norm_bel,
        "curvature_model_norm": curv_norm_mod,
        "fisher_information": fisher_information,
        "zipf_slope": slope,
        "zipf_r2":    r2,
        "kl_align_total": e_align,
        "kl_align_avg_per_point": (e_align / max(total_overlap_points, 1)) / support,
        "model_arr": np.zeros(len(Mask_list), dtype=float)
    }

    return i, stats



def compute_zipf(agent, rmin=3, rmax_frac=0.5):
    freqs = zipf_frequencies_from_q(agent.q, agent.mask)
    freqs = np.asarray(freqs, dtype=float).ravel()
    freqs = freqs[freqs > 0]

    if freqs.size < rmin:
        return 0.0, 0.0

    rmax = int(len(freqs) * rmax_frac)
    rmax = min(len(freqs), rmax)

    ranks = np.arange(1, len(freqs) + 1)
    x = np.log(ranks[rmin-1:rmax])
    y = np.log(freqs[rmin-1:rmax])

    if len(x) < 2 or np.std(y) < 1e-8:
        return 0.0, 0.0

    slope, intercept, r, _, _ = linregress(x, y)
    return slope, r**2

def preprocess_fields(agents, q_field, p_field, mask_field, overlap_eps, log_eps):
    from generalized_math_utils import sanitize_q
    Q_list, P_list, Mask_list = [], [], []
    O_bel, O_inv, O_mod, O_mod_inv = [], [], [], []

    for A in agents:
        mask = getattr(A, mask_field) > overlap_eps
        Mask_list.append(mask)
        Q_list.append(sanitize_q(getattr(A, q_field), eps=log_eps))
        P_list.append(sanitize_q(getattr(A, p_field), eps=log_eps))
        O_bel.append(A.Omega)
        O_inv.append(A.Omega_inv)
        O_mod.append(A.Omega_model)
        O_mod_inv.append(A.Omega_model_inv)

    return Q_list, P_list, Mask_list, O_bel, O_inv, O_mod, O_mod_inv

def compute_agent_metrics(
    i, A, Q_list, P_list, Mask_list,
    O_bel, O_inv, O_mod, O_mod_inv,
    cfg, gens, log_eps
):
    mask = Mask_list[i]
    if not mask.any():
        return i, zero_agent_metrics(len(Q_list))

    stats = compute_all_agent_metrics(
        i, A, Q_list, P_list, Mask_list,
        O_bel, O_inv, O_mod, O_mod_inv,
        cfg, gens, log_eps
    )
    return i, stats

def zero_agent_metrics(N: int) -> dict:
    return {
        "e_self": 0, "e_align": 0, "e_feedback": 0, "e_mod_align": 0,
        "e_lap_bel": 0, "e_mass_bel": 0, "e_lap_mod": 0, "e_mass_mod": 0,
        "e_couple": 0, "e_curv": 0, "e_curv_mod": 0,

        "phi_norm": 0,
        "phi_model_norm": 0,
        "entropy": 0,
        "lap_phi_norm": 0,
        "delta_phi_norm": 0,
        "fisher_information": 0,
        "curvature_norm": 0,
        "curvature_model_norm": 0,

        "zipf_slope": 0,
        "zipf_r2": 1,

        "kl_self_avg_per_point": 0,
        "kl_feedback_avg_per_point": 0,
        "kl_model_align_avg_per_point": 0,
        "kl_align_avg_per_point": 0,

        "model_arr": np.zeros(N, dtype=float)
    }



def accumulate_and_log_metrics(results, agents, step, Q_list, Mask_list):
    from generalized_math_utils import zipf_frequencies_from_q, zipf_slope

    keys = ["e_self", "e_align", "e_feedback", "e_mod_align"]
    accum = {k: 0.0 for k in keys}
    total_support = 0
    N = len(agents)

    for i, s in results:
        support = int(Mask_list[i].sum())
        total_support += support
        for k in keys:
            accum[k] += s[k]
        agents[i].log_metrics(step, {
        "kl_self":         s["e_self"]        / support,
        "kl_feedback":     s["e_feedback"]    / support,
        "kl_align":        s["e_align"]       / support,
        "kl_mod_align":    s["e_mod_align"]   / support,

        "kl_self_avg_per_point":        s["kl_self_avg_per_point"],
        "kl_feedback_avg_per_point":    s["kl_feedback_avg_per_point"],
        "kl_model_align_avg_per_point": s["kl_model_align_avg_per_point"],
        "kl_align_avg_per_point":       s["kl_align_avg_per_point"],

        "entropy":          s["entropy"],
        "phi_norm":         s["phi_norm"],
        "phi_model_norm":   s["phi_model_norm"],
        "lap_phi_norm":     s["lap_phi_norm"],
        "delta_phi_norm":   s["delta_phi_norm"],
        
        "lap_phi":         s["e_lap_bel"]     / support,
        "mass_phi":        s["e_mass_bel"]    / support,
        "lap_phi_mod":     s["e_lap_mod"]     / support,
        "mass_phi_mod":    s["e_mass_mod"]    / support,
        "phi_phi_couple":  s["e_couple"]      / support,
        "curvature_norm":       s["curvature_norm"]       / support,
        "curvature_model_norm": s["curvature_model_norm"] / support,

        "zipf_slope":      s["zipf_slope"],
        "zipf_r2":         s["zipf_r2"],
    })


    S = max(total_support, 1)
    metrics = {k: accum[k] / S for k in keys}
    metrics["total_energy"] = sum(accum.values()) / S
    metrics["step"] = step

    # Global Zipf
    pooled_freqs = sum(zipf_frequencies_from_q(Q_list[i], Mask_list[i]) for i in range(N))
    pooled_freqs /= pooled_freqs.sum()
    slope, r2 = zipf_slope(pooled_freqs, rmin=config.ZIPF_RMIN, rmax=int(len(pooled_freqs) * config.ZIPF_RMAX_FRAC))
    metrics["global_zipf_slope"] = slope
    metrics["global_zipf_r2"]    = r2

    return metrics

def compute_alignment_field_pairwise(
    agents,
    i,
    j,
    eps: float = config.support_cutoff_eps,
    log_eps: float = config.log_eps
) -> np.ndarray:
    """
    Compute spatial KL alignment field D_KL(q_i || Ω_ij q_j) for a single agent pair (i, j).
    Returns a full 2D array with nonzero values only on overlapping support.
    """
    A = agents[i]
    B = agents[j]
    mask_i = A.mask > eps
    mask_j = B.mask > eps
    overlap = mask_i & mask_j

    if not np.any(overlap):
        return np.zeros_like(A.mask, dtype=float)

    from generalized_diagnostics_metrics import sanitize_q, kl_divergence
    from generalized_omega import batch_apply_omega

    qi = sanitize_q(A.q, eps=log_eps)[overlap]
    qj = sanitize_q(B.q, eps=log_eps)[overlap]

    Oi     = A.Omega[overlap]
    Oj_inv = B.Omega_inv[overlap]
    Omega_ij = np.einsum("mab,mbc->mac", Oi, Oj_inv)

    qj_trans = sanitize_q(batch_apply_omega(qj, Omega_ij), eps=log_eps)
    kl_vals  = kl_divergence(qi, qj_trans)

    field = np.zeros_like(A.mask, dtype=float)
    field[overlap] = kl_vals
    return field


def compute_self_energy(qi, pi, mask, alpha, log_eps):
    return alpha * np.sum(kl_divergence(qi, pi, eps=log_eps)[mask])


def compute_feedback_energy(pi, qi, mask, model_feedback_weight, log_eps):
    return model_feedback_weight * np.sum(kl_divergence(pi, qi, eps=log_eps)[mask])

def compute_alignment_energy(i, A, Q_list, Mask_list, O_bel, O_inv, beta, log_eps, n_jobs):
    qi = Q_list[i]
    mask = Mask_list[i]
    e_align = 0.0
    for nb in A.neighbors:
        j = nb["id"]
        ov = mask & Mask_list[j]
        if not ov.any(): continue
        q_j_ov = Q_list[j][ov]
        qj_t = sanitize_q(batch_apply_omega(q_j_ov,
                                            np.einsum("mab,mbc->mac", O_bel[i][ov], O_inv[j][ov]),
                                            n_jobs=n_jobs), eps=log_eps)
        e_align += beta * np.sum(kl_divergence(qi[ov], qj_t, eps=log_eps))
    return e_align

def compute_model_alignment_energy(i, A, P_list, Mask_list, O_mod, O_mod_inv, model_align_weight, log_eps, n_jobs):
    pi = P_list[i]
    mask = Mask_list[i]
    e_mod_align = 0.0
    for nb in A.neighbors:
        j = nb["id"]
        ov = mask & Mask_list[j]
        if not ov.any(): continue
        p_j_ov = P_list[j][ov]
        pj_t = sanitize_q(batch_apply_omega(p_j_ov,
                                            np.einsum("mab,mbc->mac", O_mod[i][ov], O_mod_inv[j][ov]),
                                            n_jobs=n_jobs), eps=log_eps)
        e_mod_align += model_align_weight * np.sum(kl_divergence(pi[ov], pj_t, eps=log_eps))
    return e_mod_align

def compute_laplacian_energy(phi, mask, weight):
    lap = laplacian_field(phi)
    return weight * np.sum(np.linalg.norm(lap[mask], axis=-1))

def compute_mass_energy(phi, mask, weight):
    return weight * np.sum(np.linalg.norm(phi[mask], axis=-1)**2)

def compute_phi_coupling_energy(phi, phi_model, mask, weight):
    diff = (phi - phi_model) * mask[..., None]
    return weight * np.sum(np.linalg.norm(diff, axis=-1)**2)

def compute_curvature_energy(phi, mask, weight, lie_gens):
    F = compute_field_strength(phi, lie_gens)
    total = 0.0
    for v in F.values():
        if v.ndim < 3:
            total += v**2
        elif v.ndim == 3:
            total += np.sum(v**2, axis=-1)
        else:
            total += np.sum(v**2, axis=(-2, -1))
    return weight * float(np.sum(total[mask])), float(np.sum(total[mask]))

def compute_entropy(q, mask, log_eps):
    q_masked = sanitize_q(q, eps=log_eps)[mask]
    return float(-np.sum(q_masked * np.log(q_masked + log_eps)))


def compute_all_agent_metrics(
    i, A, Q_list, P_list, Mask_list,
    O_bel, O_inv, O_mod, O_mod_inv,
    cfg, gens, log_eps
):
    """
    Compute all energy components and diagnostics for agent i.
    """
    mask = Mask_list[i]
    q    = Q_list[i]
    p    = P_list[i]
    
    stats = {}
    stats["e_self"] = compute_self_energy(q, p, mask, cfg["alpha"], log_eps)
    stats["e_feedback"] = compute_feedback_energy(p, q, mask, cfg["model_feedback_weight"], log_eps)
    stats["e_align"] = compute_alignment_energy(i, A, Q_list, Mask_list, O_bel, O_inv, cfg["beta"], log_eps, cfg.get("n_jobs_align", 1))
    stats["e_mod_align"] = compute_model_alignment_energy(i, A, P_list, Mask_list, O_mod, O_mod_inv, cfg["model_align_weight"], log_eps, cfg.get("n_jobs_align", 1))
    stats["e_couple"] = compute_phi_coupling_energy(A.phi, A.phi_model, mask, cfg["phi_phi_tilde_coupling"])
    stats["e_curv"], stats["curvature_norm"] = compute_curvature_energy(A.phi, mask, cfg["curvature_weight"], gens)
    stats["e_curv_mod"], stats["curvature_model_norm"] = compute_curvature_energy(A.phi_model, mask, cfg["curvature_weight"], gens)
    stats["e_lap_bel"] = compute_laplacian_energy(A.phi, mask, cfg["gamma"])
    stats["e_mass_bel"] = compute_mass_energy(A.phi, mask, cfg["gauge_weight"])
    stats["e_lap_mod"] = compute_laplacian_energy(A.phi_model, mask, cfg["model_gauge_weight"])
    stats["e_mass_mod"] = compute_mass_energy(A.phi_model, mask, cfg["model_mass_weight"])
    stats["entropy"] = compute_entropy(q, mask, log_eps)
    stats["kl_align_avg_per_point"] = stats["e_align"] / max(mask.sum(), 1)
    stats["kl_model_align_avg_per_point"] = stats["e_mod_align"] / max(mask.sum(), 1)
    stats["kl_self_avg_per_point"] = stats["e_self"] / max(mask.sum(), 1)
    stats["kl_feedback_avg_per_point"] = stats["e_feedback"] / max(mask.sum(), 1)
    stats["phi_norm"] = np.linalg.norm(A.phi[mask], axis=-1).sum()
    stats["phi_model_norm"] = np.linalg.norm(A.phi_model[mask], axis=-1).sum()
    lap_phi = laplacian_field(A.phi)
    stats["lap_phi_norm"] = np.linalg.norm(lap_phi[mask], axis=-1).sum()
   
    if hasattr(A, "delta_phi"):
        stats["delta_phi_norm"] = np.linalg.norm(A.delta_phi[mask], axis=-1).sum()
    else:
        stats["delta_phi_norm"] = 0.0


    # Zipf
    freqs = zipf_frequencies_from_q(q, mask)
    if freqs.sum() > 0:
        freqs /= freqs.sum()
        slope, r2 = zipf_slope(freqs, rmin=cfg["ZIPF_RMIN"], rmax=int(len(freqs) * cfg["ZIPF_RMAX_FRAC"]))
    else:
        slope, r2 = 0.0, 1.0
    stats["zipf_slope"] = slope
    stats["zipf_r2"] = r2

    return stats


def log_all_metrics_fused(
    agents,
    step: int,
    params: dict | None = None,
    q_field: str              = "q",
    p_field: str              = "p",
    phi_belief_field: str     = "phi",
    phi_model_field: str      = "phi_model",
    mask_field: str           = "mask",
    overlap_eps: float | None = None,
    log_eps: float            = 1e-8,
    n_jobs: int               = 1,
    generators=None
) -> dict:
    

    cfg = params or {k: getattr(config, k) for k in dir(config) if not k.startswith("__")}
    if overlap_eps is None:
        overlap_eps = cfg.get("support_cutoff_eps", config.support_cutoff_eps)
    if generators is None:
        generators = get_generators(config.group_name, config.K)

    Q_list, P_list, Mask_list, O_bel, O_inv, O_mod, O_mod_inv = preprocess_fields(
        agents, q_field, p_field, mask_field, overlap_eps, log_eps
    )

    results = Parallel(n_jobs=n_jobs, backend="threading")([
        delayed(compute_agent_metrics)(
            i, agents[i], Q_list, P_list, Mask_list,
            O_bel, O_inv, O_mod, O_mod_inv, cfg, generators, log_eps
        )
        for i in range(len(agents))
    ])

    return accumulate_and_log_metrics(results, agents, step, Q_list, Mask_list)


def log_max_overlap_fields(agents, step, outdir,
                           eps=config.support_cutoff_eps):
    """
    Finds the two agents with the largest overlap and logs:
      - belief vs. model alignment fields
      - mu/sigma for belief (q) and model (p)
    into a compressed .npz per step.
    """
    os.makedirs(outdir, exist_ok=True)

    # 1) Identify best pair
    max_overlap = 0
    best_pair = None
    for i, A in enumerate(agents):
        mask_i = A.mask > eps
        if not mask_i.any():
            continue
        for nb in A.neighbors:
            j = nb["id"]
            mask_j = agents[j].mask > eps
            ov = mask_i & mask_j
            cnt = int(ov.sum())
            if cnt > max_overlap:
                max_overlap = cnt
                best_pair = (i, j)

    if best_pair is None:
        print(f"[DEBUG] No overlapping agent pairs at step {step}")
        return

    i, j = best_pair
   
    # 2) Re-exponentiate Ω frames only for agents i and j (if not already cached)
    gens = get_generators(config.group_name, config.K)

    for idx in [i, j]:
        A = agents[idx]
        if A._exp_phi is None:
            A._exp_phi = exp_lie_algebra_irrep(A.phi, gens, group_name=config.group_name)
        if A._exp_neg_phi is None:
            A._exp_neg_phi = exp_lie_algebra_irrep(-A.phi, gens, group_name=config.group_name)
        if A._exp_phi_model is None:
            A._exp_phi_model = exp_lie_algebra_irrep(A.phi_model, gens, group_name=config.group_name)
        if A._exp_neg_phi_model is None:
            A._exp_neg_phi_model = exp_lie_algebra_irrep(-A.phi_model, gens, group_name=config.group_name)


    # 3) Compute alignment fields
    belief_field = compute_alignment_field(agents, i)
    model_field  = compute_model_alignment_field(agents, i)

    # 3b) Extract µ/σ fields for the chosen agent i
    mu_q     = agents[i].mu_q_field
    sigma_q  = agents[i].sigma_q_field
    mu_p     = agents[i].mu_p_field
    sigma_p  = agents[i].sigma_p_field

    q_i = sanitize_q(agents[i].q)
    p_i = sanitize_q(agents[i].p)

    # KL(q‖p)
    kl_self_field = kl_divergence(q_i, p_i, axis=-1)
    # KL(p‖q)
    kl_feedback_field = kl_divergence(p_i, q_i, axis=-1)

    # 4) Save everything in one compressed archive
    fname = os.path.join(outdir, f"step{step:05d}_pair_{i}_{j}.npz")
    # 4a) Agent support mask (so we can blank out outside later)
    mask_i = (agents[i].mask > eps).astype(np.float32)

    # 4b) Save everything in one compressed archive
    np.savez_compressed(
        fname,
        agent_i            = i,
        agent_j            = j,
        overlap            = max_overlap,
        mask_i             = mask_i,
        belief_alignment   = belief_field,
        model_alignment    = model_field,
        mu_q               = mu_q,
        sigma_q            = sigma_q,
        mu_p               = mu_p,
        sigma_p            = sigma_p,
        kl_self_field      = kl_self_field,
        kl_feedback_field  = kl_feedback_field,

    )
    
