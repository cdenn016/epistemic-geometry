import numpy as np
import sys

# ===========================
# DEBUGGING AND UTILITIES
# ===========================

# 1) define at top of your script/module
def scaled_eta(base, *weights, min_den=1.0):
    """
    If all weights sum to zero, return base.
    Otherwise return base / max(sum(weights), min_den).
    """
    total = sum(weights)
    if total <= 0:
        return base
    return base / max(total, min_den)



def set_config_from_params(params):
    """Dynamically override config attributes from a dictionary."""
    this_module = sys.modules[__name__]
    for k, v in params.items():
        setattr(this_module, k, v)


# ===========================
# GROUP & REPRESENTATION SETTINGS
# ===========================

group_name = 'sl2r'               # Options: "u1", "so3", "sl2r", 'su2'.
representation_type = 'irrep'     # Options: 'irrep', 'fundamental', 'adjoint'
use_commutator = False            # use "false" to use the general exp.exp multiplication
debug = True  # Global debug flag for extra logging inside φ updates
                      

# ===========================
# DOMAIN / SPATIAL SETTINGS
# ===========================
K = 55          # Fiber dimension of belief/model space (depends on representation)
D = 2            #dimension of base manifold

L = 25           #length of hypercubic base-manifold

steps = 200

N = 8                           # Number of agents
max_neighbors = 6                # Max number of agent neighbors
agent_seed = 23


# ===========================
# COUPLINGS & PENALTIES
# ===========================
e = 1
alpha = 5                     # KL(q || p) self-energy
beta = 10                    # KL(q || Ω q) belief coupling
gamma = 5                    # Laplacian penalty on φ
gauge_weight = 20           # φ² mass term

model_align_weight = 20      # KL(p || Ω̃ p) analogous to beta
model_gauge_weight = 10       # Laplacian penalty on φ_model
model_mass_weight = 5     # φ_model² mass term
model_feedback_weight = 10     # KL feedback p || q analogous to alpha

phi_phi_tilde_coupling = 5   # Coupling φ ↔ φ̃

curvature_weight = 0
phi_damping = 0


psi_radius_range = (2, 4)         #agent radii

# ===========================
# DISTRIBUTION SETTINGS
# ===========================
spatial_resolution = 1
distribution_family = 'gaussian'   # Options: "gaussian", "exponential", "beta". "uniform", etc.


#=================================
# TRANSPORT DISTRIBUTION INJECTION
#=================================
injection_mode = "from_q"  # or "gaussian", "from_q", "from_p, "delta", etc




# ===========================
# AGENT GEOMETRY
# ===========================
q_mu_range = (2, K-2)
q_sigma_range = (1, 4)
p_mu_range = (2, K-2)
p_sigma_range = (1, 3)
similar_p_models = False


mu_sigma_scale_range = (2, 6)

mask_sharpness = 1.5
mu_field_smooth_range = (2, 6)
sigma_field_smooth_range = (2,6)

# ===========================
# INITIALIZATION
# ===========================



phi_init_smooth_sigma = 2
phi_init = 0.2
phi_model_offset = 0.1



# 2) keep your base‐rate definitions
eta_base_q         = 1e-4    # Leaves Δq ≃ 0.02 per step
eta_base_p         = 1e-5    # Similarly for p
eta_base_phi       = 1e-4    # Δφ ≃ 0.02–0.05 per step
eta_base_phi_model = 0.00125  # Δφ̃ ≃ 0.02 per step

# 3) replace all the old eta_* calculations with calls to scaled_eta
eta_q = scaled_eta(eta_base_q, alpha, beta)

eta_p = scaled_eta(eta_base_p,
                   alpha,
                   model_align_weight,
                   model_feedback_weight,
                   model_gauge_weight,
                   model_mass_weight)

eta_phi = scaled_eta(eta_base_phi,
                     gauge_weight,
                     gamma,
                     curvature_weight,
                     phi_damping,
                     phi_phi_tilde_coupling)

eta_model_phi = scaled_eta(eta_base_phi_model,
                           model_align_weight,
                           model_gauge_weight,
                           model_mass_weight,
                           phi_phi_tilde_coupling,
                           phi_damping)


# ===========================
# STABILITY AND CLIPPING
# ===========================

phi_clip_threshold = 4000       # scale down large φ shifts
phi_max_norm       = 100       # keep φ in a reasonable reference frame
gradient_clip      = 1e4      # if also applied to φ gradients
blowup_threshold   = 4000.0      # skip updates that are clearly unstable
phi_diff_clip = 3.0            # or experiment with values like 2.0 or 5.0


# ===========================
# EPSILONS & PRECISION
# ===========================

log_eps = 1e-10
support_cutoff_eps = 1e-1           #agent and mask overlap = at 1e-1
overlap_eps = 1e-5
eps = 1e-10

precision = np.float32

# ===========================
# CHECKPOINTING
# ===========================

checkpoint_dir = "checkpoints"
save_checkpoints = True
checkpoint_interval = 1

domain_size = (L,) * D