# -*- coding: utf-8 -*-
"""
Created on Fri Jul 18 17:43:03 2025

@author: chris and christine
"""

import numpy as np
from generalized_omega import batch_apply_omega, compute_omega_pair
from get_generators import get_generators
from numerical_utils import is_spd_matrix
from natural_gradient_utils import compute_kl_gaussian_fields
import config

def random_mvg_field(H, W, K, seed=42):
    rng = np.random.default_rng(seed)
    mu = rng.standard_normal((H, W, K)).astype(np.float32)

    A = rng.standard_normal((H, W, K, K))
    sigma = np.einsum("...ik,...jk->...ij", A, A)  # Σ = A Aᵀ
    sigma += config.eps * np.eye(K)  # Stabilize
    return mu, sigma

def test_identity_transport():
    H, W, K = 4, 4, 3
    mu, sigma = random_mvg_field(H, W, K)
    I = np.broadcast_to(np.eye(K, dtype=np.float32), (H, W, K, K))

    mu_t, sigma_t = batch_apply_omega(mu, sigma, I)

    assert np.allclose(mu, mu_t, atol=1e-5), "[identity] μ mismatch"
    assert np.allclose(sigma, sigma_t, atol=1e-5), "[identity] Σ mismatch"
    print("✅ Identity transport passed")

def test_roundtrip_transport():
    H, W, K = 4, 4, 3
    mu, sigma = random_mvg_field(H, W, K)
    gens = get_generators("sl2r", K)
    phi_i = np.zeros((H, W, 3))
    phi_j = np.random.randn(H, W, 3) * 0.2
    omega = compute_omega_pair(phi_i, phi_j, gens)
    omega_inv = compute_omega_pair(phi_j, phi_i, gens)

    mu_fwd, sigma_fwd = batch_apply_omega(mu, sigma, omega)
    mu_back, sigma_back = batch_apply_omega(mu_fwd, sigma_fwd, omega_inv)

    assert np.allclose(mu, mu_back, atol=1e-3), "[roundtrip] μ mismatch"
    assert np.allclose(sigma, sigma_back, atol=1e-3), "[roundtrip] Σ mismatch"
    print("✅ Roundtrip transport passed")

def test_spd_preservation():
    H, W, K = 4, 4, 3
    mu, sigma = random_mvg_field(H, W, K)
    gens = get_generators("sl2r", K)
    phi_i = np.zeros((H, W, 3))
    phi_j = np.random.randn(H, W, 3) * 0.4
    omega = compute_omega_pair(phi_i, phi_j, gens)
    _, sigma_t = batch_apply_omega(mu, sigma, omega)

    for i in range(H):
        for j in range(W):
            assert is_spd_matrix(sigma_t[i, j]), f"[SPD] failed at ({i},{j})"
    print("✅ SPD preservation passed")

def test_kl_roundtrip():
    H, W, K = 4, 4, 3
    mu, sigma = random_mvg_field(H, W, K)
    gens = get_generators("sl2r", K)
    phi_i = np.zeros((H, W, 3))
    phi_j = np.random.randn(H, W, 3) * 0.25
    omega = compute_omega_pair(phi_i, phi_j, gens)
    omega_inv = compute_omega_pair(phi_j, phi_i, gens)

    mu_fwd, sigma_fwd = batch_apply_omega(mu, sigma, omega)
    mu_back, sigma_back = batch_apply_omega(mu_fwd, sigma_fwd, omega_inv)

    mask = np.ones((H, W))
    kl = compute_kl_gaussian_fields(mu, sigma, mu_back, sigma_back, mask)
    print(f"✅ KL(μ, Ω⁻¹Ωμ) — mean={kl.mean():.2e}, max={kl.max():.2e}")
    assert kl.max() < 1e-3, "[KL] Too large after roundtrip"

def test_determinant_close_to_one():
    H, W, K = 4, 4, 3
    gens = get_generators("sl2r", K)
    phi_i = np.random.randn(H, W, 3) * 0.1
    phi_j = np.random.randn(H, W, 3) * 0.1
    omega = compute_omega_pair(phi_i, phi_j, gens)
    dets = np.linalg.det(omega)

    print(f"✅ Det(Ω) stats — mean: {dets.mean():.4f}, min: {dets.min():.4f}, max: {dets.max():.4f}")
    assert np.allclose(dets, 1.0, atol=1e-2), "[Det] Ω not volume-preserving"

if __name__ == "__main__":
    test_identity_transport()
    test_roundtrip_transport()
    test_spd_preservation()
    test_kl_roundtrip()
    test_determinant_close_to_one()
