# -*- coding: utf-8 -*-
"""
Created on Wed Jul 16 18:18:11 2025

@author: chris and christine
"""

# bundle_morphism_utils.py
import numpy as np
from typing import Optional, Tuple, List, Dict, Any, Union
import numpy as np
from scipy.ndimage import gaussian_filter
import config
from numerical_utils import sanitize_sigma

from get_generators import RhoFunction
from generalized_math_utils import to_natural_params, from_natural_params
from scipy.linalg import expm
from collections import defaultdict

fallback_counter = defaultdict(int)

def safe_batch_apply_morphism_nat(mu, sigma, Phi, eps=1e-8, fallback_value=1e-3):
    """
    Project (mu, Sigma) through a bundle morphism Φ using **natural parameters**.
    Adds fallback if output covariance is not SPD or produces NaNs.

    Args:
        mu:    (H, W, K_src)
        sigma: (H, W, K_src, K_src)
        Phi:   (H, W, K_tgt, K_src)
        eps:   stabilizer for inversion/logs
        fallback_value: default variance to use if output is invalid

    Returns:
        mu_out:    (H, W, K_tgt)
        sigma_out: (H, W, K_tgt, K_tgt)
    """
    from numerical_utils import condition_check_and_fallback

    theta1, theta2 = to_natural_params(mu, sigma, eps)
    theta1_out = np.einsum("...ij,...j->...i", Phi, theta1)
    theta2_out = np.einsum("...ij,...jk,...lk->...il", Phi, theta2, Phi)
    theta2_out = 0.5 * (theta2_out + theta2_out.transpose(0, 1, 3, 2))  # symmetrize

    mu_out, sigma_out = from_natural_params(theta1_out, theta2_out, eps)

    # Fallback if invalid
    H, W, K = mu_out.shape
    fallback_sigma = fallback_value * np.eye(K, dtype=sigma_out.dtype)

    for i in range(H):
        for j in range(W):
            if not np.all(np.isfinite(sigma_out[i, j])) or np.linalg.cond(sigma_out[i, j]) > 1e8:
                sigma_out[i, j] = fallback_sigma
                mu_out[i, j] = 0.0  # neutral fallback mean

    return mu_out, sigma_out



def safe_batch_apply_morphism(mu, sigma, Phi, eps=1e-8, max_cond=1e6):
    """
    Apply a bundle morphism Φ: K_src → K_tgt to mean and covariance,
    with numerical fallback for ill-conditioned output.

    Args:
        mu       : (..., K_src)
        sigma    : (..., K_src, K_src)
        Phi      : (..., K_tgt, K_src)
        eps      : float, SPD stabilizer for output
        max_cond : float, condition number threshold for fallback

    Returns:
        mu_tgt    : (..., K_tgt)
        sigma_tgt : (..., K_tgt, K_tgt)
    """
    if Phi.shape[-1] != mu.shape[-1]:
        raise ValueError(
            f"[safe_batch_apply_morphism] Mismatch: Φ maps K_src={Phi.shape[-1]} → K_tgt={Phi.shape[-2]}, "
            f"but mu has shape {mu.shape}"
        )

    try:
        mu_tgt = np.einsum("...ij,...j->...i", Phi, mu)
        sigma_tgt = np.einsum("...ik,...kl,...jl->...ij", Phi, sigma, Phi)
    except Exception as e:
        raise RuntimeError(
            f"[safe_batch_apply_morphism] einsum failed:\n"
            f"mu: {mu.shape}, sigma: {sigma.shape}, Phi: {Phi.shape}\n{str(e)}"
        )

    # Symmetrize and stabilize
    sigma_tgt = 0.5 * (sigma_tgt + np.swapaxes(sigma_tgt, -1, -2))
    eye = np.eye(Phi.shape[-2], dtype=sigma.dtype)
    while eye.ndim < sigma_tgt.ndim:
        eye = eye[np.newaxis, ...]
    sigma_tgt += eps * eye

    # Check condition number and fallback
    fallback_triggered = False
    try:
        batch_cond = np.linalg.cond(sigma_tgt.reshape(-1, sigma_tgt.shape[-2], sigma_tgt.shape[-1]))
        if not np.all(np.isfinite(batch_cond)) or np.any(batch_cond > max_cond):
            fallback_triggered = True
    except Exception:
        fallback_triggered = True

    if fallback_triggered:
        fallback_val = getattr(config, "sanitize_fallback_value", 1e-3)
        K = Phi.shape[-2]
        fallback_sigma = fallback_val * np.eye(K, dtype=sigma.dtype)
        shape = sigma_tgt.shape[:-2] + fallback_sigma.shape
        sigma_tgt = np.broadcast_to(fallback_sigma, shape)

        if "fallback_counter" in globals():
            fallback_counter["safe_batch_apply_morphism"] += 1

    return mu_tgt, sigma_tgt


#======================================================================
#
#                    Initialization
#
#======================================================================

def identity_morphism(agent_i, agent_j):
    """
    Returns Φ = Id for all spatial points.
    """
    H, W, K = agent_i.mu_q_field.shape  # works for both q and p
    return np.broadcast_to(np.eye(K, dtype=np.float32), (H, W, K, K))

def get_morphism_fn(name, generators_q=None, generators_p=None):
    """
    Returns a morphism function: (agent_i, agent_j) → Φ_{ij}

    Args:
        name         : str, e.g., "identity", "gauge_covariant"
        generators_q : (3, K_q, K_q) array for belief bundle (domain)
        generators_p : (3, K_p, K_p) array for model bundle (codomain)

    Returns:
        function(agent_i, agent_j) → (H, W, K_p, K_q)
    """
    name = name.lower()

    if name == "identity":
        return identity_morphism

    elif name == "gauge_covariant":
        if generators_q is None or generators_p is None:
            raise ValueError("[get_morphism_fn] 'gauge_covariant' requires both generators_q and generators_p")
        rho_q_func = RhoFunction(generators_q)
        rho_p_func = RhoFunction(generators_p)
        return make_morphism_fn(rho_q_func, rho_p_func)

    else:
        raise ValueError(f"[get_morphism_fn] Unknown morphism type: '{name}'")


def assign_default_morphisms(agent, K_q, K_p):
    shape = agent.grid_shape
    mask  = agent.mask[..., None, None]  # (H, W, 1, 1)

    Φ       = np.zeros((*shape, K_p, K_q), dtype=np.float32).copy()
    Φ_tilde = np.zeros((*shape, K_q, K_p), dtype=np.float32).copy()


    min_dim = min(K_q, K_p)

    for i in range(min_dim):
        Φ[..., i, i]       = mask[..., 0, 0]
        Φ_tilde[..., i, i] = mask[..., 0, 0]

    agent.bundle_morphism_phi       = Φ
    agent.bundle_morphism_phi_tilde = Φ_tilde


def generate_smooth_morphism_field(
    H, W,
    K_src, K_tgt,
    sigma=config.sigma_field_smooth_range,
    low_rank=None,
    seed=None,
    normalize=False,
    mask=None,
):
    """
    Generate a smooth spatial field of K_tgt × K_src morphisms.

    Args:
        H, W       : spatial domain
        K_src      : input dimension (e.g. q)
        K_tgt      : output dimension (e.g. p)
        sigma      : Gaussian blur σ (scalar or tuple)
        low_rank   : optional int ≤ min(K_src, K_tgt) for low-rank morphism
        seed       : optional random seed
        normalize  : if True, normalize each matrix to unit Frobenius norm
        mask       : (H, W) optional mask to apply (multiply per point)

    Returns:
        morphism_field : (H, W, K_tgt, K_src)
    """
    eps = 1e-8
    rng = np.random.default_rng(seed)
    rank = low_rank if low_rank is not None else min(K_src, K_tgt)

    field = np.zeros((H, W, K_tgt, K_src), dtype=np.float32)

    for r in range(rank):
        basis = rng.standard_normal((K_tgt, K_src)).astype(np.float32)
        coeff = rng.standard_normal((H, W)).astype(np.float32)
        coeff = gaussian_filter(coeff, sigma=sigma, mode="wrap")
        field += coeff[..., None, None] * basis[None, None, :, :]

    if normalize:
        norm = np.linalg.norm(field, axis=(-2, -1), keepdims=True)
        norm_safe = np.where(norm > eps, norm, eps)
        field = field / norm_safe

    if mask is not None:
        field *= mask[..., None, None]

    return field


def initialize_morphism_pair( 
    domain_size: tuple[int, int],
    K_q: int,
    K_p: int,
    rng: np.random.Generator,
    morphism_type: str = "identity",
    mask: Optional[np.ndarray] = None,
    config_tag: str = "",
) -> tuple[np.ndarray, np.ndarray]:
    """
    Initialize bundle morphisms Φ (q→p) and Φ̃ (p→q).

    Args:
        domain_size    : (H, W)
        K_q, K_p       : belief and model fiber dims
        rng            : np.random.Generator
        morphism_type  : "identity", "smooth", "lowrank", or "gauge_covariant"
        mask           : agent support mask
        config_tag     : optional suffix to use e.g. config.morphism_sigma_tagname

    Returns:
        phi_q_to_p : Φ : B_q → B_p   (H, W, K_p, K_q)
        phi_p_to_q : Φ̃: B_p → B_q   (H, W, K_q, K_p)
    """
    H, W = domain_size

    if morphism_type == "identity":
        if K_q != K_p:
            raise ValueError(f"Cannot use identity morphism with mismatched K_q={K_q} and K_p={K_p}")
        eye = np.eye(K_q, dtype=np.float32)
        phi_q_to_p = np.broadcast_to(eye, (H, W, K_q, K_q)).copy()
        phi_p_to_q = np.broadcast_to(eye, (H, W, K_q, K_q)).copy()
        return phi_q_to_p, phi_p_to_q

    if morphism_type == "gauge_covariant":
        phi_q_to_p = np.broadcast_to(np.eye(K_p, K_q, dtype=np.float32), (H, W, K_p, K_q)).copy()
        phi_p_to_q = np.broadcast_to(np.eye(K_q, K_p, dtype=np.float32), (H, W, K_q, K_p)).copy()
        return phi_q_to_p, phi_p_to_q

    # Otherwise: generate two smooth morphism fields (for "smooth" or "lowrank")
    sigma     = getattr(config, f"morphism_sigma{config_tag}", 1.5)
    rank      = getattr(config, f"morphism_rank{config_tag}", min(K_q, K_p))
    normalize = getattr(config, f"morphism_normalize{config_tag}", True)
    seed      = rng.integers(0, 1e9)

    phi_q_to_p = generate_smooth_morphism_field(
        H, W, K_src=K_q, K_tgt=K_p,
        sigma=sigma, low_rank=rank,
        normalize=normalize, mask=mask, seed=seed
    )

    phi_p_to_q = generate_smooth_morphism_field(
        H, W, K_src=K_p, K_tgt=K_q,
        sigma=sigma, low_rank=rank,
        normalize=normalize, mask=mask, seed=seed + 1  # offset for symmetry
    )

    return phi_q_to_p, phi_p_to_q



def build_rho(phi_vec: np.ndarray, generators: dict[str, np.ndarray]) -> np.ndarray:
    """
    phi_vec : (3,) Lie algebra coefficients [θ_H, θ_E, θ_F]
    generators : dict with 'H', 'E', 'F' matrices

    returns ρ(exp(φ)) ∈ SL(2,R)^K
    """
    phi_matrix = phi_vec[0] * generators['H'] + phi_vec[1] * generators['E'] + phi_vec[2] * generators['F']
    return expm(phi_matrix)


def gauge_covariant_transform_phi(phi_field, Phi_field, rho_q_func, rho_p_func):
    """
    Apply Φ(x) ↦ ρ_p(exp(φ(x))) · Φ(x) · ρ_q(exp(φ(x)))⁻¹ for each point.

    Args:
        phi_field : (H, W, d)       — Lie algebra coords
        Phi_field : (H, W, K_p, K_q)
        rho_q_func: φ → ρ_q(exp(φ))
        rho_p_func: φ → ρ_p(exp(φ))

    Returns:
        (H, W, K_p, K_q) transformed field
    """
    H, W = phi_field.shape[:2]
    K_p, K_q = Phi_field.shape[-2:]

    out = np.zeros_like(Phi_field)

    for i in range(H):
        for j in range(W):
            phi = phi_field[i, j]
            Phi = Phi_field[i, j]

            rho_q = rho_q_func(phi)    # (K_q, K_q)
            rho_p = rho_p_func(phi)    # (K_p, K_p)

            try:
                rho_q_inv = np.linalg.inv(rho_q)
            except np.linalg.LinAlgError:
                rho_q_inv = np.eye(K_q)

            out[i, j] = rho_p @ Phi @ rho_q_inv

    return out

def gauge_covariant_transform_phi_batch(phi_field, Phi_field, rho_q_func, rho_p_func):
    """
    Vectorized version of Φ ↦ ρ_p · Φ · ρ_q⁻¹.
    Assumes rho_p_func and rho_q_func accept batched input.

    Args:
        phi_field : (H, W, d)
        Phi_field : (H, W, K_p, K_q)

    Returns:
        (H, W, K_p, K_q)
    """
    H, W = phi_field.shape[:2]
    d = phi_field.shape[-1]
    K_p, K_q = Phi_field.shape[-2:]

    phi_flat = phi_field.reshape(-1, d)
    Phi_flat = Phi_field.reshape(-1, K_p, K_q)

    rho_p = rho_p_func(phi_flat)  # (N, K_p, K_p)
    rho_q = rho_q_func(phi_flat)  # (N, K_q, K_q)

    try:
        rho_q_inv = np.linalg.inv(rho_q)  # (N, K_q, K_q)
    except np.linalg.LinAlgError:
        rho_q_inv = np.linalg.pinv(rho_q)

    # Apply: ρ_p @ Φ @ ρ_q⁻¹
    tmp = np.einsum("nij,njk->nik", rho_p, Phi_flat)
    out_flat = np.einsum("nij,njk->nik", tmp, rho_q_inv)

    return out_flat.reshape(H, W, K_p, K_q)


def make_morphism_fn(rho_q_func, rho_p_func):
    """
    Returns a function that performs the gauge-covariant transformation:
        Φ ↦ ρ_p(exp(φ)) · Φ · ρ_q(exp(φ))⁻¹
    for a given agent_j's Φ and φ, evaluated in agent_i's frame.

    Args:
        rho_q_func : function mapping φ → ρ_q(exp(φ))
        rho_p_func : function mapping φ → ρ_p(exp(φ))

    Returns:
        morphism(agent_i, agent_j) → (H, W, K_p, K_q) transformed Φ
    """
    def morphism(agent_i, agent_j):
        phi_field  = agent_j.phi            # φ_j
        Phi_field = agent_j.bundle_morphism_q_to_p

        return gauge_covariant_transform_phi(phi_field, Phi_field, rho_q_func, rho_p_func)

    return morphism

