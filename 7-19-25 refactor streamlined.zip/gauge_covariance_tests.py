import numpy as np
from bundle_morphism_utils import safe_batch_apply_morphism
from get_generators import get_generators
from generalized_omega import exp_lie_algebra_irrep
from generalized_math_utils import kl_divergence

def gauge_transform(mu, sigma, g):
    """Apply gauge transform: μ → gμ, Σ → gΣgᵀ"""
    mu_g = np.einsum("ij,...j->...i", g, mu)
    sigma_g = np.einsum("ik,...kl,jl->...ij", g, sigma, g)
    return mu_g, sigma_g

def gauge_conjugate(omega, g):
    """Ω → g Ω g⁻¹"""
    g_inv = np.linalg.inv(g)
    return np.einsum("ik,...kl,lj->...ij", g, omega, g_inv)

def validate_gauge_covariance(mu_i, sigma_i, mu_j, sigma_j, omega_ij, G, atol=1e-6):
    """
    Validate that KL(q_i ‖ Ω_ij q_j) is invariant under a global gauge transform.

    Args:
        mu_i, sigma_i: (H, W, K), (H, W, K, K) — belief field for agent i
        mu_j, sigma_j: (H, W, K), (H, W, K, K) — belief field for agent j
        omega_ij     : (H, W, K, K) — gauge transport operator Ω_ij
        G            : (3, K, K) — Lie algebra generators
        atol         : tolerance

    Returns:
        passed       : bool
        max_error    : float
    """
    H, W, K = mu_i.shape
    assert omega_ij.shape == (H, W, K, K)

    # Step 1: Compute original KL
    mu_j_t, sigma_j_t = safe_batch_apply_morphism(mu_j, sigma_j, omega_ij)
    kl_orig = kl_divergence(mu_i, sigma_i, mu_j_t, sigma_j_t)

    # Step 2: Choose a random group element g = exp(φ)
    rng = np.random.default_rng(0)
    φ = rng.normal(0, 0.1, size=3)
    g = exp_lie_algebra_irrep(φ, G)  # (K, K)

    # Step 3: Transform beliefs and Ω
    mu_i_g, sigma_i_g = gauge_transform(mu_i, sigma_i, g)
    mu_j_g, sigma_j_g = gauge_transform(mu_j, sigma_j, g)
    omega_g = gauge_conjugate(omega_ij, g)

    # Step 4: Compute transformed KL
    mu_j_g_t, sigma_j_g_t = safe_batch_apply_morphism(mu_j_g, sigma_j_g, omega_g)
    kl_transformed = kl_divergence(mu_i_g, sigma_i_g, mu_j_g_t, sigma_j_g_t)

    # Step 5: Compare
    diff = np.abs(kl_orig - kl_transformed)
    max_err = np.max(diff)
    passed = np.allclose(kl_orig, kl_transformed, atol=atol)

    if not passed:
        print(f"[FAIL] Gauge covariance violated: max ΔKL = {max_err:.2e}")
    else:
        print(f"[PASS] Gauge covariance validated: max ΔKL = {max_err:.2e}")

    return passed, max_err

if __name__ == "__main__":
    import numpy as np
    from get_generators import get_generators
    from generalized_agents import create_smooth_fields
    from bundle_morphism_utils import safe_batch_apply_morphism
    from generalized_omega import exp_lie_algebra_irrep
    from generalized_math_utils import kl_divergence

    # --- Configurable test parameters ---
    H, W = 20, 20     # Spatial size
    K = 5             # Fiber dimension
    rng = np.random.default_rng(123)
    atol = 1e-6       # Tolerance for KL invariance

    # --- Generate smooth belief fields for agent i and j ---
    mu_i, sigma_i, mu_j, sigma_j = create_smooth_fields((H, W), rng, K)
    G = get_generators("sl2r", K)

    # --- Use identity transport Ω_ij = I for simplicity ---
    Omega_ij = np.broadcast_to(np.eye(K), (H, W, K, K))

    # --- Run the validation test ---
    passed, max_err = validate_gauge_covariance(mu_i, sigma_i, mu_j, sigma_j, Omega_ij, G, atol=atol)

    if passed:
        print(f"\n✅ Gauge covariance test passed — max ΔKL = {max_err:.2e}")
    else:
        print(f"\n❌ Gauge covariance test FAILED — max ΔKL = {max_err:.2e}")
