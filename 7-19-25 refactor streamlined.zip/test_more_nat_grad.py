# -*- coding: utf-8 -*-
"""
Created on Sat Jul 19 13:48:38 2025

@author: chris and christine
"""
 
import pytest
import numpy as np
from numpy.testing import assert_array_equal, assert_allclose
from natural_gradient_utils import (
    apply_natural_gradient_batch,
    apply_lie_natural_gradient,
    compute_kl_gaussian_fields,
    compute_fisher_metric_block_diag
)
from natural_gradient_utils import kl_gradient_mu_sigma, compute_alignment_kl_gradient
import config
from generalized_agent_schema import Agent
from unittest.mock import patch
from numerical_utils import sanitize_sigma  # Add this import to resolve the NameError
from numerical_utils import is_spd_matrix



# Function to generate Q-fields (belief fields)
def generate_q_fields(H, W, K_q):
    """
    Generate Q-fields (belief fields: mu_q and sigma_q)
    Args:
        H (int): Height of the grid
        W (int): Width of the grid
        K_q (int): Dimensionality of the belief space

    Returns:
        mu_q (np.ndarray): Belief means of shape (H, W, K_q)
        sigma_q (np.ndarray): Belief covariance of shape (H, W, K_q, K_q)
    """
    mu_q = np.random.rand(H, W, K_q)  # Shape (H, W, K_q)
    sigma_q = np.random.rand(H, W, K_q, K_q)  # Shape (H, W, K_q, K_q)
    return mu_q, sigma_q

# Function to generate P-fields (model fields)
def generate_p_fields(H, W, K_p):
    """
    Generate P-fields (model fields: mu_p and sigma_p)
    Args:
        H (int): Height of the grid
        W (int): Width of the grid
        K_p (int): Dimensionality of the model space

    Returns:
        mu_p (np.ndarray): Model means of shape (H, W, K_p)
        sigma_p (np.ndarray): Model covariance of shape (H, W, K_p, K_p)
    """
    mu_p = np.random.rand(H, W, K_p)  # Shape (H, W, K_p)
    sigma_p = np.random.rand(H, W, K_p, K_p)  # Shape (H, W, K_p, K_p)
    return mu_p, sigma_p


# Modify the random_gradient mock to return grad_mu and grad_sigma separately
@pytest.fixture
def random_gradient():
    H, W = 10, 10
    K_q, K_p = 3, 5  # K_q and K_p are both 7 for this test
    
    # Generate grad_mu with the same shape as mu_q (Q-fields)
    grad_mu = np.random.rand(H, W, K_q)  # Shape (H, W, K_q)
    
    # Generate grad_sigma with the same shape as sigma_q (Q-fields)
    grad_sigma = np.random.rand(H, W, K_q, K_q)  # Shape (H, W, K_q, K_q)
    
    return grad_mu, grad_sigma  # Return grad_mu and grad_sigma as separate values

@pytest.fixture
def random_gradient_q():
    H, W = 10, 10
    K_q = 3  # Define K_q for belief fields
    
    # Generate grad_mu_q with the same shape as mu_q (Q-fields)
    grad_mu_q = np.random.rand(H, W, K_q)  # Shape (H, W, K_q)
    
    # Generate grad_sigma_q with the same shape as sigma_q (Q-fields)
    grad_sigma_q = np.random.rand(H, W, K_q, K_q)  # Shape (H, W, K_q, K_q)
    
    # Generate grad_phi_q with the same shape as phi_q (Q-fields)
    grad_phi_q = np.random.rand(H, W, K_q)  # Shape (H, W, K_q) to match mu_q (Q-fields)
    
    return grad_mu_q, grad_sigma_q, grad_phi_q  # Return gradients for Q-fields

@pytest.fixture
def random_gradient_p():
    H, W = 10, 10
    K_p = 5  # Define K_p for model fields
    
    # Generate grad_mu_p with the same shape as mu_p (P-fields)
    grad_mu_p = np.random.rand(H, W, K_p)  # Shape (H, W, K_p)
    
    # Generate grad_sigma_p with the same shape as sigma_p (P-fields)
    grad_sigma_p = np.random.rand(H, W, K_p, K_p)  # Shape (H, W, K_p, K_p)
    
    # Generate grad_phi_p with the same shape as phi_p (P-fields)
    grad_phi_p = np.random.rand(H, W, K_p)  # Shape (H, W, K_p) to match mu_p (P-fields)
    
    return grad_mu_p, grad_sigma_p, grad_phi_p  # Return gradients for P-fields


from unittest.mock import patch
import numpy as np

@patch('numerical_utils.safe_inv')
def test_safe_inv_mock(mock_safe_inv):
    H, W, K_q = 10, 10, 3  # Dimensions for belief (K_q)
    K_p = 5  # Dimensions for model (K_p)

    # Directly generate Q-fields (belief fields) and P-fields (model fields)
    mu_q, sigma_q = generate_q_fields(H, W, K_q)  # Generate belief fields (Q-fields)
    mu_p, sigma_p = generate_p_fields(H, W, K_p)  # Generate model fields (P-fields)

    # Mocking safe_inv to return identity matrices of the correct size
    mock_safe_inv.return_value = np.eye(K_q)  # For example, identity matrix of size (3, 3)

    grad_mu = np.random.rand(H, W, K_q)  # Random gradient for mu
    grad_sigma = np.random.rand(H, W, K_q, K_q)  # Random gradient for sigma

    # Apply the gradient function (which uses the mocked safe_inv)
    delta_mu, delta_sigma = apply_natural_gradient_batch(mu_q, sigma_q, grad_mu, grad_sigma)

    # Debug print the shapes of the results to confirm correct mock behavior
    print(f"[DEBUG] delta_mu shape: {delta_mu.shape}")
    print(f"[DEBUG] delta_sigma shape: {delta_sigma.shape}")

    # Ensure the function behaves as expected despite the mock
    assert np.all(np.isfinite(delta_mu)), f"NaN or Inf in delta_mu: {delta_mu}"
    assert np.all(np.isfinite(delta_sigma)), f"NaN or Inf in delta_sigma: {delta_sigma}"




@pytest.fixture
def agent_data():
    H, W, K_q = 10, 10, 3  # Dimensions for belief (K_q)
    K_p = 5  # Dimensions for model (K_p)

    # Use the field generation functions to create belief and model fields
    mu_q, sigma_q = generate_q_fields(H, W, K_q)  # Generate belief fields (Q-fields)
    mu_p, sigma_p = generate_p_fields(H, W, K_p)  # Generate model fields (P-fields)

    # Create Agent i using the Agent class
    agent_i = Agent(
        id=0,
        center=(0, 0),
        radius=1.0,
        mask=np.ones((H, W)),
        mu_q_field=mu_q,  # Belief field
        sigma_q_field=sigma_q,  # Belief covariance field
        mu_p_field=mu_p,  # Model field
        sigma_p_field=sigma_p,  # Model covariance field
        phi=np.random.rand(H, W, K_q, K_q),  # Belief field connection
        phi_model=np.random.rand(H, W, K_p, K_p),  # If necessary for model comparison
        neighbors=[{"id": 1}, {"id": 2}],
    )

    # Initialize the exp_phi, exp_neg_phi, and the morphisms for the agents
    agent_i._exp_phi = np.random.rand(H, W, K_q, K_q)  # Initialize _exp_phi
    agent_i._exp_neg_phi = np.random.rand(H, W, K_q, K_q)  # Initialize _exp_neg_phi

    # Initialize bundle morphisms
    agent_i.bundle_morphism_q_to_p = np.random.rand(K_q, K_p)  # Phi: Q -> P
    agent_i.bundle_morphism_p_to_q = np.random.rand(K_p, K_q)  # Phi_model: P -> Q

    # Agent j (including mu_p_field and sigma_p_field)
    agent_j = Agent(
        id=1,
        center=(1, 1),
        radius=1.0,
        mask=np.ones((H, W)),
        mu_q_field=np.random.rand(H, W, K_q),  # Belief field (Q)
        sigma_q_field=np.random.rand(H, W, K_q, K_q),  # Belief covariance field (Q)
        mu_p_field=np.random.rand(H, W, K_p),  # Model field (P)
        sigma_p_field=np.random.rand(H, W, K_p, K_p),  # Model covariance field (P)
        phi=np.random.rand(H, W, K_q, K_q),  # Belief field connection
        phi_model=np.random.rand(H, W, K_p, K_p),  # Model field connection
        neighbors=[{"id": 0}],
    )
    agent_j._exp_phi = np.random.rand(H, W, K_q, K_q)
    agent_j._exp_neg_phi = np.random.rand(H, W, K_q, K_q)

    # Initialize bundle morphisms for agent_j
    agent_j.bundle_morphism_q_to_p = np.random.rand(K_q, K_p)  # Phi: Q -> P
    agent_j.bundle_morphism_p_to_q = np.random.rand(K_p, K_q)  # Phi_model: P -> Q

    # Agent k (same as agent_j)
    agent_k = Agent(
        id=2,
        center=(2, 2),
        radius=1.0,
        mask=np.ones((H, W)),
        mu_q_field=np.random.rand(H, W, K_q),  # Belief field (Q)
        sigma_q_field=np.random.rand(H, W, K_q, K_q),  # Belief covariance field (Q)
        mu_p_field=np.random.rand(H, W, K_p),  # Model field (P)
        sigma_p_field=np.random.rand(H, W, K_p, K_p),  # Model covariance field (P)
        phi=np.random.rand(H, W, K_q, K_q),  # Belief field connection
        phi_model=np.random.rand(H, W, K_p, K_p),  # Model field connection
        neighbors=[{"id": 0}],
    )
    agent_k._exp_phi = np.random.rand(H, W, K_q, K_q)
    agent_k._exp_neg_phi = np.random.rand(H, W, K_q, K_q)

    # Initialize bundle morphisms for agent_k
    agent_k.bundle_morphism_q_to_p = np.random.rand(K_q, K_p)  # Phi: Q -> P
    agent_k.bundle_morphism_p_to_q = np.random.rand(K_p, K_q)  # Phi_model: P -> Q

    # Return agent_i and a list of agents for interaction
    agents = [agent_i, agent_j, agent_k]
    return agent_i, agents

def test_kl_gradient_regularization():
    H, W, K_q = 10, 10, 3  # Dimensions for belief (K_q)
    K_p = 5  # Dimensions for model (K_p)

    # Directly generate Q-fields (belief fields) and P-fields (model fields) in the test
    mu_q, sigma_q = generate_q_fields(H, W, K_q)  # Generate belief fields (Q-fields)
    mu_p, sigma_p = generate_p_fields(H, W, K_p)  # Generate model fields (P-fields)

    # Modify the sigma matrices to create instability (high condition number)
    sigma_q[:, :, 0, 0] = 1e6  # Large condition number in sigma_q (belief covariance)
    sigma_p[:, :, 0, 0] = 1e6  # Large condition number in sigma_p (model covariance)

    # Compute KL gradient with regularization
    delta_mu, delta_sigma = kl_gradient_mu_sigma(mu_q, sigma_q, mu_p, sigma_p)

    # Ensure that no NaN or Inf values are present
    assert np.all(np.isfinite(delta_mu)), f"NaN or Inf found in delta_mu after regularization: {delta_mu}"
    assert np.all(np.isfinite(delta_sigma)), f"NaN or Inf found in delta_sigma after regularization: {delta_sigma}"

    # Optional: Verify that the regularization has reduced instability by checking gradient magnitude
    assert np.all(np.abs(delta_mu) < 1e3), f"Delta_mu is too large after regularization: {delta_mu}"
    assert np.all(np.abs(delta_sigma) < 1e3), f"Delta_sigma is too large after regularization: {delta_sigma}"

def test_kl_gradient_regularization():
    H, W, K_q = 10, 10, 3  # Dimensions for belief (K_q)

    # Directly generate Q-fields (belief fields) for both mu_q and sigma_q
    mu_q, sigma_q = generate_q_fields(H, W, K_q)  # Generate belief fields (Q-fields)

    # Create a small perturbation (delta) to destabilize sigma_q
    delta_sigma = np.zeros_like(sigma_q)  # Initialize delta_sigma with the same shape as sigma_q
    delta_sigma[:, :, 0, 0] = 1e6  # Add large instability to the first element to create a high condition number

    # Add the perturbation to the original sigma_q to destabilize it
    sigma_q += delta_sigma

    # Ensure sigma_q is still 4D (H, W, K_q, K_q) after destabilization
    assert sigma_q.shape == (H, W, K_q, K_q), f"Expected sigma_q shape: {(H, W, K_q, K_q)}, got: {sigma_q.shape}"

    # Compute KL gradient with regularization (keep original shape, no reshaping)
    delta_mu, delta_sigma = kl_gradient_mu_sigma(mu_q, sigma_q, mu_q, sigma_q)

       # Ensure that no NaN or Inf values are present
    assert np.all(np.isfinite(delta_mu)), f"NaN or Inf found in delta_mu after regularization: {delta_mu}"
    assert np.all(np.isfinite(delta_sigma)), f"NaN or Inf found in delta_sigma after regularization: {delta_sigma}"

    # Optional: Verify that the regularization has reduced instability by checking gradient magnitude
    assert np.all(np.abs(delta_mu) < 1e3), f"Delta_mu is too large after regularization: {delta_mu}"
    assert np.all(np.abs(delta_sigma) < 1e3), f"Delta_sigma is too large after regularization: {delta_sigma}"



if __name__ == "__main__":
    # Run the tests when the file is executed
    pytest.main()
