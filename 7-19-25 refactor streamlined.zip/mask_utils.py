# mask_utils.py
import numpy as np
import config

def get_support_mask(mask: np.ndarray, eps: float = None) -> np.ndarray:
    """Boolean mask where agent has support (soft mask > eps)"""
    if eps is None:
        eps = config.support_cutoff_eps
    return mask > eps

def expand_mask_for_mu(mask: np.ndarray) -> np.ndarray:
    """Expands (H, W) mask to (H, W, 1) for μ fields"""
    return mask[..., None]

def expand_mask_for_sigma(mask: np.ndarray) -> np.ndarray:
    """Expands (H, W) mask to (H, W, 1, 1) for Σ fields"""
    return mask[..., None, None]

def apply_mask_mu(mu_field: np.ndarray, mask: np.ndarray) -> np.ndarray:
    """Apply support mask to μ field"""
    return mu_field * expand_mask_for_mu(mask)

def apply_mask_sigma(sigma_field: np.ndarray, mask: np.ndarray) -> np.ndarray:
    """Apply support mask to Σ field"""
    return sigma_field * expand_mask_for_sigma(mask)

def norm_over_mask(field: np.ndarray, mask: np.ndarray) -> float:
    """Compute mean norm of field over support mask."""
    norm_vals = np.linalg.norm(field, axis=-1)
    mask_vals = get_support_mask(mask)
    return np.sum(norm_vals * mask_vals) / (np.sum(mask_vals) + 1e-8)

def threshold_mask(mask: np.ndarray, eps: float = None) -> np.ndarray:
    """Alias for get_support_mask for compatibility."""
    return get_support_mask(mask, eps)

def apply_mask_phi(phi_field: np.ndarray, mask: np.ndarray) -> np.ndarray:
    """Apply support mask to φ or φ̃ fields"""
    return phi_field * expand_mask_for_mu(mask)

def get_overlap_mask(mask_i: np.ndarray, mask_j: np.ndarray, eps: float = None) -> np.ndarray:
    """Compute overlap of two support masks."""
    return get_support_mask(mask_i, eps) & get_support_mask(mask_j, eps)

def masked_norm(field: np.ndarray, mask: np.ndarray) -> float:
    """Sum of norms of a field over masked region."""
    norm_vals = np.linalg.norm(field, axis=-1)
    return np.sum(norm_vals * get_support_mask(mask))

def clip_and_mask_gradient(grad, soft_mask, clip_threshold, support_eps, return_norm=False):
    """
    Clips the norm of the gradient over support, then reapplies soft mask.

    Parameters:
        grad: ndarray (..., d) — gradient tensor
        soft_mask: ndarray (..., 1) — soft spatial mask
        clip_threshold: float — max allowed norm over support
        support_eps: float — threshold to define support region
        return_norm: bool — whether to return the norm before clipping

    Returns:
        clipped gradient, optionally with norm
    """
    support_mask = soft_mask[..., 0] > support_eps
    masked_grad = grad[support_mask]
    norm = np.linalg.norm(masked_grad)

    if norm > clip_threshold:
        scaling = clip_threshold / (norm + 1e-8)
        grad[support_mask] *= scaling

    grad *= soft_mask
    return (grad, norm) if return_norm else grad

def clip_and_mask_morphism(morphism, clip_threshold, log_file="debug_log.txt"):
    """
    Clips the norm of the morphism matrix.
    Logs shapes and gradient norms for debugging.

    Parameters:
        morphism: ndarray (..., K_p, K_q) — morphism matrix (e.g., Φ or Φ̃)
        clip_threshold: float — max allowed norm over support
        log_file: file path for debugging log output

    Returns:
        clipped morphism
    """
    # Log the shape of the morphism for debugging
    with open(log_file, "a") as f:
        f.write(f"morphism shape: {morphism.shape}\n")

    # Compute the norm of the morphism matrix over the last two dimensions (fiber dimensions)
    norm = np.linalg.norm(morphism, axis=(-2, -1))  # Norm over the last two dimensions (fiber dimensions)
    
    # Log the norm shape
    with open(log_file, "a") as f:
        f.write(f"norm shape: {norm.shape}\n")
        f.write(f"max norm before clipping: {np.max(norm)}\n")

    # Clip the norm if it exceeds the threshold
    if np.any(norm > clip_threshold):
        scaling = clip_threshold / (norm + 1e-8)  # Avoid division by zero
        
        # Broadcast the scaling to match the morphism shape (20, 20, 7, 5)
        scaling = np.broadcast_to(scaling[..., np.newaxis, np.newaxis], morphism.shape)

        # Apply scaling on the morphism tensor
        morphism *= scaling

        # Log scaling applied
        with open(log_file, "a") as f:
            f.write(f"Applied scaling to morphism\n")

    # Log the max norm after clipping
    with open(log_file, "a") as f:
        f.write(f"max norm after clipping: {np.max(np.linalg.norm(morphism, axis=(-2, -1)))}\n")

    return morphism









def generate_soft_mask(
    center: tuple[int, ...],
    radius: float,
    domain_size: tuple[int, ...]
) -> np.ndarray:
    """
    Create a smooth soft mask (Gaussian decay) on a periodic domain.
    Distances wrap around edges in each dimension.
    """
    dtype = getattr(config, 'dtype', np.float64)

    # Build per‐axis index grids via ogrid
    grids = np.ogrid[tuple(slice(0, s) for s in domain_size)]  # one array per axis

    # Accumulate squared wrap‐aware distances
    dist_sq = 0.0
    for d, size in enumerate(domain_size):
        coord = grids[d]
        # raw distance from center
        delta = np.abs(coord - center[d])
        # wrap‐around distance
        delta = np.minimum(delta, size - delta)
        dist_sq = dist_sq + delta**2

    dist = np.sqrt(dist_sq)

    # Avoid division by zero
    r = max(radius, np.finfo(float).eps)
    mask = np.exp(-(dist / r)**2).astype(dtype)
    return mask

def create_agent_mask(
    center: tuple[int, ...],
    radius: float,
    domain_size: tuple[int, ...]
) -> np.ndarray:
    """
    Generate a soft Gaussian mask and zero out values below support_cutoff_eps from config.
    """
    mask = generate_soft_mask(center, radius, domain_size)
    cutoff = getattr(config, 'support_cutoff_eps', 1e-3)
    mask[mask < cutoff] = 0.0
    return mask























