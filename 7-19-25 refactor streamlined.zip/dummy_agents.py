# -*- coding: utf-8 -*-
"""
Created on Sat Jul 19 18:10:40 2025

@author: chris and christine
"""

import pytest
import numpy as np
from numpy.testing import assert_array_equal, assert_allclose
from natural_gradient_utils import (
    apply_natural_gradient_batch,
    apply_lie_natural_gradient,
    compute_kl_gaussian_fields,
    compute_fisher_metric_block_diag
)
from natural_gradient_utils import kl_gradient_mu_sigma, compute_alignment_kl_gradient
import config
from generalized_agent_schema import Agent
from unittest.mock import patch
from numerical_utils import sanitize_sigma  # Add this import to resolve the NameError
from numerical_utils import is_spd_matrix
from bundle_update_rules import synchronous_step
from bundle_morphism_utils import safe_batch_apply_morphism, safe_batch_apply_morphism_nat
# Function to generate Q-fields (belief fields)
from get_generators import RhoFunction, get_generators



def generate_q_fields(H, W, K_q):
    """
    Generate Q-fields (belief fields: mu_q and sigma_q)
    Args:
        H (int): Height of the grid
        W (int): Width of the grid
        K_q (int): Dimensionality of the belief space

    Returns:
        mu_q (np.ndarray): Belief means of shape (H, W, K_q)
        sigma_q (np.ndarray): Belief covariance of shape (H, W, K_q, K_q)
    """
    mu_q = np.random.rand(H, W, K_q)  # Shape (H, W, K_q)
    sigma_q = np.random.rand(H, W, K_q, K_q)  # Shape (H, W, K_q, K_q)
    return mu_q, sigma_q

# Function to generate P-fields (model fields)
def generate_p_fields(H, W, K_p):
    """
    Generate P-fields (model fields: mu_p and sigma_p)
    Args:
        H (int): Height of the grid
        W (int): Width of the grid
        K_p (int): Dimensionality of the model space

    Returns:
        mu_p (np.ndarray): Model means of shape (H, W, K_p)
        sigma_p (np.ndarray): Model covariance of shape (H, W, K_p, K_p)
    """
    mu_p = np.random.rand(H, W, K_p)  # Shape (H, W, K_p)
    sigma_p = np.random.rand(H, W, K_p, K_p)  # Shape (H, W, K_p, K_p)
    return mu_p, sigma_p








@pytest.fixture
def agent_data():
    H, W, K_q = 10, 10, 7  # Dimensions for belief (K_q)
    K_p = 7  # Set K_p to 3 (ensuring it aligns with the 3 generators for sl2r)

    # Ensure K_q is odd (as required for sl2r irreps)
    if K_q % 2 == 0:
        raise ValueError(f"K_q must be odd, but got {K_q}")

    # Ensure K_p is odd (as required for sl2r irreps)
    if K_p % 2 == 0:
        raise ValueError(f"K_p must be odd, but got {K_p}")

    # Use the field generation functions to create belief and model fields
    mu_q, sigma_q = generate_q_fields(H, W, K_q)  # Generate belief fields (Q-fields)
    mu_p, sigma_p = generate_p_fields(H, W, K_p)  # Generate model fields (P-fields)

    # Initialize RhoFunction for belief and model generators
    generators_q = get_generators("sl2r", K=K_q)  # Only get the first value (the generators)
    generators_p = get_generators("sl2r", K=K_p)  # Only get the first value (the generators)

    # Check that we have 3 generators for both belief and model
    assert generators_q.shape[0] == 3, f"Expected 3 generators for belief, but got {generators_q.shape[0]}"
    assert generators_p.shape[0] == 3, f"Expected 3 generators for model, but got {generators_p.shape[0]}"

    # Create Agent i using the Agent class
    agent_i = Agent(
        id=0,
        center=(0, 0),
        radius=1.0,
        mask=np.ones((H, W)),
        mu_q_field=mu_q,  # Belief field
        sigma_q_field=sigma_q,  # Belief covariance field
        mu_p_field=mu_p,  # Model field
        sigma_p_field=sigma_p,  # Model covariance field
        phi=np.random.rand(H, W, K_q, K_q),  # Belief field connection
        phi_model=np.random.rand(H, W, K_p, K_p),  # If necessary for model comparison
        neighbors=[{"id": 1}, {"id": 2}],
    )

    # Initialize rho_q_func and rho_p_func using RhoFunction for belief and model generators
    agent_i.rho_q_func = RhoFunction(generators_q)
    agent_i.rho_p_func = RhoFunction(generators_p)

    # Initialize the exp_phi, exp_neg_phi, and the morphisms for the agents
    agent_i._exp_phi = np.random.rand(H, W, K_q, K_q)  # Initialize _exp_phi for belief
    agent_i._exp_neg_phi = np.random.rand(H, W, K_q, K_q)  # Initialize _exp_neg_phi for belief

    # Initialize _exp_phi_model for model (needed for the gradient computation)
    agent_i._exp_phi_model = np.random.rand(H, W, K_p, K_p)  # Initialize _exp_phi_model for model
    agent_i._exp_neg_phi_model = np.random.rand(H, W, K_p, K_p)  # Initialize _exp_neg_phi_model for model

    # Initialize bundle morphisms
    agent_i.bundle_morphism_q_to_p = np.random.rand(K_q, K_p)  # Phi: Q -> P
    agent_i.bundle_morphism_p_to_q = np.random.rand(K_p, K_q)  # Phi_model: P -> Q

    # Agent j (including mu_p_field and sigma_p_field)
    agent_j = Agent(
        id=1,
        center=(1, 1),
        radius=1.0,
        mask=np.ones((H, W)),
        mu_q_field=np.random.rand(H, W, K_q),  # Belief field (Q)
        sigma_q_field=np.random.rand(H, W, K_q, K_q),  # Belief covariance field (Q)
        mu_p_field=np.random.rand(H, W, K_p),  # Model field (P)
        sigma_p_field=np.random.rand(H, W, K_p, K_p),  # Model covariance field (P)
        phi=np.random.rand(H, W, K_q, K_q),  # Belief field connection
        phi_model=np.random.rand(H, W, K_p, K_p),  # Model field connection
        neighbors=[{"id": 0}],
    )

    # Initialize rho_q_func and rho_p_func for agent_j
    agent_j.rho_q_func = RhoFunction(generators_q)
    agent_j.rho_p_func = RhoFunction(generators_p)

    agent_j._exp_phi = np.random.rand(H, W, K_q, K_q)
    agent_j._exp_neg_phi = np.random.rand(H, W, K_q, K_q)

    # Initialize _exp_phi_model for agent_j
    agent_j._exp_phi_model = np.random.rand(H, W, K_p, K_p)
    agent_j._exp_neg_phi_model = np.random.rand(H, W, K_p, K_p)

    # Initialize bundle morphisms for agent_j
    agent_j.bundle_morphism_q_to_p = np.random.rand(K_q, K_p)  # Phi: Q -> P
    agent_j.bundle_morphism_p_to_q = np.random.rand(K_p, K_q)  # Phi_model: P -> Q

    # Agent k (same as agent_j)
    agent_k = Agent(
        id=2,
        center=(2, 2),
        radius=1.0,
        mask=np.ones((H, W)),
        mu_q_field=np.random.rand(H, W, K_q),  # Belief field (Q)
        sigma_q_field=np.random.rand(H, W, K_q, K_q),  # Belief covariance field (Q)
        mu_p_field=np.random.rand(H, W, K_p),  # Model field (P)
        sigma_p_field=np.random.rand(H, W, K_p, K_p),  # Model covariance field (P)
        phi=np.random.rand(H, W, K_q, K_q),  # Belief field connection
        phi_model=np.random.rand(H, W, K_p, K_p),  # Model field connection
        neighbors=[{"id": 0}],
    )

    # Initialize rho_q_func and rho_p_func for agent_k
    agent_k.rho_q_func = RhoFunction(generators_q)
    agent_k.rho_p_func = RhoFunction(generators_p)

    agent_k._exp_phi = np.random.rand(H, W, K_q, K_q)
    agent_k._exp_neg_phi = np.random.rand(H, W, K_q, K_q)

    # Initialize _exp_phi_model for agent_k
    agent_k._exp_phi_model = np.random.rand(H, W, K_p, K_p)
    agent_k._exp_neg_phi_model = np.random.rand(H, W, K_p, K_p)

    # Initialize bundle morphisms for agent_k
    agent_k.bundle_morphism_q_to_p = np.random.rand(K_q, K_p)  # Phi: Q -> P
    agent_k.bundle_morphism_p_to_q = np.random.rand(K_p, K_q)  # Phi_model: P -> Q

    # Return agent_i and a list of agents for interaction
    agents = [agent_i, agent_j, agent_k]
    return agent_i, agents
