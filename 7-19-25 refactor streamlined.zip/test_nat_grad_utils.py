# test_nat_grad_utils.py
import pytest
import numpy as np
from numpy.testing import assert_array_equal, assert_allclose
from natural_gradient_utils import (
    apply_natural_gradient_batch,
    apply_lie_natural_gradient,
    compute_kl_gaussian_fields,
    compute_fisher_metric_block_diag
)
from natural_gradient_utils import kl_gradient_mu_sigma, compute_alignment_kl_gradient
import config
from generalized_agent_schema import Agent
from unittest.mock import patch
from numerical_utils import sanitize_sigma  # Add this import to resolve the NameError




@pytest.fixture
def random_fields():
    H, W = 10, 10
    K_q, K_p = 3, 3  # K_q and K_p are set to 7 for this test
    
    # Generate mu_q and sigma_q for Q-fields (belief fields)
    mu_q = np.random.rand(H, W, K_q)  # Shape (H, W, K_q)
    sigma_q = np.random.rand(H, W, K_q, K_q)  # Shape (H, W, K_q, K_q)
    
    # Generate mu_p and sigma_p for P-fields (model fields)
    mu_p = np.random.rand(H, W, K_p)  # Shape (H, W, K_p)
    sigma_p = np.random.rand(H, W, K_p, K_p)  # Shape (H, W, K_p, K_p)
    
    return mu_q, sigma_q, mu_p, sigma_p, K_q, K_p

# Modify the random_gradient mock to return grad_mu and grad_sigma separately
@pytest.fixture
def random_gradient():
    H, W = 10, 10
    K_q, K_p =3, 3  # K_q and K_p are both 7 for this test
    
    # Generate grad_mu with the same shape as mu_q (Q-fields)
    grad_mu = np.random.rand(H, W, K_q)  # Shape (H, W, K_q)
    
    # Generate grad_sigma with the same shape as sigma_q (Q-fields)
    grad_sigma = np.random.rand(H, W, K_q, K_q)  # Shape (H, W, K_q, K_q)
    
    return grad_mu, grad_sigma  # Return grad_mu and grad_sigma as separate values

@pytest.fixture
def random_gradient_q():
    H, W = 10, 10
    K_q = 3  # Define K_q for belief fields
    
    # Generate grad_mu_q with the same shape as mu_q (Q-fields)
    grad_mu_q = np.random.rand(H, W, K_q)  # Shape (H, W, K_q)
    
    # Generate grad_sigma_q with the same shape as sigma_q (Q-fields)
    grad_sigma_q = np.random.rand(H, W, K_q, K_q)  # Shape (H, W, K_q, K_q)
    
    # Generate grad_phi_q with the same shape as phi_q (Q-fields)
    grad_phi_q = np.random.rand(H, W, K_q)  # Shape (H, W, K_q) to match mu_q (Q-fields)
    
    return grad_mu_q, grad_sigma_q, grad_phi_q  # Return gradients for Q-fields

@pytest.fixture
def random_gradient_p():
    H, W = 10,10
    K_p = 3  # Define K_p for model fields
    
    # Generate grad_mu_p with the same shape as mu_p (P-fields)
    grad_mu_p = np.random.rand(H, W, K_p)  # Shape (H, W, K_p)
    
    # Generate grad_sigma_p with the same shape as sigma_p (P-fields)
    grad_sigma_p = np.random.rand(H, W, K_p, K_p)  # Shape (H, W, K_p, K_p)
    
    # Generate grad_phi_p with the same shape as phi_p (P-fields)
    grad_phi_p = np.random.rand(H, W, K_p)  # Shape (H, W, K_p) to match mu_p (P-fields)
    
    return grad_mu_p, grad_sigma_p, grad_phi_p  # Return gradients for P-fields


@patch('numerical_utils.safe_inv')
def test_safe_inv_mock(mock_safe_inv, random_fields, random_gradient):
    # Mocking safe_inv to return a tuple (identity matrix, identity matrix for example)
    mock_safe_inv.return_value = (np.eye(3), np.eye(3))  # Adjust to match the expected return structure
    
    mu_q, sigma_q, mu_p, sigma_p, K_q, K_p = random_fields
    grad_mu, grad_sigma = random_gradient
    
    # Apply the gradient function (which uses the mocked safe_inv)
    delta_mu, delta_sigma = apply_natural_gradient_batch(mu_q, sigma_q, grad_mu, grad_sigma)
    
    # Ensure the function behaves as expected despite the mock
    assert np.all(np.isfinite(delta_mu)), f"NaN or Inf in delta_mu: {delta_mu}"
    assert np.all(np.isfinite(delta_sigma)), f"NaN or Inf in delta_sigma: {delta_sigma}"


@pytest.fixture
def agent_data():
    H, W, K_q, K_p = 10, 10, 3, 3  # Dimensions for belief (K_q) and model (K_p)

    # Create Agent i using the Agent class
    agent_i = Agent(
        id=0,
        center=(0, 0),
        radius=1.0,
        mask=np.ones((H, W)),
        mu_q_field=np.random.rand(H, W, K_q),  # Belief field
        sigma_q_field=np.random.rand(H, W, K_q, K_q),  # Belief covariance field
        mu_p_field=np.random.rand(H, W, K_p),  # Model field
        sigma_p_field=np.random.rand(H, W, K_p, K_p),  # Model covariance field
        phi=np.random.rand(H, W, K_q, K_q),
        phi_model=np.random.rand(H, W, K_p, K_p),
        neighbors=[{"id": 1}, {"id": 2}],
    )
    
    # Manually initialize _exp_phi and _exp_phi_model, and _exp_neg_phi and _exp_neg_phi_model
    agent_i._exp_phi = np.random.rand(H, W, K_q, K_q)  # Initialize _exp_phi
    agent_i._exp_neg_phi = np.random.rand(H, W, K_q, K_q)  # Initialize _exp_neg_phi
    agent_i._exp_phi_model = np.random.rand(H, W, K_p, K_p)  # Initialize _exp_phi_model
    agent_i._exp_neg_phi_model = np.random.rand(H, W, K_p, K_p)  # Initialize _exp_neg_phi_model

    # Create Agent j and k similarly, initializing _exp_phi and _exp_neg_phi for them
    agent_j = Agent(
        id=1,
        center=(1, 1),
        radius=1.0,
        mask=np.ones((H, W)),
        mu_q_field=np.random.rand(H, W, K_q),
        sigma_q_field=np.random.rand(H, W, K_q, K_q),
        mu_p_field=np.random.rand(H, W, K_p),
        sigma_p_field=np.random.rand(H, W, K_p, K_p),
        phi=np.random.rand(H, W, K_q, K_q),
        phi_model=np.random.rand(H, W, K_p, K_p),
        neighbors=[{"id": 0}],
    )
    agent_j._exp_phi = np.random.rand(H, W, K_q, K_q)
    agent_j._exp_neg_phi = np.random.rand(H, W, K_q, K_q)
    agent_j._exp_phi_model = np.random.rand(H, W, K_p, K_p)
    agent_j._exp_neg_phi_model = np.random.rand(H, W, K_p, K_p)

    agent_k = Agent(
        id=2,
        center=(2, 2),
        radius=1.0,
        mask=np.ones((H, W)),
        mu_q_field=np.random.rand(H, W, K_q),
        sigma_q_field=np.random.rand(H, W, K_q, K_q),
        mu_p_field=np.random.rand(H, W, K_p),
        sigma_p_field=np.random.rand(H, W, K_p, K_p),
        phi=np.random.rand(H, W, K_q, K_q),
        phi_model=np.random.rand(H, W, K_p, K_p),
        neighbors=[{"id": 0}],
    )
    agent_k._exp_phi = np.random.rand(H, W, K_q, K_q)
    agent_k._exp_neg_phi = np.random.rand(H, W, K_q, K_q)
    agent_k._exp_phi_model = np.random.rand(H, W, K_p, K_p)
    agent_k._exp_neg_phi_model = np.random.rand(H, W, K_p, K_p)

    # Return agent_i and a list of agents for interaction
    agents = [agent_i, agent_j, agent_k]
    return agent_i, agents

# Existing tests to be updated for consistency with K_q = K_p = 7 and general validation
def test_compute_kl_gaussian_fields(random_fields):
    mu_q, sigma_q, mu_p, sigma_p, K_q, K_p = random_fields
    
    # Mask for the test (usually you'd want to apply a meaningful mask)
    mask = np.ones_like(mu_q[..., 0])  # Just a simple mask
    
    # Sanitize covariance matrices before computing KL divergence
    sigma_q = sanitize_sigma(sigma_q)
    sigma_p = sanitize_sigma(sigma_p)
    
    # Compute KL divergence for belief space (K_q) and model space (K_p)
    kl_divergence_q = compute_kl_gaussian_fields(mu_q, sigma_q, mu_q, sigma_q, mask)
    kl_divergence_p = compute_kl_gaussian_fields(mu_p, sigma_p, mu_p, sigma_p, mask)
    
    # Ensure the KL divergence has the correct shape
    assert kl_divergence_q.shape == mu_q.shape[:-1], f"KL divergence q shape mismatch: {kl_divergence_q.shape}"
    assert kl_divergence_p.shape == mu_p.shape[:-1], f"KL divergence p shape mismatch: {kl_divergence_p.shape}"
    
    # Check for reasonable numerical values (i.e., not NaN or Inf)
    assert np.all(np.isfinite(kl_divergence_q)), "NaN or Inf in KL divergence q"
    assert np.all(np.isfinite(kl_divergence_p)), "NaN or Inf in KL divergence p"
    
    # Optional: Check that KL divergence is within a reasonable range
    assert np.all(kl_divergence_q < 1e3), f"KL divergence q is too large: {kl_divergence_q.max()}"
    assert np.all(kl_divergence_p < 1e3), f"KL divergence p is too large: {kl_divergence_p.max()}"

def test_kl_gradient_mu_sigma_with_agents(agent_data):
    agent_i, agents = agent_data  # Retrieve agent data from the fixture

    # Get the belief fields and covariances of agent_i (using mu_q_field and sigma_q_field)
    mu_i = agent_i.mu_q_field  # Access the attribute directly
    sigma_i = agent_i.sigma_q_field
    
    # Get the belief fields of the neighbor agent (first neighbor in the list)
    agent_j = agents[agent_i.neighbors[0]["id"]]  # Access neighbors using the id
    mu_j_t = agent_j.mu_q_field  # Access the attribute directly
    sigma_j_t = agent_j.sigma_q_field
    
    # Compute KL gradient between agent_i and agent_j
    delta_mu, delta_sigma = kl_gradient_mu_sigma(mu_i, sigma_i, mu_j_t, sigma_j_t)

    # Ensure that the gradients have the correct shape
    assert delta_mu.shape == mu_i.shape, f"Expected shape {mu_i.shape}, but got {delta_mu.shape}"
    assert delta_sigma.shape == sigma_i.shape, f"Expected shape {sigma_i.shape}, but got {delta_sigma.shape}"
    
    # Clip gradients to ensure they are within a reasonable range
    delta_mu = np.clip(delta_mu, -1e3, 1e3)
    delta_sigma = np.clip(delta_sigma, -1e3, 1e3)
    
    # Ensure no NaN or Inf values in the gradients
    assert np.all(np.isfinite(delta_mu)), f"NaN or Inf found in delta_mu: {delta_mu}"
    assert np.all(np.isfinite(delta_sigma)), f"NaN or Inf found in delta_sigma: {delta_sigma}"


def test_compute_alignment_kl_gradient_with_agents(random_fields, random_gradient):
    mu_q, sigma_q, mu_p, sigma_p, K_q, K_p = random_fields
    grad_mu, grad_sigma = random_gradient

    # Ensure grad_mu and grad_sigma are correctly sized to match mu_q and sigma_q
    H, W, K = mu_q.shape
    assert grad_mu.shape == (H, W, K), f"Shape mismatch: grad_mu {grad_mu.shape} vs mu_q {mu_q.shape}"
    assert grad_sigma.shape == (H, W, K, K), f"Shape mismatch: grad_sigma {grad_sigma.shape} vs sigma_q {sigma_q.shape}"

    # Apply the natural gradient batch to Q-fields
    delta_mu_q, delta_sigma_q = apply_natural_gradient_batch(mu_q, sigma_q, grad_mu, grad_sigma)

    # Check reshaped dimensions
    assert delta_mu_q.shape == mu_q.shape, f"Shape mismatch in delta_mu_q: {delta_mu_q.shape}"
    assert delta_sigma_q.shape == sigma_q.shape, f"Shape mismatch in delta_sigma_q: {delta_sigma_q.shape}"

def test_apply_natural_gradient_batch(random_fields, random_gradient_q, random_gradient_p):
    mu_q, sigma_q, mu_p, sigma_p, K_q, K_p = random_fields
    
    grad_mu_q, grad_sigma_q, grad_phi_q = random_gradient_q  # Use Q-field gradients
    grad_mu_p, grad_sigma_p, grad_phi_p = random_gradient_p  # Use P-field gradients
    
    # Ensure grad_mu_q has the same shape as mu_q (Q-field)
    assert grad_mu_q.shape == mu_q.shape, f"Shape mismatch: grad_mu_q {grad_mu_q.shape} vs mu_q {mu_q.shape}"

    # Ensure grad_mu_p has the same shape as mu_p (P-field)
    assert grad_mu_p.shape == mu_p.shape, f"Shape mismatch: grad_mu_p {grad_mu_p.shape} vs mu_p {mu_p.shape}"

    # Apply the natural gradient for both Q and P fields
    delta_mu_q, delta_sigma_q = apply_natural_gradient_batch(mu_q, sigma_q, grad_mu_q, grad_sigma_q)
    delta_mu_p, delta_sigma_p = apply_natural_gradient_batch(mu_p, sigma_p, grad_mu_p, grad_sigma_p)

    # Check the shapes for both Q and P fields
    assert delta_mu_q.shape == mu_q.shape, f"Shape mismatch in delta_mu_q: {delta_mu_q.shape}"
    assert delta_sigma_q.shape == sigma_q.shape, f"Shape mismatch in delta_sigma_q: {delta_sigma_q.shape}"
    assert delta_mu_p.shape == mu_p.shape, f"Shape mismatch in delta_mu_p: {delta_mu_p.shape}"
    assert delta_sigma_p.shape == sigma_p.shape, f"Shape mismatch in delta_sigma_p: {delta_sigma_p.shape}"

    # Ensure no NaN or Inf values
    assert np.all(np.isfinite(delta_mu_q)), "NaN or Inf in delta_mu_q"
    assert np.all(np.isfinite(delta_sigma_q)), "NaN or Inf in delta_sigma_q"
    assert np.all(np.isfinite(delta_mu_p)), "NaN or Inf in delta_mu_p"
    assert np.all(np.isfinite(delta_sigma_p)), "NaN or Inf in delta_sigma_p"

    # Check magnitude (for stability)
    assert np.all(np.abs(delta_mu_q) < 1e3), "delta_mu_q is too large"
    assert np.all(np.abs(delta_sigma_q) < 1e3), "delta_sigma_q is too large"
    assert np.all(np.abs(delta_mu_p) < 1e3), "delta_mu_p is too large"
    assert np.all(np.abs(delta_sigma_p) < 1e3), "delta_sigma_p is too large"



def test_apply_lie_natural_gradient(random_fields, random_gradient_q, random_gradient_p):
    mu_q, sigma_q, mu_p, sigma_p, K_q, K_p = random_fields
    
    grad_mu_q, grad_sigma_q, grad_phi_q = random_gradient_q  # Use Q-field gradients
    grad_mu_p, grad_sigma_p, grad_phi_p = random_gradient_p  # Use P-field gradients
    
    # Ensure grad_phi_q has the same shape as mu_q (Q-field)
    assert grad_phi_q.shape == mu_q.shape, f"Shape mismatch: grad_phi_q {grad_phi_q.shape} vs mu_q {mu_q.shape}"

    # Ensure grad_phi_p has the same shape as mu_p (P-field)
    assert grad_phi_p.shape == mu_p.shape, f"Shape mismatch: grad_phi_p {grad_phi_p.shape} vs mu_p {mu_p.shape}"

    # Apply the Lie natural gradient for both Q and P fields
    updated_phi_q = apply_lie_natural_gradient(mu_q, grad_phi_q)
    updated_phi_p = apply_lie_natural_gradient(mu_p, grad_phi_p)

    # Check the shapes for both Q and P fields
    assert updated_phi_q.shape == mu_q.shape, f"Shape mismatch in updated_phi_q: {updated_phi_q.shape}"
    assert updated_phi_p.shape == mu_p.shape, f"Shape mismatch in updated_phi_p: {updated_phi_p.shape}"

    # Ensure no NaN or Inf values
    assert np.all(np.isfinite(updated_phi_q)), "NaN or Inf in updated_phi_q"
    assert np.all(np.isfinite(updated_phi_p)), "NaN or Inf in updated_phi_p"

    # Check magnitude
    assert np.all(np.abs(updated_phi_q) < 1e3), "Updated phi_q is too large"
    assert np.all(np.abs(updated_phi_p) < 1e3), "Updated phi_p is too large"


from numerical_utils import is_spd_matrix


    


if __name__ == "__main__":
    # Run the tests when the file is executed
    pytest.main()

