# -*- coding: utf-8 -*-
"""
Created on Thu Jul 17 20:06:34 2025

@author: chris and christine
"""

import os
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from generalized_io_utils import load_all_checkpoints  # replace with your loading utility
import config

sns.set(style="whitegrid")

def get_global_morphism_bounds(data):
    min_phi, max_phi = np.inf, -np.inf
    min_phi_tilde, max_phi_tilde = np.inf, -np.inf

    for step in data:
        for agent in data[step]:
            Φ = agent.bundle_morphism_q_to_p
            Φ̃ = agent.bundle_morphism_p_to_q

            Φ_avg = np.mean(Φ, axis=(0, 1))
            Φ̃_avg = np.mean(Φ̃, axis=(0, 1))

            min_phi = min(min_phi, Φ_avg.min())
            max_phi = max(max_phi, Φ_avg.max())

            min_phi_tilde = min(min_phi_tilde, Φ̃_avg.min())
            max_phi_tilde = max(max_phi_tilde, Φ̃_avg.max())

    return (min_phi, max_phi), (min_phi_tilde, max_phi_tilde)


def visualize_morphisms_static(agents, save_dir="Morphism_Visualizations", step=0,
                                phi_bounds=None, phi_tilde_bounds=None):
    os.makedirs(save_dir, exist_ok=True)

    for i, agent in enumerate(agents):
        fig, axes = plt.subplots(1, 2, figsize=(10, 4))

        Φ = agent.bundle_morphism_q_to_p
        Φ̃ = agent.bundle_morphism_p_to_q

        Φ_avg = np.mean(Φ, axis=(0, 1))
        Φ̃_avg = np.mean(Φ̃, axis=(0, 1))

        sns.heatmap(Φ_avg, ax=axes[0], cmap="coolwarm", center=0, cbar=True,
                    vmin=phi_bounds[0], vmax=phi_bounds[1])
        axes[0].set_title(f"Φ [Agent {i}] (shape {Φ_avg.shape})")

        sns.heatmap(Φ̃_avg, ax=axes[1], cmap="coolwarm", center=0, cbar=True,
                    vmin=phi_tilde_bounds[0], vmax=phi_tilde_bounds[1])
        axes[1].set_title(f"Φ̃ [Agent {i}] (shape {Φ̃_avg.shape})")

        fig.suptitle(f"Bundle Morphisms — Agent {i} — Step {step}")
        fig.tight_layout()
        fig.savefig(f"{save_dir}/agent_{i:02d}_step_{step:04d}.png")
        plt.close(fig)


import imageio
from io import BytesIO

def visualize_morphisms_gif(data, save_dir="Morphism_Visualizations"):
    os.makedirs(save_dir, exist_ok=True)
    steps = sorted(data.keys())
    phi_bounds, phi_tilde_bounds = get_global_morphism_bounds(data)

    num_agents = len(data[steps[0]])
    gif_writers = []

    for agent_idx in range(num_agents):
        gif_writers.append({
            "Φ": [],
            "Φ̃": []
        })

    # Collect frames per agent
    for step in steps:
        agents = data[step]
        for i, agent in enumerate(agents):
            fig, axes = plt.subplots(1, 2, figsize=(10, 4))
            Φ = np.mean(agent.bundle_morphism_q_to_p, axis=(0, 1))
            Φ̃ = np.mean(agent.bundle_morphism_p_to_q, axis=(0, 1))

            sns.heatmap(Φ, ax=axes[0], cmap="coolwarm", center=0,
                        vmin=phi_bounds[0], vmax=phi_bounds[1], cbar=False)
            axes[0].set_title("Φ")

            sns.heatmap(Φ̃, ax=axes[1], cmap="coolwarm", center=0,
                        vmin=phi_tilde_bounds[0], vmax=phi_tilde_bounds[1], cbar=False)
            axes[1].set_title("Φ̃")

            fig.suptitle(f"Agent {i} — Step {step}")
            fig.tight_layout()

                        # Save Φ frame
            buf_phi = BytesIO()
            fig_phi, ax_phi = plt.subplots()
            sns.heatmap(Φ, ax=ax_phi, cmap="coolwarm", center=0,
                        vmin=phi_bounds[0], vmax=phi_bounds[1], cbar=False)
            ax_phi.set_title(f"Φ — Agent {i} — Step {step}")
            fig_phi.tight_layout()
            fig_phi.savefig(buf_phi, format="png")
            buf_phi.seek(0)
            gif_writers[i]["Φ"].append(imageio.v2.imread(buf_phi))
            buf_phi.close()
            plt.close(fig_phi)

            # Save Φ̃ frame
            buf_phit = BytesIO()
            fig_phit, ax_phit = plt.subplots()
            sns.heatmap(Φ̃, ax=ax_phit, cmap="coolwarm", center=0,
                        vmin=phi_tilde_bounds[0], vmax=phi_tilde_bounds[1], cbar=False)
            ax_phit.set_title(f"Φ̃ — Agent {i} — Step {step}")
            fig_phit.tight_layout()
            fig_phit.savefig(buf_phit, format="png")
            buf_phit.seek(0)
            gif_writers[i]["Φ̃"].append(imageio.v2.imread(buf_phit))
            buf_phit.close()
            plt.close(fig_phit)


    # Save GIFs per agent
    for i, frames in enumerate(gif_writers):
        imageio.mimsave(f"{save_dir}/agent_{i:02d}_phi.gif", frames["Φ"], duration=0.5)
        imageio.mimsave(f"{save_dir}/agent_{i:02d}_phi_tilde.gif", frames["Φ̃"], duration=0.5)


def visualize_over_time(folder="checkpoints"):
    data = load_all_checkpoints(folder)
    visualize_morphisms_gif(data)


if __name__ == "__main__":
    visualize_over_time("checkpoints")

