# -*- coding: utf-8 -*-
"""
Created on Sun Jul 13 18:54:27 2025

@author: chris and christine
"""

# === meta_agent_plots.py ===
# Visualization utilities for meta-agent condensation and clustering

import numpy as np
import matplotlib.pyplot as plt
from pathlib import Path
import config

from generalized_io_utils import (
    save_meta_agents,
    load_meta_agents,
    save_meta_labels,
    load_meta_data,
    save_generic_alignment_data,
    load_final_step,
)
from generalized_diagnostics_metrics import compute_pairwise_kl_belief, compute_pairwise_kl_model



def plot_generic_alignment_network(
    kl_matrix: np.ndarray,
    cluster_labels: np.ndarray,
    threshold: float,
    outpath: str = "alignment_output/alignment_network.png",
    title: str = "Epistemic Alignment Network",
    node_size: int = 500,
    show_labels: bool = True
):
    """
    Visualize agent alignment as a network.
    Edges connect agents with KL < threshold.
    Nodes are colored by cluster_labels.
    """

    import numpy as np
    import matplotlib.pyplot as plt
    import networkx as nx
    from pathlib import Path

    N = kl_matrix.shape[0]
    G = nx.Graph()

    # 1) Add nodes with cluster labels
    for i in range(N):
        G.add_node(i, cluster=cluster_labels[i])

    # 2) Add edges for D_KL(i,j) < threshold
    for i in range(N):
        for j in range(i + 1, N):
            d = kl_matrix[i, j]
            if np.isfinite(d) and d < threshold:
                G.add_edge(i, j, weight=np.exp(-d))  # similarity weight

    # 3) Node positions and colors
    pos = nx.spring_layout(G, seed=42)  # deterministic layout
    unique_labels = sorted(set(cluster_labels))
    color_map = {label: plt.cm.tab10(i % 10) for i, label in enumerate(unique_labels)}
    node_colors = [color_map.get(cluster_labels[i], "gray") for i in range(N)]

    # 4) Plot
    plt.figure(figsize=(8, 6))
    nx.draw_networkx_nodes(
        G, pos,
        node_color=node_colors,
        node_size=node_size,
        edgecolors="black"
    )
    nx.draw_networkx_edges(G, pos, alpha=0.5)

    if show_labels:
        nx.draw_networkx_labels(G, pos, font_size=10, font_color="white")

    plt.title(f"{title} (ε = {threshold:.3f})")
    plt.axis("off")

    # 5) Save
    Path(outpath).parent.mkdir(parents=True, exist_ok=True)
    plt.savefig(outpath, dpi=150)
    plt.close()


def plot_matrix(kl_matrix, labels=None, outdir="alignment_output", fname="alignment_matrix.png",
                label="D_KL(q_i || Ω q_j)", title="Pairwise Alignment Matrix", cmap="viridis"):
    Path(outdir).mkdir(parents=True, exist_ok=True)
    N = kl_matrix.shape[0]

    plt.figure(figsize=(8, 6))
    im = plt.imshow(kl_matrix, cmap=cmap, interpolation="nearest")
    cbar = plt.colorbar(im)
    cbar.set_label(label)

    plt.title(title)
    plt.xlabel("Agent j")
    plt.ylabel("Agent i")

    if labels is not None and len(labels) == N:
        ticks = np.arange(N)
        plt.xticks(ticks)
        plt.yticks(ticks)
        ax = plt.gca()
        for axis, tick_labels in zip([ax.xaxis, ax.yaxis], [ax.get_xticklabels(), ax.get_yticklabels()]):
            for k, lbl in enumerate(tick_labels):
                color = f"C{labels[k] % 10}" if labels[k] >= 0 else "gray"
                lbl.set_color(color)

    savepath = Path(outdir) / fname
    plt.tight_layout()
    plt.savefig(savepath, dpi=150)
    plt.close()
    print(f"[\u2713] Saved matrix → {savepath}")


def plot_cluster_order_parameters(cluster_R, outpath=None):
    labs = sorted(cluster_R.keys())
    R_vals = [cluster_R[l][0] for l in labs]
    sigma_vals = [cluster_R[l][1] for l in labs]

    fig, ax = plt.subplots(figsize=(6, 4))
    bars = ax.bar([str(l) for l in labs], R_vals, color="tab:blue")
    ax.set_xlabel("Cluster")
    ax.set_ylabel(r"$R_C$")
    ax.set_title("Local Order Parameter per Meta-Agent")

    for bar, σ in zip(bars, sigma_vals):
        ax.text(bar.get_x() + bar.get_width() / 2, bar.get_height(), f"σ={σ:.1e}",
                ha='center', va='bottom', fontsize=8)

    plt.tight_layout()
    if outpath:
        Path(outpath).parent.mkdir(parents=True, exist_ok=True)
        fig.savefig(outpath, dpi=150)
    plt.close()


def plot_intra_kl_distribution(cluster_stats, outpath, show_fliers=False):
    labels, data = [], []
    for lab in sorted(cluster_stats):
        vals = cluster_stats[lab]['intra_vals']
        if vals.size:
            labels.append(str(lab))
            data.append(vals)

    if not data:
        print("[!] No intra-cluster KL values to plot.")
        return

    fig, ax = plt.subplots(figsize=(6, 4))
    ax.boxplot(data, vert=True, showfliers=show_fliers)
    ax.set_xticklabels(labels)
    ax.set_ylabel("Pointwise D_KL")
    ax.set_title("Intra-cluster KL Distributions")
    ax.grid(True, linestyle='--', alpha=0.4)

    fig.tight_layout()
    fig.savefig(outpath, dpi=150)
    plt.close(fig)


def plot_inter_vs_intra(cluster_stats, outpath=None):
    labels = sorted(cluster_stats)
    intra = [cluster_stats[l]['intra_mean'] for l in labels]
    extra = [cluster_stats[l]['extra_mean'] for l in labels]
    x = np.arange(len(labels))

    fig, ax = plt.subplots(figsize=(6, 4))
    width = 0.35
    ax.bar(x - width/2, intra, width=width, label='Intra-cluster KL')
    ax.bar(x + width/2, extra, width=width, label='Extra-cluster KL')

    ax.set_xticks(x)
    ax.set_xticklabels([str(l) for l in labels])
    ax.set_ylabel('Mean D_KL')
    ax.set_title('Mean KL Divergence: Intra vs Extra per Cluster')
    ax.legend()
    ax.grid(True, linestyle='--', alpha=0.4)

    fig.tight_layout()
    if outpath:
        Path(outpath).parent.mkdir(parents=True, exist_ok=True)
        fig.savefig(outpath, dpi=150)
    plt.close(fig)


def plot_spatial_cluster_map(agents, labels, outpath=None):
    from matplotlib import cm
    cmap = cm.get_cmap('tab10')
    fig, ax = plt.subplots(figsize=(5, 5))

    for i, ag in enumerate(agents):
        lab = labels[i]
        if lab < 0:
            continue
        mask_bool = ag.mask > getattr(config, "support_cutoff_eps", 0.0)
        color = cmap(lab % cmap.N)
        ax.contour(mask_bool, levels=[0.5], colors=[color], linewidths=1)
        if hasattr(ag, "center") and ag.center is not None:
            cx, cy = ag.center
            ax.text(cy, cx, str(i), color=color, ha='center', va='center', fontsize=7)

    ax.set_title('Spatial Cluster Map')
    ax.axis('off')
    fig.tight_layout()

    if outpath:
        Path(outpath).parent.mkdir(parents=True, exist_ok=True)
        fig.savefig(outpath, dpi=150, bbox_inches='tight')
        print(f"[\u2713] Saved cluster map → {outpath}")
    plt.close(fig)


def plot_curvature_heatmap(agents, labels, generators, outpath=None):
    from generalized_omega import compute_field_strength

    if not agents:
        print("[WARN] Empty agent list. Aborting curvature heatmap.")
        return

    grid_shape = agents[0].phi.shape[:2]
    curvature_sum = np.zeros(grid_shape, dtype=float)

    for i, ag in enumerate(agents):
        if labels[i] < 0:
            continue
        try:
            F_dict = compute_field_strength(ag.phi, generators)
            F_vals = list(F_dict.values())
            if all(F.ndim == 4 for F in F_vals):
                norm_per_dir = [np.linalg.norm(F, axis=(-2, -1)) for F in F_vals]
                norm_F = np.sum(norm_per_dir, axis=0)
            else:
                raise ValueError(f"Unexpected F shapes {[F.shape for F in F_vals]}")
            curvature_sum += norm_F
        except Exception as e:
            print(f"[!] Agent {i} curvature error: {e}")

    fig, ax = plt.subplots(figsize=(5, 5))
    im = ax.imshow(curvature_sum, origin='lower', cmap='plasma')
    ax.set_title('Curvature Norm Heatmap (‖F‖)')
    ax.axis('off')
    for i, ag in enumerate(agents):
        if labels[i] < 0:
            continue
        ax.contour(ag.mask > config.support_cutoff_eps, levels=[0.5], colors='white', linewidths=0.5)

    if curvature_sum.max() > curvature_sum.min():
        fig.colorbar(im, ax=ax, label='‖F‖')

    fig.tight_layout()
    if outpath:
        Path(outpath).parent.mkdir(parents=True, exist_ok=True)
        fig.savefig(outpath, dpi=150, bbox_inches='tight')
        print(f"[\u2713] Saved curvature heatmap → {outpath}")
    plt.close(fig)
    
def plot_support_phi_summary(
    agents,
    per_df,
    phi_attr="phi",
    kl_col="kl_align",
    color="red",
    phi_title="Φ Norms",
    kl_title="Alignment per Agent",
    text="No per-agent metrics"
):
    """
    Plot:
    1. Agent support masks
    2. Spatial heatmap of ‖φ‖ or ‖φ̃‖ over domain
    3. Per-agent bar chart of final KL values

    Args:
        agents    : list of Agent objects
        per_df    : DataFrame with per-agent metrics
        phi_attr  : "phi" or "phi_model"
        kl_col    : Column name in per_df for alignment KL
        color     : Bar color for panel 3
        phi_title : Title for φ panel
        kl_title  : Title for alignment panel
        text      : Message if per_df is missing
    """
    import matplotlib.pyplot as plt
    import numpy as np
    import config  # Ensure this resolves properly in your environment

    fig, axes = plt.subplots(1, 3, figsize=(18, 6))

    # ───── Panel 1: Agent support masks with indices ─────
    ax0 = axes[0]
    for idx, agent in enumerate(agents):
        mask = agent.mask
        ax0.contour(mask, levels=[getattr(config, "support_cutoff_eps", 1e-3)],
                    colors='black', linewidths=1)
        cx, cy = agent.center
        ax0.text(cy, cx, str(idx), color=color,
                 ha='center', va='center', fontsize=9, weight='bold')
    ax0.set_title("Agent Support Contours")
    ax0.axis('off')

    # ───── Panel 2: Φ or Φ̃ Norm Spatial Sum ─────
    ax1 = axes[1]
    domain_shape = getattr(config, "domain_size", agents[0].phi.shape[:2])
    combined = np.zeros(domain_shape, dtype=float)
    for agent in agents:
        phi = getattr(agent, phi_attr)  # (H, W, d)
        combined += np.linalg.norm(phi, axis=-1)
    im = ax1.imshow(combined, origin='lower', cmap='viridis')
    ax1.set_title(f"Sum of {phi_title}")
    ax1.axis('off')
    fig.colorbar(im, ax=ax1, fraction=0.046, pad=0.04)

    # ───── Panel 3: Per-agent KL bar chart ─────
    ax2 = axes[2]
    if per_df is not None and kl_col in per_df.columns:
        last_vals = per_df.groupby('agent')[kl_col].last()
        ax2.bar(last_vals.index, last_vals.values, color=color)
        ax2.set_xlabel("Agent Index")
        ax2.set_ylabel(kl_col)
        ax2.set_title(kl_title)
    else:
        ax2.text(0.5, 0.5, text, ha='center', va='center', fontsize=10)
        ax2.set_title(kl_title)
        ax2.axis('off')

    plt.tight_layout()
    plt.show()


def plot_pairwise_pointwise_heatmap(
    agents, generators, params,
    i: int, j: int,
    mode: str,
    outdir: str = "alignment_output"
):
    """
    Compute and plot the per-point KL divergence heatmap between agents i and j.
    
    Args:
        agents     : list of Agent objects
        generators : Lie algebra basis
        params     : dict with simulation params (must include 'overlap_eps')
        i, j       : agent indices
        mode       : "belief" or "model"
        outdir     : output root directory
    """
    import matplotlib.pyplot as plt
    import numpy as np
    from pathlib import Path

    # Select KL function
    if mode == "belief":
        fn = compute_pairwise_kl_belief
        subdir = "belief_pointwise"
    elif mode == "model":
        fn = compute_pairwise_kl_model
        subdir = "model_pointwise"
    else:
        raise ValueError(f"Invalid mode: {mode}. Must be 'belief' or 'model'.")

    kl_mat, pw_dict = fn(agents, generators, params, return_pointwise=True)

    if (i, j) not in pw_dict:
        if len(pw_dict) == 0:
            raise RuntimeError("No overlapping agent pairs found for pointwise KL.")
        alt = next(iter(pw_dict))
        print(f"[WARN] No overlap for ({i}, {j}); using fallback pair {alt}")
        i, j = alt
        pw = pw_dict[alt]
    else:
        pw = pw_dict[(i, j)]

    # Build full heatmap
    mask_i = agents[i].mask > params["overlap_eps"]
    mask_j = agents[j].mask > params["overlap_eps"]
    heat = np.zeros_like(mask_i, dtype=float)
    heat[mask_i & mask_j] = pw

    # Plot
    fig, ax = plt.subplots(figsize=(5, 5))
    im = ax.imshow(heat, origin='lower', cmap='magma')
    fig.colorbar(im, ax=ax, label=f"Pointwise D_KL ({mode})")
    ax.set_title(f"{mode.capitalize()} Pointwise KL: agents {i} ↔ {j}")
    ax.axis('off')

    # Save
    outpath = Path(outdir) / subdir
    outpath.mkdir(parents=True, exist_ok=True)
    fpath = outpath / f"pointwise_{mode}_{i}_{j}.png"
    fig.savefig(fpath, dpi=150)
    plt.close(fig)

