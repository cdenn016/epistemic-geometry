# -*- coding: utf-8 -*-
"""
Created on Thu Jul 24 17:54:26 2025

@author: chris and christine
"""
from scipy.ndimage import gaussian_filter
from scipy.ndimage import distance_transform_edt
import config
import scipy
import numpy as np
from mask_utils import create_agent_mask
from agent_distributions import generate_mu_sigma_fields , generate_eta1_eta2_fields, rotate_eta_fields_via_phi_safe

from generalized_agent_schema import Agent

from bundle_morphism_utils import initialize_morphism_pair

from get_generators import get_generators, build_rho_so3, build_rho_from_generators, RhoFromGenerators
from numerical_utils import sanitize_sigma
from mask_utils import create_agent_mask
from numerical_utils import safe_inv, sanitize_eta2, soft_clip_phi_norm
import config
from numpy.random import default_rng


def initialize_agents(
    seed: int,
    domain_size: tuple[int, ...],
    N: int,
    K_q: int,
    K_p: int,
    lie_algebra_dim: int,
    visualize: bool = False,
    fixed_location: bool = True,
    params=None,
) -> list:
    from bundle_morphism_utils import generate_smooth_morphism_field, gauge_covariant_transform_phi
    from numerical_utils import sanitize_sigma  # ← needed for post-noise fix

    rng = default_rng(seed)
    dtype = getattr(config, "dtype", np.float32)
    cfg = {k: getattr(config, k) for k in dir(config) if not k.startswith("__")}

    phi_init         = cfg["phi_init"]
    phi_model_offset = cfg.get("phi_model_offset", 0.1)
    max_neighbors    = cfg.get("max_neighbors", 8)
    overlap_eps      = cfg.get("overlap_eps", 1e-3)
    diagonal_sigma   = cfg.get("diagonal_eta2_init", True)

    group_name = cfg.get("group_name", "so3")
    G_q = get_generators(group_name, K_q)
    G_p = get_generators(group_name, K_p)

    fixed_center = tuple(s // 2 for s in domain_size) if fixed_location else None
    agents = []

    use_global_belief = cfg.get("use_global_belief_template", False)
    use_global_model  = cfg.get("use_global_model_template", False)

    if use_global_belief:
        global_mu_q, global_sigma_q = generate_mu_sigma_fields(
            domain_size=domain_size, rng=rng, K=K_q,
            mu_range=config.q_mu_range, sigma_range=config.q_sigma_range,
            mask=None, sigma_outside_val=cfg.get("sigma_outside_val", 1.0),
            dtype=dtype, smooth_sigma=cfg.get("init_smooth_sigma", 2.0),
            diagonal_sigma=diagonal_sigma,
        )

    if use_global_model:
        global_mu_p, global_sigma_p = generate_mu_sigma_fields(
            domain_size=domain_size, rng=rng, K=K_p,
            mu_range=config.p_mu_range, sigma_range=config.p_sigma_range,
            mask=None, sigma_outside_val=cfg.get("sigma_outside_val", 1.0),
            dtype=dtype, smooth_sigma=cfg.get("init_smooth_sigma", 2.0),
            diagonal_sigma=diagonal_sigma,
        )

    for n in range(N):
        center, radius, mask, mask_bool = create_agent_mask_and_center(
            domain_size, rng,
            radius_range=cfg.get("agent_radius_range", (5, 10)),
            fixed_center=fixed_center
        )

        if use_global_belief:
            mu_q = global_mu_q * mask[..., None]
            sigma_q = global_sigma_q * mask[..., None, None]
            mu_q += rng.normal(scale=cfg.get("belief_noise_scale_mu", 0.01), size=mu_q.shape)
            sigma_q += rng.normal(scale=cfg.get("belief_noise_scale_sigma", 0.01), size=sigma_q.shape)
            sigma_q = sanitize_sigma(sigma_q, eps=1e-6)
        else:
            mu_q, sigma_q = generate_mu_sigma_fields(
                domain_size=domain_size, rng=rng, K=K_q,
                mu_range=config.q_mu_range, sigma_range=config.q_sigma_range,
                mask=mask, sigma_outside_val=cfg.get("sigma_outside_val", 1.0),
                dtype=dtype, smooth_sigma=cfg.get("init_smooth_sigma", 2.0),
                diagonal_sigma=diagonal_sigma,
            )

        if use_global_model:
            mu_p = global_mu_p * mask[..., None]
            sigma_p = global_sigma_p * mask[..., None, None]
            mu_p += rng.normal(scale=cfg.get("model_noise_scale_mu", 0.01), size=mu_p.shape)
            sigma_p += rng.normal(scale=cfg.get("model_noise_scale_sigma", 0.01), size=sigma_p.shape)
            sigma_p = sanitize_sigma(sigma_p, eps=1e-6)
        else:
            mu_p, sigma_p = generate_mu_sigma_fields(
                domain_size=domain_size, rng=rng, K=K_p,
                mu_range=config.p_mu_range, sigma_range=config.p_sigma_range,
                mask=mask, sigma_outside_val=cfg.get("sigma_outside_val", 1.0),
                dtype=dtype, smooth_sigma=cfg.get("init_smooth_sigma", 2.0),
                diagonal_sigma=diagonal_sigma,
            )

        phi, phi_model = initialize_phi_pair(domain_size, lie_algebra_dim, rng, phi_init, phi_model_offset, mask)
        phi       = soft_clip_phi_norm(phi, max_norm=np.pi)
        phi_model = soft_clip_phi_norm(phi_model, max_norm=np.pi)

        agent = construct_agent_object(
            agent_id=n,
            center=center,
            radius=radius,
            mask=mask,
            mu_q=mu_q, sigma_q=sigma_q,
            mu_p=mu_p, sigma_p=sigma_p,
            phi=phi, phi_model=phi_model,
            dtype=dtype
        )

        agent.generators_q = G_q
        agent.generators_p = G_p

        # Morphism initialization
        morphism_seed = rng.integers(0, 1e9)
        sigma = cfg.get("morphism_sigma", 1.5)
        rank  = cfg.get("morphism_rank", min(K_q, K_p))

        Phi_0 = generate_smooth_morphism_field(
            *domain_size, K_src=K_q, K_tgt=K_p,
            sigma=sigma, low_rank=rank, mask=mask, seed=morphism_seed
        )

        Phi_tilde_0 = np.swapaxes(Phi_0, -1, -2)  # ⬅ safe only if G_p = G_q or morphisms are square
        # WARNING: If K_q ≠ K_p, Φ̃ ≠ Φᵀ in general. Make sure gauge_covariant_transform handles rectangular case.

        agent.Phi_0        = Phi_0
        agent.Phi_tilde_0  = Phi_tilde_0

        agent.bundle_morphism_q_to_p = gauge_covariant_transform_phi(
            phi_model, phi, Phi_0, G_q=G_q, G_p=G_p
        )
        agent.bundle_morphism_p_to_q = gauge_covariant_transform_phi(
            phi, phi_model, Phi_tilde_0, G_q=G_p, G_p=G_q
        )

        initialize_agent_gradients(agent, config)
        agents.append(agent)

    assign_neighbors_vectorized(agents, overlap_eps=overlap_eps, max_neighbors=max_neighbors)
    return agents


def construct_agent_object(
    agent_id,
    center,
    radius,
    mask,
    mu_q, sigma_q,
    mu_p, sigma_p,
    phi, phi_model,
    dtype=np.float32
) -> Agent:
    """
    Build an Agent object from explicit (μ, Σ) parameters.

    Args:
        agent_id   : int
        center     : (int, int)
        radius     : float
        mask       : (H, W)
        mu_q       : (H, W, K_q)
        sigma_q    : (H, W, K_q, K_q)
        mu_p       : (H, W, K_p)
        sigma_p    : (H, W, K_p, K_p)
        phi, phi_model : (..., d) gauge fields
        dtype      : float32/float64

    Returns:
        Agent
    """
    return Agent(
        id=agent_id,
        center=center,
        radius=radius,
        mask=mask.astype(dtype),

        mu_q_field=mu_q.astype(dtype),
        sigma_q_field=sigma_q.astype(dtype),
        mu_p_field=mu_p.astype(dtype),
        sigma_p_field=sigma_p.astype(dtype),

        phi=phi.astype(dtype),
        phi_model=phi_model.astype(dtype),

        neighbors=[]
    )


def soft_clip_mu(mu, mu_clip=3.0):
    """
    Softly compresses μ to avoid values far from 0,
    without hard clipping (preserves gradients).

    Returns:
        μ' = μ / (1 + |μ| / μ_clip)
    """
    return mu / (1 + np.abs(mu) / mu_clip)



def initialize_phi_field(
    domain_size: tuple[int, ...],
    lie_algebra_dim: int,
    rng: np.random.Generator,
    init_scale: float,
    mask: np.ndarray,
    smooth_sigma: float = None
) -> np.ndarray:
    """
    Initialize and smooth a φ field with Gaussian noise and apply mask.
    """
    dtype = getattr(config, 'dtype', mask.dtype)
    sigma = smooth_sigma or getattr(config, 'phi_init_smooth_sigma', 0.5)

    phi_raw = rng.normal(scale=init_scale, size=(*domain_size, lie_algebra_dim)).astype(dtype)
    phi_smooth = gaussian_filter(phi_raw, sigma=sigma)
    return phi_smooth * mask[..., None]


def initialize_phi_pair(
    domain_size: tuple[int, ...],
    lie_algebra_dim: int,
    rng: np.random.Generator,
    phi_init: float,
    phi_model_offset: float,
    mask: np.ndarray
) -> tuple[np.ndarray, np.ndarray]:
    """
    Initialize φ and φ̃ (belief and model) with optional offset for φ̃.

    If config.identical_models is True, then φ̃ = 0 identically.
    If phi_model_offset == 0.0, then φ̃ is also initialized as zero.
    Otherwise, φ̃ is an independent Lie algebra sample: φ̃ = Smooth[φ + R·ξ],
    where R is a random SO(3) rotation (on the Lie algebra basis), and ξ is Gaussian noise.
    """
    phi = initialize_phi_field(domain_size, lie_algebra_dim, rng, phi_init, mask)

    if getattr(config, "identical_models", False) or phi_model_offset == 0.0:
        phi_model = np.zeros_like(phi)
    else:
        # Sample noise
        delta = rng.normal(scale=phi_model_offset, size=(*domain_size, lie_algebra_dim)).astype(phi.dtype)

        # Apply random SO(3) rotation matrix to each φ component (shared over grid)
        from scipy.spatial.transform import Rotation
        R = Rotation.random(random_state=rng).as_matrix()  # (3, 3)
        delta_rot = np.einsum("ab,...b->...a", R, delta)   # (H, W, 3)

        phi_model_raw = phi + delta_rot
        phi_model = gaussian_filter(
            phi_model_raw,
            sigma=getattr(config, 'phi_init_smooth_sigma', 0.5)
        )
        phi_model *= mask[..., None]

    return phi, phi_model



def assign_neighbors_vectorized(
    agents: list,
    overlap_eps: float,
    max_neighbors: int
) -> None:
    """
    Assigns neighbors to each agent by computing pairwise mask overlaps.
    Vectorized for efficiency.

    A pair (i, j) is considered overlapping if:
        overlap(i, j) > overlap_eps × num_pixels
    """
    if max_neighbors == 0:
        for agent in agents:
            agent.neighbors = []
        return

    N = len(agents)
    dtype = getattr(config, 'dtype', np.float32)

    # Flatten masks into (N, H×W)
    masks_flat = np.stack([agent.mask.flatten().astype(dtype) for agent in agents])

    # Compute pairwise overlap matrix
    overlap_matrix = masks_flat @ masks_flat.T  # shape: (N, N)
    pixel_thresh = overlap_eps * masks_flat.shape[1]

    # Boolean matrix: True if overlap > threshold
    above_thresh = overlap_matrix > pixel_thresh
    np.fill_diagonal(above_thresh, False)  # Exclude self-overlap

    for i in range(N):
        sorted_idx = np.argsort(-overlap_matrix[i])  # descending order
        valid_neighbors = [j for j in sorted_idx if above_thresh[i, j]]
        agents[i].neighbors = [{"id": j} for j in valid_neighbors[:max_neighbors]]




def create_agent_mask_and_center(domain_size, rng, radius_range, fixed_center=None):
    """
    Sample agent center and radius, and generate its soft mask.

    Args:
        domain_size  : tuple[int, int] = (H, W)
        rng          : np.random.Generator
        radius_range : (float, float)
        fixed_center : optional tuple[int, int]

    Returns:
        center : (int, int) coordinates of agent center
        radius : float
        mask   : (H, W) soft float32 mask
        mask_bool : (H, W) boolean version of mask for edge decay
    """
    radius = rng.uniform(*radius_range)
    center = fixed_center or tuple(rng.integers(0, s) for s in domain_size)
    mask = create_agent_mask(center, radius, domain_size)
    return center, radius, mask.astype(np.float32), mask.astype(bool)

def initialize_agent_gradients(agent, config):
    """
    Initialize all gradient fields for the agent using the shapes of (μ, Σ).
    Should be called once after the agent is created and μ, Σ fields are populated.
    """
    # μ and Σ gradients (belief)
    agent.grad_mu_q_field = np.zeros_like(agent.mu_q_field)
    agent.grad_sigma_q_field = np.zeros_like(agent.sigma_q_field)

    # μ and Σ gradients (model)
    agent.grad_mu_p_field = np.zeros_like(agent.mu_p_field)
    agent.grad_sigma_p_field = np.zeros_like(agent.sigma_p_field)

    # Gauge field gradients
    agent.grad_phi = np.zeros_like(agent.phi)
    agent.grad_phi_tilde = np.zeros_like(agent.phi_model)




def initialize_agentsETA(
    seed: int,
    domain_size: tuple[int, ...],
    N: int,
    K_q: int,
    K_p: int,
    lie_algebra_dim: int,
    visualize: bool = False,
    fixed_location: bool = True,
    params=None,
) -> list:
    """
    Modular initialization of N agents with Gaussian beliefs, models, morphisms, φ, and neighbor structure.
    Uses only natural parameters (η₁, η₂); μ, Σ are computed on demand.
    """
    from bundle_morphism_utils import generate_smooth_morphism_field, gauge_covariant_transform_phi

    rng = default_rng(seed)
    dtype = getattr(config, "dtype", np.float32)
    cfg = {k: getattr(config, k) for k in dir(config) if not k.startswith("__")}

    phi_init         = cfg["phi_init"]
    phi_model_offset = cfg.get("phi_model_offset", 0.1)
    max_neighbors    = cfg.get("max_neighbors", 8)
    overlap_eps      = cfg.get("overlap_eps", 1e-3)
    mu_clip          = cfg.get("mu_clip", 3.0)
    delta_eta1       = cfg.get("delta_eta1", 0.01)
    delta_eta2       = cfg.get("delta_eta2", 0.005)

    group_name = cfg.get("group_name", "so3")
    G_q = get_generators(group_name, K_q)
    G_p = get_generators(group_name, K_p)

    fixed_center = tuple(s // 2 for s in domain_size) if fixed_location else None
    agents = []

    use_global_belief = cfg.get("use_global_belief_template", False)
    use_global_model  = cfg.get("use_global_model_template", False)

    if use_global_belief:
        global_eta1_q_diag, global_eta2_q_diag = generate_eta1_eta2_fields(
            domain_size=domain_size, rng=rng, K=K_q,
            eta1_range=config.q_eta1_range, eta2_range=config.q_eta2_range,
            mask=None, sigma_outside_val=cfg.get("sigma_outside_val", -0.01),
            dtype=dtype, smooth_sigma=cfg.get("init_smooth_sigma", 2.0),
            floor=cfg.get("eta2_floor", -0.5), eps=cfg.get("eta2_min_eigval", 1e-4),
        )

    if use_global_model:
        global_eta1_p_diag, global_eta2_p_diag = generate_eta1_eta2_fields(
            domain_size=domain_size, rng=rng, K=K_p,
            eta1_range=config.p_eta1_range, eta2_range=config.p_eta2_range,
            mask=None, sigma_outside_val=cfg.get("sigma_outside_val", -0.01),
            dtype=dtype, smooth_sigma=cfg.get("init_smooth_sigma", 2.0),
            floor=cfg.get("eta2_floor", -0.5), eps=cfg.get("eta2_min_eigval", 1e-4),
        )

    for n in range(N):
        center, radius, mask, mask_bool = create_agent_mask_and_center(
            domain_size, rng,
            radius_range=cfg.get("agent_radius_range", (5, 10)),
            fixed_center=fixed_center
        )

        if use_global_belief:
            eta1_q_diag = global_eta1_q_diag * mask[..., None]
            eta2_q_diag = global_eta2_q_diag * mask[..., None, None]
            eta1_q_diag += rng.normal(scale=cfg.get("belief_noise_scale_eta1", 0.01), size=eta1_q_diag.shape)
            eta2_q_diag += rng.normal(scale=cfg.get("belief_noise_scale_eta2", 0.005), size=eta2_q_diag.shape)
        else:
            eta1_q_diag, eta2_q_diag = generate_eta1_eta2_fields(
                domain_size=domain_size, rng=rng, K=K_q,
                eta1_range=config.q_eta1_range, eta2_range=config.q_eta2_range,
                mask=mask, sigma_outside_val=cfg.get("sigma_outside_val", -0.01),
                dtype=dtype, smooth_sigma=cfg.get("init_smooth_sigma", 2.0),
                floor=cfg.get("eta2_floor", -0.5), eps=cfg.get("eta2_min_eigval", 1e-4),
            )

        if use_global_model:
            eta1_p_diag = global_eta1_p_diag * mask[..., None]
            eta2_p_diag = global_eta2_p_diag * mask[..., None, None]
            eta1_p_diag += rng.normal(scale=cfg.get("model_noise_scale_eta1", 0.01), size=eta1_p_diag.shape)
            eta2_p_diag += rng.normal(scale=cfg.get("model_noise_scale_eta2", 0.005), size=eta2_p_diag.shape)
        else:
            eta1_p_diag, eta2_p_diag = generate_eta1_eta2_fields(
                domain_size=domain_size, rng=rng, K=K_p,
                eta1_range=config.p_eta1_range, eta2_range=config.p_eta2_range,
                mask=mask, sigma_outside_val=cfg.get("sigma_outside_val", -0.01),
                dtype=dtype, smooth_sigma=cfg.get("init_smooth_sigma", 2.0),
                floor=cfg.get("eta2_floor", -0.5), eps=cfg.get("eta2_min_eigval", 1e-4),
            )

        # Store raw η₁, η₂ diag before rotation
        raw_eta1_q_diag = eta1_q_diag.copy()
        raw_eta2_q_diag = eta2_q_diag.copy()

        
        phi, phi_model = initialize_phi_pair(domain_size, lie_algebra_dim, rng, phi_init, phi_model_offset, mask)
        phi       = soft_clip_phi_norm(phi, max_norm=np.pi)
        phi_model = soft_clip_phi_norm(phi_model, max_norm=np.pi)

        eta1_q, eta2_q = rotate_eta_fields_via_phi_safe(eta1_q_diag, eta2_q_diag, phi, G_q)
        eta1_p, eta2_p = rotate_eta_fields_via_phi_safe(eta1_p_diag, eta2_p_diag, phi_model, G_p)
       

        agent = construct_agent_object(
            agent_id=n,
            center=center,
            radius=radius,
            mask=mask,
            eta1_q=eta1_q, eta2_q=eta2_q,
            eta1_p=eta1_p, eta2_p=eta2_p,
            phi=phi, phi_model=phi_model,
            dtype=dtype
        )

        # Attach raw masked η_diag fields before φ rotation
        agent.raw_eta1_q_diag = raw_eta1_q_diag
        agent.raw_eta2_q_diag = raw_eta2_q_diag
        
        agent.generators_q = G_q
        agent.generators_p = G_p

        # Generate and store smooth base morphisms (Φ₀, Φ̃₀)
        sigma = cfg.get("morphism_sigma", 1.5)
        rank  = cfg.get("morphism_rank", min(K_q, K_p))
        seed  = rng.integers(0, 1e9)

        Phi_0 = generate_smooth_morphism_field(
            *domain_size, K_src=K_q, K_tgt=K_p,   # This is correct: q → p
            sigma=sigma, low_rank=rank, mask=mask, seed=seed
            )
        
        # Transpose over last two axes to get Phi_tilde_0: B_p → B_q
        Phi_tilde_0 = np.swapaxes(Phi_0, -1, -2)  # (H, W, Kq, Kp)

        agent.Phi_0        = Phi_0         # (H, W, Kp, Kq)
        agent.Phi_tilde_0  = Phi_tilde_0   # (H, W, Kq, Kp)

       
        agent.bundle_morphism_q_to_p = gauge_covariant_transform_phi(
            phi_model, phi, Phi_0, G_q=G_q, G_p=G_p
            )
        agent.bundle_morphism_p_to_q = gauge_covariant_transform_phi(
            phi, phi_model, Phi_tilde_0, G_q=G_p, G_p=G_q
            )

        initialize_agent_gradients(agent, config)
        agents.append(agent)

    assign_neighbors_vectorized(agents, overlap_eps=overlap_eps, max_neighbors=max_neighbors)
    return agents



def construct_agent_objectETA(
    agent_id,
    center,
    radius,
    mask,
    eta1_q, eta2_q,
    eta1_p, eta2_p,
    phi, phi_model,
    dtype=np.float32
) -> Agent:
    """
    Build an Agent object from natural parameters only.
    μ and Σ are computed on demand to ensure gauge invariance.

    Args:
        agent_id   : int
        center     : (int, int)
        radius     : float
        mask       : (H, W)
        eta1_q, eta2_q : natural parameters for q (H, W, K_q), (H, W, K_q, K_q)
        eta1_p, eta2_p : natural parameters for p (H, W, K_p), (H, W, K_p, K_p)
        phi, phi_model : (..., d) gauge fields
        dtype      : float32/float64

    Returns:
        Agent
    """
    return Agent(
        id=agent_id,
        center=center,
        radius=radius,
        mask=mask.astype(dtype),

        eta1_q_field=eta1_q.astype(dtype),
        eta2_q_field=eta2_q.astype(dtype),
        eta1_p_field=eta1_p.astype(dtype),
        eta2_p_field=eta2_p.astype(dtype),

        phi=phi.astype(dtype),
        phi_model=phi_model.astype(dtype),

        neighbors=[]
    )