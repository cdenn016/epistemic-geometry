# -*- coding: utf-8 -*-
"""
Created on Thu Jul 24 17:48:40 2025

@author: chris and christine
"""

import numpy as np
from numerical_utils import safe_inv, sanitize_sigma, safe_logdet, sanitize_eta2
import numpy as np
from numpy.linalg import LinAlgError
from numerical_utils import sanitize_eta2, safe_logdet, safe_inv

def convert_mu_sigma_to_eta(mu, sigma):
    """
    Convert (μ, Σ) to natural parameters (η₁, η₂) for multivariate Gaussians:

        η₁ = Σ⁻¹ μ
        η₂ = -½ Σ⁻¹

    Args:
        mu    : (..., K) mean vector
        sigma : (..., K, K) covariance matrix (symmetric, SPD)

    Returns:
        eta1  : (..., K)
        eta2  : (..., K, K)
    """
    from numerical_utils import safe_inv

    sigma_inv = safe_inv(sigma)  # (..., K, K)
    eta1 = np.einsum("...ij,...j->...i", sigma_inv, mu)
    eta2 = -0.5 * sigma_inv
    return eta1, eta2


def mean_from_natural(eta1, eta2, eps=1e-8):
    """
    Compute μ from η = (η₁, η₂), assuming η₂ is NSD.
    """
    eta2_sanitized = sanitize_eta2(eta2, eps=eps, floor=-1e-6)
    sigma_inv = -2.0 * eta2_sanitized
    sigma = safe_inv(sigma_inv, eps=eps)
    mu = np.einsum("...ij,...j->...i", sigma, eta1)
    return mu


def cov_from_natural(eta1, eta2, eps=1e-8):
    """
    Compute Σ from η₂ = −½ Σ⁻¹, with sanitization.
    """
    eta2_sanitized = sanitize_eta2(eta2, eps=eps, floor=-1e-6)
    sigma_inv = -2.0 * eta2_sanitized
    sigma = safe_inv(sigma_inv, eps=eps)
    return sigma


def log_partition_function(eta1, eta2, eps=1e-8):
    """
    Compute log-partition A(η₁, η₂) for a multivariate Gaussian in natural form.
    η₂ = -½ Σ⁻¹ → -2η₂ = Σ⁻¹ must be SPD.
    Returns scalar log-normalizer field.

    Args:
        eta1 : (..., K)
        eta2 : (..., K, K) — should be symmetric negative definite
        eps  : numerical floor for log/stability

    Returns:
        A(η₁, η₂) : log-partition value (...,)
    """
   

    # ── Sanitize η₂ ──
    eta2 = sanitize_eta2(eta2, eps=eps)

    # ── Inverse η₂ ──
    eta2_inv = safe_inv(eta2, eps=eps)

    # ── Quadratic term: ¼ η₁ᵀ η₂⁻¹ η₁ ──
    quad = 0.25 * np.einsum("...i,...ij,...j->...", eta1, eta2_inv, eta1)

    # ── Log determinant of Σ⁻¹ = -2η₂ ──
    Sigma_inv = -2.0 * eta2
    try:
        chol = np.linalg.cholesky(Sigma_inv)
        diag = np.clip(np.diagonal(chol, axis1=-2, axis2=-1), eps, None)
        logdet = 2.0 * np.sum(np.log(diag), axis=-1)
    except LinAlgError:
        logdet = safe_logdet(Sigma_inv, eps=eps)

    # ── Final result ──
    result = quad - 0.5 * logdet
    return np.nan_to_num(result, nan=0.0, posinf=1e6, neginf=0.0)



#Validated 7-26-25
def compute_bar_eta2_qj(eta2_qj, Omega_ij, eps=1e-8, eta2_qj_inv=None):
    """
    Compute:
        bar_eta2_qj = (Omega_ij · eta2_qj⁻¹ · Omega_ijᵀ)⁻¹
    Accepts optional eta2_qj_inv to avoid redundant inversion.

    Args:
        eta2_qj      : (..., K, K)
        Omega_ij     : (..., K, K)
        eta2_qj_inv  : (..., K, K), optional
        eps          : small regularization constant

    Returns:
        bar_eta2_qj : (..., K, K)
    """
    if eta2_qj_inv is None:
        eta2_qj_inv = safe_inv(eta2_qj, eps=eps)

    tmp = np.einsum("...ik,...kl->...il", Omega_ij, eta2_qj_inv)
    pushed = np.einsum("...ij,...jk->...ik", tmp, Omega_ij.swapaxes(-1, -2))
    bar_eta2_qj = safe_inv(pushed, eps=eps)
    return bar_eta2_qj


#VALIDATED 7-26-25
def compute_delta_eta(
    eta1_qi, eta2_qi,
    eta1_qj, eta2_qj,
    Omega_ij,
    eps=1e-8,
    eta2_qi_inv=None,
    eta2_qj_inv=None
):
    """
    Compute:
        Δη = η2_qi⁻¹ · η1_qi − Ω · η2_qj⁻¹ · η1_qj
    Accepts precomputed eta2_qi_inv and eta2_qj_inv.

    Args:
        eta1_qi, eta1_qj : (..., K)
        eta2_qi, eta2_qj : (..., K, K)
        Omega_ij         : (..., K, K)
        eta2_qi_inv      : (..., K, K), optional
        eta2_qj_inv      : (..., K, K), optional

    Returns:
        delta_eta : (..., K)
    """
    if eta2_qi_inv is None:
        eta2_qi_inv = safe_inv(eta2_qi, eps=eps)
    if eta2_qj_inv is None:
        eta2_qj_inv = safe_inv(eta2_qj, eps=eps)

    term_i = np.einsum("...ij,...j->...i", eta2_qi_inv, eta1_qi)
    term_j = np.einsum("...ij,...j->...i", eta2_qj_inv, eta1_qj)
    term_j_push = np.einsum("...ij,...j->...i", Omega_ij, term_j)

    return term_i - term_j_push
                                  # (..., K)




#==================================================
#
#
#$
#===============================================


def mu_sigma_to_natural(mu, sigma, eps=1e-8):
    sigma_inv = safe_inv(sigma, eps)
    eta1 = np.einsum('...ij,...j->...i', sigma_inv, mu)
    eta2 = -0.5 * sigma_inv
    return eta1, eta2

def natural_to_mu_sigma(eta1, eta2, eps=1e-8):
    sigma_inv = -2.0 * eta2
    sigma = safe_inv(sigma_inv, eps)
    mu = np.einsum('...ij,...j->...i', sigma, eta1)
    return mu, sigma

def mu_sigma_to_natural_batch(mu, sigma, eps=1e-8):
    """
    Convert (μ, Σ) → (η₁, η₂) in batch.

    η₁ = Σ⁻¹ μ
    η₂ = −½ Σ⁻¹

    Args:
        mu     : (..., K)
        sigma  : (..., K, K)
        eps    : SPD stabilizer for inverse

    Returns:
        eta1   : (..., K)
        eta2   : (..., K, K)
    """
    sigma_inv = safe_inv(sigma, eps=eps)
    eta1 = np.einsum('...ij,...j->...i', sigma_inv, mu)
    eta2 = -0.5 * sigma_inv
    return eta1, eta2


def natural_to_mu_sigma_batch(eta1, eta2, eps=1e-8):
    """
    Convert natural parameters (η₁, η₂) to (μ, Σ) in batch.

    η₁ = Σ⁻¹ μ
    η₂ = −½ Σ⁻¹

    Args:
        eta1 : (..., K)
        eta2 : (..., K, K) — symmetric
        eps  : float, SPD regularization

    Returns:
        mu    : (..., K)
        sigma : (..., K, K)
    """
    # Invert: η₂ = −½ Σ⁻¹  ⇒  Σ = (−½ η₂)⁻¹
    sigma_inv = -2.0 * eta2
    sigma = safe_inv(sigma_inv, eps=eps)

    # μ = Σ η₁
    mu = np.einsum("...ij,...j->...i", sigma, eta1)
    return mu, sigma

def compute_mu_sigma_from_natural(eta1: np.ndarray, eta2: np.ndarray, eps: float = 1e-8, mu_clip: float = 10.0):
    """
    Convert natural parameters (η₁, η₂) to mean (μ) and covariance (Σ).
    Optionally clips μ to prevent instability in KL divergence calculations.

    Args:
        eta1    : (..., K)
        eta2    : (..., K, K)
        eps     : small value for inverse regularization
        mu_clip : maximum allowed magnitude for μ components

    Returns:
        mu      : (..., K)
        sigma   : (..., K, K)
    """
    from numerical_utils import safe_inv

    sigma_inv = -2.0 * eta2
    sigma = safe_inv(sigma_inv, eps=eps)
    sigma = 0.5 * (sigma + np.swapaxes(sigma, -1, -2))  # enforce symmetry

    mu = np.einsum("...ij,...j->...i", sigma, eta1)

    #if mu_clip is not None:
       # mu_clipped = np.clip(mu, -mu_clip, mu_clip)
      #  if not np.allclose(mu, mu_clipped, atol=1e-3):
      #      print(f"[CLIP] μ values clipped to ±{mu_clip}")
       # mu = mu_clipped

    return mu, sigma


def apply_natural_gradient_batch_eta(
    eta1, eta2, d_eta1, d_eta2, mask, eps=1e-8, eta2_scale=None
):
    """
    Apply natural gradient preconditioning for η₁ and η₂:
        δη₁ = Σ ⋅ ∇η₁
        δη₂ = η2_scale · 4 Σ ⋅ ∇η₂ ⋅ Σ
    """
    _, sigma = natural_to_mu_sigma_batch(eta1, eta2, eps=eps)

    delta_eta1 = np.einsum("...ij,...j->...i", sigma, d_eta1)

    K = eta1.shape[-1]
    if eta2_scale is None:
        eta2_scale = 1.0 / K

    tmp = np.einsum("...ij,...jk->...ik", sigma, d_eta2)
    delta_eta2 = eta2_scale * 4.0 * np.einsum("...ij,...jk->...ik", tmp, sigma)
    delta_eta2 = 0.5 * (delta_eta2 + np.swapaxes(delta_eta2, -1, -2))  # enforce symmetry

    mask_eta1 = np.broadcast_to(mask, eta1.shape)
    mask_eta2 = np.broadcast_to(mask[..., None], eta2.shape)

    delta_eta1 *= mask_eta1
    delta_eta2 *= mask_eta2

    return delta_eta1, delta_eta2


def compute_bar_eta2_q_morphed(eta2_q, Phi, eps=1e-8):
    """
    Compute bar_eta2^Φ_q = (Φ η2_q⁻¹ Φᵀ)⁻¹

    Shapes:
        eta2_q : (..., K_q, K_q)
        Phi    : (..., K_p, K_q)

    Returns:
        bar_eta2_q_Phi : (..., K_p, K_p)
    """
    eta2_inv = safe_inv(eta2_q, eps=eps)
    pushed = np.einsum("...ik,...kl,...jl->...ij", Phi, eta2_inv, Phi)
    return safe_inv(pushed, eps=eps)


def compute_delta_eta_p_Phi_q(eta1_p, eta2_p, eta1_q, eta2_q, Phi, eps=1e-8):
    """
    Compute Δη = η2_p⁻¹ η1_p − Φ η2_q⁻¹ η1_q

    Returns:
        delta_eta : (..., K_p)
    """
    eta2_inv_p = safe_inv(eta2_p, eps=eps)
    eta2_inv_q = safe_inv(eta2_q, eps=eps)

    term_p = np.einsum("...ij,...j->...i", eta2_inv_p, eta1_p)
    term_q = np.einsum("...ij,...j->...i", eta2_inv_q, eta1_q)
    term_q_push = np.einsum("...ij,...j->...i", Phi, term_q)

    return term_p - term_q_push


def compute_bar_eta2_p_morphed(eta2_p, Phi_tilde, eps=1e-8):
    """
    Compute bar_eta2^Φ~_p = (Φ~ η2_p⁻¹ Φ~ᵀ)⁻¹

    Shapes:
        eta2_p     : (..., K_p, K_p)
        Phi_tilde  : (..., K_q, K_p)

    Returns:
        bar_eta2_p_PhiTilde : (..., K_q, K_q)
    """
    eta2_inv = safe_inv(eta2_p, eps=eps)

    pushed = np.einsum("...ik,...kl,...jl->...ij", Phi_tilde, eta2_inv, Phi_tilde)
    return safe_inv(pushed, eps=eps)


def compute_delta_eta_q_PhiTilde_p(eta1_q, eta2_q, eta1_p, eta2_p, Phi_tilde, eps=1e-8):
    """
    Compute Δη = η2_q⁻¹ η1_q − Φ~ η2_p⁻¹ η1_p

    Returns:
        delta_eta : (..., K_q)
    """
    eta2_inv_q = safe_inv(eta2_q, eps=eps)
    eta2_inv_p = safe_inv(eta2_p, eps=eps)

    term_q = np.einsum("...ij,...j->...i", eta2_inv_q, eta1_q)
    term_p = np.einsum("...ij,...j->...i", eta2_inv_p, eta1_p)
    term_p_push = np.einsum("...ij,...j->...i", Phi_tilde, term_p)

    return term_q - term_p_push


def compute_bar_eta2_q_morphed(eta2_q, Phi, eta2_q_inv=None, eps=1e-8):
    """
    Compute bar_eta2^Φ_q = (Φ η2_q⁻¹ Φᵀ)⁻¹

    Args:
        eta2_q       : (..., K_q, K_q)
        Phi          : (..., K_p, K_q)
        eta2_q_inv   : optional precomputed η₂_q⁻¹
    Returns:
        bar_eta2_q_Phi : (..., K_p, K_p)
    """
    if eta2_q_inv is None:
        eta2_q_inv = safe_inv(eta2_q, eps=eps)

    pushed = np.einsum("...ik,...kl->...il", Phi, eta2_q_inv)              # (..., K_p, K_q)
    pushed = np.einsum("...ij,...jk->...ik", pushed, Phi.swapaxes(-1, -2))  # (..., K_p, K_p)

    return safe_inv(pushed, eps=eps)


def compute_delta_eta_p_Phi_q(eta1_p, eta2_p, eta1_q, eta2_q, Phi,
                              eta2_p_inv=None, eta2_q_inv=None, eps=1e-8):
    """
    Compute Δη = η₂_p⁻¹ η₁_p − Φ η₂_q⁻¹ η₁_q

    Args:
        eta1_p        : (..., K_p)
        eta2_p        : (..., K_p, K_p)
        eta1_q        : (..., K_q)
        eta2_q        : (..., K_q, K_q)
        Phi           : (..., K_p, K_q)
        eta2_p_inv    : optional precomputed η₂_p⁻¹
        eta2_q_inv    : optional precomputed η₂_q⁻¹
    Returns:
        delta_eta : (..., K_p)
    """
    if eta2_p_inv is None:
        eta2_p_inv = safe_inv(eta2_p, eps=eps)
    if eta2_q_inv is None:
        eta2_q_inv = safe_inv(eta2_q, eps=eps)

    term_p = np.einsum("...ij,...j->...i", eta2_p_inv, eta1_p)
    term_q = np.einsum("...ij,...j->...i", eta2_q_inv, eta1_q)
    term_q_push = np.einsum("...ij,...j->...i", Phi, term_q)

    return term_p - term_q_push


def compute_bar_eta2_p_morphed(eta2_p, Phi_tilde, eta2_p_inv=None, eps=1e-8):
    """
    Compute bar_eta2^Φ~_p = (Φ~ η2_p⁻¹ Φ~ᵀ)⁻¹

    Shapes:
        eta2_p     : (..., K_p, K_p)
        Phi_tilde  : (..., K_q, K_p)
        eta2_p_inv : optional (..., K_p, K_p)
    Returns:
        bar_eta2_p_PhiTilde : (..., K_q, K_q)
    """
    if eta2_p_inv is None:
        eta2_p_inv = safe_inv(eta2_p, eps=eps)

    pushed = np.einsum("...ik,...kl->...il", Phi_tilde, eta2_p_inv)
    pushed = np.einsum("...ij,...jk->...ik", pushed, Phi_tilde.swapaxes(-1, -2))

    return safe_inv(pushed, eps=eps)


def compute_delta_eta_q_PhiTilde_p(
    eta1_q, eta2_q, eta1_p, eta2_p, Phi_tilde,
    eta2_q_inv=None, eta2_p_inv=None, eps=1e-8
):
    """
    Compute Δη = η2_q⁻¹ η1_q − Φ~ η2_p⁻¹ η1_p

    Args:
        eta1_q, eta2_q : (..., K_q), (..., K_q, K_q)
        eta1_p, eta2_p : (..., K_p), (..., K_p, K_p)
        Phi_tilde      : (..., K_q, K_p)
        eta2_q_inv     : optional (..., K_q, K_q)
        eta2_p_inv     : optional (..., K_p, K_p)

    Returns:
        delta_eta : (..., K_q)
    """
    if eta2_q_inv is None:
        eta2_q_inv = safe_inv(eta2_q, eps=eps)
    if eta2_p_inv is None:
        eta2_p_inv = safe_inv(eta2_p, eps=eps)

    term_q = np.einsum("...ij,...j->...i", eta2_q_inv, eta1_q)
    term_p = np.einsum("...ij,...j->...i", eta2_p_inv, eta1_p)
    term_p_push = np.einsum("...ji,...i->...j", Phi_tilde, term_p)  # Φ~ᵀ · (η2_p⁻¹ η1_p)

    return term_q - term_p_push
