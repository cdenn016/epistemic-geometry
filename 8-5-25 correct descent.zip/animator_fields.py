import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation
from pathlib import Path


def load_all_full_field_logs(folder: str):
    files = sorted(Path(folder).glob("step*.npz"))
    steps = [int(f.stem.replace("step", "")) for f in files]
    logs = [np.load(f) for f in files]
    return steps, logs


def animate_diagnostic_field(
    frames,
    steps,
    field_key: str,
    agent_index: int,
    output_path: str = None,
    cmap: str = "viridis",
    vmin=None,
    vmax=None,
):
    if vmin is None:
        vmin = np.min(frames)
    if vmax is None:
        vmax = np.max(frames)

    fig, ax = plt.subplots(figsize=(6, 6))
    im = ax.imshow(frames[0], cmap=cmap, vmin=vmin, vmax=vmax)
    fig.colorbar(im, ax=ax)

    def update(i):
        im.set_array(frames[i])
        ax.set_title(f"{field_key} — step {steps[i]} (agent {agent_index})")
        return [im]

    ani = animation.FuncAnimation(fig, update, frames=len(frames), blit=True, interval=300)

    if output_path:
        ani.save(output_path, writer="pillow", fps=25)
        print(f"[SAVED] {output_path}")
    else:
        plt.show()

    plt.close(fig)


def animate_curvature_norm(logs, steps, field_key, agent_index, output_path=None):
    frames = [
        np.linalg.norm(log[field_key][agent_index], axis=(-2, -1)) for log in logs
    ]
    animate_diagnostic_field(frames, steps, field_key + "_norm", agent_index, output_path)


def run_full_field_animation(logdir: str, outdir: str = "field_gifs"):
    os.makedirs(outdir, exist_ok=True)
    steps, logs = load_all_full_field_logs(logdir)

    scalar_keys = ["belief_align", "model_align", "kl_self", "kl_feedback"]
    tensor_keys = ["curv_tensor", "curv_model_tensor"]

    N_agents = logs[0]["belief_align"].shape[0]
    print(f"[INFO] Found {N_agents} agents across {len(steps)} steps")

    for agent_index in range(N_agents):
        agent_out = os.path.join(outdir, f"agent{agent_index:02d}")
        os.makedirs(agent_out, exist_ok=True)

        for key in scalar_keys:
            frames = [log[key][agent_index] for log in logs]
            out_path = os.path.join(agent_out, f"{key}.gif")
            animate_diagnostic_field(frames, steps, key, agent_index, output_path=out_path)

        for key in tensor_keys:
            out_path = os.path.join(agent_out, f"{key}_norm.gif")
            animate_curvature_norm(logs, steps, key, agent_index, output_path=out_path)


if __name__ == "__main__":
    run_full_field_animation(
        logdir="C:/Users/chris and christine/Desktop/ig/checkpoints/fields/",
        outdir="C:/Users/chris and christine/Desktop/ig/field_gifs/"
    )

