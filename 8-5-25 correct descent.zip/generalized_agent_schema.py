# Updated generalized_agent_schema.py with default grad_phi and grad_phi_tilde
from dataclasses import dataclass, field
from typing import Any, Dict, List, Tuple, Optional
import numpy as np
import config
from natural_params_utils import compute_mu_sigma_from_natural  # must exist
from omega import exp_lie_algebra_irrep
import copy


@dataclass
class Agent:
    id: int
    center: Tuple[int, ...]
    radius: float
    
    
    mask: np.ndarray

    phi: np.ndarray
    phi_model: np.ndarray

    mu_q_field: np.ndarray
    sigma_q_field: np.ndarray
    mu_p_field: np.ndarray
    sigma_p_field: np.ndarray

    neighbors: List[Dict[str, Any]] = field(default_factory=list)
    metrics_log: List[Dict[str, Any]] = field(default_factory=list)

    grad_mu_q: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    grad_sigma_q: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    
    grad_mu_p: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    grad_sigma_p: Optional[np.ndarray] = field(default=None, init=False, repr=False)

    # Lie algebra generators
    generators_q: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    generators_p: Optional[np.ndarray] = field(default=None, init=False, repr=False)

    # Runtime cache fields
    _exp_phi: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    _exp_neg_phi: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    _exp_phi_model: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    _exp_neg_phi_model: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    transport_cache: Dict[str, Any] = field(default_factory=dict, init=False)

    # Morphism fields
    bundle_morphism_q_to_p: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    bundle_morphism_p_to_q: Optional[np.ndarray] = field(default=None, init=False, repr=False)

    Phi_0: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    Phi_tilde_0: Optional[np.ndarray] = field(default=None, init=False, repr=False)

    grad_phi: np.ndarray = field(init=False, repr=False)
    grad_phi_tilde: np.ndarray = field(init=False, repr=False)

    grad_Phi: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    grad_Phi_tilde: Optional[np.ndarray] = field(default=None, init=False, repr=False)

    inverse_fisher_phi: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    inverse_fisher_phi_model: Optional[np.ndarray] = field(default=None, init=False, repr=False)

    inverse_fisher_Phi: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    inverse_fisher_Phi_tilde: Optional[np.ndarray] = field(default=None, init=False, repr=False)

    fisher_I: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    pull_M_vis: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    pull_Delta: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    pull_M_dark: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    spatial_G: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    
    # Existing natural parameter gradient fields (belief)
    grad_eta1_q_field: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    grad_eta2_q_field: Optional[np.ndarray] = field(default=None, init=False, repr=False)

    # 🆕 ADD THESE (model)
    grad_eta1_p_field: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    grad_eta2_p_field: Optional[np.ndarray] = field(default=None, init=False, repr=False)

    def __post_init__(self):
        self.grad_phi = np.zeros_like(self.phi)
        self.grad_phi_tilde = np.zeros_like(self.phi_model)

        self.grad_Phi = np.zeros_like(self.bundle_morphism_q_to_p) if self.bundle_morphism_q_to_p is not None else None
        self.grad_Phi_tilde = np.zeros_like(self.bundle_morphism_p_to_q) if self.bundle_morphism_p_to_q is not None else None

    def initialize_natural_parameters_from_mu_sigma(self):
        from natural_params_utils import convert_mu_sigma_to_eta
        from numerical_utils import safe_inv

        self.eta1_q_field, self.eta2_q_field = convert_mu_sigma_to_eta(self.mu_q_field, self.sigma_q_field)
        self.eta1_p_field, self.eta2_p_field = convert_mu_sigma_to_eta(self.mu_p_field, self.sigma_p_field)

        self.eta2_q_inv = safe_inv(self.eta2_q_field, eps=config.eta2_min_eigval)
        self.eta2_p_inv = safe_inv(self.eta2_p_field, eps=config.eta2_min_eigval)

        self.grad_eta1_q_field = np.zeros_like(self.eta1_q_field)
        self.grad_eta2_q_field = np.zeros_like(self.eta2_q_field)
        
        self.grad_eta1_p_field = np.zeros_like(self.eta1_p_field)
        self.grad_eta2_p_field = np.zeros_like(self.eta2_p_field)


    @property
    def grid_shape(self) -> Tuple[int, ...]:
        return self.mu_q_field.shape[:-1]

    @property
    def Omega(self) -> np.ndarray:
        K = self.mu_q_field.shape[-1]
        return self._exp_phi.reshape(*self.grid_shape, K, K)

    @property
    def Omega_inv(self) -> np.ndarray:
        K = self.mu_q_field.shape[-1]
        return self._exp_neg_phi.reshape(*self.grid_shape, K, K)

    @property
    def Omega_model(self) -> np.ndarray:
        K = self.mu_p_field.shape[-1]
        return self._exp_phi_model.reshape(*self.grid_shape, K, K)

    @property
    def Omega_model_inv(self) -> np.ndarray:
        K = self.mu_p_field.shape[-1]
        return self._exp_neg_phi_model.reshape(*self.grid_shape, K, K)

    @property
    def bundle_morphism(self) -> Optional[np.ndarray]:
        return self.bundle_morphism_q_to_p

    @property
    def bundle_morphism_model(self) -> Optional[np.ndarray]:
        return self.bundle_morphism_p_to_q

    def log_metrics(self, step: int, stats: Dict[str, Any]) -> None:
        self.metrics_log.append(copy.deepcopy({'step': step, **stats}))

    def clear_omega_cache(self) -> None:
        self._exp_phi = None
        self._exp_neg_phi = None
        self._exp_phi_model = None
        self._exp_neg_phi_model = None
        self.transport_cache.clear()

    def clear_diagnostics(self) -> None:
        self.fisher_I = None
        self.pull_M_vis = None
        self.pull_Delta = None
        self.pull_M_dark = None
        self.spatial_G = None

    def clear_fisher_caches(self) -> None:
        self.inverse_fisher_phi = None
        self.inverse_fisher_phi_model = None
        self.inverse_fisher_Phi = None
        self.inverse_fisher_Phi_tilde = None



