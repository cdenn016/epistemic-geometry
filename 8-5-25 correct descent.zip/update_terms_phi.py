# -*- coding: utf-8 -*-
"""
Created on Wed Jul 23 06:38:17 2025

@author: chris and christine
"""
import numpy as np
import config
import numpy as np
from scipy.linalg import inv
from numerical_utils import safe_inv, sanitize_sigma
from omega import exp_lie_algebra_irrep, compute_curvature_gradient_analytical
from natural_gradient import dexpinv_operator, dexpinv_operator_covariance, compute_fisher_geometry_gradient, compute_inverse_fisher_field_natural

from natural_params_utils import compute_bar_eta2_qj,compute_delta_eta
from omega import d_exp_phi_exact, exp_lie_algebra_irrep, d_exp_phi_exact_batch
from numerical_utils import safe_inv, soft_clip_phi_norm
from natural_params_utils import compute_bar_eta2_qj, compute_delta_eta

#==============================================================================
#
#                    GATHER PHI GAUGE FIELD GRADIENT TERMS
#                          Beliefs and Models
#==============================================================================

from omega import d_exp_phi_exact
from numerical_utils import safe_inv

def accumulate_phi_gradient_belief(agent_i, agent_j, generators, params, debug=False):
    """
    Compute and apply natural gradient:
        ∇_{φ_i} KL(q_i || Ω_ij q_j)
        ∇_{φ_j} KL(q_i || Ω_ij q_j)
    using exact ∂Ω/∂φ gradients, natural projection, and dexpinv correction.
    Uses (μ, Σ) parameterization.
    """
    beta = params.get("beta", config.beta)
    if beta <= 0:
        return

    eps = config.support_cutoff_eps
    joint_mask = (agent_i.mask > eps) & (agent_j.mask > eps)
    joint_mask = joint_mask.astype(float)[..., None]

    mu_qi, sigma_qi = agent_i.mu_q_field, agent_i.sigma_q_field
    mu_qj, sigma_qj = agent_j.mu_q_field, agent_j.sigma_q_field

    phi_i = agent_i.phi
    phi_j = agent_j.phi
    exp_phi_i = agent_i._exp_phi
    exp_phi_j = agent_j._exp_phi
    exp_neg_phi_j = agent_j._exp_neg_phi

    Omega_ij = agent_i.Omega_cache[agent_j.id]

    # ── Shared pushforward terms ─────────────────────────────
    mu_j_t = np.einsum("...ij,...j->...i", Omega_ij, mu_qj)
    delta_mu = mu_qi - mu_j_t

    Omega_T = np.swapaxes(Omega_ij, -1, -2)
    sigma_j_t = np.einsum("...ik,...kl,...lj->...ij", Omega_ij, sigma_qj, Omega_T)
    sigma_j_t = sanitize_sigma(sigma_j_t, eps=config.eps)
    sigma_j_inv = safe_inv(sigma_j_t, eps=config.eps)


    # ── ∇_φ_i ───────────────────────────────────────────────
    grad_phi_i_raw = grad_kl_wrt_phi_i(
        mu_qi, sigma_qi,
        mu_qj, sigma_qj,
        phi_i=phi_i,
        phi_j=phi_j,
        Omega_ij=Omega_ij,
        generators=generators,
        exp_phi_i=exp_phi_i,
        exp_phi_j=exp_phi_j,
        mu_j_t=mu_j_t,
        sigma_j_t_inv=sigma_j_inv,
        eps=config.eps
    )

    # ── ∇_φ_j ───────────────────────────────────────────────
    grad_phi_j_raw = grad_kl_wrt_phi_j(
        mu_qi, sigma_qi,
        mu_qj, sigma_qj,
        phi_j=phi_j,
        phi_i=phi_i,
        Omega_ij=Omega_ij,
        generators=generators,
        exp_phi_j=exp_phi_j,
        exp_phi_i=exp_phi_i,
        mu_j_t=mu_j_t,
        sigma_j_t_inv=sigma_j_inv,
        eps=config.eps
    )

    # ── Natural projection and dexpinv ───────────────────────
    F_inv_i = agent_i.inverse_fisher_phi
    F_inv_j = agent_j.inverse_fisher_phi

    grad_phi_i_nat = np.einsum("...ab,...b->...a", F_inv_i, grad_phi_i_raw)
    grad_phi_j_nat = np.einsum("...ab,...b->...a", F_inv_j, grad_phi_j_raw)

    grad_phi_i = dexpinv_operator(phi_i, grad_phi_i_nat, generators)
    grad_phi_j = dexpinv_operator(phi_j, grad_phi_j_nat, generators)

    # ── Regularization on φᵢ only ───────────────────────────
    reg_grad_i = apply_regularization_terms_lie_natural(
        agent=agent_i,
        phi_field=phi_i,
        generators=generators,
        field="phi",
        params=params,
    )
    reg_grad_i *= joint_mask


    agent_i.grad_phi += (beta * grad_phi_i + reg_grad_i) * joint_mask
    agent_j.grad_phi += beta * grad_phi_j * joint_mask
    
    #print(f"[phi_i grad] norm belief = {np.mean(np.linalg.norm(grad_phi_i, axis=-1)):.2e}")
    #print(f"[phi_j grad] norm belief = {np.mean(np.linalg.norm(grad_phi_j, axis=-1)):.2e}\n\n")


def accumulate_phi_gradient_model(agent_i, agent_j, generators, params, debug=False):
    """
    Compute and apply natural gradient:
        ∇_{φ̃_i} KL(p_i || Ω̃_ij p_j)
        ∇_{φ̃_j} KL(p_i || Ω̃_ij p_j)
    using exact ∂Ω̃/∂φ̃ gradients, Fisher projection, and dexpinv correction.
    """
    beta_model = params.get("beta_model", config.beta_model)
    if beta_model <= 0:
        return

    eps = config.support_cutoff_eps
    joint_mask = (agent_i.mask > eps) & (agent_j.mask > eps)
    joint_mask = joint_mask.astype(float)[..., None]

    mu_pi, sigma_pi = agent_i.mu_p_field, agent_i.sigma_p_field
    mu_pj, sigma_pj = agent_j.mu_p_field, agent_j.sigma_p_field

    phi_i = agent_i.phi_model
    phi_j = agent_j.phi_model
    exp_phi_i = agent_i._exp_phi_model
    exp_phi_j = agent_j._exp_phi_model
    exp_neg_phi_j = agent_j._exp_neg_phi_model

    Omega_tilde_ij = agent_i.Omega_tilde_cache[agent_j.id]

    expected = np.einsum("...ik,...kj->...ij", exp_phi_i, exp_neg_phi_j)
    assert np.allclose(Omega_tilde_ij, expected, atol=1e-5), \
        f"[Ω̃ mismatch] agent_i={agent_i.id}, agent_j={agent_j.id}"

    F_inv_i = agent_i.inverse_fisher_phi_model
    F_inv_j = agent_j.inverse_fisher_phi_model

    # ── Precompute shared transport quantities ──────────────
    mu_j_t = np.einsum("...ij,...j->...i", Omega_tilde_ij, mu_pj)
    delta_mu = mu_pi - mu_j_t

    Omega_T = np.swapaxes(Omega_tilde_ij, -1, -2)
    sigma_j_t = np.einsum("...ik,...kl,...lj->...ij", Omega_tilde_ij, sigma_pj, Omega_T)
    sigma_j_t = sanitize_sigma(sigma_j_t, eps=config.eps)
    sigma_j_inv = safe_inv(sigma_j_t, eps=config.eps)

    # ∂KL(pᵢ || Ω̃ pⱼ) w.r.t. φ̃ᵢ
    grad_phi_tilde_i_raw = grad_kl_wrt_phi_i(
        mu_pi, sigma_pi,
        mu_pj, sigma_pj,
        phi_i=phi_i,
        phi_j=phi_j,
        Omega_ij=Omega_tilde_ij,
        generators=generators,
        exp_phi_i=exp_phi_i,
        exp_phi_j=exp_phi_j,
        mu_j_t=mu_j_t,
        sigma_j_t_inv=sigma_j_inv,
        eps=config.eps,
    )

    # ∂KL(pᵢ || Ω̃ pⱼ) w.r.t. φ̃ⱼ
    grad_phi_tilde_j_raw = grad_kl_wrt_phi_j(
        mu_pi, sigma_pi,
        mu_pj, sigma_pj,
        phi_j=phi_j,
        phi_i=phi_i,
        Omega_ij=Omega_tilde_ij,
        generators=generators,
        exp_phi_j=exp_phi_j,
        exp_phi_i=exp_phi_i,
        mu_j_t=mu_j_t,
        sigma_j_t_inv=sigma_j_inv,
        eps=config.eps,
    )

    # ── Natural gradient projection and dexpinv ─────────────
    grad_phi_tilde_i_nat = np.einsum("...ab,...b->...a", F_inv_i, grad_phi_tilde_i_raw)
    grad_phi_tilde_j_nat = np.einsum("...ab,...b->...a", F_inv_j, grad_phi_tilde_j_raw)

    grad_phi_tilde_i = dexpinv_operator(phi_i, grad_phi_tilde_i_nat, generators)
    grad_phi_tilde_j = dexpinv_operator(phi_j, grad_phi_tilde_j_nat, generators)

    # ── Regularize φ̃ᵢ only ─────────────────────────────────
    reg_grad_i = apply_regularization_terms_lie_natural(
        agent=agent_i,
        phi_field=phi_i,
        generators=generators,
        field="phi_model",
        params=params,
    )
    reg_grad_i *= joint_mask

    agent_i.grad_phi_tilde += (beta_model * grad_phi_tilde_i + reg_grad_i) * joint_mask
    agent_j.grad_phi_tilde += beta_model * grad_phi_tilde_j * joint_mask
    
    #print(f"[phi_i grad] norm model = {np.mean(np.linalg.norm(grad_phi_tilde_i, axis=-1)):.2e}")
   # print(f"[phi_j grad] norm belief = {np.mean(np.linalg.norm(grad_phi_tilde_j, axis=-1)):.2e}\n\n")

#################################################################################


#==============================================================================
#
#                    WITH RESPECT TO phi_i TERMS
#                       VALIDATED
#==============================================================================

def grad_kl_wrt_phi_i(
    mu_i, sigma_i,
    mu_j, sigma_j,
    phi_i, phi_j,
    Omega_ij,
    generators,
    exp_phi_i,
    exp_phi_j,
    mu_j_t=None,
    sigma_j_t_inv=None,
    eps=1e-8,
):
    """
    Compute ∂/∂φ_i^a KL(q_i || Ω_ij q_j)
    using boxed expression:
        ∇_φᵢ KL = 
            -½ Tr[(Σ_ij⁻¹ Qᵢ + Qᵢᵀ Σ_ij⁻¹) Σᵢ]
            - μⱼᵀ Ωᵢⱼᵀ Qᵢᵀ Σ_ij⁻¹ Δμ
            + ½ Δμᵀ (Qᵢᵀ Σ_ij⁻¹ + Σ_ij⁻¹ Qᵢ) Δμ
    """
    d, K, _ = generators.shape
    shape = mu_i.shape[:-1]

    Omega_ij_T = Omega_ij.swapaxes(-1, -2)

    if mu_j_t is None:
        mu_j_t = np.einsum("...ij,...j->...i", Omega_ij, mu_j)

    delta_mu = mu_i - mu_j_t

    if sigma_j_t_inv is None:
        sigma_j_t = np.einsum("...ik,...kl,...lj->...ij", Omega_ij, sigma_j, Omega_ij_T)
        sigma_j_t = sanitize_sigma(sigma_j_t, eps)
        sigma_j_t_inv = safe_inv(sigma_j_t, eps)

    grad = np.zeros((*shape, d), dtype=mu_i.dtype)
    d_exp_phi_i_all = d_exp_phi_exact(phi_i, generators)

    for a in range(d):
        Q_i = d_exp_phi_i_all[a]
        Q_i_T = np.swapaxes(Q_i, -1, -2)

        # Trace term: -½ Tr[(Σ_ij⁻¹ Qᵢ + Qᵢᵀ Σ_ij⁻¹) Σᵢ]
        trace_term = -0.5 * np.einsum(
            "...ij,...jk,...ki->...",
            sigma_j_t_inv, Q_i, sigma_i
        ) - 0.5 * np.einsum(
            "...ij,...jk,...ki->...",
            Q_i_T, sigma_j_t_inv, sigma_i
        )

        # Mean transport term: -μ_jᵀ Ωᵢⱼᵀ Qᵢᵀ Σ⁻¹ Δμ
        tmp = np.einsum("...jk,...k->...j", Q_i_T, delta_mu)
        mean_term = -np.einsum(
            "...j,...jk,...k->...",
            mu_j, Omega_ij_T, np.einsum("...jk,...k->...j", sigma_j_t_inv, tmp)
        )

        # Mahalanobis term: +½ Δμᵀ (Qᵢᵀ Σ⁻¹ + Σ⁻¹ Qᵢ) Δμ
        v1 = np.einsum("...ij,...j->...i", sigma_j_t_inv, delta_mu)
        part1 = np.einsum("...ij,...j->...i", Q_i_T, v1)

        v2 = np.einsum("...ij,...j->...i", Q_i, delta_mu)
        part2 = np.einsum("...ij,...j->...i", sigma_j_t_inv, v2)

        mahalanobis_term = 0.5 * np.einsum("...i,...i->...", delta_mu, part1 + part2)

        grad[..., a] = trace_term + mean_term + mahalanobis_term

    return grad




#==============================================================================
#
#                    WITH RESPECT TO phi_j TERMS
#
#==============================================================================
def grad_kl_wrt_phi_j(
    mu_i, sigma_i,
    mu_j, sigma_j,
    phi_j, phi_i,
    Omega_ij,
    generators,
    exp_phi_j,
    exp_phi_i,
    mu_j_t=None,
    sigma_j_t_inv=None,
    eps=1e-8
):
    """
    Compute ∂/∂φ_j^a D_KL(q_i || Ω_ij q_j), where:

        - q_i ~ 𝒩(μ_i, Σ_i)           # belief
        - q_j ~ 𝒩(μ_j, Σ_j)           # transported target
        - Ω_ij = exp(φ_i) · exp(−φ_j)
        - ∂Ω_ij / ∂φ_j^a = −Ω_ij · Q_j^a
        with Q_j^a = ∂ exp(φ_j) / ∂ φ_j^a

        - μ_j^Ω = Ω_ij μ_j
        - Σ_j^Ω = Ω_ij Σ_j Ω_ijᵀ
        - Δμ = μ_i − μ_j^Ω
    
    The boxed expression is:

        ∂/∂φ_j^a KL(q_i || Ω_ij q_j) =

        −½ · Tr[ (Σ_j^Ω⁻¹ · Q̄_j + Q̄_jᵀ · Σ_j^Ω⁻¹) · Σ_i ]
        + μ_jᵀ · Q̄_jᵀ · Σ_j^Ω⁻¹ · Δμ
        + ½ · Δμᵀ · (Q̄_jᵀ · Σ_j^Ω⁻¹ + Σ_j^Ω⁻¹ · Q̄_j) · Δμ

    where:
        - Q̄_j := Ω_ij · Q_j^a ∈ ℝ^{K_i × K_j}
        is the pushforward of ∂Ω/∂φ_j^a into q_i's fiber

        All terms are computed in the fiber space of q_i.
    """

    d, K, _ = generators.shape
    shape = mu_i.shape[:-1]

    Omega_T = Omega_ij.swapaxes(-1, -2)

    if mu_j_t is None:
        mu_j_t = np.einsum("...ij,...j->...i", Omega_ij, mu_j)

    delta_mu = mu_i - mu_j_t

    if sigma_j_t_inv is None:
        sigma_ij = np.einsum("...ik,...kl,...lj->...ij", Omega_ij, sigma_j, Omega_T)
        sigma_ij = sanitize_sigma(sigma_ij, eps)
        sigma_j_t_inv = safe_inv(sigma_ij, eps)

    grad = np.zeros((*shape, d), dtype=mu_i.dtype)
    d_exp_phi_j_all = d_exp_phi_exact(phi_j, generators)

    for a in range(d):
        Q_j = d_exp_phi_j_all[a]                        # (..., K, K)
        Q_j_bar = np.einsum("...ik,...kj->...ij", Omega_ij, Q_j)   # (..., K, K)
        Q_j_bar_T = np.swapaxes(Q_j_bar, -1, -2)

        # Trace term: -½ Tr[(Σ⁻¹ Q + Qᵀ Σ⁻¹) Σᵢ]
        trace1 = -0.5 * np.einsum("...ij,...jk,...ki->...", sigma_j_t_inv, Q_j_bar, sigma_i)
        trace2 = -0.5 * np.einsum("...ij,...jk,...ki->...", Q_j_bar_T, sigma_j_t_inv, sigma_i)
        trace_term = trace1 + trace2

        v = np.einsum("...ij,...j->...i", sigma_j_t_inv, delta_mu)   
        tmp = np.einsum("...ji,...i->...j", Q_j_bar, v)               
        mean_term = np.einsum("...j,...j->...", mu_j, tmp)            


        # Mahalanobis term: +½ Δμᵀ (Qᵀ Σ⁻¹ + Σ⁻¹ Q) Δμ
        v1 = np.einsum("...ij,...j->...i", Q_j_bar_T, np.einsum("...ij,...j->...i", sigma_j_t_inv, delta_mu))
        tmp2 = np.einsum("...ij,...j->...i", Q_j_bar, delta_mu)
        v2 = np.einsum("...ij,...j->...i", sigma_j_t_inv, tmp2)
        maha_term = 0.5 * np.einsum("...i,...i->...", delta_mu, v1 + v2)


        grad[..., a] = trace_term + mean_term + maha_term

    return grad


def grad_kl_wrt_phi_jOLD(
    mu_i, sigma_i,
    mu_j, sigma_j,
    phi_j, phi_i,
    Omega_ij,
    generators,
    exp_phi_j,
    exp_phi_i,
    mu_j_t=None,
    sigma_j_t_inv=None,
    eps=1e-8
):
    """
    Compute the Lie-algebra gradient of the KL divergence:
        ∂/∂φ_j^a KL(q_i || Ω_ij q_j)

    where:
        - q_i ~ N(μ_i, Σ_i)
        - q_j ~ N(μ_j, Σ_j)
        - Ω_ij = exp(φ_i) · exp(−φ_j)
        - ∂Ω_ij / ∂φ_j^a = −Ω_ij · ∂e^{φ_j} / ∂φ_j^a · e^{−φ_j}
        - The full boxed expression is:

            ∂KL / ∂φ_j^a =
               
            ½ Tr[Σ_i Σ̃_j⁻¹ (e^{φ_i} ∂e^{−φ_j} / ∂φ_j^a + ∂e^{φ_j} / ∂φ_j^a e^{−φ_i})]
            
            + μ_jᵀ ∂e^{φ_j} / ∂φ_j^a e^{−φ_i} Σ̃_j⁻¹ Δμ
            
            − ½ Δμᵀ [Σ̃_j⁻¹ e^{φ_i} ∂e^{−φ_j} / ∂φ_j^a Ω_ijᵀ + Ω_ij ∂e^{φ_j} / ∂φ_j^a e^{−φ_i} Σ̃_j⁻¹] Δμ

        where Σ̃_j = Ω_ij Σ_j Ω_ijᵀ and Δμ = μ_i − Ω_ij μ_j.

    Args:
        mu_i, sigma_i       : (..., K), (..., K, K), belief parameters of q_i
        mu_j, sigma_j       : (..., K), (..., K, K), belief parameters of q_j
        phi_j, phi_i        : (..., d), Lie algebra coordinates of φ_j and φ_i
        Omega_ij            : (..., K, K), transport matrix from q_j to q_i (Ω_ij = e^{φ_i} · e^{−φ_j})
        generators          : (d, K, K), basis of the Lie algebra 𝔤
        exp_phi_j, exp_phi_i: (..., K, K), exponentials e^{φ_j} and e^{φ_i}
        mu_j_t              : optional (..., K), precomputed Ω_ij μ_j
        sigma_j_t_inv       : optional (..., K, K), precomputed (Ω_ij Σ_j Ω_ijᵀ)⁻¹
        eps                 : regularization constant for inverse/sanitization

    Returns:
        grad_phi_j          : (..., d), gradient ∇_{φ_j} KL(q_i || Ω_ij q_j)
    """

    d, K, _ = generators.shape
    shape = mu_i.shape[:-1]

    exp_mphi_i = exp_phi_i.swapaxes(-1, -2)
    Omega_T = Omega_ij.swapaxes(-1, -2)

    if mu_j_t is None:
        mu_j_t = np.einsum("...ij,...j->...i", Omega_ij, mu_j)

    if sigma_j_t_inv is None:
        sigma_ij = np.einsum("...ik,...kl,...lj->...ij", Omega_ij, sigma_j, Omega_T)
        sigma_ij = sanitize_sigma(sigma_ij, eps)
        sigma_j_t_inv = safe_inv(sigma_ij, eps)

    delta_mu = mu_i - mu_j_t
    d_exp_phi_j_all = d_exp_phi_exact(phi_j, generators)

    grad = np.zeros((*shape, d), dtype=mu_i.dtype)

    for a in range(d):
        Q_j = d_exp_phi_j_all[a]
        Q_j_T = np.swapaxes(Q_j, -1, -2)

        # ───── Term 1: Trace Sandwich ─────
        t1a = exp_phi_i @ Q_j_T @ Omega_T
        t1b = Omega_ij @ Q_j @ exp_mphi_i
        trace_expr = t1a + t1b
        trace_term = 0.5 * np.einsum("...ij,...jk,...ki->...", sigma_i, sigma_j_t_inv, trace_expr)

        # ───── Term 2: μ_jᵀ Q_j e^{-φ_i} Σ_{ij}^{-1} Δμ ─────
        tmp = Q_j @ exp_mphi_i @ sigma_j_t_inv @ delta_mu[..., None]
        term2 = np.einsum("...i,...i->...", mu_j, tmp[..., 0])

        # ───── Term 3a: Δμᵀ Σ_{ij}^{-1} e^{φ_i} Q_jᵀ Ωᵀ Δμ ─────
        A = sigma_j_t_inv @ exp_phi_i @ Q_j_T @ Omega_T
        term3a = np.einsum("...i,...ij,...j->...", delta_mu, A, delta_mu)

        # ───── Term 3b: Δμᵀ Ω Q_j e^{-φ_i} Σ_{ij}^{-1} Δμ ─────
        B = Omega_ij @ Q_j @ exp_mphi_i @ sigma_j_t_inv
        term3b = np.einsum("...i,...ij,...j->...", delta_mu, B, delta_mu)

        grad[..., a] = trace_term + term2 - 0.5 * term3a - 0.5 * term3b

    return grad



def apply_regularization_terms(
    phi, generators,
    curv_weight, mass_weight,
    morphism=None, fiber="phi",   # use "phi" or "phi_model"
    agent_i=None, agents=None,
    fisher_weight=0.0, params=None,
    eps=1e-8
):
    """
    Compute total φ or φ̃ regularization gradient in natural (Lie algebra) coordinates.
    Includes curvature, mass, and Fisher geometry terms.
    Uses provided `generators` and supports proper morphism conjugation.

    Args:
        phi           : (..., d)
        generators    : (d, K, K)
        curv_weight   : float, weight for curvature regularization
        mass_weight   : float, weight for mass penalty ‖φ‖²
        morphism      : optional morphism for fiber coupling (currently unused)
        fiber         : "phi" or "phi_model"
        agent_i       : current agent
        agents        : all agents
        fisher_weight : float, multiplies Fisher term (computed inside)
        params        : config params (only needed for Fisher)
        eps           : numerical stability constant

    Returns:
        grad_natural  : (..., d), regularization gradient in natural coordinates
    """
    if curv_weight == 0 and mass_weight == 0 and fisher_weight == 0:
        return np.zeros_like(phi)

    grad_euclidean = np.zeros_like(phi)

    if curv_weight > 0:
        grad_curv = compute_curvature_gradient_analytical(phi, generators)
        grad_euclidean += curv_weight * grad_curv

    if mass_weight > 0:
        grad_mass = 2 * phi
        grad_euclidean += mass_weight * grad_mass

    if fisher_weight > 0 and agent_i is not None and agents is not None:
        grad_fisher = compute_fisher_geometry_gradient(agent_i, agents, params, field=fiber)
        grad_euclidean += grad_fisher  # already weighted inside function

    return dexpinv_operator(phi, grad_euclidean, generators)




def apply_regularization_terms_lie_natural(
    agent,
    phi_field,
    generators,
    field,  # "phi" or "phi_model"
    params,
):
    """
    Compute φ or φ̃ regularization gradient in natural coordinates using agent-local fields.

    Args:
        agent      : the Agent object
        phi_field  : (..., K, K) — φ or φ̃ (current field)
        generators : (d, K, K)
        field      : "phi" or "phi_model"
        params     : dict of simulation/config params

    Returns:
        grad_nat   : (..., d) — projected natural gradient
    """
    eps = params.get("eps", config.eps)

    if field == "phi":
        curv_weight     = params.get("curvature_weight", config.curvature_weight)
        fisher_weight   = params.get("phi_fisher_weight", config.fisher_geometry_weight)
        mass_weight     = params.get("phi_mass_weight", config.belief_mass)
        phi             = phi_field
        morphism        = agent.bundle_morphism_q_to_p
        fiber           = "belief"
    elif field == "phi_model":
        curv_weight     = params.get("curvature_weight", config.model_curvature_weight)
        fisher_weight   = params.get("phi_fisher_weight", config.fisher_model_geometry_weight)
        mass_weight     = params.get("phi_model_mass_weight", config.model_mass)
        phi             = phi_field
        morphism        = agent.bundle_morphism_p_to_q
        fiber           = "model"
    else:
        raise ValueError(f"Invalid field name: {field}")

    return apply_regularization_terms(
        phi=phi,
        generators=generators,
        curv_weight=curv_weight,
        mass_weight=mass_weight,
        morphism=morphism,
        fiber=fiber,
        agent_i=agent,
        agents=params.get("agents", None),
        fisher_weight=fisher_weight,
        params=params,
        eps=eps,
    )






