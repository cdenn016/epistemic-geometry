# -*- coding: utf-8 -*-
"""
Created on Fri Jul 25 10:19:37 2025

@author: chris and christine
"""
import config
import numpy as np
from natural_params_utils import natural_to_mu_sigma_batch
from numerical_utils import sanitize_sigma, safe_logdet

from numpy.linalg import svd, eigvalsh

from pathlib import Path
# Standard library
import os
# Third-party libraries
import numpy as np
from generalized_omega import (exp_lie_algebra_irrep, batch_apply_omega,
                              compute_field_strength)
from get_generators import get_generators 
from joblib import Parallel, delayed

import config
from pathlib import Path

from generalized_math_utils import laplacian_field  # ← make sure this is imported
from mask_utils import (
    get_support_mask,
    get_overlap_mask,
    expand_mask_for_mu,
    expand_mask_for_sigma,
    apply_mask_mu,
    apply_mask_sigma,
    apply_mask_phi,
    norm_over_mask,
    masked_norm,
    threshold_mask
)
from bundle_morphism_utils import safe_batch_apply_morphism_nat
from generalized_omega import batch_apply_omega, compute_inter_omega_fieldwise, compute_field_strength



from numerical_utils import sanitize_sigma, sanitize_eta2, safe_transport_eta2
from update_rules import preprocess_agent_fields
from natural_params_utils import mean_from_natural, log_partition_function, cov_from_natural
import numpy as np
from numerical_utils import safe_inv
from natural_params_utils import compute_mu_sigma_from_natural, log_partition_function, sanitize_eta2
from bundle_morphism_utils import safe_batch_apply_morphism_nat
from numerical_utils import sanitize_eta2

def grad_log_partition(eta1, eta2, eps=1e-8):
    eta2 = sanitize_eta2(eta2, eps=eps)  # <- safety for all internal uses
    mu = mean_from_natural(eta1, eta2, eps=eps)
    Sigma = cov_from_natural(eta1, eta2, eps=eps)
    theta1 = mu
    theta2 = Sigma + np.einsum("...i,...j->...ij", mu, mu)
    return theta1, theta2


def kl_divergence(
    eta1_1, eta2_1,
    eta1_2, eta2_2,
    mask=None,
    eps=1e-8
):
    """
    Batched KL[𝒩(η₁₁, η₂₁) || 𝒩(η₁₂, η₂₂)] in natural parameters.

    Args:
        eta1_1: (..., K)     — first η₁ (e.g. q)
        eta2_1: (..., K, K)  — first η₂
        eta1_2: (..., K)     — second η₁ (e.g. p)
        eta2_2: (..., K, K)  — second η₂
        mask:   (...,) optional — multiplies KL result
        eps:    float — numerical stabilizer

    Returns:
        kl: (...,) — KL divergence values (zero where masked)
    """
    # ── Sanitize η₂ fields ──
    eta2_1 = sanitize_eta2(eta2_1, eps=eps)
    eta2_2 = sanitize_eta2(eta2_2, eps=eps)

    # ── θ = ∇A(η) = (μ, Σ + μμᵀ) ──
    theta1_1, theta2_1 = grad_log_partition(eta1_1, eta2_1, eps=eps)
    theta1_2, theta2_2 = grad_log_partition(eta1_2, eta2_2, eps=eps)

    # ⟨η₁, θ₁ - θ₂⟩
    dtheta1 = theta1_1 - theta1_2
    dtheta2 = theta2_1 - theta2_2

    inner1 = np.einsum("...i,...i->...", eta1_1, dtheta1)
    inner2 = np.einsum("...ij,...ij->...", eta2_1, dtheta2)
    inner = inner1 + inner2

    # ── A(η) terms ──
    A1 = log_partition_function(eta1_1, eta2_1, eps=eps)
    A2 = log_partition_function(eta1_2, eta2_2, eps=eps)

    kl = inner - A1 + A2

    # ── Optional masking ──
    if mask is not None:
        mask = np.asarray(mask)
        if mask.ndim == 2:
            mask = np.squeeze(mask, axis=-1)
        kl *= mask

    # ── Final safety ──
    kl = np.nan_to_num(kl, nan=0.0, posinf=1e9, neginf=0.0)
    kl = np.clip(kl, 0.0, 1e6)
    return kl

#removed sanitize
def compute_kl_projected_field_natural(agent, direction="p_to_q", eps=1e-8):
    """
    Compute KL[src || Φ·tgt] via pullback Fisher geometry on natural parameter bundles.

    Args:
        agent    : Agent object with fields and morphisms
        direction: "p_to_q" or "q_to_p"
        eps      : regularization epsilon

    Returns:
        kl_field : (H, W) array of KL approximations over support
    """
    from config import kl_self_cutoff

    support = agent.mask > kl_self_cutoff
    if not np.any(support):
        return np.zeros_like(agent.mask, dtype=np.float32)

    # Select fields based on direction
    if direction == "p_to_q":
        eta1_src = agent.eta1_q_field
        eta2_src = agent.eta2_q_field
        eta1_tgt = agent.eta1_p_field
        eta2_tgt = agent.eta2_p_field
        morphism = agent.bundle_morphism_p_to_q
    elif direction == "q_to_p":
        eta1_src = agent.eta1_p_field
        eta2_src = agent.eta2_p_field
        eta1_tgt = agent.eta1_q_field
        eta2_tgt = agent.eta2_q_field
        morphism = agent.bundle_morphism_q_to_p
    else:
        raise ValueError("direction must be 'p_to_q' or 'q_to_p'")

    # Restrict to support
    eta1_src_s = eta1_src[support]
    eta2_src_s = eta2_src[support]
    eta1_tgt_s = eta1_tgt[support]
    eta2_tgt_s = eta2_tgt[support]
    morphism_s = morphism[support]

    # Apply morphism: tgt → projected to src-fiber
    eta1_proj, eta2_proj = safe_batch_apply_morphism_nat(
        eta1_tgt_s, eta2_tgt_s, morphism_s, eps=eps
    )
    eta2_proj = 0.5 * (eta2_proj + np.swapaxes(eta2_proj, -1, -2))  # symmetrize

    # Log μ only (do NOT reconstruct η₁)
    mu_proj, _ = compute_mu_sigma_from_natural(eta1_proj, eta2_proj)
    if np.any(np.abs(mu_proj) > 10.0):
        print(f"[WARN] agent {agent.id} ‖μ_proj‖ exceeded ±10 before KL: max = {np.max(np.abs(mu_proj)):.2f}")

    # Optional: final η₁ norm clip to avoid KL blowup
    eta1_norm = np.linalg.norm(eta1_proj, axis=-1, keepdims=True)
    eta1_clip_max = 10.0
    scaling = np.minimum(1.0, eta1_clip_max / (eta1_norm + eps))
    eta1_proj *= scaling
    if np.any(scaling < 1.0):
        print(f"[CLIP] η₁_proj norm clipped for agent {agent.id}")

    # Compute Fisher metric at η_proj
    delta_eta1 = eta1_src_s - eta1_proj
    delta_eta2 = eta2_src_s - eta2_proj
    G1, G2 = hessian_log_partition(eta1_proj, eta2_proj, eps=eps)

    # KL ≈ ½ Δηᵀ G Δη
    term1 = np.einsum("...i,...ij,...j->...", delta_eta1, G1, delta_eta1)
    term2 = np.einsum("...ij,...ijkl,...kl->...", delta_eta2, G2, delta_eta2)
    kl_vals = 0.5 * (term1 + term2)

    kl_vals = np.nan_to_num(kl_vals, nan=0.0, posinf=1e9, neginf=0.0)
    kl_vals = np.clip(kl_vals, 0.0, 1e6)
    if np.any(kl_vals >= 1e6):
        print(f"[WARNING] KL maxed at 1e6 for agent {agent.id}")
        print(f"   max raw KL (geom): {np.max(term1 + term2):.4g}")

    # Fill output field
    kl_field = np.zeros_like(agent.mask, dtype=kl_vals.dtype)
    kl_field[support] = kl_vals
    
    print(f"[DEBUG KL_geom] agent {agent.id} mean KL = {np.mean(kl_vals):.4e}")
    print(f"[DEBUG KL_geom] ‖Δη₁‖ mean = {np.mean(np.linalg.norm(delta_eta1, axis=-1)):.4f}")
    print(f"[DEBUG KL_geom] ‖Δη₂‖ mean = {np.mean(np.linalg.norm(delta_eta2, axis=(-2, -1))):.4f}")

    
    return kl_field




def hessian_log_partition(eta1, eta2, eps=1e-8):
    """
    Compute Fisher information metric (Hessian of log-partition A)
    for multivariate Gaussian in natural coordinates.

    Args:
        eta1 : (..., K)
        eta2 : (..., K, K), symmetric and negative semi-definite
        eps  : regularization constant

    Returns:
        G1   : (..., K, K)     — Fisher block w.r.t. η₁ (expectation cov)
        G2   : (..., K, K, K, K) — 2nd-order Fisher block w.r.t. η₂
    """
    import numpy as np
    from numerical_utils import safe_inv

    # Safe inverse of η₂ (i.e., Σ = -½ η₂⁻¹)
    eta2_inv = safe_inv(eta2, eps=eps)
    sigma = -0.5 * eta2_inv  # (..., K, K)
    sigma = 0.5 * (sigma + np.swapaxes(sigma, -1, -2))  # enforce symmetry

    # G1 = Cov[θ₁, θ₁] = Σ
    G1 = sigma  # (..., K, K)

    # G2 = Cov[θ₂, θ₂] = 2 (Σ ⊗ Σ)
    G2 = 2.0 * np.einsum("...ij,...kl->...ijkl", sigma, sigma)  # (..., K, K, K, K)

    return G1, G2




def kl_gaussian_natural(eta1_i, eta2_i, eta1_j, eta2_j, eps=1e-8):
    """
    KL[𝒩(ηᵢ) || 𝒩(ηⱼ)] using natural parameters.
    Computes:
        D_KL(q_i || q_j) = A(η_j) - A(η_i) - ⟨η_j − η_i, ∇A(η_i)⟩
    """
    # Ensure symmetric η2
    eta2_i = 0.5 * (eta2_i + np.swapaxes(eta2_i, -1, -2))
    eta2_j = 0.5 * (eta2_j + np.swapaxes(eta2_j, -1, -2))

    # Compute ∇A(η_i)
    theta1_i, theta2_i = grad_log_partition(eta1_i, eta2_i, eps=eps)

    # Log partition values
    A_i = log_partition_function(eta1_i, eta2_i, eps=eps)
    A_j = log_partition_function(eta1_j, eta2_j, eps=eps)

    # Inner product
    d_eta1 = eta1_j - eta1_i
    d_eta2 = eta2_j - eta2_i
    inner = (
        np.einsum("...i,...i->...", d_eta1, theta1_i) +
        np.einsum("...ij,...ij->...", d_eta2, theta2_i)
    )

    kl = A_j - A_i - inner
    return np.clip(kl, 0.0, 1e9)


def compute_alignment_field_general(
    agents, i, field_type="belief",
    eps=config.support_cutoff_eps,
    log_eps=config.log_eps
) -> np.ndarray:
    """
    Compute spatial KL field KL[q_i(c) || Ω_ij · q_j(c)] (or model equivalent)
    using natural parameters and exponential-family geometry.

    Returns:
        (H, W) array — per-pixel average KL divergence field over overlaps
    """
    agent = agents[i]  # ✅ FIXED
    mask_i = threshold_mask(agent.mask, eps)
    if not np.any(mask_i) or not agent.neighbors:
        return np.zeros_like(agent.mask, dtype=np.float32)

    H, W = agent.mask.shape
    kl_accum = np.zeros((H, W), dtype=np.float32)
    n_nb_at = np.zeros((H, W), dtype=np.int32)

    if field_type == "belief":
        eta1_i = agent.eta1_q_field
        eta2_i = sanitize_eta2(agent.eta2_q_field, eps=log_eps)
        phi_i  = agent.phi
        K      = config.K_q
    elif field_type == "model":
        eta1_i = agent.eta1_p_field
        eta2_i = sanitize_eta2(agent.eta2_p_field, eps=log_eps)
        phi_i  = agent.phi_model
        K      = config.K_p
    else:
        raise ValueError(f"[compute_alignment_field] Invalid field_type: '{field_type}'")

    generators = get_generators(config.group_name, K)

    for nb in agent.neighbors:
        neighbor_agent = agents[nb["id"]]
        mask_j = threshold_mask(neighbor_agent.mask, eps)
        overlap = mask_i & mask_j
        if not np.any(overlap):
            continue

        idx = np.argwhere(overlap)
        i_idx, j_idx = idx[:, 0], idx[:, 1]

        eta1_j_full = neighbor_agent.eta1_q_field if field_type == "belief" else neighbor_agent.eta1_p_field
        eta2_j_full = neighbor_agent.eta2_q_field if field_type == "belief" else neighbor_agent.eta2_p_field
        phi_j_full  = neighbor_agent.phi if field_type == "belief" else neighbor_agent.phi_model

        eta1_i_pts = eta1_i[i_idx, j_idx]
        eta2_i_pts = sanitize_eta2(eta2_i[i_idx, j_idx], eps=log_eps)
        eta1_j_pts = eta1_j_full[i_idx, j_idx]
        eta2_j_pts = sanitize_eta2(eta2_j_full[i_idx, j_idx], eps=log_eps)
        phi_i_pts  = phi_i[i_idx, j_idx]
        phi_j_pts  = phi_j_full[i_idx, j_idx]

        O_i     = exp_lie_algebra_irrep(phi_i_pts, generators)
        O_j_inv = exp_lie_algebra_irrep(-phi_j_pts, generators)
        Omega   = np.einsum("mab,mbc->mac", O_i, O_j_inv)

        eta1_j_t = np.einsum("mab,mb->ma", Omega, eta1_j_pts)
        eta2_j_t = np.einsum("mab,mbc,mcd->mad", Omega, eta2_j_pts, Omega)
        eta2_j_t = 0.5 * (eta2_j_t + np.swapaxes(eta2_j_t, -1, -2))  # symmetrize

        eta2_i_pts = sanitize_eta2(eta2_i_pts, eps=log_eps)
        eta2_j_t   = sanitize_eta2(eta2_j_t,   eps=log_eps)

        kl_vals = kl_gaussian_natural(
            eta1_i_pts, eta2_i_pts,
            eta1_j_t,   eta2_j_t,
            eps=log_eps
        )

        if np.any(np.isnan(kl_vals)) or np.any(np.isinf(kl_vals)):
            print("[WARN] NaN/Inf in KL field")
            kl_vals = np.nan_to_num(kl_vals, nan=0.0, posinf=1e9, neginf=0.0)

        np.add.at(kl_accum, (i_idx, j_idx), kl_vals)
        np.add.at(n_nb_at, (i_idx, j_idx), 1)

    out = np.zeros_like(kl_accum, dtype=np.float32)
    valid = (n_nb_at > 0) & mask_i
    out[valid] = kl_accum[valid] / n_nb_at[valid]
    return out




def compute_pairwise_kl_field(agents, generators, params, field_type="belief", return_pointwise=False):
    """
    Compute KL[q_i || Ω_ij · q_j] or KL[p_i || Ω_ij · p_j] using natural parameters for all (i, j) pairs.

    Args:
        agents           : list of Agent objects
        generators       : (d, K, K) Lie algebra basis for the group irrep
        params           : dict with 'log_eps', 'overlap_eps', and 'group_name'
        field_type       : either "belief" or "model"
        return_pointwise : if True, returns full per-point KL maps

    Returns:
        kl_matrix        : (N, N)
        pointwise        : (optional) {(i,j): KL_field}
    """
    from numerical_utils import sanitize_eta2, safe_transport_eta2
    from omega import compute_inter_omega_fieldwise
    from natural_params_utils import grad_log_partition, log_partition_function
    import numpy as np

    log_eps = params.get("log_eps", 1e-8)
    eps     = params.get("overlap_eps", 1e-6)
    group   = params.get("group_name", "so3")

    N = len(agents)
    kl_matrix = np.full((N, N), np.nan)
    pointwise = {} if return_pointwise else None

    for i, agent_i in enumerate(agents):
        mask_i = agent_i.mask > eps
        if not np.any(mask_i):
            continue

        if field_type == "belief":
            eta1_i = agent_i.eta1_q_field
            eta2_i = sanitize_eta2(agent_i.eta2_q_field, eps=log_eps)
            phi_i  = agent_i.phi
        elif field_type == "model":
            eta1_i = agent_i.eta1_p_field
            eta2_i = sanitize_eta2(agent_i.eta2_p_field, eps=log_eps)
            phi_i  = agent_i.phi_model
        else:
            raise ValueError(f"[KL Field] Invalid field_type: '{field_type}'")

        for j, agent_j in enumerate(agents):
            if i == j:
                kl_matrix[i, j] = 0.0
                continue

            mask_j = agent_j.mask > eps
            overlap = mask_i & mask_j
            if not np.any(overlap):
                continue

            if field_type == "belief":
                eta1_j = agent_j.eta1_q_field
                eta2_j = sanitize_eta2(agent_j.eta2_q_field, eps=log_eps)
                phi_j  = agent_j.phi
            else:
                eta1_j = agent_j.eta1_p_field
                eta2_j = sanitize_eta2(agent_j.eta2_p_field, eps=log_eps)
                phi_j  = agent_j.phi_model

            eta1_i_pts = eta1_i[overlap]
            eta2_i_pts = sanitize_eta2(eta2_i[overlap], eps=log_eps)

            eta1_j_pts = eta1_j[overlap]
            eta2_j_pts = sanitize_eta2(eta2_j[overlap], eps=log_eps)

            phi_i_pts = phi_i[overlap]
            phi_j_pts = phi_j[overlap]

            # ─── Compute Ω_ij and transport q_j or p_j to i-frame ───
            Omega_ij = compute_inter_omega_fieldwise(phi_i_pts, phi_j_pts, generators, group_name=group)

            eta1_j_t = np.einsum("mab,mb->ma", Omega_ij, eta1_j_pts)
            eta2_j_t = safe_transport_eta2(eta2_j_pts, Omega_ij, eps=log_eps, clip_trace=20.0)
            eta2_j_t = sanitize_eta2(eta2_j_t, eps=log_eps)

            # ─── Compute KL divergence in natural parameter form ───
            A_i = log_partition_function(eta1_i_pts, eta2_i_pts, eps=log_eps)
            A_j = log_partition_function(eta1_j_t, eta2_j_t, eps=log_eps)

            θ1_i, θ2_i = grad_log_partition(eta1_i_pts, eta2_i_pts, eps=log_eps)
            θ1_j, θ2_j = grad_log_partition(eta1_j_t, eta2_j_t, eps=log_eps)

            dθ1 = θ1_i - θ1_j
            dθ2 = 0.5 * (θ2_i - θ2_j + np.swapaxes(θ2_i - θ2_j, -1, -2))  # symmetrize

            inner = (
                np.einsum("...i,...i->...", eta1_i_pts, dθ1) +
                np.einsum("...ij,...ij->...", eta2_i_pts, dθ2)
            )

            kl_vals = inner - A_i + A_j
            kl_vals = np.nan_to_num(kl_vals, nan=0.0, posinf=1e9, neginf=0.0)
            kl_vals = np.clip(kl_vals, 0.0, 1e9)

            if np.any(kl_vals < -1e-5):
                print(f"[WARN] KL[{i},{j}] has negative values:", kl_vals.min(), kl_vals.mean())

            mean_kl = float(np.mean(kl_vals))
            kl_matrix[i, j] = mean_kl if np.isfinite(mean_kl) else 0.0

            if return_pointwise:
                pw_field = np.zeros_like(mask_i, dtype=np.float32)
                pw_field[overlap] = kl_vals
                pointwise[(i, j)] = pw_field

    return (kl_matrix, pointwise) if return_pointwise else kl_matrix



def compute_entropy_field(eta2_field, mask, log_eps=1e-8):
    """
    Compute per-cell entropy H[q(c)] using natural parameter η₂ = −½ Σ⁻¹

    Args:
        eta2_field : (H, W, K, K) — second natural parameter η₂
        mask       : (H, W) — boolean or float mask
        log_eps    : float — stabilizer

    Returns:
        H_field    : (H, W) — entropy values, 0 outside mask
    """
    H, W, K, _ = eta2_field.shape
    H_field = np.zeros((H, W), dtype=np.float64)

    # Compute log det(−2η₂) = log det(Sigma⁻¹)
    neg2_eta2 = -2.0 * eta2_field
    neg2_eta2 += log_eps * np.eye(K)[None, None, :, :]  # Stabilize

    for i in range(H):
        for j in range(W):
            if not mask[i, j]:
                continue
            try:
                sign, logdet = safe_logdet(neg2_eta2[i, j])
                if not np.isfinite(logdet) or sign <= 0:
                    raise np.linalg.LinAlgError
            except np.linalg.LinAlgError:
                logdet = np.nan
            H_field[i, j] = 0.5 * (K * np.log(2 * np.pi * np.e) + logdet)

    H_field[~mask] = 0.0
    return H_field

def compute_self_energy(agent, log_eps, cfg):
    """
    Compute α · KL(q || Φ̃ p), using morphism_p_to_q
    """
    return cfg["alpha"] * compute_kl_projected_field_natural(
        agent=agent,
        direction="p_to_q",
        eps=log_eps,
    )


def compute_feedback_energy(agent, log_eps, cfg):
    """
    Compute β · KL(p || Φ q), using morphism_q_to_p
    """
    if agent.bundle_morphism_q_to_p is None:
        print(f"[ERROR] agent {agent.id} — bundle_morphism_q_to_p is None!")
    return cfg["feedback_weight"] * compute_kl_projected_field_natural(
        agent=agent,
        direction="q_to_p",
        eps=log_eps,
    )


def compute_curvature_energy_field(phi_field, mask, weight, lie_gens, support_eps=1e-4, debug=False):
    """
    Compute curvature energy: weight × ∑_x Tr[F_{μν}(x)^2] over valid mask.

    Args:
        phi_field   : (H, W, d)     — φ or φ_model field in Lie algebra coords
        mask        : (H, W)        — agent support mask
        weight      : float         — energy weight coefficient
        lie_gens    : (d, K, K)     — Lie algebra generators
        support_eps : float         — minimum support threshold
        debug       : bool          — optional print/debug info

    Returns:
        energy      : float         — weighted curvature energy
        raw_total   : float         — ∑ Tr[F²] over support (unweighted)
    """
    F_dict = compute_field_strength(phi_field, lie_gens)  # dict of F_xy, F_yz, etc.
    support = mask > support_eps

    total = 0.0
    for key, val in F_dict.items():
        if val.ndim == 2:
            total += val**2
        elif val.ndim == 3:
            total += np.sum(val**2, axis=-1)  # vector norm²
        elif val.ndim == 4:
            total += np.sum(val**2, axis=(-2, -1))  # Frobenius norm²
        else:
            raise ValueError(f"[ERROR] Unexpected F_{key} shape: {val.shape}")

    raw_total = float(np.sum(total[support]))
    if debug:
        print(f"[φ_curv] Raw: {raw_total:.4f} | Weighted: {weight * raw_total:.4f}")

    return weight * raw_total, raw_total

def compute_laplacian_field_energy(phi):
    """
    Return the Laplacian energy density ‖Δφ(x)‖² at each point.

    Args:
        phi : (H, W, d) — Lie algebra field

    Returns:
        (H, W) — spatial energy density field
    """
    lap = laplacian_field(phi)  # (H, W, d)
    return np.sum(lap**2, axis=-1)  # (H, W)

def compute_mass_field_energy(phi):
    """
    Return the mass energy density ‖φ(x)‖² at each point.

    Args:
        phi : (H, W, d)

    Returns:
        (H, W) — spatial energy density field
    """
    return np.sum(phi**2, axis=-1)

def compute_phi_coupling_field_energy(phi_q, phi_p, morphism_q_to_p):
    """
    Return pointwise coupling energy ‖Φ φ_q Φ⁻¹ − φ_p‖² at each point.

    Args:
        phi_q           : (H, W, d_q)
        phi_p           : (H, W, d_p)
        morphism_q_to_p : (H, W, K_p, K_q)

    Returns:
        (H, W) — spatial coupling energy field
    """
    from bundle_morphism_utils import gauge_covariant_transform_phi

    phi_q_trans = gauge_covariant_transform_phi(phi_q, morphism_q_to_p)
    assert phi_q_trans.shape == phi_p.shape, "Shape mismatch after morphism transform"

    return np.sum((phi_q_trans - phi_p)**2, axis=-1)



#===================================================================
#
#            Scalar Energies
#
#===================================================================


def compute_self_energy_scalar(agent, log_eps, cfg):
    """
    Compute total weighted KL(q_i || Φ̃ · p_i), scalar output for energy.
    """
    kl_field = compute_self_energy(agent, log_eps, cfg)
    agent.e_self_field = kl_field  # Optional: store for diagnostics
   
    print(f"[DEBUG] agent {agent.id} self KL max: {np.max(kl_field):.4e}, mean: {np.mean(kl_field):.4e}")

    # Mask invalid or zero-support regions
    valid_mask = (agent.mask > cfg.get("support_cutoff_eps", 1e-3)) & np.isfinite(kl_field)
    total_energy = float(np.sum(kl_field[valid_mask]))

    return total_energy

def compute_feedback_energy_scalar(agent, log_eps, cfg):
    """
    Compute total weighted KL(p_i || Φ · q_i) — returns scalar feedback energy.
    """
    kl_field = compute_feedback_energy(agent, log_eps, cfg)
    agent.e_feedback_field = kl_field  # Optional caching

    valid_mask = (agent.mask > cfg.get("support_cutoff_eps", 1e-3)) & np.isfinite(kl_field)
    total_energy = float(np.sum(kl_field[valid_mask]))

    return total_energy

def compute_alignment_energy_general(
    i, agent_i, eta_field_list, mask_list,
    Omega_list, Omega_inv_list,
    weight,
    log_eps=config.log_eps,
    field_type="belief"
) -> float:
    """
    Compute ∑_j weight * D_KL(η_i || Ω_ij · η_j), using natural parameters.

    Args:
        eta_field_list : list of (η₁, η₂) tuples for each agent
        mask_list      : list of binary masks
        Omega_list     : list of exp(phi) fields
        Omega_inv_list : list of exp(-phi) fields
        weight         : scalar multiplier
        field_type     : "belief" or "model" (for diagnostics only)

    Returns:
        total_energy   : scalar weighted KL
    """
    from natural_params_utils import log_partition_function

    eta1_i, eta2_i = eta_field_list[i]
    mask_i = mask_list[i]
    support_i = mask_i > config.support_cutoff_eps

    total_energy = 0.0
    for nb in agent_i.neighbors:
        j = nb["id"]
        eta1_j, eta2_j = eta_field_list[j]
        mask_j = mask_list[j]
        support_j = mask_j > config.support_cutoff_eps

        overlap = support_i & support_j
        if not np.any(overlap):
            continue

        # Ω_ij = Ω_i · Ω_j⁻¹
        Omega_ij = np.einsum("mab,mbc->mac", Omega_list[i][overlap], Omega_inv_list[j][overlap])

        # Transport η_j into i's frame
        eta1_j_t = np.einsum("mab,mb->ma", Omega_ij, eta1_j[overlap])
        eta2_j_t = np.einsum("mab,mbc,mcd->mad", Omega_ij, eta2_j[overlap], Omega_ij)

        eta1_i_pts = eta1_i[overlap]
        eta2_i_pts = eta2_i[overlap]

        # KL[q_i || Ω q_j] = A(η_j^t) − A(η_i) − ⟨η_i, η_j^t − η_i⟩
        A_j = log_partition_function(eta1_j_t, eta2_j_t, eps=log_eps)
        A_i = log_partition_function(eta1_i_pts, eta2_i_pts, eps=log_eps)

        d_eta1 = eta1_j_t - eta1_i_pts
        d_eta2 = eta2_j_t - eta2_i_pts

        inner = np.einsum("...i,...i->...", eta1_i_pts, d_eta1) \
              + np.einsum("...ij,...ij->...", eta2_i_pts, d_eta2)

        kl_vals = A_j - A_i - inner
        kl_vals = np.where(np.isfinite(kl_vals), kl_vals, 0.0)

        total_energy += weight * float(np.sum(kl_vals))

    return total_energy




def entropy_total(sigma_field, mask, log_eps=1e-8):
    """
    Total entropy ∑ H[q(c)] over the masked domain.
    """
    H = compute_entropy_field(sigma_field, mask, log_eps)
    return float(np.nansum(H))



def compute_laplacian_energy(phi, mask, weight):
    """
    Compute Laplacian regularization energy:
        E = weight * ∫_mask ‖Δφ‖²

    Args:
        phi   : (H, W, d) Lie algebra field
        mask  : (H, W) bool array
        weight: float

    Returns:
        float — scalar energy term
    """
    lap = laplacian_field(phi)  # (H, W, d)
    norms_sq = np.sum(lap**2, axis=-1)  # (H, W)
    return float(weight * np.sum(norms_sq[mask > 0]))


def compute_mass_energy(phi, mask, weight):
    """
    Compute mass regularization energy:
        E = weight * ∫_mask ‖φ‖²

    Args:
        phi   : (H, W, d) Lie algebra field
        mask  : (H, W) bool array
        weight: float

    Returns:
        float — scalar energy term
    """
    norms_sq = np.sum(phi**2, axis=-1)
    return float(weight * np.sum(norms_sq[mask > 0]))


def compute_phi_coupling_energy(
    phi_q, phi_p, morphism_q_to_p, mask, weight
):
    """
    Compute coupling energy ∫ ‖dΦ · φ_q · dΦ⁻¹ − φ_p‖² over the mask.

    Args:
        phi_q         : (H, W, d_q)
        phi_p         : (H, W, d_p)
        morphism_q_to_p : (H, W, K_p, K_q) — bundle morphism Φ: B_q → B_p
        mask          : (H, W)
        weight        : float

    Returns:
        float — scalar coupling energy
    """
    from bundle_morphism_utils import gauge_covariant_transform_phi

    # Transform phi_q into model frame
    phi_q_trans = gauge_covariant_transform_phi(phi_q, morphism_q_to_p)

    # Match shape
    assert phi_q_trans.shape == phi_p.shape, "Shape mismatch after morphism transform"

    diff_sq = np.sum((phi_q_trans - phi_p)**2, axis=-1)
    return float(weight * np.sum(diff_sq[mask > 0]))


def compute_curvature_energy(phi_field, mask, weight, lie_gens, support_eps=1e-4, debug=False):
    """
    Compute curvature energy: weight × ∑_x Tr[F_{μν}(x)^2] over valid mask.

    Args:
        phi_field   : (H, W, d)     — φ or φ_model field in Lie algebra coords
        mask        : (H, W)        — agent support mask
        weight      : float         — energy weight coefficient
        lie_gens    : (d, K, K)     — Lie algebra generators
        support_eps : float         — minimum support threshold
        debug       : bool          — optional print/debug info

    Returns:
        energy      : float         — weighted curvature energy
        raw_total   : float         — ∑ Tr[F²] over support (unweighted)
    """
    F_dict = compute_field_strength(phi_field, lie_gens)  # dict of F_xy, F_yz, etc.
    support = mask > support_eps

    total = 0.0
    for key, val in F_dict.items():
        if val.ndim == 2:
            total += val**2
        elif val.ndim == 3:
            total += np.sum(val**2, axis=-1)  # vector norm²
        elif val.ndim == 4:
            total += np.sum(val**2, axis=(-2, -1))  # Frobenius norm²
        else:
            raise ValueError(f"[ERROR] Unexpected F_{key} shape: {val.shape}")

    raw_total = float(np.sum(total[support]))
    if debug:
        print(f"[φ_curv] Raw: {raw_total:.4f} | Weighted: {weight * raw_total:.4f}")

    return weight * raw_total, raw_total



def zero_agent_metrics() -> dict:
    return {
        "e_self": 0.0,
        "e_feedback": 0.0,
        "e_align": 0.0,
        "e_mod_align": 0.0,
        "e_curv": 0.0,
        "e_curv_mod": 0.0,
        "e_mass": 0.0,
        "e_mass_mod": 0.0,
        "phi_norm": 0.0,
        "phi_model_norm": 0.0
    }


def compute_agent_metrics(
    i: int,
    agent,
    Q_eta_list, P_eta_list, Mask_list,
    O_bel, O_inv, O_mod, O_mod_inv,
    cfg, gens, log_eps
) -> tuple[int, dict]:
    """
    Compute all variational energy terms and norms for a single agent.
    Returns (i, stats)
    """
    mask = Mask_list[i]
    if not np.any(mask):
        return i, zero_agent_metrics()

    stats = compute_all_agent_metrics(
        i, agent, Q_eta_list, P_eta_list, Mask_list,
        O_bel, O_inv, O_mod, O_mod_inv,
        cfg, gens, log_eps
    )
    return i, stats

def log_agent_metrics(agent, step: int, stats: dict, support: float):
    S = support if support > 0 else 1.0
    agent.log_metrics(step, {
        "kl_self":           stats["e_self"]       / S,
        "kl_feedback":       stats["e_feedback"]   / S,
        "kl_align":          stats["e_align"]      / S,
        "kl_mod_align":      stats["e_mod_align"]  / S,
        "curv_energy":       stats["e_curv"]       / S,
        "curv_model_energy": stats["e_curv_mod"]   / S,
        "mass_energy":       stats["e_mass"]       / S,
        "mass_model_energy": stats["e_mass_mod"]   / S,
        "phi_norm":          stats["phi_norm"],
        "phi_model_norm":    stats["phi_model_norm"],
    })


def accumulate_and_log_metrics(results, agents, step: int, Q_eta_list, Mask_list) -> dict:
    keys = [
        "e_self", "e_feedback", "e_align", "e_mod_align",
        "e_curv", "e_curv_mod", "e_mass", "e_mass_mod"
    ]
    accum = {k: 0.0 for k in keys}
    total_support = 0.0

    for i, stats in results:
        support = float(np.sum(Mask_list[i]))
        total_support += support
        for k in keys:
            accum[k] += stats.get(k, 0.0)  # use .get for safety
        log_agent_metrics(agents[i], step, stats, support)

    S = total_support if total_support > 0 else 1.0
    metrics = {k: accum[k] / S for k in keys}
    metrics["total_energy"] = sum(metrics[k] for k in keys)
    metrics["step"] = step
    return metrics



def compute_all_agent_metrics(
    i, A, Q_eta_list, P_eta_list, Mask_list,
    O_bel, O_inv, O_mod, O_mod_inv,
    cfg, generators, log_eps
):
    """
    Compute all energy terms using natural parameter fields.
    """
    gen_q, gen_p = generators
    mask = Mask_list[i]

    stats = {
        "e_self": compute_self_energy_scalar(A, log_eps, cfg),
        "e_feedback": compute_feedback_energy_scalar(A, log_eps, cfg),

        "e_align": compute_alignment_energy_general(
            i=i,
            agent_i=A,
            eta_field_list=Q_eta_list,
            mask_list=Mask_list,
            Omega_list=O_bel,
            Omega_inv_list=O_inv,
            weight=cfg["beta"],
            log_eps=log_eps,
            field_type="belief"
        ),

        "e_mod_align": compute_alignment_energy_general(
            i=i,
            agent_i=A,
            eta_field_list=P_eta_list,
            mask_list=Mask_list,
            Omega_list=O_mod,
            Omega_inv_list=O_mod_inv,
            weight=cfg["beta_model"],
            log_eps=log_eps,
            field_type="model"
        ),

        "e_curv": 0.0,
        "e_curv_mod": 0.0,
        "phi_norm": np.linalg.norm(A.phi[mask], axis=-1).sum(),
        "phi_model_norm": np.linalg.norm(A.phi_model[mask], axis=-1).sum()
    }
    
    if cfg["belief_mass"] > 0:
        stats["e_mass"] = cfg["belief_mass"] * np.sum(np.sum(A.phi[mask]**2, axis=-1))

    if cfg["model_mass"] > 0:
        stats["e_mass_mod"] = cfg["model_mass"] * np.sum(np.sum(A.phi_model[mask]**2, axis=-1))

    if cfg["curvature_weight"] > 0:
        stats["e_curv"], _ = compute_curvature_energy(A.phi, mask, cfg["curvature_weight"], gen_q)

    if cfg["curvature_weight"] > 0:
        stats["e_curv_mod"], _ = compute_curvature_energy(A.phi_model, mask, cfg["curvature_weight"], gen_p)

    return stats

def log_all_metrics(
    agents,
    step: int,
    params=None,
    q_field: str = "q",                 # unused now
    p_field: str = "p",                 # unused now
    phi_belief_field: str = "phi",     # kept
    phi_model_field: str = "phi_model",
    mask_field: str = "mask",
    n_jobs: int = -1
) -> dict:
    """
    Compute and log all per-agent metrics using natural parameters (η₁, η₂).
    """
    cfg = config if params is None else {**vars(config), **params}
    log_eps = cfg.get("log_eps", 1e-10)

    N    = len(agents)
    K_q  = cfg.get("K_q", 5)
    K_p  = cfg.get("K_p", 5)
    name = cfg.get("group_name", "so3")

    gen_q = get_generators(name, K_q)
    gen_p = get_generators(name, K_p)

    # ───── Precompute fields using η₁, η₂ ─────
    Q_eta_list = [(A.eta1_q_field, A.eta2_q_field) for A in agents]
    P_eta_list = [(A.eta1_p_field, A.eta2_p_field) for A in agents]
    Mask_list  = [np.asarray(getattr(A, mask_field), dtype=bool) for A in agents]
    O_bel      = [A.Omega           for A in agents]
    O_inv      = [A.Omega_inv       for A in agents]
    O_mod      = [A.Omega_model     for A in agents]
    O_mod_inv  = [A.Omega_model_inv for A in agents]

    # ───── Compute metrics for all agents ─────
    results = Parallel(n_jobs=n_jobs, backend="threading", batch_size=1)(
        delayed(compute_agent_metrics)(
            i, agents[i], Q_eta_list, P_eta_list, Mask_list,
            O_bel, O_inv, O_mod, O_mod_inv,
            cfg, (gen_q, gen_p), log_eps
        )
        for i in range(N)
    )

    # ───── Aggregate and log ─────
    metrics = accumulate_and_log_metrics(results, agents, step, Q_eta_list, Mask_list)

    # ───── Print summary ─────
    total_energy = float(metrics["total_energy"])
    print(f"[STEP {step:04d}] Total Energy = {total_energy:.6f}")

    return metrics


def log_max_overlap_fields(agents, step, outdir, eps=config.support_cutoff_eps):
    """
    Logs full diagnostics from the max-overlap pair:
    - η₁/η₂ for q and p
    - belief/model alignment fields
    - KL(q ‖ Φ̃·p), KL(p ‖ Φ·q)
    """
    os.makedirs(outdir, exist_ok=True)

    # ───── Find most overlapping agent pair ─────
    max_overlap, best_pair = 0, None
    for i, A in enumerate(agents):
        mask_i = A.mask > eps
        if not mask_i.any():
            continue
        for nb in A.neighbors:
            j = nb["id"]
            mask_j = agents[j].mask > eps
            overlap = mask_i & mask_j
            if (count := int(overlap.sum())) > max_overlap:
                max_overlap, best_pair = count, (i, j)

    if best_pair is None:
        print(f"[DEBUG] No overlapping pair at step {step}")
        return

    i, j = best_pair
    A = agents[i]
    B = agents[j]


    # ───── Load fields ─────
    eta1_q = A.eta1_q_field
    eta2_q = A.eta2_q_field
    eta1_p = A.eta1_p_field
    eta2_p = A.eta2_p_field
    Phi     = A.Phi_q_to_p
    Phi_tilde = A.Phi_tilde
    mask_i = (A.mask > eps).astype(np.float32)
    H, W, K_q = eta1_q.shape
    K_p = eta1_p.shape[-1]

    # ───── KL fields via natural morphism projection ─────
    kl_qp = compute_kl_projected_field_natural(
        eta1_src = eta1_q,
        eta2_src = eta2_q,
        eta1_tgt = eta1_p,
        eta2_tgt = eta2_p,
        morphism = Phi_tilde,
        mask = A.mask,
        direction = "p_to_q"
    )

    kl_pq = compute_kl_projected_field_natural(
        eta1_src = eta1_p,
        eta2_src = eta2_p,
        eta1_tgt = eta1_q,
        eta2_tgt = eta2_q,
        morphism = Phi,
        mask = A.mask,
        direction = "q_to_p"
    )

    # ───── Alignment fields (natural param version) ─────
    belief_align = compute_alignment_field_general(agents, i, field_type="belief")
    model_align  = compute_alignment_field_general(agents, i, field_type="model")

    # ───── Convert to μ, Σ for optional visual inspection ─────
    mu_q, sigma_q = natural_to_mu_sigma_batch(eta1_q, eta2_q)
    mu_p, sigma_p = natural_to_mu_sigma_batch(eta1_p, eta2_p)
    sigma_q = sanitize_sigma(sigma_q)
    sigma_p = sanitize_sigma(sigma_p)

    # ───── Save output ─────
    fname = os.path.join(outdir, f"step{step:05d}_pair_{i}_{j}.npz")
    np.savez_compressed(
        fname,
        agent_i          = i,
        agent_j          = j,
        overlap          = max_overlap,
        mask_i           = mask_i,
        eta1_q           = eta1_q,
        eta2_q           = eta2_q,
        eta1_p           = eta1_p,
        eta2_p           = eta2_p,
        mu_q             = mu_q,
        sigma_q          = sigma_q,
        mu_p             = mu_p,
        sigma_p          = sigma_p,
        kl_self          = kl_qp,
        kl_feedback      = kl_pq,
        belief_alignment = belief_align,
        model_alignment  = model_align,
        phi              = A.phi,
        phi_model        = A.phi_model,
    )


def full_field_logger(agents, step: int, outdir: str):
    """
    Save one .npz per step containing per-agent fields and diagnostics:
      - eta1_q, eta2_q, phi
      - eta1_p, eta2_p, phi_model
      - belief_align, model_align
      - kl_self, kl_feedback
      - curvature tensors
      - bundle morphisms Φ, Φ̃
    """
   

    cfg   = vars(config)
    K_q   = cfg["K_q"]
    K_p   = cfg["K_p"]
    gens_q = get_generators(cfg["group_name"], K_q)
    gens_p = get_generators(cfg["group_name"], K_p)
    dx     = cfg.get("dx", 1.0)

    N = len(agents)
    H, W = agents[0].eta1_q_field.shape[:2]

    # Allocate output arrays
    eta1_q = np.zeros((N, H, W, K_q), dtype=np.float32)
    eta2_q = np.zeros((N, H, W, K_q, K_q), dtype=np.float32)
    phi    = np.zeros((N, H, W, agents[0].phi.shape[-1]), dtype=np.float32)

    eta1_p = np.zeros((N, H, W, K_p), dtype=np.float32)
    eta2_p = np.zeros((N, H, W, K_p, K_p), dtype=np.float32)
    phi_model = np.zeros((N, H, W, agents[0].phi_model.shape[-1]), dtype=np.float32)

    belief_align      = np.zeros((N, H, W), dtype=np.float32)
    model_align       = np.zeros((N, H, W), dtype=np.float32)
    kl_self_field     = np.zeros((N, H, W), dtype=np.float32)
    kl_feedback_field = np.zeros((N, H, W), dtype=np.float32)

    curv_tensor       = np.zeros((N, H, W, K_q, K_q), dtype=np.float32)
    curv_model_tensor = np.zeros((N, H, W, K_p, K_p), dtype=np.float32)

    phi_q_to_p_stack = []
    phi_p_to_q_stack = []

    for idx, A in enumerate(agents):
        # Store natural parameters and Lie fields
        eta1_q[idx] = A.eta1_q_field
        eta2_q[idx] = A.eta2_q_field
        phi[idx]    = A.phi

        eta1_p[idx] = A.eta1_p_field
        eta2_p[idx] = A.eta2_p_field
        phi_model[idx] = A.phi_model

        # Compute alignment fields
        belief_align[idx] = compute_alignment_field_general(agents, idx, field_type="belief")
        model_align[idx]  = compute_alignment_field_general(agents, idx, field_type="model")

        # Compute KL divergences via bundle morphisms
        # Self energy: D_KL(q_i || Φ̃ p_i)
        kl_qp = compute_kl_projected_field_natural(agent=A, direction="p_to_q")
        kl_pq = compute_kl_projected_field_natural(agent=A, direction="q_to_p")



        # Compute curvature tensors
        curv_tensor[idx]       = compute_field_strength(A.phi, generators=gens_q, dx=dx)["xy"]
        curv_model_tensor[idx] = compute_field_strength(A.phi_model, generators=gens_p, dx=dx)["xy"]

        # Append morphisms
        phi_q_to_p_stack.append(A.bundle_morphism_q_to_p)
        phi_p_to_q_stack.append(A.bundle_morphism_p_to_q)

    # Stack morphism arrays
    phi_q_to_p_stack = np.stack(phi_q_to_p_stack, axis=0)
    phi_p_to_q_stack = np.stack(phi_p_to_q_stack, axis=0)

    # Save to disk
    os.makedirs(outdir, exist_ok=True)
    fname = Path(outdir) / f"step{step:05d}.npz"
    np.savez_compressed(
        fname,
        eta1_q=eta1_q,
        eta2_q=eta2_q,
        phi=phi,
        eta1_p=eta1_p,
        eta2_p=eta2_p,
        phi_model=phi_model,
        belief_align=belief_align,
        model_align=model_align,
        kl_self=kl_self_field,
        kl_feedback=kl_feedback_field,
        curv_tensor=curv_tensor,
        curv_model_tensor=curv_model_tensor,
        phi_q_to_p=phi_q_to_p_stack,
        phi_p_to_q=phi_p_to_q_stack,
    )
    print(f"[DUMP] step={step} → {fname}")



