import numpy as np
import config

from generalized_math_utils import sanitize_q
from get_generators import get_generators
from transport_operator import compute_inter_agent_omega
from generalized_omega import batch_apply_omega, repair_if_forgotten_batch


def compute_self_gradient(agent_i, dist_field_q: str, dist_field_p: str, mask_field: str, params: dict) -> np.ndarray:
    """
    Compute ∇_{q_i} [ α · D_KL(q_i || p_i) ].
    """
    α = params.get("alpha", config.alpha)
    log_eps = params.get("log_eps", config.log_eps)
    support_eps = params.get("support_cutoff_eps", config.support_cutoff_eps)

    q = getattr(agent_i, dist_field_q)
    p = getattr(agent_i, dist_field_p)
    mask = getattr(agent_i, mask_field)

    grad = np.zeros_like(q)
    support = mask > support_eps
    if α > 0 and np.any(support):
        q_s = sanitize_q(q[support], eps=log_eps)
        p_s = sanitize_q(p[support], eps=log_eps)
        # ∂/∂q [D_KL(q||p)] = log(q/p) + 1
        grad_support = α * (np.log(q_s / p_s) + 1.0)
        grad[support] = grad_support
    return grad


def compute_alignment_gradient(agent_i, agents: list, dist_field: str, phi_field: str, params: dict) -> np.ndarray:
    """
    Compute ∇_{q_i} Σ_j β·D_KL(q_i || Ω_{ij} q_j), reusing cached exp(phi).
    """
    β         = params.get("beta",         config.beta)
    overlap_eps = params.get("overlap_eps", config.support_cutoff_eps)
    log_eps   = params.get("log_eps",      config.log_eps)

    q_i   = getattr(agent_i, dist_field)
    mask_i = agent_i.mask > overlap_eps
    grad  = np.zeros_like(q_i)
    if β <= 0 or not mask_i.any():
        return grad

    # Flatten once
    flat_qi   = q_i.reshape(-1, q_i.shape[-1])
    flat_grad = grad.reshape(-1, grad.shape[-1])

    # Pull cached exponentials (shape: [S, K, K])
    exp_phi_i     = agent_i._exp_phi
    exp_neg_phi_i = agent_i._exp_neg_phi

    for nb in agent_i.neighbors:
        j       = nb["id"]
        agent_j = agents[j]

        # overlap indices
        overlap = mask_i & (agent_j.mask > overlap_eps)
        idxs    = np.flatnonzero(overlap)
        if idxs.size == 0:
            continue

        # gather flat patches
        qi_vals = flat_qi[idxs]                                 # (M, K)
        qj_vals = agent_j.q.reshape(-1, q_i.shape[-1])[idxs]    # (M, K)

        # build Ω_ij = exp(phi_i) @ exp(-phi_j)
        Oi      = exp_phi_i[idxs]           # (M, K, K)
        Oj_inv  = agent_j._exp_neg_phi[idxs] # (M, K, K)
        Omegas  = np.einsum("mab,mbc->mac", Oi, Oj_inv)

        # rotate neighbor’s q and sanitize
        qj_rot  = batch_apply_omega(qj_vals, Omegas)
        qj_rot  = sanitize_q(repair_if_forgotten_batch(qj_rot, eps=log_eps), eps=log_eps)

        # gradient ∂/∂q D_KL(q||r) = log(q/r)+1
        qi_s    = sanitize_q(qi_vals, eps=log_eps)
        delta   = (np.log(qi_s / qj_rot) + 1.0)

        # accumulate weighted gradient
        flat_grad[idxs] += (β / idxs.size) * delta

    return flat_grad.reshape(*grad.shape)



def compute_beliefs_gradient(agent_i, agents: list, params: dict) -> np.ndarray:
    """Combine self and alignment gradients for q."""
    return (
        compute_self_gradient(agent_i, 'q', 'p', 'mask', params)
        + compute_alignment_gradient(agent_i, agents, 'q', 'phi', params)
    )


def compute_models_gradient(agent_i, agents: list, params: dict) -> np.ndarray:
    """Combine self, model-alignment, and model-feedback gradients for p."""
    # Self-gradient: ∇_p [α·D_KL(q||p)] = -α·q/p
    α         = params.get('alpha', config.alpha)
    log_eps   = params.get('log_eps', config.log_eps)
    support_eps = params.get('support_cutoff_eps', config.support_cutoff_eps)

    q = sanitize_q(agent_i.q, eps=log_eps)
    p = getattr(agent_i, 'p')
    mask = agent_i.mask > support_eps

    grad = np.zeros_like(p)
    if α > 0 and np.any(mask):
        q_s = q[mask]
        p_s = sanitize_q(p[mask], eps=log_eps)
        grad_self = -α * (q_s / p_s)
        grad[mask] = grad_self

    # Alignment term for p
    align = compute_alignment_gradient(agent_i, agents, 'p', 'phi_model', params)
    grad += align

    # ‹‹ added ›› Model-feedback: ∇_p [model_feedback_weight·D_KL(p||q)] = mf * (log(p/q) + 1)
    mf = params.get('model_feedback_weight', config.model_feedback_weight)
    if mf > 0 and np.any(mask):
        p_s = sanitize_q(p[mask], eps=log_eps)
        q_s = sanitize_q(q[mask], eps=log_eps)
        grad_fb = mf * (np.log(p_s / q_s) + 1)
        grad[mask] += grad_fb

    return grad



def compute_phi_alignment_gradient(agent_i, agents: list, params: dict) -> np.ndarray:
    """
    ∇_{φ} [ β·D_KL(q_i||Ω_{ij} q_j)
           + γ·Δφ
           + gauge_weight·φ²
           + φ_phi_tilde_coupling·(φ - φ_model)² ]
    """
    # Parameters
    β           = params.get("beta", config.beta)
    overlap_eps = params.get("overlap_eps", config.support_cutoff_eps)
    log_eps     = params.get("log_eps", config.log_eps)

    # Fields
    phi_i   = agent_i.phi             # shape: (*grid_shape, d)
    phi_m   = agent_i.phi_model       # same shape as phi_i
    mask_i  = agent_i.mask > overlap_eps

    # Quick exit
    grad = np.zeros_like(phi_i)
    if β <= 0 or not mask_i.any():
        return grad

    # Use pre-flattened distributions and grid info
    flat_q   = agent_i.q_flat         # shape: (N_pixels, K)
    N, K     = flat_q.shape
    d        = phi_i.shape[-1]
    flat_grad = grad.reshape(N, d)

    exp_phi_i     = agent_i._exp_phi          # (N, K, K)
    exp_neg_phi_i = agent_i._exp_neg_phi      # (N, K, K)
    Gs            = get_generators(config.group_name, K)  # (d, K, K)

    # Alignment loop over neighbors
    for nb in agent_i.neighbors:
        agent_j = agents[nb["id"]]
        mask_j  = agent_j.mask > overlap_eps
        ov      = mask_i & mask_j
        idxs    = np.flatnonzero(ov)
        if idxs.size == 0:
            continue

        qi_vals = flat_q[idxs]                   # (M, K)
        qj_vals = sanitize_q(
            agent_j.q_flat[idxs], eps=log_eps
        )                                         # (M, K)

        Oi     = exp_phi_i[idxs]                 # (M, K, K)
        Oj_inv = exp_neg_phi_i[idxs]             # (M, K, K)
        Ω      = np.einsum("mab,mbc->mac", Oi, Oj_inv)

        qj_rot = batch_apply_omega(qj_vals, Ω)
        qj_rot = sanitize_q(
            repair_if_forgotten_batch(qj_rot, eps=log_eps),
            eps=log_eps
        )                                         # (M, K)

        diff = qi_vals - qj_rot                  # (M, K)

        H      = np.einsum("aic,mcj->maij", Gs, Oi)     # (M, d, K, K)
        dΩ     = np.einsum("maij,mjk->maik", H, Oj_inv) # (M, d, K, K)
        dΩp    = np.einsum("maik,mk->mai", dΩ, qj_vals) # (M, d, K)
        grad_pixels = np.einsum("mai,mi->ma", dΩp, diff) # (M, d)

        # Add averaged contribution for this neighbor
        flat_grad[idxs] += (β / idxs.size) * grad_pixels.mean(axis=0)

    # Reshape back to grid shape
    grad = flat_grad.reshape(*phi_i.shape)

    # Laplacian term: ∇φ [γ·Δφ] = γ·laplacian_field(phi)
    γ = params.get("gamma", config.gamma)
    if γ > 0:
        from generalized_math_utils import laplacian_field
        grad += γ * laplacian_field(phi_i)

    # Mass term: ∇φ [gauge_weight·φ²] = 2·gauge_weight·φ
    gw = params.get("gauge_weight", config.gauge_weight)
    if gw > 0:
        grad += 2 * gw * phi_i

    # φ–φ_model coupling: ∇φ [κ (φ−φ_model)²] = 2·κ·(phi_i − phi_m)
    κ = params.get("phi_phi_tilde_coupling", config.phi_phi_tilde_coupling)
    if κ > 0:
        grad += 2 * κ * (phi_i - phi_m)

    return grad


def compute_phi_model_update(agent_i, agents: list, params: dict) -> np.ndarray:
    """
    ∇_{φ_model} [ βm·D_KL(p_i||Ω̃_{ij} p_j)
                   + γm·Δφ_model
                   + model_mass_weight·φ_model²
                   + φ_phi_tilde_coupling·(φ_belief - φ_model)² ]
    """
    βm          = params.get("model_align_weight",    config.model_align_weight)
    overlap_eps = params.get("overlap_eps",           config.support_cutoff_eps)
    log_eps     = params.get("log_eps",               config.log_eps)

    φm_i   = agent_i.phi_model    # (*grid, d)
    φ_i    = agent_i.phi          # (*grid, d)
    mask_i = agent_i.mask > overlap_eps

    grad = np.zeros_like(φm_i)
    if βm <= 0 or not mask_i.any():
        return grad

    flat_p    = agent_i.p_flat    # (N, K)
    N, K      = flat_p.shape
    d         = φm_i.shape[-1]
    flat_grad = grad.reshape(N, d)

    Oi_full     = agent_i._exp_phi_model      # (N, K, K)
    Oi_inv_full = agent_i._exp_neg_phi_model  # (N, K, K)
    Gs          = get_generators(config.group_name, K)  # (d, K, K)

    for nb in agent_i.neighbors:
        j       = nb["id"]
        agent_j = agents[j]
        ov      = mask_i & (agent_j.mask > overlap_eps)
        idxs    = np.flatnonzero(ov)
        if idxs.size == 0:
            continue

        pi_vals = flat_p[idxs]                                 # (M, K)
        pj_vals = sanitize_q(agent_j.p_flat[idxs], eps=log_eps)# (M, K)

        Oi    = Oi_full[idxs]                                  # (M, K, K)
        Oj_inv= Oi_inv_full[idxs]                              # (M, K, K)
        Ω     = np.einsum("mab,mbc->mac", Oi, Oj_inv)           # (M, K, K)

        pj_rot = batch_apply_omega(pj_vals, Ω)
        pj_rot = sanitize_q(repair_if_forgotten_batch(pj_rot, eps=log_eps),
                             eps=log_eps)                     # (M, K)

        diff = pi_vals - pj_rot                                 # (M, K)

        H           = np.einsum("aic,mcj->maij", Gs, Oi)        # (M, d, K, K)
        dΩ          = np.einsum("maij,mjk->maik", H, Oj_inv)    # (M, d, K, K)
        dΩp         = np.einsum("maik,mk->mai", dΩ, pj_vals)    # (M, d, K)
        grad_pixels = np.einsum("mai,mi->ma", dΩp, diff)        # (M, d)

        flat_grad[idxs] += -(βm / idxs.size) * grad_pixels.mean(axis=0)

    grad = flat_grad.reshape(*φm_i.shape)

    γm = params.get("model_gauge_weight", config.model_gauge_weight)
    if γm > 0:
        from generalized_math_utils import laplacian_field
        grad += γm * laplacian_field(φm_i)

    mmw = params.get("model_mass_weight", config.model_mass_weight)
    if mmw > 0:
        grad += 2 * mmw * φm_i

    κ = params.get("phi_phi_tilde_coupling", config.phi_phi_tilde_coupling)
    if κ > 0:
        grad += -2 * κ * (φ_i - φm_i)

    return grad



