# run_lhs_sweep.py (corrected and including base-eta parameters)

import os
import numpy as np
import pickle
from scipy.stats import qmc
from generalized_simulation import run_simulation
import argparse


DEFAULT_SAMPLES = 100  # Default number of LHS samples

# --- Parameters required for proper simulation ---
base_params = {
    "group_name": "sl2r",
    "K": 21,
    "N": 10,
    "L": 25,
    "steps": 125,
    # Enable debug prints in update routines
    "debug": True,
}


def lhs_sample(param_ranges, n_samples):
    """Generate Latin Hypercube Samples for given parameter ranges."""
    sampler = qmc.LatinHypercube(d=len(param_ranges))
    sample = sampler.random(n=n_samples)
    l_bounds = np.array([lo for lo, hi in param_ranges])
    u_bounds = np.array([hi for lo, hi in param_ranges])
    return qmc.scale(sample, l_bounds, u_bounds)


def run_lhs_sweep(n_samples=DEFAULT_SAMPLES, output_dir="lhs_results"):
    os.makedirs(output_dir, exist_ok=True)

    # Include coupling weights AND base learning rates in the sweep
    sweep_params = {
        "alpha":                (0,    500),
        "beta":                 (0,    500),
        "gamma":                (0,    500),
        "gauge_weight":         (0,    500),
        "model_align_weight":   (0,    500),
        "model_gauge_weight":   (0,    500),
        "model_mass_weight":    (0,    500),
        "model_feedback_weight":(0,    500),
        "phi_phi_tilde_coupling":(0,   500),
        "phi_init":             (0.1,    1.0),
        "e_belif":              (-10,    10),
        "e_model":              (-10,    10),
        # Base learning-rate ranges
        #"eta_base_q":           (1e-8,   1e-2),
        #"eta_base_p":           (1e-8,   1e-2),
        #"eta_base_phi":         (1e-8,   1e-2),
        #"eta_base_phi_model":   (1e-8,   1e-2),
    }

    param_names = list(sweep_params)
    ranges = [sweep_params[k] for k in param_names]
    samples = lhs_sample(ranges, n_samples)

    # Save sweep specification
    sweep_spec = {
        "param_names": param_names,
        "ranges": sweep_params,
        "samples": samples.tolist(),
    }
    with open(os.path.join(output_dir, "sweep_spec.pkl"), "wb") as f:
        pickle.dump(sweep_spec, f)

    # Run each sample independently
    for i, row in enumerate(samples):
        sampled_params = dict(zip(param_names, row))
        
                # cast these parameters to integers
        int_params = ["alpha", "beta", "gamma", "gauge_weight", "model_align_weight", 
                      "model_gauge_weight", "model_mass_weight", "model_feedback_weight","phi_phi_tilde_coupling"  ]
        for k in int_params:
            if k in sampled_params:
                sampled_params[k] = int(round(sampled_params[k]))
        
        params = dict(base_params)
        params.update(sampled_params)
        print(f"\n[SAMPLE {i}] params = {params}")

        subdir = os.path.join(output_dir, f"run_{i}")
        os.makedirs(subdir, exist_ok=True)

        agents, metrics = run_simulation(
            outdir=subdir,
            resume=False,
            log_metrics=True,
            num_cores=4,
            params=params,
        )

        # Archive results
        with open(os.path.join(subdir, "final_agents.pkl"), "wb") as f:
            pickle.dump(agents, f)
        with open(os.path.join(subdir, "final_metrics.pkl"), "wb") as f:
            pickle.dump(metrics, f)
        with open(os.path.join(subdir, "params.pkl"), "wb") as f:
            pickle.dump(params, f)

    print(f"[DONE] LHS sweep complete: {n_samples} samples → {output_dir}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description=f"Run Latin Hypercube parameter sweep (default {DEFAULT_SAMPLES} samples)."
    )
    parser.add_argument(
        "-n", "--n_samples",
        type=int,
        default=DEFAULT_SAMPLES,
        help=f"Number of LHS samples (default = {DEFAULT_SAMPLES})",
    )
    args = parser.parse_args()
    run_lhs_sweep(n_samples=args.n_samples)
