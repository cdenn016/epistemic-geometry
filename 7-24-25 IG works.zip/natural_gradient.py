# -*- coding: utf-8 -*-
"""
Created on Wed Jul 23 09:23:50 2025

@author: chris and christine
"""
import numpy as np
import config
from joblib import Parallel, delayed
from numerical_utils import safe_inv
from get_generators import get_generators
from numerical_utils import sanitize_sigma
from generalized_omega import safe_bch_exact


def cache_fisher_inverse_morphisms(agent_i, eps=1e-8):
    agent_i.fisher_inv_phi_model = compute_inverse_fisher_field(
        agent_i.bundle_morphism_q_to_p,
        agent_i.generators_q_to_p,
        eps=eps
    )
    agent_i.fisher_inv_phi = compute_inverse_fisher_field(
        agent_i.bundle_morphism_p_to_q,
        agent_i.generators_p_to_q,
        eps=eps
    )

def compute_lie_metric(generators: np.ndarray):
    """
    Compute inner product matrix G_{ab} = Tr(G_aᵀ G_b) and its inverse.

    Args:
        generators: (d, K, K) basis of Lie algebra

    Returns:
        G: (d, d) inner product matrix
        G_inv: (d, d) inverse (with fallback)
    """
    d = generators.shape[0]
    G = np.einsum("aij,bij->ab", generators, generators)
    G = 0.5 * (G + G.T)  # symmetrize

    G_inv = safe_inv(G, eps=getattr(config, "eps", 1e-6))


    return G, G_inv

def compute_inverse_fisher_field(agent, generators, field="phi"):
    """
    Computes per-point inverse Fisher metric G^{-1}_{ab}(x) in the Lie algebra.
    Skips computation in regions where agent.mask < support_cutoff_eps.

    Args:
        agent: agent object with sigma_q_field or sigma_p_field
        generators: (d, K, K) Lie algebra basis
        field: "phi" or "phi_model"

    Returns:
        G_inv_field: (H, W, d, d)
    """
    sigma_field = agent.sigma_q_field if field == "phi" else agent.sigma_p_field
    mask = agent.mask > getattr(config, "support_cutoff_eps", 1e-4)

    sigma_field = sanitize_sigma(sigma_field, eps=config.eps, debug=config.debug_sanitize_sigma)

    H, W, K, _ = sigma_field.shape
    d = generators.shape[0]
    eye_K = np.eye(K)
    eye_d = np.eye(d)

    G_inv_field = np.zeros((H, W, d, d), dtype=sigma_field.dtype)

    flat_sigma = sigma_field.reshape(-1, K, K)
    flat_mask = mask.reshape(-1)
    N = flat_sigma.shape[0]

    valid_indices = np.flatnonzero(flat_mask)
    sigma_valid = flat_sigma[valid_indices]  # (M, K, K)

    # Step 1: invert Σ⁻¹ (with fallback)
    sigma_inv = np.empty_like(sigma_valid)
    for i in range(sigma_valid.shape[0]):
        try:
            sigma_inv[i] = np.linalg.inv(sigma_valid[i])
        except np.linalg.LinAlgError:
            sigma_inv[i] = eye_K
            if config.debug:
                print(f"[WARN] Σ⁻¹ failed at valid index {i}")

    # Step 2: compute G_ab[i, a, b] = Tr[Σ⁻¹ G^a Σ⁻¹ G^b]
    G_ab = np.zeros((sigma_inv.shape[0], d, d), dtype=sigma_field.dtype)

    for a in range(d):
        for b in range(d):
            G_a = np.broadcast_to(generators[a], sigma_inv.shape)
            G_b = np.broadcast_to(generators[b], sigma_inv.shape)


            G_ab[..., a, b] = np.einsum("...ij,...jk,...kl,...il->...", sigma_inv, G_a, sigma_inv, G_b)

    # Step 3: symmetrize and invert G_ab
    flat_G_inv = G_inv_field.reshape(-1, d, d)
    for i, flat_idx in enumerate(valid_indices):
        G_sym = 0.5 * (G_ab[i] + G_ab[i].T)
        try:
            cond = np.linalg.cond(G_sym)
            if not np.isfinite(cond) or cond > config.max_fisher_condition:
                raise np.linalg.LinAlgError
            flat_G_inv[flat_idx] = np.linalg.inv(G_sym + config.eps * eye_d)
        except np.linalg.LinAlgError:
            flat_G_inv[flat_idx] = eye_d
            if config.debug:
                print(f"[WARN] G_ab⁻¹ fallback at index {flat_idx}")

    return G_inv_field


def compute_inverse_fisher_morphism_field(agent, generators, direction="q_to_p", eps=1e-8):
    """
    Return the rectangular Lie-algebra-projected inverse Fisher metric (H, W, d, d)
    for Φ or Φ̃ depending on direction.
    """
    assert direction in {"q_to_p", "p_to_q"}

    if direction == "q_to_p":
        Phi        = agent.bundle_morphism_q_to_p
        mu_q       = agent.mu_q_field
        sigma_q    = agent.sigma_q_field
        sigma_p    = agent.sigma_p_field
    else:
        Phi        = agent.bundle_morphism_p_to_q
        mu_q       = agent.mu_p_field
        sigma_q    = agent.sigma_p_field
        sigma_p    = agent.sigma_q_field

# Use passed-in generators
    _, F_inv = compute_fisher_metric_rectangular(
        Phi=Phi,
        mu_q=mu_q,
        sigma_q=sigma_q,
        sigma_p=sigma_p,
        generators=generators,
        eps=eps,
        return_inverse=True,
        )

    return F_inv





def apply_lie_natural_gradient(phi, grad_phi, G_inv=None, use_dexpinv=False):
    """
    Apply Lie-natural gradient update to φ using optional inverse Fisher metric
    and optional Lie group correction via dexp⁻¹.

    Args:
        phi         : (H, W, d) Lie algebra field
        grad_phi    : (H, W, d) raw Euclidean gradient
        G_inv       : (d,d) or (H,W,d,d) inverse Fisher metric or None
        use_dexpinv : NOT SUPPORTED HERE — caller must apply dexpinv externally if needed

    Returns:
        nat_grad : (H, W, d) Lie-natural gradient
    """
    assert phi.shape == grad_phi.shape, f"Shape mismatch: phi {phi.shape} vs grad {grad_phi.shape}"

    if use_dexpinv:
        raise NotImplementedError(
            "[ERROR] `use_dexpinv=True` requires calling dexpinv_operator_covariance(...) externally."
        )

    if G_inv is None:
        return grad_phi

    if G_inv.ndim == 2:
        return np.einsum("ab,...b->...a", G_inv, grad_phi)
    elif G_inv.ndim == 4:
        return np.einsum("...ab,...b->...a", G_inv, grad_phi)
    else:
        raise ValueError(f"G_inv must be (d,d) or (H,W,d,d), got {G_inv.shape}")

def apply_natural_gradient_batch(mu_field, sigma_field, grad_mu_field, grad_sigma_field, mask=None):
    """
    Apply natural gradient descent using local Fisher metric at each spatial point.
    Handles fallbacks and invalid regions with explicit masking and logging.

    Fisher inverse:
        G_mu^-1 = Σ
        G_Sigma^-1 = 2 × (Σ ⊗ Σ)

    Returns:
        delta_mu:    (H, W, K)
        delta_sigma: (H, W, K, K)
    """
    eps = getattr(config, "eps", 1e-8)
    debug = getattr(config, "debug_gradients", False)
    fallback_clip_value = getattr(config, "sanitize_fallback_value", 1.0)
    clip_threshold = getattr(config, "gradient_clip", 1e5)
    clip_mu = getattr(config, "clip_mu", True)
    clip_sigma = getattr(config, "clip_sigma", True)

    H, W, K = mu_field.shape
    N = H * W

    mu_flat = mu_field.reshape(N, K)
    sigma_flat = sigma_field.reshape(N, K, K)
    grad_mu_flat = grad_mu_field.reshape(N, K)
    grad_sigma_flat = grad_sigma_field.reshape(N, K, K)

    delta_mu = np.zeros_like(mu_flat)
    delta_sigma = np.zeros_like(sigma_flat)

    eye = np.eye(K)

    flat_mask = mask.reshape(N) if mask is not None else np.ones(N, dtype=bool)

    for n in range(N):
        if not flat_mask[n]:
            continue  # skip masked-out regions

        sigma_n = 0.5 * (sigma_flat[n] + sigma_flat[n].T) + eps * eye
        grad_mu_n = grad_mu_flat[n]
        grad_sigma_n = grad_sigma_flat[n]

        try:
            sigma_inv = safe_inv(sigma_n, eps=config.eps)
        except np.linalg.LinAlgError:
            sigma_inv = eye * fallback_clip_value
            if debug:
                print(f"[WARN] NG Σ⁻¹ fallback at index {n}")

        # Compute natural gradient updates
        delta_mu_n = -sigma_n @ grad_mu_n
        delta_sigma_n = -2.0 * sigma_n @ grad_sigma_n @ sigma_n

        # Clip large gradient norms if enabled
        if clip_mu:
            norm_mu = np.linalg.norm(delta_mu_n)
            if norm_mu > clip_threshold:
                delta_mu_n *= clip_threshold / norm_mu
                if debug:
                    print(f"[CLIP] ∇μ norm {norm_mu:.2e} clipped at index {n}")

        if clip_sigma:
            norm_sigma = np.linalg.norm(delta_sigma_n)
            if norm_sigma > clip_threshold:
                delta_sigma_n *= clip_threshold / norm_sigma
                if debug:
                    print(f"[CLIP] ∇Σ norm {norm_sigma:.2e} clipped at index {n}")

        delta_mu[n] = np.nan_to_num(delta_mu_n)
        delta_sigma[n] = np.nan_to_num(delta_sigma_n)

    return (
        delta_mu.reshape(H, W, K),
        delta_sigma.reshape(H, W, K, K),
    )


import numpy as np

import numpy as np

import numpy as np
from config import eps as default_eps

def dexpinv_operator_morphismunsafe(Phi, grad_Phi, generators, fisher_inv_field=None, eps=1e-8):
    """
    Project Euclidean gradient ∂L/∂Φ ∈ R^{K_p × K_q} to Lie algebra coordinates 
    via inner product Tr[ ∂L/∂Φ · G^a ] for rectangular generators.
    
    Args:
        Phi               : (H, W, K_p, K_q) morphism field Φ : B_q → B_p
        grad_Phi          : (H, W, K_p, K_q) Euclidean gradient ∂L/∂Φ
        generators        : (d, K_p, K_q) rectangular generator basis
        fisher_inv_field  : (H, W, d, d) optional inverse Fisher metric
        eps               : numerical stabilizer

    Returns:
        grad_coords       : (H, W, d) gradient in Lie algebra coordinates
    """
    H, W, K_p, K_q = grad_Phi.shape
    d = generators.shape[0]
    grad_coords = np.empty((H, W, d), dtype=grad_Phi.dtype)

    # Project gradient onto each generator direction
    for a in range(d):
        G_a = generators[a]  # shape (K_q, K_p)
        # Now perform the matrix multiplication:
        GT = G_a.T
        #print(f"G_a^T.shape: {GT.shape}")
        grad_coords[..., a] = np.einsum("...ij,ij->...", grad_Phi, G_a)
        
    # Apply inverse Fisher metric if provided
    if fisher_inv_field is not None:
        # fisher_inv_field: (H, W, d, d), grad_coords: (H, W, d)
        grad_coords = np.einsum("...ab,...b->...a", fisher_inv_field, grad_coords)  # (H,W,d,d) × (H,W,d)


    return grad_coords

def dexpinv_operator_morphism(Phi, grad_Phi, generators, fisher_inv_field=None, eps=1e-8):
    """
    Project Euclidean gradient ∂L/∂Φ ∈ R^{K_p × K_q} to Lie algebra coordinates 
    via inner product Tr[ ∂L/∂Φ · G^a ] for rectangular generators.

    Args:
        Phi               : (H, W, K_p, K_q) morphism field Φ : B_q → B_p
        grad_Phi          : (H, W, K_p, K_q) Euclidean gradient ∂L/∂Φ
        generators        : (d, K_p, K_q) rectangular generator basis
        fisher_inv_field  : (H, W, d, d) optional inverse Fisher metric
        eps               : numerical stabilizer

    Returns:
        grad_coords       : (H, W, d) gradient in Lie algebra coordinates
    """
    import numpy as np

    H, W, K_p, K_q = grad_Phi.shape
    d = generators.shape[0]

    # Sanity checks
    assert generators.shape == (d, K_p, K_q), f"Expected generators shape ({d},{K_p},{K_q}), got {generators.shape}"
    grad_coords = np.empty((H, W, d), dtype=grad_Phi.dtype)

    # Step 1: Project Euclidean gradient onto Lie generators
    for a in range(d):
        G_a = generators[a]
        grad_coords[..., a] = np.einsum("...ij,ij->...", grad_Phi, G_a)

    # Step 2: Apply inverse Fisher metric (optional)
    if fisher_inv_field is not None:
        # Safety check
        if fisher_inv_field.shape != (H, W, d, d):
            raise ValueError(
                f"Fisher shape mismatch: expected ({H},{W},{d},{d}), got {fisher_inv_field.shape}"
            )

        # Sanitize Fisher inverse in case it's degenerate
        
        fisher_inv_field = sanitize_sigma(fisher_inv_field, eps=eps)

        # Contract: (..., d, d) × (..., d) → (..., d)
        grad_coords = np.einsum("...ab,...b->...a", fisher_inv_field, grad_coords)

    # Step 3: Clamp extreme values (optional, diagnostic)
    if getattr(config, "debug_gradients", False):
        max_norm = np.linalg.norm(grad_coords, axis=-1).max()
        print(f"[DEBUG] Natural morphism grad max-norm: {max_norm:.2e}")

    return np.nan_to_num(grad_coords)



def compute_fisher_metric_rectangular(Phi, mu_q, sigma_q, sigma_p, generators, eps=1e-8, return_inverse=True):
    """
    Compute the true Fisher metric for Φ : B_q → B_p using full μ and Σ structure.

    Args:
        Phi         : (H, W, K_p, K_q) morphism field
        mu_q        : (H, W, K_q)
        sigma_q     : (H, W, K_q, K_q)
        sigma_p     : (H, W, K_p, K_p)
        generators  : (d, K_p, K_q) rectangular generators
        eps         : stabilizer for inverse
        return_inverse : bool

    Returns:
        F           : (H, W, d, d) Fisher metric
        F_inv       : (H, W, d, d) inverse (if return_inverse)
    """
   
    H, W, K_p, K_q = Phi.shape
    d = generators.shape[0]
    F = np.zeros((H, W, d, d), dtype=Phi.dtype)

    # Sanitize inputs
    sigma_q = sanitize_sigma(sigma_q, eps=eps)
    sigma_p = sanitize_sigma(sigma_p, eps=eps)
    Sigma_p_inv = safe_inv(sigma_p, eps=eps)

    for a in range(d):
        G_a = generators[a]
        dmu_a = np.einsum("ij,...j->...i", G_a, mu_q)

        term1 = np.einsum("ij,...jk,...lk->...il", G_a, sigma_q, Phi)
        term2 = np.matmul(np.matmul(Phi, sigma_q), G_a.T)
        dSigma_a = term1 + term2

        for b in range(d):
            G_b = generators[b]
            dmu_b = np.einsum("ij,...j->...i", G_b, mu_q)

            # μ contribution
            t1 = np.einsum("...i,...ij,...j->...", dmu_a, Sigma_p_inv, dmu_b)

            term1_b = np.einsum("ij,...jk,...lk->...il", G_b, sigma_q, Phi)
            intermediate = np.matmul(Phi, sigma_q)
            term2_b = np.matmul(intermediate, G_b.T)
            dSigma_b = term1_b + term2_b

            tmp = np.einsum("...ik,...kl->...il", Sigma_p_inv, dSigma_b)
            tmp = np.einsum("...ij,...jk->...ik", dSigma_a, tmp)
            t2 = np.einsum("...ii->...", tmp)  # trace

            F[..., a, b] = t1 + 0.5 * t2

    # Sanitize Fisher before inversion
    F = sanitize_sigma(F, eps=eps)

    if return_inverse:
        eye = np.eye(d, dtype=F.dtype)[None, None]
        F_reg = F + eps * eye
        F_inv = safe_inv(F_reg, eps=eps)

        if getattr(config, "debug_fisher", False):
            fro_norm = np.linalg.norm(F, axis=(-2, -1))
            print(f"[DEBUG] Fisher norm min/max: {fro_norm.min():.2e}/{fro_norm.max():.2e}")

        return F, F_inv
    else:
        return F





def dexpinv_operator(phi, delta, generators, order=None, use_exact=None):
    """
    Applies exact inverse of exp pushforward:
        dexpinv(phi, delta) ∈ 𝔤

    Uses:
        bch_exact(exp(φ), exp(δ)) - φ → projected back into 𝔤

    Args:
        phi     : (..., d) current Lie-algebra coords
        delta   : (..., d) Lie-algebra variation
        generators: (d, K, K) basis of Lie algebra

    Returns:
        corrected_delta: (..., d)
    """
    H, W, d = phi.shape
    corrected = np.zeros_like(delta)

    # Matrix form: φ, Δ ∈ 𝔤
    phi_mat   = np.einsum("...a,akl->...kl", phi, generators)
    delta_mat = np.einsum("...a,akl->...kl", delta, generators)

    composed = np.zeros_like(phi_mat)
    for i in range(H):
        for j in range(W):
            A = phi_mat[i, j]
            B = delta_mat[i, j]
            C = safe_bch_exact(A, B)  # full BCH or logm
            composed[i, j] = C - A

    # Project back: δ_corrected^a = Tr[(C - A) · G^a]
    for a in range(d):
        G = generators[a]
        corrected[..., a] = 2.0 * np.einsum("...ij,ij->...", composed, G)

    return corrected


def dexpinv_operator_covariance(phi, delta_sigma, generators, transpose=False):
    """
    Applies exact dexpinv operator to ∂L/∂Σ through transported covariance Ω Σ Ωᵀ.
    Projects gradient back into Lie-algebra coordinates via generator basis.

    Args:
        phi         : (H, W, d)  current φ field
        delta_sigma : (H, W, K, K) ∂KL/∂Σ_transport
        generators  : (d, K, K)
        transpose   : whether to apply dummy transpose (not used in practice)

    Returns:
        corrected_grad: (H, W, d)
    """
    H, W, d = phi.shape
    corrected = np.zeros((H, W, d), dtype=phi.dtype)

    # Construct φ matrix at each (i, j)
    phi_mat = np.einsum("...a,akl->...kl", phi, generators)

    for i in range(H):
        for j in range(W):
            A = phi_mat[i, j]
            dΣ = delta_sigma[i, j]

            # Use exact backprop: log(exp(A) @ exp(dΣ)) - A
            B = safe_bch_exact(A, dΣ)
            C = B - A

            for a in range(d):
                G = generators[a]
                corrected[i, j, a] += 2.0 * np.trace(C @ G)

    if transpose:
        corrected = np.swapaxes(corrected, -1, -1)  # no-op, kept for legacy compat

    return corrected


def compute_fisher_geometry_gradient(agent_i, agents, params, field="phi"):
    """
    Compute ∇_{φ} or ∇_{φ̃} for Fisher geometry preservation:
        ∇‖Gᵢ − Ωᵢⱼ Gⱼ Ωᵢⱼᵀ‖²
    Supports field="phi" (beliefs) or "phi_model" (models).
    """
    if field == "phi":
        phi     = agent_i.phi
        G_field = agent_i.cached_fisher_q
        exp_phi = agent_i._exp_phi
        exp_neg_phi_j_name = "_exp_neg_phi"
        fisher_weight = params.get("fisher_geometry_weight", config.fisher_geometry_weight)
    else:
        phi     = agent_i.phi_model
        G_field = agent_i.cached_fisher_p
        exp_phi = agent_i._exp_phi_model
        exp_neg_phi_j_name = "_exp_neg_phi_model"
        fisher_weight = params.get("fisher_model_geometry_weight", config.fisher_model_geometry_weight)

    if fisher_weight <= 0:
        return np.zeros_like(phi)

    Gs = get_generators(config.group_name, config.K)
    d, K = Gs.shape[0], Gs.shape[1]
    mask_i = agent_i.mask > config.support_cutoff_eps
    if not np.any(mask_i):
        return np.zeros_like(phi)

    grad = np.zeros_like(phi)
    flat_self_mask = mask_i.reshape(-1)

    exp_phi_i = exp_phi.reshape(-1, K, K)

    for nb in agent_i.neighbors:
        agent_j = agents[nb["id"]]
        mask_j = agent_j.mask > config.support_cutoff_eps
        overlap = mask_i & mask_j
        if not np.any(overlap):
            continue

        flat_idxs = overlap.reshape(-1)

        G_i = G_field.reshape(-1, K, K)[flat_idxs]
        G_j = getattr(agent_j, f"cached_fisher_{'q' if field == 'phi' else 'p'}").reshape(-1, K, K)[flat_idxs]
        exp_neg_phi_j = getattr(agent_j, exp_neg_phi_j_name).reshape(-1, K, K)[flat_idxs]

        Omega = np.einsum("mij,mjk->mik", exp_phi_i[flat_idxs], exp_neg_phi_j)
        G_j_rot = np.einsum("mik,mkl,mjl->mij", Omega, G_j, Omega)  # Ω G Ωᵀ
        Delta = G_i - G_j_rot

        for a in range(d):
            Ga = Gs[a]
            dΩ = np.einsum("ij,mjk->mik", Ga, Omega)
            term1 = np.einsum("mik,mkl,mjl->mij", dΩ, G_j, Omega)
            term2 = np.einsum("mik,mkl,mjl->mij", Omega, G_j, dΩ)
            dG_rot = term1 + term2
            dL = 2 * np.einsum("mij,mij->m", Delta, dG_rot)
            grad.reshape(-1, d)[flat_idxs, a] += dL

    grad *= fisher_weight
    grad[~mask_i] = 0.0
    return grad
