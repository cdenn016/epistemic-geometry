# -*- coding: utf-8 -*-
"""
Created on Sun Jul  6 14:42:59 2025

@author: chris and christine
"""
import numpy as np
import config
from joblib import Parallel, delayed
from numerical_utils import safe_inv
from get_generators import get_generators

def compute_kl_gaussian_fields(mu1, sigma1, mu2, sigma2, mask, eps=1e-8):
    """
    Compute KL(𝒩(μ1, Σ1) || 𝒩(μ2, Σ2)) at each spatial point.

    Args:
        mu1, sigma1: (H, W, K), (H, W, K, K) — belief field
        mu2, sigma2: (H, W, K), (H, W, K, K) — target field
        mask       : (H, W) — soft support
        eps        : float — numerical stabilizer

    Returns:
        kl         : (H, W) — KL divergence at each spatial point
    """
    H, W, K = mu1.shape
    kl = np.zeros((H, W), dtype=np.float32)
    I = np.eye(K, dtype=np.float32)

    for i in range(H):
        for j in range(W):
            if mask[i, j] < eps:
                continue

            μ1 = mu1[i, j]
            μ2 = mu2[i, j]
            Σ1 = sigma1[i, j]
            Σ2 = sigma2[i, j]

            # Symmetrize and stabilize
            Σ1 = 0.5 * (Σ1 + Σ1.T) + eps * I
            Σ2 = 0.5 * (Σ2 + Σ2.T) + eps * I

            try:
                Σ2_inv = np.linalg.inv(Σ2)
                trace_term = np.trace(Σ2_inv @ Σ1)
                diff = μ2 - μ1
                mahal_term = np.einsum("i,ij,j", diff, Σ2_inv, diff)

                sign1, logdet1 = np.linalg.slogdet(Σ1)
                sign2, logdet2 = np.linalg.slogdet(Σ2)

                if sign1 <= 0 or sign2 <= 0:
                    raise np.linalg.LinAlgError("Non-positive definite")

                logdet = logdet2 - logdet1
                kl[i, j] = 0.5 * (trace_term + mahal_term - K + logdet)

            except np.linalg.LinAlgError:
                if getattr(config, "debug", False):
                    print(f"[WARN] KL computation failed at ({i},{j}) — assigning ∞")
                kl[i, j] = np.nan if getattr(config, "debug_nan_on_fail", False) else np.inf

    return kl



def compute_fisher_metric_block_diag(sigma_field, mask=None, eps=1e-8):
    """
    Compute Fisher metric G = Σ⁻¹ for a batch of SPD matrices, with optional masking.
    """
    H, W, K, _ = sigma_field.shape
    G = np.zeros_like(sigma_field)
    eye = np.eye(K, dtype=sigma_field.dtype)

    for i in range(H):
        for j in range(W):
            Σ = sigma_field[i, j]
            if mask is not None and not mask[i, j]:
                G[i, j] = np.eye(K)
                continue
            Σ_reg = Σ + eps * eye
            try:
                G[i, j] = np.linalg.inv(Σ_reg)
            except np.linalg.LinAlgError:
                G[i, j] = np.eye(K)  # fallback
    return G



def compute_inverse_fisher_field(agent, generators, field="phi"):
    """
    Computes per-point inverse Fisher metric G^{-1}_{ab}(x) in the Lie algebra.
    Skips computation in regions where agent.mask < support_cutoff_eps.

    Args:
        agent: agent object with sigma_q_field or sigma_p_field
        generators: (d, K, K) Lie algebra basis
        field: "phi" or "phi_model"

    Returns:
        G_inv_field: (H, W, d, d)
    """
    sigma_field = agent.sigma_q_field if field == "phi" else agent.sigma_p_field
    mask = agent.mask > getattr(config, "support_cutoff_eps", 1e-4)

    sigma_field = sanitize_sigma(sigma_field, eps=config.eps, debug=config.debug_sanitize_sigma)

    H, W, K, _ = sigma_field.shape
    d = generators.shape[0]
    eye_K = np.eye(K)
    eye_d = np.eye(d)

    G_inv_field = np.zeros((H, W, d, d), dtype=sigma_field.dtype)

    flat_sigma = sigma_field.reshape(-1, K, K)
    flat_mask = mask.reshape(-1)
    N = flat_sigma.shape[0]

    valid_indices = np.flatnonzero(flat_mask)
    sigma_valid = flat_sigma[valid_indices]  # (M, K, K)

    # Step 1: invert Σ⁻¹ (with fallback)
    sigma_inv = np.empty_like(sigma_valid)
    for i in range(sigma_valid.shape[0]):
        try:
            sigma_inv[i] = np.linalg.inv(sigma_valid[i])
        except np.linalg.LinAlgError:
            sigma_inv[i] = eye_K
            if config.debug:
                print(f"[WARN] Σ⁻¹ failed at valid index {i}")

    # Step 2: compute G_ab[i, a, b] = Tr[Σ⁻¹ G^a Σ⁻¹ G^b]
    G_ab = np.zeros((sigma_inv.shape[0], d, d), dtype=sigma_field.dtype)

    for a in range(d):
        for b in range(d):
            G_a = np.broadcast_to(generators[a], sigma_inv.shape)
            G_b = np.broadcast_to(generators[b], sigma_inv.shape)


            G_ab[..., a, b] = np.einsum("...ij,...jk,...kl,...il->...", sigma_inv, G_a, sigma_inv, G_b)



    # Step 3: symmetrize and invert G_ab
    flat_G_inv = G_inv_field.reshape(-1, d, d)
    for i, flat_idx in enumerate(valid_indices):
        G_sym = 0.5 * (G_ab[i] + G_ab[i].T)
        try:
            cond = np.linalg.cond(G_sym)
            if not np.isfinite(cond) or cond > config.max_fisher_condition:
                raise np.linalg.LinAlgError
            flat_G_inv[flat_idx] = np.linalg.inv(G_sym + config.eps * eye_d)
        except np.linalg.LinAlgError:
            flat_G_inv[flat_idx] = eye_d
            if config.debug:
                print(f"[WARN] G_ab⁻¹ fallback at index {flat_idx}")

    return G_inv_field



def apply_lie_natural_gradient(phi, grad_phi, G_inv=None, use_dexpinv=False):
    """
    Apply Lie-natural gradient update to φ using optional inverse Fisher metric
    and optional Lie group correction via dexp⁻¹.

    Args:
        phi         : (H, W, d) Lie algebra field
        grad_phi    : (H, W, d) raw Euclidean gradient
        G_inv       : (d,d) or (H,W,d,d) inverse Fisher metric or None
        use_dexpinv : NOT SUPPORTED HERE — caller must apply dexpinv externally if needed

    Returns:
        nat_grad : (H, W, d) Lie-natural gradient
    """
    assert phi.shape == grad_phi.shape, f"Shape mismatch: phi {phi.shape} vs grad {grad_phi.shape}"

    if use_dexpinv:
        raise NotImplementedError(
            "[ERROR] `use_dexpinv=True` requires calling dexpinv_operator_covariance(...) externally."
        )

    if G_inv is None:
        return grad_phi

    if G_inv.ndim == 2:
        return np.einsum("ab,...b->...a", G_inv, grad_phi)
    elif G_inv.ndim == 4:
        return np.einsum("...ab,...b->...a", G_inv, grad_phi)
    else:
        raise ValueError(f"G_inv must be (d,d) or (H,W,d,d), got {G_inv.shape}")

def apply_natural_gradient_batch(mu_field, sigma_field, grad_mu_field, grad_sigma_field, mask=None):
    """
    Apply natural gradient descent using local Fisher metric at each spatial point.
    Handles fallbacks and invalid regions with explicit masking and logging.
    
    Fisher inverse:
        G_mu^-1 = Σ
        G_Sigma^-1 = 2 × (Σ ⊗ Σ)
    
    Returns:
        delta_mu:    (H, W, K)
        delta_sigma: (H, W, K, K)
    """
    eps = getattr(config, "eps", 1e-8)
    debug = getattr(config, "debug_gradients", False)
    fallback_clip_value = getattr(config, "sanitize_fallback_value", 1.0)
    clip_threshold = getattr(config, "gradient_clip", 1e5)

    H, W, K = mu_field.shape
    N = H * W

    mu_flat = mu_field.reshape(N, K)
    sigma_flat = sigma_field.reshape(N, K, K)
    grad_mu_flat = grad_mu_field.reshape(N, K)
    grad_sigma_flat = grad_sigma_field.reshape(N, K, K)

    delta_mu = np.zeros_like(mu_flat)
    delta_sigma = np.zeros_like(sigma_flat)

    eye = np.eye(K)

    if mask is not None:
        flat_mask = mask.reshape(N)
    else:
        flat_mask = np.ones(N, dtype=bool)

    for n in range(N):
        if not flat_mask[n]:
            continue  # skip masked-out regions

        sigma_n = 0.5 * (sigma_flat[n] + sigma_flat[n].T) + eps * eye
        grad_mu_n = grad_mu_flat[n]
        grad_sigma_n = grad_sigma_flat[n]

        try:
            sigma_inv = safe_inv(sigma_n, eps=config.eps)
        except np.linalg.LinAlgError:
            sigma_inv = eye * fallback_clip_value
            if debug:
                print(f"[WARN] NG Σ⁻¹ fallback at index {n}")

        # Compute updates
        delta_mu_n = -sigma_n @ grad_mu_n
        delta_sigma_n = -2.0 * sigma_n @ grad_sigma_n @ sigma_n

        # Clip large gradients
        norm_sigma = np.linalg.norm(delta_sigma_n)
        if norm_sigma > clip_threshold:
            delta_sigma_n *= clip_threshold / norm_sigma

        delta_mu[n] = np.nan_to_num(delta_mu_n)
        delta_sigma[n] = np.nan_to_num(delta_sigma_n)

    return (
        delta_mu.reshape(H, W, K),
        delta_sigma.reshape(H, W, K, K),
    )




def apply_natural_gradient_batchfast(mu_field, sigma_field, grad_mu_field, grad_sigma_field):
    """
    Vectorized natural gradient update with SPD-safe inversion fallback.
    """
    eps = getattr(config, "eps", 1e-8)
    debug = getattr(config, "debug_gradients", False)

    H, W, K = mu_field.shape
    N = H * W

    mu_flat         = mu_field.reshape(N, K)
    sigma_flat      = sigma_field.reshape(N, K, K)
    grad_mu_flat    = grad_mu_field.reshape(N, K)
    grad_sigma_flat = grad_sigma_field.reshape(N, K, K)

    # Symmetrize and regularize Σ
    eye_K = np.eye(K)
    sigma_sym = 0.5 * (sigma_flat + np.transpose(sigma_flat, (0, 2, 1))) + eps * eye_K[None, :, :]

    sigma_inv = np.empty_like(sigma_sym)
    for i in range(N):
        try:
            sigma_inv[i] = np.linalg.inv(sigma_sym[i])
        except np.linalg.LinAlgError:
            sigma_inv[i] = eye_K
            if debug:
                print(f"[WARN] Σ⁻¹ fallback at index {i}")

    # Apply natural gradient
    delta_mu    = -np.einsum("nij,nj->ni",     sigma_inv, grad_mu_flat)
    delta_sigma = -2.0 * np.einsum("nij,njk,nkl->nil", sigma_inv, grad_sigma_flat, sigma_inv)

    return (
        np.nan_to_num(delta_mu.reshape(H, W, K)),
        np.nan_to_num(delta_sigma.reshape(H, W, K, K)),
    )



from numerical_utils import safe_inv

def compute_lie_metric(generators: np.ndarray):
    """
    Compute inner product matrix G_{ab} = Tr(G_aᵀ G_b) and its inverse.

    Args:
        generators: (d, K, K) basis of Lie algebra

    Returns:
        G: (d, d) inner product matrix
        G_inv: (d, d) inverse (with fallback)
    """
    d = generators.shape[0]
    G = np.einsum("aij,bij->ab", generators, generators)
    G = 0.5 * (G + G.T)  # symmetrize

    G_inv = safe_inv(G, eps=getattr(config, "eps", 1e-6))


    return G, G_inv




def _sanitize_one_sigma(S, eps=1e-6):
    """
    Sanitize a single covariance matrix to ensure it's symmetric positive-definite (SPD).

    Returns:
        (S_sanitized, clipped): sanitized matrix and boolean flag indicating if it was modified
    """
    S = 0.5 * (S + S.T)  # ensure symmetry

    # First line of defense: handle invalid or pathological cases
    if not np.all(np.isfinite(S)) or np.trace(S) < eps or np.any(np.diag(S) <= 0):
        return np.eye(S.shape[0]) * eps, True

    try:
        eigvals, eigvecs = np.linalg.eigh(S)
    except np.linalg.LinAlgError:
        return np.eye(S.shape[0]) * eps, True

    clipped = np.any(eigvals < eps)
    eigvals_clipped = np.clip(eigvals, eps, None)

    if clipped:
        S = eigvecs @ np.diag(eigvals_clipped) @ eigvecs.T
        S = 0.5 * (S + S.T)  # re-symmetrize

    return S, clipped


def sanitize_sigma(Sigma, eps=1e-6, debug=False, n_jobs=None, parallel_threshold=50):
    """
    Sanitize a batch of covariance matrices to ensure SPD.

    Parameters:
        Sigma: (..., K, K) ndarray — batch of covariances
        eps: minimum eigenvalue threshold
        debug: if True, prints a summary if any matrices are clipped
        n_jobs: number of parallel workers (default: config.num_cores or 1)
        parallel_threshold: min number of matrices before enabling parallelization

    Returns:
        Sanitized SPD matrices with same shape as input.
    """
    shape = Sigma.shape
    flat_sigma = Sigma.reshape(-1, shape[-2], shape[-1])
    n_total = flat_sigma.shape[0]
    n_jobs = n_jobs or getattr(config, "num_cores", 1)

    if n_total < parallel_threshold or n_jobs == 1:
        results = [_sanitize_one_sigma(S, eps) for S in flat_sigma]
    else:
        from joblib import parallel_backend
        with parallel_backend("threading"):
            results = Parallel(n_jobs=n_jobs)(
                delayed(_sanitize_one_sigma)(S, eps) for S in flat_sigma
            )

    Sigma_out, clipped_flags = zip(*results)
    if debug:
        n_clipped = sum(clipped_flags)
        if n_clipped > 0:
            print(f"[SPD sanitize] Clipped {n_clipped} / {n_total} matrices to eps={eps:.1e}")

    out = np.stack(Sigma_out, axis=0).astype(Sigma.dtype).reshape(shape)
    return out


def transport_gaussian(mu_j, sigma_j, Omega):
    """
    Transport MVG (mu, sigma) under a linear transformation Omega:
        mu_t = Omega @ mu
        sigma_t = Omega @ sigma @ Omega^T

    Args:
        mu_j:     (..., K)
        sigma_j:  (..., K, K)
        Omega:    (..., K, K)

    Returns:
        mu_t:     (..., K)
        sigma_t:  (..., K, K)
    """
    # Ensure Omega is well-conditioned
    if np.any(np.linalg.cond(Omega) > config.max_omega_condition):
        print("[WARN] Omega has a large condition number. Regularizing Omega.")
        Omega = np.eye(Omega.shape[-1])  # Regularize Omega to identity if too large
    
    # Optionally, clip the norm of Omega to prevent runaway transformations
    if np.linalg.norm(Omega) > 1e3:  # Define max norm directly
        print(f"[WARN] Omega norm is too large. Clipping Omega.")
        Omega = Omega / np.linalg.norm(Omega) * 1e3

    # Transport mean
    mu_t = np.einsum("...ij,...j->...i", Omega, mu_j)
    
    # Transport covariance
    sigma_t = np.einsum("...ij,...jk,...lk->...il", Omega, sigma_j, Omega)

    # Regularize covariance matrix if necessary
    sigma_t = sanitize_sigma(sigma_t, eps=config.eps)

    return mu_t, sigma_t


def kl_gradient_mu_sigma(mu_i, sigma_i, mu_j_t, sigma_j_t, mask=None):
    """
    Compute natural gradient of KL[𝒩(mu_i, sigma_i) || 𝒩(mu_j_t, sigma_j_t)]
    using Fisher preconditioning at q_i = (mu_i, sigma_i).

    Args:
        mu_i:      (..., K)
        sigma_i:   (..., K, K)
        mu_j_t:    (..., K)
        sigma_j_t: (..., K, K)
        mask:      (...,) or None

    Returns:
        delta_mu:     (..., K)
        delta_sigma:  (..., K, K)
    """
    delta_mu = mu_i - mu_j_t
    delta_sigma = 0.5 * (sigma_i - sigma_j_t)

    delta_mu = np.nan_to_num(delta_mu)
    delta_sigma = np.nan_to_num(delta_sigma)

    delta_mu_nat, delta_sigma_nat = apply_natural_gradient_batch(
        mu_i, sigma_i, delta_mu, delta_sigma
    )

    if mask is not None:
        mask = mask[..., None]
        delta_mu_nat *= mask
        delta_sigma_nat *= mask[..., None]

    return delta_mu_nat, delta_sigma_nat





def compute_alignment_kl_gradient(agent_i, agents, generators, params, field_type="belief"):
    """
    Compute covariant natural gradient of:
        F[q_i] = sum_j KL(q_i || Omega_ij q_j)
    """
    beta = params.get("beta", config.beta) if field_type == "belief" else params.get("model_align_weight", config.model_align_weight)
    if beta <= 0:
        return np.zeros_like(agent_i.mu_q_field), np.zeros_like(agent_i.sigma_q_field)

    mu_i = agent_i.mu_q_field if field_type == "belief" else agent_i.mu_p_field
    sigma_i = agent_i.sigma_q_field if field_type == "belief" else agent_i.sigma_p_field
    Omega_i = agent_i._exp_phi if field_type == "belief" else agent_i._exp_phi_model
    Omega_i = Omega_i.reshape(*mu_i.shape[:-1], mu_i.shape[-1], mu_i.shape[-1])

    delta_mu = np.zeros_like(mu_i)
    delta_sigma = np.zeros_like(sigma_i)

    for nb in agent_i.neighbors:
        agent_j = agents[nb["id"]]

        mu_j = agent_j.mu_q_field if field_type == "belief" else agent_j.mu_p_field
        sigma_j = agent_j.sigma_q_field if field_type == "belief" else agent_j.sigma_p_field
        Omega_j_inv = agent_j._exp_neg_phi if field_type == "belief" else agent_j._exp_neg_phi_model
        Omega_j_inv = Omega_j_inv.reshape(*mu_j.shape[:-1], mu_j.shape[-1], mu_j.shape[-1])

        mask_overlap = (agent_i.mask * agent_j.mask) > config.support_cutoff_eps
        if not np.any(mask_overlap):
            continue

        Omega_ij = np.einsum("...ik,...kj->...ij", Omega_i, Omega_j_inv)

        # Check for NaNs and Infs in Omega_ij
        if np.any(np.isnan(Omega_ij)) or np.any(np.isinf(Omega_ij)):
            print(f"[WARN] Omega_ij contains NaNs or Infs, skipping update for agent {nb['id']}")
            continue

        # Stabilize transport of Gaussian
        mu_j_t, sigma_j_t = transport_gaussian(mu_j, sigma_j, Omega_ij)
        sigma_j_t = sanitize_sigma(sigma_j_t, eps=config.eps)

        # Check transported fields for NaNs and Infs
        if np.any(np.isnan(mu_j_t)) or np.any(np.isinf(mu_j_t)):
            print(f"[WARN] mu_j_t contains NaNs or Infs")
            continue
        if np.any(np.isnan(sigma_j_t)) or np.any(np.isinf(sigma_j_t)):
            print(f"[WARN] sigma_j_t contains NaNs or Infs")
            continue

        # Compute KL gradient step
        delta_mu_step, delta_sigma_step = kl_gradient_mu_sigma(
            mu_i, sigma_i, mu_j_t, sigma_j_t, mask=mask_overlap
        )

        # Accumulate gradients
        delta_mu += delta_mu_step
        delta_sigma += delta_sigma_step

    return delta_mu, beta * delta_sigma





def compute_fisher_geometry_gradient(agent_i, agents, params, field="phi"):
    """
    Compute ∇_{φ} or ∇_{φ̃} for Fisher geometry preservation:
        ∇‖Gᵢ − Ωᵢⱼ Gⱼ Ωᵢⱼᵀ‖²
    Supports field="phi" (beliefs) or "phi_model" (models).
    """
    if field == "phi":
        phi     = agent_i.phi
        G_field = agent_i.cached_fisher_q
        exp_phi = agent_i._exp_phi
        exp_neg_phi_j_name = "_exp_neg_phi"
        fisher_weight = params.get("fisher_geometry_weight", config.fisher_geometry_weight)
    else:
        phi     = agent_i.phi_model
        G_field = agent_i.cached_fisher_p
        exp_phi = agent_i._exp_phi_model
        exp_neg_phi_j_name = "_exp_neg_phi_model"
        fisher_weight = params.get("fisher_model_geometry_weight", config.fisher_model_geometry_weight)

    if fisher_weight <= 0:
        return np.zeros_like(phi)

    Gs = get_generators(config.group_name, config.K)
    d, K = Gs.shape[0], Gs.shape[1]
    mask_i = agent_i.mask > config.support_cutoff_eps
    if not np.any(mask_i):
        return np.zeros_like(phi)

    grad = np.zeros_like(phi)
    flat_self_mask = mask_i.reshape(-1)

    exp_phi_i = exp_phi.reshape(-1, K, K)

    for nb in agent_i.neighbors:
        agent_j = agents[nb["id"]]
        mask_j = agent_j.mask > config.support_cutoff_eps
        overlap = mask_i & mask_j
        if not np.any(overlap):
            continue

        flat_idxs = overlap.reshape(-1)

        G_i = G_field.reshape(-1, K, K)[flat_idxs]
        G_j = getattr(agent_j, f"cached_fisher_{'q' if field == 'phi' else 'p'}").reshape(-1, K, K)[flat_idxs]
        exp_neg_phi_j = getattr(agent_j, exp_neg_phi_j_name).reshape(-1, K, K)[flat_idxs]

        Omega = np.einsum("mij,mjk->mik", exp_phi_i[flat_idxs], exp_neg_phi_j)
        G_j_rot = np.einsum("mik,mkl,mjl->mij", Omega, G_j, Omega)  # Ω G Ωᵀ
        Delta = G_i - G_j_rot

        for a in range(d):
            Ga = Gs[a]
            dΩ = np.einsum("ij,mjk->mik", Ga, Omega)
            term1 = np.einsum("mik,mkl,mjl->mij", dΩ, G_j, Omega)
            term2 = np.einsum("mik,mkl,mjl->mij", Omega, G_j, dΩ)
            dG_rot = term1 + term2
            dL = 2 * np.einsum("mij,mij->m", Delta, dG_rot)
            grad.reshape(-1, d)[flat_idxs, a] += dL

    grad *= fisher_weight
    grad[~mask_i] = 0.0
    return grad






