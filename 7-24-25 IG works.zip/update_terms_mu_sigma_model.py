# -*- coding: utf-8 -*-
"""
Created on Wed Jul 23 11:36:43 2025

@author: chris and christine
"""

import numpy as np
import config
from numerical_utils import sanitize_sigma, safe_inv
from natural_gradient_utils import apply_natural_gradient_batch




#==============================================================================
#
#                    APPLY NATURAL GRADIENT
#
#==============================================================================


from natural_params_utils import convert_mu_sigma_grads_to_eta_grads

def accumulate_eta_gradient_model(agent_i, agents, params):
    """
    Accumulate ∇_{η₁_p}, ∇_{η₂_p} from all model energy terms:
      - Self:     KL(p_i || Φ q_i)
      - Feedback: KL(q_i || Φ̃ p_i)
      - Alignment: KL(p_i || Ω_ij p_j)   and   KL(p_k || Ω_kj p_j) for i == j

    Stores into:
        agent_i.grad_eta1_p_field
        agent_i.grad_eta2_p_field
    """

    # Step 1: Compute Euclidean gradients
    dmu, dsigma = compute_mu_sigma_gradient_model_euclidean(agent_i, agents, params)

    # Step 2: Convert to ∇η₁ and ∇η₂
    grad_eta1, grad_eta2 = convert_mu_sigma_grads_to_eta_grads(
        agent_i.mu_p_field,
        agent_i.sigma_p_field,
        dmu,
        dsigma,
        eps=config.support_cutoff_eps,
    )

    # Step 3: Masked accumulation
    mask = agent_i.mask[..., None]
    mask = np.squeeze(mask)  # Now shape (16, 16)
    agent_i.grad_eta1_p_field += grad_eta1 * mask[..., None]
    agent_i.grad_eta2_p_field += grad_eta2 * mask[..., None, None]



#==============================================================================
#
#                    ACCUMULATE FIELD GRADS EUCLIDEAN
#
#==============================================================================

def compute_mu_sigma_gradient_model_euclidean(agent_i, agents, params):
    """
    Accumulate ∇_μ and ∇_Σ model gradients for agent_i from:
    - Self-energy:     KL(p_i ‖ Φ q_i)
    - Feedback:        KL(q_i ‖ Φ̃ p_i)
    - Alignment (μ_i): KL(p_i ‖ Ω_ij p_j)
    - Alignment (μ_j): KL(p_k ‖ Ω_kj p_j) if i == j

    Returns:
        dmu_p:    (..., K_p)
        dsigma_p: (..., K_p, K_p)
    """
    eps   = config.support_cutoff_eps
    alpha = params.get("alpha", config.alpha)
    beta  = params.get("beta", config.beta)
    lambd = params.get("feedback", config.feedback_weight)

    mu_q    = agent_i.mu_q_field
    sigma_q = agent_i.sigma_q_field
    mu_p    = agent_i.mu_p_field
    sigma_p = agent_i.sigma_p_field
    Phi         = agent_i.bundle_morphism_q_to_p
    Phi_tilde   = agent_i.bundle_morphism_p_to_q

    # Self energy and feedback terms switched for model fiber
    dmu_self    = grad_self_energy_mu_p(mu_q, sigma_q, mu_p, sigma_p, Phi_tilde, eps=eps)
    dsigma_self = grad_self_energy_sigma_p(mu_q, sigma_q, mu_p, sigma_p, Phi_tilde, eps=eps)

    dmu_fb = grad_feedback_mu_p(mu_p, sigma_p, mu_q, sigma_q, Phi, eps=eps)
    dsigma_fb = grad_feedback_sigma_p(mu_p, sigma_p, mu_q, sigma_q, Phi, eps=eps)


    # Alignment terms where agent_i is the *source* p_i
    dmu_align = 0
    dsigma_align = 0
    for neighbor in agent_i.neighbors:
        agent_j = agents[neighbor["id"]]
        Omega_ij = agent_i._exp_phi_model @ agent_j._exp_neg_phi_model

        dmu_align += grad_model_align_mu_i(
            mu_p, sigma_p, agent_j.mu_p_field, agent_j.sigma_p_field, Omega_ij, eps=eps
        )
        dsigma_align += grad_model_align_sigma_i(
            mu_p, sigma_p, agent_j.mu_p_field, agent_j.sigma_p_field, Omega_ij, eps=eps
        )

    # Alignment terms where agent_i is the *target* p_j in p_k ‖ Ω_kj p_j
    dmu_align_rev = 0
    dsigma_align_rev = 0
    for agent_k in agents:
        for neighbor in agent_k.neighbors:
            if neighbor.get("id") == agent_i.id:
                Omega_kj = np.einsum(
                    "...ik,...kj->...ij",
                    agent_k._exp_phi_model,
                    agent_i._exp_neg_phi_model
                    )
                dmu_align_rev += grad_model_align_mu_j(
                    agent_k.mu_p_field, agent_k.sigma_p_field,
                    mu_p, sigma_p, Omega_kj, eps=eps
                )
                dsigma_align_rev += grad_model_align_sigma_j(
                    agent_k.mu_p_field, agent_k.sigma_p_field,
                    mu_p, sigma_p, Omega_kj, eps=eps
                )

    # Combine all
    dmu_total = (
        alpha * dmu_self +
        lambd * dmu_fb +
        beta * (dmu_align + dmu_align_rev)
    )

    dsigma_total = (
        alpha * dsigma_self +
        lambd * dsigma_fb +
        beta * (dsigma_align + dsigma_align_rev)
    )

    return dmu_total, dsigma_total


#==============================================================================
#
#                    FEEDBACK TERMS
#              all validated below
#==============================================================================


def grad_feedback_mu_p(mu_p_field, sigma_p_field,
                       mu_q_field, sigma_q_field, Phi, eps=1e-8):
    """
    Compute the gradient ∂/∂μ_p of the feedback KL divergence:
        D_KL(p || Φ q)
    where p ~ N(μ_p, Σ_p), and Φ q ~ N(Φ μ_q, Φ Σ_q Φᵀ),
    assuming both beliefs and models are multivariate Gaussians.

    Args:
        mu_p_field     : (..., K_p)        - model mean μ_p
        sigma_p_field  : (..., K_p, K_p)   - model covariance Σ_p (unused here)
        mu_q_field     : (..., K_q)        - belief mean μ_q
        sigma_q_field  : (..., K_q, K_q)   - belief covariance Σ_q
        Phi            : (..., K_p, K_q)   - bundle morphism Φ: B_q → B_p
        eps            : regularization epsilon for safe matrix inversion

    Returns:
        grad_mu_p      : (..., K_p)        - ∇μ_p D_KL(p || Φ q)
    """
    # Step 1: Pushforward belief mean μ_q → μ_q_push = Φ μ_q
    mu_q_push = np.einsum("...ij,...j->...i", Phi, mu_q_field)  # (..., K_p)

    sigma_q_field = sanitize_sigma(sigma_q_field, eps=eps)

    # Step 2: Pushforward belief covariance: Σ_q → Σ_q_push = Φ Σ_q Φᵀ
    sigma_q_push = np.einsum("...ik,...kl,...jl->...ij", Phi, sigma_q_field, Phi)  # (..., K_p, K_p)

    # Step 3: Invert the pushforwarded covariance
    sigma_q_push_inv = safe_inv(sigma_q_push, eps=eps)  # (..., K_p, K_p)

    # Step 4: Compute mean difference: Δμ = μ_p − Φ μ_q
    delta_mu = mu_p_field - mu_q_push  # (..., K_p)

    # Step 5: Gradient: ∇μ_p D_KL = Σ_q_push⁻¹ (μ_p − Φ μ_q)
    grad_mu_p = np.einsum("...ij,...j->...i", sigma_q_push_inv, delta_mu)

    return grad_mu_p



def grad_feedback_sigma_p(mu_p_field, sigma_p_field,
                          mu_q_field, sigma_q_field, Phi, eps=1e-8):
    """
    Compute ∂/∂Σ_p D_KL(p || Φ q)
    """
    # Pushforward belief covariance: Φ Σ_q Φ^T
    Phi_T = np.swapaxes(Phi, -1, -2)  # (..., K_q, K_p)
    
    sigma_q_field = sanitize_sigma(sigma_q_field, eps=eps)
    sigma_q_push = np.einsum("...ik,...kl,...lj->...ij", Phi, sigma_q_field, Phi_T)

    sigma_q_push = sanitize_sigma(sigma_q_push, eps=eps)
    sigma_p_field = sanitize_sigma(sigma_p_field, eps=eps)

    sigma_inv_qpush = safe_inv(sigma_q_push, eps=eps)
    sigma_inv_p     = safe_inv(sigma_p_field, eps=eps)

    # Gradient wrt Σ_p: (1/2) [ (Φ Σ_q Φ^T)^(-1) - Σ_p^(-1) ]
    grad_sigma_p = 0.5 * (sigma_inv_qpush - sigma_inv_p)

    return grad_sigma_p




#==============================================================================
#
#                    SELF-ENERGY TERMS
#
#==============================================================================


def grad_self_energy_mu_p(mu_q_field, sigma_q_field,
                          mu_p_field, sigma_p_field, Phi_tilde, eps=1e-8):
    """
    Compute ∂/∂μ_p D_KL(q || Φ̃ p) over spatial field (H, W, K_p)

    This mirrors grad_feedback_mu_q but swaps roles.
    """
    # Step 1: Compute pushforward mean: Φ̃ μ_p → (..., K_q)
    mu_p_push = np.einsum("...qk,...k->...q", Phi_tilde, mu_p_field)
    sigma_p_field = sanitize_sigma(sigma_p_field, eps=eps)
    # Step 2: Compute pushforward covariance: Φ̃ Σ_p Φ̃ᵀ → (..., K_q, K_q)
    sigma_p_push = np.einsum("...qi,...ij,...kj->...qk", Phi_tilde, sigma_p_field, Phi_tilde)


    # Step 3: Invert pushforwarded covariance
    sigma_p_push = sanitize_sigma(sigma_p_push, eps=eps)
    sigma_p_push_inv = safe_inv(sigma_p_push, eps=eps)  # (..., K_q, K_q)

    # Step 4: Δμ = μ_q − Φ̃ μ_p
    delta_mu = mu_q_field - mu_p_push  # (..., K_q)

    # Step 5: Compute −Φ̃ᵀ Σ_push⁻¹ (μ_q − Φ̃ μ_p)
    tmp = np.einsum("...ij,...j->...i", sigma_p_push_inv, delta_mu)  # (..., K_q)
    grad_mu_p = -np.einsum("...qk,...q->...k", Phi_tilde, tmp)


    return grad_mu_p



def grad_self_energy_sigma_p(mu_q_field, sigma_q_field, mu_p_field, 
                              sigma_p_field, Phi_tilde, eps=1e-8):
    """
    Compute ∂/∂Σ_p D_KL(q || Φ̃·p) ≡ 1/2 · Φ̃ᵗ [ ... ] Φ̃

    Returns:
        grad_sigma_p : (..., K_p, K_p)
    """
    # Sanitize inputs for stability
    sigma_p_field = sanitize_sigma(sigma_p_field, eps=eps)
    sigma_q_field = sanitize_sigma(sigma_q_field, eps=eps)

    Phi_tilde_T = np.swapaxes(Phi_tilde, -1, -2)

    # Σ_p' = Φ̃ Σ_p Φ̃ᵗ
    sigma_proj = np.einsum("...ik,...kl,...jl->...ij", Phi_tilde, sigma_p_field, Phi_tilde)
    sigma_proj_inv = safe_inv(sigma_proj, eps=eps)

    # μ_p' = Φ̃ μ_p
    mu_proj = np.einsum("...ij,...j->...i", Phi_tilde, mu_p_field)
    delta_mu = mu_q_field - mu_proj
    delta_mu_outer = np.einsum("...i,...j->...ij", delta_mu, delta_mu)

    # Three bracket terms
    term1 = sigma_proj_inv
    term2 = np.einsum("...ik,...kl,...lj->...ij", sigma_proj_inv, delta_mu_outer, sigma_proj_inv)
    term3 = np.einsum("...ik,...kl,...lj->...ij", sigma_proj_inv, sigma_q_field, sigma_proj_inv)

    # Combine and pull back
    M = term1 - term2 - term3
    grad_sigma_p = 0.5 * np.einsum("...ki,...ij,...jl->...kl", Phi_tilde_T, M, Phi_tilde)

    return grad_sigma_p





#==============================================================================
#
#                    ALIGNMENT TERMS - NOT VALIDATED
#
#==============================================================================

def grad_model_align_mu_i(mu_p_i, sigma_p_i, mu_p_j, sigma_p_j, Omega_ij, eps=1e-8):
    """
    ∇_{μ_i} D_KL(p_i || Ω p_j) = (Ω Σ_j Ωᵀ)^(-1) (μ_i − Ω μ_j)
    For model fibers (p_i, p_j) aligned by Ω.

    Args:
        mu_p_i    : (..., K_p) mean of p_i
        sigma_p_i : (..., K_p, K_p) covariance of p_i
        mu_p_j    : (..., K_p) mean of p_j
        sigma_p_j : (..., K_p, K_p) covariance of p_j
        Omega_ij  : (..., K_p, K_p) gauge transport operator from j to i
        eps       : numerical regularization constant

    Returns:
        grad_mu_p_i : (..., K_p) gradient w.r.t. μ_i
    """
    mu_j_t = np.einsum("...ij,...j->...i", Omega_ij, mu_p_j)  # Ω μ_j
    delta_mu = mu_p_i - mu_j_t
    
    Omega_T = np.swapaxes(Omega_ij, -1, -2)
    sigma_j_t = np.einsum("...ik,...kl,...lj->...ij", Omega_ij, sigma_p_j, Omega_T)
  # Ω Σ_j Ωᵀ
    sigma_j_t = sanitize_sigma(sigma_j_t, eps=eps)
    sigma_inv = safe_inv(sigma_j_t, eps=eps)

    grad = np.einsum("...ij,...j->...i", sigma_inv, delta_mu)
    return grad


def grad_model_align_sigma_i(mu_p_i, sigma_p_i, mu_p_j, sigma_p_j, Omega_ij, eps=1e-8):
    """
    ∇_{Σ_i} D_KL(p_i || Ω p_j) = ½ [ (Ω Σ_j Ωᵀ)^(-1) − Σ_i^(-1) ]
    For model fibers.

    Args:
        mu_p_i    : (..., K_p)
        sigma_p_i : (..., K_p, K_p)
        mu_p_j    : (..., K_p)
        sigma_p_j : (..., K_p, K_p)
        Omega_ij  : (..., K_p, K_p)
        eps       : numerical regularization constant

    Returns:
        grad_sigma_p_i : (..., K_p, K_p) gradient w.r.t. Σ_i
    """
    Omega_T = np.swapaxes(Omega_ij, -1, -2)
    sigma_j_t = np.einsum("...ik,...kl,...lj->...ij", Omega_ij, sigma_p_j, Omega_T)

    sigma_j_t = sanitize_sigma(sigma_j_t, eps=eps)
    inv_j = safe_inv(sigma_j_t, eps=eps)
    inv_i = safe_inv(sigma_p_i, eps=eps)

    grad = 0.5 * (inv_j - inv_i)
    return grad




def grad_model_align_mu_j(mu_p_i, sigma_p_i, mu_p_j, sigma_p_j, Omega_ij, eps=1e-8):
    """
    ∇_{μ_j} D_KL(p_i || Ω p_j) = -Ωᵀ (Ω Σ_j Ωᵀ)^(-1) (μ_i − Ω μ_j)
    """
    # Transported μ_j and Σ_j
    mu_j_t = np.einsum("...ij,...j->...i", Omega_ij, mu_p_j)
    delta_mu = mu_p_i - mu_j_t

    Omega_T = np.swapaxes(Omega_ij, -1, -2)
    sigma_j_t = np.einsum("...ik,...kl,...lj->...ij", Omega_ij, sigma_p_j, Omega_T)
    sigma_j_t = sanitize_sigma(sigma_j_t, eps=eps)
    sigma_inv = safe_inv(sigma_j_t, eps=eps)

    tmp = np.einsum("...ij,...j->...i", sigma_inv, delta_mu)
    grad = -np.einsum("...ij,...j->...i", Omega_T, tmp)
    return grad



def grad_model_align_sigma_j(mu_p_i, sigma_p_i, mu_p_j, sigma_p_j, Omega_ij, eps=1e-8):
    """
    ∇_{Σ_j} D_KL(p_i || Ω p_j)
    = ½ Ωᵀ [ M⁻¹ Δμ Δμᵀ M⁻¹ − M⁻¹ Σ_i M⁻¹ − M⁻¹ ] Ω
    where M = Ω Σ_j Ωᵀ
    """
    # Transport μ_j
    mu_j_t = np.einsum("...ij,...j->...i", Omega_ij, mu_p_j)
    delta_mu = mu_p_i - mu_j_t

    # Compute transported Σ_j
    Omega_T = np.swapaxes(Omega_ij, -1, -2)
    sigma_j_t = np.einsum("...ik,...kl,...lj->...ij", Omega_ij, sigma_p_j, Omega_T)
    sigma_j_t = sanitize_sigma(sigma_j_t, eps=eps)
    sigma_inv = safe_inv(sigma_j_t, eps=eps)

    # Term 1: M⁻¹ Δμ Δμᵀ M⁻¹
    tmp = np.einsum("...i,...j->...ij", delta_mu, delta_mu)
    term1 = np.einsum("...ik,...kl,...lj->...ij", sigma_inv, tmp, sigma_inv)

    # Term 2: M⁻¹ Σ_i M⁻¹
    term2 = np.einsum("...ik,...kl,...lj->...ij", sigma_inv, sigma_p_i, sigma_inv)

    # Term 3: M⁻¹
    term3 = sigma_inv

    # Combine and project back to ∇Σ_j
    diff = term1 - term2 - term3
    grad = 0.5 * np.einsum("...ik,...kl,...lj->...ij", Omega_T, diff, Omega_ij)
    return grad
