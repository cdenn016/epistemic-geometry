# -*- coding: utf-8 -*-
"""
Created on Tue Jul  1 19:54:31 2025

@author: chris and christine
"""

# zipf_fit_alpha_beta.py
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from scipy.optimize import curve_fit
from pathlib import Path

# -------------------------------------------------------
# CONFIG
# -------------------------------------------------------
CSV_PATH = Path("zipf_gifs/gamma_summary.csv")  # or wherever you saved it
SAVE_FIG = True
OUT_FIG = Path("zipf_gifs/zipf_fit_scatter.png")

# -------------------------------------------------------
# Load and clean data
# -------------------------------------------------------
df = pd.read_csv(CSV_PATH)
df = df.dropna(subset=["gamma_log", "pred_zipf_slope"])
df = df[df["agent"] != "global"]

gamma_vals = df["gamma_log"].values
n_vals = df["n_neigh"].values
s_empirical = df["pred_zipf_slope"].values  # ← change to actual Zipf slope if needed

# -------------------------------------------------------
# Define the slope model and fit it
# -------------------------------------------------------
def model_to_fit(X, alpha, beta):
    n, gamma = X
    return -beta * n * gamma / (alpha + beta * n)

X_data = np.vstack([n_vals, gamma_vals])
popt, pcov = curve_fit(model_to_fit, X_data, s_empirical, p0=[1.0, 1.0])
alpha_fit, beta_fit = popt

# Predict using fitted parameters
s_pred = model_to_fit(X_data, *popt)

# -------------------------------------------------------
# Plotting: empirical vs predicted slopes
# -------------------------------------------------------
plt.figure(figsize=(6, 5))
plt.scatter(s_empirical, s_pred, label="Agents", alpha=0.8)
plt.plot([-3, 0], [-3, 0], 'k--', label="Ideal Fit (y=x)")
plt.xlabel("Empirical Zipf Slope")
plt.ylabel("Predicted Zipf Slope")
plt.title(f"Fit: α ≈ {alpha_fit:.2f}, β ≈ {beta_fit:.2f}")
plt.legend()
plt.grid(True)
plt.tight_layout()

if SAVE_FIG:
    OUT_FIG.parent.mkdir(parents=True, exist_ok=True)
    plt.savefig(OUT_FIG, dpi=120)
    print(f"[Saved] → {OUT_FIG}")
else:
    plt.show()

# -------------------------------------------------------
# Print fitted parameters
# -------------------------------------------------------
print(f"Fitted α = {alpha_fit:.4f}")
print(f"Fitted β = {beta_fit:.4f}")
