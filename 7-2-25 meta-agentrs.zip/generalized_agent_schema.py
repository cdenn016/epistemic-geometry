from dataclasses import dataclass, field
from typing import Tuple, List, Optional, Dict, Any
import numpy as np

@dataclass
class Agent:
    id: int
    mask: np.ndarray
    q: np.ndarray
    p: np.ndarray
    phi: np.ndarray
    phi_model: np.ndarray
    center: Tuple[int, ...]   # D-dimensional center
    radius: float
    mu_q_field: np.ndarray
    sigma_q_field: np.ndarray
    mu_p_field: np.ndarray
    sigma_p_field: np.ndarray
    neighbors: List[dict]
    delta_phi_model: Optional[np.ndarray] = None  # optional update delta

    # New fields for meta-agent / multi-scale studies
    agent_scale: float = 1.0
    hierarchy_level: int = 0

    # Cached summary statistics (updated per step)
    entropy: Optional[float] = None
    energy: Optional[float] = None
    coherence: Optional[float] = None

    # Last update step index (for async or event-driven updates)
    last_update_step: Optional[int] = None

    # Per-agent metrics log
    metrics_log: List[Dict[str, Any]] = field(default_factory=list)

    # Caches for non-abelian transport (recomputed each step)
    _exp_phi: Optional[np.ndarray] = field(default=None, init=False)
    _exp_neg_phi: Optional[np.ndarray] = field(default=None, init=False)
    _exp_phi_model: Optional[np.ndarray] = field(default=None, init=False)
    _exp_neg_phi_model: Optional[np.ndarray] = field(default=None, init=False)

    # Automatically computed, for flat indexing
    q_flat: np.ndarray = field(init=False)
    p_flat: np.ndarray = field(init=False)
    #grid_shape: Tuple[int, ...] = field(init=False)

    def __post_init__(self):
        # record the spatial grid shape (all but last axis of q/p)
        self.grid_shape = self.q.shape[:-1]
        # flatten each distribution to shape (N, K)
        self.q_flat = self.q.reshape(-1, self.q.shape[-1])
        self.p_flat = self.p.reshape(-1, self.p.shape[-1])

    def log_metrics(self, step: int, stats: Dict[str, Any]) -> None:
        """
        Record diagnostic stats for this agent at a given step.
        """
        entry = {'step': step}
        entry.update(stats)
        self.metrics_log.append(entry)

    def clear_omega_cache(self) -> None:
        """
        Reset any precomputed exp(phi) caches.
        Call at the start of each Euler step.
        """
        self._exp_phi = None
        self._exp_neg_phi = None
        self._exp_phi_model = None
        self._exp_neg_phi_model = None

    @property
    def Omega(self) -> np.ndarray:
        """
        Non-abelian transport operator exp(phi) reshaped to spatial grid.
        """
        K = self.q.shape[-1]
        return self._exp_phi.reshape(*self.grid_shape, K, K)

    @property
    def Omega_inv(self) -> np.ndarray:
        """
        Inverse transport operator exp(-phi) reshaped to spatial grid.
        """
        K = self.q.shape[-1]
        return self._exp_neg_phi.reshape(*self.grid_shape, K, K)

    @property
    def Omega_model(self) -> np.ndarray:
        K = self.p.shape[-1]
        #print("[DEBUG Omega_model] grid_shape =", self.grid_shape, "K =", K)
        expected_size = np.prod(self.grid_shape) * K * K
        assert self._exp_phi_model.size == expected_size, \
            f"[Ω_model] Reshape mismatch: {self._exp_phi_model.shape} vs {self.grid_shape}×{K}×{K}"
        return self._exp_phi_model.reshape(*self.grid_shape, K, K)


    @property
    def Omega_model_inv(self) -> np.ndarray:
        """
        Inverse model-phase transport operator exp(-phi_model).
        """
        K = self.p.shape[-1]
        return self._exp_neg_phi_model.reshape(*self.grid_shape, K, K)

    @property
    def grid_shape(self):
        return self._grid_shape

    @grid_shape.setter
    def grid_shape(self, val):
        assert isinstance(val, tuple) and all(isinstance(d, int) for d in val), \
            f"[grid_shape] Invalid assignment: {val}"
        self._grid_shape = val
