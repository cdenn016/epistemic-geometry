# -----------------------------------------------------------------------------
# visualize_agent_metrics_revamped.py   ·   2025-06-30
# -----------------------------------------------------------------------------
"""
End-to-end visualisation pipeline for *Generalised Epistemic Geometry* checkpoints.

• **Zero-config** – drop next to your *gif_plot_helpers.py* and run:
      python visualize_agent_metrics_revamped.py  
  The script autodetects *config.py* (for SL(2,ℝ) vs SO(3) etc.) and the
  *gif_plot_helpers.METRIC_FUNCS* registry.

• **Robust** – never crashes on missing neighbours, metrics, or weird agent
  wrappers.  All failures are downgraded to warnings.

• **Batch GIFs + PNGs** – one folder per metric, with *final.png* + *evolution.gif*
  per agent (configurable).  The default colour-map is readable on dark/light UIs.

------------------------------------------------------------------------
Edit the *CONFIG* dict below to suit your run.  All paths are relative to the
working directory.  The default group name is pulled from *config.py*; if that
module is absent we fall back to "sl2r".
"""

# =====================================================================
#  USER CONFIG
# =====================================================================
CONFIG = {
    # Location of step_XXXX.pkl files
    "CHECKPOINT_DIR": "checkpoints",

    # Where to write PNGs + GIFs
    "OUT_DIR": "Metric_Visualizations",

    # Show at most this many agents (None = all)
    "AGENT_LIMIT": 1,

    # Frames-per-second of the GIFs
    "GIF_FPS": 4,

    # Which metrics from gif_plot_helpers.METRIC_FUNCS to render.
    #   • List[str] : render exactly these.
    #   • "all"     : render every registered metric.
    "METRICS": "all",

    # Matplotlib colour-map for images
    "CMAP": "magma",

    # Rescale each metric independently to 0-1?  (improves contrast)
    "NORMALISE": True,
}

# =====================================================================
#  Imports – only stdlib + numpy/mpl/pickle (for portability)
# =====================================================================
import warnings, pickle, re, os
from pathlib import Path
from typing import Dict, List, Tuple

import numpy as np
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation, PillowWriter

# Project helpers – *must* be present in the same folder or PYTHONPATH
import gif_plot_helpers as gph  # provides METRIC_FUNCS

try:
    import config  # project-wide defaults (e.g. group_name)
except ImportError:  # allow running outside repo root
    class _Dummy:  # minimal fall-back
        group_name = "sl2r"
    config = _Dummy()

# ---------------------------------------------------------------------
#  Natural sort helper (so that step_1 < step_10 < step_100)
# ---------------------------------------------------------------------
_DIGITS = re.compile(r"(\d+)")

def _natural_key(s: str):
    return [int(t) if t.isdigit() else t.lower() for t in _DIGITS.split(str(s))]

# ---------------------------------------------------------------------
#  Agent un-wrapper – handles [agent, cache] etc.
# ---------------------------------------------------------------------

def _unwrap_agent(obj):
    """Return the first sub-object that has a .q attribute."""
    if hasattr(obj, "q"):
        return obj
    if isinstance(obj, (list, tuple)):
        for x in obj:
            out = _unwrap_agent(x)
            if out is not None:
                return out
    return None  # not an agent

# ---------------------------------------------------------------------
#  Main visualisation routine
# ---------------------------------------------------------------------

def generate_visualisations(cfg: Dict = CONFIG):
    ckpt_dir = Path(cfg["CHECKPOINT_DIR"])
    out_root = Path(cfg["OUT_DIR"])
    out_root.mkdir(parents=True, exist_ok=True)

    # -------------------------------
    # Locate step files
    # -------------------------------
    step_files = sorted(ckpt_dir.glob("step_*.pkl"), key=_natural_key)
    if not step_files:
        print(f"[VIS] No step_*.pkl found in {ckpt_dir.resolve()}")
        return

    # -------------------------------
    # Which metrics?
    # -------------------------------
    if cfg["METRICS"] == "all":
        metrics = list(gph.METRIC_FUNCS.keys())
    else:
        metrics = list(cfg["METRICS"])  # make a copy
        # sanity-check existence
        missing = [m for m in metrics if m not in gph.METRIC_FUNCS]
        if missing:
            raise ValueError(f"Unknown metric names: {missing}")

    # dict[(metric, agent_id)] -> list[np.ndarray]
    frames: Dict[Tuple[str, int], List[np.ndarray]] = {}

    # =================================================================
    #  Iterate over checkpoints                     <-- core load loop
    # =================================================================
    for step_path in step_files:
        with open(step_path, "rb") as f:
            data = pickle.load(f)

        # Accept either plain list of Agent OR a tuple/dict containing it
        if isinstance(data, (list, tuple)) and _unwrap_agent(data[0]) is not None:
            agents = data
        elif isinstance(data, dict) and "agents" in data:
            agents = data["agents"]
        else:
            raise RuntimeError(f"Unrecognised checkpoint format: {step_path}")

        print(f"[VIS] step {step_path.stem}: loaded {len(agents)} agents")

        # Limit number of agents to visualise
        n_agents = len(agents) if cfg["AGENT_LIMIT"] is None else min(cfg["AGENT_LIMIT"], len(agents))

        # ---------------------------------------
        # Per-agent, per-metric frame extraction
        # ---------------------------------------
        for aid in range(n_agents):
            for metric in metrics:
                func = gph.METRIC_FUNCS[metric]
                key  = (metric, aid)
                try:
                    field = func(agents, aid)
                    if field is None:
                        raise ValueError("returned None")
                    # Optionally rescale to 0-1 for contrast
                    if cfg["NORMALISE"]:
                        vmin, vmax = np.nanmin(field), np.nanmax(field)
                        if vmax > vmin:
                            field = (field - vmin) / (vmax - vmin)
                    frames.setdefault(key, []).append(field.astype(float))
                except Exception as exc:
                    warnings.warn(f"[VIS] {metric}[agent {aid}] failed at {step_path.name}: {exc}")

    # =================================================================
    #  Rendering – save PNG (last frame) + GIF (sequence) per metric/agent
    # =================================================================
    cmap = cfg["CMAP"]
    fps  = cfg["GIF_FPS"]

    for (metric, aid), seq in frames.items():
        if not seq:
            continue  # nothing to render
        # Folder per metric for easy browsing
        metric_dir = out_root / metric
        metric_dir.mkdir(parents=True, exist_ok=True)

        # -------------------------
        # Save final frame PNG
        # -------------------------
        final_img = seq[-1]
        png_path  = metric_dir / f"agent_{aid}_final.png"
        plt.imsave(png_path, final_img, cmap=cmap)

        # -------------------------
        # Save evolution GIF (if >1 frame)
        # -------------------------
        if len(seq) > 1:
            gif_path = metric_dir / f"agent_{aid}_evolution.gif"
            fig, ax = plt.subplots()
            im = ax.imshow(seq[0], cmap=cmap)
            ax.set_axis_off()

            def _update(frame):
                im.set_data(frame)
                return (im,)

            ani = FuncAnimation(fig, _update, frames=seq, blit=True)
            ani.save(gif_path, writer=PillowWriter(fps=fps))
            plt.close(fig)

    print(f"[VIS] Completed – outputs in {out_root.resolve()}")


# =====================================================================
#  Entry-point
# =====================================================================
if __name__ == "__main__":
    # Allow CLI overrides via simple KEY=VAL args, e.g.  AGENT_LIMIT=3
    import sys

    for arg in sys.argv[1:]:
        if "=" not in arg:
            continue
        key, val = arg.split("=", 1)
        # Cast basic types automatically
        if key in CONFIG:
            if val.isdigit():
                CONFIG[key] = int(val)
            elif val.replace(".", "", 1).isdigit():
                CONFIG[key] = float(val)
            elif val.lower() in {"true", "false"}:
                CONFIG[key] = val.lower() == "true"
            else:
                CONFIG[key] = val
    # Run visualiser
    generate_visualisations(CONFIG)
