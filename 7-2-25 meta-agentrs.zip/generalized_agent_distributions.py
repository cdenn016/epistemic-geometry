import numpy as np


from get_generators import get_generators


def initialize_gaussian_distribution(x, mu_field, sigma_field, mask):
    mu = mu_field[..., None]
    sigma = sigma_field[..., None]
    unnorm = np.exp(-0.5 * ((x - mu) / sigma) ** 2)
    dist = unnorm / (np.sum(unnorm, axis=-1, keepdims=True) + 1e-8)
    dist *= mask[..., None]
    return dist

# generalized_agent_distributions.py
import numpy as np
import config                       # to get the global K

# generalized_agent_distributions.py
import numpy as np
import config

def initialize_uniform_distribution(x, mask=None, dtype=np.float32):
    """
    Create a uniform categorical distribution with shape (*spatial*, K),
    where spatial is inferred from `mask` if it exists, otherwise from `x`.
    """
    K = config.K

    # 1. Determine spatial grid shape ---------------------------------------
    if mask is not None:
        spatial_shape = mask.shape                          # (H, W)
    elif x is not None and x.ndim >= 2:
        spatial_shape = x.shape[:-1]                        # last axis = coords
    else:
        spatial_shape = config.domain_size                  # fallback

    # 2. Allocate writable base array ---------------------------------------
    base = np.full((*spatial_shape, K), 1.0 / K, dtype=dtype)

    # 3. Apply agent support mask (if any) ----------------------------------
    if mask is not None:
        base = base * mask[..., None]                       # ordinary multiply

    return base




def initialize_exponential_distribution(x, lambda_field, mask):
    """
    Initialize an exponential decay distribution over discrete fiber states,
    with spatially varying decay rate lambda_field > 0.
    """
    lambda_ = lambda_field[..., None]
    unnorm = np.exp(-lambda_ * x)
    dist = unnorm / (np.sum(unnorm, axis=-1, keepdims=True) + 1e-8)
    dist *= mask[..., None]
    return dist

def initialize_beta_like_distribution(x, alpha_field, beta_field, mask):
    """
    Initialize a beta-like distribution shape over discrete fiber states,
    where alpha_field, beta_field > 0 control skewness. Scales x to [0,1].
    """
    K = x.shape[-1]
    x_scaled = (x - x.min()) / (x.max() - x.min() + 1e-8)
    alpha = alpha_field[..., None]
    beta = beta_field[..., None]

    # Beta PDF shape (unnormalized)
    unnorm = (x_scaled ** (alpha - 1)) * ((1 - x_scaled) ** (beta - 1))
    dist = unnorm / (np.sum(unnorm, axis=-1, keepdims=True) + 1e-8)
    dist *= mask[..., None]
    return dist

def initialize_bimodal_gaussian_distribution(x, mu1_field, sigma1_field, mu2_field, sigma2_field, weight_field, mask):
    """
    Initialize a bimodal mixture of Gaussians over fiber states with spatially varying
    mixture weights.
    weight_field in [0,1] controls mixture proportion of first mode.
    """
    mu1 = mu1_field[..., None]
    sigma1 = sigma1_field[..., None]
    mu2 = mu2_field[..., None]
    sigma2 = sigma2_field[..., None]
    w = weight_field[..., None]

    g1 = np.exp(-0.5 * ((x - mu1) / sigma1) ** 2)
    g2 = np.exp(-0.5 * ((x - mu2) / sigma2) ** 2)

    unnorm = w * g1 + (1 - w) * g2
    dist = unnorm / (np.sum(unnorm, axis=-1, keepdims=True) + 1e-8)
    dist *= mask[..., None]
    return dist

def initialize_custom_distribution(x, mu_field, sigma_field, mask):
    # Placeholder for user-defined distributions
    raise NotImplementedError("Custom distribution initialization not implemented.")

# Dispatcher example:

def initialize_distribution(x, mu_field, sigma_field, mask, family="gaussian", **kwargs):
    if family == "gaussian":
        return initialize_gaussian_distribution(x, mu_field, sigma_field, mask)
    elif family == "uniform":
        return initialize_uniform_distribution(x, mask)
    elif family == "exponential":
        # expects lambda_field passed via mu_field
        return initialize_exponential_distribution(x, mu_field, mask)
    elif family == "beta_like":
        # expects alpha_field, beta_field in kwargs
        alpha_field = kwargs.get("alpha_field", mu_field)
        beta_field = kwargs.get("beta_field", sigma_field)
        return initialize_beta_like_distribution(x, alpha_field, beta_field, mask)
    elif family == "bimodal_gaussian":
        # expects mu2_field, sigma2_field, weight_field in kwargs
        mu2_field = kwargs.get("mu2_field")
        sigma2_field = kwargs.get("sigma2_field")
        weight_field = kwargs.get("weight_field", 0.5)
        return initialize_bimodal_gaussian_distribution(x, mu_field, sigma_field, mu2_field, sigma2_field, weight_field, mask)
    else:
        return initialize_custom_distribution(x, mu_field, sigma_field, mask)
