import numpy as np


# Cache for generated generators
_generator_cache = {}
import numpy as np

def generate_so3_real_irrep(K):
    """
    Generate real-valued, antisymmetric SO(3) irrep generators for dimension K = 2ℓ + 1.
    Output: array of shape (3, K, K)
    """
    if K % 2 == 0:
        raise ValueError("K must be odd for SO(3) irreps")
    ℓ = (K - 1) // 2

    Lp = np.zeros((K, K), dtype=complex)
    Lm = np.zeros((K, K), dtype=complex)
    Lz = np.zeros((K, K), dtype=complex)

    for m in range(-ℓ, ℓ + 1):
        i = m + ℓ
        Lz[i, i] = m
        if m < ℓ:
            j = i + 1
            coef = np.sqrt((ℓ - m) * (ℓ + m + 1))
            Lp[i, j] = coef
            Lm[j, i] = coef

    # Hermitian generators
    Lx = 0.5 * (Lp + Lm)
    Ly = -0.5j * (Lp - Lm)
    Lz = Lz

    # Convert to real antisymmetric via i·L
    T_x = (1j * Lx).real
    T_y = (1j * Ly).real
    T_z = (1j * Lz).real

    # Normalize Casimir to ℓ(ℓ+1)·I
    casimir = T_x @ T_x + T_y @ T_y + T_z @ T_z
    scale = np.sqrt(ℓ * (ℓ + 1) / np.mean(np.diag(casimir)))

    return scale * np.stack([T_x, T_y, T_z], axis=0)



def get_generators(group_name: str, K: int) -> np.ndarray:
    """
    Return the Lie algebra generators for the specified group and representation dimension.
    For 'so3', generators are now real-valued irreducible representations.
    """
    name = group_name.lower()
    key = (name, K)
    if key in _generator_cache:
        return _generator_cache[key]

    if name == "so3":
        # real-valued irreducible SO(3) rep, K = 2ℓ+1
        if K % 2 == 0:
            raise ValueError("K must be odd for SO(3) irreps (K=2ℓ+1).")
        ℓ = (K - 1) // 2
        Lx = np.zeros((K, K), dtype=float)
        Ly = np.zeros((K, K), dtype=float)
        Lz = np.zeros((K, K), dtype=float)
        for m in range(-ℓ, ℓ + 1):
            i = m + ℓ
            if i < K - 1:
                a = 0.5 * np.sqrt((ℓ - m) * (ℓ + m + 1))
                Lx[i, i + 1] = a
                Lx[i + 1, i] = a
                Ly[i, i + 1] = -a
                Ly[i + 1, i] = a
            Lz[i, i] = m
        gens = [Lx, Ly, Lz]

    elif name == "su2":
        if K % 2 == 0:
            raise ValueError("K must be odd for SU(2) irreps (K=2ℓ+1).")
        ℓ = (K - 1) // 2
        m = np.arange(ℓ, -ℓ - 1, -1)
        Jz = np.diag(m)
        Jp = np.zeros((K, K), dtype=complex)
        for i in range(K - 1):
            mm = m[i]
            Jp[i, i + 1] = np.sqrt((ℓ - mm) * (ℓ + mm + 1))
        Jm = Jp.conj().T
        Jx = 0.5 * (Jp + Jm)
        Jy = -0.5j * (Jp - Jm)
        gens = [Jx, Jy, Jz]

    elif name == "u1":
        gens = [np.eye(K, dtype=complex)]

    elif name == "sl2r":
        if K % 2 == 0:
            raise ValueError("K must be odd for SL(2,R) irreps (K=2ℓ+1).")
        ℓ = (K - 1) // 2
        L1 = np.zeros((K, K), dtype=float)
        L2 = np.zeros((K, K), dtype=float)
        L3 = np.zeros((K, K), dtype=float)
        for m in range(-ℓ, ℓ + 1):
            idx = m + ℓ
            L3[idx, idx] = m
            if idx < K - 1:
                a = np.sqrt((ℓ - m) * (ℓ + m + 1))
                L1[idx, idx + 1] = a
                L1[idx + 1, idx] = a
                L2[idx, idx + 1] = -a
                L2[idx + 1, idx] = a
        gens = [L1, L2, L3]

    else:
        raise ValueError(f"Unsupported group '{group_name}'")

    # Only non-real groups get converted to skew-Hermitian
    if name in ("su2", "u1"):
        gens = [1j * G for G in gens]

    gens = np.stack(gens, axis=0)  # shape (dim_G, K, K)
    _generator_cache[key] = gens
    return gens


def infer_lie_algebra_dim(group_name: str, K: int) -> int:
    """
    Return the dimension of the Lie algebra for the given group and rep-dimension K.
    Accepts two args so calls like infer_lie_algebra_dim(name, K) work.
    """
    name = group_name.lower()
    if name == "so3":
        return 3
    if name == "su2":
        return 3
    if name == "u1":
        return 1
    if name == "sl2r":
        return 3
    raise ValueError(f"Unknown group '{group_name}' for infer_lie_algebra_dim")
