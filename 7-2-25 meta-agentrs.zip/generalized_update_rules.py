import numpy as np
import config
from joblib import Parallel, delayed
from generalized_math_utils import sanitize_q
from generalized_omega import exp_lie_algebra_irrep
from generalized_update_terms import (
    compute_beliefs_gradient,
    compute_models_gradient,
    compute_phi_alignment_gradient,
    compute_phi_model_update,
)

def _compute_all_grads(i, agents, params):
    ai = agents[i]
    return (
        compute_beliefs_gradient(ai, agents, params),
        compute_models_gradient(ai, agents, params),
        compute_phi_alignment_gradient(ai, agents, params),
        compute_phi_model_update(ai, agents, params),
    )

def synchronous_step(agents, generators, params=None, n_jobs=1):
    """
    Perform one synchronous Euler update:
      0) Clear & precompute each agent’s exp(phi) caches
      1) Snapshot old fields
      2) Compute all gradients in parallel
      3) Load step sizes
      4) Apply updates synchronously

    Args:
        agents: list of Agent
        generators: Lie-algebra generators from get_generators(...)
        params: override parameters dict
        n_jobs: for joblib parallel
    """
    params = params or {}
    N = len(agents)

    # 0) Clear caches & precompute exp(phi) and exp(-phi)
    for A in agents:
        A.clear_omega_cache()
        
        e_belief = params.get("e_belief", config.e_belief)
        e_model  = params.get("e_model",  config.e_model)

        flat_phi       = A.phi.reshape(-1, A.phi.shape[-1]) / e_belief
        
        #print("[DEBUG] phi.shape =", A.phi.shape)  # should clarify dimensionality
        # 🔍 DEBUG: Check shape of phi and phi_model
        assert A.phi.ndim == 3, f"[phi] Expected 3D (H,W,D), got {A.phi.shape}"
        assert A.phi_model.ndim == 3, f"[phi_model] Expected 3D (H,W,D), got {A.phi_model.shape}"
        assert A.phi.shape[-1] == A.phi_model.shape[-1], f"[phi/phi_model] Last dim mismatch: {A.phi.shape} vs {A.phi_model.shape}"
        assert A.phi.shape[:-1] == A.phi_model.shape[:-1], \
            f"[phi/phi_model] Grid mismatch: {A.phi.shape[:-1]} vs {A.phi_model.shape[:-1]}"

        A.grid_shape = A.phi.shape[:-1]  # ← validated safely now
        flat_phi_model = A.phi_model.reshape(-1, A.phi_model.shape[-1]) / e_model
        A._exp_phi           = exp_lie_algebra_irrep(flat_phi,       generators)
        A._exp_neg_phi       = exp_lie_algebra_irrep(-flat_phi,      generators)
        A._exp_phi_model     = exp_lie_algebra_irrep(flat_phi_model, generators)
        A._exp_neg_phi_model = exp_lie_algebra_irrep(-flat_phi_model,generators)

    # 1) Snapshot old fields
    q_old     = [agent.q.copy()         for agent in agents]
    p_old     = [agent.p.copy()         for agent in agents]
    phi_old   = [agent.phi.copy()       for agent in agents]
    phi_m_old = [agent.phi_model.copy() for agent in agents]
    mask_list = [agent.mask            for agent in agents]

    # 2) Compute all gradients in parallel
    # Inject debug info into params if desired
    params_with_step = {**params}
    if "step_debug" not in params_with_step and "step" in params:
        params_with_step["step_debug"] = params["step"]

    q_grads, p_grads, phi_grads, phi_m_grads = zip(*Parallel(
        n_jobs=n_jobs,
        backend="threading"
    )(
        delayed(_compute_all_grads)(i, agents, params_with_step)
        for i in range(N)
    ))

    # 3) Load step sizes
    eta_q         = params.get('eta_q',         config.eta_q)
    eta_p         = params.get('eta_p',         config.eta_p)
    eta_phi       = params.get('eta_phi',       config.eta_phi)
    eta_model_phi = params.get('eta_model_phi', config.eta_model_phi)

    # 4) Apply updates synchronously
    for i, agent in enumerate(agents):
        mask = mask_list[i][..., None]

        # q update
        dq = -eta_q * q_grads[i]
        q_new = np.where(mask, q_old[i] + dq, q_old[i])
        agent.q = sanitize_q(q_new, eps=config.log_eps)

        # p update
        dp = -eta_p * p_grads[i]
        p_new = np.where(mask, p_old[i] + dp, p_old[i])
        agent.p = sanitize_q(p_new, eps=config.log_eps)

        # phi update

        dphi = eta_phi * phi_grads[i]
        mask_exp = np.broadcast_to(mask_list[i][..., None], phi_old[i].shape)
        assert mask_exp.shape == phi_old[i].shape, \
            f"[BUG] mask {mask_exp.shape} doesn’t match phi {phi_old[i].shape}"
        agent.phi = phi_old[i] + dphi * mask_exp
        agent.delta_phi = dphi * mask_exp
        #print(f"[DEBUG Δφ] max update norm = {np.max(np.linalg.norm(agent.delta_phi, axis=-1)):.5f}")
        # Debug: print norms of delta fields
        dq_norm     = np.linalg.norm(dq)
        dp_norm     = np.linalg.norm(dp)
        dphi_norm   = np.linalg.norm(dphi)
        print(f"[DEBUG Δ] Agent {i}: ‖Δq‖={dq_norm:.6f} ‖Δp‖={dp_norm:.6f} ‖Δφ‖={dphi_norm:.6f}")

        # φ_model update
        if not getattr(config, "identical_models", False):
            dphi_m = eta_model_phi * phi_m_grads[i]
            assert dphi_m.shape == phi_m_old[i].shape, \
                f"[BUG] dphi_model shape {dphi_m.shape} != phi_model shape {phi_m_old[i].shape}"
            mask_exp = np.broadcast_to(mask_list[i][..., None], phi_m_old[i].shape)
            agent.phi_model = phi_m_old[i] + dphi_m * mask_exp
            agent.delta_phi_model = dphi_m

            dphi_m_norm = np.linalg.norm(dphi_m)
            print(f"[DEBUG Δ] Agent {i}: ‖Δφ_model‖={dphi_m_norm:.6f}")


    return agents


def update_all(agents, generators, params=None, n_jobs=1):
    """
    Alias for synchronous_step with explicit generators argument.
    """
    return synchronous_step(agents, generators, params, n_jobs)