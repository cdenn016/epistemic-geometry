# epistemic_alignment.py
import numpy as np
import os
import matplotlib.pyplot as plt
from pathlib import Path

from generalized_omega import build_inter_agent_omega, batch_apply_omega
from generalized_math_utils import sanitize_q



import sys
import os
import pickle
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
from generalized_simulation import run_simulation

# Ensure we can import your suite modules
sys.path.insert(0, os.getcwd())

#from generalized_simulation import run_simulation
import config

def load_agents(checkpoint_dir):
    """Load agents from checkpoint or rerun one simulation step."""
    ckpt = os.path.join(checkpoint_dir, "step_0000.pkl")
    if os.path.isfile(ckpt):
        with open(ckpt, "rb") as f:
            agents = pickle.load(f)
    else:
        agents, _ = run_simulation(
            outdir=checkpoint_dir,
            params=None,
            n_jobs=config.num_cores
        )
    return agents

def load_per_agent_metrics(checkpoint_dir):
    """Load per_agent_metrics.csv if it exists and has the right columns."""
    csv_path = os.path.join(checkpoint_dir, "per_agent_metrics.csv")
    if os.path.isfile(csv_path):
        df = pd.read_csv(csv_path)
        if {'agent', 'kl_align'}.issubset(df.columns):
            return df
    return None



def plot_support_phi_alignment(agents, per_df):
    import matplotlib.pyplot as plt
    import numpy as np

    fig, axes = plt.subplots(1, 3, figsize=(18, 6))

    # Panel 1: Agent contours with labels
    ax0 = axes[0]
    for idx, agent in enumerate(agents):
        mask = agent.mask
        ax0.contour(mask, levels=[config.support_cutoff_eps], colors='black', linewidths=1)
        center = np.array(agent.center)
        ax0.text(center[1], center[0], str(idx), ha='center', va='center', color='red', fontsize=9, weight='bold')
    ax0.set_title("Agent Support Contours")
    ax0.axis('off')

    # Panel 2: Sum of φ norms
    ax1 = axes[1]
    combined = np.zeros(config.domain_size, dtype=float)
    for agent in agents:
        norm = np.linalg.norm(agent.phi, axis=-1)
        combined += norm
    im = ax1.imshow(combined, origin='lower')
    ax1.set_title("Sum of Φ Norms")
    ax1.axis('off')
    fig.colorbar(im, ax=ax1, fraction=0.046, pad=0.04)

    # Panel 3: KL alignment per agent
    ax2 = axes[2]
    if per_df is not None:
        last_vals = per_df.groupby('agent')['kl_align'].last()
        ax2.bar(last_vals.index, last_vals.values)
        ax2.set_xlabel("Agent Index")
        ax2.set_ylabel("KL Align")
        ax2.set_title("Alignment per Agent")
    else:
        ax2.text(0.5, 0.5, "No per-agent metrics", ha='center')
        ax2.set_title("Alignment")
        ax2.axis('off')

    plt.tight_layout()
    plt.show()



def compute_pairwise_kl(agents, generators, params):
    log_eps = params.get("log_eps", 1e-8)
    overlap_eps = params.get("overlap_eps", 1e-6)
    N = len(agents)
    kl_matrix = np.full((N, N), np.inf)

    for i in range(N):
        qi = agents[i].q
        mask_i = agents[i].mask > overlap_eps
        flat_qi = qi.reshape(-1, qi.shape[-1])

        for j in range(N):
            if i == j:
                kl_matrix[i, j] = 0.0
                continue

            qj = agents[j].q
            mask_j = agents[j].mask > overlap_eps
            overlap = mask_i & mask_j
            if not np.any(overlap):
                continue

            idxs = np.flatnonzero(overlap.reshape(-1))

            qi_vals = sanitize_q(flat_qi[idxs], eps=log_eps)
            qj_vals = sanitize_q(qj.reshape(-1, qj.shape[-1])[idxs], eps=log_eps)

            phi_i_vals = agents[i].phi.reshape(-1, agents[i].phi.shape[-1])[idxs]
            phi_j_vals = agents[j].phi.reshape(-1, agents[j].phi.shape[-1])[idxs]

            omega = build_inter_agent_omega(phi_i_vals, phi_j_vals, generators, config=params)
            qj_rot = batch_apply_omega(qj_vals, omega)
            qj_rot = sanitize_q(qj_rot, eps=log_eps)

            kl = (qi_vals * np.log(qi_vals / (qj_rot + log_eps))).sum(axis=-1).mean()
            kl_matrix[i, j] = kl

    return kl_matrix



def compute_symmetric_kl_matrix(kl_matrix):
    return 0.5 * (kl_matrix + kl_matrix.T)


def rank_agent_alignment(kl_matrix):
    rankings = {}
    for i in range(len(kl_matrix)):
        sorted_indices = np.argsort(kl_matrix[i])
        rankings[i] = {
            "best": sorted_indices[1],
            "worst": sorted_indices[-1],
            "full_rank": sorted_indices.tolist()
        }
    return rankings


def cluster_agents_dbscan(kl_matrix, eps=5.0, min_samples=2):
    from sklearn.cluster import DBSCAN
    D = 0.5 * (kl_matrix + kl_matrix.T)
    model = DBSCAN(metric="precomputed", eps=eps, min_samples=min_samples)
    return model.fit_predict(D)


def save_dbscan_clusters(labels, outdir="alignment_output"):
    Path(outdir).mkdir(exist_ok=True)
    with open(f"{outdir}/clusters.txt", "w") as f:
        for idx, label in enumerate(labels):
            f.write(f"Agent {idx}: Cluster {label}\n")


def plot_alignment_matrix(kl_matrix, outdir="alignment_output"):
    Path(outdir).mkdir(exist_ok=True)
    plt.figure(figsize=(8, 6))
    plt.imshow(kl_matrix, cmap="viridis", interpolation="nearest")
    plt.colorbar(label="D_KL(q_i || Ω q_j)")
    plt.title("Pairwise Epistemic Misalignment")
    plt.xlabel("Agent j")
    plt.ylabel("Agent i")
    plt.savefig(f"{outdir}/alignment_matrix.png")
    plt.close()


def save_alignment_data(kl_matrix, rankings, labels, outdir="alignment_output"):
    Path(outdir).mkdir(exist_ok=True)
    np.savetxt(f"{outdir}/kl_matrix.csv", kl_matrix, delimiter=",")

    with open(f"{outdir}/rankings.txt", "w") as f:
        for i, data in rankings.items():
            f.write(
                f"Agent {i}:\n"
                f"  Best: {data['best']}\n"
                f"  Worst: {data['worst']}\n"
                f"  Full rank: {data['full_rank']}\n\n"
            )

    save_dbscan_clusters(labels, outdir)


def run_alignment_analysis(agents, generators, params, threshold=5.0, outdir="alignment_output"):
    kl_matrix = compute_pairwise_kl(agents, generators, params)
    sym_kl = compute_symmetric_kl_matrix(kl_matrix)

    # Fill NaNs or infs with a large but finite number
    max_finite = np.nanmax(sym_kl[np.isfinite(sym_kl)])
    fill_value = 1.5 * max_finite if np.isfinite(max_finite) else 1e6
    sym_kl[~np.isfinite(sym_kl)] = fill_value

    # Compute rankings and cluster labels
    rankings = rank_agent_alignment(sym_kl)
    labels = cluster_agents_dbscan(sym_kl, eps=threshold)

    # Plot heatmap and network graph
    plot_alignment_matrix(sym_kl, outdir)
    plot_alignment_network(sym_kl, labels, threshold=threshold, outpath=f"{outdir}/alignment_network.png")

    # Save diagnostics
    save_alignment_data(sym_kl, rankings, labels, outdir)

    print(f"[✓] Alignment analysis completed. Results in: {outdir}/")

import matplotlib.pyplot as plt
import networkx as nx

def plot_alignment_network(kl_matrix, cluster_labels, threshold=5.0, outpath="alignment_output/alignment_network.png"):
    """
    Visualize agent alignment as a network. Edges drawn where symmetric KL < threshold.
    Nodes colored by cluster.
    """
    N = kl_matrix.shape[0]
    G = nx.Graph()

    # Add nodes with cluster labels
    for i in range(N):
        G.add_node(i, cluster=cluster_labels[i])

    # Add edges for aligned pairs
    for i in range(N):
        for j in range(i + 1, N):
            if kl_matrix[i, j] < threshold:
                G.add_edge(i, j, weight=np.exp(-kl_matrix[i, j]))  # weight = similarity

    # Layout
    pos = nx.spring_layout(G, seed=42)

    # Colors
    clusters = sorted(set(cluster_labels))
    color_map = {label: plt.cm.tab10(i % 10) for i, label in enumerate(clusters)}
    node_colors = [color_map[cluster_labels[i]] for i in range(N)]

    # Draw
    plt.figure(figsize=(8, 6))
    nx.draw_networkx_nodes(G, pos, node_color=node_colors, node_size=500, edgecolors="black")
    nx.draw_networkx_edges(G, pos, alpha=0.5)
    nx.draw_networkx_labels(G, pos, font_size=10, font_color="white")

    plt.title("Epistemic Alignment Network")
    plt.axis("off")
    Path(outpath).parent.mkdir(exist_ok=True)
    plt.savefig(outpath)
    plt.close()



# CLI/Script entry point
if __name__ == "__main__":
    from generalized_io_utils import load_final_step
    from get_generators import get_generators
    import config

    checkpoint_dir = "checkpoints"
    agents = load_final_step(checkpoint_dir)
    if agents is None:
        raise FileNotFoundError(f"No step_XXXX.pkl found in {checkpoint_dir}/")

    generators = get_generators(config.group_name, config.K)
    params = {
        "log_eps": config.log_eps,
        "overlap_eps": config.overlap_eps,
    }

    run_alignment_analysis(agents, generators, params, threshold=5.0)
    outdir = "alignment_output"  # <-- add this
    per_df = load_per_agent_metrics(checkpoint_dir)

    plot_support_phi_alignment(agents, per_df)