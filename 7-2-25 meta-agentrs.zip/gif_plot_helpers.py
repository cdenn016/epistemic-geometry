# -*- coding: utf-8 -*-
"""gif_plot_helpers.py
-----------------------------------------------------------------------
Robust per‑pixel metric helpers for visualising (PNG + GIF) diagnostics
in the Generalised Epistemic Geometry Model.  All helpers return a 2‑D
`(H, W)` array that can be turned directly into an image.  The public
`METRIC_FUNCS` dict is used by *visualize_agent_metrics.py*.

Key guarantees
--------------
* **Graceful fall‑back** – if a required object is missing (e.g. an
  agent has no neighbours) we return an all‑zero field instead of
  raising so that the visualisation loop never breaks.
* **No silent duplication** – every helper is defined exactly once.
* **Config‑aware** – group defaults come from the project‑wide
  ``config.py``; if ``config.group_name`` is absent we fall back to
  ``"sl2r"``.
-----------------------------------------------------------------------
"""
from __future__ import annotations

from pathlib import Path
from typing import Callable, Dict

import numpy as np

import config  # project‑wide configuration module
from generalized_math_utils import safe_log
from generalized_omega import batch_exp_lie_algebra_irrep
from get_generators import get_generators
from generalized_diagnostics_metrics import compute_field_strength

# ---------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------
DEFAULT_GROUP: str = getattr(config, "group_name", "sl2r")


def _unwrap_agent(agent_like):
    """Return the *Agent* even if it is wrapped in a list/tuple."""
    if hasattr(agent_like, "q"):
        return agent_like
    if isinstance(agent_like, (list, tuple)):
        for item in agent_like:
            out = _unwrap_agent(item)
            if out is not None:
                return out
    raise TypeError("Could not find Agent object in wrapper")


# ---------------------------------------------------------------------
# Metric builders – each returns an (H, W) NumPy array
# ---------------------------------------------------------------------

def mask_field(agents, idx):
    A = _unwrap_agent(agents[idx])
    return getattr(A, "mask", np.zeros_like(A.q[..., 0]))


def entropy_field(agents, idx, eps: float = 1e-12):
    A = _unwrap_agent(agents[idx])
    q = A.q
    return -np.sum(q * safe_log(q + eps), axis=-1)


def self_KL_field(agents, idx, eps: float = 1e-12):
    """KL(q || p) per pixel."""
    A = _unwrap_agent(agents[idx])
    if not hasattr(A, "p"):
        return np.zeros_like(A.q[..., 0])
    q, p = A.q, A.p
    return np.sum(q * (safe_log(q + eps) - safe_log(p + eps)), axis=-1)


def align_KL_field(agents, idx, eps: float = 1e-12):
    """KL(q_i || Ω_ij q_j) using the *first* neighbour (if any)."""
    A = _unwrap_agent(agents[idx])

    # Harvest neighbour indices (both British and US spelling accepted)
    raw = getattr(A, "neighbors", None) or getattr(A, "neighbours", None) or []
    nbr_ids = []
    for item in raw:
        if isinstance(item, (int, np.integer)):
            nbr_ids.append(int(item))
        elif isinstance(item, dict):
            nbr_ids.append(int(item.get("id", item.get("idx", -1))))

    if not nbr_ids:
        return np.zeros_like(A.mask, dtype=float)

    # Resolve neighbour Agent object
    idmap = { _unwrap_agent(a).id: _unwrap_agent(a) for a in agents }
    B = idmap.get(nbr_ids[0])
    if B is None:
        return np.zeros_like(A.mask, dtype=float)

    # Cache exp(phi) per agent to avoid repeated exponentials
    def _exp_phi(agent):
        if getattr(agent, "_exp_phi", None) is None:
            G = get_generators(getattr(agent, "group_name", DEFAULT_GROUP), agent.q.shape[-1])
            agent._exp_phi = batch_exp_lie_algebra_irrep(agent.phi, G)
        return agent._exp_phi

    omega = _exp_phi(A) @ np.linalg.inv(_exp_phi(B))  # (...,K,K)
    qB_tr = np.einsum("...ij,...j->...i", omega, B.q)
    return np.sum(A.q * (safe_log(A.q + eps) - safe_log(qB_tr + eps)), axis=-1)


def phi_norm_field(agents, idx):
    A = _unwrap_agent(agents[idx])
    return np.linalg.norm(A.phi, axis=-1)


def curv_norm_field(agents, idx):
    """‖F‖ per pixel. Works with current *dict* output or future tensor."""
    A = _unwrap_agent(agents[idx])
    G = get_generators(getattr(A, "group_name", DEFAULT_GROUP), A.q.shape[-1])
    F = compute_field_strength(A.phi, G)

    if isinstance(F, dict):  # current implementation – dict[(μ,ν)] -> (H,W)
        total = None
        for F_munu in F.values():
            total = F_munu if total is None else total + F_munu
        return total.astype(float)

    # Future: raw (H,W,K,K) tensor
    return np.linalg.norm(F, axis=(-2, -1))


# ---------------------------------------------------------------------
# Public registry – add new metrics here and they appear automatically
# ---------------------------------------------------------------------
METRIC_FUNCS: Dict[str, Callable] = {
    "mask":      mask_field,
    "entropy":   entropy_field,
    "self_KL":   self_KL_field,
    "align_KL":  align_KL_field,
    "phi_norm":  phi_norm_field,
    "curv_norm": curv_norm_field,
}

__all__ = [
    "mask_field",
    "entropy_field",
    "self_KL_field",
    "align_KL_field",
    "phi_norm_field",
    "curv_norm_field",
    "METRIC_FUNCS",
]
