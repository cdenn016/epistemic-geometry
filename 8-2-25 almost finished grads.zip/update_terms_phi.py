# -*- coding: utf-8 -*-
"""
Created on Wed Jul 23 06:38:17 2025

@author: chris and christine
"""
import numpy as np
import config
import numpy as np
from scipy.linalg import inv
from numerical_utils import safe_inv, sanitize_sigma
from generalized_omega import exp_lie_algebra_irrep, compute_curvature_gradient_analytical
from natural_gradient import dexpinv_operator, dexpinv_operator_covariance, compute_fisher_geometry_gradient, compute_inverse_fisher_field_natural
from omega import get_exp_phi
from natural_params_utils import compute_bar_eta2_qj,compute_delta_eta
from omega import d_exp_phi_exact, compute_exp_field
from numerical_utils import safe_inv, soft_clip_phi_norm
from natural_params_utils import compute_bar_eta2_qj, compute_delta_eta

#==============================================================================
#
#                    GATHER PHI GAUGE FIELD GRADIENT TERMS
#                          Beliefs and Models
#==============================================================================

from omega import d_exp_phi_exact, d_exp_phi_tilde_exact
from numerical_utils import safe_inv

def accumulate_phi_gradient_belief(agent_i, agent_j, generators, params, debug=False):
    """
    Compute and apply natural gradient:
        ∇_{φ_i} KL(q_i || Ω_ij q_j)
        ∇_{φ_j} KL(q_i || Ω_ij q_j)
    using exact ∂Ω/∂φ gradients, natural projection, and dexpinv correction.
    """
    beta = params.get("beta", config.beta)
    if beta <= 0:
        return

    eps = config.support_cutoff_eps
    joint_mask = (agent_i.mask > eps) & (agent_j.mask > eps)  # (H, W)
    joint_mask = joint_mask.astype(float)[..., None]          # (H, W, 1)

    eta1_qi, eta2_qi = agent_i.eta1_q_field, agent_i.eta2_q_field
    eta1_qj, eta2_qj = agent_j.eta1_q_field, agent_j.eta2_q_field

    exp_phi_i = agent_i._exp_phi            # (..., K, K)
    exp_phi_j = agent_j._exp_phi            # (..., K, K)
    Omega_ij  = np.einsum("...ik,...kj->...ij", exp_phi_i, np.swapaxes(exp_phi_j, -1, -2))

    # ─── Exact ∂Ω/∂φ_i^a and ∂Ω/∂φ_j^a ───
    d_exp_i = d_exp_phi_exact(agent_i.phi, generators, num_points=10)
    d_exp_j = d_exp_phi_exact(agent_j.phi, generators, num_points=10)

    d = generators.shape[0]
    dOmega_dphi_i = [np.einsum("...ik,...kj->...ij", dEi, np.swapaxes(exp_phi_j, -1, -2)) for dEi in d_exp_i]
    dOmega_dphi_j = [ -np.einsum("...ik,...kj->...ij", Omega_ij, dEj) for dEj in d_exp_j ]

    # ─── Raw gradients in φ_i, φ_j directions ───
    grad_phi_i_raw = grad_alignment_phi_i_all_directions(
        eta1_qi, eta2_qi, eta1_qj, eta2_qj,
        Omega_ij, agent_i.phi, generators,
        eps=config.eps
    )

    grad_phi_j_raw = grad_alignment_phi_j_all_directions(
        eta1_qi, eta2_qi, eta1_qj, eta2_qj,
        Omega_ij, agent_j.phi, generators,
        eps=config.eps
        )

    # ─── Project using inverse Fisher metric ───
    F_inv_i = compute_inverse_fisher_field_natural(eta2_qi, generators, mask=joint_mask[..., 0])
    F_inv_j = compute_inverse_fisher_field_natural(eta2_qj, generators, mask=joint_mask[..., 0])

    grad_phi_i_nat = np.einsum("...ab,...b->...a", F_inv_i, grad_phi_i_raw)
    grad_phi_j_nat = np.einsum("...ab,...b->...a", F_inv_j, grad_phi_j_raw)

    # ─── Apply dexpinv projection ───
    grad_phi_i = dexpinv_operator(agent_i.phi, grad_phi_i_nat, generators)
    grad_phi_j = dexpinv_operator(agent_j.phi, grad_phi_j_nat, generators)

    # ─── Regularization (on φ_i) ───
    reg_grad_i = apply_regularization_terms_lie_natural(
        agent=agent_i,
        phi_field=agent_i.phi,
        generators=generators,
        field="phi",
        params=params,
    )
    reg_grad_i *= joint_mask  # ensures spatial masking

    # ─── Final update ───
    agent_i.grad_phi += (beta * grad_phi_i + reg_grad_i) * joint_mask
    agent_j.grad_phi += beta * grad_phi_j * joint_mask

def accumulate_phi_gradient_model(agent_i, agent_j, generators, params, debug=False):
    """
    Compute and apply natural gradient:
        ∇_{φ̃_i} KL(p_i || Ω̃_ij p_j)
        ∇_{φ̃_j} KL(p_i || Ω̃_ij p_j)
    using exact ∂Ω̃/∂φ̃ gradients, Fisher projection, and dexpinv correction.
    """
    beta_model = params.get("beta_model", config.beta_model)
    if beta_model <= 0:
        return

    eps = config.support_cutoff_eps
    joint_mask = (agent_i.mask > eps) & (agent_j.mask > eps)  # (H, W)
    joint_mask = joint_mask.astype(float)[..., None]          # (H, W, 1)

    eta1_pi, eta2_pi = agent_i.eta1_p_field, agent_i.eta2_p_field
    eta1_pj, eta2_pj = agent_j.eta1_p_field, agent_j.eta2_p_field

    exp_phi_i = agent_i._exp_phi_model
    exp_phi_j = agent_j._exp_phi_model
    Omega_tilde_ij = np.einsum("...ik,...kj->...ij", exp_phi_i, np.swapaxes(exp_phi_j, -1, -2))

    # ─── Exact ∂Ω̃/∂φ̃_i^a and ∂Ω̃/∂φ̃_j^a ───
    d_exp_i = d_exp_phi_tilde_exact(agent_i.phi_model, generators, num_points=10)
    d_exp_j = d_exp_phi_tilde_exact(agent_j.phi_model, generators, num_points=10)

    d = generators.shape[0]
    dOmega_tilde_dphi_i = [np.einsum("...ik,...kj->...ij", dEi, np.swapaxes(exp_phi_j, -1, -2)) for dEi in d_exp_i]
    dOmega_tilde_dphi_j = [ -np.einsum("...ik,...kj->...ij", Omega_tilde_ij, dEj) for dEj in d_exp_j ]

    grad_phi_tilde_i_raw = grad_alignment_phi_i_all_directions(
        eta1_pi, eta2_pi, eta1_pj, eta2_pj,
        Omega_tilde_ij, agent_i.phi_model, generators,
        eps=config.eps
        )


    grad_phi_tilde_j_raw = grad_alignment_phi_j_all_directions(
        eta1_pi, eta2_pi, eta1_pj, eta2_pj,
        Omega_tilde_ij, agent_j.phi_model, generators,
        eps=config.eps
        )

    # ─── Project with inverse Fisher metric ───
    F_inv_i = compute_inverse_fisher_field_natural(eta2_pi, generators, mask=joint_mask[..., 0])
    F_inv_j = compute_inverse_fisher_field_natural(eta2_pj, generators, mask=joint_mask[..., 0])

    grad_phi_tilde_i_nat = np.einsum("...ab,...b->...a", F_inv_i, grad_phi_tilde_i_raw)
    grad_phi_tilde_j_nat = np.einsum("...ab,...b->...a", F_inv_j, grad_phi_tilde_j_raw)

    # ─── Apply dexpinv projection ───
    grad_phi_tilde_i = dexpinv_operator(agent_i.phi_model, grad_phi_tilde_i_nat, generators)
    grad_phi_tilde_j = dexpinv_operator(agent_j.phi_model, grad_phi_tilde_j_nat, generators)

    # ─── Regularization on φ̃_i ───
    reg_grad_i = apply_regularization_terms_lie_natural(
        agent=agent_i,
        phi_field=agent_i.phi_model,
        generators=generators,
        field="phi_model",
        params=params,
    )
    reg_grad_i *= joint_mask

    # ─── Final update ───
    agent_i.grad_phi_tilde += (beta_model * grad_phi_tilde_i + reg_grad_i) * joint_mask
    agent_j.grad_phi_tilde += beta_model * grad_phi_tilde_j * joint_mask



def grad_alignment_phi_i_natural_exact(
    eta1_qi, eta2_qi,
    eta1_qj, eta2_qj,
    Omega_ij,
    phi_i_vec,
    generators,
    a,
    eps=1e-8,
    quadrature_points=10
):
    """
    Compute ∂/∂φ_i^a D_KL(q_i || Ω_ij q_j) as per natural param gradient derivation.

    Shapes:
        eta1_qi, eta1_qj : (..., K)
        eta2_qi, eta2_qj : (..., K, K)
        Omega_ij         : (..., K, K)
        phi_i_vec        : (..., d) Lie algebra φ_i
        generators       : (d, K, K)
        a                : int index of generator G_a

    Returns:
        grad_phi_i_a     : (...) scalar per spatial point
    """
    from omega import d_exp_phi_exact
   

    # Step 0: Compute ∂Ω/∂φ_i^a = G_L
    d_exp_list = d_exp_phi_exact(phi_i_vec, generators, num_points=quadrature_points)
    G_L = d_exp_list[a]  # (..., K, K)

    # Step 1: Compute inverses and bar_eta2
    eta2_qi_inv = safe_inv(eta2_qi, eps=eps)                             # (..., K, K)
    eta2_qj_inv = safe_inv(eta2_qj, eps=eps)                             # (..., K, K)
    bar_eta2_qj = compute_bar_eta2_qj(eta2_qj, Omega_ij, eps=eps)       # (..., K, K)
    delta_eta = compute_delta_eta(eta1_qi, eta2_qi, eta1_qj, eta2_qj, Omega_ij, eps=eps)  # (..., K)

    # Step 2: Tr[Ω^T G_L η2qi⁻¹ bar_eta2_qj] and symmetric
    term1 = np.einsum("...ji,...im->...jm", Omega_ij, G_L)            # Ωᵀ G_L
    term1 = np.einsum("...jm,...mn->...jn", term1, eta2_qi_inv)       # ... η2qi⁻¹
    term1 = np.einsum("...jn,...nk->...jk", term1, bar_eta2_qj)       # ... bar_eta
    trace1 = np.einsum("...jj->...", term1)                           # scalar

    term2 = np.einsum("...ij,...jk->...ik", G_L, Omega_ij)            # G_Lᵀ Ω
    term2 = np.einsum("...ik,...kl->...il", term2, bar_eta2_qj)
    term2 = np.einsum("...il,...lm->...im", term2, eta2_qi_inv)
    trace2 = np.einsum("...ii->...", term2)

    term_traces = trace1 + trace2  # no minus yet

    # Step 3: −½ Tr[Ωᵀ G_L + Ω G_Lᵀ]
    sym1 = np.einsum("...ji,...im->...jm", Omega_ij, G_L)             # Ωᵀ G_L
    sym2 = np.einsum("...ij,...jm->...im", Omega_ij, G_L)             # Ω G_Lᵀ
    tr1 = np.einsum("...jj->...", sym1)
    tr2 = np.einsum("...ii->...", sym2)
    trace_sym = -0.5 * (tr1 + tr2)

    # Step 4: −¼ Δηᵀ bar_eta Ωᵀ G_L Ω η2qj⁻¹ η1qj
    v1 = np.einsum("...ij,...j->...i", eta2_qj_inv, eta1_qj)
    v2 = np.einsum("...ij,...j->...i", Omega_ij, v1)
    v3 = np.einsum("...ij,...j->...i", G_L, v2)
    v4 = np.einsum("...ij,...j->...i", Omega_ij, v3)
    v5 = np.einsum("...ij,...j->...i", bar_eta2_qj, v4)
    term3 = np.einsum("...i,...i->...", delta_eta, v5)

    # Step 5: −¼ η1qjᵀ η2qj⁻¹ G_Lᵀ bar_eta Δη
    tmp = np.einsum("...ij,...j->...i", eta2_qj_inv, eta1_qj)
    tmp = np.einsum("...ij,...j->...i", G_L, tmp)
    tmp = np.einsum("...ij,...j->...i", bar_eta2_qj, tmp)
    term4 = np.einsum("...i,...i->...", tmp, delta_eta)

    # Step 6: +¼ Δηᵀ (bar_eta Ωᵀ G_L + Ω G_Lᵀ bar_eta) Δη
    lhs = np.einsum("...ij,...jk->...ik", bar_eta2_qj, Omega_ij)
    lhs = np.einsum("...ik,...kl->...il", lhs, G_L)
    lhs = np.einsum("...ij,...j->...i", lhs, delta_eta)

    rhs = np.einsum("...ij,...jk->...ik", Omega_ij, G_L)
    rhs = np.einsum("...ik,...kl->...il", rhs, bar_eta2_qj)
    rhs = np.einsum("...ij,...j->...i", rhs, delta_eta)

    term5 = np.einsum("...i,...i->...", delta_eta, lhs + rhs)

    # Total gradient
    grad = term_traces + trace_sym - 0.25 * (term3 + term4) + 0.25 * term5
    return grad

def grad_alignment_phi_j_natural_exact(
    eta1_qi, eta2_qi,
    eta1_qj, eta2_qj,
    Omega_ij,               # (..., K, K)
    phi_j_vec,              # (..., d)
    generators,             # (d, K, K)
    a: int,                 # which ∂/∂φ_j^a
    quadrature_points=10,
    eps=1e-8
):
    """
    Exact gradient ∇_{φ_j^a} KL(q_i || Ω_ij q_j), computing dΩ/dφ_j^a internally.

    Args:
        eta1_qi, eta1_qj       : (..., K)
        eta2_qi, eta2_qj       : (..., K, K)
        Omega_ij               : (..., K, K)
        phi_j_vec              : (..., d) Lie algebra field for φ_j
        generators             : (d, K, K)
        a                      : which generator φ_j^a to differentiate
    Returns:
        grad                   : (...) scalar
    """
    from omega import d_exp_phi_exact

    # Step 0: Compute exact ∂Ω/∂φ_j^a
    d_exp_list = d_exp_phi_exact(phi_j_vec, generators, num_points=quadrature_points)
    d_Omega_d_phi_j_a = d_exp_list[a]  # (..., K, K)

    eta2_qi_inv = safe_inv(eta2_qi, eps=eps)
    eta2_qj_inv = safe_inv(eta2_qj, eps=eps)
    bar_eta = compute_bar_eta2_qj(eta2_qj, Omega_ij, eps=eps)
    delta_eta = compute_delta_eta(eta1_qi, eta2_qi, eta1_qj, eta2_qj, Omega_ij, eps=eps)

    # Compute G_eta = η2_qj⁻¹ dΩ + dΩ η2_qj⁻¹
    G_eta = (
        np.einsum("...ik,...kl->...il", eta2_qj_inv, d_Omega_d_phi_j_a) +
        np.einsum("...kl,...lj->...kj", d_Omega_d_phi_j_a, eta2_qj_inv)
    )

    # --- Term 1 ---
    tmp1 = np.einsum("...ij,...jk->...ik", G_eta, Omega_ij.swapaxes(-1, -2))
    tmp1 = np.einsum("...ik,...kl->...il", bar_eta, tmp1)
    tmp1 = np.einsum("...ij,...jk->...ik", eta2_qi_inv, tmp1)
    tmp1 = np.einsum("...ik,...kj->...ij", tmp1, bar_eta)
    term1 = np.trace(tmp1, axis1=-2, axis2=-1)

    # --- Term 2 ---
    tmp2 = np.einsum("...ij,...jk->...ik", G_eta, Omega_ij.swapaxes(-1, -2))
    tmp2 = np.einsum("...ik,...kj->...ij", bar_eta, tmp2)
    term2 = np.trace(tmp2, axis1=-2, axis2=-1)

    # --- Term 3 ---
    eta_push = np.einsum("...ij,...j->...i", eta2_qj_inv, eta1_qj)
    term3_vec = np.einsum("...ij,...j->...i", bar_eta, eta_push)
    term3_outer = np.einsum("...i,...j->...ij", term3_vec, delta_eta)
    term3_scalar = 0.25 * np.trace(
        np.einsum("...ij,...jk->...ik", term3_outer, d_Omega_d_phi_j_a),
        axis1=-2, axis2=-1
    )

    # --- Term 4 ---
    tmp4 = np.einsum("...ij,...j->...i", eta2_qj_inv, eta1_qj)
    tmp4 = np.einsum("...ij,...j->...i", d_Omega_d_phi_j_a.swapaxes(-1, -2), tmp4)
    tmp4 = np.einsum("...ij,...j->...i", bar_eta, tmp4)
    term4_scalar = np.einsum("...i,...i->...", tmp4, delta_eta)

    # --- Term 5 ---
    tmp5 = np.einsum("...ij,...jk->...ik", d_Omega_d_phi_j_a, Omega_ij.swapaxes(-1, -2))
    tmp5 = np.einsum("...ik,...kl->...il", bar_eta, tmp5)
    tmp5 = np.einsum("...ij,...jk->...ik", tmp5, bar_eta)
    tmp5_vec = np.einsum("...ij,...j->...i", tmp5, delta_eta)
    term5 = np.einsum("...i,...i->...", delta_eta, tmp5_vec)

    # --- Total gradient ---
    grad = term1 - term2 + 0.25 * (term3_scalar - term4_scalar + term5)
    return grad


def grad_alignment_phi_i_all_directions(
    eta1_qi, eta2_qi,
    eta1_qj, eta2_qj,
    Omega_ij,
    phi_i_vec,
    generators,
    eps=1e-8,
    quadrature_points=10
):
    """
    Compute all ∂/∂φ_i^a D_KL(q_i || Ω_ij q_j) for a ∈ {1,...,d}
    Returns: (..., d) array
    """
    d = generators.shape[0]
    return np.stack([
        grad_alignment_phi_i_natural_exact(
            eta1_qi, eta2_qi,
            eta1_qj, eta2_qj,
            Omega_ij,
            phi_i_vec,
            generators,
            a,
            eps=eps,
            quadrature_points=quadrature_points
        )
        for a in range(d)
    ], axis=-1)


def grad_alignment_phi_j_all_directions(
    eta1_qi, eta2_qi,
    eta1_qj, eta2_qj,
    Omega_ij,
    phi_j_vec,
    generators,
    eps=1e-8,
    quadrature_points=10
):
    """
    Compute all ∂/∂φ_j^a D_KL(q_i || Ω_ij q_j) for a ∈ {1,...,d}
    Returns: (..., d) array
    """
    d = generators.shape[0]
    return np.stack([
        grad_alignment_phi_j_natural_exact(
            eta1_qi, eta2_qi,
            eta1_qj, eta2_qj,
            Omega_ij,
            phi_j_vec,
            generators,
            a,
            eps=eps,
            quadrature_points=quadrature_points
        )
        for a in range(d)
    ], axis=-1)




#==============================================================================
#
#                    NATURAL PARAMETER GRADIENTS
#                       
#==============================================================================




def grad_alignment_phi_j_natural_exact_previous(
    eta1_qi, eta2_qi,
    eta1_qj, eta2_qj,
    Omega_ij,                     # (..., K, K)
    d_Omega_d_phi_j_a,           # (..., K, K), exact ∂Ω/∂φ_j^a
    eps=1e-8
):
    """
    Exact gradient ∇_{φ_j^a} KL(q_i || Ω_ij q_j) using numerical derivative of Ω.

    Args:
        eta1_qi, eta1_qj       : (..., K)
        eta2_qi, eta2_qj       : (..., K, K)
        Omega_ij               : (..., K, K)
        d_Omega_d_phi_j_a     : (..., K, K), exact derivative ∂Ω/∂φ_j^a
    Returns:
        grad                   : (...) scalar
    """
    eta2_qi_inv = safe_inv(eta2_qi, eps=eps)
    eta2_qj_inv = safe_inv(eta2_qj, eps=eps)
    bar_eta = compute_bar_eta2_qj(eta2_qj, Omega_ij, eps=eps)
    delta_eta = compute_delta_eta(eta1_qi, eta2_qi, eta1_qj, eta2_qj, Omega_ij, eps=eps)

    # Compute G_eta = η2_qj⁻¹ dΩ + dΩ η2_qj⁻¹ (symmetrized pushforward)
    G_eta = (
        np.einsum("...ik,...kl->...il", eta2_qj_inv, d_Omega_d_phi_j_a) +
        np.einsum("...kl,...lj->...kj", d_Omega_d_phi_j_a, eta2_qj_inv)
    )  # (..., K, K)

    # --- Term 1 ---
    tmp1 = np.einsum("...ij,...jk->...ik", G_eta, Omega_ij.swapaxes(-1, -2))
    tmp1 = np.einsum("...ik,...kl->...il", bar_eta, tmp1)
    tmp1 = np.einsum("...ij,...jk->...ik", eta2_qi_inv, tmp1)
    tmp1 = np.einsum("...ik,...kj->...ij", tmp1, bar_eta)
    term1 = np.trace(tmp1, axis1=-2, axis2=-1)

    # --- Term 2 ---
    tmp2 = np.einsum("...ij,...jk->...ik", G_eta, Omega_ij.swapaxes(-1, -2))
    tmp2 = np.einsum("...ik,...kj->...ij", bar_eta, tmp2)
    term2 = np.trace(tmp2, axis1=-2, axis2=-1)

    # --- Term 3 ---
    eta_push = np.einsum("...ij,...j->...i", eta2_qj_inv, eta1_qj)      # (..., K)
    term3_vec = np.einsum("...ij,...j->...i", bar_eta, eta_push)        # (..., K)
    term3_outer = np.einsum("...i,...j->...ij", term3_vec, delta_eta)   # (..., K, K)
    term3_scalar = 0.25 * np.trace(np.einsum("...ij,...jk->...ik", term3_outer, d_Omega_d_phi_j_a),
                                   axis1=-2, axis2=-1)

    # --- Term 4 ---
    tmp4 = np.einsum("...ij,...j->...i", eta2_qj_inv, eta1_qj)               # (..., K)
    tmp4 = np.einsum("...ij,...j->...i", d_Omega_d_phi_j_a.swapaxes(-1, -2), tmp4)  # (..., K)
    tmp4 = np.einsum("...ij,...j->...i", bar_eta, tmp4)                      # (..., K)
    term4_scalar = np.einsum("...i,...i->...", tmp4, delta_eta)

    # --- Term 5 ---
    tmp5 = np.einsum("...ij,...jk->...ik", d_Omega_d_phi_j_a, Omega_ij.swapaxes(-1, -2))
    tmp5 = np.einsum("...ik,...kl->...il", bar_eta, tmp5)
    tmp5 = np.einsum("...ij,...jk->...ik", tmp5, bar_eta)
    tmp5_vec = np.einsum("...ij,...j->...i", tmp5, delta_eta)
    term5 = np.einsum("...i,...i->...", delta_eta, tmp5_vec)

    # --- Total gradient ---
    grad = term1 - term2 + 0.25 * (term3_scalar - term4_scalar + term5)
    return grad

def grad_alignment_phi_i_natural_exact_previous(
    eta1_qi, eta2_qi,
    eta1_qj, eta2_qj,
    Omega_ij,
    d_Omega_d_phi_i_a,  # (..., K, K) = d_exp_phi_i[a] @ exp(-phi_j)
    G_a,                # (K, K), unused now unless trace_sym retained
    eps=1e-8
):
    """
    Compute ∂/∂φ_i^a D_KL(q_i || Ω_ij q_j) using exact ∂Ω/∂φ_i^a via quadrature.

    Args:
        eta1_qi, eta1_qj : (..., K)
        eta2_qi, eta2_qj : (..., K, K)
        Omega_ij         : (..., K, K)
        d_Omega_d_phi_i_a: (..., K, K), exact ∂Ω/∂φ_i^a from quadrature
        G_a              : (K, K), only used for trace_sym
    Returns:
        grad_phi_i_a     : (...) scalar per point
    """
    eta2_qi_inv = safe_inv(eta2_qi, eps=eps)
    eta2_qj_inv = safe_inv(eta2_qj, eps=eps)
    bar_eta2_qj = compute_bar_eta2_qj(eta2_qj, Omega_ij, eps=eps)
    delta_eta = compute_delta_eta(eta1_qi, eta2_qi, eta1_qj, eta2_qj, Omega_ij, eps=eps)

    # Step 1: trace terms with ∂Ω/∂φ_i^a
    # Tr[η2qi⁻¹ ∂Ω η2qj ∂Ω^T]
    tmp = np.einsum("...ik,...kl->...il", eta2_qi_inv, d_Omega_d_phi_i_a)       # (..., K, K)
    tmp = np.einsum("...il,...lm->...im", tmp, eta2_qj)                         # η2qi⁻¹ ∂Ω η2qj
    tmp = np.einsum("...im,...jm->...ij", tmp, d_Omega_d_phi_i_a)              # * ∂Ω
    trace_term = np.einsum("...ii->...", tmp)                                  # scalar

    # Step 2: term from η1_qj
    tmp = np.einsum("...ij,...j->...i", eta2_qj_inv, eta1_qj)                  # v = η2qj⁻¹ η1qj
    tmp = np.einsum("...ij,...j->...i", Omega_ij, tmp)                         # Ω v
    tmp = np.einsum("...ij,...j->...i", d_Omega_d_phi_i_a, tmp)               # dΩ v
    tmp = np.einsum("...ij,...j->...i", bar_eta2_qj, tmp)                      # bar_eta * dΩ * v
    term_eta1 = np.einsum("...i,...i->...", delta_eta, tmp)

    # Step 3: symmetric bar_eta terms
    tmp1 = np.einsum("...ik,...kl->...il", bar_eta2_qj, d_Omega_d_phi_i_a)
    tmp1 = np.einsum("...i,...il->...l", delta_eta, tmp1)

    tmp2 = np.einsum("...kl,...lj->...kj", d_Omega_d_phi_i_a, bar_eta2_qj)
    tmp2 = np.einsum("...k,...kj->...j", delta_eta, tmp2)

    sym_term = np.einsum("...l,...l->...", tmp1 + tmp2, delta_eta)

    # Optional: constant trace(G_a + G_a.T)
    trace_sym = 0.5 * np.trace(G_a + G_a.T)

    # Total
    grad = -trace_term + trace_sym + 0.25 * (term_eta1 + sym_term)
    return grad

#validated 7-26-25
def grad_alignment_phi_j_natural_LEGACY_APPROX(
    eta1_qi, eta2_qi,
    eta1_qj, eta2_qj,
    Omega_ij, G_a_R,
    eps=1e-8
):
    eta2_qi_inv = safe_inv(eta2_qi, eps=eps)        # (..., K, K)
    eta2_qj_inv = safe_inv(eta2_qj, eps=eps)        # (..., K, K)
    bar_eta = compute_bar_eta2_qj(eta2_qj, Omega_ij, eps=eps)  # (..., K, K)
    delta_eta = compute_delta_eta(eta1_qi, eta2_qi, eta1_qj, eta2_qj, Omega_ij, eps=eps)  # (..., K)

    # G_eta = η2_qj⁻¹ G_a^R + G_a^R η2_qj⁻¹
    G_eta = np.einsum("...ik,kl->...il", eta2_qj_inv, G_a_R) + \
            np.einsum("kl,...lj->...kj", G_a_R, eta2_qj_inv)  # (..., K, K)
    
    # --- Term 1 ---
    tmp1 = np.einsum("...ik,...kl->...il", Omega_ij, G_eta)                  # (..., K, K)
    tmp1 = np.einsum("...ij,...jk->...ik", tmp1, Omega_ij.swapaxes(-1, -2))  # (..., K, K)
    tmp1 = np.einsum("...ik,...kl->...il", bar_eta, tmp1)                    # (..., K, K)
    tmp1 = np.einsum("...ij,...jk->...ik", eta2_qi_inv, tmp1)                # (..., K, K)
    tmp1 = np.einsum("...ik,...kj->...ij", tmp1, bar_eta)                    # (..., K, K)
   
    term1 = np.trace(tmp1, axis1=-2, axis2=-1)                               # (...,)
   
    # --- Term 2 ---
    tmp2 = np.einsum("...ik,...kl->...il", Omega_ij, G_eta)                  # (..., K, K)
    tmp2 = np.einsum("...ij,...jk->...ik", tmp2, Omega_ij.swapaxes(-1, -2))  # (..., K, K)
    tmp2 = np.einsum("...ik,...kj->...ij", bar_eta, tmp2)                    # (..., K, K)
   
    term2 = np.trace(tmp2, axis1=-2, axis2=-1)                               # (...,)
    
    # --- Term 3 (correct order) ---
    eta_push = np.einsum("...ij,...j->...i", eta2_qj_inv, eta1_qj)     # (..., K)
    term3_vec = np.einsum("...ij,...j->...i", bar_eta, eta_push)       # (..., K)
    term3_outer = np.einsum("...i,...j->...ij", term3_vec, delta_eta)  # (..., K, K)
    OmegaG = np.einsum("...ik,kl->...il", Omega_ij, G_a_R)              # (..., K, K)
    term3_scalar = 0.25 * np.trace(np.einsum("...ij,...jk->...ik", term3_outer, OmegaG), axis1=-2, axis2=-1)

    
    # --- Term 4 ---
    tmp4 = np.einsum("...ij,...j->...i", eta2_qj_inv, eta1_qj)              # (..., K)
    tmp4 = np.einsum("jk,...k->...j", G_a_R.T, tmp4)                        # (..., K)
    tmp4 = np.einsum("...ij,...j->...i", Omega_ij.swapaxes(-1, -2), tmp4)   # (..., K)
    tmp4 = np.einsum("...ij,...j->...i", bar_eta, tmp4)                     # (..., K)
    
    term4_scalar = np.einsum("...i,...i->...", tmp4, delta_eta)
           
    # --- Term 5 ---
    tmp5 = np.einsum("...ik,...kl->...il", Omega_ij, G_eta)                 # (..., K, K)
    tmp5 = np.einsum("...ij,...jk->...ik", tmp5, Omega_ij.swapaxes(-1, -2)) # (..., K, K)
    tmp5 = np.einsum("...ik,...kl->...il", bar_eta, tmp5)                  # (..., K, K)
    tmp5 = np.einsum("...ij,...jk->...ik", tmp5, bar_eta)                  # (..., K, K)
    
    tmp5_vec = np.einsum("...ij,...j->...i", tmp5, delta_eta)              # (..., K)
   
    term5 = np.einsum("...i,...i->...", delta_eta, tmp5_vec)               # (...,)
    
    # --- Final Gradient ---
    grad = term1 - term2 + 0.25 * (term3_scalar - term4_scalar + term5)
   
    return grad

#Validated 7-26-25
def grad_alignment_phi_i_natural_LEGACY_APPROX(
    eta1_qi, eta2_qi,
    eta1_qj, eta2_qj,
    Omega_ij,
    G_a,  # generator G_a (K,K)
    eps=1e-8
):
    """
    Compute ∂/∂φ_i^a D_KL(q_i || Ω_ij q_j) as per natural param gradient derivation.

    Shapes:
        eta1_qi, eta1_qj : (..., K)
        eta2_qi, eta2_qj : (..., K, K)
        Omega_ij         : (..., K, K)
        G_a              : (K, K)
    Returns:
        grad_phi_i_a     : (...) scalar per spatial point
    """
    # Step 1: Compute inverses and bar_eta2
    eta2_qi_inv = safe_inv(eta2_qi, eps=eps)                             # (..., K, K)
    eta2_qj_inv = safe_inv(eta2_qj, eps=eps)                             # (..., K, K)
    bar_eta2_qj = compute_bar_eta2_qj(eta2_qj, Omega_ij, eps=eps)       # (..., K, K)
    delta_eta = compute_delta_eta(eta1_qi, eta2_qi, eta1_qj, eta2_qj, Omega_ij, eps=eps)  # (..., K)

    # Step 2: Tr[G_a η2qi⁻¹ bar_eta2_qj] and symmetric term
    term1 = np.einsum("kl,...lm->...km", G_a, eta2_qi_inv)              # G_a η2qi⁻¹
    term1 = np.einsum("...km,...mn->...kn", term1, bar_eta2_qj)        # (..., K, K)
    trace1 = np.einsum("...kk->...", term1)                             # scalar trace

    term2 = np.einsum("lk,...lm->...km", G_a, bar_eta2_qj)             # G_a^T bar_eta
    term2 = np.einsum("...km,...mn->...kn", term2, eta2_qi_inv)
    trace2 = np.einsum("...kk->...", term2)

    term_traces = -trace1 - trace2                                     # (−) first boxed term

    # Step 3: Tr(G_a + G_a^T)
    trace_sym = 0.5 * np.trace(G_a + G_a.T)                             # scalar

    # Step 4: Δηᵀ bar_eta G_a Ω η2_qj⁻¹ η1_qj
    tmp1 = np.einsum("...kl,...l->...k", eta2_qj_inv, eta1_qj)          # (..., K)
    tmp1 = np.einsum("...kl,...l->...k", Omega_ij, tmp1)                # Ω η2⁻¹ η1
    tmp1 = np.einsum("kl,...l->...k", G_a, tmp1)                        # G_a Ω η2⁻¹ η1
    tmp1 = np.einsum("...kl,...l->...k", bar_eta2_qj, tmp1)             # bar_eta G_a ...
    term3 = np.einsum("...k,...k->...", delta_eta, tmp1)                # scalar dot

    # Step 5: η1^T η2⁻¹ Ωᵀ G_a^T bar_eta Δη
    tmp = np.einsum("...ij,...j->...i", eta2_qj_inv, eta1_qj)                 # v1
    tmp = np.einsum("...ji,...i->...j", Omega_ij, tmp)                        # v2
    tmp = np.einsum("ij,...j->...i", G_a.T, tmp)                              # v3
    tmp = np.einsum("...ij,...j->...i", bar_eta2_qj, tmp)                     # v4
    term4 = np.einsum("...i,...i->...", delta_eta, tmp)                       # final contraction


    # Step 6: Δηᵀ (bar_eta G_a + G_a^T bar_eta) Δη
    # Step 6: Δηᵀ (bar_eta G_a + G_a^T bar_eta) Δη

    # First term: bar_eta @ G_a
    tmp1 = np.einsum("...kl,lj->...kj", bar_eta2_qj, G_a)        # (..., K, K)
    tmp1 = np.einsum("...k,...kj->...j", delta_eta, tmp1)        # (..., K)

    # Second term: G_a.T @ bar_eta
    tmp2 = np.einsum("lk,...kl->...l", G_a, bar_eta2_qj)         # (..., K)
    tmp2 = np.einsum("...l,...l->...", delta_eta, tmp2)          # scalar

    # Final contraction
    term5 = np.einsum("...j,...j->...", delta_eta, tmp1) + tmp2


    # Total
    grad = term_traces + trace_sym + 0.25 * (term3 + term4 + term5)
    return grad



def apply_regularization_terms(
    phi, phi_tilde, generators,
    curv_weight, mass_weight, coupling_weight,
    morphism=None, fiber="phi",   # use "phi" or "phi_model"
    agent_i=None, agents=None,
    fisher_weight=0.0, params=None,
    eps=1e-8
):
    """
    Compute total φ or φ̃ regularization gradient in natural (Lie algebra) coordinates.
    Includes curvature, mass, φ–φ̃ coupling, and Fisher geometry terms.
    Uses provided `generators` and supports proper morphism conjugation.
    """
    if (
        curv_weight == 0 and
        mass_weight == 0 and
        coupling_weight == 0 and
        fisher_weight == 0
    ):
        
        return np.zeros_like(phi)

    grad_euclidean = np.zeros_like(phi)

    if curv_weight > 0:
        grad_curv = compute_curvature_gradient_analytical(phi, generators)
        grad_euclidean += curv_weight * grad_curv

    if mass_weight > 0:
        grad_mass = 2 * phi
        grad_euclidean += mass_weight * grad_mass

    if fisher_weight > 0 and agent_i is not None and agents is not None:
        grad_fisher = compute_fisher_geometry_gradient(agent_i, agents, params, field=fiber)
       # print(f"[REG] Fisher term:      ||∇|| = {np.linalg.norm(grad_fisher):.5e}")
        grad_euclidean += grad_fisher  # already weighted inside the function

    #print("[REG] Fisher Euclidean norm:", np.linalg.norm(grad_euclidean))
    grad_natural = dexpinv_operator(phi, grad_euclidean, generators)
    #print("[REG] Fisher Natural norm:", np.linalg.norm(grad_natural))

    return grad_natural


def push_phi_conjugate_transpose(phi_src, morphism, generators_src):
    """
    Conjugate-push φ from source fiber to target fiber using morphism Φ:
        Φ φ Φᵀ

    Args:
        phi_src        : (..., d_src)              # Lie algebra coordinates
        morphism       : (..., K_tgt, K_src)       # Φ: B_src → B_tgt
        generators_src : (d_src, K_src, K_src)     # 𝔤_src → End(B_src)

    Returns:
        pushed_phi     : (..., K_tgt, K_tgt)       # matrix in End(B_tgt)
    """
    # Step 1: Convert φ vector → matrix in B_src
    phi_matrix = np.einsum("...a,aij->...ij", phi_src, generators_src)  # (..., K_src, K_src)

    # Step 2: Conjugate-pushforward to B_tgt
    tmp   = np.einsum("...ik,...kl->...il", morphism, phi_matrix)       # (..., K_tgt, K_src)
    phi_tgt = np.einsum("...il,...jl->...ij", tmp, morphism)            # (..., K_tgt, K_tgt)

    return phi_tgt



def compute_phi_coupling_gradient_belief_frame(phi, phi_tilde, Phi_tilde):
    """
    Gradient in belief fiber (φ-space):
        ∇ = 2 · (φ - Φ̃ φ̃ Φ̃ᵗ)
    """
    phi_tilde_up = push_phi_conjugate_transpose(phi_tilde, Phi_tilde)
    return 2.0 * (phi - phi_tilde_up)



def compute_phi_coupling_gradient_model_frame(phi, phi_tilde, Phi):
    """
    Gradient in model fiber (φ̃-space):
        ∇ = 2 · (φ̃ - Φ φ Φᵗ)
    """
    phi_down = push_phi_conjugate_transpose(phi, Phi)
    return 2.0 * (phi_tilde - phi_down)

def apply_regularization_terms_lie_natural(
    agent,
    phi_field,
    generators,
    field,  # "phi" or "phi_model"
    params,
):
    """
    Compute φ or φ̃ regularization gradient in natural coordinates using agent-local fields.

    Args:
        agent      : the Agent object
        phi_field  : (..., K, K) — φ or φ̃ (current field)
        generators : dict of Lie generators for the current fiber
        field      : "phi" or "phi_model"
        params     : dict of simulation/config params

    Returns:
        grad_nat   : (..., d) — projected natural gradient
    """
       

    coupling_weight = params.get("phi_phi_tilde_coupling", config.phi_phi_tilde_coupling)
    eps             = params.get("eps", config.eps)

    if field == "phi":
        curv_weight     = params.get("curvature_weight", config.curvature_weight)
        fisher_weight   = params.get("phi_fisher_weight", config.fisher_geometry_weight)
        mass_weight = params.get("phi_mass_weight", config.belief_mass)
        phi         = phi_field
        phi_tilde   = agent.phi_model
        morphism    = agent.bundle_morphism_q_to_p
        fiber       = "belief"
    elif field == "phi_model":
        curv_weight     = params.get("curvature_weight", config.model_curvature_weight)
        fisher_weight   = params.get("phi_fisher_weight", config.fisher_model_geometry_weight)
        mass_weight = params.get("phi_model_mass_weight", config.model_mass)
        phi         = phi_field
        phi_tilde   = agent.phi
        morphism    = agent.bundle_morphism_p_to_q
        fiber       = "model"
    else:
        raise ValueError(f"Invalid field name: {field}")


    return apply_regularization_terms(
        phi=phi,
        phi_tilde=phi_tilde,
        generators=generators,
        curv_weight=curv_weight,
        mass_weight=mass_weight,
        coupling_weight=coupling_weight,
        morphism=morphism,
        fiber=fiber,
        agent_i=agent,
        agents=params.get("agents", None),
        fisher_weight=fisher_weight,
        params=params,
        eps=eps,
    )
