# -*- coding: utf-8 -*-
"""
Created on Wed Aug  6 12:27:32 2025

@author: chris and christine
"""

import numpy as np
import config
from numerical_utils import sanitize_sigma, safe_batch_inverse
from natural_gradient import apply_natural_gradient_batch
from bundle_morphism_utils import pushforward_gaussian

# ---- cached exp(φ) helpers (reuse omega.py cache path) ----
try:
    # prefer the shared cache if available
    from omega import get_E_grid_from_phi
except ImportError:
    # minimal fallback: compute without cache
    from omega import exp_lie_algebra_irrep
    def get_E_grid_from_phi(phi, generators, *, group_name="so3", sign=+1, cache_tag=None):
        phi = np.asarray(phi, dtype=np.float32)
        generators = np.asarray(generators, dtype=np.float32)
        d = phi.shape[-1]
        Eflat = exp_lie_algebra_irrep((sign * phi).reshape(-1, d), generators,
                                      group_name=group_name, parallelize_expm=False)
        K = Eflat.shape[-1]
        return Eflat.reshape(*phi.shape[:-1], K, K).astype(np.float32, copy=False)


# -------------------------------------------------------------------------
#                          PUBLIC ENTRYPOINTS
# -------------------------------------------------------------------------

def accumulate_mu_sigma_gradient(agent_i, agents, params, mode):
    """
    Accumulate natural gradient ∇μ and ∇Σ for belief or model.

    Args:
        agent_i : current agent
        agents  : list of all agents
        params  : simulation parameters (must include 'step' for cache tagging)
        mode    : "belief" or "model"
    """
    # Euclidean gradients of your energy terms
    dmu, dsigma = compute_mu_sigma_gradient_euclidean(agent_i, agents, params, mode)

    if mode == "belief":
        mu_field    = agent_i.mu_q_field
        sigma_field = agent_i.sigma_q_field
        grad_mu_attr    = "grad_mu_q"
        grad_sigma_attr = "grad_sigma_q"
    elif mode == "model":
        mu_field    = agent_i.mu_p_field
        sigma_field = agent_i.sigma_p_field
        grad_mu_attr    = "grad_mu_p"
        grad_sigma_attr = "grad_sigma_p"
    else:
        raise ValueError(f"Unsupported mode: {mode}")

    # Natural-gradient projection on the Gaussian manifold
    delta_mu, delta_sigma = apply_natural_gradient_batch(
        mu_field,
        sigma_field,
        dmu,
        dsigma,
        mask=agent_i.mask,
    )

    # Initialize accumulators if missing
    if not hasattr(agent_i, grad_mu_attr) or getattr(agent_i, grad_mu_attr) is None:
        setattr(agent_i, grad_mu_attr, np.zeros_like(mu_field, dtype=np.float32))
    if not hasattr(agent_i, grad_sigma_attr) or getattr(agent_i, grad_sigma_attr) is None:
        setattr(agent_i, grad_sigma_attr, np.zeros_like(sigma_field, dtype=np.float32))

    # Accumulate
    setattr(agent_i, grad_mu_attr,    getattr(agent_i, grad_mu_attr)    + delta_mu)
    setattr(agent_i, grad_sigma_attr, getattr(agent_i, grad_sigma_attr) + delta_sigma)


def compute_mu_sigma_gradient_euclidean(agent_i, agents, params, mode):
    """
    Compose the Euclidean gradients from:
      - self KL term
      - feedback KL term
      - neighbor alignment term
      - (optional) entropy regularizer for belief Σ
    """
    eps = float(getattr(config, "eps", 1e-8))
    support_eps = float(getattr(config, "support_cutoff_eps", 1e-4))
    step_tag = params.get("step", None)

    
    if mode == "belief":
        alpha  = float(params.get("alpha", getattr(config, "alpha", 1.0)))
        beta   = float(params.get("beta", getattr(config, "beta", 0.0)))
        lambd  = float(params.get("feedback_weight", getattr(config, "feedback_weight", 0.0)))

        mu_q,  sigma_q  = agent_i.mu_q_field, agent_i.sigma_q_field
        mu_p,  sigma_p  = agent_i.mu_p_field, agent_i.sigma_p_field
        Phi, Phi_tilde  = agent_i.bundle_morphism_q_to_p, agent_i.bundle_morphism_p_to_q

        # pushforwards along bundle morphisms (p→q and q→p)
        mu_p_push, sigma_p_push, sigma_p_push_inv = pushforward_gaussian(mu_p, sigma_p, Phi_tilde, eps=eps)
        mu_q_push, sigma_q_push, sigma_q_push_inv = pushforward_gaussian(mu_q, sigma_q, Phi,       eps=eps)

        grad_self_mu, grad_self_sigma = grad_self_energy_belief(
            mu_q, sigma_q, mu_p_push, sigma_p_push_inv, eps=eps
        )
        grad_fb_mu, grad_fb_sigma = grad_feedback_energy_belief(
            mu_q, sigma_q,
            mu_p, mu_q_push, sigma_q_push, sigma_q_push_inv,
            sigma_p, Phi, eps=eps
        )

        # alignment fiber, fields, and generators
        fiber     = "q"
        mu_key    = "mu_q_field"
        sigma_key = "sigma_q_field"
        generators = getattr(agent_i, "generators_q", None)

    elif mode == "model":
        alpha  = float(params.get("alpha", getattr(config, "alpha", 1.0)))
        beta   = float(params.get("beta_model", getattr(config, "beta_model", 0.0)))
        lambd  = float(params.get("feedback_weight", getattr(config, "feedback_weight", 0.0)))

        mu_p,  sigma_p  = agent_i.mu_p_field, agent_i.sigma_p_field
        mu_q,  sigma_q  = agent_i.mu_q_field, agent_i.sigma_q_field
        Phi, Phi_tilde  = agent_i.bundle_morphism_q_to_p, agent_i.bundle_morphism_p_to_q

        mu_p_push, sigma_p_push, sigma_p_push_inv = pushforward_gaussian(mu_p, sigma_p, Phi_tilde, eps=eps)
        mu_q_push, sigma_q_push, sigma_q_push_inv = pushforward_gaussian(mu_q, sigma_q, Phi,       eps=eps)

        grad_self_mu, grad_self_sigma = grad_self_energy_model(
            mu_q, sigma_q, mu_p_push, sigma_p_push_inv, Phi_tilde, eps=eps
        )
        grad_fb_mu, grad_fb_sigma = grad_feedback_energy_model(
            mu_p, sigma_p,
            mu_q_push, sigma_q_push, sigma_q_push_inv,
            Phi, eps=eps
        )

        fiber     = "p"
        mu_key    = "mu_p_field"
        sigma_key = "sigma_p_field"
        generators = getattr(agent_i, "generators_p", None)

    else:
        raise ValueError(f"Unsupported mode: {mode}")

    if generators is None:
        # fall back to building generators once for this fiber size
        from get_generators import get_generators
        K = getattr(agent_i, sigma_key).shape[-1]
        generators, _ = get_generators(config.group_name, K, return_meta=True)

    mask_i = (np.asarray(agent_i.mask) > support_eps)
    # -------------------- neighbor alignment --------------------
    dmu_align    = np.zeros_like(getattr(agent_i, mu_key),    dtype=np.float32)
    dsigma_align = np.zeros_like(getattr(agent_i, sigma_key), dtype=np.float32)

    nb_list = getattr(agent_i, "neighbors", []) or []
    if nb_list:
        # prepare E_i and use sign-aware cache (step_tag)
        phi_i = agent_i.phi if fiber == "q" else agent_i.phi_model
        E_i   = get_E_grid_from_phi(phi_i, generators, group_name=config.group_name, sign=+1, cache_tag=step_tag)

        for nb in nb_list:
            j = nb["id"]
            agent_j = agents[j]
            mask_j = (np.asarray(agent_j.mask) > support_eps)
            overlap = mask_i & mask_j
            if not np.any(overlap):
                continue

            # E_{-j}
            phi_j = agent_j.phi if fiber == "q" else agent_j.phi_model
            E_mj  = get_E_grid_from_phi(phi_j, generators, group_name=config.group_name, sign=-1, cache_tag=step_tag)

            # Ω_ij = E_i E_{-j} on full grid, slice by overlap when needed
            Omega_ij = np.einsum("...ik,...kj->...ij", E_i, E_mj, optimize=True)

            # Transport neighbor (μ_j, Σ_j) → i via unified Gaussian pushforward
            mu_j    = getattr(agent_j, mu_key)
            sigma_j = getattr(agent_j, sigma_key)
            mu_j_t, sigma_j_t, sigma_j_t_inv = pushforward_gaussian(mu_j, sigma_j, Omega_ij, eps=eps)

            # Source fields for i (μ_i, Σ_i) on the same fiber
            mu_i    = getattr(agent_i, mu_key)
            sigma_i = getattr(agent_i, sigma_key)

            dmu_i, dsigma_i = grad_alignment_energy_source(
                mu_i, sigma_i, mu_j_t, sigma_j_t_inv, eps=eps
            )

            # accumulate on overlap only
            dmu_align[overlap]    += dmu_i[overlap]
            dsigma_align[overlap] += dsigma_i[overlap]

    # total
    dmu_total    = alpha * grad_self_mu + lambd * grad_fb_mu + beta * dmu_align
    dsigma_total = alpha * grad_self_sigma + lambd * grad_fb_sigma + beta * dsigma_align

    # entropy regularization (belief Σ only)
    if mode == "belief":
        dsigma_total = accumulate_entropy_sigma_gradient(agent_i, dsigma_total, params)

    # safety
    dmu_total    = np.nan_to_num(dmu_total,    nan=0.0, posinf=0.0, neginf=0.0).astype(np.float32, copy=False)
    dsigma_total = 0.5 * (dsigma_total + np.swapaxes(dsigma_total, -1, -2))
    dsigma_total = np.nan_to_num(dsigma_total, nan=0.0, posinf=0.0, neginf=0.0).astype(np.float32, copy=False)

    return dmu_total, dsigma_total


def accumulate_entropy_sigma_gradient(agent_i, grad_sigma_q, params):
    """
    Add entropy regularization to the Σ-gradient.

    Convention (default):
        E_total = E_other - gamma * H[q]
      ⇒ ∇_Σ E_total = ∇_Σ E_other - gamma * ∇_Σ H
      ⇒ with ∇_Σ H = ½ Σ^{-1}

    You can override the sign via params["entropy_in_energy_sign"] ∈ {+1, -1}.
    Use +1 if energy includes +gamma * H (penalty),
    use -1 if it includes -gamma * H (reward; default).
    """
    gamma = float(params.get("entropy_weight", getattr(config, "entropy_weight", 0.0)))
    if gamma == 0.0:
        return grad_sigma_q

    s = int(params.get("entropy_in_energy_sign", -1))
    sigma_q = sanitize_sigma(np.asarray(agent_i.sigma_q_field, dtype=np.float32), strict=True)
    grad_H  = 0.5 * safe_batch_inverse(sigma_q)

    mask = (np.asarray(agent_i.mask) > float(getattr(config, "support_cutoff_eps", 0.0)))[..., None, None]
    grad_H = grad_H * mask

    out = grad_sigma_q + gamma * s * grad_H
    out = 0.5 * (out + np.swapaxes(out, -1, -2))
    return out.astype(np.float32, copy=False)


#==============================================================================
#
#                    FEEDBACK / SELF TERMS (unchanged math, safer numerics)
#==============================================================================

def grad_alignment_energy_source(mu_i, sigma_i, mu_j_t, sigma_j_t_inv, eps=1e-8):
    delta_mu = mu_i - mu_j_t
    grad_mu = np.einsum("...ij,...j->...i", sigma_j_t_inv, delta_mu, optimize=True)

    # sanitize once per call
    sigma_i = sanitize_sigma(np.asarray(sigma_i, dtype=np.float32), strict=True)
    sigma_i_inv = safe_batch_inverse(sigma_i)

    grad_sigma = 0.5 * (sigma_j_t_inv - sigma_i_inv)
    grad_sigma = 0.5 * (grad_sigma + np.swapaxes(grad_sigma, -1, -2))
    return grad_mu.astype(np.float32, copy=False), grad_sigma.astype(np.float32, copy=False)


def grad_feedback_energy_belief(mu_q, sigma_q, mu_p, mu_q_push,
                                sigma_q_push, sigma_q_push_inv, sigma_p, Phi, eps=1e-8):
    delta_mu = mu_p - mu_q_push
    tmp = np.einsum("...ij,...j->...i", sigma_q_push_inv, delta_mu, optimize=True)
    grad_mu = -np.einsum("...ji,...j->...i", Phi, tmp, optimize=True)

    A = np.einsum("...i,...j->...ij", delta_mu, delta_mu, optimize=True)

    term1 = sigma_q_push_inv
    term2 = np.einsum("...ik,...kl,...lj->...ij", sigma_q_push_inv, A,       sigma_q_push_inv, optimize=True)
    term3 = np.einsum("...ik,...kl,...lj->...ij", sigma_q_push_inv, sigma_p, sigma_q_push_inv, optimize=True)
    M = term1 - term2 - term3

    grad_sigma = 0.5 * np.einsum("...ki,...kl,...lj->...ij", Phi, M, Phi, optimize=True)
    grad_sigma = 0.5 * (grad_sigma + np.swapaxes(grad_sigma, -1, -2))
    return grad_mu.astype(np.float32, copy=False), grad_sigma.astype(np.float32, copy=False)


def grad_feedback_energy_model(mu_p, sigma_p, mu_q_push,
                               sigma_q_push, sigma_q_push_inv, Phi=None, eps=1e-8):
    sigma_q_push = sanitize_sigma(np.asarray(sigma_q_push, dtype=np.float32), strict=True)
    if sigma_q_push_inv is None:
        sigma_q_push_inv = safe_batch_inverse(sigma_q_push)

    delta_mu = mu_p - mu_q_push
    grad_mu = np.einsum("...ij,...j->...i", sigma_q_push_inv, delta_mu, optimize=True)

    sigma_p = sanitize_sigma(np.asarray(sigma_p, dtype=np.float32), strict=True)
    sigma_p_inv = safe_batch_inverse(sigma_p)

    grad_sigma = 0.5 * (sigma_q_push_inv - sigma_p_inv)
    grad_sigma = 0.5 * (grad_sigma + np.swapaxes(grad_sigma, -1, -2))
    return grad_mu.astype(np.float32, copy=False), grad_sigma.astype(np.float32, copy=False)


def grad_self_energy_belief(mu_q, sigma_q, mu_p_push, sigma_p_push_inv, eps=1e-8, mask=None):
    delta_mu = mu_q - mu_p_push
    grad_mu = np.einsum("...ij,...j->...i", sigma_p_push_inv, delta_mu, optimize=True)

    sigma_q = sanitize_sigma(np.asarray(sigma_q, dtype=np.float32), strict=True)
    sigma_q_inv = safe_batch_inverse(sigma_q)

    grad_sigma = 0.5 * (sigma_p_push_inv - sigma_q_inv)
    grad_sigma = 0.5 * (grad_sigma + np.swapaxes(grad_sigma, -1, -2))

    if mask is not None:
        m = (np.asarray(mask) > float(getattr(config, "support_cutoff_eps", 0.0)))
        grad_mu    = grad_mu * m[..., None]
        grad_sigma = grad_sigma * m[..., None, None]

    return grad_mu.astype(np.float32, copy=False), grad_sigma.astype(np.float32, copy=False)


def grad_self_energy_model(mu_q, sigma_q, mu_p_push, sigma_p_push_inv, Phi_tilde, eps=1e-8, mask=None):
    """
    ∂ wrt (μ_p, Σ_p) of KL(q || Φ̃·p), with A = Φ̃ Σ_p Φ̃ᵀ and Δ = μ_q − μ_p^t.
    """
    delta_mu = mu_q - mu_p_push
    tmp = np.einsum("...ij,...j->...i", sigma_p_push_inv, delta_mu, optimize=True)
    grad_mu = -np.einsum("...ji,...j->...i", Phi_tilde, tmp, optimize=True)

    delta_mu_outer = np.einsum("...i,...j->...ij", delta_mu, delta_mu, optimize=True)

    M = sigma_p_push_inv
    G = M - np.einsum("...ik,...kl,...lj->...ij", M, delta_mu_outer, M, optimize=True) \
          - np.einsum("...ik,...kl,...lj->...ij", M, sigma_q,        M, optimize=True)

    Phi_tilde_T = np.swapaxes(Phi_tilde, -1, -2)
    grad_sigma = 0.5 * np.einsum("...ki,...ij,...jl->...kl", Phi_tilde_T, G, Phi_tilde, optimize=True)
    grad_sigma = 0.5 * (grad_sigma + np.swapaxes(grad_sigma, -1, -2))  # symmetrize

    if mask is not None:
        m = (np.asarray(mask) > float(getattr(config, "support_cutoff_eps", 0.0)))
        grad_mu    = grad_mu * m[..., None]
        grad_sigma = grad_sigma * m[..., None, None]

    return grad_mu.astype(np.float32, copy=False), grad_sigma.astype(np.float32, copy=False)
