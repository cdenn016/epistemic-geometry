# -*- coding: utf-8 -*-
"""
Created on Wed Jul 23 10:32:58 2025

@author: chris and christine
"""

import config
from detector import DetectorState, _detect_regions_pure
from parent_spawn import _apply_spawn_from_regions
from runtime_context import _Dirty
from bundle_morphism_utils import recompute_agent_morphisms, mark_morphism_dirty
from update_compute_all_gradients import ( 
                        _apply_children, _compute_child_grads, _parent_intrascale_grad_pass, 
                        _final_apply_parents)

from update_rules_utils import ( _pre_light,  _post_strict,
                                 _assign_children_to_parents, 
                                 _as_parent_dict, prune_orphan_parents, compute_and_set_auto_agree_gate )

from update_rules_utils import ( build_alignment_aggregates, take_dirty, _post_strict_subset,
                                mark_dirty, _refresh_child_kl_fields_subset, 
                                assign_parent_masks_from_alignment,  _invalidate_transport_caches)
from viz_lambda import save_lambda_images_from_ctx
from update_rules_utils import build_all_omega_caches
from update_rules_utils import ensure_spawn_alignment_caches
from bundle_coarsegrain_init import _periodic_parent_coarsegrain
from parent_semantics import reconcile_parent_masks_and_assignments
from preprocess_utils import build_all_lambda_caches, attach_parent_lambda_views




def synchronous_step(agents, generators_q, generators_p, params=None, n_jobs=1, runtime_ctx=None):
    assert runtime_ctx is not None, "synchronous_step: pass runtime_ctx"
    assert agents and (len(agents) > 0), "synchronous_step: no agents"
    params = params or {}

    # --------------------------- CTX INIT -----------------------------------
    if not hasattr(runtime_ctx, "detector_state") or (runtime_ctx.detector_state is None):
        runtime_ctx.detector_state = DetectorState()
    if not hasattr(runtime_ctx, "global_step"):
        runtime_ctx.global_step = 0
    if not hasattr(runtime_ctx, "parents_by_region") or (runtime_ctx.parents_by_region is None):
        runtime_ctx.parents_by_region = {}
    else:
        runtime_ctx.parents_by_region = _as_parent_dict(runtime_ctx.parents_by_region)
    if not hasattr(runtime_ctx, "next_parent_id"):
        runtime_ctx.next_parent_id = 0
    if not hasattr(runtime_ctx, "dirty"):
        runtime_ctx.dirty = _Dirty()
    if not hasattr(runtime_ctx, "cache_version"):
        runtime_ctx.cache_version = 0

    # lazy import the unified refresh orchestrator
    try:
        from preprocess_utils import ensure_transforms
    except Exception:
        ensure_transforms = None

    step_now = int(getattr(runtime_ctx, "global_step", 0))
    frozen_levels     = set(params.get("frozen_levels", []))
    frozen_phi_levels = set(params.get("frozen_phi_levels", []))

    # =========================== PRE (light) ================================
    parents = [p for p in runtime_ctx.parents_by_region.values() if p is not None]
    all_agents = [a for a in (agents + parents) if a is not None]
    _pre_light(all_agents, params, generators_q, generators_p)

    # ======================= CHILD GRADS/APPLY ==============================
    grads = _compute_child_grads(agents, all_agents, generators_q, generators_p, params)
    _apply_children(agents, grads, params, frozen_levels, frozen_phi_levels,
                    generators_q, generators_p, n_jobs)

    # mark children dirty (fields + KL need refresh)
    for a in agents:
        mark_dirty(runtime_ctx, a, kl=True)

    # strict subset field refresh (children only)
    dirty_children = [a for a in take_dirty(runtime_ctx, agents, which="agents") if a is not None]
    if dirty_children and ensure_transforms is not None:
        ensure_transforms(dirty_children, generators_q, generators_p, params)
        runtime_ctx.cache_version += 1

    # refresh KL for only dirty children vs current agents (kids + parents)
    dirty_children_kl = [a for a in take_dirty(runtime_ctx, agents, which="kl") if a is not None]
    if dirty_children_kl:
        _refresh_child_kl_fields_subset(
            dirty_children_kl,
            [a for a in (agents + list(runtime_ctx.parents_by_region.values())) if a is not None],
            eps=getattr(config, "eps", 1e-6),
            build_spawn=False,   # don't build spawn caches here
        )

    # ================ ALIGNMENT AGGREGATES + AUTO GATE ======================
    try:
        build_alignment_aggregates(runtime_ctx, agents)
        if getattr(config, "detector_agree_auto", True):
            compute_and_set_auto_agree_gate(
                runtime_ctx,
                percentile=float(getattr(config, "detector_agree_percentile", 65.0)),
                ema=float(getattr(config, "detector_agree_ema", 0.2))
            )
    except Exception as e:
        if getattr(config, "debug_strict", True):
            print(f"[AGG] skipped: {e}")

    if getattr(config, "debug_detector_log", True):
        import numpy as _np
        A = getattr(runtime_ctx, "Aq_agg", None)
        if A is not None:
            print(f"[AGG] Aq_agg mean={float(_np.nanmean(A)):.3f} max={float(_np.nanmax(A)):.3f}")

    # === SPAWN CACHES (on-demand, only for changed children) ================
    ensure_spawn_alignment_caches(
        agents,
        [a for a in (agents + list(runtime_ctx.parents_by_region.values())) if a is not None],
        runtime_ctx,
        generators_q=generators_q,
        generators_p=generators_p,
        use_cover_weight=True,
        debug=getattr(config, "debug_spawn_log_details", False),
    )

    # =========================== DETECT / SPAWN =============================
    active_regions, cand_map = _detect_regions_pure(agents, params, runtime_ctx)

    # --- probabilistic confidence gate + top-K cap ---
    regs_to_spawn = []
    if active_regions:
        CFG = globals().get('config', None)
        if CFG is None:
            try:
                import config as CFG
            except Exception:
                class _C: pass
                CFG = _C()

        conf_tau_cfg = getattr(CFG, "spawn_confidence_tau", None)
        if conf_tau_cfg is not None:
            conf_tau = float(conf_tau_cfg)
        else:
            if bool(getattr(CFG, "spawn_conf_auto", True)):
                ds = getattr(runtime_ctx, "detector_state", None)
                conf_tau = float(getattr(ds, "conf_tau_eff", 0.60)) if ds is not None else 0.60
            else:
                conf_tau = 0.60

        def _conf(r):
            try:
                return float(getattr(r, "confidence", 1.0))
            except Exception:
                return 1.0

        regs = [r for r in active_regions if _conf(r) >= conf_tau]
        max_new = int(getattr(CFG, "parent_max_new_per_step", 3))
        if regs:
            regs.sort(key=_conf, reverse=True)
            regs_to_spawn = regs[:max_new]

    changed_parents = []
    if regs_to_spawn:
        changed_parents = _apply_spawn_from_regions(runtime_ctx, regs_to_spawn,
                                                    agents, generators_q, generators_p, params) or []
        # spawn/coarsegrain mutate fields and set morphisms_dirty; no morphism/caches here
        for p in changed_parents:
            mark_dirty(runtime_ctx, p)
        if changed_parents and ensure_transforms is not None:
            ensure_transforms(changed_parents, generators_q, generators_p, params)
            runtime_ctx.cache_version += 1

    # =================== ASSIGN KIDS → PARENTS ==============================
    _assign_children_to_parents(
        agents, runtime_ctx.parents_by_region,
        eps=getattr(config, "support_cutoff_eps", 1e-3),
        tau=getattr(config, "parent_soft_assign_tau", 0.30),
        temp=getattr(config, "parent_soft_assign_temp", 0.25),
        max_parents_per_child=getattr(config, "parent_soft_assign_topk", 2),
        core_tau=getattr(config, "parent_assign_core_tau", 0.12),
        core_tau_rel=getattr(config, "parent_assign_core_tau_rel", 0.50),
        core_dilate_px=getattr(config, "parent_assign_core_dilate", 1),
        newborn_bootstrap_steps=getattr(config, "parent_assign_bootstrap", 2),
        allow_unassigned=True,
        agreement_map=getattr(runtime_ctx, "Aq_agg", None),
        use_agreement=getattr(config, "parent_assign_use_agreement", False),
        agree_weight=getattr(config, "parent_assign_agree_weight", 1.0),
        debug=getattr(config, "debug_assign_summary", False),
    )

    # ================= PERIODIC COARSE-GRAIN (ALL PARENTS) ==================
    _periodic_parent_coarsegrain(runtime_ctx, agents, generators_q, generators_p, params)
    # mark parents that CG touched as dirty (CG should set .morphisms_dirty=True itself)
    parents = [p for p in runtime_ctx.parents_by_region.values() if p is not None]
    touched_parents = [p for p in parents if getattr(p, "morphisms_dirty", False)]
    for p in touched_parents:
        mark_dirty(runtime_ctx, p)
    if touched_parents and ensure_transforms is not None:
        ensure_transforms(touched_parents, generators_q, generators_p, params)
        runtime_ctx.cache_version += 1

    # ==================== PRUNE ORPHANS =====================================
    prune_orphan_parents(
        runtime_ctx.parents_by_region,
        patience=getattr(config, "orphan_patience_steps", 3),
        min_total_weight=getattr(config, "orphan_min_total_weight", 1e-4),
        min_area_nz=getattr(config, "orphan_min_area_nz", 3),
        support_tau=getattr(config, "parent_support_tau", 0.02),
        verbose=getattr(config, "debug_prune_log", False),
    )

    # =================== REBUILD PARENT MASKS (pure) ========================
    import numpy as _np
    parents = [p for p in runtime_ctx.parents_by_region.values() if p is not None]
    _prev_masks = {int(pid): _np.asarray(P.mask, _np.float32).copy()
                   for pid, P in runtime_ctx.parents_by_region.items() if P is not None}

    # same-level Ω for children is already refreshed as needed; proceed to mask assign
    assign_parent_masks_from_alignment(
        runtime_ctx,
        agents,
        generators_q, generators_p,
        mode="max",
        mask_tau=0.10,
        tau_q=float(getattr(config, "tau_align_q", 0.30)),
        tau_p=float(getattr(config, "tau_align_p", 0.30)),
        alpha=float(getattr(config, "blend_qp_alpha", 0.5)),
        agree_map=getattr(runtime_ctx, "Aq_agg", None),
        agree_power=1.0,
        clamp_to_union=True,
        kl_cap=float(getattr(config, "signal_kl_cap", 10.0)),
        floor_eps=1e-6,
        min_pair_px=8
    )

    # mark changed parents dirty (mask changes affect domain usage)
    tol = float(getattr(config, "parent_mask_change_tol", 1e-8))
    changed_after_masks = []
    for pid, P in runtime_ctx.parents_by_region.items():
        if P is None:
            continue
        before = _prev_masks.get(int(pid))
        if before is None:
            changed_after_masks.append(P)
            continue
        now = _np.asarray(P.mask, _np.float32)
        if now.shape != before.shape or float(_np.max(_np.abs(now - before))) > tol:
            changed_after_masks.append(P)

    for p in changed_after_masks:
        mark_dirty(runtime_ctx, p)
    if changed_after_masks and ensure_transforms is not None:
        ensure_transforms(changed_after_masks, generators_q, generators_p, params)
        runtime_ctx.cache_version += 1

    # ========== RECONCILE (hysteresis, CC/PBC, IoU + assignments) ===========
    H, W = agents[0].mask.shape
    periodic = bool(getattr(config, "periodic_domain", True))
    reconcile_parent_masks_and_assignments(runtime_ctx, agents, step_now, periodic=periodic, H=H, W=W)

    # delete parents flagged by reconcile
    to_del = [pid for pid, P in runtime_ctx.parents_by_region.items() if getattr(P, "_delete", False)]
    for pid in to_del:
        runtime_ctx.parents_by_region.pop(pid, None)

    # ================= PARENT GRADS/APPLY (intrascale) ======================
    parents = [p for p in runtime_ctx.parents_by_region.values() if p is not None]
    if parents:
        # ensure transforms before gradient pass (in case reconcile added dirtiness)
        if ensure_transforms is not None:
            ensure_transforms(parents, generators_q, generators_p, params)
        _parent_intrascale_grad_pass(agents, parents, generators_q, generators_p, params, accum_into=True)
        _final_apply_parents(runtime_ctx, params)

        for p in parents:
            mark_dirty(runtime_ctx, p)
        if ensure_transforms is not None:
            ensure_transforms(parents, generators_q, generators_p, params)
            runtime_ctx.cache_version += 1

    # =================== FINAL REGISTRATION / MIRROR ========================
    children = [a for a in agents if a is not None]
    parents  = [p for p in runtime_ctx.parents_by_region.values() if p is not None]
    if children:
        runtime_ctx.register_agents(0, children)
    if parents:
        runtime_ctx.register_agents(1, parents)
    if children and parents:
        # ensure Λ/views definitely exist for both levels before mirroring
        if ensure_transforms is not None:
            ensure_transforms(children + parents, generators_q, generators_p, params)
        runtime_ctx.mirror_agent_lambdas_into_link(
            low_level=0, high_level=1,
            children=children, parents=parents,
            attach_labels=True, label_policy="primary",
            attach_lambda=True, reference_not_copy=True
        )

    # ============================= BOOKKEEPING ==============================
    runtime_ctx.children_latest = agents
    runtime_ctx.parents_latest  = runtime_ctx.parents_by_region
    runtime_ctx.global_step    += 1

    return agents


















 # after runtime_ctx.mirror_agent_lambdas_into_link(...)
 #save_lambda_images_from_ctx(runtime_ctx, step=runtime_ctx.global_step,
#                             outdir="artifacts/lambda_viz", low_level=0, high_level=1,
 #                            also_save_npy=False)


def debug_print_ctx_lambdas(ctx, low_level=0, high_level=1):
    import numpy as np

    xl = getattr(ctx, "xlinks", None)
    if not xl or (low_level, high_level) not in xl:
        print(f"[Λ-debug] no cross-scale link at ({low_level},{high_level})\n\n\n")
        return

    link = xl[(low_level, high_level)]
    # Each of these is expected to be a dict keyed by (child_id, parent_id) -> array
    dn_q = getattr(link, "Lambda_dn_q", {}) or {}
    dn_p = getattr(link, "Lambda_dn_p", {}) or {}
    up_q = getattr(link, "Lambda_up_q", {}) or {}
    up_p = getattr(link, "Lambda_up_p", {}) or {}

    total = 0
    def _print_map(tag, mp):
        nonlocal total
        for (cid, pid), L in mp.items():
            if L is None: 
                continue
            n = float(np.linalg.norm(np.asarray(L)))
            print(f"[Λ {tag}] c{cid} ↔ p{pid}  ||Λ||={n:.3e}\n\n\n")
            total += 1

    _print_map("dn_q", dn_q)
    _print_map("dn_p", dn_p)
    _print_map("up_q", up_q)
    _print_map("up_p", up_p)

    if total == 0:
        print("[Λ-debug] link exists but contains no Λ entries\n\n\n")



def debug_print_lambda_norms(children, parents):
    import numpy as np
    for c in children:
        qmap = getattr(c, "Lambda_up_q_map", {}) or {}
        pmap = getattr(c, "Lambda_up_p_map", {}) or {}
        for pid, L in qmap.items():
            print(f"[Λ-q] child {c.id} → parent {pid}  ‖Λ‖={np.linalg.norm(L):.3e}\n\n\n")
        for pid, L in pmap.items():
            print(f"[Λ-p] child {c.id} → parent {pid}  ‖Λ‖={np.linalg.norm(L):.3e}\n\n\n")

    for p in parents:
        qmap = getattr(p, "Lambda_from_child_q_map", {}) or {}
        pmap = getattr(p, "Lambda_from_child_p_map", {}) or {}
        for cid, L in qmap.items():
            print(f"[Λ<-q] parent {p.id} ← child {cid}  ‖Λ‖={np.linalg.norm(L):.3e}\n\n\n")
        for cid, L in pmap.items():
            print(f"[Λ<-p] parent {p.id} ← child {cid}  ‖Λ‖={np.linalg.norm(L):.3e}\n\n\n")


# ---- Λ bootstrap: write identity Λ for each assigned (child, parent) pair ----
import numpy as np

import numpy as np

def infer_parent_links_from_masks(children, parents, *, min_px=3, rel_tau=0.02):
    """
    Set child.parent_ids and parent.child_ids purely from mask overlaps.
    rel_tau is a fraction of the child's support; min_px is absolute pixels.
    """
    children = [c for c in children if c is not None]
    parents  = [p for p in parents  if p is not None]
    for c in children:
        cm = np.asarray(c.mask, dtype=bool)
        c_support = int(cm.sum())
        ids = []
        if c_support > 0:
            for p in parents:
                pm = np.asarray(p.mask, dtype=bool)
                if pm.shape != cm.shape:
                    continue
                ov = int((cm & pm).sum())
                if ov >= int(min_px) and (ov / c_support) >= float(rel_tau):
                    ids.append(int(p.id))
        c.parent_ids = ids  # <-- critical for Λ builders

    for p in parents:
        p.child_ids = [int(c.id) for c in children if int(p.id) in getattr(c, "parent_ids", [])]

def bootstrap_identity_lambdas(children, parents):
    """
    Seed Λ with rectangular identity for every (child,parent) in child.parent_ids.
    Writes both child-up and parent-view maps so mirroring has something to copy.
    """
    import numpy as np
    children = [c for c in children if c is not None]
    parents  = [p for p in parents  if p is not None]
    id2p = {int(p.id): p for p in parents}
    wrote = 0
    for c in children:
        pid_list = list(getattr(c, "parent_ids", []) or [])
        if not pid_list:
            continue
        c.Lambda_up_q_map = getattr(c, "Lambda_up_q_map", {}) or {}
        c.Lambda_up_p_map = getattr(c, "Lambda_up_p_map", {}) or {}
        Kc_q = int(c.mu_q_field.shape[-1]); Kc_p = int(c.mu_p_field.shape[-1])

        for pid in pid_list:
            p = id2p.get(int(pid))
            if p is None:
                continue
            p.Lambda_from_child_q_map = getattr(p, "Lambda_from_child_q_map", {}) or {}
            p.Lambda_from_child_p_map = getattr(p, "Lambda_from_child_p_map", {}) or {}
            Kp_q = int(p.mu_q_field.shape[-1]); Kp_p = int(p.mu_p_field.shape[-1])

            Iq = np.zeros((Kc_q, Kp_q), np.float32)
            Ip = np.zeros((Kc_p, Kp_p), np.float32)
            s = min(Kc_q, Kp_q); Iq[:s, :s] = np.eye(s, dtype=np.float32)
            s = min(Kc_p, Kp_p); Ip[:s, :s] = np.eye(s, dtype=np.float32)

            c.Lambda_up_q_map[int(pid)] = Iq
            c.Lambda_up_p_map[int(pid)] = Ip
            p.Lambda_from_child_q_map[int(c.id)] = Iq
            p.Lambda_from_child_p_map[int(c.id)] = Ip
            wrote += 2
    return wrote

def debug_print_lambda_norms(children, parents):
    import numpy as np
    for c in children:
        for pid, L in (getattr(c, "Lambda_up_q_map", {}) or {}).items():
            print(f"[Λ-q] child {c.id} → parent {pid}  ||Λ||={np.linalg.norm(L):.3e}")
        for pid, L in (getattr(c, "Lambda_up_p_map", {}) or {}).items():
            print(f"[Λ-p] child {c.id} → parent {pid}  ||Λ||={np.linalg.norm(L):.3e}")
    for p in parents:
        for cid, L in (getattr(p, "Lambda_from_child_q_map", {}) or {}).items():
            print(f"[Λ<-q] parent {p.id} ← child {cid}  ||Λ||={np.linalg.norm(L):.3e}")
        for cid, L in (getattr(p, "Lambda_from_child_p_map", {}) or {}).items():
            print(f"[Λ<-p] parent {p.id} ← child {cid}  ||Λ||={np.linalg.norm(L):.3e}")

