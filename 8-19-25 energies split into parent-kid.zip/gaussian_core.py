# -*- coding: utf-8 -*-
"""
Created on Mon Aug 11 10:07:56 2025

@author: chris and christine
"""
import numpy as np
from numerical_utils import sanitize_sigma, safe_inv, safe_logdet
from typing import Optional, Tuple
from omega import exp_lie_algebra_irrep



def kl_gaussians(mu1, S1, mu2, S2, eps=1e-6):
    """KL(N(μ1,Σ1) || N(μ2,Σ2)) — batch-safe, no fragile squeezes."""
    S1 = sanitize_sigma(S1, eps=eps)
    S2 = sanitize_sigma(S2, eps=eps)
    K = S1.shape[-1]
    S2_inv = safe_inv(S2, eps=eps)
    dmu = (mu2 - mu1)                                       # (..., K)
    term_trace = np.einsum('...ij,...ji->...', S2_inv, S1)  # tr(S2^{-1} Σ1)
    term_quad  = np.einsum('...i,...ij,...j->...', dmu, S2_inv, dmu)  # (μ2-μ1)^T S2^{-1} (μ2-μ1)
    s1, logdet1 = np.linalg.slogdet(S1)
    s2, logdet2 = np.linalg.slogdet(S2)
    logdet_ratio = logdet2 - logdet1
    return 0.5 * (term_trace + term_quad - K + logdet_ratio)




def QQgaussian_pushforward_linear(mu, Sigma, A):
    """Push (mu,Sigma) by linear map A: (A mu, A Σ A^T)."""
    mu_t = np.einsum('...ij,...j->...i', A, mu)
    S_t  = np.einsum('...ik,...kl,...jl->...ij', A, Sigma, A)
    return mu_t, S_t







def QQ_transport_gaussian(mu_j, S_j, R):
    """Transport Gaussian by orthogonal R: μ' = R μ, Σ' = R Σ Rᵀ (symmetrized)."""
    import numpy as _np
    muT = (R @ mu_j[..., None])[..., 0]
    ST  = R @ S_j @ R.swapaxes(-1, -2)
    ST  = 0.5 * (ST + ST.swapaxes(-1, -2))
    return muT.astype(_np.float32, copy=False), ST.astype(_np.float32, copy=False)





def _overlap_pairs(children, H, W, *, tau=0.10, min_pair_px=8):
    """
    Return list of (i,j, overlap_bool_mask) for child pairs whose supports overlap.
    Uses (mask > tau) as support for overlap detection.
    """
    Ms_bool = [(np.asarray(c.mask, np.float32) > float(tau)) for c in children]
    pairs = []
    n = len(children)
    for i in range(n):
        mi = Ms_bool[i]
        if not mi.any(): continue
        for j in range(i+1, n):
            ov = (mi & Ms_bool[j])
            if int(ov.sum()) >= int(min_pair_px):
                pairs.append((i, j, ov))
    return pairs


def QQ_mahalanobis_masked_fast(mu1, S1, mu2, S2, mask, eps=1e-6):
    """Masked Mahalanobis distance with pooled covariance 0.5*(S1+S2)."""
    import numpy as _np
    H, W, K = mu1.shape[:3]
    if not mask.any():
        return _np.zeros((H, W), _np.float32)
    I = _np.eye(K, dtype=_np.float32)
    idx = _np.flatnonzero(mask.reshape(-1))
    M1  = mu1.reshape(-1, K)[idx]
    M2  = mu2.reshape(-1, K)[idx]
    S1r = S1.reshape(-1, K, K)[idx]
    S2r = S2.reshape(-1, K, K)[idx]
    Sp  = 0.5 * (S1r + S2r) + eps * I

    d  = (M1 - M2)[..., None]
    z  = _np.linalg.solve(Sp, d)
    maha = _np.squeeze(d.transpose(0,2,1) @ z, axis=(-2,-1))

    out = _np.zeros((H, W), _np.float32)
    out.reshape(-1)[idx] = _np.clip(maha.astype(_np.float32), 0.0, _np.finfo(_np.float32).max)
    return out


def QQ_fuse_pair_weights(wq, wp, alpha, mode):
    """Fuse q/p pair weights by 'geo' (default), 'arith', or 'min'."""
    import numpy as _np
    alpha = float(alpha)
    if mode == "arith":
        return alpha * wq + (1.0 - alpha) * wp
    if mode == "min":
        return _np.minimum(wq, wp)
    # geometric
    return _np.exp(
        alpha * _np.log(_np.maximum(wq, 1e-12)) +
        (1.0 - alpha) * _np.log(_np.maximum(wp, 1e-12))
    ).astype(_np.float32, copy=False)




def curvature_boltzmann_from_children(children, H, W, *, gamma=0.0, fiber="q", curvature_map=None):
    """
    Build a curvature Boltzmann factor BF(x) = exp(-gamma * F(x)).
    If curvature_map is provided (H×W), use it directly.
    Else compute F(x) as mask-weighted Frobenius norm of F_xy from omega.compute_field_strength.
    Returns: BF ∈ ℝ^{H×W} (float32) or None if gamma<=0 or computation unavailable.
    """
    if float(gamma) <= 0.0:
        return None

    if curvature_map is not None:
        F = np.asarray(curvature_map, np.float32)
        if F.shape == (H, W):
            return np.exp(-float(gamma) * np.clip(F, 0.0, np.finfo(np.float32).max)).astype(np.float32)

    try:
        from omega import compute_field_strength
    except Exception:
        return None  # fail-open

    num = np.zeros((H, W), np.float32)
    den = np.zeros((H, W), np.float32)
    phi_name = "phi" if str(fiber)=="q" else "phi_model"
    gen_name = "generators_q" if str(fiber)=="q" else "generators_p"

    for c in children:
        m = np.asarray(getattr(c, "mask", 0.0), np.float32)
        if m.shape[:2] != (H, W) or float(m.max()) <= 0.0:
            continue
        phi = getattr(c, phi_name, None)
        G   = getattr(c, gen_name, None)
        if phi is None or G is None:
            continue
        phi = np.asarray(phi, np.float32)
        Fdict = compute_field_strength(phi, np.asarray(G, np.float32))
        Fxy = np.asarray(Fdict.get("xy", 0.0), np.float32)  # (H,W,K,K)
        if Fxy.shape[:2] != (H, W):
            continue
        Fx = np.sqrt(np.clip(np.sum(Fxy * Fxy, axis=(-2, -1)), 0.0, np.finfo(np.float32).max)).astype(np.float32)
        num += (m * Fx)
        den += np.maximum(m, 0.0)

    F = np.zeros((H, W), np.float32)
    sel = den > 1e-6
    F[sel] = (num[sel] / np.maximum(den[sel], 1e-6)).astype(np.float32)
    return np.exp(-float(gamma) * np.clip(F, 0.0, np.finfo(np.float32).max)).astype(np.float32)




def QQblended_agreement_from_softmin_kl(Aq_or_KLq, Ap_or_KLp, *, alpha=0.5, tau_q=0.45, tau_p=0.45):
    """
    Accepts either agreement A (in [0,1]) or KL arrays (>=0). If a value >1 is detected,
    we assume it's a KL and convert via exp(-KL/tau). Then blend: A = (1-α)·Aq + α·Ap.
    Returns: A ∈ [0,1], finite, dtype=float32, broadcasting-safe on (H,W).
    """
    def _to_A(x, tau):
        x = np.asarray(x, np.float32)
        if x is None:
            return None
        # heuristic: if any entry > 1, treat as KL
        if np.nanmax(x) > 1.0:
            A = np.exp(-x / max(1e-8, float(tau)))
        else:
            A = x
        A = np.clip(np.nan_to_num(A, nan=0.0, posinf=1.0, neginf=0.0), 0.0, 1.0)
        return A.astype(np.float32, copy=False)

    Aq = _to_A(Aq_or_KLq, tau_q) if Aq_or_KLq is not None else None
    Ap = _to_A(Ap_or_KLp, tau_p) if Ap_or_KLp is not None else None

    if (Aq is not None) and (Ap is not None):
        A = (1.0 - float(alpha)) * Aq + float(alpha) * Ap
    elif Aq is not None:
        A = Aq
    elif Ap is not None:
        A = Ap
    else:
        return None

    return np.clip(A, 0.0, 1.0).astype(np.float32, copy=False)


def directed_kl_weight_after_transport(
    Ai, Aj,
    mu_i, S_i, mu_j, S_j,
    *, fiber, H, W, K, ov, tau,
    assume_diag_is_stddev=True,
    debug=False,
    # NEW toggles (safe defaults)
    use_cached_omega=True,
    store_omega=None,          # None -> read config.cache_omega_fields else bool
):
    """
    w(x) = exp(- KL( N_i || T_{j->i}(N_j) ) / tau ) on overlap 'ov'.
    Uses SO(3) transport Ω_ij = exp(φ_i) · exp(-φ_j) (or model φ̃ for fiber='p').

    Cache policy:
      1) Try Ai.Omega_cache[Aj.id] / Omega_tilde_cache (full fields).
      2) Else use cached exp fields (Ai._exp_phi * Aj._exp_neg_phi, etc.), sliced to ov.
      3) Else compute exp(φ) on the fly (ov subset only), then (optionally) store.
    """
    import numpy as np
    from numerical_utils import sanitize_sigma, safe_inv
   

    if not np.any(ov):
        return np.zeros((H, W), np.float32)

    try:
        import config as _cfg
        if store_omega is None:
            store_omega = bool(getattr(_cfg, "cache_omega_fields", False))
        group_name = getattr(_cfg, "group_name", "so3")
    except Exception:
        class _C: pass
        _cfg = _C()
        if store_omega is None:
            store_omega = False
        group_name = "so3"

    # Overlap indices once
    iy, ix = np.nonzero(ov)

    # Slice means/covs on overlap
    mui = mu_i[iy, ix]  # (M,K)
    muj = mu_j[iy, ix]  # (M,K)
    Si  = S_i[iy, ix]   # (M,K,K) or (M,K)
    Sj  = S_j[iy, ix]

    # Ensure (M,K,K) SPD arrays (diagonal → full)
    if Si.ndim == 2:
        diag = Si.astype(np.float32)
        if assume_diag_is_stddev:
            diag = diag * diag
        Si = np.einsum("mk,ij->mij", diag, np.eye(K, dtype=np.float32), optimize=True)
    if Sj.ndim == 2:
        diag = Sj.astype(np.float32)
        if assume_diag_is_stddev:
            diag = diag * diag
        Sj = np.einsum("mk,ij->mij", diag, np.eye(K, dtype=np.float32), optimize=True)

    # ---- helper: get Ω on the overlap subset (M,K,K) in a cache-first way ----
    def _omega_subset_on_overlap():
        # 1) full Ω cache (fast path)
        if use_cached_omega:
            if fiber == "q":
                Om_full = getattr(Ai, "Omega_cache", {}).get(int(getattr(Aj, "id", -1)))
            else:
                Om_full = getattr(Ai, "Omega_tilde_cache", {}).get(int(getattr(Aj, "id", -1)))
            if Om_full is not None and getattr(Om_full, "shape", None) and Om_full.shape[:2] == (H, W):
                return Om_full[iy, ix]  # (M,K,K)

        # 2) exp caches → multiply on the subset only
        if fiber == "q":
            Ei  = getattr(Ai, "_exp_phi", None)
            EjN = getattr(Aj, "_exp_neg_phi", None)
        else:
            Ei  = getattr(Ai, "_exp_phi_model", None)
            EjN = getattr(Aj, "_exp_neg_phi_model", None)

        if Ei is not None and EjN is not None and Ei.shape[:2] == (H, W) and EjN.shape[:2] == (H, W):
            Ei_s  = Ei[iy, ix]   # (M,K,K)
            EjN_s = EjN[iy, ix]  # (M,K,K)
            return Ei_s @ EjN_s

        # 3) build exp(φ) on the fly (subset); try to cache small as we go
        try:
            from omega import exp_lie_algebra_irrep
        except Exception:
            raise RuntimeError("omega.exp_lie_algebra_irrep not available to build transports.")

        # Resolve generators (don’t assume agents carry them)
        try:
            gens = (Ai.generators_q if fiber == "q" else Ai.generators_p)
        except Exception:
            gens = None
        if gens is None:
            try:
                from get_generators import get_generators
                gens = get_generators(group_name, K)
            except Exception:
                raise RuntimeError(f"Missing generators for fiber='{fiber}', K={K}")

        # Build Ei, EjN on the overlap subset
        if fiber == "q":
            phi_i = Ai.phi[iy, ix]
            phi_j = Aj.phi[iy, ix]
        else:
            phi_i = Ai.phi_model[iy, ix]
            phi_j = Aj.phi_model[iy, ix]

        Ei_s  = np.stack([exp_lie_algebra_irrep(phi_i[m], gens)  for m in range(phi_i.shape[0])], axis=0)
        EjN_s = np.stack([exp_lie_algebra_irrep(-phi_j[m], gens) for m in range(phi_j.shape[0])], axis=0)
        Om_s  = Ei_s @ EjN_s  # (M,K,K)

        # Optionally store full Ω (expensive memory) or at least exp caches
        if store_omega:
            try:
                # if we have full exp fields, populate them; else build full once via vectorized path
                if fiber == "q":
                    if getattr(Ai, "_exp_phi", None) is None:
                        # Build full once (vectorized) to be consistent
                        Ei_full  = np.zeros((H, W, K, K), np.float32)
                        EjN_full = np.zeros((H, W, K, K), np.float32)
                        Ei_full[iy, ix]  = Ei_s
                        EjN_full[iy, ix] = EjN_s
                        Ai._exp_phi  = Ei_full
                        Aj._exp_neg_phi = EjN_full
                    cache = Ai.Omega_cache
                else:
                    if getattr(Ai, "_exp_phi_model", None) is None:
                        Ei_full  = np.zeros((H, W, K, K), np.float32)
                        EjN_full = np.zeros((H, W, K, K), np.float32)
                        Ei_full[iy, ix]  = Ei_s
                        EjN_full[iy, ix] = EjN_s
                        Ai._exp_phi_model  = Ei_full
                        Aj._exp_neg_phi_model = EjN_full
                    cache = Ai.Omega_tilde_cache
                # store a sparse/full Ω only if we already have full exp fields
                if getattr(Ai, "_exp_phi" if fiber=="q" else "_exp_phi_model", None) is not None and \
                   getattr(Aj, "_exp_neg_phi" if fiber=="q" else "_exp_neg_phi_model", None) is not None:
                    Om_full = (Ai._exp_phi  if fiber=="q" else Ai._exp_phi_model) @ \
                              (Aj._exp_neg_phi if fiber=="q" else Aj._exp_neg_phi_model)
                    cache[int(getattr(Aj, "id", -1))] = Om_full.astype(np.float32, copy=False)
            except Exception:
                pass

        return Om_s

    # Build Ω subset (M,K,K)
    Omega_ij = _omega_subset_on_overlap()  # (M,K,K)

    if debug:
        RtR = np.einsum("mab,mac->mbc", Omega_ij, Omega_ij, optimize=True)
        I   = np.broadcast_to(np.eye(K, dtype=np.float32), RtR.shape)
        if not np.allclose(RtR, I, atol=1e-4):
            print(f"[DKL] non-orthogonal Ω_ij detected for fiber={fiber}")

    # Transport j → i on overlap
    muj_t = np.einsum("mab,mb->ma", Omega_ij, muj, optimize=True)          # (M,K)
    OmT   = np.swapaxes(Omega_ij, -1, -2)
    Sj_t  = np.einsum("mab,mbc,mdc->mad", Omega_ij, Sj, OmT, optimize=True)

    # SPD sanitize
    Si   = sanitize_sigma(Si)
    Sj_t = sanitize_sigma(Sj_t)

    # KL per overlap pixel
    d = kl_gaussians(mui, Si, muj_t, Sj_t).astype(np.float32)
    d = np.clip(np.nan_to_num(d, nan=0.0, posinf=1e6, neginf=0.0), 0.0, 1e6)

    # Weights and scatter back
    invT = 1.0 / max(1e-8, float(tau))
    wvec = np.exp(-d * invT).astype(np.float32)
    w = np.zeros((H, W), np.float32)
    w[iy, ix] = wvec
    return w





def QQgeometric_blend(wq, wp, alpha):
    """
    Geometric blend across fibers: w = wq^(1-alpha) * wp^alpha, numerically stable.
    """
    a = float(alpha)
    if a <= 0.0:
        return wq
    if a >= 1.0:
        return wp
    return np.exp((1.0 - a) * np.log(np.maximum(wq, 1e-12)) +
                   a * np.log(np.maximum(wp, 1e-12)))


def apply_evidence_modulators(w, Mi, Mj, ov, *, A=None, agree_power=1.0, BF=None):
    """
    Combine per-pair alignment weight with spatial terms:
      wij = Mi * Mj * w * 1_ov * (BF if provided) * (A^agree_power if provided)
    """
    wij = (Mi * Mj) * w
    wij *= ov.astype(np.float32)
    if BF is not None:
        wij *= BF
    if (A is not None) and (float(agree_power) != 0.0):
        wij *= (np.asarray(A, np.float32) ** float(agree_power))
    return wij.astype(np.float32, copy=False)




