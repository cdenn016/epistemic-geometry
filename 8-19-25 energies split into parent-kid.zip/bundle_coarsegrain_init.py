# -*- coding: utf-8 -*-
"""
Created on Tue Aug 12 18:56:28 2025

@author: chris and christine
"""

from __future__ import annotations
import numpy as np
import config

from numerical_utils import safe_inv
from omega import exp_lie_algebra_irrep  
from omega import safe_bch_exact
from preprocess_utils import build_all_lambda_caches, preprocess_all_agents



# --- Periodic RG coarse-graining for ALL parents (outside spawn) ------------
def _periodic_parent_coarsegrain(ctx, children, Gq, Gp, params):
    """
    Run canonical coarse-graining for every existing parent, on a fixed period.
    - Preprocesses ONLY children (parents may be newborns with uninitialized fields).
    - (Optionally) builds Λ_up caches from children; parents are ensured lazily in CG.
    - Calls coarsegrain_parent_from_children(P, children, ...) for each parent.
    """
    
    # coarsegrain_parent_from_children is expected to be in this module; if not, import it:
    # from bundle_coarsegrain_init import coarsegrain_parent_from_children

    parents = [p for p in (getattr(ctx, "parents_by_region", {}) or {}).values() if p is not None]
    if not parents:
        return

    # schedule
    step_now = int(getattr(ctx, "global_step", 0))
    period = int(getattr(config, "parent_cg_period", params.get("parent_cg_period", 50)))
    if period <= 0 or (step_now % period) != 0:
        return

    cg_eps = float(getattr(config, "cg_eps", 1e-6))
    cg_tau = float(getattr(config, "parent_cover_support_eps", 0.30))

    # 1) preprocess only children (they always have valid fields)
    child_only = [c for c in (children or []) if c is not None]
    if child_only:
        preprocess_all_agents(child_only, params, G_q=Gq, G_p=Gp)
        # 2) build Λ caches from children only (parents' views are attached lazily in CG)
        try:
            build_all_lambda_caches(child_only)
        except Exception as e:
            print(f"[CG] lambda-cache (children-only) build warning: {e}")

    # 3) now coarse-grain per-parent; this function calls _ensure_parent_fields(...)
    for P in parents:
        try:
            # Pass generators so CG never guesses the irrep (Kq×Kq, Kp×Kp)
            coarsegrain_parent_from_children(
                P, children,
                eps=cg_eps,
                mask_tau=cg_tau,
                G_q=Gq,
                G_p=Gp,
            )
        except Exception as e:
            pid = getattr(P, 'id', '?')
            print(f"[CG] periodic coarsegrain failed for parent {pid}: {e}")

    # bump cache version so downstream can refresh Ω/Λ next step
    if hasattr(ctx, "cache_version"):
        ctx.cache_version = int(getattr(ctx, "cache_version", 0)) + 1





# =========================
# main coarsegrainer
# =========================
def coarsegrain_parent_from_children(P, children, *, eps=1e-6, mask_tau=None, G_q=None, G_p=None):
    """
    Canonical RG coarse-grain with newborn robustness — **no 3×3 shortcuts**.
    - Transport in the correct irrep using G_q / G_p
    - Moment match (μ, Σ) in q- and p-fibers (with proper normalization)
    - Karcher mean for φ/φ̃ via algebraic updates using BCH (with trust-region)
    """
    # newborn-safe sizes, support, and generators
    H, W, Kq, Kp = _ensure_parent_fields(P, children, eps=eps)  # existing utility in your codebase
    Gq = CGH_need_generators(P, "q", Kq, G_q)
    Gp = CGH_need_generators(P, "p", Kp, G_p)

    core = _parent_mask_core(P)   # existing utility: parent “core” support
    if core is None or not np.any(core):
        return
    support_tau = float(mask_tau) if (mask_tau is not None) else float(getattr(config, "support_cutoff_eps", 1e-4))

    # collect contributing children with positive weights
    wmap = getattr(P, "child_weights", {}) or {}
    pairs = []
    for c in (children or []):
        if c is None:
            continue
        w = float(wmap.get(int(getattr(c, "id", -1)), 0.0))
        if w > 0.0:
            pairs.append((c, w))
    if not pairs:
        return

    # parent rotations (identity for newborns)
    Eq_parent = CGH_rot_from_phi(getattr(P, "phi", None), H, W, Gq)
    Ep_parent = CGH_rot_from_phi(getattr(P, "phi_model", None), H, W, Gp)

    # ---------- q-fiber (μ, Σ) ----------
    Wsum_q  = np.zeros((H, W), np.float64)
    mu_acc  = np.zeros((H, W, Kq), np.float64)
    Sig_acc = np.zeros((H, W, Kq, Kq), np.float64)

    phi_list_q, w_list_q = [], []

    for c, w in pairs:
        m_c  = (np.asarray(c.mask, np.float32) > support_tau)
        w_sp = (w * m_c.astype(np.float64))
        w_sp[~core] = 0.0
        if not np.any(w_sp):
            continue

        phi_c = getattr(c, "phi", None)
        if phi_c is None:
            continue
        Eq_child = CGH_rot_from_phi(phi_c, H, W, Gq)
        Lq = Eq_parent @ np.swapaxes(Eq_child, -1, -2)

        muT = (Lq @ np.asarray(c.mu_q_field, np.float64)[..., None])[..., 0]
        ST  = Lq @ np.asarray(c.sigma_q_field, np.float64) @ np.swapaxes(Lq, -1, -2)
        ST  = 0.5 * (ST + np.swapaxes(ST, -1, -2))

        Sig_acc += w_sp[..., None, None] * ST
        mu_acc  += w_sp[..., None] * muT
        Wsum_q  += w_sp

        phi_list_q.append(np.asarray(phi_c, np.float64).reshape(H, W, 3))
        w_list_q.append(w_sp[..., None])

    valid_q = Wsum_q > 0.0
    if np.any(valid_q):
        muP = np.zeros((H, W, Kq), np.float64)
        muP[valid_q] = mu_acc[valid_q] / Wsum_q[valid_q, None]

        # normalized covariance (the critical fix)
        den = np.maximum(Wsum_q[..., None, None], 1e-12)
        Sig = (Sig_acc / den)
        Iq  = np.eye(Kq, dtype=np.float64)
        Sig = 0.5 * (Sig + np.swapaxes(Sig, -1, -2)) + eps * Iq

        P.mu_q_field[valid_q]    = muP[valid_q].astype(np.float32)
        P.sigma_q_field[valid_q] = Sig[valid_q].astype(np.float32)

    # ---------- p-fiber (μ, Σ) ----------
    Wsum_p    = np.zeros((H, W), np.float64)
    mu_acc_p  = np.zeros((H, W, Kp), np.float64)
    Sig_acc_p = np.zeros((H, W, Kp, Kp), np.float64)

    phi_list_p, w_list_p = [], []

    for c, w in pairs:
        m_c  = (np.asarray(c.mask, np.float32) > support_tau)
        w_sp = (w * m_c.astype(np.float64))
        w_sp[~core] = 0.0
        if not np.any(w_sp):
            continue

        phi_m = getattr(c, "phi_model", None)
        if phi_m is None:
            continue
        Ep_child = CGH_rot_from_phi(phi_m, H, W, Gp)
        Lp = Ep_parent @ np.swapaxes(Ep_child, -1, -2)

        muT = (Lp @ np.asarray(c.mu_p_field, np.float64)[..., None])[..., 0]
        ST  = Lp @ np.asarray(c.sigma_p_field, np.float64) @ np.swapaxes(Lp, -1, -2)
        ST  = 0.5 * (ST + np.swapaxes(ST, -1, -2))

        Sig_acc_p += w_sp[..., None, None] * ST
        mu_acc_p  += w_sp[..., None] * muT
        Wsum_p    += w_sp

        phi_list_p.append(np.asarray(phi_m, np.float64).reshape(H, W, 3))
        w_list_p.append(w_sp[..., None])

    valid_p = Wsum_p > 0.0
    if np.any(valid_p):
        muP = np.zeros((H, W, Kp), np.float64)
        muP[valid_p] = mu_acc_p[valid_p] / Wsum_p[valid_p, None]

        den = np.maximum(Wsum_p[..., None, None], 1e-12)
        Sig = (Sig_acc_p / den)
        Ip  = np.eye(Kp, dtype=np.float64)
        Sig = 0.5 * (Sig + np.swapaxes(Sig, -1, -2)) + eps * Ip

        P.mu_p_field[valid_p]    = muP[valid_p].astype(np.float32)
        P.sigma_p_field[valid_p] = Sig[valid_p].astype(np.float32)

    # ---------- φ / φ̃ means (Karcher with trust-region) ----------
    if phi_list_q:
        phi_mean_q = CGH_karcher_mean_phi_irrep(
            phi_list_q, w_list_q, H, W, Gq,
            iters=int(getattr(config, "cg_phi_iters", 6)),
            eta=float(getattr(config, "cg_phi_eta", 0.5)),
            tol=float(getattr(config, "cg_phi_tol", 1e-7)),
            step_clip=float(getattr(config, "cg_phi_step_clip", 1.5)),
            abs_clip=float(getattr(config, "cg_phi_abs_clip", 4.0)),
        )
        P.phi = phi_mean_q.astype(np.float32)
        P._exp_phi = exp_lie_algebra_irrep(phi_mean_q.reshape(-1, 3), Gq).reshape(H, W, Kq, Kq).astype(np.float32)

    if phi_list_p:
        phi_mean_p = CGH_karcher_mean_phi_irrep(
            phi_list_p, w_list_p, H, W, Gp,
            iters=int(getattr(config, "cg_phi_iters", 6)),
            eta=float(getattr(config, "cg_phi_eta", 0.5)),
            tol=float(getattr(config, "cg_phi_tol", 1e-7)),
            step_clip=float(getattr(config, "cg_phi_step_clip", 1.5)),
            abs_clip=float(getattr(config, "cg_phi_abs_clip", 4.0)),
        )
        P.phi_model = phi_mean_p.astype(np.float32)
        P._exp_phi_model = exp_lie_algebra_irrep(phi_mean_p.reshape(-1, 3), Gp).reshape(H, W, Kp, Kp).astype(np.float32)

    # ---------- φ / φ̃ means (Karcher with trust-region) ----------
    if phi_list_q:
        # ... existing phi_mean_q code ...
        P._exp_phi = exp_lie_algebra_irrep(phi_mean_q.reshape(-1, 3), Gq).reshape(H, W, Kq, Kq).astype(np.float32)

    if phi_list_p:
        # ... existing phi_mean_p code ...
        P._exp_phi_model = exp_lie_algebra_irrep(phi_mean_p.reshape(-1, 3), Gp).reshape(H, W, Kp, Kp).astype(np.float32)

    # === NEW: synthesize morphisms so self/feedback energies are defined ===
    
    try:
        from bundle_morphism_utils import have_parent_morphisms
        if not have_parent_morphisms(P):
            CGH_build_morphisms(P, Gq, Gp)  # initialize once so self/feedback prints light up

    except Exception as e:
        # Keep the simulation running; self/feedback will be zero for this parent.
        if getattr(config, "debug_parent_morphism_init", False):
            print(f"[CG][WARN] parent {getattr(P,'id',-1)} morphism build failed: {e}")


    # cache generators on parent for downstream use
    P._G_q, P._G_p = Gq, Gp



def CGH_build_morphisms(P, Gq, Gp):
    """
    Ensure P has bundle morphisms Φ: q→p and Φ̃: p→q set
    using the SO(3) irrep exponentials and any provided bases Φ0/Φ̃0.
    Fallback: rectangular identity if bases are missing.
    """
    # dims
    Kq = int(np.asarray(P.mu_q_field).shape[-1])
    Kp = int(np.asarray(P.mu_p_field).shape[-1])

    # exponentials (already cached by coarsegrain; recompute if absent)
    H, W = P.mu_q_field.shape[:2]
    if getattr(P, "_exp_phi", None) is None:
        P._exp_phi = exp_lie_algebra_irrep(np.asarray(P.phi, np.float64).reshape(-1, 3), Gq)\
                        .reshape(H, W, Kq, Kq).astype(np.float32)
    if getattr(P, "_exp_phi_model", None) is None:
        P._exp_phi_model = exp_lie_algebra_irrep(np.asarray(P.phi_model, np.float64).reshape(-1, 3), Gp)\
                              .reshape(H, W, Kp, Kp).astype(np.float32)

    # bases: try canonical names on the parent; else config; else identity
    Phi0 = getattr(P, "bundle_morphism_q_to_p_base", None)
    if Phi0 is None:
        Phi0 = getattr(P, "Phi0_q_to_p", None)
    if Phi0 is None:
        Phi0 = getattr(config, "Phi0_q_to_p", None)
    if Phi0 is None:
        Phi0 = CGH_rect_identity(Kp, Kq, dtype=np.float32)

    PhiT0 = getattr(P, "bundle_morphism_p_to_q_base", None)
    if PhiT0 is None:
        PhiT0 = getattr(P, "Phi0_p_to_q", None)
    if PhiT0 is None:
        PhiT0 = getattr(config, "Phi0_p_to_q", None)
    if PhiT0 is None:
        PhiT0 = CGH_rect_identity(Kq, Kp, dtype=np.float32)

    # broadcast bases to field if given as 2D
    Phi0 = np.asarray(Phi0, np.float32)
    PhiT0 = np.asarray(PhiT0, np.float32)
    if Phi0.ndim == 2:
        Phi0 = np.broadcast_to(Phi0, (H, W, Kp, Kq)).copy()
    if PhiT0.ndim == 2:
        PhiT0 = np.broadcast_to(PhiT0, (H, W, Kq, Kp)).copy()

    # build Φ and Φ̃ per pixel: Φ = e^{φ̃} · Φ0 · e^{φ},  Φ̃ = e^{φ} · Φ̃0 · e^{φ̃}
    Ep = np.asarray(P._exp_phi_model, np.float32)  # (H,W,Kp,Kp)
    Eq = np.asarray(P._exp_phi,       np.float32)  # (H,W,Kq,Kq)

    # Φ: (H,W,Kp,Kq)
    Phi_field = Ep @ Phi0 @ np.swapaxes(Eq, -1, -2)
    # Φ̃: (H,W,Knq,Knp) == (H,W,Kq,Kp)
    PhiT_field = Eq @ PhiT0 @ np.swapaxes(Ep, -1, -2)

    P.bundle_morphism_q_to_p = Phi_field.astype(np.float32)
    P.bundle_morphism_p_to_q = PhiT_field.astype(np.float32)

# -----------------------------------------------------------------------------
# SO(3) helpers (stable log & Karcher mean)
# -----------------------------------------------------------------------------


def _get_rotation(agent, which: str, H: int, W: int) -> np.ndarray:
    """
    Return cached rotation grid for agent in its **own irrep**; identity if absent.
    which = "q" -> _exp_phi  | "p" -> _exp_phi_model
    """
    if which == "q":
        E = getattr(agent, "_exp_phi", None)
        if E is not None:
            return np.asarray(E, np.float64)
        phi = getattr(agent, "phi", None)
        G   = getattr(agent, "_G_q", getattr(agent, "generators_q", None))
        if phi is None or G is None:
            # infer K from any available q-field
            K = int(np.asarray(getattr(agent, "mu_q_field")).shape[-1]) if getattr(agent, "mu_q_field", None) is not None else 3
            return _identity_rot_grid(H, W, K)
        K = G.shape[-1]
        return exp_lie_algebra_irrep(np.asarray(phi).reshape(-1, 3), G).reshape(H, W, K, K).astype(np.float64)
    else:
        E = getattr(agent, "_exp_phi_model", None)
        if E is not None:
            return np.asarray(E, np.float64)
        phi = getattr(agent, "phi_model", None)
        G   = getattr(agent, "_G_p", getattr(agent, "generators_p", None))
        if phi is None or G is None:
            K = int(np.asarray(getattr(agent, "mu_p_field")).shape[-1]) if getattr(agent, "mu_p_field", None) is not None else 3
            return _identity_rot_grid(H, W, K)
        K = G.shape[-1]
        return exp_lie_algebra_irrep(np.asarray(phi).reshape(-1, 3), G).reshape(H, W, K, K).astype(np.float64)




#==============================================================================
#
#
#
#===============================================================================



# =========================
# coarsegrain helpers (CGH)
# =========================
# --- add near the other CGH helpers ---

def CGH_rect_identity(K_to: int, K_from: int, dtype=np.float32):
    """
    Rectangular identity-like linear map of shape (K_to, K_from):
    maps the first r = min(K_to, K_from) axes; zeros elsewhere.
    """
    r = min(K_to, K_from)
    M = np.zeros((K_to, K_from), dtype=dtype)
    M[:r, :r] = 1.0
    return M




# ---- generator plumbing ----
def CGH_need_generators(P, which: str, K: int, hint):
    """Return (3,K,K) generators for 'q' or 'p' fiber, preferring hint or cached on parent."""
    if hint is not None:
        return hint
    cached = getattr(P, "_G_q" if which == "q" else "_G_p", None)
    if cached is not None:
        return cached
    try:
        from get_generators import get_generators
        return get_generators(getattr(config, "group_name", "SO(3)"), K)
    except Exception as e:
        raise RuntimeError(f"Missing generators for {which}-fiber (K={K}). Pass G_{which}.") from e

# ---- small linear-algebra helpers ----
def CGH_Igrid(H, W, K):
    I = np.eye(K, dtype=np.float64)
    return np.broadcast_to(I, (H, W, K, K)).copy()

def CGH_rot_from_phi(phi_field, H, W, G):
    K = G.shape[-1]
    if phi_field is None:
        return CGH_Igrid(H, W, K)
    phi = np.asarray(phi_field, np.float64).reshape(H * W, 3)
    return exp_lie_algebra_irrep(phi, G).reshape(H, W, K, K)

def CGH_gram(G):
    # M_ab = Tr(G_a^T G_b)
    return np.array([[np.einsum("ij,ij->", G[a].T, G[b]) for b in range(3)] for a in range(3)],
                    dtype=np.float64)

def CGH_as_mat(phi_hw3, G):
    # Φ(y,x) = Σ_a φ^a(y,x) G_a
    return np.einsum("...a,aij->...ij", phi_hw3, G, optimize=True)

def CGH_coeffs_from_mat(X_hwKK, G, Minv=None):
    if Minv is None:
        Minv = safe_inv(CGH_gram(G).astype(np.float64))
    b = np.stack([np.einsum("...ij,ij->...", X_hwKK, G[a].T, optimize=True) for a in range(3)], axis=-1)
    return np.einsum("ab,...b->...a", Minv, b, optimize=True)

# ---- Karcher mean in arbitrary irrep, with trust-region ----
def CGH_karcher_mean_phi_irrep(phi_list, w_list, H, W, G,
                               *, iters=6,
                               eta=None,          # step size in algebra
                               tol=1e-7,
                               step_clip=None,    # per-iteration Δ clamp (L2 in R^3)
                               abs_clip=None):    # clamp ||φ|| after update
    """
    Computes the Karcher (Frechet) mean on the group by iterating in the algebra
    using BCH in the supplied irrep. Stabilized with step/absolute trust regions.
    """
    assert len(phi_list) == len(w_list) and len(phi_list) >= 1
    N = H * W
    PHIS = [np.asarray(p, np.float64).reshape(N, 3) for p in phi_list]
    WTS  = [np.asarray(w, np.float64).reshape(N, 1) for w in w_list]
    Wsum = np.maximum(np.sum(WTS, axis=0), 1e-12)  # (N,1)

    # defaults from config, with safe fallbacks
    if eta is None:
        eta = float(getattr(config, "cg_phi_eta", 0.5))
    if step_clip is None:
        step_clip = float(getattr(config, "cg_phi_step_clip", 1.5))
    if abs_clip is None:
        abs_clip = float(getattr(config, "cg_phi_abs_clip", 4.0))

    # init: weighted Euclidean mean (good in small-angle regime)
    phi = (np.sum([w * p for p, w in zip(PHIS, WTS)], axis=0) / Wsum).reshape(N, 3)
    K   = G.shape[-1]
    Minv = safe_inv(CGH_gram(G).astype(np.float64))

    for _ in range(int(iters)):
        Phi_mat = CGH_as_mat(phi.reshape(N, 3), G).reshape(N, K, K)

        # accumulate Δ
        Delta = np.zeros((N, 3), np.float64)
        for p, w in zip(PHIS, WTS):
            Phi_i = CGH_as_mat(p, G).reshape(N, K, K)
            Di = np.stack([safe_bch_exact(-Phi_mat[i], Phi_i[i]) for i in range(N)], axis=0)
            delta_i = CGH_coeffs_from_mat(Di, G, Minv=Minv)  # (N,3)
            Delta += w * delta_i
        Delta /= Wsum  # weighted mean increment

        # step trust-region
        nrm = np.linalg.norm(Delta, axis=-1, keepdims=True)
        scl = np.minimum(1.0, step_clip / np.maximum(nrm, 1e-12))
        Delta = Delta * scl

        # convergence
        if np.all(nrm < tol):
            break

        # update via BCH on the group
        D_mat   = CGH_as_mat(eta * Delta, G).reshape(N, K, K)
        Phi_new = np.stack([safe_bch_exact(Phi_mat[i], D_mat[i]) for i in range(N)], axis=0)
        phi     = CGH_coeffs_from_mat(Phi_new, G, Minv=Minv)

        # absolute trust-region
        nrm_phi = np.linalg.norm(phi, axis=-1, keepdims=True)
        scl_abs = np.minimum(1.0, abs_clip / np.maximum(nrm_phi, 1e-12))
        phi     = phi * scl_abs

    return phi.reshape(H, W, 3)






def _infer_hwk_from_children(children, which="q"):
    """
    Find (H,W,K) from the first child that has the requested bundle.
    which: "q" -> (mu_q_field), "p" -> (mu_p_field)
    """
    for c in children:
        mu = getattr(c, "mu_q_field" if which=="q" else "mu_p_field", None)
        if mu is not None:
            mu = np.asarray(mu)
            if mu.ndim >= 3:
                H, W, K = mu.shape[:3]
                return int(H), int(W), int(K)
    return None



def _ensure_parent_fields(P, children, *, eps=1e-6):
    dims_q = _infer_hwk_from_children(children, "q")
    dims_p = _infer_hwk_from_children(children, "p")

    if dims_q is None and dims_p is None:
        # Nothing to infer from yet — let caller skip CG this step
        raise ValueError("no child fields to infer dims")

    # Prefer q dims; fall back to p dims
    if dims_q is None:
        H, W, _ = dims_p
        Kq = _ = _infer_hwk_from_children(children, "q")[2] if _infer_hwk_from_children(children, "q") else None
        if Kq is None:
            # If truly no q K yet, pick Kq = 3 as a placeholder only if your code accepts it,
            # otherwise bail and let next step handle it.
            raise ValueError("no q-dims")
    else:
        H, W, Kq = dims_q

    if getattr(P, "mu_q_field", None) is None:
        P.mu_q_field = np.zeros((H, W, Kq), dtype=np.float32)
    if getattr(P, "sigma_q_field", None) is None:
        Iq = np.eye(Kq, dtype=np.float32)
        P.sigma_q_field = np.broadcast_to(Iq, (H, W, Kq, Kq)).copy()

    if dims_p is None:
        # Try to reuse H,W and set a minimal Kp from existing parent or skip
        mup = getattr(P, "mu_p_field", None)
        if mup is None:
            # Can't infer Kp → skip CG this round
            return H, W, Kq, getattr(P, "mu_p_field", np.zeros((H, W, 0), np.float32)).shape[-1]
        Kp = int(np.asarray(mup).shape[-1])
    else:
        H2, W2, Kp = dims_p
        if (H2, W2) != (H, W):
            H, W = H2, W2  # keep grids aligned (your framework assumes same grid)
            # also resize q fields if needed (optional; or bail out and wait next step)

    if getattr(P, "mu_p_field", None) is None:
        P.mu_p_field = np.zeros((H, W, Kp), dtype=np.float32)
    if getattr(P, "sigma_p_field", None) is None:
        Ip = np.eye(Kp, dtype=np.float32)
        P.sigma_p_field = np.broadcast_to(Ip, (H, W, Kp, Kp)).copy()

    return H, W, Kq, Kp


def _identity_rot_grid(H, W, K):
    """Return an (H,W,K,K) identity rotation grid for the given irrep size."""
    I = np.eye(K, dtype=np.float64)
    return np.broadcast_to(I, (H, W, K, K)).copy()





def _get_lambda_up(child, parent, which: str, H: int, W: int):
    """
    Preferred: ctx-built Λ maps (child.Lambda_up_*_map[parent.id]).
    Fallback:  Λ = E_parent · E_child^T using cached (or identity) rotations.
    Returns (Λ, used_fallback: bool)
    """
    if which == "q":
        m = getattr(child, "Lambda_up_q_map", None)
    else:
        m = getattr(child, "Lambda_up_p_map", None)
    if isinstance(m, dict):
        L = m.get(int(getattr(parent, "id", -1)))
        if L is not None:
            return np.asarray(L, np.float64), False
    Ep = _get_rotation(parent, which, H, W)  # irrep-safe
    Ec = _get_rotation(child,  which, H, W)
    return (Ep @ np.swapaxes(Ec, -1, -2)).astype(np.float64), True

# Tag the function so parent_spawn’s guard recognizes the right implementation
try:
    coarsegrain_parent_from_children._dbg_token = "CG-v2025-08-18-A"
    coarsegrain_parent_from_children._dbg_origin = f"{__name__}:{__file__}:{coarsegrain_parent_from_children.__code__.co_firstlineno}"
except Exception:
    pass




def _parent_mask_core(P) -> np.ndarray:
    M = np.asarray(getattr(P, "mask", None), np.float32)
    if M is None:
        return None
    thr_abs = float(getattr(config, "parent_growth_core_tau", 0.20))
    thr_rel = 0.50
    thr = max(thr_abs, thr_rel * float(np.max(M) if M.size else 0.0))
    return (M > thr)







