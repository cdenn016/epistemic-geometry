from __future__ import annotations
import numpy as np
from transport_cache import E_grid
from omega import d_exp_phi_exact
from gaussian_core import sanitize_sigma, safe_inv
import config
from transport_cache import warm_E
from transport_cache import Lambda_dn
# exp/log on the group and their differentials
from omega import d_exp_phi_exact, d_exp_phi_tilde_exact, exp_lie_algebra_irrep

# SPD helpers
from numerical_utils import sanitize_sigma, safe_inv, safe_omega_inv
from numerical_utils import isfinite_scalar
from transport_cache import Lambda_up
"""
Cross-scale (child ↔ parent) energy and gradients, gauge-covariant.

- Belief side (q):   Λ = exp(φ_child) · exp(-φ_parent) = E_c · E_p^T
- Model  side (p):  Λ̃ = exp(φ̃_child) · exp(-φ̃_parent) = Ê_c · Ê_p^T

Child gradients are always accumulated.
Parent gradients are accumulated only if child_only=False.

Config knobs (expected in `config.py` or params):
  lambda_xscale_q: float   # strength on belief side
  lambda_xscale_p: float   # strength on model side
  eps: float               # numerical floor for masks / inverses
"""


# ─────────────────────────────────────────────────────────────────────────────
# Cross-scale helpers (mask coercion, weights, norms, ids, finiteness)
# ─────────────────────────────────────────────────────────────────────────────
import numpy as np
import config

def _xscale_get_parent_ids(agent):
    pids = getattr(agent, "parent_ids", None)
    if pids:
        return [int(p) for p in pids]
    pid = int(getattr(agent, "parent_id", -1))
    return [pid] if pid >= 0 else []

def _coerce_mask_shape(mask_src, shape_dst_hw):
    """
    Make mask_src match target (H,W) using reshape or NN resample.
    Returns float32 mask in [0,1].
    """
    m = np.asarray(mask_src, dtype=np.float32)
    Ht, Wt = shape_dst_hw
    if m.shape == (Ht, Wt):
        return m
    if m.size == Ht * Wt:
        return m.reshape(Ht, Wt)
    # nearest-neighbor resample (dependency-free)
    if m.ndim < 2 or m.shape[0] == 0 or m.shape[1] == 0:
        return np.zeros((Ht, Wt), np.float32)
    Hs, Ws = m.shape[:2]
    yi = (np.arange(Ht) * (Hs / float(Ht))).astype(np.int64)
    xi = (np.arange(Wt) * (Ws / float(Wt))).astype(np.int64)
    yi = np.clip(yi, 0, Hs - 1)
    xi = np.clip(xi, 0, Ws - 1)
    return m[yi[:, None], xi[None, :]].astype(np.float32, copy=False)

def _xscale_overlap_mask(child_mask, parent_mask, mask_tau):
    """
    Coerce parent mask to child grid; return boolean overlap.
    """
    Hc, Wc = np.asarray(child_mask).shape[:2]
    pm = _coerce_mask_shape(parent_mask, (Hc, Wc))
    return (np.asarray(child_mask, np.float32) > mask_tau) & (pm > mask_tau)

def _xscale_ramped_weights(parent, lam_q, lam_p, n_parents, params):
    """
    Per-parent effective weights with freeze+ramp.
    """
    eff_lam_q = float(getattr(parent, "lambda_q_weight", lam_q)) / max(1, n_parents)
    eff_lam_p = float(getattr(parent, "lambda_p_weight", lam_p)) / max(1, n_parents)

    age   = int(getattr(parent, "_age", 0))
    grace = int(getattr(parent, "_grace", params.get("parent_freeze_steps", 0)))
    ramp  = max(1, int(params.get("parent_ramp_steps", 10)))
    ramp_factor = 0.0 if age < grace else min(1.0, (age - grace + 1) / ramp)

    return eff_lam_q * ramp_factor, eff_lam_p * ramp_factor

def _isfinite_scalar(x):
    try:
        a = np.asarray(x).squeeze()
        return a.ndim == 0 and np.isfinite(a)
    except Exception:
        return False

def _masked_L2(x, overlap_bool):
    if x is None:
        return 0.0
    a = np.asarray(x, np.float64)
    # if spatial dims match overlap, mask; else use full
    if a.ndim >= 3 and a.shape[0] == overlap_bool.shape[0] and a.shape[1] == overlap_bool.shape[1]:
        sel = a[overlap_bool]
    else:
        sel = a.reshape(-1)
    return float(np.linalg.norm(sel))

def _print_norms(tag, child, parent, overlap, bundle, dbg, child_shape_hw, kl=None):
    if not dbg:
        return
    if bundle == "q":
        c_mu, c_S = getattr(child, "grad_mu_q", None), getattr(child, "grad_sigma_q", None)
        c_phi     = getattr(child, "grad_phi", None)
        p_mu, p_S = getattr(parent, "grad_mu_q", None), getattr(parent, "grad_sigma_q", None)
        p_phi     = getattr(parent, "grad_phi", None)
    else:
        c_mu, c_S = getattr(child, "grad_mu_p", None), getattr(child, "grad_sigma_p", None)
        c_phi     = getattr(child, "grad_phi_tilde", None)
        p_mu, p_S = getattr(parent, "grad_mu_p", None), getattr(parent, "grad_sigma_p", None)
        p_phi     = getattr(parent, "grad_phi_tilde", None)

    msg = [f"[XS.{bundle.upper()} {tag}] child {int(child.id)} ↔ parent {int(parent.id)}"]
    if kl is not None:
        try: msg.append(f"KL={float(np.nan_to_num(kl)):.3e}")
        except Exception: pass
    msg.append(f"overlap_px={int(overlap.sum())}  childHW={child_shape_hw}")
    msg.append(f"|dμ_c|={_masked_L2(c_mu, overlap):.3e}")
    msg.append(f"|dΣ_c|={_masked_L2(c_S, overlap):.3e}")
    msg.append(f"|dφ_c|={_masked_L2(c_phi, overlap):.3e}")
    msg.append(f"|dμ_p|={_masked_L2(p_mu, overlap):.3e}")
    msg.append(f"|dΣ_p|={_masked_L2(p_S, overlap):.3e}")
    msg.append(f"|dφ_p|={_masked_L2(p_phi, overlap):.3e}")
    print("  \n\n".join(msg))


# ─────────────────────────────────────────────────────────────────────────────
# Cross-scale main
# ─────────────────────────────────────────────────────────────────────────────
from transport_cache import warm_E


from transport_cache import warm_E, E_grid, Lambda_dn
from numerical_utils import sanitize_sigma, safe_inv, safe_omega_inv
import numpy as np, config


def accumulate_crossscale_gradients(agent_i, all_agents, generators_q, generators_p, params):
    """Accumulate child↔parent cross-scale gradients (q & p), supporting multi-parent membership
    via pixelwise or scalar responsibilities."""
    import numpy as np
    ctx        = params.get("runtime_ctx", None)
    lam_x_q    = float(params.get("lambda_xscale_q", getattr(config, "lambda_xscale_q", 0.0)))
    lam_x_p    = float(params.get("lambda_xscale_p", getattr(config, "lambda_xscale_p", 0.0)))
    eps        = float(getattr(config, "eps", 1e-6))
    child_only = bool(params.get("xscale_child_only", True))
    mask_tau   = float(params.get("support_tau", 1e-3))
    dbg        = bool(params.get("debug_xscale_grad_norms", getattr(config, "debug_xscale_grad_norms", True)))

    # pre-warm child E grids (q & p) — idempotent
    if ctx is not None:
        try:
            warm_E(ctx, [agent_i], whiches=("q", "p"))
        except Exception:
            pass

    # id→agent map
    id2A = {int(A.id): A for A in all_agents if A is not None}
    kl_out = {"kl_q": [], "kl_p": []}

    # parents
    pids = _xscale_get_parent_ids(agent_i)
    if not pids:
        return kl_out

    n_parents = max(1, len(pids))
    child_mask = np.asarray(getattr(agent_i, "mask", 0.0), dtype=np.float32)
    child_shape_hw = tuple(child_mask.shape[:2]) if child_mask.ndim >= 2 else None

    # responsibility stores (if built earlier via build_child_parent_responsibilities)
    resp_pix = getattr(agent_i, "_parent_resp_mask", {}) or {}
    resp_scl = getattr(agent_i, "_parent_resp", {}) or {}

    for pid in pids:
        parent = id2A.get(int(pid))
        if parent is None:
            continue

        # pre-warm parent E (q & p)
        if ctx is not None:
            try:
                warm_E(ctx, [parent], whiches=("q", "p"))
            except Exception:
                pass

        parent_mask = np.asarray(getattr(parent, "mask", 0.0), dtype=np.float32)

        # ---- choose weighting ----
        # Prefer pixelwise responsibilities; else scalar; else hard overlap.
        weight_mask = resp_pix.get(int(pid), None)
        if weight_mask is not None:
            # Pixelwise: use where weight > 0 as the debug/valid region
            overlap = np.asarray(weight_mask, dtype=np.float32) > 0.0
        else:
            w_scalar = float(resp_scl.get(int(pid), 0.0))
            if w_scalar > 0.0:
                overlap = _xscale_overlap_mask(child_mask, parent_mask, mask_tau)
                weight_mask = w_scalar  # scalar reweight
            else:
                overlap = _xscale_overlap_mask(child_mask, parent_mask, mask_tau)
                # no explicit responsibility → default to overlap weights only
                weight_mask = None

        if not np.any(overlap):
            continue

        eff_lam_q, eff_lam_p = _xscale_ramped_weights(parent, lam_x_q, lam_x_p, n_parents, params)

        # ---- q bundle (DOWN always; UP if child_only=False) -----------------
        if eff_lam_q > 0.0 and agent_i.mu_q_field.shape[-1] == parent.mu_q_field.shape[-1]:
            kl_q = accumulate_xscale_q_dn_gaugecov(
                child=agent_i, parent=parent, generators_q=generators_q,
                lam_q=eff_lam_q, eps=eps, child_only=True, ctx=ctx,
                weight_mask=weight_mask,   # << responsibility-aware
            )
            if _isfinite_scalar(kl_q):
                _klq = float(np.asarray(kl_q).squeeze())
                kl_out["kl_q"].append(_klq)
                _print_norms("DN", agent_i, parent, overlap, "q", dbg, child_shape_hw, kl=_klq)
            else:
                _print_norms("DN", agent_i, parent, overlap, "q", dbg, child_shape_hw, kl=None)

            if not child_only:
                _ = accumulate_xscale_q_up_gaugecov(
                    child=agent_i, parent=parent, generators_q=generators_q,
                    lam_q=eff_lam_q, eps=eps, child_only=False, ctx=ctx,
                    weight_mask=weight_mask,   # << responsibility-aware
                )
                _print_norms("UP", agent_i, parent, overlap, "q", dbg, child_shape_hw)

        # ---- p bundle (DOWN always; UP if child_only=False) -----------------
        if eff_lam_p > 0.0 and agent_i.mu_p_field.shape[-1] == parent.mu_p_field.shape[-1]:
            kl_p = accumulate_xscale_p_dn_gaugecov(
                child=agent_i, parent=parent, generators_p=generators_p,
                lam_p=eff_lam_p, eps=eps, child_only=True, ctx=ctx,
                weight_mask=weight_mask,   # << responsibility-aware
            )
            if _isfinite_scalar(kl_p):
                _klp = float(np.asarray(kl_p).squeeze())
                kl_out["kl_p"].append(_klp)
                _print_norms("DN", agent_i, parent, overlap, "p", dbg, child_shape_hw, kl=_klp)
            else:
                _print_norms("DN", agent_i, parent, overlap, "p", dbg, child_shape_hw, kl=None)

            if not child_only:
                _ = accumulate_xscale_p_up_gaugecov(
                    child=agent_i, parent=parent, generators_p=generators_p,
                    lam_p=eff_lam_p, eps=eps, child_only=False, ctx=ctx,
                    weight_mask=weight_mask,   # << responsibility-aware
                )
                _print_norms("UP", agent_i, parent, overlap, "p", dbg, child_shape_hw)

    return kl_out





def NEWaccumulate_crossscale_gradients(agent_i, all_agents, generators_q, generators_p, params):
    """Accumulate child↔parent cross-scale gradients (q & p), supporting multi-parent
    membership via pixelwise or scalar responsibilities. Adds Θ-inference terms."""
    ctx        = params.get("runtime_ctx", None)
    lam_x_q    = float(params.get("lambda_xscale_q", getattr(config, "lambda_xscale_q", 0.0)))
    lam_x_p    = float(params.get("lambda_xscale_p", getattr(config, "lambda_xscale_p", 0.0)))
    lam_inf_q  = float(params.get("lambda_infer_q",  getattr(config, "lambda_infer_q",  0.0)))
    lam_inf_p  = float(params.get("lambda_infer_p",  getattr(config, "lambda_infer_p",  0.0)))
    store_theta= bool(params.get("store_theta_fields", getattr(config, "store_theta_fields", True)))
    eps        = float(getattr(config, "eps", 1e-6))
    child_only = bool(params.get("xscale_child_only", True))
    mask_tau   = float(params.get("support_tau", 1e-3))
    dbg        = bool(params.get("debug_xscale_grad_norms", getattr(config, "debug_xscale_grad_norms", True)))

    # --- helpers we already have elsewhere in this module ---
    # _xscale_get_parent_ids, _xscale_overlap_mask, _xscale_ramped_weights,
    # _isfinite_scalar, _print_norms  (assumed present in this file)

    # pre-warm child E grids (q & p) — idempotent
    if ctx is not None:
        try:
            warm_E(ctx, [agent_i], whiches=("q", "p"))
        except Exception:
            pass

    # id→agent map
    id2A = {int(A.id): A for A in all_agents if A is not None}
    kl_out = {"kl_q": [], "kl_p": [], "kl_theta_q": [], "kl_theta_p": []}

    # parents
    pids = _xscale_get_parent_ids(agent_i)
    if not pids:
        return kl_out

    n_parents   = max(1, len(pids))
    child_mask  = np.asarray(getattr(agent_i, "mask", 0.0), dtype=np.float32)
    child_shape = tuple(child_mask.shape[:2]) if child_mask.ndim >= 2 else None

    # responsibilities
    resp_pix = getattr(agent_i, "_parent_resp_mask", {}) or {}
    resp_scl = getattr(agent_i, "_parent_resp", {}) or {}

    # ---------- tiny local helpers for Θ ----------
    def _build_theta_q(child, parent):
        # Θ = Φ̃_k ∘ Λ_p↓, with Φ̃_k = E_q · Φ̃0 · (E_p)^(-1)
        E_q_c = E_grid(ctx, child,  which="q")
        E_p_c = E_grid(ctx, child,  which="p")
        E_pinv= safe_omega_inv(E_p_c, eps=eps, debug=False)
        Phi_t0 = getattr(child, "bundle_morphism_p_to_q_0",
                         getattr(child, "Phi_tilde_0", None))
        if Phi_t0 is None:
            raise ValueError("child missing bundle_morphism_p_to_q_0 / Phi_tilde_0")
        Phi_t = np.einsum("...ik,...kj,...jl->...il", E_q_c, np.asarray(Phi_t0, np.float32), E_pinv, optimize=True)
        Lam_p = Lambda_dn(ctx, child, parent, which="p")  # parent p -> child p
        return np.einsum("...ik,...kj->...ij", Phi_t, Lam_p, optimize=True)

    def _build_theta_p(child, parent):
        # ṪΘ = Φ_k ∘ Λ_q↓, with Φ_k = E_p · Φ0 · (E_q)^(-1)
        E_p_c = E_grid(ctx, child, which="p")
        E_q_c = E_grid(ctx, child, which="q")
        E_qinv= safe_omega_inv(E_q_c, eps=eps, debug=False)
        Phi0  = getattr(child, "bundle_morphism_q_to_p_0",
                        getattr(child, "Phi_0", None))
        if Phi0 is None:
            raise ValueError("child missing bundle_morphism_q_to_p_0 / Phi_0")
        Phi = np.einsum("...ik,...kj,...jl->...il", E_p_c, np.asarray(Phi0, np.float32), E_qinv, optimize=True)
        Lam_q = Lambda_dn(ctx, child, parent, which="q")  # parent q -> child q
        return np.einsum("...ik,...kj->...ij", Phi, Lam_q, optimize=True)

    def _kl_q_vs_r(mu_q, S_q, mu_r, S_r):
        # KL(N_q || N_r) stable, with Σ^{-1} reuse
        S_q = sanitize_sigma(S_q, eps=eps)
        S_r = sanitize_sigma(S_r, eps=eps)
        d   = S_q.shape[-1]
        Lr  = np.linalg.cholesky(S_r)
        G   = np.linalg.solve(Lr, np.linalg.solve(Lr.T, np.eye(d, dtype=S_r.dtype)))  # Σ_r^{-1}
        diff= (mu_r - mu_q)[..., None]
        tr  = np.einsum("...ij,...ji->...", G, S_q)
        quad= np.einsum("...i,...ij,...j->...", diff[...,0], G, diff[...,0])
        ldq = 2.0 * np.sum(np.log(np.diagonal(np.linalg.cholesky(S_q), axis1=-2, axis2=-1)), axis=-1)
        ldr = 2.0 * np.sum(np.log(np.diagonal(Lr, axis1=-2, axis2=-1)), axis=-1)
        return 0.5*(tr + quad - d + (ldr - ldq)), G  # kl_pix, Σ_r^{-1}

    # -----------------------------------------------------------------------
    for pid in pids:
        parent = id2A.get(int(pid))
        if parent is None:
            continue

        # pre-warm parent E (q & p)
        if ctx is not None:
            try:
                warm_E(ctx, [parent], whiches=("q", "p"))
            except Exception:
                pass

        parent_mask = np.asarray(getattr(parent, "mask", 0.0), dtype=np.float32)

        # responsibilities → weighting
        weight_mask = resp_pix.get(int(pid), None)
        if weight_mask is not None:
            overlap = np.asarray(weight_mask, np.float32) > 0.0
        else:
            w_scalar = float(resp_scl.get(int(pid), 0.0))
            overlap = _xscale_overlap_mask(child_mask, parent_mask, mask_tau)
            weight_mask = w_scalar if w_scalar > 0.0 else None

        if not np.any(overlap):
            continue

        eff_lam_q, eff_lam_p = _xscale_ramped_weights(parent, lam_x_q, lam_x_p, n_parents, params)

        # ---------------- Λ terms (existing) ----------------
        if eff_lam_q > 0.0 and agent_i.mu_q_field.shape[-1] == parent.mu_q_field.shape[-1]:
            kl_q = accumulate_xscale_q_dn_gaugecov(
                child=agent_i, parent=parent, generators_q=generators_q,
                lam_q=eff_lam_q, eps=eps, child_only=True, ctx=ctx,
                weight_mask=weight_mask,
            )
            if _isfinite_scalar(kl_q):
                _klq = float(np.asarray(kl_q).squeeze()); kl_out["kl_q"].append(_klq)
                _print_norms("DN", agent_i, parent, overlap, "q", dbg, child_shape, kl=_klq)
            else:
                _print_norms("DN", agent_i, parent, overlap, "q", dbg, child_shape, kl=None)
            if not child_only:
                _ = accumulate_xscale_q_up_gaugecov(
                    child=agent_i, parent=parent, generators_q=generators_q,
                    lam_q=eff_lam_q, eps=eps, child_only=False, ctx=ctx,
                    weight_mask=weight_mask,
                )
                _print_norms("UP", agent_i, parent, overlap, "q", dbg, child_shape)

        if eff_lam_p > 0.0 and agent_i.mu_p_field.shape[-1] == parent.mu_p_field.shape[-1]:
            kl_p = accumulate_xscale_p_dn_gaugecov(
                child=agent_i, parent=parent, generators_p=generators_p,
                lam_p=eff_lam_p, eps=eps, child_only=True, ctx=ctx,
                weight_mask=weight_mask,
            )
            if _isfinite_scalar(kl_p):
                _klp = float(np.asarray(kl_p).squeeze()); kl_out["kl_p"].append(_klp)
                _print_norms("DN", agent_i, parent, overlap, "p", dbg, child_shape, kl=_klp)
            else:
                _print_norms("DN", agent_i, parent, overlap, "p", dbg, child_shape, kl=None)
            if not child_only:
                _ = accumulate_xscale_p_up_gaugecov(
                    child=agent_i, parent=parent, generators_p=generators_p,
                    lam_p=eff_lam_p, eps=eps, child_only=False, ctx=ctx,
                    weight_mask=weight_mask,
                )
                _print_norms("UP", agent_i, parent, overlap, "p", dbg, child_shape)

        # ---------------- Θ inference terms (NEW) ----------------
        # KL(q_k || Θ p_{k+1})
        if lam_inf_q > 0.0:
            try:
                m = overlap
                if not np.any(m):
                    pass
                else:
                    Theta = _build_theta_q(agent_i, parent)
                    mu_q  = agent_i.mu_q_field[m]
                    S_q   = agent_i.sigma_q_field[m]
                    mu_pP = parent.mu_p_field[m]
                    S_pP  = parent.sigma_p_field[m]

                    mu_t  = np.einsum("...ij,...j->...i", Theta[m], mu_pP, optimize=True)
                    S_t   = np.einsum("...ik,...kl,...jl->...ij", Theta[m], S_pP, np.swapaxes(Theta[m],-1,-2), optimize=True)
                    kl_pix, Ginv = _kl_q_vs_r(mu_q, S_q, mu_t, S_t)
                    kl_mean = float(np.nanmean(kl_pix))
                    kl_out["kl_theta_q"].append(kl_mean)

                    # nat grads (child μ_q, Σ_q)
                    nat_dmu_q  = np.einsum("nij,njk,nk->ni", S_q, Ginv, (mu_q - mu_t))
                    nat_dSig_q = np.einsum("nij,njk,nkl->nil", S_q, Ginv, S_q) - S_q

                    # scatter-add with responsibilities
                    if not hasattr(agent_i, "grad_mu_q") or agent_i.grad_mu_q is None:
                        agent_i.grad_mu_q = np.zeros_like(agent_i.mu_q_field, dtype=np.float32)
                    if not hasattr(agent_i, "grad_sigma_q") or agent_i.grad_sigma_q is None:
                        agent_i.grad_sigma_q = np.zeros_like(agent_i.sigma_q_field, dtype=np.float32)

                    if np.isscalar(weight_mask) and weight_mask is not None:
                        wμ, wΣ = float(weight_mask), float(weight_mask)
                        agent_i.grad_mu_q[m]    += lam_inf_q * wμ * nat_dmu_q
                        agent_i.grad_sigma_q[m] += lam_inf_q * wΣ * nat_dSig_q
                    else:
                        if weight_mask is None:
                            w_local = np.ones(m.sum(), dtype=np.float32)
                        else:
                            w_local = np.asarray(weight_mask, np.float32)[m]
                        agent_i.grad_mu_q[m]    += lam_inf_q * (nat_dmu_q * w_local[:, None])
                        agent_i.grad_sigma_q[m] += lam_inf_q * (nat_dSig_q * w_local[:, None, None])

                    # viz
                    if store_theta and ctx is not None:
                        if not hasattr(ctx, "theta_maps") or ctx.theta_maps is None:
                            ctx.theta_maps = {}
                        field = np.zeros_like(agent_i.mask, dtype=np.float32)
                        field[m] = kl_pix.astype(np.float32)
                        ctx.theta_maps[("q|Theta p", int(agent_i.id), int(parent.id))] = field

                    _print_norms("Θ", agent_i, parent, overlap, "q", dbg, child_shape, kl=kl_mean)
            except Exception:
                _print_norms("Θ", agent_i, parent, overlap, "q", dbg, child_shape, kl=None)

        # KL(p_k || ṪΘ q_{k+1})
        if lam_inf_p > 0.0:
            try:
                m = overlap
                if not np.any(m):
                    pass
                else:
                    TTheta = _build_theta_p(agent_i, parent)
                    mu_p   = agent_i.mu_p_field[m]
                    S_p    = agent_i.sigma_p_field[m]
                    mu_qP  = parent.mu_q_field[m]
                    S_qP   = parent.sigma_q_field[m]

                    mu_t  = np.einsum("...ij,...j->...i", TTheta[m], mu_qP, optimize=True)
                    S_t   = np.einsum("...ik,...kl,...jl->...ij", TTheta[m], S_qP, np.swapaxes(TTheta[m],-1,-2), optimize=True)
                    kl_pix, Ginv = _kl_q_vs_r(mu_p, S_p, mu_t, S_t)  # reusing the same helper
                    kl_mean = float(np.nanmean(kl_pix))
                    kl_out["kl_theta_p"].append(kl_mean)

                    # nat grads for child p
                    nat_dmu_p  = np.einsum("nij,njk,nk->ni", S_p, Ginv, (mu_p - mu_t))
                    nat_dSig_p = np.einsum("nij,njk,nkl->nil", S_p, Ginv, S_p) - S_p

                    if not hasattr(agent_i, "grad_mu_p") or agent_i.grad_mu_p is None:
                        agent_i.grad_mu_p = np.zeros_like(agent_i.mu_p_field, dtype=np.float32)
                    if not hasattr(agent_i, "grad_sigma_p") or agent_i.grad_sigma_p is None:
                        agent_i.grad_sigma_p = np.zeros_like(agent_i.sigma_p_field, dtype=np.float32)

                    if np.isscalar(weight_mask) and weight_mask is not None:
                        wμ, wΣ = float(weight_mask), float(weight_mask)
                        agent_i.grad_mu_p[m]    += lam_inf_p * wμ * nat_dmu_p
                        agent_i.grad_sigma_p[m] += lam_inf_p * wΣ * nat_dSig_p
                    else:
                        if weight_mask is None:
                            w_local = np.ones(m.sum(), dtype=np.float32)
                        else:
                            w_local = np.asarray(weight_mask, np.float32)[m]
                        agent_i.grad_mu_p[m]    += lam_inf_p * (nat_dmu_p * w_local[:, None])
                        agent_i.grad_sigma_p[m] += lam_inf_p * (nat_dSig_p * w_local[:, None, None])

                    if store_theta and ctx is not None:
                        if not hasattr(ctx, "theta_maps") or ctx.theta_maps is None:
                            ctx.theta_maps = {}
                        field = np.zeros_like(agent_i.mask, dtype=np.float32)
                        field[m] = kl_pix.astype(np.float32)
                        ctx.theta_maps[("p|TTheta q", int(agent_i.id), int(parent.id))] = field

                    _print_norms("ṪΘ", agent_i, parent, overlap, "p", dbg, child_shape, kl=kl_mean)
            except Exception:
                _print_norms("ṪΘ", agent_i, parent, overlap, "p", dbg, child_shape, kl=None)

    return kl_out

#=============================================================================
#
#                                 GRADIENTS
#
#============================================================================


# Child grads always; parent grads when child_only=False
def accumulate_xscale_q_dn_gaugecov(
    child, parent, generators_q, lam_q: float, eps: float = 1e-6,
    use_cached_exp: bool = True, child_only: bool = True, ctx=None,
    weight_mask=None,   # NEW: pixelwise mask (H×W) or scalar responsibility
) -> float:
    """
    Cross-scale belief KL in q-fiber with gauge-covariant transport.
    If `weight_mask` is provided (array or scalar), it multiplicatively
    reweights the overlap so a child can contribute to multiple parents
    without double-counting.
    """
    import numpy as np
    if lam_q <= 0.0:
        return 0.0

    # exp(φ) via central cache
    E_c = E_grid(ctx, child,  which="q")    # (...,K,K)
    E_p = E_grid(ctx, parent, which="q")    # (...,K,K)

    # Λ = E_c @ E_p^T (parent -> child)
    Lambda = Lambda_dn(ctx, child, parent, which="q")
    ΛT     = np.swapaxes(Lambda, -1, -2)

    # fields
    mu_c = child.mu_q_field
    S_c  = sanitize_sigma(getattr(child,  "Sigma_q_field", child.sigma_q_field), eps=eps)
    mu_P = parent.mu_q_field
    S_P  = sanitize_sigma(getattr(parent, "Sigma_q_field", parent.sigma_q_field), eps=eps)

    # transport parent stats to child frame
    mu_t = np.einsum("...ij,...j->...i", Lambda, mu_P, optimize=True)
    S_t  = np.einsum("...ik,...kl,...jl->...ij", Lambda, S_P, ΛT, optimize=True)
    S_t  = 0.5*(S_t + np.swapaxes(S_t, -1, -2))
    S_t  = sanitize_sigma(S_t, eps=eps)

    # inverses
    S_t_inv = safe_inv(S_t, eps=eps)
    S_c_inv = safe_inv(S_c, eps=eps)

    # mask weights: overlap × optional responsibility
    w  = np.minimum(np.asarray(child.mask, float), np.asarray(parent.mask, float))
    if weight_mask is not None:
        if np.isscalar(weight_mask):
            w = w * float(weight_mask)
        else:
            w = w * np.clip(np.asarray(weight_mask, float), 0.0, 1.0)
    w1 = w[..., None]
    w4 = w[..., None, None]

    # child μ,Σ grads
    g_mu_c = np.einsum("...ij,...j->...i", S_t_inv, (mu_c - mu_t), optimize=True)
    g_S_c  = 0.5*(S_t_inv - S_c_inv)
    g_S_c  = 0.5*(g_S_c + np.swapaxes(g_S_c, -1, -2))

    if getattr(child, "grad_mu_q", None) is None:
        child.grad_mu_q = np.zeros_like(mu_c)
    if getattr(child, "grad_sigma_q", None) is None:
        child.grad_sigma_q = np.zeros_like(S_c)

    child.grad_mu_q    += float(lam_q) * (g_mu_c * w1)
    child.grad_sigma_q += float(lam_q) * (g_S_c  * w4)

    # dμ_t, dΣ_t
    dmu   = (mu_c - mu_t)
    dmu_t = - np.einsum("...ij,...j->...i", S_t_inv, dmu, optimize=True)
    outer = dmu[..., None] @ np.swapaxes(dmu[..., None], -1, -2)
    dKL_dA = 0.5 * (S_c + outer - S_t)
    dS_t = - np.einsum("...ik,...kl,...lj->...ij", S_t_inv, dKL_dA, S_t_inv, optimize=True)
    dS_t = 0.5*(dS_t + np.swapaxes(dS_t, -1, -2))

    # ∂KL/∂Λ
    term_mean = dmu_t[..., None] @ mu_P[..., None, :]
    term_cov  = 2.0 * np.einsum("...ij,...jk,...kl->...il", dS_t, Lambda, S_P, optimize=True)
    GΛ = (term_mean + term_cov) * w4

    # child φ grads (via Λ = E_c @ E_p^T)
    E_p_T = np.swapaxes(E_grid(ctx, parent, which="q"), -1, -2)
    T_child = np.einsum("...ij,...jk->...ik", GΛ, E_p_T, optimize=True)
    D_c = d_exp_phi_exact(child.phi, child.generators_q, exp_phi_all=E_c)  # list of (...,K,K)
    g_phi_c = np.stack([np.einsum("...ij,...ij->...", T_child, D_c[a], optimize=True) for a in range(len(D_c))], axis=-1)
    g_phi_c = g_phi_c * w1

    if getattr(child, "grad_phi", None) is None:
        child.grad_phi = np.zeros_like(child.phi)
    child.grad_phi += float(lam_q) * g_phi_c

    # optional parent grads
    if not child_only:
        T_parent = - np.einsum("...ij,...jk->...ik", ΛT, GΛ, optimize=True)
        D_p = d_exp_phi_exact(parent.phi, parent.generators_q, exp_phi_all=E_p)
        g_phi_p = np.stack([np.einsum("...ij,...ij->...", T_parent, D_p[a], optimize=True) for a in range(len(D_p))], axis=-1)
        g_phi_p = g_phi_p * w1

        if getattr(parent, "grad_phi", None) is None:
            parent.grad_phi = np.zeros_like(parent.phi)
        parent.grad_phi += float(lam_q) * g_phi_p

        g_mu_P = np.einsum("...ij,...j->...i", ΛT, dmu_t, optimize=True)
        g_S_P  = np.einsum("...ik,...kl,...jl->...ij", ΛT, dS_t, Lambda, optimize=True)
        g_S_P  = 0.5*(g_S_P + np.swapaxes(g_S_P, -1, -2))

        if getattr(parent, "grad_mu_q", None) is None:
            parent.grad_mu_q = np.zeros_like(mu_P)
        if getattr(parent, "grad_sigma_q", None) is None:
            parent.grad_sigma_q = np.zeros_like(S_P)

        parent.grad_mu_q    += float(lam_q) * (g_mu_P * w1)
        parent.grad_sigma_q += float(lam_q) * (g_S_P  * w4)

    # scalar KL (masked mean)
    k = mu_c.shape[-1]
    diff = (mu_c - mu_t)[..., None]
    quad = (np.swapaxes(diff, -1, -2) @ S_t_inv @ diff)[..., 0, 0]
    tr   = np.einsum("...ij,...ji->...", S_t_inv, S_c, optimize=True)
    st_s, st_ld = np.linalg.slogdet(S_t); sc_s, sc_ld = np.linalg.slogdet(S_c)
    st_ld = np.where(st_s > 0, st_ld, np.nan)
    sc_ld = np.where(sc_s > 0, sc_ld, np.nan)
    kl_pt = 0.5 * (tr + quad - k + (st_ld - sc_ld))

    valid = np.isfinite(kl_pt) & (w > 0.0)
    return float(np.nanmean(kl_pt[valid]) * float(lam_q)) if np.any(valid) else 0.0






def accumulate_xscale_p_dn_gaugecov(
    child, parent, generators_p, lam_p: float, eps: float = 1e-6,
    use_cached_exp: bool = True, child_only: bool = True, ctx=None,
    weight_mask=None,   # NEW: pixelwise mask (H×W) or scalar responsibility
) -> float:
    """
    Cross-scale model KL in p-fiber (masked mean) with optional responsibility weighting.
    """
    import numpy as np
    if lam_p <= 0.0:
        return 0.0

    # exp(φ̃) via central cache
    E_c = E_grid(ctx, child,  which="p")
    E_p = E_grid(ctx, parent, which="p")

    # Λ̃ = E_c @ E_p^T (parent -> child in model fiber)
    Lambda = Lambda_dn(ctx, child, parent, which="p")
    ΛT     = np.swapaxes(Lambda, -1, -2)

    # fields (model side)
    mu_c = child.mu_p_field
    S_c  = sanitize_sigma(getattr(child,  "Sigma_p_field", child.sigma_p_field), eps=eps)
    mu_P = parent.mu_p_field
    S_P  = sanitize_sigma(getattr(parent, "Sigma_p_field", parent.sigma_p_field), eps=eps)

    # transport parent stats to child frame
    mu_t = np.einsum("...ij,...j->...i", Lambda, mu_P, optimize=True)
    S_t  = np.einsum("...ik,...kl,...jl->...ij", Lambda, S_P, ΛT, optimize=True)
    S_t  = 0.5 * (S_t + np.swapaxes(S_t, -1, -2))
    S_t  = sanitize_sigma(S_t, eps=eps)

    # inverses
    S_t_inv = safe_inv(S_t, eps=eps)
    S_c_inv = safe_inv(S_c, eps=eps)

    # mask weights: overlap × optional responsibility
    w  = np.minimum(np.asarray(child.mask, float), np.asarray(parent.mask, float))
    if weight_mask is not None:
        if np.isscalar(weight_mask):
            w = w * float(weight_mask)
        else:
            w = w * np.clip(np.asarray(weight_mask, float), 0.0, 1.0)
    w1 = w[..., None]
    w4 = w[..., None, None]

    # child μ,Σ grads (model side)
    g_mu_c = np.einsum("...ij,...j->...i", S_t_inv, (mu_c - mu_t), optimize=True)
    g_S_c  = 0.5 * (S_t_inv - S_c_inv)
    g_S_c  = 0.5 * (g_S_c + np.swapaxes(g_S_c, -1, -2))

    if getattr(child, "grad_mu_p", None) is None:
        child.grad_mu_p = np.zeros_like(mu_c)
    if getattr(child, "grad_sigma_p", None) is None:
        child.grad_sigma_p = np.zeros_like(S_c)

    child.grad_mu_p    += float(lam_p) * (g_mu_c * w1)
    child.grad_sigma_p += float(lam_p) * (g_S_c  * w4)

    # φ̃ (model gauge) grads
    dmu   = (mu_c - mu_t)
    dmu_t = - np.einsum("...ij,...j->...i", S_t_inv, dmu, optimize=True)
    outer = dmu[..., None] @ np.swapaxes(dmu[..., None], -1, -2)
    dKL_dA = 0.5 * (S_c + outer - S_t)
    dS_t = - np.einsum("...ik,...kl,...lj->...ij", S_t_inv, dKL_dA, S_t_inv, optimize=True)
    dS_t = 0.5 * (dS_t + np.swapaxes(dS_t, -1, -2))

    term_mean = dmu_t[..., None] @ mu_P[..., None, :]
    term_cov  = 2.0 * np.einsum("...ij,...jk,...kl->...il", dS_t, Lambda, S_P, optimize=True)
    GΛ = (term_mean + term_cov) * w4

    # child φ̃ grads via Λ̃ = E_c @ E_p^T
    E_p_T = np.swapaxes(E_grid(ctx, parent, which="p"), -1, -2)
    T_child = np.einsum("...ij,...jk->...ik", GΛ, E_p_T, optimize=True)
    D_c = d_exp_phi_exact(child.phi_model, child.generators_p, exp_phi_all=E_c)
    g_phi_tilde_c = np.stack(
        [np.einsum("...ij,...ij->...", T_child, D_c[a], optimize=True) for a in range(len(D_c))],
        axis=-1
    ) * w1

    if getattr(child, "grad_phi_tilde", None) is None:
        child.grad_phi_tilde = np.zeros_like(child.phi_model)
    child.grad_phi_tilde += float(lam_p) * g_phi_tilde_c

    # optional parent grads
    if not child_only:
        T_parent = - np.einsum("...ij,...jk->...ik", ΛT, GΛ, optimize=True)
        D_p = d_exp_phi_exact(parent.phi_model, parent.generators_p, exp_phi_all=E_p)
        g_phi_tilde_p = np.stack(
            [np.einsum("...ij,...ij->...", T_parent, D_p[a], optimize=True) for a in range(len(D_p))],
            axis=-1
        ) * w1

        if getattr(parent, "grad_phi_tilde", None) is None:
            parent.grad_phi_tilde = np.zeros_like(parent.phi_model)
        parent.grad_phi_tilde += float(lam_p) * g_phi_tilde_p

        g_mu_P = np.einsum("...ij,...j->...i", ΛT, dmu_t, optimize=True)
        g_S_P  = np.einsum("...ik,...kl,...jl->...ij", ΛT, dS_t, Lambda, optimize=True)
        g_S_P  = 0.5 * (g_S_P + np.swapaxes(g_S_P, -1, -2))

        if getattr(parent, "grad_mu_p", None) is None:
            parent.grad_mu_p = np.zeros_like(mu_P)
        if getattr(parent, "grad_sigma_p", None) is None:
            parent.grad_sigma_p = np.zeros_like(S_P)

        parent.grad_mu_p    += float(lam_p) * (g_mu_P * w1)
        parent.grad_sigma_p += float(lam_p) * (g_S_P  * w4)

    # scalar KL (masked mean)
    k = mu_c.shape[-1]
    diff = (mu_c - mu_t)[..., None]
    quad = (np.swapaxes(diff, -1, -2) @ S_t_inv @ diff)[..., 0, 0]
    tr   = np.einsum("...ij,...ji->...", S_t_inv, S_c, optimize=True)
    st_s, st_ld = np.linalg.slogdet(S_t); sc_s, sc_ld = np.linalg.slogdet(S_c)
    st_ld = np.where(st_s > 0, st_ld, np.nan)
    sc_ld = np.where(sc_s > 0, sc_ld, np.nan)
    kl_pt = 0.5 * (tr + quad - k + (st_ld - sc_ld))

    valid = np.isfinite(kl_pt) & (w > 0.0)
    return float(np.nanmean(kl_pt[valid]) * float(lam_p)) if np.any(valid) else 0.0






def accumulate_xscale_q_up_gaugecov(
    child, parent, generators_q, lam_q: float, eps: float = 1e-6,
    use_cached_exp: bool = True, child_only: bool = True, ctx=None,
    weight_mask=None,  # NEW: pixelwise or scalar responsibility
) -> float:
    """
    Cross-scale belief KL (UP): transport child -> parent frame in q-fiber.
    Computes KL(N_parent || N_child→parent) as masked mean.
    Parent grads always; child grads if child_only=False.
    Optional `weight_mask` reweights the overlap so a child can contribute to
    multiple parents without double-counting (pixelwise or scalar).
    """
    import numpy as np
    if lam_q <= 0.0:
        return 0.0

    # exp(φ) from cache
    E_c = E_grid(ctx, child,  which="q")     # (...,K,K)
    E_p = E_grid(ctx, parent, which="q")     # (...,K,K)

    # Λ_up = E_p @ E_c^T  (child -> parent)
    Lambda = Lambda_up(ctx, child, parent, which="q")
    ΛT     = np.swapaxes(Lambda, -1, -2)

    # fields
    mu_c = child.mu_q_field
    S_c  = sanitize_sigma(getattr(child,  "Sigma_q_field", child.sigma_q_field), eps=eps)
    mu_P = parent.mu_q_field
    S_P  = sanitize_sigma(getattr(parent, "Sigma_q_field", parent.sigma_q_field), eps=eps)

    # transport child stats to parent frame
    mu_ct = np.einsum("...ij,...j->...i", Lambda, mu_c, optimize=True)
    S_ct  = np.einsum("...ik,...kl,...jl->...ij", Lambda, S_c, ΛT, optimize=True)
    S_ct  = 0.5*(S_ct + np.swapaxes(S_ct, -1, -2))
    S_ct  = sanitize_sigma(S_ct, eps=eps)

    # inverses
    S_ct_inv = safe_inv(S_ct, eps=eps)
    S_P_inv  = safe_inv(S_P,  eps=eps)

    # overlap mask × optional responsibility
    w = np.minimum(np.asarray(child.mask, float), np.asarray(parent.mask, float))
    if weight_mask is not None:
        if np.isscalar(weight_mask):
            w = w * float(weight_mask)
        else:
            w = w * np.clip(np.asarray(weight_mask, float), 0.0, 1.0)
    w1 = w[..., None]
    w4 = w[..., None, None]

    # parent μ,Σ grads (matching in parent frame)
    g_mu_P = np.einsum("...ij,...j->...i", S_ct_inv, (mu_P - mu_ct), optimize=True)
    g_S_P  = 0.5*(S_ct_inv - S_P_inv)
    g_S_P  = 0.5*(g_S_P + np.swapaxes(g_S_P, -1, -2))

    if getattr(parent, "grad_mu_q", None) is None:
        parent.grad_mu_q = np.zeros_like(mu_P)
    if getattr(parent, "grad_sigma_q", None) is None:
        parent.grad_sigma_q = np.zeros_like(S_P)

    parent.grad_mu_q    += float(lam_q) * (g_mu_P * w1)
    parent.grad_sigma_q += float(lam_q) * (g_S_P  * w4)

    # backprop through Λ_up
    dmu   = (mu_P - mu_ct)
    dmu_t = - np.einsum("...ij,...j->...i", S_ct_inv, dmu, optimize=True)
    outer = dmu[..., None] @ np.swapaxes(dmu[..., None], -1, -2)
    dKL_dA = 0.5 * (S_P + outer - S_ct)
    dS_ct = - np.einsum("...ik,...kl,...lj->...ij", S_ct_inv, dKL_dA, S_ct_inv, optimize=True)
    dS_ct = 0.5*(dS_ct + np.swapaxes(dS_ct, -1, -2))

    # ∂KL/∂Λ_up with μ_ct = Λ_up μ_c, Σ_ct = Λ_up Σ_c Λ_up^T
    term_mean = dmu_t[..., None] @ mu_c[..., None, :]
    term_cov  = 2.0 * np.einsum("...ij,...jk,...kl->...il", dS_ct, Lambda, S_c, optimize=True)
    GΛ = (term_mean + term_cov) * w4

    # parent φ grads via Λ_up = E_p @ E_c^T  -> T_parent = GΛ @ E_c^T
    E_c_T = np.swapaxes(E_grid(ctx, child,  which="q"), -1, -2)
    T_parent = np.einsum("...ij,...jk->...ik", GΛ, E_c_T, optimize=True)
    D_p = d_exp_phi_exact(parent.phi, parent.generators_q, exp_phi_all=E_p)
    g_phi_p = np.stack([np.einsum("...ij,...ij->...", T_parent, D_p[a], optimize=True) for a in range(len(D_p))], axis=-1)
    g_phi_p = g_phi_p * w1

    if getattr(parent, "grad_phi", None) is None:
        parent.grad_phi = np.zeros_like(parent.phi)
    parent.grad_phi += float(lam_q) * g_phi_p

    # optional child grads (through E_c^T)
    if not child_only:
        T_child = - np.einsum("...ij,...jk->...ik", ΛT, GΛ, optimize=True)
        D_c = d_exp_phi_exact(child.phi, child.generators_q, exp_phi_all=E_c)
        g_phi_c = np.stack([np.einsum("...ij,...ij->...", T_child, D_c[a], optimize=True) for a in range(len(D_c))], axis=-1)
        g_phi_c = g_phi_c * w1

        if getattr(child, "grad_phi", None) is None:
            child.grad_phi = np.zeros_like(child.phi)
        child.grad_phi += float(lam_q) * g_phi_c

        g_mu_c = np.einsum("...ij,...j->...i", ΛT, dmu_t, optimize=True)
        g_S_c  = np.einsum("...ik,...kl,...jl->...ij", ΛT, dS_ct, Lambda, optimize=True)
        g_S_c  = 0.5*(g_S_c + np.swapaxes(g_S_c, -1, -2))

        if getattr(child, "grad_mu_q", None) is None:
            child.grad_mu_q = np.zeros_like(mu_c)
        if getattr(child, "grad_sigma_q", None) is None:
            child.grad_sigma_q = np.zeros_like(S_c)

        child.grad_mu_q    += float(lam_q) * (g_mu_c * w1)
        child.grad_sigma_q += float(lam_q) * (g_S_c  * w4)

    # scalar KL (masked mean): KL(N_P || N_ct)
    k = mu_P.shape[-1]
    diff = (mu_P - mu_ct)[..., None]
    quad = (np.swapaxes(diff, -1, -2) @ S_ct_inv @ diff)[..., 0, 0]
    tr   = np.einsum("...ij,...ji->...", S_ct_inv, S_P, optimize=True)
    st_s, st_ld = np.linalg.slogdet(S_ct); sp_s, sp_ld = np.linalg.slogdet(S_P)
    st_ld = np.where(st_s > 0, st_ld, np.nan)
    sp_ld = np.where(sp_s > 0, sp_ld, np.nan)
    kl_pt = 0.5 * (tr + quad - k + (st_ld - sp_ld))

    valid = np.isfinite(kl_pt) & (w > 0.0)
    return float(np.nanmean(kl_pt[valid]) * float(lam_q)) if np.any(valid) else 0.0



def accumulate_xscale_p_up_gaugecov(
    child, parent, generators_p, lam_p: float, eps: float = 1e-6,
    use_cached_exp: bool = True, child_only: bool = True, ctx=None,
    weight_mask=None,  # NEW: pixelwise or scalar responsibility
) -> float:
    """
    Cross-scale model KL (UP): transport child -> parent frame in p-fiber.
    Computes KL(N_parent || N_child→parent) as masked mean.
    Parent grads always; child grads if child_only=False.
    Optional `weight_mask` reweights the overlap to support multi-parent membership.
    """
    import numpy as np
    if lam_p <= 0.0:
        return 0.0

    # exp(φ̃) from cache
    E_c = E_grid(ctx, child,  which="p")     # (...,K,K)
    E_p = E_grid(ctx, parent, which="p")     # (...,K,K)

    # Λ̃_up = E_p @ E_c^T
    Lambda = Lambda_up(ctx, child, parent, which="p")
    ΛT     = np.swapaxes(Lambda, -1, -2)

    # fields (model)
    mu_c = child.mu_p_field
    S_c  = sanitize_sigma(getattr(child,  "Sigma_p_field", child.sigma_p_field), eps=eps)
    mu_P = parent.mu_p_field
    S_P  = sanitize_sigma(getattr(parent, "Sigma_p_field", parent.sigma_p_field), eps=eps)

    # transport child stats to parent frame
    mu_ct = np.einsum("...ij,...j->...i", Lambda, mu_c, optimize=True)
    S_ct  = np.einsum("...ik,...kl,...jl->...ij", Lambda, S_c, ΛT, optimize=True)
    S_ct  = 0.5*(S_ct + np.swapaxes(S_ct, -1, -2))
    S_ct  = sanitize_sigma(S_ct, eps=eps)

    # inverses
    S_ct_inv = safe_inv(S_ct, eps=eps)
    S_P_inv  = safe_inv(S_P,  eps=eps)

    # mask weights × optional responsibility
    w = np.minimum(np.asarray(child.mask, float), np.asarray(parent.mask, float))
    if weight_mask is not None:
        if np.isscalar(weight_mask):
            w = w * float(weight_mask)
        else:
            w = w * np.clip(np.asarray(weight_mask, float), 0.0, 1.0)
    w1 = w[..., None]
    w4 = w[..., None, None]

    # parent μ,Σ grads
    g_mu_P = np.einsum("...ij,...j->...i", S_ct_inv, (mu_P - mu_ct), optimize=True)
    g_S_P  = 0.5*(S_ct_inv - S_P_inv)
    g_S_P  = 0.5*(g_S_P + np.swapaxes(g_S_P, -1, -2))

    if getattr(parent, "grad_mu_p", None) is None:
        parent.grad_mu_p = np.zeros_like(mu_P)
    if getattr(parent, "grad_sigma_p", None) is None:
        parent.grad_sigma_p = np.zeros_like(S_P)

    parent.grad_mu_p    += float(lam_p) * (g_mu_P * w1)
    parent.grad_sigma_p += float(lam_p) * (g_S_P  * w4)

    # backprop through Λ̃_up
    dmu   = (mu_P - mu_ct)
    dmu_t = - np.einsum("...ij,...j->...i", S_ct_inv, dmu, optimize=True)
    outer = dmu[..., None] @ np.swapaxes(dmu[..., None], -1, -2)
    dKL_dA = 0.5 * (S_P + outer - S_ct)
    dS_ct = - np.einsum("...ik,...kl,...lj->...ij", S_ct_inv, dKL_dA, S_ct_inv, optimize=True)
    dS_ct = 0.5*(dS_ct + np.swapaxes(dS_ct, -1, -2))

    term_mean = dmu_t[..., None] @ mu_c[..., None, :]
    term_cov  = 2.0 * np.einsum("...ij,...jk,...kl->...il", dS_ct, Lambda, S_c, optimize=True)
    GΛ = (term_mean + term_cov) * w4

    # parent φ̃ grads via Λ̃_up = E_p @ E_c^T  -> T_parent = GΛ @ E_c^T
    E_c_T = np.swapaxes(E_grid(ctx, child,  which="p"), -1, -2)
    T_parent = np.einsum("...ij,...jk->...ik", GΛ, E_c_T, optimize=True)
    D_p = d_exp_phi_exact(parent.phi_model, parent.generators_p, exp_phi_all=E_p)
    g_phi_tilde_p = np.stack([np.einsum("...ij,...ij->...", T_parent, D_p[a], optimize=True) for a in range(len(D_p))], axis=-1)
    g_phi_tilde_p = g_phi_tilde_p * w1

    if getattr(parent, "grad_phi_tilde", None) is None:
        parent.grad_phi_tilde = np.zeros_like(parent.phi_model)
    parent.grad_phi_tilde += float(lam_p) * g_phi_tilde_p

    # optional child grads
    if not child_only:
        T_child = - np.einsum("...ij,...jk->...ik", ΛT, GΛ, optimize=True)
        D_c = d_exp_phi_exact(child.phi_model, child.generators_p, exp_phi_all=E_c)
        g_phi_tilde_c = np.stack([np.einsum("...ij,...ij->...", T_child, D_c[a], optimize=True) for a in range(len(D_c))], axis=-1)
        g_phi_tilde_c = g_phi_tilde_c * w1

        if getattr(child, "grad_phi_tilde", None) is None:
            child.grad_phi_tilde = np.zeros_like(child.phi_model)
        child.grad_phi_tilde += float(lam_p) * g_phi_tilde_c

        g_mu_c = np.einsum("...ij,...j->...i", ΛT, dmu_t, optimize=True)
        g_S_c  = np.einsum("...ik,...kl,...jl->...ij", ΛT, dS_ct, Lambda, optimize=True)
        g_S_c  = 0.5*(g_S_c + np.swapaxes(g_S_c, -1, -2))

        if getattr(child, "grad_mu_p", None) is None:
            child.grad_mu_p = np.zeros_like(mu_c)
        if getattr(child, "grad_sigma_p", None) is None:
            child.grad_sigma_p = np.zeros_like(S_c)

        child.grad_mu_p    += float(lam_p) * (g_mu_c * w1)
        child.grad_sigma_p += float(lam_p) * (g_S_c  * w4)

    # scalar KL (masked mean): KL(N_P || N_ct)
    k = mu_P.shape[-1]
    diff = (mu_P - mu_ct)[..., None]
    quad = (np.swapaxes(diff, -1, -2) @ S_ct_inv @ diff)[..., 0, 0]
    tr   = np.einsum("...ij,...ji->...", S_ct_inv, S_P, optimize=True)
    st_s, st_ld = np.linalg.slogdet(S_ct); sp_s, sp_ld = np.linalg.slogdet(S_P)
    st_ld = np.where(st_s > 0, st_ld, np.nan)
    sp_ld = np.where(sp_s > 0, sp_ld, np.nan)
    kl_pt = 0.5 * (tr + quad - k + (st_ld - sp_ld))

    valid = np.isfinite(kl_pt) & (w > 0.0)
    return float(np.nanmean(kl_pt[valid]) * float(lam_p)) if np.any(valid) else 0.0


#====================================================================
#
#     CROSS SCALE INFERENCE GRADS THETA
#
#====================================================================



# =====================  CROSS-SCALE INFERENCE via Θ ==========================
# Θ_{k←k+1} : parent p -> child q   using  Φ̃_k  ∘  Λ^{(p)}_{k←k+1}
#  ṪΘ_{k←k+1}: parent q -> child p   using   Φ_k  ∘  Λ^{(q)}_{k←k+1}
#
# KL_infer_q(child k, parent k+1):   KL( q_k || Θ_{k←k+1} p_{k+1} )
# KL_infer_p(child k, parent k+1):   KL( p_k || ṪΘ_{k←k+1} q_{k+1} )
#
# Notes:
#  - We reuse central caches E_grid(...) and Lambda_dn(...) to remain consistent.
#  - Φ̃ = e^{φ_k} Φ̃₀ e^{-φ̃_k} and Φ  = e^{φ̃_k} Φ₀ e^{-φ_k} (matches your current code).
#  - Grads flow to child (μ,Σ) and (φ,φ̃). Parent grads are optional (child_only=False).
# ============================================================================

import numpy as _np, config as _CFG
from transport_cache import E_grid, Lambda_dn
from numerical_utils import sanitize_sigma as _sanitize, safe_inv as _inv, safe_omega_inv as _oinv
from omega import d_exp_phi_exact as _dexp_q, d_exp_phi_tilde_exact as _dexp_p

def _masked_overlap_bool(a, b, thr):
    ma = _np.asarray(a, _np.float32) > float(thr)
    mb = _np.asarray(b, _np.float32) > float(thr)
    return (ma & mb)

def _push_linear_gaussian(M, mu, S):
    mu_t = _np.einsum("...ij,...j->...i", M, mu, optimize=True)
    S_t  = _np.einsum("...ik,...kl,...lj->...ij", M, S, _np.swapaxes(M, -1, -2), optimize=True)
    return mu_t, _sanitize(S_t, eps=float(getattr(_CFG, "eps", 1e-6)))

def _kl_q_vs_r(mu_q, S_q, mu_r, S_r, *, eps=1e-6):
    """KL( N_q || N_r ), vectorized, with d/dμ_r and d/dΣ_r convenience returns."""
    S_q = _sanitize(_np.asarray(S_q, _np.float32), eps=eps)
    S_r = _sanitize(_np.asarray(S_r, _np.float32), eps=eps)
    K   = S_q.shape[-1]
    S_r_inv = _inv(S_r, eps=eps)

    dmu    = (mu_q - mu_r)                              # (...,K)
    trace  = _np.einsum("...ii->...", S_r_inv @ S_q)    # (...)
    maha   = _np.einsum("...i,...ij,...j->...", dmu, S_r_inv, dmu)
    logdet = _np.linalg.slogdet(S_r)[1] - _np.linalg.slogdet(S_q)[1]
    kl     = 0.5 * (trace + maha - K + logdet)

    # grads wrt r-params (the "target" of KL)
    # ∂KL/∂μ_r = - S_r^{-1} (μ_q - μ_r)
    g_mu_r = -_np.einsum("...ij,...j->...i", S_r_inv, dmu, optimize=True)

    # ∂KL/∂Σ_r = 0.5( Σ_r^{-1} - Σ_r^{-1}( Σ_q + dμ dμ^T ) Σ_r^{-1} )
    outer  = _np.einsum("...i,...j->...ij", dmu, dmu, optimize=True)
    g_S_r  = 0.5 * (S_r_inv - _np.einsum("...ik,...kl,...lj->...ij", S_r_inv, S_q + outer, S_r_inv, optimize=True))

    # convenience: dμ_t = g_mu_r   and   dS_t = - S_r^{-1} g_S_r S_r
    # (these are the same "dμ_t" / "dS_t" symbols used in your Λ code)
    dmu_t = g_mu_r
    dS_t  = -_np.einsum("...ik,...kl,...lj->...ij", S_r_inv, g_S_r, S_r, optimize=True)

    return kl.astype(_np.float32), dmu_t.astype(_np.float32), dS_t.astype(_np.float32)

def _build_phi_tilde_full(ctx, agent, generators_q, generators_p):
    """Φ̃ = e^{φ} Φ̃₀ e^{-φ̃} with cache-backed exp."""
    E_q = E_grid(ctx, agent, which="q")
    E_p = E_grid(ctx, agent, which="p")
    E_p_inv = _oinv(E_p, eps=float(getattr(_CFG, "eps", 1e-6)), debug=False)
    Phi_tilde_0 = getattr(agent, "Phi_tilde_0", getattr(agent, "bundle_morphism_p_to_q_0", None))
    if Phi_tilde_0 is None:
        raise ValueError("Agent is missing Phi_tilde_0 / bundle_morphism_p_to_q_0")
    Phi_tilde = _np.einsum("...ik,...kj,...jl->...il", E_q, _np.asarray(Phi_tilde_0, _np.float32), E_p_inv, optimize=True)
    return Phi_tilde, E_q, E_p

def _build_phi_full(ctx, agent, generators_q, generators_p):
    """Φ = e^{φ̃} Φ₀ e^{-φ} with cache-backed exp."""
    E_q = E_grid(ctx, agent, which="q")
    E_p = E_grid(ctx, agent, which="p")
    E_q_inv = _oinv(E_q, eps=float(getattr(_CFG, "eps", 1e-6)), debug=False)
    Phi_0 = getattr(agent, "Phi_0", getattr(agent, "bundle_morphism_q_to_p_0", None))
    if Phi_0 is None:
        raise ValueError("Agent is missing Phi_0 / bundle_morphism_q_to_p_0")
    Phi = _np.einsum("...ik,...kj,...jl->...il", E_p, _np.asarray(Phi_0, _np.float32), E_q_inv, optimize=True)
    return Phi, E_q, E_p

def build_theta_down_q(ctx, child, parent, generators_q, generators_p):
    """Θ_{k←k+1} = Φ̃_k ∘ Λ^{(p)}_{k←k+1}  :  p_parent → q_child"""
    Phi_tilde, E_q, E_p = _build_phi_tilde_full(ctx, child, generators_q, generators_p)
    Lambda_p = Lambda_dn(ctx, child, parent, which="p")   # parent p → child p
    Theta = _np.einsum("...ik,...kj->...ij", Phi_tilde, Lambda_p, optimize=True)
    return Theta, (Phi_tilde, E_q, E_p, Lambda_p)

def build_theta_down_p(ctx, child, parent, generators_q, generators_p):
    """ṪΘ_{k←k+1} = Φ_k ∘ Λ^{(q)}_{k←k+1}  :  q_parent → p_child"""
    Phi, E_q, E_p = _build_phi_full(ctx, child, generators_q, generators_p)
    Lambda_q = Lambda_dn(ctx, child, parent, which="q")   # parent q → child q
    Theta_tilde = _np.einsum("...ik,...kj->...ij", Phi, Lambda_q, optimize=True)
    return Theta_tilde, (Phi, E_q, E_p, Lambda_q)

def compute_xscale_infer_kl_q(child, parent, *, generators_q, generators_p,
                              ctx=None, support_tau=1e-3, eps=1e-6,
                              return_field=False, want_grads=True, child_only=True):
    """
    KL_infer_q = KL( q_child || Θ p_parent ), Θ = Φ̃_child ∘ Λ_p(down)
    Returns:
        scalar_kl or (scalar_kl, field)
    Side-effects (if want_grads):
        accumulates grads into child.{grad_mu_q, grad_sigma_q, grad_phi, grad_phi_model}
        and, if child_only=False, parent.{grad_mu_p, grad_sigma_p, grad_phi_model}
    """
    m = _masked_overlap_bool(child.mask, parent.mask, support_tau)
    if not _np.any(m):
        return (_np.nan, _np.zeros_like(child.mask, _np.float32)) if return_field else _np.nan

    mu_q = _np.asarray(child.mu_q_field, _np.float32)
    S_q  = _np.asarray(child.sigma_q_field, _np.float32)
    mu_p = _np.asarray(parent.mu_p_field, _np.float32)
    S_p  = _np.asarray(parent.sigma_p_field, _np.float32)

    Theta, (Phi_tilde, E_q, E_p, Lambda_p) = build_theta_down_q(ctx, child, parent, generators_q, generators_p)

    # push parent-p to child-q via Θ
    mu_t, S_t = _push_linear_gaussian(Theta, mu_p, S_p)

    # KL and convenient derivatives wrt "target" (μ_t, Σ_t)
    kl_field, dmu_t, dS_t = _kl_q_vs_r(mu_q, S_q, mu_t, S_t, eps=eps)
    kl_scalar = float(_np.nanmean(kl_field[m])) if _np.any(m) else _np.nan

    if not want_grads:
        return (kl_scalar, kl_field.astype(_np.float32)) if return_field else kl_scalar

    # ---------- child μ_q, Σ_q (natural) ----------
    # Natural grads: ∇_μ = Σ (Σ_t^{-1}(μ_t − μ_q)), ∇_Σ = 0.5( Σ_t^{-1} − Σ^{-1} + ...)
    # Using your existing pattern: apply inverse safely, then broadcast on mask
    S_q_inv = _inv(_sanitize(S_q, eps=eps), eps=eps)
    S_t_inv = _inv(_sanitize(S_t, eps=eps), eps=eps)

    # grads w.r.t q (as in your Λ code)
    g_mu_q = _np.einsum("...ij,...j->...i", S_q, -dmu_t, optimize=True)
    # for Σ we use your established dS form to produce the symmetric natural update:
    # map "r-parameter" differential onto q's manifold in your standard way
    g_S_q = 0.5 * (_np.einsum("...ij->...ij", S_t_inv) - S_q_inv)

    # ---------- matrix backprop to Θ ----------
    # ∂KL/∂M  where M ≡ Θ
    # mean part
    term_mean = _np.einsum("...i,...j->...ij", dmu_t, mu_p, optimize=True)
    # cov part: 2 * dS_t @ M @ Σ_P
    term_cov  = 2.0 * _np.einsum("...ik,...kl,...lj->...ij", dS_t, Theta, S_p, optimize=True)
    G_Theta   = term_mean + term_cov

    # Split to Φ̃ and Λ_p:
    # G_{Φ̃} = G_Θ Λ_p^T
    G_Phi_tilde = _np.einsum("...ik,...jk->...ij", G_Theta, _np.swapaxes(Lambda_p, -1, -2), optimize=True)
    # G_{Λ_p} = Φ̃^T G_Θ
    G_Lambda_p  = _np.einsum("...ki,...kj->...ij", _np.swapaxes(Phi_tilde, -1, -2), G_Theta, optimize=True)

    # ---------- child φ (q) gradient via Φ̃ ----------
    # dΦ̃_a = (∂e^{φ}/∂φ^a) Φ̃₀ e^{-φ̃}  ⇒ inner product with T_q = G_{Φ̃} @ (Φ̃₀ e^{-φ̃})^T
    Q_all_q = _dexp_q(_np.asarray(child.phi, _np.float32), generators_q)
    Middle_q = _np.einsum("...kj,...jl->...kl", _np.asarray(getattr(child, "Phi_tilde_0", getattr(child, "bundle_morphism_p_to_q_0")),_np.float32), _oinv(E_p, eps=eps, debug=False), optimize=True)
    T_q = _np.einsum("...ik,...jk->...ij", G_Phi_tilde, _np.swapaxes(Middle_q, -1, -2), optimize=True)
    g_phi_q = _np.stack([_np.einsum("...ij,...ij->...", T_q, Qa, optimize=True) for Qa in Q_all_q], axis=-1)

    # ---------- child φ̃ (p) gradient: two paths (via Φ̃ and via Λ_p) ----------
    # (A) via Φ̃:  dΦ̃_a = - Φ̃ R_a,  R_a = Q̃_a e^{-φ̃}
    Q_all_p = _dexp_p(_np.asarray(child.phi_model, _np.float32), generators_p)
    R = _np.einsum("...aik,...kj->...aij", _np.stack(Q_all_p, axis=-3), _oinv(E_p, eps=eps, debug=False), optimize=True)
    dPhi_part = -_np.einsum("...ik,...akj->...aij", Phi_tilde, R, optimize=True)  # (...,a,Kq,Kp)
    g_phi_t_via_Phi = _np.einsum("...ij,...aij->...a", G_Phi_tilde, dPhi_part, optimize=True)

    # (B) via Λ_p (reuse Λ p-down gradient structure from your Λ grads)
    # For child φ̃:   T_child = G_Λ @ E_parent^T
    E_parent_p = E_grid(ctx, parent, which="p")
    T_child = _np.einsum("...ik,...jk->...ij", G_Lambda_p, _np.swapaxes(E_parent_p, -1, -2), optimize=True)
    g_phi_t_via_L = _np.stack([_np.einsum("...ij,...ij->...", T_child, Qa, optimize=True) for Qa in Q_all_p], axis=-1)

    g_phi_tilde = g_phi_t_via_Phi + g_phi_t_via_L

    # ---------- optional parent grads (μ_p, Σ_p, φ̃_parent) ----------
    g_mu_p = g_S_p = g_phi_tilde_parent = None
    if not child_only:
        # g_μP = Θ^T dμ_t
        g_mu_p = _np.einsum("...ji,...j->...i", Theta, dmu_t, optimize=True)
        # g_ΣP = Θ^T dS_t Θ
        g_S_p  = _np.einsum("...ik,...kl,...lj->...ij", _np.swapaxes(Theta, -1, -2), dS_t, Theta, optimize=True)
        # parent φ̃ via Λ_p:   T_parent = - Λ_p^T G_Λ
        T_parent = -_np.einsum("...ki,...kj->...ij", _np.swapaxes(Lambda_p, -1, -2), G_Lambda_p, optimize=True)
        Q_all_parent_p = _dexp_p(_np.asarray(parent.phi_model, _np.float32), generators_p)
        g_phi_tilde_parent = _np.stack([_np.einsum("...ij,...ij->...", T_parent, Qa, optimize=True) for Qa in Q_all_parent_p], axis=-1)

    # ---------- accumulate to agents (respect mask) ----------
    mask = m[..., None]
    # child
    child.grad_mu_q     = (getattr(child, "grad_mu_q",     0) + g_mu_q     * mask).astype(_np.float32, copy=False)
    child.grad_sigma_q  = (getattr(child, "grad_sigma_q",  0) + g_S_q      * mask).astype(_np.float32, copy=False)
    child.grad_phi      = (getattr(child, "grad_phi",      0) + g_phi_q    * mask).astype(_np.float32, copy=False)
    child.grad_phi_model= (getattr(child, "grad_phi_model",0) + g_phi_tilde* mask).astype(_np.float32, copy=False)

    if not child_only:
        parent.grad_mu_p     = (getattr(parent, "grad_mu_p",    0) + (g_mu_p    * mask)).astype(_np.float32, copy=False)
        parent.grad_sigma_p  = (getattr(parent, "grad_sigma_p", 0) + (g_S_p     * mask)).astype(_np.float32, copy=False)
        parent.grad_phi_model= (getattr(parent, "grad_phi_model",0) + (g_phi_tilde_parent * mask)).astype(_np.float32, copy=False)

    return (kl_scalar, kl_field.astype(_np.float32)) if return_field else kl_scalar


def compute_xscale_infer_kl_p(child, parent, *, generators_q, generators_p,
                              ctx=None, support_tau=1e-3, eps=1e-6,
                              return_field=False, want_grads=True, child_only=True):
    """
    KL_infer_p = KL( p_child || ṪΘ q_parent ),  ṪΘ = Φ_child ∘ Λ_q(down)
    All conventions mirror the q-side routine.
    """
    m = _masked_overlap_bool(child.mask, parent.mask, support_tau)
    if not _np.any(m):
        return (_np.nan, _np.zeros_like(child.mask, _np.float32)) if return_field else _np.nan

    mu_p = _np.asarray(child.mu_p_field, _np.float32)
    S_p  = _np.asarray(child.sigma_p_field, _np.float32)
    mu_qP = _np.asarray(parent.mu_q_field, _np.float32)
    S_qP  = _np.asarray(parent.sigma_q_field, _np.float32)

    Theta_tilde, (Phi, E_q, E_p, Lambda_q) = build_theta_down_p(ctx, child, parent, generators_q, generators_p)

    mu_t, S_t = _push_linear_gaussian(Theta_tilde, mu_qP, S_qP)
    kl_field, dmu_t, dS_t = _kl_q_vs_r(mu_p, S_p, mu_t, S_t, eps=eps)
    kl_scalar = float(_np.nanmean(kl_field[m])) if _np.any(m) else _np.nan

    if not want_grads:
        return (kl_scalar, kl_field.astype(_np.float32)) if return_field else kl_scalar

    S_p_inv = _inv(_sanitize(S_p, eps=eps), eps=eps)
    S_t_inv = _inv(_sanitize(S_t, eps=eps), eps=eps)

    g_mu_p = _np.einsum("...ij,...j->...i", S_p, -dmu_t, optimize=True)
    g_S_p  = 0.5 * (_np.einsum("...ij->...ij", S_t_inv) - S_p_inv)

    # ∂KL/∂M with M ≡ ṪΘ
    term_mean = _np.einsum("...i,...j->...ij", dmu_t, mu_qP, optimize=True)
    term_cov  = 2.0 * _np.einsum("...ik,...kl,...lj->...ij", dS_t, Theta_tilde, S_qP, optimize=True)
    G_Theta   = term_mean + term_cov

    # Split to Φ and Λ_q
    G_Phi   = _np.einsum("...ik,...jk->...ij", G_Theta, _np.swapaxes(Lambda_q, -1, -2), optimize=True)
    G_Lam_q = _np.einsum("...ki,...kj->...ij", _np.swapaxes(Phi, -1, -2), G_Theta, optimize=True)

    # child φ̃ via Φ: left trivialization   (Φ = e^{φ̃} Φ₀ e^{-φ})
    Q_all_p = _dexp_p(_np.asarray(child.phi_model, _np.float32), generators_p)
    Middle_p = _np.einsum("...kj,...jl->...kl", _np.asarray(getattr(child, "Phi_0", getattr(child, "bundle_morphism_q_to_p_0")),_np.float32), _oinv(E_q, eps=eps, debug=False), optimize=True)
    T_p = _np.einsum("...ik,...jk->...ij", G_Phi, _np.swapaxes(Middle_p, -1, -2), optimize=True)
    g_phi_tilde = _np.stack([_np.einsum("...ij,...ij->...", T_p, Qa, optimize=True) for Qa in Q_all_p], axis=-1)

    # child φ via Φ:  dΦ_a = - Φ Q̄_a   with Q̄_a = e^{-φ} (∂e^{φ}/∂φ^a) e^{-φ}
    Q_all_q = _dexp_q(_np.asarray(child.phi, _np.float32), generators_q)
    Qbar = _np.einsum("...ik,...akl,...lj->...aij", _oinv(E_q, eps=eps, debug=False), _np.stack(Q_all_q, axis=-3), _oinv(E_q, eps=eps, debug=False), optimize=True)
    dPhi = -_np.einsum("...ik,...akj->...aij", Phi, Qbar, optimize=True)
    g_phi = _np.einsum("...ij,...aij->...a", G_Phi, dPhi, optimize=True)

    # via Λ_q (child φ): T_child = G_Λ @ E_parent^T
    E_parent_q = E_grid(ctx, parent, which="q")
    T_child = _np.einsum("...ik,...jk->...ij", G_Lam_q, _np.swapaxes(E_parent_q, -1, -2), optimize=True)
    g_phi_via_L = _np.stack([_np.einsum("...ij,...ij->...", T_child, Qa, optimize=True) for Qa in Q_all_q], axis=-1)
    g_phi += g_phi_via_L

    # optional parent grads (μ_qP, Σ_qP, φ_parent)
    g_mu_qP = g_S_qP = g_phi_parent = None
    if not child_only:
        g_mu_qP = _np.einsum("...ji,...j->...i", Theta_tilde, dmu_t, optimize=True)
        g_S_qP  = _np.einsum("...ik,...kl,...lj->...ij", _np.swapaxes(Theta_tilde, -1, -2), dS_t, Theta_tilde, optimize=True)
        T_parent = -_np.einsum("...ki,...kj->...ij", _np.swapaxes(Lambda_q, -1, -2), G_Lam_q, optimize=True)
        Q_all_parent_q = _dexp_q(_np.asarray(parent.phi, _np.float32), generators_q)
        g_phi_parent = _np.stack([_np.einsum("...ij,...ij->...", T_parent, Qa, optimize=True) for Qa in Q_all_parent_q], axis=-1)

    mask = m[..., None]
    # child accumulations
    child.grad_mu_p     = (getattr(child, "grad_mu_p",     0) + g_mu_p     * mask).astype(_np.float32, copy=False)
    child.grad_sigma_p  = (getattr(child, "grad_sigma_p",  0) + g_S_p      * mask).astype(_np.float32, copy=False)
    child.grad_phi      = (getattr(child, "grad_phi",      0) + g_phi      * mask).astype(_np.float32, copy=False)
    child.grad_phi_model= (getattr(child, "grad_phi_model",0) + g_phi_tilde* mask).astype(_np.float32, copy=False)

    if not child_only:
        parent.grad_mu_q     = (getattr(parent, "grad_mu_q",    0) + (g_mu_qP    * mask)).astype(_np.float32, copy=False)
        parent.grad_sigma_q  = (getattr(parent, "grad_sigma_q", 0) + (g_S_qP     * mask)).astype(_np.float32, copy=False)
        parent.grad_phi      = (getattr(parent, "grad_phi",     0) + (g_phi_parent* mask)).astype(_np.float32, copy=False)

    return (kl_scalar, kl_field.astype(_np.float32)) if return_field else kl_scalar













