
from __future__ import annotations
from typing import Any, Dict, Iterable, Optional, Sequence, Tuple
import numpy as np

# Your existing utilities
from omega import exp_lie_algebra_irrep
from numerical_utils import safe_omega_inv

"""
Created on Tue Aug 19 20:19:10 2025

@author: chris and christine
"""

# -*- coding: utf-8 -*-
"""
transport_cache.py
Centralized facade for cached transports: exp(φ), Ω_{ij}, Λ (hooks).
Backed by runtime_ctx.cache (CacheHub). One source of truth, cleared per step.
"""


# ---------------------------------------------------------------------------
# Internal helpers (keys, accessors)
# ---------------------------------------------------------------------------

def _aid(a: Any) -> int:
    """Robust agent id (falls back to object's id if missing)."""
    return int(getattr(a, "id", id(a)))

def _exp_key(agent: Any, which: str) -> Tuple[str, int, str]:
    # which ∈ {'q','p'}
    return ("exp", _aid(agent), which)

def _omega_key(ai: Any, aj: Any, which: str) -> Tuple[str, int, int, str]:
    return ("omega", _aid(ai), _aid(aj), which)

def _lambda_key(child: Any, parent: Any, which: str, up: bool) -> Tuple[str, int, int, str, str]:
    return ("lambda", _aid(child), _aid(parent), which, "up" if up else "dn")

def _get_generators(agent: Any, which: str) -> np.ndarray:
    if which == "q":
        G = getattr(agent, "generators_q", None)
    else:
        G = getattr(agent, "generators_p", None)
    if G is None:
        raise ValueError(f"[transport_cache] generators ({which}) missing on agent id={_aid(agent)}")
    return G

def _get_phi(agent: Any, which: str) -> np.ndarray:
    if which == "q":
        phi = getattr(agent, "phi", None)
    else:
        phi = getattr(agent, "phi_model", None)
    if phi is None:
        raise ValueError(f"[transport_cache] phi field ({which}) missing on agent id={_aid(agent)}")
    return phi


# ---------------------------------------------------------------------------
# Public API: exp(φ) and Ω_{ij}
# ---------------------------------------------------------------------------

def E_grid(ctx: Any, agent: Any, which: str = "q") -> np.ndarray:
    """
    Cached exp(φ) grid for an agent in fiber 'q' or 'p'.
    Shape: (..., K, K), broadcasts over spatial dims.
    """
    cache: Dict[Any, Any] = ctx.cache.ns("exp")
    key = _exp_key(agent, which)
    E = cache.get(key)
    if E is None:
        G = _get_generators(agent, which)
        phi = _get_phi(agent, which)
        E = exp_lie_algebra_irrep(phi, G)  # (..., K, K)
        cache[key] = E
    return E


def Omega(ctx: Any, ai: Any, aj: Any, which: str = "q") -> np.ndarray:
    """
    Cached Ω_{ij} = exp(φ_i) @ inv(exp(φ_j)) for fiber 'q' or 'p'.
    Uses safe_omega_inv for general irreps (not assuming orthogonality).
    """
    om_cache = ctx.cache.ns("omega")
    key = _omega_key(ai, aj, which)
    Om = om_cache.get(key)
    if Om is None:
        Ei = E_grid(ctx, ai, which)   # (..., K, K)
        Ej = E_grid(ctx, aj, which)   # (..., K, K)
        Ej_inv = safe_omega_inv(Ej)   # (..., K, K)
        Om = np.matmul(Ei, Ej_inv)    # (..., K, K)
        om_cache[key] = Om
    return Om


# ---------------------------------------------------------------------------
# Optional Λ hooks (centralize later; stubs return cached value if present)
# ---------------------------------------------------------------------------

# transport_cache.py — add/replace these definitions

def _lambda_key(child: Any, parent: Any, which: str, up: bool) -> Tuple[str, int, int, str, str]:
    return ("lambda", _aid(child), _aid(parent), which, "up" if up else "dn")

# transport_cache.py

def Lambda_dn(ctx: Any, child: Any, parent: Any, which: str = "q") -> np.ndarray:
    """
    Cached Λ↓ (parent → child): Λ↓ = E_child @ inv(E_parent)
    """
    lam_ns = ctx.cache.ns("lambda")
    key = _lambda_key(child, parent, which, up=False)
    Lam = lam_ns.get(key)
    if Lam is None:
        E_c = E_grid(ctx, child, which=which)
        E_p = E_grid(ctx, parent, which=which)
        E_p_inv = safe_omega_inv(E_p)             # <-- inverse, not transpose
        Lam = np.einsum("...ik,...kj->...ij", E_c, E_p_inv, optimize=True)
        lam_ns[key] = Lam
    return Lam

def Lambda_up(ctx: Any, child: Any, parent: Any, which: str = "q") -> np.ndarray:
    """
    Cached Λ↑ (child → parent): Λ↑ = E_parent @ inv(E_child)
    """
    lam_ns = ctx.cache.ns("lambda")
    key = _lambda_key(child, parent, which, up=True)
    Lam = lam_ns.get(key)
    if Lam is None:
        E_c = E_grid(ctx, child, which=which)
        E_p = E_grid(ctx, parent, which=which)
        E_c_inv = safe_omega_inv(E_c)             # <-- inverse, not transpose
        Lam = np.einsum("...ik,...kj->...ij", E_p, E_c_inv, optimize=True)
        lam_ns[key] = Lam
    return Lam



# ---------------------------------------------------------------------------
# Cached dexpinv matrices Jinv(phi)  (SO(3) axis-angle principal ball)
# ---------------------------------------------------------------------------

def _jinv_key(agent: Any, which: str) -> Tuple[str, int, str]:
    # which in {"q","p"}
    return ("jinv", _aid(agent), which)

def _alpha_theta(theta: np.ndarray, theta2: np.ndarray) -> np.ndarray:
    """
    Your existing LUT/Taylor alpha(θ) helper. If you already have one
    (e.g., in update_terms_phi.py), import and call that instead.
    """
    # Minimal stable version (feel free to swap for your LUT):
    eps = 1e-12
    out = np.empty_like(theta, dtype=np.float32)
    small = theta < 1e-3
    # Taylor: alpha ≈ 1/12 + θ²/720
    out[small] = (1.0/12.0 + theta2[small] * (1.0/720.0)).astype(np.float32)
    # General: alpha = (1/θ²)(1 - (θ/2)cot(θ/2))
    t = theta[~small]
    t2 = theta2[~small]
    half = 0.5 * t
    out[~small] = ((1.0 / np.maximum(t2, eps)) * (1.0 - half * (np.cos(half) / np.maximum(np.sin(half), eps)))).astype(np.float32)
    return out

def build_dexpinv_matrix(phi: np.ndarray) -> np.ndarray:
    """
    Vectorized Jinv(phi) for all pixels:
      Jinv = (1 - α θ^2) I  - 0.5 [φ]_×  + α φ φ^T
    phi: (..., 3) axis-angle in principal ball (θ <= π - margin)
    returns: (..., 3, 3)
    """
    phi = np.asarray(phi, np.float32)
    th2 = np.einsum("...i,...i->...", phi, phi)           # (...)
    th  = np.sqrt(th2)                                     # (...)
    alpha = _alpha_theta(th, th2)                          # (...)
    I = np.eye(3, dtype=np.float32)

    # skew(φ)
    K = np.zeros(phi.shape[:-1] + (3, 3), np.float32)
    K[..., 0, 1], K[..., 0, 2] = -phi[..., 2],  phi[..., 1]
    K[..., 1, 0], K[..., 1, 2] =  phi[..., 2], -phi[..., 0]
    K[..., 2, 0], K[..., 2, 1] = -phi[..., 1],  phi[..., 0]

    outer = phi[..., :, None] * phi[..., None, :]          # (...,3,3)
    c0 = (1.0 - alpha * th2)[..., None, None]              # (...,1,1)
    c1 = -0.5
    c2 = alpha[..., None, None]
    return (c0 * I) + (c1 * K) + (c2 * outer)

def Jinv_grid(ctx: Any, agent: Any, which: str = "q") -> np.ndarray:
    """
    Cached Jinv(phi) per pixel (3x3) for φ (which='q') or φ̃ (which='p').
    """
    ns = ctx.cache.ns("jinv")
    key = _jinv_key(agent, which)
    J = ns.get(key)
    if J is None:
        # fetch the field (re-uses your existing accessors)
        phi = _get_phi(agent, which)               # (..., 3)
        # sanitize before building
        phi = np.where(np.isfinite(phi), phi, 0.0).astype(np.float32)
        J = build_dexpinv_matrix(phi)              # (..., 3, 3)
        ns[key] = J
    return J

def warm_Jinv(ctx: Any, agents: Sequence[Any], whiches: Iterable[str] = ("q", "p")) -> None:
    """Precompute Jinv for many agents (idempotent)."""
    for a in agents:
        for w in whiches:
            try:
                _ = Jinv_grid(ctx, a, which=w)
            except Exception:
                pass


# ---------------------------------------------------------------------------
# Bundle morphisms (same-level) and cross-scale morphisms (Θ)
# Cached per-step in "morphism" and "theta" namespaces
# ---------------------------------------------------------------------------

def _morphism_key(agent: Any, kind: str) -> Tuple[str, int, str]:
    # kind in {"q_to_p", "p_to_q"}
    return ("morphism", _aid(agent), kind)

def _theta_key(child: Any, parent: Any, direction: str) -> Tuple[str, int, int, str]:
    # direction in {"down", "up"}
    return ("theta", _aid(child), _aid(parent), direction)


def _get_phi0(agent: Any, kind: str) -> np.ndarray:
    """
    Fetch the base (static) morphism matrices from the agent:
      - kind="q_to_p" -> agent.bundle_morphism_q_to_p (Φ_0), shape (..., Kp, Kq)
      - kind="p_to_q" -> agent.bundle_morphism_p_to_q (Φ̃_0), shape (..., Kq, Kp)
    """
    if kind == "q_to_p":
        M = getattr(agent, "bundle_morphism_q_to_p", None)
        name = "bundle_morphism_q_to_p"
    else:
        M = getattr(agent, "bundle_morphism_p_to_q", None)
        name = "bundle_morphism_p_to_q"
    if M is None:
        raise ValueError(f"[transport_cache] missing {name} on agent id={_aid(agent)}")
    return M


def Phi(ctx, agent, kind: str = "q_to_p"):
    ns  = ctx.cache.ns("morphism")
    key = _morphism_key(agent, kind)
    M = ns.get(key)
    if M is not None:
        return M

    # Delegate to the unified builder (ctx-aware, uses exp_grid_cached)
    from bundle_morphism_utils import compute_direct_morphisms
    Gq = getattr(agent, "generators_q", None)
    Gp = getattr(agent, "generators_p", None)
    Phi_0 = getattr(agent, "Phi_0", None)
    Phi_tilde_0 = getattr(agent, "Phi_tilde_0", None)

    # Build both once; cache both
    Phi_full, Phit_full = compute_direct_morphisms(
        phi=getattr(agent, "phi"),
        phi_model=getattr(agent, "phi_model"),
        generators_q=Gq,
        generators_p=Gp,
        Phi_0=(np.asarray(Phi_0)       if Phi_0       is not None else np.eye(agent.mu_p_field.shape[-1], agent.mu_q_field.shape[-1], dtype=np.float32)),
        Phi_tilde_0=(np.asarray(Phi_tilde_0) if Phi_tilde_0 is not None else np.eye(agent.mu_q_field.shape[-1], agent.mu_p_field.shape[-1], dtype=np.float32)),
        ctx=ctx,
    )

    ns[_morphism_key(agent, "q_to_p")] = Phi_full
    ns[_morphism_key(agent, "p_to_q")] = Phit_full

    return Phi_full if kind == "q_to_p" else Phit_full


def Phi_tilde(ctx: Any, agent: Any) -> np.ndarray:
    """Shortcut for kind='p_to_q'."""
    return Phi(ctx, agent, kind="p_to_q")


def Theta_dn(ctx, child, parent):
    Lq = Lambda_dn(ctx, child, parent, which="q")  # (..., Kq_c, Kq_p)
    Lp = Lambda_dn(ctx, child, parent, which="p")  # (..., Kp_c, Kp_p)
    Phi_c   = Phi(ctx, child, kind="q_to_p")       # (..., Kp_c, Kq_c)
    Phit_c  = Phi(ctx, child, kind="p_to_q")       # (..., Kq_c, Kp_c)
    _assert_chain("Theta_dn.q", Phit_c, Lp)        # (Kq_c×Kp_c) @ (Kp_c×Kp_p)
    _assert_chain("Theta_dn.p", Phi_c,  Lq)        # (Kp_c×Kq_c) @ (Kq_c×Kq_p)
    Theta_q = np.einsum("...ik,...kj->...ij", Phit_c, Lp, optimize=True)  # (..., Kq_c, Kp_p)
    Theta_p = np.einsum("...ik,...kj->...ij", Phi_c,  Lq, optimize=True)  # (..., Kp_c, Kq_p)
    out = {"q": Theta_q, "p": Theta_p}
    ctx.cache.ns("theta")[_theta_key(child, parent, "down")] = out
    return out

def Theta_up(ctx, child, parent):
    Lq = Lambda_up(ctx, child, parent, which="q")  # (..., Kq_p, Kq_c)
    Lp = Lambda_up(ctx, child, parent, which="p")  # (..., Kp_p, Kp_c)
    Phi_p   = Phi(ctx, parent, kind="q_to_p")      # (..., Kp_p, Kq_p)
    Phit_p  = Phi(ctx, parent, kind="p_to_q")      # (..., Kq_p, Kp_p)
    _assert_chain("Theta_up.q",  Phit_p, Lp)       # (Kq_p×Kp_p) @ (Kp_p×Kp_c)
    _assert_chain("Theta_up.p",  Phi_p,  Lq)       # (Kp_p×Kq_p) @ (Kq_p×Kq_c)
    Theta_q = np.einsum("...ik,...kj->...ij", Phit_p, Lp, optimize=True)  # (..., Kq_p, Kp_c)
    Theta_p = np.einsum("...ik,...kj->...ij", Phi_p,  Lq, optimize=True)  # (..., Kp_p, Kq_c)
    out = {"q": Theta_q, "p": Theta_p}
    ctx.cache.ns("theta")[_theta_key(child, parent, "up")] = out
    return out




# ---------------------------------------------------------------------------
# Warming & invalidation
# ---------------------------------------------------------------------------

def warm_E(ctx: Any, agents: Sequence[Any], whiches: Iterable[str] = ("q", "p")) -> None:
    """Precompute exp(φ) for many agents (idempotent)."""
    for a in agents:
        for w in whiches:
            try:
                _ = E_grid(ctx, a, which=w)
            except Exception:
                # Keep warm-up best-effort; avoid failing the whole pass.
                pass

def warm_Omega(ctx: Any, pairs: Sequence[Tuple[Any, Any]], which: str = "q") -> None:
    """Precompute Ω_{ij} for (i, j) pairs (idempotent)."""
    for (ai, aj) in pairs:
        try:
            _ = Omega(ctx, ai, aj, which=which)
        except Exception:
            pass

def invalidate_agent(ctx: Any, agent: Any) -> None:
    aid = _aid(agent)
    for ns_name in ("exp", "omega", "lambda", "jinv"):  # <-- added "jinv"
        ns = ctx.cache.ns(ns_name)
        to_kill = [k for k in list(ns.keys())
                   if isinstance(k, tuple) and (aid in k)]
        for k in to_kill:
            ns.pop(k, None)



# ---------------------------------------------------------------------------
# Transitional compatibility helpers (optional)
# ---------------------------------------------------------------------------

def get_or_build_E(ctx: Optional[Any], agent: Any, which: str = "q") -> np.ndarray:
    """
    Transitional shim: if ctx given, returns E_grid(ctx,...); else computes
    exp_lie_algebra_irrep on the fly (no caching). Useful for gradual adoption.
    """
    if ctx is None:
        G = _get_generators(agent, which)
        phi = _get_phi(agent, which)
        return exp_lie_algebra_irrep(phi, G)
    return E_grid(ctx, agent, which=which)

def _matmul_shapes_ok(A, B):
    # A(..., i, k) @ B(..., k, j) -> (..., i, j)
    if A is None or B is None:
        return False
    if A.ndim < 2 or B.ndim < 2:
        return False
    return A.shape[-1] == B.shape[-2]

def _assert_chain(name, *mats):
    # Ensure M1@M2@... is dimensionally valid
    for idx in range(len(mats) - 1):
        if not _matmul_shapes_ok(mats[idx], mats[idx+1]):
            a = mats[idx].shape if mats[idx] is not None else None
            b = mats[idx+1].shape if mats[idx+1] is not None else None
            raise ValueError(f"[{name}] shape mismatch at link {idx}: {a} @ {b}")


