# -*- coding: utf-8 -*-
"""
Created on Thu Aug 21 13:30:00 2025

@author: chris and christine
"""
from __future__ import annotations


from preprocess_utils import build_all_lambda_caches, preprocess_all_agents
from runtime_context import _collect_by_ids
from gaussian_core import directed_kl_weight_after_transport

# ---------------------------------------------------------------------------
# Gaussian target getters: peer / downward (parent→child) / upward (child→parent)
# Return (mu_q_tgt, Sig_q_tgt, mu_p_tgt, Sig_p_tgt) all expressed in agent_i fibers
# ---------------------------------------------------------------------------

import numpy as np
from transport_cache import Lambda_dn, Lambda_up, Theta_dn, Theta_up
from bundle_morphism_utils import safe_batch_apply_morphism_nat  # existing helper

def _apply_gaussian_morphism(mu, Sig, M):
    """
    Apply rectangular morphism field M[..., K_out, K_in] to Gaussian
    (mu[..., K_in], Sig[..., K_in, K_in]) using your validated routine.
    Returns (mu_out, Sig_out) with Σ symmetrized/sanitized.
    """
    return safe_batch_apply_morphism_nat(mu, Sig, M)

def gaussian_targets_same(ctx, agent_i, agent_j):
    """
    Peer (same level): for μ/Σ KL we compare in the same fiber (no Ω for μ/Σ).
    Return j's fields directly; caller will mask to agent_i's support.
    """
    mu_q = getattr(agent_j, "mu_q_field")
    Si_q = getattr(agent_j, "sigma_q_field")
    mu_p = getattr(agent_j, "mu_p_field")
    Si_p = getattr(agent_j, "sigma_p_field")
    return mu_q, Si_q, mu_p, Si_p

def gaussian_targets_down(ctx, child, parent):
    """
    Downward (parent→child): map parent fields into child's fibers.

    Convention here (consistent/symmetric):
      - q-targets use Λ↓_q (same-fiber: parent q → child q).
      - p-targets use Λ↓_p (same-fiber: parent p → child p).

    If you later prefer cross-fiber for p (i.e., Θ↓.p: parent q → child p),
    swap the Lp branch to Theta_dn(ctx, child, parent)["p"].
    """
    # parent q → child q (same fiber)
    Lq = Lambda_dn(ctx, child, parent, which="q")      # (..., Kq_child, Kq_parent)
    mu_q_p = getattr(parent, "mu_q_field")
    Si_q_p = getattr(parent, "sigma_q_field")
    mu_q_tgt, Si_q_tgt = _apply_gaussian_morphism(mu_q_p, Si_q_p, Lq)

    # parent p → child p (same fiber)
    Lp = Lambda_dn(ctx, child, parent, which="p")      # (..., Kp_child, Kp_parent)
    mu_p_p = getattr(parent, "mu_p_field")
    Si_p_p = getattr(parent, "sigma_p_field")
    mu_p_tgt, Si_p_tgt = _apply_gaussian_morphism(mu_p_p, Si_p_p, Lp)

    return (
        np.asarray(mu_q_tgt, np.float32), np.asarray(Si_q_tgt, np.float32),
        np.asarray(mu_p_tgt, np.float32), np.asarray(Si_p_tgt, np.float32)
    )

def gaussian_targets_up(ctx, child, parent):
    """
    Upward (child→parent): map child fields into parent's fibers.

    Symmetric convention:
      - q-targets use Λ↑_q (same-fiber: child q → parent q).
      - p-targets use Λ↑_p (same-fiber: child p → parent p).

    As above, you could switch p to cross-fiber via Θ↑.p if desired.
    """
    # child q → parent q (same fiber)
    Lq = Lambda_up(ctx, child, parent, which="q")      # (..., Kq_parent, Kq_child)
    mu_q_c = getattr(child, "mu_q_field")
    Si_q_c = getattr(child, "sigma_q_field")
    mu_q_tgt, Si_q_tgt = _apply_gaussian_morphism(mu_q_c, Si_q_c, Lq)

    # child p → parent p (same fiber)
    Lp = Lambda_up(ctx, child, parent, which="p")      # (..., Kp_parent, Kp_child)
    mu_p_c = getattr(child, "mu_p_field")
    Si_p_c = getattr(child, "sigma_p_field")
    mu_p_tgt, Si_p_tgt = _apply_gaussian_morphism(mu_p_c, Si_p_c, Lp)

    return (
        np.asarray(mu_q_tgt, np.float32), np.asarray(Si_q_tgt, np.float32),
        np.asarray(mu_p_tgt, np.float32), np.asarray(Si_p_tgt, np.float32)
    )


# -- hierarchy wiring ---------------------------------------------------------
from collections import defaultdict

def build_hierarchy_maps(all_agents):
    """
    Returns (parents_for_agent, children_for_agent) as dict[int, list[agent]].
    Tries multiple common field names so it works with your current agent class.
    """
    # allow dict or list
    if isinstance(all_agents, dict):
        by_id = all_agents
        agents_iter = list(all_agents.values())
    else:
        agents_iter = list(all_agents)
        by_id = {int(getattr(a, "id", i)): a for i, a in enumerate(agents_iter)}

    parents_for = defaultdict(list)
    children_for = defaultdict(list)

    for a in agents_iter:
        aid = int(getattr(a, "id", id(a)))

        # explicit children list
        kids = getattr(a, "children", None)
        if kids:
            for c in kids:
                cid = int(getattr(c, "id", getattr(c, "child_id", id(c))))
                child_obj = by_id.get(cid, c)
                children_for[aid].append(child_obj)
                parents_for[int(getattr(child_obj, "id", cid))].append(a)

        # explicit parents list
        pars = getattr(a, "parents", None)
        if pars:
            for p in pars:
                pid = int(getattr(p, "id", getattr(p, "parent_id", id(p))))
                par_obj = by_id.get(pid, p)
                parents_for[aid].append(par_obj)
                children_for[int(getattr(par_obj, "id", pid))].append(a)

        # single parent fields
        for fname in ("parent", "parent_ref"):
            p = getattr(a, fname, None)
            if p is not None:
                pid = int(getattr(p, "id", getattr(p, "parent_id", id(p))))
                par_obj = by_id.get(pid, p)
                parents_for[aid].append(par_obj)
                children_for[int(getattr(par_obj, "id", pid))].append(a)

        # id-only parent fields
        for fname in ("parent_id", "parent_idx"):
            pid = getattr(a, fname, None)
            if pid is not None:
                pid = int(pid)
                par_obj = by_id.get(pid)
                if par_obj is not None:
                    parents_for[aid].append(par_obj)
                    children_for[pid].append(a)

    # de-dup (optional)
    for d in (parents_for, children_for):
        for k, lst in d.items():
            uniq = []
            seen = set()
            for x in lst:
                xid = int(getattr(x, "id", id(x)))
                if xid not in seen:
                    uniq.append(x); seen.add(xid)
            d[k] = uniq

    return dict(parents_for), dict(children_for)




def refresh_spawn_alignment_caches(
    ctx,
    children,
    agents,
    *,
    G_q=None,
    G_p=None,
    tau_q=None,
    tau_p=None,
    alpha=None,          # 0→model-only, 1→belief-only
    sm_tau=None,         # softmin temperature across neighbors
    mask_tau=None,       # support threshold on masks
    use_cover_weight=True,
    kl_cap=None,         # kept for signature compat; not used
    debug=False,
):
    """
    Build *spawn-only* caches on each child (per pixel):
        spawn_nb_count, spawn_min_kl_q/p, spawn_softmin_kl_q/p,
        spawn_cover_weight (opt), spawn_A_final, kl_field, agreement_field.

    Notes
    -----
    - Uses ctx-aware transport/KL via directed_kl_weight_after_transport(..., ctx=ctx, G=G_*).
    - Ω/exp caching is entirely in the runtime transport cache (no per-agent caches).
    """
    import numpy as np
    import config as _cfg
       

    # defaults
    tau_q    = float(getattr(_cfg, "tau_align_q", 0.45))        if tau_q    is None else float(tau_q)
    tau_p    = float(getattr(_cfg, "tau_align_p", 0.45))        if tau_p    is None else float(tau_p)
    alpha    = float(getattr(_cfg, "blend_qp_alpha", 0.50))     if alpha    is None else float(alpha)
    sm_tau   = float(getattr(_cfg, "spawn_softmin_tau", 0.40))  if sm_tau   is None else float(sm_tau)
    mask_tau = float(getattr(_cfg, "support_cutoff_eps", 1e-4)) if mask_tau is None else float(mask_tau)

    tiny = float(getattr(_cfg, "log_eps", 1e-9))

    # id -> agent for quick neighbor lookup
    id2A = {int(a.id): a for a in (agents or []) if a is not None}

    for ch in (children or []):
        if ch is None:
            continue

        H, W = np.asarray(ch.mask, np.float32).shape[:2]
        present_i = (np.asarray(ch.mask, np.float32) > mask_tau)

        # dims and generator guards
        Kq = int(getattr(getattr(ch, "mu_q_field", None), "shape", (0, 0, 0))[-1]) if getattr(ch, "mu_q_field", None) is not None else 0
        Kp = int(getattr(getattr(ch, "mu_p_field", None), "shape", (0, 0, 0))[-1]) if getattr(ch, "mu_p_field", None) is not None else 0
        have_q = (Kq > 0 and G_q is not None)
        have_p = (Kp > 0 and G_p is not None)
        if (Kq > 0 and G_q is None) or (Kp > 0 and G_p is None):
            # keep your explicit guard behavior
            if Kq > 0 and G_q is None:
                raise ValueError("refresh_spawn_alignment_caches: missing G_q for q-fiber.")
            if Kp > 0 and G_p is None:
                raise ValueError("refresh_spawn_alignment_caches: missing G_p for p-fiber.")

        # init outputs
        nb_count     = np.zeros((H, W), np.int32)
        min_kl_q     = np.full((H, W), np.inf, np.float32)
        min_kl_p     = np.full((H, W), np.inf, np.float32)
        sumexp_q     = np.zeros((H, W), np.float32)  # Σ exp(-KL_q/sm_tau)  (FIX 2: use sm_tau scale)
        sumexp_p     = np.zeros((H, W), np.float32)  # Σ exp(-KL_p/sm_tau)
        cover_weight = np.zeros((H, W), np.float32) if use_cover_weight else None

        if not getattr(ch, "neighbors", None) or not np.any(present_i):
            zf = np.zeros((H, W), np.float32)
            zi = np.zeros((H, W), np.int32)
            ch.spawn_nb_count      = zi
            ch.spawn_min_kl_q      = zf + np.inf
            ch.spawn_min_kl_p      = zf + np.inf
            ch.spawn_softmin_kl_q  = zf
            ch.spawn_softmin_kl_p  = zf
            ch.spawn_cover_weight  = zf if use_cover_weight else None
            ch.spawn_A_final       = zf
            ch.kl_field            = zf
            ch.agreement_field     = zf
            continue

        # per-neighbor accumulation on the overlap only
        for nb in ch.neighbors:
            # FIX 3: robust neighbor id extraction
            if isinstance(nb, dict):
                nid = int(nb.get("id", -1))
            else:
                nid = int(getattr(nb, "id", -1))
            j = id2A.get(nid)
            if j is None:
                continue

            present_j = (np.asarray(j.mask, np.float32) > mask_tau)
            ov = (present_i & present_j)
            if not np.any(ov):
                continue

            iy, ix = np.nonzero(ov)
            # neighbor count (per-pixel) regardless of fibers present
            np.add.at(nb_count, (iy, ix), 1)

            # q-fiber: only if present
            if have_q:
                wq = directed_kl_weight_after_transport(
                    ch, j,
                    ch.mu_q_field, ch.sigma_q_field,
                    j.mu_q_field,  j.sigma_q_field,
                    fiber="q", H=H, W=W, K=Kq, ov=ov, tau=tau_q,
                    ctx=ctx, G=G_q,
                )
                # KL from wq at tau_q
                kq = (-tau_q * np.log(np.maximum(wq[iy, ix], tiny))).astype(np.float32)
                np.minimum.at(min_kl_q, (iy, ix), kq)
                # softmin at sm_tau: exp(-KL/sm_tau)
                np.add.at(sumexp_q, (iy, ix), np.exp(-kq / max(sm_tau, tiny)).astype(np.float32))

            # p-fiber: only if present
            if have_p:
                wp = directed_kl_weight_after_transport(
                    ch, j,
                    ch.mu_p_field, ch.sigma_p_field,
                    j.mu_p_field,  j.sigma_p_field,
                    fiber="p", H=H, W=W, K=Kp, ov=ov, tau=tau_p,
                    ctx=ctx, G=G_p,
                )
                kp = (-tau_p * np.log(np.maximum(wp[iy, ix], tiny))).astype(np.float32)
                np.minimum.at(min_kl_p, (iy, ix), kp)
                np.add.at(sumexp_p, (iy, ix), np.exp(-kp / max(sm_tau, tiny)).astype(np.float32))

            # optional coverage weight
            if use_cover_weight:
                np.add.at(cover_weight, (iy, ix), np.asarray(j.mask, np.float32)[iy, ix])

        # finalize softmins on pixels that had ≥1 neighbor
        valid = (nb_count > 0)

        softmin_q = np.zeros_like(sumexp_q, np.float32)
        softmin_p = np.zeros_like(sumexp_p, np.float32)
        if have_q:
            softmin_q[valid] = (-sm_tau * np.log(np.maximum(sumexp_q[valid], tiny))).astype(np.float32)
        if have_p:
            softmin_p[valid] = (-sm_tau * np.log(np.maximum(sumexp_p[valid], tiny))).astype(np.float32)

        # blended KL softmin and final agreement
        if have_q and have_p:
            alpha_eff = float(alpha)
            tau_blend = alpha_eff * tau_q + (1.0 - alpha_eff) * tau_p
            KL_blend  = (alpha_eff * softmin_q + (1.0 - alpha_eff) * softmin_p).astype(np.float32)
        elif have_q:
            tau_blend = float(tau_q)
            KL_blend  = softmin_q.astype(np.float32)
        elif have_p:
            tau_blend = float(tau_p)
            KL_blend  = softmin_p.astype(np.float32)
        else:
            tau_blend = 1.0  # dummy to avoid div0
            KL_blend  = np.zeros((H, W), np.float32)

        A_final = np.zeros_like(KL_blend, np.float32)
        if np.any(valid & present_i):
            A_final[valid] = np.exp(-KL_blend[valid] / max(tau_blend, tiny)).astype(np.float32)
        # clamp to [0,1] for numerical safety
        A_final = np.clip(A_final, 0.0, 1.0)

        # mask outside child support
        KL_blend  = np.where(present_i, KL_blend,  0.0).astype(np.float32)
        A_final   = np.where(present_i, A_final,   0.0).astype(np.float32)
        softmin_q = np.where(present_i, softmin_q, 0.0).astype(np.float32)
        softmin_p = np.where(present_i, softmin_p, 0.0).astype(np.float32)
        if not have_q:
            min_kl_q[:] = np.inf
        else:
            min_kl_q  = np.where(valid & present_i, min_kl_q, np.inf).astype(np.float32)
        if not have_p:
            min_kl_p[:] = np.inf
        else:
            min_kl_p  = np.where(valid & present_i, min_kl_p, np.inf).astype(np.float32)
        if use_cover_weight:
            cover_weight = np.where(present_i, cover_weight, 0.0).astype(np.float32)

        # write caches on the child
        ch.spawn_nb_count      = nb_count
        ch.spawn_min_kl_q      = min_kl_q
        ch.spawn_min_kl_p      = min_kl_p
        ch.spawn_softmin_kl_q  = softmin_q
        ch.spawn_softmin_kl_p  = softmin_p
        ch.spawn_cover_weight  = cover_weight if use_cover_weight else None
        ch.spawn_A_final       = A_final
        # convenience aliases used by plots / downstream
        ch.kl_field            = KL_blend
        ch.agreement_field     = A_final

        if debug and np.any(valid & present_i) and not np.all(np.isfinite(KL_blend[present_i])):
            print(f"[spawn-cache] non-finite blended KL for child {int(getattr(ch,'id',-1))}")



def ensure_spawn_alignment_caches(
    children,
    agents,
    runtime_ctx,
    *,
    generators_q=None,
    generators_p=None,
    use_cover_weight=True,
    debug=False,
):
    import numpy as np
    import config as _cfg

    if not children:
        return

    # Pre-warm exp(φ)/exp(φ̃) in the central cache; Ω will be built on demand.
    try:
        from transport_cache import warm_E
        whiches = set()
        sample = next((c for c in children if c is not None), None)
        if sample is not None:
            kq = int(getattr(getattr(sample, "mu_q_field", None), "shape", (0, 0, 0))[-1]) if getattr(sample, "mu_q_field", None) is not None else 0
            kp = int(getattr(getattr(sample, "mu_p_field", None), "shape", (0, 0, 0))[-1]) if getattr(sample, "mu_p_field", None) is not None else 0
            if kq: whiches.add("q")
            if kp: whiches.add("p")
        if whiches:
            warm_E(runtime_ctx, children, whiches=tuple(sorted(whiches)))
    except Exception:
        pass

    # Which children actually need a refresh?
    need = [ch for ch in children if ch is not None and should_refresh_spawn_cache(ch, runtime_ctx)]
    if not need:
        return

    # Build/refresh caches for the subset
    refresh_spawn_alignment_caches(
        runtime_ctx,
        need,
        agents,
        G_q=generators_q,
        G_p=generators_p,
        tau_q=float(getattr(_cfg, "tau_align_q", 0.45)),
        tau_p=float(getattr(_cfg, "tau_align_p", 0.45)),
        alpha=float(getattr(_cfg, "blend_qp_alpha", 0.50)),
        sm_tau=float(getattr(_cfg, "spawn_softmin_tau", 0.40)),
        mask_tau=float(getattr(_cfg, "support_tau", getattr(_cfg, "support_cutoff_eps", 1e-3))),
        use_cover_weight=bool(use_cover_weight),
        debug=bool(debug),
    )

    # Record cache build metadata once
    step_tag = int(getattr(runtime_ctx, "global_step", 0))
    cachever = int(getattr(runtime_ctx, "cache_version", 0))
    for ch in need:
        ch._spawn_cache_built_at_step = step_tag
        ch._spawn_cache_built_at_cachever = cachever
        ch._mask_prev_for_spawn = np.asarray(ch.mask, dtype=np.float32).copy()
        setattr(ch, "_dirty_fields", False)
        setattr(ch, "_dirty_kl", False)








def ensure_dirty(ctx, generators_q, generators_p, params, scope="all"):
    """
    Refresh transforms for dirty items; clear flags; bump cache if anything was done.
    Now also: rebuild bundle morphisms + pre-warm exp grids in the central cache.
    """
    # local imports only for the helpers we need
    from transport_cache import warm_E
    from preprocess_utils import ensure_transforms
    from bundle_morphism_utils import recompute_agent_morphisms
    import config as CFG

    # ------------- collect dirty targets -------------
    targets = []
    if scope in ("all", "children"):
        targets += take_dirty(ctx, getattr(ctx, "children_latest", []), which="agents")
    if scope in ("all", "parents"):
        targets += take_dirty(ctx, list_parents(ctx), which="agents")
    targets = [t for t in targets if t is not None]
    if not targets:
        return targets

    debug_strict = bool(getattr(CFG, "debug_strict", True))
    did_any = False

    # 1) Ensure φ/φ̃ transforms + shape-correct Φ/Φ̃ exist (idempotent)
    try:
        ensure_transforms(targets, generators_q, generators_p, params, ctx=ctx)
        did_any = True
    except Exception as e:
        if debug_strict:
            print(f"[ensure_dirty] ensure_transforms failed: {e}")

    # 2) Recompute gauge-transported bundle morphisms where needed
    for a in targets:
        needs_recompute = (
            getattr(a, "morphisms_dirty", False)
            or getattr(a, "bundle_morphism_q_to_p", None) is None
            or getattr(a, "bundle_morphism_p_to_q", None) is None
        )
        if not needs_recompute:
            continue
        try:
            recompute_agent_morphisms(
                a,
                generators_q=generators_q,
                generators_p=generators_p,
                ctx=ctx,
            )
            # clear dirty flag if present
            if hasattr(a, "morphisms_dirty"):
                a.morphisms_dirty = False
            did_any = True
        except Exception as e:
            if debug_strict:
                print(f"[ensure_dirty] recompute_agent_morphisms failed for agent id={getattr(a,'id',None)}: {e}")
            # fall back to whatever ensure_transforms established (typically identity-shaped)

    # 3) Pre-warm exp(φ), exp(φ̃) caches if we touched anything (idempotent per step)
    if did_any:
        try:
            warm_E(ctx, targets, whiches=("q", "p"))
        except Exception as e:
            if debug_strict:
                print(f"[ensure_dirty] warm_E failed: {e}")

    # 4) Bump cache version so downstream users know something changed
    if did_any:
        try:
            bump_cache(ctx, 1)
        except Exception:
            pass

    return targets




def refresh_kl_for_dirty_children(ctx, universe, eps, Gq=None, Gp=None):
    dirty_kids = list_nonnull(take_dirty(ctx, getattr(ctx, "children_latest", []), which="kl"))
    if not dirty_kids:
        return
    _refresh_child_kl_fields_subset(
        dirty_kids, list_nonnull(universe), eps=eps,
        build_spawn=True, ctx=ctx, Gq=Gq, Gp=Gp
    )

def refresh_kl_for_dirty_parents(ctx, universe, eps, Gq=None, Gp=None):
    try:
        parents = list_parents(ctx)
    except Exception:
        parents = []
    if not parents:
        return
    dirty_par = list_nonnull(take_dirty(ctx, parents, which="kl"))
    if not dirty_par:
        return
    _refresh_child_kl_fields_subset(
        dirty_par, list_nonnull(universe), eps=eps,
        build_spawn=True, ctx=ctx, Gq=Gq, Gp=Gp
    )






def _ensure_dirty_sets(ctx):
    # normalize the dirty container once
    d = getattr(ctx, "dirty", None)
    if d is None:
        class _D: pass
        d = _D()
        d.agents = set()
        d.kl = set()
        setattr(ctx, "dirty", d)
    else:
        if not hasattr(d, "agents"): d.agents = set()
        if not hasattr(d, "kl"):     d.kl = set()
    return d

def mark_dirty(ctx, *agents, kl=False):
    """Mark agents as needing refresh; optionally mark their KL dirty too."""
    d = _ensure_dirty_sets(ctx)
    for a in agents:
        if a is None: 
            continue
        aid = int(getattr(a, "id", id(a)))
        d.agents.add(aid)
        if kl:
            d.kl.add(aid)
        # local flags for fast checks
        setattr(a, "_dirty_fields", True)
        if kl:
            setattr(a, "_dirty_kl", True)

def take_dirty(ctx, all_agents, *, which="agents"):
    """
    Pop and return objects whose ids are marked dirty.
    which ∈ {"agents","kl"}.
    """
    d = _ensure_dirty_sets(ctx)
    ids = d.agents if which == "agents" else d.kl
    subset = _collect_by_ids(all_agents, ids)  # keep your helper
    ids.clear()
    return subset


      


# --- refresh passes -----------------------------------------------------------

def refresh_agents_light(agents, params, Gq, Gp, *, ctx=None):
    """
    Light refresh: sanitize (soft), warm exp grids into ctx.cache, build Λ caches,
    and standardize mask shapes.
    """
    if not agents: 
        return
    pre = dict(params)
    pre["sanitize_strict"] = pre.get("sanitize_strict_pre", False)
    pre["exp_n_jobs"] = 1

    preprocess_all_agents(agents, pre, Gq, Gp, ctx=ctx)
    build_all_lambda_caches(agents, ctx=ctx)

    # mask shape hygiene (once)
    import numpy as np
    H, W = np.asarray(agents[0].mask).shape[:2]
    _standardize_all_masks_once(agents, (H, W))  # keep your existing helper

def refresh_agents_strict(agents, params, Gq, Gp, *, ctx=None):
    """
    Strict refresh: sanitize (strict), rebuild Λ caches, and repair morphisms.
    """
    if not agents: 
        return
    post = dict(params)
    post["sanitize_strict"] = True
    post["exp_n_jobs"] = 1

    preprocess_all_agents(agents, post, Gq, Gp, ctx=ctx)
    build_all_lambda_caches(agents, ctx=ctx)
    _rebuild_dirty_morphisms(agents, Gq, Gp, ctx=ctx)


def _rebuild_dirty_morphisms(objs, Gq, Gp, *, ctx=None):
    """Recompute rectangular, gauge-covariant morphisms for dirty agents."""
    if not objs:
        return
    try:
        from bundle_morphism_utils import recompute_agent_morphisms as _recompute
        use_new = True
    except Exception:
        use_new = False
        try:
            from bundle_coarsegrain_init import CGH_build_morphisms as _legacy_build
        except Exception:
            _legacy_build = None

    for a in objs:
        if a is None:
            continue
        need = (
            getattr(a, "morphisms_dirty", False)
            or getattr(a, "bundle_morphism_q_to_p", None) is None
            or getattr(a, "bundle_morphism_p_to_q", None) is None
        )
        if not need:
            continue
        if use_new:
            _recompute(a, generators_q=Gq, generators_p=Gp, ctx=ctx)
        elif _legacy_build is not None:
            _legacy_build(a, Gq, Gp)
        a.morphisms_dirty = False



def _refresh_child_kl_fields_subset(
    children_subset,
    all_agents,
    eps,
    build_spawn=False,
    *,
    ctx=None,
    Gq=None,
    Gp=None,
):
    """
    Recompute per-pixel KL/agree caches for a subset of agents.

    - If Gq/Gp are provided, uses them for q/p fibers respectively.
    - If Gq/Gp are None, the spawn-cache builder will skip the missing fiber(s)
      (agreement still computed from whichever fiber is available).
    """
    if not children_subset or not build_spawn:
        return

    import config as _cfg

    refresh_spawn_alignment_caches(
        ctx,
        children_subset,
        all_agents,
        G_q=Gq,
        G_p=Gp,
        tau_q=float(getattr(_cfg, "tau_align_q", 0.45)),
        tau_p=float(getattr(_cfg, "tau_align_p", 0.45)),
        alpha=float(getattr(_cfg, "blend_qp_alpha", 0.50)),
        sm_tau=float(getattr(_cfg, "spawn_softmin_tau", 0.40)),
        mask_tau=float(getattr(_cfg, "support_tau", getattr(_cfg, "support_cutoff_eps", 1e-3))),
        use_cover_weight=True,
        debug=False,
    )




def should_refresh_spawn_cache(child, runtime_ctx, *, mask_tol=None) -> bool:
    """
    Decide whether to rebuild a child's spawn/agree caches.

    Heuristics:
      - no cache built yet
      - fields or KL marked dirty
      - mask changed beyond `mask_tol`
      - runtime_ctx.cache_version advanced since last build
    """
    import numpy as np
    try:
        import config as _cfg
    except Exception:
        _cfg = None

    # Early outs
    if getattr(child, "spawn_A_final", None) is None:
        return True
    if getattr(child, "_dirty_fields", False) or getattr(child, "_dirty_kl", False):
        return True

    # Resolve tolerance (no knobs)
    if mask_tol is None:
        # Prefer explicit per-parent setting; fall back to a generic small tol
        mask_tol = 5e-3
        if _cfg is not None:
            try:
                mask_tol = float(getattr(_cfg, "parent_mask_change_tol",
                                  getattr(_cfg, "spawn_mask_change_tol", 5e-3)))
            except Exception:
                mask_tol = 5e-3
    else:
        mask_tol = float(mask_tol)

    # Compare against previous mask snapshot used for spawn cache
    prev = getattr(child, "_mask_prev_for_spawn", None)
    if prev is None:
        return True

    now = np.asarray(child.mask, dtype=np.float32)
    if now.shape != np.asarray(prev).shape:
        return True

    if float(np.max(np.abs(now - np.asarray(prev, dtype=np.float32)))) > mask_tol:
        return True

    # Cache version bump invalidates spawn caches
    built_ver = int(getattr(child, "_spawn_cache_built_at_cachever", -1))
    cur_ver   = int(getattr(runtime_ctx, "cache_version", 0))
    return built_ver != cur_ver




def _standardize_all_masks_once(all_agents, HW):
    from parent_utils import ensure_hw
    for a in all_agents:
        if hasattr(a, "mask"):
            m = getattr(a, "mask", None)
            if m is not None:
                mm = ensure_hw(m, HW)  
                if mm is not m:
                    setattr(a, "mask", mm)







# robust parent collection (reuse the helper if you defined it elsewhere)
def _collect_parents_from_ctx(ctx):
    parents = []

    def _extend(obj):
        if obj is None:
            return
        if isinstance(obj, (list, tuple)):
            parents.extend(obj)
        else:
            parents.append(obj)

    if hasattr(ctx, "parents_by_region"):
        pbr = getattr(ctx, "parents_by_region")
        if isinstance(pbr, dict):
            for v in pbr.values():
                _extend(v)
        else:
            _extend(pbr)
    elif hasattr(ctx, "parents"):
        _extend(getattr(ctx, "parents"))
    elif hasattr(ctx, "parent"):
        _extend(getattr(ctx, "parent"))

    # dedupe, preserve order
    seen = set()
    flat = []
    for p in parents:
        if p is None:
            continue
        try:
            pid = int(getattr(p, "id"))
        except Exception:
            pid = id(p)
        if pid not in seen:
            seen.add(pid)
            flat.append(p)
    return flat



def list_parents(ctx):
    """Return current parents as a flat list from ctx.parents_by_region."""
    d = getattr(ctx, "parents_by_region", {}) or {}
    return [p for p in d.values() if p is not None]

def list_nonnull(xs):
    return [x for x in (xs or []) if x is not None]

def bump_cache(ctx, n: int = 1) -> None:
    """Monotonic counter to invalidate spawn/derived caches that track it."""
    setattr(ctx, "cache_version", int(getattr(ctx, "cache_version", 0)) + int(n))






