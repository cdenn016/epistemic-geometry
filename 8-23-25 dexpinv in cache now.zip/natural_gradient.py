# -*- coding: utf-8 -*-
"""
Natural-gradient utilities (Gaussian fields) and Lie-geometry helpers.

- No per-agent caches. Central caches (CacheHub) are used only via omega helpers.
- Strict SPD everywhere (full Σ, no diagonal shortcuts).
- Irrep-agnostic: supply generators for the target fiber K.

Author: c&c
"""
from __future__ import annotations

import numpy as np
import config

from numerical_utils import sanitize_sigma
from get_generators import get_generators

# omega helpers (all cache-hub–compatible)
from omega import (
    safe_bch_exact,          # robust exact BCH/logm wrapper
    get_E_grid_from_phi,     # exp(φ) on a grid; can be cache-tagged by step
    d_exp_phi_exact,         # exact derivative ∂ exp(φ)/∂ φ^a
)


# -----------------------------------------------------------------------------
# Natural gradient in Gaussian family (μ, Σ)
# -----------------------------------------------------------------------------

def apply_natural_gradient_batch(
    mu_field,
    sigma_field,
    grad_mu_field,
    grad_sigma_field,
    mask=None,
):
    """
    Vectorized natural gradient for Gaussian fields:
        δμ = -Σ ∇_μ L
        δΣ = -2 Σ sym(∇_Σ L) Σ

    Args
    ----
    mu_field         : (H,W,K)
    sigma_field      : (H,W,K,K) SPD (full)
    grad_mu_field    : (H,W,K)
    grad_sigma_field : (H,W,K,K)
    mask             : (H,W) bool or float weights (optional)

    Returns
    -------
    delta_mu   : (H,W,K)
    delta_sigma: (H,W,K,K)
    """
    H, W, K = mu_field.shape
    N = H * W
    eps = float(getattr(config, "eps", 1e-8))
    clip_sigma = getattr(config, "gradient_clip_sigma", None)
    clip_mu    = getattr(config, "gradient_clip_mu",    None)

    mu   = np.asarray(mu_field,       np.float32).reshape(N, K)
    Sig  = np.asarray(sigma_field,    np.float32).reshape(N, K, K)
    gmu  = np.asarray(grad_mu_field,  np.float32).reshape(N, K)
    gSig = np.asarray(grad_sigma_field, np.float32).reshape(N, K, K)

    # Strict SPD sanitize once
    Sig = sanitize_sigma(Sig, strict=True)

    # Symmetrize ∇_Σ
    gSig = 0.5 * (gSig + np.swapaxes(gSig, -1, -2))

    # Natural steps
    dmu = -np.einsum("nik,nk->ni", Sig, gmu, optimize=True)
    tmp = np.einsum("nij,njk->nik", Sig, gSig, optimize=True)
    dS  = -2.0 * np.einsum("nij,njk->nik", tmp, Sig, optimize=True)
    dS  = 0.5 * (dS + np.swapaxes(dS, -1, -2))  # symmetry guard

    # Mask / weights
    if mask is None:
        active = np.ones(N, dtype=bool)
        wts = None
    else:
        m = np.asarray(mask).reshape(N)
        if m.dtype == bool:
            active = m
            wts = None
        else:
            active = m > float(getattr(config, "support_cutoff_eps", 0.0))
            wts = m.astype(np.float32, copy=False)

    # Global norm clipping (optional)
    if clip_sigma is not None:
        ns = np.linalg.norm(dS.reshape(N, -1), axis=1)
        cm = (ns > clip_sigma) & active
        scale = np.ones(N, dtype=np.float32)
        scale[cm] = clip_sigma / np.maximum(ns[cm], eps)
        dS *= scale[:, None, None]

    if clip_mu is not None:
        nm = np.linalg.norm(dmu, axis=1)
        cm = (nm > clip_mu) & active
        scale = np.ones(N, dtype=np.float32)
        scale[cm] = clip_mu / np.maximum(nm[cm], eps)
        dmu *= scale[:, None]

    if wts is not None:
        dmu *= wts[:, None]
        dS  *= wts[:, None, None]

    # Zero outside support
    if not active.all():
        ia = ~active
        dmu[ia] = 0.0
        dS[ia]  = 0.0

    dmu = np.nan_to_num(dmu, nan=0.0, posinf=0.0, neginf=0.0).reshape(H, W, K)
    dS  = np.nan_to_num(dS,  nan=0.0, posinf=0.0, neginf=0.0).reshape(H, W, K, K)
    return dmu, dS




# -----------------------------------------------------------------------------
# Fisher metric (per-point) for φ / φ̃ fibers; inverse on support
# -----------------------------------------------------------------------------

def compute_inverse_fisher_field_natural(agent, generators, field="phi", eps=1e-8):
    """
    Compute the per-point inverse Fisher metric for a Lie-algebra field on an agent:

        G_ab(x) = Tr[ Σ(x)^{-1} G^a Σ(x)^{-1} G^b ]   (a,b = 1..d)

    Returns an array (H,W,d,d) with zeros outside support.

    Parameters
    ----------
    agent      : agent with fields and mask
    generators : (d,K,K) Lie algebra basis for the chosen fiber
    field      : "phi" (belief fiber) or "phi_model" (model fiber)
    eps        : small reg. for inverses
    """
    # pick Σ for the chosen fiber
    if field == "phi":
        Sigma = np.asarray(agent.sigma_q_field, np.float32)
    elif field == "phi_model":
        Sigma = np.asarray(agent.sigma_p_field, np.float32)
    else:
        raise ValueError("field must be 'phi' or 'phi_model'")

    mask = (np.asarray(agent.mask) > float(getattr(config, "support_cutoff_eps", 1e-4)))
    Sigma = sanitize_sigma(Sigma, strict=True)
    H, W, K, _ = Sigma.shape
    d = int(generators.shape[0])

    out = np.zeros((H, W, d, d), dtype=np.float32)
    if not np.any(mask):
        return out

    # inverse Σ per-point (vectorized)
    from numerical_utils import safe_batch_inverse
    Sinv = safe_batch_inverse(Sigma)  # (H,W,K,K)

    # T_a = Σ^{-1} G^a Σ^{-1}
    T = np.einsum("...ij,ajk->...aik", Sinv, generators, optimize=True)
    T = np.einsum("...aik,...kl->...ail", T,    Sinv,       optimize=True)

    # G_ab = Tr(T_a G^b)
    G_ab = np.einsum("...aij,bji->...ab", T, generators, optimize=True)
    G_ab = 0.5 * (G_ab + np.swapaxes(G_ab, -1, -2))

    # Invert small d×d block per masked point
    eye_d = np.eye(d, dtype=np.float32)
    flat_G   = G_ab.reshape(-1, d, d)
    flat_out = out.reshape(-1, d, d)
    idx = np.flatnonzero(mask.reshape(-1))

    for m in idx:
        M = flat_G[m]
        try:
            flat_out[m] = np.linalg.inv(M + eps * eye_d)
        except np.linalg.LinAlgError:
            flat_out[m] = eye_d  # safe fallback
    return out


def cache_fisher_inverse_morphisms(agent, eps=1e-8):
    """
    Convenience: compute and stash inverse Fisher for φ and φ̃ on the agent.
    Stores:
        agent.fisher_inv_phi_model  (for φ̃ / model fiber)
        agent.fisher_inv_phi        (for φ / belief fiber)
    """
    # belief fiber (φ): uses Σ_q and generators_q
    Gq = getattr(agent, "generators_q", None)
    if Gq is None:
        Gq, _ = get_generators(config.group_name, int(agent.sigma_q_field.shape[-1]), return_meta=True)
    agent.fisher_inv_phi = compute_inverse_fisher_field_natural(agent, Gq, field="phi", eps=eps)

    # model fiber (φ̃): uses Σ_p and generators_p
    Gp = getattr(agent, "generators_p", None)
    if Gp is None:
        Gp, _ = get_generators(config.group_name, int(agent.sigma_p_field.shape[-1]), return_meta=True)
    agent.fisher_inv_phi_model = compute_inverse_fisher_field_natural(agent, Gp, field="phi_model", eps=eps)


# -----------------------------------------------------------------------------
# Lie tools: dexp^{-1} (hybrid), Fisher-geometry gradient (exact)
# -----------------------------------------------------------------------------


def _gram_matrix(generators):
    d = generators.shape[0]
    G = generators.reshape(d, -1)
    return G @ G.T  # M_ab = Tr(G_a^T G_b)

def _project_matrix_to_coeffs(Mfield, generators, gram=None):
    """
    Project matrix field (...,K,K) onto generator basis to get coeffs (...,d).
    Uses Gram solve for arbitrary irreps / non-orthonormal bases.
    """
    d = generators.shape[0]
    if gram is None:
        gram = _gram_matrix(generators)
    rhs = np.stack([np.einsum("...ij,ij->...", Mfield, G) for G in generators], axis=-1)  # (...,d)
    # Solve gram @ x = rhs
    return np.linalg.solve(gram, rhs[..., None])[..., 0]




# Optional: small LUT to avoid sin/cos at scale
_TH_GRID = np.linspace(0.0, np.pi, 2048, dtype=np.float32)
_HALF = 0.5 * _TH_GRID
_ALPHA_GRID = np.empty_like(_TH_GRID)
# α(0)=1/12; general α(θ) = (1/θ^2)(1 - (θ/2)cot(θ/2))
_ALPHA_GRID[0] = 1.0/12.0
_ALPHA_GRID[1:] = (1.0/(_TH_GRID[1:]**2)) * (1.0 - _HALF[1:] * (np.cos(_HALF[1:]) / np.sin(_HALF[1:])))

def _alpha_theta(theta, theta2):
    # Cheap piecewise: tiny -> Taylor; moderate/large -> LUT
    small = (theta < 1e-3)
    alpha_small = 1.0/12.0 + theta2/720.0
    # LUT (no sin/cos per pixel)
    # Clip theta to [0, pi]
    t = np.clip(theta, 0.0, np.pi)
    idx = np.minimum((t * (len(_TH_GRID)-1) / np.pi).astype(np.int32), len(_TH_GRID)-1)
    alpha_full = _ALPHA_GRID[idx]
    return np.where(small, alpha_small, alpha_full)



def DEPRECATEDdexpinv_operator(phi, delta, generators=None, *, eps=1e-8,
                     tiny_thr=1e-12, small_thr=1e-1):
    """
    Fast & stable SO(3) left-Jacobian inverse in coefficient space.
    phi, delta: (...,3) -> (...,3)
    - tiny angles: return delta (no-op)
    - small angles: series  I - 1/2 ad + 1/12 ad^2
    - else: exact closed form with safe trigs
    """
    phi   = np.asarray(phi,   np.float32)
    delta = np.asarray(delta, np.float32)
    assert phi.shape[-1] == 3 and delta.shape[-1] == 3, "expected (...,3)"

    px, py, pz = phi[..., 0], phi[..., 1], phi[..., 2]
    dx, dy, dz = delta[..., 0], delta[..., 1], delta[..., 2]

    theta2 = px*px + py*py + pz*pz                  # (...,)
    tiny   = theta2 <= tiny_thr

    # Cross φ×δ (computed once for all; cheap)
    cx = py*dz - pz*dy
    cy = pz*dx - px*dz
    cz = px*dy - py*dx

    # Triple product term: φ×(φ×δ) = φ(φ·δ) - ||φ||^2 δ
    dot_pd = px*dx + py*dy + pz*dz                  # (...,)
    tx = px*dot_pd - theta2*dx
    ty = py*dot_pd - theta2*dy
    tz = pz*dot_pd - theta2*dz

    # Small-angle region (series): α ≈ 1/12 + θ^2/720
    small = (~tiny) & (theta2 <= (small_thr**2))
    alpha_series = (1.0/12.0) + (theta2/720.0)      # (...,)

    # Large-angle region (exact, clamped safely away from {0,π})
    large = (~tiny) & (~small)
    theta = np.sqrt(theta2 + eps)
    th    = np.clip(theta, 1e-6, np.pi - 1e-6)
    half  = 0.5 * th
    cot_half = np.cos(half) / (np.sin(half) + eps)
    alpha_exact = (1.0/(th*th)) * (1.0 - half * cot_half)

    # Assemble α per-pixel
    alpha = np.zeros_like(theta2, dtype=np.float32)
    alpha[small] = alpha_series[small]
    alpha[large] = alpha_exact[large]

    # δ - 1/2(φ×δ) + α * [φ×(φ×δ)]
    outx = dx - 0.5*cx + alpha * tx
    outy = dy - 0.5*cy + alpha * ty
    outz = dz - 0.5*cz + alpha * tz
    out  = np.stack((outx, outy, outz), axis=-1).astype(np.float32)

    # Tiny: identity
    if np.any(tiny):
        out[tiny] = delta[tiny]

    # Final guard (paranoid): remove any residual NaN/Inf if upstream passed weird inputs
    # out = np.nan_to_num(out, copy=False, nan=0.0, posinf=0.0, neginf=0.0)

    return out







def WORKSdexpinv_operator(phi, delta, generators, order=3, threshold=0.25):
    """
    Vectorized dexp^{-1}_φ(δ) with corrected math:
      • Small-φ: I - 1/2 ad + 1/12 ad^2 - 1/720 ad^4 (no cubic term).
      • Large-φ: small-t directional derivative: (log(exp(A)exp(tX)) - A)/t.
      • Projection via Gram solve (no per-axis divide).
    """
    phi       = np.asarray(phi,   np.float32)
    delta     = np.asarray(delta, np.float32)
    generators = np.asarray(generators, np.float32)
    *_, d = phi.shape
    assert d == 3, "SO(3) coefficient dim must be 3"

    # Build matrix fields
    A = np.einsum("...a,akl->...kl", phi,   generators)  # (...,K,K)
    X = np.einsum("...a,akl->...kl", delta, generators)  # (...,K,K)

    # Branch on ||phi|| (not on ||[phi,delta]||)
    theta = np.linalg.norm(phi, axis=-1)                 # (...)
    small_mask = (theta <= threshold)
    large_mask = ~small_mask

    out_mat = np.zeros_like(A, dtype=np.float32)

    # ---- Small-φ: Bernoulli series (no cubic), optional ad^4
    if np.any(small_mask):
        As = A[small_mask]; Xs = X[small_mask]
        ad1 = As @ Xs - Xs @ As
        Y   = Xs - 0.5 * ad1
        if order >= 2:
            ad2 = As @ ad1 - ad1 @ As
            Y  += (1.0/12.0) * ad2
        if order >= 4:
            ad3 = As @ ad2 - ad2 @ As
            ad4 = As @ ad3 - ad3 @ As
            Y  += (-1.0/720.0) * ad4
        out_mat[small_mask] = Y

    # ---- Large-φ: small-t directional derivative (BCH/logm path with t≪1)
    if np.any(large_mask):
        Al = A[large_mask]; Xl = X[large_mask]
        try:
            from gaussian_core import safe_bch_exact  # your robust log(exp A exp B)
            t = 1e-3
            Ylist = []
            for Ai, Xi in zip(Al, Xl):
                C = safe_bch_exact(Ai, t * Xi)   # ≈ log(exp(A) exp(tX))
                Ylist.append((C - Ai) / t)
            out_mat[large_mask] = np.stack(Ylist, axis=0)
        except Exception:
            # fallback to series if BCH/logm unavailable
            ad1 = Al @ Xl - Xl @ Al
            Y   = Xl - 0.5 * ad1
            ad2 = Al @ ad1 - ad1 @ Al
            Y  += (1.0/12.0) * ad2
            out_mat[large_mask] = Y

    # Project back to coeffs with Gram (no Tr(GG) divide)
    gram = _gram_matrix(generators)
    coeffs = _project_matrix_to_coeffs(out_mat, generators, gram=gram).astype(np.float32)
    return coeffs



def OLDdexpinv_operator(phi, delta, generators, order=3, threshold=0.25):
    """
    Vectorized inverse exponential pushforward (dexp⁻¹_φ) acting on tangent δ.

    Small-φ  : commutator series up to `order`.
    Large-φ  : exact composition via robust BCH; project back to coeffs.

    Shapes
    ------
    phi, delta : (..., d)
    generators : (d, K, K)

    Returns
    -------
    corrected_delta : (..., d)
    """
    phi = np.asarray(phi,   np.float32)
    delta = np.asarray(delta, np.float32)
    generators = np.asarray(generators, np.float32)

    *grid_shape, d = phi.shape
    # metric weights for projection
    gen_norms = np.array([np.trace(G @ G) for G in generators], dtype=phi.dtype)

    # to matrix fields
    phi_mat   = np.einsum("...a,akl->...kl", phi,   generators)
    delta_mat = np.einsum("...a,akl->...kl", delta, generators)

    # Frobenius norm of [φ, δ] as scale proxy
    ad1 = phi_mat @ delta_mat - delta_mat @ phi_mat
    ad_norm = np.linalg.norm(ad1, axis=(-2, -1))

    # small φ: commutator expansion
    small_mask = ad_norm <= threshold
    out_small = None
    if np.any(small_mask):
        out_small = delta_mat.copy()
        if order >= 1:
            out_small -= 0.5 * ad1
        if order >= 2:
            ad2 = phi_mat @ ad1 - ad1 @ phi_mat
            out_small += (1.0 / 12.0) * ad2
        if order >= 3:
            ad3 = phi_mat @ ad2 - ad2 @ phi_mat
            out_small -= (1.0 / 24.0) * ad3

    # large φ: exact via stable BCH/logm
    out_large = None
    large_mask = ~small_mask
    if np.any(large_mask):
        phi_large   = phi_mat[large_mask]
        delta_large = delta_mat[large_mask]
        composed = []
        for A, B in zip(phi_large, delta_large):
            C = safe_bch_exact(A, B)      # ≈ log(exp(A) exp(B))
            composed.append(C - A)         # dexp^{-1}_A(B) ≈ log(exp(A) exp(B)) - A
        out_large = np.stack(composed, axis=0)

    # combine
    out_mat = np.zeros_like(phi_mat)
    if out_small is not None:
        out_mat[small_mask] = out_small[small_mask]
    if out_large is not None:
        out_mat[large_mask] = out_large

    # back to coefficients: δ^a = Tr(M·G_a) / Tr(G_a G_a)
    corrected = np.empty_like(phi)
    for a in range(d):
        G = generators[a]
        corrected[..., a] = np.einsum("...ij,ij->...", out_mat, G) / gen_norms[a]
    return corrected


def compute_fisher_geometry_gradient(agent_i, agents, params, field="phi", *, step_tag=None, ctx=None):
    """
    ∇_{φ_i}  Σ_j  || G_i  − Ω_ij G_j Ω_ijᵀ ||_F^2,   with  Ω_ij = exp(Φ_i) exp(-Φ_j),
    using exact ∂ exp(Φ_i)/∂ φ_i^a.

    - G_x = Σ_x^{-1}, fiber-aware (q or p).
    - If `ctx` is provided, rely on omega's internal caching via the `step_tag`.
    """
    # choose fiber
    if field == "phi":
        phi_i      = np.asarray(agent_i.phi,            np.float32)
        Sigma_i    = np.asarray(agent_i.sigma_q_field,  np.float32)
        gen        = getattr(agent_i, "generators_q", None)
        fisher_w   = float(params.get("fisher_geometry_weight", getattr(config, "fisher_geometry_weight", 0.0)))
        sigma_name = "sigma_q_field"
        phi_name   = "phi"
    elif field == "phi_model":
        phi_i      = np.asarray(agent_i.phi_model,      np.float32)
        Sigma_i    = np.asarray(agent_i.sigma_p_field,  np.float32)
        gen        = getattr(agent_i, "generators_p", None)
        fisher_w   = float(params.get("fisher_model_geometry_weight", getattr(config, "fisher_model_geometry_weight", 0.0)))
        sigma_name = "sigma_p_field"
        phi_name   = "phi_model"
    else:
        raise ValueError("field must be 'phi' or 'phi_model'")

    if fisher_w <= 0.0:
        return np.zeros_like(phi_i, dtype=np.float32)

    if gen is None:
        gen, _ = get_generators(config.group_name, Sigma_i.shape[-1], return_meta=True)

    mask_i = (np.asarray(agent_i.mask) > float(getattr(config, "support_cutoff_eps", 1e-4)))
    if not np.any(mask_i):
        return np.zeros_like(phi_i, dtype=np.float32)

    H, W, d = phi_i.shape
    K = Sigma_i.shape[-1]

    # exp(φ_i) with cache tag (omega handles its own hub)
    E_i = get_E_grid_from_phi(phi_i, gen, group_name=config.group_name, sign=+1, cache_tag=step_tag)  # (H,W,K,K)

    # exact derivative list [a] : (H,W,K,K)
    dE_list = d_exp_phi_exact(phi_i, gen, exp_phi_all=E_i)

    # Σ_i^{-1}
    from numerical_utils import safe_batch_inverse
    Sigma_i = sanitize_sigma(Sigma_i, strict=True)
    Sigma_i_inv = safe_batch_inverse(Sigma_i)
    G_i = Sigma_i_inv

    grad = np.zeros_like(phi_i, dtype=np.float32)
    Ei_flat   = E_i.reshape(-1, K, K)
    G_i_flat  = G_i.reshape(-1, K, K)

    # neighbors only (expect agent_i.neighbors supplied)
    nb_list = getattr(agent_i, "neighbors", []) or []
    for nb in nb_list:
        j = nb["id"]
        agent_j = agents[j]
        mask_j = (np.asarray(agent_j.mask) > float(getattr(config, "support_cutoff_eps", 1e-4)))
        overlap = (mask_i & mask_j)
        if not np.any(overlap):
            continue

        idx = np.flatnonzero(overlap.reshape(-1))
        if idx.size == 0:
            continue

        # E_{-j}
        phi_j = np.asarray(getattr(agent_j, phi_name), np.float32)
        E_mj  = get_E_grid_from_phi(phi_j, gen, group_name=config.group_name, sign=-1, cache_tag=step_tag).reshape(-1, K, K)[idx]

        # Ω_ij = E_i E_{-j}
        Ei_idx = Ei_flat[idx]
        Omega  = np.einsum("mik,mkj->mij", Ei_idx, E_mj, optimize=True)
        Omega_T= np.transpose(Omega, (0,2,1))

        # G_j = Σ_j^{-1}
        Sigma_j = sanitize_sigma(np.asarray(getattr(agent_j, sigma_name), np.float32), strict=True)
        G_j     = safe_batch_inverse(Sigma_j.reshape(-1, K, K))[idx]

        # Δ = G_i - Ω G_j Ωᵀ
        G_i_idx = G_i_flat[idx]
        Gj_rot  = np.einsum("mik,mkl,mlj->mij", Omega, G_j, Omega_T, optimize=True)
        Delta   = G_i_idx - Gj_rot  # (M,K,K)

        # dΩ/dφ_i^a = (dE_i^a) E_{-j}
        for a in range(d):
            dEi = np.asarray(dE_list[a], np.float32).reshape(-1, K, K)[idx]
            dOm = np.einsum("mik,mkj->mij", dEi, E_mj, optimize=True)
            dOm_T = np.transpose(dOm, (0,2,1))
            dGj_rot = (np.einsum("mik,mkl,mlj->mij", dOm, G_j, Omega_T, optimize=True) +
                       np.einsum("mik,mkl,mlj->mij", Omega, G_j, dOm_T, optimize=True))

            # dL/dφ_i^a = -2 ⟨Δ, dG_rot⟩
            dL_a = -2.0 * np.einsum("mij,mij->m", Delta, dGj_rot, optimize=True).astype(np.float32, copy=False)
            grad.reshape(-1, d)[idx, a] += dL_a

    grad[~mask_i] = 0.0
    grad *= np.float32(fisher_w)
    return grad
