#!/usr/bin/env python
"""
Fixed Test for Consensus Detection
===================================

This version uses the correct imports and function signatures from your codebase.
"""

import numpy as np
import sys
import os

# Add paths if needed
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

# Import existing modules from your codebase
from config import SystemConfig, AgentConfig
from agent.agents import Agent
from agent.system import MultiAgentSystem
from geometry.geometry_base import BaseManifold, TopologyType, create_full_support
from math_utils.generators import generate_so3_generators

# Import gradient computation - using the correct path
from gradients.gradient_engine import compute_all_gradients as compute_gradients_dict
from math_utils.fisher_metric import natural_gradient_gaussian  
from retraction import retract_spd

# Import new consensus module
from meta.consensus import ConsensusDetector, analyze_consensus_dynamics


def create_test_system(n_agents: int = 5, K: int = 3, seed: int = 42):
    """Create small test system optimized for consensus formation."""
    
    rng = np.random.default_rng(seed)
    
    # Create 0D base manifold (single point)
    base_manifold = BaseManifold(
        shape=(),  # 0D - single point
        topology=TopologyType.FLAT  # Use FLAT topology for 0D
    )
    
    # Agent config - 0D particles for simplicity
    agent_cfg = AgentConfig(
        spatial_shape=(),  # 0D
        K=K,
        mu_scale=0.1,      # Small initial variation
        sigma_scale=1.0,
        phi_scale=0.1      # Small gauge variation
    )
    
    # System config - strong coupling for faster consensus
    system_cfg = SystemConfig(
        lambda_self=0.1,        # Weak self-coupling
        lambda_belief_align=10.0,  # STRONG belief alignment
        lambda_prior_align=5.0,    # Moderate prior alignment  
        lambda_obs=0.0,           # No observations (vacuum dynamics)
        lambda_phi=0.01,
        kappa_beta=0.1,          # Low temperature = sharp attention
        kappa_gamma=0.5,
        overlap_threshold=0.0,    # All agents interact
        use_connection=False      # No connection field for simplicity
    )
    
    # Create agents with proper initialization
    agents = []
    generators = generate_so3_generators()
    
    for i in range(n_agents):
        agent = Agent(
            agent_id=i,
            config=agent_cfg,
            rng=rng,
            base_manifold=base_manifold
        )
        # Set up support (full support for 0D)
        agent.support = create_full_support(base_manifold)
        
        # Store generators
        agent.generators = generators
        
        agents.append(agent)
    
    # Build system
    system = MultiAgentSystem(agents, system_cfg)
    
    return system, rng


def run_consensus_experiment(
    n_steps: int = 200,
    check_interval: int = 10, 
    lr_mu: float = 0.01,
    lr_sigma: float = 0.001,
    lr_phi: float = 0.001
):
    """
    Run simulation tracking consensus formation.
    
    Simplified version that works with your actual gradient functions.
    """
    
    # Create system
    print("Creating test system...")
    system, rng = create_test_system(n_agents=5, K=3)
    
    # Create consensus detector
    detector = ConsensusDetector(
        belief_threshold=0.01,  # Fairly strict
        model_threshold=0.01,
        use_symmetric_kl=True  # More robust
    )
    
    # Storage for history
    energy_history = []
    consensus_history = []
    cluster_history = []
    
    print(f"Running {n_steps} gradient descent steps...")
    print("="*60)
    
    for step in range(n_steps):
        # Compute energy using system method
        try:
            energy_dict = system.compute_free_energy()
            energy = energy_dict.get('total', 0.0)
        except:
            # Fallback if compute_free_energy doesn't exist
            energy = system.compute_total_energy() if hasattr(system, 'compute_total_energy') else 0.0
        
        energy_history.append(energy)
        
        # Check consensus every interval
        if step % check_interval == 0:
            # Find consensus clusters
            clusters = detector.find_consensus_clusters(system)
            consensus_matrix = detector.compute_consensus_matrix(system)
            
            # Analyze
            analysis = analyze_consensus_dynamics(
                system, detector, consensus_history
            )
            
            consensus_history.append(consensus_matrix)
            cluster_history.append(clusters)
            
            # Report
            if clusters:
                print(f"Step {step:4d}: Energy={energy:8.4f}, "
                      f"Clusters={clusters}, "
                      f"Mean KL={analysis['mean_divergence']:.4f}")
            elif step % 50 == 0:
                print(f"Step {step:4d}: Energy={energy:8.4f}, "
                      f"No consensus yet, Min KL={analysis['min_divergence']:.4f}")
        
        # Compute gradients using the actual gradient engine
        try:
            # Try the dict-returning version first
            all_gradients = compute_gradients_dict(system)
            
            # Apply updates to each agent
            for i, agent in enumerate(system.agents):
                if i not in all_gradients:
                    continue
                    
                grads = all_gradients[i]
                
                # Update belief mean (simple gradient descent)
                if hasattr(grads, 'grad_mu_q') and grads.grad_mu_q is not None:
                    # For 0D case, gradients are just (K,) vectors
                    agent.mu_q -= lr_mu * grads.grad_mu_q
                
                # Update belief covariance using natural gradient and retraction
                if hasattr(grads, 'grad_Sigma_q') and grads.grad_Sigma_q is not None:
                    # Apply natural gradient transformation
                    _, nat_grad_sigma = natural_gradient_gaussian(
                        agent.mu_q,
                        agent.Sigma_q,
                        np.zeros_like(agent.mu_q),  # No mu gradient needed here
                        grads.grad_Sigma_q
                    )
                    
                    # Update on SPD manifold using retraction
                    try:
                        agent.Sigma_q = retract_spd(
                            agent.Sigma_q,
                            -lr_sigma * nat_grad_sigma
                        )
                    except:
                        # Fallback if retract_spd has issues
                        agent.Sigma_q = agent.Sigma_q - lr_sigma * grads.grad_Sigma_q
                        # Ensure positive definite
                        eigvals, eigvecs = np.linalg.eigh(agent.Sigma_q)
                        eigvals = np.maximum(eigvals, 1e-6)
                        agent.Sigma_q = eigvecs @ np.diag(eigvals) @ eigvecs.T
                
                # Update prior mean
                if hasattr(grads, 'grad_mu_p') and grads.grad_mu_p is not None:
                    agent.mu_p -= lr_mu * grads.grad_mu_p
                    
                # Update prior covariance
                if hasattr(grads, 'grad_Sigma_p') and grads.grad_Sigma_p is not None:
                    # Natural gradient for prior
                    _, nat_grad_sigma_p = natural_gradient_gaussian(
                        agent.mu_p,
                        agent.Sigma_p,
                        np.zeros_like(agent.mu_p),
                        grads.grad_Sigma_p
                    )
                    
                    try:
                        agent.Sigma_p = retract_spd(
                            agent.Sigma_p,
                            -lr_sigma * nat_grad_sigma_p
                        )
                    except:
                        # Fallback
                        agent.Sigma_p = agent.Sigma_p - lr_sigma * grads.grad_Sigma_p
                        eigvals, eigvecs = np.linalg.eigh(agent.Sigma_p)
                        eigvals = np.maximum(eigvals, 1e-6)
                        agent.Sigma_p = eigvecs @ np.diag(eigvals) @ eigvecs.T
                
                # Update gauge field
                if hasattr(grads, 'grad_phi') and grads.grad_phi is not None:
                    agent.gauge.phi -= lr_phi * grads.grad_phi
                    # Keep in SO(3) bounds
                    agent.gauge.phi = np.clip(agent.gauge.phi, -np.pi, np.pi)
                    
        except Exception as e:
            print(f"Warning at step {step}: {e}")
            # Simple fallback: move agents toward average (consensus dynamics)
            if step > 0:
                avg_mu_q = np.mean([a.mu_q for a in system.agents], axis=0)
                for agent in system.agents:
                    agent.mu_q += 0.01 * (avg_mu_q - agent.mu_q)
    
    print("="*60)
    print(f"Final clusters: {cluster_history[-1] if cluster_history else []}")
    
    # Check for meta-agent candidates
    candidates = detector.identify_meta_agent_candidates(system)
    if candidates:
        print("\nMeta-agent candidates found:")
        for i, candidate in enumerate(candidates):
            print(f"  Candidate {i}: agents {candidate['indices']}")
            print(f"    Belief coherence: {candidate['belief_coherence']:.3f}")
            print(f"    Model coherence: {candidate['model_coherence']:.3f}")
    
    return {
        'system': system,
        'detector': detector,
        'energy_history': energy_history,
        'consensus_history': consensus_history,
        'cluster_history': cluster_history
    }


def quick_consensus_test():
    """Quick test to verify consensus detection is working."""
    print("\nQUICK CONSENSUS TEST")
    print("="*60)
    
    # Create minimal system
    system, rng = create_test_system(n_agents=3, K=2)
    
    # Force two agents to have identical parameters (consensus)
    system.agents[0].mu_q = np.array([1.0, 0.0])
    system.agents[1].mu_q = np.array([1.0, 0.0])  # Same as agent 0
    system.agents[0].Sigma_q = np.eye(2)
    system.agents[1].Sigma_q = np.eye(2)
    system.agents[0].gauge.phi = np.zeros(3)
    system.agents[1].gauge.phi = np.zeros(3)
    
    # Make agent 2 different
    system.agents[2].mu_q = np.array([0.0, 1.0])
    
    # Test consensus detection
    detector = ConsensusDetector(belief_threshold=0.01)
    
    # Check pairwise
    print("\nPairwise consensus:")
    for i in range(3):
        for j in range(i+1, 3):
            state = detector.check_full_consensus(
                system.agents[i], system.agents[j]
            )
            print(f"  Agents {i}-{j}: KL={state.belief_divergence:.4f}, "
                  f"Consensus={state.is_epistemically_dead}")
    
    # Check clusters
    clusters = detector.find_consensus_clusters(system)
    print(f"\nClusters found: {clusters}")
    print("Expected: [[0, 1]] (agents 0 and 1 in consensus)")
    
    if clusters == [[0, 1]]:
        print("✓ TEST PASSED!")
    else:
        print("✗ Test failed - check consensus detection logic")


if __name__ == "__main__":
    # Run quick test first
    quick_consensus_test()
    
    # Then run full experiment
    print("\n" + "="*60)
    print("RUNNING FULL CONSENSUS EXPERIMENT")
    print("="*60)
    results = run_consensus_experiment(n_steps=200)
    
    print("\nExperiment complete!")
    print(f"Final energy: {results['energy_history'][-1] if results['energy_history'] else 'N/A'}")
    print(f"Final clusters: {results['cluster_history'][-1] if results['cluster_history'] else []}")