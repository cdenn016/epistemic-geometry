# -*- coding: utf-8 -*-
"""
Created on Sun Jul 20 11:03:58 2025

@author: chris and christine
"""

# -*- coding: utf-8 -*-
"""
Created on Sun Jul 20 10:47:49 2025

@author: chris and christine
"""

import numpy as np
from scipy.linalg import inv
import numpy as np
import config
from joblib import Parallel, delayed

from natural_gradient_utils import (
    apply_natural_gradient_batch,
    apply_lie_natural_gradient,
    compute_inverse_fisher_field
)

from numerical_utils import sanitize_sigma
from mask_utils import clip_and_mask_gradient, clip_and_mask_morphism
from numerical_utils import safe_inv

from get_generators import get_generators
from generalized_math_utils import unpack_phi_update_params
from generalized_omega import compute_curvature_gradient_analytical, exp_lie_algebra_irrep

from generalized_omega import dexpinv_operator, dexpinv_operator_covariance
from natural_gradient_utils import compute_fisher_geometry_gradient, kl_gradient_mu_sigma
from generalized_math_utils import ( 
        zero_mu_sigma_like, apply_mask_to_mu_sigma
        )
from natural_gradient_utils import transport_gaussian
from bundle_morphism_utils import safe_batch_apply_morphism
from generalized_math_utils import ( 
        zero_mu_sigma_like, compute_mu_sigma_diff,
        apply_mask_to_mu_sigma
        )



def grad_morphism_self_energy(agent_i, alpha, mask=None):
    """
    Compute the full gradient of KL(q || Φ·p) with respect to the morphism Φ̃.
    
    Args:
        agent_i    : focal agent
        alpha      : weight for the self-alignment term
        mask       : optional (H, W) spatial mask

    Returns:
        gradient   : Gradient of KL divergence with respect to Φ̃
    """
    # Compute the gradients for each term in the KL divergence
    grad_term_1 = compute_term_1_gradient_self_energy(agent_i)
    grad_term_2 = compute_term_2_gradient_self_energy(agent_i)
    grad_term_3 = compute_term_3_gradient_self_energy(agent_i)

    # Combine the gradients
    full_gradient = grad_term_1 + grad_term_2 + grad_term_3

    # Apply the mask (if provided)
    if mask is not None:
        full_gradient *= mask[..., None, None]  # Apply the mask to the full gradient

    # Apply the alpha scaling factor
    return alpha * full_gradient


def compute_morphism_covariance_term_belief(sigma_p, Phi_tilde):
    """
    Compute the term Σ_q Φ^T + Φ Σ_q for beliefs, where Phi is the morphism for beliefs (K_q x K_p).
    
    Args:
        sigma_q    : Belief covariance matrix (H, W, K_q, K_q)
        Phi        : Bundle morphism (Q → P), shape (H, W, K_q, K_p)
    
    Returns:
        result     : The result of Σ_q Φ^T + Φ Σ_q, shape (H, W, K_q, K_p)
    """
   
    # First term: Σ_q Φ^T
    Phi_tilde_t = np.transpose(Phi_tilde, (0, 1, 3, 2))  # Shape (H, W, K_p, K_q)
   
    # Perform the matrix multiplication for Σ_q Φ^T
    term_1 = np.matmul(sigma_p, Phi_tilde_t)  # Matrix multiplication for Σ_q Φ^T
  
    # Second term: Φ Σ_q
    term_2 = np.matmul(Phi_tilde, sigma_p)    # Matrix multiplication for Φ Σ_q
    
    # Transpose term_2 to match term_1 shape
    term_2 = np.transpose(term_2, (0, 1, 3, 2))  # Shape (H, W, K_q, K_p)
  #return the sum of both terms
    result = term_1 + term_2
    #print(f"result shape: {result.shape}")
    
    return result




#lookis good
def compute_term_1_gradient_self_energy(agent_i):
    """
    Compute the derivative of the first term of the KL divergence with respect to Φ̃.
    Term 1: - Σ_{proj}^{-1} Σ_p Σ_{proj}^{-1} · Λ_q
    
    Args:
        agent_i    : focal agent
        params     : dictionary of parameters
    
    Returns:
        gradient   : Gradient of Term 1 with respect to Φ̃
    """
    # Extract the fields
    mu_q = agent_i.mu_q_field             # (H, W, K_q)
    sigma_q = agent_i.sigma_q_field       # (H, W, K_q, K_q)
    mu_p = agent_i.mu_p_field             # (H, W, K_p)
    sigma_p = agent_i.sigma_p_field       # (H, W, K_p, K_p)
    Phi_tilde = agent_i.bundle_morphism_p_to_q  # Φ̃ : P → Q
    
   
    # Compute the transformed belief covariance (Σ_p projected onto q)
    mu_p_proj, sigma_p_proj = safe_batch_apply_morphism(mu_p, sigma_p, Phi_tilde)

   
    # Inverse of the transformed covariance
    sigma_proj_inv = safe_inv(sigma_p_proj, eps=config.eps)

   
    
    # Compute Σ_p Φ̃^T + Φ̃ Σ_p using the helper function
    term_covariance = compute_morphism_covariance_term_belief(sigma_p, Phi_tilde)

   
    
    # Compute the gradient for Term 1
    grad_term_1 = - np.einsum("...ij,...jl,...kl->...ik", sigma_proj_inv, sigma_p, sigma_proj_inv)
    
  
    
    grad_term_1 = np.einsum("...ij,...jk->...ik", grad_term_1, term_covariance)
    
    # Print final gradient shape
    #print(f"grad_term_1 (after second einsum) shape: {grad_term_1.shape}")
    
    return 0.5 * grad_term_1


def compute_term_2_gradient_self_energy(agent_i):
    """
    Compute the derivative of the second term of the KL divergence with respect to Φ̃.
    Term 2: - Σ_{proj}^{-1} Σ_q Δμ Δμ^T Σ_{proj}^{-1} Λ_p
    
    Args:
        agent_i    : focal agent
    
    Returns:
        gradient   : Gradient of Term 2 with respect to Φ̃
    """
    # Extract the fields
    mu_q = agent_i.mu_q_field             # (H, W, K_q)
    sigma_q = agent_i.sigma_q_field       # (H, W, K_q, K_q)
    mu_p = agent_i.mu_p_field             # (H, W, K_p)
    sigma_p = agent_i.sigma_p_field       # (H, W, K_p, K_p)
    Phi_tilde = agent_i.bundle_morphism_p_to_q  # Φ̃ : P → Q

    # Compute the projected model mean and covariance
    mu_p_proj, sigma_p_proj = safe_batch_apply_morphism(mu_p, sigma_p, Phi_tilde)

    # Compute the mean difference term
    delta_mu = mu_q - mu_p_proj  # Δμ = μ_p - μ_q_proj

    # Compute the projected covariance (Σ_proj = Φ̃ Σ_p Φ̃^T)
    mu_proj, sigma_proj = safe_batch_apply_morphism(mu_p, sigma_p, Phi_tilde)

    # Compute the inverse of the projected covariance
    sigma_proj_inv = safe_inv(sigma_proj, eps=config.eps)

    # Compute Σ_p Φ̃^T + Φ̃ Σ_p using the helper function
    term_covariance = compute_morphism_covariance_term_belief(sigma_p, Phi_tilde)  # Σ_p Φ̃^T + Φ̃ Σ_p

    # First part: Apply Σ_proj^-1 Σ_q
    part_1 = np.einsum("...ij,...jk->...ik", sigma_proj_inv, sigma_p)  # Σ_proj^-1 Σ_q

    # Second part: Multiply by Δμ Δμ^T
    # This operation contracts over the correct dimensions
    part_2 = np.einsum("...ij,...j,...k->...ik", part_1, delta_mu, delta_mu)  # Σ_proj^-1 Σ_q Δμ Δμ^T

    # Final part: Apply Σ_proj^-1 again and multiply by Λ_p
    grad_term_2 = -np.einsum("...ij,...jk->...ik", part_2, sigma_proj_inv)  # Σ_proj^-1 Σ_q Δμ Δμ^T Σ_proj^-1

    # Multiply by Λ_p (Σ_p Φ̃^T + Φ̃ Σ_p)
    grad_term_2 = np.einsum("...ij,...jk->...ik", grad_term_2, term_covariance)  # Σ_proj^-1 Σ_q Δμ Δμ^T Σ_proj^-1 Λ_p

    return grad_term_2


def compute_term_3_gradient_self_energy(agent_i):
    """
    Compute the derivative of the third term of the KL divergence with respect to Φ̃.
    Term 3: Σ_{proj}^{-1} Λ_p
    
    Args:
        agent_i    : focal agent
        params     : dictionary of parameters
    
    Returns:
        gradient   : Gradient of Term 3 with respect to Φ̃
    """
    # Extract the fields
    mu_q = agent_i.mu_q_field             # (H, W, K_q)
    sigma_q = agent_i.sigma_q_field       # (H, W, K_q, K_q)
    mu_p = agent_i.mu_p_field             # (H, W, K_p)
    sigma_p = agent_i.sigma_p_field       # (H, W, K_p, K_p)
    Phi_tilde = agent_i.bundle_morphism_p_to_q  # Φ̃ : P → Q

    # Compute the transformed model covariance (Σ_p projected onto q)
    mu_p_proj, sigma_p_proj = safe_batch_apply_morphism(mu_p, sigma_p, Phi_tilde)

    # Compute Σ_p Φ̃^T + Φ̃ Σ_p using the helper function
    term_covariance = compute_morphism_covariance_term_belief(sigma_p, Phi_tilde)

    # Compute the gradient for Term 3: Σ_{proj}^{-1} Λ_p
    # Inverse of projected covariance: Apply np.linalg.inv to each (K_q, K_q) matrix independently for (H, W)
    # We need to invert each 2D matrix along the last two dimensions (K_q, K_q)
    sigma_proj_inv = np.linalg.inv(sigma_p_proj)  # Inverse of each (K_q, K_q) matrix independently

    # Now compute grad_term_3 using matrix multiplication: np.dot
    grad_term_3 = np.matmul(sigma_proj_inv, term_covariance)  # (H, W, K_q, K_p)

    # Check the shape of grad_term_3 before further operations
    #print(f"grad_term_3 shape: {grad_term_3.shape}")

    return grad_term_3

