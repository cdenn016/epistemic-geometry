import numpy as np
import sys

# ===========================
# DEBUGGING AND UTILITIES
# ===========================


def set_config_from_params(params):
    """Dynamically override config attributes from a dictionary."""
    this_module = sys.modules[__name__]
    for k, v in params.items():
        setattr(this_module, k, v)

epsilon_model      = 1      # Threshold to classify meta-agents (can sweep)

# config.py
phi_morphism_type       = "gauge_covariant"         # identity  gauge_covariant 
phi_model_morphism_type = "gauge_covariant"

morphism_normalize    = True
coarsegrain_each_step = True


agent_seed    = 111 

# Toggle between diagonal and full Σ initialization
diagonal_sigma = False

# ===========================
# DOMAIN / SPATIAL SETTINGS
# ===========================
K_q           = 3
K_p           = 5       # Fiber dimension of belief/model space (depends on representation)
                 
D             = 2           #dimension of base manifold - d=2 validated

L             = 50         #length of hypercubic base-manifold - PBCs

steps         = 500

N             = 10                       # Number of agents
max_neighbors = 10        # Max number of agent neighbors

n_jobs = N

agent_radius_range = (5,5)         #agent radii
fixed_location = False      
# ===========================
# COUPLINGS & PENALTIES
# ===========================

alpha                  = 0.25
beta                   = 1
belief_mass            = 1
curvature_weight       = 1

feedback_weight         = 0
beta_model              = 1
model_mass              = 1
model_curvature_weight  = 1

entropy_weight          = 1


#==========================
#    IF NEEDED/CURIOUS
#==========================
exp_n_jobs = 12

phi_coupling_weight           = 0             # set > 0 to enable
phi_coupling_mode             = "projection"  # or "conjugation"


fisher_geometry_weight        = 0      
fisher_model_geometry_weight  = 0

# ===========================
# INITIALIZATION
# ===========================

# ─── Belief Bundle (q) Parameters ───
q_mu_range                     = (-1.0, 1.0)              # Range for μ_q
q_sigma_range                  = (0.2, 1.0)           # Diagonal Σ_q entries

belief_noise_scale_mu          = 0.01         # Additive noise for μ_q
belief_noise_scale_sigma       = 0.01      # Additive noise for Σ_q


# ─── Model Bundle (p) Parameters ───
p_mu_range                     = (-1.0, 1.0)             # Range for μ_p
p_sigma_range                  = (0.2, 1.0)           # Diagonal Σ_p entries

model_noise_scale_mu           = 0.01          # Additive noise for μ_p
model_noise_scale_sigma        = 0.01       # Additive noise for Σ_p

sigma_outside_val              = 1e3  # large uncertainty outside support





# ================= PRIORITY 1 — Detection / Emergence (hard gates) ==============
detector_period           = 1            # run detector every step
detector_mask_tau         = 1e-4         # fallback when activity map is None
emerge_tau                = 12         # KL gate at detect time
parent_weight_tau         = 0.1         # auto interior gate (e.g., p60); set float to fix
emerge_min_area           = 1            # ignore tiny blips

# ================= PRIORITY 2 — Global caps (spawns) ============================
parent_max_new_per_step   = 4            # cap new parents per step

# ================= PRIORITY 3 — Growth permission / locality / floors ==========
parent_support_tau        = 0.08         # what counts as “real” support
parent_grow_min_kids      = 2            # need agreement to grow
parent_local_radius_px    = 4            # locality radius for updates
parent_far_decay          = 1.0          # 1.0 disables far-field pruning
parent_floor_eps          = 1e-8         # zero-out dust below this

# ================= PRIORITY 4 — Growth signal & gates ==========================
parent_growth_signal      = "auto"       # "auto"|"kl"|"agree"|"coverage"
parent_growth_core_tau    = 0.15
parent_newborn_core_tau   = 0.15
parent_tau_grow           = "p60"
parent_tau_shrink         = "p45"
parent_kappa              = "auto"       # slope ("auto" = IQR-based)

# ================= PRIORITY 5 — Per-step magnitudes / caps =====================
eta_grow                  = 0.12
eta_shrink                = 0.06
grow_band                 = 5
shrink_band               = 1
parent_max_step_delta     = 0.1         # per-pixel clamp used by updater

# ================= PRIORITY 6 — Emergence ramp (timing) ========================
parent_freeze_steps       = 0            # newborns sit still N steps
parent_ramp_steps         = 3            # slow ramp-up

# ================= PRIORITY 7 — Spawn/seed (direct-from-alignment) =============
spawn_direct_from_alignment = True

# alignment blend & strictness
blend_qp_alpha            = 1        # 0.0=model-only, 1.0=belief-only
tau_align_q               = 0.45         # A = exp(-KL/τ)
tau_align_p               = 0.45

# mutual-agreement core / seed shaping
direct_seed_m_core        = 2            # 3 → only triple-agreement
direct_seed_A_min         = 6
direct_seed_smooth_iters  = 1
direct_seed_pair_agree_tau= 0.25         # pairwise A-threshold (e.g., exp(-1)≈0.368 default)

# componentization of soft agreement
direct_seed_soft_thr      = 0.14
direct_seed_min_area_px   = 5
direct_seed_max_per_group = 3

# grouping (build child groups inside regions)
seed_min_kids             = 2
child_support_tau         = 0.08
child_intragroup_iou_thr  = 0.10

# proposal → local seed gate & spacing
parent_proposal_local_tau = 0.15         # threshold on normalized proposal
parent_min_seed_area_px   = 10
parent_min_interseed_px   = 3

# matching vs existing parents
parent_match_iou_existing = 0.35
parent_child_jaccard_thr  = 0.40

# newborn gaussian seed shaping
parent_seed_amp           = 0.55
parent_seed_radius_px     = 4.0
parent_seed_feather_sigma = 1.0

# ================= PRIORITY 8 — Pruning / housekeeping =========================

parent_min_area_keep      = 1
parent_area_threshold     = 0.01

# ================= PRIORITY 9 — Visibility / debug =============================
debug_detector_log        = True
debug_growth_log          = True
debug_growth_probe        = True
debug_strict              = True
debug_seed_use_proposal   = False        # True => use proposal directly as seed (debug only)
debug_force_spawn         = False        # True => bypass match/area gates (debug only)


enforce_spawn_spacing     = False

# ===== Activity mixing (child_activity_map) ====================================
activity_mix_mode         = "weighted_or"   # 'weighted_or'|'and'|'or'|'model_only'|'belief_only'
activity_model_weight     = 0.1
activity_belief_weight    = 0.9
activity_score_tau        = 0.3
activity_mu_tau_p         = 1e-3
activity_trsig_tau_p      = 1e-3

# ===== Parent signal construction (growth) =====================================
signal_reduce_mode        = "weighted_mean"  # 'weighted_mean'|'mean'|'max'
signal_consensus_gamma    = 1.0              # 0.5..2.0 typical
signal_kl_cap             = 10.0             # clip KL before exp()




# Overlap behavior
parent_allow_overlap         = True     # let distinct child-sets spawn at same pixel
parent_min_interseed_px      = 3        # ignored when parent_allow_overlap=True

# Alignment clustering
use_alignment_clusters       = True
cluster_align_thr            = 0.55     # higher = stricter “aligned”
cluster_min_kids             = 1
parent_dedup_child_jaccard   = 0.95     # drop near-duplicate clusters

# Agreement fields (already used by your direct-from-alignment path)
tau_align_q                  = 0.30
tau_align_p                  = 0.30
blend_qp_alpha               = 0.50


# group-level dedup
parent_group_dedup_radius_px     = 2
parent_group_dedup_child_jaccard = 0.92
parent_group_dedup_subset_thr    = 0.90

# spacing / match
enforce_spawn_spacing            = True
parent_min_interseed_px          = 3
spacing_child_jaccard_thr        = 0.90
spacing_child_subset_thr         = 0.90
parent_match_child_jaccard_thr   = 0.85

# fallback cleanup (keeps plots clean even if one slips through)
orphan_patience_steps            = 2
orphan_min_total_weight          = 1e-4

parent_soft_assign_tau     = 0.12
parent_soft_assign_temp    = 0.25
parent_soft_assign_topk    = 2
parent_assign_core_tau     = 0.12      # absolute floor (used as core_tau if you like)
parent_assign_core_tau_rel = 0.50      # 50% of parent.max()
parent_assign_core_dilate  = 1         # 1-px dilation helps newborns
parent_assign_bootstrap    = 3         # relax thresholds for first 2 steps

# seed must hit its own coalition
parent_min_seed_child_overlap_px      = 4      # absolute pixels
parent_min_seed_child_overlap_frac    = 0.08   # vs proposal area (local_bool)


# proposal filtering
parent_min_peak_score          = 0.0    # or small positive if needed
parent_min_soft_sum            = 0.0    # only use if peaks carry soft_sum
















#======================
#
#   LEARNING RATES
#
#======================
tau_phi                 = 1e-4
tau_phi_model           = 1e-4    
tau_mu_belief           = 1e-5       # update rate for η₁_q
tau_sigma_belief        = 1e-5       # update rate for η₂_q
tau_mu_model            = 1e-5      # update rate for η₁_p
tau_sigma_model         = 1e-5       # update rate for η₂_p



phi_init_smooth_sigma   = 1.5
phi_init                = 0.1
phi_model_offset        = 0.1


eta_ema_alpha                   = 0.6          # try 0.4–0.8
eta_phi_adaptive_scaling        = 1.0
eta_phi_model_adaptive_scaling  = 1.0
eta_sigma_condition_scaling     = 0.1   # start small
sigma_eig_floor                 = 1e-6
sigma_cond_cap                  = 1e4

sigma_eig_cap                   = None          # usually None
sigma_trace_target              = None     # or K if you want trace control




eta_phi_min           = 1e-6
eta_phi_model_min     = 1e-6



#==========================================
#
#       META-AGENTS
#
#==========================================
# Cross-scale toggles
enable_crossscale = True

# Weights (q-fiber)
beta_up_q = 0.30   # child → parent
beta_dn_q = 0.10   # parent → children (smaller at first)

# Weights (p-fiber) — off for now; turn on later
beta_up_p = 0.2
beta_dn_p = 0.2

# Cross-bundle Θ terms — not implemented yet, keep 0
gamma_theta_up = 0.00
gamma_theta_dn = 0.00

# Functorial penalties (intertwining) — not implemented yet, keep 0
lambda_functor_q = 0.00
lambda_functor_p = 0.00

# Clustering / aggregation
overlap_eps = 1e-3

# Logging & seeding
xscale_log_every = 1
xscale_seed_lambda_dn_q = True      # good instant KL drop
xscale_lambda_ridge     = 1e-3      # for the Procrustes seed

# Cross-scale (model side)
enable_crossscale_p      = True




lambda_xscale_q = 0.05




frozen_levels = [1]
frozen_phi_levels = [1]










xscale_lr_mu_p_up        = 0.01
xscale_lr_sigma_p_up     = 0.005
xscale_lr_mu_p_dn        = 0.01
xscale_lr_sigma_p_dn     = 0.005


# ===========================
# AGENT GEOMETRY
# ===========================


gaussian_blur_range_morphism = (1,2)
mu_clip = 3.0



#================================
#
#  INITIALIZE GLOBAL FIELDS 
#      WITH GENTLE NOISE
#================================
use_global_belief_template = False
use_global_model_template  = False



identical_models = False         # If True, all agents share the same p, mu_p_field, sigma_p_field




# ===========================
# STABILITY AND CLIPPING
# ===========================


                                    # Gradient clipping magnitudes (optional; set to None to disable)
phi_grad_clip             = 1e5    # Max L2 norm per-point for φ update
phi_model_grad_clip       = 1e5    # Max L2 norm per-point for φ̃ update

                                     # Optional: norm type (future-proofing, L2 is default)
gradient_clip_norm_type   = 2           # Use 2 for L2 norm; 1 for L1, np.inf for max-norm
phi_exp_clip              = np.pi  # or 2π if you're okay with aliasing


mask_sharpness        = 1.5
# ===========================
# EPSILONS & NUMERICAL STABILITY
# ===========================

log_eps            = 1e-6     # Stabilize log(x)
eps                = 1e-5
# ===========================
# MASK & INTERACTION THRESHOLDS
# ===========================

support_cutoff_eps = 1e-3    # Mask threshold to include point in agent support
overlap_eps        = 1e-3     # Threshold for computing inter-agent overlap

# ===========================
# SIMULATION THRESHOLDS
# ===========================



# ===========================
# CHECKPOINTING
# ===========================

checkpoint_dir      = "checkpoints"
precision = np.float32

checkpoint_interval = 1

domain_size = (L,) * D

# 3) replace all the old eta_* calculations with calls to scaled_eta


num_cores = 1  # or however many threads you want to use



group_name = 'so3'               # Options: "u1", "so3", "so3", 'su2'.

phi_bch_max_norm = 25.0


# Enable numerical safety logging
debug = True  # Global debug flag for extra logging inside φ updates                       

  
fail_on_fallback = False                # Allow recovery rather than crashing


#=================
#    LOGDET
#==================


# ── Numerical Safeguards ─────────────────────────────
max_fisher_condition = 1e5   # Maximum allowed condition number before fallback


# Control fallback thresholds (optional)
max_safe_inv_fallbacks = 1000
max_safe_logdet_fallbacks = 1000

# ─────────────────────────────────────────────────────────
# Logging / dump toggles (matches new logger + field dumper)
# ─────────────────────────────────────────────────────────
logging = dict(
    # master switches
    enable_scalar=True,          # run log_all_metrics (global + per-agent scalars)
    enable_fields=True,          # run full_field_logger (NPZ field dumps)

    # compute-time guards (controls what goes into NPZ)
    compute_alignment=True,      # belief/model alignment maps + KL(p→q, q→p)
    compute_curvature=True,      # curvature tensors + Fq_norm/Fp_norm
    compute_pairwise_overlap=False,  # optional: builds overlap matrix (debug)

    # summaries (affects per-agent CSV rows)
    log_support_stats=True,
    log_overlap_stats=True,
    log_gradient_stats=True,     # needs *_grad or debug counters on Agent
    log_conditioning=True,       # min/max eigs, cond numbers

    # normalization / console
    normalize_by_support=True,
    print_total_energy=True,     # console print of global energies

    # cadence + outdirs
    fields_every=20,              # dump fields every step (turn up if disk heavy)
    max_overlap_every= 10,        # only used if you keep overlap logging on
    full_field_outdir="fields",
    pair_outdir="max_overlap",

    # schema
    schema_version="v3",
)

# Keep this True if any legacy gate still checks it (safe to include)
log_full_fields = False

# Finite-difference checks (optional diagnostics cadence)
fd_check_every = 1000
fd_pairs_per_step = 1
periodic_x = True          # set per your sim
periodic_y = True