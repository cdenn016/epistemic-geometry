import numpy as np
import config
from typing import Dict, List, Optional

from parent_utils import  _label4, child_activity_map
from dataclasses import dataclass, field

from gaussian_core import kl_gaussians, gaussian_pushforward_linear
from numerical_utils import sanitize_sigma
from omega import compute_inter_omega

from numerical_utils import resize_nn


@dataclass
class Region:
    id: int
    mask: np.ndarray
    state: str
    age: int = 0
    t_activated: Optional[int] = None
    child_ids: List[int] = field(default_factory=list)

@dataclass
class DetectorState:
    regions: Dict[int, Region] = field(default_factory=dict)
    next_id: int = 0
    step: int = 0





def detect_regions_minimal(
    children, *, H, W,
    min_kids: int,
    min_area: int,
    kl_tau=None,                     # None → skip KL gate (same as before)
    weight_tau=0.6,                  # or config.parent_weight_tau
    erode_iters=None,                # or config.detector_edge_erode
    runtime_ctx=None,
    agree_gate_tau=None,             # or config.agree_gate_tau
    periodic=None,
    return_cand_map: bool = True,
):
    """
    Minimal, unified region detector:
      1) require >= min_kids active children per pixel
      2) interior gate by mean child-mask weight (adaptive if weight_tau=None)
      3) optional KL gate (avg over active kids), bounded by kl_tau
      4) optional global lvl-0 agreement gate (Aq_agg/Ap_agg >= agree_gate_tau)
      5) optional 4-neigh erosion (erode_iters)
      6) CC + area filter

    Returns: (regions_dict, cand_map) if return_cand_map else regions_dict
    """
    
    if periodic is None:
        periodic = bool(getattr(config, "periodic_domain", True))
    if erode_iters is None:
        erode_iters = int(getattr(config, "detector_edge_erode", 0))
    if weight_tau is None:
        cfg_weight_tau = getattr(config, "parent_weight_tau", None)
    else:
        cfg_weight_tau = weight_tau

    # optional agreement gate threshold
    if agree_gate_tau is None:
        agree_gate_tau = getattr(config, "agree_gate_tau", None)

    cover  = np.zeros((H, W), dtype=np.int32)    # number of active kids
    weight = np.zeros((H, W), dtype=np.float32)  # sum of child mask weights
    kid_act, kid_kls = [], []

    mask_tau_mask = float(getattr(config, "detector_mask_tau", 1e-3))
    for ch in children:
        m = np.asarray(getattr(ch, "mask", 0.0))
        if m.shape != (H, W):
            m = resize_nn(m, (H, W)).astype(np.float32)
        else:
            m = m.astype(np.float32)

        act = child_activity_map(
            ch, H, W,
            mu_tau=float(getattr(config, "activity_mu_tau", 1e-3)),
            trsig_tau=float(getattr(config, "activity_trsig_tau", 1e-3)),
            eps=float(getattr(config, "eps", 1e-6)),
        )
        a = (m > mask_tau_mask) if act is None else np.asarray(act).astype(bool)

        cover  += a.astype(np.int32)
        weight += m * a.astype(np.float32)
        kid_act.append(a)

        k = getattr(ch, "cached_alignment_kl", None)
        if k is None:
            kid_kls.append(None)
        else:
            k = np.asarray(k)
            if k.shape != (H, W):
                k = resize_nn(k, (H, W))
            kid_kls.append(k.astype(np.float32))

    # 1) require enough active kids
    keep = (cover >= int(min_kids))

    # 2) interior preference by mean weight
    mean_weight = np.zeros((H, W), dtype=np.float32)
    nz = cover > 0
    mean_weight[nz] = weight[nz] / cover[nz].astype(np.float32)

    if cfg_weight_tau is None:
        ww = mean_weight[(cover >= int(min_kids)) & (mean_weight > 0)]
        thr = float(np.percentile(ww, 60)) if ww.size else 0.0
    else:
        thr = float(cfg_weight_tau)
    keep &= (mean_weight >= thr)

    # 3) KL gate (only if any child provided a finite KL map and kl_tau not None)
    if kl_tau is not None and any(k is not None for k in kid_kls):
        kl_sum = np.zeros((H, W), dtype=np.float32)
        kl_cnt = np.zeros((H, W), dtype=np.int32)
        for a, k in zip(kid_act, kid_kls):
            if k is None:
                continue
            inside = a & np.isfinite(k)
            if inside.any():
                kl_sum[inside] += k[inside]
                kl_cnt[inside] += 1
        kl_mean = np.full((H, W), np.inf, dtype=np.float32)
        valid = kl_cnt > 0
        kl_mean[valid] = kl_sum[valid] / np.maximum(kl_cnt[valid], 1)
        keep &= (kl_mean <= float(kl_tau))

    # 4) agreement gate (global lvl-0 agreement aggregate)
    if (agree_gate_tau is not None) and (runtime_ctx is not None):
        A = getattr(runtime_ctx, "Aq_agg", None)
        if A is None:
            A = getattr(runtime_ctx, "Ap_agg", None)
        if A is not None and A.shape == (H, W):
            keep &= (A >= float(agree_gate_tau))

    pre_px = int(np.asarray(keep).sum())
    core = keep.astype(bool)

    # 5) optional 4-neigh erosion
    if erode_iters > 0 and core.any():
        if periodic:
            for _ in range(erode_iters):
                e = core.copy()
                e &= np.roll(core,  1, 0)
                e &= np.roll(core, -1, 0)
                e &= np.roll(core,  1, 1)
                e &= np.roll(core, -1, 1)
                core = e
        else:
            for _ in range(erode_iters):
                up    = np.pad(core[1: , : ], ((0,1), (0,0)))
                down  = np.pad(core[:-1, : ], ((1,0), (0,0)))
                left  = np.pad(core[: , 1: ], ((0,0), (0,1)))
                right = np.pad(core[: , :-1], ((0,0), (1,0)))
                core = core & up & down & left & right

    post_px = int(core.sum())
    min_area_eff = int(min_area)

    labels, nlab = _label4(core)
    regions = {}
    rid = 0
    for lbl in range(1, nlab + 1):
        comp = (labels == lbl)
        area = int(comp.sum())
        if area < min_area_eff:
            continue
        regions[rid] = _make_region(comp.astype(np.float32), rid)
        rid += 1

    try:
        tau_repr = f"{thr:.3f}" if cfg_weight_tau is not None else f"auto->{thr:.3f}"
        print(f"[DETECT] regs={len(regions)} px_keep={pre_px} px_post={post_px} "
              f"min_area={min_area_eff} weight_tau={tau_repr} "
              f"cover_sum={int(cover.sum())} mean_w={float(np.nan_to_num(mean_weight).mean()):.3f}")
    except Exception:
        pass

    if not return_cand_map:
        return regions

    # candidate score map = union of region masks (float)
    cand_map = np.zeros((H, W), np.float32)
    for R in regions.values():
        cand_map = np.maximum(cand_map, np.asarray(R.mask, np.float32))
    return regions, cand_map















# --- REPLACE old _detect_regions_pure with a wrapper around the minimal detector
def _detect_regions_pure(agents, params, ctx):
    H, W = np.asarray(agents[0].mask).shape[:2]
    detector_period = int(getattr(config, "detector_period", 2))
    if (ctx.global_step % detector_period) != 0:
        return {}, np.zeros((H, W), np.float32)

    # SAFE parse for optional KL threshold
    _emerge = getattr(config, "emerge_tau", 0.28)
    if (_emerge is None) or (isinstance(_emerge, str) and _emerge.strip().lower() in ("none", "off", "disabled", "")):
        kl_tau = None
    else:
        kl_tau = float(_emerge)

    regions, cand_map = detect_regions_minimal(
        agents, H=H, W=W,
        min_kids=int(getattr(config, "seed_min_kids", 2)),
        min_area=int(getattr(config, "emerge_min_area", 8)),
        kl_tau=kl_tau,
        weight_tau=getattr(config, "parent_weight_tau", 0.6),
        erode_iters=getattr(config, "detector_edge_erode", 0),
        runtime_ctx=ctx,
        agree_gate_tau=getattr(config, "agree_gate_tau", None),
        periodic=getattr(config, "periodic_domain", True),
        return_cand_map=True,
    )
    return regions, cand_map



# --- NEW: single, minimal detector -------------------------------------------

def _make_region(mask: np.ndarray, rid: int):
    """
    Construct a Region with whatever signature your project uses.
    Tries several common ctor shapes; falls back to a simple object.
    """
    area  = int((mask > 0).sum())
    state = getattr(config, "region_active_state", "active")  # or 1 / True, if your code uses enums

    # Try common constructor shapes
    attempts = [
        lambda: Region(id=rid, state=state, mask=mask, area=area),
        lambda: Region(id=rid, state=state, mask=mask),
        lambda: Region(rid, state, mask),           # positional
        lambda: Region(mask=mask),                  # legacy minimal
        lambda: Region(mask),                       # very old minimal
    ]
    for ctor in attempts:
        try:
            return ctor()
        except TypeError:
            pass

    # Fallback: lightweight object with the fields we need downstream
    class _R: pass
    R = _R()
    R.id = rid
    R.state = state
    R.mask = mask
    R.area = area
    return R





# --- DEPRECATED shim: keep signature but delegate to minimal detector ----------
def detect_overlap_aligned_regions(children, *, H, W,
                                   min_kids=2,
                                   kl_tau=0.10,
                                   min_area=20,
                                   weight_tau=0.6,
                                   activity_mu_tau=1e-3, activity_trsig_tau=1e-3,  # (kept for API, handled upstream)
                                   eps=1e-6,
                                   periodic=None,
                                   runtime_ctx=None):
    """
    Deprecated: use detect_regions_minimal. This wrapper preserves the old API.
    """
    regions = detect_regions_minimal(
        children, H=H, W=W,
        min_kids=int(min_kids),
        min_area=int(min_area),
        kl_tau=kl_tau,
        weight_tau=weight_tau,
        erode_iters=getattr(config, "detector_edge_erode", 0),
        runtime_ctx=runtime_ctx,
        agree_gate_tau=None,   # old path had no agreement gate; keep behavior
        periodic=periodic,
        return_cand_map=False,
    )
    return regions




def _detect_regions_pureOLD(agents, params, ctx):
    

    H, W = np.asarray(agents[0].mask).shape[:2]
    detector_period = int(getattr(config, "detector_period", 2))
    do_detect = ((ctx.global_step % detector_period) == 0)
    if not do_detect:
        return {}, np.zeros((H, W), np.float32)

    # --- SAFE parse for optional KL threshold ---
    _emerge = getattr(config, "emerge_tau", 0.28)
    if (_emerge is None) or (isinstance(_emerge, str) and _emerge.strip().lower() in ("none", "off", "disabled", "")):
        kl_tau = None
    else:
        kl_tau = float(_emerge)

    active = detect_overlap_aligned_regions(
        agents, H=H, W=W,
        min_kids=int(getattr(config, "seed_min_kids", 2)),
        kl_tau=kl_tau,                                # ← pass None to skip KL gating
        min_area=int(getattr(config, "emerge_min_area", 8)),
        # weight_tau comes from config.parent_weight_tau inside the detector
    )

    cand_map = np.zeros((H, W), np.float32)
    for R in active.values():
        cand_map = np.maximum(cand_map, np.asarray(R.mask, np.float32))
    return active, cand_map




def detect_overlap_aligned_regionsOLD(children, *, H, W,
                                   min_kids=2,
                                   kl_tau=0.10,
                                   min_area=20,
                                   weight_tau=0.6,         
                                   activity_mu_tau=1e-3, activity_trsig_tau=1e-3,
                                   eps=1e-6,
                                   periodic=None):
    """
    Find regions where ≥min_kids children are active, the average child mask is strong,
    and the average alignment KL is low. Returns {rid: Region}.

    Improvements:
      • Activity fallback to mask if child_activity_map(...) returns None.
      • Interior weight gate supports adaptive threshold when weight_tau is None.
      • KL gate applies only if at least one child provided a finite KL map.
      • Optional 1px erosion (detector_edge_erode) happens after forming 'keep'.
    """
    
    if periodic is None:
        periodic = bool(getattr(config, "periodic_domain", True))

    cover  = np.zeros((H, W), dtype=np.int32)    # number of active kids
    weight = np.zeros((H, W), dtype=np.float32)  # sum of child mask weights
    kid_act, kid_kls = [], []

    # 1) accumulate activity, weights, and cached KLs
    mask_tau_mask = float(getattr(config, "detector_mask_tau", 1e-3))
    for ch in children:
        m = np.asarray(getattr(ch, "mask", 0.0))
        if m.shape != (H, W):
            m = resize_nn(m, (H, W)).astype(np.float32)
        else:
            m = m.astype(np.float32)

        act = child_activity_map(ch, H, W,
                                 mu_tau=activity_mu_tau,
                                 trsig_tau=activity_trsig_tau,
                                 eps=eps)
        # Fallback: if no explicit activity, use mask>tiny
        if act is None:
            a = (m > mask_tau_mask)
        else:
            a = np.asarray(act).astype(bool)

        cover  += a.astype(np.int32)
        weight += m * a.astype(np.float32)
        kid_act.append(a)

        k = getattr(ch, "cached_alignment_kl", None)
        if k is None:
            kid_kls.append(None)
        else:
            k = np.asarray(k)
            if k.shape != (H, W):
                k = resize_nn(k, (H, W))
            kid_kls.append(k.astype(np.float32))

    # 2) interior preference: require enough active kids AND strong mean mask
    keep = (cover >= int(min_kids))
    mean_weight = np.zeros((H, W), dtype=np.float32)
    nz = cover > 0
    mean_weight[nz] = weight[nz] / cover[nz].astype(np.float32)

    # interior weight gate (adaptive if weight_tau is None)
    cfg_tau = getattr(config, "parent_weight_tau", weight_tau)
    if cfg_tau is None:
        ww = mean_weight[(cover >= int(min_kids)) & (mean_weight > 0)]
        thr = float(np.percentile(ww, 60)) if ww.size else 0.0
    else:
        thr = float(cfg_tau)
    keep &= (mean_weight >= thr)

    # 3) KL filter (average over active, finite pixels) — only if any KL exists
    if kl_tau is not None:
        any_kl = any(k is not None for k in kid_kls)
        if any_kl:
            kl_sum = np.zeros((H, W), dtype=np.float32)
            kl_cnt = np.zeros((H, W), dtype=np.int32)
            for a, k in zip(kid_act, kid_kls):
                if k is None:
                    continue
                inside = a & np.isfinite(k)
                if inside.any():
                    kl_sum[inside] += k[inside]
                    kl_cnt[inside] += 1
            kl_mean = np.full((H, W), np.inf, dtype=np.float32)
            valid = kl_cnt > 0
            kl_mean[valid] = kl_sum[valid] / np.maximum(kl_cnt[valid], 1)
            keep &= (kl_mean <= float(kl_tau))
        # else: skip KL gating entirely if no KL present

    # --- connected components with optional 1px erosion ---
    pre_px = int(np.asarray(keep).sum())
    core = keep.astype(bool)

    erode_iters = int(getattr(config, "detector_edge_erode", 0))  # default OFF
    if erode_iters > 0 and core.any():
        for _ in range(erode_iters):
            if periodic:
                e = core.copy()
                e &= np.roll(core,  1, 0)
                e &= np.roll(core, -1, 0)
                e &= np.roll(core,  1, 1)
                e &= np.roll(core, -1, 1)
                core = e
            else:
                up    = np.pad(core[1: , : ], ((0,1), (0,0)))
                down  = np.pad(core[:-1, : ], ((1,0), (0,0)))
                left  = np.pad(core[: , 1: ], ((0,0), (0,1)))
                right = np.pad(core[: , :-1], ((0,0), (1,0)))
                core = core & up & down & left & right

    post_px = int(core.sum())
    min_area_eff = int(getattr(config, "emerge_min_area", min_area))

    # CC
    labels, nlab = _label4(core)
    regions = {}
    rid = 0
    for lbl in range(1, nlab + 1):
        comp = (labels == lbl)
        area = int(comp.sum())
        if area < min_area_eff:
            continue
        regions[rid] = _make_region(comp.astype(np.float32), rid)
        rid += 1

    # debug
    try:
        tau_repr = f"{cfg_tau:.3f}" if cfg_tau is not None else f"auto->{thr:.3f}"
        print(f"[DETECT] regs={len(regions)} px_keep={pre_px} px_post={post_px} "
              f"min_area={min_area_eff} weight_tau={tau_repr} "
              f"cover_sum={int(cover.sum())} mean_w={float(np.nan_to_num(mean_weight).mean()):.3f}")
    except Exception:
        pass

    return regions



