# -*- coding: utf-8 -*-
"""
Created on Wed Jul 23 10:32:58 2025

@author: chris and christine
"""
import numpy as np
import config
from detector import DetectorState, _detect_regions_pure
from update_compute_all_gradients import ( 
                        _apply_children, _compute_child_grads, _parent_intrascale_grad_pass, 
                        _final_apply_parents)
from update_rules_utils import ( _pre_light,  _post_strict,
                                _refresh_child_kl_fields, 
                                 _assign_children_to_parents, 
                                _grow_and_age_parents, _as_parent_dict, prune_orphan_parents )

from preprocess_utils import preprocess_all_agents, build_all_omega_caches, build_all_lambda_caches

from parent_spawn import _apply_spawn_from_regions
from update_rules_utils import build_alignment_aggregates



def synchronous_step(agents, generators_q, generators_p, params=None, n_jobs=1, runtime_ctx=None):
    assert runtime_ctx is not None, "synchronous_step: pass runtime_ctx"
    assert agents and (len(agents) > 0), "synchronous_step: no agents"

    import config
    params = params or {}
    eps = config.eps

    # --- runtime ctx init / normalize -------------------------------------
    if not hasattr(runtime_ctx, "detector_state") or (runtime_ctx.detector_state is None):
        runtime_ctx.detector_state = DetectorState()
    if not hasattr(runtime_ctx, "global_step"):
        runtime_ctx.global_step = 0
    if not hasattr(runtime_ctx, "parents_by_region") or (runtime_ctx.parents_by_region is None):
        runtime_ctx.parents_by_region = {}
    else:
        runtime_ctx.parents_by_region = _as_parent_dict(runtime_ctx.parents_by_region)
    if not hasattr(runtime_ctx, "next_parent_id"):
        runtime_ctx.next_parent_id = 0

    # capture once for this step
    step_now = int(getattr(runtime_ctx, "global_step", 0))

    # freeze sets
    frozen_levels     = set(params.get("frozen_levels", []))
    frozen_phi_levels = set(params.get("frozen_phi_levels", []))

    # --- PRE ---------------------------------------------------------------
    all_agents = agents + list(runtime_ctx.parents_by_region.values())
    _pre_light(all_agents, params, generators_q, generators_p)

    # --- GRADS (children) --------------------------------------------------
    grads = _compute_child_grads(agents, all_agents, generators_q, generators_p, params)

    # --- APPLY (children) --------------------------------------------------
    _apply_children(agents, grads, params, frozen_levels, frozen_phi_levels,
                    generators_q, generators_p, n_jobs)

    # --- OPTIONAL parent intrascale grad pass ------------------------------
    parents = list(runtime_ctx.parents_by_region.values())
    _parent_intrascale_grad_pass(agents, parents, generators_q, generators_p, params, accum_into=True)

    # --- POST (strict refresh pre-detect) ---------------------------------
    all_agents = agents + list(runtime_ctx.parents_by_region.values())
    _post_strict(all_agents, params, generators_q, generators_p)

    # refresh cached KL fields for children (for detect/proposals)
    _refresh_child_kl_fields(agents, all_agents, eps)

    if getattr(config, "debug_grad_timing", False):
        print(f"[STEP {step_now}] parents={len(runtime_ctx.parents_by_region)}")



    # NEW: build step-level aggregates so detector/growth can gate on agreement
    try:
        
        build_alignment_aggregates(runtime_ctx, agents)  # populates Aq_agg/Ap_agg and KLq_agg/KLp_agg
    except Exception as e:
        # Non-fatal: if aggregates missing, agreement gate will be skipped
        if getattr(config, "debug_strict", True):
            print(f"[AGG] skipped: {e}")
    A = getattr(runtime_ctx, "Aq_agg", None)
    if A is not None and getattr(config, "debug_detector_log", True):
        import numpy as np
        print(f"[AGG] Aq_agg mean={float(np.nanmean(A)):.3f} max={float(np.nanmax(A)):.3f}")



    # --- Phase C: DETECT (pure) -------------------------------------------
    active_regions, cand_map = _detect_regions_pure(agents, params, runtime_ctx)

    # --- Phase C’: SPAWN (mutating) ---------------------------------------
    if active_regions:
        _apply_spawn_from_regions(runtime_ctx, active_regions,
                                  agents, generators_q, generators_p, params)

    # --- Phase D: strict refresh after spawn -------------------------------
    all_agents = agents + list(runtime_ctx.parents_by_region.values())
    _post_strict(all_agents, params, generators_q, generators_p)

    # --- ASSIGN kids→parents (soft, supports overlap) ---------------------
    _assign_children_to_parents(
        agents, runtime_ctx.parents_by_region,
        eps=getattr(config, "support_cutoff_eps", 1e-3),
        tau=getattr(config, "parent_soft_assign_tau", 0.30),
        temp=getattr(config, "parent_soft_assign_temp", 0.25),
        max_parents_per_child=getattr(config, "parent_soft_assign_topk", 2),
        core_tau=getattr(config, "parent_assign_core_tau", 0.12),
        core_tau_rel=getattr(config, "parent_assign_core_tau_rel", 0.50),
        core_dilate_px=getattr(config, "parent_assign_core_dilate", 1),
        newborn_bootstrap_steps=getattr(config, "parent_assign_bootstrap", 2),
        allow_unassigned=True,
        debug=getattr(config, "debug_assign_summary", False),
    )
    
    prune_orphan_parents(
        runtime_ctx.parents_by_region,
        patience=getattr(config, "orphan_patience_steps", 3),
        min_total_weight=getattr(config, "orphan_min_total_weight", 1e-4),
        min_area_nz=getattr(config, "orphan_min_area_nz", 5),
        support_tau=getattr(config, "parent_support_tau", 0.02),
        verbose=getattr(config, "debug_prune_log", False),
    )


    # --- GROW/SHRINK + AGE -------------------------------------------------
    _grow_and_age_parents(runtime_ctx, agents, params)

    # --- FINAL APPLY (parents) --------------------------------------------
    _final_apply_parents(runtime_ctx, params)

    # bookkeeping
    runtime_ctx.children_latest = agents
    runtime_ctx.parents_latest  = runtime_ctx.parents_by_region
    runtime_ctx.global_step    += 1
    return agents


def _runtime_health(ctx, step, thr=0.5):
    import numpy as np
    Ps = list(getattr(ctx, "parents_by_region", {}).values())
    n = len(Ps)
    if n == 0:
        print(f"[HEALTH {step}] parents=0"); return
    areas = [int((np.asarray(P.mask)>thr).sum()) for P in Ps]
    ages  = [int(getattr(P,"_age",0)) for P in Ps]
    print(f"[HEALTH {step}] parents={n} area_med={int(np.median(areas))} "
          f"area_max={max(areas)} age_med={int(np.median(ages))} age_max={max(ages)}")

# call it:






# debug_watch.py
import numpy as np

def _shape(a):
    try: return tuple(np.asarray(a).shape)
    except: return None

def audit_sigma_shapes(agents, tag, *, raise_on_stack=False):
    bad = []
    for a in agents:
        Sq = getattr(a, "sigma_q_field", None)
        Sp = getattr(a, "sigma_p_field", None)
        msgq = f"{getattr(a,'id','?')}: q={_shape(Sq)}"
        msgp = f"{getattr(a,'id','?')}: p={_shape(Sp)}"
        print(f"[AUDIT:{tag}] {msgq}  {msgp}")
        for name, S in (("sigma_q_field", Sq), ("sigma_p_field", Sp)):
            if S is None: continue
            S = np.asarray(S)
            if S.ndim != 4 or S.shape[-1] != S.shape[-2]:
                bad.append((a, name, S.shape))
                if raise_on_stack:
                    raise RuntimeError(f"[AUDIT:{tag}] {name} bad shape {S.shape} for agent {getattr(a,'id','?')}")
    return bad

