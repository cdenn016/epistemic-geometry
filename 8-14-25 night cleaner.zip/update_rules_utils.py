# -*- coding: utf-8 -*-
"""
Created on Tue Aug 12 20:10:51 2025

@author: chris and christine
"""

import numpy as np
import config

from generalized_diagnostics_metrics import compute_alignment_field_general
from bundle_morphism_utils import init_parent_morphisms
from preprocess_utils import build_all_omega_caches, build_all_lambda_caches, preprocess_all_agents

from parent_growth import compute_parent_growth_maps_pure, apply_parent_growth


def compute_soft_assignments(children, parents, *,
                             sim_fn,            # returns s_{iP} in [0,1]
                             tau=0.5,           # minimum similarity to consider
                             temp=0.2,          # softmax temperature
                             max_parents_per_child=None,
                             # NEW:
                             allow_unassigned=True,
                             gate=None,         # optional (I,P) boolean: True if child i can support parent P
                             gamma_mode="linear",  # None | "linear" | "sigmoid"
                             gamma_scale=0.2,      # width for gamma
                             parent_caps=None,     # optional length-P array of caps (sum over i of W_iP) in [0, +inf)
                             return_diagnostics=False):
    """
    Returns W in R^{I x P} with row sums <= 1 when allow_unassigned=True (via gamma scaling),
    gating on feasible child-parent overlaps, and optional per-parent capacity clipping.
    """
    
    I, Pn = len(children), len(parents)
    W = np.zeros((I, Pn), np.float32)
    diags = {"row_max": None, "row_sum": None, "col_sum": None}

    if Pn == 0 or I == 0:
        return (W, diags) if return_diagnostics else W

    # --- compute similarity matrix S (I,P) in [0,1] ---
    S = np.zeros((I, Pn), np.float32)
    for i, c in enumerate(children):
        for p, P in enumerate(parents):
            s = float(sim_fn(c, P))
            S[i, p] = 0.0 if not np.isfinite(s) else np.clip(s, 0.0, 1.0)

    # --- optional gating (overlap, support, etc.) ---
    if gate is not None:
        G = np.asarray(gate, bool)
        if G.shape != S.shape:
            raise ValueError(f"gate shape {G.shape} != S shape {S.shape}")
        S = np.where(G, S, -np.inf)

    # --- threshold + optional top-k pre-prune per row (before softmax) ---
    S[S < float(tau)] = -np.inf
    if max_parents_per_child:
        k = int(max_parents_per_child)
        # mask out all but top-k finite entries per row
        finite = np.isfinite(S)
        # set all to -inf, then re-enable top-k
        S_pruned = np.full_like(S, -np.inf)
        # argsort on negative values sorts descending; handle rows with <k finite
        for i in range(I):
            idx = np.where(finite[i])[0]
            if idx.size:
                top = idx[np.argsort(-S[i, idx])[:k]]
                S_pruned[i, top] = S[i, top]
        S = S_pruned

    # --- compute per-row confidence gamma (0..1) so rows can sum <= 1 ---
    row_max = np.nanmax(S, axis=1)
    row_max[~np.isfinite(row_max)] = -np.inf
    if gamma_mode is None:
        gamma = np.ones((I, 1), np.float32)
    else:
        if gamma_mode == "linear":
            # gamma = clamp((row_max - tau)/gamma_scale, 0, 1)
            gamma = (row_max - float(tau)) / max(1e-6, float(gamma_scale))
            gamma = np.clip(gamma, 0.0, 1.0)
        elif gamma_mode == "sigmoid":
            x = (row_max - float(tau)) / max(1e-6, float(gamma_scale))
            gamma = 1.0 / (1.0 + np.exp(-x))
        else:
            raise ValueError(f"unknown gamma_mode={gamma_mode!r}")
        gamma = gamma.astype(np.float32).reshape(I, 1)

    # --- row-wise tempered softmax (stable) ---
    X = S / max(1e-6, float(temp))
    X -= np.nanmax(X, axis=1, keepdims=True)  # stable shift
    # rows with all -inf -> exp(-inf)=0; handle below based on allow_unassigned
    W = np.exp(X, dtype=np.float32)
    row_sum = W.sum(axis=1, keepdims=True)

    # handle fully infeasible rows
    infeas = (row_sum <= 0.0)
    if np.any(infeas):
        if allow_unassigned:
            # keep zeros (no assignment)
            pass
        else:
            # pick argmax on raw S (ties: first)
            for i in np.where(infeas)[0]:
                j = int(np.nanargmax(S[i] + 0.0)) if Pn else 0
                W[i, :] = 0.0
                if Pn:
                    W[i, j] = 1.0
            row_sum = W.sum(axis=1, keepdims=True)

    # normalize to probability on feasible parents, then scale by gamma (<=1)
    W = np.divide(W, np.maximum(row_sum, 1e-6), where=(row_sum > 0.0))
    W *= gamma  # now each row sums to <= 1

    # --- optional parent capacity (simple clip + renormalize rows, no OT) ---
    if parent_caps is not None:
        caps = np.asarray(parent_caps, np.float32).reshape(1, Pn)  # broadcast rows
        col_sum = W.sum(axis=0, keepdims=True)
        scale = np.ones_like(col_sum, np.float32)
        with np.errstate(divide="ignore", invalid="ignore"):
            scale = np.minimum(1.0, caps / np.maximum(col_sum, 1e-6))
        # apply column scaling
        W *= scale
        # do NOT renormalize rows back to 1; keep ≤1 property
    else:
        col_sum = W.sum(axis=0, keepdims=True)

    if return_diagnostics:
        diags["row_max"] = row_max.astype(np.float32)
        diags["row_sum"] = W.sum(axis=1).astype(np.float32)
        diags["col_sum"] = col_sum.flatten().astype(np.float32)
        return W, diags
    return W


def align_field_fn(ci, cj, R):
    # symmetric alignment in region R (e.g., averaged over R ∩ supports)
    # Use your existing cached per-pixel KL or agreement → convert to similarity
    # Example: s = exp(-mean KL_sym) clipped to [0,1]
    KL_sym = np.nanmean(0.5*(ci.kl_to[cj.id] + cj.kl_to[ci.id])[R])  # adapt to your caches
    return np.exp(-float(KL_sym))


# update_rules_utils.py

def _assign_children_to_parents(children, parents_by_id, *, eps=1e-3,
                                tau=0.30, temp=0.25, max_parents_per_child=2,
                                # NEW knobs:
                                core_tau=None,                 # absolute floor on parent core
                                core_tau_rel=0.50,             # relative to parent.max()
                                core_dilate_px=1,              # small dilation helps newborns
                                newborn_bootstrap_steps=2,     # relax core τ for very young parents
                                allow_unassigned=True,
                                debug=False):
    import numpy as np
    import config
    from parent_utils import ensure_hw
    try:
        from scipy.ndimage import binary_dilation
    except Exception:
        binary_dilation = None

    Ps = list(parents_by_id.values())
    Pn = len(Ps); I = len(children)

    # trivial exits
    if Pn == 0 or I == 0:
        for ch in children:
            setattr(ch, "labels", {}); setattr(ch, "parent_id", -1)
        for P in Ps:
            P.child_weights = {}; P.child_ids = ()
        return

    H, W = np.asarray(children[0].mask).shape[:2]
    abs_core = float(core_tau if core_tau is not None
                     else getattr(config, "parent_growth_core_tau", 0.20))
    rel_core = float(core_tau_rel)

    # ---- child masks (boolean) ----
    Cmb = [ensure_hw(getattr(ch, "mask", 0.0), (H, W)) > float(eps) for ch in children]

    # ---- parent cores (boolean, RELATIVE + ABS, with bootstrap + dilation) ----
    Pcore = []
    for P in Ps:
        pm = ensure_hw(getattr(P, "mask", 0.0), (H, W))
        mmax = float(np.max(pm)) if np.size(pm) else 0.0
        thr  = max(abs_core, rel_core * mmax)
        # newborn bootstrap: relax threshold a bit for very young parents
        age  = int(getattr(P, "_age", 0))
        if age < int(newborn_bootstrap_steps):
            thr *= 0.6  # 40% easier for first few steps
        core = (pm > thr)
        if core_dilate_px and binary_dilation is not None:
            core = binary_dilation(core, iterations=int(core_dilate_px))
        Pcore.append(core)

    # ---- similarity matrix with gating ----
    S = np.full((I, Pn), -np.inf, np.float32)
    for i, cm in enumerate(Cmb):
        if not cm.any():   # empty child
            continue
        for p, core in enumerate(Pcore):
            inter = int((cm & core).sum())
            if inter == 0:
                continue
            union = int((cm | core).sum())
            S[i, p] = float(inter) / float(max(1, union))  # IoU on core

    # threshold
    S[S < float(tau)] = -np.inf

    # top-k prune per row (optional)
    if max_parents_per_child:
        k = int(max_parents_per_child)
        for i in range(I):
            fin = np.isfinite(S[i])
            if fin.sum() > k:
                keep = np.where(fin)[0][np.argsort(-S[i, fin])[:k]]
                row = np.full(Pn, -np.inf, np.float32); row[keep] = S[i, keep]
                S[i] = row

    # ---- numerically safe softmax with “all -inf row” handling ----
    finite_row = np.isfinite(S).any(axis=1)
    W = np.zeros((I, Pn), np.float32)  # default: unassigned
    if finite_row.any():
        X = S[finite_row] / max(1e-6, float(temp))
        # safe max (each row has at least one finite element by construction)
        row_max = np.max(X, axis=1, keepdims=True)
        X -= row_max
        W_fin = np.exp(X, dtype=np.float32)
        W_fin /= np.maximum(W_fin.sum(axis=1, keepdims=True), 1e-6)
        W[finite_row] = W_fin
    # else: keep zeros in W (unassigned rows)

    # ---- write back ----
    for i, ch in enumerate(children):
        labs = {int(getattr(Ps[p], "id", p)): float(W[i, p])
                for p in range(Pn) if W[i, p] > 0.0}
        setattr(ch, "labels", labs)
        setattr(ch, "parent_id", int(max(labs, key=labs.get)) if labs else -1)

    for p, P in enumerate(Ps):
        weights = {}
        ids = []
        for i, ch in enumerate(children):
            w = float(W[i, p])
            if w > 0.0:
                cid = int(getattr(ch, "id", i))
                weights[cid] = w; ids.append(cid)
        P.child_weights = weights
        P.child_ids = tuple(sorted(ids))

    if debug:
        for p, P in enumerate(Ps):
            wsum = float(sum((P.child_weights or {}).values()))
            print(f"[ASSIGN] P{getattr(P,'id',p)} kids={len(P.child_ids)} wsum={wsum:.3g}")






def prune_orphan_parents(parents_by_id, *, patience=3,
                         min_total_weight=1e-4, min_area_nz=5,
                         support_tau=0.02, verbose=False):
    """Remove parents that carry ~no child weight for `patience` steps.
       Also culls tiny masks that never grow."""
    import numpy as np
    dead = []
    for pid, P in list(parents_by_id.items()):
        wsum = float(sum((getattr(P, "child_weights", {}) or {}).values()))
        nz   = int(np.count_nonzero(np.asarray(P.mask) > float(support_tau)))
        ticks = int(getattr(P, "_orphan_ticks", 0))

        if (wsum < float(min_total_weight)) or (nz < int(min_area_nz)):
            ticks += 1
        else:
            ticks = 0
        P._orphan_ticks = ticks
        if ticks >= int(patience):
            dead.append(pid)

    for pid in dead:
        parents_by_id.pop(pid, None)
    if verbose and dead:
        print(f"[PRUNE] removed {len(dead)} parents: {dead}")



def _grow_and_age_parents(ctx, children, params):
    """
    Phase E — growth (pure -> apply), then simple aging.
    ctx: runtime context with ctx.parents_by_region
    children: list of child agents (for coverage/KL inputs)
    params: (unused here, kept for signature consistency)
    """
    # no parents -> nothing to do
    if not getattr(ctx, "parents_by_region", None):
        return

    # --- compute (pure) ---
    growth_maps = compute_parent_growth_maps_pure(
        ctx, children,
        tau_grow=getattr(config, "parent_tau_grow", 0.30),     # allow "p60"
        tau_shrink=getattr(config, "parent_tau_shrink", 0.18), # allow "p40", etc.
        kappa=getattr(config, "parent_kappa", 0.05),           # allow "auto"
        grow_band=int(getattr(config, "parent_grow_band", 1)),
        shrink_band=int(getattr(config, "parent_shrink_band", 1)),
        mask_tau=float(getattr(config, "parent_growth_core_tau", 0.20)),
    )


    # --- apply (mutating) ---
    apply_parent_growth(
        ctx, growth_maps,
        eta_grow=float(getattr(config, "parent_eta_grow", 0.08)),
        eta_shrink=float(getattr(config, "parent_eta_shrink", 0.12)),
        min_area=int(getattr(config, "parent_min_area", 10)),
        max_area=getattr(config, "parent_max_area", None),
        delta_cap=float(getattr(config, "parent_delta_cap", 0.05)),
        blur_iters=int(getattr(config, "parent_blur_iters", 1)),
    )

    # --- aging / grace bookkeeping ---
    for P in ctx.parents_by_region.values():
        P._age = int(getattr(P, "_age", 0)) + 1
        if hasattr(P, "_grace"):
            P._grace = max(0, int(getattr(P, "_grace", 0)) - 1)

    # optional terse log
    if getattr(config, "debug_growth_log", False):
        thr = float(getattr(config, "parent_area_threshold",
                    getattr(config, "parent_growth_core_tau", 0.20)))

        areas = [int((np.asarray(P.mask) > thr).sum()) for P in ctx.parents_by_region.values()]
        if areas:
            print(f"[GROW] parents={len(areas)} median_area={int(np.median(areas))} max_area={max(areas)}")




def _pre_light(all_agents, params, Gq, Gp):
    pre = dict(params)
    pre["sanitize_strict"] = pre.get("sanitize_strict_pre", False)
    pre["exp_n_jobs"] = 1
    preprocess_all_agents(all_agents, pre, Gq, Gp)
    build_all_omega_caches(all_agents)
    build_all_lambda_caches(all_agents)





def _post_strict(all_agents, params, Gq, Gp):
    post = dict(params)
    post["sanitize_strict"] = True
    post["exp_n_jobs"] = 1
    preprocess_all_agents(all_agents, post, Gq, Gp)
    build_all_omega_caches(all_agents)
    build_all_lambda_caches(all_agents)

# --- find this function in update_rules_utils.py ---
def _refresh_child_kl_fields(children, all_agents, eps):

    import numpy as _np
    import config as _cfg

    tau_q  = float(getattr(_cfg, "tau_align_q", 0.45))
    tau_p  = float(getattr(_cfg, "tau_align_p", 0.45))
    alpha  = float(getattr(_cfg, "blend_qp_alpha", 0.50))  # 0→model only, 1→belief only
    kl_cap = float(getattr(_cfg, "signal_kl_cap", 10.0))   # cap before exp()

    for ch in children:
        # Per-pixel KL (lvl-0 alignment) for belief and model
        KL_q = compute_alignment_field_general(all_agents, ch.id, field_type="belief", log_eps=eps)
        KL_p = compute_alignment_field_general(all_agents, ch.id, field_type="model",  log_eps=eps)
        ch.cached_alignment_kl       = KL_q
        ch.cached_model_alignment_kl = KL_p

        # Convenience: blended KL & agreement A = exp(-KL/τ) for plotting / growth “auto” mode
        if KL_q is not None and KL_p is not None:
            KL_q_c = _np.clip(_np.asarray(KL_q, _np.float32), 0.0, kl_cap)
            KL_p_c = _np.clip(_np.asarray(KL_p, _np.float32), 0.0, kl_cap)
            KL_blend = alpha * KL_q_c + (1.0 - alpha) * KL_p_c
            # store human-friendly fields some downstream code already probes:
            ch.kl_field = KL_blend
            A_q = _np.exp(-KL_q_c / max(1e-6, tau_q))
            A_p = _np.exp(-KL_p_c / max(1e-6, tau_p))
            ch.agreement_field = _np.clip(alpha * A_q + (1.0 - alpha) * A_p, 0.0, 1.0).astype(_np.float32)
        else:
            # Fallbacks keep prior behavior if one side is missing
            if KL_q is not None:
                K = _np.clip(_np.asarray(KL_q, _np.float32), 0.0, kl_cap)
                ch.kl_field = K
                ch.agreement_field = _np.exp(-K / max(1e-6, tau_q)).astype(_np.float32)
            elif KL_p is not None:
                K = _np.clip(_np.asarray(KL_p, _np.float32), 0.0, kl_cap)
                ch.kl_field = K
                ch.agreement_field = _np.exp(-K / max(1e-6, tau_p)).astype(_np.float32)


def build_alignment_aggregates(runtime_ctx, children, *, kl_cap=10.0):
    """
    From per-child caches:
      - cached_alignment_kl  (belief)
      - cached_model_alignment_kl (model)
    produce step-level aggregates on runtime_ctx:
      KLq_agg, KLp_agg, Aq_agg, Ap_agg (H,W)
    """
    import numpy as np
    try:
        import config
        tau_q = float(getattr(config, "tau_align_q", 0.45))
        tau_p = float(getattr(config, "tau_align_p", 0.45))
        kl_cap = float(getattr(config, "signal_kl_cap", kl_cap))
    except Exception:
        tau_q, tau_p = 0.45, 0.45

    if not children:
        runtime_ctx.KLq_agg = runtime_ctx.KLp_agg = None
        runtime_ctx.Aq_agg  = runtime_ctx.Ap_agg  = None
        return

    H, W = children[0].mask.shape[:2]

    def _stack(attr):
        arrs = []
        for ch in children:
            fld = getattr(ch, attr, None)
            if fld is None:
                continue
            f = np.asarray(fld, np.float32)
            if f.shape != (H, W):
                # nearest-neighbor resize (avoid bringing deps here)
                f = f[:H, :W] if f.shape[0] >= H and f.shape[1] >= W else np.pad(
                    f, ((0, max(0, H - f.shape[0])), (0, max(0, W - f.shape[1]))),
                    mode="edge"
                )[:H, :W]
            arrs.append(f)
        if not arrs:
            return None
        return np.stack(arrs, axis=0)

    KLq_stack = _stack("cached_alignment_kl")
    KLp_stack = _stack("cached_model_alignment_kl")

    def _agg_mean(stack):
        if stack is None: return None
        return np.nan_to_num(stack, nan=np.inf, posinf=np.inf, neginf=0.0).mean(axis=0)

    KLq = _agg_mean(KLq_stack)
    KLp = _agg_mean(KLp_stack)

    def _to_A(KL, tau):
        if KL is None: return None
        K = np.clip(KL.astype(np.float32), 0.0, kl_cap)
        return np.exp(-K / max(1e-6, float(tau))).astype(np.float32)

    runtime_ctx.KLq_agg = KLq
    runtime_ctx.KLp_agg = KLp
    runtime_ctx.Aq_agg  = _to_A(KLq, tau_q)
    runtime_ctx.Ap_agg  = _to_A(KLp, tau_p)



def _as_parent_dict(obj):
    """
    Normalize parents -> {pid: Parent}. Accepts dict, list, iterable, or None.
    Uses the parent's .id if present; else falls back to enumerate index.
    """
    import collections.abc as _abc
    if obj is None:
        return {}
    if isinstance(obj, dict):
        return {int(getattr(p, "id", pid)): p for pid, p in obj.items()}
    if isinstance(obj, _abc.Iterable):
        return {int(getattr(p, "id", i)): p for i, p in enumerate(obj)}
    # Single parent object?
    return {int(getattr(obj, "id", 0)): obj}




def _as_parent_dictOld(obj):
    """Accept dict, list, or single parent object; return {pid: parent} dict."""
    import collections.abc as _abc
    if obj is None:
        return {}
    if isinstance(obj, dict):
        return {int(getattr(p, "id", pid)): p for pid, p in obj.items()}
    if isinstance(obj, _abc.Iterable) and not hasattr(obj, "mask"):
        return {int(getattr(p, "id", i)): p for i, p in enumerate(obj)}
    # single parent object
    return {int(getattr(obj, "id", 0)): obj}
