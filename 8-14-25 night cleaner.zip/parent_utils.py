# -*- coding: utf-8 -*-
"""
Created on Thu Aug 14 09:35:09 2025

@author: chris and christine
"""
from typing import Dict, List, Optional, Tuple
import numpy as np
import config
from agent_schema import Agent
from runtime_context import runtime_ctx

from numerical_utils import resize_nn






def normalize_groups(groups, H, W):
    """Make every group look like {"kids": set[int], "child_ids": tuple[int], "mask": float32(H,W)}."""
    import numpy as np
    from numerical_utils import resize_nn
    out = []
    for g in (groups or []):
        kids = g.get("kids"); 
        if kids is None: kids = g.get("child_ids") or ()
        kids = {int(k) for k in (kids if isinstance(kids, (set, list, tuple)) else list(kids))}
        m = g.get("mask", None)
        if m is None: 
            continue
        M = np.asarray(getattr(m, "mask", m), np.float32)
        if M.shape != (H, W): M = resize_nn(M, (H, W)).astype(np.float32)
        out.append({"kids": kids, "child_ids": tuple(sorted(kids)), "mask": M})
    return out




def cluster_children_by_alignment(
    region_masks, children, H, W, *,
    Gq=None, Gp=None,                   # kept for API parity (unused)
    child_eps=0.10,                     # support threshold on child.mask
    min_child_area=6,                   # min px for a child to be eligible in region
    thr_align=0.60,                     # threshold on agreement A∈[0,1]
    min_cluster_kids=1,                 # drop tiny clusters
):
    import numpy as np
    try:
        import config
    except Exception:
        class _C: pass
        config = _C()

    iou_thr = float(getattr(config, "child_intragroup_iou_thr", 0.55))
    tau_q   = float(getattr(config, "tau_align_q", 0.45))
    tau_p   = float(getattr(config, "tau_align_p", 0.45))
    alpha   = float(getattr(config, "blend_qp_alpha", 0.50))
    kl_cap  = float(getattr(config, "signal_kl_cap", 10.0))

    def _as_bool(x):
        x = np.asarray(x)
        if x.dtype != bool: x = x.astype(np.float32) > 0.5
        return x

    def _ensure_A(ch):
        # prefer precomputed agreement_field
        A = getattr(ch, "agreement_field", None)
        if A is not None and np.asarray(A).shape == (H, W):
            return np.clip(np.asarray(A, np.float32), 0.0, 1.0)
        # build from cached KLs if needed
        from numerical_utils import resize_nn
        Kq = getattr(ch, "cached_alignment_kl", None)
        Kp = getattr(ch, "cached_model_alignment_kl", None)
        if (Kq is None) and (Kp is None):
            m = np.asarray(ch.mask, np.float32)
            if m.shape != (H, W): m = resize_nn(m, (H, W)).astype(np.float32)
            return (m > float(child_eps)).astype(np.float32)
        Aq = None
        if Kq is not None:
            k = np.asarray(Kq, np.float32)
            if k.shape != (H, W):
                from numerical_utils import resize_nn
                k = resize_nn(k, (H, W)).astype(np.float32)
            Aq = np.exp(-np.clip(k, 0.0, kl_cap)/max(1e-6, tau_q)).astype(np.float32)
        Ap = None
        if Kp is not None:
            k = np.asarray(Kp, np.float32)
            if k.shape != (H, W):
                from numerical_utils import resize_nn
                k = resize_nn(k, (H, W)).astype(np.float32)
            Ap = np.exp(-np.clip(k, 0.0, kl_cap)/max(1e-6, tau_p)).astype(np.float32)
        if Aq is None: return np.clip(Ap, 0.0, 1.0)
        if Ap is None: return np.clip(Aq, 0.0, 1.0)
        return np.clip(alpha * Aq + (1.0 - alpha) * Ap, 0.0, 1.0)

    def _child_support_in_region(ch, Rmask_bool):
        from numerical_utils import resize_nn
        m = np.asarray(ch.mask, np.float32)
        if m.shape != (H, W): m = resize_nn(m, (H, W)).astype(np.float32)
        A = _ensure_A(ch)  # [0,1]
        supp = (m > float(child_eps)) & (A >= float(thr_align)) & Rmask_bool
        if supp.sum() < int(min_child_area): return None
        return supp

    def _iou(a, b):
        inter = int((a & b).sum())
        if inter == 0: return 0.0
        denom = int((a | b).sum())
        return inter / float(denom) if denom else 0.0

    class UF:
        def __init__(self, n): self.p = list(range(n)); self.r = [0]*n
        def f(self, x):
            while self.p[x] != x:
                self.p[x] = self.p[self.p[x]]
                x = self.p[x]
            return x
        def u(self, a, b):
            ra, rb = self.f(a), self.f(b)
            if ra == rb: return
            if self.r[ra] < self.r[rb]: ra, rb = rb, ra
            self.p[rb] = ra
            if self.r[ra] == self.r[rb]: self.r[ra] += 1

    # --- NEW: robust region iterator (dict | list | tuple | ndarray | Region) ---
    def _iter_regions(reg_masks):
        from numerical_utils import resize_nn
        if reg_masks is None:
            return
        # dict-like
        if hasattr(reg_masks, "items"):
            it = reg_masks.items()
        # list/tuple of masks or Region-like objs
        elif isinstance(reg_masks, (list, tuple)):
            it = enumerate(reg_masks)
        else:
            arr = np.asarray(reg_masks)
            if arr.ndim == 2 and arr.shape == (H, W):
                it = [(0, reg_masks)]
            elif arr.ndim == 3 and arr.shape[1:] == (H, W):
                it = list(enumerate(reg_masks))
            else:
                it = [(0, reg_masks)]
        for rid, R in it:
            # Accept Region-like with .mask, or raw arrays
            M = np.asarray(getattr(R, "mask", R), np.float32)
            if M.shape != (H, W):
                M = resize_nn(M, (H, W)).astype(np.float32)
            yield int(getattr(R, "id", rid)), M

    groups = []

    # ---------- iterate regions (robust to list input) ----------
    for rid, Rmask in _iter_regions(region_masks):
        Rb = _as_bool(Rmask)

        kid_ids, supports = [], []
        for ch in children:
            S = _child_support_in_region(ch, Rb)
            if S is None: 
                continue
            kid_ids.append(int(getattr(ch, "id", len(kid_ids))))
            supports.append(S)

        n = len(supports)
        if n == 0:
            continue
        if n == 1:
            if min_cluster_kids <= 1:
                gmask = supports[0].astype(np.float32)
                groups.append({"kids": {kid_ids[0]}, "mask": gmask})
            continue

        uf = UF(n)
        for i in range(n):
            Si = supports[i]
            for j in range(i+1, n):
                Sj = supports[j]
                if _iou(Si, Sj) >= iou_thr:
                    uf.u(i, j)

        comp = {}
        for i in range(n):
            root = uf.f(i)
            comp.setdefault(root, {"kids": set(), "mask": None})
            comp[root]["kids"].add(kid_ids[i])
            comp[root]["mask"] = supports[i] if comp[root]["mask"] is None else (comp[root]["mask"] | supports[i])

        for c in comp.values():
            if len(c["kids"]) < int(min_cluster_kids):
                continue
            m = c["mask"].astype(np.float32)
            if int(m.sum()) < int(min_child_area):
                continue
            groups.append({"kids": c["kids"], "mask": m})

    return groups




def o_compute_blended_agreement_maps(children, child_ids, *, generators_q=None, generators_p=None,
                                    tau_q=0.20, tau_p=0.20):
    """
    Return (A_maps, joint_maps) keyed by (gid_a, gid_b), where
      A = w*A_model + (1-w)*A_belief and A_* = exp(-KL/τ) on the overlap.
    The blend-weight w comes from config.parent_model_vs_belief_w (default 0.7).
    Falls back gracefully if one side is unavailable.
    """
    import numpy as np, config
    from detector import compute_pairwise_agreement_maps
    ids = sorted(set(int(i) for i in child_ids))
    kids = [children[i] for i in ids]   # local list
    if not kids:
        return {}, {}

    # compute A and joint for q and/or p
    A_q, J_q = {}, {}
    A_p, J_p = {}, {}

    if generators_q is not None:
        _, A_loc, J_loc = compute_pairwise_agreement_maps(kids, tau=tau_q, field="q", generators=generators_q)
        # re-key from local (i,j) to global (gid_i,gid_j)
        for (i,j), Aij in A_loc.items():
            key = (ids[i], ids[j])
            A_q[key] = Aij
            J_q[key] = J_loc[(i,j)]

    if generators_p is not None:
        _, A_loc, J_loc = compute_pairwise_agreement_maps(kids, tau=tau_p, field="p", generators=generators_p)
        for (i,j), Aij in A_loc.items():
            key = (ids[i], ids[j])
            A_p[key] = Aij
            J_p[key] = J_loc[(i,j)]

    # choose available modalities
    w = float(getattr(config, "parent_model_vs_belief_w", 0.7))  # model heavier by default
    A_blend, J_blend = {}, {}
    keys = set(A_q.keys()) | set(A_p.keys())
    for key in keys:
        Aq = A_q.get(key, None)
        Ap = A_p.get(key, None)
        if (Aq is None) and (Ap is None):
            continue
        if (Aq is None):
            A_blend[key] = Ap
            J_blend[key] = J_p[key]
        elif (Ap is None):
            A_blend[key] = Aq
            J_blend[key] = J_q[key]
        else:
            # union of overlaps; where both exist, blend; where only one exists, use it
            J = (J_q[key] | J_p[key])
            A = np.zeros_like(Aq, dtype=np.float32)
            both = (J_q[key] & J_p[key])
            only_q = (J_q[key] & ~J_p[key])
            only_p = (J_p[key] & ~J_q[key])
            if np.any(both):   A[both]   = (1.0 - w)*Aq[both] + w*Ap[both]
            if np.any(only_q): A[only_q] = Aq[only_q]
            if np.any(only_p): A[only_p] = Ap[only_p]
            A_blend[key] = A
            J_blend[key] = J

    return A_blend, J_blend





def _compute_blended_agreement_mapsnew(
    children, child_ids, *,
    generators_q=None, generators_p=None,
    tau_q=None, tau_p=None,
    omega_provider=None,        # optional: callable (ci, cj, field)-> Ω_ij (H,W,K,K)
    stride: int = 1,            # decimate overlap pixels for speed
    bbox_only: bool = True,     # compute only on overlap bbox
    tcap: float = None,         # cap KL before exp(); defaults to config.signal_kl_cap
    return_scores: bool = True, # also return per-pair scalar summaries
):
    """
    DIAGNOSTIC-ONLY (O(#pairs · H · W)): blended pairwise agreement on overlaps.

    Returns:
      A_blend, J_blend[, S_blend]
        - A_blend[(gid_i,gid_j)] : float32 (H,W) with A in [0,1] on Ji∩Jj (0 elsewhere)
        - J_blend[(gid_i,gid_j)] : bool (H,W) overlap mask
        - S_blend[(gid_i,gid_j)] : dict of scalar scores (if return_scores=True)
    """
    import numpy as np, config
    # --- config defaults ------------------------------------------------------
    if tau_q is None: tau_q = float(getattr(config, "tau_align_q", 0.45))
    if tau_p is None: tau_p = float(getattr(config, "tau_align_p", 0.45))
    if tcap  is None: tcap  = float(getattr(config, "signal_kl_cap", 10.0))
    w = float(getattr(config, "parent_model_vs_belief_w", 0.7))  # model heavier by default

    # NOTE: compute_pairwise_agreement_maps is now DIAGNOSTIC; prefer omega_provider if you have it
    from detector import compute_pairwise_agreement_maps

    ids = sorted(set(int(i) for i in child_ids))
    kids = [children[i] for i in ids]
    if not kids:
        return ({}, {} , {}) if return_scores else ({}, {})

    # --- build per-side pairwise A-maps (diagnostic) --------------------------
    A_q, J_q = {}, {}
    if generators_q is not None:
        _, A_loc, J_loc = compute_pairwise_agreement_maps(
            kids, tau=tau_q, field="q", generators=generators_q,
            omega_provider=omega_provider, stride=stride, bbox_only=bbox_only, return_kl=False
        )
        for (i, j), Aij in A_loc.items():
            key = (ids[i], ids[j]); A_q[key] = np.asarray(Aij, np.float32); J_q[key] = J_loc[(i, j)]

    A_p, J_p = {}, {}
    if generators_p is not None:
        _, A_loc, J_loc = compute_pairwise_agreement_maps(
            kids, tau=tau_p, field="p", generators=generators_p,
            omega_provider=omega_provider, stride=stride, bbox_only=bbox_only, return_kl=False
        )
        for (i, j), Aij in A_loc.items():
            key = (ids[i], ids[j]); A_p[key] = np.asarray(Aij, np.float32); J_p[key] = J_loc[(i, j)]

    # --- blend, with graceful fallbacks --------------------------------------
    A_blend, J_blend = {}, {}
    S_blend = {} if return_scores else None
    keys = set(A_q.keys()) | set(A_p.keys())
    for key in keys:
        Aq = A_q.get(key, None); Jq = J_q.get(key, None)
        Ap = A_p.get(key, None); Jp = J_p.get(key, None)
        if (Aq is None) and (Ap is None):
            continue

        if (Aq is None):
            A = Ap; J = Jp
        elif (Ap is None):
            A = Aq; J = Jq
        else:
            # union of overlaps; where both exist, blend; else take whichever exists
            J = (np.asarray(Jq, bool) | np.asarray(Jp, bool))
            A = np.zeros_like(Aq, dtype=np.float32)
            both   = (np.asarray(Jq, bool) & np.asarray(Jp, bool))
            only_q = (np.asarray(Jq, bool) & ~np.asarray(Jp, bool))
            only_p = (~np.asarray(Jq, bool) & np.asarray(Jp, bool))
            if np.any(both):   A[both]   = (1.0 - w) * Aq[both] + w * Ap[both]
            if np.any(only_q): A[only_q] = Aq[only_q]
            if np.any(only_p): A[only_p] = Ap[only_p]

        A_blend[key] = A
        J_blend[key] = J

        if return_scores:
            Jc = np.asarray(J, bool)
            n  = int(Jc.sum())
            if n > 0:
                a_vals = A[Jc]
                # a few concise scalars for grouping / reports
                S_blend[key] = dict(
                    area=n,
                    mean=float(a_vals.mean()),
                    p90=float(np.percentile(a_vals, 90)),
                    p95=float(np.percentile(a_vals, 95)),
                    amax=float(a_vals.max()),
                )
            else:
                S_blend[key] = dict(area=0, mean=0.0, p90=0.0, p95=0.0, amax=0.0)

    return (A_blend, J_blend, S_blend) if return_scores else (A_blend, J_blend)










def _dilate_bool(mask: np.ndarray, r: int, periodic: bool) -> np.ndarray:
    """Binary dilation by r px, optional periodic wrapping."""
    if r <= 0:
        return mask.astype(bool)
    try:
        from scipy.ndimage import binary_dilation
        se = np.ones((2*r + 1, 2*r + 1), dtype=bool)
        if not periodic:
            return binary_dilation(mask.astype(bool), structure=se)
        H, W = mask.shape
        T = np.tile(mask.astype(bool), (3, 3))
        Td = binary_dilation(T, structure=se)
        return Td[H:2*H, W:2*W]
    except Exception:
        # fallback: cheap square foot-print without SciPy
        m = mask.astype(bool)
        for _ in range(r):
            up    = np.pad(m[1: , : ], ((0,1),(0,0)))
            down  = np.pad(m[:-1, : ], ((1,0),(0,0)))
            left  = np.pad(m[: , 1: ], ((0,0),(0,1)))
            right = np.pad(m[: , :-1], ((0,0),(1,0)))
            m = m | up | down | left | right
        if periodic:
            # wrap edges once (approximate)
            m[0, :]  |= m[-1, :]
            m[-1, :] |= m[0, :]
            m[:, 0]  |= m[:, -1]
            m[:, -1] |= m[:, 0]
        return m


#growth
def binary_dilate_3x3(x: np.ndarray) -> np.ndarray:
    x = np.asarray(x, bool); H, W = x.shape
    y = np.zeros((H, W), bool)
    for di in (-1, 0, 1):
        for dj in (-1, 0, 1):
            y |= np.pad(x, 1)[1+di:1+di+H, 1+dj:1+dj+W]
    return y

#growth
def binary_erode_3x3(x: np.ndarray) -> np.ndarray:
    x = np.asarray(x, bool); H, W = x.shape
    y = np.ones((H, W), bool)
    for di in (-1, 0, 1):
        for dj in (-1, 0, 1):
            y &= np.pad(x, 1)[1+di:1+di+H, 1+dj:1+dj+W]
    return y

#growth
def _logistic(x, tau, kappa):
    """
    Stable sigmoid around threshold tau with slope governed by kappa.
    Accepts arrays; returns array in [0,1].
    """
    x = np.asarray(x, np.float64)
    z = (x - float(tau)) / max(float(kappa), 1e-6)
    z = np.clip(z, -60.0, 60.0)
    return 1.0 / (1.0 + np.exp(-z))




#everywhere
# --- replace in parent_utils.py ---
def child_activity_map(
    ch, H, W,
    # belief (q) thresholds (kept for backward compat with detector call)
    mu_tau=1e-3, trsig_tau=1e-3,
    # misc
    eps=1e-6,
    # model (p) thresholds (None ⇒ pull from config or fall back to q thresholds)
    mu_tau_p=None, trsig_tau_p=None,
    # mixing controls (None ⇒ pull from config)
    mix_mode=None,                 # 'weighted_or' | 'and' | 'or' | 'model_only' | 'belief_only'
    w_model=None, w_belief=None,   # weights for 'weighted_or'
    score_tau=None                 # threshold for 'weighted_or'
):
    
    try:
        import config  # read knobs if present; avoids hard dep at import time
    except Exception:
        config = None

    # --- mask gate (always required) ---
    m = getattr(ch, "mask", None)
    if m is None:
        return None
    m = np.asarray(m)
    if m.shape[:2] != (H, W):
        m = resize_nn(m, (H, W))
    m_ok = (m > eps)

    # --- fetch fields ---
    mu_q, Sig_q = getattr(ch, "mu_q_field", None), getattr(ch, "sigma_q_field", None)
    mu_p, Sig_p = getattr(ch, "mu_p_field", None), getattr(ch, "sigma_p_field", None)

    # fast path: only mask known
    if ((mu_q is None or Sig_q is None) and (mu_p is None or Sig_p is None)):
        return m_ok

    # --- default thresholds & mix from config (if provided) ---
    if mu_tau_p is None:
        mu_tau_p = float(getattr(config, "activity_mu_tau_p", mu_tau if config else mu_tau))
    if trsig_tau_p is None:
        trsig_tau_p = float(getattr(config, "activity_trsig_tau_p", trsig_tau if config else trsig_tau))

    if mix_mode is None:
        mix_mode = getattr(config, "activity_mix_mode", "weighted_or")
    if w_model is None:
        w_model = float(getattr(config, "activity_model_weight", 0.8))
    if w_belief is None:
        w_belief = float(getattr(config, "activity_belief_weight", 0.2))
    if score_tau is None:
        score_tau = float(getattr(config, "activity_score_tau", 0.5))

    # --- per-fiber strength (boolean maps) ---
    def _strength(mu, Sig, mu_thr, tr_thr):
        mu = np.asarray(mu); Sig = np.asarray(Sig)
        if mu.shape[:2] != (H, W):  mu = resize_nn(mu, (H, W))
        if Sig.shape[:2] != (H, W): Sig = resize_nn(Sig, (H, W))
        mu_mag = np.sqrt((mu**2).sum(-1)) if mu.ndim == 3 else np.abs(mu).astype(np.float32)
        trsig  = np.trace(Sig, axis1=-2, axis2=-1) if Sig.ndim == 4 else Sig.astype(np.float32)
        return (mu_mag > float(mu_thr)) | (trsig > float(tr_thr))

    b = _strength(mu_q, Sig_q, mu_tau, trsig_tau) if (mu_q is not None and Sig_q is not None) else None
    p = _strength(mu_p, Sig_p, mu_tau_p, trsig_tau_p) if (mu_p is not None and Sig_p is not None) else None

    # --- combine belief/model according to mix_mode ---
    if mix_mode == "model_only":
        act_core = p if p is not None else (b if b is not None else False)
    elif mix_mode == "belief_only":
        act_core = b if b is not None else (p if p is not None else False)
    elif mix_mode == "and":
        act_core = (b if b is not None else True) & (p if p is not None else True)
    elif mix_mode == "or":
        act_core = (b if b is not None else False) | (p if p is not None else False)
    else:
        # 'weighted_or': treat booleans as 0/1, threshold weighted sum
        b_f = b.astype(np.float32) if b is not None else 0.0
        p_f = p.astype(np.float32) if p is not None else 0.0
        score = w_model * p_f + w_belief * b_f
        act_core = (score >= float(score_tau))

    return m_ok & act_core


# --- blended agreement maps for spawn ---------------------------------------
# Put near the top of parent_utils.py (after imports)
  # uses generators_q/p under the hood








#preant spawn============================================================



def _iou_bool(a: np.ndarray, b: np.ndarray) -> float:
    inter = (a & b).sum()
    union = (a | b).sum()
    return float(inter) / max(1, int(union))

def _too_close_by_iou(comp: np.ndarray, existing_bool_masks: List[np.ndarray], *, iou_thr: float) -> bool:
    for pb in existing_bool_masks:
        if _iou_bool(comp, pb) >= float(iou_thr):
            return True
    return False

def _components(candidate_map: np.ndarray, *, min_area: int) -> List[Tuple[int, Tuple[float,float], np.ndarray]]:
    """Return components as (area, (cy,cx), mask) sorted by area desc."""
    labels, ncc = _label4(candidate_map.astype(bool))
    if ncc == 0:
        return []
    comps = []
    for c in range(1, ncc + 1):
        comp = (labels == c)
        area = int(comp.sum())
        if area < int(min_area):
            continue
        ys, xs = np.nonzero(comp)
        comps.append((area, (float(ys.mean()), float(xs.mean())), comp))
    comps.sort(key=lambda t: t[0], reverse=True)
    return comps


def _ensure_parent_store(ctx):
    """Normalize ctx.parents_by_region → Dict[int, Parent]."""
    if not hasattr(ctx, "parents_by_region") or ctx.parents_by_region is None:
        ctx.parents_by_region = {}
    if isinstance(ctx.parents_by_region, list):
        ctx.parents_by_region = {int(getattr(p, "id", i)): p for i, p in enumerate(ctx.parents_by_region)}
    return ctx.parents_by_region


def _compute_candidate_or_union(P, agents, H=None, W=None, dtype=np.float32, field_generators=None):
    # candidate from agreement
    cand = _compute_parent_candidate(P, agents, field_generators)
    # (you can keep your existing union fallback if cand is empty)
    if cand is None or not np.any(cand > 0):
        # fallback: keep current mask (or a gentle union of children)
        return np.asarray(getattr(P, "mask", 0.0), dtype=np.float32)
    return cand.astype(np.float32)





def _compute_parent_candidate(P, agents, field_generators=None):
    import numpy as np, config
    child_ids = list(getattr(P, "child_ids", []))
    if not child_ids:
        return np.zeros_like(P.mask, dtype=np.float32)

    Gq = Gp = None
    if field_generators is not None:
        Gq, Gp = field_generators

    # try blended agreement; if generators missing, fall back later
    try:
        A_maps, joint_maps = _compute_blended_agreement_maps(
            agents, child_ids,
            generators_q=Gq, generators_p=Gp,
            tau_q=float(getattr(config, "tau_align_emergent_q", 0.20)),
            tau_p=float(getattr(config, "tau_align_emergent_p", 0.20)),
        )
    except Exception:
        A_maps, joint_maps = {}, {}

    if not A_maps:
        # Fallback: cached KL → A = exp(-KL/τ), joint = mask overlap
        tau = float(getattr(config, "tau_align_emergent_fallback", 0.30))
        A_maps, joint_maps = {}, {}
        ids = sorted(set(int(i) for i in child_ids))
        for a_i in range(len(ids)):
            ia = ids[a_i]
            ma = (np.asarray(agents[ia].mask) > 1e-6)
            Kla = getattr(agents[ia], "cached_alignment_kl", None)
            for b_i in range(a_i+1, len(ids)):
                ib = ids[b_i]
                mb = (np.asarray(agents[ib].mask) > 1e-6)
                J  = (ma & mb)
                if not np.any(J): continue
                key = (ia, ib)
                klb = getattr(agents[ib], "cached_alignment_kl", None)
                # if neither cached, skip
                if Kla is None and klb is None: 
                    continue
                # simple symmetric mean if both available, else use the one we have
                if Kla is not None and klb is not None:
                    k = 0.5*(np.asarray(Kla) + np.asarray(klb))
                else:
                    k = np.asarray(Kla) if Kla is not None else np.asarray(klb)
                k = k.astype(np.float32)
                a = np.zeros_like(k, dtype=np.float32)
                a[J] = np.exp(-np.clip(k[J], 0, 10.0)/tau)
                A_maps[key] = a
                joint_maps[key] = J

    # strict core agreement → smooth mask
    m = build_parent_mask_from_group(
        agents, child_ids,
        A_maps, joint_maps,
        tau=float(getattr(config, "parent_agree_tau", 0.20)),
        m_core=int(getattr(config, "parent_core_degree", 3)),
        A_min=int(getattr(config, "parent_agree_area_min", 20)),
        soft=True,
        smooth_iters=int(getattr(config, "parent_mask_smooth_iters", 1)),
    )
    return m



def _growth_gate_from_overlap_core_activity(P, agents, H, W, eps, grow_min_kids):
    
    # overlap count
    cnt = np.zeros((H, W), np.int32)
    active_union = np.zeros((H, W), bool)
    for i in getattr(P, "child_ids", []):
        ch = agents[i]
        a = child_activity_map(ch, H, W, eps=eps)
        if a is None: continue
        active_union |= a
        cnt += (a & (np.asarray(ch.mask) > eps)).astype(np.int32)
    gate = np.ones((H, W), np.float32)
    if grow_min_kids > 0:
        gate *= np.clip(cnt.astype(np.float32) / float(grow_min_kids), 0.0, 1.0)
    # distance to core
    if getattr(P, "_core_map", None) is not None and P._core_map.any():
        dt = cheap_dt(P._core_map.astype(bool))
        r = float(getattr(config, "parent_core_decay_px", 6.0))
        gate *= np.exp(-dt / max(r, 1.0)).astype(np.float32)
    # activity
    gate *= active_union.astype(np.float32)
    return np.clip(gate, 0.0, 1.0)





def _should_reseed(P, cand):
    reseed_period = getattr(config, "parent_reseed_period", 0)
    if reseed_period <= 0: return False
    if (getattr(runtime_ctx, "global_step", 0) % reseed_period) != 0: return False
    def _iou(a, b, thr=1e-3):
        A = (a > thr); B = (b > thr); inter = (A & B).sum(); union = (A | B).sum()
        return float(inter) / max(1, int(union))
    return _iou(P.mask, cand, thr=1e-3) < float(getattr(config, "parent_reseed_iou", 0.30))



#=========================================================================






#INTERNAL HERE
def cheap_dt(core_bool: np.ndarray, cap_steps: int = 32) -> np.ndarray:
    H, W = core_bool.shape
    dt = np.full((H, W), np.inf, np.float32)
    front = core_bool.astype(bool); d = 0.0
    while front.any() and d < cap_steps:
        dt[front] = np.minimum(dt[front], d)
        new = (front | np.roll(front,1,0) | np.roll(front,-1,0) |
                      np.roll(front,1,1) | np.roll(front,-1,1))
        front = new & (~np.isfinite(dt)); d += 1.0
    return dt


def build_parent_mask_from_group(
    children,
    child_ids,
    A_maps,          # from compute_pairwise_agreement_maps (or blended helper)
    joint_maps,      # same keying as A_maps
    *,
    tau=0.2,         # A = exp(-KL/tau) → KL < tau ≈ A >= e^-1 threshold
    m_core=3,        # need ≥ m_core children mutually agreeing at a pixel
    A_min=200,       # min total soft area to accept the seed
    soft=True,
    smooth_iters=0,
    # --- NEW shaping knobs (optional) ---
    consensus="mean",     # 'mean' | 'geo'  (mask consensus)
    mask_power=1.0,       # raise consensus^mask_power
    agreement_power=1.0,  # raise A_mean^agreement_power
    normalize="clip",     # 'clip' | 'max' | 'q99' | 'none'
    periodic=None,        # None → read config.periodic_domain
    _eps=1e-8,
):
    """
    Build a parent seed from a group of children using *mutual agreement* and
    *mask consensus*.  Soft seed at pixel (y,x) is:

        soft(y,x) = 1_{in_core} * [ A_mean(y,x)^{agreement_power} * M_cons(y,x)^{mask_power} ]

    where:
      • in_core   : at least m_core children, each agreeing with ≥ (m_core-1) others
      • A_mean    : mean pairwise agreement over agreeing pairs at that pixel (∈[0,1])
      • M_cons    : child-mask consensus at that pixel (∈[0,1])

    Notes:
      - Agreement threshold uses A_thresh = exp(-1) so “agree” ≈ KL < tau.
      - Shapes are taken from child masks; no mutation of inputs.
      - Result is smooth but *data-shaped* (not circular), especially with smooth_iters>0.
    """
    import numpy as np
    try:
        import config
        if periodic is None:
            periodic = bool(getattr(config, "periodic_domain", True))
    except Exception:
        if periodic is None:
            periodic = True

    if not child_ids:
        return None

    # --- canvas shape ---
    H, W = np.asarray(children[child_ids[0]].mask).shape[:2]
    Cg   = len(child_ids)

    # --- accumulate pairwise agreement (only where both masks are on) ---
    A_sum = np.zeros((H, W), dtype=np.float32)    # sum over agreeing pairs
    pairN = np.zeros((H, W), dtype=np.int32)      # count of agreeing pairs
    deg   = np.zeros((Cg, H, W), dtype=np.int16)  # per-child degree at each pixel

    a_thresh = float(np.exp(-1.0))  # KL < tau  <=>  exp(-KL/tau) > e^-1

    for a in range(Cg):
        ia = child_ids[a]
        for b in range(a + 1, Cg):
            ib = child_ids[b]
            key = (ia, ib) if ia < ib else (ib, ia)
            A_ij = A_maps.get(key, None)
            J    = joint_maps.get(key, None)
            if A_ij is None or J is None:
                continue

            A_ij = np.asarray(A_ij, dtype=np.float32)
            agree = (A_ij >= a_thresh) & np.asarray(J, dtype=bool)
            if not np.any(agree):
                continue

            A_sum[agree] += A_ij[agree]
            pairN[agree] += 1
            deg[a][agree] += 1
            deg[b][agree] += 1

    # If no agreeing pairs anywhere → empty seed
    if int(pairN.sum()) == 0:
        return np.zeros((H, W), dtype=np.float32)

    # --- mutual-agreement core: pixels where ≥ m_core children have degree ≥ m_core-1 ---
    core_children = (deg >= (m_core - 1))    # (Cg,H,W) bool
    core_count    = core_children.sum(axis=0)
    in_core       = (core_count >= int(m_core))   # (H,W) bool

    # --- mean agreement over agreeing pairs ---
    A_mean = np.zeros((H, W), dtype=np.float32)
    nz = pairN > 0
    A_mean[nz] = A_sum[nz] / np.maximum(pairN[nz], 1)

    if agreement_power != 1.0:
        A_mean = np.clip(A_mean, 0.0, 1.0) ** float(agreement_power)

    # --- mask consensus over the group's children (in [0,1]) ---
    #     mean: soft average; geo: geometric mean (emphasizes unanimous support)
    m_stack = []
    for cid in child_ids:
        m = np.asarray(children[cid].mask, dtype=np.float32)
        if m.shape[:2] != (H, W):
            # if you have a local resize_nn, prefer that; this keeps it local
            m = np.array(m, copy=False).astype(np.float32)
        m_stack.append(np.clip(m, 0.0, 1.0))
    M = np.stack(m_stack, axis=0) if m_stack else np.zeros((1, H, W), np.float32)

    if consensus == "geo":
        # geometric mean: exp(mean(log(m+eps)))
        M_cons = np.exp(np.mean(np.log(np.clip(M, _eps, 1.0)), axis=0))
    else:
        # default: arithmetic mean
        M_cons = M.mean(axis=0)

    if mask_power != 1.0:
        M_cons = np.clip(M_cons, 0.0, 1.0) ** float(mask_power)

    # --- soft seed = (agreement × consensus) on the mutual-agreement core ---
    soft_mask = np.where(in_core, A_mean * M_cons, 0.0).astype(np.float32)

    # --- optional smoothing (small, edge-aware by periodic mode) ---
    if smooth_iters > 0:
        k = np.array([[1,1,1],
                      [1,2,1],
                      [1,1,1]], dtype=np.float32)
        k /= k.sum()
        for _ in range(int(smooth_iters)):
            if periodic:
                pad_mode, pad_kw = "wrap", {}
            else:
                pad_mode, pad_kw = "edge", {}
            pad = np.pad(soft_mask, 1, mode=pad_mode, **pad_kw)
            sm  = (
                k[0,0]*pad[:-2, :-2] + k[0,1]*pad[:-2,1:-1] + k[0,2]*pad[:-2,2:] +
                k[1,0]*pad[1:-1, :-2] + k[1,1]*pad[1:-1,1:-1] + k[1,2]*pad[1:-1,2:] +
                k[2,0]*pad[2:,  :-2] + k[2,1]*pad[2:, 1:-1] + k[2,2]*pad[2:,  2:]
            )
            soft_mask = sm.astype(np.float32)

    # --- normalization (keeps soft in [0,1] without forcing circles) ---
    if normalize == "max":
        m = float(soft_mask.max())
        if m > _eps:
            soft_mask = soft_mask / m
    elif normalize == "q99":
        q = float(np.quantile(soft_mask, 0.99))
        if q > _eps:
            soft_mask = np.clip(soft_mask / q, 0.0, 1.0)
    elif normalize == "clip":
        soft_mask = np.clip(soft_mask, 0.0, 1.0)
    # else 'none': leave raw

    # --- area guard (use soft mass; change to (soft_mask>thr).sum() if you prefer) ---
    if float(soft_mask.sum()) < float(A_min):
        return np.zeros((H, W), dtype=np.float32)

    return soft_mask if soft else (soft_mask > 0.5).astype(np.float32)






#used a LOT
def ensure_hw(mask, HW, *, reduce="max"):
    """
    Return a (H, W) float32 mask in [0,1].
    - Squeezes singleton axes.
    - Collapses any trailing stacks (H,W,M,...) via max or mean.
    - Resizes to (H,W) if needed (nn).
    """
    import numpy as np
    H, W = HW
    m = np.asarray(mask, np.float32)
    
    if m.size == 0 or m.ndim < 2:
    # create a blank mask
        return np.zeros((H, W), np.float32)

    # squeeze singletons
    while m.ndim > 0 and m.shape[-1] == 1:
        m = np.squeeze(m, axis=-1)
    if m.ndim == 3 and m.shape[0] == 1:
        m = np.squeeze(m, axis=0)
    # collapse stacks (H,W,M,...) -> (H,W)
    if m.ndim > 2:
        m = m.reshape(m.shape[0], m.shape[1], -1)
        if reduce == "max":
            m = m.max(axis=-1)
        elif reduce == "mean":
            m = m.mean(axis=-1)
        else:
            raise ValueError(f"reduce must be 'max' or 'mean', got {reduce}")
    
    
    # resize if needed
    if m.shape != (H, W):
        from parent_mask_utils import resize_nn  # already in your repo
        m = resize_nn(m, (H, W)).astype(np.float32)
    return np.clip(m, 0.0, 1.0)


#growth and detector
def _label4(binary_mask: np.ndarray):
    """
    4-connected component labeling.
    Returns (labels:int32[H,W], n_components:int)
    """
    H, W = binary_mask.shape
    labels = np.zeros((H, W), dtype=np.int32)
    vid = 0
    # neighbors: up, left
    for y in range(H):
        for x in range(W):
            if not binary_mask[y, x]:
                continue
            up  = labels[y-1, x] if y > 0 else 0
            left= labels[y, x-1] if x > 0 else 0
            if up == 0 and left == 0:
                vid += 1
                labels[y, x] = vid
            elif up != 0 and left == 0:
                labels[y, x] = up
            elif up == 0 and left != 0:
                labels[y, x] = left
            else:
                # merge: relabel one component to the other (path compression lite)
                a, b = (up, left) if up < left else (left, up)
                labels[y, x] = a
                if a != b:
                    labels[labels == b] = a
    # compact labels to 1..n
    uniq = np.unique(labels)
    uniq = uniq[uniq != 0]
    remap = {v:i+1 for i,v in enumerate(uniq)}
    for v, i in remap.items():
        labels[labels == v] = i
    return labels, len(uniq)


#used in growth
try:
    from scipy.ndimage import binary_dilation as _dilate, binary_erosion as _erode
    _HAS_SCIPY = True
except Exception:
    _HAS_SCIPY = False

def _ring_masks(core_bool, grow_band=1, shrink_band=1):
    """
    Build outer (growth) and inner (shrink) ring masks around a boolean core.
    Returns (outer_ring_bool, inner_ring_bool), each shape (H,W).
    """
    core_bool = np.asarray(core_bool, dtype=bool)

    if _HAS_SCIPY:
        og = core_bool.copy()
        for _ in range(max(1, int(grow_band))):
            og = _dilate(og, iterations=1, border_value=0)
        outer = og & (~core_bool)

        ig = core_bool.copy()
        for _ in range(max(1, int(shrink_band))):
            ig = _erode(ig, iterations=1, border_value=0)
        inner = core_bool & (~ig)
        return outer, inner

    # ---- NumPy fallback (4-neighborhood) ----
    def _dilate4(b):
        up    = np.pad(b[1: , : ], ((0,1),(0,0)))
        down  = np.pad(b[:-1, : ], ((1,0),(0,0)))
        left  = np.pad(b[: , 1: ], ((0,0),(0,1)))
        right = np.pad(b[: , :-1], ((0,0),(1,0)))
        return b | up | down | left | right

    def _erode4(b):
        up    = np.pad(b[1: , : ], ((0,1),(0,0)), constant_values=False)
        down  = np.pad(b[:-1, : ], ((1,0),(0,0)), constant_values=False)
        left  = np.pad(b[: , 1: ], ((0,0),(0,1)), constant_values=False)
        right = np.pad(b[: , :-1], ((0,0),(1,0)), constant_values=False)
        return b & up & down & left & right

    og = core_bool.copy()
    for _ in range(max(1, int(grow_band))):
        og = _dilate4(og)
    outer = og & (~core_bool)

    ig = core_bool.copy()
    for _ in range(max(1, int(shrink_band))):
        ig = _erode4(ig)
    inner = core_bool & (~ig)
    return outer, inner






#used for spawn
def _new_parent(pid, H, W, dtype, Kq, Kp, proposal):
    zeros3 = np.zeros((H, W, 3), dtype=dtype)
    eye_q = np.tile(np.eye(Kq, dtype=dtype), (H, W, 1, 1))
    eye_p = np.tile(np.eye(Kp, dtype=dtype), (H, W, 1, 1))
    P = Agent(
        id=pid, center=(0,0), radius=0.0, mask=np.zeros((H,W), dtype=dtype),
        mu_q_field=np.zeros((H,W,Kq), dtype=dtype), sigma_q_field=eye_q.copy(),
        mu_p_field=np.zeros((H,W,Kp), dtype=dtype), sigma_p_field=eye_p.copy(),
        phi=zeros3.copy(), phi_model=zeros3.copy(), neighbors=[]
    )
    P.level = 1
    P.birth_step = getattr(runtime_ctx, "global_step", 0)
    P.lambda_q_weight = 0.0; P.lambda_p_weight = 0.0
    P._region_proposal = np.clip(proposal, 0.0, 1.0).astype(dtype)
    P.emerged = False; P._prev_eval_mask = None
    P._emerge_on_cnt = 0; P._emerge_off_cnt = 0; P._core_map = None
    return P










#used all over....refactor suite to imp-lement automatically/consistently
def _as_parent_dict(obj):
    """
    Normalize parents -> {pid: Parent}. Accepts dict, list, iterable, or None.
    Uses the parent's .id if present; else falls back to enumerate index.
    """
    import collections.abc as _abc
    if obj is None:
        return {}
    if isinstance(obj, dict):
        return {int(getattr(p, "id", pid)): p for pid, p in obj.items()}
    if isinstance(obj, _abc.Iterable):
        return {int(getattr(p, "id", i)): p for i, p in enumerate(obj)}
    # Single parent object?
    return {int(getattr(obj, "id", 0)): obj}



#only for spawn
def _build_child_groups(region_masks, agents, HW, *, child_eps, min_child_area, intra_iou_thr, min_group_kids):
    """Return list[{'mask': bool(H,W), 'child_ids': tuple[int]}]."""
    
    H, W = HW
    groups = []
    for Rmask in region_masks:
        cmasks, cids = [], []
        for idx, C in enumerate(agents):
            M = ensure_hw(getattr(C, "mask", 0.0), (H, W)) > child_eps
            M &= Rmask
            if np.count_nonzero(M) >= min_child_area:
                cmasks.append(M); cids.append(int(getattr(C, "id", idx)))
        n = len(cmasks)
        if n == 0:
            continue
        # build adjacency by IoU
        adj = [set() for _ in range(n)]
        for i in range(n):
            for j in range(i+1, n):
                U = cmasks[i] | cmasks[j]
                if not U.any(): 
                    continue
                inter = np.count_nonzero(cmasks[i] & cmasks[j])
                iou_ij = inter / float(np.count_nonzero(U))
                if iou_ij >= intra_iou_thr:
                    adj[i].add(j); adj[j].add(i)
        # connected components
        seen = [False]*n
        for i in range(n):
            if seen[i]: continue
            q=[i]; seen[i]=True; comp=[i]
            while q:
                u=q.pop()
                for v in adj[u]:
                    if not seen[v]:
                        seen[v]=True; q.append(v); comp.append(v)
            gids=[cids[k] for k in comp]
            if len(gids) < min_group_kids:
                continue
            gmask = np.zeros((H,W), bool)
            for k in comp: gmask |= cmasks[k]
            groups.append({"mask": gmask, "child_ids": tuple(sorted(gids))})
    return groups




#only for spawn
def _find_group_peaks(groups, agents, HW, *, peak_min_cons, peak_nms_r, peak_max_per_gp, min_group_kids, child_eps, seed_halo_px):
    """Yield dicts with fields: cy,cx,score, child_ids, proposal."""
    
    H, W = HW
    out = []
    # tiny NMS helper (square radius)
    def _nms_coords(ys, xs, scores, r, max_keep):
        order = np.argsort(-scores)
        kept, out_ix = [], []
        r2 = max(1, r)**2
        for k in order:
            y, x, s = int(ys[k]), int(xs[k]), float(scores[k])
            ok = True
            for (py, px) in kept:
                if (py - y)**2 + (px - x)**2 < r2:
                    ok = False; break
            if ok:
                kept.append((y, x)); out_ix.append(k)
            if len(out_ix) >= max_keep: break
        return out_ix

    for G in groups:
        # stack kids’ masks
        stack = []
        for kid in G["child_ids"]:
            C = next((A for A in agents if int(getattr(A, "id", -1)) == int(kid)), None)
            if C is None: continue
            stack.append(ensure_hw(getattr(C, "mask", 0.0), (H, W)).astype(np.float32))
        if not stack: continue
        S = np.stack(stack, axis=-1)                        # (H,W,#kids)
        cons = S.mean(axis=-1)                              # agreement 0..1
        count = (S > child_eps).sum(axis=-1)
        cons[count < min_group_kids] = 0.0
        # restrict search to group halo
        halo = _dilate_bool(G["mask"].astype(bool), r=max(1, seed_halo_px), periodic=bool(getattr(config, "periodic_domain", False)))
        cons *= halo.astype(np.float32)
        # threshold & NMS
        keep = cons >= float(peak_min_cons)
        ys, xs = np.nonzero(keep)
        if ys.size == 0: continue
        idx = _nms_coords(ys, xs, cons[keep], peak_nms_r, peak_max_per_gp)
        for k in idx:
            cy, cx = float(ys[k]), float(xs[k])
            # small local proposal (disk clip)
            yy, xx = np.ogrid[:H, :W]
            d2 = (yy - int(round(cy)))**2 + (xx - int(round(cx)))**2
            local = (d2 <= (max(1, seed_halo_px*seed_halo_px))).astype(np.float32)
            proposal = (cons * local)
            if proposal.max() > 0: proposal /= (proposal.max() + 1e-8)
            out.append({"cy":cy, "cx":cx, "score":float(cons[int(cy),int(cx)]),
                        "child_ids": list(G["child_ids"]),
                        "proposal": proposal.astype(np.float32)})
    return out

            


#only for spawn
def _compute_core_from_kids(P, agents, H, W, eps):
    
    cover = np.zeros((H, W), np.int32); weight = np.zeros((H, W), np.float32)
    kl_sum = np.zeros((H, W), np.float32); kl_cnt = np.zeros((H, W), np.int32)
    for i in getattr(P, "child_ids", []):
        ch = agents[i]; m = np.asarray(ch.mask)
        if m.shape != (H, W): m = resize_nn(m, (H, W))
        a = child_activity_map(ch, H, W, eps=eps)
        if a is None: continue
        inside = a & (m > eps)
        cover += inside.astype(np.int32); weight += m.astype(np.float32) * inside.astype(np.float32)
        k = getattr(ch, "cached_alignment_kl", None)
        if k is None: continue
        k = np.asarray(k); 
        if k.shape != (H, W): continue
        good = inside & np.isfinite(k)
        kl_sum[good] += k[good].astype(np.float32); kl_cnt[good] += 1
    keep = (cover >= int(getattr(config, "core_min_kids", 2))) & (weight >= float(getattr(config, "core_weight_tau", 0.6)))
    kl_mean = kl_sum / np.maximum(kl_cnt, 1); kl_mean[kl_cnt == 0] = np.inf
    keep &= (kl_mean <= float(getattr(config, "core_kl_tau", getattr(config, "tau_align_emergent", 0.30))))
    # tiny erosion
    e = keep.copy()
    e = (e & np.roll(e,1,0) & np.roll(e,-1,0) & np.roll(e,1,1) & np.roll(e,-1,1))
    return e

#=======================
#
#        spawn-update parents
#
#===================

def norm_active_regions(active_regions, shape_hw):
    """
    Normalize 'active_regions' to a list of boolean masks with shape (H, W).
    Back-compat semantics: if active_regions is None, empty, or a scalar bool,
    treat it as "whole frame" (one mask of all True).
    """
    import numpy as np
    H, W = shape_hw
    full = np.ones((H, W), dtype=bool)

    # None or empty => full frame
    if active_regions is None:
        return [full]

    # Allow simple truthy/falsy sentinels (True/False, 0-d np.bool_) => full frame
    if isinstance(active_regions, (bool, np.bool_)):
        return [full]
    if isinstance(active_regions, np.ndarray) and active_regions.shape == ():
        # 0-d scalar array (np.bool_, np.int64, etc.) -> full frame
        return [full]

    # List/tuple of regions (each may be mask or scalar)
    if isinstance(active_regions, (list, tuple)):
        regs = []
        for r in active_regions:
            # scalar entries => whole frame
            if isinstance(r, (bool, np.bool_)):
                if r:  # True -> include full; False -> include full (back-compat)
                    regs.append(full.copy())
                else:
                    regs.append(full.copy())
                continue
            arr = np.asarray(r, dtype=bool)
            if arr.shape == ():
                regs.append(full.copy())
                continue
            if arr.shape != (H, W):
                raise RuntimeError(f"active region shape {arr.shape} != {(H, W)}")
            regs.append(arr)
        return regs if regs else [full]

    # Single array mask
    m = np.asarray(active_regions, dtype=bool)
    if m.shape == ():
        return [full]
    if m.shape != (H, W):
        raise RuntimeError(f"active region shape {m.shape} != {(H, W)}")
    return [m]



# ---- toroidal geometry ----------------------------------------------------
def dist2_toroidal(y1, x1, y2, x2, H, W, per_y=False, per_x=False):
    dy = abs(float(y1) - float(y2))
    dx = abs(float(x1) - float(x2))
    if per_y: dy = min(dy, H - dy)
    if per_x: dx = min(dx, W - dx)
    return dy*dy + dx*dx

def centroid_toroidal(mask_bool, H, W, per_y=False, per_x=False):
    m = np.asarray(mask_bool, bool)
    if not m.any(): return (1e9, 1e9)
    yy, xx = np.nonzero(m)
    w = np.ones_like(yy, float)
    # x
    if per_x:
        theta = 2*np.pi*(xx / float(W))
        cx = (np.arctan2(np.sum(np.sin(theta)*w), np.sum(np.cos(theta)*w)) % (2*np.pi))*(W/(2*np.pi))
    else:
        cx = float(xx.mean())
    # y
    if per_y:
        phi = 2*np.pi*(yy / float(H))
        cy = (np.arctan2(np.sum(np.sin(phi)*w), np.sum(np.cos(phi)*w)) % (2*np.pi))*(H/(2*np.pi))
    else:
        cy = float(yy.mean())
    return (float(cy), float(cx))




# ---- alignment clustering -------------------------------------------------



# ---- child-set dedup (toroidal-aware) ------------------------------------
def dedup_peaks_by_childset(peaks, *, radius_px=3, j_thr=0.92, subset_thr=0.80,
                            H=None, W=None, per_x=False, per_y=False):
    kept, r2 = [], float(radius_px * radius_px)
    for pk in sorted(peaks or [], key=lambda d: -d.get("score", 0.0)):
        C  = set(pk.get("child_ids", ()))
        cy = float(pk.get("cy", 0.0)); cx = float(pk.get("cx", 0.0))
        replace_i = None; dup = False
        for i, q in enumerate(kept):
            hy = float(q.get("cy", 0.0)); hx = float(q.get("cx", 0.0))
            d2 = dist2_toroidal(cy, cx, hy, hx, H, W, per_y, per_x) if (H is not None and W is not None) else (cy-hy)**2 + (cx-hx)**2
            if d2 > r2: continue
            D = set(q.get("child_ids", ()))
            if not C and not D: near = True
            elif not C or not D: near = False
            else:
                inter = len(C & D)
                if inter == 0: near = False
                else:
                    j = inter / float(len(C | D))
                    sub = min(inter / float(len(C)), inter / float(len(D)))
                    near = (j >= float(j_thr)) or (sub >= float(subset_thr))
            if near:
                if float(pk.get("score", 0.0)) > float(q.get("score", 0.0)) or len(C) > len(D):
                    replace_i = i
                dup = True; break
        if dup and (replace_i is not None):
            kept[replace_i] = pk
        elif not dup:
            kept.append(pk)
    return kept


def dedup_groups_by_childset(groups, *, radius_px=3, j_thr=0.92, subset_thr=0.90,
                             H=None, W=None, per_x=False, per_y=False):
    kept, r2 = [], float(radius_px * radius_px)

    def _center(mask_bool):
        m = np.asarray(mask_bool, bool)
        if not m.any(): return (1e9, 1e9)
        if H is not None and W is not None:
            cy, cx = centroid_toroidal(m, H, W, per_y, per_x)
            return (float(cy), float(cx))
        ys, xs = np.nonzero(m)
        return (float(ys.mean()), float(xs.mean()))

    for g in (groups or []):
        C = set(g.get("child_ids", ()))
        if not C: continue
        cy, cx = _center(np.asarray(g.get("mask", 0), bool))

        replaced = False
        for i, h in enumerate(kept):
            hy, hx = h["_cy"], h["_cx"]
            d2 = dist2_toroidal(cy, cx, hy, hx, H, W, per_y, per_x) if (H is not None and W is not None) else (cy-hy)**2 + (cx-hx)**2
            if d2 > r2: continue
            D = set(h["child_ids"]); inter = len(C & D)
            if inter == 0: continue
            j = inter / float(len(C | D))
            sub = max(inter / float(len(C)), inter / float(len(D)))
            if (j >= float(j_thr)) or (sub >= float(subset_thr)):
                # prefer higher score, then larger coalition, then area
                def _key(obj, coalition):
                    return (float(obj.get("score", 0.0)), len(coalition),
                            int(np.count_nonzero(np.asarray(obj.get("mask", 0)))))
                if _key(g, C) > _key(h, D):
                    kept[i] = {**g, "_cy": cy, "_cx": cx}
                replaced = True; break

        if not replaced:
            kept.append({**g, "_cy": cy, "_cx": cx})

    for k in kept:
        k.pop("_cy", None); k.pop("_cx", None)
    return kept


# ---- tiny convenience wrappers -------------------------------------------
def filter_peaks(peaks, *, min_peak_score=0.0):
    return [pk for pk in (peaks or []) if float(pk.get("score", 0.0)) >= float(min_peak_score)]

def spawn_spacing_radius(allow_overlap, default_px):
    return 0 if bool(allow_overlap) else int(default_px)


#match_or spawn utils

def iou_bool(a, b):
    import numpy as np
    A = np.asarray(a, bool); B = np.asarray(b, bool)
    inter = int((A & B).sum()); union = int((A | B).sum())
    return (inter / float(max(1, union))) if union else 0.0

def jaccard_sets(A, B):
    if not A and not B: return 1.0
    if not A or not B:  return 0.0
    return len(A & B) / float(len(A | B))

def child_union_for_ids(agents, child_ids, H, W, eps=0.10):
    import numpy as np
    from parent_utils import ensure_hw
    U = np.zeros((H, W), bool)
    for cid in child_ids:
        try: C = agents[cid]
        except Exception: continue
        U |= (ensure_hw(getattr(C, "mask", 0.0), (H, W)) > float(eps))
    return U

def proposal_overlaps_children(local_bool, child_union, min_px=6, min_frac=0.10):
    import numpy as np
    L = np.asarray(local_bool, bool); U = np.asarray(child_union, bool)
    ov = int((L & U).sum()); area = int(L.sum())
    return (ov >= int(min_px)) and (ov / float(max(1, area)) >= float(min_frac)), ov

def toroidal_seed_gaussian(local_bool, cy, cx, H, W, *, r0=4.0, sigma=1.0, per_x=False, per_y=False):
    import numpy as np
    try:
        from scipy.ndimage import gaussian_filter1d
    except Exception:
        gaussian_filter1d = None
    yy, xx = np.ogrid[:H, :W]
    dy = np.abs(yy - cy); dx = np.abs(xx - cx)
    if per_y: dy = np.minimum(dy, H - dy)
    if per_x: dx = np.minimum(dx, W - dx)
    d2 = dy*dy + dx*dx
    seed = np.exp(-0.5 * (d2 / max(1.0, float(r0) * float(r0)))).astype(np.float32)
    seed = seed * np.asarray(local_bool, np.float32)
    if gaussian_filter1d is not None:
        seed = gaussian_filter1d(seed, sigma=float(sigma), axis=0, mode=("wrap" if per_y else "nearest"))
        seed = gaussian_filter1d(seed, sigma=float(sigma), axis=1, mode=("wrap" if per_x else "nearest"))
    return seed

def append_center_from_mask(chosen_centers, mask_bool, pid, H, W, per_x, per_y, fallback=None):
    from parent_utils import centroid_toroidal
    cy, cx = centroid_toroidal(mask_bool, H, W, per_y=per_y, per_x=per_x)
    if cy < 1e8:
        chosen_centers.append((float(cy), float(cx), int(pid)))
    elif fallback is not None:
        fy, fx = fallback
        chosen_centers.append((float(fy), float(fx), int(pid)))

def respect_spawn_spacing(cy, cx, gkids_set, chosen_centers, exists_kids,
                          H, W, per_x, per_y, *, min_interseed_px, jac_thr, subset_thr):
    from parent_utils import dist2_toroidal
    R2 = float(max(1, min_interseed_px)) ** 2
    for (py, px, pid_near) in (chosen_centers or []):
        if dist2_toroidal(cy, cx, py, px, H, W, per_y, per_x) >= R2:
            continue
        kids_near = exists_kids.get(pid_near, set())
        inter = len(kids_near & gkids_set)
        if inter == 0: 
            continue
        j   = inter / float(len(kids_near | gkids_set))
        sub = max(inter / float(len(kids_near or {1})),
                  inter / float(len(gkids_set or {1})))
        if (j >= float(jac_thr)) or (sub >= float(subset_thr)):
            return False
    return True



#=================
#
#   proposal
#
#=========================



def mask_to_components(soft, *, soft_thr=0.25, min_area=12, max_per_gp=3):
    """
    Threshold a soft map, label 4-connecteds, return up to K components as
    (score, cy, cx, proposal) where 'proposal' is normalized to [0,1] on-component.
    """
    import numpy as np
    from parent_utils import _label4

    soft = np.asarray(soft, np.float32)
    comps = []
    binmap = (soft >= float(soft_thr))
    labels, nlab = _label4(binmap)

    for lbl in range(1, int(nlab) + 1):
        comp = (labels == lbl)
        area = int(comp.sum())
        if area < int(min_area):
            continue
        s = soft * comp.astype(np.float32)
        ys, xs = np.nonzero(comp)
        w = s[comp]
        if w.size == 0:
            continue
        wsum = float(w.sum())
        if wsum <= 0.0:
            continue
        cy = float((ys * w).sum() / wsum)
        cx = float((xs * w).sum() / wsum)
        score = float(w.mean())  # area-weighted mean soft agreement
        m = float(s.max())
        prop = (s / (m + 1e-8)) if m > 0.0 else s
        comps.append((score, cy, cx, prop.astype(np.float32)))

    comps.sort(key=lambda t: -t[0])
    if max_per_gp is not None:
        return comps[:int(max_per_gp)]
    return comps
