# -*- coding: utf-8 -*-
"""
Created on Thu Aug 14 09:17:47 2025

@author: chris and christine
"""

import numpy as np
import config



from parent_utils import ( _as_parent_dict,  _ensure_parent_store, _components, 
                           _too_close_by_iou,_build_child_groups, _find_group_peaks, _new_parent)
                         
from bundle_morphism_utils import (init_parent_morphisms, have_parent_morphisms, 
                                    compute_direct_morphisms  )

from agent_initialization import initialize_agent_gradients

from parent_utils import (ensure_hw, _dilate_bool, _compute_candidate_or_union, 
                          _growth_gate_from_overlap_core_activity, _should_reseed, 
                          ) 
                              
from bundle_coarsegrain_init import coarsegrain_parent_from_children, _refresh_parent_gauge_fields
from numerical_utils import resize_nn
import numpy as np, config
from parent_utils import (
    norm_active_regions,
    cluster_children_by_alignment,
    dedup_groups_by_childset,
    dedup_peaks_by_childset,
    filter_peaks,
    spawn_spacing_radius,
    ensure_hw,  # used by downstream helpers
)
# ---- deps from utils (keeps this fn small) ----------------------------
from parent_utils import (
    ensure_hw,
    iou_bool,
    jaccard_sets,
    centroid_toroidal,
    dist2_toroidal,
    child_union_for_ids,
    proposal_overlaps_children,
    toroidal_seed_gaussian,
    append_center_from_mask,
    respect_spawn_spacing, normalize_groups
)

from parent_utils import (
    mask_to_components,
    #remap_pairwise_local_to_global,
    #blend_pairwise_maps,
    build_parent_mask_from_group,   # you already have this
)

#from detector import compute_pairwise_agreement_maps




def _propose_from_alignment(groups, agents, HW, *, generators_q=None, generators_p=None):
    """
    Cache-based direct-from-alignment proposer (no pairwise Ω).
    Builds soft seeds per group from per-child agreement fields.

    Returns: list of dicts {cy, cx, score, child_ids, proposal}
    """
    import numpy as np
    from numerical_utils import resize_nn
    from parent_utils import ensure_hw, mask_to_components

    H, W = HW
    out = []

    # ---- knobs (keep your existing names) -----------------------------------
    soft_thr   = float(getattr(config, "direct_seed_soft_thr", 0.25))
    min_area   = int(getattr(config, "direct_seed_min_area_px", 12))
    max_per_gp = int(getattr(config, "direct_seed_max_per_group", 3))
    m_core     = int(getattr(config, "direct_seed_m_core", 2))   # min agreeing kids per pixel
    A_min      = int(getattr(config, "direct_seed_A_min", 20))   # min soft mass to accept
    smooth_it  = int(getattr(config, "direct_seed_smooth_iters", 1))

    # blend + agreement construction if a child lacks precomputed agreement_field
    alpha   = float(getattr(config, "blend_qp_alpha", 0.5))   # 0: model only, 1: belief only
    tau_q   = float(getattr(config, "tau_align_q", 0.30))
    tau_p   = float(getattr(config, "tau_align_p", 0.30))
    kl_cap  = float(getattr(config, "signal_kl_cap", 10.0))
    A_thr   = np.exp(-1.0 / max(1e-6, min(tau_q, tau_p)))     # “agree” ≈ KL < tau

    child_eps = float(getattr(config, "child_support_tau", 0.10))   # support gate on masks

    # helper: get per-child agreement map A ∈ [0,1] (H,W)
    def _agreement_for_child(ch):
        A = getattr(ch, "agreement_field", None)
        if A is not None and np.asarray(A).shape == (H, W):
            return np.clip(np.asarray(A, np.float32), 0.0, 1.0)

        # build from cached KLs if needed
        Aq = getattr(ch, "cached_alignment_kl", None)
        Ap = getattr(ch, "cached_model_alignment_kl", None)
        Ar = None
        if Aq is not None:
            k = np.asarray(Aq, np.float32)
            if k.shape != (H, W): k = resize_nn(k, (H, W)).astype(np.float32)
            Ar = np.exp(-np.clip(k, 0.0, kl_cap) / max(1e-6, tau_q)).astype(np.float32)
        if Ap is not None:
            k = np.asarray(Ap, np.float32)
            if k.shape != (H, W): k = resize_nn(k, (H, W)).astype(np.float32)
            ApA = np.exp(-np.clip(k, 0.0, kl_cap) / max(1e-6, tau_p)).astype(np.float32)
            Ar = ApA if Ar is None else (alpha * Ar + (1.0 - alpha) * ApA)
        if Ar is None:
            # last resort: use mask>eps (featureless agreement)
            m = ensure_hw(getattr(ch, "mask", 0.0), (H, W)).astype(np.float32)
            return (m > child_eps).astype(np.float32)
        return np.clip(Ar, 0.0, 1.0)

    # preindex agents by id
    agents_by_id = {int(getattr(a, "id", i)): a for i, a in enumerate(agents)}

    for G in (groups or []):
        # accept either {"child_ids": ...} or {"kids": ...}
        cids = tuple(sorted(G.get("child_ids") or G.get("kids") or ()))
        if not cids:
            continue

        # Region mask if provided on the group; else all-true
        Rmask = np.ones((H, W), np.bool_)
        if "mask" in G and G["mask"] is not None:
            Rmask = ensure_hw(G["mask"], (H, W)).astype(np.float32) > 0.5

        # collect per-child maps
        A_stack = []
        M_stack = []
        valid_ids = []
        for gid in cids:
            ch = agents_by_id.get(int(gid))
            if ch is None: 
                continue
            A = _agreement_for_child(ch)                     # [0,1]
            M = ensure_hw(getattr(ch, "mask", 0.0), (H, W))  # [0,1] or bool
            M = (np.asarray(M, np.float32) > child_eps) & Rmask
            if not M.any():
                continue
            A_stack.append(A)
            M_stack.append(M.astype(np.bool_))
            valid_ids.append(int(gid))

        if not A_stack:
            continue

        A_stack = np.stack(A_stack, axis=0)          # (Cg,H,W)
        M_stack = np.stack(M_stack, axis=0)          # (Cg,H,W)
        Cg = A_stack.shape[0]

        # “agreeing child” at a pixel: A>=A_thr and in support
        agree = (A_stack >= float(A_thr)) & M_stack  # (Cg,H,W)
        deg   = agree.sum(axis=0)                    # (H,W) how many kids agree here
        in_core = (deg >= int(m_core)) & Rmask      # mutual core gate

        # consensus of supports & mean agreement over kids (not pairs)
        # mean over kids with support; zeros outside
        with np.errstate(invalid="ignore", divide="ignore"):
            M_cons = M_stack.mean(axis=0).astype(np.float32)        # [0,1]
            # mean agreement *on supported pixels*; else 0
            denom = np.maximum(M_stack.sum(axis=0), 1)
            A_mean = ( (A_stack * M_stack).sum(axis=0) / denom ).astype(np.float32)

        # soft seed
        soft = np.zeros((H, W), np.float32)
        S = (A_mean * M_cons)
        soft[in_core] = S[in_core]

        # optional smoothing (tiny 3x3 gaussian-like)
        if int(smooth_it) > 0 and soft.any():
            k = np.array([[1,2,1],[2,4,2],[1,2,1]], dtype=np.float32); k /= k.sum()
            periodic = bool(getattr(config, "periodic_domain", True))
            for _ in range(int(smooth_it)):
                if periodic:
                    pad = np.pad(soft, 1, mode="wrap")
                else:
                    pad = np.pad(soft, 1, mode="edge")
                soft = (
                    k[0,0]*pad[:-2, :-2] + k[0,1]*pad[:-2,1:-1] + k[0,2]*pad[:-2,2:] +
                    k[1,0]*pad[1:-1, :-2] + k[1,1]*pad[1:-1,1:-1] + k[1,2]*pad[1:-1,2:] +
                    k[2,0]*pad[2:,  :-2] + k[2,1]*pad[2:, 1:-1] + k[2,2]*pad[2:,  2:]
                ).astype(np.float32)

        # reject tiny/weak proposals
        if float(soft.sum()) < float(A_min):
            continue

        # components → peaks (same contract as before)
        for score, cy, cx, prop in mask_to_components(
            soft, soft_thr=soft_thr, min_area=min_area, max_per_gp=max_per_gp
        ):
            out.append({
                "cy": float(cy),
                "cx": float(cx),
                "score": float(score),
                "child_ids": tuple(valid_ids),     # sorted already by construction
                "proposal": np.asarray(prop, np.float32),
            })

    return out























def _match_or_spawn(peaks, parents_by_id, next_parent_id, agents, shape_info, generators, *,
                    match_iou_thr, child_jac_thr, support_tau, max_new_per_step, min_interseed_px):
    """Update/Spawn parents from proposals.
       1) Try to MATCH existing parents (IoU + child-set Jaccard, with close-range override)
       2) Else SPAWN (toroidal spacing + child-set aware)
       Uses toroidal centers, seed shaping, and coalition-overlap guard.
    """
    
    # runtime & shapes
    try:
        _RC = globals().get("runtime_ctx", None)
        step_now = int(getattr(_RC, "global_step", 0))
    except Exception:
        step_now = 0

    H, W, dtype, Kq, Kp = shape_info
    Gq, Gp = generators
    per_x = bool(getattr(config, "periodic_x", False))
    per_y = bool(getattr(config, "periodic_y", False))

    # cache existing state
    exists_support = {pid: (ensure_hw(getattr(P, "mask", 0.0), (H, W)) > support_tau)
                      for pid, P in parents_by_id.items()}
    exists_kids    = {pid: set(getattr(P, "child_ids", []))
                      for pid, P in parents_by_id.items()}

    # toroidal centers for spacing
    chosen_centers = []
    for pid, supp in exists_support.items():
        append_center_from_mask(chosen_centers, supp, pid, H, W, per_x, per_y)

    # tunables (already in config)
    local_tau   = float(getattr(config, "parent_proposal_local_tau", 0.10))
    min_seed_px = int(getattr(config, "parent_min_seed_area_px", 6))
    seed_amp    = float(getattr(config, "parent_seed_amp", 0.55))
    seed_sigma  = float(getattr(config, "parent_seed_feather_sigma", 1.0))
    seed_r0     = float(getattr(config, "parent_seed_radius_px", 4.0))
    use_prop_dbg= bool(getattr(config, "debug_seed_use_proposal", False))

    # counters
    updated = spawned = dropped_local = dropped_spacing = dropped_budget = 0
    dropped_childov = 0

    # iterate proposals
    new_spawned = 0
    for peak in sorted(peaks or [], key=lambda d: -d.get("score", 0.0)):
        if new_spawned >= max_new_per_step:
            dropped_budget += 1
            break

        cy, cx = float(peak["cy"]), float(peak["cx"])
        prop   = np.asarray(peak["proposal"], np.float32)
        local_bool = (prop > local_tau)
        area = int(local_bool.sum())
        if area < min_seed_px:
            dropped_local += 1
            continue

        gkids = set(peak.get("child_ids", ()))

        # coalition-overlap guard
        child_union = child_union_for_ids(agents, gkids, H, W,
                                          eps=float(getattr(config, "child_support_tau", 0.10)))
        ok_ovlp, _ovpx = proposal_overlaps_children(
            local_bool, child_union,
            min_px=int(getattr(config, "parent_min_seed_child_overlap_px", 6)),
            min_frac=float(getattr(config, "parent_min_seed_child_overlap_frac", 0.10)),
        )
        if not ok_ovlp:
            dropped_childov += 1
            continue

        # 1) MATCH existing parent (spacing does not apply)
        best_pid, best_sc = None, (-1.0, -1.0)
        R2 = float(max(1, min_interseed_px)) ** 2
        for pid, supp in exists_support.items():
            # close in torus?
            py, px = centroid_toroidal(supp, H, W, per_y=per_y, per_x=per_x)
            close  = (dist2_toroidal(cy, cx, py, px, H, W, per_y, per_x) <= R2)

            jac = jaccard_sets(gkids, exists_kids[pid])
            iou = iou_bool(local_bool, supp)

            # close-range override for newborns or tiny IoU
            if close and (jac >= float(child_jac_thr)):
                sc = (iou, jac + 1.0)  # tie-break toward close child-set matches
            elif (iou >= float(match_iou_thr)) and (jac >= float(child_jac_thr)):
                sc = (iou, jac)
            else:
                continue

            if sc > best_sc:
                best_sc, best_pid = sc, pid

        if best_pid is not None:
            P = parents_by_id[int(best_pid)]
            P.child_ids = list(gkids)
            P._region_proposal = prop
            setattr(P, "_force_reseed_once", True)
            updated += 1
            append_center_from_mask(chosen_centers, local_bool, best_pid, H, W, per_x, per_y,
                                    fallback=(cy, cx))
            continue

        # 2) SPAWN (apply toroidal, child-set aware spacing)
        if not respect_spawn_spacing(
            cy, cx, gkids, chosen_centers, exists_kids,
            H, W, per_x, per_y,
            min_interseed_px=min_interseed_px,
            jac_thr=float(getattr(config, "spacing_child_jaccard_thr", 0.90)),
            subset_thr=float(getattr(config, "spacing_child_subset_thr", 0.90)),
        ):
            dropped_spacing += 1
            continue

        pid = int(next_parent_id); next_parent_id += 1
        # template/init
        try:
            from parent_spawn import _make_parent_template
        except Exception:
            from parent_utils import _make_parent_template
        P = _make_parent_template(_RC, agents[0], pid=pid, H=H, W=W, Kq=Kq, Kp=Kp,
                                  generators_q=Gq, generators_p=Gp)
        P.child_ids = list(gkids)
        P._region_proposal = prop

        # seed
        if use_prop_dbg:
            seed = prop.copy()
        else:
            seed = toroidal_seed_gaussian(local_bool, cy, cx, H, W,
                                          r0=seed_r0, sigma=seed_sigma,
                                          per_x=per_x, per_y=per_y)
        m = float(seed.max())
        if m > 0.0:
            seed = (seed / (m + 1e-8)).astype(np.float32)
        P.mask = np.clip(seed_amp * seed, 0.0, 1.0).astype(dtype)

        # born
        P.birth_step = step_now
        P._age = 0
        P._grace = int(getattr(config, "parent_freeze_steps", 0))

        parents_by_id[pid]  = P
        exists_support[pid] = (P.mask > support_tau)
        exists_kids[pid]    = set(P.child_ids)
        spawned += 1; new_spawned += 1

        append_center_from_mask(chosen_centers, local_bool, pid, H, W, per_x, per_y,
                                fallback=(cy, cx))

    print(f"[SPAWN] updated={updated} spawned={spawned} "
          f"d_local={dropped_local} d_space={dropped_spacing} "
          f"d_childov={dropped_childov} d_budget={dropped_budget}")
    return next_parent_id







def _apply_spawn_from_regions(ctx, active_regions, agents, Gq, Gp, params):
    """
    The ONLY place that mutates parents:
      - spawn/update parents for active regions
      - coarse-grain new/updated parents
     
    No preprocess(), no build_all_omega_caches(), no build_all_lambda_caches() here.
    """
    
    # if _as_parent_dict lives elsewhere, import from there; otherwise keep your local helper
    # from detector import _as_parent_dict

    H, W = np.asarray(agents[0].mask).shape[:2]

    # 1) spawn/update from detector-active regions
    parents_list, next_pid = spawn_or_update_parents(
        active_regions=active_regions,
        agents=agents,
        parents_by_id=ctx.parents_by_region,
        next_parent_id=ctx.next_parent_id,
        field_generators=(Gq, Gp),
    )
    parents = _as_parent_dict(parents_list)

    # normalize & insert; coarsegrain immediately so masks/Σ are usable
    existing = ctx.parents_by_region
    prev_ids = set(existing.keys())

    for pid, P in parents.items():
        pid = int(getattr(P, "id", pid))
        existing[pid] = P
        if not hasattr(P, "_age"):   P._age = 0
        if not hasattr(P, "_grace"): P._grace = int(getattr(config, "parent_freeze_steps", 0))
        try:
            cg_eps = float(getattr(config, "cg_eps", 1e-6))
            cg_tau = float(getattr(config, "parent_cover_support_eps", 0.30))
            coarsegrain_parent_from_children(P, agents, eps=cg_eps, mask_tau=cg_tau)
            if bool(getattr(config, "debug_strict", True)):
                for name in ("sigma_q_field", "sigma_p_field"):
                    S = getattr(P, name, None)
                    if S is None:
                        continue
                    S = np.asarray(S)
                    assert S.ndim == 4 and S.shape[-1] == S.shape[-2], \
                        f"[CG->ASSIGN] {name} bad shape {S.shape} for parent {getattr(P,'id','?')}"
        except Exception as e:
            print(f"[WARN] coarsegrain/init failed for parent {getattr(P,'id','?')}: {e}")
            if getattr(config, "debug_parent_masks", False):
                print("  parent.mask", np.asarray(P.mask).shape)
                print("  child0.mask", np.asarray(agents[0].mask).shape)

    # registry bookkeeping
    ctx.parents_by_region = existing
    ctx.next_parent_id = max(
        int(ctx.next_parent_id),
        int(next_pid),
        (max(existing.keys()) + 1) if existing else 1
    )

    # --- visibility: log new parents from detector phase
    new_ids = sorted(set(existing.keys()) - prev_ids)
    if new_ids:
        areas = [int((np.asarray(existing[i].mask) > 0.5).sum()) for i in new_ids]
        print(f"[SPAWN] +{len(new_ids)} (detector): ids={new_ids} areas={areas}")

    


# --- parent_spawn.py -------------------------------------------------------
def spawn_or_update_parents(active_regions, agents, parents_by_id, next_parent_id, *, field_generators):
    """
    0) normalize inputs
    1) group children (alignment-based, per region)
    2) build proposals (direct-from-alignment or legacy)
    3) match proposals to existing parents, else spawn (spacing child-set aware)
    4) ensure morphisms + optional reseed
    Returns (list(parents_by_id.values()), next_parent_id)
    """
    

    # shape + flags
    H, W = np.asarray(agents[0].mask).shape[:2]
    dtype = agents[0].mu_q_field.dtype
    Kq   = int(agents[0].mu_q_field.shape[-1])
    Kp   = int(agents[0].mu_p_field.shape[-1])
    per_x = bool(getattr(config, "periodic_x", False))
    per_y = bool(getattr(config, "periodic_y", False))

    Gq, Gp = field_generators
    if not agents:
        return list(parents_by_id.values()), next_parent_id

    # 0) normalize regions
    region_masks = norm_active_regions(active_regions, (H, W))

    # 1) groups (alignment) or legacy fallback
    use_align = bool(getattr(config, "use_alignment_clusters", True))
    if use_align:
        groups = cluster_children_by_alignment(
            region_masks, agents, H, W,
            Gq=Gq, Gp=Gp,
            child_eps=float(getattr(config, "child_support_tau", 0.10)),
            min_child_area=int(getattr(config, "min_child_area_px", 6)),
            thr_align=float(getattr(config, "cluster_align_thr", 0.60)),
            min_cluster_kids=int(getattr(config, "cluster_min_kids", 1)),
        )
    else:
        # keep your existing IoU-based fallback
        
        groups = _build_child_groups(
            region_masks, agents, (H, W),
            child_eps=float(getattr(config, "child_support_tau", 0.10)),
            min_child_area=int(getattr(config, "min_child_area_px", 6)),
            intra_iou_thr=float(getattr(config, "child_intragroup_iou_thr", 0.55)),
            min_group_kids=int(getattr(config, "parent_grow_min_kids", 2)),
        )

    # --- NEW: normalize + telemetry (pre-dedup) -----------------------------
    groups = normalize_groups(groups, H, W)
    print(f"[SPAWN] region_masks={len(region_masks) if hasattr(region_masks,'__len__') else '1?'} groups_pre={len(groups)}")


    # spatial + child-set dedup (toroidal-aware)
    groups = dedup_groups_by_childset(
        groups,
        radius_px=int(getattr(config, "parent_group_dedup_radius_px", 3)),
        j_thr=float(getattr(config, "parent_group_dedup_child_jaccard", 0.92)),
        subset_thr=float(getattr(config, "parent_group_dedup_subset_thr", 0.90)),
        H=H, W=W, per_x=per_x, per_y=per_y,
    )

    # 2) proposals
    if bool(getattr(config, "spawn_direct_from_alignment", True)):
        # prefer the alignment-driven proposer you already have
        peaks = _propose_from_alignment(groups, agents, (H, W), generators_q=Gq, generators_p=Gp)
        peaks = filter_peaks(peaks, min_peak_score=float(getattr(config, "parent_min_peak_score", 0.0)))
    else:
        
        peaks = _find_group_peaks(
            groups, agents, (H, W),
            peak_min_cons=float(getattr(config, "parent_peak_min_consensus", 0.1)),
            peak_nms_r=int(getattr(config, "parent_peak_nms_px", 5)),
            peak_max_per_gp=int(getattr(config, "parent_peak_max_per_group", 3)),
            min_group_kids=int(getattr(config, "seed_min_kids", 2)),
            child_eps=float(getattr(config, "child_support_tau", 0.10)),
            seed_halo_px=int(getattr(config, "parent_seed_exclusion_px", 3)),
        )

    # spatial + child-set dedup on peaks (toroidal-aware)
    peaks = dedup_peaks_by_childset(
        peaks or [],
        radius_px=int(getattr(config, "parent_peak_dedup_radius_px", 3)),
        j_thr=float(getattr(config, "parent_peak_dedup_child_jaccard", 0.92)),
        subset_thr=float(getattr(config, "parent_peak_dedup_subset_thr", 0.90)),
        H=H, W=W, per_x=per_x, per_y=per_y,
    )

    # Short-circuit: nothing to do (but keep existing parents alive)
    if not peaks and not parents_by_id:
        return list(parents_by_id.values()), next_parent_id

    # 3) match or spawn (toroidal-aware logic lives inside _match_or_spawn)
    allow_overlap = bool(getattr(config, "parent_allow_overlap", True))
    min_interseed_px = spawn_spacing_radius(allow_overlap, int(getattr(config, "parent_min_interseed_px", 1)))

    
    next_parent_id = _match_or_spawn(
        peaks, parents_by_id, next_parent_id, agents, (H, W, dtype, Kq, Kp), (Gq, Gp),
        match_iou_thr=float(getattr(config, "parent_match_iou_existing", 0.10)),
        child_jac_thr=float(getattr(config, "parent_match_child_jaccard_thr", 0.85)),
        support_tau=float(getattr(config, "parent_support_tau", 0.08)),
        max_new_per_step=int(getattr(config, "parent_max_new_per_step", 50)),
        min_interseed_px=min_interseed_px,
    )

    # 4) ensure morphisms
    parents_list = list(parents_by_id.values())
    for P in parents_list:
        if not have_parent_morphisms(P):
            init_parent_morphisms(P, generators_q=Gq, generators_p=Gp)

    # 5) one-shot reseed (has guard in your reseed fn)
    _apply_one_shot_reseed(
        parents_list, dtype,
        seed_amp=float(getattr(config, "parent_seed_amp", 0.55)),
    )

    # finalize caches
    _refresh_parent_gauge_fields(parents_list, agents, dtype=None)
    for P in parents_list:
        P._exp_phi = P._exp_neg_phi = None
        P._exp_phi_model = P._exp_neg_phi_model = None

    return list(parents_by_id.values()), next_parent_id























def _make_parent_template(ctx, tmpl, *, pid: int, H: int, W: int, Kq: int, Kp: int,
                          generators_q, generators_p):
    """Construct a brand-new level-1 parent with safe defaults and gradient buffers."""
    import numpy as np

    AgentCls = tmpl.__class__
    dtype = tmpl.mu_q_field.dtype

    # identities, broadcasted (lighter than tile) but materialized via copy
    eye_q = np.broadcast_to(np.eye(Kq, dtype=dtype), (H, W, Kq, Kq)).copy()
    eye_p = np.broadcast_to(np.eye(Kp, dtype=dtype), (H, W, Kp, Kp)).copy()

    P = AgentCls(
        id=pid, center=(0, 0), radius=0.0,
        mask=np.zeros((H, W), np.float32),
        mu_q_field=np.zeros((H, W, Kq), dtype=dtype), sigma_q_field=eye_q,
        mu_p_field=np.zeros((H, W, Kp), dtype=dtype), sigma_p_field=eye_p,
        phi=np.zeros((H, W, 3), dtype=dtype), phi_model=np.zeros((H, W, 3), dtype=dtype),
        neighbors=[]
    )

    P.level = 1
    P.emerged = True
    P._age = 0
    P._grace = int(getattr(config, "parent_grace_steps", 2))
    P._shrink_strikes = 0
    P.Omega_cache = {}; P.Omega_tilde_cache = {}
    P._exp_phi = P._exp_neg_phi = None
    P._exp_phi_model = P._exp_neg_phi_model = None
    P.generators_q = generators_q
    P.generators_p = generators_p

    # Base morphisms
    P.Phi_0       = np.eye(Kp, Kq, dtype=dtype)
    P.Phi_tilde_0 = np.eye(Kq, Kp, dtype=dtype)
    try:
        P.bundle_morphism_q_to_p, P.bundle_morphism_p_to_q = compute_direct_morphisms(
            phi=P.phi, phi_model=P.phi_model,
            generators_q=P.generators_q, generators_p=P.generators_p,
            Phi_0=P.Phi_0, Phi_tilde_0=P.Phi_tilde_0,
        )
    except Exception:
        P.bundle_morphism_q_to_p = np.broadcast_to(P.Phi_0, (H, W, Kp, Kq)).copy()
        P.bundle_morphism_p_to_q = np.broadcast_to(P.Phi_tilde_0, (H, W, Kq, Kp)).copy()

    # Initialize gradient buffers
    initialize_agent_gradients(P)
    
    # --- Guardrails: enforce 4D shapes + SPD once at birth ------------------
    def _spd_tidy(S):
        if S is None: return None
        S = 0.5*(S + np.swapaxes(S, -1, -2))
        K = S.shape[-1]
        return S + (1e-8 * np.eye(K, dtype=S.dtype))
    assert P.sigma_q_field.ndim == 4 and P.sigma_q_field.shape[-1] == P.sigma_q_field.shape[-2], \
        f"sigma_q_field bad shape {P.sigma_q_field.shape}"
    assert P.sigma_p_field.ndim == 4 and P.sigma_p_field.shape[-1] == P.sigma_p_field.shape[-2], \
        f"sigma_p_field bad shape {P.sigma_p_field.shape}"
    P.sigma_q_field = _spd_tidy(P.sigma_q_field)
    P.sigma_p_field = _spd_tidy(P.sigma_p_field)

    P.birth_step = int(getattr(ctx, "global_step", 0))
    return P

















def _ensure_parents_for_regions(active_regions, parents_by_id, next_parent_id, H, W, dtype, Kq, Kp):
    """
    Match current regions to existing parents by IoU. Reuse on good match; else spawn new.
    Returns (rid_to_pid, next_parent_id).
    """
    iou_thr = float(getattr(config, "parent_reuse_iou_min",
                            getattr(config, "parent_reseed_iou", 0.30)))

    if isinstance(active_regions, list):
        # fabricate IDs (0..N-1) if it’s a plain list
        active_regions = {i: R for i, R in enumerate(active_regions)}

    # cache masks
    reg_items = [(rid, np.asarray(R.mask, dtype=bool)) for rid, R in active_regions.items()]
    par_items = [(pid,
                  np.asarray((P._region_proposal if getattr(P, "_region_proposal", None) is not None else P.mask)) > 1e-3)
                 for pid, P in parents_by_id.items()]

    def _iou(A, B):
        inter = np.count_nonzero(A & B)
        if inter == 0: return 0.0
        unio  = np.count_nonzero(A | B)
        return float(inter) / float(unio) if unio else 0.0

    taken_parents = set()
    new_map = {}      # parent_id -> parent
    rid_to_pid = {}   # region id -> parent id

    for rid, Rmask in reg_items:
        best_pid, best_iou = None, 0.0
        for pid, Pmask in par_items:
            if pid in taken_parents:
                continue
            iou = _iou(Rmask, Pmask)
            if iou > best_iou:
                best_iou, best_pid = iou, pid

        if best_pid is not None and best_iou >= iou_thr:
            # reuse
            P = parents_by_id[best_pid]
            P._region_proposal = Rmask.astype(dtype)
            new_map[best_pid] = P
            rid_to_pid[rid] = best_pid
            taken_parents.add(best_pid)
        else:
            # spawn new
            Pnew = _new_parent(next_parent_id, H, W, dtype, Kq, Kp, Rmask.astype(dtype))
            new_map[next_parent_id] = Pnew
            rid_to_pid[rid] = next_parent_id
            next_parent_id += 1

    parents_by_id.clear()
    parents_by_id.update(new_map)
    return rid_to_pid, next_parent_id





def _apply_one_shot_reseed(parents, dtype, *, seed_amp):
    """If a parent was marked for rehome, blend its mask to the proposal once."""
    for P in parents:
        if getattr(P, "_force_reseed_once", False):
            P._force_reseed_once = False
            pm = np.asarray(getattr(P, "mask", 0.0), np.float32)
            prop = np.asarray(getattr(P, "_region_proposal", pm*0), np.float32)
            if prop.max() > 0: prop = prop / (prop.max() + 1e-8)
            P.mask = np.clip(seed_amp * prop, 0.0, 1.0).astype(dtype)
            




# --- helpers -----------------------------------------------------------------


