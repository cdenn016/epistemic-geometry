
import numpy as np

from core.numerical_utils import safe_inv, sanitize_sigma, safe_omega_inv

from transport.transport_cache import E_grid, Jinv_grid, Omega, build_dexpinv_matrix 
import core.config as config
from core.omega import d_exp_phi_exact, d_exp_phi_tilde_exact
from core.omega import exp_lie_algebra_irrep

from updates.update_helpers import (_weights, _fiber_keys, _exact_align_transport, reg_weights, 
                                    which_and_gens, mask_to_vec, jinv_for_field, cov_param_to_body )
#==============================================================================
#
#                    GATHER PHI GAUGE FIELD GRADIENT TERMS
#                          Beliefs and Models
#==============================================================================



def accumulate_phi_alignment_gradient(
    agent_i, agent_j, generators, params,
    field="phi", beta_key=None, omega_cache_key=None,
    mu_key=None, sigma_key=None,
    fisher_inv_key=None, grad_key=None,
    Q_all_i=None,           # list/array (d, ..., K, K)
    exp_neg_phi_j=None,     # (..., K, K)
    agents=None,            # for Fisher regularizer
    *,
    strict_numerics: bool = True,
    recover: str | None = None,
):
    """
    Same-level φ/φ̃ alignment gradient (∂ KL_{i←j} / ∂φ_i):
      - projects param-covector → body-covector with Jinv^T, applies Fisher^{-1} in body,
        adds Lie-natural regularizers (already body/natural), then maps back by Jinv.
      - uses a single beta per fiber: beta (phi) or beta_model (phi_model).
      - reuses shared helpers: _weights, _fiber_keys, _exact_align_transport.
    """
    assert mu_key and sigma_key and fisher_inv_key and grad_key, \
        "mu_key/sigma_key/fisher_inv_key/grad_key are required"

    ctx = params.get("runtime_ctx", None) or params.get("ctx", None)
    PRINT_SIGN = bool(params.get("DEBUG_PHI_SIGN", False))
    eps_num = float(getattr(config, "eps", 1e-6))

    # fiber selection from field
    which, _, _ = (_fiber_keys("belief") if field == "phi" else _fiber_keys("model"))
    # weights: (alpha, beta_like, lambda). We only need beta_like here.
    _, beta_like_default, _ = _weights("belief" if field == "phi" else "model", params)

    # optional override via beta_key, otherwise use per-fiber default
    if beta_key is not None:
        if beta_key in params:
            beta = float(params[beta_key])
        elif hasattr(config, beta_key):
            beta = float(getattr(config, beta_key))
        else:
            beta = beta_like_default
    else:
        beta = beta_like_default

    
    # joint support mask
    tau = float(getattr(ctx, "support_tau",
             getattr(config, "support_tau",
             getattr(config, "support_cutoff_eps", 1e-6))))
    Mi = (np.asarray(getattr(agent_i, "mask"), np.float32) > tau)
    Mj = (np.asarray(getattr(agent_j, "mask"), np.float32) > tau)
    joint_mask = (Mi & Mj)[..., None].astype(np.float32)
    if not np.any(joint_mask):
        return

    # fields
    mu_i    = np.asarray(getattr(agent_i, mu_key),    np.float32)
    sigma_i = np.asarray(getattr(agent_i, sigma_key), np.float32)
    mu_j    = np.asarray(getattr(agent_j, mu_key),    np.float32)

    # transports (prefer cache via ctx)
    if ctx is not None:
        E_i      = E_grid(ctx, agent_i, which=which)
        E_j      = E_grid(ctx, agent_j, which=which)
        Omega_ij = Omega(ctx, agent_i, agent_j, which=which)
    else:
        phi_i_loc = np.asarray(getattr(agent_i, field), np.float32)
        phi_j_loc = np.asarray(getattr(agent_j, field), np.float32)
        E_i      = exp_lie_algebra_irrep(phi_i_loc, generators)
        E_j      = exp_lie_algebra_irrep(phi_j_loc, generators)
        Omega_ij = np.matmul(E_i, safe_omega_inv(E_j, eps=eps_num))
    #Omega_T = np.swapaxes(Omega_ij, -1, -2)

    # push μ_j and Σ_j^{-1} (robust exact align transport via helper)
    inv_key = sigma_key.replace("_field", "_inv")
    sigma_j_inv = getattr(agent_j, inv_key, None)

    if sigma_j_inv is not None and np.asarray(sigma_j_inv).size > 0 and np.all(np.isfinite(sigma_j_inv)):
        # try inverse push; fall back if ill-conditioned
        Oinv   = safe_omega_inv(Omega_ij, eps=eps_num)
        Oinv_T = np.swapaxes(Oinv, -1, -2)
        sigma_j_t_inv = np.einsum("...ik,...kl,...jl->...ij",
                                  Oinv_T, np.asarray(sigma_j_inv, np.float32), Oinv, optimize=True)
        ok = np.all(np.isfinite(sigma_j_t_inv)) and (
            np.max(np.abs(sigma_j_t_inv)) <= float(params.get(
                "inverse_push_max_norm", getattr(config, "inverse_push_max_norm", 1e4)))
        )
        if ok:
            mu_j_t = np.einsum("...ij,...j->...i", Omega_ij, mu_j, optimize=True)
        else:
            # fall back to forward push then invert
            sigma_j   = sanitize_sigma(np.asarray(getattr(agent_j, sigma_key), np.float32), eps=eps_num)
            mu_j_t, S_j_t, _ = _exact_align_transport(mu_j, sigma_j, Omega_ij, eps=eps_num)
            sigma_j_t_inv = safe_inv(S_j_t, eps=eps_num)
    else:
        sigma_j   = sanitize_sigma(np.asarray(getattr(agent_j, sigma_key), np.float32), eps=eps_num)
        mu_j_t, S_j_t, _ = _exact_align_transport(mu_j, sigma_j, Omega_ij, eps=eps_num)
        sigma_j_t_inv = safe_inv(S_j_t, eps=eps_num)

    # Jacobians / dexp (reuse cached grids if available; otherwise exact builders)
    if Q_all_i is None:
        phi_i_loc = np.asarray(getattr(agent_i, field), np.float32)
        Q_all_i = (d_exp_phi_exact(phi_i_loc, generators)
                   if field == "phi"
                   else d_exp_phi_tilde_exact(phi_i_loc, generators))
    if exp_neg_phi_j is None:
        exp_neg_phi_j = safe_omega_inv(E_j, eps=eps_num)

    # raw parameter-covector gradient
    grad_param = grad_kl_wrt_phi_i(
        mu_i, sigma_i,
        None, None,
        phi_i=np.asarray(getattr(agent_i, field), np.float32),
        phi_j=None,
        Omega_ij=Omega_ij,
        generators=generators,
        exp_phi_i=E_i,
        exp_phi_j=E_j,
        mu_j_t=mu_j_t,
        sigma_j_t_inv=sigma_j_t_inv,
        eps=eps_num,
        exp_neg_phi_j=exp_neg_phi_j,
        Q_all=Q_all_i,
    ).astype(np.float32, copy=False)

    if not np.all(np.isfinite(grad_param)):
        raise FloatingPointError("accumulate_phi_alignment_gradient: nonfinite grad_param.")

    # Jinv^T: parameter covector -> body covector
    Jinv = Jinv_grid(ctx, agent_i, which=which) if ctx is not None else None
    if Jinv is None:
        Jinv = build_dexpinv_matrix(np.asarray(getattr(agent_i, field), np.float32))
    g_body_cov = np.einsum("...ji,...j->...i", Jinv, grad_param, optimize=True)

    if not np.all(np.isfinite(g_body_cov)):
        raise FloatingPointError("accumulate_phi_alignment_gradient: nonfinite g_body_cov.")

    # Fisher^{-1} in body (supports full, diag, or scalar per-pixel)
    v_body = g_body_cov
    F_inv = getattr(agent_i, fisher_inv_key, None)
    if F_inv is not None:
        Fi = np.asarray(F_inv, np.float32)
        if np.all(np.isfinite(Fi)) and Fi.size > 0:
            fisher_max_norm = float(params.get("fisher_max_norm",
                                               getattr(config, "fisher_max_norm", 1e3)))
            Finf = float(np.max(np.abs(Fi)))
            if np.isfinite(Finf) and Finf > fisher_max_norm:
                Fi = Fi * (fisher_max_norm / (Finf + 1e-12))
            d = int(g_body_cov.shape[-1])
            if Fi.ndim >= 2 and Fi.shape[-2:] == (d, d):
                v_body = np.einsum("...ab,...b->...a", Fi, g_body_cov, optimize=True)
            elif Fi.shape[-1:] == (d,):
                v_body = g_body_cov * Fi
            elif Fi.ndim == g_body_cov.ndim - 1:
                v_body = g_body_cov * Fi[..., None]

    # Lie-natural regularizers (already body/natural)
    reg_nat = apply_regularization_terms_lie_natural(
        agent=agent_i,
        phi_field=np.asarray(getattr(agent_i, field), np.float32),
        generators=generators,
        field=field,
        params={**params, "step_tag": getattr(ctx, "global_step", None) if ctx is not None else None},
        agents=agents,
        ctx=ctx,
    )
   # print(f"[REG-NAT] shape={reg_nat.shape} "
   #   f"mean={float(np.nanmean(reg_nat)):.3e}", flush=True)
    
    reg_nat = np.asarray(reg_nat, np.float32)
    if reg_nat.ndim == v_body.ndim - 1:   # broadcast last dim if needed
        reg_nat = reg_nat[..., None]
    elif reg_nat.shape[-1:] not in [(1,), (v_body.shape[-1],)]:
        reg_nat = np.zeros_like(v_body, dtype=np.float32)

    v_body_total = v_body + reg_nat
    
    if not np.all(np.isfinite(v_body_total)):
        raise FloatingPointError("accumulate_phi_alignment_gradient: nonfinite v_body_total.")

    # Jinv: body vector -> parameter vector
    v_param = np.einsum("...ab,...b->...a", Jinv, v_body_total, optimize=True)
   
 
    # accumulate (mask & weight)
    contrib = (beta * v_param) * joint_mask
    prev = getattr(agent_i, grad_key, None)
    if prev is None:
        prev = np.zeros_like(contrib, dtype=np.float32)
    setattr(agent_i, grad_key, prev + contrib)

    # tiny logging
    if PRINT_SIGN:
        aid  = getattr(agent_i, "id", "?")
        ajid = getattr(agent_j, "id", "?")
        spatial_axes = tuple(range(contrib.ndim - 1))
        g_mean = np.nanmean(contrib, axis=spatial_axes)
        def _sgn(x): return "+" if x > 0 else ("-" if x < 0 else "0")
        sign_str = "".join(_sgn(x) for x in g_mean.tolist())
        g_abs_mean = float(np.nanmean(np.abs(contrib)))
        print(f"[PHI-GRAD] field={field} ai={aid} aj={ajid} sign={sign_str} "
              f"mean={np.array2string(g_mean, precision=3, suppress_small=True)} "
              f"|g|_mean={g_abs_mean:.3e}", flush=True)




def accumulate_phi_morphism_self_feedback(
    agent_i,
    generators_src, generators_tgt,
    params,
    field="phi",                # "phi" (belief) or "phi_model" (model)
    fisher_inv_key=None,
    grad_key=None,
    phi_self_func=None,         # callback returning ∂E_self/∂φ (parameter-covector)
    phi_feedback_func=None,     # callback returning ∂E_fb/∂φ (parameter-covector)
):
    """
    Accumulate SELF + FEEDBACK gradients for φ (or φ̃) into agent_i.<grad_key>.

    - Uses cache E_grid/Jinv_grid if ctx is present; otherwise builds from generators.
    - Projects param-covector -> body-covector via Jinv^T, applies Fisher^{-1} (body),
      then maps body-vector -> param-vector via Jinv.
    - Weights: alpha (self), lambda (feedback) from _weights(...)—same as μ/Σ path.
    - No internal helper defs; simple, explicit control flow.
    - Prints compact sign/scale lines behind DEBUG_PHI_SIGN.
    """
    assert fisher_inv_key and grad_key, "fisher_inv_key and grad_key are required"

    PRINT_SIGN      = bool(params.get("DEBUG_PHI_SIGN", False))
    eps             = float(getattr(config, "eps", 1e-6))
    eps_sup         = float(getattr(config, "support_cutoff_eps", 1e-6))
    fisher_max_norm = float(params.get("fisher_max_norm", getattr(config, "fisher_max_norm", 1e3)))
    clip_norm       = float(params.get("phi_grad_clip_norm", getattr(config, "phi_grad_clip_norm", 1e6)))

    # Weights (we only need alpha, lambda here)
    mode = "belief" if field == "phi" else "model"
    alpha, _beta_like, lambda_ = _weights(mode, params)
    if alpha <= 0.0 and lambda_ <= 0.0:
        return

    # Mask → (...,1)
    mask = (np.asarray(agent_i.mask) > eps_sup).astype(np.float32)
    if mask.ndim == 2:
        mask = mask[..., None]
    elif mask.ndim >= 3 and mask.shape[-1] != 1:
        mask = mask[..., :1]
    if not np.any(mask):
        return

    # Fields
    mu_q, sigma_q = agent_i.mu_q_field, agent_i.sigma_q_field
    mu_p, sigma_p = agent_i.mu_p_field, agent_i.sigma_p_field
    phi       = np.asarray(agent_i.phi,       np.float32)
    phi_tilde = np.asarray(agent_i.phi_model, np.float32)

    # Transports
    ctx = params.get("runtime_ctx", None)
    if ctx is not None:
        exp_phi_q = E_grid(ctx, agent_i, which="q")
        exp_phi_p = E_grid(ctx, agent_i, which="p")
    else:
        # Fallback: build from local fields (generators role noted below)
        exp_phi_q = exp_lie_algebra_irrep(phi,       generators_tgt)  # q uses target gens here
        exp_phi_p = exp_lie_algebra_irrep(phi_tilde, generators_src)  # p uses source gens here

    # Choose which field to update, Jacobian inverse (per-pixel), and which generators are "q/p"
    if field == "phi":
        which      = "q"
        base_field = phi
        Jinv = Jinv_grid(ctx, agent_i, which) if ctx is not None else build_dexpinv_matrix(base_field)
        G_q, G_p = generators_tgt, generators_src
        exp_phi_this, exp_phi_other = exp_phi_q, exp_phi_p
    else:
        which      = "p"
        base_field = phi_tilde
        Jinv = Jinv_grid(ctx, agent_i, which) if ctx is not None else build_dexpinv_matrix(base_field)
        G_q, G_p = generators_src, generators_tgt
        exp_phi_this, exp_phi_other = exp_phi_p, exp_phi_q

    # Fisher^{-1} in body frame
    F_inv = getattr(agent_i, fisher_inv_key, None)
    has_F = F_inv is not None and np.asarray(F_inv).size > 0 and np.all(np.isfinite(F_inv))
    if has_F:
        Fi = np.asarray(F_inv, np.float32)
        # soft ∞-norm clamp
        Finf = float(np.max(np.abs(Fi)))
        if np.isfinite(Finf) and Finf > fisher_max_norm:
            Fi = Fi * (fisher_max_norm / (Finf + 1e-12))
    else:
        Fi = None

    # Prepare accumulation target
    prev = getattr(agent_i, grad_key, None)
    if prev is None:
        prev = np.zeros_like(base_field, dtype=np.float32)  # shape (..., d)
    total_accum = np.zeros_like(prev, dtype=np.float32)

    # --- SELF term (alpha) ---
    self_contrib = None
    if alpha > 0.0 and phi_self_func is not None:
        if field == "phi":
            # E_self wrt φ uses (q against Φ̃·p); generators layout as in prior code
            grad_param = phi_self_func(
                mu_q=mu_q, sigma_q=sigma_q, mu_p=mu_p, sigma_p=sigma_p,
                Phi_tilde_0=getattr(agent_i, "Phi_tilde_0", None),
                phi=phi, phi_tilde=phi_tilde,
                exp_phi=exp_phi_this, exp_phi_tilde=exp_phi_other,
                eps=eps, generators_q=G_q, generators_p=G_p,
            )
        else:
            grad_param = phi_self_func(
                mu_q=mu_q, sigma_q=sigma_q, mu_p=mu_p, sigma_p=sigma_p,
                Phi_tilde_0=getattr(agent_i, "Phi_tilde_0", None),
                phi=phi, phi_tilde=phi_tilde,
                exp_phi=exp_phi_other, exp_phi_tilde=exp_phi_this,
                eps=eps, generators_q=G_q, generators_p=G_p,
            )

        if grad_param is not None:
            grad_param = np.asarray(grad_param, np.float32)
            # param-covector -> body-covector
            g_body_cov = np.einsum("...ji,...j->...i", Jinv, grad_param, optimize=True)
            # Fisher^{-1} in body
            if Fi is not None and Fi.ndim >= 2 and Fi.shape[-2:] == g_body_cov.shape[-1:]*2:
                v_body = np.einsum("...ab,...b->...a", Fi, g_body_cov, optimize=True)
            elif Fi is not None and Fi.shape[-1:] == g_body_cov.shape[-1:]:
                v_body = g_body_cov * Fi
            elif Fi is not None and Fi.ndim == g_body_cov.ndim - 1:
                v_body = g_body_cov * Fi[..., None]
            else:
                v_body = g_body_cov
            # body-vector -> param-vector
            v_param = np.einsum("...ab,...b->...a", Jinv, v_body, optimize=True)
          
            self_contrib = alpha * v_param * mask
            total_accum += self_contrib

    # --- FEEDBACK term (lambda) ---
    fb_contrib = None
    if lambda_ > 0.0 and phi_feedback_func is not None:
        if field == "phi":
            grad_param = phi_feedback_func(
                mu_p=mu_p, sigma_p=sigma_p, mu_q=mu_q, sigma_q=sigma_q,
                Phi_0=getattr(agent_i, "Phi_0", None),
                phi=phi, phi_tilde=phi_tilde,
                exp_phi=exp_phi_this, exp_phi_tilde=exp_phi_other,
                eps=eps, generators_q=G_q,
            )
        else:
            grad_param = phi_feedback_func(
                mu_p=mu_p, sigma_p=sigma_p, mu_q=mu_q, sigma_q=sigma_q,
                Phi_0=getattr(agent_i, "Phi_0", None),
                phi=phi, phi_tilde=phi_tilde,
                exp_phi=exp_phi_other, exp_phi_tilde=exp_phi_this,
                eps=eps, generators_p=G_p, generators_q=G_q,
            )

        if grad_param is not None:
            grad_param = np.asarray(grad_param, np.float32)
            g_body_cov = np.einsum("...ji,...j->...i", Jinv, grad_param, optimize=True)
            if Fi is not None and Fi.ndim >= 2 and Fi.shape[-2:] == g_body_cov.shape[-1:]*2:
                v_body = np.einsum("...ab,...b->...a", Fi, g_body_cov, optimize=True)
            elif Fi is not None and Fi.shape[-1:] == g_body_cov.shape[-1:]:
                v_body = g_body_cov * Fi
            elif Fi is not None and Fi.ndim == g_body_cov.ndim - 1:
                v_body = g_body_cov * Fi[..., None]
            else:
                v_body = g_body_cov
            v_param = np.einsum("...ab,...b->...a", Jinv, v_body, optimize=True)
            if clip_norm > 0:
                vp_norm = np.linalg.norm(v_param, axis=-1, keepdims=True)
                scale   = np.minimum(1.0, clip_norm / np.maximum(vp_norm, 1e-9))
                v_param = v_param * scale
            fb_contrib = lambda_ * v_param * mask
            total_accum += fb_contrib

    # Accumulate into agent
    setattr(agent_i, grad_key, prev + total_accum)

    # Minimal logging
    if PRINT_SIGN:
        aid = getattr(agent_i, "id", "?")
        def _print(tag, arr):
            if arr is None: return
            spatial_axes = tuple(range(arr.ndim - 1))
            g_mean = np.mean(arr, axis=spatial_axes)
            def sgn(x): return "+" if x > 0 else "-" if x < 0 else "0"
            sign_str = "".join(sgn(x) for x in g_mean.tolist())
            g_abs_mean = float(np.mean(np.abs(arr)))
            print(f"[PHI-MORPH] field={field} ai={aid} term={tag} sign={sign_str} "
                  f"mean={np.array2string(g_mean, precision=3, suppress_small=True)} "
                  f"|g|_mean={g_abs_mean:.3e}", flush=True)

        _print("self", self_contrib)
        _print("feedback", fb_contrib)
        _print("total", total_accum)


#==============================================================================
#
#                    WITH RESPECT TO phi_i TERMS
#                       VALIDATED
#==============================================================================




def grad_kl_wrt_phi_i(
    mu_i, sigma_i,
    mu_j, sigma_j,                 # unused; kept for signature compatibility
    phi_i, phi_j,                  # unused here
    Omega_ij,
    generators,
    exp_phi_i,
    exp_phi_j,
    mu_j_t,                        # REQUIRED: (..., K)
    sigma_j_t_inv,                 # REQUIRED: (..., K, K)
    eps=1e-8,
    exp_neg_phi_j=None,
    Q_all=None,
):
    
    
    # ---- cast to f64 for internal math ----
    mu_i   = np.asarray(mu_i,   np.float64)
    mu_j_t = np.asarray(mu_j_t, np.float64)

    Sigma_i = sanitize_sigma(np.asarray(sigma_i, np.float64), eps=eps)
   

    # Q_all → (..., a, K, K)
    if Q_all is None:
        Q_all = d_exp_phi_exact(np.asarray(phi_i, np.float64), generators)
    
    Q = np.stack([np.asarray(x, np.float64) for x in Q_all], axis=-3)

    # exp(-phi_j) broadcast to Q lead dims
    if exp_neg_phi_j is None:
        exp_neg_phi_j = safe_omega_inv(np.asarray(exp_phi_j, np.float64), eps=eps, debug=False)
   
    # Ω and Ω^{-1}
    Om   = np.asarray(Omega_ij, np.float64)
    Oinv = safe_omega_inv(Om, eps=eps, debug=False).astype(np.float64, copy=False)

    # Sanity on provided precision
    Sj_inv = np.asarray(sigma_j_t_inv, np.float64)
    Sj_inv = 0.5 * (Sj_inv + np.swapaxes(Sj_inv, -1, -2))
    

    # Core pieces
    delta_mu = (mu_i - mu_j_t)                     # (..., K)
    mu_j_src = np.einsum("...ij,...j->...i", Oinv, mu_j_t, optimize=True)  # (..., K)

    # dΩ/dφ_i^a = Q[a] @ e^{-φ_j}
    Q = np.einsum("...aik,...kj->...aij", Q, exp_neg_phi_j, optimize=True)
    Q_T = np.swapaxes(Q, -1, -2)

    # ---- gradient terms ----
    # trace term
    t1 = np.einsum("...ij,...ajk,...ki->...a", Sj_inv, Q,   Sigma_i, optimize=True)
    t2 = np.einsum("...aij,...jk,...ki->...a", Q_T,   Sj_inv, Sigma_i, optimize=True)
    trace_term = -0.5 * (t1 + t2)

    # mean term
    tmp1 = np.einsum("...aij,...j->...ai", Q_T,    delta_mu, optimize=True)
    tmp2 = np.einsum("...ij,...aj->...ai", Sj_inv, tmp1,     optimize=True)
    mean_term = -np.einsum("...i,...ai->...a", mu_j_src, tmp2, optimize=True)

    # Mahalanobis term
    v1 = np.einsum("...ij,...j->...i", Sj_inv, delta_mu, optimize=True)
    part1 = np.einsum("...aij,...j->...ai", Q_T, v1,           optimize=True)
    v2    = np.einsum("...aij,...j->...ai", Q,   delta_mu,     optimize=True)
    part2 = np.einsum("...ij,...aj->...ai", Sj_inv, v2,        optimize=True)
    mahal_term = 0.5 * np.einsum("...i,...ai->...a", delta_mu, part1 + part2, optimize=True)

    grad = (trace_term + mean_term + mahal_term)
    
    return grad





def grad_feedback_phi_direct(
    mu_p, sigma_p,
    mu_q, sigma_q,
    Phi_0,
    phi,                # (..., d)
    phi_tilde,          # (..., d)
    generators_q,       # (d, K_q, K_q)
    exp_phi,            # (..., K_q, K_q)
    exp_phi_tilde,      # (..., K_p, K_p)
    eps=1e-8,
    # NEW optional precomputes:
    Q_all=None,         # (..., d, K_q, K_q) = d_exp_phi_exact(phi, generators_q)
    exp_neg_phi=None    # (..., K_q, K_q) = e^{-φ}
):
    """
    Vectorized over 'a': returns (..., d)
    Φ = e^{φ̃} Φ₀ e^{-φ}, ∂Φ = - Φ · (e^{-φ} (∂ e^{φ}) e^{-φ})
    """
    d, K_q, _ = generators_q.shape
    

    if exp_neg_phi is None:
        exp_neg_phi = safe_omega_inv(exp_phi, eps=eps, debug=False)
    if Q_all is None:
        # stack as (..., d, K_q, K_q)
        Q_list = d_exp_phi_exact(phi, generators_q)
        Q_all = np.stack(Q_list, axis=-3)  # assuming list of d arrays

    # Φ and Φᵀ
    Phi = np.einsum("...ik,...kj,...jl->...il", exp_phi_tilde, Phi_0, exp_neg_phi)
    Phi_T = np.swapaxes(Phi, -1, -2)


    # A, A^{-1}
    A = np.einsum("...ik,...kl,...lj->...ij", Phi, sigma_q, Phi_T)
    A = sanitize_sigma(A, eps=eps)
    A_inv = safe_inv(A, eps=eps)

    # Δμ and v
    Phi_mu_q = np.einsum("...ij,...j->...i", Phi, mu_q)
    delta_mu = mu_p - Phi_mu_q
    v = np.einsum("...ij,...j->...i", A_inv, delta_mu)  # (..., K_p)

    # Q̄_a = e^{-φ} Q_a e^{-φ}
    Q_bar = np.einsum("...ik,...akl,...lj->...aij", exp_neg_phi, Q_all, exp_neg_phi)

    # dΦ_a = - Φ Q̄_a
    dPhi = -np.einsum("...ik,...akj->...aij", Phi, Q_bar)
    dPhi_T = np.swapaxes(dPhi, -1, -2)

    # dA_a
    dA = (
        np.einsum("...aik,...kl,...lj->...aij", dPhi, sigma_q, Phi_T) +
        np.einsum("...ik,...kl,...alj->...aij", Phi,  sigma_q, dPhi_T)
    )

    # Term 1
    dPhi_mu = np.einsum("...aij,...j->...ai", dPhi, mu_q)       # (..., a, K_p)
    term1 = -np.einsum("...ai,...i->...a", dPhi_mu, v)

    # Term 2
    term2 = 0.5 * np.einsum("...ij,...aij->...a", A_inv, dA)

    # M_a = A^{-1} dA_a A^{-1}
    M = np.einsum("...ij,...ajk,...kl->...ail", A_inv, dA, A_inv)

    # Term 3
    term3 = -0.5 * np.einsum("...i,...aij,...j->...a", delta_mu, M, delta_mu)

    # Term 4
    term4 = -0.5 * np.einsum("...aij,...ji->...a", M, sigma_p)

    grad = (term1 + term2 + term3 + term4).astype(np.float32, copy=False)
    return grad


def grad_feedback_phi_tilde_direct(
    mu_p, sigma_p,
    mu_q, sigma_q,
    Phi_0,
    phi, phi_tilde,
    generators_p, generators_q,
    exp_phi, exp_phi_tilde,
    eps=1e-8,
    # NEW optional precomputes:
    Q_tilde_all=None,       # (..., d, K_p, K_p) = d_exp_phi_tilde_exact(phi_tilde, generators_p)
    exp_neg_phi_tilde=None  # (..., K_p, K_p) = e^{-φ̃}
):
    """
    Vectorized over 'a': returns (..., d)
    Left-trivialize: dΦ_a = L_a Φ,  L_a = (∂e^{φ̃}/∂φ̃^a) e^{-φ̃}.
    """
    d, K_p, _ = generators_p.shape
    

    if exp_neg_phi_tilde is None:
        exp_neg_phi_tilde = safe_omega_inv(exp_phi_tilde, eps=eps, debug=False)
    if Q_tilde_all is None:
        Q_list = d_exp_phi_tilde_exact(phi_tilde, generators_p)
        Q_tilde_all = np.stack(Q_list, axis=-3)

    # Φ
    exp_neg_phi = safe_omega_inv(exp_phi, eps=eps, debug=False)
    Phi   = np.einsum("...ik,...kj,...jl->...il", exp_phi_tilde, Phi_0, exp_neg_phi)
    Phi_T = np.swapaxes(Phi, -1, -2)

  
    A = np.einsum("...ik,...kl,...lj->...ij", Phi, sigma_q, Phi_T)
    A = sanitize_sigma(A, eps=eps)
    A_inv = safe_inv(A, eps=eps)

    Phi_mu_q = np.einsum("...ij,...j->...i", Phi, mu_q)
    delta_mu = mu_p - Phi_mu_q
    v = np.einsum("...ij,...j->...i", A_inv, delta_mu)

    # L_a = Q̃_a e^{-φ̃}
    L = np.einsum("...aik,...kj->...aij", Q_tilde_all, exp_neg_phi_tilde)

    # dΦ_a = L_a Φ
    dPhi = np.einsum("...aik,...kj->...aij", L, Phi)
    dPhi_T = np.swapaxes(dPhi, -1, -2)

    dA = (
        np.einsum("...aik,...kl,...lj->...aij", dPhi, sigma_q, Phi_T) +
        np.einsum("...ik,...kl,...alj->...aij", Phi,  sigma_q, dPhi_T)
    )

    dPhi_mu = np.einsum("...aij,...j->...ai", dPhi, mu_q)
    term1 = -np.einsum("...ai,...i->...a", dPhi_mu, v)

    term2 = 0.5 * np.einsum("...ij,...aij->...a", A_inv, dA)

    M = np.einsum("...ij,...ajk,...kl->...ail", A_inv, dA, A_inv)

    term3 = -0.5 * np.einsum("...i,...aij,...j->...a", delta_mu, M, delta_mu)
    term4 = -0.5 * np.einsum("...aij,...ji->...a", M, sigma_p)

    grad = term1 + term2 + term3 + term4
    return grad



def grad_self_phi_direct(
    mu_q, sigma_q,
    mu_p, sigma_p,
    Phi_tilde_0,
    phi, phi_tilde,
    generators_q, generators_p,
    exp_phi, exp_phi_tilde,
    eps=1e-8,
    # NEW optional precomputes:
    Q_all=None,               # (..., d, K_q, K_q)
    exp_neg_phi_tilde=None    # (..., K_p, K_p)
):
    """
    Vectorized over 'a': returns (..., d)
    Φ̃ = e^{φ} Φ̃₀ e^{-φ̃},  ∂Φ̃_a = (∂e^{φ}/∂φ^a) Φ̃₀ e^{-φ̃}.
    """
    d, K_q, _ = generators_q.shape
    

    if exp_neg_phi_tilde is None:
        exp_neg_phi_tilde = safe_omega_inv(exp_phi_tilde, eps=eps, debug=False)
    if Q_all is None:
        Q_list = d_exp_phi_exact(phi, generators_q)
        Q_all = np.stack(Q_list, axis=-3)

    # Φ̃ and A
    Phi_tilde = np.einsum("...ik,...kj,...jl->...il", exp_phi, Phi_tilde_0, exp_neg_phi_tilde)
    Phi_tilde_T = np.swapaxes(Phi_tilde, -1, -2)


    A = np.einsum("...ik,...kl,...lj->...ij", Phi_tilde, sigma_p, Phi_tilde_T)
    A = sanitize_sigma(A, eps=eps)
    A_inv = safe_inv(A, eps=eps)

    delta_mu = mu_q - np.einsum("...ij,...j->...i", Phi_tilde, mu_p)

    # ∂Φ̃_a = Q_a Φ̃₀ e^{-φ̃}
    dPhi = np.einsum("...aik,...kj,...jl->...ail", Q_all, Phi_tilde_0, exp_neg_phi_tilde)
    dPhi_T = np.swapaxes(dPhi, -1, -2)

    dA = (
        np.einsum("...aik,...kl,...lj->...aij", dPhi, sigma_p, Phi_tilde_T) +
        np.einsum("...ik,...kl,...alj->...aij", Phi_tilde, sigma_p, dPhi_T)
    )

    # Term 1
    dPhi_mu_p = np.einsum("...aij,...j->...ai", dPhi, mu_p)
    term1 = -np.einsum("...ai,...i->...a", dPhi_mu_p, np.einsum("...ij,...j->...i", A_inv, delta_mu))

    # Term 2   (note: your earlier self/feedback sign conventions differ; keeping your current one)
    term2 = 0.5 * np.einsum("...ij,...aij->...a", A_inv, dA)

    # M = A^{-1} dA A^{-1}
    M = np.einsum("...ij,...ajk,...kl->...ail", A_inv, dA, A_inv)

    # Term 3
    term3 = -0.5 * np.einsum("...i,...aij,...j->...a", delta_mu, M, delta_mu)

    # Term 4
    term4 = -0.5 * np.einsum("...aij,...ji->...a", M, sigma_q)

    grad = term1 + term2 + term3 + term4
    return grad


def grad_self_phi_tilde_direct(
    mu_q, sigma_q,
    mu_p, sigma_p,
    Phi_tilde_0,
    phi, phi_tilde,
    generators_q, generators_p,
    exp_phi, exp_phi_tilde,
    eps=1e-8,
    # NEW optional precomputes:
    Q_tilde_all=None,         # (..., d, K_p, K_p)
    exp_neg_phi_tilde=None    # (..., K_p, K_p)
):
    """
    Vectorized over 'a': returns (..., d)
    Right-trivialize on model: R_a = (∂e^{φ̃}/∂φ̃^a) e^{-φ̃},  ∂Φ̃_a = - Φ̃ R_a.
    """
    d, K_p, _ = generators_p.shape
    
    if exp_neg_phi_tilde is None:
        exp_neg_phi_tilde = safe_omega_inv(exp_phi_tilde, eps=eps, debug=False)
    if Q_tilde_all is None:
        Q_list = d_exp_phi_tilde_exact(phi_tilde, generators_p)
        Q_tilde_all = np.stack(Q_list, axis=-3)

    Phi_tilde = np.einsum("...ik,...kj,...jl->...il", exp_phi, Phi_tilde_0, exp_neg_phi_tilde)
    Phi_tilde_T = np.swapaxes(Phi_tilde, -1, -2)

    
    A = np.einsum("...ik,...kl,...lj->...ij", Phi_tilde, sigma_p, Phi_tilde_T)
    A = sanitize_sigma(A, eps=eps)
    A_inv = safe_inv(A, eps=eps)

    mu_t = np.einsum("...ij,...j->...i", Phi_tilde, mu_p)
    delta_mu = mu_q - mu_t

    # R_a = Q̃_a e^{-φ̃}
    R = np.einsum("...aik,...kj->...aij", Q_tilde_all, exp_neg_phi_tilde)

    # dΦ̃_a = - Φ̃ R_a
    dPhi = -np.einsum("...ik,...akj->...aij", Phi_tilde, R)
    dPhi_T = np.swapaxes(dPhi, -1, -2)

    dA = (
        np.einsum("...aik,...kl,...lj->...aij", dPhi, sigma_p, Phi_tilde_T) +
        np.einsum("...ik,...kl,...alj->...aij", Phi_tilde, sigma_p, dPhi_T)
    )

    dPhi_mu_p = np.einsum("...aij,...j->...ai", dPhi, mu_p)
    term1 = -np.einsum("...ai,...i->...a", dPhi_mu_p, np.einsum("...ij,...j->...i", A_inv, delta_mu))

    term2 = 0.5 * np.einsum("...ij,...aij->...a", A_inv, dA)

    M = np.einsum("...ij,...ajk,...kl->...ail", A_inv, dA, A_inv)

    term3 = -0.5 * np.einsum("...i,...aij,...j->...a", delta_mu, M, delta_mu)
    term4 = -0.5 * np.einsum("...aij,...ji->...a", M, sigma_q)

    grad = term1 + term2 + term3 + term4
    return grad






def compute_curvature_gradient_analytical(phi, generators, dx: float = 1.0, metric_ab: np.ndarray | None = None):
    """
    ∇_φ Tr(F^2). If generators aren't trace-orthonormal, pass metric_ab = [Tr(G^a G^b)].
    """
    H, W, d = phi.shape
    phi = np.asarray(phi, np.float32)
    G   = np.asarray(generators, np.float32)

    A_x = (np.roll(phi, -1, 0) - np.roll(phi, 1, 0)) / (2 * dx)
    A_y = (np.roll(phi, -1, 1) - np.roll(phi, 1, 1)) / (2 * dx)

    A_x_mat = np.einsum("hwd,dkm->hwkm", A_x, G)
    A_y_mat = np.einsum("hwd,dkm->hwkm", A_y, G)

    dAy_dx = (np.roll(A_y_mat, -1, 0) - np.roll(A_y_mat, 1, 0)) / (2 * dx)
    dAx_dy = (np.roll(A_x_mat, -1, 1) - np.roll(A_x_mat, 1, 1)) / (2 * dx)
    comm_xy = A_x_mat @ A_y_mat - A_y_mat @ A_x_mat
    F_xy = dAy_dx - dAx_dy + comm_xy

    dF_dx = (np.roll(F_xy, -1, 0) - np.roll(F_xy, 1, 0)) / (2 * dx)
    dF_dy = (np.roll(F_xy, -1, 1) - np.roll(F_xy, 1, 1)) / (2 * dx)
    comm1 = A_x_mat @ F_xy - F_xy @ A_x_mat
    comm2 = A_y_mat @ F_xy - F_xy @ A_y_mat
    divF = dF_dx + dF_dy + comm1 + comm2

    if metric_ab is None:
        grad = 2.0 * np.stack([np.einsum("...ij,ij->...", divF, G[a]) for a in range(d)], axis=-1)
    else:
        Ginvs = safe_omega_inv(metric_ab.astype(np.float64, copy=False))
        comps = np.array([np.einsum("...ij,ij->...", divF, G[a]) for a in range(d)])  # (d,H,W)
        grad = 2.0 * np.einsum("ab,b...->a...", Ginvs, comps).transpose(1, 2, 0)
    return grad.astype(np.float32, copy=False)


# =========================
# Regularization (with toggleable φ–φ̃ coupling)
# =========================
def apply_regularization_terms_lie_natural(
    agent,
    phi_field,
    generators,
    field,
    params,
    agents=None,
    eps=1e-8,
    *,
    ctx=None,
):
    """
    Return NATURAL (body-frame) regularizer vector for φ or φ̃.
    """
    

    phi_field = np.asarray(phi_field, np.float32)
    grad_nat  = np.zeros_like(phi_field, dtype=np.float32)    # (..., d)
    d         = int(grad_nat.shape[-1])

    # --- weights, which fiber, and generator sets ---
    curv_w, fisher_w, mass_w, cpl_w = reg_weights(field, params, config=config)
        
        
    which, gen_q, gen_p = which_and_gens(agent, field, generators)

    # quick exit
    if (curv_w == 0.0) and (fisher_w == 0.0) and (mass_w == 0.0) and (cpl_w == 0.0):
        return grad_nat

    # --- mask standardization ---
    eps_sup  = float(getattr(config, "support_cutoff_eps", 1e-6))
    mask_vec, _mask_sca = mask_to_vec(getattr(agent, "mask", 1.0), target_shape_last_d=d, eps_sup=eps_sup)

    # --- Jinv for current field (cached or built) ---
    Jinv = jinv_for_field(ctx, agent, which, phi_field, build_dexpinv_matrix=build_dexpinv_matrix)
    
    # --- curvature on φ (param covector → body) ---
    if curv_w > 0.0:
        g_param_curv = compute_curvature_gradient_analytical(phi_field, generators)    # (..., d_param)
        g_body_curv  = cov_param_to_body(Jinv, g_param_curv, d)
        grad_nat    += curv_w * g_body_curv * mask_vec

    

    # --- mass: ∂/∂φ (λ/2 ||φ||^2) = λ φ (param covector → body) ---
    if mass_w > 0.0:
        g_param_mass = mass_w * phi_field
        g_body_mass  = cov_param_to_body(Jinv, g_param_mass, d)
        grad_nat    += g_body_mass * mask_vec

    # --- q↔p coupling: (1/2)||φ_p - C φ_q||^2 ---
    if cpl_w > 0.0:
        try:
            phi_q = np.asarray(getattr(agent, "phi", None), np.float32)
            phi_p = np.asarray(getattr(agent, "phi_model", None), np.float32)
            C = _build_c_mapping_q2p(getattr(agent, "Phi_tilde_0", None), gen_q, gen_p, eps=eps)
            if C is not None and phi_q is not None and phi_p is not None:
                # residual in p-space
                r = phi_p - np.einsum("ab,...b->...a", C, phi_q, optimize=True)   # (..., d_p)
                if field == "phi":
                    # ∂L/∂φ_q = - C^T r  (param covector)
                    g_param = -np.einsum("ba,...a->...b", C, r, optimize=True)    # (..., d_q)
                else:
                    # ∂L/∂φ_p = r
                    g_param = r
                g_body_cpl = cov_param_to_body(Jinv, g_param, d)
                grad_nat   += cpl_w * g_body_cpl * mask_vec
        except Exception as e:
            if params.get("DEBUG_PHI", False):
                print(f"[DBGALIGN-WARN] reg coupling failed: {type(e).__name__}: {e}", flush=True)

    return np.asarray(grad_nat, np.float32)



# =========================
# Helpers (cached, lightweight)
# =========================

def _algebra_matrix_from_coeffs(phi_coeffs, generators):
    """
    phi_coeffs: (..., d)
    generators: (d, K, K)
    returns: (..., K, K) matrix in the algebra
    """
    # sum_a phi^a G^a
    # reshape phi to broadcast over K,K
    return np.einsum("...a,aij->...ij", phi_coeffs, generators)


def _gram_inv_cached(agent, key_name, generators, eps=1e-8):
    """
    Cache and return Gram^{-1} for the given generator set under Frobenius inner product.
    key_name: str attribute name on agent (e.g., "_Gram_q_inv" / "_Gram_p_inv")
    """
    G_inv = getattr(agent, key_name, None)
    if G_inv is not None:
        return G_inv
    d = generators.shape[0]
    Gram = np.empty((d, d), dtype=generators.dtype)
    for a in range(d):
        for b in range(d):
            Gram[a, b] = np.tensordot(generators[a], generators[b])
    Gram += eps * np.eye(d, dtype=Gram.dtype)
    G_inv = safe_inv(Gram)
    setattr(agent, key_name, G_inv)
    return G_inv


def _project_mat_to_algebra_coeffs(M, generators, G_inv):
    """
    Project matrix M (..., K, K) to algebra coefficients (..., d)
    by solving coeffs = G_inv @ h, where h_b = <G^b, M>_F.
    """
    d = generators.shape[0]
    # h_b = tr((G^b)^T M)
    h = np.stack([np.tensordot(generators[b], M) for b in range(d)], axis=-1)
    # coeffs = h @ G_inv^T (since last dim is basis index)
    # both ways are fine; using right-multiply for (..., d)
    coeffs = np.einsum("...b,bc->...c", h, G_inv)
    return coeffs


# --- helper: build C once and cache on agent ---
def _build_c_mapping_q2p(Phi_tilde_0, generators_q, generators_p, eps=1e-8):
    """
    Build linear map C (d_p x d_q) so that Ad_{Phi_tilde_0}(G_q^a) ≈ sum_b C_{ba} G_p^b,
    using Frobenius inner-product projection onto p-basis.
    """
    d_q, Kq, _ = generators_q.shape
    d_p, Kp, _ = generators_p.shape
    assert Phi_tilde_0.shape[-2:] == (Kq, Kp), "Phi_tilde_0 must be (K_q, K_p)"

    # Gram matrix of p-basis under Frobenius product
    Gp = np.zeros((d_p, d_p), dtype=generators_p.dtype)
    for b in range(d_p):
        for c in range(d_p):
            Gp[b, c] = np.tensordot(generators_p[b], generators_p[c])
    Gp += eps * np.eye(d_p, dtype=Gp.dtype)
    Gp_inv = safe_inv(Gp)

    # Conjugate each q-generator: H_a = Phi0 G_q^a Phi0^{-1}
    Phi0    = Phi_tilde_0
    Phi0_inv = safe_inv(Phi0, eps=eps)

    C = np.zeros((d_p, d_q), dtype=generators_p.dtype)
    for a in range(d_q):
        H_a = np.einsum("ik,kl,lj->ij", Phi0, generators_q[a], Phi0_inv)
        h = np.array([np.tensordot(generators_p[b], H_a) for b in range(d_p)], dtype=H_a.dtype)
        C[:, a] = Gp_inv @ h
    return C


