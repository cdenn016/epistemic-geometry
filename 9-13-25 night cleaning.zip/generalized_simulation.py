# generalized_simulation.py
import os
os.environ["OMP_NUM_THREADS"] = "1"
os.environ["MKL_NUM_THREADS"] = "1"
os.environ["NUMEXPR_NUM_THREADS"] = "1"
os.environ["OPENBLAS_NUM_THREADS"] = "1"
import sys
ROOT = os.path.dirname(os.path.abspath(__file__))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)
from pathlib import Path
import sys, time, pickle
import core.config as config

from updates.update_rules import synchronous_step
from run_sim_utils import (
    prepare_generators, merge_logging_cfg, initialize_or_resume,
    ensure_runtime, log_and_viz_after_step,
    wrap_epilogue, save_step
)
from transport.transport_cache import ensure_global_A
from diagnostics import compute_total_action, print_action_breakdown
from metrics_viz import VizConfig, MetricsViz


# --- Minimal helpers for logging/diagnostics ---
import numpy as np

def _casimir_total(G: np.ndarray) -> float:
    # G shape (3, K, K)
    return float(sum(-np.trace(G[a] @ G[a]) for a in range(3)) / 3.0)

def _safe_norm_field(arr) -> float:
    try:
        x = np.asarray(arr)
        if x.ndim >= 3:
            return float(np.nanmean(np.linalg.norm(x, axis=-1)))
        elif x.ndim == 2:
            return float(np.nanmean(np.abs(x)))
    except Exception:
        pass
    return 0.0

def _maybe_omega_drift(runtime_ctx, agents) -> float:
    # Optional Ω drift diagnostic; safe no-op if imports/fields not available
    try:
        from transport.transport_cache import Omega
        if len(agents) >= 2:
            ai, aj = agents[0], agents[1]
            Om = Omega(runtime_ctx, ai, aj, which="q")
            I  = np.eye(Om.shape[-1], dtype=Om.dtype)
            diff = np.einsum("...ik,...jk->...ij", Om, Om) - I
            return float(np.linalg.norm(diff))
    except Exception:
        pass
    return float("nan")

def _extract_global_from_Q(Q) -> dict:
    """
    Accepts a dict-like or object 'Q' from compute_total_action(...) and
    returns ONLY numeric fields for logging. Skips strings/bools and metadata.
    Also supports tiny dicts like {'value': 1.23, 'w': 1, 'src': 'cached'}.
    """
    import numpy as np
    import numbers as _numbers

    def _is_num(x):
        # true for Python/NumPy numbers, false for bools
        if isinstance(x, (bool, np.bool_)):
            return False
        return isinstance(x, _numbers.Number) or (isinstance(x, np.generic) and np.issubdtype(type(x), np.number))

    def _coerce_num(x):
        # dict with 'value' → extract; tuple/list → first numeric element; else None
        if _is_num(x):
            return float(x)
        if isinstance(x, dict) and "value" in x and _is_num(x["value"]):
            return float(x["value"])
        if isinstance(x, (list, tuple)) and len(x) > 0 and _is_num(x[0]):
            return float(x[0])
        return None

    out = {}
    if Q is None:
        return out

    if isinstance(Q, dict):
        for k, v in Q.items():
            val = _coerce_num(v)
            if val is not None:
                out[k] = val
        return out

    # object-like fallback: pick common attributes if numeric
    for k in ("Action_total","Geom_total","VFE_acc","A_curv","A_cov","ModelPrior","Curv","Frame","Comm_KL","Transp_KL"):
        if hasattr(Q, k):
            val = _coerce_num(getattr(Q, k))
            if val is not None:
                out[k] = val
    return out





def run_simulation(
    outdir="checkpoints", 
    resume=False,
    log_metrics=True,
    log_fields=True,
    num_cores=None,
    params=None,
    fresh_outdir=False,
    clear_agent_logs=True,
):
   
    # params + cores
    try:
        import multiprocessing as _mp
        _avail = max(1, (_mp.cpu_count() or 1) - 1)
    except Exception:
        _avail = 8

    num_cores = _avail if num_cores is None else int(num_cores)
    num_cores = max(1, num_cores)

    params = {} if params is None else dict(params)

    config.n_jobs = num_cores

    # generators
    G_q, G_p = prepare_generators(params)
   
    # Keep init paths consistent with the actual generators  
    Kq, Kp = int(np.asarray(G_q).shape[1]), int(np.asarray(G_p).shape[1])
    config.K_q, config.K_p = Kq, Kp

    # logging cfg
    logcfg = merge_logging_cfg(params if isinstance(params, dict) else vars(config))
    if not log_metrics: logcfg["enable_scalar"] = False
    if not log_fields:  logcfg["enable_fields"] = False
    if logcfg.get("enable_fields", False):
        os.makedirs(os.path.join(outdir, logcfg["full_field_outdir"]), exist_ok=True)

    # init or resume
    agents, step_start = initialize_or_resume(outdir, resume, params, clear_agent_logs=clear_agent_logs)
    
    # runtime context (mounted lvl-1 view)
    runtime_ctx = ensure_runtime(params)
    runtime_ctx.global_step = step_start  # initialize step index
    params["runtime_ctx"] = runtime_ctx   # expose ctx via params for legacy helpers
     
    vizcfg = VizConfig(
        outdir=Path(outdir),
        run_name=os.path.basename(outdir) or "run",
        plot_every_steps=10,
        snapshot_every_steps=50,
        
    )
    mv = MetricsViz(vizcfg)
    meta_generators = {
        "Kq": Kq, "Kp": Kp,
        "casimir_total_q": _casimir_total(G_q),
        "casimir_total_p": _casimir_total(G_p),
    }
    mv.start_run(meta=meta_generators)
    # expose if you want access elsewhere
    runtime_ctx.viz = mv

    ensure_global_A(runtime_ctx, shape_hw=agents[0].hw, init_scale = 1.0)

    # Early-exit if resuming past the configured steps
    if step_start >= int(getattr(config, "steps", step_start)):
        wrap_epilogue(runtime_ctx, agents, outdir, [], [])
        print("[DONE] Nothing to do: resume step >= total steps.")
        return agents, []

    # trackers
    parent_metrics, metric_log = [], []
    print(f"[RUN] Starting simulation at step {step_start} with {num_cores if (num_cores is not None) else 'auto'} cores")

    for step in range(step_start, config.steps):
        # keep global_step in sync BEFORE core update so gates use it
        runtime_ctx.global_step = step
        runtime_ctx.dirty.reset_step(step)
                
        print(f"\n[STEP {step}] -----------------------------\n")
        t0 = time.perf_counter()
        step_params = {**params, "step": step, "sanitize_strict_pre": False}

        # core synchronous update (ctx is threaded inside)
        agents = synchronous_step(
            agents, G_q, G_p,
            params=step_params,
            n_jobs=num_cores,
            runtime_ctx=runtime_ctx,
        )
        
        print(f"[TIMER] synchronous update: {time.perf_counter() - t0:.3f}s")

        # viz & metrics
        runtime_ctx.children_latest   = agents
        Q = compute_total_action(runtime_ctx, agents, params)
        print_action_breakdown(runtime_ctx, Q)
        log_and_viz_after_step(runtime_ctx, agents, step, outdir, params, logcfg,
                               parent_metrics, metric_log, num_cores)
 
                # --- Global metrics row ---
                # after: Q = compute_total_action(...)
        qnums = _extract_global_from_Q(Q)
        
        # prefer Geom_total for your “energy” column; fall back to Action_total
        E_tot = qnums.get("Geom_total", qnums.get("Action_total", np.nan))
        
        gmetrics = {
            "E_total": float(E_tot) if np.isfinite(E_tot) else np.nan,
            # if you have a true mean, set it; otherwise leave NaN
            "mean_total": float(qnums.get("Geom_total_mean", np.nan)),
            # keep all numeric terms from Q so they’ll plot too
            **qnums,
        }
        
        mv.log_global(step, gmetrics)

        # --- per-agent rows (schema-aware) ---
        for a in agents:
            aid = getattr(a, "id", getattr(a, "agent_id", "?"))
        
            phi_arr = getattr(a, "phi", None)
            phi_tilde_arr = getattr(a, "phi_model", None)
        
            def mean_norm(arr):
                if arr is None:
                    return np.nan
                x = np.asarray(arr)
                if x.ndim >= 3:
                    return float(np.nanmean(np.linalg.norm(x, axis=-1)))
                if x.ndim == 2:
                    return float(np.nanmean(np.abs(x)))
                return np.nan
        
            ametrics = {
                # no E_self in schema; drop it unless you compute it elsewhere
                "mask_sum": float(np.nansum(getattr(a, "mask", 0.0))) if getattr(a, "mask", None) is not None else np.nan,
                "phi_norm_mean":        mean_norm(phi_arr),
                "phi_model_norm_mean":  mean_norm(phi_tilde_arr),
            }
            mv.log_agent(step, aid, ametrics)
        
                   
        # --- Persist + visualize on cadence ---
        mv.maybe_flush(step)
        mv.maybe_plot(step)
        mv.maybe_snapshot(step, runtime_ctx, agents)
         
        save_step(agents, outdir, step)
        print(f"[SAVE] Checkpoint --> {outdir}/step_{step:04d}.pkl")

    # epilogue    
    wrap_epilogue(runtime_ctx, agents, outdir, parent_metrics, metric_log)
    print("[DONE] Simulation completed.")
    return agents, metric_log



if __name__ == "__main__":
    
    from core.get_generators import make_reducible_generators

    # 1) optional param override for config
    if len(sys.argv) > 1:
        with open(sys.argv[1], "rb") as f:
            param_override = pickle.load(f)
        # assumes you have this helper; otherwise set fields on config directly
        try:
            from core.config import set_config_from_params
            set_config_from_params(param_override)
        except Exception:
            pass
    else:
        param_override = {}

    # 2) Build reducible SO(3) generators (examples)
    spec_q = [(3, 1), (2,2)]  #E.G. [(1,2)] IS 3 ⊕ 3  -> K_q = 6 spec = [(ℓ₁, multiplicity₁), (ℓ₂, multiplicity₂), ...]
    spec_p = [(3, 1), (1,2)]  # 5      -> K_p = 5

    G_q = make_reducible_generators(spec_q, mix=False)
    G_p = make_reducible_generators(spec_p, mix=False)

    # 3) Keep config in sync with the actual generator sizes
    config.K_q = int(G_q.shape[1])
    config.K_p = int(G_p.shape[1])

    # 4) Pass the *arrays themselves* into params so init uses them directly
    runtime_params = {
        "generators_q": G_q,
        "generators_p": G_p,
        "seed": getattr(config, "seed", 0),
    }

    
    # 5) Run
    run_simulation(
        outdir="checkpoints",
        resume=False,
        log_metrics=True,
        log_fields=True,
        params=runtime_params,
    )



