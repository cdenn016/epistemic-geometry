# -*- coding: utf-8 -*-
"""
Created on Thu Aug 21 13:17:27 2025

@author: chris and christine
"""

import numpy as np


def _mask_knobs(config, *, change_tol_override=None):
    """Collect all mask dynamics knobs (single source of truth)."""
    # unification: prefer support_tau; retain compat with support_cutoff_eps
    support_tau = float(getattr(config, "support_tau",
                        getattr(config, "support_cutoff_eps", 1e-3)))

    return {
        "support_tau": support_tau,
        "betaE":       float(getattr(config, "mask_evidence_beta", 0.7)),
        "betaM":       float(getattr(config, "mask_ema_beta", 0.3)),
        "etaE":        float(getattr(config, "mask_evidence_power", 1.0)),
        "etaW":        float(getattr(config, "mask_weight_power", 1.0)),
        "p_neg":       float(getattr(config, "evidence_softmin_p", -4.0)),
        "pres_delta":  float(getattr(config, "presence_soft_delta", 0.05)),
        "count_lo":    float(getattr(config, "overlap_soft_lo", 1.5)),
        "count_hi":    float(getattr(config, "overlap_soft_hi", 2.5)),
        "core_tau":    float(getattr(config, "parent_growth_core_tau", 0.10)),
        "core_floor":  float(getattr(config, "parent_core_floor", 0.65)),
        "dcap":        float(getattr(config, "parent_delta_cap", 0.08)),
        "freeze_steps":int(getattr(config, "parent_freeze_steps", 3)),
        "beta_jitter": float(getattr(config, "parent_mask_beta_jitter", 0.0)),
        "deadband":    float(getattr(config, "parent_mask_deadband", 0.015)),
        "change_tol":  float(change_tol_override if change_tol_override is not None
                             else getattr(config, "parent_mask_change_tol", 5e-3)),
    }


# -------------------------- Assignment helpers (new) --------------------------

def _read_assign_knobs(config, *, use_agreement, agree_weight):
    activation   = str(getattr(config, "parent_assign_activation", "entmax")).lower()
    temp         = float(getattr(config, "parent_assign_temp", 0.25))
    weight_ema   = float(getattr(config, "parent_assign_weight_ema", 0.8))
    null_enabled = bool(getattr(config, "parent_assign_null_enabled", True))
    null_logit   = float(getattr(config, "parent_assign_null_logit", 0.0))
    null_tau     = float(getattr(config, "parent_assign_null_tau", 0.5))
    cal = None
    if getattr(config, "parent_assign_target_entropy", None) is not None:
        cal = {
            "target_H": float(getattr(config, "parent_assign_target_entropy", 1.0)),
            "k":        float(getattr(config, "parent_assign_temp_k", 0.4)),
        }
    link_knobs = dict(
        theta_on   = float(getattr(config, "parent_link_on_tau",  0.30)),
        theta_off  = float(getattr(config, "parent_link_off_tau", 0.20)),
        beta       = float(getattr(config, "parent_link_ema_beta", 0.4)),
        max_change = int(getattr(config,  "parent_link_max_change", 2)),
        min_kids   = int(getattr(config,  "parent_min_kids", 2)),
    )
    grace_knobs = dict(
        keep_thr     = float(getattr(config, "parent_assign_keep_thr", 0.10)),
        grace_keep   = bool(getattr(config, "parent_assign_keep_during_grace", True)),
        newborn_steps= int(getattr(config, "newborn_bootstrap_steps", 2)),
    )
    return dict(
        activation=activation, temp=temp, weight_ema=weight_ema,
        null_enabled=null_enabled, null_logit=null_logit, null_tau=null_tau,
        calibrate=cal, use_agreement=bool(use_agreement), agree_weight=float(agree_weight),
        link_knobs=link_knobs, grace_knobs=grace_knobs
    )


def _normalize_assignments(scores, agree=None, valid_mask=None, *,
                           temp=0.25, activation="softmax",
                           agree_weight=1.0, null_enabled=True,
                           null_logit=0.0, calibrate=None):
    """
    scores: [N_parents] raw similarity/alignment per child
    agree:  [N_parents] agreement in [0,1]
    valid_mask: bool mask of admissible parents
    temp: base temperature
    activation: "softmax" | "sparsemax" | "entmax15"
    agree_weight: coefficient on log-agreement
    null_enabled: include 'null' option
    null_logit: prior logit for null
    calibrate: optional dict { 'target_H': float, 'k': float } for temp calibration
    """
    import numpy as np
    z = np.asarray(scores, np.float32)

    # convert multiplicative agree -> additive in logit space
    if agree is not None:
        a = np.clip(np.asarray(agree, np.float32), 1e-6, 1.0)
        z = z + float(agree_weight) * np.log(a)

    # temperature
    t = float(temp)
    if calibrate is not None and calibrate.get("target_H") is not None:
        # one-step exponential correction toward target entropy (cheap, stable)
        target_H = float(calibrate["target_H"])
        kappa    = float(calibrate.get("k", 0.5))
        sm = _softmax(z / max(1e-8, t), mask=valid_mask)
        H = -np.sum(sm * (np.log(sm + 1e-20)), axis=-1)
        # increase temp if too peaky (H < target), decrease if too flat
        t = t * float(np.exp(kappa * (target_H - H)))

    logits = z / max(1e-8, t)

    # attach null option (last index)
    if null_enabled:
        if valid_mask is None:
            vm = None
        else:
            vm = np.concatenate([valid_mask.astype(bool), np.array([True])], axis=-1)
        logits = np.concatenate([logits, np.array([float(null_logit)], dtype=np.float32)], axis=-1)
    else:
        vm = valid_mask

    # pick activation
    if activation == "sparsemax":
        p = _sparsemax(logits[None, :], mask=None if vm is None else vm[None, :])[0]
    elif activation in ("entmax", "entmax15"):
        p = _entmax15(logits[None, :], mask=None if vm is None else vm[None, :])[0]
    else:
        p = _softmax(logits[None, :], mask=None if vm is None else vm[None, :])[0]

    return p

# --- helpers: sparsemax / entmax15 / softmax ---------------------------------
def _softmax(z, mask=None):
    import numpy as np
    z = np.asarray(z, np.float32)
    if mask is not None:
        z = np.where(mask, z, -np.inf)
    z = z - np.nanmax(z, axis=-1, keepdims=True)
    p = np.exp(z)
    p /= np.sum(p, axis=-1, keepdims=True) + 1e-20
    return p

def _sparsemax(z, mask=None):
    """
    Martins & Astudillo (2016). Returns probabilities with exact zeros.
    Works on last axis. O(K log K) per vector.
    """
    import numpy as np
    z = np.asarray(z, np.float32)
    if mask is not None:
        z = np.where(mask, z, -np.inf)
    # replace -inf with very small for sorting
    z_safe = np.where(np.isfinite(z), z, -1e30)
    z_sorted = np.sort(z_safe, axis=-1)[:, ::-1]
    k = np.arange(1, z.shape[-1] + 1, dtype=np.float32)
    z_cumsum = np.cumsum(z_sorted, axis=-1)
    # find k* s.t. 1 + k z̄_k > sum
    rhs = 1.0 + k * z_sorted
    cond = rhs > z_cumsum
    k_star = cond.sum(axis=-1)  # [N]
    # tau = (sum_{i<=k*} z_i - 1) / k*
    # gather prefix sums at k*
    idx = (k_star - 1).clip(min=0)
    tau = (z_cumsum[np.arange(z.shape[0]), idx] - 1.0) / np.maximum(k_star, 1)
    p = np.maximum(z - tau[:, None], 0.0)
    # renormalize tiny numerical drift
    Z = np.sum(p, axis=-1, keepdims=True) + 1e-20
    return p / Z

def _entmax15(z, mask=None, iters=50, tol=1e-6):
    """
    Entmax with alpha=1.5 (Peters et al., 2019). Proper sparse probabilities.
    We use a simple per-row bisection for tau. K is small here, so fine.
    """
    import numpy as np
    z = np.asarray(z, np.float32)
    if mask is not None:
        z = np.where(mask, z, -np.inf)
    z_safe = np.where(np.isfinite(z), z, -1e30)

    # upper/lower bounds for tau
    lo = np.min(z_safe, axis=-1) - 1.0
    hi = np.max(z_safe, axis=-1)
    lo = lo[:, None]; hi = hi[:, None]

    def proj(tau):
        u = np.maximum(0.0, z_safe - tau)
        return u ** 2.0

    for _ in range(iters):
        mid = (lo + hi) * 0.5  # [N,1]
        s = np.sum(proj(mid), axis=-1, keepdims=True)
        # sum u^2 should be 1 for alpha=1.5 projection
        hi = np.where(s > 1.0, mid, hi)
        lo = np.where(s > 1.0, lo, mid)
        if np.max(np.abs(hi - lo)) < tol:
            break
    tau = (lo + hi) * 0.5
    p = np.maximum(0.0, z_safe - tau) ** 2.0
    Z = np.sum(p, axis=-1, keepdims=True) + 1e-20
    return p / Z


def _stack_child_masks(children, eps):
    import numpy as np
    return np.stack([(np.asarray(ch.mask, np.float32) > float(eps)) for ch in children], axis=0).astype(bool)


def _stack_parent_masks(Ps):
    import numpy as np
    return np.stack(
        [np.nan_to_num(np.asarray(P.mask, np.float32), nan=0.0, posinf=0.0, neginf=0.0) for P in Ps],
        axis=0
    )


def _prepare_agreement_map(agreement_map, H, W, resize_nn):
    import numpy as np
    if agreement_map is None:
        return None
    A_map = np.asarray(agreement_map, np.float32)
    if A_map.shape[:2] != (H, W):
        try:
            A_map = resize_nn(A_map, (H, W)).astype(np.float32)
        except Exception:
            return None
    return np.clip(np.nan_to_num(A_map, nan=0.0, posinf=1.0, neginf=0.0), 0.0, 1.0)


def _compute_iou_on_core(Cmb, Pcore, tau):
    import numpy as np
    inter   = np.logical_and(Cmb[:, None, :, :], Pcore[None, :, :, :]).sum(axis=(2, 3)).astype(np.float32)  # (I,P)
    cm_sum  = Cmb.sum(axis=(1, 2)).astype(np.float32)             # (I,)
    core_sum= Pcore.sum(axis=(1, 2)).astype(np.float32)           # (P,)
    union   = cm_sum[:, None] + core_sum[None, :] - inter         # (I,P)
    S       = inter / np.maximum(1.0, union)
    valid   = (inter > 0) & (S >= float(tau))
    return S, inter, valid


def _agreement_over_intersections(A_map, Cmb, Pcore, inter):
    import numpy as np
    if A_map is None:
        return np.ones_like(inter, dtype=np.float32)
    mask_ip = np.logical_and(Cmb[:, None, :, :], Pcore[None, :, :, :]).astype(np.float32)
    sum_A   = (A_map[None, None, :, :] * mask_ip).sum(axis=(2, 3))
    with np.errstate(divide="ignore", invalid="ignore"):
        A = sum_A / np.maximum(1.0, inter)
        return np.clip(np.nan_to_num(A, nan=0.0, posinf=1.0, neginf=0.0), 1e-6, 1.0)


def _per_child_distribution(i, valid_row, S, A, knobs):
    """Compute probability vector (including optional null) for child i."""
    import numpy as np
    from math import isfinite
    vmask = valid_row
    if not np.any(vmask):
        return None, None, None, None  # no valid candidates

    scores = S[i, vmask]
    agree_vec = (A[i, vmask] if (A is not None and knobs["use_agreement"]) else None)

    probs_all = _normalize_assignments(
        scores=scores,
        agree=agree_vec,
        valid_mask=None,
        temp=float(knobs["temp"]),
        activation=knobs["activation"],
        agree_weight=float(knobs["agree_weight"]),
        null_enabled=bool(knobs["null_enabled"]),
        null_logit=float(knobs["null_logit"]),
        calibrate=knobs["calibrate"],
    )
    if knobs["null_enabled"]:
        p_eff  = probs_all[:-1]
        p_null = float(probs_all[-1])
        if not isfinite(p_null): p_null = 0.0
    else:
        p_eff, p_null = probs_all, 0.0
    return vmask, p_eff, p_null, probs_all


def _apply_topk_inplace(W_row, idxs, max_parents_per_child):
    import numpy as np
    if not max_parents_per_child or max_parents_per_child >= len(idxs):
        return
    k = int(max_parents_per_child)
    keep = idxs[np.argsort(-W_row[idxs])[:k]]
    prune = np.setdiff1d(idxs, keep, assume_unique=False)
    if prune.size:
        W_row[prune] = 0.0
    s = W_row[keep].sum()
    if s > 0:
        W_row[keep] /= s


def _fallback_force_best_if_needed(W_row, null_enabled, p_null, null_tau, S_row, vmask, Pn):
    """Prevent full unassignment when not allowed: pick global best IoU."""
    import numpy as np
    if (W_row.sum() > 0.0) and (not (null_enabled and p_null >= float(null_tau))):
        return
    # choose best among all parents by IoU row S_row (not only valid ones)
    best_p = int(np.argmax(S_row))
    best_iou = float(S_row[best_p])
    if best_iou <= 0.0:
        # secondary try: global IoU over full masks
        best_p = -1; best_iou = -1.0
    if best_p >= 0 and best_iou > 0.0:
        W_row[:] = 0.0
        W_row[best_p] = 1.0


def _build_iou_row_for_parent(IoU, W, children, p):
    """Return {child_id: iou} for kids with nonzero IoU or currently selected."""
    row = {}
    I = W.shape[0]
    for i in range(I):
        cid = int(getattr(children[i], "id", i))
        iou = float(IoU[i, p])
        if (iou > 0.0) or (W[i, p] > 0.0):
            row[cid] = iou
    return row


def _project_W_to_kept(W, children, p, kept_ids):
    import numpy as np
    kept_set = set(kept_ids)
    W[:, p] = 0.0
    idx_keep = [i for i, ch in enumerate(children) if int(getattr(ch, "id", i)) in kept_set]
    if idx_keep:
        w = np.ones(len(idx_keep), np.float32) / float(len(idx_keep))
        W[idx_keep, p] = w


def _writeback_children(W, Ps, children, max_parents_per_child):
    I, Pn = W.shape
    for i, ch in enumerate(children):
        pairs = [(int(getattr(Ps[p], "id", p)), float(W[i, p])) for p in range(Pn) if W[i, p] > 0.0]
        if pairs:
            pairs.sort(key=lambda t: -t[1])
            if max_parents_per_child and len(pairs) > int(max_parents_per_child):
                pairs = pairs[:int(max_parents_per_child)]
            s = sum(w for _, w in pairs)
            if s > 0:
                pairs = [(pid, w / s) for (pid, w) in pairs]
            ch.labels = {pid: w for (pid, w) in pairs}
            ch.parent_ids = [pid for (pid, _) in pairs]
            ch.parent_id = int(ch.parent_ids[0]) if ch.parent_ids else -1
        else:
            ch.labels = {}; ch.parent_ids = []; ch.parent_id = -1


def _writeback_parents(W, Ps, children):
    import numpy as np
    for p, P in enumerate(Ps):
        ids = np.where(W[:, p] > 0.0)[0]
        weights = {}
        for i in ids:
            cid = int(getattr(children[i], "id", i))
            weights[cid] = float(W[i, p])
        s = sum(weights.values())
        if s > 0.0:
            inv = 1.0 / s
            for k in list(weights.keys()):
                weights[k] *= inv
        P.child_weights = weights
        P.child_ids = tuple(sorted(weights.keys()))


def _apply_assignment_hysteresis(P, children, *, min_kids=2, keep_thr=0.10, eps=1e-6):
    """
    Keep previously assigned children if their IoU with the current mask is still reasonable.
    """
    import numpy as np
    prev_ids = set(getattr(P, "_prev_child_ids", ()) or ())
    cur_ids  = set(int(k) for k in getattr(P, "child_ids", ()))
    if not prev_ids:
        return
    M = np.asarray(getattr(P, "mask", 0.0), np.float32) >= float(eps)
    for cid in prev_ids:
        if cid in cur_ids:       # already kept
            continue
        # find child by id
        for ch in children:
            if int(getattr(ch, "id", -1)) == cid:
                Cm = np.asarray(getattr(ch, "mask", 0.0), np.float32) >= float(eps)
                inter = int((Cm & M).sum()); union = int(Cm.sum() + M.sum() - inter)
                iou = (inter / max(1, union))
                if iou >= float(keep_thr):
                    cur_ids.add(cid)
                break
    if len(cur_ids) >= min_kids:
        P.child_ids = tuple(sorted(cur_ids))


def _apply_grace_and_hysteresis(Ps, children, *, eps, min_kids, keep_thr, grace_keep, W):
    I = W.shape[0]
    for p, P in enumerate(Ps):
        _apply_assignment_hysteresis(P, children, min_kids=min_kids, keep_thr=keep_thr, eps=eps)
        if grace_keep and int(getattr(P, "_grace", 0)) > 0:
            prev_ids = set(getattr(P, "_prev_child_ids", ()) or ())
            cur_ids  = set(int(k) for k in getattr(P, "child_ids", ()))
            if (len(cur_ids) < min_kids) and (len(prev_ids) >= min_kids):
                P.child_ids = tuple(sorted(prev_ids))
                keep = [i for i, ch in enumerate(children) if int(getattr(ch, "id", i)) in prev_ids]
                row = np.zeros_like(W[:, p]); 
                if keep:
                    row[keep] = 1.0 / float(len(keep))
                for i in range(I):
                    W[i, p] = row[i]
                P.child_weights = {int(getattr(children[i], "id", i)): float(row[i]) for i in keep}


def _assign_debug_summary(W, entropy_list, top1_mass_list, null_mass_list, support_size_list, knobs, Ps):
    import numpy as np
    activation, temp, null_tau, null_enabled = knobs["activation"], knobs["temp"], knobs["null_tau"], knobs["null_enabled"]
    Hm  = float(np.mean(entropy_list)) if entropy_list else 0.0
    T1m = float(np.mean(top1_mass_list)) if top1_mass_list else 0.0
    Nul = float(np.mean(null_mass_list)) if null_mass_list else 0.0
    FrN = float(np.mean([x >= null_tau for x in null_mass_list])) if (null_enabled and null_mass_list) else 0.0
    Sup = float(np.mean(support_size_list)) if support_size_list else 0.0
    print(f"[ASSIGN] act={activation} temp={float(temp):.3f} "
          f"Hmean={Hm:.3f} top1={T1m:.3f} null_mean={Nul:.3f} null>τ={FrN:.2f} "
          f"support_mean={Sup:.2f}")
    for p, P in enumerate(Ps):
        wsum = float(sum((P.child_weights or {}).values()))
        print(f"    P{getattr(P,'id',p)} kids={len(P.child_ids)} wsum={wsum:.3g}")



#=============================================================================
#
#          # ========================= Parent-mask writer helpers =========================
#
#===============================================================================================


def _resize_to_hw(a, H, W):
    import numpy as np
    a = np.asarray(a, np.float32)
    if a.shape[:2] == (H, W):
        return a
    out = np.zeros((H, W), np.float32)
    h = min(H, a.shape[0]); w = min(W, a.shape[1])
    out[:h, :w] = a[:h, :w]
    return out


def _smoothstep(x, lo, hi):
    import numpy as np
    t = (np.asarray(x, np.float32) - float(lo)) / max(hi - lo, 1e-8)
    t = np.clip(t, 0.0, 1.0)
    return t * t * (3.0 - 2.0 * t)


def _presence_gate(mask_f, support_tau, pres_delta):
    """Soft presence gate around the support threshold."""
    lo = support_tau - pres_delta
    hi = support_tau + pres_delta
    return _smoothstep(mask_f, lo, hi)  # in [0,1]


def _softmin_power_mean(A_stack, p_neg):
    """Soft-min via power mean with negative p."""
    import numpy as np
    A = np.clip(np.asarray(A_stack, np.float32), 1e-9, 1.0)
    Mp = np.mean(np.power(A, float(p_neg), dtype=np.float32), axis=0)
    return np.power(np.clip(Mp, 1e-12, 1.0), 1.0 / float(p_neg), dtype=np.float32)


def _prepare_child_fields(children, H, W):
    """Return dicts: child_id -> agreement map (H,W), mask (H,W) (floats in [0,1])."""
    import numpy as np
    id2A, id2M = {}, {}
    for ch in (children or []):
        if ch is None: 
            continue
        cid = int(getattr(ch, "id", -1))
        A = getattr(ch, "spawn_A_final", None)
        A = _resize_to_hw(A, H, W) if isinstance(A, np.ndarray) else np.zeros((H, W), np.float32)
        m = getattr(ch, "mask", None)
        M = np.clip(np.asarray(m, np.float32), 0.0, 1.0) if m is not None else np.zeros((H, W), np.float32)
        id2A[cid] = A
        id2M[cid] = M
    return id2A, id2M


def _ensure_parent_state(ctx, P, H, W, freeze_steps):
    """Initialize persistent per-parent fields if missing; return previous mask."""
    import numpy as np
    M_prev = np.asarray(getattr(P, "mask", np.zeros((H, W), np.float32)), np.float32)
    if not hasattr(P, "_ema_E") or getattr(P, "_ema_E") is None or getattr(P, "_ema_E").shape[:2] != (H, W):
        P._ema_E = np.zeros((H, W), np.float32)
    if not hasattr(P, "freeze_until"):
        step_now = int(getattr(ctx, "global_step", 0))
        P.freeze_until = step_now + int(freeze_steps)
    return M_prev


def _apply_freeze_fade(ctx, P, M_prev, *, betaM, core_tau, core_floor, dcap):
    """If coalition broke (<2 kids), decay gently; keep core during freeze; cap delta."""
    import numpy as np
    raw = (1.0 - float(betaM)) * M_prev  # slow fade
    if int(getattr(ctx, "global_step", 0)) <= int(getattr(P, "freeze_until", -1)):
        core_prev = (M_prev >= float(core_tau))
        if core_prev.any():
            raw = np.maximum(raw, float(core_floor) * core_prev.astype(np.float32))
    d = np.clip(raw - M_prev, -float(dcap), float(dcap))
    new = np.clip(M_prev + d, 0.0, 1.0)
    return new.astype(np.float32)


def _ema_toward_target(M_prev, M_tgt, *, betaM, dcap, deadband, beta_jitter):
    """EMA step toward target with jitter, deadband, and per-step delta cap."""
    import numpy as np
    bm = float(betaM) + float(beta_jitter) * (np.random.rand() - 0.5)
    bm = float(np.clip(bm, 0.05, 0.95))
    raw = bm * M_prev + (1.0 - bm) * M_tgt
    delta = raw - M_prev
    small = np.abs(delta) < float(deadband)
    if small.any():
        delta[small] = 0.0
    d = np.clip(delta, -float(dcap), float(dcap))
    return np.clip(M_prev + d, 0.0, 1.0).astype(np.float32)


def _mark_changed_if_needed(P, prev_masks, H, W, change_tol, changed_out):
    import numpy as np
    pm = prev_masks.get(int(getattr(P, "id", -1)))
    if pm is None or pm.shape[:2] != (H, W):
        changed_out.append(P); return
    if float(np.max(np.abs(pm - np.asarray(P.mask, np.float32)))) >= float(change_tol):
        changed_out.append(P)






def _update_link_hysteresis_for_parent(P, *, iou_row, child_ids_row,
                                       theta_on, theta_off, beta,
                                       max_change, min_kids,
                                       cooldown_steps=3,    # NEW
                                       jitter=0.02):        # NEW (breaks phase lock)
    """
    EMA+hysteresis + cooldown per parent↔child link.
    """
    import numpy as np
    # persistent maps
    if not hasattr(P, "_link_score") or P._link_score is None:
        P._link_score = {}
    if not hasattr(P, "_link_cooldown") or P._link_cooldown is None:
        P._link_cooldown = {}   # cid -> steps left
    if not hasattr(P, "_link_int") or P._link_int is None:
        P._link_int = {}        # small leaky integrator to avoid on/off chatter

    scores = P._link_score
    cool   = P._link_cooldown
    integ  = P._link_int

    cur = set(int(c) for c in (child_ids_row or ()))

    # tiny per-parent jitter to thresholds breaks global synchrony
    # (same for all links of this parent this step)
    th_on  = float(theta_on)  + float(jitter) * (np.random.rand() - 0.5)
    th_off = float(theta_off) - float(jitter) * (np.random.rand() - 0.5)

    # 1) update EMA + leaky integrator
    # integrator accumulates (iou - mid); only triggers when past band
    mid = 0.5 * (th_on + th_off)
    k_i = 0.25   # integration gain
    leak = 0.90  # leaky memory
    for cid, iou in iou_row.items():
        s_old = float(scores.get(cid, 0.0))
        s_new = (1.0 - beta) * s_old + beta * float(iou)
        scores[cid] = s_new

        z_old = float(integ.get(cid, 0.0))
        z_new = leak * z_old + k_i * (float(iou) - mid)
        integ[cid] = z_new

        # tick cooldown
        if cool.get(cid, 0) > 0:
            cool[cid] = int(cool[cid]) - 1

    # 2) propose adds/drops (respect cooldown and integrator)
    adds, drops = set(), set()
    seen_cids = set(iou_row.keys()) | cur
    band = 0.0  # we already bias with integrator
    for cid in seen_cids:
        s = float(scores.get(cid, 0.0))
        z = float(integ.get(cid, 0.0))
        cd = int(cool.get(cid, 0))
        if cid in cur:
            # require BOTH: under off-threshold AND integrator negative, and no cooldown
            if (cd == 0) and (s < th_off - band) and (z < 0.0):
                drops.add(cid)
        else:
            if (cd == 0) and (s >= th_on + band) and (z > 0.0):
                adds.add(cid)

    # 3) cap changes per step
    changes = 0
    out = set(cur)

    # execute drops (lowest score first)
    for cid in sorted(drops, key=lambda c: float(scores.get(c,0.0))):
        if changes >= max_change: break
        if len(out) <= max(0, int(min_kids)): break
        out.discard(cid); changes += 1
        cool[cid] = int(cooldown_steps)   # start cooldown

    # execute adds (highest score first)
    for cid in sorted(adds, key=lambda c: -float(scores.get(c,0.0))):
        if changes >= max_change: break
        out.add(cid); changes += 1
        cool[cid] = int(cooldown_steps)

    return tuple(sorted(out))






def QQ_stable_mask_update(M_prev,
                        T,
                        *,
                        beta=0.35,            # step toward target (0..1)
                        decay_beta=0.10,      # step toward 0 when target is “empty”
                        min_mass_px=5,        # treat tiny targets as “empty”
                        seed_mask=None,       # protect newborns
                        freeze_until=None,
                        step=None):
    import numpy as np
    M_prev = np.asarray(M_prev, np.float32)
    T      = np.asarray(T,      np.float32)

    # decide whether the target actually has mass
    tgt_mass = int((T >= 1e-3).sum())
    if tgt_mass >= int(min_mass_px):
        M_new = (1.0 - float(beta)) * M_prev + float(beta) * T
    else:
        # evidence vanished: gently decay instead of dropping to zero
        M_new = (1.0 - float(decay_beta)) * M_prev

    # protect seed during newborn freeze
    if (seed_mask is not None) and (freeze_until is not None) and (step is not None):
        if int(step) <= int(freeze_until):
            M_new = np.maximum(M_new, np.asarray(seed_mask, np.float32))

    return np.clip(np.nan_to_num(M_new, nan=0.0, posinf=0.0, neginf=0.0), 0.0, 1.0)



















