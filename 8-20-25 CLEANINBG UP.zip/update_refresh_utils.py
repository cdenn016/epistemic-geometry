# -*- coding: utf-8 -*-
"""
Created on Thu Aug 21 13:30:00 2025

@author: chris and christine
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Iterable, List, Mapping, MutableMapping, Optional, Sequence, Tuple

from preprocess_utils import build_all_lambda_caches, preprocess_all_agents
from runtime_context import _collect_by_ids
from gaussian_core import directed_kl_weight_after_transport


@dataclass(frozen=True)
class Knobs:
    support_tau: float
    alpha: float
    tau_q: float
    tau_p: float
    tau_blend: float
    agree_gate: Optional[float]
    mask_eps: float
    change_tol: float

def make_pipeline_knobs(runtime_ctx) -> Knobs:
    import config as CFG
    ds = getattr(runtime_ctx, "detector_state", None)

    alpha = float(getattr(CFG, "blend_qp_alpha", 0.5))
    tau_q = float(getattr(CFG, "tau_align_q", 0.45))
    tau_p = float(getattr(CFG, "tau_align_p", 0.45))
    agree_gate = getattr(ds, "agree_gate_tau_eff", None) if ds is not None else getattr(CFG, "agree_gate_tau", None)

    # prefer support_tau; fall back gracefully once, then migrate callers
    support_tau = float(getattr(CFG, "support_tau", getattr(CFG, "support_cutoff_eps", 1e-3)))

    return Knobs(
        support_tau=support_tau,
        alpha=alpha,
        tau_q=tau_q,
        tau_p=tau_p,
        tau_blend=alpha * tau_q + (1.0 - alpha) * tau_p,
        agree_gate=agree_gate,
        mask_eps=float(getattr(CFG, "parent_mask_change_eps", 1e-5)),
        change_tol=float(getattr(CFG, "parent_mask_change_tol", 5e-3)),
    )





def _read_assign_knobs(config, *, use_agreement, agree_weight):
    activation   = str(getattr(config, "parent_assign_activation", "entmax")).lower()
    temp         = float(getattr(config, "parent_assign_temp", 0.25))
    weight_ema   = float(getattr(config, "parent_assign_weight_ema", 0.8))
    null_enabled = bool(getattr(config, "parent_assign_null_enabled", True))
    null_logit   = float(getattr(config, "parent_assign_null_logit", 0.0))
    null_tau     = float(getattr(config, "parent_assign_null_tau", 0.5))
    cal = None
    if getattr(config, "parent_assign_target_entropy", None) is not None:
        cal = {
            "target_H": float(getattr(config, "parent_assign_target_entropy", 1.0)),
            "k":        float(getattr(config, "parent_assign_temp_k", 0.4)),
        }
    link_knobs = dict(
        theta_on   = float(getattr(config, "parent_link_on_tau",  0.30)),
        theta_off  = float(getattr(config, "parent_link_off_tau", 0.20)),
        beta       = float(getattr(config, "parent_link_ema_beta", 0.4)),
        max_change = int(getattr(config,  "parent_link_max_change", 2)),
        min_kids   = int(getattr(config,  "parent_min_kids", 2)),
    )
    grace_knobs = dict(
        keep_thr     = float(getattr(config, "parent_assign_keep_thr", 0.10)),
        grace_keep   = bool(getattr(config, "parent_assign_keep_during_grace", True)),
        newborn_steps= int(getattr(config, "newborn_bootstrap_steps", 2)),
    )
    return dict(
        activation=activation, temp=temp, weight_ema=weight_ema,
        null_enabled=null_enabled, null_logit=null_logit, null_tau=null_tau,
        calibrate=cal, use_agreement=bool(use_agreement), agree_weight=float(agree_weight),
        link_knobs=link_knobs, grace_knobs=grace_knobs
    )



def refresh_spawn_alignment_caches(
    ctx,
    children,
    agents,
    *,
    G_q=None,
    G_p=None,
    tau_q=None,
    tau_p=None,
    alpha=None,          # 0→model-only, 1→belief-only
    sm_tau=None,         # softmin temperature across neighbors
    mask_tau=None,       # support threshold on masks
    use_cover_weight=True,
    kl_cap=None,         # kept for signature compat; not used
    debug=False,
):
    """
    Build *spawn-only* caches on each child (per pixel):
        spawn_nb_count, spawn_min_kl_q/p, spawn_softmin_kl_q/p,
        spawn_cover_weight (opt), spawn_A_final, kl_field, agreement_field.

    Notes
    -----
    - Uses ctx-aware transport/KL via directed_kl_weight_after_transport(..., ctx=ctx, G=G_*).
    - Ω/exp caching is entirely in the runtime transport cache (no per-agent caches).
    """
    import numpy as np
    import config as _cfg

    # defaults
    tau_q    = float(getattr(_cfg, "tau_align_q", 0.45))        if tau_q    is None else float(tau_q)
    tau_p    = float(getattr(_cfg, "tau_align_p", 0.45))        if tau_p    is None else float(tau_p)
    alpha    = float(getattr(_cfg, "blend_qp_alpha", 0.50))     if alpha    is None else float(alpha)
    sm_tau   = float(getattr(_cfg, "spawn_softmin_tau", 0.40))  if sm_tau   is None else float(sm_tau)
    mask_tau = float(getattr(_cfg, "support_cutoff_eps", 1e-4)) if mask_tau is None else float(mask_tau)

    tiny = float(getattr(_cfg, "log_eps", 1e-9))

    # id -> agent for quick neighbor lookup
    id2A = {int(a.id): a for a in agents if a is not None}

    for ch in (children or []):
        if ch is None:
            continue

        H, W = np.asarray(ch.mask).shape[:2]
        present_i = (np.asarray(ch.mask, np.float32) > mask_tau)

        # dims and generator guards
        Kq = int(getattr(ch.mu_q_field, "shape", (0, 0, 0))[-1]) if ch.mu_q_field is not None else 0
        Kp = int(getattr(ch.mu_p_field, "shape", (0, 0, 0))[-1]) if ch.mu_p_field is not None else 0
        if Kq > 0 and G_q is None:
            raise ValueError("refresh_spawn_alignment_caches: missing G_q for q-fiber.")
        if Kp > 0 and G_p is None:
            raise ValueError("refresh_spawn_alignment_caches: missing G_p for p-fiber.")

        # init outputs
        nb_count     = np.zeros((H, W), np.int32)
        min_kl_q     = np.full((H, W), np.inf, np.float32)
        min_kl_p     = np.full((H, W), np.inf, np.float32)
        sumexp_q     = np.zeros((H, W), np.float32)  # Σ exp(-KL_q/τ_q)
        sumexp_p     = np.zeros((H, W), np.float32)  # Σ exp(-KL_p/τ_p)
        cover_weight = np.zeros((H, W), np.float32) if use_cover_weight else None

        if not getattr(ch, "neighbors", None) or not np.any(present_i):
            zf = np.zeros((H, W), np.float32)
            zi = np.zeros((H, W), np.int32)
            ch.spawn_nb_count      = zi
            ch.spawn_min_kl_q      = zf + np.inf
            ch.spawn_min_kl_p      = zf + np.inf
            ch.spawn_softmin_kl_q  = zf
            ch.spawn_softmin_kl_p  = zf
            ch.spawn_cover_weight  = zf if use_cover_weight else None
            ch.spawn_A_final       = zf
            ch.kl_field            = zf
            ch.agreement_field     = zf
            continue

        # per-neighbor accumulation on the overlap only
        for nb in ch.neighbors:
            j = id2A.get(int(nb.get("id", -1)))
            if j is None:
                continue

            present_j = (np.asarray(j.mask, np.float32) > mask_tau)
            ov = (present_i & present_j)
            if not np.any(ov):
                continue

            # directed weights via central cache + explicit generators
            if Kq > 0:
                wq = directed_kl_weight_after_transport(
                    ch, j,
                    ch.mu_q_field, ch.sigma_q_field,
                    j.mu_q_field,  j.sigma_q_field,
                    fiber="q", H=H, W=W, K=Kq, ov=ov, tau=tau_q,
                    ctx=ctx, G=G_q,
                )
            else:
                wq = np.ones((H, W), np.float32)

            if Kp > 0:
                wp = directed_kl_weight_after_transport(
                    ch, j,
                    ch.mu_p_field, ch.sigma_p_field,
                    j.mu_p_field,  j.sigma_p_field,
                    fiber="p", H=H, W=W, K=Kp, ov=ov, tau=tau_p,
                    ctx=ctx, G=G_p,
                )
            else:
                wp = np.ones((H, W), np.float32)

            # scatter into accumulators at overlap pixels
            iy, ix = np.nonzero(ov)

            # neighbor count (per-pixel)
            np.add.at(nb_count, (iy, ix), 1)

            # update hard-min KL via w → KL = -τ log w
            np.minimum.at(min_kl_q, (iy, ix), (-tau_q * np.log(np.maximum(wq[iy, ix], tiny))).astype(np.float32))
            np.minimum.at(min_kl_p, (iy, ix), (-tau_p * np.log(np.maximum(wp[iy, ix], tiny))).astype(np.float32))

            # softmin sumexp
            np.add.at(sumexp_q, (iy, ix), wq[iy, ix].astype(np.float32))
            np.add.at(sumexp_p, (iy, ix), wp[iy, ix].astype(np.float32))

            # optional coverage weight
            if use_cover_weight:
                np.add.at(cover_weight, (iy, ix), np.asarray(j.mask, np.float32)[iy, ix])

        # finalize softmins on pixels that had ≥1 neighbor
        valid = (nb_count > 0)

        softmin_q = np.zeros_like(sumexp_q, np.float32)
        softmin_p = np.zeros_like(sumexp_p, np.float32)
        softmin_q[valid] = (-sm_tau * np.log(np.maximum(sumexp_q[valid], tiny))).astype(np.float32)
        softmin_p[valid] = (-sm_tau * np.log(np.maximum(sumexp_p[valid], tiny))).astype(np.float32)

        # blended KL softmin and final agreement
        tau_blend = float(alpha) * tau_q + (1.0 - float(alpha)) * tau_p
        KL_blend  = (float(alpha) * softmin_q + (1.0 - float(alpha)) * softmin_p).astype(np.float32)
        A_final   = np.zeros_like(KL_blend, np.float32)
        A_final[valid] = np.exp(-KL_blend[valid] / max(tau_blend, tiny)).astype(np.float32)

        # mask outside child support
        KL_blend  = np.where(present_i, KL_blend,  0.0).astype(np.float32)
        A_final   = np.where(present_i, A_final,   0.0).astype(np.float32)
        softmin_q = np.where(present_i, softmin_q, 0.0).astype(np.float32)
        softmin_p = np.where(present_i, softmin_p, 0.0).astype(np.float32)
        min_kl_q  = np.where(valid & present_i, min_kl_q, np.inf).astype(np.float32)
        min_kl_p  = np.where(valid & present_i, min_kl_p, np.inf).astype(np.float32)
        if use_cover_weight:
            cover_weight = np.where(present_i, cover_weight, 0.0).astype(np.float32)

        # write caches on the child
        ch.spawn_nb_count      = nb_count
        ch.spawn_min_kl_q      = min_kl_q
        ch.spawn_min_kl_p      = min_kl_p
        ch.spawn_softmin_kl_q  = softmin_q
        ch.spawn_softmin_kl_p  = softmin_p
        ch.spawn_cover_weight  = cover_weight if use_cover_weight else None
        ch.spawn_A_final       = A_final

        # convenience aliases used by plots / downstream
        ch.kl_field            = KL_blend
        ch.agreement_field     = A_final

        if debug and np.any(valid & present_i) and not np.all(np.isfinite(KL_blend[present_i])):
            print(f"[spawn-cache] non-finite blended KL for child {int(getattr(ch,'id',-1))}")








# small utilities
def list_nonnull(xs): 
    return [x for x in xs if x is not None]

# robust parent collection (reuse the helper if you defined it elsewhere)
def _collect_parents_from_ctx(ctx):
    parents = []

    def _extend(obj):
        if obj is None:
            return
        if isinstance(obj, (list, tuple)):
            parents.extend(obj)
        else:
            parents.append(obj)

    if hasattr(ctx, "parents_by_region"):
        pbr = getattr(ctx, "parents_by_region")
        if isinstance(pbr, dict):
            for v in pbr.values():
                _extend(v)
        else:
            _extend(pbr)
    elif hasattr(ctx, "parents"):
        _extend(getattr(ctx, "parents"))
    elif hasattr(ctx, "parent"):
        _extend(getattr(ctx, "parent"))

    # dedupe, preserve order
    seen = set()
    flat = []
    for p in parents:
        if p is None:
            continue
        try:
            pid = int(getattr(p, "id"))
        except Exception:
            pid = id(p)
        if pid not in seen:
            seen.add(pid)
            flat.append(p)
    return flat



def bump_cache(ctx, n=1):
    setattr(ctx, "cache_version", int(getattr(ctx, "cache_version", 0)) + n)










def list_parents(ctx):
    return _collect_parents_from_ctx(ctx)

def ensure_dirty(ctx, generators_q, generators_p, params, scope="all"):
    """
    Refresh transforms for dirty items; clear flags; bump cache if anything was done.
    Now: rebuild bundle morphisms + pre-warm exp grids in the central cache.
    """
    from transport_cache import warm_E
    from preprocess_utils import ensure_transforms
    import config as CFG

    targets = []
    if scope in ("all", "children"):
        targets += take_dirty(ctx, getattr(ctx, "children_latest", []), which="agents")
    if scope in ("all", "parents"):
        targets += take_dirty(ctx, list_parents(ctx), which="agents")
    targets = [t for t in targets if t is not None]
    if not targets:
        return targets

    # 1) Make sure Phi / Phĩ shapes match current (Kq, Kp)
    try:
        ensure_transforms(targets, generators_q, generators_p, params, ctx=ctx)
    except Exception as e:
        if bool(CFG("debug_strict", True)):
            print(f"[ensure_dirty] ensure_transforms failed: {e}")

    # 2) Pre-warm exp(φ)/exp(φ̃) in the central cache (idempotent per step)
    try:
        warm_E(ctx, targets, whiches=("q", "p"))
    except Exception:
        pass

    bump_cache(ctx, 1)
    return targets


def refresh_kl_for_dirty_children(ctx, universe, eps):
    dirty_kids = list_nonnull(take_dirty(ctx, getattr(ctx, "children_latest", []), which="kl"))
    if not dirty_kids:
        return
    _refresh_child_kl_fields_subset(dirty_kids, list_nonnull(universe), eps=eps, build_spawn=False)




def refresh_kl_for_dirty_parents(ctx, universe, eps):
    """
    Mirror of refresh_kl_for_dirty_children, but for parents.
    Recomputes KL/self-energy/etc. for any parents marked dirty (which="kl").
    """
    try:
        parents = list_parents(ctx)
    except Exception:
        parents = []
    if not parents:
        return
    # pull dirty subset
    dirty_par = list_nonnull(take_dirty(ctx, parents, which="kl"))
    if not dirty_par:
        return
    # reuse the same refresher used for children; it works for any agents
    _refresh_child_kl_fields_subset(dirty_par, list_nonnull(universe), eps=eps, build_spawn=False)






def _ensure_dirty_sets(ctx):
    # normalize the dirty container once
    d = getattr(ctx, "dirty", None)
    if d is None:
        class _D: pass
        d = _D()
        d.agents = set()
        d.kl = set()
        setattr(ctx, "dirty", d)
    else:
        if not hasattr(d, "agents"): d.agents = set()
        if not hasattr(d, "kl"):     d.kl = set()
    return d

def mark_dirty(ctx, *agents, kl=False):
    """Mark agents as needing refresh; optionally mark their KL dirty too."""
    d = _ensure_dirty_sets(ctx)
    for a in agents:
        if a is None: 
            continue
        aid = int(getattr(a, "id", id(a)))
        d.agents.add(aid)
        if kl:
            d.kl.add(aid)
        # local flags for fast checks
        setattr(a, "_dirty_fields", True)
        if kl:
            setattr(a, "_dirty_kl", True)

def take_dirty(ctx, all_agents, *, which="agents"):
    """
    Pop and return objects whose ids are marked dirty.
    which ∈ {"agents","kl"}.
    """
    d = _ensure_dirty_sets(ctx)
    ids = d.agents if which == "agents" else d.kl
    subset = _collect_by_ids(all_agents, ids)  # keep your helper
    ids.clear()
    return subset


      


# --- refresh passes -----------------------------------------------------------

def refresh_agents_light(agents, params, Gq, Gp, *, ctx=None):
    """
    Light refresh: sanitize (soft), warm exp grids into ctx.cache, build Λ caches,
    and standardize mask shapes.
    """
    if not agents: 
        return
    pre = dict(params)
    pre["sanitize_strict"] = pre.get("sanitize_strict_pre", False)
    pre["exp_n_jobs"] = 1

    preprocess_all_agents(agents, pre, Gq, Gp, ctx=ctx)
    build_all_lambda_caches(agents, ctx=ctx)

    # mask shape hygiene (once)
    import numpy as np
    H, W = np.asarray(agents[0].mask).shape[:2]
    _standardize_all_masks_once(agents, (H, W))  # keep your existing helper

def refresh_agents_strict(agents, params, Gq, Gp, *, ctx=None):
    """
    Strict refresh: sanitize (strict), rebuild Λ caches, and repair morphisms.
    """
    if not agents: 
        return
    post = dict(params)
    post["sanitize_strict"] = True
    post["exp_n_jobs"] = 1

    preprocess_all_agents(agents, post, Gq, Gp, ctx=ctx)
    build_all_lambda_caches(agents, ctx=ctx)
    _rebuild_dirty_morphisms(agents, Gq, Gp, ctx=ctx)


def _rebuild_dirty_morphisms(objs, Gq, Gp, *, ctx=None):
    """Recompute rectangular, gauge-covariant morphisms for dirty agents."""
    if not objs:
        return
    try:
        from bundle_morphism_utils import recompute_agent_morphisms as _recompute
        use_new = True
    except Exception:
        use_new = False
        try:
            from bundle_coarsegrain_init import CGH_build_morphisms as _legacy_build
        except Exception:
            _legacy_build = None

    for a in objs:
        if a is None:
            continue
        need = (
            getattr(a, "morphisms_dirty", False)
            or getattr(a, "bundle_morphism_q_to_p", None) is None
            or getattr(a, "bundle_morphism_p_to_q", None) is None
        )
        if not need:
            continue
        if use_new:
            _recompute(a, generators_q=Gq, generators_p=Gp, ctx=ctx)
        elif _legacy_build is not None:
            _legacy_build(a, Gq, Gp)
        a.morphisms_dirty = False

def _refresh_child_kl_fields_subset(children_subset, all_agents, eps, build_spawn=False, *, ctx=None):
    """
    Legacy entrypoint; delegates to the ctx-aware spawn cache builder
    for the given subset only.
    """
    if not children_subset or not build_spawn:
        return

    # pull default knobs once
    import config as _cfg
    from math import inf

    refresh_spawn_alignment_caches(
        ctx,
        children_subset,
        all_agents,
        G_q=None,  # caller should pass Gq/Gp via outer ensure_* flows if needed
        G_p=None,
        tau_q=float(getattr(_cfg, "tau_align_q", 0.45)),
        tau_p=float(getattr(_cfg, "tau_align_p", 0.45)),
        alpha=float(getattr(_cfg, "blend_qp_alpha", 0.50)),
        sm_tau=float(getattr(_cfg, "spawn_softmin_tau", 0.40)),
        mask_tau=float(getattr(_cfg, "support_tau", getattr(_cfg, "support_cutoff_eps", 1e-3))),
        use_cover_weight=True,
        debug=False,
    )




def _standardize_all_masks_once(all_agents, HW):
    from parent_utils import ensure_hw
    for a in all_agents:
        if hasattr(a, "mask"):
            m = getattr(a, "mask", None)
            if m is not None:
                mm = ensure_hw(m, HW)  
                if mm is not m:
                    setattr(a, "mask", mm)



def should_refresh_spawn_cache(child, runtime_ctx, *, mask_tol=None) -> bool:
    import numpy as np
    if getattr(child, "spawn_A_final", None) is None:
        return True
    if getattr(child, "_dirty_fields", False) or getattr(child, "_dirty_kl", False):
        return True

    if mask_tol is None:
        try:
            mask_tol = float(getattr(make_pipeline_knobs(runtime_ctx), "change_tol", 5e-3))
        except Exception:
            mask_tol = 5e-3

    prev = getattr(child, "_mask_prev_for_spawn", None)
    if prev is None:
        return True

    now = np.asarray(child.mask, np.float32)
    if now.shape != prev.shape:
        return True

    if float(np.max(np.abs(now - prev))) > float(mask_tol):
        return True

    return int(getattr(child, "_spawn_cache_built_at_cachever", -1)) != int(getattr(runtime_ctx, "cache_version", 0))




def ensure_spawn_alignment_caches(children, agents, runtime_ctx, * ,
                                  generators_q, generators_p,
                                  use_cover_weight=True, debug=False):
    import numpy as np
    import config as _cfg
    if not children:
        return

    # Pre-warm exp(φ) grids in the central cache; Ω will be built on demand.
    try:
        from transport_cache import warm_E
        whiches = []
        sample = next((c for c in children if c is not None), None)
        if sample is not None:
            kq = int(getattr(getattr(sample, "mu_q_field", None), "shape", (0,0,0))[-1]) if getattr(sample, "mu_q_field", None) is not None else 0
            kp = int(getattr(getattr(sample, "mu_p_field", None), "shape", (0,0,0))[-1]) if getattr(sample, "mu_p_field", None) is not None else 0
            if kq: whiches.append("q")
            if kp: whiches.append("p")
        if whiches:
            warm_E(runtime_ctx, children, whiches=tuple(whiches))
    except Exception:
        pass

    need = [ch for ch in children if ch is not None and should_refresh_spawn_cache(ch, runtime_ctx)]
    if not need:
        return

    refresh_spawn_alignment_caches(
        runtime_ctx,
        need,
        agents,
        G_q=generators_q,
        G_p=generators_p,
        tau_q=float(getattr(_cfg, "tau_align_q", 0.45)),
        tau_p=float(getattr(_cfg, "tau_align_p", 0.45)),
        alpha=float(getattr(_cfg, "blend_qp_alpha", 0.50)),
        sm_tau=float(getattr(_cfg, "spawn_softmin_tau", 0.40)),
        mask_tau=float(getattr(_cfg, "support_tau", getattr(_cfg, "support_cutoff_eps", 1e-3))),
        use_cover_weight=bool(use_cover_weight),
        debug=bool(debug),
    )

    step_tag = int(getattr(runtime_ctx, "global_step", 0))
    for ch in need:
        ch._spawn_cache_built_at_step = step_tag
        ch._mask_prev_for_spawn = np.asarray(ch.mask, dtype=np.float32).copy()
        setattr(ch, "_dirty_fields", False)
        setattr(ch, "_dirty_kl", False)

