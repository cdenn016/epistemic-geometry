# --- top of file -------------------------------------------------------------
# -*- coding: utf-8 -*-
"""
Utilities for parent/child assignment, mask dynamics, spawn caches, and lifecycle.
Refactor: consolidated knobs, deleted legacy paths, added invariants & typing.
"""

from parent_update_helpers import ( _agreement_over_intersections, _apply_assignment_hysteresis, 
                                   _apply_freeze_fade, _apply_grace_and_hysteresis, _apply_topk_inplace, 
                                   _build_iou_row_for_parent, _compute_iou_on_core, _ema_toward_target, 
                                   _ensure_parent_state, _entmax15, _fallback_force_best_if_needed, 
                                   _mark_changed_if_needed, _mask_knobs, _normalize_assignments, 
                                   _per_child_distribution, _prepare_agreement_map, _prepare_child_fields, 
                                   _presence_gate, _project_W_to_kept, _read_assign_knobs, 
                                   _resize_to_hw, _smoothstep, _softmax, _softmin_power_mean, 
                                   _sparsemax, _stack_child_masks, _stack_parent_masks, 
                                   _update_link_hysteresis_for_parent, _writeback_children, _writeback_parents, 
                                   _assign_debug_summary
                                  )







# -------------------------- Main function  --------------------------

def _assign_children_to_parents(
    children,
    parents_by_id,
    *,
    eps=1e-3,
    tau=0.01,
    temp=0.25,
    max_parents_per_child=2,
    core_tau=None,
    core_tau_rel=0.50,
    core_dilate_px=1,
    newborn_bootstrap_steps=2,
    allow_unassigned=False,
    agreement_map=None,
    use_agreement=None,
    agree_weight=None,
    debug=False,
):
    """
    Stable, streamlined child→parent assignment:
      - Vectorized IoU on parent cores (per-parent adaptive threshold + newborn relax)
      - Optional agreement blending (mean over cm∧core)
      - Tempered normalization via _normalize_assignments (softmax/sparsemax/entmax)
      - Weight EMA + child-link hysteresis
      - Optional top-k pruning after normalization
      - No full unassignment unless explicitly allowed
    Writes: child.labels/parent_ids/parent_id; parent.child_weights/child_ids
    """
    import numpy as np, config
    try:
        from scipy.ndimage import binary_dilation
    except Exception:
        binary_dilation = None
    from parent_utils import resize_nn  # nearest-neighbor resizer

    Ps = list(parents_by_id.values())
    Pn = len(Ps); I = len(children)
    if Pn == 0 or I == 0:
        for ch in children:
            ch.labels = {}; ch.parent_id = -1; ch.parent_ids = []
        for P in Ps:
            P.child_weights = {}; P.child_ids = ()
        return

    # ---------------- shapes & knobs ----------------
    H, W = np.asarray(children[0].mask, np.float32).shape[:2]
    if use_agreement is None:
        use_agreement = bool(getattr(config, "parent_assign_use_agreement", False))
    if agree_weight is None:
        agree_weight = float(getattr(config, "parent_assign_agree_weight", 1.0))
    knobs = _read_assign_knobs(config, use_agreement=use_agreement, agree_weight=agree_weight)
    knobs["temp"] = float(temp)  # allow caller override of temp

    # ---------------- child/parent masks & cores ----------------
    Cmb    = _stack_child_masks(children, eps)
    Pmasks = _stack_parent_masks(Ps)

    abs_core = float(core_tau if core_tau is not None else getattr(config, "core_abs_tau", 0.20))
    rel_core = float(core_tau_rel)
    ages = np.array([int(getattr(Ps[i], "_age", 0) or 0) for i in range(Pn)], dtype=int)

    Pcore = _parent_cores(
        Pmasks,
        abs_core=abs_core, rel_core=rel_core,
        ages=ages, newborn_steps=int(newborn_bootstrap_steps),
        dilate_px=int(core_dilate_px),
        binary_dilation=binary_dilation
    )

    # ---------------- agreement, IoU, validity ----------------
    A_map = _prepare_agreement_map(agreement_map, H, W, resize_nn) if knobs["use_agreement"] else None
    S, inter, valid = _compute_iou_on_core(Cmb, Pcore, tau=float(tau))
    A = _agreement_over_intersections(A_map, Cmb, Pcore, inter) if knobs["use_agreement"] else np.ones_like(S, dtype=np.float32)

    # ---------------- per-child distributions ----------------
    W = np.zeros((I, Pn), np.float32)
    entropy_list, top1_mass_list, null_mass_list, support_size_list = [], [], [], []

    for i in range(I):
        vmask, p_eff, p_null, probs_all = _per_child_distribution(i, valid[i], S, A, knobs)
        if vmask is None:
            continue

        idxs = np.where(vmask)[0]
        if p_eff is not None and p_eff.size:
            W[i, idxs] = p_eff

        # top-k AFTER normalization
        _apply_topk_inplace(W[i], idxs, max_parents_per_child)

        # robust fallback if disallowed unassignment
        if not allow_unassigned:
            _fallback_force_best_if_needed(
                W_row=W[i],
                null_enabled=knobs["null_enabled"],
                p_null=(0.0 if p_null is None else p_null),
                null_tau=knobs["null_tau"],
                S_row=S[i],
                vmask=vmask,
                Pn=Pn
            )

        # diagnostics
        row = W[i]
        if row.sum() > 0:
            nz = row[row > 0]; ent = -float(np.sum(nz * np.log(nz + 1e-20)))
            top1 = float(nz.max()) if nz.size else 1.0
            supp = int((row > 1e-3).sum())
        else:
            ent, top1, supp = 0.0, 1.0, 0
        entropy_list.append(ent); top1_mass_list.append(top1); null_mass_list.append(0.0 if p_null is None else float(p_null)); support_size_list.append(supp)

    # ---------------- EMA smoothing ----------------
    _ema_blend_assignments(W, Ps, children, float(knobs["weight_ema"]))

    # ---------------- link hysteresis (per parent) ----------------
    IoU = S  # signal for link EMA
    for p, P in enumerate(Ps):
        kept = _update_link_hysteresis_for_parent(
            P,
            iou_row=_build_iou_row_for_parent(IoU, W, children, p),
            child_ids_row=set(int(getattr(children[i], "id", i)) for i in np.where(W[:, p] > 0.0)[0]),
            theta_on=knobs["link_knobs"]["theta_on"],
            theta_off=knobs["link_knobs"]["theta_off"],
            beta=knobs["link_knobs"]["beta"],
            max_change=knobs["link_knobs"]["max_change"],
            min_kids=knobs["link_knobs"]["min_kids"],
        )
        _project_W_to_kept(W, children, p, kept)

    # ---------------- writeback ----------------
    _writeback_children(W, Ps, children, max_parents_per_child)
    _writeback_parents(W, Ps, children)

    # ---------------- hysteresis + grace keep ----------------
    _apply_grace_and_hysteresis(
        Ps, children,
        eps=float(eps),
        min_kids=knobs["link_knobs"]["min_kids"],
        keep_thr=float(getattr(config, "parent_assign_keep_thr", 0.10)),
        grace_keep=bool(getattr(config, "parent_assign_keep_during_grace", True)),
        W=W
    )

    # ---------------- debug summary ----------------
    if debug or bool(getattr(config, "debug_assign_summary", True)):
        _assign_debug_summary(W, entropy_list, top1_mass_list, null_mass_list, support_size_list, knobs, Ps)





# ====================== Cleaned parent-mask writer (main) ======================

def assign_parent_masks_from_alignment(ctx, children,
                                       generators_q, generators_p,
                                       *,
                                       mode="max",
                                       mask_tau=0.010,
                                       tau_q=None, tau_p=None, alpha=0.5,
                                       agree_map=None, agree_power=1.0,
                                       clamp_to_union=True,
                                       floor_eps=1e-6,
                                       min_pair_px=8,
                                       kl_cap=None,
                                       pnorm=99.0,
                                       return_changed=False,
                                       change_tol=None):
    """
    Smooth parent mask update (self-contained; no external reconcile step):
      - Evidence E_now via soft-min over child agreements
      - Coalition weighting W_comp (presence-weighted by soft gate around support τ)
      - Target M_tgt = (E_ema^etaE) * (W_comp^etaW) * g2_soft(count)
      - Final M_new = EMA toward M_tgt with per-step delta cap + newborn core floor
    Writes: each parent P.mask (float in [0,1]) and P.emerged (bool)
    """
    import numpy as np
    try:
        import config
    except Exception:
        class _Cfg: pass
        config = _Cfg()

    parents = getattr(ctx, "parents_by_region", {}) or {}
    if not parents or not children:
        return [] if return_changed else None

    # single-writer invariant (optional, keep if you use ctx.mask_writer)
    if hasattr(ctx, "mask_writer"):
        assert ctx.mask_writer == "alignment", f"Mask write blocked: ctx.mask_writer='{ctx.mask_writer}'"

    # shapes & knobs
    H, W = np.asarray(children[0].mask, np.float32).shape[:2]
    K = _mask_knobs(config, change_tol_override=change_tol)

    # per-child fields (agreement A and mask M) normalized to (H,W)
    id2A, id2M = _prepare_child_fields(children, H, W)

    # capture previous masks if caller wants a changed list
    prev_masks = {}
    if return_changed:
        for pid, P in parents.items():
            prev_masks[int(pid)] = np.asarray(getattr(P, "mask", np.zeros((H, W), np.float32)), np.float32)

    changed = []

    for pid, P in parents.items():
        # choose kids: prefer assigned set; if <2, union with base_ids for stability
        base_ids = list(getattr(P, "child_ids", []) or [])
        asg_ids  = list(getattr(P, "assigned_child_ids", []) or [])
        kids_ids = sorted(set(asg_ids)) if len(asg_ids) >= 2 else sorted(set(asg_ids) | set(base_ids))

        M_prev = _ensure_parent_state(ctx, P, H, W, K["freeze_steps"])

        # coalition broke → gentle decay + freeze-core keep
        if len(kids_ids) < 2:
            P.mask    = _apply_freeze_fade(ctx, P, M_prev,
                                           betaM=K["betaM"],
                                           core_tau=K["core_tau"],
                                           core_floor=K["core_floor"],
                                           dcap=K["dcap"])
            P.emerged = bool(np.any(P.mask > 0))
            if return_changed:
                _mark_changed_if_needed(P, prev_masks, H, W, K["change_tol"], changed)
            continue

        # stacks
        A_stack = np.stack([id2A.get(int(k), np.zeros((H, W), np.float32)) for k in kids_ids], axis=0)
        M_stack = np.stack([id2M.get(int(k), np.zeros((H, W), np.float32)) for k in kids_ids], axis=0)

        # evidence (soft-min power mean) with EMA
        E_now = _softmin_power_mean(A_stack, K["p_neg"])
        E_now = np.clip(np.nan_to_num(E_now, nan=0.0, posinf=1.0, neginf=0.0), 0.0, 1.0)
        E_ema = float(K["betaE"]) * P._ema_E + (1.0 - float(K["betaE"])) * E_now
        P._ema_E = E_ema.astype(np.float32)

        # presence gate & soft coalition count
        S_stack  = _presence_gate(M_stack, K["support_tau"], K["pres_delta"])   # [0,1]
        soft_cnt = np.sum(S_stack, axis=0)
        g2_soft  = _smoothstep(soft_cnt, K["count_lo"], K["count_hi"])          # [0,1]

        # coalition weights (presence & agreement & mask)
        W_num  = np.sum(S_stack * A_stack * M_stack, axis=0)
        W_den  = np.sum(S_stack * A_stack, axis=0)
        W_comp = np.divide(W_num, np.clip(W_den, 1e-9, None),
                           out=np.zeros_like(W_num), where=(W_den > 1e-9))
        W_comp = np.clip(np.nan_to_num(W_comp, nan=0.0, posinf=1.0, neginf=0.0), 0.0, 1.0)

        # target and EMA step with deadband + cap
        M_tgt = (np.power(E_ema, float(K["etaE"])) *
                 np.power(W_comp, float(K["etaW"])) *
                 g2_soft.astype(np.float32))
        M_tgt = np.clip(M_tgt, 0.0, 1.0)

        P.mask = _ema_toward_target(M_prev, M_tgt,
                                    betaM=K["betaM"], dcap=K["dcap"],
                                    deadband=K["deadband"], beta_jitter=K["beta_jitter"])
        P.emerged = bool(np.any(P.mask > 0))

        if return_changed:
            _mark_changed_if_needed(P, prev_masks, H, W, K["change_tol"], changed)

    return changed if return_changed else None



def build_alignment_aggregates(runtime_ctx, children, *, kl_cap=10.0):
    """
    Writes these onto runtime_ctx (H×W float32 each):
        - Aq_agg, KLq_agg  (agreement/KL from belief alignment)
        - Ap_agg, KLp_agg  (agreement/KL from model  alignment)

    Robust to missing caches and avoids any ambiguous array truth checks.
    """
    import numpy as np

    # ---------------- config ----------------
    try:
        import config
        tau_q = float(getattr(config, "tau_align_q", 0.45))
        tau_p = float(getattr(config, "tau_align_p", 0.45))
        kl_cap = float(getattr(config, "signal_kl_cap", kl_cap))
        reduce_mode = str(getattr(config, "agg_reduce_mode", "mean")).lower()  # "mean"|"max"|"p95"
        prefer_agreement_cache = bool(getattr(config, "agg_prefer_agreement_cache", True))
        ema = float(getattr(config, "agg_map_ema", 0.25))  # 0..1; weight for NEW value
    except Exception:
        tau_q = tau_p = 0.45
        reduce_mode = "mean"
        prefer_agreement_cache = True
        ema = 0.25

    eps = 1e-20

    # ---------------- shapes ----------------
    if not children or len(children) == 0:
        # nothing to do
        return

    # Safely infer (H, W)
    H, W = None, None
    for ch in children:
        if ch is None:
            continue
        m = getattr(ch, "mask", None)
        if isinstance(m, np.ndarray) and m.ndim >= 2:
            H, W = int(m.shape[0]), int(m.shape[1])
            break
    if (H is None) or (W is None):
        # fallback from any cached map
        for ch in children:
            A = getattr(ch, "spawn_A_final", None)
            if isinstance(A, np.ndarray) and A.ndim >= 2:
                H, W = int(A.shape[0]), int(A.shape[1])
                break
        if (H is None) or (W is None):
            return

    
    # ---------------- collect per-child maps ----------------
    Aq_list, KLq_list = [], []
    Ap_list, KLp_list = [], []

    for ch in children:
        if ch is None:
            continue

        # Prefer cached agreement (already \in [0,1]) if configured
        A_q = getattr(ch, "spawn_A_final", None) if prefer_agreement_cache else None
        if isinstance(A_q, np.ndarray):
            Aq_list.append(np.clip(_resize_to_hw(A_q), 0.0, 1.0))
        else:
            # otherwise try KL caches for q
            KLq = getattr(ch, "spawn_softmin_kl_q", None)
            if KLq is None:
                KLq = getattr(ch, "cached_alignment_kl", None)
            if isinstance(KLq, np.ndarray):
                KLq_list.append(np.clip(_resize_to_hw(KLq), 0.0, float(kl_cap)))

        A_p = getattr(ch, "spawn_A_final_p", None) if prefer_agreement_cache else None
        if isinstance(A_p, np.ndarray):
            Ap_list.append(np.clip(_resize_to_hw(A_p), 0.0, 1.0))
        else:
            KLp = getattr(ch, "spawn_softmin_kl_p", None)
            if KLp is None:
                KLp = getattr(ch, "cached_model_alignment_kl", None)
            if isinstance(KLp, np.ndarray):
                KLp_list.append(np.clip(_resize_to_hw(KLp), 0.0, float(kl_cap)))

    # ---------------- reduction helpers (NO ambiguous truth) ----------------
    def _reduce_agree(A_list, KL_list, tau):
        has_A = isinstance(A_list, list) and (len(A_list) > 0)
        has_K = isinstance(KL_list, list) and (len(KL_list) > 0)

        if has_A:
            A_stack = np.stack(A_list, axis=0)  # (N,H,W)
        elif has_K:
            KL_stack = np.stack(KL_list, axis=0)  # (N,H,W)
            A_stack = np.exp(-KL_stack / max(tau, 1e-8)).astype(np.float32)
        else:
            return None, None

        if reduce_mode == "mean":
            A_new = np.mean(A_stack, axis=0)
        elif reduce_mode == "max":
            A_new = np.max(A_stack, axis=0)
        elif reduce_mode in ("p95", "p-95", "q95"):
            A_new = np.percentile(A_stack, 95.0, axis=0)
        else:
            # default to mean for any unknown mode
            A_new = np.mean(A_stack, axis=0)

        A_new = np.clip(np.nan_to_num(A_new, nan=0.0, posinf=1.0, neginf=0.0), 0.0, 1.0)
        KL_new = (-max(tau, 1e-8) * np.log(np.maximum(A_new, eps))).astype(np.float32)
        return A_new.astype(np.float32), KL_new

    Aq_new, KLq_new = _reduce_agree(Aq_list, KLq_list, tau_q)
    Ap_new, KLp_new = _reduce_agree(Ap_list, KLp_list, tau_p)

    # ---------------- EMA smoothing (maps) ----------------
    if (ema > 0.0) and (ema < 1.0):
        Aq_prev = getattr(runtime_ctx, "Aq_agg", None)
        if (Aq_prev is not None) and (Aq_new is not None):
            Aq_prev = _resize_to_hw(Aq_prev)
            Aq_new = (1.0 - float(ema)) * Aq_prev + float(ema) * Aq_new
            KLq_new = (-max(tau_q, 1e-8) * np.log(np.maximum(Aq_new, eps))).astype(np.float32)

        Ap_prev = getattr(runtime_ctx, "Ap_agg", None)
        if (Ap_prev is not None) and (Ap_new is not None):
            Ap_prev = _resize_to_hw(Ap_prev)
            Ap_new = (1.0 - float(ema)) * Ap_prev + float(ema) * Ap_new
            KLp_new = (-max(tau_p, 1e-8) * np.log(np.maximum(Ap_new, eps))).astype(np.float32)

    # ---------------- write back ----------------
    if Aq_new is not None:
        runtime_ctx.Aq_agg  = np.asarray(Aq_new,  np.float32)
        runtime_ctx.KLq_agg = np.asarray(KLq_new, np.float32)
    else:
        runtime_ctx.Aq_agg  = None
        runtime_ctx.KLq_agg = None

    if Ap_new is not None:
        runtime_ctx.Ap_agg  = np.asarray(Ap_new,  np.float32)
        runtime_ctx.KLp_agg = np.asarray(KLp_new, np.float32)
    else:
        runtime_ctx.Ap_agg  = None
        runtime_ctx.KLp_agg = None
        
#=============================================================================#


def compute_and_set_auto_agree_gate(runtime_ctx, *, percentile=65.0, ema=0.2, use_p_if_q_missing=True):
    """
    Sets runtime_ctx.detector_state.agree_gate_tau_eff to a smoothed percentile
    of A_agg in [0,1]. If no aggregates exist, sets it to None (gate off).
    """
    import numpy as np
    ds = getattr(runtime_ctx, "detector_state", None)
    if ds is None:
        return

    A = getattr(runtime_ctx, "Aq_agg", None)
    if (A is None) and use_p_if_q_missing:
        A = getattr(runtime_ctx, "Ap_agg", None)

    if A is None:
        ds.agree_gate_tau_eff = None
        try:
            print("[AGG] auto agree gate: no aggregates, gate OFF")
        except Exception:
            pass
        return

    A = np.asarray(A, np.float32)
    good = np.isfinite(A)
    if not good.any():
        ds.agree_gate_tau_eff = None
        try:
            print("[AGG] auto agree gate: aggregates non-finite, gate OFF")
        except Exception:
            pass
        return

    thr = float(np.percentile(A[good], float(percentile)))
    prev = getattr(ds, "agree_gate_tau_eff", None)
    if (prev is None) or (not np.isfinite(prev)):
        new_tau = thr
    else:
        new_tau = (1.0 - float(ema)) * float(prev) + float(ema) * thr

    ds.agree_gate_tau_eff = float(new_tau)
    try:
        print(f"[AGG] auto agree gate p{int(percentile)} ema={ema} tau={new_tau:.3f}")
    except Exception:
        pass


def prune_orphan_parents(
    parents_by_id,
    *,
    patience=3,
    min_total_weight=1e-4,
    min_area_nz=5,
    support_tau=0.02,
    respect_grace=True,
    verbose=False,
):
    """
    Remove parents that carry ~no child weight or tiny support for `patience` consecutive steps.
    - Weight check: sum(child_weights) < min_total_weight
    - Area check:   count(mask > support_tau) < min_area_nz
    - Respects each parent's grace window (_grace) if `respect_grace=True`.
    Returns: list of pruned parent ids.
    """
    import numpy as np

    dead = []

    for pid, P in list(parents_by_id.items()):
        # ----- stats (NaN-safe) -----
        wsum = float(sum((getattr(P, "child_weights", {}) or {}).values()))
        if not np.isfinite(wsum):
            wsum = 0.0

        m = np.nan_to_num(np.asarray(getattr(P, "mask", 0.0), np.float32), nan=0.0, posinf=0.0, neginf=0.0)
        nz = int(np.count_nonzero(m > float(support_tau)))

        # ----- grace / age gate -----
        age   = int(getattr(P, "_age", 0) or 0)
        grace = int(getattr(P, "_grace", 0) or 0)
        in_grace = respect_grace and (age < grace)

        ticks = int(getattr(P, "_orphan_ticks", 0) or 0)

        if in_grace:
            # During grace, don't accrue orphan ticks; reset if any evidence appears
            if (wsum >= float(min_total_weight)) or (nz >= int(min_area_nz)):
                ticks = 0
            # else keep ticks at 0 (don’t penalize newborns)
        else:
            # Outside grace: accrue ticks when both signals are weak
            if (wsum < float(min_total_weight)) or (nz < int(min_area_nz)):
                ticks += 1
            else:
                ticks = 0

        P._orphan_ticks = ticks

        if (ticks >= int(patience)) and (not in_grace):
            dead.append(int(pid))

    for pid in dead:
        parents_by_id.pop(pid, None)

    if verbose and dead:
        print(f"[PRUNE] removed {len(dead)} parents: {dead}")

    return dead





def snapshot_parent_child_ids(parents_by_id):
    """Store previous child_ids on each parent for post-assignment guards."""
    for P in (parents_by_id or {}).values():
        try:
            P._prev_child_ids = tuple(getattr(P, "child_ids", ()) or ())
        except Exception:
            pass


def enforce_min_children_per_parent(parents_by_id, *, min_kids=2, respect_grace=True):
    """If assignment collapses a parent to < min_kids, revert to previous ids during grace."""
    for P in (parents_by_id or {}).values():
        try:
            cur = tuple(getattr(P, "child_ids", ()) or ())
            if len(cur) >= int(min_kids):
                continue
            prev = tuple(getattr(P, "_prev_child_ids", ()) or ())
            if respect_grace and int(getattr(P, "_grace", 0)) > 0 and len(prev) >= int(min_kids):
                P.child_ids = prev
        except Exception:
            pass




def build_child_parent_responsibilities(children, parents_by_id, *,
                                        mode="pixel",   # "pixel" or "global"
                                        eps=1e-6):
    """
    Compute child↔parent responsibilities so a child can belong to MULTIPLE parents.

    For each child c and parent P that lists c in P.child_ids:
      - mode="pixel":  r_{P|c}(y,x)  ∝  P.mask(y,x) over all such parents, normalized per-pixel.
      - mode="global": r_{P|c}       ∝  mean_{child-support} P.mask, normalized per-child (scalar).

    Effects (writes onto objects):
      child._parent_ids        = [pid,...]
      child._parent_resp_mask  = {pid: H×W float32}     (if mode="pixel")
      child._parent_resp       = {pid: float}           (if mode="global")
      parent._child_resp       = {cid: float}           (global scalar for diagnostics)
    """
    import numpy as np

    if not children or not parents_by_id:
        return

    # quick shape
    H, W = np.asarray(children[0].mask, np.float32).shape[:2]

    # build reverse index: parent -> set(child_ids) already exists via P.child_ids
    # we also want, for each child, the set of parents that include it
    child_to_parents = {int(getattr(ch, "id", -1)): [] for ch in children}
    for pid, P in (parents_by_id or {}).items():
        for cid in (getattr(P, "child_ids", []) or []):
            cid = int(cid)
            if cid in child_to_parents:
                child_to_parents[cid].append(int(pid))

    # prefetch parent masks
    pid2mask = {int(pid): np.asarray(getattr(P, "mask", np.zeros((H, W), np.float32)), np.float32)
                for pid, P in (parents_by_id or {}).items()}

    for ch in children:
        cid = int(getattr(ch, "id", -1))
        pids = child_to_parents.get(cid, [])
        setattr(ch, "_parent_ids", list(pids))

        if len(pids) == 0:
            setattr(ch, "_parent_resp_mask", {})
            setattr(ch, "_parent_resp", {})
            continue

        cmask = np.clip(np.asarray(getattr(ch, "mask", np.zeros((H, W), np.float32)), np.float32), 0.0, 1.0)

        if mode == "pixel":
            # stack parent masks and normalize per-pixel over parents that include this child
            stack = np.stack([pid2mask[int(pid)] for pid in pids], axis=0)  # (P,H,W)
            # restrict to child support to reduce speckle
            stack = stack * cmask[None, :, :]

            denom = np.maximum(np.sum(stack, axis=0), eps)  # (H,W)
            resp_masks = [(stack[i] / denom).astype(np.float32) for i in range(len(pids))]

            resp_map = {int(pid): resp_masks[i] for i, pid in enumerate(pids)}
            setattr(ch, "_parent_resp_mask", resp_map)
            setattr(ch, "_parent_resp", {})

            # for diagnostics: global scalar responsibility per parent (mean over child support)
            for i, pid in enumerate(pids):
                mean_w = float(np.mean(resp_masks[i][cmask > 0.0])) if np.any(cmask > 0.0) else 0.0
                P = parents_by_id.get(int(pid))
                if P is not None:
                    d = getattr(P, "_child_resp", None) or {}
                    d[cid] = mean_w
                    setattr(P, "_child_resp", d)

        else:  # mode == "global"
            # global weight ∝ mean parent mask over the child's support
            weights = []
            for pid in pids:
                pm = pid2mask[int(pid)]
                if np.any(cmask > 0.0):
                    w = float(np.mean(pm[cmask > 0.0]))
                else:
                    w = 0.0
                weights.append(max(w, 0.0))

            wsum = float(sum(weights)) if sum(weights) > 0.0 else 1.0
            norm = [float(w) / wsum for w in weights]

            resp = {int(pid): float(norm[i]) for i, pid in enumerate(pids)}
            setattr(ch, "_parent_resp", resp)
            setattr(ch, "_parent_resp_mask", {})

            for i, pid in enumerate(pids):
                P = parents_by_id.get(int(pid))
                if P is not None:
                    d = getattr(P, "_child_resp", None) or {}
                    d[cid] = float(norm[i])
                    setattr(P, "_child_resp", d)






def _parent_cores(Pmasks, *, abs_core, rel_core, ages, newborn_steps, dilate_px, binary_dilation):
    """
    Build boolean cores for each parent with newborn relax and optional dilation.
    Pmasks: (Pn,H,W) float32 in [0,1]
    Returns: (Pn,H,W) bool
    """
    import numpy as np
    Pn, H, W = Pmasks.shape
    pm_max = Pmasks.reshape(Pn, -1).max(axis=1) if Pmasks.size else np.zeros(Pn, np.float32)
    thr = np.maximum(abs_core, rel_core * pm_max).astype(np.float32)
    relax = (np.asarray(ages, int) < int(newborn_steps))
    thr = thr * np.where(relax, 0.6, 1.0).astype(np.float32)   # newborn relax
    core = (Pmasks > thr[:, None, None])
    if int(dilate_px) and (binary_dilation is not None):
        it = int(dilate_px)
        core = np.stack([binary_dilation(core[p], iterations=it) for p in range(Pn)], axis=0)
    return core



def _ema_blend_assignments(W, Ps, children, weight_ema):
    """
    Blend current assignment weights with previous per-parent weights to reduce thrash.
    Mutates W in place.
    """
    
    I, Pn = W.shape
    for p, P in enumerate(Ps):
        prev = getattr(P, "child_weights", None) or {}
        if not prev:
            continue
        for i in range(I):
            cid = int(getattr(children[i], "id", i))
            old = float(prev.get(cid, 0.0))
            new = float(W[i, p])
            if old > 0.0 or new > 0.0:
                W[i, p] = float(weight_ema) * old + (1.0 - float(weight_ema)) * new




def _as_parent_dict(obj):
    """
    Normalize parents -> {pid: Parent}. Accepts dict, list, iterable, or None.
    Uses the parent's .id if present; else falls back to enumerate index.
    """
    import collections.abc as _abc
    if obj is None:
        return {}
    if isinstance(obj, dict):
        return {int(getattr(p, "id", pid)): p for pid, p in obj.items()}
    if isinstance(obj, _abc.Iterable):
        return {int(getattr(p, "id", i)): p for i, p in enumerate(obj)}
    # Single parent object?
    return {int(getattr(obj, "id", 0)): obj}




