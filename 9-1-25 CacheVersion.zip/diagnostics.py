"""
generalized_diagnostics_metrics.py — Phase 2 (ctx+cache, uses your stack)

Implements (objective-faithful):
  • Self:     α_belief · KL(q || Φ̃ · p)
  • Feedback: λ        · KL(p || Φ  · q)
  • Mass:     ω_mass_* · ||φ||² over mask
  • Curvature:ω_curv_* · ||F||²  (uses your omega/transport_cache)

All configuration is read from ctx.config (no global config usage).
"""

from __future__ import annotations
from typing import Any, Mapping, Sequence, Dict, Optional, Tuple
import numpy as np

# ── Your modules (flexible import paths) ─────────────────────────────────

from transport.transport_cache import Phi as tc_Phi  # type: ignore
from transport.transport_cache import plaquette_product as tc_plaquette  # type: ignore
from core.gaussian_core import kl_gaussian, push_gaussian  # type: ignore
from core.numerical_utils import sanitize_sigma  # type: ignore
from core.omega import compute_field_strength  # type: ignore

from transport.transport_cache import Omega as tc_Omega  # type: ignore


from core.gaussian_core import push_gaussian, kl_gaussian as kl_divergence  # type: ignore


# ── Small local helpers ─────────────────────────────────────────────────
def _cfg_req(ctx, key: str) -> float:
    cfg = getattr(ctx, "config", None)
    if not isinstance(cfg, dict) or key not in cfg:
        raise KeyError(f"[diagnostics] missing required config key '{key}' in ctx.config")
    return float(cfg[key])

def _mask_bool(mask, tau: float):
    m = np.asarray(mask, np.float32)
    if m.ndim != 2:
        raise ValueError(f"mask must be (H,W); got {m.shape}")
    return m > tau




def _guess_generators(agent, which: str) -> np.ndarray:
    """
    Return a (K, K, 3) stack of Lie algebra generators for the requested fiber.
    Accepts several common attribute names on the agent; picks the first valid one.
    Validates shape: square matrices with a trailing axis of size 3.
    """
    which = which.lower()
    cand_map = {
        "q": ("generators_q", "G_q", "rho_q_generators", "generators", "basis_q"),
        "p": ("generators_p", "G_p", "rho_p_generators", "generators_model", "basis_p"),
    }
    if which not in cand_map:
        raise ValueError(f"_guess_generators: unknown fiber '{which}' (expected 'q' or 'p')")

    for name in cand_map[which]:
        G = getattr(agent, name, None)
        if G is None:
            continue
        G = np.asarray(G)
        if G.ndim == 3 and G.shape[0] == G.shape[1] and G.shape[2] == 3:
            return G.astype(np.float32, copy=False)

    # Nothing matched; build a helpful error message with what we actually found
    found = {name: getattr(agent, name).__class__.__name__
             for name in cand_map[which] if getattr(agent, name, None) is not None}
    raise AttributeError(
        f"_guess_generators: no suitable generators found for fiber '{which}'. "
        f"Tried {cand_map[which]}; found={found or 'none'}. "
        "Expected shape (K,K,3) with square K."
    )


def _as_bool_mask(mask: np.ndarray, tau: float) -> np.ndarray:
    m = np.asarray(mask, dtype=np.float32)
    if m.ndim != 2:
        raise ValueError(f"mask must be (H,W); got {m.shape}")
    return m > float(tau)

def _active_px(mask_bool: np.ndarray) -> int:
    return int(np.asarray(mask_bool, bool).sum())

def _spd_fallback(S: np.ndarray, eps: float) -> np.ndarray:
    S = 0.5 * (S + np.swapaxes(S, -1, -2))
    eye = np.eye(S.shape[-1], dtype=S.dtype)
    return S + eps * eye

def _spd(S: np.ndarray, eps: float) -> np.ndarray:
    if sanitize_sigma is None:
        return _spd_fallback(np.asarray(S, np.float32), eps)
    return sanitize_sigma(np.asarray(S, np.float32), eps=eps)  # type: ignore

def _reduce(field: np.ndarray, mask: np.ndarray, kind: str) -> float:
    f = np.asarray(field, np.float32)
    m = np.asarray(mask, bool)
    if f.shape != m.shape:
        raise ValueError(f"reduce mismatch: field {f.shape} vs mask {m.shape}")
    if not m.any():
        return 0.0
    if kind == "sum":
        return float(f[m].sum())
    if kind == "mean":
        return float(f[m].mean())
    raise ValueError(f"unknown reduce kind {kind}")

def _failfast(*xs: np.ndarray, where: str = "") -> None:
    for x in xs:
        if x is None:
            raise ValueError(f"{where}: None input")
        if not np.isfinite(np.asarray(x)).all():
            raise FloatingPointError(f"{where}: non-finite values")



def _materialize_morphism(M_full, H, W, Kout, Kin, r, c):
    """
    Normalize a morphism representation to either:
      - (Kout, Kin)  (global matrix), or
      - (M, Kout, Kin)  (per-active-pixel batch)
    Accepts inputs shaped:
      - (Kout, Kin)
      - (M, Kout, Kin)         # already sliced by caller
      - (H, W, Kout, Kin)      # per-pixel field -> we index with (r,c)
    """
    import numpy as np
    M = np.asarray(M_full, np.float32)
    if M.ndim == 2 and M.shape == (Kout, Kin):
        return M  # global morphism
    if M.ndim == 3 and M.shape[1:] == (Kout, Kin):
        # assume already per-item (M == len(r))
        if M.shape[0] != len(r):
            raise ValueError(f"morphism batch length {M.shape[0]} != active pixels {len(r)}")
        return M
    if M.ndim == 4 and M.shape[:2] == (H, W) and M.shape[2:] == (Kout, Kin):
        return M[r, c]  # (M, Kout, Kin)
    raise ValueError(f"unexpected morphism shape {M.shape}; expected (Kout,Kin), (M,Kout,Kin), or (H,W,Kout,Kin)")



def _as_f32(x):
    return np.asarray(x, np.float32)





def _fiber_views(A, which: str):
    """
    Return (mu, Sigma, phi, generators, K) for requested fiber.
    Accepts common attribute spellings; validates shapes.
    """
    which = which.lower()
    H, W = A.mask.shape

    if which == "q":
        mu  = getattr(A, "mu_q_field",  None)
        Sig = getattr(A, "sigma_q_field", None)
        phi = getattr(A, "phi_field",   getattr(A, "phi", None))
        G   = getattr(A, "generators_q", getattr(A, "G_q", None))
    elif which == "p":
        mu  = getattr(A, "mu_p_field",  None)
        Sig = getattr(A, "sigma_p_field", None)
        phi = getattr(A, "phi_model_field", getattr(A, "phi_model", None))
        G   = getattr(A, "generators_p", getattr(A, "G_p", None))
    else:
        raise ValueError("which must be 'q' or 'p'")

    if mu is None or Sig is None or phi is None:
        raise AttributeError(f"agent missing fields for fiber '{which}'")

    mu  = _as_f32(mu)
    Sig = _as_f32(Sig)
    phi = _as_f32(phi)

    if mu.shape[:2] != (H, W):
        raise ValueError(f"mu shape {mu.shape} incompatible with mask {(H,W)}")
    if Sig.shape[:2] != (H, W) or Sig.shape[-1] != Sig.shape[-2] or mu.shape[-1] != Sig.shape[-1]:
        raise ValueError(f"Sigma shape {Sig.shape} incompatible with mu {mu.shape}")

    K = int(mu.shape[-1])
    return mu, Sig, phi, (None if G is None else _as_f32(G)), K


def compute_alignment_field(
    agents, i, *, which="q", ctx=None,
    eps=None, log_eps=None, kl_cap=None, neighbor_tau=None, min_pair_px=None,
):
    """
    Energy-faithful alignment field for agent i:
      out(y,x) = sum_{j in N(i)} KL( N_i || Ω_ij ▷ N_j ) over overlapping neighbors,
    with NO averaging and NO caps. Suitable to integrate (sum) directly into the
    total variational energy after multiplying by the term weight.

    Notes:
      - Uses ctx.config for all thresholds/eps (no globals).
      - Ω pulled from transport cache (per-pixel (H,W,K,K)); sliced on overlap.
      - SPD is sanitized minimally (eps·I + symmetrize) via your sanitizer.
      - If A.neighbors exists (list of dicts with {"id": j}), it’s honored;
        otherwise we pick neighbors by overlap heuristic (deterministic).
    """
    if ctx is None:
        raise ValueError("compute_alignment_field requires ctx for transport/cache")

    cfg = getattr(ctx, "config", {}) or {}
    A = agents[i]

    # unified epsilon for energy terms (tiny, fixed)
    eps_val = float(cfg.get("energy_eps", 1e-6) if eps is None else eps)

    # neighbor selection (heuristic only; does not affect integration weights)
    neighbor_tau = float(cfg.get("overlap_eps", 0.20) if neighbor_tau is None else neighbor_tau)
    min_pair_px  = int(cfg.get("min_pair_px", 8) if min_pair_px is None else min_pair_px)

    # integration domain = support via threshold
    support_tau = float(cfg.get("support_cutoff_eps", 1e-3))
    mask_i = _as_bool_mask(getattr(A, "mask", None), support_tau)
    if mask_i is None or not np.any(mask_i):
        # return shape-compatible zeros
        base = getattr(A, "mask", None)
        return np.zeros_like(_as_f32(base) if base is not None else np.zeros((1, 1), np.float32), np.float32)

    # neighbors (prefer precomputed list)
    nb_list = getattr(A, "neighbors", None)
    if not nb_list:
        nb_list = []
        Ai_m = _as_f32(A.mask)
        for j, B in enumerate(agents):
            if j == i:
                continue
            m_j = _as_bool_mask(getattr(B, "mask", None), support_tau)
            if m_j is None or not np.any(m_j):
                continue
            inter = (Ai_m > neighbor_tau) & (_as_f32(B.mask) > neighbor_tau)
            if int(inter.sum()) >= min_pair_px:
                nb_list.append({"id": j})

    if not nb_list:
        return np.zeros_like(_as_f32(A.mask), np.float32)

    # choose fiber views
    mu_i_full, S_i_full, _phi_i_full, _G_i, K = _fiber_views(A, which)
    H, W = A.mask.shape

    # accumulate SUM over neighbors (no averaging)
    kl_sum = np.zeros((H, W), np.float32)

    for nb in nb_list:
        j = int(nb["id"])
        B = agents[j]
        mask_j = _as_bool_mask(getattr(B, "mask", None), support_tau)
        if mask_j is None or not np.any(mask_j):
            continue

        # overlap = integration domain for this pair
        overlap = mask_i & mask_j
        if not np.any(overlap):
            continue

        mu_j_full, S_j_full, _phi_j_full, _G_j, _Kj = _fiber_views(B, which)
        if _Kj != K:
            # It’s valid for q/p to differ across fibers, but same 'which' must match K
            raise ValueError(f"fiber dim mismatch for which='{which}': Ai K={K}, Aj K={_Kj}")

        # Slice to overlap (M pixels)
        mu_i = _as_f32(mu_i_full)[overlap]                             # (M,K)
        S_i  = sanitize_sigma(_as_f32(S_i_full)[overlap], eps=eps_val) # (M,K,K)
        mu_j = _as_f32(mu_j_full)[overlap]
        S_j  = sanitize_sigma(_as_f32(S_j_full)[overlap], eps=eps_val)

        # Ω from transport cache (per-pixel) → slice to overlap (M,K,K)
        Om_full = tc_Omega(ctx, A, B, which=which)                     # (H,W,K,K) or broadcastable
        Omega   = _as_f32(Om_full)[overlap]                            # (M,K,K)

        # push N_j by Ω into i’s fiber; exact push; SPD sanitize only
        mu_j_t, S_j_t = push_gaussian(
            mu=mu_j, Sigma=S_j, M=Omega,
            eps=eps_val, symmetrize=True, sanitize=True, approx="exact"
        )

        # KL at overlap pixels; floor to [0,∞)
        kl_vals = kl_divergence(mu_i, S_i, mu_j_t, S_j_t, eps=eps_val)
        kl_vals = np.where(np.isfinite(kl_vals), kl_vals, 0.0)
        kl_vals = np.maximum(kl_vals, 0.0).astype(np.float32, copy=False)

        # scatter-add into SUM (no averaging)
        idx = np.argwhere(overlap)
        r, c = idx[:, 0], idx[:, 1]
        np.add.at(kl_sum, (r, c), kl_vals)

    # zero outside Ai support; return SUM over neighbors
    return kl_sum * mask_i.astype(np.float32, copy=False)


def _energy_alignment(ctx, agents):
    """
    Returns (align_q_sum, align_q_mean, align_p_sum, align_p_mean), already weight-scaled.
    Uses:
      - beta       (q-side coupling)
      - beta_model (p-side coupling)
    """
    if compute_alignment_field is None:
        return 0.0, 0.0, 0.0, 0.0

    tau = _cfg_req(ctx, "support_cutoff_eps")
    wq  = _cfg_req(ctx, "beta")
    wp  = _cfg_req(ctx, "beta_model")

    if wq == 0.0 and wp == 0.0:
        return 0.0, 0.0, 0.0, 0.0

    sum_q = 0.0
    sum_p = 0.0
    S_tot = 0

    for i, A in enumerate(agents):
        mask = _mask_bool(A.mask, tau)
        if not mask.any():
            continue
        S_tot += int(mask.sum())

        if wq != 0.0:
            fq = np.asarray(compute_alignment_field(agents, i, which="q", ctx=ctx), np.float32)
            if fq.shape != mask.shape:
                raise ValueError(f"align(q) shape {fq.shape} != mask {mask.shape}")
            sum_q += float(fq[mask].sum())

        if wp != 0.0:
            fp = np.asarray(compute_alignment_field(agents, i, which="p", ctx=ctx), np.float32)
            if fp.shape != mask.shape:
                raise ValueError(f"align(p) shape {fp.shape} != mask {mask.shape}")
            sum_p += float(fp[mask].sum())

    if S_tot <= 0:
        return 0.0, 0.0, 0.0, 0.0

    return (
        wq * sum_q,
        wq * (sum_q / S_tot),
        wp * sum_p,
        wp * (sum_p / S_tot),
    )




def _energy_self_feedback(ctx: Any, agent: Any) -> Tuple[float, float, float, float]:
    """
    Returns (self_sum, self_mean, fb_sum, fb_mean), weight-scaled.
    Works with Φ/Φ̃ provided either as global matrices or per-pixel fields.
    """
    eps = _cfg_req(ctx, "energy_eps")
    tau = _cfg_req(ctx, "support_cutoff_eps")
    w_self = _cfg_req(ctx, "alpha")
    w_fb   = _cfg_req(ctx, "feedback_weight")
    
    mask = _mask_bool(agent.mask, tau)
    if not mask.any():
        return 0.0, 0.0, 0.0, 0.0

    mu_q = np.asarray(agent.mu_q_field, np.float32)   # (H,W,Kq)
    S_q  = np.asarray(agent.sigma_q_field, np.float32)  # (H,W,Kq,Kq)
    mu_p = np.asarray(agent.mu_p_field, np.float32)   # (H,W,Kp)
    S_p  = np.asarray(agent.sigma_p_field, np.float32)  # (H,W,Kp,Kp)
    H, W, Kq = mu_q.shape
    _, _, Kp = mu_p.shape
    if S_q.shape != (H, W, Kq, Kq) or S_p.shape != (H, W, Kp, Kp):
        raise ValueError("Sigma shapes do not match mu shapes")

    # Cache-first morphisms from your transport layer
    Phi_q_to_p = tc_Phi(ctx, agent, kind="q_to_p")  # could be (Kp,Kq) or (H,W,Kp,Kq)
    Phi_p_to_q = tc_Phi(ctx, agent, kind="p_to_q")  # could be (Kq,Kp) or (H,W,Kq,Kp)

    # Active pixels
    rrcc = np.argwhere(mask)
    r, c = rrcc[:, 0], rrcc[:, 1]
    mu_q_m, S_q_m = mu_q[r, c], _spd(S_q[r, c], eps)
    mu_p_m, S_p_m = mu_p[r, c], _spd(S_p[r, c], eps)

    # Materialize per-active-pixel morphisms if needed
    M_p_to_q = _materialize_morphism(Phi_p_to_q, H, W, Kq, Kp, r, c)  # (Kq,Kp) or (M,Kq,Kp)
    M_q_to_p = _materialize_morphism(Phi_q_to_p, H, W, Kp, Kq, r, c)  # (Kp,Kq) or (M,Kp,Kq)

    # Self: KL(q || Φ̃·p)
    mu_pt, S_pt = push_gaussian(mu_p_m, S_p_m, M_p_to_q, eps=eps)
    kl_self     = kl_gaussian(mu_q_m, S_q_m, mu_pt, S_pt, eps=eps)
    self_sum    = w_self * float(kl_self.sum())
    self_mean   = w_self * (float(kl_self.mean()) if kl_self.size else 0.0)

    # Feedback: KL(p || Φ·q)
    mu_qt, S_qt = push_gaussian(mu_q_m, S_q_m, M_q_to_p, eps=eps)
    kl_fb       = kl_gaussian(mu_p_m, S_p_m, mu_qt, S_qt, eps=eps)
    fb_sum      = w_fb * float(kl_fb.sum())
    fb_mean     = w_fb * (float(kl_fb.mean()) if kl_fb.size else 0.0)

    return self_sum, self_mean, fb_sum, fb_mean



def _energy_mass(ctx: Any, agent: Any) -> Tuple[float, float, float, float]:
    """Returns (mass_q_sum, mass_q_mean, mass_p_sum, mass_p_mean)."""
    tau = _cfg_req(ctx, "support_cutoff_eps")
    wq  = _cfg_req(ctx, "belief_mass")
    wp  = _cfg_req(ctx, "model_mass")
    
    mask = _mask_bool(agent.mask, tau)
    if not mask.any():
        return 0.0, 0.0, 0.0, 0.0

    phi_q = np.asarray(agent.phi, np.float32)       # (H,W,3)
    phi_p = np.asarray(agent.phi_model, np.float32) # (H,W,3)
    if phi_q.ndim != 3 or phi_q.shape[-1] != 3 or phi_p.ndim != 3 or phi_p.shape[-1] != 3:
        raise ValueError("phi_field/phi_model_field must be (H,W,3)")

    m_q = (phi_q ** 2).sum(axis=-1)  # ||φ||²
    m_p = (phi_p ** 2).sum(axis=-1)
    return (
        wq * _reduce(m_q, mask, "sum"),
        wq * _reduce(m_q, mask, "mean"),
        wp * _reduce(m_p, mask, "sum"),
        wp * _reduce(m_p, mask, "mean"),
    )

def _pick_generators(agent, names):
    for nm in names:
        G = getattr(agent, nm, None)
        if G is not None:
            return G
    return None

def _energy_curvature(ctx: Any, agent: Any) -> Tuple[float, float, float, float]:
    """
    Returns (curv_q_sum, curv_q_mean, curv_p_sum, curv_p_mean).

    Preferred backend:
      omega.compute_field_strength(phi, generators, dx) -> {"xy": F_xy}
        with F_xy shape (H, W, K, K)
      magnitude per site = ||F_xy||_F^2

    Fallback:
      transport_cache.plaquette_product(...) -> P (H, W, K, K)
      magnitude per site = ||P - I||_F^2
    """

    tau = _cfg_req(ctx, "support_cutoff_eps")
    dx  = _cfg_req(ctx, "grid_dx")
    wq  = _cfg_req(ctx, "curvature_weight")
    wp  = _cfg_req(ctx, "model_curvature_weight")
    mask = _mask_bool(agent.mask, tau)
    
    if not mask.any():
        return 0.0, 0.0, 0.0, 0.0

    # --- Try omega.compute_field_strength first (preferred) ---
    if compute_field_strength is not None:
        # q-fiber
        Gq = _pick_generators(agent, ("generators_q", "G_q"))
        if Gq is None:
            Gq = _guess_generators(agent, "q")
        Fq_dict = compute_field_strength(np.asarray(agent.phi, np.float32), np.asarray(Gq, np.float32), dx=dx)
        Fq_xy   = Fq_dict.get("xy")
        if Fq_xy is None:
            raise ValueError("compute_field_strength returned no 'xy' component for q-fiber")
        fq = np.linalg.norm(Fq_xy, ord="fro", axis=(-2, -1)) ** 2  # (H,W)

        # p-fiber
        Gp = _pick_generators(agent, ("generators_p", "G_p"))
        if Gp is None:
            Gp = _guess_generators(agent, "p")
        Fp_dict = compute_field_strength(np.asarray(agent.phi_model, np.float32), np.asarray(Gp, np.float32), dx=dx)
        Fp_xy   = Fp_dict.get("xy")
        if Fp_xy is None:
            raise ValueError("compute_field_strength returned no 'xy' component for p-fiber")
        fp = np.linalg.norm(Fp_xy, ord="fro", axis=(-2, -1)) ** 2  # (H,W)

        return (
            wq * _reduce(fq, mask, "sum"),
            wq * _reduce(fq, mask, "mean"),
            wp * _reduce(fp, mask, "sum"),
            wp * _reduce(fp, mask, "mean"),
        )

    # --- Fallback: plaquette_product (if omega backend unavailable) ---
    if tc_plaquette is None:
        raise ImportError("No curvature backend available: omega.compute_field_strength and transport_cache.plaquette_product are both missing.")

    # belief side
    Gq = getattr(agent, "generators_q", None) or getattr(agent, "G_q", None)
    if Gq is None:
        Gq = _guess_generators(agent, "q")
    Pq = np.asarray(tc_plaquette(ctx, agent.phi_field, np.asarray(Gq, np.float32), boundary="periodic"), np.float32)  # (H,W,K,K)
    if Pq.ndim != 4 or Pq.shape[-1] != Pq.shape[-2]:
        raise ValueError(f"Invalid plaquette (q) shape {Pq.shape}")
    Kq = Pq.shape[-1]
    fq = np.linalg.norm(Pq - np.eye(Kq, dtype=np.float32), ord="fro", axis=(-2, -1)) ** 2

    # model side
    Gp = getattr(agent, "generators_p", None) or getattr(agent, "G_p", None)
    if Gp is None:
        Gp = _guess_generators(agent, "p")
    Pp = np.asarray(tc_plaquette(ctx, agent.phi_model_field, np.asarray(Gp, np.float32), boundary="periodic"), np.float32)
    if Pp.ndim != 4 or Pp.shape[-1] != Pp.shape[-2]:
        raise ValueError(f"Invalid plaquette (p) shape {Pp.shape}")
    Kp = Pp.shape[-1]
    fp = np.linalg.norm(Pp - np.eye(Kp, dtype=np.float32), ord="fro", axis=(-2, -1)) ** 2

    return (
        wq * _reduce(fq, mask, "sum"),
        wq * _reduce(fq, mask, "mean"),
        wp * _reduce(fp, mask, "sum"),
        wp * _reduce(fp, mask, "mean"),
    )


# ── Public surface ──────────────────────────────────────────────────────
def compute_agent_metrics(ctx: Any, agent: Any) -> Dict[str, float]:
    self_sum, self_mean, fb_sum, fb_mean = _energy_self_feedback(ctx, agent)
    mass_q_sum, mass_q_mean, mass_p_sum, mass_p_mean = _energy_mass(ctx, agent)
    curv_q_sum, curv_q_mean, curv_p_sum, curv_p_mean = _energy_curvature(ctx, agent)
    return {
        "self_sum": self_sum, "self_mean": self_mean,
        "feedback_sum": fb_sum, "feedback_mean": fb_mean,
        "mass_q_sum": mass_q_sum, "mass_q_mean": mass_q_mean,
        "mass_p_sum": mass_p_sum, "mass_p_mean": mass_p_mean,
        "curv_q_sum": curv_q_sum, "curv_q_mean": curv_q_mean,
        "curv_p_sum": curv_p_sum, "curv_p_mean": curv_p_mean,
    }


def compute_global_metrics(ctx: Any, agents: Sequence[Any]) -> Dict[str, float]:
    tau = _cfg_req(ctx, "support_cutoff_eps")
    totals = {
        "self_sum": 0.0, "feedback_sum": 0.0,
        "mass_q_sum": 0.0, "mass_p_sum": 0.0,
        "curv_q_sum": 0.0, "curv_p_sum": 0.0,
        "_S": 0,
    }
    for a in agents:
        m = _as_bool_mask(a.mask, tau)
        S = _active_px(m)
        if S <= 0:
            continue
        d = compute_agent_metrics(ctx, a)
        for k in ("self_sum", "feedback_sum", "mass_q_sum", "mass_p_sum", "curv_q_sum", "curv_p_sum"):
            totals[k] += float(d[k])
        totals["_S"] += S

        # alignment (computed once across agents; uses neighbors)
    align_q_sum, align_q_mean, align_p_sum, align_p_mean = _energy_alignment(ctx, agents)

    S_tot = max(totals["_S"], 1)
    out = dict(totals)

    # base means
    out["self_mean"]     = out["self_sum"]     / S_tot
    out["feedback_mean"] = out["feedback_sum"] / S_tot
    out["mass_q_mean"]   = out["mass_q_sum"]   / S_tot
    out["mass_p_mean"]   = out["mass_p_sum"]   / S_tot
    out["curv_q_mean"]   = out["curv_q_sum"]   / S_tot
    out["curv_p_mean"]   = out["curv_p_sum"]   / S_tot

    # alignment terms
    out["align_q_sum"]  = align_q_sum
    out["align_q_mean"] = align_q_mean
    out["align_p_sum"]  = align_p_sum
    out["align_p_mean"] = align_p_mean

    # totals including alignment
    out["E_total"] = float(
        out["self_sum"] + out["feedback_sum"] +
        out["mass_q_sum"] + out["mass_p_sum"] +
        out["curv_q_sum"] + out["curv_p_sum"] +
        out["align_q_sum"] + out["align_p_sum"]
    )
    out["mean_total"] = float(
        out["self_mean"] + out["feedback_mean"] +
        out["mass_q_mean"] + out["mass_p_mean"] +
        out["curv_q_mean"] + out["curv_p_mean"] +
        out["align_q_mean"] + out["align_p_mean"]
    )
    return out



def print_energy_breakdown(ctx, metrics_global, *, stream=None) -> None:
    step = int(getattr(ctx, "global_step", -1))
    w_self = _cfg_req(ctx, "alpha")
    w_fb   = _cfg_req(ctx, "feedback_weight") if "feedback_weight" in ctx.config else 0.0
    w_mq   = _cfg_req(ctx, "belief_mass")
    w_mp   = _cfg_req(ctx, "model_mass")
    w_cq   = _cfg_req(ctx, "curvature_weight")
    w_cp   = _cfg_req(ctx, "model_curvature_weight")
    w_aq   = _cfg_req(ctx, "beta")         # alignment q
    w_ap   = _cfg_req(ctx, "beta_model")   # alignment p
    lines = []
    lines.append(f"[Energy Totals @ step {step}]")
    lines.append(f"  E_total = {metrics_global.get('E_total', 0.0):.6e}  |  mean_total = {metrics_global.get('mean_total', 0.0):.6e}")
    lines.append("  ----------------------------------------------------")
    lines.append("  term         weighted_sum            mean_per_px        weight")
    lines.append(f"  self         {metrics_global.get('self_sum', 0.0):>14.6e}    {metrics_global.get('self_mean', 0.0):>14.6e}    {w_self:g}")
    lines.append(f"  align_q      {metrics_global.get('align_q_sum', 0.0):>14.6e}    {metrics_global.get('align_q_mean', 0.0):>14.6e}    {w_aq:g}")
    lines.append(f"  align_p      {metrics_global.get('align_p_sum', 0.0):>14.6e}    {metrics_global.get('align_p_mean', 0.0):>14.6e}    {w_ap:g}")
    lines.append(f"  feedback     {metrics_global.get('feedback_sum', 0.0):>14.6e}    {metrics_global.get('feedback_mean', 0.0):>14.6e}    {w_fb:g}")
    lines.append(f"  mass_q       {metrics_global.get('mass_q_sum', 0.0):>14.6e}    {metrics_global.get('mass_q_mean', 0.0):>14.6e}    {w_mq:g}")
    lines.append(f"  mass_p       {metrics_global.get('mass_p_sum', 0.0):>14.6e}    {metrics_global.get('mass_p_mean', 0.0):>14.6e}    {w_mp:g}")
    lines.append(f"  curv_q       {metrics_global.get('curv_q_sum', 0.0):>14.6e}    {metrics_global.get('curv_q_mean', 0.0):>14.6e}    {w_cq:g}")
    lines.append(f"  curv_p       {metrics_global.get('curv_p_sum', 0.0):>14.6e}    {metrics_global.get('curv_p_mean', 0.0):>14.6e}    {w_cp:g}")
    
    
    
    txt = "\n".join(lines)
    if callable(getattr(ctx, "log", None)): ctx.log(txt)
    else: print(txt, file=stream or None)



def snapshot_scalars(
    ctx: Any,
    agents: Sequence[Any],
    outdir: str | None,
    metrics_global: Mapping[str, float],
    *,
    step_tag: Optional[int] = None,
) -> Optional[None]:
    # Intentionally a no-op in Phase 2 (we keep it light).
    return None
