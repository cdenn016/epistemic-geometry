
import numpy as np
from scipy.linalg import expm

#=======================================================
#
#           Generators
#
#=========================================================


_generator_cache = {}  # Already declared

def get_generators(group_name, K, return_meta=False):
    group_name = group_name.lower()
    if group_name not in ["sl2r", "so3"]:
        raise ValueError(f"Unsupported group: {group_name}")

    if isinstance(K, int):
        key = (group_name, K)
    elif isinstance(K, list):
        key = (group_name, tuple(K))
    else:
        raise TypeError(f"[get_generators] Invalid type for K: {type(K)}")

    if key in _generator_cache:
        G, meta = _generator_cache[key]
    else:
        if isinstance(K, int):
            if group_name == "sl2r":
                G_dict = sl2r_irrep(K)
            else:  # SO(3)
                G_dict = so3_irrep(K)

            for name in ["E", "F", "H"]:
                Gmat = G_dict[name]
                assert Gmat.ndim == 2 and Gmat.shape[0] == Gmat.shape[1]

            G = np.stack([G_dict["E"], G_dict["F"], G_dict["H"]], axis=0)
            meta = {"blocks": [K]}
        else:
            G, meta = _get_reducible_sl2r(K)  # You can also later define `_get_reducible_so3`

        _generator_cache[key] = (G, meta)

    return (G, meta) if return_meta else G



def so3_irrep(K: int) -> dict:
    if K % 2 == 0:
        raise ValueError("K must be odd for SO(3) irreps (K = 2ℓ + 1).")
    ℓ = (K - 1) // 2

    # 1) Complex |m> basis, m = -ℓ..ℓ
    Jp = np.zeros((K, K), dtype=np.complex64)
    Jm = np.zeros((K, K), dtype=np.complex64)
    Jz = np.zeros((K, K), dtype=np.complex64)
    for m in range(-ℓ, ℓ + 1):
        i = m + ℓ
        Jz[i, i] = m
        if m < ℓ:
            a = np.sqrt((ℓ - m) * (ℓ + m + 1))
            Jp[i, i + 1] = a
            Jm[i + 1, i] = a
    Jx = (Jp + Jm) / 2.0
    Jy = (Jp - Jm) / (2.0j)

    # 2) Complex->real spherical-harmonic basis transform S
    S = np.zeros((K, K), dtype=np.complex64)
    S[0, ℓ] = 1.0  # m=0 stays real
    r = 1
    for m in range(1, ℓ + 1):
        phase = (-1) ** m
        # cosine row (real)
        S[r,   ℓ + m] = 1 / np.sqrt(2)
        S[r,   ℓ - m] = phase / np.sqrt(2)
        # sine row (real)
        S[r+1, ℓ + m] = -1j / np.sqrt(2)
        S[r+1, ℓ - m] =  1j * phase / np.sqrt(2)
        r += 2
    Sinv = S.conj().T  # unitary

    # 3) Real skew-symmetric algebra generators: G = S (iJ) S^{-1}
    def real_skew(iJ):
        G = (S @ iJ @ Sinv).real
        return 0.5 * (G - G.T)  # enforce exact skew-symmetry

    Gx = real_skew(1j * Jx)
    Gy = real_skew(1j * Jy)
    Gz = real_skew(1j * Jz)

    # Return in a fixed order; pick any consistent (E,F,H) mapping
    return {"E": Gx, "F": Gy, "H": Gz}




def sl2r_irrep(K: int) -> dict:
    """
    Return the real irreducible SL(2,R) generators E, F, H for dimension K = 2ℓ + 1.
    """
    if K % 2 == 0:
        raise ValueError("K must be odd for SL(2,R) irreps (K = 2ℓ + 1).")
    ℓ = (K - 1) // 2
    E = np.zeros((K, K), dtype=float)
    F = np.zeros((K, K), dtype=float)
    H = np.zeros((K, K), dtype=float)

    for m in range(-ℓ, ℓ + 1):
        i = m + ℓ
        H[i, i] = m
        if i < K - 1:
            a = np.sqrt((ℓ - m) * (ℓ + m + 1))
            E[i, i + 1] = a
            E[i + 1, i] = a
            F[i, i + 1] = -a
            F[i + 1, i] = a
    return {"E": E, "F": F, "H": H}



#==========================================
#
#    Build Reducible Representations
#
#==========================================


def block_diag_generators(blocks: list[dict[str, np.ndarray]]) -> dict[str, np.ndarray]:
    """
    Combine a list of irreducible generator sets {E,F,H} into a block-diagonal reducible set.

    Args:
        blocks: list of dicts, each with {"E", "F", "H"} generators of shape (Ki, Ki)

    Returns:
        dict with:
            "E" : (K_total, K_total) ndarray
            "F" : (K_total, K_total) ndarray
            "H" : (K_total, K_total) ndarray
    """
    def block_diag(gen_list):
        sizes = [g.shape[0] for g in gen_list]
        total = sum(sizes)
        out = np.zeros((total, total), dtype=np.float64)
        offset = 0
        for g in gen_list:
            k = g.shape[0]
            out[offset:offset+k, offset:offset+k] = g
            offset += k
        return out

    return {
        "E": block_diag([b["E"] for b in blocks]),
        "F": block_diag([b["F"] for b in blocks]),
        "H": block_diag([b["H"] for b in blocks])
    }



def _get_reducible_sl2r(K_list):
    """
    Construct reducible SL(2,R) representation from list of irreducible blocks.

    Args:
        K_list : list[int] — sizes of each irreducible block

    Returns:
        G      : ndarray (3, K_total, K_total) — stacked [E, F, H]
        meta   : dict {"blocks": K_list}
    """
    irreps = [sl2r_irrep(K) for K in K_list]  # each returns {"E", "F", "H"}
    G_dict = block_diag_generators(irreps)    # builds block-diagonal E/F/H
    G = np.stack([G_dict["E"], G_dict["F"], G_dict["H"]], axis=0)
    return G, {"blocks": K_list}
