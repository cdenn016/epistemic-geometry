# Third-party libraries
import numpy as np
from pathlib import Path


import core.config as config
from core.get_generators import get_generators
from core.omega import compute_field_strength   

from core.gaussian_core import push_gaussian, kl_gaussian, kl_divergence
from core.numerical_utils import sanitize_sigma
from transport.transport_cache import Lambda_dn, Lambda_up

from transport.bundle_morphism_utils import compute_direct_morphisms


from core.omega import exp_lie_algebra_irrep
from transport.transport_cache import Omega as tc_Omega 
from transport.transport_cache import curvature_plaquette 

# ==================================================================================
#                                     Fields
# ==================================================================================



def compute_alignment_field(
    agents, i, *, which="q", ctx=None,
    eps=None, log_eps=None, kl_cap=None, neighbor_tau=None, min_pair_px=None,
):
    """
    Energy-faithful alignment field for agent i:
      out(y,x) = sum_{j in N(i)} KL( N_i || Ω_ij ▷ N_j ) over overlapping neighbors,
    with NO averaging and NO caps. Suitable to integrate (sum) directly into the
    total variational energy after multiplying by the term weight.

    - Uses a single small ε everywhere for SPD hygiene (not a display/diagnostic cap).
    - Uses the same Ω definition across the codebase (transport cache if available).
    - When falling back (no ctx), uses Ai's generators to avoid irrep mismatches.
    """
    A = agents[i]

    # unified epsilon for energy terms (tiny, fixed)
    eps_val = float(getattr(config, "energy_eps", 1e-6) if eps is None else eps)

    # neighbor selection (heuristic only; does not affect integration weights)
    neighbor_tau = float(getattr(config, "overlap_eps", 0.20) if neighbor_tau is None else neighbor_tau)
    min_pair_px  = int(getattr(config, "min_pair_px", 8) if min_pair_px is None else min_pair_px)

    # integration domain = support via threshold (no _mask_bool)
    support_tau = float(getattr(config, "support_cutoff_eps", 1e-3))
    mask_i = _as_bool_mask(A.mask, support_tau)
    if mask_i is None or not np.any(mask_i):
        return np.zeros_like(_as_f32(getattr(A, "mask", 0.0)), np.float32)

    # neighbors (fallback heuristic if A.neighbors not precomputed)
    nb_list = getattr(A, "neighbors", None)
    if not nb_list:
        nb_list = []
        Ai_m = _as_f32(A.mask)
        for j, B in enumerate(agents):
            if j == i:
                continue
            m_j = _as_bool_mask(getattr(B, "mask", None), support_tau)
            if m_j is None or not np.any(m_j):
                continue
            inter = (Ai_m > neighbor_tau) & (_as_f32(B.mask) > neighbor_tau)
            if int(inter.sum()) >= min_pair_px:
                nb_list.append({"id": j})
    if not nb_list:
        return np.zeros_like(_as_f32(A.mask), np.float32)

    # choose fiber views
    mu_i_full, S_i_full, phi_i_full, G_i, K = _fiber_views(A, which)
    H, W = A.mask.shape

    # accumulate SUM over neighbors (no averaging)
    kl_sum = np.zeros((H, W), np.float32)

    for nb in nb_list:
        j = nb["id"]
        B = agents[j]
        mask_j = _as_bool_mask(getattr(B, "mask", None), support_tau)
        if mask_j is None or not np.any(mask_j):
            continue

        # overlap pixels = integration domain for this pair
        overlap = mask_i & mask_j
        if not np.any(overlap):
            continue

        mu_j_full, S_j_full, phi_j_full, G_j, _ = _fiber_views(B, which)

        # slice to overlap
        mu_i = _as_f32(mu_i_full)[overlap]                              # (M,K)
        S_i  = sanitize_sigma(_as_f32(S_i_full)[overlap], eps=eps_val)  # (M,K,K)
        mu_j = _as_f32(mu_j_full)[overlap]
        S_j  = sanitize_sigma(_as_f32(S_j_full)[overlap], eps=eps_val)

        # Ω from transport cache (preferred) or local with Ai's generators
        if ctx is not None:
            Om_full = tc_Omega(ctx, A, B, which=which)                  # (H,W,K,K)
            Omega   = Om_full[overlap]                                  # (M,K,K)
        else:
            if G_i is None:
                raise ValueError("compute_alignment_field: missing generators for local Ω path.")
            O_i    = exp_lie_algebra_irrep(_as_f32(phi_i_full)[overlap], G_i)
            O_jinv = exp_lie_algebra_irrep(-_as_f32(phi_j_full)[overlap], G_i)
            Omega  = np.matmul(O_i, O_jinv)

        # exact push; light numerics (symmetrize+sanitize) without altering objective
        mu_j_t, S_j_t = push_gaussian(
            mu=mu_j, Sigma=S_j, M=Omega,
            eps=eps_val, symmetrize=True, sanitize=True, approx="exact"
        )

        # KL at overlap pixels; finite, non-negative (numerical floor only)
        kl_vals = kl_divergence(mu_i, S_i, mu_j_t, S_j_t, eps=eps_val)
        kl_vals = np.where(np.isfinite(kl_vals), kl_vals, 0.0)
        kl_vals = np.maximum(kl_vals, 0.0)

        # scatter-add into SUM (no averaging)
        idx = np.argwhere(overlap); r, c = idx[:, 0], idx[:, 1]
        np.add.at(kl_sum, (r, c), kl_vals.astype(np.float32, copy=False))

    # zero outside Ai support; return SUM over neighbors
    return kl_sum * mask_i.astype(np.float32, copy=False)


# --- legacy names kept as thin wrappers ----------------------------------------
def compute_alignment_field_general(agents, i, field_type="belief", *, ctx=None, **kw):
    which = "q" if field_type == "belief" else "p"
    return compute_alignment_field(agents, i, which=which, ctx=ctx, **kw)



# --- cross-scale KLs (already transport-based via Λ; leave as-is or route here)
def compute_crossscale_kl_q_single(child, parent, *, eps=1e-8, support_thr=1e-3, return_field=False, ctx=None):
    # unchanged logic, but ensure Λ comes exclusively from transport_cache
    w = np.minimum(_as_f32(child.mask), _as_f32(parent.mask))
    m = w > float(support_thr)
    if not m.any() or ctx is None:
        return (0.0, np.zeros_like(child.mask, np.float32)) if return_field else 0.0
    mu_c = _as_f32(child.mu_q_field)[m]; S_c = _as_f32(child.sigma_q_field)[m]
    mu_p = _as_f32(parent.mu_q_field)[m]; S_p = _as_f32(parent.sigma_q_field)[m]
    L = Lambda_dn(ctx, child, parent, which="q")
    Lm = L if L.ndim == 2 else L[m]
    mu_p_t, S_p_t = push_gaussian(mu=mu_p, Sigma=S_p, M=Lm, eps=eps, symmetrize=True, sanitize=True, approx="exact")
    S_c = sanitize_sigma(S_c, eps=eps); S_p_t = sanitize_sigma(S_p_t, eps=eps)
    kl_vals = kl_divergence(mu_c, S_c, mu_p_t, S_p_t, eps=eps).astype(np.float32)
    w_flat = w[m].astype(np.float32); w_sum = float(np.nan_to_num(w_flat, 0.0).sum())
    mean_kl = float((kl_vals * w_flat).sum() / w_sum) if w_sum > 0 else 0.0
    if return_field:
        out = np.zeros_like(child.mask, np.float32); out[m] = kl_vals
        return mean_kl, out
    return mean_kl



def compute_crossscale_kl_p_single(child, parent, *, eps=1e-8, support_thr=1e-3, return_field=False, ctx=None):
    w = np.minimum(_as_f32(child.mask), _as_f32(parent.mask))
    m = w > float(support_thr)
    if not m.any() or ctx is None:
        return (0.0, np.zeros_like(child.mask, np.float32)) if return_field else 0.0
    mu_c = _as_f32(child.mu_p_field)[m]; S_c = _as_f32(child.sigma_p_field)[m]
    mu_p = _as_f32(parent.mu_p_field)[m]; S_p = _as_f32(parent.sigma_p_field)[m]
    L = Lambda_dn(ctx, child, parent, which="p")
    Lm = L if L.ndim == 2 else L[m]
    mu_p_t, S_p_t = push_gaussian(mu=mu_p, Sigma=S_p, M=Lm, eps=eps, symmetrize=True, sanitize=True, approx="exact")
    S_c = sanitize_sigma(S_c, eps=eps); S_p_t = sanitize_sigma(S_p_t, eps=eps)
    kl_vals = kl_divergence(mu_c, S_c, mu_p_t, S_p_t, eps=eps).astype(np.float32)
    w_flat = w[m].astype(np.float32); w_sum = float(np.nan_to_num(w_flat, 0.0).sum())
    mean_kl = float((kl_vals * w_flat).sum() / w_sum) if w_sum > 0 else 0.0
    if return_field:
        out = np.zeros_like(child.mask, np.float32); out[m] = kl_vals
        return mean_kl, out
    return mean_kl


# ====================================================================
#                               Energy Fields
# ====================================================================

def QQcompute_self_energy_field(agent, eps, cfg, *, ctx=None):
    """
    α * KL(q_i || Φ̃ · p_i), per-pixel, with automatic interior support
    gated by mask and transported covariance sanity.

    Uses transport_cache.Phi(ctx, agent, kind="p_to_q") if ctx is provided;
    falls back to legacy agent fields or identity if absent.
    """
    
    H, W = np.asarray(agent.mask).shape[:2]

    # Prefer cache facade (per-pixel Φ̃ lives in CacheHub)
    Phi_tilde = None
    
    
    if ctx is not None:
        try:
            from transport.transport_cache import Phi as tc_Phi
            Phi_tilde = tc_Phi(ctx, agent, kind="p_to_q")  # (H,W,Kq,Kp)
            
        except Exception:
            Phi_tilde = None

 
    mu_pq, S_pq = push_gaussian(
            mu=agent.mu_p_field, Sigma=agent.sigma_p_field, M=np.asarray(Phi_tilde),
            eps=eps, symmetrize=True, sanitize=True, approx="exact"
        )
   
    


    support = _auto_support_from_push(S_pq, agent.mask, eps)
    print(F"gherfd AUTO-SUPPORT {support}")
    field = _kl_map(agent.mu_q_field, agent.sigma_q_field, mu_pq, S_pq, support, eps)
    print("gherfd self energy KL-MAP")
    alpha = float(cfg.get("alpha", getattr(config, "alpha", 1.0)))
    print("gherfd self energy ALPHA")
    return (alpha * field).astype(np.float32, copy=False)

# generalized_diagnostics_metrics.py – fix shape test in _choose_support:

# generalized_diagnostics_metrics.py

def _choose_support(S_pq: np.ndarray, mask: np.ndarray, eps: float):
    import numpy as np
    H, W = mask.shape[:2]
    stats = {}

    ok_shape = (
        S_pq.ndim in (4, 6)
        and S_pq.shape[-1] == S_pq.shape[-2]
        and (S_pq.shape[-4:-2] == (H, W) if S_pq.ndim == 6 else S_pq.shape[:2] == (H, W))
    )
    if not ok_shape:
        sup = np.asarray(mask, bool)
        stats.update(dict(ok_shape=False, finite_true=int(np.count_nonzero(sup)), spd_true=0, chosen="mask"))
        return sup, stats

    # Finite
    finite = np.isfinite(S_pq).all(axis=(-1, -2))
    if S_pq.ndim == 6:
        finite = finite.reshape(H, W)
    stats["finite_true"] = int(np.count_nonzero(finite))

    # SPD (>= eps, not > eps)
    K = S_pq.shape[-1]
    M = S_pq.reshape(-1, K, K)
    Ms = 0.5 * (M + np.swapaxes(M, 1, 2))
    try:
        w = np.linalg.eigvalsh(Ms)
        lam_min = w[:, 0].reshape(H, W)
        tol = max(float(eps), 1e-9)
        spd = lam_min >= tol
        stats["spd_true"] = int(np.count_nonzero(spd))
    except Exception:
        spd = np.zeros((H, W), dtype=bool)
        stats["spd_true"] = 0

    m = np.asarray(mask, bool)
    interior = (m & finite & spd)
    if np.any(interior):
        stats["chosen"] = "interior";  return interior, stats
    if np.any(m & finite):
        stats["chosen"] = "finite";    return (m & finite), stats
    stats["chosen"] = "mask";          return m, stats




# generalized_diagnostics_metrics.py  — replace your compute_self_energy_field with:

def compute_self_energy_field(agent, eps, cfg, *, ctx=None):
    """
    α * KL(q_i || Φ̃ · p_i), per-pixel.
    - Uses transport_cache.Phi when available
    - Sanitizes both covariances before KL
    - Robust support selection
    """
    import numpy as np
    from core.gaussian_core import sanitize_sigma     # same import you use in crossscale path

    H, W = np.asarray(agent.mask).shape[:2]
    Kq = int(agent.mu_q_field.shape[-1])
    Kp = int(agent.mu_p_field.shape[-1])

    # ---- 1) Get Φ̃ (prefer cache) ----
    Phi_tilde = None
    if ctx is not None:
        try:
            from transport.transport_cache import Phi as tc_Phi
            Phi_tilde = tc_Phi(ctx, agent, kind="p_to_q")  # (H,W,Kq,Kp) or (Kq,Kp)
        except Exception:
            Phi_tilde = None

    if Phi_tilde is None:
        # Direct fallback – use the *current* base names
        try:
            from transport.bundle_morphism_utils import compute_direct_morphisms as _cdm
        except Exception:
            from bundle_morphism_utils import compute_direct_morphisms as _cdm
        Phi, Phi_t = _cdm(
            phi=agent.phi, phi_model=agent.phi_model,
            generators_q=agent.generators_q, generators_p=agent.generators_p,
            Phi_0=getattr(agent, "Phi_0", None),
            Phi_tilde_0=getattr(agent, "Phi_tilde_0", None),
            ctx=ctx,
        )
        Phi_tilde = Phi_t

    # ---- 2) Normalize Φ̃ to (H,W,Kq,Kp) ----
    Phi_tilde = np.asarray(Phi_tilde, np.float32)
    if Phi_tilde.ndim == 2:
        if Phi_tilde.shape != (Kq, Kp):
            raise ValueError(f"Φ̃ base shape {Phi_tilde.shape} != (Kq,Kp)=({Kq},{Kp})")
        Phi_tilde = np.broadcast_to(Phi_tilde, (H, W, Kq, Kp)).copy()
    elif Phi_tilde.ndim == 4:
        if Phi_tilde.shape[:2] != (H, W) or Phi_tilde.shape[2:] != (Kq, Kp):
            raise ValueError(f"Φ̃ field shape {Phi_tilde.shape} != (H,W,Kq,Kp)=({H},{W},{Kq},{Kp})")
    else:
        raise ValueError(f"Unexpected Φ̃ ndim={Phi_tilde.ndim}; expected 2 or 4.")

    # ---- 3) Push p → q, sanitize Σs for KL ----
    mu_pq, S_pq_raw = push_gaussian(
        mu=agent.mu_p_field, Sigma=agent.sigma_p_field, M=Phi_tilde,
        eps=eps, symmetrize=True, sanitize=True, approx="exact",
    )
    
    print("[SELF] shapes:",
      "mu_q", agent.mu_q_field.shape,
      "S_q",  agent.sigma_q_field.shape,
      "mu_pq", mu_pq.shape,
      "S_pq",  S_pq_raw.shape)

    print("[SELF] mask_true:", int(np.count_nonzero(agent.mask)))
    print("[SELF] S_q finite:", np.isfinite(agent.sigma_q_field).all())
    print("[SELF] S_p finite:", np.isfinite(agent.sigma_p_field).all())
    print("[SELF] S_pq finite:", np.isfinite(S_pq_raw).all())

    
    
    S_q   = sanitize_sigma(agent.sigma_q_field, eps=eps)   # <— MISSING BEFORE
    S_pq  = sanitize_sigma(S_pq_raw,            eps=eps)   # re-sanitize for safety

    # ---- 4) Support selection that actually checks SPD on (H,W,K,K) ----
    support, sdbg = _choose_support(S_pq, agent.mask, eps)
    print(f" support = {support}")
    
    # Optional: if support is empty, fallback to mask
    if not np.any(support):
        # loud diagnostics instead of silently falling back
        def _min_eig(A):
            M = A.reshape(-1, A.shape[-2], A.shape[-1])
            Ms = 0.5*(M + np.swapaxes(M,1,2))
            try:
                return float(np.nanmin(np.linalg.eigvalsh(Ms)[:,0]))
            except Exception:
                return float("nan")
    
        print("[SELF] mask_true =", int(np.count_nonzero(agent.mask)))
        print("[SELF] min_eig(sigma_q)  =", _min_eig(S_q))
        print("[SELF] min_eig(S_pq_raw) =", _min_eig(S_pq_raw))
        print("[SELF] min_eig(S_pq)     =", _min_eig(S_pq))
        print("[SELF] support ladder dbg:", sdbg)
    
        # if mask has pixels, but support is still empty, elevate failure
        if np.any(agent.mask):
            raise FloatingPointError("Self-energy: support empty after SPD/finite checks. See prints above.")
        else:
            # truly empty mask → short-circuit to zeros
            return np.zeros((agent.mask.shape[0], agent.mask.shape[1]), dtype=np.float32)
   
    # ---- 5) KL map (don’t squash NaNs unless explicitly allowed) ----
    field = _kl_map(agent.mu_q_field, S_q, mu_pq, S_pq, support, eps)
    print(f" field = {field}")
    
    if not bool(getattr(config, "allow_nan_to_zero_in_fields", False)):
        if not np.isfinite(field).all():
            # surface the problem loudly; you asked to avoid silent zeros
            bad = int(np.count_nonzero(~np.isfinite(field)))
            raise FloatingPointError(f"self-energy KL produced {bad} non-finite pixels; "
                                     f"sdbg={sdbg}")
    else:
        field = np.nan_to_num(field, nan=0.0, posinf=0.0, neginf=0.0)

    alpha = float(cfg.get("alpha", getattr(config, "alpha", 1.0)))
    return (alpha * field).astype(np.float32, copy=False)


def compute_feedback_energy_field(agent, eps, cfg, *, ctx=None):
    """
    λ * KL(p_i || Φ · q_i), per-pixel, with automatic interior support
    gated by mask and transported covariance sanity.

    Uses transport_cache.Phi(ctx, agent, kind="q_to_p") if ctx is provided;
    falls back to legacy agent fields or identity if absent.
    """
    
    H, W = np.asarray(agent.mask).shape[:2]

    # Prefer cache facade (per-pixel Φ lives in CacheHub)
    Phi = None
    if ctx is not None:
        try:
            from transport.transport_cache import Phi as tc_Phi
            Phi = tc_Phi(ctx, agent, kind="q_to_p")  # (H,W,Kp,Kq)
        except Exception:
            Phi = None


    mu_qp, S_qp = push_gaussian(
        mu=agent.mu_q_field, Sigma=agent.sigma_q_field, M=np.asarray(Phi),
        eps=eps, symmetrize=True, sanitize=True, approx="exact"
    )
    support = _auto_support_from_push(S_qp, agent.mask, eps)
    field = _kl_map(agent.mu_p_field, agent.sigma_p_field, mu_qp, S_qp, support, eps)
    lam = float(cfg.get("lambda", cfg.get("feedback_weight", getattr(config, "feedback_weight", 0.0))))
    return (lam * field).astype(np.float32, copy=False)



# =========================
#        Scalars
# =========================
def compute_self_energy_scalar(agent, log_eps, cfg, *, ctx=None) -> float:
    """Weighted sum of KL(q_i || Φ̃·p_i) over valid support."""
    import core.config as config
    field = compute_self_energy_field(agent, log_eps, cfg, ctx=ctx)
    agent.e_self_field = field  # optional cache
    thr = float(cfg.get("support_cutoff_eps", getattr(config, "support_cutoff_eps", 1e-3)))
    return _reduce_over_mask(field, agent.mask, how="sum", eps=thr)


def compute_feedback_energy_scalar(agent, log_eps, cfg, *, ctx=None) -> float:
    """Weighted sum of KL(p_i || Φ·q_i) over valid support."""
    import core.config as config
    field = compute_feedback_energy_field(agent, log_eps, cfg, ctx=ctx)
    agent.e_feedback_field = field  # optional cache
    thr = float(cfg.get("support_cutoff_eps", getattr(config, "support_cutoff_eps", 1e-3)))
    return _reduce_over_mask(field, agent.mask, how="sum", eps=thr)

# =========================
#      Regularizers
# =========================

def compute_mass_energy(phi: np.ndarray, mask: np.ndarray, weight: float) -> float:
    """
    Mass regularization: E = weight * ∑_{mask} ||phi||^2
    phi: (H,W,d), mask: (H,W) in [0,1] or bool
    """
    m = (np.asarray(mask) > 0)
    if not m.any() or float(weight) == 0.0:
        return 0.0
    norms_sq = np.sum(np.asarray(phi, np.float32)**2, axis=-1)
    return float(weight) * float(np.sum(np.where(m, norms_sq, 0.0), dtype=np.float64))


def compute_curvature_energy(
    phi_field,
    mask,
    weight,
    lie_gens,
    support_eps: float = 1e-4,
    debug: bool = False,
    *,
    ctx=None,
    boundary: str = None,    # None -> config
    split_edge: bool = None, # None -> config
    metric: str = None,      # None -> config, 'fro' or 'angle' (K=3)
    return_map: bool = False,
):
    """
    Lattice (plaquette) curvature energy using cached link transports (transport_cache.curvature_plaquette).
    This is the single source of truth; we no longer maintain a differential fallback here.
    """
    if ctx is None:
        # Without ctx (no transport cache), we cannot build plaquettes reliably.
        # Return 0 to avoid misleading numbers.
        if return_map:
            H, W = np.asarray(mask).shape[:2]
            return 0.0, 0.0, np.zeros((H, W), dtype=np.float32)
        return 0.0, 0.0

    # Defaults from config
    if boundary   is None: boundary   = str(getattr(config, "curv_boundary", "periodic"))
    if split_edge is None: split_edge = bool(getattr(config, "curv_split_edge", False))
    if metric     is None: metric     = str(getattr(config, "curv_metric", "fro"))

    curv_map = curvature_plaquette(
        ctx,
        np.asarray(phi_field, np.float32),
        np.asarray(lie_gens,  np.float32),
        boundary=boundary,
        split_edge=split_edge,
        metric=metric,
        return_P=False,
    ).astype(np.float32, copy=False)

    curv_map = np.nan_to_num(curv_map, nan=0.0, posinf=0.0, neginf=0.0, copy=False)

    # apply support
    if mask is not None:
        support = (np.asarray(mask) > float(support_eps))
        curv_map = curv_map * support.astype(curv_map.dtype, copy=False)

    raw = float(np.sum(curv_map, dtype=np.float64))
    weighted = float(weight) * raw

    if debug:
        print(f"[φ_curv:lattice] Raw: {raw:.6e} | Weighted: {weighted:.6e} "
              f"| boundary={boundary} split_edge={split_edge} metric={metric}")

    if return_map:
        return weighted, raw, curv_map
    return weighted, raw


def _curvature_energy_for_agent(A, *, generators_q=None, generators_p=None, ctx=None):
    """
    Return RAW (unweighted) curvature energies for belief (φ) and model (φ̃).
    Single implementation via plaquettes; weights applied by caller.
    """
    cq = cp = 0.0
    if generators_q is not None and getattr(A, "phi", None) is not None:
        _, raw_q = compute_curvature_energy(
            np.asarray(A.phi, np.float32), np.asarray(A.mask), weight=1.0, lie_gens=np.asarray(generators_q, np.float32),
            ctx=ctx
        )
        cq = float(raw_q)

    if generators_p is not None and getattr(A, "phi_model", None) is not None:
        _, raw_p = compute_curvature_energy(
            np.asarray(A.phi_model, np.float32), np.asarray(A.mask), weight=1.0, lie_gens=np.asarray(generators_p, np.float32),
            ctx=ctx
        )
        cp = float(raw_p)
    return (cq, cp)







# ==========================================================================
#                                  Logging
# ==========================================================================



def _lambda_norms_primary(agent, mask, *, ctx=None) -> dict:
    """Return mean Frobenius norms of Λ_dn/Λ_up for q/p, for the primary parent."""
    out = {"lambda_q_dn_norm": np.nan, "lambda_q_up_norm": np.nan,
           "lambda_p_dn_norm": np.nan, "lambda_p_up_norm": np.nan}
    if ctx is None:
        return out
    parent = _select_primary_parent(agent, ctx)
    if parent is None:
        return out
    

    for which in ("q", "p"):
        try:
            Ldn = Lambda_dn(ctx, agent, parent, which=which)
            if Ldn is not None:
                out[f"lambda_{which}_dn_norm"] = _reduce_over_mask(_fro_map(Ldn), mask, "mean")
        except Exception:
            print("lambda norms primary down FAIL")
        try:
            Lup = Lambda_up(ctx, agent, parent, which=which)
            if Lup is not None:
                out[f"lambda_{which}_up_norm"] = _reduce_over_mask(_fro_map(Lup), mask, "mean")
        except Exception:
            print("lambda norms primary  up FAIL")
    return out

def _morphism_norms(agent, mask, *, ctx=None) -> dict:
    """Mean Frobenius norms of bundle morphisms (q→p and p→q) over support."""
    import numpy as np

    out = {"morphism_q2p_norm": np.nan, "morphism_p2q_norm": np.nan}

    # Try cache-backed morphisms first
    Phi = Phit = None
    if ctx is not None:
        try:
            from transport.transport_cache import Phi as tc_Phi
            Phi  = tc_Phi(ctx, agent, kind="q_to_p")  # (H,W,Kp,Kq)
            Phit = tc_Phi(ctx, agent, kind="p_to_q")  # (H,W,Kq,Kp)
        except Exception:
            Phi  = None
            Phit = None


    try:
        if Phi is not None:
            out["morphism_q2p_norm"] = _reduce_over_mask(_fro_map(np.asarray(Phi)), mask, "mean")
    except Exception:
        print("morphism norms Phi FAIL ")

    try:
        if Phit is not None:
            out["morphism_p2q_norm"] = _reduce_over_mask(_fro_map(np.asarray(Phit)), mask, "mean")
    except Exception:
        print("morphism norms Phi~ FAIL ")

    return out


#=============================================================================
#
#              Total Variational Energy Scalar
#
#
#=============================================================================

# ====================================================================
#                         Free Energy (scalar)
# ====================================================================



def _crossscale_energy_for_child(C, parents_by_id, *, ctx=None):
    # Child↔parent consistency via Λ: KL( child || Λ·parent ) on q and p fibers
    P = _first_parent(C, parents_by_id)
    if P is None:
        return 0.0
    e = 0.0
    try:
        ekq = compute_crossscale_kl_q_single(C, P, ctx=ctx)
        e  += float(ekq)
    except Exception:
        print("xscale energy child q FAIL ")
    try:
        ekp = compute_crossscale_kl_p_single(C, P, ctx=ctx)
        e  += float(ekp)
    except Exception:
        print("xscale energy child p FAIL ")
    return e




def _gauge_mass_energy_for_agent(A, *, eps=None):
    """
    Raw gauge mass for one agent (no weights):
      E_q_raw = 1/2 * sum_{mask} ||phi||^2
      E_p_raw = 1/2 * sum_{mask} ||phi_tilde||^2
    """
    import numpy as np
    if eps is None:
        try:
            from core import config
            eps = float(getattr(config, "support_cutoff_eps", 1e-6))
        except Exception:
            eps = 1e-6

    m   = (np.asarray(getattr(A, "mask", 0.0), np.float32) > eps)
    phi = np.asarray(getattr(A, "phi", None), np.float32)
    phm = np.asarray(getattr(A, "phi_model", None), np.float32)

    e_q = 0.0 if phi is None else 0.5 * np.sum((np.linalg.norm(phi, axis=-1)**2) * m)
    e_p = 0.0 if phm is None else 0.5 * np.sum((np.linalg.norm(phm, axis=-1)**2) * m)
    return float(e_q), float(e_p)



def compute_total_free_energy(agents, *, generators_q=None, generators_p=None, ctx=None, weights=None):
    import core.config as config  # ensure local import works everywhere
    import numpy as np

    # ---------- helper: energy-safe masked sum (no caps/robust stats) ----------
    def _sum_over_mask(field, mask, thr=None):
        thr = float(getattr(config, "support_cutoff_eps", 1e-3) if thr is None else thr)
        m = (np.asarray(mask) > thr)
        if not m.any():
            return 0.0
        x = np.asarray(field, np.float32)
        x = np.where(np.isfinite(x), x, 0.0)  # hygiene only
        return float(np.sum(x[m], dtype=np.float64))

    # Weights (allow separate curvature weights for q and p)
    enable_xscale = bool(getattr(config, "enable_xscale", False))
    W = dict(
        self    = float(getattr(config, "E_w_self",   getattr(config, "alpha", 1.0))),
        align   = float(getattr(config, "E_w_align",  getattr(config, "beta",  1.0))),
        mass_q  = float(getattr(config, "belief_mass", 0.0)),
        mass_p  = float(getattr(config, "model_mass",  0.0)),
        cross   = float(getattr(config, "E_w_cross",  1.0 if enable_xscale else 0.0)),
        curv_q  = float(getattr(config, "E_w_curv_q", getattr(config, "curvature_weight", 0.0))),
        curv_p  = float(getattr(config, "E_w_curv_p", getattr(config, "model_curvature_weight", 0.0))),
    )
    # Overrides
    verbose = bool(getattr(config, "debug_energy_print", False))
    if isinstance(weights, dict):
        verbose = bool(weights.get("verbose", verbose))
        for k in ("self","align","mass_q","mass_p","cross","curv_q","curv_p"):
            if k in weights: W[k] = float(weights[k])
        if "curv" in weights:  # legacy shared curvature override
            W["curv_q"] = W["curv_p"] = float(weights["curv"])

    children = [a for a in agents if int(getattr(a, "level", 0)) == 0]
    parents  = [a for a in agents if int(getattr(a, "level", 0)) >= 1]
    parents_by_id = {int(a.id): a for a in parents}

    # Accumulators
    E_self    = 0.0
    E_align_q = 0.0
    E_align_p = 0.0
    E_mass_q  = 0.0
    E_mass_p  = 0.0
    E_cross   = 0.0
    E_curv_q  = 0.0
    E_curv_p  = 0.0

    # Single pass over agents; accumulate all terms without resetting inside the loop
    cfg_dict = dict(vars(config))
    if ctx is not None:
        cfg_dict["ctx"] = ctx
    log_eps = float(getattr(config, "log_eps", 1e-8))

    for A in agents:
        # --- Self energy ---
        try:
            E_self += float(compute_self_energy_scalar(A, log_eps, cfg_dict, ctx = ctx))
        except Exception:
            print("[compute free energy] self failed:")

        # --- Alignment (belief) : SUM over mask, no caps/robust stats ---
        try:
            field_q = compute_alignment_field_general(agents, A.id, field_type="belief", ctx=ctx)
            E_align_q += _sum_over_mask(field_q, A.mask)
        except Exception:
            if verbose:
                import traceback; print("[energy] align belief failed:", traceback.format_exc())

        # --- Alignment (model) : SUM over mask, no caps/robust stats ---
        try:
            field_p = compute_alignment_field_general(agents, A.id, field_type="model", ctx=ctx)
            E_align_p += _sum_over_mask(field_p, A.mask)
        except Exception:
            if verbose:
                import traceback; print("[energy] align model failed:", traceback.format_exc())

        # --- Gauge mass (q/p) ---
        try:
            emq, emp = _gauge_mass_energy_for_agent(A)
            E_mass_q += float(emq); E_mass_p += float(emp)
        except Exception:
            if verbose:
                import traceback; print("[energy] mass term failed:", traceback.format_exc())

        # --- Curvature (q/p raw) — unweighted here; weights applied at the end ---
        try:
            cq, cp = _curvature_energy_for_agent(
                A, generators_q=generators_q, generators_p=generators_p, ctx=ctx
            )
            E_curv_q += float(cq); E_curv_p += float(cp)
            if verbose and ((cq == 0.0) ^ (cp == 0.0)):
                print(f"[curv/debug] one side zero: cq={cq:.3e} cp={cp:.3e} (check masks/gens)")
        except Exception:
            if verbose:
                import traceback; print("[energy] curvature term failed:", traceback.format_exc())

    # Cross-scale
    if W["cross"] != 0.0 and enable_xscale:
        for C in children:
            try:
                E_cross += _crossscale_energy_for_child(C, parents_by_id, ctx=ctx)
            except Exception:
                if verbose:
                    import traceback; print("[energy] cross-scale failed:", traceback.format_exc())

    # Weighted total
    total = (
        W["self"]   * E_self +
        W["align"]  * (E_align_q + E_align_p) +
        W["mass_q"] * E_mass_q +
        W["mass_p"] * E_mass_p +
        W["cross"]  * E_cross +
        W["curv_q"] * E_curv_q +
        W["curv_p"] * E_curv_p
    )

    breakdown = dict(
        self=E_self,
        align_q=E_align_q, align_p=E_align_p, align=(E_align_q + E_align_p),
        mass_q=E_mass_q, mass_p=E_mass_p,
        cross=E_cross,
        curv_q=E_curv_q, curv_p=E_curv_p, curv=(E_curv_q + E_curv_p),
        total=total, weights=W
    )

    if verbose:
        sc = lambda x: f"{x:.6e}"
        w  = W
        print("\n[Energy Breakdown]\n"
              f"  E_total = {sc(total)}\n"
              "  ------------------------------------\n"
              "  term               weighted                raw     weight\n"
              f"  self           {sc(w['self']*E_self):>12}  {sc(E_self):>12}  {w['self']:.0f}\n"
              f"  align_q        {sc(w['align']*E_align_q):>12}  {sc(E_align_q):>12}  {w['align']:.0f}\n"
              f"  align_p        {sc(w['align']*E_align_p):>12}  {sc(E_align_p):>12}  {w['align']:.0f}\n"
              f"  mass_q         {sc(w['mass_q']*E_mass_q):>12}  {sc(E_mass_q):>12}  {w['mass_q']:.0f}\n"
              f"  mass_p         {sc(w['mass_p']*E_mass_p):>12}  {sc(E_mass_p):>12}  {w['mass_p']:.0f}\n"
              f"  cross          {sc(w['cross']*E_cross):>12}  {sc(E_cross):>12}  {w['cross']:.0f}\n"
              f"  curv_q         {sc(w['curv_q']*E_curv_q):>12}  {sc(E_curv_q):>12}  {w['curv_q']:.0f}\n"
              f"  curv_p         {sc(w['curv_p']*E_curv_p):>12}  {sc(E_curv_p):>12}  {w['curv_p']:.0f}\n"
              "  ------------------------------------\n"
              f"  align_sum      {sc(w['align']*(E_align_q+E_align_p)):>12}  {sc(E_align_q+E_align_p):>12}          —\n"
              f"  curv_sum       {sc(w['curv_q']*E_curv_q + w['curv_p']*E_curv_p):>12}  {sc(E_curv_q+E_curv_p):>12}          —\n")
    return total, breakdown






# ============================================================
# Metrics (strict-SPD): per-agent + parent/morphism/Λ logging
# ============================================================

# ---- compact defaults for a single agent row ---------------------------------
def zero_agent_metrics() -> dict:
    return {
        # energies
        "e_self": 0.0, "e_feedback": 0.0,
        "e_align": 0.0, "e_mod_align": 0.0,
        "e_curv": 0.0, "e_curv_mod": 0.0,
        "e_mass": 0.0, "e_mass_mod": 0.0,
        # norms (support-summed)
        "phi_norm": 0.0, "phi_model_norm": 0.0,
        # optional Λ / morphism norms
        "lambda_q_dn_norm": np.nan, "lambda_q_up_norm": np.nan,
        "lambda_p_dn_norm": np.nan, "lambda_p_up_norm": np.nan,
        "morphism_q2p_norm": np.nan, "morphism_p2q_norm": np.nan,
        # optional gradient norms
        "grad_phi_norm": np.nan, "grad_phi_model_norm": np.nan,
    }


def compute_all_agent_metrics(i, agent, Q_list, P_list, Mask_list, cfg, gens, log_eps) -> dict:
    """
    Per-agent diagnostics (energy-faithful reducers):
      self/feedback, alignment (sum over support, no caps), curvature (plaquette),
      mass, gauge norms, optional Λ/Φ norms, optional grad norms.
    """
  
    stats = zero_agent_metrics()

    mask = Mask_list[i]
    if mask is None or not np.any(mask):
        return stats

    # ---------------- weights & thresholds ----------------
    alpha = float(cfg.get("alpha", cfg.get("self_weight", 0.0)))
    lam   = float(cfg.get("lambda_feedback", cfg.get("lambda", cfg.get("feedback_weight", 0.0))))
    thr   = float(cfg.get("support_cutoff_eps", getattr(config, "support_cutoff_eps", 1e-3)))
    support = _support_mask(mask, thr)

    # Shared ctx for cache-backed transports
    ctx = cfg.get("ctx", None)

    # ---------------- Self / Feedback (scalar via unified helpers) --------------
    if alpha != 0.0:
        try:
            stats["e_self"] = float(compute_self_energy_scalar(agent, log_eps, cfg, ctx=ctx))
        except Exception:
            print("comp all agent metrics e_self FAIL ")
    if lam != 0.0:
        try:
            stats["e_feedback"] = float(compute_feedback_energy_scalar(agent, log_eps, cfg, ctx=ctx))
        except Exception:
            print("comp all agent metrics e_feedback FAIL ")

    # ---------------- Alignment (sum over support; no caps/averaging) ----------
    overlap_eps = float(cfg.get("overlap_eps", getattr(config, "overlap_eps", 1e-6)))
    agents_ref = cfg.get("agents_ref", cfg.get("agents", None))

    if agents_ref is not None:
        try:
            KLq = compute_alignment_field_general(
                agents=agents_ref, i=i, field_type="belief",
                eps=overlap_eps, log_eps=log_eps, ctx=ctx
            )
            stats["e_align"] = float(getattr(config, "beta", 1.0)) * _reduce_over_mask(KLq, support, how="sum")
        except Exception:
            print("comp all agent metrics e_align FAIL ")
        try:
            KLp = compute_alignment_field_general(
                agents=agents_ref, i=i, field_type="model",
                eps=overlap_eps, log_eps=log_eps, ctx=ctx
            )
            beta_model = float(getattr(config, "beta_model", getattr(config, "beta", 1.0)))
            stats["e_mod_align"] = beta_model * _reduce_over_mask(KLp, support, how="sum")
        except Exception:
            print("comp all agent metrics e_model align FAIL ")

    # ---------------- Curvature (plaquette) ------------------------------------
    def _get(cfgdict, *names, default=0.0):
        for n in names:
            if n in cfgdict:
                return cfgdict[n]
        return default

    w_curv_q = float(_get(cfg, "curvature_weight", "belief_curvature_weight", default=0.0))
    w_curv_p = float(_get(cfg, "model_curvature_weight", "phi_model_curvature_weight", default=0.0))

    if w_curv_q != 0.0 and getattr(agent, "phi", None) is not None:
        try:
            weighted_q, _ = compute_curvature_energy(
                agent.phi, mask, weight=w_curv_q, lie_gens=np.asarray(gens[0], np.float32), ctx=ctx
            )
            stats["e_curv"] = float(weighted_q)
        except Exception:
            print("comp all agent metrics e_curv FAIL ")

    if w_curv_p != 0.0 and getattr(agent, "phi_model", None) is not None:
        try:
            weighted_p, _ = compute_curvature_energy(
                agent.phi_model, mask, weight=w_curv_p, lie_gens=np.asarray(gens[1], np.float32), ctx=ctx
            )
            stats["e_curv_mod"] = float(weighted_p)
        except Exception:
            print("comp all agent metrics e_curv-mod FAIL ")

    # ---------------- Mass (only if weights ≠ 0) --------------------------------
    try:
        w_mass_q = float(cfg.get("phi_mass_weight", cfg.get("belief_mass", 0.0)))
        w_mass_p = float(cfg.get("phi_model_mass_weight", cfg.get("model_mass", 0.0)))
        if w_mass_q != 0.0 and getattr(agent, "phi", None) is not None:
            stats["e_mass"] = float(compute_mass_energy(agent.phi, mask, w_mass_q))
        if w_mass_p != 0.0 and getattr(agent, "phi_model", None) is not None:
            stats["e_mass_mod"] = float(compute_mass_energy(agent.phi_model, mask, w_mass_p))
    except Exception:
        print("comp all agent metrics e_mass FAIL ")

    # ---------------- Gauge field norms (sum over support) ----------------------
    try:
        phi = getattr(agent, "phi", None)
        stats["phi_norm"] = 0.0 if phi is None else _reduce_over_mask(np.linalg.norm(_as_f32(phi), axis=-1), support, how="sum")
        phi_model = getattr(agent, "phi_model", None)
        stats["phi_model_norm"] = 0.0 if phi_model is None else _reduce_over_mask(np.linalg.norm(_as_f32(phi_model), axis=-1), support, how="sum")
    except Exception:
        print("comp all agent metrics phi norms FAIL ")

    # ---------------- Optional Λ / morphism norms -------------------------------
    logcfg = (cfg.get("logging") or {})
    if bool(logcfg.get("enable_lambda_norms", False)):
        try:
            stats.update(_lambda_norms_primary(agent, support, ctx=ctx))
        except Exception:
            print("comp all agent metrics lambda norms FAIL ")
    if bool(logcfg.get("enable_morphism_norms", False)):
        try:
            stats.update(_morphism_norms(agent, support, ctx=ctx))
        except Exception:
            print("comp all agent metrics morphism norms FAIL ")

    # ---------------- Optional gradient norms -----------------------------------
    gp  = getattr(agent, "grad_phi", None)
    gpt = getattr(agent, "grad_phi_tilde", None)
    try:
        if gp is not None:
            stats["grad_phi_norm"] = _reduce_over_mask(np.linalg.norm(_as_f32(gp), axis=-1), support, how="sum")
        if gpt is not None:
            stats["grad_phi_model_norm"] = _reduce_over_mask(np.linalg.norm(_as_f32(gpt), axis=-1), support, how="sum")
    except Exception:
        print("comp all agent metrics grad-phi FAIL")

    return stats


def compute_agent_metrics(i: int, agent, Q_list, P_list, Mask_list, cfg, gens, log_eps) -> tuple[int, dict]:
    # Kept signature for compatibility; Q_list / P_list are unused.
    mask = Mask_list[i]
    if mask is None or not np.any(mask):
        return i, zero_agent_metrics()
    return i, compute_all_agent_metrics(i, agent, Q_list, P_list, Mask_list, cfg, gens, log_eps)


def log_agent_metrics(agent, step: int, stats: dict, normalize=True):
    eps = float(getattr(config, "support_cutoff_eps", 1e-6))
    S = float((np.asarray(agent.mask) > eps).sum()) or 1.0
    if not normalize:
        S = 1.0

    def g(k, default=np.nan):
        try:
            return float(stats.get(k, default))
        except Exception:
            return default

    row = {
        # normalized energies
        "kl_self":            g("e_self", 0.0)      / S,
        "kl_feedback":        g("e_feedback", 0.0)  / S,
        "kl_align":           g("e_align", 0.0)     / S,
        "kl_mod_align":       g("e_mod_align", 0.0) / S,
        "curv_energy":        g("e_curv", 0.0)      / S,
        "curv_model_energy":  g("e_curv_mod", 0.0)  / S,
        "mass_energy":        g("e_mass", 0.0)      / S,
        "mass_model_energy":  g("e_mass_mod", 0.0)  / S,
        # norms already support-reduced
        "phi_norm":           g("phi_norm"),
        "phi_model_norm":     g("phi_model_norm"),
        # optional Λ/morphism/grad
        "lambda_q_dn_norm":   g("lambda_q_dn_norm"),
        "lambda_q_up_norm":   g("lambda_q_up_norm"),
        "lambda_p_dn_norm":   g("lambda_p_dn_norm"),
        "lambda_p_up_norm":   g("lambda_p_up_norm"),
        "morphism_q2p_norm":  g("morphism_q2p_norm"),
        "morphism_p2q_norm":  g("morphism_p2q_norm"),
        "grad_phi_norm":      g("grad_phi_norm"),
        "grad_phi_model_norm": g("grad_phi_model_norm"),
    }
    agent.log_metrics(step, row)


def log_all_metrics(
    agents, step: int, params=None,
    q_field: str = "q", p_field: str = "p",
    phi_belief_field: str = "phi", phi_model_field: str = "phi_model",
    mask_field: str = "mask", n_jobs: int = -1
) -> dict:
    """
    Compute per-agent stats (threading ctx via params), log per-agent rows,
    and return a flat energy total (optionally normalized by total support).
    """
    # cfg (params override config)
    cfg = dict(vars(config))
    if params:
        cfg.update(params)
    logcfg  = cfg.get("logging", {}) or {}
    log_eps = float(cfg.get("log_eps", 1e-10))
    ctx     = cfg.get("ctx", None)

    # Generators (once)
    name = cfg.get("group_name", "so3")
    K_q  = int(cfg.get("K_q", 5))
    K_p  = int(cfg.get("K_p", 5))
    gen_q = _resolve_generators(name, K_q)
    gen_p = _resolve_generators(name, K_p)
    gens  = (gen_q, gen_p)

    # Support masks (unified threshold)
    eps_tau = float(cfg.get("support_cutoff_eps", getattr(config, "support_cutoff_eps", 1e-6)))
    Mask_list = [_support_mask(getattr(A, mask_field), eps_tau) for A in agents]

    # Thread ctx to workers
    cfg_workers = dict(cfg)
    cfg_workers["agents_ref"] = agents
    cfg_workers["ctx"] = ctx

    # Per-agent stats (parallel or serial)
    try:
        from joblib import Parallel, delayed
        results = Parallel(n_jobs=n_jobs, backend="threading", batch_size=1)(
            delayed(compute_agent_metrics)(
                i, agents[i], None, None, Mask_list, cfg_workers, gens, log_eps
            )
            for i in range(len(agents))
        )
    except Exception:
        # fallback serial
        results = [compute_agent_metrics(i, agents[i], None, None, Mask_list, cfg_workers, gens, log_eps)
                   for i in range(len(agents))]

    # Accumulate unnormalized energies
    energy_keys = ["e_self", "e_feedback", "e_align", "e_mod_align",
                   "e_curv", "e_curv_mod", "e_mass", "e_mass_mod"]
    accum = {k: 0.0 for k in energy_keys}

    # Per-agent logging rows (normalized per agent if requested)
    norm_by_support = bool(logcfg.get("normalize_by_support", True))
    for i, stats in results:
        for k in energy_keys:
            accum[k] += float(stats.get(k, 0.0))
        log_agent_metrics(agents[i], step, stats, normalize=norm_by_support)

    # Global normalization by total support (for flat totals only)
    total_support = int(sum(M.sum() for M in Mask_list)) or 1
    S = float(total_support) if norm_by_support else 1.0

    flat = {k: accum[k] / S for k in energy_keys}
    flat["total_energy"]   = float(sum(flat[k] for k in energy_keys))
    flat["support_total"]  = int(total_support)
    flat["step"]           = int(step)

    # Optional: parent rows
    if bool(logcfg.get("log_parent_rows", False)):
        rows = log_parent_metrics(agents, step=step, cfg=cfg_workers, generators=gens, ctx=ctx)
        flat["parent_rows"] = rows

    return flat




def compute_parent_metrics(P, children=None, thr=0.30, cfg=None, generators=None, *, ctx=None) -> dict:
    """
    Summarize one parent agent — cheap by default.
    Heavy parts (Λ counts, cross-scale KL means) are gated by cfg flags:
      cfg['log_lambda_counts'], cfg['log_parent_kl_means']
    """
    cfg = (cfg or {})
    want_lambda = bool(cfg.get("log_lambda_counts", False))
    want_kl = bool(cfg.get("log_parent_kl_means", False))
    eps_xs = float(getattr(config, "energy_eps", 1e-6))

    # Robust children map (accept list or dict)
    def _iter_agents(ob):
        if ob is None:
            return ()
        if isinstance(ob, dict):
            return (v for v in ob.values() if v is not None)
        return (v for v in ob if v is not None)

    children_map = {}
    for a in _iter_agents(children):
        aid = getattr(a, "id", None)
        if aid is not None:
            children_map[int(aid)] = a

    kid_ids = list(getattr(P, "child_ids", []) or [])
    n_kids = len(kid_ids)

    support = _support_mask(P.mask, thr)
    stats = {
        "support_px": int(support.sum()),
        "level": int(getattr(P, "level", 0)),
        "n_children": int(n_kids),
        "has_Phi_q_to_p": bool(getattr(P, "bundle_morphism_q_to_p", None) is not None),
        "has_Phi_p_to_q": bool(getattr(P, "bundle_morphism_p_to_q", None) is not None),
    }

    # Per-pixel vector norm, then SUM over support (energy-style reducer)
    phi = getattr(P, "phi", None)
    stats["phi_norm"] = 0.0 if phi is None else _reduce_over_mask(np.linalg.norm(_as_f32(phi), axis=-1), support, how="sum")

    phi_model = getattr(P, "phi_model", None)
    stats["phi_model_norm"] = 0.0 if phi_model is None else _reduce_over_mask(np.linalg.norm(_as_f32(phi_model), axis=-1), support, how="sum")

    # Λ availability via central transport cache (optional)
    if want_lambda and ctx is not None and n_kids:
        lambda_q_ok = lambda_p_ok = 0
        try:
            for cid in kid_ids:
                ch = children_map.get(int(cid))
                if ch is None:
                    continue
                try:
                    if Lambda_dn(ctx, ch, P, which="q") is not None:
                        lambda_q_ok += 1
                except Exception:
                    pass
                try:
                    if Lambda_dn(ctx, ch, P, which="p") is not None:
                        lambda_p_ok += 1
                except Exception:
                    pass
        except Exception:
            lambda_q_ok = lambda_p_ok = 0
        stats["lambda_q_ok"] = int(lambda_q_ok)
        stats["lambda_p_ok"] = int(lambda_p_ok)

    # Cross-scale KL summaries (optional)
    if want_kl and ctx is not None and n_kids:
        try:
            vals_q = []
            for cid in kid_ids:
                ch = children_map.get(int(cid))
                if ch is None:
                    continue
                v = compute_crossscale_kl_q_single(ch, P, eps=eps_xs, ctx=ctx)
                if np.isfinite(v):
                    vals_q.append(v)
            if vals_q:
                stats["kl_q_mean"] = float(np.mean(vals_q))
        except Exception:
            pass
        try:
            vals_p = []
            for cid in kid_ids:
                ch = children_map.get(int(cid))
                if ch is None:
                    continue
                v = compute_crossscale_kl_p_single(ch, P, eps=eps_xs, ctx=ctx)
                if np.isfinite(v):
                    vals_p.append(v)
            if vals_p:
                stats["kl_p_mean"] = float(np.mean(vals_p))
        except Exception:
            pass

    return stats










def log_parent_metrics(parents, step: int, cfg=None, generators=None, thr=0.3, *, ctx=None) -> list[dict]:
    rows = []
    cfg = cfg or {}
    for pid, P in enumerate(parents):
        s = compute_parent_metrics(
            P,
            children=(P.child_ids and getattr(P, "_children_ref", None)),
            thr=thr, cfg=cfg, generators=generators, ctx=ctx
        )
        s["step"] = int(step)
        s["parent"] = int(pid)
        rows.append(s)
    return rows


def log_parent_metrics_with_children(parents, children, step: int, cfg=None, generators=None, thr=0.3, *, ctx=None) -> list[dict]:
    rows = []
    for pid, P in enumerate(parents):
        s = compute_parent_metrics(P, children=children, thr=thr, cfg=cfg, generators=generators, ctx=ctx)
        s["step"] = step
        s["parent"] = pid
        rows.append(s)
    return rows


# =============================================================================
#                           Snapshot (debugging)
# =============================================================================

def dump_snapshot_npz(
    agents,
    step: int,
    outdir: str,
    *,
    include=("mu_q", "sigma_q", "phi", "mu_p", "sigma_p", "phi_model", "mask"),
    compute_alignment: bool = False,
    compute_curvature: bool = False,
    fp16: bool = True,
    params: dict | None = None,
) -> str:
    """
    Lightweight, fiber-aware snapshot of fields for debugging/analysis.

    Adds:
      - agent_ids:    (N,)  int32
      - agent_levels: (N,)  int16

    Alignment maps are now computed via the Ω-transported path used by energy:
      belief_align[i] = Σ_j KL( q_i  || Ω_ij ▷ q_j ) on support
      model_align[i]  = Σ_j KL( p_i  || Ω̃_ij ▷ p_j ) on support
    """
    import numpy as np
        
    try:
        import core.config as config# noqa: F401
    except Exception:
        class _Cfg: pass
        config = _Cfg()
        setattr(config, "group_name", "so3")

    

    # ---------------- dtypes & helpers ----------------
    tgt_dtype = np.float16 if fp16 else np.float32
    finfo = np.finfo(tgt_dtype)
    _CLIP_MAX = float(min(1e30, finfo.max * 0.9))
    _CLIP_MIN = float(max(-1e30, finfo.min * 0.9)) if np.issubdtype(tgt_dtype, np.floating) else 0.0

    def _safe_to_dtype(x, *, dtype=tgt_dtype, clip_hi=_CLIP_MAX, clip_lo=_CLIP_MIN):
        a = np.asarray(x, np.float64)
        a = np.nan_to_num(a, posinf=clip_hi, neginf=clip_lo)
        a = np.clip(a, clip_lo, clip_hi)
        if a.ndim >= 2 and a.shape[-1] == a.shape[-2]:
            a = 0.5 * (a + np.swapaxes(a, -1, -2))  # visual-only symmetrization
        return np.ascontiguousarray(a, dtype=dtype)

    # --------------- shape introspection ---------------
    N = len(agents)
    assert N > 0, "dump_snapshot_npz: no agents"
    H, W = agents[0].mu_q_field.shape[:2]

    # infer K_q/K_p from actual tensors (avoids drift with config)
    K_q = int(agents[0].mu_q_field.shape[-1])
    K_p = int(agents[0].mu_p_field.shape[-1])
    if getattr(agents[0], "sigma_q_field", None) is not None:
        K_q = int(agents[0].sigma_q_field.shape[-1])
    if getattr(agents[0], "sigma_p_field", None) is not None:
        K_p = int(agents[0].sigma_p_field.shape[-1])

    C_phi = int(getattr(agents[0].phi, "shape", (None, None, 3))[-1] or 3)
    C_phm = C_phi
    if getattr(agents[0], "phi_model", None) is not None:
        C_phm = int(agents[0].phi_model.shape[-1])

    # --------------- schema & containers ---------------
    schema = "v3"
    if hasattr(config, "logging") and isinstance(getattr(config, "logging"), dict):
        schema = config.logging.get("schema_version", schema)
    if params and isinstance(params, dict):
        schema = params.get("logging", {}).get("schema_version", schema)

    out = {"schema": schema}
    out["agent_ids"]    = np.ascontiguousarray([int(getattr(a, "id", i)) for i, a in enumerate(agents)], dtype=np.int32)
    out["agent_levels"] = np.ascontiguousarray([int(getattr(a, "level", 0)) for a in agents], dtype=np.int16)

    # allocate
    if "mu_q"      in include: out["mu_q"]      = np.empty((N, H, W, K_q),      dtype=tgt_dtype, order="C")
    if "sigma_q"   in include: out["sigma_q"]   = np.empty((N, H, W, K_q, K_q), dtype=tgt_dtype, order="C")
    if "phi"       in include: out["phi"]       = np.empty((N, H, W, C_phi),    dtype=tgt_dtype, order="C")
    if "mu_p"      in include: out["mu_p"]      = np.empty((N, H, W, K_p),      dtype=tgt_dtype, order="C")
    if "sigma_p"   in include: out["sigma_p"]   = np.empty((N, H, W, K_p, K_p), dtype=tgt_dtype, order="C")
    if "phi_model" in include: out["phi_model"] = np.empty((N, H, W, C_phm),    dtype=tgt_dtype, order="C")
    if "mask"      in include: out["mask"]      = np.empty((N, H, W),           dtype=tgt_dtype, order="C")

    # zero-init optional layers so failures never leave junk
    if compute_alignment:
        out["belief_align"] = np.zeros((N, H, W), dtype=tgt_dtype, order="C")
        out["model_align"]  = np.zeros((N, H, W), dtype=tgt_dtype, order="C")
    if compute_curvature:
        out["Fq_norm"] = np.zeros((N, H, W), dtype=tgt_dtype, order="C")
        out["Fp_norm"] = np.zeros((N, H, W), dtype=tgt_dtype, order="C")

    # --------------- fill basics ---------------
    for i, A in enumerate(agents):
        if "mu_q" in include and getattr(A, "mu_q_field", None) is not None:
            out["mu_q"][i, ...] = _safe_to_dtype(A.mu_q_field)
        if "sigma_q" in include and getattr(A, "sigma_q_field", None) is not None:
            out["sigma_q"][i, ...] = _safe_to_dtype(A.sigma_q_field)
        if "phi" in include and getattr(A, "phi", None) is not None:
            out["phi"][i, ...] = _safe_to_dtype(A.phi)
        if "mu_p" in include and getattr(A, "mu_p_field", None) is not None:
            out["mu_p"][i, ...] = _safe_to_dtype(A.mu_p_field)
        if "sigma_p" in include and getattr(A, "sigma_p_field", None) is not None:
            out["sigma_p"][i, ...] = _safe_to_dtype(A.sigma_p_field)
        if "phi_model" in include and getattr(A, "phi_model", None) is not None:
            out["phi_model"][i, ...] = _safe_to_dtype(A.phi_model)
        if "mask" in include and getattr(A, "mask", None) is not None:
            out["mask"][i, ...] = _safe_to_dtype(A.mask)

    # --------------- optional heavy bits ---------------
    if compute_alignment or compute_curvature:
        # resolve generators once (curvature path)
        group_name = getattr(config, "group_name", "so3")
        Gq = _resolve_generators(group_name, K_q); Gp = _resolve_generators(group_name, K_p)
        if isinstance(Gq, dict): Gq = Gq.get("generators", Gq)
        if isinstance(Gp, dict): Gp = Gp.get("generators", Gp)

        # curvature norms
        if compute_curvature:
            dx = float(getattr(config, "dx", 1.0))
            for i, A in enumerate(agents):
                if getattr(A, "phi", None) is not None:
                    Fq = compute_field_strength(np.asarray(A.phi, np.float32), np.asarray(Gq, np.float32), dx=dx)["xy"]
                    out["Fq_norm"][i, ...] = _safe_to_dtype(np.linalg.norm(Fq, axis=(-2, -1)))
                if getattr(A, "phi_model", None) is not None:
                    Fp = compute_field_strength(np.asarray(A.phi_model, np.float32), np.asarray(Gp, np.float32), dx=dx)["xy"]
                    out["Fp_norm"][i, ...] = _safe_to_dtype(np.linalg.norm(Fp, axis=(-2, -1)))

        # Ω-transported alignment (same path as energy)
        if compute_alignment:
            ctx = None
            if isinstance(params, dict):
                ctx = params.get("runtime_ctx") or params.get("ctx")

            for i, A in enumerate(agents):
                try:
                    q_map = compute_alignment_field_general(agents, int(getattr(A, "id", i)), field_type="belief", ctx=ctx)
                    out["belief_align"][i, ...] = _safe_to_dtype(q_map)
                except Exception:
                    pass
                try:
                    p_map = compute_alignment_field_general(agents, int(getattr(A, "id", i)), field_type="model", ctx=ctx)
                    out["model_align"][i, ...] = _safe_to_dtype(p_map)
                except Exception:
                    pass

    # --------------- save -----------------------------
    Path(outdir).mkdir(parents=True, exist_ok=True)
    fname = str(Path(outdir) / f"step_{step:04d}.npz")

    _sanitize_alignment_curvature_inplace(out, tgt_dtype)

    for k, v in list(out.items()):
        if isinstance(v, np.ndarray) and not v.flags.writeable:
            out[k] = np.ascontiguousarray(v)

    np.savez_compressed(fname, **out)
    return fname



def _symmetrize_2t(a):
    # a: (...,K,K)
    return 0.5 * (a + np.swapaxes(a, -1, -2))

def _safe_spd(a, eps: float = 1e-6):
    # make SPD-ish for visualization math
    a = _symmetrize_2t(np.asarray(a, np.float32))
    # eig floor
    w, V = np.linalg.eigh(a)
    w = np.clip(w, eps, None)
    return (V * w[..., None, :]) @ np.swapaxes(V, -1, -2)

def _kl_gauss_per_pixel(mu1, S1, mu2, S2):
    """
    KL(N1 || N2) per-pixel, vectorized over (H,W):
      0.5 * [ tr(S2^{-1} S1) + (μ2-μ1)^T S2^{-1} (μ2-μ1) - k + log(|S2|/|S1|) ]
    Shapes:
      mu*: (H,W,K)
      S*:  (H,W,K,K)
    Returns:
      kl:  (H,W)  (float32, non-negative up to num. noise)
    """
    import numpy as np
    mu1 = np.asarray(mu1, np.float32)
    mu2 = np.asarray(mu2, np.float32)
    S1  = _safe_spd(S1)
    S2  = _safe_spd(S2)

    H, W, K = mu1.shape
    # Solve S2 X = S1 => X = S2^{-1} S1
    # We'll reshape to (HW,K,K) for batched solves
    HW = H * W
    S2f = S2.reshape(HW, K, K)
    S1f = S1.reshape(HW, K, K)

    # Solve each column of S1: S2 * X = S1 => X[..., :, j] = solve(S2, S1[..., :, j])
    X = np.empty_like(S1f)
    for j in range(K):
        X[..., :, j] = np.linalg.solve(S2f, S1f[..., :, j])
    tr_term = np.trace(X, axis1=-2, axis2=-1).reshape(H, W)

    # Mahalanobis term: (mu2-mu1)^T S2^{-1} (mu2-mu1)
    d = (mu2 - mu1).reshape(HW, K, 1)
    y = np.linalg.solve(S2f, d)                         # (HW,K,1)
    maha = (d.transpose(0, 2, 1) @ y).reshape(H, W)     # (H,W)

    # logdet term
    sign2, logdet2 = np.linalg.slogdet(S2f)
    sign1, logdet1 = np.linalg.slogdet(S1f)
    # be defensive: if any sign <= 0, zero the term locally
    mask_ok = (sign2 > 0) & (sign1 > 0)
    logdet_ratio = np.zeros((HW,), np.float32)
    logdet_ratio[mask_ok] = (logdet2 - logdet1)[mask_ok]
    logdet_ratio = logdet_ratio.reshape(H, W)

    kl = 0.5 * (tr_term + maha - K + logdet_ratio)
    return np.maximum(kl.astype(np.float32), 0.0)


def _sanitize_alignment_curvature_inplace(out: dict, tgt_dtype):
    """
    Clean up alignment/curvature maps before saving:
      - nan/inf -> 0
      - clamp alignment to >= 0
      - hard-mask by 'mask' if present
    """
    import numpy as np

    for k in ("belief_align", "model_align"):
        if k in out and out[k] is not None:
            a = np.nan_to_num(out[k], nan=0.0, posinf=0.0, neginf=0.0)
            a = np.maximum(a, 0.0)  # alignment is KL-like
            if "mask" in out and out["mask"] is not None:
                try:
                    m = (out["mask"] > 0).astype(a.dtype)
                    a = a * m
                except Exception:
                    pass
            out[k] = a.astype(tgt_dtype, copy=False)

    for k in ("Fq_norm", "Fp_norm"):
        if k in out and out[k] is not None:
            out[k] = np.nan_to_num(out[k], nan=0.0, posinf=0.0, neginf=0.0).astype(tgt_dtype, copy=False)




def _select_primary_parent(agent, ctx, *, level: int = 1):
    """
    Resolve the first listed parent id to an object using the level-aware registry.
    Falls back to legacy mirror and agents_by_level if needed.
    """
    pids = list(getattr(agent, "parent_ids", []) or [])
    if not pids:
        return None
    pid = int(pids[0])

    # Preferred: level-aware registry
    if ctx is not None:
        try:
            reg, _ = ctx.get_parent_registry(level)
            if isinstance(reg, dict):
                P = reg.get(pid)
                if P is not None:
                    return P
                # fallback linear scan in case ids are str/int-mismatched
                for v in reg.values():
                    try:
                        if int(getattr(v, "id", -1)) == pid:
                            return v
                    except Exception:
                        continue
        except Exception:
            pass

        # Secondary fallback: agents_by_level
        try:
            ablv = getattr(ctx, "agents_by_level", {})
            if isinstance(ablv, dict):
                cand = ablv.get(level, {}).get(pid)
                if cand is not None:
                    return cand
        except Exception:
            pass

        # Legacy fallback (if still present)
        pbr = getattr(ctx, "parents_by_region", None) or {}
        if isinstance(pbr, dict):
            P = pbr.get(pid)
            if P is not None:
                return P
            for v in pbr.values():
                try:
                    if int(getattr(v, "id", -1)) == pid:
                        return v
                except Exception:
                    continue

    return None




# ──────────────────────────────
# Canonical diagnostics helpers
# ──────────────────────────────




# ---- Masks & support ----------------------------------------

def _auto_support_from_push(S_pq, mask, eps):
    import numpy as np
    H, W = mask.shape[:2]
    # Accept 4-D (H,W,K,K) and 6-D (...,H,W,K,K)
    ok = (
        S_pq.ndim in (4, 6)
        and S_pq.shape[-1] == S_pq.shape[-2]  # square cov
        and (S_pq.shape[-4:-2] == (H, W) if S_pq.ndim == 6 else S_pq.shape[:2] == (H, W))
    )
    # If shape unexpected, fall back to mask (NOT zeros)
    if not ok:
        return np.asarray(mask, dtype=bool)

    # Finite check
    finite = np.isfinite(S_pq).all(axis=(-1, -2))
    if S_pq.ndim == 6:
        finite = finite.reshape(H, W)

    # SPD check: use >= with a tiny cushion so sanitize-to-eps passes
    K = S_pq.shape[-1]
    M = S_pq.reshape(-1, K, K)
    Ms = 0.5 * (M + np.swapaxes(M, 1, 2))
    try:
        w = np.linalg.eigvalsh(Ms)
        lam_min = w[:, 0]
        lam_min = lam_min.reshape(H, W)
        tol = max(float(eps), 1e-9)
        spd = lam_min >= tol
    except Exception:
        spd = np.zeros((H, W), dtype=bool)

    return (np.asarray(mask, bool) & finite & spd)




# ---- KL map (pixelwise) -------------------------------------

def _kl_map(mu1, S1, mu2, S2, support, eps):
    """
    Per-pixel KL(q1 || q2) with SPD hygiene; zeros outside 'support'.
    Accepts full grids (H,W,...) or pre-sliced overlap arrays (M,...).
    """
    mu1 = np.asarray(mu1, np.float32)
    mu2 = np.asarray(mu2, np.float32)
    S1  = sanitize_sigma(np.asarray(S1,  np.float32), eps=eps)
    S2  = sanitize_sigma(np.asarray(S2,  np.float32), eps=eps)

    support = support.astype(bool, copy=False)

    # Fast-path if already flattened to (M,·)
    if mu1.ndim == 2 and mu2.ndim == 2:
        kl_vals = kl_gaussian(mu1, S1, mu2, S2, eps=eps).astype(np.float32, copy=False)
        return np.where(support, kl_vals, 0.0)

    H, W = support.shape
    idx = np.flatnonzero(support.reshape(-1))
    if idx.size == 0:
        return np.zeros((H, W), dtype=np.float32)

    mu1_f = mu1.reshape(-1, mu1.shape[-1])[idx]
    mu2_f = mu2.reshape(-1, mu2.shape[-1])[idx]
    S1_f  = S1.reshape(-1, S1.shape[-2], S1.shape[-1])[idx]
    S2_f  = S2.reshape(-1, S2.shape[-2], S2.shape[-1])[idx]

    kl_vals = kl_gaussian(mu1_f, S1_f, mu2_f, S2_f, eps=eps).astype(np.float32, copy=False)
    out = np.zeros((H, W), dtype=np.float32)
    out.reshape(-1)[idx] = np.maximum(np.where(np.isfinite(kl_vals), kl_vals, 0.0), 0.0)
    return out






# ---- Small utilities (single source of truth) ----------------

def _as_f32(x): 
    return np.asarray(x, np.float32)



def _fiber_views(A, which):
    if which == "q":
        return A.mu_q_field, A.sigma_q_field, A.phi, getattr(A, "generators_q", None), int(getattr(config, "K_q", 3))
    if which == "p":
        return A.mu_p_field, A.sigma_p_field, A.phi_model, getattr(A, "generators_p", None), int(getattr(config, "K_p", 3))
    raise ValueError(f"which must be 'q' or 'p', got {which!r}")

def _resolve_generators(group_name, K):
    ret = get_generators(group_name, K)
    if isinstance(ret, dict) and "generators" in ret: 
        return ret["generators"]
    if isinstance(ret, (list, tuple)) and len(ret) > 0: 
        return ret[0]
    return ret

def _fro_sq_map(M):
    M = np.asarray(M, np.float32)
    if M.ndim == 2:
        return float(np.sum(M * M))
    return np.sum(M * M, axis=(-2, -1))

def _fro_map(M):  # (..., K, K) -> (...,)
    M = np.asarray(M, np.float32)
    return np.sqrt(np.einsum("...ij,...ij->...", M, M, optimize=True))

def _support_mask(mask, eps=None):
    """
    Boolean support = (soft mask > tau). Default tau = config.support_cutoff_eps.
    Accepts (...), (H,W), or (H,W,1); squeezes the last dim if single-channel.
    """
    tau = float(getattr(config, "support_cutoff_eps", 1e-3) if eps is None else eps)
    m = np.asarray(mask, np.float32)
    if m.ndim == 3 and m.shape[-1] == 1:
        m = np.squeeze(m, axis=-1)
    return m > tau


def _as_bool_mask(mask, eps=None):
    """Return a boolean mask. If already boolean, return as-is; else threshold via _support_mask."""
    if mask is None:
        return None
    m = np.asarray(mask)
    return m if m.dtype == bool else _support_mask(m, eps)


def _reduce_over_mask(arr, mask, how="sum", eps=None):
    """
    Finite-sanitized reduction over a (possibly soft) mask.
      how: "sum" | "mean"
      eps: threshold for soft masks (defaults to config.support_cutoff_eps)
    Energy path: prefer how="sum". Diagnostics: how="mean".
    """
    m = _as_bool_mask(mask, eps)
    if m is None or not m.any():
        return 0.0
    x = np.asarray(arr, np.float64)
    x = np.where(np.isfinite(x), x, 0.0)
    if how == "mean":
        return float(np.mean(x[m]))
    # default: sum
    return float(np.sum(x[m], dtype=np.float64))


def _first_parent(child, parents_by_id):
    for pid in getattr(child, "parent_ids", ()) or ():
        P = parents_by_id.get(int(pid))
        if P is not None:
            return P
    return None





