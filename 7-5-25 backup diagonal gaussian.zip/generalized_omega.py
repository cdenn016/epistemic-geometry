import numpy as np
import config
from scipy.linalg import expm
from generalized_math_utils import sanitize_q
import numpy as np
from scipy.linalg import expm
from joblib import Parallel, delayed
from joblib import Parallel, delayed
import numpy as np
import config  # for config.num_cores or set n_jobs manually
from joblib import Parallel, delayed, parallel_backend

_EPS = config.log_eps

def repair_if_forgotten(q: np.ndarray, eps: float, threshold: float = 1e-6) -> np.ndarray:
   
    total_mass = np.sum(q)
    if total_mass < threshold or not np.isfinite(total_mass):
        K = q.shape[-1]
        q = np.random.dirichlet(np.ones(K)) * eps * K
    else:
        q = np.clip(q, eps, 1.0)
        q /= np.sum(q) + eps
    return q

def compute_inter_agent_omega(
    phi_i: np.ndarray,
    phi_j: np.ndarray,
    coord: tuple[int, ...],
    generators: np.ndarray,
    use_commutator: bool = False,
    phi_key: str = "phi",
) -> np.ndarray:
   
    from config import e_belief, e_model
    e = e_belief if phi_key == "phi" else e_model

    # 1) Extract the Lie-algebra vectors at coord
    φi_vec = phi_i[coord] / e
    φj_vec = phi_j[coord] / e

    # 2) Delegate to central helper
    Ω = build_inter_agent_omega(
        φi_vec[None],       # shape (1, d)
        φj_vec[None],       # shape (1, d)
        generators,
        config=config,
        use_commutator=use_commutator
    )  # returns shape (1, K, K)

    return Ω[0]

def repair_if_forgotten_batch(q: np.ndarray, eps: float, threshold: float = 1e-6) -> np.ndarray:
   
    q = np.nan_to_num(q, nan=0.0, posinf=0.0, neginf=0.0)
    orig_shape = q.shape
    K = q.shape[-1]
    q_flat = q.reshape(-1, K)
    norms = np.sum(q_flat, axis=-1, keepdims=True)

    forgotten = (norms < threshold) | (~np.isfinite(norms))

    if np.any(forgotten):
        n_forgotten = np.sum(forgotten)
        repaired = np.random.dirichlet(np.ones(K), size=n_forgotten) * eps * K
        q_flat[forgotten.squeeze()] = repaired

    q_flat = np.clip(q_flat, eps, 1.0)
    q_flat /= np.sum(q_flat, axis=-1, keepdims=True) + eps
    return q_flat.reshape(orig_shape)

def kl_divergence(q1, q2, eps = _EPS):
    q1 = np.clip(q1, eps, 1.0)
    q2 = np.clip(q2, eps, 1.0)
    return np.sum(q1 * (np.log(q1) - np.log(q2)), axis=-1)

def adaptive_expm(G, clip_norm=None, max_norm = None):
   
    norm_G = np.linalg.norm(G)
    if clip_norm is not None and norm_G > clip_norm:
        G = G * (clip_norm / norm_G)
    return expm(G)


def exp_lie_algebra_operator(
    v,
    generators,
    use_expm=True,
    threshold=1e-3,
    max_norm=20,
    group_name=None,  # 'so3', 'sl2r', 'su2', etc.
):
    """
    Compute exp(Σ_a v_a T_a) for arbitrary Lie algebra representation.

    Parameters:
    - v: np.ndarray shape (dim_G,), Lie algebra coefficients
    - generators: np.ndarray shape (dim_G, K, K), generators for Lie algebra rep
    - use_expm: bool, use scipy expm for large norms
    - threshold: float, norm threshold below which to use Taylor approx
    - max_norm: float, max allowed norm to prevent blowup
    - group_name: str or None, optionally specify to apply group-specific handling

    Returns:
    - np.ndarray (K, K): the group element exp(Σ vᵃ Tₐ)
    """
    norm_v = np.linalg.norm(v)
    eps = 1e-16
    safe_norm = norm_v + eps

    scale = min(1.0, max_norm / safe_norm)
    v_scaled = v * scale

    G = np.einsum('a,aij->ij', v_scaled, generators)

    # === SO(3)-specific antisymmetrization for numerical stability ===
    if group_name == "so3":
        G = 0.5 * (G - G.T)

    if safe_norm < threshold or not use_expm:
        I = np.eye(G.shape[0], dtype=G.dtype)
        return I + G + 0.5 * (G @ G)
    else:
        return expm(G)



def exp_lie_algebra_irrep(
    v,
    generators,
    use_expm=True,
    threshold=1e-3,
    max_norm=20,
    group_name=None,
    n_jobs=-1  # parallelize across available CPUs
):
    """
    Parallelized version of exp(Σ v_a T_a) using joblib.
    """
    norm_v = np.linalg.norm(v, axis=-1)
    eps = 1e-16
    safe = norm_v[..., None] + eps

    # Clamp large-norm vectors
    scale = np.where(norm_v[..., None] > max_norm, max_norm / safe, 1.0)
    v_scaled = v * scale

    # Contract Lie algebra element: (..., a) x (a, K, K) → (..., K, K)
    G = np.einsum('...a,aij->...ij', v_scaled, generators)

    # Group-specific antisymmetrization
    if group_name == "so3":
        G = 0.5 * (G - np.swapaxes(G, -1, -2))
    elif group_name == "su2":
        G = 0.5 * (G - np.swapaxes(G, -1, -2).conj())

    # Preallocate result array
    result = np.empty_like(G)
    approx_mask = norm_v < threshold

    # Fast Taylor expansion for small-norm elements
    if np.any(approx_mask):
        I = np.eye(G.shape[-1], dtype=G.dtype)
        G_approx = G[approx_mask]
        G2 = G_approx @ G_approx
        result[approx_mask] = I + G_approx + 0.5 * G2

    # Heavy expm for the rest — use parallelism
    if np.any(~approx_mask):
        idxs = np.nonzero(~approx_mask)[0]
        G_heavy = [G[i] for i in idxs]

        # Parallel matrix exponentials
        expm_results = Parallel(n_jobs=n_jobs, backend = "threading")(
            delayed(expm)(G_i) for G_i in G_heavy
        )

        for i, res in zip(idxs, expm_results):
            result[i] = res

    return result



from joblib import Parallel, delayed
import numpy as np
from scipy.linalg import expm

def batch_exp_lie_algebra_irrep(
    v_batch,
    generators,
    use_expm=True,
    threshold=1e-3,
    max_norm=20,
    group_name=None,
    n_jobs=-1  # Optional parallelism for large-norm cases
):
    """
    Compute batch of exp(sum_a v[a] * T_a) using Taylor or expm depending on norm.

    Parameters:
    - v_batch: (..., dim_G) Lie algebra coefficients
    - generators: (dim_G, K, K) Lie algebra generators
    - use_expm: use adaptive_expm or scipy.expm for large-norm cases
    - threshold: Taylor cutoff for small norms
    - max_norm: clamp large-norm vectors
    - group_name: (optional) cleanup: "so3", "su2", etc.
    - n_jobs: parallel jobs for large-norm exponentials

    Returns:
    - (..., K, K): batch of exponentiated matrices
    """

    # Fallback definition if adaptive_expm is not available
    def adaptive_expm(A, **kwargs):
        return expm(A)

    *batch_shape, dim_G = v_batch.shape
    v_flat = v_batch.reshape(-1, dim_G)
    N = v_flat.shape[0]
    _, K, _ = generators.shape
    dtype = v_batch.dtype

    # --- Normalize ---
    norms = np.linalg.norm(v_flat, axis=1)
    eps = 1e-16
    scale_factors = np.minimum(1.0, max_norm / (norms + eps))
    v_scaled = v_flat * scale_factors[:, None]

    # --- Construct algebra elements ---
    G_batch = np.einsum("na,aij->nij", v_scaled, generators)

    # --- Group-specific antisymmetrization ---
    if group_name == "so3":
        G_batch = 0.5 * (G_batch - np.transpose(G_batch, axes=(0, 2, 1)))
    elif group_name == "su2":
        G_batch = 0.5 * (G_batch - np.transpose(G_batch, axes=(0, 2, 1)).conj())

    # --- Initialize result buffer ---
    result = np.empty((N, K, K), dtype=dtype)
    approx_mask = norms * scale_factors < threshold

    # --- Taylor expansion for small-norm matrices ---
    if np.any(approx_mask):
        G_approx = G_batch[approx_mask]
        I = np.eye(K, dtype=dtype)[None, :, :]
        G2 = G_approx @ G_approx
        result[approx_mask] = I + G_approx + 0.5 * G2

    # --- Parallel expm fallback for large-norm matrices ---
    if np.any(~approx_mask):
        idxs = np.flatnonzero(~approx_mask)
        G_heavy = [G_batch[i] for i in idxs]

        expm_results = Parallel(n_jobs=n_jobs, backend="threading")(
            delayed(adaptive_expm)(G) for G in G_heavy
        )

        for i, res in zip(idxs, expm_results):
            result[i] = res

    return result.reshape(*batch_shape, K, K)




def batch_apply_omega(q_batch, omega_batch, n_jobs=None, parallel_threshold = 1000):
    """
    Adaptive application of Ω to q_batch — uses parallel if batch is large.
    """
    batch_size = np.prod(q_batch.shape[:-1])
    if batch_size < parallel_threshold:
        return np.einsum('...ij,...j->...i', omega_batch, q_batch)
    else:
        return batch_apply_omega_parallel(q_batch, omega_batch, n_jobs)



def _apply_single_omega(q, omega):
    return omega @ q



def batch_apply_omega_parallel(q_batch, omega_batch, n_jobs=None):
    """
    Parallel version of batch_apply_omega using joblib with threading backend.

    Args:
        q_batch: [..., K] array of belief vectors
        omega_batch: [..., K, K] array of group matrices
        n_jobs: Number of parallel jobs (defaults to config.num_cores)

    Returns:
        Transformed batch: [..., K]
    """
    assert q_batch.shape == omega_batch.shape[:-1], (
        f"Mismatch: q_batch {q_batch.shape} vs omega_batch {omega_batch.shape}"
    )

    n_jobs = n_jobs or config.num_cores
    flat_q = q_batch.reshape(-1, q_batch.shape[-1])
    flat_omega = omega_batch.reshape(-1, omega_batch.shape[-2], omega_batch.shape[-1])

    with parallel_backend("threading"):
        results = Parallel(n_jobs=n_jobs)(
            delayed(_apply_single_omega)(q, ω) for q, ω in zip(flat_q, flat_omega)
        )

    return np.stack(results).reshape(q_batch.shape)


def apply_omega(q_vec, omega):
    """
    Apply a single group matrix Ω to a belief vector or batch of vectors q_vec.

    Args:
        q_vec: np.ndarray with shape (K,) or (..., K)
        omega: np.ndarray with shape (K, K)

    Returns:
        Transformed vector(s) with shape same as q_vec
    """
    assert omega.shape[0] == omega.shape[1], "Omega must be square"
    assert q_vec.shape[-1] == omega.shape[0], (
        f"Dimension mismatch: q_vec last dim {q_vec.shape[-1]} != omega shape {omega.shape}"
    )

    # Contract last dim of q_vec with omega
    return np.einsum('ij,...j->...i', omega, q_vec)

def compute_spatial_gradient_matrix_field(A_field, axis=0):
    grad = np.zeros_like(A_field)
    axis_size = A_field.shape[axis]
    edge_order = 2 if axis_size >= 3 else 1  # robustly handle small grid sizes
    
    for i in range(A_field.shape[-2]):
        for j in range(A_field.shape[-1]):
            grad[..., i, j] = np.gradient(A_field[..., i, j], axis=axis, edge_order=edge_order)
    return grad



def compute_gauge_potential(phi):
    """
    Compute gauge potentials A_μ^a = ∂_μ φ^a for arbitrary Lie algebra and base dimension D.
        BE CAREFUL! CANNOT PASS THIS OUTPUT INTO COMMUTATOR WITHOUT CONVERTING
    Args:
        phi: np.ndarray, shape (..., d), where
             ... represents spatial dimensions (S_1,...,S_D),
             d = dim Lie algebra.

    Returns:
        A: tuple of length D, each entry np.ndarray of shape (..., d),
           spatial derivatives of phi along each base manifold dimension.
    """
    D = phi.ndim - 1  # subtract Lie algebra dimension axis
    spatial_axes = tuple(range(D))
    A = tuple(np.gradient(phi, axis=axis) for axis in spatial_axes)
    return A


def compute_commutator(A_mu, A_nu):
    """
    Compute matrix commutator [A_μ, A_ν] = A_μ A_ν - A_ν A_μ for batch matrices.

    Args:
        A_mu, A_nu: np.ndarray with shape (..., K, K)

    Returns:
        commutator: np.ndarray with shape (..., K, K)
    """
    return np.matmul(A_mu, A_nu) - np.matmul(A_nu, A_mu)




def compute_field_strength(phi, generators):
    """
    Computes F_{μν} = ∂_μ A_ν - ∂_ν A_μ + [A_μ, A_ν], where A_μ = ∂_μ φ^a G_a
    """
    D = phi.ndim - 1  # spatial dimensions
    A_mu_coeffs = [np.gradient(phi, axis=mu) for mu in range(D)]  # (..., d)
    
    
    A_matrices = [np.einsum('...a,aij->...ij', coeffs, generators) for coeffs in A_mu_coeffs]

    # Now project ∂_μ φ^a onto matrix-valued A_μ = ∂_μ φ^a · G_a
    A_matrices = [np.einsum('...a,aij->...ij', coeffs, generators) for coeffs in A_mu_coeffs]

    curvature_norms = {}
    for mu in range(D):
        for nu in range(mu + 1, D):
            # Derivatives of matrix-valued A_ν along μ, etc
            dA_nu_dmu = compute_spatial_gradient_matrix_field(A_matrices[nu], axis=mu)
            dA_mu_dnu = compute_spatial_gradient_matrix_field(A_matrices[mu], axis=nu)


            # Matrix commutator [A_μ, A_ν]
            comm = compute_commutator(A_matrices[mu], A_matrices[nu])

            # Final curvature
            F_munu = dA_nu_dmu - dA_mu_dnu + comm

            # Frobenius norm per spatial point
            curvature_norms[(mu, nu)] = np.linalg.norm(F_munu, axis=(-2, -1))

    return curvature_norms


def build_inter_agent_omega(phi_i, phi_j, generators, config=None, use_commutator=False):
    """
    Compute the inter-agent gauge transport operator field Ω_{ij}(x).

    Parameters:
        phi_i: np.ndarray shape (..., d) — φ_i field over spatial domain
        phi_j: np.ndarray shape (..., d) — φ_j field over spatial domain
        generators: np.ndarray shape (d, K, K) — Lie algebra generators
        config: optional config object to override use_commutator
        use_commutator: bool —
            if False, do non-abelian exp(φ_i) @ exp(-φ_j);
            if True,  do abelian exp(φ_i - φ_j)

    Returns:
        omega_ij: np.ndarray shape (..., K, K) — inter-agent transport operator
    """
    # allow config to override the flag
    if config is not None:
        use_commutator = getattr(config, "use_commutator", use_commutator)

    # difference field (..., d)
    delta = phi_i - phi_j

    if not use_commutator:
        # non-abelian: exp(φ_i) @ exp(-φ_j)
        g_i     = exp_lie_algebra_irrep(phi_i, generators, group_name=getattr(config, "group_name", None))
        g_j_inv = exp_lie_algebra_irrep(-phi_j, generators, group_name=getattr(config, "group_name", None))
        return np.matmul(g_i, g_j_inv)

    # abelian shortcut: exp(φ_i - φ_j)
    return exp_lie_algebra_irrep(delta, generators, group_name=getattr(config, "group_name", None))



def compute_pairwise_kl(agents, generators, params, return_pointwise=False):
    log_eps = params.get("log_eps", 1e-8)
    overlap_eps = params.get("overlap_eps", 1e-6)
    N = len(agents)
    kl_matrix = np.full((N, N), np.inf)
    pointwise = {} if return_pointwise else None
    
    for i in range(N):
        qi = agents[i].q
        mask_i = agents[i].mask > overlap_eps
        flat_qi = qi.reshape(-1, qi.shape[-1])

        for j in range(N):
            if i == j:
                kl_matrix[i, j] = 0.0
                continue

            qj = agents[j].q
            mask_j = agents[j].mask > overlap_eps
            overlap = mask_i & mask_j
            if not np.any(overlap):
                continue

            idxs = np.flatnonzero(overlap.reshape(-1))

            qi_vals = sanitize_q(flat_qi[idxs], eps=log_eps)
            qj_vals = sanitize_q(qj.reshape(-1, qj.shape[-1])[idxs], eps=log_eps)

            phi_i_vals = agents[i].phi.reshape(-1, agents[i].phi.shape[-1])[idxs]
            phi_j_vals = agents[j].phi.reshape(-1, agents[j].phi.shape[-1])[idxs]

            omega = build_inter_agent_omega(phi_i_vals, phi_j_vals, generators, config=params)
            qj_rot = batch_apply_omega(qj_vals, omega)
            qj_rot = sanitize_q(qj_rot, eps=log_eps)

            # compute both per‐point and mean KL
            pw = (qi_vals * np.log(qi_vals / (qj_rot + log_eps))).sum(axis=-1)
            kl_matrix[i, j] = pw.mean()
            if return_pointwise:
                pointwise[(i, j)] = pw

    return (kl_matrix, pointwise) if return_pointwise else kl_matrix

def compute_pairwise_model_kl(agents, generators, params, return_pointwise=False):
    """Compute pairwise D_KL(p_i || Ω̃_ij p_j) using model gauge frames φ_model."""
    log_eps     = params.get("log_eps", 1e-8)
    overlap_eps = params.get("overlap_eps", 1e-6)
    N = len(agents)
    kl_matrix = np.full((N, N), np.inf)
    pointwise = {} if return_pointwise else None
    
    for i in range(N):
        pi = agents[i].p
        mask_i = agents[i].mask > overlap_eps
        flat_pi = pi.reshape(-1, pi.shape[-1])

        for j in range(N):
            if i == j:
                kl_matrix[i, j] = 0.0
                continue

            pj = agents[j].p
            mask_j = agents[j].mask > overlap_eps
            overlap = mask_i & mask_j
            if not np.any(overlap):
                continue

            idxs = np.flatnonzero(overlap.reshape(-1))

            pi_vals = sanitize_q(flat_pi[idxs], eps=log_eps)
            pj_vals = sanitize_q(pj.reshape(-1, pj.shape[-1])[idxs], eps=log_eps)

            phi_i_vals = agents[i].phi_model.reshape(-1, agents[i].phi_model.shape[-1])[idxs]
            phi_j_vals = agents[j].phi_model.reshape(-1, agents[j].phi_model.shape[-1])[idxs]

            omega = build_inter_agent_omega(phi_i_vals, phi_j_vals, generators, config=params)
            pj_rot = batch_apply_omega(pj_vals, omega)
            pj_rot = sanitize_q(pj_rot, eps=log_eps)

            pw = (pi_vals * np.log(pi_vals / (pj_rot + log_eps))).sum(axis=-1)
            kl_matrix[i, j] = pw.mean()
            if return_pointwise:
                pointwise[(i, j)] = pw

    return (kl_matrix, pointwise) if return_pointwise else kl_matrix