import numpy as np
import networkx as nx
from scipy.ndimage import gaussian_filter
from generalized_agent_schema import Agent
from numpy.fft import fftn, ifftn
import matplotlib.pyplot as plt
import config


#TRANSPORT ONLY??
def compute_overlap_volume(mask_i, mask_j, threshold=1e-5):
    overlap = mask_i * mask_j
    return np.sum(overlap > threshold)

#HOLONOMY
def build_overlap_graph(agents, support_cutoff_eps):
    G = nx.Graph()
    N = len(agents)
    G.add_nodes_from(range(N))

    for i in range(N):
        mask_i = agents[i].mask
        for j in range(i + 1, N):
            mask_j = agents[j].mask
            overlap = (mask_i * mask_j) > support_cutoff_eps
            if np.any(overlap):
                weight = np.sum(mask_i * mask_j)
                G.add_edge(i, j, weight=weight)

    return G

#ONLY TRANSPORT??
def build_overlap_graph_with_weights(agents, support_cutoff_eps):
    G = nx.Graph()
    N = len(agents)
    G.add_nodes_from(range(N))

    for i in range(N):
        for j in range(i + 1, N):
            vol = compute_overlap_volume(agents[i].mask, agents[j].mask, support_cutoff_eps)
            if vol > 0:
                G.add_edge(i, j, weight=1.0 / (vol + 1e-8), volume=vol)

    return G


#HOLONOMY
def find_agent_chain(agents, start_id, end_id, support_cutoff_eps):
    G = build_overlap_graph(agents, support_cutoff_eps)
    try:
        path = nx.shortest_path(G, start_id, end_id)
        return path
    except nx.NetworkXNoPath:
        return None



#HOLONOMY
def get_wrapped_position(p1, p2, domain_size):
    return np.array([
        p2[d] - p1[d] - domain_size[d] * round((p2[d] - p1[d]) / domain_size[d])
        for d in range(len(domain_size))
    ])




#HOLONOMY
def get_overlap_centroid(agent_a, agent_b, domain_size, support_cutoff_eps=1e-3):
    mask_a = agent_a.mask > support_cutoff_eps
    mask_b = agent_b.mask > support_cutoff_eps

    # Sanity check: ensure masks match spatial dimension
    if mask_a.ndim != len(domain_size):
        raise ValueError(
            f"Agent mask dimension ({mask_a.ndim}) does not match domain size ({len(domain_size)})"
        )

    overlap = mask_a & mask_b
    if not np.any(overlap):
        return None
    #print(f"[DEBUG] mask_a.shape = {mask_a.shape}, mask_b.shape = {mask_b.shape}")

    coords = np.array(np.nonzero(overlap)).T  # shape (N, D)
    centroid = np.mean(coords, axis=0)        # shape (D,)
    discrete_centroid = np.round(centroid).astype(int)
    wrapped_centroid = tuple(discrete_centroid[d] % domain_size[d] for d in range(len(domain_size)))
    return wrapped_centroid



#ONLY TRANSPORT>>??
def find_candidate_paths(agents, start_id, end_id, d, domain_size, support_cutoff_eps=1e-5):
    G = build_overlap_graph_with_weights(agents, support_cutoff_eps)

    try:
        all_paths = list(nx.all_simple_paths(G, source=start_id, target=end_id, cutoff=d + 1))
    except nx.NetworkXNoPath:
        return [], None, None, None

    candidate_paths = [p for p in all_paths if len(p) == d + 2]
    if not candidate_paths:
        return [], None, None, None

    def path_weight(path):
        return sum(G[u][v]['weight'] for u, v in zip(path[:-1], path[1:]))

    candidate_paths.sort(key=path_weight, reverse=True)

    best_path = candidate_paths[0]
    start_point = tuple(agents[start_id].center)
    end_point = tuple(agents[end_id].center)

    overlap_points = []
    for u, v in zip(best_path[:-1], best_path[1:]):
        point = get_overlap_centroid(agents[u], agents[v], domain_size, support_cutoff_eps)
        overlap_points.append(point)

    return best_path, start_point, end_point, overlap_points




#HOLONOMY
def construct_spatial_path_nd(start, end, domain_size, mask=None):
    """
    Constructs a path of discrete coordinates from `start` to `end` in ND space.

    Parameters:
        start (tuple): Starting coordinates (e.g., (x, y, ...) in ND).
        end (tuple): Ending coordinates.
        domain_size (tuple): Spatial domain shape for periodic boundary handling.
        mask (ndarray or None): Optional support mask to constrain the path.

    Returns:
        path (list of tuples): Discrete coordinate path from start to end.
    """
    start = np.array(start)
    end = np.array(end)
    domain_size = np.array(domain_size)
    delta = end - start

    # Apply minimal image convention (periodic wrap)
    delta = (delta + domain_size // 2) % domain_size - domain_size // 2
    steps = int(np.max(np.abs(delta)))
    if steps == 0:
        return [tuple(start)]

    path = []
    for t in np.linspace(0, 1, steps + 1):
        point = start + t * delta
        coord = tuple(np.round(point).astype(int) % domain_size)
        if mask is None or mask[coord] > 0:
            if not path or path[-1] != coord:
                path.append(coord)

    return path

import itertools



#HOLONOMY
def build_agent_graph(agents, support_cutoff_eps=config.support_cutoff_eps):
    """
    Build an undirected adjacency list for agents based on non-empty overlaps.
    Returns: dict mapping agent_id -> set(neighbor_ids)
    """
    N = len(agents)
    graph = {i: set() for i in range(N)}
    for i, j in itertools.combinations(range(N), 2):
        # reuse your existing overlap check
        c = get_overlap_centroid(agents[i], agents[j], config.domain_size, support_cutoff_eps)
        if c is not None:
            graph[i].add(j)
            graph[j].add(i)
    return graph


#HOLONOMY
def find_simple_cycles(graph, max_length=None):
    """
    Find all simple (no repeated nodes except start=end) cycles in an undirected graph.
    - graph: {node: set(neighbors)}
    - max_length: maximum cycle length (including return edge)
    Returns: list of cycles as lists [n0, n1, ..., n0].
    """
    # Build directed graph with bidirectional edges
    G = nx.DiGraph()
    for u, nbrs in graph.items():
        for v in nbrs:
            G.add_edge(u, v)

    cycles = []
    for cyc in nx.simple_cycles(G):
        # cycle comes as [n0, n1, ..., nk], implicitly closed n0→nk
        if len(cyc) < 3:
            continue
        if max_length and (len(cyc) + 1) > max_length:
            continue

        # close the cycle
        closed = cyc + [cyc[0]]
        # rotate so the smallest node is first
        i0 = min(range(len(cyc)), key=lambda i: closed[i])
        norm = tuple(closed[i0:-1] + closed[:i0] + [closed[i0]])
        cycles.append(norm)

    # remove exact duplicates and sort
    unique = sorted(set(cycles), key=lambda c: (len(c), c))
    return unique

#USED FOR HOLONOMY
def get_agent_cycles(agents, max_length=None):
    """
    Build overlap graph and return all simple closed chains up to max_length.
    """
    graph = build_agent_graph(agents)
    return find_simple_cycles(graph, max_length=max_length)
