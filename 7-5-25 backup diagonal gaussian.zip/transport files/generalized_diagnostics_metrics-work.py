# diagnostics_metrics.py

import numpy as np
import config
from scipy.ndimage import laplace
from typing import Dict, List, Any

from joblib import Parallel, delayed
from get_generators import get_generators
from generalized_math_utils import sanitize_q, masked_norm, laplacian_field

from generalized_omega import (
    exp_lie_algebra_irrep,
    batch_apply_omega,
    repair_if_forgotten_batch,
    compute_field_strength,
    build_inter_agent_omega
)

from powerlaw_suite import zipf_slope, rank_frequency_plot,zipf_frequencies_from_q

_DEFAULT_CUTOFF = getattr(config, "support_cutoff_eps", 1e-3)
ZIPF_RMIN       = 3          # ignore the very top-rank symbols
ZIPF_RMAX_FRAC  = 0.5        # upper rank = RMAX_FRAC * K

def support_mask(mask, cutoff=_DEFAULT_CUTOFF):
    return (mask > cutoff)

def overlap_mask(mask_i, mask_j, cutoff=_DEFAULT_CUTOFF):
    return support_mask(mask_i, cutoff) & support_mask(mask_j, cutoff)


def threshold_mask(mask: np.ndarray) -> np.ndarray:
    """
    Turn a float support field into a boolean support region.
    Works for any dimensionality of mask.
    """
    eps = getattr(config, "support_cutoff_eps", 1e-3)
    return mask > eps  # same shape, but boolean

def kl_divergence(p, q, axis=-1, eps=1e-8):
    """KL(p || q), summed along the specified axis"""
    return np.sum(p * (np.log(p + eps) - np.log(q + eps)), axis=axis)


def compute_kl_field(agents, i):
    q = sanitize_q(agents[i].q)
    p = sanitize_q(agents[i].p)
    kl = kl_divergence(q, p)
    return kl * agents[i].mask

def compute_coherence(phi: np.ndarray, mask: np.ndarray) -> float:
    # use the same threshold for boolean selection
    mask_bool = threshold_mask(mask)
    phis = phi[mask_bool]         # shape (n_points,)
    return np.abs(np.mean(np.exp(1j * phis)))


#USED OPNLY IN RUNSIM
def compute_phi_norm_field(agents, i, phi_field="phi"):
    phi = getattr(agents[i], phi_field)
    return np.linalg.norm(phi, axis=-1) * agents[i].mask

def compute_alignment_field(
    agents,
    i,
    eps: float = config.support_cutoff_eps,
    log_eps: float = config.log_eps
) -> np.ndarray:
    """
    Compute per-pixel KL alignment D_KL(q_i || Ω_{ij} q_j) averaged over neighbors,
    with debug outputs for overlap and KL values.
    """
    A = agents[i]
    mask_i = A.mask > eps

    # Early exit if no support or no neighbors
    if not mask_i.any() or not A.neighbors:
        print(f"[DEBUG] Agent {i}: no support or no neighbors → zeros")
        return np.zeros_like(mask_i, float)

    from generalized_diagnostics_metrics import sanitize_q, kl_divergence
    from generalized_omega import batch_apply_omega

    q_i_full     = sanitize_q(A.q, eps=log_eps)
    kl_accum     = np.zeros_like(mask_i, float)
    n_nb_at      = np.zeros_like(mask_i, int)
    total_overlap = 0

    for nb in A.neighbors:
        B = agents[nb["id"]]
        mask_j  = B.mask > eps
        overlap = mask_i & mask_j

        #print(f"[DEBUG] Agent {i}<-->{B.id}: overlap pixels = {overlap.sum()}")
        if not overlap.any():
            continue
        total_overlap += overlap.sum()

        qi_pts = q_i_full[overlap]
        qj_pts = sanitize_q(B.q, eps=log_eps)[overlap]

        # transport
        Oi_patch  = A.Omega[overlap]
        Oj_inv    = B.Omega_inv[overlap]
        Omegas_ij = np.einsum("mab,mbc->mac", Oi_patch, Oj_inv)
        qj_trans  = sanitize_q(batch_apply_omega(qj_pts, Omegas_ij), eps=log_eps)

        kl_vals = kl_divergence(qi_pts, qj_trans)
        #print(f"[DEBUG] first 5 KL vals for {i}↔{B.id}: {kl_vals[:5]}")
        kl_accum[overlap] += kl_vals
        n_nb_at [overlap] += 1

    #print(f"[DEBUG] Agent {i}: total overlapping pixels = {total_overlap}")

    denom = np.where(n_nb_at > 0, n_nb_at, 1)
    out = (kl_accum / denom) * mask_i

    #print(f"[DEBUG] Agent {i} field summary: min={out.min():.3e}, max={out.max():.3e}, mean={out.mean():.3e}")
    return out


def compute_model_alignment_field(
    agents,
    i,
    eps: float = config.support_cutoff_eps,
    log_eps: float = config.log_eps
) -> np.ndarray:
    """
    Just like compute_alignment_field, but uses p & phi_model instead of q & phi.
    """
    A = agents[i]
    q_saved, phi_saved = A.q, A.phi
    A.q, A.phi = A.p, A.phi_model

    try:
        out = compute_alignment_field(agents, i, eps=eps, log_eps=log_eps)
    except Exception as e:
        #print(f"[!] Model-align failed for {i}: {e}")
        out = None
    finally:
        A.q, A.phi = q_saved, phi_saved

    if out is None or not np.any(out):
        #print(f"[DEBUG] compute_model_alignment_field: returning zeros for agent {i}")
        return np.zeros_like(A.mask, float)
    return out




#USED ONLY IN RUN_SIM AND LOG_ALL_METRICS
def compute_phi_norm(
    agents,
    phi_field="phi",
    mask_field="mask",
    support_cutoff_eps=1e-3,
):
    norms = []
    for agent in agents:
        phi  = getattr(agent, phi_field)
        mask = getattr(agent, mask_field) > support_cutoff_eps
        n    = mask.sum()
        if n > 0:
            norms.append(masked_norm(phi, mask) / n)
    return float(np.mean(norms)) if norms else 0.0

#USED ONLY IN RUN SIM
def compute_entropy_field(agents, i, q_field="q", mask_field="mask", support_cutoff_eps=1e-3, log_eps=1e-8):
    q     = sanitize_q(getattr(agents[i], q_field), eps=log_eps)
    mask  = getattr(agents[i], mask_field) > support_cutoff_eps
    ent   = -np.sum(q * np.log(q), axis=-1)
    return ent * mask


#USED IN LOG_ALL_METRICS
def compute_phi_laplacian_norm(
    agents,
    phi_field: str = "phi",
    mask_field: str = "mask",
    support_cutoff_eps: float | None = None,
    log_eps: float = 1e-8,
) -> float:
    """
    Compute the average per-agent RMS norm of the Laplacian of the φ field.
    1) Threshold mask by support_cutoff_eps.
    2) Compute componentwise Laplacian via scipy.ndimage.laplace.
    3) Compute masked_norm over support and normalize by support size.
    4) Return the mean over all agents.
    """
    if support_cutoff_eps is None:
        support_cutoff_eps = _DEFAULT_CUTOFF

    norms = []
    for agent in agents:
        phi = getattr(agent, phi_field)
        mask = getattr(agent, mask_field) > support_cutoff_eps
        if not np.any(mask):
            continue

        # componentwise Laplacian
        lap_phi = np.stack([laplace(phi[..., d]) for d in range(phi.shape[-1])], axis=-1)
        # RMS norm over support
        val = masked_norm(lap_phi, mask) / (np.count_nonzero(mask) + log_eps)
        norms.append(val)

    return float(np.mean(norms)) if norms else 0.0


#NOT USED yet
def compute_cross_model_kl(
    agents,
    support_eps: float = config.support_cutoff_eps,
    log_eps: float     = config.log_eps,
    n_jobs: int        = -1,
) -> float:
    """
    Compute average D_KL(q_i || ~Ω_{ij} p_j) over unique overlapping agent pairs,
    where ~Ω_{ij}(x) = exp(φ_i(x)) @ exp(-φ_model_j(x)), by re-using cached Omegas.
    """

    def _pair_kl(i, j):
        Ai = agents[i]
        Aj = agents[j]

        # 1) overlap mask
        mi = Ai.mask > support_eps
        mj = Aj.mask > support_eps
        ov = mi & mj
        if not ov.any():
            return 0.0, 0.0

        # 2) extract & sanitize distributions
        qi = sanitize_q(Ai.q[ov], eps=log_eps)       # (M, K)
        pj = sanitize_q(Aj.p[ov], eps=log_eps)       # (M, K)

        # 3) grab cached transports
        #    - belief transport at i:     (M, K, K)
        #    - model transport inverse at j: (M, K, K)
        Oi_belief     = Ai.Omega       [ov]
        Oj_model_inv  = Aj.Omega_model_inv[ov]

        # 4) build ~Ω_ij = Oi_belief @ Oj_model_inv
        Omegas_tilde = np.einsum("mab,mbc->mac",
                                 Oi_belief,
                                 Oj_model_inv)

        # 5) transport p_j into q-space
        pj_rot = batch_apply_omega(pj, Omegas_tilde)     # (M, K)
        pj_rot = repair_if_forgotten_batch(pj_rot, eps=log_eps)
        # re-normalize just in case
        pj_rot /= (pj_rot.sum(axis=-1, keepdims=True) + log_eps)

        # 6) pointwise KL
        kl_vals = np.sum(qi * (np.log(qi) - np.log(pj_rot + log_eps)), axis=-1)
        return float(kl_vals.sum()), float(ov.sum())

    # unique i<j neighbor pairs
    pairs = [
        (i, nb["id"])
        for i, A in enumerate(agents)
        for nb in A.neighbors
        if nb["id"] > i
    ]

    # parallel compute
    results = Parallel(n_jobs=n_jobs, backend="threading")(
        delayed(_pair_kl)(i, j) for i, j in pairs
    )

    total_kl    = sum(k for k, w in results)
    total_count = sum(w for k, w in results)
    return float(total_kl / (total_count + log_eps)) if total_count > 0 else 0.0





from scipy.stats import linregress
import numpy as np
from generalized_math_utils import zipf_frequencies_from_q

def compute_zipf(agent, rmin=3, rmax_frac=0.5):
    freqs = zipf_frequencies_from_q(agent.q, agent.mask)
    freqs = np.asarray(freqs, dtype=float).ravel()
    freqs = freqs[freqs > 0]

    if freqs.size < rmin:
        return 0.0, 0.0

    rmax = int(len(freqs) * rmax_frac)
    rmax = min(len(freqs), rmax)

    ranks = np.arange(1, len(freqs) + 1)
    x = np.log(ranks[rmin-1:rmax])
    y = np.log(freqs[rmin-1:rmax])

    if len(x) < 2 or np.std(y) < 1e-8:
        return 0.0, 0.0

    slope, intercept, r, _, _ = linregress(x, y)
    return slope, r**2




def log_all_metrics_fused(
    agents,
    step: int,
    params: dict | None = None,
    q_field: str              = "q",
    p_field: str              = "p",
    phi_belief_field: str     = "phi",
    phi_model_field: str      = "phi_model",
    mask_field: str           = "mask",
    overlap_eps: float | None = None,
    log_eps: float            = 1e-8,
    n_jobs: int               = 1,
    generators=None           # ← this will be your Lie‐algebra gens
) -> dict:
    """
    Single‐pass diagnostics: energy + all per-agent norms in one Parallel loop.
    """
    import numpy as np
    from joblib import Parallel, delayed

    from generalized_math_utils import sanitize_q, laplacian_field
    from generalized_omega      import batch_apply_omega, batch_apply_omega_parallel, compute_field_strength

    # pull in all of our weights, with sensible defaults
    cfg = params or {k: getattr(config, k) for k in dir(config) if not k.startswith("__")}
    if overlap_eps is None:
        overlap_eps = cfg.get("support_cutoff_eps", config.support_cutoff_eps)

    alpha                   = cfg.get("alpha",           config.alpha)
    beta                    = cfg.get("beta",            config.beta)
    gamma                   = cfg.get("gamma",           config.gamma)                   # belief‐Laplacian
    gauge_weight            = cfg.get("gauge_weight",    config.gauge_weight)            # belief‐mass
    model_align_weight      = cfg.get("model_align_weight",  config.model_align_weight)
    model_feedback_weight   = cfg.get("model_feedback_weight", config.model_feedback_weight)
    model_gauge_weight      = cfg.get("model_gauge_weight",   config.model_gauge_weight)
    model_mass_weight       = cfg.get("model_mass_weight",    config.model_mass_weight)
    phi_phi_tilde_coupling  = cfg.get("phi_phi_tilde_coupling", config.phi_phi_tilde_coupling)
    curvature_weight        = cfg.get("curvature_weight",     config.curvature_weight)

    lie_gens = get_generators(config.group_name, config.K)
        
    # precompute lists for parallel loop
    Q_list, P_list, Mask_list = [], [], []
    O_bel, O_inv, O_mod, O_mod_inv = [], [], [], []
    for A in agents:
        mask = getattr(A, mask_field) > overlap_eps
        Mask_list.append(mask)
        Q_list.append(sanitize_q(getattr(A, q_field), eps=log_eps))
        P_list.append(sanitize_q(getattr(A, p_field), eps=log_eps))
        O_bel.append(A.Omega)
        O_inv.append(A.Omega_inv)
        O_mod.append(A.Omega_model)
        O_mod_inv.append(A.Omega_model_inv)

    N = len(agents)

    def _agent_stats(
        i,
        A,
        step,
        q_field,
        p_field,
        phi_belief_field,
        phi_model_field,
        mask_field,
        cfg,
        generators
    ):
        
        # unpack
        A    = agents[i]
        mask = Mask_list[i]
        support = int(Mask_list[i].sum())

        if not mask.any():
            # no support → all zeros
            return i, {
                "e_self":0, "e_align":0, "e_feedback":0, "e_mod_align":0,
                "e_lap_bel":0, "e_mass_bel":0, "e_lap_mod":0, "e_mass_mod":0,
                "e_couple":0, "e_curv":0, "e_curv_mod":0,
                "phi_norm":0, "phi_model_norm":0, "entropy":0,
                "lap_phi_norm":0, "delta_phi_norm":0,
                "curvature_norm":0, "curvature_model_norm":0,
                "fisher_information":0,
                "model_arr": np.zeros(N, dtype=float)
            }

        # core fields
        qi = Q_list[i];  pi = P_list[i]

        # 1) Self‐KL
        e_self = alpha * np.sum( kl_divergence(qi, pi)[mask] )

        # 2) Belief‐alignment KL
        e_align = 0.0
        for nb in A.neighbors:
            j  = nb["id"]
            ov = mask & Mask_list[j]
            if not ov.any(): continue
            q_i_ov = qi[ov]
            q_j_ov = Q_list[j][ov]
            Ω = np.einsum("mab,mbc->mac",
                         O_bel[i][ov], O_inv[j][ov])
            qj_t = sanitize_q(batch_apply_omega_parallel(q_j_ov, Ω,n_jobs=-1), eps=log_eps)
            e_align += beta * np.sum( kl_divergence(q_i_ov, qj_t) )

                # Count neighbors and overlap points for average alignment diagnostics
        neighbor_count = 0
        total_overlap_points = 0

        for nb in A.neighbors:
            j = nb["id"]
            ov = mask & Mask_list[j]
            if not ov.any():
                continue
            neighbor_count += 1
            total_overlap_points += ov.sum()


        # 3) Feedback KL(p||q)
        e_feedback = model_feedback_weight * np.sum(
            kl_divergence(pi, qi)[mask]
        )

        # 4) Model‐alignment KL
        e_mod_align = 0.0
        for nb in A.neighbors:
            j  = nb["id"]
            ov = mask & Mask_list[j]
            if not ov.any(): continue
            p_i_ov = pi[ov]
            p_j_ov = P_list[j][ov]
            Ωm = np.einsum("mab,mbc->mac",
                          O_mod[i][ov], O_mod_inv[j][ov])
            pj_t = sanitize_q(batch_apply_omega_parallel(p_j_ov, Ωm, n_jobs = -1), eps=log_eps)
            e_mod_align += model_align_weight * np.sum(
                kl_divergence(p_i_ov, pj_t)
            )

        # 5) Belief‐Laplacian
        lap_phi = laplacian_field(A.phi)
        e_lap_bel = gamma * np.sum(
            np.linalg.norm(lap_phi[mask], axis=-1)
        )

        # 6) Belief‐mass
        e_mass_bel = gauge_weight * np.sum(
            np.linalg.norm(A.phi[mask], axis=-1)**2
        )

        # 7) Model‐Laplacian
        lap_phi_m = laplacian_field(A.phi_model)
        e_lap_mod = model_gauge_weight * np.sum(
            np.linalg.norm(lap_phi_m[mask], axis=-1)
        )

        # 8) Model‐mass
        e_mass_mod = model_mass_weight * np.sum(
            np.linalg.norm(A.phi_model[mask], axis=-1)**2
        )

        # 9) φ–φ_model coupling
        mask_broadcast = mask[..., None]  # shape (H, W, 1)
        diff = A.phi * mask_broadcast - A.phi_model * mask_broadcast

        e_couple = phi_phi_tilde_coupling * np.sum(
            np.linalg.norm(diff, axis=-1)**2
        )

        # --- Belief curvature energy  (shape-robust) -------------------------
        def _energy_density(Fdict):
            """
            Sum ‖F‖² over all antisymmetric pairs.
            Works whether each F has shape (H,W,d)   or (H,W,K,K).
            Returns array with the same first two spatial dims as φ.
            """
            e = 0.0
            for F in Fdict.values():
                if F.ndim < 3:                     # (H,W) already scalar
                    e += F**2
                elif F.ndim == 3:                  # (H,W,d)
                    e += np.sum(F**2, axis=-1)
                else:                              # (H,W,K,K,[…])
                    e += np.sum(F**2, axis=(-2, -1))
            return e                               # shape (H,W)

        curv_energy_density = _energy_density(compute_field_strength(A.phi, lie_gens))

        e_curv        = curvature_weight * float(np.sum(curv_energy_density[mask]))
        curvature_norm = float(np.sum(curv_energy_density[mask]))

        # 11) Model‐curvature  ── mirror of belief side
        curv_energy_density_m = _energy_density(
            compute_field_strength(A.phi_model, lie_gens)
        )

        e_curv_mod         = curvature_weight * float(np.sum(curv_energy_density_m[mask]))
        curvature_model_norm = float(np.sum(curv_energy_density_m[mask]))

        # diagnostics
        q_s   = sanitize_q(qi, eps=log_eps)[mask]
        phi_s = A.phi[mask]
        phi_m = A.phi_model[mask]
        phi_norm       = np.linalg.norm(phi_s, axis=-1).sum()
        phi_model_norm = np.linalg.norm(phi_m, axis=-1).sum()
        entropy        = float(-np.sum(q_s * np.log(q_s + log_eps)))
        lap_phi_norm   = np.linalg.norm(laplacian_field(A.phi)[mask],axis=-1).sum()
        delta_phi_norm = (
            float(np.linalg.norm(getattr(A, "delta_phi", 0.0),axis=-1)[mask].max())
            if hasattr(A, "delta_phi") else 0.0
        )
        grads = np.gradient(q_s, axis=tuple(range(q_s.ndim-1)))
        fisher_information = float(sum((g**2/(q_s+log_eps)).sum() for g in grads))

        # ------------------------------------------------------------------
        # Zipf slope & R²
        # ------------------------------------------------------------------
        freqs = zipf_frequencies_from_q(qi, mask)          # shape (K,)
        slope, r2 = zipf_slope(
            freqs,
            rmin=ZIPF_RMIN,
            rmax=int(len(freqs) * ZIPF_RMAX_FRAC)
        )

        # package
        stats = {
            "e_self":        e_self,
            "e_align":       e_align,
            "e_feedback":    e_feedback,
            "e_mod_align":   e_mod_align,
            "e_lap_bel":     e_lap_bel,
            "e_mass_bel":    e_mass_bel,
            "e_lap_mod":     e_lap_mod,
            "e_mass_mod":    e_mass_mod,
            "e_couple":      e_couple,
            "phi_norm":      phi_norm,
            "phi_model_norm":phi_model_norm,
            "entropy":       entropy,
            "lap_phi_norm":  lap_phi_norm,
            "curvature_norm":          curvature_norm,
            "curvature_model_norm":    curvature_model_norm,
            "zipf_slope": slope,
            "zipf_r2":    r2,
            "kl_align_total": e_align,
            "kl_align_avg_per_point": (e_align / max(total_overlap_points, 1))/support,
            "model_arr":      np.zeros(N, dtype=float)  # fill later if needed
        }

        return i, stats
    
    # 3) Run per‐agent stats in parallel
    results = Parallel(n_jobs=n_jobs, backend="threading")(
        delayed(_agent_stats)(
            i, agents[i], step,
            q_field, p_field,
            phi_belief_field, phi_model_field,
            mask_field, cfg, lie_gens
        )
        for i in range(N)
    )

    # 4) Initialize accumulators for all eleven energy terms + support
    # Only accumulate the four KL‐energy terms
    keys = ["e_self", "e_align", "e_feedback", "e_mod_align"]
    accum = {k: 0.0 for k in keys}
    total_support = 0
    # also roll up diagnostics
    diag_sums = {
        "phi_norm": 0.0, "phi_model_norm": 0.0, "entropy": 0.0,
        "lap_phi_norm": 0.0, "delta_phi_norm": 0.0,
        "curvature_norm": 0.0, "curvature_model_norm": 0.0,
        "fisher_information": 0.0
    }

    # 5) Accumulate per‐agent
    for i, s in results:
        support = int(Mask_list[i].sum())
        total_support += support
        for k in keys:
            accum[k] += s[k]


        # per‐agent logging
        agents[i].log_metrics(step, {
    "kl_self":         s["e_self"]            / support,
    "kl_align":        s["e_align"]           / support,
    "kl_feedback":     s["e_feedback"]        / support,
    "kl_mod_align":    s["e_mod_align"]       / support,
    "lap_phi":         s["e_lap_bel"]         / support,
    "mass_phi":        s["e_mass_bel"]        / support,
    "lap_phi_mod":     s["e_lap_mod"]         / support,
    "mass_phi_mod":    s["e_mass_mod"]        / support,
    "phi_phi_couple":  s["e_couple"]          / support,
    "curvature_norm":       s["curvature_norm"]       / support,
    "curvature_model_norm": s["curvature_model_norm"] / support,
    "zipf_slope":  s["zipf_slope"],
    "zipf_r2":     s["zipf_r2"],
    "kl_align_avg_per_point":    s["kl_align_avg_per_point"],

    })

    # 6) Build global metrics
    S = max(total_support, 1)
    metrics = {
        "step": step,
        **{k: accum[k] / S for k in keys},
        "total_energy": sum(accum.values()) / S
    }


        # --- pooled Zipf slope across all agents -----------------------------
    pooled_freqs = sum(
        zipf_frequencies_from_q(Q_list[i], Mask_list[i]) for i in range(N)
    )
    pooled_freqs /= pooled_freqs.sum()
    g_slope, g_r2 = zipf_slope(
        pooled_freqs,
        rmin=ZIPF_RMIN,
        rmax=int(len(pooled_freqs) * ZIPF_RMAX_FRAC)
    )
    metrics["global_zipf_slope"] = g_slope
    metrics["global_zipf_r2"]    = g_r2

    return metrics

import os
import numpy as np
from get_generators import get_generators
from generalized_omega import exp_lie_algebra_irrep
from generalized_diagnostics_metrics import (
    compute_alignment_field,        # belief alignment :contentReference[oaicite:0]{index=0}
    compute_model_alignment_field   # model alignment :contentReference[oaicite:1]{index=1}
)
import config



def log_max_overlap_fields(agents, step, outdir,
                           eps=config.support_cutoff_eps):
    """
    Finds the two agents with the largest overlap and logs:
      - belief vs. model alignment fields
      - mu/sigma for belief (q) and model (p)
    into a compressed .npz per step.
    """
    os.makedirs(outdir, exist_ok=True)

    # 1) Identify best pair
    max_overlap = 0
    best_pair = None
    for i, A in enumerate(agents):
        mask_i = A.mask > eps
        if not mask_i.any():
            continue
        for nb in A.neighbors:
            j = nb["id"]
            mask_j = agents[j].mask > eps
            ov = mask_i & mask_j
            cnt = int(ov.sum())
            if cnt > max_overlap:
                max_overlap = cnt
                best_pair = (i, j)

    if best_pair is None:
        print(f"[DEBUG] No overlapping agent pairs at step {step}")
        return

    i, j = best_pair
   
    # 2) Re-exponentiate Ω frames only for agents i and j (if not already cached)
    gens = get_generators(config.group_name, config.K)

    for idx in [i, j]:
        A = agents[idx]
        if A._exp_phi is None:
            print(f"had to recompute")
            A._exp_phi = exp_lie_algebra_irrep(A.phi, gens, group_name=config.group_name)
        if A._exp_neg_phi is None:
            A._exp_neg_phi = exp_lie_algebra_irrep(-A.phi, gens, group_name=config.group_name)
        if A._exp_phi_model is None:
            A._exp_phi_model = exp_lie_algebra_irrep(A.phi_model, gens, group_name=config.group_name)
        if A._exp_neg_phi_model is None:
            A._exp_neg_phi_model = exp_lie_algebra_irrep(-A.phi_model, gens, group_name=config.group_name)


    # 3) Compute alignment fields
    belief_field = compute_alignment_field(agents, i)
    model_field  = compute_model_alignment_field(agents, i)

    # 3b) Extract µ/σ fields for the chosen agent i
    mu_q     = agents[i].mu_q_field
    sigma_q  = agents[i].sigma_q_field
    mu_p     = agents[i].mu_p_field
    sigma_p  = agents[i].sigma_p_field

    q_i = sanitize_q(agents[i].q)
    p_i = sanitize_q(agents[i].p)

    # KL(q‖p)
    kl_self_field = kl_divergence(q_i, p_i, axis=-1)
    # KL(p‖q)
    kl_feedback_field = kl_divergence(p_i, q_i, axis=-1)

    # 4) Save everything in one compressed archive
    fname = os.path.join(outdir, f"step{step:05d}_pair_{i}_{j}.npz")
    # 4a) Agent support mask (so we can blank out outside later)
    mask_i = (agents[i].mask > eps).astype(np.float32)

    # 4b) Save everything in one compressed archive
    np.savez_compressed(
        fname,
        agent_i            = i,
        agent_j            = j,
        overlap            = max_overlap,
        mask_i             = mask_i,
        belief_alignment   = belief_field,
        model_alignment    = model_field,
        mu_q               = mu_q,
        sigma_q            = sigma_q,
        mu_p               = mu_p,
        sigma_p            = sigma_p,
        kl_self_field      = kl_self_field,
        kl_feedback_field  = kl_feedback_field,

    )
    #print(f"[SAVE] Logged belief/model alignment and µ/σ to {fname}")
