# Standard library
import numpy as np

# Third-party
import config
from scipy.ndimage  import gaussian_filter

# Local utilities
from find_agent_chains      import construct_spatial_path_nd
from generalized_math_utils import kl_divergence
from generalized_omega      import (
    exp_lie_algebra_irrep,
    build_inter_agent_omega,
    )
from config import spatial_resolution


def compute_inter_agent_omega(
    phi_i: np.ndarray,
    phi_j: np.ndarray,
    coord: tuple[int, ...],
    generators: np.ndarray,
    use_commutator: bool = False,
    phi_key: str = "phi",
) -> np.ndarray:
    """
    Compute Ω_{ij}(coord) = exp(φ_i(coord)/e) · exp(-φ_j(coord)/e)
    or the abelian shortcut if use_commutator=True.

    Args:
        phi_i, phi_j: φ fields
        coord: spatial coordinate (tuple)
        generators: Lie algebra generators (d, K, K)
        use_commutator: whether to use exp(φ_i - φ_j) instead
        phi_key: "phi" or "phi_model" — determines e scaling

    Returns:
        Ω_{ij}(x): shape (K, K)
    """
    from config import e_belief, e_model
    e = e_belief if phi_key == "phi" else e_model

    # 1) Extract the Lie-algebra vectors at coord
    φi_vec = phi_i[coord] / e
    φj_vec = phi_j[coord] / e

    # 2) Delegate to central helper
    Ω = build_inter_agent_omega(
        φi_vec[None],       # shape (1, d)
        φj_vec[None],       # shape (1, d)
        generators,
        config=config,
        use_commutator=use_commutator
    )  # returns shape (1, K, K)

    return Ω[0]



def compute_intra_agent_omega(phi, c0, c1, generators, phi_key="phi", linearize_threshold=1e-5):
    """
    Compute the non-abelian intra-agent transport operator Ω(c0 → c1) using φ.

    Args:
        phi: ndarray, shape (..., d), the φ or φ_model field
        c0, c1: Tuple[int, ...], coordinates in the agent's domain
        generators: Lie algebra generators (d, K, K)
        phi_key: str, either "phi" or "phi_model", to determine which coupling constant to use
        linearize_threshold: float, norm threshold for using abelian linearization

    Returns:
        Ω(c0→c1): ndarray, shape (K, K), transport operator
    """
    from config import e_belief, e_model

    e = e_belief if phi_key == "phi" else e_model
    phi0 = phi[c0] / e
    phi1 = phi[c1] / e

    if np.linalg.norm(phi0 - phi1) < linearize_threshold:
        return exp_lie_algebra_irrep((phi0 - phi1)[None], generators)[0]

    G0     = exp_lie_algebra_irrep(phi0[None],       generators)[0]
    G1_inv = exp_lie_algebra_irrep((-phi1)[None],    generators)[0]
    return G0 @ G1_inv



def transport_belief_over_chain(
    agents,
    path: list[int],
    overlap_points: list[tuple[int,...]],
    generators: np.ndarray,
    domain_size: tuple[int,...],
    fiber_key: str = 'q',      # or 'p'
    phi_key:   str = 'phi',    # or 'phi_model'
    fixed_start: tuple[int,...] | None = None,
    fixed_end:   tuple[int,...] | None = None,
    injection_mode: str = "from_q",
):
    """
    As before, but:
    - Uses getattr(..., phi_key) instead of hard-coded .phi
    - Imports are at module top
    - Uses module config for smoothing sigmas
    """
    D = len(domain_size)
    K = getattr(agents[0], fiber_key).shape[-1]
    A = agents[path[0]]
    B = agents[path[-1]]

    c_0 = fixed_start or tuple(np.array(domain_size) // 2)

    # --- Injection setup ---
    if injection_mode == "from_q":
        f = getattr(A, fiber_key)[c_0].copy()
    elif injection_mode == "from_p":
        f = getattr(A, 'p')[c_0].copy()
    elif injection_mode == "gaussian":
        x = np.arange(K)
        center, sigma = K//2, K/10
        f = np.exp(-0.5*((x-center)/sigma)**2)
    elif injection_mode == "delta":
        f = np.zeros(K); f[K//2] = 1.0
    else:
        raise ValueError(f"Unknown injection_mode: {injection_mode}")

    # normalize helper
    def _norm(v):
        v = np.clip(v, 1e-8, 1.0)
        return v / v.sum()

    f = _norm(f)

    full_path_coords = []
    kl_path_fine     = []
    kl_path_coarse   = []
    q_sequence       = [f.copy()]

    for k in range(len(path)-1):
        id_a, id_b = path[k], path[k+1]
        agent_a, agent_b = agents[id_a], agents[id_b]

        c_a  = c_0 if k==0 else overlap_points[k-1]
        c_ab = overlap_points[k]

        # --- Intra-agent transport ---
        seg = construct_spatial_path_nd(c_a, c_ab, domain_size, mask=agent_a.mask)
        for p0, p1 in zip(seg[:-1], seg[1:]):
            phi_a = getattr(agent_a, phi_key)
            omega = compute_intra_agent_omega(phi_a, p0, p1, generators, use_commutator=False, phi_key=phi_key)
            f     = _norm(omega @ f)
            target = getattr(agent_a, fiber_key)[p1]
            kl_path_fine.append(kl_divergence(f, target))
            q_sequence.append(f.copy())

        # record segment coords
        full_path_coords.extend(seg)

        # --- Inter-agent jump ---
        phi_a, phi_b = getattr(agent_a, phi_key), getattr(agent_b, phi_key)
        omega_ab = compute_inter_agent_omega(phi_a, phi_b, c_ab, generators, use_commutator=False, phi_key=phi_key)
        f        = _norm(omega_ab @ f)
        target   = getattr(agent_b, fiber_key)[c_ab]
        kl_path_coarse.append(kl_divergence(f, target))
        q_sequence.append(f.copy())

        # record the jump coord
        full_path_coords.append(c_ab)
        c_0 = c_ab

    # --- Gauge-covariant injection ---
    c_final = fixed_end or c_0
    delta   = np.zeros(domain_size); delta[c_final]=1.0
    smoothed= gaussian_filter(delta, sigma=config.injection_smooth_sigma)
    mask    = smoothed > 1e-5

    phi_B = getattr(B, phi_key)
    for idx in zip(*np.where(mask)):
        omega = compute_intra_agent_omega(phi_B, c_final, idx, generators, use_commutator=False, phi_key=phi_key)
        transported = _norm(omega @ f)
        getattr(B, fiber_key)[idx] += transported * smoothed[idx]

    # update B.mask
    B_mask = gaussian_filter(delta, sigma=config.mask_update_sigma)
    B.mask  = np.maximum(B.mask, B_mask)

    # final normalize
    field = getattr(B, fiber_key)
    field = np.clip(field, 1e-8, 1.0)
    field = field / (np.sum(field, axis=-1, keepdims=True) + 1e-8)
    setattr(B, fiber_key, field)

    return agents, {
        "kl_path_coarse": kl_path_coarse,
        "kl_path_fine":   kl_path_fine,
        "final_point":    c_final,
        "path_indices":   path,
        "path_coords":    full_path_coords,
        "q_sequence":     q_sequence,
        "q_initial":      q_sequence[0],
        "q_final":        q_sequence[-1],
    }



