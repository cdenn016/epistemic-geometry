import numpy as np
import sys

# ===========================
# DEBUGGING AND UTILITIES
# ===========================

# 1) define at top of your script/module
def scaled_eta(base, *weights, min_den=1.0):
    """
    If all weights sum to zero, return base.
    Otherwise return base / max(sum(weights), min_den).
    """
    total = sum(weights)
    if total <= 0:
        return base
    return base / max(total, min_den)

def set_config_from_params(params):
    """Dynamically override config attributes from a dictionary."""
    this_module = sys.modules[__name__]
    for k, v in params.items():
        setattr(this_module, k, v)

# ===========================
# GROUP & REPRESENTATION SETTINGS
# ===========================
num_cores = -1  # or however many threads you want to use

group_name = 'sl2r'               # Options: "u1", "so3", "sl2r", 'su2'.
representation_type = 'irrep'     # Options: 'irrep', 'fundamental', 'adjoint'
use_commutator = False            # use "false" to use the general exp.exp multiplication
debug = True  # Global debug flag for extra logging inside φ updates
                      

# ===========================
# DOMAIN / SPATIAL SETTINGS
# ===========================
K = 15           # Fiber dimension of belief/model space (depends on representation)
                 # Fast up to K=15 then slow
D = 2            #dimension of base manifold - d=2 validated

L = 25         #length of hypercubic base-manifold - PBCs

steps = 50

N = 2                          # Number of agents
max_neighbors = 2              # Max number of agent neighbors

psi_radius_range = (4,4)         #agent radii
             
agent_seed    = 56
identical_models = False         # If True, all agents share the same p, mu_p_field, sigma_p_field
similar_p_models = False

# ===========================
# COUPLINGS & PENALTIES
# ===========================

e_belief               = 1
e_model                = 1

alpha                  = 1                    # KL(q || p) self-energy
beta                   = 20                   # KL(q || Ω q) belief coupling
gamma                  = 5                    # Laplacian penalty on φ
gauge_weight           = 1                    # φ² mass term

model_feedback_weight  = 0                    # KL feedback p || q analogous to alpha
model_align_weight     = 10                   # KL(p || Ω̃ p) analogous to beta
model_gauge_weight     = 2                   # Laplacian penalty on φ_model
model_mass_weight      = 2                    # φ_model² mass term

phi_phi_tilde_coupling = 0                    # Coupling φ ↔ φ̃

curvature_weight       = 0
phi_damping            = 0


# ===========================
# AGENT GEOMETRY
# ===========================
q_mu_range       = (2, K-2)
q_sigma_range    = (0.25, 2)
p_mu_range       = (2, K-2)
p_sigma_range    = (0.5, 3)

mask_sharpness           = 1.5
mu_field_smooth_range    = (1, 3)
mu_sigma_scale_range     = (1, 3)
sigma_field_smooth_range = (1, 2)

# ===========================
# INITIALIZATION
# ===========================
phi_init_smooth_sigma = 0.75
phi_init              = 0.1
phi_model_offset      = 0.1

# 2) keep your base‐rate definitions
eta_base_q         = 1e-3    
eta_base_p         = 1e-3    
eta_base_phi       = 1e-2    
eta_base_phi_model = 1e-2    

# ===========================
# STABILITY AND CLIPPING
# ===========================

phi_clip_threshold = 4000       # scale down large φ shifts
phi_max_norm       = 100       # keep φ in a reasonable reference frame
gradient_clip      = 1e4      # if also applied to φ gradients
blowup_threshold   = 4000.0      # skip updates that are clearly unstable
phi_diff_clip      = 3.0            # or experiment with values like 2.0 or 5.0


# ===========================
# DISTRIBUTION SETTINGS
# ===========================
spatial_resolution  = 1
distribution_family = 'gaussian'   # Options: "gaussian", "exponential", "beta". "uniform", etc.

# ===========================
# EPSILONS & PRECISION
# ===========================

log_eps            = 1e-10
support_cutoff_eps = 1e-2           #agent and mask overlap = at 1e-1
overlap_eps        = 1e-5
eps                = 1e-10
epsilon_model      = 1.0
precision = np.float32

#=================================
# TRANSPORT DISTRIBUTION INJECTION
#=================================
injection_mode = "from_q"  # or "gaussian", "from_q", "from_p, "delta", etc

# ===========================
# CHECKPOINTING
# ===========================

checkpoint_dir      = "checkpoints"
save_checkpoints    = True
checkpoint_interval = 1

domain_size = (L,) * D

# 3) replace all the old eta_* calculations with calls to scaled_eta
eta_q = scaled_eta(eta_base_q, alpha, beta)

eta_p = scaled_eta(eta_base_p,
                   alpha,
                   model_align_weight,
                   model_feedback_weight,
                   model_gauge_weight,
                   model_mass_weight)

eta_phi = scaled_eta(eta_base_phi,
                     gauge_weight,
                     gamma,
                     curvature_weight,
                     phi_phi_tilde_coupling)

eta_model_phi = scaled_eta(eta_base_phi_model,
                           model_align_weight,
                           model_gauge_weight,
                           model_mass_weight,
                           phi_phi_tilde_coupling
                           )
ZIPF_RMIN       = 1       # minimum rank (skip top-2 symbols)
ZIPF_RMAX_FRAC  = 1     # take top 50% of symbols for fit
