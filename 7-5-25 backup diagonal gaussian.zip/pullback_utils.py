import numpy as np
from get_generators import get_generators
from generalized_omega import compute_gauge_potential


def algebra_fisher_metric(p_c, generators, eps=1e-12):
    """
    Compute the Fisher metric on the Lie algebra at a single base point.

    p_c: array of shape (K,) -- probability at point c (must sum to 1)
    generators: array of shape (d, K, K) -- Lie algebra generators T_a in rep
    eps: small constant to clip p_c and avoid division by zero

    Returns
    -------
    I: array of shape (d, d) -- Fisher metric on the algebra at c
    """
    p_safe = np.clip(p_c, eps, None)
    d = generators.shape[0]
    # v_a[k] = (T_a p)[k]
    V = np.tensordot(generators, p_safe, axes=([1], [0]))  # shape (d, K)
    I = np.einsum('ak,bk->ab', V, V / p_safe)
    return I


def block_decompose(I, vis_inds, dark_inds):
    """
    Decompose a full algebra metric I into visible, mixing, and dark blocks.

    I: array (d, d)
    vis_inds: list of indices for the visible subalgebra
    dark_inds: list of indices for the dark subalgebra

    Returns
    -------
    M_vis: I[np.ix_(vis_inds, vis_inds)]
    Delta: I[np.ix_(vis_inds, dark_inds)]
    M_dark: I[np.ix_(dark_inds, dark_inds)]
    """
    mix_inds = [i for i in range(I.shape[0]) if i not in vis_inds + dark_inds]
    M_vis = I[np.ix_(vis_inds, vis_inds)]
    Delta = I[np.ix_(vis_inds, dark_inds)]
    M_dark = I[np.ix_(dark_inds, dark_inds)]
    return M_vis, Delta, M_dark


def pullback_metric_at_point(I_ab, A_vecs):
    """
    Given algebra metric I_ab and gauge potential vectors A_vecs, compute
    the pulled-back spatial metric G_{mu nu} = A_mu^T I A_nu.

    I_ab: array (d, d)
    A_vecs: list or array of length D, each element shape (d,)

    Returns
    -------
    G: array shape (D, D) -- spatial metric at this point
    """
    D = len(A_vecs)
    return np.array([[A_vecs[mu] @ (I_ab @ A_vecs[nu]) for nu in range(D)]
                     for mu in range(D)])


def compute_pullback_grid(p_grid, phi_grid, K, vis_inds, dark_inds, eps=1e-12):
    generators = get_generators('sl2r', K)  # (d, K, K)
    A_fields = compute_gauge_potential(phi_grid)  # tuple length D, each (N1, N2, d)

    N1, N2, d = phi_grid.shape
    D = len(A_fields)

    # Precompute I_grid using vectorization
    p_safe = np.clip(p_grid, eps, None)  # (N1, N2, K)
    V_batch = np.einsum('abc,ijc->ijab', generators, p_safe)  # (N1, N2, d, K)
    I_grid = np.einsum('ijak,ijbk,ijk->ijab', V_batch, V_batch, 1 / p_safe)

    # Block decompositions (corrected slicing using np.ix_)
    vis_ix  = np.ix_(vis_inds, vis_inds)
    dark_ix = np.ix_(dark_inds, dark_inds)
    mix_ix  = np.ix_(vis_inds, dark_inds)

    M_vis_grid  = I_grid[:, :, vis_ix[0], vis_ix[1]]
    Delta_grid  = I_grid[:, :, mix_ix[0], mix_ix[1]]
    M_dark_grid = I_grid[:, :, dark_ix[0], dark_ix[1]]

    # Compute spatial metric G using vectorization
    A_stack = np.stack(A_fields, axis=-2)  # shape (N1, N2, D, d)
    G_grid = np.einsum('...ua,...ab,...vb->...uv', A_stack, I_grid, A_stack)

    return {
        'I':      I_grid,
        'M_vis':  M_vis_grid,
        'Delta':  Delta_grid,
        'M_dark': M_dark_grid,
        'G':      G_grid,
    }


