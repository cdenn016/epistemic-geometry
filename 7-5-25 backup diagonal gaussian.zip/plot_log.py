import os
import pickle
import pandas as pd
import matplotlib.pyplot as plt


# Optional: Pretty labels
PRETTY = {
    'kl_self':             ("Self KL",           r"$D_{KL}(q\|p)$"),
    'kl_align':            ("Belief Align",      r"$D_{KL}(q_i\|\Omega q_j)$"),
    'kl_model_align':      ("Model Align",       r"$D_{KL}(p_i\|\widetilde\Omega p_j)$"),
    'phi_norm':            ("‖φ‖",               r"avg‖φ‖"),
    'phi_model_norm':      ("‖φ̃‖",              r"avg‖φ̃‖"),
    'entropy':             ("Entropy",           "avg H(q)"),
    'total_energy':        ("Total Energy",      "E_total"),
    'lap_phi_norm':        ("Laplacian φ",       r"‖Δφ‖"),
    'delta_phi_norm':      ("Δφ norm",           r"‖Δφ‖"),
    'curvature_norm':      ("Curvature",         "avg‖F‖"),
    'fisher_information':  ("Fisher Info",       "I_fisher"),
    'cross_model_kl':      ("Cross‐KL",          r"$D_{KL}(q_i\|\widetilde\Omega p_j)$"),
    'free_energy':         ("Free Energy",       r"$\overline{D_{KL}}(q\|p)$"),
    'coherence':           ("Coherence φ",       "Kuramoto R"),
    'model_coherence':     ("Coherence φ̃",      "Kuramoto R_model"),
    'kl_self_avg_per_point':        ("KL(q‖p) / pt",         r"$\frac{D_{KL}(q\|p)}{|\mathcal{S}|}$"),
    'kl_feedback_avg_per_point':    ("KL(p‖q) / pt",         r"$\frac{D_{KL}(p\|q)}{|\mathcal{S}|}$"),
    'kl_model_align_avg_per_point': ("Model Align / pt",     r"$\frac{D_{KL}(p_i\|\widetilde\Omega p_j)}{|\mathcal{S}|}$"),
}

# Where to save
BASE_OUTDIR = "Plots"
WINDOW = 1  # smoothing window

def find_all_metric_logs():
    """
    Return all metric_log.pkl paths in: checkpoints/, lhs_results/, optuna_tmp/
    """
    paths = []
    if os.path.exists("checkpoints/metric_log.pkl"):
        paths.append(("checkpoints", "checkpoints"))

    for root in ["lhs_results", "optuna_tmp"]:
        if os.path.isdir(root):
            for name in sorted(os.listdir(root)):
                path = os.path.join(root, name, "metric_log.pkl")
                if os.path.exists(path):
                    paths.append((f"{root}/{name}", name))
    return paths

def parse_readme_config(path):
    config = {}
    with open(path, 'r') as f:
        for line in f:
            if "=" in line and not line.startswith("="):
                k, v = line.strip().split("=", 1)
                k = k.strip()
                v = v.strip()
                # Try to cast to appropriate types
                if v.lower() in {"true", "false"}:
                    v = v.lower() == "true"
                else:
                    try:
                        v = int(v)
                    except ValueError:
                        try:
                            v = float(v)
                        except ValueError:
                            pass
                config[k] = v
    return config

def get_folder_name_from_readme(base_dir):
    readme_path = os.path.join(base_dir, "README.txt")
    cfg = parse_readme_config(readme_path)
    return f"{cfg.get('identical_models', 'X')}_{cfg.get('N','X')}_{cfg.get('K','X')}_{cfg.get('L','X')}_{cfg.get('alpha','X')}_{cfg.get('beta','X')}"


def plot_global_metrics(path, run_name):
    with open(path, "rb") as f:
        metrics = pickle.load(f)
    df = pd.DataFrame(metrics)
    df.set_index("step", inplace=True)

    # No renaming: assume keys are already canonical
    pass


    outdir = os.path.join(BASE_OUTDIR, run_name)
    os.makedirs(outdir, exist_ok=True)

    for col in df.columns:
        title, ylabel = PRETTY.get(col, (col, col))
        plt.figure(figsize=(6, 4))
        plt.plot(df.index, df[col], marker=".", linestyle="-", alpha=0.3, label="raw")
        if pd.api.types.is_float_dtype(df[col]) and df[col].notna().sum() > WINDOW:
            smoothed = df[col].rolling(window=WINDOW, min_periods=1).mean()
            plt.plot(df.index, smoothed, color="black", linewidth=2.0, label=f"mean ({WINDOW})")
        plt.title(title)
        plt.xlabel("Step")
        plt.ylabel(ylabel)
        plt.legend()
        plt.tight_layout()
        out = os.path.join(outdir, f"{col}.png")
        plt.savefig(out, dpi=150)
        plt.close()
        print(f"Saved → {out}")

    return outdir

def plot_per_agent_metrics(run_dir, outdir):
    csv_path = os.path.join(run_dir, "per_agent_metrics.csv")
    if not os.path.exists(csv_path):
        print(f"[!] No per-agent metrics found in {run_dir}")
        return

    df = pd.read_csv(csv_path)
    agent_dir = os.path.join(outdir, "per_agent")
    os.makedirs(agent_dir, exist_ok=True)

    metrics = [c for c in df.columns if c not in ("agent", "step")]
    for metric in metrics:
        plt.figure(figsize=(6, 4))

        # Identify top 3 agents with highest final value
        final_step = df["step"].max()
        sorted_agents = (
            df[df["step"] == final_step]
            .groupby("agent")[metric]
            .mean()
            .sort_values(ascending=False)
        )
        highlight = sorted_agents.head(3).index.tolist()

        for aid in sorted(df["agent"].unique()):
            sub = df[df["agent"] == aid]
            if aid in highlight:
                plt.plot(
                    sub["step"],
                    sub[metric],
                    label=f"agent {aid}",
                    linewidth=2.5,
                )
            else:
                plt.plot(
                    sub["step"],
                    sub[metric],
                    color="gray",
                    alpha=0.3,
                    linewidth=1.0,
                )

        title, ylabel = PRETTY.get(metric, (metric, metric))
        plt.title(f"{title} per Agent")
        plt.xlabel("Step")
        plt.ylabel(ylabel)
        plt.legend(loc="upper right", ncol=1, fontsize="small", frameon=False)
        plt.tight_layout()

        out = os.path.join(agent_dir, f"{metric}_per_agent.png")
        plt.savefig(out, dpi=150)
        plt.close()
        print(f"Saved per-agent → {out}")

def main():
    runs = find_all_metric_logs()
    if not runs:
        print("No metric logs found.")
        return

    for path, name in runs:
        print(f"\n--- Processing {name} ---")

        # If README.txt exists, use its values to name the output folder
        readme_path = os.path.join(path, "README.txt")
        if os.path.exists(readme_path):
            try:
                new_name = get_folder_name_from_readme(path)
                print(f"→ Using folder name from README: {new_name}")
            except Exception as e:
                print(f"[!] Failed to parse README.txt: {e}")
                new_name = name
        else:
            print(f"[!] No README.txt in {path}")
            new_name = name

        outdir = plot_global_metrics(os.path.join(path, "metric_log.pkl"), new_name)
        plot_per_agent_metrics(path, outdir)


if __name__ == "__main__":
    main()
