# -*- coding: utf-8 -*-
"""
Created on Sat Jul  5 14:13:25 2025

@author: chris and christine
"""

import os
import glob
import pickle
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation, PillowWriter
from matplotlib.colors import Normalize
from matplotlib.cm import ScalarMappable


# ─── CONFIGURATION ─────────────────────────────────────────────────────────────
CHECKPOINT_DIR = "checkpoints"
OUTPUT_DIR     = "diagnostics"
AGENT_INDEX   = 0          # which agent to inspect
INTERVAL_MS   = 200        # ms between animation frames
EPS           = 1e-12      # numeric stability
MASK_EPS      = 1e-12      # mask threshold
# Create output directory
os.makedirs(OUTPUT_DIR, exist_ok=True)

# ─── DATA LOADING ──────────────────────────────────────────────────────────────
def load_steps(checkpoint_dir=CHECKPOINT_DIR, agent_index=AGENT_INDEX):
    """
    Load pickle checkpoints and return times list and list of agent objects.
    """
    files = sorted(glob.glob(f"{checkpoint_dir}/step_*.pkl"))
    times = []
    agents = []
    for path in files:
        # parse step number
        t = int(os.path.splitext(path)[0].split("_")[-1])
        data = pickle.load(open(path, "rb"))
        agent_list = data[0] if isinstance(data, tuple) else data
        A = agent_list[agent_index]
        times.append(t)
        agents.append(A)
    return np.array(times), agents

# ─── SEQUENCE COMPUTATION ───────────────────────────────────────────────────────
def compute_sequences(agents):
    """
    From a list of agents, compute time-series arrays:
      q_seq, p_seq: distribution vectors at centroid
      mu_q_seq, mu_p_seq: mean indices
      H_field_seq, KL_field_seq: full H and KL fields (NaN outside mask)
      map_seq, centroid_seq: perceived KL-minimizer and centroid path
      scalar diagnostics: anisotropy_err, shear, mix_strength, M_dark
    """
    # preallocate lists
    q_seq, p_seq = [], []
    mu_q_seq, mu_p_seq = [], []
    H_seq, KL_seq = [], []
    map_seq, cent_seq = [], []
    anisotropy_err, shear, mix_strength, M_dark = [], [], [], []

    for A in agents:
        # spatial & mask
        H, W, K = A.q.shape
        mask = (A.mask > MASK_EPS)

        # centroid of mask support
        ys = np.arange(H)[:,None]
        xs = np.arange(W)[None,:]
        ci = np.sum(ys * mask) / mask.sum()
        cj = np.sum(xs * mask) / mask.sum()
        cent_seq.append((ci, cj))

        # point for sampling distributions
        pi, pj = int(round(ci)), int(round(cj))

        # q, p distributions & means
        qv = A.q[pi, pj, :]
        pv = A.p[pi, pj, :]
        q_seq.append(qv); p_seq.append(pv)
        mu_q_seq.append(A.mu_q_field[pi, pj])
        mu_p_seq.append(A.mu_p_field[pi, pj])

        # entropy field
        H_field = -np.sum(A.q * np.log(A.q + EPS), axis=2)
        H_seq.append(H_field)
        # KL divergence field
        KL_field = np.sum(A.q * (np.log(A.q + EPS) - np.log(A.p + EPS)), axis=2)
        # mask-out support
        H_field[~mask]  = np.nan
        KL_field[~mask] = np.nan
        H_seq[-1]       = H_field
        KL_seq.append(KL_field)

        # perceived location = KL-minimizer within mask
        KL_tmp = KL_field.copy()
        KL_tmp[~mask] = np.inf
        i_map, j_map = np.unravel_index(np.argmin(KL_tmp), KL_tmp.shape)
        map_seq.append((i_map, j_map))

        # scalar pullback metrics at perceived location
        # 1) spatial metric G (2x2) => anisotropy error, shear
        G = A.spatial_G  # shape (H,W,2,2)
        # anisotropy: Frobenius deviation from (trace/2)*I
        trG = G[:,:,0,0] + G[:,:,1,1]
        dev = np.sqrt((G[:,:,0,0]-trG/2)**2 + 2*G[:,:,0,1]**2 + (G[:,:,1,1]-trG/2)**2)
        anisotropy_err.append(dev.mean())
        shear.append(np.mean(np.abs(G[:,:,0,1])))
        # 2) mixing strength Delta
        Δ = A.pull_Delta.reshape(H, W, 2)
        mix_strength.append(np.mean(np.linalg.norm(Δ, axis=2)))
        # 3) dark-block M_dark
        Md = getattr(A, 'pull_M_dark', np.zeros((H,W,1,1)))
        M_dark.append(np.mean(Md[:,:,0,0]))

    # convert to arrays
    return (
        np.array(q_seq), np.array(p_seq),
        np.array(mu_q_seq), np.array(mu_p_seq),
        np.array(H_seq), np.array(KL_seq),
        np.array(map_seq), np.array(cent_seq),
        np.array(anisotropy_err), np.array(shear),
        np.array(mix_strength), np.array(M_dark)
    )

# ─── ANIMATION UTILITIES ───────────────────────────────────────────────────────
def animate_distributions(times, q_seq, p_seq, mu_q_seq, mu_p_seq):
    K = q_seq.shape[-1]
    fig, ax = plt.subplots()
    lq, = ax.plot([], [], '-o', label='q')
    lp, = ax.plot([], [], '-s', label='p')
    vq = ax.axvline(0, linestyle='--', color='C0')
    vp = ax.axvline(0, linestyle='--', color='C1')
    ax.set_xlim(0, K-1); ax.set_ylim(0, max(q_seq.max(), p_seq.max())*1.1)
    ax.set_xlabel('Fiber index'); ax.set_ylabel('Density'); ax.legend()

    def upd(t):
        x = np.arange(K)
        lq.set_data(x, q_seq[t]); lp.set_data(x, p_seq[t])
        xq, xp = mu_q_seq[t], mu_p_seq[t]
        vq.set_xdata([xq,xq]); vp.set_xdata([xp,xp])
        ax.set_title(f"Distributions at t={times[t]}")
        return lq, lp, vq, vp

    ani = FuncAnimation(fig, upd, frames=len(times), interval=INTERVAL_MS, blit=True)
    out = os.path.join(OUTPUT_DIR, 'fiber_distributions.gif')
    ani.save(out, writer=PillowWriter(fps=1000//INTERVAL_MS)); plt.close(fig)
    print("Saved", out)


def animate_field(times, field_seq, map_seq, cent_seq, cmap, fname, title):
    fig, ax = plt.subplots()
    vmin = np.nanmin(field_seq); vmax = np.nanpercentile(field_seq, 99)
    im = ax.imshow(field_seq[0], origin='lower', cmap=cmap, vmin=vmin, vmax=vmax)
    pm, = ax.plot([], [], 'ro-', label='Perceived')
    pc, = ax.plot([], [], 'ys-', label='Centroid')
    ax.set_xticks([]); ax.set_yticks([]); ax.legend(loc='upper right')
    fig.colorbar(im, ax=ax)

    def upd(t):
        im.set_data(field_seq[t])
        ym, xm = map_seq[t]; yc, xc = cent_seq[t]
        pm.set_data([xm],[ym]); pc.set_data([xc],[yc])
        ax.set_title(f"{title} (t={times[t]})")
        return im, pm, pc

    ani = FuncAnimation(fig, upd, frames=len(times), interval=INTERVAL_MS, blit=True)
    out = os.path.join(OUTPUT_DIR, fname)
    ani.save(out, writer=PillowWriter(fps=1000//INTERVAL_MS)); plt.close(fig)
    print("Saved", out)

# ─── STATIC PLOTS ─────────────────────────────────────────────────────────────
def plot_scalar_timeseries(times, anisotropy, shear, mix, dark):
    fig, ax = plt.subplots()
    ax.plot(times, anisotropy, '-o', label='Anisotropy error')
    ax.plot(times, shear, '-s', label='Shear |G01|')
    ax.plot(times, mix, '-^', label='Mix strength')
    ax.plot(times, dark, '-d', label='Dark mass')
    ax.set_xlabel('Step'); ax.set_ylabel('Mean value'); ax.legend(); plt.tight_layout()
    fn = os.path.join(OUTPUT_DIR, 'scalar_diagnostics.png')
    plt.savefig(fn); plt.close(fig)
    print("Saved", fn)

def animate_perceived_velocity(times, agents, q_seq):
    """
    Computes and animates perceived velocity field v^mu on the base manifold.
    """
    print("[INFO] Computing perceived velocity field...")
    EPS = 1e-12
    arrows = []

    # compute ∂q/∂x, ∂q/∂y using central differences
    dqdx = np.gradient(q_seq, axis=1)  # ∂q/∂x: shape (T,H,W,K)
    dqdy = np.gradient(q_seq, axis=2)  # ∂q/∂y: shape (T,H,W,K)

    # compute Δq = ∂q/∂t
    delta_q = q_seq[1:] - q_seq[:-1]  # shape (T-1, H, W, K)

    # G_inv from agents
    G_all = np.stack([A.spatial_G for A in agents], axis=0)  # (T, H, W, 2, 2)
    G_inv = np.linalg.pinv(G_all[:-1])  # inverse metric

    # project perceived velocity v^mu
    V = []
    for t in range(len(delta_q)):
        vx = np.sum(delta_q[t] * dqdx[t], axis=-1)
        vy = np.sum(delta_q[t] * dqdy[t], axis=-1)
        v_raw = np.stack([vx, vy], axis=-1)  # (H,W,2)
        v_proj = np.einsum("ijkl,ijl->ijk", G_inv[t], v_raw)  # (H,W,2)
        V.append(v_proj)

    V = np.array(V)  # shape (T-1, H, W, 2)
    mag = np.linalg.norm(V, axis=-1)

    # set up quiver plot
    fig, ax = plt.subplots(figsize=(6,6))
    H, W = mag.shape[1:3]
    Y, X = np.mgrid[0:H, 0:W]

    vmax = np.percentile(mag, 99)
    norm = Normalize(vmin=0, vmax=vmax)
    sm = ScalarMappable(norm=norm, cmap='viridis')
    cb = fig.colorbar(sm, ax=ax, orientation='vertical')
    quiv = ax.quiver(X, Y, V[0,:,:,0], V[0,:,:,1],
                     mag[0], angles='xy', scale_units='xy', scale=1, cmap='viridis')
    ax.set_title("Perceived velocity field")
    ax.set_xticks([]); ax.set_yticks([])

    def update(t):
        U = V[t,:,:,0]
        Vv = V[t,:,:,1]
        C  = mag[t]
        quiv.set_UVC(U, Vv, C)
        ax.set_title(f"Perceived velocity (t={times[t]})")
        return quiv,

    ani = FuncAnimation(fig, update, frames=len(V), interval=INTERVAL_MS)
    fname = os.path.join(OUTPUT_DIR, "perceived_velocity.gif")
    ani.save(fname, writer=PillowWriter(fps=1000//INTERVAL_MS)); plt.close(fig)
    print("Saved", fname)

def extract_full_q_sequence(agents):
    """
    Returns a (T, H, W, K) array of full q fields over time.
    """
    return np.stack([A.q for A in agents], axis=0)


# ─── MAIN ENTRYPOINT ──────────────────────────────────────────────────────────
def main():
    times, agents = load_steps()
    (q_seq, p_seq, mu_q_seq, mu_p_seq,
     H_seq, KL_seq,
     map_seq, cent_seq,
     anisotropy, shear,
     mix_strength, dark_mass) = compute_sequences(agents)

    q_grid_seq = extract_full_q_sequence(agents)

    # Animations
    animate_distributions(times, q_seq, p_seq, mu_q_seq, mu_p_seq)
    animate_field(times, H_seq, map_seq, cent_seq, 'magma', 'entropy_field.gif', 'Belief Entropy')
    animate_field(times, KL_seq, map_seq, cent_seq, 'inferno', 'kl_field.gif', 'KL Divergence')

    animate_perceived_velocity(times, agents, q_grid_seq)



    # Scalars
    plot_scalar_timeseries(times, anisotropy, shear, mix_strength, dark_mass)

if __name__ == '__main__':
    main()
