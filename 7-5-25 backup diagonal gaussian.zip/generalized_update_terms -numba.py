import numpy as np
from numba import njit, prange

from get_generators import get_generators

from generalized_omega import batch_apply_omega, repair_if_forgotten_batch
import config


# Sanitization fallback
def sanitize_q(q, eps):
    q = np.clip(q, eps, 1.0)
    norm = np.sum(q, axis=-1, keepdims=True)
    return q / (norm + eps)


def compute_self_gradient(agent_i, dist_field_q: str, dist_field_p: str, mask_field: str, params: dict) -> np.ndarray:
    """
    Compute ∇_{q_i} [ α · D_KL(q_i || p_i) ].
    """
    α = params.get("alpha", config.alpha)
    log_eps = params.get("log_eps", config.log_eps)
    support_eps = params.get("support_cutoff_eps", config.support_cutoff_eps)

    q = getattr(agent_i, dist_field_q)
    p = getattr(agent_i, dist_field_p)
    mask = getattr(agent_i, mask_field)

    grad = np.zeros_like(q)
    support = mask > support_eps
    if α > 0 and np.any(support):
        q_s = sanitize_q(q[support], eps=log_eps)
        p_s = sanitize_q(p[support], eps=log_eps)
        # ∂/∂q [D_KL(q||p)] = log(q/p) + 1
        grad_support = α * (np.log(q_s / p_s) + 1.0)
        grad[support] = grad_support
    return grad


def compute_alignment_gradient(agent_i, agents: list, dist_field: str, phi_field: str, params: dict) -> np.ndarray:
    """
    Compute ∇_{q_i} Σ_j β·D_KL(q_i || Ω_{ij} q_j), reusing cached exp(phi).
    """
    β         = params.get("beta",         config.beta)
    overlap_eps = params.get("overlap_eps", config.support_cutoff_eps)
    log_eps   = params.get("log_eps",      config.log_eps)

    q_i   = getattr(agent_i, dist_field)
    mask_i = agent_i.mask > overlap_eps
    grad  = np.zeros_like(q_i)
    if β <= 0 or not mask_i.any():
        return grad

    # Flatten once
    flat_qi   = q_i.reshape(-1, q_i.shape[-1])
    flat_grad = grad.reshape(-1, grad.shape[-1])

    # Pull cached exponentials (shape: [S, K, K])
    exp_phi_i     = agent_i._exp_phi

    for nb in agent_i.neighbors:
        j       = nb["id"]
        agent_j = agents[j]

        # overlap indices
        overlap = mask_i & (agent_j.mask > overlap_eps)
        idxs    = np.flatnonzero(overlap)
        if idxs.size == 0:
            continue

        # gather flat patches
        qi_vals = flat_qi[idxs]                                 # (M, K)
        qj_vals = agent_j.q.reshape(-1, q_i.shape[-1])[idxs]    # (M, K)

        # build Ω_ij = exp(phi_i) @ exp(-phi_j)
        Oi      = exp_phi_i[idxs]           # (M, K, K)
        Oj_inv  = agent_j._exp_neg_phi[idxs] # (M, K, K)
        Omegas  = np.einsum("mab,mbc->mac", Oi, Oj_inv)

        # rotate neighbor’s q and sanitize
        qj_rot  = batch_apply_omega(qj_vals, Omegas)
        qj_rot  = sanitize_q(repair_if_forgotten_batch(qj_rot, eps=log_eps), eps=log_eps)

        #delta   = (np.log(qi_s / qj_rot) + 1.0)
        delta   = compute_alignment_gradient_jit(qi_vals, qj_rot, β, log_eps)

        # accumulate weighted gradient
        flat_grad[idxs] += (β / idxs.size) * delta

    return flat_grad.reshape(*grad.shape)

def compute_beliefs_gradient(agent_i, agents: list, params: dict) -> np.ndarray:
    """Combine self and alignment gradients for q."""
    return (
        compute_self_gradient(agent_i, 'q', 'p', 'mask', params)
        + compute_alignment_gradient(agent_i, agents, 'q', 'phi', params)
    )


def compute_models_gradient(agent_i, agents: list, params: dict) -> np.ndarray:
    """Combine self, model-alignment, and model-feedback gradients for p."""

    if getattr(config, "identical_models", False):
        return np.zeros_like(agent_i.p)

    α           = params.get('alpha', config.alpha)
    mf          = params.get('model_feedback_weight', config.model_feedback_weight)
    log_eps     = params.get('log_eps', config.log_eps)
    support_eps = params.get('support_cutoff_eps', config.support_cutoff_eps)

    q = sanitize_q(agent_i.q, eps=log_eps)
    p = agent_i.p
    mask = agent_i.mask > support_eps

    grad = np.zeros_like(p)
    if np.any(mask):
        q_s = q[mask]
        p_s = sanitize_q(p[mask], eps=log_eps)

        if α > 0:
            grad_self = -α * (q_s / p_s)
            grad[mask] = grad_self

        if mf > 0:
            grad_fb = compute_alignment_gradient_jit(p_s, q_s, mf, log_eps)
            grad[mask] += grad_fb

    # Alignment term for p (uses phi_model field)
    align = compute_alignment_gradient(agent_i, agents, 'p', 'phi_model', params)
    grad += align

    return grad

def compute_phi_alignment_gradient(agent_i, agents: list, params: dict) -> np.ndarray:
    """
    ∇_{φ} [ β·D_KL(q_i||Ω_{ij} q_j) + γ·Δφ + gauge_weight·φ² + φφ̃ coupling ]
    """
    β           = params.get("beta", config.beta)
    overlap_eps = params.get("overlap_eps", config.support_cutoff_eps)
    log_eps     = params.get("log_eps", config.log_eps)

    phi_i  = agent_i.phi
    phi_m  = agent_i.phi_model
    mask_i = agent_i.mask > overlap_eps

    grad = np.zeros_like(phi_i)
    if β <= 0 or not np.any(mask_i):
        return grad

    flat_q     = agent_i.q.reshape(-1, agent_i.q.shape[-1])
    flat_grad  = grad.reshape(-1, grad.shape[-1])
    exp_phi_i  = agent_i._exp_phi
    exp_neg_phi_i = agent_i._exp_neg_phi
    Gs         = get_generators(config.group_name, flat_q.shape[-1])

    for nb in agent_i.neighbors:
        agent_j = agents[nb["id"]]
        mask_j  = agent_j.mask > overlap_eps
        ov      = mask_i & mask_j
        idxs    = np.flatnonzero(ov)
        if idxs.size == 0:
            continue

        qi_vals  = flat_q[idxs]
        qj_vals  = sanitize_q(agent_j.q_flat[idxs], eps=log_eps)

        Oi      = exp_phi_i[idxs]
        Oj_inv  = exp_neg_phi_i[idxs]
        Ω       = np.einsum("mab,mbc->mac", Oi, Oj_inv)
        qj_rot  = batch_apply_omega(qj_vals, Ω)
        qj_rot  = sanitize_q(repair_if_forgotten_batch(qj_rot, eps=log_eps), eps=log_eps)

        # Inner product gradient (un-normalized mean over pixels)
        grad_pixels = phi_alignment_inner_grad(qi_vals, qj_vals, qj_rot, Oi, Oj_inv, Gs)

        # Apply β here, no extra 1/M factor needed (mean already divides by M)
        flat_grad[idxs] += β * grad_pixels.mean(axis=0)

    grad = flat_grad.reshape(*phi_i.shape)

    # Laplacian term
    γ = params.get("gamma", config.gamma)
    if γ > 0:
        from generalized_math_utils import laplacian_field
        grad += γ * laplacian_field(phi_i)

    # Mass term
    gw = params.get("gauge_weight", config.gauge_weight)
    if gw > 0:
        grad += 2 * gw * phi_i

    # φ–φ̃ coupling
    κ = params.get("phi_phi_tilde_coupling", config.phi_phi_tilde_coupling)
    if κ > 0:
        grad += 2 * κ * (phi_i - phi_m)

    return grad

def compute_phi_model_update(agent_i, agents: list, params: dict) -> np.ndarray:
    """
    ∇_{φ_model} [ βm·D_KL(p_i||Ω̃_{ij} p_j)
                + γm·Δφ_model
                + model_mass_weight·‖φ_model‖²
                + φφ̃ coupling: (φ − φ_model)² ]
    """
    if getattr(config, "identical_models", False):
        return np.zeros_like(agent_i.phi_model)

    βm          = params.get("model_align_weight",    config.model_align_weight)
    overlap_eps = params.get("overlap_eps",           config.support_cutoff_eps)
    log_eps     = params.get("log_eps",               config.log_eps)

    φm_i   = agent_i.phi_model
    φ_i    = agent_i.phi
    mask_i = agent_i.mask > overlap_eps

    grad = np.zeros_like(φm_i)
    if βm <= 0 or not np.any(mask_i):
        return grad

    flat_p     = agent_i.p_flat
    flat_grad  = grad.reshape(-1, grad.shape[-1])
    Oi_full    = agent_i._exp_phi_model
    Oi_inv     = agent_i._exp_neg_phi_model
    Gs         = get_generators(config.group_name, flat_p.shape[-1])

    for nb in agent_i.neighbors:
        j = nb["id"]
        agent_j = agents[j]
        mask_j = agent_j.mask > overlap_eps
        ov = mask_i & mask_j
        idxs = np.flatnonzero(ov)
        if idxs.size == 0:
            continue

        pi_vals = flat_p[idxs]
        pj_vals = sanitize_q(agent_j.p_flat[idxs], eps=log_eps)

        Oi     = Oi_full[idxs]
        Oj_inv = Oi_inv[idxs]
        Ω      = np.einsum("mab,mbc->mac", Oi, Oj_inv)

        pj_rot = batch_apply_omega(pj_vals, Ω)
        pj_rot = sanitize_q(repair_if_forgotten_batch(pj_rot, eps=log_eps), eps=log_eps)

        grad_pix = phi_model_inner_grad(pi_vals, pj_vals, pj_rot, Oi, Oj_inv, Gs)
        flat_grad[idxs] += -βm * grad_pix.mean(axis=0)  # ⬅️ no extra 1/M normalization

    grad = flat_grad.reshape(*φm_i.shape)

    # Laplacian term
    γm = params.get("model_gauge_weight", config.model_gauge_weight)
    if γm > 0:
        from generalized_math_utils import laplacian_field
        grad += γm * laplacian_field(φm_i)

    # Mass term
    mmw = params.get("model_mass_weight", config.model_mass_weight)
    if mmw > 0:
        grad += 2 * mmw * φm_i

    # φ–φ̃ coupling
    κ = params.get("phi_phi_tilde_coupling", config.phi_phi_tilde_coupling)
    if κ > 0:
        grad += 2 * κ * (φ_i - φm_i)

    return grad



@njit
def sanitize_q_jit(q, eps):
    """
    Ensure q is positive and normalized. Works on (M, K).
    """
    q = q.astype(config.precision)
    q = np.maximum(q, eps)
    sums = q.sum(axis=1).reshape(-1, 1)
    return q / (sums + eps)


@njit(parallel=True)
def compute_alignment_gradient_jit(qi_vals, qj_rot, beta, log_eps):
    """
    JIT-accelerated gradient: ∇_q D_KL(q || r) = log(q/r) + 1
    """
    qi_vals = qi_vals.astype(config.precision)
    qj_rot  = qj_rot.astype(config.precision)

    M, K = qi_vals.shape
    grad = np.zeros((M, K), dtype=config.precision)

    for i in prange(M):
        q1 = sanitize_q_jit(qi_vals[i:i+1], log_eps)[0]
        q2 = sanitize_q_jit(qj_rot[i:i+1], log_eps)[0]
        grad[i] = np.log(q1 / (q2 + log_eps)) + 1.0

    if M > 0:
        grad *= beta / M

    return grad


@njit(parallel=True)
def phi_alignment_inner_grad(qi_vals, qj_vals, qj_rot, Oi, Oj_inv, Gs):
    """
    Compute per-pixel φ alignment gradient ∇_φ D_KL(qi || Ω qj).
    """
    qi_vals = qi_vals.astype(config.precision)
    qj_vals = qj_vals.astype(config.precision)
    qj_rot  = qj_rot.astype(config.precision)
    Oi      = Oi.astype(config.precision)
    Oj_inv  = Oj_inv.astype(config.precision)
    Gs      = Gs.astype(config.precision)

    M, K = qi_vals.shape
    d = Gs.shape[0]
    grad = np.zeros((M, d), dtype=config.precision)

    for m in prange(M):
        diff = qi_vals[m] - qj_rot[m]
        H = np.zeros((d, K, K), dtype=config.precision)
        for a in range(d):
            H[a] = Gs[a] @ Oi[m]
        dΩ = np.zeros((d, K, K), dtype=config.precision)
        for a in range(d):
            dΩ[a] = H[a] @ Oj_inv[m]
        dΩp = np.zeros((d, K), dtype=config.precision)
        for a in range(d):
            dΩp[a] = dΩ[a] @ qj_vals[m]
        for a in range(d):
            grad[m, a] = np.dot(dΩp[a], diff)

    return grad


@njit(parallel=True)
def phi_model_inner_grad(pi_vals, pj_vals, pj_rot, Oi, Oj_inv, Gs):
    """
    ∇_{φ̃} KL(pi || Ω̃ pj) per pixel
    """
    pi_vals = pi_vals.astype(config.precision)
    pj_vals = pj_vals.astype(config.precision)
    pj_rot  = pj_rot.astype(config.precision)
    Oi      = Oi.astype(config.precision)
    Oj_inv  = Oj_inv.astype(config.precision)
    Gs      = Gs.astype(config.precision)

    M, K = pi_vals.shape
    d = Gs.shape[0]
    grad = np.zeros((M, d), dtype=config.precision)

    for m in prange(M):
        diff = pi_vals[m] - pj_rot[m]
        H = np.zeros((d, K, K), dtype=config.precision)
        for a in range(d):
            H[a] = Gs[a] @ Oi[m]
        dΩ = np.zeros((d, K, K), dtype=config.precision)
        for a in range(d):
            dΩ[a] = H[a] @ Oj_inv[m]
        dΩp = np.zeros((d, K), dtype=config.precision)
        for a in range(d):
            dΩp[a] = dΩ[a] @ pj_vals[m]
        for a in range(d):
            grad[m, a] = np.dot(dΩp[a], diff)

    return grad
