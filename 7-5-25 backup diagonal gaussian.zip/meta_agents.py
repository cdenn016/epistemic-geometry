import itertools as it
import json
from pathlib import Path

import numpy as np
import matplotlib.pyplot as plt
from matplotlib import cm
import networkx as nx

import config
from generalized_io_utils import load_final_step, load_agents, save_generic_alignment_data
from get_generators import get_generators
from generalized_omega import (
    compute_field_strength,
    compute_pairwise_kl,
    compute_pairwise_model_kl
)


def load_meta_data(alignment_dir: str, prefix: str = "kl"):
    """
    Load KL matrix, cluster labels, and rankings from the alignment output directory.
    Returns (kl_matrix, labels, rankings_dict).
    """
    alignment_path = Path(alignment_dir)
    matrix_file = alignment_path / f"{prefix}_matrix.csv"
    kl_matrix = np.loadtxt(matrix_file, delimiter=',')
    labels_file = alignment_path / f"{prefix}_labels.csv"
    labels = np.loadtxt(labels_file, dtype=int, delimiter=',')
    meta_file = alignment_path / f"{prefix}_meta.json"
    if meta_file.exists():
        with open(meta_file, 'r') as f:
            meta = json.load(f)
        rankings = meta.get('rankings', {})
    else:
        rankings = {}
    return kl_matrix, labels, rankings

# KL statistics per cluster
def compute_cluster_kl_stats(kl_matrix: np.ndarray, labels: np.ndarray):
    """Compute intra-/extra-cluster KL values and means."""
    stats = {}
    for lab in np.unique(labels):
        if lab < 0:
            continue
        idx = np.where(labels == lab)[0]
        # intra
        if len(idx) > 1:
            dsub = kl_matrix[np.ix_(idx, idx)]
            iu = np.triu_indices(len(idx), k=1)
            intra_vals = dsub[iu]
        else:
            intra_vals = np.array([])
        # extra
        others = np.where(labels != lab)[0]
        if others.size:
            extra_vals = kl_matrix[np.ix_(idx, others)].ravel()
            extra_vals = extra_vals[np.isfinite(extra_vals)]
        else:
            extra_vals = np.array([])
        stats[int(lab)] = {
            'intra_vals': intra_vals,
            'extra_vals': extra_vals,
            'intra_mean': float(np.mean(intra_vals)) if intra_vals.size else np.nan,
            'extra_mean': float(np.mean(extra_vals)) if extra_vals.size else np.nan
        }
    return stats

def plot_intra_kl_distribution(cluster_stats, outpath):
    

    Path(outpath).parent.mkdir(parents=True, exist_ok=True)

    labels = []
    data   = []
    for lab in sorted(cluster_stats.keys()):
        vals = cluster_stats[lab]['intra_vals']
        if vals.size > 0:
            labels.append(str(lab))
            data.append(vals)

    if not data:
        print("[!] No intra-cluster KL values to plot.")
        return

    fig, ax = plt.subplots(figsize=(6,4))
    ax.boxplot(data, vert=True, showfliers=False)
    ax.set_xticklabels(labels)
    ax.set_ylabel("Pointwise D_KL")
    ax.set_title("Intra-cluster KL distributions")
    fig.savefig(outpath, dpi=150)
    plt.close(fig)


def plot_curvature_heatmap(agents, labels, generators, outpath=None):
    
    grid = agents[0].phi.shape[:-1]
    cum  = np.zeros(grid, dtype=float)
    for i, ag in enumerate(agents):
        if labels[i] < 0: continue
        F_dict  = compute_field_strength(ag.phi, generators)
        F_stack = np.stack(list(F_dict.values()), axis=-1)
        normF   = np.linalg.norm(F_stack, axis=-1)
        cum     += normF

    plt.figure(figsize=(5,5))
    im = plt.imshow(cum, origin='lower')
    for i, ag in enumerate(agents):
        if labels[i] < 0: continue
        plt.contour(ag.mask > config.support_cutoff_eps,
                    levels=[0.5], colors='white', linewidths=0.5)
    plt.title('Curvature Heatmap (Cluster Regions)')
    # only draw a colorbar if there's any variation
    if cum.max() > cum.min():
        plt.colorbar(im, label='||F||')
    if outpath:
        Path(outpath).parent.mkdir(parents=True, exist_ok=True)
        plt.savefig(outpath, dpi=150)
    plt.close()


def plot_inter_vs_intra(cluster_stats, outpath=None):
    """
    Bar chart comparing mean intra-cluster vs extra-cluster KL for each cluster.
    """
    
    labels = sorted(cluster_stats.keys())
    intra = [cluster_stats[lab]['intra_mean'] for lab in labels]
    extra = [cluster_stats[lab]['extra_mean'] for lab in labels]
    x = np.arange(len(labels))

    fig, ax = plt.subplots(figsize=(6,4))
    ax.bar(x - 0.2, intra, width=0.4, label='intra-mean')
    ax.bar(x + 0.2, extra, width=0.4, label='extra-mean')
    ax.set_xticks(x)
    ax.set_xticklabels([str(l) for l in labels])
    ax.set_ylabel('Mean D_KL')
    ax.set_title('Inter vs Intra KL per Cluster')
    ax.legend()
    if outpath:
        Path(outpath).parent.mkdir(parents=True, exist_ok=True)
        fig.savefig(outpath)
    plt.close(fig)

# Compute phi variance per cluster
def compute_phi_variance_per_cluster(agents, labels):
    stats = {}
    for lab in np.unique(labels):
        if lab < 0:
            continue
        idx = np.where(labels == lab)[0]
        means = []
        for i in idx:
            norm_field = np.linalg.norm(agents[i].phi, axis=-1)
            means.append(float(np.mean(norm_field)))
        stats[int(lab)] = {'phi_means': means, 'phi_var': float(np.var(means))}
    return stats

# Plot phi variance
def plot_phi_variance(phi_stats, outpath=None):
    labels = sorted(phi_stats.keys())
    vars_  = [phi_stats[lab]['phi_var'] for lab in labels]
    plt.figure(figsize=(6,4))
    plt.bar([str(l) for l in labels], vars_)
    plt.xlabel('Cluster')
    plt.ylabel('Var(<||phi||>)')
    plt.title('Intra-cluster Phi Norm Variance')
    if outpath:
        Path(outpath).parent.mkdir(parents=True, exist_ok=True)
        plt.savefig(outpath)
    plt.show()



# Global order parameter
def compute_order_parameter(kl_matrix: np.ndarray):
    i,j = np.triu_indices(kl_matrix.shape[0], k=1)
    d = kl_matrix[i,j]
    d = d[np.isfinite(d)]
    sigma = float(np.median(d)) if d.size else 1.0
    R = float(np.sum(np.exp(-d/sigma)) / d.size) if d.size else 0.0
    return R, sigma

# Plot order parameter
def plot_order_parameter(R, sigma, mode, outpath=None):
    plt.figure(figsize=(6,4))
    plt.bar([0], [R], width=0.5)
    # use scientific notation for sigma
    label = f"R = {R:.3f}\nσ = {sigma:.2e}"
    plt.text(0, R, label, ha='center', va='bottom')
    plt.xticks([])
    plt.ylabel('Global Order R')
    plt.title(f'Global Meta-Agent Order Parameter ({mode})')
    if outpath:
        Path(outpath).parent.mkdir(parents=True, exist_ok=True)
        plt.savefig(outpath, dpi=150)
    plt.show()

# Plot spatial cluster map
def plot_spatial_cluster_map(agents, labels, outpath=None):
    
    cmap = cm.get_cmap('tab10')
    plt.figure(figsize=(5,5))
    for i, ag in enumerate(agents):
        lab = labels[i]
        if lab < 0:
            continue
        # ensure we draw something even if support_cutoff_eps is too big
        mask_bool = ag.mask > getattr(config, "support_cutoff_eps", 0.0)
        if not mask_bool.any():
            mask_bool = ag.mask > 0.0

        plt.contour(mask_bool, levels=[0.5],
                    colors=[cmap(lab % cmap.N)], linewidths=1)
        cx, cy = ag.center
        plt.text(cy, cx, str(i),
                 color=cmap(lab % cmap.N),
                 ha='center', va='center')
    plt.title('Spatial Cluster Map')
    if outpath:
        Path(outpath).parent.mkdir(parents=True, exist_ok=True)
        plt.savefig(outpath)
    plt.show()

def compute_cluster_order_parameters(kl_matrix, labels):
    """
    For each cluster label >=0, compute
      σ_C = median of D_KL(i,j) over i<j in C
      R_C = average of exp(-D_KL(i,j)/σ_C) over i<j in C
    Returns dict: {cluster_label: (R_C, σ_C)}
    """
    
    clusters = {}
    for lab in sorted(set(labels)):
        if lab < 0:
            continue
        idx = np.where(labels == lab)[0]
        if len(idx) < 2:
            # singletons get R=1.0 by definition (or skip)
            clusters[lab] = (1.0, 0.0)
            continue

        # extract upper‐triangle of the submatrix
        sub = kl_matrix[np.ix_(idx, idx)]
        i, j = np.triu_indices(len(idx), k=1)
        vals = sub[i, j]
        vals = vals[np.isfinite(vals)]

        sigma_C = float(np.median(vals)) if vals.size else 1.0
        R_C     = float(np.mean(np.exp(-vals / sigma_C))) if sigma_C > 0 else 1.0
        clusters[lab] = (R_C, sigma_C)
    return clusters


def plot_cluster_order_parameters(cluster_R, outpath=None):
    """
    Bar-plot of R_C per cluster.
    """
    
    labs = sorted(cluster_R.keys())
    R_vals    = [cluster_R[l][0] for l in labs]
    sigma_vals= [cluster_R[l][1] for l in labs]

    fig, ax = plt.subplots(figsize=(6,4))
    bars = ax.bar([str(l) for l in labs], R_vals)
    ax.set_xlabel("Cluster")
    ax.set_ylabel("R_C")
    ax.set_title("Local Order Parameter per Meta-Agent")

    # annotate σ_C above each bar
    for bar, σ in zip(bars, sigma_vals):
        ax.text(
            bar.get_x()+bar.get_width()/2,
            bar.get_height(),
            f"σ={σ:.1e}",
            ha='center', va='bottom', fontsize=8
        )

    if outpath:
        Path(outpath).parent.mkdir(exist_ok=True, parents=True)
        fig.savefig(outpath, dpi=150)
    plt.show()


def compute_symmetric_kl_matrix(kl_matrix):
    return 0.5 * (kl_matrix + kl_matrix.T)



def plot_matrix(kl_matrix, outdir="alignment_output", label="D_KL(q_i || Ω q_j)", title="Pairwise Alignment Matrix"):
    Path(outdir).mkdir(exist_ok=True)
    plt.figure(figsize=(8, 6))
    plt.imshow(kl_matrix, cmap="viridis", interpolation="nearest")
    plt.colorbar(label=label)
    plt.title(title)
    plt.xlabel("Agent j")
    plt.ylabel("Agent i")
    plt.savefig(f"{outdir}/alignment_matrix.png")
    plt.close()

def overlap_area_matrix(agents, eps: float = 1e-6) -> np.ndarray:
    """Return an (N×N) matrix of overlap counts for agent masks."""
    N = len(agents)
    area = np.zeros((N, N), dtype=float)
    for i in range(N):
        mask_i = agents[i].mask > eps
        for j in range(i, N):
            if i == j:
                area[i, j] = mask_i.sum()
            else:
                mask_j = agents[j].mask > eps
                a = np.logical_and(mask_i, mask_j).sum()
                area[i, j] = area[j, i] = a
    return area


def curvature_mean_per_agent(agents, generators) -> np.ndarray:
    """Compute ⟨‖F‖⟩ for each agent using field strength from generalized_omega."""
    means = []
    for ag in agents:
        # compute_field_strength returns dict of component: array
        curvature = compute_field_strength(ag.phi, generators)
        # stack all spatial norms and compute global mean
        all_norms = np.stack(list(curvature.values()), axis=-1)
        means.append(all_norms.mean())
    return np.asarray(means)


def find_meta_agents(
    sym_kl, overlap_area, curv_mean,
    tau_A: float = 10,
    eta:   float = 10,
    tau_C: float = 10
):
    """
    Identify meta-agent clusters satisfying:
      A) mean intra-cluster KL < tau_A
      B) intra < eta * extra-cluster KL
      C) mean curvature < tau_C
    Returns (list of clusters, label array, eps threshold).
    """
    N = sym_kl.shape[0]
    finite = sym_kl[np.isfinite(sym_kl)]
    
    # 1) compute the adaptive threshold
    eps = np.quantile(finite, 0.30)
    
    # 2) enforce a minimum floor so tiny floats don’t disconnect you
    min_eps = getattr(config, "epsilon_model", 1e-6)
    if eps < min_eps:
        eps = min_eps

    # 3) build graph with d <= eps 
    G = nx.Graph()
    G.add_nodes_from(range(N))
    for i, j in it.combinations(range(N), 2):
        d = sym_kl[i, j]
        if np.isfinite(d) and d <= eps:
            G.add_edge(i, j, weight=d)

    # 4) extract connected components, with full‐network special case
    meta = []
    for comp in nx.connected_components(G):
        C = list(comp)
        if len(C) < 2:
            continue

        C_set, out_set = set(C), set(range(N)) - set(C)
        # compute intra‐mean and curvature‐mean
        intra_vals = sym_kl[np.ix_(C, C)]
        intra_vals = intra_vals[np.isfinite(intra_vals)]
        intra_mean = float(intra_vals.mean())
        curv_meanC = float(curv_mean[C].mean())
        # gather finite outside‐cluster KLs
        extra_vals = sym_kl[np.ix_(C, list(out_set))]
        extra_vals = extra_vals[np.isfinite(extra_vals)]
        # CASE A: no outside KLs → accept on intra & curvature only
        if extra_vals.size == 0:
            if intra_mean < tau_A and curv_meanC < tau_C:
                meta.append(C)
        # CASE B: we have outside KLs → require also intra < eta * extra_mean
        else:
            extra_mean = float(extra_vals.mean())
            if (intra_mean < tau_A and
                intra_mean < eta * extra_mean and
                curv_meanC < tau_C):
                meta.append(C)

    # 5) produce a label array
    labels = np.full(N, -1, dtype=int)
    for k, C in enumerate(meta):
        labels[C] = k

    return meta, labels, eps


def plot_generic_alignment_network(
    kl_matrix: np.ndarray,
    cluster_labels: np.ndarray,
    threshold: float,
    outpath: str = "alignment_output/alignment_network.png",
    title: str   = "Epistemic Alignment Network"
):
    """
    Draw a network where edges connect agents with KL < threshold.
    Nodes are colored by cluster_labels.
    """

    N = kl_matrix.shape[0]
    G = nx.Graph()
    G.add_nodes_from(range(N))
    for i in range(N):
        for j in range(i + 1, N):
            d = kl_matrix[i, j]
            if np.isfinite(d) and d < threshold:
                G.add_edge(i, j, weight=np.exp(-d))

    pos = nx.spring_layout(G, seed=42)
    clusters = sorted(set(cluster_labels))
    cmap = plt.cm.get_cmap("tab10")
    color_map = {lab: cmap(i % 10) for i, lab in enumerate(clusters)}
    node_colors = [color_map.get(cluster_labels[i], "grey") for i in range(N)]

    plt.figure(figsize=(8, 6))
    nx.draw_networkx_nodes(G, pos, node_color=node_colors, node_size=300, edgecolors="black")
    nx.draw_networkx_edges(G, pos, alpha=0.5)
    nx.draw_networkx_labels(G, pos, font_size=9)
    plt.title(title)
    plt.axis("off")

    out_dir = Path(outpath).parent
    out_dir.mkdir(parents=True, exist_ok=True)
    plt.savefig(outpath, dpi=150)
    plt.close()

        
def plot_generic_alignment_network(
    kl_matrix,
    cluster_labels,
    threshold,
    outpath="alignment_output/alignment_network.png",
    title="Epistemic Alignment Network"
):
    """
    Visualize agent alignment as a network. Edges drawn where symmetric KL < threshold.
    Nodes colored by cluster.
    """
    import numpy as np
    import matplotlib.pyplot as plt
    import networkx as nx
    from pathlib import Path

    N = kl_matrix.shape[0]
    G = nx.Graph()

    # Add nodes with cluster attribute
    for i in range(N):
        G.add_node(i, cluster=cluster_labels[i])

    # Add edges for pairs within threshold
    for i in range(N):
        for j in range(i + 1, N):
            d = kl_matrix[i, j]
            if np.isfinite(d) and d < threshold:
                G.add_edge(i, j, weight=np.exp(-d))  # similarity weight

    # Layout and coloring
    pos = nx.spring_layout(G, seed=42)
    clusters = sorted(set(cluster_labels))
    color_map = {label: plt.cm.tab10(i % 10) for i, label in enumerate(clusters)}
    node_colors = [color_map[cluster_labels[i]] for i in range(N)]

    # Draw network
    plt.figure(figsize=(8, 6))
    nx.draw_networkx_nodes(
        G, pos,
        node_color=node_colors,
        node_size=500,
        edgecolors="black"
    )
    nx.draw_networkx_edges(G, pos, alpha=0.5)
    nx.draw_networkx_labels(G, pos, font_size=10, font_color="white")

    # Title with eps annotation
    plt.title(f"{title} (ε={threshold:.3f})")
    plt.axis("off")

    # Ensure output directory exists and save
    Path(outpath).parent.mkdir(parents=True, exist_ok=True)
    plt.savefig(outpath)
    plt.close()
    
    
def compute_symmetric_kl_matrix(kl_matrix: np.ndarray) -> np.ndarray:
    """Return the symmetrized KL matrix: 0.5*(K + Kᵀ)."""
    return 0.5 * (kl_matrix + kl_matrix.T)


def rank_agent_alignment(kl_matrix: np.ndarray) -> dict:
    """For each agent, record best, worst neighbor and full ranking."""
    N = kl_matrix.shape[0]
    rankings = {}
    for i in range(N):
        sorted_idx = np.argsort(kl_matrix[i])
        rankings[i] = {
            "best": sorted_idx[1],
            "worst": sorted_idx[-1],
            "full_rank": sorted_idx.tolist()
        }
    return rankings


def run_generic_alignment_analysis(
    agents,
    generators,
    params: dict,
    mode: str = "belief",
    outdir: Path = None
):
    """
    Compute, cluster, plot, and save alignment data for belief or model alignment.

    Parameters
    ----------
    agents : list
        List of agent objects.
    generators : dict
        Lie algebra generators for gauge computation.
    params : dict
        Contains keys like 'log_eps', 'overlap_eps'.
    mode : str
        Either "belief" or "model".
    outdir : Path, optional
        Where to save outputs; defaults to ./alignment_output or ./model_alignment_output.
    """
    if mode == "belief":
        compute_kl   = compute_pairwise_kl
        prefix       = "kl"
        title        = "Epistemic Alignment Network"
        matrix_title = "Pairwise Epistemic Misalignment"
        default_dir  = Path("alignment_output")
    elif mode == "model":
        compute_kl   = compute_pairwise_model_kl
        prefix       = "kl_model"
        title        = "Model Alignment Network"
        matrix_title = "Pairwise Model Misalignment"
        default_dir  = Path("model_alignment_output")
    else:
        raise ValueError(f"Unknown mode '{mode}'")

    outdir = Path(outdir) if outdir else default_dir
    outdir.mkdir(parents=True, exist_ok=True)

    # Step 1: KL computations
    kl_matrix = compute_kl(agents, generators, params)
    sym_kl    = compute_symmetric_kl_matrix(kl_matrix)
    sym_kl    = np.clip(sym_kl, 0.0, None)

    # Step 2: auxiliary metrics
    overlap_A = overlap_area_matrix(agents, params.get("overlap_eps", 0.0))
    curv_mean = curvature_mean_per_agent(agents, generators)

    # Step 3: ranking and clustering
    rankings  = rank_agent_alignment(sym_kl)
    meta_list, labels, eps = find_meta_agents(sym_kl, overlap_A, curv_mean)
    print(f"[INFO] mode={mode}: adaptive eps = {eps:.3f}, meta_agents = {len(meta_list)}")

    # Step 4: visualization
    plot_matrix(sym_kl, outdir, label=f"D_KL({mode})", title=matrix_title)
    plot_generic_alignment_network(
        sym_kl, labels,
        threshold=eps,
        outpath=outdir / "alignment_network.png",
        title=f"{title} (ε={eps:.3f})"
    )

    # Step 5: save data (THIS IS CRITICAL!)
    save_generic_alignment_data(
        kl_matrix=sym_kl,
        rankings=rankings,
        labels=labels,
        outdir=outdir,   # ← key fix
        prefix=prefix
    )

    print(f"[✓] {mode.capitalize()} alignment analysis completed → {outdir}/")



def plot_support_phi_summary(
    agents,
    per_df,
    phi_attr="phi",
    kl_col="kl_align",
    color="red",
    phi_title="Φ Norms",
    kl_title="Alignment per Agent",
    text="No per-agent metrics"
):
    import matplotlib.pyplot as plt
    import numpy as np
    import config                   # <<< make sure config is in scope

    fig, axes = plt.subplots(1, 3, figsize=(18, 6))

    # Panel 1: Agent support contours
    ax0 = axes[0]
    for idx, agent in enumerate(agents):
        mask = agent.mask
        ax0.contour(mask, levels=[config.support_cutoff_eps], colors='black', linewidths=1)
        center = np.array(agent.center)
        ax0.text(center[1], center[0], str(idx),
                 ha='center', va='center',
                 color=color, fontsize=9, weight='bold')
    ax0.set_title("Agent Support Contours")
    ax0.axis('off')

    # Panel 2: Φ or Φ̃ norm heatmap
    ax1 = axes[1]
    combined = np.zeros(config.domain_size, dtype=float)
    for agent in agents:
        phi_field = getattr(agent, phi_attr)
        norm = np.linalg.norm(phi_field, axis=-1)
        combined += norm
    im = ax1.imshow(combined, origin='lower')
    ax1.set_title(f"Sum of {phi_title}")
    ax1.axis('off')
    fig.colorbar(im, ax=ax1, fraction=0.046, pad=0.04)

    # Panel 3: Per-agent KL bar chart
    ax2 = axes[2]
    if per_df is not None and kl_col in per_df.columns:
        last_vals = per_df.groupby('agent')[kl_col].last()
        ax2.bar(last_vals.index, last_vals.values, color=color)
        ax2.set_xlabel("Agent Index")
        ax2.set_ylabel(kl_col)
        ax2.set_title(kl_title)
    else:
        ax2.text(0.5, 0.5, text, ha='center')
        ax2.set_title(kl_title)
        ax2.axis('off')

    plt.tight_layout()
    plt.show()



def plot_pairwise_pointwise_heatmap(
    agents, generators, params,
    i: int, j: int,
    mode: str,
    outdir: str = "alignment_output"
):
    """
    Compute & plot the per-cell D_KL between agent i and j.
    mode ∈ {"belief","model"} decides which KL to use.
    """
    # pick the right function
    if mode == "belief":
        fn = compute_pairwise_kl
        subdir = "belief_pointwise"
    else:
        fn = compute_pairwise_model_kl
        subdir = "model_pointwise"

    kl_mat, pw_dict = fn(agents, generators, params, return_pointwise=True)
    # pick a valid overlapping pair if (i,j) not present
    if (i,j) not in pw_dict:
        alt = next(iter(pw_dict.keys()))
        print(f"[WARN] no overlap for ({i},{j}); using {alt} instead")
        pw = pw_dict[alt]
        i, j = alt
    else:
        pw = pw_dict[(i, j)]

    # build a 2D heatmap
    mask_i = agents[i].mask > params["overlap_eps"]
    mask_j = agents[j].mask > params["overlap_eps"]
    overlap_flat = (mask_i & mask_j).reshape(-1)
    inds = np.flatnonzero(overlap_flat)

    heat = np.zeros_like(mask_i, dtype=float).reshape(-1)
    heat[inds] = pw
    heat = heat.reshape(mask_i.shape)

    # plot
    plt.figure(figsize=(5,5))
    im = plt.imshow(heat, origin='lower')
    plt.colorbar(im, label=f"Pointwise D_KL ({mode})")
    plt.title(f"{mode.capitalize()} Pointwise KL: agents {i}↔{j}")
    Path(outdir).joinpath(subdir).mkdir(parents=True, exist_ok=True)
    plt.savefig(f"{outdir}/{subdir}/pointwise_{mode}_{i}_{j}.png", dpi=150)
    plt.close()


if __name__ == "__main__":
    checkpoint_dir = config.checkpoint_dir
    agents = load_final_step(checkpoint_dir)
    if agents is None:
        raise FileNotFoundError(f"No step_XXXX.pkl in {checkpoint_dir}/")

    generators = get_generators(config.group_name, config.K)
    params = {
        "log_eps":     config.log_eps,
        "overlap_eps": config.overlap_eps
    }

    i0, j0 = 0, 1

    BASEDIR = Path("meta_agent_analysis")
    BASEDIR.mkdir(exist_ok=True)

    # --- Alignment Analysis ---
    for mode in ["belief", "model"]:
        outdir = BASEDIR / f"{mode}_alignment_output"
        outdir.mkdir(exist_ok=True, parents=True)
        run_generic_alignment_analysis(agents, generators, params, mode, outdir=outdir)

    print("[✓] Alignment analyses complete.")

    # --- Meta-Agent Condensation Diagnostics ---
    for prefix, subfolder in [("kl", "belief_alignment_output"), ("kl_model", "model_alignment_output")]:
        align_dir = BASEDIR / subfolder
        print(f"[INFO] Processing '{prefix}' clusters from '{align_dir}'")

        kl_matrix, labels, rankings = load_meta_data(str(align_dir), prefix)
        stats = compute_cluster_kl_stats(kl_matrix, labels)
        R_global, σ_global = compute_order_parameter(kl_matrix)

        if not stats:
            print(f"[!] No {prefix}-mode clusters found; skipping plots.")
            continue

        outdir = BASEDIR / "condensation_output" / prefix
        outdir.mkdir(exist_ok=True, parents=True)

        plot_intra_kl_distribution(stats, outpath=outdir / "intra_kl.png")
        plot_inter_vs_intra(stats, outpath=outdir / "inter_vs_intra.png")

        cluster_R = compute_cluster_order_parameters(kl_matrix, labels)
        plot_cluster_order_parameters(cluster_R, outpath=outdir / "cluster_order_params.png")

        plot_spatial_cluster_map(agents, labels, outpath=outdir / "spatial_clusters.png")
        plot_curvature_heatmap(agents, labels, generators, outpath=outdir / "curvature_heatmap.png")

    print("[✓] Meta-agent condensation diagnostics complete.")
