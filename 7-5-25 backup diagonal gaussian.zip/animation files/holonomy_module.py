

import numpy as np

import random
from config import domain_size, support_cutoff_eps
from scipy.linalg import logm, expm, norm


import time

from find_agent_chains import construct_spatial_path_nd

from functools import lru_cache
from scipy.linalg import expm
from scipy.linalg import logm


@lru_cache(maxsize=None)
def _exp_lie(agent_id, coord):
    """
    Compute exp(φ · G) for a given agent at a spatial coordinate.
    Uses globally cached `agents_global` and `generators_global`.
    """
    agent = next(a for a in agents_global if a.id == agent_id)
    phi_vec = agent.phi[coord]                     # shape: (d,)
    Gs = generators_global                         # shape: (d, K, K)

    L = sum(phi_vec[μ] * Gs[μ] for μ in range(len(phi_vec)))  # Lie algebra element
    return expm(L)

def bch(A: np.ndarray, B: np.ndarray, max_norm: float = 10.0) -> np.ndarray:
    """
    Truncated Baker–Campbell–Hausdorff expansion (3rd order) with safety guards.

      BCH(A, B) ≈ A + B
                  + ½ [A, B]
                  + (1/12)[A, [A, B]] - (1/12)[B, [A, B]]

    Parameters
    ----------
    A, B : np.ndarray
        Lie algebra elements (matrices) to be composed.
    max_norm : float
        Maximum ∞-norm allowed for any intermediate matrix.

    Returns
    -------
    out : np.ndarray
        Approximate Lie algebra element corresponding to log(exp(A) @ exp(B)).
    """
    # 1) Clip input matrices to avoid blow-up
    for M in (A, B):
        norm = np.linalg.norm(M, ord=np.inf)
        if norm > max_norm:
            M *= max_norm / norm

    # 2) First commutator
    comm = A @ B - B @ A
    comm = np.nan_to_num(comm, nan=0.0, posinf=max_norm, neginf=-max_norm)

    # 3) Second-order term
    term2 = 0.5 * comm

    # 4) Third-order terms
    commA = A @ comm - comm @ A
    commB = B @ comm - comm @ B
    commA = np.nan_to_num(commA, nan=0.0, posinf=max_norm, neginf=-max_norm)
    commB = np.nan_to_num(commB, nan=0.0, posinf=max_norm, neginf=-max_norm)
    term3 = (1.0 / 12.0) * commA - (1.0 / 12.0) * commB

    # 5) Combine all
    out = A + B + term2 + term3
    out = np.nan_to_num(out, nan=0.0, posinf=max_norm, neginf=-max_norm)
    return out



def intra_omega(agent, p0, p1):
    Ω0 = _exp_lie(agent.id, p0)
    Ω1 = _exp_lie(agent.id, p1)
    return Ω1 @ np.linalg.inv(Ω0)

def inter_omega(agent_i, agent_j, coord):
    Ωi = _exp_lie(agent_i.id, coord)
    Ωj = _exp_lie(agent_j.id, coord)
    return Ωi @ np.linalg.inv(Ωj)

def compute_spatial_loop_holonomy(
    agent,
    coords,
    generators,
    use_commutator=False,
    return_deviations=False,
    return_beliefs=False,
    return_path=False,
    initial_belief=None,
    use_log_accumulation=False,
):
    """
    Compute holonomy around a closed spatial loop within a single agent.

    If use_log_accumulation=True, accumulate in the Lie algebra and exponentiate at the end.

    Returns:
      H
      deviations (if return_deviations=True)
      beliefs   (if return_beliefs=True)
      path      (if return_path=True)
    """
    print(f"[INFO] Running spatial loop holonomy (log_accum={use_log_accumulation})")
    global agents_global, generators_global
    agents_global = [agent]
    generators_global = generators

    if len(coords) < 2 or coords[0] != coords[-1]:
        raise ValueError("coords must start and end at the same point")

    K = generators.shape[-1]
    
    # initialize either in group (H) or algebra (logH)
    H = np.eye(K, dtype=float)
    logH = np.zeros((K, K), dtype=float) if use_log_accumulation else None
    
    deviations = []
    beliefs = []
    path_out = []

    if return_beliefs:
        if initial_belief is None:
            raise ValueError("initial_belief must be provided when return_beliefs=True")
        b = initial_belief.copy()
        b = np.clip(b, 1e-12, None)
        b /= b.sum()
        beliefs.append(b.copy())
    if return_path:
        path_out.append(coords[0])

    for p0, p1 in zip(coords[:-1], coords[1:]):
        ω = intra_omega(agent, tuple(p0), tuple(p1))

        if use_log_accumulation:
            logω = logm(ω)
            # BCH update instead of simple sum
            logH = bch(logH, logω)
        else:
            H = ω @ H

        if return_deviations:
            deviations.append(np.linalg.norm(ω - np.eye(K)))

        if return_beliefs:
            b = ω @ b
            b = np.clip(b, 1e-12, None)
            b /= b.sum()
            beliefs.append(b.copy())
        if return_path:
            path_out.append(p1)

    if use_log_accumulation:
        H = expm(logH)

    # Ensure H ∈ SL(2,R)
    detH = np.linalg.det(H)
    
    if not np.isclose(detH, 1.0):
        # divide by the K-th root of det(H)
        H /= detH ** (1.0 / float(K))

    # Collect outputs
    outputs = [H]
    if return_deviations:
        outputs.append(deviations)
    if return_beliefs:
        outputs.append(beliefs)
    if return_path:
        outputs.append(path_out)

    _exp_lie.cache_clear()
    return tuple(outputs) if len(outputs) > 1 else H


def compute_agent_cycle_holonomy(
    agents,
    agent_cycle,
    overlap_points,
    generators,
    initial_belief=None,
    return_deviations=False,
    return_logm=False,
    return_beliefs=False,
    return_path=False,
    use_commutator=False,
    use_log_accumulation=False,
):
    """
    Compute non-Abelian holonomy around a closed loop of agents.
    If use_log_accumulation=True, accumulate in Lie algebra then exponentiate.

    Returns:
      H, deviations?, logH?, beliefs?, path?
    """
    global agents_global, generators_global
    agents_global = agents
    generators_global = generators

    if len(agent_cycle) < 2 or agent_cycle[0] != agent_cycle[-1]:
        raise ValueError("agent_cycle must start and end at the same agent")
    if len(overlap_points) != len(agent_cycle) - 1:
        raise ValueError("Mismatch between cycle and overlap points")

    K = generators.shape[-1]
    H = np.eye(K, dtype=float)
    logH = np.zeros((K, K),dtype=float) if use_log_accumulation else None
    deviations = []
    beliefs = []
    full_path = []

    current_agent = agent_cycle[0]
    current_pos   = tuple(agents[current_agent].center)
    if return_beliefs:
        if initial_belief is None:
            raise ValueError("initial_belief must be provided when return_beliefs=True")
        b = initial_belief.copy()
        b = np.clip(b, 1e-12, None)
        b /= b.sum()
        beliefs.append(b.copy())
    if return_path:
        full_path.append(current_pos)

    # Main cycle
    for next_agent, overlap_pt in zip(agent_cycle[1:], overlap_points):
        # spatial steps within current agent
        path = construct_spatial_path_nd(current_pos, overlap_pt, domain_size,
                                         mask=agents[current_agent].mask)
        for p0, p1 in zip(path[:-1], path[1:]):
            ω = intra_omega(agents[current_agent], tuple(p0), tuple(p1))
            
            if use_log_accumulation:
                logω = logm(ω)
                logH = bch(logH, logω)
            else:
                H = ω @ H

            if return_deviations:
                deviations.append(np.linalg.norm(ω - np.eye(K)))
            if return_beliefs:
                b = ω @ b
                b = np.clip(b, 1e-12, None); b /= b.sum()
                beliefs.append(b.copy())
            if return_path:
                full_path.append(p1)

        # gauge hop
        Ω = inter_omega(
            agents[current_agent],
            agents[next_agent],
            tuple(overlap_pt),
        )
        if use_log_accumulation:
            logΩ = logm(Ω)
            logH = bch(logH, logΩ)
        else:
            H = Ω @ H
        

        if return_deviations:
            deviations.append(np.linalg.norm(Ω - np.eye(K)))
        if return_beliefs:
            b = Ω @ b
            b = np.clip(b, 1e-12, None); b /= b.sum()
            beliefs.append(b.copy())
        if return_path:
            full_path.append(overlap_pt)

        current_agent = next_agent
        current_pos   = overlap_pt

    # Final leg back to start
    start_center = tuple(agents[agent_cycle[0]].center)
    path = construct_spatial_path_nd(current_pos, start_center, domain_size,
                                     mask=agents[agent_cycle[0]].mask)
    first_agent = agents[agent_cycle[0]]
    for p0, p1 in zip(path[:-1], path[1:]):
        ω = intra_omega(first_agent, tuple(p0), tuple(p1))

        if use_log_accumulation:
            logω = logm(ω)
            logH = bch(logH, logω)
        else:
            H = ω @ H

        if return_deviations:
            deviations.append(np.linalg.norm(ω - np.eye(K)))
        if return_beliefs:
            b = ω @ b
            b = np.clip(b, 1e-12, None); b /= b.sum()
            beliefs.append(b.copy())
        if return_path:
            full_path.append(p1)

    # Final holonomy
    if use_log_accumulation:
        H = expm(logH)

    # Enforce SL(2,R) constraint
    detH = np.linalg.det(H)
    if not np.isclose(detH, 1.0):
        H /= detH ** (1.0 / float(K))

    logH_out = logm(H) if return_logm else None

    outputs = [H]
    if return_deviations:
        outputs.append(deviations)
    if return_logm:
        outputs.append(logH_out)
    if return_beliefs:
        outputs.append(beliefs)
    if return_path:
        outputs.append(full_path)

    _exp_lie.cache_clear()
    return tuple(outputs) if len(outputs) > 1 else H


def sample_self_avoiding_loop_within_mask(
    center,
    mask,
    *,
    min_length=4,
    max_length=75,
    support_cutoff=support_cutoff_eps,
    seed=None
):
    """
    Generate a random self‐avoiding closed loop on a periodic grid,
    staying entirely where mask >= support_cutoff.
    """
    D = len(domain_size)
    rng = random.Random(seed)

    while True:
        visited = {tuple(center)}
        path = [tuple(center)]
        current = np.array(center, dtype=int)
        prev = None

        for _ in range(max_length):
            neighbors = []
            for axis in range(D):
                for d in (-1, +1):
                    nb = list(current)
                    nb[axis] = (nb[axis] + d) % domain_size[axis]
                    nb = tuple(nb)
                    if np.all(mask[nb] >= support_cutoff):
                        neighbors.append(nb)

            if tuple(center) in neighbors and len(path) >= min_length:
                path.append(tuple(center))
                return path

            candidates = [nb for nb in neighbors if nb != prev and nb not in visited]
            if not candidates:
                break

            nxt = rng.choice(candidates)
            prev = tuple(current.tolist())
            current = np.array(nxt, dtype=int)
            visited.add(nxt)
            path.append(nxt)

        continue
