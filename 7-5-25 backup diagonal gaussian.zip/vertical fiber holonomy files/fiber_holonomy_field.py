# -*- coding: utf-8 -*-
"""
Created on Sat Jul  5 17:03:42 2025

@author: chris and christine
"""

import numpy as np
import pickle
import matplotlib.pyplot as plt
from pathlib import Path

# Import your existing functions
from fiber_holonomy import summarize_holonomy
from config import checkpoint_dir, support_cutoff_eps

def load_checkpoints_with_fields(checkpoint_dir, field_dir):
    """
    Load agent states and their mu/sigma field dumps.
    Returns: list of (agents_list, step, fields_dict).
    """
    ckpt_dir = Path(checkpoint_dir)
    fld_dir = Path(field_dir)
    agent_steps = []
    for ckpt in sorted(ckpt_dir.glob("step_*.pkl")):
        with open(ckpt, "rb") as f:
            agents, step = pickle.load(f)
        if not isinstance(agents, (list, tuple)):
            agents = [agents]
        fields = {}
        fd = fld_dir / ckpt.name
        if fd.exists():
            fields = pickle.load(open(fd, "rb"))
        agent_steps.append((agents, step, fields))
    return agent_steps

def compute_holonomy_field(agent_steps, agent_id=0):
    """
    Compute two H×W fields for the given agent:
      - deviation_field[i,j]: ||v(T)-v(0)|| at (i,j)
      - area_field[i,j]:      enclosed Fisher-area at (i,j)
    """
    agents0, _, _ = agent_steps[0]
    ag0 = agents0[agent_id]
    H, W, _ = ag0.q.shape

    deviation_field = np.full((H, W), np.nan)
    area_field      = np.full((H, W), np.nan)

    for i in range(H):
        for j in range(W):
            if ag0.mask[i, j] < support_cutoff_eps:
                continue

            # build mu/sigma trajectories
            mu_traj = []
            sigma_traj = []
            for agents, step, fields in agent_steps:
                ag = agents[agent_id]
                try:
                    mu_traj.append(fields['mu_q_field'][i, j])
                    sigma_traj.append(fields['sigma_q_field'][i, j])
                except KeyError:
                    mu_traj = sigma_traj = None
                    break
            if mu_traj is None:
                continue

            summary = summarize_holonomy(mu_traj, sigma_traj)
            deviation_field[i, j] = summary['deviation']
            area_field[i, j]      = summary['area']

    return deviation_field, area_field

if __name__ == "__main__":
    # Paths (adjust if needed)
    FIELD_DIR = Path(checkpoint_dir) / "field_dumps"

    agent_steps = load_checkpoints_with_fields(checkpoint_dir, FIELD_DIR)
    dev_field, area_field = compute_holonomy_field(agent_steps, agent_id=0)

    # Plotting
    fig, axes = plt.subplots(1, 2, figsize=(10, 5))
    im0 = axes[0].imshow(dev_field, origin='lower', cmap='viridis')
    axes[0].set_title("Holonomy Deviation")
    plt.colorbar(im0, ax=axes[0], pad=0.01)

    im1 = axes[1].imshow(area_field, origin='lower', cmap='plasma')
    axes[1].set_title("Holonomy Area")
    plt.colorbar(im1, ax=axes[1], pad=0.01)

    plt.suptitle("Agent 0 Holonomy Fields")
    plt.tight_layout()
    plt.show()
