import numpy as np
import matplotlib.pyplot as plt
from pathlib import Path
import pickle
from fiber_holonomy import batch_fiber_holonomy
from generalized_agent_schema import Agent
from config import checkpoint_dir, support_cutoff_eps

# ------------------------
# Config
# ------------------------
OUTDIR = Path("fiber_holonomy_results")
OUTDIR.mkdir(exist_ok=True)

DEFAULT_STEP_INTERVAL     = 5
DEFAULT_EPS               = 1e-3
MAX_LOOPS_PER_POINT       = 25  # ← you can tune this
DEFAULT_AGENT_IDS         = [0, 1]

# ------------------------
# Load checkpoints utility
# ------------------------
def load_checkpoints(step_interval=5):
    checkpoint_files = sorted(Path(checkpoint_dir).glob("step_*.pkl"))
    agent_steps = []

    for ckpt_path in checkpoint_files[::step_interval]:
        rec = pickle.load(open(ckpt_path, "rb"))

        if isinstance(rec, list) and isinstance(rec[0], Agent):
            agents = rec
            step = int(ckpt_path.stem.split("_")[1])
        elif isinstance(rec, tuple):
            agents, step = rec[0], rec[1]
            if not isinstance(agents, (list, tuple)):
                agents = [agents]
        else:
            raise ValueError(f"Unexpected pickle format in {ckpt_path}")

        agent_steps.append((agents, step, {}))

    return agent_steps

# ------------------------
# Main entry point
# ------------------------
def run(agent_ids=None, eps=1e-3, step_interval=5, max_loops_per_point=20):
    agent_steps = load_checkpoints(step_interval=step_interval)

    # Compute fiber holonomy across loaded checkpoints
    results = batch_fiber_holonomy(
        agent_steps,
        agent_ids=agent_ids,
        eps=eps,
        max_loops_per_point=max_loops_per_point,
        save_path=OUTDIR / "fiber_holonomy_summary.csv"
    )

    print(f"[INFO] Holonomy computations completed, results saved to {OUTDIR}/fiber_holonomy_summary.csv")

    # Visualization per agent
    agents0, _, _ = agent_steps[0]
    H, W, _ = agents0[0].q.shape

    if agent_ids is None:
        agent_ids = [agent.id for agent in agents0]

    for aid in agent_ids:
        field = np.full((H, W), np.nan)
        for res in results:
            if res["agent_id"] == aid:
                i, j = res["point"]
                field[i, j] = res["holonomy_dev"]

        plt.figure(figsize=(5, 5))
        im = plt.imshow(field, origin="lower", cmap="viridis")
        plt.colorbar(im, label="Fiber Holonomy Deviation")
        plt.title(f"Agent {aid:02d} Vertical Fiber Holonomy")
        plt.tight_layout()
        plt.savefig(OUTDIR / f"agent{aid:02d}_fiber_holonomy.png")
        plt.close()

# ------------------------
# Entry point
# ------------------------
if __name__ == "__main__":
    run(
        agent_ids=DEFAULT_AGENT_IDS,
        eps=DEFAULT_EPS,
        step_interval=DEFAULT_STEP_INTERVAL,
        max_loops_per_point=MAX_LOOPS_PER_POINT,
    )
