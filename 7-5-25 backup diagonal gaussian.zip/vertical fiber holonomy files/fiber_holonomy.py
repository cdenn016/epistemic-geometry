import numpy as np
from scipy.linalg import sqrtm, inv



def fisher_information_matrix_full(q, eps=1e-12):
    """
    Fisher information metric for a categorical distribution on K-simplex.
    """
    q = np.clip(q, eps, None)
    Q_inv = np.diag(1/q)
    ones = np.ones((len(q), 1))
    G = Q_inv - ones @ ones.T
    return G


def project_to_simplex_tangent(v):
    """
    Project vector v onto the tangent space of the K-simplex (sum to zero).
    """
    return v - np.mean(v)


def parallel_transport_full(v0, loop_points):
    """
    Parallel transport vector v0 around the loop defined by loop_points
    in the K-dimensional simplex, using the Fisher information metric.

    loop_points: list of points [q0, q1, ..., qN], each q ∈ Δᴷ
    """
    v = project_to_simplex_tangent(v0)

    for t in range(len(loop_points)-1):
        q_curr, q_next = loop_points[t], loop_points[t+1]
        G_curr = fisher_information_matrix_full(q_curr)
        G_next = fisher_information_matrix_full(q_next)

        # Symmetric parallel transport step
        S_curr = sqrtm(G_curr)
        S_next_inv = inv(sqrtm(G_next))
        v = S_next_inv @ S_curr @ v

        # Re-project onto tangent space (ensure numerical stability)
        v = project_to_simplex_tangent(v)

    return v


def make_fiber_square_loop(q0, eps, a, b):
    """
    Construct a small square loop within the simplex around q0,
    along coordinate directions a and b by a distance eps.
    """
    K = len(q0)

    def renorm(q):
        q = np.clip(q, 1e-12, None)
        return q / np.sum(q)

    ea, eb = np.zeros(K), np.zeros(K)
    ea[a], eb[b] = 1, 1

    loop = [q0]
    loop.append(renorm(q0 + eps * ea))
    loop.append(renorm(q0 + eps * ea + eps * eb))
    loop.append(renorm(q0 + eps * eb))
    loop.append(q0)

    return loop


def compute_fiber_holonomy(q0, eps, a, b):
    """
    Compute vertical fiber holonomy at fiber point q0
    using a small loop defined within the fiber simplex.

    Returns deviation magnitude indicating fiber curvature.
    """
    loop = make_fiber_square_loop(q0, eps, a, b)

    # Initialize random tangent vector (zero-sum)
    v0 = np.random.randn(len(q0))
    v0 = project_to_simplex_tangent(v0)

    # Parallel transport around loop
    v_final = parallel_transport_full(v0, loop)

    # Holonomy deviation
    deviation = np.linalg.norm(v_final - v0)
    return deviation

import itertools
import random

def batch_fiber_holonomy(agent_steps, agent_ids=None, eps=1e-3, save_path=None, max_loops_per_point=20):
    """
    Run fiber holonomy computations across multiple agents and spatial points.

    agent_steps: list of (agents, step, fields), evaluated at single fixed step
    max_loops_per_point: limit on how many (a,b) loops to sample per point
    """
    results = []

    for agents, step, _ in agent_steps:
        for agent in agents:
            if agent_ids and agent.id not in agent_ids:
                continue

            points = np.argwhere(agent.mask > 1e-6)

            for c in points:
                c = tuple(c)
                q0 = agent.q[c]
                K = len(q0)

                # Build all (a,b) pairs, a < b
                all_pairs = list(itertools.combinations(range(K), 2))
                sampled_pairs = random.sample(all_pairs, min(max_loops_per_point, len(all_pairs)))

                deviations = []
                for a, b in sampled_pairs:
                    dev = compute_fiber_holonomy(q0, eps, a, b)
                    deviations.append(dev)

                avg_dev = np.mean(deviations)

                results.append({
                    "agent_id": agent.id,
                    "point": c,
                    "step": step,
                    "holonomy_dev": avg_dev
                })

    if save_path:
        import pandas as pd
        pd.DataFrame(results).to_csv(save_path, index=False)

    return results
