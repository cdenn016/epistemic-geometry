

import numpy as np
import pickle
import matplotlib.pyplot as plt
from pathlib import Path
from collections import defaultdict

from fiber_holonomy import summarize_holonomy
from config import checkpoint_dir, support_cutoff_eps

def load_checkpoints_with_fields(checkpoint_dir, field_dir):
    """
    Returns list of (agents_list, step, fields_dict) for every checkpoint.
    """
    ckpt_dir = Path(checkpoint_dir)
    fld_dir  = Path(field_dir)
    agent_steps = []
    for ckpt in sorted(ckpt_dir.glob("step_*.pkl")):
        with open(ckpt, "rb") as f:
            rec = pickle.load(f)
        # unify formats
        if isinstance(rec, tuple):
            agents = rec[0]
            step   = rec[1]
            fields = rec[2] if len(rec) >= 3 else {}
        else:
            agents = rec
            step   = int(ckpt.stem.split("_")[1])
            fields = {}
        if not isinstance(agents, (list,tuple)):
            agents = [agents]
        # try loading external field dump
        fd = fld_dir / ckpt.name
        if fd.exists():
            fields = pickle.load(open(fd, "rb"))
        agent_steps.append((agents, step, fields))
    return agent_steps

def compute_time_resolved_holonomy(agent_steps, agent_id=0, window=None, stride=5):
    """
    Compute holonomy deviation maps for sliding windows.

    - window: number of steps per loop. If None, defaults to stride.
    - stride: step size between windows.

    Returns list of (start_step, deviation_field).
    """
    steps = [step for (_,step,_) in agent_steps]
    T = len(steps)

    # default window length = stride
    if window is None or window > T:
        window = stride

    # precompute grid dims
    ag0 = agent_steps[0][0][agent_id]
    H, W, _ = ag0.q.shape

    results = []
    for start in range(0, T - window + 1, stride):
        sub = agent_steps[start:start+window]
        dev_field = np.full((H, W), np.nan)

        for i in range(H):
            for j in range(W):
                if ag0.mask[i,j] < support_cutoff_eps:
                    continue

                mu_traj = []
                sigma_traj = []
                for agents,_,fields in sub:
                    ag = agents[agent_id]
                    if 'mu_q_field' in fields:
                        mu_traj.append(fields['mu_q_field'][i,j])
                        sigma_traj.append(fields['sigma_q_field'][i,j])
                    else:
                        mu_traj.append(ag.mu_q_field[i,j])
                        sigma_traj.append(ag.sigma_q_field[i,j])

                dev_field[i,j] = summarize_holonomy(mu_traj, sigma_traj)['deviation']

        results.append((steps[start], dev_field))

    return results


import numpy as np
import pandas as pd
import imageio
import matplotlib.pyplot as plt
from pathlib import Path

# Adjust these to your project structure:

from config import checkpoint_dir, support_cutoff_eps

def main(agent_id=0, stride=5, window=None, fps=2):
    # directories
    field_dir = Path(checkpoint_dir) / "field_dumps"
    out_dir = Path("time_resolved_holonomy")
    out_dir.mkdir(exist_ok=True)

    # load data
    agent_steps = load_checkpoints_with_fields(checkpoint_dir, field_dir)
    seq = compute_time_resolved_holonomy(agent_steps,
                                         agent_id=agent_id,
                                         window=window,
                                         stride=stride)

    # --- 1) Save CSV ---
    rows = []
    for step, dev in seq:
        H, W = dev.shape
        for i in range(H):
            for j in range(W):
                if not np.isnan(dev[i,j]):
                    rows.append({
                        "step": step,
                        "i":     i,
                        "j":     j,
                        "deviation": dev[i,j]
                    })
    df = pd.DataFrame(rows)
    csv_path = out_dir / "holonomy_summary.csv"
    df.to_csv(csv_path, index=False)
    print(f"Saved CSV → {csv_path}")

    # --- 2) Build GIF ---
    # determine global color scale
    all_devs = np.concatenate([d.flatten() for _, d in seq])
    vmin, vmax = np.nanmin(all_devs), np.nanmax(all_devs)

    frames = []
    for step, dev in seq:
        fig, ax = plt.subplots(figsize=(4,4))
        ax.imshow(dev, origin='lower', cmap='viridis', vmin=vmin, vmax=vmax)
        ax.set_title(f"Agent {agent_id} Holonomy\nsteps {step}-{step + (window or stride)}")
        ax.axis('off')
        fig.canvas.draw()
        img = np.frombuffer(fig.canvas.tostring_rgb(), dtype='uint8')
        img = img.reshape(fig.canvas.get_width_height()[::-1] + (3,))
        frames.append(img)
        plt.close(fig)

    gif_path = out_dir / "holonomy_evolution.gif"
    imageio.mimsave(str(gif_path), frames, fps=fps)
    print(f"Saved GIF → {gif_path}")

if __name__ == "__main__":
    main(agent_id=0, stride=5, window=None, fps=2)
