import os, glob, pickle, math
from typing import Dict, List, Tuple, Optional
import numpy as np
import matplotlib.pyplot as plt
import imageio.v2 as imageio

from pullback_fisher import (
    compute_agent_fisher_pullback,
    summarize_scalar_fields,
    full_geometric_report,
    compute_agent_gauge_curvature,
)

# ==============================
# Static scale helpers
# ==============================

def _gather_scalar_values(files, key):
    vals = []
    for f in files:
        pb = np.load(f)
        if key in pb:
            arr = pb[key]
            finite = np.isfinite(arr)
            if finite.any():
                vals.append(arr[finite])
    if not vals:
        return np.array([])
    return np.concatenate(vals, axis=None)

def _compute_static_scale(files, key, use_percentile=True, lo=1.0, hi=99.0):
    """
    Compute global vmin/vmax across all frames for a given scalar.
    Uses percentiles by default to avoid outlier blow-ups.
    """
    flat = _gather_scalar_values(files, key)
    if flat.size == 0:
        return None, None
    if use_percentile:
        vmin = float(np.percentile(flat, lo))
        vmax = float(np.percentile(flat, hi))
    else:
        vmin = float(np.nanmin(flat))
        vmax = float(np.nanmax(flat))
    # Guard: if vmax==vmin, widen a hair
    if not np.isfinite(vmin) or not np.isfinite(vmax) or abs(vmax - vmin) < 1e-12:
        vmin = float(np.nanmin(flat))
        vmax = float(np.nanmax(flat))
        if abs(vmax - vmin) < 1e-12:
            vmax = vmin + 1e-6
    return vmin, vmax

# ==============================
# I/O helpers
# ==============================

def find_step_files(steps_dir: str) -> List[str]:
    return sorted(glob.glob(os.path.join(steps_dir, "step_*.pkl")))

def load_agents_from_step(step_path: str):
    with open(step_path, "rb") as f:
        obj = pickle.load(f)
    if isinstance(obj, dict) and "agents" in obj:
        return obj["agents"]
    if isinstance(obj, list):
        return obj
    if hasattr(obj, "agents"):
        return obj.agents
    raise RuntimeError(f"Could not locate agents in {step_path}")

def ensure_dir(path: str):
    os.makedirs(path, exist_ok=True)

# ==============================
# Compute pullbacks + GEOMETRY + GAUGE, with summaries
# ==============================

def compute_pullbacks_for_step(step_path: str,
                               outdir: str,
                               modes: List[str],
                               periodic: bool = True,
                               eps: float = 1e-6) -> List[Dict]:
    """
    Compute and save pullbacks + geometric reports (+ gauge if available) per agent.
    Returns a list of summary dicts.
    """
    ensure_dir(outdir)
    step_name = os.path.splitext(os.path.basename(step_path))[0]
    agents = load_agents_from_step(step_path)

    summaries = []
    for idx, agent in enumerate(agents):
        for mode in modes:
            try:
                # --- Fisher pullback ---
                pb = compute_agent_fisher_pullback(agent, mode=mode, periodic=periodic, eps=eps)
                tag = f"{step_name}_agent{idx}_{mode}"
                core_npz = os.path.join(outdir, f"{tag}.npz")
                np.savez_compressed(core_npz, **pb)

                # --- Geometry bundle (Γ, K, v, div, curl, killing_dir, ||L_V G||) ---
                geom = full_geometric_report(pb, periodic=periodic)
                np.savez_compressed(os.path.join(outdir, f"{tag}_geom.npz"), **geom)

                # --- Gauge curvature if agent has phi ---
                if hasattr(agent, "phi"):
                    try:
                        gauge = compute_agent_gauge_curvature(agent, periodic=periodic)
                        np.savez_compressed(os.path.join(outdir, f"{tag}_gauge.npz"), **gauge)
                    except Exception:
                        pass

                # --- Summary row ---
                s = summarize_scalar_fields(pb)
                s.update(dict(step=step_name, agent_index=idx, mode=mode, npz=core_npz))
                summaries.append(s)
            except Exception as e:
                summaries.append(dict(step=step_name, agent_index=idx, mode=mode, error=str(e)))
    return summaries

def compute_pullbacks_all(steps_dir: str,
                          outdir: str,
                          modes: List[str] = ["belief", "model"],
                          periodic: bool = True,
                          eps: float = 1e-6) -> List[Dict]:
    """
    Loop over all step files and compute pullbacks (+ geometry + gauge).
    """
    step_files = find_step_files(steps_dir)
    if not step_files:
        raise FileNotFoundError(f"No step_*.pkl files found in {steps_dir}")
    all_summaries = []
    for sp in step_files:
        all_summaries.extend(
            compute_pullbacks_for_step(sp, outdir, modes, periodic=periodic, eps=eps)
        )
    return all_summaries

# ==============================
# QA checks
# ==============================

def qa_checks(npz_path: str) -> Dict[str, float]:
    """
    Basic sanity checks on a saved pullback NPZ.
    Returns metrics like min eigenvalues etc.
    """
    pb = np.load(npz_path)
    lmin = pb["lmin"]
    lmax = pb["lmax"]
    det  = pb["det"]
    tr   = pb["tr"]

    finite = np.isfinite(lmin)
    out = {}
    if finite.any():
        out["lmin_min"] = float(np.nanmin(lmin))
        out["lmin_max"] = float(np.nanmax(lmin))
        out["lmax_max"] = float(np.nanmax(lmax))
        out["det_min"]  = float(np.nanmin(det))
        out["tr_min"]   = float(np.nanmin(tr))
        out["aniso_max"] = float(np.nanmax(pb["aniso"]))
    else:
        out["lmin_min"] = float("nan")
        out["lmin_max"] = float("nan")
        out["lmax_max"] = float("nan")
        out["det_min"]  = float("nan")
        out["tr_min"]   = float("nan")
        out["aniso_max"] = float("nan")
    return out

# ==============================
# Visualization (core pullback)
# ==============================

def _save_fig(fig, out_path: str):
    fig.savefig(out_path, dpi=120, bbox_inches="tight")
    plt.close(fig)

def plot_scalar(npz_path: str, key: str, out_png: str, vmin: Optional[float]=None, vmax: Optional[float]=None):
    """
    Plot a scalar field from NPZ (tr, det, lmax, lmin, aniso).
    """
    pb = np.load(npz_path)
    if key not in pb:
        raise KeyError(f"{key} not in {npz_path}")
    arr = pb[key]
    fig = plt.figure()
    im = plt.imshow(arr, vmin=vmin, vmax=vmax)
    plt.title(f"{os.path.basename(npz_path)} : {key}")
    plt.colorbar(im)
    _save_fig(fig, out_png)

def plot_orientation(npz_path: str, out_png: str):
    """
    Plot principal direction angle θ from eigenvector of λ_max.
    """
    pb = np.load(npz_path)
    vecs = pb["eigvecs"][..., :, 0]  # eigenvector for largest eigenvalue
    theta = np.arctan2(vecs[..., 1], vecs[..., 0])
    fig = plt.figure()
    im = plt.imshow(theta)
    plt.title(f"{os.path.basename(npz_path)} : principal direction θ")
    plt.colorbar(im)
    _save_fig(fig, out_png)

def plot_quiver(npz_path: str, out_png: str, stride: int = 4):
    """
    Quiver of principal directions (subsampled) on tr(G).
    """
    pb = np.load(npz_path)
    vecs = pb["eigvecs"][..., :, 0]  # (H,W,2)
    H, W, _ = vecs.shape
    Y, X = np.mgrid[0:H, 0:W]
    fig = plt.figure()
    plt.imshow(pb["tr"])
    plt.title(f"{os.path.basename(npz_path)} : principal direction quiver on tr(G)")
    plt.quiver(X[::stride, ::stride], Y[::stride, ::stride],
               vecs[::stride, ::stride, 0], vecs[::stride, ::stride, 1])
    plt.gca().invert_yaxis()
    _save_fig(fig, out_png)

# ==============================
# Visualization (GEOMETRY + GAUGE)
# ==============================

def _load_geom(npz_dir: str, step_name: str, agent_index: int, mode: str):
    path = os.path.join(npz_dir, f"{step_name}_agent{agent_index}_{mode}_geom.npz")
    if not os.path.exists(path):
        raise FileNotFoundError(path)
    return path, np.load(path)

def _load_core(npz_dir: str, step_name: str, agent_index: int, mode: str):
    path = os.path.join(npz_dir, f"{step_name}_agent{agent_index}_{mode}.npz")
    if not os.path.exists(path):
        raise FileNotFoundError(path)
    return path, np.load(path)

def _load_gauge(npz_dir: str, step_name: str, agent_index: int, mode: str):
    path = os.path.join(npz_dir, f"{step_name}_agent{agent_index}_{mode}_gauge.npz")
    if not os.path.exists(path):
        raise FileNotFoundError(path)
    return path, np.load(path)

def plot_K(npz_dir: str, step_name: str, agent_index: int, mode: str, out_png: str):
    pth, geom = _load_geom(npz_dir, step_name, agent_index, mode)
    K = geom["K"]
    fig = plt.figure()
    im = plt.imshow(K)
    plt.title(f"{os.path.basename(pth)} : K (Gaussian curvature)")
    plt.colorbar(im)
    _save_fig(fig, out_png)

def plot_lie_norm(npz_dir: str, step_name: str, agent_index: int, mode: str, out_png: str):
    pth, geom = _load_geom(npz_dir, step_name, agent_index, mode)
    L = geom["lie_norm_killing"]
    fig = plt.figure()
    im = plt.imshow(L)
    plt.title(f"{os.path.basename(pth)} : ||L_V G|| (approx. Killing)")
    plt.colorbar(im)
    _save_fig(fig, out_png)

def plot_div_curl(npz_dir: str, step_name: str, agent_index: int, mode: str, out_div_png: str, out_curl_png: str):
    pth, geom = _load_geom(npz_dir, step_name, agent_index, mode)
    div = geom["div"]; curl = geom["curl"]
    fig = plt.figure(); im = plt.imshow(div); plt.title(f"{os.path.basename(pth)} : div principal"); plt.colorbar(im); _save_fig(fig, out_div_png)
    fig = plt.figure(); im = plt.imshow(curl); plt.title(f"{os.path.basename(pth)} : curl principal"); plt.colorbar(im); _save_fig(fig, out_curl_png)

def plot_gauge_norm(npz_dir: str, step_name: str, agent_index: int, mode: str, out_png: str):
    try:
        pth, gauge = _load_gauge(npz_dir, step_name, agent_index, mode)
    except FileNotFoundError as e:
        raise e
    Fn = gauge["F_norm"]
    fig = plt.figure()
    im = plt.imshow(Fn)
    plt.title(f"{os.path.basename(pth)} : ||F|| (gauge curvature norm)")
    plt.colorbar(im)
    _save_fig(fig, out_png)

# ==============================
# Belief vs Model comparisons (gaps)
# ==============================

def _compute_gap_from_core(npz_q: str, npz_p: str) -> Dict[str, np.ndarray]:
    q = np.load(npz_q); p = np.load(npz_p)
    delta_tr = q["tr"] - p["tr"]
    delta_sqrt_det = np.sqrt(np.maximum(q["det"],0)) - np.sqrt(np.maximum(p["det"],0))
    log_lmax = np.log((q["lmax"] + 1e-12) / (p["lmax"] + 1e-12))
    log_lmin = np.log((q["lmin"] + 1e-12) / (p["lmin"] + 1e-12))
    vq = q["eigvecs"][..., :, 0]; vp = p["eigvecs"][..., :, 0]
    num = vq[...,0]*vp[...,0] + vq[...,1]*vp[...,1]
    den = np.linalg.norm(vq, axis=-1)*np.linalg.norm(vp, axis=-1) + 1e-12
    cos_principal = num / den
    return dict(delta_tr=delta_tr, delta_sqrt_det=delta_sqrt_det,
                log_lambda_max_ratio=log_lmax, log_lambda_min_ratio=log_lmin,
                cos_principal=cos_principal)

def plot_gap_scalar(npz_dir: str, step_name: str, agent_index: int, key: str, out_png: str):
    path_q = os.path.join(npz_dir, f"{step_name}_agent{agent_index}_belief.npz")
    path_p = os.path.join(npz_dir, f"{step_name}_agent{agent_index}_model.npz")
    if not (os.path.exists(path_q) and os.path.exists(path_p)):
        raise FileNotFoundError("Missing belief/model npz for comparison")
    gap = _compute_gap_from_core(path_q, path_p)
    if key not in gap:
        raise KeyError(f"{key} not in gap set")
    fig = plt.figure()
    im = plt.imshow(gap[key])
    plt.title(f"{step_name} agent{agent_index} : {key} (belief − model)")
    plt.colorbar(im)
    _save_fig(fig, out_png)

# ==============================
# Animations
# ==============================

def animate_scalar_over_time(npz_dir: str,
                             agent_index: int,
                             mode: str,
                             key: str,
                             out_gif: str,
                             duration: float = 0.2,
                             use_percentile: bool = True,
                             lo: float = 1.0,
                             hi: float = 99.0):
    """
    Build a GIF for a scalar field over time from all step files with STATIC color scale.
    Requires files named like: step_XXXX_agent{agent_index}_{mode}.npz
    """
    pattern = f"step_*_agent{agent_index}_{mode}.npz"
    files = sorted(glob.glob(os.path.join(npz_dir, pattern)))
    if not files:
        raise FileNotFoundError(f"No files matching {pattern} in {npz_dir}")

    # Compute global scale once
    vmin, vmax = _compute_static_scale(files, key, use_percentile=use_percentile, lo=lo, hi=hi)

    frames = []
    for f in files:
        pb = np.load(f)
        if key not in pb:
            continue
        arr = pb[key]
        fig = plt.figure()
        im = plt.imshow(arr, vmin=vmin, vmax=vmax)
        plt.title(f"{os.path.basename(f)} : {key}")
        plt.colorbar(im)
        fig.canvas.draw()
        w, h = fig.canvas.get_width_height()
        frame = np.frombuffer(fig.canvas.tostring_rgb(), dtype=np.uint8).reshape((h, w, 3))
        frames.append(frame)
        plt.close(fig)
    imageio.mimsave(out_gif, frames, duration=duration)

def animate_quiver_over_time(npz_dir: str,
                             agent_index: int,
                             mode: str,
                             out_gif: str,
                             stride: int = 4,
                             duration: float = 0.2,
                             use_percentile: bool = True,
                             lo: float = 1.0,
                             hi: float = 99.0):
    """
    GIF of quivers of principal directions over tr(G) with STATIC color scale for tr(G).
    """
    pattern = f"step_*_agent{agent_index}_{mode}.npz"
    files = sorted(glob.glob(os.path.join(npz_dir, pattern)))
    if not files:
        raise FileNotFoundError(f"No files matching {pattern} in {npz_dir}")

    # Fix the color scale for tr(G) once
    vmin, vmax = _compute_static_scale(files, "tr", use_percentile=use_percentile, lo=lo, hi=hi)

    frames = []
    for f in files:
        pb = np.load(f)
        vecs = pb["eigvecs"][..., :, 0]
        trG  = pb["tr"]
        H, W = trG.shape
        Y, X = np.mgrid[0:H, 0:W]
        fig = plt.figure()
        im = plt.imshow(trG, vmin=vmin, vmax=vmax)
        plt.title(f"{os.path.basename(f)} : quiver on tr(G)")
        plt.quiver(X[::stride, ::stride], Y[::stride, ::stride],
                   vecs[::stride, ::stride, 0], vecs[::stride, ::stride, 1])
        plt.gca().invert_yaxis()
        plt.colorbar(im)
        fig.canvas.draw()
        w, h = fig.canvas.get_width_height()
        frame = np.frombuffer(fig.canvas.tostring_rgb(), dtype=np.uint8).reshape((h, w, 3))
        frames.append(frame)
        plt.close(fig)
    imageio.mimsave(out_gif, frames, duration=duration)

def animate_K_over_time(npz_dir: str,
                        agent_index: int,
                        mode: str,
                        out_gif: str,
                        duration: float = 0.2,
                        use_percentile: bool = True,
                        lo: float = 1.0,
                        hi: float = 99.0):
    """
    Animate Gaussian curvature K from *_geom.npz over time with STATIC scale.
    """
    pattern = f"step_*_agent{agent_index}_{mode}_geom.npz"
    files = sorted(glob.glob(os.path.join(npz_dir, pattern)))
    if not files:
        raise FileNotFoundError(f"No files matching {pattern} in {npz_dir}")
    vmin, vmax = _compute_static_scale(files, "K", use_percentile=use_percentile, lo=lo, hi=hi)
    frames = []
    for f in files:
        geom = np.load(f)
        if "K" not in geom:
            continue
        arr = geom["K"]
        fig = plt.figure()
        im = plt.imshow(arr, vmin=vmin, vmax=vmax)
        plt.title(f"{os.path.basename(f)} : K")
        plt.colorbar(im)
        fig.canvas.draw()
        w, h = fig.canvas.get_width_height()
        frames.append(np.frombuffer(fig.canvas.tostring_rgb(), dtype=np.uint8).reshape((h, w, 3)))
        plt.close(fig)
    imageio.mimsave(out_gif, frames, duration=duration)

def animate_Fnorm_over_time(npz_dir: str,
                            agent_index: int,
                            mode: str,
                            out_gif: str,
                            duration: float = 0.2,
                            use_percentile: bool = True,
                            lo: float = 1.0,
                            hi: float = 99.0):
    """
    Animate gauge curvature norm ||F|| from *_gauge.npz over time with STATIC scale.
    """
    pattern = f"step_*_agent{agent_index}_{mode}_gauge.npz"
    files = sorted(glob.glob(os.path.join(npz_dir, pattern)))
    if not files:
        raise FileNotFoundError(f"No files matching {pattern} in {npz_dir}")
    vmin, vmax = _compute_static_scale(files, "F_norm", use_percentile=use_percentile, lo=lo, hi=hi)
    frames = []
    for f in files:
        gauge = np.load(f)
        if "F_norm" not in gauge:
            continue
        arr = gauge["F_norm"]
        fig = plt.figure()
        im = plt.imshow(arr, vmin=vmin, vmax=vmax)
        plt.title(f"{os.path.basename(f)} : ||F||")
        plt.colorbar(im)
        fig.canvas.draw()
        w, h = fig.canvas.get_width_height()
        frames.append(np.frombuffer(fig.canvas.tostring_rgb(), dtype=np.uint8).reshape((h, w, 3)))
        plt.close(fig)
    imageio.mimsave(out_gif, frames, duration=duration)

# ==============================
# Belief vs Model comparisons (single step)
# ==============================

def compare_belief_model_scalar(npz_dir: str,
                                step_name: str,
                                agent_index: int,
                                key: str,
                                out_png: str):
    """
    Plot Δ scalar(q - p) for a single step and agent.
    """
    path_q = os.path.join(npz_dir, f"{step_name}_agent{agent_index}_belief.npz")
    path_p = os.path.join(npz_dir, f"{step_name}_agent{agent_index}_model.npz")
    if not (os.path.exists(path_q) and os.path.exists(path_p)):
        raise FileNotFoundError("Missing belief/model npz for comparison")

    gap = _compute_gap_from_core(path_q, path_p)
    if key not in gap:
        raise KeyError(f"{key} not in gap set")
    fig = plt.figure()
    im = plt.imshow(gap[key])
    plt.title(f"{step_name} agent{agent_index} : {key} (belief − model)")
    plt.colorbar(im)
    _save_fig(fig, out_png)

# ==============================
# Batch driver (no-arg)
# ==============================

def run_all(steps_dir: str = "checkpoints",
           outdir_npz: str = "pullbacks",
           outdir_figs: str = "pullback_reports",
           modes: List[str] = ["belief", "model"],
           periodic: bool = True,
           eps: float = 1e-6,
           do_compute: bool = True,
           do_plots: bool = True,
           do_gifs: bool = True,
           n_agents_preview: Optional[int] = 2):
    """
    End-to-end orchestration:
      1) compute NPZ pullbacks (+ geometry + gauge) for all steps and agents
      2) plot a small set of PNGs per (agent,mode) for the first few agents
      3) make simple GIFs for tr(G), quivers, K, and ||F|| for the first few agents
    """
    os.makedirs(outdir_npz, exist_ok=True)
    os.makedirs(outdir_figs, exist_ok=True)

    if do_compute:
        summaries = compute_pullbacks_all(steps_dir, outdir_npz, modes=modes, periodic=periodic, eps=eps)
        # Write CSV summary
        import pandas as pd
        csv_path = os.path.join(outdir_npz, "fisher_pullback_summary.csv")
        pd.DataFrame(summaries).to_csv(csv_path, index=False)

    # determine how many agents from the first step
    step_files = find_step_files(steps_dir)
    if not step_files:
        raise FileNotFoundError(f"No step_*.pkl files found in {steps_dir}")
    agents = load_agents_from_step(step_files[0])
    n_agents = len(agents)
    if n_agents_preview is not None:
        n_agents = min(n_agents, n_agents_preview)

    if do_plots:
        # Simple scalars for the first step only (preview)
        step0 = os.path.splitext(os.path.basename(step_files[0]))[0]
        for idx in range(n_agents):
            for mode in modes:
                tag = f"{step0}_agent{idx}_{mode}"
                core_npz = os.path.join(outdir_npz, f"{tag}.npz")
                geom_npz = os.path.join(outdir_npz, f"{tag}_geom.npz")
                gauge_npz= os.path.join(outdir_npz, f"{tag}_gauge.npz")

                if os.path.exists(core_npz):
                    for key in ["tr", "det", "lmax", "lmin", "aniso"]:
                        plot_scalar(core_npz, key, os.path.join(outdir_figs, f"{tag}_{key}.png"))
                    plot_orientation(core_npz, os.path.join(outdir_figs, f"{tag}_theta.png"))
                    plot_quiver(core_npz, os.path.join(outdir_figs, f"{tag}_quiver.png"), stride=4)

                if os.path.exists(geom_npz):
                    plot_K(outdir_npz, step0, idx, mode, os.path.join(outdir_figs, f"{tag}_K.png"))
                    plot_lie_norm(outdir_npz, step0, idx, mode, os.path.join(outdir_figs, f"{tag}_lie_norm_killing.png"))
                    plot_div_curl(outdir_npz, step0, idx, mode,
                                  os.path.join(outdir_figs, f"{tag}_div.png"),
                                  os.path.join(outdir_figs, f"{tag}_curl.png"))

                if os.path.exists(gauge_npz):
                    plot_gauge_norm(outdir_npz, step0, idx, mode, os.path.join(outdir_figs, f"{tag}_F_norm.png"))

            # also belief-vs-model gaps (single step)
            try:
                for key in ["delta_tr","delta_sqrt_det","log_lambda_max_ratio","log_lambda_min_ratio","cos_principal"]:
                    compare_belief_model_scalar(outdir_npz, step0, idx, key, os.path.join(outdir_figs, f"{step0}_agent{idx}_{key}.png"))
            except Exception:
                pass

    if do_gifs:
        # Across all steps for the first few agents
        for idx in range(n_agents):
            for mode in modes:
                try:
                    animate_scalar_over_time(outdir_npz, idx, mode, "tr",
                                             os.path.join(outdir_figs, f"agent{idx}_{mode}_tr.gif"),
                                             duration=0.25)
                except Exception:
                    pass
                try:
                    animate_quiver_over_time(outdir_npz, idx, mode,
                                             os.path.join(outdir_figs, f"agent{idx}_{mode}_quiver.gif"),
                                             stride=4, duration=0.25)
                except Exception:
                    pass
                try:
                    animate_K_over_time(outdir_npz, idx, mode,
                                        os.path.join(outdir_figs, f"agent{idx}_{mode}_K.gif"),
                                        duration=0.25)
                except Exception:
                    pass
                try:
                    animate_Fnorm_over_time(outdir_npz, idx, mode,
                                            os.path.join(outdir_figs, f"agent{idx}_{mode}_Fnorm.gif"),
                                            duration=0.25)
                except Exception:
                    pass
                try:
                    animate_lie_norm_over_time(outdir_npz, idx, mode,
                        os.path.join(outdir_figs, f"agent{idx}_{mode}_Lie.gif"), duration=0.25)
                except Exception:
                    pass

                # bake correspondence maps (writes *_corr.npz) and animate them
                try:
                    _ = bake_correspondence_npz_series(outdir_npz, idx, mode, outdir_npz)
                    animate_zKzF_over_time(outdir_npz, idx, mode,
                        os.path.join(outdir_figs, f"agent{idx}_{mode}_zKzF.gif"),
                        duration=0.25, use_percentile=True, lo=2, hi=98)
                except Exception:
                    pass

                try:
                    write_correspondence_csv(outdir_npz, os.path.join(outdir_npz, "gauge_fisher_correspondence.csv"), modes)
                except Exception:
                    pass
                animate_fisher_suite(outdir_npz, idx, mode, outdir_figs)



# ---------- Gauge–Fisher correspondence ----------

def _finite_mask(*arrs):
    m = None
    for a in arrs:
        good = np.isfinite(a)
        m = good if m is None else (m & good)
    return m

def _zscore(a, mask):
    x = a[mask]
    if x.size == 0:
        return a*0 + np.nan
    mu = float(np.mean(x)); sd = float(np.std(x) + 1e-12)
    z = (a - mu) / sd
    z[~mask] = np.nan
    return z

def _pearson(a, b, mask):
    x = a[mask]; y = b[mask]
    if x.size < 2: return np.nan
    x = (x - x.mean()); y = (y - y.mean())
    denom = (np.sqrt((x*x).sum()) * np.sqrt((y*y).sum()) + 1e-12)
    return float((x*y).sum() / denom)

def bake_correspondence_npz_series(npz_dir: str,
                                   agent_index: int,
                                   mode: str,
                                   outdir: str):
    """
    For all steps, load *_geom, *_gauge, and core npz, compute:
      - zK, zF, zKzF
      - cos_kill_principal
      - framewise correlations: corr_K_F, corr_Lie_F, corr_Lie_tr
    Save a *_corr.npz per step so you can animate zKzF etc.
    """
    os.makedirs(outdir, exist_ok=True)
    pattern = f"step_*_agent{agent_index}_{mode}"
    bases = sorted(set(p[:-4] for p in glob.glob(os.path.join(npz_dir, pattern + "*.npz"))))
    summaries = []
    for base in bases:
        core = base + ".npz"
        geom = base + "_geom.npz"
        gauge= base + "_gauge.npz"
        if not (os.path.exists(core) and os.path.exists(geom) and os.path.exists(gauge)):
            continue
        C = np.load(core); Gm = np.load(geom); Ga = np.load(gauge)

        K   = Gm["K"]                     # (H,W)
        L   = Gm["lie_norm_killing"]      # (H,W)
        v   = Gm["v"]                     # (H,W,2) principal dir
        Vk  = Gm["killing_dir"]           # (H,W,2)
        Fn  = Ga["F_norm"]                # (H,W)
        trG = C["tr"]

        mask = _finite_mask(K, Fn, L, trG, v[...,0], Vk[...,0])

        # z-scores (mask-aware)
        zK = _zscore(K, mask)
        zF = _zscore(Fn, mask)
        zKzF = zK * zF

        # cos between Killing and principal directions
        dot = Vk[...,0]*v[...,0] + Vk[...,1]*v[...,1]
        nv  = np.linalg.norm(v, axis=-1); nVk = np.linalg.norm(Vk, axis=-1)
        cos_kill_principal = dot / (nv*nVk + 1e-12)
        cos_kill_principal[~mask] = np.nan

        # framewise correlations (scalars)
        r_KF   = _pearson(K, Fn, mask)
        r_LF   = _pearson(L, Fn, mask)
        r_Ltr  = _pearson(L, trG, mask)

        # save per-step derived arrays
        out = base + "_corr.npz"
        np.savez_compressed(out,
            zK=zK, zF=zF, zKzF=zKzF,
            cos_kill_principal=cos_kill_principal,
            corr_K_F=r_KF, corr_Lie_F=r_LF, corr_Lie_tr=r_Ltr)
        summaries.append(dict(step=os.path.basename(base).split("_agent")[0],
                              agent_index=agent_index, mode=mode,
                              corr_K_F=r_KF, corr_Lie_F=r_LF, corr_Lie_tr=r_Ltr))
    return summaries


def write_correspondence_csv(outdir_npz: str, out_csv: str, modes: List[str], n_agents_guess: int = 4):
    rows = []
    # crude scan
    bases = sorted(glob.glob(os.path.join(outdir_npz, "step_*_agent*_*.npz")))
    for b in bases:
        name = os.path.basename(b)
        if name.endswith("_corr.npz"):
            d = np.load(os.path.join(outdir_npz, name))
            step = name.split("_agent")[0]
            rest = name.split("_agent")[1]
            agent = int(rest.split("_")[0]); mode = rest.split("_")[1]
            rows.append(dict(step=step, agent_index=agent, mode=mode,
                             corr_K_F=float(d["corr_K_F"]),
                             corr_Lie_F=float(d["corr_Lie_F"]),
                             corr_Lie_tr=float(d["corr_Lie_tr"])))
    if rows:
        import pandas as pd
        pd.DataFrame(rows).to_csv(out_csv, index=False)



def animate_zKzF_over_time(npz_dir: str,
                            agent_index: int,
                            mode: str,
                            out_gif: str,
                            duration: float = 0.2,
                            use_percentile: bool = True,
                            lo: float = 1.0,
                            hi: float = 99.0):
    """
    Animate zK*zF maps over time (positive = co-located high curvature & high gauge).
    """
    pattern = f"step_*_agent{agent_index}_{mode}_corr.npz"
    files = sorted(glob.glob(os.path.join(npz_dir, pattern)))
    if not files:
        raise FileNotFoundError(f"No files matching {pattern} in {npz_dir}")
    vmin, vmax = _compute_static_scale(files, "zKzF", use_percentile=use_percentile, lo=lo, hi=hi)
    frames = []
    for f in files:
        d = np.load(f); arr = d["zKzF"]
        fig = plt.figure()
        im = plt.imshow(arr, vmin=vmin, vmax=vmax)
        plt.title(f"{os.path.basename(f)} : zK·zF")
        plt.colorbar(im)
        fig.canvas.draw()
        w,h = fig.canvas.get_width_height()
        frames.append(np.frombuffer(fig.canvas.tostring_rgb(), dtype=np.uint8).reshape((h,w,3)))
        plt.close(fig)
    imageio.mimsave(out_gif, frames, duration=duration)


# ---------- Convenience: Fisher animations ----------
def animate_fisher_suite(npz_dir: str, agent_index: int, mode: str, outdir_figs: str):
    keys = ["tr", "det", "lmax", "lmin", "aniso"]
    for k in keys:
        try:
            animate_scalar_over_time(npz_dir, agent_index, mode, k,
                os.path.join(outdir_figs, f"agent{agent_index}_{mode}_{k}.gif"),
                duration=0.25, use_percentile=True, lo=2, hi=98)
        except Exception:
            pass

def animate_lie_norm_over_time(npz_dir: str,
                               agent_index: int,
                               mode: str,
                               out_gif: str,
                               duration: float = 0.2,
                               use_percentile: bool = True,
                               lo: float = 1.0,
                               hi: float = 99.0):
    pattern = f"step_*_agent{agent_index}_{mode}_geom.npz"
    files = sorted(glob.glob(os.path.join(npz_dir, pattern)))
    if not files:
        raise FileNotFoundError(f"No files matching {pattern} in {npz_dir}")
    vmin, vmax = _compute_static_scale(files, "lie_norm_killing",
                                       use_percentile=use_percentile, lo=lo, hi=hi)
    frames = []
    for f in files:
        geom = np.load(f)
        if "lie_norm_killing" not in geom: continue
        arr = geom["lie_norm_killing"]
        fig = plt.figure()
        im = plt.imshow(arr, vmin=vmin, vmax=vmax)
        plt.title(f"{os.path.basename(f)} : ||L_V G||")
        plt.colorbar(im)
        fig.canvas.draw()
        w,h = fig.canvas.get_width_height()
        frames.append(np.frombuffer(fig.canvas.tostring_rgb(), dtype=np.uint8).reshape((h,w,3)))
        plt.close(fig)
    imageio.mimsave(out_gif, frames, duration=duration)




if __name__ == "__main__":
    # No-arg runner targeting your default folders
    run_all(steps_dir="checkpoints",
            outdir_npz="pullbacks",
            outdir_figs="pullback_reports",
            modes=["belief", "model"],
            periodic=True,
            eps=1e-6,
            do_compute=True,
            do_plots=True,
            do_gifs=True,
            n_agents_preview=2)
