
import os
os.environ["OMP_NUM_THREADS"] = "1"
os.environ["MKL_NUM_THREADS"] = "1"
os.environ["NUMEXPR_NUM_THREADS"] = "1"  # Optional: just in case
os.environ["OPENBLAS_NUM_THREADS"]= "1"

# Print to confirm they are set
print("[THREADING] Thread limits set:")
print(f"  OMP_NUM_THREADS      = {os.environ.get('OMP_NUM_THREADS')}")
print(f"  MKL_NUM_THREADS      = {os.environ.get('MKL_NUM_THREADS')}")
print(f"  NUMEXPR_NUM_THREADS  = {os.environ.get('NUMEXPR_NUM_THREADS')}")
print(f"  OPENBLAS_NUM_THREADS = {os.environ.get('OPENBLAS_NUM_THREADS')}")

# Standard library
import os
import time

# Third-party
import pickle
import pandas as pd
from update_rules import synchronous_step, step_telemetry,_masked_unit, energy_diff_for_phi, energy_diff_for_phi_model
# Local configuration & utilities

from config_utils import set_config_from_params
from get_generators import get_generators
# run_simulation.py (cleaner entrypoint)
import sys


# I/O helpers
from generalized_io_utils import (
    save_step,
    load_checkpoint,
    find_resume_step,
    save_config_to_readme,
)

# Agent construction
from agent_initialization import initialize_agents, initialize_agent_gradients
import config
from generalized_diagnostics_metrics import log_all_metrics, full_field_logger




def run_simulation(
    outdir="checkpoints",
    resume=False,
    log_metrics=True,
    log_fields=True,
    num_cores=None,
    params=None,
):
    
    os.makedirs(outdir, exist_ok=True)
    save_config_to_readme(outdir)

    if num_cores is None:
        num_cores = 18

    params = params or {}
    G_q = params.get("generators_q")
    G_p = params.get("generators_p")
    # ensure generators exist even if params didn’t include them
    if G_q is None:
        G_q, _ = get_generators(config.group_name, config.K_q, return_meta=True)
        params["generators_q"] = G_q
    if G_p is None:
        G_p, _ = get_generators(config.group_name, config.K_p, return_meta=True)
        params["generators_p"] = G_p

    # ─────────── Initialization ─────────────
    if resume:
        agents, _ = load_checkpoint(outdir)
        step_start = find_resume_step(outdir)
        # make sure resumed agents have generators
        for agent in agents:
            agent.generators_q = G_q
            agent.generators_p = G_p        
        
    else:
        agents = initialize_agents(
            seed=getattr(config, "seed", None),
            domain_size=config.domain_size,
            N=config.N,
            K_q=config.K_q,
            K_p=config.K_p,
            lie_algebra_dim=3,
            visualize=False,
            fixed_location=True,
        )
        step_start = 0
        for agent in agents:
            initialize_agent_gradients(agent, config)
            agent.generators_q = G_q
            agent.generators_p = G_p

    metric_log = []
    print(f"[RUN] Starting simulation at step {step_start} with {num_cores} cores")

 
   # ─────────── Simulation Loop ─────────────
    fd_every   = getattr(config, "fd_check_every", 1000)
    fd_pairs   = getattr(config, "fd_pairs_per_step", 1)
    for step in range(step_start, config.steps):
        print(f"\n[STEP {step}] -----------------------------")

        t0 = time.perf_counter()
        step_params = dict(params)
        step_params.update({
            "step": step,
            # light sanitize on the pre-pass; strict happens post-update
            "sanitize_strict_pre": False,
            # telemetry printed after the step (we call it below)
        })
        
        agents = synchronous_step(agents, G_q, G_p, params=step_params, n_jobs=num_cores)
        print(f"[TIMER] synchronous update: {time.perf_counter() - t0:.3f}s")
        # Quick per-step health snapshot (η, KL medians, min eigens)
       
        # step_telemetry(agents, step)

        # ---- Finite-difference descent checks (every fd_every steps) ----
        if fd_every and (step % fd_every == 0):
            
            # pick up to fd_pairs neighbor pairs
            checked = 0
            for A in agents:
                if not A.neighbors: 
                    continue
                j = A.neighbors[0]["id"] if isinstance(A.neighbors[0], dict) else A.neighbors[0]
                if j is None or j == A.id: 
                    continue
                B = next((x for x in agents if x.id == j), None)
                if B is None: 
                    continue
                
                res_q = energy_diff_for_phi(A, B, agents, expect="minus")  # φ uses −grad
                res_p = energy_diff_for_phi_model(A, B, agents, expect="plus")  # φ̃ uses +grad now

                print(f"[FD φ]  {A.id}->{B.id}: ok={res_q.get('ok')}, used_eps={res_q.get('used_eps')}, \n"
                      f"E0={res_q.get('E0', float('nan')):.3e}, ||g||={res_q.get('gnorm', float('nan')):.2e}, "
                      f"rows={res_q.get('rows', [])[:2]}")
                print(f"[FD φ̃] {A.id}->{B.id}: ok={res_p.get('ok')}, used_eps={res_p.get('used_eps')}, "
                      f"E0={res_p.get('E0', float('nan')):.3e}, ||g||={res_p.get('gnorm', float('nan')):.2e}, "
                      f"rows={res_p.get('rows', [])[:2]}")


                checked += 1
                if checked >= fd_pairs:
                    break

        # (B) Log metrics
        if log_metrics:
            t0 = time.perf_counter()
            m = log_all_metrics(agents, step=step, params=params, n_jobs=num_cores)
            metric_log.append({"step": step, **m})
            
            print(f"[Energy Totals @ step {step}]")
            print(f"  Self belief      = {m['e_self']:.4e}")
            print(f"  Feedback model   = {m['e_feedback']:.4e}")
            print(f"  Belief alignment = {m['e_align']:.4e}")
            print(f"  Model alignment  = {m['e_mod_align']:.4e}")
            print(f"  Model Mass       = {m['e_mass_mod']:.4e}")
            print(f"  Belief Mass      = {m['e_mass']:.4e}")
            print(f"  Belief Curvature = {m['e_curv']:.4e}")
            print(f"  Model Curvature  = {m['e_curv_mod']:.4e}\n")
            print(f"[TIMER] log_all_metrics_fused: {time.perf_counter() - t0:.3f}s")

        # (C) Dump full fields
        if log_fields and getattr(config, "log_full_fields", False):
            t0_fields = time.perf_counter()
            field_dir = os.path.join(outdir, "fields")
            full_field_logger(agents, step, field_dir)
            print(f"[TIMER] full_step_field_logger: {time.perf_counter() - t0_fields:.3f}s")

        # (D) Save checkpoint
        for A in agents:
            A.clear_omega_cache()
            A.clear_fisher_caches()
        save_step(agents, outdir, step)
        print(f"[SAVE] Checkpoint → {outdir}/step_{step:04d}.pkl")

    # ─────────── Final Output ─────────────
    if log_metrics:
        with open(os.path.join(outdir, "metric_log.pkl"), "wb") as f:
            pickle.dump(metric_log, f)
        print(f"[SAVE] Metrics log → {outdir}/metric_log.pkl")

        rows = []
        for A in agents:
            for entry in A.metrics_log:
                rows.append({"agent": A.id, **entry})
        pd.DataFrame(rows).to_csv(os.path.join(outdir, "per_agent_metrics.csv"), index=False)
        print("[SAVE] Per-agent metrics → per_agent_metrics.csv")

    print("[DONE] Simulation completed.")
    return agents, metric_log





if __name__ == "__main__":
    

    # ─────────────────────────────────────────────
    # 1. Optional param override
    # ─────────────────────────────────────────────
    if len(sys.argv) > 1:
        with open(sys.argv[1], "rb") as f:
            param_override = pickle.load(f)
        set_config_from_params(param_override)
    else:
        param_override = {}

    # ─────────────────────────────────────────────
    # 2. Load SO(3) generators for q and p fibers
    # ─────────────────────────────────────────────
    G_q, meta_q = get_generators(config.group_name, config.K_q, return_meta=True)
    G_p, meta_p = get_generators(config.group_name, config.K_p, return_meta=True)

    # ─────────────────────────────────────────────
    # 3. Bundle runtime-only params
    # ─────────────────────────────────────────────
    runtime_params = {
        "generators_q": G_q,
        "generators_p": G_p,
    }

    # ─────────────────────────────────────────────
    # 4. Run the simulation
    # ─────────────────────────────────────────────
    run_simulation(
        outdir="checkpoints",
        resume=False,
        log_metrics = True,
        log_fields  = True ,
        params=runtime_params,
    )
