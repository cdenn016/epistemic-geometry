# -*- coding: utf-8 -*-
"""
Created on Wed Sep  3 13:38:40 2025

@author: chris and christine
"""

import numpy as np
from transport.transport_cache import plaquette_product as tc_plaquette

def test_flat_field_has_zero_curvature_float64(ctx, tiny_children):
    a = tiny_children[0]
    H, W, K = a.phi_field.shape[:2] + (a.phi_field.shape[-1],)
    # constant φ
    const = np.zeros_like(a.phi_field, dtype=np.float64)
    Gq = np.asarray(getattr(a, "generators_q"), np.float64)
    P = tc_plaquette(ctx, const, Gq, boundary="periodic", split_edge=True)
    I = np.eye(P.shape[-1], dtype=np.float64)
    curv = np.linalg.norm(P - I, ord="fro", axis=(-2,-1))**2
    assert float(np.mean(curv)) < 1e-12

def test_flat_field_has_zero_curvature_float32(ctx, tiny_children):
    a = tiny_children[0]
    H, W, K = a.phi_field.shape[:2] + (a.phi_field.shape[-1],)
    const = np.zeros_like(a.phi_field, dtype=np.float32)
    Gq = np.asarray(getattr(a, "generators_q"), np.float32)
    P = tc_plaquette(ctx, const, Gq, boundary="periodic", split_edge=True)
    I = np.eye(P.shape[-1], dtype=np.float32)
    curv = np.linalg.norm(P - I, ord="fro", axis=(-2,-1))**2
    assert float(np.mean(curv)) < 1e-7
