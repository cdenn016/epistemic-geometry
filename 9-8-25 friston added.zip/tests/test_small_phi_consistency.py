# -*- coding: utf-8 -*-
"""
Created on Wed Sep  3 13:38:53 2025

@author: chris and christine
"""

import numpy as np
import pytest

from transport.transport_cache import plaquette_product as tc_plaquette
try:
    from core.omega import compute_field_strength
except Exception:
    compute_field_strength = None

@pytest.mark.skipif(compute_field_strength is None, reason="continuum helper not available")
def test_small_phi_plaquette_matches_continuum(ctx, tiny_children):
    a = tiny_children[0]
    # force small ||phi||_inf
    phi = np.clip(a.phi_field, -1e-3, 1e-3).astype(np.float32)
    G = np.asarray(getattr(a,"generators_q"), np.float32)

    P = tc_plaquette(ctx, phi, G, boundary="periodic", split_edge=True)
    I = np.eye(P.shape[-1], dtype=np.float32)
    pq = np.linalg.norm(P - I, ord="fro", axis=(-2,-1))**2

    F = compute_field_strength(phi, G, dx=1.0)["xy"]
    fq = np.linalg.norm(F, ord="fro", axis=(-2,-1))**2

    assert np.mean(np.abs(pq - fq)) < 1e-6
