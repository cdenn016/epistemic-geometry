# -*- coding: utf-8 -*-
"""
Created on Mon Sep  1 18:40:29 2025

@author: chris and christine
"""

# tests/test_gradients.py
import numpy as np
import types
import pytest

# --- lightweight Agent / Ctx scaffolding ----------------------------------
class Agent:
    pass

class Ctx:
    def __init__(self):
        self.global_step = 0
        self.support_tau = 1e-6

        class _Cache:
            def __init__(self):
                self._spaces = {}
            def clear_on_step(self, *_): 
                pass
            def ns(self, *_, **__):
                return {}
            def nsp(self, name: str):
                # simple per-namespace dict to satisfy callers
                return self._spaces.setdefault(name, {})

        self.cache = _Cache()


def _spd(B, jitter=0.1):
    B = np.asarray(B, np.float32)
    K = B.shape[-1]
    return np.einsum("...ik,...jk->...ij", B, B) + jitter * np.eye(K, dtype=np.float32)

def make_agent(H=4, W=4, K=3, seed=0):
    rng = np.random.default_rng(seed)
    A = Agent()
    A.id = 0
    A.mask = np.ones((H, W), np.float32)
    A.mu_q_field = rng.normal(size=(H, W, K)).astype(np.float32)
    A.mu_p_field = A.mu_q_field.copy()
    Bq = rng.normal(size=(H, W, K, K)).astype(np.float32)
    A.sigma_q_field = _spd(Bq)
    A.sigma_p_field = A.sigma_q_field.copy()
    A.phi = np.zeros((H, W, 3), np.float32)
    A.phi_model = np.zeros((H, W, 3), np.float32)

    # allocate grad slots as None (orchestrator populates)
    A.grad_mu_q = A.grad_sigma_q = None
    A.grad_mu_p = A.grad_sigma_p = None
    A.grad_phi = A.grad_phi_tilde = None
    A.grad_Phi = A.grad_Phi_tilde = None

    # Fisher^{-1} for φ / φ̃ as simple identity to test plumbing
    A.inverse_fisher_phi = np.ones((H, W, 3), np.float32)
    A.inverse_fisher_phi_model = np.ones((H, W, 3), np.float32)
    return A

# --- global stubs for the transport cache so tests don't need heavy ctx.cache
@pytest.fixture(autouse=True)
def stub_transport(monkeypatch):
    # Identity exp(φ), inverse-Jacobian Jinv, and Ω transport
    def E_grid(ctx, agent, which="q"):
        H, W = agent.mask.shape
        return np.broadcast_to(np.eye(3, dtype=np.float32), (H, W, 3, 3)).copy()
    def Jinv_grid(ctx, agent, which="q"):
        H, W = agent.mask.shape
        return np.broadcast_to(np.eye(3, dtype=np.float32), (H, W, 3, 3)).copy()
    def Omega(ctx, ai, aj, which="q"):
        H, W = ai.mask.shape
        return np.broadcast_to(np.eye(3, dtype=np.float32), (H, W, 3, 3)).copy()
    def build_dexpinv_matrix(phi):
        H, W, _ = phi.shape
        return np.broadcast_to(np.eye(3, dtype=np.float32), (H, W, 3, 3)).copy()
    # Simple Phi stub: prefer agent-provided matrices, else identity with correct shape
    def Phi(ctx, agent, kind: str = "q_to_p"):
        if kind == "q_to_p":
            M = getattr(agent, "Phi_q_to_p", None)
            if M is not None: 
                return np.asarray(M)
            Kq = agent.mu_q_field.shape[-1]
            Kp = agent.mu_p_field.shape[-1]
            return np.eye(Kp, Kq, dtype=np.float32)
        else:  # "p_to_q"
            M = getattr(agent, "Phi_p_to_q", None)
            if M is not None: 
                return np.asarray(M)
            Kq = agent.mu_q_field.shape[-1]
            Kp = agent.mu_p_field.shape[-1]
            return np.eye(Kq, Kp, dtype=np.float32)

    import transport.transport_cache as tc
    monkeypatch.setattr(tc, "Phi", Phi, raising=True)
    
    import transport.transport_cache as tc
    monkeypatch.setattr(tc, "E_grid", E_grid, raising=True)
    monkeypatch.setattr(tc, "Jinv_grid", Jinv_grid, raising=True)
    monkeypatch.setattr(tc, "Omega", Omega, raising=True)
    monkeypatch.setattr(tc, "build_dexpinv_matrix", build_dexpinv_matrix, raising=True)
    yield

# --- 1) Orchestrator wiring + xscale switch ---------------------------------
def test_orchestrator_calls_all_blocks(monkeypatch):
    import numpy as np
    import updates.update_compute_all_gradients as U  # orchestrator module

    calls = {"mu_b":0, "mu_m":0, "align_phi":0, "align_phi_t":0, "xscale":0, "morph_phi":0, "morph_phi_t":0}

    # stub derivative-of-exp for alignment (only needed if real alignment runs)
    def fake_qall(phi_vec, generators):
        phi_vec = np.asarray(phi_vec, np.float32)
        *shape, d = phi_vec.shape
        assert d == 3
        I = np.eye(3, dtype=np.float32)
        return [np.broadcast_to(I, tuple(shape)+(3,3)).copy() for _ in range(3)]

    # make _alignment_block use our stubbed derivative
    monkeypatch.setitem(U._FIELD_META["phi"], "qall_func", fake_qall)
    monkeypatch.setitem(U._FIELD_META["phi_model"], "qall_func", fake_qall)

    # --- μ/Σ accumulation (belief/model) ------------------------------------
    def fake_mu_sigma(agent_i, agents, params, mode):
        if mode == "belief": calls["mu_b"] += 1
        elif mode == "model": calls["mu_m"] += 1
        H, W, K = agent_i.mu_q_field.shape
        if mode == "belief":
            agent_i.grad_mu_q = np.ones((H,W,K), np.float32)
            agent_i.grad_sigma_q = np.ones((H,W,K,K), np.float32)
        else:
            agent_i.grad_mu_p = np.ones((H,W,K), np.float32)
            agent_i.grad_sigma_p = np.ones((H,W,K,K), np.float32)
    # PATCH the orchestrator's alias (not the source module)
    monkeypatch.setattr(
        "updates.update_compute_all_gradients.accumulate_mu_sigma_gradient",
        fake_mu_sigma,
        raising=True,
    )

    # --- φ alignment (phi / phi_model) --------------------------------------
    def fake_align(agent_i, agent_j, generators, params, **kw):
        k = "align_phi" if kw.get("field","phi")=="phi" else "align_phi_t"
        calls[k] += 1
        H, W, _ = agent_i.phi.shape
        g = getattr(agent_i, "grad_phi" if kw.get("field")=="phi" else "grad_phi_tilde")
        v = np.full((H,W,3), 0.5, np.float32)
        if g is None:
            if kw.get("field")=="phi": agent_i.grad_phi = v
            else: agent_i.grad_phi_tilde = v
        else:
            g += v
    # PATCH the orchestrator's alias
    monkeypatch.setattr(
        "updates.update_compute_all_gradients.accumulate_phi_alignment_gradient",
        fake_align,
        raising=True,
    )

    # --- xscale env accumulators --------------------------------------------
    def fake_mu_sigma_env(agent_i, **_):
        H,W,K = agent_i.mu_q_field.shape
        return np.full((H,W,K), 0.2, np.float32), np.zeros((H,W,K,K), np.float32)
    def fake_xscale_phi_env(agent_i, **_):
        calls["xscale"] += 1
        H,W,_ = agent_i.phi.shape
        agent_i.grad_phi = (np.zeros((H,W,3), np.float32)
                            if agent_i.grad_phi is None else agent_i.grad_phi)
        agent_i.grad_phi += 0.2
    # PATCH the orchestrator's aliases
    monkeypatch.setattr(
        "updates.update_compute_all_gradients.compute_crossscale_mu_sigma_env",
        fake_mu_sigma_env,
        raising=True,
    )
    monkeypatch.setattr(
        "updates.update_compute_all_gradients.accumulate_crossscale_phi_env",
        fake_xscale_phi_env,
        raising=True,
    )

    # --- morphism self/feedback for φ / φ̃ -----------------------------------
    def fake_morph(agent_i, *args, **kw):
        k = "morph_phi" if kw.get("field","phi")=="phi" else "morph_phi_t"
        calls[k] += 1
        H,W,_ = agent_i.phi.shape
        gname = "grad_phi" if kw.get("field")=="phi" else "grad_phi_tilde"
        g = getattr(agent_i, gname)
        v = np.full((H,W,3), 0.3, np.float32)
        setattr(agent_i, gname, (v if g is None else (g+v)))
    # PATCH the orchestrator's alias
    monkeypatch.setattr(
        "updates.update_compute_all_gradients.accumulate_phi_morphism_self_feedback",
        fake_morph,
        raising=True,
    )

    # one agent, self-neighbor to trigger alignment block
    A = make_agent(); A.id = 0; A.neighbors = [{"id":0}]

    params = {"beta":1.0, "enable_xscale": True}
    (gq, Sq), (gp, Sp), gphi, gphit, *_ = U.compute_all_gradients(
        A, [A], [A], None, None, params, runtime_ctx=Ctx()
    )

    for arr in [gq, Sq, gp, Sp, gphi, gphit]:
        assert arr is not None and np.all(np.isfinite(arr))

    assert calls == {
        "mu_b":1, "mu_m":1,
        "align_phi":1, "align_phi_t":1,
        "xscale":1,
        "morph_phi":1, "morph_phi_t":1
    }




# --- 2) apply_phi_updates: mask + clipping works -----------------------------
def test_apply_phi_updates_mask_and_clip():
    import updates.update_compute_all_gradients as U

    A = make_agent(H=3, W=3)
    # only center pixel active
    A.mask[:] = 0.0
    A.mask[1,1] = 1.0

    # giant gradients → should be clipped, applied only where mask==1
    g_phi   = np.full_like(A.phi,  1000.0, np.float32)
    g_phim  = np.full_like(A.phi, -1000.0, np.float32)
    params  = {"tau_phi": 1.0, "tau_phi_model": 1.0}
    # configure clip thresholds small to force clipping
    import core.config as config
    config.gradient_clip_phi = 0.5
    config.gradient_clip_phi_model = 0.5

    old_phi  = A.phi.copy()
    old_phim = A.phi_model.copy()
    
    # A2 = U.apply_phi_updates(A, g_phi, g_phim, A.mask, params, ctx=Ctx())
    U.apply_phi_updates(A, g_phi, g_phim, A.mask, params, ctx=Ctx())
    A2 = A  # updates were in-place


    

    # only center pixel changes
    changed_phi  = np.nonzero(np.any((A2.phi - old_phi) != 0, axis=-1))
    changed_phim = np.nonzero(np.any((A2.phi_model - old_phim) != 0, axis=-1))
    assert set(zip(*changed_phi))  == {(1,1)}
    assert set(zip(*changed_phim)) == {(1,1)}

    # magnitude at center equals learning-rate * clipped-grad-norm
    center_delta = np.linalg.norm((A2.phi - old_phi)[1,1])
    assert center_delta > 0 and center_delta <= config.gradient_clip_phi + 1e-6

# --- 3) alignment block no-overlap is a no-op --------------------------------
def test_alignment_no_overlap_is_noop(monkeypatch):
    from updates.update_terms_phi import accumulate_phi_alignment_gradient

    ai = make_agent()
    aj = make_agent()
    ai.mask[:] = 1.0
    aj.mask[:] = 0.0  # no overlap -> early return

    params = {"beta": 1.0, "runtime_ctx": Ctx()}
    # Provide dummy generators; transport is stubbed to identities by fixture
    G = object()

    # If implementation early-returns, agent.grad_phi stays None / unchanged
    before = getattr(ai, "grad_phi", None)
    accumulate_phi_alignment_gradient(ai, aj, G, params, field="phi",
                                      beta_key="beta", mu_key="mu_q_field", sigma_key="sigma_q_field",
                                      fisher_inv_key="inverse_fisher_phi", grad_key="grad_phi",
                                      Q_all_i=None, exp_neg_phi_j=None, agents=None)
    after = getattr(ai, "grad_phi", None)
    assert before is None and after is None

# --- 4) morphism self/feedback weights & Fisher application ------------------
def test_morphism_grad_uses_alpha_lambda_and_fisher(monkeypatch):
    from updates.update_terms_phi import accumulate_phi_morphism_self_feedback

    A = make_agent()
    ctx = Ctx()
    params = {"alpha": 2.0, "feedback_weight": 3.0, "runtime_ctx": ctx}

    # make Fisher^{-1} amplify only the first component by factor 2
    A.inverse_fisher_phi = np.array([[[2.0,1.0,1.0]]], np.float32)
    A.inverse_fisher_phi = np.broadcast_to(A.inverse_fisher_phi, (A.mask.shape[0], A.mask.shape[1], 3)).copy()

    # dummy self/feedback funcs that return unit parameter-covector everywhere
    def self_fn(**kwargs):
        H,W,_ = A.phi.shape
        return np.ones((H,W,3), np.float32)
    def fb_fn(**kwargs):
        H,W,_ = A.phi.shape
        return np.ones((H,W,3), np.float32)

    # run with ctx so Jinv/E_grid stubs are used (no heavy exp/Jinv)
    accumulate_phi_morphism_self_feedback(
        A,
        generators_src=None, generators_tgt=None,
        params=params,
        field="phi",
        fisher_inv_key="inverse_fisher_phi",
        grad_key="grad_phi",
        phi_self_func=self_fn,
        phi_feedback_func=fb_fn,
    )

    assert A.grad_phi is not None
    # Expected (per-pixel, per-component): Jinv^T * (alpha*1 + lambda*1) passed through Fisher (2x on first comp) and back Jinv
    # With Jinv=I by stub, we just check relative scaling:
    # comp0 should be 2x larger than comp1/2 due to Fisher^{-1} diag=[2,1,1]
    mean0 = float(np.mean(A.grad_phi[...,0]))
    mean1 = float(np.mean(A.grad_phi[...,1]))
    mean2 = float(np.mean(A.grad_phi[...,2]))
    assert mean0 > mean1 > 0 and abs(mean1 - mean2) < 1e-6
