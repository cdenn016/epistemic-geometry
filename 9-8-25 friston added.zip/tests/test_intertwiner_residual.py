import numpy as np
import pytest

from transport.bundle_morphism_utils import build_intertwiner_bases
# If you added this helper per earlier message; if not, include the fallback below.
try:
    from transport.bundle_morphism_utils import intertwiner_residual
except Exception:
    def intertwiner_residual(Gq: np.ndarray, Gp: np.ndarray, Phi0: np.ndarray) -> float:
        Gq = np.asarray(Gq, np.float64)
        Gp = np.asarray(Gp, np.float64)
        Phi0 = np.asarray(Phi0, np.float64)
        R = 0.0
        for a in range(Gq.shape[0]):
            diff = Gp[a] @ Phi0 - Phi0 @ Gq[a]
            R += np.linalg.norm(diff, ord="fro")
        return float(R)

import numpy as np
import pytest
from core.get_generators import get_generators
from transport.bundle_morphism_utils import (
    build_intertwiner_bases, intertwiner_residual,
    solve_intertwiner_ls, orthogonalize_intertwiner,
)

def _extract_Phi0(out):
    if isinstance(out, np.ndarray) and out.ndim == 2:
        return out
    if isinstance(out, (tuple, list)):
        for v in out:
            if isinstance(v, np.ndarray) and v.ndim == 2: return v
        for v in out:
            if isinstance(v, dict):
                got = _extract_Phi0(v)
                if got is not None: return got
    if isinstance(out, dict):
        for k in ("Phi0","Phi","Phi_q_to_p","base"):
            if k in out and isinstance(out[k], np.ndarray) and out[k].ndim == 2:
                return out[k]
        for v in out.values():
            if isinstance(v, np.ndarray) and v.ndim == 2: return v
    return None

def test_intertwiner_residual_small_on_init(ctx):
    K = 9  # ℓ=4
    Gq = get_generators("so3", K).astype(np.float64)
    Gp = get_generators("so3", K).astype(np.float64)
    # Try your builder first
    out = build_intertwiner_bases(Gq, Gp, method="casimir")
    Phi0 = _extract_Phi0(out)
    if Phi0 is None:
        Phi0 = solve_intertwiner_ls(Gq, Gp)
    R = intertwiner_residual(Gq, Gp, Phi0)

    # Fallback to LS solver if residual is large (Casimir is scalar in irreps)
    if R > 1e-6:
        Phi0 = solve_intertwiner_ls(Gq, Gp)
        Phi0 = orthogonalize_intertwiner(Phi0)
        R = intertwiner_residual(Gq, Gp, Phi0)

    assert R < 1e-8, f"residual too large: {R:.3e}"
