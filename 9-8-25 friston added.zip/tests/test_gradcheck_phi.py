# -*- coding: utf-8 -*-
"""
Created on Mon Sep  1 19:06:49 2025

@author: chris and christine
"""

# tests/test_gradcheck_phi.py
import numpy as np
import diagnostics as diag
from updates.update_terms_phi import accumulate_phi_morphism_self_feedback

# Reuse simple ctx/agent constructors you already used in gradient tests
from tests.test_gradients import Ctx, make_agent  # keep using your known stubs

def _energy_self_plus_feedback(ctx, A):
    s_sum, _, fb_sum, _ = diag._energy_self_feedback(ctx, A)
    return float(s_sum + fb_sum)

def _disable_phi_clipping():
    try:
        import core.config as config
    except ModuleNotFoundError:
        import config
    config.gradient_clip_phi = 1e9
    config.gradient_clip_phi_model = 1e9

def test_gradcheck_phi_self_feedback_central_difference():
    _disable_phi_clipping()

    ctx = Ctx()
    A = make_agent(H=5, W=5, K=3, seed=0)
    A.mask[:] = 1.0
    A.phi[:] = 0.0
    A.phi_model[:] = 0.0

    # choose a pixel & a small random direction
    i, j = 2, 2
    rng = np.random.default_rng(7)
    v = rng.normal(size=(3,)).astype(np.float32)
    v /= np.linalg.norm(v) + 1e-12

    # central difference
    eps = 1e-3
    e0 = _energy_self_plus_feedback(ctx, A)

    A.phi[i, j] += eps * v
    e_plus = _energy_self_plus_feedback(ctx, A)

    A.phi[i, j] -= 2 * eps * v
    e_minus = _energy_self_plus_feedback(ctx, A)

    # restore
    A.phi[i, j] += eps * v

    dE = (e_plus - e_minus) / (2 * eps)

    # analytic gradient via your implementation
    A.grad_phi = None
    params = {
        "alpha": 1.0,             # self weight
        "lambda": 0.0,            # set to >0 if you want feedback included as well
        "beta": 1.0,              # not used here
        "runtime_ctx": ctx,
    }
    accumulate_phi_morphism_self_feedback(
        A,
        generators_src=None, generators_tgt=None,  # identity transports in your stubs
        params=params,
        field="phi",
        fisher_inv_key="inverse_fisher_phi",  # used internally if available
        grad_key="grad_phi",
    )
    g = A.grad_phi[i, j]
    dot = float(np.dot(g, v))

    # some code accumulates +∇E, some −∇E; accept either sign but check magnitude
    rel = abs(abs(dot) - abs(dE)) / max(1.0, abs(dE))
    assert np.isfinite(dot) and np.isfinite(dE)
    assert rel < 1e-2, f"gradcheck failed: <g,v>={dot} vs dE={dE} (rel err {rel})"
