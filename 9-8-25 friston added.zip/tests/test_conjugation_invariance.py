# -*- coding: utf-8 -*-
"""
Created on Wed Sep  3 13:38:20 2025

@author: chris and christine
"""

import numpy as np
import pytest

from transport.transport_cache import plaquette_product as tc_plaquette, E_grid as tc_E
from core.get_generators import get_generators  # or your generator builder

def random_orthogonal(K, seed=0):
    rng = np.random.default_rng(seed)
    Q, _ = np.linalg.qr(rng.standard_normal((K, K)))
    return Q.astype(np.float32)

@pytest.mark.parametrize("spec_q,spec_p", [([1], [2]), ([1,2], [1])])
def test_curvature_invariance_under_conjugation(ctx, tiny_children, spec_q, spec_p):
    children = tiny_children
    # build reducible reps if your API supports it; else just use fixed Gq,Gp from agents
    try:
        Gq = get_generators(spec=spec_q)
        Gp = get_generators(spec=spec_p)
    except Exception:
        Gq = getattr(children[0], "generators_q", None)
        Gp = getattr(children[0], "generators_p", None)

    # Baseline plaquette curvatures
    A0 = children[0]
    P0 = tc_plaquette(ctx, A0.phi_field, np.asarray(Gq,np.float32), boundary="periodic", split_edge=True)
    K = P0.shape[-1]
    I = np.eye(K, dtype=np.float32)
    base = np.linalg.norm(P0 - I, ord="fro", axis=(-2,-1))**2

    # Conjugate representation by random Q and recompute
    Q = random_orthogonal(K, seed=42)
    Gq_rot = np.einsum("ij,ajk,lk->aik", Q, Gq, Q.T, optimize=True).astype(np.float32)
    P1 = tc_plaquette(ctx, A0.phi_field, Gq_rot, boundary="periodic", split_edge=True)
    t1 = np.linalg.norm(P1 - I, ord="fro", axis=(-2,-1))**2

    assert np.allclose(base, t1, rtol=1e-6, atol=1e-8)
