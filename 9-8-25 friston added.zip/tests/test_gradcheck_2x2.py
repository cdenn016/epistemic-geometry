# -*- coding: utf-8 -*-
"""
Created on Wed Sep  3 13:39:39 2025

@author: chris and christine
"""

import numpy as np
import pytest

try:
    from diagnostics import total_energy  # adapt to your aggregator
except Exception:
    total_energy = None

@pytest.mark.skipif(total_energy is None, reason="energy aggregator not available")
def test_gradcheck_small_lattice(ctx, tiny_children):
    # shrink to 2x2 for speed
    for a in tiny_children:
        a.phi_field = a.phi_field[:2,:2].copy()
        a.phi_model_field = a.phi_model_field[:2,:2].copy()
        a.mu_q_field = a.mu_q_field[:2,:2].copy()
        a.mu_p_field = a.mu_p_field[:2,:2].copy()
        a.sigma_q_field = a.sigma_q_field[:2,:2].copy()
        a.sigma_p_field = a.sigma_p_field[:2,:2].copy()
        a.mask = a.mask[:2,:2].copy()

    E0 = total_energy(ctx, tiny_children)   # float
    eps = 1e-4

    # poke φ(0,0) component and compare numerical vs reported grad if available
    a = tiny_children[0]
    a.phi_field[0,0,0] += eps
    E1 = total_energy(ctx, tiny_children)
    num_g = (E1 - E0) / eps
    # If you expose analytic grad, compare here (otherwise just sanity assert finite)
    assert np.isfinite(num_g)
