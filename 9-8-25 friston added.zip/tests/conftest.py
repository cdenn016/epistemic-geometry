import numpy as np
import pytest

from runtime_context import RuntimeCtx, ensure_runtime_defaults
from core.get_generators import get_generators

class DummyAgent:
    """Minimal stand-in for your Agent objects."""
    def __init__(self, id, H, W, Kq, Kp, mask, phi_scale=1e-2):
        self.id = id
        self.level = 0
        self.mask = mask.astype(np.float32)

        # φ fields (axis-angle in ℝ³)
        self.phi        = np.zeros((H, W, 3), dtype=np.float32)
        self.phi_model  = np.zeros((H, W, 3), dtype=np.float32)
        self.phi_field       = self.phi
        self.phi_model_field = self.phi_model

        # μ fields
        self.mu_q_field = np.random.randn(H, W, Kq).astype(np.float32) * phi_scale
        self.mu_p_field = np.random.randn(H, W, Kp).astype(np.float32) * phi_scale

        # Σ fields (SPD by construction)
        Iq = np.eye(Kq, dtype=np.float32)
        Ip = np.eye(Kp, dtype=np.float32)
        self.sigma_q_field = np.broadcast_to(Iq, (H, W, Kq, Kq)).copy()
        self.sigma_p_field = np.broadcast_to(Ip, (H, W, Kp, Kp)).copy()

        # Generators (SO(3) 3D rep + simple embed if dims don’t match)
        
        self.generators_q = get_generators("so3", Kq)
        self.generators_p = get_generators("so3", Kp)

@pytest.fixture
def ctx():
    return ensure_runtime_defaults(RuntimeCtx())

def _rand_mask(H, W, p=0.7, seed=0):
    rng = np.random.default_rng(seed)
    return (rng.random((H, W)) < p).astype(np.float32)

@pytest.fixture
def tiny_children(ctx):
    H, W = 8, 8
    Kq, Kp = 3, 5
    children = []
    for aid in range(4):
        mask = _rand_mask(H, W, p=0.8, seed=aid)
        a = DummyAgent(aid, H, W, Kq, Kp, mask)
        children.append(a)
    # neighbor inference (simple overlap)
    supp = [c.mask > 1e-3 for c in children]
    for i, a in enumerate(children):
        a.neighbors = [{"id": int(children[j].id)} for j in range(len(children))
                       if j != i and np.any(supp[i] & supp[j])]
    ctx.register_agents(0, children)
    return children
