# tests/test_invariants.py
import numpy as np

# --- stubs so diagnostics doesn't require ctx.cache ---
import transport.transport_cache as tc
def _test_Phi(ctx, agent, kind: str = "q_to_p"):
    if kind == "q_to_p":
        M = getattr(agent, "Phi_q_to_p", None)
        if M is not None: return np.asarray(M)
        Kq = agent.mu_q_field.shape[-1]; Kp = agent.mu_p_field.shape[-1]
        return np.eye(Kp, Kq, dtype=np.float32)
    else:
        M = getattr(agent, "Phi_p_to_q", None)
        if M is not None: return np.asarray(M)
        Kq = agent.mu_q_field.shape[-1]; Kp = agent.mu_p_field.shape[-1]
        return np.eye(Kq, Kp, dtype=np.float32)
def _test_Omega(ctx, A, B, which="q"):
    H, W = A.mask.shape
    K = A.mu_q_field.shape[-1] if which == "q" else A.mu_p_field.shape[-1]
    I = np.eye(K, dtype=np.float32)
    return np.broadcast_to(I, (H, W, K, K)).copy()
tc.Phi = _test_Phi
tc.Omega = _test_Omega

import diagnostics as diag

class Ctx:
    def __init__(self, eps=1e-5):
        self.global_step = 0
        self.config = {"energy_eps": eps, "support_cutoff_eps": 1e-6,
                       "alpha": 1.0, "feedback_weight": 1.0,
                       "belief_mass": 0.0, "model_mass": 0.0,
                       "curvature_weight": 0.0, "model_curvature_weight": 0.0,
                       "beta": 0.0, "beta_model": 0.0, "grid_dx": 1.0}

class Agent: pass

def _spd(B, jitter=0.2):
    B = np.asarray(B, float); K = B.shape[-1]
    return np.einsum("...ik,...jk->...ij", B, B) + jitter*np.eye(K)

def _agent(H=6, W=6, K=3):
    A = Agent()
    A.mask = np.ones((H,W))
    A.phi = np.zeros((H,W,3)); A.phi_model = np.zeros_like(A.phi)
    rng = np.random.default_rng(0)
    mu = rng.normal(size=(H,W,K)); B = rng.normal(size=(H,W,K,K))
    S  = _spd(B)
    A.mu_q_field = mu.copy(); A.sigma_q_field = S.copy()
    A.mu_p_field = mu.copy(); A.sigma_p_field = S.copy()
    A.Phi_q_to_p = np.eye(K); A.Phi_p_to_q = np.eye(K)
    return A

def test_identity_self_eq_feedback():
    ctx = Ctx(); A = _agent()
    s_sum, _, fb_sum, _ = diag._energy_self_feedback(ctx, A)
    assert abs(s_sum - fb_sum) < 1e-6

def test_gauge_conjugation_invariance():
    ctx = Ctx(); A = _agent(K=3)
    theta = 0.4
    R = np.array([[np.cos(theta), -np.sin(theta), 0],
                  [np.sin(theta),  np.cos(theta), 0],
                  [0, 0, 1]])
    # rotate fields & morphisms
    A2 = _agent(K=3)
    A2.mask = A.mask.copy()
    A2.mu_q_field = (A.mu_q_field @ R.T); A2.mu_p_field = (A.mu_p_field @ R.T)
    A2.sigma_q_field = R @ A.sigma_q_field @ R.T
    A2.sigma_p_field = R @ A.sigma_p_field @ R.T
    A2.Phi_q_to_p = R @ A.Phi_q_to_p @ np.linalg.inv(R)
    A2.Phi_p_to_q = R @ A.Phi_p_to_q @ np.linalg.inv(R)
    s1,_,fb1,_ = diag._energy_self_feedback(ctx, A)
    s2,_,fb2,_ = diag._energy_self_feedback(ctx, A2)
    assert abs(s1 - s2) < 1e-6 and abs(fb1 - fb2) < 1e-6
