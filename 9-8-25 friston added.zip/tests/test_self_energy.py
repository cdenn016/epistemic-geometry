# tests/test_self_energy.py
import numpy as np

# --- Monkeypatch transport BEFORE importing diagnostics ----------------------
# We stub Phi and Omega so diagnostics doesn't need ctx.cache or the real cache layer.
import transport.transport_cache as tc

def _test_Phi(ctx, agent, kind: str = "q_to_p"):
    # Return the agent-provided morphism if present, else identity with the right shape.
    if kind == "q_to_p":
        M = getattr(agent, "Phi_q_to_p", None)
        if M is not None:
            return np.asarray(M)
        Kq = agent.mu_q_field.shape[-1]
        Kp = agent.mu_p_field.shape[-1]
        return np.eye(Kp, Kq, dtype=np.float32)
    else:  # "p_to_q"
        M = getattr(agent, "Phi_p_to_q", None)
        if M is not None:
            return np.asarray(M)
        Kq = agent.mu_q_field.shape[-1]
        Kp = agent.mu_p_field.shape[-1]
        return np.eye(Kq, Kp, dtype=np.float32)

def _test_Omega(ctx, A, B, which="q"):
    # Identity parallel transport field (H,W,K,K)
    H, W = A.mask.shape
    K = A.mu_q_field.shape[-1] if which == "q" else A.mu_p_field.shape[-1]
    I = np.eye(K, dtype=np.float32)
    return np.broadcast_to(I, (H, W, K, K)).copy()

tc.Phi = _test_Phi
tc.Omega = _test_Omega

# --- Now import diagnostics so it binds to our stubs -------------------------
import diagnostics as diag


# ---------------------- Tiny helpers & fixtures ------------------------------

class Ctx:
    def __init__(self, eps=1e-5):
        self.global_step = 0
        self.config = {
            "energy_eps": eps,
            "support_cutoff_eps": 1e-6,
            "alpha": 1.0,
            "feedback_weight": 1.0,
            "belief_mass": 0.0,
            "model_mass": 0.0,
            "curvature_weight": 0.0,
            "model_curvature_weight": 0.0,
            "beta": 0.0,
            "beta_model": 0.0,
            "grid_dx": 1.0,
        }

class Agent:
    pass

def _spd(B, jitter=0.2):
    # B: (..., K, K) -> S: (..., K, K) (SPD)
    B = np.asarray(B, dtype=np.float64)
    K = B.shape[-1]
    I = np.eye(K, dtype=B.dtype)
    S = np.einsum("...ik,...jk->...ij", B, B) + jitter * I
    return S

def make_agent(H=3, W=3, Kq=2, Kp=None, same=True):
    Kp = Kp or Kq
    A = Agent()
    A.mask = np.ones((H, W), np.float32)
    A.phi = np.zeros((H, W, 3), np.float32)
    A.phi_model = np.zeros((H, W, 3), np.float32)

    rng = np.random.default_rng(0)
    mu_q = rng.normal(size=(H, W, Kq)).astype(np.float32)
    Bq   = rng.normal(size=(H, W, Kq, Kq)).astype(np.float32)
    S_q  = _spd(Bq).astype(np.float32)

    if same:
        mu_p, S_p = mu_q.copy(), S_q.copy()
    else:
        mu_p = rng.normal(size=(H, W, Kp)).astype(np.float32)
        Bp   = rng.normal(size=(H, W, Kp, Kp)).astype(np.float32)
        S_p  = _spd(Bp).astype(np.float32)

    A.mu_q_field, A.sigma_q_field = mu_q, S_q
    A.mu_p_field, A.sigma_p_field = mu_p, S_p

    # Identity morphisms by default (shape-correct)
    A.Phi_q_to_p = np.eye(Kp, Kq, dtype=np.float32)
    A.Phi_p_to_q = np.eye(Kq, Kp, dtype=np.float32)
    return A

# ------------------------------ Tests ----------------------------------------

def test_identity_equal_zero():
    ctx = Ctx()
    A = make_agent(Kq=3, same=True)
    s_sum, s_mean, fb_sum, fb_mean = diag._energy_self_feedback(ctx, A)
    assert s_sum >= 0 and fb_sum >= 0
    # Tiny residual allowed due to SPD jitter; tighten if you reduce energy_eps/jitter
    assert s_sum < 1e-6 and fb_sum < 1e-6

def test_identity_mean_shift_symmetric():
    ctx = Ctx()
    A = make_agent(Kq=2, same=True)
    A.mu_p_field = A.mu_q_field + 0.5
    s_sum, s_mean, fb_sum, fb_mean = diag._energy_self_feedback(ctx, A)
    assert s_sum > 0 and fb_sum > 0
    # With identity morphisms and equal covariances: KL(q||p) == KL(p||q) if only means shift
    assert abs(s_sum - fb_sum) < 1e-6

def test_rotation_finite_positive():
    ctx = Ctx()
    A = make_agent(Kq=2, same=False)
    theta = 0.7
    R = np.array([[np.cos(theta), -np.sin(theta)],
                  [np.sin(theta),  np.cos(theta)]], dtype=np.float32)
    A.Phi_p_to_q = R
    A.Phi_q_to_p = R.T
    s_sum, s_mean, fb_sum, fb_mean = diag._energy_self_feedback(ctx, A)
    assert s_sum > 0 and fb_sum > 0
    assert np.isfinite(s_sum + fb_sum)

def test_per_pixel_morphism_and_mask():
    ctx = Ctx()
    A = make_agent(H=3, W=3, Kq=2, same=False)
    # sparse mask (2 pixels active)
    A.mask[:] = 0.0
    A.mask[0, 0] = 1.0
    A.mask[1, 1] = 1.0
    # per-pixel morphisms for just those 2 pixels
    R0 = np.eye(2, dtype=np.float32)
    R1 = np.array([[0, -1], [1, 0]], dtype=np.float32)
    Mfield_p_to_q = np.zeros((3, 3, 2, 2), np.float32)
    Mfield_q_to_p = np.zeros((3, 3, 2, 2), np.float32)
    Mfield_p_to_q[0, 0] = R0; Mfield_q_to_p[0, 0] = R0.T
    Mfield_p_to_q[1, 1] = R1; Mfield_q_to_p[1, 1] = R1.T
    A.Phi_p_to_q = Mfield_p_to_q
    A.Phi_q_to_p = Mfield_q_to_p

    s_sum, s_mean, fb_sum, fb_mean = diag._energy_self_feedback(ctx, A)
    assert s_sum > 0 and fb_sum > 0
    assert s_mean > 0 and fb_mean > 0
