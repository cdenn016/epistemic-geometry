# tests/test_descent_sanity.py
import math

from generalized_simulation import run_tiny_calibration

def _set_params(params):
    """
    Best-effort config override that works across variants:
    prefer core.config_utils.set_config_from_params, otherwise set attributes
    on core.config directly. Returns a restore function to revert changes.
    """
    restore = {}
    try:
        import core.config as config
        try:
            from core.config_utils import set_config_from_params as setter
        except Exception:
            setter = None

        # snapshot old values
        for k, v in params.items():
            restore[k] = getattr(config, k, None)

        # set new values
        if setter is not None:
            setter(params)
        else:
            for k, v in params.items():
                setattr(config, k, v)

        def undo():
            for k, old in restore.items():
                setattr(config, k, old)
        return undo
    except Exception:
        # No-op fallback
        return lambda: None


def is_monotone_nonincreasing(xs, slack=2):
    """Allow up to `slack` upward blips."""
    ups = sum(b > a for a, b in zip(xs, xs[1:]))
    return ups <= slack


def test_energy_generally_decreases_small_lrs():
    # Choose conservative learning rates; adjust keys to your config names
    params = {
        "tau_phi": 1e-4,
        "tau_phi_model": 1e-4,
        "tau_mu_belief" : 1e-5,
        "tau_sigma_belief": 1e-6,
    }
    undo = _set_params(params)
    try:
        trace = run_tiny_calibration(steps=45, seed=123, H=8)
        # accept multiple possible shapes from run_tiny_calibration
        totals = []
        for x in trace:
            val = (
                x.get("total_energy", None)
                or x.get("E_total", None)
                or x.get("total", None)
                or x.get("mean_total", None)  # last resort; not ideal but keeps test resilient
            )
            if val is None:
                # Fallback: sum any *_sum terms if present
                sum_keys = [k for k in x.keys() if k.endswith("_sum")]
                if sum_keys:
                    val = float(sum(float(x[k]) for k in sum_keys))
            assert val is not None, f"Trace item missing total fields: {x.keys()}"
            totals.append(float(val))


        # finite & nonnegative
        assert all(math.isfinite(t) and t >= 0 for t in totals)

        # crude descent checks
        assert totals[-1] <= 0.9 * totals[0], f"energy didn’t drop enough: {totals[0]} → {totals[-1]}"
        assert is_monotone_nonincreasing(totals, slack=3), f"too many upward steps: {totals}"
    finally:
        undo()
