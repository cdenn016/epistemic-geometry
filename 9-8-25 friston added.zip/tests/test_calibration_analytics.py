# -*- coding: utf-8 -*-
"""
Created on Mon Sep  1 18:11:07 2025

@author: chris and christine
"""

import numpy as np
import diagnostics as diag

class Ctx:
    def __init__(self, eps=1e-5):
        self.global_step = 0
        self.config = {
            "energy_eps": eps,
            "support_cutoff_eps": 1e-6,
            "alpha": 1.0,
            "feedback_weight": 1.0,
            "belief_mass": 0.0,
            "model_mass": 0.0,
            "curvature_weight": 0.0,
            "model_curvature_weight": 0.0,
            "beta": 0.0,
            "beta_model": 0.0,
            "grid_dx": 1.0,
        }

class Agent: pass

def _spd(B, jitter=0.2):
    B = np.asarray(B, dtype=np.float64)
    K = B.shape[-1]
    I = np.eye(K, dtype=B.dtype)
    return np.einsum("...ik,...jk->...ij", B, B) + jitter * I

def _make_agent(H=4, W=4, K=3):
    A = Agent()
    A.mask = np.ones((H,W), np.float32)
    A.phi = np.zeros((H,W,3), np.float32)
    A.phi_model = np.zeros((H,W,3), np.float32)
    rng = np.random.default_rng(0)
    mu  = rng.normal(size=(H,W,K)).astype(np.float32)
    B   = rng.normal(size=(H,W,K,K)).astype(np.float32)
    Sig = _spd(B).astype(np.float32)
    A.mu_q_field = mu.copy()
    A.sigma_q_field = Sig.copy()
    A.mu_p_field = mu.copy()
    A.sigma_p_field = Sig.copy()
    # identity morphisms (shape-correct)
    A.Phi_q_to_p = np.eye(K, K, dtype=np.float32)
    A.Phi_p_to_q = np.eye(K, K, dtype=np.float32)
    return A

def test_mean_shift_closed_form():
    ctx = Ctx()
    A = _make_agent(K=3)
    delta = 0.25
    # μ_p = μ_q + δ; Σ_p == Σ_q
    A.mu_p_field = A.mu_q_field + delta

    s_sum, _, fb_sum, _ = diag._energy_self_feedback(ctx, A)

    # analytic: per pixel KL = 0.5 * δᵀ Σ^{-1} δ  (here δ is a constant vector (delta,...))
    import numpy.linalg as LA
    pred = 0.0
    dvec = np.full(A.mu_q_field.shape[-1], delta, dtype=np.float64)
    for i in range(A.mask.shape[0]):
        for j in range(A.mask.shape[1]):
            invS = LA.inv(A.sigma_q_field[i,j])
            pred += 0.5 * float(dvec @ invS @ dvec)

    # self == feedback for identity M and same covariances
    assert np.isfinite(s_sum) and np.isfinite(fb_sum)
    assert abs(s_sum - pred) <= 0.05 * max(1.0, pred)
    assert abs(fb_sum - pred) <= 0.05 * max(1.0, pred)
    assert abs(s_sum - fb_sum) <= 1e-6

def test_cov_inflation_closed_form():
    ctx = Ctx()
    A = _make_agent(K=5)
    kappa = 2.0
    # μ_p = μ_q; Σ_p = κ Σ_q
    A.mu_p_field = A.mu_q_field.copy()
    A.sigma_p_field = (kappa * A.sigma_q_field)

    s_sum, _, fb_sum, _ = diag._energy_self_feedback(ctx, A)

    # per pixel closed form (μ equal): 0.5*( tr((κΣ)^{-1}Σ) - K + log det(κΣ) - log det(Σ) )
    # = 0.5*( K/κ - K + K*log κ )
    K = A.mu_q_field.shape[-1]
    per_px = 0.5 * (K / kappa - K + K * np.log(kappa))
    pred = per_px * (A.mask > 0.5).sum()

    assert np.isfinite(s_sum)
    assert s_sum > 0
    assert abs(s_sum - pred) <= 0.05 * max(1.0, pred)
    # feedback generally differs when covariances differ (asymmetric)
