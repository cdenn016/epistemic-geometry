
import os, json, pathlib
import numpy as np

from generalized_simulation import run_tiny_calibration






# diagnostics_sanity.py
def assert_energy_canaries(stats: dict, *, step: int, max_growth=100.0, keys=None):
    """
    Cheap guards:
      - all terms finite and >= 0 (KL & masses/curvature),
      - total energy doesn't explode > max_growth× in one step (requires caller to pass prev separately if desired).
    """
    import numpy as np
    keys = keys or [
        "self_sum","feedback_sum","align_q_sum","align_p_sum",
        "mass_q_sum","mass_p_sum","curv_q_sum","curv_p_sum","total_energy"
    ]
    for k in keys:
        v = float(stats.get(k, 0.0))
        if not np.isfinite(v):
            raise FloatingPointError(f"[step {step}] {k} is not finite: {v}")
        if v < -1e-8:
            raise AssertionError(f"[step {step}] {k} < 0: {v}")

def relative_close(a: float, b: float, *, rtol=0.05, atol=1e-6) -> bool:
    a = float(a); b = float(b)
    return abs(a - b) <= max(atol, rtol * max(abs(a), abs(b)))


GOLDEN_PATH = pathlib.Path("tests/golden/tiny_energy.json")
RTOL = float(os.getenv("ENERGY_RTL", "0.05"))  # default 5% tolerance
ATOL = float(os.getenv("ENERGY_ATL", "1e-6"))

def _ensure_golden_exists():
    if GOLDEN_PATH.exists():
        return
    GOLDEN_PATH.parent.mkdir(parents=True, exist_ok=True)
    metrics = run_tiny_calibration(steps=5, seed=123, H=8)
    GOLDEN_PATH.write_text(json.dumps(metrics, indent=2))

def test_tiny_energy_regression():
    """Compare current tiny run to a checked-in golden JSON.
       Set UPDATE_GOLDEN=1 to refresh the golden on purpose."""
    _ensure_golden_exists()

    current = run_tiny_calibration(steps=5, seed=123, H=8)
    golden  = json.loads(GOLDEN_PATH.read_text())

    # Optional: refresh golden intentionally
    if os.getenv("UPDATE_GOLDEN", "0") == "1":
        GOLDEN_PATH.write_text(json.dumps(current, indent=2))
        # still compare to itself to keep structure sanity
        golden = current

    assert len(current) == len(golden), "Step count changed unexpectedly."

    keys = [
        "self_sum","feedback_sum","align_q_sum","align_p_sum",
        "mass_q_sum","mass_p_sum","curv_q_sum","curv_p_sum","total_energy"
    ]
    for i, (cur, ref) in enumerate(zip(current, golden)):
        for k in keys:
            a = float(cur.get(k, 0.0))
            b = float(ref.get(k, 0.0))
            assert relative_close(a, b, rtol=RTOL, atol=ATOL), (
                f"step {i} key {k}: {a} vs {b} (rtol={RTOL}, atol={ATOL})"
            )
