
from __future__ import annotations
import numpy as np
from typing import Dict,Tuple, Optional
from core.omega import exp_lie_algebra_irrep
import core.config as config
from transport.transport_cache import E_grid
from core.numerical_utils import safe_omega_inv

# =============================================================================
#                         Direct (gauge-covariant) morphisms
# =============================================================================

def compute_direct_morphisms(
    *,
    phi: np.ndarray,
    phi_model: np.ndarray,
    generators_q: np.ndarray,
    generators_p: np.ndarray,
    Phi_0: np.ndarray,
    Phi_tilde_0: np.ndarray,
    ctx: Optional[object] = None,
    group_name: Optional[str] = None,
):
    group = (group_name or getattr(config, "group_name", "so3")).lower()
    so3_orth = bool(getattr(config, "so3_irreps_are_orthogonal", True)) and group == "so3"

    phi      = np.asarray(phi,       np.float32)
    phi_model= np.asarray(phi_model, np.float32)
    Gq = np.asarray(generators_q, np.float32)
    Gp = np.asarray(generators_p, np.float32)

    if ctx is not None and getattr(ctx, "cache", None) is not None:
        class _A:
            __slots__=("phi","phi_model","generators_q","generators_p","id")
            def __init__(self, phi, phi_m, Gq, Gp): self.phi=phi; self.phi_model=phi_m; self.generators_q=Gq; self.generators_p=Gp; self.id=id(self)
        Aview = _A(phi, phi_model, Gq, Gp)
        Eq = E_grid(ctx, Aview, which="q").astype(np.float32, copy=False)
        Ep = E_grid(ctx, Aview, which="p").astype(np.float32, copy=False)
    else:
        Eq = exp_lie_algebra_irrep(phi,      Gq).astype(np.float32, copy=False)
        Ep = exp_lie_algebra_irrep(phi_model,Gp).astype(np.float32, copy=False)

    Eq_invT = np.swapaxes(Eq, -1, -2) if so3_orth else safe_omega_inv(Eq).astype(np.float32, copy=False)
    Ep_invT = np.swapaxes(Ep, -1, -2) if so3_orth else safe_omega_inv(Ep).astype(np.float32, copy=False)

    Kq, Kp = int(Eq.shape[-1]), int(Ep.shape[-1])
    
    Phi_0       = np.asarray(Phi_0,       np.float32)
    Phi_tilde_0 = np.asarray(Phi_tilde_0, np.float32)
    
    # with strict shape checks (mirrors your cache builder)
    if Phi_0.shape[-2:] != (Kp, Kq):        raise ValueError("Phi_0 bad shape")
    if Phi_tilde_0.shape[-2:] != (Kq, Kp):  raise ValueError("Phi_tilde_0 bad shape")
    
    if Phi_0.ndim == 2:        Phi_0       = np.broadcast_to(Phi_0,       Ep.shape[:-2] + (Kp, Kq))
    if Phi_tilde_0.ndim == 2:  Phi_tilde_0 = np.broadcast_to(Phi_tilde_0, Eq.shape[:-2] + (Kq, Kp))

    Phi       = np.einsum("...ik,...kj,...jl->...il", Ep, Phi_0,       Eq_invT, optimize=True).astype(np.float32, copy=False)
    Phi_tilde = np.einsum("...ik,...kj,...jl->...il", Eq, Phi_tilde_0, Ep_invT, optimize=True).astype(np.float32, copy=False)
    return Phi, Phi_tilde






def gauge_covariant_transform_phi(
    phi_p: np.ndarray,
    phi_q: np.ndarray,
    Phi0: np.ndarray,
    G_q: np.ndarray,
    G_p: np.ndarray,
    *,
    ctx: Optional[object] = None,
    group_name: str = "so3",
) -> np.ndarray:
    # cached path
    if ctx is not None and getattr(ctx, "cache", None) is not None:
        class _Ap:  # minimal agent views for cache
            __slots__ = ("phi_model","generators_p","id","phi","generators_q")
            def __init__(self, phi_p, Gp): self.phi_model=np.asarray(phi_p,np.float32); self.generators_p=np.asarray(Gp,np.float32); self.id=id(self); self.phi=None; self.generators_q=None
        class _Aq:
            __slots__ = ("phi","generators_q","id","phi_model","generators_p")
            def __init__(self, phi_q, Gq): self.phi=np.asarray(phi_q,np.float32); self.generators_q=np.asarray(Gq,np.float32); self.id=id(self); self.phi_model=None; self.generators_p=None

        A_p = _Ap(phi_p, G_p)
        A_q = _Aq(phi_q, G_q)
        E_p = E_grid(ctx, A_p, which="p")  # (..., Kp, Kp)
        E_q = E_grid(ctx, A_q, which="q")  # (..., Kq, Kq)
    else:
        # fallback (no cache yet during initialization)
        E_p = exp_lie_algebra_irrep(np.asarray(phi_p, np.float32), np.asarray(G_p, np.float32))
        E_q = exp_lie_algebra_irrep(np.asarray(phi_q, np.float32), np.asarray(G_q, np.float32))

    Kp, Kq = int(E_p.shape[-1]), int(E_q.shape[-1])
    Phi0 = np.asarray(Phi0, np.float32)
    if Phi0.shape[-2:] != (Kp, Kq):
        Phi0 = np.eye(Kp, Kq, dtype=E_p.dtype)
    if Phi0.ndim == 2:
        lead = np.broadcast_shapes(E_p.shape[:-2], E_q.shape[:-2])
        Phi0 = np.broadcast_to(Phi0, (*lead, Kp, Kq))

    so3_orth = bool(getattr(config, "so3_irreps_are_orthogonal", True)) and str(group_name).lower() == "so3"
    E_q_inv = np.swapaxes(E_q, -1, -2) if so3_orth else safe_omega_inv(E_q).astype(np.float32, copy=False)

    Phi = np.einsum("...ik,...kj,...jl->...il", E_p, Phi0, E_q_inv, optimize=True)
    return Phi.astype(np.float32, copy=False)


# =============================================================================
#                             Init / Recompute on agent
# =============================================================================



def mark_morphism_dirty(agent, *, ctx=None) -> None:
    """
    Mark Φ/Φ̃ as stale for this agent. We no longer mutate or clear
    per-agent bundle_morphism_* fields; morphisms are derived and cached
    centrally via transport_cache.
    """
    # Delegate if the agent provides its own hook
    if hasattr(agent, "mark_morphism_dirty") and callable(agent.mark_morphism_dirty):
        agent.mark_morphism_dirty()
        return

    # Local flag only; no per-agent tensor mutation
    setattr(agent, "morphisms_dirty", True)

    # Optionally notify runtime so ensure_dirty will prewarm caches soon
    if ctx is not None:
        try:
            # Centralized invalidation path (don’t warm here).
            from updates.update_refresh_utils import mark_dirty  # preferred
        except Exception:
            try:
                from runtime_context import mark_dirty  # fallback if exposed there
            except Exception:
                mark_dirty = None
        if mark_dirty is not None:
            # KL refresh not strictly required just for morphisms,
            # but setting kl=True is safe if your pipeline expects it.
            mark_dirty(ctx, agent, kl=False)





# =============================================================================
#                            Morphism field generators
# =============================================================================

# ===================== Intertwiner Bases Builder (SO(3) reps) =====================

def _rescale_pair_fro(Phi0: np.ndarray, Phit0: np.ndarray, fro_target: float | None) -> tuple[np.ndarray, np.ndarray, float]:
    """
    If fro_target is given, scale Φ0 -> c·Φ0 and Φ̃0 -> (1/c)·Φ̃0 so that ||Φ0||_F == fro_target.
    Returns (Phi0_scaled, Phit0_scaled, c). No-op if fro_target is None or ||Φ0||_F == 0.
    """
    if fro_target is None:
        return Phi0, Phit0, 1.0
    fn = float(np.linalg.norm(Phi0, ord="fro"))
    if fn <= 0.0:
        return Phi0, Phit0, 1.0
    c = float(fro_target) / fn
    return (c * Phi0, (1.0 / max(c, 1e-30)) * Phit0, c)

# --- Safer choice of Φ̃0 from Φ0 (transpose when square & well-conditioned; else pinv) ---
def _choose_tilde_from_base_safe(Phi0: np.ndarray) -> np.ndarray:
    Kp, Kq = Phi0.shape
    if Kp == Kq:
        # condition check via singular values
        s = np.linalg.svd(Phi0, compute_uv=False)
        if s.size and s.min() > 1e-8 and s.max() < 1e8:
            return Phi0.T
    return np.linalg.pinv(Phi0)

# --------------------------- Public Entry Points ---------------------------------
# --- add near the top of the file (e.g., alongside other helpers) ---
def _as_3KK(G: np.ndarray) -> np.ndarray:
    """
    Ensure generator array is (3, K, K).
    Accepts (3,K,K) or (K,K,3); raises for anything else.
    """
    import numpy as np
    G = np.asarray(G, np.float64)
    if G.ndim != 3:
        raise ValueError(f"Generators must be 3D; got {G.shape}")
    # already (3,K,K)
    if G.shape[0] == 3 and G.shape[1] == G.shape[2]:
        return G
    # (K,K,3) -> (3,K,K)
    if G.shape[-1] == 3 and G.shape[0] == G.shape[1]:
        return np.moveaxis(G, -1, 0)
    raise ValueError(f"Unrecognized generator shape {G.shape}; expected (3,K,K) or (K,K,3)")



def build_intertwiner_bases(
    G_q: np.ndarray,
    G_p: np.ndarray,
    *,
    method: str = "casimir",         # "casimir" | "casimir_strict" | "nullspace" | "auto"
    data: Optional[Dict[str, np.ndarray]] = None,
    l_tol: float = 1e-6,
    nullspace_tol: float = 1e-9,
    max_rank: Optional[int] = None,
    return_meta: bool = False,
    on_hom0: str = "zero",           # "zero" | "raise"
) -> Tuple[np.ndarray, np.ndarray, Optional[dict]]:
    """
    Returns (Phi0, Phit0[, meta]) as rectangular intertwiners between two real SO(3) reps.
    Generators may be (3,K,K) or (K,K,3); normalized internally to (3,K,K).
    NEVER fabricates LS 'intertwiners' when Hom=0.
    """
    G_q = _as_3KK(G_q)
    G_p = _as_3KK(G_p)

    method = method.lower()
    if method not in ("casimir", "casimir_strict", "nullspace", "auto"):
        method = "casimir"

    def _hom0_return(Kp: int, Kq: int, *, reason: str):
        meta = {"hom_dim": 0, "matches": [], "reason": reason, "dims": {"Kq": Kq, "Kp": Kp}}
        if on_hom0 == "raise":
            raise ValueError(f"No nonzero intertwiner: {reason} (Kq={Kq}, Kp={Kp})")
        Phi0 = np.zeros((Kp, Kq), dtype=np.float32)
        Phit0 = np.zeros((Kq, Kp), dtype=np.float32)
        return Phi0, Phit0, meta

    Kq = G_q.shape[-1]
    Kp = G_p.shape[-1]

    # 1) Casimir block matching (preferred)
    if method in ("casimir", "casimir_strict", "auto"):
        Phi0, meta = _build_intertwiner_casimir(G_q, G_p, data=data, l_tol=l_tol, max_rank=max_rank)
        if Phi0 is not None:
            Phit0 = _choose_tilde_from_base(Phi0, mode="pinv")
            return (Phi0.astype(np.float32), Phit0.astype(np.float32), meta if return_meta else None)

        # No shared ℓ content: decide by mode
        if method == "casimir_strict":
            return _hom0_return(Kp, Kq, reason="no_shared_ell_casimir")

        # "casimir"/"auto": allow nullspace fallback, but ONLY if exact nullspace exists.
        Phi0_ns, meta_ns = _build_intertwiner_nullspace(G_q, G_p, data=data, tol=nullspace_tol, max_rank=max_rank)
        if meta_ns.get("hom_dim", 0) > 0:
            Phit0_ns = _choose_tilde_from_base_safe(Phi0_ns)
            return (Phi0_ns.astype(np.float32), Phit0_ns.astype(np.float32), meta_ns if return_meta else None)
        # nullspace empty → Hom=0
        return _hom0_return(Kp, Kq, reason="no_shared_ell_and_nullspace_empty")

    # 2) Nullspace mode (exact constraints only)
    if method == "nullspace":
        Phi0_ns, meta_ns = _build_intertwiner_nullspace(G_q, G_p, data=data, tol=nullspace_tol, max_rank=max_rank)
        if meta_ns.get("hom_dim", 0) == 0:
            return _hom0_return(Kp, Kq, reason="nullspace_empty")
        Phit0_ns = _choose_tilde_from_base_safe(Phi0_ns)
        return (Phi0_ns.astype(np.float32), Phit0_ns.astype(np.float32), meta_ns if return_meta else None)


def initialize_intertwiners_for_agent(
    ctx,
    agent,
    G_q: np.ndarray, G_p: np.ndarray,
    *,
    method: str = "casimir",
    data: Optional[Dict[str, np.ndarray]] = None,
    allow_overwrite: bool = False,
) -> Tuple[np.ndarray, np.ndarray]:
    """
    Build (Φ0, Φ̃0) once and freeze them into your persistent cache for this agent.
    Assumes you added the 'allow_overwrite' kwarg to set_morphism_bases(...).
    """
    Phi0, Phit0, _ = build_intertwiner_bases(G_q, G_p, method=method, data=data, return_meta=True)
    # Persist exactly once (unless you explicitly allow overwrite)
    from transport.transport_cache import set_morphism_bases  # adjust import if needed
    set_morphism_bases(ctx, agent, Phi0, Phit0, allow_overwrite=bool(allow_overwrite))
    return Phi0, Phit0


# --------------------------- Casimir (ℓ-block) path -------------------------------

def _build_intertwiner_casimir(G_q, G_p, *, data=None, l_tol=1e-6, max_rank=None):
    G_q = _as_3KK(G_q)
    G_p = _as_3KK(G_p)
    Cq = _casimir_from_generators(G_q); λq, Wq = np.linalg.eigh(Cq)
    Cp = _casimir_from_generators(G_p); λp, Wp = np.linalg.eigh(Cp)

    # NEW: use rel-tol degeneracy clustering (scale-invariant)
    blocks_q = _cluster_into_l_blocks(λq, Wq, rel_tol=1e-4)
    blocks_p = _cluster_into_l_blocks(λp, Wp, rel_tol=1e-4)

    # Match blocks by d (2l+1); don’t rely on absolute λ
    by_dim_q = {}
    for b in blocks_q.values():
        by_dim_q.setdefault(b["d"], []).append(b["W"])
    by_dim_p = {}
    for b in blocks_p.values():
        by_dim_p.setdefault(b["d"], []).append(b["W"])

    common_ds = sorted(set(by_dim_q.keys()).intersection(by_dim_p.keys()))
    if not common_ds:
        return (None, {"reason": "no_l_overlap"})  # will be handled by caller

    Kq = G_q.shape[-1]; Kp = G_p.shape[-1]
    Phi0 = np.zeros((Kp, Kq), dtype=np.float64)
    meta = {"used_dims": [], "rank_by_dim": {}, "path": "casimir"}

    # Optional data-aware mixing on multiplicities can be kept as before.
    for d in common_ds:
        Q_list = by_dim_q[d]   # each (Kq, m_q*d) with orthonormal cols
        P_list = by_dim_p[d]   # each (Kp, m_p*d)
        # concatenate copies -> treat multiplicity collectively
        Wq_d = np.concatenate(Q_list, axis=1)
        Wp_d = np.concatenate(P_list, axis=1)
        # multiplicities
        m_q = Wq_d.shape[1] // d
        m_p = Wp_d.shape[1] // d
        m   = min(m_q, m_p)
        if m == 0:
            continue
        # split into per-copy blocks
        Q_blocks = [Wq_d[:, i*d:(i+1)*d] for i in range(m_q)]
        P_blocks = [Wp_d[:, i*d:(i+1)*d] for i in range(m_p)]
        # identity mixer on multiplicities (orthogonal per copy)
        for i in range(m):
            Phi0 += P_blocks[i] @ Q_blocks[i].T
        meta["used_dims"].append(d)
        meta["rank_by_dim"][d] = m * d

    if max_rank is not None:
        Phi0 = _best_rank_approx(Phi0, rank=max_rank)

    return (Phi0, meta)


# ------------------------------ Nullspace path -----------------------------------

def _build_intertwiner_nullspace(G_q: np.ndarray, G_p: np.ndarray, *, tol: float = 1e-9,
                                 data: Optional[Dict[str, np.ndarray]] = None,
                                 max_rank: Optional[int] = None) -> Tuple[np.ndarray, dict]:
    G_q = _as_3KK(G_q)
    G_p = _as_3KK(G_p)
    Kq, Kp = G_q.shape[-1], G_p.shape[-1]
    Iq = np.eye(Kq); Ip = np.eye(Kp)
    rows = []
    for a in range(3):
        A = np.kron(Iq, G_p[a]) - np.kron(G_q[a].T, Ip)
        rows.append(A)
    M = np.concatenate(rows, axis=0)

    # Nullspace via SVD
    U, S, Vh = np.linalg.svd(M, full_matrices=False)
    mask = (S <= tol)
    if not np.any(mask):
        # numerically tiny but nonzero; take the smallest singular vector
        basis = Vh[-1:, :]
    else:
        basis = Vh[mask, :]        # (m, Kp*Kq)
    # Orthonormalize nullspace basis vectors (Frobenius) via QR
    Q, _ = np.linalg.qr(basis.T)   # (Kp*Kq, m) -> Q has orthonormal columns
    B = Q                          # (Kp*Kq, m_eff)

    # Default: pick the first basis vector -> simplest nonzero intertwiner
    coeff = np.zeros((B.shape[1],), dtype=np.float64)
    coeff[0] = 1.0

    # Data-aware LS in span(B): minimize Σ ||Φ0 μ_q - μ_p||_2^2
    if data is not None:
        mu_q = np.asarray(data.get("mu_q", None))
        mu_p = np.asarray(data.get("mu_p", None))
        if mu_q is not None and mu_q.size and mu_p is not None and mu_p.size:
            Qs = _thin_samples(mu_q.reshape(-1, mu_q.shape[-1]), max_samples=4096)  # (N, Kq)
            Ps = _thin_samples(mu_p.reshape(-1, mu_p.shape[-1]), max_samples=4096)  # (N, Kp)
            # Build design matrix A * coeff ≈ b, with A = [ (Bi mat) @ Qs^T ] stacked
            # We solve per-sample in Kp, so do least squares per output dim jointly:
            # vec(Φ0) = B @ coeff  =>  Φ0 = reshape(B@coeff, (Kp, Kq))
            # We choose coeff that minimizes ||Φ0 Qs^T - Ps^T||_F^2
            # This is linear in coeff:
            # Let Zi = reshape(B[:,i], Kp,Kq) @ Qs^T  -> (Kp,N)
            # Stack Zi along i to get (Kp*N, m), target vec(Ps^T) = vec(Ps.T)
            Z_blocks = []
            for i in range(B.shape[1]):
                Zi = (B[:, i].reshape(Kp, Kq) @ Qs.T)  # (Kp, N)
                Z_blocks.append(Zi.reshape(-1, 1))     # (Kp*N, 1)
            A_ls = np.concatenate(Z_blocks, axis=1)    # (Kp*N, m)
            b_ls = Ps.T.reshape(-1)                    # (Kp*N,)
            # regularized least squares to avoid degeneracy
            reg = 1e-8
            coeff, *_ = np.linalg.lstsq(A_ls.T @ A_ls + reg*np.eye(A_ls.shape[1]), A_ls.T @ b_ls, rcond=None)

    vecPhi = (B @ coeff).reshape(Kp, Kq)
    Phi0 = vecPhi
    if max_rank is not None:
        Phi0 = _best_rank_approx(Phi0, rank=max_rank)

    meta = {"nullspace_dim": B.shape[1]}
    return (Phi0, meta)


# ------------------------------ Internal Helpers ---------------------------------



def solve_intertwiner_ls(Gq: np.ndarray, Gp: np.ndarray, rtol: float = 1e-9) -> np.ndarray:
    """
    Solve for Phi0 (Kp x Kq) s.t. Gp[a] Phi0 = Phi0 Gq[a] for a=0,1,2 in least-squares sense.
    Returns a nonzero vector in the nullspace (unique up to scalar for irreducible/equivalent reps).
    """
    Gq = np.asarray(Gq, np.float64)  # (3, Kq, Kq)
    Gp = np.asarray(Gp, np.float64)  # (3, Kp, Kp)
    d, Kq, Kq2 = Gq.shape
    dp, Kp, Kp2 = Gp.shape
    assert d == 3 and dp == 3 and Kq == Kq2 and Kp == Kp2, "bad generator shapes"

    # Build A v = 0 with v = vec(Phi0), A stacks constraints for a in {0,1,2}
    # vec(Gp Phi - Phi Gq) = (I⊗Gp - Gq^T⊗I) vec(Phi)
    Iq = np.eye(Kq, dtype=np.float64)
    Ip = np.eye(Kp, dtype=np.float64)
    rows = []
    for a in range(3):
        Aa = np.kron(Ip, Gp[a]) - np.kron(Gq[a].T, Iq)  # (Kp*Kq, Kp*Kq)
        rows.append(Aa)
    A = np.vstack(rows)  # (3*Kp*Kq, Kp*Kq)

    # Nullspace via SVD
    U, S, Vt = np.linalg.svd(A, full_matrices=False)
    # Take smallest singular vector
    v = Vt[-1, :]
    Phi0 = v.reshape(Kp, Kq)

    # Normalize to avoid trivial zero scaling
    n = np.linalg.norm(Phi0)
    if n > 0:
        Phi0 /= n
    return Phi0

def orthogonalize_intertwiner(Phi0: np.ndarray) -> np.ndarray:
    """
    If Phi0 is square, project to the nearest orthogonal matrix via polar decomposition.
    For rectangular maps, returns Phi0 unchanged.
    """
    Kp, Kq = Phi0.shape
    if Kp != Kq:
        return Phi0
    U, _, Vt = np.linalg.svd(Phi0, full_matrices=False)
    return (U @ Vt).astype(Phi0.dtype, copy=False)

def intertwiner_residual(Gq: np.ndarray, Gp: np.ndarray, Phi0: np.ndarray) -> float:
    """
    R = sum_a || Gp[a] Phi0 - Phi0 Gq[a] ||_F
    """
    Gq = np.asarray(Gq, np.float64)
    Gp = np.asarray(Gp, np.float64)
    Phi0 = np.asarray(Phi0, np.float64)
    R = 0.0
    for a in range(3):
        R += np.linalg.norm(Gp[a] @ Phi0 - Phi0 @ Gq[a], ord="fro")
    return float(R)



def _casimir_from_generators(G: np.ndarray) -> np.ndarray:
    """Casimir C = Gx^2 + Gy^2 + Gz^2 for a real rep."""
    C = np.zeros((G.shape[-1], G.shape[-1]), dtype=np.float64)
    for a in range(3):
        C += G[a] @ G[a]
    return 0.5 * (C + C.T)  # enforce symmetry numerically


def _cluster_into_l_blocks(λ: np.ndarray, W: np.ndarray, rel_tol: float = 1e-4):
    """
    Scale-invariant clustering of Casimir eigenpairs by degeneracy.
    Groups consecutive eigenvalues whose relative gap ≤ rel_tol.
    For each cluster of size g, pick d = largest odd divisor of g;
    set multiplicity m = g // d and split the cluster into m blocks of size d.
    Returns dict: l -> {"W": (K, m*d), "d": d, "m": m}
    """
    K = W.shape[0]
    # sort by eigenvalue
    idx = np.argsort(λ)
    λs  = λ[idx]
    Ws  = W[:, idx]

    # cluster by relative tolerance
    clusters = []
    start = 0
    for i in range(1, len(λs) + 1):
        if i == len(λs):
            clusters.append((start, i))
            break
        # relative gap
        denom = max(abs(λs[i-1]), abs(λs[i]), 1.0)
        if abs(λs[i] - λs[i-1]) > rel_tol * denom:
            clusters.append((start, i))
            start = i

    blocks = {}
    # helper: largest odd divisor
    def largest_odd_divisor(n: int) -> int:
        while n % 2 == 0 and n > 0:
            n //= 2
        return max(1, n)

    l_counter = 0
    for (lo, hi) in clusters:
        g = hi - lo                     # cluster size
        if g <= 0:
            continue
        d = largest_odd_divisor(g)      # irrep dim = 2l+1 (odd)
        m = g // d
        if d <= 0 or m <= 0:
            continue
        # take this cluster’s eigenvectors
        Wc = Ws[:, lo:hi]               # (K, g)
        # split into m blocks of size d
        keep = Wc[:, : m*d]             # truncate if any tiny overhang
        l_val = (d - 1) // 2
        blocks[l_counter] = {"W": keep, "d": d, "m": m, "ell": l_val}
        l_counter += 1

    return blocks


def _thin_samples(X: np.ndarray, max_samples: int = 4096) -> np.ndarray:
    """Uniformly sub-sample rows to at most max_samples."""
    N = X.shape[0]
    if N <= max_samples:
        return X
    idx = np.linspace(0, N-1, num=max_samples, dtype=int)
    return X[idx]



def _choose_tilde_from_base(Phi0: np.ndarray, mode: str = "pinv") -> np.ndarray:
    """Pick Φ̃0 given Φ0. For partial isometries, pinv and transpose are both reasonable; pinv is robust."""
    if mode == "transpose":
        return Phi0.T
    # default: pseudoinverse (handles rectangular / rank-deficient cleanly)
    return np.linalg.pinv(Phi0)


def _best_rank_approx(M: np.ndarray, rank: int) -> np.ndarray:
    """Best Frobenius-norm rank-k approximation via SVD."""
    U, S, Vt = np.linalg.svd(M, full_matrices=False)
    k = min(rank, len(S))
    return (U[:, :k] * S[:k]) @ Vt[:k, :]






# =========================== End Intertwiner Builder ==============================


