# -*- coding: utf-8 -*-
"""
Created on Mon Sep  8 17:40:08 2025

@author: chris and christine
"""

# updates/update_terms_vfe.py
from __future__ import annotations
import numpy as np
from runtime_context import ensure_theta




def accumulate_theta_from_vfe(ctx, agents, params):
    # drop this near the top of each file that needs it
    import core.config as _cfg
    def CFG(params, key, default=None):
        return (params or {}).get(key, getattr(_cfg, key, default))

    
    
    if not (CFG(params, "enable_vfe", True) and CFG(params, "enable_vfe_theta", True)):
        return None
    # Derive D_obs robustly (prefer actual y, else fall back)
    a0 = agents[0]
    if getattr(a0, "observation_field", None) is not None:
        D_obs = int(a0.observation_field.shape[-1])
    else:
        D_obs = int(CFG(params, "obs_dim", a0.mu_q_field.shape[-1]))
    theta = ensure_theta(ctx, D_obs=D_obs, K_latent=a0.mu_q_field.shape[-1])
    W, b, sigma2 = theta.W, theta.b, theta.sigma2

    dW = np.zeros_like(W)
    db = np.zeros_like(b)
    dS = 0.0

    for A in agents:
        y = A.observation_field
        mu = A.mu_q_field
        S  = A.sigma_q_field
        m  = A.mask
        _dW, _db, _dS = vfe_theta_grads(y, mu, S, W, b, sigma2, mask=m)
        dW += _dW
        db += _db
        dS += _dS

    w = float(CFG(params, "vfe_weight", 1.0))
    return (w * dW, w * db, w * dS)




def expected_nll_gaussian(y, mu, Sigma, W, b, sigma2, *, mask=None):
    """
    E_q[-log p(y|x)] for y|x ~ N(Wx + b, sigma2 I)
    Shapes:
      y: (..., D), mu: (..., K), Sigma: (..., K, K)
      W: (D, K), b: (D,), sigma2: scalar
    Returns scalar total and tuple of per-location pieces if needed.
    """
    y = np.asarray(y, np.float32)
    mu = np.asarray(mu, np.float32)
    Sigma = np.asarray(Sigma, np.float32)
    W = np.asarray(W, np.float32)
    b = np.asarray(b, np.float32)
    sigma2 = float(sigma2)

    D = y.shape[-1]
    r = (mu @ W.T) + b - y             # (..., D)
    r2 = np.sum(r * r, axis=-1)        # (...)
    # tr(W Σ W^T) = tr(Σ W^T W)
    WT_W = W.T @ W                      # (K, K)
    tr_term = np.einsum("...ij,ij->...", Sigma, WT_W, optimize=True)  # (...)

    const = 0.5 * D * np.log(2.0 * np.pi * sigma2)
    quad  = 0.5 * (r2 + tr_term) / max(sigma2, 1e-12)
    nll = const + quad                  # (...)

    if mask is not None:
        nll = nll * np.asarray(mask, np.float32)

    total = float(np.sum(nll))
    return total, (r, WT_W, r2, tr_term)




def vfe_mu_sigma_grads(y, mu, Sigma, W, b, sigma2, *, mask=None,
                       sigma2_min: float = 1e-6,
                       grad_mu_clip: float | None = 5.0,
                       grad_S_clip: float | None = 5.0):
    """
    Robust Euclidean grads wrt mu, Sigma for E_q[-log p(y|x)], y|x ~ N(Wx+b, sigma2 I).
    - Sanitizes inputs
    - Applies mask BEFORE any multiplies (avoid NaN*0 issues)
    - Floors sigma2
    - Optional per-pixel gradient clipping
    """
    import numpy as np

    y     = np.nan_to_num(np.asarray(y,     np.float32), copy=False)
    mu    = np.nan_to_num(np.asarray(mu,    np.float32), copy=False)
    Sigma = np.nan_to_num(np.asarray(Sigma, np.float32), copy=False)
    W     = np.nan_to_num(np.asarray(W,     np.float32), copy=False)
    b     = np.nan_to_num(np.asarray(b,     np.float32), copy=False)

    sigma2 = float(max(sigma2, sigma2_min))
    inv_s2 = 1.0 / sigma2

    # Build masks with correct shapes
    if mask is None:
        m1 = 1.0
        m2 = 1.0
    else:
        m  = np.asarray(mask, np.float32)
        m1 = m[..., None]          # (...,1)
        m2 = m[..., None, None]    # (...,1,1)

    # Compute residual and gate by mask FIRST to avoid NaN propagation
    r = (mu @ W.T) + b - y         # (..., D)
    r = np.where(m1.astype(bool), r, 0.0)

    # grads
    WT  = W.T                      # (K, D)
    g_mu = inv_s2 * (WT @ r[..., None]).squeeze(-1)       # (..., K)
    WT_W = WT @ W                                         # (K, K)
    g_S  = 0.5 * inv_s2 * WT_W                            # (K, K), same for all pts
    g_S  = np.broadcast_to(g_S, Sigma.shape)

    # gate g_S by mask (AFTER broadcast)
    g_mu = g_mu * m1
    g_S  = g_S  * m2

    # symmetrize Σ-grad
    g_S = 0.5 * (g_S + np.swapaxes(g_S, -1, -2))

    # Optional per-pixel clipping (stable start-up)
    if grad_mu_clip is not None and grad_mu_clip > 0:
        n = np.linalg.norm(g_mu, axis=-1, keepdims=True)
        s = np.minimum(1.0, grad_mu_clip / (n + 1e-9))
        g_mu = g_mu * s
    if grad_S_clip is not None and grad_S_clip > 0:
        # clip Frobenius per pixel
        gSf = g_S.reshape(*g_S.shape[:-2], -1)
        n = np.linalg.norm(gSf, axis=-1, keepdims=True)
        s = np.minimum(1.0, grad_S_clip / (n + 1e-9))
        g_S = (gSf * s).reshape(g_S.shape)

    # Final sanitize
    
    return g_mu, g_S





def vfe_theta_grads(y, mu, Sigma, W, b, sigma2, *, mask=None):
    """
    Euclidean grads wrt theta = {W, b, sigma2}.
    Returns (dW, db, d_sigma2) aggregated (sum) over batch/pixels/agents.
    """
    y = np.asarray(y, np.float32)
    mu = np.asarray(mu, np.float32)
    Sigma = np.asarray(Sigma, np.float32)
    W = np.asarray(W, np.float32)
    b = np.asarray(b, np.float32)
    sigma2 = float(sigma2)

    inv_s2 = 1.0 / max(sigma2, 1e-12)
    r = (mu @ W.T) + b - y                         # (..., D)

    # dW: sum over examples of (r mu^T + W Σ)
    # shape handling:
    dW = np.einsum("...d,...k->dk", r, mu, optimize=True)          # (D,K)
    # add sum over Σ term:
    # sum_over_batch( W Σ ) = W * sum_over_batch(Σ) along appropriate dims
    Sigma_sum = np.sum(Sigma, axis=tuple(range(Sigma.ndim-2)))     # (K,K)
    dW += W @ Sigma_sum
    dW *= inv_s2

    # db: sum r
    db = np.sum(r, axis=tuple(range(r.ndim-1))) * inv_s2            # (D,)

    # d sigma2:
    D = y.shape[-1]
    r2 = np.sum(r*r, axis=-1)                                       # (...)
    WT_W = W.T @ W                                                  # (K,K)
    tr_term = np.einsum("...ij,ij->...", Sigma, WT_W, optimize=True)  # (...)
    num = np.sum(r2 + tr_term)                                      # scalar
    N  = r2.size                                                    # count of examples
    d_sigma2 = 0.5 * ( num / (sigma2**2 * max(sigma2, 1e-12)) - (D * N) / sigma2 )

    if mask is not None:
        m = np.asarray(mask, np.float32)
        # Recompute with masking to be precise:
        dW = np.einsum("...d,...k->dk", r*m[...,None], mu, optimize=True)
        Sigma_sum = np.sum(Sigma * m[...,None,None], axis=tuple(range(Sigma.ndim-2)))
        dW += W @ Sigma_sum
        dW *= inv_s2

        db = np.sum(r*m[...,None], axis=tuple(range(r.ndim-1))) * inv_s2

        r2m = np.sum((r*r) * m[...,None], axis=-1)
        trm = np.einsum("...ij,ij->...", Sigma*m[...,None,None], WT_W, optimize=True)
        num = float(np.sum(r2m + trm))
        N   = int(np.sum(m))
        d_sigma2 = 0.5 * ( num / (sigma2**2 * max(sigma2, 1e-12)) - (D * N) / sigma2 )

    return dW.astype(np.float32), db.astype(np.float32), float(d_sigma2)
