# -*- coding: utf-8 -*-
"""
Created on Wed Aug  6 12:27:32 2025

@author: chris and christine
"""

# --- imports (top of file) ---
import numpy as np
import core.config as config
from core.numerical_utils import sanitize_sigma, safe_batch_inverse
from core.natural_gradient import apply_natural_gradient_batch
from transport.transport_cache import Omega, Phi
from core.gaussian_core import push_gaussian

from updates.update_helpers import (_exact_align_transport, _fiber_keys, _phi_mats, 
                            _pull_agent_fields, _push_both_fibers, _recover_like, _symmetrize_S,
                            _weights, _zero_like )
# -------------------------------------------------------------------------
#                          PUBLIC ENTRYPOINTS
# -------------------------------------------------------------------------

# ----------------------------- helpers.py -----------------------------
# drop this near the top of each file that needs it



# ----------------------------- main API -----------------------------
def accumulate_mu_sigma_gradient(agent_i, agents, params, mode,
                                 *, strict_numerics: bool = True,
                                 recover: str | None = None):
    """
    Accumulate natural gradient ∇μ and ∇Σ for belief or model using cache-owned Φ, Φ̃, Ω.
    Pair counted once (i_id < j_id); exact covariance transport for alignment.
    Uses a single beta per fiber:
       - belief: params.beta
       - model : params.beta_model

    PATCH: Adds optional accuracy term E_q[-log p_theta(y|x)] for beliefs when
           params.enable_vfe is True. Requires:
             - agent_i.observation_field  (shape (..., D_obs))
             - updates.update_terms_vfe.vfe_mu_sigma_grads(...)
             - runtime_context.ensure_theta(ctx, D_obs, K_latent)
           If any of the above are missing, this block safely no-ops.
    """
    import core.config as _cfg
    def CFG(params, key, default=None):
        return (params or {}).get(key, getattr(_cfg, key, default))
    
    ctx = params.get("runtime_ctx", None)
    if ctx is None:
        if strict_numerics:
            raise RuntimeError("accumulate_mu_sigma_gradient: ctx required.")
        # graceful fallback
        if mode == "belief":
            return _zero_like(agent_i.mu_q_field, agent_i.sigma_q_field)
        elif mode == "model":
            return _zero_like(agent_i.mu_p_field, agent_i.sigma_p_field)
        else:
            raise ValueError(f"Unsupported mode: {mode}")

    PRINT_SIGN  = bool(params.get("DEBUG_MU_SIG", False))
    eps         = float(getattr(config, "eps", 1e-8))
    support_eps = float(getattr(config, "support_cutoff_eps", 1e-4))

    # weights, fiber keys, fields
    alpha, beta_like, lambd = _weights(mode, params)
    fiber, mu_key, sigma_key = _fiber_keys(mode)
    mu_q, S_q = agent_i.mu_q_field, agent_i.sigma_q_field
    mu_p, S_p = agent_i.mu_p_field, agent_i.sigma_p_field

    # cache-owned transforms
    Phi_mat, Phi_tilde_mat = _phi_mats(ctx, agent_i)

    # pushes
    (mu_q_push, S_q_push, inv_q_push), (mu_p_push, S_p_push, inv_p_push) = _push_both_fibers(
        mu_q, S_q, mu_p, S_p, Phi_mat, Phi_tilde_mat, eps
    )

    # self + feedback grads (Euclidean)
    g_self_mu, g_self_S, g_fb_mu, g_fb_S = _self_and_feedback_grads(
        mode,
        mu_q, S_q, mu_p, S_p,
        mu_q_push, S_q_push, inv_q_push,
        mu_p_push, S_p_push, inv_p_push,
        Phi_mat, Phi_tilde_mat, eps
    )

    # alignment (neighbors) — accumulate j-side natural grads inside helper
    mask_i = (np.asarray(agent_i.mask) > support_eps)
    dmu_align, dS_align = _zero_like(getattr(agent_i, mu_key), getattr(agent_i, sigma_key))

    nb_list = getattr(agent_i, "neighbors", []) or []
    if nb_list and beta_like != 0.0:
        i_id = int(getattr(agent_i, "id", -1))
        for nb in nb_list:
            j = int(nb["id"])
            agent_j = agents[j]
            j_id = int(getattr(agent_j, "id", j))

            if not (i_id < j_id):
                continue  # undirected pair counted once

            mask_j = (np.asarray(agent_j.mask) > support_eps)
            overlap = mask_i & mask_j
            if not np.any(overlap):
                continue

            add_mu_i, add_S_i = _accum_align_for_pair(
                ctx, agent_i, agent_j,
                fiber=fiber, mu_key=mu_key, sigma_key=sigma_key,
                overlap_mask=overlap, beta_like=beta_like,
                strict_numerics=strict_numerics, recover=recover, eps=eps
            )
            dmu_align[overlap] += add_mu_i[overlap]
            dS_align[overlap]  += add_S_i[overlap]

    # -------- NEW: accuracy term (belief only) --------
    # Adds Euclidean grads from E_q[-log p_theta(y|x)], if enabled and available.
    g_vfe_mu = None
    g_vfe_S  = None
    if (
        mode == "belief"
        and bool(CFG(params, "enable_vfe", False))
        and bool(CFG(params, "enable_vfe_mu_sigma", True))
    ):
        y = getattr(agent_i, "observation_field", None)
        
        if y is not None:
            try:
                # Lazy imports to avoid hard dependency if file isn't added yet
                from updates.update_terms_VFE import vfe_mu_sigma_grads
                from runtime_context import ensure_theta
                # initialize/access global theta (W, b, sigma2)
                K_latent = int(mu_q.shape[-1])
                D_obs    = int(np.asarray(y).shape[-1])
                theta = ensure_theta(ctx, D_obs=D_obs, K_latent=K_latent)
                
                w_vfe = float(CFG(params, "vfe_weight", 1.0))

                # Euclidean grads of accuracy term
                g_vfe_mu, g_vfe_S = vfe_mu_sigma_grads(
                    y=np.asarray(y, np.float32),
                    mu=np.asarray(mu_q, np.float32),
                    Sigma=np.asarray(S_q, np.float32),
                    W=np.asarray(theta.W, np.float32),
                    b=np.asarray(theta.b, np.float32),
                    sigma2=float(theta.sigma2),
                    mask=np.asarray(agent_i.mask, np.float32)
                )
                
            except Exception:
                print("FAIL\n\n\n\n\n")
                g_vfe_mu, g_vfe_S = None, None

    # total Euclidean grads for agent_i
    dmu_total = alpha * g_self_mu    + lambd * g_fb_mu    + dmu_align
    dS_total  = alpha * g_self_S     + lambd * g_fb_S     + dS_align

    # inject accuracy grads if computed
    if g_vfe_mu is not None and g_vfe_S is not None:
        w_vfe = float(params.get("vfe_weight", 1.0))
        dmu_total = dmu_total + w_vfe * g_vfe_mu
        dS_total  = dS_total  + w_vfe * g_vfe_S

    dS_total  = _symmetrize_S(dS_total)

    # finite checks / recovery
    if strict_numerics:
        if not (np.all(np.isfinite(dmu_total)) and np.all(np.isfinite(dS_total))):
            raise FloatingPointError("accumulate_mu_sigma_gradient: nonfinite dμ/dΣ.")
    else:
        if not np.all(np.isfinite(dmu_total)): dmu_total = _recover_like(dmu_total, recover)
        if not np.all(np.isfinite(dS_total)):  dS_total  = _recover_like(dS_total,  recover)

    # optional Σ-entropy reg (belief only). NOTE:
    # If you also include KL(q || Φ̃ p) as complexity, that already contains -H[q].
    # Keep entropy_weight = 0 to avoid double-counting unless intentionally temperature-tuning.
    if mode == "belief":
        dS_total = accumulate_entropy_sigma_gradient(agent_i, dS_total, params)

    # project to natural gradient for agent_i
    delta_mu, delta_S = apply_natural_gradient_batch(
        getattr(agent_i, mu_key), getattr(agent_i, sigma_key),
        dmu_total.astype(np.float32, copy=False),
        dS_total.astype(np.float32,  copy=False),
        mask=agent_i.mask,
        strict_numerics=strict_numerics,
        recover=(recover if not strict_numerics else None),
    )

    # accumulate into agent_i.*grad_*
    if fiber == "q":
        gmu_attr, gsig_attr = "grad_mu_q", "grad_sigma_q"
    else:
        gmu_attr, gsig_attr = "grad_mu_p", "grad_sigma_p"

    if getattr(agent_i, gmu_attr, None) is None:
        setattr(agent_i, gmu_attr,  np.zeros_like(getattr(agent_i, mu_key),    dtype=np.float32))
    if getattr(agent_i, gsig_attr, None) is None:
        setattr(agent_i, gsig_attr, np.zeros_like(getattr(agent_i, sigma_key), dtype=np.float32))

    setattr(agent_i, gmu_attr,  getattr(agent_i, gmu_attr)  + delta_mu)
    setattr(agent_i, gsig_attr, getattr(agent_i, gsig_attr) + delta_S)

    # minimal optional logging
    if PRINT_SIGN:
        aid = getattr(agent_i, "id", "?")
        ax = tuple(range(delta_mu.ndim - 1))
        mu_mean = np.mean(delta_mu, axis=ax)
        S_tr = np.mean(np.trace(delta_S, axis1=-2, axis2=-1), axis=ax)
        def sgns(vec): return "".join("+" if v>0 else "-" if v<0 else "0" for v in vec.tolist())
        print(f"[MU/SIG] mode={mode} ai={aid} "
              f"μ_sign={sgns(mu_mean)} μ_mean={np.array2string(mu_mean, precision=3, suppress_small=True)} "
              f"|μ|_mean={float(np.mean(np.abs(delta_mu))):.3e} "
              f"|Σ|_F_mean={float(np.mean(np.linalg.norm(delta_S.reshape(*delta_S.shape[:-2], -1), axis=-1))):.3e} "
              f"tr(ΔΣ)_mean={float(S_tr):.3e}",
              flush=True)

    return delta_mu, delta_S





def _self_and_feedback_grads(mode: str,
                             mu_q, sigma_q, mu_p, sigma_p,
                             mu_q_push, Sigma_q_push, inv_q_push,
                             mu_p_push, Sigma_p_push, inv_p_push,
                             Phi_mat, Phi_tilde_mat, eps: float):
    """
    Compute self/feedback grads for the chosen mode.
    """
    if mode == "belief":
        # belief self-energy uses p pushed into q-fiber
        g_self_mu, g_self_S = grad_self_energy_belief(
            mu_q, sigma_q, mu_p_push, inv_p_push, eps=eps
        )
        g_fb_mu, g_fb_S = grad_feedback_energy_belief(
            mu_q, sigma_q, mu_p, mu_q_push, Sigma_q_push, inv_q_push, sigma_p, Phi_mat, eps=eps
        )
    elif mode == "model":
        # model self-energy uses p in its own fiber against Φ̃·q
        g_self_mu, g_self_S = grad_self_energy_model(
            mu_q, sigma_q, mu_p_push, inv_p_push, Phi_tilde_mat, eps=eps
        )
        g_fb_mu, g_fb_S = grad_feedback_energy_model(
            mu_p, sigma_p, mu_q_push, Sigma_q_push, inv_q_push, Phi_mat, eps=eps
        )
    else:
        raise ValueError(f"Unsupported mode: {mode}")
    return g_self_mu, g_self_S, g_fb_mu, g_fb_S


def _accum_align_for_pair(ctx, agent_i, agent_j,
                          fiber: str, mu_key: str, sigma_key: str,
                          overlap_mask: np.ndarray, beta_like: float,
                          *, strict_numerics: bool, recover: str | None, eps: float):
    """
    Compute alignment contributions for pair (i,j),
    add natural-grad deltas into agent_j.*grad_*,
    and return the Euclidean contributions for agent_i on the overlap.
    """
    if beta_like == 0.0 or not np.any(overlap_mask):
        # nothing to do
        return 0.0, 0.0

    Omega_ij = Omega(ctx, agent_i, agent_j, which=fiber)
    mu_i,  S_i  = _pull_agent_fields(agent_i, mu_key, sigma_key)
    mu_j,  S_j  = _pull_agent_fields(agent_j, mu_key, sigma_key)

    mu_j_t, S_j_t, inv_j_t = _exact_align_transport(mu_j, S_j, Omega_ij, eps)

    # i-side grads (source frame)
    gμ_i, gΣ_i = grad_alignment_energy_source(mu_i, S_i, mu_j_t, inv_j_t, eps=eps)

    # j-side grads (target frame; must be accumulated as natural-grad deltas on j)
    gμ_j, gΣ_j = grad_alignment_energy_target(mu_i, S_i, mu_j_t, inv_j_t, Omega_ij, eps=eps)

    add_mu_j    = np.zeros_like(mu_j, dtype=np.float32)
    add_sigma_j = np.zeros_like(S_j,  dtype=np.float32)
    add_mu_j[overlap_mask]    = (beta_like * gμ_j)[overlap_mask]
    add_sigma_j[overlap_mask] = (beta_like * gΣ_j)[overlap_mask]

    dmu_j_nat, dS_j_nat = apply_natural_gradient_batch(
        mu_j, S_j, add_mu_j, add_sigma_j,
        mask=getattr(agent_j, "mask", None),
        strict_numerics=strict_numerics, recover=(recover if not strict_numerics else None),
    )

    # Accumulate into agent_j.*grad_* in-place
    if fiber == "q":
        gmu_attr, gsig_attr = "grad_mu_q", "grad_sigma_q"
    else:
        gmu_attr, gsig_attr = "grad_mu_p", "grad_sigma_p"

    if getattr(agent_j, gmu_attr, None) is None:
        setattr(agent_j, gmu_attr,  np.zeros_like(mu_j, dtype=np.float32))
    if getattr(agent_j, gsig_attr, None) is None:
        setattr(agent_j, gsig_attr, np.zeros_like(S_j, dtype=np.float32))

    setattr(agent_j, gmu_attr,  getattr(agent_j, gmu_attr)  + dmu_j_nat)
    setattr(agent_j, gsig_attr, getattr(agent_j, gsig_attr) + dS_j_nat)

    # Return Euclidean contrib for i (to be added by caller on overlap)
    return (beta_like * gμ_i), (beta_like * gΣ_i)








def accumulate_entropy_sigma_gradient(agent_i, grad_sigma_q, params):
    """
    Add entropy regularization to the Σ-gradient.

    Convention (default):
        E_total = E_other - gamma * H[q]
      ⇒ ∇_Σ E_total = ∇_Σ E_other - gamma * ∇_Σ H
      ⇒ with ∇_Σ H = ½ Σ^{-1}

    You can override the sign via params["entropy_in_energy_sign"] ∈ {+1, -1}.
    Use +1 if energy includes +gamma * H (penalty),
    use -1 if it includes -gamma * H (reward; default).
    """
    

    gamma = float(params.get("entropy_weight", getattr(config, "entropy_weight", 0.0)))
    if gamma == 0.0:
        return grad_sigma_q

    s = int(params.get("entropy_in_energy_sign", -1))
    sigma_q = sanitize_sigma(np.asarray(agent_i.sigma_q_field, dtype=np.float32), strict=True)
    grad_H  = 0.5 * safe_batch_inverse(sigma_q)

    mask = (np.asarray(agent_i.mask) > float(getattr(config, "support_cutoff_eps", 0.0)))[..., None, None]
    grad_H = grad_H * mask

    out = grad_sigma_q + gamma * s * grad_H
    out = 0.5 * (out + np.swapaxes(out, -1, -2))
    return out.astype(np.float32, copy=False)





#==============================================================================
#
#                    FEEDBACK / SELF TERMS (unchanged math, safer numerics)
#==============================================================================

def grad_alignment_energy_source(mu_i, sigma_i, mu_j_t, sigma_j_t_inv, eps=1e-8):
    delta_mu = mu_i - mu_j_t
    grad_mu = np.einsum("...ij,...j->...i", sigma_j_t_inv, delta_mu, optimize=True)

    # sanitize once per call
    sigma_i = sanitize_sigma(np.asarray(sigma_i, dtype=np.float32), strict=True)
    sigma_i_inv = safe_batch_inverse(sigma_i)

    grad_sigma = 0.5 * (sigma_j_t_inv - sigma_i_inv)
    grad_sigma = 0.5 * (grad_sigma + np.swapaxes(grad_sigma, -1, -2))
    return grad_mu.astype(np.float32, copy=False), grad_sigma.astype(np.float32, copy=False)

def grad_alignment_energy_target(
    mu_i,
    sigma_i,
    mu_j_t,           # = Ω_ij @ mu_j            (transported target mean)
    sigma_j_t_inv,    # = (Ω_ij Σ_j Ω_ij^T)^{-1} (transported target precision)
    Omega_ij,         # transport matrix Ω_ij
    eps: float = 1e-8,
):
    """
    Exact Euclidean gradients of KL(N(mu_i, sigma_i) || N(mu_j', Sigma_j')) wrt *j*'s params,
    mapped back to j's frame via Ω_ij^T.  (Here mu_j' = Ω_ij mu_j, Sigma_j' = Ω_ij Σ_j Ω_ij^T.)

    Returns:
        grad_mu_j   (..., K)
        grad_sigma_j(..., K, K)  [symmetric]
    """
    # --- delta in i-frame ---
    mu_i    = np.asarray(mu_i,    dtype=np.float32)
    mu_j_t  = np.asarray(mu_j_t,  dtype=np.float32)
    dmu     = mu_i - mu_j_t                      # (..., K)

    # --- sanitize inputs we multiply with ---
    Omega_ij      = np.asarray(Omega_ij,      dtype=np.float32)
    sigma_j_t_inv = np.asarray(sigma_j_t_inv, dtype=np.float32)
    sigma_j_t_inv = np.nan_to_num(sigma_j_t_inv, nan=0.0, posinf=0.0, neginf=0.0)

    # Σ_i only enters the Σ_j-gradient; sanitize once
    sigma_i = sanitize_sigma(np.asarray(sigma_i, dtype=np.float32), strict=True)

    # ---------- μ_j gradient ----------
    # ∂_{μ_j'} KL = - Σ_j'^{-1} (μ_i - μ_j')  ;  map back: ∂_{μ_j} = Ω_ij^T ∂_{μ_j'}
    gmu_jp = -np.einsum("...ij,...j->...i", sigma_j_t_inv, dmu, optimize=True)
    grad_mu_j = np.einsum("...ji,...j->...i", Omega_ij, gmu_jp, optimize=True)
    grad_mu_j = grad_mu_j.astype(np.float32, copy=False)

    # ---------- Σ_j gradient ----------
    # ∂_{Σ_j'} KL = 1/2 [ -S'^-1 Σ_i S'^-1 - S'^-1 dμ dμ^T S'^-1 + S'^-1 ]
    t0 = -np.einsum("...ij,...jk,...kl->...il", sigma_j_t_inv, sigma_i, sigma_j_t_inv, optimize=True)
    t1 = -np.einsum("...ij,...j,...k,...kl->...il", sigma_j_t_inv, dmu, dmu, sigma_j_t_inv, optimize=True)
    t2 =  sigma_j_t_inv
    gSigma_jp = 0.5 * (t0 + t1 + t2)

    # map back: ∂_{Σ_j} = Ω_ij^T (∂_{Σ_j'}) Ω_ij
    grad_sigma_j = np.einsum("...ji,...jk,...kl->...il",
                             Omega_ij, gSigma_jp, np.swapaxes(Omega_ij, -1, -2), optimize=True)
    # symmetrize + scrub (just in case)
    grad_sigma_j = 0.5 * (grad_sigma_j + np.swapaxes(grad_sigma_j, -1, -2))
    grad_sigma_j = np.nan_to_num(grad_sigma_j, nan=0.0, posinf=0.0, neginf=0.0).astype(np.float32, copy=False)

    return grad_mu_j, grad_sigma_j


def grad_feedback_energy_belief(mu_q, sigma_q, mu_p, mu_q_push,
                                sigma_q_push, sigma_q_push_inv, sigma_p, Phi, eps=1e-8):
    delta_mu = mu_p - mu_q_push
    tmp = np.einsum("...ij,...j->...i", sigma_q_push_inv, delta_mu, optimize=True)
    grad_mu = -np.einsum("...ji,...j->...i", Phi, tmp, optimize=True)

    A = np.einsum("...i,...j->...ij", delta_mu, delta_mu, optimize=True)

    term1 = sigma_q_push_inv
    term2 = np.einsum("...ik,...kl,...lj->...ij", sigma_q_push_inv, A,       sigma_q_push_inv, optimize=True)
    term3 = np.einsum("...ik,...kl,...lj->...ij", sigma_q_push_inv, sigma_p, sigma_q_push_inv, optimize=True)
    M = term1 - term2 - term3

    grad_sigma = 0.5 * np.einsum("...ki,...kl,...lj->...ij", Phi, M, Phi, optimize=True)
    grad_sigma = 0.5 * (grad_sigma + np.swapaxes(grad_sigma, -1, -2))
    return grad_mu.astype(np.float32, copy=False), grad_sigma.astype(np.float32, copy=False)


def grad_feedback_energy_model(mu_p, sigma_p, mu_q_push,
                               sigma_q_push, sigma_q_push_inv, Phi=None, eps=1e-8):
    
    sigma_q_push = sanitize_sigma(np.asarray(sigma_q_push, dtype=np.float32), strict=True)
    if sigma_q_push_inv is None:
        sigma_q_push_inv = safe_batch_inverse(sigma_q_push)

    delta_mu = mu_p - mu_q_push
    grad_mu = np.einsum("...ij,...j->...i", sigma_q_push_inv, delta_mu, optimize=True)

    sigma_p = sanitize_sigma(np.asarray(sigma_p, dtype=np.float32), strict=True)
    sigma_p_inv = safe_batch_inverse(sigma_p)

    grad_sigma = 0.5 * (sigma_q_push_inv - sigma_p_inv)
    grad_sigma = 0.5 * (grad_sigma + np.swapaxes(grad_sigma, -1, -2))
    return grad_mu.astype(np.float32, copy=False), grad_sigma.astype(np.float32, copy=False)


def grad_self_energy_belief(mu_q, sigma_q, mu_p_push, sigma_p_push_inv, eps=1e-8, mask=None):
    delta_mu = mu_q - mu_p_push
    grad_mu = np.einsum("...ij,...j->...i", sigma_p_push_inv, delta_mu, optimize=True)

    sigma_q = sanitize_sigma(np.asarray(sigma_q, dtype=np.float32), strict=True)
    sigma_q_inv = safe_batch_inverse(sigma_q)

    grad_sigma = 0.5 * (sigma_p_push_inv - sigma_q_inv)
    grad_sigma = 0.5 * (grad_sigma + np.swapaxes(grad_sigma, -1, -2))

    if mask is not None:
        m = (np.asarray(mask) > float(getattr(config, "support_cutoff_eps", 0.0)))
        grad_mu    = grad_mu * m[..., None]
        grad_sigma = grad_sigma * m[..., None, None]

    return grad_mu.astype(np.float32, copy=False), grad_sigma.astype(np.float32, copy=False)


def grad_self_energy_model(mu_q, sigma_q, mu_p_push, sigma_p_push_inv, Phi_tilde, eps=1e-8, mask=None):
    """
    ∂ wrt (μ_p, Σ_p) of KL(q || Φ̃·p), with A = Φ̃ Σ_p Φ̃ᵀ and Δ = μ_q − μ_p^t.
    """
    delta_mu = mu_q - mu_p_push
    tmp = np.einsum("...ij,...j->...i", sigma_p_push_inv, delta_mu, optimize=True)
    grad_mu = -np.einsum("...ji,...j->...i", Phi_tilde, tmp, optimize=True)

    delta_mu_outer = np.einsum("...i,...j->...ij", delta_mu, delta_mu, optimize=True)

    M = sigma_p_push_inv
    G = M - np.einsum("...ik,...kl,...lj->...ij", M, delta_mu_outer, M, optimize=True) \
          - np.einsum("...ik,...kl,...lj->...ij", M, sigma_q,        M, optimize=True)

    Phi_tilde_T = np.swapaxes(Phi_tilde, -1, -2)
    grad_sigma = 0.5 * np.einsum("...ki,...ij,...jl->...kl", Phi_tilde_T, G, Phi_tilde, optimize=True)
    grad_sigma = 0.5 * (grad_sigma + np.swapaxes(grad_sigma, -1, -2))  # symmetrize

    if mask is not None:
        m = (np.asarray(mask) > float(getattr(config, "support_cutoff_eps", 0.0)))
        grad_mu    = grad_mu * m[..., None]
        grad_sigma = grad_sigma * m[..., None, None]

    return grad_mu.astype(np.float32, copy=False), grad_sigma.astype(np.float32, copy=False)




def OLDaccumulate_mu_sigma_gradient(agent_i, agents, params, mode,
                                 *, strict_numerics: bool = True,
                                 recover: str | None = None):  # None | "nan" | "zero"
    """
    Accumulate natural gradient ∇μ and ∇Σ for belief or model using cache-owned Φ, Φ̃, Ω.
    No globals() fallbacks; requires ctx and transport_cache.{Phi, Omega}.
    """
  
    

    PRINT_SIGN = bool(params.get("DEBUG_MU_SIG", False))
    ctx = params.get("runtime_ctx", None)
    if ctx is None:
        if strict_numerics:
            raise RuntimeError("accumulate_mu_sigma_gradient: ctx required (cache-centric Φ/Ω).")
        # graceful recovery (no ctx): return zeros shaped like the active fiber
        if mode == "belief":
            return _zero_like(agent_i.mu_q_field, agent_i.sigma_q_field)
        elif mode == "model":
            return _zero_like(agent_i.mu_p_field, agent_i.sigma_p_field)
        else:
            raise ValueError(f"Unsupported mode: {mode}")

    eps         = float(getattr(config, "eps", 1e-8))
    support_eps = float(getattr(config, "support_cutoff_eps", 1e-4))

    # -------- select fields/weights by mode --------
    if mode == "belief":
        alpha  = float(params.get("alpha",           getattr(config, "alpha",           1.0)))
        beta   = float(params.get("beta",            getattr(config, "beta",            0.0)))
        lambd  = float(params.get("feedback_weight", getattr(config, "feedback_weight", 0.0)))

        mu_q,  sigma_q  = agent_i.mu_q_field, agent_i.sigma_q_field
        mu_p,  sigma_p  = agent_i.mu_p_field, agent_i.sigma_p_field

        # Φ, Φ̃ from cache
        Phi_mat       = Phi(ctx, agent_i, kind="q_to_p")
        Phi_tilde_mat = Phi(ctx, agent_i, kind="p_to_q")

        # push via Φ̃ and Φ
        mu_p_push, sigma_p_push, sigma_p_push_inv = push_gaussian(
            mu=mu_p, Sigma=sigma_p, M=Phi_tilde_mat, eps=eps,
            symmetrize=True, sanitize=True,
            approx="auto" if getattr(config, "use_first_order_sigma_push", True) else "exact",
            near_identity_tau=float(getattr(config, "lambda_near_identity_tau", 5e-2)),
            return_inv=True,
        )
        mu_q_push, sigma_q_push, sigma_q_push_inv = push_gaussian(
            mu=mu_q, Sigma=sigma_q, M=Phi_mat, eps=eps,
            symmetrize=True, sanitize=True,
            approx="auto" if getattr(config, "use_first_order_sigma_push", True) else "exact",
            near_identity_tau=float(getattr(config, "lambda_near_identity_tau", 5e-2)),
            return_inv=True,
        )

        grad_self_mu, grad_self_sigma = grad_self_energy_belief(
            mu_q, sigma_q, mu_p_push, sigma_p_push_inv, eps=eps
        )
        grad_fb_mu, grad_fb_sigma = grad_feedback_energy_belief(
            mu_q, sigma_q, mu_p, mu_q_push, sigma_q_push, sigma_q_push_inv, sigma_p, Phi_mat, eps=eps
        )

        fiber      = "q"
        mu_key     = "mu_q_field"
        sigma_key  = "sigma_q_field"

    elif mode == "model":
        alpha  = float(params.get("alpha",           getattr(config, "alpha",           1.0)))
        beta   = float(params.get("beta_model",      getattr(config, "beta_model",      0.0)))
        lambd  = float(params.get("feedback_weight", getattr(config, "feedback_weight", 0.0)))

        mu_p,  sigma_p  = agent_i.mu_p_field, agent_i.sigma_p_field
        mu_q,  sigma_q  = agent_i.mu_q_field, agent_i.sigma_q_field

        # Φ, Φ̃ from cache
        Phi_mat       = Phi(ctx, agent_i, kind="q_to_p")
        Phi_tilde_mat = Phi(ctx, agent_i, kind="p_to_q")

        mu_p_push, sigma_p_push, sigma_p_push_inv = push_gaussian(
            mu=mu_p, Sigma=sigma_p, M=Phi_tilde_mat, eps=eps,
            symmetrize=True, sanitize=True,
            approx="auto" if getattr(config, "use_first_order_sigma_push", True) else "exact",
            near_identity_tau=float(getattr(config, "lambda_near_identity_tau", 5e-2)),
            return_inv=True,
        )
        mu_q_push, sigma_q_push, sigma_q_push_inv = push_gaussian(
            mu=mu_q, Sigma=sigma_q, M=Phi_mat, eps=eps,
            symmetrize=True, sanitize=True,
            approx="auto" if getattr(config, "use_first_order_sigma_push", True) else "exact",
            near_identity_tau=float(getattr(config, "lambda_near_identity_tau", 5e-2)),
            return_inv=True,
        )

        grad_self_mu, grad_self_sigma = grad_self_energy_model(
            mu_q, sigma_q, mu_p_push, sigma_p_push_inv, Phi_tilde_mat, eps=eps
        )
        grad_fb_mu, grad_fb_sigma = grad_feedback_energy_model(
            mu_p, sigma_p, mu_q_push, sigma_q_push, sigma_q_push_inv, Phi_mat, eps=eps
        )

        fiber      = "p"
        mu_key     = "mu_p_field"
        sigma_key  = "sigma_p_field"

    else:
        raise ValueError(f"Unsupported mode: {mode}")

    mask_i = (np.asarray(agent_i.mask) > support_eps)

    # ---------------- neighbor alignment (Ω from cache) ----------------
    dmu_align    = np.zeros_like(getattr(agent_i, mu_key),    dtype=np.float32)
    dsigma_align = np.zeros_like(getattr(agent_i, sigma_key), dtype=np.float32)

    nb_list = getattr(agent_i, "neighbors", []) or []
    if nb_list:
        for nb in nb_list:
            j = nb["id"]
            agent_j = agents[j]
            mask_j = (np.asarray(agent_j.mask) > support_eps)
            overlap = mask_i & mask_j
            if not np.any(overlap):
                continue

            Omega_ij = Omega(ctx, agent_i, agent_j, which=fiber)

            mu_j    = getattr(agent_j, mu_key)
            sigma_j = getattr(agent_j, sigma_key)
            mu_j_t, sigma_j_t, sigma_j_t_inv = push_gaussian(
                mu=mu_j, Sigma=sigma_j, M=Omega_ij, eps=eps,
                symmetrize=True, sanitize=True,
                approx="auto" if getattr(config, "use_first_order_sigma_push", True) else "exact",
                near_identity_tau=float(getattr(config, "lambda_near_identity_tau", 5e-2)),
                return_inv=True,
            )

            mu_i    = getattr(agent_i, mu_key)
            sigma_i = getattr(agent_i, sigma_key)

            dmu_i, dsigma_i = grad_alignment_energy_source(
                mu_i, sigma_i, mu_j_t, sigma_j_t_inv, eps=eps
            )

            dmu_align[overlap]    += dmu_i[overlap]
            dsigma_align[overlap] += dsigma_i[overlap]

    # ---------------- total Euclidean grads ----------------
    dmu_total    = (alpha * grad_self_mu    + lambd * grad_fb_mu    + beta * dmu_align)
    dsigma_total = (alpha * grad_self_sigma + lambd * grad_fb_sigma + beta * dsigma_align)

    # Σ symmetry (no masking)
    dsigma_total = 0.5 * (dsigma_total + np.swapaxes(dsigma_total, -1, -2))

    # Final finite checks on Euclidean grads
    if strict_numerics:
        if not (np.all(np.isfinite(dmu_total)) and np.all(np.isfinite(dsigma_total))):
            raise FloatingPointError("accumulate_mu_sigma_gradient: nonfinite dμ/dΣ.")
    else:
        if not np.all(np.isfinite(dmu_total)):
            dmu_total = _recover_like(dmu_total, recover)
        if not np.all(np.isfinite(dsigma_total)):
            dsigma_total = _recover_like(dsigma_total, recover)

    # --- (belief) entropy regularizer on Σ (after checks)
    if mode == "belief":
        dsigma_total = accumulate_entropy_sigma_gradient(agent_i, dsigma_total, params)

    # --------------- project to natural gradient ---------------
    delta_mu, delta_sigma = apply_natural_gradient_batch(
        getattr(agent_i, mu_key),
        getattr(agent_i, sigma_key),
        dmu_total.astype(np.float32, copy=False),
        dsigma_total.astype(np.float32, copy=False),
        mask=agent_i.mask,
        strict_numerics=strict_numerics,
        recover=(recover if not strict_numerics else None),
    )

    # --------------- accumulate ----------------
    if mode == "belief":
        grad_mu_attr, grad_sigma_attr = "grad_mu_q", "grad_sigma_q"
    else:
        grad_mu_attr, grad_sigma_attr = "grad_mu_p", "grad_sigma_p"

    if getattr(agent_i, grad_mu_attr, None) is None:
        setattr(agent_i, grad_mu_attr, np.zeros_like(getattr(agent_i, mu_key), dtype=np.float32))
    if getattr(agent_i, grad_sigma_attr, None) is None:
        setattr(agent_i, grad_sigma_attr, np.zeros_like(getattr(agent_i, sigma_key), dtype=np.float32))

    setattr(agent_i, grad_mu_attr,    getattr(agent_i, grad_mu_attr)    + delta_mu)
    setattr(agent_i, grad_sigma_attr, getattr(agent_i, grad_sigma_attr) + delta_sigma)

    # --------------- minimal validation print ----------------
    if PRINT_SIGN:
        aid = getattr(agent_i, "id", "?")
        ax = tuple(range(delta_mu.ndim - 1))
        mu_mean = np.mean(delta_mu, axis=ax)
        S = delta_sigma
        S_tr = np.mean(np.trace(S, axis1=-2, axis2=-1), axis=ax)
        def sgns(vec): return "".join("+" if v>0 else "-" if v<0 else "0" for v in vec.tolist())
        print(f"[MU/SIG] mode={mode} ai={aid} "
              f"μ_sign={sgns(mu_mean)} μ_mean={np.array2string(mu_mean, precision=3, suppress_small=True)} "
              f"|μ|_mean={float(np.mean(np.abs(delta_mu))):.3e} "
              f"|Σ|_F_mean={float(np.mean(np.linalg.norm(S.reshape(*S.shape[:-2], -1), axis=-1))):.3e} "
              f"tr(ΣΔ)_mean={float(S_tr):.3e}",
              flush=True)

    return delta_mu, delta_sigma  # <- return deltas (useful for tests)






