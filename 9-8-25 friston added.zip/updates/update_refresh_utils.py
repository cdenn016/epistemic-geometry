# -*- coding: utf-8 -*-
from __future__ import annotations

import numpy as np
from transport.preprocess_utils import preprocess_all_agents, ensure_transforms

from transport.transport_cache import warm_E, warm_Jinv
from core.omega import pre_retract_fields

# ----------------------------
# Single-scale SO3-core utils:
#   - No spawn/detection/parents/coarse-graining
#   - No KL/spawn alignment caches
#   - Keep ensure_dirty(), mark_dirty(), take_dirty(), refresh_agents_light()
# ----------------------------

def ensure_dirty(ctx, generators_q, generators_p, params, scope="all"):
    """
    Refresh transforms for dirty items; pre-warm central caches; clear flags; bump cache version.
    Policy:
      - Ensure φ/φ̃ transforms + shape-correct Φ/Φ̃ exist (idempotent)
      - Pre-warm E and Jinv in CacheHub (lazy facades)
      - Bump cache version once if anything changed
    """
    
    try:
        from transport.transport_cache import Phi as tc_Phi
    except Exception:
        tc_Phi = None

    # Collect dirty targets
    targets = []
    if scope in ("all", "children"):
        targets += take_dirty(ctx, getattr(ctx, "children_latest", []), which="agents")
    targets = [t for t in targets if t is not None]
    if not targets:
        return targets

    pre_retract_fields(targets)

    did_any = False

    # 1) Ensure transforms (generators & morphism bases; idempotent)
    try:
        method = (params or {}).get("intertwiner_method", "casimir")
        data   = (params or {}).get("data_for_alignment", None)
        ensure_transforms(
            targets,
            generators_q=generators_q,
            generators_p=generators_p,
            ctx=ctx,
            intertwiner_method=method,
            data_for_alignment=data,
        )
        did_any = True
    except Exception as e:
        print(f"[ensure_dirty] ensure_transforms failed: {e}")

    # 2) Pre-warm E and Jinv; morphisms if available
    try:
        warm_E(ctx, targets, whiches=("q", "p"))
        warm_Jinv(ctx, targets, whiches=("q", "p"))
        if tc_Phi is not None:
            for a in targets:
                try:
                    _ = tc_Phi(ctx, a, kind="q_to_p")
                    _ = tc_Phi(ctx, a, kind="p_to_q")
                except Exception:
                    aid = getattr(a, "id", None)
                    print(f"[ensure_dirty] Phi prewarm failed for agent id={aid}")
        did_any = True
    except Exception as e:
        print(f"[ensure_dirty] cache prewarm failed: {e}")

    # 3) Clear agent-side flags (we do not store Φ/Φ̃ on agents)
    for a in targets:
        if hasattr(a, "morphisms_dirty"):
            a.morphisms_dirty = False

    # 4) Bump cache version (invalidates any stale derived caches in the future)
    if did_any:
        try:
            bump_cache(ctx, 1)
        except Exception:
            pass

    return targets


# --- Dirty-set management ----------------------------------------------------

def _ensure_dirty_sets(ctx):
    d = getattr(ctx, "dirty", None)
    if d is None:
        class _D: pass
        d = _D()
        d.agents = set()
        d.kl = set()
        setattr(ctx, "dirty", d)
    else:
        if not hasattr(d, "agents"): d.agents = set()
        if not hasattr(d, "kl"):     d.kl = set()
    return d


def mark_dirty(ctx, *agents, kl=False):
    """Mark agents as needing refresh; optionally mark their KL dirty too (harmless in SO3-core)."""
    d = _ensure_dirty_sets(ctx)
    for a in agents:
        if a is None:
            continue
        aid = int(getattr(a, "id", id(a)))
        d.agents.add(aid)
        if kl:
            d.kl.add(aid)
        setattr(a, "_dirty_fields", True)
        if kl:
            setattr(a, "_dirty_kl", True)


def take_dirty(ctx, all_agents, *, which="agents"):
    """
    Pop and return objects whose ids are marked dirty.
    which ∈ {"agents","kl"}.
    """
    d = _ensure_dirty_sets(ctx)
    ids = d.agents if which == "agents" else d.kl

    if not ids:
        subset = []
    else:
        wanted = {int(i) for i in ids}
        subset = []
        for a in all_agents:
            try:
                aid = int(getattr(a, "id", id(a)))
                if aid in wanted:
                    subset.append(a)
            except Exception:
                continue
    ids.clear()
    return subset


# --- Light agent refresh -----------------------------------------------------

def refresh_agents_light(agents, params, Gq, Gp, *, ctx=None):
    """
    Light refresh: sanitize (soft), warm exp grids into ctx.cache,
    standardize mask shapes. Single-scale only.
    """
    if not agents:
        return
    pre = dict(params)
    pre["sanitize_strict"] = pre.get("sanitize_strict_pre", False)
    pre["exp_n_jobs"] = 1

    preprocess_all_agents(agents, pre, Gq, Gp, ctx=ctx)

    H, W = np.asarray(agents[0].mask).shape[:2]
    _standardize_all_masks_once(agents, (H, W))


def _standardize_all_masks_once(all_agents, HW):
    # Local mask size normalization without parent utilities
    H, W = HW
    for a in all_agents:
        if not hasattr(a, "mask"):
            continue
        m = getattr(a, "mask", None)
        if m is None:
            continue
        mm = np.asarray(m, np.float32)
        if mm.shape[:2] == (H, W):
            setattr(a, "mask", mm)
            continue
        # Basic resize by padding/cropping to match HW (periodic-safe is a TODO if needed)
        hh, ww = mm.shape[:2]
        out = np.zeros((H, W), dtype=np.float32)
        h = min(H, hh); w = min(W, ww)
        out[:h, :w] = mm[:h, :w]
        setattr(a, "mask", out)


# --- Stubs kept for compatibility (no-ops in SO3-core) ----------------------



def list_nonnull(xs):
    return [x for x in (xs or []) if x is not None]

def bump_cache(ctx, n: int = 1) -> None:
    """Monotonic counter to invalidate derived caches in future extensions."""
    setattr(ctx, "cache_version", int(getattr(ctx, "cache_version", 0)) + int(n))
