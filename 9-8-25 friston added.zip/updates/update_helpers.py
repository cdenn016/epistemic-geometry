# -*- coding: utf-8 -*-
"""
Created on Mon Sep  8 16:26:26 2025

@author: chris and christine
"""
import core.config as config
import numpy as np
from transport.transport_cache import Phi
from core.gaussian_core import push_gaussian



def _weights(mode: str, params) -> tuple[float, float, float]:
    """
    Return (alpha, beta_like, lambda) where:
      - mode == "belief": beta_like := params.beta
      - mode == "model" : beta_like := params.beta_model
    """
    alpha = float(params.get("alpha",           getattr(config, "alpha",           1.0)))
    lambd = float(params.get("feedback_weight", getattr(config, "feedback_weight", 0.0)))
    if mode == "belief":
        beta_like = float(params.get("beta",       getattr(config, "beta",       0.0)))
    elif mode == "model":
        beta_like = float(params.get("beta_model", getattr(config, "beta_model", 0.0)))
    else:
        raise ValueError(f"Unsupported mode: {mode}")
    return alpha, beta_like, lambd


def _fiber_keys(mode: str) -> tuple[str, str, str]:
    """
    Returns (fiber_tag, mu_attr, sigma_attr) for given mode.
    """
    if mode == "belief":
        return "q", "mu_q_field", "sigma_q_field"
    elif mode == "model":
        return "p", "mu_p_field", "sigma_p_field"
    else:
        raise ValueError(f"Unsupported mode: {mode}")


def _pull_agent_fields(agent_i, mu_key: str, sigma_key: str):
    return getattr(agent_i, mu_key), getattr(agent_i, sigma_key)


def _phi_mats(ctx, agent_i):
    # cache-owned matrices
    Phi_mat       = Phi(ctx, agent_i, kind="q_to_p")
    Phi_tilde_mat = Phi(ctx, agent_i, kind="p_to_q")
    return Phi_mat, Phi_tilde_mat


def _push_both_fibers(mu_q, sigma_q, mu_p, sigma_p, Phi_mat, Phi_tilde_mat, eps: float):
    """
    Push q via Φ and p via Φ̃. Uses near-identity 'auto' (configurable) for general pushes.
    Returns:
      (mu_q_push, Sigma_q_push, inv_q_push),
      (mu_p_push, Sigma_p_push, inv_p_push)
    """
    approx_kind = "auto" if getattr(config, "use_first_order_sigma_push", True) else "exact"
    tau = float(getattr(config, "lambda_near_identity_tau", 5e-2))

    mu_q_push, Sigma_q_push, inv_q_push = push_gaussian(
        mu=mu_q, Sigma=sigma_q, M=Phi_mat, eps=eps,
        symmetrize=True, sanitize=True, approx=approx_kind,
        near_identity_tau=tau, return_inv=True,
    )
    mu_p_push, Sigma_p_push, inv_p_push = push_gaussian(
        mu=mu_p, Sigma=sigma_p, M=Phi_tilde_mat, eps=eps,
        symmetrize=True, sanitize=True, approx=approx_kind,
        near_identity_tau=tau, return_inv=True,
    )
    return (mu_q_push, Sigma_q_push, inv_q_push), (mu_p_push, Sigma_p_push, inv_p_push)



# update_helpers.py  (patch)
def stack_Q_all_before_KK(Q_all, K_expected: int | None = None, d: int | None = None) -> np.ndarray:
    if isinstance(Q_all, (list, tuple)):
        if len(Q_all) == 0:
            raise ValueError("stack_Q_all_before_KK: empty Q_all list/tuple.")
        sample = np.asarray(Q_all[0])
        if sample.ndim < 2:
            raise ValueError(f"stack_Q_all_before_KK: sample must be at least 2D, got {sample.shape}")
        Q = np.stack([np.asarray(x) for x in Q_all], axis=sample.ndim - 2)  # (..., a, K, K)
    else:
        Q = np.asarray(Q_all)

    if Q.ndim < 3:
        raise ValueError(f"stack_Q_all_before_KK: Q_all must be at least 3D; got {Q.shape}")

    K1, K2 = Q.shape[-2], Q.shape[-1]
    if K_expected is not None and (K1 != K_expected or K2 != K_expected):
        raise ValueError(f"Trailing dims {K1}x{K2} != expected {K_expected}x{K_expected}")

    # NEW: infer d if not given (most robust when generators available to caller)
    if d is None:
        # caller always has generators; mirror their usage
        # NOTE: keep signature unchanged; just allow d=None to be replaced upstream
        pass

    # If d provided, force the Lie axis to -3
    if d is not None and Q.shape[-3] != d:
        candidate = None
        for ax in range(Q.ndim - 2):
            if Q.shape[ax] == d:
                candidate = ax
                break
        if candidate is None:
            raise ValueError(f"Could not locate Lie axis of size d={d} in Q_all shape {Q.shape}")
        if candidate != Q.ndim - 3:
            Q = np.moveaxis(Q, candidate, Q.ndim - 3)

    return Q.astype(np.float32, copy=False)



def broadcast_mat_to_leading_KK(mat, lead_shape: tuple, K: int) -> np.ndarray:
    """
    Broadcast a matrix 'mat' shaped (..., K, K) so its leading dims match 'lead_shape'.
    Returns (*lead_shape, K, K).
    """
    M = np.asarray(mat)
    if M.ndim < 2 or M.shape[-2:] != (K, K):
        raise ValueError(f"broadcast_mat_to_leading_KK: expected (...,{K},{K}); got {M.shape}")
    if M.ndim == 2:
        M = M.reshape((1,) * len(lead_shape) + (K, K))
    if M.shape[:-2] != tuple(lead_shape):
        M = np.broadcast_to(M, tuple(lead_shape) + (K, K))
    return M.astype(np.float32, copy=False)





def _exact_align_transport(mu_j, Sigma_j, Omega_ij, eps: float):
    """
    Exact transport for alignment term (no near-identity approx).
    """
    mu_j_t, Sigma_j_t, inv_j_t = push_gaussian(
        mu=mu_j, Sigma=Sigma_j, M=Omega_ij, eps=eps,
        symmetrize=True, sanitize=True, approx="exact",
        near_identity_tau=0.0, return_inv=True,
    )
    return mu_j_t, Sigma_j_t, inv_j_t



def _symmetrize_S(dS: np.ndarray) -> np.ndarray:
    return 0.5 * (dS + np.swapaxes(dS, -1, -2))


def _zero_like(mu: np.ndarray, S: np.ndarray):
    return np.zeros_like(mu, dtype=np.float32), np.zeros_like(S, dtype=np.float32)


def _recover_like(arr: np.ndarray, policy: str | None) -> np.ndarray:
    if policy == "nan":
        return np.nan_to_num(arr, nan=0.0, posinf=0.0, neginf=0.0)
    if policy == "zero":
        return np.zeros_like(arr, dtype=np.float32)
    return arr  # default: leave as-is

