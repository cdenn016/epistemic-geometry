# Standard library

from numpy.random import default_rng

# Third-party
import numpy as np

# Local helpers

import matplotlib.pyplot as plt
from generalized_agent_distributions import initialize_distribution
from generalized_agent_schema import Agent
from scipy.ndimage import gaussian_filter
import config


def scale_to_range(
    field: np.ndarray,
    value_range: tuple[float, float]
) -> np.ndarray:
    """
    Linearly remap `field` so that field.min()→value_range[0], field.max()→value_range[1].
    If field is constant, fill with the midpoint of the range.
    Output dtype is taken from config.dtype.
    """
    lo, hi = value_range
    fmin, fmax = field.min(), field.max()
    dtype = getattr(config, 'dtype', field.dtype)
    if fmax <= fmin:
        return np.full_like(field, (lo + hi) / 2, dtype=dtype)

    # normalize to [0,1]
    norm = (field - fmin) / (fmax - fmin)
    # scale to [lo, hi]
    out = norm * (hi - lo) + lo
    return out.astype(dtype)


def generate_soft_mask(
    center: tuple[int, ...],
    radius: float,
    domain_size: tuple[int, ...]
) -> np.ndarray:
    """
    Create a smooth soft mask (Gaussian decay) on a periodic domain.
    Distances wrap around edges in each dimension.
    """
    dtype = getattr(config, 'dtype', np.float64)

    # Build per‐axis index grids via ogrid
    grids = np.ogrid[tuple(slice(0, s) for s in domain_size)]  # one array per axis

    # Accumulate squared wrap‐aware distances
    dist_sq = 0.0
    for d, size in enumerate(domain_size):
        coord = grids[d]
        # raw distance from center
        delta = np.abs(coord - center[d])
        # wrap‐around distance
        delta = np.minimum(delta, size - delta)
        dist_sq = dist_sq + delta**2

    dist = np.sqrt(dist_sq)

    # Avoid division by zero
    r = max(radius, np.finfo(float).eps)
    mask = np.exp(-(dist / r)**2).astype(dtype)
    return mask



def create_agent_mask(
    center: tuple[int, ...],
    radius: float,
    domain_size: tuple[int, ...]
) -> np.ndarray:
    """
    Generate a soft Gaussian mask and zero out values below support_cutoff_eps from config.
    """
    mask = generate_soft_mask(center, radius, domain_size)
    cutoff = getattr(config, 'support_cutoff_eps', 1e-3)
    mask[mask < cutoff] = 0.0
    return mask


def smooth_random_field(domain_size, rng, sigma=1.0):
    dtype = getattr(config, 'dtype', np.float64)
    noise = rng.normal(size=domain_size).astype(dtype)
    field = gaussian_filter(noise, sigma=sigma)
    return field.astype(dtype)


def create_smooth_fields(
    domain_size: tuple[int, ...],
    rng: np.random.Generator,
    K: int
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """
    Generate smoothly varying mu and sigma fields for belief and model bundles.
    """
    mu_smooth_range    = getattr(config, "mu_field_smooth_range", (1, 3))
    sigma_smooth_range = getattr(config, "sigma_field_smooth_range", (1, 3))

    mu_smooth_q     = rng.uniform(*mu_smooth_range)
    sigma_smooth_q  = rng.uniform(*sigma_smooth_range)
    mu_smooth_p     = rng.uniform(*mu_smooth_range)
    sigma_smooth_p  = rng.uniform(*sigma_smooth_range)

    mu_q_field = scale_to_range(
        smooth_random_field(domain_size, rng, sigma=mu_smooth_q),
        getattr(config, "q_mu_range", (1, K - 1))
    )
    sigma_q_field = scale_to_range(
        smooth_random_field(domain_size, rng, sigma=sigma_smooth_q),
        getattr(config, "q_sigma_range", (1, 5))
    )

    # === Model fields ===
    if getattr(config, "identical_models", False):
        # Use smooth fields for p, but shared across all agents
        mu_p_field = scale_to_range(
            smooth_random_field(domain_size, rng, sigma=mu_smooth_p),
            getattr(config, "p_mu_range", (1, K - 1))
        )
        sigma_p_field = scale_to_range(
            smooth_random_field(domain_size, rng, sigma=sigma_smooth_p),
            getattr(config, "p_sigma_range", (1, 5))
        )
    elif getattr(config, "similar_p_models", False):
        # Use flat model fields (same everywhere per agent)
        base_mu_p    = rng.uniform(*getattr(config, "p_mu_range", (1, K - 1)))
        base_sigma_p = rng.uniform(*getattr(config, "p_sigma_range", (1, 5)))
        mu_p_field    = np.full(domain_size, base_mu_p,    dtype=mu_q_field.dtype)
        sigma_p_field = np.full(domain_size, base_sigma_p, dtype=sigma_q_field.dtype)
    else:
        # Default: fully independent smooth model fields
        mu_p_field = scale_to_range(
            smooth_random_field(domain_size, rng, sigma=mu_smooth_p),
            getattr(config, "p_mu_range", (1, K - 1))
        )
        sigma_p_field = scale_to_range(
            smooth_random_field(domain_size, rng, sigma=sigma_smooth_p),
            getattr(config, "p_sigma_range", (1, 5))
        )

    return mu_q_field, sigma_q_field, mu_p_field, sigma_p_field


def initialize_phi_fields(
    domain_size: tuple[int, ...],
    lie_algebra_dim: int,
    rng: np.random.Generator,
    phi_init: float,
    phi_model_offset: float,
    mask: np.ndarray
) -> tuple[np.ndarray, np.ndarray]:
    """
    Initialize and smooth both belief-phase and model-phase fields.
    """
    dtype = getattr(config, 'dtype', mask.dtype)
    spatial_sigma = getattr(config, 'phi_init_smooth_sigma', 0.5)

    # Base phi field
    phi_base = rng.normal(scale=phi_init, size=(*domain_size, lie_algebra_dim)).astype(dtype)
    phi_smooth = gaussian_filter(phi_base, sigma=spatial_sigma)
    phi_masked = phi_smooth * mask[..., None]

    # Model-phase with offset
    delta = rng.normal(scale=phi_model_offset, size=(*domain_size, lie_algebra_dim)).astype(dtype)
    phi_model = gaussian_filter(phi_smooth + delta, sigma=spatial_sigma)
    phi_model_masked = phi_model * mask[..., None]

    return phi_masked, phi_model_masked


def assign_neighbors_vectorized(
    agents: list,
    overlap_eps: float,
    max_neighbors: int
) -> None:
    """
    Vectorized neighbor assignment based on mask overlap.
    """
    N = len(agents)
    dtype = getattr(config, 'dtype', np.float32)

    # Flatten and cast masks for memory efficiency
    masks = np.stack([agent.mask.flatten().astype(dtype) for agent in agents])  # shape: (N, prod(domain_size))
    # Compute pairwise overlaps
    overlap_matrix = masks @ masks.T
    threshold = overlap_eps * masks.shape[1]
    overlap_bool = overlap_matrix > threshold

    for i in range(N):
        overlap_bool[i, i] = False
        neighbors_sorted = np.argsort(-overlap_matrix[i])
        valid = [j for j in neighbors_sorted if overlap_bool[i, j]]
        agents[i].neighbors = [{"id": j} for j in valid[:max_neighbors]]



def plot_agent_overlap(agent_i, agent_j, cutoff=None):
    import matplotlib.pyplot as plt
    import numpy as np
    import config

    if cutoff is None:
        cutoff = getattr(config, "support_cutoff_eps", 1e-3)

    mask_i  = agent_i.mask > cutoff
    mask_j  = agent_j.mask > cutoff
    overlap = mask_i & mask_j

    if mask_i.ndim != 2:
        raise ValueError(f"plot_agent_overlap only supports 2D spatial domains, got shape {mask_i.shape}")

    H, W = mask_i.shape

    fig, axs = plt.subplots(1, 3, figsize=(12, 4))

    for ax, M, title in zip(
        axs,
        [mask_i, mask_j, overlap],
        [f"Agent {agent_i.id} Support",
         f"Agent {agent_j.id} Support",
         "Overlap"]
    ):
        ax.imshow(
            M,
            cmap="gray",
            origin="lower",
            extent=[0, W, 0, H],
            interpolation="nearest"
        )
        ax.set_title(title)
        ax.set_xticks([0, W//2, W])
        ax.set_yticks([0, H//2, H])

    plt.tight_layout()
    plt.show()



def initialize_agents(
    seed: int,
    domain_size: tuple[int, ...],
    N: int,
    K: int,
    lie_algebra_dim: int,
    visualize: bool = True,
    fixed_location: bool = True,
) -> list[Agent]:
    """
    Initialize N agents over a D-dimensional grid C:
      - Soft support masks from Gaussian decay
      - Per-point belief and model distributions (shape (..., K))
      - Smoothed phi and phi_model fields
      - Vectorized neighbor assignment

    Parameters:
      seed: RNG seed for reproducibility
      domain_size: tuple of grid sizes along each spatial dimension
      N: number of agents
      K: fiber dimension (distribution length)
      lie_algebra_dim: dimension of the Lie algebra (gauge field size)
      visualize: if True and D==2, plot mask, q, p, and |phi|
      fixed_location: if True, all agents centered at grid center; else random

    Returns:
      List of Agent objects with initialized fields and neighbor lists.
    """
    # RNG
    rng = default_rng(seed)

    # Pull config into local dict
    cfg = {k: getattr(config, k) for k in dir(config) if not k.startswith("__")}
    phi_init         = cfg["phi_init"]
    phi_model_offset = cfg.get("phi_model_offset", 0.1)
    dist_family      = cfg["distribution_family"]
    max_neighbors    = cfg.get("max_neighbors", 8)
    dtype            = cfg.get("dtype", np.float32)

    # Spatial dimension
    D = len(domain_size)
    # Broadcast template for distributions
    x = np.arange(K).reshape(*([1] * D), -1)

    # Optional fixed center
    fixed_center = tuple(s // 2 for s in domain_size) if fixed_location else None

    agents: list[Agent] = []
    # Precompute shared model fields if identical_models is enabled
# Precompute shared model fields if identical_models is enabled
    shared_mu_p = shared_sigma_p = None
    if getattr(config, "identical_models", False):
        shared_mu_p, shared_sigma_p = create_smooth_fields(domain_size, rng, K)[2:]

    for n in range(N):
    # Random radius and center
        radius = rng.uniform(*cfg.get("psi_radius_range", (5, 10)))
        center = fixed_center or tuple(rng.integers(0, s) for s in domain_size)

    # Support mask
        mask = create_agent_mask(center, radius, domain_size)

    # Belief fields (always unique)
        mu_q_field, sigma_q_field, _, _ = create_smooth_fields(domain_size, rng, K)

    # Model fields (shared or unique)
        if getattr(config, "identical_models", False):
            mu_p_field    = shared_mu_p
            sigma_p_field = shared_sigma_p
        else:
            _, _, mu_p_field, sigma_p_field = create_smooth_fields(domain_size, rng, K)



        
        # Initialize belief and model distributions
        q = initialize_distribution(x, mu_q_field, sigma_q_field, mask, dist_family).astype(dtype)
        p = initialize_distribution(x, mu_p_field, sigma_p_field, mask, dist_family).astype(dtype)

        # Initialize and smooth phi fields
        phi_masked, phi_model_masked = initialize_phi_fields(
            domain_size, lie_algebra_dim, rng,
            phi_init, phi_model_offset, mask
        )

        # Create agent object
        agent = Agent(
            id=n,
            center=center,
            radius=radius,
            mask=mask.astype(dtype),
            q=q,
            p=p,
            mu_q_field=mu_q_field.astype(dtype),
            sigma_q_field=sigma_q_field.astype(dtype),
            mu_p_field=mu_p_field.astype(dtype),
            sigma_p_field=sigma_p_field.astype(dtype),
            phi=phi_masked,
            phi_model=phi_model_masked,
            neighbors=[],
        )
        agents.append(agent)

        if visualize and D == 2:
           

    # Compute summary statistics of q and p
            K = q.shape[-1]
            indices = np.arange(K)

    # 1) Mean index under q(c)
            q_mean = np.tensordot(q, indices, axes=([-1],[0]))
            q_mode = np.argmax(q, axis=-1)
            p_mean = np.tensordot(p, indices, axes=([-1],[0]))
            p_mode = np.argmax(p, axis=-1)

    # Ensure mask is thresholded
            thresh_mask = create_agent_mask(center, radius, domain_size)

            fig, axs = plt.subplots(2, 3, figsize=(18, 10))

    # Top row: Belief
            axs[0,0].imshow(thresh_mask, cmap='gray')
            axs[0,0].set_title("Agent Mask (thresholded)")
            axs[0,1].imshow(q_mean, cmap='viridis')
            axs[0,1].set_title("Belief mean index")
            axs[0,2].imshow(q_mode, cmap='viridis')
            axs[0,2].set_title("Belief mode index")

    # Bottom row: Model
            axs[1,0].imshow(thresh_mask, cmap='gray')
            axs[1,0].set_title("Agent Mask (thresholded)")
            axs[1,1].imshow(p_mean, cmap='plasma')
            axs[1,1].set_title("Model mean index")
            axs[1,2].imshow(p_mode, cmap='plasma')
            axs[1,2].set_title("Model mode index")

            plt.tight_layout()
            plt.show()

    # Assign neighbors based on support overlap
    assign_neighbors_vectorized(agents, cfg.get("overlap_eps", 1e-3), max_neighbors)
    
    print(f"[DEBUG] Initialized {len(agents)} agents with dtype={dtype}")

    return agents
