# -*- coding: utf-8 -*-
"""
Created on Mon Jun 23 17:22:53 2025

@author: chris and christine
"""

import os
import optuna
from generalized_simulation import run_simulation as gs_run
from pathlib import Path


# Number of Optuna trials
N_TRIALS = 35
# How many trials to run in parallel
N_JOBS   = 12  

# Your selected parameter search space
sweep_params = {
     "alpha":                 (0,    200),
     "beta":                  (0,    200),
     "gamma":                 (0,    200),
     "gauge_weight":          (0,    200), 
     "model_align_weight":    (0,    200),
     "model_gauge_weight":    (0,    200),
     "model_mass_weight":     (0,    200),
     "model_feedback_weight": (0,    200),
     "phi_phi_tilde_coupling":(0,    200),
     #"eta_base_q":            (1e-11, 1e-3),    
     #"eta_base_p":            (1e-11, 1e-3),    
     #"eta_base_phi":          (1e-11, 1e-3),    
     #"eta_base_phi_model":    (1e-11, 1e-3) 
}

TARGET_SLOPE = -1.0

def run_simulation(params: dict, trial_number: int) -> float:
    outdir = Path(f"optuna_tmp/trial_{trial_number}")
    outdir.mkdir(parents=True, exist_ok=True)

    agents, metric_log, slope = gs_run(
        outdir=outdir,
        resume=False,
        log_metrics=False,   # save time – we only need the slope
        num_cores=1,
        params=params,
    )
    return slope          # <- return the diagnostic we care about

def objective(trial):
    try:
        params = {
            name: trial.suggest_float(name, max(lo, 1e-6), hi, log=True)
            for name, (lo, hi) in sweep_params.items()
        }

        agents, metric_log, zipf_stats = gs_run(
            outdir=Path(f"optuna_tmp/trial_{trial.number}"),
            resume=False,
            log_metrics=False,
            num_cores=1,
            params=params,
        )

        slope = zipf_stats["slope"]
        loss = abs(slope - TARGET_SLOPE)

        print(f"[OPTUNA] Trial {trial.number}: slope = {slope:.4f}, r² = {zipf_stats['r2']:.3f}, loss = {loss:.4f}")
        return loss

    except Exception as e:
        print(f"[ERROR] Trial {trial.number} failed: {e}")
        return float("inf")  # or `raise` if you want to crash instead



def main():
    study = optuna.create_study(direction='minimize')
    study.optimize(objective, n_trials=N_TRIALS, n_jobs=N_JOBS)

    print("\n[RESULT] Best parameters:")
    for k, v in study.best_params.items():
        print(f"  {k}: {v:.4f}")
    print(f"\n[RESULT] Best energy: {study.best_value:.6f}")

if __name__ == "__main__":
    main()
