
"""zipf_log_bias_diagnostics.py  (second fix 2025‑06‑30)

This version handles SL(2,R) (d=3) gauge fields properly:

  • builds the full K×K transport Ω_{ij}=exp φ_i · exp(−φ_j)
    using generalized_omega.batch_exp_lie_algebra_irrep;
  • works even when φ has shape (...,3) different from K;
  • renormalises transported q_j;
  • counts *actual* neighbour number n_i.

Usage:   python zipf_log_bias_diagnostics.py   (or Run from Spyder)

Outputs  gamma_summary.csv  next to the checkpoint file.
"""

# --------------------------------------------------------------
# CONFIG
# --------------------------------------------------------------
from pathlib import Path
CHECKPOINT_DIR = Path("checkpoints")
STEP_FILE      = None       # or e.g. "checkpoints/step_0199.pkl"
SAVE_CSV       = True
CSV_NAME       = "gamma_summary.csv"

RMIN       = 3
RMAX_FRAC  = 0.5
VERBOSE    = True
# --------------------------------------------------------------

import pickle, numpy as np, pandas as pd, math, warnings

# ---------- helpers -------------------------------------------
def _log(msg=""):
    if VERBOSE: print(msg, flush=True)

def _latest_step_file(folder: Path):
    files = sorted(folder.glob("step_*.pkl"))
    if not files:
        raise FileNotFoundError(f"No step_*.pkl found in {folder}")
    return files[-1]

def _load_agents(path: Path):
    data = pickle.load(open(path, "rb"))
    if isinstance(data, dict) and "agents" in data:
        return data["agents"]
    return data

def _avg_spatial(arr: np.ndarray):
    """Average over *all* axes except the last (token or lie‑dim)."""
    if arr.ndim <= 1:
        return arr.astype(float)
    return arr.reshape(-1, arr.shape[-1]).mean(axis=0).astype(float)

def _ensure_prob(v, eps=1e-12):
    v = np.clip(v, eps, None)
    v /= v.sum()
    return v

# ---------- regression utilities ------------------------------
def _gamma_from_vectors(q_i, q_trans, rmin, rmax):
    K = q_i.shape[-1]
    ranks = np.arange(1, K + 1)
    mask = (ranks >= rmin) & (ranks <= rmax)
    if mask.sum() < 3:
        return np.nan
    logk = np.log(ranks[mask])
    y = np.log(q_i[..., mask]) - np.log(q_trans[..., mask])
    logk_cent = logk - logk.mean()
    y_cent = y - y.mean(axis=-1, keepdims=True)
    num = (logk_cent * y_cent).sum(axis=-1)
    den = (logk_cent ** 2).sum()
    return num / den

# ---------- group helpers -------------------------------------
from generalized_omega import batch_exp_lie_algebra_irrep
from get_generators import get_generators
import config as _cfg

_generators_cache = {}
def _generators(K):
    if K not in _generators_cache:
        _generators_cache[K] = get_generators(_cfg.group_name, K)
    return _generators_cache[K]

def _exp_from_phi(phi_vec, K):
    """Return exp(phi) matrix (K×K) from 1‑D phi_vec (length d)."""
    gens = _generators(K)                     # shape (d,K,K)
    return batch_exp_lie_algebra_irrep(phi_vec.reshape(1,-1), gens)[0]

# ==============================================================
def main():
    step_path = Path(STEP_FILE) if STEP_FILE else _latest_step_file(CHECKPOINT_DIR)
    _log(f"[LOAD] {step_path}")
    agents = _load_agents(step_path)

    alpha = getattr(_cfg, "alpha", 1.0)
    beta  = getattr(_cfg, "beta", 1.0)

    # precompute spatial means
    K = getattr(_cfg, "K", agents[0].q.shape[-1])
    phi_means = [ _avg_spatial(ag.phi) for ag in agents ]   # list of (d,)
    q_means   = [ _ensure_prob(_avg_spatial(ag.q)) for ag in agents ]

    # exponentiate once per agent
    O_mats    = [ _exp_from_phi(phi_vec, K) for phi_vec in phi_means ]
    O_inv_mats= [ np.linalg.inv(M) for M in O_mats ]

    rows = []
    for i, ag in enumerate(agents):
        q_i = q_means[i]
        gammas = []
        neigh_ids = [nb["id"] for nb in getattr(ag, "neighbors", [])]
        for j in neigh_ids:
            Omega_ij = O_mats[i] @ O_inv_mats[j]
            q_trans  = _ensure_prob(Omega_ij @ q_means[j])
            γ_ij     = float(_gamma_from_vectors(q_i, q_trans,
                                                 RMIN, int(RMAX_FRAC*K)))
            gammas.append(γ_ij)

        n_i = len(gammas)
        gamma_val = float(np.nanmean(gammas)) if gammas else 0.0
        # analytic Zipf exponent:  s = β n γ / (α + β n)
        pred_slope = -beta * n_i * gamma_val / (alpha + beta * n_i)
        rows.append(dict(agent=i,
                         n_neigh=n_i,
                         gamma_log=gamma_val,
                         pred_zipf_slope=pred_slope))

    df = pd.DataFrame(rows)
    _log("\n" + df.to_string(index=False,
                               float_format=lambda x: f"{x: .4g}"))

    if SAVE_CSV:
        out = step_path.with_name(CSV_NAME)
        df.to_csv(out, index=False)
        _log(f"[SAVE] CSV → {out}")

# --------------------------------------------------------------
if __name__ == "__main__":
    main()
