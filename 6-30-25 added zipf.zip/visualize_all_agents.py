#!/usr/bin/env python3
"""
plot_agents_phi_alignment.py

Creates a single figure showing:
  1) All agent support contours (uses `agent.mask`)
  2) Sum of phi norms across agents (uses `agent.phi`)
  3) Bar chart of last-step alignment (KL_align) per agent

Usage:
  python plot_agents_phi_alignment.py --checkpoint-dir checkpoints
"""

import sys
import os
import pickle
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

# Ensure we can import your suite modules
sys.path.insert(0, os.getcwd())

#from generalized_simulation import run_simulation
import config

def load_agents(checkpoint_dir):
    """Load agents from checkpoint or rerun one simulation step."""
    ckpt = os.path.join(checkpoint_dir, "step_0000.pkl")
    if os.path.isfile(ckpt):
        with open(ckpt, "rb") as f:
            agents = pickle.load(f)
    else:
        agents, _ = run_simulation(
            outdir=checkpoint_dir,
            params=None,
            n_jobs=config.num_cores
        )
    return agents

def load_per_agent_metrics(checkpoint_dir):
    """Load per_agent_metrics.csv if it exists and has the right columns."""
    csv_path = os.path.join(checkpoint_dir, "per_agent_metrics.csv")
    if os.path.isfile(csv_path):
        df = pd.read_csv(csv_path)
        if {'agent', 'kl_align'}.issubset(df.columns):
            return df
    return None

def main(checkpoint_dir="checkpoints"):
    agents = load_agents(checkpoint_dir)
    per_df = load_per_agent_metrics(checkpoint_dir)

    fig, axes = plt.subplots(1, 3, figsize=(18, 6))

    # Panel 1: Support contours
    ax0 = axes[0]
    for agent in agents:
        mask = agent.mask  # per generalized_agent_schema.py
        ax0.contour(
            mask,
            levels=[config.support_cutoff_eps],
            colors='black',
            linewidths=1
        )
    ax0.set_title("Agent Support Contours")
    ax0.axis('off')

    # Panel 2: Sum of phi norms
    ax1 = axes[1]
    combined = np.zeros(config.domain_size, dtype=float)
    for agent in agents:
        phi = agent.phi  # per generalized_agent_schema.py
        combined += np.linalg.norm(phi, axis=-1)
    im = ax1.imshow(combined, origin='lower')
    ax1.set_title("Sum of Φ Norms")
    ax1.axis('off')
    fig.colorbar(im, ax=ax1, fraction=0.046, pad=0.04)

    # Panel 3: Last-step alignment per agent
    ax2 = axes[2]
    if per_df is not None:
        last_vals = per_df.groupby('agent')['kl_align'].last()
        ax2.bar(last_vals.index, last_vals.values)
        ax2.set_xlabel("Agent Index")
        ax2.set_ylabel("KL Align")
        ax2.set_title("Alignment per Agent")
    else:
        ax2.text(0.5, 0.5, "No per-agent metrics", ha='center')
        ax2.set_title("Alignment")
        ax2.axis('off')

    plt.tight_layout()
    plt.show()

if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(
        description="Plot agent masks, φ norms, and alignment"
    )
    parser.add_argument(
        "--checkpoint-dir", "-c",
        default="checkpoints",
        help="Directory with step_0000.pkl and per_agent_metrics.csv"
    )
    args = parser.parse_args()
    main(args.checkpoint_dir)
