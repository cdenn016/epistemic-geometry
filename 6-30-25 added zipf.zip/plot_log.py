import os
import pickle
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from pandas.plotting import scatter_matrix
import config
import numpy as np

# (Optional) human‐friendly titles and y‐labels
PRETTY = {
    'kl_self':             ("Self KL",           r"$D_{KL}(q\|p)$"),
    'kl_align':            ("Belief Align",      r"$D_{KL}(q_i\|\Omega q_j)$"),
    'kl_model_align':      ("Model Align",       r"$D_{KL}(p_i\|\widetilde\Omega p_j)$"),
    'phi_norm':            ("‖φ‖",               r"avg‖φ‖"),
    'phi_model_norm':      ("‖φ̃‖",              r"avg‖φ̃‖"),
    'entropy':             ("Entropy",           "avg H(q)"),
    'total_energy':        ("Total Energy",      "E_total"),
    'lap_phi_norm':        ("Laplacian φ",       r"‖Δφ‖"),
    'delta_phi_norm':      ("Δφ norm",           r"‖Δφ‖"),
    'curvature_norm':      ("Curvature",         "avg‖F‖"),
    'fisher_information':  ("Fisher Info",       "I_fisher"),
    'cross_model_kl':      ("Cross‐KL",          r"$D_{KL}(q_i\|\widetilde\Omega p_j)$"),
    # new metrics
    'free_energy':         ("Free Energy",       r"$\overline{D_{KL}}(q\|p)$"),
    'coherence':           ("Coherence φ",       "Kuramoto R"),
    'model_coherence':     ("Coherence φ̃",      "Kuramoto R_model"),
}

def main():
    # Determine result directories: single 'checkpoints' or multiple in 'lhs_results'
    base_dirs = []
    # single-run
    if os.path.exists("checkpoints/metric_log.pkl"):
        base_dirs.append("checkpoints")
    # LHS sweep runs
    lhs_root = "lhs_results"
    if os.path.isdir(lhs_root):
        for name in sorted(os.listdir(lhs_root)):
            run_dir = os.path.join(lhs_root, name)
            if os.path.isdir(run_dir) and os.path.exists(os.path.join(run_dir, "metric_log.pkl")):
                base_dirs.append(run_dir)

    if not base_dirs:
        print("No result directories found (check 'checkpoints/' or 'lhs_results/')")
        return

    for base in base_dirs:
        # load global metrics
        path = os.path.join(base, "metric_log.pkl")
        with open(path, "rb") as f:
            metrics = pickle.load(f)
        df = pd.DataFrame(metrics)
        df.set_index("step", inplace=True)

        # after we index by step, rename the fused‐metrics keys into the kl_/lap_/… names
        rename_map = {
            "e_self":      "kl_self",
            "e_align":     "kl_align",
            "e_mod_align": "kl_model_align",
            "e_lap_bel":   "lap_phi_norm",
            "e_mass_bel":  "mass_phi",
            "e_lap_mod":   "lap_phi_model",
            "e_mass_mod":  "mass_phi_model",
            "e_couple":    "phi_coupling",
            "curvature_norm":       "curv_phi",
            "curvature_model_norm": "curv_phi_model",
        }
        df.rename(columns=rename_map, inplace=True)



        # prepare output folder per run
        cfg = config
        run_name = os.path.basename(base)
        # name folder by K, alpha, beta, N and L
        folder = os.path.join(
            "plots",
            f"{cfg.group_name}_{run_name}"
            f"_K{cfg.K}"
            f"_α{cfg.alpha}"
            f"_β{cfg.beta}"
            f"_N{cfg.N}"
            f"_L{cfg.L}"
        )
        os.makedirs(folder, exist_ok=True)

        # 4) Plot raw global metrics
        for col in df.columns:
            title, ylabel = PRETTY.get(col, (col, col))
            plt.figure(figsize=(6, 4))
            plt.plot(df.index, df[col], marker=".", linestyle="-")
            plt.title(title)
            plt.xlabel("Step")
            plt.ylabel(ylabel)
            plt.tight_layout()
            out = os.path.join(folder, f"{col}.png")
            plt.savefig(out, dpi=150)
            plt.close()
            print(f"Saved {out}")

        # 5) Coupling-weight-scaled energy components
        scaled_energy_terms = {
            "kl_self":          cfg.alpha,
            "kl_align":         cfg.beta,
            "kl_model_align":   cfg.model_align_weight,
            "phi_norm":         getattr(cfg, "gauge_weight", None),
            "phi_model_norm":   getattr(cfg, "model_gauge_weight", None),
            "curvature_norm":   getattr(cfg, "curvature_weight", None),
            "free_energy":      cfg.alpha,
        }

        for term, weight in scaled_energy_terms.items():
            if term in df.columns and weight is not None:
                scaled_col = f"{term}_scaled"
                df[scaled_col] = weight * df[term]
                label = PRETTY.get(term, (term, term))[1]
                plt.figure(figsize=(6, 4))
                plt.plot(df.index, df[scaled_col], label=f"{weight}·{label}")
                plt.title(f"Scaled Energy: {term}")
                plt.xlabel("Step")
                plt.ylabel("Contribution")
                plt.legend()
                plt.tight_layout()
                out = os.path.join(folder, f"{scaled_col}.png")
                plt.savefig(out, dpi=150)
                plt.close()
                print(f"Saved {out}")

        print(f"All global plots complete for {run_name}.")

        # 6) per-agent metrics
        per_agent_csv = os.path.join(base, "per_agent_metrics.csv")
        if os.path.exists(per_agent_csv):
            df_agents = pd.read_csv(per_agent_csv)
            agent_folder = os.path.join(folder, "per_agent")
            os.makedirs(agent_folder, exist_ok=True)
            agent_cols = [c for c in df_agents.columns if c not in ("agent", "step")]
            for metric in agent_cols:
                plt.figure(figsize=(6, 4))
                for aid in sorted(df_agents["agent"].unique()):
                    sub = df_agents[df_agents["agent"] == aid]
                    plt.plot(sub["step"], sub[metric], label=f"agent {aid}")
                title, ylabel = PRETTY.get(metric, (metric, metric))
                plt.title(f"{title} per Agent")
                plt.xlabel("Step")
                plt.ylabel(ylabel)
                plt.legend(loc="upper right", ncol=2, fontsize="small")
                plt.tight_layout()
                out = os.path.join(agent_folder, f"{metric}_per_agent.png")
                plt.savefig(out, dpi=150)
                plt.close()
                print(f"Saved per-agent plot → {out}")
        else:
            print(f"Per-agent CSV not found: {per_agent_csv}")
    # 1) Load global metrics
    path = os.path.join("checkpoints", "metric_log.pkl")
    with open(path, "rb") as f:
        metrics = pickle.load(f)

   

     # 2) Convert to DataFrame
    df = pd.DataFrame(metrics)
    df.set_index("step", inplace=True)
    # — rename fused‐metrics keys here too
    rename_map = {
        "e_self":      "kl_self",
        "e_align":     "kl_align",
        "e_mod_align": "kl_model_align",
        "e_lap_bel":   "lap_phi_norm",
        "e_mass_bel":  "mass_phi",
        "e_lap_mod":   "lap_phi_model",
        "e_mass_mod":  "mass_phi_model",
        "e_couple":    "phi_coupling",
        "curvature_norm":       "curv_phi",
        "curvature_model_norm": "curv_phi_model",
  }
    df.rename(columns=rename_map, inplace=True)



    # 3) Prepare output folder
    cfg = config
        # name folder by K, alpha, beta, N and L
    folder = os.path.join(
            "plots",
            f"{cfg.group_name}_{run_name}"
            f"_K{cfg.K}"
            f"_α{cfg.alpha}"
            f"_β{cfg.beta}"
            f"_N{cfg.N}"
            f"_L{cfg.L}"
        )
    os.makedirs(folder, exist_ok=True)

    # 4) Plot raw global metrics
    for col in df.columns:
        title, ylabel = PRETTY.get(col, (col, col))
        plt.figure(figsize=(6, 4))
        plt.plot(df.index, df[col], marker=".", linestyle="-")
        plt.title(title)
        plt.xlabel("Step")
        plt.ylabel(ylabel)
        plt.tight_layout()
        out = os.path.join(folder, f"{col}.png")
        plt.savefig(out, dpi=150)
        plt.close()
        print(f"Saved {out}")

    # 5) Coupling-weight-scaled energy components
    scaled_energy_terms = {
        "kl_self":          cfg.alpha,
        "kl_align":         cfg.beta,
        "kl_model_align":   cfg.model_align_weight,
        "phi_norm":         getattr(cfg, "gauge_weight", None),
        "phi_model_norm":   getattr(cfg, "model_gauge_weight", None),
        "curvature_norm":   getattr(cfg, "curvature_weight", None),
        # optionally include free_energy scaled by alpha
        "free_energy":      cfg.alpha,
    }

    for term, weight in scaled_energy_terms.items():
        if term in df.columns and weight is not None:
            scaled_col = f"{term}_scaled"
            df[scaled_col] = weight * df[term]
            label = PRETTY.get(term, (term, term))[1]
            plt.figure(figsize=(6, 4))
            plt.plot(df.index, df[scaled_col], label=f"{weight}·{label}")
            plt.title(f"Scaled Energy: {term}")
            plt.xlabel("Step")
            plt.ylabel("Contribution")
            plt.legend()
            plt.tight_layout()
            out = os.path.join(folder, f"{scaled_col}.png")
            plt.savefig(out, dpi=150)
            plt.close()
            print(f"Saved {out}")

    print("All global plots complete.")

    # 6) Plot per-agent metrics
    per_agent_csv = os.path.join("checkpoints", "per_agent_metrics.csv")
    if os.path.exists(per_agent_csv):
        df_agents = pd.read_csv(per_agent_csv)
        agent_folder = os.path.join(folder, "per_agent")
        os.makedirs(agent_folder, exist_ok=True)
        # pick out every metric column except 'agent' and 'step'
        agent_cols = [c for c in df_agents.columns if c not in ("agent", "step")]
        for metric in agent_cols:
            plt.figure(figsize=(6, 4))
            for aid in sorted(df_agents["agent"].unique()):
                sub = df_agents[df_agents["agent"] == aid]
                plt.plot(sub["step"], sub[metric], label=f"agent {aid}")
            title, ylabel = PRETTY.get(metric, (metric, metric))
            plt.title(f"{title} per Agent")
            plt.xlabel("Step")
            plt.ylabel(ylabel)
            plt.legend(loc="upper right", ncol=2, fontsize="small")
            plt.tight_layout()
            out = os.path.join(agent_folder, f"{metric}_per_agent.png")
            plt.savefig(out, dpi=150)
            plt.close()
            print(f"Saved per-agent plot → {out}")
    else:
        print(f"Per-agent CSV not found: {per_agent_csv}")

if __name__ == "__main__":
    main()
