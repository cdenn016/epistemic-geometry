# -*- coding: utf-8 -*-
"""
Created on Sun Jul  6 14:42:59 2025

@author: chris and christine
"""
import numpy as np
import config
from joblib import Parallel, delayed



def compute_fisher_metric_block_diag(sigma: np.ndarray):
    """
    Compute block-diagonal approximation to the Fisher metric for MVN(μ, Σ)

    Fisher block structure:
    [ Σ⁻¹               0         ]
    [   0   (1/2) Σ⁻¹ ⊗ Σ⁻¹       ]

    Args:
        sigma: (K, K) positive-definite covariance matrix

    Returns:
        fisher_mu_inv: (K, K)
        fisher_sigma_inv: (K, K, K, K) tensor for Σ part
    """
    
    sigma_sanitized = sanitize_sigma(sigma, eps=1e-6, debug=config.debug_sanitize_sigma)
    sigma_inv = np.linalg.inv(sigma_sanitized)


    fisher_mu = sigma_inv
    fisher_sigma = 0.5 * np.einsum('ij,kl->ijkl', sigma_inv, sigma_inv)

    return fisher_mu, fisher_sigma


def apply_lie_natural_gradient(phi, grad_phi, G_inv=None):
    """
    Apply Lie-natural gradient update to φ using optional inverse Fisher metric.

    Args:
        phi      : (H, W, d) or None — current φ field (not used unless needed for adaptive G)
        grad_phi : (H, W, d)         — raw Euclidean gradient
        G_inv    : (d, d) or (H, W, d, d) or None — inverse Fisher metric

    Returns:
        nat_grad : (H, W, d) natural gradient update
    """
    if G_inv is None:
        return grad_phi  # fallback

    if G_inv.ndim == 2:
        # Constant global metric
        return np.einsum("ab,...b->...a", G_inv, grad_phi)
    elif G_inv.ndim == 4:
        # Spatially varying Fisher inverse
        return np.einsum("...ab,...b->...a", G_inv, grad_phi)
    else:
        raise ValueError(f"G_inv must be (d,d) or (H,W,d,d), got {G_inv.shape}")



def compute_inverse_fisher_field(agent, field="phi"):
    """
    Compute per-point inverse Fisher metric for Lie-natural gradient:
    Uses σ_q_field or σ_p_field to build local metric for φ or φ_model.

    Returns:
        G_inv_field: (H, W, d, d)
    """
    sigma = (
        agent.sigma_q_field if field == "phi"
        else agent.sigma_p_field
    )  # (H, W, K, K)

    sigma_sanitized = sanitize_sigma(sigma)
    G_inv = np.linalg.inv(sigma_sanitized)  # (H, W, K, K)
    return G_inv



def apply_natural_gradient_batch(mu_field, sigma_field, grad_mu_field, grad_sigma_field):
    """
    Apply natural gradient descent using local Fisher metric at each spatial point.
    Fisher inverse:
        G_μ⁻¹ = Σ
        G_Σ⁻¹ = 2 × (Σ ⊗ Σ)

    Returns:
        delta_mu:    (H, W, K)
        delta_sigma: (H, W, K, K)
    """
    shape = mu_field.shape
    eps = getattr(config, "eps", 1e-8)

    if len(shape) == 3:
        H, W, K = shape
        mu_flat = mu_field.reshape(-1, K)
        sigma_flat = sigma_field.reshape(-1, K, K)
        grad_mu_flat = grad_mu_field.reshape(-1, K)
        grad_sigma_flat = grad_sigma_field.reshape(-1, K, K)
    else:
        raise ValueError(f"Unsupported shape {shape} for mu_field")

    # Regularize and ensure symmetry
    eye = np.eye(K, dtype=mu_flat.dtype)
    sigma_reg = sigma_flat + eps * eye[None, :, :]
    sigma_reg = 0.5 * (sigma_reg + np.transpose(sigma_reg, (0, 2, 1)))

    # Invert Fisher metrics pointwise
    sigma_inv = np.linalg.inv(sigma_reg)

    # --- Natural gradient updates ---

    # Δμ = −Σ ∇μ (adaptive)
    delta_mu = -np.einsum("nij,nj->ni", sigma_reg, grad_mu_flat)

    # ΔΣ = −2 Σ ∇Σ Σ (adaptive)
    delta_sigma = -2 * np.einsum("nij,njk,nkl->nil", sigma_reg, grad_sigma_flat, sigma_reg)

    # Reshape to field
    return (
        delta_mu.reshape(H, W, K),
        delta_sigma.reshape(H, W, K, K)
    )



def compute_lie_metric(generators: np.ndarray):
    """
    Compute inner product matrix G_{ab} = Tr(G_a^T G_b) and its inverse.

    Args:
        generators: (d, K, K) basis of Lie algebra

    Returns:
        G: (d, d) metric matrix
        G_inv: (d, d) inverse metric
    """
    d = generators.shape[0]
    G = np.einsum("aij,bij->ab", generators, generators)
    G = 0.5 * (G + G.T)  # Symmetrize for stability

    eps = getattr(config, "eps", 1e-6)
    G_inv = np.linalg.inv(G + np.eye(d) * eps)

    return G, G_inv



def _sanitize_one_sigma(S, eps=1e-6):
    """
    Sanitize a single covariance matrix to ensure it's symmetric positive-definite (SPD).

    Returns:
        (S_sanitized, clipped): sanitized matrix and boolean flag indicating if it was modified
    """
    S = 0.5 * (S + S.T)  # ensure symmetry

    # First line of defense: handle invalid or pathological cases
    if not np.all(np.isfinite(S)) or np.trace(S) < eps or np.any(np.diag(S) <= 0):
        return np.eye(S.shape[0]) * eps, True

    try:
        eigvals, eigvecs = np.linalg.eigh(S)
    except np.linalg.LinAlgError:
        return np.eye(S.shape[0]) * eps, True

    clipped = np.any(eigvals < eps)
    eigvals_clipped = np.clip(eigvals, eps, None)

    if clipped:
        S = eigvecs @ np.diag(eigvals_clipped) @ eigvecs.T
        S = 0.5 * (S + S.T)  # re-symmetrize

    return S, clipped


def sanitize_sigma(Sigma, eps=1e-6, debug=False, n_jobs=None, parallel_threshold=50):
    """
    Sanitize a batch of covariance matrices to ensure SPD.

    Parameters:
        Sigma: (..., K, K) ndarray — batch of covariances
        eps: minimum eigenvalue threshold
        debug: if True, prints a summary if any matrices are clipped
        n_jobs: number of parallel workers (default: config.num_cores or 1)
        parallel_threshold: min number of matrices before enabling parallelization

    Returns:
        Sanitized SPD matrices with same shape as input.
    """
    shape = Sigma.shape
    flat_sigma = Sigma.reshape(-1, shape[-2], shape[-1])
    n_total = flat_sigma.shape[0]
    n_jobs = n_jobs or getattr(config, "num_cores", 1)

    if n_total < parallel_threshold or n_jobs == 1:
        results = [_sanitize_one_sigma(S, eps) for S in flat_sigma]
    else:
        from joblib import parallel_backend
        with parallel_backend("threading"):
            results = Parallel(n_jobs=n_jobs)(
                delayed(_sanitize_one_sigma)(S, eps) for S in flat_sigma
            )

    Sigma_out, clipped_flags = zip(*results)
    if debug:
        n_clipped = sum(clipped_flags)
        if n_clipped > 0:
            print(f"[SPD sanitize] Clipped {n_clipped} / {n_total} matrices to eps={eps:.1e}")

    out = np.stack(Sigma_out, axis=0).astype(Sigma.dtype).reshape(shape)
    return out

# fisher_geometry_terms.py

import numpy as np
from get_generators import get_generators
import config

def compute_fisher_geometry_gradient(agent_i, agents, params, field="phi"):
    """
    Compute ∇_{φ} or ∇_{φ̃} for Fisher geometry preservation:
        ∇‖Gᵢ − Ωᵢⱼ Gⱼ Ωᵢⱼᵀ‖²
    Supports field="phi" (beliefs) or "phi_model" (models).
    """
    if field == "phi":
        phi     = agent_i.phi
        G_field = agent_i.cached_fisher_q
        exp_phi = agent_i._exp_phi
        exp_neg_phi_j_name = "_exp_neg_phi"
        fisher_weight = params.get("fisher_geometry_weight", config.fisher_geometry_weight)
    else:
        phi     = agent_i.phi_model
        G_field = agent_i.cached_fisher_p
        exp_phi = agent_i._exp_phi_model
        exp_neg_phi_j_name = "_exp_neg_phi_model"
        fisher_weight = params.get("fisher_model_geometry_weight", config.fisher_model_geometry_weight)

    if fisher_weight <= 0:
        return np.zeros_like(phi)

    Gs = get_generators(config.group_name, config.K)
    d, K = Gs.shape[0], Gs.shape[1]
    mask_i = agent_i.mask > config.support_cutoff_eps
    if not np.any(mask_i):
        return np.zeros_like(phi)

    grad = np.zeros_like(phi)
    flat_self_mask = mask_i.reshape(-1)

    exp_phi_i = exp_phi.reshape(-1, K, K)

    for nb in agent_i.neighbors:
        agent_j = agents[nb["id"]]
        mask_j = agent_j.mask > config.support_cutoff_eps
        overlap = mask_i & mask_j
        if not np.any(overlap):
            continue

        flat_idxs = overlap.reshape(-1)

        G_i = G_field.reshape(-1, K, K)[flat_idxs]
        G_j = getattr(agent_j, f"cached_fisher_{'q' if field == 'phi' else 'p'}").reshape(-1, K, K)[flat_idxs]
        exp_neg_phi_j = getattr(agent_j, exp_neg_phi_j_name).reshape(-1, K, K)[flat_idxs]

        Omega = np.einsum("mij,mjk->mik", exp_phi_i[flat_idxs], exp_neg_phi_j)
        G_j_rot = np.einsum("mik,mkl,mjl->mij", Omega, G_j, Omega)  # Ω G Ωᵀ
        Delta = G_i - G_j_rot

        for a in range(d):
            Ga = Gs[a]
            dΩ = np.einsum("ij,mjk->mik", Ga, Omega)
            term1 = np.einsum("mik,mkl,mjl->mij", dΩ, G_j, Omega)
            term2 = np.einsum("mik,mkl,mjl->mij", Omega, G_j, dΩ)
            dG_rot = term1 + term2
            dL = 2 * np.einsum("mij,mij->m", Delta, dG_rot)
            grad.reshape(-1, d)[flat_idxs, a] += dL

    grad *= fisher_weight
    grad[~mask_i] = 0.0
    return grad

# Optional: legacy aliases
def compute_phi_fisher_gradient(agent_i, agents, params):
    return compute_fisher_geometry_gradient(agent_i, agents, params, field="phi")

def compute_phi_model_fisher_gradient(agent_i, agents, params):
    return compute_fisher_geometry_gradient(agent_i, agents, params, field="phi_model")






