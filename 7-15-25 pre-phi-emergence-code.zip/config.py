import numpy as np
import sys

# ===========================
# DEBUGGING AND UTILITIES
# ===========================

# 1) define at top of your script/module
def scaled_eta(base, *weights, min_den=1.0):
    """
    If all weights sum to zero, return base.
    Otherwise return base / max(sum(weights), min_den).
    """
    total = sum(weights)
    if total <= 0:
        return base
    return base / max(total, min_den)

def set_config_from_params(params):
    """Dynamically override config attributes from a dictionary."""
    this_module = sys.modules[__name__]
    for k, v in params.items():
        setattr(this_module, k, v)



# ===========================
# GROUP & REPRESENTATION SETTINGS
# ===========================
num_cores = -1  # or however many threads you want to use

group_name = 'sl2r'               # Options: "u1", "so3", "sl2r", 'su2'.
representation_type = 'irrep'     # Options: 'irrep', 'fundamental', 'adjoint'

use_commutator = False            # use "false" to use the general exp.exp multiplication
debug = True  # Global debug flag for extra logging inside φ updates
debug_sanitize_sigma = True  # Or False by default
                    

# ===========================
# DOMAIN / SPATIAL SETTINGS
# ===========================
K = 15          # Fiber dimension of belief/model space (depends on representation)
                 # Fast up to K=15 then slow
D = 2            #dimension of base manifold - d=2 validated

L = 14         #length of hypercubic base-manifold - PBCs

steps = 100


N = 3                         # Number of agents
max_neighbors = 3             # Max number of agent neighbors

psi_radius_range = (3,3)         #agent radii
             
agent_seed    = 13

identical_models = False         # If True, all agents share the same p, mu_p_field, sigma_p_field
similar_p_models = False
diagonal_covariance = False  # Toggle: if True, Σ is diagonal; if False, use full MVN

debug_gradients = True
log_full_fields = True  # default off
# Use full spatial inverse Fisher metric per point
use_spatial_fisher = True

# ===========================
# COUPLINGS & PENALTIES
# ===========================

e_belief               = 1
e_model                = 1

alpha                  = 74            # OK as is
beta                   = 2.8             # scale down with K
gauge_weight           = 130           # down for stability
curvature_weight       = 555

model_feedback_weight  = 20.6                # OK as is
model_align_weight     = 52
model_mass_weight      = 730
model_curvature_weight = 886

phi_phi_tilde_coupling = 343

phi_damping            = 0                # leave 0 unless blowup occurs

variance_penalty_model_weight = 0
variance_penalty_weight       = 0

fisher_geometry_weight        = 0
fisher_model_geometry_weight  = 0



# ===========================
# AGENT GEOMETRY
# ===========================
q_mu_range    = (0, K - 1)     # Mean of q
q_sigma_range = (1, 2)         # Eigenvalues of Σ_q

p_mu_range    = (0, K - 1)     # Mean of p
p_sigma_range = (0.5, 1.5)         # Eigenvalues of Σ_p

mu_field_smooth_range    = (2, 3)   # lower = noisier
sigma_field_smooth_range = (2, 3)

# Sigma field eigenvalue range
sigma_min_eig = 0.4     # minimum eigenvalue of Σ (lower bound on uncertainty)
sigma_max_eig = 2.0     # maximum eigenvalue of Σ (upper bound on uncertainty)

# Controls how sharply uncertainty grows away from support
sigma_decay_sharpness = 1.0  # passed as sigma to gaussian_filter
sigma_outside_mask_value = 1000.0  # or any large value you prefer



     #Controls how much randomness is added after masking, 
                                      #to avoid wiping out variation. Large for texture
mu_anisotropy_range  = (1, 3)       # 1 = round, 3 = stretched
mu_orientation_range = (0.1, np.pi)     # full angle range
mask_sharpness       = 1.5

# ===========================
# INITIALIZATION
# ===========================
phi_init_smooth_sigma = 1.5
phi_init              = 0.1
phi_model_offset      = 0.1



phi_max_norm = 6.0
phi_model_max_norm = 6.0

phi_grad_clip_threshold       = 1e3
phi_model_grad_clip_threshold = 1e3

phi_clip_threshold = 20  # Optional: to bound exp(φ)
phi_model_clip_threshold = 20

eta_phi_adaptive_scaling = 5.0
eta_sigma_condition_scaling = 0.1  # dampen updates if cond(Σ) is large


eta_base_q         = 2e-6    
eta_base_p         = 2e-6    
eta_base_phi       = 2e-4
eta_base_phi_model = 2e-4    

eta_phi_min        = 1e-3

# ===========================
# STABILITY AND CLIPPING
# ===========================


gradient_clip                 = 1e3  # You can tune this per experiment
epsilon_model                 = 1.0    #detecting meta agents

# ===========================
# EPSILONS & PRECISION
# ===========================

log_eps            = 1e-6  #for logs
support_cutoff_eps = 1e-1           #agent and mask overlap = at 1e-1
overlap_eps        = 1e-3   #where to consider computing overlap computations
eps                = 1e-3   #for SPD clipping



spd_eps = 1e-6
debug_sanitize_sigma = True

precision = np.float32

# ===========================
# CHECKPOINTING
# ===========================

checkpoint_dir      = "checkpoints"

checkpoint_interval = 1

domain_size = (L,) * D

# 3) replace all the old eta_* calculations with calls to scaled_eta
eta_q = scaled_eta(eta_base_q, alpha, beta)

eta_p = scaled_eta(eta_base_p,
                   alpha,
                   model_align_weight,
                   model_feedback_weight,
                  
                   model_mass_weight)

eta_phi = scaled_eta(eta_base_phi,
                     gauge_weight,
                     
                     curvature_weight,
                     phi_phi_tilde_coupling)

eta_model_phi = scaled_eta(eta_base_phi_model,
                           model_align_weight,
                          
                           model_mass_weight,
                           phi_phi_tilde_coupling
                           )


from get_generators import get_generators
generators = get_generators(group_name, K)
lie_dim = generators.shape[0]
