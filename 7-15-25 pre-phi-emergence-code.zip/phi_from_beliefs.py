# -*- coding: utf-8 -*-
"""
Created on Sun Jul 13 10:40:09 2025

@author: chris and christine
"""

# phi_from_beliefs.py
"""
Construct gauge potential \phi from epistemic misalignment between two agents.
This version focuses on metric-compatible transport: \Omega \in O(G), where G is the Fisher information metric
inferred from the belief q_i = N(\mu_i, \Sigma_i).

The goal is to derive a G-skew-symmetric \phi such that:
    exp(\phi) = \Omega aligns q_j to q_i under Fisher geometry.
"""

import numpy as np
from scipy.linalg import logm, expm


def compute_g_skew(phi_init: np.ndarray, G: np.ndarray) -> np.ndarray:
    """
    Project any matrix phi_init to the G-skew-symmetric Lie algebra:
        phi.T @ G + G @ phi = 0

    Args:
        phi_init: (K, K) raw matrix
        G:        (K, K) symmetric positive-definite Fisher metric

    Returns:
        phi:      (K, K) G-skew-symmetric matrix
    """
    G_inv = np.linalg.inv(G)
    phi = 0.5 * (phi_init - G_inv @ phi_init.T @ G)
    return phi


def construct_phi_from_pair(mu_i, sigma_i, mu_j, sigma_j, scale=1.0):
    """
    Estimate \phi such that exp(\phi) transports q_j ~ N(mu_j, sigma_j) to q_i ~ N(mu_i, sigma_i)
    in a way compatible with the Fisher metric G_i = sigma_i^{-1}.

    Args:
        mu_i, mu_j: (K,) mean vectors
        sigma_i, sigma_j: (K, K) covariance matrices
        scale:      float scale factor for perturbation size

    Returns:
        phi_i:      (K, K) G-skew-symmetric Lie algebra element
    """
    K = mu_i.shape[0]
    G_i = np.linalg.inv(sigma_i)

    # Estimate transport direction in tangent space
    delta_mu = (mu_i - mu_j).reshape(K, 1)  # (K, 1)
    phi_init = scale * (delta_mu @ delta_mu.T)  # rank-1 outer product

    # Project to G-skew
    phi = compute_g_skew(phi_init, G_i)
    return phi


def verify_isometry(phi: np.ndarray, G: np.ndarray, atol=1e-6):
    """
    Check whether exp(phi) preserves G: i.e., exp(phi).T @ G @ exp(phi) == G
    """
    Omega = expm(phi)
    return np.allclose(Omega.T @ G @ Omega, G, atol=atol)


# Example (unit test)
if __name__ == "__main__":
    K = 3
    mu_i = np.random.randn(K)
    mu_j = np.random.randn(K)
    A = np.random.randn(K, K)
    sigma_i = A @ A.T + 0.5 * np.eye(K)  # make SPD
    sigma_j = np.eye(K)

    phi = construct_phi_from_pair(mu_i, sigma_i, mu_j, sigma_j)
    G = np.linalg.inv(sigma_i)

    print("phi =\n", phi)
    print("Is exp(phi) a G-isometry?", verify_isometry(phi, G))
