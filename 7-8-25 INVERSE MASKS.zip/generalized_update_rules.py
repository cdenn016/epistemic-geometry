import numpy as np
import config
from joblib import Parallel, delayed

import config
from natural_gradient_utils import (
    apply_natural_gradient_batch,
    apply_lie_natural_gradient,
    sanitize_sigma,
)
from generalized_update_terms import (
    compute_beliefs_gradient,
    compute_models_gradient,
    compute_phi_alignment_gradient,
    compute_phi_model_update,
)
from generalized_omega import exp_lie_algebra_irrep
from joblib import Parallel, delayed

from generalized_update_terms import (
    compute_beliefs_gradient,
    compute_models_gradient,
    compute_phi_alignment_gradient,
    compute_phi_model_update,
)

from generalized_omega import batch_apply_omega

def _compute_all_grads(i, agents, params):
    ai = agents[i]
    return (
        compute_beliefs_gradient(ai, agents, params),
        compute_models_gradient(ai, agents, params),
        compute_phi_alignment_gradient(ai, agents, params),
        compute_phi_model_update(ai, agents, params),
    )

def synchronous_step(agents, generators, params=None, n_jobs=1):
    import config
    from natural_gradient_utils import (
        apply_natural_gradient_batch,
        apply_lie_natural_gradient,
        sanitize_sigma,
    )
    from generalized_update_terms import (
        compute_beliefs_gradient,
        compute_models_gradient,
        compute_phi_alignment_gradient,
        compute_phi_model_update,
    )
    from generalized_omega import exp_lie_algebra_irrep
    from joblib import Parallel, delayed

    params = params or {}
    N = len(agents)

    # 0) Precompute Lie exponentials
    for A in agents:
        A.clear_omega_cache()

        e_belief = params.get("e_belief", config.e_belief)
        e_model  = params.get("e_model",  config.e_model)

        flat_phi       = A.phi.reshape(-1, A.phi.shape[-1]) / e_belief
        flat_phi_model = A.phi_model.reshape(-1, A.phi_model.shape[-1]) / e_model

        A.grid_shape = A.phi.shape[:-1]
        A._exp_phi           = exp_lie_algebra_irrep(flat_phi,       generators)
        A._exp_neg_phi       = exp_lie_algebra_irrep(-flat_phi,      generators)
        A._exp_phi_model     = exp_lie_algebra_irrep(flat_phi_model, generators)
        A._exp_neg_phi_model = exp_lie_algebra_irrep(-flat_phi_model, generators)

    # 1) Snapshot old φ
    phi_old   = [A.phi.copy()       for A in agents]
    phi_m_old = [A.phi_model.copy() for A in agents]
    mask_list = [A.mask             for A in agents]

    # 2) Compute gradients
    def _compute_all_grads(i):
        ai = agents[i]
        return (
            compute_beliefs_gradient(ai, agents, params),
            compute_models_gradient(ai, agents, params),
            compute_phi_alignment_gradient(ai, agents, params),
            compute_phi_model_update(ai, agents, params),
        )

    grads = Parallel(n_jobs=n_jobs, backend="threading")(
        delayed(_compute_all_grads)(i) for i in range(N)
    )
    q_grads, p_grads, phi_grads, phi_m_grads = zip(*grads)

    # 3) Step sizes
    eta_q         = params.get("eta_q",         config.eta_q)
    eta_p         = params.get("eta_p",         config.eta_p)
    eta_phi       = params.get("eta_phi",       config.eta_phi)
    eta_phi_model = params.get("eta_model_phi", config.eta_model_phi)
    G_inv_phi     = params.get("G_inv_phi",     None)
    G_inv_model   = params.get("G_inv_phi_model", None)

    # 4) Apply updates
    for i, agent in enumerate(agents):
        mask = mask_list[i]
        mask_mu    = mask[..., None]
        mask_sigma = mask[..., None, None]

        grad_mu_q,    grad_sigma_q    = q_grads[i]
        grad_mu_p,    grad_sigma_p    = p_grads[i]
        grad_phi,     = (phi_grads[i],)
        grad_phi_m    = phi_m_grads[i]

        # Sanitize Σ
        agent.sigma_q_field = sanitize_sigma(agent.sigma_q_field)
        agent.sigma_p_field = sanitize_sigma(agent.sigma_p_field)

        # --- q update
        delta_mu_q, delta_sigma_q = apply_natural_gradient_batch(
            agent.mu_q_field, agent.sigma_q_field,
            grad_mu_q, grad_sigma_q
        )
        agent.mu_q_field    -= eta_q * delta_mu_q    * mask_mu
        agent.sigma_q_field -= eta_q * delta_sigma_q * mask_sigma

        # --- p update
        delta_mu_p, delta_sigma_p = apply_natural_gradient_batch(
            agent.mu_p_field, agent.sigma_p_field,
            grad_mu_p, grad_sigma_p
        )
        agent.mu_p_field    -= eta_p * delta_mu_p    * mask_mu
        agent.sigma_p_field -= eta_p * delta_sigma_p * mask_sigma  # ✅ FIXED

        # --- φ update
        mask_exp = mask[..., None]
        grad_norm_phi = np.linalg.norm(grad_phi[mask > config.support_cutoff_eps]) + 1e-8
        eta_phi_tuned = np.clip(
            config.eta_base_phi / (1.0 + config.eta_phi_adaptive_scaling * grad_norm_phi),
            config.eta_phi_min,
            config.eta_base_phi
        )
        delta_phi = eta_phi_tuned * apply_lie_natural_gradient(agent.phi, grad_phi, G_inv=G_inv_phi)
        agent.phi -= delta_phi * config.phi_step_scale* mask_exp  # ✅ SIMPLER, NO RESET
#IPUT IN MINUS SIGNS!!! DOUBLE CHECK PHI AND PHI-MODEL UPDATES!!
        # --- φ_model update
        grad_norm_phi_m = np.linalg.norm(grad_phi_m[mask > config.support_cutoff_eps]) + 1e-8
        eta_phi_model_tuned = np.clip(
            eta_phi_model / (1.0 + 0.01 * grad_norm_phi_m),
            1e-6, eta_phi_model
        )
        delta_phi_m = eta_phi_model_tuned * apply_lie_natural_gradient(agent.phi_model, grad_phi_m, G_inv=G_inv_model)
        agent.phi_model -= delta_phi_m * mask_exp  # ✅ SIMPLER, NO RESET

        # Cache for diagnostics
        agent.delta_phi       = delta_phi * mask_exp
        agent.delta_phi_model = delta_phi_m * mask_exp

    return agents
