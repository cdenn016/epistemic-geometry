import numpy as np
from scipy.ndimage import laplace
import numpy as np
import matplotlib.pyplot as plt
from scipy.stats import linregress
from pathlib import Path  # ← required for outdir handling

def mvg_mahalanobis(mu1, sigma1, mu2, sigma2, eps=1e-8):
    """
    Mahalanobis distance between two Gaussians (centered at μ1, Σ1) and (μ2, Σ2)
    """
    diff = mu2 - mu1
    try:
        sigma_inv = np.linalg.inv(sigma1 + eps * np.eye(sigma1.shape[0]))
    except np.linalg.LinAlgError:
        sigma_inv = np.linalg.pinv(sigma1 + eps * np.eye(sigma1.shape[0]))
    return float(np.sqrt(diff.T @ sigma_inv @ diff))


def kl_divergence(mu1, sigma1, mu2, sigma2, log_eps=1e-6):
    """
    Batched KL[𝒩(μ₁, Σ₁) || 𝒩(μ₂, Σ₂)] for full MVG (μ, Σ) fields.

    Parameters:
        mu1:    (N, K)
        sigma1: (N, K, K)
        mu2:    (N, K)
        sigma2: (N, K, K)

    Returns:
        kl_vals: (N,) KL divergence values
    """
    N, K = mu1.shape
    eye = np.eye(K, dtype=mu1.dtype)

    # Regularize Σ
    sigma1_reg = sigma1 + log_eps * eye[None]
    sigma2_reg = sigma2 + log_eps * eye[None]

    # Inverse and determinant
    sigma2_inv = np.linalg.inv(sigma2_reg)

    diff = mu2 - mu1  # (N, K)

    # Trace term: Tr[Σ₂⁻¹ Σ₁]
    trace_term = np.einsum("nij,njk->nik", sigma2_inv, sigma1_reg)
    trace_term = np.trace(trace_term, axis1=-2, axis2=-1)  # (N,)

    # Mahalanobis term: (μ₂ − μ₁)^T Σ₂⁻¹ (μ₂ − μ₁)
    mahal = np.einsum("ni,nij,nj->n", diff, sigma2_inv, diff)

    # Log dets
    sign1, logdet1 = np.linalg.slogdet(sigma1_reg)
    sign2, logdet2 = np.linalg.slogdet(sigma2_reg)

    # Handle sign errors (shouldn't happen with proper SPD)
    logdet1 = np.where(sign1 > 0, logdet1, 0.0)
    logdet2 = np.where(sign2 > 0, logdet2, 0.0)

    kl = 0.5 * (trace_term + mahal - K + logdet2 - logdet1)
    return kl


def laplacian_field(field):
    """Compute component‐wise Laplacian over the last (fiber) axis."""
    return np.stack([laplace(field[..., i]) for i in range(field.shape[-1])], axis=-1)

def masked_norm(field, mask, ord=2):
    """
    Compute the mean over support of ‖field(x)‖ᵒʳᵈ, i.e.
      ∑ₓ ‖field(x)‖ * mask(x)  /  (∑ₓ mask(x))
    """
    norm_vals = np.linalg.norm(field, ord=ord, axis=-1)
    return np.sum(norm_vals * mask) / (np.sum(mask) + 1e-9)

def even_range(min_val, max_val, num_samples):
    """
    Return a list of `num_samples` evenly spaced even integers
    between `min_val` and `max_val`, inclusive if possible.
    """
    # Ensure min and max are even
    if min_val % 2 != 0:
        min_val += 1
    if max_val % 2 != 0:
        max_val -= 1

    # Generate linearly spaced values and round to nearest even
    lin = np.linspace(min_val, max_val, num_samples)
    even_vals = [int(round(x / 2) * 2) for x in lin]

    # Remove duplicates and return sorted list
    return sorted(set(even_vals))

import numpy as np

def safe_log(x, eps: float = 1e-12):
    """
    Numerically stable natural log.

    Parameters
    ----------
    x : float | np.ndarray
        Input value(s). Can be scalar or array-like.
    eps : float, optional
        Values below `eps` are clipped up to `eps` before taking log,
        preventing -inf.  Default is 1e-12.

    Returns
    -------
    np.ndarray | float
        np.log( max(x, eps) ), broadcast over x.
    """
    return np.log(np.clip(x, eps, None))
import warnings

# powerlaw_utils.py  – lightweight fallback
import numpy as np
import matplotlib.pyplot as plt
import config

import numpy as np
from scipy.stats import linregress, multivariate_normal
import config
from pathlib import Path

def reconstruct_density_from_mu_sigma(mu_field, sigma_field):
    """
    Evaluate MVN density q(c) at representative fiber locations.
    Output: array of shape (H, W, K) — approximate marginal over fiber index k.
    """
    from scipy.stats import multivariate_normal

    H, W, K = mu_field.shape
    q = np.zeros((H, W, K), dtype=np.float32)

    # Evaluate at K fiber-representative points: each k-th index as constant vector
    x = np.array([[k] * K for k in range(K)])  # shape (K, K)

    for i in range(H):
        for j in range(W):
            mu = mu_field[i, j]
            Sigma = sigma_field[i, j]

            if not np.all(np.isfinite(Sigma)) or np.linalg.det(Sigma) <= 0:
                continue

            try:
                mvn = multivariate_normal(mean=mu, cov=Sigma, allow_singular=False)
                pdf_vals = mvn.pdf(x)
                pdf_vals = np.clip(pdf_vals, 1e-12, None)
                q[i, j, :] = pdf_vals / pdf_vals.sum()
            except Exception:
                continue

    return q




def zipf_frequencies_from_mu_sigma(mu_field, sigma_field, mask=None):
    """
    Estimate frequency histogram from belief means and covariances.

    Args:
        mu_field: (H, W, K) array of belief means
        sigma_field: (H, W, K, K) array of covariances
        mask: optional (H, W) spatial mask

    Returns:
        freqs: (K,) array of approximate marginal frequencies
    """
    H, W, K = mu_field.shape
    if mask is not None:
        mask = (mask > config.support_cutoff_eps)
        indices = np.argwhere(mask)
        mu_vals = np.array([mu_field[i, j] for i, j in indices])
    else:
        mu_vals = mu_field.reshape(-1, K)

    # Normalize and sum
    freqs = np.sum(mu_vals, axis=0)
    return freqs / np.sum(freqs)


import numpy as np
from scipy.stats import linregress
import matplotlib.pyplot as plt
import config

def zipf_frequencies_from_q(q, mask=None):
    """
    Compute normalized frequency vector from belief field q.

    Args:
        q: (..., K) field of belief vectors (probabilities)
        mask: optional spatial mask (same shape as q[..., 0])

    Returns:
        (K,) array of normalized frequencies
    """
    if mask is not None:
        mask = (mask > config.support_cutoff_eps)
        counts = q[mask]
    else:
        counts = q.reshape(-1, q.shape[-1])
    return counts.sum(axis=0) / counts.sum()


def zipf_slope(freqs, rmin=1, rmax=None):
    freqs = np.asarray(freqs, dtype=float).ravel()
    freqs = -np.sort(-freqs)        # descending
    freqs = freqs[freqs > 0]

    if len(freqs) < 2:
        return 0.0, 0.0

    ranks = np.arange(1, len(freqs) + 1)
    if rmax is None or rmax > len(freqs):
        rmax = len(freqs)

    x = np.log(ranks[rmin-1:rmax])
    y = np.log(freqs[rmin-1:rmax])

    if len(x) < 2:
        return 0.0, 0.0

    slope, intercept, r, *_ = linregress(x, y)
    return slope, r**2



def rank_frequency_plot(freqs, ax=None, **kwargs):
    """
    Plot a rank-frequency curve. Accepts optional matplotlib kwargs.

    Args:
        freqs: frequency array (should already be sorted descending)
        ax: optional matplotlib axis

    Returns:
        ax: the axis with the plot
    """
    if ax is None:
        ax = plt.gca()
    ranks = np.arange(1, len(freqs) + 1)
    ax.loglog(ranks, freqs, marker='o', linestyle='', **kwargs)
    ax.set_xlabel("Rank")
    ax.set_ylabel("Frequency")
    return ax


def zipf_frequencies_from_mu_sigma(mu_field, sigma_field, mask=None):
    """
    Return normalized marginal frequencies across fiber (K,) from belief or model field.
    """
    q = reconstruct_density_from_mu_sigma(mu_field, sigma_field)
    if mask is not None:
        support = mask > config.support_cutoff_eps
        q = q[support]
    else:
        q = q.reshape(-1, q.shape[-1])
    return q.sum(axis=0) / q.sum()


def zipf_slope(freqs, rmin=1, rmax=None):
    """
    Compute Zipf slope and R² from marginal frequencies.
    """
    freqs = np.asarray(freqs, dtype=float).ravel()
    freqs = -np.sort(-freqs)        # sort descending
    freqs = freqs[freqs > 0]

    if len(freqs) < 2:
        return 0.0, 0.0

    ranks = np.arange(1, len(freqs) + 1)
    if rmax is None or rmax > len(freqs):
        rmax = len(freqs)

    x = np.log(ranks[rmin-1:rmax])
    y = np.log(freqs[rmin-1:rmax])

    slope, intercept, r, *_ = linregress(x, y)
    return slope, r**2


def rank_frequency_plot(freqs, ax=None, **kwargs):
    """
    Plot a rank-frequency curve (Zipf plot). Accepts optional matplotlib kwargs.
    """
    if ax is None:
        ax = plt.gca()
    ranks = np.arange(1, len(freqs) + 1)
    ax.loglog(ranks, freqs, marker='o', linestyle='', **kwargs)
    ax.set_xlabel("Rank")
    ax.set_ylabel("Frequency")
    return ax


import numpy as np

def fit_moments(q: np.ndarray, mask: np.ndarray):
    """
    Compute the per-pixel mean and full covariance matrices
    for a multivariate distribution q(c) over K-dimensional fibers.

    Parameters:
      q:     ndarray of shape (H, W, K) — belief distribution at each pixel
      mask:  ndarray of shape (H, W) — boolean or float mask for agent support

    Returns:
      mu:    ndarray of shape (H, W, K) — mean vector per spatial point
      cov:   ndarray of shape (H, W, K, K) — covariance matrix per spatial point
    """
    H, W, K = q.shape
    x = np.eye(K, dtype=q.dtype)          # (K, K)
    x_exp = x[None, None, :, :]           # (1, 1, K, K)
    q_exp = q[..., :, None]               # (H, W, K, 1)

    # μ = E[x]
    mu = np.sum(q_exp * x_exp, axis=2)    # (H, W, K)

    # x_k - μ for each k: (H, W, K, K)
    diff = x_exp - mu[:, :, None, :]      # (H, W, K, K)

    # Outer product: (x_k - μ)(x_k - μ)^T → (H, W, K, K, K)
    outer = diff[..., :, None] * diff[..., None, :]  # (H, W, K, K, K)

    # Weight by q_k and sum over k
    q_reshaped = q[..., :, None, None]    # (H, W, K, 1, 1)
    cov = np.sum(q_reshaped * outer, axis=2)  # (H, W, K, K)

    mu[~mask] = 0.0
    cov[~mask] = 0.0

    return mu, cov

import numpy as np
from numpy.linalg import LinAlgError

def is_spd_matrix(A: np.ndarray, tol=1e-8) -> bool:
    """
    Check whether a matrix A is symmetric positive definite (SPD).
    """
    if not np.allclose(A, A.T, atol=tol):
        return False
    try:
        np.linalg.cholesky(A)
        return True
    except LinAlgError:
        return False

