from __future__ import annotations

"""
Created on Tue Aug 12 20:15:47 2025

@author: chris and christine
"""
import time
from joblib import Parallel, delayed
import numpy as np
import core.config as config
from core.omega import d_exp_phi_exact, d_exp_phi_tilde_exact

from core.numerical_utils import safe_omega_inv    
from transport.bundle_morphism_utils import mark_morphism_dirty
from core.omega import exp_lie_algebra_irrep
from transport.transport_cache import E_grid  
from updates.update_terms_phi import ( 
    accumulate_phi_morphism_self_feedback, accumulate_phi_alignment_gradient,
    grad_feedback_phi_direct, grad_feedback_phi_tilde_direct, grad_self_phi_direct,
    grad_self_phi_tilde_direct)

from updates.update_terms_mu_sigma import accumulate_mu_sigma_gradient
from transport.preprocess_utils import zero_all_gradients
from core.omega import retract_phi_principal
from core.numerical_utils import sanitize_sigma

from updates.update_refresh_utils import mark_dirty





# unified metadata for phi vs phi_tilde blocks
_FIELD_META = {
    "phi": {
        "which": "q",
        "beta_key": "beta",
        "mu_key": "mu_q_field",
        "sigma_key": "sigma_q_field",
        "fisher_inv_key": "inverse_fisher_phi",
        "grad_key": "grad_phi",
        "phi_attr": "phi",
        "qall_func": d_exp_phi_exact,
    },
    "phi_model": {
        "which": "p",
        "beta_key": "beta_model",
        "mu_key": "mu_p_field",
        "sigma_key": "sigma_p_field",
        "fisher_inv_key": "inverse_fisher_phi_model",
        "grad_key": "grad_phi_tilde",
        "phi_attr": "phi_model",
        "qall_func": d_exp_phi_tilde_exact,
    },
}

def _alignment_block(agent_i, neighbors, generators, params, *, field: str, ctx):
    """
    Compute same-level alignment gradients for 'phi' or 'phi_model'.
    """
    if not neighbors:
        return 0.0

    meta = _FIELD_META[field]
    t0 = time.perf_counter()

    # Q_all for agent_i once
    phi_i = getattr(agent_i, meta["phi_attr"])
    Q_all_i = meta["qall_func"](phi_i, generators)

    # loop neighbors
    for agent_j in neighbors:

        # Build exp(-φ_j) from central cache if available, else local
        if ctx is not None:
            Ej = E_grid(ctx, agent_j, which=meta["which"])
            exp_neg_phi_j = safe_omega_inv(Ej, eps=getattr(config, "eps", 1e-6), debug=False)
        else:
            phi_j = getattr(agent_j, meta["phi_attr"])
            Ej = exp_lie_algebra_irrep(phi_j, generators)
            exp_neg_phi_j = safe_omega_inv(Ej, eps=getattr(config, "eps", 1e-6), debug=False)

        # accumulate alignment grad
        accumulate_phi_alignment_gradient(
            agent_i, agent_j, generators, params,
            field=field,
            beta_key=meta["beta_key"],
            omega_cache_key=None,                   # ctx handles caching centrally
            mu_key=meta["mu_key"],
            sigma_key=meta["sigma_key"],
            fisher_inv_key=meta["fisher_inv_key"],
            grad_key=meta["grad_key"],
            Q_all_i=Q_all_i,
            exp_neg_phi_j=exp_neg_phi_j,
            agents=None,                            # pass if your impl needs it; else None is fine
        )
        
    return time.perf_counter() - t0

def _morphism_block(agent_i, generators_q, generators_p, params, *, field: str):
    meta = _FIELD_META[field]
    t0 = time.perf_counter()

    if field == "phi":
        accumulate_phi_morphism_self_feedback(
            agent_i, generators_p, generators_q, params,
            field="phi",
            fisher_inv_key=meta["fisher_inv_key"],
            grad_key=meta["grad_key"],
            phi_self_func=grad_self_phi_direct,
            phi_feedback_func=grad_feedback_phi_direct,
        )
    else:
        accumulate_phi_morphism_self_feedback(
            agent_i, generators_p, generators_q, params,
            field="phi_model",
            fisher_inv_key=meta["fisher_inv_key"],
            grad_key=meta["grad_key"],
            phi_self_func=grad_self_phi_tilde_direct,
            phi_feedback_func=grad_feedback_phi_tilde_direct,
        )

    return time.perf_counter() - t0


# -----------------------------------
# Disentangled gradient orchestrator
# -----------------------------------
def compute_all_gradients(agent_i, agents, all_agents, generators_q, generators_p, params, runtime_ctx=None):
    """
    Single-scale gradient orchestrator (no parents / no cross-scale).

      Phase 0: thread runtime ctx
      Phase 1: μ, Σ (belief/model) — same-level only
      Phase 2: (optional) warm local caches for agent_i + neighbors
      Phase 3: φ alignment (belief + model), same-level only
      Phase 4: morphism self + feedback (φ, φ̃), same-level
      Phase 5: return gradients
    """
    

    # -------- Phase 0 — ctx --------
    params, ctx = _thread_ctx(params, runtime_ctx)

    # reset grads, timers
    zero_all_gradients(agent_i)
    timings = {}

    # -------- Phase 1 — μ, Σ (same-level only) --------
    t0 = time.perf_counter()
    accumulate_mu_sigma_gradient(agent_i, agents, params, mode="belief")
    timings["mu_sigma_belief"] = time.perf_counter() - t0

    t0 = time.perf_counter()
    accumulate_mu_sigma_gradient(agent_i, agents, params, mode="model")
    timings["mu_sigma_model"] = time.perf_counter() - t0

    # -------- Phase 2 — (optional) warm caches for neighbors --------
    neighbors = _get_neighbors(agent_i, agents)
    # NOTE: keep lightweight to avoid global cache churn; most callers already ensured tc_E / tc_Omega warm paths.

    # -------- Phase 3 — φ alignment (same-level only) --------
    if neighbors:
        dt = _alignment_block(agent_i, neighbors, generators_q, params, field="phi", ctx=ctx)
        timings["phi_alignment"] = dt

        dt = _alignment_block(agent_i, neighbors, generators_p, params, field="phi_model", ctx=ctx)
        timings["phi_tilde_alignment"] = dt

    # -------- Phase 4 — morphism self + feedback (same-level) --------
    dt = _morphism_block(agent_i, generators_q, generators_p, params, field="phi")
    timings["phi_morphism"] = dt

    dt = _morphism_block(agent_i, generators_q, generators_p, params, field="phi_model")
    timings["phi_tilde_morphism"] = dt

    if getattr(config, "debug_grad_timing", False):
        print(f"\n[GRAD TIMINGS] Agent {agent_i.id}")
        for k, v in timings.items():
            print(f"  {k:22s} : {v*1e3:7.2f} ms")

    # -------- Phase 5 — return --------
    return (
        (agent_i.grad_mu_q, agent_i.grad_sigma_q),
        (agent_i.grad_mu_p, agent_i.grad_sigma_p),
        agent_i.grad_phi,
        agent_i.grad_phi_tilde,
        
    )



def apply_phi_updates(agent, grad_phi, grad_phi_m, mask, params, *, ctx=None,
                      strict_numerics: bool = True,
                      recover: str | None = None):   # None | "nan" | "zero"
    """
    Constant-step φ / φ̃ update (no adaptive eta).
    Policies:
      - strict_numerics=True: raise on nonfinite grads/updates.
      - strict_numerics=False with recover: return sentinel deltas per policy.
    """

    # --- capture raw grads for diagnostics (as given)
    agent.grad_phi       = None if grad_phi   is None else np.array(grad_phi,   copy=True)
    agent.grad_phi_tilde = None if grad_phi_m is None else np.array(grad_phi_m, copy=True)

    # --- soft mask (optional)
    def _soft_mask(m):
        m = np.clip(np.asarray(m, np.float32), 0.0, 1.0)
        sigma = float(getattr(config, "mask_edge_soften_sigma", 0.0))
        if sigma <= 0.0:
            return m
        try:
            from scipy.ndimage import gaussian_filter
            return np.clip(gaussian_filter(m, sigma=sigma, mode="wrap"), 0.0, 1.0)
        except Exception:
            # lightweight 4-neighbor smoothing fallback
            out = m.copy()
            for _ in range(3):
                nb = (np.roll(out, 1, 0) + np.roll(out, -1, 0) +
                      np.roll(out, 1, 1) + np.roll(out, -1, 1)) * 0.25
                out = 0.5 * out + 0.5 * nb
            return np.clip(out, 0.0, 1.0)

    mexp = _soft_mask(mask).astype(np.float32)[..., None]  # (H,W,1)

    # --- fixed learning rates
    eta_phi   = float(params.get("tau_phi",       getattr(config, "tau_phi",       1e-3)))
    eta_phi_m = float(params.get("tau_phi_model", getattr(config, "tau_phi_model", 1e-3)))

    # --- per-pixel grad-norm clipping
    clip_phi   = float(getattr(config, "gradient_clip_phi",       1.0))
    clip_phi_m = float(getattr(config, "gradient_clip_phi_model", 1.0))

    phi      = np.asarray(getattr(agent, "phi"),       np.float32)
    phi_m    = np.asarray(getattr(agent, "phi_model"), np.float32)
    H, W, D  = phi.shape
    assert D == 3, f"agent.phi last dim must be 3, got {phi.shape}"

    def _clip_vecnorm(v, thr, like_shape):
        if v is None:
            return np.zeros(like_shape, dtype=np.float32)
        v = np.asarray(v, np.float32)
        if thr > 0.0:
            n = np.linalg.norm(v, axis=-1, keepdims=True)  # (...,1)
            # scale safely where n>0
            scale = np.where(n > thr, thr / np.maximum(n, 1e-8), 1.0).astype(np.float32)
            v = v * scale
        return v

    # --- clip to thresholds (and coerce None → zeros_like current fields)
    g_phi  = _clip_vecnorm(grad_phi,   clip_phi,   phi.shape)
    g_phim = _clip_vecnorm(grad_phi_m, clip_phi_m, phi_m.shape)

    # overwrite diag snapshots with the **clipped** versions (what we actually apply)
    agent.grad_phi       = np.array(g_phi,  copy=True)
    agent.grad_phi_tilde = np.array(g_phim, copy=True)

    # --- strict finite checks on grads (no in-kernel masking)
    def _finite_or_recover(x, name):
        if np.all(np.isfinite(x)):
            return x
        if strict_numerics:
            raise FloatingPointError(f"apply_phi_updates: nonfinite {name} detected.")
        if recover is None or recover == "nan":
            return np.full_like(x, np.nan, dtype=np.float32)
        if recover == "zero":
            return np.zeros_like(x, dtype=np.float32)
        raise ValueError(f"Unknown recover policy: {recover}")

    g_phi  = _finite_or_recover(g_phi,  "grad_phi")
    g_phim = _finite_or_recover(g_phim, "grad_phi_model")

    # --- apply fixed steps (mask-aware); no nan_to_num
    delta_phi   = (eta_phi   * g_phi ).astype(np.float32, copy=False) * mexp
    delta_phi_m = (eta_phi_m * g_phim).astype(np.float32, copy=False) * mexp

    # If deltas are nonfinite, obey policy
    delta_phi   = _finite_or_recover(delta_phi,   "delta_phi")
    delta_phi_m = _finite_or_recover(delta_phi_m, "delta_phi_model")

    phi_new  = phi   - delta_phi
    phim_new = phi_m - delta_phi_m

    # --- retract to principal SO(3) chart (uses strict retract we fixed earlier)
    margin = float(getattr(config, "so3_principal_margin",
                           getattr(config, "phi_principal_margin", 1e-4)))
    agent.phi       = retract_phi_principal(phi_new,  margin=margin)
    agent.phi_model = retract_phi_principal(phim_new, margin=margin)

    # --- notify runtime that transports/metrics are dirty; no direct warming here
    if ctx is not None:
        mark_dirty(ctx, agent, kl=True)

    # retain for legacy logs
    agent._eta_phi_prev   = eta_phi
    agent._eta_phi_m_prev = eta_phi_m

    if params.get("DEBUG_APPLY", False):
        mean_gphi  = float(np.nanmean(np.linalg.norm(g_phi,  axis=-1)))
        mean_gphim = float(np.nanmean(np.linalg.norm(g_phim, axis=-1)))
        print(f"[APPLY φ-step] id={getattr(agent,'id',None)} "
              f"τφ={eta_phi:g}, τφ̃={eta_phi_m:g}, "
              f"|gφ|_mean={mean_gphi:.3e}, |gφ̃|_mean={mean_gphim:.3e}",
              flush=True)


def _apply_sigma_masked(old_S, dS, tau, mask_bool):
    mask3 = mask_bool[..., None, None]
    S = old_S.astype(np.float64, copy=False)
    Δ = (tau * dS).astype(np.float64, copy=False)

    # eig of S (per-pixel)
    w, Q = np.linalg.eigh(S)
    eps = float(getattr(config, "eps", 1e-8))
    w = np.clip(w, eps, None)
    Winvhalf = 1.0 / np.sqrt(w)

    # map Δ to relative coords: R = Σ^{-1/2} Δ Σ^{-1/2}
    # (per-pixel batched similarity transform)
    Δeig = np.einsum("...ik,...kl,...jl->...ij", np.swapaxes(Q, -1, -2), Δ, Q, optimize=True)
    R = (Winvhalf[..., :, None] * Δeig) * Winvhalf[..., None, :]

    # trust region on ||R||_F
    rho = float(getattr(config, "sigma_rel_step_max", 0.25))  # ≤ 0.25 is very safe
    Rnorm = np.linalg.norm(R.reshape(*R.shape[:-2], -1), axis=-1, keepdims=True)  # (...,1)
    scale = np.minimum(1.0, rho / np.maximum(Rnorm, eps))
    R *= scale[..., None]   # broadcast over matrix dims

    # map back: Δ_scaled = Σ^{1/2} R Σ^{1/2}
    Winhalf = np.sqrt(w)
    Δeig_scaled = (Winhalf[..., :, None] * R) * Winhalf[..., None, :]
    Δ_scaled = np.einsum("...ik,...kl,...jl->...ij", Q, Δeig_scaled, np.swapaxes(Q, -1, -2), optimize=True)

    S_new = S + Δ_scaled
    S_new = 0.5 * (S_new + np.swapaxes(S_new, -1, -2))
    S_new = sanitize_sigma(S_new.astype(np.float32, copy=False), eps=eps)  # your sanitizer

    return np.where(mask3, S_new, old_S)


def _apply_children(agents, grads, params, frozen_levels, frozen_phi_levels, Gq, Gp, n_jobs, *, ctx=None):
    import numpy as np
    import core.config as config
    

    def _nz(x, dflt):
        try:
            x = float(x)
        except Exception:
            return float(dflt)
        if (x == 0.0) or (not np.isfinite(x)):
            return float(dflt)
        return float(x)

    # τ with defensive fallbacks
    tau_mu_belief    = _nz(params.get("tau_mu_belief",    getattr(config, "tau_mu_belief",    1e-3)), 1e-3)
    tau_sigma_belief = _nz(params.get("tau_sigma_belief", getattr(config, "tau_sigma_belief", 1e-3)), 1e-3)
    tau_mu_model     = _nz(params.get("tau_mu_model",     getattr(config, "tau_mu_model",     1e-3)), 1e-3)
    tau_sigma_model  = _nz(params.get("tau_sigma_model",  getattr(config, "tau_sigma_model",  1e-3)), 1e-3)

    (q_updates, p_updates, phi_grads, phi_m_grads) = grads
    masks = [A.mask for A in agents]
    eps = float(getattr(config, "eps", 1e-8))
    DEBUG_APPLY = bool(params.get("DEBUG_APPLY", False))

       

    def _one(i):
        A = agents[i]
        level = int(getattr(A, "level", 0))
        mask = np.asarray(masks[i], np.float32)
        mask_mu    = mask[..., None]
        mask_sigma = mask[..., None, None]

        dmu_q, dsg_q = q_updates[i]
        dmu_p, dsg_p = p_updates[i]
        if dmu_q is None: dmu_q = np.zeros_like(A.mu_q_field,  dtype=np.float32)
        if dsg_q is None: dsg_q = np.zeros_like(A.sigma_q_field,dtype=np.float32)
        if dmu_p is None: dmu_p = np.zeros_like(A.mu_p_field,  dtype=np.float32)
        if dsg_p is None: dsg_p = np.zeros_like(A.sigma_p_field,dtype=np.float32)

        did_phi = False

        # ---- μ, Σ updates (masked) ----
        if level not in frozen_levels:
            mu_q_old = A.mu_q_field
            mu_p_old = A.mu_p_field

            A.mu_q_field = mu_q_old + (tau_mu_belief * dmu_q * mask_mu).astype(np.float32, copy=False)
            A.mu_p_field = mu_p_old + (tau_mu_model  * dmu_p * mask_mu).astype(np.float32, copy=False)

            A.sigma_q_field = _apply_sigma_masked(A.sigma_q_field, dsg_q, tau_sigma_belief, mask > 0.0)
            A.sigma_p_field = _apply_sigma_masked(A.sigma_p_field, dsg_p, tau_sigma_model,  mask > 0.0)

           # _sanitize_sigma_field_inplace(A.sigma_q_field, rel_floor=1e-5, cond_cap=1e3, name="Σ_q", debug=False)
           # _sanitize_sigma_field_inplace(A.sigma_p_field, rel_floor=1e-5, cond_cap=1e3, name="Σ_p", debug=False)

             
            if DEBUG_APPLY:
                dmuq_mean = float(np.mean(np.abs(A.mu_q_field - mu_q_old)))
                dmup_mean = float(np.mean(np.abs(A.mu_p_field - mu_p_old)))
                print(f"[APPLY μ] id={getattr(A,'id',i)} |Δμ_q|_mean={dmuq_mean:.3e} |Δμ_p|_mean={dmup_mean:.3e} "
                      f"(τ_q={tau_mu_belief:g}, τ_p={tau_mu_model:g})", flush=True)

        

        # ---- φ updates (masked inside) ----
        if level not in frozen_phi_levels:
            gp  = phi_grads[i];   gp  = np.zeros_like(A.phi,       dtype=np.float32) if gp  is None else gp
            gpm = phi_m_grads[i]; gpm = np.zeros_like(A.phi_model, dtype=np.float32) if gpm is None else gpm

            phi_old  = A.phi.copy()
            phim_old = A.phi_model.copy()

            apply_phi_updates(A, gp, gpm, mask, params, ctx=ctx)
            did_phi = True

            if DEBUG_APPLY:
                dphi_mean  = float(np.mean(np.linalg.norm(A.phi       - phi_old,  axis=-1)))
                dphim_mean = float(np.mean(np.linalg.norm(A.phi_model - phim_old, axis=-1)))
                print(f"[APPLY φ] id={getattr(A,'id',i)} |Δφ|_mean={dphi_mean:.3e} |Δφ̃|_mean={dphim_mean:.3e} "
                      f"(τφ={params.get('tau_phi', getattr(config,'tau_phi',1e-3))}, "
                      f"τφ̃={params.get('tau_phi_model', getattr(config,'tau_phi_model',1e-3))})",
                      flush=True)

        if did_phi:
            mark_morphism_dirty(A)

    Parallel(n_jobs=n_jobs, backend="threading", batch_size="auto")(
        delayed(_one)(i) for i in range(len(agents))
    )

    



def _compute_child_grads(agents, all_agents, Gq, Gp, params):
    """
    Batch-compute child gradients.
    Returns 4 lists: belief_grads, model_grads, phi_grads, phi_tilde_grads.
    """
    if not agents:
        # keep shape expectations: return empty lists for the 4 groups
        return ([], [], [], [])

    params_x = dict(params or {})
    ctx = params_x.get("runtime_ctx", None)
    n_jobs = max(1, min(int(getattr(config, "n_jobs", 1)), len(agents)))

    def _safe_compute(Ai):
        try:
            out = compute_all_gradients(
                Ai, agents, all_agents, Gq, Gp, params_x, runtime_ctx=ctx
            )
            # Backward tolerance: some places may still return 6-tuple.
            # We only keep the first 4 (μ/Σ for q, μ/Σ for p, φ, φ̃).
            if isinstance(out, tuple) and len(out) >= 4:
                return out[:4]
            raise RuntimeError("Unexpected return shape from compute_all_gradients")
        except Exception:
            # Fallback: shaped NaNs so failures are visible upstream.
            Kq = Ai.sigma_q_field.shape[-1]
            Kp = Ai.sigma_p_field.shape[-1]
            H, W = Ai.mask.shape[:2]
            nan = np.nan
            q_grads = (np.full((H, W, Kq), nan, np.float32),
                       np.full((H, W, Kq, Kq), nan, np.float32))
            p_grads = (np.full((H, W, Kp), nan, np.float32),
                       np.full((H, W, Kp, Kp), nan, np.float32))
            g_phi   = np.full_like(Ai.phi,       nan, np.float32)
            g_phim  = np.full_like(Ai.phi_model, nan, np.float32)
            print("safe-compute exception in _compute_child_grads; returning NaNs")
            return (q_grads, p_grads, g_phi, g_phim)

    results = Parallel(
        n_jobs=n_jobs,
        backend="threading",
        prefer="threads",
        batch_size="auto",
    )([delayed(_safe_compute)(Ai) for Ai in agents])

    # unzip -> lists
    q_updates, p_updates, phi_grads, phi_m_grads = zip(*results)
    return (list(q_updates), list(p_updates), list(phi_grads), list(phi_m_grads))


def _sanitize_sigma_field_inplace(S, abs_floor=1e-8, rel_floor=1e-6, cond_cap=1e3, name="Σ", debug=False):
    """
    In-place SPD sanitize for field S[..., K, K].
    Guarantees per-pixel cond(Σ) <= cond_cap by construction; if any pixel
    still violates due to numerical issues, falls back to isotropic clamp.

    DO NOT assign the return value; this mutates S[:] in-place.
    """
    import numpy as np

    # Make sure we can write
    if not np.asarray(S).flags.writeable:
        # If the backing array is read-only or a view into a read-only buffer,
        # replace in-place contents via .[...] assignment only; else raise.
        raise RuntimeError(f"{name} array is not writeable; cannot sanitize in-place")

    Sd = np.asarray(S, dtype=np.float64)
    Sd = 0.5 * (Sd + np.swapaxes(Sd, -1, -2))

    # Eigen decomposition per pixel
    w, V = np.linalg.eigh(Sd)                                  # w: (...,K), V: (...,K,K)

    # Floors based on scale (median eigenvalue) and absolute floor
    scale = np.median(w, axis=-1, keepdims=True)               # (...,1)
    floor = np.maximum(abs_floor, rel_floor * np.maximum(scale, 1.0))  # (...,1)

    # Window based on current w_max and cond_cap
    w_max = np.max(w, axis=-1, keepdims=True)                  # (...,1)
    w_min_target = np.maximum(floor, w_max / float(cond_cap))  # (...,1)
    lo = w_min_target
    hi = w_min_target * float(cond_cap)

    # Clamp into [lo, hi]
    w_clamped = np.clip(w, lo, hi)

    # Reconstruct
    S_new = (V * w_clamped[..., None, :]) @ np.swapaxes(V, -1, -2)
    S_new = S_new.astype(np.float32, copy=False)

    # Write back in-place
    S[:] = S_new

    # Verify; if any pixel still violates, overwrite that pixel with isotropic clamp
    Ssym = 0.5 * (S + np.swapaxes(S, -1, -2))
    wchk = np.linalg.eigvalsh(Ssym)
    wmin = np.min(wchk, axis=-1)
    wmax = np.max(wchk, axis=-1)
    cond = wmax / np.maximum(wmin, 1e-12)

    bad_mask = cond > (1.02 * float(cond_cap))  # small tolerance
    if np.any(bad_mask):
        if debug:
            print(f"[SANITIZE {name}] {int(np.sum(bad_mask))} pixels exceeded cond cap; applying isotropic fallback")
        # Build per-pixel isotropic with λ = max(floor, wmax/cond_cap)
        wmax_bad = wmax[bad_mask]
        floor_bad = np.maximum(abs_floor, rel_floor * np.maximum(np.median(wchk[bad_mask], axis=-1), 1.0))
        lam = np.maximum(floor_bad, wmax_bad / float(cond_cap)).astype(np.float32)
        # Broadcast an identity per bad pixel
        K = S.shape[-1]
        I = np.eye(K, dtype=np.float32)
        # Fancy indexing into the last two dims: set bad pixels to lam * I
        S_view = S.reshape(-1, K, K)
        bad_idx = np.nonzero(bad_mask.reshape(-1))[0]
        for idx, l in zip(bad_idx, lam):
            S_view[idx, :, :] = l * I

    if debug:
        # Final report
        Ssym = 0.5 * (S + np.swapaxes(S, -1, -2))
        wchk = np.linalg.eigvalsh(Ssym)
        wmin = np.min(wchk, axis=-1)
        wmax = np.max(wchk, axis=-1)
        cond = wmax / np.maximum(wmin, 1e-12)
        print(f"[SANITIZE {name}] post: λmin={float(wmin.min()):.2e} λmax={float(wmax.max()):.2e} cond_max={float(cond.max()):.1f}")



# ---------------------------
# Local helpers (file-local)
# ---------------------------

def _thread_ctx(params, runtime_ctx):
    params = {} if params is None else dict(params)
    if runtime_ctx is not None:
        params["runtime_ctx"] = runtime_ctx
    return params, params.get("runtime_ctx", None)

def _get_neighbors(agent_i, agents):
    nbs = getattr(agent_i, "neighbors", []) or []
    if isinstance(agents, dict):
        lookup = {int(k): v for k, v in agents.items()}
    else:
        lookup = {int(getattr(a, "id", i)): a for i, a in enumerate(agents)}
    out = []
    for nb in nbs:
        try:
            j = int(nb.get("id"))
        except Exception:
            continue
        a = lookup.get(j)
        if a is not None:
            out.append(a)
    return out



