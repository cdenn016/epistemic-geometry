# generalized_simulation.py
import os
os.environ["OMP_NUM_THREADS"] = "1"
os.environ["MKL_NUM_THREADS"] = "1"
os.environ["NUMEXPR_NUM_THREADS"] = "1"
os.environ["OPENBLAS_NUM_THREADS"] = "1"
import sys
ROOT = os.path.dirname(os.path.abspath(__file__))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

import sys, time, pickle
import core.config as config

from updates.update_rules import synchronous_step
from run_sim_utils import (
    prepare_generators, merge_logging_cfg, initialize_or_resume,
    ensure_runtime, log_and_viz_after_step,
    wrap_epilogue, save_step
)



def run_simulation(
    outdir="checkpoints", 
    resume=False,
    log_metrics=True,
    log_fields=True,
    num_cores=None,
    params=None,
    fresh_outdir=False,
    clear_agent_logs=True,
):
   
    # params + cores
    try:
        import multiprocessing as _mp
        _avail = max(1, (_mp.cpu_count() or 1) - 1)
    except Exception:
        _avail = 8

    num_cores = _avail if num_cores is None else int(num_cores)
    num_cores = max(1, num_cores)

    params = {} if params is None else dict(params)

    config.n_jobs = num_cores

    # generators
    G_q, G_p = prepare_generators(params)

    
    # Keep init paths consistent with the actual generators
    import numpy as np
    Kq, Kp = int(np.asarray(G_q).shape[1]), int(np.asarray(G_p).shape[1])
    config.K_q, config.K_p = Kq, Kp


    # logging cfg
    logcfg = merge_logging_cfg(params if isinstance(params, dict) else vars(config))
    if not log_metrics: logcfg["enable_scalar"] = False
    if not log_fields:  logcfg["enable_fields"] = False
    if logcfg.get("enable_fields", False):
        os.makedirs(os.path.join(outdir, logcfg["full_field_outdir"]), exist_ok=True)

    # init or resume
    agents, step_start = initialize_or_resume(outdir, resume, params, clear_agent_logs=clear_agent_logs)

    # runtime context (mounted lvl-1 view)
    runtime_ctx = ensure_runtime(params)
    runtime_ctx.global_step = step_start  # initialize step index
    params["runtime_ctx"] = runtime_ctx   # expose ctx via params for legacy helpers

    # Early-exit if resuming past the configured steps
    if step_start >= int(getattr(config, "steps", step_start)):
        wrap_epilogue(runtime_ctx, agents, outdir, [], [])
        print("[DONE] Nothing to do: resume step >= total steps.")
        return agents, []

    # trackers
    parent_metrics, metric_log = [], []
    print(f"[RUN] Starting simulation at step {step_start} with {num_cores if (num_cores is not None) else 'auto'} cores")

    for step in range(step_start, config.steps):
        # keep global_step in sync BEFORE core update so gates use it
        runtime_ctx.global_step = step
        runtime_ctx.dirty.reset_step(step)
                
        print(f"\n[STEP {step}] -----------------------------\n")
        t0 = time.perf_counter()
        step_params = {**params, "step": step, "sanitize_strict_pre": False}

        # core synchronous update (ctx is threaded inside)
        agents = synchronous_step(
            agents, G_q, G_p,
            params=step_params,
            n_jobs=num_cores,
            runtime_ctx=runtime_ctx,
        )

        print(f"[TIMER] synchronous update: {time.perf_counter() - t0:.3f}s")

        # --- cache stats probe every 5 steps ---
        # --- cache stats probe every 5 steps ---
        try:
            if step % 1 == 0:
                tc = getattr(runtime_ctx, "cache", None)
                if tc is not None and hasattr(tc, "full_stats"):
                    print("[cache]", tc.full_stats())
                _probe_omega_kl(runtime_ctx, agents, which="q")
                _probe_alignment_kl_grid(runtime_ctx, agents, which="q")
                _probe_sigma_health(agents)

        except Exception as e:
            print(f"[cache] stats/probe failed: {e}")

        # viz & metrics
        runtime_ctx.children_latest   = agents
 
        
 
        log_and_viz_after_step(runtime_ctx, agents, step, outdir, params, logcfg,
                               parent_metrics, metric_log, num_cores)
 
        save_step(agents, outdir, step)
        print(f"[SAVE] Checkpoint --> {outdir}/step_{step:04d}.pkl")

    # epilogue
    wrap_epilogue(runtime_ctx, agents, outdir, parent_metrics, metric_log)
    print("[DONE] Simulation completed.")
    return agents, metric_log



def _spd_sanitize(S, eps=1e-8):
    """
    Symmetrize and floor eigenvalues per pixel so Cholesky is safe.
    S: (..., K, K)
    """
    import numpy as np
    S = 0.5 * (S + np.swapaxes(S, -1, -2))
    w, V = np.linalg.eigh(S)
    w = np.maximum(w, eps)
    return (V * w[..., None, :]) @ np.swapaxes(V, -1, -2)


def _pick_overlap_pixel(Ai, Aj, eps=None, interior_margin=0.05):
    import numpy as np
    import core.config as config

    if eps is None:
        eps = float(getattr(config, "support_cutoff_eps", 1e-3))

    m = (np.asarray(Ai.mask) > eps) & (np.asarray(Aj.mask) > eps)
    if not np.any(m):
        raise RuntimeError("No overlap between the chosen pair")

    # Prefer interior pixels (higher joint weight) to avoid boundary flicker
    w = np.minimum(Ai.mask, Aj.mask)
    w = np.where(m, w, 0.0)
    thresh = interior_margin * (w.max() if np.any(w) else 1.0)
    m_int = m & (w >= thresh)
    if not np.any(m_int):
        m_int = m  # fallback to any overlap

    r, c = np.argwhere(m_int)[0]
    return int(r), int(c)


def _probe_alignment_kl_grid(ctx, agents, which="q"):
    """Scan a couple of neighbor pairs; compute KL(Ai || Ω Aj) over overlap pixels.
    SPD-sanitizes both Σ_i and Σ'_j, and uses triangular solves for Σ^{-1}."""
    import numpy as np
    from transport.transport_cache import Omega
    import core.config as config

    eps = float(getattr(config, "support_cutoff_eps", 1e-3))
    printed = 0

    for i, Ai in enumerate(agents):
        for nb in getattr(Ai, "neighbors", []):
            j = int(nb["id"]); Aj = agents[j]

            m = (Ai.mask > eps) & (Aj.mask > eps)
            if not np.any(m):
                continue

            Om = Omega(ctx, Ai, Aj, which=which)  # (H,W,K,K)

            if which == "q":
                mu_i, Si = Ai.mu_q_field, Ai.sigma_q_field
                mu_j, Sj = Aj.mu_q_field, Aj.sigma_q_field
            else:
                mu_i, Si = Ai.mu_p_field, Ai.sigma_p_field
                mu_j, Sj = Aj.mu_p_field, Aj.sigma_p_field

            Rt    = np.swapaxes(Om, -1, -2)
            muj_p = np.einsum("...ij,...j->...i", Om, mu_j)
            Sj_p  = np.einsum("...ia,...ab,...jb->...ij", Om, Sj, Rt)

            # --- NEW: sanitize BOTH covariances on overlap ---
            Si_m   = _spd_sanitize(Si[m])
            Sj_p_m = _spd_sanitize(Sj_p[m])

            try:
                # Cholesky of Σ'_j on overlap
                L2   = np.linalg.cholesky(Sj_p_m)           # (...,K,K)
                # Build Σ'_j^{-1} via triangular solves: P2 = (L2^{-1})^T (L2^{-1})
                Linv = np.linalg.inv(L2)                    # (...,K,K)
                P2   = np.einsum("...ki,...kj->...ij", Linv, Linv)
            except np.linalg.LinAlgError:
                print(f"[ALIGN-KL] pair=({i},{j}) which={which} -- Cholesky failed even after sanitize")
                continue

            diff = (muj_p[m] - mu_i[m])[..., None]         # (...,K,1)
            tr   = np.trace(np.einsum("...ij,...jk->...ik", P2, Si_m), axis1=-2, axis2=-1)
            qf   = np.einsum("...ij,...jk,...ki->...", np.swapaxes(diff, -1, -2), P2, diff)
            s1   = np.linalg.slogdet(Si_m)[1]
            s2   = np.linalg.slogdet(Sj_p_m)[1]
            K    = Si.shape[-1]
            KL   = 0.5 * (tr + qf - K + (s2 - s1))

            KL_mean = float(np.mean(KL))
            KL_max  = float(np.max(KL))

            if not hasattr(ctx, "_probe_align_prev"):
                ctx._probe_align_prev = {}
            key  = (i, j, which)
            prev = ctx._probe_align_prev.get(key, None)
            d    = (KL_mean - prev) if prev is not None else np.nan
            ctx._probe_align_prev[key] = KL_mean

            print(f"[ALIGN-KL] pair=({i},{j}) which={which} mean={KL_mean:.6e} "
                  f"max={KL_max:.6e} d_step={d:.3e}")
            printed += 1
            if printed >= 2:
                return


def _probe_sigma_health(agents):
    """Track SPD conditioning. Spikes here = Σ update culprit."""
    import numpy as np

    def stats(S):
        Ssym = 0.5 * (S + np.swapaxes(S, -1, -2))
        # eigs per pixel: shape (H,W,K)
        w = np.linalg.eigvalsh(Ssym)
        wmin_px = np.min(w, axis=-1)                # (H,W)
        wmax_px = np.max(w, axis=-1)                # (H,W)
        cond_px = wmax_px / np.maximum(wmin_px, 1e-12)
        return float(np.min(wmin_px)), float(np.max(wmax_px)), float(np.max(cond_px))


    printed = 0
    for a in agents:
        wmin_q, wmax_q, cond_q = stats(a.sigma_q_field)
        wmin_p, wmax_p, cond_p = stats(a.sigma_p_field)
        print(f"[Σ-health] aid={getattr(a,'id','?')} "
              f"q:λmin={wmin_q:.2e} λmax={wmax_q:.2e} cond={cond_q:.2e} | "
              f"p:λmin={wmin_p:.2e} λmax={wmax_p:.2e} cond={cond_p:.2e}")
        printed += 1
        if printed >= 3:
            return


def _probe_omega_kl(ctx, agents, which="q"):
    """
    One-pixel probe on a robust interior-overlap pixel; SPD-sanitizes Σ' and
    avoids NumPy deprecation by extracting scalars via .item().
    """
    from transport.transport_cache import Omega
    import numpy as np
    from scipy.linalg import expm
    import core.config as config

    for i, Ai in enumerate(agents):
        for nb in getattr(Ai, "neighbors", []):
            j = int(nb["id"])
            Aj = agents[j]

            try:
                r, c = _pick_overlap_pixel(Ai, Aj)  # robust interior pixel
            except RuntimeError:
                continue

            # cached Ω (your stack), per-pixel
            Om = Omega(ctx, Ai, Aj, which=which)[r, c]

            # gold Ω via expm + transpose inverse, then polar projection
            phi_i = Ai.phi if which == "q" else Ai.phi_model
            phi_j = Aj.phi if which == "q" else Aj.phi_model
            Gi    = Ai.generators_q if which == "q" else Ai.generators_p
            Gj    = Aj.generators_q if which == "q" else Aj.generators_p
            A_i   = phi_i[r, c, 0]*Gi[0] + phi_i[r, c, 1]*Gi[1] + phi_i[r, c, 2]*Gi[2]
            A_j   = phi_j[r, c, 0]*Gj[0] + phi_j[r, c, 1]*Gj[1] + phi_j[r, c, 2]*Gj[2]
            Ei    = expm(A_i)
            Ej    = expm(A_j)
            Om_g  = Ei @ Ej.T
            U, S, Vt = np.linalg.svd(Om_g, full_matrices=False)
            Rg = U @ Vt
            if np.linalg.det(Rg) < 0:
                U[:, -1] *= -1.0
                Rg = U @ Vt

            # orthogonality / det stats
            o_err = float(np.linalg.norm(Om.T @ Om - np.eye(Om.shape[0])))
            d     = float(np.linalg.det(Om))
            diff  = float(np.max(np.abs(Om - Rg)))

            # one-pixel KL with pushed j (SPD-sanitize Σ' first)
            if which == "q":
                mu_i, Si = Ai.mu_q_field[r, c], Ai.sigma_q_field[r, c]
                mu_j, Sj = Aj.mu_q_field[r, c], Aj.sigma_q_field[r, c]
            else:
                mu_i, Si = Ai.mu_p_field[r, c], Ai.sigma_p_field[r, c]
                mu_j, Sj = Aj.mu_p_field[r, c], Aj.sigma_p_field[r, c]

            muj_p = Om @ mu_j
            Sj_p  = Om @ Sj @ Om.T
            Sj_p  = _spd_sanitize(Sj_p)

            try:
                L    = np.linalg.cholesky(Sj_p)
                Linv = np.linalg.inv(L)
                P2   = Linv.T @ Linv
            except np.linalg.LinAlgError:
                print(f"[Ω-probe] pair=({i},{j}) px=({r},{c}) Cholesky failed after sanitize")
                return

            diffm = (muj_p - mu_i)[:, None]
            tr  = float(np.trace(P2 @ Si))
            qf  = float((diffm.T @ P2 @ diffm).item())   # avoid deprecation
            s1  = float(np.linalg.slogdet(Si)[1])
            s2  = float(np.linalg.slogdet(Sj_p)[1])
            KL  = 0.5 * (tr + qf - Si.shape[0] + (s2 - s1))

            print(f"[Ω-probe] pair=({i},{j}) px=({r},{c}) "
                  f"‖ΩᵀΩ−I‖={o_err:.2e} detΩ={d:.6f} |Ω−Ω_gold|_∞={diff:.2e} KL={KL:.6f}")
            return  # one probe per step is enough


if __name__ == "__main__":
    
    from core.get_generators import make_reducible_generators, check_so3_relations

    # 1) optional param override for config
    if len(sys.argv) > 1:
        with open(sys.argv[1], "rb") as f:
            param_override = pickle.load(f)
        # assumes you have this helper; otherwise set fields on config directly
        try:
            from core.config import set_config_from_params
            set_config_from_params(param_override)
        except Exception:
            pass
    else:
        param_override = {}

    # 2) Build reducible SO(3) generators (examples)
    spec_q = [(3, 1)]  #E.G. [(1,2)] IS 3 ⊕ 3  -> K_q = 6 spec = [(ℓ₁, multiplicity₁), (ℓ₂, multiplicity₂), ...]
    spec_p = [(3, 1)]  # 5      -> K_p = 5

    G_q = make_reducible_generators(spec_q, mix=False)
    G_p = make_reducible_generators(spec_p, mix=False)

    ok_q, rq = check_so3_relations(G_q, return_resid=True)
    ok_p, rp = check_so3_relations(G_p, return_resid=True)
    print("ok?", ok_q, ok_p, "resid:", rq, rp)
    print("K_q=", G_q.shape[1], "K_p=", G_p.shape[1])



    # 3) Keep config in sync with the actual generator sizes
    config.K_q = int(G_q.shape[1])
    config.K_p = int(G_p.shape[1])

    # 4) Pass the *arrays themselves* into params so init uses them directly
    runtime_params = {
        "generators_q": G_q,
        "generators_p": G_p,
        "seed": getattr(config, "seed", 0),
    }

    
    # 5) Run
    run_simulation(
        outdir="checkpoints",
        resume=False,
        log_metrics=True,
        log_fields=True,
        params=runtime_params,
    )



