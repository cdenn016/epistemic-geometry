import numpy as np
import matplotlib.pyplot as plt
from scipy.ndimage import gaussian_filter
from generalized_agent_distributions import initialize_distribution
from get_generators import get_generators
from generalized_agent_schema import Agent
from config import (
    domain_size, K, N,
    psi_radius_range,
    q_mu_range, q_sigma_range,
    p_mu_range, p_sigma_range,
    mu_field_smooth_range, sigma_field_smooth_range,
    overlap_eps, max_neighbors,
    support_cutoff_eps,
    phi_model_offset,
    similar_p_models, mask_sharpness
)
from config import distribution_family
# generalized_agents.py (where you call scale_to_range)
from config import q_mu_range, q_sigma_range, p_mu_range, p_sigma_range, mu_sigma_scale_range

# utils/scale_utils.py

import numpy as np

def scale_to_range(field: np.ndarray, value_range: tuple[float, float]) -> np.ndarray:
    """
    Linearly remap `field` so that field.min()→value_range[0], field.max()→value_range[1].
    If field is constant, fill with the midpoint of the range.
    """
    lo, hi = value_range
    fmin, fmax = field.min(), field.max()
    if fmax <= fmin:
        return np.full_like(field, (lo + hi) / 2)

    # normalize to [0,1]
    norm = (field - fmin) / (fmax - fmin)
    # scale to [lo, hi]
    return norm * (hi - lo) + lo


def generate_soft_mask(center, radius, domain_size):
    """
    Create a smooth soft mask (Gaussian decay) in arbitrary dimension D.

    Parameters:
    - center: tuple of length D with agent center coordinates
    - radius: scalar radius controlling mask width
    - domain_size: tuple of length D with domain size along each axis

    Returns:
    - mask: ndarray of shape domain_size with values in [0,1]
    """
    import numpy as np

    coords = np.meshgrid(*[np.arange(s) for s in domain_size], indexing='ij')
    dist_squared = np.zeros_like(coords[0], dtype=float)
    for d in range(len(domain_size)):
        dist_squared += (coords[d] - center[d])**2

    dist = np.sqrt(dist_squared)
    mask = np.exp(- (dist / radius)**2)

    return mask


def create_agent_mask(center, radius, domain_size, generate_soft_mask, support_cutoff_eps):
    mask = generate_soft_mask(center, radius, domain_size)
    mask[mask < support_cutoff_eps] = 0.0
    return mask


def create_smooth_fields(domain_size, rng, scale_to_range, smooth_random_field, config, K):
    # Sample smoothing scales for mu and sigma fields (can be adjusted)
    mu_smooth_range = getattr(config, "mu_field_smooth_range", (1, 3))
    sigma_smooth_range = getattr(config, "sigma_field_smooth_range", (1, 3))

    mu_smooth_q = rng.uniform(*mu_smooth_range)
    sigma_smooth_q = rng.uniform(*sigma_smooth_range)
    mu_smooth_p = rng.uniform(*mu_smooth_range)
    sigma_smooth_p = rng.uniform(*sigma_smooth_range)

    # Generate smooth random fields over arbitrary dimension domain_size
    mu_q_field = scale_to_range(
        smooth_random_field(domain_size, rng, sigma=mu_smooth_q),
        getattr(config, "q_mu_range", (1, K-1))
    )
    sigma_q_field = scale_to_range(
        smooth_random_field(domain_size, rng, sigma=sigma_smooth_q),
        getattr(config, "q_sigma_range", (1, 5))
    )

    if getattr(config, "similar_p_models", False):
        base_mu_p = rng.uniform(*getattr(config, "p_mu_range", (1, K-1)))
        base_sigma_p = rng.uniform(*getattr(config, "p_sigma_range", (1, 5)))
        mu_p_field = np.full(domain_size, base_mu_p, dtype=mu_q_field.dtype)
        sigma_p_field = np.full(domain_size, base_sigma_p, dtype=sigma_q_field.dtype)
    else:
        mu_p_field = scale_to_range(
            smooth_random_field(domain_size, rng, sigma=mu_smooth_p),
            getattr(config, "p_mu_range", (1, K-1))
        )
        sigma_p_field = scale_to_range(
            smooth_random_field(domain_size, rng, sigma=sigma_smooth_p),
            getattr(config, "p_sigma_range", (1, 5))
        )

    return mu_q_field, sigma_q_field, mu_p_field, sigma_p_field

def smooth_random_field(domain_size, rng, sigma=1.0):
    # domain_size is tuple (S_1,...,S_D)
    noise = rng.normal(size=domain_size)
    # Apply Gaussian filter with sigma; scipy.ndimage.gaussian_filter supports arbitrary dimensions
    from scipy.ndimage import gaussian_filter
    smooth_field = gaussian_filter(noise, sigma=sigma)
    return smooth_field

def initialize_phi_fields(domain_size, lie_algebra_dim, rng, phi_init, phi_model_offset, mask, dtype):
    from scipy.ndimage import gaussian_filter
    
    phi_raw = gaussian_filter(
        rng.normal(scale=phi_init, size=(*domain_size, lie_algebra_dim)),
        sigma=5  # smooth over all spatial dimensions
    ).astype(dtype)
    phi_masked = phi_raw * mask[..., None]

    phi_model_raw = phi_raw + rng.normal(
        scale=phi_model_offset,
        size=(*domain_size, lie_algebra_dim)
    ).astype(dtype)
    phi_model_raw = gaussian_filter(phi_model_raw, sigma=5)
    phi_model_masked = phi_model_raw * mask[..., None]

    return phi_masked, phi_model_masked


def assign_neighbors_vectorized(agents, overlap_eps, max_neighbors):
    # Flatten masks from arbitrary D spatial shape to 1D
    masks = np.array([agent.mask.flatten() for agent in agents])  # shape (N, prod(domain_size))
    overlap_matrix = masks @ masks.T  # pairwise overlaps

    overlap_bool = overlap_matrix > overlap_eps * masks.shape[1]  # threshold on fraction of mask overlap

    N = len(agents)
    for i in range(N):
        overlap_bool[i, i] = False  # exclude self
        neighbors_idx = np.argsort(-overlap_matrix[i])  # descending order by overlap
        filtered_neighbors = [j for j in neighbors_idx if j != i and overlap_bool[i, j]]
        selected_neighbors = filtered_neighbors[:max_neighbors]
        agents[i].neighbors = [{"id": j} for j in selected_neighbors]

def initialize_agents(
    seed=None,
    phi_init=None,
    domain_size=None,
    N=None,
    K=None,
    lie_algebra_dim=None,
    config=None,
    generate_soft_mask=None,
    smooth_random_field=None,
    scale_to_range=None,
    Agent=None,
    visualize=False,
):
    print("[DEBUG] Inside initialize_agents")  # Add this print to check
    rng = np.random.default_rng(seed)

    # Cache config params
    phi_init = phi_init if phi_init is not None else getattr(config, "phi_init", 0.1)
    phi_model_offset = getattr(config, "phi_model_offset", 0.1)
    dist_family = getattr(config, "distribution_family", "gaussian")
    support_cutoff_eps = getattr(config, "support_cutoff_eps", 1e-3)
    overlap_eps = getattr(config, "overlap_eps", 1e-3)
    max_neighbors = getattr(config, "max_neighbors", 8)
    dtype = getattr(config, "dtype", np.float32)

    # D = dimension of domain
    D = len(domain_size)

    # Create x with correct broadcasting shape (spatial dims + fiber dim)
    x = np.arange(K).reshape(*([1] * D), -1)

    agents = []
    print(f"[DEBUG] Number of agents initialized: {len(agents)}")
    for n in range(N):
        radius = rng.uniform(*getattr(config, "psi_radius_range", (5, 10)))
        # Sample center as a tuple of length D
        center = tuple(rng.integers(0, s) for s in domain_size)

        mask = create_agent_mask(center, radius, domain_size, generate_soft_mask, support_cutoff_eps)

        mu_q_field, sigma_q_field, mu_p_field, sigma_p_field = create_smooth_fields(
            domain_size, rng, scale_to_range, smooth_random_field, config, K
        )

        q = initialize_distribution(x, mu_q_field, sigma_q_field, mask, dist_family)
        p = initialize_distribution(x, mu_p_field, sigma_p_field, mask, dist_family)

        phi_masked, phi_model_masked = initialize_phi_fields(
            domain_size, lie_algebra_dim, rng, phi_init, phi_model_offset, mask, dtype
        )

        agent = Agent(
            id=n,
            center=center,
            radius=radius,
            mask=mask.astype(dtype),
            q=q.astype(dtype),
            p=p.astype(dtype),
            mu_q_field=mu_q_field.astype(dtype),
            sigma_q_field=sigma_q_field.astype(dtype),
            mu_p_field=mu_p_field.astype(dtype),
            sigma_p_field=sigma_p_field.astype(dtype),
            phi=phi_masked,
            phi_model=phi_model_masked,
            neighbors=[]
        )
        agents.append(agent)

        # Only visualize for 2D domains
        if visualize and n < 3 and D == 2:
            import matplotlib.pyplot as plt
            fig, axs = plt.subplots(1, 4, figsize=(16, 4))
            axs[0].imshow(mask, cmap='gray')
            axs[0].set_title(f"Agent {n} Mask")
            axs[1].imshow(np.sum(q, axis=-1), cmap='viridis')
            axs[1].set_title("Belief q marginal")
            axs[2].imshow(np.sum(p, axis=-1), cmap='plasma')
            axs[2].set_title("Model p marginal")
            axs[3].imshow(np.linalg.norm(phi_masked, axis=-1), cmap='inferno')
            axs[3].set_title("Gauge field |phi|")
            plt.tight_layout()
            plt.show()

    assign_neighbors_vectorized(agents, overlap_eps, max_neighbors)

    return agents
