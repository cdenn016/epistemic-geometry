# -*- coding: utf-8 -*-
import numpy as np
from scipy.ndimage import laplace
from scipy.linalg import expm
from get_generators import get_generators


def sanitize_q(q, eps=1e-9):
    """Clip probabilities to [eps, 1] and normalize along the last axis."""
    import numpy as np  # Importing inside the function to avoid circular import issues
    q = np.clip(q, eps, 1.0)
    q /= np.sum(q, axis=-1, keepdims=True) + eps
    return q

def kl_divergence(p, q, eps=1e-9):
    """
    Compute KL divergence D_KL(p || q) along the last axis.
    Inputs assumed to be probability distributions.
    """   
    p = sanitize_q(p, eps)
    q = sanitize_q(q, eps)
    return np.sum(p * (np.log(p) - np.log(q)), axis=-1)

def compute_agent_overlap_mask(agent_i, agent_j, threshold):
    """ Compute boolean mask of overlapping support between two agents for arbitrary spatial dims. """
    return (agent_i.mask > threshold) & (agent_j.mask > threshold)

# --- Differential Operators ---

def gradient_field(field, axes=None):
    """
    Compute gradient of a vector field along specified axes.

    Parameters:
        field : ndarray with shape (..., dim) where ... = spatial dims
        axes  : tuple of int, axes along which to compute gradient
                If None, assumes all spatial dims except last (fiber) axis.
    Returns:
        gradients : list of ndarray, one per axis in axes
    """
    
    if axes is None:
        axes = tuple(range(field.ndim - 1))  # all but last axis assumed fiber dim
    return np.gradient(field, axis=axes)

def laplacian_field(field):
    """
    Compute Laplacian of a vector field along last dimension.
    Returns array of same shape as input.
    """
    
    from scipy.ndimage import laplace  # Importing inside the function to avoid circular import issues
    return np.stack([laplace(field[..., i]) for i in range(field.shape[-1])], axis=-1)

# --- Norms and Masked Operations ---

def masked_norm(field, mask, ord=2):
    """
    Compute masked norm of a vector field.
    field: (..., dim) ndarray
    mask: same shape as field excluding last dim or broadcastable
    """    
    norm_vals = np.linalg.norm(field, ord=ord, axis=-1)
    return np.sum(norm_vals * mask) / (np.sum(mask) + 1e-9)

# --- Batch Matrix Operations ---

def batch_matmul(A, B):
    """
    Batch matrix multiplication for arrays of shape (..., M, N) and (..., N, P).
    Returns (..., M, P).
    """ 
    return np.matmul(A, B)

def batch_commutator(A, B):
    """
    Compute batch matrix commutator [A, B] = AB - BA.
    A, B: (..., K, K)
    """
    return np.matmul(A, B) - np.matmul(B, A)

# --- Matrix Exponentials and Approximations ---

def adaptive_expm(A, max_norm=20):
    """
    Compute matrix exponential using scipy.linalg.expm with optional scaling.
    Clips large norms to max_norm for stability.
    """
    norm_A = np.linalg.norm(A, ord=2)
    if norm_A > max_norm:
        A = A * (max_norm / norm_A)
    return expm(A)

def taylor_exp_approx(A, order=2):
    """
    2nd order Taylor expansion of exp(A) ~ I + A + 0.5 A^2.
    """
    I = np.eye(A.shape[-1], dtype=A.dtype)
    A2 = A @ A
    return I + A + 0.5 * A2

# --- Additional helpers as needed ---

# e.g., function to clip large values safely
def safe_clip(arr, min_val=-1e6, max_val=1e6):
    return np.clip(arr, min_val, max_val)

