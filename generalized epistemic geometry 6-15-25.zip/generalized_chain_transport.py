import numpy as np
import networkx as nx
from scipy.ndimage import gaussian_filter
from agent_schema import Agent  # Use generalized agent schema
import numpy as np
import networkx as nx

def build_overlap_graph(agents, support_cutoff_eps):
    """
    Build an undirected graph where nodes are agent indices,
    edges connect agents with overlapping support above threshold.
    
    Supports arbitrary spatial dimensions since masks are np.ndarrays.
    """
    G = nx.Graph()
    N = len(agents)
    G.add_nodes_from(range(N))
    
    for i in range(N):
        mask_i = agents[i].mask
        for j in range(i+1, N):
            mask_j = agents[j].mask
            
            # Overlap boolean mask (works in any spatial dims)
            overlap = (mask_i * mask_j) > support_cutoff_eps
            
            if np.any(overlap):
                G.add_edge(i, j)
    
    return G

def find_agent_chain(agents, start_id, end_id, support_cutoff_eps):
    """
    Find a chain of agents linking start_id to end_id via overlaps.
    
    Returns a list of agent indices or None if no path found.
    """
    G = build_overlap_graph(agents, support_cutoff_eps)
    try:
        path = nx.shortest_path(G, start_id, end_id)
        return path
    except nx.NetworkXNoPath:
        return None

def find_agent_path(graph: nx.Graph, source: int, target: int):
    """
    Find shortest path between source and target agents in the overlap graph.
    """
    try:
        return nx.shortest_path(graph, source=source, target=target)
    except nx.NetworkXNoPath:
        return None
    


def visualize_path_on_graph(graph: nx.Graph, path, save_path=None, pos=None, node_size=300, font_size=12):
    """
    Visualize the overlap graph with the specified path highlighted.

    Parameters:
    - graph: networkx Graph
    - path: list of node indices or None
    - save_path: filepath to save figure or None
    - pos: precomputed layout positions dict (optional)
    """
    import matplotlib.pyplot as plt

    if pos is None:
        pos = nx.spring_layout(graph, seed=42)

    plt.figure(figsize=(6, 6))
    nx.draw(graph, pos, node_color='lightblue', with_labels=True, edge_color='gray',
            node_size=node_size, font_size=font_size)

    if path and len(path) > 1:
        path_edges = list(zip(path[:-1], path[1:]))
        nx.draw_networkx_edges(graph, pos, edgelist=path_edges, edge_color='red', width=2)

    plt.title("Agent Overlap Graph with Transport Path")
    plt.tight_layout()

    if save_path:
        plt.savefig(save_path)
    plt.show()


def get_overlap_centroid(agent_i, agent_j, threshold=0.01, relax_factor=10):
    """
    Get the centroid coordinate of spatial overlap between two agents' masks.

    Supports arbitrary spatial dimension by working on mask boolean arrays.

    Args:
    - agent_i, agent_j: Agent objects with `.mask` attribute (numpy ndarray)
    - threshold: float threshold to binarize mask overlap
    - relax_factor: factor to lower threshold if no overlap initially

    Returns:
    - tuple of ints: centroid coordinates in spatial domain
    - None if no overlap found
    """
    overlap = (agent_i.mask > threshold) & (agent_j.mask > threshold)
    coords = np.argwhere(overlap)

    if coords.size == 0:
        # Relax threshold and retry
        overlap = (agent_i.mask > threshold / relax_factor) & (agent_j.mask > threshold / relax_factor)
        coords = np.argwhere(overlap)
        if coords.size == 0:
            return None

    centroid = np.mean(coords, axis=0)
    centroid_int = tuple(np.round(centroid).astype(int))
    return centroid_int

from typing import List, Tuple, Optional

def build_routed_centroids(agents: list, path: List[int], fail_fallback=True) -> List[Tuple[int, ...]]:
    """
    Given a path (list of agent indices), compute centroids of spatial overlaps between consecutive agents.

    Args:
    - agents: list of Agent instances with `.mask` attribute
    - path: list of agent indices defining the route
    - fail_fallback: if True, fall back to midpoint of agent centers when no overlap found;
                     else raise ValueError

    Returns:
    - List of tuples with centroid coordinates for each edge in path
    """
    centroids = []
    for idx in range(len(path) - 1):
        agent_a = agents[path[idx]]
        agent_b = agents[path[idx + 1]]
        centroid = get_overlap_centroid(agent_a, agent_b)
        if centroid is None:
            if fail_fallback:
                # fallback: midpoint between agent centers
                c_a = np.array(agent_a.center)
                c_b = np.array(agent_b.center)
                midpoint = tuple(np.round((c_a + c_b) / 2).astype(int))
                centroids.append(midpoint)
            else:
                raise ValueError(f"No spatial overlap found between agents {path[idx]} and {path[idx+1]}")
        else:
            centroids.append(centroid)
    return centroids

# generalized_transport.py
from agent_schema import Agent  # NEW

        
import numpy as np
from scipy.ndimage import gaussian_filter
from generalized_math_utils import kl_divergence
from generalized_omega import exp_lie_algebra_irrep, apply_omega_batch
from generalized_path_utils import construct_spatial_path_nd  # Your generalized path constructor

def transport_belief_along_path(
    agents,
    path,
    domain_shape,
    support_cutoff_eps,
    K,
    lie_algebra_dim,
    generators,
    fixed_start=None,
    fixed_end=None,
    config=None,
):
    """
    Generalized belief transport along a path of agents over arbitrary spatial dimension.

    Parameters:
    - agents: list of Agent objects
    - path: list of agent indices forming a chain
    - domain_shape: tuple (S_1, S_2, ..., S_D), spatial domain shape
    - support_cutoff_eps: mask threshold to consider support
    - K: fiber dimension (belief/model dimension)
    - lie_algebra_dim: dimension of Lie algebra
    - generators: array of Lie algebra generators (lie_algebra_dim, K, K)
    - fixed_start: optional coordinate tuple start point within first agent
    - fixed_end: optional coordinate tuple end point within last agent
    - config: optional config object for parameters like smoothing sigmas

    Returns:
    - updated agents list
    - diagnostics dict with paths, KL values, etc.
    """

    D = len(domain_shape)
    A = agents[path[0]]
    B = agents[path[-1]]

    # Select injection point in first agent's support
    if fixed_start is not None:
        c_0 = fixed_start
    else:
        # Find mask-supported points in agent A
        candidates = np.argwhere(A.mask > support_cutoff_eps)
        if len(candidates) == 0:
            raise RuntimeError("No candidate points with sufficient mask support in source agent.")
        # Sort by belief mass q sum over fiber dimension
        belief_sums = np.sum(A.q[candidates[:,0], candidates[:,1], ...], axis=-1) if D==2 else np.sum(A.q[candidates.T], axis=-1)
        idx_sorted = np.argsort(-belief_sums)
        c_0 = tuple(candidates[idx_sorted[0]])

    q = A.q[c_0].copy()
    if np.sum(q) < 1e-3:
        print(f"[WARNING] Selected start point {c_0} has very low belief mass: sum={np.sum(q):.3e}")

    full_path = []
    kl_path_coarse = []
    kl_path_fine = []

    # Iterate over chain path hops
    for hop_idx in range(len(path) - 1):
        id_a = path[hop_idx]
        id_b = path[hop_idx + 1]
        agent_a = agents[id_a]
        agent_b = agents[id_b]

        # Compute overlap centroid or suitable overlap point
        from generalized_path_utils import get_overlap_centroid_nd
        c_overlap = get_overlap_centroid_nd(agent_a, agent_b, support_cutoff_eps)
        if c_overlap is None:
            raise RuntimeError(f"No overlap centroid between agents {id_a} and {id_b}")

        # Construct spatial path within agent_a from c_0 to c_overlap
        path_segment = construct_spatial_path_nd(c_0, c_overlap, domain_shape, mask=agent_a.mask)
        if not path_segment:
            raise RuntimeError(f"Path {id_a} to {id_b} leaves agent {id_a}'s support.")

        # Intra-agent transport along path_segment
        for p0, p1 in zip(path_segment[:-1], path_segment[1:]):
            delta_phi = agent_a.phi[p0] - agent_a.phi[p1]  # Lie algebra element
            # Compute group element Ω via exp map
            omega = exp_lie_algebra_irrep(delta_phi, generators)
            q = apply_omega_batch(q, omega)
            target_q = agent_a.q[p1]
            kl_path_fine.append(kl_divergence(q, target_q))

        # Inter-agent jump transport at overlap
        phi_a = agent_a.phi[c_overlap]
        phi_b = agent_b.phi[c_overlap]
        r = phi_a - phi_b
        omega_jump = exp_lie_algebra_irrep(r, generators)
        q = apply_omega_batch(q, omega_jump)
        target_q = agent_b.q[c_overlap]
        kl_path_coarse.append(kl_divergence(q, target_q))

        full_path.extend(path_segment)
        c_0 = c_overlap
        if not path_segment or path_segment[-1] != c_overlap:
            full_path.append(c_overlap)

    # Final injection point normalization
    c_final = fixed_end if fixed_end is not None else (full_path[-1] if full_path else c_overlap)

    q = np.clip(q, 1e-8, 1.0)
    q /= np.sum(q)

    # Update agent B belief q with smoothed injection
    delta_mask = np.zeros(domain_shape, dtype=np.float32)
    delta_mask[c_final] = 1.0
    sigma_smooth = getattr(config, "injection_smooth_sigma", 2)
    smoothed = gaussian_filter(delta_mask, sigma=sigma_smooth)

    for k in range(K):
        B.q[..., k] += q[k] * smoothed

    # Normalize B.q over fiber dimension
    B.q = np.clip(B.q, 1e-8, 1.0)
    B.q /= np.sum(B.q, axis=-1, keepdims=True) + 1e-8

    # Update mask of B to reflect belief injection support
    mask_sigma = getattr(config, "mask_update_sigma", 0.8)
    mask_patch = gaussian_filter(delta_mask, sigma=mask_sigma)
    B.mask = np.maximum(B.mask, mask_patch)

    if c_final not in full_path:
        full_path.append(c_final)

    return agents, {
        "full_path": full_path,
        "c_start": fixed_start if fixed_start is not None else full_path[0],
        "c_final": c_final,
        "path_indices": path,
        "kl_path_coarse": kl_path_coarse,
        "kl_path_fine": kl_path_fine,
    }
