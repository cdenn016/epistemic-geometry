# transport_operator.py

import numpy as np
from sl2r_generators import get_generators
from sl2r_operator import exp_sl2r_operator

from agent_schema import Agent  # NEW
import numpy as np

def compute_base_transport_operator(path: list, K: int) -> np.ndarray:
    """
    Placeholder: Compute spatial transport operator along path.
    In generalized form, this could represent spatial parallel transport, diffusion, etc.

    Currently returns identity of dimension K.
    """
    # TODO: implement spatial transport if needed for your model
    return np.eye(K)


def apply_transport(q_B_at_cB: np.ndarray, spatial_operator: np.ndarray, omega_AB: np.ndarray) -> np.ndarray:
    """
    Apply transport operator Ω_AB and spatial operator to belief/model vector q_B at c_B.

    Parameters:
    - q_B_at_cB: (K,) belief vector at location c_B
    - spatial_operator: (K, K) spatial operator between locations c_B -> c_A
    - omega_AB: (K, K) gauge group operator transporting fiber q_B(c_B) to q_A(c_A)

    Returns:
    - transported vector in agent A's fiber space
    """
    transported = spatial_operator @ q_B_at_cB
    return omega_AB @ transported


def compute_connection_delta(
    phi_field: np.ndarray,
    x0: tuple,
    x1: tuple,
    generators: np.ndarray,
    exp_func,
) -> np.ndarray:
    """
    Compute connection operator Ω_{x0 → x1} = exp(φ(x0)) · inv(exp(φ(x1))) in the group representation.

    Parameters:
    - phi_field: ndarray (..., lie_algebra_dim), the φ-field over space
    - x0, x1: tuples of spatial indices
    - generators: ndarray (lie_algebra_dim, K, K) Lie algebra generators
    - exp_func: function to compute exp map from Lie algebra to group

    Returns:
    - ndarray (K, K) representing the group-valued connection operator
    """
    omega_x0 = exp_func(phi_field[x0], generators)
    omega_x1 = exp_func(phi_field[x1], generators)
    omega_x1_inv = np.linalg.inv(omega_x1)
    return omega_x0 @ omega_x1_inv


import numpy as np
from typing import List, Tuple, Optional

from generalized_math_utils import exp_lie_algebra_operator  # generalized exp map
from generalized_omega import get_generators  # generalized generator getter

def construct_spatial_path(
    c_from: Tuple[int, ...],
    c_to: Tuple[int, ...],
    domain_size: Tuple[int, ...],
    mask: Optional[np.ndarray] = None,
    eps: float = 1e-3,
    allow_soft_pixels: bool = True,
    soft_pixel_tolerance: int = 2,
    verbose: bool = False
) -> List[Tuple[int, ...]]:
    """
    Compute a straight-line spatial path on a periodic grid (torus) between c_from and c_to,
    for arbitrary spatial dimension.

    Parameters:
    - c_from, c_to: tuple of coordinates (e.g. (x,y,z,...))
    - domain_size: tuple giving size of each dimension
    - mask: optional ndarray with support mask; path must remain mostly in support
    - eps: support cutoff threshold
    - allow_soft_pixels: whether to tolerate some points below threshold
    - soft_pixel_tolerance: max allowed soft pixels
    - verbose: print diagnostic info

    Returns:
    - list of tuples representing the path coordinates (discrete)
    """

    dim = len(domain_size)
    c_from = np.array(c_from)
    c_to = np.array(c_to)
    domain_size = np.array(domain_size)

    # Compute shortest displacement vector with periodic boundary conditions
    delta = (c_to - c_from + domain_size // 2) % domain_size - domain_size // 2

    steps = int(np.max(np.abs(delta)))
    if steps == 0:
        return [tuple(c_from)]

    path = []
    soft_pixel_count = 0

    for i in range(steps + 1):
        pos = (c_from + delta * i / steps) % domain_size
        pos_int = tuple(np.round(pos).astype(int) % domain_size)

        if mask is not None:
            val = mask[pos_int]
            if val <= eps:
                soft_pixel_count += 1
                if not allow_soft_pixels or soft_pixel_count > soft_pixel_tolerance:
                    if verbose:
                        print(f"[FAIL] Path aborted at {pos_int}: mask={val} soft_pixel_count={soft_pixel_count}")
                    return []

        path.append(pos_int)

    if verbose and soft_pixel_count > 0:
        print(f"[WARN] Path used {soft_pixel_count} soft pixels from {c_from} to {c_to}")

    return path


def compute_path_operator(
    phi_field: np.ndarray,
    path: List[Tuple[int, ...]],
    generators: np.ndarray,
    exp_func=exp_lie_algebra_operator
) -> np.ndarray:
    """
    Compute cumulative transport operator Ω along spatial path,
    given group generators and Lie algebra field φ.

    Parameters:
    - phi_field: ndarray (..., lie_algebra_dim)
    - path: list of coordinates (tuples) in spatial domain
    - generators: ndarray (lie_algebra_dim, K, K)
    - exp_func: function to compute exp map from Lie algebra element to group element

    Returns:
    - omega: ndarray (K, K) cumulative transport operator
    """
    K = generators.shape[-1]
    omega = np.eye(K)

    for i in range(len(path) - 1):
        c0, c1 = path[i], path[i + 1]
        phi_c0 = phi_field[c0]
        phi_c1 = phi_field[c1]

        omega_c0 = exp_func(phi_c0, generators)
        omega_c1 = exp_func(phi_c1, generators)
        omega_delta = omega_c0 @ np.linalg.inv(omega_c1)
        omega = omega_delta @ omega

    return omega


def compute_full_transport_operator(
    agents: List,
    path_segments: List[List[Tuple[int, ...]]],
    overlap_points: List[Tuple[Tuple[int, ...], Tuple[int, ...]]],
    domain_size: Tuple[int, ...],
    generators: np.ndarray,
    exp_func=exp_lie_algebra_operator
) -> Tuple[np.ndarray, List]:
    """
    Compute the full transport operator for a chain of agents.

    Parameters:
    - agents: list of agent objects, each with .phi field
    - path_segments: list of spatial paths (one per agent)
    - overlap_points: list of spatial coordinate pairs for inter-agent jumps
    - domain_size: tuple of spatial domain sizes
    - generators: Lie algebra generators for group representation
    - exp_func: Lie algebra exponential map function

    Returns:
    - omega_total: total transport operator (KxK)
    - operator_steps: list of tuples describing each operator step ('within' or 'jump')
    """
    K = generators.shape[-1]
    omega_total = np.eye(K)
    operator_steps = []

    for seg_idx, path in enumerate(path_segments):
        agent = agents[seg_idx]
        phi = agent.phi

        # Compute intra-agent path transport
        omega_path = compute_path_operator(phi, path, generators, exp_func)
        omega_total = omega_path @ omega_total
        operator_steps.append(('within', seg_idx, omega_path))

        # Inter-agent jump
        if seg_idx < len(overlap_points):
            c_a, c_b = overlap_points[seg_idx]
            phi_a = agents[seg_idx].phi[c_a]
            phi_b = agents[seg_idx + 1].phi[c_b]

            omega_a = exp_func(phi_a, generators)
            omega_b_inv = np.linalg.inv(exp_func(phi_b, generators))
            omega_jump = omega_a @ omega_b_inv

            omega_total = omega_jump @ omega_total
            operator_steps.append(('jump', (seg_idx, seg_idx + 1), omega_jump))

    return omega_total, operator_steps
