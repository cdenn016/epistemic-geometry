import matplotlib.pyplot as plt
import pickle
import os
import config
def plot_energy(log_file):
    with open(log_file, 'rb') as f:
        metrics = pickle.load(f)

    steps = [m['step'] for m in metrics]
    energies = [m['total_energy']['Total'] for m in metrics]

    plt.figure(figsize=(10, 5))
    plt.plot(steps, energies, '-o')
    plt.xlabel('Simulation Step')
    plt.ylabel('Total Energy')
    plt.title('Energy Evolution Over Time')
    plt.grid(True)
    plt.tight_layout()
    plt.show()

if __name__ == "__main__":
    print(config.alpha, config.beta, config.curvature_weight, config.gamma, config.model_align_weight)

    log_file = os.path.join("checkpoints", "metric_log.pkl")
    plot_energy(log_file)
