import os
import pickle
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

def main():
    # 1) Path to your metrics log
    metric_log_path = os.path.join('checkpoints', 'metric_log.pkl')

    # 2) Load metrics
    with open(metric_log_path, 'rb') as f:
        metric_log = pickle.load(f)

    # 3) Flatten into records
    records = []
    for m in metric_log:
        rec = {
            'step': m['step'],
            'kl_self': m['kl_self'],
            'kl_align': m['kl_align'],
            'kl_model_align': m['kl_model_align'],
            'phi_norm': m['phi_norm'],
            'phi_model_norm': m['phi_model_norm'],
            'phi_model_align_error': m['phi_model_align_error'],
            'phi_belief_align_error': m['phi_belief_align_error'],
            'phi_model_align_error': m['phi_model_align_error'],
            'delta_phi_norm': m['delta_phi_norm'],
            'cross_model_kl': m['cross_model_kl'],
            'phi_model_norm': m['phi_model_norm']
            }
        # Expand nested energy dict
        for key, val in m['total_energy'].items():
            safe_key = key.replace('(', '').replace(')', '').replace(' ', '_') \
                          .replace('Ω̃', 'OmegaTilde').replace('Ω', 'Omega').replace('²', '2')
            rec[f'energy_{safe_key}'] = val
        records.append(rec)

    # 4) Create DataFrame
    df = pd.DataFrame(records)
    print(df)

    # 5) Plot each metric over time without markers
    for col in df.columns:
        if col == 'step':
            continue
        plt.figure()
        plt.plot(df['step'], df[col], linestyle='-')  # no markers
        plt.title(col)
        plt.xlabel('Step')
        plt.ylabel(col)
        plt.tight_layout()

    # Show all plots
    plt.show()

if __name__ == "__main__":
    main()
