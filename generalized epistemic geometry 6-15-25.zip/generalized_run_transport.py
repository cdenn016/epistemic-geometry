import numpy as np
from generalized_math_utils import (
    kl_divergence_batch,
    batch_exp_lie_algebra_irrep,
    batch_apply_omega,
    normalize_distribution_batch,
    compute_agent_overlap_mask
)
from generalized_transport_operator import compute_connection_delta
from generalized_io_utils import save_step
from networkx import Graph, shortest_path
from generalized_chain_transport import build_overlap_graph, transport_belief_along_path


def run_transport_full(
    agents: list,
    source_idx: int,
    target_idx: int,
    generators: np.ndarray,
    support_cutoff_eps: float,
    overlap_eps: float,
    config,
    fixed_start: tuple = None,
    fixed_end: tuple = None,
    save_path: str = None,
    q_field: str = "q",
    p_field: str = "p",
    phi_belief_field: str = "phi",
    phi_model_field: str = "phi_model",
) -> tuple:
    """
    Runs full belief transport from source to target agent along shortest overlap chain.
    Supports arbitrary groups, agents, beliefs/models, and base manifold dimension.

    Returns: (coords, kl_vals, omegas, q_vals, path)
    """
    # Build overlap graph with flexible mask field if needed
    G = build_overlap_graph(agents, support_cutoff_eps, mask_field="mask")

    try:
        path = shortest_path(G, source=source_idx, target=target_idx)
    except Exception as e:
        raise RuntimeError(f"No path between agents {source_idx} and {target_idx}: {e}")

    coords, kl_vals, omegas, q_vals = transport_belief_along_path(
        agents,
        path,
        domain_shape=agents[0].mask.shape,
        support_cutoff_eps=support_cutoff_eps,
        overlap_eps=overlap_eps,
        K=agents[0].q.shape[-1],
        lie_algebra_dim=generators.shape[0],
        generators=generators,
        fixed_start=fixed_start,
        fixed_end=fixed_end,
        config=config,
        q_field=q_field,
        p_field=p_field,
        phi_belief_field=phi_belief_field,
        phi_model_field=phi_model_field,
    )

    if save_path is not None:
        save_step(agents, save_path, step=0)

    return coords, kl_vals, omegas, q_vals, path
