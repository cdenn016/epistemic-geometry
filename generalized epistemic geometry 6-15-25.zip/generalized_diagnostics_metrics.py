# diagnostics_metrics.py

import numpy as np
from scipy.ndimage import laplace
from generalized_math_utils import (
    sanitize_q,
    laplacian_field,
    masked_norm,
    )
  
from get_generators import get_generators


from generalized_omega import (
    repair_if_forgotten,
    repair_if_forgotten_batch,
    adaptive_expm,
    exp_lie_algebra_operator,
    exp_lie_algebra_irrep,
    batch_exp_lie_algebra_irrep,
    batch_apply_omega,
    apply_omega,
    compute_gauge_potential,
    compute_commutator,
    compute_field_strength,
)


from config import log_eps, overlap_eps, support_cutoff_eps, K

def kl_divergence(q1, q2, eps=1e-12):
    q1 = np.clip(q1, eps, 1.0)
    q2 = np.clip(q2, eps, 1.0)
    return np.sum(q1 * (np.log(q1) - np.log(q2)), axis=-1)

def compute_total_energy(
    agents,
    generators,
    params: dict,
    q_field="q",
    p_field="p",
    phi_belief_field="phi",
    phi_model_field="phi_model",
) -> dict:
    """
    Compute total variational energy including all couplings,
    pulling every weight and epsilon from params/config.
    """
    import config
    from generalized_math_utils import sanitize_q, laplacian_field
    from generalized_omega import exp_lie_algebra_irrep, batch_apply_omega
    from generalized_omega import compute_field_strength
    from generalized_update_rules import kl_divergence

    # Pull hyperparameters (no more hidden literals)
    alpha              = params.get("alpha",              config.alpha)
    beta               = params.get("beta",               config.beta)
    beta_tilde         = params.get("beta_tilde",         config.model_align_weight)
    gamma              = params.get("gamma",              config.gamma)
    gamma_tilde        = params.get("gamma_tilde",        getattr(config, "gamma_tilde", 0.0))
    curvature_weight   = params.get("curvature_weight",   config.curvature_weight)
    support_cutoff_eps = params.get("support_cutoff_eps", config.support_cutoff_eps)
    overlap_eps        = params.get("overlap_eps",        config.overlap_eps)
    log_eps            = params.get("log_eps",            config.log_eps)

    E_kl = E_align = E_model_align = E_lap = E_lap_model = E_curv = 0.0

    for agent_i in agents:
        mask_i = agent_i.mask > support_cutoff_eps
        q_i    = sanitize_q(getattr(agent_i, q_field), eps=log_eps)
        p_i    = sanitize_q(getattr(agent_i, p_field), eps=log_eps)
        phi_i  = getattr(agent_i, phi_belief_field)
        phi_m  = getattr(agent_i, phi_model_field)

        # Self KL
        D_kl = kl_divergence(q_i, p_i)
        E_kl += alpha * D_kl[mask_i].sum()

        # Belief alignment
        if beta > 0:
            for nb in agent_i.neighbors:
                j   = nb["id"]
                aj  = agents[j]
                overlap = mask_i & (aj.mask > support_cutoff_eps)
                if not overlap.any(): continue

                rvecs  = phi_i[overlap] - aj.phi[overlap]
                Ω      = exp_lie_algebra_irrep(rvecs, generators)
                qj_rot = batch_apply_omega(sanitize_q(aj.q[overlap], eps=log_eps), Ω)
                qj_rot = sanitize_q(qj_rot, eps=log_eps)
                D_a    = kl_divergence(q_i[overlap], qj_rot)
                E_align += beta * D_a.sum()

        # Model alignment
        if beta_tilde > 0:
            for nb in agent_i.neighbors:
                j   = nb["id"]
                aj  = agents[j]
                overlap = mask_i & (aj.mask > support_cutoff_eps)
                if not overlap.any(): continue

                rvecs = phi_m[overlap] - aj.phi_model[overlap]
                Ωt    = exp_lie_algebra_irrep(rvecs, generators)
                pj_rot= batch_apply_omega(sanitize_q(aj.p[overlap], eps=log_eps), Ωt)
                pj_rot= sanitize_q(pj_rot, eps=log_eps)
                D_m   = kl_divergence(p_i[overlap], pj_rot)
                E_model_align += beta_tilde * D_m.sum()

        # Laplacians
        lap_belief = laplacian_field(phi_i)[mask_i]
        E_lap      += gamma * np.linalg.norm(lap_belief, axis=-1).sum()

        lap_model  = laplacian_field(phi_m)[mask_i]
        E_lap_model+= gamma_tilde * np.linalg.norm(lap_model, axis=-1).sum()

        # Curvature
        if curvature_weight > 0:
            F_dict    = compute_field_strength(phi_m, generators)
            for F in F_dict.values():
                E_curv += curvature_weight * (F[mask_i].sum())

    total_support = max(sum((a.mask > support_cutoff_eps).sum() for a in agents), 1)
    return {
        "KL(q||p)"            : E_kl / total_support,
        "KL(q||Ωq)"          : E_align / total_support,
        "KL(p||Ω̃p)"         : E_model_align / total_support,
        "Laplacian(φ_belief)" : E_lap / total_support,
        "Laplacian(φ_model)"  : E_lap_model / total_support,
        "Curvature(F²)"       : E_curv / total_support,
        "Total"               : (E_kl+E_align+E_model_align+E_lap+E_lap_model+E_curv) / total_support,
    }


def compute_alignment_error(
    agents,
    generators,
    q_field="q",
    phi_field="phi",
    support_cutoff_eps=1e-3,
    overlap_eps=1e-3,
    log_eps=1e-8,
):
    """
    Compute average KL divergence alignment error D_KL(q_i || Ω_{ij} q_j) over overlapping neighbors.

    Parameters:
    - agents: list of agent objects with attributes q_field, phi_field, mask, neighbors
    - generators: Lie algebra generators (dim_G, K, K)
    - q_field: string name of belief distribution field (default 'q')
    - phi_field: string name of phase field (default 'phi')
    - support_cutoff_eps: mask cutoff threshold
    - overlap_eps: threshold for mask overlap
    - log_eps: numerical epsilon for KL and normalization stability

    Returns:
    - average KL alignment error (float)
    """

    total_error = 0.0
    total_weight = 0.0

    for agent_i in agents:
        mask_i = getattr(agent_i, "mask") > support_cutoff_eps
        q_i = sanitize_q(getattr(agent_i, q_field), eps=log_eps)
        phi_i = getattr(agent_i, phi_field)

        for neighbor in agent_i.neighbors:
            j = neighbor["id"]
            agent_j = agents[j]
            mask_j = getattr(agent_j, "mask")
            overlap = (mask_i * mask_j) > overlap_eps
            if not np.any(overlap):
                continue

            q_j = sanitize_q(getattr(agent_j, q_field), eps=log_eps)
            phi_j = getattr(agent_j, phi_field)

            # Compute Lie algebra difference field on overlap points
            r = phi_i - phi_j
            r_vecs = r[overlap]
            qj_vecs = q_j[overlap]

            # Vectorized batch exponentiation and transport
            omega_batch = exp_lie_algebra_irrep(r_vecs, generators)
            qj_rot = batch_apply_omega(qj_vecs, omega_batch)
            qj_rot = sanitize_q(qj_rot, eps=log_eps)

            # KL divergence on overlap
            D_kl = kl_divergence(q_i[overlap], qj_rot)
            total_error += np.sum(D_kl)
            total_weight += np.sum(overlap)

    return total_error / (total_weight + 1e-8)
import numpy as np
import config
from generalized_math_utils import masked_norm
from scipy.ndimage import laplace

# Default support cutoff (from config)
_DEFAULT_CUTOFF = getattr(config, "support_cutoff_eps", 1e-3)

def compute_phi_delta_norm(
    agents,
    params: dict | None = None,
    delta_phi_field_name: str = "delta_phi",
    mask_field: str = "mask",
) -> float:
    """
    Compute the maximum update‐step norm of delta_phi across all agents.
    Hyperparameter support_cutoff_eps is pulled from params or config.
    Returns 0.0 if no valid values are found.
    """
    src = params or {}
    dphi_name = src.get("delta_phi_field_name", delta_phi_field_name)
    mask_name = src.get("mask_field",          mask_field)
    cutoff    = src.get("support_cutoff_eps", _DEFAULT_CUTOFF)

    norms = []
    for agent in agents:
        delta = getattr(agent, dphi_name, None)
        mask  = getattr(agent, mask_name, None)
        if delta is None or mask is None:
            continue

        support = mask > cutoff
        if not support.any():
            continue

        delta_norm = np.linalg.norm(delta, axis=-1)
        norms.append(np.max(delta_norm[support]))

    return float(max(norms)) if norms else 0.0


def log_phi_diagnostics(
    agents,
    step: int,
    params: dict | None = None,
    phi_field: str = "phi",
    delta_phi_field: str = "delta_phi",
    mask_field: str = "mask",
) -> dict:
    """
    Logs φ field diagnostics (norm, Laplacian norm, update magnitude) for a given phi field.
    All hyperparameters are pulled from params or config.
    Returns a dict with keys: step, phi_norm, lap_phi_norm, delta_phi_norm.
    """
    src        = params or {}
    pf_name    = src.get("phi_field",            phi_field)
    dpf_name   = src.get("delta_phi_field",     delta_phi_field)
    m_name     = src.get("mask_field",           mask_field)
    cutoff     = src.get("support_cutoff_eps",   _DEFAULT_CUTOFF)

    phi_norms   = []
    lap_norms   = []
    delta_norms = []

    for agent in agents:
        phi  = getattr(agent, pf_name, None)
        mask = getattr(agent, m_name,  None)
        if phi is None or mask is None:
            continue

        support_count = np.sum(mask > cutoff)
        if support_count < 1:
            continue

        # Mean norm of phi over support
        norm_phi = masked_norm(phi, mask) / np.sqrt(support_count)
        phi_norms.append(norm_phi)

        # Mean Laplacian norm over support
        lap_field = np.stack([laplace(phi[..., d]) for d in range(phi.shape[-1])], axis=-1)
        norm_lap  = masked_norm(lap_field, mask) / np.sqrt(support_count)
        lap_norms.append(norm_lap)

        # Max update norm over support
        delta = getattr(agent, dpf_name, None)
        if delta is not None:
            norm_delta = masked_norm(delta, mask) / np.sqrt(support_count)
            if np.isfinite(norm_delta):
                delta_norms.append(norm_delta)

    return {
        "step": step,
        "phi_norm":       float(np.mean(phi_norms))   if phi_norms   else 0.0,
        "lap_phi_norm":   float(np.mean(lap_norms))   if lap_norms   else 0.0,
        "delta_phi_norm": float(max(delta_norms))     if delta_norms else 0.0,
    }

def compute_transport_strength(
    agent_i,
    agent_j,
    generators,
    q_field="q",
    phi_field="phi",
    overlap_eps=1e-3,
):
    phi_i = getattr(agent_i, phi_field)
    phi_j = getattr(agent_j, phi_field)
    mask_i = getattr(agent_i, "mask")
    mask_j = getattr(agent_j, "mask")

    overlap_mask = (mask_i * mask_j) > overlap_eps
    if not np.any(overlap_mask):
        return 0.0

    r_vecs = phi_i[overlap_mask] - phi_j[overlap_mask]
    qj_vecs = getattr(agent_j, q_field)[overlap_mask]

    omega_batch = exp_lie_algebra_irrep(r_vecs, generators)
    qj_rot = batch_apply_omega(qj_vecs, omega_batch)

    diffs = qj_vecs - qj_rot
    norms = np.linalg.norm(diffs, axis=-1)

    return np.mean(norms)

def compute_network_transport_strength(
    agents,
    generators,
    q_field="q",
    phi_field="phi",
    overlap_eps=1e-3,
):
    total = 0.0
    count = 0
    for agent_i in agents:
        for neighbor in agent_i.neighbors:
            agent_j = agents[neighbor["id"]]
            ts = compute_transport_strength(
                agent_i, agent_j, generators, q_field=q_field, phi_field=phi_field, overlap_eps=overlap_eps
            )
            total += ts
            count += 1
    return total / (count + 1e-8)

def compute_average_entropy(
    agents,
    q_field="q",
    mask_field="mask",
    log_eps=1e-8,
):
    """
    Compute the average Shannon entropy of belief distributions q over agents,
    masking out points where mask is zero.
    """
    entropies = []
    for agent in agents:
        q = getattr(agent, q_field)
        mask = getattr(agent, mask_field)

        # Clip & normalize
        q_safe = np.clip(q, log_eps, 1.0)
        q_safe = q_safe / (np.sum(q_safe, axis=-1, keepdims=True) + log_eps)

        # Pointwise entropy
        ent = -np.sum(q_safe * np.log(q_safe), axis=-1)

        # Masked mean
        entropies.append(np.sum(ent * mask) / (np.sum(mask) + log_eps))

    return float(np.mean(entropies))

def compute_phi_norm(
    agents,
    phi_field="phi",
    mask_field="mask",
    log_eps=1e-8,
):
    norms = []
    for agent in agents:
        phi = getattr(agent, phi_field)
        mask = getattr(agent, mask_field)
        norms.append(masked_norm(phi, mask) / (np.sum(mask) + log_eps))
    return float(np.mean(norms))

def compute_curvature_norm(
    agents,
    phi_field="phi",
    mask_field="mask",
    generators=None,
    log_eps=1e-8,
):
    """
    Compute the average curvature norm per agent by:
      1) computing each F_{μν}’s Frobenius norm (dict from compute_field_strength),
      2) stacking and averaging across (μ,ν) pairs,
      3) taking a masked spatial mean,
      4) then finally averaging that scalar over agents.
    """
    norms = []
    for agent in agents:
        phi = getattr(agent, phi_field)
        mask = getattr(agent, mask_field)

        # 1) get dict of curvature-norm arrays
        F_dict = compute_field_strength(phi, generators)
        if not F_dict:
            continue

        # 2) stack all scalar-norm arrays along a new last axis
        #    shape: (…, n_pairs)
        F_stack = np.stack(list(F_dict.values()), axis=-1)

        # 3) mean over curvature pairs → shape (…)
        mean_F = np.mean(F_stack, axis=-1)

        # 4) masked spatial average
        spatial_avg = np.sum(mean_F * mask) / (np.sum(mask) + log_eps)
        norms.append(spatial_avg)

    # final: average over agents
    return float(np.mean(norms)) if norms else 0.0

def compute_phi_laplacian_norm(
    agents,
    phi_field="phi",
    mask_field="mask",
    log_eps=1e-8,
):
    norms = []
    for agent in agents:
        phi = getattr(agent, phi_field)
        mask = getattr(agent, mask_field)
        lap_phi = np.stack([laplace(phi[..., d]) for d in range(phi.shape[-1])], axis=-1)
        norms.append(masked_norm(lap_phi, mask) / (np.sum(mask) + log_eps))
    return float(np.mean(norms))

def compute_model_alignment_kl(
    agents,
    generators,
    p_field="p",
    phi_field="phi_model",
    mask_field="mask",
    overlap_eps=1e-3,
    clip_val=10.0,
    log_eps=1e-8,
):
    """
    Compute average KL divergence D_KL(p_i || Ω_ij p_j) over all overlapping agent pairs,
    using batch exponentiation and repair for transport.

    Parameters:
    - agents: list of agent objects
    - generators: Lie algebra generators for exp map
    - p_field: name of model distribution field (default "p")
    - phi_field: name of phase field for model gauge (default "phi_model")
    - mask_field: name of mask field (default "mask")
    - overlap_eps: threshold for overlap masking
    - clip_val: max clipping value for phase difference vectors
    - log_eps: numerical floor for stability

    Returns:
    - average KL divergence (float)
    """
    kl_total = 0.0
    count = 0

    for agent_i in agents:
        p_i = getattr(agent_i, p_field)
        phi_i = getattr(agent_i, phi_field)
        mask_i = getattr(agent_i, mask_field)

        for neighbor in agent_i.neighbors:
            agent_j = agents[neighbor["id"]]
            p_j = getattr(agent_j, p_field)
            phi_j = getattr(agent_j, phi_field)
            mask_j = getattr(agent_j, mask_field)

            overlap = (mask_i * mask_j) > overlap_eps
            if not np.any(overlap):
                continue

            # Clip phase difference for numerical stability
            r_vecs = np.clip(phi_i[overlap] - phi_j[overlap], -clip_val, clip_val)

            pj_vecs = p_j[overlap]
            pi_vecs = p_i[overlap]

            omega_batch = exp_lie_algebra_irrep(r_vecs, generators)
            pj_rot_batch = batch_apply_omega(pj_vecs, omega_batch)

            # Repair forgotten components if applicable
            from generalized_omega import repair_if_forgotten_batch
            pj_rot_batch = repair_if_forgotten_batch(pj_rot_batch, eps=log_eps)

            pi_vecs = np.clip(pi_vecs, log_eps, 1.0)
            pj_rot_batch = np.clip(pj_rot_batch, log_eps, 1.0)

            kl = np.sum(pi_vecs * (np.log(pi_vecs) - np.log(pj_rot_batch)), axis=-1)
            kl_total += np.sum(kl)
            count += np.sum(overlap)

    return kl_total / (count + log_eps)


def compute_phi_alignment_error(
    agents,
    phi_field="phi_model",
    mask_field="mask",
    overlap_eps=1e-3,
):
    """
    Compute average L2 norm difference ‖φ_i - φ_j‖ over overlapping regions of agents.

    Parameters:
    - agents: list of agent objects
    - phi_field: name of phase field (default "phi_model")
    - mask_field: name of mask field (default "mask")
    - overlap_eps: overlap threshold for masking

    Returns:
    - average alignment error (float)
    """
    norms = []

    for agent_i in agents:
        phi_i = getattr(agent_i, phi_field)
        mask_i = getattr(agent_i, mask_field)

        for neighbor in agent_i.neighbors:
            agent_j = agents[neighbor["id"]]
            phi_j = getattr(agent_j, phi_field)
            mask_j = getattr(agent_j, mask_field)

            overlap = (mask_i * mask_j) > overlap_eps
            if not np.any(overlap):
                continue

            delta_phi = phi_i - phi_j
            diff = np.linalg.norm(delta_phi[overlap], axis=-1)
            norms.append(np.mean(diff))

    return float(np.mean(norms)) if norms else 0.0

def compute_kl_divergences(agents, q_field="q", p_field="p", mask_field="mask", log_eps=1e-8, overlap_eps=1e-3):
    """
    Compute the Kullback-Leibler (KL) divergence for all agents in the system.
    It computes both the self KL divergence (D_KL(q_i || p_i)) and the alignment KL divergence 
    between neighbors (D_KL(q_i || Ω_{ij} q_j)).

    Args:
    - agents: list of agent objects with attributes q_field, p_field, mask, neighbors
    - q_field: field name for belief distributions (default "q")
    - p_field: field name for model distributions (default "p")
    - mask_field: field name for masks indicating valid regions (default "mask")
    - log_eps: small epsilon value for numerical stability
    - overlap_eps: threshold for considering overlap in the mask of neighboring agents

    Returns:
    - kl_self: average KL divergence D_KL(q_i || p_i)
    - kl_align: average KL divergence D_KL(q_i || Ω_{ij} q_j) with neighbors
    """
    kl_self = []
    kl_align = []

    for agent in agents:
        q = sanitize_q(getattr(agent, q_field), eps=log_eps)
        p = sanitize_q(getattr(agent, p_field), eps=log_eps)
        mask = getattr(agent, mask_field)

        # Compute self KL divergence: D_KL(q_i || p_i)
        kl = kl_divergence(q, p, eps=log_eps)
        kl_self.append(np.sum(kl * mask) / (np.sum(mask) + log_eps))

        # Compute alignment KL divergence: D_KL(q_i || Ω_{ij} q_j) for neighboring agents
        if len(agent.neighbors) > 0:
            kl_vals = []
            for neighbor in agent.neighbors:
                j = neighbor['id']
                qj = sanitize_q(getattr(agents[j], q_field), eps=log_eps)
                overlap = mask * getattr(agents[j], mask_field)  # Calculate overlap between masks

                # If no overlap, skip this pair
                if not np.any(overlap):
                    continue

                # Compute KL divergence between agent i and its neighbor j
                kl_ij = kl_divergence(q, qj, eps=log_eps)
                kl_vals.append(np.sum(kl_ij * overlap) / (np.sum(overlap) + log_eps))
            kl_align.append(np.mean(kl_vals))
        else:
            kl_align.append(0.0)

    return float(np.mean(kl_self)), float(np.mean(kl_align))

def compute_fisher_information_norm(
    agents,
    q_field="q",
    mask_field="mask",
    log_eps=1e-8,
):
    norms = []

    for agent in agents:
        q = sanitize_q(getattr(agent, q_field), eps=log_eps)
        mask = getattr(agent, mask_field)

        D = q.ndim - 1  # number of spatial dims (exclude fiber dim)
        grad_q = np.gradient(q, axis=tuple(range(D)))

        fisher = sum(np.sum((g**2) / (q + log_eps), axis=-1) for g in grad_q)

        norm = np.sum(fisher * mask) / (np.sum(mask) + log_eps)
        norms.append(norm)

    return float(np.mean(norms)) if norms else 0.0

def compute_cross_model_kl(
    agents,
    generators,
    q_field="q",
    p_field="p",
    phi_field="phi",
    phi_model_field="phi_model",
    mask_field="mask",
    overlap_eps=1e-3,
    log_eps=1e-8,
    clip_val=10.0,
):
    """
    Compute cross-model KL: D_KL(q_i || Ω̃_{ij} p_j) over overlapping agents.

    Parameters:
    - agents: list of agent objects
    - generators: Lie algebra generators for exp map
    - q_field: belief distribution field name
    - p_field: model distribution field name
    - phi_field: belief gauge field name
    - phi_model_field: model gauge field name
    - mask_field: mask attribute name
    - overlap_eps: overlap threshold
    - log_eps: numerical floor
    - clip_val: clipping range for phase difference

    Returns:
    - average cross-model KL divergence (float)
    """
    total_kl = 0.0
    count = 0

    for agent_i in agents:
        q_i = sanitize_q(getattr(agent_i, q_field), eps=log_eps)
        phi_i = getattr(agent_i, phi_field)
        mask_i = getattr(agent_i, mask_field)

        for neighbor in agent_i.neighbors:
            agent_j = agents[neighbor["id"]]
            p_j = sanitize_q(getattr(agent_j, p_field), eps=log_eps)
            phi_j = getattr(agent_j, phi_model_field)
            mask_j = getattr(agent_j, mask_field)

            overlap = (mask_i * mask_j) > overlap_eps
            if not np.any(overlap):
                continue

            q_overlap = q_i[overlap]
            p_j_overlap = p_j[overlap]
            r = phi_i[overlap] - phi_j[overlap]
            r = np.clip(r, -clip_val, clip_val)

            omega = exp_lie_algebra_irrep(r, generators)
            p_rot = batch_apply_omega(p_j_overlap, omega)
            p_rot = repair_if_forgotten_batch(p_rot, eps=log_eps)

            # Normalize p_rot to ensure it's a distribution
            p_rot /= (np.sum(p_rot, axis=-1, keepdims=True) + log_eps)

            kl = np.sum(q_overlap * (np.log(q_overlap) - np.log(p_rot + log_eps)), axis=-1)
            total_kl += np.sum(kl)
            count += np.sum(overlap)

    return total_kl / (count + log_eps)


def compute_information_update_norm(
    agent,
    delta_q_field="delta_q",
    mask_field="mask",
    log_eps=1e-8,
):
    """
    Compute norm of information update delta_q for a single agent.

    Parameters:
    - agent: single agent object
    - delta_q_field: attribute name for delta_q
    - mask_field: mask attribute name
    - log_eps: numerical floor

    Returns:
    - scalar norm of information update
    """
    dq = getattr(agent, delta_q_field, None)
    if dq is None:
        return 0.0

    mask = getattr(agent, mask_field)
    norm = np.linalg.norm(dq, axis=-1)
    return np.sum(norm * mask) / (np.sum(mask) + log_eps)


def log_all_metrics(
    agents,
    step,
    params: dict,
    generators,
    q_field="q",
    p_field="p",
    phi_belief_field="phi",
    phi_model_field="phi_model"
):
    """
    Compute and return a dictionary of all relevant diagnostics at the given step.
    Works with arbitrary φ-fields and general structure groups.
    """
    if params is None:
        import config
        params = {k: getattr(config, k) for k in dir(config) if not k.startswith("__")}

    """
    Compute and return a dictionary of all relevant diagnostics at the given step.
    Works with arbitrary φ-fields and general structure groups.
    """
    from generalized_diagnostics_metrics import (
        compute_kl_divergences,
        compute_model_alignment_kl,
        compute_average_entropy,
        compute_total_energy,
        compute_phi_norm,
        compute_phi_laplacian_norm,
        compute_phi_delta_norm,
        compute_phi_alignment_error,
        compute_curvature_norm,
        compute_fisher_information_norm,
        compute_cross_model_kl
    )
    
    kl_self, kl_align = compute_kl_divergences(agents)

    return {
        "step": step,
        "kl_self": kl_self,
        "kl_align": kl_align,
        "kl_model_align": compute_model_alignment_kl(agents, generators),
        "total_energy": compute_total_energy(agents, generators, params),
        "phi_norm": compute_phi_norm(agents, "phi"),
        "phi_model_norm": compute_phi_norm(agents, "phi_model"),
        "phi_model_align_error": compute_phi_alignment_error(agents, phi_field="phi_model"),
        "phi_belief_align_error": compute_phi_alignment_error(agents, phi_field="phi"),
        "delta_phi_norm": compute_phi_delta_norm(agents),
        "cross_model_kl": compute_cross_model_kl(agents, generators),
    }
