# -*- coding: utf-8 -*-
"""
Created on Sun Jun 15 11:16:31 2025

@author: chris and christine
"""

import config

def set_config_from_params(params):
    """Dynamically override attributes in the config module from a dictionary."""
    for k, v in params.items():
        setattr(config, k, v)
