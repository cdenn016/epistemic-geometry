import numpy as np
import sys

# ===========================
# DEBUGGING AND UTILITIES
# ===========================

debug = True  # Global debug flag for extra logging inside φ updates

def set_config_from_params(params):
    """Dynamically override config attributes from a dictionary."""
    this_module = sys.modules[__name__]
    for k, v in params.items():
        setattr(this_module, k, v)

# ===========================
# GROUP & REPRESENTATION SETTINGS
# ===========================

group_name = 'sl2r'               # Options: "u1", "so3", "sl2r", etc.
representation_type = 'irrep'     # Options: 'irrep', 'fundamental', 'adjoint'

# Fiber dimension of belief/model space (depends on representation)
K = 43                          # Must match the dimension of your irrep

# ===========================
# DOMAIN / SPATIAL SETTINGS
# ===========================

D = 2            #dimension of base manifold

L = 25           #length of hypercubic base-manifold

steps = 150


# ===========================
# COUPLINGS & PENALTIES
# ===========================

alpha = 1                     # KL(q || p) self-energy
beta = 2                     # KL(q || Ω q) belief coupling
gamma = 1                     # Laplacian penalty on φ
gauge_weight = 1              # φ² mass term

model_align_weight = 2        # KL(p || Ω̃ p)
model_gauge_weight = 1        # Laplacian penalty on φ_model
model_mass_weight = 2         # φ_model² mass term
model_feedback_weight = 1     # KL feedback p || q

phi_phi_tilde_coupling = 2    # Coupling φ ↔ φ̃

curvature_weight = 0
phi_damping = 0


psi_radius_range = (5, 10)         #agent radii

# ===========================
# DISTRIBUTION SETTINGS
# ===========================

distribution_family = 'exponential'   # Options: "gaussian", "exponential", "beta". "uniform", etc.
N = 3                              # Number of agents
max_neighbors = 2                  # Max number of agent neighbors

q_mu_range = (2, K - 2)
q_sigma_range = (2, 5)
p_mu_range = (2, K - 2)
p_sigma_range = (1, 8)
similar_p_models = False

# ===========================
# AGENT GEOMETRY
# ===========================

mu_sigma_scale_range = (5, 10)

mask_sharpness = 1.5
mu_field_smooth_range = (4, 8)
sigma_field_smooth_range = (3, 6)

# ===========================
# INITIALIZATION
# ===========================

agent_seed = 12
generate_soft_mask = 1
phi_init = 0.1
phi_model_offset = 0.1

# ===========================
# LEARNING RATES
# ===========================

eta_q = 0.0001
eta_phi = 0.00001
eta_p = 0.001
eta_model_phi = 0.000001

# ===========================
# STABILITY AND CLIPPING
# ===========================

phi_clip_threshold = 4000       # scale down large φ shifts
phi_max_norm       = 100       # keep φ in a reasonable reference frame
gradient_clip      = 10.0      # if also applied to φ gradients
blowup_threshold   = 4000.0      # skip updates that are clearly unstable
phi_diff_clip = 3.0            # or experiment with values like 2.0 or 5.0


# ===========================
# EPSILONS & PRECISION
# ===========================

log_eps = 1e-10
support_cutoff_eps = 1e-3
overlap_eps = 1e-5
eps = 1e-10

precision = np.float32

# ===========================
# CHECKPOINTING
# ===========================

checkpoint_dir = "checkpoints"
save_checkpoints = True
checkpoint_interval = 1

domain_size = (L,) * D