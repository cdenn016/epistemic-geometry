# lhs_sweeper.py

import os
import numpy as np
import pickle
from scipy.stats import qmc
from generalized_simulation import run_simulation
from config import set_config_from_params

def lhs_sample(param_ranges, n_samples):
    """Generate Latin Hypercube Samples for given parameter ranges."""
    sampler = qmc.LatinHypercube(d=len(param_ranges))
    sample = sampler.random(n=n_samples)
    l_bounds = np.array([lo for lo, hi in param_ranges])
    u_bounds = np.array([hi for lo, hi in param_ranges])
    scaled = qmc.scale(sample, l_bounds, u_bounds)
    return scaled

def run_lhs_sweep(n_samples=50, output_dir="lhs_results"):
    os.makedirs(output_dir, exist_ok=True)

    # Primary parameters to sweep
    sweep_params = {
        "alpha": (0.0, 2.0),
        "beta": (0.0, 2.0),
        "gamma": (0.0, 2.0),
        "gauge_weight": (0.0, 2.0),
        "model_align_weight": (0.0, 2.0),
        "model_gauge_weight": (0,2),
        "model_mass_weight": (0,2),
        "model_feedback_weight": (0.0, 2.0),
        "phi_phi_tilde_coupling": (0.0, 2.0),
        #"curvature_weight": (0.0, 2.0),
        #"phi_damping": (0.0, 1.0),
    }

    param_names = list(sweep_params.keys())
    ranges = [sweep_params[k] for k in param_names]
    samples = lhs_sample(ranges, n_samples)

    # Save sweep spec
    sweep_spec = {
        "param_names": param_names,
        "ranges": sweep_params,
        "samples": samples.tolist()
    }
    with open(os.path.join(output_dir, "sweep_spec.pkl"), "wb") as f:
        pickle.dump(sweep_spec, f)

    for i, row in enumerate(samples):
        param_dict = dict(zip(param_names, row))
        print(f"\n[SAMPLE {i}] {param_dict}")

        subdir = os.path.join(output_dir, f"run_{i}")
        os.makedirs(subdir, exist_ok=True)

        agents, metrics = run_simulation(
            outdir=subdir,
            resume=False,
            log_metrics=True,
            num_cores=4,
            params=param_dict
        )

        with open(os.path.join(subdir, "final_agents.pkl"), "wb") as f:
            pickle.dump(agents, f)

        with open(os.path.join(subdir, "final_metrics.pkl"), "wb") as f:
            pickle.dump(metrics, f)
        
        # Save sampled parameters for this run
        with open(os.path.join(subdir, "params.pkl"), "wb") as f:
            pickle.dump(param_dict, f)


    print(f"[DONE] LHS sweep complete: {n_samples} samples → {output_dir}")

if __name__ == "__main__":
    run_lhs_sweep(n_samples=50)
