import numpy as np
import config

from get_generators import get_generators
from generalized_omega import (
    exp_lie_algebra_irrep,
    batch_apply_omega,
    repair_if_forgotten_batch,
)
from generalized_math_utils import sanitize_q

# generalized_update_terms.py
import numpy as np
import config


from get_generators import get_generators
from generalized_omega import (
    exp_lie_algebra_irrep,
    batch_apply_omega,
    repair_if_forgotten_batch,
)
from generalized_math_utils import sanitize_q


def compute_self_gradient(
    agent_i,
    dist_field_q: str,
    dist_field_p: str,
    mask_field: str,
    params: dict
) -> np.ndarray:
    
    # Pull hyperparameters (no hard-coded literals)
    alpha = params.get("alpha", config.alpha)
    log_eps = params.get("log_eps", config.log_eps)
    support_cutoff = params.get("support_cutoff_eps", config.support_cutoff_eps)

    q = getattr(agent_i, dist_field_q)
    p = getattr(agent_i, dist_field_p)
    mask = getattr(agent_i, mask_field)
    support = mask > support_cutoff

    grad = np.zeros_like(q)
    if alpha > 0 and support.any():
        q_s = q[support]
        p_s = p[support]
        q_s = q_s / (q_s.sum(-1, keepdims=True) + log_eps)
        p_s = p_s / (p_s.sum(-1, keepdims=True) + log_eps)
        q_s = np.clip(q_s, log_eps, 1.0)
        p_s = np.clip(p_s, log_eps, 1.0)
        g = -q_s / p_s  # ∂KL/∂p
        grad[support] = alpha * np.clip(g, -config.gradient_clip, config.gradient_clip)

    return grad

def compute_alignment_gradient(
    agent_i,
    agents: list,
    dist_field: str,
    phi_field: str,
    params: dict
) -> np.ndarray:
    
    # Pull hyperparameters
    align_weight = params.get("beta", config.beta)
    overlap_eps = params.get("overlap_eps", config.overlap_eps)
    log_eps = params.get("log_eps", config.log_eps)
    clip_val = params.get("phi_diff_clip", getattr(config, "phi_diff_clip", 5.0))  # NEW

    if align_weight <= 0:
        return np.zeros_like(getattr(agent_i, dist_field))

    gens = get_generators(config.group_name, config.K)
    dist_i = getattr(agent_i, dist_field)
    phi_i  = getattr(agent_i, phi_field)
    mask_i = agent_i.mask
    grad   = np.zeros_like(dist_i)

    for nb in agent_i.neighbors:
        j = nb["id"]
        aj = agents[j]
        overlap = (mask_i * aj.mask) > overlap_eps
        if not overlap.any():
            continue

        # transport j→i
        r_vecs = phi_i[overlap] - getattr(aj, phi_field)[overlap]
        r_vecs = np.clip(r_vecs, -clip_val, clip_val)  # ✅ NEW CLIP

        dj = sanitize_q(getattr(aj, dist_field)[overlap], eps=log_eps)
        Ω_batch = exp_lie_algebra_irrep(r_vecs, gens)
        dj_rot = batch_apply_omega(dj, Ω_batch)
        dj_rot = repair_if_forgotten_batch(dj_rot, eps=log_eps)
        dj_rot = sanitize_q(dj_rot, eps=log_eps)

        di = sanitize_q(dist_i[overlap], eps=log_eps)
        g = np.log((di + log_eps) / (dj_rot + log_eps)) + 1.0
        g = np.nan_to_num(np.clip(g, -config.gradient_clip, config.gradient_clip))

        idxs = np.argwhere(overlap)
        for k, coord in enumerate(idxs):
            grad[tuple(coord)] += align_weight * g[k]

    return grad

# The wrapper functions compute_beliefs_gradient and compute_models_gradient
# unchanged, but now pass params dict to the above functions:

def compute_beliefs_gradient(agent_i, agents, params):
    return (
        compute_self_gradient(agent_i, "q", "p", "mask", params)
      + compute_alignment_gradient(agent_i, agents, "q", "phi", params)
    )


def compute_models_gradient(agent_i, agents, params):
    return (
        compute_alignment_gradient(agent_i, agents, "p", "phi_model", params)
      + compute_self_gradient(agent_i, "q", "p", "mask", params)
    )


def compute_phi_alignment_gradient(agent_i, agents, params):
    """
    
    Works for arbitrary D and any group.
    """
    import numpy as np
    import config
    
    from generalized_math_utils import sanitize_q
    from generalized_omega import exp_lie_algebra_irrep, batch_apply_omega, repair_if_forgotten_batch

    # Pull hyperparameters
    beta        = params.get("beta", config.beta)
    log_eps     = params.get("log_eps", config.log_eps)
    overlap_eps = params.get("overlap_eps", config.overlap_eps)
    clip_val    = params.get("phi_diff_clip", getattr(config, "phi_diff_clip", 5.0))  # ✅ NEW

    if beta <= 0:
        return np.zeros_like(agent_i.phi)

    # generators.shape = (dim_G, K, K)
    gens   = get_generators(config.group_name, config.K)
    phi_i  = agent_i.phi
    q_i    = sanitize_q(agent_i.q, eps=log_eps)
    mask_i = agent_i.mask

    delta_phi = np.zeros_like(phi_i)

    for nb in agent_i.neighbors:
        j  = nb["id"]
        aj = agents[j]
        overlap = (mask_i * aj.mask) > overlap_eps
        if not overlap.any():
            continue

        # build overlapping vectors
        r_vecs    = phi_i[overlap] - aj.phi[overlap]           # (n_overlap, dim_G)
        r_vecs    = np.clip(r_vecs, -clip_val, clip_val)       # ✅ NEW CLIP

        qj_vecs   = sanitize_q(aj.q[overlap], eps=log_eps)
        qi_vecs   = q_i[overlap]
        mask_vals = mask_i[overlap]

        # transport q_j → Ω q_j
        Ω_batch = exp_lie_algebra_irrep(r_vecs, gens)
        qj_rot  = batch_apply_omega(qj_vecs, Ω_batch)
        qj_rot  = repair_if_forgotten_batch(qj_rot, eps=log_eps)
        qj_rot  = sanitize_q(qj_rot, eps=log_eps)

        # compute difference direction
        diff = qi_vecs - qj_rot  # (n_overlap, K)

        # for each Lie‐generator direction a
        indices = np.argwhere(overlap)
        for a in range(gens.shape[0]):
            G     = gens[a]  # (K, K)
            dΩ_dφ = np.einsum('nij,jk->nik', Ω_batch, G)
            dΩq   = np.einsum('nik,nk->ni', dΩ_dφ, qj_vecs)
            grad_a= np.einsum('ni,ni->n', dΩq, diff)
            for idx, coord in enumerate(indices):
                delta_phi[(*coord, a)] += beta * grad_a[idx] * mask_vals[idx]

    return delta_phi

def compute_phi_model_update(agent_i, agents, params):
    """
    
    Same structure as compute_phi_alignment_gradient but for the model field.
    """
    import numpy as np
    import config
    from generalized_math_utils import sanitize_q
    from generalized_omega import (
        exp_lie_algebra_irrep,
        batch_apply_omega,
        repair_if_forgotten_batch,
    )

    # Pull hyperparameters
    beta_tilde   = params.get("beta_tilde",       config.model_align_weight)
    overlap_eps  = params.get("overlap_eps",      config.overlap_eps)
    log_eps      = params.get("log_eps",          config.log_eps)
    clip_val     = params.get("phi_diff_clip",    getattr(config, "phi_diff_clip", 5.0))  # ✅ NEW

    if beta_tilde <= 0:
        return np.zeros_like(agent_i.phi_model)

    # Prepare
    gens      = get_generators(config.group_name, config.K)
    phi_model = agent_i.phi_model
    p_full    = sanitize_q(agent_i.p, eps=log_eps)
    mask_i    = agent_i.mask

    delta_phi_model = np.zeros_like(phi_model)

    for nb in agent_i.neighbors:
        j   = nb["id"]
        aj  = agents[j]
        overlap = (mask_i * aj.mask) > overlap_eps
        if not overlap.any():
            continue

        # Differences in gauge fields
        r_vecs  = phi_model[overlap] - aj.phi_model[overlap]
        r_vecs  = np.clip(r_vecs, -clip_val, clip_val)  # ✅ NEW CLIP
        pj_vecs = sanitize_q(aj.p[overlap], eps=log_eps)
        pi_vecs = p_full[overlap]
        coords  = np.argwhere(overlap)

        # Transport p_j → Ω p_j
        Ω_batch = exp_lie_algebra_irrep(r_vecs, gens)
        pj_rot  = batch_apply_omega(pj_vecs, Ω_batch)
        pj_rot  = repair_if_forgotten_batch(pj_rot, eps=log_eps)
        pj_rot  = sanitize_q(pj_rot, eps=log_eps)

        diff = pi_vecs - pj_rot  # (n_overlap, K)

        # Loop over Lie‐generator directions
        for a in range(gens.shape[0]):
            G      = gens[a]
            dΩ_dφ  = np.einsum('nij,jk->nik', Ω_batch, G)
            dΩp    = np.einsum('nik,nk->ni', dΩ_dφ, pj_vecs)
            # ∇_{φ_model} KL(pi||pj_rot) = −⟨dΩp, diff⟩
            grad_a = -np.einsum('ni,ni->n', dΩp, diff)
            for idx, coord in enumerate(coords):
                delta_phi_model[(*coord, a)] += beta_tilde * grad_a[idx] * mask_i[tuple(coord)]

    return delta_phi_model



