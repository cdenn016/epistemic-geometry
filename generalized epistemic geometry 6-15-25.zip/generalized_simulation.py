import config
import generalized_update_rules
import generalized_update_terms
import generalized_update_wrappers

import importlib
importlib.reload(config)  # load all config constants
importlib.reload(generalized_update_rules)
importlib.reload(generalized_update_terms)
importlib.reload(generalized_update_wrappers)

import os
import time
import numpy as np
from joblib import Parallel, delayed

# Import wrappers for updates
from generalized_update_wrappers import (
    update_beliefs,
    update_models,
    update_phi,
    update_phi_model,
)

from generalized_io_utils import (save_step, load_checkpoint, 
        find_resume_step, save_config_to_readme)
from generalized_diagnostics_metrics import log_all_metrics
from generalized_agents import (
    initialize_agents,
    generate_soft_mask,
    smooth_random_field,
    scale_to_range,
)
from generalized_agent_distributions import initialize_distribution
from get_generators import get_generators, infer_lie_algebra_dim
from generalized_agent_schema import Agent
import generalized_update_wrappers  # ensure module visibility
from config import K, group_name

from config_utils import set_config_from_params


import config


def run_simulation(
    outdir="checkpoints",
    resume=True,
    log_metrics=True,
    num_cores=None,
    params=None,
):
    # 1) Determine number of cores
    if num_cores is None:
        import multiprocessing
        num_cores = multiprocessing.cpu_count()

    # 2) Override config values if provided
    if params:
        set_config_from_params(params)


    os.makedirs(outdir, exist_ok=True)
    save_config_to_readme(outdir)

    # 3) Load checkpoint or initialize agents
    agents, _ = load_checkpoint(outdir) if resume else (None, None)
    step_start = find_resume_step(outdir) if resume else 0

    lie_algebra_dim = infer_lie_algebra_dim(config.group_name, config.K)


    if agents is None:
        print("[INIT] Initializing new agents…")
        agents = initialize_agents(
            seed=config.agent_seed,
            phi_init=config.phi_init,
            domain_size=config.domain_size,
            N=config.N,
            K=config.K,
            lie_algebra_dim=lie_algebra_dim,
            config=config,
            generate_soft_mask=generate_soft_mask,
            smooth_random_field=smooth_random_field,
            scale_to_range=scale_to_range,
            Agent=Agent,
        )
        
        step_start = 0

    # 4) Precompute Lie‑algebra generators
    generators = get_generators(config.group_name, config.K)

    metric_log = []
    print(f"[RUN] Starting simulation at step {step_start} with {num_cores} cores")

    for step in range(step_start, config.steps):
        print(f"\n[STEP {step}] -----------------------------")

        # Timer: beliefs update
        t0 = time.perf_counter()
        agents = Parallel(n_jobs=num_cores, backend="loky")(  # beliefs
            delayed(update_beliefs)(i, agents, params) for i in range(config.N)
        )
        t1 = time.perf_counter()
        print(f"[TIMER] update_beliefs: {t1-t0:.3f}s")

        # Timer: models update
        t0 = time.perf_counter()
        agents = Parallel(n_jobs=num_cores, backend="loky")(  # models
            delayed(update_models)(i, agents, params) for i in range(config.N)
        )
        t1 = time.perf_counter()
        print(f"[TIMER] update_models: {t1-t0:.3f}s")

        # Timer: phi update
        t0 = time.perf_counter()
        agents = Parallel(n_jobs=num_cores, backend="loky")(  # phi
            delayed(update_phi)(i, agents, params) for i in range(config.N)
        )
        t1 = time.perf_counter()
        print(f"[TIMER] update_phi: {t1-t0:.3f}s")

        # Timer: phi_model update
        t0 = time.perf_counter()
        agents = Parallel(n_jobs=num_cores, backend="loky")(  # phi_model
            delayed(update_phi_model)(i, agents, params) for i in range(config.N)
        )
        t1 = time.perf_counter()
        print(f"[TIMER] update_phi_model: {t1-t0:.3f}s")

        # Save state
        save_step(agents, outdir, step)

        # Timer: logging metrics
        if log_metrics:
            t0 = time.perf_counter()
            m = log_all_metrics(
                agents,
                step,
                params=params,
                generators=generators,               # <-- critical for KL over group
                q_field="q",
                p_field="p",
                phi_belief_field="phi",
                phi_model_field="phi_model",
                )
            metric_log.append(m)
            t1 = time.perf_counter()
            print(f"[TIMER] log_all_metrics: {t1-t0:.3f}s")


    # Finalize metric log
    if log_metrics:
        import pickle
        with open(os.path.join(outdir, "metric_log.pkl"), "wb") as f:
            pickle.dump(metric_log, f)
        print(f"[SAVE] Metrics log → {outdir}/metric_log.pkl")

    print("[DONE] Simulation completed.")
    return agents, metric_log


if __name__ == "__main__":
   
    agents, metrics = run_simulation(
    outdir="checkpoints",
    resume=False,
    log_metrics=True,
    num_cores=4,
    params=None   # ← this is the key!
)

   
