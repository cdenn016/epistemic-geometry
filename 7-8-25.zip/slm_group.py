
import numpy as np
from scipy.linalg import expm, logm

def is_sl_matrix(M, tol=1e-6):
    """Check whether a matrix M is in sl(M,R): trace zero."""
    return np.abs(np.trace(M)) < tol

def project_to_sl(M):
    """Project an arbitrary square matrix to sl(M,R) by zeroing its trace."""
    trace = np.trace(M)
    dim = M.shape[0]
    return M - (trace / dim) * np.eye(dim)

def exp_sl(phi_batch):
    """
    Compute exp(φ) for a batch of Lie algebra elements φ ∈ sl(M,R).
    Input:
        phi_batch: (..., M, M) array of trace-zero matrices
    Output:
        omega_batch: (..., M, M) array of exp(φ)
    """
    phi_batch = np.asarray(phi_batch)
    shape = phi_batch.shape
    M = shape[-1]
    flat = phi_batch.reshape(-1, M, M)
    result = np.stack([expm(phi) for phi in flat], axis=0)
    return result.reshape(shape)

def log_sl(omega_batch):
    """
    Compute log(Ω) for a batch of SL(M,R) matrices.
    Input:
        omega_batch: (..., M, M) array of SL matrices
    Output:
        phi_batch: (..., M, M) array of trace-zero matrices (Lie algebra elements)
    """
    omega_batch = np.asarray(omega_batch)
    shape = omega_batch.shape
    M = shape[-1]
    flat = omega_batch.reshape(-1, M, M)
    result = np.stack([project_to_sl(np.real_if_close(logm(omega))) for omega in flat], axis=0)
    return result.reshape(shape)
