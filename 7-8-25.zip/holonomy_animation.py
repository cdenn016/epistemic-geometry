import matplotlib.pyplot as plt
import matplotlib.animation as animation
import pandas as pd
import numpy as np
from pathlib import Path
from sklearn.decomposition import PCA
import ast

# ── Load and parse one belief_seq entry ──
def load_belief_seq(df, param_key):
    belief_seq_raw = df.loc[df["param"] == param_key, "belief_seq"].values
    if len(belief_seq_raw) == 0:
        raise ValueError(f"No entry found for param={param_key}")
    
    try:
        scope = {
            "np": np,
            "array": np.array,
            "float32": np.float32,
            "float64": np.float64,
        }
        parsed = eval(belief_seq_raw[0], scope)  # parsed is list of arrays (or list of lists)
        parsed = [np.asarray(x) for x in parsed]  # convert everything to arrays

        shapes = [x.shape for x in parsed]
        most_common_shape = max(set(shapes), key=shapes.count)
        filtered = [x for x in parsed if x.shape == most_common_shape]

        skipped = len(parsed) - len(filtered)
        if skipped > 0:
            print(f"[SKIP] Skipped {skipped} malformed steps (inconsistent shape: {set(shapes)})")

        mu_seq = np.stack(filtered)
        print(f"[INFO] Loaded μ(t) of shape {mu_seq.shape} for param={param_key}")
        return mu_seq

    except Exception as e:
        raise RuntimeError(f"[PARSE ERROR] Could not evaluate μ(t) for param={param_key}: {e}")



# ── 1. Animate ‖μ(t)‖ norm ──
def animate_mu_norm(mu_seq, save_path):
    import numpy as np
    import matplotlib.pyplot as plt
    from matplotlib import animation

    mu_seq = np.array(mu_seq)
    if mu_seq.ndim == 4 and mu_seq.shape[0] == 1:
        mu_seq = mu_seq[0]  # (1, T, H, W) → (T, H, W)
    if mu_seq.ndim == 3:  # (T, H, W)
        mu_seq = mu_seq.reshape(mu_seq.shape[0], -1)  # Flatten spatial dims

    norms = np.linalg.norm(mu_seq, axis=1)

    T = len(norms)

    fig, ax = plt.subplots()
    ax.set_title("‖μ(t)‖ Norm Over Time")
    ax.set_xlim(0, T)
    ax.set_ylim(0, 1.1 * np.max(norms))

    # Initialize with empty line
    line, = ax.plot([], [], lw=2, color="blue")

    def update(i):
        x = np.arange(i + 1)
        y = norms[:i + 1]
        line.set_data(x, y)
        return line,

    ani = animation.FuncAnimation(fig, update, frames=T, interval=150, blit=True)
    ani.save(save_path / "mu_norm.gif", dpi=100)
    plt.close()
    print(f"[SAVED] {save_path / 'mu_norm.gif'}")

# ── 2. Plot μᵢ(t) for each component ──
def plot_mu_components(mu_seq, save_path, highlight_inds=None, num_highlight=5):
    """
    Plots μ_k(t) for selected components.
    - Highlights a few in color, greys out the rest.
    - Supports mu_seq of shape: (1, T, K), (T, K), (1, T, H, W), or (T, H, W)
    """
    mu_seq = np.array(mu_seq)
    if mu_seq.ndim == 4 and mu_seq.shape[0] == 1:
        mu_seq = mu_seq[0]  # (1, T, H, W) → (T, H, W)
    if mu_seq.ndim == 3:
        mu_seq = mu_seq.reshape(mu_seq.shape[0], -1)  # (T, K_eff)

    T, K = mu_seq.shape

    # Choose highlighted indices
    if highlight_inds is None:
        np.random.seed(42)  # for reproducibility
        highlight_inds = np.random.choice(K, size=min(num_highlight, K), replace=False)

    time = np.linspace(0, 1, T)
    plt.figure(figsize=(8, 5))

    for k in range(K):
        color = f"C{k%10}" if k in highlight_inds else "gray"
        alpha = 1.0 if k in highlight_inds else 0.25
        lw = 2.0 if k in highlight_inds else 1.0
        label = f"$\\mu_{{{k}}}$" if k in highlight_inds else None
        plt.plot(time, mu_seq[:, k], color=color, lw=lw, alpha=alpha, label=label)

    plt.xlabel("Time")
    plt.ylabel("Value")
    plt.title("μ(t) Components")
    if highlight_inds is not None and len(highlight_inds) > 0:
        plt.legend(fontsize=8)
    plt.tight_layout()
    plt.savefig(save_path / "mu_components.png", dpi=150)
    plt.close()
    print(f"[SAVED] {save_path / 'mu_components.png'}")



# ── 3. Animate μ(t) in PCA space ──
from sklearn.decomposition import PCA

def animate_mu_pca(mu_seq, save_path):
    mu_seq = np.array(mu_seq)
    if mu_seq.ndim == 5:
        mu_seq = mu_seq[0]  # Remove batch dim if present (1, T, H, W, K) → (T, H, W, K)
    elif mu_seq.ndim == 4 and mu_seq.shape[0] == 1:
        mu_seq = mu_seq[0]  # (1, T, K) → (T, K)

    original_shape = mu_seq.shape  # e.g., (T, H, W, K)

    # Reshape to (T, K_eff) where K_eff = H × W × K or H × W
    mu_flat = mu_seq.reshape(mu_seq.shape[0], -1)

    # Run PCA on time series
    pca = PCA(n_components=2)
    xy = pca.fit_transform(mu_flat)  # shape (T, 2)

    # Animate
    T = xy.shape[0]
    fig, ax = plt.subplots()
    ax.set_title("μ(t) PCA Projection")
    ax.set_xlim(np.min(xy[:, 0]), np.max(xy[:, 0]))
    ax.set_ylim(np.min(xy[:, 1]), np.max(xy[:, 1]))
    line, = ax.plot([], [], lw=2)
    point, = ax.plot([], [], "ro")

    def update(i):
        line.set_data(xy[:i+1, 0], xy[:i+1, 1])
        point.set_data([xy[i, 0]], [xy[i, 1]])  # <-- FIXED HERE
        return line, point


    ani = animation.FuncAnimation(fig, update, frames=T, interval=150, blit=True)
    ani.save(save_path / "mu_pca.gif", dpi=100)
    plt.close()
    print(f"[SAVED] {save_path / 'mu_pca.gif'}")


# ── Main Entrypoint ──
def main():
    df = pd.read_csv("holonomy_experiments/master_summary.csv")
    param_key = df["param"].iloc[0]  # or pick one like "0_5_4_2_0"
    mu_seq = load_belief_seq(df, param_key)

    SAVE_DIR = Path("Holonomy_Visualizations/μ_diagnostics")
    SAVE_DIR.mkdir(parents=True, exist_ok=True)

    print(f"[INFO] Loaded μ(t) of shape {mu_seq.shape} for param={param_key}")

    animate_mu_norm(mu_seq, SAVE_DIR)
    plot_mu_components(mu_seq, SAVE_DIR)
    animate_mu_pca(mu_seq, SAVE_DIR)
    print(f"[DONE] Saved all μ diagnostics to {SAVE_DIR}")

if __name__ == "__main__":
    main()
