"""
generalized_update_wrappers.py

Legacy API compatibility layer:
Provides the same function names that generalized_simulation expects
but delegates to a single synchronous_step orchestrator.
"""

from generalized_update_rules import synchronous_step




def update_all(agents, params=None):
    """
    Perform one full synchronous update of q, p, phi, and phi_model.
    Returns the updated agents list.
    """
    return synchronous_step(agents, params)


def update_beliefs(i, agents, params=None):
    """
    Backwards-compatible stub: runs a full synchronous update,
    then returns the specified agent.
    """
    synchronous_step(agents, params)
    return agents[i]


def update_models(i, agents, params=None):
    """
    Backwards-compatible stub: runs a full synchronous update,
    then returns the specified agent.
    """
    synchronous_step(agents, params)
    return agents[i]


def update_phi(i, agents, params=None):
    """
    Backwards-compatible stub: runs a full synchronous update,
    then returns the specified agent.
    """
    synchronous_step(agents, params)
    return agents[i]


def update_phi_model(i, agents, params=None):
    """
    Backwards-compatible stub: runs a full synchronous update,
    then returns the specified agent.
    """
    synchronous_step(agents, params)
    return agents[i]
