import numpy as np
import config

from generalized_math_utils import sanitize_q
from get_generators import get_generators
from transport_operator import compute_inter_agent_omega
from generalized_omega import batch_apply_omega, repair_if_forgotten_batch


def compute_self_gradient(agent_i, dist_field_q: str, dist_field_p: str, mask_field: str, params: dict) -> np.ndarray:
    """
    Compute ∇_{q_i} [ α · D_KL(q_i || p_i) ].
    """
    α = params.get("alpha", config.alpha)
    log_eps = params.get("log_eps", config.log_eps)
    support_eps = params.get("support_cutoff_eps", config.support_cutoff_eps)

    q = getattr(agent_i, dist_field_q)
    p = getattr(agent_i, dist_field_p)
    mask = getattr(agent_i, mask_field)

    grad = np.zeros_like(q)
    support = mask > support_eps
    if α > 0 and np.any(support):
        q_s = sanitize_q(q[support], eps=log_eps)
        p_s = sanitize_q(p[support], eps=log_eps)
        # ∂/∂q [D_KL(q||p)] = log(q/p) + 1
        grad_support = α * (np.log(q_s / p_s) + 1.0)
        grad[support] = grad_support
    return grad


def compute_alignment_gradient(agent_i, agents: list, dist_field: str, phi_field: str, params: dict) -> np.ndarray:
    """
    Compute ∇_{q_i} Σ_j β·D_KL(q_i || Ω_{ij} q_j).
    """
    β = params.get("beta", config.beta)
    overlap_eps = params.get("overlap_eps", config.overlap_eps)
    log_eps = params.get("log_eps", config.log_eps)

    q_i = getattr(agent_i, dist_field)
    phi_i = getattr(agent_i, phi_field)
    mask_i = agent_i.mask > overlap_eps
    grad = np.zeros_like(q_i)
    if β <= 0 or not np.any(mask_i):
        return grad

    gens = get_generators(config.group_name, config.K)
    flat_qi = q_i.reshape(-1, q_i.shape[-1])
    flat_grad = grad.reshape(-1, grad.shape[-1])
    idxs = np.flatnonzero(mask_i)

    for nb in agent_i.neighbors:
        j = nb['id']
        agent_j = agents[j]
        mask_j = agent_j.mask > overlap_eps
        overlap = mask_i & mask_j
        if not np.any(overlap):
            continue

        ov_idxs = np.flatnonzero(overlap)
        qi_vals = flat_qi[ov_idxs]
        qj_vals = agent_j.q.reshape(-1, qi_vals.shape[-1])[ov_idxs]
        phi_i_vals = phi_i.reshape(-1, phi_i.shape[-1])[ov_idxs]
        phi_j_vals = agent_j.phi.reshape(-1, phi_i.shape[-1])[ov_idxs]

        Ω = compute_inter_agent_omega(phi_i_vals, phi_j_vals, None, gens)
        qj_rot = batch_apply_omega(qj_vals, Ω)
        qj_rot = repair_if_forgotten_batch(qj_rot, eps=log_eps)
        qj_rot = sanitize_q(qj_rot, eps=log_eps)

        qi_s = sanitize_q(qi_vals, eps=log_eps)
        # ∂/∂q [D_KL(q||r)] = log(q/r) + 1
        delta = np.log(qi_s / qj_rot) + 1.0
        flat_grad[ov_idxs] += (β / ov_idxs.size) * delta

    return flat_grad.reshape(*grad.shape)


def compute_beliefs_gradient(agent_i, agents: list, params: dict) -> np.ndarray:
    """Combine self and alignment gradients for q."""
    return (
        compute_self_gradient(agent_i, 'q', 'p', 'mask', params)
        + compute_alignment_gradient(agent_i, agents, 'q', 'phi', params)
    )


def compute_models_gradient(agent_i, agents: list, params: dict) -> np.ndarray:
    """Combine self and model-alignment gradients for p."""
    # Self-gradient: ∇_p [α·D_KL(q||p)] = -α·q/p
    α = params.get('alpha', config.alpha)
    log_eps = params.get('log_eps', config.log_eps)
    support_eps = params.get('support_cutoff_eps', config.support_cutoff_eps)

    q = sanitize_q(agent_i.q, eps=log_eps)
    p = getattr(agent_i, 'p')
    mask = agent_i.mask > support_eps

    grad = np.zeros_like(p)
    if α > 0 and np.any(mask):
        q_s = q[mask]
        p_s = sanitize_q(p[mask], eps=log_eps)
        grad_self = -α * (q_s / p_s)
        grad[mask] = grad_self

    # Alignment term
    align = compute_alignment_gradient(agent_i, agents, 'p', 'phi_model', params)
    return grad + align


def compute_phi_alignment_gradient(agent_i, agents: list, params: dict) -> np.ndarray:
    
    from scipy.ndimage import laplace

    β = params.get('beta', config.beta)
    overlap_eps = params.get('overlap_eps', config.overlap_eps)
    log_eps = params.get('log_eps', config.log_eps)

    phi_i = agent_i.phi
    q_i = sanitize_q(agent_i.q, eps=log_eps)
    mask_i = agent_i.mask > overlap_eps
    grad = np.zeros_like(phi_i)
    if β <= 0 or not np.any(mask_i):
        return grad

    gens = get_generators(config.group_name, config.K)
    flat_phi = phi_i.reshape(-1, phi_i.shape[-1])
    flat_q = q_i.reshape(-1, q_i.shape[-1])
    flat_grad = grad.reshape(-1, grad.shape[-1])

    for nb in agent_i.neighbors:
        j = nb['id']
        agent_j = agents[j]
        overlap = mask_i & (agent_j.mask > overlap_eps)
        if not np.any(overlap):
            continue

        ov_idxs = np.flatnonzero(overlap)
        φi_vals = flat_phi[ov_idxs]
        φj_vals = agent_j.phi.reshape(-1, φi_vals.shape[-1])[ov_idxs]
        qi_vals = flat_q[ov_idxs]

        # flatten q_j over its last axis (K components)
        K = q_i.shape[-1]  # or simply config.K
        qj_flat = sanitize_q(agent_j.q.reshape(-1, K), eps=log_eps)
        qj_vals = qj_flat[ov_idxs]

        Ω = compute_inter_agent_omega(φi_vals, φj_vals, None, gens)
        qj_rot = batch_apply_omega(qj_vals, Ω)
        qj_rot = repair_if_forgotten_batch(qj_rot, eps=log_eps)
        qj_rot = sanitize_q(qj_rot, eps=log_eps)

        diff = qi_vals - qj_rot
        # dΩ/dφ applied to q_j
        dΩ = np.einsum('...ij,ajk->...iak', Ω, gens)
        dΩq = np.einsum('...iak,...k->...ia', dΩ, qj_vals)
        # inner product with diff
        flat_grad[ov_idxs] += (β / ov_idxs.size) * np.einsum('...ia,...i->...a', dΩq, diff)

    return flat_grad.reshape(*grad.shape)


def compute_phi_model_update(agent_i, agents: list, params: dict) -> np.ndarray:
    
    βm = params.get('model_align_weight', config.model_align_weight)
    overlap_eps = params.get('overlap_eps', config.overlap_eps)
    log_eps = params.get('log_eps', config.log_eps)

    φm_i = agent_i.phi_model
    mask_i = agent_i.mask > overlap_eps
    p_i = sanitize_q(agent_i.p, eps=log_eps)
    grad = np.zeros_like(φm_i)
    if βm <= 0 or not np.any(mask_i):
        return grad

    gens = get_generators(config.group_name, config.K)
    flat_φm = φm_i.reshape(-1, φm_i.shape[-1])
    flat_p = p_i.reshape(-1, p_i.shape[-1])
    flat_grad = grad.reshape(-1, grad.shape[-1])

    for nb in agent_i.neighbors:
        j = nb['id']
        agent_j = agents[j]
        overlap = mask_i & (agent_j.mask > overlap_eps)
        if not np.any(overlap):
            continue

        ov_idxs = np.flatnonzero(overlap)
        φi_vals = flat_φm[ov_idxs]
        φj_vals = agent_j.phi_model.reshape(-1, φi_vals.shape[-1])[ov_idxs]
        pi_vals = flat_p[ov_idxs]
        
        # flatten p_j over its last axis (K components)
        K = p_i.shape[-1]  # or simply config.K
        pj_flat = sanitize_q(agent_j.p.reshape(-1, K), eps=log_eps)
        pj_vals = pj_flat[ov_idxs]

        Ω = compute_inter_agent_omega(φi_vals, φj_vals, None, gens)
        pj_rot = batch_apply_omega(pj_vals, Ω)
        pj_rot = repair_if_forgotten_batch(pj_rot, eps=log_eps)
        pj_rot = sanitize_q(pj_rot, eps=log_eps)

        diff = pi_vals - pj_rot
        dΩ = np.einsum('...ij,ajk->...iak', Ω, gens)
        dΩp = np.einsum('...iak,...k->...ia', dΩ, pj_vals)
        flat_grad[ov_idxs] += -(βm / ov_idxs.size) * np.einsum('...ia,...i->...a', dΩp, diff)

    return flat_grad.reshape(*grad.shape)
