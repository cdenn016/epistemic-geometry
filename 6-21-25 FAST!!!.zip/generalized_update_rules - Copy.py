"""
Synchronous update orchestrator for q, p, phi, and phi_model.
Each step computes all gradients on a frozen state, then applies updates in parallel.
"""
import numpy as np
import config

from generalized_update_terms import (
    compute_beliefs_gradient,
    compute_models_gradient,
    compute_phi_alignment_gradient,
    compute_phi_model_update,
)
from generalized_math_utils import sanitize_q

def kl_divergence(q, p, eps=config.log_eps):
    """
    Compute the elementwise KL divergence D_KL(q||p) along the last axis.
    q, p: np.ndarray with shape (..., K)
    Returns: np.ndarray with shape (...,)
    """
    from generalized_math_utils import sanitize_q
    q_s = sanitize_q(q, eps=eps)
    p_s = sanitize_q(p, eps=eps)
    return np.sum(q_s * np.log(q_s / p_s), axis=-1)


def synchronous_step(agents, params=None):
    """
    Perform one synchronous Euler update:
      1) Compute all gradients against the old state
      2) Apply all updates at once
    """
    params = params or {}
    N = len(agents)

    # 1) Snapshot old fields
    q_old       = [agent.q.copy() for agent in agents]
    p_old       = [agent.p.copy() for agent in agents]
    phi_old     = [agent.phi.copy() for agent in agents]
    phi_m_old   = [agent.phi_model.copy() for agent in agents]
    mask_list   = [agent.mask for agent in agents]

    # 2) Compute gradients
    q_grads     = [compute_beliefs_gradient(agent, agents, params) for agent in agents]
    p_grads     = [compute_models_gradient(agent, agents, params)   for agent in agents]
    phi_grads   = [compute_phi_alignment_gradient(agent, agents, params) for agent in agents]
    phi_m_grads = [compute_phi_model_update(agent, agents, params)   for agent in agents]

    # 3) Load step sizes
    eta_q       = params.get('eta_q',       config.eta_q)
    eta_p       = params.get('eta_p',       config.eta_p)
    eta_phi     = params.get('eta_phi',     config.eta_phi)
    eta_model_phi = params.get('eta_model_phi', config.eta_model_phi)

    # 4) Apply updates synchronously
    for i, agent in enumerate(agents):
        mask = mask_list[i][..., None]

        # q update
        dq = -eta_q * q_grads[i]
        q_new = q_old[i] + dq
        q_new = np.where(mask, q_new, q_old[i])
        agent.q = sanitize_q(q_new, eps=config.log_eps)

        # p update
        dp = -eta_p * p_grads[i]
        p_new = p_old[i] + dp
        p_new = np.where(mask, p_new, p_old[i])
        agent.p = sanitize_q(p_new, eps=config.log_eps)

        # phi update
        dphi = eta_phi * phi_grads[i]
        phi_new = phi_old[i] + dphi * mask
        agent.phi = phi_new
        agent.delta_phi = dphi

        # phi_model update
        dphi_m = eta_model_phi * phi_m_grads[i]
        phi_m_new = phi_m_old[i] + dphi_m * mask
        agent.phi_model = phi_m_new
        agent.delta_phi_model = dphi_m

    return agents


# Optional: legacy wrappers routing to synchronous_step

def update_all(agents, params=None):
    """Alias for synchronous_step to maintain previous API."""
    return synchronous_step(agents, params)
