# Standard library
import os
import time

# Third-party
import numpy as np
from joblib import Parallel, delayed

# Local configuration & utilities

from config_utils import set_config_from_params
from get_generators import infer_lie_algebra_dim, get_generators

# I/O helpers
from generalized_io_utils import (
    save_step,
    load_checkpoint,
    find_resume_step,
    save_config_to_readme,
)

# Agent construction
from generalized_agents import (
    initialize_agents,
    generate_soft_mask,
    smooth_random_field,
    scale_to_range,
)
from generalized_agent_distributions import initialize_distribution
from generalized_agent_schema import Agent

# Update kernels
from generalized_update_rules import update_all

# Diagnostics

from generalized_diagnostics_metrics import (
    compute_kl_field,
    compute_alignment_field,
    compute_phi_norm_field,
    compute_entropy_field, log_all_metrics,
    compute_model_alignment_field, compute_free_energy, compute_coherence, collect_agent_metrics
)



import config

def run_simulation(
    outdir="checkpoints",
    resume=True,
    log_metrics=True,
    num_cores=None,
    params=None,
):
    # 1) Determine number of cores
    if num_cores is None:
        import multiprocessing
        num_cores = multiprocessing.cpu_count()

    # 2) Override config values if provided
    if params:
        set_config_from_params(params)


    os.makedirs(outdir, exist_ok=True)
    save_config_to_readme(outdir)

    # 3) Load checkpoint or initialize agents
    agents, _ = load_checkpoint(outdir) if resume else (None, None)
    step_start = find_resume_step(outdir) if resume else 0

    lie_algebra_dim = infer_lie_algebra_dim(config.group_name, config.K)


    if agents is None:
        print("[INIT] Initializing new agents…")
        agents = initialize_agents(
            seed=config.agent_seed,
            domain_size=config.domain_size,
            N=config.N,
            K=config.K,
            lie_algebra_dim=lie_algebra_dim,
            visualize=True,        # or True if you want the plots
            fixed_location=False,    # or False for random centers
            )
    
    # 4) Precompute Lie‑algebra generators
    generators = get_generators(config.group_name, config.K)

    metric_log = []
    print(f"[RUN] Starting simulation at step {step_start} with {num_cores} cores")

    for step in range(step_start, config.steps):
        print(f"\n[STEP {step}] -----------------------------")

                # --- Single synchronous Jacobi update ---
        t0 = time.perf_counter()
        agents = update_all(agents, params)   # alias for synchronous_step
        t1 = time.perf_counter()
        print(f"[TIMER] synchronous update: {t1-t0:.3f}s")

                # Save state
        save_step(agents, outdir, step)

        # Timer: logging metrics
        if log_metrics:
            t0 = time.perf_counter()
            # -- global metrics --
            m = log_all_metrics(
                agents,
                step,
                params=params,
                generators=generators,
                q_field="q",
                p_field="p",
                phi_belief_field="phi",
                phi_model_field="phi_model",
            )
            metric_log.append({"step": step, **m})
            t1 = time.perf_counter()
            print(f"[TIMER] log_all_metrics: {t1 - t0:.3f}s")

            # -- per-agent metrics via wrapper --
            for A in agents:
                collect_agent_metrics(A, agents, generators, step)

    # Finalize metric log
    if log_metrics:
        import pickle
        with open(os.path.join(outdir, "metric_log.pkl"), "wb") as f:
            pickle.dump(metric_log, f)
        print(f"[SAVE] Metrics log → {outdir}/metric_log.pkl")

        # …inside run_simulation, just before `return agents, metric_log`…

        # — EXPORT PER‐AGENT METRICS TO CSV —
        import pandas as pd
        rows = []
        for A in agents:
            for entry in A.metrics_log:
                row = {
                    "agent": A.id,
                    **entry
                }
                rows.append(row)
        df_agents = pd.DataFrame(rows)
        csv_path = os.path.join(outdir, "per_agent_metrics.csv")
        df_agents.to_csv(csv_path, index=False)
        print(f"[SAVE] Per‐agent metrics → {csv_path}")

    print("[DONE] Simulation completed.")
    return agents, metric_log


if __name__ == "__main__":
    import config
    from config_utils import set_config_from_params


    # Extract all user-defined config values as a params dict
    params = {
        k: getattr(config, k)
        for k in dir(config)
        if not k.startswith("__") and not callable(getattr(config, k))
    }

    # Optional: apply overrides right here
    set_config_from_params(params)

    agents, metrics = run_simulation(
        outdir="checkpoints",
        resume=False,
        log_metrics=True,
        num_cores=4,
        params=params
    )

