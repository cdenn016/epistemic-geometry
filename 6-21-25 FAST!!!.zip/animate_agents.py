# animate_agents_separate_fixedscales.py

import os
import sys
import pickle
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.backends.backend_agg import FigureCanvasAgg as FigureCanvas
import imageio

# Ensure local modules are importable
sys.path.insert(0, os.path.dirname(__file__))

import config
from get_generators import get_generators
from generalized_agent_schema import Agent
from generalized_diagnostics_metrics import compute_alignment_field, compute_field_strength


def compute_model_alignment_field(agents, i, generators, eps=config.support_cutoff_eps):
    """
    Wrapper to compute alignment using each agent's p & phi_model instead of q & phi.
    """
    A = agents[i]
    q_orig, phi_orig = A.q, A.phi
    A.q, A.phi = A.p, A.phi_model
    try:
        field = compute_alignment_field(agents, i, generators, eps)
    finally:
        A.q, A.phi = q_orig, phi_orig
    return field


def make_animations(
    steps,
    checkpoint_dir="checkpoints",
    output_folder="animations",
    dpi=150,
    fps=5
):
    """
    Create separate GIFs for each metric over the specified steps,
    with fixed color scales and agent outlines.
    Metrics: belief_phi_norm, model_phi_norm, overlap_count,
             belief_alignment, model_alignment, curvature
    """
    os.makedirs(output_folder, exist_ok=True)
    generators = get_generators(config.group_name, config.K)

    # Metrics to animate
    names = [
        "belief_phi_norm",
        "model_phi_norm",
        "overlap_count",
        "belief_alignment",
        "model_alignment",
        "curvature",
    ]
    cmaps = {
        "belief_phi_norm":"viridis",
        "model_phi_norm": "plasma",
        "overlap_count":"gray",
        "belief_alignment":"inferno",
        "model_alignment": "magma",
        "curvature":"cividis",
    }

    # Storage for maps and masks
    maps_data = {name: [] for name in names}
    masks_data = []  # list of lists of agent masks

    # Track global min/max
    vmins = {name: np.inf for name in names}
    vmaxs = {name:-np.inf for name in names}

    # First pass: compute maps and collect min/max
    for step in steps:
        # Load agents
        fname = f"step_{step:04d}.pkl"
        with open(os.path.join(checkpoint_dir, fname), "rb") as f:
            data = pickle.load(f)
        if isinstance(data, list): agents = data
        elif isinstance(data, tuple): agents = data[0] if isinstance(data[0], list) else list(data)
        elif isinstance(data, Agent): agents = [data]
        else: raise ValueError(f"Unknown data type: {type(data)}")

        X, Y = agents[0].mask.shape
        # initialize
        maps = {
            "belief_phi_norm": np.zeros((X,Y),float),
            "model_phi_norm":  np.zeros((X,Y),float),
            "overlap_count":   np.zeros((X,Y),int),
            "belief_alignment":np.zeros((X,Y),float),
            "model_alignment": np.zeros((X,Y),float),
            "curvature":       np.zeros((X,Y),float),
        }
        masks_data.append([ag.mask>config.support_cutoff_eps for ag in agents])

        # Accumulate per-agent
        for i, A in enumerate(agents):
            mask = masks_data[-1][i]
            if not mask.any(): continue
            maps["overlap_count"][mask] += 1
            maps["belief_phi_norm"][mask]     += np.linalg.norm(A.phi[mask], axis=-1)
            maps["model_phi_norm"][mask]      += np.linalg.norm(A.phi_model[mask], axis=-1)
            baf = compute_alignment_field(agents, i, generators)
            maps["belief_alignment"][mask]    += baf[mask]
            maf = compute_model_alignment_field(agents, i, generators)
            maps["model_alignment"][mask]     += maf[mask]
            Fdict = compute_field_strength(A.phi_model, generators)
            for F in Fdict.values(): maps["curvature"][mask] += np.abs(F[mask])

        # normalize and update vmin/vmax
        oc = maps["overlap_count"]>0
        for name in names:
            M = maps[name]
            if name!="overlap_count": M[oc] = M[oc] / maps["overlap_count"][oc]
            maps_data[name].append(M)
            vmins[name] = min(vmins[name], float(M.min()))
            vmaxs[name] = max(vmaxs[name], float(M.max()))

    # Second pass: render each metric with fixed scale
    for name in names:
        frames = []
        for idx, M in enumerate(maps_data[name]):
            fig, ax = plt.subplots(figsize=(6,6), dpi=dpi)
            im = ax.imshow(M, origin='lower', cmap=cmaps[name],
                           vmin=vmins[name], vmax=vmaxs[name])
            # overlay contours
            for mask in masks_data[idx]:
                ax.contour(mask, levels=[0.5], colors='white', linewidths=1)
            ax.set_title(f"{name.replace('_',' ').title()} (step {steps[idx]})")
            ax.axis('off')
            fig.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
            fig.tight_layout()
            canvas = FigureCanvas(fig)
            canvas.draw()
            img = np.frombuffer(canvas.tostring_rgb(), dtype='uint8')
            img = img.reshape(canvas.get_width_height()[::-1] + (3,))
            frames.append(img)
            plt.close(fig)
        # save gif
        out = os.path.join(output_folder, f"{name}.gif")
        imageio.mimsave(out, frames, fps=fps)
        print(f"Saved {out}")


if __name__=="__main__":
    make_animations(range(50))
