# -*- coding: utf-8 -*-
"""
Created on Thu Jul 24 17:48:40 2025

@author: chris and christine
"""

import numpy as np
from numerical_utils import safe_inv

def convert_mu_sigma_grads_to_eta_grads(mu, sigma, grad_mu, grad_sigma, eps=1e-8):
    """
    Convert gradients ∂KL/∂μ and ∂KL/∂Σ to ∂KL/∂η₁ and ∂KL/∂η₂.

    Args:
        mu         : (..., K)
        sigma      : (..., K, K)
        grad_mu    : (..., K)
        grad_sigma : (..., K, K)
        eps        : regularization constant for inversion

    Returns:
        grad_eta1  : (..., K)
        grad_eta2  : (..., K, K)
    """
    sigma_inv = safe_inv(sigma, eps=eps)

    # ∂KL / ∂η₁ = Σ ∂KL / ∂μ
    grad_eta1 = np.einsum("...ij,...j->...i", sigma, grad_mu)

    # Outer product μ μᵀ
    mu_outer = np.einsum("...i,...j->...ij", mu, mu)

    # ∂KL / ∂η₂ = −½ Σ ( ∂KL / ∂Σ + ∂KL/∂μ ⊗ μ ) Σ
    grad_eta2 = np.einsum("...ik,...kl,...lj->...ij", sigma, grad_sigma + mu_outer, sigma)
    grad_eta2 *= -0.5

    return grad_eta1, grad_eta2




def mu_sigma_to_natural(mu, sigma, eps=1e-8):
    sigma_inv = safe_inv(sigma, eps)
    eta1 = np.einsum('...ij,...j->...i', sigma_inv, mu)
    eta2 = -0.5 * sigma_inv
    return eta1, eta2

def natural_to_mu_sigma(eta1, eta2, eps=1e-8):
    sigma_inv = -2.0 * eta2
    sigma = safe_inv(sigma_inv, eps)
    mu = np.einsum('...ij,...j->...i', sigma, eta1)
    return mu, sigma

import numpy as np
from numerical_utils import safe_inv, sanitize_sigma

def compute_mu_sigma_from_natural(eta1: np.ndarray, eta2: np.ndarray, eps: float = 1e-8):
    """
    Convert natural parameters (η₁, η₂) to mean (μ) and covariance (Σ) for multivariate Gaussian.

    η₁ = Σ⁻¹ μ
    η₂ = -0.5 Σ⁻¹

    Args:
        eta1 : (..., K)
        eta2 : (..., K, K)
        eps  : regularization parameter to ensure SPD safety

    Returns:
        mu    : (..., K)
        sigma : (..., K, K)
    """
    # Invert η₂ to recover Σ
    sigma_inv = -2.0 * eta2
    sigma = safe_inv(sanitize_sigma(sigma_inv, eps=eps), eps=eps)

    # Recover μ = Σ η₁
    mu = np.einsum("...ij,...j->...i", sigma, eta1)

    return mu, sigma

def natural_to_mu_sigma(eta1, eta2, eps=1e-8):
    """
    Convert natural parameters η₁, η₂ to (μ, Σ) for multivariate Gaussian.

    η₁ = Σ⁻¹ μ
    η₂ = −½ Σ⁻¹  ⇒  Σ = −½ η₂⁻¹

    Returns:
        μ    : (..., K)
        Σ    : (..., K, K)
    """
    from numerical_utils import safe_inv

    eta2 = np.where(np.abs(eta2) < eps, eps, eta2)  # stabilize
    Sigma = -0.5 * safe_inv(eta2, eps=eps)
    mu = np.einsum("...ij,...j->...i", Sigma, eta1)
    return mu, Sigma

import numpy as np
from numerical_utils import safe_inv, sanitize_sigma

def natural_to_mu_sigma_batch(eta1, eta2, eps=1e-8):
    """
    Convert natural parameters (η₁, η₂) to (μ, Σ) in batch.

    η₁ = Σ⁻¹ μ
    η₂ = −½ Σ⁻¹

    Args:
        eta1 : (..., K)
        eta2 : (..., K, K) — symmetric
        eps  : float, SPD regularization

    Returns:
        mu    : (..., K)
        sigma : (..., K, K)
    """
    # Invert: η₂ = −½ Σ⁻¹  ⇒  Σ = (−½ η₂)⁻¹
    sigma_inv = -2.0 * eta2
    sigma = safe_inv(sigma_inv, eps=eps)

    # μ = Σ η₁
    mu = np.einsum("...ij,...j->...i", sigma, eta1)
    return mu, sigma
