# -*- coding: utf-8 -*-
"""
Created on Wed Jul 23 09:20:49 2025

@author: chris and christine
"""

import numpy as np
import config
import numpy as np
import config
import numpy as np
from scipy.linalg import inv
from numerical_utils import safe_inv, sanitize_sigma
from generalized_omega import exp_lie_algebra_irrep, compute_curvature_gradient_analytical
from natural_gradient import dexpinv_operator, dexpinv_operator_covariance, compute_fisher_geometry_gradient
import config
from update_terms_phi_belief import clip_gradient_norm
# in update_terms_phi_utils.py or update_terms_phi_belief.py
def apply_regularization_terms(
    phi, phi_tilde, generators,
    curv_weight, mass_weight, coupling_weight,
    agent_i=None, agents=None, fisher_weight=0.0, params=None
):
    """
    Returns: total regularization gradient (same shape as phi)
    """
    grad = 0.0

    if curv_weight > 0:
        
        grad += curv_weight * compute_curvature_gradient_analytical(phi, generators)

    if mass_weight > 0:
        grad += 2 * mass_weight * phi

    if coupling_weight > 0:
        grad += 2 * coupling_weight * (phi - phi_tilde)

    if fisher_weight > 0 and agent_i is not None and agents is not None:
        
        grad += fisher_weight * compute_fisher_geometry_gradient(agent_i, agents, params)

    return grad


#==============================================================================
#
#                    APPLY NATURAL GRADIENT
#                    
#==============================================================================

def accumulate_phi_gradient_model(agent_i, agent_j, generators, params):
    """
    Compute and apply natural gradient update for model fiber alignment:
        ∇_{φ̃_i} KL(p_i || Ω̃_ij p_j)
        ∇_{φ̃_j} KL(p_i || Ω̃_ij p_j)
    """

    # Step 1: Compute Euclidean gradients
    grad_phi_i_raw, grad_phi_j_raw, joint_mask = \
        accumulate_phi_gradient_model_euclidean(agent_i, agent_j, generators, params)

    if grad_phi_i_raw is None or grad_phi_j_raw is None:
        return  # Skip if gradients not defined

    phi_i = agent_i.phi_model
    phi_j = agent_j.phi_model

    # Step 2: Project Euclidean → natural gradient
    grad_phi_i = dexpinv_operator(phi_i, grad_phi_i_raw, generators)
    grad_phi_j = dexpinv_operator(phi_j, grad_phi_j_raw, generators)

    # Step 3: Regularization terms (curvature, mass, coupling, Fisher)
    curv_w    = params.get("model_curvature_weight", config.curvature_weight)
    mass_w    = params.get("model_mass", config.model_mass)
    coupling  = params.get("phi_phi_tilde_coupling", config.phi_phi_tilde_coupling)
    fisher_w  = params.get("fisher_model_geometry_weight", config.fisher_model_geometry_weight)

    reg_grad_i = apply_regularization_terms(
        phi=phi_i,
        phi_tilde=agent_i.phi,  # coupling φ̃ to φ
        generators=generators,
        curv_weight=curv_w,
        mass_weight=mass_w,
        coupling_weight=coupling,
        agent_i=agent_i,
        agents=params.get("agents", None),
        fisher_weight=fisher_w,
        params=params
    )

    if getattr(config, "debug_gradients", False):
        print(f"[Grad phi~_i]     norm: {np.linalg.norm(grad_phi_i):.2e}")
        print(f"[Grad phi~_j]     norm: {np.linalg.norm(grad_phi_j):.2e}")
        print(f"[Reg phi~_i]  norm: {np.linalg.norm(reg_grad_i):.2e}")

    # Step 5: Accumulate all updates
    beta_model = params.get("beta_model", config.beta_model)

    agent_i.grad_phi_tilde += (beta_model * grad_phi_i + reg_grad_i) * joint_mask
    agent_j.grad_phi_tilde += beta_model * grad_phi_j * joint_mask



#==============================================================================
#
#                    GATHER PHI~ GAUGE FIELD GRADIENT TERMS
#                        
#==============================================================================


def accumulate_phi_gradient_model_euclidean(agent_k, agent_j, generators, params, field="phi_model"):
    """
    Compute Euclidean gradient of KL(p_k || Ω̃_kj p_j) w.r.t. φ̃_k and φ̃_j (no dexpinv).
    Returns:
        grad_phi_k_raw: (..., d)
        grad_phi_j_raw: (..., d)
        joint_mask: (..., 1) boolean
    """
    assert field == "phi_model", f"Expected field='phi_model', got {field}"
    assert generators.ndim == 3, f"Expected generators shape (d, K, K), got {generators.shape}"
    d, K1, K2 = generators.shape
    assert K1 == K2, f"Generators must be square: got {K1}×{K2}"

    beta_tilde = params.get("beta_model", config.beta_model)
    if beta_tilde <= 0:
        return None, None, None

    eps = config.support_cutoff_eps
    mask_k = agent_k.mask[..., None] > eps
    mask_j = agent_j.mask[..., None] > eps
    joint_mask = mask_k & mask_j

    mu_k, sigma_k = agent_k.mu_p_field, agent_k.sigma_p_field
    mu_j, sigma_j = agent_j.mu_p_field, agent_j.sigma_p_field

    # Use cached φ̃ exponentials
    exp_phi_k     = agent_k._exp_phi_model          # ≈ exp(φ̃_k)
    exp_phi_j     = agent_j._exp_phi_model          # ≈ exp(φ̃_j)
    exp_neg_phi_j = agent_j._exp_neg_phi_model      # ≈ exp(−φ̃_j)

    # Compute Ω̃_kj = exp(φ̃_k) · exp(−φ̃_j)
    Omega_tilde_kj = np.einsum("...ik,...kj->...ij", exp_phi_k, exp_neg_phi_j)

    # Compute raw Euclidean gradients
    grad_phi_k_raw = grad_kl_wrt_phi_i(
        mu_k, sigma_k, mu_j, sigma_j, Omega_tilde_kj, generators, eps=config.eps
    )
    grad_phi_j_raw = grad_kl_wrt_phi_j(
        mu_k, sigma_k, mu_j, sigma_j, Omega_tilde_kj,
        generators, exp_phi_j, exp_neg_phi_j, eps=config.eps
    )

    return grad_phi_k_raw, grad_phi_j_raw, joint_mask


#==============================================================================
#
#                    WITH RESPECT TO phi_i TERMS
#
#==============================================================================



def grad_kl_wrt_phi_i(mu_i, sigma_i, mu_j, sigma_j, Omega_ij, generators, eps=1e-8):
    """
    Compute ∂KL(q_i || Ω q_j) / ∂φ_i^a for all Lie algebra directions a.

    Args:
        mu_i       : (H, W, K)
        sigma_i    : (H, W, K, K)
        mu_j       : (H, W, K)
        sigma_j    : (H, W, K, K)
        Omega_ij   : (H, W, K, K)
        generators : (d, K, K)
        eps        : regularization for inverses

    Returns:
        grad_phi_i : (H, W, d)
    """
    d, K, _ = generators.shape
    H, W, _ = mu_i.shape

    grad_phi_i = np.zeros((H, W, d), dtype=mu_i.dtype)

    # Precompute log-det gradient for all directions
    t3_all = term_logdet_grad_phi_i(sigma_j, Omega_ij, generators, eps=eps)  # (H, W, d)

    for a in range(d):
        G_a = generators[a]

        t1 = term_trace_grad_phi_i(mu_i, sigma_i, mu_j, sigma_j, Omega_ij, G_a, eps)

        t2 = term_mahalanobis_grad_phi_i(mu_i, sigma_i, mu_j, sigma_j, Omega_ij, G_a, eps)  # (H, W)
        t3 = t3_all[..., a]  # Correctly extract a single slice (H, W)

        grad_phi_i[..., a] = t1 + t2 + t3  # (H, W)

    return grad_phi_i  # shape (H, W, d)

#validated
def term_trace_grad_phi_i(mu_i, sigma_i, mu_j, sigma_j, Omega_ij, G_a, eps=1e-8):
    """
    Compute the full trace gradient term for ∂/∂φ_i^a KL(q_i || Ω_ij q_j)
    Term: -Tr[ G_a Σ_i Σ_ij⁻¹ + G_aᵗ Σ_ij⁻¹ Σ_i ]
    """
    H, W, K = mu_i.shape
    Omega_T = np.swapaxes(Omega_ij, -1, -2)

    sigma_ij = np.einsum("...ik,...kl,...jl->...ij", Omega_ij, sigma_j, Omega_T)
    sigma_ij = sanitize_sigma(sigma_ij, eps)
    sigma_ij_inv = safe_inv(sigma_ij, eps)

    # First trace: Tr[G Σ_i Σ_ij⁻¹]
    temp1 = np.einsum("...ik,...kl->...il", sigma_i, sigma_ij_inv)
    trace1 = np.einsum("...ij,...ji->...", G_a, temp1)

    # Second trace: Tr[Gᵗ Σ_ij⁻¹ Σ_i]
    temp2 = np.einsum("...ik,...kl->...il", sigma_ij_inv, sigma_i)
    trace2 = np.einsum("...ij,...ji->...", G_a.transpose(), temp2)

    return -(trace1 + trace2)



   


from get_generators import get_generators  # import at top if not already
#validated
def term_mahalanobis_grad_phi_i(mu_i, sigma_i, mu_j, sigma_j, Omega_ij, G_a, eps=1e-8):
    """
    Compute ∂/∂φ_i^a of the Mahalanobis term in KL(q_i || Ω_ij q_j):
        (μ_i - Ω_ij μ_j)^T Σ_ij^{-1} (μ_i - Ω_ij μ_j)
    where:
        Σ_ij = Ω_ij Σ_j Ω_ij^T
    and Ω_ij = exp(φ_i) @ exp(-φ_j)

    Returns:
        result : shape (H, W)
    """
    H, W, K = mu_i.shape

    Omega_T = Omega_ij.transpose(0, 1, 3, 2)
    mu_j_bar = np.einsum("...ij,...j->...i", Omega_ij, mu_j)
    delta_mu = mu_i - mu_j_bar

    sigma_ij = np.einsum("...ik,...kl,...jl->...ij", Omega_ij, sigma_j, Omega_T)
    sigma_ij = sanitize_sigma(sigma_ij, eps)
    sigma_ij_inv = safe_inv(sigma_ij, eps)

    # --- Term 1 ---
    tmp = np.einsum("...k,kl->...l", mu_j, G_a)
    mu_j_GO = np.einsum("...k,...kj->...j", tmp, Omega_ij)
    term1 = -np.einsum("...i,...ij,...j->...", delta_mu, sigma_ij_inv, mu_j_GO)

    # --- Corrected Term 2 ---
    # mu_j^T @ Omega_ij^T
    mu_j_O_T = np.einsum("...j,...ij->...i", mu_j, Omega_T)

    # (mu_j^T @ Omega_ij^T) @ G_a^T
    mu_j_O_T_G_T = np.einsum("...i,ij->...j", mu_j_O_T, G_a.T)

    # Full contraction: (μ_jᵀ Ωᵀ Gᵀ Σ⁻¹) · Δμ
    mu_j_O_T_G_T_Sinv = np.einsum("...j,...jk->...k", mu_j_O_T_G_T, sigma_ij_inv)
    term2 = -np.einsum("...k,...k->...", mu_j_O_T_G_T_Sinv, delta_mu)

    # --- Term 3 ---
    sym_term = (
        np.einsum("...ij,jk->...ik", sigma_ij_inv, G_a) +
        np.einsum("jk,...ij->...ik", G_a.T, sigma_ij_inv)
    )
    term3 = -np.einsum("...i,...ij,...j->...", delta_mu, sym_term, delta_mu)

    return term1 + term2 + term3



#validated
def term_logdet_grad_phi_i(sigma_j, Omega_ij, generators, eps=1e-8):
    """
    Compute ∂/∂φ_i^a log det(Ω Σ_j Ω^T) = Tr[ Σ_proj⁻¹ G_a Σ_proj + G_aᵗ ]
    using the identity Σ⁻¹Σ = I to simplify the computation.

    Returns:
        grads : (H, W, d) array of gradients for each generator direction.
    """
    H, W, K, _ = Omega_ij.shape
    d = generators.shape[0]

    Omega_T = np.transpose(Omega_ij, (0, 1, 3, 2))
    sigma_proj = Omega_ij @ sigma_j @ Omega_T
    sigma_proj = sanitize_sigma(sigma_proj, eps)
    sigma_proj_inv = safe_inv(sigma_proj, eps)

    grads = []

    for a in range(d):
        G = generators[a]  # (K, K)

        # Tr[ Σ⁻¹ G Σ ]
        G_sigma = np.einsum("ij,...jk->...ik", G, sigma_proj)
        sigma_inv_G_sigma = np.einsum("...ij,...jk->...ik", sigma_proj_inv, G_sigma)
        trace1 = np.einsum("...ii->...", sigma_inv_G_sigma)

        # Tr[ Gᵗ ]
        trace2 = np.trace(G.T)  # scalar

        grads.append(trace1 + trace2)

    return np.stack(grads, axis=-1)





#==============================================================================
#
#                    WITH RESPECT TO phi_j TERMS
#
#==============================================================================



def grad_kl_wrt_phi_j(mu_i, sigma_i,
                      mu_j, sigma_j,
                      Omega_ij,
                      generators,             # shape (d, K, K)
                      exp_phi_j, exp_neg_phi_j,
                      eps=1e-8):
    """
    Compute ∇_{φ_j} KL(q_i || Ω_ij q_j) as a vector over generators G_a.

    Args:
        mu_i, sigma_i      : belief i fields, shape (H, W, K), (H, W, K, K)
        mu_j, sigma_j      : belief j fields, shape (H, W, K), (H, W, K, K)
        Omega_ij           : Ω_ij = exp(φ_i) exp(−φ_j), shape (H, W, K, K)
        generators         : Lie algebra generators G_a, shape (d, K, K)
        exp_phi_j          : exp(φ_j), shape (H, W, K, K)
        exp_neg_phi_j      : exp(−φ_j), shape (H, W, K, K)
        eps                : regularization constant

    Returns:
        grad_phi_j         : gradient w.r.t. φ_j, shape (H, W, d)
    """
    d, K, _ = generators.shape
    H, W, K_ = mu_i.shape
    assert K == K_, f"Mismatch in K dimensions: {K} vs {K_}"

    grad = np.zeros((H, W, d), dtype=mu_i.dtype)

    for a in range(d):
        G_a = generators[a]
        assert G_a.shape == (K, K), f"G_a has wrong shape: {G_a.shape}"

        # Transport the generator: G_a^R = exp(φ_j) · G_a · exp(−φ_j)
        G_a_batched = np.broadcast_to(G_a[None, None], (H, W, K, K))
        G_a_R = np.einsum("...ik,...kl,...lj->...ij", exp_phi_j, G_a_batched, exp_neg_phi_j)

        first = term_trace_grad_phi_j(
            mu_i, sigma_i, mu_j, sigma_j,
            Omega_ij, G_a,
            exp_phi_j, exp_neg_phi_j, eps  # (H, W)
        )
        second = term_logdet_grad_phi_j(
            mu_i, sigma_i, mu_j, sigma_j,
            Omega_ij, G_a,
            exp_phi_j, exp_neg_phi_j, eps  # (H, W)
        )
        third = term_mahalanobis_grad_phi_j(
            mu_i, sigma_i, mu_j, sigma_j,
            Omega_ij, G_a_R,  # ✅ passed as transported generator
            exp_phi_j, exp_neg_phi_j, eps  # (H, W)
        )

        grad[..., a] = 0.5 * (first + second + third)

    return grad  # shape (H, W, d)


#validated
def term_trace_grad_phi_j(mu_i, sigma_i, mu_j, sigma_j,
                          Omega_ij, G_a,
                          exp_phi_j, exp_neg_phi_j,
                          eps=1e-8):
    """
    Compute ∂/∂φ_j^a Tr[(Ω Σ_j Ωᵀ)^−1 (Ω G_R Σ_j Ωᵀ + Ω Σ_j G_Rᵀ Ωᵀ) Σ_i]
    for a single generator G_a, where:
        G_R = exp(φ_j) @ G_a @ exp(−φ_j)

    Args:
        G_a           : (K, K)
        exp_phi_j     : (H, W, K, K)
        exp_neg_phi_j : (H, W, K, K)

    Returns:
        gradient      : (H, W)
    """
    H, W, K, _ = sigma_i.shape

    G_a = np.broadcast_to(G_a, exp_phi_j.shape)
    G_R = np.einsum("...ij,...jk,...kl->...il", exp_phi_j, G_a, exp_neg_phi_j)

    G_R_T = np.transpose(G_R, (0, 1, 3, 2))
    Omega_T = np.transpose(Omega_ij, (0, 1, 3, 2))

    sigma_ij = Omega_ij @ sigma_j @ Omega_T
    sigma_ij = sanitize_sigma(sigma_ij, eps)
    sigma_ij_inv = safe_inv(sigma_ij, eps=eps)

    # --- A term ---
    A = np.einsum("...ij,...jk,...kl->...il", Omega_ij, G_R, sigma_j)
    A = np.einsum("...ij,...jk->...ik", A, Omega_T)

    # --- B term ---
    B = np.einsum("...ij,...jk->...ik", sigma_j, G_R_T)
    B = np.einsum("...ij,...jk,...kl->...il", Omega_ij, B, Omega_T)

    term1 = np.einsum("...ij,...jk,...kl,...li->...", sigma_ij_inv, A, sigma_ij_inv, sigma_i)
    term2 = np.einsum("...ij,...jk,...kl,...li->...", sigma_ij_inv, B, sigma_ij_inv, sigma_i)

    return term1 + term2  # shape (H, W)


#validated
def term_logdet_grad_phi_j(mu_i, sigma_i, mu_j, sigma_j,
                           Omega_ij, G_a,
                           exp_phi_j, exp_neg_phi_j,
                           eps=1e-8):
    """
    Log-det gradient ∂/∂φ_j^a KL(q_i || Ω_ij q_j) for a single generator G_a:
        − Tr[ (Ω Σ_j Ωᵀ)^−1 (Ω G_R Σ_j Ωᵀ + Ω Σ_j G_Rᵀ Ωᵀ) ]
    where G_R = exp(φ_j) G_a exp(−φ_j)

    Args:
        G_a            : shape (K, K)
        exp_phi_j      : shape (H, W, K, K)
        exp_neg_phi_j  : shape (H, W, K, K)
        Omega_ij       : shape (H, W, K, K)

    Returns:
        gradient       : shape (H, W)
    """
    H, W, K, _ = sigma_j.shape

    # Correct contraction for G_R = exp(φ_j) G_a exp(-φ_j)
    tmp = np.einsum("...ij,jk->...ik", exp_phi_j, G_a)             # (H, W, K, K)
    G_R = np.einsum("...ij,...jk->...ik", tmp, exp_neg_phi_j)     # (H, W, K, K)
    G_R_T = np.transpose(G_R, (0, 1, 3, 2))                        # (H, W, K, K)

    Omega_T = np.transpose(Omega_ij, (0, 1, 3, 2))
    sigma_ij = Omega_ij @ sigma_j @ Omega_T
    sigma_ij = sanitize_sigma(sigma_ij, eps)
    sigma_ij_inv = safe_inv(sigma_ij, eps=eps)

    A = Omega_ij @ G_R @ sigma_j @ Omega_T
    B = Omega_ij @ sigma_j @ G_R_T @ Omega_T

    term1 = np.einsum("...ij,...ji->...", sigma_ij_inv, A)
    term2 = np.einsum("...ij,...ji->...", sigma_ij_inv, B)

    return -(term1 + term2)  # shape (H, W)



def term_mahalanobis_grad_phi_j(
    mu_i, sigma_i, mu_j, sigma_j,
    Omega_ij, G_a_R,
    exp_phi_j, exp_neg_phi_j,
    eps=1e-8
):
    """
    Compute ∂/∂φ_j^a (Δμᵗ Σ⁻¹ Δμ) using analytic gradient formula.
    Each term is scalar per grid point.

    Args:
        mu_i        : Agent i mean (H, W, K)
        sigma_i     : Agent i covariance (unused here)
        mu_j        : Agent j mean (H, W, K)
        sigma_j     : Agent j covariance (H, W, K, K)
        Omega_ij    : Transport operator from j to i (H, W, K, K)
        G_a_R       : Transported generator: Gᵃʳ = exp(φ_j) G_a exp(−φ_j) (H, W, K, K)
        exp_phi_j   : Not used here (included for API parity)
        exp_neg_phi_j : Not used here (included for API parity)
        eps         : Numerical stability for inverse/sanitize

    Returns:
        term        : Scalar field (H, W)
    """
    H, W, K = mu_i.shape

    Omega_T = np.transpose(Omega_ij, (0, 1, 3, 2))  # (H, W, K, K)

    # Transported μ_j
    mu_j_bar = np.einsum("...ij,...j->...i", Omega_ij, mu_j)  # (H, W, K)
    delta_mu = mu_i - mu_j_bar  # (H, W, K)

    # Transported covariance: Σ_{ij} = Ω Σ_j Ωᵀ
    Sigma_ij = np.einsum("...ik,...kl,...jl->...ij", Omega_ij, sigma_j, Omega_T)  # (H, W, K, K)
    Sigma_ij = sanitize_sigma(Sigma_ij, eps=eps)
    Sigma_ij_inv = safe_inv(Sigma_ij, eps=eps)  # (H, W, K, K)

    # --- Term 1: -Δμᵗ Σ⁻¹ μ_j Ω G ---
    mu_j_G = np.einsum("...ij,...j->...i", G_a_R, mu_j)
    mu_j_G_O = np.einsum("...ij,...j->...i", Omega_ij, mu_j_G)

    tmp1 = np.einsum("...i,...ij,...j->...", delta_mu, Sigma_ij_inv, mu_j_G_O)  # (H, W)
    term1 = -tmp1

    # --- Term 2: -μ_jᵗ Gᵀ Ωᵗ Σ⁻¹ Δμ ---
    G_R_T = np.transpose(G_a_R, (0, 1, 3, 2))                     # (H, W, K, K)
    tmp2a = np.einsum("...ij,...jk->...ik", G_R_T, Omega_T)       # (H, W, K, K)
    tmp2b = np.einsum("...ij,...jk->...ik", tmp2a, Sigma_ij_inv)  # (H, W, K, K)
    mu_j_G_RO_inv = np.einsum("...i,...ij->...j", mu_j, tmp2b)    # (H, W, K)
    term2 = -np.einsum("...i,...i->...", mu_j_G_RO_inv, delta_mu) # (H, W)

    # --- Term 3: -Δμᵗ Σ⁻¹ (Ω G Σ Ωᵗ + Ω Σ Gᵀ Ωᵗ) Σ⁻¹ Δμ ---
    # A = Ω G Σ Ωᵀ
    A = np.einsum("...ik,...kl,...lj->...ij", Omega_ij, G_a_R, sigma_j)  # (H, W, K, K)
    A = np.einsum("...ij,...jk->...ik", A, Omega_T)

    # B = Ω Σ Gᵀ Ωᵀ
    B = np.einsum("...ik,...kl,...lj->...ij", Omega_ij, sigma_j, G_R_T)  # (H, W, K, K)
    B = np.einsum("...ij,...jk->...ik", B, Omega_T)

    M = A + B  # (H, W, K, K)

    # Full sandwich: Δμᵗ Σ⁻¹ M Σ⁻¹ Δμ
    tmp3a = np.einsum("...i,...ij->...j", delta_mu, Sigma_ij_inv)       # (H, W, K)
    tmp3b = np.einsum("...i,...ij->...j", tmp3a, M)                     # (H, W, K)
    tmp3c = np.einsum("...i,...ij->...j", tmp3b, Sigma_ij_inv)          # (H, W, K)
    term3 = -np.einsum("...i,...i->...", tmp3c, delta_mu)
             # (H, W)

    return term1 + term2 + term3  # (H, W)
