import numpy as np
from scipy.linalg import expm



class GeneratorSet(dict):
    def __init__(self, E, F, H, block_dims, labels):
        super().__init__(E=E, F=F, H=H)
        self.blocks = []
        self.labels = labels

        start = 0
        for dim, label in zip(block_dims, labels):
            end = start + dim
            self.blocks.append((start, end))
            start = end

class RhoFunction:
    def __init__(self, generators: np.ndarray):
        assert generators.shape[0] == 3, "Expecting 3 generators [E, F, H]"
        self.generators = generators  # ← Add this line
        self.E = generators[0]
        self.F = generators[1]
        self.H = generators[2]

    def __call__(self, phi_vec: np.ndarray) -> np.ndarray:
        return expm(phi_vec[0] * self.E +
                    phi_vec[1] * self.F +
                    phi_vec[2] * self.H)

from scipy.linalg import expm
import numpy as np

class RhoFunction_batch:
    def __init__(self, generators: np.ndarray):
        assert generators.shape[0] == 3, "Expecting 3 generators [E, F, H]"
        self.generators = generators
        self.E = generators[0]
        self.F = generators[1]
        self.H = generators[2]

    def __call__(self, phi_vec: np.ndarray) -> np.ndarray:
        if phi_vec.ndim == 1:
            # Single input (3,)
            return expm(phi_vec[0] * self.E +
                        phi_vec[1] * self.F +
                        phi_vec[2] * self.H)

        elif phi_vec.ndim == 2:
            # Batched input (N, 3)
            N = phi_vec.shape[0]
            K = self.E.shape[0]
            out = np.zeros((N, K, K), dtype=np.float64)
            for n in range(N):
                phi = phi_vec[n]
                out[n] = expm(phi[0] * self.E +
                              phi[1] * self.F +
                              phi[2] * self.H)
            return out

        else:
            raise ValueError(f"[RhoFunction] Unsupported input shape: {phi_vec.shape}")

#=======================================================
#
#           Generators
#
#=========================================================

def get_rectangular_generators(K_out, K_in):
    """
    Returns a set of generators (d = K_out × K_in) for linear maps ℝ^{K_in} → ℝ^{K_out}
    """
    d = K_out * K_in
    generators = np.zeros((d, K_out, K_in))
    for a in range(d):
        i = a // K_in
        j = a % K_in
        generators[a, i, j] = 1.0
    return generators


def sl2r_irrep(K: int) -> dict:
    """
    Return the real irreducible SL(2,R) generators E, F, H for dimension K = 2ℓ + 1.
    """
    if K % 2 == 0:
        raise ValueError("K must be odd for SL(2,R) irreps (K = 2ℓ + 1).")
    ℓ = (K - 1) // 2
    E = np.zeros((K, K), dtype=float)
    F = np.zeros((K, K), dtype=float)
    H = np.zeros((K, K), dtype=float)

    for m in range(-ℓ, ℓ + 1):
        i = m + ℓ
        H[i, i] = m
        if i < K - 1:
            a = np.sqrt((ℓ - m) * (ℓ + m + 1))
            E[i, i + 1] = a
            E[i + 1, i] = a
            F[i, i + 1] = -a
            F[i + 1, i] = a
    return {"E": E, "F": F, "H": H}


_generator_cache = {}  # Already declared

def get_generators(group_name, K, return_meta=False):
    if group_name.lower() != "sl2r":
        raise ValueError(f"Unsupported group: {group_name}")

    # ─── Cache Key ─────────────────────
    if isinstance(K, int):
        key = (group_name, K)
    elif isinstance(K, list):
        key = (group_name, tuple(K))  # Convert list to tuple for hashing
    else:
        raise TypeError(f"[get_generators] Invalid type for K: {type(K)}")

    # ─── Cache Lookup ─────────────────
    if key in _generator_cache:
        G, meta = _generator_cache[key]
    else:
        # ─── Compute Generators ────────
        if isinstance(K, int):
            G_dict = sl2r_irrep(K)

            # Sanity check
            for name in ["E", "F", "H"]:
                Gmat = G_dict[name]
                assert Gmat.ndim == 2 and Gmat.shape[0] == Gmat.shape[1], \
                    f"[get_generators] Generator {name} must be square, got shape {Gmat.shape}"

            G = np.stack([G_dict["E"], G_dict["F"], G_dict["H"]], axis=0)  # (3, K, K)
            meta = {"blocks": [K]}
        else:
            G, meta = _get_reducible_sl2r(K)

        # Final safety check
        assert G.ndim == 3 and G.shape[1] == G.shape[2], \
            f"[get_generators] Final generator stack must be (d, K, K), got {G.shape}"

        _generator_cache[key] = (G, meta)

    return (G, meta) if return_meta else G





#==========================================
#
#    Build Reducible Representations
#
#==========================================


def block_diag_generators(blocks: list[dict[str, np.ndarray]]) -> dict[str, np.ndarray]:
    """
    Combine a list of irreducible generator sets {E,F,H} into a block-diagonal reducible set.

    Args:
        blocks: list of dicts, each with {"E", "F", "H"} generators of shape (Ki, Ki)

    Returns:
        dict with:
            "E" : (K_total, K_total) ndarray
            "F" : (K_total, K_total) ndarray
            "H" : (K_total, K_total) ndarray
    """
    def block_diag(gen_list):
        sizes = [g.shape[0] for g in gen_list]
        total = sum(sizes)
        out = np.zeros((total, total), dtype=np.float64)
        offset = 0
        for g in gen_list:
            k = g.shape[0]
            out[offset:offset+k, offset:offset+k] = g
            offset += k
        return out

    return {
        "E": block_diag([b["E"] for b in blocks]),
        "F": block_diag([b["F"] for b in blocks]),
        "H": block_diag([b["H"] for b in blocks])
    }



def _get_reducible_sl2r(K_list):
    """
    Construct reducible SL(2,R) representation from list of irreducible blocks.

    Args:
        K_list : list[int] — sizes of each irreducible block

    Returns:
        G      : ndarray (3, K_total, K_total) — stacked [E, F, H]
        meta   : dict {"blocks": K_list}
    """
    irreps = [sl2r_irrep(K) for K in K_list]  # each returns {"E", "F", "H"}
    G_dict = block_diag_generators(irreps)    # builds block-diagonal E/F/H
    G = np.stack([G_dict["E"], G_dict["F"], G_dict["H"]], axis=0)
    return G, {"blocks": K_list}
