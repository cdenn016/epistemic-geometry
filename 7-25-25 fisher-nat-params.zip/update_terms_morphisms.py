# -*- coding: utf-8 -*-
"""
Created on Wed Jul 23 06:38:37 2025

@author: chris and christine
"""
import numpy as np
from natural_gradient import dexpinv_operator_morphism  # you will need to implement this
from numerical_utils import safe_inv
from get_generators import get_generators
import config   
#==============================================================================
#
#                    Apply Natural Gradient to Bundle Morphism
#
#==============================================================================
from natural_gradient import compute_fisher_metric_rectangular_natural 

def accumulate_morphism_feedback_gradient_natural(
    agent_i,
    feedback_weight,
    G_inv_field,
    generators,
    mask=None,
    eps=1e-8,
):
    """
    Accumulate natural gradient ∇_Φ KL(p || Φ·q) into agent_i.grad_Phi
    Uses precomputed inverse Fisher metric field G_inv_field, passed externally.
    """
    # Step 1: Euclidean gradient
    grad_euclidean = compute_morphism_gradient_feedback_euclidean(agent_i, eps=eps)
    grad_euclidean = np.nan_to_num(grad_euclidean)

# Pre-project clip for safety
    grad_norm = np.linalg.norm(grad_euclidean)
    clip_thresh = getattr(config, "clip_morphism_euclidean_grad", 1e4)
    if grad_norm > clip_thresh:
        grad_euclidean *= clip_thresh / (grad_norm + eps)
        if getattr(config, "debug_gradients", False):
            print(f"[CLIP-EUC] grad Phi norm {grad_norm:.2e} clipped to {clip_thresh:.1e}")

    if mask is not None:
        grad_euclidean *= mask[..., None, None]

    # Step 2: Project to natural gradient using inverse Fisher
    grad_natural = dexpinv_operator_morphism(
        Phi=agent_i.bundle_morphism_q_to_p,
        grad_Phi=grad_euclidean,
        generators=generators,
        fisher_inv_field=G_inv_field,
        eps=eps,
    )
    grad_natural = np.nan_to_num(grad_natural)

    # Step 3: Norm & optional clipping
    norm = np.linalg.norm(grad_natural)
    if not np.isfinite(norm):
        print("[WARNING] grad_natural norm is NaN or Inf — zeroing update")
        grad_natural = np.zeros_like(grad_natural)
        norm = 0.0

    if getattr(config, "debug_gradients", False):
        print(f"[Grad Phi] GradPhi norm (pre-clip): {norm:.2e}")

    if getattr(config, "clip_morphism_grad", True) and norm > getattr(config, "gradient_clip", 1e5):
        grad_natural *= getattr(config, "gradient_clip", 1e5) / norm
        if getattr(config, "debug_gradients", False):
            print(f"[CLIP] GradPhi norm {norm:.2e} clipped to {getattr(config, 'gradient_clip', 1e5):.1e}")

    # Step 4: Convert to matrix-valued gradient and apply
    delta_Phi_matrix = np.einsum("...a,aij->...ij", grad_natural, generators)
    agent_i.grad_Phi += feedback_weight * np.nan_to_num(delta_Phi_matrix)



def accumulate_morphism_self_gradient_natural(
    agent_i,
    alpha,
    generators,
    G_inv_field,      # <-- now passed in
    mask=None,
    eps=1e-8,
):
    """
    Accumulate natural gradient ∇_{Φ̃} KL(q || Φ̃·p) into agent_i.grad_Phi_tilde

    Uses precomputed rectangular inverse Fisher metric: G_inv_field
    """
    # Step 1: Euclidean gradient
    grad_euclidean = compute_morphism_gradient_self_euclidean(agent_i, eps=eps)
    if mask is not None:
        grad_euclidean *= mask[..., None, None]

    # Step 2: Natural gradient projection using cached rectangular inverse Fisher
    grad_natural = dexpinv_operator_morphism(
        Phi=agent_i.bundle_morphism_p_to_q,
        grad_Phi=grad_euclidean,
        generators=generators,          # shape (d, K_q, K_p)
        fisher_inv_field=G_inv_field,   # <-- now cached
        eps=eps,
    )

    # Step 3: Clipping (optional)
    norm = np.linalg.norm(grad_natural)
    if getattr(config, "debug_gradients", False):
        print(f"[Grad Phi~] Norm (pre-clip): {norm:.2e}")

    clip = getattr(config, "clip_morphism_grad", True)
    threshold = getattr(config, "gradient_clip", 1e5)
    if clip and norm > threshold:
        grad_natural *= threshold / norm
        if getattr(config, "debug_gradients", False):
            print(f"[CLIP] Grad Phi~ norm {norm:.2e} clipped to {threshold:.1e}")

    # Step 4: Convert Lie gradient to matrix and apply
    delta_Phi_tilde = np.einsum("...a,aij->...ij", grad_natural, generators)
    agent_i.grad_Phi_tilde += alpha * np.nan_to_num(delta_Phi_tilde)





def compute_morphism_kl_gradient_feedback_natural(
    Phi, eta1_q, eta2_q, eta1_p, eta2_p, eps=1e-8
):
    """
    Fully η-native computation of ∇_Φ D_KL(p || Φ q)

    All terms expressed in terms of η only — no μ, Σ reconstruction.

    Returns:
        grad_Phi : (..., K_p, K_q)
    """

    eta2_q_inv = safe_inv(eta2_q, eps=eps)               # (..., K_q, K_q)
    eta2_p_inv = safe_inv(eta2_p, eps=eps)               # (..., K_p, K_p)

    A = -0.5 * np.einsum("...ik,...kl,...jl->...ij", Phi, eta2_q_inv, Phi)  # (..., K_p, K_p)
    A = sanitize_sigma(A, eps=eps)
    A_inv = safe_inv(A, eps=eps)

    B = -0.5 * (
        np.einsum("...ij,...j->...i", eta2_p_inv, eta1_p)
        - np.einsum("...ij,...jk,...k->...i", Phi, eta2_q_inv, eta1_q)
    )  # (..., K_p)

    BBT = np.einsum("...i,...j->...ij", B, B)  # (..., K_p, K_p)

    term1 = -0.5 * np.einsum("...ik,...kl,...lj->...ij", A_inv, BBT, A_inv)
    term2 = -0.25 * (A_inv + 0.25 * np.einsum("...ik,...kl,...lj->...ij", A_inv, eta2_p_inv, A_inv))

    dPhi = np.einsum("...ij,...jk->...ik", term1 + term2, eta2_q_inv)

    return dPhi

def compute_morphism_kl_gradient_self_natural(
    Phi_tilde, eta1_q, eta2_q, eta1_p, eta2_p, eps=1e-8
):
    """
    Fully η-native computation of ∇_{Φ̃} D_KL(q || Φ̃ p)

    Args:
        Phi_tilde : (..., K_q, K_p)
        eta1_q    : (..., K_q)
        eta2_q    : (..., K_q, K_q)
        eta1_p    : (..., K_p)
        eta2_p    : (..., K_p, K_p)
        eps       : regularization stabilizer

    Returns:
        grad_Phi_tilde : (..., K_q, K_p)
    """
    eta2_p_inv = safe_inv(eta2_p, eps=eps)
    eta2_q_inv = safe_inv(eta2_q, eps=eps)

    # Ã_p = Φ̃ Σ_p Φ̃ᵀ = -½ Φ̃ η₂ₚ⁻¹ Φ̃ᵀ
    A = -0.5 * np.einsum("...ik,...kl,...jl->...ij", Phi_tilde, eta2_p_inv, Phi_tilde)
    A = sanitize_sigma(A, eps=eps)
    A_inv = safe_inv(A, eps=eps)

    # B̃_qp = μ_q - Φ̃ μ_p = -½ (η₂_q⁻¹ η₁_q - Φ̃ η₂_p⁻¹ η₁_p)
    mu_q_term = np.einsum("...ij,...j->...i", eta2_q_inv, eta1_q)
    mu_p_term = np.einsum("...ij,...j->...i", eta2_p_inv, eta1_p)
    mu_push_p = np.einsum("...ij,...j->...i", Phi_tilde, mu_p_term)
    B = -0.5 * (mu_q_term - mu_push_p)  # (..., K_q)

    BBT = np.einsum("...i,...j->...ij", B, B)  # (..., K_q, K_q)

    # First term: A⁻¹ B Bᵀ A⁻¹ Φ̃ η₂ₚ⁻¹
    term1 = np.einsum("...ik,...kl,...lj->...ij", A_inv, BBT, A_inv)

    # Second term:
    term2a = 0.5 * A_inv
    term2b = 0.25 * np.einsum("...ik,...kl,...lj->...ij", A_inv, eta2_q_inv, A_inv)
    term2 = term2a + term2b

    # Final multiplication: (term1 + term2) @ Φ̃ η₂ₚ⁻¹
    tmp = term1 + term2
    grad_Phi_tilde = np.einsum("...ij,...jk,...kl->...il", tmp, Phi_tilde, eta2_p_inv)

    return grad_Phi_tilde











#######################################################
########################################################
######################################################



def compute_morphism_kl_gradient_feedback(Phi, mu_q, Sigma_q, mu_p, Sigma_p, eps=1e-8):
    """
    Compute ∂/∂Φ D_KL(p || Φ·q) using closed-form decomposition.

    Returns:
        grad_Phi : (K_p, K_q)
    """
    # Precompute shared terms
    primitives = compute_morphism_feedback_gradient_primitives(
        Phi, mu_q, Sigma_q, mu_p, Sigma_p, eps=eps
    )

    Δμ      = primitives["Delta_mu"]       # (K_p,)
    Σ_q_inv = primitives["Sigma_q_inv"]    # (K_q, K_q)
    M_inv   = primitives["M_inv"]          # (K_p, K_p)
    term_trace  = primitives["term_trace"]     # (K_p, K_p)
    term_logdet = primitives["term_logdet"]    # (K_p, K_q)

    # ---- Decompose each term ----
    outer = np.outer(Δμ, Δμ)                        # (K_p, K_p)
    mahal = M_inv @ outer @ M_inv @ Phi @ Sigma_q   # (K_p, K_q)
    logdet = term_logdet                            # (K_p, K_q)
    trace_term = -term_trace @ Phi @ Sigma_q        # (K_p, K_q)

    # ---- Total gradient ----
    grad_Phi = mahal + logdet + trace_term
    return grad_Phi

#validated
def compute_morphism_kl_gradient_self(
    Phi_tilde, mu_q, Sigma_q, mu_p, Sigma_p, eps=1e-6, max_grad_norm=10.0
):
    """
    Compute ∂/∂Φ~ D_KL(q || Φ~·p), where Φ~: P → Q

    Args:
        Phi_tilde : (K_q, K_p) morphism matrix Φ~ (pulls p → q)
        mu_q      : (K_q,)     mean of q
        Sigma_q   : (K_q, K_q) covariance of q
        mu_p      : (K_p,)     mean of p
        Sigma_p   : (K_p, K_p) covariance of p
        eps       : numerical regularization for stability
        max_grad_norm : optional clipping threshold

    Returns:
        grad_Phi  : (K_q, K_p) gradient of KL divergence w.r.t. Φ~
    """
    
    # Sanitize all covariances
    Sigma_q = sanitize_sigma(Sigma_q, eps=eps)
    Sigma_p = sanitize_sigma(Sigma_p, eps=eps)

    # Pushforward Sigma_p: Φ̃ Σ_p Φ̃ᵀ
    Sigma_push = Phi_tilde @ Sigma_p @ Phi_tilde.T
    Sigma_push = sanitize_sigma(Sigma_push, eps=eps)
    M_inv = safe_inv(Sigma_push, eps=eps)

    # Δμ = μ_q − Φ̃ μ_p
    Delta_mu = mu_q - Phi_tilde @ mu_p  # (K_q,)

    # --- Compute gradient terms ---

    # Term 1: M⁻¹ Δμ Δμᵀ M⁻¹ Φ̃ Σ_p
    term1 = M_inv @ np.outer(Delta_mu, Delta_mu) @ M_inv @ Phi_tilde @ Sigma_p

    # Term 2: + M⁻¹ Φ̃ Σ_p (from log-det derivative of pushforward)
    term2 = M_inv @ Phi_tilde @ Sigma_p

    # Term 3: - M⁻¹ Σ_q M⁻¹ Φ̃ Σ_p
    term3 = -M_inv @ Sigma_q @ M_inv @ Phi_tilde @ Sigma_p

    grad_Phi = term1 + term2 + term3

    # --- Clip gradient norm ---
    norm = np.linalg.norm(grad_Phi)
    if norm > max_grad_norm:
        grad_Phi = grad_Phi * (max_grad_norm / (norm + eps))

    # --- Sanitize output ---
    if not np.all(np.isfinite(grad_Phi)):
        grad_Phi[...] = 0.0
        print("[WARNING] ∇Φ̃ returned NaN or Inf — zeroed out")

    return grad_Phi

###########==============================
#=================######################


    
def compute_morphism_gradient_feedback_euclidean(agent_i, eps=1e-8):
    """
    Compute ∂/∂Φ KL(p || Φ·q) over spatial grid using agent fields.

    Returns:
        grad_Phi: (H, W, K_p, K_q) Euclidean gradient
    """
    return compute_morphism_feedback_gradient_batched(
        agent_i.bundle_morphism_q_to_p,
        agent_i.mu_q_field,
        agent_i.sigma_q_field,
        agent_i.mu_p_field,
        agent_i.sigma_p_field,
        eps=eps
    )


def compute_morphism_gradient_self_euclidean(agent_i, eps=1e-8):
    """
    Compute full Euclidean gradient ∂/∂Φ~ KL(q || Φ~·p) over the spatial grid.

    Returns:
        grad: (H, W, K_q, K_p) Euclidean gradient
    """
    return compute_morphism_self_gradient_batched(
        agent_i.bundle_morphism_p_to_q,
        agent_i.mu_q_field,
        agent_i.sigma_q_field,
        agent_i.mu_p_field,
        agent_i.sigma_p_field,
        eps=eps
    )




def compute_morphism_feedback_gradient_batched(Phi, mu_q, Sigma_q, mu_p, Sigma_p, eps=1e-8):
    """
    Batched version of ∂/∂Φ D_KL(p || Φ·q) for spatial grid.
    """
    H, W, K_p, K_q = Phi.shape
    grad = np.zeros_like(Phi)

    for i in range(H):
        for j in range(W):
            grad[i, j] = compute_morphism_kl_gradient_feedback(
                Phi[i, j], mu_q[i, j], Sigma_q[i, j],
                mu_p[i, j], Sigma_p[i, j], eps=eps
            )

    return grad

def compute_morphism_self_gradient_batched(Phi_tilde, mu_q, Sigma_q, mu_p, Sigma_p, eps=1e-8):
    """
    Batched version of ∂/∂Φ~ D_KL(q || Φ~·p) for spatial grid.
    
    Args:
        Phi~     : (H, W, K_q, K_p)
        mu_q     : (H, W, K_q)
        Sigma_q  : (H, W, K_q, K_q)
        mu_p     : (H, W, K_p)
        Sigma_p  : (H, W, K_p, K_p)
        eps      : float, SPD regularization
    
    Returns:
        grad     : (H, W, K_q, K_p) KL gradient w.r.t. Φ~ at each spatial location
    """
    H, W, K_q, K_p = Phi_tilde.shape
    grad = np.zeros_like(Phi_tilde)

    for i in range(H):
        for j in range(W):
            grad[i, j] = compute_morphism_kl_gradient_self(
                Phi_tilde[i, j], mu_q[i, j], Sigma_q[i, j],
                mu_p[i, j], Sigma_p[i, j], eps=eps
                )


    return grad
#==============================================================================
#
#                    FEEDBACK TERMS
#
#==============================================================================



def compute_morphism_feedback_gradient_primitives(Phi, mu_q, Sigma_q, mu_p, Sigma_p, eps=1e-8):
    """
    Compute shared intermediates needed to evaluate ∂/∂Φ D_KL(p || Φ·q)
    
    Args:
        Phi      : (K_p, K_q) linear morphism matrix Φ
        mu_q     : (K_q,)     mean of belief q
        Sigma_q  : (K_q, K_q) covariance of belief q
        mu_p     : (K_p,)     mean of model p
        Sigma_p  : (K_p, K_p) covariance of model p
        eps      : stabilizer for SPD inverse

    Returns:
        dict containing:
            - Delta_mu     : (K_p,)     = mu_p - Φ·mu_q
            - Sigma_q_inv  : (K_q, K_q)
            - Sigma_p_inv  : (K_p, K_p)
            - M            : (K_p, K_p) = Φ Σ_q Φᵀ
            - M_inv        : (K_p, K_p)
            - term_trace   : (K_p, K_p) = M⁻¹ Σ_p M⁻¹
            - term_logdet  : (K_p, K_q) = M⁻¹ Φ Σ_q
    """
    K_p, K_q = Phi.shape

    # Δμ = μ_p − Φ·μ_q
    Delta_mu = mu_p - Phi @ mu_q

    # ── Sanitize input covariances ──────────────────────────────
    Sigma_q = sanitize_sigma(Sigma_q, eps=eps)
    Sigma_p = sanitize_sigma(Sigma_p, eps=eps)

    # ── Safe inverses ───────────────────────────────────────────
    Sigma_q_inv = safe_inv(Sigma_q, eps=eps)
    Sigma_p_inv = safe_inv(Sigma_p, eps=eps)

    # M = Φ Σ_q Φᵀ
    M = Phi @ Sigma_q @ Phi.T
    M = sanitize_sigma(M, eps=eps)
    M_inv = safe_inv(M, eps=eps)

    # ── Precompute reusable terms ───────────────────────────────
    term_trace  = 0.5 * M_inv @ Sigma_p @ M_inv   # (K_p, K_p)
    term_logdet = 0.5 * M_inv @ Phi @ Sigma_q     # (K_p, K_q)

    return {
        "Delta_mu": Delta_mu,
        "Sigma_q_inv": Sigma_q_inv,
        "Sigma_p_inv": Sigma_p_inv,
        "M": M,
        "M_inv": M_inv,
        "term_trace": term_trace,
        "term_logdet": term_logdet
    }







#==============================================================================
#
#                    SELF-ENERGY TERMS
#
#==============================================================================


def grad_morphism_self_energy(agent_i, alpha, mask=None, eps=1e-8):
    """
    Compute full gradient ∂/∂Φ KL(q || Φ~·p) over spatial grid (H, W)
    """
    mu_q    = agent_i.mu_q_field
    sigma_q = agent_i.sigma_q_field
    mu_p    = agent_i.mu_p_field
    sigma_p = agent_i.sigma_p_field
    Phi_tilde     = agent_i.bundle_morphism_p_to_q

    grad = compute_morphism_self_gradient_batched(
        Phi_tilde, mu_q, sigma_q, mu_p, sigma_p, eps=eps
    )

    if mask is not None:
        grad *= mask[..., None, None]  # shape (H, W, 1, 1)

    return alpha * grad



from numerical_utils import sanitize_sigma


def compute_morphism_self_gradient_primitives(Phi_tilde, mu_q, Sigma_q, mu_p, Sigma_p, eps=1e-8):
    """
    Compute shared intermediates needed to evaluate ∂/∂Φ~ D_KL(q || Φ~·p)

    Returns:
        dict with sanitized + safe inverses:
            - Delta_mu     : (K_q,)     = mu_q - Φ~·mu_p
            - Sigma_q_inv  : (K_q, K_q)
            - Sigma_p_inv  : (K_p, K_p)
            - M            : (K_q, K_q) = Φ~ Σ_p Φ~ᵀ
            - M_inv        : (K_q, K_q)
            - term_trace   : (K_q, K_q) = M⁻¹ Σ_q M⁻¹
            - term_logdet  : (K_q, K_p) = M⁻¹ Φ~ Σ_p
    """
    K_q, K_p = Phi_tilde.shape

    # Δμ = μ_q − Φ~·μ_p
    Delta_mu = mu_q - Phi_tilde @ mu_p

    # ── Sanitize covariances ─────────────────────────────────────
    Sigma_q = sanitize_sigma(Sigma_q, eps=eps)
    Sigma_p = sanitize_sigma(Sigma_p, eps=eps)

    # ── Safe inverses ────────────────────────────────────────────
    Sigma_q_inv = safe_inv(Sigma_q, eps=eps)
    Sigma_p_inv = safe_inv(Sigma_p, eps=eps)

    # M = Φ~ Σ_p Φ~ᵀ
    M = Phi_tilde @ Sigma_p @ Phi_tilde.T
    M = sanitize_sigma(M, eps=eps)        # Ensure symmetry/SPD before inverse
    M_inv = safe_inv(M, eps=eps)

    # Precompute reusable gradient terms
    term_trace  = 0.5 * M_inv @ Sigma_q @ M_inv     # (K_q, K_q)
    term_logdet = 0.5 * M_inv @ Phi_tilde @ Sigma_p # (K_q, K_p)

    return {
        "Delta_mu": Delta_mu,
        "Sigma_q_inv": Sigma_q_inv,
        "Sigma_p_inv": Sigma_p_inv,
        "M": M,
        "M_inv": M_inv,
        "term_trace": term_trace,
        "term_logdet": term_logdet
    }






