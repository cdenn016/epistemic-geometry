# -*- coding: utf-8 -*-
"""
Created on Sat Sep 27 15:19:10 2025

@author: chris and christine

gamma_q: Case A:  KL( q_j ||Ω^q_ji Φ̃_i p_i )
gamma_p: Case B:  KL( p_i || Φ_i Ω^q_ij q_j )  

beta_q:  KL( q_i || Ω^q_ij q_j )
beta_p:  KL( p_i || Ω^p_ij p_j ) 

"""

import numpy as np
from core.numerical_utils import sanitize_sigma, kl_gaussian, push_gaussian
from core.transport_cache import Omega,  Phi
from utils import _beta_cfg, joint_masks
from runtime_context import cfg_get, EdgeMaps
 


# ──────────────────────────────────────────────────────────────────────────────
# Main entry
# ──────────────────────────────────────────────────────────────────────────────
def overlap_mask(ctx, ai, aj):
    """
    Single masking point for edge(i,j):
      - returns boolean mask (*S,) where agents overlap.
      - never pre-multiplies γ; callers must zero outside after computing γ.
    """
    import numpy as np
    mi = np.asarray(getattr(ai, "mask"), np.bool_)
    mj = np.asarray(getattr(aj, "mask"), np.bool_)
    # Broadcast-safe AND; if shapes differ, rely on numpy broadcasting or raise
    try:
        m = np.logical_and(mi, mj)
    except Exception as e:
        raise ValueError(f"overlap_mask: incompatible masks {mi.shape} vs {mj.shape}") from e
    return m





def compute_edge_betas(ctx, agents, *, which="q"):
    """
    Per-edge maps for a single fiber ('q' or 'p'), using *alignment* KL only.

    Writes ONLY via ctx.edge.set_align(...); consumers should read via
    ctx.edge.get_align(...). Joint overlap is handled by utils.joint_masks.

    Masking policy (SSOT):
      • Logits: mask via -inf (no pre-multiply).
      • Stored KL: mask via np.where(mbool, KL, 0.0).
      • Stored β:  mask once at the end via np.where(mbool, W[s], 0.0).
    """
    
    if which not in ("q", "p"):
        raise ValueError("which must be 'q' or 'p'")

    # --- unified API: clear just this fiber; no legacy dict surgery here ---
    if not hasattr(ctx, "edge") or ctx.edge is None:
        ctx.edge = EdgeMaps()
    ctx.edge.clear_fiber(which)

    # Feature toggle (still materialize zeros so downstream shapes exist)
    use_align = bool(cfg_get(ctx, "use_align_q" if which == "q" else "use_align_p", True))

    kappa, eps, _ = _beta_cfg(ctx, which)  # tau handled inside joint_masks
    _mu, _S, _mask, _mu_q, _S_q, _mu_p, _S_p = _fiber_accessors(which)
    ids = [int(getattr(a, "id", i)) for i, a in enumerate(agents)]

    for i_idx, ai in enumerate(agents):
        i_id   = ids[i_idx]
        Sshape = tuple(np.asarray(_mu(ai)).shape[:-1])

        if not use_align:
            # Write zeros for every sender to keep shapes consistent
            Z = np.zeros(Sshape, np.float32)
            for j_idx, aj in enumerate(agents):
                if j_idx == i_idx:
                    continue
                j_id = ids[j_idx]
                ctx.edge.set_align(ctx, which, i_id, j_id, kl=Z, beta=Z)
            continue

        logits_list, mask_list, send_ids = [], [], []
        kl1_store = {}

        for j_idx, aj in enumerate(agents):
            if j_idx == i_idx:
                continue
            j_id = ids[j_idx]

            # Canonical overlap mask over base space C
            mbool, _mvec = joint_masks(ctx, ai, aj)   # mbool: (*S,), mvec: (*S,1)
            if not np.any(mbool):
                # Ensure consumers see explicit zeros for non-overlaps
                Z = np.zeros(Sshape, np.float32)
                ctx.edge.set_align(ctx, which, i_id, j_id, kl=Z, beta=Z)
                continue

            # Select fiber params and transport
            if which == "q":
                Om   = Omega(ctx, ai, aj, which="q")
                mu_i, S_i = _mu_q(ai), _S_q(ai)
                mu_j, S_j = _mu_q(aj), _S_q(aj)
            else:
                Om   = Omega(ctx, ai, aj, which="p")
                mu_i, S_i = _mu_p(ai), _S_p(ai)
                mu_j, S_j = _mu_p(aj), _S_p(aj)

            # Push neighbor into receiver frame and compute alignment KL
            mu_j_t, S_j_t = push_gaussian(mu_j, S_j, Om, eps=eps)[:2]
            KL_ij = kl_gaussian(mu_i, S_i, mu_j_t, S_j_t, eps=eps)

            # Reduce any trailing latent dims if present
            if KL_ij.shape != Sshape:
                if KL_ij.shape[:len(Sshape)] == Sshape and KL_ij.ndim > len(Sshape):
                    KL_ij = KL_ij.reshape(Sshape + (-1,)).sum(axis=-1)
                else:
                    raise ValueError(f"KL dims {KL_ij.shape} incompatible with {Sshape}")

            KL_ij = KL_ij.astype(np.float32, copy=False)

            # Store masked KL for diagnostics (single masking point)
            KL_masked = np.where(mbool, KL_ij, 0.0).astype(np.float32, copy=False)
            kl1_store[(which, i_id, j_id)] = KL_masked

            # Logits: mask via -inf off-overlap (no pre-multiply)
            logits = (-KL_ij / max(kappa, eps)).astype(np.float32, copy=False)
            logits_list.append(np.where(mbool, logits, -np.inf))  # (sender, *S)
            mask_list.append(mbool)
            send_ids.append(j_id)

        if not send_ids:
            continue

        # Softmax over senders at each pixel
        L = np.stack(logits_list, axis=0)     # (Ns, *S)
        M = np.stack(mask_list,   axis=0)     # (Ns, *S) bool
        W = _softmax_over_senders(L, M, tiny=1e-12)  # (Ns, *S), zeros off-overlap

        # ---- β softmax invariant check (+ optional renorm) ----
        any_sender = np.any(M, axis=0)                 # (*S,)
        sum_beta   = np.sum(W, axis=0, dtype=np.float32)  # (*S,)
        dev_map = np.zeros_like(sum_beta, dtype=np.float32)
        dev_map[any_sender] = np.abs(sum_beta[any_sender] - 1.0)
        max_dev = float(np.nanmax(dev_map)) if np.any(any_sender) else 0.0

        tol = float(cfg_get(ctx, "beta_norm_tolerance", 1e-4))
        if max_dev > tol:
            msg = f"[β-invariant] max deviation={max_dev:.3e} (tol={tol:.1e})"
            if bool(cfg_get(ctx, "strict_beta_norm", False)):
                raise AssertionError(msg)
            else:
                tiny = 1e-12
                denom = np.where(sum_beta > tiny, sum_beta, 1.0).astype(np.float32, copy=False)
                W = W / denom  # broadcast over sender axis
                # (optional) report post-fix deviation
                sum_beta_fix = np.sum(W, axis=0, dtype=np.float32)
                dev_fix = np.zeros_like(sum_beta_fix, dtype=np.float32)
                dev_fix[any_sender] = np.abs(sum_beta_fix[any_sender] - 1.0)
                max_dev_fix = float(np.nanmax(dev_fix)) if np.any(any_sender) else 0.0
                print(msg + f" → renorm → max deviation={max_dev_fix:.3e}")

        # Store β and KL maps through the unified API (mask once, here)
        for s, j_id in enumerate(send_ids):
            beta_ij = np.where(mask_list[s], W[s], 0.0).astype(np.float32, order="C")
            ctx.edge.set_align(
                ctx, which, i_id, j_id,
                kl=kl1_store[(which, i_id, j_id)],
                beta=beta_ij,
            )

    return ctx



# --- in whatever module currently defines compute_edge_gammas (e.g., beta.py or gamma.py)

def compute_edge_gammas(ctx, agents, *, kappa_q=None, kappa_p=None, eps=1e-8):
    """
    Build γ maps for all directed pairs (i,j), via EdgeMaps only.

    Case A (store key=("A", j_id, i_id)):
        γ_A(j→i, x) = exp( - KL( q_j || Ω^q_ji[ Φ̃_i p_i ] ) / κ_q )

    Case B (store key=("B", i_id, j_id)):
        γ_B(i→j, x) = exp( - KL( p_i || Φ_i[ Ω^q_ij q_j ] ) / κ_p )

    Masking policy (mirrors β):
      • Compute KL on the full lattice (no pre-multiply).
      • After γ = exp(-KL/κ), set γ=0 off-overlap using joint_masks().
      • For diagnostics, set KL=0 off-overlap as well.

    Invariants on the overlap set:
      • KL ≥ 0 (within tol)
      • 0 ≤ γ ≤ 1 + tol
      • finite (no NaNs/Inf)
    """
    
    if not agents:
        ctx.edge.gamma.clear()
        ctx.edge.klX.clear()
        return ctx

    # --- config
    cfg = getattr(ctx, "gamma_cfg", {}) or {}
    kq = float(kappa_q if kappa_q is not None else cfg.get("kappa_q", 1.0))
    kp = float(kappa_p if kappa_p is not None else cfg.get("kappa_p", 1.0))
    tol = float(cfg.get("tol", 1e-6))

    # --- id map
    ids = [int(getattr(a, "id", i)) for i, a in enumerate(agents)]
    id2agent = {ids[i]: a for i, a in enumerate(agents)}

    for i_id, ai in id2agent.items():
        for j_id, aj in id2agent.items():
            if i_id == j_id:
                continue

            # single masking point (bool for indexing; float for broadcast if needed)
            m_bool, _m_float = joint_masks(ctx, ai, aj)
            Sshape = np.asarray(getattr(ai, "mu_q_field")).shape[:-1]

            # pre-allocate output (full lattice)
            gA = np.zeros(Sshape, np.float64)
            gB = np.zeros(Sshape, np.float64)
            kA = np.zeros(Sshape, np.float64)
            kB = np.zeros(Sshape, np.float64)

            if not np.any(m_bool):
                # still store zeros for consistent shapes
                ctx.edge.set_gamma(ctx, "A", j_id, i_id,
                                   gamma_map=gA.astype(np.float32, copy=False),
                                   kl_map=kA.astype(np.float32, copy=False))
                ctx.edge.set_gamma(ctx, "B", i_id, j_id,
                                   gamma_map=gB.astype(np.float32, copy=False),
                                   kl_map=kB.astype(np.float32, copy=False))
                continue

            # pull fields (float64 math)
           
            mu_p_i = np.asarray(getattr(ai, "mu_p_field"), np.float64)
            S_p_i  = np.asarray(getattr(ai, "sigma_p_field"), np.float64)

            mu_q_j = np.asarray(getattr(aj, "mu_q_field"), np.float64)
            S_q_j  = np.asarray(getattr(aj, "sigma_q_field"), np.float64)

            # transports / morphisms
            Om_ij = np.asarray(Omega(ctx, ai, aj, which="q"), np.float64)  # q_j -> q_i
            Om_ji = np.asarray(Omega(ctx, aj, ai, which="q"), np.float64)  # q_i -> q_j
            Phi_i  = np.asarray(Phi(ctx, ai, kind="q_to_p"), np.float64)
            Phit_i = np.asarray(Phi(ctx, ai, kind="p_to_q"), np.float64)

            # ---- Case A: KL(q_j || Ω_ji[ Φ̃_i p_i ])
            mu_pi_q, S_pi_q = push_gaussian(mu_p_i, S_p_i, Phit_i, eps=eps)[:2]
            mu_pi_q_j, S_pi_q_j = push_gaussian(mu_pi_q, S_pi_q, Om_ji, eps=eps)[:2]
            KL_A = kl_gaussian(mu_q_j, S_q_j, mu_pi_q_j, S_pi_q_j, eps=eps)

            # ---- Case B: KL(p_i || Φ_i[ Ω_ij q_j ])
            mu_qj_i, S_qj_i = push_gaussian(mu_q_j, S_q_j, Om_ij, eps=eps)[:2]
            mu_qj_i_p, S_qj_i_p = push_gaussian(mu_qj_i, S_qj_i, Phi_i, eps=eps)[:2]
            KL_B = kl_gaussian(mu_p_i, S_p_i, mu_qj_i_p, S_qj_i_p, eps=eps)

            # γ = exp(-KL/κ), then zero off-overlap
            # (compute only on overlap to avoid exp of junk)
            kA[m_bool] = np.clip(KL_A[m_bool], 0.0, np.inf)
            kB[m_bool] = np.clip(KL_B[m_bool], 0.0, np.inf)
            gA[m_bool] = np.exp(-kA[m_bool] / max(kq, eps))
            gB[m_bool] = np.exp(-kB[m_bool] / max(kp, eps))

            # invariants on the overlap only
            _check_gamma_invariants(ctx, gA[m_bool], kA[m_bool], which="A", i_id=i_id, j_id=j_id, tol=tol)
            _check_gamma_invariants(ctx, gB[m_bool], kB[m_bool], which="B", i_id=i_id, j_id=j_id, tol=tol)

            # store (float32)
            ctx.edge.set_gamma(ctx, "A", j_id, i_id,
                               gamma_map=gA.astype(np.float32, copy=False),
                               kl_map=kA.astype(np.float32, copy=False))
            ctx.edge.set_gamma(ctx, "B", i_id, j_id,
                               gamma_map=gB.astype(np.float32, copy=False),
                               kl_map=kB.astype(np.float32, copy=False))


def _check_gamma_invariants(ctx, gamma_vals, kl_vals, *, which: str, i_id: int, j_id: int, tol: float):
    """
    Invariants for γ/KL on the overlap set:
      • KL ≥ -tol
      • 0 - tol ≤ γ ≤ 1 + tol
      • finite
    Logs warnings (does not raise) to avoid killing long runs.
    """
    
    if gamma_vals.size == 0:
        return
    issues = []
    if not np.all(np.isfinite(gamma_vals)): issues.append("γ non-finite")
    if not np.all(np.isfinite(kl_vals)):    issues.append("KL non-finite")
    if np.nanmin(kl_vals) < -tol:          issues.append(f"KL < 0 (min={float(np.nanmin(kl_vals)):.3e})")
    gmin = float(np.nanmin(gamma_vals)) if gamma_vals.size else 0.0
    gmax = float(np.nanmax(gamma_vals)) if gamma_vals.size else 0.0
    if gmin < -tol or gmax > 1.0 + tol:
        issues.append(f"γ bounds (min={gmin:.3e}, max={gmax:.3e})")

    if issues:
        msg = f"[γ/{which}] invariants warn (i={i_id}, j={j_id}): " + "; ".join(issues)
        logger = getattr(ctx, "logger", None)
        try:
            (logger.warning if logger else print)(msg)
        except Exception:
            print(msg)



def compute_edge_phase(ctx, agents, *, build_q=True, build_p=True, eps=1e-8):
    """
    One call to populate per-edge state for the step:
      - ALIGN: β and KL1 for requested fibers
      - Γ maps (A/B) and their KL diagnostics
    Uses the same logic as compute_edge_betas / compute_edge_gammas but
    centralizes the pass and writes through the EdgeMaps API.
    """
    if build_q:
        compute_edge_betas(ctx, agents, which="q")
    if build_p:
        compute_edge_betas(ctx, agents, which="p")
    # γ always uses Ω^q in your current spec
    compute_edge_gammas(ctx, agents, eps=eps)
    return ctx



# ──────────────────────────────────────────────────────────────────────────────
# Accessors / config helpers
# ──────────────────────────────────────────────────────────────────────────────



def _fiber_accessors(which: str):
    """Return closures to get μ, Σ, and mask for active fiber, plus q/p helpers."""
    if which not in ("q", "p"):
        raise ValueError("_fiber_accessors: which must be 'q' or 'p'")

    def _mu(a):
        return np.asarray(getattr(a, "mu_q_field" if which == "q" else "mu_p_field"), np.float32)

    def _S(a):
        base = getattr(a, "sigma_q_field" if which == "q" else "sigma_p_field")
        return sanitize_sigma(np.asarray(base, np.float64))

    def _mask(a):
        m = np.asarray(getattr(a, "mask"), np.float32)
        if m.ndim >= 1 and m.shape[-1] == 1:
            m = m[..., 0]
        return m

    # helpers for the "other" fiber (used by A–D bases)
    def _mu_q(a): return np.asarray(getattr(a, "mu_q_field"), np.float32)
    def _S_q(a):  return sanitize_sigma(np.asarray(getattr(a, "sigma_q_field"), np.float64))
    def _mu_p(a): return np.asarray(getattr(a, "mu_p_field"), np.float32)
    def _S_p(a):  return sanitize_sigma(np.asarray(getattr(a, "sigma_p_field"), np.float64))

    return _mu, _S, _mask, _mu_q, _S_q, _mu_p, _S_p





# ──────────────────────────────────────────────────────────────────────────────
# KL builders
# ──────────────────────────────────────────────────────────────────────────────
def _softmax_over_senders(logits: np.ndarray, mask: np.ndarray, tiny: float = 1e-12):
    """
    Masked softmax over axis 0 (senders). Shapes (J,*S).
    - Zero weights where no sender is valid at a pixel.
    - NaN/±inf-safe under strict np.seterr.
    - Underflow-safe when casting to float32: clamp subnormals to 0 then renormalize.
    """
    

    L = np.asarray(logits, np.float64)
    M = np.asarray(mask, dtype=bool)

    # valid := on-mask AND finite
    valid = M & np.isfinite(L)
    any_valid = np.any(valid, axis=0, keepdims=True)  # (1,*S)

    # Max over valid entries; -inf where none are valid
    L_masked = np.where(valid, L, -np.inf)
    Lmax = np.max(L_masked, axis=0, keepdims=True)
    Lmax_safe = np.where(np.isfinite(Lmax), Lmax, 0.0)  # avoid (-inf)-(-inf)

    with np.errstate(invalid='ignore', over='ignore', under='ignore'):
        shifted = L - Lmax_safe
        shifted = np.where(valid, shifted, -np.inf)
        expL = np.exp(shifted)
        expL = np.where(valid, expL, 0.0)

    Z = np.sum(expL, axis=0, keepdims=True)
    Z = np.where(any_valid, np.maximum(Z, tiny), 1.0)

    W = expL / Z
    W = np.where(any_valid, W, 0.0)

    # ---- Underflow-safe cast to float32 ----
    # Clamp subnormals to zero, then renormalize across senders.
    tiny32 = np.finfo(np.float32).tiny  # ~1.1754944e-38
    W = np.where(W < tiny32, 0.0, W)

    sumW = np.sum(W, axis=0, keepdims=True)
    # If we zeroed some tiny entries, re-normalize to keep sum=1 where valid
    sumW_safe = np.where(any_valid, np.maximum(sumW, 1.0), 1.0)
    W = np.where(any_valid, W / sumW_safe, 0.0)

    # Now casting cannot underflow (we only have zeros or >= tiny32)
    return W.astype(np.float32, copy=False)







def _ensure_edgemaps(ctx):
    if not hasattr(ctx, "edge") or ctx.edge is None:
        ctx.edge = EdgeMaps()
    return ctx.edge


def beta_align_maps(ctx, agent_i, agent_j, *, which: str):
    """
    Read-only accessor for ALIGN maps produced earlier.
    Now reads via ctx.edge.get_align(...) and ALWAYS returns arrays.

    Returns:
        KL_ij, beta_ij  (each shape (*S,), float32)
    """
    edge = _ensure_edgemaps(ctx)

    # Determine receiver spatial shape via canonical mask helper
    mbool, _mvec = joint_masks(ctx, agent_i, agent_j)  # mbool: (*S,)
    Sshape = mbool.shape

    i_id = int(getattr(agent_i, "id", -1))
    j_id = int(getattr(agent_j, "id", -1))

    # get_align returns (beta, kl); legacy callers expect (KL, beta)
    beta_map, kl_map = edge.get_align(ctx, str(which), i_id, j_id, shape=Sshape) or (None, None)

    if beta_map is None:
        Z = np.zeros(Sshape, np.float32)
        return Z, Z

    beta_map = np.asarray(beta_map, np.float32, order="C")
    kl_map   = np.asarray(kl_map,   np.float32, order="C") if kl_map is not None else np.zeros_like(beta_map)

    return kl_map, beta_map





def gamma_maps(ctx, agent_i, agent_j, *, include_kl: bool = True):
    """
    Fetch γ and (optionally) KL maps for ordered edge (i <- j) using ctx.edge.get_gamma.
    Keys:
      A: ("A", j->i)   B: ("B", i->j)

    Returns dict:
      include_kl=True  -> {"A": (KL_A, γ_A), "B": (KL_B, γ_B)}  (omits missing)
      include_kl=False -> {"A": γ_A, "B": γ_B}
    """
   

    # Shape via canonical joint mask on q-grid (no channel dim)
    mbool, _ = joint_masks(ctx, agent_i, agent_j)
    Sshape = mbool.shape

    i_id = int(getattr(agent_i, "id", -1))
    j_id = int(getattr(agent_j, "id", -1))

    out = {}

    # Case A: j -> i
    gA, kA = ctx.edge.get_gamma(ctx, "A", j_id, i_id, shape=Sshape)
    if gA is not None:
        gA = np.asarray(gA, np.float32, order="C")
        if include_kl:
            kA = np.zeros(Sshape, np.float32) if kA is None else np.asarray(kA, np.float32, order="C")
            out["A"] = (kA, gA)
        else:
            out["A"] = gA

    # Case B: i -> j
    gB, kB = ctx.edge.get_gamma(ctx, "B", i_id, j_id, shape=Sshape)
    if gB is not None:
        gB = np.asarray(gB, np.float32, order="C")
        if include_kl:
            kB = np.zeros(Sshape, np.float32) if kB is None else np.asarray(kB, np.float32, order="C")
            out["B"] = (kB, gB)
        else:
            out["B"] = gB

    return out


def edge_maps_for_align(ctx, agent_i, agent_j, *, which: str):
    """
    Convenience wrapper so other modules don't touch private dicts.
    Returns (KL_align_ij, beta_ij) for ordered edge (i <- j).
    """
    edge = _ensure_edgemaps(ctx)

    # Shape via canonical mask (keeps behavior consistent everywhere)
    mbool, _mvec = joint_masks(ctx, agent_i, agent_j)
    Sshape = mbool.shape

    i_id = int(getattr(agent_i, "id", -1))
    j_id = int(getattr(agent_j, "id", -1))

    beta_map, kl_map = edge.get_align(ctx, str(which), i_id, j_id, shape=Sshape) or (None, None)
    if beta_map is None:
        Z = np.zeros(Sshape, np.float32)
        return Z, Z

    beta_map = np.asarray(beta_map, np.float32, order="C")
    kl_map   = np.asarray(kl_map,   np.float32, order="C") if kl_map is not None else np.zeros_like(beta_map)
    return kl_map, beta_map





