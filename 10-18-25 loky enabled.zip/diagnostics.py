
from __future__ import annotations
from typing import Any, Dict
import numpy as np
from utils import mask_hw
from joblib import Parallel, delayed
from threadpoolctl import threadpool_limits
from runtime_context import cfg_get



def _nan_ok(x):  # small utility
    return np.all(np.isfinite(x))



def inv_beta_softmax(ctx, agents, *, which="q", tol=None, strict=None):
    """
    Verify that per-receiver β maps (over senders) sum to 1 on overlap, and 0 off-overlap.
    Uses EdgeMaps.get_align(..., shape=Sshape) to satisfy your API.
    """
    import numpy as np
    from runtime_context import cfg_get

    tol = float(cfg_get(ctx, "beta_norm_tolerance", 1e-4) if tol is None else tol)
    strict = bool(cfg_get(ctx, "strict_beta_norm", False) if strict is None else strict)

    ids = [int(getattr(a, "id", i)) for i, a in enumerate(agents)]

    def _Sshape(a):
        if which == "q":
            f = getattr(a, "mu_q_field", None)
        else:
            f = getattr(a, "mu_p_field", None)
        if f is None:
            # fallback to mask or sigma
            m = getattr(a, "mask", None)
            if m is not None:
                m = np.asarray(m)
                return m.shape[:-1] if (m.ndim >= 1 and m.shape[-1] == 1) else m.shape
            s = getattr(a, f"sigma_{which}_field", None)
            if s is not None:
                return np.asarray(s).shape[:-2]
            raise ValueError(f"Cannot infer base shape for agent id={getattr(a,'id',None)}")
        return np.asarray(f).shape[:-1]

    worst = 0.0
    total_pix = 0
    bad_pix = 0

    for i_idx, ai in enumerate(agents):
        i_id = ids[i_idx]
        Sshape = _Sshape(ai)

        betas = []
        masks = []
        for j_idx, aj in enumerate(agents):
            if i_idx == j_idx:
                continue
            j_id = ids[j_idx]
            # NOTE: your EdgeMaps.get_align requires shape kwarg
            beta_map, kl_map = ctx.edge.get_align(ctx, which, i_id, j_id, shape=Sshape)
            if beta_map is None:
                continue
            b = np.asarray(beta_map, np.float32)
            betas.append(b)
            masks.append(b > 0)

        if not betas:
            continue

        B = np.stack(betas, axis=0)                 # (Ns, *S)
        any_sender = np.any(np.stack(masks, 0), 0)  # (*S,)
        sumb = np.sum(B, 0, dtype=np.float32)

        dev = np.zeros_like(sumb, dtype=np.float32)
        dev[any_sender] = np.abs(sumb[any_sender] - 1.0)
        local_worst = float(np.nanmax(dev)) if np.any(any_sender) else 0.0
        worst = max(worst, local_worst)
        total_pix += int(dev.size)
        bad_pix   += int(np.sum(dev > tol))

    msg = {"beta_max_dev": worst, "beta_dev_count": bad_pix, "beta_checked": total_pix}
    if strict and worst > tol:
        raise AssertionError(f"[inv β] max deviation={worst:.3e} > tol={tol:.1e}")
    return msg




def inv_gamma_bounds(ctx, agents, *, tol=1e-6, strict=None):
    """
    Verify γ ∈ [0, 1+tol] on overlap, finiteness, and KL non-negativity where present.
    Compatible with EdgeMaps.get_gamma(..., shape=Sshape).
    """
    import numpy as np
    
    strict = bool(cfg_get(ctx, "strict_gamma_bounds", False) if strict is None else strict)
    ids = [int(getattr(a, "id", i)) for i, a in enumerate(agents)]
    id2agent = {int(getattr(a, "id", i)): a for i, a in enumerate(agents)}

    def _Sshape_for_agent(a):
        # Prefer q-μ; fallback to mask or p-Σ if needed
        f = getattr(a, "mu_q_field", None)
        if f is not None:
            return np.asarray(f).shape[:-1]
        m = getattr(a, "mask", None)
        if m is not None:
            m = np.asarray(m)
            return m.shape[:-1] if (m.ndim >= 1 and m.shape[-1] == 1) else m.shape
        s = getattr(a, "sigma_q_field", None)
        if s is not None:
            return np.asarray(s).shape[:-2]
        raise ValueError(f"Cannot infer base shape for agent id={getattr(a,'id',None)}")

    maxA = maxB = 0.0
    nonfinite_maps = 0
    negKL = 0
    checked = 0

    for i_idx, ai in enumerate(agents):
        i_id = ids[i_idx]
        for j_idx, aj in enumerate(agents):
            if i_idx == j_idx:
                continue
            j_id = ids[j_idx]

            # Case A: stored under ("A", j_id, i_id); receiver = i_id
            recvA = id2agent[i_id]
            SA = _Sshape_for_agent(recvA)
            gA, KA = ctx.edge.get_gamma(ctx, "A", j_id, i_id, shape=SA)
            if gA is not None:
                gA = np.asarray(gA, np.float32)
                if not np.all(np.isfinite(gA)):
                    nonfinite_maps += 1
                maxA = max(maxA, float(np.nanmax(gA)))
                if KA is not None:
                    kA = np.asarray(KA, np.float32)
                    negKL += int(np.sum(kA < -1e-6))
                checked += gA.size

            # Case B: stored under ("B", i_id, j_id); receiver = i_id
            recvB = id2agent[i_id]
            SB = _Sshape_for_agent(recvB)
            gB, KB = ctx.edge.get_gamma(ctx, "B", i_id, j_id, shape=SB)
            if gB is not None:
                gB = np.asarray(gB, np.float32)
                if not np.all(np.isfinite(gB)):
                    nonfinite_maps += 1
                maxB = max(maxB, float(np.nanmax(gB)))
                if KB is not None:
                    kB = np.asarray(KB, np.float32)
                    negKL += int(np.sum(kB < -1e-6))
                checked += gB.size

    if strict:
        if max(maxA, maxB) > 1.0 + tol:
            raise AssertionError(f"[inv γ] max γ={max(maxA,maxB):.3e} > 1+{tol:.1e}")
        if nonfinite_maps:
            raise AssertionError(f"[inv γ] non-finite γ maps: {nonfinite_maps}")
        if negKL:
            raise AssertionError(f"[inv γ] negative KL entries: {negKL}")

    return {
        "gamma_max": max(maxA, maxB),
        "gamma_nonfinite_maps": int(nonfinite_maps),
        "gamma_negKL": int(negKL),
        "gamma_checked": int(checked),
    }


def inv_sigma_spd(agents, *, eps=1e-8, strict=False, sample_stride=1):
    """
    Check Σ fields are symmetric and λ_min >= eps (sampled to keep this cheap).
    """
    worst = np.inf
    viol_count = 0
    checked = 0
    for a in agents:
        S = getattr(a, "sigma_q_field", None)
        if S is None:
            continue
        Sig = np.asarray(S, np.float64)
        # downsample (optional)
        if sample_stride > 1 and Sig.ndim >= 3:
            Sig = Sig[::sample_stride]
        # symmetry deviation
        sym_dev = np.max(np.abs(Sig - np.swapaxes(Sig, -1, -2)))
        if sym_dev > 1e-6:
            viol_count += 1
            worst = min(worst, -np.inf)
        # eigen min
        try:
            w = np.linalg.eigh(Sig.reshape(-1, Sig.shape[-2], Sig.shape[-1]))[0]
            minw = float(np.min(w))
            worst = min(worst, minw)
            if minw < eps:
                viol_count += 1
        except np.linalg.LinAlgError:
            viol_count += 1
            worst = -np.inf
        checked += int(np.prod(Sig.shape[:-2]))

    if strict and (viol_count > 0):
        raise AssertionError(f"[inv Σ] SPD violations: {viol_count}, worst λ_min={worst:.3e}")
    return {"sigma_spd_violations": viol_count, "sigma_lambda_min_worst": float(worst), "sigma_sites_checked": checked}


def inv_phi_cov_energy_sign(E_cov, *, strict=False):
    """
    Optional: assert covariant frame energy is non-negative.
    """
    if strict and E_cov < -1e-6:
        raise AssertionError(f"[inv φ-cov] Energy negative: {E_cov:.6e}")
    return {"phi_cov_energy": float(E_cov)}






def _sum_beta_KL_from_ctx(ctx, which: str) -> float:
    total = 0.0
    # walk all keys in the unified store for this fiber
    for (w, i_id, j_id), B in (getattr(ctx.edge, "beta", {}) or {}).items():
        if str(w) != which: 
            continue
        # shape-safe fetch (guarantees zeros if missing)
        beta_ij, kl_ij = ctx.edge.get_align(ctx, which, i_id, j_id, shape=np.asarray(B).shape)
        b = np.asarray(beta_ij, np.float32)
        k = np.asarray(kl_ij,   np.float32)
        total += float((b * k).sum())
    return float(total)



def _sum_gamma_KL_from_ctx(ctx, which_case: str, *, kappa: float | None = None, corrected: bool = False) -> float:
    if corrected and (kappa is None):
        # A uses q’s κ, B uses p’s κ (same behavior as before)
        from runtime_context import cfg_get
        kappa = float(cfg_get(ctx, "kappa_gamma_q" if which_case == "A" else "kappa_gamma_p", 1.0))
    kap = max(float(kappa) if kappa is not None else 1.0, 1e-12)

    tot = 0.0
    for (case, a_id, b_id), G in (getattr(ctx.edge, "gamma", {}) or {}).items():
        if str(case) != which_case:
            continue
        # use the stored gamma’s shape for a shape-safe read
        g, k = ctx.edge.get_gamma(ctx, which_case, a_id, b_id, shape=np.asarray(G).shape)
        gg = np.asarray(g, np.float32)
        kk = np.asarray(k, np.float32)
        if corrected:
            tot += float((gg * (kk - 0.5 * (kk * kk) / kap)).sum())
        else:
            tot += float((gg * kk).sum())
    return float(tot)



def total_energy(ctx, agents, *, return_breakdown=False, precomputed_metrics=None):
    M = precomputed_metrics if precomputed_metrics is not None else compute_global_metrics(ctx, agents)
    E = float(M.get("E_total", 0.0))
    if not return_breakdown:
        return E

    breakdown = {
        "self":       float(M.get("self_sum_w",     M.get("self_sum", 0.0))),
        "feedback":   float(M.get("feedback_sum_w", M.get("feedback_sum", 0.0))),
        "align_q":    float(M.get("align_q_sum_w",  M.get("align_q_sum",  0.0))),
        "align_p":    float(M.get("align_p_sum_w",  M.get("align_p_sum",  0.0))),
        
        "gamma_A":    float(M.get("gamma_A_sum_w",  M.get("gamma_A_sum",  0.0))),
        "gamma_B":    float(M.get("gamma_B_sum_w",  M.get("gamma_B_sum",  0.0))),
        "mean_total": float(M.get("mean_total",     0.0)),
    }

    return E, breakdown



def print_action_breakdown(ctx, action_dict, *, stream=None):
    step = int(getattr(ctx, "global_step", -1))
    lines = []
    lines.append(f"[Action @ step {step}]")
    lines.append(f"  Action_total = {action_dict.get('Action_total', 0.0):.6e}")
    lines.append("  ---------------------------------------")
    lines.append(f"  Geom_total   = {action_dict.get('Geom_total', 0.0):.6e}")
   
    lines.append(f"  A_curv       = {action_dict.get('A_curv', 0.0):.6e}  ")
    lines.append(f"  A_cov        = {action_dict.get('A_cov', 0.0):.6e}")
   
    print("\n".join(lines), flush=True)


def print_energy_breakdown(ctx, metrics, *, hide_zero_weight=True):
       
    rows = [
        ("self(α)",      metrics.get("self_sum_w", 0.0),      metrics.get("self_mean", 0.0),      1.0),
        ("align_q(β)",   metrics.get("align_q_sum_w", 0.0),   metrics.get("align_q_mean", 0.0),   1.0),
        ("align_p(β)",   metrics.get("align_p_sum_w", 0.0),   metrics.get("align_p_mean", 0.0),   1.0),
        ("feedback(λ)",  metrics.get("feedback_sum_w", 0.0),  metrics.get("feedback_mean", 0.0),  1.0),
        # NEW
        ("gamma_A",      metrics.get("gamma_A_sum_w", 0.0),   metrics.get("gamma_A_mean", 0.0),   1.0),
        ("gamma_B",      metrics.get("gamma_B_sum_w", 0.0),   metrics.get("gamma_B_mean", 0.0),   1.0),
    ]


    print("\n[Energy Totals @ step {}]".format(int(getattr(ctx, "global_step", -1))))
    print("  E_total = {: .6e}  |  mean_total = {: .6e}".format(
        float(metrics.get("E_total", 0.0)),
        float(metrics.get("mean_total", 0.0)),
    ))
    print("  " + "-"*60)
    print("  {:<14} {:>14} {:>18} {:>8}   {:>14}".format(
        "term", "contrib_sum", "mean_per_px", "weight", "contrib_sum"))
    for name, contrib, mean_px, w in rows:
        if hide_zero_weight and (w == 0.0):
            continue
        print("  {:<14} {:>14.6e} {:>18.6e} {:>8g}   {:>14.6e}".format(
            name, float(contrib), float(mean_px), w, float(contrib)
        ))

    # Optional diagnostics: show *raw* ungated alignments (not used in action)
    aq_raw = float(metrics.get("align_q_sum_raw", 0.0))
    ap_raw = float(metrics.get("align_p_sum_raw", 0.0))
    if abs(aq_raw) + abs(ap_raw) > 0:
        print("  (diagnostic, not in action) align_q_raw = {: .6e} | align_p_raw = {: .6e}".format(aq_raw, ap_raw))
    print()





def compute_agent_metrics(ctx: Any, agent: Any) -> Dict[str, float]:
    """
    Returns per-agent RAW (unweighted) energy components.
    Keeps self/feedback unweighted to match alignment’s convention.
    """
    cfg = getattr(ctx, "step_cfg", None)
    tau = float(getattr(cfg, "support_tau", 1e-6)) if cfg is not None else 1e-6

    m = mask_hw(getattr(agent, "mask", None), tau=tau, mode="bool2")
    if m is None or not np.any(m):
        return {
            "self_sum": 0.0, "self_mean": 0.0,
            "feedback_sum": 0.0, "feedback_mean": 0.0,
        }

    S = int(np.count_nonzero(m)) or 1
    aid = int(getattr(agent, "id", -1))

    ea = getattr(ctx, "energy_acc", {}) or {}
    # read directly from the dict populated by the master reducer
    self_sum = float(ea.get(f"self_sum[{aid}]", 0.0))
    fb_sum   = float(ea.get(f"feedback_sum[{aid}]", 0.0))

    return {
        "self_sum":     self_sum,
        "self_mean":    self_sum / S,
        "feedback_sum": fb_sum,
        "feedback_mean": fb_sum / S,
    }




def compute_global_metrics(ctx, agents):
    

    cfg     = getattr(ctx, "step_cfg", None)
    tau     = cfg.support_tau
    n_jobs  = int(getattr(cfg, "metrics_n_jobs", 1))

    # Weights & options used in both grads and energy
    alpha   = float(getattr(cfg, "alpha", 0.0))
    lambd   = float(getattr(cfg, "feedback_weight", 0.0))

    def _one(a):
        m = mask_hw(a.mask, tau=tau, mode="bool2")
        S = int(np.count_nonzero(m))
        if S <= 0:
            return None
        d = compute_agent_metrics(ctx, a)  # RAW component pieces (self/feedback/mass/curv)
        return d, S

    with threadpool_limits(1):
        outs = Parallel(n_jobs=max(1, n_jobs), backend="threading", batch_size="auto")(
            delayed(_one)(a) for a in agents
        )

    totals = {"self_sum":0.0,"feedback_sum":0.0,"_S":0}

    for res in outs:
        if res is None:
            continue
        d, S = res
        for k in ("self_sum","feedback_sum"):
            totals[k] += float(d[k])
        totals["_S"] += int(S)

    S_tot = max(totals["_S"], 1)

    # Means (diagnostic)
    out = dict(totals)
    out["self_mean"]     = out["self_sum"]     / S_tot
    out["feedback_mean"] = out["feedback_sum"] / S_tot
   

    # === Alignment: use β-weighted sums (variational) ===
    align_q_sum_beta = _sum_beta_KL_from_ctx(ctx, "q")
    align_p_sum_beta = _sum_beta_KL_from_ctx(ctx, "p")

    # Store the β-weighted alignment as the canonical alignment energy
    out["align_q_sum"]  = align_q_sum_beta
    out["align_p_sum"]  = align_p_sum_beta
    out["align_q_mean"] = align_q_sum_beta / S_tot
    out["align_p_mean"] = align_p_sum_beta / S_tot

    # === Build weighted contributions actually used in the action ===
    self_w     = alpha * out["self_sum"]
    feedback_w = lambd * out["feedback_sum"]
    align_q_w  = out["align_q_sum"]    # β already included
    align_p_w  = out["align_p_sum"]    # β already included
    

    # existing weighted pieces:
    out["E_total"] = float(
        self_w + feedback_w +
        align_q_w + align_p_w
    )
    
    # NEW: gamma contributions (already weighted by gamma in the product)
    gamma_A_sum = _sum_gamma_KL_from_ctx(ctx, "A", corrected=True)  # κ inferred from cfg
    gamma_B_sum = _sum_gamma_KL_from_ctx(ctx, "B", corrected=True)
    out["gamma_A_sum"] = float(gamma_A_sum)
    out["gamma_B_sum"] = float(gamma_B_sum)
    
    # include γ-terms in the action energy:
    out["E_total"] = float(out["E_total"] + gamma_A_sum + gamma_B_sum)
    
    # means (per active pixel); these are diagnostic means, not extra weights
    S_tot = float(out.get("active_pixels", 0.0) or 1.0)
    out["gamma_A_mean"] = float(gamma_A_sum / S_tot)
    out["gamma_B_mean"] = float(gamma_B_sum / S_tot)
    
    # expose “weighted” pieces for breakdown (γ already applied, so just pass through)
    out.update({
        "self_sum_w": self_w, "feedback_sum_w": feedback_w,
        "align_q_sum_w": align_q_w, "align_p_sum_w": align_p_w,
        "gamma_A_sum_w": float(gamma_A_sum), "gamma_B_sum_w": float(gamma_B_sum),
    })


    # (Optional) keep raw ungated alignment sums ONLY as clearly-labeled diagnostics
    # NOTE: not used in E_total; shown only if you explicitly print them
    out["align_q_sum_raw"] = float(getattr(ctx, "energy_acc", {}).get("align_q_sum", 0.0))
    out["align_p_sum_raw"] = float(getattr(ctx, "energy_acc", {}).get("align_p_sum", 0.0))

    return out


def compute_total_action(ctx, agents, precomputed_metrics=None):
    
    # 1) Geometric piece
    M_geom = precomputed_metrics if (precomputed_metrics is not None) \
             else compute_global_metrics(ctx, agents)
    A_geom = float(M_geom.get("E_total", 0.0))

    
    # 4) A terms (unchanged)
    fields = getattr(ctx, "fields", {}) or {}
    A_cov = float(fields.get("A_cov_energy_last", 0.0))
    A_curv = float(fields.get("A_curv_energy", 0.0))
    A_tot = float(A_geom + A_curv + A_cov )

    return {
        "Action_total": A_tot,
        "Geom_total":   A_geom,
        "A_curv":       A_curv,
        "A_cov":        A_cov,
        "self_sum":     float(M_geom.get("self_sum", 0.0)),
        "feedback_sum": float(M_geom.get("feedback_sum", 0.0)),
        "align_q_sum":  float(M_geom.get("align_q_sum", 0.0)),
        "align_p_sum":  float(M_geom.get("align_p_sum", 0.0)),
        # NEW:
        "gamma_A_sum":  float(M_geom.get("gamma_A_sum", 0.0)),
        "gamma_B_sum":  float(M_geom.get("gamma_B_sum", 0.0)),
    }





def summarize_beta_fiber(ctx, agents, *, which: str = "q") -> dict:
    """
    Collect β and KL stats for a fiber ('q' or 'p') using the unified EdgeMaps API only.
    Reads via ctx.edge.get_align(...). No direct access to ctx._edge_*.
    Also checks per-pixel softmax consistency for each receiver.

    Returns a dict with summary stats and a small per-receiver softmax report.
    """
    import numpy as np

    if which not in ("q", "p"):
        raise ValueError(f"which must be 'q' or 'p', got {which!r}")

    # Resolve kappa/mode (kept only for reporting)
    cfg = getattr(ctx, "beta_cfg", {}) or {}
    sub = cfg.get(which, cfg)
    mode   = str(sub.get("mode", "")).lower()
    kappa  = float(sub.get("kappa", 1.0))
    detach = bool(sub.get("detach", True))

    # id map
    ids = [int(getattr(a, "id", i)) for i, a in enumerate(agents)]
    id2agent = {ids[i]: a for i, a in enumerate(agents)}

    beta_vals = []
    kl_vals   = []
    per_recv_softmax_err = {}

    for i_id, ai in id2agent.items():
        # use q shape for both fibers; p has same spatial shape
        Sshape = np.asarray(getattr(ai, "mu_q_field")).shape[:-1]
        sender_arrays = []
        for j_id, aj in id2agent.items():
            if i_id == j_id:
                continue
            B_ij, K_ij = ctx.edge.get_align(ctx, which, i_id, j_id, shape=Sshape)
            if B_ij is None:
                continue
            b = np.asarray(B_ij, np.float64)
            sender_arrays.append(b)
            beta_vals.append(b)
            if K_ij is not None:
                kl_vals.append(np.asarray(K_ij, np.float64))

        if sender_arrays:
            B = np.stack(sender_arrays, axis=0)            # (Ns, *S)
            any_sender = np.any(B > 0, axis=0)             # (*S,)
            tot = np.sum(B, axis=0)                        # (*S,)
            err = np.abs(tot - 1.0) * any_sender
            per_recv_softmax_err[int(i_id)] = {
                "max_abs_err": float(np.nanmax(err)) if np.any(any_sender) else 0.0,
                "mean_abs_err": float(np.nanmean(err[any_sender])) if np.any(any_sender) else 0.0,
                "frac_viol>1e-3": float(np.mean((err > 1e-3)[any_sender])) if np.any(any_sender) else 0.0,
            }

    if not beta_vals:
        raise RuntimeError(f"[β/{which}] no β maps available via ctx.edge.get_align")

    beta_flat = np.concatenate([v.ravel() for v in beta_vals])
    kl_flat   = np.concatenate([v.ravel() for v in kl_vals]) if kl_vals else np.zeros(1, np.float64)

    return {
        "which": which, "mode": mode, "kappa": kappa, "detach": detach,
        "beta_min": float(np.nanmin(beta_flat)),
        "beta_mean": float(np.nanmean(beta_flat)),
        "beta_max": float(np.nanmax(beta_flat)),
        "kl_min": float(np.nanmin(kl_flat)),
        "kl_med": float(np.nanmedian(kl_flat)),
        "kl_mean": float(np.nanmean(kl_flat)),
        "kl_max": float(np.nanmax(kl_flat)),
        "softmax": per_recv_softmax_err,
    }



def print_beta_summary(ctx, agents):
    q = summarize_beta_fiber(ctx, agents, which="q")
    p = summarize_beta_fiber(ctx, agents, which="p")
    step = int(getattr(ctx, "global_step", -1))

    def _fmt(f):
        return (
            f"\n[β/{f['which']} | step {step}] "
            f"mode={f['mode']} κ={f['kappa']:.3g} detach={f['detach']} "
            f"| edges={f['edges']} recv={f['recv']}\n"
            f"β[min/mean/max] = {f['beta_min']:.3g} / {f['beta_mean']:.3g} / {f['beta_max']:.3g}\n"
            f"KL[min/med/mean/max] = {f['kl_min']:.3g} / {f['kl_med']:.3g} / "
            f"{f['kl_mean']:.3g} / {f['kl_max']:.3g}\n"
        )

    print(_fmt(q))
    print(_fmt(p))

    # Softmax consistency (use the precomputed worst from summarize_beta_fiber)
    for f in (q, p):
        if f["mode"] not in ("softmax", "sm", "normexp"):
            continue
        worst_dev  = float(f.get("softmax_worst_dev", 0.0))
        worst_recv = f.get("softmax_worst_recv", None)
        if worst_dev > 1e-3:
            raise RuntimeError(
                f"[β/{f['which']}] worst softmax deviation {worst_dev:.3e} "
                f"at receiver i={worst_recv}"
            )




