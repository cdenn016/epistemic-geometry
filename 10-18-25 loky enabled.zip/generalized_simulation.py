# generalized_simulation.py
import os
os.environ["OMP_NUM_THREADS"] = "1"
os.environ["MKL_NUM_THREADS"] = "1"
os.environ["NUMEXPR_NUM_THREADS"] = "1"
os.environ["OPENBLAS_NUM_THREADS"] = "1"
import sys
ROOT = os.path.dirname(os.path.abspath(__file__))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

from pathlib import Path
import sys, shutil, multiprocessing as _mp, numpy as np
import core.config as config
from updates.update_rules import synchronous_step
from updates.update_terms_curvature_A import ensure_global_A
from diagnostics import compute_total_action, print_action_breakdown, compute_global_metrics
from metrics_viz import VizConfig, MetricsViz

from core.get_generators import casimir_scalar
from runtime_context import ensure_runtime_defaults, build_step_settings_from_overrides, cfg_get 
from utils import ( mean_norm, _aid, prepare_generators, initialize_or_resume,
    log_and_viz_after_step, wrap_epilogue, save_step )

from shared_cache import SharedDiskCache




def attach_shared_cache(ctx):
    cache_dir = ctx.config.get("shared_cache_dir", "./_shared_cache")
    ctx.cache = SharedDiskCache(cache_dir)
    return ctx


def post_step_io(
    runtime_ctx,
    agents,
    metrics,           # precomputed from run_one_step
    action,            # precomputed from run_one_step
    step: int,
    outdir: str,
    mv,                # MetricsViz instance
    parent_metrics: list,
    metric_log: list,
):
    """
    All step side effects in one place:
      - print breakdown
      - run existing log/viz helper
      - log global & per-agent rows
      - flush/plot/snapshot
      - save checkpoint

    Pure consumers: relies ONLY on inputs; no recomputation of metrics/action.
    """
    
    # 1) console output
    print_action_breakdown(runtime_ctx, action)

    # 2) reuse your consolidated logger/plotter (keeps previous behavior)
    log_and_viz_after_step(
        runtime_ctx, agents, step, outdir,
        parent_metrics, metric_log,
        getattr(runtime_ctx, "config", {}).get("n_jobs", 1),
        precomputed_metrics=metrics,
        precomputed_Q=action,
    )

    # 3) global row (reuse precomputed values)
    E_tot = action.get("Action_total", np.nan)
    gmetrics = {
        "E_total": float(E_tot) if np.isfinite(E_tot) else np.nan,
        "mean_total": float(metrics.get("mean_total", np.nan)),
        **action,  # includes Geom_total, A_curv, A_cov, align*, gamma*, etc.
    }
    mv.log_global(step, gmetrics)

    # 4) per-agent rows (cheap norms; robust to missing fields)
    for a in agents:
        mv.log_agent(step, _aid(a), {
            "phi_norm_mean":       mean_norm(getattr(a, "phi", None)),
            "phi_model_norm_mean": mean_norm(getattr(a, "phi_model", None)),
            "mu_q_norm_mean":      mean_norm(getattr(a, "mu_q_field", None)),
            "mu_p_norm_mean":      mean_norm(getattr(a, "mu_p_field", None)),
        })

    # 5) plots + snapshots (cadence inside MetricsViz)
    mv.maybe_flush(step)
    mv.maybe_plot(step)
    mv.maybe_snapshot(step, runtime_ctx, agents)

    # 6) checkpoint
    save_step(agents, outdir, step)


def run_one_step(runtime_ctx, agents, G_q, G_p, n_jobs=1):
    """
    Perform ONE pure simulation step:
      - refresh per-step settings from config + runtime overrides
      - attach a shared, disk-backed cache (memmapped) usable by loky workers
      - run synchronous child update (parallel if n_jobs > 1)
      - compute per-step metrics and action
    """
    from runtime_context import (
        ensure_runtime_defaults,
        ensure_shared_cache_attached,   # keep this
    )
 

    # Ensure defaults and step cfg
    runtime_ctx = ensure_runtime_defaults(runtime_ctx)
    runtime_ctx.step_cfg = build_step_settings_from_overrides(
        config, getattr(runtime_ctx, "config", {}) or {}
    )

    # Shared disk cache + loky-friendly defaults
    runtime_ctx.config.setdefault("shared_cache_dir", "./_shared_cache")
    runtime_ctx.config.setdefault("transport_backend", "ctx")
    runtime_ctx.config.setdefault("transport_validation", False)
    runtime_ctx.config.setdefault("joblib_prefer", "processes")
    runtime_ctx.config.setdefault("blas_threads_per_worker", 1)
    runtime_ctx.config.setdefault("n_jobs", int(n_jobs))

    # Attach the SharedDiskCache in the master process
    ensure_shared_cache_attached(runtime_ctx)

    # Per-step resets (pure, in-memory)
    runtime_ctx.timings = {}
    runtime_ctx.energy_acc = {}   # << fresh per-step accumulator dict (master-only)

    # Run updates. Parallel section writes results; master reducer fills energy_acc.
    agents = synchronous_step(
        agents, G_q, G_p,
        n_jobs=int(runtime_ctx.config["n_jobs"]),
        runtime_ctx=runtime_ctx,
    )
    runtime_ctx.children_latest = agents

    # Metrics & action (these read from runtime_ctx.energy_acc populated above)
    metrics = compute_global_metrics(runtime_ctx, agents)
    action  = compute_total_action(runtime_ctx, agents, precomputed_metrics=metrics)
    return agents, metrics, action



def run_simulation(
    outdir="checkpoints",
    resume=False,
    log_metrics=True,
    log_fields=True,
    num_cores=None,
    fresh_outdir=False,
    clear_agent_logs=True,
    runtime_ctx=None,
):
    

    # ---------- cores ----------
    _avail = max(1, (_mp.cpu_count() or 1) - 1)
    num_cores = max(1, _avail if num_cores is None else int(num_cores))

    # ---------- runtime ctx ----------
    runtime_ctx = ensure_runtime_defaults(runtime_ctx)

    # Seed ctx.config from module config once, then layer runtime entries
    base_cfg = {k: getattr(config, k) for k in dir(config) if not k.startswith("_")}
    rcfg = dict(base_cfg)
    rcfg["n_jobs"] = num_cores
    runtime_ctx.config = rcfg

    # ---------- generators (ctx-driven) ----------
    G_q, G_p = prepare_generators(runtime_ctx)
    Kq, Kp = int(np.asarray(G_q).shape[1]), int(np.asarray(G_p).shape[1])

    # ---------- init or resume ----------
    if fresh_outdir and not resume and os.path.isdir(outdir):
        shutil.rmtree(outdir, ignore_errors=True)
    os.makedirs(outdir, exist_ok=True)

    agents, step_start = initialize_or_resume(
        outdir, resume, runtime_ctx, clear_agent_logs=clear_agent_logs
    )

    # ---------- runtime ctx bootstrapping ----------
    runtime_ctx.global_step = step_start
    runtime_ctx.children_latest = agents

    vizcfg = VizConfig(
        outdir=Path(outdir),
        run_name="runs",
        legend_label=f"l_q={cfg_get(runtime_ctx, 'ell_q', 3)}",
        plot_every_steps=1,
        snapshot_every_steps=99,
    )

    mv = MetricsViz(vizcfg)
    meta_generators = {
        "Kq": Kq, "Kp": Kp,
        "casimir_total_q": casimir_scalar(G_q),
        "casimir_total_p": casimir_scalar(G_p),
    }
    mv.start_run(meta=meta_generators)
    runtime_ctx.viz = mv

    # ---------- global A (M-D) ----------
    S_agents = agents[0].spatial_shape
    A_init_scale = cfg_get(runtime_ctx, "A_init_scale", getattr(config, "A_init_scale", 0.0))
    ensure_global_A(runtime_ctx, spatial_shape=S_agents, init_scale=A_init_scale, smooth_sigma=2.0)

    # ---------- step range ----------
    total_steps = int(cfg_get(runtime_ctx, "steps", getattr(config, "steps", 0)))
    if step_start >= total_steps:
        wrap_epilogue(runtime_ctx, agents, outdir, [], [])
        print("[DONE] Nothing to do: resume step >= total steps.")
        return agents, []

    # ---------- loop ----------
    parent_metrics, metric_log = [], []
    print(f"[RUN] Starting simulation at step {step_start} with {num_cores} cores")

    for step in range(step_start, total_steps):
        runtime_ctx.global_step = step
        print(f"\n[STEP {step}] -----------------------------\n")

        agents, M_geom, Q = run_one_step(runtime_ctx, agents, G_q, G_p, n_jobs=num_cores)
        post_step_io(runtime_ctx, agents, M_geom, Q, step, outdir, mv, parent_metrics, metric_log)

    # ---------- epilogue ----------
    wrap_epilogue(runtime_ctx, agents, outdir, parent_metrics, metric_log)
    mv.end_run()

    print("[DONE] Simulation completed.")
    return agents, metric_log





if __name__ == "__main__":
    
    run_simulation()



