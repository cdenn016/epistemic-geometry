# -*- coding: utf-8 -*-
"""
generalized_math_utils.py — Core math utilities for φ updates, KL divergence, and field ops.
"""

import numpy as np
from scipy.ndimage import laplace

import config
from numerical_utils import sanitize_sigma, safe_inv, safe_logdet


def unpack_phi_update_params(params, field="phi"):
    """
    Extracts φ or φ̃ update parameters from params or config.

    Parameters:
        params: dict containing possible overrides
        field:  'phi' or 'phi_model'

    Returns:
        dict with keys: gw, κ, curv_weight, grad_clip_threshold, overlap_eps, debug
    """
    prefix = "phi_model" if field == "phi_model" else "phi"
    return dict(
        gw=params.get(f"{field}_mass_weight", getattr(config, f"{prefix}_mass_weight", config.gauge_weight)),
        κ=params.get("phi_phi_tilde_coupling", config.phi_phi_tilde_coupling),
        curv_weight=params.get(f"{field}_curvature_weight", getattr(config, f"{prefix}_curvature_weight", config.curvature_weight)),
        grad_clip_threshold=params.get(f"{field}_grad_clip_threshold", getattr(config, f"{prefix}_grad_clip_threshold", config.phi_grad_clip_threshold)),
        overlap_eps=params.get("support_cutoff_eps", config.support_cutoff_eps),
        debug=params.get("debug", getattr(config, "debug_gradients", False)),
    )


def apply_regularization_terms(
    grad,
    phi,
    phi_tilde=None,
    Gs=None,
    soft_mask=None,
    *,
    gw=0.0,
    κ=0.0,
    curv_weight=0.0,
    curvature_fn=None,
):
    """
    Applies regularization terms (mass, φ−φ̃ coupling, curvature) to a gradient.

    Parameters:
        grad:         ndarray (..., d)
        phi:          ndarray (..., d)
        phi_tilde:    optional ndarray (..., d)
        Gs:           Lie algebra basis, optional
        soft_mask:    optional mask (..., 1)
        gw:           φ mass coupling
        κ:            φ−φ̃ coupling
        curv_weight:  curvature coupling
        curvature_fn: function: curvature_fn(phi, Gs) → (..., d)

    Returns:
        updated grad with regularization terms added
    """
    if soft_mask is None:
        soft_mask = 1.0

    if gw > 0:
        grad += 2 * gw * phi * soft_mask
    if κ > 0 and phi_tilde is not None:
        grad += 2 * κ * (phi - phi_tilde) * soft_mask
    if curv_weight > 0 and curvature_fn is not None and Gs is not None:
        try:
            curv_term = curvature_fn(phi, Gs)
            grad += curv_weight * curv_term * soft_mask
        except Exception as e:
            if config.debug:
                print(f"[WARN] curvature_fn failed: {e}")
    return grad


def kl_divergence(mu1, sigma1, mu2, sigma2, log_eps=1e-6):
    """
    Batched KL[𝒩(μ₁, Σ₁) || 𝒩(μ₂, Σ₂)] for full MVG fields.

    Parameters:
        mu1:    (N, K)
        sigma1: (N, K, K)
        mu2:    (N, K)
        sigma2: (N, K, K)
        log_eps: float, stability epsilon for inverses/logdet

    Returns:
        kl_vals: (N,) KL divergence values
    """
    mu1 = np.asarray(mu1)
    mu2 = np.asarray(mu2)
    sigma1 = np.asarray(sigma1)
    sigma2 = np.asarray(sigma2)

    assert mu1.shape == mu2.shape
    assert sigma1.shape == sigma2.shape
    N, K = mu1.shape

    sigma1 = sanitize_sigma(sigma1, eps=log_eps)
    sigma2 = sanitize_sigma(sigma2, eps=log_eps)

    try:
        sigma2_inv = np.array([safe_inv(S, eps=log_eps) for S in sigma2])
        logdet1 = np.array([safe_logdet(S, eps=log_eps) for S in sigma1])
        logdet2 = np.array([safe_logdet(S, eps=log_eps) for S in sigma2])
    except Exception as e:
        raise RuntimeError(f"[KL Divergence] Sigma inversion/logdet failed: {e}")

    # Tr[Σ₂⁻¹ Σ₁]
    trace_term = np.einsum("nij,njk->nik", sigma2_inv, sigma1)
    trace_term = np.trace(trace_term, axis1=-2, axis2=-1)

    # (μ₂ − μ₁)^T Σ₂⁻¹ (μ₂ − μ₁)
    diff = mu2 - mu1
    mahal = np.einsum("ni,nij,nj->n", diff, sigma2_inv, diff)

    kl = 0.5 * (trace_term + mahal - K + logdet2 - logdet1)
    return kl


def laplacian_field(field):
    """
    Computes componentwise Laplacian of a field over its last axis.

    Parameters:
        field: ndarray (..., K)

    Returns:
        Laplacian of shape (..., K)
    """
    if field.ndim < 2:
        raise ValueError("laplacian_field expects at least 2D array (..., K)")
    return np.stack([laplace(field[..., i]) for i in range(field.shape[-1])], axis=-1)
