# -*- coding: utf-8 -*-
"""
Created on Sat Jul 12 16:20:33 2025

@author: chris and christine
"""
# phi_update_terms.py

from natural_gradient_utils import apply_lie_natural_gradient
from generalized_math_utils import unpack_phi_update_params, apply_regularization_terms
from generalized_omega import compute_curvature_gradient_analytical
from get_generators import get_generators
from numerical_utils import check_matrix_validity
import numpy as np
import config
from natural_gradient_utils import (
            apply_natural_gradient_batch, 
            compute_fisher_geometry_gradient, 
            sanitize_sigma,
            compute_inverse_fisher_field
            )

from generalized_math_utils import (
    laplacian_field,
   )

from mask_utils import clip_and_mask_gradient



def compute_local_phi_metric(agent, field="phi"):
    """
    Compute approximate Fisher metric G^{ab} = Tr[G^a Σ⁻¹ G^b Σ⁻¹]
    over the agent's support, projected to the Lie algebra basis.

    Returns:
        G_inv: (d, d) inverse Fisher metric over the Lie algebra
    """
    eps = getattr(config, "eps", 1e-8)
    support_eps = getattr(config, "support_cutoff_eps", 1e-4)
    K = agent.mu_q_field.shape[-1]
    d = config.lie_dim
    mask = agent.mask > support_eps

    sigma_field = agent.sigma_q_field if field == "phi" else agent.sigma_p_field
    if not np.any(mask):
        return np.eye(d)

    # Average Σ over support
    sigma_subset = sigma_field[mask]  # (N, K, K)
    sigma_avg = np.mean(sigma_subset, axis=0)
    sigma_avg = 0.5 * (sigma_avg + sigma_avg.T)

    # Safe inverse of Σ_avg
    try:
        sigma_inv = np.linalg.inv(sigma_avg + eps * np.eye(K))
    except np.linalg.LinAlgError:
        if config.debug:
            print("[WARN] compute_local_phi_metric: Σ_avg not invertible, using I")
        sigma_inv = np.eye(K)

    # Pull back Fisher metric to Lie algebra using basis {G_a}
    Gs = get_generators(config.group_name, K)
    G_phi = np.zeros((d, d))
    for a in range(d):
        for b in range(d):
            G_a = Gs[a]
            G_b = Gs[b]
            G_phi[a, b] = np.trace(sigma_inv @ G_a @ sigma_inv @ G_b)

    G_phi = 0.5 * (G_phi + G_phi.T)

    # Safe inverse of projected metric
    try:
        G_inv = np.linalg.inv(G_phi + eps * np.eye(d))
    except np.linalg.LinAlgError:
        if config.debug:
            print("[WARN] compute_local_phi_metric: G^ab not invertible, using I")
        G_inv = np.eye(d)

    return G_inv



def zero_mu_sigma_like(agent_i, field="model"):
    mu_attr = f"mu_{'p' if field == 'model' else 'q'}_field"
    sigma_attr = f"sigma_{'p' if field == 'model' else 'q'}_field"
    return np.zeros_like(getattr(agent_i, mu_attr)), np.zeros_like(getattr(agent_i, sigma_attr))

def compute_mu_sigma_diff(mu_a, sigma_a, mu_b, sigma_b, direction="a_minus_b"):
    if direction == "a_minus_b":
        d_mu = mu_a - mu_b
        d_sigma = 0.5 * (sigma_a - sigma_b)
    elif direction == "b_minus_a":
        d_mu = mu_b - mu_a
        d_sigma = 0.5 * (sigma_b - sigma_a)
    else:
        raise ValueError(f"Unknown direction: {direction}")
    return d_mu, d_sigma

def apply_mask_to_mu_sigma(mu, sigma, mask):
    mu = np.where(mask[..., None], mu, 0)
    sigma = np.where(mask[..., None, None], sigma, 0)
    return mu, sigma


# --- Individual Gradient Terms ---

def grad_self_field(agent_i, alpha, field_type="model", mask=None):
    """
    Gradient of KL(q || p) or KL(p || q), depending on field_type.
    Computes natural gradient ∇_μ, ∇_Σ for the chosen self field.

    Args:
        agent_i   : Agent object with belief/model fields
        alpha     : Scalar weight on self-consistency
        field_type: "model" for KL(p || q), "belief" for KL(q || p)
        mask      : Optional spatial mask

    Returns:
        (Δμ, ΔΣ) : Fisher-natural gradient of the self-alignment term
    """
    if alpha <= 0:
        return zero_mu_sigma_like(agent_i)

    if field_type == "model":
        μ_self, Σ_self = agent_i.mu_p_field, agent_i.sigma_p_field
        μ_other, Σ_other = agent_i.mu_q_field, agent_i.sigma_q_field
    elif field_type == "belief":
        μ_self, Σ_self = agent_i.mu_q_field, agent_i.sigma_q_field
        μ_other, Σ_other = agent_i.mu_p_field, agent_i.sigma_p_field
    else:
        raise ValueError(f"[grad_self_field] Unknown field_type: {field_type}")

    # Optional SPD sanitization of Σ_other (used in KL)
    if config.sanitize_sigma_before_kl:
        Σ_other = sanitize_sigma(Σ_other, eps=config.eps)

    # Direction: ∇ KL(self || other)
    dμ, dΣ = compute_mu_sigma_diff(μ_self, Σ_self, μ_other, Σ_other, direction="a_minus_b")

    # Remove NaNs/infs if any
    dμ = np.nan_to_num(dμ)
    dΣ = np.nan_to_num(dΣ)

    Δμ_nat, ΔΣ_nat = apply_natural_gradient_batch(μ_self, Σ_self, dμ, dΣ)

    # Optional masking
    if mask is not None:
        Δμ_nat, ΔΣ_nat = apply_mask_to_mu_sigma(Δμ_nat, ΔΣ_nat, mask)

    return alpha * Δμ_nat, alpha * ΔΣ_nat


def grad_feedback_field(agent_i, feedback_weight, field_type="model", mask=None):
    """
    Raw Euclidean gradient of KL(other || self), i.e. ∇_self KL(p || q).
    Preconditioning (natural gradient) should be applied centrally.
    """
    if feedback_weight <= 0:
        return zero_mu_sigma_like(agent_i, field=field_type)

    if field_type == "model":
        μ_self, Σ_self = agent_i.mu_p_field, agent_i.sigma_p_field
        μ_other, Σ_other = agent_i.mu_q_field, agent_i.sigma_q_field
    elif field_type == "belief":
        μ_self, Σ_self = agent_i.mu_q_field, agent_i.sigma_q_field
        μ_other, Σ_other = agent_i.mu_p_field, agent_i.sigma_p_field
    else:
        raise ValueError(f"[grad_feedback_field] Unknown field_type: {field_type}")

    Σ_self  = sanitize_sigma(Σ_self, eps=config.eps)
    Σ_other = sanitize_sigma(Σ_other, eps=config.eps)

    dμ, dΣ = compute_mu_sigma_diff(μ_self, Σ_self, μ_other, Σ_other, direction="b_minus_a")

    if mask is not None:
        dμ, dΣ = apply_mask_to_mu_sigma(dμ, dΣ, mask)

    return feedback_weight * dμ, feedback_weight * dΣ





def grad_variance_penalty_trace(agent_i, weight, field_type="model", mask=None):
    """
    Adds a variance regularization term: ∇ Tr[Σ]

    Returns (Δμ, ΔΣ), where Δμ = 0 and ΔΣ = weight * Σ
    """
    if weight <= 0:
        return zero_mu_sigma_like(agent_i, field=field_type)

    if field_type == "model":
        sigma = weight * agent_i.sigma_p_field
        mu    = agent_i.mu_p_field
    elif field_type == "belief":
        sigma = weight * agent_i.sigma_q_field
        mu    = agent_i.mu_q_field
    else:
        raise ValueError(f"[variance penalty] Unknown field_type: {field_type}")

    if mask is not None:
        _, sigma = apply_mask_to_mu_sigma(None, sigma, mask)
        mu_zero = np.zeros_like(mu) * mask[..., None]
    else:
        mu_zero = np.zeros_like(mu)

    return mu_zero, sigma




def grad_variance_penalty_field(agent_i, lambda_, field_type="model", mask=None):
    """
    Gradient of Tr(Σ⁻¹) penalty:
        ∇_Σ = -λ Σ⁻¹

    Returns:
        (Δμ, ΔΣ): where Δμ = 0, ΔΣ = -λ Σ⁻¹ (masked if needed)
    """
    if lambda_ <= 0:
        return zero_mu_sigma_like(agent_i, field=field_type)

    sigma = agent_i.sigma_p_field if field_type == "model" else agent_i.sigma_q_field
    mu_shape = agent_i.mu_p_field.shape if field_type == "model" else agent_i.mu_q_field.shape

    H, W, K, _ = sigma.shape
    d_sigma = np.zeros_like(sigma)
    fallback = np.eye(K)

    for i in range(H):
        for j in range(W):
            try:
                inv_ij = np.linalg.inv(sigma[i, j])
            except np.linalg.LinAlgError:
                if getattr(config, "debug", False):
                    print(f"[WARN] grad_variance_penalty_field: Σ⁻¹ fallback at ({i},{j})")
                inv_ij = np.linalg.pinv(sigma[i, j])  # fallback to pseudo-inverse

            d_sigma[i, j] = -lambda_ * inv_ij

    d_sigma = np.nan_to_num(d_sigma)

    if mask is not None:
        _, d_sigma = apply_mask_to_mu_sigma(None, d_sigma, mask)

    d_mu = np.zeros(mu_shape, dtype=d_sigma.dtype)
    return d_mu, d_sigma




def compute_alignment_gradient(agent_i, agents, params, field_type="model"):
    """
    Computes raw Euclidean gradient ∇μ, ∇Σ of KL(q_i || Ω q_j) or KL(p_i || Ω̃ p_j),
    without applying natural gradient.

    Returns:
        grad_mu_raw:    (H, W, K)
        grad_sigma_raw: (H, W, K, K)
    """
    β = params.get("model_align_weight", config.model_align_weight) if field_type == "model" else params.get("beta", config.beta)
    if β <= 0:
        return np.zeros_like(agent_i.mu_q_field), np.zeros_like(agent_i.sigma_q_field)

    μ_i = agent_i.mu_q_field if field_type == "belief" else agent_i.mu_p_field
    Σ_i = agent_i.sigma_q_field if field_type == "belief" else agent_i.sigma_p_field
    Oi = agent_i._exp_phi       if field_type == "belief" else agent_i._exp_phi_model
    Oj_inv_name = "_exp_neg_phi" if field_type == "belief" else "_exp_neg_phi_model"

    eps        = params.get("support_cutoff_eps", config.support_cutoff_eps)
    clip_th    = params.get("alignment_grad_clip", getattr(config, "gradient_clip", 1e3))
    debug      = params.get("debug", getattr(config, "debug_gradients", False))
    isometry_check = params.get("omega_isometry_check", False)

    grad_mu    = np.zeros_like(μ_i)
    grad_sigma = np.zeros_like(Σ_i)

    H, W, K = μ_i.shape

    for nb in agent_i.neighbors:
        agent_j = agents[nb["id"]]
        mask_overlap = (agent_i.mask * agent_j.mask > eps)
        if not np.any(mask_overlap):
            continue

        μ_j = agent_j.mu_q_field if field_type == "belief" else agent_j.mu_p_field
        Σ_j = agent_j.sigma_q_field if field_type == "belief" else agent_j.sigma_p_field
        Oj_inv = getattr(agent_j, Oj_inv_name)

        Ω = np.einsum("...ij,...jk->...ik", Oi, Oj_inv)
        if Ω.ndim == 3 and Ω.shape[0] == μ_j.shape[0] * μ_j.shape[1]:
            Ω = Ω.reshape(H, W, K, K)
        Ω_T = np.transpose(Ω, (0, 1, 3, 2))

        μj_rot = np.einsum("...ij,...j->...i", Ω, μ_j)
        Σj_rot = np.einsum("...ij,...jk,...kl->...il", Ω, Σ_j, Ω_T)

        Σ_i_safe = sanitize_sigma(Σ_i, eps=config.eps)
        Σj_safe  = sanitize_sigma(Σj_rot, eps=config.eps)

        for i in range(H):
            for j in range(W):
                if not mask_overlap[i, j]:
                    continue

                if isometry_check:
                    Id = np.eye(K)
                    check = Ω[i, j] @ Ω_T[i, j]
                    err = np.linalg.norm(check - Id)
                    if err > 1e-2 and debug:
                        print(f"[WARN] Ω not close to isometry at ({i},{j}) ‖ΩΩᵀ−I‖={err:.2e}")

                try:
                    Σj_inv = np.linalg.inv(Σj_safe[i, j])
                except np.linalg.LinAlgError:
                    if debug:
                        print(f"[FALLBACK] pinv for neighbor {nb['id']} at ({i},{j})")
                    Σj_inv = np.linalg.pinv(Σj_safe[i, j])

                diff = μj_rot[i, j] - μ_i[i, j]
                dμ = -Σj_inv @ diff

                # Corrected gradient of KL w.r.t. Σ_i
                dΣ = 0.5 * (Σj_inv @ Σ_i_safe[i, j] @ Σj_inv - Σj_inv)

                # --- Norm Clipping ---
                norm_dμ = np.linalg.norm(dμ)
                if norm_dμ > clip_th:
                    dμ *= clip_th / (norm_dμ + 1e-8)

                norm_dΣ = np.linalg.norm(dΣ)
                if norm_dΣ > clip_th:
                    dΣ *= clip_th / (norm_dΣ + 1e-8)

                grad_mu[i, j] += β * dμ
                grad_sigma[i, j] += β * dΣ

    grad_mu = np.nan_to_num(grad_mu)
    grad_sigma = np.nan_to_num(grad_sigma)

    return grad_mu, grad_sigma

def grad_alignment_field(agent_i, agents, weight, params, field_type="model", mask=None):
    """
    Raw Euclidean gradient of alignment KL(q_i || Ω q_j) or KL(p_i || Ω̃ p_j).
    Preconditioning should be applied in combine_field_gradients().
    """
    if weight <= 0:
        return zero_mu_sigma_like(agent_i, field=field_type)

    dμ, dΣ = compute_alignment_gradient(agent_i, agents, params, field_type=field_type)

    if mask is not None:
        dμ, dΣ = apply_mask_to_mu_sigma(dμ, dΣ, mask)

    return weight * dμ, weight * dΣ

def combine_field_gradients(agent_i, agents, params, field_type="model"):
    if field_type == "model" and getattr(config, "identical_models", False):
        return zero_mu_sigma_like(agent_i)

    # Load all parameters
    α  = params.get("alpha", config.alpha)
    β  = params.get("model_align_weight", config.model_align_weight) if field_type == "model" else params.get("beta", config.beta)
    fb = params.get("model_feedback_weight", config.model_feedback_weight) if field_type == "model" else params.get("belief_feedback_weight", getattr(config, "belief_feedback_weight", 0.0))
    λ  = params.get("variance_penalty_model_weight", getattr(config, "variance_penalty_model_weight", 0.0)) if field_type == "model" else params.get("variance_penalty_belief_weight", getattr(config, "variance_penalty_belief_weight", 0.0))
    eps = params.get("support_cutoff_eps", config.support_cutoff_eps)

    # Mask
    mask = agent_i.mask > eps
    if not np.any(mask):
        return zero_mu_sigma_like(agent_i)

    # Select fields
    mu_field    = agent_i.mu_p_field if field_type == "model" else agent_i.mu_q_field
    sigma_field = agent_i.sigma_p_field if field_type == "model" else agent_i.sigma_q_field

    # --- Natural-gradient components ---
    grad_mu_nat    = np.zeros_like(mu_field)
    grad_sigma_nat = np.zeros_like(sigma_field)

    if α > 0:
        dμ, dΣ = grad_self_field(agent_i, α, field_type, mask)
        grad_mu_nat += dμ
        grad_sigma_nat += dΣ
    if fb > 0:
        dμ, dΣ = grad_feedback_field(agent_i, fb, field_type, mask)
        grad_mu_nat += dμ
        grad_sigma_nat += dΣ
    if β > 0:
        dμ, dΣ = grad_alignment_field(agent_i, agents, β, params, field_type, mask)
        grad_mu_nat += dμ
        grad_sigma_nat += dΣ

    # --- Apply Fisher preconditioner only to KL terms ---
    delta_mu, delta_sigma = apply_natural_gradient_batch(
        mu_field, sigma_field, grad_mu_nat, grad_sigma_nat
    )

    # --- Add regularization (coordinate) terms AFTER natural gradient ---
    if λ > 0:
        dμ_reg, dΣ_reg = grad_variance_penalty_field(agent_i, λ, field_type, mask)
        delta_mu    += dμ_reg
        delta_sigma += dΣ_reg

    # Final nan sanitization
    delta_mu    = np.nan_to_num(delta_mu, nan=0.0, posinf=1e5, neginf=-1e5)
    delta_sigma = np.nan_to_num(delta_sigma, nan=0.0, posinf=1e5, neginf=-1e5)

    return delta_mu, delta_sigma


def compute_phi_alignment_grad(agent_i, agents, params, field="phi"):
    """
    Computes analytic gradient ∇_φ or ∇_{φ̃} KL(q_i || Ω q_j) or KL(p_i || Ω̃ p_j),
    using the unified transport-based gradient routine.
    """
    weight = params.get("beta", config.beta) if field == "phi" else params.get("model_align_weight", config.model_align_weight)
    if weight <= 0:
        return np.zeros_like(agent_i.phi if field == "phi" else agent_i.phi_model)

    generators = params.get("generators", get_generators(config.group_name, config.K))
    return compute_phi_gradient_via_transport(agent_i, agents, generators, field=field)



def compute_phi_model_alignment_gradient(agent_i, agents, params, field="model"):
    """
    Computes the analytic variational gradient ∇_{φ̃} KL(fiber_i ‖ Ω̃_{ij} fiber_j),
    using the unified backpropagation routine through Ω̃ = exp(φ̃).

    Args:
        agent_i: focal agent
        agents : list of all agents
        params : runtime and config dict
        field  : "model" (or optionally "belief")

    Returns:
        grad: (H, W, d) Lie-algebra-valued update
    """
    β = params.get("model_align_weight", config.model_align_weight)
    if β <= 0:
        return np.zeros_like(agent_i.phi_model)

    generators = params.get("generators", get_generators(config.group_name, config.K))
    return compute_phi_gradient_via_transport(agent_i, agents, generators, field="phi_model")



def compute_phi_update(agent_i, agents, params, field="phi"):
    """
    Unified update for φ (belief alignment) and φ̃ (model alignment).
    Applies Lie-natural gradient to alignment + optional regularizers.
    """
    if field == "phi_model" and getattr(config, "identical_models", False):
        return np.zeros_like(agent_i.phi_model)

    # --- Unpack core parameters ---
    unpacked  = unpack_phi_update_params(params, field=field)
    β         = params.get("beta", config.beta) if field == "phi" else params.get("model_align_weight", config.model_align_weight)
    κ         = unpacked["κ"]
    gw        = unpacked["gw"]
    curv_w    = unpacked["curv_weight"]
    clip_th   = unpacked["grad_clip_threshold"]
    eps       = unpacked["overlap_eps"]
    debug     = unpacked["debug"]

    phi       = agent_i.phi if field == "phi" else agent_i.phi_model
    phi_tilde = agent_i.phi_model if field == "phi" else agent_i.phi
    soft_mask = agent_i.mask[..., None]
    generators = params.get("generators", get_generators(config.group_name, config.K))

    if not np.any(soft_mask > eps):
        return np.zeros_like(phi)

    grad = np.zeros_like(phi)

    # --- Fisher metric (spatial or global) ---
    if field == "phi" and getattr(config, "use_spatial_fisher_phi", False):
        G_inv = compute_inverse_fisher_field(agent_i, generators, field=field)
    else:
        G_inv = params.get("G_inv_phi", None) if field == "phi" else params.get("G_inv_phi_model", None)
        if G_inv is None and getattr(config, "adaptive_phi_metric", True):
            G_inv = compute_local_phi_metric(agent_i, field=field)

    # --- 1. Alignment gradient (Lie-natural) ---
    if β > 0:
        align_fn = compute_phi_alignment_grad if field == "phi" else compute_phi_model_alignment_gradient
        grad_align = align_fn(agent_i, agents, params, field=field)
        grad += apply_lie_natural_gradient(phi, grad_align, G_inv=G_inv)

    # --- 2. Curvature gradient ---
    if curv_w > 0:
        grad_curv = compute_curvature_gradient_analytical(phi, generators)
        grad += curv_w * grad_curv

    # --- 3. Mass term: 2γ φ ---
    if gw > 0:
        grad += 2 * gw * phi

    # --- 4. φ–φ̃ coupling ---
    if κ > 0:
        grad += 2 * κ * (phi - phi_tilde)

    # --- 5. Optional Fisher geometry term ---
    fisher_key = "fisher_geometry_weight" if field == "phi" else "fisher_model_geometry_weight"
    fisher_weight = params.get(fisher_key, getattr(config, fisher_key, 0.0))
    if fisher_weight > 0:
        fisher_fn = compute_phi_fisher_gradient if field == "phi" else compute_phi_model_fisher_gradient
        fisher_grad = fisher_fn(agent_i, agents, params)
        grad += fisher_weight * fisher_grad

    # --- Final clip + mask ---
    return clip_and_mask_gradient(grad, soft_mask, clip_th, eps)


from natural_gradient_utils import sanitize_sigma

def compute_phi_gradient_via_transport(agent_i, agents, generators, field="phi"):
    """
    Computes the analytic variational gradient ∂KL(fiber_i ‖ Ω_ij fiber_j) / ∂φ^a
    using backprop through Ω = exp(φ), for either belief or model fibers.

    Args:
        agent_i    : focal agent
        agents     : list of all agents
        generators : (d, K, K) Lie algebra basis
        field      : "phi" (belief) or "phi_model" (model)

    Returns:
        grad_phi : (H, W, d) gradient of KL w.r.t. φ^a
    """
    assert field in ("phi", "phi_model")
    d = generators.shape[0]
    K = agent_i.mu_q_field.shape[-1]
    grad_phi = np.zeros_like(agent_i.phi if field == "phi" else agent_i.phi_model)
    soft_mask = agent_i.mask[..., None] > config.support_cutoff_eps

    # Choose fiber and Ω cache
    if field == "phi":
        mu_i = agent_i.mu_q_field
        sigma_i = agent_i.sigma_q_field
        Omega_ij = agent_i.Omega
        β = getattr(config, "beta", 1.0)
    else:
        mu_i = agent_i.mu_p_field
        sigma_i = agent_i.sigma_p_field
        Omega_ij = agent_i.Omega_model
        β = getattr(config, "model_align_weight", 1.0)

    for neighbor in agent_i.neighbors:
        agent_j = agents[neighbor["id"]]

        # Select source fiber
        if field == "phi":
            mu_j = agent_j.mu_q_field
            sigma_j = agent_j.sigma_q_field
        else:
            mu_j = agent_j.mu_p_field
            sigma_j = agent_j.sigma_p_field

        # Transport q_j → Ω q_j
        mu_trans = np.einsum("...kl,...l->...k", Omega_ij, mu_j)
        Omega_T = np.swapaxes(Omega_ij, -1, -2)
        sigma_trans = np.einsum("...km,...mn,...nl->...kl", Omega_ij, sigma_j, Omega_T)
        sigma_trans = sanitize_sigma(sigma_trans, eps=config.eps)

        # Invert Σ_trans
        sigma_inv = np.linalg.inv(sigma_trans)

        # KL gradients w.r.t. transported parameters
        delta_mu = mu_i - mu_trans
        d_mu = -np.einsum("...ij,...j->...i", sigma_inv, delta_mu)

        delta_sigma = sigma_i - sigma_trans
        d_sigma = -0.5 * np.einsum("...ik,...kl,...lj->...ij", sigma_inv, delta_sigma, sigma_inv)

        for a in range(d):
            G = generators[a]  # (K, K)

            # d(Ω μ_j)/dφ^a = Ω G μ_j
            OG = np.einsum("...ij,jk->...ik", Omega_ij, G)
            dφ_mu = np.einsum("...ij,...j->...i", OG, mu_j)

            # d(Ω Σ_j Ωᵀ)/dφ^a = Ω G Σ Ωᵀ + Ω Σ Gᵀ Ωᵀ
            OG_sigma = np.einsum("...ij,...jk->...ik", OG, sigma_j)
            dφ_sigma_1 = np.einsum("...ij,...jk->...ik", OG_sigma, Omega_T)

            sigma_G_T = np.einsum("...ij,jk->...ik", sigma_j, G.T)
            O_sigma_GT = np.einsum("...ij,...jk->...ik", Omega_ij, sigma_G_T)
            dφ_sigma_2 = np.einsum("...ij,...jk->...ik", O_sigma_GT, Omega_T)

            dφ_sigma = dφ_sigma_1 + dφ_sigma_2

            # Total gradient contraction
            delta_a = (
                np.sum(d_mu * dφ_mu, axis=-1) +
                np.einsum("...ij,...ij->...", d_sigma, dφ_sigma)
            )

            grad_phi[..., a] += delta_a

    grad_phi *= soft_mask
    grad_phi *= β
    return grad_phi



# Optional: legacy aliases
def compute_phi_fisher_gradient(agent_i, agents, params):
    return compute_fisher_geometry_gradient(agent_i, agents, params, field="phi")

def compute_phi_model_fisher_gradient(agent_i, agents, params):
    return compute_fisher_geometry_gradient(agent_i, agents, params, field="phi_model")


# Convenient aliases
def compute_phi_alignment_gradient(agent_i, agents, params):
    return compute_phi_update(agent_i, agents, params, field="phi")

def compute_phi_model_update(agent_i, agents, params):
    return compute_phi_update(agent_i, agents, params, field="phi_model")
