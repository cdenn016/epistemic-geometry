# -*- coding: utf-8 -*-
"""
Created on Sun Jul  6 14:42:59 2025

@author: chris and christine
"""
import numpy as np
import config
from joblib import Parallel, delayed

def compute_kl_gaussian_fields(mu1, sigma1, mu2, sigma2, mask, eps=1e-8):
    """
    Compute KL(𝒩(μ1, Σ1) || 𝒩(μ2, Σ2)) at each spatial point.

    Args:
        mu1, sigma1: (H, W, K), (H, W, K, K) — belief field
        mu2, sigma2: (H, W, K), (H, W, K, K) — target field
        mask       : (H, W) — soft support
        eps        : float — numerical stabilizer

    Returns:
        kl         : (H, W) — KL divergence at each spatial point
    """
    H, W, K = mu1.shape
    kl = np.zeros((H, W))

    I = np.eye(K)

    for i in range(H):
        for j in range(W):
            if mask[i, j] < eps:
                continue

            μ1 = mu1[i, j]
            μ2 = mu2[i, j]
            Σ1 = sigma1[i, j]
            Σ2 = sigma2[i, j]

            # Sanitize Σ1 and Σ2
            Σ1 = 0.5 * (Σ1 + Σ1.T) + eps * I
            Σ2 = 0.5 * (Σ2 + Σ2.T) + eps * I

            try:
                Σ2_inv = np.linalg.inv(Σ2)
                trace_term = np.trace(Σ2_inv @ Σ1)
                diff = μ2 - μ1
                mahal_term = diff.T @ Σ2_inv @ diff

                det1 = np.linalg.det(Σ1)
                det2 = np.linalg.det(Σ2)

                # Stabilize logdet
                if det1 <= 0 or det2 <= 0:
                    raise np.linalg.LinAlgError("Non-positive definite")

                logdet = np.log(det2) - np.log(det1)
                kl[i, j] = 0.5 * (trace_term + mahal_term - K + logdet)

            except np.linalg.LinAlgError:
                if config.debug:
                    print(f"[WARN] KL computation failed at ({i},{j}) — assigning ∞")
                kl[i, j] = np.inf

    return kl



def compute_fisher_metric_block_diag(sigma: np.ndarray):
    """
    Compute block-diagonal approximation to the Fisher metric for MVN(μ, Σ)

    Fisher block structure:
    [ Σ⁻¹               0         ]
    [   0   (1/2) Σ⁻¹ ⊗ Σ⁻¹       ]

    Args:
        sigma: (K, K) positive-definite covariance matrix

    Returns:
        fisher_mu_inv:    (K, K)
        fisher_sigma_inv: (K, K, K, K)
    """
    eps = getattr(config, "eps", 1e-6)
    K = sigma.shape[0]

    # SPD sanitize
    sigma_sanitized = sanitize_sigma(sigma, eps=eps, debug=config.debug_sanitize_sigma)

    try:
        sigma_inv = np.linalg.inv(sigma_sanitized)
    except np.linalg.LinAlgError:
        if getattr(config, "debug", False):
            print("[WARN] Fisher metric inverse fallback — using identity")
        sigma_inv = np.eye(K)

    fisher_mu = sigma_inv
    fisher_sigma = 0.5 * np.einsum('ij,kl->ijkl', sigma_inv, sigma_inv)

    # Optional cleanup
    fisher_mu = np.nan_to_num(fisher_mu)
    fisher_sigma = np.nan_to_num(fisher_sigma)

    return fisher_mu, fisher_sigma


def apply_lie_natural_gradient(phi, grad_phi, G_inv=None):
    """
    Apply Lie-natural gradient update to φ using optional inverse Fisher metric.

    Args:
        phi      : (H, W, d) or None — current φ field (not used unless needed for adaptive G)
        grad_phi : (H, W, d)         — raw Euclidean gradient
        G_inv    : (d, d) or (H, W, d, d) or None — inverse Fisher metric

    Returns:
        nat_grad : (H, W, d) natural gradient update
    """
    if G_inv is None:
        return grad_phi  # fallback

    if G_inv.ndim == 2:
        # Constant global metric
        return np.einsum("ab,...b->...a", G_inv, grad_phi)
    elif G_inv.ndim == 4:
        # Spatially varying Fisher inverse
        return np.einsum("...ab,...b->...a", G_inv, grad_phi)
    else:
        raise ValueError(f"G_inv must be (d,d) or (H,W,d,d), got {G_inv.shape}")



def compute_inverse_fisher_field(agent, generators, field="phi"):
    """
    Computes per-point inverse Fisher metric G^{-1}_{ab}(x) in the Lie algebra.
    Skips computation in regions where agent.mask < support_cutoff_eps.

    Args:
        agent: agent object with sigma_q_field or sigma_p_field
        generators: (d, K, K) Lie algebra basis
        field: "phi" or "phi_model"

    Returns:
        G_inv_field: (H, W, d, d)
    """
    sigma_field = agent.sigma_q_field if field == "phi" else agent.sigma_p_field
    mask = agent.mask > getattr(config, "support_cutoff_eps", 1e-4)

    sigma_field = sanitize_sigma(sigma_field, eps=config.eps, debug=config.debug_sanitize_sigma)

    H, W, K, _ = sigma_field.shape
    d = generators.shape[0]
    eye_K = np.eye(K)
    eye_d = np.eye(d)

    G_inv_field = np.zeros((H, W, d, d), dtype=sigma_field.dtype)

    flat_sigma = sigma_field.reshape(-1, K, K)
    flat_mask = mask.reshape(-1)
    N = flat_sigma.shape[0]

    valid_indices = np.flatnonzero(flat_mask)
    sigma_valid = flat_sigma[valid_indices]  # (M, K, K)

    # Step 1: invert Σ⁻¹ (with fallback)
    sigma_inv = np.empty_like(sigma_valid)
    for i in range(sigma_valid.shape[0]):
        try:
            sigma_inv[i] = np.linalg.inv(sigma_valid[i])
        except np.linalg.LinAlgError:
            sigma_inv[i] = eye_K
            if config.debug:
                print(f"[WARN] Σ⁻¹ failed at valid index {i}")

    # Step 2: compute G_ab[i, a, b] = Tr[Σ⁻¹ G^a Σ⁻¹ G^b]
    G_ab = np.zeros((sigma_inv.shape[0], d, d), dtype=sigma_field.dtype)

    for a in range(d):
        Ga = generators[a]
        A1 = np.einsum("mij,jk->mik", sigma_inv, Ga)

        for b in range(d):
            Gb = generators[b]
            A2 = np.einsum("mij,mjk->mik", A1, sigma_inv)  # ✅ fixed: broadcast-safe einsum
            G_ab[:, a, b] = np.einsum("mij,ij->m", A2, Gb)

    # Step 3: symmetrize and invert G_ab
    for i in range(G_ab.shape[0]):
        G_sym = 0.5 * (G_ab[i] + G_ab[i].T)
        try:
            G_inv_field.reshape(-1, d, d)[valid_indices[i]] = np.linalg.inv(G_sym + config.eps * eye_d)
        except np.linalg.LinAlgError:
            G_inv_field.reshape(-1, d, d)[valid_indices[i]] = eye_d
            if config.debug:
                print(f"[WARN] G_ab⁻¹ fallback at valid index {i}")

    return G_inv_field




def apply_natural_gradient_batch(mu_field, sigma_field, grad_mu_field, grad_sigma_field):
    """
    Apply natural gradient descent using local Fisher metric at each spatial point.
    Fisher inverse:
        G_mu^-1 = Σ
        G_Sigma^-1 = 2 × (Σ ⊗ Σ)

    Returns:
        delta_mu:    (H, W, K)
        delta_sigma: (H, W, K, K)
    """
    eps = getattr(config, "eps", 1e-8)
    debug = getattr(config, "debug_gradients", False)

    if mu_field.ndim != 3:
        raise ValueError(f"Unsupported shape {mu_field.shape} for mu_field")

    H, W, K = mu_field.shape
    N = H * W

    mu_flat = mu_field.reshape(N, K)
    sigma_flat = sigma_field.reshape(N, K, K)
    grad_mu_flat = grad_mu_field.reshape(N, K)
    grad_sigma_flat = grad_sigma_field.reshape(N, K, K)

    delta_mu = np.zeros_like(mu_flat)
    delta_sigma = np.zeros_like(sigma_flat)

    eye = np.eye(K)

    for n in range(N):
        sigma_n = sigma_flat[n]
        grad_mu_n = grad_mu_flat[n]
        grad_sigma_n = grad_sigma_flat[n]

        # Symmetrize and regularize
        sigma_n = 0.5 * (sigma_n + sigma_n.T) + eps * eye

        try:
            sigma_inv = np.linalg.inv(sigma_n)
        except np.linalg.LinAlgError:
            sigma_inv = eye
            if debug:
                print(f"[WARN] apply_natural_gradient_batch: Σ⁻¹ fallback at index {n}")

        # Natural gradient update
        delta_mu_n = -sigma_n @ grad_mu_n
        delta_sigma_n = -2.0 * sigma_n @ grad_sigma_n @ sigma_n

        delta_mu[n] = np.nan_to_num(delta_mu_n)
        delta_sigma[n] = np.nan_to_num(delta_sigma_n)

    return (
        delta_mu.reshape(H, W, K),
        delta_sigma.reshape(H, W, K, K),
    )




def compute_lie_metric(generators: np.ndarray):
    """
    Compute inner product matrix G_{ab} = Tr(G_a^T G_b) and its inverse.

    Args:
        generators: (d, K, K) basis of Lie algebra

    Returns:
        G: (d, d) Lie algebra inner product matrix
        G_inv: (d, d) inverse metric (fallbacks to identity if needed)
    """
    d = generators.shape[0]
    G = np.einsum("aij,bij->ab", generators, generators)  # (d, d)
    G = 0.5 * (G + G.T)  # Symmetrize

    eps = getattr(config, "eps", 1e-6)
    try:
        G_inv = np.linalg.inv(G + eps * np.eye(d))
    except np.linalg.LinAlgError:
        if getattr(config, "debug", False):
            print("[WARN] compute_lie_metric: G inverse failed — using identity")
        G_inv = np.eye(d)

    return G, G_inv



def _sanitize_one_sigma(S, eps=1e-6):
    """
    Sanitize a single covariance matrix to ensure it's symmetric positive-definite (SPD).

    Returns:
        (S_sanitized, clipped): sanitized matrix and boolean flag indicating if it was modified
    """
    S = 0.5 * (S + S.T)  # ensure symmetry

    # First line of defense: handle invalid or pathological cases
    if not np.all(np.isfinite(S)) or np.trace(S) < eps or np.any(np.diag(S) <= 0):
        return np.eye(S.shape[0]) * eps, True

    try:
        eigvals, eigvecs = np.linalg.eigh(S)
    except np.linalg.LinAlgError:
        return np.eye(S.shape[0]) * eps, True

    clipped = np.any(eigvals < eps)
    eigvals_clipped = np.clip(eigvals, eps, None)

    if clipped:
        S = eigvecs @ np.diag(eigvals_clipped) @ eigvecs.T
        S = 0.5 * (S + S.T)  # re-symmetrize

    return S, clipped


def sanitize_sigma(Sigma, eps=1e-6, debug=False, n_jobs=None, parallel_threshold=50):
    """
    Sanitize a batch of covariance matrices to ensure SPD.

    Parameters:
        Sigma: (..., K, K) ndarray — batch of covariances
        eps: minimum eigenvalue threshold
        debug: if True, prints a summary if any matrices are clipped
        n_jobs: number of parallel workers (default: config.num_cores or 1)
        parallel_threshold: min number of matrices before enabling parallelization

    Returns:
        Sanitized SPD matrices with same shape as input.
    """
    shape = Sigma.shape
    flat_sigma = Sigma.reshape(-1, shape[-2], shape[-1])
    n_total = flat_sigma.shape[0]
    n_jobs = n_jobs or getattr(config, "num_cores", 1)

    if n_total < parallel_threshold or n_jobs == 1:
        results = [_sanitize_one_sigma(S, eps) for S in flat_sigma]
    else:
        from joblib import parallel_backend
        with parallel_backend("threading"):
            results = Parallel(n_jobs=n_jobs)(
                delayed(_sanitize_one_sigma)(S, eps) for S in flat_sigma
            )

    Sigma_out, clipped_flags = zip(*results)
    if debug:
        n_clipped = sum(clipped_flags)
        if n_clipped > 0:
            print(f"[SPD sanitize] Clipped {n_clipped} / {n_total} matrices to eps={eps:.1e}")

    out = np.stack(Sigma_out, axis=0).astype(Sigma.dtype).reshape(shape)
    return out

# fisher_geometry_terms.py

import numpy as np
from get_generators import get_generators
import config

def compute_fisher_geometry_gradient(agent_i, agents, params, field="phi"):
    """
    Compute ∇_{φ} or ∇_{φ̃} for Fisher geometry preservation:
        ∇‖Gᵢ − Ωᵢⱼ Gⱼ Ωᵢⱼᵀ‖²
    Supports field="phi" (beliefs) or "phi_model" (models).
    """
    if field == "phi":
        phi     = agent_i.phi
        G_field = agent_i.cached_fisher_q
        exp_phi = agent_i._exp_phi
        exp_neg_phi_j_name = "_exp_neg_phi"
        fisher_weight = params.get("fisher_geometry_weight", config.fisher_geometry_weight)
    else:
        phi     = agent_i.phi_model
        G_field = agent_i.cached_fisher_p
        exp_phi = agent_i._exp_phi_model
        exp_neg_phi_j_name = "_exp_neg_phi_model"
        fisher_weight = params.get("fisher_model_geometry_weight", config.fisher_model_geometry_weight)

    if fisher_weight <= 0:
        return np.zeros_like(phi)

    Gs = get_generators(config.group_name, config.K)
    d, K = Gs.shape[0], Gs.shape[1]
    mask_i = agent_i.mask > config.support_cutoff_eps
    if not np.any(mask_i):
        return np.zeros_like(phi)

    grad = np.zeros_like(phi)
    flat_self_mask = mask_i.reshape(-1)

    exp_phi_i = exp_phi.reshape(-1, K, K)

    for nb in agent_i.neighbors:
        agent_j = agents[nb["id"]]
        mask_j = agent_j.mask > config.support_cutoff_eps
        overlap = mask_i & mask_j
        if not np.any(overlap):
            continue

        flat_idxs = overlap.reshape(-1)

        G_i = G_field.reshape(-1, K, K)[flat_idxs]
        G_j = getattr(agent_j, f"cached_fisher_{'q' if field == 'phi' else 'p'}").reshape(-1, K, K)[flat_idxs]
        exp_neg_phi_j = getattr(agent_j, exp_neg_phi_j_name).reshape(-1, K, K)[flat_idxs]

        Omega = np.einsum("mij,mjk->mik", exp_phi_i[flat_idxs], exp_neg_phi_j)
        G_j_rot = np.einsum("mik,mkl,mjl->mij", Omega, G_j, Omega)  # Ω G Ωᵀ
        Delta = G_i - G_j_rot

        for a in range(d):
            Ga = Gs[a]
            dΩ = np.einsum("ij,mjk->mik", Ga, Omega)
            term1 = np.einsum("mik,mkl,mjl->mij", dΩ, G_j, Omega)
            term2 = np.einsum("mik,mkl,mjl->mij", Omega, G_j, dΩ)
            dG_rot = term1 + term2
            dL = 2 * np.einsum("mij,mij->m", Delta, dG_rot)
            grad.reshape(-1, d)[flat_idxs, a] += dL

    grad *= fisher_weight
    grad[~mask_i] = 0.0
    return grad

# Optional: legacy aliases
def compute_phi_fisher_gradient(agent_i, agents, params):
    return compute_fisher_geometry_gradient(agent_i, agents, params, field="phi")

def compute_phi_model_fisher_gradient(agent_i, agents, params):
    return compute_fisher_geometry_gradient(agent_i, agents, params, field="phi_model")






