# -*- coding: utf-8 -*-
"""
Created on Tue Oct 21 21:49:19 2025

@author: chris and christine
"""

# updates/grad_config.py
"""
Frozen, picklable gradient configuration for multiprocessing.
"""
from dataclasses import dataclass
from typing import Optional
import numpy as np


@dataclass(frozen=True)
class GradientConfig:
    """
    Immutable gradient configuration suitable for multiprocessing.
    All fields have defaults; construct via from_context() for consistency.
    """
    # Numerics
    eps: float = 1e-8
    tau: float = 1e-6
    
    # Coupling weights
    alpha: float = 1.0
    feedback_weight: float = 0.0
    
    # Beta alignment
    beta_kappa_q: float = 1.0
    beta_kappa_p: float = 1.0
    
    # Gamma gating
    kappa_gamma_q: float = 1.0
    kappa_gamma_p: float = 1.0
    
    use_gamma_A_q: bool = False
    use_gamma_A_p: bool = True
    use_gamma_B_q: bool = True
    use_gamma_B_p: bool = False
    
    # Gamma normalization
    normalize_gamma: bool = False
    gamma_norm_mode: str = "sumcap"  # "sumcap" | "rowsum"
    gamma_sumcap: float = 1.0
    gamma_cap: float = 0.0  # 0 => no per-edge cap
    
    # Sender accumulation
    accumulate_sender_grads: bool = True
    
    def __post_init__(self):
        """Validate and compute hash on construction."""
        assert self.eps > 0, "eps must be positive"
        assert self.tau >= 0, "tau must be non-negative"
        assert self.beta_kappa_q > 0, "beta_kappa_q must be positive"
        assert self.beta_kappa_p > 0, "beta_kappa_p must be positive"
        assert self.kappa_gamma_q > 0, "kappa_gamma_q must be positive"
        assert self.kappa_gamma_p > 0, "kappa_gamma_p must be positive"
        assert self.gamma_norm_mode in ("sumcap", "rowsum"), \
            f"Invalid gamma_norm_mode: {self.gamma_norm_mode}"
        
        # Compute stable hash for caching (uses all fields)
        object.__setattr__(self, '_hash', hash(tuple(
            getattr(self, f.name) for f in self.__dataclass_fields__.values()
        )))
    
    def __hash__(self):
        return self._hash
    
    @classmethod
    def from_context(cls, ctx):
        """
        Extract gradient config from runtime context.
        Safe for both master and worker processes.
        """
        from core.runtime_context import cfg_get
        
        return cls(
            eps=float(cfg_get(ctx, "eps", 1e-8)),
            tau=float(cfg_get(ctx, "support_tau", 1e-6)),
            alpha=float(cfg_get(ctx, "alpha", 0.0)),
            feedback_weight=float(cfg_get(ctx, "feedback_weight", 0.0)),
            beta_kappa_q=max(float(cfg_get(ctx, "beta_kappa_q", 1.0)), 1e-12),
            beta_kappa_p=max(float(cfg_get(ctx, "beta_kappa_p", 1.0)), 1e-12),
            kappa_gamma_q=max(float(cfg_get(ctx, "kappa_gamma_q", 1.0)), 1e-12),
            kappa_gamma_p=max(float(cfg_get(ctx, "kappa_gamma_p", 1.0)), 1e-12),
            use_gamma_A_q=bool(cfg_get(ctx, "use_gamma_A_q", False)),
            use_gamma_A_p=bool(cfg_get(ctx, "use_gamma_A_p", True)),
            use_gamma_B_q=bool(cfg_get(ctx, "use_gamma_B_q", True)),
            use_gamma_B_p=bool(cfg_get(ctx, "use_gamma_B_p", False)),
            normalize_gamma=bool(cfg_get(ctx, "normalize_gamma", False)),
            gamma_norm_mode=str(cfg_get(ctx, "gamma_norm_mode", "sumcap")).lower(),
            gamma_sumcap=float(cfg_get(ctx, "gamma_sumcap", 1.0)),
            gamma_cap=float(cfg_get(ctx, "gamma_cap", 0.0)),
            accumulate_sender_grads=bool(cfg_get(ctx, "accumulate_sender_grads", False)),
        )
    
# updates/grad_config.py (ADD TO EXISTING)

@dataclass(frozen=True)
class PhiGradientConfig:
    """
    Frozen, picklable φ gradient configuration.
    Separate from GradientConfig to keep concerns modular.
    """
    # Numerics
    eps: float = 1e-8
    tau: float = 1e-6
    
    # Coupling weights
    alpha: float = 1
    feedback_weight: float = 0.0
    
    # Beta alignment (φ space)
    beta_kappa_q: float = 1.0
    beta_kappa_p: float = 1.0
    
    # Gamma gating (φ space)
    kappa_gamma_q: float = 1.0
    kappa_gamma_p: float = 1.0
    
    use_gamma_A_q: bool = False
    use_gamma_A_p: bool = True
    use_gamma_B_q: bool = True
    use_gamma_B_p: bool = False
    
    def __post_init__(self):
        """Validate and compute hash."""
        assert self.eps > 0, "eps must be positive"
        assert self.tau >= 0, "tau must be non-negative"
        object.__setattr__(self, '_hash', hash(tuple(
            getattr(self, f.name) for f in self.__dataclass_fields__.values()
        )))
    
    def __hash__(self):
        return self._hash
    
    @classmethod
    def from_context(cls, ctx):
        """Extract from runtime context (process-safe)."""
        from core.runtime_context import cfg_get
        
        return cls(
            eps=float(cfg_get(ctx, "eps", 1e-8)),
            tau=float(cfg_get(ctx, "support_tau", 1e-6)),
            alpha=float(cfg_get(ctx, "alpha", 1.0)),
            feedback_weight=float(cfg_get(ctx, "feedback_weight", 0.0)),
            beta_kappa_q=max(float(cfg_get(ctx, "beta_kappa_q", 1.0)), 1e-12),
            beta_kappa_p=max(float(cfg_get(ctx, "beta_kappa_p", 1.0)), 1e-12),
            kappa_gamma_q=max(float(cfg_get(ctx, "kappa_gamma_q", 1.0)), 1e-12),
            kappa_gamma_p=max(float(cfg_get(ctx, "kappa_gamma_p", 1.0)), 1e-12),
            use_gamma_A_q=bool(cfg_get(ctx, "use_gamma_A_q", False)),
            use_gamma_A_p=bool(cfg_get(ctx, "use_gamma_A_p", True)),
            use_gamma_B_q=bool(cfg_get(ctx, "use_gamma_B_q", True)),
            use_gamma_B_p=bool(cfg_get(ctx, "use_gamma_B_p", False)),
        )