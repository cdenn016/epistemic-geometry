# -*- coding: utf-8 -*-
"""
Created on Tue Oct 14 12:06:54 2025

@author: chris and christine
"""

import numpy as np
from core.numerical_utils import safe_inv, sanitize_sigma, safe_omega_inv
from core.transport_cache import ( Jinv_grid, E_grid, Omega, 
                                  exp_and_jinv_single, Phi_cached )
from core.omega import ( build_dexpinv_matrix , d_exp_exact, 
                        matrix_cograd_to_param_covector_irrep, project_phi_covector_to_step )

from core.runtime_context import cfg_get
from core.utils import push_neighbor_stats, mask_hw, joint_masks
from core.numerical_utils import push_gaussian

from core.beta import beta_align_maps
from typing import Tuple
#==============================================================================
#
#                    GATHER PHI GAUGE FIELD GRADIENT TERMS
#                          Beliefs and Models
#==============================================================================



_FIELD_META = {
    "phi": {
        "which": "q",
        "mu_key": "mu_q_field",
        "sigma_key": "sigma_q_field",
        "fisher_inv_key": "inverse_fisher_phi",
        "grad_key": "grad_phi",
        "phi_attr": "phi",
        "qall_func": d_exp_exact,
    },
    "phi_model": {
        "which": "p",
        "mu_key": "mu_p_field",
        "sigma_key": "sigma_p_field",
        "fisher_inv_key": "inverse_fisher_phi_model",
        "grad_key": "grad_phi_tilde",
        "phi_attr": "phi_model",
        "qall_func": d_exp_exact,
    },
}



def _run_phi_phase(
    ctx, agent_i, neighbors, *,
    field: str,
    generators_q, generators_p,
    fisher_inv_key: str,
    grad_key: str,
    phi_self_func, phi_feedback_func,
    timings: dict, prefix: str,
):
    import time
    t0 = time.perf_counter()

    # receiver step + self/feedback magnitudes
    recv_step, ener_pair = phi_recv_step(
        ctx, agent_i, neighbors, generators_q, generators_p,
        field=field, fisher_inv_key=fisher_inv_key,
        terms=("align","gamma","self"),
        phi_self_func=phi_self_func, phi_feedback_func=phi_feedback_func,
    )
    recv_step = recv_step.astype(np.float32, copy=False)
    timings[f"{prefix}_recv_total"] = time.perf_counter() - t0

    # sender steps (align + gamma)
    t1 = time.perf_counter()
    send_list = phi_send_steps(
        ctx, agent_i, neighbors, generators_q, generators_p,
        field=field, fisher_inv_key=fisher_inv_key,
        strategies=("align","gamma"),
    ) or []
    timings[f"{prefix}_send_align_total"] = time.perf_counter() - t1
    timings[f"{prefix}_send_gamma_total"] = 0.0

    # return the energy pair so the caller can aggregate on the master
    return recv_step, send_list, ener_pair



def phi_recv_step(ctx, agent_i, neighbors, generators_q, generators_p, *,
                  field: str, fisher_inv_key: str,
                  terms=("align","gamma","self"),
                  phi_self_func=None, phi_feedback_func=None):
    import numpy as np

    which, phi_attr, mu_key, S_key, _, _ = _which_meta(field)
    gens = generators_q if field == "phi" else generators_p

    E_i, Jinv_i, Finv_i = _preconds_min(ctx, agent_i, which=which, fisher_inv_key=fisher_inv_key)

    parts = []
    self_n = 0.0
    fb_n   = 0.0

    if "align" in terms:
        # must return ndarray (*S,3)
        parts.append(np.asarray(
            _phi_term_align_recv(ctx, agent_i, neighbors,
                                 which=which, gens=gens, E_i=E_i, Jinv_i=Jinv_i, Finv_i=Finv_i,
                                 mu_key=mu_key, S_key=S_key, phi_attr=phi_attr),
            np.float32
        ))

    if "gamma" in terms:
        # must return ndarray (*S,3)
        parts.append(np.asarray(
            _phi_term_gamma_recv(ctx, agent_i, neighbors,
                                 which=which, gens=gens, E_i=E_i, Jinv_i=Jinv_i, Finv_i=Finv_i),
            np.float32
        ))

    if "self" in terms:
        # build_phi_self_feedback_bucket returns (dphi ndarray, (self_n, fb_n))
        dphi_self, (self_n, fb_n) = build_phi_self_feedback_bucket(
            ctx, agent_i, generators_q, generators_p,
            field=field, fisher_inv_key=fisher_inv_key,
            phi_self_func=phi_self_func, phi_feedback_func=phi_feedback_func
        )
        parts.append(np.asarray(dphi_self, np.float32))

    if not parts:
        phi = np.asarray(getattr(agent_i, phi_attr), np.float32)
        return np.zeros_like(phi, np.float32), (0.0, 0.0)

    recv = np.sum(parts, axis=0, dtype=np.float32)
    return recv, (float(self_n), float(fb_n))




def _phi_term_align_recv(ctx, ai, neighbors, *, which, gens, E_i, Jinv_i, Finv_i, mu_key, S_key, phi_attr):
    """
    ALIGN receiver-side φ-step for agent i with TRUE softmax-β gradient.

    Energy:      E_i = Σ_j β_ij KL_ij,  β = softmax(-KL/κ) over j
    Gradient:    ∇φ_i E_i
               = Σ_j β_ij (1 - KL_ij/κ) g_ij  +  ( (Σ_j β_ij KL_ij) / κ ) · ḡ_i
      where      g_ij   = ∂ KL_ij / ∂φ_i   (receiver-frame covector, unprojected)
                 ḡ_i   = Σ_j β_ij g_ij

    We compute g_ij per neighbor, accumulate ḡ_i and Σ β KL, then project once.
    """
    eps   = float(cfg_get(ctx, "eps", 1e-8))
    kappa = max(float(cfg_get(ctx, f"beta_kappa_{which}", 1.0)), eps)

    # Receiver stats / params
    mu_i  = getattr(ai, mu_key)
    S_i   = getattr(ai, S_key)
    phi_i = np.asarray(getattr(ai, phi_attr), np.float32)

    # dExp at receiver once
    Q_all_i = d_exp_exact(phi_i, gens)

    # Accumulators in receiver frame (unprojected covectors)
    step_core = np.zeros_like(phi_i, np.float32)   # Σ_j β_ij (1 - KL_ij/κ) g_ij
    gbar      = np.zeros_like(phi_i, np.float32)   # ḡ_i = Σ_j β_ij g_ij
    sum_beta_KL = 0.0                              # scalar field per voxel: Σ_j β_ij KL_ij

    i_id = int(getattr(ai, "id", -1))
    Sshape = np.asarray(mu_i).shape[:-1]

    for aj in (neighbors or []):
        # Joint mask on receiver grid
        m_bool, m_vec = joint_masks(ctx, ai, aj)    # (*S,), (*S,1)
        if not np.any(m_bool):
            continue
        m = m_vec[..., 0].astype(np.float32, copy=False)  # (*S,)

        # Pull normalized β map and KL for this pair from the edge store
        j_id = int(getattr(aj, "id", -1))
        beta_map, KL_map = ctx.edge.get_align(ctx, which, i_id, j_id, shape=Sshape)
        if beta_map is None:
            continue

        beta = (np.asarray(beta_map, np.float32) * m)     # masked β
        if not np.any(beta):
            continue
        KL1  = np.asarray(KL_map,  np.float32) * m        # masked KL

        # Transport & sender stats in receiver frame
        Om  = Omega(ctx, ai, aj, which=which)
        E_j = E_grid(ctx, aj, which=which)
        exp_neg_phi_j = safe_omega_inv(E_j)

        mu_j_t, _, S_j_t_inv = push_neighbor_stats(aj, S_key, Om, eps)

        # Receiver covector wrt φ_i for this neighbor (unprojected)
        g_ij = grad_kl_wrt_phi_i(
            mu_i, S_i,
            None, None,                  # keep legacy placeholders
            phi_i, None,
            Om, gens, E_i, E_j,
            mu_j_t, S_j_t_inv, eps,
            exp_neg_phi_j=exp_neg_phi_j,
            Q_all=Q_all_i,
        ).astype(np.float32, copy=False)

        # Accumulate pieces
        gbar      += beta[..., None] * g_ij
        step_core += (beta * (1.0 - KL1 / kappa))[..., None] * g_ij
        sum_beta_KL += (beta * KL1)

    # If no contributing neighbors, return zeros
    if not (np.any(step_core) or np.any(gbar)):
        return np.zeros_like(phi_i, np.float32)

    # Full unprojected covector:
    #   Σ_j β_ij (1 - KL_ij/κ) g_ij  +  ((Σ_j β_ij KL_ij)/κ) ḡ_i
    full_cov = step_core + (sum_beta_KL / kappa)[..., None] * gbar

    # Project once with receiver's preconditioners
    return _project_phi_cov(full_cov, Jinv_i, Finv_i).astype(np.float32, copy=False)










def _phi_term_gamma_recv(ctx, ai, neighbors, *, which, gens, E_i, Jinv_i, Finv_i):
    """
    Receiver-side φ-step from γ terms for agent i (q or p depending on `which`).
    Uses covector-first pure dispatcher; multiplies by true overlap mask.
    Returns (*S, Dphi).
    """
    eps = float(cfg_get(ctx, "eps", 1e-8))
    kap = float(cfg_get(ctx, f"kappa_gamma_{which}", 1.0))
    use_A = bool(cfg_get(ctx, f"use_gamma_A_{which}", True))
    use_B = bool(cfg_get(ctx, f"use_gamma_B_{which}", True))

    # Fast exit if γ is off
    if not (use_A or use_B):
        phi_attr = "phi" if which == "q" else "phi_model"
        Dphi = int(np.asarray(getattr(ai, phi_attr)).shape[-1])
        Sshape = np.asarray(getattr(ai, "mu_q_field" if which == "q" else "mu_p_field")).shape[:-1]
        return np.zeros(Sshape + (Dphi,), np.float32)

    out = None

    # Receiver grid shape for γ maps
    Sshape_recv = np.asarray(
        getattr(ai, "mu_q_field" if which == "q" else "mu_p_field")
    ).shape[:-1]

    # ---- Prefetch receiver frames/stats (i) ----
    Eqi = np.asarray(E_grid(ctx, ai, which="q"), np.float64)  # (*S,Kq,Kq)
    Epi = np.asarray(E_grid(ctx, ai, which="p"), np.float64)  # (*S,Kp,Kp)
    mu_p_i  = np.asarray(ai.mu_p_field,    np.float64, order="C")
    Sig_p_i = np.asarray(ai.sigma_p_field, np.float64, order="C")

    for aj in (neighbors or []):
        i_id = int(getattr(ai, "id", -1)); j_id = int(getattr(aj, "id", -1))

        # γ maps live on receiver grid (i)
        gA, KA = ctx.edge.get_gamma(ctx, "A", j_id, i_id, shape=Sshape_recv) if use_A else (None, None)
        gB, KB = ctx.edge.get_gamma(ctx, "B", i_id, j_id, shape=Sshape_recv) if use_B else (None, None)
        if (gA is None or not np.any(gA)) and (gB is None or not np.any(gB)):
            continue

        # Joint overlap mask on receiver grid (safeguard)
        m_bool, m_vec = joint_masks(ctx, ai, aj)          # (*S,), (*S,1)
        if not np.any(m_bool):
            continue
        m = m_vec[..., 0].astype(np.float32, copy=False)  # (*S,)

        # Sender stats/frame (j)
        Eqj     = np.asarray(E_grid(ctx, aj, which="q"), np.float64)         # (*S,Kq,Kq)
        mu_q_j  = np.asarray(aj.mu_q_field,    np.float64, order="C")
        Sig_q_j = np.asarray(aj.sigma_q_field, np.float64, order="C")

        def _accum(Wmap, Kmap, basis):
            nonlocal out
            if Wmap is None or not np.any(Wmap):
                return
            W = np.asarray(Wmap, np.float32) * m
            if Kmap is not None:
                K = np.asarray(Kmap, np.float32) * m
                W = W * (1.0 - K / max(kap, eps))
            if not np.any(W):
                return

            # Pure dispatcher call: feed frames & stats directly
            cov_i_q, _, cov_i_p = grad_gamma_phi_covectors(
                Eqi=Eqi, Eqj=Eqj, Epi=Epi,
                mu_q_j=mu_q_j,  Sigma_q_j=Sig_q_j,
                mu_p_i=mu_p_i,  Sigma_p_i=Sig_p_i,
                generators_irrep=gens,
                basis=basis, eps=eps,
            )

            cov_i = cov_i_q if which == "q" else cov_i_p
            term = W[..., None] * _project_phi_cov(cov_i.astype(np.float32, copy=False), Jinv_i, Finv_i)
            out = term if out is None else (out + term)

        if use_A: _accum(gA, KA, "a")
        if use_B: _accum(gB, KB, "b")

    if out is None:
        phi_attr = "phi" if which == "q" else "phi_model"
        return np.zeros_like(getattr(ai, phi_attr), np.float32)
    return out




def grad_gamma_phi_covectors(
    *,  # <-- require kwargs, pure path only
    basis: str,
    Eqi, Eqj, Epi,
    mu_q_j, Sigma_q_j,
    mu_p_i, Sigma_p_i,
    generators_irrep,
    eps: float = 1e-8,
):
    b = str(basis).lower()
    
    
    if b == "a":
        return grad_gamma_A_phi_covectors(
            Eqi=Eqi, Eqj=Eqj, Epi=Epi,
            mu_q_j=mu_q_j, Sigma_q_j=Sigma_q_j,
            mu_p_i=mu_p_i, Sigma_p_i=Sigma_p_i,
            generators_irrep=generators_irrep, eps=eps,
        )
    if b == "b":
        return grad_gamma_B_phi_covectors(
            Eqi=Eqi, Eqj=Eqj, Epi=Epi,
            mu_p_i=mu_p_i, Sigma_p_i=Sigma_p_i,
            mu_q_j=mu_q_j, Sigma_q_j=Sigma_q_j,
            generators_irrep=generators_irrep, eps=eps,
        )
    raise ValueError(f"basis must be 'a' or 'b', got {basis!r}")



# ---------- Sender terms ----------
def phi_send_steps(ctx, agent_i, neighbors, generators_q, generators_p, *, field: str, fisher_inv_key: str,
                   strategies=("align","gamma")):
    """
    Returns [(agent_j, dphi_j)] where dphi_j is a (*S,3) covector step
    projected with the sender's Fisher inverse / Jacobian inverse.
    """
    which, phi_attr, mu_key, S_key, _, grad_key = _which_meta(field)
    gens = generators_q if field in ("phi","phi_q") else generators_p

    # receiver frame for ALIGN sender term
    E_i, _, _ = _preconds_min(ctx, agent_i, which=("q" if field in ("phi","phi_q") else "p"),
                              fisher_inv_key=fisher_inv_key)

    out = []
    # gamma maps live on the receiver grid; use agent_i's base shape
    Sshape_recv = np.asarray(
        getattr(agent_i, "mu_q_field" if which in ("q","phi","phi_q") else "mu_p_field")
    ).shape[:-1]

    # Pre-fetch frames/stats needed for γ covectors (pure path)
    Eqi_cache = np.asarray(E_grid(ctx, agent_i, which="q"), np.float64)   # (*S,Kq,Kq)
    Epi_cache = np.asarray(E_grid(ctx, agent_i, which="p"), np.float64)   # (*S,Kp,Kp)
    mu_p_i    = np.asarray(agent_i.mu_p_field,    np.float64, order="C")
    Sig_p_i   = np.asarray(agent_i.sigma_p_field, np.float64, order="C")

    for aj in (neighbors or []):
        _, Jinv_j, Finv_j = _preconds_min(ctx, aj, which=which, fisher_inv_key=fisher_inv_key)

        steps = []

        # ---------------- ALIGN sender step ----------------
        if "align" in strategies:
            eps   = float(cfg_get(ctx, "eps", 1e-8))
            kappa = max(float(cfg_get(ctx, f"beta_kappa_{which}", 1.0)), eps)
            KL1, beta = beta_align_maps(ctx, agent_i, aj, which=which)
            if np.any(beta):
                scale = beta * (1.0 + (KL1 / kappa) * (beta - 1.0))
                Om  = Omega(ctx, agent_i, aj, which=which)
                E_j = E_grid(ctx, aj, which=which)
                exp_neg_phi_j = safe_omega_inv(E_j)
                mu_j_t, _, S_j_t_inv = push_neighbor_stats(aj, S_key, Om, eps)
                phi_j = np.asarray(getattr(aj, phi_attr), np.float32)
                R_all_j = d_exp_exact(phi_j, gens)
                g_s = grad_kl_wrt_phi_j(
                    getattr(agent_i, mu_key), getattr(agent_i, S_key),
                    getattr(aj,    mu_key),   getattr(aj,    S_key),
                    mu_j_t, phi_j, Om, gens, E_i, E_j, mu_j_t, S_j_t_inv, eps,
                    exp_neg_phi_j=exp_neg_phi_j, R_all=R_all_j,
                ).astype(np.float32, copy=False)
                steps.append(scale[...,None] * _project_phi_cov(g_s, Jinv_j, Finv_j))

        # ---------------- GAMMA sender step (pure dispatcher) ----------------
        if "gamma" in strategies:
            eps = float(cfg_get(ctx, "eps", 1e-8))
            kap = float(cfg_get(ctx, f"kappa_gamma_{which}", 1.0))
            use_A = bool(cfg_get(ctx, f"use_gamma_A_{which}", True))
            use_B = bool(cfg_get(ctx, f"use_gamma_B_{which}", True))

            i_id = int(getattr(agent_i,"id",-1)); j_id = int(getattr(aj,"id",-1))
            gA, KA = ctx.edge.get_gamma(ctx, "A", j_id, i_id, shape=Sshape_recv) if use_A else (None,None)
            gB, KB = ctx.edge.get_gamma(ctx, "B", i_id, j_id, shape=Sshape_recv) if use_B else (None,None)

            # Joint overlap mask on receiver grid (safeguard)
            m_bool, m_vec = joint_masks(ctx, agent_i, aj)
            if not np.any(m_bool):
                # nothing to do for this neighbor
                pass
            else:
                m = m_vec[..., 0].astype(np.float32, copy=False)

                # Pre-fetch sender stats + frame for j
                Eqj_cache = np.asarray(E_grid(ctx, aj, which="q"), np.float64)           # (*S,Kq,Kq)
                mu_q_j    = np.asarray(aj.mu_q_field,    np.float64, order="C")
                Sig_q_j   = np.asarray(aj.sigma_q_field, np.float64, order="C")

                def _add(Wmap, Kmap, basis):
                    if Wmap is None or not np.any(Wmap):
                        return
                    W = np.asarray(Wmap, np.float32) * m
                    if Kmap is not None:
                        K = np.asarray(Kmap, np.float32) * m
                        W = W * (1.0 - K / max(kap, eps))
                    if not np.any(W):
                        return

                    # Pure covector dispatcher: feed frames & stats directly
                    _, cov_jq, _ = grad_gamma_phi_covectors(
                        Eqi=Eqi_cache, Eqj=Eqj_cache, Epi=Epi_cache,
                        mu_q_j=mu_q_j,  Sigma_q_j=Sig_q_j,
                        mu_p_i=mu_p_i,  Sigma_p_i=Sig_p_i,
                        generators_irrep=gens,
                        basis=basis, eps=eps,
                    )
                    steps.append(W[...,None] * _project_phi_cov(cov_jq, Jinv_j, Finv_j))

                if use_A: _add(gA, KA, "a")
                if use_B: _add(gB, KB, "b")

        if steps:
            dphi_j = np.sum(steps, axis=0).astype(np.float32, copy=False)
            out.append((aj, dphi_j))

    return out






# ==================== END MINIMAL φ PIPELINE (DROP-IN) ====================





def build_phi_self_feedback_bucket(
    ctx, agent_i, generators_q, generators_p, *,
    field: str,                 # "phi" or "phi_tilde"
    fisher_inv_key: str,        # "fisher_inv_q" / "fisher_inv_p"
    phi_self_func=None,
    phi_feedback_func=None,
) -> Tuple[np.ndarray, Tuple[float, float]]:
    """
    Returns:
      dphi      : (*S, 3) fp32 gradient contribution for this (self+feedback) term
      (self_n, fb_n) : L1 magnitudes for debug/diagnostics (floats)
    No side-effects.
    """
   
    eps   = float(cfg_get(ctx, "eps", 1e-8))
    tau   = float(cfg_get(ctx, "support_tau", 1e-6))
    alpha = float(cfg_get(ctx, "alpha", 0.0))
    fbw   = float(cfg_get(ctx, "feedback_weight", 0.0))

    mask3 = mask_hw(agent_i, tau=tau, mode="float3")
    if not np.any(mask3):
        # return zeros and zero diagnostics
        return np.zeros_like(getattr(agent_i, field), np.float32), (0.0, 0.0)

    mu_q,  sigma_q  = agent_i.mu_q_field,  agent_i.sigma_q_field
    mu_p,  sigma_p  = agent_i.mu_p_field,  agent_i.sigma_p_field
    phi     = np.asarray(agent_i.phi,       np.float32)
    phi_t   = np.asarray(agent_i.phi_model, np.float32)
    base_phi = phi if field == "phi" else phi_t

    exp_this, exp_other, Jinv, _, G_q, G_p = exp_and_jinv_single(
        ctx, agent_i, field, base_phi, generators_q, generators_p
    )

    Phi_tilde = Phi_cached(ctx, agent_i, kind="p_to_q")
    mu_p_push  = getattr(agent_i, "_mu_p_push",         None)
    A_inv_push = getattr(agent_i, "_Sigma_p_push_inv",  None)
    if (mu_p_push is None) or (A_inv_push is None):
        mu_p_push, _, A_inv_push = push_gaussian(
            mu=mu_p, Sigma=sigma_p, M=Phi_tilde,
            eps=eps, return_inv=True, assume_orthogonal=False
        )
        setattr(agent_i, "_mu_p_push",        mu_p_push.astype(np.float32, copy=False))
        setattr(agent_i, "_Sigma_p_push_inv", A_inv_push.astype(np.float32, copy=False))

    Fi = getattr(agent_i, fisher_inv_key, None)
    Fi = np.eye(base_phi.shape[-1], dtype=np.float32) if Fi is None else np.asarray(Fi, np.float32, order="C")

    total = np.zeros_like(base_phi, dtype=np.float32)
    self_n = 0.0
    fb_n   = 0.0

    if alpha > 0.0 and phi_self_func is not None:
        g_param = phi_self_func(
            mu_q=mu_q, sigma_q=sigma_q,
            mu_p=mu_p, sigma_p=sigma_p,
            Phi_tilde_0=getattr(agent_i, "Phi_tilde_0", None),
            phi=phi, phi_tilde=phi_t,
            generators_q=G_q, generators_p=G_p,
            exp_phi=exp_this if field == "phi" else exp_other,
            exp_phi_tilde=exp_other if field == "phi" else exp_this,
            Phi_tilde=Phi_tilde,
            A_inv_cached=A_inv_push,
            mu_t_cached=mu_p_push,
            eps=eps,
        )
        g_body = np.einsum("...ji,...j->...i", Jinv, g_param, optimize=True)
        v_body = np.einsum("...ab,...b->...a", Fi,   g_body,  optimize=True)
        v_param= np.einsum("...ab,...b->...a", Jinv, v_body,  optimize=True)
        contrib = (alpha * v_param * mask3)
        total  += contrib.astype(np.float32, copy=False)
        self_n  = float(np.sum(np.abs(contrib)))

    if fbw > 0.0 and phi_feedback_func is not None:
        g_param = phi_feedback_func(
            mu_p=mu_p, sigma_p=sigma_p,
            mu_q=mu_q, sigma_q=sigma_q,
            Phi_0=getattr(agent_i, "Phi_0", None),
            phi=phi, phi_tilde=phi_t,
            exp_phi=exp_this if field == "phi" else exp_other,
            exp_phi_tilde=exp_other if field == "phi" else exp_this,
            eps=eps,
            generators_q=G_q, generators_p=G_p,
        )
        g_body = np.einsum("...ji,...j->...i", Jinv, g_param, optimize=True)
        v_body = np.einsum("...ab,...b->...a", Fi,   g_body,  optimize=True)
        v_param= np.einsum("...ab,...b->...a", Jinv, v_body,  optimize=True)
        contrib = (fbw * v_param * mask3)
        total  += contrib.astype(np.float32, copy=False)
        fb_n    = float(np.sum(np.abs(contrib)))

    return total.astype(np.float32, copy=False), (self_n, fb_n)


#==============================================================================
#
#                    WITH RESPECT TO phi_i TERMS
#                       VALIDATED
#==============================================================================



def grad_kl_wrt_phi_i(
    mu_i, sigma_i,
    mu_j, sigma_j,                 
    phi_i, phi_j,                  
    Omega_ij,
    generators,
    exp_phi_i,
    exp_phi_j,
    mu_j_t,                        
    sigma_j_t_inv,                 
    eps=1e-8,
    exp_neg_phi_j=None,
    Q_all=None,
):
        
    # ---- cast to f64 for internal math ----
    mu_i   = np.asarray(mu_i,   np.float64)
    mu_j_t = np.asarray(mu_j_t, np.float64)

    Sigma_i = sanitize_sigma(np.asarray(sigma_i, np.float64), eps=eps)
   
    # Q_all → (..., a, K, K)
    if Q_all is None:
        Q_all = d_exp_exact(np.asarray(phi_i, np.float64), generators)
    
    Q = np.stack([np.asarray(x, np.float64) for x in Q_all], axis=-3)

    # exp(-phi_j) broadcast to Q lead dims
    if exp_neg_phi_j is None:
        exp_neg_phi_j = safe_omega_inv(np.asarray(exp_phi_j, np.float64))
   
    # Ω and Ω^{-1}
    Om   = np.asarray(Omega_ij, np.float64)
    Oinv = safe_omega_inv(Om).astype(np.float64, copy=False)

    # Sanity on provided precision
    Sj_inv = np.asarray(sigma_j_t_inv, np.float64)
    
    Sj_inv = 0.5 * (Sj_inv + np.swapaxes(Sj_inv, -1, -2))
    
    # Core pieces
    delta_mu = (mu_i - mu_j_t)                     # (..., K)
    mu_j_src = np.einsum("...ij,...j->...i", Oinv, mu_j_t, optimize=True)  # (..., K)

    # dΩ/dφ_i^a = Q[a] @ e^{-φ_j}
    Q = np.einsum("...aik,...kj->...aij", Q, exp_neg_phi_j, optimize=True)
    Q_T = np.swapaxes(Q, -1, -2)
   
    # dΩ Ω^{-1}
    Q_tilde   = np.einsum("...aik,...kj->...aij", Q, Oinv, optimize=True)  
    Qtilde_T  = np.swapaxes(Q_tilde, -1, -2)
    
    # ---- precision (trace) term:  -1/2 * ⟨ A, Q̃ Σ_i + Σ_i Q̃^T ⟩
    t1 = np.einsum("...ij,...ajk,...ki->...a", Sj_inv, Q_tilde,  Sigma_i, optimize=True)
    t2 = np.einsum("...aij,...jk, ...ki->...a", Qtilde_T, Sj_inv, Sigma_i, optimize=True)
    trace_term = -0.5 * (t1 + t2)
    
    # mean term
    tmp1 = np.einsum("...aij,...j->...ai", Q_T,    delta_mu, optimize=True)
    tmp2 = np.einsum("...ij,...aj->...ai", Sj_inv, tmp1,     optimize=True)
    mean_term = -np.einsum("...i,...ai->...a", mu_j_src, tmp2, optimize=True)
    
    # ---- Mahalanobis (through ∂A) term: +1/2 * Δμ^T ( A Q̃ + Q̃^T A ) Δμ
    v1 = np.einsum("...ij,...j->...i", Sj_inv, delta_mu, optimize=True)          # A Δμ
    part1 = np.einsum("...aij,...j->...ai", Qtilde_T, v1, optimize=True)         # Q̃^T A Δμ
    v2    = np.einsum("...aij,...j->...ai", Q_tilde,  delta_mu, optimize=True)   # Q̃ Δμ
    part2 = np.einsum("...ij,...aj->...ai", Sj_inv,   v2, optimize=True)         # A Q̃ Δμ
    mahal_term = 0.5 * np.einsum("...i,...ai->...a", delta_mu, part1 + part2, optimize=True)

    grad = (trace_term + mean_term + mahal_term)

    return grad


def grad_kl_wrt_phi_j(
    mu_i, sigma_i,
    mu_j, sigma_j,                  # not used directly; kept for parity
    phi_i, phi_j,                   # not used directly here; we use exp(phi_*)
    Omega_ij,
    generators,
    exp_phi_i,
    exp_phi_j,
    mu_j_t,                         # μ_j' = Ω_ij μ_j
    sigma_j_t_inv,                  # Σ_j'^(-1) (already pushed)
    eps=1e-8,
    exp_neg_phi_j=None,
    R_all=None,                     # d exp(φ_j)/d φ_j^b (list/array of matrices); if None, we compute
):
    """
    ∂/∂φ_j KL(q_i || Ω_ij q_j). Mirrors grad_kl_wrt_phi_i but with:
      dΩ/dφ_j^b = - Ω  * ( R_j[b] @ e^{-φ_j} ).
    We work with U := dΩ and Ũ := (dΩ) Ω^{-1} = - Ω R̃ Ω^{-1}.
    """
    import numpy as np
    mu_i   = np.asarray(mu_i,   np.float64)
    mu_j_t = np.asarray(mu_j_t, np.float64)

    # sanitize Σ_i only once here
    Sigma_i = sanitize_sigma(np.asarray(sigma_i, np.float64), eps=eps)

    Om   = np.asarray(Omega_ij, np.float64)
    Oinv = safe_omega_inv(Om).astype(np.float64, copy=False)

    Sj_inv = np.asarray(sigma_j_t_inv, np.float64)
    Sj_inv = 0.5 * (Sj_inv + np.swapaxes(Sj_inv, -1, -2))

    # Δμ and μ_j in source coords
    delta_mu = (mu_i - mu_j_t)                                     # (..., K)
    mu_j_src = np.einsum("...ij,...j->...i", Oinv, mu_j_t, optimize=True)

    # exp(-φ_j)
    if exp_neg_phi_j is None:
        exp_neg_phi_j = safe_omega_inv(np.asarray(exp_phi_j, np.float64))

    # R_all: d exp(φ_j)/d φ_j^b  → stack as (..., b, K, K)
    if R_all is None:
        R_all = d_exp_exact(np.asarray(phi_j, np.float64), generators)
    R = np.stack([np.asarray(x, np.float64) for x in R_all], axis=-3)   # (..., b, K, K)

    # R̃_b = R_b @ e^{-φ_j}
    R_tilde = np.einsum("...bik,...kj->...bij", R, exp_neg_phi_j, optimize=True)  # (..., b, K, K)

    # U := dΩ = - Ω R̃ ;   U^T;  and Ũ := (dΩ) Ω^{-1} = - Ω R̃ Ω^{-1}
    U       = -np.einsum("...ik,...bkj->...bij", Om, R_tilde, optimize=True)      # (..., b, K, K)
    U_T     = np.swapaxes(U, -1, -2)
    U_tilde = -np.einsum("...ik,...bkj,...jl->...bil", Om, R_tilde, Oinv, optimize=True)
    Utilde_T= np.swapaxes(U_tilde, -1, -2)

    # -------- precision (trace) term:  -1/2 ⟨ A, Ũ Σ_i + Σ_i Ũ^T ⟩
    t1 = np.einsum("...ij,...bij,...jk->...b", Sj_inv, U_tilde, Sigma_i, optimize=True)
    t2 = np.einsum("...bij,...jk,...ki->...b", Utilde_T, Sj_inv, Sigma_i, optimize=True)
    trace_term = -0.5 * (t1 + t2)

    # -------- mean term (through dμ' = U μ_j_src)
    # tmp1_bi = U^T_bij Δμ_j'^j
    tmp1 = np.einsum("...bij,...j->...bi", U_T, delta_mu, optimize=True)
    # tmp2_bi = A_{ik} tmp1_bk
    tmp2 = np.einsum("...ij,...bj->...bi", Sj_inv, tmp1, optimize=True)
    mean_term = -np.einsum("...i,...bi->...b", mu_j_src, tmp2, optimize=True)

    # -------- Mahalanobis term: +1/2 Δμ^T ( A Ũ + Ũ^T A ) Δμ
    v1 = np.einsum("...ij,...j->...i", Sj_inv, delta_mu, optimize=True)            # A Δμ
    part1 = np.einsum("...bij,...j->...bi", Utilde_T, v1, optimize=True)           # Ũ^T A Δμ
    v2    = np.einsum("...bij,...j->...bi", U_tilde,  delta_mu, optimize=True)     # Ũ Δμ
    part2 = np.einsum("...ij,...bj->...bi", Sj_inv,   v2, optimize=True)           # A Ũ Δμ
    mahal_term = 0.5 * np.einsum("...i,...bi->...b", delta_mu, part1 + part2, optimize=True)

    grad = (trace_term + mean_term + mahal_term)    # (..., b)
    return grad




def grad_self_phi_direct(
    mu_q, sigma_q, mu_p, sigma_p, Phi_tilde_0,
    phi, phi_tilde, generators_q, generators_p,
    exp_phi, exp_phi_tilde, *,
    eps=1e-8,
    
    Phi_tilde=None,          # (H,W,K_q,K_p) from cache
    A_inv_cached=None,       # (H,W,K_q,K_q)  inverse of Φ̃ Σ_p Φ̃ᵀ
    mu_t_cached=None,        # (H,W,K_q)      Φ̃ μ_p
    Q_all=None,
    exp_neg_phi_tilde=None
):
    d, K_q, _ = generators_q.shape

    # Inverse of exp_phi_tilde if needed for dΦ̃
    if exp_neg_phi_tilde is None:
        #print("exp-phi~ is none\n\n\n")
        exp_neg_phi_tilde = safe_omega_inv(exp_phi_tilde)

    # Derivative blocks (still need these)
    if Q_all is None:
        #print("q-all is none\n\n\n")
        Q_all = np.stack(d_exp_exact(phi, generators_q), axis=-3)  # (..., d, K_q, K_q)

    # Pull Φ̃ from cache (or build only if missing)
    if Phi_tilde is None:
        #print("Phi~ is none\n\n\n")
        Phi_tilde = np.einsum("...ik,...kj,...jl->...il",
                              exp_phi, Phi_tilde_0, exp_neg_phi_tilde, optimize=True)

    Phi_tilde_T = np.swapaxes(Phi_tilde, -1, -2)

    # A^{-1} and Φ̃ μ_p: reuse when provided
    if (A_inv_cached is None) or (mu_t_cached is None):
        #print("pushes are none\n\n\n")
        mu_t, _, A_inv = push_gaussian(
            mu=mu_p, Sigma=sigma_p, M=Phi_tilde,
            eps=eps, return_inv=True, assume_orthogonal=False
        )
    else:
        mu_t, A_inv = mu_t_cached, A_inv_cached

    delta_mu = mu_q - mu_t

    # ∂Φ̃_a = Q_a Φ̃₀ e^{-φ̃}
    dPhi = np.einsum("...aik,...kj,...jl->...ail", Q_all, Phi_tilde_0, exp_neg_phi_tilde, optimize=True)
    dPhi_T = np.swapaxes(dPhi, -1, -2)

    # dA = dΦ̃ Σ_p Φ̃ᵀ + Φ̃ Σ_p dΦ̃ᵀ
    dA = (
        np.einsum("...aik,...kl,...lj->...aij", dPhi,       sigma_p, Phi_tilde_T, optimize=True) +
        np.einsum("...ik, ...kl,...alj->...aij", Phi_tilde, sigma_p, dPhi_T,      optimize=True)
    )

    # term1: - (∂Φ̃ μ_p)^T A^{-1} Δμ
    dPhi_mu_p = np.einsum("...aij,...j->...ai", dPhi, mu_p, optimize=True)
    term1 = -np.einsum("...ai,...i->...a",
                       dPhi_mu_p,
                       np.einsum("...ij,...j->...i", A_inv, delta_mu, optimize=True),
                       optimize=True)

    # term2: + 1/2 tr(A^{-1} dA)
    term2 = 0.5 * np.einsum("...ij,...aij->...a", A_inv, dA, optimize=True)

    # M = A^{-1} dA A^{-1}
    M = np.einsum("...ij,...ajk,...kl->...ail", A_inv, dA, A_inv, optimize=True)

    # term3: - 1/2 Δμ^T M Δμ
    term3 = -0.5 * np.einsum("...i,...aij,...j->...a", delta_mu, M, delta_mu, optimize=True)

    # term4: - 1/2 tr(M Σ_q)
    term4 = -0.5 * np.einsum("...aij,...ji->...a", M, sigma_q, optimize=True)

    return (term1 + term2 + term3 + term4).astype(np.float32, copy=False)




def grad_self_phi_tilde_direct(
    mu_q, sigma_q, mu_p, sigma_p, Phi_tilde_0,
    phi, phi_tilde, generators_q, generators_p,
    exp_phi, exp_phi_tilde, *,
    eps=1e-8,
    Phi_tilde=None,          # cached (S*,K_q,K_p)
    A_inv_cached=None,       # cached (S*,K_q,K_q)
    mu_t_cached=None,        # cached Φ̃ μ_p
    Q_tilde_all=None,
    exp_neg_phi_tilde=None
):
    d, K_p, _ = generators_p.shape

    if exp_neg_phi_tilde is None:
        #print("e^-phi~ is none\n\n\n")
        exp_neg_phi_tilde = safe_omega_inv(exp_phi_tilde)

    if Q_tilde_all is None:
        #print("Q~-all is none\n\n\n")
        Q_tilde_all = np.stack(d_exp_exact(phi_tilde, generators_p), axis=-3)

    if Phi_tilde is None:
        #print("Phi~ is none\n\n\n")
        Phi_tilde = np.einsum("...ik,...kj,...jl->...il",
                              exp_phi, Phi_tilde_0, exp_neg_phi_tilde, optimize=True)
    Phi_tilde_T = np.swapaxes(Phi_tilde, -1, -2)

    if (A_inv_cached is None) or (mu_t_cached is None):
        mu_t, _, A_inv = push_gaussian(
            mu=mu_p, Sigma=sigma_p, M=Phi_tilde,
            eps=eps, return_inv=True, assume_orthogonal=False
        )
    else:
        mu_t, A_inv = mu_t_cached, A_inv_cached

    delta_mu = mu_q - mu_t

    # R_a = Q̃_a e^{-φ̃}, dΦ̃_a = - Φ̃ R_a
    R    = np.einsum("...aik,...kj->...aij", Q_tilde_all, exp_neg_phi_tilde, optimize=True)
    dPhi = -np.einsum("...ik,...akj->...aij", Phi_tilde, R, optimize=True)
    dPhi_T = np.swapaxes(dPhi, -1, -2)

    dA = (
        np.einsum("...aik,...kl,...lj->...aij", dPhi,       sigma_p, Phi_tilde_T, optimize=True) +
        np.einsum("...ik, ...kl,...alj->...aij", Phi_tilde, sigma_p, dPhi_T,      optimize=True)
    )

    dPhi_mu_p = np.einsum("...aij,...j->...ai", dPhi, mu_p, optimize=True)
    term1 = -np.einsum("...ai,...i->...a",
                       dPhi_mu_p,
                       np.einsum("...ij,...j->...i", A_inv, delta_mu, optimize=True),
                       optimize=True)

    term2 = 0.5 * np.einsum("...ij,...aij->...a", A_inv, dA, optimize=True)

    M = np.einsum("...ij,...ajk,...kl->...ail", A_inv, dA, A_inv, optimize=True)

    term3 = -0.5 * np.einsum("...i,...aij,...j->...a", delta_mu, M, delta_mu, optimize=True)
    term4 = -0.5 * np.einsum("...aij,...ji->...a", M, sigma_q, optimize=True)

    return (term1 + term2 + term3 + term4).astype(np.float32, copy=False)







def grad_feedback_phi_direct(
    mu_p, sigma_p,
    mu_q, sigma_q,
    Phi_0,
    phi,                # (..., d)
    phi_tilde,          # (..., d)
    generators_q,       # (d, K_q, K_q)
    generators_p,
    exp_phi,            # (..., K_q, K_q)
    exp_phi_tilde,      # (..., K_p, K_p)
    eps=1e-8,
    Q_all=None,         # (..., d, K_q, K_q) = d_exp_exact(phi, generators_q)
    exp_neg_phi=None    # (..., K_q, K_q) = e^{-φ}
):
    """
    Vectorized over 'a': returns (..., d)
    Φ = e^{φ̃} Φ₀ e^{-φ}, ∂Φ = - Φ · (e^{-φ} (∂ e^{φ}) e^{-φ})
    """
    
    d, K_q, _ = generators_q.shape

    if exp_neg_phi is None:
        exp_neg_phi = safe_omega_inv(exp_phi)
    if Q_all is None:
        # stack as (..., d, K_q, K_q)
        Q_list = d_exp_exact(phi, generators_q)
        Q_all = np.stack(Q_list, axis=-3)  # assuming list of d arrays

    # Φ and Φᵀ
    Phi = np.einsum("...ik,...kj,...jl->...il", exp_phi_tilde, Phi_0, exp_neg_phi)
    Phi_T = np.swapaxes(Phi, -1, -2)

    # A, A^{-1}
    A = np.einsum("...ik,...kl,...lj->...ij", Phi, sigma_q, Phi_T)
    A = sanitize_sigma(A, eps=eps)
    A_inv = safe_inv(A, eps=eps)

    # Δμ and v
    Phi_mu_q = np.einsum("...ij,...j->...i", Phi, mu_q)
    delta_mu = mu_p - Phi_mu_q
    v = np.einsum("...ij,...j->...i", A_inv, delta_mu)  # (..., K_p)

    # Q̄_a = e^{-φ} Q_a e^{-φ}
    Q_bar = np.einsum("...ik,...akl,...lj->...aij", exp_neg_phi, Q_all, exp_neg_phi)

    # dΦ_a = - Φ Q̄_a
    dPhi = -np.einsum("...ik,...akj->...aij", Phi, Q_bar)
    dPhi_T = np.swapaxes(dPhi, -1, -2)

    # dA_a
    dA = (
        np.einsum("...aik,...kl,...lj->...aij", dPhi, sigma_q, Phi_T) +
        np.einsum("...ik,...kl,...alj->...aij", Phi,  sigma_q, dPhi_T)
    )

    # Term 1
    dPhi_mu = np.einsum("...aij,...j->...ai", dPhi, mu_q)       # (..., a, K_p)
    term1 = -np.einsum("...ai,...i->...a", dPhi_mu, v)

    # Term 2
    term2 = 0.5 * np.einsum("...ij,...aij->...a", A_inv, dA)

    # M_a = A^{-1} dA_a A^{-1}
    M = np.einsum("...ij,...ajk,...kl->...ail", A_inv, dA, A_inv)

    # Term 3
    term3 = -0.5 * np.einsum("...i,...aij,...j->...a", delta_mu, M, delta_mu)

    # Term 4
    term4 = -0.5 * np.einsum("...aij,...ji->...a", M, sigma_p)

    grad = (term1 + term2 + term3 + term4).astype(np.float32, copy=False)
    return grad




def grad_feedback_phi_tilde_direct(
    mu_p, sigma_p,
    mu_q, sigma_q,
    Phi_0,
    phi, 
    phi_tilde,
    generators_q, 
    generators_p,
    exp_phi, 
    exp_phi_tilde,
    eps=1e-8,
    Q_tilde_all=None,       # (..., d, K_p, K_p) = d_exp_exact(phi_tilde, generators_p)
    exp_neg_phi_tilde=None  # (..., K_p, K_p) = e^{-φ̃}
):
    """
    Vectorized over 'a': returns (..., d)
    Left-trivialize: dΦ_a = L_a Φ,  L_a = (∂e^{φ̃}/∂φ̃^a) e^{-φ̃}.
    """
    
    d, K_p, _ = generators_p.shape
    
    if exp_neg_phi_tilde is None:
        exp_neg_phi_tilde = safe_omega_inv(exp_phi_tilde)
    if Q_tilde_all is None:
        Q_list = d_exp_exact(phi_tilde, generators_p)
        Q_tilde_all = np.stack(Q_list, axis=-3)

    # Φ
    exp_neg_phi = safe_omega_inv(exp_phi)
    Phi   = np.einsum("...ik,...kj,...jl->...il", exp_phi_tilde, Phi_0, exp_neg_phi)
    Phi_T = np.swapaxes(Phi, -1, -2)

    
    A = np.einsum("...ik,...kl,...lj->...ij", Phi, sigma_q, Phi_T)
    A = sanitize_sigma(A, eps=eps)
    A_inv = safe_inv(A, eps=eps)

    Phi_mu_q = np.einsum("...ij,...j->...i", Phi, mu_q)
    delta_mu = mu_p - Phi_mu_q
    v = np.einsum("...ij,...j->...i", A_inv, delta_mu)

    # L_a = Q̃_a e^{-φ̃}
    L = np.einsum("...aik,...kj->...aij", Q_tilde_all, exp_neg_phi_tilde)

    # dΦ_a = L_a Φ
    dPhi = np.einsum("...aik,...kj->...aij", L, Phi)
    dPhi_T = np.swapaxes(dPhi, -1, -2)

    dA = (
        np.einsum("...aik,...kl,...lj->...aij", dPhi, sigma_q, Phi_T) +
        np.einsum("...ik,...kl,...alj->...aij", Phi,  sigma_q, dPhi_T)
    )

    dPhi_mu = np.einsum("...aij,...j->...ai", dPhi, mu_q)
    term1 = -np.einsum("...ai,...i->...a", dPhi_mu, v)

    term2 = 0.5 * np.einsum("...ij,...aij->...a", A_inv, dA)

    M = np.einsum("...ij,...ajk,...kl->...ail", A_inv, dA, A_inv)

    term3 = -0.5 * np.einsum("...i,...aij,...j->...a", delta_mu, M, delta_mu)
    term4 = -0.5 * np.einsum("...aij,...ji->...a", M, sigma_p)

    grad = term1 + term2 + term3 + term4
    return grad







   



def grad_gamma_A_phi_covectors(
    *,
    Eqi, Eqj, Epi,
    mu_q_j, Sigma_q_j,
    mu_p_i, Sigma_p_i,
    generators_irrep,
    eps: float = 1e-8,
    orthonormalize: bool = True,
    **_ignored,
):
    """
    Case A (dual): KL_gamma = KL( q_j || Ω^q_{ji} Φ̃_i p_i )  in Q_j.
    Using frame factorization R = Eq(j) @ Ep(i)^T.
    Returns (g_phi_i_q_cov, g_phi_j_q_cov, g_phi_i_p_cov) each (*S,3).
    """
   
    # -------------------------------------------------------------------------
    # Exact factorization for Case B:
    # Φ_i = E_p(i) E_q(i)^T,  Ω_ij = E_q(i) E_q(j)^T  ⇒  R = Φ_i Ω_ij = E_p(i) E_q(j)^T
    # Landing in P_i:  μ_L = R μ_j,  Σ_L = R Σ_j R^T
    # KL: KL( N(μ_p,Σ_p) || N(μ_L,Σ_L) )
    # Target-form partials:
    #   v = Σ_L^{-1}(μ_p - μ_L)
    #   ∂KL/∂μ_L = -v
    #   ∂KL/∂Σ_L = 1/2( -Σ_L^{-1} Σ_p Σ_L^{-1} - v v^T + Σ_L^{-1} )
    # Chain rule:
    #   ∂KL/∂R = (∂KL/∂μ_L) μ_j^T + 2 (∂KL/∂Σ_L) R Σ_j
    # Split:
    #   dR = dE_p E_q(j)^T + E_p dE_q(j)^T  ⇒
    #   <G_R, dR> = <G_R E_q(j), dE_p> + <G_R^T E_p, dE_q(j)> ;  G_Eq(i) = 0 exactly.
    # -------------------------------------------------------------------------

    # float64 for stability
    Eqi = np.asarray(Eqi, np.float64, order="C")
    Eqj = np.asarray(Eqj, np.float64, order="C")
    Epi = np.asarray(Epi, np.float64, order="C")
    mu_j = np.asarray(mu_q_j,    np.float64, order="C")
    Sj   = sanitize_sigma(np.asarray(Sigma_q_j, np.float64), eps=eps)
    mu_p = np.asarray(mu_p_i,    np.float64, order="C")
    Sp   = sanitize_sigma(np.asarray(Sigma_p_i, np.float64), eps=eps)

    if orthonormalize:
        # push frames gently back to O(K) to better match ctx Ω/Φ path
        U, _, Vt = np.linalg.svd(Eqj, full_matrices=False);  Eqj = np.einsum("...ik,...kj->...ij", U, Vt, optimize=True)
        U, _, Vt = np.linalg.svd(Epi, full_matrices=False);  Epi = np.einsum("...ik,...kj->...ij", U, Vt, optimize=True)

    Rt = np.swapaxes

    # R = Eq(j) Ep(i)^T : (*S, Kq, Kp)
    R = np.einsum("...ik,...jk->...ij", Eqj, Rt(Epi, -1, -2), optimize=True)

    # Landed in Q_j
    mu_Q = np.einsum("...ij,...j->...i", R, mu_p, optimize=True)                       # (*S,Kq)
    S_Q  = np.einsum("...ij,...jk,...lk->...il", R, Sp, R, optimize=True)              # R Σ_p R^T
    S_Q  = sanitize_sigma(S_Q, eps=eps)
    S_Qi = safe_inv(S_Q, eps=max(eps, 1e-12))

    # KL(P||Q): P=N(mu_j,Sj), Q=N(mu_Q,S_Q)
    d     = mu_Q - mu_j
    v     = np.einsum("...ij,...j->...i", S_Qi, d, optimize=True)   # = dmuQ
    vvT   = np.einsum("...i,...j->...ij", v, v, optimize=True)
    term  = np.einsum("...ij,...jk->...ik", S_Qi,
                      np.einsum("...jk,...kl->...jl", Sj, S_Qi, optimize=True),
                      optimize=True)
    dSQ   = 0.5 * (-term - vvT + S_Qi)
    dSQ   = 0.5 * (dSQ + Rt(dSQ, -1, -2))

    # ∂KL/∂R
    G_R  = (np.einsum("...i,...j->...ij", v, mu_p, optimize=True)
            + 2.0 * np.einsum("...ij,...jk,...kl->...il", dSQ, R, Sp, optimize=True))  # (*S,Kq,Kp)

    # Split co-grads
    G_Eqj = np.einsum("...ij,...jk->...ik", G_R, Epi, optimize=True)                   # (*S,Kq,Kq)
    G_Epi = np.einsum("...ji,...jk->...ik", Rt(G_R, -1, -2), Eqj, optimize=True)       # (*S,Kp,Kp)
    G_Eqi = np.zeros_like(Eqi, dtype=np.float64)

    # Mat co-grads → parameter covectors
    g_phi_i_q_cov = matrix_cograd_to_param_covector_irrep(Eqi, G_Eqi, generators_irrep)  # zeros
    g_phi_j_q_cov = matrix_cograd_to_param_covector_irrep(Eqj, G_Eqj, generators_irrep)
    g_phi_i_p_cov = matrix_cograd_to_param_covector_irrep(Epi, G_Epi, generators_irrep)

    return (np.asarray(g_phi_i_q_cov, np.float32, order="C"),
            np.asarray(g_phi_j_q_cov, np.float32, order="C"),
            np.asarray(g_phi_i_p_cov, np.float32, order="C"))



def grad_gamma_B_phi_covectors(
    *,
    Eqi, Eqj, Epi,
    mu_p_i, Sigma_p_i,
    mu_q_j, Sigma_q_j,
    generators_irrep,
    eps: float = 1e-8,
    orthonormalize: bool = True,
    **_ignored,
):
    """
    Case B (P_i): KL_gamma = KL( p_i || Φ_i[Ω^q_ij q_j] )
    Using frame factorization R = E_p(i) @ E_q(j)^T.
    Returns (g_phi_i_q_cov, g_phi_j_q_cov, g_phi_i_p_cov) each (*S,3).
    """
    
    Eqi = np.asarray(Eqi, np.float64, order="C")
    Eqj = np.asarray(Eqj, np.float64, order="C")
    Epi = np.asarray(Epi, np.float64, order="C")
    mu_p = np.asarray(mu_p_i,    np.float64, order="C")
    Sp   = sanitize_sigma(np.asarray(Sigma_p_i, np.float64), eps=eps)
    mu_j = np.asarray(mu_q_j,    np.float64, order="C")
    Sj   = sanitize_sigma(np.asarray(Sigma_q_j, np.float64), eps=eps)

    if orthonormalize:
        U, _, Vt = np.linalg.svd(Eqj, full_matrices=False);  Eqj = np.einsum("...ik,...kj->...ij", U, Vt, optimize=True)
        U, _, Vt = np.linalg.svd(Epi, full_matrices=False);  Epi = np.einsum("...ik,...kj->...ij", U, Vt, optimize=True)

    Rt = np.swapaxes

    # R = E_p(i) @ E_q(j)^T : (*S, Kp, Kq)
    R = np.einsum("...ik,...jk->...ij", Epi, Rt(Eqj, -1, -2), optimize=True)

    # Landed in P_i
    mu_L = np.einsum("...ij,...j->...i", R, mu_j, optimize=True)

    RS   = np.einsum("...ij,...jk->...ik", R, Sj, optimize=True)
    S_L  = np.einsum("...ik,...jk->...ij", RS, R, optimize=True)   # R Σ_j R^T
    S_L  = 0.5 * (S_L + Rt(S_L, -1, -2))
    S_L  = sanitize_sigma(S_L, eps=eps)
    S_L_inv = safe_inv(S_L, eps=max(eps, 1e-12))

    # Target-form partials
    delta = (mu_p - mu_L)
    v     = np.einsum("...ij,...j->...i", S_L_inv, delta, optimize=True)
    dmuL  = -v

    vvT   = np.einsum("...i,...j->...ij", v, v, optimize=True)
    t0    = -np.einsum("...ij,...jk,...kl->...il", S_L_inv, Sp, S_L_inv, optimize=True)
    dSL   = 0.5 * (t0 - vvT + S_L_inv)
    dSL   = 0.5 * (dSL + Rt(dSL, -1, -2))

    # ∂KL/∂R
    G_R = (np.einsum("...i,...j->...ij", dmuL, mu_j, optimize=True)
           + 2.0 * np.einsum("...ij,...jk,...kl->...il", dSL, R, Sj, optimize=True))

    # Split
    G_Epi = np.einsum("...ij,...jk->...ik", G_R, Eqj, optimize=True)                 # (*,Kp,Kp)
    G_Eqj = np.einsum("...ji,...jk->...ik", Rt(G_R, -1, -2), Epi, optimize=True)     # (*,Kq,Kq)
    G_Eqi = np.zeros_like(Eqi, dtype=np.float64)                                     # exact 0

    # To parameter covectors
    g_phi_i_q_cov = matrix_cograd_to_param_covector_irrep(Eqi, G_Eqi, generators_irrep)  # zeros
    g_phi_j_q_cov = matrix_cograd_to_param_covector_irrep(Eqj, G_Eqj, generators_irrep)
    g_phi_i_p_cov = matrix_cograd_to_param_covector_irrep(Epi, G_Epi, generators_irrep)

    return (np.asarray(g_phi_i_q_cov, np.float32, order="C"),
            np.asarray(g_phi_j_q_cov, np.float32, order="C"),
            np.asarray(g_phi_i_p_cov, np.float32, order="C"))









def get_preconds(ctx, agent, which, fisher_inv_key: str):
    """
    Fetch (E, Jinv, Finv) for the given fiber `which` using an explicit
    Fisher^{-1} attribute name. No identity fallback.
    """
    E    = np.asarray(E_grid(ctx, agent, which=which), np.float32)

    Jinv = Jinv_grid(ctx, agent, which=which)
    if Jinv is None:
        base_phi = np.asarray(getattr(agent, "phi" if which == "q" else "phi_model"), np.float32)
        Jinv = build_dexpinv_matrix(base_phi)

    Finv = getattr(agent, fisher_inv_key, None)
    if Finv is None:
        aid = getattr(agent, "id", "?")
        raise AttributeError(
            f"Agent(id={aid}) missing required Fisher inverse '{fisher_inv_key}' "
            f"for which='{which}'. Populate this field before calling the accumulator."
        )

    Finv = np.asarray(Finv, np.float32)
    if Finv.shape != Jinv.shape:
        raise ValueError(f"Finv shape {Finv.shape} mismatches Jinv shape {Jinv.shape}")
    if not (np.isfinite(E).all() and np.isfinite(Jinv).all() and np.isfinite(Finv).all()):
        raise FloatingPointError("non-finite values in E/Jinv/Finv")
    return E, Jinv, Finv



def _accum(agent, grad_key: str, step: np.ndarray):
    prev = getattr(agent, grad_key, None)
    setattr(agent, grad_key, (np.zeros_like(step) if prev is None else prev) + step)



def _which_meta(field: str):
    meta = _FIELD_META["phi" if field in ("phi", "phi_q") else "phi_model"]
    return (
        meta["which"], meta["phi_attr"],
        meta["mu_key"], meta["sigma_key"],
        meta["fisher_inv_key"], meta["grad_key"],
    )



def _preconds_min(ctx, agent, *, which: str, fisher_inv_key: str):
    E, Jinv, Finv = get_preconds(ctx, agent, which=which, fisher_inv_key=fisher_inv_key)
    return E, Jinv, Finv



def _project_phi_cov(cov, Jinv, Finv):
    return project_phi_covector_to_step(np.asarray(cov, np.float32), Jinv, Finv)


