# -*- coding: utf-8 -*-
"""
Created on Wed Aug  6 12:27:32 2025

@author: chris and christine

Multiprocessing-safe μ/Σ gradient accumulation using pure functions.
All gradient computations use frozen GradientConfig and SharedDiskCache.
"""
 
import numpy as np
from core.beta import beta_align_maps, gamma_maps
from core.transport_cache import Omega, Phi_cached
from updates.grad_config import GradientConfig

from core.utils import (
    _fiber_keys_from_mode, _accumulate_into_agent,
    create_gradient_accum, add_gradient_term,
    get_cached_push_forward, get_cached_push_backward,
    iter_overlap_pairs, drain_inbox_pure,
    symmetrize, safe_cast_and_sanitize
)

from core.numerical_utils import (
    kl_gaussian, sanitize_sigma, safe_inv, push_gaussian, plain_rule,
    softmax_align_rule_receiver, softmax_align_rule_sender, 
)


# ============================================================================
# PUBLIC API - Multiprocessing-Compatible Entry Point
# ============================================================================




def accumulate_mu_sigma_gradient(ctx, agent_i, agents, mode):
    """
    Accumulate natural gradients (μ, Σ) for belief or model fiber.
    
    **Multiprocessing-safe:**
    - Uses frozen GradientConfig (picklable)
    - Pure functions with explicit config passing
    - SharedDiskCache for expensive pushes
    - No mutations to ctx.edge (read-only in workers)
    
    Parameters
    ----------
    ctx : RuntimeCtx
        Must have ctx.cache (SharedDiskCache) and ctx.grad_cfg (GradientConfig)
    agent_i : Agent
        Receiver agent (modified in-place: grad_mu_*, grad_sigma_*)
    agents : list[Agent]
        All agents at this level (for neighbors)
    mode : str
        "belief" or "model"
    
    Returns
    -------
    delta_mu : ndarray (*S, K)
        Natural gradient step for μ
    delta_S : ndarray (*S, K, K)
        Natural gradient step for Σ
    energy_tuple : (float, float)
        (self_raw, feedback_raw) energy contributions
    """
    if ctx is None:
        raise RuntimeError("accumulate_mu_sigma_gradient: ctx required")
    
    # Extract frozen config (built once in master, passed to workers)
    if hasattr(ctx, 'grad_cfg') and ctx.grad_cfg is not None:
        cfg = ctx.grad_cfg
    else:
        # Fallback: build on-the-fly (master process)
        cfg = GradientConfig.from_context(ctx)
    
    # Fiber-specific keys
    which, mu_key, S_key, gmu_key, gS_key = _fiber_keys_from_mode(mode)
    
    # Initialize accumulator
    mu_i = np.asarray(getattr(agent_i, mu_key), np.float32)
    accum = create_gradient_accum(mu_i.shape)
    
    # ========== PHASE 1: Self + Feedback ==========
    self_raw, fb_raw, dmu_self, dS_self, dmu_fb, dS_fb = \
        compute_self_feedback_pure(ctx, agent_i, cfg, mode)
    
    add_gradient_term(accum, "self", dmu_self, dS_self, weight=cfg.alpha)
    add_gradient_term(accum, "feedback", dmu_fb, dS_fb, weight=cfg.feedback_weight)
    
    # ========== PHASE 2: Alignment (β·KL) ==========
    dmu_align, dS_align = compute_alignment_gradients_pure(
        ctx, agent_i, agents, cfg, which, mu_key, S_key
    )
    add_gradient_term(accum, "align", dmu_align, dS_align)
    
    # ========== PHASE 3: Gamma (γ·KL) ==========
    dmu_gamma, dS_gamma = compute_gamma_gradients_pure(
        ctx, agent_i, agents, cfg, which, mu_key, S_key
    )
    add_gradient_term(accum, "gamma", dmu_gamma, dS_gamma)
    
    # ========== PHASE 4: Sender Inbox (if enabled) ==========
    if cfg.accumulate_sender_grads:
        dmu_inbox, dS_inbox = drain_inbox_pure(agent_i, which)
        add_gradient_term(accum, "inbox", dmu_inbox, dS_inbox)
    
    # ========== PHASE 5: Natural Projection ==========
    delta_mu, delta_S = apply_natural_gradient_batch(
        ctx,
        getattr(agent_i, mu_key),
        getattr(agent_i, S_key),
        accum['mu'],
        accum['S'],
        mask=getattr(agent_i, "mask", None),
        assume_sanitized=True,
        grad_sigma_is_symmetric=True,
        use_float64=True,
    )
    
    # ========== PHASE 6: Accumulate to Agent (Side Effect) ==========
    _accumulate_into_agent(agent_i, gmu_key, gS_key, delta_mu, delta_S)
    
    return delta_mu, delta_S, (float(self_raw), float(fb_raw))


# ============================================================================
# Self + Feedback (Pure)
# ============================================================================

def compute_self_feedback_pure(ctx, agent_i, cfg, mode):
    """
    Compute self and feedback gradients using cached pushes.
    
    Returns
    -------
    self_raw : float
        Self energy contribution
    fb_raw : float
        Feedback energy contribution
    dmu_self : ndarray
    dS_self : ndarray
    dmu_fb : ndarray
    dS_fb : ndarray
    """
    # Get fields
    mu_q = agent_i.mu_q_field
    S_q = agent_i.sigma_q_field
    mu_p = agent_i.mu_p_field
    S_p = agent_i.sigma_p_field
    
    # Get cached pushes (process-safe via SharedDiskCache)
    mu_q_push, S_q_push, inv_q_push = get_cached_push_forward(ctx, agent_i, eps=cfg.eps)
    mu_p_push, S_p_push, inv_p_push = get_cached_push_backward(ctx, agent_i, eps=cfg.eps)
    
    # Precompute inverses if not cached
    sigma_q_inv = getattr(agent_i, "sigma_q_inv", None)
    if sigma_q_inv is None:
        sigma_q_inv = safe_inv(sanitize_sigma(S_q, eps=cfg.eps), eps=cfg.eps)
    
    sigma_p_inv = getattr(agent_i, "sigma_p_inv", None)
    if sigma_p_inv is None:
        sigma_p_inv = safe_inv(sanitize_sigma(S_p, eps=cfg.eps), eps=cfg.eps)
    
    # Energy accounting (for diagnostics)
    mask = getattr(agent_i, "mask", None)
    if mask is not None:
        mm = (np.asarray(mask) > cfg.tau)
        if np.any(mm):
            self_kl = kl_gaussian(mu_q[mm], S_q[mm], mu_p_push[mm], S_p_push[mm], eps=cfg.eps)
            fb_kl = kl_gaussian(mu_p[mm], S_p[mm], mu_q_push[mm], S_q_push[mm], eps=cfg.eps)
            self_raw = float(np.sum(self_kl))
            fb_raw = float(np.sum(fb_kl))
        else:
            self_raw, fb_raw = 0.0, 0.0
    else:
        self_raw, fb_raw = 0.0, 0.0
    
    # Gradients
    if mode == "belief":
        dmu_self, dS_self = grad_self_energy_belief(
            mu_q, S_q, mu_p_push, inv_p_push,
            sigma_q_inv=sigma_q_inv, mask=mask
        )
        dmu_fb, dS_fb = grad_feedback_energy_belief(
            mu_q, S_q, mu_p, mu_q_push,
            S_q_push, inv_q_push, S_p, Phi_cached(ctx, agent_i, kind="q_to_p")
        )
    else:  # model
        Phi_tilde = Phi_cached(ctx, agent_i, kind="p_to_q")
        dmu_self, dS_self = grad_self_energy_model(
            mu_q, S_q, mu_p_push, inv_p_push, Phi_tilde, mask=mask
        )
        dmu_fb, dS_fb = grad_feedback_energy_model(
            mu_p, S_p, mu_q_push, S_q_push, inv_q_push,
            sigma_p_inv=sigma_p_inv
        )
    
    return self_raw, fb_raw, dmu_self, dS_self, dmu_fb, dS_fb


# ============================================================================
# Alignment Block (Pure)
# ============================================================================

def compute_alignment_gradients_pure(ctx, agent_i, agents, cfg, which, mu_key, S_key):
    """
    β-weighted alignment gradients with exact softmax product rule (MATCHES OLD VERSION).
    
    Returns
    -------
    dmu_align : ndarray (*S, K)
    dS_align : ndarray (*S, K, K)
    """
    
    
    # Precompute receiver stats once
    mu_i_arr = np.asarray(getattr(agent_i, mu_key), np.float32, order="C")
    S_i_arr = sanitize_sigma(
        np.asarray(getattr(agent_i, S_key), np.float64), eps=cfg.eps
    ).astype(np.float32, copy=False)
    
    dmu_align = np.zeros_like(mu_i_arr, dtype=np.float32)
    dS_align = np.zeros_like(S_i_arr, dtype=np.float32)
    
    # Accumulators for global gbar
    Sshape = tuple(mu_i_arr.shape[:-1])
    Ki = int(mu_i_arr.shape[-1])
    gbar_mu_i = np.zeros(Sshape + (Ki,), np.float32)
    gbar_S_i = np.zeros(Sshape + (Ki, Ki), np.float32)
    
    pairs = []
    
    # ===========================================================================
    # PASS 1: Accumulate gbar and compute raw gradients for ALL pairs
    # ===========================================================================
    for agent_j, overlap in iter_overlap_pairs(agent_i, agents, cfg.tau, which, mu_key, ctx):
        if not np.any(overlap):
            continue
        
        # Get alignment maps
        KL1_map, beta_map = beta_align_maps(ctx, agent_i, agent_j, which=which)
        
        m = overlap.astype(np.float32, copy=False)
        beta_ij = beta_map * m
        KL1 = KL1_map * m
        
        if not np.any(beta_ij > 0):
            continue
        
        # Get transport
        Om_align = Omega(ctx, agent_i, agent_j, which=which)
        
        # Get neighbor stats
        mu_j_arr = np.asarray(getattr(agent_j, mu_key), np.float32, order="C")
        S_j_arr = sanitize_sigma(
            np.asarray(getattr(agent_j, S_key), np.float64), eps=cfg.eps
        ).astype(np.float32, copy=False)
        
        # Push j through transport
        mu_j_t, S_j_t, inv_j_t = push_gaussian(
            mu_j_arr, S_j_arr, Om_align, eps=cfg.eps, return_inv=True, sanitize_input=False
        )
        
        # Compute raw receiver gradient (source side)
        dmu = mu_i_arr - mu_j_t
        gmu_align = np.einsum("...ij,...j->...i", inv_j_t, dmu, optimize=True)
        
        S_i_inv = safe_inv(S_i_arr, eps=cfg.eps)
        gS_align = 0.5 * (inv_j_t - S_i_inv)
        gS_align = 0.5 * (gS_align + np.swapaxes(gS_align, -1, -2))  # symmetrize
        
        # Compute raw sender gradient (target side)
        v = np.einsum("...ij,...j->...i", inv_j_t, dmu, optimize=True)
        gmu_align_j = np.einsum("...ji,...j->...i", Om_align, v, optimize=True)
        
        vvT = np.einsum("...i,...j->...ij", v, v, optimize=True)
        dS_jt = inv_j_t - vvT
        gS_align_j = np.einsum("...ki,...kl,...jl->...ij", 
                               Om_align, dS_jt, Om_align, optimize=True)
        gS_align_j = 0.5 * (gS_align_j + np.swapaxes(gS_align_j, -1, -2))
        
        # Accumulate β-weighted averages for gbar
        gbar_mu_i += beta_ij[..., None] * gmu_align
        gbar_S_i += beta_ij[..., None, None] * gS_align
        
        # Store for second pass
        pairs.append({
            'j': agent_j,
            'overlap': overlap,
            'beta_ij': beta_ij,
            'KL1': KL1,
            'gmu_align': gmu_align,
            'gS_align': gS_align,
            'gmu_align_j': gmu_align_j,
            'gS_align_j': gS_align_j,
        })
    
    # ===========================================================================
    # PASS 2: Apply exact softmax product rule with global gbar
    # ===========================================================================
    kappa = max(float(cfg.beta_kappa_q if which == "q" else cfg.beta_kappa_p), 1e-12)
    
    for P in pairs:
        agent_j = P["j"]
        overlap = P["overlap"]
        beta_ij = P["beta_ij"]
        KL1 = P["KL1"]
        gmu_align = P["gmu_align"]
        gS_align = P["gS_align"]
        gmu_align_j = P["gmu_align_j"]
        gS_align_j = P["gS_align_j"]
        
        # Apply softmax rule (from numerical_utils)
        add_mu_i = softmax_align_rule_receiver(beta_ij, KL1, kappa, gmu_align, gbar_mu_i)
        add_S_i = softmax_align_rule_receiver(beta_ij, KL1, kappa, gS_align, gbar_S_i)
        add_mu_j = softmax_align_rule_sender(beta_ij, KL1, kappa, gmu_align_j)
        add_S_j = softmax_align_rule_sender(beta_ij, KL1, kappa, gS_align_j)
        
        # Accumulate receiver
        dmu_align[overlap] += add_mu_i[overlap]
        dS_align[overlap] += add_S_i[overlap]
        
        # Accumulate sender (if enabled) - NEW version's _add_to_inbox takes 4 args
        if cfg.accumulate_sender_grads:
            # Mask sender gradients by overlap before adding to inbox
            add_mu_j_masked = np.zeros_like(add_mu_j)
            add_S_j_masked = np.zeros_like(add_S_j)
            add_mu_j_masked[overlap] = add_mu_j[overlap]
            add_S_j_masked[overlap] = add_S_j[overlap]
            _add_to_inbox(agent_j, which, add_mu_j_masked, add_S_j_masked)
    
    # Final checks
    assert np.all(np.isfinite(dmu_align)) and np.all(np.isfinite(dS_align)), "β-align NaN/Inf"
    
    return dmu_align, dS_align


# ============================================================================
# Gamma Block (Pure)
# ============================================================================



def compute_gamma_gradients_pure(ctx, agent_i, agents, cfg, which, mu_key, S_key):
    """
    γ-weighted gating gradients (Cases A and B), robust to different gamma_maps() shapes.

    Accepts any of the following gamma_maps returns:
      1) dict with include_kl=True:
         {"A": (KL_A, gamma_A), "B": (KL_B, gamma_B)}  (either key may be missing)
      2) dict with include_kl=False:
         {"A": gamma_A, "B": gamma_B}
      3) tuple length 4: (gamma_A, gamma_B, kl_A, kl_B)
      4) tuple length 2: (gamma_A, gamma_B)   (no KL provided)

    If KLs are missing, zeros are used (shape = overlap sites).
    """

    # --- local helpers ---
    def _zeros_like_mask(mask, dtype=np.float32):
        m = np.asarray(mask, dtype=dtype)
        return np.zeros_like(m, dtype=dtype)

    def _shape_sites_from(arr_like, fallback_sites):
        """
        Return the site-shape tuple (*S,) from an array that might be (*S,),
        or a fallback (*S,) if arr_like is None or has extra feature dims.
        """
        if arr_like is None:
            return tuple(fallback_sites.shape)
        a = np.asarray(arr_like)
        if a.ndim == 0:
            return tuple(fallback_sites.shape)
        # If has extra feature dims (e.g., Ki, Ki), strip them
        # until a is rank-1 site field compatible with fallback.
        site = a.shape
        while len(site) > len(fallback_sites.shape):
            site = site[:-1]
        return site

    def _unpack_gamma_maps(maps_obj, overlap):
        """
        Normalize gamma_maps return into (gamma_A, gamma_B, kl_A, kl_B) as site fields (*S,).
        Missing entries -> zeros.
        """
        m = np.asarray(overlap, dtype=np.float32)
        Sshape = m.shape

        gamma_A = gamma_B = kl_A = kl_B = None

        # Try to call gamma_maps with include_kl=True for maximal info
        maps = maps_obj
        # Normalize dict form
        if isinstance(maps, dict):
            if "A" in maps:
                A = maps["A"]
                if isinstance(A, (tuple, list)) and len(A) == 2:
                    kl_A, gamma_A = A
                else:
                    gamma_A = A
            if "B" in maps:
                B = maps["B"]
                if isinstance(B, (tuple, list)) and len(B) == 2:
                    kl_B, gamma_B = B
                else:
                    gamma_B = B

        # Normalize tuple form
        elif isinstance(maps, (tuple, list)):
            if len(maps) == 4:
                gamma_A, gamma_B, kl_A, kl_B = maps
            elif len(maps) == 2:
                gamma_A, gamma_B = maps
            else:
                # unexpected; treat as no data
                pass

        # Cast to float32 arrays and fix shapes
        def _to_sites(x):
            if x is None:
                return np.zeros(Sshape, dtype=np.float32)
            a = np.asarray(x, dtype=np.float32)
            # If a has more dims than sites (e.g., feature dims), reduce to sites by mean
            while a.ndim > len(Sshape):
                if a.shape[-1] == 1:
                    a = a[..., 0]
                elif a.ndim >= 2 and a.shape[-1] == a.shape[-2]:
                    a = a.mean(axis=(-1, -2), dtype=np.float32)
                else:
                    a = a.mean(axis=-1, dtype=np.float32)
            # If a has fewer dims (shouldn't happen), broadcast by adding singleton heads
            while a.ndim < len(Sshape):
                a = a[None, ...]
            # Final safety cast
            a = a.astype(np.float32, copy=False)
            # If shapes mismatch, try broadcast to Sshape
            if a.shape != Sshape:
                try:
                    a = np.broadcast_to(a, Sshape).astype(np.float32, copy=False)
                except Exception:
                    a = np.zeros(Sshape, dtype=np.float32)
            return a

        gamma_A = _to_sites(gamma_A)
        gamma_B = _to_sites(gamma_B)
        kl_A    = _to_sites(kl_A)
        kl_B    = _to_sites(kl_B)

        return gamma_A, gamma_B, kl_A, kl_B

    # --- main body ---
    mu_i = np.asarray(getattr(agent_i, mu_key), np.float32)
    dmu_gamma = np.zeros_like(mu_i, dtype=np.float32)
    dS_gamma = np.zeros_like(getattr(agent_i, S_key), dtype=np.float32)

    # Determine which gamma flags are active
    use_A = bool(cfg.use_gamma_A_q) if which == "q" else bool(cfg.use_gamma_A_p)
    use_B = bool(cfg.use_gamma_B_q) if which == "q" else bool(cfg.use_gamma_B_p)

    if not (use_A or use_B):
        return dmu_gamma, dS_gamma

    # Get pushes for gamma computations
    Phi  = Phi_cached(ctx, agent_i, kind="q_to_p")
    Phit = Phi_cached(ctx, agent_i, kind="p_to_q")

    # Iterate neighbors with overlap mask
    for agent_j, overlap in iter_overlap_pairs(agent_i, agents, cfg.tau, which, mu_key, ctx):
        if not np.any(overlap):
            continue

        m = overlap.astype(np.float32, copy=False)
        Omega_ij = Omega(ctx, agent_i, agent_j, which=which)

        # Fetch gamma/kl maps – handle any shape the accessor returns
        try:
            maps_obj = gamma_maps(ctx, agent_i, agent_j, include_kl=True)
        except TypeError:
            # older signature without include_kl
            maps_obj = gamma_maps(ctx, agent_i, agent_j)

        gamma_A, gamma_B, kl_A, kl_B = _unpack_gamma_maps(maps_obj, m)

        # Case A: gate i's prior belief against j's pushed model (uses Φ̃_i)
        if use_A and np.any(gamma_A):
            dmu_A, dS_A = compute_gamma_A_term(
                ctx, agent_i, agent_j, cfg, which,
                mu_key, S_key, gamma_A, kl_A, m, Omega_ij, Phit
            )
            dmu_gamma += dmu_A
            dS_gamma  += dS_A

        # Case B: gate i's pulled model against j's transported belief (uses Φ_i)
        if use_B and np.any(gamma_B):
            dmu_B, dS_B = compute_gamma_B_term(
                ctx, agent_i, agent_j, cfg, which,
                mu_key, S_key, gamma_B, kl_B, m, Omega_ij, Phi
            )
            dmu_gamma += dmu_B
            dS_gamma  += dS_B

    return dmu_gamma, dS_gamma



def compute_gamma_A_term(ctx, agent_i, agent_j, cfg, which,
                         mu_key, S_key, gamma_map, kl_map, mask, Omega_ij, Phit):
    """Compute gamma A contribution (pure) using product rule.

    Case A (j→i): KL(q_j || Ω^q_ji[ Φ̃_i p_i ])
      - Receiver grads need the Φ̃ chain rule to land back in the *p*-fiber.
      - We gate that chain rule behind cfg.gamma_caseA_use_phitilde_fix for strict legacy reproduction.
    """
    

    kappa = cfg.kappa_gamma_q if which == "q" else cfg.kappa_gamma_p

    mu_i = np.asarray(getattr(agent_i, mu_key), np.float32)
    S_i  = np.asarray(getattr(agent_i, S_key),  np.float32)
    mu_j = np.asarray(getattr(agent_j, mu_key), np.float32)
    S_j  = np.asarray(getattr(agent_j, S_key),  np.float32)

    gamma = np.asarray(gamma_map, np.float32)
    KL    = np.asarray(kl_map,    np.float32)

    # Receiver-side ∂KL in Q-frame (Case A path builds with Φ̃ internally)
    dmu_i, dS_i = grad_gamma_A_mu_sigma_i(
        mu_i, S_i, mu_j, S_j, Omega_ij,
        eps=cfg.eps, mask=mask
    )

    # Optional bugfix: chain rule through Φ̃ᵀ to land in P-frame
    use_phitilde_fix = bool(getattr(cfg, "gamma_caseA_use_phitilde_fix", True))
    if use_phitilde_fix and Phit is not None:
        Phit = np.asarray(Phit, np.float32)  # (..., Kq, Kp)
        # μ: dμ_p = Φ̃ᵀ dμ_q
        dmu_i = np.einsum("...qp,...q->...p", Phit, dmu_i, optimize=True)
        # Σ: dS_p = Φ̃ᵀ dS_q Φ̃
        dS_i  = np.einsum("...pq,...qr,...sr->...ps", Phit, dS_i, Phit, optimize=True)
        # numerical hygiene
        dS_i  = 0.5 * (dS_i + np.swapaxes(dS_i, -1, -2))

    # Product rule (apply to the gradient tensors directly)
    dmu_i = plain_rule(gamma, KL, kappa, dmu_i)
    dS_i  = plain_rule(gamma, KL, kappa, dS_i)
    # Then mask to overlap (and sym guard)
    if mask is not None:
        m = np.asarray(mask, np.float32)
        dmu_i *= m[..., None]
        dS_i  *= m[..., None, None]
    dS_i = 0.5 * (dS_i + np.swapaxes(dS_i, -1, -2))

   

    # Sender grads (optional)
    if getattr(cfg, "accumulate_sender_grads", False):
        dmu_j, dS_j = grad_gamma_A_mu_sigma_j(
            mu_j, S_j, mu_i, S_i, Omega_ij,
            eps=cfg.eps, mask=mask
        )
        dmu_j = plain_rule(gamma, KL, kappa, dmu_j)
        dS_j  = plain_rule(gamma, KL, kappa, dS_j)
        if mask is not None:
            m = np.asarray(mask, np.float32)
            dmu_j *= m[..., None]
            dS_j  *= m[..., None, None]
        dS_j = 0.5 * (dS_j + np.swapaxes(dS_j, -1, -2))
        _add_to_inbox(agent_j, which, dmu_j, dS_j)

    return dmu_i, dS_i


def compute_gamma_B_term(ctx, agent_i, agent_j, cfg, which,
                         mu_key, S_key, gamma_map, kl_map, mask, Omega_ij, Phi):
    """Compute gamma B contribution (pure) using product rule.

    Case B (i→j): KL(p_i || Φ_i[ Ω^q_ij q_j ])
      - Receiver grads are in the *p*-fiber already (via Φ).
      - Cross-fiber sender inbox routing preserved.
    """
    import numpy as np

    kappa = cfg.kappa_gamma_q if which == "q" else cfg.kappa_gamma_p

    # Cross-fiber keys (unchanged)
    if which == "q":
        mu_i_key, S_i_key = "mu_p_field", "sigma_p_field"
        mu_j_key, S_j_key = "mu_q_field", "sigma_q_field"
    else:
        mu_i_key, S_i_key = "mu_q_field", "sigma_q_field"
        mu_j_key, S_j_key = "mu_p_field", "sigma_p_field"

    mu_p_i = np.asarray(getattr(agent_i, mu_i_key), np.float32)
    S_p_i  = np.asarray(getattr(agent_i, S_i_key),  np.float32)
    mu_j   = np.asarray(getattr(agent_j, mu_j_key), np.float32)
    S_j    = np.asarray(getattr(agent_j, S_j_key),  np.float32)

    gamma = np.asarray(gamma_map, np.float32)
    KL    = np.asarray(kl_map,    np.float32)

    # Receiver-side ∂KL in P-fiber
    dmu_p, dS_p = grad_gamma_B_mu_sigma_i(
        mu_j, S_j, mu_p_i, S_p_i, Omega_ij, Phi,
        eps=cfg.eps, mask=mask
    )

    # Product rule on the gradients themselves, then mask & sym
    dmu_p = plain_rule(gamma, KL, kappa, dmu_p)
    dS_p  = plain_rule(gamma, KL, kappa, dS_p)
    if mask is not None:
        m = np.asarray(mask, np.float32)
        dmu_p *= m[..., None]
        dS_p  *= m[..., None, None]
    dS_p = 0.5 * (dS_p + np.swapaxes(dS_p, -1, -2))

    # Sender grads (optional)
    if getattr(cfg, "accumulate_sender_grads", False):
        dmu_js, dS_js = grad_gamma_B_mu_sigma_j(
            mu_j, S_j, mu_p_i, S_p_i, Omega_ij, Phi,
            eps=cfg.eps, mask=mask
        )
        dmu_js = plain_rule(gamma, KL, kappa, dmu_js)
        dS_js  = plain_rule(gamma, KL, kappa, dS_js)
        if mask is not None:
            m = np.asarray(mask, np.float32)
            dmu_js *= m[..., None]
            dS_js  *= m[..., None, None]
        dS_js = 0.5 * (dS_js + np.swapaxes(dS_js, -1, -2))
        # preserve cross-fiber inbox routing as in the refactor
        _add_to_inbox(agent_j, "q" if which == "p" else "p", dmu_js, dS_js)

    return dmu_p, dS_p




def _add_to_inbox(agent, which, dmu, dS):
    """Helper to add sender contributions to inbox (side effect)."""
    inbox_key = f"_inbox_{which}"
    inbox = getattr(agent, inbox_key, None)
    
    if inbox is None:
        inbox = {'mu': None, 'S': None}
        setattr(agent, inbox_key, inbox)
    
    if inbox['mu'] is None:
        inbox['mu'] = np.asarray(dmu, np.float32)
    else:
        inbox['mu'] = inbox['mu'] + np.asarray(dmu, np.float32)
    
    if inbox['S'] is None:
        inbox['S'] = np.asarray(dS, np.float32)
    else:
        inbox['S'] = inbox['S'] + np.asarray(dS, np.float32)


# ============================================================================
# Self Energy Gradients
# ============================================================================

def grad_self_energy_belief(mu_q, S_q, mu_p_push, inv_p_push, 
                            sigma_q_inv=None, mask=None):
    """
    Belief self-energy: ∇_q KL(q || Φ[p])
    Returns (dμ_q, dΣ_q)
    """
    mu_q, S_q = safe_cast_and_sanitize(mu_q, S_q, dtype=np.float64)
    mu_p_push = np.asarray(mu_p_push, np.float64)
    inv_p_push = np.asarray(inv_p_push, np.float64)
    
    if sigma_q_inv is None:
        sigma_q_inv = safe_inv(S_q, eps=1e-12)
    else:
        sigma_q_inv = np.asarray(sigma_q_inv, np.float64)
    
    # Standard KL source partials
    delta = mu_q - mu_p_push
    dmu = np.einsum("...ij,...j->...i", inv_p_push, delta, optimize=True)
    dS = 0.5 * (inv_p_push - sigma_q_inv)
    dS = symmetrize(dS)
    
    # Apply mask
    if mask is not None:
        m = np.asarray(mask, np.float64)
        dmu = dmu * m[..., None]
        dS = dS * m[..., None, None]
    
    return dmu.astype(np.float32), dS.astype(np.float32)


def grad_self_energy_model(mu_p, S_p, mu_q_push, inv_q_push, Phit, mask=None):
    """
    Model self-energy: ∇_p KL(Φ̃[q] || p)
    Returns (dμ_p, dΣ_p)
    """
    mu_p, S_p = safe_cast_and_sanitize(mu_p, S_p, dtype=np.float64)
    mu_q_push = np.asarray(mu_q_push, np.float64)
    inv_q_push = np.asarray(inv_q_push, np.float64)
    Phit = np.asarray(Phit, np.float64)
    
    # Map partials through Φ̃
    delta = mu_q_push - mu_p
    v = np.einsum("...ij,...j->...i", inv_q_push, delta, optimize=True)
    dmu_L = v
    
    S_p_inv = safe_inv(S_p, eps=1e-12)
    dS_L = 0.5 * (inv_q_push - S_p_inv)
    dS_L = symmetrize(dS_L)
    
    # Chain rule through Φ̃^T
    dmu = np.einsum("...ji,...j->...i", Phit, dmu_L, optimize=True)
    dS = np.einsum("...ki,...kl,...jl->...ij", Phit, dS_L, Phit, optimize=True)
    dS = symmetrize(dS)
    
    # Apply mask
    if mask is not None:
        m = np.asarray(mask, np.float64)
        dmu = dmu * m[..., None]
        dS = dS * m[..., None, None]
    
    return dmu.astype(np.float32), dS.astype(np.float32)


# ============================================================================
# Feedback Energy Gradients
# ============================================================================

def grad_feedback_energy_belief(mu_q, S_q, mu_p, mu_q_push, S_q_push, 
                                inv_q_push, S_p, Phi):
    """
    Belief feedback: ∇_q KL(Φ[q] || p)
    Returns (dμ_q, dΣ_q)
    """
    mu_q, S_q = safe_cast_and_sanitize(mu_q, S_q, dtype=np.float64)
    mu_p = np.asarray(mu_p, np.float64)
    S_p = sanitize_sigma(np.asarray(S_p, np.float64), eps=1e-8)
    Phi = np.asarray(Phi, np.float64)
    
    S_p_inv = safe_inv(S_p, eps=1e-12)
    
    # Landing-frame partials
    delta = mu_q_push - mu_p
    v = np.einsum("...ij,...j->...i", S_p_inv, delta, optimize=True)
    dmu_L = v
    
    dS_L = 0.5 * (S_p_inv - inv_q_push)
    dS_L = symmetrize(dS_L)
    
    # Chain through Φ^T
    dmu = np.einsum("...ji,...j->...i", Phi, dmu_L, optimize=True)
    dS = np.einsum("...ki,...kl,...jl->...ij", Phi, dS_L, Phi, optimize=True)
    dS = symmetrize(dS)
    
    return dmu.astype(np.float32), dS.astype(np.float32)


def grad_feedback_energy_model(mu_p, S_p, mu_q_push, S_q_push, 
                               inv_q_push, sigma_p_inv=None):
    """
    Model feedback: ∇_p KL(p || Φ̃[q])
    Returns (dμ_p, dΣ_p)
    """
    mu_p, S_p = safe_cast_and_sanitize(mu_p, S_p, dtype=np.float64)
    mu_q_push = np.asarray(mu_q_push, np.float64)
    inv_q_push = np.asarray(inv_q_push, np.float64)
    
    if sigma_p_inv is None:
        sigma_p_inv = safe_inv(S_p, eps=1e-12)
    else:
        sigma_p_inv = np.asarray(sigma_p_inv, np.float64)
    
    # Standard KL source partials
    delta = mu_p - mu_q_push
    dmu = np.einsum("...ij,...j->...i", inv_q_push, delta, optimize=True)
    dS = 0.5 * (inv_q_push - sigma_p_inv)
    dS = symmetrize(dS)
    
    return dmu.astype(np.float32), dS.astype(np.float32)


# ============================================================================
# Alignment Gradient Primitives
# ============================================================================

def grad_receiver_align_mu_sigma(mu_i, S_i, mu_j, S_j, Omega_ij,
                                 kl_map, beta_map, mask, eps=1e-8):
    """
    Receiver-side alignment gradients with exact softmax product rule.
    
    Returns (dμ_i, dΣ_i)
    """
    mu_i, S_i = safe_cast_and_sanitize(mu_i, S_i, eps=eps, dtype=np.float64)
    mu_j, S_j = safe_cast_and_sanitize(mu_j, S_j, eps=eps, dtype=np.float64)
    Omega_ij = np.asarray(Omega_ij, np.float64)
    
    kl = np.asarray(kl_map, np.float64)
    beta = np.asarray(beta_map, np.float64)
    m = np.asarray(mask, np.float64)
    
    # Push j through Omega
    mu_j_t, S_j_t, S_j_t_inv = push_gaussian(
        mu_j, S_j, Omega_ij, eps=eps, return_inv=True
    )
    
    # Compute rule and derivatives
    gbar_mu_i, gbar_S_i, dgbar_dkl = softmax_align_rule_receiver(
        mu_i, S_i, mu_j_t, S_j_t_inv, kl, beta, eps=eps
    )
    
    # KL partials
    S_i_inv = safe_inv(S_i, eps=eps)
    delta = mu_i - mu_j_t
    
    dkl_dmu = np.einsum("...ij,...j->...i", S_j_t_inv, delta, optimize=True)
    
    term = np.einsum("...ij,...jk,...kl->...il",
                    S_j_t_inv, S_i, S_j_t_inv, optimize=True)
    dkl_dS = 0.5 * (term - S_i_inv)
    dkl_dS = symmetrize(dkl_dS)
    
    # Chain rule
    dmu = gbar_mu_i + dgbar_dkl[..., None] * dkl_dmu
    dS = gbar_S_i + dgbar_dkl[..., None, None] * dkl_dS
    dS = symmetrize(dS)
    
    # Mask
    dmu = dmu * m[..., None]
    dS = dS * m[..., None, None]
    
    return dmu.astype(np.float32), dS.astype(np.float32)





def grad_sender_align_mu_sigma(mu_j, S_j, mu_i, S_i, Omega_ij,
                               kl_map, beta_map, mask, eps=1e-8):
    """
    Sender-side alignment gradients.
    
    Returns (dμ_j, dΣ_j)
    """
    mu_i, S_i = safe_cast_and_sanitize(mu_i, S_i, eps=eps, dtype=np.float64)
    mu_j, S_j = safe_cast_and_sanitize(mu_j, S_j, eps=eps, dtype=np.float64)
    Omega_ij = np.asarray(Omega_ij, np.float64)
    
    kl = np.asarray(kl_map, np.float64)
    beta = np.asarray(beta_map, np.float64)
    m = np.asarray(mask, np.float64)
    
    # Push j through Omega
    mu_j_t, S_j_t, S_j_t_inv = push_gaussian(
        mu_j, S_j, Omega_ij, eps=eps, return_inv=True
    )
    
    # Sender rule
    gbar_mu_j, gbar_S_j, dgbar_dkl = softmax_align_rule_sender(
        mu_i, S_i, mu_j_t, S_j_t_inv, kl, beta, eps=eps
    )
    
    # KL partials in j frame
    delta = mu_i - mu_j_t
    dkl_dmu_L = -np.einsum("...ij,...j->...i", S_j_t_inv, delta, optimize=True)
    
    vvT = np.einsum("...i,...j->...ij", 
                   np.einsum("...ij,...j->...i", S_j_t_inv, delta, optimize=True),
                   np.einsum("...ij,...j->...i", S_j_t_inv, delta, optimize=True),
                   optimize=True)
    
    term = np.einsum("...ij,...jk,...kl->...il",
                    S_j_t_inv, S_i, S_j_t_inv, optimize=True)
    
    dkl_dS_L = 0.5 * (-term - vvT + S_j_t_inv)
    dkl_dS_L = symmetrize(dkl_dS_L)
    
    # Map through Omega^T
    dkl_dmu_j = np.einsum("...ji,...j->...i", Omega_ij, dkl_dmu_L, optimize=True)
    dkl_dS_j = np.einsum("...ki,...kl,...jl->...ij", 
                        Omega_ij, dkl_dS_L, Omega_ij, optimize=True)
    
    dkl_dS_j = symmetrize(dkl_dS_j)
    
    # Chain
    dmu = gbar_mu_j + dgbar_dkl[..., None] * dkl_dmu_j
    dS = gbar_S_j + dgbar_dkl[..., None, None] * dkl_dS_j
    dS = symmetrize(dS)
    
    # Mask
    dmu = dmu * m[..., None]
    dS = dS * m[..., None, None]
    
    return dmu.astype(np.float32), dS.astype(np.float32)


# ============================================================================
# Gamma Gradient Primitives  
# ============================================================================

def grad_gamma_A_mu_sigma_i(mu_i, S_i, mu_j, S_j, Omega_ij, eps=1e-8, mask=None):
    """
    Receiver gradients for gamma A: ∇_i KL(q_i || Ω_ij q_j)
    
    Returns (dμ_i, dΣ_i)
    """
    mu_i, S_i = safe_cast_and_sanitize(mu_i, S_i, eps=eps, dtype=np.float64)
    mu_j, S_j = safe_cast_and_sanitize(mu_j, S_j, eps=eps, dtype=np.float64)
    Omega_ij = np.asarray(Omega_ij, np.float64)
    
    # Push j
    mu_j_t, S_j_t, S_j_t_inv = push_gaussian(
        mu_j, S_j, Omega_ij, eps=eps, return_inv=True
    )
    
    S_i_inv = safe_inv(S_i, eps=eps)
    
    # KL source partials
    delta = mu_i - mu_j_t
    dmu = np.einsum("...ij,...j->...i", S_j_t_inv, delta, optimize=True)
    dS = 0.5 * (S_j_t_inv - S_i_inv)
    dS = symmetrize(dS)
    
    if mask is not None:
        m = np.asarray(mask, np.float64)
        dmu = dmu * m[..., None]
        dS = dS * m[..., None, None]
    
    return dmu.astype(np.float32), dS.astype(np.float32)






def grad_gamma_A_mu_sigma_j(mu_j, S_j, mu_i, S_i, Omega_ij, eps=1e-8, mask=None):
    """
    Sender gradients for gamma A: chain through Ω_ij
    
    Returns (dμ_j, dΣ_j)
    """
    mu_i, S_i = safe_cast_and_sanitize(mu_i, S_i, eps=eps, dtype=np.float64)
    mu_j, S_j = safe_cast_and_sanitize(mu_j, S_j, eps=eps, dtype=np.float64)
    Omega_ij = np.asarray(Omega_ij, np.float64)
    
    # Push j
    mu_j_t, S_j_t, S_j_t_inv = push_gaussian(
        mu_j, S_j, Omega_ij, eps=eps, return_inv=True
    )
    
    # Landing-frame partials
    delta = mu_i - mu_j_t
    dmu_L = -np.einsum("...ij,...j->...i", S_j_t_inv, delta, optimize=True)
    
    vvT = np.einsum("...i,...j->...ij",
                   np.einsum("...ij,...j->...i", S_j_t_inv, delta, optimize=True),
                   np.einsum("...ij,...j->...i", S_j_t_inv, delta, optimize=True),
                   optimize=True)
    term = np.einsum("...ij,...jk,...kl->...il",
                    S_j_t_inv, S_i, S_j_t_inv, optimize=True)
    dS_L = 0.5 * (-term - vvT + S_j_t_inv)
    dS_L = symmetrize(dS_L)
    
    # Chain through Ω^T
    dmu = np.einsum("...ji,...j->...i", Omega_ij, dmu_L, optimize=True)
    dS = np.einsum("...ki,...kl,...jl->...ij",
                  Omega_ij, dS_L, Omega_ij, optimize=True)
    dS = symmetrize(dS)
    
    if mask is not None:
        m = np.asarray(mask, np.float64)
        dmu = dmu * m[..., None]
        dS = dS * m[..., None, None]
    
    return dmu.astype(np.float32), dS.astype(np.float32)





def grad_gamma_B_mu_sigma_i(mu_j, S_j, mu_p_i, S_p_i, Omega_ij, Phi_i,
                            eps=1e-8, mask=None):
    """
    Receiver gradients for gamma B: ∇_{p_i} KL(p_i || Φ_i[Ω_ij q_j])
    
    Returns (dμ_{p_i}, dΣ_{p_i})
    """
    mu_j, S_j = safe_cast_and_sanitize(mu_j, S_j, eps=eps, dtype=np.float64)
    mu_p_i, S_p_i = safe_cast_and_sanitize(mu_p_i, S_p_i, eps=eps, dtype=np.float64)
    Omega_ij = np.asarray(Omega_ij, np.float64)
    Phi_i = np.asarray(Phi_i, np.float64)
    
    # Double push: j -> Q_i -> P_i
    mu_t, S_t = push_gaussian(mu_j, S_j, Omega_ij, eps=eps, return_inv=False)
    mu_L, S_L, S_L_inv = push_gaussian(mu_t, S_t, Phi_i, eps=eps, return_inv=True)
    
    S_p_inv = safe_inv(S_p_i, eps=eps)
    
    # KL source partials
    delta = mu_p_i - mu_L
    dmu = np.einsum("...ij,...j->...i", S_L_inv, delta, optimize=True)
    dS = 0.5 * (S_L_inv - S_p_inv)
    dS = symmetrize(dS)
    
    if mask is not None:
        m = np.asarray(mask, np.float64)
        dmu = dmu * m[..., None]
        dS = dS * m[..., None, None]
    
    return dmu.astype(np.float32), dS.astype(np.float32)





def grad_gamma_B_mu_sigma_j(mu_j, S_j, mu_p_i, S_p_i, Omega_ij, Phi_i,
                            R=None, mu_1=None, Sigma_1=None, Sigma_1_inv=None,
                            Sigma_p_inv=None, eps=1e-8, assume_sanitized=True):
    """
    Sender gradients for gamma B: chain through Φ_i @ Ω_ij
    
    Returns (dμ_j, dΣ_j)
    """
    # Cast to float64
    mu_j = np.asarray(mu_j, np.float64, order="C")
    S_j = np.asarray(S_j, np.float64, order="C")
    mu_p_i = np.asarray(mu_p_i, np.float64, order="C")
    S_p_i = np.asarray(S_p_i, np.float64, order="C")
    Phi_i = np.asarray(Phi_i, np.float64, order="C")
    Omega_ij = np.asarray(Omega_ij, np.float64, order="C")
    Rt = np.swapaxes
    
    if not assume_sanitized:
        S_j = sanitize_sigma(S_j, eps=eps)
        S_p_i = sanitize_sigma(S_p_i, eps=eps)
    
    # Mapping matrix
    if R is None:
        R = np.einsum("...ik,...kj->...ij", Phi_i, Omega_ij, optimize=True)
    R_T = Rt(R, -1, -2)
    
    # Landing stats
    if (mu_1 is None) or (Sigma_1 is None and Sigma_1_inv is None):
        mu_t, S_t = push_gaussian(mu_j, S_j, Omega_ij, eps=eps, return_inv=False,
                                 Sigma_inv=None, assume_orthogonal=False,
                                 sanitize_input=False)
        mu_1_calc, S_1_calc, S_1_inv_calc = push_gaussian(
            mu_t, S_t, Phi_i, eps=eps, return_inv=True,
            Sigma_inv=None, assume_orthogonal=False, sanitize_input=True
        )
        if mu_1 is None: mu_1 = mu_1_calc
        if Sigma_1 is None: Sigma_1 = S_1_calc
        if Sigma_1_inv is None: Sigma_1_inv = S_1_inv_calc
    else:
        mu_1 = np.asarray(mu_1, np.float64, order="C")
        Sigma_1 = None if Sigma_1 is None else np.asarray(Sigma_1, np.float64, order="C")
        if Sigma_1_inv is None:
            S1 = sanitize_sigma(Sigma_1, eps=eps)
            Sigma_1_inv = safe_inv(S1, eps=max(eps, 1e-12))
    
    if Sigma_p_inv is None:
        Sp = S_p_i if assume_sanitized else sanitize_sigma(S_p_i, eps=eps)
        Sigma_p_inv = safe_inv(Sp, eps=max(eps, 1e-12))
    
    # Landing-frame partials
    dmu_1 = -np.einsum("...ij,...j->...i", Sigma_1_inv, (mu_p_i - mu_1), optimize=True)
    
    dS_1 = -Sigma_1_inv
    dS_1 += np.einsum("...ij,...jk,...kl->...il", 
                     Sigma_1_inv, S_p_i, Sigma_1_inv, optimize=True)
    dS_1 *= 0.5
    dS_1 = symmetrize(dS_1)
    
    # Map to sender frame
    dmu_j = np.einsum("...ij,...j->...i", R_T, dmu_1, optimize=True)
    dS_j = np.einsum("...ik,...kl,...jl->...ij", R_T, dS_1, R, optimize=True)
    dS_j = symmetrize(dS_j)
    
    return dmu_j.astype(np.float32, copy=False), dS_j.astype(np.float32, copy=False)


# ============================================================================
# Natural Gradient Projection
# ============================================================================

def apply_natural_gradient_batch(
    ctx,
    mu_field,
    sigma_field,
    grad_mu_field,
    grad_sigma_field,
    mask=None,
    *,
    use_float64: bool = True,
    assume_sanitized: bool = True,
    grad_sigma_is_symmetric: bool = False,
    assert_finite: bool = False,
):
    """
    Vectorized natural gradient for Gaussian fields:
        δμ = -Σ ∇_μ L
        δΣ = -2 Σ sym(∇_Σ L) Σ

    Returns
    -------
    delta_mu : (*S, K)
    delta_sigma : (*S, K, K)
    """
    from core.runtime_context import cfg_get
    
    # Config
    eps = float(cfg_get(ctx, "eps", 1e-10))
    support_tau = float(cfg_get(ctx, "support_tau", 1e-6))
    dtype_work = np.float64 if use_float64 else np.float32
    dtype_out = np.float32 if not use_float64 else dtype_work
    
    # Cast inputs
    mu = np.asarray(mu_field)
    Sig = np.asarray(sigma_field)
    gmu = np.asarray(grad_mu_field)
    gSig = np.asarray(grad_sigma_field)
    
    if mu.ndim < 2 or Sig.ndim < 3:
        raise ValueError(f"Bad shapes: mu {mu.shape}, Sigma {Sig.shape}")
    
    S = mu.shape[:-1]
    K = mu.shape[-1]
    if Sig.shape[:-2] != S or Sig.shape[-2:] != (K, K):
        raise ValueError(f"sigma_field shape {Sig.shape} incompatible with mu_field {mu.shape}")
    
    # Flatten spatial
    N = int(np.prod(S, dtype=int))
    mu = mu.astype(dtype_work, copy=False).reshape(N, K)
    Sig = Sig.astype(dtype_work, copy=False).reshape(N, K, K)
    gmu = gmu.astype(dtype_work, copy=False).reshape(N, K)
    gSig = gSig.astype(dtype_work, copy=False).reshape(N, K, K)
    
    # Sanitize and symmetrize
    if not assume_sanitized:
        Sig = sanitize_sigma(Sig, eps=eps)
    if not grad_sigma_is_symmetric:
        gSig = 0.5 * (gSig + np.swapaxes(gSig, -1, -2))
    
    # Natural steps
    dmu = -np.einsum("nik,nk->ni", Sig, gmu, optimize=True)
    tmp = np.einsum("nij,njk->nik", Sig, gSig, optimize=True)
    dS = -2.0 * np.einsum("nij,njk->nik", tmp, Sig, optimize=True)
    dS = 0.5 * (dS + np.swapaxes(dS, -1, -2))
    
    # Apply mask
    if mask is not None:
        m = np.asarray(mask)
        m_flat = m.reshape(N)
        
        if m.dtype == bool:
            active = m_flat
            wts = None
        else:
            wts = m_flat.astype(dtype_work, copy=False)
            active = wts > support_tau
            dmu *= wts[:, None]
            dS *= wts[:, None, None]
        
        if not np.all(active):
            ia = ~active
            dmu[ia] = 0.0
            dS[ia] = 0.0
    
    if assert_finite:
        if not (np.isfinite(dmu).all() and np.isfinite(dS).all()):
            raise FloatingPointError("Nonfinite natural gradient (μ or Σ).")
    
    # Restore shapes
    return (
        dmu.reshape(S + (K,)).astype(dtype_out, copy=False),
        dS.reshape(S + (K, K)).astype(dtype_out, copy=False),
    )