# -*- coding: utf-8 -*-
"""
Created on Thu Sep 11 10:54:04 2025

@author: chris and christine
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Tuple, Optional, Any
import time
import csv
from core.utils import _aid
import numpy as np
import matplotlib.pyplot as plt
import numbers as _numbers
from core.utils import _safe_vector_norm  

from mpl_toolkits.mplot3d import Axes3D  # noqa: F401

# =============================================================
# MetricsViz: one-stop logging + plotting for SO(3) Suite
# =============================================================
# Goals
#  - Single API to record GLOBAL and PER-AGENT metrics every step
#  - Lightweight CSV/JSONL logs for analysis
#  - Quick timeseries plots (energies, norms, drift)
#  - Snapshot heatmaps & step GIFs using robust percentile scaling
#  - Representation-aware annotations (reads casimir_total from meta)
#
# Notes
#  - No seaborn; pure matplotlib, as requested.
#  - Animations saved as GIFs (user preference) not MP4s.
#  - Designed to be imported by your run loop; no tight coupling.
# =============================================================


# ------------------------------
# Config
# ------------------------------
@dataclass
class VizConfig:
    outdir: Path
    run_name: str = "run"          # keeps controlling the folder
    legend_label: str = ""         # NEW: only affects plot legends

    # Logging cadence
    save_every_steps: int = 100000
    plot_every_steps: int = 1
    snapshot_every_steps: int = 2

    # Visualization settings
    dpi: int = 100
    cmap: str = "viridis"
    robust_low: float = 1.0
    robust_high: float = 99.0

    # Downsample for large fields when snapshotting
    max_side: int = 256

    # File names
    global_csv: str = "global_metrics.csv"
    agent_csv: str = "agent_metrics.csv"
    global_jsonl: str = "global_metrics.jsonl"
    agent_jsonl: str = "agent_metrics.jsonl"

    # Toggles
    enable_jsonl: bool     = False
    enable_csv: bool       = False
    enable_plots: bool     = True
    enable_snapshots: bool = True



# ------------------------------
# Utility helpers
# ------------------------------
# --- N-D helpers (spatial) ---

def _spatial_rank(arr: np.ndarray, trailing: int = 0) -> int:
    """Number of spatial axes = arr.ndim - trailing (not below zero)."""
    return max(0, arr.ndim - trailing)

def _center_slice_to_2d(arr: np.ndarray, trailing: int = 0) -> np.ndarray:
    """
    Take a central 2-D slice from an N-D spatial array, preserving the last `trailing` dims.
    If spatial rank <= 2, returns arr unchanged.
    """
    if arr.ndim <= (2 + trailing):
        return arr
    # spatial axes are arr.ndim - trailing - 1 ... 0
    s_rank = arr.ndim - trailing
    # we need to reduce to exactly 2 spatial axes -> slice middle of the extra ones
    extra = s_rank - 2
    idx = []
    for ax in range(arr.ndim):
        if ax < extra:
            # pick middle index on these leading spatial axes
            mid = arr.shape[ax] // 2
            idx.append(slice(mid, mid + 1))
        else:
            idx.append(slice(None))
    out = arr[tuple(idx)]
    # squeeze the sliced singleton spatial axes
    return np.squeeze(out, tuple(range(extra)))

def _meanproject_to_2d(arr: np.ndarray, trailing: int = 0) -> np.ndarray:
    """
    Mean-project *spatial* dimensions until only 2 spatial axes remain.
    Keeps the last `trailing` dims intact.
    """
    if arr.ndim <= (2 + trailing):
        return arr
    s_rank = arr.ndim - trailing
    # reduce earliest spatial axes first
    axes = list(range(0, s_rank - 2))
    return np.mean(arr, axis=tuple(axes), keepdims=False)

def _fwd_diff_nd(X: np.ndarray, spatial_axis: int) -> np.ndarray:
    """Periodic forward difference along the given *spatial* axis index (0..M-1)."""
    # Map spatial axis (0..M-1) to real axis (same since we put spatial dims in front)
    return np.roll(X, -1, axis=spatial_axis) - X


def _load_jsonl(path: Path) -> list[dict]:
    if not path.exists():
        return []
    rows = []
    with path.open("r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                rows.append(json.loads(line))
            except Exception:
                # skip malformed lines
                pass
    return rows


def _is_num(x) -> bool:
    if isinstance(x, (bool, np.bool_)):
        return False
    return isinstance(x, _numbers.Number) or (isinstance(x, np.generic) and np.issubdtype(type(x), np.number))

def _to_num(x):
    try:
        if _is_num(x):
            return float(x)
        # try string→float
        return float(x)
    except Exception:
        return np.nan



def _ensure_dir(p: Path):
    p.mkdir(parents=True, exist_ok=True)


def _ts() -> str:
    return time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())


def _robust_min_max(x: np.ndarray, low=1.0, high=99.0) -> Tuple[float, float]:
    lo = float(np.nanpercentile(x, low))
    hi = float(np.nanpercentile(x, high))
    if not np.isfinite(lo):
        lo = float(np.nanmin(x))
    if not np.isfinite(hi):
        hi = float(np.nanmax(x))
    if hi <= lo:
        hi = lo + 1e-6
    return lo, hi


def _downsample(img: np.ndarray, max_side: int) -> np.ndarray:
    H, W = img.shape[:2]
    s = max(H, W)
    if s <= max_side:
        return img
    scale = max_side / s
    newH = max(1, int(round(H * scale)))
    newW = max(1, int(round(W * scale)))
    # simple area-ish resize via slicing; keep dependencies light
    # For better quality, users can swap to skimage.transform.resize.
    y_idx = (np.linspace(0, H - 1, newH)).astype(int)
    x_idx = (np.linspace(0, W - 1, newW)).astype(int)
    return img[np.ix_(y_idx, x_idx)]


def _save_csv_row(csv_path: Path, header: List[str], row: List[Any]):
    exists = csv_path.exists()
    with csv_path.open("a", newline="") as f:
        writer = csv.writer(f)
        if not exists:
            writer.writerow(header)
        writer.writerow(row)


def _append_jsonl(path: Path, obj: Dict[str, Any]):
    with path.open("a", encoding="utf-8") as f:
        f.write(json.dumps(obj) + "\n")


def _safe_fig(figsize=(8,4), dpi=120):
    fig = plt.figure(figsize=figsize, dpi=dpi)
    ax = fig.add_subplot(111)
    return fig, ax


def _safe_savefig(fig: plt.Figure, path: Path, *, run_id: int | None = None):
    fig.tight_layout()
    try:
        fig.savefig(path)
    except PermissionError:
        # Windows often locks the file if it's open in an image viewer.
        # Fall back to a per-run unique filename to avoid overwriting a locked file.
        stem, suf = path.stem, path.suffix
        alt = path.with_name(f"{stem}_r{run_id or 0}{suf}")
        try:
            fig.savefig(alt)
        except PermissionError:
            # last-ditch: add a numeric suffix
            alt2 = path.with_name(f"{stem}_r{run_id or 0}_alt{suf}")
            fig.savefig(alt2)
    finally:
        plt.close(fig)


# --- tiny local helpers for A/curvature/covariant derivatives ---
def _fwd_dx(X):  # periodic forward diff along x (cols)
    X = np.asarray(X, np.float32)
    return np.roll(X, -1, axis=1) - X

def _fwd_dy(X):  # periodic forward diff along y (rows)
    X = np.asarray(X, np.float32)
    return np.roll(X, -1, axis=0) - X

def _cross(a, b):
    a = np.asarray(a, np.float32); b = np.asarray(b, np.float32)
    return np.stack([
        a[...,1]*b[...,2] - a[...,2]*b[...,1],
        a[...,2]*b[...,0] - a[...,0]*b[...,2],
        a[...,0]*b[...,1] - a[...,1]*b[...,0]
    ], axis=-1)


def _curvature_from_A(A):
    """
    Compute 2-D non-Abelian curvature on a visualization slice:
      F = ∂x A_y − ∂y A_x + A_x × A_y
    Input A is expected (H,W,2,3). Upstream converts general (*S,D,3) to this.
    """
    A = np.asarray(A, np.float32)
    if not (A.ndim == 4 and A.shape[-2:] == (2, 3)):
        raise ValueError(f"_curvature_from_A expects (H,W,2,3); got {A.shape}")

    Ax, Ay = A[..., 0, :], A[..., 1, :]
    Fx = _fwd_dx(Ay)
    Fy = _fwd_dy(Ax)
    F  = Fx - Fy + _cross(Ax, Ay)
    F2 = np.sum(F * F, axis=-1)
    return F, 0.5 * F2



def save_phi_series_npz(ctx, path: str):
    phi  = ctx.__dict__.get("_phi_series", {})
    phim = ctx.__dict__.get("_phi_model_series", {})
    # Pack as ragged lists of arrays by agent id
    np.savez_compressed(path,
        agent_ids=np.array(sorted(set(phi.keys())|set(phim.keys())), dtype=np.int32),
        phi_series=object_array_from_dict(phi),
        phim_series=object_array_from_dict(phim),
    )

def object_array_from_dict(d):
    # helper: dict[int]->list[np.ndarray(3,)] → object array aligned by sorted keys
    keys = sorted(d.keys())
    arr = np.empty(len(keys), dtype=object)
    for i,k in enumerate(keys):
        arr[i] = np.asarray(d[k], dtype=np.float32)
    return arr

def save_all_series_npz(ctx, path):
    """Write φ/φ̃/μq/μp time-series to a single NPZ for all agents."""
    phi   = ctx.__dict__.get("_phi_series", {})
    phim  = ctx.__dict__.get("_phi_model_series", {})
    mu_q  = ctx.__dict__.get("_mu_q_series", {})
    mu_p  = ctx.__dict__.get("_mu_p_series", {})

    agent_ids = sorted(set(phi) | set(phim) | set(mu_q) | set(mu_p))
    # Pack as arrays aligned to agent_ids; missing -> empty
    def pack(d):
        return np.array([np.asarray(d.get(aid, []), dtype=np.float32) for aid in agent_ids], dtype=object)

    np.savez(
        path,
        agent_ids=np.array(agent_ids, dtype=np.int32),
        phi_series=pack(phi),
        phim_series=pack(phim),             # alias acceptable by your loader
        mu_q_series=pack(mu_q),
        mu_p_series=pack(mu_p),
    )





# ------------------------------
# Main class
# ------------------------------
class MetricsViz:
    """
    Central logger/plotter. Create once per run, call from your step loop.

    API summary:
      mv = MetricsViz(VizConfig(Path(outdir), run_name="trial1"))
      mv.start_run(meta={"casimir_total": 2.0})
      for step in range(steps):
          mv.log_global(step, {...})
          for aid in agents:
              mv.log_agent(step, aid, {...})
          mv.maybe_flush(step)
          mv.maybe_plot(step)
          mv.maybe_snapshot(step, ctx, agents)
          mv.maybe_gif(step)
      mv.end_run()
    """

    def __init__(self, cfg: VizConfig):
        self.cfg = cfg
        self.root = Path(cfg.outdir)
        _ensure_dir(self.root)
        self.dir_run = self.root / cfg.run_name
        _ensure_dir(self.dir_run)
        # --- in MetricsViz.__init__ ---
        self.dir_plots = self.dir_run / "plots"
        self.dir_snapshots = self.dir_run / "snapshots"
        
        _ensure_dir(self.dir_plots)
        _ensure_dir(self.dir_snapshots)
        
        # In-memory timeseries (small; mirrors CSV/JSONL)
        self.global_rows: List[Dict[str, Any]] = []
        self.agent_rows: List[Dict[str, Any]] = []

        # Headers will be discovered from first row
        self._global_header: Optional[List[str]] = None
        self._agent_header: Optional[List[str]] = None
        self._labels_path = self.dir_run / "run_labels.json"

       
        # Meta
        self.meta: Dict[str, Any] = {}
        
        self.run_id: int | None = None
        self._counter_path = self.dir_run / "run_counter.txt"

            # metrics_viz.py (add to MetricsViz.__init__)
        self._global_history = []   # rows from prior runs
        self._agent_history  = []
        self._plot_cache   = self.dir_run / getattr(self.cfg, "plot_cache", "plot_cache.jsonl")

    # --------------------------
    # Lifecycle
    # --------------------------
    def start_run(self, meta: Optional[Dict[str, Any]] = None):
        _ensure_dir(self.dir_run); _ensure_dir(self.dir_plots); _ensure_dir(self.dir_snapshots)
    
        # ---- read optional overrides from ctx.config ----
        from core.runtime_context import cfg_get
        
        override_id   = None
        override_name = None  # can be run_label or run_name (see below)
        try:
            if getattr(self, "ctx", None) is not None:
                override_id   = cfg_get(self.ctx, "run_id",   None)   # numeric grouping id (optional)
                # Prefer a dedicated label if present; fall back to run_name in ctx
                override_name = (cfg_get(self.ctx, "run_label", None)
                                 or cfg_get(self.ctx, "run_name",  None))
        except Exception:
            pass
    
        # ---- choose numeric id (for grouping) ----
        try:
            if override_id is not None:
                run_num = int(override_id)
            else:
                run_num = _next_run_id(self._counter_path, self._plot_cache)
        except Exception:
            run_num = 1
    
        # ---- VizConfig label candidates ----
        cfg_label = None
        if getattr(self, "cfg", None) is not None:
            # if you added legend_label to VizConfig, prefer it; else fall back to cfg.run_name
            cfg_label = getattr(self.cfg, "legend_label", None) or getattr(self.cfg, "run_name", None)
    
        # ---- choose string label for legends (final precedence) ----
        if isinstance(override_name, str) and override_name.strip():
            run_label = override_name.strip()
        elif isinstance(cfg_label, str) and cfg_label.strip():
            run_label = cfg_label.strip()
        else:
            run_label = f"run {run_num}"
    
        # store both: numeric id for grouping, label for legend
        self.run_id    = int(run_num)
        self.run_label = run_label
    
    # keep/update a persistent mapping
        labels_by_rid = _load_run_labels(self._labels_path)
        labels_by_rid[str(int(self.run_id))] = str(self.run_label)
        _save_run_labels(self._labels_path, labels_by_rid)
        
        # stash for plotting
        self._labels_by_rid = {int(k): v for k, v in labels_by_rid.items() if str(k).isdigit()}

    
        # mirror to ctx so loggers can tag rows
        try:
            if getattr(self, "ctx", None) is not None:
                self.ctx.run_id    = int(self.run_id)
                self.ctx.run_label = str(self.run_label)
        except Exception:
            pass
    
        # ---- load prior rows for overlay (unchanged except run_id/label backfill) ----
        self._global_history = []
        self._agent_history  = []
        try:
            gjson = self.dir_run / getattr(self.cfg, "global_jsonl", "global.jsonl")
            ajson = self.dir_run / getattr(self.cfg, "agent_jsonl",  "agents.jsonl")
            used_any = False
            if gjson.exists() and ajson.exists():
                self._global_history = _load_jsonl(gjson) or []
                self._agent_history  = _load_jsonl(ajson) or []
                used_any = True
            if not used_any and self._plot_cache.exists():
                self._global_history = []
                self._agent_history  = []
                for row in _load_jsonl(self._plot_cache) or []:
                    if row.get("__kind__") == "global":
                        self._global_history.append({k:v for k,v in row.items() if k!="__kind__"})
                    elif row.get("__kind__") == "agent":
                        self._agent_history.append({k:v for k,v in row.items() if k!="__kind__"})
        except Exception:
            self._global_history, self._agent_history = [], []
    
                # ---- infer labels per run_id from history BEFORE backfilling ----
        def _collect_labels(rows):
            labels = {}
            for r in rows or []:
                rid = r.get("run_id", None)
                if rid is None:
                    continue
                try:
                    rid = int(rid)
                except Exception:
                    continue
                lab = r.get("run_label") or r.get("run_name")
                if lab and rid not in labels:
                    labels[rid] = str(lab)
            return labels
        
        labels_by_rid = {}
        labels_by_rid.update(_collect_labels(self._global_history))
        labels_by_rid.update(_collect_labels(self._agent_history))
        # ensure current run gets its live label
        labels_by_rid.setdefault(int(self.run_id), str(self.run_label))
        
        def _bf_per_run(rows, labels, default_rid):
            out = []
            for r in rows or []:
                rr = dict(r)
                rid = rr.get("run_id", default_rid)
                try:
                    rid = int(rid)
                except Exception:
                    rid = int(default_rid)
                rr.setdefault("run_id", rid)
                lab = labels.get(rid, None)
                # Only set labels if we actually have one for THIS rid
                if lab:
                    rr.setdefault("run_label", lab)
                    rr.setdefault("run_name",  lab)  # backward compat with existing code
                out.append(rr)
            return out
        
        self._global_history = _bf_per_run(self._global_history, labels_by_rid, self.run_id)
        self._agent_history  = _bf_per_run(self._agent_history,  labels_by_rid, self.run_id)

    
        # new-run buffers
        self.global_rows = []
        self.agent_rows  = []
    
        if isinstance(meta, dict):
            self.meta = dict(meta)



    
    # --------------------------
    # Logging
    # --------------------------
    def log_global(self, step: int, metrics: Dict[str, Any]):
        """Add a single global metrics row (merged with step & timestamp)."""
        row = {"step": int(step), "ts": _ts(), "run_id": self.run_id}
        row.update(metrics)
        self.global_rows.append(row)
        # Persist JSONL immediately for crash safety
        if self.cfg.enable_jsonl:
            _append_jsonl(self.dir_run / self.cfg.global_jsonl, row)
        # Remember header ordering
        if self._global_header is None:
            self._global_header = list(row.keys())

    def log_agent(self, step: int, agent_id: int | str, metrics: Dict[str, Any]):
        """Add a per-agent metrics row."""
        row = {"step": int(step), "agent": agent_id, "ts": _ts(), "run_id": self.run_id}
        row.update(metrics)
        self.agent_rows.append(row)
        if self.cfg.enable_jsonl:
            _append_jsonl(self.dir_run / self.cfg.agent_jsonl, row)
        if self._agent_header is None:
            self._agent_header = list(row.keys())

    # --------------------------
    # Periodic persistence & plots
    # --------------------------
    def maybe_flush(self, step: int):
        if (step % self.cfg.save_every_steps) != 0:
            return
        if self.cfg.enable_csv:
            if self.global_rows:
                self._flush_csv(self.dir_run / self.cfg.global_csv, self.global_rows, self._global_header)
            if self.agent_rows:
                self._flush_csv(self.dir_run / self.cfg.agent_csv, self.agent_rows, self._agent_header)

    def _flush_csv(self, path: Path, rows: List[Dict[str, Any]], header: Optional[List[str]]):
        if not rows:
            return
        if header is None:
            header = list(rows[0].keys())
        for r in rows:
            _save_csv_row(path, header, [r.get(h, "") for h in header])
        rows.clear()

    def maybe_plot(self, step: int):
        if not self.cfg.enable_plots or (step % self.cfg.plot_every_steps) != 0:
            return
        # Timeseries plots for a few core metrics
        self._plot_global_timeseries()
        self._plot_agent_timeseries()

    


    # replace _plot_global_timeseries() entirely
    def _plot_global_timeseries(self):
        # Merge prior runs + current run IN MEMORY (fast)
        default_rid = int(self.run_id or 1)
        rows = _normalize_plot_rows(self._global_history, self.global_rows, default_run_id=default_rid)
        if not rows:
            return
    
        # Group by normalized run_id (already ints)
        groups = {}
        for r in rows:
            groups.setdefault(r["run_id"], []).append(r)
        run_ids = sorted(groups.keys()) 
           
        preferred = ["E_total", "mean_total", "Action_total", "VFE_acc", "A_curv", "A_cov"]
        all_keys = set().union(*[r.keys() for r in rows])
    
        def _is_numeric_field(k: str) -> bool:
            # exclude internals/metadata
            if not k or k.startswith("_"):        # <- kills _seq, etc.
                return False
            if k in ("step", "ts", "run_id", "run_name", "run_label", "__kind__"):
                return False
            
            # numeric if any row has a numeric value
            return any(_is_num(r.get(k)) for r in rows)

    
        fields_pref = [k for k in preferred if k in all_keys and _is_numeric_field(k)]
        fields_rest = [k for k in sorted(all_keys) if k not in preferred and _is_numeric_field(k)]
        fields = [f for f in (fields_pref + fields_rest) if not _should_skip_field_global(f, rows, self.meta)]
        if not fields:
            return
    
        for field in fields:
            fig, ax = _safe_fig(figsize=(8,3), dpi=self.cfg.dpi)
            plotted_any = False
    
            for rid in run_ids:
                rs = groups[rid]
                # use custom name if present (logged alongside rows)
                run_name = _label_for_run(rs, rid, self.run_id, getattr(self, "run_label", None),
                          getattr(self, "_labels_by_rid", None))

                # rs already sorted by step
                steps = np.array([_to_num(r.get("step"))  for r in rs], dtype=float)
                vals  = np.array([_to_num(r.get(field)) for r in rs], dtype=float)
            
                # Segment on step decreases (resume/new run)
                breaks = np.where(np.diff(steps) < 0)[0] + 1
                segs = np.split(np.arange(len(steps)), breaks)
            
                # avoid duplicate legend entries per run
                labeled = False
                for idx in segs:
                    s = steps[idx]; y = vals[idx]
                    m = np.isfinite(s) & np.isfinite(y)
                    if np.any(m):
                        ax.plot(s[m], y[m], label=(run_name if not labeled else None))
                        labeled = True
                        plotted_any = True

    
            if not plotted_any:
                plt.close(fig); continue
    
            ax.set_xlabel("step"); ax.set_ylabel(field); ax.set_title(field)
            if plotted_any:
                ax.legend(loc="best", fontsize=8)
            _safe_savefig(fig, self.dir_plots / f"global_{field}.png")
           
    
    def _plot_agent_timeseries(self):
        default_rid = int(self.run_id or 1)
        rows = _normalize_plot_rows(self._agent_history, self.agent_rows, default_run_id=default_rid)
        if not rows:
            return
    
        # bucket by (run_id, agent)
        from collections import defaultdict
        by_ra = defaultdict(list)
        for r in rows:
            aid = r.get("agent")
            if aid is None:
                continue
            by_ra[(r["run_id"], aid)].append(r)
    
            
        # union numeric fields
        all_keys = set().union(*[r.keys() for r in rows])
        preferred = [
            "E_self", 
            "phi_norm_mean", "phi_model_norm_mean",
            "mu_q_norm_mean", "mu_p_norm_mean",   # <— add these
            ]
    
        def _is_numeric_field(k: str) -> bool:
            if not k or k.startswith("_"):
                return False
            if k in ("step", "agent", "ts", "run_id", "run_name", "run_label", "__kind__"):
                return False
            return any(_is_num(rr.get(k)) for rr in rows)

    
        fields = [k for k in preferred if k in all_keys and _is_numeric_field(k)] + [
            k for k in sorted(all_keys) if k not in preferred and _is_numeric_field(k)
        ]
    
        _MUST_KEEP = {
            "phi_norm_mean", "phi_model_norm_mean",
            "mu_q_norm_mean", "mu_p_norm_mean",   # <— add these
        }
        
        def _const_across_agents(field: str) -> bool:
            if field in _MUST_KEEP:
                return False
            vals = np.array([_to_num(r.get(field)) for r in rows], dtype=float)
            return _is_effectively_constant(vals)

    
        fields = [f for f in fields if not _const_across_agents(f)]
        if not fields:
            return
    
        for field in fields:
            fig, ax = _safe_fig(figsize=(8,3), dpi=self.cfg.dpi)
            plotted_any = False
    
            for (rid, aid), lst in by_ra.items():
                lst = sorted(lst, key=lambda r: r["step"])
                # pull a run-level name if present
                run_name = _label_for_run(lst, rid, self.run_id, getattr(self, "run_label", None),
                          getattr(self, "_labels_by_rid", None))

                s = np.array([r["step"] for r in lst], dtype=float)
                y = np.array([_to_num(r.get(field)) for r in lst], dtype=float)
            
                breaks = np.where(np.diff(s) < 0)[0] + 1
                segs = np.split(np.arange(len(s)), breaks)
            
                labeled = False
                for idx in segs:
                    ss = s[idx]; yy = y[idx]
                    m = np.isfinite(ss) & np.isfinite(yy)
                    if np.any(m):
                        ax.plot(ss[m], yy[m], label=(f"{aid}@{run_name}" if not labeled else None))
                        labeled = True
                        plotted_any = True

    
            if not plotted_any:
                plt.close(fig); continue
            ax.set_xlabel("step"); ax.set_ylabel(field); ax.set_title(field)
            if plotted_any:
                ax.legend(loc="best", fontsize=8)
               
            _safe_savefig(fig, self.dir_plots / f"agent_{field}.png")

            
    def maybe_snapshot(self, step, runtime_ctx, agents):
        """Save per-step snapshots. Render global A once; then per-agent fields."""
        # honor cadence
        try:
            every = int(getattr(self.cfg, "snapshot_every_steps", 100))
        except Exception:
            every = 50
        if every <= 0 or (step % every) != 0:
            return
    
        # step dir
        dstep = self.dir_snapshots / f"step_{step:04d}"
        dstep.mkdir(parents=True, exist_ok=True)
    
        # --- (1) Global A once ---
        try:
            self._snapshot_global_A_once(step, dstep, runtime_ctx)
        except Exception as e:
            print(f"[SNAPSHOT] global A failed: {e}")
    
        # --- (2) Per-agent (no A here) ---
        for a in (agents or []):
            if a is None:
                continue
            try:
                self._snapshot_agent(step, dstep, a, runtime_ctx)
            except Exception as e:
                # keep run alive; log minimal context
                try:
                    aid = _aid(a)
                except Exception:
                    aid = None
                print(f"[SNAPSHOT] agent {aid} failed: {e}")
    
    def _snapshot_global_A_once(self, step: int, dstep: Path, ctx: any):
        """
        Render ONE image set for the global connection A at this step.
        No-ops if already snapped this step or A is missing.
        """
        try:
            if not hasattr(ctx, "fields") or ctx.fields is None:
                return
            # guard: once per step
            if ctx.fields.get("_A_snap_step") == step:
                return
    
            A2 = _get_A_from_ctx_fields_for_snapshot(ctx)   # (H,W,2,3) or None
            if A2 is None:
                return  # nothing to draw yet
    
            Ax, Ay = A2[..., 0, :], A2[..., 1, :]
    
            self._save_heatmap(_field_norm(Ax), dstep / f"A_x_norm_step_{step:04d}.png")
            self._save_heatmap(_field_norm(Ay), dstep / f"A_y_norm_step_{step:04d}.png")
    
            # Curvature panels (fast; skip-if-fail)
            try:
                F, E_F = _curvature_from_A(A2)
                self._save_heatmap(np.linalg.norm(F, axis=-1), dstep / f"Curv_A_norm_step_{step:04d}.png")
                self._save_heatmap(E_F,                      dstep / f"Curv_A_energy_step_{step:04d}.png")
            except Exception:
                pass
    
            ctx.fields["_A_snap_step"] = step
        except Exception:
            pass


    def _snapshot_agent(self, step: int, dstep: Path, a: any, ctx: any):
        # Robust: never throw—snapshots must not crash the run.
        try:
            aid = _aid(a)
        except Exception:
            aid = "?"
    
        # --- outline setup (mask + tau) ---
        outline_mask = getattr(a, "mask", None)
        # Try to fetch support_tau from ctx.config; fallback to module config; else default
        try:
            support_tau = float(getattr(getattr(ctx, "config", {}), "support_tau", 1e-3))
        except Exception:
            try:
                import core.config as _cfg
                support_tau = float(getattr(_cfg, "support_tau", 1e-3))
            except Exception:
                support_tau = 1e-3
    
        # If mask is boolean, contour around 0.5 (after downsample) is cleaner
        if isinstance(outline_mask, np.ndarray) and outline_mask.dtype == np.bool_:
            outline_tau = 0.5
            outline_for_plot = outline_mask.astype(np.float32, copy=False)
        else:
            outline_tau = support_tau
            outline_for_plot = outline_mask
    
        def _save_with_outline(img: np.ndarray, name: str):
            path = dstep / f"Agent {aid}_{name}.png"
            if outline_for_plot is None:
                # No outline available
                self._save_heatmap(img, path)
                return
            # Prefer new signature with outline overlay; gracefully fall back if unavailable
            try:
                self._save_heatmap(img, path, outline_mask=outline_for_plot, tau=outline_tau)
            except TypeError:
                # Older _save_heatmap without outline support
                self._save_heatmap(img, path)
    
        def _maybe(name: str, getter, *, is_cov: bool = False):
            try:
                arr = getter()
                if arr is None:
                    return
                if is_cov:
                    # arr: (*S, K, K) → per-site log|Σ|
                    arr = np.asarray(arr, np.float32)
                    if arr.ndim < 3 or arr.shape[-1] != arr.shape[-2]:
                        return
                    K = arr.shape[-1]
                    flat = arr.reshape((-1, K, K))
                    sign, logabsdet = np.linalg.slogdet(flat.astype(np.float64, copy=False))
                    logabsdet = np.where(sign > 0, logabsdet.astype(np.float32), np.nan)
                    img = logabsdet.reshape(arr.shape[:-2])   # (*S,)
                else:
                    img = np.asarray(arr, np.float32)
    
                if np.any(np.isfinite(img)):
                    _save_with_outline(img, name)
            except Exception:
                pass
    
        # per-agent fields only (no A)
        _maybe("phi_norm",        lambda: _field_norm(getattr(a, "phi", None)))
        _maybe("phi_model_norm",  lambda: _field_norm(getattr(a, "phi_model", None)))
        _maybe("mu_q_norm",       lambda: _field_norm(getattr(a, "mu_q_field", None)))
        _maybe("mu_p_norm",       lambda: _field_norm(getattr(a, "mu_p_field", None)))
        _maybe("sigma_q_logdet",  lambda: np.asarray(getattr(a, "sigma_q_field", None)), is_cov=True)
        _maybe("sigma_p_logdet",  lambda: np.asarray(getattr(a, "sigma_p_field", None)), is_cov=True)

# --- in MetricsViz._save_heatmap: add an optional outline overlay ---
    def _save_heatmap(self, img: np.ndarray, path: Path, outline_mask: np.ndarray | None = None, *, tau: float = 1e-3):
        img = np.asarray(img)
    
        # RGB/RGBA direct save
        if img.ndim == 3 and img.shape[-1] in (3, 4):
            plt.imsave(path, _downsample(img, self.cfg.max_side))
            return
    
        # If there's a trailing channel dim, reduce it
        if img.ndim >= 3 and img.shape[-1] not in (img.shape[-2],):
            img = np.linalg.norm(img, axis=-1)
    
        # Reduce to 2-D for display
        if img.ndim > 2:
            img = _meanproject_to_2d(img, trailing=0)
        img = np.asarray(img, dtype=np.float32)
        if img.ndim != 2:
            img = np.squeeze(img)
            if img.ndim != 2:
                img = _center_slice_to_2d(img, trailing=0)
                img = np.asarray(img, dtype=np.float32)
    
        # Downsample image
        img = np.nan_to_num(img, nan=0.0, posinf=0.0, neginf=0.0)
        img_ds = _downsample(img, self.cfg.max_side)
    
        # Downsample outline to the same size (if provided)
        outline_ds = None
        if outline_mask is not None:
            om = np.asarray(outline_mask)
            # Reduce to 2-D if needed in the same way
            if om.ndim > 2:
                om = _meanproject_to_2d(om, trailing=0)
            if om.ndim != 2:
                om = np.squeeze(om)
                if om.ndim != 2:
                    om = _center_slice_to_2d(om, trailing=0)
            # ensure float for contour thresholding
            outline_ds = _downsample(om.astype(np.float32), self.cfg.max_side)
    
        # Render heatmap
        lo, hi = _robust_min_max(img_ds, self.cfg.robust_low, self.cfg.robust_high)
        fig, ax = _safe_fig(figsize=(4, 4), dpi=self.cfg.dpi)
        im = ax.imshow(img_ds, cmap=self.cfg.cmap, vmin=lo, vmax=hi, origin="lower")
        ax.set_xticks([]); ax.set_yticks([])
        fig.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
    
        # Overlay: contour at mask == tau (the “switch to zero” boundary with hard cutoff)
        if outline_ds is not None:
            try:
                # If your mask is already boolean, convert to {0,1} float
                if outline_ds.dtype == np.bool_:
                    outline_ds = outline_ds.astype(np.float32)
                # Draw the iso-curve where mask == tau
                ax.contour(outline_ds, levels=[tau], colors="w", linewidths=0.8)
            except Exception:
                pass
    
        _safe_savefig(fig, path)


    def end_run(self):
        # write/update compact plot cache with history + this run
        try:
            all_rows = []
            for r in (self._global_history or []):
                rr = dict(r); rr["__kind__"] = "global"; all_rows.append(rr)
            for r in (self._agent_history or []):
                rr = dict(r); rr["__kind__"] = "agent";  all_rows.append(rr)
            for r in (self.global_rows or []):
                rr = dict(r); rr["__kind__"] = "global"; all_rows.append(rr)
            for r in (self.agent_rows or []):
                rr = dict(r); rr["__kind__"] = "agent";  all_rows.append(rr)
            # rewrite plot_cache.jsonl once (small, append-only lines)
            if all_rows:
                self._plot_cache.unlink(missing_ok=True)
                for rr in all_rows:
                    _append_jsonl(self._plot_cache, rr)
        except Exception:
            pass
        # (optional) any other teardown you already have


def _label_for_run(rows_for_run, rid, current_run_id, current_run_label, labels_by_rid=None):
    # 1) manifest wins
    if labels_by_rid and int(rid) in labels_by_rid:
        return labels_by_rid[int(rid)]
    # 2) any stored label on the rows of THIS run
    for r in rows_for_run or []:
        lab = r.get("run_label") or r.get("run_name")
        if isinstance(lab, str) and lab.strip():
            return lab.strip()
    # 3) only use in-memory label for the current run
    if int(rid) == int(current_run_id) and isinstance(current_run_label, str) and current_run_label.strip():
        return current_run_label.strip()
    # 4) fallback
    return f"run {rid}"

# ------------------------------
# small utility used by _snapshot_global_A_once
# ------------------------------
def _get_A_from_ctx_fields_for_snapshot(ctx_obj):
    """
    Accept:
      - (*S,  D, 3)  generalized D-axes connection (preferred)
      
    Return:
      - (H,W,2,3)  2-D slice/projection for visualization only.
    """
    try:
        A = getattr(ctx_obj, "fields", {}).get("A", None)
        if A is None:
            return None
        A = np.asarray(A, np.float32)

        # Legacy 3-vector per site → put into x and fake y=0
        if A.ndim == 3 and A.shape[-1] == 3:
            H, W = A.shape[:2]
            A_up = np.zeros((H, W, 2, 3), dtype=np.float32)
            A_up[..., 0, :] = A
            return A_up

        # Legacy 2D: already (H,W,2,3)
        if A.ndim == 4 and A.shape[-2:] == (2, 3):
            return A

        # General D: (*S, D, 3)
        if A.ndim >= 3 and A.shape[-1] == 3:
            D = A.shape[-2]
            if D < 1:
                return None
            # We need a 2-D slice for display. Strategy:
            #  - center-slice extra spatial dims (beyond two)
            #  - keep the first two connection directions (or replicate if D==1)
            As = _center_slice_to_2d(A[..., :min(2, D), :], trailing=2)  # → (H,W,min(2,D),3)
            if As.shape[-2] == 1:
                # replicate single dir into second slot for plotting symmetry
                H, W = As.shape[:2]
                A2 = np.zeros((H, W, 2, 3), dtype=np.float32)
                A2[..., 0, :] = As[..., 0, :]
                return A2
            if As.shape[-2:] == (2, 3):
                return As
            # sanity: reshape to (H,W,2,3) if possible
            H, W = As.shape[0], As.shape[1]
            return As.reshape(H, W, 2, 3).astype(np.float32, copy=False)

        return None
    except Exception:
        return None

#----------------------
# Convenience feature extractors
# ------------------------------
def _field_norm(field, mask=None):
    """
    Robust per-pixel magnitude for vector/tensor fields for snapshot images.
    - Works for arbitrary K: field shape (*S, K) → returns 2D array (*S,)
    - Computes in float64 with underflow-safe math.
    - Applies boolean mask via np.where (no multiply).
    """
    if field is None:
        return None
    arr = np.asarray(field)
    if arr.ndim < 2:
        return None

    # Vector-field case: last axis = K (handles K=2,3,...)
    if arr.ndim >= 2 and arr.shape[-1] >= 1:
        mag = _safe_vector_norm(arr).astype(np.float64, copy=False)
    else:
        return None

    # apply mask (bool) without multiply
    if mask is not None:
        mb = np.asarray(mask).astype(bool, copy=False)
        if mb.ndim == mag.ndim + 1 and mb.shape[-1] == 1:
            mb = mb[..., 0]
        if mb.shape != mag.shape:
            pad = (1,) * max(0, mag.ndim - mb.ndim)
            mb = np.broadcast_to(mb.reshape(pad + mb.shape), mag.shape)
        mag = np.where(mb, mag, 0.0)

    mag = np.where(np.isfinite(mag), mag, 0.0).astype(np.float64, copy=False)
    return mag




# --- plotting filters (constants / skips) ---
def _is_effectively_constant(vals: np.ndarray, rtol=1e-6, atol=1e-12) -> bool:
    """True if all finite vals are (almost) the same (incl. all-zero)."""
    if vals.size == 0:
        return True
    vals = vals[np.isfinite(vals)]
    if vals.size <= 1:
        return True
    return np.allclose(vals, vals[0], rtol=rtol, atol=atol)



def _coerce_int_like(v, default=None):
    """Coerce v into an int if possible; else return default."""
    try:
        if v is None:
            return default
        if isinstance(v, str):
            s = v.strip()
            if s == "" or s.lower() == "none":
                return default
            # allow "1.0"
            return int(float(s))
        if isinstance(v, (int, np.integer)):
            return int(v)
        if isinstance(v, (float, np.floating)):
            return int(v)
        return default
    except Exception:
        return default



def _normalize_plot_rows(history_rows, live_rows, default_run_id: int):
    """
    Merge history + live, coerce run_id, stable order, and de-dup (run_id, step).
    Returns a flat list of dict rows.
    """
    
    def _rid(x):
        try:
            return int(x)
        except Exception:
            return int(default_run_id)

    rows = []
    seq = 0
    for src in (history_rows or []):
        r = dict(src)
        r["run_id"] = _rid(r.get("run_id"))
        r["_seq"] = seq; seq += 1
        rows.append(r)
    for src in (live_rows or []):
        r = dict(src)
        r["run_id"] = _rid(r.get("run_id"))
        r["_seq"] = seq; seq += 1
        rows.append(r)

    # sort by (run_id, step, seq)
    rows.sort(key=lambda r: (r["run_id"], r.get("step", 0), r["_seq"]))

    # de-dup (run_id, step) keeping the last occurrence
    dedup = {}
    for r in rows:
        k = (r["run_id"], r.get("step", 0))
        dedup[k] = r  # last wins
    rows = sorted(dedup.values(), key=lambda r: (r["run_id"], r.get("step", 0), r["_seq"]))
    return rows



def _should_skip_field_global(field: str, rows: list[dict], meta: dict) -> bool:
    """Heuristics to skip boring or disabled series."""
    # 1) obvious boilerplate keys
    if field in {"num_agents", "Kq", "Kp"}:
        return True

    # 2) meta-driven weights (optional)
    #    If you pass mv.start_run(meta={"weights": {"feedback": 0.0, ...}}),
    #    we skip fields mapped to zero-weighted terms.
    weights = (meta or {}).get("weights", {}) or {}
    zero_terms = {k for k,v in weights.items() if isinstance(v, (int,float,np.floating)) and abs(v) < 1e-12}
    # common mapping from term name -> metric keys
    term_to_fields = {
        "self":     {"self_sum", "E_self", "self"},
        "feedback": {"feedback_sum", "E_feedback", "feedback"},
        "align_q":  {"align_q_sum", "E_align_q", "align_q"},
        "align_p":  {"align_p_sum", "E_align_p", "align_p"},
        
        "A_curv":   {"A_curv"},
        "A_cov":    {"A_cov"},
        "VFE":      {"VFE_acc", "VFE"},
        "ModelPrior": {"ModelPrior"},
    }
    for term in zero_terms:
        if field in term_to_fields.get(term, set()):
            return True

    # 3) meta-driven explicit lists (optional)
    only = set((meta or {}).get("plot_only_fields", []) or [])
    if only and field not in only:
        return True
    skip = set((meta or {}).get("plot_skip_fields", []) or [])
    if field in skip:
        return True

    # 4) constant detection across all rows
    vals = np.array([_to_num(r.get(field)) for r in rows], dtype=float)
    return _is_effectively_constant(vals)

def _existing_run_ids_from_cache(cache_path: Path) -> list[int]:
    """
    Read plot_cache.jsonl (if present) and return a sorted list of run_ids.
    """
    try:
        if not cache_path.exists():
            return []
        ids = set()
        with cache_path.open("r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    obj = json.loads(line)
                except Exception:
                    continue
                rid = _coerce_int_like(obj.get("run_id"), default=None)
                if rid is not None:
                    ids.add(rid)
        return sorted(ids)
    except Exception:
        return []

def _load_run_labels(path):
    try:
        import json
        if path.exists():
            return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        pass
    return {}

def _save_run_labels(path, labels: dict):
    try:
        import json
        path.write_text(json.dumps(labels, ensure_ascii=False, indent=2), encoding="utf-8")
    except Exception:
        pass


def _next_run_id(counter_path: Path, cache_path: Path) -> int:
    """
    Determine the next run_id:
      1) If run_counter.txt exists, increment it and write back.
      2) Else, infer max run_id from plot_cache.jsonl and set next = max+1 (or 1).
         Persist that to run_counter.txt.
    """
    try:
        if counter_path.exists():
            try:
                last = int(counter_path.read_text(encoding="utf-8").strip() or "0")
            except Exception:
                last = 0
            nxt = max(1, last + 1)
            counter_path.write_text(str(nxt), encoding="utf-8")
            return nxt
        # infer from cache
        ids = _existing_run_ids_from_cache(cache_path)
        nxt = (max(ids) + 1) if ids else 1
        # persist
        try:
            counter_path.write_text(str(nxt), encoding="utf-8")
        except Exception:
            pass
        return nxt
    except Exception:
        return 1
