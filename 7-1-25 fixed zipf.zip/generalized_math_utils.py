import numpy as np
from scipy.ndimage import laplace

def sanitize_q(q, eps=1e-9):
    """Clip probabilities to [eps,1] and renormalize along the last axis."""
    q = np.clip(q, eps, 1.0)
    q /= np.sum(q, axis=-1, keepdims=True) + eps
    return q

def kl_divergence(p, q, eps=1e-9):
    """Pointwise D_KL(p || q) along the last axis."""
    p = sanitize_q(p, eps)
    q = sanitize_q(q, eps)
    return np.sum(p * (np.log(p) - np.log(q)), axis=-1)

def laplacian_field(field):
    """Compute component‐wise Laplacian over the last (fiber) axis."""
    return np.stack([laplace(field[..., i]) for i in range(field.shape[-1])], axis=-1)

def masked_norm(field, mask, ord=2):
    """
    Compute the mean over support of ‖field(x)‖ᵒʳᵈ, i.e.
      ∑ₓ ‖field(x)‖ * mask(x)  /  (∑ₓ mask(x))
    """
    norm_vals = np.linalg.norm(field, ord=ord, axis=-1)
    return np.sum(norm_vals * mask) / (np.sum(mask) + 1e-9)

def even_range(min_val, max_val, num_samples):
    """
    Return a list of `num_samples` evenly spaced even integers
    between `min_val` and `max_val`, inclusive if possible.
    """
    # Ensure min and max are even
    if min_val % 2 != 0:
        min_val += 1
    if max_val % 2 != 0:
        max_val -= 1

    # Generate linearly spaced values and round to nearest even
    lin = np.linspace(min_val, max_val, num_samples)
    even_vals = [int(round(x / 2) * 2) for x in lin]

    # Remove duplicates and return sorted list
    return sorted(set(even_vals))

import numpy as np

def safe_log(x, eps: float = 1e-12):
    """
    Numerically stable natural log.

    Parameters
    ----------
    x : float | np.ndarray
        Input value(s). Can be scalar or array-like.
    eps : float, optional
        Values below `eps` are clipped up to `eps` before taking log,
        preventing -inf.  Default is 1e-12.

    Returns
    -------
    np.ndarray | float
        np.log( max(x, eps) ), broadcast over x.
    """
    return np.log(np.clip(x, eps, None))
import warnings

# powerlaw_utils.py  – lightweight fallback
import numpy as np
import matplotlib.pyplot as plt
import config

def zipf_frequencies_from_q(q, mask=None):
    """Return normalised frequencies (shape K,) from q field."""
    if mask is not None:
        mask = (mask > config.support_cutoff_eps)  # ← convert to boolean
        counts = q[mask]
    else:
        counts = q.reshape(-1, q.shape[-1])
    return counts.sum(axis=0) / counts.sum()


from scipy.stats import linregress
import numpy as np
import warnings

def zipf_slope(freqs, rmin=3, rmax=None):
    freqs = np.asarray(freqs, dtype=float).ravel()
    freqs = freqs[freqs > 0]
    if freqs.size < 2:
        return 0.0, 0.0

    ranks = np.arange(1, len(freqs) + 1)
    if rmax is None or rmax > len(freqs):
        rmax = len(freqs)

    # select fit range
    x = np.log(ranks[rmin-1:rmax])
    y = np.log(freqs[rmin-1:rmax])

    if len(x) < 2 or np.std(y) < 1e-8 or not np.all(np.isfinite(y)):
        return 0.0, 0.0

    # fit log-log line
    slope, intercept, r, _, _ = linregress(x, y)
    return slope, r**2




def rank_frequency_plot(freqs, ax=None, **kwargs):
    """
    Plot a rank-frequency curve. Accepts optional matplotlib kwargs.
    """
    if ax is None:
        ax = plt.gca()
    ranks = np.arange(1, len(freqs) + 1)
    ax.loglog(ranks, freqs, marker='o', linestyle='', **kwargs)
    ax.set_xlabel("Rank")
    ax.set_ylabel("Frequency")
    return ax
