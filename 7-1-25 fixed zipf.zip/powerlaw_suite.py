"""
powerlaw_suite.py
=================
One-click Zipf analysis & visualisation.

* Reads every  step_XXXX.pkl  in CHECKPOINT_DIR   (≤ END_STEP if set).
* Computes per-agent and global Zipf slopes & R².
* Streams each frame into a GIF (no intermediate PNGs).
* Saves a CSV summary of slopes.

Just run this file; edit the CONFIG block to taste.
Importing the module does **not** run the analysis.
"""
# ----------------------------------------------------------------------
# Standard library
import sys, re, pickle, math, warnings
from pathlib import Path

# Third-party
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
from scipy.stats import linregress     # ← add this

from generalized_math_utils import (
    zipf_frequencies_from_q,
    zipf_slope,
    rank_frequency_plot,
)
# ----------------------------------------------------------------------
# CONFIG — adjust to suit your run
# ----------------------------------------------------------------------
CHECKPOINT_DIR = Path("checkpoints")   # folder with step_XXXX.pkl
END_STEP       = None                   # None ⇒ process all steps
PER_AGENT      = True                  # True ⇒ one panel per agent
FPS            = 6                     # frames per second in GIF
RMIN           = 3                     # drop top-rank tokens 1..RMIN-1
RMAX_FRAC      = 0.5                   # fit up to r = RMAX_FRAC * K
# Where to put GIFs and CSV
OUT_DIR        = Path("zipf_gifs")       # new folder for per-agent GIFs
OUT_CSV        = OUT_DIR / "slopes_summary.csv"
OUT_GLOBAL_GIF = OUT_DIR / "global_rankfreq.gif"   # optional pooled GIF

# ----------------------------------------------------------------------
# Prep output directory
# ----------------------------------------------------------------------
OUT_DIR.mkdir(parents=True, exist_ok=True)
# ----------------------------------------------------------------------
# Try to reuse existing utilities; otherwise fall back to minimal ones
# ----------------------------------------------------------------------

# ----------------------------------------------------------------------
def _get_imageio():
    """Import imageio safely (v2 shim if available)."""
    try:
        import imageio.v2 as imageio
    except ModuleNotFoundError:
        import imageio
    return imageio

# ----------------------------------------------------------------------
# ----------------------------------------------------------------------
# one-click power-law analysis (per-agent GIFs)
# ----------------------------------------------------------------------
def main():
    """Run the power-law analysis and export per-agent GIFs + CSV."""
    step_re = re.compile(r"step_(\d+)\.pkl")

    paths = sorted(
        (p for p in CHECKPOINT_DIR.glob("step_*.pkl")),
        key=lambda p: int(step_re.search(p.name).group(1))
    )
    if END_STEP is not None:
        paths = [p for p in paths
                 if int(step_re.search(p.name).group(1)) <= END_STEP]

    if not paths:
        sys.exit(f"[ERROR] No checkpoints found in {CHECKPOINT_DIR}")

    # ------------------------------------------------------------------
    # outputs
    # ------------------------------------------------------------------
    OUT_DIR.mkdir(parents=True, exist_ok=True)          # zipf_gifs/
    OUT_CSV.parent.mkdir(parents=True, exist_ok=True)   # same dir

    rows       = []                       # CSV rows
    imageio    = _get_imageio()           # lazy import helper
    writers    = {}                       # {agent_idx: imageio.get_writer}
    global_wr  = None                     # pooled GIF writer (optional)

    print(f"[INFO] analysing {len(paths)} checkpoints…")

    # ------------------------------------------------------------------
    # main loop over checkpoints
    # ------------------------------------------------------------------
    for ckpt in paths:
        step = int(step_re.search(ckpt.name).group(1))
        agents = pickle.loads(ckpt.read_bytes())

        # -- initialise writers on first checkpoint --------------------
        if not writers:
            n_agents = len(agents)
            for idx in range(n_agents):
                gif_path = OUT_DIR / f"A{idx}.gif"
                writers[idx] = imageio.get_writer(
                    gif_path, mode="I", loop=0,
                    subrectangles=True, fps=FPS
                )
            global_wr = imageio.get_writer(
                OUT_GLOBAL_GIF, mode="I", loop=0,
                subrectangles=True, fps=FPS
            )

        # -- per-agent processing -------------------------------------
        pooled = None
        for idx, A in enumerate(agents):
            mask   = getattr(A, "mask", None)
            freqs  = zipf_frequencies_from_q(A.q, mask)
            slope, r2 = zipf_slope(
                freqs, RMIN, int(len(freqs) * RMAX_FRAC)
            )

            # single-agent frame
            fig, ax = plt.subplots(figsize=(4, 3))
            rank_frequency_plot(freqs, ax=ax,
                                label=f"s={slope:+.3f}", alpha=0.8)
            ax.set_title(f"A{idx}  step={step}")
            ax.legend(fontsize=7)
            fig.tight_layout()

            # dump into writer
            fig.canvas.draw()
            img = np.frombuffer(fig.canvas.tostring_rgb(), np.uint8)
            img = img.reshape(fig.canvas.get_width_height()[::-1] + (3,))
            writers[idx].append_data(img)
            plt.close(fig)

            pooled = freqs if pooled is None else pooled + freqs
            rows.append({"step": step, "agent": idx,
                         "zipf_slope": slope, "zipf_r2": r2})

        # -- pooled/global curve --------------------------------------
        pooled /= pooled.sum()
        g_slope, g_r2 = zipf_slope(
            pooled, RMIN, int(len(pooled) * RMAX_FRAC)
        )
        rows.append({"step": step, "agent": "global",
                     "zipf_slope": g_slope, "zipf_r2": g_r2})

        fig_g, ax_g = plt.subplots(figsize=(5, 3))
        rank_frequency_plot(pooled, ax=ax_g,
                            label=f"s={g_slope:+.3f}", alpha=0.8)
        ax_g.set_title(f"GLOBAL  step={step}")
        ax_g.legend(fontsize=8)
        fig_g.tight_layout()

        fig_g.canvas.draw()
        img_g = np.frombuffer(fig_g.canvas.tostring_rgb(), np.uint8)
        img_g = img_g.reshape(fig_g.canvas.get_width_height()[::-1] + (3,))
        global_wr.append_data(img_g)
        plt.close(fig_g)

        print(f"  ✓ frame {step:04d}")

    # ------------------------------------------------------------------
    # close GIFs
    # ------------------------------------------------------------------
    for w in writers.values():
        w.close()
    global_wr.close()
    print(f"[GIFs]  saved to {OUT_DIR} (frames={len(paths)}, fps={FPS})")

    # ------------------------------------------------------------------
    # CSV summary
    # ------------------------------------------------------------------
    pd.DataFrame(rows).to_csv(OUT_CSV, index=False)
    print(f"[CSV]   saved → {OUT_CSV}")
    print("[DONE]  power-law analysis complete.")


# ----------------------------------------------------------------------
if __name__ == "__main__":
    main()
