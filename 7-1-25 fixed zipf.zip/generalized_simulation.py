# Standard library
import os
import time

# Third-party
import numpy as np
from joblib import Parallel, delayed
import pickle
import pandas as pd
from generalized_update_rules import synchronous_step
# Local configuration & utilities

from config_utils import set_config_from_params
from get_generators import infer_lie_algebra_dim, get_generators

# I/O helpers
from generalized_io_utils import (
    save_step,
    load_checkpoint,
    find_resume_step,
    save_config_to_readme,
)
import warnings

# Agent construction
from generalized_agents import (
    initialize_agents,
    generate_soft_mask,
    smooth_random_field,
    scale_to_range,
)
from generalized_agent_distributions import initialize_distribution
from generalized_agent_schema import Agent

# Update kernels
from generalized_update_rules import update_all

# Diagnostics
# for Zipf diagnostics
from powerlaw_suite import zipf_slope as rankfreq_slope_r2
             # existing helper

from generalized_diagnostics_metrics import (
    compute_kl_field,
    compute_alignment_field,
    compute_phi_norm_field,
    compute_entropy_field, 
    compute_model_alignment_field, 
    compute_coherence,  log_all_metrics_fused
)
import config

def run_simulation(
    outdir="checkpoints",
    resume=False,
    log_metrics=True,
    num_cores=None,
    params=None,
):
    # 1) Determine number of cores
    if num_cores is None:
        import multiprocessing
        num_cores = multiprocessing.cpu_count()

    # 2) Override config values if provided
    if params:
        set_config_from_params(params)

    os.makedirs(outdir, exist_ok=True)
    save_config_to_readme(outdir)

    # 3) Precompute Lie‐algebra generators (needed in both resume & fresh start)
    generators = get_generators(config.group_name, config.K)

    # 4) Load or initialize agents
    if resume:
        agents, _  = load_checkpoint(outdir)
        step_start = find_resume_step(outdir)
    else:
        lie_dim = generators.shape[0]
        agents = initialize_agents(
            seed             = getattr(config, "seed", None),
            domain_size      = config.domain_size,
            N                = config.N,
            K                = config.K,
            lie_algebra_dim  = lie_dim,
            visualize = False, 
            fixed_location = True 
        )
        step_start = 0

    metric_log = []
    print(f"[RUN] Starting simulation at step {step_start} with {num_cores} cores")

    # 5) Main loop
    for step in range(step_start, config.steps):
        print(f"\n[STEP {step}] -----------------------------")

        # 5a) Gradient update
        t0 = time.perf_counter()
        step_params = dict(params)  # make a shallow copy
        step_params["step"] = step  # inject current step
        agents = synchronous_step(agents, generators, params=step_params, n_jobs=num_cores)

        # 5a.1) Quick φ + KL diagnostics
        phi_norms         = [np.linalg.norm(A.phi) for A in agents]
        delta_phi_norms   = [np.linalg.norm(getattr(A, "delta_phi", 0)) for A in agents]
        kl_self_vals      = [
            np.sum((A.q * np.log((A.q + 1e-9) / (A.p + 1e-9)))[A.mask > 0]) for A in agents
            ]
        try:
            from generalized_diagnostics_metrics import compute_alignment_field
            kl_align_vals = [compute_alignment_field(agents, i).sum() for i in range(len(agents))]
        except Exception as exc:
            kl_align_vals = [0.0] * len(agents)

        #print(f"[φ norm]:     mean = {np.mean(phi_norms):.5f} | max = {np.max(phi_norms):.5f}")
        #print(f"[Δφ step]:    mean = {np.mean(delta_phi_norms):.5f} | max = {np.max(delta_phi_norms):.5f}")
        print(f"[KL(q‖p)]:    mean = {np.mean(kl_self_vals):.5f}")
        print(f"[KL(q‖Ωq_j)]: mean = {np.mean(kl_align_vals):.5f}")

        t1 = time.perf_counter()
        print(f"[TIMER] synchronous update: {t1 - t0:.3f}s")
        #print(f"[DEBUG] Step={step:03d} | curvature ‖F‖={m.get('curvature_norm', -1):.3e} | model ‖F̃‖={m.get('curvature_model_norm', -1):.3e}")

        # 5b) Diagnostics (fused)
        if log_metrics:
            t0 = time.perf_counter()
            m = log_all_metrics_fused(
                agents,
                step,
                params=params,
                q_field="q",
                p_field="p",
                phi_belief_field="phi",
                phi_model_field="phi_model",
                mask_field="mask",
                n_jobs=num_cores
            )
            metric_log.append({"step": step, **m})
            t1 = time.perf_counter()
            print(f"[TIMER] log_all_metrics_fused: {t1 - t0:.3f}s")
            #print(f"[DEBUG] Step={step:03d} | stored curvature ‖F‖={m.get('curvature_norm', -1):.3e} | model ‖F̃‖={m.get('curvature_model_norm', -1):.3e}")
        # 5c) Save state (clear Ω caches so they aren’t serialized)
        for A in agents:
            A.clear_omega_cache()
        save_step(agents, outdir, step)
        print(f"[SAVE] Checkpoint -> {outdir}/step_{step:04d}.pkl")

    # 6) Finalize metric log
    if log_metrics:
        with open(os.path.join(outdir, "metric_log.pkl"), "wb") as f:
            pickle.dump(metric_log, f)
        print(f"[SAVE] Metrics log -> {outdir}/metric_log.pkl")

        rows = []
        for A in agents:
            for entry in A.metrics_log:
                rows.append({"agent": A.id, **entry})
        df_agents = pd.DataFrame(rows)
        csv_path = os.path.join(outdir, "per_agent_metrics.csv")
        df_agents.to_csv(csv_path, index=False)
        print(f"[SAVE] Per‐agent metrics > {csv_path}")

    if log_metrics and not df_agents.empty:
        last_step = df_agents["step"].max()
        last_row = df_agents[df_agents["step"] == last_step]
        mean_F = last_row["curvature_norm"].mean()
        mean_F_model = last_row["curvature_model_norm"].mean()
        #print(f"[DEBUG] Final step={last_step:03d} | avg agent curvature ‖F‖={mean_F:.3e} | model ‖F̃‖={mean_F_model:.3e}")

    print("[DONE] Simulation completed.")

    # ----------------------------------------------------------
    #  Global Zipf statistics (pooled q over all agents)
    # ----------------------------------------------------------
    pooled_q = sum((A.q for A in agents))
    pooled_q /= pooled_q.sum()          # normalise
    slope, r2 = rankfreq_slope_r2(
        pooled_q,
        rmin=3,
        rmax=int(len(pooled_q)*0.5)
    )

    print(f"[ZIPF] global slope = {slope:+.4f}  |  R² = {r2:.3f}")

    print("[DONE] Simulation completed.")
    return agents, metric_log, dict(zipf_slope=slope, zipf_r2=r2)

if __name__ == "__main__":
    import config
    from config_utils import set_config_from_params

    # Extract all user-defined config values as a params dict
    params = {
        k: getattr(config, k)
        for k in dir(config)
        if not k.startswith("__") and not callable(getattr(config, k))
    }

    # Optional: apply overrides right here
    set_config_from_params(params)

    agents, metric_log, zipf_stats = run_simulation(
        outdir="checkpoints",
        resume=False,
        log_metrics=True,
        params=params
    )    
    # quick sanity print
    print("Zipf summary:", zipf_stats)