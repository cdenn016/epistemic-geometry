# -*- coding: utf-8 -*-
"""
Created on Wed Jul 16 18:18:11 2025

@author: chris and christine
"""

# bundle_morphism_utils.py
import numpy as np
from typing import Optional, Tuple, List, Dict, Any, Union
import numpy as np
from scipy.ndimage import gaussian_filter
import config
from numerical_utils import sanitize_sigma, safe_inv, safe_logdet

from get_generators import get_generators, RhoFromGenerators

from scipy.linalg import expm
from collections import defaultdict
from generalized_math_utils import to_natural_params, from_natural_params
from omega import compute_exp_field

def compute_direct_morphisms(phi, phi_model, generators_q, generators_p, Phi_0, Phi_tilde_0):
    from omega import compute_exp_field
    import numpy as np

    Omega_q = compute_exp_field(phi, generators_q, scale=1)       # (..., K_q, K_q)
    Omega_p = compute_exp_field(phi_model, generators_p, scale=1) # (..., K_p, K_p)

    Omega_q_T = np.swapaxes(Omega_q, -1, -2)
    Omega_p_T = np.swapaxes(Omega_p, -1, -2)

    # Φ = Ω_p · Φ₀ · Ω_qᵀ   →  (..., K_p, K_q)
    tmp = np.matmul(Omega_p, Phi_0)
    Phi = np.matmul(tmp, Omega_q_T)

    # Φ̃ = Ω_q · Φ̃₀ · Ω_pᵀ  → (..., K_q, K_p)
    tmp_tilde = np.matmul(Omega_q, Phi_tilde_0)
    Phi_tilde = np.matmul(tmp_tilde, Omega_p_T)

    return Phi, Phi_tilde









fallback_counter = defaultdict(int)

def safe_batch_apply_morphism_nat(mu, sigma, Phi, eps=1e-8, fallback_value=1e-3):
    """
    Project (mu, Sigma) through a bundle morphism Φ using **natural parameters**.
    Adds fallback if output covariance is not SPD or produces NaNs.

    Args:
        mu:    (H, W, K_src)
        sigma: (H, W, K_src, K_src)
        Phi:   (H, W, K_tgt, K_src)
        eps:   stabilizer for inversion/logs
        fallback_value: default variance to use if output is invalid

    Returns:
        mu_out:    (H, W, K_tgt)
        sigma_out: (H, W, K_tgt, K_tgt)
    """
    theta1, theta2 = to_natural_params(mu, sigma, eps)
    theta1_out = np.einsum("...ij,...j->...i", Phi, theta1)
    theta2_out = np.einsum("...ij,...jk,...lk->...il", Phi, theta2, Phi)
    theta2_out = 0.5 * (theta2_out + theta2_out.transpose(0, 1, 3, 2))  # symmetrize

    mu_out, sigma_out = from_natural_params(theta1_out, theta2_out, eps)

    # Fallback if invalid
    H, W, K = mu_out.shape
    fallback_sigma = fallback_value * np.eye(K, dtype=sigma_out.dtype)

    for i in range(H):
        for j in range(W):
            if not np.all(np.isfinite(sigma_out[i, j])) or np.linalg.cond(sigma_out[i, j]) > 1e8:
                sigma_out[i, j] = fallback_sigma
                mu_out[i, j] = 0.0  # neutral fallback mean

    return mu_out, sigma_out




#======================================================================
#
#                    Initialization
#
#======================================================================



def generate_smooth_morphism_field(
    H, W,
    K_src, K_tgt,
    sigma=config.gaussian_blur_range_morphism,
    low_rank=None,
    seed=None,
    normalize=False,
    mask=None,
):
    """
    Generate a smooth spatial field of K_tgt × K_src morphisms.

    Args:
        H, W       : spatial domain
        K_src      : input dimension (e.g. q)
        K_tgt      : output dimension (e.g. p)
        sigma      : Gaussian blur σ (scalar or tuple)
        low_rank   : optional int ≤ min(K_src, K_tgt) for low-rank morphism
        seed       : optional random seed
        normalize  : if True, normalize each matrix to unit Frobenius norm
        mask       : (H, W) optional mask to apply (multiply per point)

    Returns:
        morphism_field : (H, W, K_tgt, K_src)
    """
    eps = 1e-8
    rng = np.random.default_rng(seed)
    rank = low_rank if low_rank is not None else min(K_src, K_tgt)

    field = np.zeros((H, W, K_tgt, K_src), dtype=np.float32)

    for r in range(rank):
        basis = rng.standard_normal((K_tgt, K_src)).astype(np.float32)
        coeff = rng.standard_normal((H, W)).astype(np.float32)
        coeff = gaussian_filter(coeff, sigma=sigma, mode="wrap")
        field += coeff[..., None, None] * basis[None, None, :, :]

    if normalize:
        norm = np.linalg.norm(field, axis=(-2, -1), keepdims=True)
        norm_safe = np.where(norm > eps, norm, eps)
        field = field / norm_safe

    if mask is not None:
        field *= mask[..., None, None]

    return field



def clip_operator_norm(field: np.ndarray, max_norm: float = 1.0, eps: float = 1e-8) -> np.ndarray:
    """
    Enforce operator norm ≤ max_norm for each Φ(x) in (H,W,Kp,Kq)
    """
    H, W, Kp, Kq = field.shape
    field_out = np.empty_like(field)
    for i in range(H):
        for j in range(W):
            Phi = field[i, j]
            u, s, vh = np.linalg.svd(Phi, full_matrices=False)
            s_clipped = np.clip(s, 0, max_norm)
            Phi_clipped = (u @ np.diag(s_clipped) @ vh).astype(field.dtype)
            field_out[i, j] = Phi_clipped
    return field_out

def initialize_morphism_pair( 
    domain_size: Tuple[int, int],
    K_q: int,
    K_p: int,
    rng: np.random.Generator,
    morphism_type: str = "identity",
    mask: Optional[np.ndarray] = None,
    config_tag: str = "",
    phi_q_field: Optional[np.ndarray] = None,
    phi_p_field: Optional[np.ndarray] = None,
    G_q: Optional[dict] = None,
    G_p: Optional[dict] = None,
) -> Tuple[np.ndarray, np.ndarray]:
    """
    Initialize bundle morphisms Φ (q→p) and Φ̃ (p→q), optionally with
    full SO(3)-gauge covariance via:
        Φ(x) = exp(φ_p(x)) · Φ₀(x) · exp(−φ_q(x))

    Args:
        domain_size    : (H, W)
        K_q, K_p       : belief and model fiber dims
        rng            : np.random.Generator
        morphism_type  : "identity", "smooth", "lowrank", or "gauge_covariant"
        mask           : agent support mask
        config_tag     : optional suffix to use e.g. config.morphism_sigma_tagname
        phi_q_field    : (H, W, 3) gauge field for belief bundle
        phi_p_field    : (H, W, 3) gauge field for model bundle
        G_q, G_p       : SO(3) generator dicts for q- and p-fibers

    Returns:
        phi_q_to_p : Φ : B_q → B_p   (H, W, K_p, K_q)
        phi_p_to_q : Φ̃: B_p → B_q   (H, W, K_q, K_p)
    """
    from bundle_morphism_utils import gauge_covariant_transform_phi

    H, W = domain_size

    if morphism_type == "identity":
        if K_q != K_p:
            raise ValueError(f"Cannot use identity morphism with mismatched K_q={K_q} and K_p={K_p}")
        eye = np.eye(K_q, dtype=np.float32)
        phi_q_to_p = np.broadcast_to(eye, (H, W, K_q, K_q)).copy()
        phi_p_to_q = np.broadcast_to(eye, (H, W, K_q, K_q)).copy()
        if mask is not None:
            phi_q_to_p = np.where(mask[..., None, None], phi_q_to_p, 0.0)
            phi_p_to_q = np.where(mask[..., None, None], phi_p_to_q, 0.0)
        return phi_q_to_p, phi_p_to_q

    if morphism_type == "gauge_covariant":
        assert phi_q_field is not None and phi_p_field is not None, "φ_q and φ_p fields required"
        assert G_q is not None and G_p is not None, "SO(3) generators G_q and G_p required"

        sigma = getattr(config, f"morphism_sigma{config_tag}", 1.5)
        rank  = getattr(config, f"morphism_rank{config_tag}", min(K_q, K_p))
        seed  = rng.integers(0, 1e9)

        # Initialize base morphisms in global (flat) frame
        # Initialize base morphisms in global (flat) frame
        Phi_0_q_to_p = generate_smooth_morphism_field(
            H, W, K_src=K_q, K_tgt=K_p,  # keep this order
            sigma=sigma, low_rank=rank,
            normalize=False, mask=mask, seed=seed
            )

        Phi_0_p_to_q = generate_smooth_morphism_field(
            H, W, K_src=K_p, K_tgt=K_q,  # keep this order
            sigma=sigma, low_rank=rank,
            normalize=False, mask=mask, seed=seed + 1
            )


        # Apply gauge covariance: Φ(x) = e^{φ_p} · Φ₀ · e^{-φ_q}
        phi_q_to_p = gauge_covariant_transform_phi(
            phi_p_field, phi_q_field, Phi_0_q_to_p,
            G_q=G_q, G_p=G_p
        )

        phi_p_to_q = gauge_covariant_transform_phi(
            phi_q_field, phi_p_field, Phi_0_p_to_q,
            G_q=G_p, G_p=G_q  # flipped!
        )

        if mask is not None:
            phi_q_to_p *= mask[..., None, None]
            phi_p_to_q *= mask[..., None, None]

        return phi_q_to_p, phi_p_to_q

    # Else: smooth/lowrank generic (not gauge covariant)
    sigma     = getattr(config, f"morphism_sigma{config_tag}", 1.5)
    rank      = getattr(config, f"morphism_rank{config_tag}", min(K_q, K_p))
    normalize = getattr(config, f"morphism_normalize{config_tag}", True)
    seed      = rng.integers(0, 1e9)

    phi_q_to_p = generate_smooth_morphism_field(
        H, W, K_src=K_q, K_tgt=K_p,
        sigma=sigma, low_rank=rank,
        normalize=False, mask=mask, seed=seed
    )

    phi_p_to_q = generate_smooth_morphism_field(
        H, W, K_src=K_p, K_tgt=K_q,
        sigma=sigma, low_rank=rank,
        normalize=False, mask=mask, seed=seed + 1
    )

    if normalize:
        phi_q_to_p = clip_operator_norm(phi_q_to_p, max_norm=1.0)
        phi_p_to_q = clip_operator_norm(phi_p_to_q, max_norm=1.0)

    return phi_q_to_p, phi_p_to_q




def compose_direct_morphisms(
    phi_q_field: np.ndarray,       # (H, W, 3)
    phi_p_field: np.ndarray,       # (H, W, 3)
    G_q,                           # (3, K_q, K_q) or dict
    G_p,                           # (3, K_p, K_p) or dict
) -> Tuple[np.ndarray, np.ndarray]:
    """
    Construct rectangular morphisms Φ: B_q → B_p and Φ̃: B_p → B_q
    via:
        Φ = exp(Δφ · G_rect)
        Φ̃ = exp(−Δφ · G_rect.T)
    where G_rect is a rectangular (3, K_p, K_q) generator set.
    """
    from scipy.linalg import expm

    # Convert to dict if needed
    if isinstance(G_q, np.ndarray): G_q = dict(Jx=G_q[0], Jy=G_q[1], Jz=G_q[2])
    if isinstance(G_p, np.ndarray): G_p = dict(Jx=G_p[0], Jy=G_p[1], Jz=G_p[2])

    H, W, _ = phi_q_field.shape
    K_q = G_q["Jx"].shape[0]
    K_p = G_p["Jx"].shape[0]

    Phi        = np.zeros((H, W, K_p, K_q), dtype=np.float32)
    Phi_tilde  = np.zeros((H, W, K_q, K_p), dtype=np.float32)

    # Construct rectangular generators (each 3-vector gives a matrix)
    G_rect = np.stack([
        G_p["Jx"] @ np.eye(K_q),  # shape: (K_p, K_q)
        G_p["Jy"] @ np.eye(K_q),
        G_p["Jz"] @ np.eye(K_q)
    ], axis=0)  # (3, K_p, K_q)

    for i in range(H):
        for j in range(W):
            Δφ = phi_p_field[i, j] - phi_q_field[i, j]
            A = Δφ[0]*G_rect[0] + Δφ[1]*G_rect[1] + Δφ[2]*G_rect[2]
            Phi[i, j] = expm(A)

            A_tilde = -Δφ[0]*G_rect[0].T - Δφ[1]*G_rect[1].T - Δφ[2]*G_rect[2].T
            Phi_tilde[i, j] = expm(A_tilde)

    return Phi, Phi_tilde


def gauge_covariant_transform_phi(
    phi_p, phi_q, Phi0,
    G_q, G_p,
    group_name="so3",
    eps=1e-8
):
    """
    Apply gauge-covariant morphism:
        Φ(x) = exp(φ_p(x)) · Φ₀(x) · exp(−φ_q(x))

    Args:
        phi_p    : (H, W, d) Lie algebra field for p-bundle
        phi_q    : (H, W, d) Lie algebra field for q-bundle
        Phi0     : (H, W, K_p, K_q) initial morphism
        G_q, G_p : (3, K, K) generator arrays
        group_name: "so3" or other group string (for antisymmetrization)
        eps      : small value for numerical safety

    Returns:
        Transformed morphism field: (H, W, K_p, K_q)
    """
    from omega import exp_lie_algebra_irrep

    # Compute exp(φ_p) and exp(φ_q)
    exp_phi_p = exp_lie_algebra_irrep(phi_p, G_p, group_name=group_name)         # (H, W, K_p, K_p)
    exp_phi_q = exp_lie_algebra_irrep(phi_q, G_q, group_name=group_name)         # (H, W, K_q, K_q)

    # Inverse = transpose for SO(3)
    exp_neg_phi_q = np.swapaxes(exp_phi_q, -1, -2)                               # (H, W, K_q, K_q)

    # Compose: Φ = exp(φ_p) · Φ₀ · exp(−φ_q)
    return np.einsum("...ik,...kj,...jl->...il", exp_phi_p, Phi0, exp_neg_phi_q)



def make_morphism_fn(rho_q_func, rho_p_func):
    """
    Returns a function that performs the gauge-covariant transformation:
        Φ(x) ↦ ρ_p(exp(φ_p(x))) · Φ₀(x) · ρ_q(exp(φ_q(x)))⁻¹

    This respects separate gauge fields for model and belief bundles.

    Args:
        rho_q_func : function mapping φ_q → ρ_q(exp(φ_q))
        rho_p_func : function mapping φ_p → ρ_p(exp(φ_p))

    Returns:
        morphism(agent_i, agent_j) → (H, W, K_p, K_q) transformed Φ
    """
    def morphism(agent_i, agent_j):
        phi_q_field = agent_j.phi           # φ_q: agent_j's gauge field on belief bundle
        phi_p_field = agent_i.phi_model     # φ_p: agent_i's gauge field on model bundle
        Phi0_field  = agent_j.bundle_morphism_q_to_p  # Φ₀(x): base morphism in global frame

        return gauge_covariant_transform_phi(
            phi_p_field, phi_q_field, Phi0_field,
            rho_q_func, rho_p_func
        )

    return morphism


