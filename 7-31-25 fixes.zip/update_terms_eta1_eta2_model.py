# -*- coding: utf-8 -*-
"""
Created on Sat Jul 26 08:46:17 2025

@author: chris and christine
"""

import numpy as np
from natural_params_utils import compute_bar_eta2_qj, compute_delta_eta
from numerical_utils import safe_inv
from numerical_utils import safe_inv
from natural_params_utils import (
    compute_bar_eta2_q_morphed,
    compute_delta_eta_p_Phi_q,
    apply_natural_gradient_batch_eta
)
from natural_params_utils import (
                                  compute_bar_eta2_q_morphed,
                                  compute_bar_eta2_p_morphed,
                                  compute_delta_eta_p_Phi_q,
                                  compute_delta_eta_q_PhiTilde_p, 
                                  natural_to_mu_sigma, apply_natural_gradient_batch_eta
                                  )
import config
from omega import compute_exp_field

def accumulate_eta_gradient_model(agent_i, agents, params):
    """
    Accumulate ∇_{η₁_p}, ∇_{η₂_p} for agent_i in model fiber using:

      - Feedback: KL(p_i || Φ q_i)
      - Alignment: KL(p_i || Ω̃_ij p_j)   and   KL(p_k || Ω̃_kj p_j) for i == j

    Updates:
        agent_i.grad_eta1_p_field
        agent_i.grad_eta2_p_field
    """
    eps   = config.support_cutoff_eps
    beta  = params.get("beta", config.beta)
    lambd = params.get("lambda", config.feedback_weight)

    # ── Masked self-fields ──
    mask     = agent_i.mask > eps
    mask1    = mask[..., None]
    mask2    = mask[..., None, None]

    eta1_q = agent_i.eta1_q_field * mask1
    eta2_q = agent_i.eta2_q_field * mask2
    eta1_p = agent_i.eta1_p_field * mask1
    eta2_p = agent_i.eta2_p_field * mask2
    Phi    = agent_i.bundle_morphism_q_to_p * mask2

    # ── Feedback ──
    grad_eta1_fb = grad_eta1_p_morphism_feedback(eta1_p, eta2_p, eta1_q, eta2_q, Phi, eps=eps)
    grad_eta2_fb = grad_eta2_p_morphism_feedback(eta1_p, eta2_p, eta1_q, eta2_q, Phi, eps=eps)

    # ── Alignment (i = source) ──
    grad_eta1_align = np.zeros_like(eta1_p)
    grad_eta2_align = np.zeros_like(eta2_p)
    for neighbor in agent_i.neighbors:
        agent_j = agents[neighbor["id"]]
        mask_j = agent_j.mask > eps
        joint_mask1 = mask[..., None] & mask_j[..., None]
        joint_mask2 = mask[..., None, None] & mask_j[..., None, None]

        Omega_tilde_ij = np.einsum("...ik,...kj->...ij", agent_i._exp_phi_model, agent_j._exp_neg_phi_model)

        grad_eta1_align += grad_eta1_pi_alignment(
            eta1_p, eta2_p,
            agent_j.eta1_p_field * joint_mask1,
            agent_j.eta2_p_field * joint_mask2,
            Omega_tilde_ij, eps=eps,
        )
        grad_eta2_align += grad_eta2_pi_alignment(
            eta1_p, eta2_p,
            agent_j.eta1_p_field * joint_mask1,
            agent_j.eta2_p_field * joint_mask2,
            Omega_tilde_ij, eps=eps,
        )

    # ── Alignment (i = target) ──
    grad_eta1_align_rev = np.zeros_like(eta1_p)
    grad_eta2_align_rev = np.zeros_like(eta2_p)
    for agent_k in agents:
        for neighbor in agent_k.neighbors:
            if neighbor.get("id") == agent_i.id:
                mask_k = agent_k.mask > eps
                joint_mask1 = mask_k[..., None] & mask1
                joint_mask2 = mask_k[..., None, None] & mask2

                Omega_tilde_kj = np.einsum("...ik,...kj->...ij", agent_k._exp_phi_model, agent_i._exp_neg_phi_model)

                grad_eta1_align_rev += grad_eta1_pj_alignment(
                    agent_k.eta1_p_field * joint_mask1,
                    agent_k.eta2_p_field * joint_mask2,
                    eta1_p, eta2_p,
                    Omega_tilde_kj, eps=eps,
                )
                grad_eta2_align_rev += grad_eta2_pj_alignment(
                    agent_k.eta1_p_field * joint_mask1,
                    agent_k.eta2_p_field * joint_mask2,
                    eta1_p, eta2_p,
                    Omega_tilde_kj, eps=eps,
                )

    # ── Combine all terms ──
    grad_eta1_total = lambd * grad_eta1_fb + beta * (grad_eta1_align + grad_eta1_align_rev)
    grad_eta2_total = lambd * grad_eta2_fb + beta * (grad_eta2_align + grad_eta2_align_rev)

    grad_eta1_total *= mask1
    grad_eta2_total *= mask2


    grad_eta1_total = np.clip(grad_eta1_total, -config.grad_eta1_clip, config.grad_eta1_clip)
    grad_eta2_total = np.clip(grad_eta2_total, -config.grad_eta2_clip, config.grad_eta2_clip)

    # Debug logging
    #print(f"[∇η1_p] norm = {np.linalg.norm(grad_eta1_total):.4e}")
   # print(f"[∇η2_p] norm = {np.linalg.norm(grad_eta2_total):.4e}")

    # Apply natural gradient (clipping is handled inside)
    delta_eta1, delta_eta2 = apply_natural_gradient_batch_eta(
        eta1_p, eta2_p, grad_eta1_total, grad_eta2_total, mask1, eps=eps
    )

    # Update gradient buffers
    agent_i.grad_eta1_p_field += delta_eta1
    agent_i.grad_eta2_p_field += delta_eta2

    # η₂_p will be sanitized downstream after update



def accumulate_eta_gradient_modelmm(agent_i, agents, params):
    """
    Accumulate ∇_{η₁_p}, ∇_{η₂_p} for agent_i in model fiber using:

      - Feedback: KL(p_i || Φ q_i)
      - Alignment: KL(p_i || Ω̃_ij p_j)   and   KL(p_k || Ω̃_kj p_j) for i == j

    Updates:
        agent_i.grad_eta1_p_field
        agent_i.grad_eta2_p_field
    """
    eps = config.support_cutoff_eps
    beta  = params.get("beta", config.beta)
    lambd = params.get("lambda", config.feedback_weight)

    # ── Masked inputs ──
    mask     = agent_i.mask > eps
    mask1    = mask[..., None]
    mask2    = mask[..., None, None]

    eta1_q   = agent_i.eta1_q_field * mask1
    eta2_q   = agent_i.eta2_q_field * mask2
    eta1_p   = agent_i.eta1_p_field * mask1
    eta2_p   = agent_i.eta2_p_field * mask2
    Phi      = agent_i.bundle_morphism_q_to_p * mask2

    # ── Feedback ──
    grad_eta1_fb = grad_eta1_p_morphism_feedback(eta1_p, eta2_p, eta1_q, eta2_q, Phi, eps=eps)
    grad_eta2_fb = grad_eta2_p_morphism_feedback(eta1_p, eta2_p, eta1_q, eta2_q, Phi, eps=eps)

    # ── Alignment (i = source) ──
    grad_eta1_align = np.zeros_like(eta1_p)
    grad_eta2_align = np.zeros_like(eta2_p)
    for neighbor in agent_i.neighbors:
        agent_j = agents[neighbor["id"]]

        Omega_tilde_ij = np.einsum("...ik,...kj->...ij", agent_i._exp_phi_model, agent_j._exp_neg_phi_model)

        grad_eta1_align += grad_eta1_pi_alignment(
            eta1_p, eta2_p,
            agent_j.eta1_p_field * mask1,
            agent_j.eta2_p_field * mask2,
            Omega_tilde_ij, eps=eps,
        )
        grad_eta2_align += grad_eta2_pi_alignment(
            eta1_p, eta2_p,
            agent_j.eta1_p_field * mask1,
            agent_j.eta2_p_field * mask2,
            Omega_tilde_ij, eps=eps,
        )

    # ── Alignment (i = target) ──
    grad_eta1_align_rev = np.zeros_like(eta1_p)
    grad_eta2_align_rev = np.zeros_like(eta2_p)
    for agent_k in agents:
        for neighbor in agent_k.neighbors:
            if neighbor.get("id") == agent_i.id:
                Omega_tilde_kj = np.einsum("...ik,...kj->...ij", agent_k._exp_phi_model, agent_i._exp_neg_phi_model)

                grad_eta1_align_rev += grad_eta1_pj_alignment(
                    agent_k.eta1_p_field * mask1,
                    agent_k.eta2_p_field * mask2,
                    eta1_p, eta2_p,
                    Omega_tilde_kj, eps=eps,
                )
                grad_eta2_align_rev += grad_eta2_pj_alignment(
                    agent_k.eta1_p_field * mask1,
                    agent_k.eta2_p_field * mask2,
                    eta1_p, eta2_p,
                    Omega_tilde_kj, eps=eps,
                )

    # ── Combine ──
    grad_eta1_total = (
        lambd * grad_eta1_fb +
        beta  * (grad_eta1_align + grad_eta1_align_rev)
    )
    grad_eta2_total = (
        lambd * grad_eta2_fb +
        beta  * (grad_eta2_align + grad_eta2_align_rev)
    )

    grad_eta1_total *= mask1
    grad_eta2_total *= mask2

    grad_eta1_total = np.clip(grad_eta1_total, -config.grad_eta1_clip, config.grad_eta1_clip)
    grad_eta2_total = np.clip(grad_eta2_total, -config.grad_eta2_clip, config.grad_eta2_clip)

    delta_eta1, delta_eta2 = apply_natural_gradient_batch_eta(
        eta1_p, eta2_p, grad_eta1_total, grad_eta2_total, mask1, eps=eps
    )

    agent_i.grad_eta1_p_field += delta_eta1
    agent_i.grad_eta2_p_field += delta_eta2

def grad_eta1_p_morphism_feedback(
    eta1_p, eta2_p,
    eta1_q, eta2_q,
    Phi,
    eps=1e-8
):
    """
    ∇_{η₁_p} D_KL(p || Φ q)
    = ½ η₂_p⁻¹ η₁_p Φ η₁_q
      − ½ η₂_p⁻¹ η₁_p Φ η₂_q Φᵀ η₂_p⁻¹ η₁_p
    """
    from numerical_utils import safe_inv
    import numpy as np

    eta2_p_inv = safe_inv(eta2_p, eps=eps)

    # Compute μₚ = η₂ₚ⁻¹ η₁ₚ
    mu_p = np.einsum("...ij,...j->...i", eta2_p_inv, eta1_p)

    # First term: ½ μₚᵀ Φ η₁_q
    term1 = np.einsum("...i,...ij,...j->...i", mu_p, Phi, eta1_q)

    # Second term: ½ μₚᵀ Φ η₂_q Φᵀ μₚ
    temp = np.einsum("...ij,...jk->...ik", Phi, eta2_q)
    temp = np.einsum("...ik,...kj->...ij", temp, np.swapaxes(Phi, -1, -2))
    term2 = np.einsum("...i,...ij,...j->...i", mu_p, temp, mu_p)

    grad = 0.5 * (term1 - term2)
    return grad


def grad_eta1_p_morphism_feedbackolkd(eta1_p, eta2_p, eta1_q, eta2_q, Phi, eps=1e-8):
    """
    Compute:
        ∇_{η1_p} D_KL(p || Φ q)
        = -½ · η2_p⁻¹ · bar_eta2^Φ_q · Δη

    Inputs:
        eta1_p : (..., K_p)
        eta2_p : (..., K_p, K_p)
        eta1_q : (..., K_q)
        eta2_q : (..., K_q, K_q)
        Phi    : (..., K_p, K_q)

    Returns:
        grad_eta1_p : (..., K_p)
    """
    from numerical_utils import safe_inv
    eta2_inv_p = safe_inv(eta2_p, eps=eps)

    bar_eta2_Phi_q = compute_bar_eta2_q_morphed(eta2_q, Phi, eps=eps)
    bar_eta2_Phi_q = 0.5 * (bar_eta2_Phi_q + np.swapaxes(bar_eta2_Phi_q, -1, -2))  # Ensure symmetry

    delta_eta = compute_delta_eta_p_Phi_q(eta1_p, eta2_p, eta1_q, eta2_q, Phi, eps=eps)

    tmp = np.einsum("...ij,...j->...i", bar_eta2_Phi_q, delta_eta)
    grad_eta1_p = -0.5 * np.einsum("...ij,...j->...i", eta2_inv_p, tmp)
    return grad_eta1_p

def grad_eta2_p_morphism_feedback(
    eta1_p, eta2_p,
    eta1_q, eta2_q,
    Phi,
    eps=1e-8
):
    """
    ∇_{η₂_p} D_KL(p || Φ q) =

        ¼ η₂_p⁻¹ Φ η₂_q Φᵀ η₂_p⁻¹
      − ¼ η₂_p⁻¹
      − ½ η₂_p⁻¹ Φ η₂_q Φᵀ (μ_p ⊗ Δη) η₂_p⁻¹

    where:
        μ_p = η₂_p⁻¹ η₁_p
        Δη = η₁_p − Φ η₁_q
    """
    from numerical_utils import safe_inv
    import numpy as np

    # Inverses
    eta2_p_inv = safe_inv(eta2_p, eps=eps)
    eta2_q     = eta2_q

    # μ_p = η₂_p⁻¹ η₁_p
    mu_p = np.einsum("...ij,...j->...i", eta2_p_inv, eta1_p)  # (..., K_p)

    # Δη = η₁_p − Φ η₁_q
    push_eta1_q = np.einsum("...ij,...j->...i", Phi, eta1_q)  # (..., K_p)
    delta_eta = eta1_p - push_eta1_q  # (..., K_p)

    # bar_η₂_q = Φ η₂_q Φᵀ
    bar_eta2_q = np.einsum("...ik,...kl,...jl->...ij", Phi, eta2_q, Phi)

    # Term 1: ¼ η₂_p⁻¹ bar_η₂_q η₂_p⁻¹
    term1 = 0.25 * np.einsum("...ik,...kl,...lj->...ij", eta2_p_inv, bar_eta2_q, eta2_p_inv)

    # Term 2: −¼ η₂_p⁻¹
    term2 = -0.25 * eta2_p_inv

    # Term 3: −½ η₂_p⁻¹ bar_η₂_q (μ_p ⊗ Δη) η₂_p⁻¹
    mu_delta_outer = np.einsum("...i,...j->...ij", mu_p, delta_eta)
    term3_inner = np.einsum("...ik,...kl->...il", bar_eta2_q, mu_delta_outer)
    term3 = -0.5 * np.einsum("...ik,...kl->...il", term3_inner, eta2_p_inv)

    # Final gradient
    grad = term1 + term2 + term3
    return grad


def grad_eta2_p_morphism_feedbackold(eta1_p, eta2_p, eta1_q, eta2_q, Phi, eps=1e-8):
    """
    ∇_{η₂_p} KL(p || Φ q) in natural parameter space.

    Uses:
        ∇_{η₂_p} = -⅛ η₂_p⁻¹ [2η₂_p - Φ η₂_q Φᵀ - ½ (Φ η₂_q Φᵀ ⊗ μ_p) Δη] η₂_p⁻¹
    """
    from numerical_utils import safe_inv
    from natural_params_utils import compute_bar_eta2_q_morphed

    # η₂_p⁻¹
    eta2_inv_p = safe_inv(eta2_p, eps=eps)

    # μ_p = -½ η₂⁻¹ η₁
    mu_p = -0.5 * np.einsum("...ij,...j->...i", eta2_inv_p, eta1_p)

    # Δη = η₁_p - Φ η₁_q
    eta1_q_morphed = np.einsum("...ij,...j->...i", Phi, eta1_q)
    delta_eta = eta1_p - eta1_q_morphed

    # Pushforward η₂_q → bar_eta2_Phi_q = Φ η₂_q Φᵀ
    bar_eta2_Phi_q = compute_bar_eta2_q_morphed(eta2_q, Phi, eps=eps)
    bar_eta2_Phi_q = 0.5 * (bar_eta2_Phi_q + np.swapaxes(bar_eta2_Phi_q, -1, -2))  # ensure symmetry

    # Delta_Lambda = μ_p ⊗ Δη
    delta_Lambda = np.einsum("...i,...j->...ij", mu_p, delta_eta)

    # Bracket term inside sandwich
    bracket = 2.0 * eta2_p - bar_eta2_Phi_q - 0.5 * np.einsum("...ik,...kj->...ij", bar_eta2_Phi_q, delta_Lambda)

    # η₂⁻¹ [bracket] η₂⁻¹
    tmp = np.einsum("...ik,...kj->...ij", eta2_inv_p, bracket)
    grad_eta2 = -0.125 * np.einsum("...ik,...kj->...ij", tmp, eta2_inv_p)

    return grad_eta2

#=================================================
#
#             MODEL ALIGNMENT
#
#===================================================

def grad_eta1_pi_alignment(
    eta1_pi, eta2_pi,
    eta1_pj, eta2_pj,
    Omega_tilde_ij,
    eps=1e-8
):
    """
    Compute ∂/∂η₁_pᵢ KL(pᵢ || Ω̃ pⱼ)

    = ½ · η₂_pi⁻¹ [Ω̃ η₁_pj − Ω̃ η₂_pj Ω̃ᵀ μᵢ]
    where μᵢ = η₂_pi⁻¹ η₁_pi
    """
    from numerical_utils import safe_inv
    import numpy as np

    # Inverses
    eta2_pi_inv = safe_inv(eta2_pi, eps=eps)

    # μᵢ = η₂_pi⁻¹ η₁_pi
    mu_i = np.einsum("...ij,...j->...i", eta2_pi_inv, eta1_pi)

    # Term1 = Ω̃ η₁_pj
    term1 = np.einsum("...ij,...j->...i", Omega_tilde_ij, eta1_pj)

    # Term2 = Ω̃ η₂_pj Ω̃ᵀ μᵢ
    Omega_T = np.swapaxes(Omega_tilde_ij, -1, -2)
    tmp     = np.einsum("...ij,...jk->...ik", eta2_pj, Omega_T)
    projected = np.einsum("...ij,...j->...i",
        np.einsum("...ik,...kj->...ij", Omega_tilde_ij, tmp), mu_i)

    # Final gradient
    grad = 0.5 * np.einsum("...ij,...j->...i", eta2_pi_inv, term1 - projected)
    return grad

def grad_eta1_pj_alignment(
    eta1_pi, eta2_pi,
    eta1_pj, eta2_pj,
    Omega_tilde_ij,
    eps=1e-8
):
    """
    ∇_{η₁_pj} D_KL(p_i || Ω̃_ij p_j)
    = ½ · Ω̃_ijᵀ · [η₂_pi⁻¹ η₁_pi − Ω̃_ij η₂_pj⁻¹ η₁_pj]
    """
    from numerical_utils import safe_inv
    import numpy as np

    eta2_pi_inv = safe_inv(eta2_pi, eps=eps)  # (..., K, K)
    eta2_pj_inv = safe_inv(eta2_pj, eps=eps)

    # Δη = η₂_pi⁻¹ η₁_pi − Ω̃ η₂_pj⁻¹ η₁_pj
    mu_i = np.einsum("...ij,...j->...i", eta2_pi_inv, eta1_pi)
    mu_j = np.einsum("...ij,...j->...i", eta2_pj_inv, eta1_pj)
    push_mu_j = np.einsum("...ij,...j->...i", Omega_tilde_ij, mu_j)

    delta_eta = mu_i - push_mu_j  # (..., K)

    # grad = ½ · Ω̃ᵀ · Δη
    Omega_T = np.swapaxes(Omega_tilde_ij, -1, -2)
    grad = 0.5 * np.einsum("...ij,...j->...i", Omega_T, delta_eta)

    return grad

#validated 7-25-25
def grad_eta1_pi_alignmentold(eta1_pi, eta2_pi, eta1_pj, eta2_pj, Omega_tilde_ij, eps=1e-8):
    """
    ∇_{η1_pi} D_KL(p_i || Ω~_ij p_j)
    = -½ · bar_eta2_pj · Δη · η2_pi⁻¹
    """
    bar_eta2_pj = compute_bar_eta2_qj(eta2_pj, Omega_tilde_ij, eps=eps)
    delta_eta   = compute_delta_eta(eta1_pi, eta2_pi, eta1_pj, eta2_pj, Omega_tilde_ij, eps=eps)
    eta2_inv_pi = safe_inv(eta2_pi, eps=eps)

    tmp = np.einsum("...ij,...j->...i", bar_eta2_pj, delta_eta)
    grad = -0.5 * np.einsum("...i,...ij->...j", tmp, eta2_inv_pi)
    return grad

#validated 7-25-25
def grad_eta1_pj_alignmentold(eta1_pi, eta2_pi, eta1_pj, eta2_pj, Omega_tilde_ij, eps=1e-8):
    """
    ∇_{η1_pj} D_KL(p_i || Ω~_ij p_j)
    = +½ · Ω~_ijᵀ · bar_eta2_pj · Δη · η2_pi⁻¹
    """
    bar_eta2_pj = compute_bar_eta2_qj(eta2_pj, Omega_tilde_ij, eps=eps)
    delta_eta   = compute_delta_eta(eta1_pi, eta2_pi, eta1_pj, eta2_pj, Omega_tilde_ij, eps=eps)
    eta2_inv_pi = safe_inv(eta2_pi, eps=eps)

    tmp = np.einsum("...ij,...j->...i", bar_eta2_pj, delta_eta)
    tmp2 = np.einsum("...i,...ij->...j", tmp, eta2_inv_pi)
    grad = 0.5 * np.einsum("...ji,...i->...j", Omega_tilde_ij, tmp2)
    return grad


#=======================================
#
#     NEEDS REPLACED
#
#=====================================
def grad_eta2_pi_alignment(
    eta1_pi, eta2_pi,
    eta1_pj, eta2_pj,
    Omega_tilde_ij,
    eps=1e-8
):
    """
    ∇_{η₂_pi} D_KL(p_i || Ω̃_ij p_j) =

        + ⅛ · bar_eta2_pj · η₂_pi⁻¹
        − ¼ · η₂_pi
        + 1/16 · bar_eta2_pj · (μᵢ ⊗ μᵢ) · η₂_pi⁻¹
        − 1/16 · Ω̃ η₁_pj ⊗ μᵢ · η₂_pi⁻¹
    """
    from numerical_utils import safe_inv
    import numpy as np

    # Inverses
    eta2_pi_inv = safe_inv(eta2_pi, eps=eps)
    eta2_pj_inv = safe_inv(eta2_pj, eps=eps)

    # μᵢ = η₂_pi⁻¹ η₁_pi
    mu_i = np.einsum("...ij,...j->...i", eta2_pi_inv, eta1_pi)  # (..., K)

    # bar_eta2_pj = (Ω̃ η₂_pj⁻¹ Ω̃ᵀ)⁻¹
    Omega_eta2inv_OmegaT = np.einsum("...ik,...kl,...jl->...ij",
                                     Omega_tilde_ij, eta2_pj_inv, Omega_tilde_ij)
    bar_eta2_pj = safe_inv(Omega_eta2inv_OmegaT, eps=eps)
    bar_eta2_pj = 0.5 * (bar_eta2_pj + np.swapaxes(bar_eta2_pj, -1, -2))  # symmetrize

    # Term 1: ⅛ · bar_eta2_pj · η₂_pi⁻¹
    term1 = 0.125 * np.einsum("...ik,...kj->...ij", bar_eta2_pj, eta2_pi_inv)

    # Term 2: −¼ · η₂_pi
    term2 = -0.25 * eta2_pi

    # Term 3: 1/16 · bar_eta2_pj · (μᵢ ⊗ μᵢ) · η₂_pi⁻¹
    mu_outer = np.einsum("...i,...j->...ij", mu_i, mu_i)
    term3 = 0.0625 * np.einsum("...ik,...kl,...lj->...ij",
                               bar_eta2_pj, mu_outer, eta2_pi_inv)

    # Term 4: −1/16 · Ω̃ η₁_pj ⊗ μᵢ · η₂_pi⁻¹
    outer_Omega_eta1pj_mu = np.einsum(
        "...i,...j->...ij",
        np.einsum("...ik,...k->...i", Omega_tilde_ij, eta1_pj),
        mu_i
    )
    term4 = -0.0625 * np.einsum("...ik,...kj->...ij",
                                outer_Omega_eta1pj_mu, eta2_pi_inv)

    # Final gradient
    grad = term1 + term2 + term3 + term4
    return grad


def grad_eta2_pi_alignmentold(
    eta1_pi, eta2_pi,
    eta1_pj, eta2_pj,
    Omega_tilde_ij,
    eps=1e-8
):
    """
    Compute ∇_{η₂_pi} D_KL(p_i || Ω̃_ij p_j) using natural parameters:
    
        -1/8 · η₂_pi⁻¹ · [2η₂_pi − bar_η₂_pj − ½ bar_η₂_pj Λ_pi] · η₂_pi⁻¹

    where:
        bar_η₂_pj = (Ω̃ η₂_pj⁻¹ Ω̃ᵀ)⁻¹
        Λ_pi = Δη ⊗ (η₂_pi⁻¹ η₁_pi)
    """
    # Inverses
    eta2_pi_inv = safe_inv(eta2_pi, eps=eps)
    eta2_pj_inv = safe_inv(eta2_pj, eps=eps)

    # bar_η₂_pj = (Ω̃ η₂_pj⁻¹ Ω̃ᵀ)⁻¹
    Omega_eta2inv_OmegaT = np.einsum("...ik,...kl,...jl->...ij",
                                     Omega_tilde_ij, eta2_pj_inv, Omega_tilde_ij)
    bar_eta2_pj = safe_inv(Omega_eta2inv_OmegaT, eps=eps)

    # Δη = η₂_pi⁻¹ η₁_pi − Ω̃ η₂_pj⁻¹ η₁_pj
    term1 = np.einsum("...ij,...j->...i", eta2_pi_inv, eta1_pi)
    term2 = np.einsum("...ij,...jk,...k->...i", Omega_tilde_ij, eta2_pj_inv, eta1_pj)
    delta_eta = term1 - term2  # (..., K_p)

    # v = η₂_pi⁻¹ η₁_pi
    v = term1  # (..., K_p)

    # Λ_pi = delta_eta ⊗ v
    Lambda_pi = np.einsum("...i,...j->...ij", delta_eta, v)

    # Symmetrize bar_eta2_pj
    bar_eta2_pj_sym = 0.5 * (bar_eta2_pj + np.swapaxes(bar_eta2_pj, -1, -2))

    # Middle bracket term: [2η₂_pi − bar_η₂_pj − ½ bar_η₂_pj Λ_pi]
    term_middle = (
        2.0 * eta2_pi
        - bar_eta2_pj_sym
        - 0.5 * np.einsum("...ik,...kl->...il", bar_eta2_pj_sym, Lambda_pi)
    )

    # Final: -1/8 η₂_pi⁻¹ · term_middle · η₂_pi⁻¹
    grad = -0.125 * np.einsum(
        "...ik,...kl,...lj->...ij",
        eta2_pi_inv, term_middle, eta2_pi_inv
    )

    return grad

def grad_eta2_pj_alignment(
    eta1_pi, eta2_pi,
    eta1_pj, eta2_pj,
    Omega_tilde_ij,
    eps=1e-8
):
    """
    ∇_{η₂_pj} D_KL(p_i || Ω̃_ij p_j) =

        - ⅛ η₂_pj⁻¹
        - ⅛ Ω̃ η₂_pi⁻¹ Ω̃ᵀ
        - 1/16 Ω̃ᵀ Δη Δηᵀ Ω̃
        + 1/16 η₂_pj⁻¹ Ω̃ η₂_pj Ω̃ᵀ Δη ⊗ μⱼ η₂_pj⁻¹
    """
    from numerical_utils import safe_inv
    import numpy as np

    # Inverses
    eta2_pi_inv = safe_inv(eta2_pi, eps=eps)
    eta2_pj_inv = safe_inv(eta2_pj, eps=eps)

    # μⱼ = η₂_pj⁻¹ η₁_pj
    mu_j = np.einsum("...ij,...j->...i", eta2_pj_inv, eta1_pj)

    # Δη = η₂_pi⁻¹ η₁_pi − Ω̃ η₂_pj⁻¹ η₁_pj
    mu_i = np.einsum("...ij,...j->...i", eta2_pi_inv, eta1_pi)
    mu_j_pushed = np.einsum("...ij,...jk,...k->...i", Omega_tilde_ij, eta2_pj_inv, eta1_pj)
    delta_eta = mu_i - mu_j_pushed  # (..., K)

    # Term 1: −⅛ η₂_pj⁻¹
    term1 = -0.125 * eta2_pj_inv

    # Term 2: −⅛ Ω̃ η₂_pi⁻¹ Ω̃ᵀ
    Omega_eta2inv_pi_OmegaT = np.einsum("...ik,...kl,...jl->...ij",
                                        Omega_tilde_ij, eta2_pi_inv, Omega_tilde_ij)
    term2 = -0.125 * Omega_eta2inv_pi_OmegaT

    # Term 3: −1/16 Ω̃ᵀ Δη Δηᵀ Ω̃
    delta_outer = np.einsum("...i,...j->...ij", delta_eta, delta_eta)
    term3 = -0.0625 * np.einsum("...ki,...ij,...jl->...kl",
                                Omega_tilde_ij, delta_outer, Omega_tilde_ij)

    # Term 4: +1/16 η₂_pj⁻¹ Ω̃ η₂_pj Ω̃ᵀ Δη ⊗ μⱼ η₂_pj⁻¹
    Omega_eta2_pj = np.einsum("...ik,...kl->...il", Omega_tilde_ij, eta2_pj)
    A = np.einsum("...il,...lj->...ij", Omega_eta2_pj, np.swapaxes(Omega_tilde_ij, -1, -2))
    delta_mu_outer = np.einsum("...i,...j->...ij", delta_eta, mu_j)
    term4 = 0.0625 * np.einsum("...ik,...kl,...lj->...ij",
                               eta2_pj_inv, A,
                               np.einsum("...kl,...lj->...kj", delta_mu_outer, eta2_pj_inv))

    # Final gradient
    grad = term1 + term2 + term3 + term4
    return grad


def grad_eta2_pj_alignmentold(
    eta1_pi, eta2_pi,
    eta1_pj, eta2_pj,
    Omega_tilde_ij,
    eps=1e-8
):
    """
    Compute ∇_{η₂_pj} D_KL(p_i || Ω̃_ij p_j) using natural parameter form:
    
        -1/8 η₂_pj⁻¹ · [ Ω̃ᵀ (bar + bar η₂_pi⁻¹ bar + ½ bar Δη Δηᵀ bar) Ω̃
                         − ½ bar Λ_j ] · η₂_pj⁻¹
    """
    # Inverses
    eta2_pi_inv = safe_inv(eta2_pi, eps=eps)
    eta2_pj_inv = safe_inv(eta2_pj, eps=eps)

    # v_j = η₂_pj⁻¹ η₁_pj
    vj = np.einsum("...ij,...j->...i", eta2_pj_inv, eta1_pj)

    # Δη = η₂_pi⁻¹ η₁_pi − Ω̃ η₂_pj⁻¹ η₁_pj
    term1 = np.einsum("...ij,...j->...i", eta2_pi_inv, eta1_pi)
    term2 = np.einsum("...ij,...jk,...k->...i", Omega_tilde_ij, eta2_pj_inv, eta1_pj)
    delta_eta = term1 - term2  # (..., K_p)

    # Λ_j = delta_eta ⊗ v_j
    Lambda_j = np.einsum("...i,...j->...ij", delta_eta, vj)

    # bar_η₂_pj = (Ω̃ η₂_pj⁻¹ Ω̃ᵀ)⁻¹
    Omega_eta2inv_OmegaT = np.einsum("...ik,...kl,...jl->...ij",
                                     Omega_tilde_ij, eta2_pj_inv, Omega_tilde_ij)
    bar_eta2_pj = safe_inv(Omega_eta2inv_OmegaT, eps=eps)
    bar_eta2_pj_sym = 0.5 * (bar_eta2_pj + np.swapaxes(bar_eta2_pj, -1, -2))

    # Subterms
    term_A = bar_eta2_pj_sym
    term_B = np.einsum("...ik,...kl->...il", bar_eta2_pj_sym, eta2_pi_inv)
    term_B = np.einsum("...il,...lj->...ij", term_B, bar_eta2_pj_sym)

    tmp = np.einsum("...i,...j->...ij", delta_eta, delta_eta)
    term_C = np.einsum("...ik,...kl->...il", bar_eta2_pj_sym, tmp)
    term_C = np.einsum("...il,...lj->...ij", term_C, bar_eta2_pj_sym)

    # Full inner bracket
    full_inner = (
        term_A
        + term_B
        + 0.5 * term_C
    )

    term_D = 0.5 * np.einsum("...ik,...kj->...ij", bar_eta2_pj_sym, Lambda_j)

    # Wrap with Ω̃ᵀ and Ω̃
    term_ABC = np.einsum("...ki,...ij,...jl->...kl",
                         Omega_tilde_ij, full_inner, Omega_tilde_ij)

    bracket = term_ABC - term_D

    # Final contraction
    eta2_pj_inv_sym = 0.5 * (eta2_pj_inv + np.swapaxes(eta2_pj_inv, -1, -2))
    grad = -0.125 * np.einsum(
        "...ik,...kl,...lj->...ij",
        eta2_pj_inv_sym, bracket, eta2_pj_inv_sym
    )

    return grad

def grad_eta1_p_morphism_self(
    eta1_q, eta2_q,
    eta1_p, eta2_p,
    Phi_tilde,
    eps=1e-8
):
    """
    ∇_{η1_p} D_KL(q || Φ̃ p)
    = ½ η₂_p⁻¹ η₁_p − ½ Φ η₂_q⁻¹ η₁_q
    where Φ = Φ̃ᵀ
    """
    from numerical_utils import safe_inv
    import numpy as np

    # Inverses
    eta2_p_inv = safe_inv(eta2_p, eps=eps)
    eta2_q_inv = safe_inv(eta2_q, eps=eps)

    # Φ = Φ̃ᵀ
    Phi = np.swapaxes(Phi_tilde, -1, -2)

    # Terms
    term1 = np.einsum("...ij,...j->...i", eta2_p_inv, eta1_p)
    term2 = np.einsum("...ij,...jk,...k->...i", Phi, eta2_q_inv, eta1_q)

    grad = 0.5 * (term1 - term2)
    return grad

def grad_eta2_q_morphism_self(
    eta1_q, eta2_q,
    eta1_p, eta2_p,
    Phi_tilde,
    eps=1e-8
):
    """
    ∇_{η₂_q} D_KL(q || Φ̃ p) =

        ¼ η₂_q⁻¹ Φ̃ η₂_p Φ̃ᵀ η₂_q⁻¹
      − ¼ η₂_q⁻¹
      − ½ η₂_q⁻¹ Φ̃ η₂_p Φ̃ᵀ (Δη ⊗ μ_q) η₂_q⁻¹

    where:
        Δη = η₂_q⁻¹ η₁_q − Φ̃ η₂_p⁻¹ η₁_p
        μ_q = η₂_q⁻¹ η₁_q
    """
    from numerical_utils import safe_inv
    import numpy as np

    # Inverses
    eta2_q_inv = safe_inv(eta2_q, eps=eps)
    eta2_p_inv = safe_inv(eta2_p, eps=eps)

    # μ_q = η₂_q⁻¹ η₁_q
    mu_q = np.einsum("...ij,...j->...i", eta2_q_inv, eta1_q)

    # Δη = η₂_q⁻¹ η₁_q − Φ̃ η₂_p⁻¹ η₁_p
    push_mu_p = np.einsum("...ij,...jk,...k->...i", Phi_tilde, eta2_p_inv, eta1_p)
    delta_eta = mu_q - push_mu_p  # (..., K_q)

    # bar_η₂_p = Φ̃ η₂_p Φ̃ᵀ
    bar_eta2_p = np.einsum("...ik,...kl,...jl->...ij", Phi_tilde, eta2_p, Phi_tilde)

    # Term 1: ¼ η₂_q⁻¹ bar_η₂_p η₂_q⁻¹
    term1 = 0.25 * np.einsum("...ik,...kl,...lj->...ij",
                             eta2_q_inv, bar_eta2_p, eta2_q_inv)

    # Term 2: −¼ η₂_q⁻¹
    term2 = -0.25 * eta2_q_inv

    # Term 3: −½ η₂_q⁻¹ bar_η₂_p (Δη ⊗ μ_q) η₂_q⁻¹
    delta_outer = np.einsum("...i,...j->...ij", delta_eta, mu_q)  # (..., K_q, K_q)
    term3_inner = np.einsum("...ik,...kl->...il", bar_eta2_p, delta_outer)
    term3 = -0.5 * np.einsum("...ik,...kl->...il", term3_inner, eta2_q_inv)

    # Final gradient
    grad = term1 + term2 + term3
    return grad


def grad_eta1_p_morphism_selfold(eta1_q, eta2_q, eta1_p, eta2_p, Phi_tilde, eps=1e-8):
    """
    ∇_{η1_p} D_KL(q || Φ̃ p)
    = +½ η2_p⁻¹ · Φ̃ᵀ · bar_eta2^Φ̃_p · Δη
    """
    from numerical_utils import safe_inv

    eta2_inv_p = safe_inv(eta2_p, eps=eps)
    bar_eta2 = compute_bar_eta2_p_morphed(eta2_p, Phi_tilde, eps=eps)
    bar_eta2 = 0.5 * (bar_eta2 + np.swapaxes(bar_eta2, -1, -2))

    delta_eta = compute_delta_eta_q_PhiTilde_p(eta1_q, eta2_q, eta1_p, eta2_p, Phi_tilde, eps=eps)

    bar_eta_dot_delta = np.einsum("...ij,...j->...i", bar_eta2, delta_eta)
    Phi_T = np.swapaxes(Phi_tilde, -1, -2)
    push_term = np.einsum("...ij,...j->...i", Phi_T, bar_eta_dot_delta)

    return 0.5 * np.einsum("...ij,...j->...i", eta2_inv_p, push_term)

def grad_eta2_p_morphism_self(eta1_q, eta2_q, eta1_p, eta2_p, Phi_tilde, eps=1e-8):
    """
    ∇_{η₂_p} KL(q || Φ̃ p) using full natural parameter chain rule.
    All terms are expressed directly in η₁, η₂ space (no μ or Σ).

    Uses:
        ∇_{η₂_p} = -⅛ η₂_p⁻¹ [Φ̃ᵀ (⋯) Φ̃ + Φ̃ᵀ bar_eta₂_p Δη ⊗ μ_p Φ̃] η₂_p⁻¹
    """
    from numerical_utils import safe_inv
    from natural_params_utils import compute_bar_eta2_p_morphed

    # η₂_p⁻¹ and μ_p = -½ η₂⁻¹ η₁
    eta2_inv_p = safe_inv(eta2_p, eps=eps)
    mu_p = -0.5 * np.einsum("...ij,...j->...i", eta2_inv_p, eta1_p)

    # Pushforward η₂_p → bar_eta2 = Φ̃ η₂_p Φ̃ᵀ
    bar_eta2 = compute_bar_eta2_p_morphed(eta2_p, Phi_tilde, eps=eps)
    bar_eta2 = 0.5 * (bar_eta2 + np.swapaxes(bar_eta2, -1, -2))  # ensure symmetry

    # Δη = η₁_q − Φ̃ η₁_p
    eta1_p_morphed = np.einsum("...ij,...j->...i", Phi_tilde, eta1_p)
    delta_eta = eta1_q - eta1_p_morphed

    # (1) triple term: bar_eta2 η₂_p⁻¹ bar_eta2
    triple_term = np.einsum("...ik,...kl,...lj->...ij", bar_eta2, eta2_inv_p, bar_eta2)

    # (2) Mahalanobis term: ½ bar_eta2 Δη Δηᵀ bar_eta2
    delta_outer = np.einsum("...i,...j->...ij", delta_eta, delta_eta)
    mahal_term = 0.5 * np.einsum("...ik,...kl,...lj->...ij", bar_eta2, delta_outer, bar_eta2)

    # (3) Gradient of Σ: Φ̃ᵀ [ triple − bar_eta2 − mahal ] Φ̃
    grad_sigma = np.einsum(
        "...ik,...kl,...lj->...ij",
        Phi_tilde.swapaxes(-1, -2),
        triple_term - bar_eta2 - mahal_term,
        Phi_tilde
    )

    # (4) Gradient of μ: −Φ̃ᵀ bar_eta2 Δη
    grad_mu = -np.einsum("...ji,...j->...i", Phi_tilde, np.einsum("...ij,...j->...i", bar_eta2, delta_eta))

    # (5) Tensor product: grad_mu ⊗ μ_p
    outer = np.einsum("...i,...j->...ij", grad_mu, mu_p)

    # (6) Total bracket: grad_sigma + outer
    bracket = grad_sigma + outer

    # Final sandwich: −⅛ η₂⁻¹ [bracket] η₂⁻¹
    tmp = np.einsum("...ik,...kj->...ij", eta2_inv_p, bracket)
    grad_eta2 = -0.125 * np.einsum("...ik,...kj->...ij", tmp, eta2_inv_p)

    return grad_eta2


