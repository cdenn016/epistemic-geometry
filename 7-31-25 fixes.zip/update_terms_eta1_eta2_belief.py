# -*- coding: utf-8 -*-
"""
Created on Sat Jul 26 08:43:30 2025

@author: chris and christine
"""

import numpy as np
import config
from natural_params_utils import compute_bar_eta2_qj, compute_delta_eta
from numerical_utils import safe_inv
from natural_params_utils import ( 
                                  compute_bar_eta2_q_morphed,
                                  compute_bar_eta2_p_morphed,
                                  compute_delta_eta_p_Phi_q,
                                  compute_delta_eta_q_PhiTilde_p, 
                                  natural_to_mu_sigma, apply_natural_gradient_batch_eta
                                  )

from natural_params_utils import convert_eta_grads_to_mu_sigma
from omega import compute_exp_field

#=======================================================================
#
#                 Accumulate - need to also accum p-terms
#
#===========================================================================

def accumulate_eta_gradient_belief(agent_i, agents, params):
    """
    Accumulate ∇_{η₁_q}, ∇_{η₂_q} for agent_i directly in natural parameter space
    using variational gradients:

      - Self:     KL(q_i || Φ̃ p_i)
      - Feedback: KL(p_i || Φ q_i)
      - Alignment: KL(q_i || Ω_ij q_j)   and   KL(q_k || Ω_kj q_j) for i == j

    Updates:
        agent_i.grad_eta1_q_field
        agent_i.grad_eta2_q_field
    """
    eps = config.support_cutoff_eps
    alpha = params.get("alpha", config.alpha)
    beta  = params.get("beta", config.beta)
    lambd = params.get("lambda", config.feedback_weight)

    # ── Mask and fields ──
    mask     = agent_i.mask > eps
    mask1    = mask[..., None]
    mask2    = mask[..., None, None]

    eta1_q   = agent_i.eta1_q_field
    eta2_q   = agent_i.eta2_q_field
    eta1_p   = agent_i.eta1_p_field
    eta2_p   = agent_i.eta2_p_field
    Phi       = agent_i.bundle_morphism_q_to_p
    Phi_tilde = agent_i.bundle_morphism_p_to_q

    # ── Self-energy ──
    grad_eta1_self = grad_eta1_q_morphism_self(eta1_q, eta2_q, eta1_p, eta2_p, Phi_tilde, eps=eps)
    grad_eta2_self = grad_eta2_q_morphism_self(eta1_q, eta2_q, eta1_p, eta2_p, Phi_tilde, eps=eps)

    # ── Feedback ──
    grad_eta1_fb = grad_eta1_q_morphism_feedback(eta1_p, eta2_p, eta1_q, eta2_q, Phi, eps=eps)
    grad_eta2_fb = grad_eta2_q_morphism_feedback(eta1_p, eta2_p, eta1_q, eta2_q, Phi, eps=eps)

    # ── Alignment (i is source) ──
    grad_eta1_align = np.zeros_like(eta1_q)
    grad_eta2_align = np.zeros_like(eta2_q)

    for neighbor in agent_i.neighbors:
        agent_j = agents[neighbor["id"]]
        Omega_ij = np.einsum("...ik,...kj->...ij", agent_i._exp_phi, agent_j._exp_neg_phi)

        grad_eta1_align += grad_eta1_qi_alignment(
            eta1_q, eta2_q,
            agent_j.eta1_q_field,
            agent_j.eta2_q_field,
            Omega_ij, eps=eps,
        )
        grad_eta2_align += grad_eta2_qi_alignment(
            eta1_q, eta2_q,
            agent_j.eta1_q_field,
            agent_j.eta2_q_field,
            Omega_ij, eps=eps,
        )

    # ── Alignment (i is target) ──
    grad_eta1_align_rev = np.zeros_like(eta1_q)
    grad_eta2_align_rev = np.zeros_like(eta2_q)
    count = 0

    for agent_k in agents:
        for neighbor in agent_k.neighbors:
            if neighbor.get("id") == agent_i.id:
                Omega_kj = np.einsum("...ik,...kj->...ij", agent_k._exp_phi, agent_i._exp_neg_phi)

                grad_eta1_align_rev += grad_eta1_qj_alignment(
                    agent_k.eta1_q_field,
                    agent_k.eta2_q_field,
                    eta1_q, eta2_q, Omega_kj, eps=eps
                )
                grad_eta2_align_rev += grad_eta2_qj_alignment(
                    agent_k.eta1_q_field,
                    agent_k.eta2_q_field,
                    eta1_q, eta2_q, Omega_kj, eps=eps
                )
                count += 1

    if count > 0:
        grad_eta1_align_rev /= count
        grad_eta2_align_rev /= count

    # ── Combine and clip ──
    grad_eta1_total = (
        alpha * grad_eta1_self +
        0*lambd * grad_eta1_fb +
        beta * (grad_eta1_align + grad_eta1_align_rev)
    )
    grad_eta2_total = (
        alpha * grad_eta2_self +
        0*lambd * grad_eta2_fb +
        beta * (grad_eta2_align + grad_eta2_align_rev)
    )

    # Optional mask before clipping
    grad_eta1_total *= mask1
    grad_eta2_total *= mask2

    grad_eta1_total = np.clip(grad_eta1_total, -config.grad_eta1_clip, config.grad_eta1_clip)
    grad_eta2_total = np.clip(grad_eta2_total, -config.grad_eta2_clip, config.grad_eta2_clip)

    # Debug logging
    #print(f"[∇η1_q] norm = {np.linalg.norm(grad_eta1_total):.4e}")
    #print(f"[∇η2_q] norm = {np.linalg.norm(grad_eta2_total):.4e}")

    # ── Apply natural gradient step ──
    delta_eta1, delta_eta2 = apply_natural_gradient_batch_eta(
        eta1_q, eta2_q,
        grad_eta1_total, grad_eta2_total,
        mask1, eps=eps
    )

    agent_i.grad_eta1_q_field += delta_eta1
    agent_i.grad_eta2_q_field += delta_eta2


def accumulate_eta_gradient_belief_old(agent_i, agents, params):
    """
    Accumulate ∇_{η₁_q}, ∇_{η₂_q} for agent_i directly in natural parameter space
    using variational gradients:

      - Self:     KL(q_i || Φ̃ p_i)
      - Feedback: KL(p_i || Φ q_i)
      - Alignment: KL(q_i || Ω_ij q_j)   and   KL(q_k || Ω_kj q_j) for i == j

    Stores into:
        agent_i.grad_eta1_q_field
        agent_i.grad_eta2_q_field
    """
    eps = config.support_cutoff_eps
    alpha = params.get("alpha", config.alpha)
    beta  = params.get("beta", config.beta)
    lambd = params.get("lambda", config.feedback_weight)

    # ── Masked inputs ──
    mask     = agent_i.mask > eps
    mask1    = mask[..., None]
    mask2    = mask[..., None, None]

    eta1_q   = agent_i.eta1_q_field * mask1
    eta2_q   = agent_i.eta2_q_field * mask2
    eta1_p   = agent_i.eta1_p_field * mask1
    eta2_p   = agent_i.eta2_p_field * mask2
    Phi      = agent_i.bundle_morphism_q_to_p * mask2
    Phi_tilde = agent_i.bundle_morphism_p_to_q * mask2

    # ── Self-energy ──
    grad_eta1_self = grad_eta1_q_morphism_self(eta1_q, eta2_q, eta1_p, eta2_p, Phi_tilde, eps=eps)
    grad_eta2_self = grad_eta2_q_morphism_self(eta1_q, eta2_q, eta1_p, eta2_p, Phi_tilde, eps=eps)

    # ── Feedback ──
    grad_eta1_fb = grad_eta1_q_morphism_feedback(eta1_p, eta2_p, eta1_q, eta2_q, Phi, eps=eps)
    grad_eta2_fb = grad_eta2_q_morphism_feedback(eta1_p, eta2_p, eta1_q, eta2_q, Phi, eps=eps)

    # ── Alignment (i = source) ──
    grad_eta1_align = np.zeros_like(eta1_q)
    grad_eta2_align = np.zeros_like(eta2_q)
    for neighbor in agent_i.neighbors:
        agent_j = agents[neighbor["id"]]
        Omega_ij = np.einsum("...ik,...kj->...ij", agent_i._exp_phi, agent_j._exp_neg_phi)

        grad_eta1_align += grad_eta1_qi_alignment(
            eta1_q, eta2_q,
            agent_j.eta1_q_field * mask1,
            agent_j.eta2_q_field * mask2,
            Omega_ij, eps=eps,
        )
        grad_eta2_align += grad_eta2_qi_alignment(
            eta1_q, eta2_q,
            agent_j.eta1_q_field * mask1,
            agent_j.eta2_q_field * mask2,
            Omega_ij, eps=eps,
        )

    # ── Alignment (i = target) ──
    grad_eta1_align_rev = np.zeros_like(eta1_q)
    grad_eta2_align_rev = np.zeros_like(eta2_q)
    for agent_k in agents:
        for neighbor in agent_k.neighbors:
            if neighbor.get("id") == agent_i.id:
                Omega_kj = np.einsum("...ik,...kj->...ij", agent_k._exp_phi, agent_i._exp_neg_phi)

                grad_eta1_align_rev += grad_eta1_qj_alignment(
                    agent_k.eta1_q_field * mask1,
                    agent_k.eta2_q_field * mask2,
                    eta1_q, eta2_q, Omega_kj, eps=eps,
                )
                grad_eta2_align_rev += grad_eta2_qj_alignment(
                    agent_k.eta1_q_field * mask1,
                    agent_k.eta2_q_field * mask2,
                    eta1_q, eta2_q, Omega_kj, eps=eps,
                )

    # ── Combine ──
    grad_eta1_total = (
        alpha * grad_eta1_self +
        0 * lambd * grad_eta1_fb +
        beta * (grad_eta1_align + grad_eta1_align_rev)
    )
    grad_eta2_total = (
        alpha * grad_eta2_self +
        0 * lambd * grad_eta2_fb +
        beta * (grad_eta2_align + grad_eta2_align_rev)
    )

    grad_eta1_total *= mask1
    grad_eta2_total *= mask2

    grad_eta1_total = np.clip(grad_eta1_total, -config.grad_eta1_clip, config.grad_eta1_clip)
    grad_eta2_total = np.clip(grad_eta2_total, -config.grad_eta2_clip, config.grad_eta2_clip)

    delta_eta1, delta_eta2 = apply_natural_gradient_batch_eta(
        eta1_q, eta2_q, grad_eta1_total, grad_eta2_total, mask1, eps=eps
    )

    agent_i.grad_eta1_q_field += delta_eta1
    agent_i.grad_eta2_q_field += delta_eta2




#========================================================
#
#          Alignment Gradients wrt to eta1, eta2
#
#==========================================================

def grad_eta1_qi_alignment(
    eta1_qi, eta2_qi,
    eta1_qj, eta2_qj,
    Omega_ij,
    eps=1e-8
):
    """
    Compute ∂/∂η₁_qᵢ KL(qᵢ || Ω qⱼ)

    = ½ · η₂_qi⁻¹ [Ω η₁_qj − Ω η₂_qj Ωᵀ μᵢ]
    where μᵢ = ½ η₂_qi⁻¹ η₁_qi
    """
    from numerical_utils import safe_inv
    import numpy as np

    # Invert eta2_qi
    eta2_qi_inv = safe_inv(eta2_qi, eps=eps)
    eta2_qj     = eta2_qj
    eta1_qj     = eta1_qj

    # μᵢ =  η₂_qi⁻¹ η₁_qi
    mu_i =  np.einsum("...ij,...j->...i", eta2_qi_inv, eta1_qi)

    # Term1 = Ω η₁_qj
    term1 = np.einsum("...ij,...j->...i", Omega_ij, eta1_qj)

    # Term2 = Ω η₂_qj Ωᵀ μᵢ
    Omega_T = np.swapaxes(Omega_ij, -1, -2)
    tmp     = np.einsum("...ij,...jk->...ik", eta2_qj, Omega_T)
    projected = np.einsum("...ij,...j->...i", np.einsum("...ik,...kj->...ij", Omega_ij, tmp), mu_i)

    # Final gradient
    grad = 0.5 * np.einsum("...ij,...j->...i", eta2_qi_inv, term1 - projected)
    return grad


def grad_eta1_qj_alignment(
    eta1_qi, eta2_qi,
    eta1_qj, eta2_qj,
    Omega_ij, eps=1e-8
):
    """
    ∇_{η₁_qj} D_KL(q_i || Ω_ij q_j)
    = ½ · Ω_ijᵀ · [η2_qi⁻¹ η1_qi − Ω_ij η2_qj⁻¹ η1_qj]
    """
    from numerical_utils import safe_inv
    import numpy as np

    eta2_qi_inv = safe_inv(eta2_qi, eps=eps)  # (..., K, K)
    eta2_qj_inv = safe_inv(eta2_qj, eps=eps)

    # Δη = η2_qi⁻¹ η1_qi − Ω η2_qj⁻¹ η1_qj
    mu_i = np.einsum("...ij,...j->...i", eta2_qi_inv, eta1_qi)
    mu_j = np.einsum("...ij,...j->...i", eta2_qj_inv, eta1_qj)
    push_mu_j = np.einsum("...ij,...j->...i", Omega_ij, mu_j)

    delta_eta = mu_i - push_mu_j  # (..., K)

    # grad = ½ · Ωᵀ · Δη
    Omega_T = np.swapaxes(Omega_ij, -1, -2)
    grad = 0.5 * np.einsum("...ij,...j->...i", Omega_T, delta_eta)

    return grad



def grad_eta1_qi_alignmentold(eta1_qi, eta2_qi, eta1_qj, eta2_qj, Omega_ij, eps=1e-8):
    """
    ∇_{η₁_qi} D_KL(q_i || Ω_ij q_j)
    = -½ · η2_qi⁻¹ · bar_eta2_qj · Δη
    """
    import numpy as np
    np.set_printoptions(precision=4, suppress=True)

    bar_eta2_qj = compute_bar_eta2_qj(eta2_qj, Omega_ij, eps=eps)
    delta_eta   = compute_delta_eta(eta1_qi, eta2_qi, eta1_qj, eta2_qj, Omega_ij, eps=eps)
    eta2_inv_qi = safe_inv(eta2_qi, eps=eps)

    intermediate = np.einsum("...ij,...j->...i", bar_eta2_qj, delta_eta)
    grad         = -0.5 * np.einsum("...ij,...j->...i", eta2_inv_qi, intermediate)

    # ───── Debug Norms ─────
    fro_norm = lambda x: np.linalg.norm(x, axis=(-2, -1)) if x.ndim >= 2 else np.linalg.norm(x, axis=-1)
    vec_norm = lambda x: np.linalg.norm(x, axis=-1)

    #print("[DEBUG] ‖bar_eta2_qj‖_Frobenius:\n", fro_norm(bar_eta2_qj))
  #  print("[DEBUG] ‖delta_eta‖_2:\n", vec_norm(delta_eta))
  #  print("[DEBUG] ‖eta2_inv_qi‖_Frobenius:\n", fro_norm(eta2_inv_qi))
  #  print("[DEBUG] ‖bar_eta2_qj · delta_eta‖:\n", vec_norm(intermediate))
   # print("[DEBUG] ‖final grad‖:\n\n\n", vec_norm(grad))

    return grad

def grad_eta1_qj_alignmentold(eta1_qi, eta2_qi, eta1_qj, eta2_qj, Omega_ij, eps=1e-8):
    """
    ∇_{η₁_qj} D_KL(q_i || Ω_ij q_j)
    = -½ · η2_qj⁻¹ · Ω_ijᵀ · bar_eta2_qj · Δη
    """
    import numpy as np
    np.set_printoptions(precision=4, suppress=True)

    # ─── Core tensors ───
    bar_eta2_qj = compute_bar_eta2_qj(eta2_qj, Omega_ij, eps=eps)
    delta_eta   = compute_delta_eta(eta1_qi, eta2_qi, eta1_qj, eta2_qj, Omega_ij, eps=eps)
    eta2_inv_qj = safe_inv(eta2_qj, eps=eps)

    # ─── Intermediate products ───
    intermediate = np.einsum("...ij,...j->...i", bar_eta2_qj, delta_eta)
    Omega_T = np.swapaxes(Omega_ij, -1, -2)
    projected = np.einsum("...ij,...j->...i", Omega_T, intermediate)

    grad = -0.5 * np.einsum("...ij,...j->...i", eta2_inv_qj, projected)

    # ───── Debug Norms ─────
    fro_norm = lambda x: np.linalg.norm(x, axis=(-2, -1)) if x.ndim >= 2 else np.linalg.norm(x, axis=-1)
    vec_norm = lambda x: np.linalg.norm(x, axis=-1)

   # print("[DEBUG] ‖bar_eta2_qj‖_Frobenius:\n", fro_norm(bar_eta2_qj))
  #  print("[DEBUG] ‖delta_eta‖_2:\n", vec_norm(delta_eta))
  #  print("[DEBUG] ‖eta2_inv_qj‖_Frobenius:\n", fro_norm(eta2_inv_qj))
  #  print("[DEBUG] ‖bar_eta2_qj · delta_eta‖:\n", vec_norm(intermediate))
   # print("[DEBUG] ‖Ωᵀ · intermediate‖:\n", vec_norm(projected))
   # print("[DEBUG] ‖final grad‖:\n\n\n", vec_norm(grad))

    return grad








#===================================================================
#
#               alignment gradients with respect to eta2
#
#==================================================================




def grad_eta2_qi_alignment(
    eta1_qi, eta2_qi,
    eta1_qj, eta2_qj,
    Omega_ij,
    eps=1e-8
):
    """
    Compute ∇_{η₂_qi} D_KL(q_i || Ω_ij q_j) using:

      ∇ = ⅛ · bar_eta2_qj · η₂_qi⁻¹
         − ¼ · η₂_qi
         + 1/16 · bar_eta2_qj · (μᵢ ⊗ μᵢ) · η₂_qi⁻¹
         − 1/16 · Ω η₁_qj ⊗ μᵢ · η₂_qi⁻¹
    """
    from numerical_utils import safe_inv
    import numpy as np

    # Inverses
    eta2_qi_inv = safe_inv(eta2_qi, eps=eps)
    eta2_qj_inv = safe_inv(eta2_qj, eps=eps)

    # μᵢ =  η₂_qi⁻¹ η₁_qi
    mu_i =  np.einsum("...ij,...j->...i", eta2_qi_inv, eta1_qi)  # (..., K)

    # bar_eta2_qj = (Ω η₂_qj⁻¹ Ωᵀ)⁻¹
    Omega_eta2inv_OmegaT = np.einsum("...ik,...kl,...jl->...ij",
                                     Omega_ij, eta2_qj_inv, Omega_ij)
    bar_eta2_qj = safe_inv(Omega_eta2inv_OmegaT, eps=eps)
    bar_eta2_qj = 0.5 * (bar_eta2_qj + np.swapaxes(bar_eta2_qj, -1, -2))  # symmetrize

    # Term 1: ⅛ · bar_eta2_qj · η₂_qi⁻¹
    term1 = 0.125 * np.einsum("...ik,...kj->...ij", bar_eta2_qj, eta2_qi_inv)

    # Term 2: −¼ · η₂_qi
    term2 = -0.25 * eta2_qi

    # Term 3: 1/16 · bar_eta2_qj · (μᵢ ⊗ μᵢ) · η₂_qi⁻¹
    mu_outer = np.einsum("...i,...j->...ij", mu_i, mu_i)
    term3 = 0.0625 * np.einsum("...ik,...kl,...lj->...ij",
                               bar_eta2_qj, mu_outer, eta2_qi_inv)

    # Term 4: −1/16 · Ω η₁_qj ⊗ μᵢ · η₂_qi⁻¹
    outer_Omega_eta1j_mu = np.einsum(
        "...i,...j->...ij",
        np.einsum("...ik,...k->...i", Omega_ij, eta1_qj),
        mu_i
    )
    term4 = -0.0625 * np.einsum("...ik,...kj->...ij",
                                outer_Omega_eta1j_mu, eta2_qi_inv)

    # Final gradient
    grad = term1 + term2 + term3 + term4
    return grad

def grad_eta2_qj_alignment(
    eta1_qi, eta2_qi,
    eta1_qj, eta2_qj,
    Omega_ij,
    eps=1e-8
):
    """
    ∇_{η₂_qj} D_KL(q_i || Ω_ij q_j) =

    - ⅛ η₂_qj⁻¹
    - ⅛ Ω η₂_qi⁻¹ Ωᵀ
    - 1/16 Ωᵀ Δη Δηᵀ Ω
    + 1/16 η₂_qj⁻¹ Ω η₂_qj Ωᵀ Δη ⊗ μⱼ η₂_qj⁻¹
    """
    from numerical_utils import safe_inv
    import numpy as np

    # Inverses
    eta2_qi_inv = safe_inv(eta2_qi, eps=eps)
    eta2_qj_inv = safe_inv(eta2_qj, eps=eps)

    # 2μⱼ =  η₂_qj⁻¹ η₁_qj
    mu_j =  np.einsum("...ij,...j->...i", eta2_qj_inv, eta1_qj)

    # Δη = η₂_qi⁻¹ η₁_qi − Ω η₂_qj⁻¹ η₁_qj
    mu_i = np.einsum("...ij,...j->...i", eta2_qi_inv, eta1_qi)
    mu_j_pushed = np.einsum("...ij,...jk,...k->...i", Omega_ij, eta2_qj_inv, eta1_qj)
    delta_eta = mu_i - mu_j_pushed  # (..., K)

    # Term 1: −⅛ η₂_qj⁻¹
    term1 = -0.125 * eta2_qj_inv

    # Term 2: −⅛ Ω η₂_qi⁻¹ Ωᵀ
    Omega_eta2inv_qi_OmegaT = np.einsum("...ik,...kl,...jl->...ij",
                                        Omega_ij, eta2_qi_inv, Omega_ij)
    term2 = -0.125 * Omega_eta2inv_qi_OmegaT

    # Term 3: −1/16 Ωᵀ Δη Δηᵀ Ω
    delta_outer = np.einsum("...i,...j->...ij", delta_eta, delta_eta)
    term3 = -0.0625 * np.einsum("...ki,...ij,...jl->...kl",
                                Omega_ij, delta_outer, Omega_ij)

    # Term 4: +1/16 η₂_qj⁻¹ Ω η₂_qj Ωᵀ Δη ⊗ μⱼ η₂_qj⁻¹
    Omega_eta2_qj = np.einsum("...ik,...kl->...il", Omega_ij, eta2_qj)
    A = np.einsum("...il,...lj->...ij", Omega_eta2_qj, np.swapaxes(Omega_ij, -1, -2))
    delta_mu_outer = np.einsum("...i,...j->...ij", delta_eta, mu_j)
    term4 = 0.0625 * np.einsum("...ik,...kl,...lj->...ij",
                               eta2_qj_inv, A, np.einsum("...kl,...lj->...kj", delta_mu_outer, eta2_qj_inv))

    # Total gradient
    grad = term1 + term2 + term3 + term4
    return grad


def grad_eta2_qi_alignmentold(
    eta1_qi, eta2_qi,
    eta1_qj, eta2_qj,
    Omega_ij,
    eps=1e-8
):
    """
    Compute ∇_{η₂_qi} D_KL(q_i || Ω_ij q_j) using natural parameters,
    via the boxed expression:
    
        -1/8 · η₂_qi⁻¹ · [2η₂_qi − bar_η₂_qj − ½ bar_η₂_qj Λ_qi] · η₂_qi⁻¹

    where:
        bar_η₂_qj = (Ω η₂_qj⁻¹ Ωᵀ)⁻¹
        Λ_qi = Δη ⊗ (η₂_qi⁻¹ η₁_qi)
    """
    # Inverses
    eta2_qi_inv = safe_inv(eta2_qi, eps=eps)
    eta2_qj_inv = safe_inv(eta2_qj, eps=eps)

    # bar_η₂_qj = (Ω η₂_qj⁻¹ Ωᵀ)⁻¹
    Omega_eta2inv_OmegaT = np.einsum("...ik,...kl,...jl->...ij",
                                     Omega_ij, eta2_qj_inv, Omega_ij)
    bar_eta2_qj = safe_inv(Omega_eta2inv_OmegaT, eps=eps)

    # Δη = η₂_qi⁻¹ η₁_qi − Ω η₂_qj⁻¹ η₁_qj
    term1 = np.einsum("...ij,...j->...i", eta2_qi_inv, eta1_qi)
    term2 = np.einsum("...ij,...jk,...k->...i", Omega_ij, eta2_qj_inv, eta1_qj)
    delta_eta = term1 - term2  # (..., K_q)

    # v = η₂_qi⁻¹ η₁_qi
    v = term1  # (..., K_q)

    # Λ_qi = delta_eta ⊗ v = outer product
    Lambda_qi = np.einsum("...i,...j->...ij", delta_eta, v)

    # Symmetrize bar_eta2_qj
    bar_eta2_qj_sym = 0.5 * (bar_eta2_qj + np.swapaxes(bar_eta2_qj, -1, -2))

    # Middle bracket term: [2η₂_qi − bar_η₂_qj − ½ bar_η₂_qj Λ_qi]
    term_middle = (
        2.0 * eta2_qi
        - bar_eta2_qj_sym
        - 0.5 * np.einsum("...ik,...kl->...il", bar_eta2_qj_sym, Lambda_qi)
    )

    # Final: -1/8 η₂_qi⁻¹ · term_middle · η₂_qi⁻¹
    grad = -0.125 * np.einsum(
        "...ik,...kl,...lj->...ij",
        eta2_qi_inv, term_middle, eta2_qi_inv
    )

    return grad

def grad_eta2_qj_alignmentold(
    eta1_qi, eta2_qi,
    eta1_qj, eta2_qj,
    Omega_ij,
    eps=1e-8
):
    """
    Compute ∇_{η₂_qj} D_KL(q_i || Ω_ij q_j) in natural parameter space using:
    
        -1/8 η₂_qj⁻¹ · [ Ωᵀ (bar + bar η₂_qi⁻¹ bar + ½ bar Δη Δηᵀ bar) Ω
                         − ½ bar Λ_j ] · η₂_qj⁻¹

    where:
        bar = (Ω η₂_qj⁻¹ Ωᵀ)⁻¹
        Δη = η₂_qi⁻¹ η₁_qi − Ω η₂_qj⁻¹ η₁_qj
        Λ_j = Δη ⊗ (η₂_qj⁻¹ η₁_qj)
    """
    # Inverses
    eta2_qi_inv = safe_inv(eta2_qi, eps=eps)
    eta2_qj_inv = safe_inv(eta2_qj, eps=eps)

    # v_j = η₂_qj⁻¹ η₁_qj
    vj = np.einsum("...ij,...j->...i", eta2_qj_inv, eta1_qj)

    # Δη = η₂_qi⁻¹ η₁_qi − Ω η₂_qj⁻¹ η₁_qj
    term1 = np.einsum("...ij,...j->...i", eta2_qi_inv, eta1_qi)
    term2 = np.einsum("...ij,...jk,...k->...i", Omega_ij, eta2_qj_inv, eta1_qj)
    delta_eta = term1 - term2  # (..., K_q)

    # Λ_j = delta_eta ⊗ (η₂_qj⁻¹ η₁_qj)
    Lambda_j = np.einsum("...i,...j->...ij", delta_eta, vj)

    # bar_eta2_qj = (Ω η₂_qj⁻¹ Ωᵀ)⁻¹
    Omega_eta2inv_OmegaT = np.einsum("...ik,...kl,...jl->...ij",
                                     Omega_ij, eta2_qj_inv, Omega_ij)
    bar_eta2_qj = safe_inv(Omega_eta2inv_OmegaT, eps=eps)
    bar_eta2_qj_sym = 0.5 * (bar_eta2_qj + np.swapaxes(bar_eta2_qj, -1, -2))

    # Subterms
    term_A = bar_eta2_qj_sym
    term_B = np.einsum("...ik,...kl->...il", bar_eta2_qj_sym, eta2_qi_inv)
    term_B = np.einsum("...il,...lj->...ij", term_B, bar_eta2_qj_sym)

    tmp = np.einsum("...i,...j->...ij", delta_eta, delta_eta)
    term_C = np.einsum("...ik,...kl->...il", bar_eta2_qj_sym, tmp)
    term_C = np.einsum("...il,...lj->...ij", term_C, bar_eta2_qj_sym)

    # Full bracket:
    full_inner = (
        term_A
        + term_B
        + 0.5 * term_C
    )

    term_D = 0.5 * np.einsum("...ik,...kj->...ij", bar_eta2_qj_sym, Lambda_j)

    # Now wrap with Ωᵀ and Ω
    term_ABC = np.einsum("...ki,...ij,...jl->...kl",
                         Omega_ij, full_inner, Omega_ij)
    
    bracket = term_ABC - term_D

    # Final contraction
    eta2_qj_inv_sym = 0.5 * (eta2_qj_inv + np.swapaxes(eta2_qj_inv, -1, -2))
    grad = -0.125 * np.einsum(
        "...ik,...kl,...lj->...ij",
        eta2_qj_inv_sym, bracket, eta2_qj_inv_sym
    )

    return grad




#===================================================================
#
#               feedback gradients with respect to eta1
#
#==================================================================

def grad_eta1_q_morphism_feedback(
    eta1_p, eta2_p,
    eta1_q, eta2_q,
    Phi,
    eps=1e-8
):
    """
    ∇_{η₁_q} D_KL(p || Φ q)
    = ½ η₂_q⁻¹ η₁_q − ½ Φᵀ η₂_p⁻¹ η₁_p
    """
    from numerical_utils import safe_inv
    import numpy as np

    # Inverses
    eta2_q_inv = safe_inv(eta2_q, eps=eps)
    eta2_p_inv = safe_inv(eta2_p, eps=eps)

    # Φ̃ = Φᵀ
    Phi_tilde = np.swapaxes(Phi, -1, -2)

    # Terms
    term1 = np.einsum("...ij,...j->...i", eta2_q_inv, eta1_q)
    term2 = np.einsum("...ij,...jk,...k->...i", Phi_tilde, eta2_p_inv, eta1_p)

    grad = 0.5 * (term1 - term2)
    return grad

def grad_eta1_p_morphism_feedback(
    eta1_p, eta2_p,
    eta1_q, eta2_q,
    Phi,
    eps=1e-8
):
    """
    ∇_{η₁_p} D_KL(p || Φ q)
    = ½ η₂_p⁻¹ η₁_p Φ η₁_q
      − ½ η₂_p⁻¹ η₁_p Φ η₂_q Φᵀ η₂_p⁻¹ η₁_p
    """
    from numerical_utils import safe_inv
    import numpy as np

    eta2_p_inv = safe_inv(eta2_p, eps=eps)

    # Compute μₚ = η₂ₚ⁻¹ η₁ₚ
    mu_p = np.einsum("...ij,...j->...i", eta2_p_inv, eta1_p)

    # First term: ½ μₚᵀ Φ η₁_q
    term1 = np.einsum("...i,...ij,...j->...i", mu_p, Phi, eta1_q)

    # Second term: ½ μₚᵀ Φ η₂_q Φᵀ μₚ
    temp = np.einsum("...ij,...jk->...ik", Phi, eta2_q)
    temp = np.einsum("...ik,...kj->...ij", temp, np.swapaxes(Phi, -1, -2))
    term2 = np.einsum("...i,...ij,...j->...i", mu_p, temp, mu_p)

    grad = 0.5 * (term1 - term2)
    return grad


def grad_eta1_q_morphism_feedbackold(eta1_p, eta2_p, eta1_q, eta2_q, Phi, eps=1e-8):
    """
    Compute:
        ∂KL/∂η1_q = -½ η2_q⁻¹ · (Φᵀ · bar_eta2^Φ_q · Δη)

    Inputs:
        eta1_p, eta2_p : (..., K_p), (..., K_p, K_p)
        eta1_q, eta2_q : (..., K_q), (..., K_q, K_q)
        Phi            : (..., K_p, K_q)

    Returns:
        grad_eta1_q : (..., K_q)
    """
    from numerical_utils import safe_inv
    eta2_inv_q = safe_inv(eta2_q, eps=eps)

    bar_eta2_Phi_q = compute_bar_eta2_q_morphed(eta2_q, Phi, eps=eps)
    bar_eta2_Phi_q = 0.5 * (bar_eta2_Phi_q + np.swapaxes(bar_eta2_Phi_q, -1, -2))  # Ensure symmetry

    delta_eta = compute_delta_eta_p_Phi_q(eta1_p, eta2_p, eta1_q, eta2_q, Phi, eps=eps)

    tmp = np.einsum("...ij,...j->...i", bar_eta2_Phi_q, delta_eta)     # (..., K_p)
    tmp2 = np.einsum("...ij,...i->...j", Phi, tmp)                     # (..., K_q)

    grad_eta1_q = -0.5 * np.einsum("...ij,...j->...i", eta2_inv_q, tmp2)
    return grad_eta1_q


def grad_eta1_p_morphism_feedbackold(eta1_p, eta2_p, eta1_q, eta2_q, Phi, eps=1e-8):
    """
    Compute:
        ∇_{η1_p} D_KL(p || Φ q)
        = -½ · η2_p⁻¹ · bar_eta2^Φ_q · Δη

    Inputs:
        eta1_p : (..., K_p)
        eta2_p : (..., K_p, K_p)
        eta1_q : (..., K_q)
        eta2_q : (..., K_q, K_q)
        Phi    : (..., K_p, K_q)

    Returns:
        grad_eta1_p : (..., K_p)
    """
    from numerical_utils import safe_inv
    eta2_inv_p = safe_inv(eta2_p, eps=eps)

    bar_eta2_Phi_q = compute_bar_eta2_q_morphed(eta2_q, Phi, eps=eps)
    bar_eta2_Phi_q = 0.5 * (bar_eta2_Phi_q + np.swapaxes(bar_eta2_Phi_q, -1, -2))  # Ensure symmetry

    delta_eta = compute_delta_eta_p_Phi_q(eta1_p, eta2_p, eta1_q, eta2_q, Phi, eps=eps)

    tmp = np.einsum("...ij,...j->...i", bar_eta2_Phi_q, delta_eta)
    grad_eta1_p = -0.5 * np.einsum("...ij,...j->...i", eta2_inv_p, tmp)
    return grad_eta1_p



#===================================================================
#
#               feedback gradients with respect to eta2
#
#==================================================================

def grad_eta2_q_morphism_feedback(eta1_p, eta2_p, eta1_q, eta2_q, Phi, eps=1e-8):
    """
    ∇_{η₂_q} KL(p || Φ q) using only η₁, η₂ in natural parameter space.
    """
    from numerical_utils import safe_inv
    from natural_params_utils import compute_bar_eta2_q_morphed

    # Safe inverses and μ_q
    eta2_inv_q = safe_inv(eta2_q, eps=eps)
    mu_q = -0.5 * np.einsum("...ij,...j->...i", eta2_inv_q, eta1_q)

    # bar_eta2 = Φ η2_q Φᵀ
    bar_eta2 = compute_bar_eta2_q_morphed(eta2_q, Phi, eps=eps)
    bar_eta2 = 0.5 * (bar_eta2 + np.swapaxes(bar_eta2, -1, -2))

    # Δη = η1_p − Φ η1_q
    eta1_q_morphed = np.einsum("...ij,...j->...i", Phi, eta1_q)
    delta_eta = eta1_p - eta1_q_morphed

    # (1) Triple term: bar_eta2 η2_p⁻¹ bar_eta2
    eta2_inv_p = safe_inv(eta2_p, eps=eps)
    triple = np.einsum("...ik,...kl,...lj->...ij", bar_eta2, eta2_inv_p, bar_eta2)

    # (2) Mahalanobis term: ½ bar_eta2 Δη Δηᵀ bar_eta2
    delta_outer = np.einsum("...i,...j->...ij", delta_eta, delta_eta)
    mahal = 0.5 * np.einsum("...ik,...kl,...lj->...ij", bar_eta2, delta_outer, bar_eta2)

    # (3) ∇Σ = Φᵀ [ triple − bar_eta2 − mahal ] Φ
    grad_sigma = np.einsum(
        "...ik,...kl,...lj->...ij",
        Phi.swapaxes(-1, -2),
        triple - bar_eta2 - mahal,
        Phi
    )

    # (4) grad_mu = Φᵀ bar_eta2 Δη
    grad_mu = np.einsum("...ji,...j->...i", Phi, np.einsum("...ij,...j->...i", bar_eta2, delta_eta))

    # (5) grad_mu ⊗ μ_q
    outer = np.einsum("...i,...j->...ij", grad_mu, mu_q)

    # Total bracket
    bracket = grad_sigma + outer

    # Final projection to η₂_q: +⅛ η₂⁻¹ [bracket] η₂⁻¹
    tmp = np.einsum("...ik,...kj->...ij", eta2_inv_q, bracket)
    grad_eta2 = 0.125 * np.einsum("...ik,...kj->...ij", tmp, eta2_inv_q)

    return grad_eta2



def grad_eta2_p_morphism_feedback(eta1_p, eta2_p, eta1_q, eta2_q, Phi, eps=1e-8):
    """
    ∇_{η₂_p} KL(p || Φ q) in natural parameter space.

    Uses:
        ∇_{η₂_p} = -⅛ η₂_p⁻¹ [2η₂_p - Φ η₂_q Φᵀ - ½ (Φ η₂_q Φᵀ ⊗ μ_p) Δη] η₂_p⁻¹
    """
    from numerical_utils import safe_inv
    from natural_params_utils import compute_bar_eta2_q_morphed

    # η₂_p⁻¹
    eta2_inv_p = safe_inv(eta2_p, eps=eps)

    # μ_p = -½ η₂⁻¹ η₁
    mu_p = -0.5 * np.einsum("...ij,...j->...i", eta2_inv_p, eta1_p)

    # Δη = η₁_p - Φ η₁_q
    eta1_q_morphed = np.einsum("...ij,...j->...i", Phi, eta1_q)
    delta_eta = eta1_p - eta1_q_morphed

    # Pushforward η₂_q → bar_eta2_Phi_q = Φ η₂_q Φᵀ
    bar_eta2_Phi_q = compute_bar_eta2_q_morphed(eta2_q, Phi, eps=eps)
    bar_eta2_Phi_q = 0.5 * (bar_eta2_Phi_q + np.swapaxes(bar_eta2_Phi_q, -1, -2))  # ensure symmetry

    # Delta_Lambda = μ_p ⊗ Δη
    delta_Lambda = np.einsum("...i,...j->...ij", mu_p, delta_eta)

    # Bracket term inside sandwich
    bracket = 2.0 * eta2_p - bar_eta2_Phi_q - 0.5 * np.einsum("...ik,...kj->...ij", bar_eta2_Phi_q, delta_Lambda)

    # η₂⁻¹ [bracket] η₂⁻¹
    tmp = np.einsum("...ik,...kj->...ij", eta2_inv_p, bracket)
    grad_eta2 = -0.125 * np.einsum("...ik,...kj->...ij", tmp, eta2_inv_p)

    return grad_eta2








#===============================================
#
#                   SELF ENERGY TERMS
#
#=======================================
def grad_eta1_q_morphism_self(eta1_q, eta2_q, eta1_p, eta2_p, Phi_tilde, eps=1e-8):
    """
    ∇_{η1_q} D_KL(q || Φ̃ p)
    = -½ η2_q⁻¹ · bar_eta2^Φ̃_p · Δη
    """
    from numerical_utils import safe_inv

    eta2_inv_q = safe_inv(eta2_q, eps=eps)
    bar_eta2 = compute_bar_eta2_p_morphed(eta2_p, Phi_tilde, eps=eps)
    bar_eta2 = 0.5 * (bar_eta2 + np.swapaxes(bar_eta2, -1, -2))

    delta_eta = compute_delta_eta_q_PhiTilde_p(eta1_q, eta2_q, eta1_p, eta2_p, Phi_tilde, eps=eps)

    bar_eta_dot_delta = np.einsum("...ij,...j->...i", bar_eta2, delta_eta)
    return -0.5 * np.einsum("...ij,...j->...i", eta2_inv_q, bar_eta_dot_delta)


def grad_eta2_q_morphism_self(
    eta1_q, eta2_q,
    eta1_p, eta2_p,
    Phi_tilde,
    eps=1e-8
):
    """
    ∇_{η₂_q} D_KL(q || Φ̃ p) =

        ¼ η₂_q⁻¹ Φ̃ η₂_p Φ̃ᵀ η₂_q⁻¹
      − ¼ η₂_q⁻¹
      − ½ η₂_q⁻¹ Φ̃ η₂_p Φ̃ᵀ (Δη ⊗ μ_q) η₂_q⁻¹

    where:
        Δη = η₂_q⁻¹ η₁_q − Φ̃ η₂_p⁻¹ η₁_p
        μ_q = η₂_q⁻¹ η₁_q
    """
    from numerical_utils import safe_inv
    import numpy as np

    # Inverses
    eta2_q_inv = safe_inv(eta2_q, eps=eps)
    eta2_p_inv = safe_inv(eta2_p, eps=eps)

    # μ_q = η₂_q⁻¹ η₁_q
    mu_q = np.einsum("...ij,...j->...i", eta2_q_inv, eta1_q)

    # Δη = η₂_q⁻¹ η₁_q − Φ̃ η₂_p⁻¹ η₁_p
    push_mu_p = np.einsum("...ij,...jk,...k->...i", Phi_tilde, eta2_p_inv, eta1_p)
    delta_eta = mu_q - push_mu_p  # (..., K_q)

    # bar_η₂_p = Φ̃ η₂_p Φ̃ᵀ
    bar_eta2_p = np.einsum("...ik,...kl,...jl->...ij", Phi_tilde, eta2_p, Phi_tilde)

    # Term 1: ¼ η₂_q⁻¹ bar_η₂_p η₂_q⁻¹
    term1 = 0.25 * np.einsum("...ik,...kl,...lj->...ij",
                             eta2_q_inv, bar_eta2_p, eta2_q_inv)

    # Term 2: −¼ η₂_q⁻¹
    term2 = -0.25 * eta2_q_inv

    # Term 3: −½ η₂_q⁻¹ bar_η₂_p (Δη ⊗ μ_q) η₂_q⁻¹
    delta_outer = np.einsum("...i,...j->...ij", delta_eta, mu_q)  # (..., K_q, K_q)
    term3_inner = np.einsum("...ik,...kl->...il", bar_eta2_p, delta_outer)
    term3 = -0.5 * np.einsum("...ik,...kl->...il", term3_inner, eta2_q_inv)

    # Final gradient
    grad = term1 + term2 + term3
    return grad


def grad_eta2_q_morphism_selfold(
    eta1_q, eta2_q,
    eta1_p, eta2_p,
    Phi_tilde,
    eps=1e-8
):
    """
    ∇_{η₂_q} KL(q || Φ̃ p) in natural coordinates (entirely in η₁, η₂).

    Uses:
        ∇_{η₂_q} = -1/8 η₂⁻¹ [η̂₂^{Φ̃}_p - η₂_q - 1/2 (η̂₂^{Φ̃}_p Δη ⊗ η₂⁻¹ η₁)] η₂⁻¹
    """
    from numerical_utils import safe_inv
    from natural_params_utils import (
        compute_bar_eta2_p_morphed,
        compute_delta_eta_q_PhiTilde_p,
    )

    # Symmetrized morphed η₂_p
    bar_eta2 = compute_bar_eta2_p_morphed(eta2_p, Phi_tilde, eps=eps)
    bar_eta2 = 0.5 * (bar_eta2 + np.swapaxes(bar_eta2, -1, -2))

    # Δη = η₁_q - Φ̃ η₁_p
    delta_eta = compute_delta_eta_q_PhiTilde_p(
        eta1_q, eta2_q, eta1_p, eta2_p, Phi_tilde, eps=eps
    )

    # Compute η₂_q⁻¹
    eta2_q_inv = safe_inv(eta2_q, eps=eps)

    # μ_q = -½ η₂⁻¹ η₁
    mu_q = -0.5 * np.einsum("...ij,...j->...i", eta2_q_inv, eta1_q)

    # Δη ⊗ μ_q: (..., i, j) = Δη_i * μ_q_j
    delta_Lambda = np.einsum("...i,...j->...ij", delta_eta, mu_q)

    # Full term inside sandwich
    bracket_term = bar_eta2 - eta2_q - 0.5 * np.einsum("...ik,...kj->...ij", bar_eta2, delta_Lambda)

    # Sandwich: η₂⁻¹ [⋯] η₂⁻¹
    tmp = np.einsum("...ik,...kj->...ij", eta2_q_inv, bracket_term)
    grad_eta2 = -0.125 * np.einsum("...ik,...kj->...ij", tmp, eta2_q_inv)

    return grad_eta2

def grad_eta1_p_morphism_self(
    eta1_q, eta2_q,
    eta1_p, eta2_p,
    Phi_tilde,
    eps=1e-8
):
    """
    ∇_{η1_p} D_KL(q || Φ̃ p)
    = ½ η₂_p⁻¹ η₁_p − ½ Φ η₂_q⁻¹ η₁_q
    where Φ = Φ̃ᵀ
    """
    from numerical_utils import safe_inv
    import numpy as np

    # Inverses
    eta2_p_inv = safe_inv(eta2_p, eps=eps)
    eta2_q_inv = safe_inv(eta2_q, eps=eps)

    # Φ = Φ̃ᵀ
    Phi = np.swapaxes(Phi_tilde, -1, -2)

    # Terms
    term1 = np.einsum("...ij,...j->...i", eta2_p_inv, eta1_p)
    term2 = np.einsum("...ij,...jk,...k->...i", Phi, eta2_q_inv, eta1_q)

    grad = 0.5 * (term1 - term2)
    return grad


def grad_eta2_p_morphism_self(eta1_q, eta2_q, eta1_p, eta2_p, Phi_tilde, eps=1e-8):
    """
    ∇_{η₂_p} KL(q || Φ̃ p) using full natural parameter chain rule.
    All terms are expressed directly in η₁, η₂ space (no μ or Σ).

    Uses:
        ∇_{η₂_p} = -⅛ η₂_p⁻¹ [Φ̃ᵀ (⋯) Φ̃ + Φ̃ᵀ bar_eta₂_p Δη ⊗ μ_p Φ̃] η₂_p⁻¹
    """
    from numerical_utils import safe_inv
    from natural_params_utils import compute_bar_eta2_p_morphed

    # η₂_p⁻¹ and μ_p = -½ η₂⁻¹ η₁
    eta2_inv_p = safe_inv(eta2_p, eps=eps)
    mu_p = -0.5 * np.einsum("...ij,...j->...i", eta2_inv_p, eta1_p)

    # Pushforward η₂_p → bar_eta2 = Φ̃ η₂_p Φ̃ᵀ
    bar_eta2 = compute_bar_eta2_p_morphed(eta2_p, Phi_tilde, eps=eps)
    bar_eta2 = 0.5 * (bar_eta2 + np.swapaxes(bar_eta2, -1, -2))  # ensure symmetry

    # Δη = η₁_q − Φ̃ η₁_p
    eta1_p_morphed = np.einsum("...ij,...j->...i", Phi_tilde, eta1_p)
    delta_eta = eta1_q - eta1_p_morphed

    # (1) triple term: bar_eta2 η₂_p⁻¹ bar_eta2
    triple_term = np.einsum("...ik,...kl,...lj->...ij", bar_eta2, eta2_inv_p, bar_eta2)

    # (2) Mahalanobis term: ½ bar_eta2 Δη Δηᵀ bar_eta2
    delta_outer = np.einsum("...i,...j->...ij", delta_eta, delta_eta)
    mahal_term = 0.5 * np.einsum("...ik,...kl,...lj->...ij", bar_eta2, delta_outer, bar_eta2)

    # (3) Gradient of Σ: Φ̃ᵀ [ triple − bar_eta2 − mahal ] Φ̃
    grad_sigma = np.einsum(
        "...ik,...kl,...lj->...ij",
        Phi_tilde.swapaxes(-1, -2),
        triple_term - bar_eta2 - mahal_term,
        Phi_tilde
    )

    # (4) Gradient of μ: −Φ̃ᵀ bar_eta2 Δη
    grad_mu = -np.einsum("...ji,...j->...i", Phi_tilde, np.einsum("...ij,...j->...i", bar_eta2, delta_eta))

    # (5) Tensor product: grad_mu ⊗ μ_p
    outer = np.einsum("...i,...j->...ij", grad_mu, mu_p)

    # (6) Total bracket: grad_sigma + outer
    bracket = grad_sigma + outer

    # Final sandwich: −⅛ η₂⁻¹ [bracket] η₂⁻¹
    tmp = np.einsum("...ik,...kj->...ij", eta2_inv_p, bracket)
    grad_eta2 = -0.125 * np.einsum("...ik,...kj->...ij", tmp, eta2_inv_p)

    return grad_eta2





