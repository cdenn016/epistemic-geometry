# -*- coding: utf-8 -*-
"""
Created on Wed Jul 16 18:18:11 2025

@author: chris and christine
"""

# bundle_morphism_utils.py
import numpy as np
from typing import Optional, Tuple, List, Dict, Any, Union
import numpy as np
from scipy.ndimage import gaussian_filter
import config
from numerical_utils import sanitize_sigma, safe_inv, safe_logdet

from get_generators import build_rho_from_generators

from scipy.linalg import expm
from collections import defaultdict

def compute_direct_morphisms(
    phi_q: np.ndarray, phi_p: np.ndarray,
    Phi0_q_to_p: np.ndarray, Phi0_p_to_q: np.ndarray,
    generators_q: np.ndarray, generators_p: np.ndarray
) -> tuple[np.ndarray, np.ndarray]:
    """
    Compose Φ = e^{φ_p} · Φ₀ · e^{φ_q}ᵀ and Φ̃ = e^{φ_q} · Φ̃₀ · e^{φ_p}ᵀ.

    Args:
        phi_q       : (..., d), Lie algebra field for q-bundle
        phi_p       : (..., d), Lie algebra field for p-bundle
        Phi0_q_to_p : (..., K_p, K_q), base morphism q→p
        Phi0_p_to_q : (..., K_q, K_p), base morphism p→q
        generators_q: (d, K_q, K_q), SO(3) generators for q-bundle
        generators_p: (d, K_p, K_p), SO(3) generators for p-bundle

    Returns:
        Phi       : (..., K_p, K_q)
        Phi_tilde : (..., K_q, K_p)
    """
    from omega import compute_exp_field
    import numpy as np

    Omega_q = compute_exp_field(phi_q, generators_q)  # (..., K_q, K_q)
    Omega_p = compute_exp_field(phi_p, generators_p)  # (..., K_p, K_p)

    Omega_q_T = np.swapaxes(Omega_q, -2, -1)
    Omega_p_T = np.swapaxes(Omega_p, -2, -1)

    Phi       = np.einsum("...ik,...kl,...lj->...ij", Omega_p, Phi0_q_to_p, Omega_q_T)
    Phi_tilde = np.einsum("...ik,...kl,...lj->...ij", Omega_q, Phi0_p_to_q, Omega_p_T)

    return Phi, Phi_tilde


def construct_gauge_covariant_morphism(
    Phi0_field: np.ndarray,          # (H, W, K_p, K_q)
    phi_p_field: np.ndarray,         # (H, W, d)
    phi_q_field: np.ndarray,         # (H, W, d)
    rho_p_func,                      # φ → ρ_p(exp(φ))  (batched)
    rho_q_func                       # φ → ρ_q(exp(φ))  (batched)
) -> np.ndarray:
    """
    Construct gauge-covariant Φ(x) = ρ_p(exp(φ_p)) · Φ₀(x) · ρ_q(exp(φ_q))⁻¹

    Args:
        Phi0_field  : (H, W, K_p, K_q), base morphism field in global frame
        phi_p_field : (H, W, d), Lie algebra coords for model bundle
        phi_q_field : (H, W, d), Lie algebra coords for belief bundle
        rho_p_func  : φ → ρ_p(exp(φ)) for model fibers (batched)
        rho_q_func  : φ → ρ_q(exp(φ)) for belief fibers (batched)

    Returns:
        Phi_field : (H, W, K_p, K_q), gauge-covariant morphism
    """
    H, W = Phi0_field.shape[:2]
    K_p, K_q = Phi0_field.shape[-2:]

    N = H * W
    phi_p_flat = phi_p_field.reshape(N, -1)
    phi_q_flat = phi_q_field.reshape(N, -1)
    Phi0_flat  = Phi0_field.reshape(N, K_p, K_q)

    rho_p = rho_p_func(phi_p_flat)        # (N, K_p, K_p)
    rho_q = rho_q_func(phi_q_flat)        # (N, K_q, K_q)
    rho_q_inv = np.linalg.inv(rho_q)

    # Φ = ρ_p · Φ₀ · ρ_q⁻¹
    tmp = np.einsum("nij,njk->nik", rho_p, Phi0_flat)       # ρ_p @ Φ₀
    Phi_flat = np.einsum("nij,njk->nik", tmp, rho_q_inv)    # ... @ ρ_q⁻¹

    return Phi_flat.reshape(H, W, K_p, K_q)



def to_natural_params(mu, sigma, eps=1e-6):
    """
    Convert (μ, Σ) to natural parameters (θ₁, θ₂) for multivariate Gaussians.
    θ₁ = Σ⁻¹ μ, θ₂ = -½ Σ⁻¹
    """
    sigma = sanitize_sigma(sigma, eps=eps)
    inv_sigma = safe_inv(sigma, eps=eps)
    theta1 = np.einsum("...ij,...j->...i", inv_sigma, mu)
    theta2 = -0.5 * inv_sigma
    return theta1, theta2


def from_natural_params(theta1, theta2, eps=1e-6):
    """
    Convert natural parameters (θ₁, θ₂) back to (μ, Σ), ensuring stability.
    """
    inv_sigma = -2.0 * theta2
    inv_sigma = 0.5 * (inv_sigma + np.swapaxes(inv_sigma, -1, -2))  # symmetrize
    inv_sigma = sanitize_sigma(inv_sigma, eps=eps)
    sigma = safe_inv(inv_sigma, eps=eps)
    mu = np.einsum("...ij,...j->...i", sigma, theta1)

    try:
        if config.debug_sanitize_sigma:
            logdet = safe_logdet(sigma)
            #print(f"[DEBUG: θ→(μ,Σ)] log|Σ| stats — min: {logdet.min():.2f}, mean: {logdet.mean():.2f}, max: {logdet.max():.2f}")
    except NameError:
        pass

    return mu, sigma




fallback_counter = defaultdict(int)

def safe_batch_apply_morphism_nat(mu, sigma, Phi, eps=1e-8, fallback_value=1e-3):
    """
    Project (mu, Sigma) through a bundle morphism Φ using **natural parameters**.
    Adds fallback if output covariance is not SPD or produces NaNs.

    Args:
        mu:    (H, W, K_src)
        sigma: (H, W, K_src, K_src)
        Phi:   (H, W, K_tgt, K_src)
        eps:   stabilizer for inversion/logs
        fallback_value: default variance to use if output is invalid

    Returns:
        mu_out:    (H, W, K_tgt)
        sigma_out: (H, W, K_tgt, K_tgt)
    """
    theta1, theta2 = to_natural_params(mu, sigma, eps)
    theta1_out = np.einsum("...ij,...j->...i", Phi, theta1)
    theta2_out = np.einsum("...ij,...jk,...lk->...il", Phi, theta2, Phi)
    theta2_out = 0.5 * (theta2_out + theta2_out.transpose(0, 1, 3, 2))  # symmetrize

    mu_out, sigma_out = from_natural_params(theta1_out, theta2_out, eps)

    # Fallback if invalid
    H, W, K = mu_out.shape
    fallback_sigma = fallback_value * np.eye(K, dtype=sigma_out.dtype)

    for i in range(H):
        for j in range(W):
            if not np.all(np.isfinite(sigma_out[i, j])) or np.linalg.cond(sigma_out[i, j]) > 1e8:
                sigma_out[i, j] = fallback_sigma
                mu_out[i, j] = 0.0  # neutral fallback mean

    return mu_out, sigma_out



def safe_batch_apply_morphism(mu, sigma, Phi, eps=1e-8, max_cond=1e6):
    """
    Apply a bundle morphism Φ: K_src → K_tgt to mean and covariance,
    with numerical fallback for ill-conditioned output.

    Args:
        mu       : (..., K_src)
        sigma    : (..., K_src, K_src)
        Phi      : (..., K_tgt, K_src)
        eps      : float, SPD stabilizer for output
        max_cond : float, condition number threshold for fallback

    Returns:
        mu_tgt    : (..., K_tgt)
        sigma_tgt : (..., K_tgt, K_tgt)
    """
    if Phi.shape[-1] != mu.shape[-1]:
        raise ValueError(
            f"[safe_batch_apply_morphism] Mismatch: Φ maps K_src={Phi.shape[-1]} → K_tgt={Phi.shape[-2]}, "
            f"but mu has shape {mu.shape}"
        )

    try:
        mu_tgt = np.einsum("...ij,...j->...i", Phi, mu)
        sigma_tgt = np.einsum("...ik,...kl,...jl->...ij", Phi, sigma, Phi)
    except Exception as e:
        raise RuntimeError(
            f"[safe_batch_apply_morphism] einsum failed:\n"
            f"mu: {mu.shape}, sigma: {sigma.shape}, Phi: {Phi.shape}\n{str(e)}"
        )

    # Symmetrize and stabilize
    sigma_tgt = 0.5 * (sigma_tgt + np.swapaxes(sigma_tgt, -1, -2))
    eye = np.eye(Phi.shape[-2], dtype=sigma.dtype)
    while eye.ndim < sigma_tgt.ndim:
        eye = eye[np.newaxis, ...]
    sigma_tgt += eps * eye

    # Check condition number and fallback
    fallback_triggered = False
    try:
        batch_cond = np.linalg.cond(sigma_tgt.reshape(-1, sigma_tgt.shape[-2], sigma_tgt.shape[-1]))
        if not np.all(np.isfinite(batch_cond)) or np.any(batch_cond > max_cond):
            fallback_triggered = True
    except Exception:
        fallback_triggered = True

    if fallback_triggered:
        fallback_val = getattr(config, "sanitize_fallback_value", 1e-3)
        K = Phi.shape[-2]
        fallback_sigma = fallback_val * np.eye(K, dtype=sigma.dtype)
        shape = sigma_tgt.shape[:-2] + fallback_sigma.shape
        sigma_tgt = np.broadcast_to(fallback_sigma, shape)

        if "fallback_counter" in globals():
            fallback_counter["safe_batch_apply_morphism"] += 1

    return mu_tgt, sigma_tgt

def compute_morphism_covariance_term(sigma_i, Phi):
    """
    Compute the term Σ_p Φ̃^T + Φ̃ Σ_p for use in the gradient calculation.
    
    Args:
        sigma_i    : Covariance matrix (H, W, K_p, K_p) for models or (H, W, K_q, K_q) for beliefs
        Phi        : Bundle morphism (P → Q), shape (H, W, K_q, K_p)
    
    Returns:
        result     : The result of Σ_p Φ̃^T + Φ̃ Σ_p, shape (H, W, K_q, K_q)
    """
    # Debugging print statements with context
    print(f"Model Covariance (sigma_p) shape: {sigma_i.shape}")
    print(f"Phi shape: {Phi.shape}")

    # Perform the matrix multiplication for Σ_p Φ̃^T + Φ̃ Σ_p
    # First term: Σ_p Φ̃^T
    term_1 = np.einsum("...ij,...jl->...il", sigma_i, Phi.transpose(-1, -2))  # Σ_p Φ̃^T

    # Second term: Φ̃ Σ_p
    term_2 = np.einsum("...ij,...jl->...il", Phi, sigma_i)    # Φ̃ Σ_p

    # Return the sum of both terms
    return term_1 + term_2




#======================================================================
#
#                    Initialization
#
#======================================================================

def identity_morphism(agent_i, agent_j):
    """
    Returns Φ = Id for all spatial points.
    """
    H, W, K = agent_i.mu_q_field.shape  # works for both q and p
    return np.broadcast_to(np.eye(K, dtype=np.float32), (H, W, K, K))

def get_morphism_fn(name, generators_q=None, generators_p=None):
    """
    Returns a morphism function: (agent_i, agent_j) → Φ_{ij}

    Args:
        name         : str, e.g., "identity", "gauge_covariant"
        generators_q : (3, K_q, K_q) array for belief bundle (domain)
        generators_p : (3, K_p, K_p) array for model bundle (codomain)

    Returns:
        function(agent_i, agent_j) → (H, W, K_p, K_q)
    """
    name = name.lower()

    if name == "identity":
        return identity_morphism

    elif name == "gauge_covariant":
        if generators_q is None or generators_p is None:
            raise ValueError("[get_morphism_fn] 'gauge_covariant' requires both generators_q and generators_p")
        rho_q_func = RhoFunction(generators_q)
        rho_p_func = RhoFunction(generators_p)
        return make_morphism_fn(rho_q_func, rho_p_func)

    else:
        raise ValueError(f"[get_morphism_fn] Unknown morphism type: '{name}'")


def assign_default_morphisms(agent, K_q, K_p):
    shape = agent.grid_shape
    mask  = agent.mask[..., None, None]  # (H, W, 1, 1)

    Φ       = np.zeros((*shape, K_p, K_q), dtype=np.float32).copy()
    Φ_tilde = np.zeros((*shape, K_q, K_p), dtype=np.float32).copy()


    min_dim = min(K_q, K_p)

    for i in range(min_dim):
        Φ[..., i, i]       = mask[..., 0, 0]
        Φ_tilde[..., i, i] = mask[..., 0, 0]

    agent.bundle_morphism_phi       = Φ
    agent.bundle_morphism_phi_tilde = Φ_tilde


def generate_smooth_morphism_field(
    H, W,
    K_src, K_tgt,
    sigma=config.gaussian_blur_range_morphism,
    low_rank=None,
    seed=None,
    normalize=False,
    mask=None,
):
    """
    Generate a smooth spatial field of K_tgt × K_src morphisms.

    Args:
        H, W       : spatial domain
        K_src      : input dimension (e.g. q)
        K_tgt      : output dimension (e.g. p)
        sigma      : Gaussian blur σ (scalar or tuple)
        low_rank   : optional int ≤ min(K_src, K_tgt) for low-rank morphism
        seed       : optional random seed
        normalize  : if True, normalize each matrix to unit Frobenius norm
        mask       : (H, W) optional mask to apply (multiply per point)

    Returns:
        morphism_field : (H, W, K_tgt, K_src)
    """
    eps = 1e-8
    rng = np.random.default_rng(seed)
    rank = low_rank if low_rank is not None else min(K_src, K_tgt)

    field = np.zeros((H, W, K_tgt, K_src), dtype=np.float32)

    for r in range(rank):
        basis = rng.standard_normal((K_tgt, K_src)).astype(np.float32)
        coeff = rng.standard_normal((H, W)).astype(np.float32)
        coeff = gaussian_filter(coeff, sigma=sigma, mode="wrap")
        field += coeff[..., None, None] * basis[None, None, :, :]

    if normalize:
        norm = np.linalg.norm(field, axis=(-2, -1), keepdims=True)
        norm_safe = np.where(norm > eps, norm, eps)
        field = field / norm_safe

    if mask is not None:
        field *= mask[..., None, None]

    return field

def generate_identity_morphism_field(H, W, K, noise_scale=0.01, seed=None):
    """
    Returns (H, W, K, K) identity + smooth noise morphism field.
    """
    rng = np.random.default_rng(seed)
    field = np.tile(np.eye(K)[None, None, :, :], (H, W, 1, 1))

    noise = rng.standard_normal((H, W, K, K)) * noise_scale
    noise = gaussian_filter(noise, sigma=1.0, mode="wrap")
    return field + noise


def clip_operator_norm(field: np.ndarray, max_norm: float = 1.0, eps: float = 1e-8) -> np.ndarray:
    """
    Enforce operator norm ≤ max_norm for each Φ(x) in (H,W,Kp,Kq)
    """
    H, W, Kp, Kq = field.shape
    field_out = np.empty_like(field)
    for i in range(H):
        for j in range(W):
            Phi = field[i, j]
            u, s, vh = np.linalg.svd(Phi, full_matrices=False)
            s_clipped = np.clip(s, 0, max_norm)
            Phi_clipped = (u @ np.diag(s_clipped) @ vh).astype(field.dtype)
            field_out[i, j] = Phi_clipped
    return field_out

from scipy.linalg import expm

def generate_so3_morphism_field(H, W, noise_scale=0.01, seed=None):
    """
    Returns (H, W, 3, 3) field of SO(3) matrices near identity.
    """
    rng = np.random.default_rng(seed)
    field = np.zeros((H, W, 3, 3))
    for i in range(H):
        for j in range(W):
            # Small random skew-symmetric matrix
            A = rng.normal(0, noise_scale, size=(3, 3))
            A = A - A.T
            field[i, j] = expm(A)  # exp: so(3) → SO(3)
    return field

def initialize_morphism_pair( 
    domain_size: Tuple[int, int],
    K_q: int,
    K_p: int,
    rng: np.random.Generator,
    morphism_type: str = "identity",
    mask: Optional[np.ndarray] = None,
    config_tag: str = "",
    phi_q_field: Optional[np.ndarray] = None,
    phi_p_field: Optional[np.ndarray] = None,
) -> Tuple[np.ndarray, np.ndarray]:
    """
    Initialize bundle morphisms Φ (q→p) and Φ̃ (p→q), optionally with
    full SO(3)-gauge covariance via:
        Φ(x) = ρ_p(exp(φ_p(x))) · Φ₀(x) · ρ_q(exp(φ_q(x)))⁻¹
    """
    from get_generators import get_generators
    from bundle_morphism_utils import (
        gauge_covariant_transform_phi,
        build_rho_from_generators,
        generate_smooth_morphism_field,
        clip_operator_norm
    )
    import config

    H, W = domain_size

    if morphism_type == "identity":
        if K_q != K_p:
            raise ValueError(f"Cannot use identity morphism with mismatched K_q={K_q} and K_p={K_p}")
        eye = np.eye(K_q, dtype=np.float32)
        phi_q_to_p = np.broadcast_to(eye, (H, W, K_q, K_q)).copy()
        phi_p_to_q = np.broadcast_to(eye, (H, W, K_q, K_q)).copy()
        if mask is not None:
            phi_q_to_p = np.where(mask[..., None, None], phi_q_to_p, 0.0)
            phi_p_to_q = np.where(mask[..., None, None], phi_p_to_q, 0.0)
        return phi_q_to_p, phi_p_to_q

    if morphism_type == "gauge_covariant":
        assert phi_q_field is not None and phi_p_field is not None, "φ_q and φ_p fields required"
        G_q = get_generators("so3", K_q)
        G_p = get_generators("so3", K_p)
        rho_q_func = build_rho_from_generators(G_q)
        rho_p_func = build_rho_from_generators(G_p)

        sigma = getattr(config, f"morphism_sigma{config_tag}", 1.5)
        rank  = getattr(config, f"morphism_rank{config_tag}", min(K_q, K_p))
        seed  = rng.integers(0, 1e9)

        # Generate base morphism fields (Φ₀)
        Phi_0_q_to_p = generate_smooth_morphism_field(
            H, W, K_src=K_q, K_tgt=K_p,
            sigma=sigma, low_rank=rank,
            normalize=False, mask=mask, seed=seed
        )
        Phi_0_p_to_q = generate_smooth_morphism_field(
            H, W, K_src=K_p, K_tgt=K_q,
            sigma=sigma, low_rank=rank,
            normalize=False, mask=mask, seed=seed + 1
        )

        # Apply gauge covariance: Φ(x) = ρ_p · Φ₀ · ρ_q⁻¹
        phi_q_to_p = gauge_covariant_transform_phi(
            phi_p_field, phi_q_field, Phi_0_q_to_p,
            rho_q_func, rho_p_func
        )
        phi_p_to_q = gauge_covariant_transform_phi(
            phi_q_field, phi_p_field, Phi_0_p_to_q,
            rho_p_func, rho_q_func
        )

        if mask is not None:
            phi_q_to_p *= mask[..., None, None]
            phi_p_to_q *= mask[..., None, None]

        return phi_q_to_p, phi_p_to_q

    # Else: non-covariant low-rank morphism
    sigma     = getattr(config, f"morphism_sigma{config_tag}", 1.5)
    rank      = getattr(config, f"morphism_rank{config_tag}", min(K_q, K_p))
    normalize = getattr(config, f"morphism_normalize{config_tag}", True)
    seed      = rng.integers(0, 1e9)

    phi_q_to_p = generate_smooth_morphism_field(
        H, W, K_src=K_q, K_tgt=K_p,
        sigma=sigma, low_rank=rank,
        normalize=False, mask=mask, seed=seed
    )
    phi_p_to_q = generate_smooth_morphism_field(
        H, W, K_src=K_p, K_tgt=K_q,
        sigma=sigma, low_rank=rank,
        normalize=False, mask=mask, seed=seed + 1
    )

    if normalize:
        phi_q_to_p = clip_operator_norm(phi_q_to_p, max_norm=1.0)
        phi_p_to_q = clip_operator_norm(phi_p_to_q, max_norm=1.0)

    return phi_q_to_p, phi_p_to_q




def initialize_full_rank_morphism(H, W, K_out, K_in, scale=1.0, eps=1e-5, seed=None):
    """
    Generate a full-rank, well-conditioned rectangular morphism field Φ ∈ ℝ^{H×W×K_out×K_in}.

    Ensures that:
    - Φ is random but normalized per row (or column) for stability.
    - Compatible with K_out ≠ K_in (non-square).
    """
    if seed is not None:
        rng = np.random.default_rng(seed)
    else:
        rng = np.random.default_rng()

    M = rng.normal(loc=0.0, scale=scale, size=(H, W, K_out, K_in)).astype(np.float32)

    # Normalize rows: for each (H, W, K_out) row vector over K_in
    norm = np.linalg.norm(M, axis=-1, keepdims=True) + eps
    M = M / norm

    return M


def scaled_rectangular_identity_safe(H, W, K_out, K_in, scale=1.0, noise_scale=0.01):
    """
    Generate a full-rank diagonal-dominant morphism with light noise to prevent
    rank deficiency. Useful for gauge-covariant initialization.

    Args:
        H, W        : spatial dimensions
        K_out, K_in : fiber dimensions (target, source)
        scale       : diagonal scaling
        noise_scale : relative scale of off-diagonal noise

    Returns:
        Φ : (H, W, K_out, K_in)
    """
    dtype = np.float32
    M = np.zeros((H, W, K_out, K_in), dtype=dtype)

    d = min(K_out, K_in)
    for i in range(d):
        M[..., i, i] = scale

    # Add tiny full-rank noise to all elements
    noise = np.random.normal(loc=0.0, scale=noise_scale * scale, size=M.shape).astype(dtype)
    M += noise

    return M

from scipy.linalg import expm
from scipy.linalg import expm

from get_generators import get_generators
from scipy.linalg import expm
import numpy as np

def gauge_covariant_transform_phi(
    phi_p_field: np.ndarray,     # (H, W, 3)
    phi_q_field: np.ndarray,     # (H, W, 3)
    Phi_field: np.ndarray,       # (H, W, K_p, K_q)
    group_name: str = "so3"
) -> np.ndarray:
    """
    Apply Φ ↦ e^{φ_p·G_p} · Φ · e^{-φ_q·G_q} using SO(3) generators.

    Args:
        phi_p_field : (H, W, 3) — Lie algebra field for p-bundle
        phi_q_field : (H, W, 3) — Lie algebra field for q-bundle
        Phi_field   : (H, W, K_p, K_q)
        group_name  : Lie group name for both bundles ("so3" or "sl2r")

    Returns:
        gauge-transformed Φ : (H, W, K_p, K_q)
    """
    H, W = Phi_field.shape[:2]
    K_p, K_q = Phi_field.shape[-2:]

    # Load generators from cache
    G_p = get_generators(group_name, K_p)  # shape (3, K_p, K_p)
    G_q = get_generators(group_name, K_q)  # shape (3, K_q, K_q)

    out = np.zeros_like(Phi_field)

    for i in range(H):
        for j in range(W):
            φp = phi_p_field[i, j]
            φq = phi_q_field[i, j]

            A_p = φp[0]*G_p[0] + φp[1]*G_p[1] + φp[2]*G_p[2]
            A_q = φq[0]*G_q[0] + φq[1]*G_q[1] + φq[2]*G_q[2]

            ρp = expm(A_p)
            ρq_inv = np.linalg.inv(expm(A_q))

            out[i, j] = ρp @ Phi_field[i, j] @ ρq_inv

    return out


def make_morphism_fn(rho_q_func, rho_p_func):
    """
    Returns a function that performs the gauge-covariant transformation:
        Φ(x) ↦ ρ_p(exp(φ_p(x))) · Φ₀(x) · ρ_q(exp(φ_q(x)))⁻¹

    This respects separate gauge fields for model and belief bundles.

    Args:
        rho_q_func : function mapping φ_q → ρ_q(exp(φ_q))
        rho_p_func : function mapping φ_p → ρ_p(exp(φ_p))

    Returns:
        morphism(agent_i, agent_j) → (H, W, K_p, K_q) transformed Φ
    """
    def morphism(agent_i, agent_j):
        phi_q_field = agent_j.phi           # φ_q: agent_j's gauge field on belief bundle
        phi_p_field = agent_i.phi_model     # φ_p: agent_i's gauge field on model bundle
        Phi0_field  = agent_j.bundle_morphism_q_to_p  # Φ₀(x): base morphism in global frame

        return gauge_covariant_transform_phi(
            phi_p_field, phi_q_field, Phi0_field,
            rho_q_func, rho_p_func
        )

    return morphism


