# -*- coding: utf-8 -*-
"""
Created on Sun Jul 13 13:06:16 2025

@author: chris and christine
"""
import sys
import numpy as np
import warnings
from collections import defaultdict

from joblib import Parallel, delayed
from numpy.linalg import LinAlgError  # ✅ Needed for exception handling

import config
from scipy.linalg import logm  # Only if safe_logm is used



# Global counters
fallback_counter = defaultdict(int)

#=======================================
#
#         Reporting/Logging
#
#======================================



import numpy as np
from numpy.linalg import LinAlgError
import config

import numpy as np



def safe_inv(Sigma, eps=1e-6, max_eig=1e6, debug=False):
    """
    Safely invert symmetric positive-definite matrix Σ.
    Uses eigendecomposition, clips small/large eigenvalues,
    and reconstructs a stable inverse.

    Args:
        Sigma    : (..., K, K) batch of SPD matrices
        eps      : minimum eigenvalue (clipped to avoid explosion)
        max_eig  : maximum eigenvalue (clipped to avoid vanishing inverses)
        debug    : if True, print diagnostic stats

    Returns:
        Sigma_inv : (..., K, K) batch of inverted matrices
    """
    try:
        eigvals, eigvecs = np.linalg.eigh(Sigma)
        eigvals_clipped = np.clip(eigvals, eps, max_eig)

        if debug:
            print(f"[safe_inv] eig min: {eigvals.min():.2e}, max: {eigvals.max():.2e}")
            print(f"[safe_inv] eig clipped min: {eigvals_clipped.min():.2e}")

        inv_eigvals = 1.0 / eigvals_clipped
        Sigma_inv = np.einsum("...ik,...k,...jk->...ij", eigvecs, inv_eigvals, eigvecs)

        # Symmetrize result
        Sigma_inv = 0.5 * (Sigma_inv + np.swapaxes(Sigma_inv, -1, -2))
        return Sigma_inv

    except LinAlgError:
        if debug:
            print("[safe_inv] LinAlgError — fallback to scaled identity")
        K = Sigma.shape[-1]
        fallback = getattr(config, "sanitize_fallback_value", 1e2)
        return np.eye(K, dtype=Sigma.dtype) * fallback

def sanitize_eta2(eta2, eps=None, floor=None, debug=False):
    """
    Symmetrize and ensure η₂ is negative semi-definite (NSD) by clipping eigenvalues,
    normalizing negative trace, and bounding norm.

    Returns:
        eta2_sanitized : (..., K, K) safe NSD matrix
    """
    import numpy as np
    import config
    from numpy.linalg import norm

    # ───── Load from config if not provided ─────
    if eps is None:
        eps = getattr(config, "eta2_min_eigval", -1e-1)
    if floor is None:
        floor = getattr(config, "eta2_floor", -0.5)
    target_trace = getattr(config, "eta2_target_trace", -eta2.shape[-1])
    max_norm = getattr(config, "eta2_max_norm", None)

    # ───── 1. Symmetrize ─────
    eta2_sym = 0.5 * (eta2 + np.swapaxes(eta2, -1, -2))

    # ───── 2. Eigendecomposition ─────
    try:
        eigvals, eigvecs = np.linalg.eigh(eta2_sym)
    except np.linalg.LinAlgError:
        if debug:
            print("[sanitize_eta2] Eigendecomposition failed — returning identity.")
        shape = eta2.shape
        I = np.eye(shape[-1], dtype=eta2.dtype)
        return np.broadcast_to(I, shape)

    # ───── 3. Clip eigenvalues from above to enforce NSD ─────
    upper_clip = min(floor, eps)  # should be negative
    eigvals_clipped = np.clip(eigvals, None, upper_clip)  # upper bound only

    # ───── 4. Normalize to match target negative trace ─────
    trace_clipped = np.sum(eigvals_clipped, axis=-1, keepdims=True)
    trace_safe = np.where(np.abs(trace_clipped) < 1e-8, 1e-8, trace_clipped)
    scale = target_trace / trace_safe
    eigvals_scaled = eigvals_clipped * scale

    # ───── 5. Replace NaNs or Infs ─────
    eigvals_scaled = np.nan_to_num(eigvals_scaled, nan=eps, posinf=eps, neginf=eps)

    # ───── 6. Reconstruct η₂ from eigendecomposition ─────
    eta2_sanitized = np.matmul(eigvecs * eigvals_scaled[..., None, :],
                               np.swapaxes(eigvecs, -1, -2))

    # ───── 7. Symmetrize again for safety ─────
    eta2_sanitized = 0.5 * (eta2_sanitized + np.swapaxes(eta2_sanitized, -1, -2))

    # ───── 8. Clip matrix norm if needed ─────
    if max_norm is not None:
        norm_val = norm(eta2_sanitized, axis=(-2, -1), keepdims=True)
        norm_safe = np.maximum(norm_val, 1e-8)
        scale = np.minimum(1.0, max_norm / norm_safe)
        eta2_sanitized *= scale

    # ───── 9. Debug output ─────
    min_eig_before = eigvals.min()
    trace_after = np.sum(np.diagonal(eta2_sanitized, axis1=-2, axis2=-1), axis=-1)
    max_eig_scaled = eigvals_scaled.max()
    #print(f"[sanitize_eta2] min eig: {min_eig_before:.2e}, trace after: {trace_after.mean():.2e}, max eig (scaled): {max_eig_scaled:.2e}")
    if np.isnan(eta2_sanitized).any() or np.isinf(eta2_sanitized).any():
        print("[sanitize_eta2] NaNs or Infs detected in sanitized η₂.")

    return eta2_sanitized


def sanitize_eta2old(eta2, eps=None, floor=None, debug=False):
    """
    Symmetrize and ensure η₂ is negative semi-definite (NSD) by clipping eigenvalues and normalizing trace.

    Args:
        eta2  : (..., K, K) matrix (batchable)
        eps   : maximum eigenvalue after clipping (default = config.eta2_min_eigval)
                should be negative (e.g., eps = -0.1)
        floor : hard upper bound on raw eigenvalues (applied before eps clip)
        debug : whether to print diagnostics

    Returns:
        eta2_sanitized : (..., K, K) safe NSD matrix with normalized negative trace
    """
    # ───── Load from config if not provided ─────
    if eps is None:
        eps = getattr(config, "eta2_min_eigval", -1e-1)
    if floor is None:
        floor = getattr(config, "eta2_floor", -0.5)
    target_trace = getattr(config, "eta2_target_trace", -eta2.shape[-1])
    max_norm = getattr(config, "eta2_max_norm", None)

    # ───── 1. Symmetrize ─────
    eta2_sym = 0.5 * (eta2 + np.swapaxes(eta2, -1, -2))

    # ───── 2. Eigendecomposition ─────
    try:
        eigvals, eigvecs = np.linalg.eigh(eta2_sym)
    except np.linalg.LinAlgError:
        if debug:
            print("[sanitize_eta2] Eigendecomposition failed — returning identity.")
        shape = eta2.shape
        I = np.eye(shape[-1], dtype=eta2.dtype)
        return np.broadcast_to(I, shape)

    # ───── 3. Clip eigenvalues from above for NSD ─────
    upper_clip = min(floor, eps)  # both should be negative
    eigvals_clipped = np.clip(eigvals, None, upper_clip)

    # ───── 4. Rescale to target negative trace ─────
    trace_clipped = np.sum(eigvals_clipped, axis=-1, keepdims=True)
    trace_clipped = np.where(np.abs(trace_clipped) < 1e-8, 1e-8, trace_clipped)
    
    
    eigvals_scaled = eigvals_clipped * (target_trace / trace_clipped)
    

    # ───── 5. Replace NaNs or Infs ─────
    eigvals_scaled = np.nan_to_num(eigvals_scaled, nan=eps, posinf=target_trace, neginf=eps)

    # ───── 6. Reconstruct matrix: V diag(λ) Vᵀ ─────
    eta2_sanitized = np.matmul(eigvecs * eigvals_scaled[..., None, :],
                               np.swapaxes(eigvecs, -1, -2))

    # ───── 7. Symmetrize again for safety ─────
    eta2_sanitized = 0.5 * (eta2_sanitized + np.swapaxes(eta2_sanitized, -1, -2))

    # ───── 8. Clip norm if needed ─────
    if max_norm is not None:
        norm = np.linalg.norm(eta2_sanitized, axis=(-2, -1), keepdims=True)
        norm_safe = np.maximum(norm, 1e-8)
        scale = np.minimum(1.0, max_norm / norm_safe)
        eta2_sanitized *= scale

    # ───── 9. Debug ─────
    min_eig_before = eigvals.min()
    max_eig_after = eigvals_clipped.max()
    print(f"[sanitize_eta2] eps={eps:.2e}, floor={floor:.2e}--> raw min eig: {min_eig_before:.3e}, clipped max eig: {max_eig_after:.3e}")
    if np.isnan(eta2_sanitized).any() or np.isinf(eta2_sanitized).any():
        print("[sanitize_eta2] NaNs or Infs detected in sanitized η₂.")

    return eta2_sanitized

def sanitize_eta2smooth(eta2, eps=None, floor=None, debug=False):
    """
    Soft, localized sanitization of η₂ matrices: only sanitize unstable regions and
    blend original + sanitized fields with smooth weighting.

    Args:
        eta2  : (..., K, K) matrix (batchable)
        eps   : max eigenvalue for NSD (default = config.eta2_min_eigval)
        floor : hard eigenvalue upper bound (default = config.eta2_floor)
        debug : print diagnostics

    Returns:
        eta2_out : (..., K, K) smooth, safe NSD matrix
    """
    import numpy as np
    import config
    from numpy.linalg import eigh

    # ───── Config Defaults ─────
    if eps is None:
        eps = getattr(config, "eta2_min_eigval", -1e-1)
    if floor is None:
        floor = getattr(config, "eta2_floor", -0.5)
    target_trace = getattr(config, "eta2_target_trace", -eta2.shape[-1])
    max_norm = getattr(config, "eta2_max_norm", None)
    alpha_smooth = getattr(config, "eta2_smooth_blend", 0.1)  # e.g., 0.1 = 10% blend

    # ───── 1. Symmetrize ─────
    eta2_sym = 0.5 * (eta2 + np.swapaxes(eta2, -1, -2))

    # ───── 2. Eigendecomposition ─────
    try:
        eigvals, eigvecs = np.linalg.eigh(eta2_sym)
    except np.linalg.LinAlgError:
        if debug:
            print("[sanitize_eta2_smooth] Eigendecomposition failed — fallback to identity")
        shape = eta2.shape
        I = np.eye(shape[-1], dtype=eta2.dtype)
        return np.broadcast_to(I, shape)

    # ───── 3. Determine unstable entries ─────
    unstable = np.isnan(eigvals) | np.isinf(eigvals) | (eigvals > eps)
    needs_sanitize = unstable.any(axis=-1)  # (...,) boolean mask

    if debug:
        n_total = np.prod(needs_sanitize.shape)
        n_bad = np.count_nonzero(needs_sanitize)
        print(f"[sanitize_eta2_smooth] {n_bad}/{n_total} matrices flagged for correction")

    # ───── 4. Apply sanitization only where needed ─────
    eigvals_clipped = np.where(unstable, np.clip(eigvals, None, min(floor, eps)), eigvals)

    trace_clipped = np.sum(eigvals_clipped, axis=-1, keepdims=True)
    trace_clipped = np.where(np.abs(trace_clipped) < 1e-8, 1e-8, trace_clipped)
    eigvals_scaled = eigvals_clipped * (target_trace / trace_clipped)

    # Reconstruct sanitized η₂
    eta2_fixed = np.matmul(eigvecs * eigvals_scaled[..., None, :],
                           np.swapaxes(eigvecs, -1, -2))
    eta2_fixed = 0.5 * (eta2_fixed + np.swapaxes(eta2_fixed, -1, -2))

    # ───── 5. Blend original with sanitized using soft weighting ─────
    blend_mask = needs_sanitize.astype(eta2.dtype)[..., None, None]  # (...,1,1)
    eta2_out = (1 - alpha_smooth) * eta2_sym + alpha_smooth * eta2_fixed
    eta2_out = blend_mask * eta2_out + (1 - blend_mask) * eta2_sym

    # ───── 6. Clip norm if needed ─────
    if max_norm is not None:
        norm = np.linalg.norm(eta2_out, axis=(-2, -1), keepdims=True)
        norm_safe = np.maximum(norm, 1e-8)
        scale = np.minimum(1.0, max_norm / norm_safe)
        eta2_out *= scale

    # ───── 7. Final symmetrize and return ─────
    eta2_out = 0.5 * (eta2_out + np.swapaxes(eta2_out, -1, -2))
    # Before returning
    eigvals = np.linalg.eigvalsh(eta2_out)
    min_eig = eigvals.min(axis=-1)
    trace = np.trace(eta2_out, axis1=-2, axis2=-1)
    nan_count = np.isnan(eta2_out).sum()
   #print(f"[smooth_eta2] min_eig: {min_eig.min():.2e}, trace: {trace.mean():.2e}, NaNs: {nan_count}")
    return eta2_out


def soft_clip_phi_norm(phi: np.ndarray, max_norm: float = np.pi, eps: float = 1e-8) -> np.ndarray:
    """
    Smoothly compress φ ∈ ℝ³ to have norm ≤ max_norm.

    Args:
        phi      : (..., d) Lie algebra field (e.g. d=3 for SO(3))
        max_norm : maximum allowed norm (e.g., π or 2π)
        eps      : small stabilizer to avoid division by zero

    Returns:
        φ_clipped : (..., d) compressed φ with ‖φ‖ ≤ max_norm
    """
    norm = np.linalg.norm(phi, axis=-1, keepdims=True)  # (..., 1)
    scale = max_norm / (norm + eps)
    scale = np.minimum(1.0, scale)
    return phi * scale


def safe_transport_eta2(eta2_src, Omega, eps=1e-8, clip_trace=10.0):
    """
    Transport η₂ via η₂^t = Ω η₂ Ωᵀ, then symmetrize and sanitize.

    Args:
        eta2_src   : (..., K, K) source η₂ (should be neg-definite)
        Omega      : (..., K, K) gauge transport operator
        eps        : regularization constant for sanitize_eta2
        clip_trace : max allowed |trace| after transport (optional)

    Returns:
        eta2_t     : (..., K, K) safely transported η₂
    """
    assert eta2_src.shape[-2:] == Omega.shape[-2:], "Mismatched transport dimensions"

    # Transport: η₂^t = Ω η₂ Ωᵀ
    Omega_T = np.swapaxes(Omega, -1, -2)
    eta2_t = np.einsum("...ik,...kl,...lj->...ij", Omega, eta2_src, Omega_T)

    # Symmetrize to fix numeric drift
    eta2_t = 0.5 * (eta2_t + np.swapaxes(eta2_t, -1, -2))

    # Optional trace clipping
    tr = np.trace(eta2_t, axis1=-2, axis2=-1)[..., None, None]
    if clip_trace is not None:
        scale = np.clip(clip_trace / (np.abs(tr) + eps), 0.0, 1.0)
        eta2_t *= scale

    # Sanitize (preserve neg-definite convention)
    eta2_t = sanitize_eta2(eta2_t, eps=eps)

    return eta2_t



def log_fallback(tag: str, msg: str, count_key: str = None, error: bool = False):
    """
    Standardized fallback logger.

    Args:
        tag       : str — context tag (e.g. 'safe_inv', 'logm', etc.)
        msg       : str — fallback message
        count_key : str — key for fallback_counter increment
        error     : bool — whether to raise RuntimeError (if fail_on_fallback)

    Behavior:
        - Increments fallback counter
        - Warns or raises
        - Flushes stdout
    """
    full_msg = f"[{tag}] {msg}"

    if count_key:
        fallback_counter[count_key] += 1
        full_msg = f"[{tag}] Fallback #{fallback_counter[count_key]}: {msg}"

    if getattr(config, "fail_on_fallback", False) or error:
        raise RuntimeError(full_msg)
    else:
        warnings.warn(full_msg, RuntimeWarning)
        sys.stdout.flush()


def reset_fallback_counters():
    """Call this at the start of each simulation/run."""
    fallback_counter.clear()

def report_and_maybe_fail():
    """Inspect counters against config thresholds."""
    invs = fallback_counter.get("safe_inv", 0)
    logs = fallback_counter.get("safe_logdet", 0)
    if invs or logs:
        msg = (
            f"[Fallback Summary] safe_inv: {invs}, safe_logdet: {logs}"
            f"{', raising error' if config.fail_on_fallback else ''}"
        )
        # Always log
        print(msg)
    # Fail if configured
    if config.fail_on_fallback:
        if invs > 0 or logs > 0:
            raise RuntimeError("Numerical fallback occurred under strict mode.")
    # Or threshold-based
    if invs > config.max_safe_inv_fallbacks:
        raise RuntimeError(f"Exceeded max_safe_inv_fallbacks ({invs})")
    if logs > config.max_safe_logdet_fallbacks:
        raise RuntimeError(f"Exceeded max_safe_logdet_fallbacks ({logs})")

def report_fallback_summary():
    print("\n──── Fallback Summary ────")
    for key, count in fallback_counter.items():
        print(f"{key:<25} → {count} fallback(s)")
    print("──────────────────────────\n")


#===============================================
#
#        Checks 
#
#===============================================

def check_shape_consistency(mu_q, sigma_q, mu_p, sigma_p, Phi, Phi_tilde):
    assert mu_q.shape[:-1] == sigma_q.shape[:-2], f"Shape mismatch: mu_q {mu_q.shape} vs. sigma_q {sigma_q.shape}"
    assert mu_p.shape[:-1] == sigma_p.shape[:-2], f"Shape mismatch: mu_p {mu_p.shape} vs. sigma_p {sigma_p.shape}"
    assert Phi.shape[-1] == mu_q.shape[-1], f"Shape mismatch: Phi {Phi.shape} vs. mu_q {mu_q.shape}"
    assert Phi_tilde.shape[-1] == mu_p.shape[-1], f"Shape mismatch: Phi_tilde {Phi_tilde.shape} vs. mu_p {mu_p.shape}"


def check_spd_field(field: np.ndarray, tol=1e-8) -> bool:
    """
    Verifies whether a full field (H, W, K, K) is SPD everywhere.
    Returns True if all matrices pass, False otherwise.
    """
    H, W, K, _ = field.shape
    
    for i in range(H):
        for j in range(W):
            if not is_spd_matrix(field[i, j], tol=tol):
                return False
    return True


def is_spd_matrix(A: np.ndarray, tol=1e-8) -> bool:
    """
    Check whether a matrix A is symmetric positive definite (SPD).
    """
    if not np.allclose(A, A.T, atol=tol):
        return False
    try:
        np.linalg.cholesky(A)
        return True
    except LinAlgError:
        return False
    
def condition_check_and_fallback(sigma, max_cond=1e6):
    """
    Checks condition number of matrix and falls back to scaled identity if ill-conditioned.

    Args:
        sigma   : (K, K) SPD matrix to validate
        max_cond: float, maximum allowed condition number before fallback

    Returns:
        (K, K) ndarray — safe matrix (original or fallback)
    """
    assert sigma.shape[-2] == sigma.shape[-1], "[condition_check] Matrix must be square"
    K = sigma.shape[-1]

    try:
        cond = np.linalg.cond(sigma)
        if not np.isfinite(cond) or cond > max_cond:
            raise LinAlgError(f"Condition number {cond:.2e} exceeds max_cond {max_cond}")
        return sigma

    except LinAlgError as e:
        log_fallback(
            tag="condition_check",
            msg=f"{str(e)} → using {config.sanitize_fallback_value} · I",
            count_key="condition_check"
        )
        return np.eye(K) * config.sanitize_fallback_value



   
        
#====================================================
#
#                 Safety Ops
#
#=====================================================

def safe_omega_inv(M):
    """
    Safely compute the inverse of Omega with condition check and fallback.
    Returns the inverse matrix or a regularized identity matrix if the inversion fails.
    """
    try:
        # Ensure that Omega has the correct shape before inversion
        return condition_check_and_fallback(M, max_cond=1e8)
    except RuntimeError as e:
        log_fallback("safe_omega_inv", str(e), count_key="omega_inv")
        # Ensure fallback identity matches the dimensionality of M
        return np.eye(M.shape[-1])  # This assumes M is square and invertible.

import numpy as np
from numpy.linalg import LinAlgError



import numpy as np
from joblib import Parallel, delayed
import config


def _sanitize_one_sigma(S, eps=1e-2, debug=False):
    """
    Ensure a single Σ is symmetric positive-definite (SPD).
    Returns: (Σ_sanitized, clipped_flag)
    """
    S = 0.5 * (S + S.T)

    if not np.all(np.isfinite(S)):
        if debug:
            print("[sanitize_sigma] NaNs or Infs detected — replacing with eps*I")
        return np.eye(S.shape[0]) * eps, True

    try:
        eigvals, eigvecs = np.linalg.eigh(S)
    except np.linalg.LinAlgError:
        if debug:
            print("[sanitize_sigma] Eigendecomposition failed — replacing with eps*I")
        return np.eye(S.shape[0]) * eps, True

    clipped = np.any(eigvals < eps)
    eigvals_clipped = np.clip(eigvals, eps, None)

    if clipped:
        S = eigvecs @ np.diag(eigvals_clipped) @ eigvecs.T
        S = 0.5 * (S + S.T)
        if debug:
            print(f"[sanitize_sigma] eigvals min={eigvals.min():.3e} → clipped to ≥ {eps:.3e}")

    return S, clipped


def sanitize_sigma(Sigma, eps=1e-2, debug=False, n_jobs=None, parallel_threshold=50):
    """
    Sanitize a batch of Σ matrices to ensure SPD structure.

    Args:
        Sigma: (..., K, K) ndarray
        eps: minimum eigenvalue threshold
        debug: print summary and per-matrix diagnostics if True
        n_jobs: number of parallel jobs (defaults to config.num_cores)
        parallel_threshold: minimum number of matrices to enable parallelism

    Returns:
        Sanitized (..., K, K) array of SPD matrices
    """
    shape = Sigma.shape
    flat_sigma = Sigma.reshape(-1, shape[-2], shape[-1])
    n_total = flat_sigma.shape[0]

    if n_jobs is None:
        n_jobs = getattr(config, "num_cores", 1)

    if n_total < parallel_threshold or n_jobs == 1:
        results = [_sanitize_one_sigma(S, eps, debug) for S in flat_sigma]
    else:
        with Parallel(n_jobs=n_jobs) as parallel:
            results = parallel(delayed(_sanitize_one_sigma)(S, eps, debug) for S in flat_sigma)

    Sigma_out, clipped_flags = zip(*results)
    if debug:
        n_clipped = sum(clipped_flags)
        if n_clipped > 0:
            print(f"[sanitize_sigma] Clipped {n_clipped}/{n_total} matrices to SPD (eps={eps:.2e})")
            
    return np.stack(Sigma_out, axis=0).astype(Sigma.dtype).reshape(shape)

import numpy as np
import warnings
from scipy.linalg import logm

import numpy as np
import io
import contextlib
from scipy.linalg import logm

def safe_log(x, eps: float = 1e-12):
    x = np.asarray(x)
    clipped = np.clip(x, eps, None).astype(x.dtype, copy=False)
    return np.log(clipped)


def safe_logm(M, fallback_value=None, imag_tol=1e-10, context="Ω"):
    """
    Suppress logm's internal stderr output and check imag part manually.
    """
    from numerical_utils import log_fallback  # Ensure this exists

    try:
        # Suppress logm's stderr output
        with io.StringIO() as buf, contextlib.redirect_stderr(buf):
            logM = logm(M, display=False)

        imag_norm = np.linalg.norm(np.imag(logM), ord="fro")
        if imag_norm > imag_tol:
            log_fallback("safe_logm", f"{context}: ‖Im(logm)‖={imag_norm:.2e} > tol={imag_tol}")
        return np.real_if_close(logM, tol=imag_tol)

    except Exception as e:
        log_fallback("safe_logm", f"{context}: logm failed ({e})", count_key="safe_logm")
        K = M.shape[-1]
        return fallback_value if fallback_value is not None else np.zeros((K, K), dtype=M.dtype)


from numpy.linalg import LinAlgError

def safe_logdet(Sigma, eps=1e-8, alpha=1e-2, clip_range=(-1e3, 1e3)):
    """
    Safe computation of logdet(Sigma) with fallback and stabilization.
    
    Args:
        Sigma : (..., K, K) positive semi-definite matrices
        eps   : float, small stabilizer for numerical safety
        alpha : float, trace-based fallback scaling
        clip_range : tuple (min, max) to clip extreme logdet values

    Returns:
        logdet : (...) ndarray
    """
    import numpy as np
    from numpy.linalg import slogdet, cholesky, LinAlgError

    K = Sigma.shape[-1]
    batch_shape = Sigma.shape[:-2]
    eye = eps * np.eye(K, dtype=Sigma.dtype)
    eye = eye.reshape((1,) * len(batch_shape) + (K, K))
    Sigma_reg = Sigma + eye

    try:
        # Attempt slogdet
        sign, ld = slogdet(Sigma_reg)
        bad = (sign <= 0) | ~np.isfinite(ld)
        if not np.any(bad):
            return np.clip(ld, *clip_range)
    except LinAlgError:
        bad = np.ones(batch_shape, dtype=bool)

    # Fallback: trace-based log surrogate
    trace = np.trace(Sigma, axis1=-2, axis2=-1)  # (...)
    surrogate = alpha * (trace / K + eps)
    fallback_ld = K * np.log(surrogate)

    # Optional: log failure
    log_fallback("safe_logdet", "fallback triggered", count_key="safe_logdet")

    # Return mixed result
    ld_final = np.where(bad, fallback_ld, ld)
    return np.clip(ld_final, *clip_range)


def clip_phi_field(phi, threshold=None, norm_type=2, verbose=False, label="φ"):
    """
    Clips φ values before applying exp(φ), to avoid numerical instability.

    Args:
        phi       : (..., d) Lie algebra field
        threshold : float or None — clip if norm > threshold
        norm_type : int or float — L2 (2), L1 (1), or ∞
        verbose   : bool — print clipping info
        label     : str — for diagnostics

    Returns:
        clipped φ
    """
    if threshold is None:
        return phi

    norm = np.linalg.norm(phi.ravel(), ord=norm_type)
    if norm > threshold:
        scale = threshold / (norm + 1e-12)
        if verbose:
            print(f"[Clipping {label}] norm phi = {norm:.2e} → {threshold} (scale = {scale:.2e})")
        return phi * scale
    return phi
    