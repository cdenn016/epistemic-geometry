# Standard library
import os

# Third-party libraries
import numpy as np
from scipy.ndimage import laplace
from joblib import Parallel, delayed
from numba import njit
from scipy.stats import linregress
from config import support_cutoff_eps

from generalized_omega import get_all_Omega_fields

from get_generators import get_generators  # ← add at top if not already

# Local project modules
import config
from get_generators import get_generators
from generalized_math_utils import (
    sanitize_q,
    masked_norm,
    laplacian_field,
    zipf_frequencies_from_q
)
from generalized_omega import (
    exp_lie_algebra_irrep,
    batch_apply_omega,
    repair_if_forgotten_batch,
    compute_field_strength,
    )
from powerlaw_suite import (
    zipf_slope,
    )

# Constants
_DEFAULT_CUTOFF = getattr(config, "support_cutoff_eps", 1e-3)
ZIPF_RMIN       = 3
ZIPF_RMAX_FRAC  = 0.5


def populate_pullbacks(agent):
    """
    Compute pullback gradient fields like pull_Delta if missing.
    """
    if agent.pull_Delta is None and np.any(agent.mask > config.support_cutoff_eps):
        # ∇μ field
        mu = agent.mu_q_field
        grad = np.stack([np.gradient(mu[..., k]) for k in range(mu.shape[-1])], axis=-1)  # (D, H, W, K)
        grad = np.moveaxis(grad, 0, -2)  # → (H, W, D, K)
        agent.pull_Delta = grad * agent.mask[..., None, None]

def compute_fisher_from_gaussian(mu, sigma, mask, log_eps=1e-8):
    """
    Approximate scalar Fisher information via ∇μᵀ Σ⁻¹ ∇μ
    """
    mu_grad = np.stack([np.gradient(mu[..., d]) for d in range(mu.shape[-1])], axis=-1)  # (D1, D2, ..., K, d)
    fisher = 0.0
    for i in range(mu.shape[0]):
        for j in range(mu.shape[1]):
            if not mask[i, j]: continue
            grad_mu = mu_grad[i, j]        # shape (K,)
            sigma_ij = sigma[i, j] + log_eps * np.eye(mu.shape[-1])
            fisher += grad_mu @ np.linalg.inv(sigma_ij) @ grad_mu.T
    return float(fisher)

def kl_divergence(mu_1, sigma_1, mu_2, sigma_2, log_eps=1e-6):
    mu1 = mu_1
    mu2 = mu_2
    sigma1 = sigma_1
    sigma2 = sigma_2

    K = mu1.shape[-1]
    eye = np.eye(K)

    # Promote diagonal to full if needed
    if sigma1.ndim == mu1.ndim:
        sigma1 = np.einsum('...k,ij->...ij', sigma1**2, eye)
    if sigma2.ndim == mu2.ndim:
        sigma2 = np.einsum('...k,ij->...ij', sigma2**2, eye)

    # Regularization
    sigma1 = sigma1 + log_eps * eye
    sigma2 = sigma2 + log_eps * eye

    sigma2_inv = np.linalg.inv(sigma2)
    diff = mu2 - mu1

    trace_term = np.einsum('...ij,...ji->...', sigma2_inv, sigma1)
    mahal_term = np.einsum('...i,...ij,...j->...', diff, sigma2_inv, diff)

    log_det_1 = np.linalg.slogdet(sigma1)[1]
    log_det_2 = np.linalg.slogdet(sigma2)[1]

    return 0.5 * (trace_term + mahal_term - K + log_det_2 - log_det_1)



def fisher_information_matrix(mu, sigma, eps=1e-8):
    """
    Fisher information matrix for multivariate Gaussian parameters (μ, Σ).

    Supports:
        - Diagonal sigma: shape (..., K)
        - Full covariance: shape (..., K, K)

    Returns:
        G: (..., 2K, 2K) Fisher information matrix for each spatial point
    """
    K = mu.shape[-1]

    # Handle diagonal σ
    if sigma.ndim == mu.ndim:
        sigma_diag = np.clip(sigma, eps, None)
        inv_var = 1.0 / (sigma_diag ** 2)

        # Fisher μ–μ block: diag(1/σ²)
        F_mu = np.einsum('...k,kl->...kl', inv_var, np.eye(K))

        # Fisher σ–σ block: diag(2/σ²)
        F_sigma = np.einsum('...k,kl->...kl', 2.0 * inv_var, np.eye(K))

    # Handle full Σ
    elif sigma.ndim == mu.ndim + 1:
        sigma_reg = sigma + eps * np.eye(K)
        sigma_inv = np.linalg.inv(sigma_reg)

        # Fisher μ–μ: Σ⁻¹
        F_mu = sigma_inv

        # Fisher Σ–Σ: Σ⁻¹ ⊗ Σ⁻¹ (flattened → later if needed)
        # Here we just use 2×Σ⁻¹ for trace-based approximation
        F_sigma = 2.0 * sigma_inv

    else:
        raise ValueError(f"Invalid sigma shape: {sigma.shape}")

    zeros = np.zeros_like(F_mu)

    # Assemble block matrix
    top    = np.concatenate([F_mu, zeros], axis=-1)      # (..., K, 2K)
    bottom = np.concatenate([zeros, F_sigma], axis=-1)   # (..., K, 2K)
    G = np.concatenate([top, bottom], axis=-2)           # (..., 2K, 2K)

    return G

def support_mask(mask, cutoff=_DEFAULT_CUTOFF):
    return (mask > cutoff)

def overlap_mask(mask_i, mask_j, cutoff=config.support_cutoff_eps):
    return support_mask(mask_i, cutoff) & support_mask(mask_j, cutoff)


def threshold_mask(mask: np.ndarray, cutoff: float = None) -> np.ndarray:
    """
    Threshold a continuous support mask into a boolean mask.
    """
    if cutoff is None:
        cutoff = getattr(config, "support_cutoff_eps", 1e-3)
    return mask > cutoff



def compute_coherence(phi: np.ndarray, mask: np.ndarray) -> float:
    mask_bool = threshold_mask(mask)
    if not np.any(mask_bool):
        return 0.0
    return np.abs(np.mean(np.exp(1j * phi[mask_bool])))


#USED OPNLY IN RUNSIM
def compute_phi_norm_field(agents, i, phi_field="phi"):
    phi = getattr(agents[i], phi_field)
    mask = threshold_mask(agents[i].mask)
    return np.linalg.norm(phi, axis=-1) * mask




def masked_norm(tensor, mask):
    """
    Computes the total norm of a tensor over the masked region.

    Args:
        tensor: (H, W, D) array
        mask: (H, W) boolean or float mask

    Returns:
        scalar: sum of norms over the mask
    """
    norm_field = np.linalg.norm(tensor, axis=-1)
    return np.sum(norm_field * mask)

#USED ONLY IN RUN_SIM AND LOG_ALL_METRICS
def compute_phi_norm(
    agents,
    phi_field="phi",
    mask_field="mask",
    support_cutoff_eps=1e-3,
):
    norms = []
    for agent in agents:
        phi  = getattr(agent, phi_field)
        mask = getattr(agent, mask_field) > support_cutoff_eps
        n    = np.count_nonzero(mask)
        if n > 0:
            norms.append(masked_norm(phi, mask) / n)
    return float(np.mean(norms)) if norms else 0.0



#USED IN LOG_ALL_METRICS
def compute_phi_laplacian_norm(
    agents,
    phi_field: str = "phi",
    mask_field: str = "mask",
    support_cutoff_eps: float | None = None,
    log_eps: float = 1e-8,
) -> float:
    """
    Compute the average per-agent RMS norm of the Laplacian of the φ field.
    1) Threshold mask by support_cutoff_eps.
    2) Compute componentwise Laplacian via scipy.ndimage.laplace.
    3) Compute masked_norm over support and normalize by support size.
    4) Return the mean over all agents.
    """
    if support_cutoff_eps is None:
        support_cutoff_eps = getattr(config, "support_cutoff_eps", 1e-3)


    norms = []
    for agent in agents:
        phi = getattr(agent, phi_field)
        mask = getattr(agent, mask_field) > support_cutoff_eps
        if not np.any(mask):
            continue

        # componentwise Laplacian
        lap_phi = np.stack([laplace(phi[..., d]) for d in range(phi.shape[-1])], axis=-1)
        # RMS norm over support
        val = masked_norm(lap_phi, mask) / (np.count_nonzero(mask) + log_eps)
        norms.append(val)

    return float(np.mean(norms)) if norms else 0.0


def compute_kl_field(agents, i):
    """
    Compute spatial field of D_KL(q || p) between Gaussians with full Σ.

    Returns:
        kl: (H, W) field of KL divergences (only computed where mask > ε)
    """
    from numpy.linalg import slogdet, inv

    μq = agents[i].mu_q_field     # shape (H, W, K)
    Σq = agents[i].sigma_q_field  # shape (H, W, K, K)
    μp = agents[i].mu_p_field
    Σp = agents[i].sigma_p_field
    mask = agents[i].mask

    eps = getattr(config, "eps", 1e-8)
    cutoff = getattr(config, "support_cutoff_eps", 1e-3)
    kl = np.zeros(mask.shape, dtype=μq.dtype)

    valid_indices = np.argwhere(mask > cutoff)

    for idx in valid_indices:
        idx = tuple(idx)
        μq_, μp_ = μq[idx], μp[idx]
        Σq_, Σp_ = Σq[idx], Σp[idx]

        Σp_reg = Σp_ + eps * np.eye(Σp_.shape[-1])
        Σp_inv = np.linalg.inv(Σp_reg)

        diff = μp_ - μq_
        trace_term = np.trace(Σp_inv @ Σq_)
        mahal_term = diff @ Σp_inv @ diff
        _, logdet_q = slogdet(Σq_ + eps * np.eye(Σq_.shape[-1]))
        _, logdet_p = slogdet(Σp_reg)

        kl[idx] = 0.5 * (trace_term + mahal_term - len(μq_) + (logdet_p - logdet_q))

    return kl


def compute_alignment_field(agents, i, eps=config.support_cutoff_eps, log_eps=config.log_eps) -> np.ndarray:
    """
    Compute average KL(q_i || Ω_ij q_j) field over all neighbors of agent i.
    KL is computed between multivariate Gaussians (μ, Σ), with gauge transport.
    """
    A = agents[i]
    mask_i = A.mask > eps
    if not mask_i.any() or not A.neighbors:
        return np.zeros_like(mask_i, dtype=np.float32)

    H, W = A.mask.shape
    kl_accum = np.zeros((H, W), dtype=np.float32)
    n_nb_at = np.zeros((H, W), dtype=np.int32)

    mu_i    = A.mu_q_field        # (..., K)
    sigma_i = A.sigma_q_field     # (..., K, K)

    for nb in A.neighbors:
        j = nb["id"]
        B = agents[j]
        mask_j = B.mask > eps
        overlap = mask_i & mask_j
        if not np.any(overlap):
            continue

        # Extract overlapping values
        mu_j     = B.mu_q_field[overlap]       # (M, K)
        sigma_j  = B.sigma_q_field[overlap]    # (M, K, K)

        Ω_ij     = np.einsum("mab,mbc->mac", A.Omega[overlap], B.Omega_inv[overlap])
        mu_j_t   = np.einsum("mab,mb->ma", Ω_ij, mu_j)
        sigma_j_t = np.einsum("mab,mbc,mdc->mad", Ω_ij, sigma_j, Ω_ij)

        mu_i_pts    = mu_i[overlap]
        sigma_i_pts = sigma_i[overlap]

        kl_vals = kl_divergence(mu_i_pts, sigma_i_pts, mu_j_t, sigma_j_t, eps=log_eps)

        kl_accum[overlap] += kl_vals
        n_nb_at[overlap]  += 1

    out = np.zeros_like(kl_accum)
    valid = n_nb_at > 0
    out[valid] = kl_accum[valid] / n_nb_at[valid]
    return out * mask_i


def compute_model_alignment_field(agents, i, eps=1e-3) -> np.ndarray:
    """
    Compute D_KL(p_i || Ω̃_ij p_j) spatial field using model (μ_p, Σ_p) fields
    with gauge transport from φ_model. Averaged across neighbors.
    """
    from get_generators import get_generators
    A = agents[i]
    mask_i = threshold_mask(A.mask)
    if not np.any(mask_i) or not A.neighbors:
        return np.zeros_like(mask_i, dtype=np.float32)

    kl_accum = np.zeros_like(mask_i, dtype=np.float32)
    n_nb_at  = np.zeros_like(mask_i, dtype=np.int32)

    mu_i    = A.mu_p_field
    sigma_i = A.sigma_p_field

    generators = get_generators(config.group_name, config.K)

    for nb in A.neighbors:
        B = agents[nb["id"]]
        mask_j = threshold_mask(B.mask)
        overlap = mask_i & mask_j
        if not np.any(overlap):
            continue

        mu_j    = B.mu_p_field[overlap]
        sigma_j = B.sigma_p_field[overlap]

        O_i     = exp_lie_algebra_irrep(A.phi_model[overlap], generators)
        O_j_inv = exp_lie_algebra_irrep(-B.phi_model[overlap], generators)
        Omega   = np.einsum("mab,mbc->mac", O_i, O_j_inv)

        mu_j_t     = np.einsum("mab,mb->ma", Omega, mu_j)
        sigma_j_t  = np.einsum("mab,mbc,mdc->mad", Omega, sigma_j, Omega)

        mu_i_ov    = mu_i[overlap]
        sigma_i_ov = sigma_i[overlap]

        kl_vals = kl_divergence(mu_i_ov, sigma_i_ov, mu_j_t, sigma_j_t)
        kl_accum[overlap] += kl_vals
        n_nb_at[overlap]  += 1

    out = np.zeros_like(kl_accum)
    valid = n_nb_at > 0
    out[valid] = kl_accum[valid] / n_nb_at[valid]
    return out * mask_i

def compute_entropy_field(
    agents,
    i,
    sigma_field="sigma_q_field",
    mask_field="mask",
    support_cutoff_eps=1e-3,
    log_eps=1e-8,
):
    """
    Compute differential entropy field of a multivariate Gaussian:
        H[q(x)] = 0.5 * [ K log(2πe) + log det Σ(x) ]
    
    Args:
        agents : list of Agent objects
        i      : agent index
        sigma_field : str, name of field to use (e.g., "sigma_q_field", "sigma_p_field")
        mask_field  : str, name of mask field
        support_cutoff_eps : float, threshold to define valid region
        log_eps : float, regularization for numerical stability
    
    Returns:
        entropy : (H, W) entropy values, masked
    """
    sigma = getattr(agents[i], sigma_field)  # (..., K, K)
    mask  = getattr(agents[i], mask_field) > support_cutoff_eps
    K     = sigma.shape[-1]
    eye   = np.eye(K)

    sigma_reg = sigma + log_eps * eye
    log_det   = np.linalg.slogdet(sigma_reg)[1]  # (...,)

    entropy = 0.5 * (K * np.log(2 * np.pi * np.e) + log_det)
    return entropy * mask

def compute_entropy(sigma_field, mask, log_eps=1e-8):
    """
    Computes entropy for multivariate Gaussians:
        H[q] = 0.5 * [ K log(2πe) + log det Σ ]
    Inputs:
        sigma_field:  (L, L, K, K)
        mask:         (L, L) boolean
    Returns:
        Scalar entropy over masked region
    """
    Lx, Ly, K, _ = sigma_field.shape
    sigma_flat = sigma_field.reshape(-1, K, K)
    mask_flat  = mask.reshape(-1)

    entropy_vals = np.zeros(len(mask_flat))
    for idx in np.flatnonzero(mask_flat):
        S = sigma_flat[idx] + log_eps * np.eye(K)
        sign, logdet = np.linalg.slogdet(S)
        if sign <= 0:
            logdet = -np.inf
        entropy_vals[idx] = 0.5 * (K * np.log(2 * np.pi * np.e) + logdet)

    return float(np.sum(entropy_vals[mask_flat]))



def compute_alignment_field_pairwise(
    agents,
    i,
    j,
    eps: float = config.support_cutoff_eps,
    log_eps: float = config.log_eps
) -> np.ndarray:
    """
    Compute spatial KL alignment field D_KL(q_i || Ω_ij q_j) using full multivariate Gaussians.
    Assumes both agents have fields: mu_q_field, sigma_q_field, Omega, Omega_inv.

    Returns:
        2D array with KL divergence at overlap points, zero elsewhere.
    """
    A = agents[i]
    B = agents[j]
    mask_i = A.mask > eps
    mask_j = B.mask > eps
    overlap = mask_i & mask_j

    if not np.any(overlap):
        return np.zeros_like(A.mask, dtype=float)

    μ_i = A.mu_q_field[overlap]         # shape: (M, K)
    Σ_i = A.sigma_q_field[overlap]      # shape: (M, K, K)
    μ_j = B.mu_q_field[overlap]
    Σ_j = B.sigma_q_field[overlap]

    Ω_i = A.Omega[overlap]
    Ω_j_inv = B.Omega_inv[overlap]
    Ω_ij = np.einsum("mab,mbc->mac", Ω_i, Ω_j_inv)

    μ_j_t = np.einsum("mab,mb->ma", Ω_ij, μ_j)
    Σ_j_t = np.einsum("mab,mbc,mdc->mad", Ω_ij, Σ_j, Ω_ij)

    from generalized_math_utils import kl_divergence
    kl_vals = kl_divergence(μ_i, Σ_i, μ_j_t, Σ_j_t, eps=log_eps)

    field = np.zeros_like(A.mask, dtype=float)
    field[overlap] = kl_vals
    return field


def compute_self_energy(q_mu, q_sigma, p_mu, p_sigma, mask, alpha, log_eps):
    """
    Compute self-energy term: α · D_KL(q || p) over the agent's mask.
    """
    support = mask > config.support_cutoff_eps
    if not np.any(support):
        return 0.0
    kl_vals = kl_divergence(q_mu, q_sigma, p_mu, p_sigma, log_eps=log_eps)

    return alpha * float(np.sum(kl_vals))



from generalized_omega import transport_covariance_batch



def compute_feedback_energy(p_mu, p_sigma, q_mu, q_sigma, mask, weight, log_eps):
    support = mask > config.support_cutoff_eps
    if not np.any(support):
        return 0.0
    kl_vals = kl_divergence(
        p_mu[support], p_sigma[support],
        q_mu[support], q_sigma[support],
        log_eps  # pass as positional argument
    )
    return weight * float(np.sum(kl_vals))



def compute_alignment_energy(i, A, Q_list, Mask_list, O_bel, O_inv, beta, log_eps, n_jobs):
    """
    Alignment energy: β ∑_j D_KL(q_i || Ω_{ij} q_j)
    Assumes q_i and q_j are represented as (mu, sigma) tuples over the spatial domain.
    """
    

    qi_mu, qi_sigma = Q_list[i]
    mask = Mask_list[i]

    e_align = 0.0
    for nb in A.neighbors:
        j = nb["id"]
        ov = mask & Mask_list[j]
        if not ov.any():
            continue

        qj_mu, qj_sigma = Q_list[j]
        omega_ij = np.einsum("mab,mbc->mac", O_bel[i][ov], O_inv[j][ov])

        # Apply Ω to qj
        qj_mu_t, qj_sigma_t = batch_apply_omega(qj_mu[ov], qj_sigma[ov], omega_ij)

        # Compute KL(qi || Ω qj)
        kl_vals = kl_divergence(qi_mu[ov], qi_sigma[ov], qj_mu_t, qj_sigma_t, log_eps)
        e_align += beta * np.sum(kl_vals)

    return e_align

def compute_model_alignment_energy(i, A, P_list, Mask_list, O_mod, O_mod_inv, model_align_weight, log_eps, n_jobs):
    """
    Energy from model alignment: Σ_j D_KL(p_i || Ω̃_{ij} p_j)
    P_list entries are (mu_p, sigma_p)
    """
    
    pi_mu, pi_sigma = P_list[i]
    mask = Mask_list[i]
    e_mod_align = 0.0

    for nb in A.neighbors:
        j = nb["id"]
        ov = mask & Mask_list[j]
        if not ov.any():
            continue

        pj_mu, pj_sigma = P_list[j]
        Omega = np.einsum("mab,mbc->mac", O_mod[i][ov], O_mod_inv[j][ov])

        # Apply Ω̃ to (mu, sigma)
        pj_mu_t, pj_sigma_t = batch_apply_omega(pj_mu[ov], pj_sigma[ov], Omega)

        # KL(pi || Ω̃ pj)
        
        kl_vals = kl_divergence(
            pi_mu[ov], pi_sigma[ov],
            pj_mu_t, pj_sigma_t,
            log_eps
            )

        e_mod_align += model_align_weight * float(np.sum(kl_vals))

    return e_mod_align


def compute_laplacian_energy(phi, mask, weight):
    lap = laplacian_field(phi)
    return weight * np.sum(np.linalg.norm(lap[mask], axis=-1))

def compute_mass_energy(phi, mask, weight):
    return weight * np.sum(np.linalg.norm(phi[mask], axis=-1)**2)

def compute_phi_coupling_energy(phi, phi_model, mask, weight):
    diff = (phi - phi_model)[mask]
    return weight * float(np.sum(np.linalg.norm(diff, axis=-1)**2))


def compute_curvature_energy(phi, mask, weight, lie_gens):
    F = compute_field_strength(phi, lie_gens)  # dict of spatial tensor components
    total = 0.0
    for v in F.values():
        if v.ndim == 2:
            total += v**2                     # scalar curvature
        elif v.ndim == 3:
            total += np.sum(v**2, axis=-1)    # vector field
        elif v.ndim == 4:
            total += np.sum(v**2, axis=(-2, -1))  # matrix field
        else:
            raise ValueError(f"Unexpected curvature field shape: {v.shape}")
    total_energy = float(np.sum(total[mask]))
    return weight * total_energy, total_energy

def _agent_stats(
    i,
    A,
    step,
    q_field,
    p_field,
    phi_belief_field,
    phi_model_field,
    mask_field,
    cfg,
    generators,
    Q_list,
    P_list,
    Mask_list,
    O_bel,
    O_inv,
    O_mod,
    O_mod_inv,
    n_jobs
):
    mask = Mask_list[i]
    support = int(mask.sum())

    if not support:
        return i, {k: 0.0 for k in [
            "e_self", "e_align", "e_feedback", "e_mod_align",
            "e_lap_bel", "e_mass_bel", "e_lap_mod", "e_mass_mod",
            "e_couple", "e_curv", "e_curv_mod",
            "phi_norm", "phi_model_norm", "entropy",
            "lap_phi_norm", "delta_phi_norm",
            "curvature_norm", "curvature_model_norm",
            "fisher_information", "kl_align_total", "kl_align_avg_per_point",
        ]} | {"model_arr": np.zeros(len(Mask_list), dtype=float)}

    # Safely populate pull_Delta if needed
    if A.pull_Delta is None and np.any(mask > config.support_cutoff_eps):
        mu = A.mu_q_field
        grad = np.stack([np.gradient(mu[..., k]) for k in range(mu.shape[-1])], axis=-1)  # (D, H, W, K)
        grad = np.moveaxis(grad, 0, -2)  # → (H, W, D, K)
        A.pull_Delta = grad * mask[..., None, None]

    # field slices
    qi, pi = Q_list[i], P_list[i]
    lie_gens = generators
    log_eps = cfg["log_eps"]

    mu_q     = A.mu_q_field
    sigma_q  = A.sigma_q_field
    mu_p     = A.mu_p_field
    sigma_p  = A.sigma_p_field

    # KL Terms
    e_self = kl_divergence(mu_q, sigma_q, mu_p, sigma_p, eps=log_eps)
    e_self = float((e_self * mask).sum()) * cfg["alpha"]

    e_feedback = kl_divergence(mu_p, sigma_p, mu_q, sigma_q, eps=log_eps)
    e_feedback = float((e_feedback * mask).sum()) * cfg["model_feedback_weight"]

    e_align = compute_alignment_energy(i, A, Q_list, Mask_list, O_bel, O_inv,
                                       cfg["beta"], log_eps, n_jobs)

    e_mod_align = compute_model_alignment_energy(i, A, P_list, Mask_list,
                                                 O_mod, O_mod_inv,
                                                 cfg["model_align_weight"], log_eps, n_jobs)

    # Laplacian + mass
    e_lap_bel     = compute_laplacian_energy(A.phi, mask, cfg["gamma"])
    e_mass_bel    = compute_mass_energy(A.phi, mask, cfg["gauge_weight"])
    e_lap_mod     = compute_laplacian_energy(A.phi_model, mask, cfg["model_gauge_weight"])
    e_mass_mod    = compute_mass_energy(A.phi_model, mask, cfg["model_mass_weight"])

    # Coupling + curvature
    e_couple      = compute_phi_coupling_energy(A.phi, A.phi_model, mask, cfg["phi_phi_tilde_coupling"])
    e_curv, curv_norm_bel = compute_curvature_energy(A.phi, mask, cfg["curvature_weight"], lie_gens)
    e_curv_mod, curv_norm_mod = compute_curvature_energy(A.phi_model, mask, cfg["curvature_weight"], lie_gens)

    # Scalar diagnostics
    entropy = compute_entropy(sigma_q, mask)

    phi_norm       = np.linalg.norm(A.phi[mask], axis=-1).sum()
    phi_model_norm = np.linalg.norm(A.phi_model[mask], axis=-1).sum()
    lap_phi_norm   = np.linalg.norm(laplacian_field(A.phi)[mask], axis=-1).sum()
    delta_phi_norm = float(np.linalg.norm(getattr(A, "delta_phi", 0.0), axis=-1)[mask].max()) if hasattr(A, "delta_phi") else 0.0

    fisher_information = compute_fisher_from_gaussian(mu_q, sigma_q, mask)

    total_overlap_points = sum((mask & Mask_list[nb["id"]]).sum() for nb in A.neighbors if (mask & Mask_list[nb["id"]]).any())

    stats = {
        "e_self":        e_self,
        "e_align":       e_align,
        "e_feedback":    e_feedback,
        "e_mod_align":   e_mod_align,
        "e_lap_bel":     e_lap_bel,
        "e_mass_bel":    e_mass_bel,
        "e_lap_mod":     e_lap_mod,
        "e_mass_mod":    e_mass_mod,
        "e_couple":      e_couple,
        "e_curv":        e_curv,
        "e_curv_mod":    e_curv_mod,
        "phi_norm":      phi_norm,
        "phi_model_norm":phi_model_norm,
        "entropy":       entropy,
        "lap_phi_norm":  lap_phi_norm,
        "delta_phi_norm":delta_phi_norm,
        "curvature_norm":       curv_norm_bel,
        "curvature_model_norm": curv_norm_mod,
        "fisher_information": fisher_information,
        "kl_align_total": e_align,
        "kl_align_avg_per_point": (e_align / max(total_overlap_points, 1)) / support,
        "model_arr": np.zeros(len(Mask_list), dtype=float)
    }

    return i, stats



def preprocess_fields(agents, q_field, p_field, mask_field, overlap_eps, log_eps):
    from generalized_math_utils import sanitize_q
    Q_list, P_list, Mask_list = [], [], []
    O_bel, O_inv, O_mod, O_mod_inv = [], [], [], []

    for A in agents:
        mask = getattr(A, mask_field) > overlap_eps
        Mask_list.append(mask)
        Q_list.append(sanitize_q(getattr(A, q_field), eps=log_eps))
        P_list.append(sanitize_q(getattr(A, p_field), eps=log_eps))
        O_bel.append(A.Omega)
        O_inv.append(A.Omega_inv)
        O_mod.append(A.Omega_model)
        O_mod_inv.append(A.Omega_model_inv)

    return Q_list, P_list, Mask_list, O_bel, O_inv, O_mod, O_mod_inv

def compute_agent_metrics(
    i, A, Q_list, P_list, Mask_list,
    O_bel, O_inv, O_mod, O_mod_inv,
    cfg, gens, log_eps
):
    mask = Mask_list[i]
    if not mask.any():
        return i, zero_agent_metrics(len(Q_list))

    stats = compute_all_agent_metrics(
        i, A, Q_list, P_list, Mask_list,
        O_bel, O_inv, O_mod, O_mod_inv,
        cfg, gens, log_eps
    )
    return i, stats

def zero_agent_metrics(N: int) -> dict:
    return {
        "e_self": 0, "e_align": 0, "e_feedback": 0, "e_mod_align": 0,
        "e_lap_bel": 0, "e_mass_bel": 0, "e_lap_mod": 0, "e_mass_mod": 0,
        "e_couple": 0, "e_curv": 0, "e_curv_mod": 0,

        "phi_norm": 0,
        "phi_model_norm": 0,
        "entropy": 0,
        "lap_phi_norm": 0,
        "delta_phi_norm": 0,
        "fisher_information": 0,
        "curvature_norm": 0,
        "curvature_model_norm": 0,

        "kl_self_avg_per_point": 0,
        "kl_feedback_avg_per_point": 0,
        "kl_model_align_avg_per_point": 0,
        "kl_align_avg_per_point": 0,
        "trace_G":  0.0,
        "mix_norm": 0.0,

        "model_arr": np.zeros(N, dtype=float)
    }



def accumulate_and_log_metrics(results, agents, step, Q_list, Mask_list):
    keys = ["e_self", "e_align", "e_feedback", "e_mod_align"]
    accum = {k: 0.0 for k in keys}
    total_support = 0

    for i, s in enumerate(results):

        support = int(Mask_list[i].sum())
        total_support += support
        for k in keys:
            accum[k] += s[k]
        agents[i].log_metrics(step, {
            "kl_self":         s["e_self"]        / support,
            "kl_feedback":     s["e_feedback"]    / support,
            "kl_align":        s["e_align"]       / support,
            "kl_mod_align":    s["e_mod_align"]   / support,

            "kl_self_avg_per_point":        s["kl_self_avg_per_point"],
            "kl_feedback_avg_per_point":    s["kl_feedback_avg_per_point"],
            "kl_model_align_avg_per_point": s["kl_model_align_avg_per_point"],
            "kl_align_avg_per_point":       s["kl_align_avg_per_point"],

            "entropy":          s["entropy"],
            "phi_norm":         s["phi_norm"],
            "phi_model_norm":   s["phi_model_norm"],
            "lap_phi_norm":     s["lap_phi_norm"],
            "delta_phi_norm":   s["delta_phi_norm"],
            
            "lap_phi":         s["e_lap_bel"]     / support,
            "mass_phi":        s["e_mass_bel"]    / support,
            "lap_phi_mod":     s["e_lap_mod"]     / support,
            "mass_phi_mod":    s["e_mass_mod"]    / support,
            "phi_phi_couple":  s["e_couple"]      / support,
            "curvature_norm":       s["curvature_norm"]       / support,
            "curvature_model_norm": s["curvature_model_norm"] / support,

            "trace_G":  s["trace_G"],
            "mix_norm": s["mix_norm"],
        })

    S = max(total_support, 1)
    metrics = {k: accum[k] / S for k in keys}
    metrics["total_energy"] = sum(accum.values()) / S
    metrics["step"] = step
    return metrics

def compute_all_agent_metrics(i, A, Q_list, P_list, Mask_list,
                               O_bel, O_inv, O_mod, O_mod_inv,
                               cfg, gens, log_eps):

    mask = Mask_list[i]
    # NEW — use Gaussian params
    q_mu, q_sigma = A.mu_q_field, A.sigma_q_field
    p_mu, p_sigma = A.mu_p_field, A.sigma_p_field


    stats = {}
    stats["e_self"] = compute_self_energy(q_mu, q_sigma, p_mu, p_sigma, mask, cfg["alpha"], log_eps)
    stats["e_feedback"] = compute_feedback_energy(p_mu, p_sigma, q_mu, q_sigma, mask, cfg["model_feedback_weight"], log_eps)

    
    
    stats["e_align"] = compute_alignment_energy(i, A, Q_list, Mask_list, O_bel, O_inv, cfg["beta"], log_eps, cfg.get("n_jobs_align", 1))
    stats["e_mod_align"] = compute_model_alignment_energy(i, A, P_list, Mask_list, O_mod, O_mod_inv, cfg["model_align_weight"], log_eps, cfg.get("n_jobs_align", 1))
    stats["e_couple"] = compute_phi_coupling_energy(A.phi, A.phi_model, mask, cfg["phi_phi_tilde_coupling"])
    stats["e_curv"], stats["curvature_norm"] = compute_curvature_energy(A.phi, mask, cfg["curvature_weight"], gens)
    stats["e_curv_mod"], stats["curvature_model_norm"] = compute_curvature_energy(A.phi_model, mask, cfg["curvature_weight"], gens)
    stats["e_lap_bel"] = compute_laplacian_energy(A.phi, mask, cfg["gamma"])
    stats["e_mass_bel"] = compute_mass_energy(A.phi, mask, cfg["gauge_weight"])
    stats["e_lap_mod"] = compute_laplacian_energy(A.phi_model, mask, cfg["model_gauge_weight"])
    stats["e_mass_mod"] = compute_mass_energy(A.phi_model, mask, cfg["model_mass_weight"])

    # MV Gaussian entropy (Σ is full matrix)
    stats["entropy"] = compute_entropy(A.sigma_q_field, mask, log_eps)

    stats["kl_align_avg_per_point"] = stats["e_align"] / max(mask.sum(), 1)
    stats["kl_model_align_avg_per_point"] = stats["e_mod_align"] / max(mask.sum(), 1)
    stats["kl_self_avg_per_point"] = stats["e_self"] / max(mask.sum(), 1)
    stats["kl_feedback_avg_per_point"] = stats["e_feedback"] / max(mask.sum(), 1)

    stats["phi_norm"] = np.linalg.norm(A.phi[mask], axis=-1).sum()
    stats["phi_model_norm"] = np.linalg.norm(A.phi_model[mask], axis=-1).sum()
    stats["lap_phi_norm"] = np.linalg.norm(laplacian_field(A.phi)[mask], axis=-1).sum()
    stats["delta_phi_norm"] = np.linalg.norm(A.delta_phi[mask], axis=-1).sum() if hasattr(A, "delta_phi") else 0.0

    if A.spatial_G is not None:
        G = A.spatial_G  # shape (H, W, 2, 2)
        stats["trace_G"] = np.mean(G[..., 0, 0] + G[..., 1, 1])
    else:
        stats["trace_G"] = np.nan

    if A.pull_Delta is not None:
        Δ = A.pull_Delta.reshape(G.shape[0], G.shape[1], 2)
        stats["Δ_norm"] = np.linalg.norm(Δ)
        stats["mix_norm"] = np.mean(np.linalg.norm(Δ, axis=2))
    else:
        stats["Δ_norm"] = np.nan
        stats["mix_norm"] = np.nan

    return stats

def log_all_metrics_fused(
    agents,
    step,
    params=None,
    q_field="q",
    p_field="p",
    phi_belief_field="phi",
    phi_model_field="phi_model",
    mask_field="mask",
    n_jobs=-1
):
    import numpy as np
    from joblib import Parallel, delayed
    from generalized_diagnostics_metrics import compute_all_agent_metrics

    cfg = config if params is None else {**vars(config), **params}
    log_eps = cfg.get("log_eps", 1e-10)

    N = len(agents)  # ← FIX: number of agents
    gens = get_generators(cfg["group_name"], cfg["K"])  # ← FIX: needed for curvature terms

    # Precompute fields
    Q_list     = [(A.mu_q_field, A.sigma_q_field) for A in agents]
    P_list     = [(A.mu_p_field, A.sigma_p_field) for A in agents]
    Mask_list = [np.asarray(getattr(A, mask_field), dtype=bool) for A in agents]

    O_bel      = [A.Omega for A in agents]
    O_inv      = [A.Omega_inv for A in agents]
    O_mod      = [A.Omega_model for A in agents]
    O_mod_inv  = [A.Omega_model_inv for A in agents]

    results = Parallel(n_jobs=n_jobs, backend="threading")(
        delayed(compute_all_agent_metrics)(
            i, agents[i], Q_list, P_list, Mask_list,
            O_bel, O_inv, O_mod, O_mod_inv,
            cfg, gens, log_eps
        )
        for i in range(N)
    )

    return accumulate_and_log_metrics(results, agents, step, Q_list, Mask_list)


def log_max_overlap_fields(agents, step, outdir,
                           eps=config.support_cutoff_eps):
    """
    Finds the two agents with the largest overlap and logs:
      - belief vs. model alignment fields
      - full (K,) μ and (K,K) σ for belief (q) and model (p)
    into a compressed .npz per step.
    """
    from get_generators import get_generators
    from generalized_omega import exp_lie_algebra_irrep

    os.makedirs(outdir, exist_ok=True)

    # 1) Identify best pair
    max_overlap = 0
    best_pair = None
    for i, A in enumerate(agents):
        mask_i = A.mask > eps
        if not mask_i.any():
            continue
        for nb in A.neighbors:
            j = nb["id"]
            mask_j = agents[j].mask > eps
            ov = mask_i & mask_j
            cnt = int(ov.sum())
            if cnt > max_overlap:
                max_overlap = cnt
                best_pair = (i, j)

    if best_pair is None:
        print(f"[DEBUG] No overlapping agent pairs at step {step}")
        return

    i, j = best_pair

    # 2) Cache exponentiated φ fields
    gens = get_generators(config.group_name, config.K)
    for idx in [i, j]:
        A = agents[idx]
        if A._exp_phi is None:
            A._exp_phi = exp_lie_algebra_irrep(A.phi, gens, group_name=config.group_name)
        if A._exp_neg_phi is None:
            A._exp_neg_phi = exp_lie_algebra_irrep(-A.phi, gens, group_name=config.group_name)
        if A._exp_phi_model is None:
            A._exp_phi_model = exp_lie_algebra_irrep(A.phi_model, gens, group_name=config.group_name)
        if A._exp_neg_phi_model is None:
            A._exp_neg_phi_model = exp_lie_algebra_irrep(-A.phi_model, gens, group_name=config.group_name)

    # 3) Compute alignment fields
    belief_align_field = compute_alignment_field(agents, i)
    model_align_field  = compute_model_alignment_field(agents, i)

    # 4) Extract μ and Σ fields
    mu_q     = agents[i].mu_q_field           # shape (H, W, K)
    sigma_q  = agents[i].sigma_q_field        # shape (H, W, K, K)
    mu_p     = agents[i].mu_p_field
    sigma_p  = agents[i].sigma_p_field

    # 5) Compute KL fields
    kl_self_field     = kl_divergence(mu_q, sigma_q, mu_p, sigma_p)
    kl_feedback_field = kl_divergence(mu_p, sigma_p, mu_q, sigma_q)

    # 6) Save
    mask_i = (agents[i].mask > eps).astype(np.float32)
    fname = os.path.join(outdir, f"step{step:05d}_pair_{i}_{j}.npz")
    np.savez_compressed(
    fname,
    agent_i            = i,
    agent_j            = j,
    overlap            = max_overlap,
    mask_i             = mask_i,
    belief_alignment   = belief_align_field,
    model_alignment    = model_align_field,
    mu_q               = mu_q,
    sigma_q            = sigma_q,
    mu_p               = mu_p,
    sigma_p            = sigma_p,
    kl_self            = kl_self_field,       # ← FIXED
    kl_feedback        = kl_feedback_field,   # ← FIXED
)

