from dataclasses import dataclass, field
from typing import Tuple, List, Optional, Dict, Any
import numpy as np

@dataclass
class Agent:
    id: int
    mask: np.ndarray  # (H, W)
    mu_q_field: np.ndarray  # (H, W, K)
    sigma_q_field: np.ndarray  # (H, W, K, K)
    mu_p_field: np.ndarray  # (H, W, K)
    sigma_p_field: np.ndarray  # (H, W, K, K)
    phi: np.ndarray  # (H, W, d)
    phi_model: np.ndarray  # (H, W, d)
    center: Tuple[int, ...]
    radius: float
    neighbors: List[dict]
    delta_phi_model: Optional[np.ndarray] = None

    # Optional q/p legacy fields (e.g., for heatmap rendering)
    q: Optional[np.ndarray] = None  # (H, W, K) if needed
    p: Optional[np.ndarray] = None

    # Fisher geometry (populated by diagnostics)
    fisher_I: Optional[np.ndarray] = None
    pull_M_vis: Optional[np.ndarray] = None
    pull_Delta: Optional[np.ndarray] = None
    pull_M_dark: Optional[np.ndarray] = None
    spatial_G: Optional[np.ndarray] = None

    # Meta-agent metadata
    agent_scale: float = 1.0
    hierarchy_level: int = 0

    # Metrics log and cache
    entropy: Optional[float] = None
    energy: Optional[float] = None
    coherence: Optional[float] = None
    last_update_step: Optional[int] = None
    metrics_log: List[Dict[str, Any]] = field(default_factory=list)

    _exp_phi: Optional[np.ndarray] = field(default=None, init=False)
    _exp_neg_phi: Optional[np.ndarray] = field(default=None, init=False)
    _exp_phi_model: Optional[np.ndarray] = field(default=None, init=False)
    _exp_neg_phi_model: Optional[np.ndarray] = field(default=None, init=False)

    q_flat: Optional[np.ndarray] = field(init=False, default=None)
    p_flat: Optional[np.ndarray] = field(init=False, default=None)

    def __post_init__(self):
        self.grid_shape = self.mu_q_field.shape[:-1]  # shape (H, W)
        if self.q is not None:
            self.q_flat = self.q.reshape(-1, self.q.shape[-1])
        if self.p is not None:
            self.p_flat = self.p.reshape(-1, self.p.shape[-1])

    def log_metrics(self, step: int, stats: Dict[str, Any]) -> None:
        entry = {'step': step}
        entry.update(stats)
        self.metrics_log.append(entry)

    def clear_omega_cache(self) -> None:
        self._exp_phi = None
        self._exp_neg_phi = None
        self._exp_phi_model = None
        self._exp_neg_phi_model = None

    @property
    def Omega(self) -> np.ndarray:
        K = self.mu_q_field.shape[-1]
        return self._exp_phi.reshape(*self.grid_shape, K, K)

    @property
    def Omega_inv(self) -> np.ndarray:
        K = self.mu_q_field.shape[-1]
        return self._exp_neg_phi.reshape(*self.grid_shape, K, K)

    @property
    def Omega_model(self) -> np.ndarray:
        K = self.mu_p_field.shape[-1]
        return self._exp_phi_model.reshape(*self.grid_shape, K, K)

    @property
    def Omega_model_inv(self) -> np.ndarray:
        K = self.mu_p_field.shape[-1]
        return self._exp_neg_phi_model.reshape(*self.grid_shape, K, K)

    @property
    def grid_shape(self):
        return self._grid_shape

    @grid_shape.setter
    def grid_shape(self, val):
        assert isinstance(val, tuple) and all(isinstance(d, int) for d in val)
        self._grid_shape = val
