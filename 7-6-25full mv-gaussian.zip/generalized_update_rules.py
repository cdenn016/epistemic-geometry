import numpy as np
import config
from joblib import Parallel, delayed
from generalized_math_utils import sanitize_q
from generalized_omega import exp_lie_algebra_irrep
from generalized_update_terms import (
    compute_beliefs_gradient,
    compute_models_gradient,
    compute_phi_alignment_gradient,
    compute_phi_model_update,
)

def _compute_all_grads(i, agents, params):
    ai = agents[i]
    return (
        compute_beliefs_gradient(ai, agents, params),
        compute_models_gradient(ai, agents, params),
        compute_phi_alignment_gradient(ai, agents, params),
        compute_phi_model_update(ai, agents, params),
    )

def synchronous_step(agents, generators, params=None, n_jobs=1):
    params = params or {}
    N = len(agents)

    # 0) Clear caches & precompute exp(phi) and exp(-phi)
    for A in agents:
        A.clear_omega_cache()

        e_belief = params.get("e_belief", config.e_belief)
        e_model  = params.get("e_model",  config.e_model)

        flat_phi       = A.phi.reshape(-1, A.phi.shape[-1]) / e_belief
        flat_phi_model = A.phi_model.reshape(-1, A.phi_model.shape[-1]) / e_model

        assert A.phi.ndim == 3
        assert A.phi_model.ndim == 3
        assert A.phi.shape[-1] == A.phi_model.shape[-1]
        assert A.phi.shape[:-1] == A.phi_model.shape[:-1]

        A.grid_shape = A.phi.shape[:-1]
        A._exp_phi           = exp_lie_algebra_irrep(flat_phi,       generators)
        A._exp_neg_phi       = exp_lie_algebra_irrep(-flat_phi,      generators)
        A._exp_phi_model     = exp_lie_algebra_irrep(flat_phi_model, generators)
        A._exp_neg_phi_model = exp_lie_algebra_irrep(-flat_phi_model,generators)

    # 1) Snapshot old φ fields
    phi_old   = [agent.phi.copy()       for agent in agents]
    phi_m_old = [agent.phi_model.copy() for agent in agents]
    mask_list = [agent.mask            for agent in agents]

    # 2) Compute all gradients in parallel
    params_with_step = {**params}
    if "step_debug" not in params_with_step and "step" in params:
        params_with_step["step_debug"] = params["step"]

    q_grads, p_grads, phi_grads, phi_m_grads = zip(*Parallel(
        n_jobs=n_jobs,
        backend="threading"
    )(
        delayed(_compute_all_grads)(i, agents, params_with_step)
        for i in range(N)
    ))

    # 3) Load step sizes
    eta_q         = params.get('eta_q',         config.eta_q)
    eta_p         = params.get('eta_p',         config.eta_p)
    eta_phi       = params.get('eta_phi',       config.eta_phi)
    eta_model_phi = params.get('eta_model_phi', config.eta_model_phi)

    # 4) Apply updates synchronously
    for i, agent in enumerate(agents):
        mask = mask_list[i]
        mask_mu    = mask[..., None]       # (H, W, 1)
        mask_sigma = mask[..., None, None] # (H, W, 1, 1)

        grad_mu_q,    grad_sigma_q    = q_grads[i]
        grad_mu_p,    grad_sigma_p    = p_grads[i]
        dphi          = -eta_phi       * phi_grads[i]
        dphi_m        = -eta_model_phi * phi_m_grads[i]

        # Raw gradient norms (before applying learning rate)
        if getattr(config, "debug", False):
            norm_phi_grad     = np.linalg.norm(phi_grads[i])
            norm_phi_m_grad   = np.linalg.norm(phi_m_grads[i])
            print(f"[DEBUG ∇φ] Agent {i}: ‖∇φ‖={norm_phi_grad:.6e}")
        if not getattr(config, "identical_models", False):
            print(f"[DEBUG ∇φ_model] Agent {i}: ‖∇φ_model‖={norm_phi_m_grad:.6e}")


        # ─── Optional DEBUG dot-product diagnostics: ⟨∇F, Δ⟩ ─────────────────
        if getattr(config, "debug", False):
            dot_mu_q  = np.sum(grad_mu_q * (-eta_q * grad_mu_q * mask_mu))
            dot_mu_p  = np.sum(grad_mu_p * (-eta_p * grad_mu_p * mask_mu))
            dot_phi   = np.sum(phi_grads[i] * dphi)

            #print(f"[DEBUG ⟨∇F, Δμ_q⟩] Agent {i}: {dot_mu_q:.5e}")
            #print(f"[DEBUG ⟨∇F, Δμ_p⟩] Agent {i}: {dot_mu_p:.5e}")
            #print(f"[DEBUG ⟨∇F, Δφ⟩]    Agent {i}: {dot_phi:.5e}")

            if not getattr(config, "identical_models", False):
                dot_phi_m = np.sum(phi_m_grads[i] * dphi_m)
                #print(f"[DEBUG ⟨∇F, Δφ_model⟩] Agent {i}: {dot_phi_m:.5e}")

        # Belief updates
        agent.mu_q_field    += -eta_q * grad_mu_q    * mask_mu
        agent.sigma_q_field += -eta_q * grad_sigma_q * mask_sigma

        # Model updates
        agent.mu_p_field    += -eta_p * grad_mu_p    * mask_mu
        agent.sigma_p_field += -eta_p * grad_sigma_p * mask_sigma


        # φ update
        mask_exp = np.broadcast_to(mask_mu, phi_old[i].shape)
        agent.phi = phi_old[i] + dphi * mask_exp
        agent.delta_phi = dphi * mask_exp

        # φ_model update
        if not getattr(config, "identical_models", False):
            assert dphi_m.shape == phi_m_old[i].shape
            agent.phi_model = phi_m_old[i] + dphi_m * mask_exp
            agent.delta_phi_model = dphi_m * mask_exp

        # Norm diagnostics
        dq_norm = np.linalg.norm(-eta_q * grad_mu_q * mask_mu)
        dp_norm = np.linalg.norm(-eta_p * grad_mu_p * mask_mu)
        dphi_norm = np.linalg.norm(dphi)

        #print(f"[DEBUG Δ] Agent {i}: ‖Δμ_q‖={dq_norm:.6f} ‖Δμ_p‖={dp_norm:.6f} ‖Δφ‖={dphi_norm:.6f}")

        if not getattr(config, "identical_models", False):
            dphi_m_norm = np.linalg.norm(dphi_m)
            print(f"[DEBUG Δ] Agent {i}: ‖Δφ_model‖={dphi_m_norm:.6f}")

    return agents




def update_all(agents, generators, params=None, n_jobs=1):
    """
    Alias for synchronous_step with explicit generators argument.
    """
    return synchronous_step(agents, generators, params, n_jobs)