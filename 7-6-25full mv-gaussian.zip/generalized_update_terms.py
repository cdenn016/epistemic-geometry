import numpy as np
import config

from generalized_math_utils import sanitize_q
from get_generators import get_generators

from generalized_omega import batch_apply_omega, repair_if_forgotten_batch
from generalized_math_utils import laplacian_field


def compute_self_gradient(agent_i, params):
    """
    Compute gradients ∇_μ and ∇_Σ for self-energy KL(q || p),
    using multivariate Gaussian parameters.
    """
    alpha = params.get("alpha", config.alpha)
    eps = params.get("eps", config.eps)
    support_eps = params.get("support_cutoff_eps", config.support_cutoff_eps)

    mask = agent_i.mask > support_eps
    if not np.any(mask) or alpha <= 0:
        return (
            np.zeros_like(agent_i.mu_q_field),
            np.zeros_like(agent_i.sigma_q_field),
        )

    mu_q = agent_i.mu_q_field[mask]       # (N, K)
    sigma_q = agent_i.sigma_q_field[mask] # (N, K, K)
    mu_p = agent_i.mu_p_field[mask]
    sigma_p = agent_i.sigma_p_field[mask]

    K = mu_q.shape[-1]
    eye = np.eye(K)

    grad_mu = np.zeros((*mask.shape, K))
    grad_sigma = np.zeros((*mask.shape, K, K))

    flat_indices = np.flatnonzero(mask)
    for idx, (μq, Σq, μp, Σp) in enumerate(zip(mu_q, sigma_q, mu_p, sigma_p)):
        Σp_inv = np.linalg.solve(Σp + eps * eye, eye)
        Σq_inv = np.linalg.solve(Σq + eps * eye, eye)

        d_mu = Σp_inv @ (μq - μp)
        d_sigma = 0.5 * (Σp_inv - Σq_inv)
        d_sigma = 0.5 * (d_sigma + d_sigma.T)  # enforce symmetry

        i, j = np.unravel_index(flat_indices[idx], mask.shape)
        grad_mu[i, j, :] = alpha * d_mu
        grad_sigma[i, j, :, :] = alpha * d_sigma

    #print(f"[DEBUG ∇μ_self] Agent {agent_i.id}: ‖∇_μ KL(q‖p)‖ = {np.linalg.norm(grad_mu):.4e}")

    return grad_mu, grad_sigma

def compute_alignment_gradient(agent_i, agents, params, field_type="belief"):
    """
    Compute ∇_μ and ∇_Σ of the alignment energy:
        ∑_j β · D_KL(q_i || Ω_{ij} q_j)
        or      β̃ · D_KL(p_i || Ω̃_{ij} p_j)
    """
    if field_type == "belief":
        beta = params.get("beta", config.beta)
        mu_i_field = agent_i.mu_q_field
        sigma_i_field = agent_i.sigma_q_field
        Omega_i = agent_i.Omega
        mu_j_field_name = "mu_q_field"
        sigma_j_field_name = "sigma_q_field"
        Omega_inv_name = "Omega_inv"
    elif field_type == "model":
        beta = params.get("model_align_weight", config.model_align_weight)
        mu_i_field = agent_i.mu_p_field
        sigma_i_field = agent_i.sigma_p_field
        Omega_i = agent_i.Omega_model
        mu_j_field_name = "mu_p_field"
        sigma_j_field_name = "sigma_p_field"
        Omega_inv_name = "Omega_model_inv"
    else:
        raise ValueError(f"Invalid field_type: {field_type}")

    if beta <= 0:
        return np.zeros_like(mu_i_field), np.zeros_like(sigma_i_field)

    overlap_eps = params.get("overlap_eps", config.support_cutoff_eps)
    eps = params.get("eps", config.eps)

    mask_i = agent_i.mask > overlap_eps
    if not np.any(mask_i):
        return np.zeros_like(mu_i_field), np.zeros_like(sigma_i_field)

    K = mu_i_field.shape[-1]
    eye = np.eye(K)
    grad_mu = np.zeros_like(mu_i_field)
    grad_sigma = np.zeros_like(sigma_i_field)

    for nb in agent_i.neighbors:
        j = nb["id"]
        agent_j = agents[j]
        mask_j = agent_j.mask > overlap_eps
        overlap = mask_i & mask_j
        if not np.any(overlap):
            continue

        coords = np.argwhere(overlap)  # (M, 2)
        mu_i     = mu_i_field[overlap]            # (M, K)
        sigma_i  = sigma_i_field[overlap]         # (M, K, K)
        mu_j     = getattr(agent_j, mu_j_field_name)[overlap]  # (M, K)
        sigma_j_all = getattr(agent_j, sigma_j_field_name)     # (H, W, K, K)
        sigma_j = np.stack([sigma_j_all[i, j] for i, j in coords], axis=0)  # (M, K, K)

        Omega_i_ov  = Omega_i[overlap]                            # (M, K, K)
        Omega_j_inv = getattr(agent_j, Omega_inv_name)[overlap]  # (M, K, K)
        Omega_prod  = np.einsum("mij,mjk->mik", Omega_i_ov, Omega_j_inv)

        # Apply transport
        mu_j_rot, sigma_j_rot = batch_apply_omega(mu_j, sigma_j, Omega_prod)

        for (i_, j_), (μi, Σi, μjr, Σjr) in zip(coords, zip(mu_i, sigma_i, mu_j_rot, sigma_j_rot)):
            Σjr_inv = np.linalg.solve(Σjr + eps * eye, eye)
            Σi_inv = np.linalg.solve(Σi + eps * eye, eye)

            d_mu = Σjr_inv @ (μi - μjr)
            d_sigma = 0.5 * (Σjr_inv - Σi_inv)
            d_sigma = 0.5 * (d_sigma + d_sigma.T)

            grad_mu[i_, j_] += beta * d_mu
            grad_sigma[i_, j_] += beta * d_sigma

    #if field_type == "belief":
   #     print(f"[DEBUG ∇μ_align] Agent {agent_i.id}: ‖∇_μ KL(q‖Ωq_j)‖ = {np.linalg.norm(grad_mu):.4e}")
   # elif field_type == "model":
   #     print(f"[DEBUG ∇μ_model_align] Agent {agent_i.id}: ‖∇_μ KL(p‖Ω̃p_j)‖ = {np.linalg.norm(grad_mu):.4e}")


    return grad_mu, grad_sigma




def compute_beliefs_gradient(agent_i, agents, params):
    """
    Compute total gradients ∇_μ and ∇_Σ for belief parameters q:
        grad_mu_total    = grad_mu_self + grad_mu_align
        grad_sigma_total = grad_sigma_self + grad_sigma_align
    """
    grad_mu_self, grad_sigma_self   = compute_self_gradient(agent_i, params)
    grad_mu_align, grad_sigma_align = compute_alignment_gradient(agent_i, agents, params, field_type="belief")

    grad_mu_total    = grad_mu_self + grad_mu_align
    grad_sigma_total = grad_sigma_self + grad_sigma_align

    return grad_mu_total, grad_sigma_total

def compute_models_gradient(agent_i, agents, params):
    """
    Compute ∇μ_p and ∇Σ_p from:
        1. Self energy:     KL(q || p)
        2. Feedback term:   KL(p || q)
        3. Alignment:       KL(p || Ω̃ p_j)
    """
    if getattr(config, "identical_models", False):
        return (
            np.zeros_like(agent_i.mu_p_field),
            np.zeros_like(agent_i.sigma_p_field),
        )

    alpha = params.get("alpha", config.alpha)
    mf = params.get("model_feedback_weight", config.model_feedback_weight)
    beta_m = params.get("model_align_weight", config.model_align_weight)
    eps = params.get("eps", config.eps)
    support_eps = params.get("support_cutoff_eps", config.support_cutoff_eps)

    mask = agent_i.mask > support_eps
    if not np.any(mask):
        return (
            np.zeros_like(agent_i.mu_p_field),
            np.zeros_like(agent_i.sigma_p_field),
        )

    mu_q = agent_i.mu_q_field[mask]
    sigma_q = agent_i.sigma_q_field[mask]
    mu_p = agent_i.mu_p_field[mask]
    sigma_p = agent_i.sigma_p_field[mask]

    K = mu_p.shape[-1]
    eye = np.eye(K)

    grad_mu = np.zeros_like(agent_i.mu_p_field)
    grad_sigma = np.zeros_like(agent_i.sigma_p_field)

    flat_indices = np.flatnonzero(mask)
    for idx, (μq, Σq, μp, Σp) in enumerate(zip(mu_q, sigma_q, mu_p, sigma_p)):
        Σp_inv = np.linalg.inv(Σp + eps * eye)
        Σq_inv = np.linalg.inv(Σq + eps * eye)

        d_mu = np.zeros(K)
        d_sigma = np.zeros((K, K))

        # Self gradient: ∇_p KL(q ‖ p)
        if alpha > 0:
            d_mu += -Σp_inv @ (μq - μp)
            d_sigma += 0.5 * (-Σp_inv + Σp_inv @ Σq @ Σp_inv)

        # Feedback gradient: ∇_p KL(p ‖ q)
        if mf > 0:
            d_mu += mf * Σq_inv @ (μp - μq)
            d_sigma += 0.5 * mf * (Σq_inv - Σp_inv)

        i, j = np.unravel_index(flat_indices[idx], mask.shape)
        grad_mu[i, j] = d_mu
        grad_sigma[i, j] = 0.5 * (d_sigma + d_sigma.T)

    # Alignment term: KL(p_i || Ω̃ p_j)
    if beta_m > 0:
        grad_mu_align, grad_sigma_align = compute_alignment_gradient(
            agent_i, agents, params,
            field_type="model"
        )
        grad_mu += grad_mu_align
        grad_sigma += grad_sigma_align

    #print(f"[DEBUG ∇μ_model_self+fb] Agent {agent_i.id}: ‖∇_μ (KL(q‖p)+KL(p‖q))‖ = {np.linalg.norm(grad_mu):.4e}")


    return grad_mu, grad_sigma


def compute_phi_alignment_gradient(agent_i, agents: list, params: dict) -> np.ndarray:
    """
    ∇_{φ} [ β·D_KL(q_i||Ω_{ij} q_j) + γ·Δφ + gauge_weight·φ² + φ_phi_tilde_coupling·(φ - φ_model)² ]
    using full Gaussian KL without evaluating q explicitly.

    Epistemic justification for φ clipping and gradient clipping:

    In this model, φ represents an agent’s internal epistemic frame — the gauge field that governs
    how beliefs are transported and aligned across perspective. While misalignment (KL divergence)
    drives ∇φ updates, an agent's frame should not shift arbitrarily or instantaneously.

    This function includes two forms of regularization to reflect epistemic constraints:

    1. Gradient clipping (∇φ):
       - Prevents unbounded updates to φ from extreme KL divergence.
       - Models bounded rationality: agents can only adapt their frame at a finite rate.

    2. φ norm clipping (before exp(φ)):
       - Ensures the exponential map (Ω = exp(φ)) remains well-behaved.
       - Reflects the principle that belief-frame shifts are locally bounded in magnitude.
       - Prevents frame explosions that would correspond to incoherent or delusional shifts.

    Together, these enforce the epistemically justified assumption that an agent’s internal frame
    of reference evolves smoothly and conservatively, constrained by perceptual and computational limits.
    """
    β  = params.get("beta", config.beta)
    γ  = params.get("gamma", config.gamma)
    gw = params.get("gauge_weight", config.gauge_weight)
    κ  = params.get("phi_phi_tilde_coupling", config.phi_phi_tilde_coupling)
    overlap_eps = params.get("overlap_eps", config.support_cutoff_eps)
    grad_clip_threshold = getattr(config, "phi_grad_clip_threshold", 1e4)  # Optional: add to config

    phi_i = agent_i.phi
    phi_m = agent_i.phi_model
    mask_i = agent_i.mask > overlap_eps
    grad = np.zeros_like(phi_i)

    if β <= 0 or not mask_i.any():
        return grad

    shape = agent_i.mu_q_field.shape
    N, K = np.prod(shape[:-1]), shape[-1]
    flat_grad = grad.reshape(N, grad.shape[-1])

    mu_i = agent_i.mu_q_field.reshape(N, K)
    Si   = agent_i.sigma_q_field.reshape(N, K, K)

    exp_phi_i     = agent_i._exp_phi.reshape(N, K, K)
    exp_neg_phi_i = agent_i._exp_neg_phi.reshape(N, K, K)
    Gs = get_generators(config.group_name, K)  # (d, K, K)

    for nb in agent_i.neighbors:
        agent_j = agents[nb["id"]]
        mask_j = agent_j.mask > overlap_eps
        ov = mask_i & mask_j
        idxs = np.flatnonzero(ov)
        if len(idxs) == 0:
            continue

        mu_j = agent_j.mu_q_field.reshape(N, K)[idxs]
        Sj   = agent_j.sigma_q_field.reshape(N, K, K)[idxs]

        Oi     = exp_phi_i[idxs]
        Oj_inv = exp_neg_phi_i[idxs]
        Ω      = np.einsum("mab,mbc->mac", Oi, Oj_inv)

        mu_j_rot = np.einsum("mij,mj->mi", Ω, mu_j)
        Sj_rot   = np.einsum("mij,mjk,mkl->mil", Ω, Sj, Ω.transpose(0, 2, 1))

        mu_i_ = mu_i[idxs]
        Si_   = Si[idxs]

        Si_inv = np.linalg.inv(Si_ + 1e-6 * np.eye(K))
        Sj_inv = np.linalg.inv(Sj_rot + 1e-6 * np.eye(K))
        diff   = mu_j_rot - mu_i_

        H  = np.einsum("aij,mjk->maik", Gs, Oi)
        dΩ = np.einsum("maik,mkl->mail", H, Oj_inv)

        d = Gs.shape[0]
        grad_phi = np.zeros((len(idxs), d))

        try:
            eigvals = np.linalg.eigvalsh(Sj_rot)
            min_eig = np.min(eigvals, axis=1)
            max_eig = np.max(eigvals, axis=1)
            cond_num = max_eig / np.maximum(min_eig, 1e-12)

            n_bad = np.sum(min_eig <= 0)
            n_ill = np.sum(cond_num > 1e6)
            if n_bad > 0 or n_ill > 0:
                print(f"[WARNING ∇φ] Agent {agent_i.id}: {n_bad} non-SPD Σ_j_rot, {n_ill} ill-conditioned")

        except np.linalg.LinAlgError:
            print(f"[ERROR ∇φ] Agent {agent_i.id}: eigvalsh failed — skipping unstable neighborhood")
            continue

        for a in range(d):  # Lie algebra directions
            dΩa = dΩ[:, a, :, :]

            dmu_j_rot = np.einsum("mij,mj->mi", dΩa, mu_j)
            dSigma_rot = np.einsum("mij,mjk,mkl->mil", dΩa, Sj, Ω.transpose(0, 2, 1)) + \
                         np.einsum("mij,mjk,mkl->mil", Ω, Sj, dΩa.transpose(0, 2, 1))

            tr_term   = np.einsum("mij,mji->m", Sj_inv, dSigma_rot)
            quad_term = np.einsum("mi,mij,mj->m", diff, Sj_inv, dmu_j_rot)

            grad_phi[:, a] = β * 0.5 * (tr_term + 2 * quad_term)

        flat_grad[idxs] += grad_phi

    grad = flat_grad.reshape(*phi_i.shape)

    # Regularization
    if γ > 0:
        grad += γ * laplacian_field(phi_i)
    if gw > 0:
        grad += 2 * gw * phi_i
    if κ > 0:
        grad += 2 * κ * (phi_i - phi_m)

    # Gradient clipping (epistemic inertia)
    grad_norm = np.linalg.norm(grad)
    if grad_norm > grad_clip_threshold:
        grad *= grad_clip_threshold / (grad_norm + 1e-8)
        print(f"[CLIP ∇φ] Agent {agent_i.id}: ‖∇φ‖ clipped to {grad_clip_threshold:.1e}")

    return grad



def compute_phi_model_update(agent_i, agents: list, params: dict) -> np.ndarray:
    """
    ∇_{φ_model} [ βm·D_KL(p_i||Ω̃_{ij} p_j)
                 + γm·Δφ_model
                 + model_mass_weight·φ_model²
                 + φ_phi_tilde_coupling·(φ_belief - φ_model)² ]
    using Gaussian KL gradients via μ, Σ (no evaluation of p directly).
    """
    if getattr(config, "identical_models", False):
        return np.zeros_like(agent_i.phi_model)

    βm = params.get("model_align_weight", config.model_align_weight)
    γm = params.get("model_gauge_weight", config.model_gauge_weight)
    mmw = params.get("model_mass_weight", config.model_mass_weight)
    κ   = params.get("phi_phi_tilde_coupling", config.phi_phi_tilde_coupling)
    overlap_eps = params.get("overlap_eps", config.support_cutoff_eps)
    grad_clip_threshold = getattr(config, "phi_model_grad_clip_threshold", 1e4)

    φm_i = agent_i.phi_model       # (H, W, d)
    φ_i  = agent_i.phi             # (H, W, d)
    mask_i = agent_i.mask > overlap_eps

    grad = np.zeros_like(φm_i)
    if βm <= 0 or not mask_i.any():
        return grad

    shape = agent_i.mu_p_field.shape
    N, K = np.prod(shape[:-1]), shape[-1]
    d = φm_i.shape[-1]

    flat_grad = grad.reshape(N, d)
    mu_i = agent_i.mu_p_field.reshape(N, K)
    Si   = agent_i.sigma_p_field.reshape(N, K, K)

    exp_phi_i     = agent_i._exp_phi_model.reshape(N, K, K)
    exp_neg_phi_i = agent_i._exp_neg_phi_model.reshape(N, K, K)
    Gs = get_generators(config.group_name, K)  # (d, K, K)

    for nb in agent_i.neighbors:
        agent_j = agents[nb["id"]]
        mask_j  = agent_j.mask > overlap_eps
        ov = mask_i & mask_j
        idxs = np.flatnonzero(ov)
        if idxs.size == 0:
            continue

        mu_j = agent_j.mu_p_field.reshape(N, K)[idxs]
        Sj   = agent_j.sigma_p_field.reshape(N, K, K)[idxs]

        Oi     = exp_phi_i[idxs]
        Oj_inv = exp_neg_phi_i[idxs]
        Ω      = np.einsum("mab,mbc->mac", Oi, Oj_inv)

        mu_j_rot = np.einsum("mij,mj->mi", Ω, mu_j)
        Sj_rot   = np.einsum("mij,mjk,mkl->mil", Ω, Sj, Ω.transpose(0, 2, 1))

        mu_i_ = mu_i[idxs]
        Si_   = Si[idxs]

        Si_inv = np.linalg.inv(Si_ + 1e-6 * np.eye(K))
        Sj_inv = np.linalg.inv(Sj_rot + 1e-6 * np.eye(K))
        diff   = mu_j_rot - mu_i_

        H  = np.einsum("aij,mjk->maik", Gs, Oi)
        dΩ = np.einsum("maik,mkl->mail", H, Oj_inv)

        grad_phi = np.zeros((len(idxs), d))

        eigvals = np.linalg.eigvalsh(Sj_rot)
        min_eig = np.min(eigvals, axis=1)
        max_eig = np.max(eigvals, axis=1)
        cond_num = max_eig / np.maximum(min_eig, 1e-12)

        n_bad = np.sum(min_eig <= 0)
        n_ill = np.sum(cond_num > 1e6)
        if n_bad > 0 or n_ill > 0:
            print(f"[WARN Σ̃] Agent {agent_i.id}: {n_bad} non-SPD, {n_ill} ill-conditioned covariances after Ω̃ transport")

        for a in range(d):
            dΩa = dΩ[:, a, :, :]

            dmu_j_rot = np.einsum("mij,mj->mi", dΩa, mu_j)
            dSigma_rot = np.einsum("mij,mjk,mkl->mil", dΩa, Sj, Ω.transpose(0, 2, 1)) + \
                         np.einsum("mij,mjk,mkl->mil", Ω, Sj, dΩa.transpose(0, 2, 1))

            tr_term   = np.einsum("mij,mji->m", Sj_inv, dSigma_rot)
            quad_term = np.einsum("mi,mij,mj->m", diff, Sj_inv, dmu_j_rot)

            grad_phi[:, a] = βm * 0.5 * (tr_term + 2 * quad_term)

        flat_grad[idxs] += grad_phi  # Removed division

    grad = flat_grad.reshape(*φm_i.shape)

    if γm > 0:
        grad += γm * laplacian_field(φm_i)
    if mmw > 0:
        grad += 2 * mmw * φm_i
    if κ > 0:
        grad += 2 * κ * (φ_i - φm_i)

    # Clip to avoid φ_model explosion
    grad_norm = np.linalg.norm(grad)
    if grad_norm > grad_clip_threshold:
        grad *= grad_clip_threshold / (grad_norm + 1e-8)
        print(f"[CLIP ∇φ_model] Agent {agent_i.id}: ‖∇φ̃‖ clipped to {grad_clip_threshold:.1e}")

    return grad




