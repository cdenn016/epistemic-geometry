import numpy as np
from get_generators import get_generators
import config
from generalized_math_utils import sanitize_q

import numpy as np

def initialize_multivariate_gaussian_distribution(x_coords, mu_field, sigma_field, mask):
    """
    Initialize a multivariate Gaussian distribution over K fiber dimensions,
    using spatially varying mean (mu_field) and diagonal covariance (sigma_field).

    x_coords: shape (K, D_fiber) — fixed points in fiber space (e.g., R^K basis states)
    mu_field: shape (H, W, D_fiber) — spatial mean field
    sigma_field: shape (H, W, D_fiber) — spatial stddev field (diagonal covariance)
    mask: shape (H, W) — agent spatial support mask
    """
    H, W, D = mu_field.shape
    K = x_coords.shape[0]

    # Expand dimensions for broadcasting
    mu = mu_field[:, :, None, :]        # shape (H, W, 1, D)
    sigma = sigma_field[:, :, None, :]  # shape (H, W, 1, D)
    x = x_coords[None, None, :, :]      # shape (1, 1, K, D)

    # Compute squared Mahalanobis distances for each fiber point
    norm_sq = ((x - mu) / sigma) ** 2   # shape (H, W, K, D)
    exponent = -0.5 * np.sum(norm_sq, axis=-1)  # shape (H, W, K)

    # Apply mask
    mask_exp = mask[..., None]  # (H, W, 1)
    unnorm = np.exp(exponent) * mask_exp
    dist = unnorm / (np.sum(unnorm, axis=-1, keepdims=True) + 1e-8)  # normalize over K

    return dist

def get_fiber_basis(K: int) -> np.ndarray:
    """
    Return standard basis coordinates in fiber space ℝ^K.
    Output shape: (K, D_fiber) = (K, K)
    """
    return np.eye(K, dtype=np.float32)


def initialize_gaussian_distribution(x, mu_field, sigma_field, mask):
    mu = mu_field[..., None]
    sigma = sigma_field[..., None]
    unnorm = np.exp(-0.5 * ((x - mu) / sigma) ** 2)
    dist = unnorm / (np.sum(unnorm, axis=-1, keepdims=True) + 1e-8)
    dist *= mask[..., None]
    return dist


def initialize_uniform_distribution(x, mask=None, dtype=np.float32):
    """
    Create a uniform categorical distribution with shape (*spatial*, K),
    where spatial is inferred from `mask` if it exists, otherwise from `x`.
    """
    K = config.K

    if mask is not None:
        spatial_shape = mask.shape
    elif x is not None and x.ndim >= 2:
        spatial_shape = x.shape[:-1]
    else:
        spatial_shape = config.domain_size

    base = np.full((*spatial_shape, K), 1.0 / K, dtype=dtype)

    if mask is not None:
        base = base * mask[..., None]

    return base


def initialize_exponential_distribution(x, lambda_field, mask):
    lambda_ = lambda_field[..., None]
    unnorm = np.exp(-lambda_ * x)
    dist = unnorm / (np.sum(unnorm, axis=-1, keepdims=True) + 1e-8)
    dist *= mask[..., None]
    return dist


def initialize_beta_like_distribution(x, alpha_field, beta_field, mask):
    K = x.shape[-1]
    x_scaled = (x - x.min()) / (x.max() - x.min() + 1e-8)
    alpha = alpha_field[..., None]
    beta = beta_field[..., None]

    unnorm = (x_scaled ** (alpha - 1)) * ((1 - x_scaled) ** (beta - 1))
    dist = unnorm / (np.sum(unnorm, axis=-1, keepdims=True) + 1e-8)
    dist *= mask[..., None]
    return dist


def initialize_bimodal_gaussian_distribution(x, mu1_field, sigma1_field, mu2_field, sigma2_field, weight_field, mask):
    mu1 = mu1_field[..., None]
    sigma1 = sigma1_field[..., None]
    mu2 = mu2_field[..., None]
    sigma2 = sigma2_field[..., None]
    w = weight_field[..., None]

    g1 = np.exp(-0.5 * ((x - mu1) / sigma1) ** 2)
    g2 = np.exp(-0.5 * ((x - mu2) / sigma2) ** 2)

    unnorm = w * g1 + (1 - w) * g2
    dist = unnorm / (np.sum(unnorm, axis=-1, keepdims=True) + 1e-8)
    dist *= mask[..., None]
    return dist


def initialize_custom_distribution(x, mu_field, sigma_field, mask):
    raise NotImplementedError("Custom distribution initialization not implemented.")


def initialize_distribution(basis, mu_field, sigma_field, mask, family):
    """
    Construct K-dimensional distribution at each point from mu and sigma fields,
    then apply soft mask (e.g. 0 outside of support), and normalize across fiber.
    """
    K = mu_field.shape[-1]
    shape = mu_field.shape[:-1] + (K,)
    q = np.zeros(shape, dtype=mu_field.dtype)

    for k in range(K):
        μ = mu_field[..., k]
        σ = sigma_field[..., k]
        q[..., k] = np.exp(-0.5 * ((k - μ)**2 / σ**2))  # ← corrected line

    q = sanitize_q(q)
    q *= mask[..., None]  # apply support mask
    return q

