import numpy as np
import config
from scipy.linalg import expm
from generalized_math_utils import sanitize_q
import numpy as np
from scipy.linalg import expm
from joblib import Parallel, delayed
from joblib import Parallel, delayed
import numpy as np
import config  # for config.num_cores or set n_jobs manually
from joblib import Parallel, delayed, parallel_backend

_EPS = config.log_eps


def transport_covariance_batch(Sigma, Omega):
    """
    Transport a batch of covariance matrices: Σ → Ω Σ Ωᵀ

    Parameters:
        Sigma: (N, K, K) — batch of covariance matrices
        Omega: (N, K, K) — batch of transport operators

    Returns:
        Sigma_t: (N, K, K) — transported covariances
    """
    return np.einsum("nij,njk,nlk->nil", Omega, Sigma, Omega)


def repair_if_forgotten(q: np.ndarray, eps: float, threshold: float = 1e-6) -> np.ndarray:
   
    total_mass = np.sum(q)
    if total_mass < threshold or not np.isfinite(total_mass):
        K = q.shape[-1]
        q = np.random.dirichlet(np.ones(K)) * eps * K
    else:
        q = np.clip(q, eps, 1.0)
        q /= np.sum(q) + eps
    return q

def compute_inter_agent_omega(
    phi_i: np.ndarray,
    phi_j: np.ndarray,
    coord: tuple[int, ...],
    generators: np.ndarray,
    use_commutator: bool = False,
    phi_key: str = "phi",
) -> np.ndarray:
   
    from config import e_belief, e_model
    e = e_belief if phi_key == "phi" else e_model

    # 1) Extract the Lie-algebra vectors at coord
    φi_vec = phi_i[coord] / e
    φj_vec = phi_j[coord] / e

    # 2) Delegate to central helper
    Ω = build_inter_agent_omega(
        φi_vec[None],       # shape (1, d)
        φj_vec[None],       # shape (1, d)
        generators,
        config=config,
        use_commutator=use_commutator
    )  # returns shape (1, K, K)

    return Ω[0]

def repair_if_forgotten_batch(q: np.ndarray, eps: float, threshold: float = 1e-6) -> np.ndarray:
   
    q = np.nan_to_num(q, nan=0.0, posinf=0.0, neginf=0.0)
    orig_shape = q.shape
    K = q.shape[-1]
    q_flat = q.reshape(-1, K)
    norms = np.sum(q_flat, axis=-1, keepdims=True)

    forgotten = (norms < threshold) | (~np.isfinite(norms))

    if np.any(forgotten):
        n_forgotten = np.sum(forgotten)
        repaired = np.random.dirichlet(np.ones(K), size=n_forgotten) * eps * K
        q_flat[forgotten.squeeze()] = repaired

    q_flat = np.clip(q_flat, eps, 1.0)
    q_flat /= np.sum(q_flat, axis=-1, keepdims=True) + eps
    return q_flat.reshape(orig_shape)


def adaptive_expm(G, clip_norm=None, max_norm = None):
   
    norm_G = np.linalg.norm(G)
    if clip_norm is not None and norm_G > clip_norm:
        G = G * (clip_norm / norm_G)
    return expm(G)


def exp_lie_algebra_operator(
    v,
    generators,
    use_expm=True,
    threshold=1e-3,
    max_norm=20,
    group_name=None,  # 'so3', 'sl2r', 'su2', etc.
):
    """
    Compute exp(Σ_a v_a T_a) for arbitrary Lie algebra representation.

    Parameters:
    - v: np.ndarray shape (dim_G,), Lie algebra coefficients
    - generators: np.ndarray shape (dim_G, K, K), generators for Lie algebra rep
    - use_expm: bool, use scipy expm for large norms
    - threshold: float, norm threshold below which to use Taylor approx
    - max_norm: float, max allowed norm to prevent blowup
    - group_name: str or None, optionally specify to apply group-specific handling

    Returns:
    - np.ndarray (K, K): the group element exp(Σ vᵃ Tₐ)
    """
    norm_v = np.linalg.norm(v)
    eps = 1e-16
    safe_norm = norm_v + eps

    scale = min(1.0, max_norm / safe_norm)
    v_scaled = v * scale

    G = np.einsum('a,aij->ij', v_scaled, generators)

    # === SO(3)-specific antisymmetrization for numerical stability ===
    if group_name == "so3":
        G = 0.5 * (G - G.T)

    if safe_norm < threshold or not use_expm:
        I = np.eye(G.shape[0], dtype=G.dtype)
        return I + G + 0.5 * (G @ G)
    else:
        return expm(G)



def exp_lie_algebra_irrep(
    v,
    generators,
    use_expm=True,
    threshold=1e-3,
    max_norm=20,
    group_name=None,
    n_jobs=-1  # parallelize across available CPUs
):
    """
    Parallelized version of exp(Σ v_a T_a) using joblib.
    """
    norm_v = np.linalg.norm(v, axis=-1)
    eps = 1e-16
    safe = norm_v[..., None] + eps

    # Clamp large-norm vectors
    scale = np.where(norm_v[..., None] > max_norm, max_norm / safe, 1.0)
    v_scaled = v * scale

    # Contract Lie algebra element: (..., a) x (a, K, K) → (..., K, K)
    G = np.einsum('...a,aij->...ij', v_scaled, generators)

    # Group-specific antisymmetrization
    if group_name == "so3":
        G = 0.5 * (G - np.swapaxes(G, -1, -2))
    elif group_name == "su2":
        G = 0.5 * (G - np.swapaxes(G, -1, -2).conj())

    # Preallocate result array
    result = np.empty_like(G)
    approx_mask = norm_v < threshold

    # Fast Taylor expansion for small-norm elements
    if np.any(approx_mask):
        I = np.eye(G.shape[-1], dtype=G.dtype)
        G_approx = G[approx_mask]
        G2 = G_approx @ G_approx
        result[approx_mask] = I + G_approx + 0.5 * G2

    # Heavy expm for the rest — use parallelism
    if np.any(~approx_mask):
        idxs = np.nonzero(~approx_mask)[0]
        G_heavy = [G[i] for i in idxs]

        # Parallel matrix exponentials
        expm_results = Parallel(n_jobs=n_jobs, backend = "threading")(
            delayed(expm)(G_i) for G_i in G_heavy
        )

        for i, res in zip(idxs, expm_results):
            result[i] = res

    return result



from joblib import Parallel, delayed
import numpy as np
from scipy.linalg import expm

def batch_exp_lie_algebra_irrep(
    v_batch,
    generators,
    use_expm=True,
    threshold=1e-3,
    max_norm=20,
    group_name=None,
    n_jobs=-1  # Optional parallelism for large-norm cases
):
    """
    Compute batch of exp(sum_a v[a] * T_a) using Taylor or expm depending on norm.

    Parameters:
    - v_batch: (..., dim_G) Lie algebra coefficients
    - generators: (dim_G, K, K) Lie algebra generators
    - use_expm: use adaptive_expm or scipy.expm for large-norm cases
    - threshold: Taylor cutoff for small norms
    - max_norm: clamp large-norm vectors
    - group_name: (optional) cleanup: "so3", "su2", etc.
    - n_jobs: parallel jobs for large-norm exponentials

    Returns:
    - (..., K, K): batch of exponentiated matrices
    """

    # Fallback definition if adaptive_expm is not available
    def adaptive_expm(A, **kwargs):
        return expm(A)

    *batch_shape, dim_G = v_batch.shape
    v_flat = v_batch.reshape(-1, dim_G)
    N = v_flat.shape[0]
    _, K, _ = generators.shape
    dtype = v_batch.dtype

    # --- Normalize ---
    norms = np.linalg.norm(v_flat, axis=1)
    eps = 1e-16
    scale_factors = np.minimum(1.0, max_norm / (norms + eps))
    v_scaled = v_flat * scale_factors[:, None]

    # --- Construct algebra elements ---
    G_batch = np.einsum("na,aij->nij", v_scaled, generators)

    # --- Group-specific antisymmetrization ---
    if group_name == "so3":
        G_batch = 0.5 * (G_batch - np.transpose(G_batch, axes=(0, 2, 1)))
    elif group_name == "su2":
        G_batch = 0.5 * (G_batch - np.transpose(G_batch, axes=(0, 2, 1)).conj())

    # --- Initialize result buffer ---
    result = np.empty((N, K, K), dtype=dtype)
    approx_mask = norms * scale_factors < threshold

    # --- Taylor expansion for small-norm matrices ---
    if np.any(approx_mask):
        G_approx = G_batch[approx_mask]
        I = np.eye(K, dtype=dtype)[None, :, :]
        G2 = G_approx @ G_approx
        result[approx_mask] = I + G_approx + 0.5 * G2

    # --- Parallel expm fallback for large-norm matrices ---
    if np.any(~approx_mask):
        idxs = np.flatnonzero(~approx_mask)
        G_heavy = [G_batch[i] for i in idxs]

        expm_results = Parallel(n_jobs=n_jobs, backend="threading")(
            delayed(adaptive_expm)(G) for G in G_heavy
        )

        for i, res in zip(idxs, expm_results):
            result[i] = res

    return result.reshape(*batch_shape, K, K)


def batch_apply_omega(mu_batch, sigma_batch, omega_batch, n_jobs=None, parallel_threshold=1000):
    """
    Applies the linear transformation Ω to either:
      - both mean vectors and covariance matrices:
            μ' = Ω μ
            Σ' = Ω Σ Ωᵀ
      - or just to vectors μ: μ' = Ω μ  (if sigma_batch is None)

    Input shapes:
      - mu_batch:     (..., K)
      - sigma_batch:  (..., K, K) or None
      - omega_batch:  (..., K, K)

    Returns:
      - if sigma_batch is not None:
          (mu_transformed, sigma_transformed)
      - else:
          mu_transformed
    """
    mu_t = np.einsum("...ij,...j->...i", omega_batch, mu_batch)

    if sigma_batch is None:
        return mu_t

    sigma_t = omega_batch @ sigma_batch @ np.transpose(omega_batch, (0, 2, 1))

    return mu_t, sigma_t





def _apply_single_omega(q, omega):
    return omega @ q



def batch_apply_omega_parallel(q_batch, omega_batch, n_jobs=None):
    """
    Parallel version of batch_apply_omega using joblib with threading backend.

    Args:
        q_batch: [..., K] array of belief vectors
        omega_batch: [..., K, K] array of group matrices
        n_jobs: Number of parallel jobs (defaults to config.num_cores)

    Returns:
        Transformed batch: [..., K]
    """
    assert q_batch.shape == omega_batch.shape[:-1], (
        f"Mismatch: q_batch {q_batch.shape} vs omega_batch {omega_batch.shape}"
    )

    n_jobs = n_jobs or config.num_cores
    flat_q = q_batch.reshape(-1, q_batch.shape[-1])
    flat_omega = omega_batch.reshape(-1, omega_batch.shape[-2], omega_batch.shape[-1])

    with parallel_backend("threading"):
        results = Parallel(n_jobs=n_jobs)(
            delayed(_apply_single_omega)(q, ω) for q, ω in zip(flat_q, flat_omega)
        )

    return np.stack(results).reshape(q_batch.shape)


def apply_omega(q_vec, omega):
    """
    Apply a single group matrix Ω to a belief vector or batch of vectors q_vec.

    Args:
        q_vec: np.ndarray with shape (K,) or (..., K)
        omega: np.ndarray with shape (K, K)

    Returns:
        Transformed vector(s) with shape same as q_vec
    """
    assert omega.shape[0] == omega.shape[1], "Omega must be square"
    assert q_vec.shape[-1] == omega.shape[0], (
        f"Dimension mismatch: q_vec last dim {q_vec.shape[-1]} != omega shape {omega.shape}"
    )

    # Contract last dim of q_vec with omega
    return np.einsum('ij,...j->...i', omega, q_vec)

def compute_spatial_gradient_matrix_field(A_field, axis=0):
    grad = np.zeros_like(A_field)
    axis_size = A_field.shape[axis]
    edge_order = 2 if axis_size >= 3 else 1  # robustly handle small grid sizes
    
    for i in range(A_field.shape[-2]):
        for j in range(A_field.shape[-1]):
            grad[..., i, j] = np.gradient(A_field[..., i, j], axis=axis, edge_order=edge_order)
    return grad



def compute_gauge_potential(phi):
    """
    Compute gauge potentials A_μ^a = ∂_μ φ^a for arbitrary Lie algebra and base dimension D.
        BE CAREFUL! CANNOT PASS THIS OUTPUT INTO COMMUTATOR WITHOUT CONVERTING
    Args:
        phi: np.ndarray, shape (..., d), where
             ... represents spatial dimensions (S_1,...,S_D),
             d = dim Lie algebra.

    Returns:
        A: tuple of length D, each entry np.ndarray of shape (..., d),
           spatial derivatives of phi along each base manifold dimension.
    """
    D = phi.ndim - 1  # subtract Lie algebra dimension axis
    spatial_axes = tuple(range(D))
    A = tuple(np.gradient(phi, axis=axis) for axis in spatial_axes)
    return A


def compute_commutator(A_mu, A_nu):
    """
    Compute matrix commutator [A_μ, A_ν] = A_μ A_ν - A_ν A_μ for batch matrices.

    Args:
        A_mu, A_nu: np.ndarray with shape (..., K, K)

    Returns:
        commutator: np.ndarray with shape (..., K, K)
    """
    return np.matmul(A_mu, A_nu) - np.matmul(A_nu, A_mu)




def compute_field_strength(phi, generators):
    """
    Computes F_{μν} = ∂_μ A_ν - ∂_ν A_μ + [A_μ, A_ν], where A_μ = ∂_μ φ^a G_a
    """
    D = phi.ndim - 1  # spatial dimensions
    A_mu_coeffs = [np.gradient(phi, axis=mu) for mu in range(D)]  # (..., d)
    
    
    A_matrices = [np.einsum('...a,aij->...ij', coeffs, generators) for coeffs in A_mu_coeffs]

    # Now project ∂_μ φ^a onto matrix-valued A_μ = ∂_μ φ^a · G_a
    A_matrices = [np.einsum('...a,aij->...ij', coeffs, generators) for coeffs in A_mu_coeffs]

    curvature_norms = {}
    for mu in range(D):
        for nu in range(mu + 1, D):
            # Derivatives of matrix-valued A_ν along μ, etc
            dA_nu_dmu = compute_spatial_gradient_matrix_field(A_matrices[nu], axis=mu)
            dA_mu_dnu = compute_spatial_gradient_matrix_field(A_matrices[mu], axis=nu)


            # Matrix commutator [A_μ, A_ν]
            comm = compute_commutator(A_matrices[mu], A_matrices[nu])

            # Final curvature
            F_munu = dA_nu_dmu - dA_mu_dnu + comm

            # Frobenius norm per spatial point
            curvature_norms[(mu, nu)] = np.linalg.norm(F_munu, axis=(-2, -1))

    return curvature_norms


def build_inter_agent_omega(phi_i, phi_j, generators, config=None, use_commutator=False):
    """
    Compute the inter-agent gauge transport operator field Ω_{ij}(x).

    Parameters:
        phi_i: np.ndarray shape (..., d) — φ_i field over spatial domain
        phi_j: np.ndarray shape (..., d) — φ_j field over spatial domain
        generators: np.ndarray shape (d, K, K) — Lie algebra generators
        config: optional config object to override use_commutator
        use_commutator: bool —
            if False, do non-abelian exp(φ_i) @ exp(-φ_j);
            if True,  do abelian exp(φ_i - φ_j)

    Returns:
        omega_ij: np.ndarray shape (..., K, K) — inter-agent transport operator
    """
    # allow config to override the flag
    if config is not None:
        use_commutator = getattr(config, "use_commutator", use_commutator)

    # difference field (..., d)
    delta = phi_i - phi_j

    if not use_commutator:
        # non-abelian: exp(φ_i) @ exp(-φ_j)
        g_i     = exp_lie_algebra_irrep(phi_i, generators, group_name=getattr(config, "group_name", None))
        g_j_inv = exp_lie_algebra_irrep(-phi_j, generators, group_name=getattr(config, "group_name", None))
        return np.matmul(g_i, g_j_inv)

    # abelian shortcut: exp(φ_i - φ_j)
    return exp_lie_algebra_irrep(delta, generators, group_name=getattr(config, "group_name", None))



def compute_pairwise_kl(agents, generators, params, return_pointwise=False):
    from generalized_diagnostics_metrics import kl_divergence
    from generalized_omega import transport_covariance_batch

    log_eps = params.get("log_eps", 1e-8)
    overlap_eps = params.get("overlap_eps", 1e-6)
    N = len(agents)
    kl_matrix = np.full((N, N), np.inf)
    pointwise = {} if return_pointwise else None

    for i in range(N):
        A = agents[i]
        mu_i = A.mu_q_field
        sigma_i = A.sigma_q_field
        mask_i = A.mask > overlap_eps

        for j in range(N):
            if i == j:
                kl_matrix[i, j] = 0.0
                continue

            B = agents[j]
            mu_j = B.mu_q_field
            sigma_j = B.sigma_q_field
            mask_j = B.mask > overlap_eps

            overlap = mask_i & mask_j
            if not np.any(overlap):
                continue

            # Get transported μ_j and Σ_j at overlap
            Omega_ij = build_inter_agent_omega(
                phi_i = A.phi[overlap],
                phi_j = B.phi[overlap],
                generators = generators,
                config = params
            )  # (M, K, K)

            mu_j_ov = mu_j[overlap]                     # (M, K)
            sigma_j_ov = sigma_j[overlap]               # (M, K, K)
            mu_j_t = np.einsum("mab,mb->ma", Omega_ij, mu_j_ov)
            sigma_j_t = transport_covariance_batch(sigma_j_ov, Omega_ij)

            mu_i_ov = mu_i[overlap]
            sigma_i_ov = sigma_i[overlap]

            kl_vals = kl_divergence(mu_i_ov, sigma_i_ov, mu_j_t, sigma_j_t, eps=log_eps)
            kl_matrix[i, j] = float(np.mean(kl_vals))

            if return_pointwise:
                pw_field = np.zeros(mask_i.shape)
                pw_field[overlap] = kl_vals
                pointwise[(i, j)] = pw_field

    return (kl_matrix, pointwise) if return_pointwise else kl_matrix


def compute_pairwise_model_kl(agents, generators, params, return_pointwise=False):
    from generalized_diagnostics_metrics import kl_divergence
    from generalized_omega import transport_covariance_batch

    log_eps = params.get("log_eps", 1e-8)
    overlap_eps = params.get("overlap_eps", 1e-6)
    N = len(agents)
    kl_matrix = np.full((N, N), np.inf)
    pointwise = {} if return_pointwise else None

    for i in range(N):
        A = agents[i]
        mu_i = A.mu_p_field
        sigma_i = A.sigma_p_field
        mask_i = A.mask > overlap_eps

        for j in range(N):
            if i == j:
                kl_matrix[i, j] = 0.0
                continue

            B = agents[j]
            mu_j = B.mu_p_field
            sigma_j = B.sigma_p_field
            mask_j = B.mask > overlap_eps

            overlap = mask_i & mask_j
            if not np.any(overlap):
                continue

            # Get transported μ_j and Σ_j under φ_model
            Omega_ij = build_inter_agent_omega(
                phi_i = A.phi_model[overlap],
                phi_j = B.phi_model[overlap],
                generators = generators,
                config = params
            )  # (M, K, K)

            mu_j_ov = mu_j[overlap]
            sigma_j_ov = sigma_j[overlap]
            mu_j_t = np.einsum("mab,mb->ma", Omega_ij, mu_j_ov)
            sigma_j_t = transport_covariance_batch(sigma_j_ov, Omega_ij)

            mu_i_ov = mu_i[overlap]
            sigma_i_ov = sigma_i[overlap]

            kl_vals = kl_divergence(mu_i_ov, sigma_i_ov, mu_j_t, sigma_j_t, eps=log_eps)
            kl_matrix[i, j] = float(np.mean(kl_vals))

            if return_pointwise:
                pw_field = np.zeros(mask_i.shape)
                pw_field[overlap] = kl_vals
                pointwise[(i, j)] = pw_field

    return (kl_matrix, pointwise) if return_pointwise else kl_matrix

import numpy as np

import numpy as np

def compute_pairwise_Omega(phi_i, phi_j, mask_i, mask_j, log_eps, n_jobs, generators):
    """
    Computes Omega_ij(c) = exp(phi_i(c)) @ exp(-phi_j(c)) at all points in the overlap mask.

    Returns:
        Omega_ij   : array of shape (H, W, K, K)
        Omega_ij⁻¹ : array of shape (H, W, K, K)
    """
    # Ensure masks are boolean
    mask_i = mask_i.astype(bool)
    mask_j = mask_j.astype(bool)
    overlap = mask_i & mask_j

    if not np.any(overlap):
        shape = (*mask_i.shape, generators.shape[1], generators.shape[1])
        return np.zeros(shape), np.zeros(shape)

    # Extract phi_i and phi_j on the overlap
    phi_i_overlap = phi_i[overlap]
    phi_j_overlap = phi_j[overlap]

    # Exponentiate Lie algebra elements
    exp_phi_i = exp_lie_algebra_irrep(phi_i_overlap, generators, n_jobs=n_jobs)
    exp_neg_phi_j = exp_lie_algebra_irrep(-phi_j_overlap, generators, n_jobs=n_jobs)

    # Compute Omega = exp(phi_i) · exp(-phi_j)
    Omega_ij = np.einsum("...ij,...jk->...ik", exp_phi_i, exp_neg_phi_j)

    # Compute true matrix inverse for general Lie group
    Omega_inv = np.linalg.inv(Omega_ij)

    # Fill into full (H, W, K, K) arrays
    full_shape = (*mask_i.shape, generators.shape[1], generators.shape[1])
    Omega_full     = np.zeros(full_shape)
    Omega_inv_full = np.zeros(full_shape)

    Omega_full[overlap]     = Omega_ij
    Omega_inv_full[overlap] = Omega_inv

    return Omega_full, Omega_inv_full



def get_all_Omega_fields(agents, phi_belief_field, phi_model_field, mask_field, log_eps, n_jobs, generators):
    """
    Compute all belief and model Ω_{ij} and their inverses, per point and per pair (i, j).
    Returns 4 lists: Ω_bel, Ω_bel⁻¹, Ω_model, Ω_model⁻¹, each of length N.
    """
    from generalized_omega import compute_pairwise_Omega

    N = len(agents)
    O_bel, O_inv, O_mod, O_mod_inv = [], [], [], []

    for i, A in enumerate(agents):
        phi_i_bel  = getattr(A, phi_belief_field)
        phi_i_mod  = getattr(A, phi_model_field)
        mask_i     = getattr(A, mask_field)

        Omega_bel_i, Omega_inv_bel_i = {}, {}
        Omega_mod_i, Omega_inv_mod_i = {}, {}

        for nb in A.neighbors:
            j = nb["id"]
            B = agents[j]

            phi_j_bel = getattr(B, phi_belief_field)
            phi_j_mod = getattr(B, phi_model_field)
            mask_j    = getattr(B, mask_field)

            Omega_bel, Omega_bel_inv = compute_pairwise_Omega(
                phi_i_bel, phi_j_bel, mask_i, mask_j, log_eps, n_jobs, generators
            )
            Omega_mod, Omega_mod_inv = compute_pairwise_Omega(
                phi_i_mod, phi_j_mod, mask_i, mask_j, log_eps, n_jobs, generators
            )

            Omega_bel_i[j]     = Omega_bel
            Omega_inv_bel_i[j] = Omega_bel_inv
            Omega_mod_i[j]     = Omega_mod
            Omega_inv_mod_i[j] = Omega_mod_inv

        O_bel.append(Omega_bel_i)
        O_inv.append(Omega_inv_bel_i)
        O_mod.append(Omega_mod_i)
        O_mod_inv.append(Omega_inv_mod_i)

    return O_bel, O_inv, O_mod, O_mod_inv

