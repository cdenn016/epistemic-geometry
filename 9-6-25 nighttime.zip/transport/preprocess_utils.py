# -*- coding: utf-8 -*-
"""
Created on Mon Aug 11 16:05:57 2025

@author: chris and christine
"""

import numpy as np
from core.get_generators import get_generators              
from typing import Optional
from transport.bundle_morphism_utils import build_intertwiner_bases, _rescale_pair_fro
import core.config as config
from core.numerical_utils import sanitize_sigma, safe_inv  



def ensure_transforms(
    targets,
    generators_q=None,
    generators_p=None,
    *,
    ctx=None,
    intertwiner_method="casimir",    # "casimir" | "auto" | "nullspace"
    data_for_alignment=None,
    fro_target: float | None = None,
):
    import numpy as np
    if not targets:
        return
    if ctx is None:
        raise RuntimeError("ensure_transforms: ctx is required (cache-centric design)")

    # LAZY imports to avoid circular import at module import time
    from transport.transport_cache import set_morphism_bases as _set_bases  # <— your import error was here

    for a in targets:
        if a is None:
            continue

        # infer sizes (kept for validation / potential future checks)
        Kq = int(np.asarray(a.mu_q_field).shape[-1])
        Kp = int(np.asarray(a.mu_p_field).shape[-1])

        # effective generators (prefer explicit args; otherwise agent-attached)
        Gq_eff = generators_q if generators_q is not None else getattr(a, "generators_q", None)
        Gp_eff = generators_p if generators_p is not None else getattr(a, "generators_p", None)
        if Gq_eff is None or Gp_eff is None:
            raise ValueError("ensure_transforms: generators_q/generators_p must be provided or attached to each agent beforehand")
        Gq_eff = np.asarray(Gq_eff, np.float32)
        Gp_eff = np.asarray(Gp_eff, np.float32)
        if Gq_eff.shape != (3, Kq, Kq):
            raise ValueError(f"ensure_transforms: generators_q shape mismatch: {(3,Kq,Kq)} vs {Gq_eff.shape}")
        if Gp_eff.shape != (3, Kp, Kp):
            raise ValueError(f"ensure_transforms: generators_p shape mismatch: {(3,Kp,Kp)} vs {Gp_eff.shape}")

        # --- build geometric bases once for these gens ---
        Phi0, Phit0, meta = build_intertwiner_bases(
            Gq_eff,
            Gp_eff,
            method=str(intertwiner_method),
            data=data_for_alignment,
            return_meta=True,
        )

        # --- optional coherent Frobenius rescale ---
        Phi0, Phit0, _ = _rescale_pair_fro(Phi0, Phit0, fro_target)

        # --- persist in central cache; do not write to agent attributes ---
        try:
            _set_bases(ctx, a, np.asarray(Phi0, np.float32), np.asarray(Phit0, np.float32), allow_overwrite=False)
        except TypeError:
            _set_bases(ctx, a, np.asarray(Phi0, np.float32), np.asarray(Phit0, np.float32))








# ---------------------------------------------------------------------
# Public entry points
# ---------------------------------------------------------------------

def preprocess_all_agents(agents, params=None, G_q=None, G_p=None, *, ctx: Optional[object] = None):
    """
    Build/refresh: generators, Σ sanitize + inverses, condition proxies,
    (optionally) Fisher. Also pre-warms exp grids via transport cache.
    Safe to call repeatedly; idempotent per step.
    """
    params = params or {}
    if ctx is not None:
        params = dict(params)
        params["runtime_ctx"] = ctx

    agents = [a for a in (agents or []) if a is not None]
    if not agents:
        return

    # preprocess structural fields per agent
    for a in agents:
        preprocess_agent_fields(a, params, G_q=G_q, G_p=G_p, ctx=ctx)





# ---------------------------------------------------------------------
# Per-agent preprocessing
# ---------------------------------------------------------------------
def preprocess_agent_fields(agent, params=None, G_q=None, G_p=None, *, ctx: Optional[object] = None):
    """
    Prepare per-agent fields (generators, Σ sanitize/inv, cond proxies, Fisher).
    NOTE: No transport pre-warming here (E/Jinv/Ω). That is handled centrally by ensure_dirty(...).
    """
    import numpy as np
    import core.config as config
    from core.get_generators import get_generators
    from core.numerical_utils import sanitize_sigma, safe_inv

    params     = params or {}
    eps        = float(getattr(config, "eps", 1e-8))
    group_name = str(getattr(config, "group_name", "so3"))
    strict     = bool(params.get("sanitize_strict", True))
    step_tag   = int(params.get("step", getattr(ctx, "global_step", -1) or -1))

    # idempotency per step
    if getattr(agent, "_preprocessed_step", None) == step_tag and step_tag >= 0:
        return

    # infer sizes & ensure mask
    try:
        Kq = int(np.asarray(agent.mu_q_field).shape[-1])
        Kp = int(np.asarray(agent.mu_p_field).shape[-1])
    except Exception as e:
        raise ValueError("preprocess_agent_fields: agent.mu_q_field / mu_p_field missing or malformed") from e

    if not hasattr(agent, "mask") or agent.mask is None:
        H, W = agent.mu_q_field.shape[:2]
        agent.mask = np.ones((H, W), np.float32)

    # ---------------- Generators (attach once; NEVER mutate after freeze) ----------------
    gens_frozen = bool(getattr(agent, "_gens_frozen", False))

    if gens_frozen:
        # If caller tries to pass new arrays after freeze, hard-error to avoid drift.
        if G_q is not None and not np.array_equal(np.asarray(G_q, np.float32), np.asarray(agent.generators_q, np.float32)):
            raise RuntimeError("Attempt to change generators_q after freeze.")
        if G_p is not None and not np.array_equal(np.asarray(G_p, np.float32), np.asarray(agent.generators_p, np.float32)):
            raise RuntimeError("Attempt to change generators_p after freeze.")

        # Shapes must still match Kq/Kp
        if getattr(agent, "generators_q", None) is None or agent.generators_q.shape != (3, Kq, Kq):
            raise ValueError(f"frozen generators_q shape mismatch: expected (3,{Kq},{Kq})")
        if getattr(agent, "generators_p", None) is None or agent.generators_p.shape != (3, Kp, Kp):
            raise ValueError(f"frozen generators_p shape mismatch: expected (3,{Kp},{Kp})")

    else:
        # First-time attach/build (the ONLY time we allow mutation/sanitization)
        if G_q is not None:
            agent.generators_q = np.asarray(G_q, dtype=np.float32)
        if G_p is not None:
            agent.generators_p = np.asarray(G_p, dtype=np.float32)

        if getattr(agent, "generators_q", None) is None:
            if (group_name.lower() == "so3") and (Kq % 2 == 0):
                raise ValueError(
                    f"SO(3) generators for K_q={Kq} require a reducible spec/array; "
                    "attach agent.generators_q or pass G_q to preprocess_agent_fields."
                )
            agent.generators_q = np.asarray(get_generators(group_name, Kq), dtype=np.float32)

        if getattr(agent, "generators_p", None) is None:
            if (group_name.lower() == "so3") and (Kp % 2 == 0):
                raise ValueError(
                    f"SO(3) generators for K_p={Kp} require a reducible spec/array; "
                    "attach agent.generators_p or pass G_p to preprocess_agent_fields."
                )
            agent.generators_p = np.asarray(get_generators(group_name, Kp), dtype=np.float32)

        # Validate shapes
        if agent.generators_q.shape != (3, Kq, Kq):
            raise ValueError(f"generators_q shape mismatch: expected (3,{Kq},{Kq}), got {agent.generators_q.shape}")
        if agent.generators_p.shape != (3, Kp, Kp):
            raise ValueError(f"generators_p shape mismatch: expected (3,{Kp},{Kp}), got {agent.generators_p.shape}")

        # Optional: enforce exact antisymmetry ONCE (before freezing)
        if bool(getattr(config, "sanitize_generators", False)):
            def _antisym(G):
                G = np.asarray(G, np.float32)
                return 0.5 * (G - np.swapaxes(G, -1, -2))
            agent.generators_q = _antisym(agent.generators_q)
            agent.generators_p = _antisym(agent.generators_p)

        # Freeze so later calls cannot change them implicitly
        agent._gens_frozen = True

    # ---------------- SPD sanitize & inverses ----------------
    agent.sigma_q_field = sanitize_sigma(agent.sigma_q_field, strict=strict, eps=eps)
    agent.sigma_p_field = sanitize_sigma(agent.sigma_p_field, strict=strict, eps=eps)
    agent.sigma_q_inv   = safe_inv(agent.sigma_q_field, eps=eps)
    agent.sigma_p_inv   = safe_inv(agent.sigma_p_field, eps=eps)

    # ---------------- Fisher (optional precompute; do NOT force transport warm) ----------------
    enable_fisher = bool(params.get("enable_fisher_precompute",
                          getattr(config, "enable_fisher_precompute", True)))
    if ctx is not None and enable_fisher:
        try:
            # lazy + fully qualified to avoid circulars when refactoring
            from transport.transport_cache import Fisher_blocks  # type: ignore
            Fq = Fisher_blocks(ctx, agent, which="q")
            Fp = Fisher_blocks(ctx, agent, which="p")
            agent._precision_q = Fq.get("precision", None)
            agent._precision_p = Fp.get("precision", None)
        except Exception:
            agent._precision_q = None
            agent._precision_p = None
    else:
        agent._precision_q = None
        agent._precision_p = None

    # ---------------- optional SPD assert ----------------
    if bool(getattr(config, "assert_spd_after_sanitize", False)):
        wq = np.linalg.eigvalsh(0.5 * (agent.sigma_q_field + np.swapaxes(agent.sigma_q_field, -1, -2)))
        wp = np.linalg.eigvalsh(0.5 * (agent.sigma_p_field + np.swapaxes(agent.sigma_p_field, -1, -2)))
        floor = float(getattr(config, "sigma_eig_floor", 1e-6))
        if (wq <= floor).any() or (wp <= floor).any():
            raise RuntimeError("Non-SPD Σ after sanitize.")

    agent._preprocessed_step = step_tag





def zero_all_gradients(agent):
    """
    Zero (and if missing, create) all gradient buffers,
    keeping legacy aliases in sync and ensuring arrays are writeable.
    """
    def ensure_buf(name, like):
        arr = getattr(agent, name, None)
        if arr is None and like is not None:
            arr = np.zeros_like(like)
        elif arr is not None and not arr.flags.writeable:
            arr = np.array(arr, copy=True)
        setattr(agent, name, arr)
        return arr

    # Canonical grads (create from fields if needed)
    g_mu_q   = ensure_buf("grad_mu_q",    getattr(agent, "mu_q_field", None))
    g_sg_q   = ensure_buf("grad_sigma_q", getattr(agent, "sigma_q_field", None))
    g_mu_p   = ensure_buf("grad_mu_p",    getattr(agent, "mu_p_field", None))
    g_sg_p   = ensure_buf("grad_sigma_p", getattr(agent, "sigma_p_field", None))
    g_phi    = ensure_buf("grad_phi",       getattr(agent, "phi", None))
    g_phit   = ensure_buf("grad_phi_tilde", getattr(agent, "phi_model", None))


 
    # Keep legacy aliases in sync (as references, not copies)
    if g_mu_q is not None:
        agent.grad_mu_q_field = g_mu_q
    if g_sg_q is not None:
        agent.grad_sigma_q_field = g_sg_q
    if g_mu_p is not None:
        agent.grad_mu_p_field = g_mu_p
    if g_sg_p is not None:
        agent.grad_sigma_p_field = g_sg_p

    # Zero safely
    for arr in (g_mu_q, g_sg_q, g_mu_p, g_sg_p, g_phi, g_phit):
        if isinstance(arr, np.ndarray):
            arr.fill(0)



