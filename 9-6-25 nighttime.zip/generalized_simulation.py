# generalized_simulation.py
import os
os.environ["OMP_NUM_THREADS"] = "1"
os.environ["MKL_NUM_THREADS"] = "1"
os.environ["NUMEXPR_NUM_THREADS"] = "1"
os.environ["OPENBLAS_NUM_THREADS"] = "1"
import sys
ROOT = os.path.dirname(os.path.abspath(__file__))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

import sys, time, pickle
import core.config as config
import shutil, os
from updates.update_rules import synchronous_step
from run_sim_utils import (
    prepare_generators, merge_logging_cfg, initialize_or_resume,
    ensure_runtime, log_and_viz_after_step,
    wrap_epilogue, save_step
)



def run_simulation(
    outdir="checkpoints", 
    resume=False,
    log_metrics=True,
    log_fields=True,
    num_cores=None,
    params=None,
    fresh_outdir=False,
    clear_agent_logs=True,
):
    # outdir rotation + readme
    if not resume and fresh_outdir and os.path.isdir(outdir):
        ts = time.strftime("%Y%m%d_%H%M%S")
        shutil.move(outdir, f"{outdir}_old_{ts}")
    os.makedirs(outdir, exist_ok=True)

    # params + cores
    try:
        import multiprocessing as _mp
        _avail = max(1, (_mp.cpu_count() or 1) - 1)
    except Exception:
        _avail = 8

    num_cores = _avail if num_cores is None else int(num_cores)
    num_cores = max(1, num_cores)

    params = {} if params is None else dict(params)

    config.n_jobs = num_cores

    # generators
    G_q, G_p = prepare_generators(params)

    
    # Keep init paths consistent with the actual generators
    import numpy as np
    Kq, Kp = int(np.asarray(G_q).shape[1]), int(np.asarray(G_p).shape[1])
    config.K_q, config.K_p = Kq, Kp


    # logging cfg
    logcfg = merge_logging_cfg(params if isinstance(params, dict) else vars(config))
    if not log_metrics: logcfg["enable_scalar"] = False
    if not log_fields:  logcfg["enable_fields"] = False
    if logcfg.get("enable_fields", False):
        os.makedirs(os.path.join(outdir, logcfg["full_field_outdir"]), exist_ok=True)

    # init or resume
    agents, step_start = initialize_or_resume(outdir, resume, params, clear_agent_logs=clear_agent_logs)

    # runtime context (mounted lvl-1 view)
    runtime_ctx = ensure_runtime(params)
    runtime_ctx.global_step = step_start  # initialize step index
    params["runtime_ctx"] = runtime_ctx   # expose ctx via params for legacy helpers

    # Early-exit if resuming past the configured steps
    if step_start >= int(getattr(config, "steps", step_start)):
        wrap_epilogue(runtime_ctx, agents, outdir, [], [])
        print("[DONE] Nothing to do: resume step >= total steps.")
        return agents, []

    # trackers
    parent_metrics, metric_log = [], []
    print(f"[RUN] Starting simulation at step {step_start} with {num_cores if (num_cores is not None) else 'auto'} cores")

    for step in range(step_start, config.steps):
        # keep global_step in sync BEFORE core update so gates use it
        runtime_ctx.global_step = step
        runtime_ctx.dirty.reset_step(step)
                
        print(f"\n[STEP {step}] -----------------------------\n")
        t0 = time.perf_counter()
        step_params = {**params, "step": step, "sanitize_strict_pre": False}

        # core synchronous update (ctx is threaded inside)
        agents = synchronous_step(
            agents, G_q, G_p,
            params=step_params,
            n_jobs=num_cores,
            runtime_ctx=runtime_ctx,
        )

        print(f"[TIMER] synchronous update: {time.perf_counter() - t0:.3f}s")

        # --- cache stats probe every 5 steps ---
        try:
            if step % 1 == 0:
                tc = getattr(runtime_ctx, "cache", None)
                if tc is not None and hasattr(tc, "full_stats"):
                    print("[cache]", tc.full_stats())
        except Exception as e:
            print(f"[cache] stats probe failed: {e}")

        # viz & metrics
        runtime_ctx.children_latest = agents
        
        log_and_viz_after_step(runtime_ctx, agents, step, outdir, params, logcfg,
                               parent_metrics, metric_log, num_cores)
 
        save_step(agents, outdir, step)
        print(f"[SAVE] Checkpoint --> {outdir}/step_{step:04d}.pkl")

    # epilogue
    wrap_epilogue(runtime_ctx, agents, outdir, parent_metrics, metric_log)
    print("[DONE] Simulation completed.")
    return agents, metric_log






if __name__ == "__main__":
    
    from core.get_generators import make_reducible_generators, check_so3_relations

    # 1) optional param override for config
    if len(sys.argv) > 1:
        with open(sys.argv[1], "rb") as f:
            param_override = pickle.load(f)
        # assumes you have this helper; otherwise set fields on config directly
        try:
            from core.config import set_config_from_params
            set_config_from_params(param_override)
        except Exception:
            pass
    else:
        param_override = {}

    # 2) Build reducible SO(3) generators (examples)
    spec_q = [(3, 1)]  #E.G. [(1,2)] IS 3 ⊕ 3  -> K_q = 6 spec = [(ℓ₁, multiplicity₁), (ℓ₂, multiplicity₂), ...]
    spec_p = [(3, 1)]  # 5      -> K_p = 5

    G_q = make_reducible_generators(spec_q, mix=False)
    G_p = make_reducible_generators(spec_p, mix=False)

    ok_q, rq = check_so3_relations(G_q, return_resid=True)
    ok_p, rp = check_so3_relations(G_p, return_resid=True)
    print("ok?", ok_q, ok_p, "resid:", rq, rp)
    print("K_q=", G_q.shape[1], "K_p=", G_p.shape[1])



    # 3) Keep config in sync with the actual generator sizes
    config.K_q = int(G_q.shape[1])
    config.K_p = int(G_p.shape[1])

    # 4) Pass the *arrays themselves* into params so init uses them directly
    runtime_params = {
        "generators_q": G_q,
        "generators_p": G_p,
        "seed": getattr(config, "seed", 0),
    }

    
    # 5) Run
    run_simulation(
        outdir="checkpoints",
        resume=False,
        log_metrics=True,
        log_fields=True,
        params=runtime_params,
    )



