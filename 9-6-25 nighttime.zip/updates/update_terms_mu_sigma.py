# -*- coding: utf-8 -*-
"""
Created on Wed Aug  6 12:27:32 2025

@author: chris and christine
"""

# --- imports (top of file) ---
import numpy as np
import core.config as config
from core.numerical_utils import sanitize_sigma, safe_batch_inverse
from core.natural_gradient import apply_natural_gradient_batch
from transport.transport_cache import Omega, Phi
from core.gaussian_core import push_gaussian


# -------------------------------------------------------------------------
#                          PUBLIC ENTRYPOINTS
# -------------------------------------------------------------------------

def accumulate_mu_sigma_gradient(agent_i, agents, params, mode,
                                 *, strict_numerics: bool = True,
                                 recover: str | None = None):  # None | "nan" | "zero"
    """
    Accumulate natural gradient ∇μ and ∇Σ for belief or model using cache-owned Φ, Φ̃, Ω.
    Also accumulates alignment contributions into neighbors j for each term E_ij.
    (No rep-scale, no relative cap. Counts each undirected pair once.)
    """
    PRINT_SIGN = bool(params.get("DEBUG_MU_SIG", False))
    ctx = params.get("runtime_ctx", None)
    if ctx is None:
        if strict_numerics:
            raise RuntimeError("accumulate_mu_sigma_gradient: ctx required (cache-centric Φ/Ω).")
        # graceful recovery (no ctx): return zeros shaped like the active fiber
        if mode == "belief":
            return _zero_mu_sigma_like(agent_i.mu_q_field, agent_i.sigma_q_field)
        elif mode == "model":
            return _zero_mu_sigma_like(agent_i.mu_p_field, agent_i.sigma_p_field)
        else:
            raise ValueError(f"Unsupported mode: {mode}")

    eps         = float(getattr(config, "eps", 1e-8))
    support_eps = float(getattr(config, "support_cutoff_eps", 1e-4))

    # -------- select fields/weights by mode --------
    if mode == "belief":
        alpha  = float(params.get("alpha",           getattr(config, "alpha",           1.0)))
        beta   = float(params.get("beta",            getattr(config, "beta",            0.0)))
        lambd  = float(params.get("feedback_weight", getattr(config, "feedback_weight", 0.0)))

        mu_q,  sigma_q  = agent_i.mu_q_field, agent_i.sigma_q_field
        mu_p,  sigma_p  = agent_i.mu_p_field, agent_i.sigma_p_field

        # Φ, Φ̃ from cache
        Phi_mat       = Phi(ctx, agent_i, kind="q_to_p")
        Phi_tilde_mat = Phi(ctx, agent_i, kind="p_to_q")

        # push via Φ̃ and Φ
        mu_p_push, sigma_p_push, sigma_p_push_inv = push_gaussian(
            mu=mu_p, Sigma=sigma_p, M=Phi_tilde_mat, eps=eps,
            symmetrize=True, sanitize=True,
            approx="auto" if getattr(config, "use_first_order_sigma_push", True) else "exact",
            near_identity_tau=float(getattr(config, "lambda_near_identity_tau", 5e-2)),
            return_inv=True,
        )
        mu_q_push, sigma_q_push, sigma_q_push_inv = push_gaussian(
            mu=mu_q, Sigma=sigma_q, M=Phi_mat, eps=eps,
            symmetrize=True, sanitize=True,
            approx="auto" if getattr(config, "use_first_order_sigma_push", True) else "exact",
            near_identity_tau=float(getattr(config, "lambda_near_identity_tau", 5e-2)),
            return_inv=True,
        )

        grad_self_mu, grad_self_sigma = grad_self_energy_belief(
            mu_q, sigma_q, mu_p_push, sigma_p_push_inv, eps=eps
        )
        grad_fb_mu, grad_fb_sigma = grad_feedback_energy_belief(
            mu_q, sigma_q, mu_p, mu_q_push, sigma_q_push, sigma_q_push_inv, sigma_p, Phi_mat, eps=eps
        )

        fiber      = "q"
        mu_key     = "mu_q_field"
        sigma_key  = "sigma_q_field"

    elif mode == "model":
        alpha  = float(params.get("alpha",           getattr(config, "alpha",           1.0)))
        beta   = float(params.get("beta_model",      getattr(config, "beta_model",      0.0)))
        lambd  = float(params.get("feedback_weight", getattr(config, "feedback_weight", 0.0)))

        mu_p,  sigma_p  = agent_i.mu_p_field, agent_i.sigma_p_field
        mu_q,  sigma_q  = agent_i.mu_q_field, agent_i.sigma_q_field

        # Φ, Φ̃ from cache
        Phi_mat       = Phi(ctx, agent_i, kind="q_to_p")
        Phi_tilde_mat = Phi(ctx, agent_i, kind="p_to_q")

        mu_p_push, sigma_p_push, sigma_p_push_inv = push_gaussian(
            mu=mu_p, Sigma=sigma_p, M=Phi_tilde_mat, eps=eps,
            symmetrize=True, sanitize=True,
            approx="auto" if getattr(config, "use_first_order_sigma_push", True) else "exact",
            near_identity_tau=float(getattr(config, "lambda_near_identity_tau", 5e-2)),
            return_inv=True,
        )
        mu_q_push, sigma_q_push, sigma_q_push_inv = push_gaussian(
            mu=mu_q, Sigma=sigma_q, M=Phi_mat, eps=eps,
            symmetrize=True, sanitize=True,
            approx="auto" if getattr(config, "use_first_order_sigma_push", True) else "exact",
            near_identity_tau=float(getattr(config, "lambda_near_identity_tau", 5e-2)),
            return_inv=True,
        )

        grad_self_mu, grad_self_sigma = grad_self_energy_model(
            mu_q, sigma_q, mu_p_push, sigma_p_push_inv, Phi_tilde_mat, eps=eps
        )
        grad_fb_mu, grad_fb_sigma = grad_feedback_energy_model(
            mu_p, sigma_p, mu_q_push, sigma_q_push, sigma_q_push_inv, Phi_mat, eps=eps
        )

        fiber      = "p"
        mu_key     = "mu_p_field"
        sigma_key  = "sigma_p_field"

    else:
        raise ValueError(f"Unsupported mode: {mode}")

    mask_i = (np.asarray(agent_i.mask) > support_eps)

    # ---------------- neighbor alignment (Ω from cache) ----------------
    dmu_align    = np.zeros_like(getattr(agent_i, mu_key),    dtype=np.float32)
    dsigma_align = np.zeros_like(getattr(agent_i, sigma_key), dtype=np.float32)

    nb_list = getattr(agent_i, "neighbors", []) or []
    if nb_list and (beta != 0.0):
        # process each undirected pair exactly once
        i_id = int(getattr(agent_i, "id", -1))
        for nb in nb_list:
            j = nb["id"]
            agent_j = agents[j]
            j_id = int(getattr(agent_j, "id", j))

            if not (i_id < j_id):
                continue  # ensure each (i,j) handled once

            mask_j  = (np.asarray(agent_j.mask) > support_eps)
            overlap = mask_i & mask_j
            if not np.any(overlap):
                continue

            Omega_ij = Omega(ctx, agent_i, agent_j, which=fiber)

            mu_j    = getattr(agent_j, mu_key)
            sigma_j = getattr(agent_j, sigma_key)

            mu_j_t, sigma_j_t, sigma_j_t_inv = push_gaussian(
                mu=mu_j, Sigma=sigma_j, M=Omega_ij, eps=eps,
                symmetrize=True, sanitize=True,
                approx="auto" if getattr(config, "use_first_order_sigma_push", True) else "exact",
                near_identity_tau=float(getattr(config, "lambda_near_identity_tau", 5e-2)),
                return_inv=True,
            )

            mu_i    = getattr(agent_i, mu_key)
            sigma_i = getattr(agent_i, sigma_key)

            # ----- i-side (source) grads -----
            gμ_i, gΣ_i = grad_alignment_energy_source(mu_i, sigma_i, mu_j_t, sigma_j_t_inv, eps=eps)
            dmu_align[overlap]    += gμ_i[overlap]
            dsigma_align[overlap] += gΣ_i[overlap]

            # ----- j-side (target) grads -----
            gμ_j, gΣ_j = grad_alignment_energy_target(mu_i, sigma_i, mu_j_t, sigma_j_t_inv, Omega_ij, eps=eps)

            # mask to overlap for this edge, then convert to j's natural direction and accumulate into j now
            add_mu_j    = np.zeros_like(mu_j,    dtype=np.float32); add_mu_j[overlap]    = gμ_j[overlap]
            add_sigma_j = np.zeros_like(sigma_j, dtype=np.float32); add_sigma_j[overlap] = gΣ_j[overlap]

            dmu_j_nat, dsigma_j_nat = apply_natural_gradient_batch(
                getattr(agent_j, mu_key),
                getattr(agent_j, sigma_key),
                (beta * add_mu_j).astype(np.float32, copy=False),
                (beta * add_sigma_j).astype(np.float32, copy=False),
                mask=agent_j.mask,
                strict_numerics=strict_numerics,
                recover=(recover if not strict_numerics else None),
            )

            if mode == "belief":
                gmu_attr_j, gsig_attr_j = "grad_mu_q", "grad_sigma_q"
            else:
                gmu_attr_j, gsig_attr_j = "grad_mu_p", "grad_sigma_p"

            if getattr(agent_j, gmu_attr_j, None) is None:
                setattr(agent_j, gmu_attr_j,  np.zeros_like(mu_j,    dtype=np.float32))
            if getattr(agent_j, gsig_attr_j, None) is None:
                setattr(agent_j, gsig_attr_j, np.zeros_like(sigma_j, dtype=np.float32))

            setattr(agent_j, gmu_attr_j,  getattr(agent_j, gmu_attr_j)  + dmu_j_nat)
            setattr(agent_j, gsig_attr_j, getattr(agent_j, gsig_attr_j) + dsigma_j_nat)

    # ---------------- total Euclidean grads for agent_i ----------------
    dmu_total    = (alpha * grad_self_mu    + lambd * grad_fb_mu    + beta * dmu_align)
    dsigma_total = (alpha * grad_self_sigma + lambd * grad_fb_sigma + beta * dsigma_align)

    # Σ symmetry (no masking)
    dsigma_total = 0.5 * (dsigma_total + np.swapaxes(dsigma_total, -1, -2))

    # Final finite checks on Euclidean grads
    if strict_numerics:
        if not (np.all(np.isfinite(dmu_total)) and np.all(np.isfinite(dsigma_total))):
            raise FloatingPointError("accumulate_mu_sigma_gradient: nonfinite dμ/dΣ.")
    else:
        if not np.all(np.isfinite(dmu_total)):
            dmu_total = _recover_like(dmu_total, recover)
        if not np.all(np.isfinite(dsigma_total)):
            dsigma_total = _recover_like(dsigma_total, recover)

    # --- (belief) entropy regularizer on Σ (after checks)
    if mode == "belief":
        dsigma_total = accumulate_entropy_sigma_gradient(agent_i, dsigma_total, params)

    # --------------- project to natural gradient (agent_i) ---------------
    delta_mu, delta_sigma = apply_natural_gradient_batch(
        getattr(agent_i, mu_key),
        getattr(agent_i, sigma_key),
        dmu_total.astype(np.float32, copy=False),
        dsigma_total.astype(np.float32, copy=False),
        mask=agent_i.mask,
        strict_numerics=strict_numerics,
        recover=(recover if not strict_numerics else None),
    )

    # --------------- accumulate (agent_i) ----------------
    if mode == "belief":
        grad_mu_attr, grad_sigma_attr = "grad_mu_q", "grad_sigma_q"
    else:
        grad_mu_attr, grad_sigma_attr = "grad_mu_p", "grad_sigma_p"

    if getattr(agent_i, grad_mu_attr, None) is None:
        setattr(agent_i, grad_mu_attr, np.zeros_like(getattr(agent_i, mu_key), dtype=np.float32))
    if getattr(agent_i, grad_sigma_attr, None) is None:
        setattr(agent_i, grad_sigma_attr, np.zeros_like(getattr(agent_i, sigma_key), dtype=np.float32))

    setattr(agent_i, grad_mu_attr,    getattr(agent_i, grad_mu_attr)    + delta_mu)
    setattr(agent_i, grad_sigma_attr, getattr(agent_i, grad_sigma_attr) + delta_sigma)

    # --------------- minimal validation print ----------------
    if PRINT_SIGN:
        aid = getattr(agent_i, "id", "?")
        ax = tuple(range(delta_mu.ndim - 1))
        mu_mean = np.mean(delta_mu, axis=ax)
        S = delta_sigma
        S_tr = np.mean(np.trace(S, axis1=-2, axis2=-1), axis=ax)
        def sgns(vec): return "".join("+" if v>0 else "-" if v<0 else "0" for v in vec.tolist())
        print(f"[MU/SIG] mode={mode} ai={aid} "
              f"μ_sign={sgns(mu_mean)} μ_mean={np.array2string(mu_mean, precision=3, suppress_small=True)} "
              f"|μ|_mean={float(np.mean(np.abs(delta_mu))):.3e} "
              f"|Σ|_F_mean={float(np.mean(np.linalg.norm(S.reshape(*S.shape[:-2], -1), axis=-1))):.3e} "
              f"tr(ΣΔ)_mean={float(S_tr):.3e}",
              flush=True)

    return delta_mu, delta_sigma  # <- deltas for i (useful for tests)






def QQaccumulate_mu_sigma_gradient(agent_i, agents, params, mode,
                                 *, strict_numerics: bool = True,
                                 recover: str | None = None):  # None | "nan" | "zero"
    """
    Accumulate natural gradient ∇μ and ∇Σ for belief or model using cache-owned Φ, Φ̃, Ω.
    No globals() fallbacks; requires ctx and transport_cache.{Phi, Omega}.
    """
  
    

    PRINT_SIGN = bool(params.get("DEBUG_MU_SIG", False))
    ctx = params.get("runtime_ctx", None)
    if ctx is None:
        if strict_numerics:
            raise RuntimeError("accumulate_mu_sigma_gradient: ctx required (cache-centric Φ/Ω).")
        # graceful recovery (no ctx): return zeros shaped like the active fiber
        if mode == "belief":
            return _zero_mu_sigma_like(agent_i.mu_q_field, agent_i.sigma_q_field)
        elif mode == "model":
            return _zero_mu_sigma_like(agent_i.mu_p_field, agent_i.sigma_p_field)
        else:
            raise ValueError(f"Unsupported mode: {mode}")

    eps         = float(getattr(config, "eps", 1e-8))
    support_eps = float(getattr(config, "support_cutoff_eps", 1e-4))

    # -------- select fields/weights by mode --------
    if mode == "belief":
        alpha  = float(params.get("alpha",           getattr(config, "alpha",           1.0)))
        beta   = float(params.get("beta",            getattr(config, "beta",            0.0)))
        lambd  = float(params.get("feedback_weight", getattr(config, "feedback_weight", 0.0)))

        mu_q,  sigma_q  = agent_i.mu_q_field, agent_i.sigma_q_field
        mu_p,  sigma_p  = agent_i.mu_p_field, agent_i.sigma_p_field

        # Φ, Φ̃ from cache
        Phi_mat       = Phi(ctx, agent_i, kind="q_to_p")
        Phi_tilde_mat = Phi(ctx, agent_i, kind="p_to_q")

        # push via Φ̃ and Φ
        mu_p_push, sigma_p_push, sigma_p_push_inv = push_gaussian(
            mu=mu_p, Sigma=sigma_p, M=Phi_tilde_mat, eps=eps,
            symmetrize=True, sanitize=True,
            approx="auto" if getattr(config, "use_first_order_sigma_push", True) else "exact",
            near_identity_tau=float(getattr(config, "lambda_near_identity_tau", 5e-2)),
            return_inv=True,
        )
        mu_q_push, sigma_q_push, sigma_q_push_inv = push_gaussian(
            mu=mu_q, Sigma=sigma_q, M=Phi_mat, eps=eps,
            symmetrize=True, sanitize=True,
            approx="auto" if getattr(config, "use_first_order_sigma_push", True) else "exact",
            near_identity_tau=float(getattr(config, "lambda_near_identity_tau", 5e-2)),
            return_inv=True,
        )

        grad_self_mu, grad_self_sigma = grad_self_energy_belief(
            mu_q, sigma_q, mu_p_push, sigma_p_push_inv, eps=eps
        )
        grad_fb_mu, grad_fb_sigma = grad_feedback_energy_belief(
            mu_q, sigma_q, mu_p, mu_q_push, sigma_q_push, sigma_q_push_inv, sigma_p, Phi_mat, eps=eps
        )

        fiber      = "q"
        mu_key     = "mu_q_field"
        sigma_key  = "sigma_q_field"

    elif mode == "model":
        alpha  = float(params.get("alpha",           getattr(config, "alpha",           1.0)))
        beta   = float(params.get("beta_model",      getattr(config, "beta_model",      0.0)))
        lambd  = float(params.get("feedback_weight", getattr(config, "feedback_weight", 0.0)))

        mu_p,  sigma_p  = agent_i.mu_p_field, agent_i.sigma_p_field
        mu_q,  sigma_q  = agent_i.mu_q_field, agent_i.sigma_q_field

        # Φ, Φ̃ from cache
        Phi_mat       = Phi(ctx, agent_i, kind="q_to_p")
        Phi_tilde_mat = Phi(ctx, agent_i, kind="p_to_q")

        mu_p_push, sigma_p_push, sigma_p_push_inv = push_gaussian(
            mu=mu_p, Sigma=sigma_p, M=Phi_tilde_mat, eps=eps,
            symmetrize=True, sanitize=True,
            approx="auto" if getattr(config, "use_first_order_sigma_push", True) else "exact",
            near_identity_tau=float(getattr(config, "lambda_near_identity_tau", 5e-2)),
            return_inv=True,
        )
        mu_q_push, sigma_q_push, sigma_q_push_inv = push_gaussian(
            mu=mu_q, Sigma=sigma_q, M=Phi_mat, eps=eps,
            symmetrize=True, sanitize=True,
            approx="auto" if getattr(config, "use_first_order_sigma_push", True) else "exact",
            near_identity_tau=float(getattr(config, "lambda_near_identity_tau", 5e-2)),
            return_inv=True,
        )

        grad_self_mu, grad_self_sigma = grad_self_energy_model(
            mu_q, sigma_q, mu_p_push, sigma_p_push_inv, Phi_tilde_mat, eps=eps
        )
        grad_fb_mu, grad_fb_sigma = grad_feedback_energy_model(
            mu_p, sigma_p, mu_q_push, sigma_q_push, sigma_q_push_inv, Phi_mat, eps=eps
        )

        fiber      = "p"
        mu_key     = "mu_p_field"
        sigma_key  = "sigma_p_field"

    else:
        raise ValueError(f"Unsupported mode: {mode}")

    mask_i = (np.asarray(agent_i.mask) > support_eps)

    # ---------------- neighbor alignment (Ω from cache) ----------------
    dmu_align    = np.zeros_like(getattr(agent_i, mu_key),    dtype=np.float32)
    dsigma_align = np.zeros_like(getattr(agent_i, sigma_key), dtype=np.float32)

    nb_list = getattr(agent_i, "neighbors", []) or []
    if nb_list:
        for nb in nb_list:
            j = nb["id"]
            agent_j = agents[j]
            mask_j = (np.asarray(agent_j.mask) > support_eps)
            overlap = mask_i & mask_j
            if not np.any(overlap):
                continue

            Omega_ij = Omega(ctx, agent_i, agent_j, which=fiber)

            mu_j    = getattr(agent_j, mu_key)
            sigma_j = getattr(agent_j, sigma_key)
            mu_j_t, sigma_j_t, sigma_j_t_inv = push_gaussian(
                mu=mu_j, Sigma=sigma_j, M=Omega_ij, eps=eps,
                symmetrize=True, sanitize=True,
                approx="auto" if getattr(config, "use_first_order_sigma_push", True) else "exact",
                near_identity_tau=float(getattr(config, "lambda_near_identity_tau", 5e-2)),
                return_inv=True,
            )

            mu_i    = getattr(agent_i, mu_key)
            sigma_i = getattr(agent_i, sigma_key)

            dmu_i, dsigma_i = grad_alignment_energy_source(
                mu_i, sigma_i, mu_j_t, sigma_j_t_inv, eps=eps
            )

            dmu_align[overlap]    += dmu_i[overlap]
            dsigma_align[overlap] += dsigma_i[overlap]

    # ---------------- total Euclidean grads ----------------
    dmu_total    = (alpha * grad_self_mu    + lambd * grad_fb_mu    + beta * dmu_align)
    dsigma_total = (alpha * grad_self_sigma + lambd * grad_fb_sigma + beta * dsigma_align)

    # Σ symmetry (no masking)
    dsigma_total = 0.5 * (dsigma_total + np.swapaxes(dsigma_total, -1, -2))

    # Final finite checks on Euclidean grads
    if strict_numerics:
        if not (np.all(np.isfinite(dmu_total)) and np.all(np.isfinite(dsigma_total))):
            raise FloatingPointError("accumulate_mu_sigma_gradient: nonfinite dμ/dΣ.")
    else:
        if not np.all(np.isfinite(dmu_total)):
            dmu_total = _recover_like(dmu_total, recover)
        if not np.all(np.isfinite(dsigma_total)):
            dsigma_total = _recover_like(dsigma_total, recover)

    # --- (belief) entropy regularizer on Σ (after checks)
    if mode == "belief":
        dsigma_total = accumulate_entropy_sigma_gradient(agent_i, dsigma_total, params)

    # --------------- project to natural gradient ---------------
    delta_mu, delta_sigma = apply_natural_gradient_batch(
        getattr(agent_i, mu_key),
        getattr(agent_i, sigma_key),
        dmu_total.astype(np.float32, copy=False),
        dsigma_total.astype(np.float32, copy=False),
        mask=agent_i.mask,
        strict_numerics=strict_numerics,
        recover=(recover if not strict_numerics else None),
    )

    # --------------- accumulate ----------------
    if mode == "belief":
        grad_mu_attr, grad_sigma_attr = "grad_mu_q", "grad_sigma_q"
    else:
        grad_mu_attr, grad_sigma_attr = "grad_mu_p", "grad_sigma_p"

    if getattr(agent_i, grad_mu_attr, None) is None:
        setattr(agent_i, grad_mu_attr, np.zeros_like(getattr(agent_i, mu_key), dtype=np.float32))
    if getattr(agent_i, grad_sigma_attr, None) is None:
        setattr(agent_i, grad_sigma_attr, np.zeros_like(getattr(agent_i, sigma_key), dtype=np.float32))

    setattr(agent_i, grad_mu_attr,    getattr(agent_i, grad_mu_attr)    + delta_mu)
    setattr(agent_i, grad_sigma_attr, getattr(agent_i, grad_sigma_attr) + delta_sigma)

    # --------------- minimal validation print ----------------
    if PRINT_SIGN:
        aid = getattr(agent_i, "id", "?")
        ax = tuple(range(delta_mu.ndim - 1))
        mu_mean = np.mean(delta_mu, axis=ax)
        S = delta_sigma
        S_tr = np.mean(np.trace(S, axis1=-2, axis2=-1), axis=ax)
        def sgns(vec): return "".join("+" if v>0 else "-" if v<0 else "0" for v in vec.tolist())
        print(f"[MU/SIG] mode={mode} ai={aid} "
              f"μ_sign={sgns(mu_mean)} μ_mean={np.array2string(mu_mean, precision=3, suppress_small=True)} "
              f"|μ|_mean={float(np.mean(np.abs(delta_mu))):.3e} "
              f"|Σ|_F_mean={float(np.mean(np.linalg.norm(S.reshape(*S.shape[:-2], -1), axis=-1))):.3e} "
              f"tr(ΣΔ)_mean={float(S_tr):.3e}",
              flush=True)

    return delta_mu, delta_sigma  # <- return deltas (useful for tests)



# ---------- helpers ----------
def _recover_like(x: np.ndarray, recover: str | None):
    if recover is None or recover == "nan":
        return np.full_like(x, np.nan, dtype=np.float32)
    if recover == "zero":
        return np.zeros_like(x, dtype=np.float32)
    raise ValueError(f"Unknown recover policy: {recover}")

def _zero_mu_sigma_like(mu, Sigma):
    return (np.zeros_like(mu, dtype=np.float32),
            np.zeros_like(Sigma, dtype=np.float32))


def accumulate_entropy_sigma_gradient(agent_i, grad_sigma_q, params):
    """
    Add entropy regularization to the Σ-gradient.

    Convention (default):
        E_total = E_other - gamma * H[q]
      ⇒ ∇_Σ E_total = ∇_Σ E_other - gamma * ∇_Σ H
      ⇒ with ∇_Σ H = ½ Σ^{-1}

    You can override the sign via params["entropy_in_energy_sign"] ∈ {+1, -1}.
    Use +1 if energy includes +gamma * H (penalty),
    use -1 if it includes -gamma * H (reward; default).
    """
    

    gamma = float(params.get("entropy_weight", getattr(config, "entropy_weight", 0.0)))
    if gamma == 0.0:
        return grad_sigma_q

    s = int(params.get("entropy_in_energy_sign", -1))
    sigma_q = sanitize_sigma(np.asarray(agent_i.sigma_q_field, dtype=np.float32), strict=True)
    grad_H  = 0.5 * safe_batch_inverse(sigma_q)

    mask = (np.asarray(agent_i.mask) > float(getattr(config, "support_cutoff_eps", 0.0)))[..., None, None]
    grad_H = grad_H * mask

    out = grad_sigma_q + gamma * s * grad_H
    out = 0.5 * (out + np.swapaxes(out, -1, -2))
    return out.astype(np.float32, copy=False)





#==============================================================================
#
#                    FEEDBACK / SELF TERMS (unchanged math, safer numerics)
#==============================================================================

def grad_alignment_energy_source(mu_i, sigma_i, mu_j_t, sigma_j_t_inv, eps=1e-8):
    delta_mu = mu_i - mu_j_t
    grad_mu = np.einsum("...ij,...j->...i", sigma_j_t_inv, delta_mu, optimize=True)

    # sanitize once per call
    sigma_i = sanitize_sigma(np.asarray(sigma_i, dtype=np.float32), strict=True)
    sigma_i_inv = safe_batch_inverse(sigma_i)

    grad_sigma = 0.5 * (sigma_j_t_inv - sigma_i_inv)
    grad_sigma = 0.5 * (grad_sigma + np.swapaxes(grad_sigma, -1, -2))
    return grad_mu.astype(np.float32, copy=False), grad_sigma.astype(np.float32, copy=False)

def grad_alignment_energy_target(
    mu_i,
    sigma_i,
    mu_j_t,           # = Ω_ij @ mu_j            (transported target mean)
    sigma_j_t_inv,    # = (Ω_ij Σ_j Ω_ij^T)^{-1} (transported target precision)
    Omega_ij,         # transport matrix Ω_ij
    eps: float = 1e-8,
):
    """
    Exact Euclidean gradients of KL(N(mu_i, sigma_i) || N(mu_j', Sigma_j')) wrt *j*'s params,
    mapped back to j's frame via Ω_ij^T.  (Here mu_j' = Ω_ij mu_j, Sigma_j' = Ω_ij Σ_j Ω_ij^T.)

    Returns:
        grad_mu_j   (..., K)
        grad_sigma_j(..., K, K)  [symmetric]
    """
    # --- delta in i-frame ---
    mu_i    = np.asarray(mu_i,    dtype=np.float32)
    mu_j_t  = np.asarray(mu_j_t,  dtype=np.float32)
    dmu     = mu_i - mu_j_t                      # (..., K)

    # --- sanitize inputs we multiply with ---
    Omega_ij      = np.asarray(Omega_ij,      dtype=np.float32)
    sigma_j_t_inv = np.asarray(sigma_j_t_inv, dtype=np.float32)
    sigma_j_t_inv = np.nan_to_num(sigma_j_t_inv, nan=0.0, posinf=0.0, neginf=0.0)

    # Σ_i only enters the Σ_j-gradient; sanitize once
    sigma_i = sanitize_sigma(np.asarray(sigma_i, dtype=np.float32), strict=True)

    # ---------- μ_j gradient ----------
    # ∂_{μ_j'} KL = - Σ_j'^{-1} (μ_i - μ_j')  ;  map back: ∂_{μ_j} = Ω_ij^T ∂_{μ_j'}
    gmu_jp = -np.einsum("...ij,...j->...i", sigma_j_t_inv, dmu, optimize=True)
    grad_mu_j = np.einsum("...ji,...j->...i", Omega_ij, gmu_jp, optimize=True)
    grad_mu_j = grad_mu_j.astype(np.float32, copy=False)

    # ---------- Σ_j gradient ----------
    # ∂_{Σ_j'} KL = 1/2 [ -S'^-1 Σ_i S'^-1 - S'^-1 dμ dμ^T S'^-1 + S'^-1 ]
    t0 = -np.einsum("...ij,...jk,...kl->...il", sigma_j_t_inv, sigma_i, sigma_j_t_inv, optimize=True)
    t1 = -np.einsum("...ij,...j,...k,...kl->...il", sigma_j_t_inv, dmu, dmu, sigma_j_t_inv, optimize=True)
    t2 =  sigma_j_t_inv
    gSigma_jp = 0.5 * (t0 + t1 + t2)

    # map back: ∂_{Σ_j} = Ω_ij^T (∂_{Σ_j'}) Ω_ij
    grad_sigma_j = np.einsum("...ji,...jk,...kl->...il",
                             Omega_ij, gSigma_jp, np.swapaxes(Omega_ij, -1, -2), optimize=True)
    # symmetrize + scrub (just in case)
    grad_sigma_j = 0.5 * (grad_sigma_j + np.swapaxes(grad_sigma_j, -1, -2))
    grad_sigma_j = np.nan_to_num(grad_sigma_j, nan=0.0, posinf=0.0, neginf=0.0).astype(np.float32, copy=False)

    return grad_mu_j, grad_sigma_j


def grad_feedback_energy_belief(mu_q, sigma_q, mu_p, mu_q_push,
                                sigma_q_push, sigma_q_push_inv, sigma_p, Phi, eps=1e-8):
    delta_mu = mu_p - mu_q_push
    tmp = np.einsum("...ij,...j->...i", sigma_q_push_inv, delta_mu, optimize=True)
    grad_mu = -np.einsum("...ji,...j->...i", Phi, tmp, optimize=True)

    A = np.einsum("...i,...j->...ij", delta_mu, delta_mu, optimize=True)

    term1 = sigma_q_push_inv
    term2 = np.einsum("...ik,...kl,...lj->...ij", sigma_q_push_inv, A,       sigma_q_push_inv, optimize=True)
    term3 = np.einsum("...ik,...kl,...lj->...ij", sigma_q_push_inv, sigma_p, sigma_q_push_inv, optimize=True)
    M = term1 - term2 - term3

    grad_sigma = 0.5 * np.einsum("...ki,...kl,...lj->...ij", Phi, M, Phi, optimize=True)
    grad_sigma = 0.5 * (grad_sigma + np.swapaxes(grad_sigma, -1, -2))
    return grad_mu.astype(np.float32, copy=False), grad_sigma.astype(np.float32, copy=False)


def grad_feedback_energy_model(mu_p, sigma_p, mu_q_push,
                               sigma_q_push, sigma_q_push_inv, Phi=None, eps=1e-8):
    sigma_q_push = sanitize_sigma(np.asarray(sigma_q_push, dtype=np.float32), strict=True)
    if sigma_q_push_inv is None:
        sigma_q_push_inv = safe_batch_inverse(sigma_q_push)

    delta_mu = mu_p - mu_q_push
    grad_mu = np.einsum("...ij,...j->...i", sigma_q_push_inv, delta_mu, optimize=True)

    sigma_p = sanitize_sigma(np.asarray(sigma_p, dtype=np.float32), strict=True)
    sigma_p_inv = safe_batch_inverse(sigma_p)

    grad_sigma = 0.5 * (sigma_q_push_inv - sigma_p_inv)
    grad_sigma = 0.5 * (grad_sigma + np.swapaxes(grad_sigma, -1, -2))
    return grad_mu.astype(np.float32, copy=False), grad_sigma.astype(np.float32, copy=False)


def grad_self_energy_belief(mu_q, sigma_q, mu_p_push, sigma_p_push_inv, eps=1e-8, mask=None):
    delta_mu = mu_q - mu_p_push
    grad_mu = np.einsum("...ij,...j->...i", sigma_p_push_inv, delta_mu, optimize=True)

    sigma_q = sanitize_sigma(np.asarray(sigma_q, dtype=np.float32), strict=True)
    sigma_q_inv = safe_batch_inverse(sigma_q)

    grad_sigma = 0.5 * (sigma_p_push_inv - sigma_q_inv)
    grad_sigma = 0.5 * (grad_sigma + np.swapaxes(grad_sigma, -1, -2))

    if mask is not None:
        m = (np.asarray(mask) > float(getattr(config, "support_cutoff_eps", 0.0)))
        grad_mu    = grad_mu * m[..., None]
        grad_sigma = grad_sigma * m[..., None, None]

    return grad_mu.astype(np.float32, copy=False), grad_sigma.astype(np.float32, copy=False)


def grad_self_energy_model(mu_q, sigma_q, mu_p_push, sigma_p_push_inv, Phi_tilde, eps=1e-8, mask=None):
    """
    ∂ wrt (μ_p, Σ_p) of KL(q || Φ̃·p), with A = Φ̃ Σ_p Φ̃ᵀ and Δ = μ_q − μ_p^t.
    """
    delta_mu = mu_q - mu_p_push
    tmp = np.einsum("...ij,...j->...i", sigma_p_push_inv, delta_mu, optimize=True)
    grad_mu = -np.einsum("...ji,...j->...i", Phi_tilde, tmp, optimize=True)

    delta_mu_outer = np.einsum("...i,...j->...ij", delta_mu, delta_mu, optimize=True)

    M = sigma_p_push_inv
    G = M - np.einsum("...ik,...kl,...lj->...ij", M, delta_mu_outer, M, optimize=True) \
          - np.einsum("...ik,...kl,...lj->...ij", M, sigma_q,        M, optimize=True)

    Phi_tilde_T = np.swapaxes(Phi_tilde, -1, -2)
    grad_sigma = 0.5 * np.einsum("...ki,...ij,...jl->...kl", Phi_tilde_T, G, Phi_tilde, optimize=True)
    grad_sigma = 0.5 * (grad_sigma + np.swapaxes(grad_sigma, -1, -2))  # symmetrize

    if mask is not None:
        m = (np.asarray(mask) > float(getattr(config, "support_cutoff_eps", 0.0)))
        grad_mu    = grad_mu * m[..., None]
        grad_sigma = grad_sigma * m[..., None, None]

    return grad_mu.astype(np.float32, copy=False), grad_sigma.astype(np.float32, copy=False)








