import os
os.environ["OMP_NUM_THREADS"] = "1"
os.environ["MKL_NUM_THREADS"] = "1"
os.environ["NUMEXPR_NUM_THREADS"] = "1"

from threadpoolctl import threadpool_info
print(threadpool_info())
from get_generators import RhoFunction
from bundle_morphism_utils import make_morphism_fn

import pickle
import numpy as np
import pandas as pd
from scipy.stats import qmc
import config
from generalized_simulation import run_simulation
import matplotlib.pyplot as plt
from get_generators import get_generators
DEFAULT_SAMPLES = 50  # Number of successful runs to obtain

# --- Load default parameters from config.py ---
base_params = {
    k: getattr(config, k)
    for k in dir(config)
    if not k.startswith("__") and not callable(getattr(config, k))
}
base_params.update({
    "debug": True,
    "steps": 100,
    "N": 2,
})


import numpy as np

import numpy as np

def get_scaled_sweep_params(K):
    # Define the parameter ranges
    param_ranges = {
        "alpha":                  (0, 20),
        "beta":                   (0, 20),
        "gauge_weight":           (0, 20),
        "model_align_weight":     (0, 20),
        "model_mass_weight":      (0, 20),
        "model_feedback_weight":  (0, 20),
        "model_curvature_weight": (0, 20),
        "curvature_weight":       (0, 20),
    }

    # Create an LHS sweep of integer values for each parameter within the range
    sweep_params = {}

    for param, (min_val, max_val) in param_ranges.items():
        # Ensure the values are integer steps and fit within the range
        sweep_params[param] = np.linspace(min_val, max_val, K, dtype=int)

    return sweep_params



def is_unstable(metrics, clip_threshold=50, energy_thresh=1e8, min_kl_thresh=-1e-5):
    if not metrics:
        return True
    kl_keys = [k for k in metrics[0].keys() if "kl" in k.lower()]
    prev_vals = {k: metrics[0].get(k, 0) for k in kl_keys}
    for step in metrics:
        if any(np.isnan(v) or np.isinf(v) for v in step.values()):
            return True
        if step.get("energy_total", 0) > energy_thresh:
            return True
        if step.get("sanitize_clipped", 0) > clip_threshold:
            return True
        for k in step:
            if "kl" in k.lower():
                if step[k] < min_kl_thresh:
                    return True
                if step[k] > prev_vals[k] + 1e-3:
                    print(f"[REJECT] KL term '{k}' increased: {prev_vals[k]:.4f} --> {step[k]:.4f}")
                    return True
                prev_vals[k] = step[k]
    return False


def is_pickleable(obj):
    try:
        pickle.dumps(obj)
        return True
    except Exception:
        return False


def sanitize_for_pickle(obj):
    if isinstance(obj, dict):
        return {k: sanitize_for_pickle(v) for k, v in obj.items() if is_pickleable(v)}
    elif isinstance(obj, list):
        return [sanitize_for_pickle(v) for v in obj if is_pickleable(v)]
    return obj
 

def run_lhs_sweep_for_K(K_q, K_p, n_samples=DEFAULT_SAMPLES):
    base_params_K = dict(base_params)
    base_params_K["K_q"] = K_q
    base_params_K["K_p"] = K_p

    output_dir = f"lhs_results_Kq{K_q}_Kp{K_p}"
    csv_path = f"lhs_samples_Kq{K_q}_Kp{K_p}.csv"
    os.makedirs(output_dir, exist_ok=True)

    sweep_params = get_scaled_sweep_params(K_q)  # still use K_q for fiber dimension scaling

    param_names = list(sweep_params)
    
    # Define the low and high bounds
    low_bounds = [0 for _ in sweep_params]  # set min bounds for each parameter
    high_bounds = [20 for _ in sweep_params]  # set max bounds for each parameter
    
    # Initialize the Latin Hypercube sampler
    sampler = qmc.LatinHypercube(d=len(param_names))
    attempted_rows = set()

    with open(os.path.join(output_dir, "sweep_spec.pkl"), "wb") as f:
        pickle.dump({"param_names": param_names, "ranges": sweep_params}, f)

    all_params = []
    attempt_id = 0
    max_retries = 5

    while len(all_params) < n_samples:
        raw_sample = sampler.random(n=1)[0]
        key = tuple(raw_sample.round(decimals=6))
        if key in attempted_rows:
            continue
        attempted_rows.add(key)

        # Scale the raw sample and round to integer values
        row = qmc.scale([raw_sample], low_bounds, high_bounds)[0]
        row = np.round(row).astype(int)  # Rounding and casting to integers
        sampled_params = dict(zip(param_names, row))

        attempt = 0
        success = False

        while attempt < max_retries and not success:
            entry = dict(base_params_K)
            entry.update(sampled_params)
            entry["agent_seed"] = base_params.get("agent_seed", 13) + attempt_id
            entry["np_seed"] = 1000 + attempt_id
            entry["_lhs_raw_sample"] = raw_sample.tolist()

            run_name = f"run_{attempt_id}_try{attempt}"
            subdir = os.path.join(output_dir, run_name)
            os.makedirs(subdir, exist_ok=True)

            print(f"\n[TRY {attempt}] {run_name} → {sampled_params}")

            # Force config to match the sweep entry (used by agent_init)
            config.K_q = entry["K_q"]
            config.K_p = entry["K_p"]

            # Now build generators and morphisms from this consistent config
            group_name = base_params.get("group_name", "sl2r")
            G_q = get_generators(group_name, config.K_q)
            G_p = get_generators(group_name, config.K_p)
            rho_q = RhoFunction(G_q)
            rho_p = RhoFunction(G_p)

            entry["generators_q"] = G_q
            entry["generators_p"] = G_p
            entry["bundle_morphism_transform_q_to_p"] = make_morphism_fn(rho_q, rho_p)
            entry["bundle_morphism_transform_p_to_q"] = make_morphism_fn(rho_p, rho_q)

            try:
                # Force override config-level K_q/K_p to match this sweep entry
                config.K_q = entry["K_q"]
                config.K_p = entry["K_p"]

                np.random.seed(entry["np_seed"])
                _, metric_log = run_simulation(
                    outdir=subdir,
                    resume=False,
                    log_metrics=True,
                    log_fields=True,
                    num_cores=18,
                    params=entry,
                )

                # Energy plot
                energy = [step.get("total_energy", np.nan) for step in metric_log]
                energy = [e for e in energy if not np.isnan(e)]

                if energy:
                    plt.figure(figsize=(6, 3))
                    plt.plot(energy, '-o')
                    plt.title(f"Total Energy — {run_name}")
                    plt.xlabel("time step")
                    plt.ylabel("total_energy")
                    cfg = entry
                    txt = (
                        f"α = {cfg.get('alpha')}\n"
                        f"β = {cfg.get('beta')}\n"
                        f"g = {cfg.get('gauge_weight')}\n"
                        f"cw = {cfg.get('curvature_weight')}\n"
                        f"mfw = {cfg.get('model_feedback_weight')}\n"
                        f"maw = {cfg.get('model_align_weight')}\n"
                        f"mmw = {cfg.get('model_mass_weight')}\n"
                        f"mcw = {cfg.get('model_curvature_weight')}"
                    )
                    plt.gcf().text(0.98, 0.98, txt, ha='right', va='top', fontsize='small',
                                   bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.5))
                    plt.tight_layout()
                    plt.savefig(os.path.join(subdir, "energy_plot.png"))
                    plt.close()

                # Save metrics and params
                clean_metrics = sanitize_for_pickle(metric_log)
                with open(os.path.join(subdir, "final_metrics.pkl"), "wb") as f:
                    pickle.dump(clean_metrics, f)

                clean_params = sanitize_for_pickle(entry)
                with open(os.path.join(subdir, "params.pkl"), "wb") as f:
                    pickle.dump(clean_params, f)

                unstable = is_unstable(metric_log)
                entry["_unstable"] = unstable

                if unstable:
                    print(f"[REJECT] {run_name} failed stability check.")
                    attempt += 1
                    continue

                print(f"[✓] {run_name} accepted.")
                all_params.append(entry)
                attempt_id += 1
                success = True

            except Exception as e:
                print(f"[ERROR] {run_name} crashed: {e}")
                import traceback
                traceback.print_exc()
                attempt += 1

        if not success:
            print(f"[✗] Abandoned sample after {max_retries} failed attempts.")

    # Save the results to CSV
    df = pd.DataFrame(all_params)
    df.to_csv(csv_path, index=False)
    print(f"\n[DONE] CSV written → {csv_path}")
    print(f"[DONE] LHS sweep for (K_q={K_q}, K_p={K_p}) finished with {len(all_params)} valid runs.")



def main():
    # Specify (K_q, K_p) pairs to sweep over
    K_pairs = [(7, 9)]  # ← Edit this list as needed

    for K_q, K_p in K_pairs:
        print(f"\n{'=' * 40}")
        print(f"[SWEEP] Running for (K_q, K_p) = ({K_q}, {K_p})")
        print(f"{'=' * 40}")
        run_lhs_sweep_for_K(K_q=K_q, K_p=K_p)


if __name__ == "__main__":
    main()
