# -*- coding: utf-8 -*-
"""
Created on Sun Jul 20 11:03:58 2025

@author: chris and christine
"""

# -*- coding: utf-8 -*-
"""
Created on Sun Jul 20 10:47:49 2025

@author: chris and christine
"""

import numpy as np
from scipy.linalg import inv
import numpy as np
import config
from joblib import Parallel, delayed

from natural_gradient_utils import (
    apply_natural_gradient_batch,
    apply_lie_natural_gradient,
    compute_inverse_fisher_field
)

from numerical_utils import sanitize_sigma
from mask_utils import clip_and_mask_gradient, clip_and_mask_morphism
from numerical_utils import safe_inv

from get_generators import get_generators
from generalized_math_utils import unpack_phi_update_params
from generalized_omega import compute_curvature_gradient_analytical, exp_lie_algebra_irrep

from generalized_omega import dexpinv_operator, dexpinv_operator_covariance
from natural_gradient_utils import compute_fisher_geometry_gradient, kl_gradient_mu_sigma
from generalized_math_utils import ( 
        zero_mu_sigma_like, apply_mask_to_mu_sigma
        )
from natural_gradient_utils import transport_gaussian
from bundle_morphism_utils import safe_batch_apply_morphism
from generalized_math_utils import ( 
        zero_mu_sigma_like, compute_mu_sigma_diff,
        apply_mask_to_mu_sigma
        )


def grad_morphism_self_energy(agent_i, alpha, mask=None, eps=1e-8):
    """
    Compute full gradient ∂/∂Φ KL(q || Φ~·p) over spatial grid (H, W)
    """
    mu_q    = agent_i.mu_q_field
    sigma_q = agent_i.sigma_q_field
    mu_p    = agent_i.mu_p_field
    sigma_p = agent_i.sigma_p_field
    Phi_tilde     = agent_i.bundle_morphism_p_to_q

    grad = compute_morphism_kl_gradient_batched(
        Phi_tilde, mu_q, sigma_q, mu_p, sigma_p, eps=eps
    )

    if mask is not None:
        grad *= mask[..., None, None]  # shape (H, W, 1, 1)

    return alpha * grad


def compute_morphism_kl_gradient_batched(Phi_tilde, mu_q, Sigma_q, mu_p, Sigma_p, eps=1e-8):
    """
    Batched version of ∂/∂Φ~ D_KL(q || Φ~·p) for spatial grid.
    
    Args:
        Phi~     : (H, W, K_q, K_p)
        mu_q     : (H, W, K_q)
        Sigma_q  : (H, W, K_q, K_q)
        mu_p     : (H, W, K_p)
        Sigma_p  : (H, W, K_p, K_p)
        eps      : float, SPD regularization
    
    Returns:
        grad     : (H, W, K_q, K_p) KL gradient w.r.t. Φ~ at each spatial location
    """
    H, W, K_q, K_p = Phi_tilde.shape
    grad = np.zeros_like(Phi_tilde)

    for i in range(H):
        for j in range(W):
            grad[i, j] = compute_morphism_kl_gradient_self(
                Phi_tilde[i, j], mu_q[i, j], Sigma_q[i, j],
                mu_p[i, j], Sigma_p[i, j], eps=eps
                )


    return grad


def compute_morphism_kl_gradient_primitives(Phi_tilde, mu_q, Sigma_q, mu_p, Sigma_p, eps=1e-8):
    """
    Compute shared intermediates needed to evaluate ∂/∂Φ~ D_KL(q || Φ·p)
    
    Args:
        Phi~      : (K_q, K_p) linear morphism matrix Φ~
        mu_q     : (K_q,)     mean of belief q
        Sigma_q  : (K_q, K_q) covariance of belief q
        mu_p     : (K_p,)     mean of model p
        Sigma_p  : (K_p, K_p) covariance of model p
        eps      : stabilizer for SPD inverse

    Returns:
        dict containing:
            - Delta_mu     : (K_q,)     = mu_q - Φ~·mu_p
            - Sigma_q_inv  : (K_q, K_q)
            - M            : (K_q, K_q) = Φ~ Σ_q Φ~ᵀ
            - M_inv        : (K_q, K_q)
            - term_trace   : (K_q, K_q) = M⁻¹ Σ_q M⁻¹
            - term_logdet  : (K_q, K_p) = M⁻¹ Φ~ Σ_p
    """
    K_q, K_p = Phi_tilde.shape

    # Compute Δμ = μ_p - Φ·μ_q
    Delta_mu = mu_q - Phi_tilde @ mu_p

    # Inverse of Σ_q
    Sigma_p_inv = safe_inv(Sigma_p, eps=eps)

    # M = Φ Σ_q Φᵀ
    M = Phi_tilde @ Sigma_p @ Phi_tilde.T

    # Inverse of M
    M_inv = safe_inv(M, eps=eps)

    # Precompute reusable trace/logdet gradient terms
    term_trace = M_inv @ Sigma_q @ M_inv  # (K_p, K_p)
    term_logdet = M_inv @ Phi_tilde @ Sigma_p  # (K_p, K_q)

    return {
        "Delta_mu": Delta_mu,
        "Sigma_q_inv": Sigma_p_inv,
        "M": M,
        "M_inv": M_inv,
        "term_trace": term_trace,
        "term_logdet": term_logdet
    }


def compute_morphism_kl_gradient_self(Phi_tilde, mu_q, Sigma_q, mu_p, Sigma_p, eps=1e-8):
    """
    Compute ∂/∂Φ~ D_KL(q || Φ~·p), where Φ~: P → Q
    """
    primitives = compute_morphism_kl_gradient_primitives(
        Phi_tilde, mu_q, Sigma_q, mu_p, Sigma_p, eps=eps
    )

    Delta_mu     = primitives["Delta_mu"]
    M_inv        = primitives["M_inv"]
    term_trace   = primitives["term_trace"]
    term_logdet  = primitives["term_logdet"]

    # Term 1: - M⁻¹ Δμ μ_pᵀ
    term1 = - np.outer(M_inv @ Delta_mu, mu_p)

    # Term 2: - Δμ μ_pᵀ M⁻¹
    term2 = - M_inv @ np.outer(Delta_mu, mu_p)


    # Term 3: + M⁻¹ Φ~ Σ_p
    term3 = term_logdet

    # Term 4: - M⁻¹ Σ_q M⁻¹ Φ~ Σ_p
    term4 = - term_trace @ Phi_tilde @ Sigma_p

    return term1 + term2 + term3 + term4

