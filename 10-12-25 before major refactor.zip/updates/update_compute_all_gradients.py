from __future__ import annotations

"""
Created on Tue Aug 12 20:15:47 2025

@author: chris and christine
"""
import time
from threadpoolctl import threadpool_limits
import numpy as np
from core.numerical_utils import sanitize_sigma
from core.omega import retract_phi_principal, d_exp_exact

from updates.update_terms_phi import ( compute_gbar_align_cov_recv,
    accumulate_phi_morphism_self_feedback, accumulate_phi_alignment_gradient,
    grad_feedback_phi_direct, grad_feedback_phi_tilde_direct, grad_self_phi_direct,
    grad_self_phi_tilde_direct )

from updates.update_terms_mu_sigma import accumulate_mu_sigma_gradient
from updates.update_helpers import dirty_manager, _ensure_fisher
from joblib import Parallel, delayed
from runtime_context import cfg_get
from utils import get_neighbors, zero_all_gradients, _aid

from updates.update_terms_curvature_A import covariant_frame_energy_and_grads




# unified metadata for phi vs phi_tilde blocks
_FIELD_META = {
    "phi": {
        "which": "q",
        "mu_key": "mu_q_field",
        "sigma_key": "sigma_q_field",
        "fisher_inv_key": "inverse_fisher_phi",
        "grad_key": "grad_phi",
        "phi_attr": "phi",
        "qall_func": d_exp_exact,
    },
    "phi_model": {
        "which": "p",
        "mu_key": "mu_p_field",
        "sigma_key": "sigma_p_field",
        "fisher_inv_key": "inverse_fisher_phi_model",
        "grad_key": "grad_phi_tilde",
        "phi_attr": "phi_model",
        "qall_func": d_exp_exact,
    },
}

def _alignment_block(agent_i, neighbors, generators, *, field: str, ctx):
    if not neighbors:
        return 0.0

    # normalize name
    field_eff = "phi_model" if field in {"phi_model", "phi_tilde"} else "phi"
    meta = _FIELD_META[field_eff]

    # EXTRA SAFETY: ensure Fisher for receiver and neighbors on the correct fiber
    which = "q" if field_eff == "phi" else "p"
    eps_val = float(cfg_get(ctx, "eps", 1e-8))
    
    _ensure_fisher(agent_i, which=which, generators=generators, ctx=ctx, eps=eps_val)
    
    for aj in neighbors or []:
        _ensure_fisher(aj, which=which, generators=generators, ctx=ctx, eps=eps_val)

    t0 = time.perf_counter()

    # Pass 1: build β-weighted average ALIGN covector (uses fisher_inv_key defensively)
    gbar = compute_gbar_align_cov_recv(
        ctx, agent_i, neighbors, generators,
        field=field_eff,
        fisher_inv_key=meta["fisher_inv_key"],
    )

    # Pass 2: accumulate per edge with softmax correction
    accum_send = bool(cfg_get(ctx, "accumulate_sender_grads", False))
    for agent_j in neighbors:
        accumulate_phi_alignment_gradient(
            ctx, agent_i, agent_j, generators,
            field=field_eff,
            fisher_inv_key=meta["fisher_inv_key"],
            grad_key=meta["grad_key"],
            accumulate_sender_grads=accum_send,
            gbar_align_cov_recv=gbar,
        )

    return time.perf_counter() - t0





def _morphism_block(agent_i, generators_q, generators_p, *, field: str, ctx):
    meta = _FIELD_META[field]
    t0 = time.perf_counter()

    if field == "phi":
        accumulate_phi_morphism_self_feedback(
            ctx, agent_i, generators_q, generators_p,  # q, p (fixed)
            field="phi",
            fisher_inv_key=meta["fisher_inv_key"],
            grad_key=meta["grad_key"],
            phi_self_func=grad_self_phi_direct,
            phi_feedback_func=grad_feedback_phi_direct,
        )
    else:
        accumulate_phi_morphism_self_feedback(
            ctx, agent_i, generators_q, generators_p,  # q, p (fixed)
            field="phi_model",
            fisher_inv_key=meta["fisher_inv_key"],
            grad_key=meta["grad_key"],
            phi_self_func=grad_self_phi_tilde_direct,
            phi_feedback_func=grad_feedback_phi_tilde_direct,
        )

    return time.perf_counter() - t0



# -----------------------------------
# Disentangled gradient orchestrator
# -----------------------------------


def compute_all_gradients(agent_i, agents, all_agents, generators_q, generators_p, runtime_ctx=None):
    """
    Single-scale gradient orchestrator (no parents / no cross-scale).

      Phase 0: thread runtime ctx
      Phase 1: μ, Σ (belief/model) — same-level only
      Phase 2: (optional) warm local caches for agent_i + neighbors
      Phase 3: φ alignment (belief + model), same-level only
      Phase 4: morphism self + feedback (φ, φ̃), same-level
      Phase 5: return gradients (+ per-agent θ grads; DO NOT APPLY HERE)
    """
    ctx = runtime_ctx
    eps_val = float(cfg_get(ctx, "eps", 1e-8))
    # reset grads, timers
    zero_all_gradients(agent_i)
    timings = {}

    # -------- Phase 1 — μ, Σ (same-level only) --------
    t0 = time.perf_counter()
    accumulate_mu_sigma_gradient(ctx, agent_i, agents, mode="belief")
    timings["mu_sigma_belief"] = time.perf_counter() - t0

    t0 = time.perf_counter()
    accumulate_mu_sigma_gradient(ctx, agent_i, agents, mode="model")
    timings["mu_sigma_model"] = time.perf_counter() - t0

    # -------- Phase 2a — neighbors --------
    t0 = time.perf_counter()
    neighbors = get_neighbors(agent_i, agents)
    
    # -------- Phase 2b — Fisher preconditioners (q/p) -------
    
    for aj in (neighbors or []):
        _ensure_fisher(aj, which="q", generators=generators_q, ctx=ctx, eps=eps_val)
        _ensure_fisher(aj, which="p", generators=generators_p, ctx=ctx, eps=eps_val)
    
    # agent_i (receiver)
    _ensure_fisher(agent_i, which="q", generators=generators_q, ctx=ctx, eps=eps_val)
    _ensure_fisher(agent_i, which="p", generators=generators_p, ctx=ctx, eps=eps_val)
                

    timings["neighbors"] = time.perf_counter() - t0
    timings["neighbors_count"] = len(neighbors) if neighbors else 0  # handy context

    
    # Phase 3 — φ alignment (same-level only)
    if neighbors:
        dt = _alignment_block(agent_i, neighbors, generators_q, field="phi", ctx=ctx)
        timings["phi_alignment"] = dt
    
        dt = _alignment_block(agent_i, neighbors, generators_p, field="phi_model", ctx=ctx)
        timings["phi_tilde_alignment"] = dt


    # -------- Phase 4 — morphism self + feedback (same-level) --------
    dt = _morphism_block(agent_i, generators_q, generators_p, field="phi", ctx=ctx)
    timings["phi_morphism"] = dt

    dt = _morphism_block(agent_i, generators_q, generators_p, field="phi_model", ctx=ctx)
    timings["phi_tilde_morphism"] = dt
      
    dtheta_i = None

    if bool(cfg_get(ctx, "debug_grad_timing", False)):
        aid = _aid(agent_i)
        print(f"\n[GRAD TIMINGS] Agent {aid}")
        # pretty print in a stable order
        for k in ("neighbors","neighbors_count",
                  "mu_sigma_belief","mu_sigma_model",
                  "fisher_q","fisher_p",
                  "phi_alignment","phi_tilde_alignment",
                  "phi_morphism","phi_tilde_morphism"):
            if k in timings:
                v = timings[k]
                if k.endswith("_count"):
                    print(f"  {k:22s} : {int(v)}")
                else:
                    print(f"  {k:22s} : {v*1e3:7.2f} ms")

    return (
        (agent_i.grad_mu_q, agent_i.grad_sigma_q),
        (agent_i.grad_mu_p, agent_i.grad_sigma_p),
        agent_i.grad_phi,
        agent_i.grad_phi_tilde,
        dtheta_i,
    )





def apply_phi_updates(agent, grad_phi, grad_phi_m, mask, *, ctx=None):
    """
    Constant-step φ / φ̃ update (N-D, hypercubic PBC-ready).

    Inputs
      agent.phi        : (*S, 3)
      agent.phi_model  : (*S, 3) or None
      grad_phi         : (*S, 3)
      grad_phi_m       : (*S, 3)  (ignored if agent.phi_model is None)
      mask             : broadcastable to (*S,) (bool or float in [0,1])
    """
    import numpy as np

    # ---- cfg ----
    eta_phi   = float(cfg_get(ctx, "tau_phi", 1e-2))
    eta_phi_m = float(cfg_get(ctx, "tau_phi_model", 1e-2))
    debug     = bool(cfg_get(ctx, "DEBUG_APPLY", False))

    # ---- fields & shapes ----
    phi   = np.asarray(getattr(agent, "phi"), np.float32)          # (*S, 3)
    phi_m = getattr(agent, "phi_model", None)
    if phi_m is not None:
        phi_m = np.asarray(phi_m, np.float32)                      # (*S, 3) or None

    if phi.ndim < 1 or phi.shape[-1] != 3:
        raise ValueError(f"agent.phi must be (*S,3), got {phi.shape}")
    S = phi.shape[:-1]

    gphi  = np.asarray(grad_phi,   np.float32)
    gphim = np.asarray(grad_phi_m, np.float32) if phi_m is not None else None
    if gphi.shape != phi.shape:
        raise ValueError(f"grad_phi shape {gphi.shape} != phi shape {phi.shape}")
    if phi_m is not None and gphim.shape != phi_m.shape:
        raise ValueError(f"grad_phi_m shape {gphim.shape} != phi_model shape {phi_m.shape}")

    # ---- mask: broadcast to (*S,) then expand to (*S,1) ----
    if mask is None:
        mexp = 1.0
    else:
        m = np.asarray(mask, np.float32)
        if m.shape != S:
            # prepend singletons if needed, then broadcast
            pad = (1,) * max(0, len(S) - m.ndim)
            try:
                m = np.broadcast_to(m.reshape(pad + m.shape), S)
            except Exception as e:
                raise ValueError(f"mask shape {m.shape} not broadcastable to {S}") from e
        mexp = m[..., None]  # (*S,1)

    # ---- persist grads on agent (for diagnostics) ----
    agent.grad_phi = np.array(gphi, copy=True)
    if phi_m is not None:
        agent.grad_phi_tilde = np.array(gphim, copy=True)
    else:
        agent.grad_phi_tilde = None

    # ---- updates (mask-aware) ----
    delta_phi = (eta_phi * gphi).astype(np.float32, copy=False) * mexp
    phi_new   = phi - delta_phi

    if phi_m is not None:
        delta_phi_m = (eta_phi_m * gphim).astype(np.float32, copy=False) * mexp
        phim_new    = phi_m - delta_phi_m
    else:
        phim_new = None

    # ---- retract to principal SO(3) chart ----
    agent.phi = retract_phi_principal(phi_new, margin=1e-6)
    if phim_new is not None:
        agent.phi_model = retract_phi_principal(phim_new, margin=1e-6)

    # ---- diagnostics ----
    if debug:
        mean_gphi  = float(np.nanmean(np.linalg.norm(gphi,  axis=-1)))
        mean_gphim = float(np.nanmean(np.linalg.norm(gphim, axis=-1))) if gphim is not None else float("nan")
        print(
            f"[APPLY φ-step] id={getattr(agent, 'id', None)} "
            f"τφ={eta_phi:g}, τφ̃={eta_phi_m:g}, "
            f"|gφ|_mean={mean_gphi:.3e}, |gφ̃|_mean={mean_gphim:.3e}",
            flush=True,
        )

    # ---- mark dirty for transport / KL refresh ----
    if ctx is not None:
        dirty_manager(ctx).mark(agent, kl=True)

def _apply_sigma_masked(ctx, old_S, dS, tau, mask_bool, *, grad_type: str = "tangent"):
    """
    SPD-safe masked Sigma update that integrates exactly one intrinsic step.

    Grad semantics
    --------------
    grad_type = "tangent":   dS is an intrinsic tangent V at Σ (e.g., V = -2 Σ sym(∇) Σ)
    grad_type = "euclidean": dS is a Euclidean gradient ∇ΣL; we convert to tangent internally

    Retraction modes (config: sigma_retraction_mode)
    ------------------------------------------------
      "exp"    : affine-invariant exponential map (default, recommended)
      "linear" : first-order affine-linear step in the whitened tangent

    Trust region (config)
    ---------------------
      sigma_rel_step_max (rho) limits ||R||_F where R = Σ^{-1/2} (τ * V) Σ^{-1/2}
      sigma_skip_trust_region : bool  (NEW) if True, skip clipping of R

    Other config keys
    -----------------
      support_tau               : SPD floor for eigenvalues (default 1e-8)
      sigma_update_gmax         : per-eigen cap for EXP via |log multiplier| (1.0→off)
      sigma_assert_order1_match : print whitened ||R|| diagnostics if True
      sigma_skip_sanitize       : bool  (NEW) if True, do not sanitize on write-back
    """
    import numpy as np
    from runtime_context import cfg_get
    

    # ---------- inputs & checks ----------
    S  = np.asarray(old_S, dtype=np.float32, order="C")
    D  = np.asarray(dS,    dtype=np.float32, order="C")
    mb = np.asarray(mask_bool)

    if S.shape != D.shape:
        raise ValueError(f"_apply_sigma_masked: shape mismatch {S.shape} vs {D.shape}")
    if S.ndim < 2 or S.shape[-1] != S.shape[-2]:
        raise ValueError(f"_apply_sigma_masked: covariance must be square; got {S.shape[-2:]}")
    Sshape, K = S.shape[:-2], int(S.shape[-1])
    if tuple(mb.shape) != Sshape:
        raise ValueError(f"_apply_sigma_masked: mask shape {mb.shape} != spatial shape {Sshape}")
    if not (np.isfinite(S).all() and np.isfinite(D).all()):
        raise FloatingPointError("_apply_sigma_masked: non-finite inputs")

    mb = (mb > 0)
    if not np.any(mb):
        return S

    tau     = float(tau)
    eps_spd = float(cfg_get(ctx, "support_tau", 1e-8))
    rho     = float(cfg_get(ctx, "sigma_rel_step_max", 0.25))
    mode    = str(cfg_get(ctx, "sigma_retraction_mode", "exp")).lower()
    gmax    = float(cfg_get(ctx, "sigma_update_gmax", 1.0))
    logcap  = float(np.log(max(gmax, 1.0)))

    # NEW: fast-path toggles
    skip_trust   = bool(cfg_get(ctx, "sigma_skip_trust_region", False))
    skip_sanitize = bool(cfg_get(ctx, "sigma_skip_sanitize", False))

    if grad_type not in ("tangent", "euclidean"):
        raise ValueError(f"_apply_sigma_masked: unknown grad_type={grad_type!r}")

    # ---------- flatten active ----------
    N   = int(np.prod(Sshape)) if Sshape else 1
    idx = np.flatnonzero(mb.reshape(N))

    Sflat, Dflat = S.reshape(N, K, K), D.reshape(N, K, K)
    S_act = Sflat[idx].astype(np.float64, copy=False)  # (M,K,K) math in f64
    D_act = Dflat[idx].astype(np.float64, copy=False)

    # ---------- intrinsic tangent ----------
    if grad_type == "tangent":
        Delta = tau * 0.5 * (D_act + np.swapaxes(D_act, -1, -2))
    else:
        Dsym  = 0.5 * (D_act + np.swapaxes(D_act, -1, -2))
        V     = -2.0 * np.einsum("...ik,...kl,...lj->...ij", S_act, Dsym, S_act, optimize=True)
        Delta = tau * V

    # ---------- eig(Σ) & whiten ----------
    try:
        w, Q = np.linalg.eigh(S_act)
    except np.linalg.LinAlgError as e:
        raise np.linalg.LinAlgError(f"_apply_sigma_masked: eigh(Σ) failed: {e}") from e
    w = np.clip(w, eps_spd, None)
    Qt       = np.swapaxes(Q, -1, -2)
    sqrt_w   = np.sqrt(w)
    inv_sqrt = 1.0 / sqrt_w

    Deig = np.einsum("...ik,...kl,...jl->...ij", Qt, Delta, Q, optimize=True)
    R    = (inv_sqrt[..., :, None] * Deig) * inv_sqrt[..., None, :]
    R    = 0.5 * (R + np.swapaxes(R, -1, -2))

    # ---------- trust region (optional) ----------
    if not skip_trust:
        Rnorm = np.linalg.norm(R, axis=(-2, -1), keepdims=True)  # (M,1,1)
        clip  = np.minimum(1.0, rho / np.maximum(Rnorm, eps_spd))
        R    *= clip
        if bool(cfg_get(ctx, "sigma_assert_order1_match", False)):
            print(f"[Σ intrinsic step] max ||R||_F = {float(np.max(Rnorm)):.3e}", flush=True)

    # ---------- back-map ----------
    if mode == "linear":
        # Δ_scaled = Σ^{1/2} R Σ^{1/2}   (may break SPD if large; for debugging only)
        Deig_scaled = (sqrt_w[..., :, None] * R) * sqrt_w[..., None, :]
        Delta_scaled = np.einsum("...ik,...kl,...jl->...ij", Q, Deig_scaled, Qt, optimize=True)
        S_new_act = (S_act + Delta_scaled)
    else:
        # EXP map (keeps SPD exactly even with skip_trust)
        lam, U = np.linalg.eigh(R)
        if gmax > 1.0:  # cap only if requested
            lam = np.clip(lam, -logcap, logcap)
        exp_lam = np.exp(lam)
        expR    = (U * exp_lam[..., None, :]) @ np.swapaxes(U, -1, -2)
        eye     = np.eye(K, dtype=np.float64)[None, ...]
        Teig_scaled = (sqrt_w[..., :, None] * (expR - eye)) * sqrt_w[..., None, :]
        Delta_scaled = np.einsum("...ik,...kl,...jl->...ij", Q, Teig_scaled, Qt, optimize=True)
        S_new_act = (S_act + Delta_scaled)  # SPD preserved by exp

    # ---------- finalize ----------
    if not skip_sanitize:
        S_new_act = sanitize_sigma(S_new_act, eps=eps_spd).astype(np.float32, copy=False)
    else:
        S_new_act = S_new_act.astype(np.float32, copy=False)

    out = S.copy()  # f32
    out.reshape(N, K, K)[idx] = S_new_act
    return out







def _apply_children(agents, grads, n_jobs, *, ctx=None):
    """
    Apply per-agent updates for μ/Σ (belief+model) and φ/φ̃ over arbitrary S.
    Frozen levels removed; updates applied wherever mask > 0.
    Hard-fails on shape/finiteness mismatches.
    """
   

    tau_mu_belief    = float(cfg_get(ctx, "tau_mu_belief",    1e-2))
    tau_sigma_belief = float(cfg_get(ctx, "tau_sigma_belief", 1e-2))
    tau_mu_model     = float(cfg_get(ctx, "tau_mu_model",     1e-2))
    tau_sigma_model  = float(cfg_get(ctx, "tau_sigma_model",  1e-2))
    DEBUG_APPLY      = bool(cfg_get(ctx, "DEBUG_APPLY", False))

    (q_updates, p_updates, phi_grads, phi_m_grads) = grads

    # Establish canonical S from first agent’s mask
    S0 = tuple(np.asarray(agents[0].mask).shape)

    def _one(i):
        A = agents[i]
        mask = np.asarray(A.mask, np.float32)
        if tuple(mask.shape) != S0:
            raise ValueError(f"[apply] agent {getattr(A,'id',i)} mask shape {mask.shape} != canonical {S0}")
        mask_mu = mask[..., None]  # broadcast over last feature dim
        
        dmu_q, dsg_q = q_updates[i]
        dmu_p, dsg_p = p_updates[i]

        mu_q_old = np.asarray(A.mu_q_field, np.float32)
        mu_p_old = np.asarray(A.mu_p_field, np.float32)
        sig_q_old = np.asarray(A.sigma_q_field, np.float32)
        sig_p_old = np.asarray(A.sigma_p_field, np.float32)
 
        # Finite checks
        for name, arr in (("mu_q", mu_q_old), ("mu_p", mu_p_old), ("sig_q", sig_q_old), ("sig_p", sig_p_old)):
            if not np.isfinite(arr).all():
                raise FloatingPointError(f"[apply] non-finite in {name} for agent {getattr(A,'id',i)}")

        # Shape checks vs S0
        if mu_q_old.shape[:-1] != S0: raise ValueError(f"[apply] mu_q_field shape {mu_q_old.shape} incompatible with {S0}")
        if mu_p_old.shape[:-1] != S0: raise ValueError(f"[apply] mu_p_field shape {mu_p_old.shape} incompatible with {S0}")
        if sig_q_old.shape[:-2] != S0: raise ValueError(f"[apply] sigma_q_field shape {sig_q_old.shape} incompatible with {S0}")
        if sig_p_old.shape[:-2] != S0: raise ValueError(f"[apply] sigma_p_field shape {sig_p_old.shape} incompatible with {S0}")

        # ---- μ updates (masked) ----
        A.mu_q_field = (mu_q_old + tau_mu_belief * np.asarray(dmu_q, np.float32) * mask_mu).astype(np.float32, copy=False)
        A.mu_p_field = (mu_p_old + tau_mu_model  * np.asarray(dmu_p, np.float32) * mask_mu).astype(np.float32, copy=False)

        # ---- Σ updates (masked, SPD-safe) ----
        A.sigma_q_field = _apply_sigma_masked(ctx, sig_q_old, np.asarray(dsg_q, np.float32),
                                              tau_sigma_belief, mask > 0.0, grad_type="tangent")
        A.sigma_p_field = _apply_sigma_masked(ctx, sig_p_old, np.asarray(dsg_p, np.float32),
                                              tau_sigma_model,  mask > 0.0, grad_type="tangent")

           
        if DEBUG_APPLY:
            dmuq_mean  = float(np.mean(np.abs(A.mu_q_field - mu_q_old)))
            dmup_mean  = float(np.mean(np.abs(A.mu_p_field - mu_p_old)))
            dsigq_mean = float(np.mean(np.abs(A.sigma_q_field - sig_q_old)))
            dsigp_mean = float(np.mean(np.abs(A.sigma_p_field - sig_p_old)))
            print(
                f"[APPLY] id={getattr(A,'id',i)} "
                f"|Δμ_q|={dmuq_mean:.3e} |Δμ_p|={dmup_mean:.3e} "
                f"|ΔΣ_q|={dsigq_mean:.3e} |ΔΣ_p|={dsigp_mean:.3e} "
                f"(τμ_q={tau_mu_belief:g}, τμ_p={tau_mu_model:g}, "
                f"τσ_q={tau_sigma_belief:g}, τσ_p={tau_sigma_model:g})",
                flush=True,
            )

        # ---- φ updates (masked internally) ----
        gp  = phi_grads[i];   gp  = np.zeros_like(A.phi,       dtype=np.float32) if gp  is None else gp
        gpm = phi_m_grads[i]; gpm = np.zeros_like(A.phi_model, dtype=np.float32) if gpm is None else gpm
        apply_phi_updates(A, gp, gpm, mask, ctx=ctx)

        # Mark morphisms dirty only (μ/Σ changes already imply transport recompute elsewhere)
        dirty_manager(ctx).mark_morphism_only(A)

    Parallel(n_jobs=int(n_jobs) if n_jobs is not None else 1, backend="threading", batch_size="auto")(
        delayed(_one)(i) for i in range(len(agents))
    )
    





def _compute_child_grads(ctx, agents, all_agents, Gq, Gp):
    """
    Batch-compute child gradients.
    Returns 5 lists:
      - belief μ/Σ updates
      - model  μ/Σ updates
      - φ grads
      - φ̃ grads
      - per-agent θ grads (or None entries)
    """
    if not agents:
        return ([], [], [], [], [])

    n_jobs = max(1, min(int(cfg_get(ctx, "n_jobs", 1)), len(agents)))

    # Config knobs (no parallel_config; pass to Parallel directly)
    prefer      = str(cfg_get(ctx, "joblib_prefer", "threads"))   # "processes" or "threads"
    max_nbytes  = cfg_get(ctx, "joblib_memmap_threshold", "10M")  # only used by loky
    blas_threads = int(cfg_get(ctx, "blas_threads_per_worker",1))

    with threadpool_limits(blas_threads):
        results = Parallel(
            n_jobs=n_jobs,
            prefer=prefer,          # choose backend via preference
            max_nbytes=max_nbytes,  # memmap threshold for process backend
            batch_size="auto",
        )(
            delayed(compute_all_gradients)(Ai, agents, all_agents, Gq, Gp, runtime_ctx=ctx)
            for Ai in agents
        )

    # unzip -> 5 lists
    q_updates, p_updates, phi_grads, phi_m_grads, dtheta_parts = zip(*results)
    q_updates    = list(q_updates)
    p_updates    = list(p_updates)
    phi_grads    = list(phi_grads)
    phi_m_grads  = list(phi_m_grads)
    dtheta_parts = list(dtheta_parts)

    # optional coupling
    phi_grads = apply_A_phi_covariant_coupling(ctx, agents, phi_grads)

    return (q_updates, p_updates, phi_grads, phi_m_grads, dtheta_parts)




def apply_A_phi_covariant_coupling(ctx, agents, phi_grads):
    """
    A–φ covariant coupling (N-D):
      - Adds covariant frame grad to each child's φ-grad (in BODY coords)
      - Accumulates a single global A grad for the step
      - Records total A_cov energy
    """
    import numpy as np
    from runtime_context import cfg_get
    from core.transport_cache import Jinv_grid, build_dexpinv_matrix
    

    if ctx is None:
        return phi_grads

    use_A   = bool(cfg_get(ctx, "use_global_A", False))
    lam_cov = float(cfg_get(ctx, "lambda_A_cov", 0.0))
    if not (use_A and lam_cov > 0.0):
        if getattr(ctx, "fields", None) is not None:
            ctx.fields["A_grad_accum"] = None
            ctx.fields["A_cov_energy"] = 0.0
        return phi_grads

    # ---- fetch global A consistently ----
    A = getattr(ctx, "fields", {}).get("A", None)   # shape (*S, ndim, 3)
    if A is None:
        raise RuntimeError("Global A missing; ensure_global_A(...) set ctx.fields['A'] before coupling.")

    A_grad_accum = np.zeros_like(A, dtype=np.float32)
    E_cov_total  = 0.0
    out_phi_grads = list(phi_grads)

    # optional anisotropic spacing
    dx = cfg_get(ctx, "grid_dx", 1.0)

    for i, a in enumerate(agents):
        phi_i  = getattr(a, "phi", None)   # (*S,3)
        mask_i = getattr(a, "mask", None)  # (*S,) or (*S,1) or None

        # energy + grads in PARAM coords (algebra), and A-grad
        E_cov, g_phi_cov, gA_cov = covariant_frame_energy_and_grads(
            phi=phi_i,
            A=A,
            weight=lam_cov,
            mask=mask_i,
            dx=dx,               
        )

        # ---- project φ-grad to BODY coords with Jinv^T ----
        Jinv = Jinv_grid(ctx, a, which="q")
        if Jinv is None:
            # fallback (same as elsewhere)
            Jinv = build_dexpinv_matrix(np.asarray(phi_i, np.float32))
        g_body = np.einsum("...ji,...j->...i", Jinv, g_phi_cov, optimize=True)

        gi = out_phi_grads[i]
        out_phi_grads[i] = (np.asarray(gi, np.float32) if gi is not None else 0.0) + g_body

        # accumulate global A-grad and energy
        A_grad_accum += np.asarray(gA_cov, np.float32)
        E_cov_total  += float(E_cov)

    if not hasattr(ctx, "fields") or ctx.fields is None:
        ctx.fields = {}
    ctx.fields["A_grad_accum"] = A_grad_accum if np.any(np.isfinite(A_grad_accum)) else None
    ctx.fields["A_cov_energy"] = float(E_cov_total)

    return out_phi_grads






