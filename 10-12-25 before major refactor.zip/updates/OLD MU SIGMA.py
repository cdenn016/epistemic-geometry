# -*- coding: utf-8 -*-
"""
Created on Sun Oct 12 12:50:02 2025

@author: chris and christine
"""


def old_accum_gamma_AB_energies_for_pair(ctx, agent_i, agent_j, overlap, *, eps=1e-8, write_maps=True):
    """
    Accumulate A/B energies for the directed pair (i <- j), masked to `overlap`.

    Uses caches from `compute_edge_gammas` when present:
      ctx._edge_gamma[("A", j,i)], ctx._edge_klX[("A", j,i)]
      ctx._edge_gamma[("B", i,j)], ctx._edge_klX[("B", i,j)]

    Writes running totals via energy_acc_add:
      "KL_A_raw", "KL_B_raw", "Gamma_A", "Gamma_B"

    If `write_maps=True`, also writes per-pixel maps into ctx.fields:
      "KL_A", "KL_B", "Gamma_A_map", "Gamma_B_map"
    (created on first use with zeros and overwritten on each call for this pair)
    """
    import numpy as np
    from runtime_context import energy_acc_add
    from core.transport_cache import Omega, Phi
    from core.numerical_utils import push_gaussian, kl_gaussian

    i_id = int(getattr(agent_i, "id", -1))
    j_id = int(getattr(agent_j, "id", -1))
    Sshape = tuple(getattr(agent_i, "mu_q_field").shape[:-1])

    if not hasattr(ctx, "fields"):
        ctx.fields = {}

    m = overlap.astype(np.bool_)
    if not np.any(m):
        return

    # ---------- Case A: q_j || Ω^q_ji[Φ̃_i p_i] ----------
    gA = ctx._edge_gamma.get(("A", j_id, i_id), None)
    KL_A = ctx._edge_klX.get(("A", j_id, i_id), None)
    if (gA is not None) or (KL_A is not None):
        # If KL_A missing (toggle path), compute once on the fly
        
        if KL_A is None:
            
            Om_ji = Omega(ctx, agent_j, agent_i, which="q")
            Phit  = Phi(ctx, agent_i, kind="p_to_q")
            mu_phit_i, S_phit_i = push_gaussian(agent_i.mu_p_field, agent_i.sigma_p_field, Phit, eps=eps)[:2]
            mu_t, S_t = push_gaussian(mu_phit_i, S_phit_i, Om_ji, eps=eps)[:2]
            KL_A = kl_gaussian(agent_j.mu_q_field, agent_j.sigma_q_field, mu_t, S_t, eps=eps)
            
        KL_A = np.asarray(KL_A, np.float32)
        
        # gamma_A may be None (if toggle fully off); treat as zeros
        gA = np.zeros(Sshape, np.float32) if gA is None else np.asarray(gA, np.float32)

        # Totals (masked)
        energy_acc_add(ctx, "KL_A_raw", float(np.sum(KL_A[m])))
        energy_acc_add(ctx, "Gamma_A",  float(np.sum((gA * KL_A)[m])))

        if write_maps:
            if "KL_A" not in ctx.fields:        ctx.fields["KL_A"]        = np.zeros(Sshape, np.float32)
            if "Gamma_A_map" not in ctx.fields: ctx.fields["Gamma_A_map"] = np.zeros(Sshape, np.float32)
            # Overwrite at the masked pixels (so the last writer wins for that (i,j); totals are in energy_acc)
            ctx.fields["KL_A"][m]        = KL_A[m]
            ctx.fields["Gamma_A_map"][m] = (gA * KL_A)[m]

    # ---------- Case B: p_i || Φ_i[Ω^q_ij q_j] ----------
    gB = ctx._edge_gamma.get(("B", i_id, j_id), None)
    KL_B = ctx._edge_klX.get(("B", i_id, j_id), None)
    if (gB is not None) or (KL_B is not None):
        
        if KL_B is None:
            Om_ij = Omega(ctx, agent_i, agent_j, which="q")
            Phi_i = Phi(ctx, agent_i, kind="q_to_p")
            mu_t, S_t = push_gaussian(agent_j.mu_q_field, agent_j.sigma_q_field, Om_ij, eps=eps)[:2]
            mu_phi, S_phi = push_gaussian(mu_t, S_t, Phi_i, eps=eps)[:2]
            KL_B = kl_gaussian(agent_i.mu_p_field, agent_i.sigma_p_field, mu_phi, S_phi, eps=eps)
        KL_B = np.asarray(KL_B, np.float32)
        
        gB = np.zeros(Sshape, np.float32) if gB is None else np.asarray(gB, np.float32)

        energy_acc_add(ctx, "KL_B_raw", float(np.sum(KL_B[m])))
        energy_acc_add(ctx, "Gamma_B",  float(np.sum((gB * KL_B)[m])))

        if write_maps:
            if "KL_B" not in ctx.fields:        ctx.fields["KL_B"]        = np.zeros(Sshape, np.float32)
            if "Gamma_B_map" not in ctx.fields: ctx.fields["Gamma_B_map"] = np.zeros(Sshape, np.float32)
            ctx.fields["KL_B"][m]        = KL_B[m]
            ctx.fields["Gamma_B_map"][m] = (gB * KL_B)[m]






def OLD_accumulate_mu_sigma_gradient(ctx, agent_i, agents, mode):
    """
    Accumulate natural gradients (μ, Σ) for belief or model.

    Structure:
      1) Resolve fiber + keys (q/p)
      2) Pull Φ, Φ̃ from cache and push (q,p) once
      3) Self & feedback grads (receiver-only)
      4) Pairwise alignment grads (β ⊙ align  −  (β/κ) KL1 ⊙ β-basis)
      5) Combine -> natural projection -> accumulate to agent_i

    Inputs:
      ctx       : runtime context (required)
      agent_i   : receiver agent
      agents    : full list (for neighbors)
      mode      : {"belief","model"}
    """
    if ctx is None:
        raise RuntimeError("accumulate_mu_sigma_gradient: ctx required.")

    from runtime_context import cfg_get
    
    eps  = float(cfg_get(ctx, "eps", 1e-6))
    tau  = float(cfg_get(ctx, "support_tau", 1e-6))
    alpha = float(cfg_get(ctx, "alpha", 0.0))
    lambd = float(cfg_get(ctx, "feedback_weight", 0.0))

    accum_send = bool(cfg_get(ctx, "accumulate_sender_grads", False))
    
    which, field, mu_key, S_key, gmu_key, gS_key = _fiber_keys_from_mode(mode)

    # ---------------- 2) Φ/Φ̃ pushes once ----------------
    
    Phi  = Phi_cached(ctx, agent_i, kind="q_to_p")   # Φ: Q→P
    Phit = Phi_cached(ctx, agent_i, kind="p_to_q")   # Φ̃: P→Q
    

    mu_q = getattr(agent_i, "mu_q_field")
    S_q  = getattr(agent_i, "sigma_q_field")
    mu_p = getattr(agent_i, "mu_p_field")
    S_p  = getattr(agent_i, "sigma_p_field")

    
    mu_q_push, S_q_push, inv_q_push = push_gaussian(
        mu_q, S_q, Phi, eps=eps, return_inv=True,
        Sigma_inv=getattr(agent_i, "sigma_q_inv", None),
        assume_orthogonal=False
    )
    mu_p_push, S_p_push, inv_p_push = push_gaussian(
        mu_p, S_p, Phit, eps=eps, return_inv=True,
        Sigma_inv=getattr(agent_i, "sigma_p_inv", None),
        assume_orthogonal=False
    )
    
    
    # --- self/feedback ENERGY accounting (unweighted, float64-safe) ---
    accumulate_self_feedback_energies(
        ctx, agent_i,
        mu_q=mu_q, S_q=S_q,
        mu_p=mu_p, S_p=S_p,
        mu_q_push=mu_q_push, S_q_push=S_q_push,
        mu_p_push=mu_p_push, S_p_push=S_p_push,
    )

    
    g_self_mu, g_self_S, g_fb_mu, g_fb_S = _self_and_feedback_grads(
        mode,
        mu_q, S_q, mu_p, S_p,
        mu_q_push, S_q_push, inv_q_push,
        mu_p_push, S_p_push, inv_p_push,
        Phi, Phit, eps,
        sigma_q_inv=getattr(agent_i, "sigma_q_inv", None),
        sigma_p_inv=getattr(agent_i, "sigma_p_inv", None),
        mask=getattr(agent_i, "mask", None),
    )
    
    
   
    # Target buffers (shape-safe, prezeroed)
    mu_i = np.asarray(getattr(agent_i, mu_key), np.float32, order="C")
    S_i  = np.asarray(getattr(agent_i, S_key),  np.float32, order="C")
    dmu_align = np.zeros_like(mu_i, dtype=np.float32)
    dS_align  = np.zeros_like(S_i,  dtype=np.float32)

    if accum_send:
        dmu_align, dS_align = _drain_inbox_into_dalign(agent_i, which, dmu_align, dS_align)
        
    # -------- 4a) Precompute β-weighted average of ALIGN grads for receiver i --------
    Sshape = tuple(getattr(agent_i, mu_key).shape[:-1])
    Ki = int(getattr(agent_i, mu_key).shape[-1])
    gbar_mu_i = np.zeros(Sshape + (Ki,),    np.float32)
    gbar_S_i  = np.zeros(Sshape + (Ki, Ki), np.float32)

    _pairs = []  # stash per-neighbor ingredients to reuse in pass 2

    for agent_j, overlap in _iter_overlap_pairs(agent_i, agents, tau=tau):
        if not np.any(overlap):
            continue

        i_id = int(getattr(agent_i, "id", -1))
        j_id = int(getattr(agent_j, "id", -1))
        beta_map = np.asarray(ctx._edge_beta[(which, i_id, j_id)], np.float32)
        KL1_map  = np.asarray(ctx._edge_kl1 [(which, i_id, j_id)], np.float32)

        m  = overlap.astype(np.float32, copy=False)
        beta_ij = beta_map * m
        KL1     = KL1_map  * m
        if not np.any(beta_ij > 0):
            continue

        # ALIGN transport is on the current fiber
        Om_align = Omega(ctx, agent_i, agent_j, which=which)

        # stats
        mu_i_arr = np.asarray(getattr(agent_i, mu_key), np.float32, order="C")
        S_i_arr  = sanitize_sigma(np.asarray(getattr(agent_i, S_key), np.float64), eps=eps).astype(np.float32, copy=False)
        mu_j_arr = np.asarray(getattr(agent_j, mu_key), np.float32, order="C")
        S_j_arr  = sanitize_sigma(np.asarray(getattr(agent_j, S_key), np.float64), eps=eps).astype(np.float32, copy=False)

        # push & ALIGN grads (these are ∂ L_align_ij)
        mu_j_t, S_j_t, inv_j_t = push_gaussian(mu_j_arr, S_j_arr, Om_align, eps=eps, return_inv=True, sanitize_input=False)
        gmu_align, gS_align = grad_alignment_energy_source(
            mu_i_arr, S_i_arr, mu_j_t, inv_j_t, eps=eps, sigma_i_inv=None, assume_sanitized=True
        )
        gmu_align_j, gS_align_j = grad_alignment_energy_target(
            mu_i=mu_i_arr, sigma_i=S_i_arr,
            mu_j_t=mu_j_t, sigma_j_t_inv=inv_j_t,
            Omega_ij=Om_align, eps=eps, assume_sanitized=True
        )

        # β-weighted receiver-average for product rule
        gbar_mu_i += beta_ij[..., None]       * gmu_align
        gbar_S_i  += beta_ij[..., None, None] * gS_align

        _pairs.append(dict(
            j=agent_j, overlap=overlap, m=m,
            beta_ij=beta_ij, KL1=KL1,
            Om_align=Om_align,
            gmu_align=gmu_align, gS_align=gS_align,
            gmu_align_j=gmu_align_j, gS_align_j=gS_align_j,
        ))

    # -------- 4b) Second pass: exact softmax product rule for β·KL_align --------
    for P in _pairs:
        agent_j = P["j"]; overlap = P["overlap"]; m = P["m"]
        beta_ij = P["beta_ij"]; KL1 = P["KL1"]
        gmu_align   = P["gmu_align"];   gS_align   = P["gS_align"]
        gmu_align_j = P["gmu_align_j"]; gS_align_j = P["gS_align_j"]

        kappa = max(float(cfg_get(ctx, f"beta_kappa_{which}", 1.0)), 1e-12)
        factor = (beta_ij * (KL1 / kappa)).astype(np.float32, copy=False)

        # Receiver i: β * ∂L + (β*KL/κ) * ( ḡ_i - ∂L_ij )
        add_mu_i = beta_ij[..., None]       * gmu_align \
                 + factor[...,  None]       * (gbar_mu_i - gmu_align)
        add_S_i  = beta_ij[..., None, None] * gS_align \
                 + factor[...,  None, None] * (gbar_S_i  - gS_align)

        # Sender j: only j has sender params in L_ij, so avg reduces to β_ij * ∂L_sender
        # ⇒ β*∂L_sender + (β*KL/κ) * (β*∂L_sender - ∂L_sender) = β*∂L_sender + factor*(β-1)*∂L_sender
        add_mu_j = beta_ij[..., None]       * gmu_align_j \
                 + (factor * (beta_ij - 1.0))[..., None]       * gmu_align_j
        add_S_j  = beta_ij[..., None, None] * gS_align_j \
                 + (factor * (beta_ij - 1.0))[..., None, None] * gS_align_j

        # scatter receiver (i)
        dmu_align[overlap] += add_mu_i[overlap]
        dS_align [overlap] += add_S_i [overlap]

        # enqueue sender (j) — j will drain and project on its turn
        if accum_send:
            _add_to_inbox(agent_j, which, add_mu_j, add_S_j, overlap)

        # ---- γ (Case A/B) terms unchanged ----
        g_mu_i_G, g_S_i_G, g_mu_j_G, g_S_j_G = _accum_gamma_mu_sigma_for_pair(
            ctx,
            agent_i, agent_j,
            mu_key=mu_key, S_key=S_key,
            overlap_mask=overlap, eps=eps,
            Phi_i=Phi, Phi_tilde_i=Phit,
            Omega_q_ij=Omega(ctx, agent_i, agent_j, which="q"),
        )
        
        # ---- Track A/B energies (raw KL and gamma-weighted) ----
        _accum_gamma_AB_energies_for_pair(ctx, agent_i, agent_j, overlap, eps=eps, write_maps=True)
        
        
        dmu_align[overlap] += g_mu_i_G[overlap]
        dS_align [overlap] += g_S_i_G [overlap]
        if accum_send:
            _add_to_inbox(agent_j, which, g_mu_j_G, g_S_j_G, overlap)
    
    
    # -------- 5) combine + natural projection --------

    dmu_total = (alpha * g_self_mu + lambd * g_fb_mu + dmu_align).astype(np.float32, copy=False)
    dS_total  = (alpha * g_self_S  + lambd * g_fb_S  + dS_align ).astype(np.float32, copy=False)
    dS_total  = 0.5 * (dS_total + np.swapaxes(dS_total, -1, -2))
    

    delta_mu, delta_S = apply_natural_gradient_batch(
        ctx,
        getattr(agent_i, mu_key), getattr(agent_i, S_key),
        dmu_total, dS_total,
        mask=getattr(agent_i, "mask", None),
        assume_sanitized=True,
        grad_sigma_is_symmetric = True,
        use_float64 = True,
    )
    
    # -------- 6) accumulate to agent --------
    _accumulate_into_agent(agent_i, gmu_key, gS_key, delta_mu, delta_S)

    
    return delta_mu, delta_S

def OLD_accum_align_for_pair_clean(
    ctx,
    agent_i, agent_j,
    *,
    fiber: str,          # 'q' or 'p'
    mu_key: str,
    S_key: str,
    overlap_mask: np.ndarray,
    eps: float,
    gbar_mu_i: np.ndarray,   # PRECOMPUTED β-weighted receiver avg of ALIGN μ-grad
    gbar_S_i:  np.ndarray,   # PRECOMPUTED β-weighted receiver avg of ALIGN Σ-grad
    Phi=None, Phi_tilde=None # kept for API compat; unused when β==align
):
    dbg_pair = False

    i_id = int(getattr(agent_i, "id", -1))
    j_id = int(getattr(agent_j, "id", -1))

    # --- fetch maps (read-only!) ---
    beta_map = np.asarray(ctx._edge_beta[(fiber, i_id, j_id)], np.float32, order="C")
    KL1_map  = np.asarray(ctx._edge_kl1 [(fiber, i_id, j_id)], np.float32, order="C")
    if beta_map.shape != overlap_mask.shape or KL1_map.shape != overlap_mask.shape:
        raise ValueError("β/KL1 map shape mismatch vs overlap")

    m       = overlap_mask.astype(np.float32, copy=False)
    beta_ij = beta_map * m
    KL1     = KL1_map  * m

    # ---------- early return: MUST return 4 tensors ----------
    if not np.any(beta_ij > 0):
        Sshape = tuple(overlap_mask.shape)
        Ki = int(getattr(agent_i, mu_key).shape[-1])
        Kj = int(getattr(agent_j, mu_key).shape[-1])
        zero_mu_i = np.zeros(Sshape + (Ki,),    np.float32)
        zero_S_i  = np.zeros(Sshape + (Ki, Ki), np.float32)
        zero_mu_j = np.zeros(Sshape + (Kj,),    np.float32)
        zero_S_j  = np.zeros(Sshape + (Kj, Kj), np.float32)
        return zero_mu_i, zero_S_i, zero_mu_j, zero_S_j

    # ---------- transports ----------
    Om_align = Omega(ctx, agent_i, agent_j, which=fiber)

    # ---------- receiver/sender stats ----------
    mu_i = np.asarray(getattr(agent_i, mu_key), np.float32, order="C")
    S_i  = sanitize_sigma(np.asarray(getattr(agent_i, S_key), np.float64), eps=eps).astype(np.float32, copy=False)
    mu_j = np.asarray(getattr(agent_j, mu_key), np.float32, order="C")
    S_j  = sanitize_sigma(np.asarray(getattr(agent_j, S_key), np.float64), eps=eps).astype(np.float32, copy=False)

    # ---------- ALIGN push & ALIGN grads ----------
    mu_j_t, S_j_t, inv_j_t = push_gaussian(mu_j, S_j, Om_align, eps=eps, return_inv=True, sanitize_input=False)

    # Receiver ALIGN ∂L_ij
    gmu_align, gS_align = grad_alignment_energy_source(
        mu_i, S_i, mu_j_t, inv_j_t, eps=eps, sigma_i_inv=None, assume_sanitized=True
    )
    # Sender ALIGN ∂L_ij^(sender)
    gmu_align_j, gS_align_j = grad_alignment_energy_target(
        mu_i=mu_i, sigma_i=S_i,
        mu_j_t=mu_j_t, sigma_j_t_inv=inv_j_t,
        Omega_ij=Om_align, eps=eps, assume_sanitized=True
    )

    # ---------- exact softmax product rule (β == align) ----------
    kappa = max(float(cfg_get(ctx, f"beta_kappa_{fiber}", 1.0)), 1e-12)
    factor = (beta_ij * (KL1 / kappa)).astype(np.float32, copy=False)

    # Receiver i: β * ∂L + (β*KL/κ) * ( ḡ_i - ∂L_ij )
    gmu_i = beta_ij[..., None]       * gmu_align \
          + factor[...,  None]       * (gbar_mu_i - gmu_align)
    gS_i  = beta_ij[..., None, None] * gS_align \
          + factor[...,  None, None] * (gbar_S_i  - gS_align)

    # Sender j: β * ∂L_sender + (β*KL/κ) * (β-1) * ∂L_sender
    scale_sender = (factor * (beta_ij - 1.0)).astype(np.float32, copy=False)
    gmu_j = beta_ij[..., None]       * gmu_align_j + scale_sender[..., None]       * gmu_align_j
    gS_j  = beta_ij[..., None, None] * gS_align_j  + scale_sender[..., None, None] * gS_align_j

    # --- add gamma (A/B) terms (they have their own product rule internally) ---
    g_mu_i_G, g_S_i_G, g_mu_j_G, g_S_j_G = _accum_gamma_mu_sigma_for_pair(
        ctx,
        agent_i, agent_j,
        mu_key=mu_key, S_key=S_key,
        overlap_mask=overlap_mask, eps=eps,
        Phi_i=None, Phi_tilde_i=None,          # γ uses Ω^q & Φ/Φ̃ internally
        Omega_q_ij=Omega(ctx, agent_i, agent_j, which="q"),
    )
    
    gmu_i += g_mu_i_G
    gS_i  += g_S_i_G
    gmu_j += g_mu_j_G
    gS_j  += g_S_j_G

    if dbg_pair:
        print(f"[PAIR MAG i] fiber={fiber} i={i_id} j={j_id} "
              f"| align μ={_mu_mag(gmu_i):.3e} Σ={_S_mag(gS_i):.3e}", flush=True)

    return gmu_i.astype(np.float32, copy=False), gS_i.astype(np.float32, copy=False), \
           gmu_j.astype(np.float32, copy=False), gS_j.astype(np.float32, copy=False)


