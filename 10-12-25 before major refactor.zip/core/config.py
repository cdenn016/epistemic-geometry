F = False
T = True

freeze_omega_mode           = "none"     # "none" | "identity" 
agent_seed                  = 241 
morphism_identity_if_square = T

gamma_A_off                 = T
gamma_B_off                 = T


accumulate_sender_grads     = T

use_global_A                = T
# ===========================
# DOMAIN / SPATIAL SETTINGS
# ===========================

sigma_retraction_mode       = "exp"   #"exp" or "linear"
sigma_rel_step_max          = 1e-1


ell_q                       = 3
ell_p                       = 3

spec_q                      = [(ell_q, 1)]   # list[(ell, multiplicity)]
spec_p                      = [(ell_p, 1)]

mix_generators_q            = F
mix_generators_p            = F
                
D                           = 2           # dimension of base manifold
L                           = 20         # length of hypercubic base-manifold - PBCs

steps                       = 500

N                           = 3                    # Number of agents
max_neighbors               = 3            # Max number of agent neighbors

n_jobs                      = 8

agent_radius_range          = (4,4)         #agent radii
fixed_location              = T 



# ===========================
# COUPLINGS & PENALTIES
# ===========================

alpha                   = 1
feedback_weight         = 0

beta_kappa_q            = 1              # κ in exp(-KL/κ)
beta_kappa_p            = 1
kappa_gamma_q           = 1
kappa_gamma_p           = 1


A_init_scale            = 1e-2        # small noise so grads aren’t identically zero
lambda_A_curv           = 1e-2
lambda_A_cov            = 1e-2

#======================
#
#   LEARNING RATES
#
#======================
tau_phi                 = 1e-2
tau_phi_model           = 1e-2    
tau_mu_belief           = 1e-2       
tau_sigma_belief        = 1e-2       
tau_mu_model            = 1e-2      
tau_sigma_model         = 1e-2      

A_lr                    = 1e-2

# ===========================
# INITIALIZATION
# ===========================

# ─── Belief Bundle (q) Parameters ───
q_mu_range              = (-1.0, 1.0)              # Range for μ_q
q_sigma_range           = (0.2, 1.0)           # Diagonal Σ_q entries

# ─── Model Bundle (p) Parameters ───
p_mu_range              = (-1.0, 1.0)             # Range for μ_p
p_sigma_range           = (0.2, 1.0)           # Diagonal Σ_p entries


phi_init_smooth_sigma   = 2.0
phi_init                = 0.35
phi_model_offset        = 0.25

# ===========================
# MASK & INTERACTION THRESHOLDS
# ===========================
 
overlap_eps             = 1e-6     # Threshold for computing inter-agent overlap
support_tau             = 1e-6           #  # Mask threshold to include point in agent support

# ===== DEBUG / DIAGNOSTICS =====

debug_phase_timing      = F
debug_grad_timing       = F

#================================
#
#  INITIALIZE GLOBAL FIELDS 
#      WITH GENTLE NOISE
#================================

diagonal_sigma            = F
identical_models          = F         # If True, all agents share the same model gauge frame

# ===========================
# STABILITY AND CLIPPING
# ===========================
   
gradient_clip_phi         = -1     # clip ‖∇φ‖ per pixel to ≤ 1.0
gradient_clip_phi_model   = -1     # same for φ̃

A_grad_clip               = -1

# ===========================
# EPSILONS & NUMERICAL STABILITY
# ==========================

eps                       = 1e-8 #numerical general purpose eps

num_cores                 = 1  # or however many threads you want to use
domain_size               = (L,) * D


