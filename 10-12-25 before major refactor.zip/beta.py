# -*- coding: utf-8 -*-
"""
Created on Sat Sep 27 15:19:10 2025

@author: chris and christine

Case A:  KL( q_j ||Ω^q_ji Φ̃_i p_i )
Case B:  KL( p_i || Φ_i Ω^q_ij[q_j] )  

Case C: KL( Φ̃_i p_i  ||  Ω^q_ij q_j )  is dual to case B - we dont code
Case D: KL( Ω^q_ij  q_j || Φ̃_i  p_i )  is dual to case A - we dont code

Default beta_q:  KL( q_i || Ω^q_ij q_j )
Default beta_p:  KL( p_i || Ω^p_ij p_j ) 

later implement gamma_q and gamma_p weights for the Case A and B KL as action terms

"""

import numpy as np
from core.numerical_utils import sanitize_sigma, kl_gaussian, push_gaussian
from core.transport_cache import Omega, E_grid, Phi
from utils import _beta_cfg, _assert_finite


_TINY32 = np.finfo(np.float32).tiny
_LOG_TINY64 = np.log(np.finfo(np.float64).tiny)



# ──────────────────────────────────────────────────────────────────────────────
# Main entry
# ──────────────────────────────────────────────────────────────────────────────

def compute_edge_betas(ctx, agents, *, which="q"):
    """
    Per-edge maps for a single fiber ('q' or 'p'), using *alignment* KL only:

        ctx._edge_kl1[(which,i,j)]  = KL_ij   (alignment KL; 0 off-overlap)
        ctx._edge_beta[(which,i,j)] = β_ij    (per-pixel attention; softmax over senders)

    β construction (align-only):
      For each receiver i and sender j:
        if which == "q": KL_ij = KL(q_i || Ω^q_ij q_j)   (Q_i frame)
        if which == "p": KL_ij = KL(p_i || Ω^p_ij p_j)   (P_i frame)

      Mask off-overlap pixels (logits=-inf → weight 0), then
        β_ij(x) = softmax_j( -KL_ij(x) / κ )  per pixel.
    """
    import numpy as np

    if which not in ("q", "p"):
        raise ValueError("compute_edge_betas: which must be 'q' or 'p'")

    if not hasattr(ctx, "cache") or ctx.cache is None:
        raise RuntimeError("compute_edge_betas: ctx.cache missing (ensure runtime_ctx was initialized this step)")

    # ensure maps
    ctx._edge_kl1  = getattr(ctx, "_edge_kl1",  {})
    ctx._edge_beta = getattr(ctx, "_edge_beta", {})

    # config / accessors
    kappa, eps, tau = _beta_cfg(ctx, which)  # basis is ignored; we always use align_* now
    _mu, _S, _mask, _mu_q, _S_q, _mu_p, _S_p = _fiber_accessors(which)

    ids = [int(getattr(a, "id", i)) for i, a in enumerate(agents)]

    # ---------------- per-receiver loop ----------------
    for i_idx, ai in enumerate(agents):
        i_id = ids[i_idx]
        Sshape = _mu(ai).shape[:-1]

        logits_list, mask_list, send_ids = [], [], []
        kl1_store = {}

        mi = _mask(ai)
        for j_idx, aj in enumerate(agents):
            if j_idx == i_idx:
                continue
            j_id = ids[j_idx]

            mj = _mask(aj)
            joint = (mi > tau) & (mj > tau)
            try:
                joint = np.broadcast_to(joint, Sshape)
            except Exception as e:
                raise ValueError(f"mask broadcast failed (i={i_id}, j={j_id})") from e
            if not np.any(joint):
                continue

            # --- Alignment KL only ---
            if which == "q":
                # KL(q_i || Ω^q_ij q_j)
                Om = Omega(ctx, ai, aj, which="q")
                mu_i, S_i = _mu_q(ai), _S_q(ai)
                mu_j, S_j = _mu_q(aj), _S_q(aj)
            else:
                # KL(p_i || Ω^p_ij p_j)
                Om = Omega(ctx, ai, aj, which="p")
                mu_i, S_i = _mu_p(ai), _S_p(ai)
                mu_j, S_j = _mu_p(aj), _S_p(aj)

            mu_j_t, S_j_t = push_gaussian(mu_j, S_j, Om, eps=eps)[:2]
            KL_ij = kl_gaussian(mu_i, S_i, mu_j_t, S_j_t)

            # Force scalar-per-pixel by summing any trailing dims
            if KL_ij.shape != Sshape:
                if KL_ij.shape[:len(Sshape)] == Sshape and KL_ij.ndim > len(Sshape):
                    KL_ij = KL_ij.reshape(Sshape + (-1,)).sum(axis=-1)
                else:
                    raise ValueError(f"KL dims {KL_ij.shape} incompatible with {Sshape}")

            KL_ij = KL_ij.astype(np.float32, copy=False)
            kl1_zeroed = np.where(joint, KL_ij, 0.0).astype(np.float32, copy=False)

            logit = np.where(joint, -KL_ij / kappa, -np.inf)
            logits_list.append(logit)
            mask_list.append(joint)
            send_ids.append(j_id)
            kl1_store[(which, i_id, j_id)] = kl1_zeroed

        if not send_ids:
            continue

        L = np.stack(logits_list, axis=0)  # (J,*S)
        M = np.stack(mask_list,   axis=0)  # (J,*S)
        W = _softmax_over_senders(L, M, tiny=1e-12)  # (J,*S)

        # write back per sender
        for s, j_id in enumerate(send_ids):
            beta_ij = np.where(mask_list[s], W[s], 0.0).astype(np.float32, order="C")
            _assert_finite("beta", beta_ij, f"(i={i_id}, j={j_id})")

            ctx._edge_beta[(which, i_id, j_id)] = beta_ij
            ctx._edge_kl1 [(which, i_id, j_id)] = kl1_store[(which, i_id, j_id)]

    return ctx  # convenient for chaining/tests




def compute_edge_gammas(ctx, agents, *, kappa_q=None, kappa_p=None, eps=1e-8):
    """
    Build gamma maps for all directed pairs (i,j).

    Case A (store under ("A", j_id, i_id)):  γ_A(j→i, x) = exp( - KL(q_j || Ω^q_ji[ Φ̃_i p_i ]) / kappa_q )
    Case B (store under ("B", i_id, j_id)):  γ_B(i→j, x) = exp( - KL(p_i || Φ_i[ Ω^q_ij q_j ]) / kappa_p )

    Also stores KL maps in ctx._edge_klX with same keys for diagnostics.
    Respects toggles: gamma_A_off / gamma_B_off.
    Always writes an entry per directed edge with the correct spatial shape.
    """
    import numpy as np
    from runtime_context import cfg_get
    from core.transport_cache import Omega
    from core.numerical_utils import push_gaussian, kl_gaussian

    if not agents:
        # reset caches to avoid stale values
        ctx._edge_gamma = {}
        ctx._edge_klX   = {}
        return ctx

    # fresh caches every call
    ctx._edge_gamma = {}
    ctx._edge_klX   = {}

    eps = float(eps)
    tau = float(cfg_get(ctx, "support_tau", 1e-6))
    kq  = float(cfg_get(ctx, "kappa_gamma_q", 1.0) if kappa_q is None else kappa_q)
    kp  = float(cfg_get(ctx, "kappa_gamma_p", 1.0) if kappa_p is None else kappa_p)
    A_off = bool(cfg_get(ctx, "gamma_A_off", False))
    B_off = bool(cfg_get(ctx, "gamma_B_off", False))

    # stable ids, shapes
    ids = [int(getattr(a, "id", i)) for i, a in enumerate(agents)]

    # Pre-read masks & shapes (q-grid)
    masks = []
    q_shapes = []
    for a in agents:
        mi = np.asarray(getattr(a, "mask"), np.float32)
        Sshape = tuple(np.asarray(getattr(a, "mu_q_field")).shape[:-1])
        if mi.shape != Sshape:
            mi = np.broadcast_to(mi, Sshape)
        masks.append(mi)
        q_shapes.append(Sshape)

    # Outer loop over receivers
    for i_idx, ai in enumerate(agents):
        i_id = ids[i_idx]

        # preload transforms per receiver
        Phi_i  = np.asarray(Phi(ctx, ai, kind="q_to_p"), np.float64)   # Φ_i : Q→P
        Phit_i = np.asarray(Phi(ctx, ai, kind="p_to_q"), np.float64)   # Φ̃_i: P→Q

        # stats used in KL_B target (receiver p)
        mu_p_i = np.asarray(getattr(ai, "mu_p_field"))
        S_p_i  = np.asarray(getattr(ai, "sigma_p_field"))

        mi = masks[i_idx]

        # Inner loop over senders
        for j_idx, aj in enumerate(agents):
            if j_idx == i_idx:
                continue
            j_id = ids[j_idx]

            mj = masks[j_idx]
            # joint overlap on q-fiber spatial grid (both γ terms are built via Ω^q)
            try:
                joint = (mi > tau) & (mj > tau)
                Sshape = q_shapes[j_idx]  # sender q-shape; broadcasted to match receiver if needed
                joint = np.broadcast_to(joint, Sshape)
            except Exception as e:
                raise ValueError(f"gamma mask broadcast failed (i={i_id}, j={j_id})") from e

            # Always write entries so downstream never sees missing keys
            if not np.any(joint):
                Z = np.zeros(Sshape, np.float32)
                ctx._edge_gamma[("A", j_id, i_id)] = Z
                ctx._edge_gamma[("B", i_id, j_id)] = Z
                # Do not store KL maps when no overlap
                continue

            # --------- Case A: γ_A(j→i) uses Ω^q_ji and Φ̃_i p_i ----------
            if A_off:
                ctx._edge_gamma[("A", j_id, i_id)] = np.zeros(Sshape, np.float32)
            else:
                Om_ji_q = Omega(ctx, aj, ai, which="q")  # sender->receiver on q
                # Φ̃_i p_i
                mu_phit_i, S_phit_i = push_gaussian(mu_p_i, S_p_i, Phit_i, eps=eps)[:2]
                # Ω^q_ji[Φ̃_i p_i]
                mu_phit_i_t, S_phit_i_t = push_gaussian(mu_phit_i, S_phit_i, Om_ji_q, eps=eps)[:2]
                # KL(q_j || ⋯)
                KL_A_full = kl_gaussian(
                    np.asarray(getattr(aj, "mu_q_field")),
                    np.asarray(getattr(aj, "sigma_q_field")),
                    mu_phit_i_t, S_phit_i_t, eps=eps
                )
                # ensure per-pixel scalar
                if KL_A_full.shape != Sshape:
                    if KL_A_full.shape[:len(Sshape)] == Sshape and KL_A_full.ndim > len(Sshape):
                        KL_A = KL_A_full.reshape(Sshape + (-1,)).sum(axis=-1)
                    else:
                        raise ValueError(f"KL_A dims {KL_A_full.shape} incompatible with {Sshape}")
                else:
                    KL_A = KL_A_full
                KL_A = KL_A.astype(np.float32, copy=False)
                # Mask both KL and γ off-overlap (γ==0 off-overlap, not 1)
                gamma_A = np.where(joint, np.exp(-KL_A / max(kq, eps)), 0.0).astype(np.float32, copy=False)
                
                KL_A_out = np.where(joint, KL_A, 0.0).astype(np.float32, copy=False)

                ctx._edge_gamma[("A", j_id, i_id)] = gamma_A
                ctx._edge_klX  [("A", j_id, i_id)] = KL_A_out

            # --------- Case B: γ_B(i→j) uses Ω^q_ij then Φ_i ----------
            if B_off:
                ctx._edge_gamma[("B", i_id, j_id)] = np.zeros(Sshape, np.float32)
            else:
                Om_ij_q = Omega(ctx, ai, aj, which="q")  # receiver->sender on q
                # Ω^q_ij[q_j]
                mu_qj_t, S_qj_t = push_gaussian(
                    np.asarray(getattr(aj, "mu_q_field")),
                    np.asarray(getattr(aj, "sigma_q_field")),
                    Om_ij_q, eps=eps
                )[:2]
                # Φ_i[⋯]
                mu_phi_i, S_phi_i = push_gaussian(mu_qj_t, S_qj_t, Phi_i, eps=eps)[:2]
                # KL(p_i || ⋯)
                KL_B_full = kl_gaussian(mu_p_i, S_p_i, mu_phi_i, S_phi_i, eps=eps)
                if KL_B_full.shape != Sshape:
                    if KL_B_full.shape[:len(Sshape)] == Sshape and KL_B_full.ndim > len(Sshape):
                        KL_B = KL_B_full.reshape(Sshape + (-1,)).sum(axis=-1)
                    else:
                        raise ValueError(f"KL_B dims {KL_B_full.shape} incompatible with {Sshape}")
                else:
                    KL_B = KL_B_full
                KL_B = KL_B.astype(np.float32, copy=False)
                gamma_B = np.where(joint, np.exp(-KL_B / max(kp, eps)), 0.0).astype(np.float32, copy=False)
                KL_B_out = np.where(joint, KL_B, 0.0).astype(np.float32, copy=False)

                ctx._edge_gamma[("B", i_id, j_id)] = gamma_B
                ctx._edge_klX  [("B", i_id, j_id)] = KL_B_out

    return ctx




# ──────────────────────────────────────────────────────────────────────────────
# Accessors / config helpers
# ──────────────────────────────────────────────────────────────────────────────

def _fiber_accessors(which: str):
    """Return closures to get μ, Σ, and mask for active fiber, plus q/p helpers."""
    if which not in ("q", "p"):
        raise ValueError("_fiber_accessors: which must be 'q' or 'p'")

    def _mu(a):
        return np.asarray(getattr(a, "mu_q_field" if which == "q" else "mu_p_field"), np.float32)

    def _S(a):
        base = getattr(a, "sigma_q_field" if which == "q" else "sigma_p_field")
        return sanitize_sigma(np.asarray(base, np.float64))

    def _mask(a):
        m = np.asarray(getattr(a, "mask"), np.float32)
        if m.ndim >= 1 and m.shape[-1] == 1:
            m = m[..., 0]
        return m

    # helpers for the "other" fiber (used by A–D bases)
    def _mu_q(a): return np.asarray(getattr(a, "mu_q_field"), np.float32)
    def _S_q(a):  return sanitize_sigma(np.asarray(getattr(a, "sigma_q_field"), np.float64))
    def _mu_p(a): return np.asarray(getattr(a, "mu_p_field"), np.float32)
    def _S_p(a):  return sanitize_sigma(np.asarray(getattr(a, "sigma_p_field"), np.float64))

    return _mu, _S, _mask, _mu_q, _S_q, _mu_p, _S_p





# ──────────────────────────────────────────────────────────────────────────────
# KL builders
# ──────────────────────────────────────────────────────────────────────────────
def _softmax_over_senders(logits: np.ndarray, mask: np.ndarray, tiny: float = 1e-12):
    """
    Masked softmax over axis 0 (senders). Shapes (J,*S).
    - Zero weights where no sender is valid at a pixel.
    - NaN/±inf-safe under strict np.seterr.
    - Underflow-safe when casting to float32: clamp subnormals to 0 then renormalize.
    """
    

    L = np.asarray(logits, np.float64)
    M = np.asarray(mask, dtype=bool)

    # valid := on-mask AND finite
    valid = M & np.isfinite(L)
    any_valid = np.any(valid, axis=0, keepdims=True)  # (1,*S)

    # Max over valid entries; -inf where none are valid
    L_masked = np.where(valid, L, -np.inf)
    Lmax = np.max(L_masked, axis=0, keepdims=True)
    Lmax_safe = np.where(np.isfinite(Lmax), Lmax, 0.0)  # avoid (-inf)-(-inf)

    with np.errstate(invalid='ignore', over='ignore', under='ignore'):
        shifted = L - Lmax_safe
        shifted = np.where(valid, shifted, -np.inf)
        expL = np.exp(shifted)
        expL = np.where(valid, expL, 0.0)

    Z = np.sum(expL, axis=0, keepdims=True)
    Z = np.where(any_valid, np.maximum(Z, tiny), 1.0)

    W = expL / Z
    W = np.where(any_valid, W, 0.0)

    # ---- Underflow-safe cast to float32 ----
    # Clamp subnormals to zero, then renormalize across senders.
    tiny32 = np.finfo(np.float32).tiny  # ~1.1754944e-38
    W = np.where(W < tiny32, 0.0, W)

    sumW = np.sum(W, axis=0, keepdims=True)
    # If we zeroed some tiny entries, re-normalize to keep sum=1 where valid
    sumW_safe = np.where(any_valid, np.maximum(sumW, 1.0), 1.0)
    W = np.where(any_valid, W / sumW_safe, 0.0)

    # Now casting cannot underflow (we only have zeros or >= tiny32)
    return W.astype(np.float32, copy=False)











