# -*- coding: utf-8 -*-
"""
Created on Sun Aug 10 13:33:30 2025

@author: chris and christine
"""

import numpy as np
from bundle_morphism_utils import safe_batch_apply_morphism_nat
from generalized_diagnostics_metrics import kl_divergence
from numerical_utils import sanitize_sigma, safe_inv

import numpy as np
from bundle_morphism_utils import safe_batch_apply_morphism_nat
from numerical_utils import sanitize_sigma, safe_inv

def xscale_q_up_step(children, parents, labels,
                     beta=0.2, lr_mu=0.1, lr_sigma=0.05, eps=1e-6,
                     clip_mu=None, clip_S=None):
    """
    One gradient step to reduce KL(q_child || Λ_dn_q q_parent) for each child.
    Updates μ_q, Σ_q of CHILDREN only. Leaves Λ_dn_q fixed (identity is fine).
    """
    labels = np.asarray(labels)
    for ci, c in enumerate(children):
        pid = int(labels[ci]) if labels[ci] >= 0 else -1
        if pid < 0:  # noise/unassigned
            continue
        p = parents[pid]

        Kq = c.mu_q_field.shape[-1]
        L = getattr(p, "Lambda_dn_q", None)
        if L is None:
            L_field = np.broadcast_to(np.eye(Kq, dtype=c.mu_q_field.dtype),
                                      c.mu_q_field.shape[:2] + (Kq, Kq))
        else:
            L = np.asarray(L)
            L_field = np.broadcast_to(L, c.mu_q_field.shape[:2] + L.shape) if L.ndim == 2 else L

        mu_t, S_t = safe_batch_apply_morphism_nat(p.mu_q_field, p.sigma_q_field, L_field, eps=eps)
        mu_c, S_c = c.mu_q_field, sanitize_sigma(c.sigma_q_field, eps=eps)
        S_t = sanitize_sigma(S_t, eps=eps)

        S_t_inv = safe_inv(S_t, eps=eps)
        S_c_inv = safe_inv(S_c, eps=eps)

        # ∂/∂μ_c KL(N(μ_c,S_c) || N(μ_t,S_t)) = S_t^{-1}(μ_c − μ_t)
        g_mu = np.einsum('...ij,...j->...i', S_t_inv, (mu_c - mu_t))
        # ∂/∂S_c KL = ½(S_t^{-1} − S_c^{-1})
        g_S  = 0.5 * (S_t_inv - S_c_inv)

        m = ((c.mask > eps) & (p.mask > eps))[..., None]
        dmu = -beta * lr_mu    * g_mu * m
        dS  = -beta * lr_sigma * g_S

        if clip_mu is not None:
            dmu = np.clip(dmu, -clip_mu, clip_mu)
        if clip_S is not None:
            dS  = np.clip(dS, -clip_S, clip_S)

        mu_new = mu_c + dmu
        S_new  = S_c + dS
        S_new  = 0.5*(S_new + np.swapaxes(S_new, -1, -2))
        S_new  = sanitize_sigma(S_new, eps=eps)

        c.mu_q_field    = mu_new
        c.sigma_q_field = S_new

# update_crossscale_terms.py
import numpy as np
from numerical_utils import sanitize_sigma, safe_inv
from bundle_morphism_utils import safe_batch_apply_morphism_nat

# update_crossscale_terms.py
import numpy as np
from numerical_utils import sanitize_sigma, safe_inv
from bundle_morphism_utils import safe_batch_apply_morphism_nat

def xscale_q_dn_step(children, parents, labels,
                     beta=0.2, lr_mu=0.08, lr_sigma=0.04, eps=1e-6):
    """
    Parent-side step: for each parent p, compute a mask-weighted average target
    from its children pushed UP via Λ_up_q, then descend KL(q_parent || target).
    """
    labels = np.asarray(labels)

    # group children per parent id
    parent_to_kids = {}
    for ci, pid in enumerate(labels):
        if pid >= 0:
            pid = int(pid)
            parent_to_kids.setdefault(pid, []).append(ci)

    for pid, kid_ids in parent_to_kids.items():
        if not kid_ids:
            continue

        p = parents[pid]
        H, W, K = p.mu_q_field.shape

        # Λ_up_q (global KxK or per-pixel (H,W,K,K))
        L = getattr(p, "Lambda_up_q", None)
        if L is None:
            L_field = np.broadcast_to(np.eye(K, dtype=p.mu_q_field.dtype), (H, W, K, K))
        else:
            L = np.asarray(L)
            L_field = np.broadcast_to(L, (H, W) + L.shape) if L.ndim == 2 else L  # (H,W,K,K)

        # accumulators (correct shapes)
        mu_acc = np.zeros((H, W, K),   dtype=p.mu_q_field.dtype)
        S_acc  = np.zeros((H, W, K, K), dtype=p.sigma_q_field.dtype)
        w_sum  = np.zeros((H, W, 1),    dtype=p.mu_q_field.dtype)

        # push each child up and accumulate with mask weights
        for ci in kid_ids:
            c = children[ci]
            mu_u, S_u = safe_batch_apply_morphism_nat(c.mu_q_field, c.sigma_q_field, L_field, eps=eps)
            w = c.mask[..., None]                   # (H,W,1)
            mu_acc += w * mu_u                      # (H,W,K)
            S_acc  += w[..., None] * S_u            # (H,W,1,1) * (H,W,K,K) → (H,W,K,K)
            w_sum  += w

        # finalize weighted averages (avoid divide-by-zero)
        w_safe   = np.maximum(w_sum, eps)           # (H,W,1)
        w_safe_S = w_safe[..., None]                # (H,W,1,1)

        mu_t = mu_acc / w_safe                      # (H,W,K)
        S_t  = sanitize_sigma(S_acc / w_safe_S, eps=eps)  # (H,W,K,K)

        # parent fields & grads
        mu_p = p.mu_q_field
        S_p  = sanitize_sigma(p.sigma_q_field, eps=eps)

        S_t_inv = safe_inv(S_t, eps=eps)
        S_p_inv = safe_inv(S_p, eps=eps)

        # ∂/∂μ_p KL(N(μ_p,S_p) || N(μ_t,S_t)) = S_t^{-1}(μ_p − μ_t)
        g_mu = np.einsum('...ij,...j->...i', S_t_inv, (mu_p - mu_t))
        # ∂/∂S_p KL = ½(S_t^{-1} − S_p^{-1})
        g_S  = 0.5 * (S_t_inv - S_p_inv)

        # restrict updates to the parent’s support
        m = (p.mask > eps)[..., None]
        mu_new = mu_p - beta * lr_mu    * g_mu * m
        S_new  = S_p  - beta * lr_sigma * g_S
        S_new  = 0.5 * (S_new + np.swapaxes(S_new, -1, -2))
        S_new  = sanitize_sigma(S_new, eps=eps)

        p.mu_q_field    = mu_new
        p.sigma_q_field = S_new
