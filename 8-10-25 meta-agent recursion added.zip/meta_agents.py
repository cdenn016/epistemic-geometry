# ────────────────────────
# Core + standard libraries
# ────────────────────────
import itertools as it
import json
from pathlib import Path
from copy import deepcopy
import os
# ────────────────────────
# Scientific libraries
# ────────────────────────
import numpy as np
import matplotlib.pyplot as plt
from matplotlib import cm
import networkx as nx

# ────────────────────────
# Project configuration
# ────────────────────────
import config
from config import checkpoint_dir, group_name, K_q, K_p, log_eps, overlap_eps
from generalized_simulation import run_simulation
# ────────────────────────
# IO + data handling
# ────────────────────────
from generalized_io_utils import (
    load_final_step,
    load_agents,
    save_generic_alignment_data,
    save_meta_agents,
    load_meta_agents,
    save_meta_labels,
    load_meta_data,
)

# ────────────────────────
# Core modules
# ────────────────────────
from get_generators import get_generators
from generalized_agent_schema import Agent


# ────────────────────────
# Meta-agent diagnostics
# ────────────────────────
from meta_agent_utils import (
    procrustes_seed_lambda_dn_q,
    build_runtime_params_for_xscale,
    compute_symmetric_kl_matrix,
    overlap_area_matrix,
    curvature_mean_per_agent,
    rank_agent_alignment,
    aggregate_fields,
    aggregate_mask,
    
)
from meta_agent_plots import (
    plot_cluster_size_hist,
    plot_child_parent_overlay,
    compute_avg_crossscale_kl_q,
    plot_crossscale_kl_hist,
)
from generalized_diagnostics_metrics import compute_pairwise_kl_belief, compute_pairwise_kl_model
from meta_agent_plots import (
    plot_matrix,
    plot_generic_alignment_network,
    plot_intra_kl_distribution,
    plot_inter_vs_intra,
    plot_cluster_order_parameters,
    plot_spatial_cluster_map,
    plot_curvature_heatmap,
)

from meta_agent_utils import (
    compute_cluster_kl_stats,
    compute_order_parameter,
    compute_cluster_order_parameters,
)

from update_crossscale_terms import xscale_q_up_step
from agent_initialization import attach_crossscale_fields  # where you defined it

def run_generic_alignment_analysis(
    agents,
    generators: dict,
    params: dict,
    mode: str = "belief",
    outdir: Path = None
):
    """
    Compute, cluster, plot, and save alignment diagnostics for either belief or model fields.

    Parameters
    ----------
    agents : list
        List of Agent objects.
    generators : dict
        Dict of Lie algebra generators: {"q": (d,K_q,K_q), "p": (d,K_p,K_p)}.
    params : dict
        Runtime parameters; expects 'log_eps', 'overlap_eps', etc.
    mode : str
        Either 'belief' or 'model' – determines which alignment metric to compute.
    outdir : Path, optional
        Directory to save results. Defaults to './alignment_output' or './model_alignment_output'.
    """
    assert mode in ("belief", "model"), f"[run_generic_alignment_analysis] Invalid mode: {mode}"
    outdir = Path(outdir) if outdir else Path("alignment_output" if mode == "belief" else "model_alignment_output")
    outdir.mkdir(parents=True, exist_ok=True)

    if mode == "belief":
        compute_kl = compute_pairwise_kl_belief
        generators_used = generators["q"]
        prefix = "kl"
        title = "Epistemic Alignment Network"
        matrix_title = "Pairwise Epistemic Misalignment"
    else:
        compute_kl = compute_pairwise_kl_model
        generators_used = generators["p"]
        prefix = "kl_model"
        title = "Model Alignment Network"
        matrix_title = "Pairwise Model Misalignment"

    # Step 1: KL divergence matrix
    kl_matrix = compute_kl(agents, generators_used, params)
    sym_kl = compute_symmetric_kl_matrix(kl_matrix)
    sym_kl = np.clip(sym_kl, 0.0, None)

    # Step 2: Auxiliary metrics
    overlap_A = overlap_area_matrix(agents, params.get("overlap_eps", 0.0))
    curv_mean = curvature_mean_per_agent(agents, generators_used)

    # Step 3: Meta-agent detection
    rankings = rank_agent_alignment(sym_kl)
    meta_list, labels, eps = find_meta_agents(sym_kl, overlap_A, curv_mean)
    print(f"[INFO] mode={mode}: adaptive ε = {eps:.3f}, meta_agents = {len(meta_list)}")

    # Step 4: Visualize KL matrix and network
    plot_matrix(sym_kl, outdir=outdir, label=f"D_KL({mode})", title=matrix_title, fname="kl_matrix.png")

    plot_generic_alignment_network(
        sym_kl, labels,
        threshold=eps,
        outpath=outdir / "alignment_network.png",
        title=f"{title} (ε={eps:.3f})"
    )

    # Step 5: Save alignment data
    save_generic_alignment_data(
        kl_matrix=sym_kl,
        rankings=rankings,
        labels=labels,
        outdir=outdir,
        prefix=prefix
    )

    print(f"[✓] {mode.capitalize()} alignment analysis completed → {outdir}/")


def find_meta_agents(
    sym_kl: np.ndarray,
    overlap_area: np.ndarray,
    curv_mean: np.ndarray,
    tau_A: float = 10,
    eta:   float = 10,
    tau_C: float = 10,
    verbose: bool = False
):
    """
    Identify meta-agent clusters satisfying:
      A) mean intra-cluster KL < tau_A
      B) intra < eta × extra-cluster KL
      C) mean curvature < tau_C

    Returns:
        meta:   list of index lists (clusters)
        labels: np.ndarray of cluster labels per agent
        eps:    threshold used to form clusters (30% quantile)
    """
    N = sym_kl.shape[0]
    finite = sym_kl[np.isfinite(sym_kl)]

    # 1) Compute adaptive connectivity threshold
    eps = np.quantile(finite, 0.30)
    min_eps = getattr(config, "epsilon_model", 1e-6)
    if eps < min_eps:
        eps = min_eps

    # 2) Build KL-based graph
    G = nx.Graph()
    G.add_nodes_from(range(N))
    for i, j in it.combinations(range(N), 2):
        d = sym_kl[i, j]
        if np.isfinite(d) and d <= eps:
            G.add_edge(i, j, weight=d)

    # 3) Extract connected components satisfying alignment + curvature
    meta = []
    for comp in nx.connected_components(G):
        C = list(comp)
        if len(C) < 2:
            continue

        C_set = set(C)
        out_set = set(range(N)) - C_set
        intra_vals = sym_kl[np.ix_(C, C)]
        intra_vals = intra_vals[np.isfinite(intra_vals)]
        intra_mean = float(intra_vals.mean()) if intra_vals.size > 0 else np.inf

        curv_meanC = float(curv_mean[np.array(C)].mean())

        extra_vals = sym_kl[np.ix_(C, list(out_set))]
        extra_vals = extra_vals[np.isfinite(extra_vals)]
        extra_mean = float(extra_vals.mean()) if extra_vals.size > 0 else np.inf

        accept = False
        if extra_vals.size == 0:
            if intra_mean < tau_A and curv_meanC < tau_C:
                accept = True
        else:
            if (intra_mean < tau_A and
                intra_mean < eta * extra_mean and
                curv_meanC < tau_C):
                accept = True

        if accept:
            meta.append(C)
            if verbose:
                print(f"[meta-cluster] size={len(C)}, "
                      f"<KL_intra>={intra_mean:.3f}, "
                      f"<KL_extra>={extra_mean:.3f}, "
                      f"<curv>={curv_meanC:.3f}")

    # 4) Assign labels to agents
    labels = np.full(N, -1, dtype=int)
    for k, C in enumerate(meta):
        labels[np.array(C)] = k

    return meta, labels, eps


def build_meta_agents_from_clusters(agents, labels, generators, verbose=True):
    """
    Build coarse-grained meta-agents (as Agent objects) using IG fields.
    Neighbors are inferred from original agent overlaps.

    Args:
        agents     : list of Agent objects
        labels     : np.ndarray of cluster labels
        generators : Lie algebra generators
        verbose    : whether to print cluster sizes

    Returns:
        List of new Agent objects, one per cluster.
    """
    

    def get_meta_agent_adjacency(agents, labels, eps=1e-3):
        labels = np.asarray(labels)
        unique = sorted(set(labels[labels >= 0]))

        label_map = {lab: i for i, lab in enumerate(unique)}

        n_meta = len(label_map)
        adj = np.zeros((n_meta, n_meta), dtype=bool)

        for i, ag_i in enumerate(agents):
            lab_i = labels[i]
            if lab_i < 0: continue
            for j, ag_j in enumerate(agents):
                lab_j = labels[j]
                if lab_j < 0 or lab_i == lab_j: continue
                if np.any(ag_i.mask * ag_j.mask > eps):
                    a = label_map[lab_i]
                    b = label_map[lab_j]
                    adj[a, b] = adj[b, a] = True

        return adj, label_map

    meta_agents = []
    unique_labels = sorted(set(labels))
    H, W, K = agents[0].mu_q_field.shape
    d = agents[0].phi.shape[-1]
    fiber_basis = np.eye(K)


    for lab in unique_labels:
        if lab < 0:
            continue
        idxs = np.where(labels == lab)[0]
        if len(idxs) == 0:
            continue

        sub = [agents[i] for i in idxs]

        mask = aggregate_mask(sub)
        mu_q = aggregate_fields(sub, "mu_q_field")
        mu_p = aggregate_fields(sub, "mu_p_field")
        sigma_q = aggregate_fields(sub, "sigma_q_field")
        sigma_p = aggregate_fields(sub, "sigma_p_field")
        phi = aggregate_fields(sub, "phi")
        phi_model = aggregate_fields(sub, "phi_model")

        sigma_q = 0.5 * (sigma_q + sigma_q.transpose(0, 1, 3, 2))
        sigma_p = 0.5 * (sigma_p + sigma_p.transpose(0, 1, 3, 2))

        inds = np.argwhere(mask > 0.5)
        center = tuple(np.round(np.mean(inds, axis=0)).astype(int)) if len(inds) else (H // 2, W // 2)

        A = Agent(
            id            = int(lab),
            mask          = mask,
            mu_q_field    = mu_q,
            sigma_q_field = sigma_q,
            mu_p_field    = mu_p,
            sigma_p_field = sigma_p,
            phi           = phi,
            phi_model     = phi_model,
            center        = center,
            radius        = np.sqrt(np.sum(mask)),
            neighbors     = [],  # set below
        )
        meta_agents.append(A)

        if verbose:
            print(f"[meta-agent {lab}] from {len(sub)} agents, center={center}, radius={A.radius:.2f}")

    # ── Assign neighbors using adjacency matrix ──
    adj, label_map = get_meta_agent_adjacency(agents, labels)
    for i, A in enumerate(meta_agents):
        A.neighbors = [meta_agents[j].id for j in range(len(meta_agents)) if adj[i, j]]

    return meta_agents


def wire_child_parent_links(children, parents, labels):
    for P in parents:
        P.child_ids = []
        P.level = getattr(P, "level", 1)
    for cid, child in enumerate(children):
        pid = int(labels[cid])
        child.parent_ids = [pid]
        parents[pid].child_ids.append(cid)



def _first_present_key(d, candidates):
    for k in candidates:
        if k in d:
            return k
    return None

def get_intra_inter(stats, kl_matrix, labels):
    """
    Returns two 1D arrays: intra_vals, inter_vals.
    Tries to read from `stats`; if unavailable, computes from kl_matrix + labels.
    """
    import numpy as np

    # Try to read from stats using a few common key names
    if stats and len(stats) > 0:
        intra_all, inter_all = [], []
        for cid, entry in stats.items():
            # allow several possible key names
            k_intra = _first_present_key(entry, ["intra", "intra_kl", "intra_vals", "intra_values"])
            k_inter = _first_present_key(entry, ["inter", "inter_kl", "inter_vals", "inter_values"])
            if k_intra is not None:
                intra_all.append(np.asarray(entry[k_intra]).ravel())
            if k_inter is not None:
                inter_all.append(np.asarray(entry[k_inter]).ravel())
        if intra_all and inter_all:
            return np.concatenate(intra_all), np.concatenate(inter_all)
        # fall through to matrix-based if one is missing

    # Fallback: compute from matrix + labels
    labels = np.asarray(labels)
    uniq = np.unique(labels[labels >= 0])
    intra_vals, inter_vals = [], []
    for a in uniq:
        idx_a = np.where(labels == a)[0]
        if idx_a.size >= 2:
            # intra-cluster (exclude diagonal)
            block = kl_matrix[np.ix_(idx_a, idx_a)].astype(float)
            mask = ~np.eye(block.shape[0], dtype=bool)
            intra_vals.append(block[mask])
        # inter-cluster
        for b in uniq:
            if b <= a:
                continue
            idx_b = np.where(labels == b)[0]
            if idx_b.size == 0 or idx_a.size == 0:
                continue
            block_ab = kl_matrix[np.ix_(idx_a, idx_b)].astype(float)
            inter_vals.append(block_ab.ravel())

    intra = np.concatenate(intra_vals) if intra_vals else np.array([])
    inter = np.concatenate(inter_vals) if inter_vals else np.array([])
    return intra, inter

def condensation_score(stats, R_global, sigma_global, kl_matrix=None, labels=None):
    """
    Larger is better. Combines inter/intra separation and global order sharpness.
    Robust to missing 'intra'/'inter' keys in `stats`.
    """
    import numpy as np
    intra, inter = get_intra_inter(stats, kl_matrix, labels)

    # Handle edge cases gracefully
    if intra.size == 0 and inter.size == 0:
        return -1.0
    if intra.size == 0:  # no within-cluster pairs (e.g., all singletons)
        sep = 1.0
    elif inter.size == 0:  # only one cluster → no inter-cluster pairs
        sep = 1.0
    else:
        sep = (np.nanmean(inter) + 1e-9) / (np.nanmean(intra) + 1e-9)

    order = R_global / (sigma_global + 1e-9) if sigma_global is not None else 0.0
    return 0.7 * sep + 0.3 * order





def _shape_or_none(x):
    try:
        return None if x is None else tuple(int(s) for s in x.shape)
    except Exception:
        return None

def _as_int_or_none(x):
    if x is None:
        return None
    return int(x) if isinstance(x, (int, np.integer)) else int(x)

def _as_float_or_nan(x):
    if x is None:
        return float("nan")
    return float(x) if isinstance(x, (float, np.floating)) else float(x)

def _to_py_list_int(xs):
    return [int(v) for v in xs] if xs is not None else []

def save_meta_agent_summary(meta_agents, path="meta_agent_analysis/meta_agent_summary.json"):
    out = []
    for P in meta_agents:
        # center as tuple[int,int] or None
        center = getattr(P, "center", None)
        if center is not None:
            try:
                center = (int(center[0]), int(center[1]))
            except Exception:
                center = None

        row = {
            "id": _as_int_or_none(getattr(P, "id", None)),
            "level": _as_int_or_none(getattr(P, "level", None)),
            "center": center,
            "radius": _as_float_or_nan(getattr(P, "radius", None)),

            "mask_shape": _shape_or_none(getattr(P, "mask", None)),
            "K_q": (int(getattr(P, "mu_q_field").shape[-1]) 
                    if getattr(P, "mu_q_field", None) is not None else None),
            "K_p": (int(getattr(P, "mu_p_field").shape[-1]) 
                    if getattr(P, "mu_p_field", None) is not None else None),

            "Lambda_dn_q_shape": _shape_or_none(getattr(P, "Lambda_dn_q", None)),
            "Lambda_dn_p_shape": _shape_or_none(getattr(P, "Lambda_dn_p", None)),

            "child_ids": _to_py_list_int(getattr(P, "child_ids", [])),
            "parent_ids": _to_py_list_int(getattr(P, "parent_ids", [])),
        }
        out.append(row)

    Path(path).parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w") as f:
        json.dump(out, f, indent=2)



def _weighted_mean_field(stack, weights, eps=1e-8):
    """
    stack: (C, H, W, D)
    weights: (C, H, W, 1) nonnegative
    returns (H, W, D)
    """
    num = np.sum(weights * stack, axis=0)
    den = np.sum(weights, axis=0) + eps
    return num / den

def coarsen_phi_from_children(parent, children, field="phi", weight_mode="mask", max_norm=np.pi, eps=1e-6):
    """
    Build parent.{phi or phi_model} by weighted average of children fields.
    - field: "phi" or "phi_model"
    - weight_mode: "mask" (default), or "mask*overlap", or a callable(child)->(H,W,1)
    """
    if not getattr(parent, "child_ids", None):
        return  # nothing to do
    C = len(parent.child_ids)

    # gather child fields
    phi_stack = []
    w_stack   = []
    for cid in parent.child_ids:
        ch = children[cid]
        phi_c = getattr(ch, field)                 # (H, W, 3)
        phi_stack.append(phi_c[..., :3][None, ...])  # ensure shape (1,H,W,3)

        if callable(weight_mode):
            w = weight_mode(ch)  # (H,W,1)
        else:
            if weight_mode == "mask":
                w = ch.mask[..., None]
            elif weight_mode == "mask*overlap":
                w = (ch.mask * parent.mask)[..., None]
            else:
                w = ch.mask[..., None]
        w_stack.append(w[None, ...])

    phi_stack = np.concatenate(phi_stack, axis=0)  # (C,H,W,3)
    w_stack   = np.concatenate(w_stack,   axis=0)  # (C,H,W,1)

    # algebra-space weighted average
    phi_parent = _weighted_mean_field(phi_stack, w_stack, eps=eps)  # (H,W,3)

    # clip to stay in safe radius & sanitize
    # (same style as your existing soft clip; fallback to simple norm clip)
    norms = np.linalg.norm(phi_parent, axis=-1, keepdims=True) + 1e-12
    scale = np.minimum(1.0, max_norm / norms)
    phi_parent = phi_parent * scale

    setattr(parent, field, phi_parent.astype(children[0].mu_q_field.dtype))

import numpy as np


if __name__ == "__main__":
    BASEDIR = Path("meta_agent_analysis")
    BASEDIR.mkdir(exist_ok=True)

    # ──────────────────────────────────────────────────────────────
    # [1] Load original agents from checkpoint
    # ──────────────────────────────────────────────────────────────
    agents = load_final_step(checkpoint_dir)
    if agents is None:
        raise FileNotFoundError(f"No step_XXXX.pkl found in {checkpoint_dir}/")

    # Load both generator sets
    generators_q = get_generators(group_name, K_q)
    generators_p = get_generators(group_name, K_p)
    generators = {"q": generators_q, "p": generators_p}

    params = {"log_eps": log_eps, "overlap_eps": overlap_eps}

    # ──────────────────────────────────────────────────────────────
    # [2] Run alignment diagnostics (belief and model)
    # ──────────────────────────────────────────────────────────────
    for mode in ["belief", "model"]:
        outdir = BASEDIR / f"{mode}_alignment_output"
        outdir.mkdir(exist_ok=True, parents=True)
        print(f"\n[INFO] Running alignment analysis for mode: {mode}")
        run_generic_alignment_analysis(agents, generators, params, mode, outdir=outdir)

    print("\n[✓] Alignment analyses complete.\n")

    # ──────────────────────────────────────────────────────────────
    # [3] Detect clusters + run condensation diagnostics
    #     → compute a score for 'kl' (belief) and 'kl_model' (model)
    # ──────────────────────────────────────────────────────────────
    best = {"prefix": None, "score": -1.0, "labels": None, "kl_matrix": None}

    for prefix, subfolder in [
        ("kl",       "belief_alignment_output"),
        ("kl_model", "model_alignment_output"),
    ]:
        align_dir = BASEDIR / subfolder
        print(f"\n[INFO] Processing '{prefix}' clusters from '{align_dir}'")

        kl_matrix, labels, rankings = load_meta_data(str(align_dir), prefix)

        if len(labels) != len(agents):
            print(f"[ERROR] Label count {len(labels)} does not match agent count {len(agents)}")
            continue

        print(f"[INFO] Cluster label histogram: {np.bincount(labels[labels >= 0])}")

        stats = compute_cluster_kl_stats(kl_matrix, labels)
        R_global, sigma_global = compute_order_parameter(kl_matrix)

        if not stats:
            print(f"[!] No clusters detected for {prefix}; skipping.")
            continue

        outdir = BASEDIR / "condensation_output" / prefix
        outdir.mkdir(exist_ok=True, parents=True)

        # Main condensation plots
        plot_intra_kl_distribution(stats, outpath=outdir / "intra_kl.png")
        plot_inter_vs_intra(stats, outpath=outdir / "inter_vs_intra.png")
        cluster_R = compute_cluster_order_parameters(kl_matrix, labels)
        plot_cluster_order_parameters(cluster_R, outpath=outdir / "cluster_order_params.png")
        plot_spatial_cluster_map(agents, labels, outpath=outdir / "spatial_clusters.png")

        # Use correct generators for curvature
        curvature_generators = generators_q if prefix == "kl" else generators_p
        plot_curvature_heatmap(agents, labels, curvature_generators, outpath=outdir / "curvature_heatmap.png")

        print(f"[✓] Spatial cluster map saved to: {outdir / 'spatial_clusters.png'}")
        print(f"[✓] Curvature heatmap saved to:   {outdir / 'curvature_heatmap.png'}")

        # compute and log condensation score
        # compute and log condensation score
        score = condensation_score(stats, R_global, sigma_global, kl_matrix=kl_matrix, labels=labels)
        print(f"[INFO] {prefix} condensation score = {score:.4f}")
        

        if score > best["score"]:
            best.update({"prefix": prefix, "score": score, "labels": labels, "kl_matrix": kl_matrix})

    # ──────────────────────────────────────────────────────────────
    # [4] Build meta-agents from the best clustering and wire links
    # ──────────────────────────────────────────────────────────────
    if best["prefix"] is None:
        raise RuntimeError("No valid clustering found to build meta-agents.")

    print(f"\n[INFO] Selected clustering for meta-agent build: {best['prefix']} (score={best['score']:.4f})")

    chosen_generators = generators_q if best["prefix"] == "kl" else generators_p
    meta_agents = build_meta_agents_from_clusters(agents, best["labels"], chosen_generators)


    # NEW: give parents Λ/Θ slots + level tag
    for P in meta_agents:
        attach_crossscale_fields(P, K_q, K_p)
        P.level = 1
    
    wire_child_parent_links(agents, meta_agents, best["labels"])

    # Coarse-grain gauge fields from children → parent
    for P in meta_agents:
        coarsen_phi_from_children(P, agents, field="phi",        weight_mode="mask")
        coarsen_phi_from_children(P, agents, field="phi_model",  weight_mode="mask")
    
    def _field_norm(a, m=None):
        v = np.linalg.norm(a, axis=-1) if a.ndim==3 else np.linalg.norm(a, axis=(-1,-2))
        if m is not None:
            v = v[m > 1e-6]
        return float(np.nanmean(v)) if v.size else float("nan")
    
    for P in meta_agents:
        n_phi  = _field_norm(P.phi,       P.mask)
        n_phim = _field_norm(P.phi_model, P.mask)
        print(f"[META] parent {P.id}: ⟨‖φ‖⟩={n_phi:.4f}  ⟨‖φ̃‖⟩={n_phim:.4f}")

    procrustes_seed_lambda_dn_q(meta_agents, agents, best["labels"])

    # persist outputs
    save_meta_agents(meta_agents, output_dir="meta_agent_analysis/meta_agent_fields")
    save_meta_labels(best["labels"], path="meta_agent_analysis/meta_labels.csv")

    
        
    runtime_params = build_runtime_params_for_xscale(
        generators_q, generators_p, meta_agents, best["labels"]
    )
    agents_after, _ = run_simulation(outdir="checkpoints_L0", params=runtime_params)
    
    
    
    plots_dir = BASEDIR / "agent_plots"
    os.makedirs(plots_dir, exist_ok=True)
    
    # 1) cluster size histogram
    plot_cluster_size_hist(best["labels"], outpath=plots_dir / "cluster_sizes.png")
    
    # 2) child/parent overlay panels
    plot_child_parent_overlay(
        agents, meta_agents, best["labels"],
        outpath=plots_dir / "child_parent_overlay.png",
        max_examples=12
    )
    
    # 3) cross-scale KL sanity (q-only, identity Λ by default)
    
    vals = compute_avg_crossscale_kl_q(agents, meta_agents, best["labels"], eps=1e-6)
    plot_crossscale_kl_hist(vals, outpath=plots_dir / "crossscale_kl_q_hist.png")
    
    

    # BEFORE
    vals0 = compute_avg_crossscale_kl_q(agents, meta_agents, best["labels"], eps=1e-6)
    print(f"[XSCALE] mean KL before = {np.nanmean(vals0):.5f}  per-child = {[f'{v:.5f}' for v in vals0]}")
    
    # 5 quick steps
    for t in range(5):
        xscale_q_up_step(agents, meta_agents, best["labels"],
                         beta=0.3, lr_mu=0.12, lr_sigma=0.05, eps=1e-6,
                         clip_mu=0.5, clip_S=0.25)
        vals = compute_avg_crossscale_kl_q(agents, meta_agents, best["labels"], eps=1e-6)
    print(f"[XSCALE] t={t+1}: mean KL = {np.nanmean(vals):.5f}  per-child = {[f'{v:.5f}' for v in vals]}")

    # call it:
    save_meta_agent_summary(meta_agents)
    print(f"[XSCALE] KL(q_child || Λ_dn_q q_parent) mean = {np.nanmean(vals):.4g}  n={np.isfinite(vals).sum()}")
    print("[XSCALE] per-child KL (nats):", [f"{v:.5f}" for v in vals if np.isfinite(v)])
   

