
import os
os.environ["OMP_NUM_THREADS"] = "1"
os.environ["MKL_NUM_THREADS"] = "1"
os.environ["NUMEXPR_NUM_THREADS"] = "1"  # Optional: just in case
os.environ["OPENBLAS_NUM_THREADS"]= "1"

# Print to confirm they are set
print("[THREADING] Thread limits set:")
print(f"  OMP_NUM_THREADS      = {os.environ.get('OMP_NUM_THREADS')}")
print(f"  MKL_NUM_THREADS      = {os.environ.get('MKL_NUM_THREADS')}")
print(f"  NUMEXPR_NUM_THREADS  = {os.environ.get('NUMEXPR_NUM_THREADS')}")
print(f"  OPENBLAS_NUM_THREADS = {os.environ.get('OPENBLAS_NUM_THREADS')}")

# Standard library
import os
import time

# Third-party
import pickle
import pandas as pd
from update_rules import synchronous_step, step_telemetry,_masked_unit, energy_diff_for_phi, energy_diff_for_phi_model
# Local configuration & utilities

from config_utils import set_config_from_params
from get_generators import get_generators
# run_simulation.py (cleaner entrypoint)
import sys

# add near other imports
import numpy as np
from update_crossscale_terms import xscale_q_up_step, xscale_q_dn_step
from meta_agent_plots import compute_avg_crossscale_kl_q  # for logging only

# I/O helpers
from generalized_io_utils import (
    save_step,
    load_checkpoint,
    find_resume_step,
    save_config_to_readme,
)

# Agent construction
from agent_initialization import initialize_agents, initialize_agent_gradients
import config
from generalized_diagnostics_metrics import log_all_metrics, full_field_logger
from meta_agent_utils import procrustes_seed_lambda_dn_q

# ─────────────────────────────────────────────────────────────────────────────
# LOGGING HELPERS & DEFAULTS (drop near your imports)
# ─────────────────────────────────────────────────────────────────────────────
import time, os, pickle
from pathlib import Path
import numpy as np
import pandas as pd



LOGGING_DEFAULTS = dict(
    # master switches
    enable_scalar=True,          # run log_all_metrics
    enable_fields=True,          # run full_field_logger
    enable_max_overlap=True,     # (unused if you've removed that feature)
    print_total_energy=True,

    # cost-control cadence
    fields_every=1,              # dump full fields every k steps
    max_overlap_every=1,         # (unused if you've removed that feature)

    # misc schema & outdirs
    schema_version="v3",
    full_field_outdir="fields",
    pair_outdir="max_overlap",
)

def _merge_logging_cfg(params_or_cfg):
    """Return a logging dict with sane defaults even if missing."""
    logcfg = {}
    if hasattr(params_or_cfg, "get"):  # dict-like
        logcfg = params_or_cfg.get("logging", {}) or {}
    elif hasattr(params_or_cfg, "__dict__"):
        logcfg = getattr(params_or_cfg, "logging", {}) or {}
    out = dict(LOGGING_DEFAULTS)
    out.update(logcfg)
    return out


# ─────────────────────────────────────────────────────────────────────────────
# UPDATED run_simulation WITH NEW LOGGING
# ─────────────────────────────────────────────────────────────────────────────
def run_simulation(
    outdir="checkpoints",
    resume=False,
    log_metrics=True,    # function-level switches still honored
    log_fields=True,
    num_cores=None,
    params=None,
):
    os.makedirs(outdir, exist_ok=True)
    save_config_to_readme(outdir)

    if num_cores is None:
        num_cores = 18

    # ── prepare params + generators ──────────────────────────────────────────
    params = params or {}
    
    # PATCH: prefer params[...] then fall back to config.key
    def _cfg(key, default=None):
        if isinstance(params, dict) and key in params:
            return params[key]
        return getattr(config, key, default)

    G_q = params.get("generators_q")
    G_p = params.get("generators_p")
    if G_q is None:
        G_q, _meta_q = get_generators(config.group_name, config.K_q, return_meta=True)
        params["generators_q"] = G_q
    if G_p is None:
        G_p, _meta_p = get_generators(config.group_name, config.K_p, return_meta=True)
        params["generators_p"] = G_p

    # merge logging cfg (function args override cfg toggles when False)
    logcfg = _merge_logging_cfg(params if isinstance(params, dict) else vars(config))
    # honor function args as hard gates:
    if not log_metrics:
        logcfg["enable_scalar"] = False
    if not log_fields:
        logcfg["enable_fields"] = False

    # ── initialization / resume ──────────────────────────────────────────────
    if resume:
        agents, _ = load_checkpoint(outdir)
        step_start = find_resume_step(outdir)
        for agent in agents:
            agent.generators_q = G_q
            agent.generators_p = G_p
    else:
        agents = initialize_agents(
            seed=getattr(config, "seed", None),
            domain_size=config.domain_size,
            N=config.N,
            K_q=config.K_q,
            K_p=config.K_p,
            lie_algebra_dim=3,
            visualize=False,
            fixed_location=True,
        )
        step_start = 0
        for agent in agents:
            initialize_agent_gradients(agent, config)
            agent.generators_q = G_q
            agent.generators_p = G_p


    # ── after you build/restore 'agents' and set generators on them ──
    # (right before metric_log = [] is created is a fine place)
    
    xscale_ctx = (params or {}).get("xscale", None)
    if xscale_ctx:
        parents = xscale_ctx["parents"]
        labels  = np.asarray(xscale_ctx["labels"])
        # make sure parents have generators and cross-scale fields
        for P in parents:
            P.generators_q = G_q
            P.generators_p = G_p
            # ensure Λ/Θ slots exist (no-ops if you already did this)
            try:
                attach_crossscale_fields(P, config.K_q, config.K_p)
                P.level = getattr(P, "level", 1)
            except NameError:
                pass  # attach_crossscale_fields lives in your init module; safe to skip if already set
    
        # also ensure children have cross-scale slots
        for c in agents:
            try:
                attach_crossscale_fields(c, config.K_q, config.K_p)
            except NameError:
                pass
    
        # frequency for KL logging (optional)
        xscale_log_every = int(_cfg("xscale_log_every", 1))
    else:
        parents = None
        labels = None
        xscale_log_every = None
        
    # PATCH (optional): seed Λ_dn_q once before stepping
    if _cfg("enable_crossscale", False) and _cfg("xscale_seed_lambda_dn_q", False) and (parents is not None):
        try:
            procrustes_seed_lambda_dn_q(parents, agents, labels, ridge=_cfg("xscale_lambda_ridge", 1e-3))
            print("[XSCALE] Procrustes seeded Λ_dn_q")
        except Exception as e:
            print(f"[XSCALE] Λ seed skipped: {e}")

    
    metric_log = []
    print(f"[RUN] Starting simulation at step {step_start} with {num_cores} cores")
    fd_every = getattr(config, "fd_check_every", 1000)
    fd_pairs = getattr(config, "fd_pairs_per_step", 1)

    # ensure outdirs exist if enabled
    if logcfg["enable_fields"]:
        os.makedirs(os.path.join(outdir, logcfg["full_field_outdir"]), exist_ok=True)
    if logcfg.get("enable_max_overlap", False):
        os.makedirs(os.path.join(outdir, logcfg["pair_outdir"]), exist_ok=True)

    # ─────────── Simulation Loop ─────────────
    for step in range(step_start, config.steps):
        print(f"\n[STEP {step}] -----------------------------")

        t0 = time.perf_counter()
        step_params = dict(params)
        step_params.update({
            "step": step,
            "sanitize_strict_pre": False,  # light pre-pass sanitize; strict happens post-update
        })

        agents = synchronous_step(agents, G_q, G_p, params=step_params, n_jobs=num_cores)
        print(f"[TIMER] synchronous update: {time.perf_counter() - t0:.3f}s")

        
        # ⬇️ Cross-scale updates (Stage-1/2), if enabled and context provided
        if _cfg("enable_crossscale", False) and (parents is not None) and (labels is not None):
            # Stage-1: child → parent (q-only)
            if _cfg("beta_up_q", 0.0) > 0.0:
                xscale_q_up_step(
                    agents, parents, labels,
                    beta=_cfg("beta_up_q", 0.0),
                    lr_mu=_cfg("xscale_lr_mu_q_up", 0.12),
                    lr_sigma=_cfg("xscale_lr_sigma_q_up", 0.05),
                    eps=1e-6, clip_mu=0.5, clip_S=0.25
                )
            # Stage-2: parent → children (q-only)
            if _cfg("beta_dn_q", 0.0) > 0.0:
                xscale_q_dn_step(
                    agents, parents, labels,
                    beta=_cfg("beta_dn_q", 0.0),
                    lr_mu=_cfg("xscale_lr_mu_q_dn", 0.08),
                    lr_sigma=_cfg("xscale_lr_sigma_q_dn", 0.04),
                    eps=1e-6
                )
        
            # (optional) log cross-scale KL every few steps
            if step % _cfg("xscale_log_every", 10) == 0:
                vals = compute_avg_crossscale_kl_q(agents, parents, labels, eps=1e-6)
                print(f"[XSCALE] step {step}: mean KL(child||Λ_dn_q·parent) = {np.nanmean(vals):.5f}  n={np.isfinite(vals).sum()}")
        

        # (B) Scalar metrics (toggleable)
        if logcfg["enable_scalar"]:
            t1 = time.perf_counter()
            m = log_all_metrics(agents, step=step, params=params, n_jobs=num_cores)
            
            # PATCH: record cross-scale KL in metrics
            if _cfg("enable_crossscale", False) and (parents is not None) and (labels is not None):
                vals = compute_avg_crossscale_kl_q(agents, parents, labels, eps=1e-6)
                m["xscale_kl_q_mean"] = float(np.nanmean(vals))
                m["xscale_kl_q_n"]    = int(np.isfinite(vals).sum())

            # enrich with schema + timing
            m["schema"] = logcfg["schema_version"]
            m["compute_ms"] = int((time.perf_counter() - t1) * 1000)

            # ⬇️ append the full record AS-IS (do not re-wrap)
            metric_log.append(m)

            if logcfg["print_total_energy"]:
                print(f"[Energy Totals @ step {step}]")
                print(f"  Self belief      = {m['e_self']:.4e}")
                print(f"  Feedback model   = {m['e_feedback']:.4e}")
                print(f"  Belief alignment = {m['e_align']:.4e}")
                print(f"  Model alignment  = {m['e_mod_align']:.4e}")
                print(f"  Model Mass       = {m['e_mass_mod']:.4e}")
                print(f"  Belief Mass      = {m['e_mass']:.4e}")
                print(f"  Belief Curvature = {m['e_curv']:.4e}")
                print(f"  Model Curvature  = {m['e_curv_mod']:.4e}")
                print(f"[TIMER] log_all_metrics: {time.perf_counter() - t1:.3f}s")

        # (D) Dump full fields (toggle + cadence)  ✅ no extra gate; pass params
        if logcfg["enable_fields"] and (step % logcfg["fields_every"] == 0):
            t0_fields = time.perf_counter()
            field_dir = os.path.join(outdir, logcfg["full_field_outdir"])
            full_field_logger(agents, step, field_dir, params=params)
            print(f"[TIMER] full_field_logger: {time.perf_counter() - t0_fields:.3f}s")

        # (E) Save checkpoint
        for A in agents:
            # purge caches before serialization
            if hasattr(A, "clear_omega_cache"):   A.clear_omega_cache()
            if hasattr(A, "clear_fisher_caches"): A.clear_fisher_caches()
        save_step(agents, outdir, step)
        print(f"[SAVE] Checkpoint --> {outdir}/step_{step:04d}.pkl")

    # ─────────── Final Output ─────────────
    if logcfg["enable_scalar"]:
        with open(os.path.join(outdir, "metric_log.pkl"), "wb") as f:
            pickle.dump(metric_log, f)
        print(f"[SAVE] Metrics log --> {outdir}/metric_log.pkl")

        rows = []
        for A in agents:
            for entry in getattr(A, "metrics_log", []):
                rows.append({"agent": A.id, **entry})
        if rows:
            pd.DataFrame(rows).to_csv(os.path.join(outdir, "per_agent_metrics.csv"), index=False)
            print("[SAVE] Per-agent metrics --> per_agent_metrics.csv")

    print("[DONE] Simulation completed.")
    return agents, metric_log


if __name__ == "__main__":
    

    # ─────────────────────────────────────────────
    # 1. Optional param override
    # ─────────────────────────────────────────────
    if len(sys.argv) > 1:
        with open(sys.argv[1], "rb") as f:
            param_override = pickle.load(f)
        set_config_from_params(param_override)
    else:
        param_override = {}

    # ─────────────────────────────────────────────
    # 2. Load SO(3) generators for q and p fibers
    # ─────────────────────────────────────────────
    G_q, meta_q = get_generators(config.group_name, config.K_q, return_meta=True)
    G_p, meta_p = get_generators(config.group_name, config.K_p, return_meta=True)

    # ─────────────────────────────────────────────
    # 3. Bundle runtime-only params
    # ─────────────────────────────────────────────
    runtime_params = {
        "generators_q": G_q,
        "generators_p": G_p,
    }

    # ─────────────────────────────────────────────
    # 4. Run the simulation
    # ─────────────────────────────────────────────
    run_simulation(
        outdir="checkpoints",
        resume=False,
        log_metrics = True,
        log_fields  = True ,
        params=runtime_params,
    )
