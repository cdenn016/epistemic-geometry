# -*- coding: utf-8 -*-
"""
Created on Thu Aug 14 09:35:09 2025

@author: chris and christine
"""
from typing import Dict, List, Optional, Tuple
import numpy as np
import config
from agent_schema import Agent
from runtime_context import runtime_ctx

from numerical_utils import resize_nn

#used all over
def _dilate_bool(mask: np.ndarray, r: int, periodic: bool) -> np.ndarray:
    """Binary dilation by r px, optional periodic wrapping."""
    if r <= 0:
        return mask.astype(bool)
    try:
        from scipy.ndimage import binary_dilation
        se = np.ones((2*r + 1, 2*r + 1), dtype=bool)
        if not periodic:
            return binary_dilation(mask.astype(bool), structure=se)
        H, W = mask.shape
        T = np.tile(mask.astype(bool), (3, 3))
        Td = binary_dilation(T, structure=se)
        return Td[H:2*H, W:2*W]
    except Exception:
        # fallback: cheap square foot-print without SciPy
        m = mask.astype(bool)
        for _ in range(r):
            up    = np.pad(m[1: , : ], ((0,1),(0,0)))
            down  = np.pad(m[:-1, : ], ((1,0),(0,0)))
            left  = np.pad(m[: , 1: ], ((0,0),(0,1)))
            right = np.pad(m[: , :-1], ((0,0),(1,0)))
            m = m | up | down | left | right
        if periodic:
            # wrap edges once (approximate)
            m[0, :]  |= m[-1, :]
            m[-1, :] |= m[0, :]
            m[:, 0]  |= m[:, -1]
            m[:, -1] |= m[:, 0]
        return m


#growth
def binary_dilate_3x3(x: np.ndarray) -> np.ndarray:
    x = np.asarray(x, bool); H, W = x.shape
    y = np.zeros((H, W), bool)
    for di in (-1, 0, 1):
        for dj in (-1, 0, 1):
            y |= np.pad(x, 1)[1+di:1+di+H, 1+dj:1+dj+W]
    return y

#growth
def binary_erode_3x3(x: np.ndarray) -> np.ndarray:
    x = np.asarray(x, bool); H, W = x.shape
    y = np.ones((H, W), bool)
    for di in (-1, 0, 1):
        for dj in (-1, 0, 1):
            y &= np.pad(x, 1)[1+di:1+di+H, 1+dj:1+dj+W]
    return y

#growth
def _logistic(x, tau, kappa):
    """
    Stable sigmoid around threshold tau with slope governed by kappa.
    Accepts arrays; returns array in [0,1].
    """
    x = np.asarray(x, np.float64)
    z = (x - float(tau)) / max(float(kappa), 1e-6)
    z = np.clip(z, -60.0, 60.0)
    return 1.0 / (1.0 + np.exp(-z))




#everywhere
def child_activity_map(ch, H, W, mu_tau=1e-3, trsig_tau=1e-3, eps=1e-6):
    m = getattr(ch, "mask", None)
    if m is None: return None
    
    m = np.asarray(m); 
    if m.shape[:2] != (H, W): m = resize_nn(m, (H, W))
    m_ok = (m > eps)

    mu = getattr(ch, "mu_q_field", None)
    Sig = getattr(ch, "sigma_q_field", None)
    if mu is None or Sig is None: return m_ok

    mu = np.asarray(mu); Sig = np.asarray(Sig)
    if mu.shape[:2] != (H, W): mu = resize_nn(mu, (H, W))
    if Sig.shape[:2] != (H, W): Sig = resize_nn(Sig, (H, W))
    mu_mag = np.sqrt((mu**2).sum(-1)) if mu.ndim == 3 else np.abs(mu).astype(np.float32)
    trsig  = np.trace(Sig, axis1=-2, axis2=-1) if Sig.ndim == 4 else Sig.astype(np.float32)
    return m_ok & ((mu_mag > mu_tau) | (trsig > trsig_tau))


#preant spawn============================================================



def _iou_bool(a: np.ndarray, b: np.ndarray) -> float:
    inter = (a & b).sum()
    union = (a | b).sum()
    return float(inter) / max(1, int(union))

def _too_close_by_iou(comp: np.ndarray, existing_bool_masks: List[np.ndarray], *, iou_thr: float) -> bool:
    for pb in existing_bool_masks:
        if _iou_bool(comp, pb) >= float(iou_thr):
            return True
    return False

def _components(candidate_map: np.ndarray, *, min_area: int) -> List[Tuple[int, Tuple[float,float], np.ndarray]]:
    """Return components as (area, (cy,cx), mask) sorted by area desc."""
    labels, ncc = _label4(candidate_map.astype(bool))
    if ncc == 0:
        return []
    comps = []
    for c in range(1, ncc + 1):
        comp = (labels == c)
        area = int(comp.sum())
        if area < int(min_area):
            continue
        ys, xs = np.nonzero(comp)
        comps.append((area, (float(ys.mean()), float(xs.mean())), comp))
    comps.sort(key=lambda t: t[0], reverse=True)
    return comps


def _ensure_parent_store(ctx):
    """Normalize ctx.parents_by_region → Dict[int, Parent]."""
    if not hasattr(ctx, "parents_by_region") or ctx.parents_by_region is None:
        ctx.parents_by_region = {}
    if isinstance(ctx.parents_by_region, list):
        ctx.parents_by_region = {int(getattr(p, "id", i)): p for i, p in enumerate(ctx.parents_by_region)}
    return ctx.parents_by_region


def _compute_candidate_or_union(P, agents, H, W, dtype):
    cand = _compute_parent_candidate(P, agents)
    if cand is None:
        u = np.zeros((H, W), bool)
        for i in getattr(P, "child_ids", []): u |= (np.asarray(agents[i].mask) > 0)
        return u.astype(dtype)
    return np.asarray(cand, dtype=dtype)


def _compute_parent_candidate(P, agents):
    
    cand = build_parent_mask_from_group(
        children=agents, child_ids=getattr(P, "child_ids", []),
        A_maps={}, joint_maps={}, tau=getattr(config, "tau_align_emergent", 0.30),
        m_core=getattr(config, "m_core_emergent", 2), A_min=getattr(config, "A_min_emergent", 20),
        soft=True, smooth_iters=1,
    )
    if cand is None:
        # fallback: union of child masks
        H, W = P.mask.shape
        u = np.zeros((H, W), bool)
        for i in getattr(P, "child_ids", []): u |= (np.asarray(agents[i].mask) > 0)
        return u.astype(P.mask.dtype)
    c = np.asarray(cand)
    return c[0] if (c.ndim == 3 and c.shape[0] == 1) else c


def _growth_gate_from_overlap_core_activity(P, agents, H, W, eps, grow_min_kids):
    
    # overlap count
    cnt = np.zeros((H, W), np.int32)
    active_union = np.zeros((H, W), bool)
    for i in getattr(P, "child_ids", []):
        ch = agents[i]
        a = child_activity_map(ch, H, W, eps=eps)
        if a is None: continue
        active_union |= a
        cnt += (a & (np.asarray(ch.mask) > eps)).astype(np.int32)
    gate = np.ones((H, W), np.float32)
    if grow_min_kids > 0:
        gate *= np.clip(cnt.astype(np.float32) / float(grow_min_kids), 0.0, 1.0)
    # distance to core
    if getattr(P, "_core_map", None) is not None and P._core_map.any():
        dt = cheap_dt(P._core_map.astype(bool))
        r = float(getattr(config, "parent_core_decay_px", 6.0))
        gate *= np.exp(-dt / max(r, 1.0)).astype(np.float32)
    # activity
    gate *= active_union.astype(np.float32)
    return np.clip(gate, 0.0, 1.0)

def _should_reseed(P, cand):
    reseed_period = getattr(config, "parent_reseed_period", 0)
    if reseed_period <= 0: return False
    if (getattr(runtime_ctx, "global_step", 0) % reseed_period) != 0: return False
    def _iou(a, b, thr=1e-3):
        A = (a > thr); B = (b > thr); inter = (A & B).sum(); union = (A | B).sum()
        return float(inter) / max(1, int(union))
    return _iou(P.mask, cand, thr=1e-3) < float(getattr(config, "parent_reseed_iou", 0.30))



#=========================================================================






#INTERNAL HERE
def cheap_dt(core_bool: np.ndarray, cap_steps: int = 32) -> np.ndarray:
    H, W = core_bool.shape
    dt = np.full((H, W), np.inf, np.float32)
    front = core_bool.astype(bool); d = 0.0
    while front.any() and d < cap_steps:
        dt[front] = np.minimum(dt[front], d)
        new = (front | np.roll(front,1,0) | np.roll(front,-1,0) |
                      np.roll(front,1,1) | np.roll(front,-1,1))
        front = new & (~np.isfinite(dt)); d += 1.0
    return dt


def build_parent_mask_from_group(children,
                                 child_ids,
                                 A_maps,          # from compute_pairwise_agreement_maps
                                 joint_maps,      # from compute_pairwise_agreement_maps
                                 tau=0.2,
                                 m_core=3,
                                 A_min=200,
                                 soft=True,
                                 smooth_iters=0):
    """
    STRICT agreement mask (no union, no averaging of child masks).
    A pixel is IN only if at least m_core children mutually agree there
    (each has >= m_core-1 agreeing neighbors at that pixel).
    Soft value = mean agreement over agreeing pairs at that pixel.
    Returns (H,W) float32 in [0,1].
    """
    import numpy as np

    if len(child_ids) == 0:
        return None

    H, W = children[child_ids[0]].mask.shape
    Cg   = len(child_ids)

    # Pairwise "agree" mats and degrees
    A_sum = np.zeros((H, W), dtype=np.float32)   # sum of A over agreeing pairs
    pairN = np.zeros((H, W), dtype=np.int32)     # number of agreeing pairs
    deg   = np.zeros((Cg, H, W), dtype=np.int16) # per-child degree

    # agreement threshold: A = exp(-KL/tau); choose KL<tau → A>=e^-1
    a_thresh = np.exp(-1.0)

    # Build agreement graph per pixel (implicit via deg + counts)
    for a in range(Cg):
        ia = child_ids[a]
        for b in range(a + 1, Cg):
            ib = child_ids[b]
            key = (ia, ib) if ia < ib else (ib, ia)
            if key not in A_maps:
                continue
            A_ij = A_maps[key]       # (H,W) in [0,1]
            J    = joint_maps[key]   # (H,W) bool where both masks>0
            agree = (A_ij >= a_thresh) & J

            if not agree.any():
                continue

            A_add = np.zeros_like(A_ij, dtype=np.float32)
            A_add[agree] = A_ij[agree]
            A_sum += A_add
            pairN += agree.astype(np.int32)
            deg[a][agree] += 1
            deg[b][agree] += 1

    # If no agreeing pairs anywhere → empty mask (NO union fallback)
    if pairN.sum() == 0:
        return np.zeros((H, W), dtype=np.float32)

    # Core condition: at least m_core children each with ≥(m_core-1) agreeing neighbors
    core_children = (deg >= (m_core - 1))          # (Cg,H,W)
    core_count    = core_children.sum(axis=0)      # (H,W)
    in_core       = (core_count >= m_core)         # (H,W) bool

    # Soft value = mean of A over agreeing pairs, gated by in_core
    A_mean = np.zeros((H, W), dtype=np.float32)
    nz = pairN > 0
    A_mean[nz] = A_sum[nz] / pairN[nz]

    soft_mask = np.where(in_core, A_mean, 0.0).astype(np.float32)

    # optional smoothing (small)
    if smooth_iters > 0:
        k = np.array([[1,1,1],[1,2,1],[1,1,1]], dtype=np.float32); k /= k.sum()
        for _ in range(smooth_iters):
            pad = np.pad(soft_mask, 1, mode="edge")
            sm  = (
                k[0,0]*pad[:-2, :-2] + k[0,1]*pad[:-2,1:-1] + k[0,2]*pad[:-2,2:] +
                k[1,0]*pad[1:-1, :-2] + k[1,1]*pad[1:-1,1:-1] + k[1,2]*pad[1:-1,2:] +
                k[2,0]*pad[2:,  :-2] + k[2,1]*pad[2:, 1:-1] + k[2,2]*pad[2:,  2:]
            )
            soft_mask = np.clip(sm, 0.0, 1.0).astype(np.float32)

    # Area guard
    if soft_mask.sum() < A_min:
        return np.zeros((H, W), dtype=np.float32)

    return soft_mask if soft else (soft_mask > 0.5).astype(np.float32)





#used a LOT
def ensure_hw(mask, HW, *, reduce="max"):
    """
    Return a (H, W) float32 mask in [0,1].
    - Squeezes singleton axes.
    - Collapses any trailing stacks (H,W,M,...) via max or mean.
    - Resizes to (H,W) if needed (nn).
    """
    import numpy as np
    H, W = HW
    m = np.asarray(mask, np.float32)
    
    if m.size == 0 or m.ndim < 2:
    # create a blank mask
        return np.zeros((H, W), np.float32)

    # squeeze singletons
    while m.ndim > 0 and m.shape[-1] == 1:
        m = np.squeeze(m, axis=-1)
    if m.ndim == 3 and m.shape[0] == 1:
        m = np.squeeze(m, axis=0)
    # collapse stacks (H,W,M,...) -> (H,W)
    if m.ndim > 2:
        m = m.reshape(m.shape[0], m.shape[1], -1)
        if reduce == "max":
            m = m.max(axis=-1)
        elif reduce == "mean":
            m = m.mean(axis=-1)
        else:
            raise ValueError(f"reduce must be 'max' or 'mean', got {reduce}")
    
    
    # resize if needed
    if m.shape != (H, W):
        from parent_mask_utils import resize_nn  # already in your repo
        m = resize_nn(m, (H, W)).astype(np.float32)
    return np.clip(m, 0.0, 1.0)


#growth and detector
def _label4(binary_mask: np.ndarray):
    """
    4-connected component labeling.
    Returns (labels:int32[H,W], n_components:int)
    """
    H, W = binary_mask.shape
    labels = np.zeros((H, W), dtype=np.int32)
    vid = 0
    # neighbors: up, left
    for y in range(H):
        for x in range(W):
            if not binary_mask[y, x]:
                continue
            up  = labels[y-1, x] if y > 0 else 0
            left= labels[y, x-1] if x > 0 else 0
            if up == 0 and left == 0:
                vid += 1
                labels[y, x] = vid
            elif up != 0 and left == 0:
                labels[y, x] = up
            elif up == 0 and left != 0:
                labels[y, x] = left
            else:
                # merge: relabel one component to the other (path compression lite)
                a, b = (up, left) if up < left else (left, up)
                labels[y, x] = a
                if a != b:
                    labels[labels == b] = a
    # compact labels to 1..n
    uniq = np.unique(labels)
    uniq = uniq[uniq != 0]
    remap = {v:i+1 for i,v in enumerate(uniq)}
    for v, i in remap.items():
        labels[labels == v] = i
    return labels, len(uniq)


#used in growth
try:
    from scipy.ndimage import binary_dilation as _dilate, binary_erosion as _erode
    _HAS_SCIPY = True
except Exception:
    _HAS_SCIPY = False

def _ring_masks(core_bool, grow_band=1, shrink_band=1):
    """
    Build outer (growth) and inner (shrink) ring masks around a boolean core.
    Returns (outer_ring_bool, inner_ring_bool), each shape (H,W).
    """
    core_bool = np.asarray(core_bool, dtype=bool)

    if _HAS_SCIPY:
        og = core_bool.copy()
        for _ in range(max(1, int(grow_band))):
            og = _dilate(og, iterations=1, border_value=0)
        outer = og & (~core_bool)

        ig = core_bool.copy()
        for _ in range(max(1, int(shrink_band))):
            ig = _erode(ig, iterations=1, border_value=0)
        inner = core_bool & (~ig)
        return outer, inner

    # ---- NumPy fallback (4-neighborhood) ----
    def _dilate4(b):
        up    = np.pad(b[1: , : ], ((0,1),(0,0)))
        down  = np.pad(b[:-1, : ], ((1,0),(0,0)))
        left  = np.pad(b[: , 1: ], ((0,0),(0,1)))
        right = np.pad(b[: , :-1], ((0,0),(1,0)))
        return b | up | down | left | right

    def _erode4(b):
        up    = np.pad(b[1: , : ], ((0,1),(0,0)), constant_values=False)
        down  = np.pad(b[:-1, : ], ((1,0),(0,0)), constant_values=False)
        left  = np.pad(b[: , 1: ], ((0,0),(0,1)), constant_values=False)
        right = np.pad(b[: , :-1], ((0,0),(1,0)), constant_values=False)
        return b & up & down & left & right

    og = core_bool.copy()
    for _ in range(max(1, int(grow_band))):
        og = _dilate4(og)
    outer = og & (~core_bool)

    ig = core_bool.copy()
    for _ in range(max(1, int(shrink_band))):
        ig = _erode4(ig)
    inner = core_bool & (~ig)
    return outer, inner






#used for spawn
def _new_parent(pid, H, W, dtype, Kq, Kp, proposal):
    zeros3 = np.zeros((H, W, 3), dtype=dtype)
    eye_q = np.tile(np.eye(Kq, dtype=dtype), (H, W, 1, 1))
    eye_p = np.tile(np.eye(Kp, dtype=dtype), (H, W, 1, 1))
    P = Agent(
        id=pid, center=(0,0), radius=0.0, mask=np.zeros((H,W), dtype=dtype),
        mu_q_field=np.zeros((H,W,Kq), dtype=dtype), sigma_q_field=eye_q.copy(),
        mu_p_field=np.zeros((H,W,Kp), dtype=dtype), sigma_p_field=eye_p.copy(),
        phi=zeros3.copy(), phi_model=zeros3.copy(), neighbors=[]
    )
    P.level = 1
    P.birth_step = getattr(runtime_ctx, "global_step", 0)
    P.lambda_q_weight = 0.0; P.lambda_p_weight = 0.0
    P._region_proposal = np.clip(proposal, 0.0, 1.0).astype(dtype)
    P.emerged = False; P._prev_eval_mask = None
    P._emerge_on_cnt = 0; P._emerge_off_cnt = 0; P._core_map = None
    return P


#used all over....refactor suite to imp-lement automatically/consistently
def _as_parent_dict(obj):
    """
    Normalize parents -> {pid: Parent}. Accepts dict, list, iterable, or None.
    Uses the parent's .id if present; else falls back to enumerate index.
    """
    import collections.abc as _abc
    if obj is None:
        return {}
    if isinstance(obj, dict):
        return {int(getattr(p, "id", pid)): p for pid, p in obj.items()}
    if isinstance(obj, _abc.Iterable):
        return {int(getattr(p, "id", i)): p for i, p in enumerate(obj)}
    # Single parent object?
    return {int(getattr(obj, "id", 0)): obj}



#only for spawn
def _build_child_groups(region_masks, agents, HW, *, child_eps, min_child_area, intra_iou_thr, min_group_kids):
    """Return list[{'mask': bool(H,W), 'child_ids': tuple[int]}]."""
    
    H, W = HW
    groups = []
    for Rmask in region_masks:
        cmasks, cids = [], []
        for idx, C in enumerate(agents):
            M = ensure_hw(getattr(C, "mask", 0.0), (H, W)) > child_eps
            M &= Rmask
            if np.count_nonzero(M) >= min_child_area:
                cmasks.append(M); cids.append(int(getattr(C, "id", idx)))
        n = len(cmasks)
        if n == 0:
            continue
        # build adjacency by IoU
        adj = [set() for _ in range(n)]
        for i in range(n):
            for j in range(i+1, n):
                U = cmasks[i] | cmasks[j]
                if not U.any(): 
                    continue
                inter = np.count_nonzero(cmasks[i] & cmasks[j])
                iou_ij = inter / float(np.count_nonzero(U))
                if iou_ij >= intra_iou_thr:
                    adj[i].add(j); adj[j].add(i)
        # connected components
        seen = [False]*n
        for i in range(n):
            if seen[i]: continue
            q=[i]; seen[i]=True; comp=[i]
            while q:
                u=q.pop()
                for v in adj[u]:
                    if not seen[v]:
                        seen[v]=True; q.append(v); comp.append(v)
            gids=[cids[k] for k in comp]
            if len(gids) < min_group_kids:
                continue
            gmask = np.zeros((H,W), bool)
            for k in comp: gmask |= cmasks[k]
            groups.append({"mask": gmask, "child_ids": tuple(sorted(gids))})
    return groups




#only for spawn
def _find_group_peaks(groups, agents, HW, *, peak_min_cons, peak_nms_r, peak_max_per_gp, min_group_kids, child_eps, seed_halo_px):
    """Yield dicts with fields: cy,cx,score, child_ids, proposal."""
    
    H, W = HW
    out = []
    # tiny NMS helper (square radius)
    def _nms_coords(ys, xs, scores, r, max_keep):
        order = np.argsort(-scores)
        kept, out_ix = [], []
        r2 = max(1, r)**2
        for k in order:
            y, x, s = int(ys[k]), int(xs[k]), float(scores[k])
            ok = True
            for (py, px) in kept:
                if (py - y)**2 + (px - x)**2 < r2:
                    ok = False; break
            if ok:
                kept.append((y, x)); out_ix.append(k)
            if len(out_ix) >= max_keep: break
        return out_ix

    for G in groups:
        # stack kids’ masks
        stack = []
        for kid in G["child_ids"]:
            C = next((A for A in agents if int(getattr(A, "id", -1)) == int(kid)), None)
            if C is None: continue
            stack.append(ensure_hw(getattr(C, "mask", 0.0), (H, W)).astype(np.float32))
        if not stack: continue
        S = np.stack(stack, axis=-1)                        # (H,W,#kids)
        cons = S.mean(axis=-1)                              # agreement 0..1
        count = (S > child_eps).sum(axis=-1)
        cons[count < min_group_kids] = 0.0
        # restrict search to group halo
        halo = _dilate_bool(G["mask"].astype(bool), r=max(1, seed_halo_px), periodic=bool(getattr(config, "periodic_domain", False)))
        cons *= halo.astype(np.float32)
        # threshold & NMS
        keep = cons >= float(peak_min_cons)
        ys, xs = np.nonzero(keep)
        if ys.size == 0: continue
        idx = _nms_coords(ys, xs, cons[keep], peak_nms_r, peak_max_per_gp)
        for k in idx:
            cy, cx = float(ys[k]), float(xs[k])
            # small local proposal (disk clip)
            yy, xx = np.ogrid[:H, :W]
            d2 = (yy - int(round(cy)))**2 + (xx - int(round(cx)))**2
            local = (d2 <= (max(1, seed_halo_px*seed_halo_px))).astype(np.float32)
            proposal = (cons * local)
            if proposal.max() > 0: proposal /= (proposal.max() + 1e-8)
            out.append({"cy":cy, "cx":cx, "score":float(cons[int(cy),int(cx)]),
                        "child_ids": list(G["child_ids"]),
                        "proposal": proposal.astype(np.float32)})
    return out

            


#only for spawn
def _compute_core_from_kids(P, agents, H, W, eps):
    
    cover = np.zeros((H, W), np.int32); weight = np.zeros((H, W), np.float32)
    kl_sum = np.zeros((H, W), np.float32); kl_cnt = np.zeros((H, W), np.int32)
    for i in getattr(P, "child_ids", []):
        ch = agents[i]; m = np.asarray(ch.mask)
        if m.shape != (H, W): m = resize_nn(m, (H, W))
        a = child_activity_map(ch, H, W, eps=eps)
        if a is None: continue
        inside = a & (m > eps)
        cover += inside.astype(np.int32); weight += m.astype(np.float32) * inside.astype(np.float32)
        k = getattr(ch, "cached_alignment_kl", None)
        if k is None: continue
        k = np.asarray(k); 
        if k.shape != (H, W): continue
        good = inside & np.isfinite(k)
        kl_sum[good] += k[good].astype(np.float32); kl_cnt[good] += 1
    keep = (cover >= int(getattr(config, "core_min_kids", 2))) & (weight >= float(getattr(config, "core_weight_tau", 0.6)))
    kl_mean = kl_sum / np.maximum(kl_cnt, 1); kl_mean[kl_cnt == 0] = np.inf
    keep &= (kl_mean <= float(getattr(config, "core_kl_tau", getattr(config, "tau_align_emergent", 0.30))))
    # tiny erosion
    e = keep.copy()
    e = (e & np.roll(e,1,0) & np.roll(e,-1,0) & np.roll(e,1,1) & np.roll(e,-1,1))
    return e