import numpy as np
import config
from typing import Dict, List, Optional

from parent_utils import  _label4, child_activity_map


from dataclasses import dataclass, field

from agent_schema import Agent



from gaussian_core import kl_gaussians, gaussian_pushforward_linear
from numerical_utils import sanitize_sigma
from omega import compute_inter_omega

from numerical_utils import resize_nn


@dataclass
class Region:
    id: int
    mask: np.ndarray
    state: str
    age: int = 0
    t_activated: Optional[int] = None
    child_ids: List[int] = field(default_factory=list)

@dataclass
class DetectorState:
    regions: Dict[int, Region] = field(default_factory=dict)
    next_id: int = 0
    step: int = 0

def _make_region(mask: np.ndarray, rid: int):
    """
    Construct a Region with whatever signature your project uses.
    Tries several common ctor shapes; falls back to a simple object.
    """
    area  = int((mask > 0).sum())
    state = getattr(config, "region_active_state", "active")  # or 1 / True, if your code uses enums

    # Try common constructor shapes
    attempts = [
        lambda: Region(id=rid, state=state, mask=mask, area=area),
        lambda: Region(id=rid, state=state, mask=mask),
        lambda: Region(rid, state, mask),           # positional
        lambda: Region(mask=mask),                  # legacy minimal
        lambda: Region(mask),                       # very old minimal
    ]
    for ctor in attempts:
        try:
            return ctor()
        except TypeError:
            pass

    # Fallback: lightweight object with the fields we need downstream
    class _R: pass
    R = _R()
    R.id = rid
    R.state = state
    R.mask = mask
    R.area = area
    return R


# --- PURE detection wrapper (no side effects; returns regions + cand_map) ---
def compute_detection_maps_pure(
    agents,
    *,
    H=None,
    W=None,
    min_kids=2,
    kl_tau=0.28,
    min_area=8,
    resize_fn=None,         # optional: pass parent_mask_utils.resize_nn
):
    """
    Returns (active_regions, cand_map) without touching parents/ctx/caches.

    - active_regions: dict[rid -> Region], masks guaranteed to be (H,W) float32 in [0,1]
    - cand_map: (H,W) float32 in [0,1], max over region masks
    """
    

    if H is None or W is None:
        H, W = np.asarray(agents[0].mask).shape[:2]

    active = detect_overlap_aligned_regions(
        agents, H=H, W=W,
        min_kids=min_kids,
        kl_tau=kl_tau,
        min_area=min_area,
    )

    cand_map = np.zeros((H, W), np.float32)
    if not active:
        return active, cand_map

    # normalize every region mask to (H,W) float32
    for rid, R in list(active.items()):
        m = np.asarray(getattr(R, "mask", 0.0), np.float32)
        if m.ndim != 2:
            m = np.squeeze(m)
        if m.shape != (H, W):
            if resize_fn is None:
                from parent_mask_utils import resize_nn as _resize
                m = _resize(m, (H, W)).astype(np.float32)
            else:
                m = resize_fn(m, (H, W)).astype(np.float32)
        m = np.clip(m, 0.0, 1.0)
        R.mask = m  # make the Region self-consistent but still no global mutation
        cand_map = np.maximum(cand_map, m)

    return active, cand_map



def _detect_regions_pure(agents, params, ctx):
    

    H, W = np.asarray(agents[0].mask).shape[:2]
    detector_period = int(getattr(config, "detector_period", 2))
    do_detect = ((ctx.global_step % detector_period) == 0)
    if not do_detect:
        return {}, np.zeros((H, W), np.float32)

    # --- SAFE parse for optional KL threshold ---
    _emerge = getattr(config, "emerge_tau", 0.28)
    if (_emerge is None) or (isinstance(_emerge, str) and _emerge.strip().lower() in ("none", "off", "disabled", "")):
        kl_tau = None
    else:
        kl_tau = float(_emerge)

    active = detect_overlap_aligned_regions(
        agents, H=H, W=W,
        min_kids=int(getattr(config, "seed_min_kids", 2)),
        kl_tau=kl_tau,                                # ← pass None to skip KL gating
        min_area=int(getattr(config, "emerge_min_area", 8)),
        # weight_tau comes from config.parent_weight_tau inside the detector
    )

    cand_map = np.zeros((H, W), np.float32)
    for R in active.values():
        cand_map = np.maximum(cand_map, np.asarray(R.mask, np.float32))
    return active, cand_map








def compute_pairwise_agreement_maps(children, tau=0.10, eps=1e-6, tcap=10.0,
                                    field="q", generators=None):
    """
    Build per-pair, per-pixel soft agreement maps among overlapping agents.

    `field`: "q" (belief) uses agents' 'phi'; "p" (model) uses 'phi_model'.
    `generators`: pass the irrep generators to use (e.g., Gq or Gp).
    """
    import numpy as _np

    H, W = children[0].mask.shape
    pairs, A, joint = [], {}, {}

    def _get_mu(c): return getattr(c, f"mu_{field}_field")
    def _get_S(c): return sanitize_sigma(getattr(c, f"sigma_{field}_field"), eps=eps)
    phi_field = "phi" if field == "q" else "phi_model"

    N = len(children)
    for i in range(N):
        ci = children[i]; mi = (ci.mask > eps)
        if not mi.any(): continue
        for j in range(i + 1, N):
            cj = children[j]; mj = (cj.mask > eps)
            J = (mi & mj)
            if not J.any(): continue

            ys, xs = _np.nonzero(J)
            y = int(_np.median(ys)); x = int(_np.median(xs))

            # Ω_ij at a representative overlap pixel; broadcast across (H,W)
            Ω = compute_inter_omega(ci, cj, (y, x), field=phi_field, generators=generators)  # (K,K)
            K = Ω.shape[0]
            Omega_ij = _np.broadcast_to(Ω, (H, W, K, K))
            Omega_ji = _np.swapaxes(Omega_ij, -1, -2)

            mu_i, S_i = _get_mu(ci), _get_S(ci)
            mu_j, S_j = _get_mu(cj), _get_S(cj)

            mu_j_t, S_j_t = gaussian_pushforward_linear(mu_j, S_j, Omega_ij)
            mu_i_t, S_i_t = gaussian_pushforward_linear(mu_i, S_i, Omega_ji)

            s_ij = kl_gaussians(mu_i, S_i, mu_j_t, S_j_t, eps=eps)
            s_ji = kl_gaussians(mu_j, S_j, mu_i_t, S_i_t, eps=eps)
            s_sym = 0.5 * (s_ij + s_ji)

            a = _np.zeros((H, W), dtype=_np.float32)
            s_cap = _np.minimum(s_sym[J], tcap)
            a[J] = _np.exp(-s_cap / float(tau))

            key = (i, j)
            pairs.append(key)
            A[key] = a
            joint[key] = J

    return pairs, A, joint








def _alignment_score_from_pairs(children: List[Agent], *, field: str, generators, tau=0.30) -> np.ndarray:
    """
    Fast proxy: 1 - mean(agreement) over all neighbors per pixel.
    Uses your compute_pairwise_agreement_maps (A = exp(-KL/tau)).
    """
    H, W = children[0].mask.shape
    pairs, A_maps, joint = compute_pairwise_agreement_maps(children, tau=tau, field=("q" if field=="belief" else "p"), generators=generators)
    if not pairs:
        return np.ones((H, W), dtype=np.float32)
    acc = np.zeros((H, W), dtype=np.float32)
    cnt = np.zeros((H, W), dtype=np.float32)
    for key, A in A_maps.items():
        J = joint[key]
        acc[J] += A[J]
        cnt[J] += 1.0
    cnt = np.maximum(cnt, 1.0)
    agree_mean = acc / cnt
    return 1.0 - agree_mean  # lower is better






def _update_regions_hysteresis(det: DetectorState, score: np.ndarray,
                               *, Ton: float, Toff: float,
                               persistence_on: int, persistence_off: int,
                               min_area: int, smooth_iters: int) -> None:
    """
    Very small state machine: grow where score<Ton, decay where score>Toff.
    """
    H, W = score.shape
    low = (score < Ton).astype(np.float32)
    high = (score > Toff).astype(np.float32)

    # simple smoothing (same kernel as your utils)
    if smooth_iters > 0:
        k = np.array([[1,1,1],[1,2,1],[1,1,1]], dtype=np.float32); k /= k.sum()
        for _ in range(smooth_iters):
            pad = np.pad(low, 1, mode="edge")
            sm  = (
                k[0,0]*pad[:-2, :-2] + k[0,1]*pad[:-2,1:-1] + k[0,2]*pad[:-2,2:] +
                k[1,0]*pad[1:-1, :-2] + k[1,1]*pad[1:-1,1:-1] + k[1,2]*pad[1:-1,2:] +
                k[2,0]*pad[2:,  :-2] + k[2,1]*pad[2:, 1:-1] + k[2,2]*pad[2:,  2:]
            )
            low = np.clip(sm, 0.0, 1.0).astype(np.float32)

    # single region for now: union of low-score (you can split components if desired)
    core = (low > 0.5)
    area = int(core.sum())

    # find (or create) region 0
    R = det.regions.get(0, None)
    if R is None:
        if area >= min_area:
            det.regions[0] = Region(id=0, mask=low.copy(), state="incubating", age=0, t_activated=None)
        return

    # update existing
    R.age += 1
    if area == 0:
        if R.state in ("incubating", "active"):
            R.state = "decaying"
        # shrink fast
        R.mask *= 0.5
    else:
        # grow towards low
        R.mask = np.clip(0.90*R.mask + 0.10*low, 0.0, 1.0)
        if R.state == "candidate":
            if (R.mask > 0.3).sum() >= min_area and R.age >= persistence_on:
                R.state = "incubating"
        elif R.state == "incubating":
            if (R.mask > 0.3).sum() >= min_area and R.age >= persistence_on:
                R.state = "active"; R.t_activated = det.step
        elif R.state == "active":
            if (high > 0.5).mean() > 0.5 and R.age >= persistence_off:
                R.state = "decaying"

    if R.state == "decaying":
        R.mask *= 0.8
        if (R.mask > 0.3).sum() < (min_area // 2):
            del det.regions[0]


def detect_overlap_aligned_regions(children, *, H, W,
                                   min_kids=2,
                                   kl_tau=0.10,
                                   min_area=20,
                                   weight_tau=0.6,         # float or None (None = adaptive)
                                   activity_mu_tau=1e-3, activity_trsig_tau=1e-3,
                                   eps=1e-6,
                                   periodic=None):
    """
    Find regions where ≥min_kids children are active, the average child mask is strong,
    and the average alignment KL is low. Returns {rid: Region}.

    Improvements:
      • Activity fallback to mask if child_activity_map(...) returns None.
      • Interior weight gate supports adaptive threshold when weight_tau is None.
      • KL gate applies only if at least one child provided a finite KL map.
      • Optional 1px erosion (detector_edge_erode) happens after forming 'keep'.
    """
    import numpy as np
    if periodic is None:
        periodic = bool(getattr(config, "periodic_domain", False))

    cover  = np.zeros((H, W), dtype=np.int32)    # number of active kids
    weight = np.zeros((H, W), dtype=np.float32)  # sum of child mask weights
    kid_act, kid_kls = [], []

    # 1) accumulate activity, weights, and cached KLs
    mask_tau_mask = float(getattr(config, "detector_mask_tau", 1e-3))
    for ch in children:
        m = np.asarray(getattr(ch, "mask", 0.0))
        if m.shape != (H, W):
            m = resize_nn(m, (H, W)).astype(np.float32)
        else:
            m = m.astype(np.float32)

        act = child_activity_map(ch, H, W,
                                 mu_tau=activity_mu_tau,
                                 trsig_tau=activity_trsig_tau,
                                 eps=eps)
        # Fallback: if no explicit activity, use mask>tiny
        if act is None:
            a = (m > mask_tau_mask)
        else:
            a = np.asarray(act).astype(bool)

        cover  += a.astype(np.int32)
        weight += m * a.astype(np.float32)
        kid_act.append(a)

        k = getattr(ch, "cached_alignment_kl", None)
        if k is None:
            kid_kls.append(None)
        else:
            k = np.asarray(k)
            if k.shape != (H, W):
                k = resize_nn(k, (H, W))
            kid_kls.append(k.astype(np.float32))

    # 2) interior preference: require enough active kids AND strong mean mask
    keep = (cover >= int(min_kids))
    mean_weight = np.zeros((H, W), dtype=np.float32)
    nz = cover > 0
    mean_weight[nz] = weight[nz] / cover[nz].astype(np.float32)

    # interior weight gate (adaptive if weight_tau is None)
    cfg_tau = getattr(config, "parent_weight_tau", weight_tau)
    if cfg_tau is None:
        ww = mean_weight[(cover >= int(min_kids)) & (mean_weight > 0)]
        thr = float(np.percentile(ww, 60)) if ww.size else 0.0
    else:
        thr = float(cfg_tau)
    keep &= (mean_weight >= thr)

    # 3) KL filter (average over active, finite pixels) — only if any KL exists
    if kl_tau is not None:
        any_kl = any(k is not None for k in kid_kls)
        if any_kl:
            kl_sum = np.zeros((H, W), dtype=np.float32)
            kl_cnt = np.zeros((H, W), dtype=np.int32)
            for a, k in zip(kid_act, kid_kls):
                if k is None:
                    continue
                inside = a & np.isfinite(k)
                if inside.any():
                    kl_sum[inside] += k[inside]
                    kl_cnt[inside] += 1
            kl_mean = np.full((H, W), np.inf, dtype=np.float32)
            valid = kl_cnt > 0
            kl_mean[valid] = kl_sum[valid] / np.maximum(kl_cnt[valid], 1)
            keep &= (kl_mean <= float(kl_tau))
        # else: skip KL gating entirely if no KL present

    # --- connected components with optional 1px erosion ---
    pre_px = int(np.asarray(keep).sum())
    core = keep.astype(bool)

    erode_iters = int(getattr(config, "detector_edge_erode", 0))  # default OFF
    if erode_iters > 0 and core.any():
        for _ in range(erode_iters):
            if periodic:
                e = core.copy()
                e &= np.roll(core,  1, 0)
                e &= np.roll(core, -1, 0)
                e &= np.roll(core,  1, 1)
                e &= np.roll(core, -1, 1)
                core = e
            else:
                up    = np.pad(core[1: , : ], ((0,1), (0,0)))
                down  = np.pad(core[:-1, : ], ((1,0), (0,0)))
                left  = np.pad(core[: , 1: ], ((0,0), (0,1)))
                right = np.pad(core[: , :-1], ((0,0), (1,0)))
                core = core & up & down & left & right

    post_px = int(core.sum())
    min_area_eff = int(getattr(config, "emerge_min_area", min_area))

    # CC
    labels, nlab = _label4(core)
    regions = {}
    rid = 0
    for lbl in range(1, nlab + 1):
        comp = (labels == lbl)
        area = int(comp.sum())
        if area < min_area_eff:
            continue
        regions[rid] = _make_region(comp.astype(np.float32), rid)
        rid += 1

    # debug
    try:
        tau_repr = f"{cfg_tau:.3f}" if cfg_tau is not None else f"auto->{thr:.3f}"
        print(f"[DETECT] regs={len(regions)} px_keep={pre_px} px_post={post_px} "
              f"min_area={min_area_eff} weight_tau={tau_repr} "
              f"cover_sum={int(cover.sum())} mean_w={float(np.nan_to_num(mean_weight).mean()):.3f}")
    except Exception:
        pass

    return regions






def detector_tick(agents: List[Agent], det: DetectorState, *,
                  field: str, generators, cfg: dict) -> Dict[int, Region]:
    """
    One call per detector_period. Updates det.regions in-place and returns active regions.
    cfg keys: Ton, Toff, persistence_on, persistence_off, min_area, smooth_iters, tau_align
    """
    det.step += 1
    score = _alignment_score_from_pairs(agents, field=field, generators=generators, tau=cfg.get("tau_align", 0.30))
    _update_regions_hysteresis(
        det, score,
        Ton=cfg.get("Ton", 0.10),
        Toff=cfg.get("Toff", 0.20),
        persistence_on=cfg.get("persistence_on", 3),
        persistence_off=cfg.get("persistence_off", 3),
        min_area=int(cfg.get("min_area", 50)),
        smooth_iters=int(cfg.get("smooth_iters", 1)),
    )
    return {rid: R for rid, R in det.regions.items() if R.state == "active"}


