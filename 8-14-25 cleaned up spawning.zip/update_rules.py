# -*- coding: utf-8 -*-
"""
Created on Wed Jul 23 10:32:58 2025

@author: chris and christine
"""
import numpy as np
import config
from detector import DetectorState, _detect_regions_pure
from update_compute_all_gradients import ( 
                        _apply_children, _compute_child_grads, _parent_intrascale_grad_pass, 
                        _final_apply_parents)
from update_rules_utils import ( _pre_light,  _post_strict,
                                _refresh_child_kl_fields, 
                                 _assign_children_to_parents, 
                                _grow_and_age_parents, _as_parent_dict )

from preprocess_utils import preprocess_all_agents, build_all_omega_caches, build_all_lambda_caches

from parent_spawn import _apply_spawn_from_regions


def synchronous_step(agents, generators_q, generators_p, params=None, n_jobs=1, runtime_ctx=None):
    
    # at the very start of synchronous_step
    runtime_ctx.parents_by_region = _as_parent_dict(getattr(runtime_ctx, "parents_by_region", {}))

    assert agents and (len(agents) > 0), "synchronous_step: no agents"
    assert runtime_ctx is not None, "synchronous_step: pass runtime_ctx"
    params = params or {}
    eps = config.eps

    
    # runtime ctx init
    if not hasattr(runtime_ctx, "detector_state") or (runtime_ctx.detector_state is None):
        runtime_ctx.detector_state = DetectorState()
    if not hasattr(runtime_ctx, "global_step"):
        runtime_ctx.global_step = 0
    if not hasattr(runtime_ctx, "parents_by_region"):
        runtime_ctx.parents_by_region = {}
    if not hasattr(runtime_ctx, "next_parent_id"):
        runtime_ctx.next_parent_id = 0

    # freeze sets
    frozen_levels     = set(params.get("frozen_levels", []))
    frozen_phi_levels = set(params.get("frozen_phi_levels", []))

    # --- PRE ---------------------------------------------------------------
    all_agents = agents + list(runtime_ctx.parents_by_region.values())
    _pre_light(all_agents, params, generators_q, generators_p)

    # --- GRADS (children) --------------------------------------------------
    grads = _compute_child_grads(agents, all_agents, generators_q, generators_p, params)

    # --- APPLY (children) --------------------------------------------------
    _apply_children(agents, grads, params, frozen_levels, frozen_phi_levels, generators_q, generators_p, n_jobs)

    # --- OPTIONAL parent intrascale grad pass (kept as-is) -----------------
    parents = list(runtime_ctx.parents_by_region.values())
    _parent_intrascale_grad_pass(agents, parents, generators_q, generators_p, params, accum_into=True)

    # --- POST (strict refresh pre-detect) ----------------------------------
    all_agents = agents + list(runtime_ctx.parents_by_region.values())
    _post_strict(all_agents, params, generators_q, generators_p)

    # refresh cached KL fields for children
    _refresh_child_kl_fields(agents, all_agents, eps)

    if getattr(config, "debug_grad_timing", False):
        print(f"[STEP {runtime_ctx.global_step}] "
              f"parents={len(runtime_ctx.parents_by_region)} "
              f"mean_KL_q={np.nanmean([getattr(a,'cached_alignment_kl',0) for a in agents]):.3g}")

   
    # --- Phase C: DETECT (pure) -----------------------------------------------
    
    active_regions, cand_map = _detect_regions_pure(agents, params, runtime_ctx)
    
    # --- Phase C’: SPAWN (mutating) -------------------------------------------
    if active_regions:
        _apply_spawn_from_regions(runtime_ctx, active_regions, cand_map,
                                  agents, generators_q, generators_p, params)
            
    
    # --- Phase D: ONE central refresh + transport caches ----------------------
    all_agents = agents + list(runtime_ctx.parents_by_region.values())
    _post_strict(all_agents, params, generators_q, generators_p)   # strict sanitize + exp(...)
    
    # --- ASSIGN kids→parents ---------------------------------------------------
    _assign_children_to_parents(agents, runtime_ctx.parents_by_region,
                                eps=getattr(config, "support_cutoff_eps", 1e-3))
    
   
    # --- GROW/SHRINK + AGE -----------------------------------------------------
    _grow_and_age_parents(runtime_ctx, agents, params)
    

    
    # --- FINAL APPLY (parents) -------------------------------------------------
    _final_apply_parents(runtime_ctx, params)
    
    
    # book-keeping for viz
    runtime_ctx.children_latest = agents
    runtime_ctx.parents_latest  = runtime_ctx.parents_by_region
    runtime_ctx.global_step    += 1
    return agents







# debug_watch.py
import numpy as np

def _shape(a):
    try: return tuple(np.asarray(a).shape)
    except: return None

def audit_sigma_shapes(agents, tag, *, raise_on_stack=False):
    bad = []
    for a in agents:
        Sq = getattr(a, "sigma_q_field", None)
        Sp = getattr(a, "sigma_p_field", None)
        msgq = f"{getattr(a,'id','?')}: q={_shape(Sq)}"
        msgp = f"{getattr(a,'id','?')}: p={_shape(Sp)}"
        print(f"[AUDIT:{tag}] {msgq}  {msgp}")
        for name, S in (("sigma_q_field", Sq), ("sigma_p_field", Sp)):
            if S is None: continue
            S = np.asarray(S)
            if S.ndim != 4 or S.shape[-1] != S.shape[-2]:
                bad.append((a, name, S.shape))
                if raise_on_stack:
                    raise RuntimeError(f"[AUDIT:{tag}] {name} bad shape {S.shape} for agent {getattr(a,'id','?')}")
    return bad

