# -*- coding: utf-8 -*-
"""
Created on Thu Aug 14 09:17:47 2025

@author: chris and christine
"""

import numpy as np
import config
from runtime_context import runtime_ctx


from parent_utils import ( _as_parent_dict,  _ensure_parent_store, _components, 
                           _too_close_by_iou,_build_child_groups, _find_group_peaks, _new_parent)
                         
from bundle_morphism_utils import (init_parent_morphisms, have_parent_morphisms, 
                                    compute_direct_morphisms  )

from agent_initialization import initialize_agent_gradients

from parent_utils import (ensure_hw, _dilate_bool, _compute_candidate_or_union, 
                          _growth_gate_from_overlap_core_activity, _should_reseed) 
                              
from bundle_coarsegrain_init import coarsegrain_parent_from_children, _refresh_parent_gauge_fields
from numerical_utils import resize_nn



def _emergence_gate(P, children, eval_mask, H, W, eps):
    """
    Decide whether a parent 'emerges' (becomes active).
    Safe when KL is missing and when emerge_tau=None (disables KL test).
    """
    import numpy as np
    # config knobs
    MIN_AREA   = int(getattr(config, "emerge_min_area", 2))
    MIN_KIDS   = int(getattr(config, "seed_min_kids", 2))
    EMERGE_TAU = getattr(config, "emerge_tau", None)  # may be float or None

    # area gate
    area_ok = bool(np.asarray(eval_mask).sum() >= MIN_AREA)

    # overlap/children gate (count kids active on eval_mask)
    kids_ok = False
    if getattr(P, "child_ids", None):
        cnt = 0
        for i in P.child_ids:
            ch = children[i]
            m = np.asarray(getattr(ch, "mask", 0.0), np.float32)
            if m.shape != (H, W):
                m = resize_nn(m, (H, W))
            # "active" if mask exceeds tiny eps somewhere on eval region
            if ( (m > eps) & eval_mask ).any():
                cnt += 1
        kids_ok = (cnt >= MIN_KIDS)
    else:
        # fallback: if no explicit child_ids tracked, be permissive
        kids_ok = True

    # KL gate (median over eval_mask), but only if any KL exists and EMERGE_TAU is not None
    kl_ok = True
    if EMERGE_TAU is not None:
        kl_vals = []
        for i in getattr(P, "child_ids", range(len(children))):
            ch = children[i] if isinstance(i, int) else i
            k = getattr(ch, "cached_alignment_kl", None)
            if k is None:
                continue
            k = np.asarray(k)
            if k.shape != (H, W):
                k = resize_nn(k, (H, W))
            sel = eval_mask & np.isfinite(k)
            if sel.any():
                kl_vals.append(k[sel])
        if kl_vals:
            vec = np.concatenate(kl_vals).astype(np.float32, copy=False)
            kl_med = float(np.median(vec))
            kl_ok = (kl_med <= float(EMERGE_TAU))
        else:
            # no KL available → skip KL gating
            kl_ok = True

    emerged = bool(area_ok and kids_ok and kl_ok)

    # Optional: latch behavior / hysteresis (preserve once emerged)
    if getattr(P, "emerged", False):
        # you can add a soft condition to keep emerged unless area collapses completely
        if not area_ok:
            return False
        return True

    return emerged



# --- spawn_or_update_parents (refactored) ------------------------------------
def spawn_or_update_parents(active_regions, agents, parents_by_id, next_parent_id, *, field_generators):
    """
    Pipeline:
      0) normalize inputs
      1) group children by overlap inside each active region
      2) compute per-group consensus & local peaks (NMS)
      3) match peaks to existing parents (IoU + child-set jaccard), else spawn
      4) init/ensure morphisms
      5) optional reseed/rehome to proposal
      6) per-parent update (growth etc.)
    Returns (list(parents_by_id.values()), next_parent_id)
    """
    

    Gq, Gp = field_generators
    if not agents:
        return list(parents_by_id.values()), next_parent_id

    H, W   = np.asarray(agents[0].mask).shape[:2]
    dtype  = agents[0].mu_q_field.dtype
    Kq     = int(agents[0].mu_q_field.shape[-1])
    Kp     = int(agents[0].mu_p_field.shape[-1])
    eps    = float(getattr(config, "support_cutoff_eps", 1e-6))

    # -------------------------------------------------------------------------
    # 0) Normalize active_regions
    region_masks = _norm_active_regions(active_regions, (H, W))

    # 1) Group children by overlap per region
    groups = _build_child_groups(region_masks, agents, (H, W),
                                 child_eps=float(getattr(config, "child_support_tau", 0.10)),
                                 min_child_area=int(getattr(config, "min_child_area_px", 6)),
                                 intra_iou_thr=float(getattr(config, "child_intragroup_iou_thr", 0.55)),
                                 min_group_kids=int(getattr(config, "parent_grow_min_kids", 2)))

    # Fast exit if nothing to do and we already have parents
    if not groups and not parents_by_id:
        return list(parents_by_id.values()), next_parent_id

    # 2) Peak finding (per group)
    peak_cfg = dict(
        peak_min_cons   = float(getattr(config, "parent_peak_min_consensus", 0.60)),
        peak_nms_r      = int(getattr(config, "parent_peak_nms_px", 6)),
        peak_max_per_gp = int(getattr(config, "parent_peak_max_per_group", 3)),
        min_group_kids  = int(getattr(config, "parent_grow_min_kids", 2)),
        child_eps       = float(getattr(config, "child_support_tau", 0.10)),
        seed_halo_px    = int(getattr(config, "parent_seed_expand_px", 2)),
    )
    peaks = _find_group_peaks(groups, agents, (H, W), **peak_cfg)

    # 3) Match peaks to existing parents or spawn
    match_cfg = dict(
        match_iou_thr   = float(getattr(config, "parent_match_iou_existing", 0.45)),
        child_jac_thr   = float(getattr(config, "parent_child_jaccard_thr", 0.50)),
        support_tau     = float(getattr(config, "parent_support_tau", 0.08)),
        max_new_per_step= int(getattr(config, "parent_max_new_per_step", 2)),
        min_interseed_px= int(getattr(config, "parent_min_interseed_px", 6)),
    )
    next_parent_id = _match_or_spawn(peaks, parents_by_id, next_parent_id, agents,
                                     (H, W, dtype, Kq, Kp), (Gq, Gp), **match_cfg)

    # 4) Ensure morphisms present
    parents_list = list(parents_by_id.values())
    for P in parents_list:
        if not have_parent_morphisms(P):
            init_parent_morphisms(P, generators_q=Gq, generators_p=Gp)

    # 5) One-shot reseed/rehome to proposal if requested
    _apply_one_shot_reseed(parents_list, dtype,
                           seed_amp=float(getattr(config, "parent_seed_amp", 0.55)))

    # 6) Per-parent update using your existing updater
    try:
        step_now = int(getattr(runtime_ctx, "global_step", 0))
    except NameError:
        step_now = 0
    for P in parents_list:
        _update_single_parent(P, agents, step_now, H, W, eps, dtype)

    # Finalize caches
    _refresh_parent_gauge_fields(parents_list, agents, dtype=None)
    for P in parents_list:
        P._exp_phi = P._exp_neg_phi = None
        P._exp_phi_model = P._exp_neg_phi_model = None

    return list(parents_by_id.values()), next_parent_id



def _update_single_parent(P, agents, step_now, H, W, eps, dtype):
    

    # --- knobs (new ones have safe defaults) --------------------------------
    freeze_steps  = max(0, int(getattr(config, "parent_freeze_steps", 2)))
    ramp_steps    = max(0, int(getattr(config, "parent_ramp_steps", 12)))
    alpha_base    = float(getattr(config, "parent_mask_alpha", 0.10))
    grow_min_kids = int(getattr(config, "parent_grow_min_kids", 2))
    delta_cap     = float(getattr(config, "parent_max_step_delta", 0.1))
    decay_empty   = 0.995
    periodic      = bool(getattr(config, "periodic_domain", False))

    # NEW: what counts as "support" for locality/dilation
    support_tau   = float(getattr(config, "parent_support_tau", 0.05))
    # NEW: local expansion halo around current support
    local_r_px    = int(getattr(config, "parent_local_radius_px", 3))
    # NEW: gently kill any mass far from support
    far_decay     = float(getattr(config, "parent_far_decay", 0.98))  # 1.0 = off
    # NEW: hard floor to zero-out dust
    floor_eps     = float(getattr(config, "parent_floor_eps", 1e-4))

    kids = getattr(P, "child_ids", [])
    # -- seed from core (unchanged) ------------------------------------------
    if (P.mask <= 1e-6).all() and P._core_map is not None and P._core_map.any():
        seed = P._core_map.astype(bool)
        expand_px = max(0, int(getattr(config, "parent_seed_expand_px", 2)))
        if expand_px > 0:
            seed = _dilate_bool(seed, r=expand_px, periodic=periodic)
        P.mask = seed.astype(dtype) * 0.5

    cand = _compute_candidate_or_union(P, agents, H, W, dtype)

    # emergence gate (unchanged) ---------------------------------------------
    eval_mask = (P.mask > 1e-2)
    if not eval_mask.any():
        if getattr(P, "_region_proposal", None) is not None:
            eval_mask = (np.asarray(P._region_proposal) > 1e-2)
        elif cand is not None:
            eval_mask = (np.asarray(cand) > 1e-2)

    emerged = _emergence_gate(P, agents, eval_mask, H, W, eps)
    P.emerged = bool(emerged)

    if not P.emerged:
        target = None
        if getattr(P, "_region_proposal", None) is not None:
            target = np.asarray(P._region_proposal, dtype=np.float32)
        elif cand is not None:
            target = np.asarray(cand, dtype=np.float32)
        if target is not None:
            alpha_seed = float(getattr(config, "parent_seed_alpha", 0.15))
            pm = P.mask.astype(np.float32)
            P.mask = np.clip((1.0 - alpha_seed) * pm + alpha_seed * target, 0.0, 1.0).astype(dtype)
        return

    # EMA schedule (unchanged) -----------------------------------------------
    age = max(0, int(step_now - getattr(P, "birth_step", step_now)))
    if age < freeze_steps:
        alpha = 0.0
    else:
        denom = max(1, ramp_steps)
        ramp  = min(1.0, max(0.0, (age - freeze_steps) / denom))
        alpha = float(np.clip(alpha_base * ramp, 0.0, alpha_base))

    # no candidate → gentle decay and exit
    if cand is None:
        P.mask = (decay_empty * P.mask).astype(dtype)
        return

    # growth gates ------------------------------------------------------------
    gate = _growth_gate_from_overlap_core_activity(P, agents, H, W, eps, grow_min_kids).astype(np.float32)

    # sanitize candidate
    cand = np.asarray(cand, np.float32)
    cand = np.nan_to_num(cand, nan=0.0, posinf=1.0, neginf=0.0)
    cand = np.clip(cand, 0.0, 1.0)

    

    # bands + locality (CRITICAL change: use support_tau, not 1e-3)
    grow_band = max(1, int(getattr(config, "grow_band", 1)))
    pm       = P.mask.astype(np.float32)
    mask_bin = (pm > support_tau)                         # << was 1e-3
    dil      = _dilate_bool(mask_bin, r=grow_band, periodic=periodic)
    outer    = dil & (~mask_bin)

    # ring boost only on 'outer'
    growth_prob = np.clip(gate, 0.0, 1.0)
    eta_ring    = float(getattr(config, "eta_grow", 0.5))
    ring_target = np.clip(pm + eta_ring * growth_prob, 0.0, 1.0)
    cand        = np.where(outer, np.maximum(cand, ring_target), cand)
    cand        = (cand * growth_prob).astype(np.float32)

    # keep updates local: only chase cand near support
    local = _dilate_bool(mask_bin, r=max(local_r_px, grow_band), periodic=periodic)
    target = pm + growth_prob * (cand - pm)
    target = np.where(local, target, pm)                  # freeze far field

    # snap vs EMA toward target
    if _should_reseed(P, target):
        new_mask = target.astype(np.float32)
    else:
        delta = alpha * (target - pm)
        if delta_cap > 0:
            delta = np.clip(delta, -delta_cap, delta_cap)
        new_mask = np.clip(pm + delta, 0.0, 1.0).astype(np.float32)

    # --- NEW: far-field decay + floor (kills baseline creep) ----------------
    if far_decay < 1.0:
        far = ~_dilate_bool(mask_bin, r=max(local_r_px, grow_band), periodic=periodic)
        # Only decay truly far pixels (avoid touching core/outer)
        new_mask[far] *= far_decay
    if floor_eps > 0.0:
        new_mask[new_mask < floor_eps] = 0.0

    P.mask = new_mask.astype(dtype)




def _make_parent_template(ctx, tmpl, *, pid: int, H: int, W: int, Kq: int, Kp: int,
                          generators_q, generators_p):
    """Construct a brand-new level-1 parent with safe defaults and gradient buffers."""
    import numpy as np

    AgentCls = tmpl.__class__
    dtype = tmpl.mu_q_field.dtype

    # identities, broadcasted (lighter than tile) but materialized via copy
    eye_q = np.broadcast_to(np.eye(Kq, dtype=dtype), (H, W, Kq, Kq)).copy()
    eye_p = np.broadcast_to(np.eye(Kp, dtype=dtype), (H, W, Kp, Kp)).copy()

    P = AgentCls(
        id=pid, center=(0, 0), radius=0.0,
        mask=np.zeros((H, W), np.float32),
        mu_q_field=np.zeros((H, W, Kq), dtype=dtype), sigma_q_field=eye_q,
        mu_p_field=np.zeros((H, W, Kp), dtype=dtype), sigma_p_field=eye_p,
        phi=np.zeros((H, W, 3), dtype=dtype), phi_model=np.zeros((H, W, 3), dtype=dtype),
        neighbors=[]
    )

    P.level = 1
    P.emerged = True
    P._age = 0
    P._grace = int(getattr(config, "parent_grace_steps", 2))
    P._shrink_strikes = 0
    P.Omega_cache = {}; P.Omega_tilde_cache = {}
    P._exp_phi = P._exp_neg_phi = None
    P._exp_phi_model = P._exp_neg_phi_model = None
    P.generators_q = generators_q
    P.generators_p = generators_p

    # Base morphisms
    P.Phi_0       = np.eye(Kp, Kq, dtype=dtype)
    P.Phi_tilde_0 = np.eye(Kq, Kp, dtype=dtype)
    try:
        P.bundle_morphism_q_to_p, P.bundle_morphism_p_to_q = compute_direct_morphisms(
            phi=P.phi, phi_model=P.phi_model,
            generators_q=P.generators_q, generators_p=P.generators_p,
            Phi_0=P.Phi_0, Phi_tilde_0=P.Phi_tilde_0,
        )
    except Exception:
        P.bundle_morphism_q_to_p = np.broadcast_to(P.Phi_0, (H, W, Kp, Kq)).copy()
        P.bundle_morphism_p_to_q = np.broadcast_to(P.Phi_tilde_0, (H, W, Kq, Kp)).copy()

    # Initialize gradient buffers
    initialize_agent_gradients(P)
    
    # --- Guardrails: enforce 4D shapes + SPD once at birth ------------------
    def _spd_tidy(S):
        if S is None: return None
        S = 0.5*(S + np.swapaxes(S, -1, -2))
        K = S.shape[-1]
        return S + (1e-8 * np.eye(K, dtype=S.dtype))
    assert P.sigma_q_field.ndim == 4 and P.sigma_q_field.shape[-1] == P.sigma_q_field.shape[-2], \
        f"sigma_q_field bad shape {P.sigma_q_field.shape}"
    assert P.sigma_p_field.ndim == 4 and P.sigma_p_field.shape[-1] == P.sigma_p_field.shape[-2], \
        f"sigma_p_field bad shape {P.sigma_p_field.shape}"
    P.sigma_q_field = _spd_tidy(P.sigma_q_field)
    P.sigma_p_field = _spd_tidy(P.sigma_p_field)

    P.birth_step = int(getattr(ctx, "global_step", 0))
    return P

def _match_or_spawn(peaks, parents_by_id, next_parent_id, agents, shape_info, generators, *,
                    match_iou_thr, child_jac_thr, support_tau, max_new_per_step, min_interseed_px):
    """Update/Spawn parents from peak proposals."""
    import numpy as np
    H, W, dtype, Kq, Kp = shape_info
    Gq, Gp = generators

    def _iou(a, b):
        inter = np.count_nonzero(a & b)
        if inter == 0: return 0.0
        return inter / float(np.count_nonzero(a | b))

    def _jac(a: set, b: set):
        if not a and not b: return 1.0
        if not a or not b:  return 0.0
        return len(a & b) / float(len(a | b))

    # cache existing supports/centers/kids
    exists_support = {pid: (ensure_hw(getattr(P,"mask",0.0),(H,W)) > support_tau)
                      for pid, P in parents_by_id.items()}
    exists_kids = {pid: set(getattr(P, "child_ids", []))
                   for pid, P in parents_by_id.items()}
    chosen_centers = []
    for pid, P in parents_by_id.items():
        m = ensure_hw(getattr(P,"mask",0.0),(H,W)) > support_tau
        ys, xs = np.nonzero(m)
        if ys.size: chosen_centers.append((float(ys.mean()), float(xs.mean())))

    def _respect_spacing(cy, cx):
        R2 = float(max(1, min_interseed_px))**2
        for (py, px) in chosen_centers:
            if (py - cy)**2 + (px - cx)**2 < R2:
                return False
        return True

    # budget new spawns
    new_spawned = 0
    for peak in sorted(peaks, key=lambda d: -d["score"]):
        if new_spawned >= max_new_per_step:
            break
        cy, cx = peak["cy"], peak["cx"]
        if not _respect_spacing(cy, cx):
            continue

        local_bool = (peak["proposal"] > 0.25)
        gkids_set  = set(peak["child_ids"])

        # try to match an existing parent
        best_pid, best_score = None, (-1.0, -1.0)
        for pid, supp in exists_support.items():
            iou = _iou(local_bool, supp)
            if iou < match_iou_thr: 
                continue
            jac = _jac(gkids_set, exists_kids[pid])
            if jac < child_jac_thr:
                continue
            sc = (iou, jac)
            if sc > best_score:
                best_score = sc; best_pid = pid

        if best_pid is not None:
            P = parents_by_id[int(best_pid)]
            P.child_ids = list(peak["child_ids"])
            P._region_proposal = peak["proposal"].astype(np.float32)
            setattr(P, "_force_reseed_once", True)
            continue

        # spawn new
        pid = int(next_parent_id); next_parent_id += 1
        P = _make_parent_template(runtime_ctx, agents[0], pid=pid, H=H, W=W, Kq=Kq, Kp=Kp,
                                  generators_q=Gq, generators_p=Gp)
        P.child_ids = list(peak["child_ids"])
        P._region_proposal = peak["proposal"].astype(np.float32)

        # gaussian seed near peak (clipped to local proposal)
        seed_amp   = float(getattr(config, "parent_seed_amp", 0.55))
        seed_sigma = float(getattr(config, "parent_seed_feather_sigma", 1.0))
        seed_r0    = float(getattr(config, "parent_seed_radius_px", 4.0))
        yy, xx = np.ogrid[:H,:W]
        d2 = (yy - int(round(cy)))**2 + (xx - int(round(cx)))**2
        seed = np.exp(-0.5*(d2/max(1.0, seed_r0*seed_r0))).astype(np.float32)
        # feather & clip
        try:
            from scipy.ndimage import gaussian_filter
            seed = gaussian_filter(seed * local_bool.astype(np.float32), seed_sigma, mode="nearest")
        except Exception:
            seed = seed * local_bool.astype(np.float32)
        if seed.max() > 0: seed /= (seed.max()+1e-8)
        P.mask = np.clip(seed_amp * seed, 0.0, 1.0).astype(dtype)

        P.birth_step = int(getattr(runtime_ctx, "global_step", 0))
        P._age = 0
        P._grace = int(getattr(config, "parent_freeze_steps", 0))
        parents_by_id[int(pid)] = P
        exists_support[int(pid)] = (P.mask > support_tau)
        exists_kids[int(pid)] = set(P.child_ids)
        new_spawned += 1
        chosen_centers.append((cy, cx))
    return next_parent_id



def seed_new_parents_from_uncovered(runtime_ctx, candidate_map, *,
                                    children, generators_q, generators_p,
                                    min_area: int,
                                    cover_tau: float = 0.10,
                                    iou_thr: float = 0.40,
                                    max_new_per_step: int | None = None,
                                    min_interseed_px: int | None = None) -> list[int]:
    """
    Seed new parents from uncovered regions in candidate_map (H,W) boolean/float.
    - Filters by area, IoU vs existing parents, and min spacing.
    - Initializes fields and coarse-grains μ/Σ from children.
    - Returns list of new parent IDs.
    """
    

    # optional blur for feathering
    try:
        from scipy.ndimage import gaussian_filter as _gblur
        _HAS_SCIPY = True
    except Exception:
        _HAS_SCIPY = False

    max_new_per_step = int(max_new_per_step or getattr(config, "parent_max_new_per_step", 2))
    min_interseed_px = int(min_interseed_px or getattr(config, "parent_min_interseed_px", 6))

    parents = _ensure_parent_store(runtime_ctx)
    H, W = np.asarray(candidate_map).shape[:2]
    cand = (np.asarray(candidate_map, np.float32) > float(cover_tau))
   
    # Exclude a margin around any existing parent to kill the “ring of fire”.
    
    periodic = bool(getattr(config, "periodic_domain", True))
    support_eps = float(getattr(config, "parent_cover_support_eps", 0.30))
    excl_r = int(getattr(config, "parent_seed_exclusion_px", 3))
    if excl_r > 0 and parents:
        
        blocked = np.zeros((H, W), dtype=bool)
        for P in parents.values():
            pm = ensure_hw(getattr(P, "mask", 0.0), (H, W))
            blocked |= _dilate_bool((pm > support_eps), r=excl_r, periodic=periodic)
        cand &= ~blocked

    comps = _components(cand, min_area=int(min_area))
    if not comps:
        return []

    # existing parents’ supports (for IoU filtering)
    existing_bool = [(ensure_hw(getattr(P, "mask", 0.0), (H, W)) > support_eps) for P in parents.values()]

    # infer shapes/dtypes from a template child
    tmpl  = children[0]
    dtype = tmpl.mu_q_field.dtype
    Kq, Kp = tmpl.mu_q_field.shape[-1], tmpl.mu_p_field.shape[-1]

    # Seed spacing should also respect existing parent centers across steps.
    chosen: list[tuple[float, float]] = []
    def _center_of(m: np.ndarray):
        ys, xs = np.nonzero(m > support_eps)
        if ys.size == 0: return None
        return (float(ys.mean()), float(xs.mean()))
    for P in parents.values():
        pm = ensure_hw(getattr(P, "mask", 0.0), (H, W))
        c = _center_of(pm)
        if c is not None:
            chosen.append(c)
    seeded_ids: list[int] = []

    # seeding params
    seed_lvl   = float(getattr(config, "parent_seed_init_level", 0.45))   # amplitude
    feather    = float(getattr(config, "parent_seed_feather_sigma", 1.0)) # 0 = hard edge
    r0         = float(getattr(config, "parent_seed_radius_px", 4.0))     # NEW: small local radius

    for area, (cy, cx), comp in comps:
        if len(seeded_ids) >= max_new_per_step:
            break
        if not _respect_spacing(cy, cx, chosen, min_interseed_px):
            continue

        # reject if overlaps existing too much
        if _too_close_by_iou(comp, existing_bool, iou_thr=float(iou_thr)):
            continue

        # allocate id
        pid = int(getattr(runtime_ctx, "next_parent_id", 0))
        runtime_ctx.next_parent_id = pid + 1

        # make a fresh parent object
        P = _make_parent_template(runtime_ctx, tmpl, pid=pid, H=H, W=W, Kq=Kq, Kp=Kp,
                                  generators_q=generators_q, generators_p=generators_p)

        # ---- build a small local seed inside the component -----------------
        base = ensure_hw(comp, (H, W)).astype(np.float32)  # 0/1 component to (H,W)
        # Gaussian disk around component COM, clipped to the component
        yc, xc = int(round(cy)), int(round(cx))
        yy, xx = np.ogrid[:H, :W]
        d2 = (yy - yc) * (yy - yc) + (xx - xc) * (xx - xc)
        gauss = np.exp(-0.5 * (d2 / max(1.0, r0 * r0))).astype(np.float32)
        base *= gauss
        if feather > 0:
            if _HAS_SCIPY:
                base = _gblur(base, sigma=feather)
            else:
                # simple 3x3 box blur fallback, repeated ~feather times
                k = np.array([[1,1,1],[1,1,1],[1,1,1]], np.float32) / 9.0
                for _ in range(int(max(1, round(feather)))):
                    pad = np.pad(base, 1, mode="reflect")
                    base = (
                        pad[0:-2,0:-2] + pad[0:-2,1:-1] + pad[0:-2,2:] +
                        pad[1:-1,0:-2] + pad[1:-1,1:-1] + pad[1:-1,2:] +
                        pad[2:,0:-2]   + pad[2:,1:-1]   + pad[2:,2:]
                    ) / 9.0
        # normalize then scale to seed level
        mmax = float(base.max())
        if mmax > 0:
            base = base / mmax
        P.mask = np.clip(base * seed_lvl, 0.0, 1.0)
        # -------------------------------------------------------------------

        # init bookkeeping
        if not hasattr(P, "_age"):   P._age = 0
        if not hasattr(P, "_grace"): P._grace = int(getattr(config, "parent_freeze_steps", 0))

        # register before CG so ensure_hw sees it if needed
        parents[pid] = P

        # Coarse-grain μ, Σ into the new parent (hard-masked inside)
        try:
            cg_eps = float(getattr(config, "cg_eps", 1e-6))
            cg_tau = float(getattr(config, "parent_cover_support_eps", 0.30))
            coarsegrain_parent_from_children(P, children, eps=cg_eps, mask_tau=cg_tau)
        except Exception as e:
            if getattr(config, "debug_parent_masks", False):
                print(f"[COARSEGRAIN] parent {pid} init failed: {e}")
                mshape = np.asarray(P.mask).shape
                c0 = children[0]
                print(f"  P.mask {mshape}")
                print(f"  child0.mu_q_field {np.asarray(c0.mu_q_field).shape}, "
                      f"sigma_q_field {np.asarray(c0.sigma_q_field).shape}")

        # mark exp-caches dirty — central prepass will rebuild them
        for attr in ("_exp_phi", "_exp_neg_phi", "_exp_phi_model", "_exp_neg_phi_model"):
            setattr(P, attr, None)

        seeded_ids.append(pid)
        chosen.append((float(cy), float(cx)))

    return seeded_ids





def _apply_spawn_from_regions(ctx, active_regions, cand_map, agents, Gq, Gp, params):
    """
    The ONLY place that mutates parents:
      - spawn/update parents for active regions
      - coarse-grain new/updated parents
      - optional 'seed from uncovered' using cand_map
    No preprocess(), no build_all_omega_caches(), no build_all_lambda_caches() here.
    """
    
    # if _as_parent_dict lives elsewhere, import from there; otherwise keep your local helper
    # from detector import _as_parent_dict

    H, W = np.asarray(agents[0].mask).shape[:2]

    # 1) spawn/update from detector-active regions
    parents_list, next_pid = spawn_or_update_parents(
        active_regions=active_regions,
        agents=agents,
        parents_by_id=ctx.parents_by_region,
        next_parent_id=ctx.next_parent_id,
        field_generators=(Gq, Gp),
    )
    parents = _as_parent_dict(parents_list)

    # normalize & insert; coarsegrain immediately so masks/Σ are usable
    existing = ctx.parents_by_region
    prev_ids = set(existing.keys())

    for pid, P in parents.items():
        pid = int(getattr(P, "id", pid))
        existing[pid] = P
        if not hasattr(P, "_age"):   P._age = 0
        if not hasattr(P, "_grace"): P._grace = int(getattr(config, "parent_freeze_steps", 0))
        try:
            cg_eps = float(getattr(config, "cg_eps", 1e-6))
            cg_tau = float(getattr(config, "parent_cover_support_eps", 0.30))
            coarsegrain_parent_from_children(P, agents, eps=cg_eps, mask_tau=cg_tau)
            if bool(getattr(config, "debug_strict", True)):
                for name in ("sigma_q_field", "sigma_p_field"):
                    S = getattr(P, name, None)
                    if S is None:
                        continue
                    S = np.asarray(S)
                    assert S.ndim == 4 and S.shape[-1] == S.shape[-2], \
                        f"[CG->ASSIGN] {name} bad shape {S.shape} for parent {getattr(P,'id','?')}"
        except Exception as e:
            print(f"[WARN] coarsegrain/init failed for parent {getattr(P,'id','?')}: {e}")
            if getattr(config, "debug_parent_masks", False):
                print("  parent.mask", np.asarray(P.mask).shape)
                print("  child0.mask", np.asarray(agents[0].mask).shape)

    # registry bookkeeping
    ctx.parents_by_region = existing
    ctx.next_parent_id = max(
        int(ctx.next_parent_id),
        int(next_pid),
        (max(existing.keys()) + 1) if existing else 1
    )

    # --- visibility: log new parents from detector phase
    new_ids = sorted(set(existing.keys()) - prev_ids)
    if new_ids:
        areas = [int((np.asarray(existing[i].mask) > 0.5).sum()) for i in new_ids]
        print(f"[SPAWN] +{len(new_ids)} (detector): ids={new_ids} areas={areas}")

    # 2) seed-from-uncovered (optional)
    if bool(getattr(config, "use_seed_from_uncovered", True)):
        support_eps = float(getattr(config, "parent_cover_support_eps", 0.30))
        P_support = np.zeros((H, W), dtype=bool)
        for P in ctx.parents_by_region.values():
            pm = ensure_hw(getattr(P, "mask", 0.0), (H, W))
            P_support |= (pm > support_eps)

        erode_iters = int(getattr(config, "parent_cover_erode", 0))
        if erode_iters > 0:
            try:
                from scipy.ndimage import binary_erosion
                P_support = binary_erosion(P_support, iterations=erode_iters, border_value=0)
            except Exception:
                # simple 4-neighborhood fallback
                core = P_support.copy()
                for _ in range(erode_iters):
                    up    = np.pad(core[1: , : ], ((0,1),(0,0)))
                    down  = np.pad(core[:-1, : ], ((1,0),(0,0)))
                    left  = np.pad(core[: , 1: ], ((0,0),(0,1)))
                    right = np.pad(core[: , :-1], ((0,0),(1,0)))
                    core &= up & down & left & right
                P_support = core

        # make sure cand_map isn’t empty; if it is, fallback to child coverage
        cand_map = np.asarray(cand_map, np.float32)
        if not np.any(cand_map):
            # NEW: only allow a coverage fallback if explicitly requested
            if bool(getattr(config, "seed_from_coverage_when_no_regions", False)):
                for c in agents:
                    cand_map = np.maximum(cand_map, ensure_hw(getattr(c, "mask", 0.0), (H, W)))
                    

        seed_floor = float(getattr(config, "parent_seed_floor", 0.12))
        cand_bool  = (cand_map > seed_floor)
        uncovered_bool = cand_bool & ~P_support

        before = set(ctx.parents_by_region.keys())
        # global cap: parent_max_total (None/0 = unlimited)
        max_total = int(getattr(config, "parent_max_total", 0))
        step_budget = int(getattr(config, "parent_max_new_per_step", 2))
        if max_total > 0:
            step_budget = max(0, min(step_budget, max_total - len(before)))
        if step_budget > 0:
            seed_new_parents_from_uncovered(
                ctx,
                uncovered_bool,
                children=agents,
                generators_q=Gq, generators_p=Gp,
                min_area=int(getattr(config, "emerge_min_area", 8)),
                iou_thr=float(getattr(config, "parent_new_iou_thr", 0.40)),
                max_new_per_step=step_budget,
                min_interseed_px=int(getattr(config, "parent_min_interseed_px", 6)),
            )
        after = set(ctx.parents_by_region.keys())
        seeded = sorted(after - before)
    
        if seeded:
            thr = float(getattr(config, "parent_area_threshold",
                                getattr(config, "parent_growth_core_tau", 0.20)))
            stats = []
            for i in seeded:
                m = np.asarray(ctx.parents_by_region[i].mask, np.float32)
                stats.append({
                    "id": int(i),
                    "min": float(m.min()),
                    "max": float(m.max()),
                    "mean": float(m.mean()),
                    f"area>{thr}": int((m > thr).sum())
                })
            print("[SPAWN/DEBUG] newborn stats:", stats)



def _ensure_parents_for_regions(active_regions, parents_by_id, next_parent_id, H, W, dtype, Kq, Kp):
    """
    Match current regions to existing parents by IoU. Reuse on good match; else spawn new.
    Returns (rid_to_pid, next_parent_id).
    """
    iou_thr = float(getattr(config, "parent_reuse_iou_min",
                            getattr(config, "parent_reseed_iou", 0.30)))

    if isinstance(active_regions, list):
        # fabricate IDs (0..N-1) if it’s a plain list
        active_regions = {i: R for i, R in enumerate(active_regions)}

    # cache masks
    reg_items = [(rid, np.asarray(R.mask, dtype=bool)) for rid, R in active_regions.items()]
    par_items = [(pid,
                  np.asarray((P._region_proposal if getattr(P, "_region_proposal", None) is not None else P.mask)) > 1e-3)
                 for pid, P in parents_by_id.items()]

    def _iou(A, B):
        inter = np.count_nonzero(A & B)
        if inter == 0: return 0.0
        unio  = np.count_nonzero(A | B)
        return float(inter) / float(unio) if unio else 0.0

    taken_parents = set()
    new_map = {}      # parent_id -> parent
    rid_to_pid = {}   # region id -> parent id

    for rid, Rmask in reg_items:
        best_pid, best_iou = None, 0.0
        for pid, Pmask in par_items:
            if pid in taken_parents:
                continue
            iou = _iou(Rmask, Pmask)
            if iou > best_iou:
                best_iou, best_pid = iou, pid

        if best_pid is not None and best_iou >= iou_thr:
            # reuse
            P = parents_by_id[best_pid]
            P._region_proposal = Rmask.astype(dtype)
            new_map[best_pid] = P
            rid_to_pid[rid] = best_pid
            taken_parents.add(best_pid)
        else:
            # spawn new
            Pnew = _new_parent(next_parent_id, H, W, dtype, Kq, Kp, Rmask.astype(dtype))
            new_map[next_parent_id] = Pnew
            rid_to_pid[rid] = next_parent_id
            next_parent_id += 1

    parents_by_id.clear()
    parents_by_id.update(new_map)
    return rid_to_pid, next_parent_id





def _apply_one_shot_reseed(parents, dtype, *, seed_amp):
    """If a parent was marked for rehome, blend its mask to the proposal once."""
    for P in parents:
        if getattr(P, "_force_reseed_once", False):
            P._force_reseed_once = False
            pm = np.asarray(getattr(P, "mask", 0.0), np.float32)
            prop = np.asarray(getattr(P, "_region_proposal", pm*0), np.float32)
            if prop.max() > 0: prop = prop / (prop.max() + 1e-8)
            P.mask = np.clip(seed_amp * prop, 0.0, 1.0).astype(dtype)
            

def _norm_active_regions(active_regions, HW):
    """Return list[(H,W) bool] region masks."""
    
    H, W = HW
    if active_regions is None:
        return []
    if isinstance(active_regions, dict):
        region_objs = [active_regions[k] for k in sorted(active_regions.keys())]
    else:
        region_objs = list(active_regions)
    out = []
    for R in region_objs:
        m = getattr(R, "mask", R)
        m = ensure_hw(m, (H, W)) > 0.0
        out.append(m.astype(bool))
    return out


# --- helpers -----------------------------------------------------------------


