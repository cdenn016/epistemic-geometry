# viz_parent_masks.py
import os
import numpy as np
import matplotlib.pyplot as plt
import config



def _ensure_dir(p):
    os.makedirs(p, exist_ok=True)

def _normalize01(x):
    x = np.asarray(x, dtype=float)
    if x.size == 0 or not np.isfinite(x).any():
        return np.zeros_like(x, dtype=float)
    x = x - np.nanmin(x)
    mx = np.nanmax(x)
    return x / (mx + 1e-12) if mx > 0 else np.zeros_like(x, dtype=float)

def _autogain_support(x, *, vis_floor=1e-2, lo_p=0.0, hi_p=98.0, gamma=1.1):
    """
    Autogain only over the mask support (x >= vis_floor). Returns:
      norm_img in [0,1], support boolean, (lo, hi) original-value range used.
    """
    x = np.asarray(x, dtype=float)
    supp = x >= vis_floor
    if not supp.any():
        return np.zeros_like(x), supp, (0.0, 1.0)

    vals = x[supp]
    lo = np.percentile(vals, lo_p)
    hi = np.percentile(vals, hi_p)
    if hi <= lo:
        y = np.zeros_like(x)
        y[supp] = 1.0
        return y, supp, (lo, hi)

    y = np.zeros_like(x)
    z = np.clip((x - lo) / (hi - lo), 0.0, 1.0)
    if gamma > 0 and gamma != 1.0:
        z = np.power(z, 1.0 / gamma)
    y[supp] = z[supp]
    return y, supp, (float(lo), float(hi))

def _blend_colors_max(masks_dict, *, floor=1e-3, cmap_name="magma"):
    """
    Combine masks for a single RGB image without changing brightness
    as the number of parents changes.
    - Uses per-pixel max over *raw* mask values (after floor),
      not sum/mean/auto-gain.
    - No per-parent normalization.
    """
    import numpy as np
    import matplotlib.cm as cm

    if not masks_dict:
        return np.zeros((1, 1, 3), dtype=np.float32)

    arrs = [np.asarray(m, np.float32) for m in masks_dict.values()]
    H, W = arrs[0].shape

    # floor tiny dust to zero before combine
    arrs = [np.where(a > float(floor), a, 0.0) for a in arrs]

    # per-pixel max
    I = np.maximum.reduce(arrs)
    I = np.clip(I, 0.0, 1.0)

    # map to RGB via colormap (no extra normalization)
    cmap = cm.get_cmap(cmap_name)
    rgba = cmap(I)                     # (H,W,4)
    rgb = rgba[..., :3].astype(np.float32)
    return rgb




def save_parent_mask_frame(runtime_ctx, step, outdir, draw_per_parent=True, *, child_eps=1e-3):
    """
    Save two PNGs for this step:
      1) combined overlay: parent_masks_combined/step_XXXX.png
      2) per-parent panel grid (with colorbars): parent_masks_panels/step_XXXX.png
    Adds lvl-0 child union border overlays for context.
    More robust: pulls parents from multiple possible containers on runtime_ctx.
    """
    import numpy as np
    import os
    import matplotlib.pyplot as plt
    import config
    thr = float(getattr(config, "parent_area_threshold",
                    getattr(config, "parent_growth_core_tau", 0.20)))




    def _collect_parents(ctx):
        # Try several canonical locations, accept dicts or lists, then dedup by id
        candidates = []

        # 1) parents_by_region
        store = getattr(ctx, "parents_by_region", None)
        if store is not None:
            if isinstance(store, dict):
                candidates.extend(list(store.values()))
            else:
                candidates.extend(list(store))

        # 2) parents (some runners keep a list here)
        store2 = getattr(ctx, "parents", None)
        if store2 is not None:
            if isinstance(store2, dict):
                candidates.extend(list(store2.values()))
            else:
                candidates.extend(list(store2))

        # 3) parents_latest (another common alias)
        store3 = getattr(ctx, "parents_latest", None)
        if store3 is not None:
            if isinstance(store3, dict):
                candidates.extend(list(store3.values()))
            else:
                candidates.extend(list(store3))

        # Dedup by .id if available; else by object id
        uniq = {}
        for p in candidates:
            pid = getattr(p, "id", id(p))
            uniq[pid] = p
        # Stable order: sort by numeric id if present
        try:
            keys = sorted(uniq.keys())
        except Exception:
            keys = list(uniq.keys())
        return [uniq[k] for k in keys]

    parents = _collect_parents(runtime_ctx)
    if not parents:
        # optional debug
        if getattr(config, "debug_parent_masks", False):
            print(f"[viz] step {step}: no parents found in ctx")
        
        return

    # --- child union (lvl-0) for border overlays ---
    children = getattr(runtime_ctx, "children_latest", None)
    if children is None and hasattr(runtime_ctx, "last_children"):
        children = getattr(runtime_ctx, "last_children")

    H, W = parents[0].mask.shape
    child_union = np.zeros((H, W), dtype=bool)
    if children:
        for ch in children:
            child_union |= (np.asarray(ch.mask, dtype=float) > float(child_eps))

    # Build mask dict
    masks = {getattr(P, "id", i): np.asarray(P.mask, dtype=float) for i, P in enumerate(parents)}

    # Debug: confirm how many parents we see here
    if getattr(config, "debug_parent_masks", True):
        print(f"[viz] step {step}: plotting {len(parents)} parents (keys={list(masks.keys())[:8]}{'...' if len(masks)>8 else ''})")
        mx = max(float(np.asarray(m).max()) for m in masks.values())
        print(f"[viz] step {step}: n_parents={len(parents)} max_mask={mx:.3f} thr={thr}\n\n\n\n")

    # 1) combined overlay (RGB blend) + child borders
    out1 = os.path.join(outdir, "parent_masks_combined")
    _ensure_dir(out1)
    rgb = _blend_colors_max(masks, floor=float(getattr(config, "viz_union_floor", 1e-3)))


    plt.figure(figsize=(4, 4))
    ax = plt.gca()
    ax.imshow(rgb, origin="upper")
    # after ax.imshow(rgb, ...)
    for P in parents:
        pm = np.asarray(P.mask, float)
        if (pm > thr).any():
            ax.contour((pm > thr).astype(float), levels=[0.5], colors="white", linewidths=0.6)

    
    
    # child union border overlay (thin light gray)
    if child_union.any():
        ax.contour(child_union.astype(float), levels=[0.5],
                   colors=[(0.85, 0.85, 0.85)], linewidths=0.8)
    ax.set_title(f"Parents (step {step}) | n={len(parents)}")
    ax.axis("off")
    plt.tight_layout()
    plt.savefig(os.path.join(out1, f"step_{step:04d}.png"), dpi=140)
    plt.close()

    if not draw_per_parent:
        return

    # 2) per-parent panels
    out2 = os.path.join(outdir, "parent_masks_panels")
    _ensure_dir(out2)

    cols = min(4, max(1, int(np.ceil(np.sqrt(len(parents))))))
    rows = int(np.ceil(len(parents) / cols))

    fig_w = 3.6 * cols  # a bit wider to fit cbar
    fig_h = 3.2 * rows
    fig, axes = plt.subplots(rows, cols, figsize=(fig_w, fig_h))
    if not isinstance(axes, np.ndarray):
        axes = np.array([[axes]])
    axes = axes.reshape(rows, cols)

    for idx, P in enumerate(parents):
        r, c = divmod(idx, cols)
        ax = axes[r, c]

        # Lower vis_floor so newborn (soft) masks show up reliably
        norm, supp, (lo, hi) = _autogain_support(P.mask, vis_floor=1e-4, lo_p=0.0, hi_p=98.0, gamma=1.1)
        im = ax.imshow(norm, cmap="magma", origin="upper", vmin=0, vmax=1, alpha=0.95)

        # overlay crisp parent support contour
        if supp.any():
            ax.contour(supp.astype(float), levels=[0.5], colors="white", linewidths=0.8)

        # overlay child union borders for context
        if child_union.any():
            ax.contour(child_union.astype(float), levels=[0.5],
                       colors=[(0.85, 0.85, 0.85)], linewidths=0.7)

        # colorbar with ticks mapped back to ORIGINAL mask values
        cbar = fig.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
        ticks = [0.0, 0.5, 1.0]
        mids = lo + 0.5 * (hi - lo)
        cbar.set_ticks(ticks)
        cbar.set_ticklabels([f"{lo:.2e}", f"{mids:.2e}", f"{hi:.2e}"])
        cbar.ax.set_ylabel("mask value (orig)", rotation=270, labelpad=10)

        wq = getattr(P, "lambda_q_weight", 0.0)
        kids = len(getattr(P, "child_ids", []))
        nz = int(np.count_nonzero(np.asarray(P.mask) > thr))  # was >= 1e-2

        ax.set_title(f"P{getattr(P,'id','?')}  wq={wq:.2f}  kids={kids}  nz≥1e-2={nz}", fontsize=9)
        ax.axis("off")

    # hide any empty subplots
    for idx in range(len(parents), rows * cols):
        r, c = divmod(idx, cols)
        axes[r, c].axis("off")

    fig.suptitle(f"Parent Masks (step {step})", y=0.995)
    fig.tight_layout()
    fig.savefig(os.path.join(out2, f"step_{step:04d}.png"), dpi=140)
    plt.close(fig)


