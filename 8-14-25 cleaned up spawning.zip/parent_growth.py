# -*- coding: utf-8 -*-
"""
Created on Mon Aug 11 17:58:13 2025

@author: chris and christine
"""

import config
from numerical_utils import resize_nn
import numpy as np
from parent_utils import ensure_hw,_ring_masks, _logistic






def apply_parent_growth(runtime_ctx, growth_maps, *, eta_grow=0.08, eta_shrink=0.12,
                        min_area=10, max_area=None, delta_cap=0.05, blur_iters=1):
    """
    Mutating stage: given dict[pid] -> (grow_field, shrink_field), update masks.
    """
    import numpy as np
    from scipy.ndimage import gaussian_filter
    parents = getattr(runtime_ctx, "parents_by_region", {})
    if not parents:
        return

    for pid, P in parents.items():
        if pid not in growth_maps:
            continue
        grow_field, shrink_field = growth_maps[pid]
        m = np.asarray(P.mask, np.float32)
        dm = eta_grow * grow_field - eta_shrink * shrink_field
        dm = np.clip(dm, -delta_cap, delta_cap)
        if blur_iters and blur_iters > 0:
            dm = gaussian_filter(dm, sigma=blur_iters)
        m_new = np.clip(m + dm, 0.0, 1.0)

        prev_area = int((m > 0.5).sum())
        new_area  = int((m_new > 0.5).sum())
        net_dm    = float(dm.mean())
        age       = int(getattr(P, "_age", 0))
        ramp      = int(getattr(config, "parent_ramp_steps", 0))
    
        # your gating...
        skip = False
        if (max_area is not None) and (new_area > float(max_area)):
            skip = True
        if (new_area < float(min_area)) and (net_dm <= 0.0) and (age >= ramp):
            skip = True
    
        if getattr(config, "debug_growth_probe", True) and (age <= 2):
            print(f"[APPLY/PROBE pid={int(getattr(P,'id',-1))}] "
                  f"net_dm={net_dm:.4f} prevA={prev_area} newA={new_area} skip={skip}")
    
        if skip:
            continue
    
        P.mask = m_new
       


def compute_parent_growth_maps_pure(runtime_ctx, children, *,
                                    tau_grow=0.30, tau_shrink=0.18,
                                    kappa=0.05, grow_band=1, shrink_band=1,
                                    mask_tau=0.30):
    """
    Pure stage: dict[pid] -> (grow_field, shrink_field), each (H,W) in [0,1].
    Uses per-parent signal from labeled kids (Agreement or KL), falls back to coverage if needed.
    tau_* can be float or "pXX"; kappa can be float or "auto".
    """
    if not getattr(runtime_ctx, "parents_by_region", None):
        return {}

    H, W = np.asarray(children[0].mask).shape[:2]
    # global fallback coverage
    global_cov = np.zeros((H, W), np.float32)
    for c in children:
        global_cov = np.maximum(global_cov, ensure_hw(getattr(c, "mask", 0.0), (H, W)))

    out = {}

    # local parsers to avoid any name clashes
    def _parse_tau(spec, vals, fb):
        v = np.asarray(vals, np.float64).ravel()
        v = v[np.isfinite(v)]
        try:
            if isinstance(spec, str):
                s = spec.strip().lower()
                if s.startswith("p"):
                    pct = float(s[1:])
                    return float(np.percentile(v, pct)) if v.size else float(fb)
                return float(s)
            return float(spec)
        except Exception:
            return float(fb)

    def _parse_kappa(spec, vals, fb):
        v = np.asarray(vals, np.float64).ravel()
        v = v[np.isfinite(v)]
        if isinstance(spec, str) and spec.strip().lower() == "auto":
            if v.size:
                q75, q25 = np.percentile(v, [75, 25])
                return float(max(1e-6, 0.25 * (q75 - q25)))
            return float(fb)
        try:
            return float(spec)
        except Exception:
            return float(fb)

    signal_mode = getattr(config, "parent_growth_signal", "auto")  # "auto"|"kl"|"agree"|"coverage"

    for pid, P in runtime_ctx.parents_by_region.items():
        pm = ensure_hw(getattr(P, "mask", 0.0), (H, W))
        core = (pm > float(mask_tau))
        if not np.any(core):
            # NEWBORN fallback: allow a looser core for age 0 only
            if int(getattr(P, "_age", 0)) == 0:
                loose = float(getattr(config, "parent_newborn_core_tau", 0.05))
                core = (pm > loose)
            if not np.any(core):
                continue

        # per-parent signal from its labeled kids (or fallback)
        sig = _extract_per_parent_signal(pid, children, H, W, mode=signal_mode)
        if sig is None:
            sig = global_cov  # no labeled kids yet

        outer_ring, inner_ring = _ring_masks(core, grow_band, shrink_band)

        core_count = int(core.sum())
        outer_count = int(outer_ring.sum())
        inner_count = int(inner_ring.sum())
    
        # pick values for thresholds/slopes (your existing code)
        g_raw = sig * outer_ring.astype(np.float32)
        s_raw = (1.0 - sig) * inner_ring.astype(np.float32)
        g_vals = g_raw[outer_ring]
        s_vals = s_raw[inner_ring]
        vals_for_kappa = (
            np.concatenate([g_vals, s_vals]) if (g_vals.size and s_vals.size)
            else (g_vals if g_vals.size else s_vals)
        )
    
        # existing tau/kappa parsing
        tau_g = _parse_tau(tau_grow,  g_vals, 0.30)
        tau_s = _parse_tau(tau_shrink, s_vals, 0.18)
        kap   = _parse_kappa(kappa,    vals_for_kappa, 0.05)
    
        if getattr(config, "debug_growth_probe", False) and (int(getattr(P, "_age", 0)) <= 2):
            print(f"[GROW/PROBE pid={int(getattr(P,'id',-1))}] "
                  f"core={core_count} outer={outer_count} inner={inner_count} "
                  f"gmax={float(g_raw.max()) if g_vals.size else 0.0:.3f} "
                  f"smax={float(s_raw.max()) if s_vals.size else 0.0:.3f} "
                  f"tau_g={tau_g:.3f} tau_s={tau_s:.3f} kappa={kap:.3f}")
    


        # gates on rings
        g_raw = sig * outer_ring.astype(np.float32)          # grow where signal is strong just outside
        s_raw = (1.0 - sig) * inner_ring.astype(np.float32)  # shrink where signal is weak just inside

        g_vals = g_raw[outer_ring]
        s_vals = s_raw[inner_ring]
        vals_for_kappa = (
            np.concatenate([g_vals, s_vals]) if (g_vals.size and s_vals.size)
            else (g_vals if g_vals.size else s_vals)
        )

        tau_g = _parse_tau(tau_grow,  g_vals, 0.30)
        tau_s = _parse_tau(tau_shrink, s_vals, 0.18)
        kap   = _parse_kappa(kappa,    vals_for_kappa, 0.05)

        grow_field   = _logistic(g_raw, tau=tau_g, kappa=kap).astype(np.float32)
        shrink_field = _logistic(s_raw, tau=tau_s, kappa=kap).astype(np.float32)

        out[int(pid)] = (grow_field, shrink_field)

    return out





# ---------- main seeding function -------------------------------------------





# --- helpers ---------------------------------------------------------------






def _child_is_labeled_to(child, pid):
    """Robustly detect if a child is assigned to parent pid (supports multiple schemas)."""
    if getattr(child, "parent_id", None) == pid: return True
    if getattr(child, "assigned_parent", None) == pid: return True
    lab = getattr(child, "label", None)
    if isinstance(lab, (tuple, list, set)) and pid in lab: return True
    if isinstance(lab, (int, np.integer)) and lab == pid: return True
    labs = getattr(child, "labels", None)
    if isinstance(labs, dict) and pid in labs: return True
    return False

def _extract_per_parent_signal(pid, children, H, W, *, mode="auto"):
    """
    Build a per-parent growth signal in [0,1], shape (H,W), using only the
    children currently labeled to that parent.

    Order of preference (within labeled kids):
      1) agreement_to_parent[pid] OR child.agreement_field
      2) kl_to_parent[pid] OR child.kl_field -> invert+normalize
      3) coverage of labeled kids
    If no labeled kids, returns None.
    """
    # pick labeled kids
    labeled = [c for c in children if _child_is_labeled_to(c, pid)]
    if not labeled:
        return None  # caller must fallback

    # 1) agreement (higher is better)
    agree = None
    for c in labeled:
        # try per-parent agreement dict first
        amap = getattr(c, "agreement_to_parent", None)
        fld = amap.get(pid) if isinstance(amap, dict) else getattr(c, "agreement_field", None)
        if fld is None: continue
        a = ensure_hw(fld, (H, W), reduce="mean")
        agree = a if agree is None else np.maximum(agree, a)
    if agree is not None and (mode in ("auto", "agree")):
        return np.clip(np.nan_to_num(agree, nan=0.0, posinf=1.0, neginf=0.0), 0.0, 1.0)

    # 2) KL (lower is better) -> invert to [0,1] robustly
    kl = None
    for c in labeled:
        kd = getattr(c, "kl_to_parent", None)
        fld = kd.get(pid) if isinstance(kd, dict) else getattr(c, "kl_field", None)
        if fld is None: continue
        k = np.asarray(fld, np.float32)
        if k.shape != (H, W):
            from parent_mask_utils import resize_nn
            k = resize_nn(k, (H, W)).astype(np.float32)
        kl = k if kl is None else np.minimum(kl, k)  # best (lowest) across labeled kids
    if kl is not None and (mode in ("auto", "kl")):
        finite = np.isfinite(kl)
        if finite.any():
            q25, q75 = np.percentile(kl[finite], [25, 75])
            scale = max(1e-6, q75 - q25)
            sig = 1.0 - np.clip((kl - q25) / scale, 0.0, 1.0)
        else:
            sig = np.zeros_like(kl, np.float32)
        return np.clip(np.nan_to_num(sig, nan=0.0), 0.0, 1.0)

    # 3) coverage of labeled kids (fallback)
    cov = np.zeros((H, W), np.float32)
    for c in labeled:
        cov = np.maximum(cov, ensure_hw(getattr(c, "mask", 0.0), (H, W)))
    return cov







# --- PATCH 1: allow KL helper to look outside the mask -----------------------
def _mean_child_kl_fieldOLD(P, children, where=None):
    """
    Mean of children's cached KL on 'where' pixels.
    If where is None, falls back to (child.mask ∧ parent.mask).
    """
    H, W = P.mask.shape
    acc = np.zeros((H, W), dtype=np.float32)
    cnt = np.zeros((H, W), dtype=np.int32)

    for ch in children:
        # optional: restrict to this parent's kids if you track them
        pids = getattr(ch, "parent_ids", None)
        if pids is not None and P.id not in pids:
            continue

        kl = getattr(ch, "cached_alignment_kl", None)
        if kl is None:
            continue
        k = np.asarray(kl).squeeze()
        if k.shape != (H, W):
            k = resize_nn(k, (H, W))  # your existing resize helper

        if where is None:
            m = (np.asarray(ch.mask) > 0) & (np.asarray(P.mask) > 0)
        else:
            m = (np.asarray(ch.mask) > 0) & where

        if m.any():
            acc[m] += k[m]
            cnt[m] += 1

    out = np.full((H, W), np.nan, dtype=np.float32)
    nz = cnt > 0
    if nz.any():
        out[nz] = acc[nz] / np.maximum(cnt[nz], 1)
    # safe max computation
    if not np.isfinite(out).any():
        mx = None
        out = np.zeros_like(out, dtype=np.float32)
    else:
        mx = np.nanmax(out)
    
    # fill NaNs with a conservative high value so growth won't trigger there
    fill_val = 1.0 if mx is None or not np.isfinite(mx) else mx
    out = np.nan_to_num(out, nan=fill_val, posinf=fill_val, neginf=fill_val)
    
    return out

def _soft_agreement_from_phiOLD(children, child_ids, use_phi_tilde=True, eps=1e-6):
    """
    Returns (H,W) agreement only. Refuses φ/φ̃ with unexpected rank to prevent
    accidental (M,H,W,3) stacks from leaking into downstream exp/log maps.
    """
    import numpy as np

    ids = sorted(set(child_ids))
    phis = []
    for i in ids:
        phi = getattr(children[i], "phi", None)
        if phi is None: 
            continue
        phi = np.asarray(phi)
        if not (phi.ndim == 3 and phi.shape[-1] == 3):
            raise RuntimeError(f"child {getattr(children[i],'id','?')} phi has shape {phi.shape}, expected (H,W,3)")
        phis.append(phi)

    if use_phi_tilde:
        for i in ids:
            ptil = getattr(children[i], "phi_model", None)
            if ptil is None: 
                continue
            ptil = np.asarray(ptil)
            if not (ptil.ndim == 3 and ptil.shape[-1] == 3):
                raise RuntimeError(f"child {getattr(children[i],'id','?')} phi_model has shape {ptil.shape}, expected (H,W,3)")
            phis.append(ptil)

    if len(phis) < 2:
        return None

    # Stack only inside; we return (H,W) so no (M,...) escapes
    arr  = np.stack(phis, axis=0)        # (M,H,W,3)
    mean = arr.mean(axis=0)              # (H,W,3)
    var  = ((arr - mean)**2).mean(axis=0).sum(axis=-1)  # (H,W)
    denom = float(var.mean()) + eps
    agree = np.exp(-var / denom)
    return agree.astype(np.float32)      # (H,W)

