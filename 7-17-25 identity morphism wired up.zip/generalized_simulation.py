
import os
os.environ["OMP_NUM_THREADS"] = "1"
os.environ["MKL_NUM_THREADS"] = "1"
os.environ["NUMEXPR_NUM_THREADS"] = "1"  # Optional: just in case
os.environ["OPENBLAS_NUM_THREADS"]= "1"
from threadpoolctl import threadpool_info
print(threadpool_info())

# Standard library
import os
import time
import multiprocessing
# Third-party
import pickle
import pandas as pd
from bundle_update_rules import synchronous_step
# Local configuration & utilities
from pullback_utils import compute_agent_pullback_blocks
from config_utils import set_config_from_params
from get_generators import get_generators

# I/O helpers
from generalized_io_utils import (
    save_step,
    load_checkpoint,
    find_resume_step,
    save_config_to_readme,
)
# 3.5) Compute Lie metrics for φ and φ_model
from natural_gradient_utils import compute_lie_metric
# Agent construction
from generalized_agents import initialize_agents
from generalized_diagnostics_metrics import log_all_metrics_fused, full_field_logger
import config


# config.py
log_pullback = True  # set True to re-enable pullback logging
num_cores = 18

def run_simulation(
    outdir="checkpoints",
    resume=False,
    log_metrics=True,
    log_fields=True,
    num_cores=None,
    params=None,
):
    import config
    from numerical_utils import reset_fallback_counters
    reset_fallback_counters()

    if num_cores is None:
        num_cores = 18

    if params:
        set_config_from_params(params)

    os.makedirs(outdir, exist_ok=True)
    save_config_to_readme(outdir)

    generators = get_generators(config.group_name, config.K)
    _, G_inv = compute_lie_metric(generators)
    params = params or {}
    params["G_inv_phi"] = G_inv
    params["G_inv_phi_model"] = G_inv    
    vis_inds, dark_inds = [0, 1], [2]

    if resume:
        agents, _ = load_checkpoint(outdir)
        step_start = find_resume_step(outdir)
    else:
        lie_dim = generators.shape[0]
        agents = initialize_agents(
            seed=getattr(config, "seed", None),
            domain_size=config.domain_size,
            N=config.N,
            K=config.K,
            lie_algebra_dim=lie_dim,
            visualize=False,
            fixed_location=True,
        )
        step_start = 0

    metric_log = []
    print(f"[RUN] Starting simulation at step {step_start} with {num_cores} cores")

    for step in range(step_start, config.steps):
        print(f"\n[STEP {step}] -----------------------------")

        # 5a) Gradient update
        t0 = time.perf_counter()
        step_params = dict(params)
        step_params["step"] = step
        agents = synchronous_step(
            agents, generators, params=step_params, n_jobs=num_cores
        )
        t1 = time.perf_counter()
        print(f"[TIMER] synchronous update: {t1 - t0:.3f}s")

        # 5b) Scalar diagnostics
        if log_metrics:
            t0 = time.perf_counter()
            m = log_all_metrics_fused(
                agents, step=step, params=params, n_jobs=num_cores
            )
            metric_log.append({"step": step, **m})
            t1 = time.perf_counter()
            print(f"[TIMER] log_all_metrics_fused: {t1 - t0:.3f}s")

        # 5b.5) Optional pullback blocks (attach to agents)
        if log_fields and getattr(config, "log_pullback", False):
            for A in agents:
                pull = compute_agent_pullback_blocks(A, vis_inds, dark_inds)
                A.pullback_I      = pull["I"]
                A.pullback_G      = pull["G"]
                A.pullback_M_vis  = pull["M_vis"]
                A.pullback_M_dark = pull["M_dark"]
                A.pullback_Delta  = pull["Delta"]

        # 5c) Full-step field dumps only
        if log_fields and getattr(config, "log_full_fields", False):
            t0_fields = time.perf_counter()
            field_dir = os.path.join(outdir, "fields")
            full_field_logger(agents, step, field_dir)
            t1_fields = time.perf_counter()
            print(f"[TIMER] full_step_field_logger: {t1_fields - t0_fields:.3f}s")

        # 5d) Save checkpoint
        for A in agents:
            A.clear_omega_cache()
        save_step(agents, outdir, step)
        print(f"[SAVE] Checkpoint → {outdir}/step_{step:04d}.pkl")

    # 6) Final logs
    if log_metrics:
        with open(os.path.join(outdir, "metric_log.pkl"), "wb") as f:
            pickle.dump(metric_log, f)
        print(f"[SAVE] Metrics log → {outdir}/metric_log.pkl")

        rows = []
        for A in agents:
            for entry in A.metrics_log:
                rows.append({"agent": A.id, **entry})
        df_agents = pd.DataFrame(rows)
        df_agents.to_csv(
            os.path.join(outdir, "per_agent_metrics.csv"), index=False
        )
        print("[SAVE] Per-agent metrics → per_agent_metrics.csv")

    print("[DONE] Simulation completed.")

    from numerical_utils import report_and_maybe_fail
    report_and_maybe_fail()

    return agents, metric_log

if __name__ == "__main__":
    import sys
    if len(sys.argv) > 1:
        param_file = sys.argv[1]
        with open(param_file, "rb") as f:
            params = pickle.load(f)
    else:
        params = {
            k: getattr(config, k)
            for k in dir(config)
            if not k.startswith("__") and not callable(getattr(config, k))
        }

    set_config_from_params(params)

    # === Resolve morphism functions from config strings ===
    from bundle_morphism_utils import get_morphism_fn
    from get_generators import get_generators

    generators = get_generators(config.group_name, config.K)
    params["phi_morphism"] = get_morphism_fn(config.phi_morphism_type, generators)
    params["phi_model_morphism"] = get_morphism_fn(config.phi_model_morphism_type, generators)

    run_simulation(outdir="checkpoints", resume=False, params=params)
