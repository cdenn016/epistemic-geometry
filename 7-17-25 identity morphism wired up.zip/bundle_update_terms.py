# === generalized_update_rules.py (refactor patch) ===
import numpy as np
import config
from joblib import Parallel, delayed

from natural_gradient_utils import (
    apply_natural_gradient_batch,
    apply_lie_natural_gradient,
    compute_inverse_fisher_field
)

from numerical_utils import sanitize_sigma
from mask_utils import clip_and_mask_gradient
from numerical_utils import safe_inv
from natural_gradient_utils import compute_alignment_kl_gradient
from get_generators import get_generators
from generalized_math_utils import unpack_phi_update_params
from generalized_omega import compute_curvature_gradient_analytical

from generalized_omega import dexpinv_operator, dexpinv_operator_covariance

from bundle_morphism_utils import safe_batch_apply_morphism, gauge_covariant_transform_phi

from natural_gradient_utils import compute_fisher_geometry_gradient
from generalized_math_utils import ( 
        zero_mu_sigma_like, compute_mu_sigma_diff,
        apply_mask_to_mu_sigma
        )

def grad_variance_penalty_field(agent_i, lambda_, field_type="model", mask=None):
    """
    Gradient of Tr(Σ⁻¹) penalty:
        ∇_Σ = -λ Σ⁻¹

    Returns:
        (Δμ, ΔΣ): where Δμ = 0, ΔΣ = -λ Σ⁻¹ (masked if needed)
    """
    if lambda_ <= 0:
        return zero_mu_sigma_like(agent_i, field=field_type)

    sigma = agent_i.sigma_p_field if field_type == "model" else agent_i.sigma_q_field
    mu_shape = agent_i.mu_p_field.shape if field_type == "model" else agent_i.mu_q_field.shape

    H, W, K, _ = sigma.shape
    d_sigma = np.zeros_like(sigma)
    fallback = np.eye(K)

    for i in range(H):
        for j in range(W):
            try:
                inv_ij = np.linalg.inv(sigma[i, j])
            except np.linalg.LinAlgError:
                if getattr(config, "debug", False):
                    print(f"[WARN] grad_variance_penalty_field: Σ⁻¹ fallback at ({i},{j})")
                inv_ij = np.linalg.pinv(sigma[i, j])  # fallback to pseudo-inverse

            d_sigma[i, j] = -lambda_ * inv_ij

    d_sigma = np.nan_to_num(d_sigma)

    if mask is not None:
        _, d_sigma = apply_mask_to_mu_sigma(None, d_sigma, mask)

    d_mu = np.zeros(mu_shape, dtype=d_sigma.dtype)
    return d_mu, d_sigma

def grad_self_field(agent_i, alpha, field_type="model", mask=None,
                             phi_morphism=None, phi_tilde_morphism=None):
    """
    Compute raw Euclidean gradient of morphism-aware self-alignment:
      - field_type="belief" → ∂KL(q || Φ·p)
      - field_type="model"  → ∂KL(p || Φ̃·q)

    The morphism acts as:
      - Φ   : p → q
      - Φ̃  : q → p

    Natural gradient is applied downstream.

    Args:
        agent_i   : Agent object
        alpha     : Scalar coefficient
        field_type: "belief" or "model"
        mask      : Optional spatial mask (H, W)
        phi_morphism        : Φ   (H, W, K, K) or None = identity
        phi_tilde_morphism  : Φ̃  (H, W, K, K) or None = identity

    Returns:
        (dμ, dΣ): Euclidean gradients of self-alignment term
    """
    if alpha <= 0:
        return zero_mu_sigma_like(agent_i)

    H, W, K = agent_i.mu_q_field.shape
    identity = np.eye(K)

    if field_type == "belief":
        mu_q, sigma_q = agent_i.mu_q_field, agent_i.sigma_q_field
        mu_p, sigma_p = agent_i.mu_p_field, agent_i.sigma_p_field
        Phi = phi_morphism if phi_morphism is not None else np.broadcast_to(identity, (H, W, K, K))
        # Transform p → q
        mu_p_trans, sigma_p_trans = safe_batch_apply_morphism(mu_p, sigma_p, Phi, eps=config.eps)
        dμ, dΣ = compute_mu_sigma_diff(mu_q, sigma_q, mu_p_trans, sigma_p_trans, direction="a_minus_b")

    elif field_type == "model":
        mu_q, sigma_q = agent_i.mu_q_field, agent_i.sigma_q_field
        mu_p, sigma_p = agent_i.mu_p_field, agent_i.sigma_p_field
        Phi_tilde = phi_tilde_morphism if phi_tilde_morphism is not None else np.broadcast_to(identity, (H, W, K, K))
        # Transform q → p
        mu_q_trans, sigma_q_trans = safe_batch_apply_morphism(mu_q, sigma_q, Phi_tilde, eps=config.eps)
        dμ, dΣ = compute_mu_sigma_diff(mu_p, sigma_p, mu_q_trans, sigma_q_trans, direction="a_minus_b")

    else:
        raise ValueError(f"[grad_self_field_morphism] Unknown field_type: {field_type}")

    dμ = np.nan_to_num(dμ)
    dΣ = np.nan_to_num(dΣ)

    if mask is not None:
        dμ, dΣ = apply_mask_to_mu_sigma(dμ, dΣ, mask)

    return alpha * dμ, alpha * dΣ

def grad_feedback_field(agent_i, feedback_weight, field_type="model", mask=None,
                                 phi_morphism=None, phi_tilde_morphism=None):
    """
    Compute raw Euclidean gradient of feedback term:
      - field_type="belief" → ∂_q KL(Φ·p || q)
      - field_type="model"  → ∂_p KL(Φ̃·q || p)

    This is the gradient of KL(transformed other || self).

    Args:
        agent_i        : focal agent
        feedback_weight: scalar
        field_type     : "belief" or "model"
        mask           : optional (H, W)
        phi_morphism   : Φ   ∈ Hom(p → q), or None = identity
        phi_tilde_morphism: Φ̃ ∈ Hom(q → p), or None = identity

    Returns:
        (dμ, dΣ): Euclidean gradients of feedback term
    """
    if feedback_weight <= 0:
        return zero_mu_sigma_like(agent_i, field=field_type)

    H, W, K = agent_i.mu_q_field.shape
    identity = np.eye(K)

    if field_type == "belief":
        mu_self, sigma_self = agent_i.mu_q_field, agent_i.sigma_q_field
        mu_p, sigma_p = agent_i.mu_p_field, agent_i.sigma_p_field
        Phi = phi_morphism if phi_morphism is not None else np.broadcast_to(identity, (H, W, K, K))
        # Pull p into q-space
        mu_p_trans, sigma_p_trans = safe_batch_apply_morphism(mu_p, sigma_p, Phi, eps=config.eps)
        dμ, dΣ = compute_mu_sigma_diff(mu_self, sigma_self, mu_p_trans, sigma_p_trans, direction="b_minus_a")

    elif field_type == "model":
        mu_self, sigma_self = agent_i.mu_p_field, agent_i.sigma_p_field
        mu_q, sigma_q = agent_i.mu_q_field, agent_i.sigma_q_field
        Phi_tilde = phi_tilde_morphism if phi_tilde_morphism is not None else np.broadcast_to(identity, (H, W, K, K))
        # Pull q into p-space
        mu_q_trans, sigma_q_trans = safe_batch_apply_morphism(mu_q, sigma_q, Phi_tilde, eps=config.eps)
        dμ, dΣ = compute_mu_sigma_diff(mu_self, sigma_self, mu_q_trans, sigma_q_trans, direction="b_minus_a")

    else:
        raise ValueError(f"[grad_feedback_field_morphism] Unknown field_type: {field_type}")

    dμ = np.nan_to_num(dμ)
    dΣ = np.nan_to_num(dΣ)

    if mask is not None:
        dμ, dΣ = apply_mask_to_mu_sigma(dμ, dΣ, mask)

    return feedback_weight * dμ, feedback_weight * dΣ


def alignment_gradient_field(agent_i, agents, params, field_type="model", mask=None):
    """
    Raw Euclidean gradient of alignment KL divergence:
        KL(q_i || Ω_ij q_j) or KL(p_i || Ω̃_ij p_j)

    Natural gradient is applied centrally in combine_field_gradients.

    Args:
        agent_i   : focal agent
        agents    : list of agents
        params    : dict of parameters (must contain 'generators')
        field_type: "model" or "belief"
        mask      : optional spatial mask to restrict update region

    Returns:
        (dμ, dΣ): Euclidean gradients
    """
    if field_type == "model":
        weight = params.get("model_align_weight", config.model_align_weight)
    elif field_type == "belief":
        weight = params.get("beta", config.beta)
    else:
        raise ValueError(f"[alignment_gradient_field] Unknown field_type: {field_type}")

    if weight <= 0:
        return zero_mu_sigma_like(agent_i, field=field_type)

    generators = params["generators"]
    dμ, dΣ = compute_alignment_kl_gradient(agent_i, agents, generators, params, field_type=field_type)

    dμ = np.nan_to_num(dμ)
    dΣ = np.nan_to_num(dΣ)

    if mask is not None:
        dμ, dΣ = apply_mask_to_mu_sigma(dμ, dΣ, mask)

    return weight * dμ, weight * dΣ


def combine_field_gradients(agent_i, agents, params, field_type="model"):
    if field_type == "model" and getattr(config, "identical_models", False):
        return zero_mu_sigma_like(agent_i)

    # Load all parameters
    α  = params.get("alpha", config.alpha)
    β  = params.get("model_align_weight", config.model_align_weight) if field_type == "model" else params.get("beta", config.beta)
    fb = params.get("model_feedback_weight", config.model_feedback_weight) if field_type == "model" else params.get("belief_feedback_weight", getattr(config, "belief_feedback_weight", 0.0))
    λ  = params.get("variance_penalty_model_weight", getattr(config, "variance_penalty_model_weight", 0.0)) if field_type == "model" else params.get("variance_penalty_belief_weight", getattr(config, "variance_penalty_belief_weight", 0.0))
    eps = params.get("support_cutoff_eps", config.support_cutoff_eps)

    # Mask
    mask = agent_i.mask > eps
    if not np.any(mask):
        return zero_mu_sigma_like(agent_i)

    # Select fields
    mu_field    = agent_i.mu_p_field if field_type == "model" else agent_i.mu_q_field
    sigma_field = agent_i.sigma_p_field if field_type == "model" else agent_i.sigma_q_field

    # --- Natural-gradient components ---
    grad_mu_nat    = np.zeros_like(mu_field)
    grad_sigma_nat = np.zeros_like(sigma_field)

    if α > 0:
        dμ, dΣ = grad_self_field(agent_i, α, field_type, mask)
        grad_mu_nat += dμ
        grad_sigma_nat += dΣ
    if fb > 0:
        dμ, dΣ = grad_feedback_field(agent_i, fb, field_type, mask)
        grad_mu_nat += dμ
        grad_sigma_nat += dΣ
    if β > 0:
        dμ, dΣ = alignment_gradient_field(agent_i, agents, params, field_type=field_type, mask=mask)

        grad_mu_nat += dμ
        grad_sigma_nat += dΣ

    # --- Apply Fisher preconditioner only to KL terms ---
    delta_mu, delta_sigma = apply_natural_gradient_batch(
        mu_field, sigma_field, grad_mu_nat, grad_sigma_nat
    )

    # --- Add regularization (coordinate) terms AFTER natural gradient ---
    if λ > 0:
        dμ_reg, dΣ_reg = grad_variance_penalty_field(agent_i, λ, field_type, mask)
        delta_mu    += dμ_reg
        delta_sigma += dΣ_reg

    # Final nan sanitization
    delta_mu    = np.nan_to_num(delta_mu, nan=0.0, posinf=1e5, neginf=-1e5)
    delta_sigma = np.nan_to_num(delta_sigma, nan=0.0, posinf=1e5, neginf=-1e5)

    return delta_mu, delta_sigma

def compute_phi_update(agent_i, agents, params, field="phi"):
    """
    Unified update for φ (belief alignment) and φ̃ (model alignment).
    Applies Lie-natural gradient to alignment + optional regularizers.
    """
    if field == "phi_model" and getattr(config, "identical_models", False):
        return np.zeros_like(agent_i.phi_model)

    # --- Unpack core parameters ---
    unpacked  = unpack_phi_update_params(params, field=field)
    β         = params.get("beta", config.beta) if field == "phi" else params.get("model_align_weight", config.model_align_weight)
    κ         = unpacked["κ"]
    gw        = unpacked["gw"]
    curv_w    = unpacked["curv_weight"]
    clip_th   = unpacked["grad_clip_threshold"]
    eps       = unpacked["overlap_eps"]
    debug     = unpacked["debug"]

    phi       = agent_i.phi if field == "phi" else agent_i.phi_model
    phi_tilde = agent_i.phi_model if field == "phi" else agent_i.phi
    soft_mask = agent_i.mask[..., None]
    generators = params.get("generators", get_generators(config.group_name, config.K))

    if not np.any(soft_mask > eps):
        return np.zeros_like(phi)

    grad = np.zeros_like(phi)

    G_inv = compute_inverse_fisher_field(agent_i, generators, field=field)

    # --- 1. Alignment gradient (Lie-natural, variationally consistent) ---
    if β > 0:
        grad_align = np.zeros_like(phi)
        for neighbor in agent_i.neighbors:
            agent_j = agents[neighbor["id"]]
            accumulate_phi_gradient(agent_i, agent_j, generators, params, field=field)
        grad_align = agent_i.grad_phi.copy()
        agent_i.grad_phi[:] = 0.0  # Clear after use

        grad += apply_lie_natural_gradient(phi, grad_align, G_inv=G_inv)

    # --- 2. Curvature gradient ---
    if curv_w > 0:
        grad_curv = compute_curvature_gradient_analytical(phi, generators)
        grad += curv_w * grad_curv

    # --- 3. Mass term: 2γ φ ---
    if gw > 0:
        grad += 2 * gw * phi

    # --- 4. φ–φ̃ coupling ---
    if κ > 0:
        grad += 2 * κ * (phi - phi_tilde)

    # --- 5. Optional Fisher geometry term ---
    fisher_key = "fisher_geometry_weight" if field == "phi" else "fisher_model_geometry_weight"
    fisher_weight = params.get(fisher_key, getattr(config, fisher_key, 0.0))
    if fisher_weight > 0:
        fisher_fn = compute_fisher_geometry_gradient if field == "phi" else compute_fisher_geometry_gradient
        fisher_grad = fisher_fn(agent_i, agents, params)
        grad += fisher_weight * fisher_grad

    # --- Final clip + mask ---
    return clip_and_mask_gradient(grad, soft_mask, clip_th, eps)


def accumulate_phi_gradient(agent_i, agent_j, generators, params, field="phi"):
    """
    Compute and accumulate both variational gradients:
        ∂/∂φ_i KL(q_i ‖ Ω_ij Φ_ij q_j)
        ∂/∂φ_j KL(q_i ‖ Ω_ij Φ_ij q_j)
    where Ω_ij = exp(φ_i) · exp(−φ_j) and Φ_ij is a bundle morphism (e.g. SL(2,ℝ) irrep)
    """
    assert field in ("phi", "phi_model")
    beta = params.get("beta", config.beta) if field == "phi" else params.get("model_align_weight", config.model_align_weight)
    if beta <= 0:
        return

    eps = config.support_cutoff_eps
    mask_i = agent_i.mask[..., None] > eps
    mask_j = agent_j.mask[..., None] > eps
    joint_mask = mask_i & mask_j

    # Select fields
    mu_i = agent_i.mu_q_field if field == "phi" else agent_i.mu_p_field
    mu_j = agent_j.mu_q_field if field == "phi" else agent_j.mu_p_field
    sigma_i = agent_i.sigma_q_field if field == "phi" else agent_i.sigma_p_field
    sigma_j = agent_j.sigma_q_field if field == "phi" else agent_j.sigma_p_field

    phi_i = agent_i.phi if field == "phi" else agent_i.phi_model
    phi_j = agent_j.phi if field == "phi" else agent_j.phi_model

    Omega_ij = agent_i.Omega if field == "phi" else agent_i.Omega_model
    Omega_T = np.swapaxes(Omega_ij, -1, -2)

    # --- Get bundle morphism Φ_ij ---
    phi_key = "phi_morphism" if field == "phi" else "phi_model_morphism"
    morphism_fn = params.get(phi_key, None)
    if morphism_fn is None:
        raise ValueError(f"[accumulate_phi_gradient] Missing morphism function for {phi_key}")

    Phi_ij = morphism_fn(agent_i, agent_j)       # (H, W, K_i, K_j)
    Phi_T  = np.swapaxes(Phi_ij, -1, -2)         # (H, W, K_j, K_i)

    # --- Transport fiber_j to i using Ω · Φ ---
    transport_op = np.einsum("...ik,...kj->...ij", Omega_ij, Phi_ij)
    transport_op_T = np.swapaxes(transport_op, -1, -2)

    mu_trans = np.einsum("...ij,...j->...i", transport_op, mu_j)
    sigma_trans = np.einsum("...ik,...kl,...lj->...ij", transport_op, sigma_j, transport_op_T)
    sigma_trans = sanitize_sigma(sigma_trans, eps=config.eps)
    sigma_inv = safe_inv(sigma_trans, eps=config.eps)

    delta_mu = mu_i - mu_trans
    d_mu = -np.einsum("...ij,...j->...i", sigma_inv, delta_mu)

    delta_sigma = sigma_i - sigma_trans
    d_sigma = -0.5 * np.einsum("...ik,...kl,...lj->...ij", sigma_inv, delta_sigma, sigma_inv)

    d = generators.shape[0]
    grad_phi_i = np.zeros_like(phi_i)
    grad_phi_j = np.zeros_like(phi_j)

    for a in range(d):
        G = generators[a]

        # --- ∂Ω/∂φ_i = Ω G · Φ
        OG = np.einsum("...ij,jk->...ik", Omega_ij, G)
        OG_Phi = np.einsum("...ij,...jk->...ik", OG, Phi_ij)
        dphi_i_mu = np.einsum("...ij,...j->...i", OG_Phi, mu_j)

        OG_sigma = np.einsum("...ij,...jk->...ik", OG_Phi, sigma_j)
        dphi_sigma_1 = np.einsum("...ij,...jk->...ik", OG_sigma, transport_op_T)

        sigma_GT = np.einsum("...ij,jk->...ik", sigma_j, G.T)
        O_sigma_GT = np.einsum("...ij,...jk->...ik", transport_op, sigma_GT)
        dphi_sigma_2 = np.einsum("...ij,...jk->...ik", O_sigma_GT, transport_op_T)

        dphi_i_sigma = dphi_sigma_1 + dphi_sigma_2

        delta_a = (
            np.sum(d_mu * dphi_i_mu, axis=-1) +
            np.einsum("...ij,...ij->...", d_sigma, dphi_i_sigma)
        )

        grad_phi_i[..., a] += delta_a
        grad_phi_j[..., a] -= delta_a

    # Natural gradient projection
    grad_phi_mu_i = dexpinv_operator(phi_i, grad_phi_i, generators)
    grad_phi_mu_j = dexpinv_operator(phi_j, grad_phi_j, generators)

    grad_phi_sigma_i = dexpinv_operator_covariance(phi_i, d_sigma, generators)
    grad_phi_sigma_j = dexpinv_operator_covariance(phi_j, -d_sigma, generators)

    grad_phi_i = grad_phi_mu_i + grad_phi_sigma_i
    grad_phi_j = grad_phi_mu_j + grad_phi_sigma_j

    if not hasattr(agent_i, "grad_phi"):
        agent_i.grad_phi = np.zeros_like(phi_i)
    if not hasattr(agent_j, "grad_phi"):
        agent_j.grad_phi = np.zeros_like(phi_j)

    agent_i.grad_phi += beta * grad_phi_i * joint_mask
    agent_j.grad_phi += beta * grad_phi_j * joint_mask


def compute_phi_morphism_gradient(agent_i, agent_j, Phi_field, rho_q_func, rho_p_func, field="phi"):
    """
    Compute the variational gradient ∂/∂Φ of KL[q_i || Φ ∘ Ω_ij(q_j)].

    Args:
        agent_i     : receiving agent (reference belief)
        agent_j     : sending agent (to be transported)
        Phi_field   : (H, W, K_p, K_q) current bundle morphism Φ
        rho_q_func  : φ → ρ_q(exp(φ)) (returns (K_q, K_q))
        rho_p_func  : φ → ρ_p(exp(φ)) (returns (K_p, K_p))
        field       : "phi" (belief) or "phi_model" (model)

    Returns:
        dPhi_field  : (H, W, K_p, K_q) gradient of KL wrt Φ
    """
    eps = 1e-8
    mu_i     = agent_i.mu_q_field     if field == "phi" else agent_i.mu_p_field
    mu_j     = agent_j.mu_q_field     if field == "phi" else agent_j.mu_p_field
    sigma_i  = agent_i.sigma_q_field  if field == "phi" else agent_i.sigma_p_field
    sigma_j  = agent_j.sigma_q_field  if field == "phi" else agent_j.sigma_p_field
    Omega_ij = agent_i.Omega          if field == "phi" else agent_i.Omega_model

    mask_i = agent_i.mask[..., None] > eps
    mask_j = agent_j.mask[..., None] > eps
    joint_mask = (mask_i & mask_j)[..., 0]

    H, W, K_p, K_q = Phi_field.shape
    dPhi_field = np.zeros((H, W, K_p, K_q), dtype=Phi_field.dtype)

    for i in range(H):
        for j in range(W):
            if not joint_mask[i, j]:
                continue

            phi = agent_i.phi[i, j] if field == "phi" else agent_i.phi_model[i, j]
            rho_q = rho_q_func(phi)                     # (K_q, K_q)
            rho_p = rho_p_func(phi)                     # (K_p, K_p)
            inv_rho_q = safe_inv(rho_q, eps=eps)        # (K_q, K_q)

            Omega = Omega_ij[i, j]                      # (K_q, K_q)
            mu_j_ = mu_j[i, j]                          # (K_q,)
            sigma_j_ = sigma_j[i, j]                    # (K_q, K_q)
            mu_i_ = mu_i[i, j]                          # (K_p,)
            sigma_i_ = sigma_i[i, j]                    # (K_p, K_p)

            mu_omega = Omega @ mu_j_                    # (K_q,)
            sigma_omega = Omega @ sigma_j_ @ Omega.T    # (K_q, K_q)
            sigma_omega = sanitize_sigma(sigma_omega, eps)

            Phi = Phi_field[i, j]                       # (K_p, K_q)
            total_map = rho_p @ Phi @ inv_rho_q         # (K_p, K_q)

            mu_trans = total_map @ mu_omega             # (K_p,)
            sigma_trans = total_map @ sigma_omega @ total_map.T  # (K_p, K_p)
            sigma_trans = sanitize_sigma(sigma_trans, eps)

            delta_mu = mu_i_ - mu_trans
            sigma_inv = safe_inv(sigma_trans, eps=eps)

            d_mu = -sigma_inv @ delta_mu                # (K_p,)

            delta_sigma = sigma_i_ - sigma_trans
            d_sigma = -0.5 * (sigma_inv @ delta_sigma @ sigma_inv)
            d_sigma = 0.5 * (d_sigma + d_sigma.T)       # symmetrize

            # Chain rule: ∂KL/∂Φ = ∂KL/∂μ × ∂μ/∂Φ + ∂KL/∂Σ × ∂Σ/∂Φ
            x = inv_rho_q @ mu_omega                    # (K_q,)
            dPhi_mu = np.outer(d_mu, x)                 # (K_p, K_q)

            S = inv_rho_q @ sigma_omega @ inv_rho_q.T   # (K_q, K_q)
            temp = d_sigma @ rho_p @ Phi                # (K_p, K_q)
            dPhi_sigma = 2 * (temp @ S)                 # (K_p, K_q)

            dPhi_field[i, j] = rho_p.T @ (dPhi_mu + dPhi_sigma)

    return dPhi_field


def gradient_step_phi_morphism(agent_i, agents, generators, params, rho_q_func, rho_p_func):
    """
    Compute the natural gradient step for φ̃ (phi_morphism), governing bundle morphism Φ.

    This enforces alignment between agent_i.p and Φ_{ij}·agent_j.p for all neighbors j.
    """
    beta = params.get("model_align_weight", config.model_align_weight)
    eps  = params.get("support_cutoff_eps", config.support_cutoff_eps)

    if beta <= 0 or not np.any(agent_i.mask > eps):
        return np.zeros_like(agent_i.phi_model)

    phi_i = agent_i.phi_model
    grad_phi = np.zeros_like(phi_i)

    for neighbor in agent_i.neighbors:
        agent_j = agents[neighbor["id"]]

        phi_j = agent_j.phi_model  # φ̃_j — Lie algebra coordinates of j
        Phi   = agent_j.bundle_morphism_q_to_p  # raw Φ_j field

        # Compute Φ_ij = ρ_p(exp(φ_i)) · Φ_j · ρ_q(exp(−φ_j))
        Phi_transformed = gauge_covariant_transform_phi(phi_i, Phi, rho_q_func, rho_p_func)

        # Compute transported model fields
        mu_j = agent_j.mu_p_field
        sigma_j = agent_j.sigma_p_field

        mu_trans = np.einsum("...ij,...j->...i", Phi_transformed, mu_j)
        sigma_trans = np.einsum("...ik,...kl,...jl->...ij", Phi_transformed, sigma_j, Phi_transformed)

        mu_i = agent_i.mu_p_field
        sigma_i = agent_i.sigma_p_field
        delta_mu = mu_i - mu_trans
        delta_sigma = sigma_i - sigma_trans
        sigma_inv = safe_inv(sanitize_sigma(sigma_trans), eps=config.eps)

        # === Compute φ̃ gradient w.r.t. transport error ===
        d_mu = -np.einsum("...ij,...j->...i", sigma_inv, delta_mu)
        d_sigma = -0.5 * np.einsum("...ik,...kl,...lj->...ij", sigma_inv, delta_sigma, sigma_inv)

        # === Project to Lie algebra coordinates ===
        d_mu_proj = np.einsum("...ij,ajk->...a", np.expand_dims(d_mu, -1), generators)  # (..., a)

        d_phi_mu = dexpinv_operator(phi_i, d_mu_proj, generators)
        d_phi_sigma = dexpinv_operator_covariance(phi_i, d_sigma, generators)
        grad = d_phi_mu + d_phi_sigma

        # Masked contribution
        joint_mask = (agent_i.mask > eps) & (agent_j.mask > eps)
        grad_phi += beta * grad * joint_mask[..., None]

    return grad_phi


