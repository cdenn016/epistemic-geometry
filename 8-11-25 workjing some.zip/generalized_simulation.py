
import os
os.environ["OMP_NUM_THREADS"] = "1"
os.environ["MKL_NUM_THREADS"] = "1"
os.environ["NUMEXPR_NUM_THREADS"] = "1"  # Optional: just in case
os.environ["OPENBLAS_NUM_THREADS"]= "1"

# Print to confirm they are set
print("[THREADING] Thread limits set:")
print(f"  OMP_NUM_THREADS      = {os.environ.get('OMP_NUM_THREADS')}")
print(f"  MKL_NUM_THREADS      = {os.environ.get('MKL_NUM_THREADS')}")
print(f"  NUMEXPR_NUM_THREADS  = {os.environ.get('NUMEXPR_NUM_THREADS')}")
print(f"  OPENBLAS_NUM_THREADS = {os.environ.get('OPENBLAS_NUM_THREADS')}")

# Standard library
import os
import time
import config
# Third-party
import pickle
import pandas as pd
from update_rules import synchronous_step, step_telemetry,_masked_unit, energy_diff_for_phi, energy_diff_for_phi_model
# Local configuration & utilities

from config_utils import set_config_from_params
from get_generators import get_generators
# run_simulation.py (cleaner entrypoint)
import sys

# add near other imports
import numpy as np

from xscale_helpers import compute_avg_crossscale_kl_p
from meta_agent_plots import _snapshot_parents_npz, _append_parent_metrics_csv
# I/O helpers
from generalized_io_utils import (
    save_step,
    load_checkpoint,
    find_resume_step,
    save_config_to_readme,
)

# Agent construction
from agent_initialization import initialize_agents, initialize_agent_gradients

from generalized_diagnostics_metrics import log_all_metrics, full_field_logger
from xscale_helpers import procrustes_seed_lambda_dn_q, compute_avg_crossscale_kl_q
from agent_initialization import attach_crossscale_fields

# ─────────────────────────────────────────────────────────────────────────────
# LOGGING HELPERS & DEFAULTS (drop near your imports)
# ─────────────────────────────────────────────────────────────────────────────
import os, shutil, time, pickle
import numpy as np
import pandas as pd
from update_rules import synchronous_step, step_telemetry,_masked_unit, energy_diff_for_phi, energy_diff_for_phi_model
from config_utils import set_config_from_params
from get_generators import get_generators
from generalized_io_utils import save_step, load_checkpoint, find_resume_step, save_config_to_readme
from generalized_diagnostics_metrics import log_all_metrics, full_field_logger
from xscale_helpers import compute_avg_crossscale_kl_q, compute_avg_crossscale_kl_p
from agent_initialization import initialize_agents, initialize_agent_gradients
from crossscale_lambda import _prepare_xscale_context, _seed_morphisms_if_missing
from update_rules import preprocess_agent_fields
from joblib import Parallel, delayed


LOGGING_DEFAULTS = dict(
    # master switches
    enable_scalar=True,          # run log_all_metrics
    enable_fields=False,          # run full_field_logger
    enable_max_overlap=True,     # (unused if you've removed that feature)
    print_total_energy=True,

    # cost-control cadence
    fields_every=1,              # dump full fields every k steps
    max_overlap_every=1,         # (unused if you've removed that feature)

    # misc schema & outdirs
    schema_version="v3",
    full_field_outdir="fields",
    pair_outdir="max_overlap",
)

def _merge_logging_cfg(params_or_cfg):
    """Return a logging dict with sane defaults even if missing."""
    logcfg = {}
    if hasattr(params_or_cfg, "get"):  # dict-like
        logcfg = params_or_cfg.get("logging", {}) or {}
    elif hasattr(params_or_cfg, "__dict__"):
        logcfg = getattr(params_or_cfg, "logging", {}) or {}
    out = dict(LOGGING_DEFAULTS)
    out.update(logcfg)
    return out


# ─────────────────────────────────────────────────────────────────────────────
# UPDATED run_simulation WITH NEW LOGGING
# ─────────────────────────────────────────────────────────────────────────────
def run_simulation(
    outdir="checkpoints",
    resume=False,
    log_metrics=True,
    log_fields=True,
    num_cores=None,
    params=None,
    fresh_outdir=False,
    clear_agent_logs=True,
):
    

    # fresh outdir rotation
    if not resume and fresh_outdir and os.path.isdir(outdir):
        ts = time.strftime("%Y%m%d_%H%M%S")
        shutil.move(outdir, f"{outdir}_old_{ts}")
    os.makedirs(outdir, exist_ok=True)
    save_config_to_readme(outdir)

    num_cores = 18 if num_cores is None else num_cores
    params = {} if params is None else params

    # config helpers
    def _cfg(key, default=None):
        if isinstance(params, dict) and key in params:
            return params[key]
        return getattr(config, key, default)

    # generators
    def _prepare_generators():
        Gq = params.get("generators_q")
        Gp = params.get("generators_p")
        if Gq is None:
            Gq, _ = get_generators(config.group_name, config.K_q, return_meta=True)
            params["generators_q"] = Gq
        if Gp is None:
            Gp, _ = get_generators(config.group_name, config.K_p, return_meta=True)
            params["generators_p"] = Gp
        return Gq, Gp

    G_q, G_p = _prepare_generators()

    # logging cfg
    logcfg = _merge_logging_cfg(params if isinstance(params, dict) else vars(config))
    if not log_metrics:
        logcfg["enable_scalar"] = False
    if not log_fields:
        logcfg["enable_fields"] = False
    if logcfg.get("enable_fields", False):
        os.makedirs(os.path.join(outdir, logcfg["full_field_outdir"]), exist_ok=True)
    if logcfg.get("enable_max_overlap", False):
        os.makedirs(os.path.join(outdir, logcfg["pair_outdir"]), exist_ok=True)

    # init / resume
    if resume:
        agents, _ = load_checkpoint(outdir)
        step_start = find_resume_step(outdir)
    else:
        agents = initialize_agents(
            seed=getattr(config, "seed", None),
            domain_size=config.domain_size,
            N=config.N,
            K_q=config.K_q,
            K_p=config.K_p,
            lie_algebra_dim=3,
            visualize=False,
            fixed_location=False,
        )
        step_start = 0
        for A in agents:
            initialize_agent_gradients(A, config)
        if clear_agent_logs:
            for A in agents:
                if hasattr(A, "metrics_log"):
                    A.metrics_log.clear()

    # ensure generators on agents
    for A in agents:
        A.generators_q = G_q
        A.generators_p = G_p

    # cross-scale context (all hidden in helper)
    agents, parents, labels, xscale_enabled, base_children = _prepare_xscale_context(agents, params, G_q, G_p)

    # morphism seeds (idempotent) + exp/Fisher caches once
    _seed_morphisms_if_missing(agents, G_q, G_p)
    Parallel(n_jobs=1, backend="threading")(   # keep single-threaded to avoid nested pools
        delayed(preprocess_agent_fields)(A, {"sanitize_strict": False, "exp_n_jobs": 1}, G_q, G_p)
        for A in agents
    )

    metric_log = []
    print(f"[RUN] Starting simulation at step {step_start} with {num_cores} cores")

    for step in range(step_start, config.steps):
        print(f"\n[STEP {step}] -----------------------------")
        t0 = time.perf_counter()
        step_params = {**params, "step": step, "sanitize_strict_pre": False}
        agents = synchronous_step(agents, G_q, G_p, params=step_params, n_jobs=num_cores)
        print(f"[TIMER] synchronous update: {time.perf_counter() - t0:.3f}s")

        if logcfg.get("enable_scalar", False):
            t1 = time.perf_counter()
            m = log_all_metrics(agents, step=step, params=params, n_jobs=num_cores)

            # XSCALE telemetry (child slice only)
            if xscale_enabled:
                try:
                    vals = compute_avg_crossscale_kl_q(agents[:base_children], parents, labels, eps=1e-6)
                    m["xscale_kl_q_mean"] = float(np.nanmean(vals))
                    m["xscale_kl_q_n"]    = int(np.isfinite(vals).sum())
                except Exception:
                    m["xscale_kl_q_mean"] = float("nan")
                    m["xscale_kl_q_n"]    = 0

                if _cfg("enable_crossscale_p", False):
                    try:
                        vals_p = compute_avg_crossscale_kl_p(agents[:base_children], parents, labels, eps=1e-6)
                        m["xscale_kl_p_mean"] = float(np.nanmean(vals_p))
                        m["xscale_kl_p_n"]    = int(np.isfinite(vals_p).sum())
                    except Exception:
                        m["xscale_kl_p_mean"] = float("nan")
                        m["xscale_kl_p_n"]    = 0

            m["schema"] = logcfg["schema_version"]
            m["compute_ms"] = int((time.perf_counter() - t1) * 1000)
            metric_log.append(m)

            if logcfg.get("print_total_energy", False):
                print(f"[Energy Totals @ step {step}]")
                print(f"  Self belief      = {m['e_self']:.4e}")
                print(f"  Feedback model   = {m['e_feedback']:.4e}")
                print(f"  Belief alignment = {m['e_align']:.4e}")
                print(f"  Model alignment  = {m['e_mod_align']:.4e}")
                print(f"  Model Mass       = {m['e_mass_mod']:.4e}")
                print(f"  Belief Mass      = {m['e_mass']:.4e}")
                print(f"  Belief Curvature = {m['e_curv']:.4e}")
                print(f"  Model Curvature  = {m['e_curv_mod']:.4e}")
                print(f"[TIMER] log_all_metrics: {time.perf_counter() - t1:.3f}s")

        if logcfg.get("enable_fields", False) and (step % logcfg["fields_every"] == 0):
            tF = time.perf_counter()
            field_dir = os.path.join(outdir, logcfg["full_field_outdir"])
            full_field_logger(agents, step, field_dir, params=params)
            print(f"[TIMER] full_field_logger: {time.perf_counter() - tF:.3f}s")

        # checkpoint
        for A in agents:
            if hasattr(A, "clear_omega_cache"):   A.clear_omega_cache()
            if hasattr(A, "clear_fisher_caches"): A.clear_fisher_caches()
        save_step(agents, outdir, step)
        print(f"[SAVE] Checkpoint --> {outdir}/step_{step:04d}.pkl")

    # epilogue
    if logcfg.get("enable_scalar", False):
        with open(os.path.join(outdir, "metric_log.pkl"), "wb") as f:
            pickle.dump(metric_log, f)
        print(f"[SAVE] Metrics log --> {outdir}/metric_log.pkl")

        rows = [
            {"agent": A.id, **entry}
            for A in agents
            for entry in getattr(A, "metrics_log", [])
        ]
        if rows:
            pd.DataFrame(rows).to_csv(os.path.join(outdir, "per_agent_metrics.csv"), index=False)
            print("[SAVE] Per-agent metrics --> per_agent_metrics.csv")

    if xscale_enabled:
        _snapshot_parents_npz(parents, os.path.join(outdir, "parents_end.npz"))

    print("[DONE] Simulation completed.")
    return agents, metric_log

if __name__ == "__main__":
    

    # ─────────────────────────────────────────────
    # 1. Optional param override
    # ─────────────────────────────────────────────
    if len(sys.argv) > 1:
        with open(sys.argv[1], "rb") as f:
            param_override = pickle.load(f)
        set_config_from_params(param_override)
    else:
        param_override = {}

    # ─────────────────────────────────────────────
    # 2. Load SO(3) generators for q and p fibers
    # ─────────────────────────────────────────────
    G_q, meta_q = get_generators(config.group_name, config.K_q, return_meta=True)
    G_p, meta_p = get_generators(config.group_name, config.K_p, return_meta=True)

    # ─────────────────────────────────────────────
    # 3. Bundle runtime-only params
    # ─────────────────────────────────────────────
    runtime_params = {
        "generators_q": G_q,
        "generators_p": G_p,
    }

    # ─────────────────────────────────────────────
    # 4. Run the simulation
    # ─────────────────────────────────────────────
    run_simulation(
        outdir="checkpoints",
        resume=False,
        log_metrics = True,
        log_fields  = False ,
        params=runtime_params,
    )
