# -*- coding: utf-8 -*-
"""
Created on Sun Aug 10 13:33:30 2025

@author: chris and christine
"""
# --- top of file: remove duplicate imports and unused kl_divergence ---
import numpy as np
from bundle_morphism_utils import safe_batch_apply_morphism_nat
from numerical_utils import sanitize_sigma, safe_inv
from xscale_helpers import compute_avg_crossscale_kl_p, compute_avg_crossscale_kl_q
from meta_gauge_fields import _hat3, so3_exp
from gaussian_core import _pushdown_gaussian, gaussian_pushforward_linear
import numpy as np
import config
from numerical_utils import safe_inv, sanitize_sigma
from omega import compute_curvature_gradient_analytical, d_exp_phi_exact
from natural_gradient import dexpinv_operator, compute_fisher_geometry_gradient

from numerical_utils import safe_inv, soft_clip_phi_norm
import numpy as np

from numerical_utils import safe_inv, sanitize_sigma

from numerical_utils import safe_omega_inv
from natural_gradient import dexpinv_operator
from omega import d_exp_phi_exact, d_exp_phi_tilde_exact, exp_lie_algebra_irrep



def accumulate_crossscale_gradients(agent_i, agents, generators_q, generators_p, params):
    """
    Child <- Parent cross-scale accumulation (q + p).
    Parents untouched (child_only=True). Prints one summary line per child.
    """
    import numpy as np
    lam_x_q = params.get("lambda_xscale_q", getattr(config, "lambda_xscale_q", 0.0))
    lam_x_p = params.get("lambda_xscale_p", getattr(config, "lambda_xscale_p", 0.0))
    eps     = getattr(config, "eps", 1e-6)

    pid = getattr(agent_i, "parent_id", -1)
    if pid < 0 or pid >= len(agents):
        return
    parent = agents[pid]

    # quick overlap check
    m = (np.asarray(agent_i.mask) > eps) & (np.asarray(parent.mask) > eps)
    if not np.any(m):
        return

    # dimension guards
    kl_q = float("nan")
    kl_p = float("nan")

    if lam_x_q > 0.0 and agent_i.mu_q_field.shape[-1] == parent.mu_q_field.shape[-1]:
        kl_q = accumulate_xscale_q_dn_gaugecov(
            child=agent_i, parent=parent, generators_q=generators_q,
            lam_q=lam_x_q, eps=eps, child_only=True
        )

    if lam_x_p > 0.0 and agent_i.mu_p_field.shape[-1] == parent.mu_p_field.shape[-1]:
        kl_p = accumulate_xscale_p_dn_gaugecov(
            child=agent_i, parent=parent, generators_p=generators_p,
            lam_p=lam_x_p, eps=eps, child_only=True
        )

    #print(f"[XSCALE] child {getattr(agent_i,'id','?')} -> parent {getattr(parent,'id','?')} | "
        #  f"λq={lam_x_q:.3g} KLq={kl_q:.4g} | λp={lam_x_p:.3g} KLp={kl_p:.4g}")



def accumulate_xscale_q_dn_gaugecov(
    child, parent, generators_q, lam_q: float, eps: float = 1e-6,
    use_cached_exp: bool = True,
    child_only: bool = False,
):
    """
    Cross-scale belief KL with gauge-covariant Λ:
      Λ = exp(φ_child) · exp(-φ_parent) = E_c · E_p^T
    Accumulates into child grads always; into parent grads only if child_only=False.
    Returns masked-mean scalar KL for telemetry.
    """
    if lam_q <= 0.0:
        return 0.0

    def _sym(A): 
        return 0.5 * (A + np.swapaxes(A, -1, -2))

    # --- exp(φ) caches ---
    if use_cached_exp and getattr(child, "_exp_phi", None) is not None:
        E_c = child._exp_phi
    else:
        E_c = exp_lie_algebra_irrep(child.phi, generators_q)
        child._exp_phi = E_c

    if use_cached_exp and getattr(parent, "_exp_phi", None) is not None:
        E_p = parent._exp_phi
    else:
        E_p = exp_lie_algebra_irrep(parent.phi, generators_q)
        parent._exp_phi = E_p

    E_p_T = np.swapaxes(E_p, -1, -2)
    Lambda = np.einsum("...ik,...kj->...ij", E_c, E_p_T)

    # --- fields ---
    muP = parent.mu_q_field
    SP  = sanitize_sigma(parent.sigma_q_field, eps=eps)
    mu  = child.mu_q_field
    S   = sanitize_sigma(child.sigma_q_field, eps=eps)

    # --- push down parent to child frame ---
    mu_t = np.einsum("...ij,...j->...i", Lambda, muP)
    S_t  = np.einsum("...ik,...kl,...jl->...ij", Lambda, SP, Lambda)
    S_t  = sanitize_sigma(_sym(S_t), eps=eps)

    S_t_inv = safe_inv(S_t, eps=eps)
    S_inv   = safe_inv(S,   eps=eps)

    # --- joint mask ---
    H, W = mu.shape[-3], mu.shape[-2]
    m   = ((child.mask > eps) & (parent.mask > eps))
    m   = np.broadcast_to(np.asarray(m, dtype=bool), (H, W))        # (H,W)
    m1  = m[..., None].astype(mu.dtype)                              # (H,W,1)
    m4  = m[..., None, None].astype(mu.dtype)                        # (H,W,1,1)

    # --- child μ, Σ grads ---
    g_mu_child = (S_t_inv @ (mu - mu_t)[..., None])[..., 0]          # (H,W,K)
    g_S_child  = _sym(0.5 * (S_t_inv - S_inv))                       # (H,W,K,K)

    if getattr(child, "grad_mu_q", None) is None:
        child.grad_mu_q = np.zeros_like(mu)
    if getattr(child, "grad_sigma_q", None) is None:
        child.grad_sigma_q = np.zeros_like(S)

    child.grad_mu_q    += lam_q * g_mu_child * m1
    child.grad_sigma_q += lam_q * g_S_child  * m4

    # --- shared helpers for Λ backprop ---
    dmu    = (mu - mu_t)                                            # (H,W,K)
    dmu_t  = - (S_t_inv @ dmu[..., None])[..., 0]                   # ∂KL/∂μ_t
    outer  = dmu[..., None] @ np.swapaxes(dmu[..., None], -1, -2)   # (H,W,K,K)
    dKL_dA = 0.5 * (S + outer - S_t)
    dS_t   = _sym(- np.einsum("...ik,...kl,...lj->...ij", S_t_inv, dKL_dA, S_t_inv))

    # --- parent μ, Σ grads (only if enabled) ---
    if not child_only:
        g_muP = (np.swapaxes(Lambda, -1, -2) @ dmu_t[..., None])[..., 0]
        g_SP  = _sym(np.einsum("...ik,...kl,...jl->...ij",
                               np.swapaxes(Lambda, -1, -2), dS_t, Lambda))
        if getattr(parent, "grad_mu_q", None) is None:
            parent.grad_mu_q = np.zeros_like(muP)
        if getattr(parent, "grad_sigma_q", None) is None:
            parent.grad_sigma_q = np.zeros_like(SP)
        parent.grad_mu_q    += lam_q * g_muP * m1
        parent.grad_sigma_q += lam_q * g_SP  * m4

    # --- φ grads: child always; parent only if enabled ---
    # GΛ = (∂KL/∂μ_t) μ_P^T + 2 (∂KL/∂S_t) Λ Σ_P
    term_mean = dmu_t[..., None] @ muP[..., None, :]
    term_cov  = 2.0 * np.einsum("...ij,...jk,...kl->...il", dS_t, Lambda, SP)
    GΛ = (term_mean + term_cov) * m4                                      # (H,W,K,K)

    T_child   = np.einsum("...ij,...jk->...ik", GΛ, E_p)                  # right-multiply by E_p
    D_child   = d_exp_phi_exact(child.phi, generators_q, exp_phi_all=E_c) # list of 3 (...,K,K)
    g_phi_child = np.stack([np.einsum("...ij,...ij->...", T_child, D_child[a])
                            for a in range(3)], axis=-1)                  # (H,W,3)
    if getattr(child, "grad_phi", None) is None:
        child.grad_phi = np.zeros_like(child.phi)
    child.grad_phi += lam_q * g_phi_child * m1

    if not child_only:
        T_parent = - np.einsum("...ij,...jk,...kl->...il",
                               np.swapaxes(Lambda, -1, -2), GΛ, E_p)
        D_parent = d_exp_phi_exact(parent.phi, generators_q, exp_phi_all=E_p)
        g_phi_parent = np.stack([np.einsum("...ij,...ij->...", T_parent, D_parent[a])
                                 for a in range(3)], axis=-1)
        if getattr(parent, "grad_phi", None) is None:
            parent.grad_phi = np.zeros_like(parent.phi)
        parent.grad_phi += lam_q * g_phi_parent * m1

    # --- scalar KL (masked mean) ---
    diff = (mu_t - mu)[..., None]                                     # (H,W,K,1)
    quad = (np.swapaxes(diff, -1, -2) @ S_t_inv @ diff)[..., 0, 0]
    tr_term = np.einsum("...ij,...ji->...", S_t_inv, S)
    sign_t, logdet_t = np.linalg.slogdet(S_t)
    sign_c, logdet_c = np.linalg.slogdet(S)
    logdet_t = np.where(sign_t > 0, logdet_t, np.nan)
    logdet_c = np.where(sign_c > 0, logdet_c, np.nan)
    kl_point = 0.5 * (tr_term + quad - S.shape[-1] + (logdet_t - logdet_c))

    valid = np.isfinite(kl_point) & m
    return float(np.nanmean(kl_point[valid])) if np.any(valid) else 0.0


def accumulate_xscale_p_dn_gaugecov(
    child, parent, generators_p, lam_p: float, eps: float = 1e-6,
    use_cached_exp: bool = True,
    child_only: bool = False,
):
    """
    Cross-scale model KL with gauge-covariant Λ̃ (phi_model side):
      Λ̃ = exp(φ̃_child) · exp(-φ̃_parent) = Ê_c · Ê_p^T
    Accumulates into child grads always; into parent grads only if child_only=False.
    Returns masked-mean scalar KL for telemetry.
    """
    if lam_p <= 0.0:
        return 0.0

    def _sym(A):
        return 0.5 * (A + np.swapaxes(A, -1, -2))

    # --- exp(φ̃) caches ---
    if use_cached_exp and getattr(child, "_exp_phi_model", None) is not None:
        Ec = child._exp_phi_model
    else:
        Ec = exp_lie_algebra_irrep(child.phi_model, generators_p)
        child._exp_phi_model = Ec

    if use_cached_exp and getattr(parent, "_exp_phi_model", None) is not None:
        Ep = parent._exp_phi_model
    else:
        Ep = exp_lie_algebra_irrep(parent.phi_model, generators_p)
        parent._exp_phi_model = Ep

    Ep_T   = np.swapaxes(Ep, -1, -2)
    Lambda = np.einsum("...ik,...kj->...ij", Ec, Ep_T)

    # --- fields (model side) ---
    muP = parent.mu_p_field
    SP  = sanitize_sigma(parent.sigma_p_field, eps=eps)
    mu  = child.mu_p_field
    S   = sanitize_sigma(child.sigma_p_field, eps=eps)

    # --- push down parent to child frame ---
    mu_t = np.einsum("...ij,...j->...i", Lambda, muP)
    S_t  = np.einsum("...ik,...kl,...jl->...ij", Lambda, SP, Lambda)
    S_t  = sanitize_sigma(_sym(S_t), eps=eps)

    S_t_inv = safe_inv(S_t, eps=eps)
    S_inv   = safe_inv(S,   eps=eps)

    # --- joint mask ---
    H, W = mu.shape[-3], mu.shape[-2]
    m   = ((child.mask > eps) & (parent.mask > eps))
    m   = np.broadcast_to(np.asarray(m, dtype=bool), (H, W))
    m1  = m[..., None].astype(mu.dtype)           # (H,W,1)
    m4  = m[..., None, None].astype(mu.dtype)     # (H,W,1,1)

    # --- child μ, Σ grads (model side) ---
    g_mu_child = (S_t_inv @ (mu - mu_t)[..., None])[..., 0]
    g_S_child  = _sym(0.5 * (S_t_inv - S_inv))

    if getattr(child, "grad_mu_p", None) is None:
        child.grad_mu_p = np.zeros_like(mu)
    if getattr(child, "grad_sigma_p", None) is None:
        child.grad_sigma_p = np.zeros_like(S)

    child.grad_mu_p    += lam_p * g_mu_child * m1
    child.grad_sigma_p += lam_p * g_S_child  * m4

    # --- shared helpers for Λ̃ backprop ---
    dmu    = (mu - mu_t)
    dmu_t  = - (S_t_inv @ dmu[..., None])[..., 0]  # ∂KL/∂μ_t
    outer  = dmu[..., None] @ np.swapaxes(dmu[..., None], -1, -2)
    dKL_dA = 0.5 * (S + outer - S_t)
    dS_t   = _sym(- np.einsum("...ik,...kl,...lj->...ij", S_t_inv, dKL_dA, S_t_inv))

    # --- parent μ, Σ grads (model side) ---
    if not child_only:
        g_muP = (np.swapaxes(Lambda, -1, -2) @ dmu_t[..., None])[..., 0]
        g_SP  = _sym(np.einsum("...ik,...kl,...jl->...ij",
                               np.swapaxes(Lambda, -1, -2), dS_t, Lambda))
        if getattr(parent, "grad_mu_p", None) is None:
            parent.grad_mu_p = np.zeros_like(muP)
        if getattr(parent, "grad_sigma_p", None) is None:
            parent.grad_sigma_p = np.zeros_like(SP)
        parent.grad_mu_p    += lam_p * g_muP * m1
        parent.grad_sigma_p += lam_p * g_SP  * m4

    # --- φ̃ grads (model gauge): child always; parent only if enabled ---
    term_mean = dmu_t[..., None] @ muP[..., None, :]
    term_cov  = 2.0 * np.einsum("...ij,...jk,...kl->...il", dS_t, Lambda, SP)
    GΛ = (term_mean + term_cov) * m4

    T_child    = np.einsum("...ij,...jk->...ik", GΛ, Ep)
    D_child    = d_exp_phi_exact(child.phi_model, generators_p, exp_phi_all=Ec)
    g_phi_m_ch = np.stack([np.einsum("...ij,...ij->...", T_child, D_child[a])
                           for a in range(3)], axis=-1)
    if getattr(child, "grad_phi_tilde", None) is None:
        child.grad_phi_tilde = np.zeros_like(child.phi_model)
    child.grad_phi_tilde += lam_p * g_phi_m_ch * m1

    if not child_only:
        T_parent   = - np.einsum("...ij,...jk,...kl->...il",
                                 np.swapaxes(Lambda, -1, -2), GΛ, Ep)
        D_parent   = d_exp_phi_exact(parent.phi_model, generators_p, exp_phi_all=Ep)
        g_phi_m_pa = np.stack([np.einsum("...ij,...ij->...", T_parent, D_parent[a])
                               for a in range(3)], axis=-1)
        if getattr(parent, "grad_phi_tilde", None) is None:
            parent.grad_phi_tilde = np.zeros_like(parent.phi_model)
        parent.grad_phi_tilde += lam_p * g_phi_m_pa * m1

    # --- scalar KL (masked mean), model side ---
    diff = (mu_t - mu)[..., None]
    quad = (np.swapaxes(diff, -1, -2) @ S_t_inv @ diff)[..., 0, 0]
    tr_term = np.einsum("...ij,...ji->...", S_t_inv, S)
    sign_t, logdet_t = np.linalg.slogdet(S_t)
    sign_c, logdet_c = np.linalg.slogdet(S)
    logdet_t = np.where(sign_t > 0, logdet_t, np.nan)
    logdet_c = np.where(sign_c > 0, logdet_c, np.nan)
    kl_point = 0.5 * (tr_term + quad - S.shape[-1] + (logdet_t - logdet_c))

    valid = np.isfinite(kl_point) & m
    return float(np.nanmean(kl_point[valid])) if np.any(valid) else 0.0



