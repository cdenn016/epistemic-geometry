from dataclasses import dataclass, field
from typing import Any, Dict, List, Tuple, Optional
import numpy as np

@dataclass
class Agent:
    id: int
    center: Tuple[int, ...]
    radius: float
    mask: np.ndarray

    # Lie fields
    phi: np.ndarray
    phi_model: np.ndarray

    # Belief/model fields
    mu_q_field: np.ndarray
    sigma_q_field: np.ndarray
    mu_p_field: np.ndarray
    sigma_p_field: np.ndarray

    # Inverses (filled in preprocess)
    sigma_q_inv: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    sigma_p_inv: Optional[np.ndarray] = field(default=None, init=False, repr=False)

    # Neighborhood & logging
    neighbors: List[Dict[str, Any]] = field(default_factory=list)
    metrics_log: List[Dict[str, Any]] = field(default_factory=list)

    # Gradient caches
    grad_mu_q: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    grad_sigma_q: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    grad_mu_p: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    grad_sigma_p: Optional[np.ndarray] = field(default=None, init=False, repr=False)

    # Generators (prefer set once and reused)
    generators_q: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    generators_p: Optional[np.ndarray] = field(default=None, init=False, repr=False)

    # exp(φ) caches
    _exp_phi: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    _exp_neg_phi: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    _exp_phi_model: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    _exp_neg_phi_model: Optional[np.ndarray] = field(default=None, init=False, repr=False)

    # Inter-agent transport caches
    Omega_cache: Dict[str, Any] = field(default_factory=dict, init=False, repr=False)
    Omega_tilde_cache: Dict[str, Any] = field(default_factory=dict, init=False, repr=False)

    # Morphisms
    bundle_morphism_q_to_p: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    bundle_morphism_p_to_q: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    Phi_0: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    Phi_tilde_0: Optional[np.ndarray] = field(default=None, init=False, repr=False)

    # φ/φ̃ grads (field-shaped)
    grad_phi: np.ndarray = field(init=False, repr=False)
    grad_phi_tilde: np.ndarray = field(init=False, repr=False)

    # Morphism grads (optional)
    grad_Phi: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    grad_Phi_tilde: Optional[np.ndarray] = field(default=None, init=False, repr=False)

    # Fisher caches for φ/φ̃ or morphisms
    inverse_fisher_phi: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    inverse_fisher_phi_model: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    inverse_fisher_Phi: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    inverse_fisher_Phi_tilde: Optional[np.ndarray] = field(default=None, init=False, repr=False)

    # Diagnostics / pullbacks (optional)
    fisher_I: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    pull_M_vis: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    pull_Delta: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    pull_M_dark: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    spatial_G: Optional[np.ndarray] = field(default=None, init=False, repr=False)

    # NEW: adaptive-η & KL caches
    _cond_proxy_q: Optional[float] = field(default=None, init=False, repr=False)
    _cond_proxy_p: Optional[float] = field(default=None, init=False, repr=False)
    _eta_phi_prev: Optional[float]   = field(default=None, init=False, repr=False)
    _eta_phi_m_prev: Optional[float] = field(default=None, init=False, repr=False)
    cached_alignment_kl: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    cached_model_alignment_kl: Optional[np.ndarray] = field(default=None, init=False, repr=False)


        # Cross-scale metadata
    level: int = 0
    parent_ids: List[int] = field(default_factory=list)
    child_ids: List[int] = field(default_factory=list)
    
    # Cross-scale maps (child ↔ parent) — q- and p-bundles
    Lambda_up_q: Optional[np.ndarray] = field(default=None, init=False, repr=False)  # (Kq, Kq)
    Lambda_dn_q: Optional[np.ndarray] = field(default=None, init=False, repr=False)  # inverse of above
    Lambda_up_p: Optional[np.ndarray] = field(default=None, init=False, repr=False)  # (Kp, Kp)
    Lambda_dn_p: Optional[np.ndarray] = field(default=None, init=False, repr=False)  # inverse of above
    
    # (optional) gradient buffers for future use
    grad_Lambda_up_q: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    grad_Lambda_dn_q: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    grad_Lambda_up_p: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    grad_Lambda_dn_p: Optional[np.ndarray] = field(default=None, init=False, repr=False)

    # Cross-scale Inference maps (Θ)
    Theta_up: Optional[np.ndarray] = field(default=None, init=False, repr=False)   # (K_p, K_q)
    Theta_dn: Optional[np.ndarray] = field(default=None, init=False, repr=False)   # (K_q, K_p)
    
    grad_Theta_up: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    grad_Theta_dn: Optional[np.ndarray] = field(default=None, init=False, repr=False)




    def __post_init__(self):
        self.grad_phi = np.zeros_like(self.phi)
        self.grad_phi_tilde = np.zeros_like(self.phi_model)
        if self.bundle_morphism_q_to_p is not None:
            self.grad_Phi = np.zeros_like(self.bundle_morphism_q_to_p)
        if self.bundle_morphism_p_to_q is not None:
            self.grad_Phi_tilde = np.zeros_like(self.bundle_morphism_p_to_q)

    @property
    def grid_shape(self) -> Tuple[int, ...]:
        return self.mu_q_field.shape[:-1]

    @property
    def Omega(self) -> np.ndarray:
        K = self.mu_q_field.shape[-1]
        return self._exp_phi.reshape(*self.grid_shape, K, K)

    @property
    def Omega_inv(self) -> np.ndarray:
        K = self.mu_q_field.shape[-1]
        return self._exp_neg_phi.reshape(*self.grid_shape, K, K)

    @property
    def Omega_model(self) -> np.ndarray:
        K = self.mu_p_field.shape[-1]
        return self._exp_phi_model.reshape(*self.grid_shape, K, K)

    @property
    def Omega_model_inv(self) -> np.ndarray:
        K = self.mu_p_field.shape[-1]
        return self._exp_neg_phi_model.reshape(*self.grid_shape, K, K)

    def log_metrics(self, step: int, stats: Dict[str, Any]) -> None:
        import copy
        self.metrics_log.append(copy.deepcopy({'step': step, **stats}))

    def clear_omega_cache(self) -> None:
        self._exp_phi = None
        self._exp_neg_phi = None
        self._exp_phi_model = None
        self._exp_neg_phi_model = None
        self.Omega_cache.clear()
        self.Omega_tilde_cache.clear()

    def clear_diagnostics(self) -> None:
        self.fisher_I = None
        self.pull_M_vis = None
        self.pull_Delta = None
        self.pull_M_dark = None
        self.spatial_G = None

    def clear_fisher_caches(self) -> None:
        self.inverse_fisher_phi = None
        self.inverse_fisher_phi_model = None
        self.inverse_fisher_Phi = None
        self.inverse_fisher_Phi_tilde = None

    def ensure_crossscale_defaults(self, Kq: int, Kp: int) -> None:
        if self.Lambda_up_q is None:
            self.Lambda_up_q = np.eye(Kq)
            self.Lambda_dn_q = np.eye(Kq)
        if self.Lambda_up_p is None:
            self.Lambda_up_p = np.eye(Kp)
            self.Lambda_dn_p = np.eye(Kp)
        if self.Theta_up is None:
            self.Theta_up = np.zeros((Kp, Kq))
            self.Theta_dn = np.zeros((Kq, Kp))

    def ensure_crossscale_grad_buffers(self) -> None:
        if self.Lambda_up_q is not None and self.grad_Lambda_up_q is None:
            self.grad_Lambda_up_q = np.zeros_like(self.Lambda_up_q)
            self.grad_Lambda_dn_q = np.zeros_like(self.Lambda_dn_q)
        if self.Lambda_up_p is not None and self.grad_Lambda_up_p is None:
            self.grad_Lambda_up_p = np.zeros_like(self.Lambda_up_p)
            self.grad_Lambda_dn_p = np.zeros_like(self.Lambda_dn_p)
        if self.Theta_up is not None and self.grad_Theta_up is None:
            self.grad_Theta_up = np.zeros_like(self.Theta_up)
            self.grad_Theta_dn = np.zeros_like(self.Theta_dn)
    
    def clear_crossscale_maps(self) -> None:
        """Clear cached cross-scale maps (Λ/Λ̃) and their grads."""
        self.Lambda_up_q = self.Lambda_dn_q = None
        self.Lambda_up_p = self.Lambda_dn_p = None
        self.grad_Lambda_up_q = self.grad_Lambda_dn_q = None
        self.grad_Lambda_up_p = self.grad_Lambda_dn_p = None
    
    
    def build_lambda_q_to(self, parent: "Agent") -> np.ndarray:
        """
        Build Λ_{c→P}^q = exp(φ_P) · exp(−φ_c) and cache both up/down.
        Assumes K_q dimensions match between child (self) and parent.
        """
        E_c = getattr(self, "_exp_phi", None)
        E_P = getattr(parent, "_exp_phi", None)
        if E_c is None or E_P is None:
            raise RuntimeError("Missing exp(phi) cache(s): build exponentials before calling build_lambda_q_to().")
    
        # Using pseudoinverse for numerical safety; replace with your safe inverse if you prefer
        E_c_inv = np.linalg.pinv(E_c)
        Lambda_up = E_P @ E_c_inv
        Lambda_dn = np.linalg.pinv(Lambda_up)
    
        self.Lambda_up_q = Lambda_up
        self.Lambda_dn_q = Lambda_dn
        return Lambda_up
    
    
    def build_lambda_p_to(self, parent: "Agent") -> np.ndarray:
        """
        Build Λ_{c→P}^p = exp(φ̃_P) · exp(−φ̃_c) and cache both up/down.
        Assumes K_p dimensions match between child (self) and parent.
        """
        Ec = getattr(self, "_exp_phi_model", None)
        EP = getattr(parent, "_exp_phi_model", None)
        if Ec is None or EP is None:
            raise RuntimeError("Missing exp(phĩ) cache(s): build exponentials before calling build_lambda_p_to().")
    
        Ec_inv = np.linalg.pinv(Ec)
        Lambda_up = EP @ Ec_inv
        Lambda_dn = np.linalg.pinv(Lambda_up)
    
        self.Lambda_up_p = Lambda_up
        self.Lambda_dn_p = Lambda_dn
        return Lambda_up
    
    
    def primary_parent(self) -> Optional[int]:
        """Return the first parent id if present, else None."""
        pids = getattr(self, "parent_ids", None)
        return pids[0] if pids else None
