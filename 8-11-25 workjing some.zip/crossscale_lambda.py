# -*- coding: utf-8 -*-
"""
Created on Mon Aug 11 11:34:26 2025

@author: chris and christine
"""

# crossscale_lambda.py
from __future__ import annotations
from typing import Sequence
import numpy as np
import config


def attach_crossscale_fields(agent, Kq, Kp):
    if getattr(agent, "level", None) is None:      agent.level = 0
    if getattr(agent, "parent_ids", None) is None: agent.parent_ids = []
    if getattr(agent, "child_ids", None) is None:  agent.child_ids = []
    if getattr(agent, "Lambda_up_q", None) is None: agent.Lambda_up_q = np.eye(Kq)
    if getattr(agent, "Lambda_dn_q", None) is None: agent.Lambda_dn_q = np.eye(Kq)
    if getattr(agent, "Lambda_up_p", None) is None: agent.Lambda_up_p = np.eye(Kp)
    if getattr(agent, "Lambda_dn_p", None) is None: agent.Lambda_dn_p = np.eye(Kp)
    if getattr(agent, "Theta_up", None) is None:    agent.Theta_up = np.zeros((Kp, Kq))
    if getattr(agent, "Theta_dn", None) is None:    agent.Theta_dn = np.zeros((Kq, Kp))




def ensure_exp_caches(agents: Sequence) -> None:
    """
    Ensure each agent has exp(phi) and exp(phĩ) cached as _exp_phi and _exp_phi_model.
    If your code already populates these, this is a no-op.
    Otherwise, call your existing cache builder here.
    """
    for a in agents:
        if getattr(a, "_exp_phi", None) is None:
            if hasattr(a, "build_exp_phi"):
                a.build_exp_phi()
            else:
                # last resort: exp via omega exp map you already use
                # replace with your project's exact function if needed
                a._exp_phi = np.linalg.expm(a.phi) if hasattr(np.linalg, "expm") else np.eye(a.phi.shape[-1])
        if getattr(a, "_exp_phi_model", None) is None:
            if hasattr(a, "build_exp_phi_model"):
                a.build_exp_phi_model()
            else:
                a._exp_phi_model = np.linalg.expm(a.phi_model) if hasattr(np.linalg, "expm") else np.eye(a.phi_model.shape[-1])

def build_all_lambdas(children: Sequence, parents: Sequence, labels) -> None:
    """
    Build and cache Λ (up) and Λ̃ (down) for q and p for every child that has a parent.
    Assumes parent/child fiber dims match (your current constraint).
    Uses Agent methods you added: build_lambda_q_to, build_lambda_p_to.
    """
    for i, ch in enumerate(children):
        pid = int(labels[i]) if i < len(labels) else -1
        if pid < 0:
            continue
        P = parents[pid]
        # Will raise clean RuntimeError if exponentials are missing
        ch.build_lambda_q_to(P)
        ch.build_lambda_p_to(P)

def validate_lambdas(children: Sequence, atol: float = 1e-5) -> None:
    """
    Optional sanity check: ||Λ Λ̃ - I|| and ||Λ̃ Λ - I|| small.
    Prints warnings but does not raise.
    """
    for idx, ch in enumerate(children):
        Lq = getattr(ch, "Lambda_up_q", None)
        Lqi = getattr(ch, "Lambda_dn_q", None)
        Lp = getattr(ch, "Lambda_up_p", None)
        Lpi = getattr(ch, "Lambda_dn_p", None)
        if Lq is not None and Lqi is not None:
            nrm = np.linalg.norm(Lq @ Lqi - np.eye(Lq.shape[0]))
            if nrm > atol:
                print(f"[Λq WARN child {idx}] ||Λ Λ̃ - I|| = {nrm:.2e}")
        if Lp is not None and Lpi is not None:
            nrm = np.linalg.norm(Lp @ Lpi - np.eye(Lp.shape[0]))
            if nrm > atol:
                print(f"[Λp WARN child {idx}] ||Λ Λ̃ - I|| = {nrm:.2e}")

def _prepare_xscale_context(agents, params, G_q, G_p):
    """
    If params["xscale"] is present, integrate parents into `agents`,
    wire child<->parent ids, ensure cross-scale slots, build exp caches + Λ.
    Returns: (agents, parents, labels, xscale_enabled, base_children)
    """
    import numpy as np
    from agent_initialization import attach_crossscale_fields, initialize_agent_gradients
    from crossscale_lambda import ensure_exp_caches, build_all_lambdas

    xctx = params.get("xscale")
    parents, labels = (None, None)
    if not xctx:
        return agents, parents, labels, False, 0

    parents = xctx["parents"]
    labels  = np.asarray(xctx["labels"])
    # make sure parents carry generators and slots
    for P in parents:
        P.generators_q = G_q
        P.generators_p = G_p
        attach_crossscale_fields(P, config.K_q, config.K_p)
        P.level = getattr(P, "level", 1)

    # make sure children have slots
    for C in agents:
        attach_crossscale_fields(C, config.K_q, config.K_p)

    xscale_enabled   = bool(getattr(config, "enable_crossscale", False) and (parents is not None) and (labels is not None))
    if not xscale_enabled:
        return agents, parents, labels, False, 0

    # integrate parents exactly once (so child.parent_id works)
    already_linked = any(getattr(A, "parent_id", -1) >= 0 for A in agents)
    if already_linked:
        base_children = sum(1 for A in agents if getattr(A, "level", 0) == 0)
        ensure_exp_caches(agents)
        # rebuild Λ in case φ changed via resume
        build_all_lambdas(children=agents[:base_children], parents=[A for A in agents if getattr(A, "level", 0) == 1], labels=labels)
        return agents, parents, labels, True, base_children

    base_children = len(agents)

    # append parents with fresh ids
    for j, P in enumerate(parents):
        P.id = base_children + j
        P.level = 1
        initialize_agent_gradients(P, config)
        P.generators_q = G_q
        P.generators_p = G_p
        agents.append(P)

    # wire children -> parents and parents <- children
    for i in range(base_children):
        C = agents[i]
        C.level = 0
        pid_local = int(labels[i]) if i < len(labels) else -1
        if pid_local >= 0:
            P = parents[pid_local]
            C.parent_id = P.id
            if not hasattr(P, "child_ids") or P.child_ids is None:
                P.child_ids = []
            P.child_ids.append(C.id)

    # build exp caches + Λ maps
    ensure_exp_caches(agents)  # includes appended parents
    build_all_lambdas(children=agents[:base_children], parents=agents[base_children:], labels=labels)

    return agents, parents, labels, True, base_children


def _seed_morphisms_if_missing(agents, G_q, G_p):
    """
    Ensure rectangular seeds Phi_0 (Kp×Kq) and Phi_tilde_0 (Kq×Kp),
    then compute bundle morphisms from current φ, φ̃.
    """
    from bundle_morphism_utils import compute_direct_morphisms
    import numpy as np

    def _rect_identity(rows, cols, dtype=float):
        M = np.zeros((rows, cols), dtype=dtype)
        k = min(rows, cols)
        idx = np.arange(k)
        M[idx, idx] = 1.0
        return M

    for A in agents:
        if not hasattr(A, "Phi_0") or A.Phi_0 is None or np.asarray(A.Phi_0).ndim != 2:
            A.Phi_0 = _rect_identity(config.K_p, config.K_q, dtype=float)
        if not hasattr(A, "Phi_tilde_0") or A.Phi_tilde_0 is None or np.asarray(A.Phi_tilde_0).ndim != 2:
            A.Phi_tilde_0 = _rect_identity(config.K_q, config.K_p, dtype=float)

        A.bundle_morphism_q_to_p, A.bundle_morphism_p_to_q = compute_direct_morphisms(
            phi=A.phi,
            phi_model=A.phi_model,
            generators_q=G_q,
            generators_p=G_p,
            Phi_0=A.Phi_0,
            Phi_tilde_0=A.Phi_tilde_0,
        )

def rebuild_downscale_maps(agents, G_q, G_p, only_adjacent=True):
    """
    Rebuild Λ_dn_q and Λ_dn_p fields for all child→parent pairs using cached exponentials.
    Assumes preprocess_agent_fields has just refreshed _exp_phi/_exp_phi_model.
    Returns number of (q,p) maps rebuilt.
    """
    n_q = 0
    n_p = 0
    # cheap gate: nothing to do if nobody has a parent_id
    if not any(getattr(a, "parent_id", -1) >= 0 for a in agents):
        return n_q, n_p

    for ch in agents:
        pid = getattr(ch, "parent_id", -1)
        if pid is None or pid < 0:
            continue
        P = agents[pid]
        if only_adjacent:
            if not (getattr(P, "level", None) == getattr(ch, "level", None) + 1):
                continue

        # use cached exponentials produced by preprocess_agent_fields
        Ec = getattr(ch, "_exp_phi", None)
        Ep = getattr(P,  "_exp_phi", None)
        if (Ec is not None) and (Ep is not None):
            ch.Lambda_dn_q = Ec @ np.swapaxes(Ep, -1, -2)
            n_q += 1

        Emc = getattr(ch, "_exp_phi_model", None)
        Emp = getattr(P,  "_exp_phi_model", None)
        if (Emc is not None) and (Emp is not None):
            ch.Lambda_dn_p = Emc @ np.swapaxes(Emp, -1, -2)
            n_p += 1

    return n_q, n_p
