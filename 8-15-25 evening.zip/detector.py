import numpy as np
import config
from typing import Dict, List, Optional

from parent_utils import child_activity_map
from dataclasses import dataclass, field



@dataclass
class Region:
    id: int
    mask: np.ndarray
    state: str
    age: int = 0
    t_activated: Optional[int] = None
    child_ids: List[int] = field(default_factory=list)

@dataclass
class DetectorState:
    regions: Dict[int, Region] = field(default_factory=dict)
    next_id: int = 0
    step: int = 0





def detect_regions_minimal(
    children, *, H, W,
    min_kids: int,
    min_area: int,
    kl_tau=None,                     # None → skip KL/Agree gate
    weight_tau=0.6,                  # or config.parent_weight_tau (None => auto)
    erode_iters=None,                # or config.detector_edge_erode
    runtime_ctx=None,
    agree_gate_tau=None,             # or config.agree_gate_tau / runtime auto
    periodic=None,
    return_cand_map: bool = True,
):
    """
    Minimal, unified region detector (MVG-aware; uses spawn caches when present):
      1) require >= min_kids active children per pixel
      2) interior gate by mean child-mask weight (adaptive if weight_tau=None)
      3) optional local gate via blended agreement from per-child softmin KLs (kl_tau)
      4) optional global lvl-0 agreement gate (Aq_agg/Ap_agg >= agree_gate_tau)
      5) optional 4-neigh erosion (erode_iters)
      6) CC + area filter

    Returns: (regions_dict, cand_map) if return_cand_map else regions_dict
    """
    import numpy as np
    try:
        import config
    except Exception:
        class _C: pass
        config = _C()

    # ---- helpers -------------------------------------------------------------
    def _resize_to_hw(a):
        a = np.asarray(a)
        if a.shape == (H, W): return a.astype(np.float32, copy=False)
        # minimal pad/crop fallback (NN-like) to avoid hard deps
        if a.shape[0] >= H and a.shape[1] >= W:
            return a[:H, :W].astype(np.float32, copy=False)
        pad_y = max(0, H - a.shape[0]); pad_x = max(0, W - a.shape[1])
        a2 = np.pad(a, ((0, pad_y), (0, pad_x)), mode="edge")
        return a2[:H, :W].astype(np.float32, copy=False)

    # ---- knobs ---------------------------------------------------------------
    if periodic is None:
        periodic = bool(getattr(config, "periodic_domain", True))
    if erode_iters is None:
        erode_iters = int(getattr(config, "detector_edge_erode", 0))

    # weight gate knob (can be auto if None)
    cfg_weight_tau = weight_tau if (weight_tau is not None) else getattr(config, "parent_weight_tau", None)

    # dynamic agree gate (runtime EMA if enabled)
    if agree_gate_tau is None:
        if runtime_ctx is not None and bool(getattr(config, "detector_agree_auto", False)):
            agree_gate_tau = getattr(getattr(runtime_ctx, "detector_state", None), "agree_gate_tau_eff", None)
        if agree_gate_tau is None:
            agree_gate_tau = getattr(config, "agree_gate_tau", None)

    alpha      = float(getattr(config, "blend_qp_alpha", 0.5))
    tau_q      = float(getattr(config, "tau_align_q", 0.45))
    tau_p      = float(getattr(config, "tau_align_p", 0.45))
    tau_blend  = alpha * tau_q + (1.0 - alpha) * tau_p
    mask_tau_mask = float(getattr(config, "detector_mask_tau", 1e-3))

    # ---- per-child evidence gather ------------------------------------------
    cover  = np.zeros((H, W), dtype=np.int32)    # number of active kids
    weight = np.zeros((H, W), dtype=np.float32)  # sum of child mask weights
    kid_act, kid_agree = [], []                  # per-child active mask & agreement

    for ch in children:
        m = np.asarray(getattr(ch, "mask", 0.0), np.float32)
        # activity (boolean) inside child mask/support
        act = child_activity_map(
            ch, H, W,
            mu_tau=float(getattr(config, "activity_mu_tau", 1e-3)),
            trsig_tau=float(getattr(config, "activity_trsig_tau", 1e-3)),
            eps=float(getattr(config, "eps", 1e-6)),
        )
        a = (m > mask_tau_mask) if (act is None) else np.asarray(act).astype(bool)

        cover  += a.astype(np.int32)
        weight += m * a.astype(np.float32)
        kid_act.append(a)

        # Prefer spawn caches: blended softmin KL -> agreement
        q = getattr(ch, "spawn_softmin_kl_q", None)
        p = getattr(ch, "spawn_softmin_kl_p", None)
        if q is None: q = getattr(ch, "cached_alignment_kl", None)
        if p is None: p = getattr(ch, "cached_model_alignment_kl", None)

        q = None if q is None else _resize_to_hw(q)
        p = None if p is None else _resize_to_hw(p)

        if q is None and p is None:
            # maybe child stored a ready-made agreement
            A_child = getattr(ch, "spawn_A_final", None)
            if A_child is not None:
                A_child = _resize_to_hw(A_child)
                kid_agree.append(np.clip(A_child, 0.0, 1.0))
            else:
                kid_agree.append(None)
            continue

        if q is None:
            kl_b = p;  tau_local = tau_p
        elif p is None:
            kl_b = q;  tau_local = tau_q
        else:
            kl_b = alpha * q + (1.0 - alpha) * p; tau_local = tau_blend

        # agreement for this child at each pixel
        A_child = np.exp(-np.asarray(kl_b, np.float32) / max(tau_local, 1e-8)).astype(np.float32)
        kid_agree.append(np.clip(A_child, 0.0, 1.0))

    # 1) require enough active kids
    keep = (cover >= int(min_kids))

    # 2) interior preference by mean weight
    mean_weight = np.zeros((H, W), dtype=np.float32)
    nz = cover > 0
    mean_weight[nz] = weight[nz] / cover[nz].astype(np.float32)

    if cfg_weight_tau is None:
        ww = mean_weight[(cover >= int(min_kids)) & (mean_weight > 0)]
        thr = float(np.percentile(ww, 60)) if ww.size else 0.0
    else:
        thr = float(cfg_weight_tau)
    keep &= (mean_weight >= thr)

    # 3) Local KL/Agreement gate (only if requested and we have any per-child evidence)
    if kl_tau is not None and any(A is not None for A in kid_agree):
        # aggregate child agreements only where child is active
        A_sum   = np.zeros((H, W), np.float32)
        A_count = np.zeros((H, W), np.int32)
        for a, A in zip(kid_act, kid_agree):
            if A is None:
                continue
            inside = a & np.isfinite(A)
            if inside.any():
                A_sum[inside]   += A[inside]
                A_count[inside] += 1

        A_mean = np.zeros((H, W), np.float32)
        validA = A_count > 0
        A_mean[validA] = A_sum[validA] / A_count[validA].astype(np.float32)
        A_mean = np.clip(A_mean, 0.0, 1.0)

        # Convert aggregated agreement to effective KL using blended τ
        KL_eff = np.full((H, W), np.inf, np.float32)
        KL_eff[validA] = -tau_blend * np.log(np.maximum(A_mean[validA], 1e-20)).astype(np.float32)
        keep &= (KL_eff <= float(kl_tau))

    # 4) Global agreement gate (uses step-level aggregates on runtime_ctx)
    if (agree_gate_tau is not None) and (runtime_ctx is not None):
        A_global = getattr(runtime_ctx, "Aq_agg", None)
        if A_global is None:
            A_global = getattr(runtime_ctx, "Ap_agg", None)
        if A_global is not None and A_global.shape == (H, W):
            keep &= (np.asarray(A_global, np.float32) >= float(agree_gate_tau))

    pre_px = int(np.asarray(keep).sum())
    core = keep.astype(bool)

    # 5) optional 4-neigh erosion (toroidal-safe)
    core = np.asarray(core, dtype=bool, order="C")
    if erode_iters > 0 and core.any():
        if periodic:
            for _ in range(erode_iters):
                e = core.copy()
                e &= np.roll(core,  1, axis=0)  # north
                e &= np.roll(core, -1, axis=0)  # south
                e &= np.roll(core,  1, axis=1)  # west
                e &= np.roll(core, -1, axis=1)  # east
                core = e
        else:
            for _ in range(erode_iters):
                north = np.pad(core[1:, :],  ((0,1),(0,0)), constant_values=False)
                south = np.pad(core[:-1, :], ((1,0),(0,0)), constant_values=False)
                west  = np.pad(core[:, 1:],  ((0,0),(0,1)), constant_values=False)
                east  = np.pad(core[:, :-1], ((0,0),(1,0)), constant_values=False)
                core = core & north & south & west & east

    post_px = int(core.sum())
    min_area_eff = int(min_area)

    # 6) Toroidal-aware CC
    from parent_utils import _label4
    labels = _label4(core, periodic=bool(periodic))
    nlab = int(labels.max())  # _label4 returns only the label image

    regions = {}
    rid = 0
    for lbl in range(1, nlab + 1):
        comp = (labels == lbl)
        area = int(comp.sum())
        if area < min_area_eff:
            continue
        regions[rid] = _make_region(comp.astype(np.float32), rid)
        rid += 1

    try:
        tau_repr = f"{thr:.3f}" if cfg_weight_tau is not None else f"auto->{thr:.3f}"
        print(f"[DETECT] regs={len(regions)} px_keep={pre_px} px_post={post_px} "
              f"min_area={min_area_eff} weight_tau={tau_repr} "
              f"cover_sum={int(cover.sum())} mean_w={float(np.nan_to_num(mean_weight).mean()):.3f}")
    except Exception:
        pass

    if not return_cand_map:
        return regions

    # candidate score map = union of region masks (float)
    cand_map = np.zeros((H, W), np.float32)
    for R in regions.values():
        cand_map = np.maximum(cand_map, np.asarray(R.mask, np.float32))
    return regions, cand_map


#move to update utils
# --- REPLACE old _detect_regions_pure with a wrapper around the minimal detector
def _detect_regions_pure(agents, params, ctx):
    H, W = np.asarray(agents[0].mask).shape[:2]
    detector_period = int(getattr(config, "detector_period", 1))
    if (ctx.global_step % detector_period) != 0:
        return {}, np.zeros((H, W), np.float32)

    # SAFE parse for optional KL threshold
    _emerge = getattr(config, "emerge_tau", 0.28)
    if (_emerge is None) or (isinstance(_emerge, str) and _emerge.strip().lower() in ("none", "off", "disabled", "")):
        kl_tau = None
    else:
        kl_tau = float(_emerge)

    regions, cand_map = detect_regions_minimal(
        agents, H=H, W=W,
        min_kids=int(getattr(config, "seed_min_kids", 2)),
        min_area=int(getattr(config, "emerge_min_area", 8)),
        kl_tau=kl_tau,
        weight_tau=getattr(config, "parent_weight_tau", 0.6),
        erode_iters=getattr(config, "detector_edge_erode", 0),
        runtime_ctx=ctx,
        agree_gate_tau=getattr(config, "agree_gate_tau", None),
        periodic=getattr(config, "periodic_domain", True),
        return_cand_map=True,
    )
    return regions, cand_map



# --- NEW: single, minimal detector -------------------------------------------

def _make_region(mask: np.ndarray, rid: int):
    """
    Construct a Region with whatever signature your project uses.
    Tries several common ctor shapes; falls back to a simple object.
    """
    area  = int((mask > 0).sum())
    state = getattr(config, "region_active_state", "active")  # or 1 / True, if your code uses enums

    # Try common constructor shapes
    attempts = [
        lambda: Region(id=rid, state=state, mask=mask, area=area),
        lambda: Region(id=rid, state=state, mask=mask),
        lambda: Region(rid, state, mask),           # positional
        lambda: Region(mask=mask),                  # legacy minimal
        lambda: Region(mask),                       # very old minimal
    ]
    for ctor in attempts:
        try:
            return ctor()
        except TypeError:
            pass

    # Fallback: lightweight object with the fields we need downstream
    class _R: pass
    R = _R()
    R.id = rid
    R.state = state
    R.mask = mask
    R.area = area
    return R




