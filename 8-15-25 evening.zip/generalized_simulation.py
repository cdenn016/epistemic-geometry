# generalized_simulation.py
import os
os.environ["OMP_NUM_THREADS"] = "1"
os.environ["MKL_NUM_THREADS"] = "1"
os.environ["NUMEXPR_NUM_THREADS"] = "1"
os.environ["OPENBLAS_NUM_THREADS"] = "1"

print("[THREADING] Thread limits set:")
for k in ("OMP_NUM_THREADS","MKL_NUM_THREADS","NUMEXPR_NUM_THREADS","OPENBLAS_NUM_THREADS"):
    print(f"  {k:>20} = {os.environ.get(k)}")

import sys, time, pickle
import numpy as np
import config
import shutil, os
from run_sim_utils import (
    prepare_generators, merge_logging_cfg, initialize_or_resume,
    attach_generators_to_agents, ensure_runtime, log_and_viz_after_step,
    checkpoint_step, wrap_epilogue, set_config_from_params
)
from generalized_io_utils import save_config_to_readme, save_step  # reused
from update_rules import synchronous_step


def run_simulation(
    outdir="checkpoints",
    resume=False,
    log_metrics=True,
    log_fields=False,
    num_cores=None,
    params=None,
    fresh_outdir=False,
    clear_agent_logs=True,
):
    
    # outdir rotation + readme
    if not resume and fresh_outdir and os.path.isdir(outdir):
        ts = time.strftime("%Y%m%d_%H%M%S")
        shutil.move(outdir, f"{outdir}_old_{ts}")
    os.makedirs(outdir, exist_ok=True)
    save_config_to_readme(outdir)

    # params + cores
    num_cores = 18 if num_cores is None else num_cores
    params = {} if params is None else dict(params)

    # generators
    G_q, G_p = prepare_generators(params)

    # logging cfg
    logcfg = merge_logging_cfg(params if isinstance(params, dict) else vars(config))
    if not log_metrics: logcfg["enable_scalar"] = True
    if not log_fields:  logcfg["enable_fields"] = False
    if logcfg.get("enable_fields", False):
        os.makedirs(os.path.join(outdir, logcfg["full_field_outdir"]), exist_ok=True)
    

    # init or resume
    agents, step_start = initialize_or_resume(outdir, resume, params, clear_agent_logs=clear_agent_logs)
    attach_generators_to_agents(agents, G_q, G_p)

    # runtime context (mounted lvl-1 view)
    runtime_ctx = ensure_runtime(params)
    runtime_ctx.global_step = step_start  # ← initialize

    # trackers
    parent_metrics, metric_log = [], []
    print(f"[RUN] Starting simulation at step {step_start} with {num_cores if (num_cores is not None) else 'auto'} cores")

    for step in range(step_start, config.steps):
        # keep global_step in sync BEFORE core update so gates use it
        runtime_ctx.global_step = step  # ← crucial for detector/growth/snapshot cadence

        print(f"\n[STEP {step}] -----------------------------")
        t0 = time.perf_counter()
        step_params = {**params, "step": step, "sanitize_strict_pre": False}

        # core synchronous update
        agents = synchronous_step(
            agents, G_q, G_p,
            params=step_params,
            n_jobs=num_cores,
            runtime_ctx=runtime_ctx,
        )
        runtime_ctx.persist_mounted_level()
        print(f"[TIMER] synchronous update: {time.perf_counter() - t0:.3f}s")

        # viz & metrics (this will now see up-to-date global_step)
        runtime_ctx.children_latest = agents
        log_and_viz_after_step(runtime_ctx, agents, step, outdir, params, logcfg,
                               parent_metrics, metric_log, num_cores)

        # checkpoint (clear caches per-agent, then save)
        for A in agents:
            if hasattr(A, "clear_omega_cache"):   A.clear_omega_cache()
            if hasattr(A, "clear_fisher_caches"): A.clear_fisher_caches()
        save_step(agents, outdir, step)
        print(f"[SAVE] Checkpoint --> {outdir}/step_{step:04d}.pkl")

    # epilogue
    wrap_epilogue(runtime_ctx, agents, outdir, parent_metrics, metric_log)
    print("[DONE] Simulation completed.")
    return agents, metric_log


if __name__ == "__main__":
    if len(sys.argv) > 1:
        with open(sys.argv[1], "rb") as f:
            param_override = pickle.load(f)
        set_config_from_params(param_override)
    else:
        param_override = {}

    # Prepare runtime generators for convenience CLI usage
    from get_generators import get_generators
    G_q, meta_q = get_generators(config.group_name, config.K_q, return_meta=True)
    G_p, meta_p = get_generators(config.group_name, config.K_p, return_meta=True)
    runtime_params = {"generators_q": G_q, "generators_p": G_p}

    run_simulation(
        outdir="checkpoints",
        resume=False,
        log_metrics=True,
        log_fields=False,
        params=runtime_params,
    )
