
from scipy.ndimage import laplace
from typing import Dict, List, Any


from generalized_omega import (
    exp_lie_algebra_irrep,
    batch_apply_omega,
    repair_if_forgotten_batch,
    compute_field_strength,
    build_inter_agent_omega
)
import numpy as np
import config
from joblib import Parallel, delayed

from IG_math_utils import (support_mask, kl_divergence_family, 
                           natural_gradient_norm, threshold_mask,
                           masked_mean, geodesic_distance,
                           compute_phi_laplacian_norm_field
                           
                           )


_DEFAULT_CUTOFF = getattr(config, "support_cutoff_eps", 1e-3)


def compute_coherence(phi: np.ndarray, mask: np.ndarray) -> float:
    # use the same threshold for boolean selection
    mask_bool = threshold_mask(mask)
    phis = phi[mask_bool]         # shape (n_points,)
    return np.abs(np.mean(np.exp(1j * phis)))


def compute_natural_gradient_norm_field(agents, i, mode="belief"):
    """
    Pointwise Fisher–Rao norm of the natural gradient for agent i.
    - mode="belief": uses dθ_q and q_fam.
    - mode="model" : uses dθ_p and p_fam.
    Returns an array shaped like agent.mask.
    """
    agent = agents[i]
    if mode == "belief":
        fam  = agent.q_fam
        grad = agent.last_gradients["dθ_q"]
    else:
        fam  = agent.p_fam
        grad = agent.last_gradients["dθ_p"]

    # natural_gradient_norm returns shape mask.shape
    field = natural_gradient_norm(fam, fam.theta, grad)
    # zero out outside support
    return field * (agent.mask > config.support_cutoff_eps)

def compute_avg_natural_gradient_norm(agent, mode="belief"):
    """
    Mean Fisher–Rao norm of the natural-gradient over the agent’s support.
    """
    # compute the pointwise field
    field = compute_natural_gradient_norm_field([agent], 0, mode)
    mask  = agent.mask > config.support_cutoff_eps
    vals  = field[mask]
    return float(vals.sum() / (mask.sum() or 1))


def compute_alignment_KL(
    agents: list,
    mode: str = "belief",          # "belief", "model", or "cross"
    support_eps: float = None,
    n_jobs: int = 1
) -> float:
    """
    Compute mean D_KL over overlapping pixels for:
      mode="belief":   D_KL[q_i || Ω_belief_i q_j]
      mode="model":    D_KL[p_i || Ω_model_i p_j]
      mode="cross":    D_KL[q_i || (Ω_belief_i (Ω_model_j)^{-1}) p_j]
    """

    if support_eps is None:
        support_eps = config.support_cutoff_eps

    def _pair(i: int, j: int):
        A_i, A_j = agents[i], agents[j]
        ov = support_mask(A_i.mask, support_eps) & support_mask(A_j.mask, support_eps)
        if not ov.any():
            return 0.0, 0

        # choose families and transports
        if mode == "belief":
            fam_i, fam_j = A_i.q_fam,    A_j.q_fam
            Ω_i, Ω_j_inv = A_i.Omega_belief,     A_j.Omega_belief_inv
        elif mode == "model":
            fam_i, fam_j = A_i.p_fam,    A_j.p_fam
            Ω_i, Ω_j_inv = A_i.Omega_model,      A_j.Omega_model_inv
        else:  # cross
            fam_i        = A_i.q_fam
            fam_j        = A_j.p_fam
            # cross‐transport
            Ω_i          = A_i.Omega_belief
            Ω_j_inv      = A_j.Omega_model_inv

        # build transport operator Ω_ij (or tildeΩ)
        Omega_ij = np.einsum('...ab,...bc->...ac', Ω_i, Ω_j_inv)

        # push_forward uses each family's own method
        fam_j_rot = fam_j.push_forward(Omega_ij)

        # get the pointwise KL‐field
        kl_field  = kl_divergence_family(fam_i, fam_j_rot)

        vals = kl_field[ov]
        return float(vals.sum()), int(ov.sum())

    # unique i<j neighbor pairs
    pairs = [
        (i, nb)
        for i, A in enumerate(agents)
        for nb in A.neighbors
        if nb > i
    ]

    # parallel execution
    results = Parallel(n_jobs=n_jobs, backend="threading")(
        delayed(_pair)(i, j) for i, j in pairs
    )

    total_kl   = sum(k for k, cnt in results)
    total_pts  = sum(cnt for k, cnt in results)
    return float(total_kl / (total_pts or 1))


def compute_alignment_KL_field(
    agents: list,
    i: int,
    j: int,
    mode: str = "belief",          # "belief", "model", or "cross"
    support_eps: float = None
) -> np.ndarray:
    """
    Pointwise D_KL field between agent i and j:
      - "belief":  D_KL[q_i || Ω_belief_i Ω_belief_j⁻¹ q_j]
      - "model":   D_KL[p_i || Ω_model_i  Ω_model_j⁻¹ p_j]
      - "cross":   D_KL[q_i || Ω_belief_i Ω_model_j⁻¹ p_j]
    Returns an array shaped like agents[i].mask, zeroed outside overlap.
    """
    if support_eps is None:
        support_eps = config.support_cutoff_eps

    A_i, A_j = agents[i], agents[j]
    # build overlap mask
    ov = support_mask(A_i.mask, support_eps) & support_mask(A_j.mask, support_eps)

    # pick families & transports
    if mode == "belief":
        fam_i, fam_j = A_i.q_fam,    A_j.q_fam
        Ω_i,   Ω_j_inv = A_i.Omega_belief,    A_j.Omega_belief_inv
    elif mode == "model":
        fam_i, fam_j = A_i.p_fam,    A_j.p_fam
        Ω_i,   Ω_j_inv = A_i.Omega_model,     A_j.Omega_model_inv
    else:  # cross
        fam_i = A_i.q_fam
        fam_j = A_j.p_fam
        # Φ_model = identity for now
        Ω_i, Ω_j_inv = A_i.Omega_belief, A_j.Omega_model_inv

    # build transport
    Omega_ij = np.einsum('...ab,...bc->...ac', Ω_i, Ω_j_inv)
    # push forward
    fam_j_rot = fam_j.push_forward(Omega_ij)
    # compute full field
    kl_field = kl_divergence_family(fam_i, fam_j_rot)
    # zero outside overlap
    return kl_field * ov



def compute_self_KL_field(
    agents: list,
    i: int,
    support_eps: float = None,
    apply_morphism: str = "none"  # one of "none", "belief", "model"
) -> np.ndarray:
    """
    Pointwise D_KL between each agent's q and p, optionally pushed through
    the Phi_belief or Phi_model morphism first.

    Parameters
    ----------
    agents : list of Agent
    i : index of the agent
    support_eps : float cutoff for support mask (defaults to config.support_cutoff_eps)
    apply_morphism : str
        "none"   : KL[q_i || p_i]
        "belief" : KL[ Φ_belief(q_i) || p_i ]
        "model"  : KL[ q_i || Φ_model(p_i) ]
    Returns
    -------
    kl_field : np.ndarray
      shape == agents[i].mask.shape
    """
    if support_eps is None:
        support_eps = config.support_cutoff_eps

    A = agents[i]
    # pick families, possibly after morphism
    if apply_morphism == "belief":
        # map q → p‐bundle
        fam_q = A.q_fam.push_forward(A.Phi_belief)
        fam_p = A.p_fam
    elif apply_morphism == "model":
        # map p → q‐bundle
        fam_q = A.q_fam
        fam_p = A.p_fam.push_forward(A.Phi_model)
    else:
        fam_q = A.q_fam
        fam_p = A.p_fam

    # compute raw KL field in the q‐bundle coordinates
    kl_field = kl_divergence_family(fam_q, fam_p)

    # mask outside support
    mask = support_mask(A.mask, support_eps)
    return kl_field * mask


def compute_avg_self_KL(
    agents: list,
    i: int,
    support_eps: float = None,
    apply_morphism: str = "none"
) -> float:
    """
    Scalar mean of D_KL[q_i||p_i] (with optional bundle‐morphism)
    over agent i’s support.
    """
    field = compute_self_KL_field(agents, i, support_eps, apply_morphism)
    mask  = support_mask(agents[i].mask, support_eps)
    return float(field[mask].sum() / (mask.sum() or 1))


def compute_avg_alignment_KL(
    agents: list,
    i: int,
    mode: str = "belief",
    support_eps: float = None
) -> float:
    """
    Scalar mean of D_KL between agent i and each neighbor j
    (mode="belief","model","cross"), averaged over supports.
    """
    if support_eps is None:
        support_eps = config.support_cutoff_eps

    sums, counts = 0.0, 0
    for nb in agents[i].neighbors:
        field = compute_alignment_KL_field(agents, i, nb, mode, support_eps)
        mask  = support_mask(agents[i].mask, support_eps)
        sums  += field[mask].sum()
        counts+= mask.sum()
    return float(sums / (counts or 1))


def compute_phi_norm_field(
    agent,
    phi_field: str = "phi_belief",
    mask_field: str = "mask",
    support_eps: float = None
) -> np.ndarray:
    """
    Pointwise ‖phi‖ field for a single agent.
    - phi_field: name of the attribute on agent, e.g. "phi_belief" or "phi_model".
    - mask_field: name of the support array on agent (usually "mask").
    - support_eps: threshold for support mask; defaults to config.support_cutoff_eps.
    Returns an array shaped like agent.mask.
    """
    if support_eps is None:
        support_eps = config.support_cutoff_eps

    phi = getattr(agent, phi_field)
    mask = support_mask(getattr(agent, mask_field), support_eps)

    # pointwise Euclidean norm over the last axis (the Lie‐algebra components)
    norm_field = np.linalg.norm(phi, axis=-1)

    # zero out outside support
    return norm_field * mask

def compute_avg_phi_norm(
    agents: list,
    phi_field: str = "phi_belief",
    mask_field: str = "mask",
    support_eps: float = None
) -> float:
    """
    For each agent, compute the mean of its ‖phi‖ field over support,
    then return the average of those means across all agents.
    """
    if support_eps is None:
        support_eps = config.support_cutoff_eps

    means = []
    for agent in agents:
        field = compute_phi_norm_field(agent, phi_field, mask_field, support_eps)
        # masked_mean will sum & divide by support count
        means.append(masked_mean(field, getattr(agent, mask_field), support_eps))
    return float(np.mean(means)) if means else 0.0


def compute_phi_delta_norm_field(
    agent,
    delta_phi_field: str = "delta_phi_belief",
    mask_field: str      = "mask",
    support_eps: float   = None
) -> np.ndarray:
    """
    Pointwise Euclidean norm of the agent’s delta‐phi update field,
    zeroed outside support.
    """
    if support_eps is None:
        support_eps = config.support_cutoff_eps

    delta = getattr(agent, delta_phi_field, None)
    mask  = getattr(agent, mask_field, None)
    if delta is None or mask is None:
        # no data → zero field
        return np.zeros_like(mask, dtype=float)

    # support mask
    m = support_mask(mask, support_eps)
    # pointwise norm over the Lie‐algebra fiber
    norm_field = np.linalg.norm(delta, axis=-1)
    return norm_field * m

def compute_max_phi_delta_norm(
    agents: list,
    delta_phi_field: str = "delta_phi_belief",
    mask_field: str      = "mask",
    support_eps: float   = None
) -> float:
    """
    Maximum pointwise update‐step norm across all agents and all support points.
    """
    if support_eps is None:
        support_eps = config.support_cutoff_eps

    max_vals = []
    for A in agents:
        field = compute_phi_delta_norm_field(A, delta_phi_field, mask_field, support_eps)
        if np.any(field):
            max_vals.append(field.max())
    return float(max(max_vals)) if max_vals else 0.0


def compute_entropy_field(agents: list, i: int, support_eps: float = None) -> np.ndarray:
    if support_eps is None:
        support_eps = config.support_cutoff_eps
    A = agents[i]
    ent = A.q_fam.entropy()           # pointwise array
    mask = support_mask(A.mask, support_eps)
    return ent * mask

def compute_avg_entropy(agent, support_eps: float = None) -> float:
    field = compute_entropy_field([agent], 0, support_eps)
    mask  = support_mask(agent.mask, support_eps)
    return float(masked_mean(field, agent.mask, support_eps))


def compute_transport_distance(
    agent_i,
    agent_j,
    mode: str = "belief",
    support_eps: float = None
) -> float:
    """
    Compute the average Fisher–Rao geodesic distance between agent_j’s family
    and its transport into agent_i’s frame, over their overlap.

    mode="belief":   use q_fam and Omega_belief  
    mode="model":    use p_fam and Omega_model  
    """
    if support_eps is None:
        support_eps = config.support_cutoff_eps

    # 1) overlap mask
    mask_i = support_mask(agent_i.mask, support_eps)
    mask_j = support_mask(agent_j.mask, support_eps)
    ov     = mask_i & mask_j
    if not ov.any():
        return 0.0

    # 2) pick the right bundle & transport
    if mode == "belief":
        fam   = agent_j.q_fam
        Ω_i   = agent_i.Omega_belief
        Ω_j_inv = agent_j.Omega_belief_inv
    else:
        fam   = agent_j.p_fam
        Ω_i   = agent_i.Omega_model
        Ω_j_inv = agent_j.Omega_model_inv

    # 3) build Ω_ij = Ω_i · Ω_j_inv
    Omega_ij = np.einsum('...ab,...bc->...ac', Ω_i, Ω_j_inv)

    # 4) push-forward j into i’s frame
    fam_j_rot = fam.push_forward(Omega_ij)

    # 5) compute pointwise geodesic distance
    #    geodesic_distance(...) returns an array shaped like mask
    d_field = geodesic_distance(fam, fam.theta, fam_j_rot.theta)

    # 6) average over overlap
    return masked_mean(d_field * ov, ov)

def compute_network_transport_distance(
    agents: list,
    mode: str = "belief",
    support_eps: float = None
) -> float:
    """
    Loop over all unique i<j pairs and average their transport distance.
    """
    if support_eps is None:
        support_eps = config.support_cutoff_eps

    vals = []
    N = len(agents)
    for i in range(N):
        for j in agents[i].neighbors:    # neighbors are integer indices
            if j <= i:
                continue
            vals.append(
                compute_transport_distance(
                    agents[i], agents[j],
                    mode        = mode,
                    support_eps = support_eps
                )
            )
    return float(np.mean(vals)) if vals else 0.0



def log_all_metrics_IG(
    agents: list,
    step: int,
    weights: dict | None = None,
    support_eps: float   = None,
    n_jobs: int          = 1
) -> dict:
    """
    Compute and log all IG metrics for each agent, then return a global summary.
    Metrics per agent:
      - self_KL        = ⟨D_KL[q||p]⟩
      - align_KL       = ⟨D_KL[q_i||Ω q_j]⟩ over neighbors
      - cross_belief   = ⟨D_KL[q_i||Ω_model Phi_model p_j]⟩
      - cross_model    = ⟨D_KL[p_i||Ω_belief Phi_belief q_j]⟩
      - phi_norm       = ⟨‖φ_belief‖⟩
      - phi_model_norm = ⟨‖φ_model‖⟩
      - delta_phi      = max ‖Δφ_belief‖
      - entropy        = ⟨H[q]⟩
      - transport_dist = ⟨geodesic_distance(q_j→i)⟩
    Then aggregates a “total_energy” as a weighted sum of these.
    """
    if support_eps is None:
        support_eps = config.support_cutoff_eps
        # at the top of log_all_metrics_IG, after loading config…
    w = weights or {
        # Self‐KL terms
        "self_KL":        config.alpha_belief,   # α_belief · D_KL(q‖p)
        "self_KL_model":  config.alpha_model,    # α_model · D_KL(p‖q)

        # Inter‐agent alignment
        "align_KL":       config.beta_belief,    # β_belief · D_KL(q_i‖Ω_belief q_j)
        "align_KL_model": config.beta_model,     # β_model  · D_KL(p_i‖Ω_model p_j)

        # Laplacian (gauge‐connection) penalties
        "laplacian_phi":      config.gamma_belief,   # γ_belief · ⟨‖Δφ_belief‖⟩
        "laplacian_phi_model":config.gamma_model,    # γ_model  · ⟨‖Δφ_model‖⟩

        # Mass‐terms on φ
        "mass_phi_belief":      config.mass_belief,    # m_belief · ⟨‖φ_belief‖²⟩
        "mass_phi_model":       config.mass_model,     # m_model  · ⟨‖φ_model‖²⟩

        # Cross‐coupling between φ_belief and φ_model
        "gauge_coupling":  config.gauge_coupling,  # e_belief·e_model or gauge_coupling · ⟨φ_b·φ_m⟩

    # Future bundle‐morphism KL: belief→model and model→belief
        "cross_belief":  config.cross_kl_belief_weight,  # D_KL(qᵢ‖Φ_model Ω̃ pⱼ)
        "cross_model":   config.cross_kl_model_weight,   # D_KL(pᵢ‖Φ_belief Ω qⱼ)

        # Curvature penalties on φ‐connections
        "curvature_phi":       config.curvature_belief,  # weight on curvature of φ_belief
        "curvature_phi_model": config.curvature_model,   # weight on curvature of φ_model

        # (optionally) reward or penalize entropy
        "entropy":        0.0,  # or set to +/– config.some_entropy_weight
    }


    N = len(agents)
    def _per_agent(i):
        A = agents[i]
        mask = support_mask(A.mask, support_eps)
        if not mask.any():
            return i, {}

    # 1) Self‐KL: D_KL(q||p) and D_KL(p||q)
        f_qp = compute_self_KL_field(agents, i, support_eps, apply_morphism="none")
        f_pq = compute_self_KL_field(agents, i, support_eps, apply_morphism="model")
        self_KL       = masked_mean(f_qp, mask)
        self_KL_model = masked_mean(f_pq, mask)

    # 2) Neighbor‐alignment KL (belief & model) and cross‐model KL
        align_vals       = []
        align_model_vals = []
        
        for j in A.neighbors:
        # belief alignment
            f_bel = compute_alignment_KL_field(agents, i, j, mode="belief", support_eps=support_eps)
            align_vals.append(masked_mean(f_bel, mask))
        # model alignment
            f_mod = compute_alignment_KL_field(agents, i, j, mode="model", support_eps=support_eps)
            align_model_vals.append(masked_mean(f_mod, mask))
        # cross‐model alignment
            # (placeholders) future bundle‐morphism KLs
            # f_cb = compute_morphism_KL_field(..., mode="belief_morphism")
            # f_cm = compute_morphism_KL_field(..., mode="model_morphism")
            # cross_belief_vals.append(masked_mean(f_cb, mask))
            # cross_model_vals.append(masked_mean(f_cm, mask))
            # for now, leave them empty (will be zero)

        align_KL       = float(np.mean(align_vals))       if align_vals else 0.0
        align_KL_model = float(np.mean(align_model_vals)) if align_model_vals else 0.0
        
        cross_belief = 0.0
        cross_model  = 0.0
    # 3) φ‐norms
        phi_belief_norm = masked_mean(compute_phi_norm_field(A, "phi_belief", "mask", support_eps), mask)
        phi_model_norm  = masked_mean(compute_phi_norm_field(A, "phi_model",  "mask", support_eps), mask)

    # 4) Δφ_belief max norm
        delta_phi_belief_norm = np.max(compute_phi_delta_norm_field(A, "delta_phi_belief", "mask", support_eps))

    # 5) Entropy
        ent_field = compute_entropy_field([A], 0, support_eps)
        entropy   = masked_mean(ent_field, mask)

    # 6) Transport distance (belief bundle)
        trans_vals = [
            compute_transport_distance(A, agents[j], mode="belief", support_eps=support_eps)
            for j in A.neighbors
            ]
        transport_dist = float(np.mean(trans_vals)) if trans_vals else 0.0

    # 7) Laplacian penalties
        lap_field_bel = compute_phi_laplacian_norm_field(agents, i, phi_field="phi_belief")
        lap_field_mod = compute_phi_laplacian_norm_field(agents, i, phi_field="phi_model")
        laplacian_phi       = masked_mean(lap_field_bel, mask)
        laplacian_phi_model = masked_mean(lap_field_mod, mask)

    # 8) Mass terms (⟨φ²⟩ over support)
        mass_phi_belief = masked_mean(A.phi_belief**2, mask)
        mass_phi_model  = masked_mean(A.phi_model **2, mask)
        
    # 9) Gauge‐coupling term: ⟨φ_belief · φ_model⟩
    # pointwise inner‐product coupling between φ_belief and φ_model
        bel = np.atleast_3d(A.phi_belief)
        mod = np.atleast_3d(A.phi_model)
        coupling_vals = np.sum(bel * mod, axis=-1)
        gauge_coupling_stat = masked_mean(coupling_vals, mask)

    # Assemble stats
        stats = {
            "self_KL":                self_KL,
            "self_KL_model":          self_KL_model,
            "align_KL":               align_KL,
            "align_KL_model":         align_KL_model,
            "cross_belief":           cross_belief,
            "cross_model":            cross_model,
            "phi_belief_norm":        phi_belief_norm,
            "phi_model_norm":         phi_model_norm,
            "delta_phi_belief_norm":  delta_phi_belief_norm,
            "entropy":                entropy,
            "transport_dist":         transport_dist,
            "laplacian_phi":          laplacian_phi,
            "laplacian_phi_model":    laplacian_phi_model,
            "mass_phi_belief":        mass_phi_belief,
            "mass_phi_model":         mass_phi_model,
            "gauge_coupling":         gauge_coupling_stat,
        }

        A.log_metrics(step, stats)
        return i, stats

    # run in parallel
    results = Parallel(n_jobs=n_jobs, backend="threading")(
        delayed(_per_agent)(i) for i in range(N)
    )

    # aggregate global summary
    accum = {k: 0.0 for k in w}
    for _, stats in results:
        for k, v in stats.items():
            accum[k] += w.get(k, 0.0) * v

    # normalize: divide additive energies by total support size,
    # divide averaged metrics by N as appropriate
    total_support = sum(int(support_mask(A.mask, support_eps).sum()) for A in agents) or 1
    summary = {"step": step}
    for k, val in accum.items():
        # self_KL, align_KL, cross_KL, phi_norm, phi_model, delta_phi, transport scale by support:
        if k in (
                "self_KL", "self_KL_model",
                "align_KL", "align_KL_model",
                "cross_belief", "cross_model",
                "transport_dist", "mass_phi_belief", "mass_phi_model",
                ):
    # support-normalized quantities
            summary[k] = val / total_support
        else:
            summary[k] = val / N


    # weighted total‐energy
    summary["total_energy"] = sum(accum.values()) / total_support

    return summary
