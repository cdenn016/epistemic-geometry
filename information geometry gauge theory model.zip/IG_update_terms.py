import numpy as np
import config

from generalized_math_utils import sanitize_q
from get_generators import get_generators
from transport_operator import compute_inter_agent_omega
from generalized_omega import batch_apply_omega, repair_if_forgotten_batch

from families import get_generators   # returns array shape (d, K, K)


def compute_self_gradient(
    agent_i,
    params: dict,
    mode: str = "q",                    # "q" for D_KL(q||p), "p" for D_KL(p||q)
    morphism: callable = None           # optional: (fam_other) -> ExponentialFamily
) -> np.ndarray:
    """
    Generic IG self-KL gradient:
      if mode=="q": grad w.r.t. θ_q of α·D_KL(q || p or morphism(p))
      if mode=="p": grad w.r.t. θ_p of α·D_KL(p || q or morphism(q))
      
    morphism: a function that takes the 'other' family and returns
              an ExponentialFamily in the same coordinates as the 'self' family.
    """
    α          = params.get("alpha", config.alpha)
    support_eps= params.get("support_cutoff_eps", config.support_cutoff_eps)

    # select which fibers we work on
    if mode == "q":
        fam_self, fam_other = agent_i.q_fam, agent_i.p_fam
    elif mode == "p":
        fam_self, fam_other = agent_i.p_fam, agent_i.q_fam
    else:
        raise ValueError(f"Unknown mode: {mode!r}, expected 'q' or 'p'")

    # optional morphism (e.g. bundle map)
    if morphism is not None:
        fam_other = morphism(fam_other)

    mask = agent_i.mask > support_eps
    if α <= 0 or not mask.any():
        return np.zeros_like(fam_self.theta)

    # expectation coords
    η_self  = fam_self.expectation  # (*domain, dim_theta)
    η_other = fam_other.expectation

    # gradient = α·(η_self - η_other)
    grad = α * (η_self - η_other)

    # zero outside support
    support = mask[..., None]
    grad *= support

    return grad


def compute_theta_gradient(agent_i, agents: list, params: dict, mode: str) -> np.ndarray:
    """
    Generic θ‐gradient for either belief‐ or model‐fibers.

    mode = "belief":
      ∇_{θ_q}[ α_belief·D_KL(q||p) + Σ_j β_belief·D_KL(q||Ωq_j) ]
    mode = "model":
      ∇_{θ_p}[ α_model·D_KL(p||q) + Σ_j β_model·D_KL(p||Ω̃p_j) ]
    """
    overlap_eps = params.get("support_cutoff_eps", config.support_cutoff_eps)

    if mode == "belief":
        fam_self   = agent_i.q_fam
        fam_other  = agent_i.p_fam
        α          = params.get("alpha_belief", config.alpha_belief)
        β          = params.get("beta_belief",  config.beta_belief)
        push_align = fam_self.push_forward_via_belief
    elif mode == "model":
        fam_self   = agent_i.p_fam
        fam_other  = agent_i.q_fam
        α          = params.get("alpha_model", config.alpha_model)
        β          = params.get("beta_model",  config.beta_model)
        push_align = fam_self.push_forward_model_via
    else:
        raise ValueError(f"Invalid mode: {mode!r}")

    mask = agent_i.mask > overlap_eps
    if not mask.any():
        return np.zeros_like(fam_self.theta)

    # 1) Self‐KL term
    grad = np.zeros_like(fam_self.theta)
    if α > 0:
        η_self  = fam_self.expectation
        η_other = fam_other.expectation
        grad_self = α * (η_self - η_other)
        grad += grad_self * mask[..., None]

    # 2) Neighbor‐alignment term
    if β > 0:
        η_self = fam_self.expectation
        nbs = max(len(agent_i.neighbors), 1)
        for j in agent_i.neighbors:
            nbr      = agents[j]
            transported = push_align(agent_i, nbr)
            η_nb     = transported.expectation
            grad += (β / nbs) * (η_self - η_nb) * mask[..., None]

    return grad


def compute_phi_gradient(agent_i, agents: list, params: dict, mode: str = "belief") -> np.ndarray:
    """
    Generic φ‐gradient for either φ_belief or φ_model.

    mode = "belief":
      Σ_j β_belief·D_KL(q||Ωq_j)
      + γ_belief·Δφ_belief
      + mass_belief·φ_belief
      + gauge_coupling·φ_model

    mode = "model":
      Σ_j β_model·D_KL(p||Ω̃p_j)
      + γ_model·Δφ_model
      + mass_model·φ_model
      + gauge_coupling·φ_belief
    """
    # Pick fields and params
    if mode == "belief":
        phi        = agent_i.phi_belief
        fam        = agent_i.q_fam
        β          = params.get("beta_belief",    config.beta_belief)
        γ          = params.get("gamma_belief",   config.gamma_belief)
        mass       = params.get("mass_belief",    config.mass_belief)
        push_fn    = fam.push_forward_via_belief
        other_phi  = agent_i.phi_model
    elif mode == "model":
        phi        = agent_i.phi_model
        fam        = agent_i.p_fam
        β          = params.get("beta_model",     config.beta_model)
        γ          = params.get("gamma_model",    config.gamma_model)
        mass       = params.get("mass_model",     config.mass_model)
        push_fn    = fam.push_forward_model_via
        other_phi  = agent_i.phi_belief
    else:
        raise ValueError(f"Unknown mode: {mode!r}")

    support_eps = params.get("support_cutoff_eps", config.support_cutoff_eps)
    coupling    = params.get("gauge_coupling",     config.gauge_coupling)

    mask = agent_i.mask > support_eps
    base = np.zeros_like(phi)
    if β > 0 and mask.any():
        # Precompute
        η_self   = fam.expectation
        Gs       = get_generators(config.group_name, fam.K)
        flat_mask= mask.ravel()
        η_flat   = η_self.reshape(-1, η_self.shape[-1])
        grad_flat= base.reshape(-1, base.shape[-1])

        # neighbor‐alignment
        nbs = max(len(agent_i.neighbors),1)
        for j in agent_i.neighbors:
            neigh = agents[j]
            transported = push_fn(agent_i, neigh)
            η_nb_flat = transported.expectation.reshape(-1, η_flat.shape[-1])
            Δη = η_flat - η_nb_flat

            stat_nb = transported.statistic_expectation_field.reshape(-1, η_flat.shape[-1])
            idxs    = np.nonzero(flat_mask)[0]
            if idxs.size == 0:
                continue

            for a, G in enumerate(Gs):
                Gs_stat = stat_nb[idxs] @ G.T
                contrib = (Δη[idxs] * Gs_stat).sum(axis=1)
                grad_flat[idxs, a] += (β / nbs) * contrib

        base = grad_flat.reshape(*base.shape)

    # Laplacian penalty
    if γ > 0:
        from ig_math_utils import laplacian_field
        base += γ * laplacian_field(phi)

    # Mass term φ^2
    if mass > 0:
        base += mass * phi

    # Cross‐coupling φ↔φ_model
    if coupling > 0:
        base += coupling * other_phi

    return base
