import numpy as np
import config
from scipy.integrate import simps




def laplacian_field(phi: np.ndarray) -> np.ndarray:
    """
    Compute the Laplacian Δφ on a 2D grid.
    If phi is 2D, returns a 2D array.
    If phi is 3D (last axis is components), applies laplace() along each component.
    """
    if phi.ndim == 2:
        return laplace(phi)
    # assume last axis is components
    comps = [laplace(phi[..., c]) for c in range(phi.shape[-1])]
    return np.stack(comps, axis=-1)


def compute_phi_laplacian_norm_field(agent, phi_field: str) -> np.ndarray:
    """
    Fetch `agent.<phi_field>` (shape (H, W) or (H, W, C)), compute its
    componentwise Laplacian, and return the Frobenius norm |Δφ| at each (x,y).
    """
    phi = getattr(agent, phi_field)
    lap = laplacian_field(phi)
    # if vector‐valued, Frobenius norm over the last axis
    if lap.ndim == 3:
        return np.linalg.norm(lap, axis=-1)
    # scalar field
    return np.abs(lap)


def support_mask(mask: np.ndarray, cutoff: float = None) -> np.ndarray:
    """
    Boolean mask where support > cutoff.
    If cutoff is None, uses config.support_cutoff_eps.
    """
    if cutoff is None:
        cutoff = config.support_cutoff_eps
    return mask > cutoff

def overlap_mask(mask_i: np.ndarray, mask_j: np.ndarray, cutoff: float = None) -> np.ndarray:
    """
    Boolean mask of the overlap region between two supports.
    """
    return support_mask(mask_i, cutoff) & support_mask(mask_j, cutoff)

def threshold_mask(mask: np.ndarray, cutoff: float = None) -> np.ndarray:
    """
    Alias for support_mask to produce a boolean mask.
    """
    return support_mask(mask, cutoff)

def masked_mean(field: np.ndarray, mask: np.ndarray, cutoff: float = None) -> float:
    """
    Compute the mean of `field` over those entries where mask > cutoff.
    If cutoff is None, uses config.support_cutoff_eps.
    """
    if cutoff is None:
        cutoff = config.support_cutoff_eps
    mask_bool = mask > cutoff
    values    = field[mask_bool]
    return float(values.sum() / (mask_bool.sum() or 1))

def kl_divergence_family(family_p, family_q):
    """
    Pointwise KL divergence D_KL[p||q] for two ExponentialFamily instances
    whose theta arrays have identical shapes:
      KL = A(θ_q) - A(θ_p) - ⟨θ_q - θ_p, η_p⟩
    """
    A_p = family_p.log_partition()
    A_q = family_q.log_partition()
    eta_p = family_p.grad_log_partition()
    delta_theta = family_q.theta - family_p.theta
    return A_q - A_p - np.sum(delta_theta * eta_p, axis=-1)

def fisher_information_matrix(family, theta=None):
    """
    Compute the Fisher information matrix I(θ) = ∇² A(θ).
    Uses an analytic Hessian if available, otherwise a finite-difference fallback.
    """
    if hasattr(family, 'hessian_log_partition'):
        return family.hessian_log_partition(theta or family.theta)

    thetas = theta if theta is not None else family.theta
    n = thetas.shape[-1]
    I = np.zeros(thetas.shape + (n,))
    eps = 1e-5
    for i in range(n):
        tf = thetas.copy()
        tb = thetas.copy()
        tf[..., i] += eps
        tb[..., i] -= eps
        grad_f = family.__class__(tf).grad_log_partition()
        grad_b = family.__class__(tb).grad_log_partition()
        I[..., i] = (grad_f - grad_b) / (2 * eps)
    return I

def natural_gradient(family, theta, grad):
    """
    Compute the natural gradient I(θ)^{-1} @ grad for each spatial location.
    """
    I = fisher_information_matrix(family, theta)
    return np.linalg.solve(I, grad)

def natural_gradient_norm(family, theta, grad):
    """
    Compute the Fisher–Rao norm of the natural gradient at each point:
      ||grad||_nat = sqrt( grad^T · I(θ)^{-1} · grad ).
    """
    nat = natural_gradient(family, theta, grad)
    return np.sqrt(np.sum(nat * grad, axis=-1))

def geodesic_distance(family, theta1: np.ndarray, theta2: np.ndarray, num_steps: int = 20) -> np.ndarray:
    """
    Approximate the Riemannian geodesic distance between theta1 and theta2
    under the Fisher metric:
      ∫₀¹ sqrt((Δθ)^T I(θ(t)) Δθ) dt
    along the straight line θ(t)=θ1 + t·Δθ.
    Returns an array of shape theta1.shape[:-1].
    """
    delta = theta2 - theta1
    ts = np.linspace(0, 1, num_steps)
    integrand = []
    for t in ts:
        θ_t = theta1 + t * delta
        I_t = fisher_information_matrix(family, θ_t)
        val = np.sqrt(np.einsum('...i,...ij,...j', delta, I_t, delta))
        integrand.append(val)
    integrand = np.stack(integrand, axis=0)
    return simps(integrand, ts, axis=0)





def even_range(min_val: int, max_val: int, num_samples: int) -> list[int]:
    """
    Return a list of `num_samples` evenly spaced even integers
    between `min_val` and `max_val`, inclusive if possible.
    """
    if min_val % 2 != 0:
        min_val += 1
    if max_val % 2 != 0:
        max_val -= 1
    lin = np.linspace(min_val, max_val, num_samples)
    evens = [int(round(x / 2) * 2) for x in lin]
    return sorted(set(evens))
