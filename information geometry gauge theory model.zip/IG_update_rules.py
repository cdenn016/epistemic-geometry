import numpy as np
import config
from joblib import Parallel, delayed
from typing import List, Dict, Any

from ig_agent_schema import Agent
from ig_update_terms import compute_theta_gradient, compute_phi_gradient
from ig_math_utils import laplacian_field
from spatial_utils import compute_curvature_field
from get_generators import get_generators


def synchronous_step(
    agents: List[Agent],
    params: Dict[str, Any] = None,
    n_jobs: int = 1
) -> List[Agent]:
    """
    One Euler step over all agents, with IG, Laplacian regularization, mass penalties,
    gauge coupling, and optional curvature-squared coupling:
      1) Clear phi caches
      2) Compute KL-based gradients in parallel
      3) Compute Laplacian, mass, gauge, and curvature regularizers for phi
      4) Update q_fam.theta, p_fam.theta, phi_belief, phi_model
      5) Store gradients and deltas for downstream metrics
    """
    params = params or {}

    # Load step sizes and regularization weights
    eta_q                = params.get('eta_q',              config.eta_q)
    eta_p                = params.get('eta_p',              config.eta_p)
    eta_phi_belief       = params.get('eta_phi_belief',     config.eta_phi_belief)
    eta_phi_model        = params.get('eta_phi_model',      config.eta_phi_model)
    gamma_belief         = params.get('gamma_belief',       config.gamma_belief)
    gamma_model          = params.get('gamma_model',        config.gamma_model)
    mass_belief          = params.get('mass_belief',        config.mass_belief)
    mass_model           = params.get('mass_model',         config.mass_model)
    gauge_coupling       = params.get('gauge_coupling',     config.gauge_coupling)
    curv_coupling_belief = params.get('curvature_belief',   config.curvature_belief)
    curv_coupling_model  = params.get('curvature_model',    config.curvature_model)

    N = len(agents)

    # 1) Clear φ caches so exp(phi) is recomputed next step
    for agent in agents:
        agent.clear_phi_cache()

    # 2) Compute KL-based gradients in parallel
    def _compute_grads(i: int):
        ag = agents[i]
        g_q       = compute_theta_gradient(ag, agents, params, mode="belief")
        g_p       = compute_theta_gradient(ag, agents, params, mode="model")
        g_phi     = compute_phi_gradient(ag, agents, params, mode="belief")
        g_phi_mod = compute_phi_gradient(ag, agents, params, mode="model")
        return g_q, g_p, g_phi, g_phi_mod

    results = Parallel(n_jobs=n_jobs)(delayed(_compute_grads)(i) for i in range(N))
    q_grads, p_grads, phi_grads, phi_model_grads = zip(*results)

    # 3 & 4) Apply updates synchronously, including all regularization
    # Need generators for curvature
    Gs = get_generators(config.group_name)
    for i, agent in enumerate(agents):
        g_q        = q_grads[i]
        g_p        = p_grads[i]
        g_phi      = phi_grads[i]
        g_phi_mod  = phi_model_grads[i]

        # Compute Laplacian of phi fields
        lap_bel = laplacian_field(agent.phi_belief)
        lap_mod = laplacian_field(agent.phi_model)

        # Compute mass gradients (penalty term ∝ φ)
        mass_grad_bel = agent.phi_belief
        mass_grad_mod = agent.phi_model

        # Compute gauge-coupling gradients (penalty term ∝ other φ)
        coupling_grad_bel = gauge_coupling * agent.phi_model
        coupling_grad_mod = gauge_coupling * agent.phi_belief

        # Compute curvature-squared gradients if coupling nonzero
        if curv_coupling_belief != 0:
            F_bel = compute_curvature_field(
                agents, i,
                phi_field='phi_belief',
                mask_field='mask',
                generators=Gs,
                support_cutoff_eps=params.get('support_cutoff_eps', config.support_cutoff_eps)
            )
            curvature_grad_bel = curv_coupling_belief * F_bel * agent.phi_belief
        else:
            curvature_grad_bel = 0
        if curv_coupling_model != 0:
            F_mod = compute_curvature_field(
                agents, i,
                phi_field='phi_model',
                mask_field='mask',
                generators=Gs,
                support_cutoff_eps=params.get('support_cutoff_eps', config.support_cutoff_eps)
            )
            curvature_grad_mod = curv_coupling_model * F_mod * agent.phi_model
        else:
            curvature_grad_mod = 0

        # Total φ gradients include KL term, Laplacian, mass, gauge coupling, and curvature coupling
        total_phi_grad       = (
            g_phi
            - gamma_belief * lap_bel
            - mass_belief  * mass_grad_bel
            - coupling_grad_bel
            - curvature_grad_bel
        )
        total_phi_model_grad = (
            g_phi_mod
            - gamma_model  * lap_mod
            - mass_model   * mass_grad_mod
            - coupling_grad_mod
            - curvature_grad_mod
        )

        # Store raw gradients and deltas for metrics
        agent.last_gradients = {
            'dθ_q': g_q,
            'dθ_p': g_p
        }
        agent.delta_phi_belief = eta_phi_belief * total_phi_grad
        agent.delta_phi_model  = eta_phi_model  * total_phi_model_grad

        # θ-space updates
        agent.q_fam.theta   -= eta_q * g_q
        agent.p_fam.theta   -= eta_p * g_p

        # φ updates with full regularization
        agent.phi_belief    += eta_phi_belief * total_phi_grad
        agent.phi_model     += eta_phi_model  * total_phi_model_grad

    return agents


def update_all(
    agents: List[Agent],
    params: Dict[str, Any] = None,
    n_jobs: int = 1
) -> List[Agent]:
    return synchronous_step(agents, params, n_jobs)
