# ig_agent_schema.py
from dataclasses import dataclass, field
from typing import Tuple, List, Dict, Any
from families import ExponentialFamily

import numpy as np
from find_agent_chains import find_spatial_paths  # your graph/path utilities

@dataclass
class Agent:
    """
    Information-Geometry Agent schema: holds compact exponential-family fibers
    and gauge phases for beliefs and models, plus spatial mask and topology.
    """
    id: int
    mask: np.ndarray                     # spatial support mask (bool or float)
    q_fam: "ExponentialFamily"         # belief fiber in natural-parameter space
    p_fam: "ExponentialFamily"         # model fiber in natural-parameter space
    phi_belief: np.ndarray               # gauge phase field for belief transport
    phi_model: np.ndarray                # gauge phase field for model transport
    center: Tuple[int, ...]              # spatial grid center
    radius: float                        # effective support radius
    neighbors: List[int]                 # list of neighbor agent IDs

    metrics_log: List[Dict[str, Any]] = field(default_factory=list)

    def log_metrics(self, step: int, stats: Dict[str, Any]) -> None:
        """
        Record diagnostic stats for this agent at a given step.
        """
        entry = {'step': step}
        entry.update(stats)
        self.metrics_log.append(entry)

    def clear_phi_cache(self) -> None:
        """
        Reset any cached exponentials of phi fields.
        """
        self._exp_phi_belief = None
        self._exp_phi_model = None

    @property
    def Omega_belief(self) -> np.ndarray:
        if getattr(self, '_exp_phi_belief', None) is None:
            self._exp_phi_belief = np.exp(self.phi_belief)
        return self._exp_phi_belief

    @property
    def Omega_belief_inv(self) -> np.ndarray:
        return np.linalg.inv(self.Omega_belief)

    @property
    def Omega_model(self) -> np.ndarray:
        if getattr(self, '_exp_phi_model', None) is None:
            self._exp_phi_model = np.exp(self.phi_model)
        return self._exp_phi_model

    @property
    def Omega_model_inv(self) -> np.ndarray:
        return np.linalg.inv(self.Omega_model)

    # --- Topology / spatial methods ---
    def is_neighbor(self, other: 'Agent', overlap_threshold: float = 1e-6) -> bool:
        """
        Return True if this agent overlaps with `other` by at least `overlap_threshold`.
        """
        overlap = np.sum(self.mask * other.mask)
        return overlap > overlap_threshold

    def overlap_region(self, other: 'Agent') -> np.ndarray:
        """
        Return the spatial mask of points where both agents' supports overlap.
        """
        return self.mask * other.mask

    def distance_to(self, other: 'Agent') -> float:
        """
        Euclidean distance between this agent's center and another's.
        """
        return float(np.linalg.norm(np.array(self.center) - np.array(other.center)))

    def find_spatial_paths(self, max_length=None) -> List[List[int]]:
        """
        Find all simple spatial paths within this agent's mask up to max_length.
        Returns a list of paths (lists of linear indices or coordinates).
        """
        # delegate to external utility, passing mask and length constraint
        return find_spatial_paths(self.mask, max_length)
