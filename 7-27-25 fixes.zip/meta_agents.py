# ────────────────────────
# Core + standard libraries
# ────────────────────────
import itertools as it
import json
from pathlib import Path
from copy import deepcopy

# ────────────────────────
# Scientific libraries
# ────────────────────────
import numpy as np
import matplotlib.pyplot as plt
from matplotlib import cm
import networkx as nx

# ────────────────────────
# Project configuration
# ────────────────────────
import config
from config import checkpoint_dir, group_name, K_q, K_p, log_eps, overlap_eps

# ────────────────────────
# IO + data handling
# ────────────────────────
from generalized_io_utils import (
    load_final_step,
    load_agents,
    save_generic_alignment_data,
    save_meta_agents,
    load_meta_agents,
    save_meta_labels,
    load_meta_data,
)

# ────────────────────────
# Core modules
# ────────────────────────
from get_generators import get_generators
from generalized_agent_schema import Agent
from agent_distributions import get_fiber_basis

# ────────────────────────
# Meta-agent diagnostics
# ────────────────────────
from meta_agent_utils import (
    
    compute_symmetric_kl_matrix,
    overlap_area_matrix,
    curvature_mean_per_agent,
    rank_agent_alignment,
    aggregate_fields,
    aggregate_mask,
    
)
from generalized_diagnostics_metrics import compute_pairwise_kl_belief, compute_pairwise_kl_model
from meta_agent_plots import (
    plot_matrix,
    plot_generic_alignment_network,
    plot_intra_kl_distribution,
    plot_inter_vs_intra,
    plot_cluster_order_parameters,
    plot_spatial_cluster_map,
    plot_curvature_heatmap,
)

from meta_agent_utils import (
    compute_cluster_kl_stats,
    compute_order_parameter,
    compute_cluster_order_parameters,
)
from natural_params_utils import mu_sigma_to_natural


def run_generic_alignment_analysis(
    agents,
    generators: dict,
    params: dict,
    mode: str = "belief",
    outdir: Path = None
):
    """
    Compute, cluster, plot, and save alignment diagnostics for either belief or model fields.

    Parameters
    ----------
    agents : list
        List of Agent objects.
    generators : dict
        Dict of Lie algebra generators: {"q": (d,K_q,K_q), "p": (d,K_p,K_p)}.
    params : dict
        Runtime parameters; expects 'log_eps', 'overlap_eps', etc.
    mode : str
        Either 'belief' or 'model' – determines which alignment metric to compute.
    outdir : Path, optional
        Directory to save results. Defaults to './alignment_output' or './model_alignment_output'.
    """
    assert mode in ("belief", "model"), f"[run_generic_alignment_analysis] Invalid mode: {mode}"
    outdir = Path(outdir) if outdir else Path("alignment_output" if mode == "belief" else "model_alignment_output")
    outdir.mkdir(parents=True, exist_ok=True)

    if mode == "belief":
        compute_kl = compute_pairwise_kl_belief
        generators_used = generators["q"]
        prefix = "kl"
        title = "Epistemic Alignment Network"
        matrix_title = "Pairwise Epistemic Misalignment"
    else:
        compute_kl = compute_pairwise_kl_model
        generators_used = generators["p"]
        prefix = "kl_model"
        title = "Model Alignment Network"
        matrix_title = "Pairwise Model Misalignment"

    # Step 1: KL divergence matrix
    kl_matrix = compute_kl(agents, generators_used, params)
    sym_kl = compute_symmetric_kl_matrix(kl_matrix)
    sym_kl = np.clip(sym_kl, 0.0, None)

    # Step 2: Auxiliary metrics
    overlap_A = overlap_area_matrix(agents, params.get("overlap_eps", 0.0))
    curv_mean = curvature_mean_per_agent(agents, generators_used)

    # Step 3: Meta-agent detection
    rankings = rank_agent_alignment(sym_kl)
    meta_list, labels, eps = find_meta_agents(sym_kl, overlap_A, curv_mean)
    print(f"[INFO] mode={mode}: adaptive ε = {eps:.3f}, meta_agents = {len(meta_list)}")

    # Step 4: Visualize KL matrix and network
    plot_matrix(sym_kl, outdir=outdir, label=f"D_KL({mode})", title=matrix_title, fname="kl_matrix.png")

    plot_generic_alignment_network(
        sym_kl, labels,
        threshold=eps,
        outpath=outdir / "alignment_network.png",
        title=f"{title} (ε={eps:.3f})"
    )

    # Step 5: Save alignment data
    save_generic_alignment_data(
        kl_matrix=sym_kl,
        rankings=rankings,
        labels=labels,
        outdir=outdir,
        prefix=prefix
    )

    print(f"[✓] {mode.capitalize()} alignment analysis completed → {outdir}/")
    return {
        "kl_matrix": sym_kl,
        "meta_agents": meta_list,
        "eps": eps,
        "labels": labels,
        "rankings": rankings,
    }



def find_meta_agents(
    sym_kl: np.ndarray,
    overlap_area: np.ndarray,
    curv_mean: np.ndarray,
    tau_A: float = 10,
    eta:   float = 10,
    tau_C: float = 10,
    verbose: bool = False
):
    """
    Identify meta-agent clusters using alignment, separation, and curvature criteria.

    Parameters
    ----------
    sym_kl : (N, N) np.ndarray
        Symmetric matrix of pairwise KL divergences D_KL(i || j).
    overlap_area : (N, N) np.ndarray
        Optional overlap matrix (not currently used, may be useful in future).
    curv_mean : (N,) np.ndarray
        Average curvature norm per agent, used to filter stable agents.
    tau_A : float, default=10
        Intra-cluster alignment threshold: mean intra-KL must be < tau_A.
    eta : float, default=10
        Separation factor: mean intra-KL must be < eta × extra-KL.
    tau_C : float, default=10
        Curvature threshold: mean agent curvature must be < tau_C.
    verbose : bool, default=False
        Print meta-cluster stats if True.

    Returns
    -------
    meta : list of lists[int]
        List of meta-agent clusters (each a list of agent indices).
    labels : np.ndarray of shape (N,)
        Cluster label per agent (−1 for unassigned).
    eps : float
        KL threshold used to construct the alignment graph.
    """
    N = sym_kl.shape[0]

    # ── 1. Adaptive KL threshold (30% quantile of finite values) ──
    finite = sym_kl[np.isfinite(sym_kl)]
    eps = np.quantile(finite, 0.30)
    min_eps = getattr(config, "epsilon_model", 1e-6)
    if eps < min_eps:
        eps = min_eps

    # ── 2. Build KL-based alignment graph (edges if KL ≤ ε) ──
    G = nx.Graph()
    G.add_nodes_from(range(N))
    for i, j in it.combinations(range(N), 2):
        d = sym_kl[i, j]
        if np.isfinite(d) and d <= eps:
            G.add_edge(i, j, weight=d)

    # ── 3. Extract components and filter by alignment and curvature ──
    meta = []
    for comp in nx.connected_components(G):
        C = list(comp)
        if len(C) < 2:
            continue  # skip singletons

        C_set = set(C)
        out_set = set(range(N)) - C_set

        # Mean intra-cluster KL
        intra_vals = sym_kl[np.ix_(C, C)]
        intra_vals = intra_vals[np.isfinite(intra_vals)]
        intra_mean = float(intra_vals.mean()) if intra_vals.size > 0 else np.inf

        # Mean extra-cluster KL
        extra_vals = sym_kl[np.ix_(C, list(out_set))]
        extra_vals = extra_vals[np.isfinite(extra_vals)]
        extra_mean = float(extra_vals.mean()) if extra_vals.size > 0 else np.inf

        # Mean curvature over this group
        curv_meanC = float(curv_mean[np.array(C)].mean())

        # ── Apply meta-agent acceptance criteria ──
        accept = False
        if extra_vals.size == 0:
            # No exterior agents — fallback to alignment + curvature
            if intra_mean < tau_A and curv_meanC < tau_C:
                accept = True
        else:
            # Full check: A, B, and C
            if (
                intra_mean < tau_A and
                intra_mean < eta * extra_mean and
                curv_meanC < tau_C
            ):
                accept = True

        if accept:
            meta.append(C)
            if verbose:
                print(f"[meta-cluster] size={len(C)}, "
                      f"<KL_intra>={intra_mean:.3f}, "
                      f"<KL_extra>={extra_mean:.3f}, "
                      f"<curv>={curv_meanC:.3f}")

    # ── 4. Label output (−1 for unassigned) ──
    labels = np.full(N, -1, dtype=int)
    for k, C in enumerate(meta):
        labels[np.array(C)] = k

    return meta, labels, eps


def build_meta_agents_from_clusters(agents, labels, generators, verbose=True):
    """
    Build coarse-grained meta-agents (as Agent objects) using information-geometric fields.

    Args:
        agents     : list of Agent objects
        labels     : np.ndarray of cluster labels (length N_agents, label ≥ 0 for valid)
        generators : dict of Lie algebra generators (used only for phi if needed later)
        verbose    : if True, prints cluster size and center

    Returns:
        List[Agent] : one new coarse-grained meta-agent per unique cluster label.
    """

    def get_meta_agent_adjacency(agents, labels, eps=1e-3):
        """
        Builds adjacency graph between meta-agents by checking original agent mask overlaps.

        Returns:
            adj       : (N_meta, N_meta) bool adjacency matrix
            label_map : {original label → meta-agent index}
        """
        labels = np.asarray(labels)
        unique = sorted(set(labels[labels >= 0]))
        label_map = {lab: i for i, lab in enumerate(unique)}

        n_meta = len(label_map)
        adj = np.zeros((n_meta, n_meta), dtype=bool)

        for i, ag_i in enumerate(agents):
            lab_i = labels[i]
            if lab_i < 0:
                continue
            for j, ag_j in enumerate(agents):
                lab_j = labels[j]
                if lab_j < 0 or lab_i == lab_j:
                    continue
                if np.any(ag_i.mask * ag_j.mask > eps):
                    a, b = label_map[lab_i], label_map[lab_j]
                    adj[a, b] = adj[b, a] = True
        return adj, label_map

    meta_agents = []
    unique_labels = sorted(set(labels))
    H, W, K = agents[0].mu_q_field.shape
    d = agents[0].phi.shape[-1]

    for lab in unique_labels:
        if lab < 0:
            continue
        idxs = np.where(labels == lab)[0]
        if len(idxs) == 0:
            continue

        sub = [agents[i] for i in idxs]

        # ── Aggregate fields ──
        mask     = aggregate_mask(sub)                     # (H, W)
        mu_q     = aggregate_fields(sub, "mu_q_field")     # (H, W, K)
        sigma_q  = aggregate_fields(sub, "sigma_q_field")  # (H, W, K, K)
        mu_p     = aggregate_fields(sub, "mu_p_field")
        sigma_p  = aggregate_fields(sub, "sigma_p_field")
        phi      = aggregate_fields(sub, "phi")
        phi_model= aggregate_fields(sub, "phi_model")

        # ── Symmetrize covariances BEFORE conversion ──
        sigma_q = 0.5 * (sigma_q + np.swapaxes(sigma_q, -1, -2))
        sigma_p = 0.5 * (sigma_p + np.swapaxes(sigma_p, -1, -2))

        # Optional: ensure positive-definiteness
        # sigma_q = sanitize_sigma(sigma_q)  

        # ── Convert to natural parameters ──
        eta1_q, eta2_q = mu_sigma_to_natural(mu_q, sigma_q)
        eta1_p, eta2_p = mu_sigma_to_natural(mu_p, sigma_p)

        # ── Compute center from mask mass ──
        inds = np.argwhere(mask > 0.5)
        center = tuple(np.round(np.mean(inds, axis=0)).astype(int)) if len(inds) else (H // 2, W // 2)

        # ── Construct meta-agent ──
        A = Agent(
            id                = int(lab),
            mask              = mask,
            eta1_q_field      = eta1_q,
            eta2_q_field      = eta2_q,
            eta1_p_field      = eta1_p,
            eta2_p_field      = eta2_p,
            phi               = phi,
            phi_model         = phi_model,
            center            = center,
            radius            = np.sqrt(np.sum(mask)),
            neighbors         = [],
        )

        meta_agents.append(A)

        if verbose:
            print(f"[meta-agent {lab}] from {len(sub)} agents, center={center}, radius={A.radius:.2f}")

    # ── Assign neighbors using original overlap ──
    adj, label_map = get_meta_agent_adjacency(agents, labels)
    for i, A in enumerate(meta_agents):
        A.neighbors = [meta_agents[j].id for j in range(len(meta_agents)) if adj[i, j]]

    return meta_agents



if __name__ == "__main__":
    BASEDIR = Path("meta_agent_analysis")
    BASEDIR.mkdir(exist_ok=True)

    # ──────────────────────────────────────────────────────────────
    # [1] Load original agents from checkpoint
    # ──────────────────────────────────────────────────────────────
    agents = load_final_step(checkpoint_dir)
    if agents is None:
        raise FileNotFoundError(f"No step_XXXX.pkl found in {checkpoint_dir}/")

    # Load both generator sets
    generators_q = get_generators(group_name, K_q)
    generators_p = get_generators(group_name, K_p)
    generators = {
        "q": generators_q,
        "p": generators_p
    }

    params = {
        "log_eps":     log_eps,
        "overlap_eps": overlap_eps
    }

    # ──────────────────────────────────────────────────────────────
    # [2] Run alignment diagnostics (belief and model)
    # ──────────────────────────────────────────────────────────────
    for mode in ["belief", "model"]:
        outdir = BASEDIR / f"{mode}_alignment_output"
        outdir.mkdir(exist_ok=True, parents=True)
        print(f"\n[INFO] Running alignment analysis for mode: {mode}")
        run_generic_alignment_analysis(agents, generators, params, mode, outdir=outdir)

    print("\n[✓] Alignment analyses complete.\n")

    # ──────────────────────────────────────────────────────────────
    # [3] Detect clusters + run condensation diagnostics
    # ──────────────────────────────────────────────────────────────
    for prefix, subfolder in [
        ("kl",       "belief_alignment_output"),
        ("kl_model", "model_alignment_output")
    ]:
        align_dir = BASEDIR / subfolder
        print(f"\n[INFO] Processing '{prefix}' clusters from '{align_dir}'")

        kl_matrix, labels, rankings = load_meta_data(str(align_dir), prefix)

        if len(labels) != len(agents):
            print(f"[ERROR] Label count {len(labels)} does not match agent count {len(agents)}")
            continue

        print(f"[INFO] Cluster label histogram: {np.bincount(labels[labels >= 0])}")

        stats = compute_cluster_kl_stats(kl_matrix, labels)
        R_global, σ_global = compute_order_parameter(kl_matrix)

        if not stats:
            print(f"[!] No clusters detected for {prefix}; skipping.")
            continue

        outdir = BASEDIR / "condensation_output" / prefix
        outdir.mkdir(exist_ok=True, parents=True)

        # Main condensation plots
        plot_intra_kl_distribution(stats, outpath=outdir / "intra_kl.png")
        plot_inter_vs_intra(stats, outpath=outdir / "inter_vs_intra.png")

        cluster_R = compute_cluster_order_parameters(kl_matrix, labels)
        plot_cluster_order_parameters(cluster_R, outpath=outdir / "cluster_order_params.png")
        plot_spatial_cluster_map(agents, labels, outpath=outdir / "spatial_clusters.png")

        # Use correct generators for curvature
        curvature_generators = generators_q if prefix == "kl" else generators_p
        plot_curvature_heatmap(agents, labels, curvature_generators, outpath=outdir / "curvature_heatmap.png")

        print(f"[✓] Spatial cluster map saved to: {outdir / 'spatial_clusters.png'}")
        print(f"[✓] Curvature heatmap saved to:   {outdir / 'curvature_heatmap.png'}")

        # ──────────────────────────────────────────────────────────────
        # [4] Save meta-agent fields + cluster labels (only once for 'kl')
        # ──────────────────────────────────────────────────────────────
        if prefix == "kl":
            meta_agents = build_meta_agents_from_clusters(agents, labels, generators_q)
            save_meta_agents(meta_agents, output_dir="meta_agent_analysis/meta_agent_fields")
            save_meta_labels(labels, path="meta_agent_analysis/meta_labels.csv")

    print("\n[✓] Meta-agent condensation diagnostics complete.")
    print("[✓] Meta-agents saved and ready for recursive simulation.")

