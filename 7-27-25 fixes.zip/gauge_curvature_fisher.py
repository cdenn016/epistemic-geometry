import numpy as np
import matplotlib.pyplot as plt
import os
from numpy.linalg import inv
from generalized_io_utils import load_all_checkpoints, load_latest_checkpoint  # From uploaded file
from get_generators import get_generators
from generalized_omega import compute_field_strength
import config



def compute_fisher_pullback_eta(eta1: np.ndarray, eta2: np.ndarray, eps=1e-8):
    """
    Compute pullback Fisher metric G_{μν}(c) from natural parameters.

    For a multivariate Gaussian:
        Fisher metric G = Σ⁻¹

    η₂ is the natural precision matrix (i.e. η₂ = Σ⁻¹),
    so we simply sanitize and return it.

    Args:
        eta1: (H, W, K)   — natural mean (unused here)
        eta2: (H, W, K, K) — natural precision
        eps: stabilizer

    Returns:
        G_field: (H, W, K, K) — pullback Fisher metric field
    """
    from natural_params_utils import sanitize_eta2
    return sanitize_eta2(eta2, eps=eps)

def compute_pullback_curl_eta(G_field: np.ndarray, dx: float = 1.0):
    """
    Compute ∇_{[μ} G_{ν]} — antisymmetric curl of pullback Fisher metric.

    Assumes central difference approximation and periodic boundary conditions.

    Args:
        G_field: (H, W, K, K)
        dx: grid spacing

    Returns:
        curl: (H, W, K, K) — antisymmetrized derivative of Fisher metric
    """
    dG_dx = (np.roll(G_field, -1, axis=0) - np.roll(G_field, 1, axis=0)) / (2 * dx)
    dG_dy = (np.roll(G_field, -1, axis=1) - np.roll(G_field, 1, axis=1)) / (2 * dx)
    return dG_dx - dG_dy  # antisymmetric ∇_x G_y - ∇_y G_x

def compare_curvature_to_pullback(F: np.ndarray, curl_G: np.ndarray):
    """
    Compare gauge curvature F and pullback curl ∇_{[μ} G_{ν]}.

    Args:
        F       : (H, W, K, K) — gauge curvature tensor
        curl_G  : (H, W, K, K) — antisymmetric Fisher curl

    Returns:
        norm_F         : (H, W) — Frobenius norm of F
        norm_curl_G    : (H, W) — Frobenius norm of curl G
        correlation    : float — Pearson correlation between flattened norms
    """
    norm_F = np.linalg.norm(F, ord="fro", axis=(-2, -1))         # (H, W)
    norm_curl_G = np.linalg.norm(curl_G, ord="fro", axis=(-2, -1))  # (H, W)

    norm_F_flat = norm_F.flatten()
    norm_curl_flat = norm_curl_G.flatten()

    # Remove NaNs/Infs for correlation
    mask = np.isfinite(norm_F_flat) & np.isfinite(norm_curl_flat)
    correlation = np.corrcoef(norm_F_flat[mask], norm_curl_flat[mask])[0, 1]

    return norm_F, norm_curl_G, correlation

def run_diagnostics(checkpoint_path, load_latest=True):
    """
    Run Fisher curvature diagnostic:
        - Loads checkpoint with η₁, η₂, φ
        - Computes pullback Fisher metric from η₂
        - Computes gauge curvature from φ
        - Compares ∇_[μ G_ν] vs F_{μν}
    """
    if load_latest:
        data = load_latest_checkpoint(checkpoint_path)
    else:
        data = load_all_checkpoints(checkpoint_path)

    # Load natural param fields
    eta1_q = data["eta1_q_field"]       # (H, W, K)
    eta2_q = data["eta2_q_field"]       # (H, W, K, K)
    phi    = data["phi_field"]          # (H, W, d)

    # Compute pullback Fisher metric
    G_pullback = compute_fisher_pullback_eta(eta1_q, eta2_q)      # (H, W, K, K)

    # Compute numerical curl of G
    curl_G = compute_pullback_curl_eta(G_pullback, dx=1.0)

    # Compute curvature from phi
    generators = get_generators(config.group_name, config.K_q)    # (d, K, K)
    F_field = compute_field_strength(phi, generators)["xy"]       # (H, W, K, K)

    # Compare norms and correlation
    norm_F, norm_curl_G, correlation = compare_curvature_to_pullback(F_field, curl_G)

    # Plot results
    plt.figure(figsize=(12, 6))

    plt.subplot(1, 2, 1)
    plt.imshow(norm_F, cmap='hot')
    plt.title("||F_{μν}||")
    plt.colorbar()

    plt.subplot(1, 2, 2)
    plt.imshow(norm_curl_G, cmap='hot')
    plt.title("||∇_{[μ} G_{ν]}||")
    plt.colorbar()

    plt.tight_layout()
    plt.show()

    print(f"[Fisher Curvature Diagnostic] Correlation = {correlation:.4f}")


# Run the diagnostics when this script is executed directly
if __name__ == "__main__":
    checkpoint_path = "checkpoints"  # Replace with the actual path
    run_diagnostics(checkpoint_path, load_latest=True)  # Set load_latest=True to use the latest checkpoint
