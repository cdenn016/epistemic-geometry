import numpy as np
from scipy.linalg import expm

from natural_params_utils import natural_to_mu_sigma, mu_sigma_to_natural

from get_generators import get_generators

import numpy as np
from numerical_utils import safe_inv, sanitize_sigma

def kl_divergence_natural_gaussians_pushforward(eta1_p, eta2_p, eta1_q, eta2_q, Phi, eps=1e-8):
    """
    Compute D_KL(p || Φ q) purely in natural parameter form.

    Args:
        eta1_p : (K_p,) or (..., K_p)
        eta2_p : (K_p,K_p) or (..., K_p,K_p)
        eta1_q : (K_q,) or (..., K_q)
        eta2_q : (K_q,K_q) or (..., K_q,K_q)
        Phi    : (K_p, K_q) or (..., K_p, K_q)

    Returns:
        Scalar KL divergence
    """
    # --- Pushforward q under Φ ---
    eta1_q_push = np.einsum("...ij,...j->...i", Phi, eta1_q)
    eta2_q_push = np.einsum("...ik,...kl,...jl->...ij", Phi, eta2_q, Phi)

    # Sanitize eta2 for inversion
    eta2_p = sanitize_sigma(eta2_p, eps=eps)
    eta2_q_push = sanitize_sigma(eta2_q_push, eps=eps)

    # Compute log partition function A(η)
    def logZ(eta1, eta2):
        eta2_inv = safe_inv(-2 * eta2, eps=eps)
        quad = np.einsum("...i,...ij,...j->...", eta1, eta2_inv, eta1)
        logdet = np.linalg.slogdet(-2 * eta2)[1]
        return 0.25 * quad - 0.5 * logdet

    A_q = logZ(eta1_q_push, eta2_q_push)
    A_p = logZ(eta1_p, eta2_p)

    # ∇A at p
    sigma_p = safe_inv(-2 * eta2_p, eps=eps)
    mu_p = np.einsum("...ij,...j->...i", sigma_p, eta1_p)

    grad_eta1_p = mu_p
    grad_eta2_p = -0.5 * (sigma_p + np.einsum("...i,...j->...ij", mu_p, mu_p))

    delta_eta1 = eta1_q_push - eta1_p
    delta_eta2 = eta2_q_push - eta2_p

    inner = (
        np.einsum("...i,...i->...", delta_eta1, grad_eta1_p)
        + np.einsum("...ij,...ij->...", delta_eta2, grad_eta2_p)
    )

    kl = A_q - A_p - inner
    return kl


def sample_eta(K):
    """Sample random natural parameters η₁, η₂ for a Gaussian."""
    mu = np.random.randn(K)
    A = np.random.randn(K, K)
    Sigma = A @ A.T + np.eye(K) * 1e-2
    eta1, eta2 = mu_sigma_to_natural(mu, Sigma)
    return eta1, eta2


from numerical_utils import sanitize_sigma

def gauge_transform_eta(eta1, eta2, rho, eps=1e-8):
    """
    Gauge transform η₁, η₂ using SL(2,R) irrep ρ, by transforming (μ, Σ) safely.
    """
    mu, sigma = natural_to_mu_sigma(eta1, eta2, eps=eps)
    mu_g = rho @ mu
    sigma_g = rho @ sigma @ rho.T
    sigma_g = sanitize_sigma(sigma_g, eps=1e-6)

    return mu_sigma_to_natural(mu_g, sigma_g, eps=eps)


def build_irrep(g, K):
    """
    Build the SL(2,R) irrep matrix ρ(g) = exp(g^a G_a) from Lie algebra coordinates.

    Args:
        g : (3,) Lie algebra vector [g_E, g_F, g_H]
        K : int, dimension of the SL(2,R) irrep (must be odd)

    Returns:
        rho : (K, K) matrix in SL(2,R)
    """
    G = get_generators("sl2r", K)  # shape (3, K, K)
    assert g.shape == (3,), f"Expected g.shape = (3,), got {g.shape}"

    lie_alg = g[0] * G[0] + g[1] * G[1] + g[2] * G[2]  # g^a G_a
    rho = expm(lie_alg)
    return rho


def check_kl_belief_alignment(K, g):
    """Check that KL(q_i || Ω q_j) is invariant under gauge transform with SL(2,R) irrep"""
    eta1_i, eta2_i = sample_eta(K)
    eta1_j, eta2_j = sample_eta(K)

    # Construct Ω = ρ(g_i) @ ρ(g_j)⁻¹
    rho = build_irrep(g, K)
    rho_inv = np.linalg.inv(rho)
    Omega = rho @ rho_inv.T  # effectively identity

    kl_orig = kl_divergence_natural_gaussians_pushforward(eta1_i, eta2_i, eta1_j, eta2_j, Omega)

    # Apply gauge to both q_i and q_j
    eta1_i_g, eta2_i_g = gauge_transform_eta(eta1_i, eta2_i, rho)
    eta1_j_g, eta2_j_g = gauge_transform_eta(eta1_j, eta2_j, rho)

    kl_gauge = kl_divergence_natural_gaussians_pushforward(eta1_i_g, eta2_i_g, eta1_j_g, eta2_j_g, Omega)

    print("==== Belief Alignment ====")
    print(f"KL(q_i || Ω q_j):        {kl_orig:.8f}")
    print(f"After gauge transform:   {kl_gauge:.8f}")
    print(f"Relative difference:     {abs(kl_orig - kl_gauge) / abs(kl_orig):.2e}")

def check_kl_model_alignment(K, g):
    """Check gauge invariance of KL(p || Φ·q) under SL(2,R) irrep conjugation"""
    eta1_q, eta2_q = sample_eta(K)
    eta1_p, eta2_p = sample_eta(K)
    Phi = np.random.randn(K, K)
    print("eta2 eigenvalues (before):", np.linalg.eigvalsh(eta2_q))
    

    rho = build_irrep(g, K)
    rho_inv = np.linalg.inv(rho)
    Phi_g = rho @ Phi @ rho_inv

    eta1_q_g, eta2_q_g = gauge_transform_eta(eta1_q, eta2_q, rho)
    print("eta2 eigenvalues (after):", np.linalg.eigvalsh(eta2_q_g))
    
    kl_orig = kl_divergence_natural_gaussians_pushforward(eta1_p, eta2_p, eta1_q, eta2_q, Phi)
    kl_gauge = kl_divergence_natural_gaussians_pushforward(eta1_p, eta2_p, eta1_q_g, eta2_q_g, Phi_g)

    print("\n==== Model Alignment ====")
    print(f"KL(p || Φ q):            {kl_orig:.8f}")
    print(f"After gauge transform:   {kl_gauge:.8f}")
    print(f"Relative difference:     {abs(kl_orig - kl_gauge) / abs(kl_orig):.2e}")

if __name__ == "__main__":
    K = 5
    g = np.random.randn(3)  # coefficients for SL(2,R) Lie algebra: a·H + b·E + c·F

    check_kl_belief_alignment(K, g)
    check_kl_model_alignment(K, g)
