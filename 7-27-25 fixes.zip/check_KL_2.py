# -*- coding: utf-8 -*-
"""
Created on Sat Jul 26 16:56:51 2025

@author: chris and christine
"""
import config
import numpy as np
from numerical_utils import sanitize_sigma, safe_inv, safe_logdet
from natural_params_utils import log_partition_function
from natural_params_utils import log_partition_function, natural_to_mu_sigma, mu_sigma_to_natural


from generalized_math_utils import kl_divergence

from natural_params_utils import natural_to_mu_sigma

def compute_projected_mu_sigma_from_mu_space(mu, sigma, morphism):
    morph_T = np.swapaxes(morphism, -1, -2)
    mu_proj = np.einsum("...ik,...k->...i", morph_T, mu)
    sigma_proj = np.einsum("...ik,...kl,...jl->...ij", morph_T, sigma, morph_T)
    return mu_proj, sigma_proj

def compute_projected_mu_sigma_from_eta_space(eta1, eta2, morphism):
    mu, sigma = natural_to_mu_sigma(eta1, eta2)
    return compute_projected_mu_sigma_from_mu_space(mu, sigma, morphism)


def compute_kl_projected_field_mu_sigma(
    mu_src, sigma_src,          # (..., K_src), (..., K_src, K_src)
    mu_tgt, sigma_tgt,          # (..., K_tgt), (..., K_tgt, K_tgt)
    morphism,                   # (..., K_tgt, K_src) — Φ or Φ̃
    mask,                       # (...,)
    direction="p_to_q",         # "p_to_q" for KL[q ‖ Φ̃·p], "q_to_p" for KL[p ‖ Φ·q]
    eps=1e-8
):
    """
    Compute per-point KL divergence between a source distribution
    and a morphism-projected target distribution using μ, Σ.
    """
    support = mask > config.support_cutoff_eps
    if not np.any(support):
        return np.zeros(mask.shape, dtype=np.float32)

    if direction == "q_to_p":
        mu_proj = np.einsum("...ik,...k->...i", morphism, mu_tgt)
        sigma_proj = np.einsum("...ik,...kl,...jl->...ij", morphism, sigma_tgt, morphism)

    elif direction == "p_to_q":
        morphism_T = np.swapaxes(morphism, -1, -2)
        mu_proj = np.einsum("...ki,...k->...i", morphism_T, mu_tgt)
        sigma_proj = np.einsum("...ki,...kl,...kj->...ij", morphism_T, sigma_tgt, morphism_T)

    else:
        raise ValueError("direction must be 'q_to_p' or 'p_to_q'")

    
    kl_vals = kl_divergence(
    mu_src[support], sigma_src[support],
    mu_proj[support], sigma_proj[support],
   )


    kl_field = np.zeros(mask.shape, dtype=np.float32)
    kl_field[support] = kl_vals
    return kl_field

def compute_kl_projected_field_eta(
    eta1_src, eta2_src,         # (..., K_src), (..., K_src, K_src)
    eta1_tgt, eta2_tgt,         # (..., K_tgt), (..., K_tgt, K_tgt)
    morphism,                   # (..., K_tgt, K_src)
    mask,                       # (...,)
    direction="p_to_q",         # "p_to_q" = KL[q ‖ Φ̃·p], "q_to_p" = KL[p ‖ Φ·q]
    eps=1e-8
):
    """
    Compute per-point KL divergence using η₁, η₂ inputs,
    by internally converting to μ, Σ and calling kl_gaussian().
    """
    from natural_params_utils import natural_to_mu_sigma
    from numerical_utils import sanitize_sigma
    from config import support_cutoff_eps

    H, W = mask.shape
    support = mask > support_cutoff_eps
    if not np.any(support):
        return np.zeros((H, W), dtype=np.float32)

    # Flatten and slice supported points
    eta1_src_flat = eta1_src.reshape(-1, eta1_src.shape[-1])[support.ravel()]
    eta2_src_flat = eta2_src.reshape(-1, eta2_src.shape[-2], eta2_src.shape[-1])[support.ravel()]
    eta1_tgt_flat = eta1_tgt.reshape(-1, eta1_tgt.shape[-1])[support.ravel()]
    eta2_tgt_flat = eta2_tgt.reshape(-1, eta2_tgt.shape[-2], eta2_tgt.shape[-1])[support.ravel()]
    morphism_flat = morphism.reshape(-1, morphism.shape[-2], morphism.shape[-1])[support.ravel()]

    # η → μ, Σ
    mu_src, sigma_src = natural_to_mu_sigma(eta1_src_flat, eta2_src_flat, eps)
    mu_tgt, sigma_tgt = natural_to_mu_sigma(eta1_tgt_flat, eta2_tgt_flat, eps)

    if direction == "p_to_q":
        morph_T = np.swapaxes(morphism_flat, -1, -2)
        mu_proj = np.einsum("...ik,...k->...i", morph_T, mu_tgt)
        sigma_proj = np.einsum("...ik,...kl,...jl->...ij", morph_T, sigma_tgt, morph_T)
    elif direction == "q_to_p":
        mu_proj = np.einsum("...ik,...k->...i", morphism_flat, mu_tgt)
        sigma_proj = np.einsum("...ik,...kl,...jl->...ij", morphism_flat, sigma_tgt, morphism_flat)
    else:
        raise ValueError("direction must be 'p_to_q' or 'q_to_p'")

    # Compute KL via Gaussian formula
    kl_vals = kl_divergence(mu_src, sigma_src, mu_proj, sigma_proj, eps=eps)

    # Write result to full grid
    kl_field = np.zeros((H * W,), dtype=np.float32)
    kl_field[support.ravel()] = kl_vals
    return kl_field.reshape(H, W)





from natural_params_utils import cov_from_natural, mean_from_natural

def natural_to_expectation(eta1, eta2, eps=1e-8):
    """
    Convert natural parameters (η₁, η₂) to expectation parameters (θ₁, θ₂)
    where:
      η₁ = Σ⁻¹ μ
      η₂ = -½ Σ⁻¹
    so:
      μ = Σ η₁
      θ₁ = μ
      θ₂ = μ μᵀ + Σ = E[xxᵀ]
    """
    mu = mean_from_natural(eta1, eta2, eps=eps)        # (..., K)
    sigma = cov_from_natural(eta1, eta2, eps=eps)       # (..., K, K)

    theta1 = mu
    theta2 = np.einsum("...i,...j->...ij", mu, mu) + sigma
    return theta1, theta2


# test_compare_kl_mu_sigma_vs_eta.py

import os
import numpy as np
import pickle
from pathlib import Path

import config

from natural_params_utils import mu_sigma_to_natural


# -*- coding: utf-8 -*-
"""
Compare KL[q || Φ̃·p] computed via (μ, Σ) and (η₁, η₂)

Created on Sat Jul 26 2025
@author: chris and christine
"""

import os
import numpy as np
import pickle
from pathlib import Path

import config


def load_agents_from_checkpoint(filepath):
    """
    Load agents from a checkpoint .pkl file.
    Assumes structure: {'agents': [...], ...}
    """
    with open(filepath, "rb") as f:
        data = pickle.load(f)
    if isinstance(data, dict) and "agents" in data:
        return data["agents"]
    return data  # fallback if checkpoint is a bare list

from natural_params_utils import (
    mu_sigma_to_natural, natural_to_mu_sigma
)

def check_roundtrip_consistency(mu_q, sigma_q, eta1_q, eta2_q):
    eta1_q_check, eta2_q_check = mu_sigma_to_natural(mu_q, sigma_q)
    mu_q_check, sigma_q_check = natural_to_mu_sigma(eta1_q, eta2_q)

    delta_eta1 = np.max(np.abs(eta1_q - eta1_q_check))
    delta_eta2 = np.max(np.abs(eta2_q - eta2_q_check))
    delta_mu   = np.max(np.abs(mu_q - mu_q_check))
    delta_sig  = np.max(np.abs(sigma_q - sigma_q_check))

    print("=== Internal Field Consistency ===")
    print(f"‖Δη₁_q‖ = {delta_eta1:.4e}")
    print(f"‖Δη₂_q‖ = {delta_eta2:.4e}")
    print(f"‖Δμ_q‖  = {delta_mu:.4e}")
    print(f"‖ΔΣ_q‖  = {delta_sig:.4e}")

from natural_params_utils import natural_to_mu_sigma

def compute_projected_mu_sigma_from_mu(mu, sigma, morphism):
    morph_T = np.swapaxes(morphism, -1, -2)
    mu_proj = np.einsum("...ik,...k->...i", morph_T, mu)
    sigma_proj = np.einsum("...ik,...kl,...jl->...ij", morph_T, sigma, morph_T)
    return mu_proj, sigma_proj

def check_projection_consistency(mu_p, sigma_p, eta1_p, eta2_p, morphism):
    mu_proj_mu, sigma_proj_mu = compute_projected_mu_sigma_from_mu(mu_p, sigma_p, morphism)
    mu_eta, sigma_eta = natural_to_mu_sigma(eta1_p, eta2_p)
    mu_proj_eta, sigma_proj_eta = compute_projected_mu_sigma_from_mu(mu_eta, sigma_eta, morphism)

    delta_mu_proj = np.max(np.abs(mu_proj_mu - mu_proj_eta))
    delta_sig_proj = np.max(np.abs(sigma_proj_mu - sigma_proj_eta))

    print("=== Projected μ, Σ Consistency ===")
    print(f"‖Δμ_proj‖ = {delta_mu_proj:.4e}")
    print(f"‖ΔΣ_proj‖ = {delta_sig_proj:.4e}")


from natural_params_utils import mu_sigma_to_natural

from natural_params_utils import natural_to_mu_sigma, mu_sigma_to_natural

def main():
    # Load agent from latest checkpoint
    checkpoint_dir = Path("checkpoints")
    ckpt_files = sorted(checkpoint_dir.glob("step_*.pkl"))
    if not ckpt_files:
        raise FileNotFoundError("No checkpoints found.")

    agents = load_agents_from_checkpoint(str(ckpt_files[-1]))
    agent = agents[0]

    # Use only η-fields (canonical simulation representation)
    eta1_q, eta2_q = agent.eta1_q_field, agent.eta2_q_field
    eta1_p, eta2_p = agent.eta1_p_field, agent.eta2_p_field
    morphism = agent.bundle_morphism_p_to_q
    mask = agent.mask

    # For μΣ-version, derive μ, Σ from η
    mu_q, sigma_q = natural_to_mu_sigma(eta1_q, eta2_q)
    mu_p, sigma_p = natural_to_mu_sigma(eta1_p, eta2_p)

    # Re-encode for perfect round-trip match
    eta1_q, eta2_q = mu_sigma_to_natural(mu_q, sigma_q)
    eta1_p, eta2_p = mu_sigma_to_natural(mu_p, sigma_p)

    # Consistency diagnostics (optional)
    check_roundtrip_consistency(mu_q, sigma_q, eta1_q, eta2_q)
    check_projection_consistency(mu_p, sigma_p, eta1_p, eta2_p, morphism)

    # KL via μΣ
    kl_mu_sigma = compute_kl_projected_field_mu_sigma(
        mu_q, sigma_q, mu_p, sigma_p, morphism, mask, direction="p_to_q"
    )

    # KL via η
    kl_eta = compute_kl_projected_field_eta(
        eta1_q, eta2_q, eta1_p, eta2_p, morphism, mask, direction="p_to_q"
    )

    # Compare
    diff = np.abs(kl_mu_sigma - kl_eta)
    max_diff = np.max(diff)
    mean_diff = np.mean(diff[mask > config.support_cutoff_eps])

    print("Comparison of KL[q || Φ̃·p]:")
    print(f"  Max ΔKL = {max_diff:.4e}")
    print(f"  Mean ΔKL = {mean_diff:.4e}")

    if max_diff > 1e-3:
        mismatch = np.where(diff > 1e-3)
        print(f"  Total mismatches over threshold 0.001: {len(mismatch[0])}")

if __name__ == "__main__":
    main()
