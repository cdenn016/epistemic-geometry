# -*- coding: utf-8 -*-
"""
Created on Wed Jul 23 09:23:50 2025

@author: chris and christine
"""
import numpy as np
import config
from joblib import Parallel, delayed
from numerical_utils import safe_inv
from get_generators import get_generators
from numerical_utils import sanitize_sigma
from generalized_omega import safe_bch_exact


def clip_gradient_field(grad_field, threshold=None, norm_type=2, verbose=False, label="∇φ"):
    """
    Optionally clips a gradient field to a maximum norm (global across all entries).

    Args:
        grad_field : (..., d) array of gradients
        threshold  : float or None — if None, no clipping is applied
        norm_type  : int or float — 1, 2, or np.inf
        verbose    : bool — print when clipping happens
        label      : str — name for diagnostics

    Returns:
        clipped gradient field of same shape
    """
    if threshold is None:
        return grad_field

    norm = np.linalg.norm(grad_field.ravel(), ord=norm_type)
    if norm > threshold:
        scale = threshold / (norm + 1e-12)
        if verbose:
            print(f"[Clipping {label}] norm {norm:.2e} → {threshold} (scale {scale:.2e})")
        return grad_field * scale
    return grad_field


def cache_fisher_inverse_morphisms(agent_i, eps=1e-8):
    agent_i.fisher_inv_phi_model = compute_inverse_fisher_field_natural(
        agent_i.bundle_morphism_q_to_p,
        agent_i.generators_q_to_p,
        eps=eps
    )
    agent_i.fisher_inv_phi = compute_inverse_fisher_field_natural(
        agent_i.bundle_morphism_p_to_q,
        agent_i.generators_p_to_q,
        eps=eps
    )

def compute_lie_metric(generators: np.ndarray):
    """
    Compute inner product matrix G_{ab} = Tr(G_aᵀ G_b) and its inverse.

    Args:
        generators: (d, K, K) basis of Lie algebra

    Returns:
        G: (d, d) inner product matrix
        G_inv: (d, d) inverse (with fallback)
    """
    d = generators.shape[0]
    G = np.einsum("aij,bij->ab", generators, generators)
    G = 0.5 * (G + G.T)  # symmetrize

    G_inv = safe_inv(G, eps=getattr(config, "eps", 1e-6))


    return G, G_inv



def compute_inverse_fisher_field_naturalold(eta2_field, generators, mask=None, eps=1e-8):
    """
    Compute Lie-algebra Fisher metric G_ab = 4 Tr[η₂ G^a η₂ G^b] without inversion.

    Args:
        eta2_field : (..., K, K)
        generators : (d, K, K)
        mask       : (...,) optional boolean mask
        eps        : stability

    Returns:
        G_field_inv : (..., d, d) inverse Fisher metric
    """
    H, W, K, _ = eta2_field.shape
    d = generators.shape[0]
    G_inv_field = np.zeros((H, W, d, d), dtype=eta2_field.dtype)
    eye_d = np.eye(d)

    eta2_flat = eta2_field.reshape(-1, K, K)
    G_flat = G_inv_field.reshape(-1, d, d)
    mask_flat = mask.reshape(-1) if mask is not None else np.ones((H * W,), dtype=bool)

    for i in range(len(eta2_flat)):
        if not mask_flat[i]:
            continue
        eta2 = eta2_flat[i]
        G_local = np.zeros((d, d), dtype=eta2.dtype)
        for a in range(d):
            G_a = generators[a]
            eta2_Ga = eta2 @ G_a
            for b in range(d):
                G_b = generators[b]
                G_local[a, b] = 4 * np.trace(eta2_Ga @ eta2 @ G_b)
        try:
            cond = np.linalg.cond(G_local)
            if not np.isfinite(cond) or cond > config.max_fisher_condition:
                raise np.linalg.LinAlgError
            G_flat[i] = np.linalg.inv(G_local + eps * eye_d)
        except np.linalg.LinAlgError:
            G_flat[i] = eye_d
            if config.debug:
                print(f"[WARN] eta2-based Fisher fallback at index {i}")

    return G_inv_field

def compute_inverse_fisher_field_natural(eta2_field, generators, mask=None, eps=1e-8):
    """
    Compute inverse Fisher metric G^{-1}_{ab} = [4 Tr(η₂ G^a η₂ G^b)]⁻¹ over space.

    Args:
        eta2_field : (H, W, K, K)
        generators : (d, K, K)
        mask       : (H, W) or None
        eps        : regularization epsilon

    Returns:
        G_inv_field : (H, W, d, d)
    """
    import config

    H, W, K, _ = eta2_field.shape
    d = generators.shape[0]
    G_inv_field = np.zeros((H, W, d, d), dtype=eta2_field.dtype)
    eye_d = np.eye(d, dtype=eta2_field.dtype)

    eta2_flat = eta2_field.reshape(-1, K, K)
    G_flat = G_inv_field.reshape(-1, d, d)

    if mask is not None:
        mask_flat = mask.reshape(-1)
        valid_idxs = np.flatnonzero(mask_flat)
    else:
        valid_idxs = np.arange(H * W)

    for i in valid_idxs:
        eta2 = eta2_flat[i]
        G_local = np.empty((d, d), dtype=eta2.dtype)

        for a in range(d):
            eta2_Ga = eta2 @ generators[a]
            for b in range(d):
                G_local[a, b] = 4 * np.trace(eta2_Ga @ eta2 @ generators[b])

        # SPD check + fallback
        try:
            cond = np.linalg.cond(G_local)
            if not np.isfinite(cond) or cond > config.max_fisher_condition:
                raise np.linalg.LinAlgError
            G_flat[i] = np.linalg.inv(G_local + eps * eye_d)
        except np.linalg.LinAlgError:
            G_flat[i] = eye_d
            if getattr(config, "debug_fisher", False):
                print(f"[FISHER] Inversion fallback at spatial index {i}")

    return G_inv_field


def compute_inverse_fisher_morphism_field(agent, generators, direction="q_to_p", eps=1e-8):
    """
    Return the rectangular Lie-algebra-projected inverse Fisher metric (H, W, d, d)
    for Φ or Φ̃ depending on direction, using natural parameters (η₁, η₂).
    """
    assert direction in {"q_to_p", "p_to_q"}

    if direction == "q_to_p":
        Phi     = agent.bundle_morphism_q_to_p
        eta1_q  = agent.eta1_q_field
        eta2_q  = agent.eta2_q_field
        eta2_p  = agent.eta2_p_field
    else:
        Phi     = agent.bundle_morphism_p_to_q
        eta1_q  = agent.eta1_p_field
        eta2_q  = agent.eta2_p_field
        eta2_p  = agent.eta2_q_field

    _, F_inv = compute_fisher_metric_rectangular_natural(
        Phi=Phi,
        eta1_q=eta1_q,
        eta2_q=eta2_q,
        eta2_p=eta2_p,
        generators=generators,
        eps=eps,
        return_inverse=True,
    )

    return F_inv



def compute_fisher_metric_rectangular_natural(
    Phi, eta1_q, eta2_q, eta2_p, generators, eps=1e-8, return_inverse=True
):
    """
    Compute rectangular Fisher metric for Φ: B_q → B_p using natural parameters η₁, η₂.

    Args:
        Phi        : (H, W, K_p, K_q) morphism field
        eta1_q     : (H, W, K_q)
        eta2_q     : (H, W, K_q, K_q)
        eta2_p     : (H, W, K_p, K_p)
        generators : (d, K_p, K_q) rectangular Lie algebra generators
        eps        : regularization constant
        return_inverse : if True, return inverse metric

    Returns:
        F     : (H, W, d, d) Fisher metric
        F_inv : (H, W, d, d) inverse Fisher metric (if requested)
    """
    H, W, K_p, K_q = Phi.shape
    d = generators.shape[0]
    eye_d = np.eye(d)

    F = np.zeros((H, W, d, d), dtype=Phi.dtype)

    # Invert η₂_q stably
    eta2_q_inv = np.linalg.inv(eta2_q + eps * np.eye(K_q)[None, None])
    mu_q = -0.5 * np.einsum("...ij,...j->...i", eta2_q_inv, eta1_q)

    # Precompute dμ and dΣ for each generator
    # Pushforward: dmu[a] = G_a @ mu_q → shape (..., K_p)
    dmu = np.einsum("akq,...q->...ak", generators, mu_q)  # (..., d, K_p)
    dSigma = []
    for a in range(d):
        G_a = generators[a]
        term1 = np.einsum("ij,...jk,...lk->...il", G_a, eta2_q_inv, Phi)
        G_a_T = G_a.T  # (K_q, K_q)
        B = np.einsum("...ij,...jk->...ik", eta2_q_inv, G_a_T)  # (..., K_q, K_q)
        term2 = np.einsum("...ij,...jk->...ik", Phi, B)         # (..., K_p, K_q)

        dSigma.append(-0.5 * (term1 + term2))
    dSigma = np.stack(dSigma, axis=0)  # (d, H, W, K_p, K_q)

    # Main Fisher computation
    for a in range(d):
        for b in range(d):
            v_a = dmu[..., a, :]  # (..., K_p)
            v_b = dmu[..., b, :]  # (..., K_p)
            v_a = v_a[..., None]  # (..., K_p, 1)
            v_b = v_b[..., None]  # (..., K_p, 1)
            tmp = np.matmul(eta2_p, v_b)  # (..., K_p, 1)
            t1 = np.einsum("...i,...i->...", v_a[..., 0], tmp[..., 0])

            tmp = np.einsum("...ik,...kl->...il", eta2_p, dSigma[b])
            tmp = np.einsum("...ij,...jk->...ik", dSigma[a], tmp)
            t2 = np.einsum("...ii->...", tmp)
            F[..., a, b] = t1 + 0.5 * t2

    # Regularization and inverse
    F += eps * eye_d[None, None]
    F_inv = np.linalg.inv(F) if return_inverse else None
    return F, F_inv

def compute_fisher_metric_rectangular_naturalfast(
    Phi, eta1_q, eta2_q, eta2_p, generators, eps=1e-8, return_inverse=True
):
    """
    Compute rectangular Fisher metric for Φ: B_q → B_p using natural parameters η₁, η₂.

    Args:
        Phi        : (H, W, K_p, K_q) morphism field
        eta1_q     : (H, W, K_q)
        eta2_q     : (H, W, K_q, K_q)
        eta2_p     : (H, W, K_p, K_p)
        generators : (d, K_p, K_q) rectangular Lie algebra generators
        eps        : regularization constant
        return_inverse : if True, return inverse metric

    Returns:
        F     : (H, W, d, d) Fisher metric
        F_inv : (H, W, d, d) inverse Fisher metric (if requested)
    """
    from numerical_utils import sanitize_sigma

    H, W, K_p, K_q = Phi.shape
    d = generators.shape[0]
    eye_d = np.eye(d)

    # Invert eta2_q and sanitize eta2_p
    eta2_q_inv = np.linalg.inv(eta2_q + eps * np.eye(K_q)[None, None])
    eta2_p = sanitize_sigma(eta2_p, eps=eps)

    # Compute μ_q = -½ η₂_q⁻¹ η₁_q
    mu_q = -0.5 * np.einsum("...ij,...j->...i", eta2_q_inv, eta1_q)

    # dμ_a = G_a ⋅ μ_q   → (..., d, K_p)
    dmu = np.einsum("akq,...q->...ak", generators, mu_q)  # (..., d, K_p)

    # dΣ_a = -½ ⋅ [ G_a η₂_q⁻¹ Φ + Φ η₂_q⁻¹ G_aᵀ ]   → (d, H, W, K_p, K_q)
    G = generators  # (d, K_p, K_q)
    G_T = np.swapaxes(G, -1, -2)  # (d, K_q, K_p)

    term1 = np.einsum("aij,...jk,...lk->a...il", G, eta2_q_inv, Phi)   # (d, H, W, K_p, K_q)
    term2 = np.einsum("aij,...jk,...lk->a...il", G_T, eta2_q_inv, Phi) # (d, H, W, K_p, K_q)
    dSigma = -0.5 * (term1 + term2)  # (d, H, W, K_p, K_q)

    # term1: Mahalanobis dμ^T Σ⁻¹ dμ = Tr(η₂_p ⋅ dμ_a^T ⋅ dμ_b)
    # dmu: (..., d, K_p), η₂_p: (..., K_p, K_p)
    v = np.einsum("...dk,...kl->...dl", dmu, eta2_p)   # (..., d, K_p)
    t1 = np.einsum("...di,...di->...d", v, dmu)        # (..., d)
    t1 = np.einsum("...a,...b->...ab", t1, t1)         # outer product (..., d, d)

    # term2: Trace(η₂_p ⋅ dΣ_a ⋅ dΣ_bᵀ)
    tmp = np.einsum("a...ij,...jk->a...ik", dSigma, eta2_p)     # (d, H, W, K_p, K_q)
    t2 = np.einsum("a...ij,b...ij->...ab", tmp, dSigma)         # (..., d, d)

    F = t1 + 0.5 * t2
    F += eps * eye_d[None, None]
    F = np.nan_to_num(F)

    if return_inverse:
        F_inv = np.linalg.inv(F)
        F_inv = np.nan_to_num(F_inv)
        return F, F_inv
    else:
        return F, None



def dexpinv_operator_morphism(Phi, grad_Phi, generators, fisher_inv_field=None, eps=1e-8):
    """
    Project Euclidean gradient ∂L/∂Φ ∈ R^{K_p × K_q} to Lie algebra coordinates 
    via inner product Tr[ ∂L/∂Φ · G^a ] for rectangular generators.

    Args:
        Phi               : (H, W, K_p, K_q) morphism field Φ : B_q → B_p
        grad_Phi          : (H, W, K_p, K_q) Euclidean gradient ∂L/∂Φ
        generators        : (d, K_p, K_q) rectangular generator basis
        fisher_inv_field  : (H, W, d, d) optional inverse Fisher metric
        eps               : numerical stabilizer

    Returns:
        grad_coords       : (H, W, d) gradient in Lie algebra coordinates
    """
    import numpy as np

    H, W, K_p, K_q = grad_Phi.shape
    d = generators.shape[0]

    # Sanity checks
    assert generators.shape == (d, K_p, K_q), f"Expected generators shape ({d},{K_p},{K_q}), got {generators.shape}"
    grad_coords = np.empty((H, W, d), dtype=grad_Phi.dtype)

    # Step 1: Project Euclidean gradient onto Lie generators
    for a in range(d):
        G_a = generators[a]
        grad_coords[..., a] = np.einsum("...ij,ij->...", grad_Phi, G_a)

    # Step 2: Apply inverse Fisher metric (optional)
    if fisher_inv_field is not None:
        # Safety check
        if fisher_inv_field.shape != (H, W, d, d):
            raise ValueError(
                f"Fisher shape mismatch: expected ({H},{W},{d},{d}), got {fisher_inv_field.shape}"
            )

        # Sanitize Fisher inverse in case it's degenerate
        
        fisher_inv_field = sanitize_sigma(fisher_inv_field, eps=eps)

        # Contract: (..., d, d) × (..., d) → (..., d)
        grad_coords = np.einsum("...ab,...b->...a", fisher_inv_field, grad_coords)

    # Step 3: Clamp extreme values (optional, diagnostic)
    if getattr(config, "debug_gradients", False):
        max_norm = np.linalg.norm(grad_coords, axis=-1).max()
        print(f"[DEBUG] Natural morphism grad max-norm: {max_norm:.2e}")

    return np.nan_to_num(grad_coords)



def dexpinv_operator(phi, delta, generators, order=None, use_exact=None):
    """
    Applies exact inverse of exp pushforward:
        dexpinv(phi, delta) ∈ 𝔤

    Uses:
        bch_exact(exp(φ), exp(δ)) - φ → projected back into 𝔤

    Args:
        phi     : (..., d) current Lie-algebra coords
        delta   : (..., d) Lie-algebra variation
        generators: (d, K, K) basis of Lie algebra

    Returns:
        corrected_delta: (..., d)
    """
    H, W, d = phi.shape
    corrected = np.zeros_like(delta)

    # Matrix form: φ, Δ ∈ 𝔤
    phi_mat   = np.einsum("...a,akl->...kl", phi, generators)
    delta_mat = np.einsum("...a,akl->...kl", delta, generators)

    composed = np.zeros_like(phi_mat)
    for i in range(H):
        for j in range(W):
            A = phi_mat[i, j]
            B = delta_mat[i, j]
            C = safe_bch_exact(A, B)  # full BCH or logm
            composed[i, j] = C - A

    # Project back: δ_corrected^a = Tr[(C - A) · G^a]
    for a in range(d):
        G = generators[a]
        corrected[..., a] = 2.0 * np.einsum("...ij,ij->...", composed, G)

    return corrected


def dexpinv_operator_covariance(phi, delta_sigma, generators, transpose=False):
    """
    Applies exact dexpinv operator to ∂L/∂Σ through transported covariance Ω Σ Ωᵀ.
    Projects gradient back into Lie-algebra coordinates via generator basis.

    Args:
        phi         : (H, W, d)  current φ field
        delta_sigma : (H, W, K, K) ∂KL/∂Σ_transport
        generators  : (d, K, K)
        transpose   : whether to apply dummy transpose (not used in practice)

    Returns:
        corrected_grad: (H, W, d)
    """
    H, W, d = phi.shape
    corrected = np.zeros((H, W, d), dtype=phi.dtype)

    # Construct φ matrix at each (i, j)
    phi_mat = np.einsum("...a,akl->...kl", phi, generators)

    for i in range(H):
        for j in range(W):
            A = phi_mat[i, j]
            dΣ = delta_sigma[i, j]

            # Use exact backprop: log(exp(A) @ exp(dΣ)) - A
            B = safe_bch_exact(A, dΣ)
            C = B - A

            for a in range(d):
                G = generators[a]
                corrected[i, j, a] += 2.0 * np.trace(C @ G)

    if transpose:
        corrected = np.swapaxes(corrected, -1, -1)  # no-op, kept for legacy compat

    return corrected

def compute_fisher_geometry_gradient(agent_i, agents, params, field="phi"):
    """
    Compute ∇_{φ} or ∇_{φ̃} for Fisher geometry preservation:
        ∇‖Gᵢ − Ωᵢⱼ Gⱼ Ωᵢⱼᵀ‖²
    where G = Σ⁻¹ = -2 η₂.
    Supports field="phi" (beliefs) or "phi_model" (models).
    """
    if field == "phi":
        phi = agent_i.phi
        eta2_q = agent_i.eta2_q_field
        exp_phi = agent_i._exp_phi
        exp_neg_phi_j_name = "_exp_neg_phi"
        eta2_field_name = "eta2_q_field"
        fisher_weight = params.get("fisher_geometry_weight", config.fisher_geometry_weight)
    else:
        phi = agent_i.phi_model
        eta2_q = agent_i.eta2_p_field
        exp_phi = agent_i._exp_phi_model
        exp_neg_phi_j_name = "_exp_neg_phi_model"
        eta2_field_name = "eta2_p_field"
        fisher_weight = params.get("fisher_model_geometry_weight", config.fisher_model_geometry_weight)

    if fisher_weight <= 0:
        return np.zeros_like(phi)

    Gs = get_generators(config.group_name, config.K)
    d, K = Gs.shape[0], Gs.shape[1]
    mask_i = agent_i.mask > config.support_cutoff_eps
    if not np.any(mask_i):
        return np.zeros_like(phi)

    grad = np.zeros_like(phi)
    flat_self_mask = mask_i.reshape(-1)
    exp_phi_i = exp_phi.reshape(-1, K, K)
    G_i = (-2.0 * eta2_q).reshape(-1, K, K)

    for nb in agent_i.neighbors:
        agent_j = agents[nb["id"]]
        mask_j = agent_j.mask > config.support_cutoff_eps
        overlap = mask_i & mask_j
        if not np.any(overlap):
            continue

        flat_idxs = overlap.reshape(-1)

        # G_j = -2 * η2_qj
        eta2_q_j = getattr(agent_j, eta2_field_name).reshape(-1, K, K)[flat_idxs]
        G_j = -2.0 * eta2_q_j
        exp_neg_phi_j = getattr(agent_j, exp_neg_phi_j_name).reshape(-1, K, K)[flat_idxs]

        Omega = np.einsum("mij,mjk->mik", exp_phi_i[flat_idxs], exp_neg_phi_j)
        G_j_rot = np.einsum("mik,mkl,mjl->mij", Omega, G_j, Omega)  # Ω G Ωᵀ
        Delta = G_i[flat_idxs] - G_j_rot

        for a in range(d):
            Ga = Gs[a]
            dΩ = np.einsum("ij,mjk->mik", Ga, Omega)
            term1 = np.einsum("mik,mkl,mjl->mij", dΩ, G_j, Omega)
            term2 = np.einsum("mik,mkl,mjl->mij", Omega, G_j, dΩ)
            dG_rot = term1 + term2
            dL = 2 * np.einsum("mij,mij->m", Delta, dG_rot)
            grad.reshape(-1, d)[flat_idxs, a] += dL

    grad *= fisher_weight
    grad[~mask_i] = 0.0
    return grad

