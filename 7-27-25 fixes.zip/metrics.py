# -*- coding: utf-8 -*-
"""
Created on Fri Jul 25 10:19:37 2025

@author: chris and christine
"""
import config
import numpy as np
from natural_params_utils import natural_to_mu_sigma_batch
from numerical_utils import sanitize_sigma, safe_logdet



from pathlib import Path
# Standard library
import os
# Third-party libraries
import numpy as np
from generalized_omega import (exp_lie_algebra_irrep, batch_apply_omega,
                              compute_field_strength)
from get_generators import get_generators 
from joblib import Parallel, delayed

import config
from pathlib import Path

from generalized_math_utils import kl_divergence, laplacian_field  # ← make sure this is imported
from mask_utils import (
    get_support_mask,
    get_overlap_mask,
    expand_mask_for_mu,
    expand_mask_for_sigma,
    apply_mask_mu,
    apply_mask_sigma,
    apply_mask_phi,
    norm_over_mask,
    masked_norm,
    threshold_mask
)
from bundle_morphism_utils import safe_batch_apply_morphism_nat
from generalized_omega import batch_apply_omega, compute_inter_omega_fieldwise, compute_field_strength



from numerical_utils import sanitize_sigma, sanitize_eta2, safe_transport_eta2
from update_rules import preprocess_agent_fields
from natural_params_utils import mean_from_natural, log_partition_function, cov_from_natural

def grad_log_partition(eta1, eta2, eps=1e-8):
    """
    Return ∇A(η) = (μ, Σ + μμᵀ)
    without computing μ, Σ directly.
    But since Σ = ∇²A(η), we need μ anyway.
    """
    mu = mean_from_natural(eta1, eta2, eps=eps)
    Sigma = cov_from_natural(eta1, eta2, eps=eps)
    theta1 = mu
    theta2 = Sigma + np.einsum("...i,...j->...ij", mu, mu)
    return (theta1, theta2)



def kl_divergence_natural_projected_p_to_qqq(
    eta1_q, eta2_q,
    eta1_p, eta2_p,
    Phi_tilde,
    mask=None,
    eps=1e-8
):
    eta2_q = sanitize_eta2(eta2_q, eps=eps)
    eta2_p = sanitize_eta2(eta2_p, eps=eps)

    # Project p to q space
    eta1_proj = np.einsum("...ik,...k->...i", Phi_tilde, eta1_p)
    eta2_proj = np.einsum("...ik,...kl,...jl->...ij", Phi_tilde, eta2_p, Phi_tilde)
    eta2_proj = 0.5 * (eta2_proj + np.swapaxes(eta2_proj, -1, -2))

    # Compute θ = ∇A(η)
    theta1_q, theta2_q = grad_log_partition(eta1_q, eta2_q, eps)
    theta1_proj, theta2_proj = grad_log_partition(eta1_proj, eta2_proj, eps)

    # ⟨η_q, θ_q − θ_proj⟩
    delta_theta1 = theta1_q - theta1_proj
    delta_theta2 = theta2_q - theta2_proj
    inner1 = np.einsum("...i,...i->...", eta1_q, delta_theta1)
    inner2 = np.einsum("...ij,...ji->...", eta2_q, delta_theta2)

    A_q = log_partition_function(eta1_q, eta2_q, eps)
    A_proj = log_partition_function(eta1_proj, eta2_proj, eps)

    kl = inner1 + inner2 - A_q + A_proj
    return np.where(mask > 0, kl, 0.0) if mask is not None else kl



def kl_divergence_natural_projected_p_to_q(
    eta1_q, eta2_q,             # (..., K_q), (..., K_q, K_q)
    eta1_proj, eta2_proj,       # (..., K_q), (..., K_q, K_q)
    eps=1e-8,
    mask=None
):
    """
    Compute KL[q || Φ̃·p] in fully natural parameter space:
        D_KL = ⟨η_q, ∇A(η_q) - ∇A(η_proj)⟩ - A(η_q) + A(η_proj)
    """
    eta2_q     = sanitize_eta2(eta2_q, eps=eps)
    eta2_proj  = sanitize_eta2(eta2_proj, eps=eps)

    theta_q    = grad_log_partition(eta1_q, eta2_q, eps=eps)
    theta_proj = grad_log_partition(eta1_proj, eta2_proj, eps=eps)

    # Inner product: ⟨η_q, θ_q - θ_proj⟩
    dtheta1 = theta_q[0] - theta_proj[0]   # (..., K)
    dtheta2 = theta_q[1] - theta_proj[1]   # (..., K, K)

    inner1 = np.einsum("...i,...i->...", eta1_q, dtheta1)
    inner2 = np.einsum("...ij,...ji->...", eta2_q, dtheta2)
    inner = inner1 + inner2

    A_q    = log_partition_function(eta1_q, eta2_q, eps=eps)
    A_proj = log_partition_function(eta1_proj, eta2_proj, eps=eps)

    kl = inner - A_q + A_proj
    return np.where(mask > 0, kl, 0.0) if mask is not None else kl


def compute_alignment_field_general(
    agents, i, field_type="belief",
    eps=config.support_cutoff_eps,
    log_eps=config.log_eps
) -> np.ndarray:
    """
    Compute spatial KL field KL[q_i(c) || Ω_ij · q_j(c)] for agent i using natural parameters.

    Returns:
        (H, W) array — per-pixel average KL divergence field over overlaps
    """
    A = agents[i]
    mask_i = threshold_mask(A.mask, eps)
    if not np.any(mask_i) or not A.neighbors:
        return np.zeros_like(A.mask, dtype=np.float32)

    H, W = A.mask.shape
    kl_accum = np.zeros((H, W), dtype=np.float32)
    n_nb_at = np.zeros((H, W), dtype=np.int32)

    if field_type == "belief":
        eta1_i = A.eta1_q_field
        eta2_i = sanitize_eta2(A.eta2_q_field, eps)
        phi_i  = A.phi
        K      = config.K_q
    elif field_type == "model":
        eta1_i = A.eta1_p_field
        eta2_i = sanitize_eta2(A.eta2_p_field, eps)
        phi_i  = A.phi_model
        K      = config.K_p
    else:
        raise ValueError(f"[compute_alignment_field] Invalid field_type: '{field_type}'")

    generators = get_generators(config.group_name, K)

    for nb in A.neighbors:
        B = agents[nb["id"]]
        mask_j = threshold_mask(B.mask, eps)
        overlap = mask_i & mask_j
        if not np.any(overlap):
            continue

        idx = np.argwhere(overlap)
        i_idx, j_idx = idx[:, 0], idx[:, 1]

        eta1_j = B.eta1_q_field if field_type == "belief" else B.eta1_p_field
        eta2_j = sanitize_eta2(
            B.eta2_q_field if field_type == "belief" else B.eta2_p_field, eps
        )
        phi_j = B.phi if field_type == "belief" else B.phi_model

        # Gather overlapping points
        eta1_i_pts = eta1_i[overlap]
        eta2_i_pts = eta2_i[overlap]
        eta1_j_pts = eta1_j[overlap]
        eta2_j_pts = eta2_j[overlap]

        # Gauge transport: Ω = exp(φ_i) @ exp(−φ_j)
        O_i     = exp_lie_algebra_irrep(phi_i[overlap], generators)    # (..., K, K)
        O_j_inv = exp_lie_algebra_irrep(-phi_j[overlap], generators)   # (..., K, K)
        Omega   = np.einsum("mab,mbc->mac", O_i, O_j_inv)

        # Pushforward: η₁' = Ω η₁,   η₂' = Ω η₂ Ωᵀ
        eta1_j_t = np.einsum("mab,mb->ma", Omega, eta1_j_pts)
        eta2_j_t = safe_transport_eta2(eta2_j_pts, Omega, eps=log_eps, clip_trace=20.0)

        # Log-partitions
        A_i = log_partition_function(eta1_i_pts, eta2_i_pts, eps=log_eps)
        A_j = log_partition_function(eta1_j_t, eta2_j_t, eps=log_eps)

        # Gradients of A give θ = E[t(x)]
        theta1_i, theta2_i = grad_log_partition(eta1_i_pts, eta2_i_pts, eps=log_eps)
        theta1_j, theta2_j = grad_log_partition(eta1_j_t, eta2_j_t, eps=log_eps)

        delta_theta1 = theta1_i - theta1_j
        delta_theta2 = theta2_i - theta2_j

        inner_prod = (
            np.einsum("...i,...i->...", eta1_i_pts, delta_theta1)
          + np.einsum("...ij,...ij->...", eta2_i_pts, delta_theta2)
        )

        kl_vals = inner_prod - A_i + A_j
        kl_vals = np.nan_to_num(kl_vals, nan=0.0, posinf=0.0, neginf=0.0)
        kl_vals = np.clip(kl_vals, 0.0, 1e6)

        np.add.at(kl_accum, (i_idx, j_idx), kl_vals)
        np.add.at(n_nb_at, (i_idx, j_idx), 1)

    out = np.zeros_like(kl_accum, dtype=np.float32)
    valid = n_nb_at > 0
    out[valid] = kl_accum[valid] / n_nb_at[valid]
    return out * mask_i

def compute_pairwise_kl_field(agents, generators, params, field_type="belief", return_pointwise=False):
    """
    Compute KL[q_i || Ω_ij · q_j] or KL[p_i || Ω_ij · p_j] using natural parameters for all (i, j) pairs.

    Args:
        agents           : list of Agent objects
        generators       : (d, K, K) Lie algebra basis for the group irrep
        params           : dict with 'log_eps', 'overlap_eps', and 'group_name'
        field_type       : either "belief" or "model"
        return_pointwise : if True, returns full per-point KL maps

    Returns:
        kl_matrix        : (N, N)
        pointwise        : (optional) {(i,j): KL_field}
    """
    log_eps = params.get("log_eps", 1e-8)
    eps     = params.get("overlap_eps", 1e-6)
    group   = params.get("group_name", "sl2r")

    N = len(agents)
    kl_matrix = np.full((N, N), np.nan)
    pointwise = {} if return_pointwise else None

    for i, A in enumerate(agents):
        mask_i = A.mask > eps
        if not np.any(mask_i):
            continue

        if field_type == "belief":
            eta1_i = A.eta1_q_field
            eta2_i = sanitize_eta2(A.eta2_q_field, eps)
            phi_i  = A.phi
        elif field_type == "model":
            eta1_i = A.eta1_p_field
            eta2_i = sanitize_eta2(A.eta2_p_field, eps)
            phi_i  = A.phi_model
        else:
            raise ValueError(f"[KL Field] Invalid field_type: '{field_type}'")

        for j, B in enumerate(agents):
            if i == j:
                kl_matrix[i, j] = 0.0
                continue

            mask_j = B.mask > eps
            if not np.any(mask_j):
                continue

            overlap = mask_i & mask_j
            if not np.any(overlap):
                continue

            if field_type == "belief":
                eta1_j = B.eta1_q_field
                eta2_j = sanitize_eta2(B.eta2_q_field, eps)
                phi_j  = B.phi
            else:
                eta1_j = B.eta1_p_field
                eta2_j = sanitize_eta2(B.eta2_p_field, eps)
                phi_j  = B.phi_model

            eta1_i_pts = eta1_i[overlap]
            eta2_i_pts = eta2_i[overlap]
            eta1_j_pts = eta1_j[overlap]
            eta2_j_pts = eta2_j[overlap]
            phi_i_pts  = phi_i[overlap]
            phi_j_pts  = phi_j[overlap]

            Omega_ij = compute_inter_omega_fieldwise(phi_i_pts, phi_j_pts, generators, group_name=group)
            eta1_j_t = np.einsum("mab,mb->ma", Omega_ij, eta1_j_pts)
            eta2_j_t = safe_transport_eta2(eta2_j_pts, Omega_ij, eps=log_eps, clip_trace=20.0)

            A_i = log_partition_function(eta1_i_pts, eta2_i_pts, eps=log_eps)
            A_j = log_partition_function(eta1_j_t, eta2_j_t, eps=log_eps)

            θ1_i, θ2_i = grad_log_partition(eta1_i_pts, eta2_i_pts, eps=log_eps)
            θ1_j, θ2_j = grad_log_partition(eta1_j_t, eta2_j_t, eps=log_eps)

            delta_θ1 = θ1_i - θ1_j
            delta_θ2 = θ2_i - θ2_j

            inner = (
                np.einsum("...i,...i->...", eta1_i_pts, delta_θ1) +
                np.einsum("...ij,...ij->...", eta2_i_pts, delta_θ2)
            )

            kl_vals = inner - A_i + A_j
            kl_vals = np.nan_to_num(kl_vals, nan=0.0, posinf=0.0, neginf=0.0)
            kl_vals = np.clip(kl_vals, 0.0, 1e6)

            mean_kl = float(np.mean(kl_vals))
            kl_matrix[i, j] = mean_kl if np.isfinite(mean_kl) else 0.0

            if return_pointwise:
                pw_field = np.zeros_like(mask_i, dtype=np.float32)
                pw_field[overlap] = kl_vals
                pointwise[(i, j)] = pw_field

    return (kl_matrix, pointwise) if return_pointwise else kl_matrix



def compute_entropy_field(eta2_field, mask, log_eps=1e-8):
    """
    Compute per-cell entropy H[q(c)] using natural parameter η₂ = −½ Σ⁻¹

    Args:
        eta2_field : (H, W, K, K) — second natural parameter η₂
        mask       : (H, W) — boolean or float mask
        log_eps    : float — stabilizer

    Returns:
        H_field    : (H, W) — entropy values, 0 outside mask
    """
    H, W, K, _ = eta2_field.shape
    H_field = np.zeros((H, W), dtype=np.float64)

    # Compute log det(−2η₂) = log det(Sigma⁻¹)
    neg2_eta2 = -2.0 * eta2_field
    neg2_eta2 += log_eps * np.eye(K)[None, None, :, :]  # Stabilize

    for i in range(H):
        for j in range(W):
            if not mask[i, j]:
                continue
            try:
                sign, logdet = safe_logdet(neg2_eta2[i, j])
                if not np.isfinite(logdet) or sign <= 0:
                    raise np.linalg.LinAlgError
            except np.linalg.LinAlgError:
                logdet = np.nan
            H_field[i, j] = 0.5 * (K * np.log(2 * np.pi * np.e) + logdet)

    H_field[~mask] = 0.0
    return H_field

from metrics import compute_kl_projected_field_natural

def compute_self_energy(agent, log_eps, cfg):
    """
    Compute KL(q_i || Φ̃ · p_i) as a spatial field using natural parameter morphism projection.
    """
    return cfg["alpha"] * compute_kl_projected_field_natural(
        eta1_src = agent.eta1_q_field,
        eta2_src = agent.eta2_q_field,
        eta1_tgt = agent.eta1_p_field,
        eta2_tgt = agent.eta2_p_field,
        morphism = agent.bundle_morphism_p_to_q,
        mask     = agent.mask,
        direction = "p_to_q",
        eps = log_eps
    )

def compute_feedback_energy(agent, log_eps, cfg):
    """
    Compute KL(p_i || Φ · q_i) as a spatial field using natural parameter morphism projection.
    """
    return cfg["feedback_weight"] * compute_kl_projected_field_natural(
        eta1_src = agent.eta1_p_field,
        eta2_src = agent.eta2_p_field,
        eta1_tgt = agent.eta1_q_field,
        eta2_tgt = agent.eta2_q_field,
        morphism = agent.bundle_morphism_q_to_p,
        mask     = agent.mask,
        direction = "q_to_p",
        eps = log_eps
    )

def compute_curvature_energy_field(phi_field, mask, weight, lie_gens, support_eps=1e-4, debug=False):
    """
    Compute curvature energy: weight × ∑_x Tr[F_{μν}(x)^2] over valid mask.

    Args:
        phi_field   : (H, W, d)     — φ or φ_model field in Lie algebra coords
        mask        : (H, W)        — agent support mask
        weight      : float         — energy weight coefficient
        lie_gens    : (d, K, K)     — Lie algebra generators
        support_eps : float         — minimum support threshold
        debug       : bool          — optional print/debug info

    Returns:
        energy      : float         — weighted curvature energy
        raw_total   : float         — ∑ Tr[F²] over support (unweighted)
    """
    F_dict = compute_field_strength(phi_field, lie_gens)  # dict of F_xy, F_yz, etc.
    support = mask > support_eps

    total = 0.0
    for key, val in F_dict.items():
        if val.ndim == 2:
            total += val**2
        elif val.ndim == 3:
            total += np.sum(val**2, axis=-1)  # vector norm²
        elif val.ndim == 4:
            total += np.sum(val**2, axis=(-2, -1))  # Frobenius norm²
        else:
            raise ValueError(f"[ERROR] Unexpected F_{key} shape: {val.shape}")

    raw_total = float(np.sum(total[support]))
    if debug:
        print(f"[φ_curv] Raw: {raw_total:.4f} | Weighted: {weight * raw_total:.4f}")

    return weight * raw_total, raw_total

def compute_laplacian_field_energy(phi):
    """
    Return the Laplacian energy density ‖Δφ(x)‖² at each point.

    Args:
        phi : (H, W, d) — Lie algebra field

    Returns:
        (H, W) — spatial energy density field
    """
    lap = laplacian_field(phi)  # (H, W, d)
    return np.sum(lap**2, axis=-1)  # (H, W)

def compute_mass_field_energy(phi):
    """
    Return the mass energy density ‖φ(x)‖² at each point.

    Args:
        phi : (H, W, d)

    Returns:
        (H, W) — spatial energy density field
    """
    return np.sum(phi**2, axis=-1)

def compute_phi_coupling_field_energy(phi_q, phi_p, morphism_q_to_p):
    """
    Return pointwise coupling energy ‖Φ φ_q Φ⁻¹ − φ_p‖² at each point.

    Args:
        phi_q           : (H, W, d_q)
        phi_p           : (H, W, d_p)
        morphism_q_to_p : (H, W, K_p, K_q)

    Returns:
        (H, W) — spatial coupling energy field
    """
    from bundle_morphism_utils import gauge_covariant_transform_phi

    phi_q_trans = gauge_covariant_transform_phi(phi_q, morphism_q_to_p)
    assert phi_q_trans.shape == phi_p.shape, "Shape mismatch after morphism transform"

    return np.sum((phi_q_trans - phi_p)**2, axis=-1)



#===================================================================
#
#            Scalar Energies
#
#===================================================================


def compute_self_energy_scalar(agent, log_eps, cfg):
    """
    Compute total weighted KL(q_i || Φ̃ · p_i), scalar output for energy.
    """
    kl_field = compute_self_energy(agent, log_eps, cfg)
    agent.e_self_field = kl_field  # Optional: store for diagnostics

    # Mask invalid or zero-support regions
    valid_mask = (agent.mask > cfg.get("support_cutoff_eps", 1e-3)) & np.isfinite(kl_field)
    total_energy = float(np.sum(kl_field[valid_mask]))

    return total_energy

def compute_feedback_energy_scalar(agent, log_eps, cfg):
    """
    Compute total weighted KL(p_i || Φ · q_i) — returns scalar feedback energy.
    """
    kl_field = compute_feedback_energy(agent, log_eps, cfg)
    agent.e_feedback_field = kl_field  # Optional caching

    valid_mask = (agent.mask > cfg.get("support_cutoff_eps", 1e-3)) & np.isfinite(kl_field)
    total_energy = float(np.sum(kl_field[valid_mask]))

    return total_energy

def compute_alignment_energy_general(
    i, agent_i, eta_field_list, mask_list,
    Omega_list, Omega_inv_list,
    weight,
    log_eps=config.log_eps,
    field_type="belief"
) -> float:
    """
    Compute ∑_j weight * D_KL(η_i || Ω_ij · η_j), using natural parameters.

    Args:
        eta_field_list : list of (η₁, η₂) tuples for each agent
        mask_list      : list of binary masks
        Omega_list     : list of exp(phi) fields
        Omega_inv_list : list of exp(-phi) fields
        weight         : scalar multiplier
        field_type     : "belief" or "model" (for diagnostics only)

    Returns:
        total_energy   : scalar weighted KL
    """
    from natural_params_utils import log_partition_function

    eta1_i, eta2_i = eta_field_list[i]
    mask_i = mask_list[i]
    support_i = mask_i > config.support_cutoff_eps

    total_energy = 0.0
    for nb in agent_i.neighbors:
        j = nb["id"]
        eta1_j, eta2_j = eta_field_list[j]
        mask_j = mask_list[j]
        support_j = mask_j > config.support_cutoff_eps

        overlap = support_i & support_j
        if not np.any(overlap):
            continue

        # Ω_ij = Ω_i · Ω_j⁻¹
        Omega_ij = np.einsum("mab,mbc->mac", Omega_list[i][overlap], Omega_inv_list[j][overlap])

        # Transport η_j into i's frame
        eta1_j_t = np.einsum("mab,mb->ma", Omega_ij, eta1_j[overlap])
        eta2_j_t = np.einsum("mab,mbc,mcd->mad", Omega_ij, eta2_j[overlap], Omega_ij)

        eta1_i_pts = eta1_i[overlap]
        eta2_i_pts = eta2_i[overlap]

        # KL[q_i || Ω q_j] = A(η_j^t) − A(η_i) − ⟨η_i, η_j^t − η_i⟩
        A_j = log_partition_function(eta1_j_t, eta2_j_t, eps=log_eps)
        A_i = log_partition_function(eta1_i_pts, eta2_i_pts, eps=log_eps)

        d_eta1 = eta1_j_t - eta1_i_pts
        d_eta2 = eta2_j_t - eta2_i_pts

        inner = np.einsum("...i,...i->...", eta1_i_pts, d_eta1) \
              + np.einsum("...ij,...ij->...", eta2_i_pts, d_eta2)

        kl_vals = A_j - A_i - inner
        kl_vals = np.where(np.isfinite(kl_vals), kl_vals, 0.0)

        total_energy += weight * float(np.sum(kl_vals))

    return total_energy




def entropy_total(sigma_field, mask, log_eps=1e-8):
    """
    Total entropy ∑ H[q(c)] over the masked domain.
    """
    H = compute_entropy_field(sigma_field, mask, log_eps)
    return float(np.nansum(H))



def compute_laplacian_energy(phi, mask, weight):
    """
    Compute Laplacian regularization energy:
        E = weight * ∫_mask ‖Δφ‖²

    Args:
        phi   : (H, W, d) Lie algebra field
        mask  : (H, W) bool array
        weight: float

    Returns:
        float — scalar energy term
    """
    lap = laplacian_field(phi)  # (H, W, d)
    norms_sq = np.sum(lap**2, axis=-1)  # (H, W)
    return float(weight * np.sum(norms_sq[mask > 0]))


def compute_mass_energy(phi, mask, weight):
    """
    Compute mass regularization energy:
        E = weight * ∫_mask ‖φ‖²

    Args:
        phi   : (H, W, d) Lie algebra field
        mask  : (H, W) bool array
        weight: float

    Returns:
        float — scalar energy term
    """
    norms_sq = np.sum(phi**2, axis=-1)
    return float(weight * np.sum(norms_sq[mask > 0]))


def compute_phi_coupling_energy(
    phi_q, phi_p, morphism_q_to_p, mask, weight
):
    """
    Compute coupling energy ∫ ‖dΦ · φ_q · dΦ⁻¹ − φ_p‖² over the mask.

    Args:
        phi_q         : (H, W, d_q)
        phi_p         : (H, W, d_p)
        morphism_q_to_p : (H, W, K_p, K_q) — bundle morphism Φ: B_q → B_p
        mask          : (H, W)
        weight        : float

    Returns:
        float — scalar coupling energy
    """
    from bundle_morphism_utils import gauge_covariant_transform_phi

    # Transform phi_q into model frame
    phi_q_trans = gauge_covariant_transform_phi(phi_q, morphism_q_to_p)

    # Match shape
    assert phi_q_trans.shape == phi_p.shape, "Shape mismatch after morphism transform"

    diff_sq = np.sum((phi_q_trans - phi_p)**2, axis=-1)
    return float(weight * np.sum(diff_sq[mask > 0]))


def compute_curvature_energy(phi_field, mask, weight, lie_gens, support_eps=1e-4, debug=False):
    """
    Compute curvature energy: weight × ∑_x Tr[F_{μν}(x)^2] over valid mask.

    Args:
        phi_field   : (H, W, d)     — φ or φ_model field in Lie algebra coords
        mask        : (H, W)        — agent support mask
        weight      : float         — energy weight coefficient
        lie_gens    : (d, K, K)     — Lie algebra generators
        support_eps : float         — minimum support threshold
        debug       : bool          — optional print/debug info

    Returns:
        energy      : float         — weighted curvature energy
        raw_total   : float         — ∑ Tr[F²] over support (unweighted)
    """
    F_dict = compute_field_strength(phi_field, lie_gens)  # dict of F_xy, F_yz, etc.
    support = mask > support_eps

    total = 0.0
    for key, val in F_dict.items():
        if val.ndim == 2:
            total += val**2
        elif val.ndim == 3:
            total += np.sum(val**2, axis=-1)  # vector norm²
        elif val.ndim == 4:
            total += np.sum(val**2, axis=(-2, -1))  # Frobenius norm²
        else:
            raise ValueError(f"[ERROR] Unexpected F_{key} shape: {val.shape}")

    raw_total = float(np.sum(total[support]))
    if debug:
        print(f"[φ_curv] Raw: {raw_total:.4f} | Weighted: {weight * raw_total:.4f}")

    return weight * raw_total, raw_total



def zero_agent_metrics() -> dict:
    return {
        "e_self": 0.0,
        "e_feedback": 0.0,
        "e_align": 0.0,
        "e_mod_align": 0.0,
        "e_curv": 0.0,
        "e_curv_mod": 0.0,
        "e_mass": 0.0,
        "e_mass_mod": 0.0,
        "phi_norm": 0.0,
        "phi_model_norm": 0.0
    }


def compute_agent_metrics(
    i: int,
    agent,
    Q_eta_list, P_eta_list, Mask_list,
    O_bel, O_inv, O_mod, O_mod_inv,
    cfg, gens, log_eps
) -> tuple[int, dict]:
    """
    Compute all variational energy terms and norms for a single agent.
    Returns (i, stats)
    """
    mask = Mask_list[i]
    if not np.any(mask):
        return i, zero_agent_metrics()

    stats = compute_all_agent_metrics(
        i, agent, Q_eta_list, P_eta_list, Mask_list,
        O_bel, O_inv, O_mod, O_mod_inv,
        cfg, gens, log_eps
    )
    return i, stats

def log_agent_metrics(agent, step: int, stats: dict, support: float):
    S = support if support > 0 else 1.0
    agent.log_metrics(step, {
        "kl_self":           stats["e_self"]       / S,
        "kl_feedback":       stats["e_feedback"]   / S,
        "kl_align":          stats["e_align"]      / S,
        "kl_mod_align":      stats["e_mod_align"]  / S,
        "curv_energy":       stats["e_curv"]       / S,
        "curv_model_energy": stats["e_curv_mod"]   / S,
        "mass_energy":       stats["e_mass"]       / S,
        "mass_model_energy": stats["e_mass_mod"]   / S,
        "phi_norm":          stats["phi_norm"],
        "phi_model_norm":    stats["phi_model_norm"],
    })


def accumulate_and_log_metrics(results, agents, step: int, Q_eta_list, Mask_list) -> dict:
    keys = [
        "e_self", "e_feedback", "e_align", "e_mod_align",
        "e_curv", "e_curv_mod", "e_mass", "e_mass_mod"
    ]
    accum = {k: 0.0 for k in keys}
    total_support = 0.0

    for i, stats in results:
        support = float(np.sum(Mask_list[i]))
        total_support += support
        for k in keys:
            accum[k] += stats.get(k, 0.0)  # use .get for safety
        log_agent_metrics(agents[i], step, stats, support)

    S = total_support if total_support > 0 else 1.0
    metrics = {k: accum[k] / S for k in keys}
    metrics["total_energy"] = sum(metrics[k] for k in keys)
    metrics["step"] = step
    return metrics



def compute_all_agent_metrics(
    i, A, Q_eta_list, P_eta_list, Mask_list,
    O_bel, O_inv, O_mod, O_mod_inv,
    cfg, generators, log_eps
):
    """
    Compute all energy terms using natural parameter fields.
    """
    gen_q, gen_p = generators
    mask = Mask_list[i]

    stats = {
        "e_self": compute_self_energy_scalar(A, log_eps, cfg),
        "e_feedback": compute_feedback_energy_scalar(A, log_eps, cfg),

        "e_align": compute_alignment_energy_general(
            i=i,
            agent_i=A,
            eta_field_list=Q_eta_list,
            mask_list=Mask_list,
            Omega_list=O_bel,
            Omega_inv_list=O_inv,
            weight=cfg["beta"],
            log_eps=log_eps,
            field_type="belief"
        ),

        "e_mod_align": compute_alignment_energy_general(
            i=i,
            agent_i=A,
            eta_field_list=P_eta_list,
            mask_list=Mask_list,
            Omega_list=O_mod,
            Omega_inv_list=O_mod_inv,
            weight=cfg["beta_model"],
            log_eps=log_eps,
            field_type="model"
        ),

        "e_curv": 0.0,
        "e_curv_mod": 0.0,
        "phi_norm": np.linalg.norm(A.phi[mask], axis=-1).sum(),
        "phi_model_norm": np.linalg.norm(A.phi_model[mask], axis=-1).sum()
    }
    
    if cfg["belief_mass"] > 0:
        stats["e_mass"] = cfg["belief_mass"] * np.sum(np.sum(A.phi[mask]**2, axis=-1))

    if cfg["model_mass"] > 0:
        stats["e_mass_mod"] = cfg["model_mass"] * np.sum(np.sum(A.phi_model[mask]**2, axis=-1))

    if cfg["curvature_weight"] > 0:
        stats["e_curv"], _ = compute_curvature_energy(A.phi, mask, cfg["curvature_weight"], gen_q)

    if cfg["curvature_weight"] > 0:
        stats["e_curv_mod"], _ = compute_curvature_energy(A.phi_model, mask, cfg["curvature_weight"], gen_p)

    return stats

def log_all_metrics(
    agents,
    step: int,
    params=None,
    q_field: str = "q",                 # unused now
    p_field: str = "p",                 # unused now
    phi_belief_field: str = "phi",     # kept
    phi_model_field: str = "phi_model",
    mask_field: str = "mask",
    n_jobs: int = -1
) -> dict:
    """
    Compute and log all per-agent metrics using natural parameters (η₁, η₂).
    """
    cfg = config if params is None else {**vars(config), **params}
    log_eps = cfg.get("log_eps", 1e-10)

    N    = len(agents)
    K_q  = cfg.get("K_q", 5)
    K_p  = cfg.get("K_p", 5)
    name = cfg.get("group_name", "sl2r")

    gen_q = get_generators(name, K_q)
    gen_p = get_generators(name, K_p)

    # ───── Precompute fields using η₁, η₂ ─────
    Q_eta_list = [(A.eta1_q_field, A.eta2_q_field) for A in agents]
    P_eta_list = [(A.eta1_p_field, A.eta2_p_field) for A in agents]
    Mask_list  = [np.asarray(getattr(A, mask_field), dtype=bool) for A in agents]
    O_bel      = [A.Omega           for A in agents]
    O_inv      = [A.Omega_inv       for A in agents]
    O_mod      = [A.Omega_model     for A in agents]
    O_mod_inv  = [A.Omega_model_inv for A in agents]

    # ───── Compute metrics for all agents ─────
    results = Parallel(n_jobs=n_jobs, backend="threading", batch_size=1)(
        delayed(compute_agent_metrics)(
            i, agents[i], Q_eta_list, P_eta_list, Mask_list,
            O_bel, O_inv, O_mod, O_mod_inv,
            cfg, (gen_q, gen_p), log_eps
        )
        for i in range(N)
    )

    # ───── Aggregate and log ─────
    metrics = accumulate_and_log_metrics(results, agents, step, Q_eta_list, Mask_list)

    # ───── Print summary ─────
    total_energy = float(metrics["total_energy"])
    print(f"[STEP {step:04d}] Total Energy = {total_energy:.6f}")

    return metrics


def log_max_overlap_fields(agents, step, outdir, eps=config.support_cutoff_eps):
    """
    Logs full diagnostics from the max-overlap pair:
    - η₁/η₂ for q and p
    - belief/model alignment fields
    - KL(q ‖ Φ̃·p), KL(p ‖ Φ·q)
    """
    os.makedirs(outdir, exist_ok=True)

    # ───── Find most overlapping agent pair ─────
    max_overlap, best_pair = 0, None
    for i, A in enumerate(agents):
        mask_i = A.mask > eps
        if not mask_i.any():
            continue
        for nb in A.neighbors:
            j = nb["id"]
            mask_j = agents[j].mask > eps
            overlap = mask_i & mask_j
            if (count := int(overlap.sum())) > max_overlap:
                max_overlap, best_pair = count, (i, j)

    if best_pair is None:
        print(f"[DEBUG] No overlapping pair at step {step}")
        return

    i, j = best_pair
    A = agents[i]
    B = agents[j]

    # ───── Preprocess φ caches ─────
    preprocess_agent_fields(A, {})
    preprocess_agent_fields(B, {})

    # ───── Load fields ─────
    eta1_q = A.eta1_q_field
    eta2_q = A.eta2_q_field
    eta1_p = A.eta1_p_field
    eta2_p = A.eta2_p_field
    Phi     = A.bundle_morphism_q_to_p
    Phi_tilde = A.bundle_morphism_p_to_q
    mask_i = (A.mask > eps).astype(np.float32)
    H, W, K_q = eta1_q.shape
    K_p = eta1_p.shape[-1]

    # ───── KL fields via natural morphism projection ─────
    kl_qp = compute_kl_projected_field_natural(
        eta1_src = eta1_q,
        eta2_src = eta2_q,
        eta1_tgt = eta1_p,
        eta2_tgt = eta2_p,
        morphism = Phi_tilde,
        mask = A.mask,
        direction = "p_to_q"
    )

    kl_pq = compute_kl_projected_field_natural(
        eta1_src = eta1_p,
        eta2_src = eta2_p,
        eta1_tgt = eta1_q,
        eta2_tgt = eta2_q,
        morphism = Phi,
        mask = A.mask,
        direction = "q_to_p"
    )

    # ───── Alignment fields (natural param version) ─────
    belief_align = compute_alignment_field_general(agents, i, field_type="belief")
    model_align  = compute_alignment_field_general(agents, i, field_type="model")

    # ───── Convert to μ, Σ for optional visual inspection ─────
    mu_q, sigma_q = natural_to_mu_sigma_batch(eta1_q, eta2_q)
    mu_p, sigma_p = natural_to_mu_sigma_batch(eta1_p, eta2_p)
    sigma_q = sanitize_sigma(sigma_q)
    sigma_p = sanitize_sigma(sigma_p)

    # ───── Save output ─────
    fname = os.path.join(outdir, f"step{step:05d}_pair_{i}_{j}.npz")
    np.savez_compressed(
        fname,
        agent_i          = i,
        agent_j          = j,
        overlap          = max_overlap,
        mask_i           = mask_i,
        eta1_q           = eta1_q,
        eta2_q           = eta2_q,
        eta1_p           = eta1_p,
        eta2_p           = eta2_p,
        mu_q             = mu_q,
        sigma_q          = sigma_q,
        mu_p             = mu_p,
        sigma_p          = sigma_p,
        kl_self          = kl_qp,
        kl_feedback      = kl_pq,
        belief_alignment = belief_align,
        model_alignment  = model_align,
        phi              = A.phi,
        phi_model        = A.phi_model,
    )



def full_field_logger(agents, step: int, outdir: str):
    """
    Save one .npz per step containing per-agent fields and diagnostics:
      - eta1_q, eta2_q, phi
      - eta1_p, eta2_p, phi_model
      - belief_align, model_align
      - kl_self, kl_feedback
      - curvature tensors
      - bundle morphisms Φ, Φ̃
    """
    cfg  = vars(config)
    K_q  = cfg["K_q"]
    K_p  = cfg["K_p"]
    gens_q = get_generators(cfg["group_name"], K_q)
    gens_p = get_generators(cfg["group_name"], K_p)
    dx   = cfg.get("dx", 1.0)
    log_eps = cfg.get("log_eps", 1e-8)

    N = len(agents)
    H, W = agents[0].eta1_q_field.shape[:2]

    # Allocate tensors
    eta1_q = np.zeros((N, H, W, K_q), dtype=np.float32)
    eta2_q = np.zeros((N, H, W, K_q, K_q), dtype=np.float32)
    phi    = np.zeros((N, H, W, agents[0].phi.shape[-1]), dtype=np.float32)

    eta1_p = np.zeros((N, H, W, K_p), dtype=np.float32)
    eta2_p = np.zeros((N, H, W, K_p, K_p), dtype=np.float32)
    phi_model = np.zeros((N, H, W, agents[0].phi_model.shape[-1]), dtype=np.float32)

    belief_align      = np.zeros((N, H, W), dtype=np.float32)
    model_align       = np.zeros((N, H, W), dtype=np.float32)
    kl_self_field     = np.zeros((N, H, W), dtype=np.float32)
    kl_feedback_field = np.zeros((N, H, W), dtype=np.float32)

    curv_tensor       = np.zeros((N, H, W, K_q, K_q), dtype=np.float32)
    curv_model_tensor = np.zeros((N, H, W, K_p, K_p), dtype=np.float32)

    for idx, A in enumerate(agents):
        eta1_q[idx] = A.eta1_q_field
        eta2_q[idx] = A.eta2_q_field
        phi[idx]    = A.phi

        eta1_p[idx] = A.eta1_p_field
        eta2_p[idx] = A.eta2_p_field
        phi_model[idx] = A.phi_model

        belief_align[idx] = compute_alignment_field_general(agents, idx, field_type="belief")
        model_align[idx]  = compute_alignment_field_general(agents, idx, field_type="model")

        kl_self_field[idx] = compute_kl_projected_field_natural(
            eta1_src = A.eta1_q_field,
            eta2_src = A.eta2_q_field,
            eta1_tgt = A.eta1_p_field,
            eta2_tgt = A.eta2_p_field,
            morphism = A.bundle_morphism_p_to_q,
            mask     = A.mask,
            direction = "p_to_q",
            eps = log_eps
        )

        kl_feedback_field[idx] = compute_kl_projected_field_natural(
            eta1_src = A.eta1_p_field,
            eta2_src = A.eta2_p_field,
            eta1_tgt = A.eta1_q_field,
            eta2_tgt = A.eta2_q_field,
            morphism = A.bundle_morphism_q_to_p,
            mask     = A.mask,
            direction = "q_to_p",
            eps = log_eps
        )

        curv_tensor[idx]       = compute_field_strength(A.phi, generators=gens_q, dx=dx)["xy"]
        curv_model_tensor[idx] = compute_field_strength(A.phi_model, generators=gens_p, dx=dx)["xy"]

    # Stack morphisms
    phi_q_to_p_stack = np.stack([A.bundle_morphism_q_to_p for A in agents], axis=0)
    phi_p_to_q_stack = np.stack([A.bundle_morphism_p_to_q for A in agents], axis=0)

    # Save
    os.makedirs(outdir, exist_ok=True)
    fname = Path(outdir) / f"step{step:05d}.npz"
    np.savez_compressed(
        fname,
        eta1_q=eta1_q,
        eta2_q=eta2_q,
        phi=phi,
        eta1_p=eta1_p,
        eta2_p=eta2_p,
        phi_model=phi_model,
        belief_align=belief_align,
        model_align=model_align,
        kl_self=kl_self_field,
        kl_feedback=kl_feedback_field,
        curv_tensor=curv_tensor,
        curv_model_tensor=curv_model_tensor,
        phi_q_to_p=phi_q_to_p_stack,
        phi_p_to_q=phi_p_to_q_stack,
    )
    print(f"[DUMP] step={step} → {fname}")





