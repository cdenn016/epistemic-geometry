
import pickle
import logging
import random

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from numpy.linalg import norm
from scipy.linalg import logm
import json
from pathlib import Path
from generalized_io_utils import load_all_checkpoints
import config
from joblib import Parallel, delayed

from config import (
    group_name,
    K_q, K_p
)
from get_generators import get_generators
from holonomy_utils import get_agent_cycles, get_overlap_centroid
from holonomy_module import (
    compute_spatial_loop_holonomy,
    compute_agent_cycle_holonomy,
    sample_self_avoiding_loop_within_mask,
)
from numerical_utils import safe_logm
# ----------------------------
# Experiment parameters
# ----------------------------
max_agent_cycles = 3        # None = all cycles
spatial_sizes = [6]
STEP_INTERVAL = 2  # Run holonomy every N steps

# ----------------------------
# Logging setup
# ----------------------------


logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s %(levelname)s %(message)s'
)

def summarize_holonomy(H):
    """
    Given a holonomy matrix H (K×K), return a dict of rich diagnostics.
    """
    I = np.eye(H.shape[0])
    try:
        logH = logm(H)
        logH_norm = norm(logH)
    except Exception:
        logH = np.full_like(H, np.nan)
        logH_norm = np.nan

    tr   = np.trace(H)
    det  = np.linalg.det(H)
    cond = np.linalg.cond(H)
    dev_norm = norm(H - I)

    sym = 0.5 * (H + H.T)
    skew = 0.5 * (H - H.T)
    sym_norm  = norm(sym)
    skew_norm = norm(skew)

    try:
        eigvals = np.linalg.eigvals(H)
        eigvals_sorted = sorted(eigvals, key=lambda z: -abs(z))
        max_abs_eig  = max(abs(e) for e in eigvals)
        mean_abs_eig = np.mean(np.abs(eigvals))
    except Exception:
        eigvals_sorted = []
        max_abs_eig = np.nan
        mean_abs_eig = np.nan

    # Optional geometric interpretation if K=2 (SO(2)-like rotation)
    curve_type = None
    curve_val  = None
    if H.shape == (2, 2):
        try:
            angle = np.arccos(np.clip(tr / 2.0, -1.0, 1.0))
            curve_type = 'rotation_angle'
            curve_val  = angle
        except Exception:
            pass

    return {
        'trace':           tr,
        'det_minus1':      det - 1.0,
        'cond':            cond,
        'deviation_norm':  dev_norm,
        'logH_norm':       logH_norm,
        'sym_norm':        sym_norm,
        'skew_norm':       skew_norm,
        'max_abs_eig':     max_abs_eig,
        'mean_abs_eig':    mean_abs_eig,
        'curve_type':      curve_type,
        'curve_value':     curve_val,
    }



from natural_params_utils import natural_to_mu_sigma

def run_spatial_experiments(
    data_cache,
    steps,
    spatial_sizes,
    generators,
    use_commutator=False,
    phi_key="phi",
    save_transport_logs=True,
    log_dir="holonomy_experiments/transport_logs"
):
    """
    For each radius r in spatial_sizes:
      1. Sample one self-avoiding loop on the first step's mask.
      2. Replay that loop across all steps in parallel.
      3. Log holonomy diagnostics and metrics inline.
    """
    records = []
    Path(log_dir).mkdir(parents=True, exist_ok=True)

    first_agents = data_cache[steps[0]][0] if isinstance(data_cache[steps[0]], tuple) else data_cache[steps[0]]
    first_agent  = first_agents[0]
    center       = tuple(first_agent.center)
    mask         = first_agent.mask
    agent_seed   = getattr(config, "loop_sampling_seed", 0)

    for r in spatial_sizes:
        circ  = 2 * np.pi * r
        min_L = max(4, int(0.5 * circ))
        max_L = max(min_L, int(1.2 * circ))

        coords_loop = sample_self_avoiding_loop_within_mask(
            center,
            mask,
            min_length=min_L,
            max_length=max_L,
            seed=agent_seed
        )

        # Precompute from η for initial belief
        b0_mu, b0_sigma = natural_to_mu_sigma(
            first_agent.eta1_q_field[center],
            first_agent.eta2_q_field[center],
        )
        b0 = (b0_mu, b0_sigma)

        def run_one_step(step):
            agents = data_cache[step][0] if isinstance(data_cache[step], tuple) else data_cache[step]
            agent  = agents[0]

            # Convert η → μ, Σ for current agent
            mu_q_field, sigma_q_field = natural_to_mu_sigma(agent.eta1_q_field, agent.eta2_q_field)
            agent.mu_q_field = mu_q_field
            agent.sigma_q_field = sigma_q_field

            H, deviations, belief_seq, path_coords = compute_spatial_loop_holonomy(
                agent,
                coords_loop,
                generators,
                use_commutator=use_commutator,
                return_deviations=True,
                return_beliefs=True,
                return_path=True,
                initial_belief=b0,
                use_log_accumulation=True,
            )

            logH = safe_logm(H, context=f"holonomy step={step}")
            curvature_norm = np.linalg.norm(logH)

            mu_seq, sigma_seq = map(np.asarray, belief_seq)
            belief_json = json.dumps([mu_seq.tolist(), sigma_seq.tolist()])
            path_json   = json.dumps([[int(x) for x in p] for p in path_coords])

            if save_transport_logs:
                log_data = {
                    "param": step,
                    "radius": r,
                    "mu_seq": mu_seq,
                    "sigma_seq": sigma_seq,
                    "transport_path": path_coords,
                    "holonomy": H,
                    "logH": logH,
                }
                fname = f"step{step:05d}_spatial_radius_{r:.3f}.pkl"
                with open(Path(log_dir) / fname, "wb") as f:
                    pickle.dump(log_data, f)

            holonomy_summary = summarize_holonomy(H)
            return {
                'experiment':       'spatial',
                'param':            step,
                'radius':           r,
                'step':             step,
                'loop_length':      len(coords_loop) - 1,
                'mean_deviation':   np.mean(deviations),
                'curvature_norm':   curvature_norm,
                'belief_seq':       belief_json,
                'path_coords':      path_json,
                'logH':             logH,
                'holonomy':         H,
                'phi_key':          phi_key,
                'use_commutator':   use_commutator,
                **holonomy_summary
            }

        step_records = Parallel(n_jobs=-1, backend="threading")(
            delayed(run_one_step)(step) for step in steps
        )
        records.extend(step_records)

    return records


from natural_params_utils import natural_to_mu_sigma

def run_agent_cycle_experiments(
    data_cache,
    steps,
    agents_at_first_step,
    cycles,
    generators,
    use_commutator=False,
    phi_key="phi",
    save_transport_logs=True,
    log_dir="holonomy_experiments/transport_logs"
):
    records = []
    Path(log_dir).mkdir(parents=True, exist_ok=True)

    domain_size = config.domain_size
    support_cutoff_eps = getattr(config, "support_cutoff_eps", 1e-3)

    # Precompute overlap centroids once
    all_overlaps = {
        tuple(cycle): [
            get_overlap_centroid(
                agents_at_first_step[i],
                agents_at_first_step[j],
                domain_size,
                support_cutoff_eps
            ) or (np.nan,)
            for i, j in zip(cycle[:-1], cycle[1:])
        ]
        for cycle in cycles
    }

    for cycle in cycles:
        label = '_'.join(map(str, cycle))
        overlaps = all_overlaps[tuple(cycle)]

        def compute_one_step(step):
            agents = data_cache[step][0] if isinstance(data_cache[step], tuple) else data_cache[step]

            # Convert η → μ, Σ for all agents
            for agent in agents:
                mu_q, sigma_q = natural_to_mu_sigma(agent.eta1_q_field, agent.eta2_q_field)
                agent.mu_q_field = mu_q
                agent.sigma_q_field = sigma_q

            # Extract initial belief from first agent in cycle
            start_agent = cycle[0]
            start_pos   = tuple(agents[start_agent].center)
            mu0         = agents[start_agent].mu_q_field[start_pos]
            sigma0      = agents[start_agent].sigma_q_field[start_pos]
            b0          = (mu0, sigma0)

            # Compute holonomy
            H, deviations, belief_seq, transport_path = compute_agent_cycle_holonomy(
                agents,
                cycle,
                overlaps,
                generators,
                initial_belief=b0,
                return_deviations=True,
                return_beliefs=True,
                return_path=True,
                use_commutator=use_commutator,
                use_log_accumulation=True,
            )

            logH = safe_logm(H, context=f"holonomy step={step}")
            curvature_norm = np.linalg.norm(logH)

            mu_seq, sigma_seq = map(np.asarray, belief_seq)
            belief_json = json.dumps([mu_seq.tolist(), sigma_seq.tolist()])
            path_json   = json.dumps([[int(x) for x in p] for p in transport_path])

            # Save transport log to file
            if save_transport_logs:
                log_data = {
                    "param": step,
                    "agent_cycle": cycle,
                    "mu_seq": mu_seq,
                    "sigma_seq": sigma_seq,
                    "transport_path": transport_path,
                    "holonomy": H,
                    "logH": logH,
                }

                fname = f"step{step:05d}_cycle_{label}.pkl"
                with open(Path(log_dir) / fname, "wb") as f:
                    pickle.dump(log_data, f)

            holonomy_summary = summarize_holonomy(H)
            return {
                'experiment':       'agent_cycle',
                'param':            label,
                'step':             step,
                'loop_length':      len(cycle),
                'mean_deviation':   np.mean(deviations),
                'max_deviation':    np.max(deviations),
                'curvature_norm':   curvature_norm,
                'belief_seq':       belief_json,
                'transport_path':   path_json,
                'holonomy':         H,
                'logH':             logH,
                'phi_key':          phi_key,
                'use_commutator':   use_commutator,
                **holonomy_summary
            }

        step_records = Parallel(n_jobs=-1, backend="threading")(
            delayed(compute_one_step)(step) for step in steps
        )
        records.extend(step_records)

    return records


def main():
    # Load all checkpoints
    data_cache = load_all_checkpoints()
    steps = sorted(data_cache.keys())[::STEP_INTERVAL]

    global max_agent_cycles, spatial_sizes

    # Extract first-step agents and sample agent cycles
    first_agents = data_cache[steps[0]][0] if isinstance(data_cache[steps[0]], tuple) else data_cache[steps[0]]
    all_cycles = get_agent_cycles(first_agents, max_length=40)

    random.seed(42)
    cycles = random.sample(
        all_cycles,
        min(len(all_cycles), max_agent_cycles or len(all_cycles))
    ) if all_cycles else []

    # Shared config
    phi_key = "phi"
    use_commutator = False
    generators_q = get_generators(group_name, K_q)
    generators_p = get_generators(group_name, K_p)
    records = []

    # ── Run spatial loop experiments (belief fiber only) ──
    records += run_spatial_experiments(
        data_cache=data_cache,
        steps=steps,
        spatial_sizes=spatial_sizes,
        generators=generators_q,  # use belief generators
        use_commutator=use_commutator,
        phi_key=phi_key,
    )

    # ── Run agent-cycle holonomy in belief space ──
    if cycles:
        records += run_agent_cycle_experiments(
            data_cache=data_cache,
            steps=steps,
            agents_at_first_step=first_agents,
            cycles=cycles,
            generators=generators_q,  # use belief generators
            use_commutator=use_commutator,
            phi_key=phi_key,
        )
    else:
        logging.warning("No agent cycles found; skipping agent_cycle experiments.")

    # ── Save master summary CSV ──
    df = pd.DataFrame(records)
    if 'curvature_norm' not in df.columns and 'deviation_norm' in df.columns:
        df['curvature_norm'] = df['deviation_norm']

    out_dir = Path("holonomy_experiments")
    out_dir.mkdir(exist_ok=True)
    master_csv = out_dir / "master_summary.csv"
    df.to_csv(master_csv, index=False)
    logging.info(f"Master summary written to {master_csv}")

    # ── Plot summary metrics vs. param (radii or agent cycles) ──
    metrics_to_plot = [
        'curvature_norm',
        'logH_norm',
        'sym_norm',
        'skew_norm',
        'max_abs_eig'
    ]

    for metric in metrics_to_plot:
        if metric not in df.columns:
            continue
        plt.figure(figsize=(10, 6))
        for exp_type in df['experiment'].unique():
            subset = df[df['experiment'] == exp_type]
            grouped = subset.groupby('param')[metric].mean()
            plt.plot(grouped.index, grouped.values, marker='o', label=exp_type)
        plt.xlabel('Parameter')
        plt.ylabel(metric)
        plt.title(f'{metric} vs Parameter')
        plt.xticks(rotation=45)
        plt.legend()
        plt.tight_layout()
        plt.savefig(out_dir / f"{metric}_vs_param.png")
        plt.close()
        logging.info(f"Saved plot for {metric}")

    logging.info("All summary plots saved.")

if __name__ == '__main__':
    main()
