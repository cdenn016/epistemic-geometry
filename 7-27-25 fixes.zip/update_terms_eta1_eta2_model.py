# -*- coding: utf-8 -*-
"""
Created on Sat Jul 26 08:46:17 2025

@author: chris and christine
"""

import numpy as np
from natural_params_utils import compute_bar_eta2_qj, compute_delta_eta, grad_eta2_from_sigma_mu
from numerical_utils import safe_inv
from numerical_utils import safe_inv
from natural_params_utils import (
    compute_bar_eta2_q_morphed,
    compute_delta_eta_p_Phi_q,
    
    grad_eta2_from_sigma_mu,
    apply_natural_gradient_batch_eta
)
import config
from omega import compute_exp_field

def accumulate_eta_gradient_model(agent_i, agents, params):
    """
    Accumulate ∇_{η₁_p}, ∇_{η₂_p} for agent_i in model fiber using:

      - Self:     KL(q_i || Φ̃ p_i)
      - Feedback: KL(p_i || Φ q_i)
      - Alignment: KL(p_i || Ω̃_ij p_j)   and   KL(p_k || Ω̃_kj p_j) for i == j

    Updates:
        agent_i.grad_eta1_p_field
        agent_i.grad_eta2_p_field
    """
    eps = config.support_cutoff_eps
    alpha = params.get("alpha", config.alpha)
    beta  = params.get("beta", config.beta)
    lambd = params.get("lambda", config.feedback_weight)

    # ── Masked inputs ──
    mask     = agent_i.mask > eps
    mask1    = mask[..., None]
    mask2    = mask[..., None, None]

    eta1_q   = agent_i.eta1_q_field * mask1
    eta2_q   = agent_i.eta2_q_field * mask2
    eta1_p   = agent_i.eta1_p_field * mask1
    eta2_p   = agent_i.eta2_p_field * mask2
    Phi      = agent_i.bundle_morphism_q_to_p * mask2
    Phi_tilde = agent_i.bundle_morphism_p_to_q * mask2

    # ── Self-energy ──
    #grad_eta1_self = grad_eta1_p_morphism_self(eta1_p, eta2_p, eta1_q, eta2_q, Phi, eps=eps)
    #grad_eta2_self = grad_eta2_p_morphism_self(eta1_p, eta2_p, eta1_q, eta2_q, Phi, eps=eps)

    # ── Feedback ──
    grad_eta1_fb = grad_eta1_p_morphism_feedback(eta1_p, eta2_p, eta1_q, eta2_q, Phi, eps=eps)
    grad_eta2_fb = grad_eta2_p_morphism_feedback(eta1_p, eta2_p, eta1_q, eta2_q, Phi, eps=eps)

    # ── Alignment (i = source) ──
    grad_eta1_align = np.zeros_like(eta1_p)
    grad_eta2_align = np.zeros_like(eta2_p)
    for neighbor in agent_i.neighbors:
        agent_j = agents[neighbor["id"]]

    # Force recomputation of Omega_model and Omega_model_inv (post-cache-clear)
        Omega_i = compute_exp_field(
            agent_i.phi_model,
            agent_i.generators_p,
            scale=config.phi_scale,
            group_name=config.group_name,
            )
        Omega_j_inv = compute_exp_field(
            -agent_j.phi_model,
            agent_j.generators_p,
            scale=config.phi_scale,
            group_name=config.group_name,
            )

        Omega_tilde_ij = np.einsum("...ik,...kj->...ij", Omega_i, Omega_j_inv)

        grad_eta1_align += grad_eta1_pi_alignment(
            eta1_p,
            eta2_p,
            agent_j.eta1_p_field * mask1,
            agent_j.eta2_p_field * mask2,
            Omega_tilde_ij,
            eps=eps,
            )
        grad_eta2_align += grad_eta2_pi_alignment(
            eta1_p,
            eta2_p,
            agent_j.eta1_p_field * mask1,
            agent_j.eta2_p_field * mask2,
            Omega_tilde_ij,
            eps=eps,
            )   


    # ── Alignment (i = target) ──
    grad_eta1_align_rev = np.zeros_like(eta1_p)
    grad_eta2_align_rev = np.zeros_like(eta2_p)
    for agent_k in agents:
        for neighbor in agent_k.neighbors:
            if neighbor.get("id") == agent_i.id:

            # Recompute Omegã_k and Omegã_j⁻¹ for alignment
                Omega_k = compute_exp_field(
                    agent_k.phi_model,
                    agent_k.generators_p,
                    scale=config.phi_scale,
                   group_name=config.group_name,
                   )
                Omega_i_inv = compute_exp_field(
                    -agent_i.phi_model,
                    agent_i.generators_p,
                    scale=config.phi_scale,
                    group_name=config.group_name,
                    )

                Omega_tilde_kj = np.einsum("...ik,...kj->...ij", Omega_k, Omega_i_inv)

                grad_eta1_align_rev += grad_eta1_pj_alignment(
                    agent_k.eta1_p_field * mask1,
                    agent_k.eta2_p_field * mask2,
                    eta1_p,
                    eta2_p,
                    Omega_tilde_kj,
                    eps=eps,
                    )
                grad_eta2_align_rev += grad_eta2_pj_alignment(
                    agent_k.eta1_p_field * mask1,
                    agent_k.eta2_p_field * mask2,
                    eta1_p,
                    eta2_p,
                    Omega_tilde_kj,
                    eps=eps,
                    )

    # ── Combine ──
    grad_eta1_total = (
        
        lambd * grad_eta1_fb +
        beta * (grad_eta1_align + grad_eta1_align_rev)
    )
    grad_eta2_total = (
        
        lambd * grad_eta2_fb +
        beta * (grad_eta2_align + grad_eta2_align_rev)
    )

    grad_eta1_total *= mask1
    grad_eta2_total *= mask2

    # Optional clipping
    grad_eta1_total = np.clip(grad_eta1_total, -config.grad_eta1_clip, config.grad_eta1_clip)
    grad_eta2_total = np.clip(grad_eta2_total, -config.grad_eta2_clip, config.grad_eta2_clip)

    # Logging
    #print("\n η₁_p grad norm [total]:", np.mean(np.linalg.norm(grad_eta1_total, axis=-1)))
   # print("η₂_p grad norm [total]:", np.mean(np.linalg.norm(grad_eta2_total.reshape(grad_eta2_total.shape[:-2] + (-1,)), axis=-1)))

    # Natural gradient update (Fisher-preconditioned)
    delta_eta1, delta_eta2 = apply_natural_gradient_batch_eta(
        eta1_p, eta2_p, grad_eta1_total, grad_eta2_total, mask1, eps=eps
    )

    agent_i.grad_eta1_p_field += delta_eta1
    agent_i.grad_eta2_p_field += delta_eta2



#validated 7-25-25
def grad_eta1_pi_alignment(eta1_pi, eta2_pi, eta1_pj, eta2_pj, Omega_tilde_ij, eps=1e-8):
    """
    ∇_{η1_pi} D_KL(p_i || Ω~_ij p_j)
    = -½ · bar_eta2_pj · Δη · η2_pi⁻¹
    """
    bar_eta2_pj = compute_bar_eta2_qj(eta2_pj, Omega_tilde_ij, eps=eps)
    delta_eta   = compute_delta_eta(eta1_pi, eta2_pi, eta1_pj, eta2_pj, Omega_tilde_ij, eps=eps)
    eta2_inv_pi = safe_inv(eta2_pi, eps=eps)

    tmp = np.einsum("...ij,...j->...i", bar_eta2_pj, delta_eta)
    grad = -0.5 * np.einsum("...i,...ij->...j", tmp, eta2_inv_pi)
    return grad

#validated 7-25-25
def grad_eta1_pj_alignment(eta1_pi, eta2_pi, eta1_pj, eta2_pj, Omega_tilde_ij, eps=1e-8):
    """
    ∇_{η1_pj} D_KL(p_i || Ω~_ij p_j)
    = +½ · Ω~_ijᵀ · bar_eta2_pj · Δη · η2_pi⁻¹
    """
    bar_eta2_pj = compute_bar_eta2_qj(eta2_pj, Omega_tilde_ij, eps=eps)
    delta_eta   = compute_delta_eta(eta1_pi, eta2_pi, eta1_pj, eta2_pj, Omega_tilde_ij, eps=eps)
    eta2_inv_pi = safe_inv(eta2_pi, eps=eps)

    tmp = np.einsum("...ij,...j->...i", bar_eta2_pj, delta_eta)
    tmp2 = np.einsum("...i,...ij->...j", tmp, eta2_inv_pi)
    grad = 0.5 * np.einsum("...ji,...i->...j", Omega_tilde_ij, tmp2)
    return grad


def grad_mu_pi_alignment(eta1_pi, eta2_pi, eta1_pj, eta2_pj, Omega_tilde_ij, eps=1e-8):
    """
    Compute:
        ∂KL / ∂μ_pi = bar_eta2_pj · (η2_pi⁻¹ η1_pi − Ω~ η2_pj⁻¹ η1_pj)
    """
    bar_eta2_pj = compute_bar_eta2_qj(eta2_pj, Omega_tilde_ij, eps=eps)
    delta_eta   = compute_delta_eta(eta1_pi, eta2_pi, eta1_pj, eta2_pj, Omega_tilde_ij, eps=eps)
    grad_mu = np.einsum("...ij,...j->...i", bar_eta2_pj, delta_eta)
    return grad_mu


#===================================================================
#
#               gradients with respect to eta2
#
#==================================================================

def grad_mu_q_morphism_feedback(eta1_p, eta2_p, eta1_q, eta2_q, Phi, eps=1e-8):
    """
    Compute:
        ∇_{μ_q} D_KL(p || Φ q) = Φᵀ · bar_eta2^Φ_q · Δη
    """
    bar_eta2_Phi_q = compute_bar_eta2_q_morphed(eta2_q, Phi, eps=eps)
    bar_eta2_Phi_q = 0.5 * (bar_eta2_Phi_q + np.swapaxes(bar_eta2_Phi_q, -1, -2))  # ensure symmetry

    delta_eta = compute_delta_eta_p_Phi_q(eta1_p, eta2_p, eta1_q, eta2_q, Phi, eps=eps)

    tmp = np.einsum("...ij,...j->...i", bar_eta2_Phi_q, delta_eta)
    Phi_T = np.swapaxes(Phi, -1, -2)
    grad_mu_q = np.einsum("...ij,...j->...i", Phi_T, tmp)

    # Optional: clip large values to prevent η₂ instability
    clip = 1e3
    grad_mu_q = np.clip(grad_mu_q, -clip, clip)

    return grad_mu_q



def grad_mu_p_morphism_feedback(eta1_p, eta2_p, eta1_q, eta2_q, Phi, eps=1e-8):
    """
    Compute:
        ∇_{μ_p} D_KL(p || Φ q) = bar_eta2^Φ_q · Δη
    """
    bar_eta2_Phi_q = compute_bar_eta2_q_morphed(eta2_q, Phi, eps=eps)
    bar_eta2_Phi_q = 0.5 * (bar_eta2_Phi_q + np.swapaxes(bar_eta2_Phi_q, -1, -2))

    delta_eta = compute_delta_eta_p_Phi_q(eta1_p, eta2_p, eta1_q, eta2_q, Phi, eps=eps)
    grad_mu_p = np.einsum("...ij,...j->...i", bar_eta2_Phi_q, delta_eta)
    return grad_mu_p


def grad_eta1_p_morphism_feedback(eta1_p, eta2_p, eta1_q, eta2_q, Phi, eps=1e-8):
    """
    Compute:
        ∇_{η1_p} D_KL(p || Φ q)
        = -½ · η2_p⁻¹ · bar_eta2^Φ_q · Δη

    Inputs:
        eta1_p : (..., K_p)
        eta2_p : (..., K_p, K_p)
        eta1_q : (..., K_q)
        eta2_q : (..., K_q, K_q)
        Phi    : (..., K_p, K_q)

    Returns:
        grad_eta1_p : (..., K_p)
    """
    
    eta2_inv_p = safe_inv(eta2_p, eps=eps)

    bar_eta2_Phi_q = compute_bar_eta2_q_morphed(eta2_q, Phi, eps=eps)
    bar_eta2_Phi_q = 0.5 * (bar_eta2_Phi_q + np.swapaxes(bar_eta2_Phi_q, -1, -2))  # Ensure symmetry

    delta_eta = compute_delta_eta_p_Phi_q(eta1_p, eta2_p, eta1_q, eta2_q, Phi, eps=eps)

    tmp = np.einsum("...ij,...j->...i", bar_eta2_Phi_q, delta_eta)
    grad_eta1_p = -0.5 * np.einsum("...ij,...j->...i", eta2_inv_p, tmp)
    return grad_eta1_p



def grad_eta2_p_morphism_feedback(eta1_q, eta2_q, eta1_p, eta2_p, Phi_tilde, eps=1e-8):
    """
    Compute ∇_{η₂_p} KL[q || Φ̃·p] via natural parameters.

    This mirrors grad_eta2_q_morphism_feedback but for model fiber (p), using:
        KL[q || Φ̃·p] = ⟨η_q, θ_q - θ_proj⟩ - A_q + A_proj

    Args:
        eta1_q : (..., K_q)
        eta2_q : (..., K_q, K_q)
        eta1_p : (..., K_p)
        eta2_p : (..., K_p, K_p)
        Phi_tilde : (..., K_q, K_p) — morphism: B_p → B_q
    Returns:
        grad_eta2_p : (..., K_p, K_p)
    """


    # Invert η2_q and compute (μ_q, Σ_q)
    eta2_inv_q = safe_inv(eta2_q, eps=eps)
    eta2_inv_q = 0.5 * (eta2_inv_q + np.swapaxes(eta2_inv_q, -1, -2))
    mu_q = -0.5 * np.einsum("...ij,...j->...i", eta2_inv_q, eta1_q)
    sigma_q = -0.5 * eta2_inv_q

    # Invert η2_p
    eta2_inv_p = safe_inv(eta2_p, eps=eps)
    eta2_inv_p = 0.5 * (eta2_inv_p + np.swapaxes(eta2_inv_p, -1, -2))

    # Morph bar_eta2(q) into p-fiber using Φ̃
    bar_eta2_Phi_q = compute_bar_eta2_q_morphed(eta2_q, Phi_tilde, eps=eps)
    bar_eta2_Phi_q = 0.5 * (bar_eta2_Phi_q + np.swapaxes(bar_eta2_Phi_q, -1, -2))

    # Δη = η_p − Φ̃ η_q
    delta_eta = compute_delta_eta_p_Phi_q(eta1_p, eta2_p, eta1_q, eta2_q, Phi_tilde, eps=eps)

    # --- Build inner gradient tensor ---
    term1 = bar_eta2_Phi_q

    term2 = np.einsum("...ik,...kl,...lj->...ij", bar_eta2_Phi_q, eta2_inv_p, bar_eta2_Phi_q)
    term2 = 0.5 * (term2 + np.swapaxes(term2, -1, -2))  # symmetrize

    outer = np.einsum("...i,...j->...ij", delta_eta, delta_eta)
    term3 = 0.5 * np.einsum("...ik,...kl,...lj->...ij", bar_eta2_Phi_q, outer, bar_eta2_Phi_q)
    term3 = 0.5 * (term3 + np.swapaxes(term3, -1, -2))

    # Damping regularizer on trace and Mahalanobis terms
    damping = 1
    inner = term1 + damping * term2 + damping * term3

    # Pull back gradient to p-fiber via Φ̃
    Phi = Phi_tilde  # (..., K_q, K_p)
    Phi_T = np.swapaxes(Phi, -1, -2)  # (..., K_p, K_q)
    temp = np.einsum("...ik,...kl->...il", Phi_T, inner)
    grad_sigma_p = np.einsum("...ik,...kj->...ij", temp, Phi)

    # Use μ_q gradient from KL[q ‖ Φ̃·p]
    grad_mu_p = grad_mu_q_morphism_feedback(eta1_p, eta2_p, eta1_q, eta2_q, Phi_tilde, eps=eps)

    return grad_eta2_from_sigma_mu(grad_sigma_p, grad_mu_p, mu_q, sigma_q)

def grad_eta2_p_morphism_feedback(eta1_p, eta2_p, eta1_q, eta2_q, Phi, eps=1e-8):
    """
    Compute ∇_{η₂_p} D_KL(p || Φ·q) using natural parameters.

    Args:
        eta1_p : (..., K_p)
        eta2_p : (..., K_p, K_p)
        eta1_q : (..., K_q)
        eta2_q : (..., K_q, K_q)
        Phi    : (..., K_p, K_q) — morphism Φ: B_q → B_p

    Returns:
        grad_eta2_p : (..., K_p, K_p)
    """

    # Get (μ_p, Σ_p) from η₂_p
    eta2_inv_p = safe_inv(eta2_p, eps=eps)
    mu_p = -0.5 * np.einsum("...ij,...j->...i", eta2_inv_p, eta1_p)
    sigma_p = -0.5 * eta2_inv_p

    # Target (morphed) η₂ from q
    bar_eta2_Phi_q = compute_bar_eta2_q_morphed(eta2_q, Phi, eps=eps)
    grad_sigma_p = 2.0 * eta2_p - bar_eta2_Phi_q

    # μ_p contribution
    grad_mu_p = grad_mu_p_morphism_feedback(eta1_p, eta2_p, eta1_q, eta2_q, Phi, eps=eps)

    return grad_eta2_from_sigma_mu(grad_sigma_p, grad_mu_p, mu_p, sigma_p)



def grad_eta2_pi_alignment(eta1_pi, eta2_pi, eta1_pj, eta2_pj, Omega_tilde_ij, eps=1e-8):
    """
    Compute:
        ∇_{η2_pi} D_KL(p_i || Ω~_ij p_j)
    """
    eta2_inv_pi = safe_inv(eta2_pi, eps=eps)
    mu_pi       = -0.5 * np.einsum("...ij,...j->...i", eta2_inv_pi, eta1_pi)
    sigma_pi    = -0.5 * eta2_inv_pi

    bar_eta2_pj = compute_bar_eta2_qj(eta2_pj, Omega_tilde_ij, eps=eps)
    grad_sigma_pi = 2.0 * eta2_pi - bar_eta2_pj

    grad_mu_pi = grad_mu_pi_alignment(
        eta1_pi, eta2_pi, eta1_pj, eta2_pj, Omega_tilde_ij, eps=eps
    )

    return grad_eta2_from_sigma_mu(grad_sigma_pi, grad_mu_pi, mu_pi, sigma_pi)

def grad_eta2_pj_alignment(
    eta1_pi, eta2_pi,
    eta1_pj, eta2_pj,
    Omega_ij,
    eps=1e-8,
):
    """
    ∇_{η₂_pj} D_KL(p_i || Ω̃_ij p_j)
    """
    from update_terms_eta1_eta2_belief import grad_sigma_qj_alignment
    from natural_params_utils import (
        compute_bar_eta2_q_morphed,
        compute_delta_eta,
        
        grad_eta2_from_sigma_mu,
        natural_to_mu_sigma,
    )

    # Bar η₂ under gauge transport (p_j → p_i frame)
    bar_eta2 = compute_bar_eta2_q_morphed(eta2_pj, Omega_ij, eps=eps)
    bar_eta2 = 0.5 * (bar_eta2 + np.swapaxes(bar_eta2, -1, -2))

    # Δη = η₂_pi⁻¹ η₁_pi − Ω η₂_pj⁻¹ η₁_pj
    delta_eta = compute_delta_eta(eta1_pi, eta2_pi, eta1_pj, eta2_pj, Omega_ij, eps=eps)

    # ∇μ_j: project mismatch backward via Ω
    intermediate = np.einsum("...ij,...j->...i", bar_eta2, delta_eta)
    grad_mu_j = -np.einsum("...ji,...i->...j", Omega_ij, intermediate)

    # Convert natural params to μ, Σ
    mu_i, _ = natural_to_mu_sigma(eta1_pi, eta2_pi, eps=eps)
    mu_j, sigma_j = natural_to_mu_sigma(eta1_pj, eta2_pj, eps=eps)

    # ∇Σ_j via transported Mahalanobis term
    grad_sigma_j = grad_sigma_qj_alignment(mu_i, eta2_pi, mu_j, sigma_j, Omega_ij, eps=eps)
    grad_sigma_j = 0.5 * (grad_sigma_j + np.swapaxes(grad_sigma_j, -1, -2))

    # Project to η₂_pj
    return grad_eta2_from_sigma_mu(grad_sigma_j, grad_mu_j, mu_j, sigma_j)


def grad_sigma_pj_alignment(eta1_pi, eta2_pi, eta1_pj, eta2_pj, Omega_tilde_ij, eps=1e-8):
    """
    Compute:
        ∇_{Σ_pj} D_KL(p_i || Ω~_ij p_j)
    """
    bar_eta2_pj = compute_bar_eta2_qj(eta2_pj, Omega_tilde_ij, eps=eps)
    delta_eta   = compute_delta_eta(eta1_pi, eta2_pi, eta1_pj, eta2_pj, Omega_tilde_ij, eps=eps)
    eta2_inv_pi = safe_inv(eta2_pi, eps=eps)

    term2 = np.einsum("...ik,...kl,...lj->...ij", bar_eta2_pj, eta2_inv_pi, bar_eta2_pj)
    outer = np.einsum("...i,...j->...ij", delta_eta, delta_eta)
    term3 = 0.5 * np.einsum("...ik,...kl,...lj->...ij", bar_eta2_pj, outer, bar_eta2_pj)

    inner = bar_eta2_pj + term2 + term3
    grad_sigma_pj = np.einsum("...ki,...ij,...jl->...kl", Omega_tilde_ij, inner, Omega_tilde_ij)
    return grad_sigma_pj
