# -*- coding: utf-8 -*-
"""
Created on Wed Jul 23 06:38:17 2025

@author: chris and christine
"""
import numpy as np
import config
import numpy as np
from scipy.linalg import inv
from numerical_utils import safe_inv, sanitize_sigma
from generalized_omega import exp_lie_algebra_irrep, compute_curvature_gradient_analytical
from natural_gradient import dexpinv_operator, dexpinv_operator_covariance, compute_fisher_geometry_gradient, compute_inverse_fisher_field_natural
from omega import get_exp_phi
from natural_params_utils import compute_bar_eta2_qj,compute_delta_eta
from generalized_math_utils import apply_regularization_terms_lie_natural

#==============================================================================
#
#                    GATHER PHI GAUGE FIELD GRADIENT TERMS
#                          Beliefs and Models
#==============================================================================



def accumulate_phi_gradient_belief(agent_i, agent_j, generators, params):
    """
    Compute and apply natural gradient:
        ∇_{φ_i} KL(q_i || Ω_ij q_j)
        ∇_{φ_j} KL(q_i || Ω_ij q_j)
    using natural parameter gradients and dexpinv projection.
    Optionally clips the φ gradients.
    """
    beta = params.get("beta", config.beta)
    if beta <= 0:
        return

    eps = config.support_cutoff_eps
    joint_mask = (agent_i.mask > eps) & (agent_j.mask > eps)  # (H, W)
    joint_mask = joint_mask.astype(float)[..., None]          # (H, W, 1)

    eta1_qi, eta2_qi = agent_i.eta1_q_field, agent_i.eta2_q_field
    eta1_qj, eta2_qj = agent_j.eta1_q_field, agent_j.eta2_q_field

    exp_phi_i = get_exp_phi(agent_i.phi, generators)
    exp_phi_j = get_exp_phi(agent_j.phi, generators)
    Omega_ij  = np.einsum("...ik,...kj->...ij", exp_phi_i, np.swapaxes(exp_phi_j, -1, -2))

    d = generators.shape[0]
    grad_phi_i_raw = np.stack([
        grad_alignment_phi_i_natural(eta1_qi, eta2_qi, eta1_qj, eta2_qj, Omega_ij, generators[a], eps=config.eps)
        for a in range(d)
    ], axis=-1)

    grad_phi_j_raw = np.stack([
        grad_alignment_phi_j_natural(eta1_qi, eta2_qi, eta1_qj, eta2_qj, Omega_ij, generators[a], eps=config.eps)
        for a in range(d)
    ], axis=-1)

    F_inv_i = compute_inverse_fisher_field_natural(eta2_qi, generators, mask=joint_mask[..., 0])
    F_inv_j = compute_inverse_fisher_field_natural(eta2_qj, generators, mask=joint_mask[..., 0])

    grad_phi_i_raw = np.einsum("...ab,...b->...a", F_inv_i, grad_phi_i_raw)
    grad_phi_j_raw = np.einsum("...ab,...b->...a", F_inv_j, grad_phi_j_raw)


    grad_phi_i = dexpinv_operator(agent_i.phi, grad_phi_i_raw, generators)
    grad_phi_j = dexpinv_operator(agent_j.phi, grad_phi_j_raw, generators)

    reg_grad_i = apply_regularization_terms_lie_natural(
        agent=agent_i,
        phi_field=agent_i.phi,
        generators=generators,  # use belief generators here
        field="phi",
        params=params,
    )

    agent_i.grad_phi += (beta * grad_phi_i + reg_grad_i) * joint_mask
    agent_j.grad_phi += beta * grad_phi_j * joint_mask
    
    #accumulate_phi_gradient_from_morphism_self(agent_i, generators, params)


def accumulate_phi_gradient_model(agent_i, agent_j, generators, params):
    """
    Compute and apply natural gradient update for model fiber alignment:
        ∇_{φ̃_i} KL(p_i || Ω̃_ij p_j)
        ∇_{φ̃_j} KL(p_i || Ω̃_ij p_j)
    """
    beta_model = params.get("beta_model", config.beta_model)
    if beta_model <= 0:
        return

    eps = config.support_cutoff_eps
    joint_mask = ((agent_i.mask > eps) & (agent_j.mask > eps)).astype(float)[..., None]

    eta1_pi, eta2_pi = agent_i.eta1_p_field, agent_i.eta2_p_field
    eta1_pj, eta2_pj = agent_j.eta1_p_field, agent_j.eta2_p_field

    exp_phi_i = get_exp_phi(agent_i.phi_model, generators)
    exp_phi_j = get_exp_phi(agent_j.phi_model, generators)
    Omega_tilde_ij = np.einsum("...ik,...kj->...ij", exp_phi_i, np.swapaxes(exp_phi_j, -1, -2))

    d = generators.shape[0]
    grad_phi_i_raw = np.stack([
        grad_alignment_phi_i_natural(eta1_pi, eta2_pi, eta1_pj, eta2_pj, Omega_tilde_ij, generators[a], eps=config.eps)
        for a in range(d)
    ], axis=-1)

    grad_phi_j_raw = np.stack([
        grad_alignment_phi_j_natural(eta1_pi, eta2_pi, eta1_pj, eta2_pj, Omega_tilde_ij, generators[a], eps=config.eps)
        for a in range(d)
    ], axis=-1)

    F_inv_i = compute_inverse_fisher_field_natural(eta2_pi, generators, mask=joint_mask[..., 0])
    F_inv_j = compute_inverse_fisher_field_natural(eta2_pj, generators, mask=joint_mask[..., 0])

    grad_phi_i_raw = np.einsum("...ab,...b->...a", F_inv_i, grad_phi_i_raw)
    grad_phi_j_raw = np.einsum("...ab,...b->...a", F_inv_j, grad_phi_j_raw)

    grad_phi_i = dexpinv_operator(agent_i.phi_model, grad_phi_i_raw, generators)
    grad_phi_j = dexpinv_operator(agent_j.phi_model, grad_phi_j_raw, generators)

    reg_grad_i = apply_regularization_terms_lie_natural(
        agent=agent_i,
        phi_field=agent_i.phi_model,
        generators=generators,
        field="phi_model",
        params=params,
    )

    agent_i.grad_phi_tilde += (beta_model * grad_phi_i + reg_grad_i) * joint_mask
    agent_j.grad_phi_tilde += beta_model * grad_phi_j * joint_mask

   # accumulate_phi_model_gradient_from_morphism_feedback(agent_i, generators, params)


def clip_gradient_norm(grad_field, max_norm, eps=1e-8):
    """
    Clips the norm of a (..., d)-shaped gradient field to max_norm.

    Args:
        grad_field : np.ndarray of shape (..., d)
        max_norm   : float, maximum allowed L2 norm
        eps        : float, stability term to avoid division by zero

    Returns:
        grad_field_clipped : np.ndarray of same shape (..., d)
    """
    norm = np.linalg.norm(grad_field, axis=-1, keepdims=True)  # (..., 1)
    clip_coef = np.minimum(1.0, max_norm / (norm + eps))       # (..., 1)
    return grad_field * clip_coef

#==============================================================================
#
#                    NATURAL PARAMETER GRADIENTS
#                       
#==============================================================================


#validated 7-26-25
def grad_alignment_phi_j_natural(
    eta1_qi, eta2_qi,
    eta1_qj, eta2_qj,
    Omega_ij, G_a_R,
    eps=1e-8
):
    eta2_qi_inv = safe_inv(eta2_qi, eps=eps)        # (..., K, K)
    eta2_qj_inv = safe_inv(eta2_qj, eps=eps)        # (..., K, K)
    bar_eta = compute_bar_eta2_qj(eta2_qj, Omega_ij, eps=eps)  # (..., K, K)
    delta_eta = compute_delta_eta(eta1_qi, eta2_qi, eta1_qj, eta2_qj, Omega_ij, eps=eps)  # (..., K)

    # G_eta = η2_qj⁻¹ G_a^R + G_a^R η2_qj⁻¹
    G_eta = np.einsum("...ik,kl->...il", eta2_qj_inv, G_a_R) + \
            np.einsum("kl,...lj->...kj", G_a_R, eta2_qj_inv)  # (..., K, K)
    
    # --- Term 1 ---
    tmp1 = np.einsum("...ik,...kl->...il", Omega_ij, G_eta)                  # (..., K, K)
    tmp1 = np.einsum("...ij,...jk->...ik", tmp1, Omega_ij.swapaxes(-1, -2))  # (..., K, K)
    tmp1 = np.einsum("...ik,...kl->...il", bar_eta, tmp1)                    # (..., K, K)
    tmp1 = np.einsum("...ij,...jk->...ik", eta2_qi_inv, tmp1)                # (..., K, K)
    tmp1 = np.einsum("...ik,...kj->...ij", tmp1, bar_eta)                    # (..., K, K)
   
    term1 = np.trace(tmp1, axis1=-2, axis2=-1)                               # (...,)
   
    # --- Term 2 ---
    tmp2 = np.einsum("...ik,...kl->...il", Omega_ij, G_eta)                  # (..., K, K)
    tmp2 = np.einsum("...ij,...jk->...ik", tmp2, Omega_ij.swapaxes(-1, -2))  # (..., K, K)
    tmp2 = np.einsum("...ik,...kj->...ij", bar_eta, tmp2)                    # (..., K, K)
   
    term2 = np.trace(tmp2, axis1=-2, axis2=-1)                               # (...,)
    
    # --- Term 3 (correct order) ---
    eta_push = np.einsum("...ij,...j->...i", eta2_qj_inv, eta1_qj)     # (..., K)
    term3_vec = np.einsum("...ij,...j->...i", bar_eta, eta_push)       # (..., K)
    term3_outer = np.einsum("...i,...j->...ij", term3_vec, delta_eta)  # (..., K, K)
    OmegaG = np.einsum("...ik,kl->...il", Omega_ij, G_a_R)              # (..., K, K)
    term3_scalar = 0.25 * np.trace(np.einsum("...ij,...jk->...ik", term3_outer, OmegaG), axis1=-2, axis2=-1)

    
    # --- Term 4 ---
    tmp4 = np.einsum("...ij,...j->...i", eta2_qj_inv, eta1_qj)              # (..., K)
    tmp4 = np.einsum("jk,...k->...j", G_a_R.T, tmp4)                        # (..., K)
    tmp4 = np.einsum("...ij,...j->...i", Omega_ij.swapaxes(-1, -2), tmp4)   # (..., K)
    tmp4 = np.einsum("...ij,...j->...i", bar_eta, tmp4)                     # (..., K)
    
    term4_scalar = np.einsum("...i,...i->...", tmp4, delta_eta)
           
    # --- Term 5 ---
    tmp5 = np.einsum("...ik,...kl->...il", Omega_ij, G_eta)                 # (..., K, K)
    tmp5 = np.einsum("...ij,...jk->...ik", tmp5, Omega_ij.swapaxes(-1, -2)) # (..., K, K)
    tmp5 = np.einsum("...ik,...kl->...il", bar_eta, tmp5)                  # (..., K, K)
    tmp5 = np.einsum("...ij,...jk->...ik", tmp5, bar_eta)                  # (..., K, K)
    
    tmp5_vec = np.einsum("...ij,...j->...i", tmp5, delta_eta)              # (..., K)
   
    term5 = np.einsum("...i,...i->...", delta_eta, tmp5_vec)               # (...,)
    
    # --- Final Gradient ---
    grad = term1 - term2 + 0.25 * (term3_scalar - term4_scalar + term5)
   
    return grad

#Validated 7-26-25
def grad_alignment_phi_i_natural(
    eta1_qi, eta2_qi,
    eta1_qj, eta2_qj,
    Omega_ij,
    G_a,  # generator G_a (K,K)
    eps=1e-8
):
    """
    Compute ∂/∂φ_i^a D_KL(q_i || Ω_ij q_j) as per natural param gradient derivation.

    Shapes:
        eta1_qi, eta1_qj : (..., K)
        eta2_qi, eta2_qj : (..., K, K)
        Omega_ij         : (..., K, K)
        G_a              : (K, K)
    Returns:
        grad_phi_i_a     : (...) scalar per spatial point
    """
    # Step 1: Compute inverses and bar_eta2
    eta2_qi_inv = safe_inv(eta2_qi, eps=eps)                             # (..., K, K)
    eta2_qj_inv = safe_inv(eta2_qj, eps=eps)                             # (..., K, K)
    bar_eta2_qj = compute_bar_eta2_qj(eta2_qj, Omega_ij, eps=eps)       # (..., K, K)
    delta_eta = compute_delta_eta(eta1_qi, eta2_qi, eta1_qj, eta2_qj, Omega_ij, eps=eps)  # (..., K)

    # Step 2: Tr[G_a η2qi⁻¹ bar_eta2_qj] and symmetric term
    term1 = np.einsum("kl,...lm->...km", G_a, eta2_qi_inv)              # G_a η2qi⁻¹
    term1 = np.einsum("...km,...mn->...kn", term1, bar_eta2_qj)        # (..., K, K)
    trace1 = np.einsum("...kk->...", term1)                             # scalar trace

    term2 = np.einsum("lk,...lm->...km", G_a, bar_eta2_qj)             # G_a^T bar_eta
    term2 = np.einsum("...km,...mn->...kn", term2, eta2_qi_inv)
    trace2 = np.einsum("...kk->...", term2)

    term_traces = -trace1 - trace2                                     # (−) first boxed term

    # Step 3: Tr(G_a + G_a^T)
    trace_sym = 0.5 * np.trace(G_a + G_a.T)                             # scalar

    # Step 4: Δηᵀ bar_eta G_a Ω η2_qj⁻¹ η1_qj
    tmp1 = np.einsum("...kl,...l->...k", eta2_qj_inv, eta1_qj)          # (..., K)
    tmp1 = np.einsum("...kl,...l->...k", Omega_ij, tmp1)                # Ω η2⁻¹ η1
    tmp1 = np.einsum("kl,...l->...k", G_a, tmp1)                        # G_a Ω η2⁻¹ η1
    tmp1 = np.einsum("...kl,...l->...k", bar_eta2_qj, tmp1)             # bar_eta G_a ...
    term3 = np.einsum("...k,...k->...", delta_eta, tmp1)                # scalar dot

    # Step 5: η1^T η2⁻¹ Ωᵀ G_a^T bar_eta Δη
    tmp = np.einsum("...ij,...j->...i", eta2_qj_inv, eta1_qj)                 # v1
    tmp = np.einsum("...ji,...i->...j", Omega_ij, tmp)                        # v2
    tmp = np.einsum("ij,...j->...i", G_a.T, tmp)                              # v3
    tmp = np.einsum("...ij,...j->...i", bar_eta2_qj, tmp)                     # v4
    term4 = np.einsum("...i,...i->...", delta_eta, tmp)                       # final contraction


    # Step 6: Δηᵀ (bar_eta G_a + G_a^T bar_eta) Δη
    # Step 6: Δηᵀ (bar_eta G_a + G_a^T bar_eta) Δη

    # First term: bar_eta @ G_a
    tmp1 = np.einsum("...kl,lj->...kj", bar_eta2_qj, G_a)        # (..., K, K)
    tmp1 = np.einsum("...k,...kj->...j", delta_eta, tmp1)        # (..., K)

    # Second term: G_a.T @ bar_eta
    tmp2 = np.einsum("lk,...kl->...l", G_a, bar_eta2_qj)         # (..., K)
    tmp2 = np.einsum("...l,...l->...", delta_eta, tmp2)          # scalar

    # Final contraction
    term5 = np.einsum("...j,...j->...", delta_eta, tmp1) + tmp2


    # Total
    grad = term_traces + trace_sym + 0.25 * (term3 + term4 + term5)
    return grad



from natural_gradient import dexpinv_operator

def apply_regularization_terms(
    phi, phi_tilde, generators,
    curv_weight, mass_weight, coupling_weight,
    agent_i=None, agents=None, fisher_weight=0.0, params=None
):
    """
    Compute total phi regularization gradient and project to natural coordinates.
    Returns:
        grad_nat: (..., d) natural gradient in Lie algebra basis
    """
    if (
        curv_weight == 0 and
        mass_weight == 0 and
        coupling_weight == 0 and
        fisher_weight == 0
    ):
        return np.zeros_like(phi)

    grad_euclidean = 0.0

    if curv_weight > 0:
        grad_curv = compute_curvature_gradient_analytical(phi, generators)
 #       print("Curvature grad norm:", np.linalg.norm(grad_curv))
        grad_euclidean += curv_weight * grad_curv

    if mass_weight > 0:
        grad_mass = 2 * phi
  #      print("Mass grad norm:", np.linalg.norm(grad_mass))
        grad_euclidean += mass_weight * grad_mass

    if coupling_weight > 0:
        grad_coupling = 2 * (phi - phi_tilde)
  #      print("Coupling grad norm:", np.linalg.norm(grad_coupling))
        grad_euclidean += coupling_weight * grad_coupling

    if fisher_weight > 0 and agent_i is not None and agents is not None:
        grad_fisher = compute_fisher_geometry_gradient(agent_i, agents, params)
    #    print("Fisher grad norm:", np.linalg.norm(grad_fisher))
        grad_euclidean += fisher_weight * grad_fisher

    grad_natural = dexpinv_operator(phi, grad_euclidean, generators)
    return grad_natural

