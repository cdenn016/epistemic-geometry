import numpy as np
from natural_params_utils import natural_to_mu_sigma_batch
from numerical_utils import safe_logdet, sanitize_sigma
from generalized_omega import compute_inter_omega_fieldwise
import config


import pickle
import os

import pickle
import numpy as np
from natural_params_utils import compute_mu_sigma_from_natural
from metrics import compute_kl_projected_field_natural
from generalized_diagnostics_metrics import compute_kl_pq_field, compute_kl_qp_field

import config


def compare_kl_metrics_pairwise(step_path, direction="q_to_p"):
    with open(step_path, "rb") as f:
        agents = pickle.load(f)

    N = len(agents)
    mismatches = []

    for i in range(N):
        for j in range(N):
            if i == j:
                continue

            A = agents[i]
            B = agents[j]

            if direction == "q_to_p":
                # KL(p_i || Φ·q_j)
                eta1_p, eta2_p = A.eta1_p_field, A.eta2_p_field
                eta1_q, eta2_q = B.eta1_q_field, B.eta2_q_field
                Phi = B.bundle_morphism_q_to_p  # Φ: q → p
                mask = A.mask
            elif direction == "p_to_q":
                # KL(q_i || Φ̃·p_j)
                eta1_q, eta2_q = A.eta1_q_field, A.eta2_q_field
                eta1_p, eta2_p = B.eta1_p_field, B.eta2_p_field
                Phi = B.bundle_morphism_p_to_q  # Φ̃: p → q
                mask = A.mask
            else:
                raise ValueError("direction must be 'p_to_q' or 'q_to_p'")

            # KL from η-space
            if direction == "q_to_p":
                kl_eta = compute_kl_projected_field_natural(
                    eta1_p, eta2_p,
                    eta1_q, eta2_q,
                    Phi, mask,
                    direction="q_to_p"
                )
            else:  # p_to_q
                kl_eta = compute_kl_projected_field_natural(
                    eta1_q, eta2_q,
                    eta1_p, eta2_p,
                    Phi, mask,
                    direction="p_to_q"
                )

            # KL from μ, Σ space
            if direction == "q_to_p":
                mu_p, sigma_p = natural_to_mu_sigma_batch(eta1_p, eta2_p)
                mu_q, sigma_q = natural_to_mu_sigma_batch(eta1_q, eta2_q)
                kl_mu = compute_kl_pq_field(mu_p, sigma_p, mu_q, sigma_q, Phi, mask)
            else:  # p_to_q
                mu_q, sigma_q = natural_to_mu_sigma_batch(eta1_q, eta2_q)
                mu_p, sigma_p = natural_to_mu_sigma_batch(eta1_p, eta2_p)
                kl_mu = compute_kl_qp_field(mu_q, sigma_q, mu_p, sigma_p, Phi, mask)

            # Compare
            diff = np.abs(kl_mu - kl_eta)
            support = mask > config.support_cutoff_eps
            max_diff = np.max(diff[support])
            mean_diff = np.mean(diff[support])

            print(f"[{i} → {j}] max ΔKL = {max_diff:.4e}, mean ΔKL = {mean_diff:.4e}")
            if max_diff > 1e-3:
                mismatches.append((i, j, max_diff, mean_diff))

    print(f"\nTotal mismatches over threshold: {len(mismatches)}")
    return mismatches




if __name__ == "__main__":
    step_path = "checkpoints/step_0002.pkl"
    compare_kl_metrics_pairwise(step_path, direction="p_to_q")
    compare_kl_metrics_pairwise(step_path, direction="q_to_p")