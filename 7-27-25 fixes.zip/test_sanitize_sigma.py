# test_kl_sanitization.py

import numpy as np
from natural_params_utils import safe_logdet
from generalized_math_utils import kl_divergence
from numerical_utils import sanitize_sigma  # ← Update import if named differently

def generate_bad_covariances(N, K, eps=1e-6):
    """
    Generate N random pathological (possibly non-SPD) K×K covariance matrices.
    """
    rng = np.random.default_rng(42)
    A = rng.normal(size=(N, K, K))
    Sigma = np.einsum("nij,nkj->nik", A, A) / K

    # Inject bad behavior
    perturb = rng.normal(scale=0.2, size=(N, K, K))
    Sigma += 0.1 * (perturb + perturb.transpose(0, 2, 1))
    Sigma *= rng.uniform(0.001, 2.0, size=(N, 1, 1))

    return Sigma

def main():
    N, K = 100, 5
    print(f"[TEST] Generating {N} pathological {K}×{K} covariance matrices...")

    Sigma1 = generate_bad_covariances(N, K)
    Sigma2 = generate_bad_covariances(N, K)
    mu1 = np.random.randn(N, K)
    mu2 = np.random.randn(N, K)

    print("\nBefore sanitization:")
    eigvals_raw = np.linalg.eigvalsh(Sigma1)
    print(f"[Raw Σ] eig min: {eigvals_raw.min():.2e}, max: {eigvals_raw.max():.2e}, mean: {eigvals_raw.mean():.2e}")
    print(f"[Raw Σ] NaNs? {np.isnan(Sigma1).any()}, Infs? {np.isinf(Sigma1).any()}")

    try:
        logdets = safe_logdet(Sigma1)
        print(f"[Raw Σ] log|Σ| min: {logdets.min():.2f}, max: {logdets.max():.2f}, mean: {logdets.mean():.2f}")
    except Exception as e:
        print(f"[Raw Σ] log|Σ| failed: {e}")

    Sigma1_san = sanitize_sigma(Sigma1, eps=1e-6, debug=True)
    Sigma2_san = sanitize_sigma(Sigma2, eps=1e-6)

    print("\nAfter sanitization:")
    eigvals_san = np.linalg.eigvalsh(Sigma1_san)
    print(f"[Sanitized Σ] eig min: {eigvals_san.min():.2e}, max: {eigvals_san.max():.2e}, mean: {eigvals_san.mean():.2e}")
    print(f"[Sanitized Σ] NaNs? {np.isnan(Sigma1_san).any()}, Infs? {np.isinf(Sigma1_san).any()}")

    try:
        logdets_san = safe_logdet(Sigma1_san)
        print(f"[Sanitized Σ] log|Σ| min: {logdets_san.min():.2f}, max: {logdets_san.max():.2f}, mean: {logdets_san.mean():.2f}")
    except Exception as e:
        print(f"[Sanitized Σ] log|Σ| failed: {e}")

    print("\nTesting KL divergence (with internal sanitization)...")
    try:
        kl_vals = kl_divergence(mu1, Sigma1, mu2, Sigma2)
        print(f"[KL] min: {kl_vals.min():.2f}, max: {kl_vals.max():.2f}, mean: {kl_vals.mean():.2f}")
        print(f"[KL] NaNs? {np.isnan(kl_vals).any()}, Infs? {np.isinf(kl_vals).any()}")
        print("✅ KL divergence passed without NaNs or Infs.")
    except Exception as e:
        print(f"[KL] failed: {e}")

if __name__ == "__main__":
    main()
