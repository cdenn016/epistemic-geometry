

import numpy as np
import random
from config import domain_size, support_cutoff_eps
from scipy.linalg import logm, expm
from natural_gradient_utils import sanitize_sigma
from holonomy_utils import construct_spatial_path_nd, transport_belief



from generalized_omega import compute_intra_omega, compute_inter_omega, bch, safe_bch_exact
from scipy.linalg import logm, expm
from numerical_utils import sanitize_sigma, safe_logm
import numpy as np

from natural_params_utils import natural_to_mu_sigma  # eta → (mu, sigma)
from numerical_utils import sanitize_sigma  # ensures Σ is positive-definite
from transport_belief import transport_belief
from omega_operator import compute_intra_omega
from utils_linalg import safe_logm, safe_bch_exact
from scipy.linalg import expm
import numpy as np


def compute_spatial_loop_holonomy(
    agent,
    coords,
    generators,
    use_log_accumulation=False,
    return_deviations=False,
    return_beliefs=False,
    return_path=False,
    initial_belief=None,  # expects (mu, sigma)
):
    """
    Compute holonomy around a closed spatial loop within a single agent.

    Converts η → (μ, Σ) before running, using agent.eta1_q_field and eta2_q_field.

    Returns:
        H
        deviations (if return_deviations=True)
        (mu_seq, sigma_seq) if return_beliefs=True
        path      (if return_path=True)
    """
    print(f"[INFO] Running spatial loop holonomy (log_accum={use_log_accumulation})")

    if len(coords) < 2 or coords[0] != coords[-1]:
        raise ValueError("coords must start and end at the same point")

    # ─── Convert η → μ, Σ ───
    mu_field, sigma_field = natural_to_mu_sigma(agent.eta1_q_field, agent.eta2_q_field)
    agent.mu_q_field = mu_field  # Patch for Ω and transport
    agent.sigma_q_field = sigma_field

    K = generators.shape[-1]
    H = np.eye(K, dtype=float)
    logH = np.zeros((K, K), dtype=float) if use_log_accumulation else None

    deviations = []
    path_out = []

    if return_beliefs:
        if not isinstance(initial_belief, tuple) or len(initial_belief) != 2:
            raise ValueError("initial_belief must be a (mu, sigma) tuple")
        μ = initial_belief[0].copy()
        Σ = sanitize_sigma(initial_belief[1].copy())
        mu_seq = [μ.copy()]
        sigma_seq = [Σ.copy()]

    if return_path:
        path_out.append(coords[0])

    for p0, p1 in zip(coords[:-1], coords[1:]):
        ω = compute_intra_omega(agent, p0, p1, generators)

        if use_log_accumulation:
            logω = safe_logm(ω, context="intra Ω")
            logH = safe_bch_exact(logH, logω)
        else:
            H = ω @ H

        if return_deviations:
            deviations.append(np.linalg.norm(ω - np.eye(K)))

        if return_beliefs:
            μ, Σ = transport_belief(μ, Σ, ω)
            mu_seq.append(μ.copy())
            sigma_seq.append(Σ.copy())

        if return_path:
            path_out.append(p1)

    if use_log_accumulation:
        H = expm(logH)

    # ─── Normalize determinant for SL(2,R) consistency ───
    detH = np.linalg.det(H)
    if not np.isclose(detH, 1.0):
        H /= detH ** (1.0 / float(K))

    outputs = [H]
    if return_deviations:
        outputs.append(deviations)
    if return_beliefs:
        outputs.append((mu_seq, sigma_seq))
    if return_path:
        outputs.append(path_out)

    return tuple(outputs) if len(outputs) > 1 else H



from generalized_omega import compute_intra_omega
from holonomy_utils import construct_spatial_path_nd  # or however your path module is called
from numerical_utils import sanitize_sigma
from scipy.linalg import logm, expm

import numpy as np
import config  # for domain_size

def compute_agent_cycle_holonomy(
    agents,
    agent_cycle,
    overlap_points,
    generators,
    initial_belief=None,
    return_deviations=False,
    return_logm=False,
    return_beliefs=False,
    return_path=False,
    use_log_accumulation=False,
):
    """
    Compute holonomy around a closed loop of agents.
    Returns:
      H, deviations?, logH?, (μ_seq, Σ_seq)?, path?
    """
    if len(agent_cycle) < 2 or agent_cycle[0] != agent_cycle[-1]:
        raise ValueError("agent_cycle must start and end at the same agent")
    if len(overlap_points) != len(agent_cycle) - 1:
        raise ValueError("Mismatch between cycle and overlap points")

    K = generators.shape[-1]
    H = np.eye(K)
    logH = np.zeros((K, K)) if use_log_accumulation else None
    deviations, full_path = [], []

    if return_beliefs:
        if not isinstance(initial_belief, tuple) or len(initial_belief) != 2:
            raise ValueError("initial_belief must be (μ, Σ)")
        μ, Σ = initial_belief
        Σ = sanitize_sigma(Σ)
        mu_seq = [μ.copy()]
        sigma_seq = [Σ.copy()]

    current_pos = tuple(agents[agent_cycle[0]].center)
    current_agent = agent_cycle[0]
    if return_path:
        full_path.append(current_pos)

    # ─── Helper: Accumulate one Ω or ω ───
    def apply_omega(Ω):
        nonlocal H, logH, μ, Σ
        if use_log_accumulation:
            logΩ = safe_logm(Ω, context="Ω")
            logH = safe_bch_exact(logH, logΩ)
        else:
            H = Ω @ H
        if return_deviations:
            deviations.append(np.linalg.norm(Ω - np.eye(K)))
        if return_beliefs:
            μ, Σ = transport_belief(μ, Σ, Ω)
            mu_seq.append(μ.copy())
            sigma_seq.append(Σ.copy())

    # ─── Helper: Intra-agent transport from current_pos to overlap_pt ───
    def intra_leg(agent_id, start, end):
        path = construct_spatial_path_nd(start, end, config.domain_size,
                                         mask=agents[agent_id].mask)
        for p0, p1 in zip(path[:-1], path[1:]):
            ω = compute_intra_omega(agents[agent_id], p0, p1, generators)
            apply_omega(ω)
            if return_path:
                full_path.append(p1)
        return path[-1]

    # ─── Main loop ─────────────────────────────────────────────
    for next_agent, overlap_pt in zip(agent_cycle[1:], overlap_points):
        current_pos = intra_leg(current_agent, current_pos, overlap_pt)

        Ω = compute_inter_omega(
            agents[current_agent],
            agents[next_agent],
            overlap_pt,
            generators,
        )
        apply_omega(Ω)
        if return_path:
            full_path.append(overlap_pt)

        current_agent = next_agent
        current_pos = overlap_pt

    # ─── Final leg: back to center of agent[0] ─────────────────
    final_target = tuple(agents[agent_cycle[0]].center)
    final_path = construct_spatial_path_nd(
        current_pos, final_target, config.domain_size,
        mask=agents[current_agent].mask,
    )
    invalid = [p for p in final_path if agents[current_agent].mask[p] <= config.support_cutoff_eps]
    if invalid:
        msg = f"[Holonomy] Return path from {current_pos} to {final_target} contains {len(invalid)} unsupported points"
        if getattr(config, "raise_on_path_violation", True):
            raise ValueError(msg)
        else:
            print(f"[WARNING] {msg} Proceeding anyway.")

    for p0, p1 in zip(final_path[:-1], final_path[1:]):
        ω = compute_intra_omega(agents[current_agent], p0, p1, generators)
        apply_omega(ω)
        if return_path:
            full_path.append(p1)

    if use_log_accumulation:
        H = expm(logH)

    # ─── Project to SL(K) ───
    detH = np.linalg.det(H)
    if not np.isclose(detH, 1.0):
        H /= detH ** (1.0 / K)

    outputs = [H]
    if return_deviations:
        outputs.append(deviations)
    if return_logm:
        outputs.append(logm(H))
    if return_beliefs:
        outputs.append((mu_seq, sigma_seq))
    if return_path:
        outputs.append(full_path)

    return tuple(outputs) if len(outputs) > 1 else H




def sample_self_avoiding_loop_within_mask(
    center,
    mask,
    *,
    min_length=4,
    max_length=75,
    support_cutoff=support_cutoff_eps,
    seed=None
):
    """
    Generate a random self‐avoiding closed loop on a periodic grid,
    staying entirely where mask >= support_cutoff.
    """
    D = len(domain_size)
    rng = random.Random(seed)

    while True:
        visited = {tuple(center)}
        path = [tuple(center)]
        current = np.array(center, dtype=int)
        prev = None

        for _ in range(max_length):
            neighbors = []
            for axis in range(D):
                for d in (-1, +1):
                    nb = list(current)
                    nb[axis] = (nb[axis] + d) % domain_size[axis]
                    nb = tuple(nb)
                    if np.all(mask[nb] >= support_cutoff):
                        neighbors.append(nb)

            if tuple(center) in neighbors and len(path) >= min_length:
                path.append(tuple(center))
                return path

            candidates = [nb for nb in neighbors if nb != prev and nb not in visited]
            if not candidates:
                break

            nxt = rng.choice(candidates)
            prev = tuple(current.tolist())
            current = np.array(nxt, dtype=int)
            visited.add(nxt)
            path.append(nxt)

        continue
