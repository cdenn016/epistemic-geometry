import numpy as np
import itertools as it
import networkx as nx
import matplotlib.pyplot as plt
from matplotlib import cm
from pathlib import Path
import json

# --- Project-specific imports ---
import config
from config import checkpoint_dir, group_name, K_q, K_p, log_eps, overlap_eps

from generalized_io_utils import (
    load_final_step,
    load_agents,
    save_generic_alignment_data,
    save_meta_agents,
    load_meta_agents,
    save_meta_labels,
    load_meta_data,
)

from generalized_omega import (
    compute_field_strength,
    compute_inter_omega,
    batch_apply_omega,
   )
from numerical_utils import sanitize_sigma
from generalized_math_utils import  kl_divergence

def transport_covariance_batch(Sigma, Omega):
    """
    Transport a batch of covariance matrices: Σ → Ω Σ Ωᵀ

    Parameters:
        Sigma: (N, K, K) — batch of covariance matrices
        Omega: (N, K, K) — batch of transport operators

    Returns:
        Sigma_t: (N, K, K) — transported covariances
    """
    return Omega @ Sigma @ np.transpose(Omega, (0, 2, 1))


def aggregate_fields(agent_list, attr: str):
    """Average a tensor field (e.g., mu_q_field) over agents."""
    return np.mean([getattr(ag, attr) for ag in agent_list], axis=0)


def aggregate_mask(agent_list, eps: float = 1e-3):
    """Compute union of support masks across agents."""
    masks = [(ag.mask > eps).astype(float) for ag in agent_list]
    return np.clip(np.sum(masks, axis=0), 0, 1)



def curvature_mean_per_agent(agents, generators) -> np.ndarray:
    """
    Compute ⟨Tr(F_{μν} F^{μν})⟩ for each agent using field strength from generalized_omega.
    Only includes values inside the agent's support.
    """
    eps = getattr(config, "support_cutoff_eps", 1e-3)
    means = []

    for i, ag in enumerate(agents):
        try:
            mask = ag.mask > eps
            F_dict = compute_field_strength(ag.phi, generators)
            H, W = ag.phi.shape[:2]

            total_energy = 0.0
            count = np.sum(mask)

            for F_name, F in F_dict.items():
                if F.ndim != 4 or F.shape[-2:] != (generators.shape[1], generators.shape[2]):
                    print(f"[!] Skipping invalid F[{F_name}] shape: {F.shape}")
                    continue

                # Compute Tr(F²) per point: sum_ij F_ij²
                pointwise_energy = np.einsum("...ij,...ij->...", F, F)  # (H, W)
                total_energy += np.sum(pointwise_energy[mask])

            mean_energy = total_energy / count if count > 0 else 0.0
            means.append(mean_energy)

        except Exception as e:
            print(f"[!] Failed to compute curvature for agent {i}: {e}")
            means.append(0.0)

    return np.array(means)




def compute_phi_variance_per_cluster(agents, labels):
    """
    Compute φ-norm variance for each cluster of agents.

    Returns:
        stats: dict {cluster_id: {'phi_means': [...], 'phi_var': float}}
    """
    eps = getattr(config, "support_cutoff_eps", 1e-3)
    stats = {}

    for lab in np.unique(labels):
        if lab < 0:
            continue  # Ignore noise/outlier label

        idx = np.where(labels == lab)[0]
        means = []

        for i in idx:
            agent = agents[i]
            if agent.phi is None:
                continue
            mask = agent.mask > eps
            phi_norm = np.linalg.norm(agent.phi, axis=-1)
            if np.any(mask):
                mean_val = np.mean(phi_norm[mask])
                means.append(float(mean_val))

        if means:
            stats[int(lab)] = {
                'phi_means': means,
                'phi_var': float(np.var(means))
            }

    return stats


def rank_agent_alignment(kl_matrix):
    """
    For each agent i, rank all other agents by ascending KL divergence.
    Returns dict[i] = {"best": j, "worst": k, "full_rank": [j1, j2, ...]}
    """
    N = kl_matrix.shape[0]
    rankings = {}
    for i in range(N):
        dists = kl_matrix[i].copy()
        dists[i] = np.inf  # ignore self
        sorted_idx = np.argsort(dists)
        rankings[i] = {
            "best": int(sorted_idx[0]),
            "worst": int(sorted_idx[-1]),
            "full_rank": sorted_idx.tolist()
        }
    return rankings

def compute_symmetric_kl_matrix(kl_matrix: np.ndarray) -> np.ndarray:
    """
    Compute the symmetrized KL matrix:
        D_sym(i, j) = 0.5 * [ D_KL(q_i || Ω q_j) + D_KL(q_j || Ω⁻¹ q_i) ]
    Args:
        kl_matrix: (N, N) asymmetric KL divergence matrix
    Returns:
        symmetric KL matrix (N, N)
    """
    assert kl_matrix.shape[0] == kl_matrix.shape[1], "KL matrix must be square"
    return 0.5 * (kl_matrix + kl_matrix.T)

def compute_cluster_kl_stats(kl_matrix, labels, verbose=False):
    """
    Compute intra-/extra-cluster KL stats for each cluster.
    Returns dict[cluster_id] = {intra_vals, extra_vals, means, stds}
    """
    stats = {}
    for lab in np.unique(labels):
        if lab < 0:
            continue
        idx = np.where(labels == lab)[0]
        others = np.where(labels != lab)[0]

        # Intra-cluster KL
        intra_vals = kl_matrix[np.ix_(idx, idx)]
        iu = np.triu_indices(len(idx), k=1)
        intra = intra_vals[iu][np.isfinite(intra_vals[iu])]

        # Extra-cluster KL
        extra = kl_matrix[np.ix_(idx, others)].ravel()
        extra = extra[np.isfinite(extra)]

        stats[int(lab)] = {
            'intra_vals': intra,
            'extra_vals': extra,
            'intra_mean': float(np.mean(intra)) if intra.size else np.nan,
            'extra_mean': float(np.mean(extra)) if extra.size else np.nan,
            'intra_std': float(np.std(intra)) if intra.size else np.nan,
            'extra_std': float(np.std(extra)) if extra.size else np.nan,
        }

        if verbose:
            print(f"[cluster {lab}] N={len(idx)}  KL_intra={stats[lab]['intra_mean']:.3f}  KL_extra={stats[lab]['extra_mean']:.3f}")

    return stats

def compute_order_parameter(kl_matrix):
    """
    Compute global condensation order parameter R, based on median KL.
    """
    i, j = np.triu_indices(kl_matrix.shape[0], k=1)
    d = kl_matrix[i, j]
    d = d[np.isfinite(d)]
    sigma = float(np.median(d)) if d.size else 1.0
    R = float(np.sum(np.exp(-d / sigma)) / d.size) if d.size else 0.0
    return R, sigma

def compute_cluster_order_parameters(kl_matrix, labels):
    """
    For each cluster: compute (R_C, sigma_C) based on pairwise KLs.
    Returns dict[cluster_id] = (R, sigma)
    """
    clusters = {}
    for lab in sorted(set(labels)):
        if lab < 0:
            continue
        idx = np.where(labels == lab)[0]
        if len(idx) < 2:
            clusters[lab] = (1.0, 0.0)
            continue

        sub = kl_matrix[np.ix_(idx, idx)]
        i, j = np.triu_indices(len(idx), k=1)
        vals = sub[i, j][np.isfinite(sub[i, j])]

        sigma = float(np.median(vals)) if vals.size else 1.0
        R = float(np.mean(np.exp(-vals / sigma))) if sigma > 0 else 1.0
        clusters[lab] = (R, sigma)
    return clusters

def find_meta_agents(sym_kl, overlap_area, curv_mean, tau_A=10, eta=10, tau_C=10, verbose=False):
    """
    Identify meta-agent clusters based on KL, curvature, and overlap graph.
    """
    N = sym_kl.shape[0]
    finite_vals = sym_kl[np.isfinite(sym_kl)]
    eps = np.quantile(finite_vals, 0.30)
    eps = max(eps, getattr(config, "epsilon_model", 1e-6))

    # Build connectivity graph
    G = nx.Graph()
    G.add_nodes_from(range(N))
    for i, j in it.combinations(range(N), 2):
        d = sym_kl[i, j]
        if np.isfinite(d) and d <= eps:
            G.add_edge(i, j, weight=d)

    # Connected components as candidate meta-agents
    meta = []
    for comp in nx.connected_components(G):
        C = list(comp)
        if len(C) < 2:
            continue

        out_set = list(set(range(N)) - set(C))
        intra = sym_kl[np.ix_(C, C)][np.triu_indices(len(C), k=1)]
        extra = sym_kl[np.ix_(C, out_set)].ravel()
        intra = intra[np.isfinite(intra)]
        extra = extra[np.isfinite(extra)]

        intra_mean = float(np.mean(intra)) if intra.size else np.inf
        extra_mean = float(np.mean(extra)) if extra.size else np.inf
        curv_mean_C = float(np.mean(curv_mean[C])) if len(C) else np.inf

        accept = (intra_mean < tau_A and curv_mean_C < tau_C and
                  (extra.size == 0 or intra_mean < eta * extra_mean))

        if accept:
            meta.append(C)
            if verbose:
                print(f"[✓] meta-cluster size={len(C)}, <KL_intra>={intra_mean:.3f}, <KL_extra>={extra_mean:.3f}, <curv>={curv_mean_C:.3f}")

    labels = np.full(N, -1, dtype=int)
    for k, C in enumerate(meta):
        labels[np.array(C)] = k

    return meta, labels, eps


def overlap_area_matrix(agents, eps: float = 1e-6) -> np.ndarray:
    """
    Compute N x N matrix where entry (i, j) is the area of overlap between agent i and j.
    """
    N = len(agents)
    area = np.zeros((N, N), dtype=float)
    for i in range(N):
        mask_i = agents[i].mask > eps
        for j in range(i, N):
            if i == j:
                area[i, j] = np.sum(mask_i)
            else:
                mask_j = agents[j].mask > eps
                area_ij = np.sum(np.logical_and(mask_i, mask_j))
                area[i, j] = area[j, i] = area_ij
    return area




