# -*- coding: utf-8 -*-
"""
Created on Sat Jul 19 08:23:33 2025

@author: chris and christine
"""


# === generalized_update_rules.py (refactor patch) ===
import numpy as np
import config
from joblib import Parallel, delayed

from natural_gradient_utils import (
    apply_natural_gradient_batch,
    apply_lie_natural_gradient,
    compute_inverse_fisher_field
)
from generalized_diagnostics_metrics import compute_alignment_field_general
from update_terms_belief import combine_field_gradients_belief, compute_phi_update_belief, grad_morphism_feedback_energy
from update_terms_model import combine_field_gradients_model, compute_phi_update_model, grad_morphism_self_energy
from numerical_utils import sanitize_sigma

from generalized_omega import exp_lie_algebra_irrep
from scipy.linalg import solve_triangular  # or np.linalg.solve per batch
from generalized_math_utils import batch_matrix_inverse, safe_batch_inverse, preprocess_agent_fields


from bundle_update_terms import compute_phi_tilde_morphism_update, compute_phi_morphism_update

from get_generators import RhoFunction  # or however you're loading rho


def compute_all_gradients(i, agents, params):
    ai = agents[i]

    # Field gradients
    # Belief field gradients
    dq_mu, dq_sigma = combine_field_gradients_belief(ai, agents, params, field_type="belief")
    # Model field gradients
    dp_mu, dp_sigma = combine_field_gradients_model(ai, agents, params, field_type="model")

    # Gauge fields (phi and phi_model)
    # Belief field update
    dphi = compute_phi_update_belief(ai, agents, params, field="phi")
    # Model field update
    dphi_m = compute_phi_update_model(ai, agents, params, field="phi_model")

    # Bundle morphism gradient (only compute, no update)
    # Direct call to `grad_morphism_feedback_energy` for the gradient for Phi
    dPhi = grad_morphism_feedback_energy(ai, params.get("model_feedback_weight", config.model_feedback_weight), mask=ai.mask)  # Only compute gradient

    # Correct call for dPhi_tilde: Use grad_morphism_self_energy for the gradient for Phĩ
    dPhi_tilde = grad_morphism_self_energy(ai, params.get("alpha", config.alpha), mask=ai.mask)  # Correct gradient computation

    # Fallback to zero if the gradient is skipped (although it should always be computed)
    if dPhi is None:
        dPhi = np.zeros_like(ai.bundle_morphism_q_to_p)
    if dPhi_tilde is None:
        dPhi_tilde = np.zeros_like(ai.bundle_morphism_p_to_q)

    return (dq_mu, dq_sigma), (dp_mu, dp_sigma), dphi, dphi_m, dPhi, dPhi_tilde






# --- Shared η scaling helper ---
def compute_adaptive_eta(base_eta, grad, cached_kl, sigma_field, scaling_kl, scaling_cond, eta_min):
    """
    Computes adaptive step size η based on KL alignment and condition number of Σ.
    """
    kl_term = (
        np.mean(cached_kl)
        if cached_kl is not None and np.isfinite(np.mean(cached_kl))
        else np.mean(np.abs(grad))
    )

    try:
        conds = np.linalg.cond(sigma_field.reshape(-1, sigma_field.shape[-2], sigma_field.shape[-1]))
        cond_avg = np.mean(conds)
    except Exception:
        cond_avg = 1.0

    denom = 1.0 + scaling_kl * kl_term + scaling_cond * cond_avg
    eta_scaled = base_eta / denom
    return np.clip(eta_scaled, eta_min, base_eta)



def apply_phi_updates(agent, grad_phi, grad_phi_m, mask, params):
    mask_exp = mask[..., None]

    def clip_lie_update(delta, threshold):
        if threshold <= 0:
            return delta
        norm = np.linalg.norm(delta, axis=-1, keepdims=True)
        factor = np.minimum(1.0, threshold / (norm + 1e-8))
        return delta * factor

    # Extract config safely
    cfg = vars(config) if params is None else {**vars(config), **params}

    # φ adaptive update
    eta_phi_tuned = compute_adaptive_eta(
        cfg["eta_base_phi"],
        grad_phi,
        getattr(agent, "cached_alignment_kl", None),
        agent.sigma_q_field,
        cfg["eta_phi_adaptive_scaling"],
        cfg["eta_sigma_condition_scaling"],
        cfg["eta_phi_min"],
    )
    delta_phi = eta_phi_tuned * grad_phi
    delta_phi = clip_lie_update(delta_phi, cfg.get("phi_grad_clip_threshold", 0.0))
    delta_phi = np.nan_to_num(delta_phi, nan=0.0, posinf=1e5, neginf=-1e5)
    agent.phi -= delta_phi * mask_exp

    # φ̃ adaptive update
    eta_phi_m_tuned = compute_adaptive_eta(
        cfg["eta_base_phi_model"],
        grad_phi_m,
        getattr(agent, "cached_model_alignment_kl", None),
        agent.sigma_p_field,
        cfg["eta_phi_model_adaptive_scaling"],
        cfg["eta_sigma_condition_scaling"],
        cfg["eta_phi_model_min"],
    )
    delta_phi_m = eta_phi_m_tuned * grad_phi_m
    delta_phi_m = clip_lie_update(delta_phi_m, cfg.get("phi_model_grad_clip_threshold", 0.0))
    delta_phi_m = np.nan_to_num(delta_phi_m, nan=0.0, posinf=1e5, neginf=-1e5)
    agent.phi_model -= delta_phi_m * mask_exp




def synchronous_step(agents, generators_q, generators_p, params=None, n_jobs=1):
    params = params or {}
    N = len(agents)
    print(f"[DEBUG] Using {n_jobs} workers in synchronous_step")

    # Step 1: Preprocess Fisher, exp(φ), etc.
    Parallel(n_jobs=n_jobs, backend="threading", batch_size=1)(
        delayed(preprocess_agent_fields)(A, params) for A in agents
    )

    # Step 2: Refresh KL alignment caches
    for A in agents:
        A.cached_alignment_kl       = compute_alignment_field_general(agents, A.id, field_type="belief", log_eps=config.eps)
        A.cached_model_alignment_kl = compute_alignment_field_general(agents, A.id, field_type="model",  log_eps=config.eps)

    # Step 3: Compute all gradients (including morphism gradients)
    grads = Parallel(n_jobs=n_jobs, backend="loky", batch_size=2)(  # Parallelize gradient computations
        delayed(compute_all_gradients)(i, agents, params) for i in range(N)
    )
    q_updates, p_updates, phi_grads, phi_m_grads, morphism_grads, morphism_tilde_grads = zip(*grads)
    mask_list = [A.mask for A in agents]

    eta_q = params.get("eta_q", config.eta_q)
    eta_p = params.get("eta_p", config.eta_p)
    lr_phi     = params.get("phi_morphism_lr", getattr(config, "phi_morphism_lr", 1e-3))
    lr_phi_til = params.get("phi_tilde_morphism_lr", getattr(config, "phi_tilde_morphism_lr", 1e-3))

    # Step 4: Apply all updates
    def apply_agent_updates(i):
        agent = agents[i]
        mask = mask_list[i]

        Δμ_q, ΔΣ_q = q_updates[i]
        Δμ_p, ΔΣ_p = p_updates[i]
        dPhi       = morphism_grads[i]
        dPhi_tilde = morphism_tilde_grads[i]

        mask_mu    = mask[..., None]
        mask_sigma = mask[..., None, None]

        # Apply updates for belief and model fields
        agent.mu_q_field    -= eta_q * Δμ_q * mask_mu
        agent.sigma_q_field -= eta_q * ΔΣ_q * mask_sigma
        agent.mu_p_field    -= eta_p * Δμ_p * mask_mu
        agent.sigma_p_field -= eta_p * ΔΣ_p * mask_sigma

        agent.sigma_q_field = sanitize_sigma(agent.sigma_q_field)
        agent.sigma_p_field = sanitize_sigma(agent.sigma_p_field)

        # Apply phi field updates
        apply_phi_updates(agent, phi_grads[i], phi_m_grads[i], mask, params)

        # Apply morphism updates (single location for both morphisms)
        agent.bundle_morphism_p_to_q -= lr_phi_til * dPhi_tilde              # Update for Φ̃ : P → Q
        agent.bundle_morphism_q_to_p -= lr_phi * dPhi  # Update for Φ : Q → P

        return agent

    agents = Parallel(n_jobs=n_jobs, backend="threading", batch_size=1)(  # Apply updates in parallel
        delayed(apply_agent_updates)(i) for i in range(N)
    )

    return agents


