from __future__ import annotations
"""
Created on Tue Aug 12 20:36:43 2025

@author: chris and christine
"""
# -*- coding: utf-8 -*-
"""run_sim_utils — streamlined"""

import os, sys, time, pickle, shutil
from pathlib import Path
from typing import Dict, List, Tuple
import numpy as np
import core.config as config

# Re-export for callers (__main__/generalized_simulation)
from core.config_utils import set_config_from_params  # keep name/behavior

# Core deps
from core.get_generators import get_generators
from core.agent_initialization import initialize_agents, initialize_agent_gradients
from runtime_context import ensure_runtime_defaults

# Diagnostics & metrics (single source of truth)
from generalized_diagnostics_metrics import (
    log_all_metrics, dump_snapshot_npz, compute_total_free_energy,
    compute_crossscale_kl_q_single, compute_crossscale_kl_p_single,
)

# Optional viz helpers (thin wrappers)
from data.viz_parent_masks import (
    save_parent_mask_frame, save_parent_mask_delta, plot_parent_masks_grid, save_alignment_vs_parents
)


# Optional transport-cache hooks (if available)
try:
    from transport.transport_cache import Lambda_up, Lambda_dn  # type: ignore
except Exception:  # module may be absent in some runs
    Lambda_up = Lambda_dn = None

# ------------------------------- Logging defaults ----------------------------
LOGGING_DEFAULTS: Dict = dict(
    enable_scalar=True,
    print_total_energy=True,
    normalize_by_support=True,
    print_crossscale=True,
    log_link_norms=True,
    log_typical_grads=True,
    typical_grad_agent_id=1,
    enable_fields=True,
    fields_every=1,
    full_field_outdir="fields",
    snapshot_mode="full",  # "crucial" | "full"
    fp16_snapshot=True,
    compute_alignment=True,
    compute_curvature=True,
    parent_snapshot_every=1,
    parent_snapshot_dir="parents",
    child_snapshot_every=1,
    child_snapshot_dir="children",
    snapshot_include_levels="both",  # "both" | "children" | "parents"
    store_levels=True,
    schema_version="v3",
)


def load_checkpoint(outdir: str):
    # prefer compressed if present
    for name in ("checkpoint.pkl.xz", "checkpoint.pkl"):
        p = os.path.join(outdir, name)
        if os.path.exists(p):
            if name.endswith(".xz"):
                import lzma
                with lzma.open(p, "rb") as f:
                    return pickle.load(f), name
            with open(p, "rb") as f:
                return pickle.load(f), name
    # fall back to last step_XXXX
    step_files = sorted([f for f in os.listdir(outdir) if f.startswith("step_") and (f.endswith(".pkl") or f.endswith(".pkl.xz"))])
    if not step_files: return (None, None)
    last = step_files[-1]
    if last.endswith(".xz"):
        import lzma
        with lzma.open(os.path.join(outdir, last), "rb") as f:
            return pickle.load(f), last
    with open(os.path.join(outdir, last), "rb") as f:
        return pickle.load(f), last


def find_resume_step(outdir: str) -> int:
    step_files = sorted([f for f in os.listdir(outdir) if f.startswith("step_") and (f.endswith(".pkl") or f.endswith(".pkl.xz"))])
    if not step_files: return 0
    last = step_files[-1]
    num = last.replace("step_", "").replace(".pkl.xz","").replace(".pkl","")
    try: return int(num) + 1
    except: return 0




def merge_logging_cfg(params_or_cfg) -> Dict:
    cfg = {}
    if hasattr(params_or_cfg, "get"):       # dict-like
        cfg = params_or_cfg.get("logging", {}) or {}
    elif hasattr(params_or_cfg, "__dict__"): # module-like (config)
        cfg = getattr(params_or_cfg, "logging", {}) or {}
    out = dict(LOGGING_DEFAULTS)
    out.update(cfg)
    return out


# ------------------------------ Generator prep ------------------------------

def prepare_generators(params: Dict) -> Tuple[np.ndarray, np.ndarray]:
    Gq = params.get("generators_q")
    Gp = params.get("generators_p")
    if Gq is None:
        Gq, _ = get_generators(getattr(config, "group_name", "so3"), getattr(config, "K_q", getattr(config, "K", 3)), return_meta=True)
        params["generators_q"] = Gq
    if Gp is None:
        Gp, _ = get_generators(getattr(config, "group_name", "so3"), getattr(config, "K_p", getattr(config, "K", 3)), return_meta=True)
        params["generators_p"] = Gp
    return Gq, Gp


# -------------------------- Init / resume helpers ---------------------------

def initialize_or_resume(outdir: str, resume: bool, params: Dict, clear_agent_logs: bool=True):
    """Return (agents, step_start)."""
    if resume:
        agents, _ = load_checkpoint(outdir)
        step_start = find_resume_step(outdir)
    else:
        agents = initialize_agents(
            seed=getattr(config, "seed", None),
            domain_size=config.domain_size,
            N=config.N,
            K_q=config.K_q,
            K_p=config.K_p,
            lie_algebra_dim=3,
            visualize=False,
            fixed_location=getattr(config, "fixed_location", False), 
        )
        step_start = 0
        for A in agents:
            initialize_agent_gradients(A, config)
        if clear_agent_logs:
            for A in agents:
                if hasattr(A, "metrics_log"):
                    A.metrics_log.clear()
    return agents, step_start



def ensure_runtime(params: Dict):
    """Create/normalize the runtime context once and attach to params."""
    ctx = ensure_runtime_defaults(params.get("runtime_ctx", None))
    return ctx



def _log_metrics_by_levels(runtime_ctx, *, children_level0: List, step: int, params: Dict, n_jobs: int) -> Dict:
    """Compute scalar metrics separately for:
      - level 0 (children_level0 list)
      - each parent level L present in runtime_ctx.parents_by_level
    Returns a dict: {"levels": {0: m0, 1: m1, 2: m2, ...}, "flat": m0} where "flat" preserves legacy total.
    """
    

    out: Dict = {"levels": {}}
    # Ensure the plaquette/curvature paths see ctx (fixes mean-curvature=0 symptom)
    params_with_ctx = dict(params or {})
    params_with_ctx["ctx"] = runtime_ctx
    # lvl-0 (children)
    m0 = log_all_metrics(children_level0, step=step, params=params_with_ctx, n_jobs=n_jobs)
    out["levels"][0] = m0
    out["flat"] = m0  # preserve old behavior for downstream consumers

    # parents per level
    parents_levels = getattr(runtime_ctx, "parents_by_level", {}) or {}
    for L, bucket in sorted(parents_levels.items()):
        if not bucket:
            continue
        parents_L = list(bucket.values()) if isinstance(bucket, dict) else list(bucket)
        mL = log_all_metrics(parents_L, step=step, params=params_with_ctx, n_jobs=n_jobs)
        out["levels"][int(L)] = mL

    return out



def _collect_all_parents(ctx):
    """Robust parent flattener over either parents_by_level or parents_by_region."""
    if ctx is None: return []
    pbL = getattr(ctx, "parents_by_level", None)
    if isinstance(pbL, dict) and pbL:
        out = []
        for bucket in pbL.values():
            out.extend(list(bucket.values()) if isinstance(bucket, dict) else list(bucket))
        return out
    return list((getattr(ctx, "parents_by_region", {}) or {}).values())

def _choose_agents(children, parents, include_lvls: str):
    if include_lvls == "children": return list(children)
    if include_lvls == "parents":  return list(parents or [])
    return list(children) + (list(parents or []) if parents else [])

def dump_fields_if_needed(runtime_ctx, agents, step, outdir, params, logcfg):
    """
    Unified, de-duped snapshot writer. This function writes small bootstrap
    snapshots at step=0 and cadence-controlled full/crucial snapshots later.
    """
    do_fields   = bool(logcfg.get("enable_fields", False))
    cadence     = int(logcfg.get("fields_every", 1))
    field_dir   = os.path.join(outdir, logcfg.get("full_field_outdir", "fields"))
    snapshot_mode = str(logcfg.get("snapshot_mode", "full")).lower()
    fp16        = bool(logcfg.get("fp16_snapshot", True))
    include_lvls= str(logcfg.get("snapshot_include_levels", "both")).lower()

    include_crucial = {"mask", "mu_q", "sigma_q", "phi", "mu_p", "sigma_p"}
    include_full    = set(include_crucial) | {"phi_model", "bundle_morphism_q_to_p", "bundle_morphism_p_to_q"}
 
        # ---- ensure dir ----
    os.makedirs(field_dir, exist_ok=True)

    # ---- step 0 bootstrap (always write a small snapshot to prime viz) ----
    if step == 0:
        try:
            parents_now     = _collect_all_parents(runtime_ctx)
            agents_to_dump  = _choose_agents(agents, parents_now, include_lvls)
            if agents_to_dump:
                dump_snapshot_npz(
                    agents_to_dump, step, field_dir,
                    compute_alignment=False,
                    compute_curvature=False,
                    fp16=fp16,
                    params=params,
                    include=tuple(sorted(include_crucial)),
                )
        except Exception as e:
            print(f"[SNAPSHOT][ERROR bootstrap] {e}")

    # ---- cadence-controlled snapshots ----
    if do_fields and (step % cadence == 0):
        try:
            parents_now     = _collect_all_parents(runtime_ctx)
            agents_to_dump  = _choose_agents(agents, parents_now, include_lvls)
            if not agents_to_dump:
                return  # nothing to write
            include = include_crucial if snapshot_mode == "crucial" else include_full
            dump_snapshot_npz(
                agents_to_dump, step, field_dir,
                compute_alignment=bool(logcfg.get("compute_alignment", False)),
                compute_curvature=bool(logcfg.get("compute_curvature", False)),
                fp16=fp16,
                params=params,
                include=tuple(sorted(include)),
            )
        except Exception as e:
            print(f"[SNAPSHOT][ERROR] {e}")









# -------- compact NPZ snapshots (masks only; tiny) --------

def snapshot_parents_npz_simple(parents, save_path):
    """
    Minimal parent snapshot:
      - ids: (P,)
      - masks: (P,H,W) if same-shape; else masks_obj: array(object)
    """
    ids, masks = [], []
    for idx, P in enumerate(parents or ()):
        ids.append(int(getattr(P, "id", idx)))
        masks.append(np.asarray(getattr(P, "mask", 0.0), np.float32))
    out = {"ids": np.asarray(ids, dtype=np.int32)}
    shapes = {m.shape for m in masks if m is not None}
    if len(shapes) == 1 and len(masks) > 0:
        out["masks"] = np.stack(masks, axis=0)
    else:
        out["masks_obj"] = np.array(masks, dtype=object)
    os.makedirs(os.path.dirname(save_path), exist_ok=True)
    np.savez_compressed(save_path, **out)

def snapshot_children_npz_simple(children, save_path):
    """Minimal child snapshot: ids + masks."""
    ids, masks = [], []
    for idx, C in enumerate(children or ()):
        ids.append(int(getattr(C, "id", idx)))
        masks.append(np.asarray(getattr(C, "mask", 0.0), np.float32))
    out = {"ids": np.asarray(ids, dtype=np.int32)}
    shapes = {m.shape for m in masks if m is not None}
    if len(shapes) == 1 and len(masks) > 0:
        out["masks"] = np.stack(masks, axis=0)
    else:
        out["masks_obj"] = np.array(masks, dtype=object)
    os.makedirs(os.path.dirname(save_path), exist_ok=True)
    np.savez_compressed(save_path, **out)

def write_mask_snapshots(runtime_ctx, agents, step, outdir, logcfg):
    """Handles parent/child mask-only snapshots, throttled by logcfg."""
    snap_every  = int(logcfg.get("parent_snapshot_every", getattr(config, "parent_snapshot_every", 0)) or 0)
    snap_dir    = logcfg.get("parent_snapshot_dir", getattr(config, "parent_snapshot_dir", "parents"))
    child_every = int(logcfg.get("child_snapshot_every", getattr(config, "child_snapshot_every", 0)) or 0)
    child_dir   = logcfg.get("child_snapshot_dir", getattr(config, "child_snapshot_dir", "children"))

    if snap_every > 0 and (step % snap_every) == 0:
        Ps = _collect_all_parents(runtime_ctx)
        if Ps:
            pdir = os.path.join(outdir, snap_dir); os.makedirs(pdir, exist_ok=True)
            try:
                snapshot_parents_npz_simple(Ps, os.path.join(pdir, f"parents_step_{step:04d}.npz"))
            except Exception as e:
                print(f"[SNAP][PARENTS][ERROR] step {step}: {e}")

    if child_every > 0 and (step % child_every) == 0 and agents:
        cdir = os.path.join(outdir, child_dir); os.makedirs(cdir, exist_ok=True)
        try:
            snapshot_children_npz_simple(agents, os.path.join(cdir, f"children_step_{step:04d}.npz"))
        except Exception as e:
            print(f"[SNAP][CHILDREN][ERROR] step {step}: {e}")

# -------- Λ / morphism norms (tiny tables) --------

def parent_link_and_morphism_norms(ctx, parents, agents, *, thr=0.30):
    """
    Per-parent norms for animation/validation:
      - Frobenius mean of bundle morphisms Φ, Φ̃ (over parent support)
      - mean norms of Lambda_up/dn (q/p), if available in CacheHub
    """
    rows = []
    if not parents:
        return rows

    Lambda_up = Lambda_dn = None

    for P in parents:
        pid = int(getattr(P, "id", -1))
        m = np.asarray(getattr(P, "mask", 0.0), np.float32)
        mb = (m > float(thr))

        def _frob_mean(M):
            if M is None:
                return np.nan
            A = np.asarray(M, np.float32)
            if A.ndim < 2:
                return np.nan
            F = np.sqrt(np.sum(A*A, axis=(-2, -1)))
            return float(F[mb].mean()) if mb.any() else 0.0

        row = {
            "parent": pid,
            "phi_map_frob": _frob_mean(getattr(P, "bundle_morphism_q_to_p", None)),
            "phi_tilde_map_frob": _frob_mean(getattr(P, "bundle_morphism_p_to_q", None)),
            "lambda_up_q_mean": np.nan,
            "lambda_dn_q_mean": np.nan,
            "lambda_up_p_mean": np.nan,
            "lambda_dn_p_mean": np.nan,
        }

        kids = list(getattr(P, "child_ids", []) or [])
        if kids and ctx is not None and (Lambda_up or Lambda_dn):
            vals = {"u_q": [], "d_q": [], "u_p": [], "d_p": []}
            # agent lookup
            amap = getattr(ctx, "agent_index", None) or {int(getattr(a, "id")): a for a in (agents or []) if hasattr(a, "id")}
            for cid in kids:
                ch = amap.get(int(cid))
                if ch is None:
                    continue
                for which, key in (("q", "q"), ("p", "p")):
                    try:
                        if Lambda_up:
                            Lu = Lambda_up(ctx, ch, P, which=which)
                            if Lu is not None:
                                A = np.asarray(Lu, np.float32)
                                vals[f"u_{key}"].append(float(np.sqrt(np.sum(A*A))))
                    except Exception:
                        pass
                    try:
                        if Lambda_dn:
                            Ld = Lambda_dn(ctx, ch, P, which=which)
                            if Ld is not None:
                                A = np.asarray(Ld, np.float32)
                                vals[f"d_{key}"].append(float(np.sqrt(np.sum(A*A))))
                    except Exception:
                        pass
            for k_map, out_key in (("u_q","lambda_up_q_mean"), ("d_q","lambda_dn_q_mean"),
                                   ("u_p","lambda_up_p_mean"), ("d_p","lambda_dn_p_mean")):
                v = vals[k_map]
                row[out_key] = float(np.mean(v)) if v else np.nan

        rows.append(row)
    return rows

# -------- cross-scale (same-fiber) KL summaries --------

def crossscale_energy_totals(ctx, agents, parents) -> dict:
    """
    SAME-FIBER child→parent KL:
      - xscale_q_* : KL(child q || parent q)
      - xscale_p_* : KL(child p || parent p)
    """
    out = {"xscale_q_mean": np.nan, "xscale_p_mean": np.nan,
           "xscale_q_sum": 0.0, "xscale_p_sum": 0.0, "xscale_pairs": 0}
    if ctx is None or not parents:
        return out
    try:
        qs, ps, n = 0.0, 0.0, 0
        amap = getattr(ctx, "agent_index", None)
        if amap is None:
            amap = {int(getattr(a, "id")): a for a in (agents or []) if hasattr(a, "id")}
        
        
        for P in (parents or []):
            for cid in getattr(P, "child_ids", []) or []:
                ch = amap.get(int(cid))
                if ch is None:
                    continue
                vq = compute_crossscale_kl_q_single(ch, P, eps=1e-6, ctx=ctx)  # q vs q
                vp = compute_crossscale_kl_p_single(ch, P, eps=1e-6, ctx=ctx)  # p vs p
                if np.isfinite(vq): qs += float(vq)
                if np.isfinite(vp): ps += float(vp)
                n += 1
        if n > 0:
            out["xscale_q_mean"] = qs / n
            out["xscale_p_mean"] = ps / n
        out["xscale_q_sum"] = qs
        out["xscale_p_sum"] = ps
        out["xscale_pairs"] = n
    except Exception:
        pass
    return out

# -------- pretty-print energies safely --------

def _pf(d, k, default=0.0):
    """safe float pull from dict-like"""
    try:
        return float((d or {}).get(k, default))
    except Exception:
        return float(default)

def print_energy_totals(step, levels_map, flat_record, all_metrics_for_print, logcfg):
    """Compact, robust console output for energies + cross-scale."""
    import numpy as np  # ensure np is in scope

    print(f"[Energy Totals @ step {step}]")

    # lvl-0 (children)
    m0 = (levels_map or {}).get(0) or {}
    print(f"  [lvl-0 children]")
    print(f"    Self belief      = {_pf(m0,'e_self'):.4e}")
    print(f"    Feedback model   = {_pf(m0,'e_feedback'):.4e}")
    print(f"    Belief alignment = {_pf(m0,'e_align'):.4e}")
    print(f"    Model alignment  = {_pf(m0,'e_mod_align'):.4e}")
    print(f"    Belief curvature = {_pf(m0,'e_curv'):.4e}")
    print(f"    Model curvature  = {_pf(m0,'e_curv_mod'):.4e}")
    print(f"    Belief mass      = {_pf(m0,'e_mass'):.4e}")
    print(f"    Model mass       = {_pf(m0,'e_mass_mod'):.4e}")
    if "total_energy" in m0:
        print(f"    ----")
        print(f"    TOTAL (level raw) = {_pf(m0,'total_energy'):.4e}")

    # parents per level
    for L in sorted(k for k in (levels_map or {}).keys() if k != 0):
        mL = (levels_map or {}).get(L) or {}
        print(f"  [lvl-{L} parents]")
        print(f"    Self belief      = {_pf(mL,'e_self'):.4e}")
        print(f"    Feedback model   = {_pf(mL,'e_feedback'):.4e}")
        print(f"    Belief alignment = {_pf(mL,'e_align'):.4e}")
        print(f"    Model alignment  = {_pf(mL,'e_mod_align'):.4e}")
        print(f"    Belief curvature = {_pf(mL,'e_curv'):.4e}")
        print(f"    Model curvature  = {_pf(mL,'e_curv_mod'):.4e}")
        print(f"    Belief mass      = {_pf(mL,'e_mass'):.4e}")
        print(f"    Model mass       = {_pf(mL,'e_mass_mod'):.4e}")
        if "total_energy" in mL:
            print(f"    ----")
            print(f"    TOTAL (level raw) = {_pf(mL,'total_energy'):.4e}")

    # cross-scale summary (same fiber)
    if bool(logcfg.get("print_crossscale", False)):
        m = all_metrics_for_print or {}
        print("  [cross-scale child→parent KL (same fiber)]")
        print(f"    mean KL(q→q): {float(m.get('xscale_q_mean', np.nan)):.4e}   "
              f"mean KL(p→p): {float(m.get('xscale_p_mean', np.nan)):.4e}   "
              f"pairs: {int(m.get('xscale_pairs', 0))}")
        print(f"    sum  KL(q→q): {float(m.get('xscale_q_sum', 0.0)):.4e}   "
              f"sum  KL(p→p): {float(m.get('xscale_p_sum', 0.0)):.4e}\n")

    # --- GRAND TOTAL: prefer weighted total from rec (matches optimizer) -----
    try:
        rec = all_metrics_for_print or {}
        if isinstance(rec, dict) and ("total_energy" in rec):
            grand = float(rec["total_energy"])
            print(f"[GRAND TOTAL variational energy (weighted)] {grand:.4e}")
            # optional: echo weights if present
            bd = rec.get("E_breakdown")
            if isinstance(bd, dict) and isinstance(bd.get("weights"), dict):
                W = bd["weights"]
                def _fw(k, dv=1.0): 
                    try: return float(W.get(k, dv))
                    except Exception: return dv
                print(f"  weights: self={_fw('self'):.3g}  align={_fw('align'):.3g}  "
                      f"morph={_fw('morph'):.3g}  cross={_fw('cross'):.3g}  curv={_fw('curv'):.3g}\n")
        else:
            # fallback: sum level totals (likely raw/unweighted)
            totals = [
                float(v.get("total_energy", 0.0))
                for v in (levels_map or {}).values()
                if isinstance(v, dict)
            ]
            if totals:
                print(f"[GRAND TOTAL variational energy (sum of level totals)] {float(sum(totals)):.4e}\n")
    except Exception:
        pass





# run_sim_utils.py
def save_step(agents, outdir, step, *, save_every=1, compress=True):
    import pickle, os
    os.makedirs(outdir, exist_ok=True)
    ckpt_path = os.path.join(outdir, "checkpoint.pkl")
    if compress:
        import lzma
        with lzma.open(ckpt_path + ".xz", "wb", preset=3) as f:
            pickle.dump(agents, f, protocol=pickle.HIGHEST_PROTOCOL)
    else:
        with open(ckpt_path, "wb") as f:
            pickle.dump(agents, f, protocol=pickle.HIGHEST_PROTOCOL)

    if (step is not None) and (step % int(save_every) == 0):
        step_base = os.path.join(outdir, f"step_{step:04d}.pkl")
        if compress:
            import lzma
            with lzma.open(step_base + ".xz", "wb", preset=3) as f:
                pickle.dump(agents, f, protocol=pickle.HIGHEST_PROTOCOL)
        else:
            with open(step_base, "wb") as f:
                pickle.dump(agents, f, protocol=pickle.HIGHEST_PROTOCOL)






def log_and_viz_after_step(runtime_ctx, agents, step, outdir, params, logcfg,
                           parent_metrics, metric_log, num_cores):
    """
    Streamlined per-step logging + lightweight viz/snapshots.

    logcfg keys (optional):
      - enable_scalar: bool (default True)
      - print_total_energy: bool (default True)
      - print_crossscale: bool (default True)
      - log_link_norms: bool (default True)
      - log_typical_grads: bool (default False)
      - typical_grad_agent_id: int|None
      - enable_fields: bool (default False)
      - fields_every: int (default 1)
      - full_field_outdir: str (default "fields")
      - snapshot_mode: "crucial"|"full" (default "crucial")
      - fp16_snapshot: bool (default True)
      - parent_snapshot_every: int (default 0)
      - parent_snapshot_dir: str (default "parents")
      - child_snapshot_every: int (default 0)
      - child_snapshot_dir: str (default "children")
      - viz_parent_masks: bool (default True)
      - viz_parent_masks_every: int (default 1)
      - viz_parent_grid: bool (default False)
    """
    # 1) tiny mask snapshots (parents/children)
    write_mask_snapshots(runtime_ctx, agents, step, outdir, logcfg)

    # 2) quick overlays (best-effort) — call viz with correct signature and robust import
    try:
        if bool(logcfg.get("viz_parent_masks", True)) and (
            int(step) % int(logcfg.get("viz_parent_masks_every", 1)) == 0
        ):
            import os
            

            viz_dir = os.path.join(outdir, "viz", "parents")
            os.makedirs(viz_dir, exist_ok=True)

            # main evolving frame (per-step)
            save_parent_mask_frame(runtime_ctx, step=int(step), outdir=viz_dir, draw_per_parent=True)

            # delta frame (if prior step exists, function handles first-step gracefully)
            save_parent_mask_delta(runtime_ctx, step=int(step), outdir=viz_dir)

            # optional tiled grid snapshot (slower; OFF by default)
            if bool(logcfg.get("viz_parent_grid", True)):
                plot_parent_masks_grid(runtime_ctx, step=int(step), outdir=viz_dir,
                                       center_on_com=True, shared_scale=True)
    except Exception as e:
        print("[viz] parent-mask viz skipped:", repr(e))

    # 3) scalar metrics (lean)
    if bool(logcfg.get("enable_scalar", True)):
        t1 = time.perf_counter()

        # Level-aware metrics
        levels_metrics = _log_metrics_by_levels(
            runtime_ctx, children_level0=agents, step=step, params=params, n_jobs=num_cores
        ) or {}
        flat_rec   = levels_metrics.get("flat")   or {}
        levels_map = levels_metrics.get("levels") or {}

        # keep only core energies; default to 0.0 if missing
        keep_keys = ("e_self","e_feedback","e_align","e_mod_align","e_curv","e_curv_mod","e_mass","e_mass_mod")
        rec = {k: float(flat_rec.get(k, 0.0)) for k in keep_keys}
        rec["step"] = int(step)

        # --- Weighted total that mirrors the optimizer -----------------------
        # Local import to avoid file-level coupling
        try:
            from generalized_diagnostics_metrics import compute_total_free_energy
            import core.config as config
        except Exception:
            compute_total_free_energy = None
            config = None

        total_energy_weighted = float(flat_rec.get("total_energy", sum(rec.values())))
        breakdown_w = None
        if compute_total_free_energy is not None and config is not None:
            # build weights from run config (split align/curv)
            W = {
                "self":    float(getattr(config, "alpha", 1.0)),
                "align_q": float(getattr(config, "beta",  1.0)),
                "align_p": float(getattr(config, "beta_model", 1.0)),
                "mass_q":  float(getattr(config, "belief_mass", 0.0)),
                "mass_p":  float(getattr(config, "model_mass",  0.0)),
                "cross":   1.0 if bool(getattr(config, "enable_xscale", False)) else 0.0,
                "curv_q":  float(getattr(config, "curvature_weight", 0.0)),
                "curv_p":  float(getattr(config, "model_curvature_weight", 0.0)),
                "verbose": False,  # printing handled below
            }

            # drop-in replacement inside log_and_viz_after_step
            Gq = params.get("generators_q", None)
            if Gq is None:
                Gq = getattr(runtime_ctx, "generators_q", None)

            Gp = params.get("generators_p", None)
            if Gp is None:
                Gp = getattr(runtime_ctx, "generators_p", None)

            try:
                total_energy_weighted, breakdown_w = compute_total_free_energy(
                    agents,
                    generators_q=Gq,
                    generators_p=Gp,
                    ctx=runtime_ctx,
                    weights=W,
                )
            except Exception:
                breakdown_w = None

        rec["total_energy"] = float(total_energy_weighted)
        if breakdown_w is not None:
            rec["E_breakdown"] = breakdown_w

        # (1) Λ + morphism norms (small)
        if bool(logcfg.get("log_link_norms", True)):
            Ps = _collect_all_parents(runtime_ctx)
            rec["parent_link_norms"] = parent_link_and_morphism_norms(runtime_ctx, Ps, agents)

        # (2) typical agent grad norms
        if bool(logcfg.get("log_typical_grads", False)):
            tid = logcfg.get("typical_grad_agent_id")
            if tid is None:
                # choose the largest-support agent
                best_id, best_px = None, -1
                for a in agents:
                    m = np.asarray(getattr(a, "mask", 0.0), np.float32) > float(getattr(config, "parent_area_threshold", 0.01))
                    px = int(m.sum())
                    if px > best_px:
                        best_px = px
                        best_id = int(getattr(a, "id", -1))
                tid = best_id
            if tid is not None:
                sel = next((a for a in agents if int(getattr(a, "id", -999)) == int(tid)), None)
                if sel is not None:
                    gq = getattr(sel, "grad_phi", None)
                    gp = getattr(sel, "grad_phi_tilde", None)
                    rec["typical_grad_agent"] = int(tid)
                    rec["grad_phi_norm"] = float(np.linalg.norm(gq)) if gq is not None else np.nan
                    rec["grad_phi_model_norm"] = float(np.linalg.norm(gp)) if gp is not None else np.nan

        # (3) cross-scale KL (same fiber)
        if bool(logcfg.get("print_crossscale", True)):
            Ps = _collect_all_parents(runtime_ctx)
            xs = crossscale_energy_totals(runtime_ctx, agents, Ps)
            rec.update(xs)
            # explicit aliases
            rec["xscale_qq_mean"] = rec.get("xscale_q_mean")
            rec["xscale_pp_mean"] = rec.get("xscale_p_mean")
            rec["xscale_qq_sum"]  = rec.get("xscale_q_sum")
            rec["xscale_pp_sum"]  = rec.get("xscale_p_sum")

        # timings + append
        rec["compute_ms"] = int((time.perf_counter() - t1) * 1000)
        if bool(logcfg.get("store_levels", False)):
            rec["levels"] = levels_map  # optional, can be large
        metric_log.append(rec)

        # pretty print to console (weighted + means; no raw sums)
        if bool(logcfg.get("print_total_energy", False)):
            if breakdown_w is not None:
                Wb = breakdown_w.get("weights", {})
            
                # helpers
                def bw(k, alt=None, default=0.0):  # objective scalar per term (raw sum used only for weighted contrib)
                    if k in breakdown_w: return float(breakdown_w[k])
                    return float(breakdown_w.get(alt, default)) if alt is not None else float(default)
                def wt(k, alt=None, default=1.0):
                    if k in Wb: return float(Wb[k])
                    return float(Wb.get(alt, default)) if alt is not None else float(default)
            
                # means from flat_rec (same ones print_energy_totals uses)
                mean_self  = float(flat_rec.get("e_self_mean",  flat_rec.get("e_self", 0.0)))
                mean_aq    = float(flat_rec.get("e_align",      0.0))
                mean_ap    = float(flat_rec.get("e_mod_align",  0.0))
                mean_mq    = float(flat_rec.get("e_mass",       0.0))
                mean_mp    = float(flat_rec.get("e_mass_mod",   0.0))
                mean_cq    = float(flat_rec.get("e_curv",       0.0))
                mean_cp    = float(flat_rec.get("e_curv_mod",   0.0))
                mean_xq    = float(flat_rec.get("xscale_q_mean", flat_rec.get("xscale_qq_mean", 0.0)))
                mean_xp    = float(flat_rec.get("xscale_p_mean", flat_rec.get("xscale_pp_mean", 0.0)))
                mean_cross = (mean_xq + mean_xp) * 0.5
            
                rows = [
                    ("self",    wt("self"),                 bw("self"),                mean_self),
                    ("align_q", wt("align","align_q"),      bw("align_q","align"),     mean_aq),
                    ("align_p", wt("align","align_p"),      bw("align_p",None),        mean_ap),
                    ("mass_q",  wt("mass_q"),               bw("mass_q"),              mean_mq),
                    ("mass_p",  wt("mass_p"),               bw("mass_p"),              mean_mp),
                    ("curv_q",  wt("curv_q","curv"),        bw("curv_q","curv"),       mean_cq),
                    ("curv_p",  wt("curv_p","curv"),        bw("curv_p",None),         mean_cp),
                    ("cross",   wt("cross", default=0.0),   bw("cross"),               mean_cross),
                ]
            
                # NEW: mean_total = sum(weights * per-term means)
                mean_total = sum(w * mean_val for (_n, w, _sum_scalar, mean_val) in rows)
            
                title = f"E_total = {total_energy_weighted:.6e}  |  mean_total = {mean_total:.6e}"
                print("\n[Energy Breakdown]")
                print(f"  {title}")
                print("  " + "-" * max(44, len(title)))
                print("  {:<10} {:>16}   {:>16}   {:>8}".format("term", "weighted", "mean", "weight"))
                for name, w, sum_scalar, mean_val in rows:
                    print(f"  {name:<10} {w*sum_scalar:>16.6e}   {mean_val:>16.6e}   {w:>8.3g}")
                print()
            else:
                print_energy_totals(step, levels_map, flat_rec, rec, logcfg)

    # 4) field snapshots (crucial vs full)
    dump_fields_if_needed(runtime_ctx, agents, step, outdir, params, logcfg)


# --- fix: checkpoint save_step wrong kw ---------------------------------------
def checkpoint_step(agents, outdir):
    """Optional pre-checkpoint compaction; then save a non-step checkpoint."""
    for A in agents:
        if hasattr(A, "clear_omega_cache"):   A.clear_omega_cache()
        if hasattr(A, "clear_fisher_caches"): A.clear_fisher_caches()
    save_step(agents, outdir, step=None)  # filename handled by save_step



def wrap_epilogue(runtime_ctx, agents, outdir, parent_metrics, metric_log):
    import os, pickle
    import numpy as np
    try:
        import pandas as pd
    except Exception:
        pd = None


    # --- 1) Save the metrics log (pickle) + optional per-agent CSV ---
    if metric_log:
        os.makedirs(outdir, exist_ok=True)
        with open(os.path.join(outdir, "metric_log.pkl"), "wb") as f:
            pickle.dump(metric_log, f)

        # flatten per-agent step logs if present
        rows = [{"agent": getattr(A, "id", -1), **e}
                for A in agents
                for e in (getattr(A, "metrics_log", None) or [])]
        if rows and pd is not None:
            pd.DataFrame(rows).to_csv(os.path.join(outdir, "per_agent_metrics.csv"), index=False)

    
    parents_now = _collect_all_parents(runtime_ctx)

        # 3) Final parent masks viz (PNG) + compact NPZ snapshot
    if parents_now:
        # PNG viz (call with correct signature)
        try:
            viz_dir = os.path.join(outdir, "viz")
            os.makedirs(viz_dir, exist_ok=True)
            # Use step=0 (or last step if you track it) for consistent filename
            save_parent_mask_frame(runtime_ctx, step=0, outdir=viz_dir, draw_per_parent=True)
        except Exception:
            pass


        # NPZ: ids + masks (stack if uniform shape, else object array)
        try:
            ids = [int(getattr(P, "id", i)) for i, P in enumerate(parents_now)]
            masks = [np.asarray(getattr(P, "mask", None), dtype=np.float32) for P in parents_now]
            save_path = os.path.join(outdir, "parents_final.npz")
            os.makedirs(os.path.dirname(save_path), exist_ok=True)
            out = {"ids": np.asarray(ids, dtype=np.int32)}
            shapes = {m.shape for m in masks if m is not None}
            if len(shapes) == 1 and len(masks) > 0:
                out["masks"] = np.stack(masks, axis=0)
            else:
                out["masks_obj"] = np.array(masks, dtype=object)
            np.savez_compressed(save_path, **out)
        except Exception as e:
            print(f"[SNAP][ERROR] final NPZ: {e}")

    # --- 4) Optional parent metrics CSV ---
    if parent_metrics and pd is not None:
        try:
            pd.DataFrame(parent_metrics).to_csv(os.path.join(outdir, "parent_metrics.csv"), index=False)
        except Exception:
            pass
