import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation
from pathlib import Path
import re
import glob
import config

from generalized_agent_schema import Agent
from pullback_utils import compute_agent_pullback_blocks

SAVE_DIR = Path("Holonomy_Visualizations/pullback")
SAVE_DIR.mkdir(parents=True, exist_ok=True)

# ── Extract step ID ──
def extract_step(fname):
    match = re.search(r"step(\d+)", fname)
    return int(match.group(1)) if match else -1

def load_agents_from_field_dumps(folder):
    files = sorted(Path(folder).glob("step*.npz"))
    agents = []
    steps = []

    for f in files:
        data = np.load(f, allow_pickle=True)
        step_id = extract_step(f.name)

        mu_q, sigma_q = data["mu_q"], data["sigma_q"]
        mu_p, sigma_p = data["mu_p"], data["sigma_p"]
        phi_model = data.get("phi_model", np.zeros((*mu_q.shape[:2], config.lie_dim)))
        phi       = data.get("phi", np.zeros_like(phi_model))

        A = Agent(
            id             = int(data["agent_i"]),
            mask           = data["mask_i"],
            mu_q_field     = mu_q,
            sigma_q_field  = sigma_q,
            mu_p_field     = mu_p,
            sigma_p_field  = sigma_p,
            phi            = phi,
            phi_model      = phi_model,
            center         = (0, 0),
            radius         = 1.0,
            neighbors      = [],
        )
        A.grid_shape = mu_q.shape[:2]
        agents.append(A)
        steps.append(step_id)

    return steps, agents


# ── Extract pullback metric diagnostics ──
def extract_traces(blocks):
    M_vis  = blocks["M_vis"]
    M_dark = blocks["M_dark"]
    Delta  = blocks["Delta"]
    Tr_vis  = np.trace(M_vis, axis1=-2, axis2=-1)
    Tr_dark = np.trace(M_dark, axis1=-2, axis2=-1)
    Mix_norm = np.linalg.norm(Delta, axis=(-2, -1))
    return Tr_vis, Tr_dark, Mix_norm

# ── Static: Tr(M_vis), Tr(M_dark), ‖Δ‖ ──
def plot_static_pullback_fields(agent, vis_inds, dark_inds, step_id=None):
    blocks = compute_agent_pullback_blocks(agent, vis_inds, dark_inds)
    Tr_vis, Tr_dark, Mix_norm = extract_traces(blocks)

    fig, axes = plt.subplots(1, 3, figsize=(15, 4))
    im0 = axes[0].imshow(Tr_vis, cmap="viridis")
    axes[0].set_title("Tr(M_vis)")
    plt.colorbar(im0, ax=axes[0])

    im1 = axes[1].imshow(Tr_dark, cmap="inferno")
    axes[1].set_title("Tr(M_dark)")
    plt.colorbar(im1, ax=axes[1])

    im2 = axes[2].imshow(Mix_norm, cmap="plasma")
    axes[2].set_title("‖Delta‖")
    plt.colorbar(im2, ax=axes[2])

    if step_id is not None:
        fname = SAVE_DIR / f"pullback_step_{step_id:04d}.png"
        plt.savefig(fname)
    else:
        plt.show()
    plt.close()

# ── φ_model norm ──
def plot_phi_model_norm(agent, step_id=None):
    if agent.phi_model is None:
        print(f"[WARN] No phi_model at step {step_id}")
        return
    norm = np.linalg.norm(agent.phi_model, axis=-1)
    plt.figure(figsize=(6, 5))
    im = plt.imshow(norm, origin="upper")
    plt.title(f"‖φ_model‖ (step {step_id})" if step_id else "‖φ_model‖")
    plt.colorbar(im)
    plt.tight_layout()
    plt.savefig(SAVE_DIR / f"phi_model_norm_{step_id:04d}.png") if step_id else plt.show()
    plt.close()

# ── μ_p and Σ_p components ──
def plot_mu_sigma_components(agent, k_list=[0, 1, 2], step_id=None):
    mu, sigma = agent.mu_p_field, agent.sigma_p_field
    for k in k_list:
        fig, axs = plt.subplots(1, 2, figsize=(10, 4))
        im0 = axs[0].imshow(mu[..., k], origin="upper")
        axs[0].set_title(f"μ_p[..., {k}]")
        plt.colorbar(im0, ax=axs[0])
        im1 = axs[1].imshow(sigma[..., k, k], origin="upper")
        axs[1].set_title(f"Σ_p[..., {k},{k}]")
        plt.colorbar(im1, ax=axs[1])
        if step_id is not None:
            fig.suptitle(f"Step {step_id}")
            plt.savefig(SAVE_DIR / f"mu_sigma_{step_id:04d}_k{k}.png")
        else:
            plt.show()
        plt.close()

# ── Animate pullback metrics over time ──
def animate_pullback_fields(agent_seq, vis_inds, dark_inds, fname="pullback_fields.gif"):
    frames = []
    for A in agent_seq:
        blocks = compute_agent_pullback_blocks(A, vis_inds, dark_inds)
        Tr_vis, Tr_dark, Mix_norm = extract_traces(blocks)
        norm_vis  = Tr_vis / np.nanmax(Tr_vis)
        norm_dark = Tr_dark / np.nanmax(Tr_dark)
        norm_mix  = Mix_norm / np.nanmax(Mix_norm)
        frame = np.concatenate([norm_vis[..., None], norm_dark[..., None], norm_mix[..., None]], axis=1)
        frames.append(frame)
    frames = np.stack(frames, axis=0)

    fig = plt.figure(figsize=(10, 4))
    im = plt.imshow(frames[0], animated=True, cmap="viridis")

    def update(i):
        im.set_array(frames[i])
        return [im]

    ani = animation.FuncAnimation(fig, update, frames=len(frames), blit=True)
    ani.save(SAVE_DIR / fname, fps=4)
    plt.close()

# ── Run ──
if __name__ == "__main__":
    vis_inds  = [0, 1]
    dark_inds = [2]
    dump_dir  = Path("checkpoints/field_dumps")
    steps, agents = load_agents_from_field_dumps(dump_dir)

    for step, A in zip(steps, agents):
        plot_static_pullback_fields(A, vis_inds, dark_inds, step_id=step)
        plot_phi_model_norm(A, step_id=step)
        plot_mu_sigma_components(A, k_list=[0, 1, 2], step_id=step)

    animate_pullback_fields(agents, vis_inds, dark_inds)
