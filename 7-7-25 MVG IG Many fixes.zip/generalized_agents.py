from numpy.random import default_rng

import numpy as np

import matplotlib.pyplot as plt
from generalized_agent_distributions import initialize_distribution
from generalized_agent_schema import Agent
from scipy.ndimage import gaussian_filter
import config


def scale_to_range(
    field: np.ndarray,
    value_range: tuple[float, float]
) -> np.ndarray:
    """
    Linearly remap `field` so that field.min()→value_range[0], field.max()→value_range[1].
    If field is constant, fill with the midpoint of the range.
    Output dtype is taken from config.dtype.
    """
    lo, hi = value_range
    fmin, fmax = field.min(), field.max()
    dtype = getattr(config, 'dtype', field.dtype)
    if fmax <= fmin:
        return np.full_like(field, (lo + hi) / 2, dtype=dtype)

    # normalize to [0,1]
    norm = (field - fmin) / (fmax - fmin)
    # scale to [lo, hi]
    out = norm * (hi - lo) + lo
    return out.astype(dtype)

def generate_soft_mask(
    center: tuple[int, ...],
    radius: float,
    domain_size: tuple[int, ...]
) -> np.ndarray:
    """
    Create a smooth soft mask (Gaussian decay) on a periodic domain.
    Distances wrap around edges in each dimension.
    """
    dtype = getattr(config, 'dtype', np.float64)

    # Build per‐axis index grids via ogrid
    grids = np.ogrid[tuple(slice(0, s) for s in domain_size)]  # one array per axis

    # Accumulate squared wrap‐aware distances
    dist_sq = 0.0
    for d, size in enumerate(domain_size):
        coord = grids[d]
        # raw distance from center
        delta = np.abs(coord - center[d])
        # wrap‐around distance
        delta = np.minimum(delta, size - delta)
        dist_sq = dist_sq + delta**2

    dist = np.sqrt(dist_sq)

    # Avoid division by zero
    r = max(radius, np.finfo(float).eps)
    mask = np.exp(-(dist / r)**2).astype(dtype)
    return mask

def create_agent_mask(
    center: tuple[int, ...],
    radius: float,
    domain_size: tuple[int, ...]
) -> np.ndarray:
    """
    Generate a soft Gaussian mask and zero out values below support_cutoff_eps from config.
    """
    mask = generate_soft_mask(center, radius, domain_size)
    cutoff = getattr(config, 'support_cutoff_eps', 1e-3)
    mask[mask < cutoff] = 0.0
    return mask

def smooth_random_field(domain_size, rng, sigma=1.0, K=1):
    dtype = getattr(config, 'dtype', np.float64)

    if K == 1:
        noise = rng.normal(size=domain_size).astype(dtype)
        field = gaussian_filter(noise, sigma=sigma)
    else:
        noise = rng.normal(size=(*domain_size, K)).astype(dtype)
        field = np.empty_like(noise)
        for k in range(K):
            field[..., k] = gaussian_filter(noise[..., k], sigma=sigma)

    return field.astype(dtype)

def expand_diagonal_to_covariance(sigma_diag: np.ndarray) -> np.ndarray:
    """
    Expand a field of diagonal stddevs (H, W, K) to full covariance matrices (H, W, K, K).
    """
    H, W, K = sigma_diag.shape
    sigma_full = np.zeros((H, W, K, K), dtype=sigma_diag.dtype)
    for k in range(K):
        sigma_full[..., k, k] = sigma_diag[..., k]
    return sigma_full



def create_smooth_fields(
    domain_size: tuple[int, ...],
    rng: np.random.Generator,
    K: int,
    mask: np.ndarray = None
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """
    Generate spatially smooth μ and full SPD Σ fields for q and p, optionally applying a mask.
    μ: (*domain_size, K)
    Σ: (*domain_size, K, K) SPD
    """
    
    dtype = getattr(config, "dtype", np.float32)

    mu_anisotropy_range  = getattr(config, "mu_anisotropy_range", (1.0, 1.0))  # 1.0 = isotropic
    mu_orientation_range = getattr(config, "mu_orientation_range", (0.0, 0.0))

    def make_anisotropic_field(smooth_sigma_range, value_range):
        fields = []
        for _ in range(K):
            sigma1 = rng.uniform(*smooth_sigma_range)
            anisotropy = rng.uniform(*mu_anisotropy_range)
            angle = rng.uniform(*mu_orientation_range)
            sigma2 = sigma1 / anisotropy

            # Build anisotropic Gaussian kernel covariance
            c, s = np.cos(angle), np.sin(angle)
            R = np.array([[c, -s], [s, c]])
            Λ = np.diag([sigma1**2, sigma2**2])
            cov = R @ Λ @ R.T

            f = smooth_random_field_anisotropic(domain_size, rng, cov=cov)
            fields.append(scale_to_range(f, value_range))

        return np.stack(fields, axis=-1).astype(dtype)

    mu_smooth_range    = getattr(config, "mu_field_smooth_range", (1, 3))
    sigma_smooth_range = getattr(config, "sigma_field_smooth_range", (1, 3))

    mu_smooth_q    = rng.uniform(*mu_smooth_range)
    sigma_smooth_q = rng.uniform(*sigma_smooth_range)
    mu_smooth_p    = rng.uniform(*mu_smooth_range)
    sigma_smooth_p = rng.uniform(*sigma_smooth_range)

    q_mu_range     = getattr(config, "q_mu_range", (0, K - 1))
    q_sigma_range  = getattr(config, "q_sigma_range", (1, 5))
    p_mu_range     = getattr(config, "p_mu_range", (0, K - 1))
    p_sigma_range  = getattr(config, "p_sigma_range", (1, 5))

    mu_q_field = make_anisotropic_field(mu_smooth_range, q_mu_range)
    sigma_q_field = generate_smooth_spd_matrix_field(
        H=domain_size[0],
        W=domain_size[1],
        D=K,
        min_eig=q_sigma_range[0],
        max_eig=q_sigma_range[1],
        sigma=sigma_smooth_q,
        seed=rng.integers(0, 1e9)
    )
    if mask is not None:
        mu_q_field *= mask[..., None]
        sigma_q_field *= mask[..., None, None]

    if getattr(config, "identical_models", False):
        mu_p_field = make_anisotropic_field(mu_smooth_range, p_mu_range)
        sigma_p_field = generate_smooth_spd_matrix_field(
            H=domain_size[0],
            W=domain_size[1],
            D=K,
            min_eig=p_sigma_range[0],
            max_eig=p_sigma_range[1],
            sigma=sigma_smooth_p,
            seed=rng.integers(0, 1e9)
        )
    elif getattr(config, "similar_p_models", False):
        base_mu_p    = rng.uniform(*p_mu_range, size=K).astype(dtype)
        mu_p_field   = np.broadcast_to(base_mu_p, (*domain_size, K))
        sigma_p_field = generate_smooth_spd_matrix_field(
            H=domain_size[0],
            W=domain_size[1],
            D=K,
            min_eig=p_sigma_range[0],
            max_eig=p_sigma_range[1],
            sigma=sigma_smooth_p,
            seed=rng.integers(0, 1e9)
        )
    else:
        mu_p_field = make_anisotropic_field(mu_smooth_range, p_mu_range)
        sigma_p_field = generate_smooth_spd_matrix_field(
            H=domain_size[0],
            W=domain_size[1],
            D=K,
            min_eig=p_sigma_range[0],
            max_eig=p_sigma_range[1],
            sigma=sigma_smooth_p,
            seed=rng.integers(0, 1e9)
        )

    if mask is not None:
        mu_p_field *= mask[..., None]
        sigma_p_field *= mask[..., None, None]

    return mu_q_field, sigma_q_field, mu_p_field, sigma_p_field



import scipy.ndimage

def apply_anisotropic_filter(field: np.ndarray, sigma_x: float, sigma_y: float, angle: float) -> np.ndarray:
    """
    Apply an anisotropic Gaussian filter to a 2D field by rotating, blurring, and rotating back.
    """
    # Rotate field by -angle
    rotated = scipy.ndimage.rotate(field, angle * 180 / np.pi, reshape=False, order=1, mode='wrap')

    # Apply Gaussian blur in x and y (major/minor)
    blurred = scipy.ndimage.gaussian_filter(rotated, sigma=(sigma_y, sigma_x), mode='wrap')

    # Rotate back by +angle
    unrotated = scipy.ndimage.rotate(blurred, -angle * 180 / np.pi, reshape=False, order=1, mode='wrap')

    return unrotated





def smooth_random_field_anisotropic(domain_size, rng, mean=0.0, std=1.0, cov=None):
    """
    Generate a smooth random field with an anisotropic Gaussian kernel.
    Args:
        domain_size: Tuple of spatial shape (H, W)
        rng: random generator
        mean, std: field mean and std
        cov: 2x2 SPD matrix defining smoothing kernel shape (default isotropic)
    """
    from scipy.ndimage import gaussian_filter

    field = rng.normal(loc=mean, scale=std, size=domain_size)

    if cov is None:
        # Default to isotropic
        sigma_x = sigma_y = 1.0
        angle = 0.0
    else:
        # Convert covariance to principal axes
        eigvals, eigvecs = np.linalg.eigh(cov)
        major, minor = np.sqrt(eigvals[::-1])  # σ₁, σ₂
        angle = np.arctan2(eigvecs[1, 0], eigvecs[0, 0])  # rotation of major axis

        # Apply smoothing in aligned coordinates
        field = apply_anisotropic_filter(field, major, minor, angle)

    return field


from scipy.ndimage import gaussian_filter

from scipy.ndimage import gaussian_filter
import numpy as np

def generate_smooth_spd_matrix_field(H, W, D, min_eig=0.5, max_eig=2.0, sigma=1.0, seed=None):
    """
    Generate a smooth (H, W, D, D) field of SPD matrices by smoothing eigenvalues
    and using a fixed orthonormal basis across space.
    """
    if seed is not None:
        np.random.seed(seed)

    # Step 1: generate raw eigenvalues
    eigval_field = np.random.uniform(min_eig, max_eig, size=(H, W, D)).astype(np.float32)

    # Step 2: smooth each eigenvalue channel
    for d in range(D):
        eigval_field[..., d] = gaussian_filter(eigval_field[..., d], sigma=sigma)

    # ── PATCH HERE: clip smoothed eigenvalues ──
    eigval_field = np.clip(eigval_field, min_eig, max_eig)

    # Step 3: fixed orthonormal Q for whole field
    A = np.random.randn(D, D)
    Q_global, _ = np.linalg.qr(A)

    # Step 4: construct SPD matrices Σ = Q Λ Qᵀ
    sigma_field = np.zeros((H, W, D, D), dtype=np.float32)
    for i in range(H):
        for j in range(W):
            Λ = np.diag(eigval_field[i, j])
            sigma_field[i, j] = Q_global @ Λ @ Q_global.T

    # Optional sanity checks
    if not np.all(np.isfinite(sigma_field)):
        print("[WARNING] Σ field contains NaNs or infs")
    if np.any(np.linalg.det(sigma_field.reshape(-1, D, D)) <= 0):
        print("[WARNING] Σ field contains singular or non-SPD matrices")

    return sigma_field



def smooth_random_spd_field(domain_size, D, rng, smooth_sigma=1.0):
    """
    Generate a smooth SPD field of shape (H, W, D, D) by smoothing random SPD matrices.
    """
    H, W = domain_size
    raw_field = np.empty((H, W, D, D), dtype=np.float32)
    for i in range(D):
        for j in range(i, D):
            noise = rng.normal(size=(H, W)).astype(np.float32)
            smooth = gaussian_filter(noise, sigma=smooth_sigma)
            raw_field[..., i, j] = smooth
            if i != j:
                raw_field[..., j, i] = smooth  # ensure symmetry

    # Eigenvalue projection to ensure SPD
    for i in range(H):
        for j in range(W):
            A = raw_field[i, j]
            eigvals, eigvecs = np.linalg.eigh(A)
            eigvals_clipped = np.clip(eigvals, 0.5, 5.0)
            A_spd = eigvecs @ np.diag(eigvals_clipped) @ eigvecs.T
            raw_field[i, j] = A_spd

    return raw_field



def initialize_phi_fields(
    domain_size: tuple[int, ...],
    lie_algebra_dim: int,
    rng: np.random.Generator,
    phi_init: float,
    phi_model_offset: float,
    mask: np.ndarray
) -> tuple[np.ndarray, np.ndarray]:
    """
    Initialize and smooth both belief-phase and model-phase fields.
    Returns:
      - phi (belief-phase): always initialized
      - phi_model (model-phase): zero if config.identical_models else offset
    """
    dtype = getattr(config, 'dtype', mask.dtype)
    spatial_sigma = getattr(config, 'phi_init_smooth_sigma', 0.5)

    # Base phi field (belief)
    phi_base = rng.normal(scale=phi_init, size=(*domain_size, lie_algebra_dim)).astype(dtype)
    phi_smooth = gaussian_filter(phi_base, sigma=spatial_sigma)
    phi_masked = phi_smooth * mask[..., None]

    # Handle model-phase
    if getattr(config, "identical_models", False):
        phi_model_masked = np.zeros_like(phi_masked)
    else:
        delta = rng.normal(scale=phi_model_offset, size=(*domain_size, lie_algebra_dim)).astype(dtype)
        phi_model = gaussian_filter(phi_smooth + delta, sigma=spatial_sigma)
        phi_model_masked = phi_model * mask[..., None]

    return phi_masked, phi_model_masked

def assign_neighbors_vectorized(
    agents: list,
    overlap_eps: float,
    max_neighbors: int
) -> None:
    """
    Vectorized neighbor assignment based on mask overlap.
    """
    N = len(agents)
    dtype = getattr(config, 'dtype', np.float32)

    # Flatten and cast masks for memory efficiency
    masks = np.stack([agent.mask.flatten().astype(dtype) for agent in agents])  # shape: (N, prod(domain_size))
    # Compute pairwise overlaps
    overlap_matrix = masks @ masks.T
    threshold = overlap_eps * masks.shape[1]
    overlap_bool = overlap_matrix > threshold

    for i in range(N):
        overlap_bool[i, i] = False
        neighbors_sorted = np.argsort(-overlap_matrix[i])
        valid = [j for j in neighbors_sorted if overlap_bool[i, j]]
        agents[i].neighbors = [{"id": j} for j in valid[:max_neighbors]]

def plot_agent_overlap(agent_i, agent_j, cutoff=None):
    import matplotlib.pyplot as plt
    import numpy as np
    import config

    if cutoff is None:
        cutoff = getattr(config, "support_cutoff_eps", 1e-3)

    mask_i  = agent_i.mask > cutoff
    mask_j  = agent_j.mask > cutoff
    overlap = mask_i & mask_j

    if mask_i.ndim != 2:
        raise ValueError(f"plot_agent_overlap only supports 2D spatial domains, got shape {mask_i.shape}")

    H, W = mask_i.shape

    fig, axs = plt.subplots(1, 3, figsize=(12, 4))

    for ax, M, title in zip(
        axs,
        [mask_i, mask_j, overlap],
        [f"Agent {agent_i.id} Support",
         f"Agent {agent_j.id} Support",
         "Overlap"]
    ):
        ax.imshow(
            M,
            cmap="gray",
            origin="lower",
            extent=[0, W, 0, H],
            interpolation="nearest"
        )
        ax.set_title(title)
        ax.set_xticks([0, W//2, W])
        ax.set_yticks([0, H//2, H])

    plt.tight_layout()
    plt.show()

import numpy as np
import matplotlib.pyplot as plt
from numpy.random import default_rng

import config

def initialize_agents(
    seed: int,
    domain_size: tuple[int, ...],
    N: int,
    K: int,
    lie_algebra_dim: int,
    visualize: bool = False,
    fixed_location: bool = True,
) -> list[Agent]:
    from numpy.random import default_rng
    from natural_gradient_utils import sanitize_sigma

    rng = default_rng(seed)
    cfg = {k: getattr(config, k) for k in dir(config) if not k.startswith("__")}
    phi_init         = cfg["phi_init"]
    phi_model_offset = cfg.get("phi_model_offset", 0.1)
    max_neighbors    = cfg.get("max_neighbors", 8)
    dtype            = cfg.get("dtype", np.float32)

    D = len(domain_size)
    fixed_center = tuple(s // 2 for s in domain_size) if fixed_location else None

    agents: list[Agent] = []
    shared_mu_p = shared_sigma_p = None

    # Shared model for identical agents
    if getattr(config, "identical_models", False):
        _, _, shared_mu_p, shared_sigma_p = create_smooth_fields(domain_size, rng, K)

    for n in range(N):
        radius = rng.uniform(*cfg.get("psi_radius_range", (5, 10)))
        center = fixed_center or tuple(rng.integers(0, s) for s in domain_size)
        mask = create_agent_mask(center, radius, domain_size)

        mu_q_field, sigma_q_field, mu_p_field, sigma_p_field = create_smooth_fields(domain_size, rng, K)

        if getattr(config, "identical_models", False):
            mu_p_field    = shared_mu_p
            sigma_p_field = shared_sigma_p

        mu_q_field    = mu_q_field.copy()    * mask[..., None]
        sigma_q_field = sigma_q_field.copy() * mask[..., None, None]
        mu_p_field    = mu_p_field.copy()    * mask[..., None]
        sigma_p_field = sigma_p_field.copy() * mask[..., None, None]

        phi_masked, phi_model_masked = initialize_phi_fields(
            domain_size, lie_algebra_dim, rng,
            phi_init, phi_model_offset, mask
        )

        agent = Agent(
            id=n,
            center=center,
            radius=radius,
            mask=mask.astype(dtype),
            mu_q_field=mu_q_field.astype(dtype),
            sigma_q_field=sigma_q_field.astype(dtype),
            mu_p_field=mu_p_field.astype(dtype),
            sigma_p_field=sigma_p_field.astype(dtype),
            phi=phi_masked,
            phi_model=phi_model_masked,
            neighbors=[],
        )

        # ── 🔒 Sanitize covariance fields and zero out-of-mask ──
        agent.sigma_q_field = sanitize_sigma(agent.sigma_q_field)
        agent.sigma_p_field = sanitize_sigma(agent.sigma_p_field)

        mask_bool = agent.mask.astype(bool)
        agent.mu_q_field[~mask_bool] = 0.0
        agent.mu_p_field[~mask_bool] = 0.0
        agent.sigma_q_field[~mask_bool] = 0.0
        agent.sigma_p_field[~mask_bool] = 0.0

        agents.append(agent)

    assign_neighbors_vectorized(agents, cfg.get("overlap_eps", 1e-3), max_neighbors)
    print(f"[DEBUG] Initialized {len(agents)} agents with K={K}, domain={domain_size}, dtype={dtype}")

    # ── Optional validation ──
    for A in agents:
        mask = A.mask > config.support_cutoff_eps
        if not np.isfinite(A.sigma_q_field[mask]).all():
            print(f"[VALIDATION] Agent {A.id}: bad Σ_q inside mask")
        if not np.isfinite(A.sigma_p_field[mask]).all():
            print(f"[VALIDATION] Agent {A.id}: bad Σ_p inside mask")

    return agents
