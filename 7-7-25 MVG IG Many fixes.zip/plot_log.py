#!/usr/bin/env python3
# ──────────────────────────────────────────────────────────────────────────────
# File: plot_metrics.py
# Purpose:  Visualise logs produced by run_simulation() / log_all_metrics_fused
# Author:   <you>
# ──────────────────────────────────────────────────────────────────────────────
import argparse, pickle, pathlib, re
from typing import List, Sequence, Optional, Dict

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt                     # ← keep deps minimal

# --------------------------------------------------------------------------- #
#                               I/O HELPERS                                   #
# --------------------------------------------------------------------------- #
def load_metric_log_pkl(path: pathlib.Path) -> pd.DataFrame:
    """Load metric_log.pkl → DataFrame (one row per step)."""
    if not path.exists():
        raise FileNotFoundError(path)
    with open(path, "rb") as f:
        log = pickle.load(f)           # list[dict]
    return pd.DataFrame(log)

def load_per_agent_csv(path: pathlib.Path) -> pd.DataFrame:
    """Load per_agent_metrics.csv if present."""
    if path.exists():
        return pd.read_csv(path)
    else:
        return pd.DataFrame()          # empty ⇒ simply ignored later

# --------------------------------------------------------------------------- #
#                             PLOTTING CORE                                   #
# --------------------------------------------------------------------------- #
def numeric_columns(df: pd.DataFrame, skip: Sequence[str] = ()) -> List[str]:
    """Return names of float/int columns (excluding 'step' & any in skip)."""
    cols = []
    for c in df.columns:
        if c in skip or c == "step":
            continue
        if pd.api.types.is_numeric_dtype(df[c]):
            cols.append(c)
    return cols

def plot_scalar_series(
    steps, values, ylabel: str, title: str, save_path: pathlib.Path
):
    plt.figure()
    plt.plot(steps, values, linewidth=1.5)
    plt.xlabel("Simulation step")
    plt.ylabel(ylabel)
    plt.title(title)
    plt.tight_layout()
    plt.savefig(save_path, dpi=150)
    plt.close()

# --------------------------------------------------------------------------- #
#                             MAIN ROUTINE                                    #
# --------------------------------------------------------------------------- #
def main(
    outdir: pathlib.Path,
    figs_dir: pathlib.Path,
    *,
    energy_regex: str = r"^e_",       # treat any column starting with 'e_' as energy
    aggregate: str = "mean",          # 'mean' or 'sum' for per-agent roll-up
):
    figs_dir.mkdir(parents=True, exist_ok=True)

    # 1. GLOBAL / aggregate metrics (metric_log.pkl) -------------------------
    df_global = load_metric_log_pkl(outdir / "metric_log.pkl")
    if df_global.empty:
        print("[WARN] metric_log.pkl is empty or missing.")
    else:
        num_cols_g = numeric_columns(df_global)
        for col in num_cols_g:
            plot_scalar_series(
                df_global["step"], df_global[col],
                ylabel=col, title=f"{col} (global)",
                save_path=figs_dir / f"{col}_global.png",
            )

        # 2. PER-AGENT metrics (per_agent_metrics.csv) --------------------------
    df_agent = load_per_agent_csv(outdir / "per_agent_metrics.csv")
    if df_agent.empty:
        print("[INFO] per_agent_metrics.csv not found – skipping per-agent plots.")
    else:
        num_cols_a = numeric_columns(df_agent, skip=("agent",))
        grouped    = df_agent.groupby("step")
        agg_df     = getattr(grouped, aggregate)()        # DataFrame

        for col in num_cols_a:
            series = agg_df[col]                          # Series (step → value)
            plot_scalar_series(
                series.index, series.values,
                ylabel=f"{aggregate}({col})",
                title=f"{col} ({aggregate} across agents)",
                save_path=figs_dir / f"{col}_{aggregate}.png",
            )

        # stacked energy chart
        energy_cols = [c for c in num_cols_a if re.match(energy_regex, c)]
        if energy_cols:
            energy_df = agg_df[energy_cols]               # already aggregated
            plt.figure(figsize=(8, 5))
            bottom = np.zeros(len(energy_df))
            for col in energy_cols:
                plt.bar(
                    energy_df.index, energy_df[col],
                    bottom=bottom, label=col, width=1.0,
                )
                bottom += energy_df[col].values
            plt.xlabel("Simulation step")
            plt.ylabel(f"{aggregate} energy per agent")
            plt.title("Energy budget decomposition")
            plt.legend(fontsize=7, frameon=False)
            plt.tight_layout()
            plt.savefig(figs_dir / "energy_budget_stacked.png", dpi=150)
            plt.close()


        print(f"[DONE] Figures → {figs_dir.resolve()}")

# --------------------------------------------------------------------------- #
if __name__ == "__main__":
    p = argparse.ArgumentParser(
        description="Plot metrics produced by log_all_metrics_fused()",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    p.add_argument("--outdir", default="checkpoints",
                   help="Simulation output directory")
    p.add_argument("--figdir", default="Holonomy_Visualizations",
                   help="Where to write PNGs")
    p.add_argument("--aggregate", choices=("mean", "sum"), default="mean",
                   help="How to combine per-agent values at each step")
    args = p.parse_args()

    main(
        pathlib.Path(args.outdir),
        pathlib.Path(args.figdir),
        aggregate=args.aggregate,
    )
