import numpy as np
from get_generators import get_generators


from generalized_omega import compute_gauge_potential
import numpy as np
import matplotlib.pyplot as plt
import os

from generalized_agent_distributions import (
    initialize_multivariate_gaussian_distribution,
    get_fiber_basis,
)


SAVE_DIR = "Holonomy_Visualizations/pullback_debug"
os.makedirs(SAVE_DIR, exist_ok=True)

def compute_agent_pullback_blocks(agent, vis_inds, dark_inds, eps=1e-12):
    """
    Compute pullback blocks for a given agent using its model field.
    Returns: dictionary with blocks I, M_vis, M_dark, Delta, G
    """
    K = agent.mu_p_field.shape[-1]
    fiber_x = get_fiber_basis(K)

    # Reconstruct full model distribution p(c) over the fiber
    p_field = initialize_multivariate_gaussian_distribution(
        x_coords    = fiber_x,
        mu_field    = agent.mu_p_field,
        sigma_field = agent.sigma_p_field,
        mask        = agent.mask,
        log_eps     = eps,
    )  # shape (H, W, K)

    # Compute pullback metric blocks
    pull = compute_pullback_grid(
        p_grid     = p_field,
        phi_grid   = agent.phi_model,
        K          = K,
        vis_inds   = vis_inds,
        dark_inds  = dark_inds,
        eps        = eps,
    )

    return pull



def algebra_fisher_metric(p_c, generators, eps=1e-12):
    """
    Compute the Fisher metric on the Lie algebra at a single base point.

    Args:
        p_c:         (K,) — probability vector at a single point in the fiber (∑ p_k = 1)
        generators:  (d, K, K) — Lie algebra generators T_a in the fiber representation
        eps:         float — regularization to avoid division by 0

    Returns:
        I: (d, d) — Fisher information metric over the Lie algebra directions
    """
    # Ensure p is properly normalized and clipped to avoid div-by-zero
    p_safe = np.clip(p_c, eps, 1.0)
    p_safe /= np.sum(p_safe)

    d = generators.shape[0]  # dim of the Lie algebra

    # V[a, k] = (T_a · p)_k
    V = np.tensordot(generators, p_safe, axes=([1], [0]))  # shape (d, K)

    # I_ab = sum_k (T_a p)_k (T_b p)_k / p_k
    I = np.einsum('ak,bk,k->ab', V, V, 1.0 / p_safe)  # (d, d)

    return I



def block_decompose(I, vis_inds, dark_inds):
    """
    Decompose a full algebra metric I into visible, mixing, and dark blocks.

    I: array (d, d)
    vis_inds: list of indices for the visible subalgebra
    dark_inds: list of indices for the dark subalgebra

    Returns
    -------
    M_vis: I[np.ix_(vis_inds, vis_inds)]
    Delta: I[np.ix_(vis_inds, dark_inds)]
    M_dark: I[np.ix_(dark_inds, dark_inds)]
    """
    mix_inds = [i for i in range(I.shape[0]) if i not in vis_inds + dark_inds]
    M_vis = I[np.ix_(vis_inds, vis_inds)]
    Delta = I[np.ix_(vis_inds, dark_inds)]
    M_dark = I[np.ix_(dark_inds, dark_inds)]
    return M_vis, Delta, M_dark


def pullback_metric_at_point(I_ab, A_vecs):
    """
    Given algebra metric I_ab and gauge potential vectors A_vecs, compute
    the pulled-back spatial metric G_{mu nu} = A_mu^T I A_nu.

    I_ab: array (d, d)
    A_vecs: list or array of length D, each element shape (d,)

    Returns
    -------
    G: array shape (D, D) -- spatial metric at this point
    """
    D = len(A_vecs)
    return np.array([[A_vecs[mu] @ (I_ab @ A_vecs[nu]) for nu in range(D)]
                     for mu in range(D)])


def compute_pullback_grid(p_grid, phi_grid, K, vis_inds, dark_inds, eps=1e-12):
    generators = get_generators('sl2r', K)  # (d, K, K)
    A_fields = compute_gauge_potential(phi_grid)  # tuple length D, each (N1, N2, d)

    N1, N2, d = phi_grid.shape
    D = len(A_fields)

    # Precompute I_grid using vectorization
    p_safe = np.clip(p_grid, eps, None)  # (N1, N2, K)
    V_batch = np.einsum('abc,ijc->ijab', generators, p_safe)  # (N1, N2, d, K)
    I_grid = np.einsum('ijak,ijbk,ijk->ijab', V_batch, V_batch, 1 / p_safe)

    # Block decompositions (corrected slicing using np.ix_)
    vis_ix  = np.ix_(vis_inds, vis_inds)
    dark_ix = np.ix_(dark_inds, dark_inds)
    mix_ix  = np.ix_(vis_inds, dark_inds)

    M_vis_grid  = I_grid[:, :, vis_ix[0], vis_ix[1]]
    Delta_grid  = I_grid[:, :, mix_ix[0], mix_ix[1]]
    M_dark_grid = I_grid[:, :, dark_ix[0], dark_ix[1]]

    # Compute spatial metric G using vectorization
    A_stack = np.stack(A_fields, axis=-2)  # shape (N1, N2, D, d)
    G_grid = np.einsum('...ua,...ab,...vb->...uv', A_stack, I_grid, A_stack)

    return {
        'I':      I_grid,
        'M_vis':  M_vis_grid,
        'Delta':  Delta_grid,
        'M_dark': M_dark_grid,
        'G':      G_grid,
    }

import numpy as np

def compute_fisher_metric_block_diag(sigma_field, eps=1e-8):
    """
    Compute the block-diagonal Fisher metric G = Σ⁻¹ for a field of full
    multivariate Gaussian covariances.

    Args:
        sigma_field: (H, W, K, K) — full SPD covariance matrices
        eps: float — regularization added to diagonal for numerical stability

    Returns:
        G: (H, W, K, K) — Fisher metric Σ⁻¹ at each point
    """
    H, W, K, _ = sigma_field.shape
    G = np.zeros_like(sigma_field)

    eye = np.eye(K, dtype=sigma_field.dtype)

    for i in range(H):
        for j in range(W):
            Σ = sigma_field[i, j]
            Σ_reg = Σ + eps * eye
            try:
                G[i, j] = np.linalg.inv(Σ_reg)
            except np.linalg.LinAlgError:
                G[i, j] = np.eye(K)  # fallback to identity

    return G



import numpy as np
from scipy.ndimage import sobel
import config

import numpy as np
from scipy.ndimage import sobel

def compute_pullback_metric(mu_field, sigma_field):
    """
    Compute pullback Fisher metric from μ and Σ using full contraction:
        M_ab(c) = ∂_a μ_k · Σ^{-1}_{kl} · ∂_b μ_l
    
    Args:
        mu_field: (H, W, K)
        sigma_field: (H, W, K, K)
    
    Returns:
        M: (H, W, D, D) — pullback metric (e.g., D=2 for 2D grid)
    """
    from pullback_utils import compute_fisher_metric_block_diag
    from scipy.ndimage import sobel

    H, W, K = mu_field.shape
    D = 2  # spatial dimensions
    M = np.zeros((H, W, D, D), dtype=mu_field.dtype)

    # Compute Fisher metric G_kl = Σ⁻¹
    G_p = compute_fisher_metric_block_diag(sigma_field)  # (H, W, K, K)

    # Compute ∇μ: (H, W, D, K)
    grad_mu = np.stack([
        sobel(mu_field, axis=0, mode='wrap') / 8.0,  # ∂y μ
        sobel(mu_field, axis=1, mode='wrap') / 8.0,  # ∂x μ
    ], axis=2)  # shape: (H, W, D, K)

    # Compute M_ab = ∇μ_a^k · G_kl · ∇μ_b^l
    for a in range(D):
        for b in range(D):
            for k in range(K):
                for l in range(K):
                    M[..., a, b] += grad_mu[..., a, k] * G_p[..., k, l] * grad_mu[..., b, l]

    return M


