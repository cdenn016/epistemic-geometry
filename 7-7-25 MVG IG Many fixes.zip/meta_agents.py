import itertools as it
import json
from pathlib import Path

import numpy as np
import matplotlib.pyplot as plt
from matplotlib import cm
import networkx as nx

import config
from generalized_io_utils import load_final_step, load_agents, save_generic_alignment_data
from get_generators import get_generators
from generalized_omega import (
    compute_field_strength,
    compute_pairwise_kl,
    compute_pairwise_model_kl
)

def curvature_mean_per_agent(agents, generators) -> np.ndarray:
    """
    Compute ⟨‖F‖⟩ for each agent using field strength from generalized_omega.
    Only includes values inside the agent's support.
    """
    eps = getattr(config, "support_cutoff_eps", 1e-3)
    means = []

    for ag in agents:
        mask = ag.mask > eps
        F_dict = compute_field_strength(ag.phi, generators)

        total_norm = 0.0
        count = 0

        for F in F_dict.values():
            # F can have shape (H, W, K, K)
            if F.ndim == 4:
                norm = np.linalg.norm(F, axis=(-2, -1))  # Frobenius norm per point
            elif F.ndim == 3:
                norm = np.linalg.norm(F, axis=-1)        # vector-valued
            elif F.ndim == 2:
                norm = np.abs(F)                         # scalar field
            else:
                raise ValueError(f"[curvature] Unexpected F shape: {F.shape}")

            total_norm += np.sum(norm[mask])
            count += np.sum(mask)

        mean = total_norm / count if count > 0 else 0.0
        means.append(mean)

    return np.array(means)

def compute_phi_variance_per_cluster(agents, labels):
    """
    Compute φ-norm variance for each cluster of agents.

    Returns:
        stats: dict {cluster_id: {'phi_means': [...], 'phi_var': float}}
    """
    eps = getattr(config, "support_cutoff_eps", 1e-3)
    stats = {}

    for lab in np.unique(labels):
        if lab < 0:
            continue  # Ignore noise/outlier label

        idx = np.where(labels == lab)[0]
        means = []

        for i in idx:
            agent = agents[i]
            if agent.phi is None:
                continue
            mask = agent.mask > eps
            phi_norm = np.linalg.norm(agent.phi, axis=-1)
            if np.any(mask):
                mean_val = np.mean(phi_norm[mask])
                means.append(float(mean_val))

        if means:
            stats[int(lab)] = {
                'phi_means': means,
                'phi_var': float(np.var(means))
            }

    return stats

import matplotlib.pyplot as plt
from pathlib import Path

def plot_phi_variance(phi_stats, outpath=None):
    """
    Plot the variance of φ-norm means per cluster.

    Args:
        phi_stats: dict from compute_phi_variance_per_cluster()
        outpath: optional path to save the figure (e.g. 'meta_agent_analysis/phi_var.png')
    """
    if not phi_stats:
        print("[WARN] No phi_stats to plot.")
        return

    labels = sorted(phi_stats.keys())
    variances = [phi_stats[l]['phi_var'] for l in labels]

    plt.figure(figsize=(6, 4))
    bars = plt.bar([str(l) for l in labels], variances, color='teal')
    plt.xlabel('Cluster')
    plt.ylabel('Var(⟨‖φ‖⟩)')
    plt.title('Intra-Cluster φ Norm Variance')

    for bar, var in zip(bars, variances):
        height = bar.get_height()
        plt.text(bar.get_x() + bar.get_width()/2, height,
                 f"{var:.2e}", ha='center', va='bottom', fontsize=8)

    if outpath:
        Path(outpath).parent.mkdir(parents=True, exist_ok=True)
        plt.savefig(outpath, bbox_inches='tight')
        print(f"[✓] Saved φ variance plot → {outpath}")

    plt.tight_layout()
    plt.show()

import numpy as np
import matplotlib.pyplot as plt
from pathlib import Path
from generalized_omega import compute_field_strength
import config

def plot_curvature_heatmap(agents, labels, generators, outpath=None):
    """
    Plot a spatial heatmap of cumulative curvature norm ‖F‖ over all agents,
    overlaying contours of cluster-assigned agent masks.

    Args:
        agents: list of Agent objects
        labels: array-like cluster assignments (same length as agents)
        generators: Lie algebra generators for compute_field_strength
        outpath: optional path to save figure (e.g. 'meta_agent_analysis/curvature_heatmap.png')
    """
    if not agents:
        print("[WARN] Empty agent list. Aborting curvature heatmap.")
        return

    grid_shape = agents[0].phi.shape[:-1]
    curvature_sum = np.zeros(grid_shape, dtype=float)

    for i, ag in enumerate(agents):
        if labels[i] < 0:
            continue  # skip unclustered agents
        try:
            F_dict = compute_field_strength(ag.phi, generators)  # {'xy': (..., K, K), ...}
            F_stack = np.stack(list(F_dict.values()), axis=-1)   # (..., K, K, n_dirs)
            norm_F = np.linalg.norm(F_stack, axis=(-2, -1, -1))  # Frobenius norm across all dirs
            curvature_sum += norm_F
        except Exception as e:
            print(f"[!] Failed to compute curvature for agent {i}: {e}")

    plt.figure(figsize=(5, 5))
    im = plt.imshow(curvature_sum, origin='lower', cmap='plasma')
    plt.title('Curvature Norm Heatmap (‖F‖)')

    # Overlay cluster agent boundaries
    for i, ag in enumerate(agents):
        if labels[i] < 0:
            continue
        plt.contour(ag.mask > config.support_cutoff_eps,
                    levels=[0.5], colors='white', linewidths=0.5)

    if curvature_sum.max() > curvature_sum.min():
        plt.colorbar(im, label='‖F‖')

    if outpath:
        Path(outpath).parent.mkdir(parents=True, exist_ok=True)
        plt.savefig(outpath, dpi=150, bbox_inches='tight')
        print(f"[✓] Saved curvature heatmap → {outpath}")
    plt.close()

import numpy as np
import matplotlib.pyplot as plt
from pathlib import Path

def compute_symmetric_kl_matrix(kl_matrix: np.ndarray) -> np.ndarray:
    """
    Compute the symmetrized KL matrix:
        D_sym(i, j) = 0.5 * [ D_KL(q_i || Ω q_j) + D_KL(q_j || Ω⁻¹ q_i) ]
    Args:
        kl_matrix: (N, N) asymmetric KL divergence matrix
    Returns:
        symmetric KL matrix (N, N)
    """
    assert kl_matrix.shape[0] == kl_matrix.shape[1], "KL matrix must be square"
    return 0.5 * (kl_matrix + kl_matrix.T)


def plot_matrix(kl_matrix: np.ndarray, labels=None, outdir="alignment_output",
                fname="alignment_matrix.png", label="D_KL(q_i || Ω q_j)",
                title="Pairwise Alignment Matrix", cmap="viridis"):
    """
    Plot a heatmap of a pairwise alignment or KL matrix.

    Args:
        kl_matrix: (N, N) matrix of divergences or similarities
        labels: optional list of cluster labels for tick coloring
        outdir: output directory to save the figure
        fname: output filename
        label: colorbar label
        title: plot title
        cmap: colormap to use
    """
    Path(outdir).mkdir(parents=True, exist_ok=True)
    N = kl_matrix.shape[0]

    plt.figure(figsize=(8, 6))
    im = plt.imshow(kl_matrix, cmap=cmap, interpolation="nearest")
    cbar = plt.colorbar(im)
    cbar.set_label(label)

    plt.title(title)
    plt.xlabel("Agent j")
    plt.ylabel("Agent i")

    if labels is not None and len(labels) == N:
        ticks = np.arange(N)
        plt.xticks(ticks)
        plt.yticks(ticks)
        # color tick labels by cluster
        ax = plt.gca()
        for axis, tick_labels in zip([ax.xaxis, ax.yaxis], [ax.get_xticklabels(), ax.get_yticklabels()]):
            for k, lbl in enumerate(tick_labels):
                color = f"C{labels[k] % 10}" if labels[k] >= 0 else "gray"
                lbl.set_color(color)

    savepath = Path(outdir) / fname
    plt.tight_layout()
    plt.savefig(savepath, dpi=150)
    plt.close()
    print(f"[✓] Saved matrix → {savepath}")


import numpy as np


def rank_agent_alignment(kl_matrix: np.ndarray) -> dict:
    """
    For each agent i, rank all others by alignment (KL divergence).
    
    Returns:
        dict of agent i → {
            "best": index of lowest non-diagonal KL(j ≠ i),
            "worst": index of highest KL,
            "full_rank": list of indices sorted by increasing KL
        }
    """
    N = kl_matrix.shape[0]
    rankings = {}
    for i in range(N):
        dists = kl_matrix[i].copy()
        dists[i] = np.inf  # exclude self
        sorted_idx = np.argsort(dists)
        rankings[i] = {
            "best": int(sorted_idx[0]),
            "worst": int(sorted_idx[-1]),
            "full_rank": sorted_idx.tolist()
        }
    return rankings

def run_generic_alignment_analysis(
    agents,
    generators,
    params: dict,
    mode: str = "belief",
    outdir: Path = None
):
    """
    Compute, cluster, plot, and save alignment diagnostics for either belief or model fields.

    Parameters
    ----------
    agents : list
        List of Agent objects.
    generators : np.ndarray
        Lie algebra generators for the group (e.g., sl(2,R)).
    params : dict
        Runtime parameters; expects 'log_eps', 'overlap_eps', etc.
    mode : str
        Either 'belief' or 'model' – determines which alignment metric to compute.
    outdir : Path, optional
        Directory to save results. Defaults to './alignment_output' or './model_alignment_output'.
    """
    assert mode in ("belief", "model"), f"Invalid mode: {mode}"

    if mode == "belief":
        compute_kl   = compute_pairwise_kl
        prefix       = "kl"
        title        = "Epistemic Alignment Network"
        matrix_title = "Pairwise Epistemic Misalignment"
        default_dir  = Path("alignment_output")
    else:
        compute_kl   = compute_pairwise_model_kl
        prefix       = "kl_model"
        title        = "Model Alignment Network"
        matrix_title = "Pairwise Model Misalignment"
        default_dir  = Path("model_alignment_output")

    outdir = Path(outdir) if outdir else default_dir
    outdir.mkdir(parents=True, exist_ok=True)

    # Step 1: KL divergence matrix (belief or model alignment)
    kl_matrix = compute_kl(agents, generators, params)
    sym_kl    = compute_symmetric_kl_matrix(kl_matrix)
    sym_kl    = np.clip(sym_kl, 0.0, None)

    # Step 2: Auxiliary metrics
    overlap_A = overlap_area_matrix(agents, params.get("overlap_eps", 0.0))
    curv_mean = curvature_mean_per_agent(agents, generators)

    # Step 3: Meta-agent detection
    rankings  = rank_agent_alignment(sym_kl)
    meta_list, labels, eps = find_meta_agents(sym_kl, overlap_A, curv_mean)
    print(f"[INFO] mode={mode}: adaptive ε = {eps:.3f}, meta_agents = {len(meta_list)}")

    # Step 4: Visualize KL matrix and network
    plot_matrix(sym_kl, outdir=outdir, label=f"D_KL({mode})", title=matrix_title, fname="kl_matrix.png")

   
    plot_generic_alignment_network(
        sym_kl, labels,
        threshold=eps,
        outpath=outdir / "alignment_network.png",
        title=f"{title} (ε={eps:.3f})"
    )

    # Step 5: Save alignment data
    save_generic_alignment_data(
        kl_matrix=sym_kl,
        rankings=rankings,
        labels=labels,
        outdir=outdir,
        prefix=prefix
    )

    print(f"[✓] {mode.capitalize()} alignment analysis completed → {outdir}/")


def find_meta_agents(
    sym_kl: np.ndarray,
    overlap_area: np.ndarray,
    curv_mean: np.ndarray,
    tau_A: float = 10,
    eta:   float = 10,
    tau_C: float = 10,
    verbose: bool = False
):
    """
    Identify meta-agent clusters satisfying:
      A) mean intra-cluster KL < tau_A
      B) intra < eta × extra-cluster KL
      C) mean curvature < tau_C

    Returns:
        meta:   list of index lists (clusters)
        labels: np.ndarray of cluster labels per agent
        eps:    threshold used to form clusters (30% quantile)
    """
    N = sym_kl.shape[0]
    finite = sym_kl[np.isfinite(sym_kl)]

    # 1) Compute adaptive connectivity threshold
    eps = np.quantile(finite, 0.30)
    min_eps = getattr(config, "epsilon_model", 1e-6)
    if eps < min_eps:
        eps = min_eps

    # 2) Build KL-based graph
    G = nx.Graph()
    G.add_nodes_from(range(N))
    for i, j in it.combinations(range(N), 2):
        d = sym_kl[i, j]
        if np.isfinite(d) and d <= eps:
            G.add_edge(i, j, weight=d)

    # 3) Extract connected components satisfying alignment + curvature
    meta = []
    for comp in nx.connected_components(G):
        C = list(comp)
        if len(C) < 2:
            continue

        C_set = set(C)
        out_set = set(range(N)) - C_set
        intra_vals = sym_kl[np.ix_(C, C)]
        intra_vals = intra_vals[np.isfinite(intra_vals)]
        intra_mean = float(intra_vals.mean()) if intra_vals.size > 0 else np.inf

        curv_meanC = float(curv_mean[np.array(C)].mean())

        extra_vals = sym_kl[np.ix_(C, list(out_set))]
        extra_vals = extra_vals[np.isfinite(extra_vals)]
        extra_mean = float(extra_vals.mean()) if extra_vals.size > 0 else np.inf

        accept = False
        if extra_vals.size == 0:
            if intra_mean < tau_A and curv_meanC < tau_C:
                accept = True
        else:
            if (intra_mean < tau_A and
                intra_mean < eta * extra_mean and
                curv_meanC < tau_C):
                accept = True

        if accept:
            meta.append(C)
            if verbose:
                print(f"[meta-cluster] size={len(C)}, "
                      f"<KL_intra>={intra_mean:.3f}, "
                      f"<KL_extra>={extra_mean:.3f}, "
                      f"<curv>={curv_meanC:.3f}")

    # 4) Assign labels to agents
    labels = np.full(N, -1, dtype=int)
    for k, C in enumerate(meta):
        labels[np.array(C)] = k

    return meta, labels, eps

def compute_cluster_kl_stats(kl_matrix: np.ndarray, labels: np.ndarray, verbose: bool = False):
    """
    Compute intra-/extra-cluster KL values, means, and stds for each cluster.

    Parameters
    ----------
    kl_matrix : np.ndarray
        (N, N) symmetric KL matrix.
    labels : np.ndarray
        (N,) array of cluster labels (−1 for unassigned).
    verbose : bool
        Whether to print statistics per cluster.

    Returns
    -------
    stats : dict
        Dictionary keyed by cluster index, with values:
        {
            'intra_vals': array of intra-cluster KLs,
            'extra_vals': array of extra-cluster KLs,
            'intra_mean': float,
            'extra_mean': float,
            'intra_std': float,
            'extra_std': float
        }
    """
    stats = {}
    for lab in np.unique(labels):
        if lab < 0:
            continue

        idx = np.where(labels == lab)[0]
        others = np.where(labels != lab)[0]

        # INTRA-cluster KLs (upper triangle only, exclude diagonal)
        if len(idx) > 1:
            dsub = kl_matrix[np.ix_(idx, idx)]
            iu = np.triu_indices(len(idx), k=1)
            intra_vals = dsub[iu]
            intra_vals = intra_vals[np.isfinite(intra_vals)]
        else:
            intra_vals = np.array([])

        # EXTRA-cluster KLs
        if others.size:
            extra_vals = kl_matrix[np.ix_(idx, others)].ravel()
            extra_vals = extra_vals[np.isfinite(extra_vals)]
        else:
            extra_vals = np.array([])

        intra_mean = float(np.mean(intra_vals)) if intra_vals.size else np.nan
        extra_mean = float(np.mean(extra_vals)) if extra_vals.size else np.nan
        intra_std  = float(np.std(intra_vals))  if intra_vals.size else np.nan
        extra_std  = float(np.std(extra_vals))  if extra_vals.size else np.nan

        stats[int(lab)] = {
            'intra_vals': intra_vals,
            'extra_vals': extra_vals,
            'intra_mean': intra_mean,
            'extra_mean': extra_mean,
            'intra_std': intra_std,
            'extra_std': extra_std,
        }

        if verbose:
            print(f"[cluster {lab}] N={len(idx)}, "
                  f"<KL_intra>={intra_mean:.3f}±{intra_std:.3f}, "
                  f"<KL_extra>={extra_mean:.3f}±{extra_std:.3f}")

    return stats

def compute_order_parameter(kl_matrix: np.ndarray):
    i,j = np.triu_indices(kl_matrix.shape[0], k=1)
    d = kl_matrix[i,j]
    d = d[np.isfinite(d)]
    sigma = float(np.median(d)) if d.size else 1.0
    R = float(np.sum(np.exp(-d/sigma)) / d.size) if d.size else 0.0
    return R, sigma

def compute_cluster_order_parameters(kl_matrix, labels):
    """
    For each cluster label >=0, compute
      σ_C = median of D_KL(i,j) over i<j in C
      R_C = average of exp(-D_KL(i,j)/σ_C) over i<j in C
    Returns dict: {cluster_label: (R_C, σ_C)}
    """
    
    clusters = {}
    for lab in sorted(set(labels)):
        if lab < 0:
            continue
        idx = np.where(labels == lab)[0]
        if len(idx) < 2:
            # singletons get R=1.0 by definition (or skip)
            clusters[lab] = (1.0, 0.0)
            continue

        # extract upper‐triangle of the submatrix
        sub = kl_matrix[np.ix_(idx, idx)]
        i, j = np.triu_indices(len(idx), k=1)
        vals = sub[i, j]
        vals = vals[np.isfinite(vals)]

        sigma_C = float(np.median(vals)) if vals.size else 1.0
        R_C     = float(np.mean(np.exp(-vals / sigma_C))) if sigma_C > 0 else 1.0
        clusters[lab] = (R_C, sigma_C)
    return clusters

def load_meta_data(alignment_dir: str, prefix: str = "kl"):
    """
    Load KL matrix, cluster labels, and rankings from the alignment output directory.
    Returns (kl_matrix, labels, rankings_dict).
    """
    import json
    from pathlib import Path
    import numpy as np

    alignment_path = Path(alignment_dir).resolve()
    matrix_file = alignment_path / f"{prefix}_matrix.csv"
    labels_file = alignment_path / f"{prefix}_labels.csv"
    meta_file   = alignment_path / f"{prefix}_meta.json"

    if not matrix_file.exists():
        raise FileNotFoundError(f"Missing KL matrix file: {matrix_file}")
    if not labels_file.exists():
        raise FileNotFoundError(f"Missing cluster label file: {labels_file}")

    kl_matrix = np.loadtxt(matrix_file, delimiter=',')
    labels    = np.loadtxt(labels_file, dtype=int, delimiter=',')

    if meta_file.exists():
        with open(meta_file, 'r') as f:
            meta = json.load(f)
        rankings = meta.get('rankings', {})
    else:
        rankings = {}

    print(f"[LOAD] Loaded KL matrix from {matrix_file.name}, labels from {labels_file.name}")
    return kl_matrix, labels, rankings

def plot_intra_kl_distribution(cluster_stats, outpath, show_fliers=False):
    """
    Plot boxplots of intra-cluster KL distributions.
    
    Parameters
    ----------
    cluster_stats : dict
        Output of compute_cluster_kl_stats, keyed by cluster label.
    outpath : str or Path
        Filepath where the plot will be saved.
    show_fliers : bool
        Whether to show outliers in the boxplot.
    """
    from pathlib import Path
    import matplotlib.pyplot as plt

    Path(outpath).parent.mkdir(parents=True, exist_ok=True)

    labels = []
    data   = []

    for lab in sorted(cluster_stats.keys()):
        vals = cluster_stats[lab]['intra_vals']
        if vals.size > 0:
            labels.append(str(lab))
            data.append(vals)

    if not data:
        print("[!] No intra-cluster KL values to plot.")
        return

    fig, ax = plt.subplots(figsize=(6, 4))
    ax.boxplot(data, vert=True, showfliers=show_fliers)
    ax.set_xticklabels(labels)
    ax.set_ylabel("Pointwise D_KL")
    ax.set_title("Intra-cluster KL Distributions")
    ax.grid(True, linestyle='--', alpha=0.4)

    fig.tight_layout()
    fig.savefig(outpath, dpi=150)
    plt.close(fig)


def plot_inter_vs_intra(cluster_stats, outpath=None):
    """
    Bar chart comparing mean intra-cluster vs extra-cluster KL for each cluster.
    """
    import numpy as np
    import matplotlib.pyplot as plt
    from pathlib import Path

    labels = sorted(cluster_stats.keys())
    intra = [cluster_stats[lab]['intra_mean'] for lab in labels]
    extra = [cluster_stats[lab]['extra_mean'] for lab in labels]
    x = np.arange(len(labels))

    fig, ax = plt.subplots(figsize=(6, 4))
    width = 0.35
    ax.bar(x - width/2, intra, width=width, label='Intra-cluster KL')
    ax.bar(x + width/2, extra, width=width, label='Extra-cluster KL')

    ax.set_xticks(x)
    ax.set_xticklabels([str(l) for l in labels])
    ax.set_ylabel('Mean D_KL')
    ax.set_title('Mean KL Divergence: Intra vs Extra per Cluster')
    ax.legend()
    ax.grid(True, linestyle='--', alpha=0.4)

    fig.tight_layout()
    if outpath:
        Path(outpath).parent.mkdir(parents=True, exist_ok=True)
        fig.savefig(outpath, dpi=150)
    plt.close(fig)

def plot_spatial_cluster_map(agents, labels, outpath=None):
    """
    Draw spatial map of agent clusters using contour overlays and agent indices.
    """
    import matplotlib.pyplot as plt
    import matplotlib.cm as cm
    from pathlib import Path
    import numpy as np

    cmap = cm.get_cmap('tab10')
    plt.figure(figsize=(5, 5))

    for i, ag in enumerate(agents):
        lab = labels[i]
        if lab < 0:
            continue

        # Robust fallback for mask visibility
        mask_bool = ag.mask > getattr(config, "support_cutoff_eps", 0.0)
        if not np.any(mask_bool):
            mask_bool = ag.mask > 0.0

        color = cmap(lab % cmap.N)
        plt.contour(mask_bool, levels=[0.5], colors=[color], linewidths=1)

        # Agent center text marker
        if hasattr(ag, "center") and ag.center is not None:
            cx, cy = ag.center
            plt.text(cy, cx, str(i), color=color, ha='center', va='center', fontsize=7)

    plt.title('Spatial Cluster Map')
    plt.axis('off')
    plt.tight_layout()

    if outpath:
        Path(outpath).parent.mkdir(parents=True, exist_ok=True)
        plt.savefig(outpath, dpi=150)
    plt.show()


def plot_cluster_order_parameters(cluster_R, outpath=None):
    """
    Plot the local order parameter R_C for each cluster and annotate σ_C above each bar.
    """
    import matplotlib.pyplot as plt
    from pathlib import Path

    labs        = sorted(cluster_R.keys())
    R_vals      = [cluster_R[l][0] for l in labs]
    sigma_vals  = [cluster_R[l][1] for l in labs]

    fig, ax = plt.subplots(figsize=(6, 4))
    bars = ax.bar([str(l) for l in labs], R_vals, color="tab:blue")

    ax.set_xlabel("Cluster")
    ax.set_ylabel(r"$R_C$")
    ax.set_title("Local Order Parameter per Meta-Agent")

    for bar, σ in zip(bars, sigma_vals):
        ax.text(bar.get_x() + bar.get_width() / 2,
                bar.get_height(),
                f"$\\sigma$={σ:.1e}",
                ha='center', va='bottom',
                fontsize=8)

    plt.tight_layout()
    if outpath:
        Path(outpath).parent.mkdir(parents=True, exist_ok=True)
        fig.savefig(outpath, dpi=150)
    plt.show()

def overlap_area_matrix(agents, eps: float = 1e-6) -> np.ndarray:
    """
    Compute N x N matrix where entry (i, j) is the area of overlap between agent i and j.
    """
    N = len(agents)
    area = np.zeros((N, N), dtype=float)
    for i in range(N):
        mask_i = agents[i].mask > eps
        for j in range(i, N):
            if i == j:
                area[i, j] = np.sum(mask_i)
            else:
                mask_j = agents[j].mask > eps
                area_ij = np.sum(np.logical_and(mask_i, mask_j))
                area[i, j] = area[j, i] = area_ij
    return area


def plot_generic_alignment_network(
    kl_matrix: np.ndarray,
    cluster_labels: np.ndarray,
    threshold: float,
    outpath: str = "alignment_output/alignment_network.png",
    title: str = "Epistemic Alignment Network",
    node_size: int = 500,
    show_labels: bool = True
):
    """
    Visualize agent alignment as a network.
    Edges connect agents with KL < threshold.
    Nodes are colored by cluster_labels.
    """

    import numpy as np
    import matplotlib.pyplot as plt
    import networkx as nx
    from pathlib import Path

    N = kl_matrix.shape[0]
    G = nx.Graph()

    # 1) Add nodes with cluster labels
    for i in range(N):
        G.add_node(i, cluster=cluster_labels[i])

    # 2) Add edges for D_KL(i,j) < threshold
    for i in range(N):
        for j in range(i + 1, N):
            d = kl_matrix[i, j]
            if np.isfinite(d) and d < threshold:
                G.add_edge(i, j, weight=np.exp(-d))  # similarity weight

    # 3) Node positions and colors
    pos = nx.spring_layout(G, seed=42)  # deterministic layout
    unique_labels = sorted(set(cluster_labels))
    color_map = {label: plt.cm.tab10(i % 10) for i, label in enumerate(unique_labels)}
    node_colors = [color_map.get(cluster_labels[i], "gray") for i in range(N)]

    # 4) Plot
    plt.figure(figsize=(8, 6))
    nx.draw_networkx_nodes(
        G, pos,
        node_color=node_colors,
        node_size=node_size,
        edgecolors="black"
    )
    nx.draw_networkx_edges(G, pos, alpha=0.5)

    if show_labels:
        nx.draw_networkx_labels(G, pos, font_size=10, font_color="white")

    plt.title(f"{title} (ε = {threshold:.3f})")
    plt.axis("off")

    # 5) Save
    Path(outpath).parent.mkdir(parents=True, exist_ok=True)
    plt.savefig(outpath, dpi=150)
    plt.close()


def plot_support_phi_summary(
    agents,
    per_df,
    phi_attr="phi",
    kl_col="kl_align",
    color="red",
    phi_title="Φ Norms",
    kl_title="Alignment per Agent",
    text="No per-agent metrics"
):
    """
    Plot:
    1. Agent support masks
    2. Spatial heatmap of ‖φ‖ or ‖φ̃‖ over domain
    3. Per-agent bar chart of final KL values

    Args:
        agents    : list of Agent objects
        per_df    : DataFrame with per-agent metrics
        phi_attr  : "phi" or "phi_model"
        kl_col    : Column name in per_df for alignment KL
        color     : Bar color for panel 3
        phi_title : Title for φ panel
        kl_title  : Title for alignment panel
        text      : Message if per_df is missing
    """
    import matplotlib.pyplot as plt
    import numpy as np
    import config  # Ensure this resolves properly in your environment

    fig, axes = plt.subplots(1, 3, figsize=(18, 6))

    # ───── Panel 1: Agent support masks with indices ─────
    ax0 = axes[0]
    for idx, agent in enumerate(agents):
        mask = agent.mask
        ax0.contour(mask, levels=[getattr(config, "support_cutoff_eps", 1e-3)],
                    colors='black', linewidths=1)
        cx, cy = agent.center
        ax0.text(cy, cx, str(idx), color=color,
                 ha='center', va='center', fontsize=9, weight='bold')
    ax0.set_title("Agent Support Contours")
    ax0.axis('off')

    # ───── Panel 2: Φ or Φ̃ Norm Spatial Sum ─────
    ax1 = axes[1]
    domain_shape = getattr(config, "domain_size", agents[0].phi.shape[:2])
    combined = np.zeros(domain_shape, dtype=float)
    for agent in agents:
        phi = getattr(agent, phi_attr)  # (H, W, d)
        combined += np.linalg.norm(phi, axis=-1)
    im = ax1.imshow(combined, origin='lower', cmap='viridis')
    ax1.set_title(f"Sum of {phi_title}")
    ax1.axis('off')
    fig.colorbar(im, ax=ax1, fraction=0.046, pad=0.04)

    # ───── Panel 3: Per-agent KL bar chart ─────
    ax2 = axes[2]
    if per_df is not None and kl_col in per_df.columns:
        last_vals = per_df.groupby('agent')[kl_col].last()
        ax2.bar(last_vals.index, last_vals.values, color=color)
        ax2.set_xlabel("Agent Index")
        ax2.set_ylabel(kl_col)
        ax2.set_title(kl_title)
    else:
        ax2.text(0.5, 0.5, text, ha='center', va='center', fontsize=10)
        ax2.set_title(kl_title)
        ax2.axis('off')

    plt.tight_layout()
    plt.show()


def plot_pairwise_pointwise_heatmap(
    agents, generators, params,
    i: int, j: int,
    mode: str,
    outdir: str = "alignment_output"
):
    """
    Compute and plot the per-point KL divergence heatmap between agents i and j.
    
    Args:
        agents     : list of Agent objects
        generators : Lie algebra basis
        params     : dict with simulation params (must include 'overlap_eps')
        i, j       : agent indices
        mode       : "belief" or "model"
        outdir     : output root directory
    """
    import matplotlib.pyplot as plt
    import numpy as np
    from pathlib import Path

    # Select appropriate KL function
    if mode == "belief":
        fn = compute_pairwise_kl
        subdir = "belief_pointwise"
    elif mode == "model":
        fn = compute_pairwise_model_kl
        subdir = "model_pointwise"
    else:
        raise ValueError(f"Invalid mode: {mode}. Must be 'belief' or 'model'.")

    kl_mat, pw_dict = fn(agents, generators, params, return_pointwise=True)

    # Fallback if requested pair has no overlap
    if (i, j) not in pw_dict:
        if len(pw_dict) == 0:
            raise RuntimeError("No overlapping agent pairs found for pointwise KL.")
        alt = next(iter(pw_dict))
        print(f"[WARN] No overlap for ({i}, {j}); using fallback pair {alt}")
        i, j = alt
        pw = pw_dict[alt]
    else:
        pw = pw_dict[(i, j)]

    # Reconstruct full spatial heatmap
    mask_i = agents[i].mask > params["overlap_eps"]
    mask_j = agents[j].mask > params["overlap_eps"]
    overlap_flat = (mask_i & mask_j).reshape(-1)
    inds = np.flatnonzero(overlap_flat)

    heat = np.zeros_like(mask_i, dtype=float).reshape(-1)
    heat[inds] = pw
    heat = heat.reshape(mask_i.shape)

    # Plot heatmap
    fig, ax = plt.subplots(figsize=(5, 5))
    im = ax.imshow(heat, origin='lower', cmap='magma')
    fig.colorbar(im, ax=ax, label=f"Pointwise D_KL ({mode})")
    ax.set_title(f"{mode.capitalize()} Pointwise KL: agents {i} ↔ {j}")
    ax.axis('off')

    # Save
    outpath = Path(outdir) / subdir
    outpath.mkdir(parents=True, exist_ok=True)
    fpath = outpath / f"pointwise_{mode}_{i}_{j}.png"
    fig.savefig(fpath, dpi=150)
    plt.close(fig)


if __name__ == "__main__":
    from pathlib import Path
    from config import checkpoint_dir, group_name, K, log_eps, overlap_eps
    import config

    # Load final agent state
    agents = load_final_step(checkpoint_dir)
    if agents is None:
        raise FileNotFoundError(f"No step_XXXX.pkl found in {checkpoint_dir}/")

    generators = get_generators(group_name, K)
    params = {
        "log_eps":     log_eps,
        "overlap_eps": overlap_eps
    }

    BASEDIR = Path("meta_agent_analysis")
    BASEDIR.mkdir(exist_ok=True)

    # --- [1] Run belief/model alignment diagnostics
    for mode in ["belief", "model"]:
        outdir = BASEDIR / f"{mode}_alignment_output"
        outdir.mkdir(exist_ok=True, parents=True)
        print(f"[INFO] Running alignment analysis for mode: {mode}")
        run_generic_alignment_analysis(agents, generators, params, mode, outdir=outdir)

    print("[✓] Alignment analyses complete.\n")

    # --- [2] Meta-agent condensation diagnostics
    for prefix, subfolder in [
        ("kl",       "belief_alignment_output"),
        ("kl_model", "model_alignment_output")
    ]:
        align_dir = BASEDIR / subfolder
        print(f"[INFO] Processing '{prefix}' clusters from '{align_dir}'")

        kl_matrix, labels, rankings = load_meta_data(str(align_dir), prefix)
        stats = compute_cluster_kl_stats(kl_matrix, labels)
        R_global, σ_global = compute_order_parameter(kl_matrix)

        if not stats:
            print(f"[!] No clusters detected for {prefix}; skipping.")
            continue

        outdir = BASEDIR / "condensation_output" / prefix
        outdir.mkdir(exist_ok=True, parents=True)

        # Main condensation plots
        plot_intra_kl_distribution(stats, outpath=outdir / "intra_kl.png")
        plot_inter_vs_intra(stats, outpath=outdir / "inter_vs_intra.png")

        cluster_R = compute_cluster_order_parameters(kl_matrix, labels)
        plot_cluster_order_parameters(cluster_R, outpath=outdir / "cluster_order_params.png")
        plot_spatial_cluster_map(agents, labels, outpath=outdir / "spatial_clusters.png")
        plot_curvature_heatmap(agents, labels, generators, outpath=outdir / "curvature_heatmap.png")

    print("[✓] Meta-agent condensation diagnostics complete.")













