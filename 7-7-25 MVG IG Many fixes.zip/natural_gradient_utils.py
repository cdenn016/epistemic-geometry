# -*- coding: utf-8 -*-
"""
Created on Sun Jul  6 14:42:59 2025

@author: chris and christine
"""
import numpy as np
from numpy.linalg import inv
import config


def log_lie_group_matrix(group_matrix_flat: np.ndarray) -> np.ndarray:
    """
    Safer logm wrapper that handles near-degenerate matrices and removes imaginary drift.
    """
    from scipy.linalg import logm
    B = group_matrix_flat.shape[0]
    d = group_matrix_flat.shape[-1]
    logm_matrices = np.zeros((B, d, d), dtype=np.float32)
    
    for i in range(B):
        try:
            logm_result = logm(group_matrix_flat[i])
            logm_real = np.real_if_close(logm_result, tol=1e5)
            logm_matrices[i] = np.clip(logm_real, -1e2, 1e2)
        except Exception as e:
            logm_matrices[i] = np.zeros((d, d))  # fallback
    return logm_matrices


def compute_fisher_metric_block_diag(sigma: np.ndarray):
    """
    Compute block-diagonal approximation to the Fisher metric for MVN(μ, Σ)

    Fisher block structure:
    [ Σ⁻¹               0         ]
    [   0   (1/2) Σ⁻¹ ⊗ Σ⁻¹       ]

    Args:
        sigma: (K, K) positive-definite covariance matrix

    Returns:
        fisher_mu_inv: (K, K)
        fisher_sigma_inv: (K, K, K, K) tensor for Σ part
    """
    K = sigma.shape[0]
    sigma_sanitized = sanitize_sigma(sigma, eps=1e-6, debug=config.debug_sanitize_sigma)
    sigma_inv = np.linalg.inv(sigma_sanitized)


    fisher_mu = sigma_inv
    fisher_sigma = 0.5 * np.einsum('ij,kl->ijkl', sigma_inv, sigma_inv)

    return fisher_mu, fisher_sigma


def apply_natural_gradient_batch(mu_field, sigma_field, grad_mu_field, grad_sigma_field):
    """
    Apply Fisher-preconditioned natural gradient updates for MVGs over full fields or batches.

    Accepts either:
    - Full field shape: (H, W, K)
    - Batch shape: (N, K)

    Returns:
        delta_mu_field:    (same shape as mu_field)
        delta_sigma_field: (same shape as sigma_field)
    """
    shape = mu_field.shape
    if len(shape) == 3:
        H, W, K = shape
        is_field = True
        mu_flat = mu_field.reshape(-1, K)
        sigma_flat = sigma_field.reshape(-1, K, K)
        grad_mu_flat = grad_mu_field.reshape(-1, K)
        grad_sigma_flat = grad_sigma_field.reshape(-1, K, K)
    elif len(shape) == 2:
        N, K = shape
        is_field = False
        mu_flat = mu_field
        sigma_flat = sigma_field
        grad_mu_flat = grad_mu_field
        grad_sigma_flat = grad_sigma_field
    else:
        raise ValueError(f"Unsupported shape {shape} for mu_field")

    delta_mu = np.zeros_like(mu_flat)
    delta_sigma = np.zeros_like(sigma_flat)

    for i in range(mu_flat.shape[0]):
        g_mu, g_sigma = compute_fisher_metric_block_diag(sigma_flat[i])
        delta_mu[i] = - g_mu @ grad_mu_flat[i]

        if g_sigma.ndim == 4:
            delta_sigma[i] = - np.einsum("ijkl,kl->ij", g_sigma, grad_sigma_flat[i])
        elif g_sigma.ndim == 2:
            grad_vec = grad_sigma_flat[i].reshape(-1)
            delta_vec = - g_sigma @ grad_vec
            delta_sigma[i] = delta_vec.reshape(sigma_flat[i].shape)
        else:
            raise ValueError(f"Unexpected g_sigma shape: {g_sigma.shape}")

    if is_field:
        return delta_mu.reshape(H, W, K), delta_sigma.reshape(H, W, K, K)
    else:
        return delta_mu, delta_sigma



def compute_lie_metric(generators: np.ndarray):
    """
    Compute inner product matrix G_{ab} = Tr(G_a^T G_b) and its inverse.

    Args:
        generators: (d, K, K) basis of Lie algebra

    Returns:
        G: (d, d) metric matrix
        G_inv: (d, d) inverse metric
    """
    d, K, _ = generators.shape
    G = np.zeros((d, d))
    for a in range(d):
        for b in range(d):
            G[a, b] = np.trace(generators[a].T @ generators[b])
    G_inv = np.linalg.inv(G + np.eye(d) * 1e-8)  # Regularized inverse
    return G, G_inv


# Add this to natural_gradient_utils.py

def apply_lie_natural_gradient(phi, grad_phi, G_inv=None):
    """
    Apply Lie-natural gradient update to φ using optional inverse Fisher metric.

    Args:
        phi      : (H, W, d) or None — current φ field (not used unless needed for adaptive G)
        grad_phi : (H, W, d)         — raw gradient
        G_inv    : (d, d) or None    — optional inverse Fisher metric (constant)

    Returns:
        nat_grad : (H, W, d) natural gradient update
    """
    if G_inv is None:
        return grad_phi  # Euclidean fallback

    # Apply the inverse metric globally — assume grad_phi already masked
    return np.einsum("ab,...b->...a", G_inv, grad_phi)

def riemannian_phi_update(
    phi: np.ndarray,
    grad: np.ndarray,
    eta: float,
    generators: np.ndarray,
    G_inv: np.ndarray = None
) -> np.ndarray:
    """
    Apply a Riemannian natural gradient update to φ using the Lie algebra geometry.

    Args:
        phi:    (..., d) Lie algebra field
        grad:   (..., d) Euclidean gradient of energy wrt φ
        eta:    float step size
        generators: (d, K, K) Lie algebra generators (unused here but reserved)
        G_inv:  Optional inverse Fisher tensor (..., d, d)

    Returns:
        φ_new:  (..., d) updated Lie algebra field
    """
    # Compute Lie-aware natural gradient step
    delta_phi = apply_lie_natural_gradient(phi, grad, G_inv=G_inv)

    return phi - eta * delta_phi



def phi_to_matrix(phi_vec, Gs):
    """
    Convert Lie algebra vector φ (shape (..., d)) to matrix form (..., K, K)
    using generators Gs (shape (d, K, K)).
    """
    return np.einsum("...a,akl->...kl", phi_vec, Gs)


def matrix_to_vector(phi_matrix, Gs):
    """
    Convert a Lie algebra matrix (..., K, K) back to a vector (..., d)
    using the trace inner product with the generators.

    Assumes inner product Tr[Gaᵀ · φ_matrix], consistent with metric G_ab = Tr[Gaᵀ Gb].
    """
    d = Gs.shape[0]
    vec = np.zeros(phi_matrix.shape[:-2] + (d,))
    for a in range(d):
        Ga_T = Gs[a].T  # ensure consistency with compute_lie_metric
        vec[..., a] = np.einsum("...ij,ij->...", phi_matrix, Ga_T)
    return vec


import numpy as np

def sanitize_sigma(Sigma, eps=1e-6, debug=False):
    """
    Sanitize a batch of covariance matrices to ensure SPD.

    Parameters:
        Sigma: (..., K, K) ndarray — batch of covariances
        eps: minimum eigenvalue threshold
        debug: if True, prints a single summary message per call

    Returns:
        Sanitized SPD matrices with same shape as input.
    """
    shape = Sigma.shape
    flat_sigma = Sigma.reshape(-1, shape[-2], shape[-1])
    n_total = flat_sigma.shape[0]

    Sigma_out = np.empty_like(flat_sigma)
    clipped = 0

    for i in range(n_total):
        S = flat_sigma[i]
        S = 0.5 * (S + S.T)  # Ensure symmetry
        eigvals, eigvecs = np.linalg.eigh(S)

        if np.any(eigvals < eps):
            eigvals = np.clip(eigvals, eps, None)
            S = eigvecs @ np.diag(eigvals) @ eigvecs.T
            clipped += 1

        Sigma_out[i] = 0.5 * (S + S.T)  # Re-symmetrize after projection

    if debug and clipped > 0:
        print(f"[SPD sanitize] Clipped {clipped} / {n_total} matrices to ε={eps:.1e}")

    return Sigma_out.reshape(shape)


import numpy as np

def transport_covariance_cholesky(Sigma_batch, Omega_batch):
    """
    Transport covariances via Cholesky root transport:
        Σ → ΩL · (ΩL)ᵀ  where Σ = LLᵀ

    Parameters:
        Sigma_batch: (N, K, K) — batch of SPD matrices
        Omega_batch: (N, K, K) — transport operators

    Returns:
        Sigma_transported: (N, K, K) — transported SPD matrices
    """
    N, K, _ = Sigma_batch.shape
    Sigma_out = np.empty_like(Sigma_batch)

    for i in range(N):
        try:
            L = np.linalg.cholesky(Sigma_batch[i])
            L_t = Omega_batch[i] @ L
            Sigma_out[i] = L_t @ L_t.T
        except np.linalg.LinAlgError:
            # Fall back to identity if Cholesky fails
            Sigma_out[i] = np.eye(K)

    return Sigma_out






