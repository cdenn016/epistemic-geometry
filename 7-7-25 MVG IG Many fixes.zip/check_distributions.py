# -*- coding: utf-8 -*-
"""
Created on Mon Jul  7 15:14:11 2025

@author: chris and christine
"""

import numpy as np
from pathlib import Path
import re

THRESHOLD_STD = 1e-4  # anything flatter than this is considered "uniform"
FIELD_DIR = Path("checkpoints/field_dumps")

def extract_step(fname):
    match = re.search(r"step(\d+)", fname.name)
    return int(match.group(1)) if match else -1

def check_variation(field, name, threshold=THRESHOLD_STD):
    std = np.std(field, axis=(0, 1)) if field.ndim >= 3 else np.std(field)
    is_flat = np.all(std < threshold)
    return std, is_flat

def validate_fields(npz_path):
    data = np.load(npz_path)

    mu_q     = data["mu_q"]
    sigma_q  = data["sigma_q"]
    mu_p     = data["mu_p"]
    sigma_p  = data["sigma_p"]

    result = {"step": extract_step(npz_path)}

    for name, field in [("mu_q", mu_q), ("sigma_q", sigma_q),
                        ("mu_p", mu_p), ("sigma_p", sigma_p)]:
        std, is_flat = check_variation(field, name)
        result[name + "_std"] = std
        result[name + "_is_flat"] = is_flat

    return result

def main():
    files = sorted(FIELD_DIR.glob("step*.npz"))
    print(f"[INFO] Found {len(files)} field dumps.\n")
    flagged = []

    for f in files:
        result = validate_fields(f)
        step = result["step"]
        print(f"Step {step:04d}:")

        for key in ["mu_q", "sigma_q", "mu_p", "sigma_p"]:
            std = result[f"{key}_std"]
            flat = result[f"{key}_is_flat"]
            flag = "⚠️" if flat else ""
            if isinstance(std, np.ndarray):
                std_str = f"[mean std={np.mean(std):.2e}]"
            else:
                std_str = f"[std={std:.2e}]"
            print(f"  {key:8s}: {std_str:20s} {flag}")
        
        if any(result[k + "_is_flat"] for k in ["mu_q", "mu_p"]):
            flagged.append(step)

    if flagged:
        print(f"\n⚠️ Likely uniform distributions detected at steps: {flagged}")
    else:
        print("\n✅ No obviously uniform distributions detected.")

if __name__ == "__main__":
    main()
