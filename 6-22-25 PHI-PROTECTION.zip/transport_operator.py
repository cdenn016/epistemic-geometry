# Standard library
import numpy as np

# Third-party
import config
from scipy.ndimage  import gaussian_filter

# Local utilities
from find_agent_chains      import construct_spatial_path_nd
from generalized_math_utils import kl_divergence
from generalized_omega      import (
    exp_lie_algebra_irrep,
    build_inter_agent_omega,
    )
from config import spatial_resolution

def compute_intra_agent_omega(phi, c0, c1, generators, linearize_threshold=1e-5):
    # Strictly non-abelian: Ω(c0→c1) = exp(φ(c0)) · exp(−φ(c1))
    phi0 = phi[c0]
    phi1 = phi[c1]
    # if very small difference, we can linearize (abelian approx)
    if np.linalg.norm(phi0 - phi1) < linearize_threshold:
        return exp_lie_algebra_irrep((phi0 - phi1)[None], generators)[0]
    # otherwise build full non-abelian transport
    G0    = exp_lie_algebra_irrep(phi0[None], generators)[0]
    G1_inv= exp_lie_algebra_irrep((-phi1)[None], generators)[0]
    return G0 @ G1_inv



def compute_inter_agent_omega_at_point(
    phi_i: np.ndarray,
    phi_j: np.ndarray,
    coord: tuple[int, ...],
    generators: np.ndarray,
) -> np.ndarray:
    """
    Non-Abelian transport Ω_{ij}(x) = exp(φ_i(x)) · exp(-φ_j(x))
    at a single spatial index `coord`.
    """
    phi_i_vec = phi_i[coord]
    phi_j_vec = phi_j[coord]

    G_i     = exp_lie_algebra_irrep(phi_i_vec[None], generators)[0]
    G_j_inv = exp_lie_algebra_irrep(-phi_j_vec[None], generators)[0]
    return G_i @ G_j_inv


def compute_inter_agent_omega(
    phi_i: np.ndarray,
    phi_j: np.ndarray,
    coord: tuple[int, ...],
    generators: np.ndarray,
    use_commutator: bool = False
) -> np.ndarray:
    """
    Compute Ω_{ij}(coord) = exp(φ_i(coord)) · exp(-φ_j(coord))
    (non-abelian transport), or the abelian shortcut if
    use_commutator=True.
    """
    # 1) Extract the Lie-algebra vectors at coord
    φi_vec = phi_i[coord]  # shape (d,)
    φj_vec = phi_j[coord]  # shape (d,)

    # 2) Delegate to central helper
    #    build_inter_agent_omega handles both abelian and non-abelian
    Ω = build_inter_agent_omega(
        φi_vec[None],       # convert to shape (1, d)
        φj_vec[None],       # same here
        generators,
        config=config,
        use_commutator=use_commutator
    )  # returns array shape (1, K, K)

    return Ω[0]  # return single operator of shape (K, K)


def transport_belief_spatially(
    phi_field: np.ndarray,
    c0: tuple[int, ...],
    c1: tuple[int, ...],
    generators: np.ndarray,
    use_commutator: bool = False
) -> np.ndarray:
    """
    Compute intra-agent spatial transport operator T_{c0→c1}
    using non-Abelian φ field:

        Ω = exp(φ(c0)) · exp(−φ(c1))

    Args:
        phi_field: φ tensor of shape (..., d)
        c0, c1: spatial indices (tuples)
        generators: array (d, K, K) of Lie algebra generators
        use_commutator: if True, apply a first-order BCH correction

    Returns:
        Omega (K×K) transporting from c0 to c1
    """
    # 1) Extract the two field values
    phi0 = phi_field[c0]  # shape (d,)
    phi1 = phi_field[c1]  # shape (d,)

    # 2) Non‐abelian transport: exp(φ0) · exp(−φ1)
    G0 = exp_lie_algebra_irrep(phi0[None], generators)[0]
    G1 = exp_lie_algebra_irrep((-phi1)[None], generators)[0]
    Omega = G0 @ G1

    # 3) Optional first‐order BCH correction (small‐delta commutator)
    #if use_commutator:
        # Δ = φ0 - φ1, approximate M = ½[φ0, φ1]
        # actual implementation would build M via the Lie commutator on generators
        # placeholder here if you want to refine later
        #delta = phi0 - phi1
        # M = 0.5 * (ad_phi0 @ ad_phi1 - ad_phi1 @ ad_phi0)  # sketch
        # Omega = Omega @ expm(M)  # full BCH would be exp(Δ + M + …)
        #pass

    return Omega


def transport_belief_over_chain(
    agents,
    path: list[int],
    overlap_points: list[tuple[int,...]],
    generators: np.ndarray,
    domain_size: tuple[int,...],
    fiber_key: str = 'q',      # or 'p'
    phi_key:   str = 'phi',    # or 'phi_model'
    fixed_start: tuple[int,...] | None = None,
    fixed_end:   tuple[int,...] | None = None,
    injection_mode: str = "from_q",
):
    """
    As before, but:
    - Uses getattr(..., phi_key) instead of hard-coded .phi
    - Imports are at module top
    - Uses module config for smoothing sigmas
    """
    D = len(domain_size)
    K = getattr(agents[0], fiber_key).shape[-1]
    A = agents[path[0]]
    B = agents[path[-1]]

    c_0 = fixed_start or tuple(np.array(domain_size) // 2)

    # --- Injection setup ---
    if injection_mode == "from_q":
        f = getattr(A, fiber_key)[c_0].copy()
    elif injection_mode == "from_p":
        f = getattr(A, 'p')[c_0].copy()
    elif injection_mode == "gaussian":
        x = np.arange(K)
        center, sigma = K//2, K/10
        f = np.exp(-0.5*((x-center)/sigma)**2)
    elif injection_mode == "delta":
        f = np.zeros(K); f[K//2] = 1.0
    else:
        raise ValueError(f"Unknown injection_mode: {injection_mode}")

    # normalize helper
    def _norm(v):
        v = np.clip(v, 1e-8, 1.0)
        return v / v.sum()

    f = _norm(f)

    full_path_coords = []
    kl_path_fine     = []
    kl_path_coarse   = []
    q_sequence       = [f.copy()]

    for k in range(len(path)-1):
        id_a, id_b = path[k], path[k+1]
        agent_a, agent_b = agents[id_a], agents[id_b]

        c_a  = c_0 if k==0 else overlap_points[k-1]
        c_ab = overlap_points[k]

        # --- Intra-agent transport ---
        seg = construct_spatial_path_nd(c_a, c_ab, domain_size, mask=agent_a.mask)
        for p0, p1 in zip(seg[:-1], seg[1:]):
            phi_a = getattr(agent_a, phi_key)
            omega = compute_intra_agent_omega(phi_a, p0, p1, generators, use_commutator=False)
            f     = _norm(omega @ f)
            target = getattr(agent_a, fiber_key)[p1]
            kl_path_fine.append(kl_divergence(f, target))
            q_sequence.append(f.copy())

        # record segment coords
        full_path_coords.extend(seg)

        # --- Inter-agent jump ---
        phi_a, phi_b = getattr(agent_a, phi_key), getattr(agent_b, phi_key)
        omega_ab = compute_inter_agent_omega(phi_a, phi_b, c_ab, generators, use_commutator=False)
        f        = _norm(omega_ab @ f)
        target   = getattr(agent_b, fiber_key)[c_ab]
        kl_path_coarse.append(kl_divergence(f, target))
        q_sequence.append(f.copy())

        # record the jump coord
        full_path_coords.append(c_ab)
        c_0 = c_ab

    # --- Gauge-covariant injection ---
    c_final = fixed_end or c_0
    delta   = np.zeros(domain_size); delta[c_final]=1.0
    smoothed= gaussian_filter(delta, sigma=config.injection_smooth_sigma)
    mask    = smoothed > 1e-5

    phi_B = getattr(B, phi_key)
    for idx in zip(*np.where(mask)):
        omega = compute_intra_agent_omega(phi_B, c_final, idx, generators, use_commutator=False)
        transported = _norm(omega @ f)
        getattr(B, fiber_key)[idx] += transported * smoothed[idx]

    # update B.mask
    B_mask = gaussian_filter(delta, sigma=config.mask_update_sigma)
    B.mask  = np.maximum(B.mask, B_mask)

    # final normalize
    field = getattr(B, fiber_key)
    field = np.clip(field, 1e-8, 1.0)
    field = field / (np.sum(field, axis=-1, keepdims=True) + 1e-8)
    setattr(B, fiber_key, field)

    return agents, {
        "kl_path_coarse": kl_path_coarse,
        "kl_path_fine":   kl_path_fine,
        "final_point":    c_final,
        "path_indices":   path,
        "path_coords":    full_path_coords,
        "q_sequence":     q_sequence,
        "q_initial":      q_sequence[0],
        "q_final":        q_sequence[-1],
    }


def compute_total_path_length(path_coords, dx=spatial_resolution):
    if len(path_coords) < 2:
        return 0.0
    deltas    = np.diff(np.array(path_coords), axis=0)
    distances = np.linalg.norm(deltas, axis=1)
    return dx * distances.sum()

def log_transport_summary(info_dict, config=None):
    coords = info_dict.get("path_coords", [])
    dx = getattr(config, "spatial_resolution", spatial_resolution)
    length = compute_total_path_length(coords, dx=dx)
    steps  = len(coords) - 1 if len(coords) >= 2 else 0
    print(f"[TRANSPORT] Steps: {steps}, Δx: {dx}, Total length: {length:.2f}")
