# holonomy_master_csv.py

import os
import glob
import pickle
import pandas as pd
import numpy as np

MASTER_CSV = "holonomy_experiments/master_summary.csv"
RUNS_ROOT = "holonomy_runs"


def load_master_summary(path):
    df = pd.read_csv(path)
    if "param" not in df.columns:
        df["param"] = np.nan
    df["experiment"] = df["experiment"].str.strip()
    df["param"] = df["param"].astype(str)
    return df


def summarize_diagnostics(diag):
    summary = {
        "step": diag.get("step", np.nan),
        "label": diag.get("label", None),
        "radius": diag.get("radius", None),
        "experiment": "agent_cycle" if "cycle" in diag else "spatial",

    }

    H = diag.get("holonomy")
    if H is not None:
        summary.update({
            "trace": np.trace(H),
            "det_minus1": np.linalg.det(H) - 1.0,
            "cond": np.linalg.cond(H),
            "deviation_norm": np.linalg.norm(H - np.eye(H.shape[0])),
        })

    F = diag.get("logH")
    if isinstance(F, np.ndarray):
        summary["curvature_norm"] = np.linalg.norm(F)

    if "curvature_norm" in diag:
        summary["curvature_norm"] = diag["curvature_norm"]

    devs = diag.get("deviations")
    if isinstance(devs, (list, np.ndarray)) and len(devs) > 0:
        devs = np.array(devs)
        summary.update({
            "dev_min": np.min(devs),
            "dev_max": np.max(devs),
            "dev_mean": np.mean(devs),
            "dev_std": np.std(devs),
        })

    summary["belief_seq_len"] = len(diag.get("belief_seq", []))
    summary["transport_path_len"] = len(diag.get("transport_path", []))
    summary["cycle_len"] = len(diag.get("cycle", [])) if "cycle" in diag else np.nan

    return summary


def load_all_diagnostics(runs_root):
    records = []
    for exp in ("spatial", "agent"):
        folder = os.path.join(runs_root, exp)
        pattern = os.path.join(folder, "**", "diagnostics.pkl")
        for pkl_path in glob.glob(pattern, recursive=True):
            with open(pkl_path, "rb") as f:
                diag = pickle.load(f)
            rec = summarize_diagnostics(diag)
            rec["run_id"] = os.path.basename(os.path.dirname(pkl_path))
            records.append(rec)
    return pd.DataFrame(records)


def main():
    master = load_master_summary(MASTER_CSV)
    raw = load_all_diagnostics(RUNS_ROOT)

    # Key harmonization
    raw["label"] = raw["label"].astype(str)
    master["param_key"] = master.apply(
        lambda r: r["radius"] if r["experiment"] == "spatial" else r["param"], axis=1)
    raw["param_key"] = raw.apply(
        lambda r: r["radius"] if r["experiment"] == "spatial" else r["label"], axis=1)

    # Merge and cleanup
    merged = pd.merge(master, raw,
                      how="left",
                      on=["experiment", "step", "param_key"],
                      suffixes=("", "_drop"))
    merged.drop([col for col in merged.columns if col.endswith("_drop")], axis=1, inplace=True)

    # Final fallback for curvature_norm
    if "curvature_norm" not in merged.columns:
        if "curvature_norm_master" in merged.columns:
            merged["curvature_norm"] = merged["curvature_norm_master"]
        elif "deviation_norm" in merged.columns:
            merged["curvature_norm"] = merged["deviation_norm"]
        else:
            merged["curvature_norm"] = np.nan

    # Export cleaned version
    os.makedirs("holonomy_experiments", exist_ok=True)
    merged.to_csv("holonomy_experiments/merged_full_summary.csv", index=False)
    print("[✓] Wrote holonomy_experiments/merged_full_summary.csv")

    # Optional: diagnostic preview
    agent = merged[merged["experiment"] == "agent"]
    if not agent.empty:
        pivot = agent.pivot_table(
            index="cycle_len", columns="step", values="curvature_norm", aggfunc="mean")
        print("Pivot table (cycle_len x step):")
        print(pivot.head())


if __name__ == "__main__":
    main()
