# plot_omega_deviations_holonomy.py

import numpy as np
import matplotlib.pyplot as plt
import os
import pickle

def plot_omega_deviations(deviations, title="‖Ω − I‖ Along Loop", out_path=None):
    plt.figure(figsize=(6, 3))
    plt.plot(deviations, marker='o')
    plt.xlabel("Step in Loop")
    plt.ylabel("‖Ω − I‖")
    plt.title(title)
    plt.tight_layout()
    if out_path:
        plt.savefig(out_path)
    else:
        plt.show()

if __name__ == "__main__":
    base_dir = "holonomy_runs/spatial"
    candidates = []

    for root, dirs, files in os.walk(base_dir):
        if "diagnostics.pkl" in files:
            rel_path = os.path.relpath(os.path.join(root, "diagnostics.pkl"), base_dir)
            candidates.append(rel_path)

    if not candidates:
        raise FileNotFoundError("No diagnostics.pkl files found in holonomy_runs/spatial")

    print("Available holonomy diagnostics:")
    for i, fname in enumerate(candidates):
        print(f"  [{i}] {fname}")

    choice = int(input("\nSelect file index to load: ").strip())
    chosen_path = os.path.join(base_dir, candidates[choice])
    print(f"[INFO] Loading diagnostics from: {chosen_path}")

    with open(chosen_path, "rb") as f:
        diag = pickle.load(f)

    H = diag["holonomy"]
    deviations = diag.get("deviations", None)

    print("\n[SUMMARY]")
    print(f"‖H − I‖: {np.linalg.norm(H - np.eye(H.shape[0])):.4f}")
    print(f"Trace: {np.trace(H):.4f}")
    print(f"Det − 1: {np.linalg.det(H) - 1:.4e}")
    print(f"Condition #: {np.linalg.cond(H):.2f}")

    if deviations is not None:
        print(f"Stepwise ‖Ω − I‖: mean={np.mean(deviations):.4f}, max={np.max(deviations):.4f}")
        plot_omega_deviations(deviations)
    else:
        print("[NOTE] No deviations stored in diagnostics — only showing summary of H.")
