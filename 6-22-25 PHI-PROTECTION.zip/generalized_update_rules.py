import numpy as np
import config
from joblib import Parallel, delayed
from generalized_math_utils import sanitize_q
from generalized_omega import exp_lie_algebra_irrep
from generalized_update_terms import (
    compute_beliefs_gradient,
    compute_models_gradient,
    compute_phi_alignment_gradient,
    compute_phi_model_update,
)

def _compute_all_grads(i, agents, params):
    ai = agents[i]
    return (
        compute_beliefs_gradient(ai, agents, params),
        compute_models_gradient(ai, agents, params),
        compute_phi_alignment_gradient(ai, agents, params),
        compute_phi_model_update(ai, agents, params),
    )



def synchronous_step(agents, generators, params=None, n_jobs=1):
    """
    Perform one synchronous Euler update with φ and φ_model gradient/step clipping.

    Args:
        agents: list of Agent
        generators: Lie-algebra generators from get_generators(...)
        params: override parameters dict
        n_jobs: for joblib parallel
    """
    params = params or {}
    N = len(agents)

    # 0) Clear caches & precompute exp(phi) and exp(-phi)
    for A in agents:
        A.clear_omega_cache()
        flat_phi       = A.phi.reshape(-1, A.phi.shape[-1])
        flat_phi_model = A.phi_model.reshape(-1, A.phi_model.shape[-1])
        A._exp_phi           = exp_lie_algebra_irrep(flat_phi,       generators)
        A._exp_neg_phi       = exp_lie_algebra_irrep(-flat_phi,      generators)
        A._exp_phi_model     = exp_lie_algebra_irrep(flat_phi_model, generators)
        A._exp_neg_phi_model = exp_lie_algebra_irrep(-flat_phi_model, generators)

    # 1) Snapshot old fields
    q_old     = [agent.q.copy()         for agent in agents]
    p_old     = [agent.p.copy()         for agent in agents]
    phi_old   = [agent.phi.copy()       for agent in agents]
    phi_m_old = [agent.phi_model.copy() for agent in agents]
    mask_list = [agent.mask            for agent in agents]

    # 2) Compute all gradients in parallel
    q_grads, p_grads, phi_grads, phi_m_grads = zip(*Parallel(
        n_jobs=n_jobs, backend="threading"
    )(delayed(_compute_all_grads)(i, agents, params) for i in range(N)))

    # 3) Load step sizes and thresholds
    eta_q         = params.get('eta_q',         config.eta_q)
    eta_p         = params.get('eta_p',         config.eta_p)
    eta_phi       = params.get('eta_phi',       config.eta_phi)
    eta_model_phi = params.get('eta_model_phi', config.eta_model_phi)

    grad_clip        = config.gradient_clip
    dphi_clip        = config.phi_clip_threshold
    phi_max          = config.phi_max_norm
    blowup_threshold = config.blowup_threshold
    eps              = config.eps

    # 4) Apply updates synchronously
    for i, agent in enumerate(agents):
        mask = mask_list[i][..., None]

        # --- q update
        dq = -eta_q * q_grads[i]
        q_new = np.where(mask, q_old[i] + dq, q_old[i])
        agent.q = sanitize_q(q_new, eps=config.log_eps)

        # --- p update
        dp = -eta_p * p_grads[i]
        p_new = np.where(mask, p_old[i] + dp, p_old[i])
        agent.p = sanitize_q(p_new, eps=config.log_eps)

        # --- φ update (with clipping)
        gphi = phi_grads[i]
        gphi_norm = np.linalg.norm(gphi)
        if gphi_norm > grad_clip:
            gphi *= grad_clip / (gphi_norm + eps)

        dphi = eta_phi * gphi
        dphi_norm = np.linalg.norm(dphi)
        if dphi_norm > blowup_threshold:
            print(f"[SKIP] φ update agent {i}: ‖Δφ‖={dphi_norm:.1e} > {blowup_threshold}")
            continue
        if dphi_norm > dphi_clip:
            dphi *= dphi_clip / (dphi_norm + eps)

        agent.phi = phi_old[i] + dphi * mask
        phi_new_norm = np.linalg.norm(agent.phi)
        if phi_new_norm > phi_max:
            agent.phi *= phi_max / (phi_new_norm + eps)
        agent.delta_phi = dphi

        # --- φ_model update (same protection as φ)
        gphi_m = phi_m_grads[i]
        gphi_m_norm = np.linalg.norm(gphi_m)
        if gphi_m_norm > grad_clip:
            gphi_m *= grad_clip / (gphi_m_norm + eps)

        dphi_m = eta_model_phi * gphi_m
        dphi_m_norm = np.linalg.norm(dphi_m)
        if dphi_m_norm > blowup_threshold:
            print(f"[SKIP] φ_model update agent {i}: ‖Δφ̃‖={dphi_m_norm:.1e} > {blowup_threshold}")
            continue
        if dphi_m_norm > dphi_clip:
            dphi_m *= dphi_clip / (dphi_m_norm + eps)

        agent.phi_model = phi_m_old[i] + dphi_m * mask
        phi_model_new_norm = np.linalg.norm(agent.phi_model)
        if phi_model_new_norm > phi_max:
            agent.phi_model *= phi_max / (phi_model_new_norm + eps)
        agent.delta_phi_model = dphi_m

    return agents

def update_all(agents, generators, params=None, n_jobs=1):
    """
    Alias for synchronous_step with explicit generators argument.
    """
    return synchronous_step(agents, generators, params, n_jobs)