

def plot_spatial_summary(master_csv, out_dir='holonomy_plots/spatial'):
    import os
    import pandas as pd
    import matplotlib.pyplot as plt

    df = pd.read_csv(master_csv)
    os.makedirs(out_dir, exist_ok=True)

    metrics = ['curvature_norm', 'det_minus1', 'trace',
               'cond', 'chordal', 'loop_length']

    # Select just the spatial experiments
    df_spatial = df[df['experiment'] == 'spatial']

    def extract_loop_size(param_str):
        try:
            nums = [int(x) for x in param_str.strip('[]').split('-')]
            return abs(nums[1] - nums[0]) + 1
        except:
            return None

    df_spatial['loop_size'] = df_spatial['param'].apply(extract_loop_size)
    df_spatial = df_spatial.dropna(subset=['loop_size'])

    for metric in metrics:
        avg = df_spatial.groupby('loop_size')[metric].mean()

        plt.figure(figsize=(8, 5))
        plt.plot(avg.index, avg.values, marker='o')
        plt.xlabel('Spatial loop size')
        plt.ylabel(metric)
        plt.title(f'Spatial: average {metric} vs. loop size')
        plt.xticks(avg.index, rotation=45, ha='right')
        plt.tight_layout()

        out_file = os.path.join(out_dir, f'spatial_{metric}_vs_size.png')
        plt.savefig(out_file)
        plt.close()



def plot_agent_cycle_summary(master_csv, out_dir='holonomy_plots/agent_cycle'):
    import os
    import pandas as pd
    import matplotlib.pyplot as plt

    df = pd.read_csv(master_csv)
    os.makedirs(out_dir, exist_ok=True)

    metrics = ['curvature_norm', 'det_minus1', 'trace',
               'cond', 'chordal', 'loop_length']

    # select just the agent_cycle experiments
    df_cycle = df[df['experiment'] == 'agent_cycle']

    for metric in metrics:
        # average over each distinct cycle label
        avg = df_cycle.groupby('param')[metric].mean()

        plt.figure(figsize=(8,5))
        # use integer positions for categorical x
        x = range(len(avg))
        plt.plot(x, avg.values, marker='o')
        plt.xlabel('Agent-cycle (categorical)')
        plt.ylabel(metric)
        plt.title(f'Agent Cycle: average {metric} vs. cycle')
        plt.xticks(x, avg.index, rotation=45, ha='right')
        plt.tight_layout()

        out_file = os.path.join(out_dir, f'agent_cycle_{metric}_vs_cycle.png')
        plt.savefig(out_file)
        plt.close()

def plot_time_series_all(master_csv, out_dir='holonomy_timeseries'):
    import os, pandas as pd, matplotlib.pyplot as plt
    df = pd.read_csv(master_csv)
    os.makedirs(out_dir, exist_ok=True)
    metrics = [
        ('curvature_norm', 'Proxy ‖H−I‖'),
        ('det_minus1',    'det(H)−1'),
        ('trace',         'trace(H)'),
        ('cond',          'cond(H)'),
        ('chordal',       'Chordal dist'),
        ('loop_length',   'Loop length'),
    ]
    for exp in df['experiment'].unique():
        for param in df[df['experiment']==exp]['param'].unique():
            df_sub = df[(df['experiment']==exp)&(df['param'].astype(str)==str(param))].sort_values('step')
            plt.figure(figsize=(6,4))
            for key, label in metrics:
                if key in df_sub:
                    plt.plot(df_sub['step'], df_sub[key], label=label)
            plt.xlabel('Step')
            plt.ylabel('Value')
            plt.title(f'{exp} param={param}')
            plt.legend(loc='best', fontsize='small')
            plt.tight_layout()
            fname = f"{exp}_{param}_timeseries.png".replace(' ', '_')
            plt.savefig(os.path.join(out_dir, fname))
            plt.close()


if __name__ == '__main__':
    master_csv = 'holonomy_experiments/master_summary.csv'

    # plot spatial summaries
    plot_spatial_summary(master_csv)

    # plot inter-agent (cycle) summaries
    plot_agent_cycle_summary(master_csv)
    
    # 2) plot per‐step time series for each (experiment, param)
    plot_time_series_all(master_csv, out_dir='holonomy_timeseries')


   


