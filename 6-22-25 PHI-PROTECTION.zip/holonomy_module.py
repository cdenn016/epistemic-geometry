

import numpy as np

import random
from config import domain_size, support_cutoff_eps
from scipy.linalg import logm, expm, norm


import time

from find_agent_chains import construct_spatial_path_nd

from functools import lru_cache
from scipy.linalg import expm

# how many coords we cache before evicting
_CACHE_SIZE = 512

@lru_cache(maxsize=_CACHE_SIZE)


def _exp_lie(agent_id, coord):
    # look up the agent and the loop’s generators
    agent     = next(a for a in agents_global   if a.id == agent_id)
    gens      = generators_global
    # grab the phi‐vector for this agent at that coord
    phi_vec   = agent.phi[coord]   # shape (d,)
    # assemble the lie‐algebra element L = sum(phi_vec[μ] * gens[μ])
    L = sum(phi_vec[μ] * gens[μ] for μ in range(len(phi_vec)))
    return expm(L)



def intra_omega(agent, p0, p1):
    Ω0 = _exp_lie(agent.id, p0)
    Ω1 = _exp_lie(agent.id, p1)
    return Ω1 @ np.linalg.inv(Ω0)

def inter_omega(agent_i, agent_j, coord):
    Ωi = _exp_lie(agent_i.id, coord)
    Ωj = _exp_lie(agent_j.id, coord)
    return Ωi @ np.linalg.inv(Ωj)


def compute_spatial_loop_holonomy(
    agent,
    coords,
    generators,
    use_commutator=False,
    return_deviations=False,
    return_beliefs=False,
    return_path=False,
    initial_belief=None
):
    """
    Compute holonomy around a closed spatial loop within a single agent,
    multiplying successive intra-agent frame maps and re-orthonormalizing
    at each step to prevent overflow/NaNs. Optionally track deviations,
    belief propagation, and the actual path.

    Returns:
      H
      deviations (if return_deviations=True)
      beliefs   (if return_beliefs=True)
      path      (if return_path=True)
    """
    # expose for cache lookups
    global agents_global, generators_global
    agents_global = [agent]
    generators_global = generators

    if len(coords) < 2 or coords[0] != coords[-1]:
        raise ValueError("coords must start and end at the same point")

    K = generators.shape[-1]
    H = np.eye(K, dtype=float)
    deviations = []
    beliefs = []
    path_out = []

    # initialize belief tracking
    if return_beliefs:
        if initial_belief is None:
            raise ValueError("initial_belief must be provided when return_beliefs=True")
        b = initial_belief.copy()
        beliefs.append(b.copy())
    if return_path:
        path_out.append(coords[0])

    # iterate along the loop
    for p0, p1 in zip(coords[:-1], coords[1:]):
        ω = intra_omega(agent, tuple(p0), tuple(p1))
        H = ω @ H

        if return_deviations:
            deviations.append(np.linalg.norm(ω - np.eye(K)))

        if return_beliefs:
            b = ω @ b
            b = np.clip(b, 1e-12, None)
            b /= b.sum()
            beliefs.append(b.copy())
        if return_path:
            path_out.append(p1)

        # re-orthonormalize H
        U, _, Vt = np.linalg.svd(H, full_matrices=False)
        H = U @ Vt

    # optional logm check
    try:
        logH = logm(H)
        err = np.linalg.norm(expm(logH) - H)
        print(f"[Spatial: Holonomy logm error] ‖exp(logH)-H‖ = {err:.2e}")
    except:
        pass

    # assemble outputs
    outputs = [H]
    if return_deviations:
        outputs.append(deviations)
    if return_beliefs:
        outputs.append(beliefs)
    if return_path:
        outputs.append(path_out)

    # clear cache before exiting
    _exp_lie.cache_clear()

    return tuple(outputs) if len(outputs) > 1 else H



def compute_agent_cycle_holonomy(
    agents,
    agent_cycle,
    overlap_points,
    generators,
    initial_belief=None,
    return_deviations=False,
    return_logm=False,
    return_beliefs=False,
    return_path=False,
    use_commutator=False,
):
    """
    Compute non-Abelian holonomy around a closed loop of agents,
    optionally tracking belief propagation & returning the full spatial path.

    Returns:
      If return_beliefs & return_path:
        H, deviations, logH?, beliefs, path
      etc.
    """
    # Validate inputs
    
        # make our cache helpers see the agents
    global agents_global
    agents_global = agents
    
    global generators_global
    generators_global = generators

    
    if len(agent_cycle) < 2 or agent_cycle[0] != agent_cycle[-1]:
        raise ValueError("agent_cycle must start and end at the same agent")
    if len(overlap_points) != len(agent_cycle) - 1:
        raise ValueError("Mismatch between cycle and overlap points")

    K = generators.shape[-1]
    H = np.eye(K, dtype=float)
    deviations = []
    beliefs = []
    full_path = []

    # Initialize
    current_agent = agent_cycle[0]
    current_pos   = tuple(agents[current_agent].center)
    if return_beliefs:
        if initial_belief is None:
            raise ValueError("initial_belief must be provided when return_beliefs=True")
        b = initial_belief.copy()
        b = np.clip(b,1e-12,None)
        b = b / b.sum()
        beliefs.append(b.copy())
    if return_path:
        full_path.append(current_pos)

    # Loop each leg
    for next_agent, overlap_pt in zip(agent_cycle[1:], overlap_points):
        # spatial micro-steps
        path = construct_spatial_path_nd(current_pos, overlap_pt, domain_size,
                                        mask=agents[current_agent].mask)
        for p0, p1 in zip(path[:-1], path[1:]):
            ω = intra_omega(agents[current_agent], tuple(p0), tuple(p1))
            H = ω @ H
            if return_deviations:
                deviations.append(np.linalg.norm(ω - np.eye(K)))
            if return_beliefs:
                b = ω @ b
                b = np.clip(b,1e-12,None); b = b / b.sum()
                beliefs.append(b.copy())
            if return_path:
                full_path.append(p1)
            # re-orthonormalize
            U, _, Vt = np.linalg.svd(H, full_matrices=False)
            H = U @ Vt

        # gauge hop
        Ω = inter_omega(
            agents[current_agent],
            agents[next_agent],
            tuple(overlap_pt),
             )
        H = Ω @ H
        if return_deviations:
            deviations.append(np.linalg.norm(Ω - np.eye(K)))
        if return_beliefs:
            b = Ω @ b
            b = np.clip(b,1e-12,None); b = b / b.sum()
            beliefs.append(b.copy())
        if return_path:
            full_path.append(overlap_pt)
        U, _, Vt = np.linalg.svd(H, full_matrices=False)
        H = U @ Vt

        # advance
        current_agent = next_agent
        current_pos   = overlap_pt

    # final leg back to start
    start_center = tuple(agents[agent_cycle[0]].center)
    path = construct_spatial_path_nd(current_pos, start_center, domain_size,
                                    mask=agents[agent_cycle[0]].mask)
    first_agent = agents[agent_cycle[0]]
    for p0, p1 in zip(path[:-1], path[1:]):
        ω = intra_omega(first_agent, tuple(p0), tuple(p1))
        H = ω @ H
        if return_deviations:
            deviations.append(np.linalg.norm(ω - np.eye(K)))
        if return_beliefs:
            b = ω @ b
            b = np.clip(b,1e-12,None); b = b / b.sum()
            beliefs.append(b.copy())
        if return_path:
            full_path.append(p1)
        U, _, Vt = np.linalg.svd(H, full_matrices=False)
        H = U @ Vt

    logH = logm(H) if return_logm else None

    # collect outputs
    outputs = [H]
    if return_deviations:
        outputs.append(deviations)
    if return_logm:
        outputs.append(logH)
    if return_beliefs:
        outputs.append(beliefs)
    if return_path:
        outputs.append(full_path)
    _exp_lie.cache_clear()

    return tuple(outputs) if len(outputs)>1 else H


def sample_self_avoiding_loop_within_mask(
    center,
    mask,
    *,
    min_length=4,
    max_length=1000,
    support_cutoff=support_cutoff_eps,
    seed=None
):
    """
    Generate a random self‐avoiding closed loop on a periodic grid,
    staying entirely where mask >= support_cutoff.
    """
    D = len(domain_size)
    rng = random.Random(seed)

    while True:
        visited = {tuple(center)}
        path = [tuple(center)]
        current = np.array(center, dtype=int)
        prev = None

        for _ in range(max_length):
            neighbors = []
            for axis in range(D):
                for d in (-1, +1):
                    nb = list(current)
                    nb[axis] = (nb[axis] + d) % domain_size[axis]
                    nb = tuple(nb)
                    if np.all(mask[nb] >= support_cutoff):
                        neighbors.append(nb)

            if tuple(center) in neighbors and len(path) >= min_length:
                path.append(tuple(center))
                return path

            candidates = [nb for nb in neighbors if nb != prev and nb not in visited]
            if not candidates:
                break

            nxt = rng.choice(candidates)
            prev = tuple(current.tolist())
            current = np.array(nxt, dtype=int)
            visited.add(nxt)
            path.append(nxt)

        continue
