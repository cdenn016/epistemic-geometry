#!/usr/bin/env python3
"""
hyperparam_search.py

A parallelized pipeline for hyperparameter exploration:
  1. Latin-Hypercube design (NumPy implementation) to generate space-filling samples.
  2. Surrogate modeling (RandomForest) with feature-importance output.
  3. Bayesian optimization (Optuna) for adaptive search.

Run without arguments to default to an LHS design of 200 samples.
Usage:
  python hyperparam_search.py --stage [lhs|surrogate|optuna] --n <count>
"""
import numpy as np
import pandas as pd
import logging
import argparse

# Surrogate modeling
from sklearn.ensemble import RandomForestRegressor

# Bayesian optimization
import optuna

# Parallel execution
from joblib import Parallel, delayed
# Import your simulation entrypoint
from generalized_simulation import run_simulation as gs_run

# Number of parallel jobs (-1 uses all CPUs)
N_JOBS = -1

#------------------------------------------------------------------------------
# User must implement this to call their simulator
#------------------------------------------------------------------------------
def run_simulation(params: dict) -> float:
    """
    Wrapper around generalized_simulation.run_simulation.
    Runs your full simulator with the given param overrides,
    then extracts the final total_energy from metric_log.
    """
    # choose a temporary output directory per call
    outdir = f"hp_tmp"
    # always start fresh
    agents, metric_log = gs_run(
        outdir=outdir,
        resume=False,
        log_metrics=True,
        num_cores=1,
        params=params
    )
    # metric_log is a list of dicts; each dict has a 'total_energy' entry
    final = metric_log[-1]
    return final['total_energy']
#------------------------------------------------------------------------------
# Latin-Hypercube sampling (manual NumPy implementation)
#------------------------------------------------------------------------------
def latin_hypercube(params_space: dict, n_samples: int = 10, seed: int = None) -> pd.DataFrame:
    rng = np.random.RandomState(seed)
    keys = list(params_space.keys())
    D = len(keys)
    cut = np.linspace(0, 1, n_samples + 1)
    u = rng.rand(n_samples, D)
    lhs = np.zeros_like(u)
    for i in range(D):
        lhs[:, i] = u[:, i] * (cut[1] - cut[0]) + cut[:n_samples]
        rng.shuffle(lhs[:, i])
    X = np.zeros_like(lhs)
    for j, key in enumerate(keys):
        low, high = params_space[key]
        X[:, j] = low + (high - low) * lhs[:, j]
    return pd.DataFrame(X, columns=keys)

#------------------------------------------------------------------------------
# Surrogate modeling (Random Forest)
#------------------------------------------------------------------------------
import os
import pickle

def train_surrogate(df: pd.DataFrame):
    """
    Loads cached total_energy from lhs_results/run_*/final_metrics.pkl
    and fits a RandomForest surrogate using only numeric columns.
    """
    run_dirs = sorted([
        d for d in os.listdir("lhs_results")
        if os.path.isdir(os.path.join("lhs_results", d)) and d.startswith("run_")
    ])

    energies = []
    for i, run in enumerate(run_dirs):
        path = os.path.join("lhs_results", run, "final_metrics.pkl")
        if not os.path.exists(path):
            print(f"[WARN] Missing: {path}")
            energies.append(np.nan)
            continue
        with open(path, "rb") as f:
            metrics = pickle.load(f)
            if isinstance(metrics, list):
                metrics = metrics[-1]
            energies.append(metrics.get("total_energy", np.nan))

    if len(energies) != len(df):
        raise ValueError("Mismatch: lhs_samples.csv vs lhs_results/*")

    # Filter numeric columns only (drop string columns like 'group_name')
    X = df.select_dtypes(include=[np.number])

    # Remove entries where energy is NaN
    mask = ~np.isnan(energies)
    X = X[mask]
    y = np.array(energies)[mask]

    # Train surrogate
    rf = RandomForestRegressor(
        n_estimators=100, max_features='sqrt', random_state=0,
        n_jobs=N_JOBS
    )
    rf.fit(X.values, y)
    importances = pd.Series(rf.feature_importances_, index=X.columns)
    return rf, importances.sort_values(ascending=False), y


#------------------------------------------------------------------------------
# Bayesian optimization (Optuna)
#------------------------------------------------------------------------------
def optuna_search(params_space: dict, n_trials: int = 50):
    def objective(trial):
        p = {name: trial.suggest_uniform(name, *bounds)
             for name, bounds in params_space.items()}
        return run_simulation(p)
    study = optuna.create_study(direction='minimize')
    study.optimize(objective, n_trials=n_trials, n_jobs=N_JOBS)
    return study

#------------------------------------------------------------------------------
# CLI entrypoint
#------------------------------------------------------------------------------
if __name__ == '__main__':
    parser = argparse.ArgumentParser(
        description="Parallel hyperparameter exploration pipeline"
    )
    parser.add_argument('--stage', choices=['lhs', 'surrogate', 'optuna'],
                        default='lhs', help="Pipeline stage to run (default: lhs)")
    parser.add_argument('--n', type=int, default=10,
                        help="Number of samples/trajectories/trials (default: 200)")
    args = parser.parse_args()

    sweep_params = {
        "alpha":                (0,    100),
        "beta":                 (0,    100),
        "gamma":                (0,    100),
        "gauge_weight":         (0,    100),
        #"model_align_weight":   (0,    100),
        #"model_gauge_weight":   (0,    100),
        #"model_mass_weight":    (0,    100),
        #"model_feedback_weight":(0,    100),
        #"phi_phi_tilde_coupling":(0,   100),
        #"phi_init":             (0,    1.0),
        # Base learning-rate ranges
        #"eta_base_q":           (1e-8,   1e-2),
        #"eta_base_p":           (1e-8,   1e-2),
        #"eta_base_phi":         (1e-8,   1e-2),
        #"eta_base_phi_model":   (1e-8,   1e-2),
    }

    if args.stage == 'lhs':
        # 1) Generate LHS design
        df = latin_hypercube(sweep_params, n_samples=args.n)
        df.to_csv('lhs_samples.csv', index=False)
        print(f'LHS design saved to lhs_samples.csv ({len(df)} samples)')
        
        # 2) Immediately run surrogate stage on the new samples
        print('Starting surrogate evaluation on generated LHS samples...')
        _, importances, _ = train_surrogate(df)
        print('Feature importances from surrogate:')
        print(importances)
    elif args.stage == 'surrogate':
        df = pd.read_csv('lhs_samples.csv')
        _, importances, _ = train_surrogate(df)
        print('Feature importances:')
        print(importances)

    elif args.stage == 'optuna':
        study = optuna_search(sweep_params, n_trials=args.n)
        print('Best parameters:')
        print(study.best_params)
        print('Best value:')
        print(study.best_value)
