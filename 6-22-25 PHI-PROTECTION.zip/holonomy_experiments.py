import os
import re
import time
import pickle
import logging
import random

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from numpy.linalg import norm
from scipy.linalg import logm
from functools import partial

from config import (
    checkpoint_dir,
    domain_size,
    support_cutoff_eps,
    agent_seed,
    group_name,
    K,
)
from get_generators import get_generators
from find_agent_chains import get_agent_cycles, get_overlap_centroid
from holonomy_module import (
    compute_spatial_loop_holonomy,
    compute_agent_cycle_holonomy,
    sample_self_avoiding_loop_within_mask,
)

# ----------------------------
# Experiment parameters
# ----------------------------
max_agent_cycles = 2          # None = all cycles
spatial_sizes = [4]


# ----------------------------
# Logging setup
# ----------------------------
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s %(levelname)s %(message)s'
)


def summarize_holonomy(H):
    """
    Given a holonomy matrix H (K×K), return a dict of common diagnostics.
    """
    I = np.eye(H.shape[0])
    # deviation from identity
    dev_norm   = norm(H - I)
    # trace and determinant metrics
    tr         = np.trace(H)
    det_minus1 = np.linalg.det(H) - 1.0
    # condition number
    cond_num   = np.linalg.cond(H)
    # optional: interpret curve type/value if 2×2, e.g. rotation angle
    curve_type = None
    curve_val  = None
    if H.shape == (2, 2):
        # for SO(2)-like rotations: cos⁻¹(tr/2)
        curve_type = 'rotation_angle'
        curve_val  = np.arccos(tr / 2.0)

    return {
        'deviation_norm': dev_norm,
        'trace':          tr,
        'det_minus1':     det_minus1,
        'cond':           cond_num,
        'curve_type':     curve_type,
        'curve_value':    curve_val,
    }


def parse_step(filename):
    """
    Extract integer step from filenames like 'step_0001.pkl'.
    """
    match = re.match(r'step_(\d+)\.pkl$', filename)
    if not match:
        raise ValueError(f"Filename '{filename}' does not match expected pattern")
    return int(match.group(1))


def load_all_checkpoints():
    """
    Load and cache all checkpoint files from checkpoint_dir.
    Returns a dict mapping step -> unpickled data.
    """
    files = [f for f in os.listdir(checkpoint_dir)
             if f.startswith('step_') and f.endswith('.pkl')]
    if not files:
        raise RuntimeError(f"No checkpoint files found in {checkpoint_dir}")

    # sort by parsed step number
    files_sorted = sorted(files, key=lambda f: parse_step(f))
    cache = {}
    for fname in files_sorted:
        step = parse_step(fname)
        path = os.path.join(checkpoint_dir, fname)
        with open(path, 'rb') as f:
            cache[step] = pickle.load(f)
        logging.info(f"Loaded checkpoint step={step}")
    return cache



from scipy.linalg import logm

def run_spatial_experiments(data_cache, steps, spatial_sizes, generators):
    """
    For each radius r in spatial_sizes:
      1. Sample a single self-avoiding loop on the first step's mask.
      2. Replay that same loop on every timestep in 'steps'.
      3. Record holonomy, deviations, belief trajectories, and summary metrics per step.
    """
    records = []

    # Pick the agent mask from the very first timestep
    first_agents = data_cache[steps[0]][0] if isinstance(data_cache[steps[0]], tuple) else data_cache[steps[0]]
    first_agent  = first_agents[0]
    center       = tuple(first_agent.center)
    mask         = first_agent.mask

    for r in spatial_sizes:
        # Compute loop-length bounds from radius r
        circ  = 2 * np.pi * r
        min_L = max(4, int(0.5 * circ))
        max_L = max(min_L, int(1.2 * circ))

        # Sample ONE loop for this radius using the first step's mask
        coords_loop = sample_self_avoiding_loop_within_mask(
            center,
            mask,
            min_length = min_L,
            max_length = max_L,
            seed       = agent_seed
        )

        # Initial belief on that loop’s start
        b0 = first_agent.q[center].copy()

        # Now replay on every timestep
        for step in steps:
            agents = data_cache[step][0] if isinstance(data_cache[step], tuple) else data_cache[step]
            agent  = agents[0]

            # Holonomy & diagnostics
            H, deviations, belief_seq, path_coords = compute_spatial_loop_holonomy(
                agent,
                coords_loop,
                generators,
                return_deviations=True,
                return_beliefs=True,
                return_path=True,
                initial_belief=b0
            )

            # compute matrix-log and its norm
            F = logm(H)
            curvature_norm = np.linalg.norm(F)

            # Save per-step diagnostics
            diag = {
                'radius':      r,
                'path_coords': path_coords,
                'step':        step,
                'holonomy':    H,
                'logH':        F,
                'deviations':  deviations,
                'belief_seq':  belief_seq,
            }
            outdir = os.path.join('holonomy_runs', 'spatial', f"r{r}_{step}")
            os.makedirs(outdir, exist_ok=True)
            with open(os.path.join(outdir, 'diagnostics.pkl'), 'wb') as f:
                pickle.dump(diag, f)

            # Record summary metrics (including curvature_norm)
            metrics = summarize_holonomy(H)
            metrics['curvature_norm'] = curvature_norm
            records.append({
                'experiment':     'spatial',
                'param':          r,
                'radius':         r,
                'step':           step,
                'loop_length':    len(coords_loop) - 1,
                'max_deviation':  np.max(deviations),
                'mean_deviation': np.mean(deviations),
                'min_deviation':  np.min(deviations),
                **metrics,
            })

    return records

from scipy.linalg import logm

def run_agent_cycle_experiments(data_cache, steps, agents_at_first_step, cycles, generators):
    records = []
    count = 0  # For counting total calls

    # Precompute all overlap centroids for each cycle
    all_overlaps = {
        tuple(cycle): [
            get_overlap_centroid(
                agents_at_first_step[i],
                agents_at_first_step[j],
                domain_size,
                support_cutoff_eps
            ) or (np.nan,)
            for i, j in zip(cycle[:-1], cycle[1:])
        ]
        for cycle in cycles
    }

    for cycle in cycles:
        label    = '_'.join(map(str, cycle))
        overlaps = all_overlaps[tuple(cycle)]

        for step in steps:
            agents = data_cache[step][0] if isinstance(data_cache[step], tuple) else data_cache[step]

            # ⏱️ Time compute_agent_cycle_holonomy + capture belief trajectory & path
            start_agent = cycle[0]
            start_pos   = tuple(agents[start_agent].center)
            b0          = agents[start_agent].q[start_pos]

            start_time = time.time()
            
            H, deviations, belief_seq, transport_path = compute_agent_cycle_holonomy(
                agents,
                cycle,
                overlaps,
                generators,
                initial_belief=b0,
                return_deviations=True,
                return_beliefs=True,
                return_path=True,
                )

            
            elapsed = time.time() - start_time
            print(f"[TIMER] Step={step} Cycle={label} → compute_agent_cycle_holonomy took {elapsed:.4f} sec")
            count += 1

            # Compute logm(H) here and include curvature norm
            F = logm(H)
            curvature_norm = np.linalg.norm(F)

            # compute and record summary metrics
            metrics = summarize_holonomy(H)
            metrics['curvature_norm'] = curvature_norm
            records.append({
                'experiment':   'agent_cycle',
                'param':        label,
                'step':         step,
                'loop_length':  len(cycle),
                **metrics,
                'chordal':      np.linalg.norm(H - np.eye(H.shape[0])),
            })

            # Save diagnostics for this cycle+step
            diag = {
                'cycle':          cycle,
                'overlaps':       overlaps,
                'step':           step,
                'holonomy':       H,
                'logH':           F,
                'deviations':     deviations,
                'belief_seq':     belief_seq,
                'transport_path': transport_path,
                'label':          label,
                'curvature_norm': curvature_norm,

            }
            outdir = os.path.join('holonomy_runs', 'agent', f"{label}_{step}")
            os.makedirs(outdir, exist_ok=True)
            with open(os.path.join(outdir, 'diagnostics.pkl'), 'wb') as f:
                pickle.dump(diag, f)

    print(f"[DEBUG] compute_agent_cycle_holonomy was called {count} times.")
    return records


def main():
    # Load all checkpoints
    data_cache = load_all_checkpoints()
    steps = sorted(data_cache.keys())

    # Use the module-level parameters
    # max_agent_cycles and spatial_sizes are defined at the top
    global max_agent_cycles, spatial_sizes

    # Find agent cycles from the first step’s agents
    first_agents = (data_cache[steps[0]][0]
                    if isinstance(data_cache[steps[0]], tuple)
                    else data_cache[steps[0]])
    all_cycles = get_agent_cycles(first_agents, max_length=24)
    if not all_cycles:
        logging.warning("No agent cycles found; skipping agent_cycle experiments.")
    random.seed(42)
    cycles = random.sample(all_cycles,
                           min(len(all_cycles), max_agent_cycles or len(all_cycles)))

    # Prepare generators and records list
    generators = get_generators(group_name, K)
    records = []

    # Run the two experiment suites
    records += run_spatial_experiments(data_cache, steps, spatial_sizes, generators)
    if all_cycles:
        records += run_agent_cycle_experiments(
            data_cache, steps, first_agents, cycles, generators
        )

    # Save master summary
    df = pd.DataFrame(records)
    # If agent-cycle only logged 'deviation_norm', copy it to 'curvature_norm'
    if 'curvature_norm' not in df.columns and 'deviation_norm' in df.columns:
        df['curvature_norm'] = df['deviation_norm']

    os.makedirs('holonomy_experiments', exist_ok=True)
    master_csv = os.path.join('holonomy_experiments', 'master_summary.csv')
    df.to_csv(master_csv, index=False)
    logging.info(f"Master summary written to {master_csv}")

    # Plot a summary figure
    for metric in ['curvature_norm']:
        plt.figure(figsize=(10, 6))
        for exp in df['experiment'].unique():
            sub = df[df['experiment'] == exp]
            mean_vals = sub.groupby('param')[metric].mean()
            plt.plot(mean_vals.index, mean_vals.values,
                     marker='o', label=exp)
        plt.xlabel('Parameter')
        plt.ylabel(metric)
        plt.title(f'Average {metric} vs. Parameter')
        plt.xticks(rotation=45, ha='right')
        plt.legend()
        plt.tight_layout()
        plt.savefig(os.path.join('holonomy_experiments', f'{metric}_vs_param.png'))
        plt.close()
    logging.info("Plots saved.")

if __name__ == '__main__':
    # Just click Run in Spyder—edit the two constants at the top first if you like:
    main()
