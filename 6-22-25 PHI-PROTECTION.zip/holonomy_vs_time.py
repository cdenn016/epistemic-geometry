import pandas as pd
import matplotlib.pyplot as plt
import os

INPUT_CSV = "holonomy_experiments/merged_full_summary.csv"
OUTPUT_DIR = "holonomy_experiments/plots"
os.makedirs(OUTPUT_DIR, exist_ok=True)


def plot_agent_curvature(df):
    df["experiment"] = df["experiment"].astype(str).str.strip()
    df["param"] = df["param"].astype(str).str.strip()

    agent_df = df[df["experiment"] == "agent_cycle"].dropna(subset=["curvature_norm"])
    if agent_df.empty:
        print("[!] No agent curvature data found.")
        return

    print(f"[✓] Plotting {agent_df['param'].nunique()} agent cycles separately...")

    for label, group in agent_df.groupby("param"):
        group_sorted = group.sort_values("step")
        if group_sorted["curvature_norm"].isna().all():
            print(f"[SKIP] All NaNs in {label}")
            continue

        plt.figure(figsize=(8, 5))
        plt.plot(group_sorted["step"], group_sorted["curvature_norm"], label=f"Cycle {label}")
        plt.title(f"Agent Cycle Curvature: {label}")
        plt.xlabel("Step")
        plt.ylabel("Curvature Norm")
        plt.grid(True)
        plt.tight_layout()
        outname = f"agent_curvature_{label.replace('_', '-')}.png"
        outpath = os.path.join(OUTPUT_DIR, outname)
        plt.savefig(outpath)
        plt.close()
        print(f"[✓] Saved: {outpath}")

def plot_spatial_curvature(df):
    spatial_df = df[df["experiment"] == "spatial"].dropna(subset=["curvature_norm"])
    if spatial_df.empty:
        print("[!] No spatial data found.")
        return

    for radius, group in spatial_df.groupby("radius"):
        group_sorted = group.sort_values("step")

        plt.figure(figsize=(8, 5))
        plt.plot(group_sorted["step"], group_sorted["curvature_norm"], label=f"radius={radius}")
        plt.title(f"Spatial Curvature: radius={radius}")
        plt.xlabel("Step")
        plt.ylabel("Curvature Norm")
        plt.grid(True)
        plt.tight_layout()

        outname = f"spatial_curvature_radius-{int(radius)}.png"
        outpath = os.path.join(OUTPUT_DIR, outname)
        plt.savefig(outpath)
        plt.close()
        print(f"[✓] Saved: {outpath}")



def main():
    df = pd.read_csv(INPUT_CSV)
    print(f"[INFO] Loaded {len(df)} rows from {INPUT_CSV}")
    print("[DEBUG] Unique experiment types:", df["experiment"].unique())

    agent_debug = df[df["experiment"] == "agent_cycle"]
    print("[DEBUG] Agent cycle rows (sample):")
    print(agent_debug.head())

    print("[DEBUG] Agent rows with valid curvature:")
    print(agent_debug[agent_debug["curvature_norm"].notna()][["step", "param", "curvature_norm"]].head())

    plot_agent_curvature(df)
    plot_spatial_curvature(df)


if __name__ == "__main__":
    main()
