# generalized_update_wrappers.py

from generalized_update_rules import synchronous_step


def update_all(agents, generators, params=None, n_jobs=1):
    """
    Alias for synchronous_step with explicit generators argument.
    """
    return synchronous_step(agents, generators, params, n_jobs)


def update_beliefs(i, agents, params=None, n_jobs=1):
    """
    Backwards-compatible stub: runs a full synchronous update,
    then returns the specified agent.
    """
    synchronous_step(agents, params, n_jobs=n_jobs)
    return agents[i]

def update_models(i, agents, params=None, n_jobs=1):
    synchronous_step(agents, params, n_jobs=n_jobs)
    return agents[i]

def update_phi(i, agents, params=None, n_jobs=1):
    synchronous_step(agents, params, n_jobs=n_jobs)
    return agents[i]

def update_phi_model(i, agents, params=None, n_jobs=1):
    synchronous_step(agents, params, n_jobs=n_jobs)
    return agents[i]
