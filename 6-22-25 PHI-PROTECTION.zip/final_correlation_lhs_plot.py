# -*- coding: utf-8 -*-
"""
Created on Sat Jun 21 08:24:13 2025

@author: chris and christine
"""

# plot_sweep_correlation.py

import os
import pickle
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

# Which final metrics to extract:
METRICS = ["coherence", "model_coherence", "free_energy", "total_energy"]

def main():
    records = []
    root = "lhs_results"
    for run in sorted(os.listdir(root)):
        run_dir = os.path.join(root, run)
        pkl_params = os.path.join(run_dir, "params.pkl")
        pkl_metrics = os.path.join(run_dir, "metric_log.pkl")
        if not (os.path.isfile(pkl_params) and os.path.isfile(pkl_metrics)):
            continue

        # 1) load params
        with open(pkl_params, "rb") as f:
            params = pickle.load(f)

        # 2) load metrics and take last entry
        with open(pkl_metrics, "rb") as f:
            metric_log = pickle.load(f)
        final = metric_log[-1]  # assumes list of dicts with 'step' + metric keys

        # 3) build record
        rec = {"run": run}
        # include all scalar params
        for k, v in params.items():
            if isinstance(v, (int, float, str, bool)):
                rec[k] = v
        # include final metrics (if present)
        for m in METRICS:
            rec[f"final_{m}"] = final.get(m, None)
        records.append(rec)

   
        # 4) DataFrame
    df = pd.DataFrame(records).set_index("run")
    print("Summary dataframe:")
    print(df.head())

    # ---- only keep numeric columns for correlation ----
    df_numeric = df.select_dtypes(include=["number"])
    if df_numeric.shape[1] < 2:
        print("Not enough numeric columns to correlate.")
        return

    # 5) Correlation matrix
    corr = df_numeric.corr()
    plt.figure(figsize=(10, 8))
    sns.heatmap(corr, annot=True, fmt=".2f", cmap="vlag", center=0)
    plt.title("Parameter ↔ Final‐Metric Correlation")
    plt.tight_layout()
    out = "plots/sweep_param_metric_correlation.png"
    os.makedirs(os.path.dirname(out), exist_ok=True)
    plt.savefig(out, dpi=200)
    print(f"Saved correlation heatmap → {out}")
    plt.show()


if __name__ == "__main__":
    main()
