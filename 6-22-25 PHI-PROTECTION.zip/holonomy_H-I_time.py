# plot_omega_deviation_vs_time.py

import os
import pickle
import numpy as np
import matplotlib.pyplot as plt
from config import K  # Required to construct identity matrix for ‖H − I‖

base_dir = "holonomy_runs/spatial"
step_vals = []
avg_dev_vals = []
max_dev_vals = []
holonomy_devs = []

for root, dirs, files in os.walk(base_dir):
    if "diagnostics.pkl" not in files:
        continue
    path = os.path.join(root, "diagnostics.pkl")
    try:
        with open(path, "rb") as f:
            diag = pickle.load(f)

        step = diag.get("step", None)
        H = diag.get("holonomy", None)
        deviations = diag.get("deviations", None)

        if step is not None and H is not None and deviations is not None:
            step_vals.append(step)
            avg_dev_vals.append(np.mean(deviations))
            max_dev_vals.append(np.max(deviations))
            holonomy_devs.append(np.linalg.norm(H - np.eye(K)))

    except Exception as e:
        print(f"[WARN] Skipped {path} due to error: {e}")

if not step_vals:
    raise RuntimeError("No valid diagnostics found.")

# Sort by step for cleaner plotting
step_vals = np.array(step_vals)
avg_dev_vals = np.array(avg_dev_vals)
max_dev_vals = np.array(max_dev_vals)
holonomy_devs = np.array(holonomy_devs)
order = np.argsort(step_vals)

# Apply order
step_vals = step_vals[order]
avg_dev_vals = avg_dev_vals[order]
max_dev_vals = max_dev_vals[order]
holonomy_devs = holonomy_devs[order]

# --- PLOT: Separate subplots ---
fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(10, 8), sharex=True)

# Top: Local gauge deviation
ax1.plot(step_vals, avg_dev_vals, marker='o', label="Mean ‖Ω − I‖")
ax1.plot(step_vals, max_dev_vals, marker='x', label="Max ‖Ω − I‖", alpha=0.7)
ax1.set_ylabel("‖Ω − I‖")
ax1.set_title("Local Gauge Deviation Along Loops")
ax1.legend()
ax1.grid(True)

# Bottom: Global holonomy deviation
ax2.plot(step_vals, holonomy_devs, marker='s', linestyle='--', color='green', label="‖H − I‖")
ax2.set_xlabel("Simulation Step")
ax2.set_ylabel("‖H − I‖")
ax2.set_title("Global Holonomy Deviation")
ax2.legend()
ax2.grid(True)

plt.tight_layout()
plt.show()


if __name__ == "__main__":
    print("[RUNNING] Plotting average and max ‖Ω − I‖ deviation vs. step...")

    try:
        base_dir = "holonomy_runs/spatial"
        step_vals = []
        avg_dev_vals = []
        max_dev_vals = []

        for root, dirs, files in os.walk(base_dir):
            if "diagnostics.pkl" not in files:
                continue
            path = os.path.join(root, "diagnostics.pkl")
            try:
                with open(path, "rb") as f:
                    diag = pickle.load(f)
                deviations = diag.get("deviations", None)
                step = diag.get("step", None)
                if deviations is not None and step is not None:
                    step_vals.append(step)
                    avg_dev_vals.append(np.mean(deviations))
                    max_dev_vals.append(np.max(deviations))
            except Exception as e:
                print(f"[WARN] Skipped {path} due to error: {e}")

        if not step_vals:
            raise RuntimeError("No valid diagnostics with deviations and step found.")

        # Sort by step
        step_vals = np.array(step_vals)
        avg_dev_vals = np.array(avg_dev_vals)
        max_dev_vals = np.array(max_dev_vals)
        order = np.argsort(step_vals)

        step_vals = step_vals[order]
        avg_dev_vals = avg_dev_vals[order]
        max_dev_vals = max_dev_vals[order]

        # Plot
        plt.figure(figsize=(8, 4))
        plt.plot(step_vals, avg_dev_vals, label="Mean ‖Ω − I‖", marker='o')
        plt.plot(step_vals, max_dev_vals, label="Max ‖Ω − I‖", marker='x', alpha=0.7)
        plt.xlabel("Simulation Step")
        plt.ylabel("‖Ω − I‖")
        plt.title("Gauge Deviation Along Loops vs. Step")
        plt.legend()
        plt.grid(True)
        plt.tight_layout()
        plt.show()

    except Exception as e:
        print(f"[ERROR] Failed to process deviations: {e}")
