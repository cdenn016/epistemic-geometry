
from __future__ import annotations
from typing import Any, Dict, Iterable, Optional, Sequence, Tuple
import numpy as np

# Your existing utilities
from omega import exp_lie_algebra_irrep
from numerical_utils import safe_omega_inv

"""
Created on Tue Aug 19 20:19:10 2025

@author: chris and christine
"""

# -*- coding: utf-8 -*-
"""
transport_cache.py
Centralized facade for cached transports: exp(φ), Ω_{ij}, Λ (hooks).
Backed by runtime_ctx.cache (CacheHub). One source of truth, cleared per step.
"""


# ---------------------------------------------------------------------------
# Internal helpers (keys, accessors)
# ---------------------------------------------------------------------------

def _aid(a: Any) -> int:
    """Robust agent id (falls back to object's id if missing)."""
    return int(getattr(a, "id", id(a)))

def _exp_key(agent: Any, which: str) -> Tuple[str, int, str]:
    # which ∈ {'q','p'}
    return ("exp", _aid(agent), which)

def _omega_key(ai: Any, aj: Any, which: str) -> Tuple[str, int, int, str]:
    return ("omega", _aid(ai), _aid(aj), which)

def _lambda_key(child: Any, parent: Any, which: str, up: bool) -> Tuple[str, int, int, str, str]:
    return ("lambda", _aid(child), _aid(parent), which, "up" if up else "dn")

def _get_generators(agent: Any, which: str) -> np.ndarray:
    if which == "q":
        G = getattr(agent, "generators_q", None)
    else:
        G = getattr(agent, "generators_p", None)
    if G is None:
        raise ValueError(f"[transport_cache] generators ({which}) missing on agent id={_aid(agent)}")
    return G

def _get_phi(agent: Any, which: str) -> np.ndarray:
    if which == "q":
        phi = getattr(agent, "phi", None)
    else:
        phi = getattr(agent, "phi_model", None)
    if phi is None:
        raise ValueError(f"[transport_cache] phi field ({which}) missing on agent id={_aid(agent)}")
    return phi


# ---------------------------------------------------------------------------
# Public API: exp(φ) and Ω_{ij}
# ---------------------------------------------------------------------------

def E_grid(ctx: Any, agent: Any, which: str = "q") -> np.ndarray:
    """
    Cached exp(φ) grid for an agent in fiber 'q' or 'p'.
    Shape: (..., K, K), broadcasts over spatial dims.
    """
    cache: Dict[Any, Any] = ctx.cache.ns("exp")
    key = _exp_key(agent, which)
    E = cache.get(key)
    if E is None:
        G = _get_generators(agent, which)
        phi = _get_phi(agent, which)
        E = exp_lie_algebra_irrep(phi, G)  # (..., K, K)
        cache[key] = E
    return E


def Omega(ctx: Any, ai: Any, aj: Any, which: str = "q") -> np.ndarray:
    """
    Cached Ω_{ij} = exp(φ_i) @ inv(exp(φ_j)) for fiber 'q' or 'p'.
    Uses safe_omega_inv for general irreps (not assuming orthogonality).
    """
    om_cache = ctx.cache.ns("omega")
    key = _omega_key(ai, aj, which)
    Om = om_cache.get(key)
    if Om is None:
        Ei = E_grid(ctx, ai, which)   # (..., K, K)
        Ej = E_grid(ctx, aj, which)   # (..., K, K)
        Ej_inv = safe_omega_inv(Ej)   # (..., K, K)
        Om = np.matmul(Ei, Ej_inv)    # (..., K, K)
        om_cache[key] = Om
    return Om


# ---------------------------------------------------------------------------
# Optional Λ hooks (centralize later; stubs return cached value if present)
# ---------------------------------------------------------------------------

# transport_cache.py — add/replace these definitions

def _lambda_key(child: Any, parent: Any, which: str, up: bool) -> Tuple[str, int, int, str, str]:
    return ("lambda", _aid(child), _aid(parent), which, "up" if up else "dn")

def Lambda_dn(ctx: Any, child: Any, parent: Any, which: str = "q") -> np.ndarray:
    """
    Cached Λ↓ (parent → child) for fiber 'q' or 'p'.
    Λ↓ = E_child @ E_parent^T
    """
    lam_ns = ctx.cache.ns("lambda")
    key = _lambda_key(child, parent, which, up=False)
    Lam = lam_ns.get(key)
    if Lam is None:
        E_c = E_grid(ctx, child, which=which)
        E_p = E_grid(ctx, parent, which=which)
        E_p_T = np.swapaxes(E_p, -1, -2)
        Lam = np.einsum("...ik,...kj->...ij", E_c, E_p_T, optimize=True)
        lam_ns[key] = Lam
    return Lam

def Lambda_up(ctx: Any, child: Any, parent: Any, which: str = "q") -> np.ndarray:
    """
    Cached Λ↑ (child → parent) for fiber 'q' or 'p'.
    Λ↑ = E_parent @ E_child^T
    """
    lam_ns = ctx.cache.ns("lambda")
    key = _lambda_key(child, parent, which, up=True)
    Lam = lam_ns.get(key)
    if Lam is None:
        E_c = E_grid(ctx, child, which=which)
        E_p = E_grid(ctx, parent, which=which)
        E_c_T = np.swapaxes(E_c, -1, -2)
        Lam = np.einsum("...ik,...kj->...ij", E_p, E_c_T, optimize=True)
        lam_ns[key] = Lam
    return Lam



# ---------------------------------------------------------------------------
# Warming & invalidation
# ---------------------------------------------------------------------------

def warm_E(ctx: Any, agents: Sequence[Any], whiches: Iterable[str] = ("q", "p")) -> None:
    """Precompute exp(φ) for many agents (idempotent)."""
    for a in agents:
        for w in whiches:
            try:
                _ = E_grid(ctx, a, which=w)
            except Exception:
                # Keep warm-up best-effort; avoid failing the whole pass.
                pass

def warm_Omega(ctx: Any, pairs: Sequence[Tuple[Any, Any]], which: str = "q") -> None:
    """Precompute Ω_{ij} for (i, j) pairs (idempotent)."""
    for (ai, aj) in pairs:
        try:
            _ = Omega(ctx, ai, aj, which=which)
        except Exception:
            pass

def invalidate_agent(ctx: Any, agent: Any) -> None:
    """
    Drop all exp/omega/lambda entries involving this agent.
    Call after mutating agent.phi / agent.phi_model mid-step.
    (Per-step clears still happen via ctx.cache.clear_on_step(...).)
    """
    aid = _aid(agent)
    for ns_name in ("exp", "omega", "lambda"):
        ns = ctx.cache.ns(ns_name)
        # Build a kill-list first (avoid dict-size change during iteration)
        to_kill = [k for k in list(ns.keys())
                   if isinstance(k, tuple) and (aid in k)]
        for k in to_kill:
            ns.pop(k, None)


# ---------------------------------------------------------------------------
# Transitional compatibility helpers (optional)
# ---------------------------------------------------------------------------

def get_or_build_E(ctx: Optional[Any], agent: Any, which: str = "q") -> np.ndarray:
    """
    Transitional shim: if ctx given, returns E_grid(ctx,...); else computes
    exp_lie_algebra_irrep on the fly (no caching). Useful for gradual adoption.
    """
    if ctx is None:
        G = _get_generators(agent, which)
        phi = _get_phi(agent, which)
        return exp_lie_algebra_irrep(phi, G)
    return E_grid(ctx, agent, which=which)
