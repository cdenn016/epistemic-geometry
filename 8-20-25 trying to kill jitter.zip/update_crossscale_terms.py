from __future__ import annotations
import numpy as np
from transport_cache import E_grid
from omega import d_exp_phi_exact
from gaussian_core import sanitize_sigma, safe_inv
import config
from transport_cache import warm_E
from transport_cache import Lambda_dn
# exp/log on the group and their differentials
from omega import d_exp_phi_exact, d_exp_phi_tilde_exact, exp_lie_algebra_irrep

# SPD helpers
from numerical_utils import sanitize_sigma, safe_inv, safe_omega_inv
from numerical_utils import isfinite_scalar
from transport_cache import Lambda_up
"""
Cross-scale (child ↔ parent) energy and gradients, gauge-covariant.

- Belief side (q):   Λ = exp(φ_child) · exp(-φ_parent) = E_c · E_p^T
- Model  side (p):  Λ̃ = exp(φ̃_child) · exp(-φ̃_parent) = Ê_c · Ê_p^T

Child gradients are always accumulated.
Parent gradients are accumulated only if child_only=False.

Config knobs (expected in `config.py` or params):
  lambda_xscale_q: float   # strength on belief side
  lambda_xscale_p: float   # strength on model side
  eps: float               # numerical floor for masks / inverses
"""


# ─────────────────────────────────────────────────────────────────────────────
# Cross-scale helpers (mask coercion, weights, norms, ids, finiteness)
# ─────────────────────────────────────────────────────────────────────────────
import numpy as np
import config

def _xscale_get_parent_ids(agent):
    pids = getattr(agent, "parent_ids", None)
    if pids:
        return [int(p) for p in pids]
    pid = int(getattr(agent, "parent_id", -1))
    return [pid] if pid >= 0 else []

def _coerce_mask_shape(mask_src, shape_dst_hw):
    """
    Make mask_src match target (H,W) using reshape or NN resample.
    Returns float32 mask in [0,1].
    """
    m = np.asarray(mask_src, dtype=np.float32)
    Ht, Wt = shape_dst_hw
    if m.shape == (Ht, Wt):
        return m
    if m.size == Ht * Wt:
        return m.reshape(Ht, Wt)
    # nearest-neighbor resample (dependency-free)
    if m.ndim < 2 or m.shape[0] == 0 or m.shape[1] == 0:
        return np.zeros((Ht, Wt), np.float32)
    Hs, Ws = m.shape[:2]
    yi = (np.arange(Ht) * (Hs / float(Ht))).astype(np.int64)
    xi = (np.arange(Wt) * (Ws / float(Wt))).astype(np.int64)
    yi = np.clip(yi, 0, Hs - 1)
    xi = np.clip(xi, 0, Ws - 1)
    return m[yi[:, None], xi[None, :]].astype(np.float32, copy=False)

def _xscale_overlap_mask(child_mask, parent_mask, mask_tau):
    """
    Coerce parent mask to child grid; return boolean overlap.
    """
    Hc, Wc = np.asarray(child_mask).shape[:2]
    pm = _coerce_mask_shape(parent_mask, (Hc, Wc))
    return (np.asarray(child_mask, np.float32) > mask_tau) & (pm > mask_tau)

def _xscale_ramped_weights(parent, lam_q, lam_p, n_parents, params):
    """
    Per-parent effective weights with freeze+ramp.
    """
    eff_lam_q = float(getattr(parent, "lambda_q_weight", lam_q)) / max(1, n_parents)
    eff_lam_p = float(getattr(parent, "lambda_p_weight", lam_p)) / max(1, n_parents)

    age   = int(getattr(parent, "_age", 0))
    grace = int(getattr(parent, "_grace", params.get("parent_freeze_steps", 0)))
    ramp  = max(1, int(params.get("parent_ramp_steps", 10)))
    ramp_factor = 0.0 if age < grace else min(1.0, (age - grace + 1) / ramp)

    return eff_lam_q * ramp_factor, eff_lam_p * ramp_factor

def _isfinite_scalar(x):
    try:
        a = np.asarray(x).squeeze()
        return a.ndim == 0 and np.isfinite(a)
    except Exception:
        return False

def _masked_L2(x, overlap_bool):
    if x is None:
        return 0.0
    a = np.asarray(x, np.float64)
    # if spatial dims match overlap, mask; else use full
    if a.ndim >= 3 and a.shape[0] == overlap_bool.shape[0] and a.shape[1] == overlap_bool.shape[1]:
        sel = a[overlap_bool]
    else:
        sel = a.reshape(-1)
    return float(np.linalg.norm(sel))

def _print_norms(tag, child, parent, overlap, bundle, dbg, child_shape_hw, kl=None):
    if not dbg:
        return
    if bundle == "q":
        c_mu, c_S = getattr(child, "grad_mu_q", None), getattr(child, "grad_sigma_q", None)
        c_phi     = getattr(child, "grad_phi", None)
        p_mu, p_S = getattr(parent, "grad_mu_q", None), getattr(parent, "grad_sigma_q", None)
        p_phi     = getattr(parent, "grad_phi", None)
    else:
        c_mu, c_S = getattr(child, "grad_mu_p", None), getattr(child, "grad_sigma_p", None)
        c_phi     = getattr(child, "grad_phi_tilde", None)
        p_mu, p_S = getattr(parent, "grad_mu_p", None), getattr(parent, "grad_sigma_p", None)
        p_phi     = getattr(parent, "grad_phi_tilde", None)

    msg = [f"[XS.{bundle.upper()} {tag}] child {int(child.id)} ↔ parent {int(parent.id)}"]
    if kl is not None:
        try: msg.append(f"KL={float(np.nan_to_num(kl)):.3e}")
        except Exception: pass
    msg.append(f"overlap_px={int(overlap.sum())}  childHW={child_shape_hw}")
    msg.append(f"|dμ_c|={_masked_L2(c_mu, overlap):.3e}")
    msg.append(f"|dΣ_c|={_masked_L2(c_S, overlap):.3e}")
    msg.append(f"|dφ_c|={_masked_L2(c_phi, overlap):.3e}")
    msg.append(f"|dμ_p|={_masked_L2(p_mu, overlap):.3e}")
    msg.append(f"|dΣ_p|={_masked_L2(p_S, overlap):.3e}")
    msg.append(f"|dφ_p|={_masked_L2(p_phi, overlap):.3e}")
    print("  \n\n".join(msg))


# ─────────────────────────────────────────────────────────────────────────────
# Cross-scale main
# ─────────────────────────────────────────────────────────────────────────────
from transport_cache import warm_E
def accumulate_crossscale_gradients(agent_i, all_agents, generators_q, generators_p, params):
    """Accumulate child↔parent cross-scale gradients (q & p), supporting multi-parent membership
    via pixelwise or scalar responsibilities."""
    import numpy as np
    ctx        = params.get("runtime_ctx", None)
    lam_x_q    = float(params.get("lambda_xscale_q", getattr(config, "lambda_xscale_q", 0.0)))
    lam_x_p    = float(params.get("lambda_xscale_p", getattr(config, "lambda_xscale_p", 0.0)))
    eps        = float(getattr(config, "eps", 1e-6))
    child_only = bool(params.get("xscale_child_only", True))
    mask_tau   = float(params.get("support_tau", 1e-3))
    dbg        = bool(params.get("debug_xscale_grad_norms", getattr(config, "debug_xscale_grad_norms", True)))

    # pre-warm child E grids (q & p) — idempotent
    if ctx is not None:
        try:
            warm_E(ctx, [agent_i], whiches=("q", "p"))
        except Exception:
            pass

    # id→agent map
    id2A = {int(A.id): A for A in all_agents if A is not None}
    kl_out = {"kl_q": [], "kl_p": []}

    # parents
    pids = _xscale_get_parent_ids(agent_i)
    if not pids:
        return kl_out

    n_parents = max(1, len(pids))
    child_mask = np.asarray(getattr(agent_i, "mask", 0.0), dtype=np.float32)
    child_shape_hw = tuple(child_mask.shape[:2]) if child_mask.ndim >= 2 else None

    # responsibility stores (if built earlier via build_child_parent_responsibilities)
    resp_pix = getattr(agent_i, "_parent_resp_mask", {}) or {}
    resp_scl = getattr(agent_i, "_parent_resp", {}) or {}

    for pid in pids:
        parent = id2A.get(int(pid))
        if parent is None:
            continue

        # pre-warm parent E (q & p)
        if ctx is not None:
            try:
                warm_E(ctx, [parent], whiches=("q", "p"))
            except Exception:
                pass

        parent_mask = np.asarray(getattr(parent, "mask", 0.0), dtype=np.float32)

        # ---- choose weighting ----
        # Prefer pixelwise responsibilities; else scalar; else hard overlap.
        weight_mask = resp_pix.get(int(pid), None)
        if weight_mask is not None:
            # Pixelwise: use where weight > 0 as the debug/valid region
            overlap = np.asarray(weight_mask, dtype=np.float32) > 0.0
        else:
            w_scalar = float(resp_scl.get(int(pid), 0.0))
            if w_scalar > 0.0:
                overlap = _xscale_overlap_mask(child_mask, parent_mask, mask_tau)
                weight_mask = w_scalar  # scalar reweight
            else:
                overlap = _xscale_overlap_mask(child_mask, parent_mask, mask_tau)
                # no explicit responsibility → default to overlap weights only
                weight_mask = None

        if not np.any(overlap):
            continue

        eff_lam_q, eff_lam_p = _xscale_ramped_weights(parent, lam_x_q, lam_x_p, n_parents, params)

        # ---- q bundle (DOWN always; UP if child_only=False) -----------------
        if eff_lam_q > 0.0 and agent_i.mu_q_field.shape[-1] == parent.mu_q_field.shape[-1]:
            kl_q = accumulate_xscale_q_dn_gaugecov(
                child=agent_i, parent=parent, generators_q=generators_q,
                lam_q=eff_lam_q, eps=eps, child_only=True, ctx=ctx,
                weight_mask=weight_mask,   # << responsibility-aware
            )
            if _isfinite_scalar(kl_q):
                _klq = float(np.asarray(kl_q).squeeze())
                kl_out["kl_q"].append(_klq)
                _print_norms("DN", agent_i, parent, overlap, "q", dbg, child_shape_hw, kl=_klq)
            else:
                _print_norms("DN", agent_i, parent, overlap, "q", dbg, child_shape_hw, kl=None)

            if not child_only:
                _ = accumulate_xscale_q_up_gaugecov(
                    child=agent_i, parent=parent, generators_q=generators_q,
                    lam_q=eff_lam_q, eps=eps, child_only=False, ctx=ctx,
                    weight_mask=weight_mask,   # << responsibility-aware
                )
                _print_norms("UP", agent_i, parent, overlap, "q", dbg, child_shape_hw)

        # ---- p bundle (DOWN always; UP if child_only=False) -----------------
        if eff_lam_p > 0.0 and agent_i.mu_p_field.shape[-1] == parent.mu_p_field.shape[-1]:
            kl_p = accumulate_xscale_p_dn_gaugecov(
                child=agent_i, parent=parent, generators_p=generators_p,
                lam_p=eff_lam_p, eps=eps, child_only=True, ctx=ctx,
                weight_mask=weight_mask,   # << responsibility-aware
            )
            if _isfinite_scalar(kl_p):
                _klp = float(np.asarray(kl_p).squeeze())
                kl_out["kl_p"].append(_klp)
                _print_norms("DN", agent_i, parent, overlap, "p", dbg, child_shape_hw, kl=_klp)
            else:
                _print_norms("DN", agent_i, parent, overlap, "p", dbg, child_shape_hw, kl=None)

            if not child_only:
                _ = accumulate_xscale_p_up_gaugecov(
                    child=agent_i, parent=parent, generators_p=generators_p,
                    lam_p=eff_lam_p, eps=eps, child_only=False, ctx=ctx,
                    weight_mask=weight_mask,   # << responsibility-aware
                )
                _print_norms("UP", agent_i, parent, overlap, "p", dbg, child_shape_hw)

    return kl_out

#=============================================================================
#
#                                 GRADIENTS
#
#============================================================================


# Child grads always; parent grads when child_only=False
def accumulate_xscale_q_dn_gaugecov(
    child, parent, generators_q, lam_q: float, eps: float = 1e-6,
    use_cached_exp: bool = True, child_only: bool = True, ctx=None,
    weight_mask=None,   # NEW: pixelwise mask (H×W) or scalar responsibility
) -> float:
    """
    Cross-scale belief KL in q-fiber with gauge-covariant transport.
    If `weight_mask` is provided (array or scalar), it multiplicatively
    reweights the overlap so a child can contribute to multiple parents
    without double-counting.
    """
    import numpy as np
    if lam_q <= 0.0:
        return 0.0

    # exp(φ) via central cache
    E_c = E_grid(ctx, child,  which="q")    # (...,K,K)
    E_p = E_grid(ctx, parent, which="q")    # (...,K,K)

    # Λ = E_c @ E_p^T (parent -> child)
    Lambda = Lambda_dn(ctx, child, parent, which="q")
    ΛT     = np.swapaxes(Lambda, -1, -2)

    # fields
    mu_c = child.mu_q_field
    S_c  = sanitize_sigma(getattr(child,  "Sigma_q_field", child.sigma_q_field), eps=eps)
    mu_P = parent.mu_q_field
    S_P  = sanitize_sigma(getattr(parent, "Sigma_q_field", parent.sigma_q_field), eps=eps)

    # transport parent stats to child frame
    mu_t = np.einsum("...ij,...j->...i", Lambda, mu_P, optimize=True)
    S_t  = np.einsum("...ik,...kl,...jl->...ij", Lambda, S_P, ΛT, optimize=True)
    S_t  = 0.5*(S_t + np.swapaxes(S_t, -1, -2))
    S_t  = sanitize_sigma(S_t, eps=eps)

    # inverses
    S_t_inv = safe_inv(S_t, eps=eps)
    S_c_inv = safe_inv(S_c, eps=eps)

    # mask weights: overlap × optional responsibility
    w  = np.minimum(np.asarray(child.mask, float), np.asarray(parent.mask, float))
    if weight_mask is not None:
        if np.isscalar(weight_mask):
            w = w * float(weight_mask)
        else:
            w = w * np.clip(np.asarray(weight_mask, float), 0.0, 1.0)
    w1 = w[..., None]
    w4 = w[..., None, None]

    # child μ,Σ grads
    g_mu_c = np.einsum("...ij,...j->...i", S_t_inv, (mu_c - mu_t), optimize=True)
    g_S_c  = 0.5*(S_t_inv - S_c_inv)
    g_S_c  = 0.5*(g_S_c + np.swapaxes(g_S_c, -1, -2))

    if getattr(child, "grad_mu_q", None) is None:
        child.grad_mu_q = np.zeros_like(mu_c)
    if getattr(child, "grad_sigma_q", None) is None:
        child.grad_sigma_q = np.zeros_like(S_c)

    child.grad_mu_q    += float(lam_q) * (g_mu_c * w1)
    child.grad_sigma_q += float(lam_q) * (g_S_c  * w4)

    # dμ_t, dΣ_t
    dmu   = (mu_c - mu_t)
    dmu_t = - np.einsum("...ij,...j->...i", S_t_inv, dmu, optimize=True)
    outer = dmu[..., None] @ np.swapaxes(dmu[..., None], -1, -2)
    dKL_dA = 0.5 * (S_c + outer - S_t)
    dS_t = - np.einsum("...ik,...kl,...lj->...ij", S_t_inv, dKL_dA, S_t_inv, optimize=True)
    dS_t = 0.5*(dS_t + np.swapaxes(dS_t, -1, -2))

    # ∂KL/∂Λ
    term_mean = dmu_t[..., None] @ mu_P[..., None, :]
    term_cov  = 2.0 * np.einsum("...ij,...jk,...kl->...il", dS_t, Lambda, S_P, optimize=True)
    GΛ = (term_mean + term_cov) * w4

    # child φ grads (via Λ = E_c @ E_p^T)
    E_p_T = np.swapaxes(E_grid(ctx, parent, which="q"), -1, -2)
    T_child = np.einsum("...ij,...jk->...ik", GΛ, E_p_T, optimize=True)
    D_c = d_exp_phi_exact(child.phi, child.generators_q, exp_phi_all=E_c)  # list of (...,K,K)
    g_phi_c = np.stack([np.einsum("...ij,...ij->...", T_child, D_c[a], optimize=True) for a in range(len(D_c))], axis=-1)
    g_phi_c = g_phi_c * w1

    if getattr(child, "grad_phi", None) is None:
        child.grad_phi = np.zeros_like(child.phi)
    child.grad_phi += float(lam_q) * g_phi_c

    # optional parent grads
    if not child_only:
        T_parent = - np.einsum("...ij,...jk->...ik", ΛT, GΛ, optimize=True)
        D_p = d_exp_phi_exact(parent.phi, parent.generators_q, exp_phi_all=E_p)
        g_phi_p = np.stack([np.einsum("...ij,...ij->...", T_parent, D_p[a], optimize=True) for a in range(len(D_p))], axis=-1)
        g_phi_p = g_phi_p * w1

        if getattr(parent, "grad_phi", None) is None:
            parent.grad_phi = np.zeros_like(parent.phi)
        parent.grad_phi += float(lam_q) * g_phi_p

        g_mu_P = np.einsum("...ij,...j->...i", ΛT, dmu_t, optimize=True)
        g_S_P  = np.einsum("...ik,...kl,...jl->...ij", ΛT, dS_t, Lambda, optimize=True)
        g_S_P  = 0.5*(g_S_P + np.swapaxes(g_S_P, -1, -2))

        if getattr(parent, "grad_mu_q", None) is None:
            parent.grad_mu_q = np.zeros_like(mu_P)
        if getattr(parent, "grad_sigma_q", None) is None:
            parent.grad_sigma_q = np.zeros_like(S_P)

        parent.grad_mu_q    += float(lam_q) * (g_mu_P * w1)
        parent.grad_sigma_q += float(lam_q) * (g_S_P  * w4)

    # scalar KL (masked mean)
    k = mu_c.shape[-1]
    diff = (mu_c - mu_t)[..., None]
    quad = (np.swapaxes(diff, -1, -2) @ S_t_inv @ diff)[..., 0, 0]
    tr   = np.einsum("...ij,...ji->...", S_t_inv, S_c, optimize=True)
    st_s, st_ld = np.linalg.slogdet(S_t); sc_s, sc_ld = np.linalg.slogdet(S_c)
    st_ld = np.where(st_s > 0, st_ld, np.nan)
    sc_ld = np.where(sc_s > 0, sc_ld, np.nan)
    kl_pt = 0.5 * (tr + quad - k + (st_ld - sc_ld))

    valid = np.isfinite(kl_pt) & (w > 0.0)
    return float(np.nanmean(kl_pt[valid]) * float(lam_q)) if np.any(valid) else 0.0






def accumulate_xscale_p_dn_gaugecov(
    child, parent, generators_p, lam_p: float, eps: float = 1e-6,
    use_cached_exp: bool = True, child_only: bool = True, ctx=None,
    weight_mask=None,   # NEW: pixelwise mask (H×W) or scalar responsibility
) -> float:
    """
    Cross-scale model KL in p-fiber (masked mean) with optional responsibility weighting.
    """
    import numpy as np
    if lam_p <= 0.0:
        return 0.0

    # exp(φ̃) via central cache
    E_c = E_grid(ctx, child,  which="p")
    E_p = E_grid(ctx, parent, which="p")

    # Λ̃ = E_c @ E_p^T (parent -> child in model fiber)
    Lambda = Lambda_dn(ctx, child, parent, which="p")
    ΛT     = np.swapaxes(Lambda, -1, -2)

    # fields (model side)
    mu_c = child.mu_p_field
    S_c  = sanitize_sigma(getattr(child,  "Sigma_p_field", child.sigma_p_field), eps=eps)
    mu_P = parent.mu_p_field
    S_P  = sanitize_sigma(getattr(parent, "Sigma_p_field", parent.sigma_p_field), eps=eps)

    # transport parent stats to child frame
    mu_t = np.einsum("...ij,...j->...i", Lambda, mu_P, optimize=True)
    S_t  = np.einsum("...ik,...kl,...jl->...ij", Lambda, S_P, ΛT, optimize=True)
    S_t  = 0.5 * (S_t + np.swapaxes(S_t, -1, -2))
    S_t  = sanitize_sigma(S_t, eps=eps)

    # inverses
    S_t_inv = safe_inv(S_t, eps=eps)
    S_c_inv = safe_inv(S_c, eps=eps)

    # mask weights: overlap × optional responsibility
    w  = np.minimum(np.asarray(child.mask, float), np.asarray(parent.mask, float))
    if weight_mask is not None:
        if np.isscalar(weight_mask):
            w = w * float(weight_mask)
        else:
            w = w * np.clip(np.asarray(weight_mask, float), 0.0, 1.0)
    w1 = w[..., None]
    w4 = w[..., None, None]

    # child μ,Σ grads (model side)
    g_mu_c = np.einsum("...ij,...j->...i", S_t_inv, (mu_c - mu_t), optimize=True)
    g_S_c  = 0.5 * (S_t_inv - S_c_inv)
    g_S_c  = 0.5 * (g_S_c + np.swapaxes(g_S_c, -1, -2))

    if getattr(child, "grad_mu_p", None) is None:
        child.grad_mu_p = np.zeros_like(mu_c)
    if getattr(child, "grad_sigma_p", None) is None:
        child.grad_sigma_p = np.zeros_like(S_c)

    child.grad_mu_p    += float(lam_p) * (g_mu_c * w1)
    child.grad_sigma_p += float(lam_p) * (g_S_c  * w4)

    # φ̃ (model gauge) grads
    dmu   = (mu_c - mu_t)
    dmu_t = - np.einsum("...ij,...j->...i", S_t_inv, dmu, optimize=True)
    outer = dmu[..., None] @ np.swapaxes(dmu[..., None], -1, -2)
    dKL_dA = 0.5 * (S_c + outer - S_t)
    dS_t = - np.einsum("...ik,...kl,...lj->...ij", S_t_inv, dKL_dA, S_t_inv, optimize=True)
    dS_t = 0.5 * (dS_t + np.swapaxes(dS_t, -1, -2))

    term_mean = dmu_t[..., None] @ mu_P[..., None, :]
    term_cov  = 2.0 * np.einsum("...ij,...jk,...kl->...il", dS_t, Lambda, S_P, optimize=True)
    GΛ = (term_mean + term_cov) * w4

    # child φ̃ grads via Λ̃ = E_c @ E_p^T
    E_p_T = np.swapaxes(E_grid(ctx, parent, which="p"), -1, -2)
    T_child = np.einsum("...ij,...jk->...ik", GΛ, E_p_T, optimize=True)
    D_c = d_exp_phi_exact(child.phi_model, child.generators_p, exp_phi_all=E_c)
    g_phi_tilde_c = np.stack(
        [np.einsum("...ij,...ij->...", T_child, D_c[a], optimize=True) for a in range(len(D_c))],
        axis=-1
    ) * w1

    if getattr(child, "grad_phi_tilde", None) is None:
        child.grad_phi_tilde = np.zeros_like(child.phi_model)
    child.grad_phi_tilde += float(lam_p) * g_phi_tilde_c

    # optional parent grads
    if not child_only:
        T_parent = - np.einsum("...ij,...jk->...ik", ΛT, GΛ, optimize=True)
        D_p = d_exp_phi_exact(parent.phi_model, parent.generators_p, exp_phi_all=E_p)
        g_phi_tilde_p = np.stack(
            [np.einsum("...ij,...ij->...", T_parent, D_p[a], optimize=True) for a in range(len(D_p))],
            axis=-1
        ) * w1

        if getattr(parent, "grad_phi_tilde", None) is None:
            parent.grad_phi_tilde = np.zeros_like(parent.phi_model)
        parent.grad_phi_tilde += float(lam_p) * g_phi_tilde_p

        g_mu_P = np.einsum("...ij,...j->...i", ΛT, dmu_t, optimize=True)
        g_S_P  = np.einsum("...ik,...kl,...jl->...ij", ΛT, dS_t, Lambda, optimize=True)
        g_S_P  = 0.5 * (g_S_P + np.swapaxes(g_S_P, -1, -2))

        if getattr(parent, "grad_mu_p", None) is None:
            parent.grad_mu_p = np.zeros_like(mu_P)
        if getattr(parent, "grad_sigma_p", None) is None:
            parent.grad_sigma_p = np.zeros_like(S_P)

        parent.grad_mu_p    += float(lam_p) * (g_mu_P * w1)
        parent.grad_sigma_p += float(lam_p) * (g_S_P  * w4)

    # scalar KL (masked mean)
    k = mu_c.shape[-1]
    diff = (mu_c - mu_t)[..., None]
    quad = (np.swapaxes(diff, -1, -2) @ S_t_inv @ diff)[..., 0, 0]
    tr   = np.einsum("...ij,...ji->...", S_t_inv, S_c, optimize=True)
    st_s, st_ld = np.linalg.slogdet(S_t); sc_s, sc_ld = np.linalg.slogdet(S_c)
    st_ld = np.where(st_s > 0, st_ld, np.nan)
    sc_ld = np.where(sc_s > 0, sc_ld, np.nan)
    kl_pt = 0.5 * (tr + quad - k + (st_ld - sc_ld))

    valid = np.isfinite(kl_pt) & (w > 0.0)
    return float(np.nanmean(kl_pt[valid]) * float(lam_p)) if np.any(valid) else 0.0






def accumulate_xscale_q_up_gaugecov(
    child, parent, generators_q, lam_q: float, eps: float = 1e-6,
    use_cached_exp: bool = True, child_only: bool = True, ctx=None,
    weight_mask=None,  # NEW: pixelwise or scalar responsibility
) -> float:
    """
    Cross-scale belief KL (UP): transport child -> parent frame in q-fiber.
    Computes KL(N_parent || N_child→parent) as masked mean.
    Parent grads always; child grads if child_only=False.
    Optional `weight_mask` reweights the overlap so a child can contribute to
    multiple parents without double-counting (pixelwise or scalar).
    """
    import numpy as np
    if lam_q <= 0.0:
        return 0.0

    # exp(φ) from cache
    E_c = E_grid(ctx, child,  which="q")     # (...,K,K)
    E_p = E_grid(ctx, parent, which="q")     # (...,K,K)

    # Λ_up = E_p @ E_c^T  (child -> parent)
    Lambda = Lambda_up(ctx, child, parent, which="q")
    ΛT     = np.swapaxes(Lambda, -1, -2)

    # fields
    mu_c = child.mu_q_field
    S_c  = sanitize_sigma(getattr(child,  "Sigma_q_field", child.sigma_q_field), eps=eps)
    mu_P = parent.mu_q_field
    S_P  = sanitize_sigma(getattr(parent, "Sigma_q_field", parent.sigma_q_field), eps=eps)

    # transport child stats to parent frame
    mu_ct = np.einsum("...ij,...j->...i", Lambda, mu_c, optimize=True)
    S_ct  = np.einsum("...ik,...kl,...jl->...ij", Lambda, S_c, ΛT, optimize=True)
    S_ct  = 0.5*(S_ct + np.swapaxes(S_ct, -1, -2))
    S_ct  = sanitize_sigma(S_ct, eps=eps)

    # inverses
    S_ct_inv = safe_inv(S_ct, eps=eps)
    S_P_inv  = safe_inv(S_P,  eps=eps)

    # overlap mask × optional responsibility
    w = np.minimum(np.asarray(child.mask, float), np.asarray(parent.mask, float))
    if weight_mask is not None:
        if np.isscalar(weight_mask):
            w = w * float(weight_mask)
        else:
            w = w * np.clip(np.asarray(weight_mask, float), 0.0, 1.0)
    w1 = w[..., None]
    w4 = w[..., None, None]

    # parent μ,Σ grads (matching in parent frame)
    g_mu_P = np.einsum("...ij,...j->...i", S_ct_inv, (mu_P - mu_ct), optimize=True)
    g_S_P  = 0.5*(S_ct_inv - S_P_inv)
    g_S_P  = 0.5*(g_S_P + np.swapaxes(g_S_P, -1, -2))

    if getattr(parent, "grad_mu_q", None) is None:
        parent.grad_mu_q = np.zeros_like(mu_P)
    if getattr(parent, "grad_sigma_q", None) is None:
        parent.grad_sigma_q = np.zeros_like(S_P)

    parent.grad_mu_q    += float(lam_q) * (g_mu_P * w1)
    parent.grad_sigma_q += float(lam_q) * (g_S_P  * w4)

    # backprop through Λ_up
    dmu   = (mu_P - mu_ct)
    dmu_t = - np.einsum("...ij,...j->...i", S_ct_inv, dmu, optimize=True)
    outer = dmu[..., None] @ np.swapaxes(dmu[..., None], -1, -2)
    dKL_dA = 0.5 * (S_P + outer - S_ct)
    dS_ct = - np.einsum("...ik,...kl,...lj->...ij", S_ct_inv, dKL_dA, S_ct_inv, optimize=True)
    dS_ct = 0.5*(dS_ct + np.swapaxes(dS_ct, -1, -2))

    # ∂KL/∂Λ_up with μ_ct = Λ_up μ_c, Σ_ct = Λ_up Σ_c Λ_up^T
    term_mean = dmu_t[..., None] @ mu_c[..., None, :]
    term_cov  = 2.0 * np.einsum("...ij,...jk,...kl->...il", dS_ct, Lambda, S_c, optimize=True)
    GΛ = (term_mean + term_cov) * w4

    # parent φ grads via Λ_up = E_p @ E_c^T  -> T_parent = GΛ @ E_c^T
    E_c_T = np.swapaxes(E_grid(ctx, child,  which="q"), -1, -2)
    T_parent = np.einsum("...ij,...jk->...ik", GΛ, E_c_T, optimize=True)
    D_p = d_exp_phi_exact(parent.phi, parent.generators_q, exp_phi_all=E_p)
    g_phi_p = np.stack([np.einsum("...ij,...ij->...", T_parent, D_p[a], optimize=True) for a in range(len(D_p))], axis=-1)
    g_phi_p = g_phi_p * w1

    if getattr(parent, "grad_phi", None) is None:
        parent.grad_phi = np.zeros_like(parent.phi)
    parent.grad_phi += float(lam_q) * g_phi_p

    # optional child grads (through E_c^T)
    if not child_only:
        T_child = - np.einsum("...ij,...jk->...ik", ΛT, GΛ, optimize=True)
        D_c = d_exp_phi_exact(child.phi, child.generators_q, exp_phi_all=E_c)
        g_phi_c = np.stack([np.einsum("...ij,...ij->...", T_child, D_c[a], optimize=True) for a in range(len(D_c))], axis=-1)
        g_phi_c = g_phi_c * w1

        if getattr(child, "grad_phi", None) is None:
            child.grad_phi = np.zeros_like(child.phi)
        child.grad_phi += float(lam_q) * g_phi_c

        g_mu_c = np.einsum("...ij,...j->...i", ΛT, dmu_t, optimize=True)
        g_S_c  = np.einsum("...ik,...kl,...jl->...ij", ΛT, dS_ct, Lambda, optimize=True)
        g_S_c  = 0.5*(g_S_c + np.swapaxes(g_S_c, -1, -2))

        if getattr(child, "grad_mu_q", None) is None:
            child.grad_mu_q = np.zeros_like(mu_c)
        if getattr(child, "grad_sigma_q", None) is None:
            child.grad_sigma_q = np.zeros_like(S_c)

        child.grad_mu_q    += float(lam_q) * (g_mu_c * w1)
        child.grad_sigma_q += float(lam_q) * (g_S_c  * w4)

    # scalar KL (masked mean): KL(N_P || N_ct)
    k = mu_P.shape[-1]
    diff = (mu_P - mu_ct)[..., None]
    quad = (np.swapaxes(diff, -1, -2) @ S_ct_inv @ diff)[..., 0, 0]
    tr   = np.einsum("...ij,...ji->...", S_ct_inv, S_P, optimize=True)
    st_s, st_ld = np.linalg.slogdet(S_ct); sp_s, sp_ld = np.linalg.slogdet(S_P)
    st_ld = np.where(st_s > 0, st_ld, np.nan)
    sp_ld = np.where(sp_s > 0, sp_ld, np.nan)
    kl_pt = 0.5 * (tr + quad - k + (st_ld - sp_ld))

    valid = np.isfinite(kl_pt) & (w > 0.0)
    return float(np.nanmean(kl_pt[valid]) * float(lam_q)) if np.any(valid) else 0.0



def accumulate_xscale_p_up_gaugecov(
    child, parent, generators_p, lam_p: float, eps: float = 1e-6,
    use_cached_exp: bool = True, child_only: bool = True, ctx=None,
    weight_mask=None,  # NEW: pixelwise or scalar responsibility
) -> float:
    """
    Cross-scale model KL (UP): transport child -> parent frame in p-fiber.
    Computes KL(N_parent || N_child→parent) as masked mean.
    Parent grads always; child grads if child_only=False.
    Optional `weight_mask` reweights the overlap to support multi-parent membership.
    """
    import numpy as np
    if lam_p <= 0.0:
        return 0.0

    # exp(φ̃) from cache
    E_c = E_grid(ctx, child,  which="p")     # (...,K,K)
    E_p = E_grid(ctx, parent, which="p")     # (...,K,K)

    # Λ̃_up = E_p @ E_c^T
    Lambda = Lambda_up(ctx, child, parent, which="p")
    ΛT     = np.swapaxes(Lambda, -1, -2)

    # fields (model)
    mu_c = child.mu_p_field
    S_c  = sanitize_sigma(getattr(child,  "Sigma_p_field", child.sigma_p_field), eps=eps)
    mu_P = parent.mu_p_field
    S_P  = sanitize_sigma(getattr(parent, "Sigma_p_field", parent.sigma_p_field), eps=eps)

    # transport child stats to parent frame
    mu_ct = np.einsum("...ij,...j->...i", Lambda, mu_c, optimize=True)
    S_ct  = np.einsum("...ik,...kl,...jl->...ij", Lambda, S_c, ΛT, optimize=True)
    S_ct  = 0.5*(S_ct + np.swapaxes(S_ct, -1, -2))
    S_ct  = sanitize_sigma(S_ct, eps=eps)

    # inverses
    S_ct_inv = safe_inv(S_ct, eps=eps)
    S_P_inv  = safe_inv(S_P,  eps=eps)

    # mask weights × optional responsibility
    w = np.minimum(np.asarray(child.mask, float), np.asarray(parent.mask, float))
    if weight_mask is not None:
        if np.isscalar(weight_mask):
            w = w * float(weight_mask)
        else:
            w = w * np.clip(np.asarray(weight_mask, float), 0.0, 1.0)
    w1 = w[..., None]
    w4 = w[..., None, None]

    # parent μ,Σ grads
    g_mu_P = np.einsum("...ij,...j->...i", S_ct_inv, (mu_P - mu_ct), optimize=True)
    g_S_P  = 0.5*(S_ct_inv - S_P_inv)
    g_S_P  = 0.5*(g_S_P + np.swapaxes(g_S_P, -1, -2))

    if getattr(parent, "grad_mu_p", None) is None:
        parent.grad_mu_p = np.zeros_like(mu_P)
    if getattr(parent, "grad_sigma_p", None) is None:
        parent.grad_sigma_p = np.zeros_like(S_P)

    parent.grad_mu_p    += float(lam_p) * (g_mu_P * w1)
    parent.grad_sigma_p += float(lam_p) * (g_S_P  * w4)

    # backprop through Λ̃_up
    dmu   = (mu_P - mu_ct)
    dmu_t = - np.einsum("...ij,...j->...i", S_ct_inv, dmu, optimize=True)
    outer = dmu[..., None] @ np.swapaxes(dmu[..., None], -1, -2)
    dKL_dA = 0.5 * (S_P + outer - S_ct)
    dS_ct = - np.einsum("...ik,...kl,...lj->...ij", S_ct_inv, dKL_dA, S_ct_inv, optimize=True)
    dS_ct = 0.5*(dS_ct + np.swapaxes(dS_ct, -1, -2))

    term_mean = dmu_t[..., None] @ mu_c[..., None, :]
    term_cov  = 2.0 * np.einsum("...ij,...jk,...kl->...il", dS_ct, Lambda, S_c, optimize=True)
    GΛ = (term_mean + term_cov) * w4

    # parent φ̃ grads via Λ̃_up = E_p @ E_c^T  -> T_parent = GΛ @ E_c^T
    E_c_T = np.swapaxes(E_grid(ctx, child,  which="p"), -1, -2)
    T_parent = np.einsum("...ij,...jk->...ik", GΛ, E_c_T, optimize=True)
    D_p = d_exp_phi_exact(parent.phi_model, parent.generators_p, exp_phi_all=E_p)
    g_phi_tilde_p = np.stack([np.einsum("...ij,...ij->...", T_parent, D_p[a], optimize=True) for a in range(len(D_p))], axis=-1)
    g_phi_tilde_p = g_phi_tilde_p * w1

    if getattr(parent, "grad_phi_tilde", None) is None:
        parent.grad_phi_tilde = np.zeros_like(parent.phi_model)
    parent.grad_phi_tilde += float(lam_p) * g_phi_tilde_p

    # optional child grads
    if not child_only:
        T_child = - np.einsum("...ij,...jk->...ik", ΛT, GΛ, optimize=True)
        D_c = d_exp_phi_exact(child.phi_model, child.generators_p, exp_phi_all=E_c)
        g_phi_tilde_c = np.stack([np.einsum("...ij,...ij->...", T_child, D_c[a], optimize=True) for a in range(len(D_c))], axis=-1)
        g_phi_tilde_c = g_phi_tilde_c * w1

        if getattr(child, "grad_phi_tilde", None) is None:
            child.grad_phi_tilde = np.zeros_like(child.phi_model)
        child.grad_phi_tilde += float(lam_p) * g_phi_tilde_c

        g_mu_c = np.einsum("...ij,...j->...i", ΛT, dmu_t, optimize=True)
        g_S_c  = np.einsum("...ik,...kl,...jl->...ij", ΛT, dS_ct, Lambda, optimize=True)
        g_S_c  = 0.5*(g_S_c + np.swapaxes(g_S_c, -1, -2))

        if getattr(child, "grad_mu_p", None) is None:
            child.grad_mu_p = np.zeros_like(mu_c)
        if getattr(child, "grad_sigma_p", None) is None:
            child.grad_sigma_p = np.zeros_like(S_c)

        child.grad_mu_p    += float(lam_p) * (g_mu_c * w1)
        child.grad_sigma_p += float(lam_p) * (g_S_c  * w4)

    # scalar KL (masked mean): KL(N_P || N_ct)
    k = mu_P.shape[-1]
    diff = (mu_P - mu_ct)[..., None]
    quad = (np.swapaxes(diff, -1, -2) @ S_ct_inv @ diff)[..., 0, 0]
    tr   = np.einsum("...ij,...ji->...", S_ct_inv, S_P, optimize=True)
    st_s, st_ld = np.linalg.slogdet(S_ct); sp_s, sp_ld = np.linalg.slogdet(S_P)
    st_ld = np.where(st_s > 0, st_ld, np.nan)
    sp_ld = np.where(sp_s > 0, sp_ld, np.nan)
    kl_pt = 0.5 * (tr + quad - k + (st_ld - sp_ld))

    valid = np.isfinite(kl_pt) & (w > 0.0)
    return float(np.nanmean(kl_pt[valid]) * float(lam_p)) if np.any(valid) else 0.0


#====================================================================
#
#     ACCUMULATE GRADIENTS HELPERS/DEBUGS
#
#====================================================================

