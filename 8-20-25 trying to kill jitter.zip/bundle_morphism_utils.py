# -*- coding: utf-8 -*-
"""
Bundle morphism utilities (cache-hub friendly, no legacy mirrors).

- All exponentials use omega.exp_grid_cached(ctx, ...) when ctx is provided.
- No per-agent caches or print spam.
- Strict full-SPD handling for covariances.

Author: c&c
"""
from __future__ import annotations

from typing import Optional, Tuple

import numpy as np
from scipy.ndimage import gaussian_filter

import config
from numerical_utils import sanitize_sigma, safe_inv
from omega import exp_grid_cached


# =============================================================================
#                         Linear pushforwards (Gaussian)
# =============================================================================

def pushforward_gaussian(mu, sigma, morphism, eps: float = 1e-6):
    """
    Push-forward a Gaussian (μ, Σ) under a linear map M:

        μ' = M μ
        Σ' = M Σ Mᵀ

    With an optional first-order near-identity approximation when
    config.use_first_order_sigma_push is True and ||M−I||_F ≤ tau.

    Returns:
        (mu_push, sigma_push, sigma_push_inv)
    """
    mu = np.asarray(mu)
    sigma = np.asarray(sigma)

    K = int(mu.shape[-1])

    # Symmetrize/jitter Σ
    sigma = 0.5 * (sigma + np.swapaxes(sigma, -1, -2))
    sigma = sigma + eps * np.eye(sigma.shape[-1], dtype=sigma.dtype)

    # Normalize/validate M
    M = np.asarray(morphism) if morphism is not None else None
    if M is None or M.ndim < 2:
        if sigma.shape[-2:] == (K, K):
            M = np.eye(K, dtype=sigma.dtype)
        else:
            raise ValueError(
                "pushforward_gaussian: missing/degenerate morphism and cannot infer identity "
                f"for Σ shape {sigma.shape[-2:]} (expected {K}×{K})."
            )

    if M.shape[-1] != K:
        raise ValueError(f"pushforward_gaussian: morphism last dim {M.shape[-1]} != μ dim {K}")
    if sigma.shape[-2:] != (K, K):
        raise ValueError(f"pushforward_gaussian: Σ dims {sigma.shape[-2:]} incompatible with μ dim {K}")

    # ---- Optional near-identity fast path -----------------------------------
    use_fast = bool(getattr(config, "use_first_order_sigma_push", True))
    tau = float(getattr(config, "lambda_near_identity_tau", 5e-2))

    is_square = (M.shape[-2] == K)
    if use_fast and is_square:
        I = np.eye(K, dtype=M.dtype)
        A = M - I
        # Frobenius norm per batch
        A_norm = np.sqrt(np.square(A).sum(axis=(-2, -1)))
        near_identity = np.all(A_norm <= tau)

        if near_identity:
            mu_push = np.einsum("...ik,...k->...i", A, mu, optimize=True) + mu

            A_S   = np.einsum("...ik,...kl->...il", A, sigma, optimize=True)
            S_AT  = np.einsum("...ik,...jk->...ij", sigma, A, optimize=True)  # ΣAᵀ
            sigma_push = sigma + A_S + S_AT
            sigma_push = 0.5 * (sigma_push + np.swapaxes(sigma_push, -1, -2)) + \
                         eps * np.eye(K, dtype=sigma_push.dtype)

            Sigma_inv = safe_inv(sigma, eps=1e-8)
            term_left  = np.einsum("...ij,...jk->...ik", Sigma_inv, A, optimize=True)
            term_right = np.einsum("...ij,...jk->...ik", np.swapaxes(A, -1, -2), Sigma_inv, optimize=True)
            sigma_push_inv = Sigma_inv - term_left - term_right

            return mu_push.astype(mu.dtype), sigma_push.astype(sigma.dtype), sigma_push_inv.astype(sigma.dtype)

    # ---- Exact path ----------------------------------------------------------
    mu_push = np.einsum("...ik,...k->...i", M, mu, optimize=True)
    sigma_push = np.einsum("...ik,...kl,...jl->...ij", M, sigma, M, optimize=True)
    sigma_push = 0.5 * (sigma_push + np.swapaxes(sigma_push, -1, -2)) + \
                 eps * np.eye(sigma_push.shape[-1], dtype=sigma_push.dtype)
    sigma_push_inv = safe_inv(sigma_push, eps=1e-8)
    return mu_push.astype(mu.dtype), sigma_push.astype(sigma.dtype), sigma_push_inv.astype(sigma.dtype)


def safe_batch_apply_morphism_nat(mu, sigma, morphism, eps: float = 1e-8):
    """
    Apply morphism Φ to Gaussian parameters (μ, Σ):

        μ'     = Φ μ
        Σ'     = Φ Σ Φᵀ

    Args:
        mu       : (..., K_in)
        sigma    : (..., K_in, K_in)  [full SPD]
        morphism : (..., K_out, K_in)

    Returns:
        (mu_out, sigma_out) with symmetrized/sanitized Σ'
    """
    mu = np.asarray(mu)
    sigma = np.asarray(sigma)
    morphism = np.asarray(morphism)

    K_in_mu     = mu.shape[-1]
    K_in_sigma1 = sigma.shape[-2]
    K_in_sigma2 = sigma.shape[-1]
    K_in_phi    = morphism.shape[-1]

    if not (K_in_mu == K_in_sigma1 == K_in_sigma2 == K_in_phi):
        raise ValueError(
            f"[safe_batch_apply_morphism_nat] Input dimension mismatch:\n"
            f"  mu[-1]={K_in_mu}, Σ[-2:]=({K_in_sigma1},{K_in_sigma2}), Φ[-1]={K_in_phi}"
        )

    mu_out    = np.einsum("...ij,...j->...i", morphism, mu, optimize=True)
    sigma_out = np.einsum("...ik,...kl,...jl->...ij", morphism, sigma, morphism, optimize=True)

    sigma_out = 0.5 * (sigma_out + np.swapaxes(sigma_out, -1, -2))
    sigma_out = sanitize_sigma(sigma_out, eps=eps)

    return mu_out, sigma_out


# =============================================================================
#                         Direct (gauge-covariant) morphisms
# =============================================================================

def compute_direct_morphisms(
    *,
    phi: np.ndarray,
    phi_model: np.ndarray,
    generators_q: np.ndarray,
    generators_p: np.ndarray,
    Phi_0: np.ndarray,
    Phi_tilde_0: np.ndarray,
    ctx: Optional[object] = None,
    group_name: Optional[str] = None,
):
    """
    Build rectangular morphisms with gauge transport (ctx-aware):

        Φ       = exp(φ̃) · Φ₀ · exp(φ)^T      (SO(3): ^T = inverse)
        Φ̃      = exp(φ)  · Φ̃₀ · exp(φ̃)^T

    Accepts Φ₀/Φ̃₀ as 2D (Kx,K) or field-shaped (H,W,Kx,K).
    """
    group = (group_name or getattr(config, "group_name", "so3")).lower()
    so3_orth = bool(getattr(config, "so3_irreps_are_orthogonal", True)) and group == "so3"

    phi      = np.asarray(phi,       np.float32)
    phi_model= np.asarray(phi_model, np.float32)

    Eq = exp_grid_cached(ctx, phi,        generators_q, group=group, sign=+1).astype(np.float32, copy=False)
    Ep = exp_grid_cached(ctx, phi_model,  generators_p, group=group, sign=+1).astype(np.float32, copy=False)

    if so3_orth:
        Eq_invT = np.swapaxes(Eq, -1, -2)
        Ep_invT = np.swapaxes(Ep, -1, -2)
    else:
        Eq_invT = exp_grid_cached(ctx, phi,        generators_q, group=group, sign=-1).astype(np.float32, copy=False)
        Ep_invT = exp_grid_cached(ctx, phi_model,  generators_p, group=group, sign=-1).astype(np.float32, copy=False)

    Kq = int(Eq.shape[-1]); Kp = int(Ep.shape[-1])

    Phi_0       = np.asarray(Phi_0,       np.float32)
    Phi_tilde_0 = np.asarray(Phi_tilde_0, np.float32)

    if Phi_0.shape[-2:] != (Kp, Kq):
        Phi_0 = np.eye(Kp, Kq, dtype=np.float32)
    if Phi_tilde_0.shape[-2:] != (Kq, Kp):
        Phi_tilde_0 = np.eye(Kq, Kp, dtype=np.float32)

    if Phi_0.ndim == 2:
        Phi_0 = np.broadcast_to(Phi_0, Ep.shape[:-2] + (Kp, Kq))
    if Phi_tilde_0.ndim == 2:
        Phi_tilde_0 = np.broadcast_to(Phi_tilde_0, Eq.shape[:-2] + (Kq, Kp))

    Phi       = np.einsum("...ik,...kj,...jl->...il", Ep, Phi_0,       Eq_invT, optimize=True).astype(np.float32, copy=False)
    Phi_tilde = np.einsum("...ik,...kj,...jl->...il", Eq, Phi_tilde_0, Ep_invT, optimize=True).astype(np.float32, copy=False)

    return Phi, Phi_tilde


def gauge_covariant_transform_phi(
    phi_p: np.ndarray,
    phi_q: np.ndarray,
    Phi0: np.ndarray,
    G_q: np.ndarray,
    G_p: np.ndarray,
    *,
    ctx: Optional[object] = None,
    group_name: str = "so3",
) -> np.ndarray:
    """
    Φ(x) = exp(φ_p(x)) · Φ₀(x) · exp(−φ_q(x))

    - Uses CacheHub via exp_grid_cached(ctx, ...) to reuse exp grids.
    - Accepts Φ₀ as (Kp,Kq) or field-shaped (...,Kp,Kq) and broadcasts as needed.
    - For SO(3) orthogonal irreps, uses transpose for the inverse (more stable).
    """
    phi_p = np.asarray(phi_p, np.float32)
    phi_q = np.asarray(phi_q, np.float32)

    E_p = exp_grid_cached(ctx, phi_p, G_p, group=group_name, sign=+1)  # (..., Kp, Kp)
    E_q = exp_grid_cached(ctx, phi_q, G_q, group=group_name, sign=+1)  # (..., Kq, Kq)

    Kp = E_p.shape[-1]
    Kq = E_q.shape[-1]

    Phi0 = np.asarray(Phi0, np.float32)
    if Phi0.shape[-2:] != (Kp, Kq):
        Phi0 = np.eye(Kp, Kq, dtype=E_p.dtype)
    if Phi0.ndim == 2:
        lead = np.broadcast_shapes(E_p.shape[:-2], E_q.shape[:-2])
        Phi0 = np.broadcast_to(Phi0, (*lead, Kp, Kq))

    if str(group_name).lower() == "so3":
        E_q_inv = np.swapaxes(E_q, -1, -2)
    else:
        E_q_inv = exp_grid_cached(ctx, phi_q, G_q, group=group_name, sign=-1)

    Phi = np.einsum("...ik,...kj,...jl->...il", E_p, Phi0, E_q_inv, optimize=True)
    return Phi.astype(np.float32, copy=False)


# =============================================================================
#                             Init / Recompute on agent
# =============================================================================

def init_parent_morphisms(P, generators_q, generators_p, *, ctx: Optional[object] = None):
    """
    Ensure a newly spawned parent has base morphisms and computed bundle morphisms.

    - Sets identity Φ₀, Φ̃₀ with correct shapes (Kp×Kq and Kq×Kp).
    - Stores generators on the parent (for later recomputes).
    - Computes bundle_morphism_q_to_p and bundle_morphism_p_to_q once (ctx-aware).
    """
    # infer dims from parent's fields
    try:
        Kq = int(np.asarray(P.mu_q_field).shape[-1])
        Kp = int(np.asarray(P.mu_p_field).shape[-1])
    except Exception:
        return
    if Kq <= 0 or Kp <= 0:
        return

    H, W = np.asarray(P.mu_q_field).shape[:2]
    dtype = getattr(P.mu_q_field, "dtype", np.float32)

    # algebra dims (fallbacks if generators not set yet)
    d_q = int(np.asarray(generators_q).shape[0]) if generators_q is not None else int(np.asarray(getattr(P, "phi", np.zeros(3))).shape[-1])
    d_p = int(np.asarray(generators_p).shape[0]) if generators_p is not None else int(np.asarray(getattr(P, "phi_model", np.zeros(3))).shape[-1])

    # base morphisms (identities with correct shapes)
    if getattr(P, "Phi_0", None) is None or np.asarray(P.Phi_0).shape[-2:] != (Kp, Kq):
        P.Phi_0 = np.eye(Kp, Kq, dtype=dtype)
    if getattr(P, "Phi_tilde_0", None) is None or np.asarray(P.Phi_tilde_0).shape[-2:] != (Kq, Kp):
        P.Phi_tilde_0 = np.eye(Kq, Kp, dtype=dtype)

    # stash generators (don’t overwrite if already present)
    if getattr(P, "generators_q", None) is None:
        P.generators_q = generators_q
    if getattr(P, "generators_p", None) is None:
        P.generators_p = generators_p

    # ensure phi fields exist (H,W,d)
    if getattr(P, "phi", None) is None or np.asarray(P.phi).ndim < 3:
        P.phi = np.zeros((H, W, d_q), dtype=dtype)
    if getattr(P, "phi_model", None) is None or np.asarray(P.phi_model).ndim < 3:
        P.phi_model = np.zeros((H, W, d_p), dtype=dtype)

    # compute initial transported morphisms (ctx-aware)
    try:
        Phi, Phit = compute_direct_morphisms(
            phi=P.phi, phi_model=P.phi_model,
            generators_q=P.generators_q, generators_p=P.generators_p,
            Phi_0=P.Phi_0, Phi_tilde_0=P.Phi_tilde_0, ctx=ctx
        )
        P.bundle_morphism_q_to_p = np.asarray(Phi,  dtype=np.float32)
        P.bundle_morphism_p_to_q = np.asarray(Phit, dtype=np.float32)
        if hasattr(P, "morphisms_dirty"):
            P.morphisms_dirty = False
    except Exception:
        # identity-like broadcast fallback
        P.bundle_morphism_q_to_p = np.broadcast_to(P.Phi_0,       (H, W, Kp, Kq)).astype(np.float32).copy()
        P.bundle_morphism_p_to_q = np.broadcast_to(P.Phi_tilde_0, (H, W, Kq, Kp)).astype(np.float32).copy()


def recompute_agent_morphisms(
    agent,
    *,
    generators_q: Optional[np.ndarray] = None,
    generators_p: Optional[np.ndarray] = None,
    allow_make_bases: bool = True,
    ctx: Optional[object] = None,
) -> None:
    """
    Rebuild agent.bundle_morphism_q_to_p and agent.bundle_morphism_p_to_q using gauge transport.
    Uses CacheHub if ctx is provided.
    """
    # 0) Ensure generators
    if hasattr(agent, "ensure_generators"):
        agent.ensure_generators(generators_q, generators_p)
    Gq = getattr(agent, "generators_q", generators_q)
    Gp = getattr(agent, "generators_p", generators_p)
    if Gq is None or Gp is None:
        raise ValueError("recompute_agent_morphisms: generators_q/p required or must be present on agent")

    # 1) Fiber sizes
    try:
        Kq = int(agent.mu_q_field.shape[-1])
        Kp = int(agent.mu_p_field.shape[-1])
    except Exception as e:
        raise ValueError("recompute_agent_morphisms: agent.mu_q_field / mu_p_field missing or malformed") from e

    # 2) Base morphisms
    if getattr(agent, "Phi_0", None) is None:
        if not allow_make_bases:
            raise ValueError("recompute_agent_morphisms: Phi_0 missing and allow_make_bases=False")
        agent.Phi_0 = np.eye(Kp, Kq, dtype=agent.mu_q_field.dtype)
    if getattr(agent, "Phi_tilde_0", None) is None:
        if not allow_make_bases:
            raise ValueError("recompute_agent_morphisms: Phi_tilde_0 missing and allow_make_bases=False")
        agent.Phi_tilde_0 = np.eye(Kq, Kp, dtype=agent.mu_q_field.dtype)

    # 3) Build Φ / Φ̃
    Phi, Phi_tilde = compute_direct_morphisms(
        phi=agent.phi,
        phi_model=agent.phi_model,
        generators_q=Gq,
        generators_p=Gp,
        Phi_0=agent.Phi_0,
        Phi_tilde_0=agent.Phi_tilde_0,
        ctx=ctx,
    )

    # 4) Store & mark clean
    agent.bundle_morphism_q_to_p = Phi.astype(np.float32, copy=False)
    agent.bundle_morphism_p_to_q = Phi_tilde.astype(np.float32, copy=False)
    if hasattr(agent, "morphisms_dirty"):
        agent.morphisms_dirty = False


def mark_morphism_dirty(agent) -> None:
    """
    Invalidate an agent's Φ/Φ̃ in a safe, minimal way.
    """
    if hasattr(agent, "mark_morphism_dirty") and callable(agent.mark_morphism_dirty):
        agent.mark_morphism_dirty()
        return
    setattr(agent, "morphisms_dirty", True)
    agent.bundle_morphism_q_to_p = None
    agent.bundle_morphism_p_to_q = None


def have_parent_morphisms(P) -> bool:
    """
    True iff base morphisms exist with correct rectangular shapes, and generators present:

        Phi_0       : (Kp, Kq)
        Phi_tilde_0 : (Kq, Kp)
    """
    if not hasattr(P, "mu_q_field") or not hasattr(P, "mu_p_field"):
        return False
    Kq = int(getattr(P.mu_q_field, "shape", (0,))[-1])
    Kp = int(getattr(P.mu_p_field, "shape", (0,))[-1])
    if Kq <= 0 or Kp <= 0:
        return False

    ok_gen = hasattr(P, "generators_q") and hasattr(P, "generators_p")

    A = getattr(P, "Phi_0", None)
    B = getattr(P, "Phi_tilde_0", None)
    ok_A = isinstance(A, np.ndarray) and A.ndim == 2 and A.shape == (Kp, Kq)
    ok_B = isinstance(B, np.ndarray) and B.ndim == 2 and B.shape == (Kq, Kp)

    return bool(ok_gen and ok_A and ok_B)


# =============================================================================
#                            Morphism field generators
# =============================================================================

def generate_smooth_morphism_fieldID(  # kept for backward compat
    H: int,
    W: int,
    K_src: int,
    K_tgt: int,
    sigma: float = getattr(config, "gaussian_blur_range_morphism", 1.5),
    low_rank=None,
    seed=None,
    normalize=False,
    mask=None,
) -> np.ndarray:
    """
    Identity-like morphism field on shared rank R = min(K_src, K_tgt).
    """
    R = min(K_src, K_tgt)
    field = np.zeros((H, W, K_tgt, K_src), dtype=np.float32)
    ones = np.ones((H, W), dtype=np.float32)
    coeff = gaussian_filter(ones, sigma=1.5, mode="wrap")
    for i in range(R):
        field[..., i, i] = coeff
    return field


def generate_smooth_morphism_field(
    H: int,
    W: int,
    K_src: int,
    K_tgt: int,
    sigma: float = getattr(config, "gaussian_blur_range_morphism", 1.5),
    low_rank: Optional[int] = None,
    seed: Optional[int] = None,
    normalize: bool = False,
    mask: Optional[np.ndarray] = None,
) -> np.ndarray:
    """
    Generate a smooth spatial field of K_tgt × K_src morphisms,
    optionally low-rank and softly blended to identity outside support.
    """
    rng = np.random.default_rng(seed)
    rank = low_rank if low_rank is not None else min(K_src, K_tgt)

    field = np.zeros((H, W, K_tgt, K_src), dtype=np.float32)
    for r in range(rank):
        basis = rng.standard_normal((K_tgt, K_src)).astype(np.float32)
        coeff = rng.standard_normal((H, W)).astype(np.float32)
        coeff = gaussian_filter(coeff, sigma=sigma, mode="wrap")
        field += coeff[..., None, None] * basis[None, None, :, :]

    if normalize:
        eps = 1e-8
        norm = np.linalg.norm(field, axis=(-2, -1), keepdims=True)
        field = field / np.where(norm > eps, norm, eps)

    if mask is not None:
        soft = gaussian_filter(mask.astype(np.float32), sigma=1.0)
        soft = np.clip(soft, 0.0, 1.0)[..., None, None]
        I = np.eye(K_tgt, K_src, dtype=np.float32)[None, None, :, :]
        field = soft * field + (1.0 - soft) * I

    return field


def clip_operator_norm(field: np.ndarray, max_norm: float = 1.0, eps: float = 1e-8) -> np.ndarray:
    """
    Enforce operator norm ≤ max_norm for each Φ(x) in (H,W,Kp,Kq).
    """
    H, W, Kp, Kq = field.shape
    out = np.empty_like(field)
    for i in range(H):
        for j in range(W):
            Phi = field[i, j]
            u, s, vh = np.linalg.svd(Phi, full_matrices=False)
            s_clipped = np.clip(s, 0, max_norm)
            out[i, j] = (u @ np.diag(s_clipped) @ vh).astype(field.dtype)
    return out


def initialize_morphism_pair(
    domain_size: Tuple[int, int],
    K_q: int,
    K_p: int,
    rng: np.random.Generator,
    morphism_type: str = "identity",
    mask: Optional[np.ndarray] = None,
    config_tag: str = "",
    phi_q_field: Optional[np.ndarray] = None,
    phi_p_field: Optional[np.ndarray] = None,
    G_q: Optional[np.ndarray] = None,
    G_p: Optional[np.ndarray] = None,
) -> Tuple[np.ndarray, np.ndarray]:
    """
    Initialize bundle morphisms Φ (q→p) and Φ̃ (p→q).

    If morphism_type == "gauge_covariant", applies:
        Φ(x) = exp(φ_p(x)) · Φ₀(x) · exp(−φ_q(x))
    """
    H, W = domain_size

    if morphism_type == "identity":
        if K_q != K_p:
            raise ValueError(f"Cannot use identity morphism with mismatched K_q={K_q} and K_p={K_p}")
        eye = np.eye(K_q, dtype=np.float32)
        phi_q_to_p = np.broadcast_to(eye, (H, W, K_q, K_q)).copy()
        phi_p_to_q = np.broadcast_to(eye, (H, W, K_q, K_q)).copy()
        if mask is not None:
            soft = gaussian_filter(mask.astype(np.float32), sigma=1.0)
            soft = np.clip(soft, 0.0, 1.0)[..., None, None]
            phi_q_to_p = soft * phi_q_to_p + (1.0 - soft) * phi_q_to_p
            phi_p_to_q = soft * phi_p_to_q + (1.0 - soft) * phi_p_to_q
        return phi_q_to_p, phi_p_to_q

    if morphism_type == "gauge_covariant":
        assert phi_q_field is not None and phi_p_field is not None, "φ_q and φ_p fields required"
        assert G_q is not None and G_p is not None, "Generators G_q and G_p required"

        sigma = getattr(config, f"morphism_sigma{config_tag}", 1.5)
        rank  = getattr(config, f"morphism_rank{config_tag}", min(K_q, K_p))
        seed  = rng.integers(0, 1e9)

        Phi_0_q_to_p = generate_smooth_morphism_field(
            H, W, K_src=K_q, K_tgt=K_p,
            sigma=sigma, low_rank=rank,
            normalize=False, mask=mask, seed=seed
        )
        Phi_0_p_to_q = generate_smooth_morphism_field(
            H, W, K_src=K_p, K_tgt=K_q,
            sigma=sigma, low_rank=rank,
            normalize=False, mask=mask, seed=seed + 1
        )

        phi_q_to_p = gauge_covariant_transform_phi(
            phi_p_field, phi_q_field, Phi_0_q_to_p, G_q=G_q, G_p=G_p
        )
        phi_p_to_q = gauge_covariant_transform_phi(
            phi_q_field, phi_p_field, Phi_0_p_to_q, G_q=G_p, G_p=G_q
        )

        if mask is not None:
            soft = gaussian_filter(mask.astype(np.float32), sigma=1.0)
            soft = np.clip(soft, 0.0, 1.0)[..., None, None]
            I_qp = np.eye(K_p, K_q, dtype=np.float32)[None, None, :, :]
            I_pq = np.eye(K_q, K_p, dtype=np.float32)[None, None, :, :]
            phi_q_to_p = soft * phi_q_to_p + (1.0 - soft) * I_qp
            phi_p_to_q = soft * phi_p_to_q + (1.0 - soft) * I_pq

        return phi_q_to_p, phi_p_to_q

    # Generic smooth/low-rank morphism
    sigma     = getattr(config, f"morphism_sigma{config_tag}", 1.5)
    rank      = getattr(config, f"morphism_rank{config_tag}", min(K_q, K_p))
    normalize = getattr(config, f"morphism_normalize{config_tag}", True)
    seed      = rng.integers(0, 1e9)

    phi_q_to_p = generate_smooth_morphism_field(
        H, W, K_src=K_q, K_tgt=K_p,
        sigma=sigma, low_rank=rank,
        normalize=False, mask=mask, seed=seed
    )
    phi_p_to_q = np.swapaxes(phi_q_to_p, -1, -2)

    if normalize:
        phi_q_to_p = clip_operator_norm(phi_q_to_p, max_norm=1.0)
        phi_p_to_q = clip_operator_norm(phi_p_to_q, max_norm=1.0)

    return phi_q_to_p, phi_p_to_q


def generate_morphism_pair(
    H: int,
    W: int,
    K_q: int,
    K_p: int,
    rank: Optional[int] = None,
    sigma: float = 1.5,
    seed: Optional[int] = None,
    mask: Optional[np.ndarray] = None,
    s_floor: float = 0.05,
    s_scale: float = 0.25,
    dtype=np.float32,
):
    """
    Build a paired rectangular morphism field (Φ0, Φ̃0) with shared low-rank frames:

        Φ0(x)   = U S(x) Vᵀ   ∈ ℝ^{K_p × K_q}
        Φ̃0(x)  = V S(x) Uᵀ   ∈ ℝ^{K_q × K_p}

    U ∈ ℝ^{K_p×r}, V ∈ ℝ^{K_q×r} orthonormal; S(x) diagonal, positive, smooth.
    """
    rng = np.random.default_rng(seed)
    r = rank if rank is not None else min(K_q, K_p)

    U0, _ = np.linalg.qr(rng.standard_normal((K_p, r)))
    V0, _ = np.linalg.qr(rng.standard_normal((K_q, r)))

    S_fields = []
    for _ in range(r):
        f = rng.standard_normal((H, W)).astype(dtype)
        f = gaussian_filter(f, sigma=sigma, mode="wrap")
        f = np.abs(f) * s_scale + s_floor  # positive, bounded away from 0
        if mask is not None:
            f = f * mask
        S_fields.append(f)
    S_stack = np.stack(S_fields, axis=-1)  # (H, W, r)

    S_diag = np.zeros((H, W, r, r), dtype=dtype)
    idx = np.arange(r)
    S_diag[..., idx, idx] = S_stack

    Phi_0 = np.einsum("pr,hwrs,sq->hwpq", U0.astype(dtype), S_diag, V0.T.astype(dtype))
    Phi_tilde_0 = np.einsum("qr,hwrs,sp->hwqp", V0.astype(dtype), S_diag, U0.T.astype(dtype))
    return Phi_0, Phi_tilde_0
