from __future__ import annotations

"""
Created on Tue Aug 12 20:15:47 2025

@author: chris and christine
"""
import time
from joblib import Parallel, delayed
import numpy as np
import config
from omega import d_exp_phi_exact, d_exp_phi_tilde_exact

from numerical_utils import safe_omega_inv, masked_stat        
from bundle_morphism_utils import mark_morphism_dirty

from update_terms_phi import ( 
    accumulate_phi_morphism_self_feedback, accumulate_phi_alignment_gradient,
    grad_feedback_phi_direct, grad_feedback_phi_tilde_direct, grad_self_phi_direct,
    grad_self_phi_tilde_direct)

from update_terms_mu_sigma import accumulate_mu_sigma_gradient
from preprocess_utils import zero_all_gradients
from update_crossscale_terms import accumulate_crossscale_gradients
from transport_cache import warm_E, E_grid
from numerical_utils import sanitize_sigma



def _coerce_mask_shape(mask_src, shape_dst):
    """
    Make mask_src match shape_dst (H,W), using:
      1) exact reshape if sizes match,
      2) nearest-neighbor resample if not.
    Returns float32 mask in [0,1].
    """
    import numpy as np
    m = np.asarray(mask_src, dtype=np.float32)
    Ht, Wt = shape_dst
    if m.shape == (Ht, Wt):
        return m

    # reshape if number of elements matches
    if m.size == Ht * Wt:
        return m.reshape(Ht, Wt)

    # nearest neighbor resample (no deps)
    Hs, Ws = m.shape[:2]
    if Hs <= 0 or Ws <= 0:
        return np.zeros((Ht, Wt), np.float32)
    yi = (np.arange(Ht) * (Hs / float(Ht))).astype(np.int64)
    xi = (np.arange(Wt) * (Ws / float(Wt))).astype(np.int64)
    yi = np.clip(yi, 0, Hs - 1)
    xi = np.clip(xi, 0, Ws - 1)
    return m[yi[:, None], xi[None, :]].astype(np.float32)




def compute_all_gradients(agent_i, agents, all_agents, generators_q, generators_p, params, runtime_ctx=None):
    """
    Role-aware gradient accumulator:
      - level 0: unchanged behavior (child intra-scale + cross-scale)
      - level 1: does intra-parent alignment + morphism + cross-scale (upward)

    Notes:
      - If runtime_ctx is provided, it's inserted into params["runtime_ctx"] so
        downstream functions can route Ω/exp/Fisher through ctx.cache.
    """
    

    # --- thread ctx into params (non-destructive) ---------------------------
    params = {} if params is None else dict(params)
    if runtime_ctx is not None:
        params["runtime_ctx"] = runtime_ctx  # downstream can opt-in to hub via params
    ctx = params.get("runtime_ctx", None)

    level = getattr(agent_i, "level", 0)
    is_parent = (level >= 1)

    # toggles (all default True)
    enable_intrascale_belief  = params.get("enable_intrascale_belief",  True)
    enable_intrascale_model   = params.get("enable_intrascale_model",   True)
    enable_morphism_terms     = params.get("enable_morphism_terms",     True)
    enable_crossscale         = params.get("enable_crossscale",         True)
    enable_parent_intrascale  = params.get("enable_parent_intrascale",  True)  # parents vs parents
    enable_parent_morphism    = params.get("enable_parent_morphism",    True)

    # parent update ramp/freeze can be handled in the optimizer phase; here we just build grads.

    zero_all_gradients(agent_i)
    timings = {}

    # ─── Belief μ, Σ (intra-scale) ───
    if enable_intrascale_belief and (not is_parent or enable_parent_intrascale):
        t0 = time.perf_counter()
        accumulate_mu_sigma_gradient(agent_i, agents, params, mode="belief")
        timings["mu_sigma_belief"] = time.perf_counter() - t0

    # ─── Model μ, Σ (intra-scale) ───
    if enable_intrascale_model and (not is_parent or enable_parent_intrascale):
        t0 = time.perf_counter()
        accumulate_mu_sigma_gradient(agent_i, agents, params, mode="model")
        timings["mu_sigma_model"] = time.perf_counter() - t0

    # Choose which neighbor list to use:
    same_level_neighbors = getattr(agent_i, "neighbors", [])

    # Pre-warm exp grids for child + its neighbors (cache is per-step/idempotent)
    if ctx is not None and same_level_neighbors:
        try:
            nb_agents = [agents[nb["id"]] for nb in same_level_neighbors if nb and "id" in nb]
            warm_E(ctx, [agent_i] + nb_agents, whiches=("q", "p"))
        except Exception:
            pass

    # ─── Belief alignment: φᵢ vs same-level neighbors ───
    if enable_intrascale_belief and (not is_parent or enable_parent_intrascale) and same_level_neighbors:
        t0 = time.perf_counter()

        Q_all_belief_i = d_exp_phi_exact(agent_i.phi, generators_q)

        for nb in same_level_neighbors:
            agent_j = agents[nb["id"]]

            # Build exp(-φ_j) from central cache (no per-agent fields)
            if ctx is not None:
                Ej = E_grid(ctx, agent_j, which="q")
                exp_neg_phi_j = safe_omega_inv(Ej, eps=getattr(config, "eps", 1e-6), debug=False)
            else:
                # Fallback if no ctx (uncached, local compute)
                from omega import exp_lie_algebra_irrep
                Ej = exp_lie_algebra_irrep(agent_j.phi, generators_q)
                exp_neg_phi_j = safe_omega_inv(Ej, eps=getattr(config, "eps", 1e-6), debug=False)

            # Pass through params (now contains "runtime_ctx" if provided)
            accumulate_phi_alignment_gradient(
                agent_i, agent_j, generators_q, params,
                field="phi",
                beta_key="beta",
                omega_cache_key=None,               # legacy cache key not used; ctx handles caching
                mu_key="mu_q_field",
                sigma_key="sigma_q_field",
                fisher_inv_key="inverse_fisher_phi",
                grad_key="grad_phi",
                Q_all_i=Q_all_belief_i,
                exp_neg_phi_j=exp_neg_phi_j,
                agents=agents,
            )

        timings["phi_alignment"] = time.perf_counter() - t0

    # ─── Model alignment: φ̃ᵢ vs same-level neighbors ───
    if enable_intrascale_model and (not is_parent or enable_parent_intrascale) and same_level_neighbors:
        t0 = time.perf_counter()

        Q_all_model_i = d_exp_phi_tilde_exact(agent_i.phi_model, generators_p)

        for nb in same_level_neighbors:
            agent_j = agents[nb["id"]]

            # Build exp(-φ̃_j) from central cache (no per-agent fields)
            if ctx is not None:
                Ej = E_grid(ctx, agent_j, which="p")
                exp_neg_phi_j = safe_omega_inv(Ej, eps=getattr(config, "eps", 1e-6), debug=False)
            else:
                from omega import exp_lie_algebra_irrep
                Ej = exp_lie_algebra_irrep(agent_j.phi_model, generators_p)
                exp_neg_phi_j = safe_omega_inv(Ej, eps=getattr(config, "eps", 1e-6), debug=False)

            accumulate_phi_alignment_gradient(
                agent_i, agent_j, generators_p, params,
                field="phi_model",
                beta_key="beta_model",
                omega_cache_key=None,               # legacy cache key not used; ctx handles caching
                mu_key="mu_p_field",
                sigma_key="sigma_p_field",
                fisher_inv_key="inverse_fisher_phi_model",
                grad_key="grad_phi_tilde",
                Q_all_i=Q_all_model_i,
                exp_neg_phi_j=exp_neg_phi_j,
                agents=agents,
            )

        timings["phi_tilde_alignment"] = time.perf_counter() - t0

    # ─── Cross-scale (child pass writes UP; parent pass runs child_only) ───
    if enable_crossscale:
        xparams = dict(params)
        xparams["xscale_child_only"] = (True if is_parent else False)
        accumulate_crossscale_gradients(agent_i, all_agents, generators_q, generators_p, xparams)

    # ─── Morphism self + feedback terms (belief/model) ───
    if enable_morphism_terms and (not is_parent or enable_parent_morphism):
        t0 = time.perf_counter()
        accumulate_phi_morphism_self_feedback(
            agent_i, generators_p, generators_q, params,
            field="phi",
            fisher_inv_key="inverse_fisher_phi",
            grad_key="grad_phi",
            phi_self_func=grad_self_phi_direct,
            phi_feedback_func=grad_feedback_phi_direct,
        )
        timings["phi_morphism"] = time.perf_counter() - t0

        t0 = time.perf_counter()
        accumulate_phi_morphism_self_feedback(
            agent_i, generators_p, generators_q, params,
            field="phi_model",
            fisher_inv_key="inverse_fisher_phi_model",
            grad_key="grad_phi_tilde",
            phi_self_func=grad_self_phi_tilde_direct,
            phi_feedback_func=grad_feedback_phi_tilde_direct,
        )
        timings["phi_tilde_morphism"] = time.perf_counter() - t0

    if getattr(config, "debug_grad_timing", False):
        print(f"\n[GRAD TIMINGS] Agent {agent_i.id} (lvl={level})")
        for k, v in timings.items():
            print(f"  {k:22s} : {v*1e3:7.2f} ms")

    return (
        (agent_i.grad_mu_q, agent_i.grad_sigma_q),
        (agent_i.grad_mu_p, agent_i.grad_sigma_p),
        agent_i.grad_phi,
        agent_i.grad_phi_tilde,
        agent_i.grad_Phi,
        agent_i.grad_Phi_tilde,
    )











from transport_cache import invalidate_agent   # central cache invalidation


def _apply_children(agents, grads, params, frozen_levels, frozen_phi_levels, Gq, Gp, n_jobs, *, ctx=None):
    tau_mu_belief    = params.get("tau_mu_belief",    config.tau_mu_belief)
    tau_sigma_belief = params.get("tau_sigma_belief", config.tau_sigma_belief)
    tau_mu_model     = params.get("tau_mu_model",     config.tau_mu_model)
    tau_sigma_model  = params.get("tau_sigma_model",  config.tau_sigma_model)

    (q_updates, p_updates, phi_grads, phi_m_grads, _, _) = grads
    masks = [A.mask for A in agents]

    def _one(i):
        A = agents[i]
        mask = masks[i]
        dmu_q, dsg_q = q_updates[i]
        dmu_p, dsg_p = p_updates[i]

        if dmu_q is None: dmu_q = np.zeros_like(A.mu_q_field)
        if dsg_q is None: dsg_q = np.zeros_like(A.sigma_q_field)
        if dmu_p is None: dmu_p = np.zeros_like(A.mu_p_field)
        if dsg_p is None: dsg_p = np.zeros_like(A.sigma_p_field)

        mask_mu    = mask[..., None]
        mask_sigma = mask[..., None, None]

        # --- field updates (μ, Σ) ---
        if getattr(A, "level", 0) not in frozen_levels:
            A.mu_q_field = A.mu_q_field + tau_mu_belief * dmu_q * mask_mu
            A.mu_p_field = A.mu_p_field + tau_mu_model  * dmu_p * mask_mu

            # Σ: update, symmetrize, sanitize on masked region
            Sq = A.sigma_q_field + tau_sigma_belief * dsg_q * mask_sigma
            Sp = A.sigma_p_field + tau_sigma_model  * dsg_p * mask_sigma
            A.sigma_q_field = sanitize_sigma(_safe_symmetrize(Sq), eps=getattr(config, "eps", 1e-8))
            A.sigma_p_field = sanitize_sigma(_safe_symmetrize(Sp), eps=getattr(config, "eps", 1e-8))

        # --- φ updates ---
        if getattr(A, "level", 0) not in frozen_phi_levels:
            gp  = phi_grads[i]
            gpm = phi_m_grads[i]
            gp  = np.zeros_like(A.phi)       if gp  is None else gp
            gpm = np.zeros_like(A.phi_model) if gpm is None else gpm

            apply_phi_updates(A, gp, gpm, mask, params, ctx=ctx)

        # mark Φ/Φ̃ stale
        mark_morphism_dirty(A)

    Parallel(n_jobs=n_jobs, backend="threading", batch_size="auto")(
        delayed(_one)(i) for i in range(len(agents))
    )
    


def apply_phi_updates(agent, grad_phi, grad_phi_m, mask, params, *, ctx=None):
    # capture grads for debugging/diags
    agent.grad_phi       = np.array(grad_phi,   copy=True)
    agent.grad_phi_tilde = np.array(grad_phi_m, copy=True)

    mexp = mask[..., None]

    # config pulls
    tau_phi       = params.get("tau_phi",        config.tau_phi)
    tau_phi_model = params.get("tau_phi_model",  config.tau_phi_model)
    s_eta_phi     = params.get("eta_phi_adaptive_scaling",    config.eta_phi_adaptive_scaling)
    s_eta_cond    = params.get("eta_sigma_condition_scaling", config.eta_sigma_condition_scaling)
    eta_phi_min   = params.get("eta_phi_min",                 config.eta_phi_min)
    eta_phi_m_min = params.get("eta_phi_model_min",           config.eta_phi_model_min)

    # robust, masked KL scalars (if present)
    kl_q = masked_stat(getattr(agent, "cached_alignment_kl", None), mask, default=0.0)
    kl_p = masked_stat(getattr(agent, "cached_model_alignment_kl", None), mask, default=0.0)

    # condition proxies (from preprocess)
    cond_q = getattr(agent, "_cond_proxy_q", 1.0)
    cond_p = getattr(agent, "_cond_proxy_p", 1.0)

    # EMA memory
    ema_a          = getattr(config, "eta_ema_alpha", None)
    prev_eta_phi   = getattr(agent, "_eta_phi_prev", None)
    prev_eta_phi_m = getattr(agent, "_eta_phi_m_prev", None)

    # adaptive step sizes
    eta_phi = compute_adaptive_eta(
        tau_phi, kl_q, cond_q, grad=grad_phi,
        scaling_kl=s_eta_phi, scaling_cond=s_eta_cond,
        eta_min=eta_phi_min, ema_prev=prev_eta_phi, ema_alpha=ema_a
    )
    eta_phi_m = compute_adaptive_eta(
        tau_phi_model, kl_p, cond_p, grad=grad_phi_m,
        scaling_kl=params.get("eta_phi_model_adaptive_scaling", s_eta_phi),
        scaling_cond=s_eta_cond, eta_min=eta_phi_m_min,
        ema_prev=prev_eta_phi_m, ema_alpha=ema_a
    )

    delta_phi   = np.nan_to_num(eta_phi   * grad_phi,   nan=0.0, posinf=0.0, neginf=0.0)
    delta_phi_m = np.nan_to_num(eta_phi_m * grad_phi_m, nan=0.0, posinf=0.0, neginf=0.0)

    # IMPORTANT: avoid in-place writes (preserve array identity semantics)
    agent.phi       = (agent.phi       - delta_phi   * mexp).astype(np.float32, copy=False)
    agent.phi_model = (agent.phi_model + delta_phi_m * mexp).astype(np.float32, copy=False)

    # per-agent transport invalidation (exp/omega/lambda) after φ changes
    if ctx is not None:
        invalidate_agent(ctx, agent)

    # stash adaptive etas
    agent._eta_phi_prev   = eta_phi
    agent._eta_phi_m_prev = eta_phi_m





def _apply_parent_updates(parents, step, params, *, ctx=None):
    """
    Apply parent μ/Σ and φ/φ̃ updates with ramping; invalidate central caches
    when gauge fields change; and mark objects dirty for downstream rebuilds.
    """
    freeze = int(params.get("parent_freeze_steps", 0))
    ramp   = max(1, int(params.get("parent_ramp_steps", 1)))
    if step < freeze:
        return
    s = min(1.0, (step - freeze + 1) / ramp)

    tau_mu_belief    = params.get("tau_mu_belief",    0.0)
    tau_sigma_belief = params.get("tau_sigma_belief", 0.0)
    tau_mu_model     = params.get("tau_mu_model",     0.0)
    tau_sigma_model  = params.get("tau_sigma_model",  0.0)

    for P in parents:
        pmask = np.asarray(getattr(P, "mask", 0.0), dtype=np.float32)
        mask_mu    = pmask[..., None]
        mask_sigma = pmask[..., None, None]

        # q-bundle
        if getattr(P, "grad_mu_q", None) is not None:
            P.mu_q_field   = P.mu_q_field   + s * tau_mu_belief * P.grad_mu_q * mask_mu
        if getattr(P, "grad_sigma_q", None) is not None:
            P.sigma_q_field = P.sigma_q_field + s * tau_sigma_belief * P.grad_sigma_q * mask_sigma

        # p-bundle
        if getattr(P, "grad_mu_p", None) is not None:
            P.mu_p_field   = P.mu_p_field   + s * tau_mu_model * P.grad_mu_p * mask_mu
        if getattr(P, "grad_sigma_p", None) is not None:
            P.sigma_p_field = P.sigma_p_field + s * tau_sigma_model * P.grad_sigma_p * mask_sigma

        # φ / φ̃ updates — apply and let apply_phi_updates handle per-agent invalidation
        if getattr(P, "grad_phi", None) is not None or getattr(P, "grad_phi_tilde", None) is not None:
            apply_phi_updates(
                P,
                getattr(P, "grad_phi", None),
                getattr(P, "grad_phi_tilde", None),
                pmask,
                params,
                ctx=ctx,  # IMPORTANT: triggers invalidate_agent(ctx, P) inside
            )

            # mark dirty so downstream phases rebuild Λ / Φ
            try:
                from update_rules_utils import mark_dirty
                if ctx is not None:
                    mark_dirty(ctx, P, kl=True)
            except Exception:
                setattr(P, "morphisms_dirty", True)










def _parent_intrascale_grad_pass(agents, parents, Gq, Gp, params, accum_into=True, *, ctx=None):
    if not parents:
        return
    params_par = dict(params)
    params_par["enable_crossscale"] = False  # keep x-scale grads from child pass intact
    if ctx is not None:
        params_par["runtime_ctx"] = ctx

    all_agents_par = agents + parents
    parents_by_id = {int(getattr(p, "id", i)): p for i, p in enumerate(parents)}

    def _safe_add(a, b):
        if a is None: return b
        if b is None: return a
        return a + b

    results = Parallel(n_jobs=config.n_jobs, backend="threading", batch_size="auto")(
        delayed(compute_all_gradients)(
            P, parents_by_id, all_agents_par, Gq, Gp, params_par, runtime_ctx=ctx
        )
        for P in parents
    )

    for P, res in zip(parents, results):
        (dmuq, dsgq), (dmup, dsgp), gphi, gphit, *_ = res

        # ensure grad slots exist
        if not hasattr(P, "grad_mu_q"):      P.grad_mu_q = None
        if not hasattr(P, "grad_sigma_q"):   P.grad_sigma_q = None
        if not hasattr(P, "grad_mu_p"):      P.grad_mu_p = None
        if not hasattr(P, "grad_sigma_p"):   P.grad_sigma_p = None
        if not hasattr(P, "grad_phi") or P.grad_phi is None:
            P.grad_phi = (np.zeros_like(P.phi, dtype=np.float32)
                          if getattr(P, "phi", None) is not None else None)
        if not hasattr(P, "grad_phi_tilde") or P.grad_phi_tilde is None:
            P.grad_phi_tilde = (np.zeros_like(P.phi_model, dtype=np.float32)
                                if getattr(P, "phi_model", None) is not None else None)

        # accumulate or overwrite
        if accum_into:
            P.grad_mu_q      = _safe_add(P.grad_mu_q,    dmuq)
            P.grad_sigma_q   = _safe_add(P.grad_sigma_q, dsgq)
            P.grad_mu_p      = _safe_add(P.grad_mu_p,    dmup)
            P.grad_sigma_p   = _safe_add(P.grad_sigma_p, dsgp)
            if gphi  is not None and P.grad_phi is not None:
                P.grad_phi       = P.grad_phi       + gphi
            if gphit is not None and P.grad_phi_tilde is not None:
                P.grad_phi_tilde = P.grad_phi_tilde + gphit
        else:
            P.grad_mu_q, P.grad_sigma_q = dmuq, dsgq
            P.grad_mu_p, P.grad_sigma_p = dmup, dsgp
            if gphi is not None:
                if P.grad_phi is None and getattr(P, "phi", None) is not None:
                    P.grad_phi = np.zeros_like(P.phi, dtype=np.float32)
                if P.grad_phi is not None:
                    P.grad_phi[...] = gphi
            if gphit is not None:
                if P.grad_phi_tilde is None and getattr(P, "phi_model", None) is not None:
                    P.grad_phi_tilde = np.zeros_like(P.phi_model, dtype=np.float32)
                if P.grad_phi_tilde is not None:
                    P.grad_phi_tilde[...] = gphit



def _compute_child_grads(agents, all_agents, Gq, Gp, params):
    params_x = dict(params or {})
    params_x["xscale_child_only"] = False  # allow x-scale to write into parents' grad buffers

    results = Parallel(n_jobs=config.n_jobs, backend="threading", batch_size="auto")(
        delayed(compute_all_gradients)(Ai, agents, all_agents, Gq, Gp, params_x, runtime_ctx=params_x.get("runtime_ctx"))
        for Ai in agents
    )
    q_updates, p_updates, phi_grads, phi_m_grads, morphism_grads, morphism_tilde_grads = zip(*results)
    return (q_updates, p_updates, phi_grads, phi_m_grads, morphism_grads, morphism_tilde_grads)



def compute_adaptive_eta(base_eta, kl_scalar, cond_scalar,
                         grad=None, scaling_kl=1.0, scaling_cond=1.0,
                         eta_min=0.0, ema_prev=None, ema_alpha=None):
    """
    Returns η in [eta_min, base_eta]. Robust to array/None/object inputs.
    - kl_scalar: if bad → falls back to mean |grad| (or 0)
    - cond_scalar: if bad → 1.0
    """
    def _to_scalar(x, default):
        try:
            a = np.asarray(x, dtype=float)
            if a.ndim == 0:
                v = float(a)
            else:
                v = float(np.nanmedian(a))
            return v if np.isfinite(v) else float(default)
        except Exception:
            return float(default)

    # KL term (fallback to grad norm if needed; ignore non-finite)
    if grad is not None:
        g = np.asarray(grad, dtype=float)
        g = g[np.isfinite(g)]
        default_kl = float(np.mean(np.abs(g))) if g.size else 0.0
    else:
        default_kl = 0.0
    kl_term = _to_scalar(kl_scalar, default_kl)

    # Condition term (fallback to 1.0)
    cond_term = _to_scalar(cond_scalar, 1.0)

    denom = 1.0 + scaling_kl * kl_term + scaling_cond * cond_term
    eta = np.clip(base_eta / denom, eta_min, base_eta)

    if (ema_prev is not None) and (ema_alpha is not None) and (0.0 < ema_alpha < 1.0):
        eta = ema_alpha * eta + (1.0 - ema_alpha) * float(ema_prev)

    return float(eta)



def _safe_symmetrize(S):
    return 0.5 * (S + np.swapaxes(S, -1, -2))
# --- robust parent collection -----------------------------------------------
def _collect_parents_from_ctx(ctx):
    """
    Returns a flat list of parent agents from ctx.
    Accepts:
      - ctx.parents_by_region: dict[str]-> list[Agent] OR Agent
      - ctx.parents: list[Agent] OR Agent
      - ctx.parent: Agent
    """
    parents = []

    def _extend(obj):
        if obj is None:
            return
        if isinstance(obj, (list, tuple)):
            parents.extend(obj)
        else:
            parents.append(obj)

    if hasattr(ctx, "parents_by_region"):
        pbr = getattr(ctx, "parents_by_region")
        if isinstance(pbr, dict):
            for v in pbr.values():
                _extend(v)
        else:
            _extend(pbr)
    elif hasattr(ctx, "parents"):
        _extend(getattr(ctx, "parents"))
    elif hasattr(ctx, "parent"):
        _extend(getattr(ctx, "parent"))

    # drop Nones / duplicates while preserving order
    seen = set()
    flat = []
    for p in parents:
        try:
            pid = int(getattr(p, "id"))
        except Exception:
            pid = id(p)
        if p is not None and pid not in seen:
            seen.add(pid)
            flat.append(p)
    return flat


def _final_apply_parents(ctx, params):
    parents = _collect_parents_from_ctx(ctx)
    if not parents:
        return
    _apply_parent_updates(parents, getattr(ctx, "global_step", 0), params, ctx=ctx)




