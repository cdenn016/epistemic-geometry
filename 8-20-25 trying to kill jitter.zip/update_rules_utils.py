# -*- coding: utf-8 -*-
"""
Created on Tue Aug 12 20:10:51 2025

@author: chris and christine
"""

import numpy as np
from preprocess_utils import build_all_omega_caches, build_all_lambda_caches, preprocess_all_agents
from runtime_context import _collect_by_ids
from gaussian_core import directed_kl_weight_after_transport
from omega import exp_grid_cached


# --- in update_rules_utils.py (add near other small helpers) ---
from types import SimpleNamespace






def make_pipeline_knobs(runtime_ctx):
    """
    Centralize a few thresholds so detect→spawn→assign use the same values.
    Keep this tiny; grow only if absolutely necessary.
    """
    import config as CFG
    ds = getattr(runtime_ctx, "detector_state", None)

    alpha  = float(getattr(CFG, "blend_qp_alpha", 0.5))
    tau_q  = float(getattr(CFG, "tau_align_q", 0.45))
    tau_p  = float(getattr(CFG, "tau_align_p", 0.45))
    agree_gate = getattr(ds, "agree_gate_tau_eff", None) if ds is not None else None
    if agree_gate is None:
        agree_gate = getattr(CFG, "agree_gate_tau", None)

    return SimpleNamespace(
        support_tau = float(getattr(CFG, "support_tau", 1e-3)),
        alpha       = alpha,
        tau_q       = tau_q,
        tau_p       = tau_p,
        tau_blend   = alpha * tau_q + (1.0 - alpha) * tau_p,
        agree_gate  = agree_gate,
        mask_eps    = float(getattr(CFG, "parent_mask_change_eps", 1e-5)),
        change_tol  = float(getattr(CFG, "parent_mask_change_tol", 5e-3)),
    )


# --- small helpers you can place near the function ---------------------------

def _parent_cores(Pmasks, *, abs_core, rel_core, ages, newborn_steps, dilate_px, binary_dilation):
    """
    Build boolean cores for each parent with newborn relax and optional dilation.
    Pmasks: (Pn,H,W) float32 in [0,1]
    Returns: (Pn,H,W) bool
    """
    import numpy as np
    Pn, H, W = Pmasks.shape
    pm_max = Pmasks.reshape(Pn, -1).max(axis=1) if Pmasks.size else np.zeros(Pn, np.float32)
    thr = np.maximum(abs_core, rel_core * pm_max).astype(np.float32)
    relax = (np.asarray(ages, int) < int(newborn_steps))
    thr = thr * np.where(relax, 0.6, 1.0).astype(np.float32)   # newborn relax
    core = (Pmasks > thr[:, None, None])
    if int(dilate_px) and (binary_dilation is not None):
        it = int(dilate_px)
        core = np.stack([binary_dilation(core[p], iterations=it) for p in range(Pn)], axis=0)
    return core

def _apply_assignment_hysteresis(P, children, *, min_kids=2, keep_thr=0.10, eps=1e-6):
    """
    Keep previously assigned children if their IoU with the current mask is still reasonable.
    """
    import numpy as np
    prev_ids = set(getattr(P, "_prev_child_ids", ()) or ())
    cur_ids  = set(int(k) for k in getattr(P, "child_ids", ()))
    if not prev_ids:
        return
    M = np.asarray(getattr(P, "mask", 0.0), np.float32) >= float(eps)
    for cid in prev_ids:
        if cid in cur_ids:       # already kept
            continue
        # find child by id
        for ch in children:
            if int(getattr(ch, "id", -1)) == cid:
                Cm = np.asarray(getattr(ch, "mask", 0.0), np.float32) >= float(eps)
                inter = int((Cm & M).sum()); union = int(Cm.sum() + M.sum() - inter)
                iou = (inter / max(1, union))
                if iou >= float(keep_thr):
                    cur_ids.add(cid)
                break
    if len(cur_ids) >= min_kids:
        P.child_ids = tuple(sorted(cur_ids))

def _ema_blend_assignments(W, Ps, children, weight_ema):
    """
    Blend current assignment weights with previous per-parent weights to reduce thrash.
    Mutates W in place.
    """
    import numpy as np
    I, Pn = W.shape
    for p, P in enumerate(Ps):
        prev = getattr(P, "child_weights", None) or {}
        if not prev:
            continue
        for i in range(I):
            cid = int(getattr(children[i], "id", i))
            old = float(prev.get(cid, 0.0))
            new = float(W[i, p])
            if old > 0.0 or new > 0.0:
                W[i, p] = float(weight_ema) * old + (1.0 - float(weight_ema)) * new


# --- main function -----------------------------------------------------------

def _assign_children_to_parents(
    children,
    parents_by_id,
    *,
    eps=1e-3,
    tau=0.01,
    temp=0.25,
    max_parents_per_child=2,
    core_tau=None,
    core_tau_rel=0.50,
    core_dilate_px=1,
    newborn_bootstrap_steps=2,
    allow_unassigned=False,
    agreement_map=None,
    use_agreement=None,
    agree_weight=None,
    debug=False,
):
    """
    Stable, streamlined child→parent assignment:
      - Vectorized IoU on parent cores (per-parent adaptive threshold + newborn relax)
      - Optional agreement blending (mean over cm∧core)
      - Tempered normalization via _normalize_assignments (softmax/sparsemax/entmax)
      - Weight EMA + child-link hysteresis
      - Optional top-k pruning after normalization
      - No full unassignment unless explicitly allowed
    Writes: child.labels/parent_ids/parent_id; parent.child_weights/child_ids
    """
    import numpy as np, config
    try:
        from scipy.ndimage import binary_dilation
    except Exception:
        binary_dilation = None
    from parent_utils import resize_nn  # nearest-neighbor resizer

    Ps = list(parents_by_id.values())
    Pn = len(Ps); I = len(children)
    if Pn == 0 or I == 0:
        for ch in children:
            ch.labels = {}; ch.parent_id = -1; ch.parent_ids = []
        for P in Ps:
            P.child_weights = {}; P.child_ids = ()
        return

    H, W = np.asarray(children[0].mask, np.float32).shape[:2]

    # knobs
    if use_agreement is None:
        use_agreement = bool(getattr(config, "parent_assign_use_agreement", False))
    if agree_weight is None:
        agree_weight = float(getattr(config, "parent_assign_agree_weight", 1.0))
    activation   = str(getattr(config, "parent_assign_activation", "entmax")).lower()
    null_enabled = bool(getattr(config, "parent_assign_null_enabled", True))
    null_logit   = 0.0
    null_tau     = float(getattr(config, "parent_assign_null_tau", 0.5))

    cal = None
    if getattr(config, "parent_assign_target_entropy", None) is not None:
        cal = {"target_H": float(getattr(config, "parent_assign_target_entropy", 1.0)),
               "k":       float(getattr(config, "parent_assign_temp_k", 0.4))}

    # child boolean masks
    Cmb = np.stack([(np.asarray(ch.mask, np.float32) > float(eps)) for ch in children], axis=0).astype(bool)

    # parent masks
    Pmasks = np.stack(
        [np.nan_to_num(np.asarray(P.mask, np.float32), nan=0.0, posinf=0.0, neginf=0.0) for P in Ps],
        axis=0
    )

    abs_core = float(core_tau if core_tau is not None else getattr(config, "core_abs_tau", 0.20))
    rel_core = float(core_tau_rel)
    ages = np.array([int(getattr(Ps[i], "_age", 0) or 0) for i in range(Pn)], dtype=int)

    # cores with relax + dilation
    Pcore = _parent_cores(Pmasks, abs_core=abs_core, rel_core=rel_core,
                          ages=ages, newborn_steps=newborn_bootstrap_steps,
                          dilate_px=core_dilate_px, binary_dilation=binary_dilation)

    # optional agreement map
    A_map = None
    if use_agreement and (agreement_map is not None):
        A_map = np.asarray(agreement_map, np.float32)
        if A_map.shape[:2] != (H, W):
            try:
                A_map = resize_nn(A_map, (H, W)).astype(np.float32)
            except Exception:
                A_map = None
        if A_map is not None:
            A_map = np.clip(np.nan_to_num(A_map, nan=0.0, posinf=1.0, neginf=0.0), 0.0, 1.0)

    # IoU on cores (vectorized)
    inter = np.logical_and(Cmb[:, None, :, :], Pcore[None, :, :, :]).sum(axis=(2, 3)).astype(np.float32)  # (I,Pn)
    cm_sum = Cmb.sum(axis=(1, 2)).astype(np.float32)
    core_sum = Pcore.sum(axis=(1, 2)).astype(np.float32)
    union = cm_sum[:, None] + core_sum[None, :] - inter
    S = inter / np.maximum(1.0, union)
    valid = (inter > 0) & (S >= float(tau))

    # agreement over intersections
    if A_map is not None:
        mask_ip = np.logical_and(Cmb[:, None, :, :], Pcore[None, :, :, :]).astype(np.float32)
        sum_A = (A_map[None, None, :, :] * mask_ip).sum(axis=(2, 3))
        with np.errstate(divide="ignore", invalid="ignore"):
            A = sum_A / np.maximum(1.0, inter)
            A = np.clip(np.nan_to_num(A, nan=0.0, posinf=1.0, neginf=0.0), 1e-6, 1.0)
    else:
        A = np.ones_like(S, dtype=np.float32)

    # per-child normalization
    W = np.zeros((I, Pn), np.float32)
    entropy_list, top1_mass_list, null_mass_list, support_size_list = [], [], [], []

    for i in range(I):
        vmask = valid[i]
        if not np.any(vmask):
            continue

        scores = S[i, vmask]
        agree_vec = (A[i, vmask] if (A_map is not None and use_agreement) else None)

        probs_all = _normalize_assignments(
            scores=scores,
            agree=agree_vec,
            valid_mask=None,
            temp=float(temp),
            activation=activation,
            agree_weight=float(agree_weight),
            null_enabled=bool(null_enabled),
            null_logit=float(null_logit),
            calibrate=cal
        )

        if null_enabled:
            p_eff = probs_all[:-1]; p_null = float(probs_all[-1])
        else:
            p_eff = probs_all; p_null = 0.0

        idxs = np.where(vmask)[0]
        W[i, idxs] = p_eff

        # top-k AFTER normalization
        if max_parents_per_child and max_parents_per_child < len(idxs):
            k = int(max_parents_per_child)
            row = W[i]
            keep = idxs[np.argsort(-row[idxs])[:k]]
            prune = np.setdiff1d(idxs, keep, assume_unique=False)
            if prune.size:
                row[prune] = 0.0
            s = row[keep].sum()
            if s > 0:
                row[keep] /= s
            W[i] = row

        # robust fallback if disallowed unassignment
        if not allow_unassigned:
            if (W[i].sum() <= 0.0) or (null_enabled and p_null >= float(null_tau)):
                best_p = int(np.argmax(S[i])); best_iou = float(S[i, best_p])
                if best_iou <= 0.0:
                    cm = Cmb[i]; best_p, best_iou = -1, -1.0
                    for p in range(Pn):
                        pm = (Pmasks[p] > 0)
                        u = int((cm | pm).sum()); inter2 = int((cm & pm).sum())
                        iou = float(inter2) / float(max(1, u))
                        if iou > best_iou: best_iou, best_p = iou, p
                if best_p >= 0 and best_iou > 0.0:
                    W[i, :] = 0.0; W[i, best_p] = 1.0

        # diagnostics
        row = W[i]
        if row.sum() > 0:
            nz = row[row > 0]; ent = -float(np.sum(nz * np.log(nz + 1e-20)))
            top1 = float(nz.max()) if nz.size else 1.0
            supp = int((row > 1e-3).sum())
        else:
            ent, top1, supp = 0.0, 1.0, 0
        entropy_list.append(ent); top1_mass_list.append(top1); null_mass_list.append(p_null); support_size_list.append(supp)

    # --- NEW: assignment EMA to reduce flip-flops ---
    weight_ema = float(getattr(config, "parent_assign_weight_ema", 0.7))
    _ema_blend_assignments(W, Ps, children, weight_ema)


    # === NEW BLOCK: per-link hysteresis on coalition membership ==============
    # knobs (with safe defaults)
    theta_on   = float(getattr(config, "parent_link_on_tau",  0.30))   # raise to be conservative
    theta_off  = float(getattr(config, "parent_link_off_tau", 0.20))   # off < on
    link_beta  = float(getattr(config, "parent_link_ema_beta", 0.4))   # 0..1
    max_change = int(getattr(config, "parent_link_max_change", 2))     # per step, per parent
    min_kids   = int(getattr(config, "parent_min_kids", 2))

    # precompute per-(i,p) IoU used as the "signal" for the link score
    # NOTE: we already have S = IoU(cm, core_p). Convert into a row dict per parent.
    IoU = S  # (I,Pn), already computed above on cores

    # current "hard" child selection per parent from W > 0
    for p, P in enumerate(Ps):
        # child ids from current probabilistic assignment
        sel = set(int(getattr(children[i], "id", i)) for i in np.where(W[:, p] > 0.0)[0])

        # build iou_row for kids that either are selected or have nonzero IoU
        row = {}
        for i, ch in enumerate(children):
            cid = int(getattr(ch, "id", i))
            iou = float(IoU[i, p])
            if (iou > 0.0) or (cid in sel):
                row[cid] = iou

        # run hysteresis with EMA & change cap
        kept = _update_link_hysteresis_for_parent(
            P,
            iou_row=row,
            child_ids_row=sel,
            theta_on=theta_on,
            theta_off=theta_off,
            beta=link_beta,
            max_change=max_change,
            min_kids=min_kids,
        )

        # project W to exactly those kept child ids (renormalize)
        kept_set = set(kept)
        W[:, p] = 0.0
        idx_keep = [i for i, ch in enumerate(children) if int(getattr(ch, "id", i)) in kept_set]
        if idx_keep:
            w = np.ones(len(idx_keep), np.float32) / float(len(idx_keep))
            W[idx_keep, p] = w


    # ---------------- write back: children ----------------
    for i, ch in enumerate(children):
        pairs = [(int(getattr(Ps[p], "id", p)), float(W[i, p])) for p in range(Pn) if W[i, p] > 0.0]
        if pairs:
            pairs.sort(key=lambda t: -t[1])
            if max_parents_per_child and len(pairs) > int(max_parents_per_child):
                pairs = pairs[:int(max_parents_per_child)]
            s = sum(w for _, w in pairs)
            if s > 0:
                pairs = [(pid, w / s) for (pid, w) in pairs]
            ch.labels = {pid: w for (pid, w) in pairs}
            ch.parent_ids = [pid for (pid, _) in pairs]
            ch.parent_id = int(ch.parent_ids[0]) if ch.parent_ids else -1
        else:
            ch.labels = {}; ch.parent_ids = []; ch.parent_id = -1

    # ---------------- write back: parents ----------------
    for p, P in enumerate(Ps):
        ids = np.where(W[:, p] > 0.0)[0]
        weights = {}
        for i in ids:
            cid = int(getattr(children[i], "id", i))
            weights[cid] = float(W[i, p])
        s = sum(weights.values())
        if s > 0.0:
            inv = 1.0 / s
            for k in list(weights.keys()):
                weights[k] *= inv
        P.child_weights = weights
        P.child_ids = tuple(sorted(weights.keys()))

    # --- NEW: link hysteresis & grace coalition keep ---
    min_kids   = int(getattr(config, "parent_min_kids", 2))
    keep_thr   = float(getattr(config, "parent_assign_keep_thr", 0.10))
    grace_keep = bool(getattr(config, "parent_assign_keep_during_grace", True))
    for p, P in enumerate(Ps):
        _apply_assignment_hysteresis(P, children, min_kids=min_kids, keep_thr=keep_thr, eps=eps)
        if grace_keep and int(getattr(P, "_grace", 0)) > 0:
            prev_ids = set(getattr(P, "_prev_child_ids", ()) or ())
            cur_ids  = set(int(k) for k in getattr(P, "child_ids", ()))
            if (len(cur_ids) < min_kids) and (len(prev_ids) >= min_kids):
                P.child_ids = tuple(sorted(prev_ids))
                # re-spread weights uniformly over kept ids
                keep = [i for i, ch in enumerate(children) if int(getattr(ch, "id", i)) in prev_ids]
                row = np.zeros_like(W[:, p]); row[keep] = 1.0 / max(1, len(keep))
                for i in range(I):
                    W[i, p] = row[i]
                P.child_weights = {int(getattr(children[i], "id", i)): float(row[i]) for i in keep}

    # ---------------- debug summary ----------------
    if debug or bool(getattr(config, "debug_assign_summary", True)):
        Hm  = float(np.mean(entropy_list)) if entropy_list else 0.0
        T1m = float(np.mean(top1_mass_list)) if top1_mass_list else 0.0
        Nul = float(np.mean(null_mass_list)) if null_mass_list else 0.0
        FrN = float(np.mean([x >= null_tau for x in null_mass_list])) if (null_enabled and null_mass_list) else 0.0
        Sup = float(np.mean(support_size_list)) if support_size_list else 0.0
        print(f"[ASSIGN] act={activation} temp={float(temp):.3f} "
              f"Hmean={Hm:.3f} top1={T1m:.3f} null_mean={Nul:.3f} null>τ={FrN:.2f} "
              f"support_mean={Sup:.2f}")
        for p, P in enumerate(Ps):
            wsum = float(sum((P.child_weights or {}).values()))
            print(f"    P{getattr(P,'id',p)} kids={len(P.child_ids)} wsum={wsum:.3g}")

# --- helper: update per-link EMA + hysteresis -------------------------------

# replace your _update_link_hysteresis_for_parent with this version
def _update_link_hysteresis_for_parent(P, *, iou_row, child_ids_row,
                                       theta_on, theta_off, beta,
                                       max_change, min_kids,
                                       cooldown_steps=3,    # NEW
                                       jitter=0.02):        # NEW (breaks phase lock)
    """
    EMA+hysteresis + cooldown per parent↔child link.
    """
    import numpy as np
    # persistent maps
    if not hasattr(P, "_link_score") or P._link_score is None:
        P._link_score = {}
    if not hasattr(P, "_link_cooldown") or P._link_cooldown is None:
        P._link_cooldown = {}   # cid -> steps left
    if not hasattr(P, "_link_int") or P._link_int is None:
        P._link_int = {}        # small leaky integrator to avoid on/off chatter

    scores = P._link_score
    cool   = P._link_cooldown
    integ  = P._link_int

    cur = set(int(c) for c in (child_ids_row or ()))

    # tiny per-parent jitter to thresholds breaks global synchrony
    # (same for all links of this parent this step)
    th_on  = float(theta_on)  + float(jitter) * (np.random.rand() - 0.5)
    th_off = float(theta_off) - float(jitter) * (np.random.rand() - 0.5)

    # 1) update EMA + leaky integrator
    # integrator accumulates (iou - mid); only triggers when past band
    mid = 0.5 * (th_on + th_off)
    k_i = 0.25   # integration gain
    leak = 0.90  # leaky memory
    for cid, iou in iou_row.items():
        s_old = float(scores.get(cid, 0.0))
        s_new = (1.0 - beta) * s_old + beta * float(iou)
        scores[cid] = s_new

        z_old = float(integ.get(cid, 0.0))
        z_new = leak * z_old + k_i * (float(iou) - mid)
        integ[cid] = z_new

        # tick cooldown
        if cool.get(cid, 0) > 0:
            cool[cid] = int(cool[cid]) - 1

    # 2) propose adds/drops (respect cooldown and integrator)
    adds, drops = set(), set()
    seen_cids = set(iou_row.keys()) | cur
    band = 0.0  # we already bias with integrator
    for cid in seen_cids:
        s = float(scores.get(cid, 0.0))
        z = float(integ.get(cid, 0.0))
        cd = int(cool.get(cid, 0))
        if cid in cur:
            # require BOTH: under off-threshold AND integrator negative, and no cooldown
            if (cd == 0) and (s < th_off - band) and (z < 0.0):
                drops.add(cid)
        else:
            if (cd == 0) and (s >= th_on + band) and (z > 0.0):
                adds.add(cid)

    # 3) cap changes per step
    changes = 0
    out = set(cur)

    # execute drops (lowest score first)
    for cid in sorted(drops, key=lambda c: float(scores.get(c,0.0))):
        if changes >= max_change: break
        if len(out) <= max(0, int(min_kids)): break
        out.discard(cid); changes += 1
        cool[cid] = int(cooldown_steps)   # start cooldown

    # execute adds (highest score first)
    for cid in sorted(adds, key=lambda c: -float(scores.get(c,0.0))):
        if changes >= max_change: break
        out.add(cid); changes += 1
        cool[cid] = int(cooldown_steps)

    return tuple(sorted(out))



def build_child_parent_responsibilities(children, parents_by_id, *,
                                        mode="pixel",   # "pixel" or "global"
                                        eps=1e-6):
    """
    Compute child↔parent responsibilities so a child can belong to MULTIPLE parents.

    For each child c and parent P that lists c in P.child_ids:
      - mode="pixel":  r_{P|c}(y,x)  ∝  P.mask(y,x) over all such parents, normalized per-pixel.
      - mode="global": r_{P|c}       ∝  mean_{child-support} P.mask, normalized per-child (scalar).

    Effects (writes onto objects):
      child._parent_ids        = [pid,...]
      child._parent_resp_mask  = {pid: H×W float32}     (if mode="pixel")
      child._parent_resp       = {pid: float}           (if mode="global")
      parent._child_resp       = {cid: float}           (global scalar for diagnostics)
    """
    import numpy as np

    if not children or not parents_by_id:
        return

    # quick shape
    H, W = np.asarray(children[0].mask, np.float32).shape[:2]

    # build reverse index: parent -> set(child_ids) already exists via P.child_ids
    # we also want, for each child, the set of parents that include it
    child_to_parents = {int(getattr(ch, "id", -1)): [] for ch in children}
    for pid, P in (parents_by_id or {}).items():
        for cid in (getattr(P, "child_ids", []) or []):
            cid = int(cid)
            if cid in child_to_parents:
                child_to_parents[cid].append(int(pid))

    # prefetch parent masks
    pid2mask = {int(pid): np.asarray(getattr(P, "mask", np.zeros((H, W), np.float32)), np.float32)
                for pid, P in (parents_by_id or {}).items()}

    for ch in children:
        cid = int(getattr(ch, "id", -1))
        pids = child_to_parents.get(cid, [])
        setattr(ch, "_parent_ids", list(pids))

        if len(pids) == 0:
            setattr(ch, "_parent_resp_mask", {})
            setattr(ch, "_parent_resp", {})
            continue

        cmask = np.clip(np.asarray(getattr(ch, "mask", np.zeros((H, W), np.float32)), np.float32), 0.0, 1.0)

        if mode == "pixel":
            # stack parent masks and normalize per-pixel over parents that include this child
            stack = np.stack([pid2mask[int(pid)] for pid in pids], axis=0)  # (P,H,W)
            # restrict to child support to reduce speckle
            stack = stack * cmask[None, :, :]

            denom = np.maximum(np.sum(stack, axis=0), eps)  # (H,W)
            resp_masks = [(stack[i] / denom).astype(np.float32) for i in range(len(pids))]

            resp_map = {int(pid): resp_masks[i] for i, pid in enumerate(pids)}
            setattr(ch, "_parent_resp_mask", resp_map)
            setattr(ch, "_parent_resp", {})

            # for diagnostics: global scalar responsibility per parent (mean over child support)
            for i, pid in enumerate(pids):
                mean_w = float(np.mean(resp_masks[i][cmask > 0.0])) if np.any(cmask > 0.0) else 0.0
                P = parents_by_id.get(int(pid))
                if P is not None:
                    d = getattr(P, "_child_resp", None) or {}
                    d[cid] = mean_w
                    setattr(P, "_child_resp", d)

        else:  # mode == "global"
            # global weight ∝ mean parent mask over the child's support
            weights = []
            for pid in pids:
                pm = pid2mask[int(pid)]
                if np.any(cmask > 0.0):
                    w = float(np.mean(pm[cmask > 0.0]))
                else:
                    w = 0.0
                weights.append(max(w, 0.0))

            wsum = float(sum(weights)) if sum(weights) > 0.0 else 1.0
            norm = [float(w) / wsum for w in weights]

            resp = {int(pid): float(norm[i]) for i, pid in enumerate(pids)}
            setattr(ch, "_parent_resp", resp)
            setattr(ch, "_parent_resp_mask", {})

            for i, pid in enumerate(pids):
                P = parents_by_id.get(int(pid))
                if P is not None:
                    d = getattr(P, "_child_resp", None) or {}
                    d[cid] = float(norm[i])
                    setattr(P, "_child_resp", d)





















def _stable_mask_update(M_prev,
                        T,
                        *,
                        beta=0.35,            # step toward target (0..1)
                        decay_beta=0.10,      # step toward 0 when target is “empty”
                        min_mass_px=5,        # treat tiny targets as “empty”
                        seed_mask=None,       # protect newborns
                        freeze_until=None,
                        step=None):
    import numpy as np
    M_prev = np.asarray(M_prev, np.float32)
    T      = np.asarray(T,      np.float32)

    # decide whether the target actually has mass
    tgt_mass = int((T >= 1e-3).sum())
    if tgt_mass >= int(min_mass_px):
        M_new = (1.0 - float(beta)) * M_prev + float(beta) * T
    else:
        # evidence vanished: gently decay instead of dropping to zero
        M_new = (1.0 - float(decay_beta)) * M_prev

    # protect seed during newborn freeze
    if (seed_mask is not None) and (freeze_until is not None) and (step is not None):
        if int(step) <= int(freeze_until):
            M_new = np.maximum(M_new, np.asarray(seed_mask, np.float32))

    return np.clip(np.nan_to_num(M_new, nan=0.0, posinf=0.0, neginf=0.0), 0.0, 1.0)


def assign_parent_masks_from_alignment(ctx, children,
                                       generators_q, generators_p,
                                       *,
                                       mode="max",
                                       mask_tau=0.010,
                                       tau_q=None, tau_p=None, alpha=0.5,
                                       agree_map=None, agree_power=1.0,
                                       clamp_to_union=True,
                                       floor_eps=1e-6,
                                       min_pair_px=8,
                                       kl_cap=None,
                                       pnorm=99.0,
                                       return_changed=False,
                                       change_tol=None):
    """
    Smooth parent mask update (self-contained; no external reconcile step):
      - Evidence E_now via soft-min over child agreements
      - Coalition weighting W_comp (presence-weighted)
      - Target M_tgt = (E_ema^etaE)*(W_comp^etaW)*g2_soft
      - Final M_new = EMA toward M_tgt with per-step delta cap + newborn floor
    """
    import numpy as np
    try:
        import config
    except Exception:
        class _Cfg: pass
        config = _Cfg()

    parents = getattr(ctx, "parents_by_region", {}) or {}
    if not parents or not children:
        return [] if return_changed else None

    # -------- knobs (single-sourced) ----------
    support_cut  = float(getattr(config, "support_cutoff_eps", 1e-3))
    betaE        = float(getattr(config, "mask_evidence_beta", 0.7))    # EMA on evidence
    betaM        = float(getattr(config, "mask_ema_beta", 0.3))         # EMA toward target (smaller => smoother)
    etaE         = float(getattr(config, "mask_evidence_power", 1.0))
    etaW         = float(getattr(config, "mask_weight_power", 1.0))
    p_neg        = float(getattr(config, "evidence_softmin_p", -4.0))   # p<0 soft-min
    pres_delta   = float(getattr(config, "presence_soft_delta", 0.05))
    count_lo     = float(getattr(config, "overlap_soft_lo", 1.5))
    count_hi     = float(getattr(config, "overlap_soft_hi", 2.5))
    core_tau     = float(getattr(config, "parent_growth_core_tau", max(0.10, support_cut)))
    core_floor   = float(getattr(config, "parent_core_floor", 0.65))
    dcap         = float(getattr(config, "parent_delta_cap", 0.08))     # tighter cap to stop “jumping”
    freeze_steps = int(getattr(config, "parent_freeze_steps", 3))        # respect newborn freeze here too
    change_tol   = float(change_tol if change_tol is not None
                         else getattr(config, "parent_mask_change_tol", 5e-3))

    # -------- shapes ----------
    H, W = np.asarray(children[0].mask, np.float32).shape[:2]

    # -------- helpers ----------
    def _to_hw(a):
        a = np.asarray(a, np.float32)
        if a.shape[:2] == (H, W): return a
        out = np.zeros((H, W), np.float32)
        h = min(H, a.shape[0]); w = min(W, a.shape[1]); out[:h, :w] = a[:h, :w]
        return out

    def _smoothstep(x, lo, hi):
        t = (np.asarray(x, np.float32) - float(lo)) / max(hi - lo, 1e-8)
        t = np.clip(t, 0.0, 1.0); return t * t * (3.0 - 2.0 * t)

    def _presence_soft(m):
        lo = support_cut - pres_delta; hi = support_cut + pres_delta
        return _smoothstep(m, lo, hi)

    def _softmin_power_mean(A_stack, p):
        A = np.clip(np.asarray(A_stack, np.float32), 1e-9, 1.0)
        Mp = np.mean(np.power(A, p, dtype=np.float32), axis=0)
        return np.power(np.clip(Mp, 1e-12, 1.0), 1.0 / p, dtype=np.float32)

    # -------- per-child fields (agreement & masks) ----------
    id2A, id2M = {}, {}
    for ch in children:
        if ch is None: continue
        cid = int(getattr(ch, "id", -1))
        A = getattr(ch, "spawn_A_final", None)
        id2A[cid] = _to_hw(A) if isinstance(A, np.ndarray) else np.zeros((H, W), np.float32)
        m = getattr(ch, "mask", None)
        id2M[cid] = np.clip(np.asarray(m, np.float32), 0.0, 1.0) if m is not None else np.zeros((H, W), np.float32)

    # capture prev masks if caller wants a changed list
    prev_masks = {}
    if return_changed:
        for pid, P in parents.items():
            prev_masks[int(pid)] = np.asarray(getattr(P, "mask", np.zeros((H, W), np.float32)), np.float32)

    changed = []

    for pid, P in parents.items():
        base_ids = list(getattr(P, "child_ids", []) or [])
        asg_ids  = list(getattr(P, "assigned_child_ids", []) or [])
        kids_ids = sorted(set(asg_ids)) if len(asg_ids) >= 2 else sorted(set(asg_ids) | set(base_ids))

        M_prev = np.asarray(getattr(P, "mask", np.zeros((H, W), np.float32)), np.float32)

        # initialize persistent fields
        if not hasattr(P, "_ema_E") or getattr(P, "_ema_E") is None or getattr(P, "_ema_E").shape[:2] != (H, W):
            P._ema_E = np.zeros((H, W), np.float32)
        if not hasattr(P, "freeze_until"):
            step_now = int(getattr(ctx, "global_step", 0))
            P.freeze_until = step_now + freeze_steps

        # coalition broke → gentle decay, not drop-to-zero
        if len(kids_ids) < 2:
            raw = (1.0 - betaM) * M_prev  # slow fade
            # keep core during freeze
            if int(getattr(ctx, "global_step", 0)) <= int(P.freeze_until):
                core_prev = (M_prev >= core_tau)
                if core_prev.any():
                    raw = np.maximum(raw, core_floor * core_prev.astype(np.float32))
            # cap delta
            d = np.clip(raw - M_prev, -dcap, dcap)
            P.mask = np.clip(M_prev + d, 0.0, 1.0).astype(np.float32)
            P.emerged = bool(np.any(P.mask > 0))
            continue

        A_stack = np.stack([id2A.get(int(k), np.zeros((H, W), np.float32)) for k in kids_ids], axis=0)
        M_stack = np.stack([id2M.get(int(k), np.zeros((H, W), np.float32)) for k in kids_ids], axis=0)

        # evidence
        E_now = _softmin_power_mean(A_stack, p_neg)
        E_now = np.clip(np.nan_to_num(E_now, nan=0.0, posinf=1.0, neginf=0.0), 0.0, 1.0)
        E_ema = float(betaE) * P._ema_E + (1.0 - float(betaE)) * E_now
        P._ema_E = E_ema.astype(np.float32)

        # coalition presence & weights
        S_stack   = _presence_soft(M_stack)                 # [0,1]
        soft_cnt  = np.sum(S_stack, axis=0)
        g2_soft   = _smoothstep(soft_cnt, count_lo, count_hi)
        W_num     = np.sum(S_stack * A_stack * M_stack, axis=0)
        W_den     = np.sum(S_stack * A_stack, axis=0)
        W_comp    = np.divide(W_num, np.clip(W_den, 1e-9, None), out=np.zeros_like(W_num), where=(W_den > 1e-9))
        W_comp    = np.clip(np.nan_to_num(W_comp, nan=0.0, posinf=1.0, neginf=0.0), 0.0, 1.0)

        # target, newborn core floor, EMA + delta cap
        M_tgt = (np.power(E_ema, float(etaE)) *
                 np.power(W_comp, float(etaW)) *
                 g2_soft.astype(np.float32))
        M_tgt = np.clip(M_tgt, 0.0, 1.0)

        # small per-parent jitter to break phase locking
        bm = float(betaM) + float(getattr(config, "parent_mask_beta_jitter", 0.0)) * (np.random.rand() - 0.5)
        bm = float(np.clip(bm, 0.05, 0.95))
        
        raw = bm * M_prev + (1.0 - bm) * M_tgt
        
        # deadband: ignore tiny moves (prevents breathing)
        dead = float(getattr(config, "parent_mask_deadband", 0.015))
        delta = raw - M_prev
        small = np.abs(delta) < dead
        delta[small] = 0.0
        
        d   = np.clip(delta, -dcap, dcap)
        new = np.clip(M_prev + d, 0.0, 1.0)


        P.mask = new.astype(np.float32)
        P.emerged = bool(np.any(P.mask > 0))

        if return_changed:
            pm = prev_masks.get(int(pid))
            if pm is None or pm.shape[:2] != (H, W) or float(np.max(np.abs(pm - P.mask))) >= change_tol:
                changed.append(P)

    return changed if return_changed else None



















def build_alignment_aggregates(runtime_ctx, children, *, kl_cap=10.0):
    """
    Writes these onto runtime_ctx (H×W float32 each):
        - Aq_agg, KLq_agg  (agreement/KL from belief alignment)
        - Ap_agg, KLp_agg  (agreement/KL from model  alignment)

    Robust to missing caches and avoids any ambiguous array truth checks.
    """
    import numpy as np

    # ---------------- config ----------------
    try:
        import config
        tau_q = float(getattr(config, "tau_align_q", 0.45))
        tau_p = float(getattr(config, "tau_align_p", 0.45))
        kl_cap = float(getattr(config, "signal_kl_cap", kl_cap))
        reduce_mode = str(getattr(config, "agg_reduce_mode", "mean")).lower()  # "mean"|"max"|"p95"
        prefer_agreement_cache = bool(getattr(config, "agg_prefer_agreement_cache", True))
        ema = float(getattr(config, "agg_map_ema", 0.25))  # 0..1; weight for NEW value
    except Exception:
        tau_q = tau_p = 0.45
        reduce_mode = "mean"
        prefer_agreement_cache = True
        ema = 0.25

    eps = 1e-20

    # ---------------- shapes ----------------
    if not children or len(children) == 0:
        # nothing to do
        return

    # Safely infer (H, W)
    H, W = None, None
    for ch in children:
        if ch is None:
            continue
        m = getattr(ch, "mask", None)
        if isinstance(m, np.ndarray) and m.ndim >= 2:
            H, W = int(m.shape[0]), int(m.shape[1])
            break
    if (H is None) or (W is None):
        # fallback from any cached map
        for ch in children:
            A = getattr(ch, "spawn_A_final", None)
            if isinstance(A, np.ndarray) and A.ndim >= 2:
                H, W = int(A.shape[0]), int(A.shape[1])
                break
        if (H is None) or (W is None):
            return

    def _resize_to_hw(a):
        a = np.asarray(a, np.float32)
        if a.shape[:2] == (H, W):
            return a
        # simple crop/pad (no cv2 dependency)
        out = np.zeros((H, W), np.float32)
        h = min(H, a.shape[0]); w = min(W, a.shape[1])
        out[:h, :w] = a[:h, :w]
        return out

    # ---------------- collect per-child maps ----------------
    Aq_list, KLq_list = [], []
    Ap_list, KLp_list = [], []

    for ch in children:
        if ch is None:
            continue

        # Prefer cached agreement (already \in [0,1]) if configured
        A_q = getattr(ch, "spawn_A_final", None) if prefer_agreement_cache else None
        if isinstance(A_q, np.ndarray):
            Aq_list.append(np.clip(_resize_to_hw(A_q), 0.0, 1.0))
        else:
            # otherwise try KL caches for q
            KLq = getattr(ch, "spawn_softmin_kl_q", None)
            if KLq is None:
                KLq = getattr(ch, "cached_alignment_kl", None)
            if isinstance(KLq, np.ndarray):
                KLq_list.append(np.clip(_resize_to_hw(KLq), 0.0, float(kl_cap)))

        A_p = getattr(ch, "spawn_A_final_p", None) if prefer_agreement_cache else None
        if isinstance(A_p, np.ndarray):
            Ap_list.append(np.clip(_resize_to_hw(A_p), 0.0, 1.0))
        else:
            KLp = getattr(ch, "spawn_softmin_kl_p", None)
            if KLp is None:
                KLp = getattr(ch, "cached_model_alignment_kl", None)
            if isinstance(KLp, np.ndarray):
                KLp_list.append(np.clip(_resize_to_hw(KLp), 0.0, float(kl_cap)))

    # ---------------- reduction helpers (NO ambiguous truth) ----------------
    def _reduce_agree(A_list, KL_list, tau):
        has_A = isinstance(A_list, list) and (len(A_list) > 0)
        has_K = isinstance(KL_list, list) and (len(KL_list) > 0)

        if has_A:
            A_stack = np.stack(A_list, axis=0)  # (N,H,W)
        elif has_K:
            KL_stack = np.stack(KL_list, axis=0)  # (N,H,W)
            A_stack = np.exp(-KL_stack / max(tau, 1e-8)).astype(np.float32)
        else:
            return None, None

        if reduce_mode == "mean":
            A_new = np.mean(A_stack, axis=0)
        elif reduce_mode == "max":
            A_new = np.max(A_stack, axis=0)
        elif reduce_mode in ("p95", "p-95", "q95"):
            A_new = np.percentile(A_stack, 95.0, axis=0)
        else:
            # default to mean for any unknown mode
            A_new = np.mean(A_stack, axis=0)

        A_new = np.clip(np.nan_to_num(A_new, nan=0.0, posinf=1.0, neginf=0.0), 0.0, 1.0)
        KL_new = (-max(tau, 1e-8) * np.log(np.maximum(A_new, eps))).astype(np.float32)
        return A_new.astype(np.float32), KL_new

    Aq_new, KLq_new = _reduce_agree(Aq_list, KLq_list, tau_q)
    Ap_new, KLp_new = _reduce_agree(Ap_list, KLp_list, tau_p)

    # ---------------- EMA smoothing (maps) ----------------
    if (ema > 0.0) and (ema < 1.0):
        Aq_prev = getattr(runtime_ctx, "Aq_agg", None)
        if (Aq_prev is not None) and (Aq_new is not None):
            Aq_prev = _resize_to_hw(Aq_prev)
            Aq_new = (1.0 - float(ema)) * Aq_prev + float(ema) * Aq_new
            KLq_new = (-max(tau_q, 1e-8) * np.log(np.maximum(Aq_new, eps))).astype(np.float32)

        Ap_prev = getattr(runtime_ctx, "Ap_agg", None)
        if (Ap_prev is not None) and (Ap_new is not None):
            Ap_prev = _resize_to_hw(Ap_prev)
            Ap_new = (1.0 - float(ema)) * Ap_prev + float(ema) * Ap_new
            KLp_new = (-max(tau_p, 1e-8) * np.log(np.maximum(Ap_new, eps))).astype(np.float32)

    # ---------------- write back ----------------
    if Aq_new is not None:
        runtime_ctx.Aq_agg  = np.asarray(Aq_new,  np.float32)
        runtime_ctx.KLq_agg = np.asarray(KLq_new, np.float32)
    else:
        runtime_ctx.Aq_agg  = None
        runtime_ctx.KLq_agg = None

    if Ap_new is not None:
        runtime_ctx.Ap_agg  = np.asarray(Ap_new,  np.float32)
        runtime_ctx.KLp_agg = np.asarray(KLp_new, np.float32)
    else:
        runtime_ctx.Ap_agg  = None
        runtime_ctx.KLp_agg = None




def snapshot_parent_child_ids(parents_by_id):
    """Store previous child_ids on each parent for post-assignment guards."""
    for P in (parents_by_id or {}).values():
        try:
            P._prev_child_ids = tuple(getattr(P, "child_ids", ()) or ())
        except Exception:
            pass


def enforce_min_children_per_parent(parents_by_id, *, min_kids=2, respect_grace=True):
    """If assignment collapses a parent to < min_kids, revert to previous ids during grace."""
    for P in (parents_by_id or {}).values():
        try:
            cur = tuple(getattr(P, "child_ids", ()) or ())
            if len(cur) >= int(min_kids):
                continue
            prev = tuple(getattr(P, "_prev_child_ids", ()) or ())
            if respect_grace and int(getattr(P, "_grace", 0)) > 0 and len(prev) >= int(min_kids):
                P.child_ids = prev
        except Exception:
            pass











# --- spawn cache refresh policy --------------------------------------------
from update_rules_utils import make_pipeline_knobs

def should_refresh_spawn_cache(child, runtime_ctx, *, mask_tol=None) -> bool:
    """
    Return True if child's spawn caches should be recomputed this step.
    """
    import numpy as np
    if getattr(child, "spawn_A_final", None) is None:
        return True
    if getattr(child, "_dirty_fields", False) or getattr(child, "_dirty_kl", False):
        return True

    # Use centralized tolerance knob
    if mask_tol is None:
        try:
            knobs = make_pipeline_knobs(runtime_ctx)
            mask_tol = float(getattr(knobs, "change_tol", 5e-3))
        except Exception:
            mask_tol = 5e-3

    try:
        prev = getattr(child, "_mask_prev_for_spawn", None)
        if prev is None:
            return True
        now = np.asarray(child.mask, np.float32)
        if now.shape != prev.shape:
            return True
        # L∞ guard with sane tolerance
        if float(np.max(np.abs(now - prev))) > float(mask_tol):
            return True
    except Exception:
        return True

    built_ver = int(getattr(child, "_spawn_cache_built_at_cachever", -1))
    glob_ver  = int(getattr(runtime_ctx, "cache_version", 0))
    return (built_ver != glob_ver)


def ensure_spawn_alignment_caches(children, agents, runtime_ctx, *,
                                  generators_q, generators_p,
                                  use_cover_weight=True, debug=False):
    """
    Build spawn caches ONLY for children that need it (policy above).
    Uses the central runtime transport cache (no per-agent Ω caches).
    """
    import numpy as np
    import config as _cfg

    if not children:
        return

    # Pre-warm exp(φ) grids in the central cache; Ω will be built on demand.
    try:
        from transport_cache import warm_E
        whiches = []
        # choose fibers to warm based on dims present in the data
        kq = int(getattr(children[0].mu_q_field, "shape", (0, 0, 0))[-1]) if children[0] is not None else 0
        kp = int(getattr(children[0].mu_p_field, "shape", (0, 0, 0))[-1]) if children[0] is not None else 0
        if kq: whiches.append("q")
        if kp: whiches.append("p")
        if whiches:
            warm_E(runtime_ctx, children, whiches=tuple(whiches))
    except Exception:
        pass

    # Only refresh those that actually need a rebuild
    need = [ch for ch in children if ch is not None and should_refresh_spawn_cache(ch, runtime_ctx)]
    if not need:
        return

    # Spawn cache build (ctx-aware; explicit generators)
    refresh_spawn_alignment_caches(
        runtime_ctx,
        need,
        agents,
        G_q=generators_q,
        G_p=generators_p,
        tau_q=float(getattr(_cfg, "tau_align_q", 0.45)),
        tau_p=float(getattr(_cfg, "tau_align_p", 0.45)),
        alpha=float(getattr(_cfg, "blend_qp_alpha", 0.50)),
        sm_tau=float(getattr(_cfg, "spawn_softmin_tau", 0.40)),
        kl_cap=float(getattr(_cfg, "signal_kl_cap", 10.0)),  # kept for signature compat
        use_cover_weight=bool(use_cover_weight),
        debug=bool(debug),
    )

    # Bookkeeping
    step_tag = int(getattr(runtime_ctx, "global_step", 0))
    for ch in need:
        ch._spawn_cache_built_at_step = step_tag
        ch._mask_prev_for_spawn = np.asarray(ch.mask, dtype=np.float32).copy()
        setattr(ch, "_dirty_fields", False)
        setattr(ch, "_dirty_kl", False)


def refresh_spawn_alignment_caches(
    ctx,
    children,
    agents,
    *,
    G_q=None,
    G_p=None,
    tau_q=None,
    tau_p=None,
    alpha=None,          # 0→model-only, 1→belief-only
    sm_tau=None,         # softmin temperature across neighbors
    mask_tau=None,       # support threshold on masks
    use_cover_weight=True,
    kl_cap=None,         # kept for signature compat; not used
    debug=False,
):
    """
    Build *spawn-only* caches on each child (per pixel):
        spawn_nb_count, spawn_min_kl_q/p, spawn_softmin_kl_q/p,
        spawn_cover_weight (opt), spawn_A_final, kl_field, agreement_field.

    Notes
    -----
    - Uses ctx-aware transport/KL via directed_kl_weight_after_transport(..., ctx=ctx, G=G_*).
    - Ω/exp caching is entirely in the runtime transport cache (no per-agent caches).
    """
    import numpy as np
    import config as _cfg

    # defaults
    tau_q    = float(getattr(_cfg, "tau_align_q", 0.45))        if tau_q    is None else float(tau_q)
    tau_p    = float(getattr(_cfg, "tau_align_p", 0.45))        if tau_p    is None else float(tau_p)
    alpha    = float(getattr(_cfg, "blend_qp_alpha", 0.50))     if alpha    is None else float(alpha)
    sm_tau   = float(getattr(_cfg, "spawn_softmin_tau", 0.40))  if sm_tau   is None else float(sm_tau)
    mask_tau = float(getattr(_cfg, "support_cutoff_eps", 1e-4)) if mask_tau is None else float(mask_tau)

    tiny = float(getattr(_cfg, "log_eps", 1e-9))

    # id -> agent for quick neighbor lookup
    id2A = {int(a.id): a for a in agents if a is not None}

    for ch in (children or []):
        if ch is None:
            continue

        H, W = np.asarray(ch.mask).shape[:2]
        present_i = (np.asarray(ch.mask, np.float32) > mask_tau)

        # dims and generator guards
        Kq = int(getattr(ch.mu_q_field, "shape", (0, 0, 0))[-1]) if ch.mu_q_field is not None else 0
        Kp = int(getattr(ch.mu_p_field, "shape", (0, 0, 0))[-1]) if ch.mu_p_field is not None else 0
        if Kq > 0 and G_q is None:
            raise ValueError("refresh_spawn_alignment_caches: missing G_q for q-fiber.")
        if Kp > 0 and G_p is None:
            raise ValueError("refresh_spawn_alignment_caches: missing G_p for p-fiber.")

        # init outputs
        nb_count     = np.zeros((H, W), np.int32)
        min_kl_q     = np.full((H, W), np.inf, np.float32)
        min_kl_p     = np.full((H, W), np.inf, np.float32)
        sumexp_q     = np.zeros((H, W), np.float32)  # Σ exp(-KL_q/τ_q)
        sumexp_p     = np.zeros((H, W), np.float32)  # Σ exp(-KL_p/τ_p)
        cover_weight = np.zeros((H, W), np.float32) if use_cover_weight else None

        if not getattr(ch, "neighbors", None) or not np.any(present_i):
            zf = np.zeros((H, W), np.float32)
            zi = np.zeros((H, W), np.int32)
            ch.spawn_nb_count      = zi
            ch.spawn_min_kl_q      = zf + np.inf
            ch.spawn_min_kl_p      = zf + np.inf
            ch.spawn_softmin_kl_q  = zf
            ch.spawn_softmin_kl_p  = zf
            ch.spawn_cover_weight  = zf if use_cover_weight else None
            ch.spawn_A_final       = zf
            ch.kl_field            = zf
            ch.agreement_field     = zf
            continue

        # per-neighbor accumulation on the overlap only
        for nb in ch.neighbors:
            j = id2A.get(int(nb.get("id", -1)))
            if j is None:
                continue

            present_j = (np.asarray(j.mask, np.float32) > mask_tau)
            ov = (present_i & present_j)
            if not np.any(ov):
                continue

            # directed weights via central cache + explicit generators
            if Kq > 0:
                wq = directed_kl_weight_after_transport(
                    ch, j,
                    ch.mu_q_field, ch.sigma_q_field,
                    j.mu_q_field,  j.sigma_q_field,
                    fiber="q", H=H, W=W, K=Kq, ov=ov, tau=tau_q,
                    ctx=ctx, G=G_q,
                )
            else:
                wq = np.ones((H, W), np.float32)

            if Kp > 0:
                wp = directed_kl_weight_after_transport(
                    ch, j,
                    ch.mu_p_field, ch.sigma_p_field,
                    j.mu_p_field,  j.sigma_p_field,
                    fiber="p", H=H, W=W, K=Kp, ov=ov, tau=tau_p,
                    ctx=ctx, G=G_p,
                )
            else:
                wp = np.ones((H, W), np.float32)

            # scatter into accumulators at overlap pixels
            iy, ix = np.nonzero(ov)

            # neighbor count (per-pixel)
            np.add.at(nb_count, (iy, ix), 1)

            # update hard-min KL via w → KL = -τ log w
            np.minimum.at(min_kl_q, (iy, ix), (-tau_q * np.log(np.maximum(wq[iy, ix], tiny))).astype(np.float32))
            np.minimum.at(min_kl_p, (iy, ix), (-tau_p * np.log(np.maximum(wp[iy, ix], tiny))).astype(np.float32))

            # softmin sumexp
            np.add.at(sumexp_q, (iy, ix), wq[iy, ix].astype(np.float32))
            np.add.at(sumexp_p, (iy, ix), wp[iy, ix].astype(np.float32))

            # optional coverage weight
            if use_cover_weight:
                np.add.at(cover_weight, (iy, ix), np.asarray(j.mask, np.float32)[iy, ix])

        # finalize softmins on pixels that had ≥1 neighbor
        valid = (nb_count > 0)

        softmin_q = np.zeros_like(sumexp_q, np.float32)
        softmin_p = np.zeros_like(sumexp_p, np.float32)
        softmin_q[valid] = (-sm_tau * np.log(np.maximum(sumexp_q[valid], tiny))).astype(np.float32)
        softmin_p[valid] = (-sm_tau * np.log(np.maximum(sumexp_p[valid], tiny))).astype(np.float32)

        # blended KL softmin and final agreement
        tau_blend = float(alpha) * tau_q + (1.0 - float(alpha)) * tau_p
        KL_blend  = (float(alpha) * softmin_q + (1.0 - float(alpha)) * softmin_p).astype(np.float32)
        A_final   = np.zeros_like(KL_blend, np.float32)
        A_final[valid] = np.exp(-KL_blend[valid] / max(tau_blend, tiny)).astype(np.float32)

        # mask outside child support
        KL_blend  = np.where(present_i, KL_blend,  0.0).astype(np.float32)
        A_final   = np.where(present_i, A_final,   0.0).astype(np.float32)
        softmin_q = np.where(present_i, softmin_q, 0.0).astype(np.float32)
        softmin_p = np.where(present_i, softmin_p, 0.0).astype(np.float32)
        min_kl_q  = np.where(valid & present_i, min_kl_q, np.inf).astype(np.float32)
        min_kl_p  = np.where(valid & present_i, min_kl_p, np.inf).astype(np.float32)
        if use_cover_weight:
            cover_weight = np.where(present_i, cover_weight, 0.0).astype(np.float32)

        # write caches on the child
        ch.spawn_nb_count      = nb_count
        ch.spawn_min_kl_q      = min_kl_q
        ch.spawn_min_kl_p      = min_kl_p
        ch.spawn_softmin_kl_q  = softmin_q
        ch.spawn_softmin_kl_p  = softmin_p
        ch.spawn_cover_weight  = cover_weight if use_cover_weight else None
        ch.spawn_A_final       = A_final

        # convenience aliases used by plots / downstream
        ch.kl_field            = KL_blend
        ch.agreement_field     = A_final

        if debug and np.any(valid & present_i) and not np.all(np.isfinite(KL_blend[present_i])):
            print(f"[spawn-cache] non-finite blended KL for child {int(getattr(ch,'id',-1))}")











#=============================================================================#







def compute_and_set_auto_agree_gate(runtime_ctx, *, percentile=65.0, ema=0.2, use_p_if_q_missing=True):
    """
    Sets runtime_ctx.detector_state.agree_gate_tau_eff to a smoothed percentile
    of A_agg in [0,1]. If no aggregates exist, sets it to None (gate off).
    """
    import numpy as np
    ds = getattr(runtime_ctx, "detector_state", None)
    if ds is None:
        return

    A = getattr(runtime_ctx, "Aq_agg", None)
    if (A is None) and use_p_if_q_missing:
        A = getattr(runtime_ctx, "Ap_agg", None)

    if A is None:
        ds.agree_gate_tau_eff = None
        try:
            print("[AGG] auto agree gate: no aggregates, gate OFF")
        except Exception:
            pass
        return

    A = np.asarray(A, np.float32)
    good = np.isfinite(A)
    if not good.any():
        ds.agree_gate_tau_eff = None
        try:
            print("[AGG] auto agree gate: aggregates non-finite, gate OFF")
        except Exception:
            pass
        return

    thr = float(np.percentile(A[good], float(percentile)))
    prev = getattr(ds, "agree_gate_tau_eff", None)
    if (prev is None) or (not np.isfinite(prev)):
        new_tau = thr
    else:
        new_tau = (1.0 - float(ema)) * float(prev) + float(ema) * thr

    ds.agree_gate_tau_eff = float(new_tau)
    try:
        print(f"[AGG] auto agree gate p{int(percentile)} ema={ema} tau={new_tau:.3f}")
    except Exception:
        pass




def prune_orphan_parents(
    parents_by_id,
    *,
    patience=3,
    min_total_weight=1e-4,
    min_area_nz=5,
    support_tau=0.02,
    respect_grace=True,
    verbose=False,
):
    """
    Remove parents that carry ~no child weight or tiny support for `patience` consecutive steps.
    - Weight check: sum(child_weights) < min_total_weight
    - Area check:   count(mask > support_tau) < min_area_nz
    - Respects each parent's grace window (_grace) if `respect_grace=True`.
    Returns: list of pruned parent ids.
    """
    import numpy as np

    dead = []

    for pid, P in list(parents_by_id.items()):
        # ----- stats (NaN-safe) -----
        wsum = float(sum((getattr(P, "child_weights", {}) or {}).values()))
        if not np.isfinite(wsum):
            wsum = 0.0

        m = np.nan_to_num(np.asarray(getattr(P, "mask", 0.0), np.float32), nan=0.0, posinf=0.0, neginf=0.0)
        nz = int(np.count_nonzero(m > float(support_tau)))

        # ----- grace / age gate -----
        age   = int(getattr(P, "_age", 0) or 0)
        grace = int(getattr(P, "_grace", 0) or 0)
        in_grace = respect_grace and (age < grace)

        ticks = int(getattr(P, "_orphan_ticks", 0) or 0)

        if in_grace:
            # During grace, don't accrue orphan ticks; reset if any evidence appears
            if (wsum >= float(min_total_weight)) or (nz >= int(min_area_nz)):
                ticks = 0
            # else keep ticks at 0 (don’t penalize newborns)
        else:
            # Outside grace: accrue ticks when both signals are weak
            if (wsum < float(min_total_weight)) or (nz < int(min_area_nz)):
                ticks += 1
            else:
                ticks = 0

        P._orphan_ticks = ticks

        if (ticks >= int(patience)) and (not in_grace):
            dead.append(int(pid))

    for pid in dead:
        parents_by_id.pop(pid, None)

    if verbose and dead:
        print(f"[PRUNE] removed {len(dead)} parents: {dead}")

    return dead





# in update_rules_utils.py (or wherever mark_dirty is defined)
def mark_dirty(ctx, *agents, kl=False):
    for a in agents:
        aid = int(getattr(a, "id", id(a)))
        ctx.dirty.agents.add(aid)
        if kl:
            ctx.dirty.kl.add(aid)
            
        # also per-agent flags so local policies can see staleness
        try:
            setattr(a, "_dirty_fields", True)
            if kl:
                setattr(a, "_dirty_kl", True)
        except Exception:
            pass        
      





def take_dirty(ctx, all_agents, *, which="agents"):
    """
    Pop and return the actual objects whose ids are marked dirty.
    which: "agents" (fields/morphisms) or "kl" (KL refresh).
    """
    # tolerate missing ctx.dirty in early boot
    dirty = getattr(ctx, "dirty", None)
    if dirty is None:
        return []
    ids = dirty.agents if which == "agents" else dirty.kl
    subset = _collect_by_ids(all_agents, ids)
    ids.clear()
    return subset



def _rebuild_dirty_morphisms(objs, Gq, Gp, *, ctx=None):
    if not objs:
        return
    # Prefer recompute_agent_morphisms (rectangular, gauge-covariant)
    try:
        from bundle_morphism_utils import recompute_agent_morphisms as _recompute
        use_new = True
    except Exception:
        use_new = False
        try:
            from bundle_coarsegrain_init import CGH_build_morphisms as _legacy_build
        except Exception:
            _legacy_build = None

    for a in objs:
        if a is None:
            continue
        need = (
            getattr(a, "morphisms_dirty", False)
            or getattr(a, "bundle_morphism_q_to_p", None) is None
            or getattr(a, "bundle_morphism_p_to_q", None) is None
        )
        if not need:
            continue
        if use_new:
            _recompute(a, generators_q=Gq, generators_p=Gp, ctx=ctx)
        elif _legacy_build is not None:
            _legacy_build(a, Gq, Gp)
        a.morphisms_dirty = False


def _post_strict(all_agents, params, Gq, Gp, *, ctx=None):
    if not all_agents:
        return
    post = dict(params)
    post["sanitize_strict"] = True
    post["exp_n_jobs"] = 1

    preprocess_all_agents(all_agents, post, Gq, Gp, ctx=ctx)
    build_all_lambda_caches(all_agents, ctx=ctx)
    _rebuild_dirty_morphisms(all_agents, Gq, Gp, ctx=ctx)





def _pre_light(all_agents, params, Gq, Gp, *, ctx=None):
    if not all_agents:
        return
    pre = dict(params)
    pre["sanitize_strict"] = pre.get("sanitize_strict_pre", False)
    pre["exp_n_jobs"] = 1

    # preprocess (build exp caches into ctx.cache)
    preprocess_all_agents(all_agents, pre, Gq, Gp, ctx=ctx)

    # no per-agent Ω caches anymore (centralized via CacheHub)
    # build Λ child maps and parent-side views
    build_all_lambda_caches(all_agents, ctx=ctx)
    

    # mask shape hygiene (once)
    H, W = np.asarray(all_agents[0].mask).shape[:2]
    _standardize_all_masks_once(all_agents, (H, W))

# update_rules_utils.py

def _post_strict_subset(agents_subset, params, generators_q, generators_p, *, ctx=None):
    """
    Strict refresh for a subset:
      preprocess -> Λ caches ->  (optional) morphisms
    """
    if not agents_subset:
        return
    agents_subset = [a for a in agents_subset if a is not None]
    if not agents_subset:
        return

    preprocess_all_agents(agents_subset, params, generators_q, generators_p, ctx=ctx)
    build_all_lambda_caches(agents_subset, ctx = ctx)
    _rebuild_dirty_morphisms(agents_subset, generators_q, generators_p, ctx=ctx)



def _refresh_child_kl_fields_subset(children_subset, all_agents, eps, build_spawn=False, *, ctx=None):
    """
    Legacy entrypoint used by detector/growth passes.
    Delegates to spawn-only MVG cache builder for the given subset.
    """
    if not children_subset:
        return
    try:
        import config as _cfg
        log_eps = float(getattr(_cfg, "log_eps", 1e-9))
    except Exception:
        log_eps = 1e-9

    if build_spawn:
        refresh_spawn_alignment_caches(
            children_subset,
            all_agents,
            eps=float(eps),
            log_eps=log_eps,
            ctx=ctx,   
        )


    





def _standardize_all_masks_once(all_agents, HW):
    from parent_utils import ensure_hw
    for a in all_agents:
        if hasattr(a, "mask"):
            m = getattr(a, "mask", None)
            if m is not None:
                mm = ensure_hw(m, HW)  
                if mm is not m:
                    setattr(a, "mask", mm)




# --- helpers: sparsemax / entmax15 / softmax ---------------------------------
def _softmax(z, mask=None):
    import numpy as np
    z = np.asarray(z, np.float32)
    if mask is not None:
        z = np.where(mask, z, -np.inf)
    z = z - np.nanmax(z, axis=-1, keepdims=True)
    p = np.exp(z)
    p /= np.sum(p, axis=-1, keepdims=True) + 1e-20
    return p

def _sparsemax(z, mask=None):
    """
    Martins & Astudillo (2016). Returns probabilities with exact zeros.
    Works on last axis. O(K log K) per vector.
    """
    import numpy as np
    z = np.asarray(z, np.float32)
    if mask is not None:
        z = np.where(mask, z, -np.inf)
    # replace -inf with very small for sorting
    z_safe = np.where(np.isfinite(z), z, -1e30)
    z_sorted = np.sort(z_safe, axis=-1)[:, ::-1]
    k = np.arange(1, z.shape[-1] + 1, dtype=np.float32)
    z_cumsum = np.cumsum(z_sorted, axis=-1)
    # find k* s.t. 1 + k z̄_k > sum
    rhs = 1.0 + k * z_sorted
    cond = rhs > z_cumsum
    k_star = cond.sum(axis=-1)  # [N]
    # tau = (sum_{i<=k*} z_i - 1) / k*
    # gather prefix sums at k*
    idx = (k_star - 1).clip(min=0)
    tau = (z_cumsum[np.arange(z.shape[0]), idx] - 1.0) / np.maximum(k_star, 1)
    p = np.maximum(z - tau[:, None], 0.0)
    # renormalize tiny numerical drift
    Z = np.sum(p, axis=-1, keepdims=True) + 1e-20
    return p / Z

def _entmax15(z, mask=None, iters=50, tol=1e-6):
    """
    Entmax with alpha=1.5 (Peters et al., 2019). Proper sparse probabilities.
    We use a simple per-row bisection for tau. K is small here, so fine.
    """
    import numpy as np
    z = np.asarray(z, np.float32)
    if mask is not None:
        z = np.where(mask, z, -np.inf)
    z_safe = np.where(np.isfinite(z), z, -1e30)

    # upper/lower bounds for tau
    lo = np.min(z_safe, axis=-1) - 1.0
    hi = np.max(z_safe, axis=-1)
    lo = lo[:, None]; hi = hi[:, None]

    def proj(tau):
        u = np.maximum(0.0, z_safe - tau)
        return u ** 2.0

    for _ in range(iters):
        mid = (lo + hi) * 0.5  # [N,1]
        s = np.sum(proj(mid), axis=-1, keepdims=True)
        # sum u^2 should be 1 for alpha=1.5 projection
        hi = np.where(s > 1.0, mid, hi)
        lo = np.where(s > 1.0, lo, mid)
        if np.max(np.abs(hi - lo)) < tol:
            break
    tau = (lo + hi) * 0.5
    p = np.maximum(0.0, z_safe - tau) ** 2.0
    Z = np.sum(p, axis=-1, keepdims=True) + 1e-20
    return p / Z


def _as_parent_dict(obj):
    """
    Normalize parents -> {pid: Parent}. Accepts dict, list, iterable, or None.
    Uses the parent's .id if present; else falls back to enumerate index.
    """
    import collections.abc as _abc
    if obj is None:
        return {}
    if isinstance(obj, dict):
        return {int(getattr(p, "id", pid)): p for pid, p in obj.items()}
    if isinstance(obj, _abc.Iterable):
        return {int(getattr(p, "id", i)): p for i, p in enumerate(obj)}
    # Single parent object?
    return {int(getattr(obj, "id", 0)): obj}

# ======================== helpers (place near module top) =====================

try:
    import config as _CFG_MOD
    def CFG(name, default=None):
        return getattr(_CFG_MOD, name, default)
except Exception:
    def CFG(name, default=None):  # fallback
        return default

import numpy as _np

def _mask_gate(m, tau):
    """Keep graded weight but zero out below τ."""
    m = _np.asarray(m, _np.float32)
    return (m >= tau).astype(_np.float32) * m

def _support_bool(m, tau):
    """Boolean presence above τ."""
    return _np.asarray(m, _np.float32) >= tau

def _agreement_prior_map(agree_map, H, W):
    """Resizes/clamps an optional agreement prior A(x)∈[0,1] to (H,W) or returns None."""
    if agree_map is None:
        return None
    A = _np.asarray(agree_map, _np.float32)
    if A.shape != (H, W):
        from parent_utils import resize_nn
        A = resize_nn(A, (H, W))
    return _np.clip(_np.nan_to_num(A, nan=1.0, posinf=1.0, neginf=0.0), 0.0, 1.0)

def _capture_prev_masks(ctx):
    """Return {pid:int -> mask copy} for change detection."""
    parents_dict = getattr(ctx, "parents_by_region", {}) or {}
    out = {}
    for pid, P in parents_dict.items():
        if P is None or getattr(P, "mask", None) is None:
            continue
        out[int(getattr(P, "id", pid))] = _np.asarray(P.mask, _np.float32).copy()
    return out

def _detect_changed_parents(ctx, prev_masks, change_tol=None):
    """Return [P,...] whose mask changed beyond tol (shape or max|Δ|)."""
    tol = float(CFG("parent_mask_change_tol", 1e-8) if change_tol is None else change_tol)
    changed = []
    parents_dict = getattr(ctx, "parents_by_region", {}) or {}
    for pid, P in parents_dict.items():
        if P is None or getattr(P, "mask", None) is None:
            continue
        key = int(getattr(P, "id", pid))
        before = prev_masks.get(key)
        now = _np.asarray(P.mask, _np.float32)
        if before is None or now.shape != before.shape:
            changed.append(P); continue
        if float(_np.max(_np.abs(now - before))) > tol:
            changed.append(P)
    return changed

# ==============================================================================


# --- core: from scores -> logits -> probs (with null) -------------------------
def _normalize_assignments(scores, agree=None, valid_mask=None, *,
                           temp=0.25, activation="softmax",
                           agree_weight=1.0, null_enabled=True,
                           null_logit=0.0, calibrate=None):
    """
    scores: [N_parents] raw similarity/alignment per child
    agree:  [N_parents] agreement in [0,1]
    valid_mask: bool mask of admissible parents
    temp: base temperature
    activation: "softmax" | "sparsemax" | "entmax15"
    agree_weight: coefficient on log-agreement
    null_enabled: include 'null' option
    null_logit: prior logit for null
    calibrate: optional dict { 'target_H': float, 'k': float } for temp calibration
    """
    import numpy as np
    z = np.asarray(scores, np.float32)

    # convert multiplicative agree -> additive in logit space
    if agree is not None:
        a = np.clip(np.asarray(agree, np.float32), 1e-6, 1.0)
        z = z + float(agree_weight) * np.log(a)

    # temperature
    t = float(temp)
    if calibrate is not None and calibrate.get("target_H") is not None:
        # one-step exponential correction toward target entropy (cheap, stable)
        target_H = float(calibrate["target_H"])
        kappa    = float(calibrate.get("k", 0.5))
        sm = _softmax(z / max(1e-8, t), mask=valid_mask)
        H = -np.sum(sm * (np.log(sm + 1e-20)), axis=-1)
        # increase temp if too peaky (H < target), decrease if too flat
        t = t * float(np.exp(kappa * (target_H - H)))

    logits = z / max(1e-8, t)

    # attach null option (last index)
    if null_enabled:
        if valid_mask is None:
            vm = None
        else:
            vm = np.concatenate([valid_mask.astype(bool), np.array([True])], axis=-1)
        logits = np.concatenate([logits, np.array([float(null_logit)], dtype=np.float32)], axis=-1)
    else:
        vm = valid_mask

    # pick activation
    if activation == "sparsemax":
        p = _sparsemax(logits[None, :], mask=None if vm is None else vm[None, :])[0]
    elif activation in ("entmax", "entmax15"):
        p = _entmax15(logits[None, :], mask=None if vm is None else vm[None, :])[0]
    else:
        p = _softmax(logits[None, :], mask=None if vm is None else vm[None, :])[0]

    return p



