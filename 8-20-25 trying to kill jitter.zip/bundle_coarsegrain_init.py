# -*- coding: utf-8 -*-
"""
Created on Tue Aug 12 18:56:28 2025

@author: chris and christine
"""

from __future__ import annotations
import numpy as np
import config
from preprocess_utils import preprocess_all_agents
from transport_cache import Lambda_up, warm_E


# --- add below your existing helpers inside bundle_coarsegrain_init.py ---
def _soft_support(mask_2d: np.ndarray) -> np.ndarray:
    import numpy as np, config
    tau = float(getattr(config, "support_cutoff_eps", 1e-3))
    return (np.asarray(mask_2d, np.float32) > tau)

def _periodic_parent_coarsegrain(ctx, children, Gq, Gp, params):
    """
    Run canonical coarse-graining for every existing parent, on a fixed period.

    Runtime-cache design:
      - Preprocess ONLY children (ensures φ/φ̃, Φ/Φ̃, μ/Σ are sane).
      - Do NOT prebuild Λ caches; Lambda_up(...) pulls from the central cache.
      - Each parent is coarse-grained independently; CG warms exp grids as needed.
    """
    import numpy as np, config

    parents_dict = getattr(ctx, "parents_by_region", {}) or {}
    parents = [p for p in parents_dict.values() if p is not None]
    if not parents:
        return {"cg_ok": 0, "cg_fail": 0}

    # schedule
    step_now = int(getattr(ctx, "global_step", 0))
    period = int(getattr(config, "parent_cg_period", params.get("parent_cg_period", 50)))
    if period <= 0 or (step_now % period) != 0:
        return {"cg_ok": 0, "cg_fail": 0}

    cg_eps = float(getattr(config, "cg_eps", 1e-6))
    # Use the same cutoff the CG uses for child support (not a high mask-level τ)
    cg_tau = float(getattr(config, "support_tau",
                           getattr(config, "support_cutoff_eps", 1e-4)))

    # 1) preprocess only children (keeps parents lazy/fixed-up inside CG)
    child_only = [c for c in (children or []) if c is not None]
    if child_only:
        try:
            preprocess_all_agents(child_only, params, G_q=Gq, G_p=Gp, ctx=ctx)
        except Exception as e:
            print(f"[CG] preprocess(children) failed: {e}")

    # 2) coarse-grain per-parent
    cg_ok, cg_fail = 0, 0
    write_tau = float(getattr(config, "parent_phi_write_tau",
                              getattr(config, "support_cutoff_eps", 1e-4)))

    for P in parents:
        try:
            # quick skip: empty/degenerate parent masks
            m = np.asarray(getattr(P, "mask", None))
            if m is None or m.size == 0 or not np.any(m > write_tau):
                continue

            coarsegrain_parent_from_children(
                P, children,
                eps=cg_eps,
                mask_tau=cg_tau,
                G_q=Gq,
                G_p=Gp,
                ctx=ctx,
            )
            cg_ok += 1
        except Exception as e:
            pid = getattr(P, "id", "?")
            print(f"[CG] periodic coarsegrain failed for parent {pid}: {e}")
            cg_fail += 1

    return {"cg_ok": cg_ok, "cg_fail": cg_fail}



# =========================
# main coarsegrainer
# =========================


def coarsegrain_parent_from_children(
    P, children, *, eps=1e-6, mask_tau=None, G_q=None, G_p=None, ctx=None
):
    """
    Fast RG coarse-grain — Λ_up maps + sparse tiling, with automatic fast paths.

    Flow:
      1) Resolve cache ns, sizes, and parent “core” (for eff gating only).
      2) Collect (child, weight) pairs from P.child_weights (filtered >0).
      3) Allocate μ/Σ accumulators (q & p).
      4) For each child with overlap:
           a) eff = core ∧ (child.mask > τ)   # cached
           b) grab flattened (μ,Σ,Λ_up) views # cached
           c) accumulate moments per sparse tile (first-order iff Λ≈I)
           d) stash φ/φ̃ fields + per-pixel weights + scalar tallies
      5) Finalize μ/Σ into parent.
      6) Smoothly **extend μ/Σ to the whole soft support** (periodic harmonic inpaint).
      7) Aggregate φ/φ̃ (small-angle fast path → Karcher fallback),
         then smoothly **extend φ/φ̃** to the whole soft support.
      8) Ensure newborn morphisms; attach generators.
    """
    import numpy as np, config

    ns_misc = resolve_cache_ns(ctx)  # CacheHub ns('misc') or a dict

    # ---- sizes / thresholds --------------------------------------------------------
    H, W = P.mask.shape[:2]
    Kq = int(P.mu_q_field.shape[-1])
    Kp = int(P.mu_p_field.shape[-1])

    core = compute_core_mask(
        P, ns_misc,
        core_tau=float(getattr(config, "core_abs_tau", 0.20)),
    )
    if not np.any(core):
        return {}

    tau = float(mask_tau if mask_tau is not None
                else getattr(config, "support_cutoff_eps", 1e-4))

    pairs = collect_child_pairs(P, children)
    if not pairs:
        return {}

    # ---- accumulators --------------------------------------------------------------
    Wsum_q, mu_acc_q, Sig_acc_q = alloc_fiber_accumulators(H, W, Kq)
    Wsum_p, mu_acc_p, Sig_acc_p = alloc_fiber_accumulators(H, W, Kp)

    # φ/φ̃ aggregation inputs
    phi_list_q, w_list_q, phi_wts_q = [], [], []
    phi_list_p, w_list_p, phi_wts_p = [], [], []

    # Tunables
    TILE = int(getattr(config, "cg_tile_pixels", 32768))
    tau_L = float(getattr(config, "lambda_near_identity_tau", 5e-2))
    force_exact_push = bool(getattr(config, "force_exact_sigma_push", False))
    use_L_first_order = bool(getattr(config, "use_first_order_sigma_push", True)) and not force_exact_push

    pid = int(getattr(P, "id", -1))

    # ---- main loop over children ---------------------------------------------------
    for child, w in pairs:
        if w <= 0:
            continue

        eff = get_eff_mask_cached(ns_misc, P, child, tau, H, W, core)
        if not np.any(eff):
            continue

        # Warm exp grids (central cache) and fetch Λ_up maps
        if ctx is not None:
            try:
                whiches = tuple(wch for wch, kdim in (("q", Kq), ("p", Kp)) if kdim)
                if whiches:
                    warm_E(ctx, [child, P], whiches=whiches)
            except Exception:
                pass

        Lq = Lambda_up(ctx, child, P, which="q") if Kq else None
        Lp = Lambda_up(ctx, child, P, which="p") if Kp else None
        if (Kq and Lq is None) or (Kp and Lp is None):
            continue

        # Flattened views (cached)
        mu_q_f, sg_q_f, mu_p_f, sg_p_f, Lq_f, Lp_f = get_flattened_views(
            ns_misc, P, child, Lq, Lp, Kq, Kp, H, W
        )

        # Sparse index + weights over overlap
        idx = indices_of(eff)
        if idx.size == 0:
            continue
        w_sp = (w * eff.astype(np.float32)).reshape(-1)  # (H*W,)

        # φ/φ̃ fields + per-pixel weights for aggregation
        eff_f32 = eff.astype(np.float32)
        if Kq and getattr(child, "phi", None) is not None:
            phi_list_q.append(child.phi)                 # (H,W,3)
            w_list_q.append(eff_f32 * w)                 # (H,W)
            phi_wts_q.append(float(idx.size) * float(w)) # scalar
        if Kp and getattr(child, "phi_model", None) is not None:
            phi_list_p.append(child.phi_model)           # (H,W,3)
            w_list_p.append(eff_f32 * w)                 # (H,W)
            phi_wts_p.append(float(idx.size) * float(w))

        # Decide first-order vs exact push per fiber (using flattened rows)
        q_first_ok = (Kq and use_L_first_order and _near_identity_ok(Lq_f, tau_L))
        p_first_ok = (Kp and use_L_first_order and _near_identity_ok(Lp_f, tau_L))

        # Tile over sparse rows
        for ids in tile_slices(idx, tile=TILE):
            wv = w_sp[ids][:, None]  # (T,1)

            if Kq:
                accumulate_fiber_rows(
                    ids=ids,
                    wv=wv,
                    w_sp=w_sp,
                    mu_f=mu_q_f, sg_f=sg_q_f, L_f=Lq_f, K=Kq,
                    Wsum=Wsum_q, mu_acc=mu_acc_q, Sig_acc=Sig_acc_q,
                    use_first_order=q_first_ok, tau_L=tau_L,
                )

            if Kp:
                accumulate_fiber_rows(
                    ids=ids,
                    wv=wv,
                    w_sp=w_sp,
                    mu_f=mu_p_f, sg_f=sg_p_f, L_f=Lp_f, K=Kp,
                    Wsum=Wsum_p, mu_acc=mu_acc_p, Sig_acc=Sig_acc_p,
                    use_first_order=p_first_ok, tau_L=tau_L,
                )

    # ---- finalize μ/Σ into parent (evidence region only) --------------------------
    if Kq:
        finalize_fiber_into_parent(
            Wsum=Wsum_q, mu_acc=mu_acc_q, Sig_acc=Sig_acc_q,
            P_mu=P.mu_q_field, P_Sigma=P.sigma_q_field,
            eps=eps, K=Kq,
        )
    if Kp:
        finalize_fiber_into_parent(
            Wsum=Wsum_p, mu_acc=mu_acc_p, Sig_acc=Sig_acc_p,
            P_mu=P.mu_p_field, P_Sigma=P.sigma_p_field,
            eps=eps, K=Kp,
        )

    # ---- extend μ/Σ to the full soft support (periodic harmonic inpaint) ----------
    support = _soft_support(P.mask)

    if Kq:
        cover_q = (Wsum_q > 0.0)
        # μ_q : vector inpaint
        mu_q_full = _harmonic_inpaint_vec(P.mu_q_field.astype(np.float32), cover_q, support, iters=8)
        P.mu_q_field = np.where(support[..., None], mu_q_full, P.mu_q_field.astype(np.float32))
        # Σ_q : SPD inpaint (log-Euclidean)
        sig_q_full = _harmonic_inpaint_spd(P.sigma_q_field.astype(np.float32), cover_q, support, iters=6, eps=eps)
        P.sigma_q_field = np.where(support[..., None, None], sig_q_full, P.sigma_q_field.astype(np.float32))

    if Kp:
        cover_p = (Wsum_p > 0.0)
        mu_p_full = _harmonic_inpaint_vec(P.mu_p_field.astype(np.float32), cover_p, support, iters=8)
        P.mu_p_field = np.where(support[..., None], mu_p_full, P.mu_p_field.astype(np.float32))
        sig_p_full = _harmonic_inpaint_spd(P.sigma_p_field.astype(np.float32), cover_p, support, iters=6, eps=eps)
        P.sigma_p_field = np.where(support[..., None, None], sig_p_full, P.sigma_p_field.astype(np.float32))

    # ---- φ/φ̃ aggregation (fast small-angle → Karcher fallback) --------------------
    if Kq and phi_list_q:
        phi_q = aggregate_phi_field(
            P=P, which="q",
            phi_list=phi_list_q, w_list=w_list_q, scalar_wts=phi_wts_q,
            G=getattr(P, "generators_q", G_q),
            H=H, W=W,
        )
        if phi_q is not None:
            # extend to full support (same inpaint as μ)
            phi_q_full = _harmonic_inpaint_vec(phi_q.astype(np.float32),
                                               cover=(Wsum_q > 0.0),
                                               support=support,
                                               iters=6)
            prev = P.phi if getattr(P, "phi", None) is not None else np.zeros_like(phi_q_full, np.float32)
            P.phi = np.where(support[..., None], phi_q_full, prev)

    if Kp and phi_list_p:
        phi_p = aggregate_phi_field(
            P=P, which="p",
            phi_list=phi_list_p, w_list=w_list_p, scalar_wts=phi_wts_p,
            G=getattr(P, "generators_p", G_p),
            H=H, W=W,
        )
        if phi_p is not None:
            phi_p_full = _harmonic_inpaint_vec(phi_p.astype(np.float32),
                                               cover=(Wsum_p > 0.0),
                                               support=support,
                                               iters=6)
            prev = P.phi_model if getattr(P, "phi_model", None) is not None else np.zeros_like(phi_p_full, np.float32)
            P.phi_model = np.where(support[..., None], phi_p_full, prev)

    # ---- newborn morphisms + remember generators -----------------------------------
    ensure_parent_morphisms_if_missing(P, G_q, G_p, ctx)
    attach_generators_to_parent(P, G_q, G_p)

    return {}



# -------- morphisms + generators -------------------------------------------------
def ensure_parent_morphisms_if_missing(P, G_q, G_p, ctx):
    """
    Initializes parent bundle morphisms for newborns if missing.
    """
    try:
        from bundle_morphism_utils import have_parent_morphisms, init_parent_morphisms
        if not have_parent_morphisms(P):
            init_parent_morphisms(P, G_q, G_p, ctx=ctx)
    except Exception:
        pass





#==============================================================================
#
#          # ========================== bundle_coarsegrain_utils.py ==========================
#                    All helpers used by the orchestrator. Pure functions where possible.
#
#===============================================================================



# ============================ Local helper implementations ============================

def near_identity_mask(L: np.ndarray, tau_L: float) -> np.ndarray:
    """
    Return a boolean mask over the first dimension of L selecting rows where
    the linear map is 'near identity' under Frobenius norm.
    L: (T, K, K)
    tau_L: threshold on ||L - I||_F / ||I||_F (dimensionless)
    """
    T, K, _ = L.shape
    I = np.eye(K, dtype=L.dtype)
    diff = L - I  # (T, K, K)
    num = np.linalg.norm(diff.reshape(T, -1), axis=1)
    den = np.linalg.norm(I.reshape(-1))  # = sqrt(K)
    return (num / max(den, 1.0)) <= float(tau_L)


def push_mu_sigma_exact(mu: np.ndarray, Sigma: np.ndarray, L: np.ndarray):
    """
    Exact pushforward of Gaussian moments through linear map x' = L x.
    mu:    (T, K)
    Sigma: (T, K, K)
    L:     (T, K, K)
    Returns:
      (mu', Sigma') with shapes (T, K), (T, K, K)
    """
    # μ' = L μ
    mu_p = (L @ mu[..., None])[..., 0]
    # Σ' = L Σ L^T   (vectorized via einsum)
    Sig_p = np.einsum("tij, tjk, tlk -> til", L, Sigma, L, optimize=True)
    return mu_p, Sig_p


def push_mu_sigma_first_order(mu: np.ndarray, Sigma: np.ndarray, L: np.ndarray):
    """
    First-order push for near-identity L = I + A (small A):
      μ'   ≈ μ + A μ
      Σ'   ≈ Σ + A Σ + Σ A^T
    Shapes like the exact version.
    """
    T, K = mu.shape
    I = np.eye(K, dtype=L.dtype)
    A = L - I
    mu_p = mu + (A @ mu[..., None])[..., 0]
    # A Σ + Σ A^T
    A_S  = np.einsum("tij, tjk -> tik", A, Sigma, optimize=True)
    S_AT = np.einsum("tij, tik -> tjk", A, Sigma, optimize=True)  # (A Σ)^T wrt last two dims
    Sig_p = Sigma + A_S + np.swapaxes(S_AT, -1, -2)
    return mu_p, Sig_p


# === bundle_coarsegrain_init.py: guards for fast/ exact paths =================

def _small_angle_ok(phi_list, *, abs_tau: float, spread_tau: float) -> bool:
    """Cheap predicate: accept fast φ-mean iff magnitudes are small and concentrated."""
    import numpy as np
    if not phi_list:
        return False
    X = np.stack(phi_list, axis=0)   # (n,H,W,3) or (n,3)
    norms = np.linalg.norm(X, axis=-1)
    return (np.nanmax(norms) <= abs_tau) and (np.nanstd(norms) <= spread_tau)


def _near_identity_ok(Lf, tau_L: float) -> bool:
    """
    Accept first-order push iff Λ is near-identity on the rows we will actually use.
    Lf is flattened (T,K,K) rows for the effective pixels.
    """
    import numpy as np
    if Lf is None or Lf.size == 0:
        return False
    T, K, _ = Lf.shape
    I = np.eye(K, dtype=Lf.dtype)
    diff = Lf - I
    # dimensionless Frobenius ratio
    num = np.linalg.norm(diff.reshape(T, -1), axis=1)
    den = np.sqrt(float(K))
    return bool((num <= tau_L * den).all())


# -------- φ/φ̃ aggregation (no helpers dict) ---------------------------------
# in bundle_coarsegrain_init.py (or wherever _try_fast_small_angle lives)


# -------- φ/φ̃ aggregation (no helpers dict) ---------------------------------
def _try_fast_small_angle(P, which, phi_list, w_list, scalar_wts):
    """
    Small-angle fast mean using per-pixel weights ONLY.
    If per-pixel weights are unavailable/invalid, bail to Karcher.
    """
    import numpy as np, config
    if not phi_list or getattr(config, "force_exact_phi_mean", False):
        return False, None

    tau_abs = float(getattr(config, "phi_small_abs", 5e-2))
    tau_sp  = float(getattr(config, "phi_small_spread", 5e-2))

    Pmat = np.stack(phi_list, axis=0).astype(np.float32)   # (n,H,W,3)
    norms = np.linalg.norm(Pmat, axis=-1)
    if (np.nanmax(norms) > tau_abs) or (np.nanstd(norms) > tau_sp):
        return False, None

    # require per-pixel weights
    if not w_list or len(w_list) != Pmat.shape[0]:
        return False, None
    try:
        Wts = np.stack(w_list, axis=0).astype(np.float32)  # (n,H,W)
    except Exception:
        return False, None
    if Wts.ndim != 3 or Wts.shape[1:] != Pmat.shape[1:3]:
        return False, None

    Wts = np.clip(Wts, 0.0, np.inf)
    Wsum = Wts.sum(axis=0)                                 # (H,W)
    has_cov = (Wsum > 0)
    if not np.any(has_cov):
        return False, None

    phi_bar = (Wts[..., None] * Pmat).sum(axis=0) / np.maximum(Wsum, 1e-12)[..., None]
    phi_bar[~has_cov, :] = 0.0
    return True, phi_bar.astype(np.float32)




def aggregate_phi_field(*, P, which, phi_list, w_list, scalar_wts, G, H, W):
    """
    1) Try small-angle fast mean (only if small); else
    2) Irrep Karcher mean (group-correct).
    """
    if not phi_list:
        return None

    used_fast, phi_bar = _try_fast_small_angle(P, which, phi_list, scalar_wts, G)
    if used_fast and phi_bar is not None:
        return phi_bar

    # group-correct fallback (algebraic Karcher)
    return CGH_karcher_mean_phi_irrep(
        phi_list, w_list, H, W, G,
        iters=int(getattr(config, "cg_phi_iters", 6)),
        eta=float(getattr(config, "cg_phi_eta", 0.5)),
        tol=float(getattr(config, "cg_phi_tol", 1e-7)),
        step_clip=float(getattr(config, "cg_phi_step_clip", 1.5)),
        abs_clip=float(getattr(config, "cg_phi_abs_clip", 4.0)),
        init=phi_bar,
        max_iters_small=int(getattr(config, "cg_phi_refine_small", 2)),
    )





def fast_mean_phi_small_angle(
    Pmat: np.ndarray,
    *,
    weights: np.ndarray | None,
    tau_abs: float,
    tau_spread: float
):
    """
    Small-angle mean of algebra 3-vectors φ with accept/reject gate.

    Pmat:    (n, H, W, 3) or (n, 3)
    weights: (n,) or None (nonnegative)
    Accept if:
      max ||φ_i||₂ <= tau_abs and std(||φ_i||₂) <= tau_spread  (elementwise per-pixel if H,W given)
    Returns: (ok: bool, phi_bar: same spatial shape as single φ or None)
    """
    Pmat = np.asarray(Pmat)
    if Pmat.ndim == 2 and Pmat.shape[1] == 3:
        # no spatial dims
        norms = np.linalg.norm(Pmat, axis=-1)  # (n,)
        ok = (norms.max() <= tau_abs) and (norms.std() <= tau_spread)
        if not ok:
            return False, None
        if weights is None:
            phi_bar = Pmat.mean(axis=0)
        else:
            w = np.clip(weights.astype(np.float64), 0.0, np.inf)
            if w.sum() <= 0 or not np.isfinite(w).all():
                phi_bar = Pmat.mean(axis=0)
            else:
                w = w / w.sum()
                phi_bar = (w[:, None] * Pmat).sum(axis=0)
        return True, phi_bar.astype(np.float32)

    # spatial case: (n, H, W, 3)
    n, H, W, _ = Pmat.shape
    norms = np.linalg.norm(Pmat, axis=-1)  # (n, H, W)
    ok = (norms.max(axis=0) <= tau_abs) & (norms.std(axis=0) <= tau_spread)  # (H, W)

    if weights is None:
        phi_bar = Pmat.mean(axis=0)  # (H, W, 3)
    else:
        w = np.clip(weights.astype(np.float64), 0.0, np.inf)
        if w.sum() <= 0 or not np.isfinite(w).all():
            phi_bar = Pmat.mean(axis=0)
        else:
            w = (w / w.sum()).reshape(n, 1, 1, 1)
            phi_bar = (w * Pmat).sum(axis=0)

    # Return φ̄ only where accepted; elsewhere None-signaled by caller via fallback
    if not np.any(ok):
        return False, None
    # Optionally zero-out rejected pixels to make a partial init; caller can still fall back
    phi_bar = phi_bar.astype(np.float32)
    return True, phi_bar


def CGH_karcher_mean_phi_irrep(
    phi_list, w_list, H, W, G,
    *,
    iters: int = 6,
    eta: float = 0.5,
    tol: float = 1e-7,
    step_clip: float = 1.5,
    abs_clip: float = 4.0,
    init=None,
    max_iters_small: int = 2
):
    """
    Practical algebra-space Karcher-like mean for φ (SO(3) algebra coefficients).
    - Works directly on 3-vectors (coeffs of generators); no per-agent caches.
    - If 'init' provided, starts there; else weighted Euclidean mean.
    - Uses clipped gradient steps on the Euclidean surrogate; adequate in practice
      for small-to-moderate angles and matches your 'algebraic' preference.
    - 'G' is accepted for signature compatibility (irrep generators), but this
      routine operates in coefficient space and does not require exp/log.

    Returns φ̄ with shape (H, W, 3).
    """
    import numpy as np

    n = len(phi_list)
    if n == 0:
        return None
    # stack inputs
    X = np.stack(phi_list, axis=0).astype(np.float64)  # (n, H, W, 3)
    if X.ndim == 2 and X.shape[1] == 3:
        X = X[:, None, None, :]  # broadcast to (n,1,1,3) for uniform handling
        H, W = 1, 1

    if w_list is None or len(w_list) != n:
        Wts = np.ones((n, H, W, 1), dtype=np.float64)
    else:
        Wts = np.stack(w_list, axis=0)[..., None].astype(np.float64)  # (n,H,W,1)
        Wts = np.clip(Wts, 0.0, np.inf)

    Wsum = np.maximum(Wts.sum(axis=0), 1e-12)  # (H,W,1)

    # init
    if init is None:
        phi_bar = (Wts * X).sum(axis=0) / Wsum  # (H,W,3)
    else:
        phi_bar = np.asarray(init, dtype=np.float64)
        if phi_bar.ndim == 1 and phi_bar.shape[0] == 3:
            phi_bar = phi_bar[None, None, :]

    # iterations
    for _ in range(max(1, int(iters))):
        # residual (Euclidean surrogate for log on group)
        R = X - phi_bar  # (n,H,W,3)

        # weighted average residual
        grad = (Wts * R).sum(axis=0) / Wsum  # (H,W,3)

        # step clipping
        step_norm = np.linalg.norm(grad, axis=-1, keepdims=True)  # (H,W,1)
        clip = np.maximum(1.0, step_norm / max(step_clip, 1e-12))
        step = (grad / clip)

        # update
        phi_new = phi_bar + float(eta) * step

        # absolute clip for robustness
        absn = np.linalg.norm(phi_new, axis=-1, keepdims=True)
        over = absn > float(abs_clip)
        if np.any(over):
            phi_new[over[..., 0]] *= (abs_clip / np.maximum(absn[over], 1e-12))

        # convergence check
        delta = np.linalg.norm((phi_new - phi_bar).reshape(-1, 3), axis=1).mean()
        phi_bar = phi_new
        if delta <= float(tol):
            break

    return phi_bar.astype(np.float32)
# ========================= /Local helper implementations =========================


# -------- cache + shapes ---------------------------------------------------------
def resolve_cache_ns(ctx):
    """
    Returns a mutable mapping for ns('misc').
    Falls back to a simple dict if no CacheHub exists.
    """
    if ctx is None:
        return {}
    hub = getattr(ctx, "cache", None)
    return hub.ns("misc") if hub is not None else {}


def compute_core_mask(P, ns_misc, *, core_tau):
    """
    Cached parent 'core' support: mask > max(core_tau, 0.5*peak).
    Keyed by (cg_core, pid, core_tau, peak, H, W).
    """
    H, W = P.mask.shape[:2]
    pid = int(getattr(P, "id", -1))
    peak = float(P.mask.max() if P.mask.size else 0.0)
    key = ("cg_core", pid, float(core_tau), peak, H, W)
    core = ns_misc.get(key)
    if core is None:
        core = (np.asarray(P.mask, np.float32) > max(float(core_tau), 0.5 * peak))
        ns_misc[key] = core
    return core


def collect_child_pairs(P, children):
    """
    Returns filtered list of (child, weight) with weight > 0.
    Uses P.child_weights to determine per-child weight.
    """
    wmap = getattr(P, "child_weights", {}) or {}
    pairs = []
    for c in (children or []):
        if c is None:
            continue
        w = float(wmap.get(int(getattr(c, "id", -1)), 0.0))
        if w > 0.0:
            pairs.append((c, w))
    return pairs


def alloc_fiber_accumulators(H, W, K):
    if K <= 0:
        # Use empty arrays to simplify call sites
        Z = np.zeros((H, W), np.float32)
        return Z, np.zeros((H, W, 0), np.float32), np.zeros((H, W, 0, 0), np.float32)
    Wsum = np.zeros((H, W), np.float32)
    mu_acc = np.zeros((H, W, K), np.float32)
    Sig_acc = np.zeros((H, W, K, K), np.float32)
    return Wsum, mu_acc, Sig_acc


# -------- sparse indexing / tiling ----------------------------------------------
def indices_of(mask_bool):
    return np.flatnonzero(np.asarray(mask_bool, dtype=bool).reshape(-1))


def tile_slices(idx, *, tile=65536):
    for s in range(0, idx.size, tile):
        yield idx[s : s + tile]


# -------- per-(parent,child) cached views ---------------------------------------
def get_flattened_views(ns_misc, P, child, Lq, Lp, Kq, Kp, H, W):
    """
    Returns flattened (view) arrays for μ, Σ, Λ in q/p fibers, cached by (P,c).
    """
    pid = int(getattr(P, "id", -1))
    cid = int(getattr(child, "id", -1))
    key = ("cg_flat", pid, cid, Kq, Kp, H, W)
    cached = ns_misc.get(key)
    if cached is None:
        mu_q_f = child.mu_q_field.reshape(-1, Kq) if Kq else None
        sg_q_f = child.sigma_q_field.reshape(-1, Kq, Kq) if Kq else None
        mu_p_f = child.mu_p_field.reshape(-1, Kp) if Kp else None
        sg_p_f = child.sigma_p_field.reshape(-1, Kp, Kp) if Kp else None
        Lq_f = Lq.reshape(-1, Kq, Kq) if (Kq and Lq is not None) else None
        Lp_f = Lp.reshape(-1, Kp, Kp) if (Kp and Lp is not None) else None
        cached = (mu_q_f, sg_q_f, mu_p_f, sg_p_f, Lq_f, Lp_f)
        ns_misc[key] = cached
    return cached


def get_eff_mask_cached(ns_misc, P, child, tau, H, W, core):
    """
    Effective per-(parent,child) mask: eff = core ∧ (child.mask > τ), cached by (P,c,τ).
    """
    pid = int(getattr(P, "id", -1))
    cid = int(getattr(child, "id", -1))
    key = ("cg_eff", pid, cid, float(tau), H, W)
    eff = ns_misc.get(key)
    if eff is None:
        c_mask = (np.asarray(child.mask, np.float32) > float(tau))
        eff = (core & c_mask)
        ns_misc[key] = eff
    return eff


# -------- accumulation kernel (generic for q/p fiber) ---------------------------
def _push_mu_sigma_exact_fallback(mu, sg, L):
    """
    Fallback exact push when helper isn't available:
      μ' = L μ
      Σ' = L Σ L^T  (symmetrized)
    """
    mu_ex = np.einsum("tij,tj->ti", L, mu, optimize=True)
    S_ex = np.einsum("tij,tjk,tlk->til", L, sg, L, optimize=True)
    S_ex = 0.5 * (S_ex + np.swapaxes(S_ex, -1, -2))
    return mu_ex, S_ex




# -------- finalize μ/Σ into parent fields --------------------------------------
def finalize_fiber_into_parent(*, Wsum, mu_acc, Sig_acc, P_mu, P_Sigma, eps, K):
    """
    Normalizes accumulators and writes μ/Σ into parent field arrays.
    Ensures Σ is SPD via symmetrization + eps·I.
    """
    if K <= 0:
        return
    valid = (Wsum > 0)
    if not np.any(valid):
        return

    den = np.maximum(Wsum[..., None, None], 1e-12).astype(np.float64)
    Sig = (Sig_acc.astype(np.float64) / den)
    Sig = 0.5 * (Sig + np.swapaxes(Sig, -1, -2)) + float(eps) * np.eye(K, dtype=np.float64)

    muP = np.zeros_like(P_mu, dtype=np.float64)
    muP[valid] = (mu_acc.astype(np.float64)[valid] / Wsum[valid, None])

    P_mu[valid]    = muP[valid].astype(np.float32)
    P_Sigma[valid] = Sig[valid].astype(np.float32)


def accumulate_fiber_rows(
    *,
    ids, wv, w_sp,
    mu_f, sg_f, L_f, K,
    Wsum, mu_acc, Sig_acc,
    use_first_order, tau_L
):
    """
    Accumulates pushed moments for a set of row indices (ids) into (Wsum, mu_acc, Sig_acc).
    - First-order fast path for near-identity Λ when allowed.
    - Exact push otherwise.
    """
    import numpy as np

    if K <= 0:
        return

    mu = mu_f[ids]         # (T, K)
    sg = sg_f[ids]         # (T, K, K)
    L  = L_f[ids]          # (T, K, K)

    ni_mask = None
    if use_first_order:
        ni_mask = near_identity_mask(L, float(tau_L))

    # First-order subset
    do_first = (use_first_order and (ni_mask is not None) and np.any(ni_mask))
    if do_first:
        mu_fast, S_fast = push_mu_sigma_first_order(mu[ni_mask], sg[ni_mask], L[ni_mask])
        mu_acc.reshape(-1, K)[ids[ni_mask]]      += (wv[ni_mask] * mu_fast).astype(np.float32, copy=False)
        Sig_acc.reshape(-1, K, K)[ids[ni_mask]]  += (wv[ni_mask, None] * S_fast).astype(np.float32, copy=False)
        Wsum.reshape(-1)[ids[ni_mask]]           += w_sp[ids[ni_mask]]

    # Exact subset (rest) or all rows if no first-order
    rest = (~ni_mask) if (ni_mask is not None) else slice(None)
    if (ni_mask is None) or np.any(rest):
        mu_ex, S_ex = push_mu_sigma_exact(mu[rest], sg[rest], L[rest])
        mu_acc.reshape(-1, K)[ids[rest]]      += (wv[rest] * mu_ex).astype(np.float32, copy=False)
        Sig_acc.reshape(-1, K, K)[ids[rest]]  += (wv[rest, None] * S_ex).astype(np.float32, copy=False)
        Wsum.reshape(-1)[ids[rest]]           += w_sp[ids[rest]]




def _harmonic_inpaint_vec(V: np.ndarray, cover: np.ndarray, support: np.ndarray, iters: int = 8) -> np.ndarray:
    """
    Periodic masked 4-neighbor averaging for a vector field V[...,K].
    Keeps covered pixels fixed; fills the rest of 'support'.
    """
    import numpy as np
    V = np.asarray(V, np.float32)
    H, W, K = V.shape
    out = np.zeros_like(V, np.float32)
    m_fix = cover.astype(bool)
    m_sup = support.astype(bool)
    out[m_fix] = V[m_fix]
    out[~m_sup] = 0.0
    for _ in range(int(iters)):
        nb = (np.roll(out, 1, 0) + np.roll(out, -1, 0) + np.roll(out, 1, 1) + np.roll(out, -1, 1)) * 0.25
        upd = (m_sup & ~m_fix)[..., None]
        out = np.where(upd, nb, out)
    return out

# --- FIXED SPD log/exp helpers (drop-in replacements) ------------------------------

def _log_spd(A, eps):
    """Matrix log for SPD A (KxK). Returns (K,K)."""
    import numpy as np
    A = np.asarray(A)
    A = (A + A.T) * 0.5
    w, U = np.linalg.eigh(A)                      # w: (K,), U: (K,K)
    w = np.clip(w, eps, np.inf)
    # U @ diag(log w) @ U^T  -> implement as (U * logw) @ U^T
    logw = np.log(w).astype(U.dtype)
    L = (U * logw) @ U.T
    return (L + L.T) * 0.5

def _exp_sym(L):
    """Matrix exp for symmetric L (KxK). Returns (K,K)."""
    import numpy as np
    L = np.asarray(L)
    L = (L + L.T) * 0.5
    w, U = np.linalg.eigh(L)                      # w: (K,), U: (K,K)
    expw = np.exp(w).astype(U.dtype)
    E = (U * expw) @ U.T                          # U @ diag(exp w) @ U^T
    return (E + E.T) * 0.5


def _harmonic_inpaint_spd(S: np.ndarray, cover: np.ndarray, support: np.ndarray, iters: int = 6, eps: float = 1e-6) -> np.ndarray:
    """
    Inpaint SPD field S[...,K,K] over 'support' by smoothing in log-Euclidean space.
    Keeps covered pixels (cover=True) fixed.
    """
    import numpy as np
    H, W, K, _ = S.shape
    L = np.zeros_like(S, np.float32)
    m_fix = cover.astype(bool)
    m_sup = support.astype(bool)

    # seed log-space where we have evidence
    ys, xs = np.where(m_fix)
    for y, x in zip(ys, xs):
        L[y, x] = _log_spd(S[y, x].astype(np.float64), eps).astype(np.float32)

    # iteratively smooth each matrix entry with periodic neighbors
    for _ in range(int(iters)):
        nb = (np.roll(L, 1, 0) + np.roll(L, -1, 0) + np.roll(L, 1, 1) + np.roll(L, -1, 1)) * 0.25
        upd = (m_sup & ~m_fix)[..., None, None]
        L = np.where(upd, nb, L)

    # project back to SPD
    out = np.zeros_like(S, np.float32)
    ys, xs = np.where(m_sup)
    for y, x in zip(ys, xs):
        out[y, x] = (_exp_sym(L[y, x].astype(np.float64)) + eps * np.eye(K)).astype(np.float32)
    return out




def attach_generators_to_parent(P, G_q, G_p):
    """
    Remember generators on the parent for downstream φ work.
    """
    if G_q is not None:
        P.generators_q = G_q
    if G_p is not None:
        P.generators_p = G_p




