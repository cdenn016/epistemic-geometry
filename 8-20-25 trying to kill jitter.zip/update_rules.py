# -*- coding: utf-8 -*-
"""
Created on Wed Jul 23 10:32:58 2025

@author: chris and christine
"""
import config
import time
from detector import DetectorState, detect_regions_minimal, _parse_kl_tau 

from parent_spawn import _apply_spawn_from_regions
from runtime_context import _Dirty
from update_rules_utils import ensure_spawn_alignment_caches
from bundle_coarsegrain_init import _periodic_parent_coarsegrain
from parent_semantics import reconcile_parent_masks_and_assignments, update_parent_lifecycle
from update_compute_all_gradients import ( _apply_children, _compute_child_grads,
                                          _parent_intrascale_grad_pass, _final_apply_parents)
from update_rules_utils import ( _pre_light, _assign_children_to_parents, 
                                _as_parent_dict, prune_orphan_parents, compute_and_set_auto_agree_gate )
from update_rules_utils import ( build_alignment_aggregates, take_dirty,
                                mark_dirty, _refresh_child_kl_fields_subset, 
                                assign_parent_masks_from_alignment,  )
from update_rules_utils import snapshot_parent_child_ids, enforce_min_children_per_parent


def CFG(name, default=None):
    """Unified config accessor with explicit failure if config is absent."""
    return getattr(config, name, default)







class PhaseTimer:
    """Context-manager timer that aggregates per-phase wall time on runtime_ctx."""
    def __init__(self, ctx):
        self.ctx = ctx
        if not hasattr(ctx, "timings") or getattr(ctx, "timings") is None:
            ctx.timings = {}

    def __call__(self, name: str):
        ctx = self.ctx
        class _T:
            def __enter__(_s):
                _s.t0 = time.perf_counter()
                return _s
            def __exit__(_s, *_):
                dt = time.perf_counter() - _s.t0
                ctx.timings[name] = ctx.timings.get(name, 0.0) + dt
        return _T()

def bump_counter(ctx, key: str, inc: int = 1):
    """Optional: simple per-step counters."""
    if not hasattr(ctx, "counters") or getattr(ctx, "counters") is None:
        ctx.counters = {}
    ctx.counters[key] = ctx.counters.get(key, 0) + inc


# --- synchronous step (simplified, timed) ------------------------------------
def synchronous_step(agents, generators_q, generators_p, params=None, n_jobs=1, runtime_ctx=None):
    assert runtime_ctx is not None, "synchronous_step: pass runtime_ctx"
    assert agents and (len(agents) > 0), "synchronous_step: no agents"

    # Base params + thread ctx everywhere downstream expects it
    params = dict(params or {})
    params["runtime_ctx"] = runtime_ctx

    # Ensure runtime context is initialized before using global_step/cache
    init_runtime_ctx(runtime_ctx)

    # Ensure a CacheHub exists and clear per-step
    if not hasattr(runtime_ctx, "cache") or runtime_ctx.cache is None:
        try:
            from runtime_context import CacheHub  # local import to avoid circulars if any
            runtime_ctx.cache = CacheHub()
        except Exception:
            class _NoopCache:
                def clear_on_step(self, *_args, **_kw): pass
                def ns(self, *_args, **_kw):
                    class _D(dict):
                        def clear(self): super().clear()
                    return _D()
            runtime_ctx.cache = _NoopCache()

    # small local helper for safe selective clears (kept for rare callers)
    def _clear_cache(ctx, *names: str):
        try:
            if hasattr(ctx, "cache_clear"):
                ctx.cache_clear(*names)
                return
            hub = getattr(ctx, "cache", None)
            if not hub:
                return
            if names:
                for n in names:
                    try:
                        hub.ns(n).clear()
                    except Exception:
                        pass
            else:
                hub.clear_on_step(getattr(ctx, "global_step", 0))
        except Exception:
            pass

    step_now = int(getattr(runtime_ctx, "global_step", 0))
    runtime_ctx.cache.clear_on_step(step_now)   # central per-step cache invalidation

    T = PhaseTimer(runtime_ctx)  # timer

    frozen_levels     = set(params.get("frozen_levels", []))
    frozen_phi_levels = set(params.get("frozen_phi_levels", []))

    # ---------- Phase 0: pre -------------------------------------------------
    with T("pre"):
        parents    = list_parents(runtime_ctx)
        children   = list_nonnull(agents)
        all_agents = children + parents
        # pass ctx-aware params to the pre-light refresh
        _pre_light(all_agents, params, generators_q, generators_p, ctx=runtime_ctx)

    # ---------- Phase 1: child grads/apply ----------------------------------
    with T("child_grad"):
        grads = _compute_child_grads(children, all_agents, generators_q, generators_p, params)

    with T("child_apply"):
        _apply_children(children, grads, params, frozen_levels, frozen_phi_levels, generators_q, generators_p, n_jobs, ctx=runtime_ctx)
        for a in children:
            mark_dirty(runtime_ctx, a, kl=True)  # fields updated; need KL
        runtime_ctx.children_latest = children
        # NO global cache clears here; per-agent invalidation happens in apply_phi_updates

    with T("ensure_children"):
        ensure_dirty(runtime_ctx, generators_q, generators_p, params, scope="children")
    with T("refresh_child_kl"):
        refresh_kl_for_dirty_children(runtime_ctx, universe=all_agents, eps=CFG("eps", 1e-6))

    # ---------- Phase 2: spawn caches (build child agreement/KL now) ----------
    with T("spawn_caches"):
        ensure_spawn_alignment_caches(
            children,                     # children to build caches for
            children,                     # 'agents' universe is fine as children here
            runtime_ctx,
            generators_q=generators_q,
            generators_p=generators_p,
            use_cover_weight=True,
            debug=bool(CFG("debug_spawn_log_details", False)),
        )

    # ---------- Phase 3: aggregates + auto gate -------------------------------
    with T("aggregates"):
        try:
            # children aggregates (agreement/KL maps)
            build_alignment_aggregates(runtime_ctx, children)

            # OPTIONAL: parents aggregates for diagnostics (mass/curvature/alignment)
            parents = list_parents(runtime_ctx)
            if parents:
                build_alignment_aggregates(runtime_ctx, parents)

            if bool(CFG("detector_agree_auto", True)):
                compute_and_set_auto_agree_gate(
                    runtime_ctx,
                    percentile=float(CFG("detector_agree_percentile", 65.0)),
                    ema=float(CFG("detector_agree_ema", 0.2)),
                    use_p_if_q_missing=True,
                )
        except Exception as e:
            if bool(CFG("debug_strict", False)):
                print(f"[AGG] skipped: {e}")

    with T("spawn_detect"):
        import numpy as np
        H, W = np.asarray(children[0].mask, np.float32).shape[:2]
    
        # detector state
        ds = getattr(runtime_ctx, "detector_state", None)
        if ds is None:
            ds = DetectorState()
            runtime_ctx.detector_state = ds
    
        # period + EMA handled here
        every = int(CFG("detector_period", 1))
        run_now = (int(getattr(runtime_ctx, "global_step", 0)) % max(1, every) == 0)
    
        if run_now:
            regions, cand_now = detect_regions_minimal(
                children, H=H, W=W,
                min_kids=int(CFG("seed_min_kids", 2)),
                min_area=int(CFG("emerge_min_area", 8)),
                kl_tau=_parse_kl_tau(CFG("emerge_tau", 0.28)),
                weight_tau=CFG("parent_weight_tau", 0.6),
                erode_iters=CFG("detector_edge_erode", 0),
                runtime_ctx=runtime_ctx,
                agree_gate_tau=CFG("agree_gate_tau", None),
                return_cand_map=True,
            )
            beta = float(CFG("detector_cand_ema", 0.7))
            prev = getattr(ds, "ema_cand", None)
            if (prev is None) or (getattr(prev, "shape", None) != (H, W)):
                prev = np.zeros((H, W), np.float32)
            ds.ema_cand = beta * prev + (1.0 - beta) * np.asarray(cand_now, np.float32)
            cand_map = ds.ema_cand
        else:
            regions = {}
            cand_map = getattr(ds, "ema_cand", np.zeros((H, W), np.float32))
    
        active_regions = regions
        regs_to_spawn = _gate_spawns(active_regions, runtime_ctx)

    with T("spawn_apply"):
        if regs_to_spawn:
            changed_parents = _apply_spawn_from_regions(
                runtime_ctx, regs_to_spawn, children, generators_q, generators_p, params
            ) or []
        else:
            changed_parents = []

    # ---------- Phase 4: assign kids→parents ---------------------------------
    with T("assign_kids_to_parents"):
       
        snapshot_parent_child_ids(runtime_ctx.parents_by_region)

        _assign_children_to_parents(
            children, runtime_ctx.parents_by_region,
            eps=CFG("support_cutoff_eps", 1e-3),
            tau=CFG("parent_soft_assign_tau", 0.30),
            temp=CFG("parent_soft_assign_temp", 0.25),
            max_parents_per_child=CFG("parent_soft_assign_topk", 2),
            core_tau=CFG("core_abs_tau", 0.12),
            core_tau_rel=CFG("core_rel_tau", 0.50),
            core_dilate_px=CFG("parent_assign_core_dilate", 1),
            newborn_bootstrap_steps=CFG("parent_assign_bootstrap", 5),
            allow_unassigned=True,
            agreement_map=getattr(runtime_ctx, "Aq_agg", None),
            use_agreement=bool(CFG("parent_assign_use_agreement", False)),
            agree_weight=CFG("parent_assign_agree_weight", 1.0),
            debug=bool(CFG("debug_assign_summary", False)),
        )

        # Guard against single-kid parents (major source of mask=0)
        enforce_min_children_per_parent(
            runtime_ctx.parents_by_region,
            min_kids=int(CFG("parent_min_kids", 2)),
            respect_grace=True,
        )

    with T("assign_build_responsibilities"):
        from update_rules_utils import build_child_parent_responsibilities
        # choose pixelwise for most faithful energy attribution; switch to "global" if you want cheaper scalars
        build_child_parent_responsibilities(children, runtime_ctx.parents_by_region,
                                            mode=str(CFG("parent_resp_mode", "pixel")).lower())

    # ---------- Phase 5: prune + rebuild parent masks -----------------------
    with T("prune"):
        prune_orphan_parents(
            runtime_ctx.parents_by_region,
            patience=CFG("orphan_patience_steps", 3),
            min_total_weight=CFG("orphan_min_total_weight", 1e-4),
            min_area_nz=CFG("orphan_min_area_nz", 3),
            support_tau=CFG("support_tau", 0.02),
            verbose=bool(CFG("debug_prune_log", False)),
        )
    with T("parent_masks"):
        changed_masks = assign_parent_masks_from_alignment(
            runtime_ctx, children, generators_q, generators_p,
            mode="max",
            mask_tau=float(CFG("support_cutoff_eps", 1e-3)), 
            tau_q=float(CFG("tau_align_q", 0.30)),
            tau_p=float(CFG("tau_align_p", 0.30)),
            alpha=float(CFG("blend_qp_alpha", 0.5)),
            agree_map=getattr(runtime_ctx, "Aq_agg", None),
            agree_power=1.0,
            clamp_to_union=True,
            kl_cap=float(CFG("signal_kl_cap", 10.0)),
            floor_eps=1e-6,
            min_pair_px=8,
            return_changed=True,
            change_tol=getattr(config, "parent_mask_change_tol", 5e-3),
        ) or []
        for p in changed_masks:
            mark_dirty(runtime_ctx, p)
        ensure_dirty(runtime_ctx, generators_q, generators_p, params, scope="parents")
        # NEW: parent KL/self-energy refresh after mask changes
        try:
            refresh_kl_for_dirty_parents(runtime_ctx, universe=all_agents, eps=CFG("eps", 1e-6))
        except Exception:
            pass

    # ---------- Phase 6: lifecycle only (no mask edits) ----------------------
    with T("lifecycle"):
        _ = update_parent_lifecycle(runtime_ctx, step_now)
        # purge deletions
        for pid, P in list(runtime_ctx.parents_by_region.items()):
            if getattr(P, "_delete", False):
                runtime_ctx.parents_by_region.pop(pid, None)

   #------------Phase 7: coarsegrain
    with T("parent_coarsegrain"):
        if changed_masks:
            try:
                from parent_spawn import run_cg_for_parents
                cg_tau = float(CFG("support_cutoff_eps", 1e-3))
                _ = run_cg_for_parents(
                    runtime_ctx, changed_masks, children, generators_q, generators_p,
                    eps=float(CFG("cg_eps", 1e-6)),
                    mask_tau=cg_tau,
                    backend=str(CFG("cg_backend", "loky")).lower(),
                    n_jobs=int(CFG("cg_jobs", 1)),
                    batch_size=CFG("cg_batch", 1),
                    prefer=CFG("cg_prefer", None),
                    omp_thr=int(CFG("cg_omp_thr", 1)),
                )
                for p in changed_masks:
                    mark_dirty(runtime_ctx, p)
                ensure_dirty(runtime_ctx, generators_q, generators_p, params, scope="parents")
            except Exception as e:
                if bool(CFG("debug_strict", False)):
                    print(f"[CG] skipped: {e}")



    # ---------- Phase 8: parent-level grads/updates --------------------------
    with T("parent_grads_apply"):
        parents = list_parents(runtime_ctx)  # refresh view after lifecycle/CG
        if parents:
            ensure_dirty(runtime_ctx, generators_q, generators_p, params, scope="parents")
            # pass ctx into parent grad pass
            _parent_intrascale_grad_pass(children, parents, generators_q, generators_p, params, accum_into=True, ctx=runtime_ctx)
            _final_apply_parents(runtime_ctx, params)
            for p in parents:
                mark_dirty(runtime_ctx, p)
            ensure_dirty(runtime_ctx, generators_q, generators_p, params, scope="parents")
            # NEW: refresh parent energies/diagnostics after apply
            try:
                refresh_kl_for_dirty_parents(runtime_ctx, universe=all_agents, eps=CFG("eps", 1e-6))
            except Exception:
                pass
            # NO global cache clears here; apply paths already invalidate per-agent entries

    # ---------- Phase 9: register/mirror + bookkeeping -----------------------
    with T("register_mirror"):
        runtime_ctx.register_agents(0, children) if children else None
        runtime_ctx.register_agents(1, parents)  if parents  else None

        if children and parents:
            ensure_dirty(runtime_ctx, generators_q, generators_p, params, scope="all")
            # labels only; Λ matrices come from transport_cache on demand
            import numpy as np
            child_ids  = [int(getattr(ch, "id")) for ch in children]
            parent_ids = [int(getattr(p, "id")) for p in parents]
            pid_set    = set(parent_ids)
            labels = np.full(len(child_ids), -1, dtype=int)
            for i, ch in enumerate(children):
                pids = getattr(ch, "parent_ids", ()) or ()
                labels[i] = next((int(pid) for pid in pids if int(pid) in pid_set), -1)
            runtime_ctx.set_crossscale_labels(0, 1, child_ids, parent_ids, labels=labels)

        runtime_ctx.children_latest = children
        runtime_ctx.parents_latest  = runtime_ctx.parents_by_region
        runtime_ctx.global_step    += 1

    if bool(CFG("debug_phase_timing", False)):
        print("[timings]", getattr(runtime_ctx, "timings", {}))
        try:
            print("[cache]", runtime_ctx.cache.stats() if hasattr(runtime_ctx, "cache") else {})
        except Exception:
            pass
        if getattr(runtime_ctx, "counters", None):
            print("[counts]", runtime_ctx.counters)

    return agents



def refresh_kl_for_dirty_parents(ctx, universe, eps):
    """
    Mirror of refresh_kl_for_dirty_children, but for parents.
    Recomputes KL/self-energy/etc. for any parents marked dirty (which="kl").
    """
    try:
        parents = list_parents(ctx)
    except Exception:
        parents = []
    if not parents:
        return
    # pull dirty subset
    dirty_par = list_nonnull(take_dirty(ctx, parents, which="kl"))
    if not dirty_par:
        return
    # reuse the same refresher used for children; it works for any agents
    _refresh_child_kl_fields_subset(dirty_par, list_nonnull(universe), eps=eps, build_spawn=False)






# small utilities
def list_nonnull(xs): 
    return [x for x in xs if x is not None]

# robust parent collection (reuse the helper if you defined it elsewhere)
def _collect_parents_from_ctx(ctx):
    parents = []

    def _extend(obj):
        if obj is None:
            return
        if isinstance(obj, (list, tuple)):
            parents.extend(obj)
        else:
            parents.append(obj)

    if hasattr(ctx, "parents_by_region"):
        pbr = getattr(ctx, "parents_by_region")
        if isinstance(pbr, dict):
            for v in pbr.values():
                _extend(v)
        else:
            _extend(pbr)
    elif hasattr(ctx, "parents"):
        _extend(getattr(ctx, "parents"))
    elif hasattr(ctx, "parent"):
        _extend(getattr(ctx, "parent"))

    # dedupe, preserve order
    seen = set()
    flat = []
    for p in parents:
        if p is None:
            continue
        try:
            pid = int(getattr(p, "id"))
        except Exception:
            pid = id(p)
        if pid not in seen:
            seen.add(pid)
            flat.append(p)
    return flat

def list_parents(ctx):
    return _collect_parents_from_ctx(ctx)

def bump_cache(ctx, n=1):
    setattr(ctx, "cache_version", int(getattr(ctx, "cache_version", 0)) + n)

def init_runtime_ctx(ctx):
    if not hasattr(ctx, "detector_state") or ctx.detector_state is None:
        ctx.detector_state = DetectorState()
    if not hasattr(ctx, "global_step"): 
        ctx.global_step = 0
    if not hasattr(ctx, "parents_by_region") or ctx.parents_by_region is None:
        ctx.parents_by_region = {}
    else:
        ctx.parents_by_region = _as_parent_dict(ctx.parents_by_region)
    if not hasattr(ctx, "next_parent_id"): 
        ctx.next_parent_id = 0
    if not hasattr(ctx, "dirty"): 
        ctx.dirty = _Dirty()
    if not hasattr(ctx, "cache_version"): 
        ctx.cache_version = 0

def ensure_dirty(ctx, generators_q, generators_p, params, scope="all"):
    """
    Refresh transforms for dirty items; clear flags; bump cache if anything was done.
    Now: rebuild bundle morphisms + pre-warm exp grids in the central cache.
    """
    from transport_cache import warm_E
    from preprocess_utils import ensure_transforms

    targets = []
    if scope in ("all", "children"):
        targets += take_dirty(ctx, getattr(ctx, "children_latest", []), which="agents")
    if scope in ("all", "parents"):
        targets += take_dirty(ctx, list_parents(ctx), which="agents")
    targets = [t for t in targets if t is not None]
    if not targets:
        return targets

    # 1) Make sure Phi / Phĩ shapes match current (Kq, Kp)
    try:
        ensure_transforms(targets, generators_q, generators_p, params, ctx=ctx)
    except Exception as e:
        if bool(CFG("debug_strict", True)):
            print(f"[ensure_dirty] ensure_transforms failed: {e}")

    # 2) Pre-warm exp(φ)/exp(φ̃) in the central cache (idempotent per step)
    try:
        warm_E(ctx, targets, whiches=("q", "p"))
    except Exception:
        pass

    bump_cache(ctx, 1)
    return targets


def refresh_kl_for_dirty_children(ctx, universe, eps):
    dirty_kids = list_nonnull(take_dirty(ctx, getattr(ctx, "children_latest", []), which="kl"))
    if not dirty_kids:
        return
    _refresh_child_kl_fields_subset(dirty_kids, list_nonnull(universe), eps=eps, build_spawn=False)



def _gate_spawns(active_regions, ctx):
    
   
    if not active_regions:
        return []
    conf_tau = CFG("spawn_confidence_tau", None)
    if conf_tau is None and bool(CFG("spawn_conf_auto", True)):
        ds = getattr(ctx, "detector_state", None)
        conf_tau = float(getattr(ds, "conf_tau_eff", 0.60)) if ds is not None else 0.60
    conf_tau = 0.60 if conf_tau is None else float(conf_tau)
    regs = [r for r in active_regions if float(getattr(r, "confidence", 1.0)) >= conf_tau]
    regs.sort(key=lambda r: float(getattr(r, "confidence", 1.0)), reverse=True)
    return regs[: int(CFG("parent_max_new_per_step", 3))]




# ---------------------------------------------------------------------------
# Detect/Spawn run-modes
# ---------------------------------------------------------------------------



