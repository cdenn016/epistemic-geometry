# -*- coding: utf-8 -*-
"""
Created on Fri Aug 15 16:38:18 2025

@author: chris and christine
"""

# parent_semantics.py
import numpy as np
from typing import Dict, Iterable, Tuple






from parent_utils import _label4  # your toroidal CC




def _largest_cc(mask: np.ndarray, periodic: bool, prefer_overlap: np.ndarray = None) -> np.ndarray:
    """Return boolean mask of the largest 4-conn component (toroidal if periodic).
    If prefer_overlap is given, prefer component with max overlap with it."""
    if not mask.any():
        return mask
    labels = _label4(mask, periodic=bool(periodic))
    nlab = int(labels.max())
    if nlab <= 1:
        return mask
    best_lbl, best_score = 0, -1
    for lbl in range(1, nlab + 1):
        comp = (labels == lbl)
        score = int(comp.sum())
        if prefer_overlap is not None:
            score = (comp & prefer_overlap).sum() * (10**9) + score  # lexicographic prefer-overlap
        if score > best_score:
            best_score = score
            best_lbl = lbl
    return labels == best_lbl



def update_parent_lifecycle(runtime_ctx, step: int) -> int:
    """
    Bookkeeping only:
      - newborn freeze window
      - orphan detection (no assigned kids + tiny active area)
      - mark for deletion via P._delete
    Returns the number of parents marked for deletion this call.
    """
    import numpy as np
    import config as CFG

    parents = getattr(runtime_ctx, "parents_by_region", {}) or {}
    if not parents:
        return 0

    # knobs (single-sourced; keep them few and obvious)
    active_thr_min     = float(getattr(CFG, "parent_active_level_min", 0.06))
    min_cc_px_base     = int(getattr(CFG, "parent_active_min_cc_px", 8))
    orphan_grace_steps = int(getattr(CFG, "parent_orphan_grace_steps", 10))
    freeze_steps       = int(getattr(CFG, "parent_freeze_steps", 2))

    deleted = 0
    for pid, P in list(parents.items()):
        # init lifecycle fields
        if not hasattr(P, "freeze_until"):
            P.freeze_until = int(step) + freeze_steps
        if not hasattr(P, "orphan_steps"):
            P.orphan_steps = 0
        if not hasattr(P, "assigned_child_ids") or P.assigned_child_ids is None:
            P.assigned_child_ids = set()

        # compute a simple "active" area from the current mask
        M = np.asarray(getattr(P, "mask", 0.0), np.float32)
        active_bool  = (M >= active_thr_min)
        active_area  = int(active_bool.sum())
        # scale min-cc with size (4% of area, clamped by base)
        min_cc_px    = max(min_cc_px_base, int(0.04 * max(1, active_area)))

        # orphan rule after newborn freeze
        if (int(step) > int(P.freeze_until)) and (len(P.assigned_child_ids) == 0) and (active_area < min_cc_px):
            P.orphan_steps += 1
        else:
            P.orphan_steps = 0

        if P.orphan_steps >= orphan_grace_steps:
            setattr(P, "_delete", True)
            deleted += 1

    return deleted






def reconcile_parent_masks_and_assignments(runtime_ctx, children, step: int, *, periodic: bool, H: int, W: int) -> None:
    """
    Enforce: (1) per-step child assignment by IoU with hysteresis,
             (2) seed vs active masks (freeze),
             (3) coalition-aware growth (strong->weak),
             (4) continuity-first CC under PBC,
             (5) soft-mask dynamics with step cap.
    Mutates parent objects in runtime_ctx.parents_by_region in place.
    """
    import numpy as np
    import config as CFG

    parents: Dict[int, object] = getattr(runtime_ctx, "parents_by_region", {})
    if not parents:
        return

    # ------------------ knobs ------------------
    # ACTIVE threshold: fixed or adaptive
    active_thr_cfg     = getattr(CFG, "parent_active_level", None)  # None => auto
    active_thr_q       = float(getattr(CFG, "parent_active_level_q", 60.0))
    active_thr_rel     = float(getattr(CFG, "parent_active_level_rel", 0.60))
    active_thr_min     = float(getattr(CFG, "parent_active_level_min", 0.06))

    add_iou_thr        = float(getattr(CFG, "parent_assign_iou_add_thr", 0.05))
    keep_iou_thr       = float(getattr(CFG, "parent_assign_iou_keep_thr", 0.15))
    min_overlap_px     = int(getattr(CFG, "parent_assign_min_overlap_px", 8))
    orphan_grace_steps = int(getattr(CFG, "parent_orphan_grace_steps", 10))
    freeze_steps       = int(getattr(CFG, "parent_freeze_steps", 3))
    seed_erode_iters   = int(getattr(CFG, "parent_seed_erode_iters", 1))
    min_cc_px_base     = int(getattr(CFG, "parent_active_min_cc_px", 8))
    active_iou_min     = float(getattr(CFG, "parent_active_iou_min", 0.30))
    hysteresis_keep_fr = float(getattr(CFG, "parent_hysteresis_keep_frac", 0.75))

    # Soft-mask dynamics
    eta_up    = float(getattr(CFG, "parent_eta_up", 0.25))
    eta_down  = float(getattr(CFG, "parent_eta_down", 0.20))
    sigma     = float(getattr(CFG, "parent_feather_sigma", 1.0))
    delta_cap = float(getattr(CFG, "parent_delta_cap", 0.20))

    # Coalition growth (agreement + cover>=N)
    cover_N         = int(getattr(CFG, "coalition_cover_n", 2))
    coal_hi         = float(getattr(CFG, "coalition_high_tau", 0.18))
    coal_lo         = float(getattr(CFG, "coalition_low_tau", 0.06))
    agree_map = getattr(runtime_ctx, "Ap_agg" if bool(getattr(CFG, "model_only", False)) else "Aq_agg", None)

    # ------------------ helpers ------------------
    def _to_bool(m, thr): return (np.asarray(m, np.float32) >= float(thr))
    def _iou(a, b):
        a = np.asarray(a, bool); b = np.asarray(b, bool)
        inter = int((a & b).sum()); union = int(a.sum() + b.sum() - inter)
        return (inter / max(1, union))
    def _erode4(mask, iters=1, periodic=False):
        m = np.asarray(mask, bool)
        for _ in range(max(0, int(iters))):
            nbr = (np.roll(m,1,0) & np.roll(m,-1,0) & np.roll(m,1,1) & np.roll(m,-1,1))
            if not periodic:
                # zero borders for safety (simple)
                nbr[0,:]=False; nbr[-1,:]=False; nbr[:,0]=False; nbr[:,-1]=False
            m = m & nbr
        return m
  

    # grow strong -> weak with 8-neigh
    def _grow8(weak, strong):
        weak   = np.asarray(weak, bool)
        strong = np.asarray(strong, bool)
        act = strong.copy()
        while True:
            nbr = (np.roll(act,1,0)|np.roll(act,-1,0)|np.roll(act,1,1)|np.roll(act,-1,1)|
                   np.roll(np.roll(act,1,0),1,1)|np.roll(np.roll(act,1,0),-1,1)|
                   np.roll(np.roll(act,-1,0),1,1)|np.roll(np.roll(act,-1,0),-1,1))
            add = weak & (~act) & nbr
            if not add.any(): break
            act |= add
        return act

    def _union_of_children(children, cids, H, W, thr):
        u = np.zeros((H, W), bool)
        for c in children:
            cid = int(getattr(c, "id", -1))
            if cid in cids:
                u |= _to_bool(c.mask, thr)
        return u

    # precompute child bool masks @active_thr_min for fast IoUs
    child_ids = [int(getattr(c, "id", i)) for i, c in enumerate(children)]
    child_bool_cache = {cid: _to_bool(children[i].mask, active_thr_min) for i, cid in enumerate(child_ids)}

    # cover count (>=N kids) for coalition growth
    child_tau = float(getattr(CFG, "support_tau", 0.01))
    try:
        M_stack = np.stack([(np.asarray(c.mask, np.float32) >= child_tau).astype(np.uint8) for c in children], axis=0)
        cover_count = M_stack.sum(axis=0)
    except Exception:
        cover_count = None

    for pid, P in list(parents.items()):
        # -------- init persistent fields --------
        if not hasattr(P, "active_mask"):
            P.active_mask = _to_bool(P.mask, active_thr_min)
        else:
            P.active_mask = _to_bool(P.active_mask, active_thr_min)

        if not hasattr(P, "seed_mask") or P.seed_mask is None or not np.any(P.seed_mask):
            seed0 = _erode4(P.active_mask, seed_erode_iters, periodic=periodic)
            if not seed0.any():
                seed0 = P.active_mask.copy()
            P.seed_mask = seed0.astype(np.float32)

        if not hasattr(P, "assigned_child_ids") or P.assigned_child_ids is None:
            P.assigned_child_ids = set()

        if not hasattr(P, "freeze_until"):
            P.freeze_until = int(step) + freeze_steps

        if not hasattr(P, "orphan_steps"):
            P.orphan_steps = 0

        # -------- adaptive active threshold & min-cc --------
        if active_thr_cfg is None:
            vals = np.asarray(P.mask, np.float32)
            vals = vals[vals > 1e-6]
            if vals.size:
                q = float(np.percentile(vals, active_thr_q))
                active_thr = max(active_thr_min, active_thr_rel * q)
            else:
                active_thr = active_thr_min
        else:
            active_thr = float(active_thr_cfg)

        active_bool  = _to_bool(P.mask, active_thr)
        active_area  = int(active_bool.sum())
        # scale min-cc with parent size (4% of area, clamped)
        min_cc_px    = max(min_cc_px_base, int(0.04 * max(1, active_area)))

        # -------- assignment with hysteresis --------
        new_assign = set()
        for cid in child_ids:
            cm = child_bool_cache[cid]
            if not cm.any():
                continue
            inter = int((active_bool & cm).sum())
            if inter < min_overlap_px:
                continue
            if _iou(active_bool, cm) >= add_iou_thr:
                new_assign.add(cid)

        kept = set()
        for cid in list(P.assigned_child_ids):
            cm = child_bool_cache.get(cid, None)
            if cm is None or not cm.any():
                continue
            inter = int((active_bool & cm).sum())
            if inter >= min_overlap_px and _iou(active_bool, cm) >= keep_iou_thr:
                kept.add(cid)

        P.assigned_child_ids = kept | new_assign

        # -------- orphan detection --------
        if (len(P.assigned_child_ids) == 0) and (active_area < min_cc_px) and (int(step) > int(P.freeze_until)):
            P.orphan_steps += 1
        else:
            P.orphan_steps = 0
        if P.orphan_steps >= orphan_grace_steps:
            setattr(P, "_delete", True)
            continue

        # -------- coalition hysteresis (strong->weak) --------
        coalition = None
        if isinstance(agree_map, np.ndarray) and (cover_count is not None):
            strong = (cover_count >= cover_N) & (agree_map >= coal_hi)
            weak   = (cover_count >= cover_N) & (agree_map >= coal_lo)
            if weak.any() or strong.any():
                coalition = _grow8(weak, strong)

        # -------- choose target CC (continuity-first) --------
        if len(P.assigned_child_ids) > 0:
            union_assigned = _union_of_children(children, P.assigned_child_ids, H, W, active_thr_min)

            labels = _label4(active_bool, periodic=bool(periodic))
            nlab = int(labels.max())
            if nlab > 1:
                # prefer CC that overlaps union_assigned AND previous/seed (continuity)
                prev_anchor = active_bool | _to_bool(P.seed_mask, 0.5)
                best_lbl, best_score = 0, -1
                for lbl in range(1, nlab + 1):
                    comp = (labels == lbl)
                    if comp.sum() < min_cc_px:
                        continue
                    ov_u = int((comp & union_assigned).sum())
                    ov_p = int((comp & prev_anchor).sum())
                    score = (ov_u, ov_p, int(comp.sum()))
                    if score > (best_score if isinstance(best_score, tuple) else (-1,-1,-1)):
                        best_score = score; best_lbl = lbl
                target_bool = (labels == best_lbl) if best_lbl != 0 else _largest_cc(active_bool, periodic=periodic)
            else:
                target_bool = active_bool

            # Active↔assigned IoU gate with smart restore
            iou_u = _iou(target_bool, union_assigned)
            if iou_u < active_iou_min:
                prev = target_bool.copy()
                target_bool = target_bool & union_assigned
                dropped = prev & (~target_bool)
                if dropped.any():
                    restore_cap = int(np.ceil((1.0 - hysteresis_keep_fr) * dropped.sum()))
                    if restore_cap > 0:
                        M_prev = np.asarray(P.mask, np.float32)
                        yy, xx = np.where(dropped)
                        vals = M_prev[yy, xx]
                        idx_sorted = np.argsort(-vals)[:restore_cap]
                        rr = np.zeros_like(prev, dtype=bool)
                        rr[yy[idx_sorted], xx[idx_sorted]] = True
                        target_bool |= rr
        else:
            target_bool = _largest_cc(active_bool, periodic=periodic) if active_area >= min_cc_px else active_bool

        # merge coalition CC that touches current/seed (natural growth)
        if isinstance(coalition, np.ndarray) and coalition.any():
            anchor = target_bool | _to_bool(P.seed_mask, 0.5)
            lab = _label4(coalition, periodic=bool(periodic))
            best, score = 0, -1
            for lbl in range(1, int(lab.max())+1):
                comp = (lab == lbl)
                s = int((comp & anchor).sum())
                if s > score:
                    score = s; best = lbl
            if best > 0:
                target_bool |= (lab == best)

        # -------- freeze seed protection --------
        if step <= int(P.freeze_until):
            target_bool |= _to_bool(P.seed_mask, 0.5)

        # -------- soft update --------
        target_float = target_bool.astype(np.float32)
        if sigma > 0.0:
            try:
                from scipy.ndimage import gaussian_filter as _gf
                target_float = _gf(target_float, sigma=sigma, mode="wrap" if periodic else "nearest")
            except Exception:
                pass
        target_float = np.clip(target_float, 0.0, 1.0)

        M_prev = np.asarray(P.mask, np.float32)
        delta  = target_float - M_prev
        eta    = np.where(delta > 0.0, eta_up, np.where(delta < 0.0, eta_down, 0.0)).astype(np.float32)
        raw    = M_prev + eta * delta
        d      = np.clip(raw - M_prev, -delta_cap, delta_cap)
        M_new  = np.clip(M_prev + d, 0.0, 1.0)

        # minimal area safeguard during freeze
        if (M_new >= active_thr).sum() < min_cc_px and step <= int(P.freeze_until):
            M_new = np.maximum(M_new, np.asarray(P.seed_mask, np.float32))

        # commit
        P.mask = M_new.astype(np.float32)
        P.active_mask = (P.mask >= active_thr)



