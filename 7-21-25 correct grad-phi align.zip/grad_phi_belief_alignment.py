import numpy as np
from scipy.linalg import inv
from numerical_utils import safe_inv, sanitize_sigma

def grad_kl_wrt_phi_i(mu_i, sigma_i, mu_j, sigma_j, Omega_ij, generators, eps=1e-8):
    """
    Compute ∂/∂φ_i KL(q_i || Ω_ij q_j)
    where Ω_ij = exp(φ_i) · exp(−φ_j), and φ_i ∈ Lie algebra
    Returns shape (H, W, d)
    """
    d = generators.shape[0]
    grad_phi_i = np.zeros((*mu_i.shape[:-1], d))

    # Transported μ_j and Σ_j
    mu_trans = np.einsum("...ij,...j->...i", Omega_ij, mu_j)
    Omega_T = np.swapaxes(Omega_ij, -1, -2)
    sigma_trans = np.einsum("...ik,...kl,...jl->...ij", Omega_ij, sigma_j, Omega_T)
    sigma_trans = sanitize_sigma(sigma_trans, eps=eps)
    sigma_inv = safe_inv(sigma_trans, eps=eps)

    delta_mu = mu_i - mu_trans
    delta_sigma = sigma_i - sigma_trans

    d_mu = -np.einsum("...ij,...j->...i", sigma_inv, delta_mu)
    d_sigma = -0.5 * np.einsum("...ik,...kl,...lj->...ij", sigma_inv, delta_sigma, sigma_inv)

    for a in range(d):
        G = generators[a]
        OG = np.einsum("...ij,jk->...ik", Omega_ij, G)

        dphi_mu = np.einsum("...ij,...j->...i", OG, mu_j)

        OG_sigma = np.einsum("...ij,...jk->...ik", OG, sigma_j)
        dphi_sigma_1 = np.einsum("...ij,...jk->...ik", OG_sigma, Omega_T)

        sigma_GT = np.einsum("...ij,jk->...ik", sigma_j, G.T)
        O_sigma_GT = np.einsum("...ij,...jk->...ik", Omega_ij, sigma_GT)
        dphi_sigma_2 = np.einsum("...ij,...jk->...ik", O_sigma_GT, Omega_T)

        dphi_sigma = dphi_sigma_1 + dphi_sigma_2

        term1 = np.sum(d_mu * dphi_mu, axis=-1)
        term2 = np.einsum("...ij,...ij->...", d_sigma, dphi_sigma)

        grad_phi_i[..., a] = term1 + term2

    return grad_phi_i


def grad_kl_wrt_phi_j(mu_i, sigma_i, mu_j, sigma_j, Omega_ij,
                      generators, exp_phi_j, exp_neg_phi_j, eps=1e-8):
    """
    Compute ∂/∂φ_j KL(q_i || Ω_ij q_j)
    Returns shape (H, W, d)
    """
    d = generators.shape[0]
    grad_phi_j = np.zeros((*mu_i.shape[:-1], d))

    Omega_T = np.swapaxes(Omega_ij, -1, -2)
    mu_trans = np.einsum("...ij,...j->...i", Omega_ij, mu_j)
    sigma_trans = np.einsum("...ik,...kl,...jl->...ij", Omega_ij, sigma_j, Omega_T)
    sigma_trans = sanitize_sigma(sigma_trans, eps=eps)
    sigma_inv = safe_inv(sigma_trans, eps=eps)

    delta_mu = mu_i - mu_trans
    d_mu = -np.einsum("...ij,...j->...i", sigma_inv, delta_mu)
    delta_sigma = sigma_i - sigma_trans
    d_sigma = -0.5 * np.einsum("...ik,...kl,...lj->...ij", sigma_inv, delta_sigma, sigma_inv)

    for a in range(d):
        G = generators[a]
        G_batch = np.broadcast_to(G, exp_phi_j.shape)
        G_right = np.einsum("...ij,...jk,...kl->...il", exp_phi_j, G_batch, exp_neg_phi_j)

        dphi_mu = -np.einsum("...ij,...j->...i", G_right, mu_j)

        G_right_sigma = np.einsum("...ij,...jk->...ik", G_right, sigma_j)
        dphi_sigma_1 = np.einsum("...ij,...jk->...ik", G_right_sigma, Omega_T)

        sigma_GT = np.einsum("...ij,jk->...ik", sigma_j, G.T)
        O_sigma_GT = np.einsum("...ij,...jk->...ik", Omega_ij, sigma_GT)
        dphi_sigma_2 = np.einsum("...ij,...jk->...ik", O_sigma_GT, Omega_T)

        dphi_sigma = dphi_sigma_1 + dphi_sigma_2

        term1 = np.sum(d_mu * dphi_mu, axis=-1)
        term2 = np.einsum("...ij,...ij->...", d_sigma, dphi_sigma)

        grad_phi_j[..., a] = term1 + term2

    return grad_phi_j




def term_trace_grad_phi_i(mu_i, sigma_i, mu_j, sigma_j, Omega_ij, generators, eps=1e-8):
    """
    Compute vector-valued trace term for ∂/∂φ_i KL(q_i || Ω_ij q_j)
    Term (for each a): Tr[ G_a ⋅ (Σ_i ⋅ (Ω Σ_j Ωᵀ)⁻¹) ]

    Returns:
        result : shape (H, W, d)
    """
    H, W, K = mu_i.shape
    d = generators.shape[0]

    # Transpose of Omega_ij: (H, W, K, K)
    Omega_T = np.swapaxes(Omega_ij, -1, -2)

    # Projected covariance: Ω Σ_j Ω^T → shape (H, W, K, K)
    sigma_ij = np.einsum("...ik,...kl,...jl->...ij", Omega_ij, sigma_j, Omega_T)
    sigma_ij = sanitize_sigma(sigma_ij, eps)
    sigma_ij_inv = safe_inv(sigma_ij, eps)

    # Compute Σ_i ⋅ Σ_ij⁻¹
    temp = np.einsum("...ik,...kl->...il", sigma_i, sigma_ij_inv)  # shape (H,W,K,K)

    # Trace for each generator
    traces = np.zeros((H, W, d), dtype=mu_i.dtype)
    for a in range(d):
        G = np.broadcast_to(generators[a], (H, W, K, K))
        traces[..., a] = np.einsum("...ij,...ji->...", G, temp)

    return traces  # shape (H, W, d)


   


from get_generators import get_generators  # import at top if not already

def term_mahalanobis_grad_phi_i(mu_i, sigma_i, mu_j, sigma_j, Omega_ij, generators=None, eps=1e-8):
    """
    Compute the full vector-valued gradient ∂/∂φ_i^a of the Mahalanobis term:
        (μ_i − Ω μ_j)^T · (Ω Σ_j Ω^T)^−1 · (μ_i − Ω μ_j)
    for all generators a = 1,...,d
    """
    H, W, K = mu_i.shape

    # ── Sanitize generators ──
    if generators is None or generators.ndim != 3 or generators.shape[1:] != (K, K):
        print(f"[WARNING] Using fallback SL(2,R) generators for K={K}")
        generators = get_generators("sl2r", K)

    d = generators.shape[0]

    # ── Sanitize mu_j ──
    mu_j = np.asarray(mu_j)
    if mu_j.ndim == 4:
        if mu_j.shape[-2] == 1:
            mu_j = mu_j.squeeze(-2)
        elif mu_j.shape[-1] == 1:
            mu_j = mu_j.squeeze(-1)
    assert mu_j.ndim == 3 and mu_j.shape == mu_i.shape, f"[BUG] mu_j shape = {mu_j.shape}, expected {(H, W, K)}"

    # ── Precompute quantities ──
    Omega_T = Omega_ij.transpose(0, 1, 3, 2)
    mu_j_bar = np.einsum("...ij,...j->...i", Omega_ij, mu_j)
    delta_mu = mu_i - mu_j_bar
    sigma_ij = np.einsum("...ik,...kl,...jl->...ij", Omega_ij, sigma_j, Omega_T)
    sigma_ij = sanitize_sigma(sigma_ij, eps)
    sigma_ij_inv = safe_inv(sigma_ij, eps)

    # ── Initialize output ──
    grad = np.zeros((H, W, d), dtype=mu_i.dtype)

    for a in range(d):
        G_a = generators[a]
        assert G_a.shape == (K, K), f"G_a has bad shape: {G_a.shape}"

        # ---- Term 1 ----
        tmp = np.einsum("...k,kl->...l", mu_j, G_a)
        mu_j_GO = np.einsum("...k,...kj->...j", tmp, Omega_ij)
        term1 = -np.einsum("...i,...ij,...j->...", delta_mu, sigma_ij_inv, mu_j_GO)

        # ---- Term 2 ----
        GO_T = np.einsum("jk,...kl->...jl", G_a.T, Omega_T)
        GO_T_sigma_inv = np.einsum("...jk,...kl->...jl", GO_T, sigma_ij_inv)
        mu_j_GO_T_sigma_inv = np.einsum("...j,...jk->...k", mu_j, GO_T_sigma_inv)
        term2 = -np.einsum("...k,...k->...", mu_j_GO_T_sigma_inv, delta_mu)

        # ---- Term 3 ----
        sym_term = (
            np.einsum("...ij,jk->...ik", sigma_ij_inv, G_a) +
            np.einsum("jk,...ij->...ik", G_a.T, sigma_ij_inv)
        )
        term3 = -np.einsum("...i,...ij,...j->...", delta_mu, sym_term, delta_mu)

        grad[..., a] = term1 + term2 + term3

    return grad  # shape (H, W, d)




def term_logdet_grad_phi_i(generators, H, W):
    """
    Batched Term 3: Gradient of log-determinant term
    ∂/∂φ_i^a Tr[log(det(Ω Σ Ω^T))] ≈ Tr[G + G^T] for each generator

    Args:
        generators : (d, K, K)
        H, W       : spatial grid dimensions

    Returns:
        grad_phi_i : (H, W, d) — broadcast scalar trace for each generator
    """
    d = generators.shape[0]
    traces = np.array([np.trace(G + G.T) for G in generators])  # shape (d,)
    grad = np.broadcast_to(traces[None, None, :], (H, W, d))    # shape (H, W, d)
    return grad



def term_trace_grad_phi_j(mu_i, sigma_i, mu_j, sigma_j,
                          Omega_ij, generators,
                          exp_phi_j, exp_neg_phi_j,
                          eps=1e-8):
    """
    Compute ∂/∂φ_j^a Tr[(Ω Σ_j Ωᵀ)^−1 (Ω G_R Σ_j Ωᵀ + Ω Σ_j G_Rᵀ Ωᵀ) Σ_i]
    where G_R = exp(φ_j) @ G_a @ exp(−φ_j)

    Args:
        generators     : (d, K, K)
        exp_phi_j      : (H, W, K, K)
        exp_neg_phi_j  : (H, W, K, K)

    Returns:
        gradient       : (H, W, d)
    """
    H, W, K, _ = sigma_i.shape
    d = generators.shape[0]
    Omega_T = np.transpose(Omega_ij, (0, 1, 3, 2))
    sigma_ij = Omega_ij @ sigma_j @ Omega_T
    sigma_ij = sanitize_sigma(sigma_ij, eps)
    sigma_ij_inv = safe_inv(sigma_ij, eps=eps)

    grads = []

    for a in range(d):
        G_a = generators[a]
        G_R = np.einsum("...ij,jk,...kl->...il", exp_phi_j, G_a, exp_neg_phi_j)  # shape (H, W, K, K)

        A = np.einsum("...ij,...jk,...kl->...il", Omega_ij, G_R, sigma_j)
        A = np.einsum("...ij,...jk->...ik", A, Omega_T)  # (H,W,K,K)

        G_R_T = np.transpose(G_R, (0, 1, 3, 2))
        B = np.einsum("...ij,...jk->...ik", sigma_j, G_R_T)
        B = np.einsum("...ij,...jk,...kl->...il", Omega_ij, B, Omega_T)

        term1 = np.einsum("...ij,...jk,...kl,...li->...", sigma_ij_inv, A, sigma_ij_inv, sigma_i)
        term2 = np.einsum("...ij,...jk,...kl,...li->...", sigma_ij_inv, B, sigma_ij_inv, sigma_i)

        grads.append(term1 + term2)  # shape (H, W)

    return np.stack(grads, axis=-1)  # shape (H, W, d)


def term_logdet_grad_phi_j(mu_i, sigma_i, mu_j, sigma_j,
                           Omega_ij, generators,
                           exp_phi_j, exp_neg_phi_j,
                           eps=1e-8):
    """
    Batched log-det term gradient ∂/∂φ_j^a KL(q_i || Ω_ij q_j)
    for each generator G_a:
        − Tr[ (Ω Σ_j Ωᵀ)^−1 (Ω G_R Σ_j Ωᵀ + Ω Σ_j G_Rᵀ Ωᵀ) ]
    where G_R = exp(φ_j) G_a exp(−φ_j)

    Args:
        generators     : (d, K, K)
        exp_phi_j      : (H, W, K, K)
        exp_neg_phi_j  : (H, W, K, K)

    Returns:
        gradient       : (H, W, d)
    """
    H, W, K, _ = sigma_j.shape
    d = generators.shape[0]

    Omega_T = np.transpose(Omega_ij, (0, 1, 3, 2))
    sigma_ij = Omega_ij @ sigma_j @ Omega_T
    sigma_ij = sanitize_sigma(sigma_ij, eps)
    sigma_ij_inv = safe_inv(sigma_ij, eps=eps)

    grads = []

    for a in range(d):
        G_a = generators[a]
        G_R = np.einsum("...ij,jk,...kl->...il", exp_phi_j, G_a, exp_neg_phi_j)  # (..., K, K)
        G_R_T = np.transpose(G_R, (0, 1, 3, 2))

        A = Omega_ij @ G_R @ sigma_j @ Omega_T
        B = Omega_ij @ sigma_j @ G_R_T @ Omega_T

        term1 = np.einsum("...ij,...ji->...", sigma_ij_inv, A)
        term2 = np.einsum("...ij,...ji->...", sigma_ij_inv, B)

        grads.append(-(term1 + term2))  # shape (H, W)

    return np.stack(grads, axis=-1)  # shape (H, W, d)


def term_mahalanobis_grad_phi_j(mu_i, sigma_i, mu_j, sigma_j,
                                 Omega_ij, generators,
                                 exp_phi_j, exp_neg_phi_j,
                                 eps=1e-8):
    """
    Batched Mahalanobis gradient ∂/∂φ_j^a KL(q_i || Ω_ij q_j)

    Args:
        generators     : (d, K, K)
        exp_phi_j      : (H, W, K, K)
        exp_neg_phi_j  : (H, W, K, K)

    Returns:
        gradient       : (H, W, d)
    """
    H, W, K = mu_j.shape
    d = generators.shape[0]

    Omega_T = np.transpose(Omega_ij, (0, 1, 3, 2))                         # (..., K, K)
    sigma_ij = Omega_ij @ sigma_j @ Omega_T
    sigma_ij = sanitize_sigma(sigma_ij, eps)
    sigma_ij_inv = safe_inv(sigma_ij, eps=eps)

    mu_j_bar = np.einsum("...ij,...j->...i", Omega_ij, mu_j)
    delta_mu = mu_i - mu_j_bar  # (..., K)

    grads = []

    for a in range(d):
        G_a = generators[a]
        G_R = np.einsum("...ij,jk,...kl->...il", exp_phi_j, G_a, exp_neg_phi_j)
        G_R_T = np.transpose(G_R, (0, 1, 3, 2))

        # --- Term 1 ---
        mu_j_G_O = np.einsum("...i,ij,jk->...k", mu_j, G_a, Omega_ij)
        term1 = -np.einsum("...i,...ij,...j->...", delta_mu, sigma_ij_inv, mu_j_G_O)

        # --- Term 2 ---
        mu_j_GR_O = np.einsum("...i,...ij->...j", mu_j, G_R_T)
        tmp_term2 = np.einsum("...ij,...j->...i", sigma_ij_inv, delta_mu)
        term2 = -np.einsum("...i,...i->...", mu_j_GR_O @ Omega_T, tmp_term2)

        # --- Term 3 ---
        A = Omega_ij @ G_R @ sigma_j @ Omega_T
        B = Omega_ij @ sigma_j @ G_R_T @ Omega_T
        M = A + B

        tmp = np.einsum("...i,...ij->...j", delta_mu, sigma_ij_inv)
        tmp2 = np.einsum("...j,...jk->...k", tmp, M)
        tmp3 = np.einsum("...k,...kl->...l", tmp2, sigma_ij_inv)
        term3 = -np.einsum("...i,...i->...", delta_mu, tmp3)

        grads.append(term1 + term2 + term3)

    return np.stack(grads, axis=-1)  # shape (H, W, d)

