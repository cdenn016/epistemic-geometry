# -*- coding: utf-8 -*-
"""
Created on Wed Aug  6 12:27:32 2025

@author: chris and christine
"""
 
import numpy as np
import core.config as config
from core.numerical_utils import sanitize_sigma, safe_inv, push_gaussian
from core.transport_cache import Omega
from core.transport_cache import Phi_cached
from runtime_context import cfg_get
from core.numerical_utils import kl_gaussian
from beta_grads import grad_beta_mu_sigma_dispatch

from utils import (_fiber_keys_from_mode, _iter_overlap_pairs, _accumulate_into_agent,
                   _drain_inbox_into_dalign, _add_to_inbox, _mu_mag, _S_mag )


# -------------------------------------------------------------------------
#                          PUBLIC ENTRYPOINTS
# -------------------------------------------------------------------------


def accumulate_mu_sigma_gradient(ctx, agent_i, agents, mode):
    """
    Accumulate natural gradients (μ, Σ) for belief or model.

    Structure:
      1) Resolve fiber + keys (q/p)
      2) Pull Φ, Φ̃ from cache and push (q,p) once
      3) Self & feedback grads (receiver-only)
      4) Pairwise alignment grads (β ⊙ align  −  (β/κ) KL1 ⊙ β-basis)
      5) Combine -> natural projection -> accumulate to agent_i

    Inputs:
      ctx       : runtime context (required)
      agent_i   : receiver agent
      agents    : full list (for neighbors)
      mode      : {"belief","model"}
    """
    if ctx is None:
        raise RuntimeError("accumulate_mu_sigma_gradient: ctx required.")

    from runtime_context import cfg_get
    
    eps  = float(cfg_get(ctx, "eps", 1e-6))
    tau  = float(cfg_get(ctx, "support_tau", 1e-6))
    alpha = float(cfg_get(ctx, "alpha", 0.0))
    lambd = float(cfg_get(ctx, "feedback_weight", 0.0))

    accum_send = bool(cfg_get(ctx, "accumulate_sender_grads", False))
    
    which, field, mu_key, S_key, gmu_key, gS_key = _fiber_keys_from_mode(mode)

    # ---------------- 2) Φ/Φ̃ pushes once ----------------
    
    Phi  = Phi_cached(ctx, agent_i, kind="q_to_p")   # Φ: Q→P
    Phit = Phi_cached(ctx, agent_i, kind="p_to_q")   # Φ̃: P→Q
    

    mu_q = getattr(agent_i, "mu_q_field")
    S_q  = getattr(agent_i, "sigma_q_field")
    mu_p = getattr(agent_i, "mu_p_field")
    S_p  = getattr(agent_i, "sigma_p_field")

    
    mu_q_push, S_q_push, inv_q_push = push_gaussian(
        mu_q, S_q, Phi, eps=eps, return_inv=True,
        Sigma_inv=getattr(agent_i, "sigma_q_inv", None),
        assume_orthogonal=False
    )
    mu_p_push, S_p_push, inv_p_push = push_gaussian(
        mu_p, S_p, Phit, eps=eps, return_inv=True,
        Sigma_inv=getattr(agent_i, "sigma_p_inv", None),
        assume_orthogonal=False
    )
    
    
    # --- self/feedback ENERGY accounting (unweighted, float64-safe) ---
    accumulate_self_feedback_energies(
        ctx, agent_i,
        mu_q=mu_q, S_q=S_q,
        mu_p=mu_p, S_p=S_p,
        mu_q_push=mu_q_push, S_q_push=S_q_push,
        mu_p_push=mu_p_push, S_p_push=S_p_push,
    )

    
    g_self_mu, g_self_S, g_fb_mu, g_fb_S = _self_and_feedback_grads(
        mode,
        mu_q, S_q, mu_p, S_p,
        mu_q_push, S_q_push, inv_q_push,
        mu_p_push, S_p_push, inv_p_push,
        Phi, Phit, eps,
        sigma_q_inv=getattr(agent_i, "sigma_q_inv", None),
        sigma_p_inv=getattr(agent_i, "sigma_p_inv", None),
        mask=getattr(agent_i, "mask", None),
    )
    
    
   
    # Target buffers (shape-safe, prezeroed)
    mu_i = np.asarray(getattr(agent_i, mu_key), np.float32, order="C")
    S_i  = np.asarray(getattr(agent_i, S_key),  np.float32, order="C")
    dmu_align = np.zeros_like(mu_i, dtype=np.float32)
    dS_align  = np.zeros_like(S_i,  dtype=np.float32)

    if accum_send:
        dmu_align, dS_align = _drain_inbox_into_dalign(agent_i, which, dmu_align, dS_align)
        
    # -------- 4a) Precompute β-weighted average of ALIGN grads for receiver i --------
    Sshape = tuple(getattr(agent_i, mu_key).shape[:-1])
    Ki = int(getattr(agent_i, mu_key).shape[-1])
    gbar_mu_i = np.zeros(Sshape + (Ki,),    np.float32)
    gbar_S_i  = np.zeros(Sshape + (Ki, Ki), np.float32)

    _pairs = []  # stash per-neighbor ingredients to reuse in pass 2

    for agent_j, overlap in _iter_overlap_pairs(agent_i, agents, tau=tau):
        if not np.any(overlap):
            continue

        i_id = int(getattr(agent_i, "id", -1))
        j_id = int(getattr(agent_j, "id", -1))
        beta_map = np.asarray(ctx._edge_beta[(which, i_id, j_id)], np.float32)
        KL1_map  = np.asarray(ctx._edge_kl1 [(which, i_id, j_id)], np.float32)

        m  = overlap.astype(np.float32, copy=False)
        beta_ij = beta_map * m
        KL1     = KL1_map  * m
        if not np.any(beta_ij > 0):
            continue

        # ALIGN transport is on the current fiber
        Om_align = Omega(ctx, agent_i, agent_j, which=which)

        # stats
        mu_i_arr = np.asarray(getattr(agent_i, mu_key), np.float32, order="C")
        S_i_arr  = sanitize_sigma(np.asarray(getattr(agent_i, S_key), np.float64), eps=eps).astype(np.float32, copy=False)
        mu_j_arr = np.asarray(getattr(agent_j, mu_key), np.float32, order="C")
        S_j_arr  = sanitize_sigma(np.asarray(getattr(agent_j, S_key), np.float64), eps=eps).astype(np.float32, copy=False)

        # push & ALIGN grads (these are ∂ L_align_ij)
        mu_j_t, S_j_t, inv_j_t = push_gaussian(mu_j_arr, S_j_arr, Om_align, eps=eps, return_inv=True, sanitize_input=False)
        gmu_align, gS_align = grad_alignment_energy_source(
            mu_i_arr, S_i_arr, mu_j_t, inv_j_t, eps=eps, sigma_i_inv=None, assume_sanitized=True
        )
        gmu_align_j, gS_align_j = grad_alignment_energy_target(
            mu_i=mu_i_arr, sigma_i=S_i_arr,
            mu_j_t=mu_j_t, sigma_j_t_inv=inv_j_t,
            Omega_ij=Om_align, eps=eps, assume_sanitized=True
        )

        # β-weighted receiver-average for product rule
        gbar_mu_i += beta_ij[..., None]       * gmu_align
        gbar_S_i  += beta_ij[..., None, None] * gS_align

        _pairs.append(dict(
            j=agent_j, overlap=overlap, m=m,
            beta_ij=beta_ij, KL1=KL1,
            Om_align=Om_align,
            gmu_align=gmu_align, gS_align=gS_align,
            gmu_align_j=gmu_align_j, gS_align_j=gS_align_j,
        ))

    # -------- 4b) Second pass: exact softmax product rule for β·KL_align --------
    for P in _pairs:
        agent_j = P["j"]; overlap = P["overlap"]; m = P["m"]
        beta_ij = P["beta_ij"]; KL1 = P["KL1"]
        gmu_align   = P["gmu_align"];   gS_align   = P["gS_align"]
        gmu_align_j = P["gmu_align_j"]; gS_align_j = P["gS_align_j"]

        kappa = max(float(cfg_get(ctx, f"beta_kappa_{which}", 1.0)), 1e-12)
        factor = (beta_ij * (KL1 / kappa)).astype(np.float32, copy=False)

        # Receiver i: β * ∂L + (β*KL/κ) * ( ḡ_i - ∂L_ij )
        add_mu_i = beta_ij[..., None]       * gmu_align \
                 + factor[...,  None]       * (gbar_mu_i - gmu_align)
        add_S_i  = beta_ij[..., None, None] * gS_align \
                 + factor[...,  None, None] * (gbar_S_i  - gS_align)

        # Sender j: only j has sender params in L_ij, so avg reduces to β_ij * ∂L_sender
        # ⇒ β*∂L_sender + (β*KL/κ) * (β*∂L_sender - ∂L_sender) = β*∂L_sender + factor*(β-1)*∂L_sender
        add_mu_j = beta_ij[..., None]       * gmu_align_j \
                 + (factor * (beta_ij - 1.0))[..., None]       * gmu_align_j
        add_S_j  = beta_ij[..., None, None] * gS_align_j \
                 + (factor * (beta_ij - 1.0))[..., None, None] * gS_align_j

        # scatter receiver (i)
        dmu_align[overlap] += add_mu_i[overlap]
        dS_align [overlap] += add_S_i [overlap]

        # enqueue sender (j) — j will drain and project on its turn
        if accum_send:
            _add_to_inbox(agent_j, which, add_mu_j, add_S_j, overlap)

        # ---- γ (Case A/B) terms unchanged ----
        g_mu_i_G, g_S_i_G, g_mu_j_G, g_S_j_G = _accum_gamma_mu_sigma_for_pair(
            ctx,
            agent_i, agent_j,
            mu_key=mu_key, S_key=S_key,
            overlap_mask=overlap, eps=eps,
            Phi_i=Phi, Phi_tilde_i=Phit,
            Omega_q_ij=Omega(ctx, agent_i, agent_j, which="q"),
        )
        
        # ---- Track A/B energies (raw KL and gamma-weighted) ----
        _accum_gamma_AB_energies_for_pair(ctx, agent_i, agent_j, overlap, eps=eps, write_maps=True)

        
        dmu_align[overlap] += g_mu_i_G[overlap]
        dS_align [overlap] += g_S_i_G [overlap]
        if accum_send:
            _add_to_inbox(agent_j, which, g_mu_j_G, g_S_j_G, overlap)
    
    
    # -------- 5) combine + natural projection --------

    dmu_total = (alpha * g_self_mu + lambd * g_fb_mu + dmu_align).astype(np.float32, copy=False)
    dS_total  = (alpha * g_self_S  + lambd * g_fb_S  + dS_align ).astype(np.float32, copy=False)
    dS_total  = 0.5 * (dS_total + np.swapaxes(dS_total, -1, -2))
    

    delta_mu, delta_S = apply_natural_gradient_batch(
        ctx,
        getattr(agent_i, mu_key), getattr(agent_i, S_key),
        dmu_total, dS_total,
        mask=getattr(agent_i, "mask", None),
        assume_sanitized=True,
        grad_sigma_is_symmetric = True,
        use_float64 = True,
    )
    
    # -------- 6) accumulate to agent --------
    _accumulate_into_agent(agent_i, gmu_key, gS_key, delta_mu, delta_S)

    
    return delta_mu, delta_S






def _accum_align_for_pair_clean(
    ctx,
    agent_i, agent_j,
    *,
    fiber: str,          # 'q' or 'p'
    mu_key: str,
    S_key: str,
    overlap_mask: np.ndarray,
    eps: float,
    gbar_mu_i: np.ndarray,   # PRECOMPUTED β-weighted receiver avg of ALIGN μ-grad
    gbar_S_i:  np.ndarray,   # PRECOMPUTED β-weighted receiver avg of ALIGN Σ-grad
    Phi=None, Phi_tilde=None # kept for API compat; unused when β==align
):
    dbg_pair = False

    i_id = int(getattr(agent_i, "id", -1))
    j_id = int(getattr(agent_j, "id", -1))

    # --- fetch maps (read-only!) ---
    beta_map = np.asarray(ctx._edge_beta[(fiber, i_id, j_id)], np.float32, order="C")
    KL1_map  = np.asarray(ctx._edge_kl1 [(fiber, i_id, j_id)], np.float32, order="C")
    if beta_map.shape != overlap_mask.shape or KL1_map.shape != overlap_mask.shape:
        raise ValueError("β/KL1 map shape mismatch vs overlap")

    m       = overlap_mask.astype(np.float32, copy=False)
    beta_ij = beta_map * m
    KL1     = KL1_map  * m

    # ---------- early return: MUST return 4 tensors ----------
    if not np.any(beta_ij > 0):
        Sshape = tuple(overlap_mask.shape)
        Ki = int(getattr(agent_i, mu_key).shape[-1])
        Kj = int(getattr(agent_j, mu_key).shape[-1])
        zero_mu_i = np.zeros(Sshape + (Ki,),    np.float32)
        zero_S_i  = np.zeros(Sshape + (Ki, Ki), np.float32)
        zero_mu_j = np.zeros(Sshape + (Kj,),    np.float32)
        zero_S_j  = np.zeros(Sshape + (Kj, Kj), np.float32)
        return zero_mu_i, zero_S_i, zero_mu_j, zero_S_j

    # ---------- transports ----------
    Om_align = Omega(ctx, agent_i, agent_j, which=fiber)

    # ---------- receiver/sender stats ----------
    mu_i = np.asarray(getattr(agent_i, mu_key), np.float32, order="C")
    S_i  = sanitize_sigma(np.asarray(getattr(agent_i, S_key), np.float64), eps=eps).astype(np.float32, copy=False)
    mu_j = np.asarray(getattr(agent_j, mu_key), np.float32, order="C")
    S_j  = sanitize_sigma(np.asarray(getattr(agent_j, S_key), np.float64), eps=eps).astype(np.float32, copy=False)

    # ---------- ALIGN push & ALIGN grads ----------
    mu_j_t, S_j_t, inv_j_t = push_gaussian(mu_j, S_j, Om_align, eps=eps, return_inv=True, sanitize_input=False)

    # Receiver ALIGN ∂L_ij
    gmu_align, gS_align = grad_alignment_energy_source(
        mu_i, S_i, mu_j_t, inv_j_t, eps=eps, sigma_i_inv=None, assume_sanitized=True
    )
    # Sender ALIGN ∂L_ij^(sender)
    gmu_align_j, gS_align_j = grad_alignment_energy_target(
        mu_i=mu_i, sigma_i=S_i,
        mu_j_t=mu_j_t, sigma_j_t_inv=inv_j_t,
        Omega_ij=Om_align, eps=eps, assume_sanitized=True
    )

    # ---------- exact softmax product rule (β == align) ----------
    kappa = max(float(cfg_get(ctx, f"beta_kappa_{fiber}", 1.0)), 1e-12)
    factor = (beta_ij * (KL1 / kappa)).astype(np.float32, copy=False)

    # Receiver i: β * ∂L + (β*KL/κ) * ( ḡ_i - ∂L_ij )
    gmu_i = beta_ij[..., None]       * gmu_align \
          + factor[...,  None]       * (gbar_mu_i - gmu_align)
    gS_i  = beta_ij[..., None, None] * gS_align \
          + factor[...,  None, None] * (gbar_S_i  - gS_align)

    # Sender j: β * ∂L_sender + (β*KL/κ) * (β-1) * ∂L_sender
    scale_sender = (factor * (beta_ij - 1.0)).astype(np.float32, copy=False)
    gmu_j = beta_ij[..., None]       * gmu_align_j + scale_sender[..., None]       * gmu_align_j
    gS_j  = beta_ij[..., None, None] * gS_align_j  + scale_sender[..., None, None] * gS_align_j

    # --- add gamma (A/B) terms (they have their own product rule internally) ---
    g_mu_i_G, g_S_i_G, g_mu_j_G, g_S_j_G = _accum_gamma_mu_sigma_for_pair(
        ctx,
        agent_i, agent_j,
        mu_key=mu_key, S_key=S_key,
        overlap_mask=overlap_mask, eps=eps,
        Phi_i=None, Phi_tilde_i=None,          # γ uses Ω^q & Φ/Φ̃ internally
        Omega_q_ij=Omega(ctx, agent_i, agent_j, which="q"),
    )
    gmu_i += g_mu_i_G
    gS_i  += g_S_i_G
    gmu_j += g_mu_j_G
    gS_j  += g_S_j_G

    if dbg_pair:
        print(f"[PAIR MAG i] fiber={fiber} i={i_id} j={j_id} "
              f"| align μ={_mu_mag(gmu_i):.3e} Σ={_S_mag(gS_i):.3e}", flush=True)

    return gmu_i.astype(np.float32, copy=False), gS_i.astype(np.float32, copy=False), \
           gmu_j.astype(np.float32, copy=False), gS_j.astype(np.float32, copy=False)


#-----Cross Fiber Case A and Case B
def _accum_gamma_mu_sigma_for_pair(
    ctx,
    agent_i, agent_j,
    *,
    mu_key: str,
    S_key: str,
    overlap_mask: np.ndarray,
    eps: float,
    Phi_i,            # Φ_i (Q→P)
    Phi_tilde_i,      # Φ̃_i (P→Q)  (kept for dispatcher symmetry)
    Omega_q_ij,       # Ω^q_ij (reused; no recompute)
):
    import numpy as np
    
    from runtime_context import cfg_get

    i_id = int(getattr(agent_i, "id", -1))
    j_id = int(getattr(agent_j, "id", -1))

    Sshape = tuple(overlap_mask.shape)
    Ki = int(getattr(agent_i, mu_key).shape[-1])
    Kj = int(getattr(agent_j, mu_key).shape[-1])

    add_mu_i = np.zeros(Sshape + (Ki,),    np.float32)
    add_S_i  = np.zeros(Sshape + (Ki, Ki), np.float32)
    add_mu_j = np.zeros(Sshape + (Kj,),    np.float32)
    add_S_j  = np.zeros(Sshape + (Kj, Kj), np.float32)

    if not np.any(overlap_mask):
        return add_mu_i, add_S_i, add_mu_j, add_S_j

    m = overlap_mask.astype(np.float32, copy=False)

    # directed gammas (may be None) and their KL maps
    gA = ctx._edge_gamma.get(("A", j_id, i_id), None)  # j→i
    gB = ctx._edge_gamma.get(("B", i_id, j_id), None)  # i→j
    KA = ctx._edge_klX.get(("A", j_id, i_id), None)
    KB = ctx._edge_klX.get(("B", i_id, j_id), None)

    if (gA is None and gB is None):
        return add_mu_i, add_S_i, add_mu_j, add_S_j

   
    kq = float(cfg_get(ctx, "kappa_gamma_q", 1.0))
    kp = float(cfg_get(ctx, "kappa_gamma_p", 1.0))

    # ---- Case A (basis="a"): KL(q_j || Ω^q_ji [ Φ̃_i p_i ]) ----
    if gA is not None:
        wA = np.asarray(gA, np.float32) * m
        if np.any(wA):
            if KA is not None:
                wA = wA * (1.0 - np.asarray(KA, np.float32) / max(kq, 1e-12))
            outA = grad_beta_mu_sigma_dispatch(
                ctx, agent_i, agent_j,
                basis="a",
                Omega_ij=Omega_q_ij,
                Phi_i=Phi_i,
                eps=eps,
            )
            add_mu_i += wA[..., None]       * outA["mu_rec"]
            add_S_i  += wA[..., None, None] * outA["S_rec"]
            add_mu_j += wA[..., None]       * outA["mu_send"]
            add_S_j  += wA[..., None, None] * outA["S_send"]

    # ---- Case B (basis="b"): KL(p_i || Φ_i [ Ω^q_ij q_j ]) ----
    if gB is not None:
        wB = np.asarray(gB, np.float32) * m
        if np.any(wB):
            if KB is not None:
                wB = wB * (1.0 - np.asarray(KB, np.float32) / max(kp, 1e-12))
            outB = grad_beta_mu_sigma_dispatch(
                ctx, agent_i, agent_j,
                basis="b",
                Omega_ij=Omega_q_ij,
                Phi_i=Phi_i,
                eps=eps,
            )
            add_mu_i += wB[..., None]       * outB["mu_rec"]
            add_S_i  += wB[..., None, None] * outB["S_rec"]
            add_mu_j += wB[..., None]       * outB["mu_send"]
            add_S_j  += wB[..., None, None] * outB["S_send"]

    return add_mu_i, add_S_i, add_mu_j, add_S_j

# --- Self / Feedback energy accumulation (shared with diagnostics) ---


def accumulate_self_feedback_energies(
    ctx,
    agent_i,
    *,
    mu_q, S_q,
    mu_p, S_p,
    mu_q_push, S_q_push,
    mu_p_push, S_p_push,
):
    """
    Accumulate UNWEIGHTED pixel-summed KLs into the per-step accumulator:
      self_sum     += sum_px KL(q || p')
      feedback_sum += sum_px KL(p || q')

    Keep α, λ application outside (e.g., in compute_global_metrics/total_energy),
    just like alignment stores unweighted KL. Returns (self_raw, feedback_raw).
    """
    import numpy as np
    from runtime_context import cfg_get, energy_acc_add
    from core.numerical_utils import sanitize_sigma

    eps = float(cfg_get(ctx, "eps", 1e-8))
    tau = float(cfg_get(ctx, "support_tau", 1e-6))

    # common support mask
    m = np.asarray(getattr(agent_i, "mask", 1.0), np.float32)
    mm = (m > tau) if (m.dtype != bool) else m
    if not np.any(mm):
        return 0.0, 0.0

    # slice active pixels
    μq  = np.asarray(mu_q[mm],      np.float64, order="C")
    Σq  = sanitize_sigma(np.asarray(S_q[mm],    np.float64, order="C"), eps=eps)
    μp  = np.asarray(mu_p[mm],      np.float64, order="C")
    Σp  = sanitize_sigma(np.asarray(S_p[mm],    np.float64, order="C"), eps=eps)
    μqʹ = np.asarray(mu_q_push[mm], np.float64, order="C")
    Σqʹ = sanitize_sigma(np.asarray(S_q_push[mm], np.float64, order="C"), eps=eps)
    μpʹ = np.asarray(mu_p_push[mm], np.float64, order="C")
    Σpʹ = sanitize_sigma(np.asarray(S_p_push[mm], np.float64, order="C"), eps=eps)

    # pixelwise KLs (unweighted)
    self_px     = kl_gaussian(μq, Σq, μpʹ, Σpʹ, eps=eps)   # KL(q || p')
    feedback_px = kl_gaussian(μp, Σp, μqʹ, Σqʹ, eps=eps)   # KL(p || q')

    self_raw = float(np.sum(self_px))
    fb_raw   = float(np.sum(feedback_px))

    # Accumulate UNWEIGHTED totals (match alignment convention)
    energy_acc_add(ctx, "self_sum",     self_raw)
    energy_acc_add(ctx, "feedback_sum", fb_raw)

    # Optional per-agent buckets (mirrors your alignment helper)
    aid = getattr(agent_i, "id", None)
    if aid is not None:
        energy_acc_add(ctx, f"self_sum[{aid}]",     self_raw)
        energy_acc_add(ctx, f"feedback_sum[{aid}]", fb_raw)

    return self_raw, fb_raw


def _accum_gamma_AB_energies_for_pair(ctx, agent_i, agent_j, overlap, *, eps=1e-8, write_maps=True):
    """
    Accumulate A/B energies for the directed pair (i <- j), masked to `overlap`.

    Uses caches from `compute_edge_gammas` when present:
      ctx._edge_gamma[("A", j,i)], ctx._edge_klX[("A", j,i)]
      ctx._edge_gamma[("B", i,j)], ctx._edge_klX[("B", i,j)]

    Writes running totals via energy_acc_add:
      "KL_A_raw", "KL_B_raw", "Gamma_A", "Gamma_B"

    If `write_maps=True`, also writes per-pixel maps into ctx.fields:
      "KL_A", "KL_B", "Gamma_A_map", "Gamma_B_map"
    (created on first use with zeros and overwritten on each call for this pair)
    """
    import numpy as np
    from runtime_context import energy_acc_add, cfg_get
    from core.transport_cache import Omega, Phi
    from core.numerical_utils import push_gaussian, kl_gaussian

    i_id = int(getattr(agent_i, "id", -1))
    j_id = int(getattr(agent_j, "id", -1))
    Sshape = tuple(getattr(agent_i, "mu_q_field").shape[:-1])

    if not hasattr(ctx, "fields"):
        ctx.fields = {}

    m = overlap.astype(np.bool_)
    if not np.any(m):
        return

    # ---------- Case A: q_j || Ω^q_ji[Φ̃_i p_i] ----------
    gA = ctx._edge_gamma.get(("A", j_id, i_id), None)
    KL_A = ctx._edge_klX.get(("A", j_id, i_id), None)
    if (gA is not None) or (KL_A is not None):
        # If KL_A missing (toggle path), compute once on the fly
        if KL_A is None:
            Om_ji = Omega(ctx, agent_j, agent_i, which="q")
            Phit  = Phi(ctx, agent_i, kind="p_to_q")
            mu_phit_i, S_phit_i = push_gaussian(agent_i.mu_p_field, agent_i.sigma_p_field, Phit, eps=eps)[:2]
            mu_t, S_t = push_gaussian(mu_phit_i, S_phit_i, Om_ji, eps=eps)[:2]
            KL_A = kl_gaussian(agent_j.mu_q_field, agent_j.sigma_q_field, mu_t, S_t, eps=eps)
        KL_A = np.asarray(KL_A, np.float32)

        # gamma_A may be None (if toggle fully off); treat as zeros
        gA = np.zeros(Sshape, np.float32) if gA is None else np.asarray(gA, np.float32)

        # Totals (masked)
        energy_acc_add(ctx, "KL_A_raw", float(np.sum(KL_A[m])))
        energy_acc_add(ctx, "Gamma_A",  float(np.sum((gA * KL_A)[m])))

        if write_maps:
            if "KL_A" not in ctx.fields:        ctx.fields["KL_A"]        = np.zeros(Sshape, np.float32)
            if "Gamma_A_map" not in ctx.fields: ctx.fields["Gamma_A_map"] = np.zeros(Sshape, np.float32)
            # Overwrite at the masked pixels (so the last writer wins for that (i,j); totals are in energy_acc)
            ctx.fields["KL_A"][m]        = KL_A[m]
            ctx.fields["Gamma_A_map"][m] = (gA * KL_A)[m]

    # ---------- Case B: p_i || Φ_i[Ω^q_ij q_j] ----------
    gB = ctx._edge_gamma.get(("B", i_id, j_id), None)
    KL_B = ctx._edge_klX.get(("B", i_id, j_id), None)
    if (gB is not None) or (KL_B is not None):
        if KL_B is None:
            Om_ij = Omega(ctx, agent_i, agent_j, which="q")
            Phi_i = Phi(ctx, agent_i, kind="q_to_p")
            mu_t, S_t = push_gaussian(agent_j.mu_q_field, agent_j.sigma_q_field, Om_ij, eps=eps)[:2]
            mu_phi, S_phi = push_gaussian(mu_t, S_t, Phi_i, eps=eps)[:2]
            KL_B = kl_gaussian(agent_i.mu_p_field, agent_i.sigma_p_field, mu_phi, S_phi, eps=eps)
        KL_B = np.asarray(KL_B, np.float32)

        gB = np.zeros(Sshape, np.float32) if gB is None else np.asarray(gB, np.float32)

        energy_acc_add(ctx, "KL_B_raw", float(np.sum(KL_B[m])))
        energy_acc_add(ctx, "Gamma_B",  float(np.sum((gB * KL_B)[m])))

        if write_maps:
            if "KL_B" not in ctx.fields:        ctx.fields["KL_B"]        = np.zeros(Sshape, np.float32)
            if "Gamma_B_map" not in ctx.fields: ctx.fields["Gamma_B_map"] = np.zeros(Sshape, np.float32)
            ctx.fields["KL_B"][m]        = KL_B[m]
            ctx.fields["Gamma_B_map"][m] = (gB * KL_B)[m]




def accumulate_gamma_action_energy(ctx, agent_i, agent_j, *, eps=1e-8):
    """
    Adds gamma-weighted A/B KLs to ctx.energy_acc.
    Uses cached KLs from compute_edge_gammas when available.
    """
    import numpy as np
    from runtime_context import energy_acc_add, cfg_get
    from core.transport_cache import Omega, Phi
    from core.numerical_utils import push_gaussian, kl_gaussian

    i_id = int(getattr(agent_i, "id", -1))
    j_id = int(getattr(agent_j, "id", -1))

    # joint mask (only count where both agents are "on")
    mi = np.asarray(getattr(agent_i, "mask"), np.float32)
    mj = np.asarray(getattr(agent_j, "mask"), np.float32)
    Sshape = tuple(getattr(agent_i, "mu_q_field").shape[:-1])
    if mi.shape != Sshape: mi = np.broadcast_to(mi, Sshape)
    if mj.shape != Sshape: mj = np.broadcast_to(mj, Sshape)
    tau = float(cfg_get(ctx, "support_tau", 1e-6))
    joint = (mi > tau) & (mj > tau)
    if not np.any(joint):
        return

    # ---------- Case A: KL(q_j || Ω^q_ji[Φ̃_i p_i]) ----------
    gamma_A = ctx._edge_gamma.get(("A", j_id, i_id), None)
    if gamma_A is not None:
        gA = np.asarray(gamma_A, np.float32)
        if gA.shape != Sshape:
            raise ValueError(f"gamma_A shape {gA.shape} != spatial {Sshape}")

        # Prefer cached KL if present (skips heavy pushes)
        KL_A = ctx._edge_klX.get(("A", j_id, i_id), None)
        if KL_A is None:
            # toggles may skip KL cache; compute on the fly
            Om_ji = Omega(ctx, agent_j, agent_i, which="q")
            Phit  = Phi(ctx, agent_i, kind="p_to_q")
            mu_phit_i, S_phit_i = push_gaussian(agent_i.mu_p_field, agent_i.sigma_p_field, Phit, eps=eps)[:2]
            mu_t, S_t = push_gaussian(mu_phit_i, S_phit_i, Om_ji, eps=eps)[:2]
            KL_A = kl_gaussian(agent_j.mu_q_field, agent_j.sigma_q_field, mu_t, S_t, eps=eps)
        KL_A = np.asarray(KL_A, np.float32)

        valA = np.sum((gA * KL_A)[joint])
        if np.isfinite(valA):
            energy_acc_add(ctx, "Gamma_A", float(valA))

    # ---------- Case B: KL(p_i || Φ_i[Ω^q_ij q_j]) ----------
    gamma_B = ctx._edge_gamma.get(("B", i_id, j_id), None)
    if gamma_B is not None:
        gB = np.asarray(gamma_B, np.float32)
        if gB.shape != Sshape:
            raise ValueError(f"gamma_B shape {gB.shape} != spatial {Sshape}")

        KL_B = ctx._edge_klX.get(("B", i_id, j_id), None)
        if KL_B is None:
            Om_ij = Omega(ctx, agent_i, agent_j, which="q")
            Phi_i = Phi(ctx, agent_i, kind="q_to_p")
            mu_t, S_t = push_gaussian(agent_j.mu_q_field, agent_j.sigma_q_field, Om_ij, eps=eps)[:2]
            mu_phi, S_phi = push_gaussian(mu_t, S_t, Phi_i, eps=eps)[:2]
            KL_B = kl_gaussian(agent_i.mu_p_field, agent_i.sigma_p_field, mu_phi, S_phi, eps=eps)
        KL_B = np.asarray(KL_B, np.float32)

        valB = np.sum((gB * KL_B)[joint])
        if np.isfinite(valB):
            energy_acc_add(ctx, "Gamma_B", float(valB))




def _self_and_feedback_grads(
    mode: str,
    mu_q, sigma_q, mu_p, sigma_p,
    mu_q_push, Sigma_q_push, inv_q_push,
    mu_p_push, Sigma_p_push, inv_p_push,
    Phi_mat, Phi_tilde_mat, eps: float,
    *, sigma_q_inv=None, sigma_p_inv=None, mask=None
):
    if mode == "belief":
        g_self_mu, g_self_S = grad_self_energy_belief(
            mu_q, sigma_q, mu_p_push, inv_p_push,
            sigma_q_inv=sigma_q_inv, mask=mask
        )
        g_fb_mu, g_fb_S = grad_feedback_energy_belief(
            mu_q, sigma_q, mu_p, mu_q_push,
            Sigma_q_push, inv_q_push, sigma_p, Phi_mat
        )
    elif mode == "model":
        g_self_mu, g_self_S = grad_self_energy_model(
            mu_q, sigma_q, mu_p_push, inv_p_push, Phi_tilde_mat, mask=mask
        )
        g_fb_mu, g_fb_S = grad_feedback_energy_model(
            mu_p, sigma_p, mu_q_push, Sigma_q_push, inv_q_push,
            sigma_p_inv=sigma_p_inv
        )
    else:
        raise ValueError(f"Unsupported mode: {mode}")
    return g_self_mu, g_self_S, g_fb_mu, g_fb_S




#==============================================================================
#
#                    FEEDBACK / SELF TERMS (unchanged math, safer numerics)
#==============================================================================

def grad_alignment_energy_source(
    mu_i, sigma_i, mu_j_t, sigma_j_t_inv, eps=1e-8,
    *, sigma_i_inv=None, assume_sanitized=True
):
    """
    Faster: reuse precomputed sigma_i_inv if provided; optionally skip sanitize.
    """
    mu_i       = np.asarray(mu_i,       dtype=np.float32, order="C")
    mu_j_t     = np.asarray(mu_j_t,     dtype=np.float32, order="C")
    sigma_j_t_inv = np.asarray(sigma_j_t_inv, dtype=np.float32, order="C")

    dmu = mu_i - mu_j_t
    # grad_mu_i = S'^-1 (μ_i - μ_j')
    grad_mu = np.einsum("...ij,...j->...i", sigma_j_t_inv, dmu, optimize=True)

    if sigma_i_inv is None:
        Si = np.asarray(sigma_i, dtype=np.float32, order="C")
        if not assume_sanitized:
            Si = sanitize_sigma(Si, eps=eps)
        sigma_i_inv = safe_inv(Si)   # batched cholesky-inv

    grad_sigma = 0.5 * (sigma_j_t_inv - sigma_i_inv)
    # symmetrize
    grad_sigma = 0.5 * (grad_sigma + np.swapaxes(grad_sigma, -1, -2))

    return grad_mu.astype(np.float32, copy=False), grad_sigma.astype(np.float32, copy=False)


def grad_alignment_energy_target(
    mu_i, sigma_i, mu_j_t, sigma_j_t_inv, Omega_ij, eps: float = 1e-8,
    *, assume_sanitized=True
):
    """
    Faster: use v = S'^-1 dμ  ->  v vᵀ for the middle term; skip repeated sanitize.
    """
    mu_i       = np.asarray(mu_i,       dtype=np.float32, order="C")
    mu_j_t     = np.asarray(mu_j_t,     dtype=np.float32, order="C")
    Omega_ij   = np.asarray(Omega_ij,   dtype=np.float32, order="C")
    sigma_jinv = np.asarray(sigma_j_t_inv, dtype=np.float32, order="C")

    dmu = mu_i - mu_j_t

    # ∂_{μ_j'} KL = - S'^-1 dμ  ;  map back with Ωᵀ
    gmu_jp    = -np.einsum("...ij,...j->...i", sigma_jinv, dmu, optimize=True)
    grad_mu_j = np.einsum("...ji,...j->...i", Omega_ij, gmu_jp, optimize=True)

    # Σ_i only appears (not inverted); assume sanitized upstream
    Si = np.asarray(sigma_i, dtype=np.float32, order="C")
    if not assume_sanitized:
        Si = sanitize_sigma(Si)

    # v = S'^-1 dμ  ->  v vᵀ
    v   = np.einsum("...ij,...j->...i", sigma_jinv, dmu, optimize=True)
    vvT = np.einsum("...i,...j->...ij", v, v, optimize=True)

    # gΣ' = 1/2( -S'^-1 Σ_i S'^-1 - vvᵀ + S'^-1 )
    t0 = -np.einsum("...ij,...jk,...kl->...il", sigma_jinv, Si, sigma_jinv, optimize=True)
    gSp = 0.5 * (t0 - vvT + sigma_jinv)

    # map back: Ωᵀ gΣ' Ω, then symmetrize
    grad_sigma_j = np.einsum("...ji,...jk,...kl->...il",
                             Omega_ij, gSp, np.swapaxes(Omega_ij, -1, -2), optimize=True)
    grad_sigma_j = 0.5 * (grad_sigma_j + np.swapaxes(grad_sigma_j, -1, -2))

    return grad_mu_j.astype(np.float32, copy=False), grad_sigma_j.astype(np.float32, copy=False)



def grad_feedback_energy_belief(
    mu_q, sigma_q, mu_p, mu_q_push,
    sigma_q_push, sigma_q_push_inv, sigma_p, Phi, eps=1e-8, *,
    assume_sanitized=True,
):
    """
    ∂ wrt (μ_q, Σ_q) of KL(p || Φ·q), evaluated in q-fiber.
    Uses v = S'^-1 Δ and v v^T instead of S'^-1 ΔΔ^T S'^-1 to cut temps.
    """
    # Δ = μ_p - μ_q'
    delta = (mu_p - mu_q_push).astype(np.float32, copy=False)

    # v = S'^-1 Δ  (matvec)
    v = np.matmul(sigma_q_push_inv, delta[..., None])[..., 0]  # (...,K)

    # grad_μ = - Φ^T v
    Phi_T = np.swapaxes(Phi, -1, -2)
    grad_mu = -np.matmul(Phi_T, v[..., None])[..., 0]

    # M = S'^-1  - v v^T  - S'^-1 Σ_p S'^-1
    term1 = sigma_q_push_inv
    term2 = np.matmul(v[..., :, None], v[..., None, :])        # v v^T
    term3 = np.matmul(np.matmul(sigma_q_push_inv, sigma_p), sigma_q_push_inv)

    M = term1 - term2 - term3

    # grad_Σ = 1/2 Φ^T M Φ (symmetrized)
    grad_sigma = 0.5 * np.matmul(np.matmul(Phi_T, M), Phi)
    grad_sigma = 0.5 * (grad_sigma + np.swapaxes(grad_sigma, -1, -2))

    return grad_mu.astype(np.float32, copy=False), grad_sigma.astype(np.float32, copy=False)


def grad_feedback_energy_model(
    mu_p, sigma_p, mu_q_push,
    sigma_q_push, sigma_q_push_inv, Phi=None, eps=1e-8, *,
    sigma_p_inv=None, assume_sanitized=True,
):
    """
    ∂ wrt (μ_p, Σ_p) of KL(p || q'), evaluated in p-fiber.
    Avoids inverting Σ_p if sigma_p_inv is provided.
    """
    delta = (mu_p - mu_q_push).astype(np.float32, copy=False)

    # grad_μ = S'^-1 Δ
    grad_mu = np.matmul(sigma_q_push_inv, delta[..., None])[..., 0]

    # grad_Σ = 1/2 (S'^-1 - Σ_p^{-1})
    if sigma_p_inv is None:
        # assume Σ_p already sanitized upstream; we only invert if caller didn’t pass inv
        sigma_p_inv = safe_inv(sigma_p.astype(np.float32, copy=False))
    grad_sigma = 0.5 * (sigma_q_push_inv - sigma_p_inv)
    grad_sigma = 0.5 * (grad_sigma + np.swapaxes(grad_sigma, -1, -2))

    return grad_mu.astype(np.float32, copy=False), grad_sigma.astype(np.float32, copy=False)


def grad_self_energy_belief(
    mu_q, sigma_q, mu_p_push, sigma_p_push_inv, eps=1e-8, *,
    sigma_q_inv=None, mask=None, assume_sanitized=True,
):
    """
    ∂ wrt (μ_q, Σ_q) of KL(q || p'), evaluated in q-fiber.
    Reuses sigma_q_inv if provided.
    """
    delta = (mu_q - mu_p_push).astype(np.float32, copy=False)

    # grad_μ = S_p'^-1 Δ
    grad_mu = np.matmul(sigma_p_push_inv, delta[..., None])[..., 0]

    # grad_Σ = 1/2 (S_p'^-1 - Σ_q^{-1})
    if sigma_q_inv is None:
        sigma_q_inv = safe_inv(sigma_q.astype(np.float32, copy=False))
    
    grad_sigma = 0.5 * (sigma_p_push_inv - sigma_q_inv)
    grad_sigma = 0.5 * (grad_sigma + np.swapaxes(grad_sigma, -1, -2))

    if mask is not None:
        m = (np.asarray(mask) > float(getattr(config, "support_tau", 0.0)))
        grad_mu    = grad_mu * m[..., None]
        grad_sigma = grad_sigma * m[..., None, None]

    return grad_mu.astype(np.float32, copy=False), grad_sigma.astype(np.float32, copy=False)


def grad_self_energy_model(
    mu_q, sigma_q, mu_p_push, sigma_p_push_inv, Phi_tilde, eps=1e-8, *,
    assume_sanitized=True, mask=None,
):
    """
    ∂ wrt (μ_p, Σ_p) of KL(q || p'), evaluated in p-fiber.
    Uses v = M Δ and v v^T to avoid an extra large einsum.
    """
    delta = (mu_q - mu_p_push).astype(np.float32, copy=False)

    # tmp = M Δ
    v = np.matmul(sigma_p_push_inv, delta[..., None])[..., 0]

    # grad_μ = - Φ̃^T v
    Phi_tilde_T = np.swapaxes(Phi_tilde, -1, -2)
    grad_mu = -np.matmul(Phi_tilde_T, v[..., None])[..., 0]

    # G = M - v v^T - M Σ_q M
    vvT = np.matmul(v[..., :, None], v[..., None, :])
    M_Sq = np.matmul(sigma_p_push_inv, sigma_q.astype(np.float32, copy=False))
    G = sigma_p_push_inv - vvT - np.matmul(M_Sq, sigma_p_push_inv)

    # grad_Σ = 1/2 Φ̃^T G Φ̃  (symmetrized)
    grad_sigma = 0.5 * np.matmul(np.matmul(Phi_tilde_T, G), Phi_tilde)
    grad_sigma = 0.5 * (grad_sigma + np.swapaxes(grad_sigma, -1, -2))

    if mask is not None:
        m = (np.asarray(mask) > float(getattr(config, "support_tau", 0.0)))
        grad_mu    = grad_mu * m[..., None]
        grad_sigma = grad_sigma * m[..., None, None]

    return grad_mu.astype(np.float32, copy=False), grad_sigma.astype(np.float32, copy=False)




def apply_natural_gradient_batch(
    ctx,
    mu_field,
    sigma_field,
    grad_mu_field,
    grad_sigma_field,
    mask=None,
    *,
    use_float64: bool = True,
    assume_sanitized: bool = True,
    grad_sigma_is_symmetric: bool = False,
    assert_finite: bool = False,
):
    """
    Vectorized natural gradient for Gaussian fields on an N-D periodic grid:
        δμ = -Σ ∇_μ L
        δΣ = -2 Σ sym(∇_Σ L) Σ

    Inputs:
      mu_field          : (*S, K)
      sigma_field       : (*S, K, K)   [SPD]
      grad_mu_field     : (*S, K)
      grad_sigma_field  : (*S, K, K)
      mask (optional)   : (*S,) bool or float weights

    Returns:
      delta_mu          : (*S, K)
      delta_sigma       : (*S, K, K)
    """
    import numpy as np
    from runtime_context import cfg_get

    # ---- config ----
    eps         = float(cfg_get(ctx, "eps", 1e-10))
    support_tau = float(cfg_get(ctx, "support_tau", 1e-6))
    dtype_work  = np.float64 if use_float64 else np.float32
    dtype_out   = np.float32 if not use_float64 else dtype_work

    # ---- infer spatial shape S, fiber dim K ----
    mu = np.asarray(mu_field)
    Sig = np.asarray(sigma_field)
    gmu = np.asarray(grad_mu_field)
    gSig = np.asarray(grad_sigma_field)

    if mu.ndim < 2 or Sig.ndim < 3:
        raise ValueError(f"Bad shapes: mu {mu.shape}, Sigma {Sig.shape}")

    S = mu.shape[:-1]               # *S
    K = mu.shape[-1]
    if Sig.shape[:-2] != S or Sig.shape[-2:] != (K, K):
        raise ValueError(f"sigma_field shape {Sig.shape} incompatible with mu_field {mu.shape}")

    # ---- flatten spatial for batched einsum ----
    N = int(np.prod(S, dtype=int))
    mu  = mu.astype(dtype_work, copy=False).reshape(N, K)
    Sig = Sig.astype(dtype_work, copy=False).reshape(N, K, K)
    gmu  = gmu.astype(dtype_work, copy=False).reshape(N, K)
    gSig = gSig.astype(dtype_work, copy=False).reshape(N, K, K)

    # ---- SPD sanitize Σ and symmetrize ∇Σ ----
    if not assume_sanitized:
        Sig = sanitize_sigma(Sig, eps=eps)  # must return symmetric SPD in dtype_work
    if not grad_sigma_is_symmetric:
        gSig = 0.5 * (gSig + np.swapaxes(gSig, -1, -2))

    # ---- natural steps ----
    # δμ = -Σ ∇_μ
    dmu = -np.einsum("nik,nk->ni", Sig, gmu, optimize=True)
    # δΣ = -2 Σ sym(∇_Σ) Σ
    tmp =  np.einsum("nij,njk->nik", Sig, gSig, optimize=True)
    dS  = -2.0 * np.einsum("nij,njk->nik", tmp, Sig, optimize=True)
    dS  = 0.5 * (dS + np.swapaxes(dS, -1, -2))  # symmetry guard

    # ---- mask / weights ----
    if mask is not None:
        m = np.asarray(mask)

        m_flat = m.reshape(N)
        if m.dtype == bool:
            active = m_flat
            wts = None
        else:
            wts = m_flat.astype(dtype_work, copy=False)
            active = wts > support_tau
            # soft weights
            dmu *= wts[:, None]
            dS  *= wts[:, None, None]

        # zero outside support
        if not np.all(active):
            ia = ~active
            dmu[ia] = 0.0
            dS[ia]  = 0.0


    if assert_finite:
        if not (np.isfinite(dmu).all() and np.isfinite(dS).all()):
            raise FloatingPointError("Nonfinite natural gradient (μ or Σ).")

    # ---- restore shapes / cast ----
    return (
        dmu.reshape(S + (K,)).astype(dtype_out, copy=False),
        dS.reshape(S + (K, K)).astype(dtype_out, copy=False),
    )







