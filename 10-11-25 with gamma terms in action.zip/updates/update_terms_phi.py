
import numpy as np
from core.numerical_utils import safe_inv, sanitize_sigma, safe_omega_inv
from core.transport_cache import (build_dexpinv_matrix , Jinv_grid, E_grid, Omega, 
                                  exp_and_jinv_single, Phi_cached )
from core.omega import d_exp_exact
from runtime_context import cfg_get
from utils import log_phi_grad_like, _aid, push_neighbor_stats, mask_hw
from core.numerical_utils import push_gaussian
from updates.update_helpers import _ensure_fisher
from beta import get_edge_fields

from beta_grads import grad_beta_phi_covectors
#==============================================================================
#
#                    GATHER PHI GAUGE FIELD GRADIENT TERMS
#                          Beliefs and Models
#==============================================================================
def compute_gbar_align_cov_recv(
    ctx, agent_i, neighbors, generators, *,
    field: str = "phi",
    fisher_inv_key: str,     # <-- pass meta["fisher_inv_key"]
):
    which = "q" if field == "phi" else "p"
    eps   = float(cfg_get(ctx, "eps", 1e-8))
    tau   = float(cfg_get(ctx, "support_tau", 1e-6))

    mu_key  = "mu_q_field"    if which == "q" else "mu_p_field"
    sg_key  = "sigma_q_field" if which == "q" else "sigma_p_field"

    mu_i = np.asarray(getattr(agent_i, mu_key), np.float32)
    Sshape = mu_i.shape[:-1]
    Dphi   = int(np.asarray(getattr(agent_i, field)).shape[-1])

    mi = np.asarray(getattr(agent_i, "mask"), np.float32)
    if mi.shape != Sshape: mi = np.broadcast_to(mi, Sshape)

    i_id = int(getattr(agent_i, "id", -1))

    # ---- require preconds for receiver; compute if missing ----
    try:
        E_i, _, _ = get_preconds(ctx, agent_i, which, fisher_inv_key=fisher_inv_key)
    except AttributeError:
        _ensure_fisher(agent_i, which=which, generators=generators, ctx=ctx, eps=eps)
        E_i, _, _ = get_preconds(ctx, agent_i, which, fisher_inv_key=fisher_inv_key)

    phi_i   = np.asarray(getattr(agent_i, field), np.float32)
    Q_all_i = d_exp_exact(phi_i, generators)

    gbar = np.zeros(Sshape + (Dphi,), dtype=np.float32)
    any_contrib = False

    for agent_j in neighbors:
        mj = np.asarray(getattr(agent_j, "mask"), np.float32)
        if mj.shape != Sshape: mj = np.broadcast_to(mj, Sshape)
        joint = (mi > tau) & (mj > tau)
        if not np.any(joint):
            continue

        j_id = int(getattr(agent_j, "id", -1))
        beta_map = np.asarray(ctx._edge_beta[(which, i_id, j_id)], np.float32)
        beta_eff = beta_map * joint.astype(np.float32)
        if not np.any(beta_eff > 0):
            continue

        Om = np.asarray(Omega(ctx, agent_i, agent_j, which=which), np.float32)
        E_j = np.asarray(E_grid(ctx, agent_j, which=which), np.float32)
        exp_neg_phi_j = safe_omega_inv(E_j)

        # neighbor stats in i-frame
        mu_j_t, S_j_t, S_j_t_inv = push_neighbor_stats(agent_j, sg_key, Om, eps)

        # ALIGN φ covector (UNPROJECTED)
        g_align_cov_recv = grad_kl_wrt_phi_i(
            getattr(agent_i, mu_key), getattr(agent_i, sg_key),
            None, None,
            phi_i, None,
            Om, generators, E_i, E_j,
            mu_j_t, S_j_t_inv, eps,
            exp_neg_phi_j=exp_neg_phi_j, Q_all=Q_all_i,
        ).astype(np.float32, copy=False)

        gbar += beta_eff[..., None] * g_align_cov_recv
        any_contrib = True

    if not any_contrib:
        return np.zeros_like(gbar, dtype=np.float32)

    return gbar



def accumulate_phi_alignment_gradient(
    ctx, agent_i, agent_j, generators,
    *,
    field: str = "phi",                 # "phi" (q) or "phi_tilde" (p)
    fisher_inv_key: str,                # "fisher_inv_q" or "fisher_inv_p"
    grad_key: str,                      # "grad_phi" or "grad_phi_tilde"
    accumulate_sender_grads: bool = False,
    gbar_align_cov_recv: np.ndarray = None,  # << REQUIRED for softmax β (precomputed receiver average)
):
    # ---- setup & masks ----
    which = "q" if field == "phi" else "p"
    eps   = float(cfg_get(ctx, "eps", 1e-8))
    tau   = float(cfg_get(ctx, "support_tau", 1e-6))

    mu_key  = "mu_q_field"    if which == "q" else "mu_p_field"
    sg_key  = "sigma_q_field" if which == "q" else "sigma_p_field"

    mu_i = np.asarray(getattr(agent_i, mu_key), np.float32)
    Sshape = mu_i.shape[:-1]

    mi = np.asarray(getattr(agent_i, "mask"), np.float32)
    mj = np.asarray(getattr(agent_j, "mask"), np.float32)
    if mi.shape != Sshape: mi = np.broadcast_to(mi, Sshape)
    if mj.shape != Sshape: mj = np.broadcast_to(mj, Sshape)
    joint_mask = (mi > tau) & (mj > tau)
    if not np.any(joint_mask):
        return

    # ---- edge β, KL, κ (use masked versions) ----
    i_id = int(getattr(agent_i, "id", -1))
    j_id = int(getattr(agent_j, "id", -1))
    beta_map = np.asarray(ctx._edge_beta[(which, i_id, j_id)], np.float32)
    KL1_map  = np.asarray(ctx._edge_kl1 [(which, i_id, j_id)], np.float32)
    m32 = joint_mask.astype(np.float32)
    beta_eff = beta_map * m32
    KL1_eff  = KL1_map  * m32
    kappa    = max(float(cfg_get(ctx, f"beta_kappa_{which}", 1.0)), eps)

    # Require the β-weighted receiver average of ALIGN φ-covectors
    if gbar_align_cov_recv is None:
        raise ValueError("accumulate_phi_alignment_gradient: gbar_align_cov_recv is required for softmax β.")

    # ---- transports / preconds ----
    Om   = np.asarray(Omega(ctx, agent_i, agent_j, which=which), np.float32)
    E_i, Jinv_i, Finv_i = get_preconds(ctx, agent_i, which, fisher_inv_key=fisher_inv_key)
    E_j = np.asarray(E_grid(ctx, agent_j, which=which), np.float32)
    exp_neg_phi_j = safe_omega_inv(E_j)

    # neighbor stats in i-frame (ALIGN φ grads)
    mu_j_t, S_j_t, S_j_t_inv = push_neighbor_stats(agent_j, sg_key, Om, eps)

    # ---- ALIGN covectors (receiver & sender) ----
    phi_i = np.asarray(getattr(agent_i, field), np.float32)      # (*S,3)
    Q_all_i = d_exp_exact(phi_i, generators)

    g_align_cov_recv = grad_kl_wrt_phi_i(
        getattr(agent_i, mu_key), getattr(agent_i, sg_key),
        None, None,
        phi_i, None,
        Om, generators, E_i, E_j,
        mu_j_t, S_j_t_inv, eps,
        exp_neg_phi_j=exp_neg_phi_j, Q_all=Q_all_i,
    ).astype(np.float32, copy=False)

    step_align_recv = project_phi_covector_to_step(g_align_cov_recv, Jinv_i, Finv_i)

    # Softmax correction factor (masked)
    factor = (beta_eff * (KL1_eff / kappa)).astype(np.float32)

    # Project once for the correction (ḡ_i − g_ij)
    corr_cov = (gbar_align_cov_recv - g_align_cov_recv).astype(np.float32, copy=False)
    step_corr = project_phi_covector_to_step(corr_cov, Jinv_i, Finv_i)

    # ---- Receiver step: β * Proj(g_ij) + (β*KL/κ) * Proj(ḡ_i − g_ij) ----
    step_recv = beta_eff[..., None] * step_align_recv + factor[..., None] * step_corr

    # ======================= γ (Case A/B) with product rule (not softmax) =======================
    # γ_A: KL(q_j || Ω^q_ji[Φ̃_i p_i])  → basis "a"
    # γ_B: KL(p_i || Φ_i[Ω^q_ij q_j])   → basis "b"
    use_prod = bool(cfg_get(ctx, "gamma_use_product_rule", True))
    kq = float(cfg_get(ctx, "kappa_gamma_q", 1.0))
    kp = float(cfg_get(ctx, "kappa_gamma_p", 1.0))
    Om_q_ij = np.asarray(Omega(ctx, agent_i, agent_j, which="q"), np.float32)

    gamma_A = ctx._edge_gamma.get(("A", j_id, i_id), None)  # j→i
    KL_A    = ctx._edge_klX  .get(("A", j_id, i_id), None)
    if gamma_A is not None:
        scale_A = np.asarray(gamma_A, np.float32) * m32
        if use_prod and KL_A is not None:
            scale_A = scale_A * (1.0 - np.asarray(KL_A, np.float32) / max(kq, eps))
        if np.any(scale_A):
            cov_iq_A, cov_jq_A, cov_ip_A = grad_beta_phi_covectors(
                ctx, agent_i, agent_j, basis="a", Omega_ij=Om_q_ij,
                generators_irrep=generators, eps=eps
            )
            cov_i_A = cov_iq_A if which == "q" else cov_ip_A
            step_recv += scale_A[..., None] * project_phi_covector_to_step(cov_i_A, Jinv_i, Finv_i)

    gamma_B = ctx._edge_gamma.get(("B", i_id, j_id), None)  # i→j
    KL_B    = ctx._edge_klX  .get(("B", i_id, j_id), None)
    if gamma_B is not None:
        scale_B = np.asarray(gamma_B, np.float32) * m32
        if use_prod and KL_B is not None:
            scale_B = scale_B * (1.0 - np.asarray(KL_B, np.float32) / max(kp, eps))
        if np.any(scale_B):
            cov_iq_B, cov_jq_B, cov_ip_B = grad_beta_phi_covectors(
                ctx, agent_i, agent_j, basis="b", Omega_ij=Om_q_ij,
                generators_irrep=generators, eps=eps
            )
            cov_i_B = cov_iq_B if which == "q" else cov_ip_B
            step_recv += scale_B[..., None] * project_phi_covector_to_step(cov_i_B, Jinv_i, Finv_i)
    # ============================================================================================

    # ---- accumulate receiver ----
    prev = getattr(agent_i, grad_key, None)
    setattr(agent_i, grad_key, (np.zeros_like(step_recv) if prev is None else prev) + step_recv)

    # ---- optional sender φ_j ----
    if accumulate_sender_grads:
        phi_j = np.asarray(getattr(agent_j, field), np.float32)
        R_all_j = d_exp_exact(phi_j, generators)
        g_align_cov_send = grad_kl_wrt_phi_j(
            getattr(agent_i, mu_key), getattr(agent_i, sg_key),
            getattr(agent_j, mu_key), getattr(agent_j, sg_key),
            None, phi_j,
            Om, generators, E_i, E_j,
            mu_j_t, S_j_t_inv, eps,
            exp_neg_phi_j=exp_neg_phi_j, R_all=R_all_j,
        ).astype(np.float32, copy=False)
        _, Jinv_j, Finv_j = get_preconds(ctx, agent_j, which, fisher_inv_key=fisher_inv_key)
        step_align_send = project_phi_covector_to_step(g_align_cov_send, Jinv_j, Finv_j)

        # Sender softmax form: β * Proj(g_s,ij) + (β*KL/κ)*(β−1)*Proj(g_s,ij)
        step_send = beta_eff[..., None] * step_align_send \
                  + (factor * (beta_eff - 1.0))[..., None] * step_align_send

        # Sender γ (A/B) terms
        if gamma_A is not None and np.any(scale_A):
            _, cov_jq_A, _ = grad_beta_phi_covectors(
                ctx, agent_i, agent_j, basis="a", Omega_ij=Om_q_ij,
                generators_irrep=generators, eps=eps
            )
            step_send += scale_A[..., None] * project_phi_covector_to_step(cov_jq_A, Jinv_j, Finv_j)
        if gamma_B is not None and np.any(scale_B):
            _, cov_jq_B, _ = grad_beta_phi_covectors(
                ctx, agent_i, agent_j, basis="b", Omega_ij=Om_q_ij,
                generators_irrep=generators, eps=eps
            )
            step_send += scale_B[..., None] * project_phi_covector_to_step(cov_jq_B, Jinv_j, Finv_j)

        prev_j = getattr(agent_j, grad_key, None)
        setattr(agent_j, grad_key, (np.zeros_like(step_send) if prev_j is None else prev_j) + step_send)


def _accum_gamma_phi_for_pair(
    ctx,
    *,
    which: str,                # "q" or "p" — which φ field you’re updating
    agent_i, agent_j,
    overlap_mask: np.ndarray,
    Om_q_ij,                   # Ω^q_ij (reuse)
    Jinv_i, Finv_i,            # receiver i preconds
    Jinv_j=None, Finv_j=None,  # optional sender j preconds if accumulating sender φ
    generators=None,
):
    import numpy as np
    from runtime_context import cfg_get
    from beta_grads import grad_beta_phi_covectors
    

    i_id = int(getattr(agent_i, "id", -1))
    j_id = int(getattr(agent_j, "id", -1))

    m = overlap_mask.astype(np.float32, copy=False)
    if not np.any(m):
        Ki = getattr(agent_i, "phi").shape[-1] if which == "p" else getattr(agent_i, "phi").shape[-1]
        zero = np.zeros(m.shape + (Ki,), np.float32)
        return zero, (None if Jinv_j is None else zero)

    # directed gammas and KLs
    gA = ctx._edge_gamma.get(("A", j_id, i_id), None)  # j→i
    gB = ctx._edge_gamma.get(("B", i_id, j_id), None)  # i→j
    KA = ctx._edge_klX.get(("A", j_id, i_id), None)
    KB = ctx._edge_klX.get(("B", i_id, j_id), None)

    if gA is None and gB is None:
        Ki = getattr(agent_i, "phi").shape[-1]
        zero = np.zeros(m.shape + (Ki,), np.float32)
        return zero, (None if Jinv_j is None else zero)

    use_prod = bool(cfg_get(ctx, "gamma_use_product_rule", True))
    kq = float(cfg_get(ctx, "kappa_gamma_q", 1.0))
    kp = float(cfg_get(ctx, "kappa_gamma_p", 1.0))

    step_recv = 0.0
    step_send = 0.0 if (Jinv_j is not None and Finv_j is not None) else None

    # ---- Case A → basis="a" covectors ----
    if gA is not None:
        wA = np.asarray(gA, np.float32) * m
        if np.any(wA):
            if use_prod and KA is not None:
                wA = wA * (1.0 - np.asarray(KA, np.float32) / max(kq, 1e-12))
            cov_iq_A, cov_jq_A, cov_ip_A = grad_beta_phi_covectors(
                ctx, agent_i, agent_j, basis="a", Omega_ij=Om_q_ij, generators_irrep=generators
            )
            # pick covector matching 'which'
            cov_i = cov_iq_A if which == "q" else cov_ip_A
            step_recv = step_recv + (wA[..., None] * project_phi_covector_to_step(cov_i, Jinv_i, Finv_i))
            if step_send is not None:
                step_send = step_send + (wA[..., None] * project_phi_covector_to_step(cov_jq_A, Jinv_j, Finv_j))

    # ---- Case B → basis="b" covectors ----
    if gB is not None:
        wB = np.asarray(gB, np.float32) * m
        if np.any(wB):
            if use_prod and KB is not None:
                wB = wB * (1.0 - np.asarray(KB, np.float32) / max(kp, 1e-12))
            cov_iq_B, cov_jq_B, cov_ip_B = grad_beta_phi_covectors(
                ctx, agent_i, agent_j, basis="b", Omega_ij=Om_q_ij, generators_irrep=generators
            )
            cov_i = cov_iq_B if which == "q" else cov_ip_B
            step_recv = step_recv + (wB[..., None] * project_phi_covector_to_step(cov_i, Jinv_i, Finv_i))
            if step_send is not None:
                step_send = step_send + (wB[..., None] * project_phi_covector_to_step(cov_jq_B, Jinv_j, Finv_j))

    return np.asarray(step_recv, np.float32), (None if step_send is None else np.asarray(step_send, np.float32))



def accumulate_alignment_energy(
    ctx,
    agent_i, agent_j,
    *,
    field: str,                  # "phi" or "phi_model"
    joint_mask,                  # boolean/broadcastable vector for active pixels
    mu_i, sigma_i,               # Ai's μ/Σ (already sliced/broadcasted as in grad path)
    mu_j_t,
    sigma_j_t: np.ndarray | None = None,        # NEW: covariance in i-frame
    sigma_j_t_inv: np.ndarray | None = None,    # kept for back-compat
    eps: float = 1e-8,
    per_agent: bool | None = None,
):
    import numpy as np
    from runtime_context import energy_acc_add
    from core.numerical_utils import kl_gaussian, safe_inv, sanitize_sigma

    mu_i = np.asarray(mu_i, np.float64, order="C")
    Si   = sanitize_sigma(np.asarray(sigma_i, np.float64, order="C"), eps=max(eps, 1e-10))

    if sigma_j_t is not None:
        Sj_t = sanitize_sigma(np.asarray(sigma_j_t, np.float64, order="C"), eps=max(eps, 1e-10))
    else:
        
        A = np.asarray(sigma_j_t_inv, np.float64, order="C")
        A = 0.5 * (A + np.swapaxes(A, -1, -2))
        # simple SPD projection via covariance sanitizer (works for precision too)
        A = sanitize_sigma(A, eps=max(eps, 1e-10))
        Sj_t = safe_inv(A, eps=max(eps, 1e-10))

    kl_px = kl_gaussian(mu_i, Si, mu_j_t, Sj_t, eps=max(eps, 1e-10))  # (...,)

    # ref has shape (*S,)
    S = kl_px.shape
    if joint_mask is None:
        m = np.ones(S, dtype=np.float64)
    else:
        m = np.asarray(joint_mask, dtype=np.float64)
        if m.shape != S:
            raise ValueError(f"joint_mask shape {m.shape} != {S}")

    align_sum = float(np.sum(kl_px * m))

    bucket = "align_q_sum" if field == "phi" else "align_p_sum"
    energy_acc_add(ctx, bucket, align_sum)

    if per_agent is None:
        per_agent = bool(getattr(getattr(ctx, "step_cfg", None), "align_track_per_agent", False))
    if per_agent:
        aid = getattr(agent_i, "id", None)
        if aid is not None:
            energy_acc_add(ctx, f"{bucket}[{aid}]", align_sum)

    return align_sum




def grad_kl_wrt_phi_i(
    mu_i, sigma_i,
    mu_j, sigma_j,                 
    phi_i, phi_j,                  
    Omega_ij,
    generators,
    exp_phi_i,
    exp_phi_j,
    mu_j_t,                        
    sigma_j_t_inv,                 
    eps=1e-8,
    exp_neg_phi_j=None,
    Q_all=None,
):
        
    # ---- cast to f64 for internal math ----
    mu_i   = np.asarray(mu_i,   np.float64)
    mu_j_t = np.asarray(mu_j_t, np.float64)

    Sigma_i = sanitize_sigma(np.asarray(sigma_i, np.float64), eps=eps)
   
    # Q_all → (..., a, K, K)
    if Q_all is None:
        Q_all = d_exp_exact(np.asarray(phi_i, np.float64), generators)
    
    Q = np.stack([np.asarray(x, np.float64) for x in Q_all], axis=-3)

    # exp(-phi_j) broadcast to Q lead dims
    if exp_neg_phi_j is None:
        exp_neg_phi_j = safe_omega_inv(np.asarray(exp_phi_j, np.float64))
   
    # Ω and Ω^{-1}
    Om   = np.asarray(Omega_ij, np.float64)
    Oinv = safe_omega_inv(Om).astype(np.float64, copy=False)

    # Sanity on provided precision
    Sj_inv = np.asarray(sigma_j_t_inv, np.float64)
    
    Sj_inv = 0.5 * (Sj_inv + np.swapaxes(Sj_inv, -1, -2))
    
    # Core pieces
    delta_mu = (mu_i - mu_j_t)                     # (..., K)
    mu_j_src = np.einsum("...ij,...j->...i", Oinv, mu_j_t, optimize=True)  # (..., K)

    # dΩ/dφ_i^a = Q[a] @ e^{-φ_j}
    Q = np.einsum("...aik,...kj->...aij", Q, exp_neg_phi_j, optimize=True)
    Q_T = np.swapaxes(Q, -1, -2)
   
    # dΩ Ω^{-1}
    Q_tilde   = np.einsum("...aik,...kj->...aij", Q, Oinv, optimize=True)  
    Qtilde_T  = np.swapaxes(Q_tilde, -1, -2)
    
    # ---- precision (trace) term:  -1/2 * ⟨ A, Q̃ Σ_i + Σ_i Q̃^T ⟩
    t1 = np.einsum("...ij,...ajk,...ki->...a", Sj_inv, Q_tilde,  Sigma_i, optimize=True)
    t2 = np.einsum("...aij,...jk, ...ki->...a", Qtilde_T, Sj_inv, Sigma_i, optimize=True)
    trace_term = -0.5 * (t1 + t2)
    
    # mean term
    tmp1 = np.einsum("...aij,...j->...ai", Q_T,    delta_mu, optimize=True)
    tmp2 = np.einsum("...ij,...aj->...ai", Sj_inv, tmp1,     optimize=True)
    mean_term = -np.einsum("...i,...ai->...a", mu_j_src, tmp2, optimize=True)
    
    # ---- Mahalanobis (through ∂A) term: +1/2 * Δμ^T ( A Q̃ + Q̃^T A ) Δμ
    v1 = np.einsum("...ij,...j->...i", Sj_inv, delta_mu, optimize=True)          # A Δμ
    part1 = np.einsum("...aij,...j->...ai", Qtilde_T, v1, optimize=True)         # Q̃^T A Δμ
    v2    = np.einsum("...aij,...j->...ai", Q_tilde,  delta_mu, optimize=True)   # Q̃ Δμ
    part2 = np.einsum("...ij,...aj->...ai", Sj_inv,   v2, optimize=True)         # A Q̃ Δμ
    mahal_term = 0.5 * np.einsum("...i,...ai->...a", delta_mu, part1 + part2, optimize=True)


    # ---- previous gradients -possibly incorrect? ----
    # trace term
   # t1 = np.einsum("...ij,...ajk,...ki->...a", Sj_inv, Q,   Sigma_i, optimize=True)
   # t2 = np.einsum("...aij,...jk,...ki->...a", Q_T,   Sj_inv, Sigma_i, optimize=True)
   # trace_term = -0.5 * (t1 + t2)

    # Mahalanobis term
   # v1 = np.einsum("...ij,...j->...i", Sj_inv, delta_mu, optimize=True)
   # part1 = np.einsum("...aij,...j->...ai", Q_T, v1,           optimize=True)
   # v2    = np.einsum("...aij,...j->...ai", Q,   delta_mu,     optimize=True)
   # part2 = np.einsum("...ij,...aj->...ai", Sj_inv, v2,        optimize=True)
   # mahal_term = 0.5 * np.einsum("...i,...ai->...a", delta_mu, part1 + part2, optimize=True)

    grad = (trace_term + mean_term + mahal_term)
    #print(f"grad = {grad}")
    return grad


def grad_kl_wrt_phi_j(
    mu_i, sigma_i,
    mu_j, sigma_j,                  # not used directly; kept for parity
    phi_i, phi_j,                   # not used directly here; we use exp(phi_*)
    Omega_ij,
    generators,
    exp_phi_i,
    exp_phi_j,
    mu_j_t,                         # μ_j' = Ω_ij μ_j
    sigma_j_t_inv,                  # Σ_j'^(-1) (already pushed)
    eps=1e-8,
    exp_neg_phi_j=None,
    R_all=None,                     # d exp(φ_j)/d φ_j^b (list/array of matrices); if None, we compute
):
    """
    ∂/∂φ_j KL(q_i || Ω_ij q_j). Mirrors grad_kl_wrt_phi_i but with:
      dΩ/dφ_j^b = - Ω  * ( R_j[b] @ e^{-φ_j} ).
    We work with U := dΩ and Ũ := (dΩ) Ω^{-1} = - Ω R̃ Ω^{-1}.
    """
    import numpy as np
    mu_i   = np.asarray(mu_i,   np.float64)
    mu_j_t = np.asarray(mu_j_t, np.float64)

    # sanitize Σ_i only once here
    Sigma_i = sanitize_sigma(np.asarray(sigma_i, np.float64), eps=eps)

    Om   = np.asarray(Omega_ij, np.float64)
    Oinv = safe_omega_inv(Om).astype(np.float64, copy=False)

    Sj_inv = np.asarray(sigma_j_t_inv, np.float64)
    Sj_inv = 0.5 * (Sj_inv + np.swapaxes(Sj_inv, -1, -2))

    # Δμ and μ_j in source coords
    delta_mu = (mu_i - mu_j_t)                                     # (..., K)
    mu_j_src = np.einsum("...ij,...j->...i", Oinv, mu_j_t, optimize=True)

    # exp(-φ_j)
    if exp_neg_phi_j is None:
        exp_neg_phi_j = safe_omega_inv(np.asarray(exp_phi_j, np.float64))

    # R_all: d exp(φ_j)/d φ_j^b  → stack as (..., b, K, K)
    if R_all is None:
        R_all = d_exp_exact(np.asarray(phi_j, np.float64), generators)
    R = np.stack([np.asarray(x, np.float64) for x in R_all], axis=-3)   # (..., b, K, K)

    # R̃_b = R_b @ e^{-φ_j}
    R_tilde = np.einsum("...bik,...kj->...bij", R, exp_neg_phi_j, optimize=True)  # (..., b, K, K)

    # U := dΩ = - Ω R̃ ;   U^T;  and Ũ := (dΩ) Ω^{-1} = - Ω R̃ Ω^{-1}
    U       = -np.einsum("...ik,...bkj->...bij", Om, R_tilde, optimize=True)      # (..., b, K, K)
    U_T     = np.swapaxes(U, -1, -2)
    U_tilde = -np.einsum("...ik,...bkj,...jl->...bil", Om, R_tilde, Oinv, optimize=True)
    Utilde_T= np.swapaxes(U_tilde, -1, -2)

    # -------- precision (trace) term:  -1/2 ⟨ A, Ũ Σ_i + Σ_i Ũ^T ⟩
    t1 = np.einsum("...ij,...bij,...jk->...b", Sj_inv, U_tilde, Sigma_i, optimize=True)
    t2 = np.einsum("...bij,...jk,...ki->...b", Utilde_T, Sj_inv, Sigma_i, optimize=True)
    trace_term = -0.5 * (t1 + t2)

    # -------- mean term (through dμ' = U μ_j_src)
    # tmp1_bi = U^T_bij Δμ_j'^j
    tmp1 = np.einsum("...bij,...j->...bi", U_T, delta_mu, optimize=True)
    # tmp2_bi = A_{ik} tmp1_bk
    tmp2 = np.einsum("...ij,...bj->...bi", Sj_inv, tmp1, optimize=True)
    mean_term = -np.einsum("...i,...bi->...b", mu_j_src, tmp2, optimize=True)

    # -------- Mahalanobis term: +1/2 Δμ^T ( A Ũ + Ũ^T A ) Δμ
    v1 = np.einsum("...ij,...j->...i", Sj_inv, delta_mu, optimize=True)            # A Δμ
    part1 = np.einsum("...bij,...j->...bi", Utilde_T, v1, optimize=True)           # Ũ^T A Δμ
    v2    = np.einsum("...bij,...j->...bi", U_tilde,  delta_mu, optimize=True)     # Ũ Δμ
    part2 = np.einsum("...ij,...bj->...bi", Sj_inv,   v2, optimize=True)           # A Ũ Δμ
    mahal_term = 0.5 * np.einsum("...i,...bi->...b", delta_mu, part1 + part2, optimize=True)

    grad = (trace_term + mean_term + mahal_term)    # (..., b)
    return grad




# ─────────────────────────────────────────────────────────────────────────────
#            SELF AND FEEDBACK GRADS
# ─────────────────────────────────────────────────────────────────────────────


def accumulate_phi_morphism_self_feedback(
    ctx,
    agent_i,
    generators_src, generators_tgt,
    *,
    field: str = "phi",
    fisher_inv_key: str | None = None,
    grad_key: str | None = None,
    phi_self_func=None,
    phi_feedback_func=None,
):
    """
    Accumulate SELF + FEEDBACK gradients for φ (or φ̃) into agent_i.<grad_key>.
    Pipeline: Jinv^T (param-covector) → Fisher^{-1} (body) → Jinv (param-vector).
    Uses cached Φ̃ and reuses pushed mean/precision if available.
    """
   
    assert fisher_inv_key and grad_key, "fisher_inv_key and grad_key are required"

    PRINT_SIGN = False

    eps   = float(cfg_get(ctx, "eps", 1e-8))
    tau   = float(cfg_get(ctx, "support_tau", 1e-6))
    alpha = float(cfg_get(ctx, "alpha", 0.0))
    fbw   = float(cfg_get(ctx, "feedback_weight", 0.0))

    # (H,W,1) mask for broadcasting with (...,A)
    mask = mask_hw(agent_i, tau=tau, mode="float3")
    if not np.any(mask):
        return

    # fields & base φ
    mu_q,  sigma_q  = agent_i.mu_q_field,  agent_i.sigma_q_field
    mu_p,  sigma_p  = agent_i.mu_p_field,  agent_i.sigma_p_field
    phi     = np.asarray(agent_i.phi,       np.float32)
    phi_t   = np.asarray(agent_i.phi_model, np.float32)

    base_phi = phi if field == "phi" else phi_t

    # transports & Jinv (cache-first)
    exp_this, exp_other, Jinv, which, G_q, G_p = exp_and_jinv_single(
        ctx, agent_i, field, base_phi, generators_src, generators_tgt
    )

    # Φ̃ from central cache (q <- p)
    Phi_tilde = Phi_cached(ctx, agent_i, kind="p_to_q")  # (H,W,K_q,K_p)

    # Reuse pushed mean/precision from μ/Σ pass if present, else compute once
    mu_p_push  = getattr(agent_i, "_mu_p_push",          None)  # Φ̃ μ_p
    A_inv_push = getattr(agent_i, "_Sigma_p_push_inv",    None)  # (Φ̃ Σ_p Φ̃ᵀ)^{-1}
    if (mu_p_push is None) or (A_inv_push is None):
        mu_p_push, _, A_inv_push = push_gaussian(
            mu=mu_p, Sigma=sigma_p, M=Phi_tilde,
            eps=eps, return_inv=True, assume_orthogonal=False
        )
        # keep for the rest of this step
        setattr(agent_i, "_mu_p_push",         mu_p_push.astype(np.float32, copy=False))
        setattr(agent_i, "_Sigma_p_push_inv",  A_inv_push.astype(np.float32, copy=False))

        # Fisher^{-1}: treat missing as identity (no-op, but warn once)
    F_inv = getattr(agent_i, fisher_inv_key, None)
    
    if F_inv is None:      
        print(f"[warn] Fisher metric missing for agent {getattr(agent_i,'id', '?')}, "
                  f"field={field}; using identity.\n\n\n\n")
            #setattr(agent_i, "_warned_missing_fisher", True)
        Fi = np.eye(base_phi.shape[-1], dtype=np.float32)  # identity acts as neutral metric
    else:
        Fi = np.asarray(F_inv, dtype=np.float32, order="C")

    total = np.zeros_like(base_phi, dtype=np.float32)
    self_contrib = fb_contrib = None

   # -------- SELF term --------
    if alpha > 0.0 and phi_self_func is not None:
        # unified argument set (includes cached fast-path values;
        # the target function must accept them)
        g_param = phi_self_func(
            mu_q=mu_q, sigma_q=sigma_q,
            mu_p=mu_p, sigma_p=sigma_p,
            Phi_tilde_0=getattr(agent_i, "Phi_tilde_0", None),
            phi=phi, phi_tilde=phi_t,
            generators_q=G_q, generators_p=G_p,
            exp_phi=exp_this if field == "phi" else exp_other,
            exp_phi_tilde=exp_other if field == "phi" else exp_this,
            # always provide fast-path extras
            Phi_tilde=Phi_tilde,
            A_inv_cached=A_inv_push,
            mu_t_cached=mu_p_push,
            eps=eps,
        )
        if g_param is None:
            raise RuntimeError("phi_self_func returned None; check arguments.")
    
        # param-covector → body-covector → Fisher^{-1} → param-vector
        g_body = np.einsum("...ji,...j->...i", Jinv, g_param, optimize=True)
        v_body = g_body if Fi is None else np.einsum("...ab,...b->...a", Fi, g_body, optimize=True)
        v_param = np.einsum("...ab,...b->...a", Jinv, v_body, optimize=True)
    
        self_contrib = alpha * v_param * mask
        total += self_contrib
    
    elif alpha > 0.0:
        print(f"[warn] phi_self_func is None for agent {getattr(agent_i,'id','?')} (field={field})\n\n\n\n\n\n\n")
    
    # -------- FEEDBACK term --------
    if fbw > 0.0 and phi_feedback_func is not None:
        g_param = phi_feedback_func(
            mu_p=mu_p, sigma_p=sigma_p,
            mu_q=mu_q, sigma_q=sigma_q,
            Phi_0=getattr(agent_i, "Phi_0", None),
            phi=phi, phi_tilde=phi_t,
            exp_phi=exp_this if field == "phi" else exp_other,
            exp_phi_tilde=exp_other if field == "phi" else exp_this,
            eps=eps,
            generators_q=G_q, generators_p=G_p,
        )
        if g_param is None:
            raise RuntimeError("phi_feedback_func returned None; check arguments.")
    
        g_body = np.einsum("...ji,...j->...i", Jinv, g_param, optimize=True)
        v_body = g_body if Fi is None else np.einsum("...ab,...b->...a", Fi, g_body, optimize=True)
        v_param = np.einsum("...ab,...b->...a", Jinv, v_body, optimize=True)
    
        fb_contrib = fbw * v_param * mask
        total += fb_contrib
    
    elif fbw > 0.0:
        print(f"[warn] phi_feedback_func is None for agent {getattr(agent_i,'id','?')} (field={field})\n\n\n\n\n\n")

    prev = getattr(agent_i, grad_key, None)
    
    if prev is None:
        prev = np.zeros_like(total, dtype=np.float32)
    setattr(agent_i, grad_key, prev + total)

    if PRINT_SIGN:
        aid = _aid(agent_i)
        log_phi_grad_like(aid, field, "self", self_contrib)
        log_phi_grad_like(aid, field, "feedback", fb_contrib)
        log_phi_grad_like(aid, field, "total", total)



#==============================================================================
#
#                    WITH RESPECT TO phi_i TERMS
#                       VALIDATED
#==============================================================================


def grad_self_phi_direct(
    mu_q, sigma_q, mu_p, sigma_p, Phi_tilde_0,
    phi, phi_tilde, generators_q, generators_p,
    exp_phi, exp_phi_tilde, *,
    eps=1e-8,
    
    Phi_tilde=None,          # (H,W,K_q,K_p) from cache
    A_inv_cached=None,       # (H,W,K_q,K_q)  inverse of Φ̃ Σ_p Φ̃ᵀ
    mu_t_cached=None,        # (H,W,K_q)      Φ̃ μ_p
    Q_all=None,
    exp_neg_phi_tilde=None
):
    d, K_q, _ = generators_q.shape

    # Inverse of exp_phi_tilde if needed for dΦ̃
    if exp_neg_phi_tilde is None:
        #print("exp-phi~ is none\n\n\n")
        exp_neg_phi_tilde = safe_omega_inv(exp_phi_tilde)

    # Derivative blocks (still need these)
    if Q_all is None:
        #print("q-all is none\n\n\n")
        Q_all = np.stack(d_exp_exact(phi, generators_q), axis=-3)  # (..., d, K_q, K_q)

    # Pull Φ̃ from cache (or build only if missing)
    if Phi_tilde is None:
        #print("Phi~ is none\n\n\n")
        Phi_tilde = np.einsum("...ik,...kj,...jl->...il",
                              exp_phi, Phi_tilde_0, exp_neg_phi_tilde, optimize=True)

    Phi_tilde_T = np.swapaxes(Phi_tilde, -1, -2)

    # A^{-1} and Φ̃ μ_p: reuse when provided
    if (A_inv_cached is None) or (mu_t_cached is None):
        #print("pushes are none\n\n\n")
        mu_t, _, A_inv = push_gaussian(
            mu=mu_p, Sigma=sigma_p, M=Phi_tilde,
            eps=eps, return_inv=True, assume_orthogonal=False
        )
    else:
        mu_t, A_inv = mu_t_cached, A_inv_cached

    delta_mu = mu_q - mu_t

    # ∂Φ̃_a = Q_a Φ̃₀ e^{-φ̃}
    dPhi = np.einsum("...aik,...kj,...jl->...ail", Q_all, Phi_tilde_0, exp_neg_phi_tilde, optimize=True)
    dPhi_T = np.swapaxes(dPhi, -1, -2)

    # dA = dΦ̃ Σ_p Φ̃ᵀ + Φ̃ Σ_p dΦ̃ᵀ
    dA = (
        np.einsum("...aik,...kl,...lj->...aij", dPhi,       sigma_p, Phi_tilde_T, optimize=True) +
        np.einsum("...ik, ...kl,...alj->...aij", Phi_tilde, sigma_p, dPhi_T,      optimize=True)
    )

    # term1: - (∂Φ̃ μ_p)^T A^{-1} Δμ
    dPhi_mu_p = np.einsum("...aij,...j->...ai", dPhi, mu_p, optimize=True)
    term1 = -np.einsum("...ai,...i->...a",
                       dPhi_mu_p,
                       np.einsum("...ij,...j->...i", A_inv, delta_mu, optimize=True),
                       optimize=True)

    # term2: + 1/2 tr(A^{-1} dA)
    term2 = 0.5 * np.einsum("...ij,...aij->...a", A_inv, dA, optimize=True)

    # M = A^{-1} dA A^{-1}
    M = np.einsum("...ij,...ajk,...kl->...ail", A_inv, dA, A_inv, optimize=True)

    # term3: - 1/2 Δμ^T M Δμ
    term3 = -0.5 * np.einsum("...i,...aij,...j->...a", delta_mu, M, delta_mu, optimize=True)

    # term4: - 1/2 tr(M Σ_q)
    term4 = -0.5 * np.einsum("...aij,...ji->...a", M, sigma_q, optimize=True)

    return (term1 + term2 + term3 + term4).astype(np.float32, copy=False)


def grad_self_phi_tilde_direct(
    mu_q, sigma_q, mu_p, sigma_p, Phi_tilde_0,
    phi, phi_tilde, generators_q, generators_p,
    exp_phi, exp_phi_tilde, *,
    eps=1e-8,
    Phi_tilde=None,          # cached (S*,K_q,K_p)
    A_inv_cached=None,       # cached (S*,K_q,K_q)
    mu_t_cached=None,        # cached Φ̃ μ_p
    Q_tilde_all=None,
    exp_neg_phi_tilde=None
):
    d, K_p, _ = generators_p.shape

    if exp_neg_phi_tilde is None:
        #print("e^-phi~ is none\n\n\n")
        exp_neg_phi_tilde = safe_omega_inv(exp_phi_tilde)

    if Q_tilde_all is None:
        #print("Q~-all is none\n\n\n")
        Q_tilde_all = np.stack(d_exp_exact(phi_tilde, generators_p), axis=-3)

    if Phi_tilde is None:
        #print("Phi~ is none\n\n\n")
        Phi_tilde = np.einsum("...ik,...kj,...jl->...il",
                              exp_phi, Phi_tilde_0, exp_neg_phi_tilde, optimize=True)
    Phi_tilde_T = np.swapaxes(Phi_tilde, -1, -2)

    if (A_inv_cached is None) or (mu_t_cached is None):
        mu_t, _, A_inv = push_gaussian(
            mu=mu_p, Sigma=sigma_p, M=Phi_tilde,
            eps=eps, return_inv=True, assume_orthogonal=False
        )
    else:
        mu_t, A_inv = mu_t_cached, A_inv_cached

    delta_mu = mu_q - mu_t

    # R_a = Q̃_a e^{-φ̃}, dΦ̃_a = - Φ̃ R_a
    R    = np.einsum("...aik,...kj->...aij", Q_tilde_all, exp_neg_phi_tilde, optimize=True)
    dPhi = -np.einsum("...ik,...akj->...aij", Phi_tilde, R, optimize=True)
    dPhi_T = np.swapaxes(dPhi, -1, -2)

    dA = (
        np.einsum("...aik,...kl,...lj->...aij", dPhi,       sigma_p, Phi_tilde_T, optimize=True) +
        np.einsum("...ik, ...kl,...alj->...aij", Phi_tilde, sigma_p, dPhi_T,      optimize=True)
    )

    dPhi_mu_p = np.einsum("...aij,...j->...ai", dPhi, mu_p, optimize=True)
    term1 = -np.einsum("...ai,...i->...a",
                       dPhi_mu_p,
                       np.einsum("...ij,...j->...i", A_inv, delta_mu, optimize=True),
                       optimize=True)

    term2 = 0.5 * np.einsum("...ij,...aij->...a", A_inv, dA, optimize=True)

    M = np.einsum("...ij,...ajk,...kl->...ail", A_inv, dA, A_inv, optimize=True)

    term3 = -0.5 * np.einsum("...i,...aij,...j->...a", delta_mu, M, delta_mu, optimize=True)
    term4 = -0.5 * np.einsum("...aij,...ji->...a", M, sigma_q, optimize=True)

    return (term1 + term2 + term3 + term4).astype(np.float32, copy=False)







def grad_feedback_phi_direct(
    mu_p, sigma_p,
    mu_q, sigma_q,
    Phi_0,
    phi,                # (..., d)
    phi_tilde,          # (..., d)
    generators_q,       # (d, K_q, K_q)
    generators_p,
    exp_phi,            # (..., K_q, K_q)
    exp_phi_tilde,      # (..., K_p, K_p)
    eps=1e-8,
    Q_all=None,         # (..., d, K_q, K_q) = d_exp_exact(phi, generators_q)
    exp_neg_phi=None    # (..., K_q, K_q) = e^{-φ}
):
    """
    Vectorized over 'a': returns (..., d)
    Φ = e^{φ̃} Φ₀ e^{-φ}, ∂Φ = - Φ · (e^{-φ} (∂ e^{φ}) e^{-φ})
    """
    
    d, K_q, _ = generators_q.shape

    if exp_neg_phi is None:
        exp_neg_phi = safe_omega_inv(exp_phi)
    if Q_all is None:
        # stack as (..., d, K_q, K_q)
        Q_list = d_exp_exact(phi, generators_q)
        Q_all = np.stack(Q_list, axis=-3)  # assuming list of d arrays

    # Φ and Φᵀ
    Phi = np.einsum("...ik,...kj,...jl->...il", exp_phi_tilde, Phi_0, exp_neg_phi)
    Phi_T = np.swapaxes(Phi, -1, -2)

    # A, A^{-1}
    A = np.einsum("...ik,...kl,...lj->...ij", Phi, sigma_q, Phi_T)
    A = sanitize_sigma(A, eps=eps)
    A_inv = safe_inv(A, eps=eps)

    # Δμ and v
    Phi_mu_q = np.einsum("...ij,...j->...i", Phi, mu_q)
    delta_mu = mu_p - Phi_mu_q
    v = np.einsum("...ij,...j->...i", A_inv, delta_mu)  # (..., K_p)

    # Q̄_a = e^{-φ} Q_a e^{-φ}
    Q_bar = np.einsum("...ik,...akl,...lj->...aij", exp_neg_phi, Q_all, exp_neg_phi)

    # dΦ_a = - Φ Q̄_a
    dPhi = -np.einsum("...ik,...akj->...aij", Phi, Q_bar)
    dPhi_T = np.swapaxes(dPhi, -1, -2)

    # dA_a
    dA = (
        np.einsum("...aik,...kl,...lj->...aij", dPhi, sigma_q, Phi_T) +
        np.einsum("...ik,...kl,...alj->...aij", Phi,  sigma_q, dPhi_T)
    )

    # Term 1
    dPhi_mu = np.einsum("...aij,...j->...ai", dPhi, mu_q)       # (..., a, K_p)
    term1 = -np.einsum("...ai,...i->...a", dPhi_mu, v)

    # Term 2
    term2 = 0.5 * np.einsum("...ij,...aij->...a", A_inv, dA)

    # M_a = A^{-1} dA_a A^{-1}
    M = np.einsum("...ij,...ajk,...kl->...ail", A_inv, dA, A_inv)

    # Term 3
    term3 = -0.5 * np.einsum("...i,...aij,...j->...a", delta_mu, M, delta_mu)

    # Term 4
    term4 = -0.5 * np.einsum("...aij,...ji->...a", M, sigma_p)

    grad = (term1 + term2 + term3 + term4).astype(np.float32, copy=False)
    return grad




def grad_feedback_phi_tilde_direct(
    mu_p, sigma_p,
    mu_q, sigma_q,
    Phi_0,
    phi, 
    phi_tilde,
    generators_q, 
    generators_p,
    exp_phi, 
    exp_phi_tilde,
    eps=1e-8,
    Q_tilde_all=None,       # (..., d, K_p, K_p) = d_exp_exact(phi_tilde, generators_p)
    exp_neg_phi_tilde=None  # (..., K_p, K_p) = e^{-φ̃}
):
    """
    Vectorized over 'a': returns (..., d)
    Left-trivialize: dΦ_a = L_a Φ,  L_a = (∂e^{φ̃}/∂φ̃^a) e^{-φ̃}.
    """
    
    d, K_p, _ = generators_p.shape
    
    if exp_neg_phi_tilde is None:
        exp_neg_phi_tilde = safe_omega_inv(exp_phi_tilde)
    if Q_tilde_all is None:
        Q_list = d_exp_exact(phi_tilde, generators_p)
        Q_tilde_all = np.stack(Q_list, axis=-3)

    # Φ
    exp_neg_phi = safe_omega_inv(exp_phi)
    Phi   = np.einsum("...ik,...kj,...jl->...il", exp_phi_tilde, Phi_0, exp_neg_phi)
    Phi_T = np.swapaxes(Phi, -1, -2)

    
    A = np.einsum("...ik,...kl,...lj->...ij", Phi, sigma_q, Phi_T)
    A = sanitize_sigma(A, eps=eps)
    A_inv = safe_inv(A, eps=eps)

    Phi_mu_q = np.einsum("...ij,...j->...i", Phi, mu_q)
    delta_mu = mu_p - Phi_mu_q
    v = np.einsum("...ij,...j->...i", A_inv, delta_mu)

    # L_a = Q̃_a e^{-φ̃}
    L = np.einsum("...aik,...kj->...aij", Q_tilde_all, exp_neg_phi_tilde)

    # dΦ_a = L_a Φ
    dPhi = np.einsum("...aik,...kj->...aij", L, Phi)
    dPhi_T = np.swapaxes(dPhi, -1, -2)

    dA = (
        np.einsum("...aik,...kl,...lj->...aij", dPhi, sigma_q, Phi_T) +
        np.einsum("...ik,...kl,...alj->...aij", Phi,  sigma_q, dPhi_T)
    )

    dPhi_mu = np.einsum("...aij,...j->...ai", dPhi, mu_q)
    term1 = -np.einsum("...ai,...i->...a", dPhi_mu, v)

    term2 = 0.5 * np.einsum("...ij,...aij->...a", A_inv, dA)

    M = np.einsum("...ij,...ajk,...kl->...ail", A_inv, dA, A_inv)

    term3 = -0.5 * np.einsum("...i,...aij,...j->...a", delta_mu, M, delta_mu)
    term4 = -0.5 * np.einsum("...aij,...ji->...a", M, sigma_p)

    grad = term1 + term2 + term3 + term4
    return grad




# 1) keep this utility as-is (optional: add finite checks inside)
def project_phi_covector_to_step(param_cograd, Jinv, Finv):
    """
    param-covector (∂L/∂φ)_param → param-step via:
        g_body = Jinv^T @ param_cograd
        v_body = Finv   @ g_body
        v_param= Jinv   @ v_body
    Shapes: grad: (*S,3), Jinv/Finv: (*S,3,3) → step: (*S,3)
    """
    g_body = np.einsum("...ji,...j->...i", Jinv, param_cograd, optimize=True)
    v_body = np.einsum("...ab,...b->...a", Finv, g_body,      optimize=True)
    return np.einsum("...ab,...b->...a",   Jinv, v_body,      optimize=True)


def get_preconds(ctx, agent, which, fisher_inv_key: str):
    """
    Fetch (E, Jinv, Finv) for the given fiber `which` using an explicit
    Fisher^{-1} attribute name. No identity fallback.
    """
    E    = np.asarray(E_grid(ctx, agent, which=which), np.float32)

    Jinv = Jinv_grid(ctx, agent, which=which)
    if Jinv is None:
        base_phi = np.asarray(getattr(agent, "phi" if which == "q" else "phi_model"), np.float32)
        Jinv = build_dexpinv_matrix(base_phi)

    Finv = getattr(agent, fisher_inv_key, None)
    if Finv is None:
        aid = getattr(agent, "id", "?")
        raise AttributeError(
            f"Agent(id={aid}) missing required Fisher inverse '{fisher_inv_key}' "
            f"for which='{which}'. Populate this field before calling the accumulator."
        )

    Finv = np.asarray(Finv, np.float32)
    if Finv.shape != Jinv.shape:
        raise ValueError(f"Finv shape {Finv.shape} mismatches Jinv shape {Jinv.shape}")
    if not (np.isfinite(E).all() and np.isfinite(Jinv).all() and np.isfinite(Finv).all()):
        raise FloatingPointError("non-finite values in E/Jinv/Finv")
    return E, Jinv, Finv







