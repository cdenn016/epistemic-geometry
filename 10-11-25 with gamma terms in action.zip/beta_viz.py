# -*- coding: utf-8 -*-
"""
Created on Fri Oct 10 09:48:27 2025

@author: chris and christine
"""




def _collect_beta_tensor(ctx, agents, which="q"):
    """
    Returns:
      ids: [N] agent ids
      B:   (N, N, *S) tensor where B[i,j,...] = β_{ij}(...) (0 if missing)
    Assumes ctx._edge_beta[(which, i_id, j_id)] exists for populated edges.
    """
    ids = [int(getattr(a, "id", k)) for k, a in enumerate(agents)]
    id_to_idx = {aid: k for k, aid in enumerate(ids)}
    # discover spatial shape *S from any beta map present
    sample = None
    for (w,i_id,j_id), arr in getattr(ctx, "_edge_beta", {}).items():
        if w == which:
            sample = np.asarray(arr, np.float32); break
    if sample is None:
        raise RuntimeError(f"No _edge_beta entries for which={which!r}. Did you call compute_edge_betas?")
    Sshape = sample.shape
    N = len(ids)
    B = np.zeros((N, N) + Sshape, dtype=np.float32)
    for (w, i_id, j_id), arr in ctx._edge_beta.items():
        if w != which: 
            continue
        i = id_to_idx.get(i_id, None); j = id_to_idx.get(j_id, None)
        if i is None or j is None: 
            continue
        B[i, j] = np.asarray(arr, np.float32)
    return ids, B




def _pick_beta_voxel(B, how="max", quantile=0.5):
    """
    Pick a voxel index from B (N,N,*S) by aggregating over (i,j).
      how: 'max' | 'mean' | 'median' | 'quantile'
      quantile: used when how == 'quantile' (e.g., 0.5 for median)
    Returns:
      index: tuple for *S (e.g., (y,x) or (z,y,x))
    """
    # aggregate β over edge matrix dims (i,j) -> A with shape *S
    A = B.sum(axis=(0,1)) / max(B.shape[0] * B.shape[1], 1)

    if how == "max":
        flat = np.argmax(A.ravel())
    elif how == "mean":
        # choose voxel whose value is closest to the global mean
        target = float(A.mean())
        flat = int(np.abs(A.ravel() - target).argmin())
    elif how == "median":
        # choose voxel whose value is closest to the global median
        target = float(np.median(A))
        flat = int(np.abs(A.ravel() - target).argmin())
    elif how == "quantile":
        # pick closest voxel to the chosen quantile
        target = float(np.quantile(A, quantile))
        flat = int(np.abs(A.ravel() - target).argmin())
    else:
        raise ValueError("how must be 'max','mean','median','quantile'")

    return np.unravel_index(flat, A.shape)

def show_beta_heatmap_at(ctx, agents, which="q", how="median", quantile=0.5,
                             title=None, vmax=None, annotate=False, figsize=(6,5)):
    """
    Choose voxel by aggregate over (i,j) edges, then draw heatmap at that voxel.
      how: 'max'|'mean'|'median'|'quantile'
    """
    ids, B = _collect_beta_tensor(ctx, agents, which)
    index = _pick_beta_voxel(B, how=how, quantile=quantile)
    M = B[(slice(None), slice(None)) + index]  # (N,N)

    fig, ax = plt.subplots(1,1, figsize=figsize)
    im = ax.imshow(M, vmin=0.0, vmax=(vmax or float(M.max()) or 1.0))
    ax.set_xticks(range(len(ids))); ax.set_yticks(range(len(ids)))
    ax.set_xticklabels(ids, rotation=45, ha="right"); ax.set_yticklabels(ids)
    ax.set_xlabel("sender j"); ax.set_ylabel("receiver i")
    ax.set_title(title or f"β (which={which}) at {how} voxel {index}")
    fig.colorbar(im, ax=ax, fraction=0.046, pad=0.04, label="β weight")

    if annotate and M.size <= 20_000:
        for i in range(M.shape[0]):
            for j in range(M.shape[1]):
                ax.text(j, i, f"{M[i,j]:.2f}", ha="center", va="center", fontsize=8)

    plt.tight_layout()
    return fig, ax, (ids, M, index)

def show_beta_network_at(ctx, agents, which="q", how="median", quantile=0.5,
                             threshold=1e-3, scale=6.0, layout="circular", figsize=(6,6)):
    """
    Choose voxel by aggregate over (i,j), then draw network at that voxel.
    """
    import networkx as nx

    ids, B = _collect_beta_tensor(ctx, agents, which)
    index = _pick_beta_voxel(B, how=how, quantile=quantile)
    M = B[(slice(None), slice(None)) + index]  # (N,N)

    G = nx.DiGraph()
    for aid in ids: G.add_node(aid)
    for i, ri in enumerate(ids):
        for j, sj in enumerate(ids):
            w = float(M[i,j])
            if w > threshold:
                G.add_edge(sj, ri, weight=w)

    pos = nx.spring_layout(G, seed=0) if layout == "spring" else nx.circular_layout(G)
    widths = [scale * G[u][v]["weight"] for u,v in G.edges()]

    plt.figure(figsize=figsize)
    nx.draw_networkx_nodes(G, pos, node_size=600)
    nx.draw_networkx_labels(G, pos, font_size=10)
    nx.draw_networkx_edges(G, pos, arrows=True, width=widths, arrowstyle="-|>", arrowsize=16)
    plt.title(f"β network (which={which}) at {how} voxel {index}")
    plt.axis("off"); plt.tight_layout()
    return G, pos, (ids, M, index)


def summarize_beta(ctx, agents, which="q", reduce="mean"):
    """
    Aggregates β across space → (N,N) matrix.
      reduce in {'mean','max','sum'}
    """
    ids, B = _collect_beta_tensor(ctx, agents, which)
    if reduce == "mean":
        M = B.mean(axis=tuple(range(2, B.ndim)))
    elif reduce == "max":
        M = B.max(axis=tuple(range(2, B.ndim)))
    elif reduce == "sum":
        M = B.sum(axis=tuple(range(2, B.ndim)))
    else:
        raise ValueError("reduce must be 'mean','max','sum'")
    return ids, M

