# -*- coding: utf-8 -*-
"""
Created on Wed Jul 23 06:37:51 2025

@author: chris and christine
"""


import numpy as np
import config
from numerical_utils import sanitize_sigma, safe_inv
from natural_gradient import apply_natural_gradient_batch




#==============================================================================
#
#                    APPLY NATURAL GRADIENT
#
#==============================================================================


def accumulate_mu_sigma_gradient_belief(agent_i, agents, params):
    """
    Accumulate ∇μ_q and ∇Σ_q from all belief energy terms:
      - Self:     KL(q_i || Φ̃ p_i)
      - Feedback: KL(p_i || Φ q_i)
      - Alignment: KL(q_i || Ω_ij q_j) and KL(q_k || Ω_kj q_j) for i == j

    Stores total gradient into:
        agent_i.grad_mu_q_field
        agent_i.grad_sigma_q_field
    """

    # Compute total Euclidean gradient
    dmu, dsigma = compute_mu_sigma_gradient_belief_euclidean(agent_i, agents, params)
    

    # Project into Fisher-natural gradient directions
    delta_mu, delta_sigma = apply_natural_gradient_batch(
        agent_i.mu_q_field,
        agent_i.sigma_q_field,
        dmu,
        dsigma,
        mask=agent_i.mask,
    )

   

    # Accumulate
    agent_i.grad_mu_q    += delta_mu
    agent_i.grad_sigma_q += delta_sigma






#==============================================================================
#
#                    ACCUMULATE FIELD GRADS EUCLIDEAN
#
#==============================================================================

def compute_mu_sigma_gradient_belief_euclidean(agent_i, agents, params):
    """
    Accumulate ∇_μ and ∇_Σ belief gradients for agent_i from:
    - Self-energy:     KL(q_i ‖ Φ̃ p_i)
    - Feedback:        KL(p_i ‖ Φ q_i)
    - Alignment (μ_i): KL(q_i ‖ Ω_ij q_j)
    - Alignment (μ_j): KL(q_k ‖ Ω_kj q_j) for i == j

    Returns:
        dmu_q:    (..., K_q)
        dsigma_q: (..., K_q, K_q)
    """
    eps   = config.support_cutoff_eps
    alpha = params.get("alpha", config.alpha)
    beta  = params.get("beta", config.beta)
    lambd = params.get("feedback_weight", config.feedback_weight)

    mu_q    = agent_i.mu_q_field
    sigma_q = sanitize_sigma(agent_i.sigma_q_field, eps=eps)
    mu_p    = agent_i.mu_p_field
    sigma_p = sanitize_sigma(agent_i.sigma_p_field, eps=eps)

    Phi         = agent_i.bundle_morphism_q_to_p
    Phi_tilde   = agent_i.bundle_morphism_p_to_q

    # ─── Self and Feedback terms ───
    dmu_self    = grad_self_energy_mu_q(mu_q, sigma_q, mu_p, sigma_p, Phi_tilde, eps=eps)
    dsigma_self = grad_self_energy_sigma_q(mu_q, sigma_q, mu_p, sigma_p, Phi_tilde, eps=eps)

    dmu_fb      = grad_feedback_mu_q(mu_q, sigma_q, mu_p, Phi, eps=eps)
    dsigma_fb   = grad_feedback_sigma_q(mu_q, sigma_q, mu_p, sigma_p, Phi, eps=eps)

    # ─── Alignment: i is source ───
    dmu_align = 0
    dsigma_align = 0
    for neighbor in agent_i.neighbors:
        agent_j = agents[neighbor["id"]]
        Omega_ij = agent_i.Omega_cache[agent_j.id]

        sigma_qj = sanitize_sigma(agent_j.sigma_q_field, eps=eps)

        dmu_align += grad_belief_align_mu_i(
            mu_q, sigma_q, agent_j.mu_q_field, sigma_qj, Omega_ij, eps=eps
        )
        dsigma_align += grad_belief_align_sigma_i(
            mu_q, sigma_q, agent_j.mu_q_field, sigma_qj, Omega_ij, eps=eps
        )

    # ─── Alignment: i is target ───
    dmu_align_rev = 0
    dsigma_align_rev = 0
    for agent_k in agents:
        for neighbor in agent_k.neighbors:
            if neighbor.get("id") == agent_i.id:
                Omega_kj = agent_k.Omega_cache[agent_i.id]

                sigma_qk = sanitize_sigma(agent_k.sigma_q_field, eps=eps)

                dmu_align_rev += grad_belief_align_mu_j(
                    agent_k.mu_q_field, sigma_qk,
                    mu_q, sigma_q, Omega_kj, eps=eps
                )
                dsigma_align_rev += grad_belief_align_sigma_j(
                    agent_k.mu_q_field, sigma_qk,
                    mu_q, sigma_q, Omega_kj, eps=eps
                )

    # ─── Total gradient ───
    dmu_total = (
        alpha * dmu_self +
        lambd * dmu_fb +
        beta * (dmu_align + dmu_align_rev)
    )

    dsigma_total = (
        alpha * dsigma_self +
        lambd * dsigma_fb +
        beta * (dsigma_align + dsigma_align_rev)
    )

    #print(f"[grad mu_q] norm from belief= {np.linalg.norm(dmu_total):.2e}")
   # print(f"[grad Sigma_q] norm from belief = {np.linalg.norm(dsigma_total):.2e}\n\n")

    return dmu_total, dsigma_total





#==============================================================================
#
#                    FEEDBACK TERMS
#      everything validated below
#==============================================================================

def grad_feedback_mu_q(mu_q_field, sigma_q_field, mu_p_field, Phi, eps=1e-8):
    """
    Compute ∂/∂μ_q D_KL(p || Φ·q) over a spatial field (..., K_q)

    This computes the gradient of the KL divergence between
    a fixed distribution p = N(μ_p, Σ_p) and the pushforward of
    a belief distribution q = N(μ_q, Σ_q) under the linear transformation Φ:
        Φ·q := N(Φ μ_q, Φ Σ_q Φᵀ)

    Let:
        Δμ = μ_p − Φ μ_q
        Σ_q_push = Φ Σ_q Φᵀ
        M = Σ_q_push⁻¹

    The closed-form expression is:
        ∂/∂μ_q D_KL(p || Φ·q) = - Φᵀ · M · (μ_p − Φ μ_q)

    Args:
        mu_q_field    : (..., K_q)     — belief mean field
        sigma_q_field : (..., K_q, K_q) — belief covariance field
        mu_p_field    : (..., K_p)     — target model mean
        Phi           : (..., K_p, K_q) — bundle morphism Φ
        eps           : small regularization for matrix inversion
        
    Returns:
        grad_mu_q     : (..., K_q), the KL gradient w.r.t. μ_q
    """
    # Compute pushforward mean: Φ μ_q
    mu_q_push = np.einsum("...ij,...j->...i", Phi, mu_q_field)
    sigma_q_field = sanitize_sigma(sigma_q_field, eps=eps)

    # Compute pushforward covariance: Φ Σ_q Φ^T
    sigma_push = np.einsum("...ik,...kl,...jl->...ij", Phi, sigma_q_field, Phi)

    # Safe inverse
    sigma_push_inv = safe_inv(sigma_push, eps=eps)

    # Δμ = μ_p − Φ μ_q
    delta_mu = mu_p_field - mu_q_push

    # Gradient: - Φ^T (Φ Σ_q Φ^T)^{-1} (μ_p - Φ μ_q)
    tmp = np.einsum("...ij,...j->...i", sigma_push_inv, delta_mu)
    grad_mu_q = -np.einsum("...ji,...j->...i", Phi, tmp)

    return grad_mu_q


def grad_feedback_sigma_q(mu_q_field, sigma_q_field, mu_p_field,
                           sigma_p_field, Phi, eps=1e-8):
    """
    Compute ∂/∂Σ_q D_KL(p || Φ·q) over spatial field (H, W, K_q, K_q)

    This computes the variational gradient of the KL divergence between
    a target distribution p = N(μ_p, Σ_p) and the pushforward of a belief
    distribution q = N(μ_q, Σ_q) under the linear transformation Φ:
        Φ·q := N(Φ μ_q, Φ Σ_q Φᵀ)

    Let:
        Δμ = μ_p - Φ μ_q
        Σ_q_push = Φ Σ_q Φᵀ
        M := Σ_q_push⁻¹
        A := Δμ Δμᵀ

    The closed-form expression is:
        ∂/∂Σ_q D_KL(p || Φ·q)
        = ½ Φᵀ [ M - M A M - M Σ_p M ] Φ

    Args:
        mu_q_field     : (..., K_q)
        sigma_q_field  : (..., K_q, K_q)
        mu_p_field     : (..., K_p)
        sigma_p_field  : (..., K_p, K_p)
        Phi            : (..., K_p, K_q)
        eps            : regularization epsilon

    Returns:
        grad_sigma_q   : (..., K_q, K_q)
    """
    mu_q_push = np.einsum("...ij,...j->...i", Phi, mu_q_field)  # (..., K_p)

    Phi_T = np.swapaxes(Phi, -1, -2)
    sigma_q_field = sanitize_sigma(sigma_q_field, eps=eps)

    sigma_q_push = np.einsum("...ik,...kl,...jl->...ij", Phi, sigma_q_field, Phi)
    sigma_q_push_inv = safe_inv(sigma_q_push, eps=eps)

    delta_mu = mu_p_field - mu_q_push  # (..., K_p)
    A = np.einsum("...i,...j->...ij", delta_mu, delta_mu)

    inv_term     = sigma_q_push_inv
    mahal_term   = np.einsum("...ik,...kl,...lj->...ij", sigma_q_push_inv, A, sigma_q_push_inv)
    trace_term   = np.einsum("...ik,...kl,...lj->...ij", sigma_q_push_inv, sigma_p_field, sigma_q_push_inv)

    M = inv_term - mahal_term - trace_term  # (..., K_p, K_p)

    grad_sigma_q = 0.5 * np.einsum("...ki,...kl,...lj->...ij", Phi, M, Phi)

    return grad_sigma_q






#==============================================================================
#
#                    SELF-ENERGY TERMS
#
#==============================================================================

def grad_self_energy_mu_q(mu_q_field, sigma_q_field, mu_p_field, sigma_p_field, Phi_tilde, eps=1e-8):
    """
    Compute ∂/∂μ_q D_KL(q || Φ̃·p) over a spatial field (..., K_q)

    This is the gradient of the KL divergence between q and the
    pushforward of a model distribution p under Φ̃:
        Φ̃·p := N(Φ̃ μ_p, Φ̃ Σ_p Φ̃ᵀ)

    Let:
        Δμ = μ_q − Φ̃ μ_p
        Σ_p_push = Φ̃ Σ_p Φ̃ᵀ
        M = Σ_p_push⁻¹

    The gradient is:
        ∂/∂μ_q D_KL(q || Φ̃·p) = M · (μ_q − Φ̃ μ_p)

    Args:
        mu_q_field     : (..., K_q)
        sigma_q_field  : (..., K_q, K_q)
        mu_p_field     : (..., K_p)
        sigma_p_field  : (..., K_p, K_p)
        Phi_tilde      : (..., K_q, K_p)
        eps            : small regularization for inversion

    Returns:
        grad_mu_q      : (..., K_q)
    """
    mu_p_push = np.einsum("...ij,...j->...i", Phi_tilde, mu_p_field)
    sigma_p_field = sanitize_sigma(sigma_p_field, eps=eps)
    sigma_p_push = np.einsum("...iq,...qr,...jr->...ij", Phi_tilde, sigma_p_field, Phi_tilde)
    sigma_p_push_inv = safe_inv(sigma_p_push, eps=eps)

    delta_mu = mu_q_field - mu_p_push
    grad_mu_q = np.einsum("...ij,...j->...i", sigma_p_push_inv, delta_mu)

    return grad_mu_q


def grad_self_energy_sigma_q(mu_q_field, sigma_q_field, mu_p_field, sigma_p_field, Phi_tilde, eps=1e-8):
    """
    Compute ∂/∂Σ_q D_KL(q || Φ̃·p) over a spatial field (..., K_q, K_q)

    This is the gradient of the KL divergence between:
        q = N(μ_q, Σ_q)
        Φ̃·p = N(Φ̃ μ_p, Φ̃ Σ_p Φ̃ᵀ)

    The closed-form expression is:
        ∂/∂Σ_q D_KL(q || Φ̃·p)
        = ½ [ Σ_q⁻¹ − (Φ̃ Σ_p Φ̃ᵀ)⁻¹ ]

    Args:
        mu_q_field     : (..., K_q)
        sigma_q_field  : (..., K_q, K_q)
        mu_p_field     : (..., K_p)
        sigma_p_field  : (..., K_p, K_p)
        Phi_tilde      : (..., K_q, K_p)
        eps            : small regularization constant for safe inversion

    Returns:
        grad_sigma_q   : (..., K_q, K_q)
    """
    sigma_q_inv = safe_inv(sigma_q_field, eps=eps)
    sigma_p_field = sanitize_sigma(sigma_p_field, eps=eps)
    sigma_p_push = np.einsum("...iq,...qr,...jr->...ij", Phi_tilde, sigma_p_field, Phi_tilde)
    sigma_p_push_inv = safe_inv(sigma_p_push, eps=eps)

    #check this sign!!!!

    grad = 0.5 * (sigma_p_push_inv - sigma_q_inv)
    return grad



#==============================================================================
#
#                    ALIGNMENT TERMS - NOT VALIDATED
#
#==============================================================================

def grad_belief_align_mu_i(mu_i, sigma_i, mu_j, sigma_j, Omega_ij, eps=1e-8):
    """
    Compute ∂/∂μ_i D_KL(q_i || Ω q_j)

    This computes the gradient of the KL divergence between:
        q_i = N(μ_i, Σ_i)
        Ω q_j = N(Ω μ_j, Ω Σ_j Ωᵀ)

    with respect to μ_i.

    Let:
        μ_j^t := Ω μ_j
        Σ_j^t := Ω Σ_j Ωᵀ
        Δμ := μ_i − μ_j^t

    Then:
        ∂/∂μ_i D_KL(q_i || Ω q_j) = Σ_j^t⁻¹ · (μ_i − Ω μ_j)

    Args:
        mu_i     : (..., K)
        sigma_i  : (..., K, K)
        mu_j     : (..., K)
        sigma_j  : (..., K, K)
        Omega_ij : (..., K, K) — transport operator
        eps      : regularization for inversion

    Returns:
        grad_mu_i: (..., K)
    """
    
    mu_j_t = np.einsum("...ij,...j->...i", Omega_ij, mu_j)
    delta_mu = mu_i - mu_j_t

    Omega_T = np.swapaxes(Omega_ij, -1, -2)
    sigma_j_t = np.matmul(Omega_ij, np.matmul(sigma_j, Omega_T))
    sigma_j_t = sanitize_sigma(sigma_j_t, eps=eps)
    sigma_inv = safe_inv(sigma_j_t, eps=eps)

    grad = np.einsum("...ij,...j->...i", sigma_inv, delta_mu)
    return grad


def grad_belief_align_sigma_i(mu_i, sigma_i, mu_j, sigma_j, Omega_ij, eps=1e-8):
    """
    Compute ∂/∂Σ_i D_KL(q_i || Ω q_j)

    This computes the gradient of the KL divergence between:
        q_i = N(μ_i, Σ_i)
        Ω q_j = N(Ω μ_j, Ω Σ_j Ωᵀ)

    with respect to Σ_i.

    The closed-form expression is:
        ∂/∂Σ_i D_KL(q_i || Ω q_j)
        = ½ [ (Ω Σ_j Ωᵀ)^(-1) − Σ_i^(-1) ]

    Args:
        mu_i     : (..., K)
        sigma_i  : (..., K, K)
        mu_j     : (..., K)
        sigma_j  : (..., K, K)
        Omega_ij : (..., K, K)
        eps      : regularization epsilon

    Returns:
        grad_sigma_i : (..., K, K)
    """
    Omega_T = np.swapaxes(Omega_ij, -1, -2)
    sigma_j_t = np.einsum("...ik,...kl,...lj->...ij", Omega_ij, sigma_j, Omega_T)

    inv_j = safe_inv(sigma_j_t, eps=eps)
    inv_i = safe_inv(sigma_i, eps=eps)

    grad = 0.5 * (inv_j - inv_i)
    return grad


def grad_belief_align_mu_j(mu_i, sigma_i, mu_j, sigma_j, Omega_ij, eps=1e-8):
    """
    Compute ∂/∂μ_j D_KL(q_i || Ω q_j)

    This is the gradient of the KL divergence between:
        q_i = N(μ_i, Σ_i)
        Ω q_j = N(Ω μ_j, Ω Σ_j Ωᵀ)

    with respect to μ_j.

    Let:
        μ_j^t := Ω μ_j
        Σ_j^t := Ω Σ_j Ωᵀ
        Δμ := μ_i − μ_j^t
        M := Σ_j^t⁻¹

    Then:
        ∂/∂μ_j D_KL(q_i || Ω q_j)
        = - Ωᵀ M (μ_i − Ω μ_j)

    Args:
        mu_i     : (..., K)
        sigma_i  : (..., K, K)
        mu_j     : (..., K)
        sigma_j  : (..., K, K)
        Omega_ij : (..., K, K)
        eps      : small regularization constant

    Returns:
        grad_mu_j : (..., K)
    """
    mu_j_t = np.einsum("...ij,...j->...i", Omega_ij, mu_j)
    delta_mu = mu_i - mu_j_t

    Omega_T = np.swapaxes(Omega_ij, -1, -2)
    sigma_j_t = np.einsum("...ik,...kl,...lj->...ij", Omega_ij, sigma_j, Omega_T)

    #sigma_j_t = sanitize_sigma(sigma_j_t, eps=eps)
    sigma_inv = safe_inv(sigma_j_t, eps=eps)

    tmp = np.einsum("...ij,...j->...i", sigma_inv, delta_mu)
    grad = -np.einsum("...ji,...i->...j", Omega_ij, tmp)
    return grad


def grad_belief_align_sigma_j_simp(mu_i, sigma_i, mu_j, sigma_j, Omega_ij, eps=1e-8):
    """
    Compute ∂/∂Σ_j D_KL(q_i || Ω q_j), assuming Ω ∈ SO(3)

    This computes the gradient of the KL divergence between:
        q_i     = N(μ_i, Σ_i)
        Ω q_j   = N(Ω μ_j, Ω Σ_j Ωᵀ)

    Let:
        Δμ := μ_i − Ω μ_j

    Uses the SO(3)-simplified expression:
        ∂/∂Σ_j D_KL(q_i || Ω q_j)
        = ½ [ Σ_j⁻¹ Ωᵀ Δμ Δμᵀ Ω Σ_j⁻¹
             − Σ_j⁻¹ Ωᵀ Σ_i Ω Σ_j⁻¹
             − Σ_j⁻¹ ]
        simplified due to SO3
    Args:
        mu_i     : (..., K)
        sigma_i  : (..., K, K)
        mu_j     : (..., K)
        sigma_j  : (..., K, K)
        Omega_ij : (..., K, K)
        eps      : regularization constant

    Returns:
        grad_sigma_j : (..., K, K)
    """
    Omega_T = np.swapaxes(Omega_ij, -1, -2)

    mu_j_t = np.einsum("...ij,...j->...i", Omega_ij, mu_j)
    delta_mu = mu_i - mu_j_t

    sigma_j = sanitize_sigma(sigma_j, eps=eps)
    sigma_j_inv = safe_inv(sigma_j, eps=eps)

    # Δμ Δμᵀ
    outer = np.einsum("...i,...j->...ij", delta_mu, delta_mu)

    # First term: Σ_j⁻¹ Ωᵀ Δμ Δμᵀ Ω Σ_j⁻¹
    term1 = np.einsum("...ik,...kl,...lm,...mj->...ij",
                      sigma_j_inv, Omega_T, outer, Omega_ij)
    term1 = np.einsum("...ik,...kj->...ij", term1, sigma_j_inv)

    # Second term: Σ_j⁻¹ Ωᵀ Σ_i Ω Σ_j⁻¹
    term2 = np.einsum("...ik,...kl,...lm->...im", Omega_T, sigma_i, Omega_ij)
    term2 = np.einsum("...ik,...kl,...lj->...ij",
                      sigma_j_inv, term2, sigma_j_inv)

    # Third term: Σ_j⁻¹
    term3 = sigma_j_inv

    grad = 0.5 * (term1 - term2 - term3)
    return grad



def grad_belief_align_sigma_j(mu_i, sigma_i, mu_j, sigma_j, Omega_ij, eps=1e-8):
    """
    Compute ∂/∂Σ_j D_KL(q_i || Ω q_j)

    This is the gradient of the KL divergence between:
        q_i = N(μ_i, Σ_i)
        Ω q_j = N(Ω μ_j, Ω Σ_j Ωᵀ)

    with respect to Σ_j.

    Let:
        Σ_j^t := Ω Σ_j Ωᵀ
        Δμ := μ_i − Ω μ_j
        M := (Σ_j^t)^(-1)

    The full expression is:
        ∂/∂Σ_j D_KL(q_i || Ω q_j)
        = ½ Ωᵀ [ M Δμ Δμᵀ M − M Σ_i M − M ] Ω

    Args:
        mu_i     : (..., K)
        sigma_i  : (..., K, K)
        mu_j     : (..., K)
        sigma_j  : (..., K, K)
        Omega_ij : (..., K, K)
        eps      : small regularization constant

    Returns:
        grad_sigma_j : (..., K, K)
    """
    mu_j_t = np.einsum("...ij,...j->...i", Omega_ij, mu_j)
    delta_mu = mu_i - mu_j_t

    Omega_T = np.swapaxes(Omega_ij, -1, -2)
    sigma_j_t = np.einsum("...ik,...kl,...lj->...ij", Omega_ij, sigma_j, Omega_T)
    #sigma_j_t = sanitize_sigma(sigma_j_t, eps=eps)
    sigma_inv = safe_inv(sigma_j_t, eps=eps)

    # Term 1: M Δμ Δμᵀ M
    tmp = np.einsum("...i,...j->...ij", delta_mu, delta_mu)
    term1 = np.einsum("...ik,...kl,...lj->...ij", sigma_inv, tmp, sigma_inv)

    # Term 2: M Σ_i M
    term2 = np.einsum("...ik,...kl,...lj->...ij", sigma_inv, sigma_i, sigma_inv)

    # Term 3: M
    term3 = sigma_inv

    # Combine and pull back to Σ_j
    diff = term1 - term2 - term3
    grad = 0.5 * np.einsum("...ik,...kl,...lj->...ij", Omega_T, diff, Omega_ij)
    return grad


