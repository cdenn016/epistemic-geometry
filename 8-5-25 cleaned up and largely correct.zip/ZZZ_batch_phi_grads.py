# -*- coding: utf-8 -*-
"""
Created on Tue Aug  5 12:20:38 2025

@author: chris and christine
"""


def accumulate_phi_alignment_gradient_batched(agent_i, agents, generators, params, debug=False):
    """
    Batch over all neighbors j of agent_i:
        ∇_{φ_i} KL(q_i || Ω_{ij} q_j)
    and accumulate into agent_i.grad_phi.

    Args:
        agent_i    : source agent (holds φ_i)
        agents     : list of all agents
        generators : (d, K, K) Lie algebra generators
        params     : dict of parameters
    """
    beta = params.get("beta", config.beta)
    if beta <= 0:
        return

    eps = config.support_cutoff_eps
    mask = (agent_i.mask > eps)[..., None]
    neighbors = agent_i.neighbors
    if not neighbors:
        return

    # ─── Stack neighbor fields ───
    mu_j_list, sigma_j_list = [], []
    phi_j_list, exp_phi_j_list = [], []
    Omega_ij_list = []

    for nb in neighbors:
        j = nb["id"]
        agent_j = agents[j]
        mu_j_list.append(agent_j.mu_q_field)
        sigma_j_list.append(agent_j.sigma_q_field)
        phi_j_list.append(agent_j.phi)
        exp_phi_j_list.append(agent_j._exp_phi)
        Omega_ij_list.append(agent_i.Omega_cache[j])

    mu_j_batch       = np.stack(mu_j_list)          # (B, H, W, K)
    sigma_j_batch    = np.stack(sigma_j_list)       # (B, H, W, K, K)
    phi_j_batch      = np.stack(phi_j_list)         # (B, H, W, d)
    exp_phi_j_batch  = np.stack(exp_phi_j_list)     # (B, H, W, K, K)
    Omega_ij_batch   = np.stack(Omega_ij_list)      # (B, H, W, K, K)

    # ─── Fields of agent_i ───
    mu_i     = agent_i.mu_q_field                   # (H, W, K)
    sigma_i  = agent_i.sigma_q_field                # (H, W, K, K)
    phi_i    = agent_i.phi                          # (H, W, d)
    exp_phi_i = agent_i._exp_phi                    # (H, W, K, K)

    # ─── Precompute Ω μ_j and (Ω Σ_j Ωᵀ)⁻¹ ───
    mu_j_t = np.einsum("...ij,...j->...i", Omega_ij_batch, mu_j_batch)
    Omega_T = np.swapaxes(Omega_ij_batch, -1, -2)
    sigma_j_push = np.einsum("...ik,...kl,...jl->...ij", Omega_ij_batch, sigma_j_batch, Omega_T)
    sigma_j_push = sanitize_sigma(sigma_j_push, eps)
    sigma_j_inv = safe_inv(sigma_j_push, eps)

    # ─── Compute batched ∇_{φ_i} KL(q_i || Ω q_j) ───
    grad_batch = grad_kl_alignment_phi_i_batched(
        mu_i, sigma_i,
        mu_j_batch, sigma_j_batch,
        phi_i, phi_j_batch,
        Omega_ij_batch,
        generators,
        exp_phi_i, exp_phi_j_batch,
        mu_j_t, sigma_j_inv,
        eps=eps,
    )  # → (B, H, W, d)

    grad_sum = np.sum(grad_batch, axis=0)           # (H, W, d)

    # ─── Apply Fisher projection, dexp⁻¹, mask ───
    G_inv = agent_i.inverse_fisher_phi
    grad_nat = np.einsum("...ab,...b->...a", G_inv, grad_sum)
    grad_phi = dexpinv_operator(phi_i, grad_nat, generators)
    #grad_phi = clip_gradient_norm(grad_phi, config.phi_grad_clip)

    agent_i.grad_phi += beta * grad_phi * mask


def accumulate_phi_alignment_gradient_phi_j_batched(agent_i, agents, generators, params, debug=False):
    """
    Batch and accumulate ∇_{φ_j} KL(q_i || Ω_{ij} q_j) for all neighbors j of agent_i.
    Applies gradient to each agent_j.grad_phi.
    """
    beta = params.get("beta", config.beta)
    if beta <= 0:
        return

    eps = config.support_cutoff_eps
    neighbors = agent_i.neighbors
    if not neighbors:
        return

    # Agent i fields
    mu_i = agent_i.mu_q_field                    # (H, W, K)
    sigma_i = agent_i.sigma_q_field              # (H, W, K, K)
    phi_i = agent_i.phi
    exp_phi_i = agent_i._exp_phi

    # Stack all neighbor fields
    mu_j_list = []
    sigma_j_list = []
    phi_j_list = []
    exp_phi_j_list = []
    Omega_ij_list = []
    G_inv_list = []
    mask_list = []
    id_list = []

    for nb in neighbors:
        j = nb["id"]
        agent_j = agents[j]
        mu_j_list.append(agent_j.mu_q_field)
        sigma_j_list.append(agent_j.sigma_q_field)
        phi_j_list.append(agent_j.phi)
        exp_phi_j_list.append(agent_j._exp_phi)
        Omega_ij_list.append(agent_i.Omega_cache[j])
        G_inv_list.append(agent_j.inverse_fisher_phi)
        mask_list.append(agent_j.mask > eps)
        id_list.append(j)

    # Stack arrays
    mu_j_batch = np.stack(mu_j_list)                 # (B, H, W, K)
    sigma_j_batch = np.stack(sigma_j_list)           # (B, H, W, K, K)
    phi_j_batch = np.stack(phi_j_list)               # (B, H, W, d)
    exp_phi_j_batch = np.stack(exp_phi_j_list)       # (B, H, W, K, K)
    Omega_ij_batch = np.stack(Omega_ij_list)         # (B, H, W, K, K)
    G_inv_batch = np.stack(G_inv_list)               # (B, H, W, d, d)
    mask_batch = np.stack(mask_list)[..., None]      # (B, H, W, 1)

    # Precompute pushforward mean/cov
    mu_j_t_batch = np.einsum("...ij,...j->...i", Omega_ij_batch, mu_j_batch)
    Omega_T = np.swapaxes(Omega_ij_batch, -1, -2)
    sigma_j_push = np.einsum("...ik,...kl,...jl->...ij", Omega_ij_batch, sigma_j_batch, Omega_T)
    sigma_j_push = sanitize_sigma(sigma_j_push, eps)
    sigma_j_inv_batch = safe_inv(sigma_j_push, eps)

    # Batched gradient
    grad_batch = grad_kl_alignment_phi_j_batched(
        mu_i, sigma_i,
        mu_j_batch, sigma_j_batch,
        phi_j_batch, phi_i,
        Omega_ij_batch,
        generators,
        exp_phi_j_batch, exp_phi_i,
        mu_j_t_batch,
        sigma_j_inv_batch,
        eps=eps,
    )  # (B, H, W, d)

    # Apply projection, dexpinv, mask, and accumulate to each j
    for b, j in enumerate(id_list):
        grad_j_nat = np.einsum("...ab,...b->...a", G_inv_batch[b], grad_batch[b])
        grad_j = dexpinv_operator(phi_j_batch[b], grad_j_nat, generators)
        grad_j *= mask_batch[b]
        agents[j].grad_phi += beta * grad_j

def accumulate_phi_alignment_gradients_both(agent_i, agents, generators, params, debug=False):
    """
    Compute and apply both:
        ∇_{φ_i} KL(q_i || Ω_ij q_j)       (accumulated into agent_i.grad_phi)
        ∇_{φ_j} KL(q_i || Ω_ij q_j)       (accumulated into agent_j.grad_phi)

    for all neighbors j of agent_i, in a single batched call.

    Args:
        agent_i    : central agent (source of φ_i)
        agents     : list of all agents
        generators : (d, K, K) Lie algebra generators
        params     : dict of parameters
    """
    beta = params.get("beta", config.beta)
    if beta <= 0:
        return

    eps = config.support_cutoff_eps
    mask_i = (agent_i.mask > eps)[..., None]
    neighbors = agent_i.neighbors
    if not neighbors:
        return

    # ─── Agent i fields ───
    mu_i = agent_i.mu_q_field
    sigma_i = agent_i.sigma_q_field
    phi_i = agent_i.phi
    exp_phi_i = agent_i._exp_phi
    G_inv_i = agent_i.inverse_fisher_phi

    # ─── Stack neighbor fields ───
    mu_j_list, sigma_j_list = [], []
    phi_j_list, exp_phi_j_list = [], []
    Omega_ij_list = []
    G_inv_list, mask_list, id_list = [], [], []

    for nb in neighbors:
        j = nb["id"]
        agent_j = agents[j]
        mu_j_list.append(agent_j.mu_q_field)
        sigma_j_list.append(agent_j.sigma_q_field)
        phi_j_list.append(agent_j.phi)
        exp_phi_j_list.append(agent_j._exp_phi)
        Omega_ij_list.append(agent_i.Omega_cache[j])
        G_inv_list.append(agent_j.inverse_fisher_phi)
        mask_list.append(agent_j.mask > eps)
        id_list.append(j)

    # ─── Convert to batch arrays ───
    mu_j_batch       = np.stack(mu_j_list)               # (B, H, W, K)
    sigma_j_batch    = np.stack(sigma_j_list)            # (B, H, W, K, K)
    phi_j_batch      = np.stack(phi_j_list)              # (B, H, W, d)
    exp_phi_j_batch  = np.stack(exp_phi_j_list)          # (B, H, W, K, K)
    Omega_ij_batch   = np.stack(Omega_ij_list)           # (B, H, W, K, K)
    G_inv_batch      = np.stack(G_inv_list)              # (B, H, W, d, d)
    mask_batch       = np.stack(mask_list)[..., None]    # (B, H, W, 1)

    # ─── Precompute shared values ───
    mu_j_t_batch = np.einsum("...ij,...j->...i", Omega_ij_batch, mu_j_batch)
    Omega_T = np.swapaxes(Omega_ij_batch, -1, -2)
    sigma_j_push = np.einsum("...ik,...kl,...jl->...ij", Omega_ij_batch, sigma_j_batch, Omega_T)
    sigma_j_push = sanitize_sigma(sigma_j_push, eps)
    sigma_j_inv_batch = safe_inv(sigma_j_push, eps)

    # ─── ∇_{φᵢ} KL(qᵢ ‖ Ω_ij qⱼ) ───
    grad_phi_i_batch = grad_kl_alignment_phi_i_batched(
        mu_i, sigma_i,
        mu_j_batch, sigma_j_batch,
        phi_i, phi_j_batch,
        Omega_ij_batch,
        generators,
        exp_phi_i, exp_phi_j_batch,
        mu_j_t_batch, sigma_j_inv_batch,
        eps=eps,
    )
    grad_phi_i_total = np.sum(grad_phi_i_batch, axis=0)  # (H, W, d)
    grad_i_nat = np.einsum("...ab,...b->...a", G_inv_i, grad_phi_i_total)
    grad_i = dexpinv_operator(phi_i, grad_i_nat, generators)
    agent_i.grad_phi += beta * grad_i * mask_i

    # ─── ∇_{φⱼ} KL(qᵢ ‖ Ω_ij qⱼ) ───
    grad_phi_j_batch = grad_kl_alignment_phi_j_batched(
        mu_i, sigma_i,
        mu_j_batch, sigma_j_batch,
        phi_j_batch, phi_i,
        Omega_ij_batch,
        generators,
        exp_phi_j_batch, exp_phi_i,
        mu_j_t_batch, sigma_j_inv_batch,
        eps=eps,
    )
    for b, j in enumerate(id_list):
        grad_j_nat = np.einsum("...ab,...b->...a", G_inv_batch[b], grad_phi_j_batch[b])
        grad_j = dexpinv_operator(phi_j_batch[b], grad_j_nat, generators)
        agents[j].grad_phi += beta * grad_j * mask_batch[b]



def accumulate_phi_model_alignment_gradients_both(agent_i, agents, generators, params, debug=False):
    """
    Compute and apply both:
        ∇_{φ̃_i} KL(p_i || Ω̃_ij p_j)
        ∇_{φ̃_j} KL(p_i || Ω̃_ij p_j)
    for all neighbors j of agent_i, in a single batched call.

    Applies to:
        agent_i.grad_phi_tilde
        agent_j.grad_phi_tilde for all neighbors j
    """
    beta = params.get("beta_model", config.beta_model)
    if beta <= 0:
        return

    eps = config.support_cutoff_eps
    mask_i = (agent_i.mask > eps)[..., None]
    neighbors = agent_i.neighbors
    if not neighbors:
        return

    mu_pi = agent_i.mu_p_field
    sigma_pi = agent_i.sigma_p_field
    phi_i = agent_i.phi_model
    exp_phi_i = agent_i._exp_phi_model
    G_inv_i = agent_i.inverse_fisher_phi_model

    mu_j_list, sigma_j_list = [], []
    phi_j_list, exp_phi_j_list = [], []
    Omega_tilde_list = []
    G_inv_list, mask_list, id_list = [], [], []

    for nb in neighbors:
        j = nb["id"]
        agent_j = agents[j]
        mu_j_list.append(agent_j.mu_p_field)
        sigma_j_list.append(agent_j.sigma_p_field)
        phi_j_list.append(agent_j.phi_model)
        exp_phi_j_list.append(agent_j._exp_phi_model)
        Omega_tilde_list.append(agent_i.Omega_tilde_cache[j])
        G_inv_list.append(agent_j.inverse_fisher_phi_model)
        mask_list.append(agent_j.mask > eps)
        id_list.append(j)

    mu_j_batch = np.stack(mu_j_list)
    sigma_j_batch = np.stack(sigma_j_list)
    phi_j_batch = np.stack(phi_j_list)
    exp_phi_j_batch = np.stack(exp_phi_j_list)
    Omega_tilde_batch = np.stack(Omega_tilde_list)
    G_inv_batch = np.stack(G_inv_list)
    mask_batch = np.stack(mask_list)[..., None]

    mu_j_t_batch = np.einsum("...ij,...j->...i", Omega_tilde_batch, mu_j_batch)
    Omega_T = np.swapaxes(Omega_tilde_batch, -1, -2)
    sigma_j_push = np.einsum("...ik,...kl,...jl->...ij", Omega_tilde_batch, sigma_j_batch, Omega_T)
    sigma_j_push = sanitize_sigma(sigma_j_push, eps)
    sigma_j_inv_batch = safe_inv(sigma_j_push, eps)

    # ∇_{φ̃_i} batched
    grad_phi_i_batch = grad_kl_alignment_phi_i_batched(
        mu_pi, sigma_pi,
        mu_j_batch, sigma_j_batch,
        phi_i, phi_j_batch,
        Omega_tilde_batch,
        generators,
        exp_phi_i, exp_phi_j_batch,
        mu_j_t_batch, sigma_j_inv_batch,
        eps=eps,
    )
    grad_phi_i_total = np.sum(grad_phi_i_batch, axis=0)
    grad_i_nat = np.einsum("...ab,...b->...a", G_inv_i, grad_phi_i_total)
    grad_i = dexpinv_operator(phi_i, grad_i_nat, generators)
    agent_i.grad_phi_tilde += beta * grad_i * mask_i

    # ∇_{φ̃_j} batched
    grad_phi_j_batch = grad_kl_alignment_phi_j_batched(
        mu_pi, sigma_pi,
        mu_j_batch, sigma_j_batch,
        phi_j_batch, phi_i,
        Omega_tilde_batch,
        generators,
        exp_phi_j_batch, exp_phi_i,
        mu_j_t_batch, sigma_j_inv_batch,
        eps=eps,
    )

    for b, j in enumerate(id_list):
        grad_j_nat = np.einsum("...ab,...b->...a", G_inv_batch[b], grad_phi_j_batch[b])
        grad_j = dexpinv_operator(phi_j_batch[b], grad_j_nat, generators)
        agents[j].grad_phi_tilde += beta * grad_j * mask_batch[b]





def grad_kl_alignment_phi_i_batched(
    mu_i, sigma_i,
    mu_j_batch, sigma_j_batch,
    phi_i, phi_j_batch,
    Omega_ij_batch,
    generators,
    exp_phi_i,
    exp_phi_j_batch,
    mu_j_t_batch,
    sigma_j_t_inv_batch,
    eps=1e-8
):
    """
    Compute batched ∇_{φ_i} KL(q_i || Ω_{ij} q_j) for multiple neighbors j.

    Returns:
        grad_phi_i_batch : (B, H, W, d)
    """
    d, K, _ = generators.shape
    B, H, W, _ = mu_j_batch.shape
    grad = np.zeros((B, H, W, d), dtype=mu_i.dtype)

    delta_mu = mu_i[None, ...] - mu_j_t_batch  # (B, H, W, K)

    # Precompute batch of ∂ e^{φ_i} / ∂ φ^a → shape (H, W, d, K, K)
    d_exp_batch = d_exp_phi_exact_batch(phi_i, generators)  # (H, W, d, K, K)

    for a in range(d):
        Q = d_exp_batch[..., a, :, :]           # (H, W, K, K)
        Q_T = np.swapaxes(Q, -1, -2)
        Q_batched = np.broadcast_to(Q, (B, H, W, K, K))
        Q_T_batched = np.broadcast_to(Q_T, (B, H, W, K, K))

        exp_phi_j = exp_phi_j_batch
        exp_mphi_j = exp_phi_j.swapaxes(-1, -2)

        sigma_i_batch = np.broadcast_to(sigma_i, (B, H, W, K, K))
        mu_j = mu_j_batch
        sigma_j_inv = sigma_j_t_inv_batch
        Omega_ij = Omega_ij_batch
        Omega_T = Omega_ij.swapaxes(-1, -2)

        # ---- Term 1 ----
        t1a = np.einsum("...ij,...jk,...kl,...lm->...im", sigma_j_batch, exp_phi_j, Q_T_batched, sigma_i_batch)
        t1a = np.einsum("...ij,...jk->...ik", t1a, Omega_ij)

        t1b = np.einsum("...ij,...jk,...kl,...lm->...im", sigma_j_batch, Omega_T, sigma_i_batch, Q_batched)
        t1b = np.einsum("...ij,...jk->...ik", t1b, exp_mphi_j)

        trace1 = np.einsum("...ii->...", t1a + t1b)

        # ---- Term 2 ----
        v = np.einsum("...ij,...j->...i", sigma_j_inv, delta_mu)
        tmp = np.einsum("...ij,...jk->...ik", Q_T_batched, v[..., None])
        tmp = np.einsum("...ij,...jk->...ik", exp_phi_j, tmp)
        term2 = np.einsum("...i,...i->...", mu_j, tmp[..., 0])

        # ---- Term 3 ----
        A1 = np.einsum("...ij,...jk,...kl->...il", exp_phi_j, Q_T_batched, Omega_ij)
        A1 = np.einsum("...ij,...jk->...ik", A1, sigma_j_batch)

        A2 = np.einsum("...ij,...jk,...kl->...il", Q_batched, exp_mphi_j, sigma_j_batch)
        A2 = np.einsum("...ij,...jk->...ik", A2, Omega_T)

        A = A1 + A2
        quad = np.einsum("...i,...ij,...j->...", delta_mu, A, delta_mu)

        grad[..., a] = 0.5 * trace1 + term2 - 0.5 * quad

    return grad

def grad_kl_alignment_phi_j_batched(
    mu_i, sigma_i,
    mu_j_batch, sigma_j_batch,
    phi_j_batch, phi_i,
    Omega_ij_batch,
    generators,
    exp_phi_j_batch, exp_phi_i,
    mu_j_t_batch,
    sigma_j_t_inv_batch,
    eps=1e-8,
):
    d, K, _ = generators.shape
    B, H, W, _ = mu_j_batch.shape

    grad = np.zeros((B, H, W, d), dtype=mu_i.dtype)

    delta_mu = mu_i[None, ...] - mu_j_t_batch  # (B, H, W, K)
    sigma_i_batch = np.broadcast_to(sigma_i, (B, H, W, K, K))
    exp_phi_i_batch = np.broadcast_to(exp_phi_i, (B, H, W, K, K))
    exp_mphi_i_batch = np.swapaxes(exp_phi_i_batch, -1, -2)

    # ✅ Use batched directional derivative
    d_exp_batch = d_exp_phi_exact_batch(phi_j_batch, generators)  # (B, H, W, d, K, K)

    for a in range(d):
        Q_j = d_exp_batch[..., a, :, :]      # (B, H, W, K, K)
        Q_j_T = np.swapaxes(Q_j, -1, -2)

        Omega_ij = Omega_ij_batch
        Omega_T = np.swapaxes(Omega_ij, -1, -2)
        exp_phi_j = exp_phi_j_batch
        exp_mphi_i = exp_mphi_i_batch
        sigma_j_inv = sigma_j_t_inv_batch

        # ─── Term 1: Trace sandwich ─────────────────────────────
        t1a = np.einsum("...ij,...jk,...kl->...il", exp_phi_i_batch, Q_j_T, Omega_T)
        t1b = np.einsum("...ij,...jk,...kl->...il", Omega_ij, Q_j, exp_mphi_i)
        trace_expr = t1a + t1b
        trace_term = 0.5 * np.einsum("...ij,...jk,...ki->...", sigma_i_batch, sigma_j_inv, trace_expr)

        # ─── Term 2: μ_jᵀ Q_j e^{-φ_i} Σ⁻¹ Δμ ─────────────────────
        tmp = Q_j @ exp_mphi_i @ sigma_j_inv @ delta_mu[..., None]
        term2 = np.einsum("...i,...i->...", mu_j_batch, tmp[..., 0])

        # ─── Term 3a: Δμᵀ Σ⁻¹ e^{φ_i} Q_jᵀ Ωᵀ Δμ ─────────────────
        A = sigma_j_t_inv_batch @ exp_phi_i_batch @ Q_j_T @ Omega_T
        term3a = np.einsum("...i,...ij,...j->...", delta_mu, A, delta_mu)

        # ─── Term 3b: Δμᵀ Ω Q_j e^{-φ_i} Σ⁻¹ Δμ ──────────────────
        B = Omega_ij @ Q_j @ exp_mphi_i @ sigma_j_inv
        term3b = np.einsum("...i,...ij,...j->...", delta_mu, B, delta_mu)

        grad[..., a] = trace_term + term2 - 0.5 * term3a - 0.5 * term3b

    return grad
