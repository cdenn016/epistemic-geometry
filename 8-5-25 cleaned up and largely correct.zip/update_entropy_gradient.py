# -*- coding: utf-8 -*-
"""
Created on Sat Aug  2 16:17:56 2025

@author: chris and christine
"""
from numerical_utils import safe_inv

def compute_entropy_from_eta2(eta2, eps=1e-8):
    """
    Compute entropy of Gaussian from natural parameter η₂.
    Assumes q ∝ exp(η₁ᵀx + xᵀη₂x), where η₂ = −½ Σ⁻¹.

    H[q] = ½ log det(2πe Σ) = ½ (K log(2πe) + log det(−η₂⁻¹))

    Args:
        eta2: (..., K, K)
    Returns:
        entropy: (...,) — entropy scalar per point
    """
    import numpy as np
    from numerical_utils import safe_inv, safe_logdet

    eta2_inv = safe_inv(eta2, eps=eps)  # = −2Σ
    log_det = safe_logdet(eta2_inv, eps=eps)  # log det(−η₂⁻¹)

    K = eta2.shape[-1]
    entropy = 0.5 * (K * (1 + np.log(2 * np.pi)) + log_det)
    return entropy



def grad_entropy_eta2(eta2, eps=1e-8):
    """
    ∇_{η₂} H[q] = −½ η₂⁻¹
    """
    eta2_inv = safe_inv(eta2, eps=eps)
    return -0.5 * eta2_inv  # gradient shape (..., K, K)
