# -*- coding: utf-8 -*-
"""
Created on Wed Jul 23 10:32:58 2025

@author: chris and christine
"""
from joblib import Parallel, delayed
import numpy as np
import config
from natural_gradient import (compute_inverse_fisher_field_natural,
                              )
from get_generators import get_generators
from omega import exp_lie_algebra_irrep

from numerical_utils import soft_clip_phi_norm, safe_inv                       


from numerical_utils import sanitize_sigma, sanitize_eta2, safe_omega_inv              
from generalized_diagnostics_metrics import compute_alignment_field_general


from generalized_diagnostics_metrics import compute_alignment_field_general


from update_terms_morphisms import (
                                    accumulate_phi_gradient_from_morphism_self_and_feedback, 
                                    accumulate_phi_tilde_gradient_from_morphism_self_and_feedback
                                    )


from update_terms_mu_sigma_belief import accumulate_mu_sigma_gradient_belief
from update_terms_mu_sigma_model import accumulate_mu_sigma_gradient_model

from update_terms_phi import (
                accumulate_phi_gradient_belief, 
                accumulate_phi_gradient_model,
                
                )
from bundle_morphism_utils import compute_direct_morphisms


def zero_all_gradients(agent_i):
    import numpy as np

    def ensure_writeable(arr):
        if arr is None:
            return None
        if not arr.flags.writeable:
            return np.copy(arr)
        return arr

    # μ and Σ gradients (belief)
    agent_i.grad_mu_q_field = ensure_writeable(agent_i.grad_mu_q_field)
    agent_i.grad_sigma_q_field = ensure_writeable(agent_i.grad_sigma_q_field)
    agent_i.grad_mu_q = agent_i.grad_mu_q_field
    agent_i.grad_sigma_q = agent_i.grad_sigma_q_field

    # μ and Σ gradients (model)
    agent_i.grad_mu_p_field = ensure_writeable(agent_i.grad_mu_p_field)
    agent_i.grad_sigma_p_field = ensure_writeable(agent_i.grad_sigma_p_field)
    agent_i.grad_mu_p = agent_i.grad_mu_p_field
    agent_i.grad_sigma_p = agent_i.grad_sigma_p_field

    # Gauge field gradients
    agent_i.grad_phi = ensure_writeable(agent_i.grad_phi)
    agent_i.grad_phi_tilde = ensure_writeable(agent_i.grad_phi_tilde)

    # Morphism gradients
    agent_i.grad_Phi = ensure_writeable(agent_i.grad_Phi)
    agent_i.grad_Phi_tilde = ensure_writeable(agent_i.grad_Phi_tilde)

    
    # Zero everything else
    agent_i.grad_mu_q_field.fill(0)
    agent_i.grad_sigma_q_field.fill(0)
    agent_i.grad_mu_p_field.fill(0)
    agent_i.grad_sigma_p_field.fill(0)
    agent_i.grad_phi.fill(0)
    agent_i.grad_phi_tilde.fill(0)
    if agent_i.grad_Phi is not None:
        agent_i.grad_Phi.fill(0)
    if agent_i.grad_Phi_tilde is not None:
        agent_i.grad_Phi_tilde.fill(0)

        

def build_all_omega_caches(agents):
    """
    Build Ω and Ω̃ caches for each agent using their precomputed exp(φ).
    Should be called AFTER preprocess_agent_fields for all agents.
    """
    for agent_i in agents:
        agent_i.Omega_cache = {}
        agent_i.Omega_tilde_cache = {}

        for nb in agent_i.neighbors:
            j = nb["id"]
            agent_j = agents[j]

            Omega_ij = np.einsum("...ik,...kj->...ij", agent_i._exp_phi, agent_j._exp_neg_phi)
            Omega_tilde_ij = np.einsum("...ik,...kj->...ij", agent_i._exp_phi_model, agent_j._exp_neg_phi_model)

            agent_i.Omega_cache[j] = Omega_ij
            agent_i.Omega_tilde_cache[j] = Omega_tilde_ij
            
def preprocess_agent_fields(agent, params):
    """
    Sanitize sigmas, convert to natural parameters, cache Fisher info,
    compute exp(φ), exp(−φ), and inverse Fisher metrics.
    """
   

    # ───── Fetch Lie algebra generators from config ─────
    group_name = config.group_name
    G_q = get_generators(group_name, config.K_q)
    G_p = get_generators(group_name, config.K_p)

    # ───── Sanitize covariance fields ─────
    agent.sigma_q_field = sanitize_sigma(agent.sigma_q_field, eps=config.eta2_min_eigval)
    agent.sigma_p_field = sanitize_sigma(agent.sigma_p_field, eps=config.eta2_min_eigval)

    # ───── Compute exp(φ), exp(−φ) for belief ─────
    agent._exp_phi = exp_lie_algebra_irrep(
        agent.phi,
        G_q,
        group_name=group_name,
        max_norm=config.phi_exp_clip,
        threshold=getattr(config, "phi_exp_threshold", 1e-3),
        n_jobs=-1,
        verbose=False
    )

    # ───── Compute exp(φ_model), exp(−φ_model) for model ─────
    agent._exp_phi_model = exp_lie_algebra_irrep(
        agent.phi_model,
        G_p,
        group_name=group_name,
        max_norm=config.phi_exp_clip,
        threshold=getattr(config, "phi_exp_threshold", 1e-3),
        n_jobs=-1,
        verbose=False
    )
    agent._exp_neg_phi = safe_omega_inv(agent._exp_phi, debug=True)
    agent._exp_neg_phi_model = safe_omega_inv(agent._exp_phi_model, debug=True)

    # ─── Build and cache Omega fields ───
    agent.Omega_cache = {}
    agent.Omega_tilde_cache = {}

    # ───── Optional inverse Fisher metric cache for φ updates ─────
    agent.inverse_fisher_phi = compute_inverse_fisher_field_natural(agent, G_q, field="phi")
    agent.inverse_fisher_phi_model = compute_inverse_fisher_field_natural(agent, G_p, field="phi_model")


def compute_all_gradients(agent_i, agents, generators_q, generators_p, params):
    zero_all_gradients(agent_i)

    
    accumulate_mu_sigma_gradient_belief(agent_i, agents, params)
    accumulate_mu_sigma_gradient_model(agent_i, agents, params)
   
    
    for nb in agent_i.neighbors:
        agent_j = agents[nb["id"]]
        accumulate_phi_gradient_belief(agent_i, agent_j, generators_q, params)
        accumulate_phi_gradient_model(agent_i, agent_j, generators_p, params)
   
    accumulate_phi_gradient_from_morphism_self_and_feedback(
        agent_i, generators_p, generators_q, params
    )
   
    accumulate_phi_tilde_gradient_from_morphism_self_and_feedback(
        agent_i, generators_p, generators_q, params
    )
    
    return (
        (agent_i.grad_mu_q, agent_i.grad_sigma_q),
        (agent_i.grad_mu_p, agent_i.grad_sigma_p),
        agent_i.grad_phi,
        agent_i.grad_phi_tilde,
        agent_i.grad_Phi,
        agent_i.grad_Phi_tilde,
    )



def compute_adaptive_eta(base_eta, grad, cached_kl, sigma_field, scaling_kl, scaling_cond, eta_min):
    """
    Computes adaptive step size η based on KL alignment and condition number proxy of Σ.

    Uses:
        - KL divergence (or grad norm fallback)
        - Condition proxy: trace(Σ) / det(Σ)^{1/K} (safer than cond)

    Returns:
        eta_scaled: clipped η in [eta_min, base_eta]
    """
    eps = 1e-8
    K = sigma_field.shape[-1]

    # KL or fallback to grad norm
    kl_term = (
        np.mean(cached_kl)
        if cached_kl is not None and np.isfinite(np.mean(cached_kl))
        else np.mean(np.abs(grad))
    )

    try:
        # Reshape to (..., K, K)
        Sigma = sigma_field.reshape(-1, K, K)
        traces = np.trace(Sigma, axis1=-2, axis2=-1)            # (...,)
        dets = np.linalg.det(Sigma)                             # (...,)
        dets = np.clip(dets, eps, None)                         # avoid divide by 0
        cond_proxy = traces / (dets ** (1.0 / K))               # (...,)
        cond_avg = np.mean(cond_proxy)
    except Exception:
        cond_avg = 1.0

    denom = 1.0 + scaling_kl * kl_term + scaling_cond * cond_avg
    eta_scaled = base_eta / denom
    return np.clip(eta_scaled, eta_min, base_eta)




def apply_phi_updates(agent, grad_phi, grad_phi_m, mask, params):
    mask_exp = mask[..., None]

    def clip_lie_update(delta, threshold):
        if threshold <= 0:
            return delta
        norm = np.linalg.norm(delta, axis=-1, keepdims=True)
        factor = np.minimum(1.0, threshold / (norm + 1e-8))
        return delta * factor

    # Extract config safely
    cfg = {k: getattr(config, k) for k in dir(config) if not k.startswith("__")}
    if params is not None:
        cfg.update(params)

    # φ adaptive update
    eta_phi_tuned = compute_adaptive_eta(
        cfg["tau_phi"],
        grad_phi,
        getattr(agent, "cached_alignment_kl", None),
        agent.sigma_q_field,
        cfg["eta_phi_adaptive_scaling"],
        cfg["eta_sigma_condition_scaling"],
        cfg["eta_phi_min"],
    )
    delta_phi = eta_phi_tuned * grad_phi
    delta_phi = clip_lie_update(delta_phi, cfg.get("phi_grad_clip_threshold", 0.0))
    delta_phi = np.nan_to_num(delta_phi, nan=0.0, posinf=1e5, neginf=-1e5)
    agent.phi -= delta_phi * mask_exp

    # φ̃ adaptive update
    eta_phi_m_tuned = compute_adaptive_eta(
        cfg["tau_phi_model"],
        grad_phi_m,
        getattr(agent, "cached_model_alignment_kl", None),
        agent.sigma_p_field,
        cfg["eta_phi_model_adaptive_scaling"],
        cfg["eta_sigma_condition_scaling"],
        cfg["eta_phi_model_min"],
    )
    delta_phi_m = eta_phi_m_tuned * grad_phi_m
    delta_phi_m = clip_lie_update(delta_phi_m, cfg.get("phi_model_grad_clip_threshold", 0.0))
    delta_phi_m = np.nan_to_num(delta_phi_m, nan=0.0, posinf=1e5, neginf=-1e5)
    agent.phi_model -= delta_phi_m * mask_exp






def synchronous_step(agents, generators_q, generators_p, params=None, n_jobs=1):
    params = params or {}
    N = len(agents)
    print(f"[DEBUG] Using {n_jobs} workers in synchronous_step")

    tau_mu_belief   = params.get("tau_mu_belief", config.tau_mu_belief)
    tau_sigma_belief = params.get("tau_sigma_belief", config.tau_sigma_belief)
    tau_mu_model    = params.get("tau_mu_model", config.tau_mu_model)
    tau_sigma_model = params.get("tau_sigma_model", config.tau_sigma_model)
    eps = config.eps

    # Step 1: Preprocess φ, φ̃ and exp(·) fields
    Parallel(n_jobs=n_jobs, backend="threading", batch_size=1)(
        delayed(preprocess_agent_fields)(A, params) for A in agents
    )

    # Step 2: Build all Ω caches after φ exponential maps are prepared
    build_all_omega_caches(agents)

    # Step 3: Compute all gradients
    grads = Parallel(n_jobs=n_jobs, backend="loky", batch_size=2)(
        delayed(compute_all_gradients)(agent_i, agents, generators_q, generators_p, params)
        for agent_i in agents
    )
    q_updates, p_updates, phi_grads, phi_m_grads, morphism_grads, morphism_tilde_grads = zip(*grads)
    mask_list = [A.mask for A in agents]

    # ─────────────────────────────────────────────────────────────────────────
    # NEW: helper to refresh exp(φ), exp(φ̃), and updated morphisms
    # Update Φ and Φ̃ after φ, φ̃ changes
    

    # ─────────────────────────────────────────────────────────────────────────

    # Step 4: Apply η and φ updates
    def apply_agent_updates(i):
        agent = agents[i]
        mask = mask_list[i]

        Δη1_q, Δη2_q = q_updates[i]
        Δη1_p, Δη2_p = p_updates[i]

    # Fallback safeguards
        if Δη1_q is None: Δη1_q = np.zeros_like(agent.mu_q_field)
        if Δη2_q is None: Δη2_q = np.zeros_like(agent.sigma_q_field)
        if Δη1_p is None: Δη1_p = np.zeros_like(agent.mu_p_field)
        if Δη2_p is None: Δη2_p = np.zeros_like(agent.sigma_p_field)

        mask_mu    = mask[..., None]
        mask_sigma = mask[..., None, None]

        # Apply μ updates
        q_mu_update = tau_mu_belief   * Δη1_q * mask_mu
        p_mu_update = tau_mu_model    * Δη1_p * mask_mu

        # Apply Σ updates
        q_si_update = tau_sigma_belief * Δη2_q * mask_sigma
        p_si_update = tau_sigma_model  * Δη2_p * mask_sigma

       # print(f"[agent {i}] ‖Δμ_q‖ = {np.linalg.norm(q_mu_update):.2e}, ‖Δμ_p‖ = {np.linalg.norm(p_mu_update):.2e}", flush=True)
       # print(f"[agent {i}] ‖ΔΣ_q‖ = {np.linalg.norm(q_si_update):.2e}, ‖ΔΣ_p‖ = {np.linalg.norm(p_si_update):.2e}", flush=True)

        # Apply μ updates
        agent.mu_q_field += q_mu_update
        agent.mu_p_field += p_mu_update

        # Apply Σ updates (first add deltas)
        sigma_q_new = agent.sigma_q_field + q_si_update
        sigma_p_new = agent.sigma_p_field + p_si_update

        # Sanitize (eigenvalue floor, symmetrize)
        sigma_q_new = sanitize_sigma(sigma_q_new, eps=eps)
        sigma_p_new = sanitize_sigma(sigma_p_new, eps=eps)

        # Clamp trace
        sigma_q_new = clamp_sigma_trace(sigma_q_new, max_trace=1e2)
        sigma_p_new = clamp_sigma_trace(sigma_p_new, max_trace=1e2)
    
        # Assign
        agent.sigma_q_field = sigma_q_new
        agent.sigma_p_field = sigma_p_new
      #  print(f"[agent {i}] ‖μ_q‖ = {np.linalg.norm(agent.mu_q_field):.2e}, ‖μ_p‖ = {np.linalg.norm(agent.mu_p_field):.2e}", flush=True)
      #  print(f"[agent {i}] ‖Σ_q‖ = {np.linalg.norm(agent.sigma_q_field):.2e}, ‖Σ_p‖ = {np.linalg.norm(agent.sigma_p_field):.2e}", flush=True)

        # φ and φ̃ updates
        apply_phi_updates(agent, phi_grads[i], phi_m_grads[i], mask, params)
        agent.phi       = soft_clip_phi_norm(agent.phi, max_norm=np.pi)
        agent.phi_model = soft_clip_phi_norm(agent.phi_model, max_norm=np.pi)

        print(f"[agent {i}] ‖φ‖ = {np.linalg.norm(agent.phi):.2e}, ‖φ̃‖ = {np.linalg.norm(agent.phi_model):.2e}", flush=True)

    # Update morphisms
        agent.bundle_morphism_q_to_p, agent.bundle_morphism_p_to_q = compute_direct_morphisms(
            phi=agent.phi,
            phi_model=agent.phi_model,
            generators_q=agent.generators_q,
        generators_p=agent.generators_p,
        Phi_0=agent.Phi_0,
        Phi_tilde_0=agent.Phi_tilde_0,
        )


                # ─── Descent test ────────────────────────────────────────────────
        if params.get("debug_energy_descent", False):
            from copy import deepcopy
            eta_test = 1e-4

            agent_copy = deepcopy(agent)
            E_before = compute_total_energy(agent_copy, agents, params)

            # Apply one test step of gradient descent manually
            agent_copy.mu_q_field -= eta_test * q_mu_update
            agent_copy.mu_p_field -= eta_test * p_mu_update
            agent_copy.sigma_q_field = sanitize_sigma(agent_copy.sigma_q_field - eta_test * q_si_update, eps=eps)
            agent_copy.sigma_p_field = sanitize_sigma(agent_copy.sigma_p_field - eta_test * p_si_update, eps=eps)

            E_after = compute_total_energy(agent_copy, agents, params)
            dE = E_after - E_before

            print(f"[agent {i}] ΔE (descend test) = {dE:.3e}  {'✅' if dE < 0 else '❌'}", flush=True)


        return agent


    Parallel(n_jobs=n_jobs, backend="threading", batch_size="auto")(
        delayed(apply_agent_updates)(i) for i in range(N)
    )

    # Step 5: Refresh cached KL fields for animation and analysis
    for A in agents:
        A.cached_alignment_kl       = compute_alignment_field_general(agents, A.id, field_type="belief", log_eps=eps)
        A.cached_model_alignment_kl = compute_alignment_field_general(agents, A.id, field_type="model", log_eps=eps)

    return agents

def clamp_sigma_trace(sigma, max_trace=1e2, eps=1e-8):
    trace = np.trace(sigma, axis1=-2, axis2=-1)  # (...,)
    scale = np.minimum(1.0, max_trace / (trace + eps))[..., None, None]
    return sigma * scale

def compute_total_energy(agent_i, agents, params=None, use_fields=None):
    """
    Compute total variational energy for agent_i:
        F = α·KL(q_i || Φ̃ p_i) +
            λ·KL(p_i || Φ q_i) +
            β·Σ_j KL(q_i || Ω_ij q_j) +
            β̃·Σ_j KL(p_i || Ω̃_ij p_j)

    Args:
        agent_i     : the agent whose energy we compute
        agents      : full agent list (used for neighbors)
        params      : override config (optional)
        use_fields  : optional override of (mu_q, sigma_q) instead of using agent fields

    Returns:
        scalar energy (float)
    """
    cfg = config if params is None else {**vars(config), **params}
    eps = cfg.get("eps", 1e-8)

    α    = cfg.get("alpha", 1.0)
    λ    = cfg.get("feedback_weight", 1.0)
    β    = cfg.get("beta", 1.0)
    β̃   = cfg.get("beta_model", 1.0)

    if use_fields is not None:
        assert isinstance(use_fields, tuple) and len(use_fields) == 2
        mu_q, sigma_q = use_fields
    else:
        mu_q     = agent_i.mu_q_field
        sigma_q  = agent_i.sigma_q_field

    mu_p     = agent_i.mu_p_field
    sigma_p  = agent_i.sigma_p_field
    Φ̃       = agent_i.bundle_morphism_p_to_q  # maps p → q
    Φ        = agent_i.bundle_morphism_q_to_p  # maps q → p

    # ───── Self: KL(q || Φ̃·p) ─────
    mu_p_proj = np.einsum("...ij,...j->...i", Φ̃, mu_p)
    sigma_p_proj = np.einsum("...ik,...kl,...jl->...ij", Φ̃, sigma_p, Φ̃)
    sigma_q = sanitize_sigma(sigma_q, eps=eps)
    sigma_p_proj = sanitize_sigma(sigma_p_proj, eps=eps)

    Δμ_q = mu_q - mu_p_proj
    inv_proj = safe_inv(sigma_p_proj, eps=eps)
    kl_q_p = 0.5 * (
        np.einsum("...i,...ij,...j->...", Δμ_q, inv_proj, Δμ_q) +
        np.einsum("...ii->...", inv_proj @ sigma_q) -
        np.log(np.clip(np.linalg.det(sigma_q) / np.linalg.det(sigma_p_proj), eps, None)) -
        mu_q.shape[-1]
    )

    # ───── Feedback: KL(p || Φ·q) ─────
    mu_q_push = np.einsum("...ij,...j->...i", Φ, mu_q)
    sigma_q_push = np.einsum("...ik,...kl,...jl->...ij", Φ, sigma_q, Φ)
    sigma_p = sanitize_sigma(sigma_p, eps=eps)
    sigma_q_push = sanitize_sigma(sigma_q_push, eps=eps)

    Δμ_p = mu_p - mu_q_push
    inv_qpush = safe_inv(sigma_q_push, eps=eps)
    kl_p_q = 0.5 * (
        np.einsum("...i,...ij,...j->...", Δμ_p, inv_qpush, Δμ_p) +
        np.einsum("...ii->...", inv_qpush @ sigma_p) -
        np.log(np.clip(np.linalg.det(sigma_p) / np.linalg.det(sigma_q_push), eps, None)) -
        mu_p.shape[-1]
    )

    # ───── Alignment: KL(q || Ω_ij q_j) ─────
    align_q = 0.0
    for nb in agent_i.neighbors:
        j = nb["id"]
        agent_j = agents[j]
        Ω_ij = agent_i.Omega_cache[j]

        mu_j = agent_j.mu_q_field
        sigma_j = sanitize_sigma(agent_j.sigma_q_field, eps=eps)

        mu_j_push = np.einsum("...ij,...j->...i", Ω_ij, mu_j)
        sigma_j_push = np.einsum("...ik,...kl,...jl->...ij", Ω_ij, sigma_j, Ω_ij)
        sigma_j_push = sanitize_sigma(sigma_j_push, eps=eps)
        inv_jpush = safe_inv(sigma_j_push, eps=eps)

        Δμ = mu_q - mu_j_push
        kl_q_qj = 0.5 * (
            np.einsum("...i,...ij,...j->...", Δμ, inv_jpush, Δμ) +
            np.einsum("...ii->...", inv_jpush @ sigma_q) -
            np.log(np.clip(np.linalg.det(sigma_q) / np.linalg.det(sigma_j_push), eps, None)) -
            mu_q.shape[-1]
        )
        align_q += kl_q_qj

    # ───── Model alignment: KL(p || Ω̃_ij p_j) ─────
    align_p = 0.0
    for nb in agent_i.neighbors:
        j = nb["id"]
        agent_j = agents[j]
        Ωt_ij = agent_i.Omega_tilde_cache[j]

        mu_j = agent_j.mu_p_field
        sigma_j = sanitize_sigma(agent_j.sigma_p_field, eps=eps)

        mu_j_push = np.einsum("...ij,...j->...i", Ωt_ij, mu_j)
        sigma_j_push = np.einsum("...ik,...kl,...jl->...ij", Ωt_ij, sigma_j, Ωt_ij)
        sigma_j_push = sanitize_sigma(sigma_j_push, eps=eps)
        inv_jpush = safe_inv(sigma_j_push, eps=eps)

        Δμ = mu_p - mu_j_push
        kl_p_pj = 0.5 * (
            np.einsum("...i,...ij,...j->...", Δμ, inv_jpush, Δμ) +
            np.einsum("...ii->...", inv_jpush @ sigma_p) -
            np.log(np.clip(np.linalg.det(sigma_p) / np.linalg.det(sigma_j_push), eps, None)) -
            mu_p.shape[-1]
        )
        align_p += kl_p_pj

    # ───── Total Energy ─────
    energy = α * kl_q_p + λ * kl_p_q + β * align_q + β̃ * align_p
    return float(np.mean(energy))
