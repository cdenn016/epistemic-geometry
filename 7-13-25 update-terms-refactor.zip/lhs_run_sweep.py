# -*- coding: utf-8 -*-
"""
Run Latin Hypercube parameter sweep over multiple odd K values and output both individual results and a consolidated CSV of sampled parameters.
"""
import os
import numpy as np
import pickle
import pandas as pd
from scipy.stats import qmc
from generalized_simulation import run_simulation

DEFAULT_SAMPLES = 10  # Number of successful runs to obtain

# --- Base simulation parameters ---
base_params = {
    "group_name": "sl2r",
    "N": 3,
    "L": 15,
    "steps": 100,
    "debug": True,
}

def get_scaled_sweep_params(K):
    return {
        "alpha":                           (0.05,     10),                   
        "beta":                            (1 ,       50),      
        "gauge_weight":                    (5,      1000),
        "model_align_weight":              (5,      1000),
        "model_mass_weight":               (5,      1000),
        "model_feedback_weight":           (0,        10),                
        "phi_phi_tilde_coupling":          (5 ,     1000),
        "model_curvature_weight":          (5,      1000),
        "curvature_weight":                (5,      1000),
    }

def is_unstable(metrics, clip_threshold=50, energy_thresh=1e6, min_kl_thresh=-1e-5):
    if not metrics:
        return True

    # Track monotonicity of KL-related terms
    kl_keys = [k for k in metrics[0].keys() if "kl" in k.lower()]
    prev_vals = {k: metrics[0].get(k, 0) for k in kl_keys}

    for step in metrics:
        if any(np.isnan(v) or np.isinf(v) for v in step.values()):
            return True
        if step.get("energy_total", 0) > energy_thresh:
            return True
        clips = step.get("sanitize_clipped", 0)
        if clips > clip_threshold:
            return True

        for k in step:
            if "kl" in k.lower():
                if step[k] < min_kl_thresh:
                    return True
                # KL divergence increasing over time?
                if step[k] > prev_vals[k] + 1e-3:  # Allow tiny fluctuations
                    print(f"[REJECT] KL term '{k}' increased: {prev_vals[k]:.4f} --> {step[k]:.4f}")
                    return True
                prev_vals[k] = step[k]

    return False

def run_lhs_sweep_for_K(K, n_samples=DEFAULT_SAMPLES):
    base_params_K = dict(base_params)
    base_params_K["K"] = K

    output_dir = f"lhs_results_K{K}"
    csv_path = f"lhs_samples_K{K}.csv"

    os.makedirs(output_dir, exist_ok=True)
    sweep_params = get_scaled_sweep_params(K)
    param_names = list(sweep_params)
    ranges = [sweep_params[k] for k in param_names]
    sampler = qmc.LatinHypercube(d=len(ranges))
    attempted_rows = set()

    sweep_spec_path = os.path.join(output_dir, "sweep_spec.pkl")
    with open(sweep_spec_path, "wb") as f:
        pickle.dump({"param_names": param_names, "ranges": sweep_params}, f)

    all_params = []
    attempt_id = 0
    max_retries = 5

    while len(all_params) < n_samples:
        raw_sample = sampler.random(n=1)[0]
        sample_key = tuple(raw_sample.round(decimals=6))
        if sample_key in attempted_rows:
            continue
        attempted_rows.add(sample_key)

        row = qmc.scale([raw_sample], [lo for lo, hi in ranges], [hi for lo, hi in ranges])[0]
        sampled_params = dict(zip(param_names, row))

        attempt = 0
        success = False

        while attempt < max_retries and not success:
            entry = dict(base_params_K)
            entry.update(sampled_params)
            run_name = f"run_{attempt_id}_try{attempt}"
            subdir = os.path.join(output_dir, run_name)
            os.makedirs(subdir, exist_ok=True)

            print(f"\n[TRY {attempt}] {run_name} → {sampled_params}")
            try:
                agents, metrics = run_simulation(
                    outdir=subdir,
                    resume=False,
                    log_metrics=True,
                    log_fields=True,
                    num_cores=-1,
                    params=entry,
                )

                with open(os.path.join(subdir, "final_agents.pkl"), "wb") as f:
                    pickle.dump(agents, f)
                with open(os.path.join(subdir, "final_metrics.pkl"), "wb") as f:
                    pickle.dump(metrics, f)
                with open(os.path.join(subdir, "params.pkl"), "wb") as f:
                    pickle.dump(entry, f)

                log_path = os.path.join(subdir, "metric_log.pkl")
                if os.path.exists(log_path):
                    with open(log_path, "rb") as f:
                        metric_log = pickle.load(f)
                else:
                    metric_log = []

                if is_unstable(metric_log):
                    print(f"[REJECT] {run_name} failed stability check.")
                    attempt += 1
                    continue

                print(f"[✓] {run_name} accepted.")
                all_params.append(entry)
                attempt_id += 1
                success = True

            except Exception as e:
                print(f"[ERROR] {run_name} crashed: {e}")
                attempt += 1

        if not success:
            print(f"[✗] Abandoned sample after {max_retries} failed attempts.")

    df = pd.DataFrame(all_params)
    df.to_csv(csv_path, index=False)
    print(f"\n[DONE] CSV written → {csv_path}")
    print(f"[DONE] LHS sweep for K={K} finished with {len(all_params)} valid runs.")

def main():
    odd_K_values = [9, 11, 13]
    for K in odd_K_values:
        print(f"\n{'='*40}\n[SWEEP] Running for K={K}\n{'='*40}")
        run_lhs_sweep_for_K(K)

if __name__ == "__main__":
    main()