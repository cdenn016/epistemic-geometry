import numpy as np
from generalized_agent_schema import Agent

from generalized_omega import (
    exp_lie_algebra_irrep,
    )


from find_agent_chains import construct_spatial_path_nd
from generalized_math_utils import kl_divergence
from config import spatial_resolution
from scipy.ndimage import gaussian_filter

from config import spatial_resolution  # Defaults to 1.0

from scipy.linalg import solve

def compute_intra_agent_omega(phi, c0, c1, generators, linearize_threshold=1e-5):
    delta_phi = phi[c0] - phi[c1]
    if np.linalg.norm(delta_phi) < linearize_threshold:
        return exp_lie_algebra_irrep(delta_phi[None], generators)[0]
    else:
        g0 = exp_lie_algebra_irrep(phi[c0][None], generators)[0]
        g1 = exp_lie_algebra_irrep(phi[c1][None], generators)[0]
        return np.linalg.solve(g1, g0)

def compute_inter_agent_omega_at_point(phi_i, phi_j, c, generators, use_commutator=False, warn_if_linear=False):
    import config
    phi_i_vec = phi_i[c]
    phi_j_vec = phi_j[c]
    delta = phi_i_vec - phi_j_vec

    e = getattr(config, "e", 1.0)

    if warn_if_linear and np.linalg.norm(delta) < 1e-6:
        print(f"[DEBUG] Small φ difference at {c}: consider using linearized transport.")

    Phi_i = exp_lie_algebra_irrep(phi_i_vec[None]/e, generators)[0]
    Phi_j_neg = exp_lie_algebra_irrep((-phi_j_vec)[None]/e, generators)[0]
    return Phi_i @ Phi_j_neg


def compute_inter_agent_omega(phi_i, phi_j, c, generators, use_commutator=False):
    """
    Compute Ω_{ij}(c) for non-abelian G:
       Ω = exp(phi_i/e) · exp(-phi_j/e)
    Always use the two-exp form to avoid matrix inverses.
    """
    import config
    # Extract the Lie-algebra vectors at c (if c is not used, ignore it)
    φi = phi_i if phi_i.ndim>1 else phi_i[None]
    φj = phi_j if phi_j.ndim>1 else phi_j[None]

    # coupling constant
    e = getattr(config, "e", 1.0)

    # scale and exponentiate separately
    A = (φi / e)
    B = (-φj / e)
    Phi_i   = exp_lie_algebra_irrep(A, generators)
    Phi_j_neg = exp_lie_algebra_irrep(B, generators)

    # multiply group elements
    Ω = np.matmul(Phi_i, Phi_j_neg)
    return Ω

def transport_belief_spatially(phi_field, c0, c1, generators, use_commutator=False):
    """
    Compute intra-agent spatial transport operator T_{c0→c1} using non-Abelian φ field.

    Args:
        phi_field: φ tensor of shape (S₁, ..., S_D, d)
        c0, c1: spatial indices (tuples)
        generators: array of shape (d, K, K), Lie algebra generators
        use_commutator: if True, use BCH commutator correction for exp(A)exp(-B)

    Returns:
        Omega: matrix of shape (K, K) transporting from c0 to c1
    """
    from generalized_omega import exp_lie_algebra_irrep
   
    # Extract local phi values
    phi0 = phi_field[c0]  # shape (d,)
    phi1 = phi_field[c1]

    # Compute exponentials separately for non-Abelian group
    # Omega = exp(phi1) @ exp(-phi0)
    Omega1 = exp_lie_algebra_irrep(phi1[None], generators)[0]
    Omega0 = exp_lie_algebra_irrep((-phi0)[None], generators)[0]
    Omega = Omega1 @ Omega0

    if use_commutator:
        # optional BCH correction: exp(B)exp(-A) ≈ exp(B - A + 1/2 [B, A])
        delta = phi1 - phi0
        # compute commutator correction term
        # com = 0.5 * (phi1_i phi0_j - phi0_i phi1_j) [generators_i, generators_j]
        # Here we approximate by adding half commutator of the Lie algebra elements
        # (for small phi differences)
        # could implement full BCH if needed
        # For now, note: commutator form placeholder
        pass

    return Omega



def transport_belief_over_chain(
    agents,
    path,
    overlap_points,
    generators,
    domain_size,
    fiber_key='q',      # or 'p'
    phi_key='phi',      # or 'phi_model'
    fixed_start=None,
    fixed_end=None,
    config=None,
    injection_mode="from_q",
):
    from scipy.ndimage import gaussian_filter
    import numpy as np

    D = len(domain_size)
    K = getattr(agents[0], fiber_key).shape[-1]
    A = agents[path[0]]
    B = agents[path[-1]]

    if fixed_start is not None:
        c_0 = fixed_start
    else:
        c_0 = tuple(np.array(domain_size) // 2)

    # --- Injection setup ---
    if injection_mode == "from_q":
        f = A.q[c_0].copy()
    elif injection_mode == "from_p":
        f = A.p[c_0].copy()
    elif injection_mode == "gaussian":
        x = np.arange(K)
        center = K // 2
        sigma = K / 10
        f = np.exp(-0.5 * ((x - center) / sigma) ** 2)
    elif injection_mode == "delta":
        f = np.zeros(K)
        f[K // 2] = 1.0
    else:
        raise ValueError(f"Unknown injection_mode: {injection_mode}")

    f = np.clip(f, 1e-8, 1.0)
    f /= np.sum(f)

    full_path_coords = []
    kl_path_fine = []
    kl_path_coarse = []
    q_sequence = [f.copy()]

    for k in range(len(path) - 1):
        id_a = path[k]
        id_b = path[k + 1]
        agent_a = agents[id_a]
        agent_b = agents[id_b]

        c_a = c_0 if k == 0 else overlap_points[k - 1]
        c_ab = overlap_points[k]

        # --- Intra-agent transport ---
        path_segment = construct_spatial_path_nd(c_a, c_ab, domain_size, mask=agent_a.mask)
        for p0, p1 in zip(path_segment[:-1], path_segment[1:]):
            omega = compute_intra_agent_omega(agent_a.phi, p0, p1, generators, use_commutator=False)
            
            #print(f"[Ω] ∥Ω_{p0}->{p1} - I∥ = {np.linalg.norm(omega - np.eye(K)):.4f}")

            f = omega @ f
            f = np.clip(f, 1e-8, 1.0); f /= np.sum(f)
            target = getattr(agent_a, fiber_key)[p1]
            kl_path_fine.append(kl_divergence(f, target))
            q_sequence.append(f.copy())

        # --- Inter-agent jump ---
        omega_ab = compute_inter_agent_omega(agent_a.phi, agent_b.phi, c_ab, generators, use_commutator=False)
        f = omega_ab @ f
        f = np.clip(f, 1e-8, 1.0); f /= np.sum(f)
        target = getattr(agent_b, fiber_key)[c_ab]
        kl_path_coarse.append(kl_divergence(f, target))
        q_sequence.append(f.copy())

        full_path_coords.extend(path_segment)
        c_0 = c_ab

    # --- Gauge-covariant injection ---
    c_final = fixed_end if fixed_end else c_0
    delta = np.zeros(domain_size)
    delta[c_final] = 1.0
    smoothed = gaussian_filter(delta, sigma=getattr(config, "injection_smooth_sigma", 2))
    target_mask = smoothed > 1e-5

    for index in zip(*np.where(target_mask)):
        omega = compute_intra_agent_omega(B.phi, c_final, index, generators, use_commutator=False)
        transported_f = omega @ f
        transported_f = np.clip(transported_f, 1e-8, 1.0)
        transported_f /= np.sum(transported_f)
        getattr(B, fiber_key)[index] += transported_f * smoothed[index]

    B_mask = gaussian_filter(delta, sigma=getattr(config, "mask_update_sigma", 0.8))
    B.mask = np.maximum(B.mask, B_mask)

    #print("Injected q before normalization:", getattr(B, fiber_key)[c_final])


    field = getattr(B, fiber_key)
    field = np.clip(field, 1e-8, 1.0)
    field /= np.sum(field, axis=-1, keepdims=True) + 1e-8
    setattr(B, fiber_key, field)

    return agents, {
        "kl_path_coarse": kl_path_coarse,
        "kl_path_fine": kl_path_fine,
        "final_point": c_final,
        "path_indices": path,
        "path_coords": full_path_coords,
        "q_sequence": q_sequence,
        "q_initial": q_sequence[0],
        "q_final": q_sequence[-1],
    }


def compute_total_path_length(path_coords):
    """
    Compute the total physical length of a path through space,
    applying optional spatial scaling (per voxel = spatial_resolution).

    Parameters:
    - path_coords: list of coordinate tuples [(x0,y0,...), (x1,y1,...), ...]
    Returns:
    - total_length: float, scaled path length
    """
    if not path_coords or len(path_coords) < 2:
        return 0.0

    deltas = np.diff(np.array(path_coords), axis=0)
    distances = np.linalg.norm(deltas, axis=1)
    return spatial_resolution * np.sum(distances)

def log_transport_summary(info_dict, config=None):
    path = info_dict.get("full_path", [])
    step_count = len(path)

    if config is not None and hasattr(config, "spatial_resolution"):
        dx = config.spatial_resolution
    else:
        dx = 1.0  # default to 1 unit per step

    total_length = dx * step_count
    print(f"[TRANSPORT] Path steps: {step_count}, Spatial resolution: {dx}, Total path length: {total_length:.2f}")






