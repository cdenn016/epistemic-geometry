import os
import glob
import pickle
import random

import numpy as np
import matplotlib.pyplot as plt
import imageio

from config import domain_size, checkpoint_dir
from find_agent_chains import construct_spatial_path_nd


def animate_belief_seq(diagnostics_path, output_gif, fps=5, figsize=(6,4), ymax=1.1):
    """
    Create a bar-chart GIF of the belief sequence from diagnostics.
    """
    # ensure output directory exists
    out_dir = os.path.dirname(output_gif)
    if out_dir:
        os.makedirs(out_dir, exist_ok=True)

    # load belief sequence
    with open(diagnostics_path, 'rb') as f:
        diag = pickle.load(f)
    belief_seq = diag['belief_seq']
    K = belief_seq[0].shape[0]

    # prepare frames
    tmpdir = os.path.join(out_dir, '_frames')
    os.makedirs(tmpdir, exist_ok=True)
    frames = []

    for idx, b in enumerate(belief_seq):
        fig, ax = plt.subplots(figsize=figsize)
        ax.bar(np.arange(K), b)
        ax.set_ylim(0, ymax)
        ax.set_title(f"Step {idx}")
        ax.set_xlabel("Component")
        ax.set_ylabel("Belief")
        frame_path = os.path.join(tmpdir, f"frame_{idx:04d}.png")
        fig.tight_layout()
        fig.savefig(frame_path)
        plt.close(fig)
        frames.append(frame_path)

    # write GIF
    with imageio.get_writer(output_gif, mode='I', fps=fps) as writer:
        for frame in frames:
            img = imageio.imread(frame)
            writer.append_data(img)

    # cleanup
    for frame in frames:
        os.remove(frame)
    os.rmdir(tmpdir)
    print(f"Saved animation: {output_gif}")


def visualize_path_on_mask(diag_folder, agent_index=0, cmap='Greys', path_color='red', alpha=0.5):
    """
    Overlay a spatial loop path on the agent's mask.
    """
    # load diagnostics
    diag_path = os.path.join(diag_folder, 'diagnostics.pkl')
    with open(diag_path, 'rb') as f:
        diag = pickle.load(f)
    coords = diag['path_coords']
    step   = diag['step']

    # load agents from checkpoint
    chkpt = os.path.join(checkpoint_dir, f"step_{step:04d}.pkl")
    with open(chkpt, 'rb') as f:
        agents = pickle.load(f)
    mask = agents[agent_index].mask

    # plot overlay
    fig, ax = plt.subplots(figsize=(6,6))
    ax.imshow(mask.T, origin='lower', cmap=cmap, alpha=alpha)
    xs, ys = zip(*coords)
    ax.plot(xs, ys, color=path_color, linewidth=2)
    ax.scatter(xs, ys, color=path_color, s=20)
    ax.set_title(f"Spatial loop (step {step})")
    ax.axis('off')
    plt.show()


def visualize_cycle_overlay(diag_folder, mask_colors=None, cmap='Greys', path_color='red', alpha=0.3, linewidth=2):
    """
    Overlay all agent masks and the full transport path for one agent-cycle.
    """
    # load diagnostics
    diag_path = os.path.join(diag_folder, 'diagnostics.pkl')
    with open(diag_path, 'rb') as f:
        diag = pickle.load(f)
    cycle       = diag['cycle']
    transport_path = diag['transport_path']
    step        = diag['step']

    # load agents
    chkpt = os.path.join(checkpoint_dir, f"step_{step:04d}.pkl")
    with open(chkpt, 'rb') as f:
        agents = pickle.load(f)

    xs, ys = zip(*transport_path)

    # default mask colors
    if mask_colors is None:
        mask_colors = {aid: f"C{idx}" for idx, aid in enumerate(cycle[:-1])}

    fig, ax = plt.subplots(figsize=(6,6))
    for aid in cycle[:-1]:
        mask = (agents[aid].mask > agents[aid].mask.max()*0.01)
        ax.contour(mask.T.astype(float), levels=[0.5], colors=mask_colors.get(aid,'k'), alpha=alpha, linewidths=2)

    ax.plot(xs, ys, color=path_color, linewidth=linewidth)
    ax.scatter(xs, ys, color=path_color, s=10)
    ax.set_title(f"Agent-cycle {cycle} at step {step}")
    ax.axis('off')
    plt.tight_layout()
    plt.show()


def main(max_cycles=3, max_spatial=3, fps=3):
    # Agent-cycle animations and overlays
    latest = {}
    for dp in glob.glob("holonomy_runs/agent/*/diagnostics.pkl"):
        cid, step_str = os.path.basename(os.path.dirname(dp)).rsplit("_",1)
        try:
            step = int(step_str)
        except:
            continue
        prev = latest.get(cid)
        if prev is None or step > prev[0]:
            latest[cid] = (step, dp)

    sampled = random.sample(list(latest.items()), min(len(latest), max_cycles))
    for cid, (_, dp) in sampled:
        print(f"Animating cycle {cid}")
        gif = os.path.join("holonomy_animations", f"belief_{cid}.gif")
        animate_belief_seq(dp, gif, fps=fps)
        visualize_cycle_overlay(os.path.dirname(dp))

    # Spatial overlays
    spatial = glob.glob("holonomy_runs/spatial/*")
    sampled_sp = random.sample(spatial, min(len(spatial), max_spatial))
    for folder in sampled_sp:
        print(f"Visualizing spatial loop {folder}")
        visualize_path_on_mask(folder)


if __name__ == '__main__':
    main()
