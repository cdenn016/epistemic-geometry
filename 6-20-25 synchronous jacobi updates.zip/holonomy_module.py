# -*- coding: utf-8 -*-
"""
Created on Tue Jun 17 16:26:21 2025

@author: chris and christine
"""

'''
holonomy_module.py

Module to compute gauge holonomy within a single agent (spatial loops) and across agents (agent-chain loops).
'''

import numpy as np
from transport_operator import compute_intra_agent_omega, compute_inter_agent_omega_at_point, transport_belief_spatially
import random
from config import domain_size, support_cutoff_eps
from scipy.linalg import logm, expm, norm

import time
from find_agent_chains import construct_spatial_path_nd

def compute_spatial_loop_holonomy(
    agent,
    coords,
    generators,
    use_commutator=False,
    return_deviations=False,
    return_beliefs=False,
    initial_belief=None
):
    """
    Compute holonomy around a closed spatial loop within a single agent,
    by multiplying successive intra-agent frame maps and re-orthonormalizing
    at each step to prevent overflow/NaNs. Optionally track belief propagation.

    Parameters:
        agent:           Agent object with `.phi` and `.mask`, plus `.q` for beliefs
        coords:          list of grid-coordinate tuples (first == last)
        generators:      array of shape (lie_dim, K, K)
        use_commutator:  unused here (kept for API consistency)
        return_deviations: whether to return stepwise ∥ω − I∥ norms
        return_beliefs:  whether to return the belief sequence
        initial_belief:  np.ndarray of shape (K,) required if return_beliefs=True

    Returns:
        H: np.ndarray (K×K) total holonomy
        deviations (optional): list of ∥ω − I∥ per step
        beliefs (optional): list of belief vectors at each micro-step
    """
    from transport_operator import compute_intra_agent_omega
    import numpy as np
    from scipy.linalg import logm, expm, norm

    if len(coords) < 2 or coords[0] != coords[-1]:
        raise ValueError("coords must start and end at the same point")

    K = generators.shape[-1]
    H = np.eye(K, dtype=float)
    deviations = []
    beliefs = []

    # initialize belief tracking
    if return_beliefs:
        if initial_belief is None:
            raise ValueError("initial_belief must be provided when return_beliefs=True")
        b = initial_belief.copy()
        beliefs.append(b.copy())

    # iterate along the loop
    for p0, p1 in zip(coords[:-1], coords[1:]):
        ω = compute_intra_agent_omega(agent.phi, p0, p1, generators)
        H = ω @ H

        if return_deviations:
            deviations.append(np.linalg.norm(ω - np.eye(K)))

        if return_beliefs:
            b = ω @ b
            # renormalize if needed (e.g., for probabilities)
            b = np.clip(b, 1e-8, None)
            b /= b.sum()
            beliefs.append(b.copy())

        # re-orthonormalize H
        U, _, Vt = np.linalg.svd(H, full_matrices=False)
        H = U @ Vt

    # logm check (optional, can be removed if noisy)
    try:
        logH = logm(H)
        err = norm(expm(logH) - H)
        print(f"[Spatial: Holonomy logm error] ‖exp(logH)-H‖ = {err:.2e}")
    except Exception:
        pass

    # return based on flags
    outputs = [H]
    if return_deviations:
        outputs.append(deviations)
    if return_beliefs:
        outputs.append(beliefs)

    return tuple(outputs) if len(outputs) > 1 else H



import time
import numpy as np
from scipy.linalg import logm
from transport_operator import compute_intra_agent_omega, compute_inter_agent_omega_at_point
from find_agent_chains import construct_spatial_path_nd
from config import domain_size

def compute_agent_cycle_holonomy(
    agents,
    agent_cycle,
    overlap_points,
    generators,
    initial_belief=None,
    return_deviations=False,
    return_logm=False,
    return_beliefs=False,
    return_path=False,
    use_commutator=False,
):
    """
    Compute non-Abelian holonomy around a closed loop of agents,
    optionally tracking belief propagation & returning the full spatial path.

    Returns:
      If return_beliefs & return_path:
        H, deviations, logH?, beliefs, path
      etc.
    """
    # Validate inputs
    if len(agent_cycle) < 2 or agent_cycle[0] != agent_cycle[-1]:
        raise ValueError("agent_cycle must start and end at the same agent")
    if len(overlap_points) != len(agent_cycle) - 1:
        raise ValueError("Mismatch between cycle and overlap points")

    K = generators.shape[-1]
    H = np.eye(K, dtype=float)
    deviations = []
    beliefs = []
    full_path = []

    # Initialize
    current_agent = agent_cycle[0]
    current_pos   = tuple(agents[current_agent].center)
    if return_beliefs:
        if initial_belief is None:
            raise ValueError("initial_belief must be provided when return_beliefs=True")
        b = initial_belief.copy()
        b = np.clip(b,1e-12,None)
        b = b / b.sum()
        beliefs.append(b.copy())
    if return_path:
        full_path.append(current_pos)

    # Loop each leg
    for next_agent, overlap_pt in zip(agent_cycle[1:], overlap_points):
        # spatial micro-steps
        path = construct_spatial_path_nd(current_pos, overlap_pt, domain_size,
                                        mask=agents[current_agent].mask)
        for p0, p1 in zip(path[:-1], path[1:]):
            ω = compute_intra_agent_omega(agents[current_agent].phi, p0, p1, generators)
            H = ω @ H
            if return_deviations:
                deviations.append(np.linalg.norm(ω - np.eye(K)))
            if return_beliefs:
                b = ω @ b
                b = np.clip(b,1e-12,None); b = b / b.sum()
                beliefs.append(b.copy())
            if return_path:
                full_path.append(p1)
            # re-orthonormalize
            U, _, Vt = np.linalg.svd(H, full_matrices=False)
            H = U @ Vt

        # gauge hop
        Ω = compute_inter_agent_omega_at_point(
            agents[current_agent].phi,
            agents[next_agent].phi,
            overlap_pt,
            generators,
            use_commutator
        )
        H = Ω @ H
        if return_deviations:
            deviations.append(np.linalg.norm(Ω - np.eye(K)))
        if return_beliefs:
            b = Ω @ b
            b = np.clip(b,1e-12,None); b = b / b.sum()
            beliefs.append(b.copy())
        if return_path:
            full_path.append(overlap_pt)
        U, _, Vt = np.linalg.svd(H, full_matrices=False)
        H = U @ Vt

        # advance
        current_agent = next_agent
        current_pos   = overlap_pt

    # final leg back to start
    start_center = tuple(agents[agent_cycle[0]].center)
    path = construct_spatial_path_nd(current_pos, start_center, domain_size,
                                    mask=agents[agent_cycle[0]].mask)
    for p0, p1 in zip(path[:-1], path[1:]):
        ω = compute_intra_agent_omega(agents[agent_cycle[0]].phi, p0, p1, generators)
        H = ω @ H
        if return_deviations:
            deviations.append(np.linalg.norm(ω - np.eye(K)))
        if return_beliefs:
            b = ω @ b
            b = np.clip(b,1e-12,None); b = b / b.sum()
            beliefs.append(b.copy())
        if return_path:
            full_path.append(p1)
        U, _, Vt = np.linalg.svd(H, full_matrices=False)
        H = U @ Vt

    logH = logm(H) if return_logm else None

    # collect outputs
    outputs = [H]
    if return_deviations:
        outputs.append(deviations)
    if return_logm:
        outputs.append(logH)
    if return_beliefs:
        outputs.append(beliefs)
    if return_path:
        outputs.append(full_path)
    return tuple(outputs) if len(outputs)>1 else H


def sample_self_avoiding_loop_within_mask(
    center,
    mask,
    *,
    min_length=4,
    max_length=1000,
    support_cutoff=support_cutoff_eps,
    seed=None
):
    """
    Generate a random self‐avoiding closed loop on a periodic grid,
    staying entirely where mask >= support_cutoff.
    """
    D = len(domain_size)
    rng = random.Random(seed)

    while True:
        visited = {tuple(center)}
        path = [tuple(center)]
        current = np.array(center, dtype=int)
        prev = None

        for _ in range(max_length):
            neighbors = []
            for axis in range(D):
                for d in (-1, +1):
                    nb = list(current)
                    nb[axis] = (nb[axis] + d) % domain_size[axis]
                    nb = tuple(nb)
                    if np.all(mask[nb] >= support_cutoff):
                        neighbors.append(nb)

            if tuple(center) in neighbors and len(path) >= min_length:
                path.append(tuple(center))
                return path

            candidates = [nb for nb in neighbors if nb != prev and nb not in visited]
            if not candidates:
                break

            nxt = rng.choice(candidates)
            prev = tuple(current.tolist())
            current = np.array(nxt, dtype=int)
            visited.add(nxt)
            path.append(nxt)

        continue
