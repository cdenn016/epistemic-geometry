import numpy as np

import sys

def set_config_from_params(params):
    this_module = sys.modules[__name__]
    for k, v in params.items():
        setattr(this_module, k, v)

agent_seed =18

# --- Simulation Parameters ---
steps = 150
domain_size = (50, 50)

N = 4  # number of agents
max_neighbors = 4   #number of interactions at point in overlap

K = 25 # dimension of belief fiber

#Agent self coupling 
alpha = 1    # D_KL(qi|pi)


# Belief gauge connection couplings
beta = 5                #D_KL(qi| Omega qj)
gamma = 1              #lap phi
gauge_weight = 10        #mass term - phi^2


# Model gauge connection couplings
model_align_weight = 5  # D_KL(pi | Omega~ pj)
model_gauge_weight = 2   #lap-phi~
model_mass_weight =  10          #phi`^2

model_feedback_weight = 1 # D_KL(pi|qi) - analogous  to alpha

#interactions between model and belief gauges
phi_phi_tilde_coupling = 1  # strength of reference frame unification


#necessary phi, phi~ initializations of agents
phi_init = 0.1
phi_model_offset = 0.1

# --- Dynamics Parameters ---
eta_q = 0.0001   # Learning rate for belief update
eta_phi = 0.0001 #gauge update
eta_p = 0.001 # Learning rate for model update (smaller than eta_q)
eta_model_phi = 0.00001 #phi~ update

# φ update tuning
phi_clip_threshold = 50  # infinity for non-compact
phi_max_norm = 100    # Maximum allowed norm of φ̃ vectors

#extra couplings for future exploration
curvature_weight = 0  #F^2 term - penalize curvature
phi_damping = 0  # Epistemic prior: only if we want forgetfullness 


# --- Agent Geometry ---
psi_radius_range = (12.5,12.5)
mask_sharpness = 1.5

# Belief (q) distribution parameters
q_mu_range = (2, K-2)
q_sigma_range = (2, 5)
q_sigma_init = 0.5

# Model (p) distribution parameters
p_mu_range = (2, K-2)
p_sigma_range = (1, 8)
p_sigma_init = 1  # or whatever default you want

similar_p_models = False  # if True, all p-models are similar

mu_field_smooth_range = (4, 8)
sigma_field_smooth_range = (3,6)

#q_mu_range = (2, K//2)
#p_mu_range = (K//2 + 1, K - 2)



# --- Numerical Thresholds ---
log_eps = 1e-10
support_cutoff_eps = 1e-3  #larger reduces agent's masks
overlap_eps = 1e-5
eps = 1e-10

# --- Output & Precision ---
checkpoint_dir = "checkpoints"
save_checkpoints = True
checkpoint_interval = 1
precision = np.float32
