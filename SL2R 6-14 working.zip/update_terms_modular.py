
import numpy as np
import config
from omega_operator import (
    kl_divergence,
    batch_exp_sl2r_irrep,
    batch_apply_omega,
    repair_if_forgotten_batch
)
from sl2r_generators import get_generators
_, _, _, generators = get_generators(config.K)

def compute_self_model_gradient(agent_i):
    q_i, p_i, mask_i = agent_i.q, agent_i.p, agent_i.mask
    support_i = mask_i > config.support_cutoff_eps
    grad = np.zeros_like(q_i)
    eps = config.log_eps

    if config.alpha > 0 and np.any(support_i):
        q_support = q_i[support_i]
        p_support = p_i[support_i]

        q_support = q_support / (np.sum(q_support, axis=-1, keepdims=True) + eps)
        p_support = p_support / (np.sum(p_support, axis=-1, keepdims=True) + eps)

        q_support = np.clip(q_support, eps, 1.0)
        p_support = np.clip(p_support, eps, 1.0)

        grad_support = - q_support / p_support  # Correct gradient for ∂KL/∂p
        grad_support = np.clip(grad_support, -1e3, 1e3)

        grad[support_i] += config.alpha * grad_support

    return grad

def compute_alignment_gradient(agent_i, agents):
    from omega_operator import (
        batch_exp_sl2r_irrep,
        batch_apply_omega,
        repair_if_forgotten_batch
    )
    from sl2r_generators import get_generators
    from math_utils import sanitize_q
    import config

    _, _, _, generators = get_generators(config.K)

    q_i, mask_i, phi_i = agent_i.q, agent_i.mask, agent_i.phi
    grad = np.zeros_like(q_i)
    eps = config.log_eps

    if config.beta <= 0:
        return grad

    for neighbor in agent_i.neighbors:
        j = neighbor["id"]
        agent_j = agents[j]
        q_j, phi_j, mask_j = agent_j.q, agent_j.phi, agent_j.mask

        q_j = sanitize_q(q_j, eps=eps)  # 🔧 Important fix

        overlap = (mask_i * mask_j) > config.overlap_eps
        if not np.any(overlap):
            continue

        r_vecs = phi_i[overlap] - phi_j[overlap]  # ✅ No clip
        qj_vecs = sanitize_q(q_j[overlap], eps=eps)


        omega_batch = batch_exp_sl2r_irrep(r_vecs, generators)
        qj_rot_batch = batch_apply_omega(qj_vecs, omega_batch)
        qj_rot_batch = repair_if_forgotten_batch(qj_rot_batch, eps=eps)
        qj_rot_batch = sanitize_q(qj_rot_batch, eps=eps)

        qi_vecs = sanitize_q(q_i[overlap], eps=eps)

        grad_vecs = np.log((qi_vecs + eps) / (qj_rot_batch + eps)) + 1.0
        grad_vecs = np.clip(grad_vecs, -1e3, 1e3)
        grad_vecs = np.nan_to_num(grad_vecs)

        indices = np.argwhere(overlap)
        for idx, (x, y) in enumerate(indices):
            grad[x, y] += config.beta * grad_vecs[idx]

    return grad

def compute_model_alignment_gradient(agent_i, agents):
    from omega_operator import (
        batch_exp_sl2r_irrep, batch_apply_omega, repair_if_forgotten_batch
    )
    from sl2r_generators import get_generators
    from math_utils import sanitize_q
    import config

    _, _, _, generators = get_generators(config.K)

    p_i, mask_i, phi_model_i = agent_i.p, agent_i.mask, agent_i.phi_model
    grad = np.zeros_like(p_i)
    eps = config.log_eps

    if config.model_align_weight <= 0:
        return grad

    for neighbor in agent_i.neighbors:
        j = neighbor["id"]
        agent_j = agents[j]
        p_j, phi_model_j, mask_j = agent_j.p, agent_j.phi_model, agent_j.mask

        overlap = (mask_i * mask_j) > config.overlap_eps
        if not np.any(overlap):
            continue

        # Get overlapping values
        r_vecs = phi_model_i[overlap] - phi_model_j[overlap]  # ✅ Correct


        pi_vecs = sanitize_q(p_i[overlap], eps=eps)
        pj_vecs = sanitize_q(p_j[overlap], eps=eps)

        # Transport pj → i
        omega_batch = batch_exp_sl2r_irrep(r_vecs, generators)
        pj_rot_batch = batch_apply_omega(pj_vecs, omega_batch)
        pj_rot_batch = repair_if_forgotten_batch(pj_rot_batch, eps=eps)
        pj_rot_batch = sanitize_q(pj_rot_batch, eps=eps)

        # Gradient of KL(pi || Ω pj) w.r.t pi
        grad_vecs = np.log(pi_vecs / pj_rot_batch) + 1.0
        grad_vecs = np.clip(grad_vecs, -1e3, 1e3)

        # Accumulate into output gradient
        indices = np.argwhere(overlap)
        for idx, (x, y) in enumerate(indices):
            grad[x, y] += config.model_align_weight * grad_vecs[idx]

    return grad


def compute_phi_alignment_gradient(agent_i, agents):
    from omega_operator import batch_exp_sl2r_irrep, batch_apply_omega, repair_if_forgotten_batch
    from sl2r_generators import get_generators
    from math_utils import sanitize_q
    import config

    _, _, _, generators = get_generators(config.K)
    phi_i = agent_i.phi
    q_i = sanitize_q(agent_i.q, eps=config.log_eps)
    mask_i = agent_i.mask

    delta_phi = np.zeros_like(phi_i)
    eps = config.log_eps

    if config.beta <= 0:
        return delta_phi

    for neighbor in agent_i.neighbors:
        j = neighbor["id"]
        agent_j = agents[j]
        phi_j = agent_j.phi
        q_j = sanitize_q(agent_j.q, eps=eps)
        mask_j = agent_j.mask

        overlap = (mask_i * mask_j) > config.overlap_eps
        if not np.any(overlap):
            continue

        r_vecs = phi_i[overlap] - phi_j[overlap]
        qj_vecs = q_j[overlap]
        qi_vecs = q_i[overlap]
        indices = np.argwhere(overlap)
        mask_vals = mask_i[overlap]

        omega_batch = batch_exp_sl2r_irrep(r_vecs, generators)
        qj_rot_batch = batch_apply_omega(qj_vecs, omega_batch)
        qj_rot_batch = repair_if_forgotten_batch(qj_rot_batch, eps=eps)
        qj_rot_batch = sanitize_q(qj_rot_batch, eps=eps)

        diff = qi_vecs - qj_rot_batch
        diff = np.nan_to_num(diff)

        for a in range(3):
            G = generators[a]
            dOmega_dphi_a = np.einsum('nij,jk->nik', omega_batch, G)
            dOmega_qj = np.einsum('nik,nk->ni', dOmega_dphi_a, qj_vecs)
            dOmega_qj = np.nan_to_num(dOmega_qj)

            grad_a = np.einsum('ni,ni->n', dOmega_qj, diff)

            for idx, (x, y) in enumerate(indices):
                delta_phi[x, y, a] += config.beta * grad_a[idx] * mask_vals[idx]

    return delta_phi


def compute_phi_model_update(agent_i, agents):
    import config
    from omega_operator import batch_exp_sl2r_irrep, batch_apply_omega, repair_if_forgotten_batch
    from sl2r_generators import get_generators
    from math_utils import sanitize_q

    _, _, _, generators = get_generators(config.K)
    H, W, K = agent_i.p.shape

    p_i = sanitize_q(agent_i.p, eps=config.log_eps)
    phi_i = agent_i.phi_model
    mask_i = agent_i.mask

    delta_phi = np.zeros((H, W, 3), dtype=np.float32)
    eps = config.log_eps

    if config.model_align_weight <= 0:
        return delta_phi

    for neighbor in agent_i.neighbors:
        j = neighbor["id"]
        agent_j = agents[j]
        p_j = sanitize_q(agent_j.p, eps=eps)
        phi_j = agent_j.phi_model
        mask_j = agent_j.mask

        overlap = (mask_i * mask_j) > config.overlap_eps
        if not np.any(overlap):
            continue

        # Prepare tensors
        r_vecs = phi_i[overlap] - phi_j[overlap]

        pj_vecs = p_j[overlap]
        pi_vecs = p_i[overlap]
        indices = np.argwhere(overlap)

        # Compute Omegã and apply
        omega_batch = batch_exp_sl2r_irrep(r_vecs, generators)
        pj_rot_batch = batch_apply_omega(pj_vecs, omega_batch)
        pj_rot_batch = repair_if_forgotten_batch(pj_rot_batch, eps=eps)

        pj_rot_batch = sanitize_q(pj_rot_batch, eps=eps)

        # Compute difference in belief space
        diff = pi_vecs - pj_rot_batch

        for a in range(3):
            G = generators[a]  # (K, K)
            dOmega_dphi_a = np.einsum('nij,jk->nik', omega_batch, G)  # ∂Ω/∂φ^a
            dOmega_pj = np.einsum('nik,nk->ni', dOmega_dphi_a, pj_vecs)  # (∂Ω/∂φ^a)·p_j

            # Project onto difference direction
            grad_a = np.einsum('ni,ni->n', dOmega_pj, -diff)  # ∑ (∂Ω·p_j · (p_j - p_i))

            # Accumulate at (x, y)
            for idx, (x, y) in enumerate(indices):
                delta_phi[x, y, a] += config.model_align_weight * grad_a[idx]

    return delta_phi
