# omega_operator.py

import numpy as np
from config import K, phi_clip_threshold
from scipy.linalg import expm
from scipy.ndimage import sobel
from sl2r_generators import get_generators


from config import beta, phi_clip_threshold, log_eps
from sl2r_generators import get_generators
from scipy.linalg import expm
import numpy as np
import config

def repair_if_forgotten(q: np.ndarray, eps: float, threshold: float = 1e-6) -> np.ndarray:
    """
    If a belief vector q has near-zero total mass, inject small uniform mass
    so that belief learning can resume.

    Parameters:
        q         : (K,) belief vector
        eps       : small clipping constant
        threshold : total mass threshold to trigger repair

    Returns:
        q_repaired : repaired or original belief vector
    """
    total_mass = np.sum(q)
    if total_mass < threshold or not np.isfinite(total_mass):
        K = q.shape[-1]
        q = np.random.dirichlet(np.ones(K)) * eps * K
    else:
        q = np.clip(q, eps, 1.0)
        q /= np.sum(q) + eps
    return q


def repair_if_forgotten_batch(q: np.ndarray, eps: float, threshold: float = 1e-6) -> np.ndarray:
    """
    Repair a batch of belief vectors where some may have near-zero total mass.

    Parameters:
        q         : (..., K) array of belief vectors
        eps       : small floor value (e.g., config.log_eps)
        threshold : total mass below which a vector is considered "forgotten"

    Returns:
        q_repaired : repaired batch, same shape as q
    """
    q = np.nan_to_num(q, nan=0.0, posinf=0.0, neginf=0.0)
    orig_shape = q.shape
    K = q.shape[-1]
    q_flat = q.reshape(-1, K)
    norms = np.sum(q_flat, axis=-1, keepdims=True)

    forgotten = (norms < threshold) | (~np.isfinite(norms))

    if np.any(forgotten):
        n_forgotten = np.sum(forgotten)
        repaired = np.random.dirichlet(np.ones(K), size=n_forgotten) * eps * K
        q_flat[forgotten.squeeze()] = repaired

    q_flat = np.clip(q_flat, eps, 1.0)
    q_flat /= np.sum(q_flat, axis=-1, keepdims=True) + eps
    return q_flat.reshape(orig_shape)



def kl_divergence(q1, q2, eps=1e-12):
    q1 = np.clip(q1, eps, 1.0)
    q2 = np.clip(q2, eps, 1.0)
    return np.sum(q1 * (np.log(q1) - np.log(q2)), axis=-1)

from sl2r_generators import get_generators
_, _, _, generators = get_generators(K)



import numpy as np
from scipy.linalg import expm
from sl2r_generators import get_generators

import config

def adaptive_expm(G, max_norm=20):
    """
    Matrix exponential with adaptive scaling and squaring for numerical stability.
    """
    norm_G = np.linalg.norm(G, ord=2)
    if norm_G <= max_norm:
        return expm(G)
    else:
        s = int(np.ceil(norm_G / max_norm))
        G_scaled = G / s
        exp_G_scaled = expm(G_scaled)
        result = exp_G_scaled
        for _ in range(s - 1):
            result = result @ exp_G_scaled
        return result

def exp_sl2r_irrep(v, generators=None, use_expm=True, threshold=config.phi_clip_threshold, max_norm=20):
    if generators is None:
        _, _, _, generators = get_generators(config.K)

    norm_v = np.linalg.norm(v)
    if norm_v > max_norm:
        v = v * (max_norm / norm_v)  # scale down to max_norm

    G = sum(v[a] * generators[a] for a in range(3))

    if not use_expm or norm_v < threshold:
        # Taylor expansion up to 2nd order
        return np.eye(G.shape[0]) + G + 0.5 * G @ G
    else:
        return adaptive_expm(G, max_norm=max_norm)

def batch_exp_sl2r_irrep(v_batch, generators, use_expm=True, threshold=config.phi_clip_threshold, max_norm=20):
    _, _, _, generators = get_generators(config.K)
    beta = config.beta
    K = config.K

    if beta == 0:
        return None

    # Scale down vectors exceeding max_norm
    norms = np.linalg.norm(v_batch, axis=1)
    scale_factors = np.minimum(1, max_norm / norms)
    v_batch_scaled = v_batch * scale_factors[:, None]

    G_batch = np.einsum('na,aij->nij', v_batch_scaled, generators)  # (N, K, K)

    norms_scaled = np.linalg.norm(v_batch_scaled, axis=1)

    result = np.zeros((len(v_batch), K, K), dtype=np.float64)

    approx_mask = norms_scaled < threshold
    if np.any(approx_mask):
        G_approx = G_batch[approx_mask]
        G2 = np.einsum('nij,njk->nik', G_approx, G_approx)
        G3 = np.einsum('nij,njk->nik', G2, G_approx)
        G4 = np.einsum('nij,njk->nik', G3, G_approx)
        G5 = np.einsum('nij,njk->nik', G4, G_approx)
        I = np.eye(K)[None, :, :]

        result[approx_mask] = (
            I +
            G_approx +
            (1/2) * G2 +
            (1/6) * G3 +
            (1/24) * G4 +
            (1/120) * G5
        )

    if np.any(~approx_mask):
        for idx in np.where(~approx_mask)[0]:
            result[idx] = adaptive_expm(G_batch[idx], max_norm=max_norm)

    return result


from scipy.linalg import expm
from sl2r_generators import get_generators  # assumes sl2r generators are provided here
import config
import numpy as np
from scipy.linalg import expm
import config

def batch_apply_omega(q_batch, omega_batch):
    """
    Apply batch of group elements Ω to batch of belief vectors q.
    Args:
        q_batch: shape (N, K)
        omega_batch: shape (N, K, K)
    Returns:
        Transformed batch: shape (N, K)
    """
    assert omega_batch.shape[0] == q_batch.shape[0], "Batch size mismatch"
    assert omega_batch.shape[1] == omega_batch.shape[2], "Omega must be square"
    assert omega_batch.shape[1] == q_batch.shape[1], (
        f"Mismatch in fiber dimension: "
        f"omega is ({omega_batch.shape[1]}, {omega_batch.shape[2]}), "
        f"but q has K = {q_batch.shape[1]}"
    )
    return np.einsum('nij,nj->ni', omega_batch, q_batch)

def exp_sl2r_operator(v, generators, use_expm=True, threshold=config.phi_clip_threshold, max_norm=20):
    """
    Compute exp(Σ vₐ Tₐ) in SL(2,ℝ) irrep with adaptive scaling and squaring.
    """
    norm_v = np.linalg.norm(v)
    if norm_v > max_norm:
        v = v * (max_norm / norm_v)  # scale down to max_norm

    G = sum(v[a] * generators[a] for a in range(3))

    if not use_expm or norm_v < threshold:
        return np.eye(G.shape[0]) + G + 0.5 * G @ G
    else:
        # Use the adaptive expm implementation discussed earlier
   
        return adaptive_expm(G, max_norm=max_norm)

def apply_omega(q_j, omega):
    """
    Apply a single SL(2,ℝ) group matrix Ω to a belief vector q_j.
    Args:
        q_j: shape (K,) or (..., K)
        omega: shape (K, K)
    Returns:
        Transformed vector of same shape as q_j
    """
    return np.einsum('ij,...j->...i', omega, q_j)

def compute_gauge_potential(phi):
    """
    Compute SL(2,ℝ) gauge potential: A_μ^a = ∂_μ φ^a

    Returns:
    - A_x, A_y ∈ ℝ^(H, W, 3) where last dim is Lie algebra index
    """
    dphi_dx = np.gradient(phi, axis=1)  # ∂/∂x φ^a
    dphi_dy = np.gradient(phi, axis=0)  # ∂/∂y φ^a
    A_x = dphi_dx
    A_y = dphi_dy
    return A_x, A_y


def compute_field_strength(phi):
    """
    SL(2,ℝ) curvature: F_{xy} = ∂_x A_y - ∂_y A_x + [A_x, A_y]
    with A_μ ∈ ℝ³ Lie algebra components

    Returns:
        F_squared (H, W) — scalar curvature magnitude per point
    """
    A_x, A_y = compute_gauge_potential(phi)

    dAy_dx = np.gradient(A_y, axis=1)  # ∂_x A_y
    dAx_dy = np.gradient(A_x, axis=0)  # ∂_y A_x

    commutator = np.cross(A_x, A_y)  # Lie bracket in ℝ³ basis
    F = dAy_dx - dAx_dy + commutator

    # Clip to avoid overflow in squaring
    F_clipped = np.clip(F, -1e6, 1e6)

    if np.any(np.isnan(F_clipped)) or np.any(np.isinf(F_clipped)):
        print("[WARNING] Curvature contains NaN or Inf values.")

    F_squared = np.sum(F_clipped**2, axis=-1)

    return F_squared


def compute_sl2r_commutator(A_mu, A_nu):
    """
    Matrix commutator: [A_μ, A_ν] = A_μ A_ν - A_ν A_μ
    A_μ, A_ν are (..., K, K) matrices.
    """
    return np.matmul(A_mu, A_nu) - np.matmul(A_nu, A_mu)
def compute_sl2r_curvature(phi):
    A_x_vec, A_y_vec = compute_gauge_potential(phi)
    _, _, _, generators = get_generators(config.K)

    A_x = np.einsum('...a,aij->...ij', A_x_vec, generators)
    A_y = np.einsum('...a,aij->...ij', A_y_vec, generators)

    dAy_dx = np.gradient(A_y, axis=1)
    dAx_dy = np.gradient(A_x, axis=0)

    comm = compute_sl2r_commutator(A_x, A_y)
    F_xy = dAy_dx - dAx_dy + comm

    # Optional clipping or NaN check
    F_xy = np.clip(F_xy, -1e6, 1e6)
    if np.any(np.isnan(F_xy)) or np.any(np.isinf(F_xy)):
        print("[WARNING] Curvature tensor contains NaN or Inf values.")

    curvature_norm = np.linalg.norm(F_xy, axis=(-2, -1))  # Frobenius norm over last two dims
    return curvature_norm
