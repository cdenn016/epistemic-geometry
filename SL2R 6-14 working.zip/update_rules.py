# Modular update_rules.py
from config import eta_q, log_eps, K
from agent_schema import Agent
import numpy as np
from update_terms_modular import (
    compute_self_model_gradient,
    compute_alignment_gradient,
    compute_phi_alignment_gradient
)
from math_utils import sanitize_q
from update_terms_modular import compute_model_alignment_gradient  # add to your import block

from update_terms_modular import compute_phi_model_update
import config
from agent_schema import Agent


def update_beliefs(i: int, agents: list[Agent], params: dict) -> Agent:
    """
    Update beliefs q for agent i using parameters from params dict.

    Expected keys in params:
        - eta_q: float, learning rate
        - support_cutoff_eps: float, mask cutoff threshold
        - log_eps: float, numerical floor for probabilities

    Fallback default values are provided.
    """
    eta_q = params.get("eta_q", 0.0001)
    support_cutoff_eps = params.get("support_cutoff_eps", 1e-3)
    log_eps = params.get("log_eps", 1e-8)

    agent_i = agents[i]
    q_i = agent_i.q
    mask_i = agent_i.mask

    grad = compute_self_model_gradient(agent_i)
    grad += compute_alignment_gradient(agent_i, agents)

    q_new = q_i - eta_q * grad

    # Preserve q outside support
    outside_support = mask_i < support_cutoff_eps
    q_new[outside_support] = q_i[outside_support]

    # Use sanitize_q if available, else fallback clip + normalize
    try:
        q_new = sanitize_q(q_new, eps=log_eps)
    except Exception:
        q_new = np.clip(q_new, log_eps, None)
        q_new /= np.sum(q_new, axis=-1, keepdims=True) + 1e-12

    agent_i.q = q_new
    return agent_i

def update_models(i: int, agents: list[Agent], params: dict) -> Agent:
    """
    Update model distribution p for agent i using parameters from params dict.

    Expected keys in params:
      - eta_p: learning rate for model updates
      - log_eps: numerical floor for probabilities
      - support_cutoff_eps: cutoff threshold for agent support mask
      - model_feedback_weight: weight for epistemic feedback pulling model toward belief
    """
    eta_p = params.get("eta_p", 0.0001)
    log_eps = params.get("log_eps", 1e-8)
    support_cutoff_eps = params.get("support_cutoff_eps", 1e-3)
    model_feedback_weight = params.get("model_feedback_weight", 0.0)

    from math_utils import sanitize_q

    agent_i = agents[i]
    q_i = agent_i.q
    p_i = agent_i.p
    mask_i = agent_i.mask

    grad = compute_model_alignment_gradient(agent_i, agents)

    if model_feedback_weight > 0:
        q_safe = np.clip(q_i, log_eps, 1.0)
        p_safe = np.clip(p_i, log_eps, 1.0)
        grad_qp = np.log(p_safe / q_safe)  # ∇_p D_KL(q || p)
        grad += model_feedback_weight * grad_qp

    p_new = p_i - eta_p * grad

    # Preserve model outside support
    outside_support = mask_i < support_cutoff_eps
    p_new[outside_support] = p_i[outside_support]

    # Normalize after update
    p_new = sanitize_q(p_new, eps=log_eps)

    agent_i.p = p_new
    return agent_i


def update_phi(i: int, agents: list[Agent], eta_phi: float, params: dict) -> Agent:
    # Extract parameters from params dict with defaults
    phi_phi_tilde_coupling = params.get("phi_phi_tilde_coupling", 0.0)
    gamma = params.get("gamma", 0.0)
    gauge_weight = params.get("gauge_weight", 0.0)
    phi_damping = params.get("phi_damping", 0.0)
    phi_max_norm = params.get("phi_max_norm", 10.0)
    blowup_threshold = params.get("blowup_threshold", 1e10)

    agent_i = agents[i]
    phi_i = agent_i.phi
    mask_i = agent_i.mask

    delta_phi = compute_phi_alignment_gradient(agent_i, agents)

    if phi_phi_tilde_coupling > 0 and hasattr(agent_i, "phi_model"):
        delta_phi -= phi_phi_tilde_coupling * (phi_i - agent_i.phi_model) * mask_i[..., None]

    if gamma > 0:
        from scipy.ndimage import laplace
        lap_phi = np.stack([laplace(phi_i[..., d]) for d in range(3)], axis=-1)
        delta_phi -= gamma * lap_phi * mask_i[..., None]

    if gauge_weight > 0:
        delta_phi -= gauge_weight * phi_i * mask_i[..., None]

    if phi_damping > 0:
        delta_phi -= phi_damping * phi_i * mask_i[..., None]

    # Blow-up detection
    max_delta = np.max(np.abs(delta_phi))
    if np.any(np.isnan(delta_phi)) or max_delta > blowup_threshold:
        print(f"[WARNING] phi update unstable in agent {i}: max delta_phi = {max_delta:.2e}")

    delta_phi = np.nan_to_num(delta_phi, nan=0.0, posinf=0.0, neginf=0.0)

    phi_new = phi_i + eta_phi * delta_phi

    # Post-update blow-up check on phi_new
    max_phi_norm = np.max(np.linalg.norm(phi_new, axis=-1))
    if np.any(np.isnan(phi_new)) or max_phi_norm > blowup_threshold:
        print(f"[WARNING] phi field unstable in agent {i}: max norm = {max_phi_norm:.2e}")

    # Clip norm to phi_max_norm
    norm = np.linalg.norm(phi_new, axis=-1, keepdims=True)
    clip_mask = norm > phi_max_norm
    if np.any(clip_mask):
        phi_new = np.where(clip_mask, phi_new * (phi_max_norm / (norm + 1e-8)), phi_new)

    agent_i.phi = phi_new
    agent_i.delta_phi = delta_phi

    return agent_i


def update_phi_model(i: int, agents: list[Agent], eta_model_phi: float, params: dict) -> Agent:
    """
    Update model gauge field phi_model for agent i using parameters from params dict.

    Expected keys in params:
      - phi_phi_tilde_coupling: coupling strength between phi and phi_model
      - phi_damping: damping coefficient for phi_model
      - model_gauge_weight: Laplacian smoothing / curvature penalty weight for phi_model
      - model_mass_weight: quadratic mass penalty weight on phi_model (new)
      - phi_max_norm: maximum allowed norm of phi_model vectors
      - debug: bool, enable debug printing
      - blowup_threshold: threshold for delta_phi_model instability detection
    """
    phi_phi_tilde_coupling = params.get("phi_phi_tilde_coupling", 0.0)
    phi_damping = params.get("phi_damping", 0.0)
    model_gauge_weight = params.get("model_gauge_weight", 0.0)
    model_mass_weight = params.get("model_mass_weight", 0.0)  # <-- added here
    phi_max_norm = params.get("phi_max_norm", 10.0)
    debug = params.get("debug", False)
    blowup_threshold = params.get("blowup_threshold", 1e10)

    agent_i = agents[i]
    phi_model = agent_i.phi_model
    mask_i = agent_i.mask

    delta_phi = compute_phi_model_update(agent_i, agents)

    if phi_phi_tilde_coupling > 0:
        if hasattr(agent_i, "phi"):
            phi_i = agent_i.phi
            assert phi_model.shape == phi_i.shape, (
                f"[ERROR] phi_model vs phi shape mismatch: {phi_model.shape} vs {phi_i.shape}"
            )
            delta_phi -= phi_phi_tilde_coupling * (phi_model - phi_i) * mask_i[..., None]
        else:
            print(f"[WARNING] Agent {i} has no phi; skipping φ̃–φ coupling")

    if phi_damping > 0:
        delta_phi -= phi_damping * phi_model * mask_i[..., None]

    if model_gauge_weight > 0:
        from scipy.ndimage import laplace
        lap_phi_model = np.stack([laplace(phi_model[..., d]) for d in range(3)], axis=-1)
        delta_phi -= model_gauge_weight * lap_phi_model * mask_i[..., None]

    # --- Add model mass term ---
    if model_mass_weight > 0:
        delta_phi -= model_mass_weight * phi_model * mask_i[..., None]

    if debug:
        delta_norm = np.linalg.norm(delta_phi, axis=-1)
        print(f"[φ̃ DEBUG] Agent {i} — delta_phi_model max: {np.max(delta_norm):.4f}, mean: {np.mean(delta_norm):.4f}")

    max_delta = np.max(np.abs(delta_phi))
    if np.any(np.isnan(delta_phi)) or max_delta > blowup_threshold:
        print(f"[WARNING] phi-model update unstable in agent {i}: max delta_phi_model = {max_delta:.2e}")

    delta_phi = np.nan_to_num(delta_phi, nan=0.0, posinf=0.0, neginf=0.0)

    phi_model_new = phi_model + eta_model_phi * delta_phi

    norm = np.linalg.norm(phi_model_new, axis=-1, keepdims=True)
    clip_mask = norm > phi_max_norm
    if np.any(clip_mask):
        phi_model_new = np.where(clip_mask, phi_model_new * (phi_max_norm / (norm + 1e-8)), phi_model_new)

    agent_i.phi_model = phi_model_new
    agent_i.delta_phi_model = delta_phi

    return agent_i


