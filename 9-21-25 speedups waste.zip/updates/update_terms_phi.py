
import numpy as np
from core.numerical_utils import safe_inv, sanitize_sigma, safe_omega_inv
from core.transport_cache import build_dexpinv_matrix , Jinv_grid, E_grid, exp_and_jinv_single, Phi_cached
import core.config as config
from core.omega import d_exp_exact
from runtime_context import cfg_get
from utils import ( log_phi_grad_like, _joint_mask, reg_weights, _aid,
                   mask_hw, build_c_mapping_q2p)
from core.numerical_utils import push_gaussian
#==============================================================================
#
#                    GATHER PHI GAUGE FIELD GRADIENT TERMS
#                          Beliefs and Models
#==============================================================================

def accumulate_phi_alignment_gradient(
    ctx,
    agent_i, agent_j, generators,
    *,
    field: str = "phi",
    beta_key: str | None = None,
    omega_cache_key: str | None = None,
    mu_key: str | None = None,
    sigma_key: str | None = None,
    fisher_inv_key: str | None = None,
    grad_key: str | None = None,
    Q_all_i=None,             # legacy; we’ll prefer R_i
    exp_neg_phi_j=None,
    agents=None,
    exp_phi_i=None,           # E_i
    Jinv_i=None,              # Jinv_i
    joint_mask_override=None,
    exp_neg_phi_i=None,       # E_i^{-1}
    M_i=None,
    Q_tilde_i=None,
    R_i=None,                 # NEW: (…, A, K, K)
):
    import numpy as np, time

    assert mu_key and sigma_key and fisher_inv_key and grad_key

    prof = bool(cfg_get(ctx, "debug_phi_timing", False))
    t = {}
    TIC = (lambda: time.perf_counter()) if prof else (lambda: None)
    def TOCK(t0, key):
        if prof and t0 is not None: t[key] = t.get(key, 0.0) + (time.perf_counter() - t0)

    eps = float(cfg_get(ctx, "eps", 1e-8))
    tau = float(cfg_get(ctx, "support_tau", 1e-6))

    which = "q" if field == "phi" else "p"
    beta = float(cfg_get(ctx, beta_key or ("beta" if field=="phi" else "beta_model"), 0.0))
    if beta == 0.0:
        return

    # mask
    t0 = TIC()
    joint_mask = joint_mask_override
    if joint_mask is None:
        joint_mask = _joint_mask(agent_i, agent_j, tau=tau, as_vector=True)
    TOCK(t0, "mask")
    if not np.any(joint_mask):
        return

    # Active index for compaction
    active_idx = np.nonzero(joint_mask)[0]
    compact = active_idx.size < joint_mask.size  # compact only if sparse

    # fields for i
    t0 = TIC()
    mu_i_all    = np.asarray(getattr(agent_i, mu_key),    np.float32, order="C")
    sigma_i_all = np.asarray(getattr(agent_i, sigma_key), np.float32, order="C")
    mu_i    = mu_i_all[active_idx]    if compact else mu_i_all
    sigma_i = sigma_i_all[active_idx] if compact else sigma_i_all
    TOCK(t0, "fields")

    # E_i / E_j and inverses (and compact them consistently)
    t0 = TIC()
    E_i  = exp_phi_i if exp_phi_i is not None else E_grid(ctx, agent_i, which=which)
    E_j  = E_grid(ctx, agent_j, which=which)
    Enj  = exp_neg_phi_j if exp_neg_phi_j is not None else safe_omega_inv(E_j)
    Eni  = exp_neg_phi_i if exp_neg_phi_i is not None else safe_omega_inv(E_i)

    Omega_ij = np.einsum("...ik,...kj->...ij", E_i, Enj,  optimize=True)
    Oinv_ij  = np.einsum("...ik,...kj->...ij", E_j, Eni, optimize=True)

    if compact:
        Omega_ij = Omega_ij[active_idx]
        Oinv_ij  = Oinv_ij[active_idx]
        Enj_c    = Enj[active_idx]    # <- IMPORTANT: compact E_j^{-1}
        Eni_c    = Eni[active_idx]    # <- IMPORTANT: compact E_i^{-1}
    else:
        Enj_c    = Enj
        Eni_c    = Eni
    TOCK(t0, "transports")

    # push neighbor stats using Σ_j^{-1} if available
    t0 = TIC()
    mu_j_all = np.asarray(getattr(agent_j, mu_key.replace("sigma","mu")), np.float32, order="C")
    mu_j     = mu_j_all[active_idx] if compact else mu_j_all
    mu_j_t   = np.einsum("...ij,...j->...i", Omega_ij, mu_j, optimize=True)

    inv_key  = sigma_key.replace("_field", "_inv")
    S_inv_j  = getattr(agent_j, inv_key, None)
    if S_inv_j is None:
        Sigma_j_all = sanitize_sigma(np.asarray(getattr(agent_j, sigma_key), np.float32), eps=eps)
        Sigma_j = Sigma_j_all[active_idx] if compact else Sigma_j_all
        S_j_t   = np.einsum("...ik,...kl,...jl->...ij", Omega_ij, Sigma_j, Omega_ij, optimize=True)
        S_inv_t = safe_inv(S_j_t, eps=eps)
    else:
        S_inv_j = np.asarray(S_inv_j, np.float32, order="C")
        S_inv_j = S_inv_j[active_idx] if compact else S_inv_j
        S_inv_t = np.einsum("...ki,...kl,...lj->...ij", Oinv_ij, S_inv_j, Oinv_ij, optimize=True)
    TOCK(t0, "push_neighbor")

    # d-exp bits: prefer pre-stacked R_i
    phi_i = np.asarray(getattr(agent_i, field), np.float32, order="C")
    t0 = TIC()
    if R_i is None:
        Q_all = Q_all_i if Q_all_i is not None else d_exp_exact(phi_i, generators)
        R_i = np.stack([np.asarray(x, np.float32, order="C") for x in Q_all], axis=-3)
    R_i_c = R_i[active_idx] if compact else R_i
    Qtilde_i_c = Q_tilde_i[active_idx] if (Q_tilde_i is not None and compact) else Q_tilde_i
    TOCK(t0, "dexp_setup")

    # --- grad in compact space ---
    t0 = TIC()
    grad_param_c = grad_kl_wrt_phi_i(
        mu_i, sigma_i,
        mu_j_src=mu_j,
        phi_i=phi_i,
        Omega_ij=Omega_ij,
        Oinv_ij=Oinv_ij,           # unused when Q_tilde_i provided; harmless
        generators=generators,
        exp_phi_i=E_i,
        mu_j_t=mu_j_t,
        sigma_j_t_inv=S_inv_t,
        eps=eps,
        exp_neg_phi_j=Enj_c,       # <-- compacted
        exp_neg_phi_i=Eni_c,       # <-- NEW: compacted E_i^{-1}
        Q_all=None,
        Q_tilde_i=Qtilde_i_c,
        R_i=R_i_c,
    ).astype(np.float32, copy=False)
    TOCK(t0, "grad_param")

    # ---- Fisher / regularizers / back-map ----
    regularizers_enabled = bool(cfg_get(ctx, "enable_lie_regularizers", True))
    
    if (M_i is not None) and (not regularizers_enabled):
        # M_i may be (A,A), (L,L,A,A) or (L*L,A,A).
        Mi = np.asarray(M_i, np.float32, order="C")
    
        # If it's (L, L, A, A) -> flatten to (L*L, A, A)
        if Mi.ndim == 4 and Mi.shape[-1] == Mi.shape[-2]:
            H, W, A1, A2 = Mi.shape
            Mi = Mi.reshape(H * W, A1, A2)
    
        # If it's per-site (N_full, A, A), compact to active sites
        if Mi.ndim == 3 and Mi.shape[0] == joint_mask.size and compact:
            Mi = Mi[active_idx]  # -> (N_active, A, A)
    
        # If it's global (A, A), leave as-is; einsum will broadcast over N_active
        # Now safe: (N_active, A, A) @ (N_active, A) or (A, A) @ (N_active, A)
        v_param_c = np.einsum("...ab,...b->...a", Mi, grad_param_c, optimize=True)
    
    else:
        # original slow path (Jinv, F_inv, regs)
        Jinv = Jinv_i if Jinv_i is not None else Jinv_grid(ctx, agent_i, which=which)
        if Jinv is None:
            Jinv = build_dexpinv_matrix(phi_i)
    
        Jinv_c = Jinv if not compact else Jinv[active_idx]  # (N_active, A, A) if compact
        g_body_c = np.einsum("...ji,...j->...i", Jinv_c, grad_param_c, optimize=True)
    
        F_inv_i = getattr(agent_i, fisher_inv_key, None)
        if F_inv_i is None:
            v_body_c = g_body_c
        else:
            F_inv_full = np.asarray(F_inv_i, np.float32, order="C")
            F_inv_c = F_inv_full if not compact else F_inv_full[active_idx]
            v_body_c = np.einsum("...ab,...b->...a", F_inv_c, g_body_c, optimize=True)
    
        v_body_tot_c = _apply_lie_natural_regularizers(
            agent_i, field, generators, ctx, v_body_c, agents=agents, active_idx=(active_idx if compact else None)
        )
        v_param_c = np.einsum("...ab,...b->...a", Jinv_c, v_body_tot_c, optimize=True)

    # ---- scatter (if compact) & accumulate ----
    if compact:
        out = np.zeros((joint_mask.shape[0],) + v_param_c.shape[1:], dtype=np.float32)
        out[active_idx] = v_param_c
        contrib = beta * out
    else:
        contrib = beta * v_param_c

    prev = getattr(agent_i, grad_key, None)
    if prev is None:
        prev = np.zeros_like(contrib, dtype=np.float32)
    setattr(agent_i, grad_key, prev + contrib)

    if prof:
        aid  = _aid(agent_i)
        ajid = getattr(agent_j, "id", "?")
        order = [
            "mask","fields","transports","push_neighbor","dexp_setup",
            "grad_param","Jinv","param_to_body","fisher_apply","regularizers",
            "body_to_param","accumulate","fisher_sandwich_fastpath"
        ]
        print(
            f"[φ-PROF align] ai={aid} aj={ajid} "
            + " ".join(f"{k}:{t[k]*1e3:.2f}ms" for k in order if k in t),
            flush=True
        )


def grad_kl_wrt_phi_i(
    mu_i, sigma_i,
    *,
    mu_j_src,
    phi_i,
    Omega_ij,
    Oinv_ij,
    generators,
    exp_phi_i,
    mu_j_t,
    sigma_j_t_inv,
    eps=1e-8,
    exp_neg_phi_j=None,
    exp_neg_phi_i=None,   # <-- NEW: accept compacted E_i^{-1}
    Q_all=None,
    Q_tilde_i=None,
    R_i=None,             # (..., A, K, K)
):
    import numpy as np
    mu_i    = np.asarray(mu_i,    np.float32, order="C")
    mu_j_t  = np.asarray(mu_j_t,  np.float32, order="C")
    Sigma_i = sanitize_sigma(np.asarray(sigma_i, np.float32, order="C"), eps=eps)
    A = np.asarray(sigma_j_t_inv, np.float32, order="C")
    A = 0.5 * (A + np.swapaxes(A, -1, -2))
    delta = mu_i - mu_j_t

    # Build small blocks
    S1 = np.einsum("...ij,...jk->...ik", Sigma_i, A, optimize=True)
    S2 = np.einsum("...ij,...jk->...ik", A,       Sigma_i, optimize=True)
    S  = S1 + S2

    # Use provided compacted inverses directly (DO NOT recompute)
    assert exp_neg_phi_i is not None and exp_neg_phi_j is not None, \
        "exp_neg_phi_i and exp_neg_phi_j must be provided (already compacted if needed)."

    v_i = np.einsum("...ij,...j->...i", np.asarray(exp_neg_phi_i, np.float32, order="C"),
                                   np.asarray(delta,          np.float32, order="C"), optimize=True)
    v_j = np.einsum("...ij,...j->...i", np.asarray(exp_neg_phi_j, np.float32, order="C"),
                                   np.asarray(delta,          np.float32, order="C"), optimize=True)

    b = np.einsum("...ij,...j->...i", A, delta, optimize=True)
    c = np.einsum("...ij,...j->...i", A, np.asarray(mu_j_src, np.float32, order="C"), optimize=True)

    # Trace: tr(Q̃ S) with Q̃ = R_i E_i^{-1}
    EniS = np.einsum("...ik,...kj->...ij", np.asarray(exp_neg_phi_i, np.float32, order="C"), S, optimize=True)
    trace_term = -0.5 * np.einsum("...aik,...ki->...a",
                                  np.asarray(R_i, np.float32, order="C"), EniS, optimize=True)

    # Mean: -(Q Δ)·(A μ_j) with Q = R_i E_j^{-1}
    yQ = np.einsum("...aik,...k->...ai", np.asarray(R_i, np.float32, order="C"), v_j, optimize=True)
    mean_term = -np.einsum("...ai,...i->...a", yQ, c, optimize=True)

    # Mahalanobis: (Q̃ Δ)·(A Δ) with Q̃ = R_i E_i^{-1}
    y = np.einsum("...aik,...k->...ai", np.asarray(R_i, np.float32, order="C"), v_i, optimize=True)
    mahal_term = np.einsum("...ai,...i->...a", y, b, optimize=True)

    return (trace_term + mean_term + mahal_term)



# ─────────────────────────────────────────────────────────────────────────────
#            SELF AND FEEDBACK GRADS
# ─────────────────────────────────────────────────────────────────────────────


def accumulate_phi_morphism_self_feedback(
    ctx,
    agent_i,
    generators_src, generators_tgt,
    *,
    field: str = "phi",
    fisher_inv_key: str | None = None,
    grad_key: str | None = None,
    phi_self_func=None,
    phi_feedback_func=None,
):
    """
    Accumulate SELF + FEEDBACK gradients for φ (or φ̃) into agent_i.<grad_key>.
    Pipeline: Jinv^T (param-covector) → Fisher^{-1} (body) → Jinv (param-vector).
    Uses cached Φ̃ and reuses pushed mean/precision if available.
    """
   

    assert fisher_inv_key and grad_key, "fisher_inv_key and grad_key are required"

    PRINT_SIGN = False

    eps   = float(cfg_get(ctx, "eps", 1e-8))
    tau   = float(cfg_get(ctx, "support_tau", 1e-6))
    alpha = float(cfg_get(ctx, "alpha", 0.0))
    fbw   = float(cfg_get(ctx, "feedback_weight", 0.0))

    # (H,W,1) mask for broadcasting with (...,A)
    mask = mask_hw(agent_i, tau=tau, mode="float3")
    if not np.any(mask):
        return

    # fields & base φ
    mu_q,  sigma_q  = agent_i.mu_q_field,  agent_i.sigma_q_field
    mu_p,  sigma_p  = agent_i.mu_p_field,  agent_i.sigma_p_field
    phi     = np.asarray(agent_i.phi,       np.float32)
    phi_t   = np.asarray(agent_i.phi_model, np.float32)

    base_phi = phi if field == "phi" else phi_t

    # transports & Jinv (cache-first)
    exp_this, exp_other, Jinv, which, G_q, G_p = exp_and_jinv_single(
        ctx, agent_i, field, base_phi, generators_src, generators_tgt
    )

    # Φ̃ from central cache (q <- p)
    Phi_tilde = Phi_cached(ctx, agent_i, kind="p_to_q")  # (H,W,K_q,K_p)

    # Reuse pushed mean/precision from μ/Σ pass if present, else compute once
    mu_p_push  = getattr(agent_i, "_mu_p_push",          None)  # Φ̃ μ_p
    A_inv_push = getattr(agent_i, "_Sigma_p_push_inv",    None)  # (Φ̃ Σ_p Φ̃ᵀ)^{-1}
    if (mu_p_push is None) or (A_inv_push is None):
        mu_p_push, _, A_inv_push = push_gaussian(
            mu=mu_p, Sigma=sigma_p, M=Phi_tilde,
            eps=eps, return_inv=True, assume_orthogonal=False
        )
        # keep for the rest of this step
        setattr(agent_i, "_mu_p_push",         mu_p_push.astype(np.float32, copy=False))
        setattr(agent_i, "_Sigma_p_push_inv",  A_inv_push.astype(np.float32, copy=False))

    # Fisher^{-1}: treat missing as identity (no-op)
    F_inv = getattr(agent_i, fisher_inv_key, None)
    Fi = None if F_inv is None else np.asarray(F_inv, np.float32, order="C")

    total = np.zeros_like(base_phi, dtype=np.float32)
    self_contrib = fb_contrib = None

    # -------- SELF term --------
    if alpha > 0.0 and phi_self_func is not None:
        if field == "phi":
            # try fast-path kwargs first; fall back if the function doesn't accept them
            try:
                g_param = phi_self_func(
                    mu_q=mu_q, sigma_q=sigma_q, mu_p=mu_p, sigma_p=sigma_p,
                    Phi_tilde_0=getattr(agent_i, "Phi_tilde_0", None),
                    phi=phi, phi_tilde=phi_t,
                    generators_q=G_q, generators_p=G_p,
                    exp_phi=exp_this, exp_phi_tilde=exp_other,
                    # fast-path:
                    Phi_tilde=Phi_tilde, A_inv_cached=A_inv_push, mu_t_cached=mu_p_push,
                    eps=eps
                )
            except TypeError:
                g_param = phi_self_func(
                    mu_q=mu_q, sigma_q=sigma_q, mu_p=mu_p, sigma_p=sigma_p,
                    Phi_tilde_0=getattr(agent_i, "Phi_tilde_0", None),
                    phi=phi, phi_tilde=phi_t,
                    generators_q=G_q, generators_p=G_p,
                    exp_phi=exp_this, exp_phi_tilde=exp_other,
                    eps=eps
                )
        else:  # field == "phi_model"
            try:
                g_param = phi_self_func(
                    mu_q=mu_q, sigma_q=sigma_q, mu_p=mu_p, sigma_p=sigma_p,
                    Phi_tilde_0=getattr(agent_i, "Phi_tilde_0", None),
                    phi=phi, phi_tilde=phi_t,
                    generators_q=G_q, generators_p=G_p,
                    exp_phi=exp_other, exp_phi_tilde=exp_this,
                    # fast-path:
                    Phi_tilde=Phi_tilde, A_inv_cached=A_inv_push, mu_t_cached=mu_p_push,
                    eps=eps
                )
            except TypeError:
                g_param = phi_self_func(
                    mu_q=mu_q, sigma_q=sigma_q, mu_p=mu_p, sigma_p=sigma_p,
                    Phi_tilde_0=getattr(agent_i, "Phi_tilde_0", None),
                    phi=phi, phi_tilde=phi_t,
                    generators_q=G_q, generators_p=G_p,
                    exp_phi=exp_other, exp_phi_tilde=exp_this,
                    eps=eps
                )

        if g_param is None:
            raise RuntimeError("phi_self_func returned None; check arguments.")

        # param-covector -> body-covector
        g_body = np.einsum("...ji,...j->...i", Jinv, g_param, optimize=True)
        # Fisher^{-1} (no-op if Fi is None)
        v_body = g_body if Fi is None else np.einsum("...ab,...b->...a", Fi, g_body, optimize=True)
        # body-vector -> param-vector
        v_param = np.einsum("...ab,...b->...a", Jinv, v_body, optimize=True)

        self_contrib = alpha * v_param * mask      # (H,W,A)
        total += self_contrib

    # -------- FEEDBACK term --------
    if fbw > 0.0 and phi_feedback_func is not None:
        if field == "phi":
            # conservative call; pass only standard args (feedback fn may not accept fast-paths)
            g_param = phi_feedback_func(
                mu_p=mu_p, sigma_p=sigma_p, mu_q=mu_q, sigma_q=sigma_q,
                Phi_0=getattr(agent_i, "Phi_0", None),
                phi=phi, phi_tilde=phi_t,
                exp_phi=exp_this, exp_phi_tilde=exp_other,
                eps=eps,
                generators_q=G_q, generators_p=G_p,
            )
        else:
            g_param = phi_feedback_func(
                mu_p=mu_p, sigma_p=sigma_p, mu_q=mu_q, sigma_q=sigma_q,
                Phi_0=getattr(agent_i, "Phi_0", None),
                phi=phi, phi_tilde=phi_t,
                exp_phi=exp_other, exp_phi_tilde=exp_this,
                eps=eps,
                generators_q=G_q, generators_p=G_p,
            )

        if g_param is None:
            raise RuntimeError("phi_feedback_func returned None; check arguments.")

        g_body = np.einsum("...ji,...j->...i", Jinv, g_param, optimize=True)
        v_body = g_body if Fi is None else np.einsum("...ab,...b->...a", Fi, g_body, optimize=True)
        v_param = np.einsum("...ab,...b->...a", Jinv, v_body, optimize=True)

        fb_contrib = fbw * v_param * mask          # (H,W,A)
        total += fb_contrib

    prev = getattr(agent_i, grad_key, None)
    if prev is None:
        prev = np.zeros_like(total, dtype=np.float32)
    setattr(agent_i, grad_key, prev + total)

    if PRINT_SIGN:
        aid = _aid(agent_i)
        log_phi_grad_like(aid, field, "self", self_contrib)
        log_phi_grad_like(aid, field, "feedback", fb_contrib)
        log_phi_grad_like(aid, field, "total", total)



#==============================================================================
#
#                    WITH RESPECT TO phi_i TERMS
#                       VALIDATED
#==============================================================================




def grad_self_phi_direct(
    mu_q, sigma_q, mu_p, sigma_p, Phi_tilde_0,
    phi, phi_tilde, generators_q, generators_p,
    exp_phi, exp_phi_tilde, *,
    eps=1e-8,
    # NEW fast-paths:
    Phi_tilde=None,          # (H,W,K_q,K_p) from cache
    A_inv_cached=None,       # (H,W,K_q,K_q)  inverse of Φ̃ Σ_p Φ̃ᵀ
    mu_t_cached=None,        # (H,W,K_q)      Φ̃ μ_p
    Q_all=None,
    exp_neg_phi_tilde=None
):
    d, K_q, _ = generators_q.shape

    # Inverse of exp_phi_tilde if needed for dΦ̃
    if exp_neg_phi_tilde is None:
        #print("exp-phi~ is none\n\n\n")
        exp_neg_phi_tilde = safe_omega_inv(exp_phi_tilde)

    # Derivative blocks (still need these)
    if Q_all is None:
        #print("q-all is none\n\n\n")
        Q_all = np.stack(d_exp_exact(phi, generators_q), axis=-3)  # (..., d, K_q, K_q)

    # Pull Φ̃ from cache (or build only if missing)
    if Phi_tilde is None:
        #print("Phi~ is none\n\n\n")
        Phi_tilde = np.einsum("...ik,...kj,...jl->...il",
                              exp_phi, Phi_tilde_0, exp_neg_phi_tilde, optimize=True)

    Phi_tilde_T = np.swapaxes(Phi_tilde, -1, -2)

    # A^{-1} and Φ̃ μ_p: reuse when provided
    if (A_inv_cached is None) or (mu_t_cached is None):
        #print("pushes are none\n\n\n")
        mu_t, _, A_inv = push_gaussian(
            mu=mu_p, Sigma=sigma_p, M=Phi_tilde,
            eps=eps, return_inv=True, assume_orthogonal=False
        )
    else:
        mu_t, A_inv = mu_t_cached, A_inv_cached

    delta_mu = mu_q - mu_t

    # ∂Φ̃_a = Q_a Φ̃₀ e^{-φ̃}
    dPhi = np.einsum("...aik,...kj,...jl->...ail", Q_all, Phi_tilde_0, exp_neg_phi_tilde, optimize=True)
    dPhi_T = np.swapaxes(dPhi, -1, -2)

    # dA = dΦ̃ Σ_p Φ̃ᵀ + Φ̃ Σ_p dΦ̃ᵀ
    dA = (
        np.einsum("...aik,...kl,...lj->...aij", dPhi,       sigma_p, Phi_tilde_T, optimize=True) +
        np.einsum("...ik, ...kl,...alj->...aij", Phi_tilde, sigma_p, dPhi_T,      optimize=True)
    )

    # term1: - (∂Φ̃ μ_p)^T A^{-1} Δμ
    dPhi_mu_p = np.einsum("...aij,...j->...ai", dPhi, mu_p, optimize=True)
    term1 = -np.einsum("...ai,...i->...a",
                       dPhi_mu_p,
                       np.einsum("...ij,...j->...i", A_inv, delta_mu, optimize=True),
                       optimize=True)

    # term2: + 1/2 tr(A^{-1} dA)
    term2 = 0.5 * np.einsum("...ij,...aij->...a", A_inv, dA, optimize=True)

    # M = A^{-1} dA A^{-1}
    M = np.einsum("...ij,...ajk,...kl->...ail", A_inv, dA, A_inv, optimize=True)

    # term3: - 1/2 Δμ^T M Δμ
    term3 = -0.5 * np.einsum("...i,...aij,...j->...a", delta_mu, M, delta_mu, optimize=True)

    # term4: - 1/2 tr(M Σ_q)
    term4 = -0.5 * np.einsum("...aij,...ji->...a", M, sigma_q, optimize=True)

    return (term1 + term2 + term3 + term4).astype(np.float32, copy=False)


def grad_self_phi_tilde_direct(
    mu_q, sigma_q, mu_p, sigma_p, Phi_tilde_0,
    phi, phi_tilde, generators_q, generators_p,
    exp_phi, exp_phi_tilde, *,
    eps=1e-8,
    Phi_tilde=None,          # cached (H,W,K_q,K_p)
    A_inv_cached=None,       # cached (H,W,K_q,K_q)
    mu_t_cached=None,        # cached Φ̃ μ_p
    Q_tilde_all=None,
    exp_neg_phi_tilde=None
):
    d, K_p, _ = generators_p.shape

    if exp_neg_phi_tilde is None:
        #print("e^-phi~ is none\n\n\n")
        exp_neg_phi_tilde = safe_omega_inv(exp_phi_tilde)

    if Q_tilde_all is None:
        #print("Q~-all is none\n\n\n")
        Q_tilde_all = np.stack(d_exp_exact(phi_tilde, generators_p), axis=-3)

    if Phi_tilde is None:
        #print("Phi~ is none\n\n\n")
        Phi_tilde = np.einsum("...ik,...kj,...jl->...il",
                              exp_phi, Phi_tilde_0, exp_neg_phi_tilde, optimize=True)
    Phi_tilde_T = np.swapaxes(Phi_tilde, -1, -2)

    if (A_inv_cached is None) or (mu_t_cached is None):
        mu_t, _, A_inv = push_gaussian(
            mu=mu_p, Sigma=sigma_p, M=Phi_tilde,
            eps=eps, return_inv=True, assume_orthogonal=False
        )
    else:
        mu_t, A_inv = mu_t_cached, A_inv_cached

    delta_mu = mu_q - mu_t

    # R_a = Q̃_a e^{-φ̃}, dΦ̃_a = - Φ̃ R_a
    R    = np.einsum("...aik,...kj->...aij", Q_tilde_all, exp_neg_phi_tilde, optimize=True)
    dPhi = -np.einsum("...ik,...akj->...aij", Phi_tilde, R, optimize=True)
    dPhi_T = np.swapaxes(dPhi, -1, -2)

    dA = (
        np.einsum("...aik,...kl,...lj->...aij", dPhi,       sigma_p, Phi_tilde_T, optimize=True) +
        np.einsum("...ik, ...kl,...alj->...aij", Phi_tilde, sigma_p, dPhi_T,      optimize=True)
    )

    dPhi_mu_p = np.einsum("...aij,...j->...ai", dPhi, mu_p, optimize=True)
    term1 = -np.einsum("...ai,...i->...a",
                       dPhi_mu_p,
                       np.einsum("...ij,...j->...i", A_inv, delta_mu, optimize=True),
                       optimize=True)

    term2 = 0.5 * np.einsum("...ij,...aij->...a", A_inv, dA, optimize=True)

    M = np.einsum("...ij,...ajk,...kl->...ail", A_inv, dA, A_inv, optimize=True)

    term3 = -0.5 * np.einsum("...i,...aij,...j->...a", delta_mu, M, delta_mu, optimize=True)
    term4 = -0.5 * np.einsum("...aij,...ji->...a", M, sigma_q, optimize=True)

    return (term1 + term2 + term3 + term4).astype(np.float32, copy=False)







def grad_feedback_phi_direct(
    mu_p, sigma_p,
    mu_q, sigma_q,
    Phi_0,
    phi,                # (..., d)
    phi_tilde,          # (..., d)
    generators_q,       # (d, K_q, K_q)
    generators_p,
    exp_phi,            # (..., K_q, K_q)
    exp_phi_tilde,      # (..., K_p, K_p)
    eps=1e-8,
    Q_all=None,         # (..., d, K_q, K_q) = d_exp_exact(phi, generators_q)
    exp_neg_phi=None    # (..., K_q, K_q) = e^{-φ}
):
    """
    Vectorized over 'a': returns (..., d)
    Φ = e^{φ̃} Φ₀ e^{-φ}, ∂Φ = - Φ · (e^{-φ} (∂ e^{φ}) e^{-φ})
    """
    
    d, K_q, _ = generators_q.shape

    if exp_neg_phi is None:
        exp_neg_phi = safe_omega_inv(exp_phi)
    if Q_all is None:
        # stack as (..., d, K_q, K_q)
        Q_list = d_exp_exact(phi, generators_q)
        Q_all = np.stack(Q_list, axis=-3)  # assuming list of d arrays

    # Φ and Φᵀ
    Phi = np.einsum("...ik,...kj,...jl->...il", exp_phi_tilde, Phi_0, exp_neg_phi)
    Phi_T = np.swapaxes(Phi, -1, -2)

    # A, A^{-1}
    A = np.einsum("...ik,...kl,...lj->...ij", Phi, sigma_q, Phi_T)
    A = sanitize_sigma(A, eps=eps)
    A_inv = safe_inv(A, eps=eps)

    # Δμ and v
    Phi_mu_q = np.einsum("...ij,...j->...i", Phi, mu_q)
    delta_mu = mu_p - Phi_mu_q
    v = np.einsum("...ij,...j->...i", A_inv, delta_mu)  # (..., K_p)

    # Q̄_a = e^{-φ} Q_a e^{-φ}
    Q_bar = np.einsum("...ik,...akl,...lj->...aij", exp_neg_phi, Q_all, exp_neg_phi)

    # dΦ_a = - Φ Q̄_a
    dPhi = -np.einsum("...ik,...akj->...aij", Phi, Q_bar)
    dPhi_T = np.swapaxes(dPhi, -1, -2)

    # dA_a
    dA = (
        np.einsum("...aik,...kl,...lj->...aij", dPhi, sigma_q, Phi_T) +
        np.einsum("...ik,...kl,...alj->...aij", Phi,  sigma_q, dPhi_T)
    )

    # Term 1
    dPhi_mu = np.einsum("...aij,...j->...ai", dPhi, mu_q)       # (..., a, K_p)
    term1 = -np.einsum("...ai,...i->...a", dPhi_mu, v)

    # Term 2
    term2 = 0.5 * np.einsum("...ij,...aij->...a", A_inv, dA)

    # M_a = A^{-1} dA_a A^{-1}
    M = np.einsum("...ij,...ajk,...kl->...ail", A_inv, dA, A_inv)

    # Term 3
    term3 = -0.5 * np.einsum("...i,...aij,...j->...a", delta_mu, M, delta_mu)

    # Term 4
    term4 = -0.5 * np.einsum("...aij,...ji->...a", M, sigma_p)

    grad = (term1 + term2 + term3 + term4).astype(np.float32, copy=False)
    return grad




def grad_feedback_phi_tilde_direct(
    mu_p, sigma_p,
    mu_q, sigma_q,
    Phi_0,
    phi, 
    phi_tilde,
    generators_q, 
    generators_p,
    exp_phi, 
    exp_phi_tilde,
    eps=1e-8,
    Q_tilde_all=None,       # (..., d, K_p, K_p) = d_exp_exact(phi_tilde, generators_p)
    exp_neg_phi_tilde=None  # (..., K_p, K_p) = e^{-φ̃}
):
    """
    Vectorized over 'a': returns (..., d)
    Left-trivialize: dΦ_a = L_a Φ,  L_a = (∂e^{φ̃}/∂φ̃^a) e^{-φ̃}.
    """
    
    d, K_p, _ = generators_p.shape
    
    if exp_neg_phi_tilde is None:
        exp_neg_phi_tilde = safe_omega_inv(exp_phi_tilde)
    if Q_tilde_all is None:
        Q_list = d_exp_exact(phi_tilde, generators_p)
        Q_tilde_all = np.stack(Q_list, axis=-3)

    # Φ
    exp_neg_phi = safe_omega_inv(exp_phi)
    Phi   = np.einsum("...ik,...kj,...jl->...il", exp_phi_tilde, Phi_0, exp_neg_phi)
    Phi_T = np.swapaxes(Phi, -1, -2)

    
    A = np.einsum("...ik,...kl,...lj->...ij", Phi, sigma_q, Phi_T)
    A = sanitize_sigma(A, eps=eps)
    A_inv = safe_inv(A, eps=eps)

    Phi_mu_q = np.einsum("...ij,...j->...i", Phi, mu_q)
    delta_mu = mu_p - Phi_mu_q
    v = np.einsum("...ij,...j->...i", A_inv, delta_mu)

    # L_a = Q̃_a e^{-φ̃}
    L = np.einsum("...aik,...kj->...aij", Q_tilde_all, exp_neg_phi_tilde)

    # dΦ_a = L_a Φ
    dPhi = np.einsum("...aik,...kj->...aij", L, Phi)
    dPhi_T = np.swapaxes(dPhi, -1, -2)

    dA = (
        np.einsum("...aik,...kl,...lj->...aij", dPhi, sigma_q, Phi_T) +
        np.einsum("...ik,...kl,...alj->...aij", Phi,  sigma_q, dPhi_T)
    )

    dPhi_mu = np.einsum("...aij,...j->...ai", dPhi, mu_q)
    term1 = -np.einsum("...ai,...i->...a", dPhi_mu, v)

    term2 = 0.5 * np.einsum("...ij,...aij->...a", A_inv, dA)

    M = np.einsum("...ij,...ajk,...kl->...ail", A_inv, dA, A_inv)

    term3 = -0.5 * np.einsum("...i,...aij,...j->...a", delta_mu, M, delta_mu)
    term4 = -0.5 * np.einsum("...aij,...ji->...a", M, sigma_p)

    grad = term1 + term2 + term3 + term4
    return grad




def compute_curvature_gradient_analytical(phi, generators, dx: float = 1.0, metric_ab: np.ndarray | None = None):
    """
    ∇_φ Tr(F^2). If generators aren't trace-orthonormal, pass metric_ab = [Tr(G^a G^b)].
    """
    H, W, d = phi.shape
    phi = np.asarray(phi, np.float32)
    G   = np.asarray(generators, np.float32)

    A_x = (np.roll(phi, -1, 0) - np.roll(phi, 1, 0)) / (2 * dx)
    A_y = (np.roll(phi, -1, 1) - np.roll(phi, 1, 1)) / (2 * dx)

    A_x_mat = np.einsum("hwd,dkm->hwkm", A_x, G)
    A_y_mat = np.einsum("hwd,dkm->hwkm", A_y, G)

    dAy_dx = (np.roll(A_y_mat, -1, 0) - np.roll(A_y_mat, 1, 0)) / (2 * dx)
    dAx_dy = (np.roll(A_x_mat, -1, 1) - np.roll(A_x_mat, 1, 1)) / (2 * dx)
    comm_xy = A_x_mat @ A_y_mat - A_y_mat @ A_x_mat
    F_xy = dAy_dx - dAx_dy + comm_xy

    dF_dx = (np.roll(F_xy, -1, 0) - np.roll(F_xy, 1, 0)) / (2 * dx)
    dF_dy = (np.roll(F_xy, -1, 1) - np.roll(F_xy, 1, 1)) / (2 * dx)
    comm1 = A_x_mat @ F_xy - F_xy @ A_x_mat
    comm2 = A_y_mat @ F_xy - F_xy @ A_y_mat
    divF = dF_dx + dF_dy + comm1 + comm2

    if metric_ab is None:
        print("[comp curv grad] metric ab is NONE\n\n\n")
        grad = 2.0 * np.stack([np.einsum("...ij,ij->...", divF, G[a]) for a in range(d)], axis=-1)
    else:
        Ginvs = safe_omega_inv(metric_ab.astype(np.float64, copy=False))
        comps = np.array([np.einsum("...ij,ij->...", divF, G[a]) for a in range(d)])  # (d,H,W)
        grad = 2.0 * np.einsum("ab,b...->a...", Ginvs, comps).transpose(1, 2, 0)
        print("[comp curv grad] metric ab is not NONE\n\n\n")
    return grad.astype(np.float32, copy=False)


# =========================
# Regularization (with toggleable φ–φ̃ coupling)
# =========================




def _apply_lie_natural_regularizers(
    agent_i,
    field: str,
    generators,
    ctx,
    v_body: np.ndarray,
    *,
    agents=None,
    active_idx: np.ndarray | None = None,   # <-- NEW
) -> np.ndarray:
    """
    Add Lie-natural regularizers (already in body coords) with safe broadcasting.
    Handles compacted grids (active_idx) and both (N,A) and (N,K,A) v_body shapes.
    """
    import numpy as np

    reg_nat = apply_regularization_terms_lie_natural(
        agent=agent_i,
        phi_field=np.asarray(getattr(agent_i, field), np.float32),
        generators=generators,
        field=field,
        agents=agents,
        ctx=ctx,
    )
    reg_nat = np.asarray(reg_nat, np.float32)

    # -------- normalize reg_nat shape to (N_full, A) --------
    # Accept (H,W,A) or (H,W,A,1) or already (N_full,A)
    if reg_nat.ndim == 4 and reg_nat.shape[-1] == 1:
        reg_nat = reg_nat[..., 0]  # (H,W,A)
    if reg_nat.ndim == 3:
        H, W, A = reg_nat.shape
        reg_nat = reg_nat.reshape(H * W, A)  # (N_full, A)
    elif reg_nat.ndim == 2:
        # assume already (N_full, A)
        pass
    else:
        # Unknown layout -> disable regularizer safely
        return v_body

    # -------- compact to active sites if requested --------
    if active_idx is not None:
        try:
            reg_nat = reg_nat[active_idx]  # (N_active, A)
        except Exception:
            # Fall back: disable rather than crash
            return v_body

    # -------- broadcast to v_body --------
    # v_body is either (N,A) or (N,K,A)
    if v_body.ndim == 2:
        # (N,A) expected
        if reg_nat.shape == v_body.shape:
            return v_body + reg_nat
        elif reg_nat.ndim == 2 and reg_nat.shape[-1] == v_body.shape[-1]:
            # try to match N dimension via simple broadcast (should already match)
            return v_body + reg_nat
        else:
            return v_body  # mismatch -> no-op
    elif v_body.ndim == 3:
        # (N,K,A) expected
        N, K, A = v_body.shape
        if reg_nat.ndim == 2 and reg_nat.shape == (N, A):
            reg_nat = reg_nat[:, None, :]  # (N,1,A) -> broadcast over K
            return v_body + reg_nat
        elif reg_nat.ndim == 3 and reg_nat.shape == (N, 1, A):
            return v_body + reg_nat
        else:
            return v_body  # mismatch -> no-op
    else:
        # Unknown v_body layout -> no-op
        return v_body




def apply_regularization_terms_lie_natural(
    agent,
    phi_field,
    generators,
    field,
    *,
    agents=None,
    eps=1e-8,
    ctx=None,
):
    
    phi_field = np.asarray(phi_field, np.float32)
    grad_nat  = np.zeros_like(phi_field, dtype=np.float32)
       
    # weights
    curv_w, fisher_w, mass_w, cpl_w = reg_weights(field, ctx=ctx, config=config)
   
# ---- inline which/gen mapping (replaces which_and_gens) ----
    if field == "phi":
        which  = "q"
        gen_q  = generators
        gen_p  = getattr(agent, "generators_p", None)
    elif field == "phi_model":
        which  = "p"
        gen_q  = getattr(agent, "generators_q", None)
        gen_p  = generators
    else:
        raise ValueError(f"Invalid field: {field!r}")

    # quick exit
    if (curv_w == 0.0) and (fisher_w == 0.0) and (mass_w == 0.0) and (cpl_w == 0.0):
        return grad_nat

    # --- mask standardization ---
    tau      = float(cfg_get(ctx, "support_tau", 1e-6))
    mask_vec = mask_hw(agent, tau=tau, mode = "float3")     # -> (H,W,1) float32

    Jinv = Jinv_grid(ctx, agent, which=which)
    if Jinv is None:
        Jinv = build_dexpinv_matrix(phi_field)

    # --- curvature on φ (param covector → body) ---
    if curv_w > 0.0:
        g_param_curv = compute_curvature_gradient_analytical(phi_field, generators)    # (..., d_param)
        g_body_curv  = np.einsum("...ji,...j->...i", Jinv, g_param_curv, optimize=True)
        grad_nat    += curv_w * g_body_curv * mask_vec

    # --- mass: ∂/∂φ (λ/2 ||φ||^2) = λ φ (param covector → body) ---
    if mass_w > 0.0:
        g_param_mass = mass_w * phi_field
        g_body_mass  = np.einsum("...ji,...j->...i", Jinv, g_param_mass, optimize=True)
        grad_nat    += g_body_mass * mask_vec

    # --- q↔p coupling: (1/2)||φ_p - C φ_q||^2 ---
    if cpl_w > 0.0:
        try:
           
            phi_q = np.asarray(getattr(agent, "phi", None), np.float32)
            phi_p = np.asarray(getattr(agent, "phi_model", None), np.float32)
            C = build_c_mapping_q2p(getattr(agent, "Phi_tilde_0", None), gen_q, gen_p, eps=eps)
            #print(f"coupling = {C}")
            if C is not None and phi_q is not None and phi_p is not None:
                # residual in p-space
                r = phi_p - np.einsum("ab,...b->...a", C, phi_q, optimize=True)   # (..., d_p)
               
                if field == "phi":
                    # ∂L/∂φ_q = - C^T r  (param covector)
                    g_param = -np.einsum("ba,...a->...b", C, r, optimize=True)    # (..., d_q)
                else:
                    # ∂L/∂φ_p = r
                    g_param = r
                g_body_cpl = np.einsum("...ji,...j->...i", Jinv, g_param, optimize=True)
                grad_nat   += cpl_w * g_body_cpl * mask_vec
               # print(f"{grad_nat}")
        except Exception as e:
            print(f"[DBGALIGN-WARN] reg coupling failed: {type(e).__name__}: {e}", flush=True)

    return np.asarray(grad_nat, np.float32)



def OLDgrad_kl_wrt_phi_i(
    mu_i, sigma_i,
    mu_j, sigma_j,                 # unused; kept for signature compatibility
    phi_i, phi_j,                  # unused here
    Omega_ij,
    generators,
    exp_phi_i,
    exp_phi_j,
    mu_j_t,                        
    sigma_j_t_inv,                 
    eps=1e-8,
    exp_neg_phi_j=None,
    Q_all=None,
):
        
    # ---- cast to f64 for internal math ----
    mu_i   = np.asarray(mu_i,   np.float64)
    mu_j_t = np.asarray(mu_j_t, np.float64)

    Sigma_i = sanitize_sigma(np.asarray(sigma_i, np.float64), eps=eps)
   
    # Q_all → (..., a, K, K)
    if Q_all is None:
        Q_all = d_exp_exact(np.asarray(phi_i, np.float64), generators)
    
    Q = np.stack([np.asarray(x, np.float64) for x in Q_all], axis=-3)

    # exp(-phi_j) broadcast to Q lead dims
    if exp_neg_phi_j is None:
        exp_neg_phi_j = safe_omega_inv(np.asarray(exp_phi_j, np.float64))
   
    # Ω and Ω^{-1}
    Om   = np.asarray(Omega_ij, np.float64)
    Oinv = safe_omega_inv(Om).astype(np.float64, copy=False)

    # Sanity on provided precision
    Sj_inv = np.asarray(sigma_j_t_inv, np.float64)
    
    Sj_inv = 0.5 * (Sj_inv + np.swapaxes(Sj_inv, -1, -2))
    
    # Core pieces
    delta_mu = (mu_i - mu_j_t)                     # (..., K)
    mu_j_src = np.einsum("...ij,...j->...i", Oinv, mu_j_t, optimize=True)  # (..., K)

    # dΩ/dφ_i^a = Q[a] @ e^{-φ_j}
    Q = np.einsum("...aik,...kj->...aij", Q, exp_neg_phi_j, optimize=True)
    Q_T = np.swapaxes(Q, -1, -2)
   
    # dΩ Ω^{-1}
    Q_tilde   = np.einsum("...aik,...kj->...aij", Q, Oinv, optimize=True)  
    Qtilde_T  = np.swapaxes(Q_tilde, -1, -2)
    
    # ---- precision (trace) term:  -1/2 * ⟨ A, Q̃ Σ_i + Σ_i Q̃^T ⟩
    t1 = np.einsum("...ij,...ajk,...ki->...a", Sj_inv, Q_tilde,  Sigma_i, optimize=True)
    t2 = np.einsum("...aij,...jk, ...ki->...a", Qtilde_T, Sj_inv, Sigma_i, optimize=True)
    trace_term = -0.5 * (t1 + t2)
    
    # mean term
    tmp1 = np.einsum("...aij,...j->...ai", Q_T,    delta_mu, optimize=True)
    tmp2 = np.einsum("...ij,...aj->...ai", Sj_inv, tmp1,     optimize=True)
    mean_term = -np.einsum("...i,...ai->...a", mu_j_src, tmp2, optimize=True)
    
    # ---- Mahalanobis (through ∂A) term: +1/2 * Δμ^T ( A Q̃ + Q̃^T A ) Δμ
    v1 = np.einsum("...ij,...j->...i", Sj_inv, delta_mu, optimize=True)          # A Δμ
    part1 = np.einsum("...aij,...j->...ai", Qtilde_T, v1, optimize=True)         # Q̃^T A Δμ
    v2    = np.einsum("...aij,...j->...ai", Q_tilde,  delta_mu, optimize=True)   # Q̃ Δμ
    part2 = np.einsum("...ij,...aj->...ai", Sj_inv,   v2, optimize=True)         # A Q̃ Δμ
    mahal_term = 0.5 * np.einsum("...i,...ai->...a", delta_mu, part1 + part2, optimize=True)


    # ---- previous gradients -possibly incorrect? ----
    # trace term
   # t1 = np.einsum("...ij,...ajk,...ki->...a", Sj_inv, Q,   Sigma_i, optimize=True)
   # t2 = np.einsum("...aij,...jk,...ki->...a", Q_T,   Sj_inv, Sigma_i, optimize=True)
   # trace_term = -0.5 * (t1 + t2)

    # Mahalanobis term
   # v1 = np.einsum("...ij,...j->...i", Sj_inv, delta_mu, optimize=True)
   # part1 = np.einsum("...aij,...j->...ai", Q_T, v1,           optimize=True)
   # v2    = np.einsum("...aij,...j->...ai", Q,   delta_mu,     optimize=True)
   # part2 = np.einsum("...ij,...aj->...ai", Sj_inv, v2,        optimize=True)
   # mahal_term = 0.5 * np.einsum("...i,...ai->...a", delta_mu, part1 + part2, optimize=True)

    grad = (trace_term + mean_term + mahal_term)
    
    return grad




def Qgrad_self_phi_direct(
    mu_q, sigma_q,
    mu_p, sigma_p,
    Phi_tilde_0,
    phi, 
    phi_tilde,
    generators_q, 
    generators_p,
    exp_phi,
    exp_phi_tilde,
    eps=1e-8,
    Q_all=None,               # (..., d, K_q, K_q)
    exp_neg_phi_tilde=None    # (..., K_p, K_p)
):
    """
    Vectorized over 'a': returns (..., d)
    Φ̃ = e^{φ} Φ̃₀ e^{-φ̃},  ∂Φ̃_a = (∂e^{φ}/∂φ^a) Φ̃₀ e^{-φ̃}.
    """
    d, K_q, _ = generators_q.shape
    
    if exp_neg_phi_tilde is None:
        exp_neg_phi_tilde = safe_omega_inv(exp_phi_tilde)
    if Q_all is None:
        Q_list = d_exp_exact(phi, generators_q)
        Q_all = np.stack(Q_list, axis=-3)

    # Φ̃ and A
    Phi_tilde = np.einsum("...ik,...kj,...jl->...il", exp_phi, Phi_tilde_0, exp_neg_phi_tilde)
    Phi_tilde_T = np.swapaxes(Phi_tilde, -1, -2)

    A = np.einsum("...ik,...kl,...lj->...ij", Phi_tilde, sigma_p, Phi_tilde_T)
    A = sanitize_sigma(A, eps=eps)
    A_inv = safe_inv(A, eps=eps)

    delta_mu = mu_q - np.einsum("...ij,...j->...i", Phi_tilde, mu_p)

    # ∂Φ̃_a = Q_a Φ̃₀ e^{-φ̃}
    dPhi = np.einsum("...aik,...kj,...jl->...ail", Q_all, Phi_tilde_0, exp_neg_phi_tilde)
    dPhi_T = np.swapaxes(dPhi, -1, -2)

    dA = (
        np.einsum("...aik,...kl,...lj->...aij", dPhi, sigma_p, Phi_tilde_T) +
        np.einsum("...ik,...kl,...alj->...aij", Phi_tilde, sigma_p, dPhi_T)
    )

    # Term 1
    dPhi_mu_p = np.einsum("...aij,...j->...ai", dPhi, mu_p)
    term1 = -np.einsum("...ai,...i->...a", dPhi_mu_p, np.einsum("...ij,...j->...i", A_inv, delta_mu))

    # Term 2   (note: your earlier self/feedback sign conventions differ; keeping your current one)
    term2 = 0.5 * np.einsum("...ij,...aij->...a", A_inv, dA)

    # M = A^{-1} dA A^{-1}
    M = np.einsum("...ij,...ajk,...kl->...ail", A_inv, dA, A_inv)

    # Term 3
    term3 = -0.5 * np.einsum("...i,...aij,...j->...a", delta_mu, M, delta_mu)

    # Term 4
    term4 = -0.5 * np.einsum("...aij,...ji->...a", M, sigma_q)

    grad = term1 + term2 + term3 + term4
    return grad


def Qgrad_self_phi_tilde_direct(
    mu_q, sigma_q,
    mu_p, sigma_p,
    Phi_tilde_0,
    phi, 
    phi_tilde,
    generators_q, 
    generators_p,
    exp_phi, 
    exp_phi_tilde,
    eps=1e-8,
    Q_tilde_all=None,         # (..., d, K_p, K_p)
    exp_neg_phi_tilde=None    # (..., K_p, K_p)
):
    """
    Vectorized over 'a': returns (..., d)
    Right-trivialize on model: R_a = (∂e^{φ̃}/∂φ̃^a) e^{-φ̃},  ∂Φ̃_a = - Φ̃ R_a.
    """
    d, K_p, _ = generators_p.shape
    
    if exp_neg_phi_tilde is None:
        exp_neg_phi_tilde = safe_omega_inv(exp_phi_tilde)
    
    if Q_tilde_all is None:
        Q_list = d_exp_exact(phi_tilde, generators_p)
        Q_tilde_all = np.stack(Q_list, axis=-3)

    Phi_tilde = np.einsum("...ik,...kj,...jl->...il", exp_phi, Phi_tilde_0, exp_neg_phi_tilde)
    Phi_tilde_T = np.swapaxes(Phi_tilde, -1, -2)
  
    A = np.einsum("...ik,...kl,...lj->...ij", Phi_tilde, sigma_p, Phi_tilde_T)
    A = sanitize_sigma(A, eps=eps)
    A_inv = safe_inv(A, eps=eps)

    mu_t = np.einsum("...ij,...j->...i", Phi_tilde, mu_p)
    delta_mu = mu_q - mu_t

    # R_a = Q̃_a e^{-φ̃}
    R = np.einsum("...aik,...kj->...aij", Q_tilde_all, exp_neg_phi_tilde)

    # dΦ̃_a = - Φ̃ R_a
    dPhi = -np.einsum("...ik,...akj->...aij", Phi_tilde, R)
    dPhi_T = np.swapaxes(dPhi, -1, -2)

    dA = (
        np.einsum("...aik,...kl,...lj->...aij", dPhi, sigma_p, Phi_tilde_T) +
        np.einsum("...ik,...kl,...alj->...aij", Phi_tilde, sigma_p, dPhi_T)
    )

    dPhi_mu_p = np.einsum("...aij,...j->...ai", dPhi, mu_p)
    term1 = -np.einsum("...ai,...i->...a", dPhi_mu_p, np.einsum("...ij,...j->...i", A_inv, delta_mu))

    term2 = 0.5 * np.einsum("...ij,...aij->...a", A_inv, dA)

    M = np.einsum("...ij,...ajk,...kl->...ail", A_inv, dA, A_inv)

    term3 = -0.5 * np.einsum("...i,...aij,...j->...a", delta_mu, M, delta_mu)
    term4 = -0.5 * np.einsum("...aij,...ji->...a", M, sigma_q)

    grad = term1 + term2 + term3 + term4
    return grad
