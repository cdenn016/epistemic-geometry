import argparse
import pickle
import pathlib
import re
from typing import Sequence

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt


def load_metric_log_pkl(path: pathlib.Path) -> pd.DataFrame:
    """Load metric_log.pkl → DataFrame (one row per step)."""
    if not path.exists():
        raise FileNotFoundError(f"Metric log not found: {path}")
    with open(path, "rb") as f:
        log = pickle.load(f)
    return pd.DataFrame(log)


def load_per_agent_csv(path: pathlib.Path) -> pd.DataFrame:
    """Load per_agent_metrics.csv if present, else empty DF."""
    if path.exists():
        return pd.read_csv(path)
    return pd.DataFrame()





def plot_scalar_series(steps, values, ylabel: str, title: str, save_path: pathlib.Path):
    plt.figure()
    plt.plot(steps, values, linewidth=1.5)
    plt.xlabel("Simulation step")
    plt.ylabel(ylabel)
    plt.title(title)
    plt.tight_layout()
    plt.savefig(save_path, dpi=150)
    plt.close()


# --- replace numeric_columns with a slightly safer version ---
def numeric_columns(df: pd.DataFrame, skip: Sequence[str] = ()) -> list[str]:
    """Return numeric columns excluding 'step' and any in skip."""
    cols = []
    for c in df.columns:
        if c == "step" or c in skip:
            continue
        if pd.api.types.is_numeric_dtype(df[c]):
            cols.append(c)
    return cols

# --- add helpers for energy columns detection (global vs per-agent) ---
GLOBAL_ENERGY_ORDER = [
    "e_self","e_feedback","e_align","e_mod_align",
    "e_curv","e_curv_mod","e_mass","e_mass_mod"
]

PER_AGENT_ENERGY_ORDER = [
    "kl_self","kl_feedback","kl_align","kl_mod_align",
    "curv_energy","curv_model_energy","mass_energy","mass_model_energy"
]

def present_cols(df: pd.DataFrame, wanted: Sequence[str]) -> list[str]:
    return [c for c in wanted if c in df.columns]

# --- replace plot_scalar_series unchanged (fine) ---

def main(
    outdir: pathlib.Path,
    figs_dir: pathlib.Path,
    *,
    aggregate: str = "mean",
):
    figs_dir.mkdir(parents=True, exist_ok=True)

    # 1) Global metrics (metric_log.pkl)
    try:
        df_global = load_metric_log_pkl(outdir / "metric_log.pkl")
    except FileNotFoundError:
        df_global = pd.DataFrame()

    if df_global.empty:
        print("[WARN] metric_log.pkl is empty or missing.")
    else:
        # ensure sorted by step if present
        if "step" in df_global.columns:
            df_global = df_global.sort_values("step")
        # plot all numeric series (skips step/schema/strings automatically)
        num_cols_g = numeric_columns(df_global, skip=("compute_ms",))
        for col in num_cols_g:
            plot_scalar_series(
                df_global["step"], df_global[col],
                ylabel=col, title=f"{col} (global)",
                save_path=figs_dir / f"{col}_global.png",
            )
        # stacked global energy budget from e_* keys (if present)
        ecols_g = present_cols(df_global, GLOBAL_ENERGY_ORDER)
        if ecols_g:
            plt.figure(figsize=(8,5))
            bottom = np.zeros(len(df_global))
            for col in ecols_g:
                plt.bar(df_global["step"], df_global[col], bottom=bottom, label=col, width=1.0)
                bottom += df_global[col].values
            plt.xlabel("Simulation step")
            plt.ylabel("normalized energy")
            plt.title("Global energy budget (stacked)")
            plt.legend(fontsize=7, frameon=False, ncol=2)
            plt.tight_layout()
            plt.savefig(figs_dir / "global_energy_budget_stacked.png", dpi=150)
            plt.close()

    # 2) Per-agent metrics
    df_agent = load_per_agent_csv(outdir / "per_agent_metrics.csv")
    if df_agent.empty:
        print("[INFO] per_agent_metrics.csv not found – skipping per-agent plots.")
        print(f"[DONE] Figures → {figs_dir.resolve()}")
        return

    if "step" in df_agent.columns:
        df_agent = df_agent.sort_values(["step","agent"])

    num_cols_a = numeric_columns(df_agent, skip=("agent",))
    # 2a) Aggregated per-agent (mean or sum)
    grouped = df_agent.groupby("step", sort=True)
    agg_df = getattr(grouped, aggregate)()
    for col in num_cols_a:
        plot_scalar_series(
            agg_df.index, agg_df[col],
            ylabel=f"{aggregate}({col})",
            title=f"{col} ({aggregate} across agents)",
            save_path=figs_dir / f"{col}_{aggregate}.png",
        )

    # stacked per-agent energy (use kl_* + curv_* + mass_* names)
    ecols_a = present_cols(agg_df, PER_AGENT_ENERGY_ORDER)
    if ecols_a:
        plt.figure(figsize=(8,5))
        bottom = np.zeros(len(agg_df))
        for col in ecols_a:
            plt.bar(agg_df.index, agg_df[col], bottom=bottom, label=col, width=1.0)
            bottom += agg_df[col].values
        plt.xlabel("Simulation step")
        plt.ylabel(f"{aggregate} energy per agent")
        plt.title("Per-agent energy budget (stacked)")
        plt.legend(fontsize=7, frameon=False, ncol=2)
        plt.tight_layout()
        plt.savefig(figs_dir / "per_agent_energy_budget_stacked.png", dpi=150)
        plt.close()

    # 2b) Individual agent plots (for the most informative columns only)
    informative = set(PER_AGENT_ENERGY_ORDER) | {"phi_norm","phi_model_norm","support"}
    cols_individual = [c for c in num_cols_a if c in informative]
    agents = sorted(df_agent["agent"].unique())
    for col in cols_individual:
        plt.figure(figsize=(8,4))
        for ag in agents:
            sub = df_agent[df_agent["agent"] == ag]
            plt.plot(sub["step"], sub[col], label=f"a{ag}", linewidth=1)
        plt.xlabel("Simulation step")
        plt.ylabel(col)
        plt.title(f"{col} by agent")
        plt.legend(ncol=4, fontsize="small", frameon=False)
        plt.tight_layout()
        plt.savefig(figs_dir / f"{col}_by_agent.png", dpi=150)
        plt.close()

    print(f"[DONE] Figures → {figs_dir.resolve()}")


if __name__ == '__main__':
    # No CLI. Use hardcoded defaults.
    OUTDIR = pathlib.Path("checkpoints")
    FIGDIR = pathlib.Path("Plots")
    AGG = "mean"  # or "sum"

    main(
        OUTDIR,
        FIGDIR,
        aggregate=AGG,
    )

