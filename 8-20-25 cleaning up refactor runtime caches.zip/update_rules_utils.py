# -*- coding: utf-8 -*-
"""
Created on Tue Aug 12 20:10:51 2025

@author: chris and christine
"""

import numpy as np
from preprocess_utils import build_all_omega_caches, build_all_lambda_caches, preprocess_all_agents
from runtime_context import _collect_by_ids
from gaussian_core import directed_kl_weight_after_transport
from omega import exp_grid_cached





def _assign_children_to_parents( 
    children,
    parents_by_id,
    *,
    eps=1e-3,
    tau=0.30,
    temp=0.25,
    max_parents_per_child=2,
    core_tau=None,
    core_tau_rel=0.50,
    core_dilate_px=1,
    newborn_bootstrap_steps=2,
    allow_unassigned=True,
    agreement_map=None,           # e.g. runtime_ctx.Aq_agg / Ap_agg
    use_agreement=None,
    agree_weight=None,            # now used as λ in log-add: z += λ·log(A)
    debug=False,
):
    import numpy as np
    import config
    try:
        from scipy.ndimage import binary_dilation
    except Exception:
        binary_dilation = None

    from parent_utils import resize_nn  # unified NN resizer

    Ps = list(parents_by_id.values())
    Pn = len(Ps); I = len(children)

    # trivial exits
    if Pn == 0 or I == 0:
        for ch in children:
            setattr(ch, "labels", {}); setattr(ch, "parent_id", -1)
        for P in Ps:
            P.child_weights = {}; P.child_ids = ()
        return

    # shapes
    H, W = np.asarray(children[0].mask).shape[:2]

    # knobs
    if use_agreement is None:
        use_agreement = bool(getattr(config, "parent_assign_use_agreement", False))
    if agree_weight is None:
        agree_weight = float(getattr(config, "parent_assign_agree_weight", 1.0))

    activation   = str(getattr(config, "parent_assign_activation", "entmax")).lower()  # "softmax"|"sparsemax"|"entmax"
    null_enabled = bool(getattr(config, "parent_assign_null_enabled", True))
    null_logit   = float(getattr(config, "parent_assign_null_logit", 0.0))
    null_tau     = float(getattr(config, "parent_assign_null_tau", 0.5))

    # optional entropy calibration (keeps distributions from collapsing)
    cal = None
    if getattr(config, "parent_assign_target_entropy", None) is not None:
        cal = {"target_H": float(getattr(config, "parent_assign_target_entropy", 1.0)),
               "k":       float(getattr(config, "parent_assign_temp_k", 0.4))}

    # child boolean masks (already standardized in _pre_light)
    Cmb = [(np.asarray(ch.mask, np.float32) > float(eps)) for ch in children]

    # parent masks array (sanitize once)
    Pmasks = [np.nan_to_num(np.asarray(P.mask, np.float32), nan=0.0, posinf=0.0, neginf=0.0) for P in Ps]

    abs_core = float(core_tau if core_tau is not None
                     else getattr(config, "parent_growth_core_tau", 0.20))
    rel_core = float(core_tau_rel)

    # parent cores
    Pcore = []
    for idx, pm in enumerate(Pmasks):
        mmax = float(pm.max()) if pm.size else 0.0
        thr  = max(abs_core, rel_core * mmax)
        age  = int(getattr(Ps[idx], "_age", 0) or 0)
        if age < int(newborn_bootstrap_steps):
            thr *= 0.6  # relax for newborns
        core = (pm > thr)
        if core_dilate_px and binary_dilation is not None and core.any():
            core = binary_dilation(core, iterations=int(core_dilate_px))
        Pcore.append(core)

    # agreement map (optional)
    A_map = None
    if use_agreement and (agreement_map is not None):
        A_map = np.asarray(agreement_map, np.float32)
        if A_map.shape[:2] != (H, W):
            try:
                A_map = resize_nn(A_map, (H, W)).astype(np.float32)
            except Exception:
                A_map = None
        if A_map is not None:
            A_map = np.clip(np.nan_to_num(A_map, nan=0.0, posinf=1.0, neginf=0.0), 0.0, 1.0)

    # -------------------- build IoU scores + (per-child) agreement vectors --------------------
    S = np.full((I, Pn), -np.inf, np.float32)  # IoU on cores (base scores)
    A = np.ones((I, Pn),  np.float32)          # mean agreement on child∧core
    valid = np.zeros((I, Pn), bool)

    for i, cm in enumerate(Cmb):
        if not cm.any():
            continue
        for p, core in enumerate(Pcore):
            if not core.any():
                continue
            ov = (cm & core)
            inter = int(ov.sum())
            if inter == 0:
                continue

            union = int((cm | core).sum())
            base = float(inter) / float(max(1, union))  # IoU on core
            S[i, p] = base
            valid[i, p] = (base >= float(tau))  # keep τ as a validity gate

            if A_map is not None:
                a = float(np.nanmean(A_map[ov])) if ov.any() else 0.0
                if not np.isfinite(a): a = 0.0
                A[i, p] = np.clip(a, 1e-6, 1.0)  # for log-add later

    # -------------------- normalize per child using your helper --------------------
    W = np.zeros((I, Pn), np.float32)  # final parent weights (no null here)
    entropy_list, top1_mass_list, null_mass_list, support_size_list = [], [], [], []

    for i in range(I):
        score_vec = S[i]
        valid_mask = valid[i]
        if not np.any(valid_mask):
            continue

        agree_vec = (A[i] if (A_map is not None and use_agreement) else None)

        # NOTE: _normalize_assignments is your helper (already added elsewhere)
        probs_all = _normalize_assignments(
            scores=score_vec[valid_mask],         # only pass valid parents
            agree=(agree_vec[valid_mask] if agree_vec is not None else None),
            valid_mask=None,                      # already filtered
            temp=float(temp),
            activation=activation,
            agree_weight=float(agree_weight),
            null_enabled=bool(null_enabled),
            null_logit=float(null_logit),
            calibrate=cal
        )
        # reconstruct into full parent index space
        if null_enabled:
            p_eff = probs_all[:-1]  # parents only
            p_null = float(probs_all[-1])
        else:
            p_eff = probs_all
            p_null = 0.0

        # map back to absolute indices
        idxs = np.where(valid_mask)[0]
        W[i, idxs] = p_eff

        # optional top-k AFTER normalization (keeps sparsemax/entmax sparsity)
        if max_parents_per_child and max_parents_per_child < len(idxs):
            k = int(max_parents_per_child)
            row = W[i, :]
            keep = idxs[np.argsort(-row[idxs])[:k]]
            pruned = np.setdiff1d(idxs, keep, assume_unique=False)
            if pruned.size:
                row[pruned] = 0.0
            s = row[keep].sum()
            if s > 0:
                row[keep] /= s
            W[i, :] = row

        # allow_unassigned vs. null
        if not allow_unassigned:
            # if all mass went null or zero, force best IoU parent
            if (W[i].sum() <= 0.0) or (null_enabled and p_null >= null_tau):
                # lenient fallback on raw parent masks (not cores)
                cm = Cmb[i]
                best_p, best_iou = -1, -1.0
                for p, pm in enumerate(Pmasks):
                    union = int((cm | (pm > 0)).sum())
                    if union == 0: continue
                    inter = int((cm & (pm > 0)).sum())
                    iou = float(inter) / float(union)
                    if iou > best_iou:
                        best_iou, best_p = iou, p
                if best_p >= 0 and best_iou > 0.0:
                    W[i, :] = 0.0
                    W[i, best_p] = 1.0

        # diagnostics
        peff = W[i, :]
        if peff.sum() > 0:
            peff_nz = peff[peff > 0]
            ent = -float(np.sum(peff_nz * np.log(peff_nz + 1e-20)))
            top1 = float(peff_nz.max()) if peff_nz.size else 1.0
            supp = int((peff > 1e-3).sum())
        else:
            ent, top1, supp = 0.0, 1.0, 0
        entropy_list.append(ent)
        top1_mass_list.append(top1)
        null_mass_list.append(p_null)
        support_size_list.append(supp)

    # -------------------- write back to children --------------------
    for i, ch in enumerate(children):
        # collect all nonzero parents with weights
        pairs = [(int(getattr(Ps[p], "id", p)), float(W[i, p]))
                 for p in range(Pn) if W[i, p] > 0.0]
    
        # sort by weight desc and cap to max_parents_per_child (already sparsified, but be safe)
        if pairs:
            pairs.sort(key=lambda t: -t[1])
            if max_parents_per_child and len(pairs) > int(max_parents_per_child):
                pairs = pairs[:int(max_parents_per_child)]
    
            # renormalize selected weights to 1.0
            s = sum(w for _, w in pairs)
            if s > 0:
                pairs = [(pid, w / s) for (pid, w) in pairs]
    
            # write labels + ids
            ch.labels = {pid: w for (pid, w) in pairs}
            ch.parent_ids = [pid for (pid, _) in pairs]
            ch.parent_id = int(ch.parent_ids[0]) if ch.parent_ids else -1
        else:
            # unassigned
            ch.labels = {}
            ch.parent_ids = []
            ch.parent_id = -1


    # -------------------- write back to parents --------------------
    # -------------------- write back to parents --------------------
    for p, P in enumerate(Ps):
        weights = {}
        ids = []
        for i, ch in enumerate(children):
            w = float(W[i, p])
            if w > 0.0:
                cid = int(getattr(ch, "id", i))
                weights[cid] = w
                ids.append(cid)
    
        # Optional: renormalize parent’s incoming weights to sum to 1 over its children
        s = sum(weights.values())
        if s > 0.0:
            for k in list(weights.keys()):
                weights[k] = weights[k] / s
    
        P.child_weights = weights
        P.child_ids = tuple(sorted(ids))


    # -------------------- debug summary --------------------
    if debug or bool(getattr(config, "debug_assign_summary", False)):
        Hm  = float(np.mean(entropy_list)) if entropy_list else 0.0
        T1m = float(np.mean(top1_mass_list)) if top1_mass_list else 0.0
        Nul = float(np.mean(null_mass_list)) if null_mass_list else 0.0
        FrN = float(np.mean([x >= null_tau for x in null_mass_list])) if null_enabled and null_mass_list else 0.0
        Sup = float(np.mean(support_size_list)) if support_size_list else 0.0
        print(f"[ASSIGN] act={activation} temp={float(temp):.3f} "
              f"Hmean={Hm:.3f} top1={T1m:.3f} null_mean={Nul:.3f} null>τ={FrN:.2f} "
              f"support_mean={Sup:.2f}")
        for p, P in enumerate(Ps):
            wsum = float(sum((P.child_weights or {}).values()))
            print(f"    P{getattr(P,'id',p)} kids={len(P.child_ids)} wsum={wsum:.3g}")






def assign_parent_masks_from_alignment(ctx, children,
                                       generators_q, generators_p,
                                       *,
                                       mode="max",                # "max" or "mean"
                                       mask_tau=0.10,
                                       tau_q=None, tau_p=None, alpha=0.5,
                                       agree_map=None, agree_power=1.0,
                                       clamp_to_union=True,
                                       floor_eps=1e-6,
                                       min_pair_px=8,
                                       kl_cap=None,               # remains in signature (unused here)
                                       pnorm=99.0,
                                       return_changed=False,      # NEW
                                       change_tol=None):          # NEW
    """
    Gauge-covariant parent mask assignment (pure evidence, no dilation).
    Uses CacheHub to reuse exp(±φ), Ω fields, and per-child mask gates/supports.
    """
    import numpy as np
    from update_rules_utils import (
        _agreement_prior_map, _capture_prev_masks, _detect_changed_parents,
        _mask_gate, _support_bool, CFG
    )
    from gaussian_core import directed_kl_weight_after_transport
    from transport_cache import warm_E

    parents = getattr(ctx, "parents_by_region", {}) or {}
    if not parents or not children:
        return [] if return_changed else None

    # config defaults
    if tau_q is None:
        tau_q = float(CFG("tau_align_q", 0.45))
    if tau_p is None:
        tau_p = float(CFG("tau_align_p", 0.45))

    H, W = np.asarray(children[0].mask, dtype=np.float32).shape[:2]
    A = _agreement_prior_map(agree_map, H, W)

    # ---- Prewarm exp grids for all children (central cache) -----------------
    kq = int(getattr(children[0].mu_q_field, "shape", (0, 0, 0))[-1]) if children[0] is not None else 0
    kp = int(getattr(children[0].mu_p_field, "shape", (0, 0, 0))[-1]) if children[0] is not None else 0
    whiches = tuple(w for w, k in (("q", kq), ("p", kp)) if k > 0)
    if whiches:
        try:
            warm_E(ctx, children, whiches=whiches)
        except Exception:
            pass  # fine—Ω calls will compute on demand

    # ---- Cache helpers ------------------------------------------------------
    hub = getattr(ctx, "cache", None)
    ns_misc = hub.ns("misc") if hub is not None else {}

    def _mask_gate_cached(ch):
        key = ("mask_gate", int(ch.id), float(mask_tau), H, W)
        if key in ns_misc:
            return ns_misc[key]
        mg = _mask_gate(ch.mask, mask_tau).astype(np.float32, copy=False)
        if hub is not None:
            ns_misc[key] = mg
        return mg

    def _support_bool_cached(ch):
        key = ("support_bool", int(ch.id), float(mask_tau), H, W)
        if key in ns_misc:
            return ns_misc[key]
        sb = _support_bool(ch.mask, mask_tau)
        if hub is not None:
            ns_misc[key] = sb
        return sb

    # id -> child
    by_id = {int(ch.id): ch for ch in children}

    # capture masks before changes (if needed)
    prev_masks = _capture_prev_masks(ctx) if return_changed else None

    for rid, P in parents.items():
        base_ids = list(getattr(P, "child_ids", []) or [])
        assigned_ids = list(getattr(P, "assigned_child_ids", []) or [])

        # coalition choice
        eff_ids = sorted(set(assigned_ids)) if len(assigned_ids) >= 2 else sorted(set(assigned_ids) | set(base_ids))
        if len(eff_ids) < 2:
            P.mask = np.zeros((H, W), np.float32); P.emerged = False; continue

        Kkids = [by_id.get(int(k)) for k in eff_ids]
        Kkids = [ch for ch in Kkids if ch is not None]
        if len(Kkids) < 2:
            P.mask = np.zeros((H, W), np.float32); P.emerged = False; continue

        # gates and union clamp (cached)
        masks_gated  = [_mask_gate_cached(ch) for ch in Kkids]
        present_bool = [_support_bool_cached(ch) for ch in Kkids]

        union_gate = None
        if clamp_to_union:
            union_gate = np.zeros((H, W), np.float32)
            for pb in present_bool:
                union_gate = np.maximum(union_gate, pb.astype(np.float32))

        # admissible domain: at least two kids present
        present_stack = np.stack(present_bool, axis=0).astype(np.int16)
        domain = (present_stack.sum(axis=0) >= 2)
        if not np.any(domain):
            P.mask = np.zeros((H, W), np.float32); P.emerged = False; continue

        acc = np.zeros((H, W), np.float32)
        if mode == "mean":
            cnt = np.zeros((H, W), np.float32)

        klen = len(Kkids)
        for a in range(klen):
            for b in range(a + 1, klen):
                Ci, Cj = Kkids[a], Kkids[b]
                mi, mj = masks_gated[a], masks_gated[b]

                support = (present_bool[a] & present_bool[b] & domain)
                if support.sum() < min_pair_px:
                    continue

                Kq_i = int(Ci.mu_q_field.shape[-1]) if getattr(Ci, "mu_q_field", None) is not None else 0
                Kp_i = int(Ci.mu_p_field.shape[-1]) if getattr(Ci, "mu_p_field", None) is not None else 0

                # q-bundle weight (ctx + explicit generators)
                wq = directed_kl_weight_after_transport(
                    Ci, Cj,
                    Ci.mu_q_field, Ci.sigma_q_field,
                    Cj.mu_q_field, Cj.sigma_q_field,
                    fiber="q", H=H, W=W, K=Kq_i,
                    ov=support, tau=max(1e-12, float(tau_q)),
                    assume_diag_is_stddev=True, debug=False,
                    ctx=ctx, G=generators_q,
                ) if Kq_i > 0 else np.ones((H, W), np.float32)

                # p-bundle weight
                wp = directed_kl_weight_after_transport(
                    Ci, Cj,
                    Ci.mu_p_field, Ci.sigma_p_field,
                    Cj.mu_p_field, Cj.sigma_p_field,
                    fiber="p", H=H, W=W, K=Kp_i,
                    ov=support, tau=max(1e-12, float(tau_p)),
                    assume_diag_is_stddev=True, debug=False,
                    ctx=ctx, G=generators_p,
                ) if Kp_i > 0 else np.ones((H, W), np.float32)

                # blend q/p, gate by masks and optional agreement prior
                w = (wq ** (1.0 - float(alpha))) * (wp ** float(alpha))
                w *= (mi * mj)
                if A is not None:
                    w *= (A ** float(agree_power))

                if mode == "max":
                    acc = np.maximum(acc, w)
                else:
                    acc += w
                    cnt += (w > 0).astype(np.float32)

        if mode == "mean":
            acc = acc / (cnt + float(floor_eps))

        # clamp & restrict to domain
        if union_gate is not None:
            acc *= union_gate
        acc *= domain.astype(np.float32)

        # percentile normalization (dynamic range)
        dom_vals = acc[domain]
        if dom_vals.size == 0 or np.all(dom_vals <= float(floor_eps)):
            P.mask = np.zeros((H, W), np.float32); P.emerged = False; continue

        scale = float(np.percentile(dom_vals, float(pnorm)))
        if not np.isfinite(scale) or scale <= float(floor_eps):
            scale = float(dom_vals.max())
        if scale <= float(floor_eps):
            P.mask = np.zeros((H, W), np.float32); P.emerged = False; continue

        acc = acc / scale
        acc = np.clip(np.nan_to_num(acc, nan=0.0, posinf=1.0, neginf=0.0), 0.0, 1.0)
        acc *= domain.astype(np.float32)

        P.mask = acc.astype(np.float32)
        P.emerged = True

    if return_changed:
        return _detect_changed_parents(ctx, prev_masks, change_tol)
    # else no return (backward-compatible)





def build_alignment_aggregates(runtime_ctx, children, *, kl_cap=10.0):
    """
    Aggregates per-child caches into step-level fields on runtime_ctx:
      KLq_agg, KLp_agg, Aq_agg, Ap_agg  (H,W)

    Priority (per child, per fiber):
      1) Agreement cache if present (spawn_A_final for q; optional model A for p)
      2) Softmin KL cache (spawn_softmin_kl_q/p)
      3) Fallback blended/cached KL (cached_alignment_kl / cached_model_alignment_kl)

    Aggregation occurs in AGREEMENT space; KL_agg is computed back from the agg agreement.
    """
    import numpy as np
    try:
        import config
        tau_q = float(getattr(config, "tau_align_q", 0.45))
        tau_p = float(getattr(config, "tau_align_p", 0.45))
        kl_cap = float(getattr(config, "signal_kl_cap", kl_cap))
        reduce_mode = str(getattr(config, "agg_reduce_mode", "mean"))  # "mean" | "max" | "p80" etc.
        prefer_agreement_cache = bool(getattr(config, "agg_prefer_agreement_cache", True))
    except Exception:
        tau_q = tau_p = 0.45
        reduce_mode = "mean"
        prefer_agreement_cache = True

    if not children:
        runtime_ctx.KLq_agg = runtime_ctx.KLp_agg = None
        runtime_ctx.Aq_agg  = runtime_ctx.Ap_agg  = None
        return

    H, W = children[0].mask.shape[:2]

    def _resize_to_hw(a):
        a = np.asarray(a, np.float32)
        if a.shape == (H, W): return a
        # minimal NN-like adjust without deps
        if a.shape[0] >= H and a.shape[1] >= W:
            return a[:H, :W].astype(np.float32, copy=False)
        py, px = max(0, H - a.shape[0]), max(0, W - a.shape[1])
        return np.pad(a, ((0, py), (0, px)), mode="edge")[:H, :W].astype(np.float32, copy=False)

    # Collect per-child AGREEMENT for each fiber if possible, else collect KL
    Aq_list, KLq_list = [], []
    Ap_list, KLp_list = [], []

    for ch in children:
        # ----- q fiber -----
        A_q = getattr(ch, "spawn_A_final", None) if prefer_agreement_cache else None
        if A_q is not None:
            Aq_list.append(np.clip(_resize_to_hw(A_q), 0.0, 1.0))
        else:
            # fall back to KL caches
            KLq = getattr(ch, "spawn_softmin_kl_q", None)
            if KLq is None:
                KLq = getattr(ch, "cached_alignment_kl", None)
            if KLq is not None:
                KLq = np.clip(_resize_to_hw(KLq), 0.0, kl_cap)
                KLq_list.append(KLq)

        # ----- p fiber -----
        # If you ever cache a model-side agreement (e.g., ch.spawn_A_final_p), prefer it here
        A_p = getattr(ch, "spawn_A_final_p", None) if prefer_agreement_cache else None
        if A_p is not None:
            Ap_list.append(np.clip(_resize_to_hw(A_p), 0.0, 1.0))
        else:
            KLp = getattr(ch, "spawn_softmin_kl_p", None)
            if KLp is None:
                KLp = getattr(ch, "cached_model_alignment_kl", None)
            if KLp is not None:
                KLp = np.clip(_resize_to_hw(KLp), 0.0, kl_cap)
                KLp_list.append(KLp)

    def _reduce_agree(A_list, KL_list, tau):
        """
        Prefer agreements (A_list). If absent, convert KL_list to agreements, then reduce.
        Returns (KL_eff, A_agg) or (None, None) if no inputs.
        """
        if A_list:
            A_stack = np.stack(A_list, axis=0)  # (C,H,W)
        elif KL_list:
            KL_stack = np.stack(KL_list, axis=0)
            A_stack = np.exp(-KL_stack / max(tau, 1e-8)).astype(np.float32)
        else:
            return None, None

        if reduce_mode == "mean":
            A_agg = np.mean(A_stack, axis=0)
        elif reduce_mode == "max":
            A_agg = np.max(A_stack, axis=0)
        elif reduce_mode.startswith("p"):
            try:
                q = float(reduce_mode[1:])
            except Exception:
                q = 80.0
            A_agg = np.percentile(A_stack, q, axis=0)
        else:
            A_agg = np.mean(A_stack, axis=0)

        A_agg = np.clip(np.nan_to_num(A_agg, nan=0.0, posinf=1.0, neginf=0.0), 0.0, 1.0)
        KL_eff = (-max(tau, 1e-8) * np.log(np.maximum(A_agg, 1e-20))).astype(np.float32)
        KL_eff = np.clip(KL_eff, 0.0, kl_cap)
        return KL_eff, A_agg

    KLq_agg, Aq_agg = _reduce_agree(Aq_list, KLq_list, tau_q)
    KLp_agg, Ap_agg = _reduce_agree(Ap_list, KLp_list, tau_p)

    runtime_ctx.KLq_agg = KLq_agg
    runtime_ctx.KLp_agg = KLp_agg
    runtime_ctx.Aq_agg  = Aq_agg
    runtime_ctx.Ap_agg  = Ap_agg





# --- spawn cache refresh policy --------------------------------------------
def should_refresh_spawn_cache(child, runtime_ctx, *, mask_tol=1e-8) -> bool:
    """
    Return True if child's spawn caches should be recomputed this step.
    Triggers:
      - child marked dirty (fields or KL) OR
      - child's mask changed meaningfully vs. last snapshot OR
      - transport cache_version changed since last spawn build OR
      - child carries no spawn caches yet
    """
    import numpy as np
    if getattr(child, "spawn_A_final", None) is None:
        return True
    if getattr(child, "_dirty_fields", False) or getattr(child, "_dirty_kl", False):
        return True

    # mask delta check (cheap)
    try:
        prev = getattr(child, "_mask_prev_for_spawn", None)
        if prev is None:
            return True
        now = np.asarray(child.mask, np.float32)
        if now.shape != prev.shape:
            return True
        if float(np.max(np.abs(now - prev))) > float(mask_tol):
            return True
    except Exception:
        return True

    # global transport cache version bump (parents/children changed)
    built_ver = int(getattr(child, "_spawn_cache_built_at_cachever", -1))
    glob_ver  = int(getattr(runtime_ctx, "cache_version", 0))
    return (built_ver != glob_ver)


def ensure_spawn_alignment_caches(children, agents, runtime_ctx, *,
                                  generators_q, generators_p,
                                  use_cover_weight=True, debug=False):
    """
    Build spawn caches ONLY for children that need it (policy above).
    Uses the central runtime transport cache (no per-agent Ω caches).
    """
    import numpy as np
    import config as _cfg

    if not children:
        return

    # Pre-warm exp(φ) grids in the central cache; Ω will be built on demand.
    try:
        from transport_cache import warm_E
        whiches = []
        # choose fibers to warm based on dims present in the data
        kq = int(getattr(children[0].mu_q_field, "shape", (0, 0, 0))[-1]) if children[0] is not None else 0
        kp = int(getattr(children[0].mu_p_field, "shape", (0, 0, 0))[-1]) if children[0] is not None else 0
        if kq: whiches.append("q")
        if kp: whiches.append("p")
        if whiches:
            warm_E(runtime_ctx, children, whiches=tuple(whiches))
    except Exception:
        pass

    # Only refresh those that actually need a rebuild
    need = [ch for ch in children if ch is not None and should_refresh_spawn_cache(ch, runtime_ctx)]
    if not need:
        return

    # Spawn cache build (ctx-aware; explicit generators)
    refresh_spawn_alignment_caches(
        runtime_ctx,
        need,
        agents,
        G_q=generators_q,
        G_p=generators_p,
        tau_q=float(getattr(_cfg, "tau_align_q", 0.45)),
        tau_p=float(getattr(_cfg, "tau_align_p", 0.45)),
        alpha=float(getattr(_cfg, "blend_qp_alpha", 0.50)),
        sm_tau=float(getattr(_cfg, "spawn_softmin_tau", 0.40)),
        kl_cap=float(getattr(_cfg, "signal_kl_cap", 10.0)),  # kept for signature compat
        use_cover_weight=bool(use_cover_weight),
        debug=bool(debug),
    )

    # Bookkeeping
    step_tag = int(getattr(runtime_ctx, "global_step", 0))
    for ch in need:
        ch._spawn_cache_built_at_step = step_tag
        ch._mask_prev_for_spawn = np.asarray(ch.mask, dtype=np.float32).copy()
        setattr(ch, "_dirty_fields", False)
        setattr(ch, "_dirty_kl", False)


def refresh_spawn_alignment_caches(
    ctx,
    children,
    agents,
    *,
    G_q=None,
    G_p=None,
    tau_q=None,
    tau_p=None,
    alpha=None,          # 0→model-only, 1→belief-only
    sm_tau=None,         # softmin temperature across neighbors
    mask_tau=None,       # support threshold on masks
    use_cover_weight=True,
    kl_cap=None,         # kept for signature compat; not used
    debug=False,
):
    """
    Build *spawn-only* caches on each child (per pixel):
        spawn_nb_count, spawn_min_kl_q/p, spawn_softmin_kl_q/p,
        spawn_cover_weight (opt), spawn_A_final, kl_field, agreement_field.

    Notes
    -----
    - Uses ctx-aware transport/KL via directed_kl_weight_after_transport(..., ctx=ctx, G=G_*).
    - Ω/exp caching is entirely in the runtime transport cache (no per-agent caches).
    """
    import numpy as np
    import config as _cfg

    # defaults
    tau_q    = float(getattr(_cfg, "tau_align_q", 0.45))        if tau_q    is None else float(tau_q)
    tau_p    = float(getattr(_cfg, "tau_align_p", 0.45))        if tau_p    is None else float(tau_p)
    alpha    = float(getattr(_cfg, "blend_qp_alpha", 0.50))     if alpha    is None else float(alpha)
    sm_tau   = float(getattr(_cfg, "spawn_softmin_tau", 0.40))  if sm_tau   is None else float(sm_tau)
    mask_tau = float(getattr(_cfg, "support_cutoff_eps", 1e-4)) if mask_tau is None else float(mask_tau)

    tiny = float(getattr(_cfg, "log_eps", 1e-9))

    # id -> agent for quick neighbor lookup
    id2A = {int(a.id): a for a in agents if a is not None}

    for ch in (children or []):
        if ch is None:
            continue

        H, W = np.asarray(ch.mask).shape[:2]
        present_i = (np.asarray(ch.mask, np.float32) > mask_tau)

        # dims and generator guards
        Kq = int(getattr(ch.mu_q_field, "shape", (0, 0, 0))[-1]) if ch.mu_q_field is not None else 0
        Kp = int(getattr(ch.mu_p_field, "shape", (0, 0, 0))[-1]) if ch.mu_p_field is not None else 0
        if Kq > 0 and G_q is None:
            raise ValueError("refresh_spawn_alignment_caches: missing G_q for q-fiber.")
        if Kp > 0 and G_p is None:
            raise ValueError("refresh_spawn_alignment_caches: missing G_p for p-fiber.")

        # init outputs
        nb_count     = np.zeros((H, W), np.int32)
        min_kl_q     = np.full((H, W), np.inf, np.float32)
        min_kl_p     = np.full((H, W), np.inf, np.float32)
        sumexp_q     = np.zeros((H, W), np.float32)  # Σ exp(-KL_q/τ_q)
        sumexp_p     = np.zeros((H, W), np.float32)  # Σ exp(-KL_p/τ_p)
        cover_weight = np.zeros((H, W), np.float32) if use_cover_weight else None

        if not getattr(ch, "neighbors", None) or not np.any(present_i):
            zf = np.zeros((H, W), np.float32)
            zi = np.zeros((H, W), np.int32)
            ch.spawn_nb_count      = zi
            ch.spawn_min_kl_q      = zf + np.inf
            ch.spawn_min_kl_p      = zf + np.inf
            ch.spawn_softmin_kl_q  = zf
            ch.spawn_softmin_kl_p  = zf
            ch.spawn_cover_weight  = zf if use_cover_weight else None
            ch.spawn_A_final       = zf
            ch.kl_field            = zf
            ch.agreement_field     = zf
            continue

        # per-neighbor accumulation on the overlap only
        for nb in ch.neighbors:
            j = id2A.get(int(nb.get("id", -1)))
            if j is None:
                continue

            present_j = (np.asarray(j.mask, np.float32) > mask_tau)
            ov = (present_i & present_j)
            if not np.any(ov):
                continue

            # directed weights via central cache + explicit generators
            if Kq > 0:
                wq = directed_kl_weight_after_transport(
                    ch, j,
                    ch.mu_q_field, ch.sigma_q_field,
                    j.mu_q_field,  j.sigma_q_field,
                    fiber="q", H=H, W=W, K=Kq, ov=ov, tau=tau_q,
                    ctx=ctx, G=G_q,
                )
            else:
                wq = np.ones((H, W), np.float32)

            if Kp > 0:
                wp = directed_kl_weight_after_transport(
                    ch, j,
                    ch.mu_p_field, ch.sigma_p_field,
                    j.mu_p_field,  j.sigma_p_field,
                    fiber="p", H=H, W=W, K=Kp, ov=ov, tau=tau_p,
                    ctx=ctx, G=G_p,
                )
            else:
                wp = np.ones((H, W), np.float32)

            # scatter into accumulators at overlap pixels
            iy, ix = np.nonzero(ov)

            # neighbor count (per-pixel)
            np.add.at(nb_count, (iy, ix), 1)

            # update hard-min KL via w → KL = -τ log w
            np.minimum.at(min_kl_q, (iy, ix), (-tau_q * np.log(np.maximum(wq[iy, ix], tiny))).astype(np.float32))
            np.minimum.at(min_kl_p, (iy, ix), (-tau_p * np.log(np.maximum(wp[iy, ix], tiny))).astype(np.float32))

            # softmin sumexp
            np.add.at(sumexp_q, (iy, ix), wq[iy, ix].astype(np.float32))
            np.add.at(sumexp_p, (iy, ix), wp[iy, ix].astype(np.float32))

            # optional coverage weight
            if use_cover_weight:
                np.add.at(cover_weight, (iy, ix), np.asarray(j.mask, np.float32)[iy, ix])

        # finalize softmins on pixels that had ≥1 neighbor
        valid = (nb_count > 0)

        softmin_q = np.zeros_like(sumexp_q, np.float32)
        softmin_p = np.zeros_like(sumexp_p, np.float32)
        softmin_q[valid] = (-sm_tau * np.log(np.maximum(sumexp_q[valid], tiny))).astype(np.float32)
        softmin_p[valid] = (-sm_tau * np.log(np.maximum(sumexp_p[valid], tiny))).astype(np.float32)

        # blended KL softmin and final agreement
        tau_blend = float(alpha) * tau_q + (1.0 - float(alpha)) * tau_p
        KL_blend  = (float(alpha) * softmin_q + (1.0 - float(alpha)) * softmin_p).astype(np.float32)
        A_final   = np.zeros_like(KL_blend, np.float32)
        A_final[valid] = np.exp(-KL_blend[valid] / max(tau_blend, tiny)).astype(np.float32)

        # mask outside child support
        KL_blend  = np.where(present_i, KL_blend,  0.0).astype(np.float32)
        A_final   = np.where(present_i, A_final,   0.0).astype(np.float32)
        softmin_q = np.where(present_i, softmin_q, 0.0).astype(np.float32)
        softmin_p = np.where(present_i, softmin_p, 0.0).astype(np.float32)
        min_kl_q  = np.where(valid & present_i, min_kl_q, np.inf).astype(np.float32)
        min_kl_p  = np.where(valid & present_i, min_kl_p, np.inf).astype(np.float32)
        if use_cover_weight:
            cover_weight = np.where(present_i, cover_weight, 0.0).astype(np.float32)

        # write caches on the child
        ch.spawn_nb_count      = nb_count
        ch.spawn_min_kl_q      = min_kl_q
        ch.spawn_min_kl_p      = min_kl_p
        ch.spawn_softmin_kl_q  = softmin_q
        ch.spawn_softmin_kl_p  = softmin_p
        ch.spawn_cover_weight  = cover_weight if use_cover_weight else None
        ch.spawn_A_final       = A_final

        # convenience aliases used by plots / downstream
        ch.kl_field            = KL_blend
        ch.agreement_field     = A_final

        if debug and np.any(valid & present_i) and not np.all(np.isfinite(KL_blend[present_i])):
            print(f"[spawn-cache] non-finite blended KL for child {int(getattr(ch,'id',-1))}")











#=============================================================================#







def compute_and_set_auto_agree_gate(runtime_ctx, *, percentile=65.0, ema=0.2, use_p_if_q_missing=True):
    """
    Sets runtime_ctx.detector_state.agree_gate_tau_eff to a smoothed percentile
    of A_agg in [0,1]. If no aggregates exist, sets it to None (gate off).
    """
    import numpy as np
    ds = getattr(runtime_ctx, "detector_state", None)
    if ds is None:
        return

    A = getattr(runtime_ctx, "Aq_agg", None)
    if (A is None) and use_p_if_q_missing:
        A = getattr(runtime_ctx, "Ap_agg", None)

    if A is None:
        ds.agree_gate_tau_eff = None
        try:
            print("[AGG] auto agree gate: no aggregates, gate OFF")
        except Exception:
            pass
        return

    A = np.asarray(A, np.float32)
    good = np.isfinite(A)
    if not good.any():
        ds.agree_gate_tau_eff = None
        try:
            print("[AGG] auto agree gate: aggregates non-finite, gate OFF")
        except Exception:
            pass
        return

    thr = float(np.percentile(A[good], float(percentile)))
    prev = getattr(ds, "agree_gate_tau_eff", None)
    if (prev is None) or (not np.isfinite(prev)):
        new_tau = thr
    else:
        new_tau = (1.0 - float(ema)) * float(prev) + float(ema) * thr

    ds.agree_gate_tau_eff = float(new_tau)
    try:
        print(f"[AGG] auto agree gate p{int(percentile)} ema={ema} tau={new_tau:.3f}")
    except Exception:
        pass




def prune_orphan_parents(
    parents_by_id,
    *,
    patience=3,
    min_total_weight=1e-4,
    min_area_nz=5,
    support_tau=0.02,
    respect_grace=True,
    verbose=False,
):
    """
    Remove parents that carry ~no child weight or tiny support for `patience` consecutive steps.
    - Weight check: sum(child_weights) < min_total_weight
    - Area check:   count(mask > support_tau) < min_area_nz
    - Respects each parent's grace window (_grace) if `respect_grace=True`.
    Returns: list of pruned parent ids.
    """
    import numpy as np

    dead = []

    for pid, P in list(parents_by_id.items()):
        # ----- stats (NaN-safe) -----
        wsum = float(sum((getattr(P, "child_weights", {}) or {}).values()))
        if not np.isfinite(wsum):
            wsum = 0.0

        m = np.nan_to_num(np.asarray(getattr(P, "mask", 0.0), np.float32), nan=0.0, posinf=0.0, neginf=0.0)
        nz = int(np.count_nonzero(m > float(support_tau)))

        # ----- grace / age gate -----
        age   = int(getattr(P, "_age", 0) or 0)
        grace = int(getattr(P, "_grace", 0) or 0)
        in_grace = respect_grace and (age < grace)

        ticks = int(getattr(P, "_orphan_ticks", 0) or 0)

        if in_grace:
            # During grace, don't accrue orphan ticks; reset if any evidence appears
            if (wsum >= float(min_total_weight)) or (nz >= int(min_area_nz)):
                ticks = 0
            # else keep ticks at 0 (don’t penalize newborns)
        else:
            # Outside grace: accrue ticks when both signals are weak
            if (wsum < float(min_total_weight)) or (nz < int(min_area_nz)):
                ticks += 1
            else:
                ticks = 0

        P._orphan_ticks = ticks

        if (ticks >= int(patience)) and (not in_grace):
            dead.append(int(pid))

    for pid in dead:
        parents_by_id.pop(pid, None)

    if verbose and dead:
        print(f"[PRUNE] removed {len(dead)} parents: {dead}")

    return dead





# in update_rules_utils.py (or wherever mark_dirty is defined)
def mark_dirty(ctx, *agents, kl=False):
    for a in agents:
        aid = int(getattr(a, "id", id(a)))
        ctx.dirty.agents.add(aid)
        if kl:
            ctx.dirty.kl.add(aid)
            
        # also per-agent flags so local policies can see staleness
        try:
            setattr(a, "_dirty_fields", True)
            if kl:
                setattr(a, "_dirty_kl", True)
        except Exception:
            pass        
      





def take_dirty(ctx, all_agents, *, which="agents"):
    """
    Pop and return the actual objects whose ids are marked dirty.
    which: "agents" (fields/morphisms) or "kl" (KL refresh).
    """
    # tolerate missing ctx.dirty in early boot
    dirty = getattr(ctx, "dirty", None)
    if dirty is None:
        return []
    ids = dirty.agents if which == "agents" else dirty.kl
    subset = _collect_by_ids(all_agents, ids)
    ids.clear()
    return subset



def _rebuild_dirty_morphisms(objs, Gq, Gp, *, ctx=None):
    if not objs:
        return
    # Prefer recompute_agent_morphisms (rectangular, gauge-covariant)
    try:
        from bundle_morphism_utils import recompute_agent_morphisms as _recompute
        use_new = True
    except Exception:
        use_new = False
        try:
            from bundle_coarsegrain_init import CGH_build_morphisms as _legacy_build
        except Exception:
            _legacy_build = None

    for a in objs:
        if a is None:
            continue
        need = (
            getattr(a, "morphisms_dirty", False)
            or getattr(a, "bundle_morphism_q_to_p", None) is None
            or getattr(a, "bundle_morphism_p_to_q", None) is None
        )
        if not need:
            continue
        if use_new:
            _recompute(a, generators_q=Gq, generators_p=Gp, ctx=ctx)
        elif _legacy_build is not None:
            _legacy_build(a, Gq, Gp)
        a.morphisms_dirty = False


def _post_strict(all_agents, params, Gq, Gp, *, ctx=None):
    if not all_agents:
        return
    post = dict(params)
    post["sanitize_strict"] = True
    post["exp_n_jobs"] = 1

    preprocess_all_agents(all_agents, post, Gq, Gp, ctx=ctx)
    build_all_lambda_caches(all_agents, ctx=ctx)
    _rebuild_dirty_morphisms(all_agents, Gq, Gp, ctx=ctx)





def _pre_light(all_agents, params, Gq, Gp, *, ctx=None):
    if not all_agents:
        return
    pre = dict(params)
    pre["sanitize_strict"] = pre.get("sanitize_strict_pre", False)
    pre["exp_n_jobs"] = 1

    # preprocess (build exp caches into ctx.cache)
    preprocess_all_agents(all_agents, pre, Gq, Gp, ctx=ctx)

    # no per-agent Ω caches anymore (centralized via CacheHub)
    # build Λ child maps and parent-side views
    build_all_lambda_caches(all_agents, ctx=ctx)
    

    # mask shape hygiene (once)
    H, W = np.asarray(all_agents[0].mask).shape[:2]
    _standardize_all_masks_once(all_agents, (H, W))

# update_rules_utils.py

def _post_strict_subset(agents_subset, params, generators_q, generators_p, *, ctx=None):
    """
    Strict refresh for a subset:
      preprocess -> Λ caches ->  (optional) morphisms
    """
    if not agents_subset:
        return
    agents_subset = [a for a in agents_subset if a is not None]
    if not agents_subset:
        return

    preprocess_all_agents(agents_subset, params, generators_q, generators_p, ctx=ctx)
    build_all_lambda_caches(agents_subset, ctx = ctx)
    _rebuild_dirty_morphisms(agents_subset, generators_q, generators_p, ctx=ctx)



def _refresh_child_kl_fields_subset(children_subset, all_agents, eps, build_spawn=False, *, ctx=None):
    """
    Legacy entrypoint used by detector/growth passes.
    Delegates to spawn-only MVG cache builder for the given subset.
    """
    if not children_subset:
        return
    try:
        import config as _cfg
        log_eps = float(getattr(_cfg, "log_eps", 1e-9))
    except Exception:
        log_eps = 1e-9

    if build_spawn:
        refresh_spawn_alignment_caches(
            children_subset,
            all_agents,
            eps=float(eps),
            log_eps=log_eps,
            ctx=ctx,   # <-- propagate ctx for caching/transports
        )


    





def _standardize_all_masks_once(all_agents, HW):
    from parent_utils import ensure_hw
    for a in all_agents:
        if hasattr(a, "mask"):
            m = getattr(a, "mask", None)
            if m is not None:
                mm = ensure_hw(m, HW)  # no-op if already right
                if mm is not m:
                    setattr(a, "mask", mm)




# --- helpers: sparsemax / entmax15 / softmax ---------------------------------
def _softmax(z, mask=None):
    import numpy as np
    z = np.asarray(z, np.float32)
    if mask is not None:
        z = np.where(mask, z, -np.inf)
    z = z - np.nanmax(z, axis=-1, keepdims=True)
    p = np.exp(z)
    p /= np.sum(p, axis=-1, keepdims=True) + 1e-20
    return p

def _sparsemax(z, mask=None):
    """
    Martins & Astudillo (2016). Returns probabilities with exact zeros.
    Works on last axis. O(K log K) per vector.
    """
    import numpy as np
    z = np.asarray(z, np.float32)
    if mask is not None:
        z = np.where(mask, z, -np.inf)
    # replace -inf with very small for sorting
    z_safe = np.where(np.isfinite(z), z, -1e30)
    z_sorted = np.sort(z_safe, axis=-1)[:, ::-1]
    k = np.arange(1, z.shape[-1] + 1, dtype=np.float32)
    z_cumsum = np.cumsum(z_sorted, axis=-1)
    # find k* s.t. 1 + k z̄_k > sum
    rhs = 1.0 + k * z_sorted
    cond = rhs > z_cumsum
    k_star = cond.sum(axis=-1)  # [N]
    # tau = (sum_{i<=k*} z_i - 1) / k*
    # gather prefix sums at k*
    idx = (k_star - 1).clip(min=0)
    tau = (z_cumsum[np.arange(z.shape[0]), idx] - 1.0) / np.maximum(k_star, 1)
    p = np.maximum(z - tau[:, None], 0.0)
    # renormalize tiny numerical drift
    Z = np.sum(p, axis=-1, keepdims=True) + 1e-20
    return p / Z

def _entmax15(z, mask=None, iters=50, tol=1e-6):
    """
    Entmax with alpha=1.5 (Peters et al., 2019). Proper sparse probabilities.
    We use a simple per-row bisection for tau. K is small here, so fine.
    """
    import numpy as np
    z = np.asarray(z, np.float32)
    if mask is not None:
        z = np.where(mask, z, -np.inf)
    z_safe = np.where(np.isfinite(z), z, -1e30)

    # upper/lower bounds for tau
    lo = np.min(z_safe, axis=-1) - 1.0
    hi = np.max(z_safe, axis=-1)
    lo = lo[:, None]; hi = hi[:, None]

    def proj(tau):
        u = np.maximum(0.0, z_safe - tau)
        return u ** 2.0

    for _ in range(iters):
        mid = (lo + hi) * 0.5  # [N,1]
        s = np.sum(proj(mid), axis=-1, keepdims=True)
        # sum u^2 should be 1 for alpha=1.5 projection
        hi = np.where(s > 1.0, mid, hi)
        lo = np.where(s > 1.0, lo, mid)
        if np.max(np.abs(hi - lo)) < tol:
            break
    tau = (lo + hi) * 0.5
    p = np.maximum(0.0, z_safe - tau) ** 2.0
    Z = np.sum(p, axis=-1, keepdims=True) + 1e-20
    return p / Z


def _as_parent_dict(obj):
    """
    Normalize parents -> {pid: Parent}. Accepts dict, list, iterable, or None.
    Uses the parent's .id if present; else falls back to enumerate index.
    """
    import collections.abc as _abc
    if obj is None:
        return {}
    if isinstance(obj, dict):
        return {int(getattr(p, "id", pid)): p for pid, p in obj.items()}
    if isinstance(obj, _abc.Iterable):
        return {int(getattr(p, "id", i)): p for i, p in enumerate(obj)}
    # Single parent object?
    return {int(getattr(obj, "id", 0)): obj}

# ======================== helpers (place near module top) =====================

try:
    import config as _CFG_MOD
    def CFG(name, default=None):
        return getattr(_CFG_MOD, name, default)
except Exception:
    def CFG(name, default=None):  # fallback
        return default

import numpy as _np

def _mask_gate(m, tau):
    """Keep graded weight but zero out below τ."""
    m = _np.asarray(m, _np.float32)
    return (m >= tau).astype(_np.float32) * m

def _support_bool(m, tau):
    """Boolean presence above τ."""
    return _np.asarray(m, _np.float32) >= tau

def _agreement_prior_map(agree_map, H, W):
    """Resizes/clamps an optional agreement prior A(x)∈[0,1] to (H,W) or returns None."""
    if agree_map is None:
        return None
    A = _np.asarray(agree_map, _np.float32)
    if A.shape != (H, W):
        from parent_utils import resize_nn
        A = resize_nn(A, (H, W))
    return _np.clip(_np.nan_to_num(A, nan=1.0, posinf=1.0, neginf=0.0), 0.0, 1.0)

def _capture_prev_masks(ctx):
    """Return {pid:int -> mask copy} for change detection."""
    parents_dict = getattr(ctx, "parents_by_region", {}) or {}
    out = {}
    for pid, P in parents_dict.items():
        if P is None or getattr(P, "mask", None) is None:
            continue
        out[int(getattr(P, "id", pid))] = _np.asarray(P.mask, _np.float32).copy()
    return out

def _detect_changed_parents(ctx, prev_masks, change_tol=None):
    """Return [P,...] whose mask changed beyond tol (shape or max|Δ|)."""
    tol = float(CFG("parent_mask_change_tol", 1e-8) if change_tol is None else change_tol)
    changed = []
    parents_dict = getattr(ctx, "parents_by_region", {}) or {}
    for pid, P in parents_dict.items():
        if P is None or getattr(P, "mask", None) is None:
            continue
        key = int(getattr(P, "id", pid))
        before = prev_masks.get(key)
        now = _np.asarray(P.mask, _np.float32)
        if before is None or now.shape != before.shape:
            changed.append(P); continue
        if float(_np.max(_np.abs(now - before))) > tol:
            changed.append(P)
    return changed

# ==============================================================================


# --- core: from scores -> logits -> probs (with null) -------------------------
def _normalize_assignments(scores, agree=None, valid_mask=None, *,
                           temp=0.25, activation="softmax",
                           agree_weight=1.0, null_enabled=True,
                           null_logit=0.0, calibrate=None):
    """
    scores: [N_parents] raw similarity/alignment per child
    agree:  [N_parents] agreement in [0,1]
    valid_mask: bool mask of admissible parents
    temp: base temperature
    activation: "softmax" | "sparsemax" | "entmax15"
    agree_weight: coefficient on log-agreement
    null_enabled: include 'null' option
    null_logit: prior logit for null
    calibrate: optional dict { 'target_H': float, 'k': float } for temp calibration
    """
    import numpy as np
    z = np.asarray(scores, np.float32)

    # convert multiplicative agree -> additive in logit space
    if agree is not None:
        a = np.clip(np.asarray(agree, np.float32), 1e-6, 1.0)
        z = z + float(agree_weight) * np.log(a)

    # temperature
    t = float(temp)
    if calibrate is not None and calibrate.get("target_H") is not None:
        # one-step exponential correction toward target entropy (cheap, stable)
        target_H = float(calibrate["target_H"])
        kappa    = float(calibrate.get("k", 0.5))
        sm = _softmax(z / max(1e-8, t), mask=valid_mask)
        H = -np.sum(sm * (np.log(sm + 1e-20)), axis=-1)
        # increase temp if too peaky (H < target), decrease if too flat
        t = t * float(np.exp(kappa * (target_H - H)))

    logits = z / max(1e-8, t)

    # attach null option (last index)
    if null_enabled:
        if valid_mask is None:
            vm = None
        else:
            vm = np.concatenate([valid_mask.astype(bool), np.array([True])], axis=-1)
        logits = np.concatenate([logits, np.array([float(null_logit)], dtype=np.float32)], axis=-1)
    else:
        vm = valid_mask

    # pick activation
    if activation == "sparsemax":
        p = _sparsemax(logits[None, :], mask=None if vm is None else vm[None, :])[0]
    elif activation in ("entmax", "entmax15"):
        p = _entmax15(logits[None, :], mask=None if vm is None else vm[None, :])[0]
    else:
        p = _softmax(logits[None, :], mask=None if vm is None else vm[None, :])[0]

    return p



