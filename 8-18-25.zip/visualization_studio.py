# snapshot_viz.py
# ---------------------------------------------------------------------
# Visualization helpers for dump_snapshot_npz() outputs and metrics.
# Fiber-aware (K_q vs K_p), strict-SPD maps, robust normalization.
# No CLI; just flip the toggles in the __main__ block.
# ---------------------------------------------------------------------

from __future__ import annotations
import os
os.environ.setdefault("OMP_NUM_THREADS", "1")
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
os.environ.setdefault("MKL_NUM_THREADS", "1")
os.environ.setdefault("BLIS_NUM_THREADS", "1")
os.environ.setdefault("NUMEXPR_NUM_THREADS", "1")
os.environ.setdefault("MPLBACKEND", "Agg")  # headless-safe

import os, glob, math, pickle, warnings, subprocess, shlex
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Tuple, Optional

import numpy as np
import matplotlib.pyplot as plt

# Optional: imageio for GIF fallback
try:
    import imageio.v3 as iio
    _HAS_IMAGEIO = True
except Exception:
    _HAS_IMAGEIO = False

# ============================ Loading =================================

@dataclass
class Snapshot:
    path: str
    step: int
    data: Dict[str, np.ndarray]


_DEFAULT_PANELS = [
    "phi_norm", "phi_model_norm",
    "belief_align", "model_align",
    "Fq_norm", "Fp_norm",
    "mu_q_norm", "mu_p_norm",
    "sigma_q_logdet", "sigma_p_logdet",
    "phi_morph_norm", "phi_tilde_morph_norm",
    "lambda_q_norm", "lambda_p_norm",
    "grad_phi_norm", "grad_phi_model_norm",
]


import re
import numpy as np
from typing import Iterator, Tuple, Optional

_step_re = re.compile(r"step[_\-]?(\d+)", re.IGNORECASE)


# Robust imageio import (supports v2 and v3)
_HAS_IMAGEIO = False
_HAS_IMAGEIO_WRITER = False

try:
    import imageio.v2 as iio  # v2-compat API (has get_writer, imread, imwrite)
    _HAS_IMAGEIO = True
    _HAS_IMAGEIO_WRITER = hasattr(iio, "get_writer")
except Exception:
    try:
        import imageio as iio  # might be v3
        _HAS_IMAGEIO = True
        _HAS_IMAGEIO_WRITER = hasattr(iio, "get_writer")
    except Exception:
        iio = None
        _HAS_IMAGEIO = False
        _HAS_IMAGEIO_WRITER = False


# -*- coding: utf-8 -*-
"""
Created on Mon Aug 18 16:31:11 2025

@author: chris and christine
"""

# Lambda Visualization Utility
#
# Visualizes Λ (Lambda) mappings between a child and parent from the
# in-memory runtime context (runtime_context.runtime_ctx).
#
# For each fiber q and p, when available:
#   1) Per-pixel Frobenius norm heatmap if Λ is a field (H,W,Kc,Kp).
#   2) Mean Λ matrix (Kc x Kp) averaged over valid pixels (child∩parent).
#
# Saves PNGs to /mnt/data/ and returns a dict of file paths.

import os
import numpy as np
import matplotlib.pyplot as plt

OUT_DIR = "/mnt/data"

def _get_masks(child, parent):
    """Return (child_mask, parent_mask, overlap_bool_or_None)."""
    cm = getattr(child, "mask", None)
    pm = getattr(parent, "mask", None)
    if cm is None or pm is None:
        return cm, pm, None
    cm = np.asarray(cm).astype(bool)
    pm = np.asarray(pm).astype(bool)
    if cm.shape != pm.shape:
        return cm, pm, None
    return cm, pm, (cm & pm)

def _fro_norm_per_pixel(L):
    """L: (H, W, Kc, Kp) -> (H, W) Frobenius norm per pixel."""
    H, W = L.shape[:2]
    M = L.reshape(H, W, -1)
    M = np.nan_to_num(M, nan=0.0, posinf=0.0, neginf=0.0)
    return np.linalg.norm(M, axis=-1)

def _robust_vlims(im):
    finite = im[np.isfinite(im)]
    if finite.size == 0:
        return None, None
    lo = np.percentile(finite, 1.0)
    hi = np.percentile(finite, 99.0)
    if not np.isfinite(hi) or hi <= lo:
        return None, None
    return float(lo), float(hi)

def _imshow_save(arr, title, filename):
    """Plot a single 2D array and save to OUT_DIR/filename."""
    os.makedirs(OUT_DIR, exist_ok=True)
    path = os.path.join(OUT_DIR, filename)
    plt.figure(figsize=(6, 6))
    vmin, vmax = _robust_vlims(arr)
    plt.imshow(arr, vmin=vmin, vmax=vmax, interpolation="nearest")
    plt.title(title)
    plt.xticks([]); plt.yticks([])
    plt.colorbar(fraction=0.046, pad=0.04)
    plt.tight_layout()
    plt.savefig(path, dpi=140, bbox_inches="tight")
    plt.close()
    return path

def _imshow_matrix(M, title, filename):
    """Plot a small matrix (Kc x Kp)."""
    os.makedirs(OUT_DIR, exist_ok=True)
    path = os.path.join(OUT_DIR, filename)
    plt.figure(figsize=(5, 4))
    plt.imshow(M, interpolation="nearest")
    plt.title(title)
    plt.xlabel("parent (Kp)")
    plt.ylabel("child (Kc)")
    plt.colorbar(fraction=0.046, pad=0.04)
    plt.tight_layout()
    plt.savefig(path, dpi=160, bbox_inches="tight")
    plt.close()
    return path

def _mean_matrix_from_field(L, overlap=None):
    """
    L: (H, W, Kc, Kp). If overlap is provided (H, W) bool, average only over True pixels.
    Returns (Kc, Kp) mean matrix or None.
    """
    if L is None or not isinstance(L, np.ndarray):
        return None
    if L.ndim == 2:
        return L
    if L.ndim >= 4:
        H, W = L.shape[:2]
        if overlap is not None and overlap.shape == (H, W):
            idx = np.flatnonzero(overlap.reshape(-1))
            if idx.size == 0:
                M = L.reshape(-1, *L.shape[-2:]).astype(np.float64, copy=False)
            else:
                M = L.reshape(-1, *L.shape[-2:])[idx].astype(np.float64, copy=False)
        else:
            M = L.reshape(-1, *L.shape[-2:]).astype(np.float64, copy=False)
        M = np.nan_to_num(M, nan=0.0, posinf=0.0, neginf=0.0)
        return np.mean(M, axis=0)
    return None

def _fetch_lambda(child, parent, fiber, direction):
    """
    Try runtime_ctx first; fallback to agent-attached maps.
    Returns np.ndarray or None.
    """
    try:
        from runtime_context import runtime_ctx as _rtx
        L = _rtx.get_lambda(
            low_level=getattr(child, "level", 0),
            high_level=getattr(parent, "level", 1),
            child_id=int(child.id),
            parent_id=int(parent.id),
            fiber=fiber,
            direction=direction,
            agents_fallback=True,
        )
        if L is not None:
            return np.asarray(L, dtype=np.float32)
    except Exception:
        pass

    if direction == "dn":
        if fiber == "q":
            mp = getattr(parent, "Lambda_from_child_q_map", None)
        else:
            mp = getattr(parent, "Lambda_from_child_p_map", None)
        if isinstance(mp, dict):
            val = mp.get(int(child.id))
            return np.asarray(val, dtype=np.float32) if val is not None else None
    else:
        if fiber == "q":
            mp = getattr(child, "Lambda_up_q_map", None)
        else:
            mp = getattr(child, "Lambda_up_p_map", None)
        if isinstance(mp, dict):
            val = mp.get(int(parent.id))
            return np.asarray(val, dtype=np.float32) if val is not None else None
    return None

def visualize_lambdas(child_id: int, parent_id: int, *, level_child: int = 0, level_parent: int = 1):
    """
    Visualize Λ for a given (child_id, parent_id). Returns dict of written files.
    Requires runtime_ctx.register_agents(level_child, children) and
    runtime_ctx.register_agents(level_parent, parents) to have run.
    """
    written = {}
    child = None
    parent = None
    try:
        from runtime_context import runtime_ctx as _rtx
        cand_c = getattr(_rtx, "agents_by_level", {}).get(level_child, {})
        cand_p = getattr(_rtx, "agents_by_level", {}).get(level_parent, {})
        child = cand_c.get(int(child_id), None) if isinstance(cand_c, dict) else None
        parent = cand_p.get(int(parent_id), None) if isinstance(cand_p, dict) else None
    except Exception:
        pass

    if child is None or parent is None:
        raise RuntimeError(
            "Could not locate child or parent in runtime_ctx.agents_by_level. "
            "Make sure you called runtime_ctx.register_agents for both levels."
        )

    cm, pm, overlap = _get_masks(child, parent)

    for fiber in ("q", "p"):
        # Downstream Λ (parent → child)
        L_dn = _fetch_lambda(child, parent, fiber=fiber, direction="dn")
        if L_dn is not None:
            if L_dn.ndim >= 4:
                fro_dn = _fro_norm_per_pixel(L_dn)
                if overlap is not None:
                    fro_dn = np.where(overlap, fro_dn, np.nan)
                fname = f"Lambda_{fiber}_dn_fro_{child_id}-{parent_id}.png"
                written[f"{fiber}_dn_fro"] = _imshow_save(
                    fro_dn,
                    f"Λ_{fiber}↓ Fro norm (child {child_id} ← parent {parent_id})",
                    fname,
                )
                Mmean = _mean_matrix_from_field(L_dn, overlap=overlap)
            else:
                Mmean = L_dn
            if Mmean is not None and Mmean.ndim == 2:
                fname = f"Lambda_{fiber}_dn_mean_{child_id}-{parent_id}.png"
                written[f"{fiber}_dn_mean"] = _imshow_matrix(
                    Mmean,
                    f"Mean Λ_{fiber}↓ (child {child_id} ← parent {parent_id})",
                    fname,
                )

        # Upstream Λ (child → parent)
        L_up = _fetch_lambda(child, parent, fiber=fiber, direction="up")
        if L_up is not None:
            if L_up.ndim >= 4:
                fro_up = _fro_norm_per_pixel(L_up)
                if overlap is not None:
                    fro_up = np.where(overlap, fro_up, np.nan)
                fname = f"Lambda_{fiber}_up_fro_{child_id}-{parent_id}.png"
                written[f"{fiber}_up_fro"] = _imshow_save(
                    fro_up,
                    f"Λ_{fiber}↑ Fro norm (child {child_id} → parent {parent_id})",
                    fname,
                )
                Mmean_up = _mean_matrix_from_field(L_up, overlap=overlap)
            else:
                Mmean_up = L_up
            if Mmean_up is not None and Mmean_up.ndim == 2:
                fname = f"Lambda_{fiber}_up_mean_{child_id}-{parent_id}.png"
                written[f"{fiber}_up_mean"] = _imshow_matrix(
                    Mmean_up,
                    f"Mean Λ_{fiber}↑ (child {child_id} → parent {parent_id})",
                    fname,
                )

    return written






def _gif_writer(out_path: str, fps: int):
    """
    Version-agnostic GIF writer:
      - prefers imageio.v2.get_writer
      - falls back to imageio.get_writer if available
    """
    if not _HAS_IMAGEIO:
        raise RuntimeError("imageio not available; install 'imageio' to write GIFs")
    if hasattr(iio, "get_writer"):
        return iio.get_writer(out_path, mode="I", fps=fps)
    # Final fallback: raise with a clear message
    raise RuntimeError(
        "imageio found but no streaming writer API available. "
        "Install a version with v2-compat, e.g. 'pip install \"imageio<3\"' "
        "or 'pip install imageio' and import imageio.v2."
    )



def _iter_snapshot_paths(snapshot_dir: str, limit: Optional[int] = None) -> Iterator[Tuple[int, Path]]:
    """Yield (step, path) sorted by step without loading arrays."""
    files = sorted(Path(snapshot_dir).glob("*.npz"), key=lambda p: int(_step_re.search(p.stem).group(1)) if _step_re.search(p.stem) else -1)
    if limit is not None:
        files = files[:limit]
    for f in files:
        m = _step_re.search(f.stem)
        step = int(m.group(1)) if m else -1
        yield step, f

def _iter_snapshots_lazy(snapshot_dir: str, limit: Optional[int] = None):
    """Yield (step, npz) and close npz immediately after use."""
    for step, f in _iter_snapshot_paths(snapshot_dir, limit):
        with np.load(f, allow_pickle=False) as npz:
            # npz[...] returns arrays on demand; we consume them then close the file
            yield step, npz


def _parse_step_from_name(path: str) -> Optional[int]:
    stem = Path(path).stem
    for token in stem.split("_"):
        if token.startswith("step"):
            try:
                return int(token.replace("step", ""))
            except Exception:
                pass
    # fallback: trailing digits
    import re
    m = re.search(r"(\d+)$", stem)
    return int(m.group(1)) if m else None

def load_snapshots_dir(directory: str, pattern: str = "step*.npz") -> List[Snapshot]:
    files = sorted(glob.glob(str(Path(directory) / pattern)))
    snaps: List[Snapshot] = []
    for f in files:
        step = _parse_step_from_name(f)
        if step is None:
            continue
        data = dict(np.load(f, allow_pickle=False))
        snaps.append(Snapshot(f, step, data))
    return snaps

# ========================= Map extraction ==============================

def _robust_norm(arr: np.ndarray, pmin: float = 1.0, pmax: float = 99.0) -> Tuple[float, float]:
    """Return robust [vmin, vmax] using percentiles."""
    a = np.asarray(arr)
    a = a[np.isfinite(a)]
    if a.size == 0:
        return 0.0, 1.0
    lo = np.percentile(a, pmin)
    hi = np.percentile(a, pmax)
    if not np.isfinite(lo) or not np.isfinite(hi) or hi <= lo:
        lo = float(np.nanmin(a))
        hi = float(np.nanmax(a))
        if not np.isfinite(hi) or hi <= lo:
            hi = lo + 1.0
    return float(lo), float(hi)

def _trace2d(M: np.ndarray) -> np.ndarray:
    # M: (H,W,K,K) -> (H,W)
    return np.einsum("...ii->...", M, optimize=True)

def _logdet2d(M: np.ndarray, eps: float = 1e-8) -> np.ndarray:
    """M: (H,W,K,K) SPD -> (H,W) slogdet. Casts to float32 for linalg safety."""
    H, W, K, _ = M.shape
    # float16 → float32 to satisfy numpy.linalg
    S = M.astype(np.float32, copy=False).reshape(-1, K, K)
    I = np.eye(K, dtype=np.float32)
    # symmetrize + jitter to keep SPD
    S = 0.5 * (S + np.swapaxes(S, -1, -2)) + eps * I[None, ...]
    sign, ld = np.linalg.slogdet(S)
    out = np.zeros((H, W), dtype=np.float32)
    out.reshape(-1)[:] = ld
    return out

def compute_scalar_maps(npz: Dict[str, np.ndarray], agent_index: int = 0) -> Dict[str, np.ndarray]:
    maps: Dict[str, np.ndarray] = {}
    def _maybe(k): return npz.get(k, None)

    # mask (not animated per your request, but available)
    mask = _maybe("mask")
    if mask is not None:
        maps["mask"] = mask[agent_index] if mask.ndim == 3 else mask

    # φ norms
    phi = _maybe("phi")
    if phi is not None:
        maps["phi_norm"] = np.linalg.norm(phi[agent_index], axis=-1) if phi.ndim == 4 else np.linalg.norm(phi, axis=-1)
    phi_m = _maybe("phi_model")
    if phi_m is not None:
        maps["phi_model_norm"] = np.linalg.norm(phi_m[agent_index], axis=-1) if phi_m.ndim == 4 else np.linalg.norm(phi_m, axis=-1)

    # alignment fields
    ba = _maybe("belief_align")
    if ba is not None: maps["belief_align"] = ba[agent_index] if ba.ndim == 3 else ba
    ma = _maybe("model_align")
    if ma is not None: maps["model_align"]  = ma[agent_index] if ma.ndim == 3 else ma

    # curvature norms
    Fq = _maybe("Fq_norm")
    if Fq is not None: maps["Fq_norm"] = Fq[agent_index] if Fq.ndim == 3 else Fq
    Fp = _maybe("Fp_norm")
    if Fp is not None: maps["Fp_norm"] = Fp[agent_index] if Fp.ndim == 3 else Fp

    # μ norms
    muq = _maybe("mu_q")
    if muq is not None: maps["mu_q_norm"] = np.linalg.norm(muq[agent_index], axis=-1) if muq.ndim == 4 else np.linalg.norm(muq, axis=-1)
    mup = _maybe("mu_p")
    if mup is not None: maps["mu_p_norm"] = np.linalg.norm(mup[agent_index], axis=-1) if mup.ndim == 4 else np.linalg.norm(mup, axis=-1)

    # Σ stats
    Sq = _maybe("sigma_q")
    if Sq is not None:
        if Sq.ndim == 5:
            maps["sigma_q_logdet"] = _logdet2d(Sq[agent_index])
        else:
            maps["sigma_q_logdet"] = _logdet2d(Sq)
    Sp = _maybe("sigma_p")
    if Sp is not None:
        if Sp.ndim == 5:
            maps["sigma_p_logdet"] = _logdet2d(Sp[agent_index])
        else:
            maps["sigma_p_logdet"] = _logdet2d(Sp)

    # morphism norms (written by dump_snapshot_npz when compute_morphisms=True)
    for k in ("phi_morph_norm","phi_tilde_morph_norm","lambda_q_norm","lambda_p_norm"):
        arr = _maybe(k)
        if arr is not None:
            maps[k] = arr[agent_index] if arr.ndim == 3 else arr

    # gradient norms if present in snapshot (either full grads or precomputed norms)
    G = _maybe("grad_phi")
    if G is not None:
        maps["grad_phi_norm"] = np.linalg.norm(G[agent_index], axis=-1) if G.ndim == 4 else np.linalg.norm(G, axis=-1)
    else:
        Gn = _maybe("grad_phi_norm")
        if Gn is not None: maps["grad_phi_norm"] = Gn[agent_index] if Gn.ndim == 3 else Gn
    Gm = _maybe("grad_phi_model")
    if Gm is not None:
        maps["grad_phi_model_norm"] = np.linalg.norm(Gm[agent_index], axis=-1) if Gm.ndim == 4 else np.linalg.norm(Gm, axis=-1)
    else:
        Gmn = _maybe("grad_phi_model_norm")
        if Gmn is not None: maps["grad_phi_model_norm"] = Gmn[agent_index] if Gmn.ndim == 3 else Gmn

    return maps






# ---------- separate GIF per metric (mask skipped) ----------

def animate_separate_metrics(snapshot_dir: str,
                             out_dir: str,
                             metrics: Optional[List[str]] = None,
                             fps: int = 8,
                             dpi: int = 120,
                             cmap: str = "viridis",
                             agent_index: int = 0,
                             exclude: Tuple[str, ...] = ("mask",),
                             per_metric_percentiles: Optional[Dict[str, Tuple[float, float]]] = None,
                             limit: Optional[int] = None) -> List[str]:
    """
    Streamed, memory-safe per-metric GIF writer.
    - Discovers metrics from the first frame when `metrics` is None
    - Computes robust vmin/vmax from a SAMPLE of frames
    - Streams frames directly to GIF via _gif_writer (imageio v2-compatible)
    """
    # discover metrics from the FIRST frame only
    first_it = _iter_snapshots_lazy(snapshot_dir, limit=1)
    try:
        step0, npz0 = next(first_it)
    except StopIteration:
        print(f"[ANIM] no snapshots found under {snapshot_dir}")
        return []

    maps0 = compute_scalar_maps({k: npz0[k] for k in npz0.files}, agent_index=agent_index)
    if metrics is None:
        metrics = [k for k in _DEFAULT_PANELS if k in maps0 and k not in exclude]
    metrics = [m for m in metrics if m not in exclude]
    if not metrics:
        return []

    # compute vlims from a SAMPLE of frames (keeps memory tiny)
    sample_paths = list(_iter_snapshot_paths(snapshot_dir, limit))  # list[(step, path)]
    if len(sample_paths) <= 256:
        sample_idxs = range(len(sample_paths))
    else:
        import numpy as _np
        sample_idxs = _np.linspace(0, len(sample_paths) - 1, 256, dtype=int)

    vlims: Dict[str, Tuple[float, float]] = {}
    for m in metrics:
        lo_vals: List[float] = []
        hi_vals: List[float] = []
        pmin_default, pmax_default = (0.1, 99.9) if m in ("belief_align", "model_align") else (1.0, 99.0)
        if per_metric_percentiles and m in per_metric_percentiles:
            pmin, pmax = per_metric_percentiles[m]
        else:
            pmin, pmax = pmin_default, pmax_default

        for idx in sample_idxs:
            _, f = sample_paths[idx]
            with np.load(f, allow_pickle=False) as npz:
                maps = compute_scalar_maps({k: npz[k] for k in npz.files}, agent_index=agent_index)
            if m in maps:
                v = maps[m]
                finite = v[np.isfinite(v)]
                if finite.size:
                    lo_vals.append(float(np.percentile(finite, pmin)))
                    hi_vals.append(float(np.percentile(finite, pmax)))

        if lo_vals and hi_vals:
            lo = float(np.median(lo_vals))
            hi = float(np.median(hi_vals))
            if not np.isfinite(hi) or hi <= lo:
                hi = lo + 1e-6
            vlims[m] = (lo, hi)

    Path(out_dir).mkdir(parents=True, exist_ok=True)
    written: List[str] = []

    def _fig_to_rgb(fig) -> np.ndarray:
        fig.canvas.draw()
        w, h = fig.canvas.get_width_height()
        return np.frombuffer(fig.canvas.tostring_rgb(), dtype=np.uint8).reshape(h, w, 3)

    for m in metrics:
        out_path = str(Path(out_dir) / f"{m}.gif")
        if not _HAS_IMAGEIO:
            print(f"[ANIM] imageio not available; cannot write {out_path}")
            continue

        with _gif_writer(out_path, fps=fps) as writer:
            for step, npz in _iter_snapshots_lazy(snapshot_dir, limit):
                plt.close("all")
                maps = compute_scalar_maps({k: npz[k] for k in npz.files}, agent_index=agent_index)

                fig, ax = plt.subplots(1, 1, figsize=(6, 6))
                if m not in maps:
                    ax.axis("off")
                    ax.set_title(f"{m} (missing)")
                else:
                    vmin, vmax = vlims.get(m, (None, None))
                    im = ax.imshow(maps[m], cmap=cmap, vmin=vmin, vmax=vmax, interpolation="nearest")
                    ax.set_title(f"{m} — step {step}")
                    ax.set_xticks([]); ax.set_yticks([])
                    plt.colorbar(im, ax=ax, fraction=0.046, pad=0.04)

                fig.set_dpi(dpi)
                writer.append_data(_fig_to_rgb(fig))
                plt.close(fig)

        written.append(out_path)

    if written:
        print(f"[ANIM] wrote {len(written)} GIFs to {out_dir}")
    return written




# =========================== Plotting (static) ===============================


def _render_panel(ax, arr: np.ndarray, title: str, cmap: str = "viridis", robust: bool = True):
    if arr is None:
        ax.axis("off")
        ax.set_title(f"{title} (missing)")
        return
    vmin, vmax = _robust_norm(arr) if robust else (float(np.min(arr)), float(np.max(arr)))
    im = ax.imshow(arr, cmap=cmap, vmin=vmin, vmax=vmax, interpolation="nearest")
    ax.set_title(title)
    ax.set_xticks([]); ax.set_yticks([])
    plt.colorbar(im, ax=ax, fraction=0.046, pad=0.04)

def plot_grid_from_npz(npz: Dict[str, np.ndarray],
                       panels: List[str] = None,
                       suptitle: str = "",
                       figsize: Tuple[int,int] = (14, 10),
                       cmap: str = "viridis",
                       robust: bool = True,
                       agent_index: int = 0):
    if panels is None:
        panels = _DEFAULT_PANELS
    maps = compute_scalar_maps(npz, agent_index=agent_index)
    keys = [k for k in panels if k in maps]
    n = max(len(keys), 1)
    cols = min(3, n)
    rows = math.ceil(n / cols)

    fig, axes = plt.subplots(rows, cols, figsize=figsize, squeeze=False)
    for k, ax in zip(keys, axes.flat):
        _render_panel(ax, maps[k], k, cmap=cmap, robust=robust)
    for ax in axes.flat[len(keys):]:
        ax.axis("off")
    if suptitle:
        fig.suptitle(suptitle)
    fig.tight_layout()
    return fig

# ============================= Animation =====================================

def animate_from_dir(snapshot_dir: str,
                     out_path: str,
                     panels: List[str] = None,
                     fps: int = 8,
                     dpi: int = 120,
                     cmap: str = "viridis",
                     robust: bool = True,
                     limit: Optional[int] = None,
                     agent_index: int = 0) -> str:
    """
    Streamed, memory-safe animation:
      - Iterates snapshots lazily (no bulk preload)
      - Streams frames directly to GIF via _gif_writer (imageio v2-compatible)
      - Falls back to ffmpeg MP4; if that fails, writes GIF as final fallback
    """
    want_gif = out_path.lower().endswith(".gif")

    def _fig_to_rgb(fig) -> np.ndarray:
        fig.canvas.draw()
        w, h = fig.canvas.get_width_height()
        return np.frombuffer(fig.canvas.tostring_rgb(), dtype=np.uint8).reshape(h, w, 3)

    if want_gif:
        if not _HAS_IMAGEIO:
            raise RuntimeError("imageio not available; install imageio to write GIFs")

        any_frame = False
        with _gif_writer(out_path, fps=fps) as writer:
            for step, npz in _iter_snapshots_lazy(snapshot_dir, limit):
                any_frame = True
                plt.close("all")
                data = {k: npz[k] for k in npz.files}  # per-frame dict, not all frames
                fig = plot_grid_from_npz(
                    data, panels=panels, suptitle=f"step {step}",
                    cmap=cmap, robust=robust, agent_index=agent_index
                )
                fig.set_dpi(dpi)
                writer.append_data(_fig_to_rgb(fig))
                plt.close(fig)
        if not any_frame:
            raise FileNotFoundError(f"No snapshots found under {snapshot_dir}")

    else:
        # MP4 path: write streamed PNGs, then stitch with ffmpeg
        tmpdir = Path(snapshot_dir) / "_frames_tmp"
        tmpdir.mkdir(exist_ok=True)
        pngs: List[str] = []
        any_frame = False
        try:
            for t, (step, npz) in enumerate(_iter_snapshots_lazy(snapshot_dir, limit)):
                any_frame = True
                plt.close("all")
                data = {k: npz[k] for k in npz.files}
                fig = plot_grid_from_npz(
                    data, panels=panels, suptitle=f"step {step}",
                    cmap=cmap, robust=robust, agent_index=agent_index
                )
                png_path = tmpdir / f"frame_{t:05d}.png"
                fig.savefig(png_path, dpi=dpi, bbox_inches="tight")
                pngs.append(str(png_path))
                plt.close(fig)

            if not any_frame:
                raise FileNotFoundError(f"No snapshots found under {snapshot_dir}")

            cmd = f'ffmpeg -y -r {fps} -i "{tmpdir.as_posix()}/frame_%05d.png" -vcodec libx264 -pix_fmt yuv420p "{out_path}"'
            subprocess.run(shlex.split(cmd), check=True, stdout=subprocess.DEVNULL, stderr=subprocess.STDOUT)

        except Exception as e:
            if _HAS_IMAGEIO:
                warnings.warn(f"ffmpeg failed ({e}); writing GIF instead", RuntimeWarning)
                gif_path = str(Path(out_path).with_suffix(".gif"))
                with _gif_writer(gif_path, fps=fps) as writer:
                    for p in pngs:
                        writer.append_data(iio.imread(p))
                out_path = gif_path
            else:
                raise
        finally:
            for p in pngs:
                try:
                    os.remove(p)
                except Exception:
                    pass
            try:
                tmpdir.rmdir()
            except Exception:
                pass

    print(f"[ANIM] wrote {out_path}")
    return out_path


# ============================ Timeseries =====================================

def load_metric_log(outdir: str) -> List[dict]:
    """Try metric_log.pkl first; fallback to per_agent_metrics.csv aggregated."""
    pkl = Path(outdir) / "metric_log.pkl"
    if pkl.exists():
        with open(pkl, "rb") as f:
            return pickle.load(f)
    csv = Path(outdir) / "per_agent_metrics.csv"
    if csv.exists():
        try:
            import pandas as pd
            df = pd.read_csv(csv)
            numeric_cols = [c for c in df.columns if df[c].dtype != "O" and c not in ("agent",)]
            g = df.groupby("step")[numeric_cols].mean().reset_index()
            return g.to_dict(orient="records")
        except Exception as e:
            warnings.warn(f"Failed to aggregate per_agent_metrics.csv: {e}")
    return []

def plot_energy_timeseries(outdir: str,
                           keys: List[str] = None,
                           savepath: Optional[str] = None,
                           figsize: Tuple[int,int] = (10,6)):
    """
    Plot total/ component energies logged each step.
    Defaults to the keys emitted by log_all_metrics().
    """
    recs = load_metric_log(outdir)
    if not recs:
        raise FileNotFoundError(f"No metric logs found under {outdir}")

    if keys is None:
        keys = ["e_self","e_feedback","e_align","e_mod_align","e_curv","e_curv_mod","e_mass","e_mass_mod","total_energy"]

    steps = [r.get("step", i) for i, r in enumerate(recs)]
    plt.figure(figsize=figsize)
    for k in keys:
        vals = [r.get(k, np.nan) for r in recs]
        if np.all(np.isnan(vals)):
            continue
        plt.plot(steps, vals, label=k, lw=1.8)
    plt.xlabel("step")
    plt.ylabel("energy")
    plt.title("Energies over time")
    plt.grid(alpha=0.3)
    plt.legend(ncol=2, fontsize=9)
    if savepath:
        Path(savepath).parent.mkdir(parents=True, exist_ok=True)
        plt.savefig(savepath, dpi=140, bbox_inches="tight")
        print(f"[PLOT] wrote {savepath}")
    return plt.gcf()

def plot_energy_timeseries_separate(outdir: str,
                                    keys: List[str] = None,
                                    save_dir: Optional[str] = None,
                                    figsize: Tuple[int,int] = (8,5),
                                    dpi: int = 140) -> List[str]:
    """
    Render each metric as its own figure.
    Returns list of written file paths (empty if save_dir is None).
    """
    recs = load_metric_log(outdir)
    if not recs:
        raise FileNotFoundError(f"No metric logs found under {outdir}")
    if keys is None:
        keys = ["e_self","e_feedback","e_align","e_mod_align","e_curv","e_curv_mod","e_mass","e_mass_mod","total_energy"]

    steps = np.array([r.get("step", i) for i, r in enumerate(recs)])
    written: List[str] = []
    if save_dir:
        Path(save_dir).mkdir(parents=True, exist_ok=True)

    for k in keys:
        vals = np.array([r.get(k, np.nan) for r in recs], dtype=float)
        if np.all(np.isnan(vals)):
            continue
        plt.figure(figsize=figsize)
        plt.plot(steps, vals, lw=2.0)
        plt.xlabel("step"); plt.ylabel(k); plt.title(k.replace("_"," "))
        plt.grid(alpha=0.3)
        if save_dir:
            fpath = str(Path(save_dir) / f"{k}.png")
            plt.savefig(fpath, dpi=dpi, bbox_inches="tight")
            written.append(fpath)
            plt.close()
    if save_dir:
        if written:
            print(f"[PLOT] wrote {len(written)} figures to {save_dir}")
    return written

# --- Parallel wrappers for animations -----------------------------------------

os.environ.setdefault("MPLBACKEND", "Agg")       # safe for headless rendering
os.environ.setdefault("OMP_NUM_THREADS", "1")    # avoid BLAS oversubscription


import multiprocessing as mp
from joblib import Parallel, delayed, parallel_backend

def _list_metrics_from_first_snapshot(snapshot_dir: str, exclude=()):
    snaps = load_snapshots_dir(snapshot_dir)
    if not snaps:
        return []
    # Derive metric keys from the first snapshot; honor exclusions
    keys = list(snaps[0].data.keys())
    return [k for k in keys if k not in exclude]

import psutil, multiprocessing as mp


def animate_metrics_parallel(
    snapshot_dir: str,
    out_dir: str,
    *,
    metrics=None,
    exclude=("mask",),
    fps=15,
    dpi=130,
    agent_index=0,
    per_metric_percentiles=None,
    limit=None,
    n_jobs=-1,
    backend="threading",          # "loky" (processes) | "threading" (I/O bound)
    verbose=10,
):
    """
    Run animate_separate_metrics for each metric in parallel (one process per metric).
    Writes each metric's GIF/frames into its own subfolder under out_dir.

    Reuses your existing animate_separate_metrics(...) implementation to avoid
    re-writing any plotting code; we just isolate outputs and parallelize.
    """
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)

    # If caller didn't pass explicit metrics, infer from first snapshot and exclude a few.
    if metrics is None:
        metrics = _list_metrics_from_first_snapshot(snapshot_dir, exclude=exclude)
    if not metrics:
        print("[parallel] no metrics found to render")
        return

    if n_jobs in (-1, None):
        # use ~1/3 of CPUs, cap at 6
        n_jobs = max(1, min(6, mp.cpu_count() // 3 or 1))

    # Optional: auto-cap by available RAM (rough heuristic ~400MB per worker)
    try:
        avail = psutil.virtual_memory().available
        max_by_ram = max(1, int(avail // (400 * 1024 * 1024)))
        n_jobs = min(n_jobs, max_by_ram)
    except Exception:
        pass

    def _render_one_metric(metric: str):
        # dedicate a unique subdir to avoid any cross-process collisions
        metric_out_dir = str(out / metric)
        Path(metric_out_dir).mkdir(parents=True, exist_ok=True)

        # Call your original function but constrain it to a single metric
        # NOTE: we pass exclude=() because we already selected the metric
        animate_separate_metrics(
            snapshot_dir,
            metric_out_dir,
            metrics=[metric],
            fps=fps,
            dpi=dpi,
            agent_index=agent_index,
            exclude=(),
            per_metric_percentiles=per_metric_percentiles,
            limit=limit,
        )
        return metric

    print(f"[parallel] rendering {len(metrics)} metrics with backend={backend}, n_jobs={n_jobs}")
    with parallel_backend(backend, n_jobs=n_jobs):
        Parallel(verbose=verbose)(
            delayed(_render_one_metric)(m) for m in metrics
        )


# =============================== main toggles ================================


if __name__ == "__main__":
    # --------- EDIT THESE TO YOUR LIKING ----------
    SNAPSHOT_DIR = "checkpoints/fields"
    OUT_DIR      = "out/plots"

    PANELS = [
        "mask",
        "phi_norm", "phi_model_norm",
        "belief_align", "model_align",
        "Fq_norm", "Fp_norm",
        "mu_q_norm", "mu_p_norm",
        "sigma_q_logdet", "sigma_p_logdet",
        "phi_morph_norm", "phi_tilde_morph_norm",
        "lambda_q_norm", "lambda_p_norm",
        "grad_phi_norm", "grad_phi_model_norm",
    ]

    # Behavior toggles
    DO_FRAME      = False
    DO_ANIM       = True
    DO_TIMESERIES = True
    DO_TS_SEPARATE = True

    # Parallel options for animations
    PAR_BACKEND = "loky"   # "loky" for CPU-bound rendering; "threading" for I/O-heavy
    NUM_WORKERS = -1       # -1 → use (CPU count - 1)
    LIMIT_FRAMES = None    # e.g., 2000 to cap animation length

    FRAME_FILENAME = str(Path(OUT_DIR) / "latest_frame.png")
    ANIM_DIR       = str(Path(OUT_DIR) / "gifs")   # we’ll place per-metric outputs here
    FPS            = 50
    DPI            = 100
    ROBUST         = True
    AGENT_INDEX    = 1

    Path(OUT_DIR).mkdir(parents=True, exist_ok=True)

    PER_METRIC_PERCENTILES = {
        "belief_align": (0.1, 99.9),
        "model_align":  (0.1, 99.9),
    }

    

    if DO_ANIM:
        animate_metrics_parallel(
            SNAPSHOT_DIR,
            ANIM_DIR,
            metrics=None,                    # infer from snapshots
            exclude=("mask",),
            fps=FPS,
            dpi=DPI,
            agent_index=AGENT_INDEX,
            per_metric_percentiles=PER_METRIC_PERCENTILES,
            limit=LIMIT_FRAMES,              # set to 2000 for your run
            n_jobs=NUM_WORKERS,
            backend=PAR_BACKEND,
            verbose=10,
        )

    if DO_FRAME:
        snaps = load_snapshots_dir(SNAPSHOT_DIR)
        if not snaps:
            print(f"[FRAME] no snapshots found under {SNAPSHOT_DIR}")
        else:
            snap = snaps[-1]
            fig = plot_grid_from_npz(
                snap.data, panels=PANELS,
                suptitle=f"step {snap.step}", robust=ROBUST, agent_index=AGENT_INDEX
            )
            fig.savefig(FRAME_FILENAME, dpi=DPI, bbox_inches="tight")
            print(f"[FRAME] wrote {FRAME_FILENAME}")

    if DO_TIMESERIES:
        ts_path = str(Path(OUT_DIR) / "energy_timeseries.png")
        plot_energy_timeseries(Path(SNAPSHOT_DIR).parent, savepath=ts_path)
        print(f"[TS] wrote {ts_path}")

    if DO_TS_SEPARATE:
        sep_dir = str(Path(OUT_DIR) / "energies")
        plot_energy_timeseries_separate(Path(SNAPSHOT_DIR).parent, save_dir=sep_dir)
