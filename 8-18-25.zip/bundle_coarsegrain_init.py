# -*- coding: utf-8 -*-
"""
Created on Tue Aug 12 18:56:28 2025

@author: chris and christine
"""

from __future__ import annotations
import numpy as np
import config

from numerical_utils import safe_inv
from omega import exp_lie_algebra_irrep  # group exponential for so(3)
from agent_initialization import initialize_agent_gradients
import numpy as np
import config
from numerical_utils import resize_nn
from omega import safe_bch_exact




# --- Periodic RG coarse-graining for ALL parents (outside spawn) ------------
def _periodic_parent_coarsegrain(ctx, children, Gq, Gp, params):
    """
    Run canonical coarse-graining for every existing parent, on a fixed period.
    - Preprocesses ONLY children (parents may be newborns with uninitialized fields).
    - (Optionally) builds Λ_up caches from children; parents are ensured lazily in CG.
    - Calls coarsegrain_parent_from_children(P, children, ...) for each parent.
    """
    import numpy as np, config
    from preprocess_utils import build_all_lambda_caches, preprocess_all_agents
    # coarsegrain_parent_from_children is expected to be in this module; if not, import it:
    # from bundle_coarsegrain_init import coarsegrain_parent_from_children

    parents = [p for p in (getattr(ctx, "parents_by_region", {}) or {}).values() if p is not None]
    if not parents:
        return

    # schedule
    step_now = int(getattr(ctx, "global_step", 0))
    period = int(getattr(config, "parent_cg_period", params.get("parent_cg_period", 50)))
    if period <= 0 or (step_now % period) != 0:
        return

    cg_eps = float(getattr(config, "cg_eps", 1e-6))
    cg_tau = float(getattr(config, "parent_cover_support_eps", 0.30))

    # 1) preprocess only children (they always have valid fields)
    child_only = [c for c in (children or []) if c is not None]
    if child_only:
        preprocess_all_agents(child_only, params, G_q=Gq, G_p=Gp)
        # 2) build Λ caches from children only (parents' views are attached lazily in CG)
        try:
            build_all_lambda_caches(child_only)
        except Exception as e:
            print(f"[CG] lambda-cache (children-only) build warning: {e}")

    # 3) now coarse-grain per-parent; this function calls _ensure_parent_fields(...)
    for P in parents:
        try:
            # Pass generators so CG never guesses the irrep (Kq×Kq, Kp×Kp)
            coarsegrain_parent_from_children(
                P, children,
                eps=cg_eps,
                mask_tau=cg_tau,
                G_q=Gq,
                G_p=Gp,
            )
        except Exception as e:
            pid = getattr(P, 'id', '?')
            print(f"[CG] periodic coarsegrain failed for parent {pid}: {e}")

    # bump cache version so downstream can refresh Ω/Λ next step
    if hasattr(ctx, "cache_version"):
        ctx.cache_version = int(getattr(ctx, "cache_version", 0)) + 1





def coarsegrain_parent_from_children(P, children, *, eps=1e-6, mask_tau=None, G_q=None, G_p=None):
    """
    Canonical RG coarse-grain with newborn robustness — **no 3×3 shortcuts**.
    - Transport in the correct irrep using G_q (Kq×Kq) / G_p (Kp×Kp)
    - Moment match (μ, Σ) in q- and p-fibers
    - Karcher mean for φ/φ̃ via **algebraic** updates using BCH in the supplied irrep
    """
    import numpy as np

    # ---- helpers (irrep-safe) -------------------------------------------------
    def _need(which: str, K: int, hint):
        if hint is not None:
            return hint
        # Prefer generators already attached to the parent
        cand = getattr(P, "_G_q" if which == "q" else "_G_p", None)
        if cand is not None:
            return cand
        try:
            from get_generators import get_generators
            return get_generators(getattr(config, "group_name", "SO(3)"), K)
        except Exception as e:
            raise RuntimeError(f"Missing generators for {which}-fiber (K={K}). Pass G_{which}.") from e

    def _Igrid(H, W, K):
        I = np.eye(K, dtype=np.float64)
        return np.broadcast_to(I, (H, W, K, K)).copy()

    def _rot_from_phi(phi_field, H, W, G, K):
        if phi_field is None:
            return _Igrid(H, W, K)
        phi = np.asarray(phi_field, np.float64).reshape(H * W, 3)
        E = exp_lie_algebra_irrep(phi, G).reshape(H, W, K, K)
        return E

    # Algebraic projections in given basis {G_a}
    def _gram(G):
        # M_ab = Tr(G_a^T G_b)
        return np.array([[np.einsum("ij,ij->", G[a].T, G[b]) for b in range(3)] for a in range(3)], dtype=np.float64)

    def _as_mat(phi_hw3, G):
        # Φ(y,x) = Σ_a φ^a(y,x) G_a
        return np.einsum("...a,aij->...ij", phi_hw3, G, optimize=True)

    def _coeffs_from_mat(X_hwKK, G, Minv=None):
        # Project algebra matrix X onto basis using Frobenius metric
        if Minv is None:
            Minv = safe_inv(_gram(G).astype(np.float64))
        b = np.stack([np.einsum("...ij,ij->...", X_hwKK, G[a].T, optimize=True) for a in range(3)], axis=-1)
        # (...,3) = (...,3) @ (3,3)^T  (but Minv is 3×3 so either left/right works with einsum)
        return np.einsum("ab,...b->...a", Minv, b, optimize=True)

    def _karcher_mean_phi_irrep(phi_list, w_list, H, W, G, *, iters=6, eta=1.0, tol=1e-7):
        """
        Karcher mean in the supplied irrep (no quaternion shortcuts).
        Iteration in algebra coords via BCH:
            Δ_i = Log(exp(-Φ) exp(Φ_i))  ≈  BCH(-Φ, Φ_i)
            Δ   = (Σ w_i Δ_i) / Σ w_i
            Φ   ← Log(exp(Φ) exp(ηΔ))    ≈  BCH(Φ, ηΔ)
        """
        assert len(phi_list) == len(w_list) and len(phi_list) >= 1
        N = H * W
        # stack to (N,3) and (N,1)
        PHIS = [np.asarray(p, np.float64).reshape(N, 3) for p in phi_list]
        WTS  = [np.asarray(w, np.float64).reshape(N, 1) for w in w_list]
        Wsum = np.maximum(np.sum(WTS, axis=0), 1e-12)  # (N,1)
        # init = weighted Euclidean mean (small-θ safe and fast)
        phi = (np.sum([w * p for p, w in zip(PHIS, WTS)], axis=0) / Wsum).reshape(N, 3)
        K   = G.shape[-1]
        Minv = safe_inv(_gram(G).astype(np.float64))

        for _ in range(int(iters)):
            # Φ_mean as matrices
            Phi_mat = _as_mat(phi.reshape(N, 3), G).reshape(N, K, K)
            # accumulate Δ
            Delta = np.zeros((N, 3), np.float64)
            for p, w in zip(PHIS, WTS):
                Phi_i = _as_mat(p, G).reshape(N, K, K)
                # Δ_i = Log(exp(-Φ) exp(Φ_i)) using BCH in this irrep
                # safe_bch_exact computes the BCH(A,B) matrix
                Di = np.stack([safe_bch_exact(-Phi_mat[i], Phi_i[i]) for i in range(N)], axis=0)
                delta_i = _coeffs_from_mat(Di, G, Minv=Minv)  # (N,3)
                Delta += w * delta_i
            Delta /= Wsum
            # stopping criterion
            if np.all(np.linalg.norm(Delta, axis=-1) < tol):
                break
            # update Φ ← BCH(Φ, ηΔ)
            D_mat = _as_mat(eta * Delta, G).reshape(N, K, K)
            Phi_new = np.stack([safe_bch_exact(Phi_mat[i], D_mat[i]) for i in range(N)], axis=0)
            phi = _coeffs_from_mat(Phi_new, G, Minv=Minv)
        return phi.reshape(H, W, 3)

    
# ---- newborn-safe sizes & generators -------------------------------------
    H, W, Kq, Kp = _ensure_parent_fields(P, children, eps=eps)
    Gq = _need("q", Kq, G_q)  # (3,Kq,Kq)
    Gp = _need("p", Kp, G_p)  # (3,Kp,Kp)

    # ---- gates ----------------------------------------------------------------
    core = _parent_mask_core(P)
    if core is None or not np.any(core):
        return
    support_tau = float(mask_tau) if (mask_tau is not None) else float(getattr(config, "support_cutoff_eps", 1e-4))

    # ---- collect contributing children & weights ------------------------------
    wmap = getattr(P, "child_weights", {}) or {}
    pairs = []
    for c in (children or []):
        if c is None:
            continue
        w = float(wmap.get(int(getattr(c, "id", -1)), 0.0))
        if w > 0.0:
            pairs.append((c, w))
    if not pairs:
        return

    # parent rotations in irreps (identity for newborns)
    Eq_parent = _rot_from_phi(getattr(P, "phi", None), H, W, Gq, Kq)
    Ep_parent = _rot_from_phi(getattr(P, "phi_model", None), H, W, Gp, Kp)

    # === q-fiber (μ, Σ) =======================================================
    Wsum_q  = np.zeros((H, W), np.float64)
    mu_acc  = np.zeros((H, W, Kq), np.float64)
    Sig_acc = np.zeros((H, W, Kq, Kq), np.float64)

    # for φ mean (algebra), use φ fields + weights
    phi_list_q, w_list_q = [], []

    for c, w in pairs:
        m_c = (np.asarray(c.mask, np.float32) > support_tau)
        w_sp = (w * m_c.astype(np.float64))
        w_sp[~core] = 0.0
        if not np.any(w_sp):
            continue

        # transport via Kq irrep
        phi_c = getattr(c, "phi", None)
        if phi_c is None:
            continue  # cannot build rotation in Kq for this child
        Eq_child = _rot_from_phi(phi_c, H, W, Gq, Kq)
        Lq = Eq_parent @ np.swapaxes(Eq_child, -1, -2)

        muT = (Lq @ np.asarray(c.mu_q_field, np.float64)[..., None])[..., 0]
        ST  = Lq @ np.asarray(c.sigma_q_field, np.float64) @ np.swapaxes(Lq, -1, -2)
        ST  = 0.5 * (ST + np.swapaxes(ST, -1, -2))

        Sig_acc += w_sp[..., None, None] * ST
        mu_acc  += w_sp[..., None] * muT
        Wsum_q  += w_sp

        # Karcher: accumulate algebra coords (just φ field of child)
        phi_list_q.append(np.asarray(phi_c, np.float64).reshape(H, W, 3))
        w_list_q.append(w_sp[..., None])

    valid_q = Wsum_q > 0.0
    if np.any(valid_q):
        muP = np.zeros((H, W, Kq), np.float64)
        muP[valid_q] = mu_acc[valid_q] / Wsum_q[valid_q, None]

        diff = np.zeros_like(Sig_acc)
        # NOTE: if you want exact second-moment correction, keep mu_list_q; else skip.
        # (Keeping structure for future extension.)

        Sig = Sig_acc + diff
        Iq  = np.eye(Kq, dtype=np.float64)
        Sig = 0.5 * (Sig + np.swapaxes(Sig, -1, -2)) + eps * Iq

        P.mu_q_field[valid_q]    = muP[valid_q].astype(np.float32)
        P.sigma_q_field[valid_q] = Sig[valid_q].astype(np.float32)

    # === p-fiber (μ, Σ) =======================================================
    Wsum_p  = np.zeros((H, W), np.float64)
    mu_acc_p  = np.zeros((H, W, Kp), np.float64)
    Sig_acc_p = np.zeros((H, W, Kp, Kp), np.float64)

    phi_list_p, w_list_p = [], []

    for c, w in pairs:
        m_c = (np.asarray(c.mask, np.float32) > support_tau)
        w_sp = (w * m_c.astype(np.float64))
        w_sp[~core] = 0.0
        if not np.any(w_sp):
            continue

        phi_m = getattr(c, "phi_model", None)
        if phi_m is None:
            continue
        Ep_child = _rot_from_phi(phi_m, H, W, Gp, Kp)
        Lp = Ep_parent @ np.swapaxes(Ep_child, -1, -2)

        muT = (Lp @ np.asarray(c.mu_p_field, np.float64)[..., None])[..., 0]
        ST  = Lp @ np.asarray(c.sigma_p_field, np.float64) @ np.swapaxes(Lp, -1, -2)
        ST  = 0.5 * (ST + np.swapaxes(ST, -1, -2))

        Sig_acc_p += w_sp[..., None, None] * ST
        mu_acc_p  += w_sp[..., None] * muT
        Wsum_p    += w_sp

        phi_list_p.append(np.asarray(phi_m, np.float64).reshape(H, W, 3))
        w_list_p.append(w_sp[..., None])

    valid_p = Wsum_p > 0.0
    if np.any(valid_p):
        muP = np.zeros((H, W, Kp), np.float64)
        muP[valid_p] = mu_acc_p[valid_p] / Wsum_p[valid_p, None]

        diff = np.zeros_like(Sig_acc_p)

        Sig = Sig_acc_p + diff
        Ip  = np.eye(Kp, dtype=np.float64)
        Sig = 0.5 * (Sig + np.swapaxes(Sig, -1, -2)) + eps * Ip

        P.mu_p_field[valid_p]    = muP[valid_p].astype(np.float32)
        P.sigma_p_field[valid_p] = Sig[valid_p].astype(np.float32)

    # === φ / φ̃ Karcher means (algebra via BCH in given irrep) =================
    if phi_list_q:
        phi_mean_q = _karcher_mean_phi_irrep(phi_list_q, w_list_q, H, W, Gq, iters=6, eta=1.0, tol=1e-7)
        P.phi = phi_mean_q.astype(np.float32)
        P._exp_phi = exp_lie_algebra_irrep(phi_mean_q.reshape(-1, 3), Gq).reshape(H, W, Kq, Kq).astype(np.float32)

    if phi_list_p:
        phi_mean_p = _karcher_mean_phi_irrep(phi_list_p, w_list_p, H, W, Gp, iters=6, eta=1.0, tol=1e-7)
        P.phi_model = phi_mean_p.astype(np.float32)
        P._exp_phi_model = exp_lie_algebra_irrep(phi_mean_p.reshape(-1, 3), Gp).reshape(H, W, Kp, Kp).astype(np.float32)

    # expose generators on the parent for any downstream helper that needs them
    try:
        P._G_q = Gq
        P._G_p = Gp
    except Exception:
        pass

# -----------------------------------------------------------------------------
# SO(3) helpers (stable log & Karcher mean)
# -----------------------------------------------------------------------------


def _get_rotation(agent, which: str, H: int, W: int) -> np.ndarray:
    """
    Return cached rotation grid for agent in its **own irrep**; identity if absent.
    which = "q" -> _exp_phi  | "p" -> _exp_phi_model
    """
    if which == "q":
        E = getattr(agent, "_exp_phi", None)
        if E is not None:
            return np.asarray(E, np.float64)
        phi = getattr(agent, "phi", None)
        G   = getattr(agent, "_G_q", getattr(agent, "generators_q", None))
        if phi is None or G is None:
            # infer K from any available q-field
            K = int(np.asarray(getattr(agent, "mu_q_field")).shape[-1]) if getattr(agent, "mu_q_field", None) is not None else 3
            return _identity_rot_grid(H, W, K)
        K = G.shape[-1]
        return exp_lie_algebra_irrep(np.asarray(phi).reshape(-1, 3), G).reshape(H, W, K, K).astype(np.float64)
    else:
        E = getattr(agent, "_exp_phi_model", None)
        if E is not None:
            return np.asarray(E, np.float64)
        phi = getattr(agent, "phi_model", None)
        G   = getattr(agent, "_G_p", getattr(agent, "generators_p", None))
        if phi is None or G is None:
            K = int(np.asarray(getattr(agent, "mu_p_field")).shape[-1]) if getattr(agent, "mu_p_field", None) is not None else 3
            return _identity_rot_grid(H, W, K)
        K = G.shape[-1]
        return exp_lie_algebra_irrep(np.asarray(phi).reshape(-1, 3), G).reshape(H, W, K, K).astype(np.float64)




#==============================================================================
#
#
#
#===============================================================================








def _infer_hwk_from_children(children, which="q"):
    """
    Find (H,W,K) from the first child that has the requested bundle.
    which: "q" -> (mu_q_field), "p" -> (mu_p_field)
    """
    for c in children:
        mu = getattr(c, "mu_q_field" if which=="q" else "mu_p_field", None)
        if mu is not None:
            mu = np.asarray(mu)
            if mu.ndim >= 3:
                H, W, K = mu.shape[:3]
                return int(H), int(W), int(K)
    return None



def _ensure_parent_fields(P, children, *, eps=1e-6):
    dims_q = _infer_hwk_from_children(children, "q")
    dims_p = _infer_hwk_from_children(children, "p")

    if dims_q is None and dims_p is None:
        # Nothing to infer from yet — let caller skip CG this step
        raise ValueError("no child fields to infer dims")

    # Prefer q dims; fall back to p dims
    if dims_q is None:
        H, W, _ = dims_p
        Kq = _ = _infer_hwk_from_children(children, "q")[2] if _infer_hwk_from_children(children, "q") else None
        if Kq is None:
            # If truly no q K yet, pick Kq = 3 as a placeholder only if your code accepts it,
            # otherwise bail and let next step handle it.
            raise ValueError("no q-dims")
    else:
        H, W, Kq = dims_q

    if getattr(P, "mu_q_field", None) is None:
        P.mu_q_field = np.zeros((H, W, Kq), dtype=np.float32)
    if getattr(P, "sigma_q_field", None) is None:
        Iq = np.eye(Kq, dtype=np.float32)
        P.sigma_q_field = np.broadcast_to(Iq, (H, W, Kq, Kq)).copy()

    if dims_p is None:
        # Try to reuse H,W and set a minimal Kp from existing parent or skip
        mup = getattr(P, "mu_p_field", None)
        if mup is None:
            # Can't infer Kp → skip CG this round
            return H, W, Kq, getattr(P, "mu_p_field", np.zeros((H, W, 0), np.float32)).shape[-1]
        Kp = int(np.asarray(mup).shape[-1])
    else:
        H2, W2, Kp = dims_p
        if (H2, W2) != (H, W):
            H, W = H2, W2  # keep grids aligned (your framework assumes same grid)
            # also resize q fields if needed (optional; or bail out and wait next step)

    if getattr(P, "mu_p_field", None) is None:
        P.mu_p_field = np.zeros((H, W, Kp), dtype=np.float32)
    if getattr(P, "sigma_p_field", None) is None:
        Ip = np.eye(Kp, dtype=np.float32)
        P.sigma_p_field = np.broadcast_to(Ip, (H, W, Kp, Kp)).copy()

    return H, W, Kq, Kp


def _identity_rot_grid(H, W, K):
    """Return an (H,W,K,K) identity rotation grid for the given irrep size."""
    I = np.eye(K, dtype=np.float64)
    return np.broadcast_to(I, (H, W, K, K)).copy()





def _get_lambda_up(child, parent, which: str, H: int, W: int):
    """
    Preferred: ctx-built Λ maps (child.Lambda_up_*_map[parent.id]).
    Fallback:  Λ = E_parent · E_child^T using cached (or identity) rotations.
    Returns (Λ, used_fallback: bool)
    """
    if which == "q":
        m = getattr(child, "Lambda_up_q_map", None)
    else:
        m = getattr(child, "Lambda_up_p_map", None)
    if isinstance(m, dict):
        L = m.get(int(getattr(parent, "id", -1)))
        if L is not None:
            return np.asarray(L, np.float64), False
    Ep = _get_rotation(parent, which, H, W)  # irrep-safe
    Ec = _get_rotation(child,  which, H, W)
    return (Ep @ np.swapaxes(Ec, -1, -2)).astype(np.float64), True

# Tag the function so parent_spawn’s guard recognizes the right implementation
try:
    coarsegrain_parent_from_children._dbg_token = "CG-v2025-08-18-A"
    coarsegrain_parent_from_children._dbg_origin = f"{__name__}:{__file__}:{coarsegrain_parent_from_children.__code__.co_firstlineno}"
except Exception:
    pass




def _parent_mask_core(P) -> np.ndarray:
    M = np.asarray(getattr(P, "mask", None), np.float32)
    if M is None:
        return None
    thr_abs = float(getattr(config, "parent_growth_core_tau", 0.20))
    thr_rel = 0.50
    thr = max(thr_abs, thr_rel * float(np.max(M) if M.size else 0.0))
    return (M > thr)







