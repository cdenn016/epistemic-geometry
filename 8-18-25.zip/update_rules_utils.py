# -*- coding: utf-8 -*-
"""
Created on Tue Aug 12 20:10:51 2025

@author: chris and christine
"""
from preprocess_utils import attach_parent_lambda_views
import numpy as np
from preprocess_utils import build_all_omega_caches, build_all_lambda_caches, preprocess_all_agents
from runtime_context import _collect_by_ids
from gaussian_core import (
    _prep_A,
    directed_kl_weight_after_transport,
    geometric_blend,
    apply_evidence_modulators,
    curvature_boltzmann_from_children,
)


def _assign_children_to_parents( 
    children,
    parents_by_id,
    *,
    eps=1e-3,
    tau=0.30,
    temp=0.25,
    max_parents_per_child=2,
    core_tau=None,
    core_tau_rel=0.50,
    core_dilate_px=1,
    newborn_bootstrap_steps=2,
    allow_unassigned=True,
    agreement_map=None,           # e.g. runtime_ctx.Aq_agg / Ap_agg
    use_agreement=None,
    agree_weight=None,            # now used as λ in log-add: z += λ·log(A)
    debug=False,
):
    import numpy as np
    import config
    try:
        from scipy.ndimage import binary_dilation
    except Exception:
        binary_dilation = None

    from parent_utils import resize_nn  # unified NN resizer

    Ps = list(parents_by_id.values())
    Pn = len(Ps); I = len(children)

    # trivial exits
    if Pn == 0 or I == 0:
        for ch in children:
            setattr(ch, "labels", {}); setattr(ch, "parent_id", -1)
        for P in Ps:
            P.child_weights = {}; P.child_ids = ()
        return

    # shapes
    H, W = np.asarray(children[0].mask).shape[:2]

    # knobs
    if use_agreement is None:
        use_agreement = bool(getattr(config, "parent_assign_use_agreement", False))
    if agree_weight is None:
        agree_weight = float(getattr(config, "parent_assign_agree_weight", 1.0))

    activation   = str(getattr(config, "parent_assign_activation", "entmax")).lower()  # "softmax"|"sparsemax"|"entmax"
    null_enabled = bool(getattr(config, "parent_assign_null_enabled", True))
    null_logit   = float(getattr(config, "parent_assign_null_logit", 0.0))
    null_tau     = float(getattr(config, "parent_assign_null_tau", 0.5))

    # optional entropy calibration (keeps distributions from collapsing)
    cal = None
    if getattr(config, "parent_assign_target_entropy", None) is not None:
        cal = {"target_H": float(getattr(config, "parent_assign_target_entropy", 1.0)),
               "k":       float(getattr(config, "parent_assign_temp_k", 0.4))}

    # child boolean masks (already standardized in _pre_light)
    Cmb = [(np.asarray(ch.mask, np.float32) > float(eps)) for ch in children]

    # parent masks array (sanitize once)
    Pmasks = [np.nan_to_num(np.asarray(P.mask, np.float32), nan=0.0, posinf=0.0, neginf=0.0) for P in Ps]

    abs_core = float(core_tau if core_tau is not None
                     else getattr(config, "parent_growth_core_tau", 0.20))
    rel_core = float(core_tau_rel)

    # parent cores
    Pcore = []
    for idx, pm in enumerate(Pmasks):
        mmax = float(pm.max()) if pm.size else 0.0
        thr  = max(abs_core, rel_core * mmax)
        age  = int(getattr(Ps[idx], "_age", 0) or 0)
        if age < int(newborn_bootstrap_steps):
            thr *= 0.6  # relax for newborns
        core = (pm > thr)
        if core_dilate_px and binary_dilation is not None and core.any():
            core = binary_dilation(core, iterations=int(core_dilate_px))
        Pcore.append(core)

    # agreement map (optional)
    A_map = None
    if use_agreement and (agreement_map is not None):
        A_map = np.asarray(agreement_map, np.float32)
        if A_map.shape[:2] != (H, W):
            try:
                A_map = resize_nn(A_map, (H, W)).astype(np.float32)
            except Exception:
                A_map = None
        if A_map is not None:
            A_map = np.clip(np.nan_to_num(A_map, nan=0.0, posinf=1.0, neginf=0.0), 0.0, 1.0)

    # -------------------- build IoU scores + (per-child) agreement vectors --------------------
    S = np.full((I, Pn), -np.inf, np.float32)  # IoU on cores (base scores)
    A = np.ones((I, Pn),  np.float32)          # mean agreement on child∧core
    valid = np.zeros((I, Pn), bool)

    for i, cm in enumerate(Cmb):
        if not cm.any():
            continue
        for p, core in enumerate(Pcore):
            if not core.any():
                continue
            ov = (cm & core)
            inter = int(ov.sum())
            if inter == 0:
                continue

            union = int((cm | core).sum())
            base = float(inter) / float(max(1, union))  # IoU on core
            S[i, p] = base
            valid[i, p] = (base >= float(tau))  # keep τ as a validity gate

            if A_map is not None:
                a = float(np.nanmean(A_map[ov])) if ov.any() else 0.0
                if not np.isfinite(a): a = 0.0
                A[i, p] = np.clip(a, 1e-6, 1.0)  # for log-add later

    # -------------------- normalize per child using your helper --------------------
    W = np.zeros((I, Pn), np.float32)  # final parent weights (no null here)
    entropy_list, top1_mass_list, null_mass_list, support_size_list = [], [], [], []

    for i in range(I):
        score_vec = S[i]
        valid_mask = valid[i]
        if not np.any(valid_mask):
            continue

        agree_vec = (A[i] if (A_map is not None and use_agreement) else None)

        # NOTE: _normalize_assignments is your helper (already added elsewhere)
        probs_all = _normalize_assignments(
            scores=score_vec[valid_mask],         # only pass valid parents
            agree=(agree_vec[valid_mask] if agree_vec is not None else None),
            valid_mask=None,                      # already filtered
            temp=float(temp),
            activation=activation,
            agree_weight=float(agree_weight),
            null_enabled=bool(null_enabled),
            null_logit=float(null_logit),
            calibrate=cal
        )
        # reconstruct into full parent index space
        if null_enabled:
            p_eff = probs_all[:-1]  # parents only
            p_null = float(probs_all[-1])
        else:
            p_eff = probs_all
            p_null = 0.0

        # map back to absolute indices
        idxs = np.where(valid_mask)[0]
        W[i, idxs] = p_eff

        # optional top-k AFTER normalization (keeps sparsemax/entmax sparsity)
        if max_parents_per_child and max_parents_per_child < len(idxs):
            k = int(max_parents_per_child)
            row = W[i, :]
            keep = idxs[np.argsort(-row[idxs])[:k]]
            pruned = np.setdiff1d(idxs, keep, assume_unique=False)
            if pruned.size:
                row[pruned] = 0.0
            s = row[keep].sum()
            if s > 0:
                row[keep] /= s
            W[i, :] = row

        # allow_unassigned vs. null
        if not allow_unassigned:
            # if all mass went null or zero, force best IoU parent
            if (W[i].sum() <= 0.0) or (null_enabled and p_null >= null_tau):
                # lenient fallback on raw parent masks (not cores)
                cm = Cmb[i]
                best_p, best_iou = -1, -1.0
                for p, pm in enumerate(Pmasks):
                    union = int((cm | (pm > 0)).sum())
                    if union == 0: continue
                    inter = int((cm & (pm > 0)).sum())
                    iou = float(inter) / float(union)
                    if iou > best_iou:
                        best_iou, best_p = iou, p
                if best_p >= 0 and best_iou > 0.0:
                    W[i, :] = 0.0
                    W[i, best_p] = 1.0

        # diagnostics
        peff = W[i, :]
        if peff.sum() > 0:
            peff_nz = peff[peff > 0]
            ent = -float(np.sum(peff_nz * np.log(peff_nz + 1e-20)))
            top1 = float(peff_nz.max()) if peff_nz.size else 1.0
            supp = int((peff > 1e-3).sum())
        else:
            ent, top1, supp = 0.0, 1.0, 0
        entropy_list.append(ent)
        top1_mass_list.append(top1)
        null_mass_list.append(p_null)
        support_size_list.append(supp)

    # -------------------- write back to children --------------------
    for i, ch in enumerate(children):
        # collect all nonzero parents with weights
        pairs = [(int(getattr(Ps[p], "id", p)), float(W[i, p]))
                 for p in range(Pn) if W[i, p] > 0.0]
    
        # sort by weight desc and cap to max_parents_per_child (already sparsified, but be safe)
        if pairs:
            pairs.sort(key=lambda t: -t[1])
            if max_parents_per_child and len(pairs) > int(max_parents_per_child):
                pairs = pairs[:int(max_parents_per_child)]
    
            # renormalize selected weights to 1.0
            s = sum(w for _, w in pairs)
            if s > 0:
                pairs = [(pid, w / s) for (pid, w) in pairs]
    
            # write labels + ids
            ch.labels = {pid: w for (pid, w) in pairs}
            ch.parent_ids = [pid for (pid, _) in pairs]
            ch.parent_id = int(ch.parent_ids[0]) if ch.parent_ids else -1
        else:
            # unassigned
            ch.labels = {}
            ch.parent_ids = []
            ch.parent_id = -1


    # -------------------- write back to parents --------------------
    # -------------------- write back to parents --------------------
    for p, P in enumerate(Ps):
        weights = {}
        ids = []
        for i, ch in enumerate(children):
            w = float(W[i, p])
            if w > 0.0:
                cid = int(getattr(ch, "id", i))
                weights[cid] = w
                ids.append(cid)
    
        # Optional: renormalize parent’s incoming weights to sum to 1 over its children
        s = sum(weights.values())
        if s > 0.0:
            for k in list(weights.keys()):
                weights[k] = weights[k] / s
    
        P.child_weights = weights
        P.child_ids = tuple(sorted(ids))


    # -------------------- debug summary --------------------
    if debug or bool(getattr(config, "debug_assign_summary", False)):
        Hm  = float(np.mean(entropy_list)) if entropy_list else 0.0
        T1m = float(np.mean(top1_mass_list)) if top1_mass_list else 0.0
        Nul = float(np.mean(null_mass_list)) if null_mass_list else 0.0
        FrN = float(np.mean([x >= null_tau for x in null_mass_list])) if null_enabled and null_mass_list else 0.0
        Sup = float(np.mean(support_size_list)) if support_size_list else 0.0
        print(f"[ASSIGN] act={activation} temp={float(temp):.3f} "
              f"Hmean={Hm:.3f} top1={T1m:.3f} null_mean={Nul:.3f} null>τ={FrN:.2f} "
              f"support_mean={Sup:.2f}")
        for p, P in enumerate(Ps):
            wsum = float(sum((P.child_weights or {}).values()))
            print(f"    P{getattr(P,'id',p)} kids={len(P.child_ids)} wsum={wsum:.3g}")



# --- core: from scores -> logits -> probs (with null) -------------------------
def _normalize_assignments(scores, agree=None, valid_mask=None, *,
                           temp=0.25, activation="softmax",
                           agree_weight=1.0, null_enabled=True,
                           null_logit=0.0, calibrate=None):
    """
    scores: [N_parents] raw similarity/alignment per child
    agree:  [N_parents] agreement \in [0,1]
    valid_mask: bool mask of admissible parents
    temp: base temperature
    activation: "softmax" | "sparsemax" | "entmax15"
    agree_weight: coefficient on log-agreement
    null_enabled: include 'null' option
    null_logit: prior logit for null
    calibrate: optional dict { 'target_H': float, 'k': float } for temp calibration
    """
    import numpy as np
    z = np.asarray(scores, np.float32)

    # convert multiplicative agree -> additive in logit space
    if agree is not None:
        a = np.clip(np.asarray(agree, np.float32), 1e-6, 1.0)
        z = z + float(agree_weight) * np.log(a)

    # temperature
    t = float(temp)
    if calibrate is not None and calibrate.get("target_H") is not None:
        # one-step exponential correction toward target entropy (cheap, stable)
        target_H = float(calibrate["target_H"])
        kappa    = float(calibrate.get("k", 0.5))
        sm = _softmax(z / max(1e-8, t), mask=valid_mask)
        H = -np.sum(sm * (np.log(sm + 1e-20)), axis=-1)
        # increase temp if too peaky (H < target), decrease if too flat
        t = t * float(np.exp(kappa * (target_H - H)))

    logits = z / max(1e-8, t)

    # attach null option (last index)
    if null_enabled:
        if valid_mask is None:
            vm = None
        else:
            vm = np.concatenate([valid_mask.astype(bool), np.array([True])], axis=-1)
        logits = np.concatenate([logits, np.array([float(null_logit)], dtype=np.float32)], axis=-1)
    else:
        vm = valid_mask

    # pick activation
    if activation == "sparsemax":
        p = _sparsemax(logits[None, :], mask=None if vm is None else vm[None, :])[0]
    elif activation in ("entmax", "entmax15"):
        p = _entmax15(logits[None, :], mask=None if vm is None else vm[None, :])[0]
    else:
        p = _softmax(logits[None, :], mask=None if vm is None else vm[None, :])[0]

    return p



  
def assign_parent_masks_from_alignment(ctx, children,
                                       generators_q, generators_p,
                                       *,
                                       mode="max",                # "max" or "mean"
                                       mask_tau=0.10,
                                       tau_q=None, tau_p=None, alpha=0.5,
                                       agree_map=None, agree_power=1.0,
                                       clamp_to_union=True,
                                       floor_eps=1e-6,
                                       min_pair_px=8,
                                       kl_cap=None,
                                       pnorm=99.0):              # percentile norm inside domain
    """
    Gauge-covariant parent mask assignment (pure evidence, no dilation).
    - Lives strictly on multi-child overlap (>=2 kids above mask_tau).
    - Uses assigned_child_ids if available (>=2), else falls back to child_ids ∪ assigned.
    - Transport: Ω_{ij}(x) from caches when available:
          Ω_{ij}^q(x) = Ci.Omega_cache[Cj.id][y,x]
          Ω_{ij}^p(x) = Ci.Omega_tilde_cache[Cj.id][y,x]
      If missing, fall back to cached exp fields: exp(φ_i) @ exp(-φ_j) (and model fiber).
      On last resort only, compute exp at the pixel.
    - Evidence per pair (i,j) at pixel x:
          w_ij(x) = 1{m_i>=τ}·1{m_j>=τ} · m_i(x)·m_j(x) · exp(-[(1-α)·DQ + α·DP])
      where DQ = KL(q_i || T_{j→i}(q_j)),   DP = KL(p_i || T_{j→i}(p_j)).
    - Aggregate across pairs via max or mean, clamp to children union if requested, then
      percentile-normalize within the admissible domain and clip to [0,1].
    """
    import numpy as np
    from numerical_utils import safe_inv
    from omega import exp_lie_algebra_irrep

    # ---- temps / caps ----
    try:
        import config
        if kl_cap is None:
            kl_cap = float(getattr(config, "signal_kl_cap", 10.0))
        if tau_q is None:
            tau_q = float(getattr(config, "tau_align_q", 0.45))
        if tau_p is None:
            tau_p = float(getattr(config, "tau_align_p", 0.45))
    except Exception:
        kl_cap = 10.0 if kl_cap is None else kl_cap
        tau_q = 0.45 if tau_q is None else tau_q
        tau_p = 0.45 if tau_p is None else tau_p

    parents = getattr(ctx, "parents_by_region", {}) or {}
    if not parents or not children:
        return

    H, W = np.asarray(children[0].mask, dtype=np.float32).shape[:2]

    # optional agreement prior A(x) ∈ [0,1]
    A = None
    if agree_map is not None:
        A = np.asarray(agree_map, np.float32)
        if A.shape != (H, W):
            from parent_utils import resize_nn
            A = resize_nn(A, (H, W))
        A = np.clip(np.nan_to_num(A, nan=1.0, posinf=1.0, neginf=0.0), 0.0, 1.0)

    # helpers
    def _mask_gate(m):
        # keep graded weight but zero out below τ
        g = (m >= mask_tau).astype(np.float32)
        return g * np.asarray(m, np.float32)

    def _support_bool(m):
        # boolean gate for "present" above τ
        return (np.asarray(m, np.float32) >= mask_tau)

    def _gaussian_kl(mu1, S1, mu2, S2, cap=10.0, eps=1e-8):
        # KL( N(mu1,S1) || N(mu2,S2) ) ; numerically safe, returns float
        d = mu1.shape[-1]
        S2i = safe_inv(S2, eps=eps)
        diff = (mu2 - mu1)[..., None]  # (d,1)
        t = float(np.trace(S2i @ S1))
        md = float((diff.T @ S2i @ diff).squeeze())
        sign1, logdet1 = np.linalg.slogdet(S1)
        sign2, logdet2 = np.linalg.slogdet(S2)
        if (sign1 <= 0) or (sign2 <= 0) or not np.isfinite(md) or not np.isfinite(t):
            return np.inf
        kl = 0.5 * (t + md - d + (logdet2 - logdet1))
        if cap < np.inf:
            kl = min(kl, cap)
        if not np.isfinite(kl) or kl < 0:
            return np.inf
        return kl

    # map id->child once to avoid repeated scans
    _by_id = {int(ch.id): ch for ch in children}

    # small accessors for Ω fields (prefer cached Ω, else exp-cached products, else exp on the fly)
    def _get_O_fields(Ci, Cj):
        """Return tuple (Oq_field, Op_field) each shaped (H,W,K,K) or None if unavailable."""
        Oq = getattr(Ci, "Omega_cache", {}).get(int(getattr(Cj, "id", -1)))
        Op = getattr(Ci, "Omega_tilde_cache", {}).get(int(getattr(Cj, "id", -1)))

        ok_q = (Oq is not None) and (getattr(Oq, "shape", None) is not None) and (Oq.shape[:2] == (H, W))
        ok_p = (Op is not None) and (getattr(Op, "shape", None) is not None) and (Op.shape[:2] == (H, W))

        if ok_q and ok_p:
            return Oq, Op

        # try to build from cached exp fields (fast einsums over full field)
        Ei_q   = getattr(Ci, "_exp_phi", None)
        Ej_qn  = getattr(Cj, "_exp_neg_phi", None)
        Ei_p   = getattr(Ci, "_exp_phi_model", None)
        Ej_pn  = getattr(Cj, "_exp_neg_phi_model", None)

        if (not ok_q) and (Ei_q is not None) and (Ej_qn is not None) and Ei_q.shape[:2] == (H, W) and Ej_qn.shape[:2] == (H, W):
            Oq = np.einsum("...ik,...kj->...ij", Ei_q, Ej_qn, optimize=True)
            ok_q = True
        if (not ok_p) and (Ei_p is not None) and (Ej_pn is not None) and Ei_p.shape[:2] == (H, W) and Ej_pn.shape[:2] == (H, W):
            Op = np.einsum("...ik,...kj->...ij", Ei_p, Ej_pn, optimize=True)
            ok_p = True

        return (Oq if ok_q else None), (Op if ok_p else None)

    for rid, P in parents.items():
        base_ids = list(getattr(P, "child_ids", []) or [])
        assigned_ids = list(getattr(P, "assigned_child_ids", []) or [])

        # --- choose effective coalition per step ---
        eff_ids = sorted(set(assigned_ids) | set(base_ids))
        if len(assigned_ids) >= 2:
            eff_ids = sorted(set(assigned_ids))  # prefer assigned if valid

        if len(eff_ids) < 2:
            P.mask = np.zeros((H, W), np.float32)
            P.emerged = False
            continue

        K = []
        for k in eff_ids:
            ch = _by_id.get(int(k), None)
            if ch is not None:
                K.append(ch)
        if len(K) < 2:
            P.mask = np.zeros((H, W), np.float32)
            P.emerged = False
            continue

        # gates and (optional) union clamp
        masks_gated  = [_mask_gate(ch.mask) for ch in K]
        present_bool = [_support_bool(ch.mask) for ch in K]

        union_gate = None
        if clamp_to_union:
            union_gate = np.zeros((H, W), np.float32)
            for pb in present_bool:
                union_gate = np.maximum(union_gate, pb.astype(np.float32))

        # admissible domain: at least two kids present (≥ τ)
        present_stack = np.stack(present_bool, axis=0).astype(np.int16)  # (k,H,W)
        domain = (present_stack.sum(axis=0) >= 2)
        if not np.any(domain):
            P.mask = np.zeros((H, W), np.float32)
            P.emerged = False
            continue

        acc = np.zeros((H, W), np.float32)
        if mode == "mean":
            cnt = np.zeros((H, W), np.float32)

                # ---- pair loop (use cached helper; no inline KL math) ----
        klen = len(K)
        for a in range(klen):
            for b in range(a + 1, klen):
                Ci, Cj = K[a], K[b]
                mi, mj = masks_gated[a], masks_gated[b]

                support = (present_bool[a] & present_bool[b] & domain)
                if support.sum() < min_pair_px:
                    continue

                # weights on overlap using cached Ω / exp fields
                wq = directed_kl_weight_after_transport(
                    Ci, Cj,
                    Ci.mu_q_field, Ci.sigma_q_field,
                    Cj.mu_q_field, Cj.sigma_q_field,
                    fiber="q", H=H, W=W, K=Ci.mu_q_field.shape[-1],
                    ov=support, tau=max(1e-12, float(tau_q)),
                    assume_diag_is_stddev=True, debug=False
                )
                wp = directed_kl_weight_after_transport(
                    Ci, Cj,
                    Ci.mu_p_field, Ci.sigma_p_field,
                    Cj.mu_p_field, Cj.sigma_p_field,
                    fiber="p", H=H, W=W, K=Ci.mu_p_field.shape[-1],
                    ov=support, tau=max(1e-12, float(tau_p)),
                    assume_diag_is_stddev=True, debug=False
                )

                # blend q/p, gate by masks and optional agreement prior
                w = (wq ** (1.0 - float(alpha))) * (wp ** float(alpha))
                w *= (mi * mj)  # stays zero outside both supports
                if A is not None:
                    w *= (A ** float(agree_power))

                # accumulate
                if mode == "max":
                    acc = np.maximum(acc, w)
                else:
                    acc += w
                    # count only positive contributions
                    cnt += (w > 0).astype(np.float32)

        if mode == "mean":
            acc = acc / (cnt + floor_eps)

        # clamp to union (optional), and to domain (always)
        if union_gate is not None:
            acc *= union_gate
        acc *= domain.astype(np.float32)

        # percentile normalization inside the domain for dynamic range
        dom_vals = acc[domain]
        if dom_vals.size == 0 or np.all(dom_vals <= floor_eps):
            P.mask = np.zeros((H, W), np.float32)
            P.emerged = False
            continue

        scale = np.percentile(dom_vals, pnorm)
        if not np.isfinite(scale) or scale <= floor_eps:
            scale = float(dom_vals.max())
        if scale <= floor_eps:
            P.mask = np.zeros((H, W), np.float32)
            P.emerged = False
            continue

        acc = acc / scale
        acc = np.clip(np.nan_to_num(acc, nan=0.0, posinf=1.0, neginf=0.0), 0.0, 1.0)

        # defensive: enforce ≥2-kid domain again
        acc *= domain.astype(np.float32)

        P.mask = acc.astype(np.float32)
        P.emerged = True




def build_alignment_aggregates(runtime_ctx, children, *, kl_cap=10.0):
    """
    Aggregates per-child caches into step-level fields on runtime_ctx:
      KLq_agg, KLp_agg, Aq_agg, Ap_agg  (H,W)

    Priority (per child, per fiber):
      1) Agreement cache if present (spawn_A_final for q; optional model A for p)
      2) Softmin KL cache (spawn_softmin_kl_q/p)
      3) Fallback blended/cached KL (cached_alignment_kl / cached_model_alignment_kl)

    Aggregation occurs in AGREEMENT space; KL_agg is computed back from the agg agreement.
    """
    import numpy as np
    try:
        import config
        tau_q = float(getattr(config, "tau_align_q", 0.45))
        tau_p = float(getattr(config, "tau_align_p", 0.45))
        kl_cap = float(getattr(config, "signal_kl_cap", kl_cap))
        reduce_mode = str(getattr(config, "agg_reduce_mode", "mean"))  # "mean" | "max" | "p80" etc.
        prefer_agreement_cache = bool(getattr(config, "agg_prefer_agreement_cache", True))
    except Exception:
        tau_q = tau_p = 0.45
        reduce_mode = "mean"
        prefer_agreement_cache = True

    if not children:
        runtime_ctx.KLq_agg = runtime_ctx.KLp_agg = None
        runtime_ctx.Aq_agg  = runtime_ctx.Ap_agg  = None
        return

    H, W = children[0].mask.shape[:2]

    def _resize_to_hw(a):
        a = np.asarray(a, np.float32)
        if a.shape == (H, W): return a
        # minimal NN-like adjust without deps
        if a.shape[0] >= H and a.shape[1] >= W:
            return a[:H, :W].astype(np.float32, copy=False)
        py, px = max(0, H - a.shape[0]), max(0, W - a.shape[1])
        return np.pad(a, ((0, py), (0, px)), mode="edge")[:H, :W].astype(np.float32, copy=False)

    # Collect per-child AGREEMENT for each fiber if possible, else collect KL
    Aq_list, KLq_list = [], []
    Ap_list, KLp_list = [], []

    for ch in children:
        # ----- q fiber -----
        A_q = getattr(ch, "spawn_A_final", None) if prefer_agreement_cache else None
        if A_q is not None:
            Aq_list.append(np.clip(_resize_to_hw(A_q), 0.0, 1.0))
        else:
            # fall back to KL caches
            KLq = getattr(ch, "spawn_softmin_kl_q", None)
            if KLq is None:
                KLq = getattr(ch, "cached_alignment_kl", None)
            if KLq is not None:
                KLq = np.clip(_resize_to_hw(KLq), 0.0, kl_cap)
                KLq_list.append(KLq)

        # ----- p fiber -----
        # If you ever cache a model-side agreement (e.g., ch.spawn_A_final_p), prefer it here
        A_p = getattr(ch, "spawn_A_final_p", None) if prefer_agreement_cache else None
        if A_p is not None:
            Ap_list.append(np.clip(_resize_to_hw(A_p), 0.0, 1.0))
        else:
            KLp = getattr(ch, "spawn_softmin_kl_p", None)
            if KLp is None:
                KLp = getattr(ch, "cached_model_alignment_kl", None)
            if KLp is not None:
                KLp = np.clip(_resize_to_hw(KLp), 0.0, kl_cap)
                KLp_list.append(KLp)

    def _reduce_agree(A_list, KL_list, tau):
        """
        Prefer agreements (A_list). If absent, convert KL_list to agreements, then reduce.
        Returns (KL_eff, A_agg) or (None, None) if no inputs.
        """
        if A_list:
            A_stack = np.stack(A_list, axis=0)  # (C,H,W)
        elif KL_list:
            KL_stack = np.stack(KL_list, axis=0)
            A_stack = np.exp(-KL_stack / max(tau, 1e-8)).astype(np.float32)
        else:
            return None, None

        if reduce_mode == "mean":
            A_agg = np.mean(A_stack, axis=0)
        elif reduce_mode == "max":
            A_agg = np.max(A_stack, axis=0)
        elif reduce_mode.startswith("p"):
            try:
                q = float(reduce_mode[1:])
            except Exception:
                q = 80.0
            A_agg = np.percentile(A_stack, q, axis=0)
        else:
            A_agg = np.mean(A_stack, axis=0)

        A_agg = np.clip(np.nan_to_num(A_agg, nan=0.0, posinf=1.0, neginf=0.0), 0.0, 1.0)
        KL_eff = (-max(tau, 1e-8) * np.log(np.maximum(A_agg, 1e-20))).astype(np.float32)
        KL_eff = np.clip(KL_eff, 0.0, kl_cap)
        return KL_eff, A_agg

    KLq_agg, Aq_agg = _reduce_agree(Aq_list, KLq_list, tau_q)
    KLp_agg, Ap_agg = _reduce_agree(Ap_list, KLp_list, tau_p)

    runtime_ctx.KLq_agg = KLq_agg
    runtime_ctx.KLp_agg = KLp_agg
    runtime_ctx.Aq_agg  = Aq_agg
    runtime_ctx.Ap_agg  = Ap_agg





# --- spawn cache refresh policy --------------------------------------------
def should_refresh_spawn_cache(child, runtime_ctx, *, mask_tol=1e-8) -> bool:
    """
    Return True if child's spawn caches should be recomputed this step.
    Triggers:
      - child marked dirty (fields or KL) OR
      - child's mask changed meaningfully vs. last snapshot OR
      - transport cache_version changed since last spawn build OR
      - child carries no spawn caches yet
    """
    import numpy as np
    if getattr(child, "spawn_A_final", None) is None:
        return True
    if getattr(child, "_dirty_fields", False) or getattr(child, "_dirty_kl", False):
        return True

    # mask delta check (cheap)
    try:
        prev = getattr(child, "_mask_prev_for_spawn", None)
        if prev is None:
            return True
        now = np.asarray(child.mask, np.float32)
        if now.shape != prev.shape:
            return True
        if float(np.max(np.abs(now - prev))) > float(mask_tol):
            return True
    except Exception:
        return True

    # global transport cache version bump (parents/children changed)
    built_ver = int(getattr(child, "_spawn_cache_built_at_cachever", -1))
    glob_ver  = int(getattr(runtime_ctx, "cache_version", 0))
    return (built_ver != glob_ver)


def ensure_spawn_alignment_caches(children, agents, runtime_ctx, *,
                                  generators_q, generators_p,
                                  use_cover_weight=True, debug=False):
    """
    Build spawn caches ONLY for children that need it (policy above).
    Reuses any prebuilt Ω caches or exp(φ) caches; falls back if missing.
    """
    # prefer Ω caches; if missing, try to (re)build them *just for children*
    from update_rules_utils import build_all_omega_caches
    build_all_omega_caches(children, strict=False, debug=False)

    need = [ch for ch in children if should_refresh_spawn_cache(ch, runtime_ctx)]
    if not need:
        return

    # call the existing builder but let it leverage cached transports/exp
    refresh_spawn_alignment_caches(
        need, agents,
        tau_q=getattr(__import__("config"), "tau_align_q", 0.45),
        tau_p=getattr(__import__("config"), "tau_align_p", 0.45),
        alpha=getattr(__import__("config"), "blend_qp_alpha", 0.50),
        sm_tau=getattr(__import__("config"), "spawn_softmin_tau", 0.40),
        kl_cap=getattr(__import__("config"), "signal_kl_cap", 10.0),
        eps=getattr(__import__("config"), "support_cutoff_eps", 1e-4),
        use_cover_weight=bool(use_cover_weight),
        debug=bool(debug),
    )

    # stamp bookkeeping for next time
    import numpy as np
    cv = int(getattr(runtime_ctx, "cache_version", 0))
    for ch in need:
        ch._spawn_cache_built_at_cachever = cv
        ch._mask_prev_for_spawn = np.asarray(ch.mask, dtype=np.float32).copy()
        # this refresh satisfied the dirtiness
        setattr(ch, "_dirty_fields", False)
        setattr(ch, "_dirty_kl", False)


def refresh_spawn_alignment_caches(children, agents, *,
                                   tau_q=None, tau_p=None,
                                   alpha=None,         # blend 0→model-only, 1→belief-only
                                   sm_tau=None,        # softmin temperature across neighbors
                                   kl_cap=None,        # cap *before* exponentials
                                   eps=None, log_eps=None,
                                   use_cover_weight=True,
                                   debug=False):
    """
    Build *spawn-only* caches on each child:
        ch.spawn_nb_count        : (H,W) int32
        ch.spawn_min_kl_q        : (H,W) float32
        ch.spawn_min_kl_p        : (H,W) float32
        ch.spawn_softmin_kl_q    : (H,W) float32
        ch.spawn_softmin_kl_p    : (H,W) float32
        ch.spawn_cover_weight    : (H,W) float32   (optional)
        ch.spawn_A_final         : (H,W) float32   final agreement weight for seeding
    Compatibility conveniences (for plotting / downstream):
        ch.kl_field              : blended softmin KL
        ch.agreement_field       : same as spawn_A_final
    Notes:
      - Uses moment-frame KL with *orthogonal* transport: Σ -> Ω Σ Ω^T.
      - All aggregations are per-pixel over neighbors of child i.
    """
    import numpy as np
    import config as _cfg
    from omega import exp_lie_algebra_irrep
    from numerical_utils import sanitize_sigma
    from get_generators import get_generators
    from generalized_diagnostics_metrics import kl_divergence
    # ----- knobs with safe defaults from config --------------------------------
    tau_q   = float(_cfg.tau_align_q)      if tau_q   is None else float(tau_q)
    tau_p   = float(_cfg.tau_align_p)      if tau_p   is None else float(tau_p)
    alpha   = float(getattr(_cfg, "blend_qp_alpha", 0.50)) if alpha is None else float(alpha)
    sm_tau  = float(getattr(_cfg, "spawn_softmin_tau", 0.40)) if sm_tau is None else float(sm_tau)
    kl_cap  = float(getattr(_cfg, "signal_kl_cap", 10.0)) if kl_cap is None else float(kl_cap)
    eps     = float(getattr(_cfg, "support_cutoff_eps", 1e-4)) if eps is None else float(eps)
    log_eps = float(getattr(_cfg, "log_eps", 1e-9)) if log_eps is None else float(log_eps)

    # ----- local helpers --------------------------------------------------------
    def _threshold_mask(m):
        a = np.asarray(m, np.float32)
        return a > eps

    def _to_full_cov_at(points_cov, K):
        """
        Accepts either diagonal std/var per-pixel or full SPD (K,K).
        Returns (M,K,K) for M selected pixels.
        """
        s = points_cov
        if s.ndim == 2 and s.shape[1] == K:
            # treat as diagonal stddevs: (M,K) -> (M,K,K)
            return np.einsum("mk,ij->mij", s**2, np.eye(K, dtype=s.dtype))
        if s.ndim == 3 and s.shape[1] == K and s.shape[2] == K:
            return s
        raise ValueError(f"Unexpected covariance shape {s.shape}; expected (M,K) diag or (M,K,K).")

    def _sanitize_sigma(S):
        # Your existing SPD guard; keep it light since transport is orthogonal
        return sanitize_sigma(S, eps=log_eps)

    def _expR(phi_grid, generators):
        # exp in irrep, per-pixel
        return exp_lie_algebra_irrep(phi_grid, generators)

    def _softmin_from_sumexp(sumexp, temp):
        # temp > 0.0
        return -temp * np.log(np.maximum(sumexp, 1e-20))

    # ----- main loop ------------------------------------------------------------
    for ch in children:
        Ai = ch
        if not getattr(Ai, "neighbors", None):
            # allocate empty caches
            H, W = Ai.mask.shape[:2]
            zf = np.zeros((H, W), np.float32)
            zi = np.zeros((H, W), np.int32)
            Ai.spawn_nb_count      = zi
            Ai.spawn_min_kl_q      = zf + np.inf
            Ai.spawn_min_kl_p      = zf + np.inf
            Ai.spawn_softmin_kl_q  = zf
            Ai.spawn_softmin_kl_p  = zf
            Ai.spawn_cover_weight  = zf
            Ai.spawn_A_final       = zf
            Ai.kl_field            = zf
            Ai.agreement_field     = zf
            continue

        mask_i = _threshold_mask(Ai.mask)
        if not np.any(mask_i):
            # same zero-allocation branch
            H, W = Ai.mask.shape[:2]
            zf = np.zeros((H, W), np.float32)
            zi = np.zeros((H, W), np.int32)
            Ai.spawn_nb_count      = zi
            Ai.spawn_min_kl_q      = zf + np.inf
            Ai.spawn_min_kl_p      = zf + np.inf
            Ai.spawn_softmin_kl_q  = zf
            Ai.spawn_softmin_kl_p  = zf
            Ai.spawn_cover_weight  = zf
            Ai.spawn_A_final       = zf
            Ai.kl_field            = zf
            Ai.agreement_field     = zf
            continue

        H, W = Ai.mask.shape[:2]

        # Select fields and group generators for belief/model
        Kq = int(getattr(_cfg, "K_q", Ai.mu_q_field.shape[-1]))
        Kp = int(getattr(_cfg, "K_p", Ai.mu_p_field.shape[-1]))
        Gq = get_generators(_cfg.group_name, Kq)
        Gp = get_generators(_cfg.group_name, Kp)

        # Accumulators
        nb_count      = np.zeros((H, W), np.int32)
        min_kl_q      = np.full((H, W), np.inf, np.float32)
        min_kl_p      = np.full((H, W), np.inf, np.float32)
        sumexp_q      = np.zeros((H, W), np.float32)
        sumexp_p      = np.zeros((H, W), np.float32)
        cover_weight  = np.zeros((H, W), np.float32) if use_cover_weight else None

        # local (child i) fields
        mu_q_i    = Ai.mu_q_field
        mu_p_i    = Ai.mu_p_field
        Sig_q_i   = Ai.sigma_q_field
        Sig_p_i   = Ai.sigma_p_field
        phi_q_i   = Ai.phi        # (H,W,3)
        phi_p_i   = Ai.phi_model  # (H,W,3)

        # Pre-extract i's values at overlap later
        for nb in Ai.neighbors:
            Bj = agents[nb["id"]]
            mask_j = _threshold_mask(Bj.mask)
            overlap = mask_i & mask_j
            if not np.any(overlap):
                continue

            idx = np.argwhere(overlap)
            iy, ix = idx[:, 0], idx[:, 1]

            # ---------- belief side (Kq) ----------
            mu_i = mu_q_i[overlap]                   # (M,Kq)
            mu_j = Bj.mu_q_field[overlap]            # (M,Kq)
            Si   = _to_full_cov_at(Sig_q_i[overlap], Kq)   # (M,Kq,Kq)
            Sj   = _to_full_cov_at(Bj.sigma_q_field[overlap], Kq)

            Si = _sanitize_sigma(Si)
            Sj = _sanitize_sigma(Sj)

            Ri    = _expR(phi_q_i[overlap], Gq)      # (M,Kq,Kq)
            RjInv = _expR(-Bj.phi[overlap], Gq)      # (M,Kq,Kq)
            Omega = np.einsum("mab,mbc->mac", Ri, RjInv)
            Omega_T = np.swapaxes(Omega, -1, -2)

            mu_j_t = np.einsum("mab,mb->ma", Omega, mu_j)
            Sj_t   = np.einsum("mab,mbc,mdc->mad", Omega, Sj, Omega_T)
            Sj_t   = _sanitize_sigma(Sj_t)

            KL_q_ij = kl_divergence(mu_i, Si, mu_j_t, Sj_t, eps=log_eps)  # (M,)
            KL_q_ij = np.where(np.isfinite(KL_q_ij), KL_q_ij, 0.0)
            KL_q_ij = np.clip(KL_q_ij, 0.0, kl_cap)

            # ---------- model side (Kp) ----------
            mu_i = mu_p_i[overlap]                   # (M,Kp)
            mu_j = Bj.mu_p_field[overlap]            # (M,Kp)
            Si   = _to_full_cov_at(Sig_p_i[overlap], Kp)
            Sj   = _to_full_cov_at(Bj.sigma_p_field[overlap], Kp)

            Si = _sanitize_sigma(Si)
            Sj = _sanitize_sigma(Sj)

            Ri    = _expR(phi_p_i[overlap], Gp)      # (M,Kp,Kp)
            RjInv = _expR(-Bj.phi_model[overlap], Gp)
            Omega = np.einsum("mab,mbc->mac", Ri, RjInv)
            Omega_T = np.swapaxes(Omega, -1, -2)

            mu_j_t = np.einsum("mab,mb->ma", Omega, mu_j)
            Sj_t   = np.einsum("mab,mbc,mdc->mad", Omega, Sj, Omega_T)
            Sj_t   = _sanitize_sigma(Sj_t)

            KL_p_ij = kl_divergence(mu_i, Si, mu_j_t, Sj_t, eps=log_eps)  # (M,)
            KL_p_ij = np.where(np.isfinite(KL_p_ij), KL_p_ij, 0.0)
            KL_p_ij = np.clip(KL_p_ij, 0.0, kl_cap)

            # ---------- aggregate at (iy, ix) ----------
            np.add.at(nb_count, (iy, ix), 1)

            # hard-mins
            np.minimum.at(min_kl_q, (iy, ix), KL_q_ij.astype(np.float32))
            np.minimum.at(min_kl_p, (iy, ix), KL_p_ij.astype(np.float32))

            # softmin via sumexp over neighbors
            np.add.at(sumexp_q, (iy, ix), np.exp(-KL_q_ij / max(sm_tau, 1e-8)))
            np.add.at(sumexp_p, (iy, ix), np.exp(-KL_p_ij / max(sm_tau, 1e-8)))

            # optional coverage weight (accumulate neighbor mask weight)
            if use_cover_weight:
                np.add.at(cover_weight, (iy, ix), np.asarray(Bj.mask, np.float32)[overlap])

        # --- finalize per-pixel aggregates (valid where nb_count>0) ---
        valid   = (nb_count > 0)
        support = (mask_i.astype(bool))
        pixels  = (valid & support)
        
        softmin_q = np.zeros_like(sumexp_q, np.float32)
        softmin_p = np.zeros_like(sumexp_p, np.float32)
        softmin_q[valid] = _softmin_from_sumexp(sumexp_q[valid], sm_tau).astype(np.float32)
        softmin_p[valid] = _softmin_from_sumexp(sumexp_p[valid], sm_tau).astype(np.float32)
        
        # blended softmin KL and final A(x)
        tau_blend = alpha * tau_q + (1.0 - alpha) * tau_p
        KL_blend  = alpha * softmin_q + (1.0 - alpha) * softmin_p
        
        A_final = np.zeros_like(KL_blend, np.float32)
        A_final[valid] = np.exp(-KL_blend[valid] / max(tau_blend, 1e-8)).astype(np.float32)
        
        # ---- mask using where (avoid inf*0) ----
        # KL "best" maps: +inf where no valid neighbor OR outside support
        min_kl_q = np.where(pixels, min_kl_q, np.inf).astype(np.float32)
        min_kl_p = np.where(pixels, min_kl_p, np.inf).astype(np.float32)
        
        # softmins/blends/agreements: 0 outside support
        softmin_q = np.where(support, softmin_q, 0.0).astype(np.float32)
        softmin_p = np.where(support, softmin_p, 0.0).astype(np.float32)
        KL_blend  = np.where(support,  KL_blend,  0.0).astype(np.float32)
        A_final   = np.where(support,  A_final,   0.0).astype(np.float32)
        
        if use_cover_weight:
            cover_weight = np.where(support, cover_weight, 0.0).astype(np.float32)
        
        # ---- write caches on the child ----
        Ai.spawn_nb_count       = nb_count
        Ai.spawn_min_kl_q       = min_kl_q
        Ai.spawn_min_kl_p       = min_kl_p
        Ai.spawn_softmin_kl_q   = softmin_q
        Ai.spawn_softmin_kl_p   = softmin_p
        Ai.spawn_cover_weight   = cover_weight if use_cover_weight else None
        Ai.spawn_A_final        = A_final
        
        # compatibility fields for existing downstream code/plots
        Ai.kl_field             = KL_blend
        Ai.agreement_field      = A_final
        
        if debug and np.any(pixels):
            if not np.all(np.isfinite(KL_blend[support])):
                print(f"[spawn-cache] non-finite blended KL for child {Ai.id}")
    











#=============================================================================#







def compute_and_set_auto_agree_gate(runtime_ctx, *, percentile=65.0, ema=0.2, use_p_if_q_missing=True):
    """
    Sets runtime_ctx.detector_state.agree_gate_tau_eff to a smoothed percentile
    of A_agg in [0,1]. If no aggregates exist, sets it to None (gate off).
    """
    import numpy as np
    ds = getattr(runtime_ctx, "detector_state", None)
    if ds is None:
        return

    A = getattr(runtime_ctx, "Aq_agg", None)
    if (A is None) and use_p_if_q_missing:
        A = getattr(runtime_ctx, "Ap_agg", None)

    if A is None:
        ds.agree_gate_tau_eff = None
        try:
            print("[AGG] auto agree gate: no aggregates, gate OFF")
        except Exception:
            pass
        return

    A = np.asarray(A, np.float32)
    good = np.isfinite(A)
    if not good.any():
        ds.agree_gate_tau_eff = None
        try:
            print("[AGG] auto agree gate: aggregates non-finite, gate OFF")
        except Exception:
            pass
        return

    thr = float(np.percentile(A[good], float(percentile)))
    prev = getattr(ds, "agree_gate_tau_eff", None)
    if (prev is None) or (not np.isfinite(prev)):
        new_tau = thr
    else:
        new_tau = (1.0 - float(ema)) * float(prev) + float(ema) * thr

    ds.agree_gate_tau_eff = float(new_tau)
    try:
        print(f"[AGG] auto agree gate p{int(percentile)} ema={ema} tau={new_tau:.3f}")
    except Exception:
        pass




def prune_orphan_parents(
    parents_by_id,
    *,
    patience=3,
    min_total_weight=1e-4,
    min_area_nz=5,
    support_tau=0.02,
    respect_grace=True,
    verbose=False,
):
    """
    Remove parents that carry ~no child weight or tiny support for `patience` consecutive steps.
    - Weight check: sum(child_weights) < min_total_weight
    - Area check:   count(mask > support_tau) < min_area_nz
    - Respects each parent's grace window (_grace) if `respect_grace=True`.
    Returns: list of pruned parent ids.
    """
    import numpy as np

    dead = []

    for pid, P in list(parents_by_id.items()):
        # ----- stats (NaN-safe) -----
        wsum = float(sum((getattr(P, "child_weights", {}) or {}).values()))
        if not np.isfinite(wsum):
            wsum = 0.0

        m = np.nan_to_num(np.asarray(getattr(P, "mask", 0.0), np.float32), nan=0.0, posinf=0.0, neginf=0.0)
        nz = int(np.count_nonzero(m > float(support_tau)))

        # ----- grace / age gate -----
        age   = int(getattr(P, "_age", 0) or 0)
        grace = int(getattr(P, "_grace", 0) or 0)
        in_grace = respect_grace and (age < grace)

        ticks = int(getattr(P, "_orphan_ticks", 0) or 0)

        if in_grace:
            # During grace, don't accrue orphan ticks; reset if any evidence appears
            if (wsum >= float(min_total_weight)) or (nz >= int(min_area_nz)):
                ticks = 0
            # else keep ticks at 0 (don’t penalize newborns)
        else:
            # Outside grace: accrue ticks when both signals are weak
            if (wsum < float(min_total_weight)) or (nz < int(min_area_nz)):
                ticks += 1
            else:
                ticks = 0

        P._orphan_ticks = ticks

        if (ticks >= int(patience)) and (not in_grace):
            dead.append(int(pid))

    for pid in dead:
        parents_by_id.pop(pid, None)

    if verbose and dead:
        print(f"[PRUNE] removed {len(dead)} parents: {dead}")

    return dead





# in update_rules_utils.py (or wherever mark_dirty is defined)
def mark_dirty(ctx, *agents, kl=False):
    for a in agents:
        aid = int(getattr(a, "id", id(a)))
        ctx.dirty.agents.add(aid)
        if kl:
            ctx.dirty.kl.add(aid)
            
        # also per-agent flags so local policies can see staleness
        try:
            setattr(a, "_dirty_fields", True)
            if kl:
                setattr(a, "_dirty_kl", True)
        except Exception:
            pass        
      


def take_dirty(ctx, all_agents, *, which="agents"):
    ids = ctx.dirty.agents if which=="agents" else ctx.dirty.kl
    subset = _collect_by_ids(all_agents, ids)
    ids.clear()
    return subset



def _pre_light(all_agents, params, Gq, Gp):
    if not all_agents:
        return
    pre = dict(params)
    pre["sanitize_strict"] = pre.get("sanitize_strict_pre", False)
    pre["exp_n_jobs"] = 1
    preprocess_all_agents(all_agents, pre, Gq, Gp)
    build_all_omega_caches(all_agents)
    build_all_lambda_caches(all_agents)
    attach_parent_lambda_views(all_agents)
    H, W = np.asarray(all_agents[0].mask).shape[:2]
    _standardize_all_masks_once(all_agents, (H, W))


def _post_strict(all_agents, params, Gq, Gp):
    if not all_agents:
        return
    post = dict(params)
    post["sanitize_strict"] = True
    post["exp_n_jobs"] = 1
    preprocess_all_agents(all_agents, post, Gq, Gp)
    build_all_omega_caches(all_agents)
    build_all_lambda_caches(all_agents)
    attach_parent_lambda_views(all_agents)




def _post_strict_subset(agents_subset, params, generators_q, generators_p):
    """
    Strict refresh but only for a subset of agents/parents.
      order: preprocess -> Ω caches -> Λ caches -> parent views
    """
    if not agents_subset:
        return

    # guard against Nones from spawn/detector
    agents_subset = [a for a in agents_subset if a is not None]
    if not agents_subset:
        return

    preprocess_all_agents(agents_subset, params, generators_q, generators_p)
    build_all_omega_caches(agents_subset)
    build_all_lambda_caches(agents_subset)
    attach_parent_lambda_views(agents_subset)



# --- subset wrapper (spawn-only caches, MVG, orthogonal transport) ------------
def _refresh_child_kl_fields_subset(children_subset, all_agents, eps, build_spawn = False):
    """
    Legacy entrypoint used by detector/growth passes.
    Now delegates to spawn-only MVG cache builder for just the given subset.
    """
    if not children_subset:
        return

    try:
        import config as _cfg
        log_eps = float(getattr(_cfg, "log_eps", 1e-9))
    except Exception:
        log_eps = 1e-9

    if build_spawn:
        
        refresh_spawn_alignment_caches(
            children_subset,
            all_agents,
            eps=float(eps),
            log_eps=log_eps,
            # leave other knobs None → pulled from config inside the function
        )




    

def _invalidate_transport_caches(objs):
    """
    Clear all transport-related caches on the given agent objects.
    Safe to call with empty lists. Bumps per-agent cache_version for debugging.

    Invalidates:
      - Ω caches, exp(φ/φ̃) caches
      - Λ maps (child maps + parent-side views)
      - per-step KL caches
      - marks rectangular morphisms Φ/Φ̃ dirty (but keeps bases Φ₀/Φ̃₀)
    """
    if not objs:
        return

    for a in objs:
        if a is None:
            continue

        # Ω caches: prefer clearing dicts rather than None
        if hasattr(a, "Omega_cache"):
            try: a.Omega_cache.clear()
            except Exception: a.Omega_cache = {}
        if hasattr(a, "Omega_tilde_cache"):
            try: a.Omega_tilde_cache.clear()
            except Exception: a.Omega_tilde_cache = {}

        # exp(φ) / exp(φ̃) arrays
        for attr in ("_exp_phi", "_exp_neg_phi", "_exp_phi_model", "_exp_neg_phi_model"):
            if hasattr(a, attr):
                try: setattr(a, attr, None)
                except Exception: pass

        # Λ maps on child (authoritative)
        for attr in ("Lambda_up_q_map", "Lambda_dn_q_map", "Lambda_up_p_map", "Lambda_dn_p_map"):
            if hasattr(a, attr):
                try:
                    m = getattr(a, attr)
                    if isinstance(m, dict):
                        m.clear()
                    else:
                        setattr(a, attr, {})
                except Exception:
                    setattr(a, attr, {})

        # optional Λ globals
        for attr in ("Lambda_up_q_global", "Lambda_up_p_global"):
            if hasattr(a, attr):
                try:
                    m = getattr(a, attr)
                    if isinstance(m, dict):
                        m.clear()
                    else:
                        setattr(a, attr, {})
                except Exception:
                    setattr(a, attr, {})

        # Parent-side Λ views
        for attr in ("Lambda_from_child_q_map", "Lambda_to_child_q_map",
                     "Lambda_from_child_p_map", "Lambda_to_child_p_map"):
            if hasattr(a, attr):
                try:
                    m = getattr(a, attr)
                    if isinstance(m, dict):
                        m.clear()
                    else:
                        setattr(a, attr, {})
                except Exception:
                    setattr(a, attr, {})

        # KL/alignment caches
        for attr in ("kl_cache", "kl_fields", "cached_alignment_kl", "cached_model_alignment_kl"):
            if hasattr(a, attr):
                try: setattr(a, attr, None)
                except Exception: pass

        # Rectangular morphisms Φ/Φ̃ (mark dirty + clear transported)
        try:
            if hasattr(a, "mark_morphism_dirty") and callable(a.mark_morphism_dirty):
                a.mark_morphism_dirty()
            else:
                setattr(a, "morphisms_dirty", True)
                if hasattr(a, "bundle_morphism_q_to_p"):
                    a.bundle_morphism_q_to_p = None
                if hasattr(a, "bundle_morphism_p_to_q"):
                    a.bundle_morphism_p_to_q = None
        except Exception:
            pass

        # bump cache version
        try:
            a.cache_version = int(getattr(a, "cache_version", 0)) + 1
        except Exception:
            pass




def _standardize_all_masks_once(all_agents, HW):
    from parent_utils import ensure_hw
    for a in all_agents:
        if hasattr(a, "mask"):
            m = getattr(a, "mask", None)
            if m is not None:
                mm = ensure_hw(m, HW)  # no-op if already right
                if mm is not m:
                    setattr(a, "mask", mm)




# --- helpers: sparsemax / entmax15 / softmax ---------------------------------
def _softmax(z, mask=None):
    import numpy as np
    z = np.asarray(z, np.float32)
    if mask is not None:
        z = np.where(mask, z, -np.inf)
    z = z - np.nanmax(z, axis=-1, keepdims=True)
    p = np.exp(z)
    p /= np.sum(p, axis=-1, keepdims=True) + 1e-20
    return p

def _sparsemax(z, mask=None):
    """
    Martins & Astudillo (2016). Returns probabilities with exact zeros.
    Works on last axis. O(K log K) per vector.
    """
    import numpy as np
    z = np.asarray(z, np.float32)
    if mask is not None:
        z = np.where(mask, z, -np.inf)
    # replace -inf with very small for sorting
    z_safe = np.where(np.isfinite(z), z, -1e30)
    z_sorted = np.sort(z_safe, axis=-1)[:, ::-1]
    k = np.arange(1, z.shape[-1] + 1, dtype=np.float32)
    z_cumsum = np.cumsum(z_sorted, axis=-1)
    # find k* s.t. 1 + k z̄_k > sum
    rhs = 1.0 + k * z_sorted
    cond = rhs > z_cumsum
    k_star = cond.sum(axis=-1)  # [N]
    # tau = (sum_{i<=k*} z_i - 1) / k*
    # gather prefix sums at k*
    idx = (k_star - 1).clip(min=0)
    tau = (z_cumsum[np.arange(z.shape[0]), idx] - 1.0) / np.maximum(k_star, 1)
    p = np.maximum(z - tau[:, None], 0.0)
    # renormalize tiny numerical drift
    Z = np.sum(p, axis=-1, keepdims=True) + 1e-20
    return p / Z

def _entmax15(z, mask=None, iters=50, tol=1e-6):
    """
    Entmax with alpha=1.5 (Peters et al., 2019). Proper sparse probabilities.
    We use a simple per-row bisection for tau. K is small here, so fine.
    """
    import numpy as np
    z = np.asarray(z, np.float32)
    if mask is not None:
        z = np.where(mask, z, -np.inf)
    z_safe = np.where(np.isfinite(z), z, -1e30)

    # upper/lower bounds for tau
    lo = np.min(z_safe, axis=-1) - 1.0
    hi = np.max(z_safe, axis=-1)
    lo = lo[:, None]; hi = hi[:, None]

    def proj(tau):
        u = np.maximum(0.0, z_safe - tau)
        return u ** 2.0

    for _ in range(iters):
        mid = (lo + hi) * 0.5  # [N,1]
        s = np.sum(proj(mid), axis=-1, keepdims=True)
        # sum u^2 should be 1 for alpha=1.5 projection
        hi = np.where(s > 1.0, mid, hi)
        lo = np.where(s > 1.0, lo, mid)
        if np.max(np.abs(hi - lo)) < tol:
            break
    tau = (lo + hi) * 0.5
    p = np.maximum(0.0, z_safe - tau) ** 2.0
    Z = np.sum(p, axis=-1, keepdims=True) + 1e-20
    return p / Z


def _as_parent_dict(obj):
    """
    Normalize parents -> {pid: Parent}. Accepts dict, list, iterable, or None.
    Uses the parent's .id if present; else falls back to enumerate index.
    """
    import collections.abc as _abc
    if obj is None:
        return {}
    if isinstance(obj, dict):
        return {int(getattr(p, "id", pid)): p for pid, p in obj.items()}
    if isinstance(obj, _abc.Iterable):
        return {int(getattr(p, "id", i)): p for i, p in enumerate(obj)}
    # Single parent object?
    return {int(getattr(obj, "id", 0)): obj}


