# -*- coding: utf-8 -*-
"""
Created on Sun Oct 26 08:37:08 2025

@author: chris and christine
"""

"""
Observation and Generative Model Module

This module implements observations and generative models to break the symmetry
in the action, preventing μ collapse while maintaining φ alignment.

Key idea: Without observations, the action is "vacuum-like" and all μ_i flow to 
the same value. Adding observations provides a source term (like a loss function)
that forces different agents to have different μ_i to explain their local data.

Mathematical framework:
    Action = Geometric_terms + Observation_terms
    
    Observation_terms = Σ_i -log p(o_i | μ_i, σ_i)
    
This is the symmetry-breaking mechanism that unifies FEP with ML.
"""

import numpy as np
from typing import Dict, List, Any, Optional, Tuple
from dataclasses import dataclass


@dataclass
class ObservationConfig:
    """Configuration for observation generation and likelihood model."""
    
    # Generation parameters
    observation_type: str = "gaussian_blobs"  # "gaussian_blobs", "mnist_patches", "synthetic_sequences"
    num_observation_points: int = 10  # Number of distinct observation centers
    observation_dim: int = 3  # Dimensionality of observations (should match K)
    noise_std: float = 0.1  # Observation noise
    
    # Likelihood model parameters
    likelihood_type: str = "gaussian"  # "gaussian", "categorical"
    likelihood_scale: float = 1.0  # Weight of observation term in action
    
    # Spatial assignment
    spatial_assignment: str = "nearest"  # "nearest", "overlap", "all"
    
    # For synthetic data generation
    seed: int = 42


class ObservationGenerator:
    """
    Generates observations for agents based on their spatial location.
    
    This creates the "data" that breaks the symmetry and prevents μ collapse.
    """
    
    def __init__(self, config: ObservationConfig):
        self.config = config
        self.rng = np.random.RandomState(config.seed)
        
        # Generate observation centers in embedding space
        self.observation_centers = self._generate_observation_centers()
        
    def _generate_observation_centers(self) -> np.ndarray:
        """
        Generate K distinct centers in embedding space.
        These represent different "concepts" or "features" that observations encode.
        """
        K = self.config.num_observation_points
        d = self.config.observation_dim
        
        if self.config.observation_type == "gaussian_blobs":
            # Create well-separated clusters in embedding space
            # Use a grid or random points on a sphere for good separation
            if K <= 8:
                # Use corners of a hypercube for good separation
                import itertools
                corners = list(itertools.product([-1, 1], repeat=min(3, d)))
                centers = np.array(corners[:K], dtype=np.float32)
                # Pad with zeros if d > 3
                if d > 3:
                    centers = np.pad(centers, ((0, 0), (0, d - centers.shape[1])))
            else:
                # Random points on sphere
                centers = self.rng.randn(K, d).astype(np.float32)
                centers /= np.linalg.norm(centers, axis=1, keepdims=True) + 1e-8
            
            # Scale for separation
            centers *= 3.0  # Make well-separated
            
        elif self.config.observation_type == "synthetic_sequences":
            # Sequential pattern: points along a manifold
            t = np.linspace(0, 2 * np.pi, K)
            centers = np.zeros((K, d), dtype=np.float32)
            centers[:, 0] = np.cos(t)
            centers[:, 1] = np.sin(t)
            if d > 2:
                centers[:, 2] = t / (2 * np.pi)  # Add a "time" dimension
                
        else:
            # Default: random
            centers = self.rng.randn(K, d).astype(np.float32)
            
        return centers
    
    def assign_observations_to_agents(
        self, 
        agents: List[Any],
        spatial_shape: Tuple[int, ...]
    ) -> Dict[int, np.ndarray]:
        """
        Assign observations to each agent based on spatial location.
        
        Returns:
            Dict mapping agent_id -> observation vector (shape: (observation_dim,))
        """
        observations = {}
        
        if self.config.spatial_assignment == "nearest":
            # Assign each agent to its nearest observation center based on spatial position
            for agent in agents:
                agent_id = agent.id
                center = np.array(agent.center, dtype=np.float32)
                
                # Normalize center to [0, 1]
                normalized_center = center / np.array(spatial_shape, dtype=np.float32)
                
                # Map spatial position to observation index
                # Simple approach: tile the observation centers in space
                K = len(self.observation_centers)
                # Use spatial position to select observation
                idx = int(np.sum(normalized_center * K)) % K
                
                # Get observation with noise
                obs_mean = self.observation_centers[idx]
                obs = obs_mean + self.rng.randn(self.config.observation_dim) * self.config.noise_std
                observations[agent_id] = obs.astype(np.float32)
                
        elif self.config.spatial_assignment == "overlap":
            # Each agent sees a mixture of nearby observations
            for agent in agents:
                agent_id = agent.id
                # This would require more sophisticated spatial reasoning
                # For now, fall back to nearest
                observations[agent_id] = self._assign_nearest(agent, spatial_shape)
                
        elif self.config.spatial_assignment == "all":
            # All agents see all observations (useful for sequence modeling)
            # In this case, μ should encode the sequence position
            for agent in agents:
                # Each agent gets a different observation from the sequence
                idx = agent.id % len(self.observation_centers)
                obs = self.observation_centers[idx] + \
                      self.rng.randn(self.config.observation_dim) * self.config.noise_std
                observations[agent.id] = obs.astype(np.float32)
        
        return observations
    
    def _assign_nearest(self, agent: Any, spatial_shape: Tuple[int, ...]) -> np.ndarray:
        """Helper to assign nearest observation."""
        center = np.array(agent.center, dtype=np.float32)
        normalized_center = center / np.array(spatial_shape, dtype=np.float32)
        K = len(self.observation_centers)
        idx = int(np.sum(normalized_center * K)) % K
        obs_mean = self.observation_centers[idx]
        obs = obs_mean + self.rng.randn(self.config.observation_dim) * self.config.noise_std
        return obs.astype(np.float32)


class GenerativeModel:
    """
    Implements the generative model p(o | μ, σ).
    
    This computes the likelihood of observations given the agent's beliefs,
    which enters the action as -log p(o | μ, σ).
    """
    
    def __init__(self, config: ObservationConfig):
        self.config = config
    
    def log_likelihood(
        self, 
        observation: np.ndarray,
        mu: np.ndarray,
        sigma: Optional[np.ndarray] = None
    ) -> float:
        """
        Compute log p(o | μ, σ).
        
        Args:
            observation: Observed data (shape: (d,))
            mu: Belief mean (shape: (K,))
            sigma: Belief covariance (shape: (K, K)) or None
            
        Returns:
            Log-likelihood (scalar)
        """
        if self.config.likelihood_type == "gaussian":
            return self._gaussian_log_likelihood(observation, mu, sigma)
        else:
            raise NotImplementedError(f"Likelihood type {self.config.likelihood_type}")
    
    def _gaussian_log_likelihood(
        self,
        observation: np.ndarray,
        mu: np.ndarray,
        sigma: Optional[np.ndarray] = None
    ) -> float:
        """
        Gaussian likelihood: log p(o | μ, σ) = -0.5 * ||o - μ||²_Σ + const
        
        For simplicity, we'll use the first observation_dim components of μ.
        """
        d = self.config.observation_dim
        
        # Extract relevant components
        mu_obs = mu[:d]  # First d components
        
        # Compute squared error
        diff = observation - mu_obs
        
        if sigma is not None:
            # Use covariance if provided
            sigma_obs = sigma[:d, :d]
            # Add small regularization for numerical stability
            sigma_obs = sigma_obs + 1e-6 * np.eye(d)
            try:
                # Mahalanobis distance
                inv_sigma = np.linalg.inv(sigma_obs)
                log_det = np.linalg.slogdet(sigma_obs)[1]
                squared_dist = diff @ inv_sigma @ diff
                ll = -0.5 * (squared_dist + log_det + d * np.log(2 * np.pi))
            except np.linalg.LinAlgError:
                # Fallback to simple squared error
                squared_dist = np.sum(diff ** 2)
                ll = -0.5 * squared_dist
        else:
            # Simple squared error (assuming unit variance)
            squared_dist = np.sum(diff ** 2)
            ll = -0.5 * squared_dist
        
        return float(ll)
    
    def negative_log_likelihood(
        self,
        observation: np.ndarray,
        mu: np.ndarray,
        sigma: Optional[np.ndarray] = None
    ) -> float:
        """
        Compute -log p(o | μ, σ) for the action.
        This is the "surprise" or prediction error.
        """
        return -self.log_likelihood(observation, mu, sigma)


def compute_observation_energy(
    agents: List[Any],
    observations: Dict[int, np.ndarray],
    generative_model: GenerativeModel,
    config: ObservationConfig
) -> Dict[str, float]:
    """
    Compute the total observation energy across all agents.
    
    This is the term that breaks the symmetry and prevents μ collapse.
    
    Returns:
        Dictionary with observation energy breakdown
    """
    total_energy = 0.0
    per_agent_energies = {}
    
    for agent in agents:
        agent_id = agent.id
        
        if agent_id not in observations:
            continue
        
        observation = observations[agent_id]
        
        # Get agent's belief at center point
        # For simplicity, take spatial mean of μ field
        mu_field = agent.mu_q_field  # Shape: (S, K)
        mu_center = np.mean(mu_field.reshape(-1, mu_field.shape[-1]), axis=0)
        
        # Optionally use sigma
        sigma_field = agent.sigma_q_field  # Shape: (S, K, K)
        sigma_center = np.mean(sigma_field.reshape(-1, *sigma_field.shape[-2:]), axis=0)
        
        # Compute negative log-likelihood (surprise)
        nll = generative_model.negative_log_likelihood(
            observation, mu_center, sigma_center
        )
        
        # Scale by configuration weight
        nll_weighted = config.likelihood_scale * nll
        
        total_energy += nll_weighted
        per_agent_energies[agent_id] = nll_weighted
    
    return {
        "observation_total": float(total_energy),
        "observation_mean": float(total_energy / max(len(per_agent_energies), 1)),
        "num_observed_agents": len(per_agent_energies),
        "per_agent": per_agent_energies
    }


def compute_observation_gradient(
    agent: Any,
    observation: np.ndarray,
    generative_model: GenerativeModel,
    config: ObservationConfig
) -> np.ndarray:
    """
    Compute gradient of -log p(o | μ) with respect to μ.
    
    For Gaussian likelihood: ∇_μ(-log p(o|μ)) = μ - o (for relevant components)
    
    Returns:
        Gradient with same shape as μ_field
    """
    d = config.observation_dim
    mu_field = agent.mu_q_field  # Shape: (S, K)
    S_shape = mu_field.shape[:-1]
    K = mu_field.shape[-1]
    
    # Initialize gradient
    grad = np.zeros_like(mu_field)
    
    # For Gaussian: gradient is (μ - o) for observed dimensions
    mu_mean = np.mean(mu_field.reshape(-1, K), axis=0)
    
    # Gradient only affects first d components
    grad_vec = np.zeros(K, dtype=np.float32)
    grad_vec[:d] = (mu_mean[:d] - observation) * config.likelihood_scale
    
    # Broadcast to all spatial locations (simplified)
    grad = np.broadcast_to(grad_vec[None, ...], mu_field.shape).copy()
    
    return grad


# ============================================================================
# Integration with existing simulation
# ============================================================================

def initialize_observations(
    agents: List[Any],
    config: ObservationConfig,
    spatial_shape: Optional[Tuple[int, ...]] = None
) -> Tuple[Dict[int, np.ndarray], ObservationGenerator, GenerativeModel]:
    """
    Initialize the observation system for a simulation.
    
    Returns:
        (observations, generator, generative_model)
    """
    # Infer spatial shape from first agent if not provided
    if spatial_shape is None and len(agents) > 0:
        spatial_shape = agents[0].spatial_shape
    
    generator = ObservationGenerator(config)
    generative_model = GenerativeModel(config)
    
    observations = generator.assign_observations_to_agents(agents, spatial_shape)
    
    return observations, generator, generative_model


def add_observation_gradients(
    agents: List[Any],
    observations: Dict[int, np.ndarray],
    generative_model: GenerativeModel,
    config: ObservationConfig
) -> None:
    """
    Add observation-induced gradients to agent gradient buffers.
    
    This modifies agents in-place by adding to their grad_mu_q fields.
    """
    for agent in agents:
        if agent.id not in observations:
            continue
        
        observation = observations[agent.id]
        
        # Compute gradient
        grad_obs = compute_observation_gradient(
            agent, observation, generative_model, config
        )
        
        # Add to existing gradient (if any)
        if agent.grad_mu_q is None:
            agent.grad_mu_q = grad_obs
        else:
            agent.grad_mu_q = agent.grad_mu_q + grad_obs