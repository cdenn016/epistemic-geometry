# === generalized_update_rules.py (refactor patch) ===
import numpy as np
import config
from joblib import Parallel, delayed

from natural_gradient_utils import (
    apply_natural_gradient_batch,
    apply_lie_natural_gradient,
    compute_inverse_fisher_field
)

from numerical_utils import sanitize_sigma
from mask_utils import clip_and_mask_gradient
from numerical_utils import safe_inv
from natural_gradient_utils import compute_alignment_kl_gradient
from get_generators import get_generators
from generalized_math_utils import unpack_phi_update_params
from generalized_omega import compute_curvature_gradient_analytical

from generalized_omega import dexpinv_operator, dexpinv_operator_covariance

from bundle_morphism_utils import safe_batch_apply_morphism, gauge_covariant_transform_phi

from natural_gradient_utils import compute_fisher_geometry_gradient
from generalized_math_utils import ( 
        zero_mu_sigma_like, compute_mu_sigma_diff,
        apply_mask_to_mu_sigma
        )

def grad_variance_penalty_field(agent_i, lambda_, field_type="model", mask=None):
    """
    Gradient of Tr(Σ⁻¹) penalty:
        ∇_Σ = -λ Σ⁻¹

    Returns:
        (Δμ, ΔΣ): where Δμ = 0, ΔΣ = -λ Σ⁻¹ (masked if needed)
    """
    if lambda_ <= 0:
        return zero_mu_sigma_like(agent_i, field=field_type)

    sigma = agent_i.sigma_p_field if field_type == "model" else agent_i.sigma_q_field
    mu_shape = agent_i.mu_p_field.shape if field_type == "model" else agent_i.mu_q_field.shape

    H, W, K, _ = sigma.shape
    d_sigma = np.zeros_like(sigma)
    fallback = np.eye(K)

    for i in range(H):
        for j in range(W):
            try:
                inv_ij = np.linalg.inv(sigma[i, j])
            except np.linalg.LinAlgError:
                if getattr(config, "debug", False):
                    print(f"[WARN] grad_variance_penalty_field: Σ⁻¹ fallback at ({i},{j})")
                inv_ij = np.linalg.pinv(sigma[i, j])  # fallback to pseudo-inverse

            d_sigma[i, j] = -lambda_ * inv_ij

    d_sigma = np.nan_to_num(d_sigma)

    if mask is not None:
        _, d_sigma = apply_mask_to_mu_sigma(None, d_sigma, mask)

    d_mu = np.zeros(mu_shape, dtype=d_sigma.dtype)
    return d_mu, d_sigma

def grad_self_field(agent_i, alpha, field_type="model", mask=None,
                             phi_morphism=None, phi_tilde_morphism=None):
    """
    Compute raw Euclidean gradient of morphism-aware self-alignment:
      - field_type="belief" → ∂KL(q || Φ·p)
      - field_type="model"  → ∂KL(p || Φ̃·q)

    The morphism acts as:
      - Φ   : p → q
      - Φ̃  : q → p

    Natural gradient is applied downstream.

    Args:
        agent_i   : Agent object
        alpha     : Scalar coefficient
        field_type: "belief" or "model"
        mask      : Optional spatial mask (H, W)
        phi_morphism        : Φ   (H, W, K_p, K_q) or None = identity
        phi_tilde_morphism  : Φ̃  (H, W, K_q, K_p) or None = identity

    Returns:
        (dμ, dΣ): Euclidean gradients of self-alignment term
    """
    if alpha <= 0:
        return zero_mu_sigma_like(agent_i)

    H, W = agent_i.grid_shape

    if field_type == "belief":
        mu_q, sigma_q = agent_i.mu_q_field, agent_i.sigma_q_field  # q-space
        mu_p, sigma_p = agent_i.mu_p_field, agent_i.sigma_p_field  # p-space
        K_q = mu_q.shape[-1]
        K_p = mu_p.shape[-1]

        if phi_morphism is not None:
            Phi = phi_morphism  # should be (..., K_q, K_p)
        else:
            eye = np.eye(K_q, K_p, dtype=mu_q.dtype)  # p → q maps from K_p to K_q
            Phi = np.broadcast_to(eye, (H, W, K_q, K_p))

        mu_p_trans, sigma_p_trans = safe_batch_apply_morphism(mu_p, sigma_p, Phi, eps=config.eps)
        dμ, dΣ = compute_mu_sigma_diff(mu_q, sigma_q, mu_p_trans, sigma_p_trans, direction="a_minus_b")

    elif field_type == "model":
        mu_q, sigma_q = agent_i.mu_q_field, agent_i.sigma_q_field
        mu_p, sigma_p = agent_i.mu_p_field, agent_i.sigma_p_field
        K_q = mu_q.shape[-1]
        K_p = mu_p.shape[-1]

        if phi_tilde_morphism is not None:
            Phi_tilde = phi_tilde_morphism  # should be (..., K_p, K_q)
        else:
            eye = np.eye(K_p, K_q, dtype=mu_q.dtype)  # q → p maps from K_q to K_p
            Phi_tilde = np.broadcast_to(eye, (H, W, K_p, K_q))

        mu_q_trans, sigma_q_trans = safe_batch_apply_morphism(mu_q, sigma_q, Phi_tilde, eps=config.eps)
        dμ, dΣ = compute_mu_sigma_diff(mu_p, sigma_p, mu_q_trans, sigma_q_trans, direction="a_minus_b")

    else:
        raise ValueError(f"[grad_self_field_morphism] Unknown field_type: {field_type}")

    dμ = np.nan_to_num(dμ)
    dΣ = np.nan_to_num(dΣ)

    if mask is not None:
        dμ, dΣ = apply_mask_to_mu_sigma(dμ, dΣ, mask)

    return alpha * dμ, alpha * dΣ

def grad_morphism_self_energy(agent_i, alpha, mask=None):
    """
    Compute the gradient ∂/∂Φ of KL[q || Φ · p], projecting q into p-fiber.

    Args:
        agent_i: agent whose morphism Φ : q → p is being updated
        alpha: weight of the self-energy KL term
        mask: optional spatial mask

    Returns:
        Gradient ∂F/∂Φ of shape (H, W, K_p, K_q)
    """
    mu_q     = agent_i.mu_q_field        # (H, W, K_q)
    sigma_q  = agent_i.sigma_q_field     # (H, W, K_q, K_q)
    mu_p     = agent_i.mu_p_field        # (H, W, K_p)
    sigma_p  = agent_i.sigma_p_field     # (H, W, K_p, K_p)
    Phi      = agent_i.bundle_morphism_q_to_p  # (H, W, K_p, K_q)

    # Project q into p-fiber
    mu_q_proj, sigma_q_proj = safe_batch_apply_morphism(mu_q, sigma_q, Phi, eps=config.eps)
    sigma_p_inv = safe_inv(sigma_p, eps=config.eps)

    # --- KL gradient terms ---

    # ∂/∂Φ Tr[ Σ_p⁻¹ (Φ Σ_q Φᵀ) ]
    term_sigma = 2 * np.einsum("...ij,...jl,...kl->...ik", sigma_p_inv, Phi, sigma_q)

    # ∂/∂Φ (μ_q_proj - μ_p)ᵀ Σ_p⁻¹ ∂μ_q_proj/∂Φ
    delta_mu = mu_q_proj - mu_p
    term_mu  = 2 * np.einsum("...ij,...j,...k->...ik", sigma_p_inv, delta_mu, mu_q)

    grad_total = term_mu + term_sigma

    if mask is not None:
        grad_total *= mask[..., None, None]
    print("|grad_feedback| =", np.linalg.norm(grad_total))

    return alpha * grad_total





def grad_feedback_field(agent_i, feedback_weight, field_type="model", mask=None,
                                 phi_morphism=None, phi_tilde_morphism=None):
    """
    Compute raw Euclidean gradient of feedback term:
      - field_type="belief" → ∂_q KL(Φ·p || q)
      - field_type="model"  → ∂_p KL(Φ̃·q || p)

    This is the gradient of KL(transformed other || self).

    Args:
        agent_i        : focal agent
        feedback_weight: scalar
        field_type     : "belief" or "model"
        mask           : optional (H, W)
        phi_morphism   : Φ   ∈ Hom(p → q), or None = identity
        phi_tilde_morphism: Φ̃ ∈ Hom(q → p), or None = identity

    Returns:
        (dμ, dΣ): Euclidean gradients of feedback term
    """
    if feedback_weight <= 0:
        return zero_mu_sigma_like(agent_i, field=field_type)

    H, W = agent_i.grid_shape

    if field_type == "belief":
        mu_self, sigma_self = agent_i.mu_q_field, agent_i.sigma_q_field
        mu_p, sigma_p = agent_i.mu_p_field, agent_i.sigma_p_field
        K_q = mu_self.shape[-1]
        K_p = mu_p.shape[-1]
        if phi_morphism is not None:
            Phi = phi_morphism
        else:
            eye = np.eye(K_q, K_p, dtype=mu_self.dtype)
            Phi = np.broadcast_to(eye, (H, W, K_q, K_p))
        # Pull p into q-space
        mu_p_trans, sigma_p_trans = safe_batch_apply_morphism(mu_p, sigma_p, Phi, eps=config.eps)
        dμ, dΣ = compute_mu_sigma_diff(mu_self, sigma_self, mu_p_trans, sigma_p_trans, direction="b_minus_a")

    elif field_type == "model":
        mu_self, sigma_self = agent_i.mu_p_field, agent_i.sigma_p_field
        mu_q, sigma_q = agent_i.mu_q_field, agent_i.sigma_q_field
        K_q = mu_q.shape[-1]
        K_p = mu_self.shape[-1]
        if phi_tilde_morphism is not None:
            Phi_tilde = phi_tilde_morphism
        else:
            eye = np.eye(K_p, K_q, dtype=mu_self.dtype)
            Phi_tilde = np.broadcast_to(eye, (H, W, K_p, K_q))
        # Pull q into p-space
        mu_q_trans, sigma_q_trans = safe_batch_apply_morphism(mu_q, sigma_q, Phi_tilde, eps=config.eps)
        dμ, dΣ = compute_mu_sigma_diff(mu_self, sigma_self, mu_q_trans, sigma_q_trans, direction="b_minus_a")

    else:
        raise ValueError(f"[grad_feedback_field_morphism] Unknown field_type: {field_type}")

    dμ = np.nan_to_num(dμ)
    dΣ = np.nan_to_num(dΣ)

    if mask is not None:
        dμ, dΣ = apply_mask_to_mu_sigma(dμ, dΣ, mask)

    return feedback_weight * dμ, feedback_weight * dΣ

def grad_morphism_feedback_energy(agent_i, feedback_weight, mask=None):
    """
    Compute Euclidean gradient of KL(p || Φ̃·q) with respect to Φ̃.
    Projects q into the p-fiber and backpropagates the KL divergence.

    Returns:
        Gradient of shape (H, W, K_p, K_q)
    """
    if feedback_weight <= 0:
        return np.zeros_like(agent_i.bundle_morphism_p_to_q)

    mu_q     = agent_i.mu_q_field        # (H, W, K_q)
    sigma_q  = agent_i.sigma_q_field     # (H, W, K_q, K_q)
    mu_p     = agent_i.mu_p_field        # (H, W, K_p)
    sigma_p  = agent_i.sigma_p_field     # (H, W, K_p, K_p)
    Phi_tilde = agent_i.bundle_morphism_p_to_q  # (H, W, K_p, K_q)

    # Push q into p-fiber via Φ̃
    mu_q_proj, sigma_q_proj = safe_batch_apply_morphism(mu_q, sigma_q, Phi_tilde, eps=config.eps)
    sigma_proj_inv = safe_inv(sigma_q_proj, eps=config.eps)

    delta_mu     = mu_p - mu_q_proj
    delta_sigma  = sigma_p - sigma_q_proj

    # --- KL gradient terms ---

    # Mean term: ∂/∂Φ̃ KL[N(μ_p, Σ_p) || N(μ_q_proj, Σ_q_proj)]
    term_mu = 2 * np.einsum("...ij,...j,...k->...ik", sigma_proj_inv, delta_mu, mu_q)

    # Covariance term: ∂/∂Φ̃ Tr[Σ_proj⁻¹ (Φ̃ Σ_q Φ̃ᵀ)]
    term_sigma = 2 * np.einsum("...ij,...jl,...kl->...ik", sigma_proj_inv, Phi_tilde, sigma_q)

    grad_total = term_mu + term_sigma

    if mask is not None:
        grad_total *= mask[..., None, None]
    print("|grad_feedback| =", np.linalg.norm(grad_total))

    return feedback_weight * grad_total



def alignment_gradient_field(agent_i, agents, params, field_type="model", mask=None):
    """
    Raw Euclidean gradient of alignment KL divergence:
        KL(q_i || Ω_ij q_j) or KL(p_i || Ω̃_ij p_j)

    Natural gradient is applied centrally in combine_field_gradients.

    Args:
        agent_i    : focal agent
        agents     : list of agents
        params     : dict of parameters
        field_type : "model" or "belief"
        mask       : optional spatial mask to restrict update region

    Returns:
        dμ, dΣ : raw Euclidean gradients (H, W, K), (H, W, K, K)
    """
    if field_type == "model":
        weight = params.get("model_align_weight", config.model_align_weight)
        K_fiber = agent_i.mu_p_field.shape[-1]
    elif field_type == "belief":
        weight = params.get("beta", config.beta)
        K_fiber = agent_i.mu_q_field.shape[-1]
    else:
        raise ValueError(f"[alignment_gradient_field] Unknown field_type: {field_type}")

    if weight <= 0:
        return zero_mu_sigma_like(agent_i, field=field_type)

    # Load or generate the appropriate representation generators
    generators = params.get("generators", get_generators(config.group_name, K_fiber))

    # Compute raw KL alignment gradients
    dμ, dΣ = compute_alignment_kl_gradient(agent_i, agents, generators, params, field_type=field_type)

    # Ensure numerical stability
    dμ = np.nan_to_num(dμ)
    dΣ = np.nan_to_num(dΣ)

    # Apply optional mask
    if mask is not None:
        dμ, dΣ = apply_mask_to_mu_sigma(dμ, dΣ, mask)

    return weight * dμ, weight * dΣ




def compute_joint_mask(agent_i, agent_j, eps):
    mask_i = agent_i.mask[..., None] > eps
    mask_j = agent_j.mask[..., None] > eps
    return mask_i & mask_j

def extract_belief_fields(agent_i, agent_j):
    mu_i = agent_i.mu_q_field
    sigma_i = agent_i.sigma_q_field
    mu_j = agent_j.mu_q_field
    sigma_j = agent_j.sigma_q_field
    return mu_i, sigma_i, mu_j, sigma_j

def extract_model_fields(agent_i, agent_j):
    mu_i = agent_i.mu_p_field
    sigma_i = agent_i.sigma_p_field
    mu_j = agent_j.mu_p_field
    sigma_j = agent_j.sigma_p_field
    return mu_i, sigma_i, mu_j, sigma_j


def extract_phi_and_omega(agent_i, agent_j, field):
    phi_i = getattr(agent_i, field)
    phi_j = getattr(agent_j, field)
    omega_name = f"Omega{'' if field == 'phi' else '_model'}"
    Omega_ij = getattr(agent_i, omega_name)
    return phi_i, phi_j, Omega_ij

def get_bundle_morphism(agent_i, agent_j, params, field):
    key = "bundle_morphism_q_to_p_fn" if field == "phi" else "bundle_morphism_p_to_q_fn"
    morphism_fn = params.get(key, None)
    return morphism_fn(agent_i, agent_j)

def transport_fields(mu_j, sigma_j, Omega_ij, Phi_ij):
    """
    Transport μ_j and Σ_j from agent_j to agent_i using the gauge-covariant operator:
        T = Φ_ij @ Ω_ij

    Inputs:
        mu_j      : (..., K_q)         – belief mean of agent_j
        sigma_j   : (..., K_q, K_q)    – belief covariance of agent_j
        Omega_ij  : (..., K_q, K_q)    – gauge transport operator from j to i
        Phi_ij    : (..., K_p, K_q)    – bundle morphism from q-fiber to p-fiber

    Returns:
        T             : (..., K_p, K_q) – total transport operator
        mu_trans      : (..., K_p)
        sigma_trans   : (..., K_p, K_p)
    """
    # Transport operator: Φ @ Ω
    T = np.einsum("...ik,...kj->...ij", Phi_ij, Omega_ij)   # (H,W,K_p,K_q)

    # Sanity checks
    assert T.shape[-1] == sigma_j.shape[-1], \
        f"Mismatch in inner dim: T={T.shape}, sigma_j={sigma_j.shape}"
    assert sigma_j.shape[-2] == sigma_j.shape[-1], \
        f"sigma_j must be square: got {sigma_j.shape}"

    # Transport mean: μ' = T · μ_j
    mu_trans = np.einsum("...ij,...j->...i", T, mu_j)       # (H,W,K_p)

    # Transport covariance: Σ' = T · Σ · Tᵀ
    sigma_trans = np.einsum("...ik,...kl,...jl->...ij", T, sigma_j, T)

    return T, mu_trans, sigma_trans


def accumulate_into_agent(agent, grad_phi, beta, mask):
    if not hasattr(agent, "grad_phi"):
        agent.grad_phi = np.zeros_like(grad_phi)
    agent.grad_phi += beta * grad_phi * mask



def accumulate_phi_gradient(agent_i, agent_j, generators, params, field="phi"):
    """
    Compute and accumulate both variational gradients:
        ∂/∂φ_i KL(q_i ‖ Ω_ij q_j)
        ∂/∂φ_j KL(q_i ‖ Ω_ij q_j)
    where Ω_ij = exp(φ_i) · exp(−φ_j)
    """
    assert field in ("phi", "phi_model")
    beta = params.get("beta", config.beta) if field == "phi" else params.get("model_align_weight", config.model_align_weight)
    if beta <= 0:
        return

    eps = config.support_cutoff_eps
    mask_i = agent_i.mask[..., None] > eps
    mask_j = agent_j.mask[..., None] > eps
    joint_mask = mask_i & mask_j

    # Select fibers
    mu_i = agent_i.mu_q_field if field == "phi" else agent_i.mu_p_field
    mu_j = agent_j.mu_q_field if field == "phi" else agent_j.mu_p_field
    sigma_i = agent_i.sigma_q_field if field == "phi" else agent_i.sigma_p_field
    sigma_j = agent_j.sigma_q_field if field == "phi" else agent_j.sigma_p_field

    phi_i = agent_i.phi if field == "phi" else agent_i.phi_model
    phi_j = agent_j.phi if field == "phi" else agent_j.phi_model

    Omega_ij = agent_i.Omega if field == "phi" else agent_i.Omega_model
    Omega_T = np.swapaxes(Omega_ij, -1, -2)

    # Transport fiber_j to i
    mu_trans = np.einsum("...kl,...l->...k", Omega_ij, mu_j)
    sigma_trans = np.einsum("...km,...mn,...nl->...kl", Omega_ij, sigma_j, Omega_T)
    sigma_trans = sanitize_sigma(sigma_trans, eps=config.eps)
    sigma_inv = safe_inv(sigma_trans, eps=config.eps)

    delta_mu = mu_i - mu_trans
    d_mu = -np.einsum("...ij,...j->...i", sigma_inv, delta_mu)

    delta_sigma = sigma_i - sigma_trans
    d_sigma = -0.5 * np.einsum("...ik,...kl,...lj->...ij", sigma_inv, delta_sigma, sigma_inv)

    d = generators.shape[0]
    grad_phi_i = np.zeros_like(phi_i)
    grad_phi_j = np.zeros_like(phi_j)

    for a in range(d):
        G = generators[a]

        # ∂Ω/∂φ_i = Ω G
        OG = np.einsum("...ij,jk->...ik", Omega_ij, G)
        dphi_i_mu = np.einsum("...ij,...j->...i", OG, mu_j)

        OG_sigma = np.einsum("...ij,...jk->...ik", OG, sigma_j)
        dphi_sigma_1 = np.einsum("...ij,...jk->...ik", OG_sigma, Omega_T)

        sigma_GT = np.einsum("...ij,jk->...ik", sigma_j, G.T)
        O_sigma_GT = np.einsum("...ij,...jk->...ik", Omega_ij, sigma_GT)
        dphi_sigma_2 = np.einsum("...ij,...jk->...ik", O_sigma_GT, Omega_T)

        dphi_i_sigma = dphi_sigma_1 + dphi_sigma_2

        delta_a = (
            np.sum(d_mu * dphi_i_mu, axis=-1) +
            np.einsum("...ij,...ij->...", d_sigma, dphi_i_sigma)
        )

        grad_phi_i[..., a] += delta_a
        grad_phi_j[..., a] -= delta_a

    # ✅ Always apply Lie-covariant natural gradient (no conditionals)
    # Split μ and Σ contributions
    grad_phi_mu_i = dexpinv_operator(phi_i, grad_phi_i, generators)
    grad_phi_mu_j = dexpinv_operator(phi_j, grad_phi_j, generators)

    # Recompute clean ∂KL/∂Σ′ (already have sigma_inv, delta_sigma)
    d_sigma = -0.5 * np.einsum("...ik,...kl,...lj->...ij", sigma_inv, delta_sigma, sigma_inv)

    # Project ∂KL/∂Σ′ back via Lie-covariant map
    grad_phi_sigma_i = dexpinv_operator_covariance(phi_i, d_sigma, generators)
    grad_phi_sigma_j = dexpinv_operator_covariance(phi_j, -d_sigma, generators)

    # Total φ gradients
    grad_phi_i = grad_phi_mu_i + grad_phi_sigma_i
    grad_phi_j = grad_phi_mu_j + grad_phi_sigma_j


    if not hasattr(agent_i, "grad_phi"):
        agent_i.grad_phi = np.zeros_like(phi_i)
    if not hasattr(agent_j, "grad_phi"):
        agent_j.grad_phi = np.zeros_like(phi_j)

    agent_i.grad_phi += beta * grad_phi_i * joint_mask
    agent_j.grad_phi += beta * grad_phi_j * joint_mask



def compute_phi_morphism_update(agent_i, params):
    """
    Update for Φ : p → q (used in KL(q || Φ·p)).
    Applies Euclidean gradient descent to the bundle morphism.
    """
    alpha = params.get("alpha", config.alpha)
    lr_phi = params.get("phi_morphism_lr", getattr(config, "phi_morphism_lr", 1e-3))
    eps = params.get("support_cutoff_eps", config.support_cutoff_eps)

    if alpha <= 0 or lr_phi <= 0:
        return None

    mask = agent_i.mask > eps
    dPhi = grad_morphism_self_energy(agent_i, alpha, mask=mask)

    # Apply update: Φ ← Φ - η ∇Φ
    agent_i.bundle_morphism_q_to_p = np.array(agent_i.bundle_morphism_q_to_p, copy=True)
    agent_i.bundle_morphism_q_to_p -= lr_phi * dPhi

    return dPhi

def compute_phi_tilde_morphism_update(agent_i, params):
    """
    Update for Φ̃ : q → p (used in KL(p || Φ̃·q)).
    Applies Euclidean gradient descent to the bundle morphism.
    """
    fb = params.get("model_feedback_weight", config.model_feedback_weight)
    lr_phi_tilde = params.get("phi_tilde_morphism_lr", getattr(config, "phi_tilde_morphism_lr", 1e-3))
    eps = params.get("support_cutoff_eps", config.support_cutoff_eps)

    if fb <= 0 or lr_phi_tilde <= 0:
        return None

    mask = agent_i.mask > eps
    dPhi_tilde = grad_morphism_feedback_energy(agent_i, fb, mask=mask)

    # Make the array writable before in-place subtraction
    if not agent_i.bundle_morphism_p_to_q.flags.writeable:
        agent_i.bundle_morphism_p_to_q = agent_i.bundle_morphism_p_to_q.copy()

    before = agent_i.bundle_morphism_p_to_q.copy()
    agent_i.bundle_morphism_p_to_q -= lr_phi_tilde * dPhi_tilde
    delta = np.linalg.norm(agent_i.bundle_morphism_p_to_q - before)
    print(f"[DEBUG] |Phi~change| = {delta:.6f}")

    return dPhi_tilde




def gradient_step_phi_morphism(agent_i, agents, generators, params, rho_q_func, rho_p_func):
    """
    Compute the natural gradient step for φ̃ (phi_morphism), governing bundle morphism Φ.

    This enforces alignment between agent_i.p and Φ_{ij}·agent_j.p for all neighbors j.
    """
    beta = params.get("model_align_weight", config.model_align_weight)
    eps  = params.get("support_cutoff_eps", config.support_cutoff_eps)

    if beta <= 0 or not np.any(agent_i.mask > eps):
        return np.zeros_like(agent_i.phi_model)

    phi_i = agent_i.phi_model
    grad_phi = np.zeros_like(phi_i)

    for neighbor in agent_i.neighbors:
        agent_j = agents[neighbor["id"]]

        phi_j = agent_j.phi_model  # φ̃_j — Lie algebra coordinates of j
        Phi   = agent_j.bundle_morphism_q_to_p  # raw Φ_j field

        # Compute Φ_ij = ρ_p(exp(φ_i)) · Φ_j · ρ_q(exp(−φ_j))
        Phi_transformed = gauge_covariant_transform_phi(phi_i, Phi, rho_q_func, rho_p_func)

        # Compute transported model fields
        mu_j = agent_j.mu_p_field
        sigma_j = agent_j.sigma_p_field

        mu_trans = np.einsum("...ij,...j->...i", Phi_transformed, mu_j)
        sigma_trans = np.einsum("...ik,...kl,...jl->...ij", Phi_transformed, sigma_j, Phi_transformed)

        mu_i = agent_i.mu_p_field
        sigma_i = agent_i.sigma_p_field
        delta_mu = mu_i - mu_trans
        delta_sigma = sigma_i - sigma_trans
        sigma_inv = safe_inv(sanitize_sigma(sigma_trans), eps=config.eps)

        # === Compute φ̃ gradient w.r.t. transport error ===
        d_mu = -np.einsum("...ij,...j->...i", sigma_inv, delta_mu)
        d_sigma = -0.5 * np.einsum("...ik,...kl,...lj->...ij", sigma_inv, delta_sigma, sigma_inv)

        # === Project to Lie algebra coordinates ===
        d_mu_proj = np.einsum("...ij,ajk->...a", np.expand_dims(d_mu, -1), generators)  # (..., a)

        d_phi_mu = dexpinv_operator(phi_i, d_mu_proj, generators)
        d_phi_sigma = dexpinv_operator_covariance(phi_i, d_sigma, generators)
        grad = d_phi_mu + d_phi_sigma

        # Masked contribution
        joint_mask = (agent_i.mask > eps) & (agent_j.mask > eps)
        grad_phi += beta * grad * joint_mask[..., None]

    return grad_phi


def combine_field_gradients(agent_i, agents, params, field_type="model"):
    if field_type == "model" and getattr(config, "identical_models", False):
        return zero_mu_sigma_like(agent_i)

    # Load all parameters
    α  = params.get("alpha", config.alpha)
    β  = params.get("model_align_weight", config.model_align_weight) if field_type == "model" else params.get("beta", config.beta)
    fb = params.get("model_feedback_weight", config.model_feedback_weight) if field_type == "model" else params.get("belief_feedback_weight", getattr(config, "belief_feedback_weight", 0.0))
    λ  = params.get("variance_penalty_model_weight", getattr(config, "variance_penalty_model_weight", 0.0)) if field_type == "model" else params.get("variance_penalty_belief_weight", getattr(config, "variance_penalty_belief_weight", 0.0))
    eps = params.get("support_cutoff_eps", config.support_cutoff_eps)

    # Mask
    mask = agent_i.mask > eps
    if not np.any(mask):
        return zero_mu_sigma_like(agent_i)

    # Select fields
    mu_field    = agent_i.mu_p_field if field_type == "model" else agent_i.mu_q_field
    sigma_field = agent_i.sigma_p_field if field_type == "model" else agent_i.sigma_q_field

    # --- Natural-gradient components ---
    grad_mu_nat    = np.zeros_like(mu_field)
    grad_sigma_nat = np.zeros_like(sigma_field)

    if α > 0:
        dμ, dΣ = grad_self_field(agent_i, α, field_type, mask)
        grad_mu_nat += dμ
        grad_sigma_nat += dΣ
    if fb > 0:
        dμ, dΣ = grad_feedback_field(agent_i, fb, field_type, mask)
        grad_mu_nat += dμ
        grad_sigma_nat += dΣ
    if β > 0:
        dμ, dΣ = alignment_gradient_field(agent_i, agents, params, field_type=field_type, mask=mask)

        grad_mu_nat += dμ
        grad_sigma_nat += dΣ

    # --- Apply Fisher preconditioner only to KL terms ---
    delta_mu, delta_sigma = apply_natural_gradient_batch(
        mu_field, sigma_field, grad_mu_nat, grad_sigma_nat
    )

    # --- Add regularization (coordinate) terms AFTER natural gradient ---
    if λ > 0:
        dμ_reg, dΣ_reg = grad_variance_penalty_field(agent_i, λ, field_type, mask)
        delta_mu    += dμ_reg
        delta_sigma += dΣ_reg

    # Final nan sanitization
    delta_mu    = np.nan_to_num(delta_mu, nan=0.0, posinf=1e5, neginf=-1e5)
    delta_sigma = np.nan_to_num(delta_sigma, nan=0.0, posinf=1e5, neginf=-1e5)

    return delta_mu, delta_sigma

def compute_phi_update(agent_i, agents, params, field="phi"):
    """
    Unified update for φ (belief alignment) and φ̃ (model alignment).
    Applies Lie-natural gradient to alignment + optional regularizers.
    """
    if field == "phi_model" and getattr(config, "identical_models", False):
        return np.zeros_like(agent_i.phi_model)

    # --- Unpack core parameters ---
    unpacked  = unpack_phi_update_params(params, field=field)
    β         = params.get("beta", config.beta) if field == "phi" else params.get("model_align_weight", config.model_align_weight)
    κ         = unpacked["κ"]
    gw        = unpacked["gw"]
    curv_w    = unpacked["curv_weight"]
    clip_th   = unpacked["grad_clip_threshold"]
    eps       = unpacked["overlap_eps"]
    debug     = unpacked["debug"]

    phi       = agent_i.phi if field == "phi" else agent_i.phi_model
    phi_tilde = agent_i.phi_model if field == "phi" else agent_i.phi
    soft_mask = agent_i.mask[..., None]
    generators_q = params.get("generators_q", get_generators(config.group_name, config.K_q))
    generators_p = params.get("generators_p", get_generators(config.group_name, config.K_p))


    if not np.any(soft_mask > eps):
        return np.zeros_like(phi)

    grad = np.zeros_like(phi)

    generators = generators_q if field == "phi" else generators_p
    G_inv = compute_inverse_fisher_field(agent_i, generators, field=field)


    # --- 1. Alignment gradient (Lie-natural, variationally consistent) ---
    if β > 0:
        grad_align = np.zeros_like(phi)
        for neighbor in agent_i.neighbors:
            agent_j = agents[neighbor["id"]]
            accumulate_phi_gradient(agent_i, agent_j, generators, params, field=field)
        grad_align = agent_i.grad_phi.copy()
        agent_i.grad_phi[:] = 0.0  # Clear after use

        grad += apply_lie_natural_gradient(phi, grad_align, G_inv=G_inv)

    # --- 2. Curvature gradient ---
    if curv_w > 0:
        generators = generators_q if field == "phi" else generators_p
        grad_curv = compute_curvature_gradient_analytical(phi, generators)
        grad += curv_w * grad_curv

    # --- 3. Mass term: 2γ φ ---
    if gw > 0:
        grad += 2 * gw * phi

    # --- 4. φ–φ̃ coupling ---
    if κ > 0:
        grad += 2 * κ * (phi - phi_tilde)

    # --- 5. Optional Fisher geometry term ---
    fisher_key = "fisher_geometry_weight" if field == "phi" else "fisher_model_geometry_weight"
    fisher_weight = params.get(fisher_key, getattr(config, fisher_key, 0.0))
    if fisher_weight > 0:
        fisher_fn = compute_fisher_geometry_gradient if field == "phi" else compute_fisher_geometry_gradient
        fisher_grad = fisher_fn(agent_i, agents, params)
        grad += fisher_weight * fisher_grad

    # --- Final clip + mask ---
    return clip_and_mask_gradient(grad, soft_mask, clip_th, eps)