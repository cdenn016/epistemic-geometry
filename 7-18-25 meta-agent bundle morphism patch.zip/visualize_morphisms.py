# -*- coding: utf-8 -*-
"""
Created on Thu Jul 17 20:06:34 2025

@author: chris and christine
"""

import os
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from generalized_io_utils import load_all_checkpoints  # replace with your loading utility
import config

sns.set(style="whitegrid")

def get_global_morphism_bounds(data):
    min_phi, max_phi = np.inf, -np.inf
    min_phi_tilde, max_phi_tilde = np.inf, -np.inf

    for step in data:
        for agent in data[step]:
            Φ = agent.bundle_morphism_q_to_p
            Φ̃ = agent.bundle_morphism_p_to_q

            Φ_avg = np.mean(Φ, axis=(0, 1))
            Φ̃_avg = np.mean(Φ̃, axis=(0, 1))

            min_phi = min(min_phi, Φ_avg.min())
            max_phi = max(max_phi, Φ_avg.max())

            min_phi_tilde = min(min_phi_tilde, Φ̃_avg.min())
            max_phi_tilde = max(max_phi_tilde, Φ̃_avg.max())

    return (min_phi, max_phi), (min_phi_tilde, max_phi_tilde)


def visualize_morphisms_static(agents, save_dir="Morphism_Visualizations", step=0,
                                phi_bounds=None, phi_tilde_bounds=None):
    os.makedirs(save_dir, exist_ok=True)

    for i, agent in enumerate(agents):
        fig, axes = plt.subplots(1, 2, figsize=(10, 4))

        Φ = agent.bundle_morphism_q_to_p
        Φ̃ = agent.bundle_morphism_p_to_q

        Φ_avg = np.mean(Φ, axis=(0, 1))
        Φ̃_avg = np.mean(Φ̃, axis=(0, 1))

        sns.heatmap(Φ_avg, ax=axes[0], cmap="coolwarm", center=0, cbar=True,
                    vmin=phi_bounds[0], vmax=phi_bounds[1])
        axes[0].set_title(f"Φ [Agent {i}] (shape {Φ_avg.shape})")

        sns.heatmap(Φ̃_avg, ax=axes[1], cmap="coolwarm", center=0, cbar=True,
                    vmin=phi_tilde_bounds[0], vmax=phi_tilde_bounds[1])
        axes[1].set_title(f"Φ̃ [Agent {i}] (shape {Φ̃_avg.shape})")

        fig.suptitle(f"Bundle Morphisms — Agent {i} — Step {step}")
        fig.tight_layout()
        fig.savefig(f"{save_dir}/agent_{i:02d}_step_{step:04d}.png")
        plt.close(fig)


def visualize_over_time(folder="checkpoints"):
    data = load_all_checkpoints(folder)
    steps = sorted(data.keys())
    phi_bounds, phi_tilde_bounds = get_global_morphism_bounds(data)

    for step in steps:
        agents = data[step]
        visualize_morphisms_static(agents, step=step,
                                   phi_bounds=phi_bounds,
                                   phi_tilde_bounds=phi_tilde_bounds)



if __name__ == "__main__":
    # Option 1: visualize a static frame (live agents)
    # from generalized_simulation import initialize_agents
    # agents = initialize_agents(...)
    # visualize_morphisms_static(agents)

    # Option 2: visualize over saved checkpoints
    visualize_over_time("checkpoints")
