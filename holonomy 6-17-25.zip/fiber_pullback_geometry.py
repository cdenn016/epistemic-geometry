# -*- coding: utf-8 -*-
"""
Created on Sun Jun 15 16:01:51 2025

@author: chris and christine
"""

import numpy as np
import config
from generalized_math_utils import gradient_field, sanitize_q
from fiber_information_geometry import compute_fisher_velocity


def pullback_velocity_vector_field(agent_t, agent_tp1, field="q", dt=1.0):
    """
    Pull back the epistemic velocity \dot{q} to the base manifold as a vector field.
    Computes the gradient of Fisher norm \| \dot{q}(c) \|_F.
    Returns: array of shape (..., D), where D is spatial dimension.
    """
    q0 = getattr(agent_t, field)
    q1 = getattr(agent_tp1, field)
    mask = agent_t.mask

    fisher_speed = compute_fisher_velocity(q0, q1, dt=dt) * mask  # shape (...,)
    grad = gradient_field(fisher_speed)
    return np.stack(grad, axis=-1) * mask[..., None]  # shape (..., D)


def pullback_fisher_metric(agent, field="q"):
    """
    Pull back the Fisher metric tensor at each spatial point q(c), shape (..., K, K).
    Can be used to compute anisotropy or directional epistemic tension.
    """
    q = getattr(agent, field)
    q = sanitize_q(q)
    shape = q.shape[:-1]
    K = q.shape[-1]
    fisher = np.zeros(shape + (K, K))
    for idx in np.ndindex(shape):
        qi = q[idx]
        fisher[idx] = np.diag(1.0 / qi) - np.outer(1.0 / qi, 1.0 / qi) / np.sum(1.0 / qi)
    return fisher * agent.mask[..., None, None]


def compute_epistemic_gradient_field(agent, scalar_func):
    """
    Compute the gradient of a scalar fiber-derived quantity over the base manifold.
    scalar_func: function(agent) -> scalar field of shape (...,)
    Returns: vector field (..., D)
    """
    scalar_field = scalar_func(agent)
    grad = gradient_field(scalar_field)
    return np.stack(grad, axis=-1) * agent.mask[..., None]


def project_fiber_update_to_scalar(agent_t, agent_tp1, field="q", dt=1.0):
    """
    Project fiber update velocity \dot{q}(c) onto scalar field via Fisher norm.
    Returns scalar field of shape (...,) over the base.
    """
    q0 = getattr(agent_t, field)
    q1 = getattr(agent_tp1, field)
    return compute_fisher_velocity(q0, q1, dt=dt) * agent_t.mask
