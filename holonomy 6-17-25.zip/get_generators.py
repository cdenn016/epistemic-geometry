import numpy as np

# Cache for generated generators
_generator_cache = {}

def get_generators(group_name: str, K: int) -> np.ndarray:
    """
    Return the Lie algebra generators for the specified group and representation dimension.

    Parameters:
        group_name: str -- name of the Lie group ("sl2r", "so3", "u1", "su2", "so5", etc.)
        K: int -- dimension of the representation (K must match the fundamental rep dimension for so(n))

    Returns:
        generators: np.ndarray of shape (dim_G, K, K)
    """
    key = (group_name.lower(), K)
    if key in _generator_cache:
        return _generator_cache[key]

    name = group_name.lower()
    if name == "sl2r":
        gens = _generate_sl2r_generators(K)
    elif name == "so3":
        gens = _generate_so3_generators(K)
    elif name == "u1":
        gens = _generate_u1_generators(K)
    elif name in ("su2", "su_2"):
        gens = _generate_su2_generators(K)
    elif name.startswith("so"): #can only use the fundamental irrep
        try:
            dim = int(name[2:])
            if K != dim:
                raise ValueError(f"SO({dim}) fundamental representation requires K={dim}, got K={K}")
            gens = _generate_soN_generators(dim)
        except:
            raise ValueError(f"Invalid SO(n) group name: '{group_name}'")
    else:
        raise ValueError(f"Unsupported group '{group_name}' for get_generators.")

    _generator_cache[key] = gens
    return gens



def infer_lie_algebra_dim(group_name: str, K: int) -> int:
    group_name = group_name.lower()
    if group_name == 'u1':
        return 1
    elif group_name == 'so3':
        return 3
    elif group_name == 'sl2r':
        return 3
    elif group_name.startswith('su'):
        try:
            N = int(group_name[2:])
            return N**2 - 1
        except:
            raise ValueError(f"Invalid SU(N) group name: {group_name}")
    else:
        raise NotImplementedError(f"Group {group_name} not recognized for algebra dimension inference.")



def _generate_sl2r_generators(K: int) -> np.ndarray:
    if K % 2 == 0:
        raise ValueError("K must be odd for SL(2,R) irreps (K=2ℓ+1).")
    l = (K - 1) // 2
    L1 = np.zeros((K, K), dtype=float)
    L2 = np.zeros((K, K), dtype=float)
    L3 = np.zeros((K, K), dtype=float)
    for m in range(-l, l + 1):
        idx = m + l
        L3[idx, idx] = m
        if idx < K - 1:
            a = np.sqrt((l - m) * (l + m + 1))
            L1[idx, idx + 1] = a
            L1[idx + 1, idx] = a
            L2[idx, idx + 1] = -a
            L2[idx + 1, idx] = a
    return np.stack([L1, L2, L3], axis=0)


def _generate_so3_generators(K: int) -> np.ndarray:
    if K % 2 == 0:
        raise ValueError("K must be odd for SO(3) irreps (K=2ℓ+1).")
    l = (K - 1) // 2
    Jx = np.zeros((K, K), dtype=float)
    Jy = np.zeros((K, K), dtype=complex)
    Jz = np.zeros((K, K), dtype=float)
    for m in range(-l, l + 1):
        idx = m + l
        Jz[idx, idx] = m
        if idx < K - 1:
            a = 0.5 * np.sqrt((l - m) * (l + m + 1))
            Jx[idx, idx + 1] = a
            Jx[idx + 1, idx] = a
            Jy[idx, idx + 1] = -1j * a
            Jy[idx + 1, idx] = 1j * a
    Jy = Jy.real
    return np.stack([Jx, Jy, Jz], axis=0)


def _generate_u1_generators(K: int) -> np.ndarray:
    # Abelian U(1): single diagonal generator
    l = (K - 1) // 2
    Jz = np.diag(np.arange(-l, l + 1, dtype=float))
    return Jz[np.newaxis, :, :]


def _generate_su2_generators(K: int) -> np.ndarray:
    """
    Generate SU(2) generators (spin-j irrep) for dimension K = 2j+1.
    """
    j = (K - 1) / 2
    # Magnetic quantum numbers m = j, j-1, ..., -j
    m_vals = np.array([j - i for i in range(K)], dtype=float)
    # Diagonal Jz
    Jz = np.diag(m_vals)
    # Ladder operators J+ and J-
    Jp = np.zeros((K, K), dtype=complex)
    for idx, m in enumerate(m_vals):
        if idx < K - 1:
            coef = np.sqrt((j - m) * (j + m + 1))
            Jp[idx, idx + 1] = coef
    Jm = Jp.conj().T
    # Jx = (J+ + J-) / 2
    Jx = 0.5 * (Jp + Jm)
    # Jy = (J+ - J-) / (2i)
    Jy = (Jp - Jm) * (-0.5j)
    return np.stack([Jx, Jy, Jz], axis=0)


def _generate_soN_generators(dim: int) -> np.ndarray:
    """
    Generate the fundamental representation of so(dim),
    i.e., real antisymmetric dim x dim matrices.

    Returns:
        generators: ndarray of shape (dim*(dim-1)//2, dim, dim)
    """
    count = 0
    gens = []
    for i in range(dim):
        for j in range(i+1, dim):
            G = np.zeros((dim, dim), dtype=float)
            G[i, j] = 1.0
            G[j, i] = -1.0
            gens.append(G)
            count += 1
    return np.stack(gens, axis=0)
