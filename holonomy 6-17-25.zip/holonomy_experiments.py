#!/usr/bin/env python3
"""
holonomy_experiments.py

Run holonomy analyses across multiple configurations:
 1. Spatial loops of varying sizes.
 2. Agent-cycle loops sampled randomly from discovered cycles.

For each experiment, computes both simple curvature proxy ||H - I|| and true curvature via ||logm(H)||.
Aggregates results into a master CSV and produces summary plots.
"""
import os
import re
import pickle
import random
import logging
import numpy as np
import pandas as pd
from numpy.linalg import norm
from scipy.linalg import logm
import matplotlib.pyplot as plt

from get_generators import get_generators
from holonomy_module import (
    sample_square_loop,
    compute_spatial_loop_holonomy,
    compute_agent_cycle_holonomy
)
from find_agent_chains import (
    get_overlap_centroid,
    get_agent_cycles
)
from config import (
    checkpoint_dir,
    domain_size,
    support_cutoff_eps,
    group_name,
    K
)

# ----------------------------
# Experiment parameters
# ----------------------------
max_agent_cycles = 15          # None = all cycles
spatial_sizes = [int(round(x)) for x in np.linspace(1, 10, num=20)]

# ----------------------------
# Logging setup
# ----------------------------
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s %(levelname)s %(message)s'
)


def parse_step(filename):
    """
    Extract integer step from filenames like 'step_0001.pkl'.
    """
    match = re.match(r'step_(\d+)\.pkl$', filename)
    if not match:
        raise ValueError(f"Filename '{filename}' does not match expected pattern")
    return int(match.group(1))


def load_all_checkpoints():
    """
    Load and cache all checkpoint files from checkpoint_dir.
    Returns a dict mapping step -> unpickled data.
    """
    files = [f for f in os.listdir(checkpoint_dir)
             if f.startswith('step_') and f.endswith('.pkl')]
    if not files:
        raise RuntimeError(f"No checkpoint files found in {checkpoint_dir}")

    # sort by parsed step number
    files_sorted = sorted(files, key=lambda f: parse_step(f))
    cache = {}
    for fname in files_sorted:
        step = parse_step(fname)
        path = os.path.join(checkpoint_dir, fname)
        with open(path, 'rb') as f:
            cache[step] = pickle.load(f)
        logging.info(f"Loaded checkpoint step={step}")
    return cache


def main():
    # Load all simulation checkpoints
    data_cache = load_all_checkpoints()
    steps = sorted(data_cache.keys())

    # Discover agent cycles from first checkpoint
    first_data = data_cache[steps[0]]
    agents0 = first_data[0] if isinstance(first_data, tuple) else first_data
    all_cycles = get_agent_cycles(agents0, max_length=5)
    if not all_cycles:
        logging.warning("No agent cycles found; skipping agent_cycle experiments.")

    # Reproducible sampling of cycles
    random.seed(42)
    if max_agent_cycles is not None and len(all_cycles) > max_agent_cycles:
        agent_cycles_list = random.sample(all_cycles, max_agent_cycles)
    else:
        agent_cycles_list = all_cycles

    logging.info(f"Using {len(agent_cycles_list)} agent cycles and {len(spatial_sizes)} spatial sizes.")

    # Prepare generators and records
    generators = get_generators(group_name, K)
    records = []

    # Spatial loop experiments
    for size in spatial_sizes:
        exp_name = 'spatial'
        for step in steps:
            data = data_cache[step]
            agents = data[0] if isinstance(data, tuple) else data

            # Square loop around center
            center = (domain_size[0] // 2, domain_size[1] // 2)
            coords = sample_square_loop(center, size=size, domain_size=domain_size)
            # … inside the `for step in steps:` loop, after computing H …
            H = compute_spatial_loop_holonomy(agents[0], coords, generators)

            # —— insert diagnostics here —— #
            F          = logm(H)                       # the matrix‐log for true curvature
            c_logm     = norm(F)                       # your existing log‐norm metric
            c_norm     = norm(H - np.eye(H.shape[0]))  # your existing proxy

            det_H      = np.linalg.det(H)              # should be ~1 for an orthonormal holonomy
            trace_H    = np.trace(H)                   # trace gives axis‐angle info in SO(3)
            cond_H     = np.linalg.cond(H)             # condition number
            chordal    = c_norm                        # alias for readability
            loop_len   = len(coords)                   # spatial loop length

            records.append({
                'experiment':     exp_name,
                'param':          size,
                'step':           step,
                'curvature_logm': c_logm,
                'curvature_norm': c_norm,
                'det_minus1':     det_H - 1,
                'trace':          trace_H,
                'cond':           cond_H,
                'chordal':        chordal,
                'loop_length':    loop_len,
                })

    # Agent-cycle experiments
    for cycle in agent_cycles_list:
        exp_name    = 'agent_cycle'
        param_label = '_'.join(map(str, cycle))
        for step in steps:
            data   = data_cache[step]
            agents = data[0] if isinstance(data, tuple) else data

            overlaps = []
            for i, j in zip(cycle[:-1], cycle[1:]):
                c = get_overlap_centroid(agents[i], agents[j], domain_size, support_cutoff_eps)
                overlaps.append(c if c is not None else (np.nan,))

            H = compute_agent_cycle_holonomy(agents, cycle, overlaps, generators)

            # … after computing H …
            F        = logm(H)
            c_logm   = norm(F)
            c_norm   = norm(H - np.eye(H.shape[0]))
            det_H    = np.linalg.det(H)
            trace_H  = np.trace(H)
            cond_H   = np.linalg.cond(H)
            chordal  = c_norm
            loop_len = len(cycle)

            records.append({
                'experiment':     exp_name,
                'param':          param_label,
                'step':           step,
                'curvature_logm': c_logm,
                'curvature_norm': c_norm,
                'det_minus1':     det_H - 1,
                'trace':          trace_H,
                'cond':           cond_H,
                'chordal':        chordal,
                'loop_length':    loop_len,
                })


    # Save results
    summary_df = pd.DataFrame(records)
    out_dir = 'holonomy_experiments'
    os.makedirs(out_dir, exist_ok=True)
    master_csv = os.path.join(out_dir, 'master_summary.csv')
    summary_df.to_csv(master_csv, index=False)
    logging.info(f"Master summary written to {master_csv}")

    # Generate summary plots
    for metric in ['curvature_norm', 'curvature_logm']:
        plt.figure(figsize=(10, 6))
        for exp in summary_df['experiment'].unique():
            df_sub = summary_df[summary_df['experiment'] == exp]
            avg = df_sub.groupby('param')[metric].mean()
            plt.plot(avg.index, avg.values, marker='o', label=exp)
        plt.xlabel('Parameter (size or cycle)')
        plt.ylabel(metric)
        plt.title(f'Average {metric} vs. experiment parameter')
        plt.xticks(rotation=45, ha='right')
        plt.legend()
        plt.tight_layout()
        plt.savefig(os.path.join(out_dir, f'{metric}_vs_param.png'))
        plt.close()
    logging.info(f"Plots saved to {out_dir}")


if __name__ == '__main__':
    main()
