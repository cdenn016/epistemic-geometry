import numpy as np
import matplotlib.pyplot as plt
import os
import config


def plot_fiber_at_point(agent, coord, field="q", title=None, savepath=None):
    """
    Plot the probability vector (fiber) at a given spatial coordinate from an agent.
    """
    fiber = getattr(agent, field)
    if not all(0 <= c < s for c, s in zip(coord, fiber.shape[:-1])):
        raise ValueError(f"Invalid coordinate {coord} for shape {fiber.shape}")

    vec = fiber[coord]  # shape: (K,)
    K = vec.shape[-1]
    plt.figure()
    plt.bar(np.arange(K), vec)
    plt.xlabel("Fiber index k")
    plt.ylabel(f"{field}(c)[k]")
    plt.title(title or f"{field} at {coord}")
    plt.ylim(0, 1)
    if savepath:
        os.makedirs(os.path.dirname(savepath), exist_ok=True)
        plt.savefig(savepath)
    plt.close()


def compare_q_and_p_at_point(agent, coord, title=None, savepath=None):
    """
    Compare q and p distributions at a spatial coordinate in one agent.
    """
    q = agent.q[coord]
    p = agent.p[coord]
    K = q.shape[-1]
    x = np.arange(K)

    plt.figure()
    plt.bar(x - 0.2, q, width=0.4, label="q", alpha=0.8)
    plt.bar(x + 0.2, p, width=0.4, label="p", alpha=0.8)
    plt.xlabel("Fiber index k")
    plt.ylabel("Probability")
    plt.title(title or f"q vs p at {coord}")
    plt.ylim(0, 1)
    plt.legend()
    if savepath:
        os.makedirs(os.path.dirname(savepath), exist_ok=True)
        plt.savefig(savepath)
    plt.close()


def compare_fiber_between_agents(agent_i, agent_j, coord, field="q", title=None, savepath=None):
    """
    Compare the same fiber (e.g., q) at a location between two agents.
    """
    vec_i = getattr(agent_i, field)[coord]
    vec_j = getattr(agent_j, field)[coord]
    K = vec_i.shape[-1]
    x = np.arange(K)

    plt.figure()
    plt.bar(x - 0.2, vec_i, width=0.4, label=f"Agent {agent_i.id}", alpha=0.8)
    plt.bar(x + 0.2, vec_j, width=0.4, label=f"Agent {agent_j.id}", alpha=0.8)
    plt.xlabel("Fiber index k")
    plt.ylabel(f"{field}(c)[k]")
    plt.title(title or f"{field} at {coord} (Agent {agent_i.id} vs {agent_j.id})")
    plt.ylim(0, 1)
    plt.legend()
    if savepath:
        os.makedirs(os.path.dirname(savepath), exist_ok=True)
        plt.savefig(savepath)
    plt.close()


def animate_fiber_at_point_over_time(agent_sequence, coord, field="q", title="", savepath=None):
    """
    Animate the evolution of q(c) or p(c) over time.
    agent_sequence: list of Agent objects, one per timestep.
    """
    import matplotlib.animation as animation

    K = getattr(agent_sequence[0], field)[coord].shape[-1]
    fig, ax = plt.subplots()
    bars = ax.bar(np.arange(K), np.zeros(K))
    ax.set_ylim(0, 1)
    ax.set_xlabel("Fiber index k")
    ax.set_ylabel(f"{field}(c)[k]")

    def update(t):
        vec = getattr(agent_sequence[t], field)[coord]
        for b, v in zip(bars, vec):
            b.set_height(v)
        ax.set_title(f"{title} (t={t})")
        return bars

    ani = animation.FuncAnimation(fig, update, frames=len(agent_sequence), blit=False)
    if savepath:
        os.makedirs(os.path.dirname(savepath), exist_ok=True)
        ani.save(savepath, writer="pillow", fps=5)
    plt.close()
