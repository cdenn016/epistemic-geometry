# -*- coding: utf-8 -*-
"""
Created on Tue Jun 17 16:26:21 2025

@author: chris and christine
"""

'''
holonomy_module.py

Module to compute gauge holonomy within a single agent (spatial loops) and across agents (agent-chain loops).
'''

import numpy as np
from transport_operator import compute_intra_agent_omega, compute_inter_agent_omega
from find_agent_chains import construct_spatial_path_nd


def compute_spatial_loop_holonomy(agent, loop_coords, generators, use_commutator=True):
    """
    Compute holonomy around a closed spatial loop within a single agent.

    Parameters:
        agent: Agent object with `phi` field (shape [..., lie_dim])
        loop_coords: List of coordinate tuples defining a closed loop (first == last)
        generators: Lie algebra generators for exp map
        use_commutator: bool, whether to use commutator form for omega

    Returns:
        H: np.ndarray of shape (K, K), the holonomy matrix for the loop
    """
    if len(loop_coords) < 2 or loop_coords[0] != loop_coords[-1]:
        raise ValueError("loop_coords must start and end at the same coordinate")

    H = np.eye(generators.shape[-1])  # identity in representation space
    # traverse loop edges
    for p0, p1 in zip(loop_coords[:-1], loop_coords[1:]):
        omega = compute_intra_agent_omega(agent.phi, p0, p1, generators, use_commutator)
        H = omega @ H
    return H


def compute_agent_cycle_holonomy(agents, agent_cycle, overlap_points, generators, use_commutator=True):
    """
    Compute holonomy around a closed loop of agents.

    Parameters:
        agents: list of Agent objects
        agent_cycle: list of agent IDs (first == last) defining a closed chain
        overlap_points: list of spatial coords where each consecutive pair overlaps
                        length == len(agent_cycle)-1, last should correspond to closing step
        generators: Lie algebra generators for exp map
        use_commutator: bool, whether to use commutator for inter-agent omega

    Returns:
        H: np.ndarray of shape (K, K), the total holonomy for the agent cycle
    """
    if len(agent_cycle) < 2 or agent_cycle[0] != agent_cycle[-1]:
        raise ValueError("agent_cycle must start and end at the same agent ID")
    if len(overlap_points) != len(agent_cycle) - 1:
        raise ValueError("overlap_points length must be one less than agent_cycle length")

    H = np.eye(generators.shape[-1])
    # traverse inter-agent jumps
    for idx in range(len(agent_cycle)-1):
        i = agent_cycle[idx]
        j = agent_cycle[idx+1]
        c = overlap_points[idx]
        omega = compute_inter_agent_omega(
            agents[i].phi, agents[j].phi, c, generators, use_commutator
        )
        H = omega @ H
    return H


def sample_square_loop(center, size=1, domain_size=None):
    """
    Utility to generate a square loop of given half-size around center in ND.
    Only supports 2D loops.

    Parameters:
        center: tuple (x, y)
        size: int, half-length of the square side
        domain_size: tuple to wrap coordinates periodically

    Returns:
        loop_coords: list of coordinate tuples closing the square
    """
    if len(center) != 2:
        raise ValueError("sample_square_loop only supports 2D loops")
    x0, y0 = center
    corners = [
        (x0 - size, y0 - size),
        (x0 + size, y0 - size),
        (x0 + size, y0 + size),
        (x0 - size, y0 + size),
        (x0 - size, y0 - size),
    ]
    loop = []
    for coord in corners:
        if domain_size is not None:
            coord = tuple(np.array(coord) % np.array(domain_size))
        loop.append(coord)
    return loop
