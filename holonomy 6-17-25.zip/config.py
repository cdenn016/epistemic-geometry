import numpy as np
import sys

# ===========================
# DEBUGGING AND UTILITIES
# ===========================

debug = True  # Global debug flag for extra logging inside φ updates

def set_config_from_params(params):
    """Dynamically override config attributes from a dictionary."""
    this_module = sys.modules[__name__]
    for k, v in params.items():
        setattr(this_module, k, v)

# ===========================
# GROUP & REPRESENTATION SETTINGS
# ===========================

group_name = 'sl2r'               # Options: "u1", "so3", "sl2r", 'su2'.
representation_type = 'irrep'     # Options: 'irrep', 'fundamental', 'adjoint'
use_commutator = False            # use "false" to use the general exp.exp multiplication

                      

# ===========================
# DOMAIN / SPATIAL SETTINGS
# ===========================
K = 45          # Fiber dimension of belief/model space (depends on representation)
D = 2            #dimension of base manifold

L = 75           #length of hypercubic base-manifold

steps = 150

N = 5                              # Number of agents
max_neighbors = 3                # Max number of agent neighbors
agent_seed = 23


# ===========================
# COUPLINGS & PENALTIES
# ===========================

alpha = 5                     # KL(q || p) self-energy
beta = 20                    # KL(q || Ω q) belief coupling
gamma = 5                    # Laplacian penalty on φ
gauge_weight = 10            # φ² mass term

model_align_weight = 9        # KL(p || Ω̃ p)
model_gauge_weight = 5       # Laplacian penalty on φ_model
model_mass_weight = 9       # φ_model² mass term
model_feedback_weight = 5    # KL feedback p || q

phi_phi_tilde_coupling = 10    # Coupling φ ↔ φ̃

curvature_weight = 0
phi_damping = 0


psi_radius_range = (13, 20)         #agent radii

# ===========================
# DISTRIBUTION SETTINGS
# ===========================
spatial_resolution=1
distribution_family = 'gaussian'   # Options: "gaussian", "exponential", "beta". "uniform", etc.


#=================================
# TRANSPORT DISTRIBUTION INJECTION
#=================================
injection_mode = "gaussian"  # or "gaussian", "from_q", "from_p, "delta", etc




# ===========================
# AGENT GEOMETRY
# ===========================
q_mu_range = (2, K-2)
q_sigma_range = (1, 4)
p_mu_range = (2, K-2)
p_sigma_range = (1, 3)
similar_p_models = False


mu_sigma_scale_range = (2, 6)

mask_sharpness = 1.5
mu_field_smooth_range = (2, 6)
sigma_field_smooth_range = (2,6)

# ===========================
# INITIALIZATION
# ===========================



phi_init_smooth_sigma = 2
phi_init = 0.1
phi_model_offset = 0.1

# ===========================
# LEARNING RATES
# ===========================
eta_base_q = 1e-4
eta_base_p = 1e-5
eta_base_phi = 1e-3
eta_base_phi_model = 1e-6

# --- Belief field q_i update ---
eta_q = eta_base_q / (alpha + beta + 1e-8)

# --- Model field p_i update ---
eta_p = eta_base_p / (
    alpha +
    model_align_weight +
    model_feedback_weight +
    model_gauge_weight +
    model_mass_weight + 1e-8
)

# --- Phase field φ_i (belief transport) ---
eta_phi = eta_base_phi / (
    gauge_weight +
    gamma +
    curvature_weight +
    phi_damping +
    phi_phi_tilde_coupling + 1e-8
)

# --- Phase field φ̃_i (model transport) ---
eta_model_phi = eta_base_phi_model / (
    model_align_weight +
    model_gauge_weight +
    model_mass_weight +
    phi_phi_tilde_coupling +
    phi_damping + 1e-8
)


# ===========================
# STABILITY AND CLIPPING
# ===========================

phi_clip_threshold = 4000       # scale down large φ shifts
phi_max_norm       = 100       # keep φ in a reasonable reference frame
gradient_clip      = 10.0      # if also applied to φ gradients
blowup_threshold   = 4000.0      # skip updates that are clearly unstable
phi_diff_clip = 3.0            # or experiment with values like 2.0 or 5.0


# ===========================
# EPSILONS & PRECISION
# ===========================

log_eps = 1e-10
support_cutoff_eps = 1e-1           #agent and mask overlap = at 1e-1
overlap_eps = 1e-5
eps = 1e-10

precision = np.float32

# ===========================
# CHECKPOINTING
# ===========================

checkpoint_dir = "checkpoints"
save_checkpoints = True
checkpoint_interval = 1

domain_size = (L,) * D