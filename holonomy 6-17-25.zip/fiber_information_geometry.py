# -*- coding: utf-8 -*-
"""
Created on Sun Jun 15 15:58:00 2025

@author: chris and christine
"""

import numpy as np
import config
from generalized_math_utils import sanitize_q


def compute_fisher_information(q):
    """
    Compute Fisher information matrix I(q) for a single distribution q over K classes.
    q: array of shape (K,), assumed sanitized.
    Returns: Fisher matrix of shape (K, K) in standard coordinates.
    """
    q = sanitize_q(q)
    return np.diag(1.0 / q) - np.outer(1.0 / q, 1.0 / q) / np.sum(1.0 / q)


def compute_fisher_velocity(q_t, q_tp1, dt=1.0):
    """
    Approximate Fisher norm of the change in q between two timesteps.
    Returns a scalar Fisher norm at each point.
    """
    q_t = sanitize_q(q_t)
    q_tp1 = sanitize_q(q_tp1)

    dq = (q_tp1 - q_t) / dt
    fisher = np.diag(1.0 / q_t)  # diagonal Fisher metric
    return np.sqrt(np.sum(fisher * dq**2, axis=-1))  # shape (...,)


def compute_fisher_velocity_field(agents_t, agents_tp1, field="q", dt=1.0):
    """
    Compute the Fisher norm of the epistemic update at each spatial point for all agents.
    field: either "q" or "p"
    Returns: list of arrays (one per agent), each shape (...,) matching the domain.
    """
    velocities = []
    for a0, a1 in zip(agents_t, agents_tp1):
        q0 = getattr(a0, field)
        q1 = getattr(a1, field)
        mask = a0.mask
        vel = compute_fisher_velocity(q0, q1, dt=dt)
        velocities.append(vel * mask)  # zero outside support
    return velocities


def compute_mean_fisher_velocity(agents_t, agents_tp1, field="q", dt=1.0):
    """
    Mean Fisher velocity over all agents, support-weighted.
    """
    total = 0.0
    weight = 0.0
    for a0, a1 in zip(agents_t, agents_tp1):
        q0 = getattr(a0, field)
        q1 = getattr(a1, field)
        mask = a0.mask
        vel = compute_fisher_velocity(q0, q1, dt=dt)
        total += np.sum(vel * mask)
        weight += np.sum(mask)
    return total / (weight + config.eps)


def compute_fisher_matrix_field(agent, field="q"):
    """
    Compute the Fisher information matrix I(q(c)) at each spatial point in an agent.
    Returns: array of shape (..., K, K)
    """
    q = getattr(agent, field)
    shape = q.shape[:-1]
    K = q.shape[-1]
    F = np.zeros(shape + (K, K))
    for idx in np.ndindex(shape):
        F[idx] = compute_fisher_information(q[idx])
    return F * agent.mask[..., None, None]
