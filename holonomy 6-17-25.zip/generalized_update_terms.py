import numpy as np
import config

from get_generators import get_generators
from generalized_omega import (
    exp_lie_algebra_irrep,
    batch_apply_omega,
    repair_if_forgotten_batch,
)
from generalized_math_utils import sanitize_q


def self_grad_wrt_q(q,p,eps):
    q = sanitize_q(q,eps)
    p = sanitize_q(p,eps)
    return np.log(q/p) + 1.0

def self_grad_wrt_p(q,p,eps):
    q = sanitize_q(q,eps)
    p = sanitize_q(p,eps)
    return -q/p


def compute_self_gradient(
    agent_i,
    dist_field_q: str,
    dist_field_p: str,
    mask_field: str,
    params: dict
) -> np.ndarray:
    """
    Compute gradient of self KL D_KL(q_i || p_i) with respect to q_i over support.
    Uses ∂/∂q D_KL(q||p) = log(q/p) + 1.
    """
    # Hyperparameters
    alpha          = params.get("alpha", config.alpha)
    log_eps        = params.get("log_eps", config.log_eps)
    support_cutoff = params.get("support_cutoff_eps", config.support_cutoff_eps)

    # Fields
    q    = getattr(agent_i, dist_field_q)
    p    = getattr(agent_i, dist_field_p)
    mask = getattr(agent_i, mask_field)
    support = mask > support_cutoff

    grad = np.zeros_like(q)
    if alpha > 0 and support.any():
        # sanitize distributions on support
        q_s = sanitize_q(q[support], eps=log_eps)
        p_s = sanitize_q(p[support], eps=log_eps)

        # gradient wrt q: use helper
        g = self_grad_wrt_q(q_s, p_s, log_eps)
        # clip extreme values
        g = np.clip(g, -config.gradient_clip, config.gradient_clip)

        grad[support] = alpha * g

    return grad


def compute_alignment_gradient(
    agent_i,
    agents: list,
    dist_field: str,
    phi_field: str,
    params: dict
) -> np.ndarray:
    """
    Compute gradient of alignment KL sum_j D_KL(q_i || Ω_{ij} q_j) w.r.t. q_i.
    Uses ∂/∂q D_KL(q||r) = log(q/r) + 1, summed over neighbors.
    """
    # Hyperparameters
    align_weight = params.get("beta", config.beta)
    overlap_eps  = params.get("overlap_eps", config.overlap_eps)
    log_eps      = params.get("log_eps", config.log_eps)
    clip_val     = params.get("phi_diff_clip", getattr(config, "phi_diff_clip", 5.0))

    dist_i    = getattr(agent_i, dist_field)
    phi_i     = getattr(agent_i, phi_field)
    mask_i    = getattr(agent_i, "mask")
    support_i = mask_i > overlap_eps

    grad = np.zeros_like(dist_i)
    if align_weight <= 0 or not support_i.any():
        return grad

    gens = get_generators(config.group_name, config.K)

    for nb in agent_i.neighbors:
        j = nb["id"]
        agent_j = agents[j]
        mask_j  = getattr(agent_j, "mask") > overlap_eps

        # overlapping support
        overlap = support_i & mask_j
        if not overlap.any():
            continue

        # phase difference (clipped)
        r = phi_i[overlap] - getattr(agent_j, phi_field)[overlap]
        r = np.clip(r, -clip_val, clip_val)
        if r.ndim == 1:
            r = r[None, :]

        # transport q_j into i's frame
        qj = sanitize_q(getattr(agent_j, dist_field)[overlap], eps=log_eps)
        omega = exp_lie_algebra_irrep(r, gens)
        qj_rot = batch_apply_omega(qj, omega)
        qj_rot = repair_if_forgotten_batch(qj_rot, eps=log_eps)
        qj_rot = sanitize_q(qj_rot, eps=log_eps)

        # compute gradient contribution: log(q_i/qj_rot) + 1
        qi = sanitize_q(dist_i[overlap], eps=log_eps)
        g  = np.log(qi / qj_rot) + 1.0
        g  = np.clip(g, -config.gradient_clip, config.gradient_clip)

        # vectorized add into grad
        coords = np.nonzero(overlap)
        grad[coords] += align_weight * g

    return grad


# The wrapper functions compute_beliefs_gradient and compute_models_gradient
# unchanged, but now pass params dict to the above functions:

def compute_beliefs_gradient(agent_i, agents, params):
    return (
        compute_self_gradient(agent_i, "q", "p", "mask", params)
      + compute_alignment_gradient(agent_i, agents, "q", "phi", params)
    )


def compute_models_gradient(agent_i, agents, params):
    # transport-alignment gradient w.r.t. p
    align_p = compute_alignment_gradient(agent_i, agents, "p", "phi_model", params)
    # self-gradient w.r.t. p using self_grad_wrt_p
    q = getattr(agent_i, "q")
    p = getattr(agent_i, "p")
    mask = getattr(agent_i, "mask")
    cutoff = params.get("support_cutoff_eps", config.support_cutoff_eps)
    support = mask > cutoff

    grad_p = np.zeros_like(p)
    if params.get("alpha", config.alpha) > 0 and support.any():
        log_eps = params.get("log_eps", config.log_eps)
        q_s = sanitize_q(q[support], eps=log_eps)
        p_s = sanitize_q(p[support], eps=log_eps)
        g_self_p = self_grad_wrt_p(q_s, p_s, log_eps)
        grad_p[support] = np.clip(g_self_p, -config.gradient_clip, config.gradient_clip) * params.get("alpha", config.alpha)

    return align_p + grad_p


def compute_phi_alignment_gradient(agent_i, agents, params):
    """
    Gradient of the phase alignment term
      sum_j D_KL(q_i || Ω_{ij} q_j)
    w.r.t. the local phase field phi_i. Returns an array same shape as phi_i.
    """
    beta        = params.get("beta",        config.beta)
    log_eps     = params.get("log_eps",     config.log_eps)
    overlap_eps = params.get("overlap_eps", config.overlap_eps)
    clip_val    = params.get("phi_diff_clip", getattr(config, "phi_diff_clip", 5.0))

    if beta <= 0:
        return np.zeros_like(agent_i.phi)

    gens    = get_generators(config.group_name, config.K)  # (dim_G, K, K)
    phi_i   = agent_i.phi                                  # (..., dim_G)
    q_i     = sanitize_q(agent_i.q, eps=log_eps)           # (..., K)
    support = agent_i.mask > overlap_eps                   # boolean mask

    delta_phi = np.zeros_like(phi_i)                       # (..., dim_G)

    for nb in agent_i.neighbors:
        j         = nb["id"]
        agent_j   = agents[j]
        support_j = agent_j.mask > overlap_eps
        overlap   = support & support_j
        if not overlap.any():
            continue

        # get flat indices of overlap
        coords = np.nonzero(overlap)  # tuple of index arrays

        # compute clipped phase differences
        r_vecs = phi_i[coords] - agent_j.phi[coords]      # (N, dim_G)
        r_vecs = np.clip(r_vecs, -clip_val, clip_val)

        # transport q_j into i frame
        qj = sanitize_q(agent_j.q[coords], eps=log_eps)   # (N, K)
        Ω   = exp_lie_algebra_irrep(r_vecs, gens)         # (N, K, K)
        qj_rot = batch_apply_omega(qj, Ω)                 # (N, K)
        qj_rot = repair_if_forgotten_batch(qj_rot, eps=log_eps)
        qj_rot = sanitize_q(qj_rot, eps=log_eps)

        # compute local difference
        qi   = q_i[coords]                                # (N, K)
        diff = qi - qj_rot                                # (N, K)

        # compute dΩg[n,i,a,k] = Ω[n,i,j] * G[a,j,k]
        dΩg = np.einsum('nij,ajk->niak', Ω, gens)         # (N, K, dim_G, K)
        # contract with qj to get dΩq[n,i,a] = sum_k dΩg[n,i,a,k] * qj[n,k]
        dΩq = np.einsum('niak,nk->nia', dΩg, qj)          # (N, K, dim_G)
        # finally inner‐product with diff: grads[n,a] = sum_i dΩq[n,i,a] * diff[n,i]
        grads = np.einsum('nia,ni->na', dΩq, diff)        # (N, dim_G)

        # normalize by overlap size, clip & scale
        N = coords[0].size
        grads = (beta / (N + log_eps)) * np.clip(grads,
                                                 -config.gradient_clip,
                                                 config.gradient_clip)

        # accumulate back into delta_phi
        delta_phi[coords + (slice(None),)] += grads

    return delta_phi


def compute_phi_model_update(agent_i, agents, params):
    """
    Compute gradient of model‐phase alignment term
      sum_j D_KL(p_i || Ω_{ij} p_j)
    w.r.t. the model‐phase field phi_model_i.
    """
    beta_tilde   = params.get("beta_tilde", config.model_align_weight)
    log_eps      = params.get("log_eps", config.log_eps)
    overlap_eps  = params.get("overlap_eps", config.overlap_eps)
    clip_val     = params.get("phi_diff_clip", getattr(config, "phi_diff_clip", 5.0))

    if beta_tilde <= 0:
        return np.zeros_like(agent_i.phi_model)

    gens        = get_generators(config.group_name, config.K)  # (dim_G, K, K)
    phi_model   = agent_i.phi_model                             # (..., dim_G)
    p_full      = sanitize_q(agent_i.p, eps=log_eps)            # (..., K)
    support_i   = agent_i.mask > overlap_eps                    # boolean mask

    delta_phi = np.zeros_like(phi_model)

    for nb in agent_i.neighbors:
        j         = nb["id"]
        agent_j   = agents[j]
        support_j = agent_j.mask > overlap_eps
        overlap   = support_i & support_j
        if not overlap.any():
            continue

        coords    = np.nonzero(overlap)                         # tuple of arrays
        # Clipped phase differences
        r_vecs    = phi_model[coords] - agent_j.phi_model[coords]  
        r_vecs    = np.clip(r_vecs, -clip_val, clip_val)        # (N, dim_G)

        # Transport p_j into i’s frame
        pj_vecs   = sanitize_q(agent_j.p[coords], eps=log_eps)  # (N, K)
        omega     = exp_lie_algebra_irrep(r_vecs, gens)         # (N, K, K)
        pj_rot    = batch_apply_omega(pj_vecs, omega)           # (N, K)
        pj_rot    = repair_if_forgotten_batch(pj_rot, eps=log_eps)
        pj_rot    = sanitize_q(pj_rot, eps=log_eps)

        pi_vecs   = p_full[coords]                               # (N, K)
        diff      = pi_vecs - pj_rot                             # (N, K)

        # Compute dΩg[n,i,a,k] = Ω[n,i,j] * G[a,j,k]
        dΩg       = np.einsum('nij,ajk->niak', omega, gens)     # (N, K, dim_G, K)
        # Contract with pj_vecs to get dΩp[n,i,a] = sum_k dΩg[n,i,a,k] * pj_vecs[n,k]
        dΩp       = np.einsum('niak,nk->nia', dΩg, pj_vecs)     # (N, K, dim_G)
        # Inner‐product with diff: grads[n,a] = -sum_i dΩp[n,i,a] * diff[n,i]
        grads     = -np.einsum('nia,ni->na', dΩp, diff)         # (N, dim_G)

        # Normalize by overlap size, clip & scale
        N         = coords[0].size
        grads     = (beta_tilde / (N + log_eps)) * np.clip(
                        grads, -config.gradient_clip, config.gradient_clip
                    )                                         # (N, dim_G)

        # Scatter-add into delta_phi
        delta_phi[coords + (slice(None),)] += grads            # accumulate

    return delta_phi
