import numpy as np
from config import K, phi_clip_threshold, beta, phi_clip_threshold, log_eps
from scipy.ndimage import sobel
from scipy.linalg import expm
import config
from get_generators import get_generators


def repair_if_forgotten(q: np.ndarray, eps: float, threshold: float = 1e-6) -> np.ndarray:
    """
    If a belief vector q has near-zero total mass, inject small uniform mass
    so that belief learning can resume.

    Parameters:
        q         : (K,) belief vector
        eps       : small clipping constant
        threshold : total mass threshold to trigger repair

    Returns:
        q_repaired : repaired or original belief vector
    """
    total_mass = np.sum(q)
    if total_mass < threshold or not np.isfinite(total_mass):
        K = q.shape[-1]
        q = np.random.dirichlet(np.ones(K)) * eps * K
    else:
        q = np.clip(q, eps, 1.0)
        q /= np.sum(q) + eps
    return q


def repair_if_forgotten_batch(q: np.ndarray, eps: float, threshold: float = 1e-6) -> np.ndarray:
    """
    Repair a batch of belief vectors where some may have near-zero total mass.

    Parameters:
        q         : (..., K) array of belief vectors
        eps       : small floor value (e.g., config.log_eps)
        threshold : total mass below which a vector is considered "forgotten"

    Returns:
        q_repaired : repaired batch, same shape as q
    """
    q = np.nan_to_num(q, nan=0.0, posinf=0.0, neginf=0.0)
    orig_shape = q.shape
    K = q.shape[-1]
    q_flat = q.reshape(-1, K)
    norms = np.sum(q_flat, axis=-1, keepdims=True)

    forgotten = (norms < threshold) | (~np.isfinite(norms))

    if np.any(forgotten):
        n_forgotten = np.sum(forgotten)
        repaired = np.random.dirichlet(np.ones(K), size=n_forgotten) * eps * K
        q_flat[forgotten.squeeze()] = repaired

    q_flat = np.clip(q_flat, eps, 1.0)
    q_flat /= np.sum(q_flat, axis=-1, keepdims=True) + eps
    return q_flat.reshape(orig_shape)

def kl_divergence(q1, q2, eps=1e-12):
    q1 = np.clip(q1, eps, 1.0)
    q2 = np.clip(q2, eps, 1.0)
    return np.sum(q1 * (np.log(q1) - np.log(q2)), axis=-1)

def adaptive_expm(G, max_norm=20):
     """
     Matrix exponential with adaptive scaling and squaring for numerical stability.
     """
     # use the Frobenius norm so we can handle batches of matrices
     norm_G = np.linalg.norm(G)
     if norm_G <= max_norm:
         return expm(G)
     else:
         s = int(np.ceil(norm_G / max_norm))
         G_scaled = G / s
         exp_G_scaled = expm(G_scaled)
         result = exp_G_scaled
         for _ in range(s - 1):
             result = result @ exp_G_scaled
         return result

def exp_lie_algebra_operator(
    v,
    generators,
    use_expm=True,
    threshold=1e-3,
    max_norm=20,
):
    """
    Compute exp(Σ_a v_a T_a) in arbitrary Lie algebra representation
    using adaptive scaling/squaring or Taylor approximation.

    Parameters:
    - v: np.ndarray shape (dim_G,), Lie algebra coefficients
    - generators: np.ndarray shape (dim_G, K, K), generators for Lie algebra rep
    - use_expm: bool, whether to use adaptive_expm for large norms
    - threshold: float, below which to use 2nd-order Taylor approx
    - max_norm: float, maximum allowed norm of the exponent
    """
    # 1) compute norm and guard against zero
    norm_v = np.linalg.norm(v)
    eps = 1e-16
    safe_norm = norm_v + eps

    # 2) scale v down if needed
    scale = min(1.0, max_norm / safe_norm)
    v_scaled = v * scale

    # 3) build the Lie‐algebra element
    G = np.einsum('a,aij->ij', v_scaled, generators)

    # 4) choose Taylor vs expm
    if safe_norm < threshold or not use_expm:
        I = np.eye(G.shape[0])
        return I + G + 0.5 * (G @ G)
    else:
        # use your adaptive_expm for stability
        return adaptive_expm(G, max_norm=max_norm)


def exp_lie_algebra_irrep(v, generators, use_expm=True, threshold=1e-3, max_norm=20):
    """
    Compute exp(Σ v_a T_a) in specified representation.
    v: (..., dim_G) array of Lie algebra coefficients
    generators: (dim_G, K, K)
    """
    norm_v = np.linalg.norm(v, axis=-1)               # shape (...,)
    eps    = 1e-16
    safe   = norm_v[..., None] + eps                  # avoids div-by-zero
    # build a per-element scale factor: clamp to [0,1]
    scale  = np.where(norm_v[..., None] > max_norm,
                      max_norm / safe,
                      1.0)
    v_scaled = v * scale

    # now build G and the rest is unchanged...
    G = np.einsum('...a,aij->...ij', v_scaled, generators)

    approx_mask = norm_v < threshold
    result = np.empty_like(G)
    if np.any(approx_mask):
        I          = np.eye(G.shape[-1])
        G_approx   = G[approx_mask]
        G2         = G_approx @ G_approx
        result[approx_mask] = I + G_approx + 0.5 * G2

    if np.any(~approx_mask):
        idxs = np.nonzero(~approx_mask)[0]
        for i in idxs:
            result[i] = adaptive_expm(G[i], max_norm=max_norm)

    return result

def batch_exp_lie_algebra_irrep(
    v_batch,
    generators,
    use_expm=True,
    threshold=1e-3,
    max_norm=20,
):
    """
    Compute batch of exp(sum_a v_batch[a] * T_a) where T_a are Lie algebra generators
    in a K-dimensional representation.

    Parameters:
    - v_batch: np.ndarray shape (..., dim_G), batch of Lie algebra coefficient vectors
    - generators: np.ndarray shape (dim_G, K, K), Lie algebra generators in chosen rep
    - use_expm: bool, whether to use adaptive_expm for large norms
    - threshold: float, below which use Taylor approx instead of expm
    - max_norm: float, max norm for scaling vectors to avoid numerical issues

    Returns:
    - result: np.ndarray shape (..., K, K), batch of group elements in rep
    """
    *batch_shape, dim_G = v_batch.shape
    v_flat = v_batch.reshape(-1, dim_G)
    N = v_flat.shape[0]
    _, K, _ = generators.shape

    # 1) compute norms and safe scale factors
    norms = np.linalg.norm(v_flat, axis=1)                       # shape (N,)
    eps = 1e-16
    scale_factors = np.minimum(1.0, max_norm / (norms + eps))    # avoid div-zero
    v_scaled = v_flat * scale_factors[:, None]                   # shape (N, dim_G)

    # 2) build Lie-algebra elements in batch
    G_batch = np.einsum('na,aij->nij', v_scaled, generators)     # shape (N, K, K)

    # 3) norms after scaling for Taylor masking
    norms_scaled = norms * scale_factors

    # 4) allocate output
    result = np.zeros((N, K, K), dtype=np.float64)

    # 5) Taylor approx for small norms
    approx_mask = norms_scaled < threshold
    if np.any(approx_mask):
        G_approx = G_batch[approx_mask]                          # shape (M, K, K)
        I_batch = np.eye(K)[None, :, :]                          # shape (1, K, K)
        G2 = G_approx @ G_approx
        G3 = G2 @ G_approx
        G4 = G3 @ G_approx
        G5 = G4 @ G_approx

        result[approx_mask] = (
            I_batch +
            G_approx +
            0.5 * G2 +
            (1.0 / 6.0)  * G3 +
            (1.0 / 24.0) * G4 +
            (1.0 / 120.0)* G5
        )

    # 6) adaptive_expm for the rest
    if np.any(~approx_mask):
        if use_expm:
            idxs = np.nonzero(~approx_mask)[0]
            for idx in idxs:
                result[idx] = adaptive_expm(G_batch[idx], max_norm=max_norm)
        else:
            raise RuntimeError("Large norm vectors require use_expm=True")

    # 7) reshape back to original batch shape
    return result.reshape(*batch_shape, K, K)


def batch_apply_omega(q_batch, omega_batch):
    """
    Apply a batch of group elements Ω to a batch of belief vectors q.

    Args:
        q_batch: np.ndarray with shape (..., K)
        omega_batch: np.ndarray with shape (..., K, K), must broadcast with q_batch

    Returns:
        Transformed batch: np.ndarray with shape (..., K)
    """
    # Validate batch dimensions match except for last dims
    assert q_batch.shape[-1] == omega_batch.shape[-2] == omega_batch.shape[-1], (
        f"Dimension mismatch: q_batch last dim {q_batch.shape[-1]} != "
        f"omega_batch last dims {omega_batch.shape[-2:]}"
    )

    # Use einsum to contract last dim of q_batch with last dim of omega_batch
    return np.einsum('...ij,...j->...i', omega_batch, q_batch)


def apply_omega(q_vec, omega):
    """
    Apply a single group matrix Ω to a belief vector or batch of vectors q_vec.

    Args:
        q_vec: np.ndarray with shape (K,) or (..., K)
        omega: np.ndarray with shape (K, K)

    Returns:
        Transformed vector(s) with shape same as q_vec
    """
    assert omega.shape[0] == omega.shape[1], "Omega must be square"
    assert q_vec.shape[-1] == omega.shape[0], (
        f"Dimension mismatch: q_vec last dim {q_vec.shape[-1]} != omega shape {omega.shape}"
    )

    # Contract last dim of q_vec with omega
    return np.einsum('ij,...j->...i', omega, q_vec)


def compute_gauge_potential(phi):
    """
    Compute gauge potentials A_μ^a = ∂_μ φ^a for arbitrary Lie algebra and base dimension D.
        BE CAREFUL! CANNOT PASS THIS OUTPUT INTO COMMUTATOR WITHOUT CONVERTING
    Args:
        phi: np.ndarray, shape (..., d), where
             ... represents spatial dimensions (S_1,...,S_D),
             d = dim Lie algebra.

    Returns:
        A: tuple of length D, each entry np.ndarray of shape (..., d),
           spatial derivatives of phi along each base manifold dimension.
    """
    D = phi.ndim - 1  # subtract Lie algebra dimension axis
    spatial_axes = tuple(range(D))
    A = tuple(np.gradient(phi, axis=axis) for axis in spatial_axes)
    return A


def compute_commutator(A_mu, A_nu):
    """
    Compute matrix commutator [A_μ, A_ν] = A_μ A_ν - A_ν A_μ for batch matrices.

    Args:
        A_mu, A_nu: np.ndarray with shape (..., K, K)

    Returns:
        commutator: np.ndarray with shape (..., K, K)
    """
    return np.matmul(A_mu, A_nu) - np.matmul(A_nu, A_mu)


def compute_field_strength(phi, generators):
    """
    Compute curvature tensors F_{μν} = ∂_μ A_ν - ∂_ν A_μ + [A_μ, A_ν]
    for all μ < ν, where φ is the gauge field and generators specify
    the Lie algebra representation.

    Args:
        phi: np.ndarray of shape (S_1,...,S_D, d), gauge field components
        generators: np.ndarray of shape (d, K, K), Lie algebra generators

    Returns:
        curvature_norms: dict mapping (mu, nu) -> np.ndarray of shape (S_1,...,S_D)
                         scalar Frobenius norm of curvature tensor F_{μν}
    """
    D = phi.ndim - 1
    A = compute_gauge_potential(phi)  # tuple length D, each (..., d)

    # Project each A_μ from (..., d) to (..., K, K)
    A_matrices = [np.einsum('...a,aij->...ij', A_mu, generators) for A_mu in A]

    curvature_norms = {}

    for mu in range(D):
        for nu in range(mu + 1, D):
            # Partial derivatives of A_nu and A_mu along directions mu and nu
            dA_nu_dmu = np.gradient(A_matrices[nu], axis=mu)
            dA_mu_dnu = np.gradient(A_matrices[mu], axis=nu)

            # Commutator [A_mu, A_nu]
            comm = compute_commutator(A_matrices[mu], A_matrices[nu])

            F_munu = dA_nu_dmu - dA_mu_dnu + comm

            # Optional numerical clipping and NaN/Inf checks
            F_munu = np.clip(F_munu, -1e6, 1e6)
            if np.any(np.isnan(F_munu)) or np.any(np.isinf(F_munu)):
                print(f"[WARNING] Curvature tensor F_{{{mu},{nu}}} contains NaN or Inf.")

            # Frobenius norm over last two dims (K x K matrix)
            curvature_norms[(mu, nu)] = np.linalg.norm(F_munu, axis=(-2, -1))

    return curvature_norms

def build_inter_agent_omega(phi_i, phi_j, generators, config=None, use_commutator=False):
    """
    Compute the inter-agent gauge transport operator field Ω_{ij}(x) for full φ fields.

    Parameters:
        phi_i: np.ndarray shape (..., d) — φ_i field over spatial domain
        phi_j: np.ndarray shape (..., d) — φ_j field over spatial domain
        generators: np.ndarray shape (d, K, K) — Lie algebra generators
        config: optional config object to override use_commutator
        use_commutator: bool — if True, use exp(φ_i - φ_j); else use exp(φ_i) @ exp(-φ_j)

    Returns:
        omega_ij: np.ndarray shape (..., K, K) — inter-agent transport operator at each point
    """
    # override via config flag if set
    if config is not None:
        use_commutator = getattr(config, "use_commutator", use_commutator)

    # coefficient difference field, shape (..., d)
    delta = phi_i - phi_j

    if use_commutator:
        # exponentiate the difference directly
        return exp_lie_algebra_irrep(delta, generators)  # (..., K, K)

    # otherwise exponentiate each field separately and multiply
    g_i     = exp_lie_algebra_irrep(phi_i, generators)       # (..., K, K)
    g_j_inv = exp_lie_algebra_irrep(-phi_j, generators)      # (..., K, K)
    # broadcasted matmul over leading dims
    return np.matmul(g_i, g_j_inv)                           # (..., K, K)
