

def plot_master_summary(master_csv, out_dir='holonomy_plots'):
    import os, pandas as pd, matplotlib.pyplot as plt
    df = pd.read_csv(master_csv)
    os.makedirs(out_dir, exist_ok=True)
    for metric in [
        'curvature_norm',
        'curvature_logm',
        'det_minus1',
        'trace',
        'cond',
        'chordal',
        'loop_length'
    ]:
        plt.figure(figsize=(8,5))
        for exp in df['experiment'].unique():
            df_sub = df[df['experiment'] == exp]
            avg = df_sub.groupby('param')[metric].mean()
            plt.plot(avg.index, avg.values, marker='o', label=exp)
        plt.xlabel('Parameter (size or cycle)')
        plt.ylabel(metric)
        plt.title(f'Average {metric} vs. parameter')
        plt.xticks(rotation=45, ha='right')
        plt.legend()
        plt.tight_layout()
        plt.savefig(os.path.join(out_dir, f'{metric}_vs_param.png'))
        plt.close()

def plot_time_series_all(master_csv, out_dir='holonomy_timeseries'):
    import os, pandas as pd, matplotlib.pyplot as plt
    df = pd.read_csv(master_csv)
    os.makedirs(out_dir, exist_ok=True)
    metrics = [
        ('curvature_norm', 'Proxy ‖H−I‖'),
        ('curvature_logm','True ‖logm(H)‖'),
        ('det_minus1',    'det(H)−1'),
        ('trace',         'trace(H)'),
        ('cond',          'cond(H)'),
        ('chordal',       'Chordal dist'),
        ('loop_length',   'Loop length'),
    ]
    for exp in df['experiment'].unique():
        for param in df[df['experiment']==exp]['param'].unique():
            df_sub = df[(df['experiment']==exp)&(df['param'].astype(str)==str(param))].sort_values('step')
            plt.figure(figsize=(6,4))
            for key, label in metrics:
                if key in df_sub:
                    plt.plot(df_sub['step'], df_sub[key], label=label)
            plt.xlabel('Step')
            plt.ylabel('Value')
            plt.title(f'{exp} param={param}')
            plt.legend(loc='best', fontsize='small')
            plt.tight_layout()
            fname = f"{exp}_{param}_timeseries.png".replace(' ', '_')
            plt.savefig(os.path.join(out_dir, fname))
            plt.close()


if __name__ == '__main__':
    import os
    # path to the master CSV produced by holonomy_experiments.py
    master_csv = os.path.join('holonomy_experiments', 'master_summary.csv')
    
    # 1) plot averages vs. parameter
    plot_master_summary(master_csv, out_dir='holonomy_plots')
    
    # 2) plot per‐step time series for each (experiment, param)
    plot_time_series_all(master_csv, out_dir='holonomy_timeseries')


