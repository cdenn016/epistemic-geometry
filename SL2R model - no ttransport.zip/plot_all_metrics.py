# plot_all_metrics_from_log.py

import os
import pickle
import matplotlib.pyplot as plt

def load_metric_log(path="checkpoints/metric_log.pkl"):
    if not os.path.exists(path):
        raise FileNotFoundError(f"No metric log found at {path}")
    with open(path, "rb") as f:
        return pickle.load(f)

def plot_metrics_over_time(metric_log):
    if not metric_log:
        print("Empty metric log.")
        return

    steps = [entry["step"] for entry in metric_log]
    keys = [k for k in metric_log[0].keys() if k != "step"]

    for key in keys:
        values = [entry[key] for entry in metric_log]

        # --- Scalar values ---
        if not isinstance(values[0], dict):
            plt.figure(figsize=(8, 4))
            plt.plot(steps, values, label=key)
            plt.xlabel("Step")
            plt.ylabel(key)
            plt.title(f"{key} Over Time")
            plt.grid(True)
            plt.tight_layout()
            plt.legend()
            plt.show()

        # --- Nested dictionary values ---
        elif isinstance(values[0], dict):
            subkeys = values[0].keys()
            for subkey in subkeys:
                subvalues = [v[subkey] for v in values]
                plt.figure(figsize=(8, 4))
                plt.plot(steps, subvalues, label=subkey)
                plt.xlabel("Step")
                plt.ylabel(subkey)
                plt.title(f"{key}.{subkey} Over Time")
                plt.grid(True)
                plt.tight_layout()
                plt.legend()
                plt.show()

        else:
            print(f"[WARNING] Skipped unrecognized metric type for key: {key}")

if __name__ == "__main__":
    log = load_metric_log("checkpoints/metric_log.pkl")
    plot_metrics_over_time(log)
