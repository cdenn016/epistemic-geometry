# -*- coding: utf-8 -*-
"""
Created on Fri Jun 13 17:17:51 2025

@author: chris and christine
"""

import multiprocessing
import os
import time
import pickle
from joblib import Parallel, delayed

from config import (
    set_config_from_params, agent_seed, steps, N, eta_phi
)
from agent_init_phi_smoothed import initialize_agents
from io_utils import load_checkpoint, save_step, find_resume_step
from update_rules import update_beliefs, update_models, update_phi, update_phi_model
from diagnostics_metrics import log_all_metrics
import config

# Use all available cores
num_cores = -1


def run_simulation(outdir="checkpoints", resume=True, log_metrics=True, **params):
    set_config_from_params(params)

    print(f"[SWEEP PARAMS] alpha={config.alpha}, beta={config.beta}, gamma={config.gamma}, "
          f"cw={config.curvature_weight}, gw={config.gauge_weight}")

    os.makedirs(outdir, exist_ok=True)

    # --- Initialization or resume ---
    if resume:
        agents, file_loaded = load_checkpoint(outdir)
        if agents is not None:
            step_start = find_resume_step(outdir)
            print(f"[RESUME] Loaded: {file_loaded}, resuming from step {step_start}")
        else:
            print("[INIT] No previous checkpoint found — fresh start")
            step_start = 0
            agents = initialize_agents(seed=agent_seed)
            save_step(agents, outdir, step_start)
    else:
        print("[INIT] Starting new simulation (resume=False)")
        step_start = 0
        agents = initialize_agents(seed=agent_seed, phi_init=params.get("phi_init", None))
        save_step(agents, outdir, step_start)

    metric_log = []

    # --- Main loop ---
    for step in range(step_start, steps):
        print(f"\n[STEP {step}] -----------------------------")

        # Belief updates
        t1 = time.time()
        agents = Parallel(n_jobs=num_cores, backend="loky")(
            delayed(update_beliefs)(i, agents, params) for i in range(N)
        )
        print(f"[TIMING] update_beliefs:    {time.time() - t1:.3f}s")

        # Model updates
        t2 = time.time()
        agents = Parallel(n_jobs=num_cores, backend="loky")(
            delayed(update_models)(i, agents, params) for i in range(N)
        )
        print(f"[TIMING] update_models:     {time.time() - t2:.3f}s")

        # φ belief update
        t3 = time.time()
        agents = Parallel(n_jobs=num_cores, backend="loky")(
            delayed(update_phi)(i, agents, eta_phi, params) for i in range(N)
        )
        print(f"[TIMING] update_phi:        {time.time() - t3:.3f}s")

        # φ_model update
        t4 = time.time()
        agents = Parallel(n_jobs=num_cores, backend="loky")(
            delayed(update_phi_model)(i, agents, eta_phi, params) for i in range(N)
        )
        print(f"[TIMING] update_phi_model:  {time.time() - t4:.3f}s")

        # Save state
        save_step(agents, outdir, step)

        if log_metrics:
            metrics = log_all_metrics(agents, step)
            metric_log.append(metrics)

    print("[DONE] Simulation completed.")

    if log_metrics:
        with open(os.path.join(outdir, "metric_log.pkl"), "wb") as f:
            pickle.dump(metric_log, f)
        print("[INFO] Saved metric_log.pkl")


if __name__ == "__main__":
    run_simulation()
