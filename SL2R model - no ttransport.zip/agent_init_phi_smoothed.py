import numpy as np
import matplotlib.pyplot as plt
from scipy.ndimage import gaussian_filter

from config import (
    domain_size, K, N,
    psi_radius_range,
    q_mu_range, q_sigma_range,
    p_mu_range, p_sigma_range,
    mu_field_smooth_range, sigma_field_smooth_range,
    overlap_eps, max_neighbors,
    support_cutoff_eps,
    phi_model_offset,
    similar_p_models, mask_sharpness
)

from agent_schema import Agent

def generate_soft_mask(center, radius, grid_shape, sharpness=1.5):
    cx, cy = center
    H, W = grid_shape
    x = np.arange(H)[:, None]
    y = np.arange(W)[None, :]

    dx = np.minimum(np.abs(x - cx), H - np.abs(x - cx))
    dy = np.minimum(np.abs(y - cy), W - np.abs(y - cy))

    dist_sq = dx**2 + dy**2
    sigma_sq = (radius / sharpness)**2
    mask = np.exp(-dist_sq / (2 * sigma_sq)).astype(np.float32)
    mask[mask < 1e-6] = 0.0
    return mask

def smooth_random_field(shape, rng, sigma=5):
    field = rng.uniform(0, 1, size=shape)
    return gaussian_filter(field, sigma=sigma)

def scale_to_range(field, new_range):
    min_val, max_val = np.min(field), np.max(field)
    a, b = new_range
    return a + (field - min_val) / (max_val - min_val + 1e-8) * (b - a)

def initialize_agents(seed=None, visualize=False, phi_init=None):
    import inspect
    print(inspect.stack()[1].filename)

    rng = np.random.default_rng(seed)
    if phi_init is None:
        from config import phi_init as default_phi_init
        phi_init = default_phi_init
        print(f"[DEBUG] Using phi_init = {phi_init}")

    agents = []

    for n in range(N):
        radius = rng.uniform(*psi_radius_range)
        center = rng.integers(0, domain_size[0]), rng.integers(0, domain_size[1])
        mask = generate_soft_mask(center, radius, domain_size)
        mask[mask < support_cutoff_eps] = 0.0

        mu_smooth_q = rng.uniform(*mu_field_smooth_range)
        sigma_smooth_q = rng.uniform(*sigma_field_smooth_range)
        mu_smooth_p = rng.uniform(*mu_field_smooth_range)
        sigma_smooth_p = rng.uniform(*sigma_field_smooth_range)

        mu_q_field = scale_to_range(smooth_random_field(domain_size, rng, sigma=mu_smooth_q), q_mu_range)
        sigma_q_field = scale_to_range(smooth_random_field(domain_size, rng, sigma=sigma_smooth_q), q_sigma_range)

        if similar_p_models:
            base_mu_p = rng.uniform(*p_mu_range)
            base_sigma_p = rng.uniform(*p_sigma_range)
            mu_p_field = np.full(domain_size, base_mu_p, dtype=np.float32)
            sigma_p_field = np.full(domain_size, base_sigma_p, dtype=np.float32)
        else:
            mu_p_field = scale_to_range(smooth_random_field(domain_size, rng, sigma=mu_smooth_p), p_mu_range)
            sigma_p_field = scale_to_range(smooth_random_field(domain_size, rng, sigma=sigma_smooth_p), p_sigma_range)

        x = np.arange(K).reshape(1, 1, -1)
        mu_q = mu_q_field[..., None]
        sigma_q = sigma_q_field[..., None]
        q_unnorm = np.exp(-0.5 * ((x - mu_q) / sigma_q)**2)
        q = q_unnorm / (np.sum(q_unnorm, axis=-1, keepdims=True) + 1e-8)
        q *= mask[..., None]

        mu_p = mu_p_field[..., None]
        sigma_p = sigma_p_field[..., None]
        p_unnorm = np.exp(-0.5 * ((x - mu_p) / sigma_p)**2)
        p = p_unnorm / (np.sum(p_unnorm, axis=-1, keepdims=True) + 1e-8)
        p *= mask[..., None]

        phi_raw = gaussian_filter(rng.normal(scale=phi_init, size=(*domain_size, 3)), sigma=5).astype(np.float32)
        phi_masked = phi_raw * mask[..., None]

        phi_model_raw = phi_raw + rng.normal(scale=phi_model_offset, size=(*domain_size, 3)).astype(np.float32)
        phi_model_raw = gaussian_filter(phi_model_raw, sigma=5)

        phi_model_masked = phi_model_raw * mask[..., None]

        agent = Agent(
            id=n,
            center=center,
            radius=radius,
            mask=mask,
            q=q,
            p=p,
            mu_q_field=mu_q_field,
            sigma_q_field=sigma_q_field,
            mu_p_field=mu_p_field,
            sigma_p_field=sigma_p_field,
            phi=phi_masked,
            phi_model=phi_model_masked,
            neighbors=[]
        )
        agents.append(agent)

        if visualize:
            fig, axs = plt.subplots(2, 3, figsize=(12, 8))
            axs[0, 0].imshow(mask, cmap='gray')
            axs[0, 0].set_title(f"Agent {n} Soft Mask")
            axs[0, 1].imshow(mu_q_field * mask, cmap='viridis')
            axs[0, 1].set_title("mu_q(c)")
            axs[0, 2].imshow(sigma_q_field * mask, cmap='plasma')
            axs[0, 2].set_title("sig_q(c)")
            axs[1, 0].imshow(mu_p_field * mask, cmap='viridis')
            axs[1, 0].set_title("mu_p(c)")
            axs[1, 1].imshow(sigma_p_field * mask, cmap='plasma')
            axs[1, 1].set_title("sig_p(c)")
            axs[1, 2].axis('off')
            plt.tight_layout()
            plt.show()

    for i, agent_i in enumerate(agents):
        mask_i = agent_i.mask
        overlaps = []
        for j, agent_j in enumerate(agents):
            if i == j:
                continue
            mask_j = agent_j.mask
            overlap = (mask_i * mask_j) > overlap_eps
            if np.any(overlap):
                overlaps.append((j, np.sum(overlap)))
        overlaps.sort(key=lambda x: -x[1])
        neighbors = [{"id": j} for j, _ in overlaps[:max_neighbors]]
        agent_i.neighbors = neighbors

    return agents
