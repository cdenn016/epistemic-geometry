# -*- coding: utf-8 -*-
"""
Created on Fri Jun 13 17:15:21 2025

@author: chris and christine
"""

# sl2r_generators.py

import numpy as np

_generator_cache = {}

def get_generators(K):
    """
    Return cached or freshly computed SL(2,R) real-valued generators:
    (L1, L2, L3, generators) where generators has shape (3, K, K)

    These correspond to:
        L1 = 1/2 * [[0, 1], [1, 0]]
        L2 = 1/2 * [[0, -1], [1, 0]]
        L3 = 1/2 * [[1, 0], [0, -1]]
    in 2D, generalized to arbitrary odd K (spin-ℓ reps).
    """
    if K in _generator_cache:
        return _generator_cache[K]

    l = (K - 1) // 2
    m = np.arange(-l, l + 1)

    L1 = np.zeros((K, K))
    L2 = np.zeros((K, K))
    L3 = np.diag(m)

    for i in range(K - 1):
        c = 0.5 * np.sqrt((l - m[i]) * (l + m[i] + 1))
        L1[i, i+1] = L1[i+1, i] = c
        L2[i, i+1] = -c
        L2[i+1, i] = c

    generators = np.stack([L1, L2, L3], axis=0)
    _generator_cache[K] = (L1, L2, L3, generators)
    return _generator_cache[K]
