# diagnostics_metrics.py

import numpy as np
from scipy.ndimage import laplace
from sl2r_generators import get_generators

from omega_operator import (
    get_generators,
    kl_divergence,
    exp_sl2r_irrep,
    batch_exp_sl2r_irrep,
    apply_omega,
    batch_apply_omega,
    compute_gauge_potential,
    compute_field_strength,
    compute_sl2r_commutator,
    compute_sl2r_curvature
)


from config import (
    log_eps, overlap_eps, support_cutoff_eps, K
)

import config
# Prepare Sl2r generators for Ω construction
_, _, _, generators = get_generators(K)  # Only use stacked generators (3, K, K)


def compute_total_energy(agents):
    """
    Computes total variational energy and components:
    - KL(q || p)
    - KL(q || Ω q)
    - Laplacian energy on φ
    - Curvature energy on φ
    """
    E_kl = 0.0
    E_align = 0.0
    E_lap = 0.0
    E_curv = 0.0

    for agent_i in agents:
        mask_i = agent_i.mask > support_cutoff_eps
        q_i = np.clip(agent_i.q, log_eps, 1.0)
        p_i = np.clip(agent_i.p, log_eps, 1.0)
        phi_i = agent_i.phi

        # --- KL(q || p) ---
        D_kl = kl_divergence(q_i, p_i)  # shape (H, W)
        E_kl += config.alpha * np.sum(D_kl * mask_i)

        # --- KL(q || Ω q_j), only if beta > 0 ---
        if config.beta > 0:
            for neighbor in agent_i.neighbors:
                j = neighbor['id']
                agent_j = agents[j]
                q_j = np.clip(agent_j.q, log_eps, 1.0)
                phi_j = agent_j.phi
                mask_j = agent_j.mask

                overlap = (agent_i.mask * mask_j) > overlap_eps
                if not np.any(overlap):
                    continue

                r = phi_i - phi_j
                qj_rot = np.zeros_like(q_j)

                for x in range(r.shape[0]):
                    for y in range(r.shape[1]):
                        if overlap[x, y]:
                            omega = exp_sl2r_irrep(r[x, y], generators)
                            qj_rot[x, y] = apply_omega(q_j[x, y], omega)

                qj_rot = np.clip(qj_rot, log_eps, 1.0)
                qj_rot /= np.sum(qj_rot, axis=-1, keepdims=True) + log_eps

                D_align = kl_divergence(q_i, qj_rot)  # shape (H, W)
                E_align += config.beta * np.sum(D_align * overlap)

        # --- φ Laplacian term ---
        lap_phi = np.stack([laplace(phi_i[..., d]) for d in range(3)], axis=-1)
        E_lap += config.gamma * np.sum(np.linalg.norm(lap_phi, axis=-1) * mask_i)

        # --- Curvature F² term ---
        if config.curvature_weight > 0:
            F2 = compute_field_strength(phi_i)
            E_curv += config.curvature_weight * np.sum(F2 * mask_i)

    N = sum(np.sum(agent.mask > support_cutoff_eps) for agent in agents)
    return {
        "KL(q||p)": E_kl / N,
        "KL(q||Ωq)": E_align / N,
        "Laplacian(φ)": E_lap / N,
        "Curvature(F²)": E_curv / N,
        "Total": (E_kl + E_align + E_lap + E_curv) / N
    }

def compute_alignment_error(agents):
    """
    Computes KL(q_i || Ω_{ij} q_j) averaged over all overlapping agent pairs.
    """
    _, _, _, generators = get_generators(K)  # (3, K, K)



    total_error = 0.0
    count = 0

    for agent_i in agents:
        q_i = agent_i.q
        phi_i = agent_i.phi
        mask_i = agent_i.mask
        q_i_clipped = np.clip(q_i, log_eps, 1.0)

        for neighbor in agent_i.neighbors:
            j = neighbor['id']
            agent_j = agents[j]
            q_j = agent_j.q
            phi_j = agent_j.phi
            mask_j = agent_j.mask

            overlap = (mask_i * mask_j) > overlap_eps
            if not np.any(overlap):
                continue

            r = phi_i - phi_j
            qj_rot = np.zeros_like(q_j)

            for x in range(r.shape[0]):
                for y in range(r.shape[1]):
                    if not overlap[x, y]:
                        continue
                    omega = exp_sl2r_irrep(r[x, y], generators)
                    qj_rot[x, y] = apply_omega(q_j[x, y], omega)

            # Normalize safely on the overlap only
            sums = np.sum(qj_rot, axis=-1, keepdims=True)
            qj_rot = np.divide(qj_rot, sums + log_eps, out=qj_rot, where=sums > 0)
            qj_rot = np.clip(qj_rot, log_eps, 1.0)

            # KL divergence
            kl = np.sum(q_i_clipped * (np.log(q_i_clipped / qj_rot)), axis=-1)
            total_error += np.sum(kl * overlap)
            count += np.sum(overlap)

    return total_error / (count + 1e-8)

def log_phi_diagnostics(agents, step):
    """
    Logs φ field diagnostics: norm, Laplacian norm, update magnitude.
    All norms are normalized by agent support size.
    """
    phi_norms = []
    lap_norms = []
    delta_norms = []

    for agent in agents:
        phi = agent.phi
        mask = agent.mask
        support = np.sum(mask)

        if support < 1e-6:
            continue  # skip empty agents

        # ‖φ‖ normalized by support volume
        norm_phi = np.linalg.norm(phi * mask[..., None]) / np.sqrt(support)
        phi_norms.append(norm_phi)

        # ‖Δφ‖ normalized
        lap_phi = np.stack([laplace(phi[..., d]) for d in range(3)], axis=-1)
        norm_lap = np.linalg.norm(lap_phi * mask[..., None]) / np.sqrt(support)
        lap_norms.append(norm_lap)

        # ‖δφ‖ normalized
        delta = getattr(agent, 'delta_phi', None)
        if delta is not None:
            norm_delta = np.linalg.norm(delta * mask[..., None]) / np.sqrt(support)
            if np.isfinite(norm_delta):
                delta_norms.append(norm_delta)

    return {
        "step": step,
        "phi_norm": np.mean(phi_norms) if phi_norms else 0.0,
        "lap_phi_norm": np.mean(lap_norms) if lap_norms else 0.0,
        "delta_phi_norm": np.max(delta_norms) if delta_norms else 0.0,
    }

def compute_transport_strength(agent_i, agent_j, generators):
    """
    Computes the average norm of belief change due to Omega transport:
    ‖q_j(c) - Ω_{ij}(c) q_j(c)‖ over the overlapping region.
    """
    r = agent_i.phi - agent_j.phi
    mask = (agent_i.mask * agent_j.mask) > config.overlap_eps
    if not np.any(mask):
        return 0.0

    r_vecs = r[mask]
    qj_vecs = agent_j.q[mask]

    omega_batch = batch_exp_sl2r_irrep(r_vecs, generators)
    qj_rot = batch_apply_omega(qj_vecs, omega_batch)

    diffs = qj_vecs - qj_rot
    norms = np.linalg.norm(diffs, axis=-1)

    return np.mean(norms)

def compute_network_transport_strength(agents, generators):
    total = 0.0
    count = 0
    for agent_i in agents:
        for neighbor in agent_i.neighbors:
            agent_j = agents[neighbor["id"]]
            ts = compute_transport_strength(agent_i, agent_j, generators)
            total += ts
            count += 1
    return total / (count + 1e-8)


def compute_average_entropy(agents):
    entropies = []
    for agent in agents:
        q = agent.q
        mask = agent.mask
        q_safe = np.clip(q, log_eps, 1.0)
        entropy = -np.sum(q_safe * np.log(q_safe), axis=-1)
        entropies.append(np.sum(entropy * mask) / (np.sum(mask) + log_eps))
    return float(np.mean(entropies))

def compute_kl_divergences(agents):
    kl_self = []
    kl_align = []

    for agent in agents:
        q = np.clip(agent.q, log_eps, 1.0)
        p = np.clip(agent.p, log_eps, 1.0)
        kl = np.sum(q * (np.log(q) - np.log(p)), axis=-1)
        kl_self.append(np.sum(kl * agent.mask) / (np.sum(agent.mask) + log_eps))

        # Inter-agent KL
        if len(agent.neighbors) > 0:
            kl_vals = []
            for neighbor in agent.neighbors:
                j = neighbor['id']
                qj = np.clip(agents[j].q, log_eps, 1.0)
                kl_ij = np.sum(q * (np.log(q) - np.log(qj)), axis=-1)
                overlap = agent.mask * agents[j].mask
                kl_vals.append(np.sum(kl_ij * overlap) / (np.sum(overlap) + log_eps))
            kl_align.append(np.mean(kl_vals))
        else:
            kl_align.append(0.0)

    return float(np.mean(kl_self)), float(np.mean(kl_align))

def compute_phi_norm(agents):
    norms = []
    for agent in agents:
        phi = agent.phi
        mask = agent.mask
        norm = np.sqrt(np.sum(phi**2, axis=-1))
        norms.append(np.sum(norm * mask) / (np.sum(mask) + log_eps))
    return float(np.mean(norms))

def compute_curvature_norm(agents):
    
    norms = []
    for agent in agents:
        F = compute_field_strength(agent.phi)
        mask = agent.mask
        norm = np.linalg.norm(F, axis=-1)
        norms.append(np.sum(norm * mask) / (np.sum(mask) + log_eps))
    return float(np.mean(norms))

def compute_phi_laplacian_norm(agents):
    norms = []
    for agent in agents:
        phi = agent.phi
        mask = agent.mask
        lap_phi = np.stack([laplace(phi[..., d]) for d in range(3)], axis=-1)
        norm = np.linalg.norm(lap_phi, axis=-1)
        norms.append(np.sum(norm * mask) / (np.sum(mask) + log_eps))
    return float(np.mean(norms))

def compute_phi_delta_norm(agents):
    norms = []
    for agent in agents:
        if hasattr(agent, "delta_phi") and agent.delta_phi is not None:
            delta = agent.delta_phi
            mask = agent.mask
            norm = np.linalg.norm(delta, axis=-1)
            norms.append(np.sum(norm * mask) / (np.sum(mask) + log_eps))
    return float(np.mean(norms)) if norms else 0.0

def compute_phi_model_norm(agents):
    norms = []
    for agent in agents:
        phi = agent.phi_model
        mask = agent.mask
        norm = np.linalg.norm(phi, axis=-1)
        avg_norm = np.sum(norm * mask) / (np.sum(mask) + 1e-8)
        norms.append(avg_norm)
    return float(np.mean(norms))

def compute_model_alignment_kl(agents):
    import config
    from omega_operator import batch_exp_sl2r_irrep, batch_apply_omega, repair_if_forgotten_batch
    from sl2r_generators import get_generators

    _, _, _, generators = get_generators(config.K)
    eps = config.log_eps

    kl_total = 0.0
    count = 0

    for agent_i in agents:
        p_i, phi_i, mask_i = agent_i.p, agent_i.phi_model, agent_i.mask

        for neighbor in agent_i.neighbors:
            agent_j = agents[neighbor["id"]]
            p_j, phi_j, mask_j = agent_j.p, agent_j.phi_model, agent_j.mask
            overlap = (mask_i * mask_j) > config.overlap_eps
            if not np.any(overlap):
                continue

            r_vecs = np.clip(phi_i[overlap] - phi_j[overlap], -10.0, 10.0)
            pj_vecs = p_j[overlap]
            pi_vecs = p_i[overlap]

            omega_batch = batch_exp_sl2r_irrep(r_vecs, generators)
            pj_rot_batch = batch_apply_omega(pj_vecs, omega_batch)
            pj_rot_batch = repair_if_forgotten_batch(pj_rot_batch, eps=eps)

            pi_vecs = np.clip(pi_vecs, eps, 1.0)
            pj_rot_batch = np.clip(pj_rot_batch, eps, 1.0)

            kl = np.sum(pi_vecs * (np.log(pi_vecs) - np.log(pj_rot_batch)), axis=-1)
            kl_total += np.sum(kl)
            count += np.sum(overlap)

    return kl_total / (count + eps)

def compute_phi_model_alignment_error(agents):
    from config import overlap_eps
    norms = []
    for agent_i in agents:
        phi_i = agent_i.phi_model
        mask_i = agent_i.mask
        for neighbor in agent_i.neighbors:
            agent_j = agents[neighbor["id"]]
            phi_j = agent_j.phi_model
            mask_j = agent_j.mask
            overlap = (mask_i * mask_j) > overlap_eps
            if not np.any(overlap):
                continue
            delta_phi = phi_i - phi_j
            diff = np.linalg.norm(delta_phi[overlap], axis=-1)
            norms.append(np.mean(diff))
    return float(np.mean(norms)) if norms else 0.0

def compute_fisher_information_norm(agents):
    norms = []
    for agent in agents:
        q = np.clip(agent.q, config.log_eps, 1.0)
        grad_q = np.gradient(q, axis=(0, 1))  # (2, H, W, K)
        fisher = sum(np.sum((g**2) / (q + config.log_eps), axis=-1) for g in grad_q)
        norm = np.sum(fisher * agent.mask) / (np.sum(agent.mask) + config.log_eps)
        norms.append(norm)
    return float(np.mean(norms)) if norms else 0.0

def compute_cross_model_kl(agents):
    from omega_operator import batch_exp_sl2r_irrep, batch_apply_omega, repair_if_forgotten_batch
    _, _, _, generators = get_generators(config.K)
    total_kl = 0.0
    count = 0

    for agent_i in agents:
        q_i = agent_i.q
        phi_i = agent_i.phi

        for neighbor in agent_i.neighbors:
            agent_j = agents[neighbor["id"]]
            phi_j = agent_j.phi_model
            p_j = agent_j.p

            overlap = (agent_i.mask * agent_j.mask) > config.overlap_eps
            if not np.any(overlap):
                continue

            # Extract overlap region
            q_overlap = q_i[overlap]
            p_j_overlap = p_j[overlap]
            r = phi_i[overlap] - phi_j[overlap]

            # Clip and normalize before applying transport
            p_j_overlap = np.clip(p_j_overlap, config.eps, 1.0)
            p_j_overlap /= np.sum(p_j_overlap, axis=-1, keepdims=True)

            q_overlap = np.clip(q_overlap, config.eps, 1.0)
            q_overlap /= np.sum(q_overlap, axis=-1, keepdims=True)

            omega = batch_exp_sl2r_irrep(r, generators)
            p_rot = batch_apply_omega(p_j_overlap, omega)
            p_rot = repair_if_forgotten_batch(p_rot, config.eps)

            # KL divergence: D_KL(q || p_rot)
            kl = np.sum(q_overlap * (np.log(q_overlap) - np.log(p_rot + config.eps)), axis=-1)
            total_kl += np.sum(kl)
            count += np.sum(overlap)

    return total_kl / (count + config.log_eps)


def compute_information_update_norm(agent):
    dq = getattr(agent, 'delta_q', None)
    if dq is None:
        return 0.0
    mask = agent.mask
    norm = np.linalg.norm(dq, axis=-1)
    return np.sum(norm * mask) / (np.sum(mask) + config.log_eps)


def log_all_metrics(agents, step):
    
    kl_self, kl_align = compute_kl_divergences(agents)
    return {
        "step": step,
        "kl_self": kl_self,
        "kl_align": kl_align,
        "kl_model_align": compute_model_alignment_kl(agents),
        "entropy": compute_average_entropy(agents),
        "total_energy": compute_total_energy(agents),
        "phi_norm": compute_phi_norm(agents),
        "phi_model_norm": compute_phi_model_norm(agents),
        "phi_model_align_error": compute_phi_model_alignment_error(agents),
        "curvature": compute_curvature_norm(agents),
        "lap_phi_norm": compute_phi_laplacian_norm(agents),
        "delta_phi_norm": compute_phi_delta_norm(agents),
        "fisher_information": compute_fisher_information_norm(agents),
        "cross_model_kl": compute_cross_model_kl(agents),
    }
