# omega_operator.py

import numpy as np
from config import K, phi_clip_threshold
from scipy.linalg import expm
from scipy.ndimage import sobel
from sl2r_generators import get_generators


from config import beta, phi_clip_threshold, log_eps
from sl2r_generators import get_generators
from scipy.linalg import expm
import numpy as np
import config

def repair_if_forgotten(q: np.ndarray, eps: float, threshold: float = 1e-6) -> np.ndarray:
    """
    If a belief vector q has near-zero total mass, inject small uniform mass
    so that belief learning can resume.

    Parameters:
        q         : (K,) belief vector
        eps       : small clipping constant
        threshold : total mass threshold to trigger repair

    Returns:
        q_repaired : repaired or original belief vector
    """
    total_mass = np.sum(q)
    if total_mass < threshold or not np.isfinite(total_mass):
        K = q.shape[-1]
        q = np.random.dirichlet(np.ones(K))  # proper normalized distribution
    else:
        q = np.clip(q, eps, 1.0)
        q /= np.sum(q) + eps  # safe normalization
    return q



def repair_if_forgotten_batch(q: np.ndarray, eps: float, threshold: float = 1e-6) -> np.ndarray:
    """
    Repair a batch of belief vectors where some may have near-zero total mass.

    Parameters:
        q         : (..., K) array of belief vectors
        eps       : small floor value (e.g., config.log_eps)
        threshold : total mass below which a vector is considered "forgotten"

    Returns:
        q_repaired : repaired batch, same shape as q
    """
    q = np.nan_to_num(q, nan=0.0, posinf=0.0, neginf=0.0)
    K = q.shape[-1]
    norms = np.sum(q, axis=-1, keepdims=True)

    # Identify forgotten locations
    forgotten = (norms < threshold) | (~np.isfinite(norms))

    # Inject small Dirichlet mass for forgotten vectors
    if np.any(forgotten):
        shape = q[forgotten].shape
        n_forgotten = shape[0]
        q_noise = np.random.dirichlet(np.ones(K), size=n_forgotten) * eps * K
        q[forgotten] = q_noise

    # Clip and renormalize all vectors safely
    q = np.clip(q, eps, 1.0)
    norms = np.sum(q, axis=-1, keepdims=True)
    q /= norms + eps
    return q




def kl_divergence(q1, q2, eps=1e-12):
    q1 = np.clip(q1, eps, 1.0)
    q2 = np.clip(q2, eps, 1.0)
    return np.sum(q1 * (np.log(q1) - np.log(q2)), axis=-1)

from sl2r_generators import get_generators
_, _, _, generators = get_generators(K)


from scipy.linalg import expm
from sl2r_generators import get_generators  # assuming this replaces sl2r_generators
import config

def exp_sl2r_irrep(v, generators=None, use_expm=True, threshold=config.phi_clip_threshold):
    """
    Exponentiate a Lie algebra element ∑ vᵃ Gₐ using SL(2,ℝ) irrep.
    """
    if generators is None:
        _, _, _, generators = get_generators(config.K)

    G = sum(v[a] * generators[a] for a in range(3))
    norm = np.linalg.norm(v)
    if not use_expm or norm < threshold:
        return np.eye(G.shape[0]) + G + 0.5 * G @ G
    else:
        return expm(G)

def batch_exp_sl2r_irrep(v_batch, generators, use_expm=True, threshold=config.phi_clip_threshold):
    ...

    """
    Batch exponentiation of SL(2,ℝ) Lie algebra elements: vᵢ·G → exp(∑ vᵃ Gₐ)

    Uses:
    - 5th-order Taylor series for small ‖v‖
    - Full expm for large ‖v‖

    Returns:
        Ω_batch : (N, K, K)
    """
    _, _, _, generators = get_generators(config.K)
    beta = config.beta
    K = config.K

    if beta == 0:
        return None

    G_batch = np.einsum('na,aij->nij', v_batch, generators)  # (N, K, K)
    norms = np.linalg.norm(v_batch, axis=1)

    result = np.zeros((len(v_batch), K, K), dtype=np.float64)

    approx_mask = norms < threshold
    if np.any(approx_mask):
        G_approx = G_batch[approx_mask]
        G2 = np.einsum('nij,njk->nik', G_approx, G_approx)
        G3 = np.einsum('nij,njk->nik', G2, G_approx)
        G4 = np.einsum('nij,njk->nik', G3, G_approx)
        G5 = np.einsum('nij,njk->nik', G4, G_approx)
        I = np.eye(K)[None, :, :]

        result[approx_mask] = (
            I +
            G_approx +
            (1/2) * G2 +
            (1/6) * G3 +
            (1/24) * G4 +
            (1/120) * G5
        )

    if np.any(~approx_mask):
        for idx in np.where(~approx_mask)[0]:
            result[idx] = expm(G_batch[idx])

    return result



from scipy.linalg import expm
from sl2r_generators import get_generators  # assumes sl2r generators are provided here
import config

def batch_apply_omega(q_batch, omega_batch):
    """
    Apply batch of group elements Ω to batch of belief vectors q.
    """
    assert omega_batch.shape[0] == q_batch.shape[0], "Batch size mismatch"
    assert omega_batch.shape[1] == omega_batch.shape[2], "Omega must be square"
    assert omega_batch.shape[1] == q_batch.shape[1], (
        f"Mismatch in fiber dimension: "
        f"omega is ({omega_batch.shape[1]}, {omega_batch.shape[2]}), "
        f"but q has K = {q_batch.shape[1]}"
    )
    return np.einsum('nij,nj->ni', omega_batch, q_batch)


def exp_sl2r_operator(v, generators, use_expm=True, threshold=config.phi_clip_threshold):
    """
    Compute exp(Σ vₐ Tₐ) in SL(2,ℝ) irrep:
    - Uses Taylor approx for small ‖v‖
    - Uses expm otherwise

    Parameters:
    - v: 3D vector (sl(2,ℝ) Lie algebra element)
    - generators: array of shape (3, K, K)
    - use_expm: whether to use full matrix exponential
    - threshold: norm cutoff for switching methods

    Returns:
    - Ω ∈ SL(2,ℝ) irrep (K x K matrix)
    """
    G = sum(v[a] * generators[a] for a in range(3))
    norm = np.linalg.norm(v)

    if not use_expm or norm < threshold:
        return np.eye(G.shape[0]) + G + 0.5 * G @ G
    else:
        return expm(G)

def apply_omega(q_j, omega):
    """
    Apply a single SL(2,ℝ) group matrix Ω to a belief vector q_j.
    """
    return np.einsum('ij,...j->...i', omega, q_j)

def compute_gauge_potential(phi):
    """
    Compute SL(2,ℝ) gauge potential: A_μ^a = ∂_μ φ^a

    Returns:
    - A_x, A_y ∈ ℝ^(H, W, 3) where last dim is Lie algebra index
    """
    dphi_dx = np.gradient(phi, axis=1)  # ∂/∂x φ^a
    dphi_dy = np.gradient(phi, axis=0)  # ∂/∂y φ^a
    A_x = dphi_dx
    A_y = dphi_dy
    return A_x, A_y


def compute_field_strength(phi):
    """
    SL(2,ℝ) curvature: F_{xy} = ∂_x A_y - ∂_y A_x + [A_x, A_y]
    with A_μ ∈ ℝ³ Lie algebra components

    Returns:
        F_squared (H, W) — scalar curvature magnitude per point
    """
    A_x, A_y = compute_gauge_potential(phi)

    dAy_dx = np.gradient(A_y, axis=1)  # ∂_x A_y
    dAx_dy = np.gradient(A_x, axis=0)  # ∂_y A_x

    commutator = np.cross(A_x, A_y)  # Lie bracket in ℝ³ basis
    F = dAy_dx - dAx_dy + commutator
    F_squared = np.sum(F**2, axis=-1)
    return F_squared

def compute_sl2r_commutator(A_mu, A_nu):
    """
    Matrix commutator: [A_μ, A_ν] = A_μ A_ν - A_ν A_μ
    A_μ, A_ν are (..., K, K) matrices.
    """
    return np.matmul(A_mu, A_nu) - np.matmul(A_nu, A_mu)

def compute_sl2r_curvature(phi):
    """
    Full SL(2,ℝ) curvature tensor F_{μν} in matrix form.

    Parameters:
        phi: (H, W, 3) Lie algebra coordinates

    Returns:
        curvature_norm: (H, W) Frobenius norm ‖F_{xy}‖ at each point
    """
    A_x_vec, A_y_vec = compute_gauge_potential(phi)
    _, _, _, generators = get_generators(config.K)

    A_x = np.einsum('...a,aij->...ij', A_x_vec, generators)
    A_y = np.einsum('...a,aij->...ij', A_y_vec, generators)

    dAy_dx = np.gradient(A_y, axis=1)  # ∂_x A_y
    dAx_dy = np.gradient(A_x, axis=0)  # ∂_y A_x

    comm = compute_sl2r_commutator(A_x, A_y)
    F_xy = dAy_dx - dAx_dy + comm

    curvature_norm = np.linalg.norm(F_xy, axis=(2, 3))  # Frobenius norm
    return curvature_norm
