# -*- coding: utf-8 -*-
"""
Created on Wed Aug  6 12:27:32 2025

@author: chris and christine
"""
 
import numpy as np
import config as config
from core.edge_maps import gamma_maps
from core.transport_cache import Omega, Phi_cached, Phi
from core.runtime_context import cfg_get
from agents.agent_accessor import AA

from core.utils import (iter_overlap_pairs, _accumulate_into_agent,
                   _drain_inbox_into_dalign, _add_to_inbox, _zeros_mu_S_like)

from core.numerical_utils import (kl_gaussian,sanitize_sigma, safe_inv, push_gaussian, plain_rule,
                                  softmax_align_rule_receiver, softmax_align_rule_sender, 
                                  )

def _fiber_keys_from_mode(mode: str):
    """Map 'belief'/'model' → fiber and attribute names (q/p)."""
    which = "q" if mode == "belief" else "p"
    field = "phi" if which == "q" else "phi_model"
    mu_key = "mu_q_field" if which == "q" else "mu_p_field"
    S_key  = "sigma_q_field" if which == "q" else "sigma_p_field"
    gmu_key= "grad_mu_q" if which == "q" else "grad_mu_p"
    gS_key = "grad_sigma_q" if which == "q" else "grad_sigma_p"
    return which, field, mu_key, S_key, gmu_key, gS_key



def _run_mu_sigma_pipeline(
    *,
    ctx,
    agent_i,
    which: str,                 # "q" or "p"
    dmu_self=None, dS_self=None,
    dmu_feedback=None, dS_feedback=None,
    dmu_align=None, dS_align=None,
    dmu_gamma=None, dS_gamma=None,
    natural_project: bool = True,
):
    """
    Canonical μ/Σ post-processing and (optionally) accumulation for one fiber.

    Steps:
      1) Sum all provided buckets (treat missing as zeros).
      2) Symmetrize Σ-gradient.
      3) Natural-gradient projection (uses apply_natural_gradient_batch).
      4) Return (delta_mu, delta_S); caller can accumulate.
    """
    
    # Fiber-specific keys
    mu_key  = "mu_q_field"    if which == "q" else "mu_p_field"
    S_key   = "sigma_q_field" if which == "q" else "sigma_p_field"

    # Shapes / zeros
    mu_i = np.asarray(getattr(agent_i, mu_key), np.float32)
    
    S    = mu_i.shape[:-1]
    K    = mu_i.shape[-1]

    def _zmu(x): return np.zeros(S + (K,),   np.float32) if x is None else np.asarray(x, np.float32, order="C")
    def _zS (x): return np.zeros(S + (K,K),  np.float32) if x is None else np.asarray(x, np.float32, order="C")

    # 1) sum buckets
    dmu_total = _zmu(dmu_self) + _zmu(dmu_feedback) + _zmu(dmu_align) + _zmu(dmu_gamma)
    dS_total  = _zS (dS_self)  + _zS (dS_feedback)  + _zS (dS_align)  + _zS (dS_gamma)

    # 2) symmetrize
    dS_total = 0.5 * (dS_total + np.swapaxes(dS_total, -1, -2))

    if not natural_project:
        return dmu_total, dS_total

    # 3) natural projection (correct signature — no Sigma/Sigma_inv kwargs)
    delta_mu, delta_S = apply_natural_gradient_batch(
        ctx,
        getattr(agent_i, mu_key),
        getattr(agent_i, S_key),
        dmu_total,
        dS_total,
        mask=getattr(agent_i, "mask", None),
        assume_sanitized=True,
        grad_sigma_is_symmetric=True,
        use_float64=True,
    )

    # 4) return to caller; accumulation can be handled outside
    return delta_mu, delta_S



def accumulate_mu_sigma_gradient(ctx, agent_i, agents, mode):
    """
    Accumulate natural gradients (μ, Σ) for belief or model.

    Structure:
      1) Resolve fiber + keys (q/p)
      2) Pull Φ, Φ̃ from cache and push (q,p) once
      3) Self & feedback grads (receiver-only)
      4) Pairwise alignment block (β·ALIGN) + γ(A/B)
      5) Combine -> natural projection via _run_mu_sigma_pipeline -> accumulate to agent
    """
    if ctx is None:
        raise RuntimeError("accumulate_mu_sigma_gradient: ctx required.")

      
    eps   = float(cfg_get(ctx, "eps", 1e-6))
    tau   = float(cfg_get(ctx, "support_tau", 1e-6))
    alpha = float(cfg_get(ctx, "alpha", 0.0))
    lambd = float(cfg_get(ctx, "feedback_weight", 0.0))
    accum_send_cfg = bool(cfg_get(ctx, "accumulate_sender_grads", False))

    which, field, mu_key, S_key, gmu_key, gS_key = _fiber_keys_from_mode(mode)

    # 2) Φ/Φ̃ pushes once
    Phi  = Phi_cached(ctx, agent_i, kind="q_to_p")
    Phit = Phi_cached(ctx, agent_i, kind="p_to_q")

    mu_q = getattr(agent_i, "mu_q_field"); S_q = getattr(agent_i, "sigma_q_field")
    mu_p = getattr(agent_i, "mu_p_field"); S_p = getattr(agent_i, "sigma_p_field")

    mu_q_push, S_q_push, inv_q_push = push_gaussian(
        mu_q, S_q, Phi, eps=eps, return_inv=True,
        Sigma_inv=getattr(agent_i, "sigma_q_inv", None),
        assume_orthogonal=False
    )
    mu_p_push, S_p_push, inv_p_push = push_gaussian(
        mu_p, S_p, Phit, eps=eps, return_inv=True,
        Sigma_inv=getattr(agent_i, "sigma_p_inv", None),
        assume_orthogonal=False
    )

    # (optional) energy accounting
    self_raw, fb_raw = accumulate_self_feedback_energies(
        ctx, agent_i,
        mu_q=mu_q, S_q=S_q,
        mu_p=mu_p, S_p=S_p,
        mu_q_push=mu_q_push, S_q_push=S_q_push,
        mu_p_push=mu_p_push, S_p_push=S_p_push,
    )

    # 3) self + feedback grads
    g_self_mu, g_self_S, g_fb_mu, g_fb_S = _self_and_feedback_grads(
        mode,
        mu_q, S_q, mu_p, S_p,
        mu_q_push, S_q_push, inv_q_push,
        mu_p_push, S_p_push, inv_p_push,
        Phi, Phit, eps,
        sigma_q_inv=getattr(agent_i, "sigma_q_inv", None),
        sigma_p_inv=getattr(agent_i, "sigma_p_inv", None),
        mask=getattr(agent_i, "mask", None),
    )

    # 4) β·ALIGN and γ
    dmu_align, dS_align = _accum_alignment_block_mu_sigma(
        ctx, agent_i, agents,
        which=which, mu_key=mu_key, S_key=S_key,
        eps=eps, tau=tau, accum_send=accum_send_cfg,
    )
    dmu_gamma, dS_gamma = _accum_gamma_block_mu_sigma(
        ctx, agent_i, agents,
        which=which, mu_key=mu_key, S_key=S_key,
        eps=eps, tau=tau, accum_send=accum_send_cfg,
        Phi=Phi, Phit=Phit,
        use_gamma_A=None, use_gamma_B=None,
    )

    # 5) combine → natural projection → accumulate
    delta_mu, delta_S = _run_mu_sigma_pipeline(
        ctx=ctx, agent_i=agent_i, which=which,
        dmu_self=alpha * g_self_mu,    dS_self=alpha * g_self_S,
        dmu_feedback=lambd * g_fb_mu,  dS_feedback=lambd * g_fb_S,
        dmu_align=dmu_align,           dS_align=dS_align,
        dmu_gamma=dmu_gamma,           dS_gamma=dS_gamma,
        natural_project=True,
    )

    _accumulate_into_agent(agent_i, gmu_key, gS_key, delta_mu, delta_S)
    return delta_mu, delta_S, (float(self_raw), float(fb_raw))






def _accum_alignment_block_mu_sigma(
    ctx,
    agent_i,
    agents,
    *,
    which: str,             # 'q' or 'p'
    mu_key: str,
    S_key: str,
    eps: float,
    tau: float,
    accum_send: bool,
):
    """
    β-align only. Computes pairwise ALIGN β-weighted μ/Σ gradients for receiver i
    (and enqueues sender j) using the exact softmax product rule with KL1 := ALIGN KL.
    """
    from core.edge_maps import beta_align_maps

    # Precompute receiver stats once
    mu_i_arr = np.asarray(getattr(agent_i, mu_key), np.float32, order="C")
    S_i_arr  = sanitize_sigma(np.asarray(getattr(agent_i, S_key), np.float64), eps=eps)\
                  .astype(np.float32, copy=False)

    dmu_align = np.zeros_like(mu_i_arr, dtype=np.float32)
    dS_align  = np.zeros_like(S_i_arr,  dtype=np.float32)

    Sshape = tuple(mu_i_arr.shape[:-1])
    Ki = int(mu_i_arr.shape[-1])
    gbar_mu_i = np.zeros(Sshape + (Ki,),    np.float32)
    gbar_S_i  = np.zeros(Sshape + (Ki, Ki), np.float32)

    pairs = []

    for agent_j, overlap in iter_overlap_pairs(agent_i, agents, tau=tau, which=which, mu_key=mu_key, ctx = ctx):
        if not np.any(overlap):
            continue

        KL1_map, beta_map = beta_align_maps(ctx, agent_i, agent_j, which=which)
        
        m        = overlap.astype(np.float32, copy=False)
        beta_ij  = beta_map * m
        KL1      = KL1_map  * m
        if not np.any(beta_ij > 0):
            continue

        Om_align = Omega(ctx, agent_i, agent_j, which=which)

        mu_j_arr = np.asarray(getattr(agent_j, mu_key), np.float32, order="C")
        S_j_arr  = sanitize_sigma(np.asarray(getattr(agent_j, S_key), np.float64), eps=eps)\
                      .astype(np.float32, copy=False)

        mu_j_t, S_j_t, inv_j_t = push_gaussian(
            mu_j_arr, S_j_arr, Om_align, eps=eps, return_inv=True, sanitize_input=False
        )
     
        gmu_align, gS_align = grad_alignment_energy_source(
            mu_i_arr, S_i_arr, mu_j_t, inv_j_t, eps=eps, sigma_i_inv=None, assume_sanitized=True
        )
        
       
        gmu_align_j, gS_align_j = grad_alignment_energy_target(
            mu_i=mu_i_arr, sigma_i=S_i_arr,
            mu_j_t=mu_j_t, sigma_j_t_inv=inv_j_t,
            Omega_ij=Om_align, eps=eps, assume_sanitized=True
        )
        
        # shape guards
        assert beta_ij.shape == KL1.shape
        assert gmu_align.shape[:-1] == KL1.shape
        assert gS_align.shape[:-2] == KL1.shape

        # β-averages for softmax rule
        gbar_mu_i += beta_ij[..., None]       * gmu_align
        gbar_S_i  += beta_ij[..., None, None] * gS_align

        pairs.append(dict(
            j=agent_j, overlap=overlap,
            beta_ij=beta_ij, KL1=KL1,
            gmu_align=gmu_align, gS_align=gS_align,
            gmu_align_j=gmu_align_j, gS_align_j=gS_align_j,
        ))

    # second pass: exact softmax product rule
    for P in pairs:
        agent_j     = P["j"]
        overlap     = P["overlap"]
        beta_ij     = P["beta_ij"]
        KL1         = P["KL1"]
        gmu_align   = P["gmu_align"]
        gS_align    = P["gS_align"]
        gmu_align_j = P["gmu_align_j"]
        gS_align_j  = P["gS_align_j"]

       
        kappa  = max(float(cfg_get(ctx, f"beta_kappa_{which}", 1.0)), 1e-12)

        add_mu_i = softmax_align_rule_receiver(beta_ij, KL1, kappa, gmu_align, gbar_mu_i)
        add_S_i  = softmax_align_rule_receiver(beta_ij, KL1, kappa, gS_align,  gbar_S_i)
        add_mu_j = softmax_align_rule_sender  (beta_ij, KL1, kappa, gmu_align_j)
        add_S_j  = softmax_align_rule_sender  (beta_ij, KL1, kappa, gS_align_j)

        dmu_align[overlap] += add_mu_i[overlap]
        dS_align [overlap] += add_S_i [overlap]
        
        if accum_send:
            _add_to_inbox(agent_j, which, add_mu_j, add_S_j, overlap)
            
    # final guards
    assert np.all(np.isfinite(dmu_align)) and np.all(np.isfinite(dS_align)), "β-align NaN/Inf"
    return dmu_align, dS_align



def _accum_gamma_block_mu_sigma(
    ctx,
    agent_i,
    agents,
    *,
    which: str,             # 'q' or 'p'
    mu_key: str,
    S_key: str,
    eps: float,
    tau: float,
    accum_send: bool,
    Phi=None,
    Phit=None,
    use_gamma_A: bool | None = None,
    use_gamma_B: bool | None = None,
):
    """
    γ-only block. Centralized product rule per *case*:
        ∂(γ KL) = γ * (1 - KL/κ_γ) * ∂KL
    No softmax. Optional per-receiver γ normalization (sum-cap / row-sum).
    """

    # ---- config toggles ----
    if use_gamma_A is None:
        use_gamma_A = bool(cfg_get(ctx, f"use_gamma_A_{which}", True))
    if use_gamma_B is None:
        use_gamma_B = bool(cfg_get(ctx, f"use_gamma_B_{which}", True))

    use_gamma_norm  = bool(cfg_get(ctx, "normalize_gamma", False))
    gamma_norm_mode = str(cfg_get(ctx, "gamma_norm_mode", "sumcap")).lower()  # "sumcap" | "rowsum"
    gamma_sumcap    = float(cfg_get(ctx, "gamma_sumcap", 1.0))                # used if sumcap
   

    kap = max(float(cfg_get(ctx, f"kappa_gamma_{which}", 1.0)), 1e-12)

    # ---- init accumulators (receiver i) ----
    mu_i_arr0 = np.asarray(getattr(agent_i, mu_key), np.float32, order="C")
    S_i_arr0  = np.asarray(getattr(agent_i, S_key),  np.float32, order="C")
    dmu_G = np.zeros_like(mu_i_arr0, dtype=np.float32)
    dS_G  = np.zeros_like(S_i_arr0,  dtype=np.float32)

    # ---- gather pass (collect per-neighbor, per-case entries) ----
    entries_A = []   # list of dicts with keys: w, K, mu_rec, S_rec, mu_send, S_send, overlap, agent_j
    entries_B = []

    # Pre-cached receiver fields for dispatcher
    Omega_q = {}  # cache Ω_ij per neighbor
    for agent_j, overlap in iter_overlap_pairs(agent_i, agents, tau=tau, which=which, mu_key=mu_key, ctx=ctx):
        if not np.any(overlap):
            continue

        Om_q_ij = Omega_q.get(id(agent_j))
        if Om_q_ij is None:
            Om_q_ij = Omega(ctx, agent_i, agent_j, which="q")
            Omega_q[id(agent_j)] = Om_q_ij

        gam = gamma_maps(ctx, agent_i, agent_j)  # {"A": (KL_A, γ_A), "B": (KL_B, γ_B)}
        if not gam:
            continue

        # Case A
        if use_gamma_A and ("A" in gam):
            KLc, Gc = gam["A"]  # (*S,), (*S,)
            outA = grad_gamma_mu_sigma_dispatch(
                ctx, agent_i, agent_j,
                basis="a",
                Omega_ij=Om_q_ij,
                Phi_i=Phi,
                Phi_tilde_i=Phit,
                eps=eps,
            )
            m = overlap.astype(np.float32, copy=False)
            w = (np.asarray(Gc,  np.float32) * m).astype(np.float32, copy=False)
            K = (np.asarray(KLc, np.float32) * m).astype(np.float32, copy=False)

           
            entries_A.append(dict(
                w=w, K=K, overlap=overlap, agent_j=agent_j,
                mu_rec=np.asarray(outA["mu_rec"],  np.float32, order="C"),
                S_rec =np.asarray(outA["S_rec"],   np.float32, order="C"),
                mu_send=np.asarray(outA["mu_send"],np.float32, order="C"),
                S_send =np.asarray(outA["S_send"], np.float32, order="C"),
            ))

        # Case B
        if use_gamma_B and ("B" in gam):
            KLc, Gc = gam["B"]
            outB = grad_gamma_mu_sigma_dispatch(
                ctx, agent_i, agent_j,
                basis="b",
                Omega_ij=Om_q_ij,
                Phi_i=Phi,
                Phi_tilde_i=Phit,
                eps=eps,
            )
            m = overlap.astype(np.float32, copy=False)
            w = (np.asarray(Gc,  np.float32) * m).astype(np.float32, copy=False)
            K = (np.asarray(KLc, np.float32) * m).astype(np.float32, copy=False)

          
            entries_B.append(dict(
                w=w, K=K, overlap=overlap, agent_j=agent_j,
                mu_rec=np.asarray(outB["mu_rec"],  np.float32, order="C"),
                S_rec =np.asarray(outB["S_rec"],   np.float32, order="C"),
                mu_send=np.asarray(outB["mu_send"],np.float32, order="C"),
                S_send =np.asarray(outB["S_send"], np.float32, order="C"),
            ))

    # ---- optional per-receiver γ normalization (per case separately) ----
    def _normalize_entries(entries, mode, cap_val):
        if (not use_gamma_norm) or (not entries):
            return [e["w"] for e in entries]
        # Stack all w maps: shape (*S, J)
        W = np.stack([e["w"] for e in entries], axis=-1)
        Ssum = np.sum(W, axis=-1, keepdims=True)  # (*S,1)
        eps_ = 1e-6
        if mode == "rowsum":
            Wn = W / (Ssum + eps_)
        else:  # "sumcap" default
            scale = np.minimum(1.0, cap_val / (Ssum + eps_))
            Wn = W * scale
        # split back per-entry
        return [Wn[..., j] for j in range(Wn.shape[-1])]

    wA_norm = _normalize_entries(entries_A, gamma_norm_mode, gamma_sumcap)
    wB_norm = _normalize_entries(entries_B, gamma_norm_mode, gamma_sumcap)
    # ---- accumulate pass (apply product rule per entry with normalized w) ----
    def _accumulate(entries, w_norm_list):
        nonlocal dmu_G, dS_G
        for e, w_norm in zip(entries, w_norm_list):
            w = np.asarray(w_norm, np.float32, order="C")
            K = np.asarray(e["K"], np.float32, order="C")

            add_mu_i = plain_rule(w, K, kap, e["mu_rec"])
            add_S_i  = plain_rule(w, K, kap, e["S_rec"])
            dmu_G += add_mu_i
            dS_G  += add_S_i

            if accum_send:
                add_mu_j = plain_rule(w, K, kap, e["mu_send"])
                add_S_j  = plain_rule(w, K, kap, e["S_send"])
                _add_to_inbox(e["agent_j"], which, add_mu_j, add_S_j, e["overlap"])

    _accumulate(entries_A, wA_norm)
    _accumulate(entries_B, wB_norm)

    # Optional: drain sender inbox into d_align buckets here
    if accum_send:
        dmu_G, dS_G = _drain_inbox_into_dalign(agent_i, which, dmu_G, dS_G)

    # Final sanity
    assert np.all(np.isfinite(dmu_G)) and np.all(np.isfinite(dS_G)), "γ NaN/Inf"
    return dmu_G, dS_G




def _accum_gamma_mu_sigma_for_pair(
    ctx,
    agent_i, agent_j,
    *,
    mu_key: str,
    S_key: str,
    overlap_mask: np.ndarray,
    eps: float,
    Phi_i,            # Φ_i (Q→P)
    Phi_tilde_i,      # Φ̃_i (P→Q) (kept for signature symmetry)
    Omega_q_ij,       # Ω^q_ij (reused; no recompute)
):
    """
    Return *raw* ∂KL tensors (masked to overlap) for γ Cases A/B, summed:
      (g_mu_i_raw, g_S_i_raw, g_mu_j_raw, g_S_j_raw, {"A": KL_A, "B": KL_B})
    Weighting by γ and (1 - KL/κ) is applied by the caller.
    """

    i_id = AA.get_id(agent_i)
    j_id = int(getattr(agent_j, "id", -1))

    Sshape = tuple(overlap_mask.shape)
    Ki = int(getattr(agent_i, mu_key).shape[-1])
    Kj = int(getattr(agent_j, mu_key).shape[-1])

    g_mu_i = np.zeros(Sshape + (Ki,),    np.float32)
    g_S_i  = np.zeros(Sshape + (Ki, Ki), np.float32)
    g_mu_j = np.zeros(Sshape + (Kj,),    np.float32)
    g_S_j  = np.zeros(Sshape + (Kj, Kj), np.float32)

    if not np.any(overlap_mask):
        return g_mu_i, g_S_i, g_mu_j, g_S_j, {}

    m = overlap_mask.astype(np.float32, copy=False)

    # --- Use EdgeMaps: always returns arrays (zeros if missing) ---
    # Keys are (case, i_id, j_id) with i <- j
    gA_map, KL_A = ctx.edge.get_gamma(ctx, "A", i_id, j_id, shape=Sshape)
    gB_map, KL_B = ctx.edge.get_gamma(ctx, "B", i_id, j_id, shape=Sshape)
    
    # --- Case A raw grads (FIX: pass Phi_tilde_i) ---
    if np.any(gA_map) or np.any(KL_A):
        outA = grad_gamma_mu_sigma_dispatch(
            ctx, agent_i, agent_j,
            basis="a",
            Omega_ij=Omega_q_ij,
            Phi_tilde_i=Phi_tilde_i,   # <-- was missing
            eps=eps,
        )
        g_mu_i += m[..., None]       * np.asarray(outA["mu_rec"],  np.float32)
        g_S_i  += m[..., None, None] * np.asarray(outA["S_rec"],   np.float32)
        g_mu_j += m[..., None]       * np.asarray(outA["mu_send"], np.float32)
        g_S_j  += m[..., None, None] * np.asarray(outA["S_send"],  np.float32)


    # Case B raw grads
    if np.any(gB_map) or np.any(KL_B):
        outB = grad_gamma_mu_sigma_dispatch(
            ctx, agent_i, agent_j,
            basis="b",
            Omega_ij=Omega_q_ij,
            Phi_i=Phi_i,
            eps=eps,
        )
        g_mu_i += m[..., None]       * np.asarray(outB["mu_rec"],  np.float32)
        g_S_i  += m[..., None, None] * np.asarray(outB["S_rec"],   np.float32)
        g_mu_j += m[..., None]       * np.asarray(outB["mu_send"], np.float32)
        g_S_j  += m[..., None, None] * np.asarray(outB["S_send"],  np.float32)

    KLs = {}
    if np.any(KL_A): KLs["A"] = KL_A.astype(np.float32, copy=False)
    if np.any(KL_B): KLs["B"] = KL_B.astype(np.float32, copy=False)

    return g_mu_i, g_S_i, g_mu_j, g_S_j, KLs




def grad_gamma_mu_sigma_dispatch(
    ctx, agent_i, agent_j, *, basis,
    Omega_ij=None,         # Ω^q_{ij} : Q_j→Q_i  (… ,Kq,Kq)
    Phi_i=None,            # Φ_i      : Q_i→P_i  (… ,Kp,Kq)
    Phi_tilde_i=None,      # Φ̃_i     : P_i→Q_i  (… ,Kq,Kp)
    eps: float = 1e-8,
):
    """
    Return dict with receiver/sender μ/Σ grads for γ-basis in {"A","B","align","align_q","align_p"}.
    Prefers passed-in maps; falls back to ctx to fetch them if missing.
    """

    b = str(basis).lower()

    # ---- trivial align* → zeros (no cross-fiber μ/Σ grads) ----
    if b in {"align", "align_q", "align_p"}:
        mu_i_any = getattr(agent_i, "mu_p_field", None) or getattr(agent_i, "mu_q_field", None)
        mu_j_any = getattr(agent_j, "mu_q_field", None) or getattr(agent_j, "mu_p_field", None)
        mu_rec_0, S_rec_0   = _zeros_mu_S_like(mu_i_any)
        mu_send_0, S_send_0 = _zeros_mu_S_like(mu_j_any)
        return {"mu_rec": mu_rec_0, "S_rec": S_rec_0,
                "mu_send": mu_send_0, "S_send": S_send_0}

    # ---- maps (prefer explicit, fallback to ctx) ----
    if Omega_ij is None:
        Omega_ij = Omega(ctx, agent_i, agent_j, which="q")  # Q_j→Q_i
    if b == "a" and (Phi_tilde_i is None):
        Phi_tilde_i = Phi(ctx, agent_i, kind="p_to_q")      # P→Q
    if b == "b" and (Phi_i is None):
        Phi_i = Phi(ctx, agent_i, kind="q_to_p")            # Q→P

    # ---- cast once to float64 (stable math), keep originals for shape if needed ----
    Om_ij64   = np.asarray(Omega_ij,  np.float64, order="C")
    Phi_i64   = None if Phi_i is None else np.asarray(Phi_i, np.float64, order="C")
    Phit_i64  = None if Phi_tilde_i is None else np.asarray(Phi_tilde_i, np.float64, order="C")

    mu_q_j64  = np.asarray(agent_j.mu_q_field,    np.float64, order="C")
    Sig_q_j64 = np.asarray(agent_j.sigma_q_field, np.float64, order="C")
    mu_p_i64  = AA.get_mu_p(agent_i).astype(np.float64, order="C")
    Sig_p_i64 = AA.get_sigma_p(agent_i, sanitize=False).astype(np.float64, order="C")

    # ---- helper: Ω_ji from Ω_ij with a cheap ortho check ----
    def _omega_ji_from_ij(Om_ij):
        Om_t = np.swapaxes(Om_ij, -1, -2)
        I = Om_t @ Om_ij
        eye = np.eye(I.shape[-1], dtype=Om_ij.dtype)
        dev = np.max(np.abs(I - eye))
        if np.all(np.isfinite(I)) and dev < 1e-6:
            return Om_t
        return np.linalg.inv(Om_ij)

    if b == "a":
      

        Om_ji64 = _omega_ji_from_ij(Om_ij64)

        # --- receiver (i) ---
        dmu_rec, dS_rec = grad_gamma_A_mu_sigma_i(
            Phit_i=Phit_i64, Om_ji=Om_ji64,
            mu_q_j=mu_q_j64,  Sigma_q_j=Sig_q_j64,
            mu_p_i=mu_p_i64,  Sigma_p_i=Sig_p_i64,
            eps=eps,
        )

        # --- sender (j) ---
        dmu_send, dS_send = grad_gamma_A_mu_sigma_j(
            mu_q_j64,  Sig_q_j64,
            mu_p_i64,  Sig_p_i64,
            Phit_i=Phit_i64, Om_ji=Om_ji64,
            eps=eps, assume_sanitized=True,
        )

    elif b == "b":
        
        # --- receiver (i) ---
        dmu_rec, dS_rec = grad_gamma_B_mu_sigma_i(
            Phi_i=Phi_i64, Om_ij=Om_ij64,
            mu_q_j=mu_q_j64,  Sigma_q_j=Sig_q_j64,
            mu_p_i=mu_p_i64,  Sigma_p_i=Sig_p_i64,
            eps=eps,
        )

        # --- sender (j) ---   (precompute R once; pass along)
        R64 = np.einsum("...ik,...kj->...ij", Phi_i64, Om_ij64, optimize=True)
        dmu_send, dS_send = grad_gamma_B_mu_sigma_j(
            mu_j=mu_q_j64,  Sigma_j=Sig_q_j64,
            mu_p_i=mu_p_i64, Sigma_p_i=Sig_p_i64,
            Omega_ij=Om_ij64, Phi_i=Phi_i64,
            R=R64,
            eps=eps, assume_sanitized=True,
        )

    else:
        raise ValueError(f"Unknown gamma basis: {basis}")

    # ---- symmetry & final dtype ----
    dS_rec  = 0.5 * (dS_rec  + np.swapaxes(dS_rec,  -1, -2))
    dS_send = 0.5 * (dS_send + np.swapaxes(dS_send, -1, -2))

    return {
        "mu_rec":  np.asarray(dmu_rec,  np.float32, order="C"),
        "S_rec":   np.asarray(dS_rec,   np.float32, order="C"),
        "mu_send": np.asarray(dmu_send, np.float32, order="C"),
        "S_send":  np.asarray(dS_send,  np.float32, order="C"),
    }



# --- Self / Feedback energy accumulation (shared with diagnostics) ---


def accumulate_self_feedback_energies(
    ctx,
    agent_i,
    *,
    mu_q, S_q,
    mu_p, S_p,
    mu_q_push, S_q_push,
    mu_p_push, S_p_push,
):
    """
    Returns (self_raw, feedback_raw) as plain floats.
    No side effects here; the master will aggregate.
    """
    eps = float(cfg_get(ctx, "eps", 1e-8))
    tau = float(cfg_get(ctx, "support_tau", 1e-6))

    m  = np.asarray(getattr(agent_i, "mask", 1.0), np.float32)
    mm = (m > tau) if (m.dtype != bool) else m
    if not np.any(mm):
        return 0.0, 0.0

    μq  = np.asarray(mu_q[mm],        np.float64, order="C")
    Σq  = sanitize_sigma(np.asarray(S_q[mm],      np.float64, order="C"), eps=eps)
    μp  = np.asarray(mu_p[mm],        np.float64, order="C")
    Σp  = sanitize_sigma(np.asarray(S_p[mm],      np.float64, order="C"), eps=eps)
    μqʹ = np.asarray(mu_q_push[mm],   np.float64, order="C")
    Σqʹ = sanitize_sigma(np.asarray(S_q_push[mm], np.float64, order="C"), eps=eps)
    μpʹ = np.asarray(mu_p_push[mm],   np.float64, order="C")
    Σpʹ = sanitize_sigma(np.asarray(S_p_push[mm], np.float64, order="C"), eps=eps)

    self_px     = kl_gaussian(μq, Σq, μpʹ, Σpʹ, eps=eps)   # KL(q || p')
    feedback_px = kl_gaussian(μp, Σp, μqʹ, Σqʹ, eps=eps)   # KL(p || q')

    self_raw = float(np.sum(self_px))
    fb_raw   = float(np.sum(feedback_px))
   
    return self_raw, fb_raw





def _self_and_feedback_grads(
    mode: str,
    mu_q, sigma_q, mu_p, sigma_p,
    mu_q_push, Sigma_q_push, inv_q_push,
    mu_p_push, Sigma_p_push, inv_p_push,
    Phi_mat, Phi_tilde_mat, eps: float,
    *, sigma_q_inv=None, sigma_p_inv=None, mask=None
):
    if mode == "belief":
        g_self_mu, g_self_S = grad_self_energy_belief(
            mu_q, sigma_q, mu_p_push, inv_p_push,
            sigma_q_inv=sigma_q_inv, mask=mask
        )
        g_fb_mu, g_fb_S = grad_feedback_energy_belief(
            mu_q, sigma_q, mu_p, mu_q_push,
            Sigma_q_push, inv_q_push, sigma_p, Phi_mat
        )
        #print(f"{g_self_mu}")    
    
    elif mode == "model":
        g_self_mu, g_self_S = grad_self_energy_model(
            mu_q, sigma_q, mu_p_push, inv_p_push, Phi_tilde_mat, mask=mask
        )
        g_fb_mu, g_fb_S = grad_feedback_energy_model(
            mu_p, sigma_p, mu_q_push, Sigma_q_push, inv_q_push,
            sigma_p_inv=sigma_p_inv
        )
    else:
        raise ValueError(f"Unsupported mode: {mode}")
    return g_self_mu, g_self_S, g_fb_mu, g_fb_S




#==============================================================================
#
#                    FEEDBACK / SELF TERMS (unchanged math, safer numerics)
#==============================================================================

def grad_alignment_energy_source(
    mu_i, sigma_i, mu_j_t, sigma_j_t_inv, eps=1e-8,
    *, sigma_i_inv=None, assume_sanitized=True
):
    """
    Faster: reuse precomputed sigma_i_inv if provided; optionally skip sanitize.
    """
    mu_i       = np.asarray(mu_i,       dtype=np.float32, order="C")
    mu_j_t     = np.asarray(mu_j_t,     dtype=np.float32, order="C")
    sigma_j_t_inv = np.asarray(sigma_j_t_inv, dtype=np.float32, order="C")

    dmu = mu_i - mu_j_t
    # grad_mu_i = S'^-1 (μ_i - μ_j')
    grad_mu = np.einsum("...ij,...j->...i", sigma_j_t_inv, dmu, optimize=True)

    if sigma_i_inv is None:
        Si = np.asarray(sigma_i, dtype=np.float32, order="C")
        if not assume_sanitized:
            Si = sanitize_sigma(Si, eps=eps)
        sigma_i_inv = safe_inv(Si)   # batched cholesky-inv

    grad_sigma = 0.5 * (sigma_j_t_inv - sigma_i_inv)
    # symmetrize
    grad_sigma = 0.5 * (grad_sigma + np.swapaxes(grad_sigma, -1, -2))

    return grad_mu.astype(np.float32, copy=False), grad_sigma.astype(np.float32, copy=False)


def grad_alignment_energy_target(
    mu_i, sigma_i, mu_j_t, sigma_j_t_inv, Omega_ij, eps: float = 1e-8,
    *, assume_sanitized=True
):
    """
    Faster: use v = S'^-1 dμ  ->  v vᵀ for the middle term; skip repeated sanitize.
    """
    mu_i       = np.asarray(mu_i,       dtype=np.float32, order="C")
    mu_j_t     = np.asarray(mu_j_t,     dtype=np.float32, order="C")
    Omega_ij   = np.asarray(Omega_ij,   dtype=np.float32, order="C")
    sigma_jinv = np.asarray(sigma_j_t_inv, dtype=np.float32, order="C")

    dmu = mu_i - mu_j_t

    # ∂_{μ_j'} KL = - S'^-1 dμ  ;  map back with Ωᵀ
    gmu_jp    = -np.einsum("...ij,...j->...i", sigma_jinv, dmu, optimize=True)
    grad_mu_j = np.einsum("...ji,...j->...i", Omega_ij, gmu_jp, optimize=True)

    # Σ_i only appears (not inverted); assume sanitized upstream
    Si = np.asarray(sigma_i, dtype=np.float32, order="C")
    if not assume_sanitized:
        Si = sanitize_sigma(Si)

    # v = S'^-1 dμ  ->  v vᵀ
    v   = np.einsum("...ij,...j->...i", sigma_jinv, dmu, optimize=True)
    vvT = np.einsum("...i,...j->...ij", v, v, optimize=True)

    # gΣ' = 1/2( -S'^-1 Σ_i S'^-1 - vvᵀ + S'^-1 )
    t0 = -np.einsum("...ij,...jk,...kl->...il", sigma_jinv, Si, sigma_jinv, optimize=True)
    gSp = 0.5 * (t0 - vvT + sigma_jinv)

    # map back: Ωᵀ gΣ' Ω, then symmetrize
    grad_sigma_j = np.einsum("...ji,...jk,...kl->...il",
                             Omega_ij, gSp, np.swapaxes(Omega_ij, -1, -2), optimize=True)
    grad_sigma_j = 0.5 * (grad_sigma_j + np.swapaxes(grad_sigma_j, -1, -2))

    return grad_mu_j.astype(np.float32, copy=False), grad_sigma_j.astype(np.float32, copy=False)



def grad_feedback_energy_belief(
    mu_q, sigma_q, mu_p, mu_q_push,
    sigma_q_push, sigma_q_push_inv, sigma_p, Phi, eps=1e-8, *,
    assume_sanitized=True,
):
    """
    ∂ wrt (μ_q, Σ_q) of KL(p || Φ·q), evaluated in q-fiber.
    Uses v = S'^-1 Δ and v v^T instead of S'^-1 ΔΔ^T S'^-1 to cut temps.
    """
    # Δ = μ_p - μ_q'
    delta = (mu_p - mu_q_push).astype(np.float32, copy=False)

    # v = S'^-1 Δ  (matvec)
    v = np.matmul(sigma_q_push_inv, delta[..., None])[..., 0]  # (...,K)

    # grad_μ = - Φ^T v
    Phi_T = np.swapaxes(Phi, -1, -2)
    grad_mu = -np.matmul(Phi_T, v[..., None])[..., 0]

    # M = S'^-1  - v v^T  - S'^-1 Σ_p S'^-1
    term1 = sigma_q_push_inv
    term2 = np.matmul(v[..., :, None], v[..., None, :])        # v v^T
    term3 = np.matmul(np.matmul(sigma_q_push_inv, sigma_p), sigma_q_push_inv)

    M = term1 - term2 - term3

    # grad_Σ = 1/2 Φ^T M Φ (symmetrized)
    grad_sigma = 0.5 * np.matmul(np.matmul(Phi_T, M), Phi)
    grad_sigma = 0.5 * (grad_sigma + np.swapaxes(grad_sigma, -1, -2))

    return grad_mu.astype(np.float32, copy=False), grad_sigma.astype(np.float32, copy=False)


def grad_feedback_energy_model(
    mu_p, sigma_p, mu_q_push,
    sigma_q_push, sigma_q_push_inv, Phi=None, eps=1e-8, *,
    sigma_p_inv=None, assume_sanitized=True,
):
    """
    ∂ wrt (μ_p, Σ_p) of KL(p || q'), evaluated in p-fiber.
    Avoids inverting Σ_p if sigma_p_inv is provided.
    """
    delta = (mu_p - mu_q_push).astype(np.float32, copy=False)

    # grad_μ = S'^-1 Δ
    grad_mu = np.matmul(sigma_q_push_inv, delta[..., None])[..., 0]

    # grad_Σ = 1/2 (S'^-1 - Σ_p^{-1})
    if sigma_p_inv is None:
        # assume Σ_p already sanitized upstream; we only invert if caller didn’t pass inv
        sigma_p_inv = safe_inv(sigma_p.astype(np.float32, copy=False))
    grad_sigma = 0.5 * (sigma_q_push_inv - sigma_p_inv)
    grad_sigma = 0.5 * (grad_sigma + np.swapaxes(grad_sigma, -1, -2))

    return grad_mu.astype(np.float32, copy=False), grad_sigma.astype(np.float32, copy=False)


def grad_self_energy_belief(
    mu_q, sigma_q, mu_p_push, sigma_p_push_inv, eps=1e-8, *,
    sigma_q_inv=None, mask=None, assume_sanitized=True,
):
    """
    ∂ wrt (μ_q, Σ_q) of KL(q || p'), evaluated in q-fiber.
    Reuses sigma_q_inv if provided.
    """
    delta = (mu_q - mu_p_push).astype(np.float32, copy=False)

    # grad_μ = S_p'^-1 Δ
    grad_mu = np.matmul(sigma_p_push_inv, delta[..., None])[..., 0]

    # grad_Σ = 1/2 (S_p'^-1 - Σ_q^{-1})
    if sigma_q_inv is None:
        sigma_q_inv = safe_inv(sigma_q.astype(np.float32, copy=False))
    
    grad_sigma = 0.5 * (sigma_p_push_inv - sigma_q_inv)
    grad_sigma = 0.5 * (grad_sigma + np.swapaxes(grad_sigma, -1, -2))

    if mask is not None:
        m = (np.asarray(mask) > float(getattr(config, "support_tau", 0.0)))
        grad_mu    = grad_mu * m[..., None]
        grad_sigma = grad_sigma * m[..., None, None]

    return grad_mu.astype(np.float32, copy=False), grad_sigma.astype(np.float32, copy=False)


def grad_self_energy_model(
    mu_q, sigma_q, mu_p_push, sigma_p_push_inv, Phi_tilde, eps=1e-8, *,
    assume_sanitized=True, mask=None,
):
    """
    ∂ wrt (μ_p, Σ_p) of KL(q || p'), evaluated in p-fiber.
    Uses v = M Δ and v v^T to avoid an extra large einsum.
    """
    delta = (mu_q - mu_p_push).astype(np.float32, copy=False)

    # tmp = M Δ
    v = np.matmul(sigma_p_push_inv, delta[..., None])[..., 0]

    # grad_μ = - Φ̃^T v
    Phi_tilde_T = np.swapaxes(Phi_tilde, -1, -2)
    grad_mu = -np.matmul(Phi_tilde_T, v[..., None])[..., 0]

    # G = M - v v^T - M Σ_q M
    vvT = np.matmul(v[..., :, None], v[..., None, :])
    M_Sq = np.matmul(sigma_p_push_inv, sigma_q.astype(np.float32, copy=False))
    G = sigma_p_push_inv - vvT - np.matmul(M_Sq, sigma_p_push_inv)

    # grad_Σ = 1/2 Φ̃^T G Φ̃  (symmetrized)
    grad_sigma = 0.5 * np.matmul(np.matmul(Phi_tilde_T, G), Phi_tilde)
    grad_sigma = 0.5 * (grad_sigma + np.swapaxes(grad_sigma, -1, -2))

    if mask is not None:
        m = (np.asarray(mask) > float(getattr(config, "support_tau", 0.0)))
        grad_mu    = grad_mu * m[..., None]
        grad_sigma = grad_sigma * m[..., None, None]

    return grad_mu.astype(np.float32, copy=False), grad_sigma.astype(np.float32, copy=False)




# ---------------- A (receiver i): KL( q_j || Ω_ji[ Φ̃_i p_i ] ) — grads wrt (μ_p_i, Σ_p_i)
# ---------------- A (receiver i): KL( q_j || Ω_ji[ Φ̃_i p_i ] ) — grads wrt (μ_p_i, Σ_p_i)
def grad_gamma_A_mu_sigma_i(
    *,
    Phit_i,                  # Φ̃_i : P_i→Q_i        (..., Kq, Kp)
    Om_ji,                   # Ω^q_{ji} : Q_i→Q_j    (..., Kq, Kq)
    mu_q_j,  Sigma_q_j,      # sender q_j            (..., Kq), (..., Kq,Kq)
    mu_p_i,  Sigma_p_i,      # receiver p_i          (..., Kp), (..., Kp,Kp)
    eps: float = 1e-8,
):
    """
    ∂/∂(μ_{p_i}, Σ_{p_i}) of KL_A = KL( q_j || Ω_ji[ Φ̃_i p_i ] ).
    Uses push_gaussian for all linear pushes. Returns: dμ_p_i (*S,Kp), dΣ_p_i (*S,Kp,Kp)
    """
  
    # ---- cast/sanitize inputs (once) ----
    Phit_i = np.asarray(Phit_i,   np.float64, order="C")
    Om_ji  = np.asarray(Om_ji,    np.float64, order="C")
    mu_j   = np.asarray(mu_q_j,   np.float64, order="C")
    Sj     = sanitize_sigma(np.asarray(Sigma_q_j, np.float64), eps=eps)

    mu_p = np.asarray(mu_p_i,   np.float64, order="C")
    Sp   = sanitize_sigma(np.asarray(Sigma_p_i, np.float64), eps=eps)

    Rt = np.swapaxes

    # ---- push p_i to Q_i via Φ̃_i using push_gaussian ----
    # First push: inputs already sanitized (Sp), so skip extra sanitation here.
    mu_qhat, S_qhat = push_gaussian(
        mu_p, Sp, Phit_i,
        eps=eps, return_inv=False,
        Sigma_inv=None, assume_orthogonal=False,
        sanitize_input=False,
    )

    # ---- land in Q_j via Ω_ji; get Σ_L^{-1} directly from push_gaussian ----
    # Second push: allow push_gaussian to sanitize the landing covariance.
    mu_L, S_L, S_L_inv = push_gaussian(
        mu_qhat, S_qhat, Om_ji,
        eps=eps, return_inv=True,
        Sigma_inv=None, assume_orthogonal=False,
        sanitize_input=True,
    )

    # ---- KL(q_j || N(mu_L, S_L)) partials wrt (μ_L, Σ_L) ----
    d   = mu_L - mu_j
    v   = np.einsum("...ij,...j->...i", S_L_inv, d, optimize=True)
    vvT = np.einsum("...i,...j->...ij", v, v, optimize=True)
    term = np.einsum("...ij,...jk->...ik", S_L_inv,
                     np.einsum("...jk,...kl->...jl", Sj, S_L_inv, optimize=True),
                     optimize=True)
    dSL = 0.5 * (-term - vvT + S_L_inv)
    dSL = 0.5 * (dSL + Rt(dSL, -1, -2))

    # ---- backprop to (μ_p, Σ_p) through Ω_ji then Φ̃_i ----
    g_mu_qhat = np.einsum("...ji,...j->...i", Om_ji, v, optimize=True)                     # Ω_ji^T v
    g_S_qhat  = np.einsum("...ji,...jk,...kl->...il", Om_ji, dSL, Om_ji, optimize=True)   # Ω_ji^T dSL Ω_ji
    dmu_p     = np.einsum("...ji,...j->...i", Phit_i, g_mu_qhat, optimize=True)           # Φ̃_i^T g
    dS_p      = np.einsum("...ji,...jk,...kl->...il", Phit_i, g_S_qhat, Phit_i, optimize=True)
    dS_p      = 0.5 * (dS_p + Rt(dS_p, -1, -2))

    return dmu_p.astype(np.float32, copy=False), dS_p.astype(np.float32, copy=False)


    
def grad_gamma_A_mu_sigma_j(
    mu_q_j,  Sigma_q_j,          # sender q_j         (...,Kq), (...,Kq,Kq)
    mu_p_i,  Sigma_p_i,          # receiver p_i       (...,Kp), (...,Kp,Kp)
    *,
    Phit_i,  Om_ji,              # Φ̃_i: P→Q,  Ω_ji: Q_i→Q_j
    mask=None,
    eps: float = 1e-8,
    assume_sanitized: bool = True,
):
    """
    ∂/∂(μ_j, Σ_j) for KL_A = KL( q_j || Ω_ji[ Φ̃_i p_i ] ).
    Uses push_gaussian for linear pushes.
    Returns: (dμ_j, dΣ_j) in the sender q_j frame.
    """
   

    # ---- cast (optionally sanitize inputs) ----
    mu_j   = np.asarray(mu_q_j,    np.float64, order="C")
    Sj     = np.asarray(Sigma_q_j, np.float64, order="C")
    mu_pi  = np.asarray(mu_p_i,    np.float64, order="C")
    Sp     = np.asarray(Sigma_p_i, np.float64, order="C")
    Phit_i = np.asarray(Phit_i,    np.float64, order="C")
    Om_ji  = np.asarray(Om_ji,     np.float64, order="C")
    Rt     = np.swapaxes

    if not assume_sanitized:
        Sj = sanitize_sigma(Sj, eps=eps)
        Sp = sanitize_sigma(Sp, eps=eps)

    # ---- landing distribution: q̂_j = Ω_ji[ Φ̃_i p_i ] ----
    # 1) push to Q_i via Φ̃_i (trust input Σ_p if assume_sanitized=True)
    mu_qhat_i, S_qhat_i = push_gaussian(
        mu_pi, Sp, Phit_i,
        eps=eps, return_inv=False,
        Sigma_inv=None, assume_orthogonal=False,
        sanitize_input=False,             # don't sanitize on this hop
    )

    # 2) push to Q_j via Ω_ji, and sanitize landing Σ_hat
    mu_hat, S_hat = push_gaussian(
        mu_qhat_i, S_qhat_i, Om_ji,
        eps=eps, return_inv=False,
        Sigma_inv=None, assume_orthogonal=False,
        sanitize_input=True,              # sanitize Σ_hat for KL stability
    )

    # ---- KL(P||Q) with P=N(mu_j,Sj), Q=N(mu_hat,S_hat) — grads wrt P=(μ_j,Σ_j) ----
    Sj_inv = safe_inv(Sj, eps=max(eps, 1e-12))

    diff   = (mu_j - mu_hat)
    vj     = np.einsum("...ij,...j->...i", Sj_inv, diff, optimize=True)     # Σ_j^{-1}(μ_j-μ_hat)
    dmu_j  = vj

    # dΣ_j = 1/2( -Σ_j^{-1} + Σ_j^{-1} Σ_hat Σ_j^{-1} - Σ_j^{-1}(μ_j-μ_hat)(μ_j-μ_hat)^T Σ_j^{-1} )
    vvT    = np.einsum("...i,...j->...ij", vj, vj, optimize=True)
    term   = np.einsum("...ij,...jk,...kl->...il", Sj_inv, S_hat, Sj_inv, optimize=True)
    dS_j   = 0.5 * (-Sj_inv + term - vvT)
    dS_j   = 0.5 * (dS_j + Rt(dS_j, -1, -2))

    # ---- optional mask ----
    if mask is not None:
        m = (np.asarray(mask) > 0).astype(np.float64, copy=False)
        dmu_j = dmu_j * m[..., None]
        dS_j  = dS_j  * m[..., None, None]

    return dmu_j.astype(np.float32, copy=False), dS_j.astype(np.float32, copy=False)





def grad_gamma_B_mu_sigma_i(
    *,
    Phi_i,                 # Φ_i : Q_i→P_i        (..., Kp, Kq)
    Om_ij,                 # Ω^q_{ij} : Q_j→Q_i   (..., Kq, Kq)
    mu_q_j, Sigma_q_j,     # sender q_j stats     (..., Kq), (..., Kq,Kq)
    mu_p_i, Sigma_p_i,     # receiver p_i stats   (..., Kp), (..., Kp,Kp)
    eps: float = 1e-8,
):
    """
    ∂/∂(μ_{p_i}, Σ_{p_i}) of KL_B = KL( p_i || Φ_i[Ω_ij q_j] ), all tensors passed in.
    Returns:
      gμ_p: (*S, Kp),  gΣ_p: (*S, Kp, Kp)
    """
    
    # ---- cast/sanitize once ----
    Phi_i     = np.asarray(Phi_i,     np.float64, order="C")   # (...,Kp,Kq)
    Om_ij     = np.asarray(Om_ij,     np.float64, order="C")   # (...,Kq,Kq)
    mu_q_j    = np.asarray(mu_q_j,    np.float64, order="C")   # (...,Kq)
    Sigma_q_j = sanitize_sigma(np.asarray(Sigma_q_j, np.float64), eps=eps)
    mu_p_i    = np.asarray(mu_p_i,    np.float64, order="C")   # (...,Kp)
    Sigma_p_i = sanitize_sigma(np.asarray(Sigma_p_i, np.float64), eps=eps)
    Rt = np.swapaxes

    # ---- 1) push q_j → Q_i via Ω_ij (trust input Σ_q_j already sanitized) ----
    mu_t, Sigma_t = push_gaussian(
        mu_q_j, Sigma_q_j, Om_ij,
        eps=eps, return_inv=False,
        Sigma_inv=None, assume_orthogonal=False,
        sanitize_input=False,
    )

    # ---- 2) land in P_i via Φ_i; get Σ_L^{-1} directly and sanitize landing ----
    mu_L, Sigma_L, S_L_inv = push_gaussian(
        mu_t, Sigma_t, Phi_i,
        eps=eps, return_inv=True,
        Sigma_inv=None, assume_orthogonal=False,
        sanitize_input=True,
    )

    # ---- KL( N(μ_p,Σ_p) || N(μ_L,Σ_L) ) source-form grads in P_i ----
    S_p_inv = safe_inv(Sigma_p_i, eps=max(eps, 1e-12))

    dmu   = mu_p_i - mu_L
    gmu_p = np.einsum("...ab,...b->...a", S_L_inv, dmu, optimize=True)      # Σ_L^{-1}(μ_p−μ_L)

    
    gS_p  = 0.5 * (S_L_inv - S_p_inv)

    gS_p  = 0.5 * (gS_p + Rt(gS_p, -1, -2))                                  # symmetrize

    return gmu_p.astype(np.float32, copy=False), gS_p.astype(np.float32, copy=False)



def grad_gamma_B_mu_sigma_j(
    mu_j, Sigma_j,                  # sender q_j stats (...,Kq), (...,Kq,Kq)
    mu_p_i, Sigma_p_i,              # receiver p_i stats (...,Kp), (...,Kp,Kp)  (KL's N0)
    Omega_ij, Phi_i,                # linear maps: Ω_ij (...,Kq,Kq), Φ_i (...,Kp,Kq)
    *,
    R=None,                         # optional precomputed R = Φ_i @ Ω_ij  (...,Kp,Kq)
    mu_1=None,                      # optional landing mean:  μ_1 = R μ_j  (...,Kp)
    Sigma_1=None,                   # optional landing cov:   Σ_1 = R Σ_j R^T (...,Kp,Kp)
    Sigma_1_inv=None,               # optional Σ_1^{-1}      (...,Kp,Kp)
    Sigma_p_inv=None,               # optional Σ_p_i^{-1}    (...,Kp,Kp)
    
    eps: float = 1e-8,
    assume_sanitized: bool = True,
):
    """
    Sender-side μ/Σ gradients for Case B gating:
        KL_B = KL( p_i || Φ_i[Ω_ij q_j] ).
    Returns (dμ_j, dΣ_j) in the *sender q_j* frame.
    Uses push_gaussian for the linear pushes and sanitizes only the landing Σ_1.
    """

    # ---- cast to float64 for stable math ----
    mu_j      = np.asarray(mu_j,      np.float64, order="C")
    Sigma_j   = np.asarray(Sigma_j,   np.float64, order="C")
    mu_p_i    = np.asarray(mu_p_i,    np.float64, order="C")
    Sigma_p_i = np.asarray(Sigma_p_i, np.float64, order="C")
    Phi_i     = np.asarray(Phi_i,     np.float64, order="C")   # (...,Kp,Kq)
    Omega_ij  = np.asarray(Omega_ij,  np.float64, order="C")   # (...,Kq,Kq)
    Rt = np.swapaxes

    # Optional input sanitation (usually already sanitized upstream)
    if not assume_sanitized:
        Sigma_j   = sanitize_sigma(Sigma_j,   eps=eps)
        Sigma_p_i = sanitize_sigma(Sigma_p_i, eps=eps)

    # ---- mapping matrix for chain rule ----
# ---- mapping matrix for chain rule ----
    if R is None:
        R = np.einsum("...ik,...kj->...ij", Phi_i, Omega_ij, optimize=True)
    

    R_T = Rt(R, -1, -2)

    # ---- landing stats (μ_1, Σ_1, Σ_1^{-1}) via push_gaussian ----
    if (mu_1 is None) or (Sigma_1 is None and Sigma_1_inv is None):
        # 1) q_j -> Q_i via Ω_ij (trust input Σ_j; no extra sanitization)
        mu_t, Sigma_t = push_gaussian(
            mu_j, Sigma_j, Omega_ij,
            eps=eps, return_inv=False,
            Sigma_inv=None, assume_orthogonal=False,
            sanitize_input=False,
        )
        # 2) Q_i -> P_i via Φ_i (sanitize landing; also get Σ_1^{-1})
        mu_1_calc, Sigma_1_calc, Sigma_1_inv_calc = push_gaussian(
            mu_t, Sigma_t, Phi_i,
            eps=eps, return_inv=True,
            Sigma_inv=None, assume_orthogonal=False,
            sanitize_input=True,
        )
        if mu_1 is None:          mu_1 = mu_1_calc
        if Sigma_1 is None:       Sigma_1 = Sigma_1_calc
        if Sigma_1_inv is None:   Sigma_1_inv = Sigma_1_inv_calc
    else:
        # Ensure provided landing tensors are arrays and sanitize/invert if needed
        mu_1    = np.asarray(mu_1,    np.float64, order="C")
        Sigma_1 = None if Sigma_1 is None else np.asarray(Sigma_1, np.float64, order="C")
        if Sigma_1_inv is None:
            S1 = sanitize_sigma(Sigma_1, eps=eps)
            Sigma_1_inv = safe_inv(S1, eps=max(eps, 1e-12))

    # ---- precompute Σ_p^{-1} if not provided ----
    if Sigma_p_inv is None:
        Sp = Sigma_p_i if assume_sanitized else sanitize_sigma(Sigma_p_i, eps=eps)
        Sigma_p_inv = safe_inv(Sp, eps=max(eps, 1e-12))

    # ---- landing-frame partials for KL(N0||N1) with N0=(μ_p,Σ_p), N1=(μ_1,Σ_1) ----
    # ∂KL/∂μ_1 = - Σ_1^{-1} (μ_p - μ_1)
    dmu_1 = -np.einsum("...ij,...j->...i", Sigma_1_inv, (mu_p_i - mu_1), optimize=True)

    # ∂KL/∂Σ_1 = 1/2 ( -Σ_1^{-1} + Σ_1^{-1} Σ_p Σ_1^{-1} )
    dS_1  = -Sigma_1_inv
    dS_1 += np.einsum("...ij,...jk,...kl->...il", Sigma_1_inv, Sigma_p_i, Sigma_1_inv, optimize=True)
    dS_1 *= 0.5
    dS_1  = 0.5 * (dS_1 + Rt(dS_1, -1, -2))  # symmetrize

    # ---- map back to sender frame (q_j) ----
    dmu_j = np.einsum("...ij,...j->...i", R_T, dmu_1, optimize=True)             # (...,Kq)
    dS_j  = np.einsum("...ik,...kl,...jl->...ij", R_T, dS_1, R, optimize=True)   # (...,Kq,Kq)
    dS_j  = 0.5 * (dS_j + Rt(dS_j, -1, -2))                                       # symmetrize


    return dmu_j.astype(np.float32, copy=False), dS_j.astype(np.float32, copy=False)




def apply_natural_gradient_batch(
    ctx,
    mu_field,
    sigma_field,
    grad_mu_field,
    grad_sigma_field,
    mask=None,
    *,
    use_float64: bool = True,
    assume_sanitized: bool = True,
    grad_sigma_is_symmetric: bool = False,
    assert_finite: bool = False,
):
    """
    Vectorized natural gradient for Gaussian fields on an N-D periodic grid:
        δμ = -Σ ∇_μ L
        δΣ = -2 Σ sym(∇_Σ L) Σ

    Inputs:
      mu_field          : (*S, K)
      sigma_field       : (*S, K, K)   [SPD]
      grad_mu_field     : (*S, K)
      grad_sigma_field  : (*S, K, K)
      mask (optional)   : (*S,) bool or float weights

    Returns:
      delta_mu          : (*S, K)
      delta_sigma       : (*S, K, K)
    """
    import numpy as np
    from core.runtime_context import cfg_get

    # ---- config ----
    eps         = float(cfg_get(ctx, "eps", 1e-10))
    support_tau = float(cfg_get(ctx, "support_tau", 1e-6))
    dtype_work  = np.float64 if use_float64 else np.float32
    dtype_out   = np.float32 if not use_float64 else dtype_work

    # ---- infer spatial shape S, fiber dim K ----
    mu = np.asarray(mu_field)
    Sig = np.asarray(sigma_field)
    gmu = np.asarray(grad_mu_field)
    gSig = np.asarray(grad_sigma_field)

    if mu.ndim < 2 or Sig.ndim < 3:
        raise ValueError(f"Bad shapes: mu {mu.shape}, Sigma {Sig.shape}")

    S = mu.shape[:-1]               # *S
    K = mu.shape[-1]
    if Sig.shape[:-2] != S or Sig.shape[-2:] != (K, K):
        raise ValueError(f"sigma_field shape {Sig.shape} incompatible with mu_field {mu.shape}")

    # ---- flatten spatial for batched einsum ----
    N = int(np.prod(S, dtype=int))
    mu  = mu.astype(dtype_work, copy=False).reshape(N, K)
    Sig = Sig.astype(dtype_work, copy=False).reshape(N, K, K)
    gmu  = gmu.astype(dtype_work, copy=False).reshape(N, K)
    gSig = gSig.astype(dtype_work, copy=False).reshape(N, K, K)

    # ---- SPD sanitize Σ and symmetrize ∇Σ ----
    if not assume_sanitized:
        Sig = sanitize_sigma(Sig, eps=eps)  # must return symmetric SPD in dtype_work
    if not grad_sigma_is_symmetric:
        gSig = 0.5 * (gSig + np.swapaxes(gSig, -1, -2))

    # ---- natural steps ----
    # δμ = -Σ ∇_μ
    dmu = -np.einsum("nik,nk->ni", Sig, gmu, optimize=True)
    # δΣ = -2 Σ sym(∇_Σ) Σ
    tmp =  np.einsum("nij,njk->nik", Sig, gSig, optimize=True)
    dS  = -2.0 * np.einsum("nij,njk->nik", tmp, Sig, optimize=True)
    dS  = 0.5 * (dS + np.swapaxes(dS, -1, -2))  # symmetry guard

    # ---- mask / weights ----
    if mask is not None:
        m = np.asarray(mask)

        m_flat = m.reshape(N)
        if m.dtype == bool:
            active = m_flat
            wts = None
        else:
            wts = m_flat.astype(dtype_work, copy=False)
            active = wts > support_tau
            # soft weights
            dmu *= wts[:, None]
            dS  *= wts[:, None, None]

        # zero outside support
        if not np.all(active):
            ia = ~active
            dmu[ia] = 0.0
            dS[ia]  = 0.0


    if assert_finite:
        if not (np.isfinite(dmu).all() and np.isfinite(dS).all()):
            raise FloatingPointError("Nonfinite natural gradient (μ or Σ).")

    # ---- restore shapes / cast ----
    return (
        dmu.reshape(S + (K,)).astype(dtype_out, copy=False),
        dS.reshape(S + (K, K)).astype(dtype_out, copy=False),
    )