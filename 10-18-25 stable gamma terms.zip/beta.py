# -*- coding: utf-8 -*-
"""
Created on Sat Sep 27 15:19:10 2025

@author: chris and christine

gamma_q: Case A:  KL( q_j ||Ω^q_ji Φ̃_i p_i )
gamma_p: Case B:  KL( p_i || Φ_i Ω^q_ij q_j )  

beta_q:  KL( q_i || Ω^q_ij q_j )
beta_p:  KL( p_i || Ω^p_ij p_j ) 

"""

import numpy as np
from core.numerical_utils import sanitize_sigma, kl_gaussian, push_gaussian
from core.transport_cache import Omega,  Phi
from utils import _beta_cfg
from utils import joint_masks
from runtime_context import cfg_get
from runtime_context import EdgeMaps

_TINY32 = np.finfo(np.float32).tiny
_LOG_TINY64 = np.log(np.finfo(np.float64).tiny)



# ──────────────────────────────────────────────────────────────────────────────
# Main entry
# ──────────────────────────────────────────────────────────────────────────────


def compute_edge_betas(ctx, agents, *, which="q"):
    """
    Per-edge maps for a single fiber ('q' or 'p'), using *alignment* KL only.

    Writes ONLY via ctx.edge.set_align(...); consumers should read via
    ctx.edge.get_align(...). Joint overlap is handled by utils.joint_masks.

    Masking policy (SSOT):
      • Logits: mask via -inf (no pre-multiply).
      • Stored KL: mask via np.where(mbool, KL, 0.0).
      • Stored β:  mask once at the end via np.where(mbool, W[s], 0.0).
    """
    
    if which not in ("q", "p"):
        raise ValueError("which must be 'q' or 'p'")

    # --- unified API: clear just this fiber; no legacy dict surgery here ---
    if not hasattr(ctx, "edge") or ctx.edge is None:
        ctx.edge = EdgeMaps()
    ctx.edge.clear_fiber(which)

    # Feature toggle (still materialize zeros so downstream shapes exist)
    use_align = bool(cfg_get(ctx, "use_align_q" if which == "q" else "use_align_p", True))

    kappa, eps, _ = _beta_cfg(ctx, which)  # tau handled inside joint_masks
    _mu, _S, _mask, _mu_q, _S_q, _mu_p, _S_p = _fiber_accessors(which)
    ids = [int(getattr(a, "id", i)) for i, a in enumerate(agents)]

    for i_idx, ai in enumerate(agents):
        i_id   = ids[i_idx]
        Sshape = tuple(np.asarray(_mu(ai)).shape[:-1])

        if not use_align:
            # Write zeros for every sender to keep shapes consistent
            Z = np.zeros(Sshape, np.float32)
            for j_idx, aj in enumerate(agents):
                if j_idx == i_idx:
                    continue
                j_id = ids[j_idx]
                ctx.edge.set_align(ctx, which, i_id, j_id, kl=Z, beta=Z)
            continue

        logits_list, mask_list, send_ids = [], [], []
        kl1_store = {}

        for j_idx, aj in enumerate(agents):
            if j_idx == i_idx:
                continue
            j_id = ids[j_idx]

            # Canonical overlap mask over base space C
            mbool, _mvec = joint_masks(ctx, ai, aj)   # mbool: (*S,), mvec: (*S,1)
            if not np.any(mbool):
                # Ensure consumers see explicit zeros for non-overlaps
                Z = np.zeros(Sshape, np.float32)
                ctx.edge.set_align(ctx, which, i_id, j_id, kl=Z, beta=Z)
                continue

            # Select fiber params and transport
            if which == "q":
                Om   = Omega(ctx, ai, aj, which="q")
                mu_i, S_i = _mu_q(ai), _S_q(ai)
                mu_j, S_j = _mu_q(aj), _S_q(aj)
            else:
                Om   = Omega(ctx, ai, aj, which="p")
                mu_i, S_i = _mu_p(ai), _S_p(ai)
                mu_j, S_j = _mu_p(aj), _S_p(aj)

            # Push neighbor into receiver frame and compute alignment KL
            mu_j_t, S_j_t = push_gaussian(mu_j, S_j, Om, eps=eps)[:2]
            KL_ij = kl_gaussian(mu_i, S_i, mu_j_t, S_j_t, eps=eps)

            # Reduce any trailing latent dims if present
            if KL_ij.shape != Sshape:
                if KL_ij.shape[:len(Sshape)] == Sshape and KL_ij.ndim > len(Sshape):
                    KL_ij = KL_ij.reshape(Sshape + (-1,)).sum(axis=-1)
                else:
                    raise ValueError(f"KL dims {KL_ij.shape} incompatible with {Sshape}")

            KL_ij = KL_ij.astype(np.float32, copy=False)

            # Store masked KL for diagnostics (single masking point)
            KL_masked = np.where(mbool, KL_ij, 0.0).astype(np.float32, copy=False)
            kl1_store[(which, i_id, j_id)] = KL_masked

            # Logits: mask via -inf off-overlap (no pre-multiply)
            logits = (-KL_ij / max(kappa, eps)).astype(np.float32, copy=False)
            logits_list.append(np.where(mbool, logits, -np.inf))  # (sender, *S)
            mask_list.append(mbool)
            send_ids.append(j_id)

        if not send_ids:
            continue

        # Softmax over senders at each pixel
        L = np.stack(logits_list, axis=0)     # (Ns, *S)
        M = np.stack(mask_list,   axis=0)     # (Ns, *S) bool
        W = _softmax_over_senders(L, M, tiny=1e-12)  # (Ns, *S), zeros off-overlap

        # ---- β softmax invariant check (+ optional renorm) ----
        any_sender = np.any(M, axis=0)                 # (*S,)
        sum_beta   = np.sum(W, axis=0, dtype=np.float32)  # (*S,)
        dev_map = np.zeros_like(sum_beta, dtype=np.float32)
        dev_map[any_sender] = np.abs(sum_beta[any_sender] - 1.0)
        max_dev = float(np.nanmax(dev_map)) if np.any(any_sender) else 0.0

        tol = float(cfg_get(ctx, "beta_norm_tolerance", 1e-4))
        if max_dev > tol:
            msg = f"[β-invariant] max deviation={max_dev:.3e} (tol={tol:.1e})"
            if bool(cfg_get(ctx, "strict_beta_norm", False)):
                raise AssertionError(msg)
            else:
                tiny = 1e-12
                denom = np.where(sum_beta > tiny, sum_beta, 1.0).astype(np.float32, copy=False)
                W = W / denom  # broadcast over sender axis
                # (optional) report post-fix deviation
                sum_beta_fix = np.sum(W, axis=0, dtype=np.float32)
                dev_fix = np.zeros_like(sum_beta_fix, dtype=np.float32)
                dev_fix[any_sender] = np.abs(sum_beta_fix[any_sender] - 1.0)
                max_dev_fix = float(np.nanmax(dev_fix)) if np.any(any_sender) else 0.0
                print(msg + f" → renorm → max deviation={max_dev_fix:.3e}")

        # Store β and KL maps through the unified API (mask once, here)
        for s, j_id in enumerate(send_ids):
            beta_ij = np.where(mask_list[s], W[s], 0.0).astype(np.float32, order="C")
            ctx.edge.set_align(
                ctx, which, i_id, j_id,
                kl=kl1_store[(which, i_id, j_id)],
                beta=beta_ij,
            )

    return ctx



def compute_edge_gammas(ctx, agents, *, kappa_q=None, kappa_p=None, eps=1e-8):
    """
    Build gamma maps for all directed pairs (i,j) using canonical joint masks over the base space C.

    Case A (store under ("A", j_id, i_id)):  γ_A(j→i, x) = exp( - KL(q_j || Ω^q_ji[ Φ̃_i p_i ]) / kappa_q )
    Case B (store under ("B", i_id, j_id)):  γ_B(i→j, x) = exp( - KL(p_i || Φ_i[ Ω^q_ij q_j ]) / kappa_p )

    Writes ONLY via ctx.edge.set_gamma(...); consumers should read via
    ctx.edge.get_gamma(...). Off-overlap entries are explicitly zeroed
    so downstream code never sees missing keys.

    Invariants enforced here (config-tunable):
      - γ maps are finite and within [0, 1] on overlaps (numerically ≤ 1 + tol).
    """
   
    if not agents:
        return ctx

    if not hasattr(ctx, "edge") or ctx.edge is None:
        ctx.edge = EdgeMaps()
    ctx.edge.gamma.clear()
    ctx.edge.klX.clear()

    eps = float(eps)
    kq  = float(cfg_get(ctx, "kappa_gamma_q", 1.0) if kappa_q is None else kappa_q)
    kp  = float(cfg_get(ctx, "kappa_gamma_p", 1.0) if kappa_p is None else kappa_p)
    A_off = bool(cfg_get(ctx, "gamma_A_off", False))
    B_off = bool(cfg_get(ctx, "gamma_B_off", False))

    tol_gamma = float(cfg_get(ctx, "gamma_tolerance", 1e-6))
    strict_gamma = bool(cfg_get(ctx, "strict_gamma_bounds", False))

    ids = [int(getattr(a, "id", i)) for i, a in enumerate(agents)]

    for i_idx, ai in enumerate(agents):
        i_id = ids[i_idx]

        # Receiver-specific morphisms (reuse across senders)
        Phi_i  = np.asarray(Phi(ctx, ai, kind="q_to_p"), np.float64)
        Phit_i = np.asarray(Phi(ctx, ai, kind="p_to_q"), np.float64)

        mu_p_i = np.asarray(getattr(ai, "mu_p_field"))
        S_p_i  = np.asarray(getattr(ai, "sigma_p_field"))

        gA_stack, gB_stack, mask_union = [], [], None
        sender_ids = []

        for j_idx, aj in enumerate(agents):
            if j_idx == i_idx:
                continue
            j_id = ids[j_idx]

            # Base-space overlap mask (shared by all fibers)
            mbool, _ = joint_masks(ctx, ai, aj)       # (*S,), (*S,1)
            Sshape = mbool.shape

            if not np.any(mbool):
                Z = np.zeros(Sshape, np.float32)
                ctx.edge.set_gamma(ctx, "A", j_id, i_id, gamma_map=Z, kl_map=None)
                ctx.edge.set_gamma(ctx, "B", i_id, j_id, gamma_map=Z, kl_map=None)
                continue

            # ---- Case A ----
            if A_off:
                gamma_A = np.zeros(Sshape, np.float32)
                KL_A_out = None
            else:
                Om_ji_q = Omega(ctx, aj, ai, which="q")
                mu_phit_i, S_phit_i = push_gaussian(mu_p_i, S_p_i, Phit_i, eps=eps)[:2]
                mu_phit_i_t, S_phit_i_t = push_gaussian(mu_phit_i, S_phit_i, Om_ji_q, eps=eps)[:2]

                KL_A_full = kl_gaussian(
                    np.asarray(getattr(aj, "mu_q_field")),
                    np.asarray(getattr(aj, "sigma_q_field")),
                    mu_phit_i_t, S_phit_i_t, eps=eps
                )
                if KL_A_full.shape != Sshape:
                    if KL_A_full.shape[:len(Sshape)] == Sshape and KL_A_full.ndim > len(Sshape):
                        KL_A = KL_A_full.reshape(Sshape + (-1,)).sum(axis=-1)
                    else:
                        raise ValueError(f"KL_A dims {KL_A_full.shape} incompatible with {Sshape}")
                else:
                    KL_A = KL_A_full
                KL_A = KL_A.astype(np.float32, copy=False)

                # Compute exp only on overlap
                gamma_A = np.zeros(Sshape, np.float32)
                idx = mbool
                if np.any(idx):
                    gamma_A[idx] = np.exp(-KL_A[idx] / max(kq, eps, 1e-12)).astype(np.float32, copy=False)

                KL_A_out = np.where(mbool, KL_A, 0.0).astype(np.float32, copy=False)

            ctx.edge.set_gamma(ctx, "A", j_id, i_id, gamma_map=gamma_A, kl_map=KL_A_out)

            # ---- Case B ----
            if B_off:
                gamma_B = np.zeros(Sshape, np.float32)
                KL_B_out = None
            else:
                Om_ij_q = Omega(ctx, ai, aj, which="q")
                mu_qj_t, S_qj_t = push_gaussian(
                    np.asarray(getattr(aj, "mu_q_field")),
                    np.asarray(getattr(aj, "sigma_q_field")),
                    Om_ij_q, eps=eps
                )[:2]
                mu_phi_i, S_phi_i = push_gaussian(mu_qj_t, S_qj_t, Phi_i, eps=eps)[:2]

                KL_B_full = kl_gaussian(mu_p_i, S_p_i, mu_phi_i, S_phi_i, eps=eps)
                if KL_B_full.shape != Sshape:
                    if KL_B_full.shape[:len(Sshape)] == Sshape and KL_B_full.ndim > len(Sshape):
                        KL_B = KL_B_full.reshape(Sshape + (-1,)).sum(axis=-1)
                    else:
                        raise ValueError(f"KL_B dims {KL_B_full.shape} incompatible with {Sshape}")
                else:
                    KL_B = KL_B_full
                KL_B = KL_B.astype(np.float32, copy=False)

                gamma_B = np.zeros(Sshape, np.float32)
                idx = mbool
                if np.any(idx):
                    gamma_B[idx] = np.exp(-KL_B[idx] / max(kp, eps, 1e-12)).astype(np.float32, copy=False)

                KL_B_out = np.where(mbool, KL_B, 0.0).astype(np.float32, copy=False)

            ctx.edge.set_gamma(ctx, "B", i_id, j_id, gamma_map=gamma_B, kl_map=KL_B_out)

            # diagnostics stacks
            mask_union = mbool if mask_union is None else np.logical_or(mask_union, mbool)
            gA_stack.append(gamma_A)
            gB_stack.append(gamma_B)
            sender_ids.append(j_id)

        # ---- bounds / finiteness checks on overlaps (unchanged behavior) ----
        if sender_ids:
            GA = np.stack(gA_stack, axis=0).astype(np.float32, copy=False)
            GB = np.stack(gB_stack, axis=0).astype(np.float32, copy=False)
            any_sender = mask_union

            def _check_bounds(name, G):
                G_act = G[:, any_sender] if np.any(any_sender) else G[:, ...]
                if G_act.size == 0:
                    return
                max_val = float(np.nanmax(G_act))
                min_val = float(np.nanmin(G_act))
                nonfinite = int(np.sum(~np.isfinite(G_act)))
                if (max_val > 1.0 + tol_gamma) or (min_val < -tol_gamma) or nonfinite:
                    msg = (f"[gamma-bounds:{name}] max={max_val:.6f}, min={min_val:.6f}, "
                           f"nonfinite={nonfinite}, tol={tol_gamma:.1e}, recv={i_id}")
                    if strict_gamma:
                        raise AssertionError(msg)
                    else:
                        print(msg)

            _check_bounds("A", GA)
            _check_bounds("B", GB)

    return ctx





def compute_edge_phase(ctx, agents, *, build_q=True, build_p=True, eps=1e-8):
    """
    One call to populate per-edge state for the step:
      - ALIGN: β and KL1 for requested fibers
      - Γ maps (A/B) and their KL diagnostics
    Uses the same logic as compute_edge_betas / compute_edge_gammas but
    centralizes the pass and writes through the EdgeMaps API.
    """
    if build_q:
        compute_edge_betas(ctx, agents, which="q")
    if build_p:
        compute_edge_betas(ctx, agents, which="p")
    # γ always uses Ω^q in your current spec
    compute_edge_gammas(ctx, agents, eps=eps)
    return ctx

# ──────────────────────────────────────────────────────────────────────────────
# Accessors / config helpers
# ──────────────────────────────────────────────────────────────────────────────

def _fiber_accessors(which: str):
    """Return closures to get μ, Σ, and mask for active fiber, plus q/p helpers."""
    if which not in ("q", "p"):
        raise ValueError("_fiber_accessors: which must be 'q' or 'p'")

    def _mu(a):
        return np.asarray(getattr(a, "mu_q_field" if which == "q" else "mu_p_field"), np.float32)

    def _S(a):
        base = getattr(a, "sigma_q_field" if which == "q" else "sigma_p_field")
        return sanitize_sigma(np.asarray(base, np.float64))

    def _mask(a):
        m = np.asarray(getattr(a, "mask"), np.float32)
        if m.ndim >= 1 and m.shape[-1] == 1:
            m = m[..., 0]
        return m

    # helpers for the "other" fiber (used by A–D bases)
    def _mu_q(a): return np.asarray(getattr(a, "mu_q_field"), np.float32)
    def _S_q(a):  return sanitize_sigma(np.asarray(getattr(a, "sigma_q_field"), np.float64))
    def _mu_p(a): return np.asarray(getattr(a, "mu_p_field"), np.float32)
    def _S_p(a):  return sanitize_sigma(np.asarray(getattr(a, "sigma_p_field"), np.float64))

    return _mu, _S, _mask, _mu_q, _S_q, _mu_p, _S_p





# ──────────────────────────────────────────────────────────────────────────────
# KL builders
# ──────────────────────────────────────────────────────────────────────────────
def _softmax_over_senders(logits: np.ndarray, mask: np.ndarray, tiny: float = 1e-12):
    """
    Masked softmax over axis 0 (senders). Shapes (J,*S).
    - Zero weights where no sender is valid at a pixel.
    - NaN/±inf-safe under strict np.seterr.
    - Underflow-safe when casting to float32: clamp subnormals to 0 then renormalize.
    """
    

    L = np.asarray(logits, np.float64)
    M = np.asarray(mask, dtype=bool)

    # valid := on-mask AND finite
    valid = M & np.isfinite(L)
    any_valid = np.any(valid, axis=0, keepdims=True)  # (1,*S)

    # Max over valid entries; -inf where none are valid
    L_masked = np.where(valid, L, -np.inf)
    Lmax = np.max(L_masked, axis=0, keepdims=True)
    Lmax_safe = np.where(np.isfinite(Lmax), Lmax, 0.0)  # avoid (-inf)-(-inf)

    with np.errstate(invalid='ignore', over='ignore', under='ignore'):
        shifted = L - Lmax_safe
        shifted = np.where(valid, shifted, -np.inf)
        expL = np.exp(shifted)
        expL = np.where(valid, expL, 0.0)

    Z = np.sum(expL, axis=0, keepdims=True)
    Z = np.where(any_valid, np.maximum(Z, tiny), 1.0)

    W = expL / Z
    W = np.where(any_valid, W, 0.0)

    # ---- Underflow-safe cast to float32 ----
    # Clamp subnormals to zero, then renormalize across senders.
    tiny32 = np.finfo(np.float32).tiny  # ~1.1754944e-38
    W = np.where(W < tiny32, 0.0, W)

    sumW = np.sum(W, axis=0, keepdims=True)
    # If we zeroed some tiny entries, re-normalize to keep sum=1 where valid
    sumW_safe = np.where(any_valid, np.maximum(sumW, 1.0), 1.0)
    W = np.where(any_valid, W / sumW_safe, 0.0)

    # Now casting cannot underflow (we only have zeros or >= tiny32)
    return W.astype(np.float32, copy=False)







def _edge_key(which, i_id, j_id):
    # kept for compatibility if anything else still uses it
    return (str(which), int(i_id), int(j_id))


def _ensure_edgemaps(ctx):
    if not hasattr(ctx, "edge") or ctx.edge is None:
        ctx.edge = EdgeMaps()
    return ctx.edge


def beta_align_maps(ctx, agent_i, agent_j, *, which: str):
    """
    Read-only accessor for ALIGN maps produced earlier.
    Now reads via ctx.edge.get_align(...) and ALWAYS returns arrays.

    Returns:
        KL_ij, beta_ij  (each shape (*S,), float32)
    """
    edge = _ensure_edgemaps(ctx)

    # Determine receiver spatial shape via canonical mask helper
    mbool, _mvec = joint_masks(ctx, agent_i, agent_j)  # mbool: (*S,)
    Sshape = mbool.shape

    i_id = int(getattr(agent_i, "id", -1))
    j_id = int(getattr(agent_j, "id", -1))

    # get_align returns (beta, kl); legacy callers expect (KL, beta)
    beta_map, kl_map = edge.get_align(ctx, str(which), i_id, j_id, shape=Sshape) or (None, None)

    if beta_map is None:
        Z = np.zeros(Sshape, np.float32)
        return Z, Z

    beta_map = np.asarray(beta_map, np.float32, order="C")
    kl_map   = np.asarray(kl_map,   np.float32, order="C") if kl_map is not None else np.zeros_like(beta_map)

    return kl_map, beta_map



def normalize_gamma_sumcap(gamma_stack, cap=1.0, eps=1e-6):
    """
    gamma_stack: (..., J) gammas to all neighbors at each voxel
    Per-voxel sum-cap: scale down only if sum exceeds `cap`.
    """
    s = np.clip(np.sum(gamma_stack, axis=-1, keepdims=True), 0.0, None)
    scale = np.minimum(1.0, cap / (s + eps))
    return gamma_stack * scale


def normalize_gamma_rowsum(gamma_stack, eps=1e-6):
    s = np.sum(gamma_stack, axis=-1, keepdims=True)
    return gamma_stack / (s + eps)  # mass=1 when there is at least one neighbor



def gamma_maps(ctx, agent_i, agent_j, *, include_kl: bool = True):
    """
    Fetch γ and (optionally) KL maps for ordered edge (i <- j) using ctx.edge.get_gamma.
    Keys:
      A: ("A", j->i)   B: ("B", i->j)

    Returns dict:
      include_kl=True  -> {"A": (KL_A, γ_A), "B": (KL_B, γ_B)}  (omits missing)
      include_kl=False -> {"A": γ_A, "B": γ_B}
    """
    edge = _ensure_edgemaps(ctx)

    # Shape via canonical joint mask on q-grid
    mbool, _mvec = joint_masks(ctx, agent_i, agent_j)
    Sshape = mbool.shape

    i_id = int(getattr(agent_i, "id", -1))
    j_id = int(getattr(agent_j, "id", -1))

    out = {}

    # Case A: j -> i
    gA, kA = edge.get_gamma(ctx, "A", j_id, i_id, shape=Sshape) or (None, None)
    if gA is not None:
        gA = np.asarray(gA, np.float32, order="C")
        if include_kl:
            kA = np.zeros(Sshape, np.float32) if kA is None else np.asarray(kA, np.float32, order="C")
            out["A"] = (kA, gA)
        else:
            out["A"] = gA

    # Case B: i -> j
    gB, kB = edge.get_gamma(ctx, "B", i_id, j_id, shape=Sshape) or (None, None)
    if gB is not None:
        gB = np.asarray(gB, np.float32, order="C")
        if include_kl:
            kB = np.zeros(Sshape, np.float32) if kB is None else np.asarray(kB, np.float32, order="C")
            out["B"] = (kB, gB)
        else:
            out["B"] = gB

    return out


def edge_maps_for_align(ctx, agent_i, agent_j, *, which: str):
    """
    Convenience wrapper so other modules don't touch private dicts.
    Returns (KL_align_ij, beta_ij) for ordered edge (i <- j).
    """
    edge = _ensure_edgemaps(ctx)

    # Shape via canonical mask (keeps behavior consistent everywhere)
    mbool, _mvec = joint_masks(ctx, agent_i, agent_j)
    Sshape = mbool.shape

    i_id = int(getattr(agent_i, "id", -1))
    j_id = int(getattr(agent_j, "id", -1))

    beta_map, kl_map = edge.get_align(ctx, str(which), i_id, j_id, shape=Sshape) or (None, None)
    if beta_map is None:
        Z = np.zeros(Sshape, np.float32)
        return Z, Z

    beta_map = np.asarray(beta_map, np.float32, order="C")
    kl_map   = np.asarray(kl_map,   np.float32, order="C") if kl_map is not None else np.zeros_like(beta_map)
    return kl_map, beta_map





