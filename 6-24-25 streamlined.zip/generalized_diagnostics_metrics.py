# diagnostics_metrics.py

import numpy as np
import config
from scipy.ndimage import laplace
from typing import Dict, List, Any

from joblib import Parallel, delayed
from get_generators import get_generators
from generalized_math_utils import sanitize_q, masked_norm, laplacian_field

from generalized_omega import (
    exp_lie_algebra_irrep,
    batch_apply_omega,
    repair_if_forgotten_batch,
    compute_field_strength,
    build_inter_agent_omega
)

_DEFAULT_CUTOFF = getattr(config, "support_cutoff_eps", 1e-3)


def support_mask(mask, cutoff=_DEFAULT_CUTOFF):
    return (mask > cutoff)

def overlap_mask(mask_i, mask_j, cutoff=_DEFAULT_CUTOFF):
    return support_mask(mask_i, cutoff) & support_mask(mask_j, cutoff)


def threshold_mask(mask: np.ndarray) -> np.ndarray:
    """
    Turn a float support field into a boolean support region.
    Works for any dimensionality of mask.
    """
    eps = getattr(config, "support_cutoff_eps", 1e-3)
    return mask > eps  # same shape, but boolean

def kl_divergence(p, q, eps=1e-9):
    """Pointwise D_KL(p || q) along the last axis."""
    p = sanitize_q(p, eps)
    q = sanitize_q(q, eps)
    return np.sum(p * (np.log(p) - np.log(q)), axis=-1)

def compute_kl_field(agents, i):
    q = sanitize_q(agents[i].q)
    p = sanitize_q(agents[i].p)
    kl = kl_divergence(q, p)
    return kl * agents[i].mask

def compute_coherence(phi: np.ndarray, mask: np.ndarray) -> float:
    # use the same threshold for boolean selection
    mask_bool = threshold_mask(mask)
    phis = phi[mask_bool]         # shape (n_points,)
    return np.abs(np.mean(np.exp(1j * phis)))


#USED OPNLY IN RUNSIM
def compute_phi_norm_field(agents, i, phi_field="phi"):
    phi = getattr(agents[i], phi_field)
    return np.linalg.norm(phi, axis=-1) * agents[i].mask

#USED A LOT
def compute_alignment_field(
    agents,
    i,
    eps: float = config.support_cutoff_eps,
    log_eps: float = config.log_eps
) -> np.ndarray:
    """
    Compute per‐pixel KL alignment D_KL(q_i || Ω_{ij} q_j) averaged over neighbors,
    using each Agent’s cached Omega & Omega_inv fields.
    """
    A = agents[i]
    mask_i = A.mask > eps

    # no support or no neighbors
    if not mask_i.any() or not A.neighbors:
        return np.zeros_like(mask_i, float)

    # sanitize once
    q_i_full = sanitize_q(A.q, eps=log_eps)

    # accumulators
    kl_accum = np.zeros_like(mask_i, float)
    n_nb_at  = np.zeros_like(mask_i, int)

    for nb in A.neighbors:
        B = agents[nb["id"]]
        mask_j  = B.mask > eps
        overlap = mask_i & mask_j
        if not overlap.any():
            continue

        # slice out overlapping values
        qi_pts = q_i_full[overlap]                               # (M, K)
        qj_pts = sanitize_q(B.q, eps=log_eps)[overlap]           # (M, K)

        # grab cached Ω and Ω⁻¹ for each pixel
        Oi_patch    = A.Omega[overlap]       # (M, K, K)
        Oj_inv_patch= B.Omega_inv[overlap]   # (M, K, K)

        # build inter‐agent Ω_ij(x) = Oi @ Oj_inv
        Omegas_ij = np.einsum("mab,mbc->mac", Oi_patch, Oj_inv_patch)

        # rotate q_j and sanitize
        qj_trans = batch_apply_omega(qj_pts, Omegas_ij)
        qj_trans = sanitize_q(qj_trans, eps=log_eps)

        # accumulate KL at these pixels
        kl_vals = kl_divergence(qi_pts, qj_trans)  # shape (M,)
        kl_accum[overlap] += kl_vals
        n_nb_at [overlap] += 1

    # avoid divide‐by‐zero
    denom = np.where(n_nb_at > 0, n_nb_at, 1)

    # return per‐pixel average KL inside support, zero outside
    return (kl_accum / denom) * mask_i


#USED A LOT!
def compute_model_alignment_field(
    agents,
    i,
    eps: float = config.support_cutoff_eps,
    log_eps: float = config.log_eps
) -> np.ndarray:
    """
    Exactly like compute_alignment_field, but uses each agent's p & phi_model.
    Returns the per‐pixel model‐alignment field for agent i.
    """
    A = agents[i]
    # swap in p & phi_model
    q_saved, phi_saved = A.q, A.phi
    A.q, A.phi = A.p, A.phi_model

    try:
        # now call without generators
        field = compute_alignment_field(agents, i, eps=eps, log_eps=log_eps)
    finally:
        # restore q & phi
        A.q, A.phi = q_saved, phi_saved

    return field






#USED ONLY IN RUN_SIM AND LOG_ALL_METRICS
def compute_phi_norm(
    agents,
    phi_field="phi",
    mask_field="mask",
    support_cutoff_eps=1e-3,
):
    norms = []
    for agent in agents:
        phi  = getattr(agent, phi_field)
        mask = getattr(agent, mask_field) > support_cutoff_eps
        n    = mask.sum()
        if n > 0:
            norms.append(masked_norm(phi, mask) / n)
    return float(np.mean(norms)) if norms else 0.0

#USED ONLY IN RUN SIM
def compute_entropy_field(agents, i, q_field="q", mask_field="mask", support_cutoff_eps=1e-3, log_eps=1e-8):
    q     = sanitize_q(getattr(agents[i], q_field), eps=log_eps)
    mask  = getattr(agents[i], mask_field) > support_cutoff_eps
    ent   = -np.sum(q * np.log(q), axis=-1)
    return ent * mask


#USED IN LOG_ALL_METRICS
def compute_phi_laplacian_norm(
    agents,
    phi_field: str = "phi",
    mask_field: str = "mask",
    support_cutoff_eps: float | None = None,
    log_eps: float = 1e-8,
) -> float:
    """
    Compute the average per-agent RMS norm of the Laplacian of the φ field.
    1) Threshold mask by support_cutoff_eps.
    2) Compute componentwise Laplacian via scipy.ndimage.laplace.
    3) Compute masked_norm over support and normalize by support size.
    4) Return the mean over all agents.
    """
    if support_cutoff_eps is None:
        support_cutoff_eps = _DEFAULT_CUTOFF

    norms = []
    for agent in agents:
        phi = getattr(agent, phi_field)
        mask = getattr(agent, mask_field) > support_cutoff_eps
        if not np.any(mask):
            continue

        # componentwise Laplacian
        lap_phi = np.stack([laplace(phi[..., d]) for d in range(phi.shape[-1])], axis=-1)
        # RMS norm over support
        val = masked_norm(lap_phi, mask) / (np.count_nonzero(mask) + log_eps)
        norms.append(val)

    return float(np.mean(norms)) if norms else 0.0


#NOT USED FOR SOME DUMB REASON
def compute_cross_model_kl(
    agents,
    support_eps: float = config.support_cutoff_eps,
    log_eps: float     = config.log_eps,
    n_jobs: int        = 1,
) -> float:
    """
    Compute average D_KL(q_i || ~Ω_{ij} p_j) over unique overlapping agent pairs,
    where ~Ω_{ij}(x) = exp(φ_i(x)) @ exp(-φ_model_j(x)), by re-using cached Omegas.
    """

    def _pair_kl(i, j):
        Ai = agents[i]
        Aj = agents[j]

        # 1) overlap mask
        mi = Ai.mask > support_eps
        mj = Aj.mask > support_eps
        ov = mi & mj
        if not ov.any():
            return 0.0, 0.0

        # 2) extract & sanitize distributions
        qi = sanitize_q(Ai.q[ov], eps=log_eps)       # (M, K)
        pj = sanitize_q(Aj.p[ov], eps=log_eps)       # (M, K)

        # 3) grab cached transports
        #    - belief transport at i:     (M, K, K)
        #    - model transport inverse at j: (M, K, K)
        Oi_belief     = Ai.Omega       [ov]
        Oj_model_inv  = Aj.Omega_model_inv[ov]

        # 4) build ~Ω_ij = Oi_belief @ Oj_model_inv
        Omegas_tilde = np.einsum("mab,mbc->mac",
                                 Oi_belief,
                                 Oj_model_inv)

        # 5) transport p_j into q-space
        pj_rot = batch_apply_omega(pj, Omegas_tilde)     # (M, K)
        pj_rot = repair_if_forgotten_batch(pj_rot, eps=log_eps)
        # re-normalize just in case
        pj_rot /= (pj_rot.sum(axis=-1, keepdims=True) + log_eps)

        # 6) pointwise KL
        kl_vals = np.sum(qi * (np.log(qi) - np.log(pj_rot + log_eps)), axis=-1)
        return float(kl_vals.sum()), float(ov.sum())

    # unique i<j neighbor pairs
    pairs = [
        (i, nb["id"])
        for i, A in enumerate(agents)
        for nb in A.neighbors
        if nb["id"] > i
    ]

    # parallel compute
    results = Parallel(n_jobs=n_jobs, backend="threading")(
        delayed(_pair_kl)(i, j) for i, j in pairs
    )

    total_kl    = sum(k for k, w in results)
    total_count = sum(w for k, w in results)
    return float(total_kl / (total_count + log_eps)) if total_count > 0 else 0.0


def log_all_metrics_fused(
    agents,
    step: int,
    params: dict | None = None,
    q_field: str              = "q",
    p_field: str              = "p",
    phi_belief_field: str     = "phi",
    phi_model_field: str      = "phi_model",
    mask_field: str           = "mask",
    overlap_eps: float | None = None,
    log_eps: float            = 1e-8,
    n_jobs: int               = 1,
    generators=None           # ← this will be your Lie‐algebra gens
) -> dict:
    """
    Single‐pass diagnostics: energy + all per-agent norms in one Parallel loop.
    """
    import numpy as np
    from joblib import Parallel, delayed

    from generalized_math_utils import sanitize_q, laplacian_field
    from generalized_omega      import batch_apply_omega, compute_field_strength

    # pull in all of our weights, with sensible defaults
    cfg = params or {k: getattr(config, k) for k in dir(config) if not k.startswith("__")}
    if overlap_eps is None:
        overlap_eps = cfg.get("support_cutoff_eps", config.support_cutoff_eps)

    alpha                   = cfg.get("alpha",           config.alpha)
    beta                    = cfg.get("beta",            config.beta)
    gamma                   = cfg.get("gamma",           config.gamma)                   # belief‐Laplacian
    gauge_weight            = cfg.get("gauge_weight",    config.gauge_weight)            # belief‐mass
    model_align_weight      = cfg.get("model_align_weight",  config.model_align_weight)
    model_feedback_weight   = cfg.get("model_feedback_weight", config.model_feedback_weight)
    model_gauge_weight      = cfg.get("model_gauge_weight",   config.model_gauge_weight)
    model_mass_weight       = cfg.get("model_mass_weight",    config.model_mass_weight)
    phi_phi_tilde_coupling  = cfg.get("phi_phi_tilde_coupling", config.phi_phi_tilde_coupling)
    curvature_weight        = cfg.get("curvature_weight",     config.curvature_weight)

    lie_gens = get_generators(config.group_name, config.K)
        
    # precompute lists for parallel loop
    Q_list, P_list, Mask_list = [], [], []
    O_bel, O_inv, O_mod, O_mod_inv = [], [], [], []
    for A in agents:
        mask = getattr(A, mask_field) > overlap_eps
        Mask_list.append(mask)
        Q_list.append(sanitize_q(getattr(A, q_field), eps=log_eps))
        P_list.append(sanitize_q(getattr(A, p_field), eps=log_eps))
        O_bel.append(A.Omega)
        O_inv.append(A.Omega_inv)
        O_mod.append(A.Omega_model)
        O_mod_inv.append(A.Omega_model_inv)

    N = len(agents)

    def _agent_stats(
        i,
        A,
        step,
        q_field,
        p_field,
        phi_belief_field,
        phi_model_field,
        mask_field,
        cfg,
        generators
    ):
        
        # unpack
        A    = agents[i]
        mask = Mask_list[i]
        if not mask.any():
            # no support → all zeros
            return i, {
                "e_self":0, "e_align":0, "e_feedback":0, "e_mod_align":0,
                "e_lap_bel":0, "e_mass_bel":0, "e_lap_mod":0, "e_mass_mod":0,
                "e_couple":0, "e_curv":0, "e_curv_mod":0,
                "phi_norm":0, "phi_model_norm":0, "entropy":0,
                "lap_phi_norm":0, "delta_phi_norm":0,
                "curvature_norm":0, "curvature_model_norm":0,
                "fisher_information":0,
                "model_arr": np.zeros(N, dtype=float)
            }

        # core fields
        qi = Q_list[i];  pi = P_list[i]

        # 1) Self‐KL
        e_self = alpha * np.sum( kl_divergence(qi, pi)[mask] )

        # 2) Belief‐alignment KL
        e_align = 0.0
        for nb in A.neighbors:
            j  = nb["id"]
            ov = mask & Mask_list[j]
            if not ov.any(): continue
            q_i_ov = qi[ov]
            q_j_ov = Q_list[j][ov]
            Ω = np.einsum("mab,mbc->mac",
                         O_bel[i][ov], O_inv[j][ov])
            qj_t = sanitize_q(batch_apply_omega(q_j_ov, Ω), eps=log_eps)
            e_align += beta * np.sum( kl_divergence(q_i_ov, qj_t) )

        # 3) Feedback KL(p||q)
        e_feedback = model_feedback_weight * np.sum(
            kl_divergence(pi, qi)[mask]
        )

        # 4) Model‐alignment KL
        e_mod_align = 0.0
        for nb in A.neighbors:
            j  = nb["id"]
            ov = mask & Mask_list[j]
            if not ov.any(): continue
            p_i_ov = pi[ov]
            p_j_ov = P_list[j][ov]
            Ωm = np.einsum("mab,mbc->mac",
                          O_mod[i][ov], O_mod_inv[j][ov])
            pj_t = sanitize_q(batch_apply_omega(p_j_ov, Ωm), eps=log_eps)
            e_mod_align += model_align_weight * np.sum(
                kl_divergence(p_i_ov, pj_t)
            )

        # 5) Belief‐Laplacian
        lap_phi = laplacian_field(A.phi)
        e_lap_bel = gamma * np.sum(
            np.linalg.norm(lap_phi[mask], axis=-1)
        )

        # 6) Belief‐mass
        e_mass_bel = gauge_weight * np.sum(
            np.linalg.norm(A.phi[mask], axis=-1)**2
        )

        # 7) Model‐Laplacian
        lap_phi_m = laplacian_field(A.phi_model)
        e_lap_mod = model_gauge_weight * np.sum(
            np.linalg.norm(lap_phi_m[mask], axis=-1)
        )

        # 8) Model‐mass
        e_mass_mod = model_mass_weight * np.sum(
            np.linalg.norm(A.phi_model[mask], axis=-1)**2
        )

        # 9) φ–φ_model coupling
        diff = A.phi[mask] - A.phi_model[mask]
        e_couple = phi_phi_tilde_coupling * np.sum(
            np.linalg.norm(diff, axis=-1)**2
        )

        # 10) Belief‐curvature
        Fdict = compute_field_strength(A.phi, lie_gens)
        mean_F = np.mean(np.stack(list(Fdict.values()), axis=-1), axis=-1)
        curvature_norm       = float(np.sum(mean_F[mask]))
        e_curv               = curvature_weight * curvature_norm


        # 11) Model‐curvature
        Fdict_m = compute_field_strength(A.phi_model, lie_gens)
        mean_Fm = np.mean(np.stack(list(Fdict_m.values()), axis=-1), axis=-1)
        curvature_model_norm = float(np.sum(mean_Fm[mask]))
        e_curv_mod           = curvature_weight * curvature_model_norm

        # diagnostics
        q_s   = sanitize_q(qi, eps=log_eps)[mask]
        phi_s = A.phi[mask]
        phi_m = A.phi_model[mask]
        phi_norm       = np.linalg.norm(phi_s, axis=-1).sum()
        phi_model_norm = np.linalg.norm(phi_m, axis=-1).sum()
        entropy        = float(-np.sum(q_s * np.log(q_s + log_eps)))
        lap_phi_norm   = np.linalg.norm(laplacian_field(A.phi)[mask],axis=-1).sum()
        delta_phi_norm = (
            float(np.linalg.norm(getattr(A, "delta_phi", 0.0),axis=-1)[mask].max())
            if hasattr(A, "delta_phi") else 0.0
        )
        grads = np.gradient(q_s, axis=tuple(range(q_s.ndim-1)))
        fisher_information = float(sum((g**2/(q_s+log_eps)).sum() for g in grads))

        # package
        stats = {
            "e_self":        e_self,
            "e_align":       e_align,
            "e_feedback":    e_feedback,
            "e_mod_align":   e_mod_align,
            "e_lap_bel":     e_lap_bel,
            "e_mass_bel":    e_mass_bel,
            "e_lap_mod":     e_lap_mod,
            "e_mass_mod":    e_mass_mod,
            "e_couple":      e_couple,
            "e_curv":        e_curv,
            "e_curv_mod":    e_curv_mod,
            "phi_norm":      phi_norm,
            "phi_model_norm":phi_model_norm,
            "entropy":       entropy,
            "lap_phi_norm":  lap_phi_norm,
            "delta_phi_norm":delta_phi_norm,
            "curvature_norm":    np.sum(mean_F[mask]),
            "curvature_model_norm": np.sum(mean_Fm[mask]),
            "fisher_information":   fisher_information,
            "model_arr":      np.zeros(N, dtype=float)  # fill later if needed
        }

        return i, stats
    
    
    # 3) Run per‐agent stats in parallel
    results = Parallel(n_jobs=n_jobs, backend="threading")(
        delayed(_agent_stats)(
            i, agents[i], step,
            q_field, p_field,
            phi_belief_field, phi_model_field,
            mask_field, cfg, lie_gens
        )
        for i in range(N)
    )

    # 4) Initialize accumulators for all eleven energy terms + support
    keys = [
        "e_self", "e_align", "e_feedback", "e_mod_align",
        "e_lap_bel", "e_mass_bel", "e_lap_mod", "e_mass_mod",
        "e_couple", "e_curv", "e_curv_mod"
    ]
    accum = {k: 0.0 for k in keys}
    total_support = 0
    # also roll up diagnostics
    diag_sums = {
        "phi_norm": 0.0, "phi_model_norm": 0.0, "entropy": 0.0,
        "lap_phi_norm": 0.0, "delta_phi_norm": 0.0,
        "curvature_norm": 0.0, "curvature_model_norm": 0.0,
        "fisher_information": 0.0
    }

    # 5) Accumulate per‐agent
    for i, s in results:
        mask = Mask_list[i]
        support = int(mask.sum())
        total_support += support

        # energies
        for k in keys:
            accum[k] += s[k]

        # diagnostics
        for dk in diag_sums:
            diag_sums[dk] += s[dk]

        # per‐agent logging
        agents[i].log_metrics(step, {
    "kl_self":         s["e_self"]            / support,
    "kl_align":        s["e_align"]           / support,
    "kl_feedback":     s["e_feedback"]        / support,
    "kl_mod_align":    s["e_mod_align"]       / support,
    "lap_phi":         s["e_lap_bel"]         / support,
    "mass_phi":        s["e_mass_bel"]        / support,
    "lap_phi_mod":     s["e_lap_mod"]         / support,
    "mass_phi_mod":    s["e_mass_mod"]        / support,
    "phi_phi_couple":  s["e_couple"]          / support,
    "curv_phi":        s["e_curv"]            / support,
    "curv_phi_mod":    s["e_curv_mod"]        / support,
    "curvature_norm":       s["curvature_norm"]       / support,
    "curvature_model_norm": s["curvature_model_norm"] / support,
    # … any other diagnostics …
    })


    # 6) Build global metrics
    S = max(total_support, 1)
    metrics = {
        "step": step,
        # mean energies per support
        **{ k: accum[k] / S for k in keys },
        # mean diagnostics per agent or per support
        "phi_norm":      diag_sums["phi_norm"] / S,
        "phi_model_norm":diag_sums["phi_model_norm"] / S,
        "entropy":       diag_sums["entropy"] / N,
        "lap_phi_norm":  diag_sums["lap_phi_norm"] / S,
        "delta_phi_norm":diag_sums["delta_phi_norm"] / S,
        "curvature_norm":    diag_sums["curvature_norm"] / S,
        "curvature_model_norm": diag_sums["curvature_model_norm"] / S,
        "fisher_information":   diag_sums["fisher_information"] / S,
    }

    # 7) total_energy = sum of all eleven terms (normalized)
    metrics["total_energy"] = sum(accum.values()) / S

    return metrics
