import numpy as np
import config

from get_generators import get_generators
from generalized_omega import (
    exp_lie_algebra_irrep,
    batch_apply_omega,
    repair_if_forgotten_batch,
)
from generalized_math_utils import sanitize_q
from transport_operator import compute_inter_agent_omega

def self_grad_wrt_q(q,p,eps):
    q = sanitize_q(q,eps)
    p = sanitize_q(p,eps)
    return np.log(q/p) + 1.0

def self_grad_wrt_p(q,p,eps):
    q = sanitize_q(q,eps)
    p = sanitize_q(p,eps)
    return -q/p


import numpy as np
import config

def compute_self_gradient(agent_i,
                          dist_field_q: str,
                          dist_field_p: str,
                          mask_field: str,
                          params: dict) -> np.ndarray:
    """
    ∂/∂q [ α · D_KL(q_i || p_i) ]
    """
    # Hyperparams
    α       = params.get("alpha",             config.alpha)
    log_eps = params.get("log_eps",           config.log_eps)
    eps_supp = params.get("support_cutoff_eps", config.support_cutoff_eps)
    clip   = getattr(config, "gradient_clip", None)

    # Fields
    q     = getattr(agent_i, dist_field_q)  # shape (..., K)
    p     = getattr(agent_i, dist_field_p)
    mask  = getattr(agent_i, mask_field)    # shape (...)

    # Initialize gradient
    grad = np.zeros_like(q)

    # Only compute where the agent actually “lives”
    support = (mask > eps_supp)
    if α > 0 and support.any():
        # extract the (n_pts, K) arrays
        q_s = sanitize_q(q[support], eps=log_eps)
        p_s = sanitize_q(p[support], eps=log_eps)

        # ∂/∂q D_KL(q||p) = log(q/p) + 1
        g = np.log(q_s / p_s) + 1.0

        # clip if requested
        if clip is not None:
            g = np.clip(g, -clip, clip)

        # apply alpha
        grad[support] = α * g

        # optional debug
        if params.get("debug", False):
            mag = np.max(np.abs(α * g))
            print(f"[TRACE] self‐KL ∂ term max = {mag:.3e}")

    return grad

import numpy as np
import config



def compute_alignment_gradient(
    agent_i,
    agents: list,
    dist_field: str,
    phi_field: str,
    params: dict
) -> np.ndarray:
    """
    ∂/∂q_i ∑_j D_KL(q_i || Ω_{ij} q_j)
    where Ω_{ij} = exp(phi_i/e)·exp(-phi_j/e) for non-abelian G.
    Uses flattened spatial indexing to avoid broadcast issues.
    """
    # Hyperparameters
    β           = params.get("beta",          config.beta)
    overlap_eps = params.get("overlap_eps",   config.overlap_eps)
    log_eps     = params.get("log_eps",       config.log_eps)
    clip_val    = getattr(config, "gradient_clip", None)

    # Agent-i fields
    q_i    = getattr(agent_i, dist_field)    # shape (..., K)
    phi_i  = getattr(agent_i, phi_field)     # shape (..., lie_dim)
    mask_i = agent_i.mask > overlap_eps      # boolean, shape spatial_dims

    grad = np.zeros_like(q_i)
    if β <= 0 or not mask_i.any():
        return grad

    # Precompute generators once
    gens = get_generators(config.group_name, config.K)

    # Flatten spatial axes for q_i, phi_i, and grad
    spatial_shape = mask_i.shape
    K = q_i.shape[-1]
    q_i_flat   = q_i.reshape(-1, K)
    grad_flat  = grad.reshape(-1, K)
    # flatten phi too
    lie_dim = phi_i.shape[-1]
    phi_i_flat = phi_i.reshape(-1, lie_dim)

    # Loop over neighbors
    for nb in agent_i.neighbors:
        j = nb["id"]
        agent_j = agents[j]
        mask_j = agent_j.mask > overlap_eps
        overlap = mask_i & mask_j
        if not overlap.any():
            continue

        # 1) get flat spatial indices of overlap
        flat_idx = np.flatnonzero(overlap)    # shape (n_pts,)

        # 2) gather q/phi values at those flat indices
        q_i_vals   = q_i_flat[flat_idx]       # (n_pts, K)
        q_j_vals   = getattr(agent_j, dist_field).reshape(-1, K)[flat_idx]
        phi_i_vals = phi_i_flat[flat_idx]     # (n_pts, lie_dim)
        phi_j_vals = getattr(agent_j, phi_field).reshape(-1, lie_dim)[flat_idx]

        # 3) build non-abelian transport operator
        Omega = compute_inter_agent_omega(
            phi_i_vals, phi_j_vals, None, gens, use_commutator=False
        )  # shape (n_pts, K, K)

        # 4) rotate and sanitize q_j
        qj_rot = batch_apply_omega(q_j_vals, Omega)
        qj_rot = repair_if_forgotten_batch(qj_rot, eps=log_eps)
        qj_rot = sanitize_q(qj_rot, eps=log_eps)
        qj_rot = np.real_if_close(qj_rot, tol=1e-12).astype(q_i.dtype, copy=False)

        # 5) compute gradient contributions
        qi_s = sanitize_q(q_i_vals, eps=log_eps)
        g    = np.log(qi_s / qj_rot) + 1.0
        if clip_val is not None:
            g = np.clip(g, -clip_val, clip_val)
        # make sure g is 2D (n_pts, K), not (1, n_pts, K) etc.
        g = g.reshape(flat_idx.size, -1)
        
        # 6) average and accumulate into flat grad
        n_pts = flat_idx.size
        grad_flat[flat_idx] += (β / n_pts) * g
    
    # reshape back to original and return
    return grad_flat.reshape(*spatial_shape, K)


# The wrapper functions compute_beliefs_gradient and compute_models_gradient
# unchanged, but now pass params dict to the above functions:

def compute_beliefs_gradient(agent_i, agents, params):
    return (
        compute_self_gradient(agent_i, "q", "p", "mask", params)
      + compute_alignment_gradient(agent_i, agents, "q", "phi", params)
    )


def compute_models_gradient(agent_i, agents, params):
    # transport-alignment gradient w.r.t. p
    align_p = compute_alignment_gradient(agent_i, agents, "p", "phi_model", params)
    # self-gradient w.r.t. p using self_grad_wrt_p
    q = getattr(agent_i, "q")
    p = getattr(agent_i, "p")
    mask = getattr(agent_i, "mask")
    cutoff = params.get("support_cutoff_eps", config.support_cutoff_eps)
    support = mask > cutoff

    grad_p = np.zeros_like(p)
    if params.get("alpha", config.alpha) > 0 and support.any():
        log_eps = params.get("log_eps", config.log_eps)
        q_s = sanitize_q(q[support], eps=log_eps)
        p_s = sanitize_q(p[support], eps=log_eps)
        g_self_p = self_grad_wrt_p(q_s, p_s, log_eps)
        grad_p[support] = np.clip(g_self_p, -config.gradient_clip, config.gradient_clip) * params.get("alpha", config.alpha)

    return align_p + grad_p




def compute_phi_alignment_gradient(agent_i, agents, params):
    """
    ∂/∂φ_i ∑_j D_KL(q_i || Ω_{ij} q_j)
    where Ω_{ij} = exp(φ_i/e)·exp(-φ_j/e) for non-abelian G.
    Works for any spatial dimension via flattened indexing.
    """
    β           = params.get("beta",        config.beta)
    log_eps     = params.get("log_eps",     config.log_eps)
    overlap_eps = params.get("overlap_eps", config.overlap_eps)
    clip_val    = params.get("phi_diff_clip", getattr(config, "phi_diff_clip", 5.0))

    if β <= 0:
        return np.zeros_like(agent_i.phi)

    # prepare
    gens     = get_generators(config.group_name, config.K)   # (dim_G, K, K)
    phi_i    = agent_i.phi                                  # (..., dim_G)
    q_i      = sanitize_q(agent_i.q, eps=log_eps)           # (..., K)
    mask_i   = agent_i.mask > overlap_eps                   # spatial mask
    spatial_shape = mask_i.shape
    dim_G    = phi_i.shape[-1]

    # flatten spatial dims
    phi_i_flat = phi_i.reshape(-1, dim_G)
    q_i_flat   = q_i.reshape(-1, q_i.shape[-1])
    delta_flat = np.zeros_like(phi_i_flat)                  # (n_pts, dim_G)

    # loop over neighbors
    for nb in agent_i.neighbors:
        agent_j = agents[nb["id"]]
        mask_j  = agent_j.mask > overlap_eps
        overlap = mask_i & mask_j
        if not overlap.any():
            continue

        # flat spatial indices
        flat_idx = np.flatnonzero(overlap)

        # gather values
        phi_i_vals = phi_i_flat[flat_idx]          # (N, dim_G)
        phi_j_vals = agent_j.phi.reshape(-1, dim_G)[flat_idx]
        q_j_flat   = sanitize_q(agent_j.q.reshape(-1, q_i.shape[-1]), eps=log_eps)
        q_i_vals   = q_i_flat[flat_idx]            # (N, K)
        q_j_vals   = q_j_flat[flat_idx]

        # build non-abelian Ω
        Omega = compute_inter_agent_omega(
            phi_i_vals, phi_j_vals, None, gens, use_commutator=False
        )  # (N, K, K)

        # rotate and sanitize q_j
        qj_rot = batch_apply_omega(q_j_vals, Omega)
        qj_rot = repair_if_forgotten_batch(qj_rot, eps=log_eps)
        qj_rot = sanitize_q(qj_rot, eps=log_eps)
        qj_rot = np.real_if_close(qj_rot, tol=1e-12).astype(q_i_flat.dtype, copy=False)

        # compute difference
        diff = q_i_vals - qj_rot                   # (N, K)

       # dΩ/dφ inner-products, using ellipsis to handle any leading dims
        dΩg  = np.einsum('...ij,ajk->...iak', Omega, gens)     # (..., K, dim_G, K)
        dΩq  = np.einsum('...iak,...k->...ia', dΩg, q_j_vals)   # (..., K, dim_G)
        grads= np.einsum('...ia,...i->...a', dΩq, diff)         # (..., dim_G)

        # average, scale & clip
        N = flat_idx.size or 1
        grads = (β / N) * np.clip(grads, -clip_val, clip_val)
        grads = grads.astype(delta_flat.dtype, copy=False)

       # ensure shape is (N, dim_G)
        grads = grads.reshape(flat_idx.size, -1)
        # accumulate
        delta_flat[flat_idx] += grads

    # reshape back
    return delta_flat.reshape(*spatial_shape, dim_G)



def compute_phi_model_update(agent_i, agents, params):
    """
    ∂/∂φ_model_i ∑_j D_KL(p_i || Ω_{ij} p_j)
    using true non-abelian transport and flattened indexing.
    """
    β̃          = params.get("beta_tilde",      config.model_align_weight)
    log_eps     = params.get("log_eps",         config.log_eps)
    overlap_eps = params.get("overlap_eps",     config.overlap_eps)
    clip_val    = params.get("phi_diff_clip",   getattr(config, "phi_diff_clip", 5.0))

    if β̃ <= 0:
        return np.zeros_like(agent_i.phi_model)

    # Setup
    gens        = get_generators(config.group_name, config.K)  # (dim_G, K, K)
    φm          = agent_i.phi_model                           # (..., dim_G)
    p_flat_full = sanitize_q(agent_i.p, eps=log_eps)          # (..., K)
    mask_i      = agent_i.mask > overlap_eps                  # spatial mask
    spatial_shape = mask_i.shape
    dim_G       = φm.shape[-1]
    K           = p_flat_full.shape[-1]

    # Flatten spatial dims
    φm_flat = φm.reshape(-1, dim_G)                           # (S, dim_G)
    p_flat  = p_flat_full.reshape(-1, K)                      # (S,  K)
    delta_flat = np.zeros_like(φm_flat)                       # (S, dim_G)

    # Loop neighbors
    for nb in agent_i.neighbors:
        agent_j = agents[nb["id"]]
        mask_j  = agent_j.mask > overlap_eps
        overlap = mask_i & mask_j
        if not overlap.any():
            continue

        # Flat indices
        idx = np.flatnonzero(overlap)                        # (N,)

        # Gather local chunks
        φm_i = φm_flat[idx]                                   # (N, dim_G)
        φm_j = agent_j.phi_model.reshape(-1, dim_G)[idx]
        p_i  = p_flat[idx]                                    # (N, K)
        p_j  = sanitize_q(agent_j.p.reshape(-1, K), eps=log_eps)[idx]

        # Non-abelian transport
        Ω = compute_inter_agent_omega(
            φm_i, φm_j, None, gens, use_commutator=False
        )  # (N, K, K)

        # Rotate & sanitize p_j
        pj_rot = batch_apply_omega(p_j, Ω)
        pj_rot = repair_if_forgotten_batch(pj_rot, eps=log_eps)
        pj_rot = sanitize_q(pj_rot, eps=log_eps)
        pj_rot = np.real_if_close(pj_rot, tol=1e-12).astype(p_i.dtype, copy=False)

        # Difference
        diff = p_i - pj_rot                                  # (N, K)

        # Derivative of Ω wrt φ_model
        dΩg = np.einsum('...ij,ajk->...iak', Ω, gens)       # (..., K, dim_G, K)
        dΩp = np.einsum('...iak,...k->...ia', dΩg, p_j)     # (..., K, dim_G)

        # Inner product with diff (note the minus sign from ∂ KL wrt transport)
        grads = -np.einsum('...ia,...i->...a', dΩp, diff)   # (..., dim_G)

        # Average, scale & clip
        N = idx.size or 1
        grads = (β̃ / N) * np.clip(grads, -clip_val, clip_val)
        grads = grads.reshape(N, dim_G).astype(delta_flat.dtype, copy=False)

        # Scatter into flat delta
        delta_flat[idx] += grads

    # reshape back to original
    return delta_flat.reshape(*spatial_shape, dim_G)
