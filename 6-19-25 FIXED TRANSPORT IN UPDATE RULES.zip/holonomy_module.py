# -*- coding: utf-8 -*-
"""
Created on Tue Jun 17 16:26:21 2025

@author: chris and christine
"""

'''
holonomy_module.py

Module to compute gauge holonomy within a single agent (spatial loops) and across agents (agent-chain loops).
'''

import numpy as np
from transport_operator import compute_intra_agent_omega, compute_inter_agent_omega
import random
from config import domain_size, support_cutoff_eps

def compute_spatial_loop_holonomy(agent, coords, generators, use_commutator=False, return_deviations=False):
    """
    Compute holonomy around a closed spatial loop within a single agent,
    by multiplying successive intra-agent frame maps and re-orthonormalizing
    at each step to prevent overflow/NaNs.

    Parameters:
        agent:             Agent object with a `.phi` field (array of shape domain × lie_dim)
        coords:            list of grid-coordinate tuples (first == last)
        generators:        array of shape (lie_dim, K, K) giving Lie‐algebra generators
        use_commutator:    whether to compute ω via commutator form
        return_deviations: whether to return stepwise ∥Ω - I∥ diagnostics

    Returns:
        H: np.ndarray of shape (K, K) giving the total holonomy
        deviations (optional): list of ∥Ω - I∥ norms per step
    """
    if len(coords) < 2 or coords[0] != coords[-1]:
        raise ValueError("coords must start and end at the same point")

    K = generators.shape[-1]
    H = np.eye(K, dtype=float)
    deviations = []

    for p0, p1 in zip(coords[:-1], coords[1:]):
        ω = compute_intra_agent_omega(
            agent.phi,
            p0,
            p1,
            generators,
            use_commutator
        )
        H = ω @ H

        if return_deviations:
            deviations.append(np.linalg.norm(ω - np.eye(K)))

        if np.all(np.isfinite(H)):
            U, s, Vt = np.linalg.svd(H, full_matrices=False)
            H = U @ Vt
        else:
            raise RuntimeError(f"Holonomy overflow at step from {p0} to {p1}")

    return (H, deviations) if return_deviations else H

def compute_agent_cycle_holonomy(agents, agent_cycle, overlap_points, generators, use_commutator=False, return_deviations=False):
    """
    Compute holonomy around a closed loop of agents.

    Parameters:
        agents: list of Agent objects
        agent_cycle: list of agent IDs (first == last) defining a closed chain
        overlap_points: list of spatial coords where each consecutive pair overlaps
                        length == len(agent_cycle)-1, last should correspond to closing step
        generators: Lie algebra generators for exp map
        use_commutator: bool, whether to use commutator for inter-agent omega
        return_deviations: whether to return stepwise ∥Ω - I∥ diagnostics

    Returns:
        H: np.ndarray of shape (K, K), the total holonomy for the agent cycle
        deviations (optional): list of ∥Ω - I∥ norms per jump
    """
    if len(agent_cycle) < 2 or agent_cycle[0] != agent_cycle[-1]:
        raise ValueError("agent_cycle must start and end at the same agent ID")
    if len(overlap_points) != len(agent_cycle) - 1:
        raise ValueError("overlap_points length must be one less than agent_cycle length")

    K = generators.shape[-1]
    H = np.eye(K)
    deviations = []

    for idx in range(len(agent_cycle)-1):
        i = agent_cycle[idx]
        j = agent_cycle[idx+1]
        c = overlap_points[idx]
        omega = compute_inter_agent_omega(
            agents[i].phi, agents[j].phi, c, generators, use_commutator
        )
        H = omega @ H
        if return_deviations:
            deviations.append(np.linalg.norm(omega - np.eye(K)))

    return (H, deviations) if return_deviations else H

def sample_self_avoiding_loop_within_mask(
    center,
    mask,
    *,
    min_length=4,
    max_length=1000,
    support_cutoff=support_cutoff_eps,
    seed=None
):
    """
    Generate a random self‐avoiding closed loop on a periodic grid,
    staying entirely where mask >= support_cutoff.
    """
    D = len(domain_size)
    rng = random.Random(seed)

    while True:
        visited = {tuple(center)}
        path = [tuple(center)]
        current = np.array(center, dtype=int)
        prev = None

        for _ in range(max_length):
            neighbors = []
            for axis in range(D):
                for d in (-1, +1):
                    nb = list(current)
                    nb[axis] = (nb[axis] + d) % domain_size[axis]
                    nb = tuple(nb)
                    if np.all(mask[nb] >= support_cutoff):
                        neighbors.append(nb)

            if tuple(center) in neighbors and len(path) >= min_length:
                path.append(tuple(center))
                return path

            candidates = [nb for nb in neighbors if nb != prev and nb not in visited]
            if not candidates:
                break

            nxt = rng.choice(candidates)
            prev = tuple(current.tolist())
            current = np.array(nxt, dtype=int)
            visited.add(nxt)
            path.append(nxt)

        continue
