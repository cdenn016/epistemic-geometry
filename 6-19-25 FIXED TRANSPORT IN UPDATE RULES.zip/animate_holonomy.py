# animate_belief_vs_fiber_loop.py

import os
import pickle
import numpy as np
import matplotlib.pyplot as plt
import imageio

from transport_operator import compute_intra_agent_omega
from get_generators import get_generators
from config import checkpoint_dir, group_name, K

# -----------------------
# CONFIG4
# -----------------------
DIAG_PATH = "holonomy_runs/spatial/22-54_0/diagnostics.pkl"
OUTDIR = "holonomy_gifs"
os.makedirs(OUTDIR, exist_ok=True)

# -----------------------
# Animation function
# -----------------------
def run_belief_vs_fiber_loop_animation():
    with open(DIAG_PATH, "rb") as f:
        diag = pickle.load(f)

    path_coords = diag["path_coords"]
    step = diag["step"]
    coord0 = path_coords[0]

    ckpt_path = os.path.join(checkpoint_dir, f"step_{step:04d}.pkl")
    with open(ckpt_path, "rb") as f:
        data = pickle.load(f)
    agents = data[0] if isinstance(data, tuple) else data
    agent = agents[0]

    generators = get_generators(group_name, K)

    q_initial = agent.q[coord0]
    q_current = q_initial.copy()
    q_sequence = [q_initial.copy()]

    for c0, c1 in zip(path_coords[:-1], path_coords[1:]):
        omega = compute_intra_agent_omega(agent.phi, c0, c1, generators)
        q_current = omega @ q_current
        q_sequence.append(q_current.copy())

    images = []
    max_val = max(np.max(q) for q in q_sequence)

    for t, q in enumerate(q_sequence):
        fig, ax = plt.subplots(figsize=(6, 3))
        ax.plot(q, color="blue", label="Transported q")
        ax.plot(q_initial, color="gray", linestyle="--", label="Initial q")
        ax.set_ylim(0, max_val * 1.1)
        ax.set_xlabel("Fiber Index")
        ax.set_ylabel("Probability")
        ax.set_title(f"Transported Belief (Step {t})")
        ax.legend()
        fig.tight_layout()

        tmp_path = f"_frame_fiber_{t:03d}.png"
        fig.savefig(tmp_path)
        plt.close(fig)
        images.append(imageio.imread(tmp_path))
        os.remove(tmp_path)

    gif_path = os.path.join(OUTDIR, f"belief_vs_fiber_loop_step{step:04d}.gif")
    imageio.mimsave(gif_path, images, fps=5)
    print(f"[✓] Saved GIF to: {gif_path}")
    
if __name__ == "__main__":
    import re

    print("[RUNNING] Belief vs Fiber Index Animation Along Holonomy Loop...")
    try:
        # -------------------------
        # Ask user for desired step
        # -------------------------
        step_str = input("Enter desired step number (e.g. 0001): ").strip()
        if not re.fullmatch(r"\d{4}", step_str):
            raise ValueError("Step must be a 4-digit number, e.g. 0001") #enter this in terminal

        step_int = int(step_str)

        # -------------------------
        # Search holonomy_runs/spatial/* for a matching *_step folder
        # -------------------------
        base_dir = "holonomy_runs/spatial"
        found = None
        for root, dirs, files in os.walk(base_dir):
            for d in dirs:
                if d.endswith(f"_{step_int}"):
                    diag_path = os.path.join(root, d, "diagnostics.pkl")
                    if os.path.exists(diag_path):
                        found = diag_path
                        break
            if found:
                break

        if not found:
            raise FileNotFoundError(f"No diagnostics found for step {step_str}")

        print(f"[INFO] Using diagnostics file: {found}")
        DIAG_PATH = found
        run_belief_vs_fiber_loop_animation()

    except Exception as e:
        print(f"[ERROR] Animation failed: {e}")
