import numpy as np
import sys

# ===========================
# DEBUGGING AND UTILITIES
# ===========================

# 1) define at top of your script/module
def scaled_eta(base, *weights, min_den=1.0):
    """
    If all weights sum to zero, return base.
    Otherwise return base / max(sum(weights), min_den).
    """
    total = sum(weights)
    if total <= 0:
        return base
    return base / max(total, min_den)

def set_config_from_params(params):
    """Dynamically override config attributes from a dictionary."""
    this_module = sys.modules[__name__]
    for k, v in params.items():
        setattr(this_module, k, v)

identical_models = False         # If True, all agents share the same p, mu_p_field, sigma_p_field
similar_p_models = False
diagonal_covariance = False  # Toggle: if True, Σ is diagonal; if False, use full MVN
agent_seed    = 141

dynamic_morphisms = True

q_to_p_morphism_type = "gauge_covariant"   # For Φ: q → p
p_to_q_morphism_type = "gauge_covariant"   # For Φ̃: p → q
# config.py
phi_morphism_type = "smooth"
phi_model_morphism_type = "smooth"


morphism_sigma_qtop = 1.5
morphism_rank_qtop = 2
morphism_normalize_qtop = True

morphism_sigma_ptoq = 1.5
morphism_rank_ptoq = 2
morphism_normalize_ptoq = True

# ===========================
# DOMAIN / SPATIAL SETTINGS
# ===========================
K_q = 7
K_p = 5        # Fiber dimension of belief/model space (depends on representation)
                 # Fast up to K=15 then slow
D = 2            #dimension of base manifold - d=2 validated

L = 16         #length of hypercubic base-manifold - PBCs

steps = 150

N = 3                         # Number of agents
max_neighbors = 3            # Max number of agent neighbors

psi_radius_range = (3,3)         #agent radii
             
# ===========================
# COUPLINGS & PENALTIES
# ===========================
e_belief               = 1
e_model                = 1

alpha                  = 1         
beta                   = 5           
gauge_weight           = 1          
curvature_weight       = 1

model_feedback_weight  = 1               
model_align_weight     = 5
model_mass_weight      = 1
model_curvature_weight = 1

# ===========================
# INITIALIZATION
# ===========================
phi_init_smooth_sigma = 1.5
phi_init              = 0.1
phi_model_offset      = 0.1

eta_base_q         = 1e-5    
eta_base_p         = 1e-5    
eta_base_phi       = 1e-4
eta_base_phi_model = 1e-4    

phi_morphism_lr     = 1e-3
phi_tilde_morphism_lr = 1e-3

eta_phi_min        = 1e-3
eta_phi_model_min = 1e-3

# ===========================
# AGENT GEOMETRY
# ===========================
q_mu_range    = (0, K_q - 1)        # Mean of q
q_sigma_range = (0.2, 3)         # Eigenvalues of Σ_q

p_mu_range    = (0, K_p - 1)        # Mean of p
p_sigma_range = (0.5, 3)         # Eigenvalues of Σ_p

mu_field_smooth_range    = (2, 3)   # lower = noisier
sigma_field_smooth_range = (0.2, 2)  #alignment is VERY sensitive smaller values => bigger swings

# Sigma field eigenvalue range
sigma_min_eig = 0.5     # minimum eigenvalue of Σ (lower bound on uncertainty)
sigma_max_eig = 3.0     # maximum eigenvalue of Σ (upper bound on uncertainty)

# Controls how sharply uncertainty grows away from support
sigma_decay_sharpness = 0.5  # passed as sigma to gaussian_filter
sigma_outside_mask_value = 1000.0  # or any large value you prefer
                                        
                                        #Controls how much randomness is added after masking, 
                                      #to avoid wiping out variation. Large for texture
mu_anisotropy_range  = (0.5, 2)       # 1 = round, 3 = stretched
mu_orientation_range = (0.1, np.pi)     # full angle range
mask_sharpness       = 1.5

# ===========================
# STABILITY AND CLIPPING
# ===========================

alignment_grad_clip           = 1e3

gradient_clip                 = 1e3  # You can tune this per experiment

phi_max_norm                  = 5.0
phi_model_max_norm            = 5.0

phi_grad_clip_threshold       = 1e2
phi_model_grad_clip_threshold = 1e2

phi_morphism_grad_clip        = 1.0  # or 5.0 if you want softer clipping
phi_tilde_morphism_grad_clip  = 1.0  # or higher if needed


phi_clip_threshold            = 15  # Optional: to bound exp(φ)
phi_model_clip_threshold      = 15


eta_phi_adaptive_scaling       = 2.0
eta_phi_model_adaptive_scaling = 2.0

eta_sigma_condition_scaling    = 0.1  # dampen updates if cond(Σ) is large

# Max allowed condition number for Omega matrix
max_omega_condition = 1e6  # Adjust as needed

# ===========================
# EPSILONS & PRECISION
# ===========================

log_eps            = 1e-6  #for logs
support_cutoff_eps = 1e-2           #agent and mask overlap = at 1e-1
overlap_eps        = 1e-3   #where to consider computing overlap computations
eps                = 1e-3   #for SPD clipping

epsilon_model      = 1.0    #detecting meta agents

spd_eps            = 1e-6

precision = np.float32


# =====if needed/curious ======= #
phi_phi_tilde_coupling = 0
phi_damping            = 0                # leave 0 unless blowup occurs

variance_penalty_model_weight = 0
variance_penalty_weight       = 0

fisher_geometry_weight        = 0
fisher_model_geometry_weight  = 0

# ===========================
# CHECKPOINTING
# ===========================

checkpoint_dir      = "checkpoints"

checkpoint_interval = 1

domain_size = (L,) * D

# 3) replace all the old eta_* calculations with calls to scaled_eta
eta_q = scaled_eta(eta_base_q, alpha, beta)

eta_p = scaled_eta(eta_base_p,
                   alpha,
                   model_align_weight,
                   model_feedback_weight,
                  
                   model_mass_weight)

eta_phi = scaled_eta(eta_base_phi,
                     gauge_weight,
                     
                     curvature_weight,
                     phi_phi_tilde_coupling)

eta_model_phi = scaled_eta(eta_base_phi_model,
                           model_align_weight,
                          
                           model_mass_weight,
                           phi_phi_tilde_coupling
                           )

num_cores = 1  # or however many threads you want to use
log_full_fields = True  # default off



group_name = 'sl2r'               # Options: "u1", "so3", "sl2r", 'su2'.
representation_type = 'irrep'     # Options: 'irrep', 'fundamental', 'adjoint'


# Enable numerical safety logging
debug = True  # Global debug flag for extra logging inside φ updates                       
debug_gradients = True                  # Log gradient-related issues
debug_sanitize_sigma = True             # Show SPD sanitization messages
fail_on_fallback = False                # Allow recovery rather than crashing
sanitize_fallback_value = 1.0           # Value used for fallback matrices
# ── Numerical Safeguards ─────────────────────────────
max_fisher_condition = 1e4   # Maximum allowed condition number before fallback


# Control fallback thresholds (optional)
max_safe_inv_fallbacks = 1000
max_safe_logdet_fallbacks = 1000

