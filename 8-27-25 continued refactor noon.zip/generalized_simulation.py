# generalized_simulation.py
import os
os.environ["OMP_NUM_THREADS"] = "1"
os.environ["MKL_NUM_THREADS"] = "1"
os.environ["NUMEXPR_NUM_THREADS"] = "1"
os.environ["OPENBLAS_NUM_THREADS"] = "1"
import sys
ROOT = os.path.dirname(os.path.abspath(__file__))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

import sys, time, pickle
import core.config as config
import shutil, os
from run_sim_utils import (
    prepare_generators, merge_logging_cfg, initialize_or_resume,
    ensure_runtime, log_and_viz_after_step,
    wrap_epilogue, set_config_from_params, save_step
)

from updates.update_rules import synchronous_step

def run_simulation(
    outdir="checkpoints",
    resume=False,
    log_metrics=True,
    log_fields=True,
    num_cores=None,
    params=None,
    fresh_outdir=False,
    clear_agent_logs=True,
):
    # outdir rotation + readme
    if not resume and fresh_outdir and os.path.isdir(outdir):
        ts = time.strftime("%Y%m%d_%H%M%S")
        shutil.move(outdir, f"{outdir}_old_{ts}")
    os.makedirs(outdir, exist_ok=True)

    # params + cores
    try:
        import multiprocessing as _mp
        _avail = max(1, (_mp.cpu_count() or 1) - 1)
    except Exception:
        _avail = 8

    num_cores = _avail if num_cores is None else int(num_cores)
    num_cores = max(1, num_cores)

    params = {} if params is None else dict(params)

    # Make sure inner joblib calls use the same level of parallelism
    try:
        import core.config as _cfg
        _cfg.n_jobs = num_cores
    except Exception:
        pass

    # generators
    G_q, G_p = prepare_generators(params)

    # logging cfg
    logcfg = merge_logging_cfg(params if isinstance(params, dict) else vars(config))
    if not log_metrics: logcfg["enable_scalar"] = False
    if not log_fields:  logcfg["enable_fields"] = False
    if logcfg.get("enable_fields", False):
        os.makedirs(os.path.join(outdir, logcfg["full_field_outdir"]), exist_ok=True)

    # init or resume
    agents, step_start = initialize_or_resume(outdir, resume, params, clear_agent_logs=clear_agent_logs)

    # runtime context (mounted lvl-1 view)
    runtime_ctx = ensure_runtime(params)
    runtime_ctx.global_step = step_start  # initialize step index
    params["runtime_ctx"] = runtime_ctx   # expose ctx via params for legacy helpers

    # Early-exit if resuming past the configured steps
    if step_start >= int(getattr(config, "steps", step_start)):
        wrap_epilogue(runtime_ctx, agents, outdir, [], [])
        print("[DONE] Nothing to do: resume step >= total steps.")
        return agents, []

    # trackers
    parent_metrics, metric_log = [], []
    print(f"[RUN] Starting simulation at step {step_start} with {num_cores if (num_cores is not None) else 'auto'} cores")

    for step in range(step_start, config.steps):
        # keep global_step in sync BEFORE core update so gates use it
        runtime_ctx.global_step = step

        # Advance central transport-cache epoch once per step (no per-agent caches)
        try:
            tc = getattr(runtime_ctx, "transport_cache", None)
            if tc is not None and hasattr(tc, "clear_on_step"):
                tc.clear_on_step(step)
        except Exception:
            pass

        print(f"\n[STEP {step}] -----------------------------\n")
        t0 = time.perf_counter()
        step_params = {**params, "step": step, "sanitize_strict_pre": False}

        # core synchronous update (ctx is threaded inside)
        agents = synchronous_step(
            agents, G_q, G_p,
            params=step_params,
            n_jobs=num_cores,
            runtime_ctx=runtime_ctx,
        )
       
        print(f"[TIMER] synchronous update: {time.perf_counter() - t0:.3f}s")

        # viz & metrics
        runtime_ctx.children_latest = agents
        log_and_viz_after_step(runtime_ctx, agents, step, outdir, params, logcfg,
                               parent_metrics, metric_log, num_cores)
        # OPTIONAL: compact central cache before checkpoint (no per-agent clears)
        try:
            tc = getattr(runtime_ctx, "transport_cache", None)
            if tc is not None and hasattr(tc, "compact"):
                tc.compact()
        except Exception:
            pass

        save_step(agents, outdir, step)
        print(f"[SAVE] Checkpoint --> {outdir}/step_{step:04d}.pkl")

    # epilogue
    wrap_epilogue(runtime_ctx, agents, outdir, parent_metrics, metric_log)
    print("[DONE] Simulation completed.")
    return agents, metric_log


if __name__ == "__main__":
    if len(sys.argv) > 1:
        with open(sys.argv[1], "rb") as f:
            param_override = pickle.load(f)
        set_config_from_params(param_override)
    else:
        param_override = {}

    # Prepare runtime generators for convenience CLI usage
    from core.get_generators import get_generators
    G_q, meta_q = get_generators(config.group_name, config.K_q, return_meta=True)
    G_p, meta_p = get_generators(config.group_name, config.K_p, return_meta=True)
    runtime_params = {"generators_q": G_q, "generators_p": G_p}

    run_simulation(
        outdir="checkpoints",
        resume=False,
        log_metrics=True,
        log_fields=True,
        params=runtime_params,
    )



