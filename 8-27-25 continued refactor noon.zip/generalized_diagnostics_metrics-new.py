from __future__ import annotations
"""
Created on Wed Aug 27 11:13:07 2025

@author: chris and christine
"""

# -*- coding: utf-8 -*-
"""
Streamlined diagnostics & energies.

Goals:
  • Single, minimal API to compute and print/log energies per agent.
  • No duplicated math: defer to gaussian_core / gaussian_kl / transport_cache / omega.
  • Cache-friendly: use transport_cache (E / Ω / Λ / curvature) when ctx is provided.
  • Safe numerics: sanitize Σ, clip NaNs/Infs, mask-aware reductions.

Public API (stable):
  - compute_all_agent_metrics(i, agent, Q_list, P_list, Mask_list, cfg, gens, log_eps) -> dict
  - log_all_metrics(agents, step, params=None, n_jobs=1, *, ctx=None) -> (levels_map, flat_record)
  - format_energy_table(step, totals) -> str

Where:
  Q_list[i] = (mu_q, Sigma_q) for agent i
  P_list[i] = (mu_p, Sigma_p) for agent i
  Mask_list[i] = soft/binary support mask for agent i
  gens = {"q": generators_q, "p": generators_p} (K×K×3 for SO(3) irreps)

Notes:
  - Curvature uses transport_cache.curvature_plaquette (lattice-plaquette, cache-backed).
  - Alignment fields use Ω from transport_cache when ctx is provided (preferred).
  - “Self” / “Feedback” use Gaussian push + KL from gaussian_core/gaussian_kl.
  - Mass is simple ||φ||² over mask.
"""
from transport.transport_cache import Omega  # cached Ω if ctx provided


from core.group import exp_lie_algebra_irrep  # fallback path
from core.gaussian_core import push_gaussian
from core.numerical_utils import sanitize_sigma
from dataclasses import dataclass
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple
from transport.transport_cache import Lambda_dn
from core.gaussian_kl import kl_divergence, kl_gaussian

import numpy as np

# Import lightweight helpers only at module import time
try:
    import core.config as config  # project config (weights, eps, etc.)
except Exception:  # pragma: no cover
    class _Cfg: pass
    config = _Cfg()  # minimal fallback; all accesses guarded

# Avoid heavy / circular imports: pull bigger deps inside functions where needed

__all__ = [
    "compute_all_agent_metrics",
    "log_all_metrics",
    "format_energy_table",
]


# ─────────────────────────────────────────────────────────────────────────────
# Small utilities (safe casts, reductions)
# ─────────────────────────────────────────────────────────────────────────────

def _as_f32(x):
    return np.asarray(x, np.float32)


def _support_mask(mask, eps=None):
    tau = float(getattr(config, "support_cutoff_eps", 1e-3) if eps is None else eps)
    m = np.asarray(mask, np.float32)
    if m.ndim == 3 and m.shape[-1] == 1:
        m = np.squeeze(m, axis=-1)
    return m > tau


def _weighted_sum(arr, mask) -> float:
    if arr is None:
        return 0.0
    m = np.asarray(mask, np.bool_)
    if not np.any(m):
        return 0.0
    return float(np.sum(np.asarray(arr, np.float64)[m], dtype=np.float64))


def _sum_over_mask(arr, mask) -> float:
    if arr is None:
        return 0.0
    m = np.asarray(mask, np.bool_)
    return float(np.sum(np.where(m, np.asarray(arr, np.float64), 0.0), dtype=np.float64))


# === Phase-2 helpers: parent resolver + Λ metrics ============================

def _select_primary_parent(agent, ctx=None):
    """Best-effort: prefer agent.primary_parent; else resolve via ctx.parents_by_region using first id in agent.parent_ids."""
    P = getattr(agent, "primary_parent", None)
    if P is not None:
        return P
    pids = list(getattr(agent, "parent_ids", []) or [])
    if not pids or ctx is None or not hasattr(ctx, "parents_by_region"):
        return None
    pid = int(pids[0])
    P = ctx.parents_by_region.get(pid)
    if P is not None:
        return P
    for v in getattr(ctx, "parents_by_region", {}).values():
        if int(getattr(v, "id", -1)) == pid:
            return v
    return None


def lambda_norms(agent, mask, *, ctx=None) -> Dict[str,float]:
    out = {"lambda_q_dn_norm": np.nan, "lambda_q_up_norm": np.nan,
           "lambda_p_dn_norm": np.nan, "lambda_p_up_norm": np.nan}
    if ctx is None:
        return out
    try:
        from transport_cache import Lambda_dn, Lambda_up
    except Exception:
        return out

    parent = _select_primary_parent(agent, ctx)
    if parent is None:
        return out

    m = np.asarray(mask, np.bool_)
    def _fro_map(A): 
        if A is None: return None
        return np.sqrt(np.sum(np.asarray(A, np.float32)**2, axis=(-2, -1)))

    for which in ("q","p"):
        try:
            Ldn = Lambda_dn(ctx, agent, parent, which=which)
            if Ldn is not None:
                out[f"lambda_{which}_dn_norm"] = float(np.mean(_fro_map(Ldn)[m]))
        except Exception:
            pass
        try:
            Lup = Lambda_up(ctx, agent, parent, which=which)
            if Lup is not None:
                out[f"lambda_{which}_up_norm"] = float(np.mean(_fro_map(Lup)[m]))
        except Exception:
            pass
    return out



def lambda_kl_dn(agent, parent, which: str, *, eps: float, ctx=None) -> float:
    """KL(agent || Λ_dn parent) over child∩parent overlap, fiber=which ∈ {'q','p'}."""
    

    ov = np.minimum(np.asarray(agent.mask, np.float32),
                    np.asarray(parent.mask, np.float32)) > float(getattr(config, "support_cutoff_eps", 1e-3))
    if not np.any(ov): 
        return 0.0
    iy, ix = np.nonzero(ov)

    if which == "q":
        mu_c, S_c = agent.mu_q_field, agent.sigma_q_field
        mu_p, S_p = parent.mu_q_field, parent.sigma_q_field
    else:
        mu_c, S_c = agent.mu_p_field, agent.sigma_p_field
        mu_p, S_p = parent.mu_p_field, parent.sigma_p_field

    Ldn = Lambda_dn(ctx, agent, parent, which=which)
    if Ldn is None:
        return 0.0

    L = Ldn[iy, ix]
    mu_pt = np.einsum("mab,mb->ma", L, mu_p[iy, ix], optimize=True)
    Spt   = np.einsum("mab,mbc,mdc->mad", L, sanitize_sigma(S_p[iy, ix], eps=eps), np.swapaxes(L, -1, -2), optimize=True)
    Spt   = sanitize_sigma(Spt, eps=eps)
    d = kl_divergence(mu_c[iy, ix], sanitize_sigma(S_c[iy, ix], eps=eps), mu_pt, Spt, eps=eps)
    return float(np.sum(d, dtype=np.float64))




# ─────────────────────────────────────────────────────────────────────────────
# KL helpers (defer to gaussian_core / gaussian_kl)
# ─────────────────────────────────────────────────────────────────────────────

def _kl_map(mu1, S1, mu2, S2, support, eps):
    """Per-pixel KL(N1 || N2) on `support` (boolean H×W). Returns an H×W field (zeros outside)."""
    

    mu1 = _as_f32(mu1); mu2 = _as_f32(mu2)
    S1  = sanitize_sigma(_as_f32(S1), eps=eps)
    S2  = sanitize_sigma(_as_f32(S2), eps=eps)

    sup = np.asarray(support, np.bool_)
    if not sup.any():
        return np.zeros_like(sup, np.float32)

    iy, ix = np.nonzero(sup)
    d = kl_gaussian(mu1[iy, ix], S1[iy, ix], mu2[iy, ix], S2[iy, ix], eps=eps).astype(np.float32)
    out = np.zeros_like(sup, np.float32); out[iy, ix] = d
    return out


def _push_gaussian(mu, Sigma, M, eps):
    
    mu_t, S_t = push_gaussian(mu=_as_f32(mu), Sigma=_as_f32(Sigma), M=_as_f32(M),
                              eps=eps, symmetrize=True, sanitize=True, approx="exact")
    return mu_t, sanitize_sigma(S_t, eps=eps)


# --- Robust morphism fetch ----------------------------------------------------
def _get_cached_morphism(ctx, agent, direction: str):
    """
    Return a bundle morphism for this agent.
    direction ∈ {"p_to_q", "q_to_p"}.
    Tries agent attrs first, then several transport_cache variants.
    """
    # 1) agent fields
    if direction == "p_to_q":
        M = getattr(agent, "bundle_morphism_p_to_q", None)
    else:
        M = getattr(agent, "bundle_morphism_q_to_p", None)
    if M is not None:
        return M

    # 2) cache lookups
    if ctx is None:
        return None
    try:
        from transport.transport_cache import Phi, Phi_tilde
    except Exception:
        Phi = None
        Phi_tilde = None

    # try common call shapes without assuming exact signatures
    trials = []
    if direction == "p_to_q":
        if Phi_tilde is not None:
            trials.append(lambda: Phi_tilde(ctx, agent))
        if Phi is not None:
            trials.append(lambda: Phi(ctx, agent, which="p_to_q"))
            trials.append(lambda: Phi(ctx, agent))
    else:  # q_to_p
        if Phi is not None:
            trials.append(lambda: Phi(ctx, agent, which="q_to_p"))
            trials.append(lambda: Phi(ctx, agent))
        if Phi_tilde is not None:
            trials.append(lambda: Phi_tilde(ctx, agent, which="q_to_p"))  # harmless if unsupported

    for fn in trials:
        try:
            M = fn()
            if M is not None:
                return M
        except Exception:
            pass

    # 3) last-chance generic
    try:
        from transport.transport_cache import get_morphism  # if your cache exposes this
        return get_morphism(ctx, agent, direction=direction)
    except Exception:
        return None



# ─────────────────────────────────────────────────────────────────────────────
# Alignment field (pairwise KL after Ω-transport)
# ─────────────────────────────────────────────────────────────────────────────

def _alignment_field(Ai, Aj, *, which: str, eps: float, ctx=None, generators=None) -> np.ndarray:
    """Return an H×W field: KL( N_i || Ω_ij ◁ N_j ) masked to ov(Ai, Aj)."""
    

    # Overlap & slices
    w = np.minimum(_as_f32(Ai.mask), _as_f32(Aj.mask))
    ov = w > float(getattr(config, "support_cutoff_eps", 1e-3))
    if not np.any(ov):
        return np.zeros_like(w, np.float32)
    iy, ix = np.nonzero(ov)

    if which == "q":
        mu_i, S_i = _as_f32(Ai.mu_q_field), _as_f32(Ai.sigma_q_field)
        mu_j, S_j = _as_f32(Aj.mu_q_field), _as_f32(Aj.sigma_q_field)
        phi_i, phi_j = _as_f32(Ai.phi), _as_f32(Aj.phi)
        G = getattr(Ai, "generators_q", None) if generators is None else generators
    else:
        mu_i, S_i = _as_f32(Ai.mu_p_field), _as_f32(Ai.sigma_p_field)
        mu_j, S_j = _as_f32(Aj.mu_p_field), _as_f32(Aj.sigma_p_field)
        phi_i, phi_j = _as_f32(Ai.phi_model), _as_f32(Aj.phi_model)
        G = getattr(Ai, "generators_p", None) if generators is None else generators

    mui = mu_i[iy, ix]; Si = sanitize_sigma(S_i[iy, ix], eps=eps)
    muj = mu_j[iy, ix]; Sj = sanitize_sigma(S_j[iy, ix], eps=eps)

    # Ω from cache if ctx; else local exp-lie fallback
    if ctx is not None:
        Om_full = Omega(ctx, Ai, Aj, which=which)
        Om = Om_full[iy, ix]
    else:
        if G is None:
            raise ValueError("_alignment_field: missing generators and no ctx cache path available")
        O_i = exp_lie_algebra_irrep(phi_i[iy, ix], _as_f32(G))
        O_j_inv = exp_lie_algebra_irrep(-phi_j[iy, ix], _as_f32(G))
        Om = np.matmul(O_i, O_j_inv)

    # Transport j → i
    muj_t = np.einsum("mab,mb->ma", Om, muj, optimize=True)
    OmT   = np.swapaxes(Om, -1, -2)
    Sj_t  = np.einsum("mab,mbc,mdc->mad", Om, Sj, OmT, optimize=True)
    Sj_t  = sanitize_sigma(Sj_t, eps=eps)

    # KL on overlap, scatter back
    d = kl_gaussian(mui, Si, muj_t, Sj_t, eps=eps).astype(np.float32)
    out = np.zeros_like(w, np.float32); out[iy, ix] = d
    return out

# ---- Legacy shims for cross-scale KL (expected by run_sim_utils) ------------

def compute_crossscale_kl_q_single(child, parent, *, params=None, ctx=None, direction="down", eps=None, **_):
    """
    Returns the cross-scale KL for q-fiber.
    By default computes KL(child || Λ_dn parent) over child∩parent support.
    """
    e = float(eps if eps is not None else (params or {}).get("log_eps", getattr(config, "log_eps", 1e-8)))
    if str(direction).lower() in ("down", "dn"):
        # Phase-2 helper implemented earlier
        return float(lambda_kl_dn(child, parent, "q", eps=e, ctx=ctx))
    # 'up' not wired yet (no Lambda_up KL helper here); return 0 for compatibility
    return 0.0


def compute_crossscale_kl_p_single(child, parent, *, params=None, ctx=None, direction="down", eps=None, **_):
    """
    Returns the cross-scale KL for p-fiber.
    By default computes KL(child || Λ_dn parent) over child∩parent support.
    """
    e = float(eps if eps is not None else (params or {}).get("log_eps", getattr(config, "log_eps", 1e-8)))
    if str(direction).lower() in ("down", "dn"):
        return float(lambda_kl_dn(child, parent, "p", eps=e, ctx=ctx))
    return 0.0

# ─────────────────────────────────────────────────────────────────────────────
# Energies per agent
# ─────────────────────────────────────────────────────────────────────────────

# at top of file (helpers keep lazy imports inside funcs, so no new globals needed)

def _self_energy_field(A, mu_q, Sig_q, mu_p, Sig_p, *, eps: float, ctx=None) -> np.ndarray:
    """E_self field: KL(q || Φ̃ p)  (zeros outside mask)."""
    M = _get_cached_morphism(ctx, A, "p_to_q")
    if M is None:
        return np.zeros_like(A.mask, np.float32)
    mu_t, S_t = _push_gaussian(mu_p, Sig_p, M, eps)
    support = _support_mask(A.mask, getattr(config, "support_cutoff_eps", 1e-3))
    return _kl_map(mu_q, Sig_q, mu_t, S_t, support, eps)


def _feedback_energy_field(A, mu_q, Sig_q, mu_p, Sig_p, *, eps: float, ctx=None) -> np.ndarray:
    """E_feedback field: KL(p || Φ q)  (zeros outside mask)."""
    M = _get_cached_morphism(ctx, A, "q_to_p")
    if M is None:
        return np.zeros_like(A.mask, np.float32)
    mu_t, S_t = _push_gaussian(mu_q, Sig_q, M, eps)
    support = _support_mask(A.mask, getattr(config, "support_cutoff_eps", 1e-3))
    return _kl_map(mu_p, Sig_p, mu_t, S_t, support, eps)



def _curvature_energy_value(phi_field, mask, weight, lie_gens, *, ctx=None) -> float:
    """Plaquette curvature energy (weight * sum over mask)."""
    if ctx is None or phi_field is None or lie_gens is None:
        return 0.0
    try:
        from transport.transport_cache import curvature_plaquette
    except Exception:
        return 0.0
    curv = curvature_plaquette(ctx, _as_f32(phi_field), _as_f32(lie_gens),
                                boundary=str(getattr(config, "curv_boundary", "periodic")),
                                split_edge=bool(getattr(config, "curv_split_edge", False)),
                                metric=str(getattr(config, "curv_metric", "fro")),
                                return_P=False)
    m = _support_mask(mask, getattr(config, "support_cutoff_eps", 1e-3))
    return float(weight) * float(np.sum(np.where(m, curv, 0.0), dtype=np.float64))


def _mass_energy_value(phi_field, mask, weight) -> float:
    if phi_field is None or float(weight) == 0.0:
        return 0.0
    m = _support_mask(mask, getattr(config, "support_cutoff_eps", 1e-3))
    norms_sq = np.sum(_as_f32(phi_field)**2, axis=-1)
    return float(weight) * float(np.sum(np.where(m, norms_sq, 0.0), dtype=np.float64))


@dataclass
class AgentMetrics:
    e_self: float = 0.0
    e_feedback: float = 0.0
    e_align: float = 0.0
    e_mod_align: float = 0.0
    e_curv: float = 0.0
    e_curv_mod: float = 0.0
    e_mass: float = 0.0
    e_mass_mod: float = 0.0
    area: float = 0.0
    # Phase-2 additions:
    xscale_dn_q: float = 0.0
    xscale_dn_p: float = 0.0
    lambda_q_dn_norm: float = np.nan
    lambda_q_up_norm: float = np.nan
    lambda_p_dn_norm: float = np.nan
    lambda_p_up_norm: float = np.nan

    def as_dict(self) -> Dict[str, float]:
        return {
            "self": self.e_self,
            "feedback": self.e_feedback,
            "align_q": self.e_align,
            "align_p": self.e_mod_align,
            "curv_q": self.e_curv,
            "curv_p": self.e_curv_mod,
            "mass_q": self.e_mass,
            "mass_p": self.e_mass_mod,
            "area": self.area,
            # Phase-2:
            "xscale_dn_q": self.xscale_dn_q,
            "xscale_dn_p": self.xscale_dn_p,
            "lambda_q_dn_norm": self.lambda_q_dn_norm,
            "lambda_q_up_norm": self.lambda_q_up_norm,
            "lambda_p_dn_norm": self.lambda_p_dn_norm,
            "lambda_p_up_norm": self.lambda_p_up_norm,
        }


# ─────────────────────────────────────────────────────────────────────────────
# Single-agent computation
# ─────────────────────────────────────────────────────────────────────────────

def compute_all_agent_metrics(i: int, agent: Any,
                              Q_list: Sequence[Tuple[np.ndarray, np.ndarray]],
                              P_list: Sequence[Tuple[np.ndarray, np.ndarray]],
                              Mask_list: Sequence[np.ndarray],
                              cfg: Dict[str, Any],
                              gens: Dict[str, Optional[np.ndarray]],
                              log_eps: float,
                              *, ctx=None) -> Dict[str, float]:
    """
    Compute weighted energies for a single agent `agent` at index i.
    Returns a flat dict suitable for aggregation/printing.
    """
    eps = float(log_eps)

    mask = Mask_list[i]
    if mask is None or not np.any(mask):
        return AgentMetrics(area=0.0).as_dict()

    (mu_q, Sig_q) = Q_list[i]
    (mu_p, Sig_p) = P_list[i]

    # Weights from cfg or config (params override config)
    alpha = float(cfg.get("alpha", cfg.get("alpha", getattr(config, "alpha", 0.0))))
    lam   = float(cfg.get("lambda_feedback", cfg.get("lambda", cfg.get("feedback_weight", getattr(config, "feedback_weight", 0.0)))))
    w_curv_q = float(cfg.get("curvature_weight", getattr(config, "curvature_weight", 0.0)))
    w_curv_p = float(cfg.get("model_curvature_weight", getattr(config, "model_curvature_weight", 0.0)))
    w_mass_q = float(cfg.get("belief_mass", getattr(config, "belief_mass", 0.0)))
    w_mass_p = float(cfg.get("model_mass", getattr(config, "model_mass", 0.0)))

    # Cross-scale weights (default 0.0 so it's inert until you flip them on)
    w_x_dn_q = float(cfg.get("xscale_dn_q_weight", getattr(config, "xscale_dn_q_weight", 0.0)))
    w_x_dn_p = float(cfg.get("xscale_dn_p_weight", getattr(config, "xscale_dn_p_weight", 0.0)))

    # ── Self / Feedback (with cache fallback for Φ/Φ̃) ───────────────────────
    f_self = _self_energy_field(agent, mu_q, Sig_q, mu_p, Sig_p, eps=eps, ctx=ctx)
    if (not np.any(f_self)) and (ctx is not None):
        # try cache Φ̃ if agent doesn't carry morphism
        try:
            from transport_cache import Phi_tilde  # p→q
            M = Phi_tilde(ctx, agent)
            if M is not None:
                mu_t, S_t = _push_gaussian(mu_p, Sig_p, M, eps)
                f_self = _kl_map(mu_q, Sig_q, mu_t, S_t, _support_mask(mask, getattr(config, "support_cutoff_eps", 1e-3)), eps)
        except Exception:
            pass

    f_feed = _feedback_energy_field(agent, mu_q, Sig_q, mu_p, Sig_p, eps=eps, ctx=ctx)
    if (not np.any(f_feed)) and (ctx is not None):
        # try cache Φ if agent doesn't carry morphism
        try:
            from transport_cache import Phi  # q→p
            M = Phi(ctx, agent, kind="q_to_p")
            if M is not None:
                mu_t, S_t = _push_gaussian(mu_q, Sig_q, M, eps)
                f_feed = _kl_map(mu_p, Sig_p, mu_t, S_t, _support_mask(mask, getattr(config, "support_cutoff_eps", 1e-3)), eps)
        except Exception:
            pass

    e_self = float(alpha) * _sum_over_mask(f_self, mask)
    e_feed = float(lam)   * _sum_over_mask(f_feed, mask)

    # ── Alignment (robust neighbor discovery) ────────────────────────────────
    e_align = 0.0
    e_mod_align = 0.0
    try:
        neigh_idx = [j for j in range(len(Q_list)) if j != i]
    except Exception:
        neigh_idx = []

    # prefer agent.peers; else params["agents_ref"]; else ctx.agents
    peers = getattr(agent, "peers", None)
    agents_ref = cfg.get("agents_ref", None)
    if agents_ref is None and hasattr(ctx, "agents"):
        agents_ref = getattr(ctx, "agents")

    for j in neigh_idx:
        Aj = None
        if isinstance(peers, (list, tuple)) and j < len(peers):
            Aj = peers[j]
        if Aj is None and isinstance(agents_ref, (list, tuple)) and j < len(agents_ref):
            Aj = agents_ref[j]
        if Aj is None or Aj is agent:
            continue

        # belief alignment
        f_align = _alignment_field(agent, Aj, which="q", eps=eps, ctx=ctx,
                                   generators=gens.get("q") if gens else None)
        e_align += _sum_over_mask(f_align, np.minimum(mask, Aj.mask))
        # model alignment
        f_align_p = _alignment_field(agent, Aj, which="p", eps=eps, ctx=ctx,
                                     generators=gens.get("p") if gens else None)
        e_mod_align += _sum_over_mask(f_align_p, np.minimum(mask, Aj.mask))

    # ── Cross-scale KL via Λ_dn (child || Λ_dn parent) ───────────────────────
    e_x_dn_q = e_x_dn_p = 0.0
    parent = _select_primary_parent(agent, ctx)
    if (parent is not None) and (ctx is not None) and (w_x_dn_q or w_x_dn_p):
        e_x_dn_q = float(w_x_dn_q) * lambda_kl_dn(agent, parent, "q", eps=eps, ctx=ctx)
        e_x_dn_p = float(w_x_dn_p) * lambda_kl_dn(agent, parent, "p", eps=eps, ctx=ctx)

    # Λ norms (diagnostics; doesn’t affect energy)
    lam_diag = lambda_norms(agent, mask, ctx=ctx)

    # ── Curvature (plaquette) & Mass ─────────────────────────────────────────
    Gq = gens.get("q") if gens else None
    Gp = gens.get("p") if gens else None
    e_curv   = _curvature_energy_value(getattr(agent, "phi", None),        mask, w_curv_q, Gq, ctx=ctx)
    e_curv_p = _curvature_energy_value(getattr(agent, "phi_model", None),  mask, w_curv_p, Gp, ctx=ctx)

    e_mass   = _mass_energy_value(getattr(agent, "phi", None),       mask, w_mass_q)
    e_mass_p = _mass_energy_value(getattr(agent, "phi_model", None), mask, w_mass_p)

    area = float(np.sum(_support_mask(mask), dtype=np.float64))

    return AgentMetrics(
        e_self=e_self, e_feedback=e_feed, e_align=e_align, e_mod_align=e_mod_align,
        e_curv=e_curv, e_curv_mod=e_curv_p, e_mass=e_mass, e_mass_mod=e_mass_p,
        area=area,
        xscale_dn_q=e_x_dn_q,
        xscale_dn_p=e_x_dn_p,
        lambda_q_dn_norm=lam_diag.get("lambda_q_dn_norm", np.nan),
        lambda_q_up_norm=lam_diag.get("lambda_q_up_norm", np.nan),
        lambda_p_dn_norm=lam_diag.get("lambda_p_dn_norm", np.nan),
        lambda_p_up_norm=lam_diag.get("lambda_p_up_norm", np.nan),
    ).as_dict()

# ---- Legacy shim: keep run_sim_utils imports happy --------------------------
def compute_total_free_energy(agents, params=None, n_jobs=1, *, ctx=None, step=None, return_breakdown=False, **_):
    """
    Legacy API expected by run_sim_utils.
    - Returns E_total by default (float).
    - If return_breakdown=True, returns (levels_map, flat_record).
    """
    step = -1 if step is None else step
    p = dict(params or {})
    p.setdefault("print_table", False)
    levels_map, flat_record = log_all_metrics(agents, step=step, params=p, n_jobs=n_jobs, ctx=ctx)
    if return_breakdown:
        return levels_map, flat_record
    # children level (lvl-0) E_total matches what the old code called "free energy"
    return float((levels_map or {}).get(0, {}).get("E_total", flat_record.get("E/E_total", 0.0)))


# ─────────────────────────────────────────────────────────────────────────────
# Aggregation & logging
# ─────────────────────────────────────────────────────────────────────────────

def _compute_rows_parallel(agents, Q_list, P_list, Mask_list, params, gens, eps, *, ctx=None, n_jobs=1):
    # Import joblib lazily to avoid hard dependency
    try:
        from joblib import Parallel, delayed
    except Exception:
        Parallel = None
        delayed = None

    if Parallel is None or int(n_jobs) == 1:
        rows = [compute_all_agent_metrics(i, agents[i], Q_list, P_list, Mask_list, params or {}, gens, eps, ctx=ctx)
                for i in range(len(agents))]
    else:
        rows = Parallel(n_jobs=int(n_jobs))(
            delayed(compute_all_agent_metrics)(i, agents[i], Q_list, P_list, Mask_list, params or {}, gens, eps, ctx=ctx)
            for i in range(len(agents))
        )
    return rows


def _sum_key(rows, key: str) -> float:
    return float(sum(float(r.get(key, 0.0)) for r in rows))


def _mean_per_agent(rows, key: str) -> float:
    vals = [float(r.get(key, 0.0)) for r in rows]
    return float(np.mean(vals)) if vals else 0.0


def _area(rows) -> float:
    return float(sum(float(r.get("area", 0.0)) for r in rows))


def log_all_metrics(agents: Sequence[Any], step: int, params: Optional[Dict[str, Any]] = None, n_jobs: int = 1, *, ctx=None):
    """
    Compute and optionally print/log an energy table across all agents.
    Returns (levels_map, flat_record) where levels_map[0] contains totals for children.
    """
    params = dict(params or {})
    eps = float(params.get("log_eps", getattr(config, "log_eps", 1e-8)))

    # Early exit if no agents
    if not agents:
        totals = {k: 0.0 for k in (
            "E_total","self","feedback","align_q","align_p",
            "curv_q","curv_p","mass_q","mass_p","xscale_dn_q","xscale_dn_p",
            "mean_total","lambda_q_dn_norm","lambda_q_up_norm","lambda_p_dn_norm","lambda_p_up_norm","area_sum"
        )}
        levels_map = {0: {
            "e_self": 0.0, "e_feedback": 0.0, "e_align": 0.0, "e_mod_align": 0.0,
            "e_curv": 0.0, "e_curv_mod": 0.0, "e_mass": 0.0, "e_mass_mod": 0.0,
            "area": 0.0, "E_total": 0.0,
        }}
        flat_record = {f"E/{k}": v for k, v in totals.items()}
        if bool(params.get("print_table", True)):
            print(format_energy_table(step, totals))
        return levels_map, flat_record

    # Assemble lists (caller may precompute to avoid repeated property access)
    Q_list = [(a.mu_q_field, a.sigma_q_field) for a in agents]
    P_list = [(a.mu_p_field, a.sigma_p_field) for a in agents]
    Mask_list = [a.mask for a in agents]

    gens = {
        "q": getattr(agents[0], "generators_q", None),
        "p": getattr(agents[0], "generators_p", None),
    }

    # <<< key change: provide a peers fallback to alignment code >>>
    worker_params = {**params, "agents_ref": agents}

    rows = _compute_rows_parallel(agents, Q_list, P_list, Mask_list, worker_params, gens, eps, ctx=ctx, n_jobs=n_jobs)

    # Totals (weighted sums) and means (per-agent)
    totals = {
        "E_total": _sum_key(rows, "self") + _sum_key(rows, "feedback") + _sum_key(rows, "align_q") + _sum_key(rows, "align_p") +
                   _sum_key(rows, "curv_q") + _sum_key(rows, "curv_p") + _sum_key(rows, "mass_q") + _sum_key(rows, "mass_p"),
        "self": _sum_key(rows, "self"),
        "feedback": _sum_key(rows, "feedback"),
        "align_q": _sum_key(rows, "align_q"),
        "align_p": _sum_key(rows, "align_p"),
        "curv_q": _sum_key(rows, "curv_q"),
        "curv_p": _sum_key(rows, "curv_p"),
        "mass_q": _sum_key(rows, "mass_q"),
        "mass_p": _sum_key(rows, "mass_p"),
        "xscale_dn_q": _sum_key(rows, "xscale_dn_q"),
        "xscale_dn_p": _sum_key(rows, "xscale_dn_p"),
        "mean_total": _mean_per_agent(rows, "self") + _mean_per_agent(rows, "feedback") +
                      _mean_per_agent(rows, "align_q") + _mean_per_agent(rows, "align_p") +
                      _mean_per_agent(rows, "xscale_dn_q") + _mean_per_agent(rows, "xscale_dn_p") +
                      _mean_per_agent(rows, "curv_q") + _mean_per_agent(rows, "curv_p") +
                      _mean_per_agent(rows, "mass_q") + _mean_per_agent(rows, "mass_p"),
        # Λ norms (means over agents; for display only)
        "lambda_q_dn_norm": _mean_per_agent(rows, "lambda_q_dn_norm"),
        "lambda_q_up_norm": _mean_per_agent(rows, "lambda_q_up_norm"),
        "lambda_p_dn_norm": _mean_per_agent(rows, "lambda_p_dn_norm"),
        "lambda_p_up_norm": _mean_per_agent(rows, "lambda_p_up_norm"),
        "area_sum": _area(rows),
    }
    totals["E_total"] += totals["xscale_dn_q"] + totals["xscale_dn_p"]

    # Optional: print nicely
    if bool(params.get("print_table", True)):
        print(format_energy_table(step, totals))

    # Prepare simple level map (children only)
    levels_map = {0: {
        "e_self": totals["self"],
        "e_feedback": totals["feedback"],
        "e_align": totals["align_q"],
        "e_mod_align": totals["align_p"],
        "e_curv": totals["curv_q"],
        "e_curv_mod": totals["curv_p"],
        "e_mass": totals["mass_q"],
        "e_mass_mod": totals["mass_p"],
        "area": totals["area_sum"],
        "E_total": totals["E_total"],
    }}

    # Flattened record for loggers
    flat_record = {f"E/{k}": v for k, v in totals.items()}
    return levels_map, flat_record

# --- Snapshot NPZ dumper (minimal, stable) -----------------------------------
def dump_snapshot_npz(path: str, agents, step: int, *, ctx=None, **_ignore):
    ...

    """
    Save a compact diagnostic snapshot:
      - μ/Σ for q & p (Σ symmetrized)
      - φ (belief) and φ_model (model)
      - Φ and Φ̃ morphisms if present
      - agent mask (optional but handy)
    Returns the path written.
    """
    import numpy as np

    def _sym(S): 
        S = np.asarray(S)
        return 0.5 * (S + np.swapaxes(S, -1, -2))

    out = {"step": int(step)}
    for i, A in enumerate(agents):
        out[f"agent{i}_mu_q"]     = np.asarray(getattr(A, "mu_q_field"), np.float32)
        out[f"agent{i}_sigma_q"]  = _sym(getattr(A, "sigma_q_field"))
        out[f"agent{i}_mu_p"]     = np.asarray(getattr(A, "mu_p_field"), np.float32)
        out[f"agent{i}_sigma_p"]  = _sym(getattr(A, "sigma_p_field"))
        out[f"agent{i}_phi"]      = np.asarray(getattr(A, "phi"), np.float32)
        out[f"agent{i}_phi_model"]= np.asarray(getattr(A, "phi_model"), np.float32)
        # optional but useful for analysis
        if hasattr(A, "mask"):
            out[f"agent{i}_mask"] = np.asarray(A.mask, np.float32)
        # include morphisms if present
        if hasattr(A, "bundle_morphism_q_to_p"):
            out[f"agent{i}_Phi"] = np.asarray(A.bundle_morphism_q_to_p, np.float32)
        if hasattr(A, "bundle_morphism_p_to_q"):
            out[f"agent{i}_Phi_tilde"] = np.asarray(A.bundle_morphism_p_to_q, np.float32)

    np.savez_compressed(path, **out)
    return path


# ─────────────────────────────────────────────────────────────────────────────
# Pretty printing
# ─────────────────────────────────────────────────────────────────────────────

def _pf(x: float) -> str:
    return f"{float(x):.6e}"


def format_energy_table(step: int, totals: Dict[str, float]) -> str:
    lines = []
    lines.append(f"[Energy Totals @ step {int(step)}]")
    lines.append(f"  E_total = {_pf(totals.get('E_total', 0.0))}  |  mean_total = {_pf(totals.get('mean_total', 0.0))}")
    lines.append("  " + "-"*52)
    lines.append("  term               weighted               mean")
    lines.append(f"  self           {_pf(totals.get('self', 0.0))}       {_pf(_mean_per_agent([totals], 'self'))}")
    lines.append(f"  feedback       {_pf(totals.get('feedback', 0.0))}       {_pf(_mean_per_agent([totals], 'feedback'))}")
    lines.append(f"  align_q        {_pf(totals.get('align_q', 0.0))}       {_pf(_mean_per_agent([totals], 'align_q'))}")
    lines.append(f"  align_p        {_pf(totals.get('align_p', 0.0))}       {_pf(_mean_per_agent([totals], 'align_p'))}")
    lines.append(f"  mass_q         {_pf(totals.get('mass_q', 0.0))}       {_pf(_mean_per_agent([totals], 'mass_q'))}")
    lines.append(f"  mass_p         {_pf(totals.get('mass_p', 0.0))}       {_pf(_mean_per_agent([totals], 'mass_p'))}")
    lines.append(f"  curv_q         {_pf(totals.get('curv_q', 0.0))}       {_pf(_mean_per_agent([totals], 'curv_q'))}")
    lines.append(f"  curv_p         {_pf(totals.get('curv_p', 0.0))}       {_pf(_mean_per_agent([totals], 'curv_p'))}")
    
    if totals.get("xscale_dn_q", 0.0) or totals.get("xscale_dn_p", 0.0):
        lines.append(f"  xscale_dn_q    {_pf(totals.get('xscale_dn_q', 0.0))}       {_pf(_mean_per_agent([totals], 'xscale_dn_q'))}")
        lines.append(f"  xscale_dn_p    {_pf(totals.get('xscale_dn_p', 0.0))}       {_pf(_mean_per_agent([totals], 'xscale_dn_p'))}")
    
    # Λ diagnostics
    if not np.isnan(totals.get("lambda_q_dn_norm", np.nan)):
        lines.append("  " + "-"*52)
        lines.append("  Λ diagnostics (mean Frobenius on support)")
        lines.append(f"  lambda_q_dn_norm   = {_pf(totals.get('lambda_q_dn_norm', 0.0))}")
        lines.append(f"  lambda_q_up_norm   = {_pf(totals.get('lambda_q_up_norm', 0.0))}")
        lines.append(f"  lambda_p_dn_norm   = {_pf(totals.get('lambda_p_dn_norm', 0.0))}")
        lines.append(f"  lambda_p_up_norm   = {_pf(totals.get('lambda_p_up_norm', 0.0))}")

    
    
    return "\n".join(lines)
