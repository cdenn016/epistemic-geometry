
from __future__ import annotations
from typing import Any, Sequence, Dict, Tuple
import numpy as np

from core.transport_cache import plaquette_product  
from core.numerical_utils import expected_nll_gaussian
from runtime_context import ensure_theta, cfg_get
from core.get_generators import get_generators
from utils import mask_hw
from joblib import Parallel, delayed
from threadpoolctl import threadpool_limits
from runtime_context import energy_acc_get




def _reduce(field: np.ndarray, mask: np.ndarray, kind: str) -> float:
    f = np.asarray(field, np.float32)
    m = np.asarray(mask, bool)
    if f.shape != m.shape:
        raise ValueError(f"reduce mismatch: field {f.shape} vs mask {m.shape}")
    if not m.any():
        return 0.0
    if kind == "sum":
        return float(f[m].sum())
    if kind == "mean":
        return float(f[m].mean())
    raise ValueError(f"unknown reduce kind {kind}")



def _energy_mass(ctx: Any, agent: Any) -> Tuple[float, float, float, float]:
    """Returns (mass_q_sum, mass_q_mean, mass_p_sum, mass_p_mean)."""
    
    cfg = getattr(ctx, "step_cfg", None)

    tau = cfg.support_tau
    wq  = cfg.belief_mass
    wp  = cfg.model_mass
    
    mask = mask_hw(agent.mask, tau=tau, mode = "bool2")
    if not mask.any():
        return 0.0, 0.0, 0.0, 0.0

    phi_q = np.asarray(agent.phi, np.float32)       # (H,W,3)
    phi_p = np.asarray(agent.phi_model, np.float32) # (H,W,3)
    if phi_q.ndim != 3 or phi_q.shape[-1] != 3 or phi_p.ndim != 3 or phi_p.shape[-1] != 3:
        raise ValueError("phi_field/phi_model_field must be (H,W,3)")

    m_q = (phi_q ** 2).sum(axis=-1)  # ||Ï†||Â²
    m_p = (phi_p ** 2).sum(axis=-1)
    return (
        wq * _reduce(m_q, mask, "sum"),
        wq * _reduce(m_q, mask, "mean"),
        wp * _reduce(m_p, mask, "sum"),
        wp * _reduce(m_p, mask, "mean"),
    )



def _energy_curvature(ctx: Any, agent: Any) -> Tuple[float, float, float, float]:
    """
    Returns (curv_q_sum, curv_q_mean, curv_p_sum, curv_p_mean).

    Backend: lattice plaquette via transport_cache.plaquette_product(...)
      P ∈ ℝ^{H×W×K×K}, site magnitude = ||P - I||_F^2
    """
    import numpy as np
    cfg = getattr(ctx, "step_cfg", None)

    tau = cfg.support_tau
    wq  = cfg.curvature_weight
    wp  = cfg.model_curvature_weight

    mask = mask_hw(agent.mask, tau=tau, mode = "bool2")
    if not mask.any():
        return 0.0, 0.0, 0.0, 0.0

    
    # ---- belief side (q-fiber) ----
    Gq = get_generators(agent, "q")
   
    Pq = plaquette_product(ctx, agent.phi, Gq, split_edge=True)
        
    if Pq.ndim != 4 or Pq.shape[-1] != Pq.shape[-2]:
        raise ValueError(f"Invalid plaquette (q) shape {Pq.shape}")
        
    Kq = int(Pq.shape[-1])
    Iq = np.eye(Kq, dtype=np.float32)
    Dq = Pq - Iq
    fq = np.einsum("...ij,...ij->...", Dq, Dq, optimize=True)
   
    # ---- model side (p-fiber) ----
    Gp = get_generators(agent, "p")
       
    Pp = plaquette_product(ctx, agent.phi_model, Gp, split_edge=True)

    if Pp.ndim != 4 or Pp.shape[-1] != Pp.shape[-2]:
        raise ValueError(f"Invalid plaquette (p) shape {Pp.shape}")
    
    Kp = int(Pp.shape[-1])
    Ip = np.eye(Kp, dtype=np.float32)
    Dp = Pp - Ip
    fp = np.einsum("...ij,...ij->...", Dp, Dp, optimize=True)

    return (
        wq * _reduce(fq, mask, "sum"),
        wq * _reduce(fq, mask, "mean"),
        wp * _reduce(fp, mask, "sum"),
        wp * _reduce(fp, mask, "mean"),
    )


# --- diagnostics.py ---

def total_energy(ctx: Any,
                 agents: Any,
                 *,
                 return_breakdown: bool = False,
                 precomputed_metrics: Dict[str, float] | None = None
                 ) -> float | Tuple[float, Dict[str, float]]:
    """
    Variational energy minimized by the suite.

    If precomputed_metrics is provided, it should be the dict returned by
    compute_global_metrics(ctx, agents); we will skip recomputing it.
    """
    M = precomputed_metrics if precomputed_metrics is not None else compute_global_metrics(ctx, agents)
    E = float(M.get("E_total", 0.0))

    if not return_breakdown:
        return E

    breakdown = {
        "self":       float(M.get("self_sum",     0.0)),
        "feedback":   float(M.get("feedback_sum", 0.0)),
        "align_q":    float(M.get("align_q_sum",  0.0)),
        "align_p":    float(M.get("align_p_sum",  0.0)),
        "mass_q":     float(M.get("mass_q_sum",   0.0)),
        "mass_p":     float(M.get("mass_p_sum",   0.0)),
        "curv_q":     float(M.get("curv_q_sum",   0.0)),
        "curv_p":     float(M.get("curv_p_sum",   0.0)),
        "mean_total": float(M.get("mean_total",   0.0)),
    }
    return E, breakdown





def print_action_breakdown(ctx, action_dict, *, stream=None):
    step = int(getattr(ctx, "global_step", -1))
    lines = []
    lines.append(f"[Action @ step {step}]")
    lines.append(f"  Action_total = {action_dict.get('Action_total', 0.0):.6e}")
    lines.append("  ---------------------------------------")
    lines.append(f"  Geom_total   = {action_dict.get('Geom_total', 0.0):.6e}")
    lines.append(f"  VFE_acc      = {action_dict.get('VFE_acc', 0.0):.6e}")
    lines.append(f"  A_curv       = {action_dict.get('A_curv', 0.0):.6e}  ")
    lines.append(f"  A_cov        = {action_dict.get('A_cov', 0.0):.6e}")
    lines.append(f"  ModelPrior   = {action_dict.get('ModelPrior', 0.0):.6e}")
    print("\n".join(lines), flush=True)


def print_energy_breakdown(ctx, metrics, *, hide_zero_weight=True):
    """
    Print a consistent table:
      raw_sum, mean_per_px, weight, weighted_sum (= raw_sum * weight)
    Rows with weight==0 can be hidden unless debug asks otherwise.
    """
    cfg = getattr(ctx, "step_cfg", None)

    alpha  = float(getattr(cfg, "alpha", 0.0))
    lambd  = float(getattr(cfg, "feedback_weight", 0.0))
    beta_q = float(getattr(cfg, "beta", 0.0))
    beta_p = float(getattr(cfg, "beta_model", 0.0))
    div2   = bool(getattr(cfg, "align_energy_div2", False))
    w_align_q = (0.5 if div2 else 1.0) * beta_q
    w_align_p = (0.5 if div2 else 1.0) * beta_p

    rows = [
        ("self",      metrics.get("self_sum", 0.0),      metrics.get("self_mean", 0.0),      alpha),
        ("align_q",   metrics.get("align_q_sum", 0.0),   metrics.get("align_q_mean", 0.0),   w_align_q),
        ("align_p",   metrics.get("align_p_sum", 0.0),   metrics.get("align_p_mean", 0.0),   w_align_p),
        ("feedback",  metrics.get("feedback_sum", 0.0),  metrics.get("feedback_mean", 0.0),  lambd),
        ("mass_q",    metrics.get("mass_q_sum", 0.0),    metrics.get("mass_q_mean", 0.0),    1.0),
        ("mass_p",    metrics.get("mass_p_sum", 0.0),    metrics.get("mass_p_mean", 0.0),    1.0),
        ("curv_q",    metrics.get("curv_q_sum", 0.0),    metrics.get("curv_q_mean", 0.0),    1.0),
        ("curv_p",    metrics.get("curv_p_sum", 0.0),    metrics.get("curv_p_mean", 0.0),    1.0),
    ]

    print("\n[Energy Totals @ step {}]".format(int(getattr(ctx, "global_step", -1))))
    print("  E_total = {: .6e}  |  mean_total = {: .6e}".format(
        float(metrics.get("E_total", 0.0)),
        float(metrics.get("mean_total", 0.0)),
    ))
    print("  " + "-"*52)
    print("  {:<12} {:>14} {:>18} {:>8}".format("term", "raw_sum", "mean_per_px", "weight") +
          "   {:>14}".format("weighted_sum"))
    for name, raw_sum, mean_px, w in rows:
        if hide_zero_weight and (w == 0.0):
            # still show if raw is nonzero and you want visibility:
            # if abs(raw_sum) > 0: pass
            continue
        weighted = raw_sum * w
        print("  {:<12} {:>14.6e} {:>18.6e} {:>8g}   {:>14.6e}".format(
            name, float(raw_sum), float(mean_px), w, float(weighted)
        ))
    print()


def compute_agent_metrics(ctx: Any, agent: Any) -> Dict[str, float]:
    """
    Returns per-agent RAW (unweighted) energy components.
    We keep self/feedback unweighted here to mirror alignment’s convention.
    Mass/curv are also raw; weighting (if any) is applied in compute_global_metrics.
    """
    cfg = getattr(ctx, "step_cfg", None)
    tau = float(getattr(cfg, "support_tau", 1e-6)) if cfg is not None else 1e-6
    m = mask_hw(getattr(agent, "mask", None), tau=tau, mode="bool2")
    if (m is None) or (not np.any(m)):
        return {
            "self_sum": 0.0, "self_mean": 0.0,
            "feedback_sum": 0.0, "feedback_mean": 0.0,
            "mass_q_sum": 0.0, "mass_q_mean": 0.0,
            "mass_p_sum": 0.0, "mass_p_mean": 0.0,
            "curv_q_sum": 0.0, "curv_q_mean": 0.0,
            "curv_p_sum": 0.0, "curv_p_mean": 0.0,
        }

    S = int(np.count_nonzero(m)) or 1

    # Prefer per-agent accumulators populated earlier (raw, unweighted)
    aid = getattr(agent, "id", None)
    self_sum = fb_sum = 0.0
    if aid is not None:
        v = energy_acc_get(ctx, f"self_sum[{aid}]", None)
        if v is not None: self_sum = float(v)
        v = energy_acc_get(ctx, f"feedback_sum[{aid}]", None)
        if v is not None: fb_sum = float(v)

    self_mean = self_sum / S
    fb_mean   = fb_sum   / S

    # Mass/curvature are computed here (raw)
    mass_q_sum, mass_q_mean, mass_p_sum, mass_p_mean = _energy_mass(ctx, agent)
    curv_q_sum, curv_q_mean, curv_p_sum, curv_p_mean = _energy_curvature(ctx, agent)

    return {
        "self_sum": self_sum, "self_mean": self_mean,
        "feedback_sum": fb_sum, "feedback_mean": fb_mean,
        "mass_q_sum": mass_q_sum, "mass_q_mean": mass_q_mean,
        "mass_p_sum": mass_p_sum, "mass_p_mean": mass_p_mean,
        "curv_q_sum": curv_q_sum, "curv_q_mean": curv_q_mean,
        "curv_p_sum": curv_p_sum, "curv_p_mean": curv_p_mean,
    }



def compute_global_metrics(ctx: Any, agents: Sequence[Any]) -> Dict[str, float]:
    cfg     = getattr(ctx, "step_cfg", None)
    tau     = cfg.support_tau
    n_jobs  = int(getattr(cfg, "metrics_n_jobs", 1))

    # Weights & options
    alpha   = float(getattr(cfg, "alpha", 0.0))
    lambd   = float(getattr(cfg, "feedback_weight", 0.0))
    beta_q  = float(getattr(cfg, "beta", 0.0))
    beta_p  = float(getattr(cfg, "beta_model", 0.0))
    

    def _one(a):
        m = mask_hw(a.mask, tau=tau, mode="bool2")
        S = int(np.count_nonzero(m))
        if S <= 0:
            return None
        d = compute_agent_metrics(ctx, a)  # RAW values
        return d, S

    with threadpool_limits(1):
        outs = Parallel(n_jobs=max(1, n_jobs), backend="threading", batch_size="auto")(
            delayed(_one)(a) for a in agents
        )

    totals = {"self_sum":0.0,"feedback_sum":0.0,"mass_q_sum":0.0,"mass_p_sum":0.0,
              "curv_q_sum":0.0,"curv_p_sum":0.0,"_S":0}

    for res in outs:
        if res is None:
            continue
        d, S = res
        for k in ("self_sum","feedback_sum","mass_q_sum","mass_p_sum","curv_q_sum","curv_p_sum"):
            totals[k] += float(d[k])
        totals["_S"] += int(S)

    # Alignment RAW totals from the per-step accumulator (unweighted)
    aq = energy_acc_get(ctx, "align_q_sum", 0.0)
    ap = energy_acc_get(ctx, "align_p_sum", 0.0)
    align_q_sum_raw = float(aq or 0.0)
    align_p_sum_raw = float(ap or 0.0)

    S_tot = max(totals["_S"], 1)

    # Raw means
    out = dict(totals)
    out["self_mean"]     = out["self_sum"]     / S_tot
    out["feedback_mean"] = out["feedback_sum"] / S_tot
    out["mass_q_mean"]   = out["mass_q_sum"]   / S_tot
    out["mass_p_mean"]   = out["mass_p_sum"]   / S_tot
    out["curv_q_mean"]   = out["curv_q_sum"]   / S_tot
    out["curv_p_mean"]   = out["curv_p_sum"]   / S_tot

    # Weighted alignment
    w_align_q = beta_q
    w_align_p = beta_p
    out["align_q_sum"]  = align_q_sum_raw
    out["align_p_sum"]  = align_p_sum_raw
    out["align_q_mean"] = align_q_sum_raw / S_tot
    out["align_p_mean"] = align_p_sum_raw / S_tot

    # Weighted totals (final energy)
    self_w     = alpha * out["self_sum"]
    feedback_w = lambd * out["feedback_sum"]
    align_q_w  = w_align_q * out["align_q_sum"]
    align_p_w  = w_align_p * out["align_p_sum"]

    mass_q_w = out["mass_q_sum"]   # keep as-is unless you add a separate weight
    mass_p_w = out["mass_p_sum"]
    curv_q_w = out["curv_q_sum"]
    curv_p_w = out["curv_p_sum"]

    out["E_total"] = float(
        self_w + feedback_w +
        mass_q_w + mass_p_w +
        curv_q_w + curv_p_w +
        align_q_w + align_p_w
    )

    out["mean_total"] = float(
        (alpha  * out["self_mean"])     +
        (lambd  * out["feedback_mean"]) +
        (w_align_q * out["align_q_mean"]) +
        (w_align_p * out["align_p_mean"]) +
        out["mass_q_mean"] + out["mass_p_mean"] +
        out["curv_q_mean"] + out["curv_p_mean"]
    )

    # (Optional) also expose weighted breakdowns for logging
    out.update({
        "self_sum_w": self_w, "feedback_sum_w": feedback_w,
        "align_q_sum_w": align_q_w, "align_p_sum_w": align_p_w,
    })

    return out



def compute_total_action(ctx, agents, precomputed_metrics=None):
    cfg = getattr(ctx, "step_cfg", None)

    # 1) Geometric piece
    M_geom = precomputed_metrics if (precomputed_metrics is not None) \
             else compute_global_metrics(ctx, agents)
    A_geom = float(M_geom.get("E_total", 0.0))

    
    # 4) A terms (unchanged)
    fields = getattr(ctx, "fields", {}) or {}
    A_cov = float(fields.get("A_cov_energy_last", 0.0))
    A_curv = float(fields.get("A_curv_energy", 0.0))
    A_tot = float(A_geom + A_curv + A_cov )

    return {
        "Action_total": A_tot,
        "Geom_total":   A_geom,
        "A_curv":       A_curv,
        "A_cov":        A_cov,       
        "self_sum":     float(M_geom.get("self_sum", 0.0)),
        "feedback_sum": float(M_geom.get("feedback_sum", 0.0)),
        "align_q_sum":  float(M_geom.get("align_q_sum", 0.0)),
        "align_p_sum":  float(M_geom.get("align_p_sum", 0.0)),
        "mass_q_sum":   float(M_geom.get("mass_q_sum", 0.0)),
        "mass_p_sum":   float(M_geom.get("mass_p_sum", 0.0)),
        "curv_q_sum":   float(M_geom.get("curv_q_sum", 0.0)),
        "curv_p_sum":   float(M_geom.get("curv_p_sum", 0.0)),
    }




