# -*- coding: utf-8 -*-
"""
Created on Sat Sep 27 15:19:10 2025

@author: chris and christine
"""

import numpy as np
from runtime_context import cfg_get
from core.numerical_utils import sanitize_sigma, kl_gaussian, push_gaussian
from core.transport_cache import Omega, Phi   
from utils import _joint_mask


# ---------- common utils ----------

def _soft_weights(logits: np.ndarray, *, mode: str) -> np.ndarray:
    """Per-receiver normalization (softmax) or plain exp; with clipping."""
    if mode == "softmax":
        m = np.max(logits)
        ex = np.exp(logits - m)
        w = ex / max(1e-12, float(np.sum(ex)))
    else:
        w = np.exp(logits)
    return w.astype(np.float32, copy=False)


def _ids_of(agents):
    return [int(getattr(a, "id", i)) for i, a in enumerate(agents)]





# ---------- Q-fiber builders ----------


def build_beta_q_model_gated(ctx, agents, *, kappa: float, mode: str, eps: float, tau: float):
    """
    Pixelwise β_q maps for each (i<-j):
      β_{i<-j}(x,y) ∝ exp( - KL_{x,y}( Ω^q_ij q_j || Φ̃_i p_i ) / κ )

    Returns:
      beta_q: dict[(i_id, j_id)] -> (H,W) float32
      kl_q:   dict[(i_id, j_id)] -> (H,W) float32  (KL per pixel; 0 outside overlap)
    """
   

    ids = [int(getattr(a, "id", i)) for i, a in enumerate(agents)]
    beta_q, kl_q = {}, {}

    # Precompute q̂_i = Φ̃_i p_i in Q_i
    qhat_mu, qhat_S = [], []
    for ai in agents:
        A     = Phi(ctx, ai, kind="p_to_q")  # (..., q, p)
        mu_p  = np.asarray(ai.mu_p_field,  np.float32)
        S_p   = sanitize_sigma(np.asarray(ai.sigma_p_field, np.float64))
        mu_q  = np.einsum("...qp,...p->...q",  A, mu_p, optimize=True).astype(np.float32, copy=False)
        S_q   = np.einsum("...qp,...pr,...rq->...qr", A, S_p, A, optimize=True)
        S_q   = sanitize_sigma(S_q).astype(np.float64, copy=False)
        qhat_mu.append(mu_q)
        qhat_S.append(S_q)

    for i_idx, ai in enumerate(agents):
        i_id     = ids[i_idx]
        mu_q_hat = qhat_mu[i_idx]  # (H,W,Kq)
        S_q_hat  = qhat_S[i_idx]   # (H,W,Kq,Kq)

        H, W = mu_q_hat.shape[:2]

        KL_maps_masked = []   # list of (J,H,W) masked with +inf outside overlap
        KL_maps_grad   = []   # list of (J,H,W) with 0 outside overlap (for grads)
        sender_id      = []
        masks          = []   # (H,W) bool per sender

        for j_idx, aj in enumerate(agents):
            if j_idx == i_idx:
                continue
            j_id = ids[j_idx]

            overlap = _joint_mask(ai, aj, tau=tau, as_vector=False)  # (H,W) bool
            if not np.any(overlap):
                continue

            Om_q   = Omega(ctx, ai, aj, which="q")
            mu_qj  = np.asarray(aj.mu_q_field,  np.float32)
            S_qj   = sanitize_sigma(np.asarray(aj.sigma_q_field, np.float64))

            mu_t, S_t, _ = push_gaussian(
                mu_qj, S_qj, Om_q, eps=eps, return_inv=True, assume_orthogonal=False
            )

            KLpx = kl_gaussian(mu_t, S_t, mu_q_hat, S_q_hat)  # expect (H,W)
            KLpx = np.asarray(KLpx, np.float64)
            if KLpx.shape[:2] != (H, W):
                raise ValueError(f"KLpx spatial dims {KLpx.shape[:2]} != (H,W)=({H},{W}) for (i={i_id}, j={j_id})")
            if KLpx.ndim > 2:
                KLpx = KLpx.reshape(H, W, -1).sum(axis=-1)  # collapse trailing axes

            # For β construction: +inf outside overlap so exp(-inf)=0
            KL_masked = np.where(overlap, KLpx, np.inf)
            # For gradient weighting: 0 outside overlap (finite field)
            KL_grad   = np.where(overlap, KLpx, 0.0).astype(np.float32, copy=False)

            KL_maps_masked.append(KL_masked)
            KL_maps_grad.append(KL_grad)
            sender_id.append(j_id)
            masks.append(overlap)

        if not sender_id:
            continue

        # Stack senders: (J,H,W)
        K = np.stack(KL_maps_masked, axis=0)
        if K.shape[1:] != (H, W):
            raise ValueError(f"Stacked KL maps shape {K.shape} wrong; expected (*,{H},{W})")

        # logits = -KL/κ
        logits = -K / max(1e-12, float(kappa))

        mode_l = (mode or "softmax").lower()
        if mode_l in ("softmax", "sm", "normexp"):
            m   = np.max(logits, axis=0, keepdims=True)       # (1,H,W)
            ex  = np.exp(logits - m) * np.isfinite(K)         # zero at masked pixels
            den = np.sum(ex, axis=0, keepdims=True)           # (1,H,W)
            den = np.maximum(den, 1e-12)
            Wj  = ex / den                                    # (J,H,W)
        elif mode_l in ("exp", "gated-exp", "exp-gated"):
            Wj  = np.exp(logits) * np.isfinite(K)             # (J,H,W)
        else:
            m   = np.max(logits, axis=0, keepdims=True)
            ex  = np.exp(logits - m) * np.isfinite(K)
            den = np.sum(ex, axis=0, keepdims=True)
            den = np.maximum(den, 1e-12)
            Wj  = ex / den

        
        # Store per-edge β and KL fields
        for s, j_id in enumerate(sender_id):
            wm = Wj[s]                               # (H,W)
            if masks[s] is not None:
                wm = np.where(masks[s], wm, 0.0)
            wm = np.asarray(wm, np.float32, order="C")
            if wm.ndim != 2:
                wm = wm.reshape(H, W, -1).sum(axis=-1)
            if wm.shape != (H, W):
                raise ValueError(f"β_q map shape {wm.shape} not (H,W)=({H},{W}) for (i={i_id}, j={j_id})")

            beta_q[(i_id, int(j_id))] = wm
            kl_q[(i_id, int(j_id))]   = KL_maps_grad[s].astype(np.float32, copy=False)

    return beta_q, kl_q





def build_beta_q_peer(ctx, agents, *, kappa: float, mode: str, eps: float, tau: float):
    """
    Pixelwise β_q for each edge (i<-j) from KL(q_i || Ω^q_ij q_j).

    Returns:
      beta_q: dict[(i_id, j_id)] -> (H,W) float32
      kl_q:   dict[(i_id, j_id)] -> (H,W) float32  (KL per pixel; 0 outside overlap)
    """
    

    tiny   = 1e-12
    kappa  = float(max(kappa, tiny))
    ids    = _ids_of(agents)

    beta_q, kl_q = {}, {}

    for i_idx, ai in enumerate(agents):
        i_id = int(ids[i_idx])

        # Receiver belief (in Q_i), authoritative (H,W)
        mu_i = np.asarray(ai.mu_q_field,  np.float32)                 # (H,W,Kq)
        S_i  = sanitize_sigma(np.asarray(ai.sigma_q_field, np.float64))# (H,W,Kq,Kq)
        H, W = mu_i.shape[:2]

        # Collect sender KL maps (masked with +inf outside overlap for softmax)
        K_masked = []   # list of (H,W) float64 with +inf off-overlap
        K_grad   = []   # list of (H,W) float32 with 0 off-overlap (for grads)
        js       = []   # sender ids
        masks    = []   # sender overlap masks (H,W) bool

        for j_idx, aj in enumerate(agents):
            if j_idx == i_idx:
                continue
            j_id = int(ids[j_idx])

            # 2-D overlap mask (avoids (H,W,W) broadcasts)
            overlap = _joint_mask(ai, aj, tau=tau, as_vector=False)   # (H,W) bool
            if not np.any(overlap):
                continue

            # Push sender belief into i's q-frame
            Om_q  = Omega(ctx, ai, aj, which="q")
            mu_qj = np.asarray(aj.mu_q_field,  np.float32)
            S_qj  = sanitize_sigma(np.asarray(aj.sigma_q_field, np.float64))
            mu_t, S_t, _ = push_gaussian(
                mu_qj, S_qj, Om_q, eps=eps, return_inv=True, assume_orthogonal=False
            )

            # Per-pixel KL: KL(q_i || Ω^q_ij q_j)
            KLpx = kl_gaussian(mu_i, S_i, mu_t, S_t)  # expect (H,W)
            KLpx = np.asarray(KLpx, np.float64)
            if KLpx.shape[:2] != (H, W):
                raise ValueError(f"KLpx spatial dims {KLpx.shape[:2]} != (H,W)=({H},{W}) for (i={i_id}, j={j_id})")
            if KLpx.ndim > 2:
                KLpx = KLpx.reshape(H, W, -1).sum(axis=-1)

            # For β construction: +inf outside overlap so exp(-inf)=0
            K_masked.append(np.where(overlap, KLpx, np.inf))
            # For gradient weighting: 0 outside overlap (finite field)
            K_grad.append(np.where(overlap, KLpx, 0.0).astype(np.float32, copy=False))
            js.append(j_id)
            masks.append(overlap)

        if not js:
            continue

        # Stack senders: (J,H,W)
        K = np.stack(K_masked, axis=0)
        if K.shape[1:] != (H, W):
            raise ValueError(f"Stacked KL maps shape {K.shape} wrong; expected (*,{H},{W})")

        # logits = -KL/κ
        L = -K / kappa  # (J,H,W)

        mode_l = (mode or "softmax").lower()
        if mode_l in ("softmax", "sm", "normexp"):
            m   = np.max(L, axis=0, keepdims=True)       # (1,H,W)
            ex  = np.exp(L - m) * np.isfinite(K)         # zero at masked pixels
            den = np.sum(ex, axis=0, keepdims=True)      # (1,H,W)
            den = np.maximum(den, tiny)
            Wj  = ex / den                                # (J,H,W)
        elif mode_l in ("exp", "gated-exp", "exp-gated"):
            Wj  = np.exp(L) * np.isfinite(K)             # (J,H,W)
        else:
            # fallback to softmax
            m   = np.max(L, axis=0, keepdims=True)
            ex  = np.exp(L - m) * np.isfinite(K)
            den = np.sum(ex, axis=0, keepdims=True)
            den = np.maximum(den, tiny)
            Wj  = ex / den

        # Store per-edge β and KL fields (as float32, shape (H,W))
        for s, j_id in enumerate(js):
            w_m = Wj[s]                       # (H,W)
            if masks[s] is not None:
                w_m = np.where(masks[s], w_m, 0.0)
            w_m = np.asarray(w_m, np.float32, order="C")
            if w_m.ndim != 2:
                w_m = w_m.reshape(H, W, -1).sum(axis=-1)
            if w_m.shape != (H, W):
                raise ValueError(f"β_q map shape {w_m.shape} not (H,W)=({H},{W}) for (i={i_id}, j={j_id})")

            beta_q[(i_id, int(j_id))] = w_m
            kl_q[(i_id, int(j_id))]   = K_grad[s]  # (H,W) float32

    return beta_q, kl_q






def build_beta_q_model_gated_reversed(
    ctx, agents, *,
    kappa: float,
    mode: str,
    eps: float,
    tau: float,
):
    """
    Pixelwise β_q (reversed order):
        KL( Φ̃_i p_i  ||  Ω^q_ij q_j )   in Q_i, per pixel.

    Returns:
      beta_q: dict[(i_id, j_id)] -> (H,W) float32
      kl_q:   dict[(i_id, j_id)] -> (H,W) float32   (KL per pixel; 0 outside overlap)
    """
    

    tiny  = 1e-12
    kappa = float(max(kappa, tiny))
    mode_l = (mode or "softmax").lower()

    beta_q, kl_q = {}, {}
    ids = _ids_of(agents)

    # Precompute receiver's model rendered in Q_i: q̂_i = Φ̃_i p_i
    qhat_mu, qhat_S = [], []
    for ai in agents:
        A     = Phi(ctx, ai, kind="p_to_q")  # (..., q, p)
        mu_p  = np.asarray(ai.mu_p_field,  np.float32)
        S_p   = sanitize_sigma(np.asarray(ai.sigma_p_field, np.float64))
        mu_qh = np.einsum("...qp,...p->...q",  A, mu_p, optimize=True).astype(np.float32, copy=False)
        S_qh  = np.einsum("...qp,...pr,...rq->...qr", A, S_p, A, optimize=True)
        S_qh  = sanitize_sigma(S_qh).astype(np.float64, copy=False)
        qhat_mu.append(mu_qh)
        qhat_S.append(S_qh)

    for i_idx, ai in enumerate(agents):
        i_id    = int(ids[i_idx])
        mu_qhat = qhat_mu[i_idx]   # (H,W,Kq)
        S_qhat  = qhat_S[i_idx]    # (H,W,Kq,Kq)
        H, W    = mu_qhat.shape[:2]

        K_masked = []  # (J,H,W) with +inf off-overlap for softmax/exps
        K_grad   = []  # (J,H,W) with 0 off-overlap for grads
        js       = []
        masks    = []

        for j_idx, aj in enumerate(agents):
            if j_idx == i_idx:
                continue
            j_id = int(ids[j_idx])

            # 2-D mask to avoid (H,W,W)
            overlap = _joint_mask(ai, aj, tau=tau, as_vector=False)  # (H,W) bool
            if not np.any(overlap):
                continue

            # Sender belief in i's Q-frame: Ω^q_ij q_j
            Om_q  = Omega(ctx, ai, aj, which="q")
            mu_qj = np.asarray(aj.mu_q_field,  np.float32)
            S_qj  = sanitize_sigma(np.asarray(aj.sigma_q_field, np.float64))
            mu_t, S_t, _ = push_gaussian(
                mu_qj, S_qj, Om_q, eps=eps, return_inv=True, assume_orthogonal=False
            )

            # KL per pixel: KL( Φ̃_i p_i || Ω^q_ij q_j )
            KLpx = kl_gaussian(mu_qhat, S_qhat, mu_t, S_t)  # expect (H,W)
            KLpx = np.asarray(KLpx, np.float64)
            if KLpx.shape[:2] != (H, W):
                raise ValueError(f"KLpx spatial dims {KLpx.shape[:2]} != (H,W)=({H},{W}) for (i={i_id}, j={j_id})")
            if KLpx.ndim > 2:
                KLpx = KLpx.reshape(H, W, -1).sum(axis=-1)

            # For β construction: -inf where no overlap
            K_masked.append(np.where(overlap, KLpx, np.inf))
            # For grads: 0 where no overlap
            K_grad.append(np.where(overlap, KLpx, 0.0).astype(np.float32, copy=False))
            js.append(j_id)
            masks.append(overlap)

        if not js:
            continue

        # Stack senders: (J,H,W)
        K = np.stack(K_masked, axis=0)
        if K.shape[1:] != (H, W):
            raise ValueError(f"Stacked KL maps shape {K.shape} wrong; expected (*,{H},{W})")

        # logits = -KL/κ
        L = -K / kappa  # (J,H,W)

        if mode_l in ("softmax", "sm", "normexp"):
            m   = np.max(L, axis=0, keepdims=True)      # (1,H,W)
            ex  = np.exp(L - m) * np.isfinite(K)        # zero off-overlap
            den = np.sum(ex, axis=0, keepdims=True)     # (1,H,W)
            den = np.maximum(den, tiny)
            Wj  = ex / den                               # (J,H,W)
        elif mode_l in ("exp", "gated-exp", "exp-gated"):
            Wj  = np.exp(L) * np.isfinite(K)            # (J,H,W)
        else:
            # fallback to softmax
            m   = np.max(L, axis=0, keepdims=True)
            ex  = np.exp(L - m) * np.isfinite(K)
            den = np.sum(ex, axis=0, keepdims=True)
            den = np.maximum(den, tiny)
            Wj  = ex / den

        # Store per-edge fields
        for s, j_id in enumerate(js):
            w_m = Wj[s]  # (H,W)
            if masks[s] is not None:
                w_m = np.where(masks[s], w_m, 0.0)
            w_m = np.asarray(w_m, np.float32, order="C")
            if w_m.ndim != 2:
                w_m = w_m.reshape(H, W, -1).sum(axis=-1)
            if w_m.shape != (H, W):
                raise ValueError(f"β_q map shape {w_m.shape} not (H,W)=({H},{W}) for (i={i_id}, j={j_id})")

            beta_q[(i_id, int(j_id))] = w_m
            kl_q[(i_id, int(j_id))]   = K_grad[s]  # (H,W) float32

    return beta_q, kl_q




def build_beta_q_belief_to_model(ctx, agents, *, kappa: float, mode: str, eps: float, tau: float):
    """
    Pixelwise β_q for edges (i<-j) from:
        KL( p_i || Φ_i[ Ω^q_ij q_j ] )   evaluated in P_i per pixel.

    Returns:
      beta_q: dict[(i_id, j_id)] -> (H,W) float32
      kl_q:   dict[(i_id, j_id)] -> (H,W) float32  (KL per pixel; 0 outside overlap)
    """
    

    tiny  = 1e-12
    kappa = float(max(kappa, tiny))
    mode_l = (mode or "softmax").lower()

    beta_q, kl_q = {}, {}
    ids = _ids_of(agents)

    for i_idx, ai in enumerate(agents):
        i_id = int(ids[i_idx])

        # Receiver model fields in P_i (authoritative spatial shape)
        mu_pi = np.asarray(ai.mu_p_field,  np.float32)            # (H,W,Kp)
        S_pi  = sanitize_sigma(np.asarray(ai.sigma_p_field, np.float64))  # (H,W,Kp,Kp)
        H, W  = mu_pi.shape[:2]

        # Encoder Φ_i : Q_i -> P_i
        Phi_i = Phi(ctx, ai, kind="q_to_p")                       # (H,W,Kp,Kq)

        K_masked = []      # list of (H,W) float64; +inf off-overlap (for softmax)
        K_grad   = []      # list of (H,W) float32; 0 off-overlap (for grads)
        js       = []
        masks    = []

        for j_idx, aj in enumerate(agents):
            if j_idx == i_idx:
                continue
            j_id = int(ids[j_idx])

            # 2-D overlap in i's frame
            overlap = _joint_mask(ai, aj, tau=tau, as_vector=False)  # (H,W) bool
            if not np.any(overlap):
                continue

            # Push sender belief into i's Q-frame
            Om_q  = Omega(ctx, ai, aj, which="q")
            mu_qj = np.asarray(aj.mu_q_field,  np.float32)
            S_qj  = sanitize_sigma(np.asarray(aj.sigma_q_field, np.float64))
            mu_qj_t, S_qj_t, _ = push_gaussian(
                mu_qj, S_qj, Om_q, eps=eps, return_inv=True, assume_orthogonal=False
            )

            # Map into P_i via Φ_i: μ_hat_p = Φ μ_q ; Σ_hat_p = Φ Σ_q Φ^T
            mu_hat_p = np.einsum("...pk,...k->...p",  Phi_i, mu_qj_t, optimize=True)               # (H,W,Kp)
            S_hat_p  = np.einsum("...pa,...ab,...pb->...pp", Phi_i, S_qj_t, Phi_i, optimize=True)  # (H,W,Kp,Kp)
            S_hat_p  = sanitize_sigma(S_hat_p).astype(np.float64, copy=False)

            # Per-pixel KL in P_i: KL(p_i || Φ_i[Ω q_j])
            KLpx = kl_gaussian(mu_pi, S_pi, mu_hat_p, S_hat_p)   # expect (H,W)
            KLpx = np.asarray(KLpx, np.float64)
            if KLpx.shape[:2] != (H, W):
                raise ValueError(f"KLpx spatial dims {KLpx.shape[:2]} != (H,W)=({H},{W}) for (i={i_id}, j={j_id})")
            if KLpx.ndim > 2:
                KLpx = KLpx.reshape(H, W, -1).sum(axis=-1)

            # For β construction: -inf where no overlap (excluded from softmax)
            K_masked.append(np.where(overlap, KLpx, np.inf))
            # For gradient weighting: 0 outside overlap
            K_grad.append(np.where(overlap, KLpx, 0.0).astype(np.float32, copy=False))
            js.append(j_id)
            masks.append(overlap)

        if not js:
            continue

        # Stack senders: (J,H,W); logits = -KL/κ
        K = np.stack(K_masked, axis=0)
        if K.shape[1:] != (H, W):
            raise ValueError(f"Stacked KL maps shape {K.shape} wrong; expected (*,{H},{W})")
        L = -K / kappa

        if mode_l in ("softmax", "sm", "normexp"):
            m   = np.max(L, axis=0, keepdims=True)        # (1,H,W)
            ex  = np.exp(L - m) * np.isfinite(K)          # zero off-overlap
            den = np.sum(ex, axis=0, keepdims=True)       # (1,H,W)
            den = np.maximum(den, tiny)
            Wj  = ex / den                                # (J,H,W)
        elif mode_l in ("exp", "gated-exp", "exp-gated"):
            Wj  = np.exp(L) * np.isfinite(K)              # (J,H,W)
        else:
            m   = np.max(L, axis=0, keepdims=True)
            ex  = np.exp(L - m) * np.isfinite(K)
            den = np.sum(ex, axis=0, keepdims=True)
            den = np.maximum(den, tiny)
            Wj  = ex / den

        # Store per-edge fields
        for s, j_id in enumerate(js):
            w_m = Wj[s]  # (H,W)
            if masks[s] is not None:
                w_m = np.where(masks[s], w_m, 0.0)
            w_m = np.asarray(w_m, np.float32, order="C")
            if w_m.ndim != 2:
                w_m = w_m.reshape(H, W, -1).sum(axis=-1)
            if w_m.shape != (H, W):
                raise ValueError(f"β_q map shape {w_m.shape} not (H,W)=({H},{W}) for (i={i_id}, j={j_id})")

            beta_q[(i_id, int(j_id))] = w_m
            kl_q[(i_id, int(j_id))]   = K_grad[s]  # (H,W) float32

    return beta_q, kl_q


# ---------- P-fiber builders ----------


def build_beta_p_belief_from_q(
    ctx,
    agents,
    *,
    kappa: float,
    mode: str = "softmax",   
    eps: float = 1e-6,
    tau: float = 1e-6,
):
    """
    β_p(x,y) from KL( Φ_i[Ω^q_ij q_j] || p_i ) in P_i, per pixel.

    Returns:
      beta_p: dict[(i_id, j_id)] -> (H,W) float32
      kl_p:   dict[(i_id, j_id)] -> (H,W) float32  (KL per pixel; 0 outside overlap)
    """
    
    tiny = 1e-12
    kappa = float(max(kappa, tiny))
    

    beta_p, kl_p = {}, {}
    ids = _ids_of(agents)

    for i_idx, ai in enumerate(agents):
        i_id = int(ids[i_idx])

        mu_pi = np.asarray(ai.mu_p_field, np.float32)           # (H,W,Kp)
        S_pi  = sanitize_sigma(np.asarray(ai.sigma_p_field, np.float64))  # (H,W,Kp,Kp)
        Phi_i = Phi(ctx, ai, kind="q_to_p")                     # (H,W,Kp,Kq)
        H, W  = mu_pi.shape[:2]

        logits_list = []   # (J,H,W)
        js = []            # sender ids
        mask_list = []     # (H,W) bool
        kl_grad_list = []  # (J,H,W) KL with 0 outside overlap

        for j_idx, aj in enumerate(agents):
            if j_idx == i_idx:
                continue
            j_id = int(ids[j_idx])

            overlap = _joint_mask(ai, aj, tau=tau, as_vector=False)  # (H,W) bool
            if not np.any(overlap):
                continue

            Om_q  = Omega(ctx, ai, aj, which="q")
            mu_qj = np.asarray(aj.mu_q_field, np.float32)
            S_qj  = sanitize_sigma(np.asarray(aj.sigma_q_field, np.float64))
            mu_qj_t, S_qj_t, _ = push_gaussian(
                mu_qj, S_qj, Om_q, eps=eps, return_inv=True, assume_orthogonal=False
            )

            mu_hat_p = np.einsum("...pq,...q->...p",  Phi_i, mu_qj_t, optimize=True)            # (H,W,Kp)
            S_hat_p  = np.einsum("...pq,...qr,...sr->...ps", Phi_i, S_qj_t, Phi_i, optimize=True) # (H,W,Kp,Kp)
            S_hat_p  = sanitize_sigma(S_hat_p).astype(np.float64, copy=False)

            KLpx = kl_gaussian(mu_hat_p, S_hat_p, mu_pi, S_pi)   # expect (H,W)
            KLpx = np.asarray(KLpx, np.float64)
            if KLpx.shape[:2] != (H, W):
                raise ValueError(f"KLpx spatial dims {KLpx.shape[:2]} != (H,W)=({H},{W}) for (i={i_id}, j={j_id})")
            if KLpx.ndim > 2:
                KLpx = KLpx.reshape(H, W, -1).sum(axis=-1)

            # logits: -inf outside overlap (excluded)
            logit = -KLpx / kappa
            logit = np.where(overlap, logit, -np.inf)

            logits_list.append(logit)
            mask_list.append(overlap)
            js.append(j_id)
            # KL for gradients: 0 outside overlap
            kl_grad_list.append(np.where(overlap, KLpx, 0.0).astype(np.float32, copy=False))

        if not js:
            continue

        L = np.stack(logits_list, axis=0)    # (M,H,W)
        if L.shape[1:] != (H, W):
            raise ValueError(f"Stacked logits shape {L.shape} wrong; expected (*,{H},{W})")

        overlap_any = np.any(np.stack(mask_list, axis=0), axis=0)  # (H,W) bool

        mode_l = (mode or "softmax").lower()
        if mode_l in ("softmax", "sm", "normexp"):
            Lmax = np.max(L, axis=0)                         # (H,W)
            exps = np.exp(L - Lmax[None, ...])               # (M,H,W)
            exps = np.where(overlap_any[None, ...], exps, 0.0)
            Z = np.sum(exps, axis=0)                         # (H,W)
            Z = np.maximum(Z, tiny)
            Wjx = exps / Z[None, ...]                        # (M,H,W)
        elif mode_l in ("exp", "gated-exp", "exp-gated"):
            Wjx = np.exp(L)                                   # (M,H,W)
            Wjx = np.where(overlap_any[None, ...], Wjx, 0.0)
        else:
            Lmax = np.max(L, axis=0)
            exps = np.exp(L - Lmax[None, ...])
            exps = np.where(overlap_any[None, ...], exps, 0.0)
            Z = np.sum(exps, axis=0)
            Z = np.maximum(Z, tiny)
            Wjx = exps / Z[None, ...]

        
        # Store per-edge fields
        for m, j_id in enumerate(js):
            w_m = Wjx[m]                                      # (H,W)
            if mask_list[m] is not None:
                w_m = np.where(mask_list[m], w_m, 0.0)
            w_m = np.asarray(w_m, np.float32, order="C")
            if w_m.ndim != 2:
                w_m = w_m.reshape(H, W, -1).sum(axis=-1)
            if w_m.shape != (H, W):
                raise ValueError(f"β_p map shape {w_m.shape} not (H,W)=({H},{W}) for (i={i_id}, j={j_id})")

            beta_p[(i_id, int(j_id))] = w_m
            kl_p[(i_id, int(j_id))]   = kl_grad_list[m]

    return beta_p, kl_p



def build_beta_p_peer(ctx, agents, *, kappa: float, mode: str, eps: float, tau: float):
    """
    Pixelwise β_p for each edge (i<-j) from:
        KL( p_i || Ω^p_ij p_j )   in P_i, per pixel.

    Returns:
      beta_p: dict[(i_id, j_id)] -> (H,W) float32
      kl_p:   dict[(i_id, j_id)] -> (H,W) float32  (KL per pixel; 0 outside overlap)
    """
    

    tiny  = 1e-12
    kappa = float(max(kappa, tiny))
    mode_l = (mode or "softmax").lower()

    beta_p, kl_p = {}, {}
    ids = _ids_of(agents)

    for i_idx, ai in enumerate(agents):
        i_id = int(ids[i_idx])

        # Receiver model (in P_i), authoritative spatial shape
        mu_pi = np.asarray(ai.mu_p_field,  np.float32)                  # (H,W,Kp)
        S_pi  = sanitize_sigma(np.asarray(ai.sigma_p_field, np.float64))# (H,W,Kp,Kp)
        H, W  = mu_pi.shape[:2]

        K_masked = []   # (J,H,W) with +inf off-overlap (for softmax/exps)
        K_grad   = []   # (J,H,W) with 0 off-overlap (for grads)
        js       = []
        masks    = []

        for j_idx, aj in enumerate(agents):
            if j_idx == i_idx:
                continue
            j_id = int(ids[j_idx])

            # 2-D overlap mask in i's frame
            overlap = _joint_mask(ai, aj, tau=tau, as_vector=False)     # (H,W) bool
            if not np.any(overlap):
                continue

            # Push sender model into i's P-frame: Ω^p_ij p_j
            Om_p  = Omega(ctx, ai, aj, which="p")
            mu_pj = np.asarray(aj.mu_p_field,  np.float32)
            S_pj  = sanitize_sigma(np.asarray(aj.sigma_p_field, np.float64))
            mu_t, S_t, _ = push_gaussian(
                mu_pj, S_pj, Om_p, eps=eps, return_inv=True, assume_orthogonal=False
            )

            # Per-pixel KL: KL( p_i || Ω^p_ij p_j )
            KLpx = kl_gaussian(mu_pi, S_pi, mu_t, S_t)                  # expect (H,W)
            KLpx = np.asarray(KLpx, np.float64)
            if KLpx.shape[:2] != (H, W):
                raise ValueError(f"KLpx spatial dims {KLpx.shape[:2]} != (H,W)=({H},{W}) for (i={i_id}, j={j_id})")
            if KLpx.ndim > 2:
                KLpx = KLpx.reshape(H, W, -1).sum(axis=-1)

            # For β construction: +inf where no overlap (excluded from softmax)
            K_masked.append(np.where(overlap, KLpx, np.inf))
            # For gradient weighting: 0 outside overlap
            K_grad.append(np.where(overlap, KLpx, 0.0).astype(np.float32, copy=False))
            js.append(j_id)
            masks.append(overlap)

        if not js:
            continue

        # Stack senders and build logits
        K = np.stack(K_masked, axis=0)                                   # (J,H,W)
        if K.shape[1:] != (H, W):
            raise ValueError(f"Stacked KL maps shape {K.shape} wrong; expected (*,{H},{W})")
        L = -K / kappa                                                   # (J,H,W)

        # Per-pixel weights across senders
        if mode_l in ("softmax", "sm", "normexp"):
            m   = np.max(L, axis=0, keepdims=True)                       # (1,H,W)
            ex  = np.exp(L - m) * np.isfinite(K)                         # zero off-overlap
            den = np.sum(ex, axis=0, keepdims=True)                      # (1,H,W)
            den = np.maximum(den, tiny)
            Wj  = ex / den                                               # (J,H,W)
        elif mode_l in ("exp", "gated-exp", "exp-gated"):
            Wj  = np.exp(L) * np.isfinite(K)                             # (J,H,W)
        else:
            m   = np.max(L, axis=0, keepdims=True)
            ex  = np.exp(L - m) * np.isfinite(K)
            den = np.sum(ex, axis=0, keepdims=True)
            den = np.maximum(den, tiny)
            Wj  = ex / den

        # Store per-edge β and KL
        for s, j_id in enumerate(js):
            w_m = Wj[s]                                                  # (H,W)
            if masks[s] is not None:
                w_m = np.where(masks[s], w_m, 0.0)
            w_m = np.asarray(w_m, np.float32, order="C")
            if w_m.ndim != 2:
                w_m = w_m.reshape(H, W, -1).sum(axis=-1)
            if w_m.shape != (H, W):
                raise ValueError(f"β_p map shape {w_m.shape} not (H,W)=({H},{W}) for (i={i_id}, j={j_id})")

            beta_p[(i_id, int(j_id))] = w_m
            kl_p[(i_id, int(j_id))]   = K_grad[s]                        # (H,W) float32

    return beta_p, kl_p




#============================================================================
#
#       ENTRY POINT AND WEIGHTS
#
#===========================================================================


def compute_edge_betas(ctx, agents):
    """
    Build per-edge attention for BOTH fibers with per-receiver normalization.

    Config keys:
      obs_beta_enable: bool
     
      obs_beta_kappa:  float
      obs_beta_mode:   "softmax" | "exp" | ...
      obs_beta_q_basis in {"peer_q","peer_q_rev","model_gated_q","belief_to_model","model_gated_q_rev"}
      obs_beta_p_basis in {"peer_p","obs_to_model","model_to_obs"}
      obs_beta_detach: bool  (if False, β-through-softmax grads are enabled via s_ij)
    """
    # Disabled?
    if not bool(cfg_get(ctx, "obs_beta_enable", True)):
        setattr(ctx, "_edge_beta_q", None)
        setattr(ctx, "_edge_beta_p", None)
        setattr(ctx, "_edge_kl_q",   {})
        setattr(ctx, "_edge_kl_p",   {})
        setattr(ctx, "_edge_beta_cfg", {
            "q": {"kappa": 1.0, "mode": "softmax"},
            "p": {"kappa": 1.0, "mode": "softmax"},
            "detach": True,   # ✅ canonical key
        })
        return

   
    kappa  = float(cfg_get(ctx, "obs_beta_kappa", 1.0))
    mode   = str(cfg_get(ctx, "obs_beta_mode", "softmax")).lower()
    eps    = float(cfg_get(ctx, "eps", 1e-8))
    tau    = float(cfg_get(ctx, "support_tau", 1e-6))
    detach = bool(cfg_get(ctx, "obs_beta_detach", False))

    q_basis = str(cfg_get(ctx, "obs_beta_q_basis", "model_gated_q")).lower()
    p_basis = str(cfg_get(ctx, "obs_beta_p_basis", "peer_p")).lower()

    # Builders (some return β; some return (β, KL))
    q_builders = {
        "peer_q":            build_beta_q_peer,
        
        "model_gated_q":     build_beta_q_model_gated,   # returns (β, KL)
        "belief_to_model":   build_beta_q_belief_to_model,
        "model_gated_q_rev": build_beta_q_model_gated_reversed,
    }
    p_builders = {
        "peer_p":            build_beta_p_peer,
        "obs_to_model":      build_beta_p_belief_from_q, # returns (β, KL)
        
    }

    if q_basis not in q_builders:
        raise ValueError(f"Unknown obs_beta_q_basis={q_basis}")
    if p_basis not in p_builders:
        raise ValueError(f"Unknown obs_beta_p_basis={p_basis}")

    # Q-side
    out_q = q_builders[q_basis](ctx, agents, kappa=kappa, mode=mode, eps=eps, tau=tau)
    beta_q, kl_q = (out_q if (isinstance(out_q, tuple) and len(out_q) == 2) else (out_q, {}))

    # P-side
    out_p = p_builders[p_basis](ctx, agents, kappa=kappa, mode=mode, eps=eps, tau=tau)
    beta_p, kl_p = (out_p if (isinstance(out_p, tuple) and len(out_p) == 2) else (out_p, {}))

    # Normalize empty → None for convenience
    beta_q = beta_q if beta_q else None
    beta_p = beta_p if beta_p else None

    # Stash
    setattr(ctx, "_edge_beta_q", beta_q)
    setattr(ctx, "_edge_beta_p", beta_p)
    setattr(ctx, "_edge_kl_q",   kl_q or {})
    setattr(ctx, "_edge_kl_p",   kl_p or {})
    setattr(ctx, "_edge_beta_cfg", {
        "q": {"kappa": float(kappa), "mode": str(mode)},
        "p": {"kappa": float(kappa), "mode": str(mode)},
        "detach": bool(detach),  # ✅ canonical key
    })

 

def beta_effective_weight(ctx, i_id: int, j_id: int, *, which: str, joint_mask, allow_exp: bool = True):
    """
    Returns s_ij(x,y) for weighting ∂KL/∂{μ,Σ,φ}:
      softmax:              s = β * [1 - (KL_ij - KL_bar)/kappa],  KL_bar = Σ_r β_ir KL_ir
      exp:                  s = β * [1 - KL_ij/kappa]
    Requires ctx._edge_beta_{q,p}, ctx._edge_kl_{q,p}, and ctx._edge_beta_cfg.
    """
    
    # --- validate inputs ---
    if which not in ("q", "p"):
        raise ValueError(f"beta_effective_weight: which must be 'q' or 'p', got {which!r}")
    joint_mask = np.asarray(joint_mask)
    if joint_mask.ndim != 2:
        raise ValueError(f"beta_effective_weight: joint_mask must be 2-D, got {joint_mask.shape}")
    
    H, W = joint_mask.shape
    mask_f32 = joint_mask.astype(np.float32, copy=False)

    # --- fetch maps and config ---
    beta_map = getattr(ctx, "_edge_beta_q" if which == "q" else "_edge_beta_p", {}) or {}
    kl_map   = getattr(ctx, "_edge_kl_q"   if which == "q" else "_edge_kl_p", {}) or {}
    cfg      = getattr(ctx, "_edge_beta_cfg", {}) or {}
    sub      = cfg.get(which, {})
    kappa    = float(sub.get("kappa", 1.0))
    mode     = str(sub.get("mode", "softmax")).lower()
    detach   = bool(cfg.get("detach", True))  # ✅ canonical key

    # --- look up β_ij ---
    beta_ij = beta_map.get((i_id, j_id), None)
    if beta_ij is None:
        return np.zeros((H, W), np.float32)
    beta_ij = np.asarray(beta_ij, np.float32)
    if beta_ij.shape != (H, W):
        raise ValueError(f"beta_effective_weight: β shape {beta_ij.shape} != {(H, W)} for edge {(i_id, j_id)}")

    # Apply mask once here
    beta_ij = beta_ij * mask_f32

    if detach:
        return beta_ij

    # --- need KL maps to include β-through-softmax grads ---
    KL_ij = kl_map.get((i_id, j_id), None)
    if KL_ij is None:
        raise RuntimeError(f"beta_effective_weight: missing KL map for edge {(i_id, j_id)} and which='{which}'")
    KL_ij = np.asarray(KL_ij, np.float32)
    if KL_ij.shape != (H, W):
        raise ValueError(f"beta_effective_weight: KL shape {KL_ij.shape} != {(H, W)} for edge {(i_id, j_id)}")

    kappa = max(kappa, 1e-12)

    if mode in ("softmax", "sm", "normexp"):
        # KL_bar = Σ_r β_ir KL_ir  (same receiver i)
        KL_bar = np.zeros((H, W), np.float32)
        for (ii, jj), b in beta_map.items():
            if ii != i_id:
                continue
            b = np.asarray(b, np.float32)
            if b.shape != (H, W):
                raise ValueError("beta_effective_weight: inconsistent β field shape")
            KL_r = kl_map.get((ii, jj), None)
            if KL_r is None:
                raise RuntimeError(f"beta_effective_weight: missing KL map for edge {(ii, jj)}")
            KL_r = np.asarray(KL_r, np.float32)
            if KL_r.shape != (H, W):
                raise ValueError("beta_effective_weight: inconsistent KL field shape")
            KL_bar += (b * KL_r)

        s = beta_ij * (1.0 - (KL_ij - KL_bar) / kappa)

    elif allow_exp and mode in ("exp", "gated-exp", "exp-gated"):
        s = beta_ij * (1.0 - KL_ij / kappa)

    else:
        # default to softmax behavior
        KL_bar = np.zeros((H, W), np.float32)
        for (ii, jj), b in beta_map.items():
            if ii != i_id:
                continue
            b = np.asarray(b, np.float32)
            KL_r = np.asarray(kl_map.get((ii, jj), None), np.float32)
            KL_bar += (b * KL_r)
        s = beta_ij * (1.0 - (KL_ij - KL_bar) / kappa)

    # Mask already applied to β; s inherits that support. Return as float32.
    return s.astype(np.float32, copy=False)





