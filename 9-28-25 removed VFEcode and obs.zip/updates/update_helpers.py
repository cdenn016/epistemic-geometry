# -*- coding: utf-8 -*-
"""
Created on Mon Sep  8 16:26:26 2025

@author: chris and christine
"""

import numpy as np
from core.numerical_utils import safe_inv, sanitize_sigma  




# --- Unified dirty manager ----------------------------------------------------
class DirtyManager:
    """
    Single source of truth for 'dirty' state.

    Responsibilities:
      - Track dirty agents across categories: fields, kl, morphisms
      - Provide stable IDs (no object-id fallbacks)
      - Materialize a target agent subset by category
      - Clear agent-side flags only after successful processing
      - Bump ctx cache_version exactly when work happened
    """
    __slots__ = ("_fields", "_kl", "_morph",)

    def __init__(self):
        self._fields: set[int] = set()
        self._kl: set[int] = set()
        self._morph: set[int] = set()

    # ---- Stable ID helpers -------------------------------------------------
    @staticmethod
    def _aid(agent) -> int:
        aid = getattr(agent, "id", None)
        if aid is None:
            raise ValueError("DirtyManager: agent has no stable `id` attribute")
        return int(aid)

    # ---- Marking -----------------------------------------------------------
    def mark(self, *agents: object, kl: bool = False, morphism: bool = False) -> None:
        for a in agents:
            if a is None:
                continue
            aid = self._aid(a)
            # Always mark fields when any aspect of the agent changed
            self._fields.add(aid)
            setattr(a, "_dirty_fields", True)
            if kl:
                self._kl.add(aid)
                setattr(a, "_dirty_kl", True)
            if morphism:
                self._morph.add(aid)
                setattr(a, "morphisms_dirty", True)

    def mark_morphism_only(self, *agents: object) -> None:
        self.mark(*agents, morphism=True)

    def mark_kl_only(self, *agents: object) -> None:
        self.mark(*agents, kl=True)

    # ---- Selection ---------------------------------------------------------
    def take(self, all_agents: list, category: str = "fields") -> list:
        if   category == "fields": bag = self._fields
        elif category == "kl":     bag = self._kl
        elif category == "morph":  bag = self._morph
        else:
            raise ValueError(f"DirtyManager.take: unknown category {category!r}")

        if not bag:
            return []
        wanted = {int(x) for x in bag}
        subset = [a for a in (all_agents or []) if a is not None and self._aid(a) in wanted]
        bag.clear()
        return subset

    # ---- Post-processing cleanup ------------------------------------------
    def clear_agent_flags(self, *agents: object) -> None:
        for a in agents:
            if a is None:
                continue
            if hasattr(a, "_dirty_fields"): a._dirty_fields = False
            if hasattr(a, "_dirty_kl"):     a._dirty_kl = False
            if hasattr(a, "morphisms_dirty"): a.morphisms_dirty = False


# Attach/get from ctx (one per runtime context)
def dirty_manager(ctx) -> DirtyManager:
    d = getattr(ctx, "_dirty_manager", None)
    if d is None:
        d = DirtyManager()
        setattr(ctx, "_dirty_manager", d)
    return d


def ensure_dirty(ctx, generators_q, generators_p, scope="all"):
    """
    Resolve and process dirty agents for the given scope.
    Does: inline φ/φ̃ projection, build/ensure morphism bases in cache,
         pre-warm caches (E, Jinv, Φ/Φ̃), clear flags, bump cache when work happened.
    """
    DM = dirty_manager(ctx)

    # 1) Select targets by scope
    if scope not in ("all", "children"):
        raise ValueError(f"[ensure_dirty] unknown scope={scope!r}")

    all_children = list(getattr(ctx, "children_latest", []))
    targets = DM.take(all_children, category="fields")
    targets = [t for t in targets if t is not None]
    if not targets:
        return []

    # Record whether anything *was* marked dirty (for bump decision)
    had_flags = any(
        getattr(a, "_dirty_fields", False)
        or getattr(a, "_dirty_kl", False)
        or getattr(a, "morphisms_dirty", False)
        for a in targets
    )

    did_any = False

    # 5) Clear flags only if we actually processed them
    if did_any:
        DM.clear_agent_flags(*targets)

    # 6) Bump cache exactly when we had flags and did work
    if did_any and had_flags:
        setattr(ctx, "cache_version", int(getattr(ctx, "cache_version", 0)) + 1)

    return targets








# ---------------------------------------------------------------------
# Per-agent preprocessing
# ---------------------------------------------------------------------
def refresh_agents(agents, Gq, Gp, *, ctx=None):
    """
    Lightweight preprocessing for a batch of agents, fail-fast + idempotent per step.

    Per agent:
      • ensure mask exists and normalize to a common (H,W)
      • sanitize Σ_q / Σ_p to SPD
      • optionally compute Σ^{-1}
      
      • mark per-step preprocessed
    """
    from runtime_context import cfg_get
    eps  = cfg_get(ctx, "eps", 1e-8)

    if not agents:
        raise ValueError("refresh_agents: empty `agents` list")
    
    if any(a is None for a in agents):
        raise ValueError("refresh_agents: `agents` contains None entries")
    
    if Gq is None or Gp is None:
        raise ValueError("refresh_agents: generators_q/p must be provided")
   
    step_tag   = int(getattr(ctx, "global_step", -1))
    
    # Determine canonical mask size from the first agent (after ensuring it exists)
    if not hasattr(agents[0], "mask") or agents[0].mask is None:
        print("NO MASK?!! REFRESHER\n\n")
        H0, W0 = np.asarray(agents[0].mu_q_field).shape[:2]
        agents[0].mask = np.ones((H0, W0), np.float32)
    else:
        H0, W0 = np.asarray(agents[0].mask).shape[:2]

    def _normalize_mask(m):
        """Inline normalize_mask: pad/crop to (H0,W0), force float32 2-D."""
        mm = np.asarray(m, np.float32)
        if mm.ndim >= 3:
            mm = mm[..., 0]
        out = np.zeros((H0, W0), dtype=np.float32)
        h = min(H0, mm.shape[0])
        w = min(W0, mm.shape[1])
        out[:h, :w] = mm[:h, :w]
        return out

    for a in agents:
        if getattr(a, "_preprocessed_step", None) == step_tag and step_tag >= 0:
            continue

        # guarantee a normalized mask
        if not hasattr(a, "mask") or a.mask is None:
            print("MASK IS NONE!!! REFRESHER\n\n")
            a.mask = np.ones((H0, W0), np.float32)
        else:
            a.mask = _normalize_mask(a.mask)

        # sanitize Σ fields and (optionally) invert
       
        a.sigma_q_field = sanitize_sigma(np.asarray(a.sigma_q_field, np.float64),
                                         eps=eps).astype(np.float32, copy=False)
        a.sigma_p_field = sanitize_sigma(np.asarray(a.sigma_p_field, np.float64),
                                         eps=eps).astype(np.float32, copy=False)    
        
        a.sigma_q_inv = safe_inv(a.sigma_q_field.astype(np.float64), eps=eps).astype(np.float32, copy=False)
        a.sigma_p_inv = safe_inv(a.sigma_p_field.astype(np.float64), eps=eps).astype(np.float32, copy=False)

        a._preprocessed_step = step_tag


