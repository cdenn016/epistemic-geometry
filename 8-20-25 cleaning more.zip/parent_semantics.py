# -*- coding: utf-8 -*-
"""
Created on Fri Aug 15 16:38:18 2025

@author: chris and christine
"""

# parent_masks.py
from __future__ import annotations
from typing import List
# parent_semantics.py
import numpy as np
from typing import Dict, Iterable, Tuple






from parent_utils import _label4  # your toroidal CC



# Use your existing reconciler as the single implementation


def update_parent_masks(ctx, children: List[object], *, step: int, H: int, W: int) -> None:
    """
    Single entry point for parent mask updates. Always periodic.
    """
    reconcile_parent_masks_and_assignments(
        runtime_ctx=ctx,
        children=children,
        step=step,
        periodic=True,
        H=H,
        W=W,
    )





def update_parent_lifecycle(runtime_ctx, step: int) -> int:
    """
    Bookkeeping only:
      - newborn freeze window
      - orphan detection (no assigned kids + tiny active area)
      - mark for deletion via P._delete
    Returns the number of parents marked for deletion this call.
    """
    import numpy as np
    import config as CFG

    parents = getattr(runtime_ctx, "parents_by_region", {}) or {}
    if not parents:
        return 0

    # knobs (single-sourced; keep them few and obvious)
    active_thr_min     = float(getattr(CFG, "parent_active_level_min", 0.06))
    min_cc_px_base     = int(getattr(CFG, "parent_active_min_cc_px", 8))
    orphan_grace_steps = int(getattr(CFG, "parent_orphan_grace_steps", 10))
    freeze_steps       = int(getattr(CFG, "parent_freeze_steps", 2))

    deleted = 0
    for pid, P in list(parents.items()):
        # init lifecycle fields
        if not hasattr(P, "freeze_until"):
            P.freeze_until = int(step) + freeze_steps
        if not hasattr(P, "orphan_steps"):
            P.orphan_steps = 0
        if not hasattr(P, "assigned_child_ids") or P.assigned_child_ids is None:
            P.assigned_child_ids = set()

        # compute a simple "active" area from the current mask
        M = np.asarray(getattr(P, "mask", 0.0), np.float32)
        active_bool  = (M >= active_thr_min)
        active_area  = int(active_bool.sum())
        # scale min-cc with size (4% of area, clamped by base)
        min_cc_px    = max(min_cc_px_base, int(0.04 * max(1, active_area)))

        # orphan rule after newborn freeze
        if (int(step) > int(P.freeze_until)) and (len(P.assigned_child_ids) == 0) and (active_area < min_cc_px):
            P.orphan_steps += 1
        else:
            P.orphan_steps = 0

        if P.orphan_steps >= orphan_grace_steps:
            setattr(P, "_delete", True)
            deleted += 1

    return deleted







# Use your existing toroidal CC impl
from parent_utils import cc_label  # returns (labels, n)  :contentReference[oaicite:0]{index=0}

def _largest_cc(mask_bool: np.ndarray, *, periodic: bool) -> np.ndarray:
    """Pick largest connected component (toroidal if periodic=True)."""
    labels, n = cc_label(mask_bool, periodic=bool(periodic))  # :contentReference[oaicite:1]{index=1}
    if n <= 1:
        return np.asarray(mask_bool, bool)
    best = 0
    best_area = -1
    for k in range(1, n + 1):
        area = int((labels == k).sum())
        if area > best_area:
            best_area = area; best = k
    return (labels == best)

def reconcile_parent_masks_and_assignments(runtime_ctx, children, step: int, *, periodic: bool, H: int, W: int) -> None:
    """
    Enforce: (1) per-step child assignment by IoU with hysteresis,
             (2) seed vs active masks (freeze),
             (3) coalition-aware growth (strong->weak),
             (4) continuity-first CC under PBC,
             (5) soft-mask dynamics with step cap,
             (6) hard gate to prevent global 'glow' outside multi-child support.
    Mutates parent objects in runtime_ctx.parents_by_region in place.
    """
    import config as CFG

    parents: Dict[int, object] = getattr(runtime_ctx, "parents_by_region", {}) or {}
    if not parents:
        return

    # ------------------ knobs ------------------
    active_thr_cfg     = getattr(CFG, "parent_active_level", None)  # None => auto
    active_thr_q       = float(getattr(CFG, "parent_active_level_q", 60.0))
    active_thr_rel     = float(getattr(CFG, "parent_active_level_rel", 0.60))
    active_thr_min     = float(getattr(CFG, "parent_active_level_min", 0.06))

    # Make KEEP easier than ADD to prevent churning
    add_iou_thr        = float(getattr(CFG, "parent_assign_iou_add_thr", 0.15))
    keep_iou_thr       = float(getattr(CFG, "parent_assign_iou_keep_thr", 0.05))
    # safety: if someone sets weird config, enforce keep <= 0.75*add
    keep_iou_thr       = min(keep_iou_thr, 0.75 * add_iou_thr)
    min_overlap_px     = int(getattr(CFG, "parent_assign_min_overlap_px", 8))
    orphan_grace_steps = int(getattr(CFG, "parent_orphan_grace_steps", 10))
    freeze_steps       = int(getattr(CFG, "parent_freeze_steps", 3))
    seed_erode_iters   = int(getattr(CFG, "parent_seed_erode_iters", 1))
    min_cc_px_base     = int(getattr(CFG, "parent_active_min_cc_px", 8))
    active_iou_min     = float(getattr(CFG, "parent_active_iou_min", 0.30))
    hysteresis_keep_fr = float(getattr(CFG, "parent_hysteresis_keep_frac", 0.75))

    # Soft-mask dynamics
    eta_up    = float(getattr(CFG, "parent_eta_up", 0.25))
    eta_down  = float(getattr(CFG, "parent_eta_down", 0.20))
    sigma     = float(getattr(CFG, "parent_feather_sigma", 1.0))
    delta_cap = float(getattr(CFG, "parent_delta_cap", 0.20))

    # Coalition growth (agreement + cover>=N)
    cover_N   = int(getattr(CFG, "coalition_cover_n", 2))
    coal_hi   = float(getattr(CFG, "coalition_high_tau", 0.18))
    coal_lo   = float(getattr(CFG, "coalition_low_tau", 0.06))
    agree_map = getattr(runtime_ctx, "Ap_agg" if bool(getattr(CFG, "model_only", False)) else "Aq_agg", None)

    # Anti-glow: stricter child tau for *assigned* union + ≥2 cover
    child_tau_coal = float(getattr(CFG, "parent_coalition_tau", getattr(CFG, "support_tau", 0.01)))
    child_tau_coal = max(child_tau_coal, 0.08)  # tighten to avoid global glow

    # ------------------ helpers ------------------
    def _to_bool(m, thr): return (np.asarray(m, np.float32) >= float(thr))
    def _iou(a, b):
        a = np.asarray(a, bool); b = np.asarray(b, bool)
        inter = int((a & b).sum()); union = int(a.sum() + b.sum() - inter)
        return inter / max(1, union)

    def _erode4(mask, iters=1, periodic=False):
        m = np.asarray(mask, bool)
        for _ in range(max(0, int(iters))):
            nbr = (np.roll(m,1,0) & np.roll(m,-1,0) & np.roll(m,1,1) & np.roll(m,-1,1))
            if not periodic:
                nbr[0,:]=False; nbr[-1,:]=False; nbr[:,0]=False; nbr[:,-1]=False
            m = m & nbr
        return m

    # grow strong -> weak with 8-neigh
    def _grow8(weak, strong):
        weak   = np.asarray(weak, bool)
        strong = np.asarray(strong, bool)
        act = strong.copy()
        while True:
            nbr = (np.roll(act,1,0)|np.roll(act,-1,0)|np.roll(act,1,1)|np.roll(act,-1,1)|
                   np.roll(np.roll(act,1,0),1,1)|np.roll(np.roll(act,1,0),-1,1)|
                   np.roll(np.roll(act,-1,0),1,1)|np.roll(np.roll(act,-1,0),-1,1))
            add = weak & (~act) & nbr
            if not add.any(): break
            act |= add
        return act

    def _union_of_children(children, cids, H, W, thr):
        u = np.zeros((H, W), bool)
        for c in children:
            cid = int(getattr(c, "id", -1))
            if cid in cids:
                u |= _to_bool(c.mask, thr)
        return u  # :contentReference[oaicite:2]{index=2}

    # precompute child bool masks @active_thr_min for fast IoUs
    # precompute *interior* child masks for robust IoUs (reduce edge flipping)
    child_ids = [int(getattr(c, "id", i)) for i, c in enumerate(children)]
    child_bool_cache = {}
    for i, cid in enumerate(child_ids):
        cm = _to_bool(children[i].mask, active_thr_min)
        cm = _erode4(cm, iters=int(getattr(CFG, "assign_child_erode_iters", 1)), periodic=periodic)
        child_bool_cache[cid] = cm

    # coalition cover count (>=N kids) using permissive tau (for strong/weak growth)
    child_tau = float(getattr(CFG, "support_tau", 0.01))
    try:
        M_stack = np.stack([(np.asarray(c.mask, np.float32) >= child_tau).astype(np.uint8) for c in children], axis=0)
        cover_count = M_stack.sum(axis=0)
    except Exception:
        cover_count = None

    for pid, P in list(parents.items()):
        # -------- init persistent fields --------
        if not hasattr(P, "active_mask"):
            P.active_mask = _to_bool(P.mask, active_thr_min)
        else:
            P.active_mask = _to_bool(P.active_mask, active_thr_min)

        if not hasattr(P, "seed_mask") or P.seed_mask is None or not np.any(P.seed_mask):
            seed0 = _erode4(P.active_mask, seed_erode_iters, periodic=periodic)
            if not seed0.any():
                seed0 = P.active_mask.copy()
            P.seed_mask = seed0.astype(np.float32)

        if not hasattr(P, "assigned_child_ids") or P.assigned_child_ids is None:
            P.assigned_child_ids = set()

        if not hasattr(P, "freeze_until"):
            P.freeze_until = int(step) + freeze_steps

        if not hasattr(P, "orphan_steps"):
            P.orphan_steps = 0

        # -------- adaptive active threshold & min-cc --------
        if active_thr_cfg is None:
            vals = np.asarray(P.mask, np.float32)
            vals = vals[vals > 1e-6]
            if vals.size:
                q = float(np.percentile(vals, active_thr_q))
                raw_thr = max(active_thr_min, active_thr_rel * q)
            else:
                raw_thr = active_thr_min
        else:
            raw_thr = float(active_thr_cfg)
        # low-pass the threshold per-parent to avoid jitter
        beta_thr = float(getattr(CFG, "parent_active_thr_beta", 0.30))
        prev_thr = float(getattr(P, "_active_thr_prev", raw_thr))
        active_thr = (1.0 - beta_thr) * prev_thr + beta_thr * raw_thr
        P._active_thr_prev = float(active_thr)
        
        
        active_bool  = _to_bool(P.mask, active_thr)
        active_area  = int(active_bool.sum())
        min_cc_px    = max(min_cc_px_base, int(0.04 * max(1, active_area)))  # 4% of area

        # -------- assignment with hysteresis --------
        new_assign = set()
        for cid in child_ids:
            cm = child_bool_cache[cid]
            if not cm.any(): continue
            inter = int((active_bool & cm).sum())
            if inter < min_overlap_px: continue
            if _iou(active_bool, cm) >= add_iou_thr:
                new_assign.add(cid)

        kept = set()
        for cid in list(P.assigned_child_ids):
            cm = child_bool_cache.get(cid)
            if cm is None or not cm.any(): continue
            inter = int((active_bool & cm).sum())
            if inter >= min_overlap_px and _iou(active_bool, cm) >= keep_iou_thr:
                kept.add(cid)

        P.assigned_child_ids = kept | new_assign

        # --- Bootstrap assignments while frozen if empty ---
        if (len(P.assigned_child_ids) == 0) and (step <= int(P.freeze_until)):
            from parent_utils import conservative_child_set_from_seed  # :contentReference[oaicite:1]{index=1}
            seed_bool = (np.asarray(P.seed_mask, np.float32) >= 0.5)
            boot = conservative_child_set_from_seed(children, seed_bool,
                                                    mask_tau=active_thr_min,
                                                    min_overlap_px=min_overlap_px)  # same knobs you use above
            P.assigned_child_ids = set(int(x) for x in boot) or set()


        # -------- orphan detection --------
        if (len(P.assigned_child_ids) == 0) and (active_area < min_cc_px) and (int(step) > int(P.freeze_until)):
            P.orphan_steps += 1
        else:
            P.orphan_steps = 0
        if P.orphan_steps >= orphan_grace_steps:
            setattr(P, "_delete", True)
            continue

        # -------- coalition hysteresis (strong->weak) --------
        coalition = None
        if isinstance(agree_map, np.ndarray) and (cover_count is not None):
            strong = (cover_count >= cover_N) & (agree_map >= coal_hi)
            weak   = (cover_count >= cover_N) & (agree_map >= coal_lo)
            if weak.any() or strong.any():
                coalition = _grow8(weak, strong)

        # -------- choose target CC (continuity-first) --------
        if len(P.assigned_child_ids) > 0:
            union_assigned = _union_of_children(children, P.assigned_child_ids, H, W, active_thr_min)  # :contentReference[oaicite:3]{index=3}
            labels, nlab = cc_label(active_bool, periodic=bool(periodic))  # :contentReference[oaicite:4]{index=4}
            if nlab > 1:
                # prefer CC that overlaps union_assigned AND previous/seed (continuity)
                prev_anchor = active_bool | _to_bool(P.seed_mask, 0.5)
                best_lbl, best_score = 0, (-1, -1, -1)
                for lbl in range(1, nlab + 1):
                    comp = (labels == lbl)
                    if comp.sum() < min_cc_px: continue
                    ov_u = int((comp & union_assigned).sum())
                    ov_p = int((comp & prev_anchor).sum())
                    score = (ov_u, ov_p, int(comp.sum()))
                    if score > best_score: best_score, best_lbl = score, lbl

                # --- CC stickiness: only switch if clearly better and persistent ---
                margin_u = int(getattr(CFG, "cc_switch_margin_u", 3))   # require +3 px overlap with union
                persist  = int(getattr(CFG, "cc_switch_persist", 2))    # win for 2 consecutive steps
                last_lbl = int(getattr(P, "_last_cc_lbl", 0))
                last_score = tuple(getattr(P, "_last_cc_score", (-1,-1,-1)))
                if last_lbl in range(1, nlab + 1):
                    comp_last = (labels == last_lbl)
                    ov_u_last = int((comp_last & union_assigned).sum())
                    # if not a clear win on union overlap, stick to last
                    if (best_score[0] < ov_u_last + margin_u):
                        best_lbl, best_score = last_lbl, (ov_u_last,
                                                          int((comp_last & prev_anchor).sum()),
                                                          int(comp_last.sum()))
                        P._cc_hold = 0
                    else:
                        P._cc_hold = int(getattr(P, "_cc_hold", 0)) + 1
                        if P._cc_hold < persist:
                            # not persistent yet → stick
                            best_lbl, best_score = last_lbl, (ov_u_last,
                                                              int((comp_last & prev_anchor).sum()),
                                                              int(comp_last.sum()))
                        else:
                            P._cc_hold = 0
                P._last_cc_lbl = int(best_lbl)
                P._last_cc_score = tuple(best_score)

                target_bool = (labels == best_lbl) if best_lbl != 0 else _largest_cc(active_bool, periodic=periodic)
            else:
                target_bool = active_bool

            # Active↔assigned IoU gate with smart restore
            iou_u = _iou(target_bool, union_assigned)
            if iou_u < active_iou_min:
                prev = target_bool.copy()
                target_bool = target_bool & union_assigned
                dropped = prev & (~target_bool)
                if dropped.any():
                    restore_cap = int(np.ceil((1.0 - hysteresis_keep_fr) * dropped.sum()))
                    if restore_cap > 0:
                        M_prev = np.asarray(P.mask, np.float32)
                        yy, xx = np.where(dropped)
                        vals = M_prev[yy, xx]
                        idx_sorted = np.argsort(-vals)[:restore_cap]
                        rr = np.zeros_like(prev, dtype=bool)
                        rr[yy[idx_sorted], xx[idx_sorted]] = True
                        target_bool |= rr
        else:
            target_bool = _largest_cc(active_bool, periodic=periodic) if active_area >= min_cc_px else active_bool

        # merge coalition CC that touches current/seed (natural growth)
        if isinstance(coalition, np.ndarray) and coalition.any():
            anchor = target_bool | _to_bool(P.seed_mask, 0.5)
            lab, ncoal = cc_label(coalition, periodic=bool(periodic))  # :contentReference[oaicite:5]{index=5}
            best, score = 0, -1
            for lbl in range(1, ncoal + 1):
                comp = (lab == lbl)
                s = int((comp & anchor).sum())
                if s > score:
                    score = s; best = lbl
            if best > 0:
                target_bool |= (lab == best)

        # -------- freeze seed protection --------
        if step <= int(P.freeze_until):
            target_bool |= _to_bool(P.seed_mask, 0.5)

        # -------- soft update --------
        target_float = target_bool.astype(np.float32)
        if sigma > 0.0:
            try:
                from scipy.ndimage import gaussian_filter as _gf
                                # slightly smaller sigma to reduce "breathing"
                target_float = _gf(target_float, sigma=float(getattr(CFG, "parent_feather_sigma", 0.8)),
                                   mode="wrap" if periodic else "nearest")
            except Exception:
                pass
        target_float = np.clip(target_float, 0.0, 1.0)

        M_prev = np.asarray(P.mask, np.float32)
        delta  = target_float - M_prev
        # make per-step change gentler (default a bit smaller)
        eta_up   = float(getattr(CFG, "parent_eta_up", 0.20))
        eta_down = float(getattr(CFG, "parent_eta_down", 0.15))
        eta      = np.where(delta > 0.0, eta_up, np.where(delta < 0.0, eta_down, 0.0)).astype(np.float32)
        raw    = M_prev + eta * delta
        d      = np.clip(raw - M_prev, -float(getattr(CFG,"parent_delta_cap",0.12)),
                                         float(getattr(CFG,"parent_delta_cap",0.12)))
        M_new  = np.clip(M_prev + d, 0.0, 1.0)

        # ---- Anti-glow hard gate (STRICT) ----
        # ---- Anti-glow hard gate ----
        if cover_count is not None:
            cover_ge2 = (cover_count >= 2)
        
            if len(P.assigned_child_ids) > 0:
                # strict mode: assigned-union ∩ ≥2-cover
                u_assigned_strict = _union_of_children(children, P.assigned_child_ids, H, W, child_tau_coal)  # :contentReference[oaicite:2]{index=2}
                hard_gate = (cover_ge2 & u_assigned_strict).astype(np.float32)
            else:
                # bootstrap mode (no assignments yet): allow only near the seed, still requiring ≥2-cover
                seed = (np.asarray(P.seed_mask, np.float32) >= 0.5)
                # 1–2 rings of 8-neigh growth around seed to make a small halo
                halo = seed.copy()
                for _ in range(2):
                    nbr = (np.roll(halo,1,0)|np.roll(halo,-1,0)|np.roll(halo,1,1)|np.roll(halo,-1,1)|
                           np.roll(np.roll(halo,1,0),1,1)|np.roll(np.roll(halo,1,0),-1,1)|
                           np.roll(np.roll(halo,-1,0),1,1)|np.roll(np.roll(halo,-1,0),-1,1))
                    halo |= nbr
                hard_gate = (cover_ge2 & halo).astype(np.float32)
        
            M_new = np.asarray(M_new, np.float32) * hard_gate
            M_new[M_new < 1e-5] = 0.0


        # minimal area safeguard during freeze
        if (M_new >= active_thr).sum() < min_cc_px and step <= int(P.freeze_until):
            M_new = np.maximum(M_new, np.asarray(P.seed_mask, np.float32))

        # commit only if meaningful change (reduces 1e-6 flicker)
        commit_eps = float(getattr(CFG, "parent_commit_eps", 1e-4))
        if float(np.max(np.abs(M_new - M_prev))) >= commit_eps:
            P.mask = M_new.astype(np.float32)
        else:
            P.mask = M_prev.astype(np.float32)
        P.active_mask = (P.mask >= active_thr)

