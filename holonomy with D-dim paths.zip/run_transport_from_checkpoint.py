import os
import pickle
import numpy as np
from datetime import datetime

from generalized_io_utils import load_checkpoint, load_final_step
from generalized_agent_schema import Agent
from find_agent_chains import find_candidate_paths
from transport_operator import transport_belief_over_chain
from get_generators import get_generators
import config

# --- MANUAL CONFIGURATION ---
checkpoint_path = "checkpoints"  # can also be "checkpoints/step_0050.pkl"
start_id = 0
end_id = 2
d = 1  # number of intermediate agents
fiber_key = "q"
phi_key = "phi"
start_coord = None  # override with tuple like (25, 25)
end_coord = None

# --- LOAD CHECKPOINT ---
if os.path.isdir(checkpoint_path):
    agents, _ = load_checkpoint(checkpoint_path)
    domain_size = config.domain_size
else:
    with open(checkpoint_path, "rb") as f:
        agents = pickle.load(f)
    domain_size = config.domain_size

# --- FIND PATH ---
path, c_start, c_end, overlap_points = find_candidate_paths(
    agents,
    start_id,
    end_id,
    d=d,
    domain_size=domain_size,
    support_cutoff_eps=config.support_cutoff_eps
)

if not path:
    print("[ERROR] No path found with given constraints.")
    exit()

print(f"[PATH] Agent chain found: {path}")
print(f"[POINTS] Overlap centroids: {overlap_points}")

fixed_start = tuple(start_coord) if start_coord else c_start
fixed_end = tuple(end_coord) if end_coord else c_end

# --- GET GENERATORS ---
generators = get_generators(config.group_name, config.K)

# --- PERFORM TRANSPORT ---
agents, diagnostics = transport_belief_over_chain(
    agents=agents,
    path=path,
    overlap_points=overlap_points,
    generators=generators,
    domain_size=domain_size,
    fiber_key=fiber_key,
    phi_key=phi_key,
    fixed_start=fixed_start,
    fixed_end=fixed_end,
    config=config
)

# --- SAVE OUTPUT ---
timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
outdir = "transport_log_latest"
os.makedirs(outdir, exist_ok=True)

# Save transport diagnostics
with open(os.path.join(outdir, "diagnostics.pkl"), "wb") as f:
    pickle.dump(diagnostics, f)

# Save each transported belief q_t along the path
q_seq = diagnostics.get("q_sequence", [])
if q_seq:
    print(f"[LOG] Saving {len(q_seq)} transported beliefs...")
    for t, q in enumerate(q_seq):
        step_path = os.path.join(outdir, f"q_step_{t:03d}.pkl")
        with open(step_path, "wb") as f:
            pickle.dump(q, f)
    print(f"[DONE] Saved q_step_XXX.pkl files to: {outdir}")
else:
    print("[WARNING] No q_sequence found to save.")

# Save path metadata
with open(os.path.join(outdir, "path.txt"), "w") as f:
    f.write("Path: " + str(path) + "\n")
    f.write("Start coord: " + str(fixed_start) + "\n")
    f.write("End coord: " + str(fixed_end) + "\n")
    f.write("Overlap points: " + str(overlap_points) + "\n")

print(f"[DONE] Transport complete. Output saved to: {outdir}")
