# lhs_sweeper.py

import os
import numpy as np
import pickle
from scipy.stats import qmc
from generalized_simulation import run_simulation
from config import set_config_from_params
import argparse
#import config as config_module

DEFAULT_SAMPLES = 100  # ← Default number of LHS samples

# --- Parameters required for proper simulation ---
base_params = {
    "group_name": "so3",
    "K": 21,
    "N": 3,
    "L": 25,
    "steps": 200,
}


def lhs_sample(param_ranges, n_samples):
    """Generate Latin Hypercube Samples for given parameter ranges."""
    sampler = qmc.LatinHypercube(d=len(param_ranges))
    sample = sampler.random(n=n_samples)
    l_bounds = np.array([lo for lo, hi in param_ranges])
    u_bounds = np.array([hi for lo, hi in param_ranges])
    scaled = qmc.scale(sample, l_bounds, u_bounds)
    return scaled


def run_lhs_sweep(n_samples=DEFAULT_SAMPLES, output_dir="lhs_results"):
    os.makedirs(output_dir, exist_ok=True)

    sweep_params = {
        "alpha": (0.0, 800.0),
        "beta": (0.0, 800.0),
        "gamma": (0.0, 800.0),
        "gauge_weight": (0.0, 800.0),
        "model_align_weight": (0.0, 800.0),
        "model_gauge_weight": (0, 800),
        "model_mass_weight": (0, 800),
        "model_feedback_weight": (0, 800.0),
        "phi_phi_tilde_coupling": (0, 800.0),
        "phi_init": (0.05,1),
        # "curvature_weight": (0.0, 2.0),
        # "phi_damping": (0.0, 1.0),
    }

    param_names = list(sweep_params.keys())
    ranges = [sweep_params[k] for k in param_names]
    samples = lhs_sample(ranges, n_samples)

    sweep_spec = {
        "param_names": param_names,
        "ranges": sweep_params,
        "samples": samples.tolist()
    }
    with open(os.path.join(output_dir, "sweep_spec.pkl"), "wb") as f:
        pickle.dump(sweep_spec, f)

    for i, row in enumerate(samples):
        sampled_params = dict(zip(param_names, row))
        param_dict = {**base_params, **sampled_params}  # Merge base + sweep
        print(f"\n[SAMPLE {i}] {param_dict}")

        subdir = os.path.join(output_dir, f"run_{i}")
        os.makedirs(subdir, exist_ok=True)

        agents, metrics = run_simulation(
            outdir=subdir,
            resume=False,
            log_metrics=True,
            num_cores=4,
            params=param_dict
        )

        with open(os.path.join(subdir, "final_agents.pkl"), "wb") as f:
            pickle.dump(agents, f)

        with open(os.path.join(subdir, "final_metrics.pkl"), "wb") as f:
            pickle.dump(metrics, f)

        with open(os.path.join(subdir, "params.pkl"), "wb") as f:
            pickle.dump(param_dict, f)

        print(f"[DONE] LHS sweep complete: {n_samples} samples → {output_dir}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Run Latin Hypercube parameter sweep.")
    parser.add_argument("--n", "--n_samples", type=int, default=DEFAULT_SAMPLES,
                        help="Number of LHS samples (default = 2)")
    args = parser.parse_args()
    run_lhs_sweep(n_samples=args.n)
