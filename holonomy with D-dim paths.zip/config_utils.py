
import config

def set_config_from_params(params):
    """Safely override known config attributes from a dictionary."""
    valid_keys = {
        k for k in dir(config)
        if not k.startswith("__") and not callable(getattr(config, k))
    }

    for k, v in params.items():
        if k in valid_keys:
            setattr(config, k, v)
        else:
            print(f"[WARNING] Ignored unknown config key: '{k}'")

    # Optional: warn about keys in config not set by params
    unused = valid_keys - params.keys()
    for k in sorted(unused):
        print(f"[NOTICE] Config key '{k}' not set by params — using default or previous value.")
