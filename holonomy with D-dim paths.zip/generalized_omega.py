import numpy as np
from config import K, phi_clip_threshold, beta, phi_clip_threshold, log_eps
from scipy.ndimage import sobel
from scipy.linalg import expm
import config
from get_generators import get_generators


def repair_if_forgotten(q: np.ndarray, eps: float, threshold: float = 1e-6) -> np.ndarray:
    """
    If a belief vector q has near-zero total mass, inject small uniform mass
    so that belief learning can resume.

    Parameters:
        q         : (K,) belief vector
        eps       : small clipping constant
        threshold : total mass threshold to trigger repair

    Returns:
        q_repaired : repaired or original belief vector
    """
    total_mass = np.sum(q)
    if total_mass < threshold or not np.isfinite(total_mass):
        K = q.shape[-1]
        q = np.random.dirichlet(np.ones(K)) * eps * K
    else:
        q = np.clip(q, eps, 1.0)
        q /= np.sum(q) + eps
    return q


def repair_if_forgotten_batch(q: np.ndarray, eps: float, threshold: float = 1e-6) -> np.ndarray:
    """
    Repair a batch of belief vectors where some may have near-zero total mass.

    Parameters:
        q         : (..., K) array of belief vectors
        eps       : small floor value (e.g., config.log_eps)
        threshold : total mass below which a vector is considered "forgotten"

    Returns:
        q_repaired : repaired batch, same shape as q
    """
    q = np.nan_to_num(q, nan=0.0, posinf=0.0, neginf=0.0)
    orig_shape = q.shape
    K = q.shape[-1]
    q_flat = q.reshape(-1, K)
    norms = np.sum(q_flat, axis=-1, keepdims=True)

    forgotten = (norms < threshold) | (~np.isfinite(norms))

    if np.any(forgotten):
        n_forgotten = np.sum(forgotten)
        repaired = np.random.dirichlet(np.ones(K), size=n_forgotten) * eps * K
        q_flat[forgotten.squeeze()] = repaired

    q_flat = np.clip(q_flat, eps, 1.0)
    q_flat /= np.sum(q_flat, axis=-1, keepdims=True) + eps
    return q_flat.reshape(orig_shape)

def kl_divergence(q1, q2, eps=1e-12):
    q1 = np.clip(q1, eps, 1.0)
    q2 = np.clip(q2, eps, 1.0)
    return np.sum(q1 * (np.log(q1) - np.log(q2)), axis=-1)

def adaptive_expm(G, clip_norm=None):
    """
    Safe exponentiation of a Lie algebra matrix G.
    
    Parameters:
    - G: (K,K) numpy array
    - clip_norm: float or None. If set, scales G down if ‖G‖ > clip_norm.

    Returns:
    - expm(G) or expm(scaled G)
    """
    norm_G = np.linalg.norm(G)
    if clip_norm is not None and norm_G > clip_norm:
        G = G * (clip_norm / norm_G)
    return expm(G)


def exp_lie_algebra_operator(
    v,
    generators,
    use_expm=True,
    threshold=1e-3,
    max_norm=20,
    group_name=None,  # 'so3', 'sl2r', 'su2', etc.
):
    """
    Compute exp(Σ_a v_a T_a) for arbitrary Lie algebra representation.

    Parameters:
    - v: np.ndarray shape (dim_G,), Lie algebra coefficients
    - generators: np.ndarray shape (dim_G, K, K), generators for Lie algebra rep
    - use_expm: bool, use scipy expm for large norms
    - threshold: float, norm threshold below which to use Taylor approx
    - max_norm: float, max allowed norm to prevent blowup
    - group_name: str or None, optionally specify to apply group-specific handling

    Returns:
    - np.ndarray (K, K): the group element exp(Σ vᵃ Tₐ)
    """
    norm_v = np.linalg.norm(v)
    eps = 1e-16
    safe_norm = norm_v + eps

    scale = min(1.0, max_norm / safe_norm)
    v_scaled = v * scale

    G = np.einsum('a,aij->ij', v_scaled, generators)

    # === SO(3)-specific antisymmetrization for numerical stability ===
    if group_name == "so3":
        G = 0.5 * (G - G.T)

    if safe_norm < threshold or not use_expm:
        I = np.eye(G.shape[0], dtype=G.dtype)
        return I + G + 0.5 * (G @ G)
    else:
        return expm(G)

def exp_lie_algebra_irrep(
    v,
    generators,
    use_expm=True,
    threshold=1e-3,
    max_norm=20,
    group_name=None  # e.g., "so3", "sl2r", "su2", etc.
):
    """
    Compute exp(Σ v_a T_a) in specified representation.
    
    Parameters:
    - v: (..., dim_G) array of Lie algebra coefficients
    - generators: (dim_G, K, K)
    - use_expm: whether to use scipy.linalg.expm or truncated Taylor
    - threshold: use Taylor approx for small norm
    - max_norm: clamp norm before exponentiating
    - group_name: optionally specify Lie group for extra stabilization

    Returns:
    - (..., K, K) array of exponentiated matrices
    """
    import numpy as np
    from scipy.linalg import expm

    norm_v = np.linalg.norm(v, axis=-1)               # shape (...,)
    eps = 1e-16
    safe = norm_v[..., None] + eps                    # avoids div-by-zero

    # scale if norm too large
    scale = np.where(norm_v[..., None] > max_norm, max_norm / safe, 1.0)
    v_scaled = v * scale

    # contract Lie algebra element
    G = np.einsum('...a,aij->...ij', v_scaled, generators)

    # --- group-specific cleanup ---
    if group_name == "so3":
        G = 0.5 * (G - np.swapaxes(G, -1, -2))  # antisymmetrize
    elif group_name == "su2":
        G = 0.5 * (G - np.swapaxes(G, -1, -2).conj())  # anti-Hermitian
    # no-op for sl2r: allow general real matrices

    # --- main loop ---
    result = np.empty_like(G)
    approx_mask = norm_v < threshold

    if np.any(approx_mask):
        I = np.eye(G.shape[-1], dtype=G.dtype)
        G_approx = G[approx_mask]
        G2 = G_approx @ G_approx
        result[approx_mask] = I + G_approx + 0.5 * G2

    if np.any(~approx_mask):
        idxs = np.nonzero(~approx_mask)[0]
        for i in idxs:
            result[i] = expm(G[i])

    return result

def batch_exp_lie_algebra_irrep(
    v_batch,
    generators,
    use_expm=True,
    threshold=1e-3,
    max_norm=20,
    group_name=None,  # Optional: for future group-specific handling
):
    """
    Compute batch of exp(sum_a v_batch[a] * T_a) where T_a are Lie algebra generators
    in a K-dimensional representation.

    Parameters:
    - v_batch: (..., dim_G), batch of Lie algebra coefficients
    - generators: (dim_G, K, K)
    - use_expm: whether to use adaptive_expm for large norms
    - threshold: Taylor cutoff for small norms
    - max_norm: scale down inputs above this norm
    - group_name: optional, for future group-specific branching

    Returns:
    - (..., K, K): batch of exponentiated group elements
    """
    *batch_shape, dim_G = v_batch.shape
    v_flat = v_batch.reshape(-1, dim_G)
    N = v_flat.shape[0]
    _, K, _ = generators.shape
    dtype = v_batch.dtype

    # --- Compute norms and scale vectors ---
    norms = np.linalg.norm(v_flat, axis=1)
    eps = 1e-16
    scale_factors = np.minimum(1.0, max_norm / (norms + eps))
    v_scaled = v_flat * scale_factors[:, None]

    # --- Build algebra elements ---
    G_batch = np.einsum("na,aij->nij", v_scaled, generators)

    # --- Taylor approx for small-norm G ---
    norms_scaled = norms * scale_factors
    result = np.empty((N, K, K), dtype=dtype)

    approx_mask = norms_scaled < threshold
    if np.any(approx_mask):
        G_approx = G_batch[approx_mask]
        I_batch = np.eye(K, dtype=dtype)[None, :, :]
        G2 = G_approx @ G_approx
        result[approx_mask] = I_batch + G_approx + 0.5 * G2

    # --- Adaptive expm for large-norm G ---
    if np.any(~approx_mask):
        for idx in np.flatnonzero(~approx_mask):
            result[idx] = adaptive_expm(G_batch[idx], max_norm=max_norm)

    return result.reshape(*batch_shape, K, K)


def batch_apply_omega(q_batch, omega_batch):
    """
    Apply a batch of group elements Ω to a batch of belief vectors q.

    Args:
        q_batch: np.ndarray with shape (..., K)
        omega_batch: np.ndarray with shape (..., K, K), must broadcast with q_batch

    Returns:
        Transformed batch: np.ndarray with shape (..., K)
    """
    # Validate batch dimensions match except for last dims
    assert q_batch.shape[-1] == omega_batch.shape[-2] == omega_batch.shape[-1], (
        f"Dimension mismatch: q_batch last dim {q_batch.shape[-1]} != "
        f"omega_batch last dims {omega_batch.shape[-2:]}"
    )

    # Use einsum to contract last dim of q_batch with last dim of omega_batch
    return np.einsum('...ij,...j->...i', omega_batch, q_batch)


def apply_omega(q_vec, omega):
    """
    Apply a single group matrix Ω to a belief vector or batch of vectors q_vec.

    Args:
        q_vec: np.ndarray with shape (K,) or (..., K)
        omega: np.ndarray with shape (K, K)

    Returns:
        Transformed vector(s) with shape same as q_vec
    """
    assert omega.shape[0] == omega.shape[1], "Omega must be square"
    assert q_vec.shape[-1] == omega.shape[0], (
        f"Dimension mismatch: q_vec last dim {q_vec.shape[-1]} != omega shape {omega.shape}"
    )

    # Contract last dim of q_vec with omega
    return np.einsum('ij,...j->...i', omega, q_vec)


def compute_gauge_potential(phi):
    """
    Compute gauge potentials A_μ^a = ∂_μ φ^a for arbitrary Lie algebra and base dimension D.
        BE CAREFUL! CANNOT PASS THIS OUTPUT INTO COMMUTATOR WITHOUT CONVERTING
    Args:
        phi: np.ndarray, shape (..., d), where
             ... represents spatial dimensions (S_1,...,S_D),
             d = dim Lie algebra.

    Returns:
        A: tuple of length D, each entry np.ndarray of shape (..., d),
           spatial derivatives of phi along each base manifold dimension.
    """
    D = phi.ndim - 1  # subtract Lie algebra dimension axis
    spatial_axes = tuple(range(D))
    A = tuple(np.gradient(phi, axis=axis) for axis in spatial_axes)
    return A


def compute_commutator(A_mu, A_nu):
    """
    Compute matrix commutator [A_μ, A_ν] = A_μ A_ν - A_ν A_μ for batch matrices.

    Args:
        A_mu, A_nu: np.ndarray with shape (..., K, K)

    Returns:
        commutator: np.ndarray with shape (..., K, K)
    """
    return np.matmul(A_mu, A_nu) - np.matmul(A_nu, A_mu)


def compute_field_strength(phi, generators):
    """
    Compute curvature tensors F_{μν} = ∂_μ A_ν - ∂_ν A_μ + [A_μ, A_ν]
    for all μ < ν, where φ is the gauge field and generators specify
    the Lie algebra representation.

    Args:
        phi: np.ndarray of shape (S_1,...,S_D, d), gauge field components
        generators: np.ndarray of shape (d, K, K), Lie algebra generators

    Returns:
        curvature_norms: dict mapping (mu, nu) -> np.ndarray of shape (S_1,...,S_D)
                         scalar Frobenius norm of curvature tensor F_{μν}
    """
    D = phi.ndim - 1
    A = compute_gauge_potential(phi)  # tuple length D, each (..., d)

    # Project each A_μ from (..., d) to (..., K, K)
    A_matrices = [np.einsum('...a,aij->...ij', A_mu, generators) for A_mu in A]

    curvature_norms = {}

    for mu in range(D):
        for nu in range(mu + 1, D):
            # Partial derivatives of A_nu and A_mu along directions mu and nu
            dA_nu_dmu = np.gradient(A_matrices[nu], axis=mu)
            dA_mu_dnu = np.gradient(A_matrices[mu], axis=nu)

            # Commutator [A_mu, A_nu]
            comm = compute_commutator(A_matrices[mu], A_matrices[nu])

            F_munu = dA_nu_dmu - dA_mu_dnu + comm

            # Optional numerical clipping and NaN/Inf checks
            F_munu = np.clip(F_munu, -1e6, 1e6)
            if np.any(np.isnan(F_munu)) or np.any(np.isinf(F_munu)):
                print(f"[WARNING] Curvature tensor F_{{{mu},{nu}}} contains NaN or Inf.")

            # Frobenius norm over last two dims (K x K matrix)
            curvature_norms[(mu, nu)] = np.linalg.norm(F_munu, axis=(-2, -1))

    return curvature_norms

def build_inter_agent_omega(phi_i, phi_j, generators, config=None, use_commutator=False):
    """
    Compute the inter-agent gauge transport operator field Ω_{ij}(x) for full φ fields.

    Parameters:
        phi_i: np.ndarray shape (..., d) — φ_i field over spatial domain
        phi_j: np.ndarray shape (..., d) — φ_j field over spatial domain
        generators: np.ndarray shape (d, K, K) — Lie algebra generators
        config: optional config object to override use_commutator
        use_commutator: bool — if True, use exp(φ_i - φ_j); else use exp(φ_i) @ exp(-φ_j)

    Returns:
        omega_ij: np.ndarray shape (..., K, K) — inter-agent transport operator at each point
    """
    # override via config flag if set
    if config is not None:
        use_commutator = getattr(config, "use_commutator", use_commutator)

    # coefficient difference field, shape (..., d)
    delta = phi_i - phi_j

    if use_commutator:
        # exponentiate the difference directly
        return exp_lie_algebra_irrep(delta, generators)  # (..., K, K)

    # otherwise exponentiate each field separately and multiply
    g_i     = exp_lie_algebra_irrep(phi_i, generators)       # (..., K, K)
    g_j_inv = exp_lie_algebra_irrep(-phi_j, generators)      # (..., K, K)
    # broadcasted matmul over leading dims
    return np.matmul(g_i, g_j_inv)                           # (..., K, K)
