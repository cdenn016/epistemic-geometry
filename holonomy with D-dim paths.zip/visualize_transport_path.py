import os
import pickle
import numpy as np
import matplotlib.pyplot as plt
import imageio
import config




# visualize_transport_path.py
def plot_transport_path_overlay(agents, path, overlap_points, domain_size, savepath=None):
    import matplotlib.pyplot as plt
    import numpy as np

    fig, ax = plt.subplots(figsize=(6, 6))
    ax.set_xlim(0, domain_size[0])
    ax.set_ylim(0, domain_size[1])
    ax.set_aspect('equal')

    # Plot all agents (faded)
    for i, agent in enumerate(agents):
        x, y = agent.center
        ax.plot(x, y, 'o', color='lightgray')
        circle = plt.Circle((x, y), radius=agent.radius, fill=False, color='lightgray', linestyle='--')
        ax.add_patch(circle)

    # Highlight agents in path
    for i in path:
        x, y = agents[i].center
        ax.plot(x, y, 'o', color='blue')
        circle = plt.Circle((x, y), radius=agents[i].radius, fill=False, color='blue', linewidth=2)
        ax.add_patch(circle)

    # Connect path with arrows
    for i in range(len(path) - 1):
        x0, y0 = agents[path[i]].center
        x1, y1 = agents[path[i + 1]].center
        ax.annotate("",
                    xy=(x1, y1), xycoords='data',
                    xytext=(x0, y0), textcoords='data',
                    arrowprops=dict(arrowstyle="->", color='black'))

    # Overlap points
    for c in overlap_points:
        ax.plot(c[0], c[1], 'rx', markersize=8, label="Overlap")

    # Start/end labels
    start = path[0]
    end = path[-1]
    ax.text(*agents[start].center, "START", color="green", ha="right", fontsize=10)
    ax.text(*agents[end].center, "END", color="red", ha="left", fontsize=10)

    ax.set_title("Transport Path and Overlapping Agents")
    ax.grid(True)
    if savepath:
        fig.savefig(savepath)
    else:
        plt.show()
    plt.close(fig)



def animate_spatial_transport(logdir, savepath="transport_spatial.gif", K_plot=0):
    """
    Animate belief transport over space for a single fiber index (K_plot).
    Only plots belief mass at each step’s coordinate.
    """
    with open(os.path.join(logdir, "diagnostics.pkl"), "rb") as f:
        diag = pickle.load(f)

    path_coords = diag["path_coords"]
    q_sequence = diag["q_sequence"]
    domain_size = config.domain_size

    frames = []
    temp_files = []

    vmax = max(q[K_plot] for q in q_sequence)

    for t, (coord, q_vec) in enumerate(zip(path_coords, q_sequence)):
        field = np.zeros(domain_size)
        field[coord] = q_vec[K_plot]

        fig, ax = plt.subplots(figsize=(6, 5))
        im = ax.imshow(field.T, origin="lower", cmap="plasma", vmin=0, vmax=vmax)
        ax.set_title(f"Step {t+1} — Fiber Index {K_plot}")
        fig.colorbar(im, ax=ax, label="q[k]")
        frame_path = f"_frame_{t:03d}.png"
        fig.savefig(frame_path)
        temp_files.append(frame_path)
        plt.close(fig)
        frames.append(imageio.imread(frame_path))

    gif_path = os.path.join(logdir, savepath)
    imageio.mimsave(gif_path, frames, fps=4)
    print(f"[DONE] Spatial animation saved to: {gif_path}")

    for f in temp_files:
        os.remove(f)


def plot_visited_beliefs(logdir, K_plot=0, savepath="transport_path_overlay.png"):
    """
    Static overlay plot of transported belief vector (q_sequence) across space.
    """
    with open(os.path.join(logdir, "diagnostics.pkl"), "rb") as f:
        diag = pickle.load(f)

    path_coords = diag["path_coords"]
    q_sequence = diag["q_sequence"]
    domain_size = config.domain_size

    field = np.zeros(domain_size)
    for coord, q in zip(path_coords, q_sequence):
        field[coord] = q[K_plot]

    fig, ax = plt.subplots(figsize=(6, 5))
    im = ax.imshow(field.T, origin="lower", cmap="plasma", vmin=0, vmax=np.max(field))
    ax.set_title(f"Visited Belief Mass — Fiber Index {K_plot}")
    fig.colorbar(im, ax=ax, label="q[k]")
    fig.tight_layout()
    save_full = os.path.join(logdir, savepath)
    fig.savefig(save_full)
    plt.show()
    print(f"[DONE] Static field saved to: {save_full}")

if __name__ == "__main__":
    logdir = "transport_log_latest"
    fiber_index = 0  # Change this to plot a different q[k]

    # Animate transport of q[k] over space
    animate_spatial_transport(logdir, savepath="transport_spatial.gif", K_plot=fiber_index)

    # Plot static overlay of visited q[k] values
    plot_visited_beliefs(logdir, K_plot=fiber_index, savepath="transport_path_overlay.png")
