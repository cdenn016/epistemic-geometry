#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Jun 18 16:38:43 2025

@author: chris and christine
"""

import argparse
import os
import glob
import pickle
import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from config import domain_size, support_cutoff_eps, checkpoint_dir


def load_diagnostics(path):
    """Load a diagnostics pickle containing path_coords and metadata."""
    with open(path, 'rb') as f:
        return pickle.load(f)


def check_continuity(coords, tol=None):
    """
    Check that consecutive points in coords differ by at most tol (Euclidean norm).
    If tol is None, use sqrt(D), where D is dimension of coords.
    Returns max jump and indices where jump > tol.
    """
    arr = np.array(coords, dtype=float)
    diffs = np.diff(arr, axis=0)
    dists = np.linalg.norm(diffs, axis=1)
    D = arr.shape[1]
    if tol is None:
        tol = np.sqrt(D)
    violations = np.where(dists > tol)[0].tolist()
    return float(dists.max()), violations


def expand_grid_path(corners):
    """
    Given a list of integer corner tuples (differing in exactly one axis per step),
    return the full sequence of grid points along each edge, moving one step at a time.
    """
    full = []
    for a, b in zip(corners, corners[1:]):
        a = np.array(a, dtype=int)
        b = np.array(b, dtype=int)
        diff = (b - a + domain_size) % domain_size
        # pick shortest wrap direction
        minimal = []
        for di, ds in zip(diff, domain_size):
            minimal.append(di if di <= ds//2 else di - ds)
        diff = np.array(minimal, dtype=int)
        n = int(np.max(np.abs(diff)))
        if n <= 0:
            continue
        step = diff // n
        for i in range(n):
            pt = (a + step * i) % domain_size
            full.append(tuple(pt.tolist()))
    full.append(tuple(corners[-1]))
    return full


def plot_path_3d(coords, title=None, annotate=False):
    """3D scatter + line plot of the given coordinates."""
    arr = np.array(coords, dtype=int)
    if arr.shape[1] != 3:
        raise ValueError(f"Cannot 3D-plot data with dimension {arr.shape[1]}")
    fig = plt.figure(figsize=(8, 6))
    ax = fig.add_subplot(111, projection='3d')
    xs, ys, zs = arr[:,0], arr[:,1], arr[:,2]
    ax.plot(xs, ys, zs, '-o', markersize=4, color='red', zorder=2)
    if annotate:
        for i, (x, y, z) in enumerate(arr):
            ax.text(x, y, z, str(i), size=8, zorder=3)
    ax.set_xlabel('X'); ax.set_ylabel('Y'); ax.set_zlabel('Z')
    if title:
        ax.set_title(title)
    plt.tight_layout()
    return fig, ax


def find_default_diagnostics():
    candidates = glob.glob('holonomy_runs/spatial/*/diagnostics.pkl')
    if not candidates:
        raise FileNotFoundError("No diagnostics found under holonomy_runs/spatial/")
    return sorted(candidates)[0]


def main():
    parser = argparse.ArgumentParser(
        description='Inspect and plot 3D holonomy transport paths.'
    )
    parser.add_argument(
        'diagnostics',
        nargs='?',
        default=None,
        help='Path to diagnostics.pkl file'
    )
    parser.add_argument(
        '--annotate',
        action='store_true',
        help='Annotate point indices'
    )
    parser.add_argument(
        '--output', '-o',
        default=None,
        help='Output image file (PNG)'
    )
    args = parser.parse_args()

    diag_path = args.diagnostics or find_default_diagnostics()
    print(f"Loading diagnostics from: {diag_path}")
    diag = load_diagnostics(diag_path)

    corners = diag.get('path_coords') or diag.get('coords')
    if corners is None:
        raise KeyError("No 'path_coords' found in diagnostics")

    mj, viol = check_continuity(corners)
    print(f"Corner max jump: {mj:.3f}")
    if viol:
        print("Corner continuity violations at indices:", viol)

    path = expand_grid_path(corners)
    mj2, viol2 = check_continuity(path, tol=1.1)
    print(f"Full path max jump: {mj2:.3f}")
    if viol2:
        print("Full path continuity violations at indices:", viol2)
    else:
        print("Full path is continuous (unit steps).")

    # Plot path
    fig, ax = plot_path_3d(path,
        title=f"Holonomy Path: {os.path.basename(os.path.dirname(diag_path))}",
        annotate=args.annotate
    )

    # --- Overlay agent mask beneath path ---
    # Determine which step this is from folder name
    step_folder = os.path.basename(os.path.dirname(diag_path))
    # e.g. '12-15_7' => tail after '_' is step
    try:
        step = int(step_folder.split('_')[-1])
        ckpt = os.path.join(checkpoint_dir, f"step_{step:04d}.pkl")
        with open(ckpt, 'rb') as f:
            data = pickle.load(f)
        agents = data[0] if isinstance(data, tuple) else data
        mask = agents[0].mask
        xm, ym, zm = np.where(mask >= support_cutoff_eps)
        # plot mask points in light gray, low alpha
        ax.scatter(xm, ym, zm, marker='o', s=5, alpha=0.6, c='blue', zorder=1)
    except Exception as e:
        print(f"Could not overlay mask: {e}")

    if args.output:
        fig.savefig(args.output, dpi=150)
        print(f"Saved plot to {args.output}")
    else:
        plt.show()


if __name__ == '__main__':
    main()
