# plot_log.py

import os
import pickle
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from pandas.plotting import scatter_matrix
import config
import numpy as np

# (Optional) human‐friendly titles and y‐labels
PRETTY = {
    'kl_self':             ("Self KL",           r"$D_{KL}(q\|p)$"),
    'kl_align':            ("Belief Align",      r"$D_{KL}(q_i\|\Omega q_j)$"),
    'kl_model_align':      ("Model Align",       r"$D_{KL}(p_i\|\widetilde\Omega p_j)$"),
    'phi_norm':            ("‖φ‖",               r"avg‖φ‖"),
    'phi_model_norm':      ("‖φ̃‖",              r"avg‖φ̃‖"),
    'entropy':             ("Entropy",           "avg H(q)"),
    'total_energy':        ("Total Energy",      "E_total"),
    'lap_phi_norm':        ("Laplacian φ",       r"‖Δφ‖"),
    'delta_phi_norm':      ("Δφ norm",           r"‖Δφ‖"),
    'curvature_norm':      ("Curvature",         "avg‖F‖"),
    'fisher_information':  ("Fisher Info",       "I_fisher"),
    'cross_model_kl':      ("Cross‐KL",          r"$D_{KL}(q_i\|\widetilde\Omega p_j)$"),
}

def main():
    # 1) load metrics
    path = os.path.join("checkpoints", "metric_log.pkl")
    with open(path, "rb") as f:
        metrics = pickle.load(f)

    # 2) DataFrame
    df = pd.DataFrame(metrics)
    df.set_index("step", inplace=True)

    # 3) prepare output folder
    cfg = config
    folder = (
        f"plots/{cfg.group_name}"
        f"_α{cfg.alpha}_β{cfg.beta}_γ{cfg.gamma}"
        f"_maw{cfg.model_align_weight}"
        f"_dist_{cfg.distribution_family}"
    )
    os.makedirs(folder, exist_ok=True)

    # 4) plot each metric (time series)
    for col in df.columns:
        title, ylabel = PRETTY.get(col, (col, col))
        plt.figure(figsize=(6,4))
        plt.plot(df.index, df[col], marker=".", linestyle="-")
        plt.title(title)
        plt.xlabel("Step")
        plt.ylabel(ylabel)
        plt.tight_layout()
        out = os.path.join(folder, f"{col}.png")
        plt.savefig(out, dpi=150)
        plt.close()
        print(f"Saved {out}")

     # 5.2 Log–Log convergence plots
    for col in df.columns:
        plt.figure(figsize=(6,4))
        plt.loglog(df.index + 1, df[col], marker='.', linestyle='-')
        plt.title(f"Log–Log plot of {col}")
        plt.xlabel("Step")
        plt.ylabel(col)
        plt.tight_layout()
        out = os.path.join(folder, f"{col}_loglog.png")
        plt.savefig(out, dpi=150)
        plt.close()
        print(f"Saved {out}")

    # 5.3 Rolling-average overlays
    window = 10
    for col in df.columns:
        plt.figure(figsize=(6,4))
        plt.plot(df.index, df[col], alpha=0.3, label="raw")
        plt.plot(df.index, df[col].rolling(window).mean(), label=f"MA({window})")
        plt.title(f"{col} with Rolling Avg")
        plt.xlabel("Step")
        plt.ylabel(col)
        plt.legend()
        plt.tight_layout()
        out = os.path.join(folder, f"{col}_rollavg.png")
        plt.savefig(out, dpi=150)
        plt.close()
        print(f"Saved {out}")

    # 5.4 Correlation heatmap
    plt.figure(figsize=(8,6))
    corr = df.corr()
    sns.heatmap(corr, annot=True, fmt=".2f", cmap="viridis")
    plt.title("Metric Correlation")
    plt.tight_layout()
    out = os.path.join(folder, "correlation_heatmap.png")
    plt.savefig(out, dpi=150)
    plt.close()
    print(f"Saved {out}")

    # … after your correlation‐heatmap …

# 5.5) — a cleaner pair-plot of core metrics
    cols = ["kl_self", "kl_align", "kl_model_align", "total_energy", "phi_norm", "phi_model_norm"]
    n_max = 500
    df_sub = df[cols].sample(n=min(len(df), n_max), random_state=0)

    g = sns.pairplot(
        df_sub,
        kind="scatter",
        diag_kind="kde",
        plot_kws={"s": 10, "alpha": 0.3},
        diag_kws={"shade": True},
    )

    # rotate the x- and y-labels for readability
    for ax in g.axes.flatten():
        if ax is not None:
            for label in ax.get_xticklabels():
                label.set_rotation(45)
            for label in ax.get_yticklabels():
                label.set_rotation(0)

    out = os.path.join(folder, "pairplot_core_metrics.png")
    g.fig.savefig(out, dpi=150, bbox_inches="tight")
    print(f"Saved {out}")

    # 5.6) Heatmap of all metrics over time
    plt.figure(figsize=(10,8))
    plt.imshow(df.T, aspect='auto', interpolation='none')
    plt.yticks(range(len(df.columns)), df.columns)
    plt.xlabel("Step")
    plt.title("Metrics Over Time")
    plt.colorbar(label="Value")
    plt.tight_layout()
    out = os.path.join(folder, "metrics_heatmap.png")
    plt.savefig(out, dpi=150)
    plt.close()
    print(f"Saved {out}")

    print("All done.")

if __name__ == "__main__":
    main()
