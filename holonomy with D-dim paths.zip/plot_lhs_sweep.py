import os
import pickle
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

from generalized_io_utils import load_final_step
from generalized_diagnostics_metrics import log_all_metrics


def build_dataframe(lhs_dir="lhs_results"):
    def flatten_dict_values(d):
        flat = {}
        for k, v in d.items():
            if isinstance(v, dict) and "value" in v:
                flat[k] = v["value"]
            else:
                flat[k] = v
        return flat

    records = []
    for subdir in sorted(os.listdir(lhs_dir)):
        run_path = os.path.join(lhs_dir, subdir)
        if not os.path.isdir(run_path):
            continue

        # Load run parameters
        param_path = os.path.join(run_path, "params.pkl")
        if not os.path.exists(param_path):
            print(f"[SKIP] Missing params.pkl in: {subdir}")
            continue
        with open(param_path, "rb") as f:
            params = pickle.load(f)

        # Load final metrics
        metrics_path = os.path.join(run_path, "final_metrics.pkl")
        if os.path.exists(metrics_path):
            with open(metrics_path, "rb") as f:
                metrics = pickle.load(f)
                # 🔧 FIX: Handle list of step metrics
                if isinstance(metrics, list) and all(isinstance(m, dict) for m in metrics):
                    metrics = metrics[-1]
        else:
            try:
                agents = load_final_step(run_path)
                if agents is None:
                    print(f"[SKIP] No step_*.pkl in: {subdir}")
                    continue
                metrics = log_all_metrics(agents, step=-1)
            except Exception as e:
                print(f"[SKIP] Failed to compute metrics in {subdir}: {type(e).__name__}: {e}")
                continue

        combined = {**flatten_dict_values(params), **flatten_dict_values(metrics)}
        records.append(combined)

    df = pd.DataFrame(records)

    # Drop non-scalar columns to prevent seaborn/pandas errors
    for col in df.columns:
        if df[col].apply(lambda x: isinstance(x, (dict, list, set))).any():
            print(f"[WARNING] Dropping non-scalar column: {col}")
            df.drop(columns=[col], inplace=True)

    # --- Filter and normalize phi-based diagnostics ---
    eps = 1e-9
    if "phi_init" in df.columns:
        df = df[df["phi_init"] > 1e-3]  # filter out near-zero phi_init

        if "curvature" in df.columns:
            df["curvature_scaled"] = df["curvature"] / (df["phi_init"] ** 2 + eps)
            df["log_curvature_scaled"] = np.log10(df["curvature_scaled"] + eps)

        if "phi_norm" in df.columns:
            df["phi_gain"] = df["phi_norm"] / (df["phi_init"] + eps)

        df["log_phi_init"] = np.log10(df["phi_init"] + eps)

    print(f"[INFO] Loaded {len(df)} complete runs.")
    return df


def plot_pairwise_relationships(df, param_keys, metric_keys, outdir="lhs_plots"):
    os.makedirs(outdir, exist_ok=True)
    for metric in metric_keys:
        for param in param_keys:
            if param not in df.columns or metric not in df.columns:
                print(f"[WARN] Skipping plot {metric} vs {param} (missing column)")
                continue
            plt.figure(figsize=(6, 4))
            sns.scatterplot(data=df, x=param, y=metric)
            plt.title(f"{metric} vs {param}")
            plt.tight_layout()
            plot_path = os.path.join(outdir, f"{metric}_vs_{param}.png")
            plt.savefig(plot_path)
            plt.close()

    subset_keys = [k for k in param_keys + metric_keys if k in df.columns]
    if len(subset_keys) >= 2:
        sns.pairplot(df[subset_keys])
        plt.savefig(os.path.join(outdir, "pairplot_all.png"))
        plt.close()


if __name__ == "__main__":
    lhs_dir = "lhs_results"
    df = build_dataframe(lhs_dir)

    if df.empty:
        print("[ERROR] No valid LHS runs found. Aborting.")
        import sys
        sys.exit(1)

    param_cols = [
    "alpha", "beta", "gamma",
    "gauge_weight",
    "model_align_weight", "model_gauge_weight",
    "model_mass_weight", "model_feedback_weight",
    "phi_phi_tilde_coupling",
    "phi_init",
    # Optional (uncomment if used in sweep):
    # "curvature_weight", "phi_damping"
]

    metric_cols = [
    "kl_self", "kl_align", "kl_model_align", "cross_model_kl",
    "total_energy",
    "phi_norm", "phi_model_norm",
    "lap_phi_norm", "delta_phi_norm",
    "curvature", "curvature_scaled", "phi_gain",
    # Optional: "entropy", "fisher_information"
]


    plot_pairwise_relationships(df, param_cols, metric_cols)
    print("[DONE] Plots saved to lhs_plots/")
