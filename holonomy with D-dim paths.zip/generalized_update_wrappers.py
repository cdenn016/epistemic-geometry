# generalized_update_wrappers.py

from get_generators import get_generators

from generalized_update_rules import update_distribution_generic, update_phi_generic
from generalized_update_terms import (
    compute_beliefs_gradient,
    compute_models_gradient,
    compute_phi_alignment_gradient,
    compute_phi_model_update,
)
def update_beliefs(i, agents, params):
    return update_distribution_generic(
        i, agents, params,
        dist_attr="q",
        eta_key="eta_q",
        grad_fn=compute_beliefs_gradient,
    )

def update_models(i, agents, params):
    return update_distribution_generic(
        i, agents, params,
        dist_attr="p",
        eta_key="eta_p",
        grad_fn=compute_models_gradient,
        feedback_weight_key="model_feedback_weight",
    )

def update_phi(i, agents, params):
    return update_phi_generic(
        i, agents, params,
        field_name="phi",
        compute_gradient_fn=compute_phi_alignment_gradient,
        coupling_field_name="phi_model",
        coupling_weight_key="phi_phi_tilde_coupling",
        smoothing_weight_key="gamma",
        mass_weight_key="gauge_weight",
        damping_weight_key="phi_damping",
        debug_key="debug",
        # eta_key defaults to "eta_phi", max_norm_key to "phi_max_norm", etc.
    )

def update_phi_model(i, agents, params):
    return update_phi_generic(
        i, agents, params,
        field_name="phi_model",
        compute_gradient_fn=compute_phi_model_update,
        coupling_field_name="phi",
        coupling_weight_key="phi_phi_tilde_coupling",
        smoothing_weight_key="model_gauge_weight",
        mass_weight_key="model_mass_weight",
        damping_weight_key="phi_damping",
        debug_key="debug",
        eta_key="eta_model_phi",            # ✅ this is critical!
        max_norm_key="phi_max_norm",        # optional but safe
        blowup_threshold_key="blowup_threshold",  # ensure this is enforced
    )

