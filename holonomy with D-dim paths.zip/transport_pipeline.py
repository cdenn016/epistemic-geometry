# transport_pipeline.py
# Step-by-step belief transport across saved simulation steps using a fixed path

import os
import pickle
from datetime import datetime
from config import domain_size, support_cutoff_eps, group_name, K, checkpoint_dir
from generalized_io_utils import load_checkpoint
from get_generators import get_generators
from transport_operator import transport_belief_over_chain
from find_agent_chains import find_candidate_paths, get_overlap_centroid
from visualize_transport_path import plot_transport_path_overlay
import numpy as np

import config


def run_dynamic_transport():
    # --- Configurable inputs ---
    transport_dir = "transport_runs"
    metadata_path = "transport_path_metadata.pkl"
    fiber_key = "q"           # or "p"
    phi_key = "phi"           # or "phi_model"
    max_chain_length = 3       # try d = 6, 5, ..., 1

    os.makedirs(transport_dir, exist_ok=True)

    # --- Step 1: Load initial agents ---
    initial_path = os.path.join(checkpoint_dir, "step_0000.pkl")
    if not os.path.exists(initial_path):
        raise FileNotFoundError(f"[ERROR] Missing initial checkpoint: {initial_path}")

    with open(initial_path, "rb") as f:
        agents = pickle.load(f)

    # --- Step 2: Find agent path ---
    centers = np.array([a.center for a in agents])
    dist = np.linalg.norm(centers[:, None, :] - centers[None, :, :], axis=-1)
    start_id, end_id = np.unravel_index(np.argmax(dist), dist.shape)

    path = None
    for d in range(max_chain_length, 0, -1):
        path, c_start, c_end, overlap_points = find_candidate_paths(
            agents, start_id, end_id, d,
            domain_size=domain_size,
            support_cutoff_eps=support_cutoff_eps
        )
        if path:
            print(f"[✓] Found path of length {len(path)}: {path}")
            break

    # --- Fallback: try direct 2-agent path ---
    if not path:
        direct_centroid = get_overlap_centroid(
            agents[start_id], agents[end_id], domain_size, support_cutoff_eps
        )
        if direct_centroid is not None:
            path = [start_id, end_id]
            overlap_points = [direct_centroid]
            c_start = tuple(agents[start_id].center)
            c_end = tuple(agents[end_id].center)
            print(f"[✓] Fallback to direct path: {path} via {direct_centroid}")
        else:
            raise RuntimeError("[FAIL] No valid transport path found")

    # --- Step 3: Save metadata ---
    metadata = {
        "path": path,
        "overlap_points": overlap_points,
        "start_coord": c_start,
        "end_coord": c_end,
        "start_id": start_id,
        "end_id": end_id,
        "length": len(path) - 2
    }
    metadata_path = os.path.join(transport_dir, "transport_path_metadata.pkl")
    with open(metadata_path, "wb") as f:
        pickle.dump(metadata, f)
    print(f"[✓] Saved path metadata to: {metadata_path}")

    # --- Step 3.5: Plot path overlay ---
    # Only plot overlay if domain is 2D
    if len(domain_size) == 2:
        plot_transport_path_overlay(
        agents=agents,
        path=path,
        overlap_points=overlap_points,
        domain_size=domain_size,
        savepath=os.path.join(transport_dir, "transport_path_overlay.png")
    )


    # --- Step 4: Load transport operator ---
    generators = get_generators(group_name, K)

    # --- Step 5: Gather all step files ---
    step_files = sorted([
        f for f in os.listdir(checkpoint_dir)
        if f.startswith("step_") and f.endswith(".pkl")
    ], key=lambda s: int(s.split("_")[1].split(".")[0]))

    # --- Step 6: Run transport for each step ---
    for fname in step_files:
        step = int(fname.split("_")[1].split(".")[0])
        print(f"[TRANSPORT] Step {step}")
        with open(os.path.join(checkpoint_dir, fname), "rb") as f:
            agents = pickle.load(f)
        
        injection_mode = getattr(config, "injection_mode", "from_q")

        agents, diagnostics = transport_belief_over_chain(
            agents=agents,
            path=metadata["path"],
            overlap_points=metadata["overlap_points"],
            generators=generators,
            domain_size=domain_size,
            fiber_key=fiber_key,
            phi_key=phi_key,
            fixed_start=metadata["start_coord"],
            fixed_end=metadata["end_coord"],
            config=config,
            injection_mode=injection_mode,
        )

        step_dir = os.path.join(transport_dir, f"step_{step:04d}")
        os.makedirs(step_dir, exist_ok=True)

        with open(os.path.join(step_dir, "diagnostics.pkl"), "wb") as f:
            pickle.dump(diagnostics, f)

        for t, q in enumerate(diagnostics.get("q_sequence", [])):
            qpath = os.path.join(step_dir, f"q_step_{t:03d}.pkl")
            with open(qpath, "wb") as f:
                pickle.dump(q, f)

        print(f"[✓] Saved transport result for step {step} to: {step_dir}")


if __name__ == "__main__":
    run_dynamic_transport()