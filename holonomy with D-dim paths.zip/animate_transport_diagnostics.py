# plot_transport_diagnostics.py
# Visualize KL divergence, belief evolution, and transport path

import os
import pickle
import numpy as np
import matplotlib.pyplot as plt
import imageio


# --- Directories ---
TRANSPORT_DIR = "transport_runs"
OUTDIR = "dynamic transport visualization"
os.makedirs(OUTDIR, exist_ok=True)

# Load metadata and injection mode
METADATA_PATH = os.path.join(TRANSPORT_DIR, "transport_path_metadata.pkl")
with open(METADATA_PATH, "rb") as f:
    metadata = pickle.load(f)

start_coord = metadata["start_coord"]
end_coord = metadata["end_coord"]
injection_mode = metadata.get("injection_mode", "from_q")  # fallback if not stored
label_str = f"{injection_mode}_from_{start_coord}_to_{end_coord}".replace(" ", "").replace("(", "").replace(")", "").replace(",", "_")


def load_kl_sequences(transport_dir):
    kl_fine = []
    kl_coarse = []
    steps = []

    for folder in sorted(os.listdir(transport_dir)):
        if not folder.startswith("step_"): continue
        step = int(folder.split("_")[1])
        diag_path = os.path.join(transport_dir, folder, "diagnostics.pkl")
        if not os.path.exists(diag_path):
            continue
        with open(diag_path, "rb") as f:
            diag = pickle.load(f)
        kl_fine.append(np.mean(diag.get("kl_path_fine", [0])))
        kl_coarse.append(np.mean(diag.get("kl_path_coarse", [0])))
        steps.append(step)

    return np.array(steps), np.array(kl_fine), np.array(kl_coarse)



def plot_kl_vs_time(steps, kl_fine, kl_coarse):
    plt.figure(figsize=(8, 4))
    plt.plot(steps, kl_fine, label="KL (fine path)", color="black")
    plt.plot(steps, kl_coarse, label="KL (agent jumps)", linestyle="--", color="orange")
    plt.xlabel("Simulation Step")
    plt.ylabel("KL Divergence")
    plt.title("KL Over Time — " + label_str)
    plt.grid(True)
    plt.legend()
    plt.tight_layout()
    save_path = os.path.join(OUTDIR, f"kl_vs_time_{label_str}.png")
    plt.savefig(save_path)
    plt.show()
    print(f"[✓] Saved KL plot to {save_path}")


def plot_final_belief_at_end():
    import glob
    files = sorted(glob.glob(os.path.join(TRANSPORT_DIR, "step_*/q_step_*.pkl")))
    if not files:
        print("[WARNING] No q_step files found.")
        return

    with open(files[-1], "rb") as f:
        q = pickle.load(f)

    plt.figure(figsize=(6, 3))
    plt.plot(q, color="blue")
    plt.title(f"Final Belief Vector — {label_str}")
    plt.xlabel("Fiber Index")
    plt.ylabel("Probability")
    plt.grid(True)
    plt.tight_layout()
    save_path = os.path.join(OUTDIR, f"final_q_vector_{label_str}.png")
    plt.savefig(save_path)
    plt.show()
    print(f"[✓] Saved final transported belief vector to {save_path}")



def animate_q_vectors(savepath=None):
    import glob

    step_dirs = sorted(glob.glob(os.path.join(TRANSPORT_DIR, "step_*")), key=lambda d: int(d.split("_")[-1]))
    images = []

    # Load first step's q_initial
    if not step_dirs:
        print("[WARNING] No step directories found.")
        return

    with open(os.path.join(step_dirs[0], "diagnostics.pkl"), "rb") as f:
        first_diag = pickle.load(f)
    q_initial = first_diag.get("q_initial", None)

    # Determine global y-axis range
    max_val = 0
    for step_dir in step_dirs:
        q_files = sorted(glob.glob(os.path.join(step_dir, "q_step_*.pkl")))
        if not q_files: continue
        with open(q_files[-1], "rb") as f:
            q = pickle.load(f)
            max_val = max(max_val, np.max(q))

    for step_dir in step_dirs:
        q_files = sorted(glob.glob(os.path.join(step_dir, "q_step_*.pkl")))
        if not q_files: continue
        with open(q_files[-1], "rb") as f:
            q = pickle.load(f)

        step = int(step_dir.split("_")[-1])
        fig, ax = plt.subplots(figsize=(6, 3))

        # Plot evolving q
        ax.plot(q, color="blue", label="Transported q (final)")
        # Plot initial q for reference
        if q_initial is not None:
            ax.plot(q_initial, color="gray", linestyle="--", label="Initial q")

        ax.set_title(f"Step {step} — {label_str}")
        ax.set_xlabel("Fiber Index")
        ax.set_ylabel("Probability")
        ax.set_ylim(0, max_val * 1.1)
        ax.grid(True)
        ax.legend()
        fig.tight_layout()

        tmp_path = f"frame_{step:04d}.png"
        fig.savefig(tmp_path)
        plt.close(fig)
        images.append(imageio.imread(tmp_path))
        os.remove(tmp_path)

    gif_path = savepath or os.path.join(OUTDIR, f"q_evolution_{label_str}.gif")
    imageio.mimsave(gif_path, images, fps=5)
    print(f"[✓] Saved animated belief evolution to {gif_path}")

def animate_belief_transport_path(savepath=None):
    import glob

    step_dirs = sorted(glob.glob(os.path.join(TRANSPORT_DIR, "step_*")), key=lambda d: int(d.split("_")[-1]))
    if not step_dirs:
        print("[WARNING] No step directories found.")
        return

    # Choose a single step to animate path-wise (typically the last one)
    step_dir = step_dirs[-1]

    q_files = sorted(glob.glob(os.path.join(step_dir, "q_step_*.pkl")))
    if not q_files:
        print("[WARNING] No q_step_*.pkl files found in:", step_dir)
        return

    # Load all path-step q's
    q_sequence = []
    for q_path in q_files:
        with open(q_path, "rb") as f:
            q = pickle.load(f)
            q_sequence.append(q)

    images = []
    max_val = max(np.max(q) for q in q_sequence)

    for t, q in enumerate(q_sequence):
        fig, ax = plt.subplots(figsize=(6, 3))
        ax.plot(q, color="blue")
        ax.set_title(f"Transport Path Step {t} — {label_str}")
        ax.set_xlabel("Fiber Index")
        ax.set_ylabel("Probability")
        ax.set_ylim(0, max_val * 1.1)
        ax.grid(True)
        fig.tight_layout()

        tmp_path = f"frame_path_{t:03d}.png"
        fig.savefig(tmp_path)
        plt.close(fig)
        images.append(imageio.imread(tmp_path))
        os.remove(tmp_path)

    gif_path = savepath or os.path.join(OUTDIR, f"q_along_path_{label_str}.gif")
    imageio.mimsave(gif_path, images, fps=5)
    print(f"[✓] Saved belief transport animation to {gif_path}")


if __name__ == "__main__":
    steps, kl_fine, kl_coarse = load_kl_sequences(TRANSPORT_DIR)
    #plot_kl_vs_time(steps, kl_fine, kl_coarse)
    animate_q_vectors()
    animate_belief_transport_path()