from scipy.linalg import norm, det, expm
import numpy as np
from get_generators import get_generators
from generalized_omega import exp_lie_algebra_operator


def validate_so3_irrep(K_list, num_trials=5):
    for K in K_list:
        print(f"\n=== Validating SO(3) irrep for K={K} ===")
        try:
            gens = get_generators("so3", K)  # shape = (3, K, K)
        except Exception as e:
            print(f"[ERROR] Failed to generate generators for K={K}: {e}")
            continue

        dim = gens.shape[1]
        I = np.eye(dim)
        ℓ = (K - 1) // 2
        expected_casimir = ℓ * (ℓ + 1)

        # --- Generator antisymmetry check ---
        antisymmetry_errors = [norm(G + G.T) for G in gens]
        print("  [GEN] Max antisymmetry error:        ", f"{max(antisymmetry_errors):.6g}")

        # --- Commutator closure ---
        comm_errors = []
        for i in range(3):
            for j in range(i + 1, 3):
                comm = gens[i] @ gens[j] - gens[j] @ gens[i]
                coeffs = [np.trace(comm @ gens[k].T) / np.trace(gens[k] @ gens[k].T) for k in range(3)]
                proj = sum(coeffs[k] * gens[k] for k in range(3))
                err = norm(comm - proj)
                comm_errors.append(err)
        print("  [GEN] Max commutator closure error: ", f"{max(comm_errors):.6g}")

        # --- Casimir operator check ---
        casimir = sum([G @ G for G in gens])
        deviation = norm(casimir - expected_casimir * I) / norm(expected_casimir * I)
        print("  [GEN] Casimir deviation (relative): ", f"{deviation:.6g}")

        # --- Omega tests using general exponentiator ---
        for t in range(num_trials):
            phi = np.random.randn(3)
            from generalized_omega import exp_lie_algebra_irrep

            Omega = exp_lie_algebra_irrep(
                    phi[np.newaxis, :],  # shape (1, dim_G)
                    gens,
                    use_expm=True,
                    threshold=1e-3,
                    max_norm=20,
                    group_name="so3",    # we patched it to support this
                    )[0]  # unpack single result


            orthogonality_error = norm(Omega.T @ Omega - I)
            determinant = det(Omega)
            imag_error = np.max(np.abs(Omega.imag))

            print(f"  [Ω  ] Trial {t+1}: ‖ΩᵀΩ−I‖={orthogonality_error:.2e}, "
                  f"det(Ω)={determinant:.6f}, max|Im(Ω)|={imag_error:.2e}")


if __name__ == "__main__":
    odd_K_values = [23, 25, 27, 29, 211, 15, 21, 31, 243]
    validate_so3_irrep(odd_K_values)
