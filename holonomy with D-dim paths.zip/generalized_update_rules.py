import numpy as np
from scipy.ndimage import laplace

from generalized_math_utils import kl_divergence, sanitize_q
from generalized_agent_schema import Agent  
import config 

def update_distribution_generic(
    i: int,
    agents: list,
    params: dict,
    dist_attr: str,
    eta_key: str,
    grad_fn,
    feedback_weight_key: str | None = None
) -> 'Agent':
    """
    Generic update for any probability distribution field (q or p).
    grad_fn must be of the form grad_fn(agent_i, agents, params).
    """
    import config
    

    # --- Fix: allow params to be None ---
    params = params or {}

    # Pull defaults from config when not overridden:
    eta               = params.get(eta_key, getattr(config, eta_key))
    log_eps           = params.get("log_eps", config.log_eps)
    support_cutoff_eps= params.get("support_cutoff_eps", config.support_cutoff_eps)
    feedback_weight   = (
        params.get(feedback_weight_key, getattr(config, feedback_weight_key))
        if feedback_weight_key else 0.0
    )

    agent_i = agents[i]
    dist     = getattr(agent_i, dist_attr)
    mask     = agent_i.mask

    # Compute the gradient using the shared params dict
    grad = grad_fn(agent_i, agents, params)

    # Optional p ← q feedback term
    if feedback_weight_key and dist_attr == "p" and feedback_weight > 0:
        q_safe = np.clip(agent_i.q, log_eps, 1.0)
        p_safe = np.clip(dist,      log_eps, 1.0)
        grad_qp = np.log(p_safe / q_safe)
        grad   += feedback_weight * grad_qp

    # Euler update
    dist_new = dist - eta * grad

    # Freeze outside the support mask
    outside = mask < support_cutoff_eps
    dist_new[outside] = dist[outside]

    # Renormalize with a floor
    try:
        dist_new = sanitize_q(dist_new, eps=log_eps)
    except Exception:
        dist_new = np.clip(dist_new, log_eps, None)
        dist_new /= dist_new.sum(axis=-1, keepdims=True) + log_eps

    setattr(agent_i, dist_attr, dist_new)
    return agent_i


def update_phi_generic(
    i: int,
    agents: list,
    params: dict,
    field_name: str,
    compute_gradient_fn,
    coupling_field_name: str | None = None,
    coupling_weight_key:   str | None = None,
    smoothing_weight_key:  str | None = None,
    mass_weight_key:       str | None = None,
    damping_weight_key:    str | None = None,
    debug_key:             str | None = None,
    eta_key:               str = "eta_phi",
    max_norm_key:          str = "phi_max_norm",
    blowup_threshold_key:  str = "blowup_threshold",
) -> 'Agent':
    
    params = params or {}

    # --- Load hyperparameters ---
    eta       = params.get(eta_key, getattr(config, eta_key))
    w_couple  = (params.get(coupling_weight_key, getattr(config, coupling_weight_key))
                 if coupling_weight_key else 0.0)
    w_smooth  = (params.get(smoothing_weight_key, getattr(config, smoothing_weight_key))
                 if smoothing_weight_key else 0.0)
    w_mass    = (params.get(mass_weight_key, getattr(config, mass_weight_key))
                 if mass_weight_key else 0.0)
    w_damp    = (params.get(damping_weight_key, getattr(config, damping_weight_key))
                 if damping_weight_key else 0.0)
    phi_max   = params.get(max_norm_key, getattr(config, max_norm_key))
    
    thresh    = params.get(blowup_threshold_key, getattr(config, blowup_threshold_key))
        
    debug     = params.get(debug_key, getattr(config, debug_key)) if debug_key else False

    clip_thresh = params.get("phi_clip_threshold", getattr(config, "phi_clip_threshold", np.inf))

    agent_i = agents[i]
    phi     = getattr(agent_i, field_name)
    mask    = agent_i.mask

    # --- Compute gradient ---
    delta_phi = compute_gradient_fn(agent_i, agents, params)

    # --- Add coupling ---
    if w_couple > 0 and coupling_field_name and hasattr(agent_i, coupling_field_name):
        other = getattr(agent_i, coupling_field_name)
        delta_phi -= w_couple * (phi - other) * mask[..., None]

    # --- Add Laplacian smoothing ---
    if w_smooth > 0:
        lap = np.stack([laplace(phi[..., d]) for d in range(phi.shape[-1])], axis=-1)
        delta_phi -= w_smooth * lap * mask[..., None]

    # --- Mass + damping ---
    if w_mass > 0:
        delta_phi -= w_mass * phi * mask[..., None]
    if w_damp > 0:
        delta_phi -= w_damp * phi * mask[..., None]

    # --- Norm-based control ---
    delta_norm = np.linalg.norm(delta_phi, axis=-1, keepdims=True)

    # Skip updates with dangerously large gradient
    skip_mask = (delta_norm > thresh)
    if np.any(skip_mask):
        delta_phi = np.where(skip_mask, 0.0, delta_phi)

    # Scale down large steps
    scale_mask = (delta_norm > clip_thresh)
    scale_factor = np.minimum(1.0, clip_thresh / (delta_norm + config.eps))
    delta_phi = np.where(scale_mask, delta_phi * scale_factor, delta_phi)

    # --- Debug logging ---
    if debug:
        clipped = int(scale_mask.sum())
        skipped = int(skip_mask.sum())
        total   = int(np.prod(delta_norm.shape[:-1]))
        max_delta = float(np.max(delta_norm))

        #print(f"[phi DIAG] {field_name} agent {i}: {clipped}/{total} clipped, {skipped} skipped")
        if max_delta > thresh:
            print(f"[WARNING] {field_name} update unstable at agent {i}: max_delta={max_delta:.2e}")
        elif clipped > 0:
            print(f"[INFO] {field_name} agent {i}: max_delta={max_delta:.2e} (clipped)")
        else:
            print(f"[DEBUG] {field_name} agent {i}: max_delta={max_delta:.2e}")

    # --- Safety: remove NaNs or infs ---
    delta_phi = np.nan_to_num(delta_phi, nan=0.0, posinf=0.0, neginf=0.0)

    # --- Euler update ---
    phi_new = phi + eta * delta_phi

    # --- Clip norm ---
    norm = np.linalg.norm(phi_new, axis=-1, keepdims=True)
    mask_clip = norm > phi_max
    phi_new = np.where(mask_clip, phi_new * (phi_max / (norm + config.eps)), phi_new)

    # --- Store back ---
    setattr(agent_i, field_name, phi_new)
    setattr(agent_i, f"delta_{field_name}", delta_phi)
    return agent_i
