import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import os

from visualize_fields import project_field



def animate_scalar_field_over_time(
    field_sequence,
    title="Scalar Field Evolution",
    cmap="viridis",
    savepath="scalar_field_evolution.gif",
    fps=10
):
    """
    Animate a sequence of scalar fields over time.
    Each frame should be (H, W) or projectable to 2D.
    """
    field_sequence = np.array(field_sequence)  # shape (T, ...)
    T = field_sequence.shape[0]
    proj_field = project_field(field_sequence[0])

    fig, ax = plt.subplots()
    im = ax.imshow(proj_field, cmap=cmap, origin="lower")
    fig.colorbar(im)
    ax.set_title(f"{title} — t=0")

    def update(frame):
        f = project_field(field_sequence[frame])
        im.set_data(f)
        ax.set_title(f"{title} — t={frame}")
        return [im]

    ani = animation.FuncAnimation(fig, update, frames=T, blit=False)
    os.makedirs(os.path.dirname(savepath), exist_ok=True)
    ani.save(savepath, writer="pillow", fps=fps)
    plt.close()


def animate_q_distribution_over_time(
    q_sequence,
    mask_sequence=None,
    title="Average q Distribution Evolution",
    savepath="belief_distribution_evolution.gif",
    fps=10
):
    """
    Animate spatially averaged q distribution over time as histogram.
    q_sequence: shape (T, ..., K)
    mask_sequence: optional shape (T, ...,)
    """
    q_sequence = np.array(q_sequence)
    T = q_sequence.shape[0]
    K = q_sequence.shape[-1]

    fig, ax = plt.subplots()
    bar = ax.bar(np.arange(K), np.zeros(K))
    ax.set_ylim(0, 1.0)
    ax.set_xlabel("Fiber index")
    ax.set_ylabel("Average probability")
    ax.set_title(f"{title} — t=0")

    def update(frame):
        q = q_sequence[frame]
        if mask_sequence is not None:
            mask = mask_sequence[frame]
            q = q * mask[..., None]

        avg_q = np.sum(q, axis=tuple(range(q.ndim - 1)))
        avg_q /= np.sum(avg_q) + 1e-9

        for k in range(K):
            bar[k].set_height(avg_q[k])
        ax.set_title(f"{title} — t={frame}")
        return bar

    ani = animation.FuncAnimation(fig, update, frames=T, blit=False)
    os.makedirs(os.path.dirname(savepath), exist_ok=True)
    ani.save(savepath, writer="pillow", fps=fps)
    plt.close()
