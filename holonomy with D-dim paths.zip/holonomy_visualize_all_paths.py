# -*- coding: utf-8 -*-
"""
Created on Wed Jun 18 16:52:39 2025

@author: chris and christine
"""

#!/usr/bin/env python3
import os
import glob
import pickle
import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D


def expand_grid_path(corners):
    full = []
    for a, b in zip(corners, corners[1:]):
        a = np.array(a, dtype=int)
        b = np.array(b, dtype=int)
        diff = b - a
        n = int(np.max(np.abs(diff)))
        step = diff // n
        for i in range(n):
            full.append(tuple((a + step * i).tolist()))
    full.append(tuple(corners[-1]))
    return full


def check_continuity(path):
    arr = np.array(path, dtype=float)
    dists = np.linalg.norm(np.diff(arr, axis=0), axis=1)
    return dists.max(), np.where(dists>1.5)[0].tolist()


def plot_and_save(path, outpng):
    arr = np.array(path)
    xs, ys, zs = arr[:,0], arr[:,1], arr[:,2]

    fig = plt.figure(figsize=(12,10))
    # 3D view
    ax1 = fig.add_subplot(221, projection='3d')
    ax1.plot(xs, ys, zs, '-o', markersize=3)
    ax1.set_title('3D Path')

    # XY
    ax2 = fig.add_subplot(222)
    ax2.plot(xs, ys, '-o', markersize=3)
    ax2.set_xlabel('X'); ax2.set_ylabel('Y')
    ax2.set_title('XY projection')

    # XZ
    ax3 = fig.add_subplot(223)
    ax3.plot(xs, zs, '-o', markersize=3)
    ax3.set_xlabel('X'); ax3.set_ylabel('Z')
    ax3.set_title('XZ projection')

    # YZ
    ax4 = fig.add_subplot(224)
    ax4.plot(ys, zs, '-o', markersize=3)
    ax4.set_xlabel('Y'); ax4.set_ylabel('Z')
    ax4.set_title('YZ projection')

    plt.suptitle(os.path.basename(os.path.dirname(outpng)))
    plt.tight_layout(rect=[0,0,1,0.96])
    plt.savefig(outpng, dpi=150)
    plt.close(fig)


def main():
    root = os.path.join('holonomy_runs','spatial')
    pats = glob.glob(os.path.join(root, '*', 'diagnostics.pkl'))
    print(f"Found {len(pats)} diagnostics files in {root}")
    for pkl in pats:
        data = pickle.load(open(pkl, 'rb'))
        corners = data.get('path_coords') or data.get('coords')
        if corners is None: 
            continue

        path = expand_grid_path(corners)
        max_jump, viol = check_continuity(path)
        print(f"{pkl}: max_jump={max_jump:.1f}, violations={viol}")

        # determine output path
        outdir = os.path.splitext(pkl)[0]  # drop .pkl
        outpng = outdir + '_path.png'
        plot_and_save(path, outpng)
        print(f"Saved plot to {outpng}")

if __name__ == '__main__':
    main()
