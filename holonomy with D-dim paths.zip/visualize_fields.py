import numpy as np 
import matplotlib.pyplot as plt
import os

from mpl_toolkits.mplot3d import Axes3D  # Needed for 3D plots

import matplotlib.pyplot as plt
import numpy as np
import os

def animate_scalar_field_over_time(field_sequence, title="", savepath=None, cmap="viridis",):
    import matplotlib.animation as animation

    fig, ax = plt.subplots()
    im = ax.imshow(field_sequence[0], cmap=cmap, origin="lower")
    ax.set_title(title)
    fig.colorbar(im)

    def update(frame):
        im.set_array(field_sequence[frame])
        ax.set_title(f"{title} (Step {frame})")
        return [im]

    ani = animation.FuncAnimation(fig, update, frames=len(field_sequence), blit=True)
    if savepath:
        os.makedirs(os.path.dirname(savepath), exist_ok=True)
        ani.save(savepath, writer='pillow', fps=5)
    plt.close()


def animate_q_distribution_over_time(q_sequence, mask_sequence=None, title="", savepath=None):
    import matplotlib.animation as animation

    fig, ax = plt.subplots()
    K = q_sequence[0].shape[-1]
    bar = ax.bar(np.arange(K), np.zeros(K))
    ax.set_ylim(0, 1)
    ax.set_title(title)
    ax.set_xlabel("Fiber index")
    ax.set_ylabel("Average probability")

    def update(frame):
        q = q_sequence[frame]
        if mask_sequence is not None:
            q = q * mask_sequence[frame][..., None]
        avg_q = np.sum(q, axis=(0, 1)) / (np.sum(mask_sequence[frame]) + 1e-8)
        for b, v in zip(bar, avg_q):
            b.set_height(v)
        ax.set_title(f"{title} (Step {frame})")
        return bar

    ani = animation.FuncAnimation(fig, update, frames=len(q_sequence), blit=False)
    if savepath:
        os.makedirs(os.path.dirname(savepath), exist_ok=True)
        ani.save(savepath, writer='pillow', fps=5)
    plt.close()


def project_field(field, method="mid", axis=0):
    """
    Reduce high-D field to 2D via slicing or projection.
    """
    if field.ndim <= 2:
        return field

    spatial_shape = field.shape[:-1] if field.ndim >= 3 else field.shape
    D = len(spatial_shape)

    if D == 2:
        return field
    elif D == 3:
        if method == "mid":
            idx = field.shape[axis] // 2
            return np.take(field, idx=idx, axis=axis)
        elif method == "mean":
            return np.mean(field, axis=axis)
        elif method == "sum":
            return np.sum(field, axis=axis)
    else:
        raise NotImplementedError("Projection for D > 3 is not supported yet.")


def visualize_scalar_field(field, title="", cmap="viridis", savepath=None):
    """
    Visualize a scalar field in 2D or 3D (projected to 2D).
    """
    field_2d = project_field(field)
    plt.figure(figsize=(6, 5))
    plt.imshow(field_2d, cmap=cmap, origin="lower")
    plt.colorbar()
    plt.title(title)
    plt.tight_layout()
    if savepath:
        os.makedirs(os.path.dirname(savepath), exist_ok=True)
        plt.savefig(savepath)
    plt.close()


def visualize_vector_field(field, title="", slice_idx=None, quiver_scale=1.0, savepath=None):
    """
    Visualize a vector field in 2D or 3D by slicing along the 3rd axis.
    """
    spatial_shape = field.shape[:-1]
    D = len(spatial_shape)

    if D == 2:
        X, Y = np.meshgrid(np.arange(spatial_shape[1]), np.arange(spatial_shape[0]))
        U, V = field[..., 0], field[..., 1]
        plt.figure(figsize=(6, 5))
        plt.quiver(X, Y, U, V, scale=quiver_scale)
        plt.title(title)
        plt.tight_layout()
        if savepath:
            os.makedirs(os.path.dirname(savepath), exist_ok=True)
            plt.savefig(savepath)
        plt.close()

    elif D == 3:
        if slice_idx is None:
            slice_idx = spatial_shape[2] // 2
        field_slice = field[:, :, slice_idx, :]
        X, Y = np.meshgrid(np.arange(spatial_shape[1]), np.arange(spatial_shape[0]))
        U, V = field_slice[..., 0], field_slice[..., 1]
        plt.figure(figsize=(6, 5))
        plt.quiver(X, Y, U, V, scale=quiver_scale)
        plt.title(f"{title} (slice z={slice_idx})")
        plt.tight_layout()
        if savepath:
            os.makedirs(os.path.dirname(savepath), exist_ok=True)
            plt.savefig(savepath)
        plt.close()

    else:
        raise NotImplementedError("Vector visualization only implemented for D=2 and D=3 (sliced).")


def project_field(field, method="mid", axis=0):
    if method == "mid":
        index = field.shape[axis] // 2
        return np.take(field, index, axis=axis)
    elif method == "mean":
        return np.mean(field, axis=axis)
    elif method == "sum":
        return np.sum(field, axis=axis)
    else:
        raise ValueError(f"Unknown projection method: {method}")


def animate_scalar_field_3d_over_time(field_sequence, title="", savepath=None, axis=0, method="mid", cmap="viridis"):
    """
    Animate a sequence of 3D scalar fields by slicing them to 2D.

    Parameters:
        field_sequence: list of 3D scalar fields (shape: [D1, D2, D3])
        title: str, title prefix
        savepath: str, where to save the GIF
        axis: int, which axis to slice along (0, 1, or 2)
        method: "mid", "mean", or "sum" — how to project
        cmap: matplotlib colormap
    """
    import matplotlib.animation as animation

    # Slice/projection
    projected_sequence = [project_field(field, method=method, axis=axis) for field in field_sequence]

    fig, ax = plt.subplots()
    im = ax.imshow(projected_sequence[0], cmap=cmap, origin="lower")
    fig.colorbar(im)
    ax.set_title(f"{title} (Step 0)")

    def update(frame):
        im.set_array(projected_sequence[frame])
        ax.set_title(f"{title} (Step {frame})")
        return [im]

    ani = animation.FuncAnimation(fig, update, frames=len(projected_sequence), blit=True)

    if savepath:
        os.makedirs(os.path.dirname(savepath), exist_ok=True)
        ani.save(savepath, writer="pillow", fps=5)
    plt.close()


def visualize_distribution_field(q, mask=None, title="Belief Distribution", savepath=None):
    """
    Visualize average belief distribution across space (project to 2D).
    """
    if mask is not None:
        q = q * mask[..., None]

    avg_q = np.sum(q, axis=tuple(range(q.ndim - 1)))
    avg_q /= np.sum(avg_q) + 1e-9

    plt.figure(figsize=(6, 4))
    plt.bar(np.arange(len(avg_q)), avg_q)
    plt.title(title)
    plt.xlabel("Fiber index")
    plt.ylabel("Average probability")
    if savepath:
        os.makedirs(os.path.dirname(savepath), exist_ok=True)
        plt.savefig(savepath)
    plt.close()
