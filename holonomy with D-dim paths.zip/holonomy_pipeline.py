#!/usr/bin/env python3
"""
holonomy_pipeline.py

Pipeline to compute intra-agent and inter-agent holonomy from your saved `step_XXXX.pkl` simulation checkpoints.
"""
import os
import pickle
import numpy as np
from numpy.linalg import norm
from config import checkpoint_dir, domain_size, support_cutoff_eps, group_name, K
from get_generators import get_generators
from holonomy_module import (
    sample_self_avoiding_loop_within_mask,
    compute_spatial_loop_holonomy,
    compute_agent_cycle_holonomy
)
from generalized_agent_schema import Agent
from find_agent_chains import get_overlap_centroid
from scipy.linalg import logm
import csv

# ----------------------------
# User Configuration
# ----------------------------
loop_type = 'spatial'       # 'spatial' or 'agent_cycle'
# Spatial loop parameters
single_agent_id = 0
spatial_center    = tuple(ds//2 for ds in domain_size)    # center in full D dims
spatial_size      = 10    # desired loop length
# Agent-cycle parameters (must start/end at same ID)
agent_cycle = [0, 1, 2, 0]
# ----------------------------

def run_holonomy_pipeline():
    """
    Iterate through each `step_XXXX.pkl` in `checkpoint_dir`, compute holonomy,
    and save per-step results in `holonomy_runs/step_XXXX/`.
    A CSV summary of curvature proxies is written to `holonomy_runs/summary.csv`.
    """
    holonomy_dir = 'holonomy_runs'
    os.makedirs(holonomy_dir, exist_ok=True)

    # Preload Lie generators
    generators = get_generators(group_name, K)

    # Find all checkpoint files
    step_files = sorted(
        [f for f in os.listdir(checkpoint_dir) if f.startswith('step_') and f.endswith('.pkl')],
        key=lambda s: int(s.split('_')[1].split('.')[0])
    )

    summary = []
    for fname in step_files:
        step = int(fname.split('_')[1].split('.')[0])
        print(f"[HOLONOMY] Step {step}")

        # Load agents from checkpoint
        path = os.path.join(checkpoint_dir, fname)
        with open(path, 'rb') as handle:
            data = pickle.load(handle)
        if isinstance(data, tuple) and len(data) == 2:
            agents, _ = data
        else:
            agents = data

        # Compute H depending on loop type
        if loop_type == 'spatial':
            # sample a self-avoiding loop within the agent's mask
            mask = agents[single_agent_id].mask
            coords = sample_self_avoiding_loop_within_mask(
                center      = spatial_center,
                mask        = mask,
                min_length  = spatial_size,
                max_length  = spatial_size,
                support_cutoff = support_cutoff_eps,
                seed        = step
            )
            H = compute_spatial_loop_holonomy(
                agents[single_agent_id],
                coords,
                generators
            )

        else:  # agent_cycle
            overlaps = []
            for i, j in zip(agent_cycle[:-1], agent_cycle[1:]):
                c = get_overlap_centroid(agents[i], agents[j], domain_size, support_cutoff_eps)
                if c is None:
                    raise RuntimeError(f"No overlap between agents {i} and {j} at step {step}")
                overlaps.append(c)
            H = compute_agent_cycle_holonomy(
                agents,
                agent_cycle,
                overlaps,
                generators
            )

        # Curvature proxy: log-norm deviation from identity
        curvature = norm(logm(H))

        # Save per-step holonomy
        step_dir = os.path.join(holonomy_dir, f'step_{step:04d}')
        os.makedirs(step_dir, exist_ok=True)
        with open(os.path.join(step_dir, 'holonomy.pkl'), 'wb') as out:
            pickle.dump({'H': H, 'curvature': curvature, 'coords': coords}, out)

        summary.append((step, curvature))

    # Write summary CSV
    summary_path = os.path.join(holonomy_dir, 'summary.csv')
    with open(summary_path, 'w', newline='') as csvfile:
        writer = csv.writer(csvfile)
        writer.writerow(['step', 'curvature'])
        for row in summary:
            writer.writerow(row)

    print(f"[✓] Holonomy pipeline complete. Results in: {holonomy_dir}")

if __name__ == '__main__':
    run_holonomy_pipeline()
