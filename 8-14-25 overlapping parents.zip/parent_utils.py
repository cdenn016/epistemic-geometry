# -*- coding: utf-8 -*-
"""
Created on Thu Aug 14 09:35:09 2025

@author: chris and christine
"""
from typing import Dict, List, Optional, Tuple
import numpy as np
import config
from agent_schema import Agent
from runtime_context import runtime_ctx

from numerical_utils import resize_nn

#used all over
def _dilate_bool(mask: np.ndarray, r: int, periodic: bool) -> np.ndarray:
    """Binary dilation by r px, optional periodic wrapping."""
    if r <= 0:
        return mask.astype(bool)
    try:
        from scipy.ndimage import binary_dilation
        se = np.ones((2*r + 1, 2*r + 1), dtype=bool)
        if not periodic:
            return binary_dilation(mask.astype(bool), structure=se)
        H, W = mask.shape
        T = np.tile(mask.astype(bool), (3, 3))
        Td = binary_dilation(T, structure=se)
        return Td[H:2*H, W:2*W]
    except Exception:
        # fallback: cheap square foot-print without SciPy
        m = mask.astype(bool)
        for _ in range(r):
            up    = np.pad(m[1: , : ], ((0,1),(0,0)))
            down  = np.pad(m[:-1, : ], ((1,0),(0,0)))
            left  = np.pad(m[: , 1: ], ((0,0),(0,1)))
            right = np.pad(m[: , :-1], ((0,0),(1,0)))
            m = m | up | down | left | right
        if periodic:
            # wrap edges once (approximate)
            m[0, :]  |= m[-1, :]
            m[-1, :] |= m[0, :]
            m[:, 0]  |= m[:, -1]
            m[:, -1] |= m[:, 0]
        return m


#growth
def binary_dilate_3x3(x: np.ndarray) -> np.ndarray:
    x = np.asarray(x, bool); H, W = x.shape
    y = np.zeros((H, W), bool)
    for di in (-1, 0, 1):
        for dj in (-1, 0, 1):
            y |= np.pad(x, 1)[1+di:1+di+H, 1+dj:1+dj+W]
    return y

#growth
def binary_erode_3x3(x: np.ndarray) -> np.ndarray:
    x = np.asarray(x, bool); H, W = x.shape
    y = np.ones((H, W), bool)
    for di in (-1, 0, 1):
        for dj in (-1, 0, 1):
            y &= np.pad(x, 1)[1+di:1+di+H, 1+dj:1+dj+W]
    return y

#growth
def _logistic(x, tau, kappa):
    """
    Stable sigmoid around threshold tau with slope governed by kappa.
    Accepts arrays; returns array in [0,1].
    """
    x = np.asarray(x, np.float64)
    z = (x - float(tau)) / max(float(kappa), 1e-6)
    z = np.clip(z, -60.0, 60.0)
    return 1.0 / (1.0 + np.exp(-z))




#everywhere
# --- replace in parent_utils.py ---
def child_activity_map(
    ch, H, W,
    # belief (q) thresholds (kept for backward compat with detector call)
    mu_tau=1e-3, trsig_tau=1e-3,
    # misc
    eps=1e-6,
    # model (p) thresholds (None ⇒ pull from config or fall back to q thresholds)
    mu_tau_p=None, trsig_tau_p=None,
    # mixing controls (None ⇒ pull from config)
    mix_mode=None,                 # 'weighted_or' | 'and' | 'or' | 'model_only' | 'belief_only'
    w_model=None, w_belief=None,   # weights for 'weighted_or'
    score_tau=None                 # threshold for 'weighted_or'
):
    
    """
        Compute a per-pixel *activity* mask for a child agent by combining the
        agent's binary support mask with fiber-specific strength tests on the
        belief (q) and model (p) fields.
        
        The result is a boolean array `activity[y, x]` that says whether this
        child should count as *active* at pixel (y, x) for detection/coverage.
        
        Activity logic:
        1) **Mask gate** (always): pixel is eligible iff `mask > eps`.
        2) **Fiber strength** (optional): for each available fiber, compute
           - `mu_mag = ||mu||`  (L2 over last dim if vector-valued; abs if scalar)
           - `trsig  = tr(Sigma)` (trace if matrix-valued; value if scalar)
           The fiber is "strong" at a pixel if `(mu_mag > mu_tau*) OR (trsig > trsig_tau*)`.
        3) **Mixing** (configurable): combine belief/model strength maps using one of:
           - `"weighted_or"` (default): `score = w_model*model + w_belief*belief`,
             mark active if `score >= score_tau`.
           - `"and"`:       active iff both fibers (when present) are strong.
                           (Missing fiber counts as True so it doesn't disable.)
           - `"or"`:        active iff any available fiber is strong.
                           (Missing fiber counts as False.)
           - `"model_only"`: use model strength if present, else fall back to belief.
           - `"belief_only"`: use belief strength if present, else fall back to model.
        Finally, activity is `mask_ok & mixed_strength`.
        
        Shapes & types are lenient:
        - `mask`: (H,W) or broadcastable; resized to `(H, W)` if needed.
        - `mu_q_field`: (H,W,Kq) or (H,W)  ; `sigma_q_field`: (H,W,Kq,Kq) or (H,W)
        - `mu_p_field`: (H,W,Kp) or (H,W)  ; `sigma_p_field`: (H,W,Kp,Kp) or (H,W)
        Resizing uses nearest-neighbor.
        
        Parameters
        ----------
        ch : object
            Child agent with attributes: `mask`, and optionally
            `mu_q_field`, `sigma_q_field`, `mu_p_field`, `sigma_p_field`.
        H, W : int
            Target canvas height/width for the detector.
        mu_tau : float, optional
            Belief (q) threshold for `||mu_q||`. Default `1e-3`.
        trsig_tau : float, optional
            Belief (q) threshold for `tr(sigma_q)`. Default `1e-3`.
        eps : float, optional
            Mask cutoff; pixels with `mask <= eps` are always inactive. Default `1e-6`.
        mu_tau_p : float or None, optional
            Model (p) threshold for `||mu_p||`. If None, taken from
            `config.activity_mu_tau_p` or falls back to `mu_tau`.
        trsig_tau_p : float or None, optional
            Model (p) threshold for `tr(sigma_p)`. If None, taken from
            `config.activity_trsig_tau_p` or falls back to `trsig_tau`.
        mix_mode : {"weighted_or","and","or","model_only","belief_only"} or None
            How to combine belief/model strength maps. If None, taken from
            `config.activity_mix_mode` (default "weighted_or").
        w_model, w_belief : float or None
            Weights used when `mix_mode == "weighted_or"`. If None, pulled from
            `config.activity_model_weight` / `config.activity_belief_weight`
            (defaults 0.85 / 0.15).
        score_tau : float or None
            Threshold for the weighted score when `mix_mode == "weighted_or"`.
            If None, pulled from `config.activity_score_tau` (default 0.5).
        
        Returns
        -------
        activity : np.ndarray of bool, shape (H, W)
            Per-pixel activity mask: True where the child counts toward coverage.
            If both fibers are missing, this reduces to the mask gate `mask > eps`.
            If `mask` is missing on `ch`, returns `None` (detector will then fall
            back to `mask > detector_mask_tau`).
        
        Notes
        -----
        - This function **does not mutate** `ch`. It only reads fields.
        - If only one fiber is present, mixing rules degrade gracefully:
          `"and"` treats a missing fiber as True; `"or"` treats it as False;
          `"model_only"` / `"belief_only"` fall back to the available fiber.
        - Complexity is O(H*W*K) where K is the fiber dimension; fully vectorized.
        
        Examples
        --------
        # Strictly model-driven activity:
        act = child_activity_map(ch, H, W, mix_mode="model_only")
        
        # Weighted mix favoring models:
        act = child_activity_map(ch, H, W, w_model=0.9, w_belief=0.1, score_tau=0.4)
        
        # Belief-only with tighter thresholds:
        act = child_activity_map(ch, H, W, mix_mode="belief_only",
                                 mu_tau=1e-2, trsig_tau=1e-2)
        """

    try:
        import config  # read knobs if present; avoids hard dep at import time
    except Exception:
        config = None

    # --- mask gate (always required) ---
    m = getattr(ch, "mask", None)
    if m is None:
        return None
    m = np.asarray(m)
    if m.shape[:2] != (H, W):
        m = resize_nn(m, (H, W))
    m_ok = (m > eps)

    # --- fetch fields ---
    mu_q, Sig_q = getattr(ch, "mu_q_field", None), getattr(ch, "sigma_q_field", None)
    mu_p, Sig_p = getattr(ch, "mu_p_field", None), getattr(ch, "sigma_p_field", None)

    # fast path: only mask known
    if ((mu_q is None or Sig_q is None) and (mu_p is None or Sig_p is None)):
        return m_ok

    # --- default thresholds & mix from config (if provided) ---
    if mu_tau_p is None:
        mu_tau_p = float(getattr(config, "activity_mu_tau_p", mu_tau if config else mu_tau))
    if trsig_tau_p is None:
        trsig_tau_p = float(getattr(config, "activity_trsig_tau_p", trsig_tau if config else trsig_tau))

    if mix_mode is None:
        mix_mode = getattr(config, "activity_mix_mode", "weighted_or")
    if w_model is None:
        w_model = float(getattr(config, "activity_model_weight", 0.8))
    if w_belief is None:
        w_belief = float(getattr(config, "activity_belief_weight", 0.2))
    if score_tau is None:
        score_tau = float(getattr(config, "activity_score_tau", 0.5))

    # --- per-fiber strength (boolean maps) ---
    def _strength(mu, Sig, mu_thr, tr_thr):
        mu = np.asarray(mu); Sig = np.asarray(Sig)
        if mu.shape[:2] != (H, W):  mu = resize_nn(mu, (H, W))
        if Sig.shape[:2] != (H, W): Sig = resize_nn(Sig, (H, W))
        mu_mag = np.sqrt((mu**2).sum(-1)) if mu.ndim == 3 else np.abs(mu).astype(np.float32)
        trsig  = np.trace(Sig, axis1=-2, axis2=-1) if Sig.ndim == 4 else Sig.astype(np.float32)
        return (mu_mag > float(mu_thr)) | (trsig > float(tr_thr))

    b = _strength(mu_q, Sig_q, mu_tau, trsig_tau) if (mu_q is not None and Sig_q is not None) else None
    p = _strength(mu_p, Sig_p, mu_tau_p, trsig_tau_p) if (mu_p is not None and Sig_p is not None) else None

    # --- combine belief/model according to mix_mode ---
    if mix_mode == "model_only":
        act_core = p if p is not None else (b if b is not None else False)
    elif mix_mode == "belief_only":
        act_core = b if b is not None else (p if p is not None else False)
    elif mix_mode == "and":
        act_core = (b if b is not None else True) & (p if p is not None else True)
    elif mix_mode == "or":
        act_core = (b if b is not None else False) | (p if p is not None else False)
    else:
        # 'weighted_or': treat booleans as 0/1, threshold weighted sum
        b_f = b.astype(np.float32) if b is not None else 0.0
        p_f = p.astype(np.float32) if p is not None else 0.0
        score = w_model * p_f + w_belief * b_f
        act_core = (score >= float(score_tau))

    return m_ok & act_core



# --- blended agreement maps for spawn ---------------------------------------
# Put near the top of parent_utils.py (after imports)
  # uses generators_q/p under the hood

def _compute_blended_agreement_maps(children, child_ids, *, generators_q=None, generators_p=None,
                                    tau_q=0.20, tau_p=0.20):
    """
    Return (A_maps, joint_maps) keyed by (gid_a, gid_b), where
      A = w*A_model + (1-w)*A_belief and A_* = exp(-KL/τ) on the overlap.
    The blend-weight w comes from config.parent_model_vs_belief_w (default 0.7).
    Falls back gracefully if one side is unavailable.
    """
    import numpy as np, config
    from detector import compute_pairwise_agreement_maps
    ids = sorted(set(int(i) for i in child_ids))
    kids = [children[i] for i in ids]   # local list
    if not kids:
        return {}, {}

    # compute A and joint for q and/or p
    A_q, J_q = {}, {}
    A_p, J_p = {}, {}

    if generators_q is not None:
        _, A_loc, J_loc = compute_pairwise_agreement_maps(kids, tau=tau_q, field="q", generators=generators_q)
        # re-key from local (i,j) to global (gid_i,gid_j)
        for (i,j), Aij in A_loc.items():
            key = (ids[i], ids[j])
            A_q[key] = Aij
            J_q[key] = J_loc[(i,j)]

    if generators_p is not None:
        _, A_loc, J_loc = compute_pairwise_agreement_maps(kids, tau=tau_p, field="p", generators=generators_p)
        for (i,j), Aij in A_loc.items():
            key = (ids[i], ids[j])
            A_p[key] = Aij
            J_p[key] = J_loc[(i,j)]

    # choose available modalities
    w = float(getattr(config, "parent_model_vs_belief_w", 0.7))  # model heavier by default
    A_blend, J_blend = {}, {}
    keys = set(A_q.keys()) | set(A_p.keys())
    for key in keys:
        Aq = A_q.get(key, None)
        Ap = A_p.get(key, None)
        if (Aq is None) and (Ap is None):
            continue
        if (Aq is None):
            A_blend[key] = Ap
            J_blend[key] = J_p[key]
        elif (Ap is None):
            A_blend[key] = Aq
            J_blend[key] = J_q[key]
        else:
            # union of overlaps; where both exist, blend; where only one exists, use it
            J = (J_q[key] | J_p[key])
            A = np.zeros_like(Aq, dtype=np.float32)
            both = (J_q[key] & J_p[key])
            only_q = (J_q[key] & ~J_p[key])
            only_p = (J_p[key] & ~J_q[key])
            if np.any(both):   A[both]   = (1.0 - w)*Aq[both] + w*Ap[both]
            if np.any(only_q): A[only_q] = Aq[only_q]
            if np.any(only_p): A[only_p] = Ap[only_p]
            A_blend[key] = A
            J_blend[key] = J

    return A_blend, J_blend










#preant spawn============================================================



def _iou_bool(a: np.ndarray, b: np.ndarray) -> float:
    inter = (a & b).sum()
    union = (a | b).sum()
    return float(inter) / max(1, int(union))

def _too_close_by_iou(comp: np.ndarray, existing_bool_masks: List[np.ndarray], *, iou_thr: float) -> bool:
    for pb in existing_bool_masks:
        if _iou_bool(comp, pb) >= float(iou_thr):
            return True
    return False

def _components(candidate_map: np.ndarray, *, min_area: int) -> List[Tuple[int, Tuple[float,float], np.ndarray]]:
    """Return components as (area, (cy,cx), mask) sorted by area desc."""
    labels, ncc = _label4(candidate_map.astype(bool))
    if ncc == 0:
        return []
    comps = []
    for c in range(1, ncc + 1):
        comp = (labels == c)
        area = int(comp.sum())
        if area < int(min_area):
            continue
        ys, xs = np.nonzero(comp)
        comps.append((area, (float(ys.mean()), float(xs.mean())), comp))
    comps.sort(key=lambda t: t[0], reverse=True)
    return comps


def _ensure_parent_store(ctx):
    """Normalize ctx.parents_by_region → Dict[int, Parent]."""
    if not hasattr(ctx, "parents_by_region") or ctx.parents_by_region is None:
        ctx.parents_by_region = {}
    if isinstance(ctx.parents_by_region, list):
        ctx.parents_by_region = {int(getattr(p, "id", i)): p for i, p in enumerate(ctx.parents_by_region)}
    return ctx.parents_by_region


def _compute_candidate_or_union(P, agents, H=None, W=None, dtype=np.float32, field_generators=None):
    # candidate from agreement
    cand = _compute_parent_candidate(P, agents, field_generators)
    # (you can keep your existing union fallback if cand is empty)
    if cand is None or not np.any(cand > 0):
        # fallback: keep current mask (or a gentle union of children)
        return np.asarray(getattr(P, "mask", 0.0), dtype=np.float32)
    return cand.astype(np.float32)



# BEFORE (inside parent_utils._compute_parent_candidate)
# A_maps, joint_maps = {}, {}
# m = build_parent_mask_from_group(children, child_ids, A_maps, joint_maps, ...)

# AFTER
def _compute_parent_candidate(P, agents, field_generators=None):
    import numpy as np, config
    child_ids = list(getattr(P, "child_ids", []))
    if not child_ids:
        return np.zeros_like(P.mask, dtype=np.float32)

    Gq = Gp = None
    if field_generators is not None:
        Gq, Gp = field_generators

    # try blended agreement; if generators missing, fall back later
    try:
        A_maps, joint_maps = _compute_blended_agreement_maps(
            agents, child_ids,
            generators_q=Gq, generators_p=Gp,
            tau_q=float(getattr(config, "tau_align_emergent_q", 0.20)),
            tau_p=float(getattr(config, "tau_align_emergent_p", 0.20)),
        )
    except Exception:
        A_maps, joint_maps = {}, {}

    if not A_maps:
        # Fallback: cached KL → A = exp(-KL/τ), joint = mask overlap
        tau = float(getattr(config, "tau_align_emergent_fallback", 0.30))
        A_maps, joint_maps = {}, {}
        ids = sorted(set(int(i) for i in child_ids))
        for a_i in range(len(ids)):
            ia = ids[a_i]
            ma = (np.asarray(agents[ia].mask) > 1e-6)
            Kla = getattr(agents[ia], "cached_alignment_kl", None)
            for b_i in range(a_i+1, len(ids)):
                ib = ids[b_i]
                mb = (np.asarray(agents[ib].mask) > 1e-6)
                J  = (ma & mb)
                if not np.any(J): continue
                key = (ia, ib)
                klb = getattr(agents[ib], "cached_alignment_kl", None)
                # if neither cached, skip
                if Kla is None and klb is None: 
                    continue
                # simple symmetric mean if both available, else use the one we have
                if Kla is not None and klb is not None:
                    k = 0.5*(np.asarray(Kla) + np.asarray(klb))
                else:
                    k = np.asarray(Kla) if Kla is not None else np.asarray(klb)
                k = k.astype(np.float32)
                a = np.zeros_like(k, dtype=np.float32)
                a[J] = np.exp(-np.clip(k[J], 0, 10.0)/tau)
                A_maps[key] = a
                joint_maps[key] = J

    # strict core agreement → smooth mask
    m = build_parent_mask_from_group(
        agents, child_ids,
        A_maps, joint_maps,
        tau=float(getattr(config, "parent_agree_tau", 0.20)),
        m_core=int(getattr(config, "parent_core_degree", 3)),
        A_min=int(getattr(config, "parent_agree_area_min", 20)),
        soft=True,
        smooth_iters=int(getattr(config, "parent_mask_smooth_iters", 1)),
    )
    return m



def _growth_gate_from_overlap_core_activity(P, agents, H, W, eps, grow_min_kids):
    
    # overlap count
    cnt = np.zeros((H, W), np.int32)
    active_union = np.zeros((H, W), bool)
    for i in getattr(P, "child_ids", []):
        ch = agents[i]
        a = child_activity_map(ch, H, W, eps=eps)
        if a is None: continue
        active_union |= a
        cnt += (a & (np.asarray(ch.mask) > eps)).astype(np.int32)
    gate = np.ones((H, W), np.float32)
    if grow_min_kids > 0:
        gate *= np.clip(cnt.astype(np.float32) / float(grow_min_kids), 0.0, 1.0)
    # distance to core
    if getattr(P, "_core_map", None) is not None and P._core_map.any():
        dt = cheap_dt(P._core_map.astype(bool))
        r = float(getattr(config, "parent_core_decay_px", 6.0))
        gate *= np.exp(-dt / max(r, 1.0)).astype(np.float32)
    # activity
    gate *= active_union.astype(np.float32)
    return np.clip(gate, 0.0, 1.0)





def _should_reseed(P, cand):
    reseed_period = getattr(config, "parent_reseed_period", 0)
    if reseed_period <= 0: return False
    if (getattr(runtime_ctx, "global_step", 0) % reseed_period) != 0: return False
    def _iou(a, b, thr=1e-3):
        A = (a > thr); B = (b > thr); inter = (A & B).sum(); union = (A | B).sum()
        return float(inter) / max(1, int(union))
    return _iou(P.mask, cand, thr=1e-3) < float(getattr(config, "parent_reseed_iou", 0.30))



#=========================================================================






#INTERNAL HERE
def cheap_dt(core_bool: np.ndarray, cap_steps: int = 32) -> np.ndarray:
    H, W = core_bool.shape
    dt = np.full((H, W), np.inf, np.float32)
    front = core_bool.astype(bool); d = 0.0
    while front.any() and d < cap_steps:
        dt[front] = np.minimum(dt[front], d)
        new = (front | np.roll(front,1,0) | np.roll(front,-1,0) |
                      np.roll(front,1,1) | np.roll(front,-1,1))
        front = new & (~np.isfinite(dt)); d += 1.0
    return dt


def build_parent_mask_from_group(
    children,
    child_ids,
    A_maps,          # from compute_pairwise_agreement_maps (or blended helper)
    joint_maps,      # same keying as A_maps
    *,
    tau=0.2,         # A = exp(-KL/tau) → KL < tau ≈ A >= e^-1 threshold
    m_core=3,        # need ≥ m_core children mutually agreeing at a pixel
    A_min=200,       # min total soft area to accept the seed
    soft=True,
    smooth_iters=0,
    # --- NEW shaping knobs (optional) ---
    consensus="mean",     # 'mean' | 'geo'  (mask consensus)
    mask_power=1.0,       # raise consensus^mask_power
    agreement_power=1.0,  # raise A_mean^agreement_power
    normalize="clip",     # 'clip' | 'max' | 'q99' | 'none'
    periodic=None,        # None → read config.periodic_domain
    _eps=1e-8,
):
    """
    Build a parent seed from a group of children using *mutual agreement* and
    *mask consensus*.  Soft seed at pixel (y,x) is:

        soft(y,x) = 1_{in_core} * [ A_mean(y,x)^{agreement_power} * M_cons(y,x)^{mask_power} ]

    where:
      • in_core   : at least m_core children, each agreeing with ≥ (m_core-1) others
      • A_mean    : mean pairwise agreement over agreeing pairs at that pixel (∈[0,1])
      • M_cons    : child-mask consensus at that pixel (∈[0,1])

    Notes:
      - Agreement threshold uses A_thresh = exp(-1) so “agree” ≈ KL < tau.
      - Shapes are taken from child masks; no mutation of inputs.
      - Result is smooth but *data-shaped* (not circular), especially with smooth_iters>0.
    """
    import numpy as np
    try:
        import config
        if periodic is None:
            periodic = bool(getattr(config, "periodic_domain", True))
    except Exception:
        if periodic is None:
            periodic = True

    if not child_ids:
        return None

    # --- canvas shape ---
    H, W = np.asarray(children[child_ids[0]].mask).shape[:2]
    Cg   = len(child_ids)

    # --- accumulate pairwise agreement (only where both masks are on) ---
    A_sum = np.zeros((H, W), dtype=np.float32)    # sum over agreeing pairs
    pairN = np.zeros((H, W), dtype=np.int32)      # count of agreeing pairs
    deg   = np.zeros((Cg, H, W), dtype=np.int16)  # per-child degree at each pixel

    a_thresh = float(np.exp(-1.0))  # KL < tau  <=>  exp(-KL/tau) > e^-1

    for a in range(Cg):
        ia = child_ids[a]
        for b in range(a + 1, Cg):
            ib = child_ids[b]
            key = (ia, ib) if ia < ib else (ib, ia)
            A_ij = A_maps.get(key, None)
            J    = joint_maps.get(key, None)
            if A_ij is None or J is None:
                continue

            A_ij = np.asarray(A_ij, dtype=np.float32)
            agree = (A_ij >= a_thresh) & np.asarray(J, dtype=bool)
            if not np.any(agree):
                continue

            A_sum[agree] += A_ij[agree]
            pairN[agree] += 1
            deg[a][agree] += 1
            deg[b][agree] += 1

    # If no agreeing pairs anywhere → empty seed
    if int(pairN.sum()) == 0:
        return np.zeros((H, W), dtype=np.float32)

    # --- mutual-agreement core: pixels where ≥ m_core children have degree ≥ m_core-1 ---
    core_children = (deg >= (m_core - 1))    # (Cg,H,W) bool
    core_count    = core_children.sum(axis=0)
    in_core       = (core_count >= int(m_core))   # (H,W) bool

    # --- mean agreement over agreeing pairs ---
    A_mean = np.zeros((H, W), dtype=np.float32)
    nz = pairN > 0
    A_mean[nz] = A_sum[nz] / np.maximum(pairN[nz], 1)

    if agreement_power != 1.0:
        A_mean = np.clip(A_mean, 0.0, 1.0) ** float(agreement_power)

    # --- mask consensus over the group's children (in [0,1]) ---
    #     mean: soft average; geo: geometric mean (emphasizes unanimous support)
    m_stack = []
    for cid in child_ids:
        m = np.asarray(children[cid].mask, dtype=np.float32)
        if m.shape[:2] != (H, W):
            # if you have a local resize_nn, prefer that; this keeps it local
            m = np.array(m, copy=False).astype(np.float32)
        m_stack.append(np.clip(m, 0.0, 1.0))
    M = np.stack(m_stack, axis=0) if m_stack else np.zeros((1, H, W), np.float32)

    if consensus == "geo":
        # geometric mean: exp(mean(log(m+eps)))
        M_cons = np.exp(np.mean(np.log(np.clip(M, _eps, 1.0)), axis=0))
    else:
        # default: arithmetic mean
        M_cons = M.mean(axis=0)

    if mask_power != 1.0:
        M_cons = np.clip(M_cons, 0.0, 1.0) ** float(mask_power)

    # --- soft seed = (agreement × consensus) on the mutual-agreement core ---
    soft_mask = np.where(in_core, A_mean * M_cons, 0.0).astype(np.float32)

    # --- optional smoothing (small, edge-aware by periodic mode) ---
    if smooth_iters > 0:
        k = np.array([[1,1,1],
                      [1,2,1],
                      [1,1,1]], dtype=np.float32)
        k /= k.sum()
        for _ in range(int(smooth_iters)):
            if periodic:
                pad_mode, pad_kw = "wrap", {}
            else:
                pad_mode, pad_kw = "edge", {}
            pad = np.pad(soft_mask, 1, mode=pad_mode, **pad_kw)
            sm  = (
                k[0,0]*pad[:-2, :-2] + k[0,1]*pad[:-2,1:-1] + k[0,2]*pad[:-2,2:] +
                k[1,0]*pad[1:-1, :-2] + k[1,1]*pad[1:-1,1:-1] + k[1,2]*pad[1:-1,2:] +
                k[2,0]*pad[2:,  :-2] + k[2,1]*pad[2:, 1:-1] + k[2,2]*pad[2:,  2:]
            )
            soft_mask = sm.astype(np.float32)

    # --- normalization (keeps soft in [0,1] without forcing circles) ---
    if normalize == "max":
        m = float(soft_mask.max())
        if m > _eps:
            soft_mask = soft_mask / m
    elif normalize == "q99":
        q = float(np.quantile(soft_mask, 0.99))
        if q > _eps:
            soft_mask = np.clip(soft_mask / q, 0.0, 1.0)
    elif normalize == "clip":
        soft_mask = np.clip(soft_mask, 0.0, 1.0)
    # else 'none': leave raw

    # --- area guard (use soft mass; change to (soft_mask>thr).sum() if you prefer) ---
    if float(soft_mask.sum()) < float(A_min):
        return np.zeros((H, W), dtype=np.float32)

    return soft_mask if soft else (soft_mask > 0.5).astype(np.float32)






#used a LOT
def ensure_hw(mask, HW, *, reduce="max"):
    """
    Return a (H, W) float32 mask in [0,1].
    - Squeezes singleton axes.
    - Collapses any trailing stacks (H,W,M,...) via max or mean.
    - Resizes to (H,W) if needed (nn).
    """
    import numpy as np
    H, W = HW
    m = np.asarray(mask, np.float32)
    
    if m.size == 0 or m.ndim < 2:
    # create a blank mask
        return np.zeros((H, W), np.float32)

    # squeeze singletons
    while m.ndim > 0 and m.shape[-1] == 1:
        m = np.squeeze(m, axis=-1)
    if m.ndim == 3 and m.shape[0] == 1:
        m = np.squeeze(m, axis=0)
    # collapse stacks (H,W,M,...) -> (H,W)
    if m.ndim > 2:
        m = m.reshape(m.shape[0], m.shape[1], -1)
        if reduce == "max":
            m = m.max(axis=-1)
        elif reduce == "mean":
            m = m.mean(axis=-1)
        else:
            raise ValueError(f"reduce must be 'max' or 'mean', got {reduce}")
    
    
    # resize if needed
    if m.shape != (H, W):
        from parent_mask_utils import resize_nn  # already in your repo
        m = resize_nn(m, (H, W)).astype(np.float32)
    return np.clip(m, 0.0, 1.0)


#growth and detector
def _label4(binary_mask: np.ndarray):
    """
    4-connected component labeling.
    Returns (labels:int32[H,W], n_components:int)
    """
    H, W = binary_mask.shape
    labels = np.zeros((H, W), dtype=np.int32)
    vid = 0
    # neighbors: up, left
    for y in range(H):
        for x in range(W):
            if not binary_mask[y, x]:
                continue
            up  = labels[y-1, x] if y > 0 else 0
            left= labels[y, x-1] if x > 0 else 0
            if up == 0 and left == 0:
                vid += 1
                labels[y, x] = vid
            elif up != 0 and left == 0:
                labels[y, x] = up
            elif up == 0 and left != 0:
                labels[y, x] = left
            else:
                # merge: relabel one component to the other (path compression lite)
                a, b = (up, left) if up < left else (left, up)
                labels[y, x] = a
                if a != b:
                    labels[labels == b] = a
    # compact labels to 1..n
    uniq = np.unique(labels)
    uniq = uniq[uniq != 0]
    remap = {v:i+1 for i,v in enumerate(uniq)}
    for v, i in remap.items():
        labels[labels == v] = i
    return labels, len(uniq)


#used in growth
try:
    from scipy.ndimage import binary_dilation as _dilate, binary_erosion as _erode
    _HAS_SCIPY = True
except Exception:
    _HAS_SCIPY = False

def _ring_masks(core_bool, grow_band=1, shrink_band=1):
    """
    Build outer (growth) and inner (shrink) ring masks around a boolean core.
    Returns (outer_ring_bool, inner_ring_bool), each shape (H,W).
    """
    core_bool = np.asarray(core_bool, dtype=bool)

    if _HAS_SCIPY:
        og = core_bool.copy()
        for _ in range(max(1, int(grow_band))):
            og = _dilate(og, iterations=1, border_value=0)
        outer = og & (~core_bool)

        ig = core_bool.copy()
        for _ in range(max(1, int(shrink_band))):
            ig = _erode(ig, iterations=1, border_value=0)
        inner = core_bool & (~ig)
        return outer, inner

    # ---- NumPy fallback (4-neighborhood) ----
    def _dilate4(b):
        up    = np.pad(b[1: , : ], ((0,1),(0,0)))
        down  = np.pad(b[:-1, : ], ((1,0),(0,0)))
        left  = np.pad(b[: , 1: ], ((0,0),(0,1)))
        right = np.pad(b[: , :-1], ((0,0),(1,0)))
        return b | up | down | left | right

    def _erode4(b):
        up    = np.pad(b[1: , : ], ((0,1),(0,0)), constant_values=False)
        down  = np.pad(b[:-1, : ], ((1,0),(0,0)), constant_values=False)
        left  = np.pad(b[: , 1: ], ((0,0),(0,1)), constant_values=False)
        right = np.pad(b[: , :-1], ((0,0),(1,0)), constant_values=False)
        return b & up & down & left & right

    og = core_bool.copy()
    for _ in range(max(1, int(grow_band))):
        og = _dilate4(og)
    outer = og & (~core_bool)

    ig = core_bool.copy()
    for _ in range(max(1, int(shrink_band))):
        ig = _erode4(ig)
    inner = core_bool & (~ig)
    return outer, inner






#used for spawn
def _new_parent(pid, H, W, dtype, Kq, Kp, proposal):
    zeros3 = np.zeros((H, W, 3), dtype=dtype)
    eye_q = np.tile(np.eye(Kq, dtype=dtype), (H, W, 1, 1))
    eye_p = np.tile(np.eye(Kp, dtype=dtype), (H, W, 1, 1))
    P = Agent(
        id=pid, center=(0,0), radius=0.0, mask=np.zeros((H,W), dtype=dtype),
        mu_q_field=np.zeros((H,W,Kq), dtype=dtype), sigma_q_field=eye_q.copy(),
        mu_p_field=np.zeros((H,W,Kp), dtype=dtype), sigma_p_field=eye_p.copy(),
        phi=zeros3.copy(), phi_model=zeros3.copy(), neighbors=[]
    )
    P.level = 1
    P.birth_step = getattr(runtime_ctx, "global_step", 0)
    P.lambda_q_weight = 0.0; P.lambda_p_weight = 0.0
    P._region_proposal = np.clip(proposal, 0.0, 1.0).astype(dtype)
    P.emerged = False; P._prev_eval_mask = None
    P._emerge_on_cnt = 0; P._emerge_off_cnt = 0; P._core_map = None
    return P


def _dedup_peaks_by_childset(peaks, *, radius_px=3, j_thr=0.92, subset_thr=0.80):
    """Keep one proposal per local neighborhood when child sets are near-identical
       or one is (almost) a subset of the other. Prefer higher score."""
    import numpy as np
    kept = []
    r2 = float(radius_px * radius_px)

    def _near(C, D):
        if not C and not D: return True
        if not C or not D:  return False
        inter = len(C & D)
        if inter == 0: return False
        j = inter / float(len(C | D))
        if j >= float(j_thr): return True
        # subset-like (one covers ≥ subset_thr of the other)
        sub = min(inter / float(len(C)), inter / float(len(D)))
        return sub >= float(subset_thr)

    for pk in sorted(peaks or [], key=lambda d: -d.get("score", 0.0)):
        C = set(pk.get("child_ids", ()))
        cy, cx = float(pk.get("cy", 0.0)), float(pk.get("cx", 0.0))
        replace_i = None
        dup = False
        for i, q in enumerate(kept):
            dy = cy - float(q["cy"]); dx = cx - float(q["cx"])
            if dy*dy + dx*dx > r2:
                continue
            D = set(q.get("child_ids", ()))
            if _near(C, D):
                # keep the better one (higher score, then larger coalition)
                if float(pk.get("score", 0.0)) > float(q.get("score", 0.0)) or len(C) > len(D):
                    replace_i = i
                dup = True
                break
        if dup and replace_i is not None:
            kept[replace_i] = pk
        elif not dup:
            kept.append(pk)
    return kept

def _dedup_groups_by_childset(groups, *, radius_px=3, j_thr=0.92, subset_thr=0.90):
    """
    Collapse groups that have (a) near-identical child sets or (b) one is
    (almost) a subset of another within a small spatial radius.
    Keep the group with: higher 'score' if present, else larger coalition, else larger area.
    """
    import numpy as np

    def _center(mask_bool):
        ys, xs = np.nonzero(mask_bool)
        return (float(ys.mean()), float(xs.mean())) if ys.size else (1e9, 1e9)

    kept = []
    r2 = float(radius_px * radius_px)

    for g in groups:
        C = set(g.get("child_ids", ()))
        if not C:  # ignore empty
            continue
        cy, cx = _center(np.asarray(g["mask"], bool))
        area = int(np.count_nonzero(g["mask"]))
        score = float(g.get("score", 0.0))

        replaced = False
        for i, h in enumerate(kept):
            hy, hx = h["_cy"], h["_cx"]
            dy, dx = cy - hy, cx - hx
            if dy*dy + dx*dx > r2:
                continue

            D = set(h["child_ids"])
            inter = len(C & D)
            if inter == 0:
                continue

            # near-identical?
            j = inter / float(len(C | D))
            # subset-like (one covers >= subset_thr of the other)
            sub = max(inter / float(len(C)), inter / float(len(D)))

            if (j >= float(j_thr)) or (sub >= float(subset_thr)):
                # choose winner
                def _key(obj, coalition):
                    return (float(obj.get("score", 0.0)),
                            len(coalition),
                            int(np.count_nonzero(obj["mask"])))
                if _key(g, C) > _key(h, D):
                    kept[i] = {**g, "_cy": cy, "_cx": cx}
                replaced = True
                break

        if not replaced:
            kept.append({**g, "_cy": cy, "_cx": cx})

    # strip helpers
    for k in kept:
        k.pop("_cy", None); k.pop("_cx", None)
    return kept



#used all over....refactor suite to imp-lement automatically/consistently
def _as_parent_dict(obj):
    """
    Normalize parents -> {pid: Parent}. Accepts dict, list, iterable, or None.
    Uses the parent's .id if present; else falls back to enumerate index.
    """
    import collections.abc as _abc
    if obj is None:
        return {}
    if isinstance(obj, dict):
        return {int(getattr(p, "id", pid)): p for pid, p in obj.items()}
    if isinstance(obj, _abc.Iterable):
        return {int(getattr(p, "id", i)): p for i, p in enumerate(obj)}
    # Single parent object?
    return {int(getattr(obj, "id", 0)): obj}



#only for spawn
def _build_child_groups(region_masks, agents, HW, *, child_eps, min_child_area, intra_iou_thr, min_group_kids):
    """Return list[{'mask': bool(H,W), 'child_ids': tuple[int]}]."""
    
    H, W = HW
    groups = []
    for Rmask in region_masks:
        cmasks, cids = [], []
        for idx, C in enumerate(agents):
            M = ensure_hw(getattr(C, "mask", 0.0), (H, W)) > child_eps
            M &= Rmask
            if np.count_nonzero(M) >= min_child_area:
                cmasks.append(M); cids.append(int(getattr(C, "id", idx)))
        n = len(cmasks)
        if n == 0:
            continue
        # build adjacency by IoU
        adj = [set() for _ in range(n)]
        for i in range(n):
            for j in range(i+1, n):
                U = cmasks[i] | cmasks[j]
                if not U.any(): 
                    continue
                inter = np.count_nonzero(cmasks[i] & cmasks[j])
                iou_ij = inter / float(np.count_nonzero(U))
                if iou_ij >= intra_iou_thr:
                    adj[i].add(j); adj[j].add(i)
        # connected components
        seen = [False]*n
        for i in range(n):
            if seen[i]: continue
            q=[i]; seen[i]=True; comp=[i]
            while q:
                u=q.pop()
                for v in adj[u]:
                    if not seen[v]:
                        seen[v]=True; q.append(v); comp.append(v)
            gids=[cids[k] for k in comp]
            if len(gids) < min_group_kids:
                continue
            gmask = np.zeros((H,W), bool)
            for k in comp: gmask |= cmasks[k]
            groups.append({"mask": gmask, "child_ids": tuple(sorted(gids))})
    return groups




#only for spawn
def _find_group_peaks(groups, agents, HW, *, peak_min_cons, peak_nms_r, peak_max_per_gp, min_group_kids, child_eps, seed_halo_px):
    """Yield dicts with fields: cy,cx,score, child_ids, proposal."""
    
    H, W = HW
    out = []
    # tiny NMS helper (square radius)
    def _nms_coords(ys, xs, scores, r, max_keep):
        order = np.argsort(-scores)
        kept, out_ix = [], []
        r2 = max(1, r)**2
        for k in order:
            y, x, s = int(ys[k]), int(xs[k]), float(scores[k])
            ok = True
            for (py, px) in kept:
                if (py - y)**2 + (px - x)**2 < r2:
                    ok = False; break
            if ok:
                kept.append((y, x)); out_ix.append(k)
            if len(out_ix) >= max_keep: break
        return out_ix

    for G in groups:
        # stack kids’ masks
        stack = []
        for kid in G["child_ids"]:
            C = next((A for A in agents if int(getattr(A, "id", -1)) == int(kid)), None)
            if C is None: continue
            stack.append(ensure_hw(getattr(C, "mask", 0.0), (H, W)).astype(np.float32))
        if not stack: continue
        S = np.stack(stack, axis=-1)                        # (H,W,#kids)
        cons = S.mean(axis=-1)                              # agreement 0..1
        count = (S > child_eps).sum(axis=-1)
        cons[count < min_group_kids] = 0.0
        # restrict search to group halo
        halo = _dilate_bool(G["mask"].astype(bool), r=max(1, seed_halo_px), periodic=bool(getattr(config, "periodic_domain", False)))
        cons *= halo.astype(np.float32)
        # threshold & NMS
        keep = cons >= float(peak_min_cons)
        ys, xs = np.nonzero(keep)
        if ys.size == 0: continue
        idx = _nms_coords(ys, xs, cons[keep], peak_nms_r, peak_max_per_gp)
        for k in idx:
            cy, cx = float(ys[k]), float(xs[k])
            # small local proposal (disk clip)
            yy, xx = np.ogrid[:H, :W]
            d2 = (yy - int(round(cy)))**2 + (xx - int(round(cx)))**2
            local = (d2 <= (max(1, seed_halo_px*seed_halo_px))).astype(np.float32)
            proposal = (cons * local)
            if proposal.max() > 0: proposal /= (proposal.max() + 1e-8)
            out.append({"cy":cy, "cx":cx, "score":float(cons[int(cy),int(cx)]),
                        "child_ids": list(G["child_ids"]),
                        "proposal": proposal.astype(np.float32)})
    return out

            


#only for spawn
def _compute_core_from_kids(P, agents, H, W, eps):
    
    cover = np.zeros((H, W), np.int32); weight = np.zeros((H, W), np.float32)
    kl_sum = np.zeros((H, W), np.float32); kl_cnt = np.zeros((H, W), np.int32)
    for i in getattr(P, "child_ids", []):
        ch = agents[i]; m = np.asarray(ch.mask)
        if m.shape != (H, W): m = resize_nn(m, (H, W))
        a = child_activity_map(ch, H, W, eps=eps)
        if a is None: continue
        inside = a & (m > eps)
        cover += inside.astype(np.int32); weight += m.astype(np.float32) * inside.astype(np.float32)
        k = getattr(ch, "cached_alignment_kl", None)
        if k is None: continue
        k = np.asarray(k); 
        if k.shape != (H, W): continue
        good = inside & np.isfinite(k)
        kl_sum[good] += k[good].astype(np.float32); kl_cnt[good] += 1
    keep = (cover >= int(getattr(config, "core_min_kids", 2))) & (weight >= float(getattr(config, "core_weight_tau", 0.6)))
    kl_mean = kl_sum / np.maximum(kl_cnt, 1); kl_mean[kl_cnt == 0] = np.inf
    keep &= (kl_mean <= float(getattr(config, "core_kl_tau", getattr(config, "tau_align_emergent", 0.30))))
    # tiny erosion
    e = keep.copy()
    e = (e & np.roll(e,1,0) & np.roll(e,-1,0) & np.roll(e,1,1) & np.roll(e,-1,1))
    return e






def _too_similar_children(A_ids, B_ids, thr=0.9):
    A, B = set(A_ids), set(B_ids)
    if not A or not B: 
        return False
    j = len(A & B) / float(len(A | B))
    return j >= float(thr)

def _dist2_toroidal(y1, x1, y2, x2, H, W, per_y=False, per_x=False):
    import numpy as np
    dy = abs(float(y1) - float(y2))
    dx = abs(float(x1) - float(x2))
    if per_y: dy = min(dy, H - dy)
    if per_x: dx = min(dx, W - dx)
    return dy*dy + dx*dx

def _centroid_toroidal(mask_bool, H, W, per_y=False, per_x=False):
    """Centroid on a torus using circular means (avoids wrap splits)."""
    import numpy as np
    m = np.asarray(mask_bool, bool)
    if not m.any():
        return (1e9, 1e9)
    yy, xx = np.nonzero(m)
    w = np.ones_like(yy, float)
    # X centroid
    if per_x:
        theta = 2*np.pi*(xx / float(W))
        cx = (np.arctan2(np.sum(np.sin(theta)*w), np.sum(np.cos(theta)*w)) % (2*np.pi)) * (W/(2*np.pi))
    else:
        cx = float(xx.mean())
    # Y centroid
    if per_y:
        phi = 2*np.pi*(yy / float(H))
        cy = (np.arctan2(np.sum(np.sin(phi)*w), np.sum(np.cos(phi)*w)) % (2*np.pi)) * (H/(2*np.pi))
    else:
        cy = float(yy.mean())
    return (float(cy), float(cx))









