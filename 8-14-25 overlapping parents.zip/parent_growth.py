# -*- coding: utf-8 -*-
"""
Created on Mon Aug 11 17:58:13 2025

@author: chris and christine
"""

import config
from numerical_utils import resize_nn
import numpy as np
from parent_utils import ensure_hw,_ring_masks, _logistic






def apply_parent_growth(runtime_ctx, growth_maps, *, 
                        eta_grow=0.75, eta_shrink=0.10,
                        min_area=10, max_area=None,
                        delta_cap=None,           # kept for back-compat; ignored if parent_max_step_delta is set
                        blur_iters=1):
    """
    Mutating stage: given dict[pid] -> (grow_field, shrink_field), update masks.
    Uses ring-masked fields; applies masked blur, locality, ramp/freeze, and per-step clamps.
    """
    import numpy as np
    from scipy.ndimage import gaussian_filter

    parents = getattr(runtime_ctx, "parents_by_region", {})
    if not parents:
        return

    # prefer the live-updater clamp; fall back to provided delta_cap
    max_step = float(getattr(config, "parent_max_step_delta", 0.10 if delta_cap is None else delta_cap))
    local_rad = int(getattr(config, "parent_local_radius_px", 0))
    far_decay = float(getattr(config, "parent_far_decay", 1.0))
    core_tau  = float(getattr(config, "parent_growth_core_tau", 0.15))
    nb_freeze = int(getattr(config, "parent_freeze_steps", 0))
    nb_ramp   = int(getattr(config, "parent_ramp_steps", 0))
    floor_eps = float(getattr(config, "parent_floor_eps", 1e-8))
    masked_blur = bool(getattr(config, "growth_masked_blur", True))

    for pid, P in parents.items():
        if pid not in growth_maps:
            continue

        m = np.asarray(P.mask, np.float32)
        H, W = m.shape[:2]
        grow_field, shrink_field = growth_maps[pid]
        grow_field   = np.asarray(grow_field,   np.float32)
        shrink_field = np.asarray(shrink_field, np.float32)

        # newborn freeze/ramp
        age = int(getattr(P, "_age", 0))
        if age < nb_freeze:
            # skip updates during freeze
            continue
        ramp_scale = 1.0 if nb_ramp <= 0 else min(1.0, (age - nb_freeze + 1) / float(nb_ramp))

        # locality mask (dilate current support by local_rad)
        if local_rad > 0:
            core = (m > core_tau)
            try:
                from scipy.ndimage import binary_dilation, generate_binary_structure
                st = generate_binary_structure(2, 1)
                loc = core.copy()
                for _ in range(local_rad):
                    loc = binary_dilation(loc, structure=st, border_value=0)
            except Exception:
                # simple 4-neighborhood fallback
                loc = core.copy()
                for _ in range(local_rad):
                    loc |= (np.roll(loc,1,0)|np.roll(loc,-1,0)|np.roll(loc,1,1)|np.roll(loc,-1,1))
        else:
            loc = np.ones_like(m, bool)

        # combine fields (already ring-masked upstream)
        dm = ramp_scale * (eta_grow * grow_field - eta_shrink * shrink_field)

        # masked blur (don’t bleed across empty areas)
        if blur_iters and blur_iters > 0:
            if masked_blur:
                mask_mb = ((grow_field > 0) | (shrink_field > 0)).astype(np.float32)
                num = gaussian_filter(dm * mask_mb, blur_iters, mode="nearest")
                den = gaussian_filter(mask_mb,        blur_iters, mode="nearest")
                dm = np.divide(num, np.maximum(den, 1e-6), out=np.zeros_like(num), where=(den>0))
            else:
                dm = gaussian_filter(dm, blur_iters, mode="nearest")

        # strictly local
        dm *= loc.astype(np.float32)

        # per-pixel clamp
        dm = np.clip(dm, -max_step, max_step)

        # apply delta
        m_new = np.clip(m + dm, 0.0, 1.0)

        # optional far-field decay (suppresses tails)
        if far_decay < 1.0:
            outside = ~loc
            m_new[outside] *= far_decay

        # floor → clean dust
        if floor_eps > 0.0:
            m_new[m_new < floor_eps] = 0.0

        # area guards (binary area at 0.5 for diagnostics)
        prev_area = int((m > 0.5).sum())
        new_area  = int((m_new > 0.5).sum())
        net_dm    = float(dm.mean())

        skip = False
        if (max_area is not None) and (new_area > float(max_area)):
            skip = True
        if (new_area < float(min_area)) and (net_dm <= 0.0) and (age >= nb_ramp):
            skip = True

        if getattr(config, "debug_growth_probe", True) and (age <= 2):
            print(f"[APPLY/PROBE pid={int(getattr(P,'id',-1))}] "
                  f"net_dm={net_dm:.4f} prevA={prev_area} newA={new_area} skip={skip}")

        if skip:
            continue

        # commit
        P.mask = m_new.astype(P.mask.dtype)

       


def compute_parent_growth_maps_pure(runtime_ctx, children, *,
                                    tau_grow=0.30, tau_shrink=0.18,
                                    kappa=0.05, grow_band=1, shrink_band=1,
                                    mask_tau=0.30):
    """
    Return dict[pid] -> (grow_field, shrink_field), each (H,W) in [0,1].
    For each parent:
      1) core := (parent_mask > mask_tau) [looser for age==0 if needed]
      2) outer/inner ring masks from core
      3) signal := per-parent field in [0,1] (agreement/KL/coverage)
      4) g_raw := signal * outer_ring,  s_raw := (1 - signal) * inner_ring
      5) tau_g/tau_s: numeric or 'pXX' percentiles of the ring values
      6) kappa: numeric or 'auto' = 0.25 * IQR of ring values
      7) grow := outer_ring * logistic(g_raw; tau_g,kappa)
         shrink := inner_ring * logistic(s_raw; tau_s,kappa)
    """
    if not getattr(runtime_ctx, "parents_by_region", None):
        return {}

    H, W = np.asarray(children[0].mask).shape[:2]

    # global fallback coverage
    global_cov = np.zeros((H, W), np.float32)
    for c in children:
        global_cov = np.maximum(global_cov, ensure_hw(getattr(c, "mask", 0.0), (H, W)))

    out = {}

    def _parse_tau(spec, vals, fb):
        v = np.asarray(vals, np.float64)
        v = v[np.isfinite(v)]
        try:
            if isinstance(spec, str):
                s = spec.strip().lower()
                if s.startswith("p"):
                    pct = float(s[1:])
                    return float(np.percentile(v, pct)) if v.size else float(fb)
                return float(s)
            return float(spec)
        except Exception:
            return float(fb)

    def _parse_kappa(spec, vals, fb):
        v = np.asarray(vals, np.float64)
        v = v[np.isfinite(v)]
        if isinstance(spec, str) and spec.strip().lower() == "auto":
            if v.size:
                q75, q25 = np.percentile(v, [75, 25])
                return float(max(1e-6, 0.25 * (q75 - q25)))
            return float(fb)
        try:
            return float(spec)
        except Exception:
            return float(fb)

    signal_mode = getattr(config, "parent_growth_signal", "auto")  # "auto"|"kl"|"agree"|"coverage"

    for pid, P in runtime_ctx.parents_by_region.items():
        pm = ensure_hw(getattr(P, "mask", 0.0), (H, W))
        core = (pm > float(mask_tau))
        if not np.any(core) and int(getattr(P, "_age", 0)) == 0:
            loose = float(getattr(config, "parent_newborn_core_tau", 0.05))
            core = (pm > loose)
        if not np.any(core):
            continue

        # per-parent signal from labeled kids (else global coverage)
        sig = _extract_per_parent_signal(pid, children, H, W, mode=signal_mode)
        if sig is None:
            sig = global_cov
        sig = np.clip(np.asarray(sig, np.float32), 0.0, 1.0)

        outer_ring, inner_ring = _ring_masks(core, grow_band, shrink_band)

        # raw ring values
        g_raw = sig * outer_ring.astype(np.float32)          # [0,1] on outer ring
        s_raw = (1.0 - sig) * inner_ring.astype(np.float32)  # [0,1] on inner ring

        g_vals = g_raw[outer_ring]
        s_vals = s_raw[inner_ring]
        vals_for_kappa = (np.concatenate([g_vals, s_vals]) if (g_vals.size and s_vals.size)
                          else (g_vals if g_vals.size else s_vals))

        tau_g = _parse_tau(tau_grow,  g_vals, 0.30)
        tau_s = _parse_tau(tau_shrink, s_vals, 0.18)
        kap   = _parse_kappa(kappa,    vals_for_kappa, 0.05)

        if getattr(config, "debug_growth_probe", False) and (int(getattr(P, "_age", 0)) <= 2):
            print(f"[GROW/PROBE pid={int(getattr(P,'id',-1))}] "
                  f"core={int(core.sum())} outer={int(outer_ring.sum())} inner={int(inner_ring.sum())} "
                  f"gmax={float(g_raw.max()) if g_vals.size else 0.0:.3f} "
                  f"smax={float(s_raw.max()) if s_vals.size else 0.0:.3f} "
                  f"tau_g={tau_g:.3f} tau_s={tau_s:.3f} kappa={kap:.3f}")

        # logistic → re-mask to rings (ensures 0 outside rings)
        grow_field   = outer_ring.astype(np.float32) * _logistic(g_raw, tau=tau_g, kappa=kap).astype(np.float32)
        shrink_field = inner_ring.astype(np.float32) * _logistic(s_raw, tau=tau_s, kappa=kap).astype(np.float32)

        out[int(pid)] = (grow_field, shrink_field)

    return out





# ---------- main seeding function -------------------------------------------





# --- helpers ---------------------------------------------------------------






def _child_is_labeled_to(child, pid):
    """Robustly detect if a child is assigned to parent pid (supports multiple schemas)."""
    if getattr(child, "parent_id", None) == pid: return True
    if getattr(child, "assigned_parent", None) == pid: return True
    lab = getattr(child, "label", None)
    if isinstance(lab, (tuple, list, set)) and pid in lab: return True
    if isinstance(lab, (int, np.integer)) and lab == pid: return True
    labs = getattr(child, "labels", None)
    if isinstance(labs, dict) and pid in labs: return True
    return False

def _extract_per_parent_signal(pid, children, H, W, *, mode="auto"):
    """
    Per-parent growth signal in [0,1], shape (H,W), using ONLY children labeled to `pid`.

    Preference (within labeled kids):
      1) Agreement field  A(x)  (higher is better)
      2) KL field         KL(x) → A(x) = exp(-clip(KL,0,cap)/tau)
      3) Coverage         C(x)  = mask-consensus of labeled kids

    In (1) and (2), the returned signal is:   S(x) = A(x) * [Consensus(x)]^gamma
    where Consensus(x) is a (weighted) mean of child masks at (x), ensuring locality.

    Returns
    -------
    np.ndarray (H,W) float32 in [0,1], or None if no labeled kids exist.
    """
    import numpy as np

    # --- collect labeled kids ---
    labeled = [c for c in children if _child_is_labeled_to(c, pid)]
    if not labeled:
        return None  # caller will fall back to global coverage

    # knobs (re-use your existing spawn knobs for consistency)
    tau_kl   = float(getattr(config, "tau_align_p", 0.45))            # τ for exp(-KL/τ)
    kl_cap   = float(getattr(config, "signal_kl_cap", 10.0))          # cap KL before exp
    gamma    = float(getattr(config, "signal_consensus_gamma", 1.0))  # power on consensus [0.5..2]
    reduce_mode = getattr(config, "signal_reduce_mode", "weighted_mean")  # 'weighted_mean'|'max'|'mean'

    # helper to ensure (H,W)
    def _hw(a):
        a = ensure_hw(a, (H, W), reduce="mean")
        return np.asarray(a, np.float32)

    # build mask consensus (locality)
    m_sum = np.zeros((H, W), np.float32)
    w_sum = np.zeros((H, W), np.float32)

    def _w_for(child):
        # prefer child.labels dict written by the soft assignment
        labs = getattr(child, "labels", {}) or {}
        if isinstance(labs, dict) and pid in labs:
            return float(labs[pid])
        # fallback to 1.0 if older single-parent paths are used
        return 1.0

    masks = []
    for c in labeled:
        w = max(0.0, _w_for(c))
        if w <= 0.0:  # skip zero-weight kids
            continue
        m = _hw(getattr(c, "mask", 0.0))
        masks.append(m)
        m_sum += (w * m)
        w_sum += w

    if len(masks) == 0:
        return None

    consensus = np.divide(m_sum, np.maximum(w_sum, 1e-6), out=np.zeros_like(m_sum), where=(w_sum>0))
    if gamma != 1.0:
        consensus = np.clip(consensus, 0.0, 1.0) ** max(0.0, gamma)

    # AGREEMENT accumulation now also weight-scales contributions:
    A_accum, W_accum = None, None
    def _accumulate_agree(field, weight_map):
        nonlocal A_accum, W_accum
        if field is None: return
        f = _hw(field)
        w = _hw(weight_map)
        A_accum = f*w if A_accum is None else (A_accum + f*w)
        W_accum = w   if W_accum is None else (W_accum + w)

    # (1) dedicated per-parent agreement maps on the child
    for c in labeled:
        w = max(0.0, _w_for(c))
        if w <= 0.0: continue
        amap = getattr(c, "agreement_to_parent", None)
        if isinstance(amap, dict) and pid in amap:
            # weight by both assignment and child support
            _accumulate_agree(amap[pid], w * _hw(getattr(c, "mask", 0.0)))

    # (2) generic child.agreement_field fallback
    if A_accum is None:
        for c in labeled:
            w = max(0.0, _w_for(c))
            if w <= 0.0: continue
            a = getattr(c, "agreement_field", None)
            if a is not None:
                _accumulate_agree(a, w * _hw(getattr(c, "mask", 0.0)))
    # --------------------------------------------------------------------------
    # 2) KL path → convert to agreement via exp(-KL/τ)
    KL_accum = None
    Wk_accum = None

    def _accumulate_kl(field, weight):
        nonlocal KL_accum, Wk_accum
        k = _hw(field)
        w = _hw(weight)
        if reduce_mode == "max":
            K = k if KL_accum is None else np.minimum(KL_accum, k)  # "best" (lowest KL)
            KL_accum, Wk_accum = K, None
        elif reduce_mode == "mean":
            KL_accum = k if KL_accum is None else (KL_accum + k)
            Wk_accum = 1.0 if Wk_accum is None else (Wk_accum + 1.0)
        else:  # weighted_mean (default)
            KL_accum = (k * w) if KL_accum is None else (KL_accum + k * w)
            Wk_accum = w if Wk_accum is None else (Wk_accum + w)

    for c in labeled:
        kd = getattr(c, "kl_to_parent", None)
        if isinstance(kd, dict) and (pid in kd):
            _accumulate_kl(kd[pid], getattr(c, "mask", 0.0))
        else:
            fld = getattr(c, "kl_field", None)
            if fld is not None:
                _accumulate_kl(fld, getattr(c, "mask", 0.0))

    if KL_accum is not None and (mode in ("auto", "kl")):
        if reduce_mode == "mean":
            KL = KL_accum / max(Wk_accum, 1e-6)
        elif reduce_mode == "weighted_mean":
            KL = np.divide(KL_accum, np.maximum(Wk_accum, 1e-6), out=np.zeros_like(KL_accum), where=(Wk_accum>0))
        else:  # max/min semantics handled above
            KL = KL_accum

        KL = np.clip(KL, 0.0, float(kl_cap))
        A  = np.exp(-KL / max(1e-6, tau_kl))  # same transform as spawning
        S  = np.clip(A * np.clip(consensus, 0.0, 1.0), 0.0, 1.0)
        return S.astype(np.float32)

    # --------------------------------------------------------------------------
    # 3) Coverage fallback (no agreement/KL available yet)
    return np.clip(consensus, 0.0, 1.0).astype(np.float32)




