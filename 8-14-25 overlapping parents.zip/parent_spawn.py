# -*- coding: utf-8 -*-
"""
Created on Thu Aug 14 09:17:47 2025

@author: chris and christine
"""

import numpy as np
import config
from runtime_context import runtime_ctx


from parent_utils import ( _as_parent_dict,  _ensure_parent_store, _components, 
                           _too_close_by_iou,_build_child_groups, _find_group_peaks, _new_parent)
                         
from bundle_morphism_utils import (init_parent_morphisms, have_parent_morphisms, 
                                    compute_direct_morphisms  )

from agent_initialization import initialize_agent_gradients

from parent_utils import (ensure_hw, _dilate_bool, _compute_candidate_or_union, 
                          _growth_gate_from_overlap_core_activity, _should_reseed, 
                          _dedup_peaks_by_childset, _dedup_groups_by_childset) 
                              
from bundle_coarsegrain_init import coarsegrain_parent_from_children, _refresh_parent_gauge_fields
from numerical_utils import resize_nn


def _match_or_spawn(peaks, parents_by_id, next_parent_id, agents, shape_info, generators, *,
                    match_iou_thr, child_jac_thr, support_tau, max_new_per_step, min_interseed_px):
    """Update/Spawn parents from peak/proposal dicts.
       - Match first (IoU & child-set Jaccard), spacing is enforced only for *new* spawns.
       - Spacing is child-set aware: co-located spawns are allowed when coalitions differ.
    """
    import numpy as np
    try:
        import config
    except Exception:
        class _C: pass
        config = _C()

    # ---- local imports to avoid module coupling issues ----
    from parent_utils import ensure_hw
    try:
        # prefer canonical location
        from parent_spawn import _make_parent_template
    except Exception:
        # fallback if utils re-export it
        from parent_utils import _make_parent_template

    # ---- try to get runtime_ctx safely (do not hard-require) ----
    try:
        _RC = globals().get("runtime_ctx", None)
    except Exception:
        _RC = None

    H, W, dtype, Kq, Kp = shape_info
    Gq, Gp = generators

    def _iou(a, b):
        inter = np.count_nonzero(a & b)
        if inter == 0:
            return 0.0
        return inter / float(np.count_nonzero(a | b))

    def _jac(a: set, b: set):
        if not a and not b:
            return 1.0
        if not a or not b:
            return 0.0
        return len(a & b) / float(len(a | b))

    # Cache existing supports/centers/kids
    exists_support = {pid: (ensure_hw(getattr(P, "mask", 0.0), (H, W)) > support_tau)
                      for pid, P in parents_by_id.items()}
    exists_kids = {pid: set(getattr(P, "child_ids", []))
                   for pid, P in parents_by_id.items()}

    chosen_centers = []
    for pid, supp in exists_support.items():
        ys, xs = np.nonzero(supp)
        if ys.size:
            chosen_centers.append((float(ys.mean()), float(xs.mean()), int(pid)))

    # spacing policy: allow co-located spawns when child coalitions differ enough
    def _respect_spacing(cy, cx, gkids_set):
        if not bool(getattr(config, "enforce_spawn_spacing", True)):
            return True
        R  = float(max(1, min_interseed_px)); R2 = R * R
        jac_thr    = float(getattr(config, "spacing_child_jaccard_thr", 0.90))
        subset_thr = float(getattr(config, "spacing_child_subset_thr", 0.90))
        for (py, px, pid_near) in chosen_centers:
            dy, dx = py - cy, px - cx
            if dy*dy + dx*dx >= R2:
                continue
            kids_near = exists_kids.get(pid_near, set())
            inter = len(kids_near & gkids_set)
            if inter == 0:
                continue
            # Jaccard (near-identical)
            j = inter / float(len(kids_near | gkids_set))
            # subset coverage (one covers most of the other)
            sub = max(inter / float(len(kids_near or {1})),
                      inter / float(len(gkids_set or {1})))
            if (j >= jac_thr) or (sub >= subset_thr):
                return False
        return True


    # Debug counters
    updated = spawned = dropped_local = dropped_spacing = dropped_budget = dropped_match = 0

    # Tunables
    local_tau   = float(getattr(config, "parent_proposal_local_tau", 0.10))
    min_seed_px = int(getattr(config, "parent_min_seed_area_px", 6))
    seed_amp    = float(getattr(config, "parent_seed_amp", 0.55))
    seed_sigma  = float(getattr(config, "parent_seed_feather_sigma", 1.0))
    seed_r0     = float(getattr(config, "parent_seed_radius_px", 4.0))
    use_prop_dbg= bool(getattr(config, "debug_seed_use_proposal", False))

    # robust step for birth_step (prefer ctx, fall back to config/global)
    try:
        _step_now = int(getattr(_RC, "global_step", 0))
    except Exception:
        _step_now = int(getattr(config, "global_step", 0)) if hasattr(config, "global_step") else 0

    new_spawned = 0
    for peak in sorted(peaks or [], key=lambda d: -d.get("score", 0.0)):
        if new_spawned >= max_new_per_step:
            dropped_budget += 1
            break

        cy, cx = float(peak["cy"]), float(peak["cx"])
        prop = np.asarray(peak["proposal"], np.float32)

        # local gating
        local_bool = (prop > local_tau)
        area = int(local_bool.sum())
        if area < min_seed_px:
            dropped_local += 1
            continue

        gkids_set = set(peak["child_ids"])


        # --- NEW: require proposal to overlap its own coalition ---
        min_ovlp_px   = int(getattr(config, "parent_min_seed_child_overlap_px", 6))
        min_ovlp_frac = float(getattr(config, "parent_min_seed_child_overlap_frac", 0.10))
        
        # build union-of-children support for this coalition
        child_union = np.zeros((H, W), bool)
        for cid in gkids_set:
            try:
                C = agents[cid]
            except Exception:
                continue
            cm = (ensure_hw(getattr(C, "mask", 0.0), (H, W)) > float(getattr(config, "child_support_tau", 0.10)))
            child_union |= cm
        
        ovlp_px   = int((child_union & local_bool).sum())
        ovlp_frac = (ovlp_px / max(1, int(local_bool.sum())))
        
        if (ovlp_px < min_ovlp_px) or (ovlp_frac < min_ovlp_frac):
            # optional: counter
            try:
                dropped_childov += 1
            except NameError:
                dropped_childov = 1
            continue



        # 1) try to MATCH existing parent (spacing does NOT apply to matches)
        best_pid, best_score = None, (-1.0, -1.0)
        for pid, supp in exists_support.items():
            # distance to its current center
            ys, xs = np.nonzero(supp)
            if ys.size:
                py, px = float(ys.mean()), float(xs.mean())
            else:
                py = px = 1e9
            dy = py - cy; dx = px - cx
            close = (dy*dy + dx*dx) <= float(max(1, min_interseed_px))**2
        
            jac = _jac(gkids_set, exists_kids[pid])
            iou = _iou(local_bool, supp)

        # NEW: if very close and child sets nearly same, accept as a match even with small IoU
            if close and jac >= float(getattr(config, "parent_match_child_jaccard_thr", 0.85)):
                sc = (iou, jac + 1.0)  # nudge score to win over pure-IoU candidates
                if sc > best_score:
                    best_score, best_pid = sc, pid
                continue
        
            if (iou >= match_iou_thr) and (jac >= float(getattr(config, "parent_match_child_jaccard_thr", 0.85))):
                sc = (iou, jac)
                if sc > best_score:
                    best_score, best_pid = sc, pid


        if best_pid is not None:
            P = parents_by_id[int(best_pid)]
            P.child_ids = list(peak["child_ids"])
            P._region_proposal = prop  # one-shot reseed will consume this
            setattr(P, "_force_reseed_once", True)
            updated += 1
            # refresh spacing centroid based on this proposal
            ys, xs = np.nonzero(local_bool)
            if ys.size:
                chosen_centers.append((float(ys.mean()), float(xs.mean()), int(best_pid)))
            else:
                chosen_centers.append((cy, cx, int(best_pid)))
            continue

        # 2) otherwise SPAWN (now spacing applies, but child-set aware)
        if not _respect_spacing(cy, cx, gkids_set):
            dropped_spacing += 1
            continue

        pid = int(next_parent_id)
        next_parent_id += 1

        # create parent object
        P = _make_parent_template(_RC, agents[0], pid=pid, H=H, W=W, Kq=Kq, Kp=Kp,
                                  generators_q=Gq, generators_p=Gp)
        P.child_ids = list(peak["child_ids"])
        P._region_proposal = prop

        # Seed mask
        if use_prop_dbg:
            seed = prop.copy()
        else:
            yy, xx = np.ogrid[:H, :W]
            d2 = (yy - int(round(cy))) ** 2 + (xx - int(round(cx))) ** 2
            seed = np.exp(-0.5 * (d2 / max(1.0, seed_r0 * seed_r0))).astype(np.float32)
            try:
                from scipy.ndimage import gaussian_filter
                seed = gaussian_filter(seed * local_bool.astype(np.float32),
                                       seed_sigma, mode="nearest")
            except Exception:
                seed = seed * local_bool.astype(np.float32)
            mval = float(seed.max())
            if mval > 0:
                seed /= (mval + 1e-8)

        P.mask = np.clip(seed_amp * seed, 0.0, 1.0).astype(dtype)

        # newborn metadata
        P.birth_step = _step_now
        P._age  = 0
        P._grace = int(getattr(config, "parent_freeze_steps", 0))

        parents_by_id[int(pid)] = P
        exists_support[int(pid)] = (P.mask > support_tau)
        exists_kids[int(pid)]    = set(P.child_ids)
        spawned     += 1
        new_spawned += 1

        # spacing bookkeeping for subsequent proposals
        ys, xs = np.nonzero(local_bool)
        if ys.size:
            chosen_centers.append((float(ys.mean()), float(xs.mean()), int(pid)))
        else:
            chosen_centers.append((cy, cx, int(pid)))

    print(f"[SPAWN] updated={updated} spawned={spawned} "
          f"d_local={dropped_local} d_space={dropped_spacing} "
          f"d_childov={locals().get('dropped_childov', 0)} "
          f"d_budget={dropped_budget} d_match={dropped_match}")

    return next_parent_id




def _propose_from_alignment(groups, agents, HW, *, generators_q=None, generators_p=None):
    """
    Build parent proposals directly from kid agreement, per child-group.
    Returns: list of dicts {cy, cx, score, child_ids, proposal}
    """
    import numpy as np
    from parent_utils import _label4, build_parent_mask_from_group
    from detector import compute_pairwise_agreement_maps
    try:
        import config
    except Exception:
        class _C: pass
        config = _C()

    H, W = HW
    out = []

    # knobs (with safe defaults)
    soft_thr   = float(getattr(config, "direct_seed_soft_thr", 0.25))
    min_area   = int(getattr(config, "direct_seed_min_area_px", 12))
    max_per_gp = int(getattr(config, "direct_seed_max_per_group", 3))
    m_core     = int(getattr(config, "direct_seed_m_core", 2))
    A_min      = int(getattr(config, "direct_seed_A_min", 20))
    smooth_it  = int(getattr(config, "direct_seed_smooth_iters", 1))
    alpha      = float(getattr(config, "blend_qp_alpha", 0.5))   # 0.0 = model only, 1.0 = belief only
    tau_q      = float(getattr(config, "tau_align_q", 0.30))
    tau_p      = float(getattr(config, "tau_align_p", 0.30))

    def _mask_to_comps(soft):
        binmap = (soft >= soft_thr)
        labels, nlab = _label4(binmap)
        comps = []
        for lbl in range(1, nlab + 1):
            comp = (labels == lbl)
            if int(comp.sum()) < min_area:
                continue
            s = soft * comp.astype(np.float32)
            ys, xs = np.nonzero(comp)
            w = s[comp]
            if w.size == 0 or float(w.max()) <= 0.0:
                continue
            cy = float((ys * w).sum() / max(w.sum(), 1e-6))
            cx = float((xs * w).sum() / max(w.sum(), 1e-6))
            score = float(w.mean())  # area-weighted mean soft agreement
            # normalize proposal to [0,1] on this component
            prop = s.copy()
            m = float(prop.max())
            if m > 0:
                prop /= m
            comps.append((score, cy, cx, prop))
        comps.sort(key=lambda t: -t[0])
        return comps[:max_per_gp]

    for G in groups:
        try:
            cids = list(G.get("child_ids", ()))
            if not cids:
                continue
            # keep 'kids' in the same order as 'cids' for correct local indexing
            kids = [next((A for A in agents if int(getattr(A, "id", -1)) == int(k)), None) for k in cids]
            kids = [k for k in kids if k is not None]
            if not kids:
                continue

            # pairwise agreement for q and/or p (LOCAL keys (i,j))
            A_q_loc = J_q_loc = A_p_loc = J_p_loc = {}
            if generators_q is not None and alpha > 0.0:
                _, A_maps_q, joint_q = compute_pairwise_agreement_maps(
                    kids, tau=tau_q, field="q", generators=generators_q
                )
                A_q_loc, J_q_loc = A_maps_q, joint_q
            if generators_p is not None and alpha < 1.0:
                _, A_maps_p, joint_p = compute_pairwise_agreement_maps(
                    kids, tau=tau_p, field="p", generators=generators_p
                )
                A_p_loc, J_p_loc = A_maps_p, joint_p

            # re-key LOCAL (i,j) -> GLOBAL (gid_i,gid_j)
            def _remap(A_loc, J_loc):
                A_g, J_g = {}, {}
                for (i, j), Aij in (A_loc or {}).items():
                    gi, gj = int(cids[i]), int(cids[j])
                    key = (gi, gj) if gi < gj else (gj, gi)
                    A_g[key] = Aij
                    J_g[key] = J_loc[(i, j)]
                return A_g, J_g

            A_q, J_q = _remap(A_q_loc, J_q_loc)
            A_p, J_p = _remap(A_p_loc, J_p_loc)

            # blend to GLOBAL-keyed A_blend / J_blend
            A_blend, J_blend = {}, {}
            keys = set(A_q.keys()) | set(A_p.keys())
            for key in keys:
                a_q = A_q.get(key); j_q = J_q.get(key)
                a_p = A_p.get(key); j_p = J_p.get(key)
                if (a_q is not None) and (a_p is not None):
                    A_blend[key] = alpha * a_q + (1.0 - alpha) * a_p
                    # permissive overlap: either fiber overlapping counts
                    J_blend[key] = (j_q | j_p)
                elif a_q is not None:
                    A_blend[key] = a_q; J_blend[key] = j_q
                elif a_p is not None:
                    A_blend[key] = a_p; J_blend[key] = j_p

            # build soft parent mask from blended agreement
            soft = build_parent_mask_from_group(
                children=agents, child_ids=cids,
                A_maps=A_blend, joint_maps=J_blend,
                tau=min(tau_q, tau_p), m_core=m_core,
                A_min=A_min, soft=True, smooth_iters=smooth_it
            )
            if soft is None:
                continue
            soft = np.asarray(soft, np.float32)

            # DEBUG visibility
            try:
                print(f"[DIRECT-SPAWN] group kids={tuple(sorted(cids))} "
                      f"Akeys={len(A_blend)} soft_sum={float(soft.sum()):.1f}")
            except Exception:
                pass

            # componentize soft → proposals and append
            for score, cy, cx, prop in _mask_to_comps(soft):
                out.append({
                    "cy": cy, "cx": cx, "score": score,
                    "child_ids": tuple(sorted(cids)),
                    "proposal": prop.astype(np.float32),
                })
        except Exception as e:
            print(f"[DIRECT-SPAWN][WARN] group {tuple(sorted(G.get('child_ids', ())))} skipped: {e}")
            continue

    return out  # ALWAYS return a list





def _apply_spawn_from_regions(ctx, active_regions, agents, Gq, Gp, params):
    """
    The ONLY place that mutates parents:
      - spawn/update parents for active regions
      - coarse-grain new/updated parents
     
    No preprocess(), no build_all_omega_caches(), no build_all_lambda_caches() here.
    """
    
    # if _as_parent_dict lives elsewhere, import from there; otherwise keep your local helper
    # from detector import _as_parent_dict

    H, W = np.asarray(agents[0].mask).shape[:2]

    # 1) spawn/update from detector-active regions
    parents_list, next_pid = spawn_or_update_parents(
        active_regions=active_regions,
        agents=agents,
        parents_by_id=ctx.parents_by_region,
        next_parent_id=ctx.next_parent_id,
        field_generators=(Gq, Gp),
    )
    parents = _as_parent_dict(parents_list)

    # normalize & insert; coarsegrain immediately so masks/Σ are usable
    existing = ctx.parents_by_region
    prev_ids = set(existing.keys())

    for pid, P in parents.items():
        pid = int(getattr(P, "id", pid))
        existing[pid] = P
        if not hasattr(P, "_age"):   P._age = 0
        if not hasattr(P, "_grace"): P._grace = int(getattr(config, "parent_freeze_steps", 0))
        try:
            cg_eps = float(getattr(config, "cg_eps", 1e-6))
            cg_tau = float(getattr(config, "parent_cover_support_eps", 0.30))
            coarsegrain_parent_from_children(P, agents, eps=cg_eps, mask_tau=cg_tau)
            if bool(getattr(config, "debug_strict", True)):
                for name in ("sigma_q_field", "sigma_p_field"):
                    S = getattr(P, name, None)
                    if S is None:
                        continue
                    S = np.asarray(S)
                    assert S.ndim == 4 and S.shape[-1] == S.shape[-2], \
                        f"[CG->ASSIGN] {name} bad shape {S.shape} for parent {getattr(P,'id','?')}"
        except Exception as e:
            print(f"[WARN] coarsegrain/init failed for parent {getattr(P,'id','?')}: {e}")
            if getattr(config, "debug_parent_masks", False):
                print("  parent.mask", np.asarray(P.mask).shape)
                print("  child0.mask", np.asarray(agents[0].mask).shape)

    # registry bookkeeping
    ctx.parents_by_region = existing
    ctx.next_parent_id = max(
        int(ctx.next_parent_id),
        int(next_pid),
        (max(existing.keys()) + 1) if existing else 1
    )

    # --- visibility: log new parents from detector phase
    new_ids = sorted(set(existing.keys()) - prev_ids)
    if new_ids:
        areas = [int((np.asarray(existing[i].mask) > 0.5).sum()) for i in new_ids]
        print(f"[SPAWN] +{len(new_ids)} (detector): ids={new_ids} areas={areas}")

    



# --- spawn_or_update_parents (refactored) ------------------------------------
# --- spawn_or_update_parents (overlap-ready) ------------------------------------
def spawn_or_update_parents(active_regions, agents, parents_by_id, next_parent_id, *, field_generators):
    """
    Pipeline:
      0) normalize inputs
      1) group children by ALIGNMENT inside each active region (allow >1 group at same pixel)
      2) compute per-group consensus & local peaks (NMS) OR direct-from-alignment proposals
      3) match proposals to existing parents (IoU + child-set jaccard), else spawn
      4) init/ensure morphisms
      5) optional reseed/rehome to proposal
    Returns (list(parents_by_id.values()), next_parent_id)
    """
    import numpy as np
    import config
    from parent_utils import ensure_hw, _build_child_groups  # fallback grouper
    from parent_utils import _compute_blended_agreement_maps

    Gq, Gp = field_generators
    if not agents:
        return list(parents_by_id.values()), next_parent_id

    H, W   = np.asarray(agents[0].mask).shape[:2]
    dtype  = agents[0].mu_q_field.dtype
    Kq     = int(agents[0].mu_q_field.shape[-1])
    Kp     = int(agents[0].mu_p_field.shape[-1])
    eps    = float(getattr(config, "support_cutoff_eps", 1e-6))

    # 0) Normalize active_regions
    region_masks = _norm_active_regions(active_regions, (H, W))

    # -----------------------------
    # 1) CLUSTER BY ALIGNMENT (new)
    # -----------------------------
    use_align_clusters = bool(getattr(config, "use_alignment_clusters", True))
    allow_overlap      = bool(getattr(config, "parent_allow_overlap", True))

    child_eps         = float(getattr(config, "child_support_tau", 0.10))
    min_child_area    = int(getattr(config, "min_child_area_px", 6))
    thr_align         = float(getattr(config, "cluster_align_thr", 0.60))  # similarity in [0,1]
    min_cluster_kids  = int(getattr(config, "cluster_min_kids", 1))
    dedup_j_thr       = float(getattr(config, "parent_dedup_child_jaccard", 0.95))

    def _cluster_children_by_alignment(Rmask):
        # collect kids that materially touch the region
        cmasks, cids = [], []
        for idx, C in enumerate(agents):
            M = (ensure_hw(getattr(C, "mask", 0.0), (H, W)) > child_eps) & Rmask
            if int(M.sum()) >= min_child_area:
                cmasks.append(M)
                cids.append(int(getattr(C, "id", idx)))
        n = len(cids)
        if n == 0:
            return []

        # pairwise blended agreement maps keyed by global (gid_i,gid_j)
        A_map, J_map = _compute_blended_agreement_maps(
            agents, cids,
            generators_q=Gq, generators_p=Gp,
            tau_q=float(getattr(config, "tau_align_q", 0.30)),
            tau_p=float(getattr(config, "tau_align_p", 0.30)),
        )

        # build similarity graph from mean agreement in R ∩ supports
        adj = [set() for _ in range(n)]
        for i in range(n):
            for j in range(i + 1, n):
                key = (cids[i], cids[j]) if cids[i] < cids[j] else (cids[j], cids[i])
                Aij = A_map.get(key, None)
                Jij = J_map.get(key, None)
                if Aij is None or Jij is None:
                    continue
                Jloc = (np.asarray(Jij, bool) & cmasks[i] & cmasks[j] & Rmask)
                if not np.any(Jloc):
                    continue
                s = float(np.asarray(Aij, np.float32)[Jloc].mean())  # similarity in [0,1]
                if s >= thr_align:
                    adj[i].add(j); adj[j].add(i)

        # connected components → clusters
        seen = [False] * n
        groups_local = []
        for i in range(n):
            if seen[i]:
                continue
            q = [i]; seen[i] = True; comp = [i]
            while q:
                u = q.pop()
                for v in adj[u]:
                    if not seen[v]:
                        seen[v] = True; q.append(v); comp.append(v)
            if len(comp) < min_cluster_kids:
                continue
            gmask = np.zeros((H, W), bool)
            for k in comp: gmask |= cmasks[k]
            gids  = tuple(sorted(cids[k] for k in comp))
            groups_local.append({"mask": gmask, "child_ids": gids})

        # if nothing connected but singletons are allowed, add them
        if not groups_local and min_cluster_kids <= 1:
            for k in range(n):
                groups_local.append({"mask": cmasks[k], "child_ids": (cids[k],)})

        return groups_local

    if use_align_clusters:
        groups = []
        for Rmask in region_masks:
            groups.extend(_cluster_children_by_alignment(Rmask))

        # de-dup groups by near-identical child sets (keep first)
        kept = []
        for G in groups:
            S = set(G["child_ids"])
            dup = False
            for Hh in kept:
                T = set(Hh["child_ids"])
                j = (len(S & T) / float(len(S | T))) if (S or T) else 1.0
                if j >= dedup_j_thr:
                    dup = True; break
            if not dup:
                kept.append(G)
        groups = kept
    else:
        # Fallback: legacy IoU grouper (previous behavior)
        groups = _build_child_groups(
            region_masks, agents, (H, W),
            child_eps=child_eps,
            min_child_area=min_child_area,
            intra_iou_thr=float(getattr(config, "child_intragroup_iou_thr", 0.55)),
            min_group_kids=int(getattr(config, "parent_grow_min_kids", 2)),
        )  # IoU-based connected components inside region. :contentReference[oaicite:3]{index=3}

        print(f"[SPAWN] groups={len(groups)} (align_clusters={use_align_clusters})\n")

        groups = _dedup_groups_by_childset(
            groups,
            radius_px=int(getattr(config, "parent_group_dedup_radius_px", 3)),
            j_thr=float(getattr(config, "parent_group_dedup_child_jaccard", 0.92)),
            subset_thr=float(getattr(config, "parent_group_dedup_subset_thr", 0.90)),
        )
        print(f"[SPAWN] groups={len(groups)} after group-dedup")
            

    # No fast-exit: even with 0 groups we may still keep existing parents alive.
    if not groups and not parents_by_id:
        return list(parents_by_id.values()), next_parent_id

    # 2) Proposals (direct-from-alignment or legacy peaks)
    if bool(getattr(config, "spawn_direct_from_alignment", True)):
        peaks = _propose_from_alignment(
            groups, agents, (H, W),
            generators_q=(field_generators[0] if field_generators else None),
            generators_p=(field_generators[1] if field_generators else None),
        )
                
        min_peak_score = float(getattr(config, "parent_min_peak_score", 0.0))
        # (keep proposals unless you really want to cull weak ones)
        peaks = [pk for pk in (peaks or []) if float(pk.get("score", 0.0)) >= min_peak_score]


        peaks = _dedup_peaks_by_childset(
            peaks,
            radius_px=int(getattr(config, "parent_peak_dedup_radius_px", 3)),
            j_thr=float(getattr(config, "parent_peak_dedup_child_jaccard", 0.92)),
            subset_thr=float(getattr(config, "parent_peak_dedup_subset_thr", 0.80)),
        )


    else:
        peaks = _find_group_peaks(
            groups, agents, (H, W),
            peak_min_cons=float(getattr(config, "parent_peak_min_consensus", 0.1)),
            peak_nms_r=int(getattr(config, "parent_peak_nms_px", 5)),
            peak_max_per_gp=int(getattr(config, "parent_peak_max_per_group", 3)),
            min_group_kids=int(getattr(config, "seed_min_kids", 2)),
            child_eps=child_eps,
            seed_halo_px=int(getattr(config, "parent_seed_exclusion_px", 3)),
        )
    peaks = peaks or []

    # 3) MATCH or SPAWN
    #    Allow co-located spawns when child sets differ: pass 0 spacing if enabled.
    min_interseed_px = 0 if allow_overlap else int(getattr(config, "parent_min_interseed_px", 1))
    next_parent_id = _match_or_spawn(
        peaks, parents_by_id, next_parent_id, agents, (H,W,dtype,Kq,Kp), (Gq,Gp),
        match_iou_thr=float(getattr(config, "parent_match_iou_existing", 0.10)),
        child_jac_thr=float(getattr(config, "parent_match_child_jaccard_thr", 0.85)),  # <— tighten
        support_tau=float(getattr(config, "parent_support_tau", 0.08)),
        max_new_per_step=int(getattr(config, "parent_max_new_per_step", 50)),
        min_interseed_px=int(getattr(config, "parent_min_interseed_px", 3)),
    )

    # ^ spacing is enforced in _match_or_spawn; by passing 0 we permit overlap. :contentReference[oaicite:4]{index=4}

    # 4) Ensure morphisms present
    parents_list = list(parents_by_id.values())
    for P in parents_list:
        if not have_parent_morphisms(P):
            init_parent_morphisms(P, generators_q=Gq, generators_p=Gp)

    # 5) One-shot reseed/rehome to proposal if requested
    _apply_one_shot_reseed(
        parents_list, dtype,
        seed_amp=float(getattr(config, "parent_seed_amp", 0.55)),
    )

    # Finalize caches
    _refresh_parent_gauge_fields(parents_list, agents, dtype=None)
    for P in parents_list:
        P._exp_phi = P._exp_neg_phi = None
        P._exp_phi_model = P._exp_neg_phi_model = None

    return list(parents_by_id.values()), next_parent_id








def _update_single_parent(P, agents, step_now, H, W, eps, dtype, field_generators=None):
    

    # --- knobs (new ones have safe defaults) --------------------------------
    freeze_steps  = max(0, int(getattr(config, "parent_freeze_steps", 2)))
    ramp_steps    = max(0, int(getattr(config, "parent_ramp_steps", 12)))
    alpha_base    = float(getattr(config, "parent_mask_alpha", 0.10))
    grow_min_kids = int(getattr(config, "parent_grow_min_kids", 2))
    delta_cap     = float(getattr(config, "parent_max_step_delta", 0.1))
    decay_empty   = 0.995
    periodic      = bool(getattr(config, "periodic_domain", False))

    # NEW: what counts as "support" for locality/dilation
    support_tau   = float(getattr(config, "parent_support_tau", 0.05))
    # NEW: local expansion halo around current support
    local_r_px    = int(getattr(config, "parent_local_radius_px", 3))
    # NEW: gently kill any mass far from support
    far_decay     = float(getattr(config, "parent_far_decay", 0.98))  # 1.0 = off
    # NEW: hard floor to zero-out dust
    floor_eps     = float(getattr(config, "parent_floor_eps", 1e-4))

    kids = getattr(P, "child_ids", [])
    # -- seed from core (unchanged) ------------------------------------------
    if (P.mask <= 1e-6).all() and P._core_map is not None and P._core_map.any():
        seed = P._core_map.astype(bool)
        expand_px = max(0, int(getattr(config, "parent_seed_expand_px", 2)))
        if expand_px > 0:
            seed = _dilate_bool(seed, r=expand_px, periodic=periodic)
        P.mask = seed.astype(dtype) * 0.5

    # inside _update_single_parent(...):
    cand = _compute_candidate_or_union(P, agents, H, W, dtype, field_generators=field_generators)


    # emergence gate (unchanged) ---------------------------------------------
    eval_mask = (P.mask > 1e-2)
    if not eval_mask.any():
        if getattr(P, "_region_proposal", None) is not None:
            eval_mask = (np.asarray(P._region_proposal) > 1e-2)
        elif cand is not None:
            eval_mask = (np.asarray(cand) > 1e-2)

    emerged = _emergence_gate(P, agents, eval_mask, H, W, eps)
    P.emerged = bool(emerged)

    if not P.emerged:
        target = None
        if getattr(P, "_region_proposal", None) is not None:
            target = np.asarray(P._region_proposal, dtype=np.float32)
        elif cand is not None:
            target = np.asarray(cand, dtype=np.float32)
        if target is not None:
            alpha_seed = float(getattr(config, "parent_seed_alpha", 0.15))
            pm = P.mask.astype(np.float32)
            P.mask = np.clip((1.0 - alpha_seed) * pm + alpha_seed * target, 0.0, 1.0).astype(dtype)
        return

    # EMA schedule (unchanged) -----------------------------------------------
    age = max(0, int(step_now - getattr(P, "birth_step", step_now)))
    if age < freeze_steps:
        alpha = 0.0
    else:
        denom = max(1, ramp_steps)
        ramp  = min(1.0, max(0.0, (age - freeze_steps) / denom))
        alpha = float(np.clip(alpha_base * ramp, 0.0, alpha_base))

    # no candidate → gentle decay and exit
    if cand is None:
        P.mask = (decay_empty * P.mask).astype(dtype)
        return

    # growth gates ------------------------------------------------------------
    gate = _growth_gate_from_overlap_core_activity(P, agents, H, W, eps, grow_min_kids).astype(np.float32)

    # sanitize candidate
    cand = np.asarray(cand, np.float32)
    cand = np.nan_to_num(cand, nan=0.0, posinf=1.0, neginf=0.0)
    cand = np.clip(cand, 0.0, 1.0)

    

    # bands + locality (CRITICAL change: use support_tau, not 1e-3)
    grow_band = max(1, int(getattr(config, "grow_band", 1)))
    pm       = P.mask.astype(np.float32)
    mask_bin = (pm > support_tau)                         # << was 1e-3
    dil      = _dilate_bool(mask_bin, r=grow_band, periodic=periodic)
    outer    = dil & (~mask_bin)

    # ring boost only on 'outer'
    growth_prob = np.clip(gate, 0.0, 1.0)
    eta_ring    = float(getattr(config, "eta_grow", 0.5))
    ring_target = np.clip(pm + eta_ring * growth_prob, 0.0, 1.0)
    cand        = np.where(outer, np.maximum(cand, ring_target), cand)
    cand        = (cand * growth_prob).astype(np.float32)

    # keep updates local: only chase cand near support
    local = _dilate_bool(mask_bin, r=max(local_r_px, grow_band), periodic=periodic)
    target = pm + growth_prob * (cand - pm)
    target = np.where(local, target, pm)                  # freeze far field

    # snap vs EMA toward target
    if _should_reseed(P, target):
        new_mask = target.astype(np.float32)
    else:
        delta = alpha * (target - pm)
        if delta_cap > 0:
            delta = np.clip(delta, -delta_cap, delta_cap)
        new_mask = np.clip(pm + delta, 0.0, 1.0).astype(np.float32)

    # --- NEW: far-field decay + floor (kills baseline creep) ----------------
    if far_decay < 1.0:
        far = ~_dilate_bool(mask_bin, r=max(local_r_px, grow_band), periodic=periodic)
        # Only decay truly far pixels (avoid touching core/outer)
        new_mask[far] *= far_decay
    if floor_eps > 0.0:
        new_mask[new_mask < floor_eps] = 0.0

    P.mask = new_mask.astype(dtype)
















def _norm_active_regions(active_regions, HW):
    """Return list[(H,W) bool] region masks."""
    
    H, W = HW
    if active_regions is None:
        return []
    if isinstance(active_regions, dict):
        region_objs = [active_regions[k] for k in sorted(active_regions.keys())]
    else:
        region_objs = list(active_regions)
    out = []
    for R in region_objs:
        m = getattr(R, "mask", R)
        m = ensure_hw(m, (H, W)) > 0.0
        out.append(m.astype(bool))
    return out







def _emergence_gate(P, children, eval_mask, H, W, eps):
    """
    Decide whether a parent 'emerges' (becomes active).
    Safe when KL is missing and when emerge_tau=None (disables KL test).
    """
    import numpy as np
    # config knobs
    MIN_AREA   = int(getattr(config, "emerge_min_area", 2))
    MIN_KIDS   = int(getattr(config, "seed_min_kids", 2))
    EMERGE_TAU = getattr(config, "emerge_tau", None)  # may be float or None

    # area gate
    area_ok = bool(np.asarray(eval_mask).sum() >= MIN_AREA)

    # overlap/children gate (count kids active on eval_mask)
    kids_ok = False
    if getattr(P, "child_ids", None):
        cnt = 0
        for i in P.child_ids:
            ch = children[i]
            m = np.asarray(getattr(ch, "mask", 0.0), np.float32)
            if m.shape != (H, W):
                m = resize_nn(m, (H, W))
            # "active" if mask exceeds tiny eps somewhere on eval region
            if ( (m > eps) & eval_mask ).any():
                cnt += 1
        kids_ok = (cnt >= MIN_KIDS)
    else:
        # fallback: if no explicit child_ids tracked, be permissive
        kids_ok = True

    # KL gate (median over eval_mask), but only if any KL exists and EMERGE_TAU is not None
    kl_ok = True
    if EMERGE_TAU is not None:
        kl_vals = []
        for i in getattr(P, "child_ids", range(len(children))):
            ch = children[i] if isinstance(i, int) else i
            k = getattr(ch, "cached_alignment_kl", None)
            if k is None:
                continue
            k = np.asarray(k)
            if k.shape != (H, W):
                k = resize_nn(k, (H, W))
            sel = eval_mask & np.isfinite(k)
            if sel.any():
                kl_vals.append(k[sel])
        if kl_vals:
            vec = np.concatenate(kl_vals).astype(np.float32, copy=False)
            kl_med = float(np.median(vec))
            kl_ok = (kl_med <= float(EMERGE_TAU))
        else:
            # no KL available → skip KL gating
            kl_ok = True

    emerged = bool(area_ok and kids_ok and kl_ok)

    # Optional: latch behavior / hysteresis (preserve once emerged)
    if getattr(P, "emerged", False):
        # you can add a soft condition to keep emerged unless area collapses completely
        if not area_ok:
            return False
        return True

    return emerged



def _make_parent_template(ctx, tmpl, *, pid: int, H: int, W: int, Kq: int, Kp: int,
                          generators_q, generators_p):
    """Construct a brand-new level-1 parent with safe defaults and gradient buffers."""
    import numpy as np

    AgentCls = tmpl.__class__
    dtype = tmpl.mu_q_field.dtype

    # identities, broadcasted (lighter than tile) but materialized via copy
    eye_q = np.broadcast_to(np.eye(Kq, dtype=dtype), (H, W, Kq, Kq)).copy()
    eye_p = np.broadcast_to(np.eye(Kp, dtype=dtype), (H, W, Kp, Kp)).copy()

    P = AgentCls(
        id=pid, center=(0, 0), radius=0.0,
        mask=np.zeros((H, W), np.float32),
        mu_q_field=np.zeros((H, W, Kq), dtype=dtype), sigma_q_field=eye_q,
        mu_p_field=np.zeros((H, W, Kp), dtype=dtype), sigma_p_field=eye_p,
        phi=np.zeros((H, W, 3), dtype=dtype), phi_model=np.zeros((H, W, 3), dtype=dtype),
        neighbors=[]
    )

    P.level = 1
    P.emerged = True
    P._age = 0
    P._grace = int(getattr(config, "parent_grace_steps", 2))
    P._shrink_strikes = 0
    P.Omega_cache = {}; P.Omega_tilde_cache = {}
    P._exp_phi = P._exp_neg_phi = None
    P._exp_phi_model = P._exp_neg_phi_model = None
    P.generators_q = generators_q
    P.generators_p = generators_p

    # Base morphisms
    P.Phi_0       = np.eye(Kp, Kq, dtype=dtype)
    P.Phi_tilde_0 = np.eye(Kq, Kp, dtype=dtype)
    try:
        P.bundle_morphism_q_to_p, P.bundle_morphism_p_to_q = compute_direct_morphisms(
            phi=P.phi, phi_model=P.phi_model,
            generators_q=P.generators_q, generators_p=P.generators_p,
            Phi_0=P.Phi_0, Phi_tilde_0=P.Phi_tilde_0,
        )
    except Exception:
        P.bundle_morphism_q_to_p = np.broadcast_to(P.Phi_0, (H, W, Kp, Kq)).copy()
        P.bundle_morphism_p_to_q = np.broadcast_to(P.Phi_tilde_0, (H, W, Kq, Kp)).copy()

    # Initialize gradient buffers
    initialize_agent_gradients(P)
    
    # --- Guardrails: enforce 4D shapes + SPD once at birth ------------------
    def _spd_tidy(S):
        if S is None: return None
        S = 0.5*(S + np.swapaxes(S, -1, -2))
        K = S.shape[-1]
        return S + (1e-8 * np.eye(K, dtype=S.dtype))
    assert P.sigma_q_field.ndim == 4 and P.sigma_q_field.shape[-1] == P.sigma_q_field.shape[-2], \
        f"sigma_q_field bad shape {P.sigma_q_field.shape}"
    assert P.sigma_p_field.ndim == 4 and P.sigma_p_field.shape[-1] == P.sigma_p_field.shape[-2], \
        f"sigma_p_field bad shape {P.sigma_p_field.shape}"
    P.sigma_q_field = _spd_tidy(P.sigma_q_field)
    P.sigma_p_field = _spd_tidy(P.sigma_p_field)

    P.birth_step = int(getattr(ctx, "global_step", 0))
    return P

















def _ensure_parents_for_regions(active_regions, parents_by_id, next_parent_id, H, W, dtype, Kq, Kp):
    """
    Match current regions to existing parents by IoU. Reuse on good match; else spawn new.
    Returns (rid_to_pid, next_parent_id).
    """
    iou_thr = float(getattr(config, "parent_reuse_iou_min",
                            getattr(config, "parent_reseed_iou", 0.30)))

    if isinstance(active_regions, list):
        # fabricate IDs (0..N-1) if it’s a plain list
        active_regions = {i: R for i, R in enumerate(active_regions)}

    # cache masks
    reg_items = [(rid, np.asarray(R.mask, dtype=bool)) for rid, R in active_regions.items()]
    par_items = [(pid,
                  np.asarray((P._region_proposal if getattr(P, "_region_proposal", None) is not None else P.mask)) > 1e-3)
                 for pid, P in parents_by_id.items()]

    def _iou(A, B):
        inter = np.count_nonzero(A & B)
        if inter == 0: return 0.0
        unio  = np.count_nonzero(A | B)
        return float(inter) / float(unio) if unio else 0.0

    taken_parents = set()
    new_map = {}      # parent_id -> parent
    rid_to_pid = {}   # region id -> parent id

    for rid, Rmask in reg_items:
        best_pid, best_iou = None, 0.0
        for pid, Pmask in par_items:
            if pid in taken_parents:
                continue
            iou = _iou(Rmask, Pmask)
            if iou > best_iou:
                best_iou, best_pid = iou, pid

        if best_pid is not None and best_iou >= iou_thr:
            # reuse
            P = parents_by_id[best_pid]
            P._region_proposal = Rmask.astype(dtype)
            new_map[best_pid] = P
            rid_to_pid[rid] = best_pid
            taken_parents.add(best_pid)
        else:
            # spawn new
            Pnew = _new_parent(next_parent_id, H, W, dtype, Kq, Kp, Rmask.astype(dtype))
            new_map[next_parent_id] = Pnew
            rid_to_pid[rid] = next_parent_id
            next_parent_id += 1

    parents_by_id.clear()
    parents_by_id.update(new_map)
    return rid_to_pid, next_parent_id





def _apply_one_shot_reseed(parents, dtype, *, seed_amp):
    """If a parent was marked for rehome, blend its mask to the proposal once."""
    for P in parents:
        if getattr(P, "_force_reseed_once", False):
            P._force_reseed_once = False
            pm = np.asarray(getattr(P, "mask", 0.0), np.float32)
            prop = np.asarray(getattr(P, "_region_proposal", pm*0), np.float32)
            if prop.max() > 0: prop = prop / (prop.max() + 1e-8)
            P.mask = np.clip(seed_amp * prop, 0.0, 1.0).astype(dtype)
            




# --- helpers -----------------------------------------------------------------


