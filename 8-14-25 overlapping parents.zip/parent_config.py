# -*- coding: utf-8 -*-
"""
Created on Thu Aug 14 11:37:58 2025

@author: chris and christine
"""

# parent1_config.py
from types import SimpleNamespace
import math

# -----------------------------
# 7 meta-knobs (small & powerful)
# -----------------------------
# profile:     coarse preset tuning
# seed_sensitivity: 0..1  (higher = easier to seed)
# coverage_strictness: 0..1 (higher = existing parents block more area/seeds)
# growth_gain: 0..1   (higher = masks adapt faster; bigger deltas)
# growth_selectivity: 0..1 (higher = pickier thresholds; narrower grow/shrink band)
# reseed_period: int  (steps; 0 disables periodic reseed)
# support_tau: float 0..1 (mask floor for parent operations)

PROFILES = {
    "stable":   dict(seed_sensitivity=0.35, coverage_strictness=0.70, growth_gain=0.35, growth_selectivity=0.70, reseed_period=30, support_tau=0.10),
    "balanced": dict(seed_sensitivity=0.50, coverage_strictness=0.50, growth_gain=0.50, growth_selectivity=0.50, reseed_period=20, support_tau=0.08),
    "eager":    dict(seed_sensitivity=0.70, coverage_strictness=0.30, growth_gain=0.70, growth_selectivity=0.30, reseed_period=10, support_tau=0.06),
}

def _lerp(a, b, t): return a + (b - a) * float(t)
def _clamp(x, lo, hi): return max(lo, min(hi, x))
def _p(q): return f"p{int(round(q))}"  # percentile string like "p40"

def resolve_parent1(
    *,
    H, W, num_children,
    profile: str = "balanced",
    seed_sensitivity: float | None = None,
    coverage_strictness: float | None = None,
    growth_gain: float | None = None,
    growth_selectivity: float | None = None,
    reseed_period: int | None = None,
    support_tau: float | None = None,
    regularization_strength: float = 0.5,   # 0..1: Σ shrink_to_I & cond cap
    max_new_per_step: int | None = None,
):
    """
    Returns a dict of **all** the detailed keys used by your spawn/growth/detector code.
    Only these 7 meta-knobs are user-facing.
    """

    # -- base from profile --
    if profile not in PROFILES:
        raise ValueError(f"Unknown profile '{profile}'. Choose from {list(PROFILES)}.")
    meta = PROFILES[profile].copy()

    # -- apply overrides --
    if seed_sensitivity is not None:     meta["seed_sensitivity"]     = _clamp(seed_sensitivity, 0.0, 1.0)
    if coverage_strictness is not None:  meta["coverage_strictness"]  = _clamp(coverage_strictness, 0.0, 1.0)
    if growth_gain is not None:          meta["growth_gain"]          = _clamp(growth_gain, 0.0, 1.0)
    if growth_selectivity is not None:   meta["growth_selectivity"]   = _clamp(growth_selectivity, 0.0, 1.0)
    if reseed_period is not None:        meta["reseed_period"]        = int(max(0, reseed_period))
    if support_tau is not None:          meta["support_tau"]          = float(_clamp(support_tau, 0.0, 1.0))

    S  = meta["seed_sensitivity"]
    C  = meta["coverage_strictness"]
    G  = meta["growth_gain"]
    Sel= meta["growth_selectivity"]
    RP = meta["reseed_period"]
    ST = meta["support_tau"]

    # -- canvas-aware scaling (so knobs feel similar at diff resolutions) --
    A = H * W
    diag = math.sqrt(H*H + W*W)
    # NMS radius grows with image size; more sensitive → smaller spacing
    peak_nms_px = max(3, int( _lerp(0.07*diag, 0.035*diag, S) ))
    min_interseed_px = max(4, int( _lerp(0.09*diag, 0.05*diag, S) ))

    # -- seeding gates from S --
    emerge_tau_mode = "quantile"
    emerge_tau_q    = _lerp(0.30, 0.55, S)       # allow ~30–55% best-aligned pixels
    peak_min_cons   = _lerp(0.75, 0.50, S)       # required kid-agreement (high S lowers bar)
    emerge_min_area = max(6, int(_lerp(24, 8, S)))
    seed_min_kids   = max(1, min(num_children, int(round(_lerp(3, 1, S)))))

    # seed shape
    seed_r0      = _lerp(5.0, 3.5, S)
    seed_sigma   = 1.0
    seed_amp     = 0.55
    seed_halo_px = 2

    # pickiness for child-set matching
    child_jac_thr = _lerp(0.65, 0.45, S)  # lower with higher S

    # cap new births per step
    if max_new_per_step is None:
        max_new_per_step = 1 if A > 300*300 else 2

    # -- coverage/NMS strictness from C --
    parent_cover_support_eps = _lerp(0.35, 0.70, C)  # how much “covered” blocks new seeds
    parent_new_iou_thr       = _lerp(0.55, 0.85, C)  # anti-dup IoU vs existing
    match_iou_thr            = _lerp(0.40, 0.65, C)

    # -- reseeding cadence (periodic reconsideration) --
    parent_reseed_period = RP
    parent_reseed_iou    = 0.30

    # -- growth thresholds from Sel (percentiles over local KL band) --
    qg = 30 + 15*Sel     # p30..p45
    qs = 90 - 30*Sel     # p90..p60
    parent_tau_grow   = _p(qg)
    parent_tau_shrink = _p(qs)

    # -- growth gains/smoothing from G --
    eta_grow   = _lerp(0.04, 0.16, G)
    eta_shrink = _lerp(0.03, 0.12, G)
    delta_cap  = _lerp(0.02, 0.08, G)
    kappa      = _lerp(0.03, 0.12, G)   # small leak/regularizer in your update
    blur_iters = 1 if G >= 0.5 else 2   # slower gain → a touch more smoothing
    grow_band  = 1
    shrink_band= 1
    agreement_floor = 0.20              # safety floor so growth never fully stalls

    # -- regularization of Σ from regularization_strength --
    shrink_to_I = _lerp(0.02, 0.20, regularization_strength)
    cond_cap    = int(_lerp(1e5, 3e6, regularization_strength))

    # -- sensible static defaults you likely won’t touch --
    parent_peak_max_per_group = 3
    parent_freeze_steps = 1
    parent_ramp_steps   = int(_lerp(8, 3, G))  # gentler ramp for low gain
    parent_max_new_per_step = max_new_per_step

    # -- assemble the full “legacy” config dict your code already uses --
    cfg = {
        # grouping
        "child_support_tau": 0.10,
        "min_child_area_px": 6,
        "child_intragroup_iou_thr": 0.55,
        "parent_grow_min_kids": seed_min_kids,

        # peaks / seeding
        "emerge_tau_mode": emerge_tau_mode,
        "emerge_tau_q": float(emerge_tau_q),
        "emerge_min_area": int(emerge_min_area),
        "parent_peak_min_consensus": float(peak_min_cons),
        "parent_peak_nms_px": int(peak_nms_px),
        "parent_peak_max_per_group": int(parent_peak_max_per_group),

        # seed shape
        "parent_seed_radius_px": float(seed_r0),
        "parent_seed_amp": float(seed_amp),
        "parent_seed_feather_sigma": float(seed_sigma),
        "parent_seed_expand_px": int(seed_halo_px),

        # matching / coverage
        "parent_match_iou_existing": float(match_iou_thr),
        "parent_child_jaccard_thr": float(child_jac_thr),
        "parent_support_tau": float(ST),
        "parent_max_new_per_step": int(parent_max_new_per_step),
        "parent_min_interseed_px": int(min_interseed_px),
        "parent_cover_support_eps": float(parent_cover_support_eps),
        "parent_new_iou_thr": float(parent_new_iou_thr),

        # reseed
        "parent_reseed_period": int(parent_reseed_period),
        "parent_reseed_iou": float(parent_reseed_iou),

        # growth thresholds (percentiles)
        "parent_tau_grow": parent_tau_grow,
        "parent_tau_shrink": parent_tau_shrink,

        # growth dynamics
        "eta_grow": float(eta_grow),
        "eta_shrink": float(eta_shrink),
        "kappa": float(kappa),
        "grow_band": int(grow_band),
        "shrink_band": int(shrink_band),
        "delta_cap": float(delta_cap),
        "blur_iters": int(blur_iters),
        "agreement_floor": float(agreement_floor),

        # Σ regularization
        "cg_shrink_to_I": float(shrink_to_I),
        "cg_cond_cap": int(cond_cap),

        # ramp/freeze
        "parent_freeze_steps": int(parent_freeze_steps),
        "parent_ramp_steps": int(parent_ramp_steps),
    }
    return cfg, SimpleNamespace(**meta)

# Convenience: apply to an existing config module (in-place)
def apply_to_config(config_module, *, H, W, num_children, profile="balanced", **overrides):
    resolved, meta = resolve_parent1(H=H, W=W, num_children=num_children, profile=profile, **overrides)
    for k, v in resolved.items():
        setattr(config_module, k, v)
    # expose the small meta for logging/telemetry
    setattr(config_module, "parent1_meta", meta)
    return resolved
