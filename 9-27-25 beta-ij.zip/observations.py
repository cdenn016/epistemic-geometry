# -*- coding: utf-8 -*-
"""
observations.py — Gauge-covariant message passing for observations

Phase 1–3 implementation:
  - Message schema and ObservationBus
  - ObservationGraph (directed edges j→i with simple policy)
  - Emit & deliver (compose M = Φ ∘ Ω, push sender Gaussian to receiver q-fiber)
  - VFE hook: build μ/Σ grads for receiver via KL(q_i || message)

Notes:
  * Uses existing cached facades: Omega, Phi_cached
  * Uses push_gaussian / safe SPD ops from core.numerical_utils
  * Uses grad_alignment_energy_source (existing, fast) for KL grads
  * Mask-aware aggregation

Author: c&c + copilot
"""
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple
import numpy as np

# Suite imports (match current codebase style)

from core.transport_cache import Omega, Phi_cached
from core.numerical_utils import push_gaussian, sanitize_sigma
from utils import _aid

# For gradient computation compatible with your KL alignment math
 # ∂/∂(μ_i, Σ_i) of KL(q_i || N(μ*, Σ*))

# -----------------------------------------------------------------------------
# Message schema & bus
# -----------------------------------------------------------------------------

@dataclass
class Message:
    sender_id: int
    recv_id: int
    t: int
    payload_mu: np.ndarray           # (..., K_q_i)
    payload_cov: np.ndarray          # (..., K_q_i, K_q_i) — SPD
    channel: str = "gaussian"
    noise_params: dict = field(default_factory=dict)
    weight: float = 1.0              # attention / reliability ≥ 0

@dataclass
class ObsEdge:
    sender_id: int
    recv_id: int
    which_sender: str = "p"          # "p" or "q" (sender fiber)
    map_kind: str = "p_to_q"         # Φ variant: "p_to_q", "q_to_q", ... (receiver is q-fiber target)
    noise_sigma2: float = 0.0         # extra isotropic channel noise
    weight: float = 1.0               # base reliability
    enabled: bool = True

@dataclass
class ObservationGraph:
    """Receiver-indexed adjacency: recv_id → [edges]."""
    by_recv: Dict[int, List[ObsEdge]] = field(default_factory=dict)

    def add_edge(self, e: ObsEdge) -> None:
        self.by_recv.setdefault(int(e.recv_id), []).append(e)

    def edges_for(self, recv_id: int) -> List[ObsEdge]:
        return self.by_recv.get(int(recv_id), [])

@dataclass
class ObservationBus:
    """Per-step inbox of delivered messages."""
    inbox: Dict[int, List[Message]] = field(default_factory=dict)

    def clear_step(self) -> None:
        self.inbox.clear()

    def deliver(self, msg: Message) -> None:
        self.inbox.setdefault(int(msg.recv_id), []).append(msg)

    def take(self, recv_id: int) -> List[Message]:
        return self.inbox.get(int(recv_id), [])

    def iter_inbox_items(self):
        # yields (recv_id, inbox_list)
        return list(self.inbox.items())

# -----------------------------------------------------------------------------
# Utilities
# -----------------------------------------------------------------------------

def _edge_weight(edge: ObsEdge) -> float:
    w = float(edge.weight)
    return 0.0 if not np.isfinite(w) or w < 0.0 else w

def _noise_cov(edge: ObsEdge, dim: int, dtype=np.float32) -> np.ndarray:
    s2 = float(edge.noise_sigma2)
    if not np.isfinite(s2) or s2 <= 0.0:
        return np.zeros((dim, dim), dtype=dtype)
    return (s2 * np.eye(dim, dtype=dtype))

# -----------------------------------------------------------------------------
# Emit & deliver (pre-VFE)
# -----------------------------------------------------------------------------

def emit_and_deliver_messages(ctx, agents, *, obs_graph: Optional[ObservationGraph] = None) -> None:
    """
    Build ctx.obs_bus.inbox for the current step.
    For each edge j→i:
      1) choose sender latent (μ_s, Σ_s) from p- or q-fiber
      2) build a sender→receiver linear map M using Ω and Φ
         - if sender is q:   M = Ω_q(i←j)
         - if sender is p:   M = Ω_q(i←j) ∘ Φ_j(p→q)
      3) push Gaussian: (μ~, Σ~) = (M μ_s, M Σ_s M^T)
      4) add channel noise and deliver a Message
    """
    obs_bus = getattr(ctx, "obs_bus", None)
    if obs_bus is None:
        raise RuntimeError(
            "emit_and_deliver_messages: ctx.obs_bus is missing; call ensure_runtime_defaults first."
        )

    G = obs_graph if obs_graph is not None else getattr(ctx, "obs_graph", None)
    if G is None:
        
        obs_bus.clear_step()
        return

    obs_bus.clear_step()
    by_id = {int(getattr(a, "id", i)): a for i, a in enumerate(agents)}

    for ai in agents:
        rid = int(getattr(ai, "id", -1))
        edges = G.edges_for(rid)
        if not edges:
            continue

        for e in edges:
            if not e.enabled:
                continue
            aj = by_id.get(int(e.sender_id))
            if aj is None:
                continue
            
            # 1) Sender latent
            if str(e.which_sender).lower() == "p":
                mu_s = np.asarray(getattr(aj, "mu_p_field"), np.float32)
                S_s  = np.asarray(getattr(aj, "sigma_p_field"), np.float32)
                which_omega = "p"
            else:
                mu_s = np.asarray(getattr(aj, "mu_q_field"), np.float32)
                S_s  = np.asarray(getattr(aj, "sigma_q_field"), np.float32)
                which_omega = "q"

            # 2) Build sender→receiver map
            if which_omega == "q":
                # Same-dimensional q-fiber transport; requires Kq_j == Kq_i
                O_q_ij = Omega(ctx, ai, aj, which="q")  # (..., K_q_i, K_q_j)
                M = O_q_ij
            else:
                # p→q at sender j, then q-transport to receiver i
                Phi_j_p_to_q = Phi_cached(ctx, aj, kind="p_to_q")  # (..., K_q_j, K_p_j)
                O_q_ij = Omega(ctx, ai, aj, which="q")             # (..., K_q_i, K_q_j)
                M = np.einsum("...ab,...bc->...ac", O_q_ij, Phi_j_p_to_q, optimize=True)

            # 3) Push sender Gaussian to receiver using M
            mu_t, S_t = push_gaussian(mu_s, S_s, M)

            # 4) Add channel noise (isotropic) in receiver's fiber
            K_dst = int(mu_t.shape[-1])
            S_y = sanitize_sigma(S_t + _noise_cov(e, K_dst, dtype=S_t.dtype))

            msg = Message(
                sender_id=int(e.sender_id),
                recv_id=rid,
                t=int(getattr(ctx, "global_step", 0)),
                payload_mu=mu_t,
                payload_cov=S_y,
                channel="gaussian",
                noise_params={"sigma2": float(getattr(e, "noise_sigma2", 0.0))},
                weight=_edge_weight(e),
            )
            
            obs_bus.deliver(msg)


# -----------------------------------------------------------------------------
# VFE hook: accumulate message-derived grads for (μ_i, Σ_i)
# -----------------------------------------------------------------------------

def vfe_from_messages(ctx, agent_i) -> Tuple[float, np.ndarray, np.ndarray]:
    """
    Returns (E_msg, g_mu_msg, g_S_msg) for receiver's q-fiber given inbox messages.
    Each message contributes KL( N(μ_i, Σ_i) || N(μ_msg, Σ_msg) ).
    Grads are aggregated and *not* Fisher-projected here (caller does that already).
    """
    from updates.update_terms_mu_sigma import grad_alignment_energy_source 
    from core.numerical_utils import sanitize_sigma, safe_inv, kl_gaussian
    from runtime_context import cfg_get
    
    obs_bus = getattr(ctx, "obs_bus", None)
    if obs_bus is None:
        return 0.0, None, None

    msgs = obs_bus.take(int(getattr(agent_i, "id", -1)))
    if not msgs:
        mu_i = np.asarray(getattr(agent_i, "mu_q_field"), np.float32)
        S_i  = np.asarray(getattr(agent_i, "sigma_q_field"), np.float32)
        return 0.0, np.zeros_like(mu_i), np.zeros_like(S_i)

    mu_i = np.asarray(getattr(agent_i, "mu_q_field"), np.float32)
    S_i  = np.asarray(getattr(agent_i, "sigma_q_field"), np.float32)

    # Optional mask gating
    mask = np.asarray(getattr(agent_i, "mask", None))
    use_mask = mask is not None
    if use_mask:
        m1 = mask[..., None].astype(bool)
        m2 = mask[..., None, None].astype(bool)

    E_total = 0.0
    g_mu    = np.zeros_like(mu_i)
    g_S     = np.zeros_like(S_i)

    for m in msgs:
        mu_star = np.asarray(m.payload_mu,  np.float32)
        S_star  = np.asarray(m.payload_cov, np.float32)
        S_star  = sanitize_sigma(S_star)  # ensure SPD

        # Use suite's batched, SPD-safe inversion
        S_star_inv = safe_inv(S_star, eps=float(cfg_get(ctx, "sanitize_sigma_eps", 1e-6)))

        inv_S_i = getattr(agent_i, "sigma_q_inv", None)

        dμ, dΣ = grad_alignment_energy_source(
            mu_i, S_i,
            mu_star, S_star_inv,
            eps=float(cfg_get(ctx, "eps_num", 1e-8)),
            sigma_i_inv=inv_S_i,
            assume_sanitized=True,
        )

        if use_mask:
            dμ = np.where(m1, dμ, 0.0)
            dΣ = np.where(m2, dΣ, 0.0)

        w = float(m.weight)
        g_mu += w * dμ
        g_S  += w * dΣ

        # Energy accumulation (pixel-sum KL)
        
        kl_px = kl_gaussian(mu_i, S_i, mu_star, S_star)  # (...,)
        if use_mask:
            kl_px = np.where(mask.astype(bool), kl_px, 0.0)
        E_total += w * float(np.sum(kl_px))

    return float(E_total), g_mu.astype(np.float32, copy=False), g_S.astype(np.float32, copy=False)

# -----------------------------------------------------------------------------
# Convenience: ensure defaults in ctx (to be called from runtime setup)
# -----------------------------------------------------------------------------

def ensure_observation_infra(ctx) -> None:
    """Attach bus/graph to ctx if missing."""
    if not hasattr(ctx, "obs_bus") or getattr(ctx, "obs_bus") is None:
        ctx.obs_bus = ObservationBus()
    if not hasattr(ctx, "obs_graph") or getattr(ctx, "obs_graph") is None:
        ctx.obs_graph = ObservationGraph()


def compute_edge_betas(ctx, agents):
    """
    Build per-edge attention for BOTH fibers with per-receiver normalization:

      β_{i<-j} ∝ exp(- KL_i( q_i || Ω_ij q_j ) / κ)   [q-fiber]
      β_{i<-j} ∝ exp(- KL_i( p_i || Ω_ij p_j ) / κ)   [p-fiber]

    where KL_i is computed in *receiver i's* frame and (optionally) softmax-normalized
    over all senders j for each fixed receiver i.

    Writes:
      ctx._edge_beta_q[(i,j)], ctx._edge_beta_p[(i,j)]

    Notes:
      - If i has inbox messages, those (already in i's q-frame) are used for β_q.
      - If i has no inbox messages, β_q falls back to an all-pairs q-fiber computation.
      - β_p is always built via all-pairs in the p-fiber.
    """
    import numpy as np
    from runtime_context import cfg_get
    from core.numerical_utils import sanitize_sigma, kl_gaussian, push_gaussian
    from core.transport_cache import Omega
    # joint-mask helper that returns mask in i's frame
    from utils import _joint_mask

    # ---- cfg ----
    if not bool(cfg_get(ctx, "obs_beta_enable", True)):
        setattr(ctx, "_edge_beta_q", None)
        setattr(ctx, "_edge_beta_p", None)
        return

    lo, hi = cfg_get(ctx, "obs_beta_clip", (1e-4, 10.0))
    kappa  = float(cfg_get(ctx, "obs_beta_kappa", 1.0))
    mode   = str(cfg_get(ctx, "obs_beta_mode", "softmax")).lower()
    eps    = float(cfg_get(ctx, "eps", 1e-8))
    tau    = float(cfg_get(ctx, "support_tau", 1e-6))

    def _soft_weights(logits):
        # logits already = -KL/kappa for a fixed receiver i
        if mode == "softmax":
            m = np.max(logits)
            ex = np.exp(logits - m)
            w = ex / max(1e-12, np.sum(ex))
        else:
            w = np.exp(logits)
        return w

    N = len(agents)
    id_of = [int(getattr(a, "id", i)) for i, a in enumerate(agents)]
    idx_by_id = {aid: idx for idx, aid in enumerate(id_of)}

    # -------------------------
    # 1) β_q per receiver: try inbox, else all-pairs q-fiber
    # -------------------------
    beta_q = {}
    bus = getattr(ctx, "obs_bus", None)
    inbox_available = bool(bus and getattr(bus, "inbox", None))

    for i_idx, ai in enumerate(agents):
        i_id = id_of[i_idx]

        # Attempt inbox route for this receiver i
        used_inbox = False
        KLs = []
        js  = []

        if inbox_available:
            inbox = bus.inbox.get(i_id, [])
            if inbox:
                used_inbox = True
                # KLs from messages already in i's q-frame
                mu_i = np.asarray(ai.mu_q_field, np.float32)
                S_i  = sanitize_sigma(np.asarray(ai.sigma_q_field, np.float64))
                for m in inbox:
                    mu_star = np.asarray(m.payload_mu,  np.float32)
                    S_star  = sanitize_sigma(np.asarray(m.payload_cov, np.float64))
                    KL = float(np.sum(kl_gaussian(mu_i, S_i, mu_star, S_star)))
                    KLs.append(KL)
                    js.append(int(m.sender_id))

        # Fallback: all-pairs q-fiber for this receiver i
        if not used_inbox:
            mu_i = np.asarray(ai.mu_q_field, np.float32)
            S_i  = sanitize_sigma(np.asarray(ai.sigma_q_field, np.float64))
            KLs = []
            js  = []
            for j_idx, aj in enumerate(agents):
                if j_idx == i_idx:
                    continue
                j_id = id_of[j_idx]

                # overlap mask in i's support
                overlap = _joint_mask(ai, aj, tau=tau, as_vector=True)
                if not np.any(overlap):
                    continue

                Om_q = Omega(ctx, ai, aj, which="q")
                mu_j = np.asarray(aj.mu_q_field, np.float32)
                S_j  = sanitize_sigma(np.asarray(aj.sigma_q_field, np.float64))
                mu_j_t, S_j_t, _ = push_gaussian(mu_j, S_j, Om_q, eps=eps, return_inv=True, assume_orthogonal=False)

                KLpx  = kl_gaussian(mu_i, S_i, mu_j_t, S_j_t)
                denom = max(1.0, float(np.sum(overlap)))
                KLs.append(float(np.sum(KLpx * overlap) / denom))
                js.append(j_id)

        if js:
            logits = -np.asarray(KLs, np.float64) / max(1e-12, kappa)
            w = _soft_weights(logits)
            for j_id, wij in zip(js, w):
                # if we had an inbox message, keep the message's base weight multiplicative
                if inbox_available and used_inbox:
                    # find the message for (i<-j) and update its weight too
                    for m in bus.inbox.get(i_id, []):
                        if int(m.sender_id) == int(j_id):
                            m.weight = float(wij) * float(getattr(m, "weight", 1.0))
                            break
                    beta_q[(i_id, int(j_id))] = float(wij) * float(getattr(m, "weight", 1.0)) if 'm' in locals() else float(wij)
                else:
                    beta_q[(i_id, int(j_id))] = float(wij)

    setattr(ctx, "_edge_beta_q", beta_q if beta_q else None)

    # -------------------------
    # 2) β_p per receiver: all-pairs p-fiber
    # -------------------------
    beta_p = {}
    for i_idx, ai in enumerate(agents):
        i_id = id_of[i_idx]
        mu_i = np.asarray(ai.mu_p_field, np.float32)
        S_i  = sanitize_sigma(np.asarray(ai.sigma_p_field, np.float64))

        KLs = []
        js  = []
        for j_idx, aj in enumerate(agents):
            if j_idx == i_idx:
                continue
            j_id = id_of[j_idx]

            overlap = _joint_mask(ai, aj, tau=tau, as_vector=True)
            if not np.any(overlap):
                continue

            Om_p = Omega(ctx, ai, aj, which="p")
            mu_j = np.asarray(aj.mu_p_field, np.float32)
            S_j  = sanitize_sigma(np.asarray(aj.sigma_p_field, np.float64))
            mu_j_t, S_j_t, _ = push_gaussian(mu_j, S_j, Om_p, eps=eps, return_inv=True, assume_orthogonal=False)

            KLpx  = kl_gaussian(mu_i, S_i, mu_j_t, S_j_t)
            denom = max(1.0, float(np.sum(overlap)))
            KLs.append(float(np.sum(KLpx * overlap) / denom))
            js.append(j_id)

        if js:
            logits = -np.asarray(KLs, np.float64) / max(1e-12, kappa)
            w = _soft_weights(logits)
            for j_id, wij in zip(js, w):
                beta_p[(i_id, int(j_id))] = float(wij)

    setattr(ctx, "_edge_beta_p", beta_p if beta_p else None)

    # -------------------------
    # 3) Debug print
    # -------------------------
  #  step = getattr(ctx, "global_step", "?")
 #   n_q = len(beta_q); n_p = len(beta_p)
  #  print(f"[obs_beta] step {step}  q:{n_q} p:{n_p}  "
  #        f"q_samp={list(beta_q.items())[:6]}  p_samp={list(beta_p.items())[:6]}")

# -----------------------------------------------------------------------------
# Build ObservationGraph from existing neighbor lists
# -----------------------------------------------------------------------------

def seed_obs_graph_from_neighbors(
    ctx,
    agents,
    *,
    sender_fiber: str | None = None,
    map_kind: str | None = None,
    weight_mode: str = "normalize_max",   # "raw", "normalize_sum", "normalize_max"
    min_overlap: int = 1,
    default_noise_sigma2: float | None = None,
    clear: bool = True,
) -> None:
    """
    Construct a directed ObservationGraph (j→i) from each agent's `.neighbors` list.

    Each neighbor entry is expected to be `{ "id": int, "overlap": int }` as set by
    `assign_neighbors_simple(...)`. We create an edge **sender=j, recv=i** with:
      - which_sender: chosen globally (default from config: obs_sender_fiber)
      - map_kind:     chosen globally (default from config: obs_map_kind)
      - weight:       derived from `overlap` via `weight_mode`
      - noise_sigma2: from arg or config (obs_noise_sigma2)

    Args:
      weight_mode:
        - "raw": use overlap count directly (≥ min_overlap else skip)
        - "normalize_sum": weight = overlap / sum_j overlap_j→i (if sum>0)
        - "normalize_max": weight = overlap / max_j overlap_j→i (if max>0)
    """
    from runtime_context import cfg_get
    import numpy as _np
    
    # Resolve defaults from config
    which_sender = (sender_fiber or str(cfg_get(ctx, "obs_sender_fiber", "p"))).lower()
    mkind        = (map_kind     or str(cfg_get(ctx, "obs_map_kind", "p_to_q"))).lower()
    
    s2_default   = default_noise_sigma2
    
    if s2_default is None:
        try:
            s2_default = float(cfg_get(ctx, "obs_noise_sigma2", 0.0))
        except Exception:
            s2_default = 0.0

    G = getattr(ctx, "obs_graph", None)
    if G is None:
        ensure_observation_infra(ctx)
        G = ctx.obs_graph

    if clear:
        G.by_recv.clear()

    # Pre-compute per-receiver normalization stats
    # Build a map: rid -> list of (sender_id, overlap)
    recv_overlap: dict[int, list[tuple[int, int]]] = {}
    for ai in agents:
        rid = int(getattr(ai, "id", -1))
        raw = getattr(ai, "neighbors", None) or []
        pairs = []
        for nb in raw:
            try:
                j = int(nb["id"]) if isinstance(nb, dict) else int(nb)
                ov = int(nb.get("overlap", 0)) if isinstance(nb, dict) else 1
            except Exception:
                continue
            if ov >= int(min_overlap) and j != rid:
                pairs.append((j, ov))
        if pairs:
            recv_overlap[rid] = pairs

    # Compute normalizers
    
    sums: dict[int, float] = {}
    maxs: dict[int, float] = {}
    if weight_mode in ("normalize_sum", "normalize_max"):
        for rid, lst in recv_overlap.items():
            vals = _np.asarray([ov for (_, ov) in lst], dtype=_np.float64)
            sums[rid] = float(_np.sum(vals)) if vals.size else 0.0
            maxs[rid] = float(_np.max(vals)) if vals.size else 0.0

    # Emit edges
    for rid, lst in recv_overlap.items():
        for (sid, ov) in lst:
            if weight_mode == "raw":
                w = float(ov)
            elif weight_mode == "normalize_sum":
                denom = max(1e-12, sums.get(rid, 0.0))
                w = float(ov) / denom
            else:  # normalize_max (default)
                denom = max(1e-12, maxs.get(rid, 0.0))
                w = float(ov) / denom

            edge = ObsEdge(
                sender_id=int(sid),
                recv_id=int(rid),
                which_sender=which_sender,
                map_kind=mkind,
                noise_sigma2=float(s2_default),
                weight=float(max(0.0, w)),
                enabled=True,
            )
            G.add_edge(edge)
    # Done; graph lives on ctx.obs_graph
    return None



def fuse_messages_to_pseudo_y_for_agent(ctx, agent_i):
    """
    Precision-weighted fusion of inbox messages into one Gaussian; set observation_field to fused mean.
    """
    import numpy as np
    from runtime_context import cfg_get
    from core.numerical_utils import safe_inv, sanitize_sigma

    bus = getattr(ctx, "obs_bus", None)
    msgs = bus.take(int(getattr(agent_i, "id", -1))) if bus else []
    if not msgs:
        return

    mu_i = np.asarray(getattr(agent_i, "mu_q_field"), np.float32)
    H, W, K = agent_i.mask.shape[0], agent_i.mask.shape[1], mu_i.shape[-1]

    Lam_sum = np.zeros((H, W, K, K), dtype=np.float32)
    rhs     = np.zeros((H, W, K),    dtype=np.float32)

    for m in msgs:
        mu_m = np.asarray(m.payload_mu,  np.float32)
        S_m  = sanitize_sigma(np.asarray(m.payload_cov, np.float32), eps=float(cfg_get(ctx, "sanitize_sigma_eps", 1e-6)))
        Lam_m = safe_inv(S_m, eps=float(cfg_get(ctx, "sanitize_sigma_eps", 1e-6)))
        w = float(getattr(m, "weight", 1.0))
        Lam_sum += w * Lam_m
        rhs     += w * np.einsum("...ij,...j->...i", Lam_m, mu_m, optimize=True)

    Lam_inv = safe_inv(Lam_sum, eps=float(cfg_get(ctx, "sanitize_sigma_eps", 1e-6)))
    mu_hat  = np.einsum("...ij,...j->...i", Lam_inv, rhs, optimize=True).astype(np.float32, copy=False)
    agent_i.observation_field = mu_hat
