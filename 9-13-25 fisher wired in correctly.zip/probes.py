# -*- coding: utf-8 -*-
"""
Created on Sun Sep  7 15:06:07 2025

@author: chris and christine
"""
import numpy as np
from core.gaussian_core import kl_gaussian, push_gaussian 
from numpy.linalg import det
from scipy.linalg import expm
from transport.transport_cache import Omega


def eval_KL_field_with_Omega(Ai, Aj, Om, which="q"):
    # Applies Ω to Aj’s (μ,Σ) on the chosen fiber, then KL per pixel Ai || Ω Aj
    if which=="q":
        mu_i, S_i = Ai.mu_q_field, Ai.sigma_q_field
        mu_j, S_j = Aj.mu_q_field, Aj.sigma_q_field
    else:
        mu_i, S_i = Ai.mu_p_field, Ai.sigma_p_field
        mu_j, S_j = Aj.mu_p_field, Aj.sigma_p_field

    mu_jp, S_jp = push_gaussian(mu_j, S_j, Om)      # Ω·q_j
    return kl_gaussian(mu_i, S_i, mu_jp, S_jp)



def _eye_field_like(mu_field):
    H, W, K = mu_field.shape
    I = np.eye(K, dtype=np.float32)
    return np.broadcast_to(I, (H, W, K, K)).copy()

def _proj_SO_per_pixel(M):
    # M: (...,K,K)
    U, S, Vt = np.linalg.svd(M, full_matrices=False)
    R = U @ Vt
    d = det(R)
    bad = d < 0
    if np.any(bad):
        U[bad, :, -1] *= -1.0
        R = U @ Vt
    return R.astype(np.float32, copy=False)




def _egrid_expm(phi, G):
    # Reference implementation using scipy.linalg.expm on blocks (no cache, no shortcuts).
    # phi: (H,W,3) or (...,3); G: (3,K,K)
    H, W = phi.shape[:2]
    K = G.shape[-1]
    M = np.empty((H, W, K, K), dtype=np.float64)
    A = phi[...,0][...,None,None]*G[0] + phi[...,1][...,None,None]*G[1] + phi[...,2][...,None,None]*G[2]
    for i in range(H):
        for j in range(W):
            M[i,j] = expm(A[i,j])
    return M.astype(np.float32)

def make_Omega_gold(ctx, Ai, Aj, which="q"):
    # Build Ω via expm reference path + exact transpose inverse, then project to SO
    phi_i = getattr(Ai, "phi" if which=="q" else "phi_model")
    phi_j = getattr(Aj, "phi" if which=="q" else "phi_model")
    G_i   = getattr(Ai, "generators_q" if which=="q" else "generators_p")
    G_j   = getattr(Aj, "generators_q" if which=="q" else "generators_p")
    Ei = _egrid_expm(phi_i, G_i)
    Ej = _egrid_expm(phi_j, G_j)
    Om = Ei @ np.swapaxes(Ej, -1, -2)
    return _proj_SO_per_pixel(Om)

def omega_stats(Om):
    RtR = np.einsum("...ik,...jk->...ij", np.swapaxes(Om,-1,-2), Om)  # Ω^T Ω
    I = np.eye(Om.shape[-1], dtype=Om.dtype)
    ortho_err = np.sqrt(np.sum((RtR - I)**2, axis=(-1,-2)))  # Fro per pixel
    d = np.linalg.det(Om)
    return {
        "ortho_err_min": float(np.min(ortho_err)),
        "ortho_err_max": float(np.max(ortho_err)),
        "det_min": float(np.min(d)),
        "det_max": float(np.max(d)),
    }





def _as_float(x):
    return np.asarray(x, dtype=float)


def _expand_diag(diag_or_full: np.ndarray, *, assume_stddev: bool) -> np.ndarray:
    """Convert (...,K) or (...,K,K) to full SPD (...,K,K)."""
    S = np.asarray(diag_or_full)
    if S.ndim >= 2 and S.shape[-2] == S.shape[-1]:
        return S
    if S.ndim == 1:
        S = S[None]
    diag = S
    if assume_stddev:
        diag = diag * diag
    K = int(diag.shape[-1])
    I = np.eye(K, dtype=diag.dtype)
    return np.einsum("...k,ij->...ij", diag, I, optimize=True)




def _spd_sanitize(S, eps=1e-8):
    """
    Symmetrize and floor eigenvalues per pixel so Cholesky is safe.
    S: (..., K, K)
    """
    import numpy as np
    S = 0.5 * (S + np.swapaxes(S, -1, -2))
    w, V = np.linalg.eigh(S)
    return (V * w[..., None, :]) @ np.swapaxes(V, -1, -2)
    w = np.maximum(w, eps)


def _pick_overlap_pixel(Ai, Aj, eps=None, interior_margin=0.05):
    import numpy as np
    import core.config as config

    if eps is None:
        eps = float(getattr(config, "support_cutoff_eps", 1e-3))

    m = (np.asarray(Ai.mask) > eps) & (np.asarray(Aj.mask) > eps)
    if not np.any(m):
        raise RuntimeError("No overlap between the chosen pair")

    # Prefer interior pixels (higher joint weight) to avoid boundary flicker
    w = np.minimum(Ai.mask, Aj.mask)
    w = np.where(m, w, 0.0)
    thresh = interior_margin * (w.max() if np.any(w) else 1.0)
    m_int = m & (w >= thresh)
    if not np.any(m_int):
        m_int = m  # fallback to any overlap

    r, c = np.argwhere(m_int)[0]
    return int(r), int(c)

def KL_smoothness_probe(ctx, Ai, Aj, which="q", delta=1e-4, nsteps=5):
    """
    Build a *constant* Ω once (three ways), check it, then finite-difference KL
    by nudging φ_i and φ_j in a random unit direction of R^3.
    Returns a dict of all the useful numbers.
    """
    from transport.transport_cache import Omega as Omega_cached  # your path

    # 1) Three Omegas
    Om_cache = Omega_cached(ctx, Ai, Aj, which=which)      # through your stack
    Om_gold  = make_Omega_gold(ctx, Ai, Aj, which=which)   # slow, reference
    # Project cached too, to eliminate projection differences
    Om_cache_proj = _proj_SO_per_pixel(Om_cache)

    # 2) Stats
    s_cache = omega_stats(Om_cache_proj)
    s_gold  = omega_stats(Om_gold)
    Om_diff = np.max(np.abs(Om_cache_proj - Om_gold))

    # 3) KL at baseline
    KL0_c = eval_KL_field_with_Omega(Ai, Aj, Om_cache_proj, which=which)
    KL0_g = eval_KL_field_with_Omega(Ai, Aj, Om_gold,       which=which)

    # 4) Smoothness: nudge φ_i and φ_j by tiny deltas and check |ΔKL|/‖δ‖
    rng = np.random.default_rng(0)
    v = rng.normal(size=3).astype(np.float32)
    v /= max(1e-9, np.linalg.norm(v))
    def _nudge_phi(A, which, sign):
        fld = getattr(A, "phi" if which=="q" else "phi_model").copy()
        fld[...,0] += sign*delta*v[0]
        fld[...,1] += sign*delta*v[1]
        fld[...,2] += sign*delta*v[2]
        return fld

    # Nudge i
    phi_i_saved = getattr(Ai, "phi" if which=="q" else "phi_model")
    setattr(Ai, "phi" if which=="q" else "phi_model", _nudge_phi(Ai, which, +1))
    Om_i_plus  = make_Omega_gold(ctx, Ai, Aj, which=which)
    KL_i_plus  = eval_KL_field_with_Omega(Ai, Aj, Om_i_plus, which=which)
    setattr(Ai, "phi" if which=="q" else "phi_model", _nudge_phi(Ai, which, -1))
    Om_i_minus = make_Omega_gold(ctx, Ai, Aj, which=which)
    KL_i_minus = eval_KL_field_with_Omega(Ai, Aj, Om_i_minus, which=which)
    setattr(Ai, "phi" if which=="q" else "phi_model", phi_i_saved)

    # Nudge j
    phi_j_saved = getattr(Aj, "phi" if which=="q" else "phi_model")
    setattr(Aj, "phi" if which=="q" else "phi_model", _nudge_phi(Aj, which, +1))
    Om_j_plus  = make_Omega_gold(ctx, Ai, Aj, which=which)
    KL_j_plus  = eval_KL_field_with_Omega(Ai, Aj, Om_j_plus, which=which)
    setattr(Aj, "phi" if which=="q" else "phi_model", _nudge_phi(Aj, which, -1))
    Om_j_minus = make_Omega_gold(ctx, Ai, Aj, which=which)
    KL_j_minus = eval_KL_field_with_Omega(Ai, Aj, Om_j_minus, which=which)


    # Restore
    setattr(Aj, "phi" if which=="q" else "phi_model", phi_j_saved)

    # Lipschitz proxies
    eps = 1e-12
    lip_i = float(np.max(np.abs(KL_i_plus - KL_i_minus)) / (2*delta + eps))
    lip_j = float(np.max(np.abs(KL_j_plus - KL_j_minus)) / (2*delta + eps))

    return {
        "cache_stats": s_cache,
        "gold_stats":  s_gold,
        "max_abs_diff_Omega_cache_vs_gold": float(Om_diff),
        "KL0_cache_max": float(np.max(KL0_c)),
        "KL0_gold_max":  float(np.max(KL0_g)),
        "KL0_cache_gold_maxdiff": float(np.max(np.abs(KL0_c - KL0_g))),
        "lip_i": lip_i,
        "lip_j": lip_j,
    }



def _probe_alignment_kl_grid(ctx, agents, which="q"):
    """Scan a couple of neighbor pairs; compute KL(Ai || Ω Aj) over overlap pixels.
    SPD-sanitizes both Σ_i and Σ'_j, and uses triangular solves for Σ^{-1}."""
    import numpy as np
    from transport.transport_cache import Omega
    import core.config as config

    eps = float(getattr(config, "support_cutoff_eps", 1e-3))
    printed = 0

    for i, Ai in enumerate(agents):
        for nb in getattr(Ai, "neighbors", []):
            j = int(nb["id"]); Aj = agents[j]

            m = (Ai.mask > eps) & (Aj.mask > eps)
            if not np.any(m):
                continue

            Om = Omega(ctx, Ai, Aj, which=which)  # (H,W,K,K)

            if which == "q":
                mu_i, Si = Ai.mu_q_field, Ai.sigma_q_field
                mu_j, Sj = Aj.mu_q_field, Aj.sigma_q_field
            else:
                mu_i, Si = Ai.mu_p_field, Ai.sigma_p_field
                mu_j, Sj = Aj.mu_p_field, Aj.sigma_p_field

            Rt    = np.swapaxes(Om, -1, -2)
            muj_p = np.einsum("...ij,...j->...i", Om, mu_j)
            Sj_p  = np.einsum("...ia,...ab,...jb->...ij", Om, Sj, Rt)

            # --- NEW: sanitize BOTH covariances on overlap ---
            Si_m   = _spd_sanitize(Si[m])
            Sj_p_m = _spd_sanitize(Sj_p[m])

            try:
                # Cholesky of Σ'_j on overlap
                L2   = np.linalg.cholesky(Sj_p_m)           # (...,K,K)
                # Build Σ'_j^{-1} via triangular solves: P2 = (L2^{-1})^T (L2^{-1})
                Linv = np.linalg.inv(L2)                    # (...,K,K)
                P2   = np.einsum("...ki,...kj->...ij", Linv, Linv)
            except np.linalg.LinAlgError:
                print(f"[ALIGN-KL] pair=({i},{j}) which={which} -- Cholesky failed even after sanitize")
                continue

            diff = (muj_p[m] - mu_i[m])[..., None]         # (...,K,1)
            tr   = np.trace(np.einsum("...ij,...jk->...ik", P2, Si_m), axis1=-2, axis2=-1)
            qf   = np.einsum("...ij,...jk,...ki->...", np.swapaxes(diff, -1, -2), P2, diff)
            s1   = np.linalg.slogdet(Si_m)[1]
            s2   = np.linalg.slogdet(Sj_p_m)[1]
            K    = Si.shape[-1]
            KL   = 0.5 * (tr + qf - K + (s2 - s1))

            KL_mean = float(np.mean(KL))
            KL_max  = float(np.max(KL))

            if not hasattr(ctx, "_probe_align_prev"):
                ctx._probe_align_prev = {}
            key  = (i, j, which)
            prev = ctx._probe_align_prev.get(key, None)
            d    = (KL_mean - prev) if prev is not None else np.nan
            ctx._probe_align_prev[key] = KL_mean

            print(f"[ALIGN-KL] pair=({i},{j}) which={which} mean={KL_mean:.6e} "
                  f"max={KL_max:.6e} d_step={d:.3e}")
            printed += 1
            if printed >= 2:
                return


def _probe_sigma_health(agents):
    """Track SPD conditioning. Spikes here = Σ update culprit."""
    import numpy as np

    def stats(S):
        Ssym = 0.5 * (S + np.swapaxes(S, -1, -2))
        # eigs per pixel: shape (H,W,K)
        w = np.linalg.eigvalsh(Ssym)
        wmin_px = np.min(w, axis=-1)                # (H,W)
        wmax_px = np.max(w, axis=-1)                # (H,W)
        cond_px = wmax_px / np.maximum(wmin_px, 1e-12)
        return float(np.min(wmin_px)), float(np.max(wmax_px)), float(np.max(cond_px))


    printed = 0
    for a in agents:
        wmin_q, wmax_q, cond_q = stats(a.sigma_q_field)
        wmin_p, wmax_p, cond_p = stats(a.sigma_p_field)
        print(f"[Σ-health] aid={getattr(a,'id','?')} "
              f"q:λmin={wmin_q:.2e} λmax={wmax_q:.2e} cond={cond_q:.2e} | "
              f"p:λmin={wmin_p:.2e} λmax={wmax_p:.2e} cond={cond_p:.2e}")
        printed += 1
        if printed >= 3:
            return


def _probe_omega_kl(ctx, agents, which="q"):
    """
    One-pixel probe on a robust interior-overlap pixel; SPD-sanitizes Σ' and
    avoids NumPy deprecation by extracting scalars via .item().
    """
    
  

    for i, Ai in enumerate(agents):
        for nb in getattr(Ai, "neighbors", []):
            j = int(nb["id"])
            Aj = agents[j]

            try:
                r, c = _pick_overlap_pixel(Ai, Aj)  # robust interior pixel
            except RuntimeError:
                continue

            # cached Ω (your stack), per-pixel
            Om = Omega(ctx, Ai, Aj, which=which)[r, c]

            # gold Ω via expm + transpose inverse, then polar projection
            phi_i = Ai.phi if which == "q" else Ai.phi_model
            phi_j = Aj.phi if which == "q" else Aj.phi_model
            Gi    = Ai.generators_q if which == "q" else Ai.generators_p
            Gj    = Aj.generators_q if which == "q" else Aj.generators_p
            A_i   = phi_i[r, c, 0]*Gi[0] + phi_i[r, c, 1]*Gi[1] + phi_i[r, c, 2]*Gi[2]
            A_j   = phi_j[r, c, 0]*Gj[0] + phi_j[r, c, 1]*Gj[1] + phi_j[r, c, 2]*Gj[2]
            Ei    = expm(A_i)
            Ej    = expm(A_j)
            Om_g  = Ei @ Ej.T
            U, S, Vt = np.linalg.svd(Om_g, full_matrices=False)
            Rg = U @ Vt
            if np.linalg.det(Rg) < 0:
                U[:, -1] *= -1.0
                Rg = U @ Vt

            # orthogonality / det stats
            o_err = float(np.linalg.norm(Om.T @ Om - np.eye(Om.shape[0])))
            d     = float(np.linalg.det(Om))
            diff  = float(np.max(np.abs(Om - Rg)))

            # one-pixel KL with pushed j (SPD-sanitize Σ' first)
            if which == "q":
                mu_i, Si = Ai.mu_q_field[r, c], Ai.sigma_q_field[r, c]
                mu_j, Sj = Aj.mu_q_field[r, c], Aj.sigma_q_field[r, c]
            else:
                mu_i, Si = Ai.mu_p_field[r, c], Ai.sigma_p_field[r, c]
                mu_j, Sj = Aj.mu_p_field[r, c], Aj.sigma_p_field[r, c]

            muj_p = Om @ mu_j
            Sj_p  = Om @ Sj @ Om.T
            Sj_p  = _spd_sanitize(Sj_p)

            try:
                L    = np.linalg.cholesky(Sj_p)
                Linv = np.linalg.inv(L)
                P2   = Linv.T @ Linv
            except np.linalg.LinAlgError:
                print(f"[Ω-probe] pair=({i},{j}) px=({r},{c}) Cholesky failed after sanitize")
                return

            diffm = (muj_p - mu_i)[:, None]
            tr  = float(np.trace(P2 @ Si))
            qf  = float((diffm.T @ P2 @ diffm).item())   # avoid deprecation
            s1  = float(np.linalg.slogdet(Si)[1])
            s2  = float(np.linalg.slogdet(Sj_p)[1])
            KL  = 0.5 * (tr + qf - Si.shape[0] + (s2 - s1))

            print(f"[Ω-probe] pair=({i},{j}) px=({r},{c}) "
                  f"‖ΩᵀΩ−I‖={o_err:.2e} detΩ={d:.6f} |Ω−Ω_gold|_∞={diff:.2e} KL={KL:.6f}")
            return  # one probe per step is enough
