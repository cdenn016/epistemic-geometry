# -*- coding: utf-8 -*-
"""
Created on Thu Sep 11 10:54:04 2025

@author: chris and christine
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Tuple, Optional, Any, Iterable
import time
import csv

import numpy as np
import matplotlib.pyplot as plt

# =============================================================
# MetricsViz: one-stop logging + plotting for SO(3) Suite
# =============================================================
# Goals
#  - Single API to record GLOBAL and PER-AGENT metrics every step
#  - Lightweight CSV/JSONL logs for analysis
#  - Quick timeseries plots (energies, norms, drift)
#  - Snapshot heatmaps & step GIFs using robust percentile scaling
#  - Representation-aware annotations (reads casimir_total from meta)
#
# Notes
#  - No seaborn; pure matplotlib, as requested.
#  - Animations saved as GIFs (user preference) not MP4s.
#  - Designed to be imported by your run loop; no tight coupling.
# =============================================================


# ------------------------------
# Config
# ------------------------------
@dataclass
class VizConfig:
    outdir: Path
    run_name: str = "run"

    # Logging cadence
    save_every_steps: int = 1            # write CSV/JSONL every N steps
    plot_every_steps: int = 1           # render timeseries every N steps
    snapshot_every_steps: int = 1       # save per-agent field PNGs every N steps
    

    # Visualization settings
    dpi: int = 120
    cmap: str = "viridis"
    robust_low: float = 1.0              # robust percentile lower bound
    robust_high: float = 99.0            # robust percentile upper bound

    # Downsample for large fields when snapshotting
    max_side: int = 256                  # downsample larger H/W to this

    # File names
    global_csv: str = "global_metrics.csv"
    agent_csv: str = "agent_metrics.csv"
    global_jsonl: str = "global_metrics.jsonl"
    agent_jsonl: str = "agent_metrics.jsonl"



    # Toggles
    enable_jsonl: bool = True
    enable_csv: bool = True
    enable_plots: bool = True
    enable_snapshots: bool = True
    


# ------------------------------
# Utility helpers
# ------------------------------


import numbers as _numbers

def _load_jsonl(path: Path) -> list[dict]:
    if not path.exists():
        return []
    rows = []
    with path.open("r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                rows.append(json.loads(line))
            except Exception:
                # skip malformed lines
                pass
    return rows

def _is_num(x) -> bool:
    if isinstance(x, (bool, np.bool_)):
        return False
    return isinstance(x, _numbers.Number) or (isinstance(x, np.generic) and np.issubdtype(type(x), np.number))

def _to_num(x):
    try:
        if _is_num(x):
            return float(x)
        # try string→float
        return float(x)
    except Exception:
        return np.nan



def _ensure_dir(p: Path):
    p.mkdir(parents=True, exist_ok=True)


def _ts() -> str:
    return time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())


def _robust_min_max(x: np.ndarray, low=1.0, high=99.0) -> Tuple[float, float]:
    lo = float(np.nanpercentile(x, low))
    hi = float(np.nanpercentile(x, high))
    if not np.isfinite(lo):
        lo = float(np.nanmin(x))
    if not np.isfinite(hi):
        hi = float(np.nanmax(x))
    if hi <= lo:
        hi = lo + 1e-6
    return lo, hi


def _downsample(img: np.ndarray, max_side: int) -> np.ndarray:
    H, W = img.shape[:2]
    s = max(H, W)
    if s <= max_side:
        return img
    scale = max_side / s
    newH = max(1, int(round(H * scale)))
    newW = max(1, int(round(W * scale)))
    # simple area-ish resize via slicing; keep dependencies light
    # For better quality, users can swap to skimage.transform.resize.
    y_idx = (np.linspace(0, H - 1, newH)).astype(int)
    x_idx = (np.linspace(0, W - 1, newW)).astype(int)
    return img[np.ix_(y_idx, x_idx)]


def _save_csv_row(csv_path: Path, header: List[str], row: List[Any]):
    exists = csv_path.exists()
    with csv_path.open("a", newline="") as f:
        writer = csv.writer(f)
        if not exists:
            writer.writerow(header)
        writer.writerow(row)


def _append_jsonl(path: Path, obj: Dict[str, Any]):
    with path.open("a", encoding="utf-8") as f:
        f.write(json.dumps(obj) + "\n")


def _safe_fig(figsize=(8,4), dpi=120):
    fig = plt.figure(figsize=figsize, dpi=dpi)
    ax = fig.add_subplot(111)
    return fig, ax


def _safe_savefig(fig: plt.Figure, path: Path):
    fig.tight_layout()
    fig.savefig(path)
    plt.close(fig)

# --- tiny local helpers for A/curvature/covariant derivatives ---
def _fwd_dx(X):  # periodic forward diff along x (cols)
    X = np.asarray(X, np.float32)
    return np.roll(X, -1, axis=1) - X

def _fwd_dy(X):  # periodic forward diff along y (rows)
    X = np.asarray(X, np.float32)
    return np.roll(X, -1, axis=0) - X

def _cross(a, b):
    a = np.asarray(a, np.float32); b = np.asarray(b, np.float32)
    return np.stack([
        a[...,1]*b[...,2] - a[...,2]*b[...,1],
        a[...,2]*b[...,0] - a[...,0]*b[...,2],
        a[...,0]*b[...,1] - a[...,1]*b[...,0]
    ], axis=-1)

def _get_A_from_ctx(ctx_obj, which="q"):
    # Try common attribute names; expect shape (H,W,2,3)
    names = [f"A_{which}", "A", "A_field", f"global_A_{which}", "global_A"]
    for nm in names:
        A = getattr(ctx_obj, nm, None)
        if A is not None:
            A = np.asarray(A)
            if A.ndim == 4 and A.shape[-2:] == (2, 3):
                return A.astype(np.float32, copy=False)
    # Try ctx.transport.* if present
    tr = getattr(ctx_obj, "transport", None)
    if tr is not None:
        for nm in (f"A_{which}", "A"):
            A = getattr(tr, nm, None)
            if A is not None and A.ndim == 4 and A.shape[-2:] == (2, 3):
                return A.astype(np.float32, copy=False)
    return None

def _curvature_from_A(A):
    # Non-Abelian curvature: F = ∂x Ay − ∂y Ax + Ax × Ay
    Ax, Ay = A[..., 0, :], A[..., 1, :]
    Fx = _fwd_dx(Ay)
    Fy = _fwd_dy(Ax)
    F  = Fx - Fy + _cross(Ax, Ay)
    F2 = np.sum(F * F, axis=-1)
    return F, 0.5 * F2

def _covariant_phi_terms(phi, A):
    # Dφ = (∂x φ − Ax×φ, ∂y φ − Ay×φ) → per-pixel norms and energy
    Ax, Ay = A[..., 0, :], A[..., 1, :]
    Dx = _fwd_dx(phi) - _cross(Ax, phi)
    Dy = _fwd_dy(phi) - _cross(Ay, phi)
    Dx2 = np.sum(Dx * Dx, axis=-1)
    Dy2 = np.sum(Dy * Dy, axis=-1)
    return np.sqrt(Dx2), np.sqrt(Dy2), 0.5 * (Dx2 + Dy2)


# ------------------------------
# Main class
# ------------------------------
class MetricsViz:
    """
    Central logger/plotter. Create once per run, call from your step loop.

    API summary:
      mv = MetricsViz(VizConfig(Path(outdir), run_name="trial1"))
      mv.start_run(meta={"casimir_total": 2.0})
      for step in range(steps):
          mv.log_global(step, {...})
          for aid in agents:
              mv.log_agent(step, aid, {...})
          mv.maybe_flush(step)
          mv.maybe_plot(step)
          mv.maybe_snapshot(step, ctx, agents)
          mv.maybe_gif(step)
      mv.end_run()
    """

    def __init__(self, cfg: VizConfig):
        self.cfg = cfg
        self.root = Path(cfg.outdir)
        _ensure_dir(self.root)
        self.dir_run = self.root / cfg.run_name
        _ensure_dir(self.dir_run)
        self.dir_plots = self.dir_run / "plots"
        self.dir_snaps = self.dir_run / "snapshots"
        
        _ensure_dir(self.dir_plots)
        _ensure_dir(self.dir_snaps)
        

        # In-memory timeseries (small; mirrors CSV/JSONL)
        self.global_rows: List[Dict[str, Any]] = []
        self.agent_rows: List[Dict[str, Any]] = []

        # Headers will be discovered from first row
        self._global_header: Optional[List[str]] = None
        self._agent_header: Optional[List[str]] = None

       
        # Meta
        self.meta: Dict[str, Any] = {}
        self.run_started = False
        
        self.run_id: int | None = None
        self._counter_path = self.dir_run / "run_counter.txt"

    # --------------------------
    # Lifecycle
    # --------------------------
# replace start_run()
    def start_run(self, meta: Optional[Dict[str, Any]] = None):
        # allocate a new run_id (persistent counter)
        cur = 0
        if self._counter_path.exists():
            try:
                cur = int(self._counter_path.read_text().strip())
            except Exception:
                cur = 0
        self.run_id = cur + 1
        self._counter_path.write_text(str(self.run_id))
    
        # save meta + run label
        self.meta = {"run_id": self.run_id, "started": _ts(), **(meta or {})}
        with (self.dir_run / "meta.json").open("w", encoding="utf-8") as f:
            json.dump(self.meta, f, indent=2)
        self.run_started = True


    
    # --------------------------
    # Logging
    # --------------------------
    def log_global(self, step: int, metrics: Dict[str, Any]):
        """Add a single global metrics row (merged with step & timestamp)."""
        row = {"step": int(step), "ts": _ts(), "run_id": self.run_id}
        row.update(metrics)
        self.global_rows.append(row)
        # Persist JSONL immediately for crash safety
        if self.cfg.enable_jsonl:
            _append_jsonl(self.dir_run / self.cfg.global_jsonl, row)
        # Remember header ordering
        if self._global_header is None:
            self._global_header = list(row.keys())

    def log_agent(self, step: int, agent_id: int | str, metrics: Dict[str, Any]):
        """Add a per-agent metrics row."""
        row = {"step": int(step), "agent": agent_id, "ts": _ts(), "run_id": self.run_id}
        row.update(metrics)
        self.agent_rows.append(row)
        if self.cfg.enable_jsonl:
            _append_jsonl(self.dir_run / self.cfg.agent_jsonl, row)
        if self._agent_header is None:
            self._agent_header = list(row.keys())

    # --------------------------
    # Periodic persistence & plots
    # --------------------------
    def maybe_flush(self, step: int):
        if (step % self.cfg.save_every_steps) != 0:
            return
        if self.cfg.enable_csv:
            if self.global_rows:
                self._flush_csv(self.dir_run / self.cfg.global_csv, self.global_rows, self._global_header)
            if self.agent_rows:
                self._flush_csv(self.dir_run / self.cfg.agent_csv, self.agent_rows, self._agent_header)

    def _flush_csv(self, path: Path, rows: List[Dict[str, Any]], header: Optional[List[str]]):
        if not rows:
            return
        if header is None:
            header = list(rows[0].keys())
        for r in rows:
            _save_csv_row(path, header, [r.get(h, "") for h in header])
        rows.clear()

    def maybe_plot(self, step: int):
        if not self.cfg.enable_plots or (step % self.cfg.plot_every_steps) != 0:
            return
        # Timeseries plots for a few core metrics
        self._plot_global_timeseries()
        self._plot_agent_timeseries()

    # replace _plot_global_timeseries() entirely
    def _plot_global_timeseries(self):
        rows = _load_jsonl(self.dir_run / self.cfg.global_jsonl)
        if not rows:
            return
    
        # collect unique runs; fallback to step-based segmentation if no run_id
        have_run = any("run_id" in r for r in rows)
        if have_run:
            run_ids = sorted({int(r["run_id"]) for r in rows if "run_id" in r})
            groups = {rid: [r for r in rows if r.get("run_id") == rid] for rid in run_ids}
        else:
            # single pseudo-run; we’ll still segment by step resets
            groups = {1: rows}
            run_ids = [1]
    
        preferred = ["E_total","Geom_total","Action_total","mean_total","VFE_acc","A_curv","A_cov","ModelPrior"]
        all_keys = set().union(*[r.keys() for r in rows])
        fields = [k for k in preferred if k in all_keys] + [
            k for k in sorted(all_keys) if k not in preferred and k not in ("step","ts","run_id")
        ]
    
        for field in fields:
            # figure with one color per run
            fig, ax = _safe_fig(figsize=(8,3), dpi=self.cfg.dpi)
            plotted_any = False
            for rid in run_ids:
                rs = groups[rid]
                # sort by step
                rs = sorted(rs, key=lambda r: _to_num(r.get("step")))
                steps = np.array([_to_num(r.get("step")) for r in rs], dtype=float)
                vals  = np.array([_to_num(r.get(field))   for r in rs], dtype=float)
    
                # segment by step resets (avoid diagonal artifact even within the same run)
                breaks = np.where(np.diff(steps) < 0)[0] + 1
                segs = np.split(np.arange(len(steps)), breaks)
                for idx in segs:
                    s = steps[idx]; y = vals[idx]
                    m = np.isfinite(s) & np.isfinite(y)
                    if np.any(m):
                        ax.plot(s[m], y[m], label=f"run {rid}")
                        plotted_any = True
    
            if not plotted_any:
                plt.close(fig); continue
            ax.set_xlabel("step"); ax.set_ylabel(field); ax.set_title(field)
            ax.legend(loc="best", fontsize=8, ncols=min(len(run_ids), 3))
            _safe_savefig(fig, self.dir_plots / f"global_{field}.png")
           


    # replace _plot_agent_timeseries() entirely
    def _plot_agent_timeseries(self):
        rows = _load_jsonl(self.dir_run / self.cfg.agent_jsonl)
        if not rows:
            return
    
        have_run = any("run_id" in r for r in rows)
        if have_run:
            run_ids = sorted({int(r["run_id"]) for r in rows if "run_id" in r})
        else:
            run_ids = [1]
            for r in rows: r["run_id"] = 1
    
        # union fields
        all_keys = set().union(*[r.keys() for r in rows])
        preferred = ["E_self","mask_sum","phi_norm_mean","phi_model_norm_mean"]
        fields = [k for k in preferred if k in all_keys] + [
            k for k in sorted(all_keys) if k not in ("step","agent","ts","run_id") and any(_is_num(rr.get(k)) for rr in rows)
        ]
    
        from collections import defaultdict
        # group by (run, agent)
        by_ra = defaultdict(list)
        for r in rows:
            aid = r.get("agent")
            rid = r.get("run_id", 1)
            if aid is None: continue
            by_ra[(rid, aid)].append(r)
    
        for field in fields:
            fig, ax = _safe_fig(figsize=(8,3), dpi=self.cfg.dpi)
            plotted_any = False
            for (rid, aid), lst in by_ra.items():
                lst = sorted(lst, key=lambda r: _to_num(r.get("step")))
                s = np.array([_to_num(r.get("step")) for r in lst], dtype=float)
                y = np.array([_to_num(r.get(field)) for r in lst], dtype=float)
                # break on step resets
                breaks = np.where(np.diff(s) < 0)[0] + 1
                segs = np.split(np.arange(len(s)), breaks)
                for idx in segs:
                    ss = s[idx]; yy = y[idx]
                    m = np.isfinite(ss) & np.isfinite(yy)
                    if np.any(m):
                        ax.plot(ss[m], yy[m], label=f"{aid}@r{rid}")
                        plotted_any = True
            if not plotted_any:
                plt.close(fig); continue
            ax.set_xlabel("step"); ax.set_ylabel(field); ax.set_title(field)
            ax.legend(loc="best", fontsize=7, ncols=min(len(run_ids), 4))
            _safe_savefig(fig, self.dir_plots / f"agent_{field}.png")
            


    # --------------------------
    # Snapshots (per agent fields)
    # --------------------------
    def maybe_snapshot(self, step: int, ctx: Any, agents: Iterable[Any]):
        if not self.cfg.enable_snapshots or (step % self.cfg.snapshot_every_steps) != 0:
            return
        # Create a folder per step
        d = self.dir_snaps / f"step_{step:06d}"
        _ensure_dir(d)
        for a in agents:
            self._snapshot_agent(step, d, a, ctx)

    def _snapshot_agent(self, step: int, dstep: Path, a: Any, ctx: Any):
        # Expect agent fields: mask, phi (q/p), mu_q, mu_p, sigma_q, sigma_p
        # Robust: never throw—snapshots must not crash the run.
        try:
            aid = getattr(a, "agent_id", None) or getattr(a, "id", "?")
        except Exception:
            aid = "?"
    
        def _maybe(name: str, getter, *, is_cov: bool = False):
            try:
                arr = getter()
                if arr is None:
                    return
                if is_cov:
                    # Σ shape (H,W,K,K) => per-pixel logdet
                    arr = np.asarray(arr, np.float32)
                    H, W, K = arr.shape[0], arr.shape[1], arr.shape[-1]
                    arr2 = arr.reshape(H * W, K, K)
                    logdet = np.empty((H * W,), dtype=np.float32)
                    for i in range(H * W):
                        try:
                            c = np.linalg.cholesky(arr2[i])
                            logdet[i] = 2.0 * float(np.sum(np.log(np.diag(c))))
                        except Exception:
                            logdet[i] = np.nan
                    img = logdet.reshape(H, W)
                else:
                    img = np.asarray(arr, np.float32)
                if np.any(np.isfinite(img)):
                    self._save_heatmap(img, dstep / f"Agent {aid}_{name}.png")
            except Exception:
                pass
    
        # --- tiny local helper for this scope: fetch A from ctx.fields["A"] ---
        def _get_A_from_ctx_fields(ctx_obj):
            try:
                A = getattr(ctx_obj, "fields", {}).get("A", None)
                if A is None:
                    return None
                A = np.asarray(A, np.float32)
                if A.ndim == 4 and A.shape[-2:] == (2, 3):
                    return A
                if A.ndim == 3 and A.shape[-1] == 3:
                    # legacy (H,W,3) -> promote to (H,W,2,3) with Ay=0
                    H, W = A.shape[:2]
                    A_up = np.zeros((H, W, 2, 3), dtype=np.float32)
                    A_up[..., 0, :] = A
                    return A_up
                return None
            except Exception:
                return None
    
        # --- existing snapshots ---
        _maybe("phi_norm",        lambda: _field_norm(getattr(a, "phi", None)))
        _maybe("phi_model_norm",  lambda: _field_norm(getattr(a, "phi_model", None)))
        _maybe("mu_q_norm",       lambda: _field_norm(getattr(a, "mu_q_field", None)))
        _maybe("mu_p_norm",       lambda: _field_norm(getattr(a, "mu_p_field", None)))
        _maybe("sigma_q_logdet",  lambda: np.asarray(getattr(a, "sigma_q_field", None)), is_cov=True)
        _maybe("sigma_p_logdet",  lambda: np.asarray(getattr(a, "sigma_p_field", None)), is_cov=True)
    
        # --- A-field & curvature visualizations (from ctx.fields["A"]) ---
        try:
            A = _get_A_from_ctx_fields(ctx)
            if A is not None:
                Ax, Ay = A[..., 0, :], A[..., 1, :]
                self._save_heatmap(_field_norm(Ax), dstep / f"{aid}_A_x_norm.png")
                self._save_heatmap(_field_norm(Ay), dstep / f"{aid}_A_y_norm.png")
    
                F, E_F = _curvature_from_A(A)  # expects (H,W,2,3) A
                self._save_heatmap(np.linalg.norm(F, axis=-1), dstep / f"{aid}_Curv_A_norm.png")
                self._save_heatmap(E_F,                      dstep / f"{aid}_Curv_A_energy.png")
    
                # Covariant φ smoothness (q)
                if getattr(a, "phi", None) is not None:
                    phi_q = np.asarray(a.phi, np.float32)
                    DxN, DyN, Ephi = _covariant_phi_terms(phi_q, A)
                    self._save_heatmap(DxN,  dstep / f"Agent {aid}_phi_Curv_x_norm.png")
                    self._save_heatmap(DyN,  dstep / f"Agent {aid}_phi_Curv_y_norm.png")
                    self._save_heatmap(Ephi, dstep / f"Agent {aid}_phi_Curv_energy.png")
    
                # Covariant φ̃ smoothness (p)
                if getattr(a, "phi_model", None) is not None:
                    phi_p = np.asarray(a.phi_model, np.float32)
                    DxN, DyN, Ephi = _covariant_phi_terms(phi_p, A)
                    self._save_heatmap(DxN,  dstep / f"Agent {aid}_phi_model_Curv_x_norm.png")
                    self._save_heatmap(DyN,  dstep / f"Agent {aid}_phi_model_Curv_y_norm.png")
                    self._save_heatmap(Ephi, dstep / f"Agent {aid}_phi_model_Curv_energy.png")
            else:
                # optional breadcrumb so you know why nothing saved
                try:
                    print(f"[SNAP] step={step} aid={aid}: ctx.fields['A'] not set", flush=True)
                except Exception:
                    pass
        except Exception:
            pass
    
       


    def _save_heatmap(self, img: np.ndarray, path: Path):
        img = np.asarray(img)
        if img.ndim == 3 and img.shape[-1] in (3, 4):
            # RGB or RGBA image—save directly
            plt.imsave(path, _downsample(img, self.cfg.max_side))
            return
        if img.ndim > 2:
            # reduce via norm across channels
            img = np.linalg.norm(img, axis=-1)
        img = np.nan_to_num(img, nan=0.0, posinf=0.0, neginf=0.0)
        img = _downsample(img, self.cfg.max_side)
        lo, hi = _robust_min_max(img, self.cfg.robust_low, self.cfg.robust_high)
        fig, ax = _safe_fig(figsize=(4, 4), dpi=self.cfg.dpi)
        im = ax.imshow(img, cmap=self.cfg.cmap, vmin=lo, vmax=hi, origin="lower")
        ax.set_xticks([]); ax.set_yticks([])
        fig.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
        _safe_savefig(fig, path)



# ------------------------------
# Convenience feature extractors
# ------------------------------

def _field_norm(field: Optional[np.ndarray]) -> Optional[np.ndarray]:
    if field is None:
        return None
    arr = np.asarray(field)
    if arr.ndim >= 3:
        return np.linalg.norm(arr, axis=-1)
    elif arr.ndim == 2:
        return np.abs(arr)
    else:
        return None


