# -*- coding: utf-8 -*-
"""
Created on Mon Aug 11 16:05:57 2025

@author: chris and christine
"""

import numpy as np         
from typing import Optional
from transport.bundle_morphism_utils import build_intertwiner_bases

from transport.transport_cache import (
    set_morphism_bases as _set_bases,
    get_morphism_bases as _get_bases,
)

import core.config as config
from core.numerical_utils import sanitize_sigma, safe_inv




def ensure_transforms(
    targets,
    generators_q=None,
    generators_p=None,
    *,
    ctx=None,
    intertwiner_method="casimir",     # "casimir" | "auto" | "nullspace"
    data_for_alignment=None,
    fro_target: float | None = None,
):
    """
    Ensure each target agent has *frozen* geometric morphism bases (Phi0, Phit0)
    persisted in the central cache. If already present, we DO NOT rebuild.

    Policy:
      - Prefer explicit generators_q/p, else use agent-attached fields.
      - Validate shapes (3, K, K) against agent fibers.
      - Build bases ONCE via build_intertwiner_bases(...) and persist.
      - Optionally rescale both bases to a Frobenius norm target (coherent).
      - Never write Phi0/Phi~0 onto the agent; the transport cache owns them.
    """
    
    if not targets:
        return
    if ctx is None:
        raise RuntimeError("ensure_transforms: ctx is required (cache-centric design)")


    for a in targets:
        if a is None:
            continue

        # Infer fiber sizes from agent fields
        Kq = int(np.asarray(a.mu_q_field).shape[-1])
        Kp = int(np.asarray(a.mu_p_field).shape[-1])

        # Effective generators (prefer explicit, else agent-attached)
        Gq_eff = generators_q if generators_q is not None else getattr(a, "generators_q", None)
        Gp_eff = generators_p if generators_p is not None else getattr(a, "generators_p", None)
        if Gq_eff is None or Gp_eff is None:
            raise ValueError("ensure_transforms: generators_q/generators_p must be provided or attached to each agent beforehand")

        Gq_eff = np.asarray(Gq_eff, np.float32)
        Gp_eff = np.asarray(Gp_eff, np.float32)
        if Gq_eff.shape != (3, Kq, Kq):
            raise ValueError(f"ensure_transforms: generators_q shape mismatch: expected {(3, Kq, Kq)}, got {Gq_eff.shape}")
        if Gp_eff.shape != (3, Kp, Kp):
            raise ValueError(f"ensure_transforms: generators_p shape mismatch: expected {(3, Kp, Kp)}, got {Gp_eff.shape}")

        # --- fetch if present; build once otherwise ---
        cached = _get_bases(ctx, a)
        if cached is not None:
            # Already frozen — skip rebuild entirely
            continue

        # Build geometric bases ONCE for these generators
        Phi0, Phit0, meta = build_intertwiner_bases(
            Gq_eff,
            Gp_eff,
            method=str(intertwiner_method),
            data=data_for_alignment,
            return_meta=True,
        )

        
        # Persist in central cache (do NOT attach to agent)
        _set_bases(ctx, a, np.asarray(Phi0, np.float32), np.asarray(Phit0, np.float32), allow_overwrite=False)
       

# ---------------------------------------------------------------------
# Public entry points
# ---------------------------------------------------------------------

def preprocess_all_agents(agents, params=None, G_q=None, G_p=None, *, ctx: Optional[object] = None):
    """
    Build/refresh: generators, Σ sanitize + inverses, condition proxies,
    (optionally) Fisher. Also pre-warms exp grids via transport cache.
    Safe to call repeatedly; idempotent per step.
    """
    params = params or {}
    if ctx is not None:
        params = dict(params)
        params["runtime_ctx"] = ctx

    agents = [a for a in (agents or []) if a is not None]
    if not agents:
        return

    # preprocess structural fields per agent
    for a in agents:
        preprocess_agent_fields(a, params, G_q=G_q, G_p=G_p, ctx=ctx)





# ---------------------------------------------------------------------
# Per-agent preprocessing
# ---------------------------------------------------------------------
def preprocess_agent_fields(agent, params=None, G_q=None, G_p=None, *, ctx: Optional[object] = None):
    """
    Prepare per-agent fields (generators, Σ sanitize/inv, cond proxies, Fisher).
    NOTE: No transport pre-warming here (E/Jinv/Ω). That is handled centrally by ensure_dirty(...).
    """
    

    params     = params or {}
    eps        = float(getattr(config, "eps", 1e-8))
   
    strict     = bool(params.get("sanitize_strict", True))
    step_tag   = int(params.get("step", getattr(ctx, "global_step", -1) or -1))

    # idempotency per step
    if getattr(agent, "_preprocessed_step", None) == step_tag and step_tag >= 0:
        return
   
    if not hasattr(agent, "mask") or agent.mask is None:
        H, W = agent.mu_q_field.shape[:2]
        agent.mask = np.ones((H, W), np.float32)

    # ---------------- SPD sanitize & inverses ----------------
    agent.sigma_q_field = sanitize_sigma(agent.sigma_q_field, strict=strict, eps=eps)
    agent.sigma_p_field = sanitize_sigma(agent.sigma_p_field, strict=strict, eps=eps)
    agent.sigma_q_inv   = safe_inv(agent.sigma_q_field, eps=eps)
    agent.sigma_p_inv   = safe_inv(agent.sigma_p_field, eps=eps)

    

    # ---------------- optional SPD assert ----------------
    if bool(getattr(config, "assert_spd_after_sanitize", False)):
        wq = np.linalg.eigvalsh(0.5 * (agent.sigma_q_field + np.swapaxes(agent.sigma_q_field, -1, -2)))
        wp = np.linalg.eigvalsh(0.5 * (agent.sigma_p_field + np.swapaxes(agent.sigma_p_field, -1, -2)))
        floor = float(getattr(config, "sigma_eig_floor", 1e-6))
        if (wq <= floor).any() or (wp <= floor).any():
            raise RuntimeError("Non-SPD Σ after sanitize.")

    agent._preprocessed_step = step_tag





def zero_all_gradients(agent):
    """
    Zero (and if missing, create) all gradient buffers,
    keeping legacy aliases in sync and ensuring arrays are writeable.
    """
    def ensure_buf(name, like):
        arr = getattr(agent, name, None)
        if arr is None and like is not None:
            arr = np.zeros_like(like)
        elif arr is not None and not arr.flags.writeable:
            arr = np.array(arr, copy=True)
        setattr(agent, name, arr)
        return arr

    # Canonical grads (create from fields if needed)
    g_mu_q   = ensure_buf("grad_mu_q",    getattr(agent, "mu_q_field", None))
    g_sg_q   = ensure_buf("grad_sigma_q", getattr(agent, "sigma_q_field", None))
    g_mu_p   = ensure_buf("grad_mu_p",    getattr(agent, "mu_p_field", None))
    g_sg_p   = ensure_buf("grad_sigma_p", getattr(agent, "sigma_p_field", None))
    g_phi    = ensure_buf("grad_phi",       getattr(agent, "phi", None))
    g_phit   = ensure_buf("grad_phi_tilde", getattr(agent, "phi_model", None))


 
    # Keep legacy aliases in sync (as references, not copies)
    if g_mu_q is not None:
        agent.grad_mu_q_field = g_mu_q
    if g_sg_q is not None:
        agent.grad_sigma_q_field = g_sg_q
    if g_mu_p is not None:
        agent.grad_mu_p_field = g_mu_p
    if g_sg_p is not None:
        agent.grad_sigma_p_field = g_sg_p

    # Zero safely
    for arr in (g_mu_q, g_sg_q, g_mu_p, g_sg_p, g_phi, g_phit):
        if isinstance(arr, np.ndarray):
            arr.fill(0)



