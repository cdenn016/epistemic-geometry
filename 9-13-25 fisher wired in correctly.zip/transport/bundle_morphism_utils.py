
from __future__ import annotations
import numpy as np
from typing import Dict,Tuple, Optional
from core.omega import exp_lie_algebra_irrep
import core.config as config
from transport.transport_cache import E_grid
from core.numerical_utils import safe_omega_inv
from transport.transport_cache import set_morphism_bases  
# =============================================================================
#                         Direct (gauge-covariant) morphisms
# =============================================================================

def compute_direct_morphisms(
    *,
    phi: np.ndarray,
    phi_model: np.ndarray,
    generators_q: np.ndarray,
    generators_p: np.ndarray,
    Phi_0: np.ndarray,
    Phi_tilde_0: np.ndarray,
    ctx: Optional[object] = None,
    group_name: Optional[str] = None,
    return_dtype: Optional[np.dtype] = np.float32,
):
    """
    Build morphisms
      Φ       = E_p  Φ_0       (E_q)^{-T}
      Φ̃ (tilde)= E_q  Φ̃_0      (E_p)^{-T}

    Shapes:
      phi, phi_model : (H,W,3)  (axis-angle per pixel)
      generators_*   : (K,3,3)  or appropriate irrep shape
      E_q, E_p       : (H,W,Kq,Kq), (H,W,Kp,Kp)
      Φ_0            : (Kp,Kq) or (H,W,Kp,Kq)
      Φ̃_0           : (Kq,Kp) or (H,W,Kq,Kp)
    """
   

    # promote to fp64 internally
    phi64       = np.asarray(phi,       dtype=np.float64)
    phi_m64     = np.asarray(phi_model, dtype=np.float64)
    Gq64        = np.asarray(generators_q, dtype=np.float64)
    Gp64        = np.asarray(generators_p, dtype=np.float64)
    Phi0        = np.asarray(Phi_0,       dtype=np.float64)
    PhiT0       = np.asarray(Phi_tilde_0, dtype=np.float64)

    
    # E-grids: use cache only if you have a real agent identity the cache recognizes;
    # otherwise compute directly to avoid guaranteed cache misses.
    use_cache = (ctx is not None) and (getattr(ctx, "cache", None) is not None) \
                and hasattr(ctx, "agent") and (ctx.agent is not None)

    if use_cache:
        # preferred path: your existing cache accessor (name may be tc_E_grid/E_grid)
        Eq64 = E_grid(ctx, ctx.agent, which="q").astype(np.float64, copy=False)
        Ep64 = E_grid(ctx, ctx.agent, which="p").astype(np.float64, copy=False)
    else:
        # direct exponentiation (no cache spam)
        Eq64 = exp_lie_algebra_irrep(phi64,   Gq64).astype(np.float64, copy=False)
        Ep64 = exp_lie_algebra_irrep(phi_m64, Gp64).astype(np.float64, copy=False)



        # true inverse then transpose
    Eq_inv = safe_omega_inv(Eq64).astype(np.float64, copy=False)  # (...,Kq,Kq)
    Ep_inv = safe_omega_inv(Ep64).astype(np.float64, copy=False)  # (...,Kp,Kp)
    Eq_invT = np.swapaxes(Eq_inv, -1, -2)
    Ep_invT = np.swapaxes(Ep_inv, -1, -2)

    # dims
    Kq = int(Eq64.shape[-1])
    Kp = int(Ep64.shape[-1])

    # broadcast Φ_0, Φ̃_0 to grid if needed (no copy)
    grid_shape = Eq64.shape[:-2]
    if Phi0.ndim == 2:
        if Phi0.shape != (Kp, Kq):
            raise ValueError(f"Phi_0 shape {Phi0.shape} != (Kp,Kq)=({Kp},{Kq})")
        Phi0 = np.broadcast_to(Phi0, grid_shape + (Kp, Kq))
    else:
        if Phi0.shape[-2:] != (Kp, Kq):
            raise ValueError(f"Phi_0 trailing shape {Phi0.shape[-2:]} != (Kp,Kq)")
    if PhiT0.ndim == 2:
        if PhiT0.shape != (Kq, Kp):
            raise ValueError(f"Phi_tilde_0 shape {PhiT0.shape} != (Kq,Kp)=({Kq},{Kp})")
        PhiT0 = np.broadcast_to(PhiT0, grid_shape + (Kq, Kp))
    else:
        if PhiT0.shape[-2:] != (Kq, Kp):
            raise ValueError(f"Phi_tilde_0 trailing shape {PhiT0.shape[-2:]} != (Kq,Kp)")

    # Φ = E_p Φ0 (E_q)^{-T},  Φ̃ = E_q Φ̃0 (E_p)^{-T}
    Phi       = np.einsum("...ik,...kj,...jl->...il", Ep64, Phi0,  Eq_invT, optimize=True)
    Phi_tilde = np.einsum("...ik,...kj,...jl->...il", Eq64, PhiT0, Ep_invT, optimize=True)

    # cast out
    out_dtype = return_dtype or np.float32
    return Phi.astype(out_dtype, copy=False), Phi_tilde.astype(out_dtype, copy=False)




# =============================================================================
#                             Init / Recompute on agent
# =============================================================================



def mark_morphism_dirty(agent, *, ctx=None) -> None:
    if hasattr(agent, "mark_morphism_dirty") and callable(agent.mark_morphism_dirty):
        agent.mark_morphism_dirty()
        return
    setattr(agent, "morphisms_dirty", True)
    # Optional: notify runtime once you actually wire it
    from updates.update_refresh_utils import mark_dirty
    if ctx is not None:
        mark_dirty(ctx, agent, kl=False)





# =============================================================================
#                            Morphism field generators
# =============================================================================




# --------------------------- Public Entry Points ---------------------------------
# --- add near the top of the file (e.g., alongside other helpers) ---
def _as_3KK(G: np.ndarray) -> np.ndarray:
    """
    Ensure generator array is (3, K, K).
    Accepts (3,K,K) or (K,K,3); raises for anything else.
    """
    import numpy as np
    G = np.asarray(G, np.float64)
    if G.ndim != 3:
        raise ValueError(f"Generators must be 3D; got {G.shape}")
    # already (3,K,K)
    if G.shape[0] == 3 and G.shape[1] == G.shape[2]:
        return G
    # (K,K,3) -> (3,K,K)
    if G.shape[-1] == 3 and G.shape[0] == G.shape[1]:
        return np.moveaxis(G, -1, 0)
    raise ValueError(f"Unrecognized generator shape {G.shape}; expected (3,K,K) or (K,K,3)")



def build_intertwiner_bases(
    G_q: np.ndarray,
    G_p: np.ndarray,
    *,
    method: str = "casimir",         # "casimir" | "casimir_strict" | "nullspace" | "auto"
    data: Optional[Dict[str, np.ndarray]] = None,
    l_tol: float = 1e-6,
    nullspace_tol: float = 1e-9,
    max_rank: Optional[int] = None,
    return_meta: bool = False,
    on_hom0: str = "zero",           # "zero" | "raise"
) -> Tuple[np.ndarray, np.ndarray, Optional[dict]]:
    """
    Returns (Phi0, Phit0[, meta]) as rectangular intertwiners between two real SO(3) reps.
    Generators may be (3,K,K) or (K,K,3); normalized internally to (3,K,K).
    NEVER fabricates LS 'intertwiners' when Hom=0.
    """
    G_q = _as_3KK(G_q)
    G_p = _as_3KK(G_p)

    method = method.lower()
    if method not in ("casimir", "casimir_strict", "nullspace", "auto"):
        method = "casimir"

    def _hom0_return(Kp: int, Kq: int, *, reason: str):
        meta = {"hom_dim": 0, "matches": [], "reason": reason, "dims": {"Kq": Kq, "Kp": Kp}}
        if on_hom0 == "raise":
            raise ValueError(f"No nonzero intertwiner: {reason} (Kq={Kq}, Kp={Kp})")
        Phi0 = np.zeros((Kp, Kq), dtype=np.float32)
        Phit0 = np.zeros((Kq, Kp), dtype=np.float32)
        return Phi0, Phit0, meta

    Kq = G_q.shape[-1]
    Kp = G_p.shape[-1]

    # 1) Casimir block matching (preferred)
    if method in ("casimir", "casimir_strict", "auto"):
        Phi0, meta = _build_intertwiner_casimir(G_q, G_p, data=data, l_tol=l_tol, max_rank=max_rank)
        if Phi0 is not None:
            Phit0 = _choose_tilde_from_base_safe(Phi0)
            return (Phi0.astype(np.float32), Phit0.astype(np.float32), meta if return_meta else None)

        # No shared ℓ content: decide by mode
        if method == "casimir_strict":
            return _hom0_return(Kp, Kq, reason="no_shared_ell_casimir")

        # "casimir"/"auto": allow nullspace fallback, but ONLY if exact nullspace exists.
        Phi0_ns, meta_ns = _build_intertwiner_nullspace(G_q, G_p, data=data, tol=nullspace_tol, max_rank=max_rank)
        if meta_ns.get("hom_dim", 0) > 0:
            Phit0_ns = _choose_tilde_from_base_safe(Phi0_ns)
            return (Phi0_ns.astype(np.float32), Phit0_ns.astype(np.float32), meta_ns if return_meta else None)
        # nullspace empty → Hom=0
        return _hom0_return(Kp, Kq, reason="no_shared_ell_and_nullspace_empty")

    # 2) Nullspace mode (exact constraints only)
    if method == "nullspace":
        Phi0_ns, meta_ns = _build_intertwiner_nullspace(G_q, G_p, data=data, tol=nullspace_tol, max_rank=max_rank)
        if meta_ns.get("hom_dim", 0) == 0:
            return _hom0_return(Kp, Kq, reason="nullspace_empty")
        Phit0_ns = _choose_tilde_from_base_safe(Phi0_ns)
        return (Phi0_ns.astype(np.float32), Phit0_ns.astype(np.float32), meta_ns if return_meta else None)


def initialize_intertwiners_for_agent(
    ctx,
    agent,
    G_q: np.ndarray, G_p: np.ndarray,
    *,
    method: str = "casimir",
    data: Optional[Dict[str, np.ndarray]] = None,
    allow_overwrite: bool = False,
) -> Tuple[np.ndarray, np.ndarray]:
    """
    Build (Φ0, Φ̃0) once and freeze them into your persistent cache for this agent.
    Assumes you added the 'allow_overwrite' kwarg to set_morphism_bases(...).
    """
    Phi0, Phit0, _ = build_intertwiner_bases(G_q, G_p, method=method, data=data, return_meta=True)
    # Persist exactly once (unless you explicitly allow overwrite)
    
    set_morphism_bases(ctx, agent, Phi0, Phit0, allow_overwrite=bool(allow_overwrite))
    return Phi0, Phit0


# --------------------------- Casimir (ℓ-block) path -------------------------------

def _build_intertwiner_casimir(G_q, G_p, *, data=None, l_tol=1e-6, max_rank=None):
    G_q = _as_3KK(G_q)
    G_p = _as_3KK(G_p)
    Cq = _casimir_from_generators(G_q); λq, Wq = np.linalg.eigh(Cq)
    Cp = _casimir_from_generators(G_p); λp, Wp = np.linalg.eigh(Cp)

    # NEW: use rel-tol degeneracy clustering (scale-invariant)
    blocks_q = _cluster_into_l_blocks(λq, Wq, rel_tol=1e-4)
    blocks_p = _cluster_into_l_blocks(λp, Wp, rel_tol=1e-4)

    # Match blocks by d (2l+1); don’t rely on absolute λ
    by_dim_q = {}
    for b in blocks_q.values():
        by_dim_q.setdefault(b["d"], []).append(b["W"])
    by_dim_p = {}
    for b in blocks_p.values():
        by_dim_p.setdefault(b["d"], []).append(b["W"])

    common_ds = sorted(set(by_dim_q.keys()).intersection(by_dim_p.keys()))
    if not common_ds:
        return (None, {"reason": "no_l_overlap"})  # will be handled by caller

    Kq = G_q.shape[-1]; Kp = G_p.shape[-1]
    Phi0 = np.zeros((Kp, Kq), dtype=np.float64)
    meta = {"used_dims": [], "rank_by_dim": {}, "path": "casimir"}

    # Optional data-aware mixing on multiplicities can be kept as before.
    for d in common_ds:
        Q_list = by_dim_q[d]   # each (Kq, m_q*d) with orthonormal cols
        P_list = by_dim_p[d]   # each (Kp, m_p*d)
        # concatenate copies -> treat multiplicity collectively
        Wq_d = np.concatenate(Q_list, axis=1)
        Wp_d = np.concatenate(P_list, axis=1)
        # multiplicities
        m_q = Wq_d.shape[1] // d
        m_p = Wp_d.shape[1] // d
        m   = min(m_q, m_p)
        if m == 0:
            continue
        # split into per-copy blocks
        Q_blocks = [Wq_d[:, i*d:(i+1)*d] for i in range(m_q)]
        P_blocks = [Wp_d[:, i*d:(i+1)*d] for i in range(m_p)]
        # identity mixer on multiplicities (orthogonal per copy)
        for i in range(m):
            Phi0 += P_blocks[i] @ Q_blocks[i].T
        meta["used_dims"].append(d)
        meta["rank_by_dim"][d] = m * d

    if max_rank is not None:
        Phi0 = _best_rank_approx(Phi0, rank=max_rank)

    return (Phi0, meta)


# ------------------------------ Nullspace path -----------------------------------

def _build_intertwiner_nullspace(G_q: np.ndarray, G_p: np.ndarray, *, tol: float = 1e-9,
                                 data: Optional[Dict[str, np.ndarray]] = None,
                                 max_rank: Optional[int] = None) -> Tuple[np.ndarray, dict]:
    G_q = _as_3KK(G_q)
    G_p = _as_3KK(G_p)
    Kq, Kp = G_q.shape[-1], G_p.shape[-1]
    Iq = np.eye(Kq); Ip = np.eye(Kp)
    rows = []
    for a in range(3):
        A = np.kron(Iq, G_p[a]) - np.kron(G_q[a].T, Ip)
        rows.append(A)
    M = np.concatenate(rows, axis=0)

    # Nullspace via SVD
    U, S, Vh = np.linalg.svd(M, full_matrices=False)
    mask = (S <= tol)
    if not np.any(mask):
        # numerically tiny but nonzero; take the smallest singular vector
        basis = Vh[-1:, :]
    else:
        basis = Vh[mask, :]        # (m, Kp*Kq)
    # Orthonormalize nullspace basis vectors (Frobenius) via QR
    Q, _ = np.linalg.qr(basis.T)   # (Kp*Kq, m) -> Q has orthonormal columns
    B = Q                          # (Kp*Kq, m_eff)

    # Default: pick the first basis vector -> simplest nonzero intertwiner
    coeff = np.zeros((B.shape[1],), dtype=np.float64)
    coeff[0] = 1.0

    # Data-aware LS in span(B): minimize Σ ||Φ0 μ_q - μ_p||_2^2
    if data is not None:
        mu_q = np.asarray(data.get("mu_q", None))
        mu_p = np.asarray(data.get("mu_p", None))
        if mu_q is not None and mu_q.size and mu_p is not None and mu_p.size:
            Qs = _thin_samples(mu_q.reshape(-1, mu_q.shape[-1]), max_samples=4096)  # (N, Kq)
            Ps = _thin_samples(mu_p.reshape(-1, mu_p.shape[-1]), max_samples=4096)  # (N, Kp)
            # Build design matrix A * coeff ≈ b, with A = [ (Bi mat) @ Qs^T ] stacked
            # We solve per-sample in Kp, so do least squares per output dim jointly:
            # vec(Φ0) = B @ coeff  =>  Φ0 = reshape(B@coeff, (Kp, Kq))
            # We choose coeff that minimizes ||Φ0 Qs^T - Ps^T||_F^2
            # This is linear in coeff:
            # Let Zi = reshape(B[:,i], Kp,Kq) @ Qs^T  -> (Kp,N)
            # Stack Zi along i to get (Kp*N, m), target vec(Ps^T) = vec(Ps.T)
            Z_blocks = []
            for i in range(B.shape[1]):
                Zi = (B[:, i].reshape(Kp, Kq) @ Qs.T)  # (Kp, N)
                Z_blocks.append(Zi.reshape(-1, 1))     # (Kp*N, 1)
            A_ls = np.concatenate(Z_blocks, axis=1)    # (Kp*N, m)
            b_ls = Ps.T.reshape(-1)                    # (Kp*N,)
            # regularized least squares to avoid degeneracy
            reg = 1e-8
            coeff, *_ = np.linalg.lstsq(A_ls.T @ A_ls + reg*np.eye(A_ls.shape[1]), A_ls.T @ b_ls, rcond=None)

    vecPhi = (B @ coeff).reshape(Kp, Kq)
    Phi0 = vecPhi
    if max_rank is not None:
        Phi0 = _best_rank_approx(Phi0, rank=max_rank)

    meta = {"nullspace_dim": B.shape[1]}
    return (Phi0, meta)


# ------------------------------ Internal Helpers ---------------------------------




def orthogonalize_intertwiner(Phi0: np.ndarray) -> np.ndarray:
    """
    If Phi0 is square, project to the nearest orthogonal matrix via polar decomposition.
    For rectangular maps, returns Phi0 unchanged.
    """
    Kp, Kq = Phi0.shape
    if Kp != Kq:
        return Phi0
    U, _, Vt = np.linalg.svd(Phi0, full_matrices=False)
    return (U @ Vt).astype(Phi0.dtype, copy=False)




def _casimir_from_generators(G: np.ndarray) -> np.ndarray:
    """Casimir C = Gx^2 + Gy^2 + Gz^2 for a real rep."""
    C = np.zeros((G.shape[-1], G.shape[-1]), dtype=np.float64)
    for a in range(3):
        C += G[a] @ G[a]
    return 0.5 * (C + C.T)  # enforce symmetry numerically


def _cluster_into_l_blocks(λ: np.ndarray, W: np.ndarray, rel_tol: float = 1e-4):
    """
    Scale-invariant clustering of Casimir eigenpairs by degeneracy.
    Groups consecutive eigenvalues whose relative gap ≤ rel_tol.
    For each cluster of size g, pick d = largest odd divisor of g;
    set multiplicity m = g // d and split the cluster into m blocks of size d.
    Returns dict: l -> {"W": (K, m*d), "d": d, "m": m}
    """
    K = W.shape[0]
    # sort by eigenvalue
    idx = np.argsort(λ)
    λs  = λ[idx]
    Ws  = W[:, idx]

    # cluster by relative tolerance
    clusters = []
    start = 0
    for i in range(1, len(λs) + 1):
        if i == len(λs):
            clusters.append((start, i))
            break
        # relative gap
        denom = max(abs(λs[i-1]), abs(λs[i]), 1.0)
        if abs(λs[i] - λs[i-1]) > rel_tol * denom:
            clusters.append((start, i))
            start = i

    blocks = {}
    # helper: largest odd divisor
    def largest_odd_divisor(n: int) -> int:
        while n % 2 == 0 and n > 0:
            n //= 2
        return max(1, n)

    l_counter = 0
    for (lo, hi) in clusters:
        g = hi - lo                     # cluster size
        if g <= 0:
            continue
        d = largest_odd_divisor(g)      # irrep dim = 2l+1 (odd)
        m = g // d
        if d <= 0 or m <= 0:
            continue
        # take this cluster’s eigenvectors
        Wc = Ws[:, lo:hi]               # (K, g)
        # split into m blocks of size d
        keep = Wc[:, : m*d]             # truncate if any tiny overhang
        l_val = (d - 1) // 2
        blocks[l_counter] = {"W": keep, "d": d, "m": m, "ell": l_val}
        l_counter += 1

    return blocks


def _thin_samples(X: np.ndarray, max_samples: int = 4096) -> np.ndarray:
    """Uniformly sub-sample rows to at most max_samples."""
    N = X.shape[0]
    if N <= max_samples:
        return X
    idx = np.linspace(0, N-1, num=max_samples, dtype=int)
    return X[idx]


# --- Safer choice of Φ̃0 from Φ0 (transpose when square & well-conditioned; else pinv) ---
def _choose_tilde_from_base_safe(Phi0: np.ndarray) -> np.ndarray:
    Kp, Kq = Phi0.shape
    if Kp == Kq:
        # condition check via singular values
        s = np.linalg.svd(Phi0, compute_uv=False)
        if s.size and s.min() > 1e-8 and s.max() < 1e8:
            return Phi0.T
    return np.linalg.pinv(Phi0)




def _best_rank_approx(M: np.ndarray, rank: int) -> np.ndarray:
    """Best Frobenius-norm rank-k approximation via SVD."""
    U, S, Vt = np.linalg.svd(M, full_matrices=False)
    k = min(rank, len(S))
    return (U[:, :k] * S[:k]) @ Vt[:k, :]






# =========================== End Intertwiner Builder ==============================


