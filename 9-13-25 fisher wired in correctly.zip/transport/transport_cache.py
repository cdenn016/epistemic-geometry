
from __future__ import annotations
from typing import Any, Iterable, Optional, Sequence
import numpy as np

# Your existing utilities
from core.omega import exp_lie_algebra_irrep, retract_phi_principal
from core.numerical_utils import safe_omega_inv
import core.config as CFG
import hashlib
import math
from typing import Tuple, Dict


"""
Cache Policy — Rule of One
1) One cache hub: runtime_ctx.cache (cleared once per step).
2) One facade to read/write: this file (E_grid, Omega, Jinv_grid, Phi, Phi_tilde, Lambda_*).
3) One warm point per step: ensure_dirty(...) — nowhere else.
Consumers must never pre-warm; they just call the facade.
"""

def _ctx_cfg(ctx):
    # Prefer ctx.config if you have one; otherwise fall back to CFG module
    src = getattr(ctx, "config", None)
    def _get(k, default=None):
        if src is not None and k in src:
            return src[k]
        return getattr(CFG, k, default)
    return {
        "group_name": _get("group_name", "so3"),
        "phi_clip": _get("phi_clip", 2.8),
        "periodic_wrap": _get("periodic_wrap", True),
        "so3_irreps_are_orthogonal": _get("so3_irreps_are_orthogonal", True),
        "mask_edge_soften_sigma": _get("mask_edge_soften_sigma", 0.0),
    }



def _gensig(G: np.ndarray) -> tuple[int, str]:
    """
    Small, stable signature for a generator set:
      (K, sha256(bytes))
    """
    G = np.asarray(G, np.float32, order="C")
    return (int(G.shape[-2]), hashlib.sha256(G.tobytes()).hexdigest())



def _sanitize_axis_angle(
    phi,
    *,
    max_theta: Optional[float] = None,
    margin: Optional[float] = None,
    strict_numerics: bool = True,    # NEW: fail fast on nonfinite input
    recover: Optional[str] = None,   # NEW: None | "nan" | "zero" (used only if strict_numerics=False)
    use_float64: bool = False,       # NEW: compute in float64 internally
):
    """
    Sanitize an SO(3) axis–angle field φ (...,3):

      1) Read margin from config (or use provided 'margin').
      2) Retract to principal ball via retract_phi_principal(..., margin).
      3) Optional hard cap after retract: ||φ|| ← min(||φ||, max_theta).

    Returns float32, same leading shape as φ.

    Policy:
      - No in-kernel masking. If inputs are nonfinite:
          - strict_numerics=True  -> raise
          - strict_numerics=False -> return sentinel per 'recover'
    """
    # Margin policy
    if margin is None:
        try:
            import core.config as config
            margin = float(getattr(
                config, "phi_principal_margin",
                getattr(config, "so3_principal_margin", 1e-4)
            ))
        except Exception:
            margin = 1e-4
    margin = float(margin)

    # Dtype & shape
    dtype = np.float64 if use_float64 else np.float32
    v = np.asarray(phi, dtype=dtype)

    # 1) retract (uses stable wrap/reflect/clamp; no masking inside)
    out = retract_phi_principal(
        v, margin=margin, strict_numerics=strict_numerics, use_float64=use_float64
    ).astype(np.float32, copy=False)

    # 2) optional hard cap after retract
    if max_theta is not None:
        cap = float(min(float(max_theta), math.pi - margin))
        if cap < 0.0:
            cap = 0.0
        th = np.linalg.norm(out, axis=-1, keepdims=True)              # (...,1)
        scale = np.where(th > 0.0, np.minimum(1.0, cap / th), 1.0).astype(np.float32)
        out = (out * scale).astype(np.float32, copy=False)

    return out



# ---------------------------------------------------------------------------
# Internal helpers (keys, accessors)
# ---------------------------------------------------------------------------

def _aid(a: Any) -> int:
    """Robust agent id (falls back to object's id if missing)."""
    return int(getattr(a, "id", id(a)))

def _bases_key(agent) -> tuple[int, int, int]:
    aid = int(getattr(agent, "id", id(agent)))
    Kq = int(np.asarray(agent.mu_q_field).shape[-1])
    Kp = int(np.asarray(agent.mu_p_field).shape[-1])
    return (aid, Kq, Kp)

# --- drop-in replacement ---
def _morphism_key(agent, kind: str, cfg: dict, step_tag: int,
                  Kq: int, Kp: int, Phi0: Optional[np.ndarray]) -> tuple:
    import hashlib, json, numpy as np

    def _cfg_md5(c: dict) -> str:
        keys = ["group_name", "so3_irreps_are_orthogonal", "periodic_wrap", "phi_clip"]
        s = json.dumps({k: c.get(k, None) for k in keys},
                       sort_keys=True, separators=(",", ":"))
        return hashlib.md5(s.encode()).hexdigest()

    def _arr_digest(a: Optional[np.ndarray]) -> Optional[str]:
        if a is None:
            return None
        a = np.asarray(a, np.float32, order="C")
        h = hashlib.sha256()
        h.update(str(a.shape).encode())
        h.update(a.tobytes(order="C"))
        return h.hexdigest()

    # current algebra fields (affect the transported morphisms)
    phi_q = getattr(agent, "phi", None)
    phi_p = getattr(agent, "phi_model", None)

    # side selection by kind
    if kind == "q_to_p":
        left_phi, right_phi = phi_p, phi_q
    elif kind == "p_to_q":
        left_phi, right_phi = phi_q, phi_p
    else:
        raise ValueError(f"unknown morphism kind: {kind!r}")

    # include generator signatures for safety across reducible/mixed reps
    try:
        Gsig_q = _gensig(_get_generators(agent, "q"))
    except Exception:
        raise ValueError("[morphism_key] Gsig_q FAIL")
        Gsig_q = None
    try:
        Gsig_p = _gensig(_get_generators(agent, "p"))
    except Exception:
        raise ValueError("[morphism_key] Gsig_p FAIL")
        Gsig_p = None

    return ("morphism",
            int(getattr(agent, "id", id(agent))),
            str(kind),
            int(step_tag),
            (int(Kq), int(Kp)),
            _cfg_md5(cfg),
            _arr_digest(Phi0),
            _arr_digest(left_phi),
            _arr_digest(right_phi),
            Gsig_q, Gsig_p)





def _get_phi(agent: Any, which: str) -> np.ndarray:
    if which == "q":
        phi = getattr(agent, "phi", None)
    else:
        phi = getattr(agent, "phi_model", None)
    if phi is None:
        raise ValueError(f"[transport_cache] phi field ({which}) missing on agent id={_aid(agent)}")
    return phi


def _get_generators(agent: Any, which: str) -> np.ndarray:
    if which == "q":
        G = getattr(agent, "generators_q", None)
    else:
        G = getattr(agent, "generators_p", None)
    if G is None:
        raise ValueError(f"[transport_cache] generators ({which}) missing on agent id={_aid(agent)}")
    return G


def get_A(ctx):
    A = getattr(ctx, "fields", {}).get("A", None)
    if A is None:
        raise RuntimeError("Global A not initialized. Call ensure_global_A(...) first.")
    return A

def _sample_agent(ctx):
    for level_dict in ctx.agents_by_level.values():
        for ag in level_dict.values():
            return ag
    raise RuntimeError("No agents found")


# ---------------------------------------------------------------------------
#                              Caches
# ---------------------------------------------------------------------------

def ensure_global_A(ctx, shape_hw, *, init_scale=0.0, dtype=np.float32):
    """
    Ensure a global gauge field A with shape (H, W, 2, 3):
      - axis -2: spatial direction (0 -> x, 1 -> y)
      - axis -1: so(3) components (3)
    Back-compat: if an older (H,W,3) array is found, expand to (H,W,2,3) with zeros for Ay.
    """
    if not hasattr(ctx, "fields"):
        raise RuntimeError("ctx.fields missing; update RuntimeCtx to include a fields dict.")
    H, W = int(shape_hw[0]), int(shape_hw[1])

    A = ctx.fields.get("A", None)
    if A is not None:
        A = np.asarray(A)
        if A.shape == (H, W, 2, 3):
            ctx.fields["A"] = A.astype(dtype, copy=False)
            return ctx.fields["A"]
        if A.shape == (H, W, 3):
            # upgrade: interpret as A_x, set A_y=0
            A_up = np.zeros((H, W, 2, 3), dtype=dtype)
            A_up[..., 0, :] = A.astype(dtype, copy=False)
            ctx.fields["A"] = A_up
            return ctx.fields["A"]
        # shape mismatch (new grid size) -> reinit
        ctx.fields["A"] = None

    if init_scale and init_scale > 0.0:
        rng = np.random.default_rng(0)
        A = rng.normal(0.0, init_scale, size=(H, W, 2, 3)).astype(dtype)
    else:
        A = np.zeros((H, W, 2, 3), dtype=dtype)
    ctx.fields["A"] = A
    return ctx.fields["A"]


def expA_q(ctx, agent=None):
    C = ctx.cache
    step_tag = int(getattr(ctx, "global_step", -1))
    # include agent id to avoid cross-K collisions across different fibers
    key = ("expA_q", step_tag, int(getattr(agent, "id", -1)) if agent is not None else None)
    U = C.get("exp", key)
    if U is not None:
        return U

    A = get_A(ctx)  # (H,W,3)
    # use the passed agent if available; otherwise fall back to sampling
    if agent is None:
        try:
            agent = _sample_agent(ctx)
        except Exception:
            raise RuntimeError("expA_q: need an agent (ctx.agents_by_level not registered yet)")

    Gq = _get_generators(agent, "q")  # (3,Kq,Kq)

    if np.max(np.abs(A)) < 1e-15:
        # identity fast-path (broadcast will work)
        Kq = int(Gq.shape[-1])
        U = np.eye(Kq, dtype=np.float32)
    else:
        A = _sanitize_axis_angle(A)
        U = exp_lie_algebra_irrep(A, Gq, max_norm=float(getattr(CFG, "exp_clip_max_norm", 10.0)))

    if not np.all(np.isfinite(U)):
        raise FloatingPointError("expA_q produced non-finite values")
    C.put("exp", key, U.astype(np.float32, copy=False))
    return U


def expA_p(ctx, agent=None):
    C = ctx.cache
    step_tag = int(getattr(ctx, "global_step", -1))
    key = ("expA_p", step_tag, int(getattr(agent, "id", -1)) if agent is not None else None)
    U = C.get("exp", key)
    if U is not None:
        return U

    A = get_A(ctx)
    if agent is None:
        try:
            agent = _sample_agent(ctx)
        except Exception:
            raise RuntimeError("expA_p: need an agent (ctx.agents_by_level not registered yet)")

    Gp = _get_generators(agent, "p")  # (3,Kp,Kp)

    if np.max(np.abs(A)) < 1e-15:
        Kp = int(Gp.shape[-1])
        U = np.eye(Kp, dtype=np.float32)
    else:
        A = _sanitize_axis_angle(A)
        U = exp_lie_algebra_irrep(A, Gp, max_norm=float(getattr(CFG, "exp_clip_max_norm", 10.0)))

    if not np.all(np.isfinite(U)):
        raise FloatingPointError("expA_p produced non-finite values")
    C.put("exp", key, U.astype(np.float32, copy=False))
    return U






def _frame_E(agent, which: str) -> np.ndarray:
    G   = _get_generators(agent, which)
    phi = _get_phi(agent, which)
    phi = _sanitize_axis_angle(phi)
    return exp_lie_algebra_irrep(phi, G, max_norm=float(getattr(CFG,"exp_clip_max_norm",10.0)))


def E_grid(ctx, agent, which: str = "q", *, tol=None) -> np.ndarray:
    import numpy as np

    C        = ctx.cache
    cfg      = _ctx_cfg(ctx) or {}
    step_tag = int(getattr(ctx, "global_step", -1))
    wrap_flag      = bool(cfg.get("periodic_wrap", True))
    use_global_A   = bool(cfg.get("use_global_A", False))
    A_compose_order = str(cfg.get("A_compose_order", "yx")).lower()  # "yx" or "xy"
    phi_small_thr   = float(cfg.get("phi_small_threshold", 0.0))
    exp_clip_max    = float(cfg.get("exp_clip_max_norm", 10.0))

    phi = _get_phi(agent, which)
    G   = _get_generators(agent, which)

    key = C.key_E(
        agent_id=_aid(agent),
        step=step_tag,
        phi=phi,
        cfg=cfg,
        wrap_flag=wrap_flag,
        tol=tol,
        gensig=_gensig(G),
    )
    E_cached = C.get("exp", key)
    if E_cached is not None:
        return E_cached

    # sanitize & fast-path small rotations
    phi = _sanitize_axis_angle(phi)
    if phi.shape[-1] == 3:
        th = np.linalg.norm(phi, axis=-1)
        if np.all(th < phi_small_thr):
            K = int(G.shape[-2])
            E = np.broadcast_to(np.eye(K, dtype=np.float32), phi.shape[:-1] + (K, K)).copy()
            if use_global_A:
                U_geom = expA_q(ctx, agent) if which == "q" else expA_p(ctx, agent)
                U_geom = np.asarray(U_geom, np.float32)
                # If U_geom is (H,W,2,K,K), compose dir axis → (H,W,K,K)
                if U_geom.ndim == E.ndim + 1 and U_geom.shape[-3] == 2:
                    Ugx = U_geom[..., 0, :, :]
                    Ugy = U_geom[..., 1, :, :]
                    U_geom = (Ugy @ Ugx) if (A_compose_order != "xy") else (Ugx @ Ugy)
                E = U_geom @ E
            C.put("exp", key, E)
            return E

    # frame transform from φ
    U_frame = exp_lie_algebra_irrep(phi, G, max_norm=exp_clip_max).astype(np.float32, copy=False)

    if use_global_A:
        U_geom = expA_q(ctx, agent) if which == "q" else expA_p(ctx, agent)
        U_geom = np.asarray(U_geom, np.float32)
        # Compose (H,W,2,K,K) → (H,W,K,K) if needed
        if U_geom.ndim == U_frame.ndim + 1 and U_geom.shape[-3] == 2:
            Ugx = U_geom[..., 0, :, :]
            Ugy = U_geom[..., 1, :, :]
            U_geom = (Ugy @ Ugx) if (A_compose_order != "xy") else (Ugx @ Ugy)
        E = U_geom @ U_frame
    else:
        E = U_frame

    if not np.all(np.isfinite(E)):
        raise FloatingPointError("E_grid produced non-finite matrices")

    C.put("exp", key, E.astype(np.float32, copy=False))
    return E



def Omega(ctx: Any, ai: Any, aj: Any, which: str = "q", *, tol=None) -> np.ndarray:
    """
    Neighbor transport Ω_{ij} with freeze modes.

    config.freeze_omega_mode:
      - "none"     : default behavior (cached per step & φ)
      - "identity" : return identity transport (per-pixel I_K)
      - "snapshot" : build once from current φ fields and reuse forever

    Also:
      - If config.so3_irreps_are_orthogonal is True, use Ej^T instead of inv(Ej)
      - NOTE: Any orthogonalization/projection of Ω has been **removed** by request.
    """
    import numpy as np

    C   = ctx.cache
    cfg = _ctx_cfg(ctx)
    step_tag = int(getattr(ctx, "global_step", -1))
    mode = getattr(CFG, "freeze_omega_mode", "none")  # keeping your original symbol
    use_ortho = bool(cfg.get("so3_irreps_are_orthogonal", True))

    # helper: identity field with correct shape
    def _identity_field(ai, which: str) -> np.ndarray:
        if which == "q":
            H, W, K = np.asarray(ai.mu_q_field).shape
        else:
            H, W, K = np.asarray(ai.mu_p_field).shape
        I = np.eye(K, dtype=np.float32)
        return np.broadcast_to(I, (H, W, K, K)).copy()

    # ---------- Mode: IDENTITY ----------
    if mode == "identity":
        keyI = ("Omega_identity", _aid(ai), _aid(aj), which)
        OmI = C.get("omega", keyI)
        if OmI is None:
            OmI = _identity_field(ai, which)
            C.put("omega", keyI, OmI)
        return OmI

    # ---------- Pull fields/generators ----------
    wrap_flag = bool(cfg.get("periodic_wrap", True))
    phi_i = _get_phi(ai, which)
    phi_j = _get_phi(aj, which)
    Gi    = _get_generators(ai, which)
    Gj    = _get_generators(aj, which)

    # ---------- Mode: SNAPSHOT ----------
    if mode == "snapshot":
        # Persist across steps; depend only on agent ids, which side, and gensig
        keyS = ("Omega_snapshot", _aid(ai), _aid(aj), which,
                _gensig(Gi), _gensig(Gj))
        OmS = C.get("omega", keyS)
        if OmS is None:
            Ei = _frame_E(ai, which)   # was: E_grid(ctx, ai, which=which, tol=tol)
            Ej = _frame_E(aj, which)   # was: E_grid(ctx, aj, which=which, tol=tol)
            Ej_inv = np.swapaxes(Ej, -1, -2) if use_ortho else safe_omega_inv(Ej)
            Om = np.matmul(Ei, Ej_inv)
            # REMOVED: projection to SO (no SVD, no det fix)
            OmS = Om.astype(np.float32, copy=False)
            C.put("omega", keyS, OmS)

        return OmS

    # ---------- Mode: NONE (original behavior, no projection) ----------
    key = C.key_Omega(agent_i=_aid(ai), agent_j=_aid(aj), step=step_tag,
                      phi_i=phi_i, phi_j=phi_j, cfg=cfg, wrap_flag=wrap_flag, tol=tol,
                      gensig_i=_gensig(Gi), gensig_j=_gensig(Gj))
    Om = C.get("omega", key)
    if Om is not None:
        return Om

    Ei = _frame_E(ai, which)   # was: E_grid(ctx, ai, which=which, tol=tol)
    Ej = _frame_E(aj, which)   # was: E_grid(ctx, aj, which=which, tol=tol)
    if not (np.isfinite(Ei).all() and np.isfinite(Ej).all()):
        raise FloatingPointError("Omega: non-finite frame exponentials")

    Ej_inv = np.swapaxes(Ej, -1, -2) if use_ortho else safe_omega_inv(Ej)
    Om = np.matmul(Ei, Ej_inv)

    if not np.isfinite(Om).all():
        raise FloatingPointError("Omega: non-finite Ω")

    C.put("omega", key, Om.astype(np.float32, copy=False))
    return Om





def Jinv_grid(ctx, agent, which="q", bbox=None, *, tol=None):
    C = ctx.cache
    cfg = _ctx_cfg(ctx)
    step_tag = int(getattr(ctx, "global_step", -1))
    wrap_flag = bool(cfg.get("periodic_wrap", True))

    phi = _get_phi(agent, which)
    key = C.key_Jinv(agent_id=_aid(agent), step=step_tag, phi=phi,
                     cfg=cfg, wrap_flag=wrap_flag, tol=tol)
    J = C.get("jinv", key)  # or use a dedicated 'jinv' namespace if you prefer
    if J is None:
        phi = _sanitize_axis_angle(phi)
        J = build_dexpinv_matrix(phi)  # (...,3,3)
        C.put("jinv", key, J)

    if bbox is None:
        return J
    y0,y1,x0,x1 = bbox
    return J[y0:y1, x0:x1, :, :]




def Phi(ctx, agent, kind: str = "q_to_p"):
    """
    Return the bundle morphism Φ (q→p) or Φ̃ (p→q), honoring freeze modes:

      config.freeze_phi_mode:
        - "none"  : default behavior (keys include step_tag and φ hashes)
        - "bases" : keep Φ0/Φ̃0 fixed, still conjugate by current ϕ/ϕ̃;
                    cache key ignores step_tag so it doesn't churn every step
        - "full"  : snapshot once (using current φ, φ̃ & bases) and return
                    the same constant matrix/field thereafter
    """
    assert ctx is not None and hasattr(ctx, "cache"), "Phi: ctx with cache required"
    C   = ctx.cache
    cfg = _ctx_cfg(ctx)
    step_tag = int(getattr(ctx, "global_step", -1))

    # --- freeze mode knob in core.config (CFG) ---
    freeze_mode = getattr(CFG, "freeze_phi_mode", "none")

    Kq = int(np.asarray(agent.mu_q_field).shape[-1])
    Kp = int(np.asarray(agent.mu_p_field).shape[-1])

    # Pull (and possibly build) intertwiner bases; these are already digest-guarded
    Phi_0_in, Phi_tilde_0_in = get_morphism_bases(ctx, agent)

    # --------------------------
    # Mode: FULL (constant)
    # --------------------------
    # Build both directions once and pin them under fixed keys that do NOT depend on step_tag or φ.
    if freeze_mode == "full":
        key_qp_const = ("Phi_full_const", _aid(agent), "q_to_p")
        key_pq_const = ("Phi_full_const", _aid(agent), "p_to_q")
        M_qp = C.get("morphism", key_qp_const)
        M_pq = C.get("morphism", key_pq_const)
        if (M_qp is None) or (M_pq is None):
            Phi_full, Phit_full = _build_morphisms_with_cache(
                ctx, agent, Phi_0_in, Phi_tilde_0_in, group_name=_infer_group_name()
            )
            C.put("morphism", key_qp_const, Phi_full)
            C.put("morphism", key_pq_const, Phit_full)
            M_qp, M_pq = Phi_full, Phit_full
        return M_qp if kind == "q_to_p" else M_pq

    # --------------------------
    # Mode: BASES (fixed Φ0/Φ̃0, dynamic conjugation)
    # --------------------------
    # Keep Φ0, Φ̃0 frozen (get_morphism_bases already locks them to the generator digest),
    # but still allow current ϕ/ϕ̃ to conjugate. Avoid per-step churn by omitting step_tag in the key.
    if freeze_mode == "bases":
        # Choose the base for this direction
        base0 = Phi_0_in if kind == "q_to_p" else Phi_tilde_0_in

        # Hash only what *mathematically* matters for a conjugated morphism in this mode:
        #   (agent id, direction, Kq/Kp, base digest, current left/right φ digests, generator signatures)
        # Note: do NOT include step_tag.
        # Also, depend on current φ so cache updates when φ changes (as intended).
        phi_q = getattr(agent, "phi", None)
        phi_p = getattr(agent, "phi_model", None)
        if kind == "q_to_p":
            left_phi, right_phi = phi_p, phi_q
        else:
            left_phi, right_phi = phi_q, phi_p

        key_bases = (
            "morphism_bases",
            _aid(agent),
            str(kind),
            (int(Kq), int(Kp)),
            _gensig(_get_generators(agent, "q")),
            _gensig(_get_generators(agent, "p")),
            # digests of base and current φ fields
            # (omit step_tag to prevent per-step invalidation churn)
            _digest_array(np.asarray(base0, np.float32), tol=0.0),
            _digest_array(np.asarray(left_phi,  np.float32), tol=0.0) if left_phi  is not None else None,
            _digest_array(np.asarray(right_phi, np.float32), tol=0.0) if right_phi is not None else None,
        )

        M = C.get("morphism", key_bases)
        if M is None:
            # Build both directions from the *frozen bases* and current φ, φ̃
            Phi_full, Phit_full = _build_morphisms_with_cache(
                ctx, agent, Phi_0_in, Phi_tilde_0_in, group_name=_infer_group_name()
            )
            # Cache only the requested direction under the bases key
            M = Phi_full if kind == "q_to_p" else Phit_full
            C.put("morphism", key_bases, M)
        return M

    # --------------------------
    # Mode: NONE (default/original behavior)
    # --------------------------
    # Include step_tag and φ hashes in the key (original churny but correct behavior).
    base0 = Phi_0_in if kind == "q_to_p" else Phi_tilde_0_in
    key   = _morphism_key(agent, kind, cfg, step_tag, Kq, Kp, base0)

    M_cached = C.get("morphism", key)
    if M_cached is not None:
        return M_cached

    # Build both once (re-uses E cache) and store under their own keys
    Phi_full, Phit_full = _build_morphisms_with_cache(
        ctx, agent, Phi_0_in, Phi_tilde_0_in, group_name=_infer_group_name()
    )
    key_qp = _morphism_key(agent, "q_to_p", cfg, step_tag, Kq, Kp, Phi_0_in)
    key_pq = _morphism_key(agent, "p_to_q", cfg, step_tag, Kq, Kp, Phi_tilde_0_in)
    C.put("morphism", key_qp, Phi_full)
    C.put("morphism", key_pq, Phit_full)
    return Phi_full if kind == "q_to_p" else Phit_full


def Phi_tilde(ctx, agent) -> np.ndarray:
    return Phi(ctx, agent, kind="p_to_q")








#==============================================================================
#
#
#
#==============================================================================


def _canon_gens(G):
    """Return generators as (K, K, 3). Accepts (K,K,3) or (3,K,K)."""
    G = np.asarray(G, np.float32)
    if G.ndim != 3:
        raise ValueError(f"Generators must be 3D, got {G.shape}")
    if G.shape[-1] == 3 and G.shape[0] == G.shape[1]:
        return G  # (K,K,3)
    if G.shape[0] == 3 and G.shape[1] == G.shape[2]:
        return np.moveaxis(G, 0, -1)  # (3,K,K) -> (K,K,3)
    raise ValueError(f"Unrecognized generator shape {G.shape}")

def _ensure_q_to_p_shape(X, Kp, Kq):
    """Φ0: q→p must be (Kp, Kq). Auto-transpose if (Kq, Kp)."""
    X = np.asarray(X, np.float32)
    if X.shape == (Kp, Kq): return X
    if X.shape == (Kq, Kp): return X.T
    raise ValueError(f"Φ0 wrong shape {X.shape}; expected {(Kp, Kq)} or {(Kq, Kp)}")

def _ensure_p_to_q_shape(X, Kq, Kp):
    """Φ̃0: p→q must be (Kq, Kp). Auto-transpose if (Kp, Kq)."""
    X = np.asarray(X, np.float32)
    if X.shape == (Kq, Kp): return X
    if X.shape == (Kp, Kq): return X.T
    raise ValueError(f"Φ̃0 wrong shape {X.shape}; expected {(Kq, Kp)} or {(Kp, Kq)}")

def _intertwining_resid(G_left, G_right, X):
    """
    Residual || G_left[a] X - X G_right[a] ||_F summed over a=0..2.
    Shapes: G_left(Kout,Kout,3), G_right(Kin,Kin,3), X(Kout,Kin)
    """
    Gl = _canon_gens(G_left)
    Gr = _canon_gens(G_right)
    X  = np.asarray(X, np.float32)
    Kout = Gl.shape[0]; Kin = Gr.shape[0]
    if X.shape != (Kout, Kin):
        raise ValueError(f"X has shape {X.shape}, expected {(Kout, Kin)}")
    r = 0.0
    for a in range(3):
        r += float(np.linalg.norm(Gl[..., a] @ X - X @ Gr[..., a]))
    return r





def _digest_array(a: np.ndarray, tol: float = 0.0) -> str:
    a = np.asarray(a)
    if tol > 0:
        a = (np.round(a / tol) * tol)
    h = hashlib.sha256()
    h.update(str(a.shape).encode())
    h.update(a.tobytes(order="C"))
    return h.hexdigest()

def _gens_digest(Gq: np.ndarray, Gp: np.ndarray) -> str:
    cq = _canon_gens(Gq)  # canonicalize to (K,K,3)
    cp = _canon_gens(Gp)
    return _digest_array(cq, tol=1e-9) + "|" + _digest_array(cp, tol=1e-9)


def get_morphism_bases(ctx, agent) -> Tuple[np.ndarray, np.ndarray]:
    
    import core.config as config
    ns  = ctx.cache.nsp("morph_base")
    key = _bases_key(agent)
    entry: Optional[Dict[str, Any]] = ns.get(key)

    # Frozen generators (preprocess should have frozen them)
    Gq_raw = _get_generators(agent, "q")
    Gp_raw = _get_generators(agent, "p")
    Gq = _canon_gens(Gq_raw)
    Gp = _canon_gens(Gp_raw)
    Kq, Kp = Gq.shape[0], Gp.shape[0]
    dig_now = _gens_digest(Gq_raw, Gp_raw)

    # Back-compat: upgrade tuple → dict
    if isinstance(entry, tuple):
        Phi0, Phit0 = entry
        entry = {"Phi0": np.asarray(Phi0, np.float32),
                 "Phit0": np.asarray(Phit0, np.float32),
                 "digest": None,
                 "warned": False}
        ns[key] = entry

    # If we already have bases and digest matches, return them as-is.
    if entry is not None and entry.get("digest") == dig_now:
        return entry["Phi0"], entry["Phit0"]

   
    # Seed from agent attributes if present
    Phi0  = None if entry is None else entry.get("Phi0", None)
    Phit0 = None if entry is None else entry.get("Phit0", None)
    if Phi0 is None or Phit0 is None:
        Phi0  = getattr(agent, "Phi_0", None)
        Phit0 = getattr(agent, "Phi_tilde_0", None)

    if (Kq == Kp) and bool(getattr(config, "morphism_identity_when_square", False)):
        Iq = np.eye(Kq, dtype=np.float32)
        ns[key] = {"Phi0": Iq, "Phit0": Iq, "digest": dig_now, "warned": False}
        # Optional diagnostic when bases mismatch
        Gq_raw = _get_generators(agent, "q")
        Gp_raw = _get_generators(agent, "p")
        if not np.allclose(np.asarray(Gq_raw, np.float32), np.asarray(Gp_raw, np.float32)):
            aid = getattr(agent, "id", None)
            print(f"[morph] note: identity bases set for aid={aid}, but Gq != Gp; intertwiner residuals may be large.")
        return ns[key]["Phi0"], ns[key]["Phit0"]

    # If still missing OR digest changed: rebuild once for this digest
    if (Phi0 is None) or (Phit0 is None) or (entry is None) or (entry.get("digest") != dig_now):
                
        from transport.bundle_morphism_utils import build_intertwiner_bases, orthogonalize_intertwiner
        Phi0_new, Phit0_new, _ = build_intertwiner_bases(Gq, Gp, method="auto", return_meta=True)
        Phi0  = _ensure_q_to_p_shape(Phi0_new,  Kp, Kq)
        Phit0 = _ensure_p_to_q_shape(Phit0_new, Kq, Kp)
        if Kq == Kp:
            Phi0  = orthogonalize_intertwiner(Phi0)
            Phit0 = orthogonalize_intertwiner(Phit0)

        # Final sanity
        if not (np.all(np.isfinite(Phi0)) and np.all(np.isfinite(Phit0))):
            raise ValueError("[morph] Φ0/Φ̃0 contain non-finite values")
        if max(np.linalg.norm(Phi0), np.linalg.norm(Phit0)) == 0.0:
            raise ValueError("[morph] Φ0/Φ̃0 are zero")

        ns[key] = {
            "Phi0":  np.asarray(Phi0,  np.float32),
            "Phit0": np.asarray(Phit0, np.float32),
            "digest": dig_now,
            "warned": False,
        }
        entry = ns[key]

    # Optional: residual check is now WARN-ONLY (never overwrites)
    tol_rel = float(getattr(CFG, "intertwiner_rel_tol", 1e-7))
    if not entry.get("warned", False):
        try:
            r1 = _intertwining_resid(Gp, Gq, entry["Phi0"])
            r2 = _intertwining_resid(Gq, Gp, entry["Phit0"])
            scale = max(np.linalg.norm(Gq), np.linalg.norm(Gp), 1.0)
            rel = (r1 + r2) / (1e-6 + scale)
            if rel > tol_rel:
                print(f"[morph] note: relative intertwiner residual ≈ {rel:.2e} (digest-guarded; not overwriting)")
                entry["warned"] = True
        except Exception:
            # Do not mutate bases here; just note once.
            entry["warned"] = False

    return entry["Phi0"], entry["Phit0"]



def set_morphism_bases(ctx, agent, Phi0: np.ndarray, Phit0: np.ndarray, *, allow_overwrite: bool = False):
    """
    Persist Φ0 (Kp×Kq) and Φ̃0 (Kq×Kp) for (agent) in the 'morph_base' namespace.
    Overwrites only if allow_overwrite=True. Stores a generator digest to lock the pair to the basis.
    """
    ns  = ctx.cache.nsp("morph_base")
    key = _bases_key(agent)  # you already have this helper

    if (not allow_overwrite) and (key in ns):
        return  # keep the first, frozen pair

    # get frozen generators (3,K,K), digest them
    Gq = _get_generators(agent, "q")
    Gp = _get_generators(agent, "p")
    dig_now = _gens_digest(Gq, Gp)

    # sanity & dtype
    Phi0  = np.asarray(Phi0,  np.float32)
    Phit0 = np.asarray(Phit0, np.float32)
    if not (np.all(np.isfinite(Phi0)) and np.all(np.isfinite(Phit0))):
        raise ValueError("[morph] set_morphism_bases: non-finite Φ0/Φ̃0")

    ns[key] = {
        "Phi0":  Phi0,
        "Phit0": Phit0,
        "digest": dig_now,
        "warned": False,
    }





def E_grid_field(ctx, phi_field, generators, *, sign=+1):
    """
    Exponential from *field* (not from agent): E = exp(sign * φ) under the given generators.
    Uses the same sanitization as E_grid.
    """
    phi = _sanitize_axis_angle(np.asarray(phi_field, np.float32))
    phi = (float(sign) * phi).astype(np.float32, copy=False)
    G   = np.asarray(generators, np.float32)
    # clip via the same max-norm logic if you want parity with E_grid:
    # max_norm = float(getattr(CFG, "exp_clip_max_norm", 10.0))
    # return exp_lie_algebra_irrep(phi, G, max_norm=max_norm)
    return exp_lie_algebra_irrep(phi, G)







def Fisher_blocks(ctx, agent, which: str = "q", *, tol=None):
    """
    Cache per-pixel Fisher blocks for a Gaussian: precision Σ^{-1} (and log|Σ|).
    Returns dict with entries you can reuse across updates.
    """
    C   = ctx.cache
    cfg = _ctx_cfg(ctx)
    step_tag = int(getattr(ctx, "global_step", -1))

    # pull fields
    mu  = getattr(agent, "mu_q_field" if which=="q" else "mu_p_field")
    Sig = getattr(agent, "sigma_q_field" if which=="q" else "sigma_p_field")

    key = C.key_Fisher(agent_id=_aid(agent), step=step_tag,
                       mu=mu, Sigma=Sig, cfg=cfg, which=which, tol=tol)
    F = C.get("fisher", key)
    if F is not None:
        return F

    # compute once (vectorized over pixels)
    Sig = np.asarray(Sig, np.float32)                     # (...,K,K)
    # stable precision via cholesky if you have it; fallback to inv
    try:
        L = np.linalg.cholesky(Sig)                       # (...,K,K)
        Linv = np.linalg.inv(L)
        Prec = Linv.swapaxes(-1,-2) @ Linv               # Σ^{-1}
        logdet = 2.0 * np.log(np.clip(np.diagonal(L, axis1=-2, axis2=-1), 1e-30, None)).sum(axis=-1)
    except Exception:
        print("fisher inv fallback! \n\n\n")
        Prec   = np.linalg.inv(Sig)
        sign, logabs = np.linalg.slogdet(Sig)
        logdet = logabs

    # for natural gradient on μ, Fisher(μ)=Σ^{-1}; keep that directly
    F = {
        "precision": Prec.astype(np.float32, copy=False),   # (...,K,K)
        "logdet":    logdet.astype(np.float32, copy=False)  # (...,)
        # If/when you implement Fisher wrt Σ params, add blocks/operators here.
    }
    C.put("fisher", key, F)
    return F



#==============================================================================
#
#                  Gauge Curvature
#
#==============================================================================


import numpy as np

def _orth_inv(M):
    # for orthonormal reps: inverse = transpose
    return np.swapaxes(M, -1, -2)

def _shift(a, axis, boundary):
    if boundary == "periodic":
        return np.roll(a, -1, axis=axis)
    # "clamp": repeat edge value
    if axis == 0:
        return np.concatenate([a[1:,:,:,:], a[-1:,:,:,:]], axis=0)
    else:
        return np.concatenate([a[:,1:,:,:], a[:,-1:,:,:]], axis=1)



def _roll2(a, shift, *, boundary="periodic"):
    di, dj = int(shift[0]), int(shift[1])
    if boundary == "periodic":
        return np.roll(np.roll(a, di, axis=-4), dj, axis=-3)
    # "clamp" (repeat edge values)
    out = a
    if di != 0:
        if di > 0:
            pad = np.repeat(out[..., -1:,:,:], di, axis=-4)
            out = np.concatenate([out[..., di:,:,:], pad], axis=-4)
        else:
            di = -di
            pad = np.repeat(out[..., :1,:,:], di, axis=-4)
            out = np.concatenate([pad, out[..., :-di,:,:]], axis=-4)
    if dj != 0:
        if dj > 0:
            pad = np.repeat(out[..., -1:,:,:], dj, axis=-3)  # <-- fixed
            out = np.concatenate([out[..., dj:,:,:], pad], axis=-3)
        else:
            dj = -dj
            pad = np.repeat(out[..., :1,:,:], dj, axis=-3)
            out = np.concatenate([pad, out[..., :-dj,:,:]], axis=-3)
    return out

def plaquette_product(ctx, phi_field, generators, *, boundary="periodic",
                      split_edge=False, sign=+1):
    """
    P(i,j) = Ux(i,j) · Uy(i+1,j) · Ux(i,j+1)^T · Uy(i,j)^T
    phi_field: (..., H, W, 3)
    generators: (3,K,K) or (K,K,3)
    Returns: (..., H, W, K, K)
    """
    import numpy as np

    # Accept either layout; normalize to (3,K,K)
    G = np.asarray(generators, np.float32)
    if G.ndim != 3:
        raise ValueError(f"generators must be rank-3, got {G.shape}")
    if G.shape[0] == 3:
        G3 = G
    elif G.shape[-1] == 3 and G.shape[0] == G.shape[1]:
        G3 = np.moveaxis(G, -1, 0)  # (K,K,3) -> (3,K,K)
    else:
        raise ValueError(f"bad generators shape {G.shape}; expected (3,K,K) or (K,K,3)")

    # Site exponentials (orthonormal reps => inverse = transpose)
    E  = E_grid_field(ctx, phi_field, G3, sign=sign)   # (..., H, W, K, K)
    Et = np.swapaxes(E, -1, -2)

    if not split_edge:
        E_right = _roll2(E, (0, +1), boundary=boundary)  # (i, j+1)
        E_down  = _roll2(E, (+1, 0), boundary=boundary)  # (i+1, j)
        Ux_ij = np.matmul(E_down,  Et)
        Uy_ij = np.matmul(E_right, Et)
        Ux_i_j1 = _roll2(Ux_ij, (0, +1), boundary=boundary)
        Uy_i1_j = _roll2(Uy_ij, (+1, 0), boundary=boundary)
    else:
        half = 0.5
        Ehalf_here  = E_grid_field(ctx, half*phi_field, G3, sign=sign)
        Ehalf_right = _roll2(Ehalf_here, (0, +1), boundary=boundary)
        Ehalf_down  = _roll2(Ehalf_here, (+1, 0), boundary=boundary)
        Eh_t = np.swapaxes(Ehalf_here, -1, -2)
        Ux_ij = np.matmul(Ehalf_down,  Eh_t)
        Uy_ij = np.matmul(Ehalf_right, Eh_t)
        Ux_i_j1 = _roll2(Ux_ij, (0, +1), boundary=boundary)
        Uy_i1_j = _roll2(Uy_ij, (+1, 0), boundary=boundary)

    P = Ux_ij @ Uy_i1_j @ np.swapaxes(Ux_i_j1, -1, -2) @ np.swapaxes(Uy_ij, -1, -2)
    return P.astype(np.float32, copy=False)




def curvature_plaquette(ctx, phi_field, generators, *,
                        boundary="periodic",
                        split_edge=False,
                        metric="fro",
                        return_P=False,
                        eps=1e-7):
    """
    Gauge-invariant lattice curvature density from 1×1 plaquettes.

    metric:
      - 'fro'  : 0.5 * ||I - P||_F^2  (cheap, stable; ~ ||log P||^2 near identity)
      - 'angle': use principal rotation angle θ from trace(P) when K==3 and P∈SO(3),
                 returns θ^2 (NaN-safe; clipped)

    Returns
    -------
    curv: (..., H, W) float32
    (optional) P: (..., H, W, K, K)
    """
    P = plaquette_product(ctx, phi_field, generators, boundary=boundary, split_edge=split_edge, sign=+1)
    K  = P.shape[-1]
    IK = np.eye(K, dtype=P.dtype)

    if metric == "fro":
        D = P - IK
        # frob norm squared per site
        curv = 0.5 * np.sum(D * D, axis=(-1, -2))
    elif metric == "angle":
        # only meaningful for faithful SO(3) K=3; fall back if not
        if K != 3:
            D = P - IK
            curv = 0.5 * np.sum(D * D, axis=(-1, -2))
        else:
            # θ = arccos((trace(P)-1)/2), clamp arg for numeric safety
            tr = np.trace(P, axis1=-2, axis2=-1)
            x  = np.clip((tr - 1.0) * 0.5, -1.0 + 1e-6, 1.0 - 1e-6)
            theta = np.arccos(x)
            curv = theta * theta
    else:
        raise ValueError(f"curvature_plaquette: unknown metric '{metric}'")

    curv = curv.astype(np.float32, copy=False)
    return (curv, P) if return_P else curv




# ---------------------------------------------------------------------------
# Cached dexpinv matrices Jinv(phi)  (SO(3) axis-angle principal ball)
# ---------------------------------------------------------------------------




def build_dexpinv_matrix(phi: np.ndarray, eps: float = 1e-12, phi_clip: float = 2.8) -> np.ndarray:
    """
    Stable SO(3) dexp^{-1}(phi) in closed form, with safe series near 0 and cap near pi.
    Returns Jinv with shape (..., 3, 3).
    """
    # axis-angle
    phi = np.asarray(phi, dtype=np.float32)
    th   = np.linalg.norm(phi, axis=-1)                      # (...,)
    th_c = np.clip(th, 0.0, phi_clip)                        # cap away from pi
    u    = np.divide(phi, th[..., None] + eps, dtype=np.float32)

    # ad(u)
    ux, uy, uz = u[..., 0], u[..., 1], u[..., 2]
    zero = np.zeros_like(ux, dtype=np.float32)
    adu = np.stack([
        np.stack([ zero, -uz,   uy], axis=-1),
        np.stack([  uz,  zero, -ux], axis=-1),
        np.stack([ -uy,   ux,  zero], axis=-1),
    ], axis=-2).astype(np.float32)  # (..., 3, 3)

    # h(θ) = (θ/2) cot(θ/2) with stable small-θ series
    half  = 0.5 * th_c
    small = th_c < 1e-3
    h = np.empty_like(th_c, dtype=np.float32)

    # series near 0: h = 1 - θ^2/12 - θ^4/720 + O(θ^6)
    t2 = th_c**2
    h[small] = 1.0 - (t2[small] / 12.0) - (t2[small] * t2[small] / 720.0)

    # stable far from 0
    not_small = ~small
    half_ns = np.clip(half[not_small], 1e-6, np.pi/2 - 1e-6)
    h[not_small] = half_ns / np.tan(half_ns)

    # J^{-1}(φ) = I - (θ/2) ad(u) + (1 - h) ad(u)^2
    I    = np.eye(3, dtype=np.float32)
    adu2 = adu @ adu
    c1   = (half)[..., None, None]                # coefficient for ad(u)
    c2   = (1.0 - h)[..., None, None]             # coefficient for ad(u)^2  <-- FIXED

    Jinv = I + c1 * adu + c2 * adu2
    return Jinv.astype(np.float32)





# ---------------------------------------------------------------------------
# Bundle morphisms (same-level) and cross-scale morphisms (Θ)
# Cached per-step in "morphism" and "theta" namespaces
# ---------------------------------------------------------------------------





def _infer_group_name():
    return str(getattr(CFG, "group_name", "so3")).lower()

def _eye_like(Kd: int, Ks: int, dtype=np.float32):
    M = np.zeros((Kd, Ks), dtype=dtype)
    m = min(Kd, Ks);  M[np.arange(m), np.arange(m)] = 1.0
    return M


def _broadcast_morphism_template(M, target_tail, lead_shape):
    M = np.asarray(M, np.float32)
    if M.shape[-2:] != tuple(target_tail):
        raise ValueError(f"[transport_cache] Bad morphism base shape {M.shape}, expected {tuple(target_tail)}")
    if M.ndim == 2:
        M = np.broadcast_to(M, tuple(lead_shape) + tuple(target_tail))
    return M


def _build_morphisms_with_cache(ctx, agent, Phi_0, Phi_tilde_0, *, group_name=None):
    """
    Build Φ and Φ̃ using the central E_grid cache. Assumes ctx/cache is present.
      Φ   = E_p · Φ₀ · E_q^{-1}
      Φ̃  = E_q · Φ̃₀ · E_p^{-1}
    """
    group = (group_name or _infer_group_name())
    so3_orth_cfg = bool(getattr(CFG, "so3_irreps_are_orthogonal", True)) and group == "so3"

    # Pull transport frames
    E_q = E_grid(ctx, agent, which="q")
    E_p = E_grid(ctx, agent, which="p")

    # Dtype normalization (do AFTER retrieval so we can check orthogonality in native dtype if needed)
    E_q = np.asarray(E_q, dtype=np.float32)
    E_p = np.asarray(E_p, dtype=np.float32)

    Kq = int(E_q.shape[-1]); Kp = int(E_p.shape[-1])
    lead = np.broadcast_shapes(E_q.shape[:-2], E_p.shape[:-2])

    # --- Consistency with fibers (catches stale E_grid/generator mixups) ---
    Kq_mu = int(np.asarray(agent.mu_q_field).shape[-1])
    Kp_mu = int(np.asarray(agent.mu_p_field).shape[-1])
    if Kq != Kq_mu or Kp != Kp_mu:
        raise ValueError(
            f"[transport_cache] Fiber-size mismatch: E_grid gives (Kq,Kp)=({Kq},{Kp}) "
            f"but mu-fields are ({Kq_mu},{Kp_mu}). Check generators_q/p and caching."
        )

    # --- Template broadcast (strict shape; no identity fallback) ---
    Phi_0       = _broadcast_morphism_template(Phi_0,       (Kp, Kq), lead)
    Phi_tilde_0 = _broadcast_morphism_template(Phi_tilde_0, (Kq, Kp), lead)

    # --- Optional finite/norm sanity on provided bases ---
    if not (np.all(np.isfinite(Phi_0)) and np.all(np.isfinite(Phi_tilde_0))):
        raise FloatingPointError("[transport_cache] Nonfinite Φ₀/Φ̃₀ detected before build.")
    # Tiny-norm guard to avoid later 1/||·|| explosions (does NOT change zeros for Hom=0)
    # (Only clamp if nonzero but denormal-range tiny.)
    def _soft_clip_tiny(A, tiny=1e-20):
        n = np.linalg.norm(A, axis=(-2, -1), keepdims=True)
        mask = (n > 0) & (n < tiny)
        if np.any(mask):
            A = A * np.where(mask, tiny / (n + 1e-30), 1.0)
        return A
    Phi_0       = _soft_clip_tiny(Phi_0)
    Phi_tilde_0 = _soft_clip_tiny(Phi_tilde_0)

    # --- Inverse of E frames: transpose for (near) orthogonal, else robust inverse ---
    if so3_orth_cfg:
        # Check orthogonality once; fall back if off beyond tolerance
        def _near_orth(E, tol=1e-3):
            # ||E^T E - I||_F / ||I||_F
            I = np.eye(E.shape[-1], dtype=E.dtype)
            EtE = np.einsum("...ik,...jk->...ij", E, E)
            dev = np.linalg.norm(EtE - I, axis=(-2, -1)) / np.linalg.norm(I)
            # Broadcasted max across leads:
            return bool(np.nanmax(dev) <= tol)

        if _near_orth(E_q) and _near_orth(E_p):
            E_q_inv = np.swapaxes(E_q, -1, -2)
            E_p_inv = np.swapaxes(E_p, -1, -2)
        else:
            E_q_inv = safe_omega_inv(E_q).astype(np.float32, copy=False)
            E_p_inv = safe_omega_inv(E_p).astype(np.float32, copy=False)
    else:
        E_q_inv = safe_omega_inv(E_q).astype(np.float32, copy=False)
        E_p_inv = safe_omega_inv(E_p).astype(np.float32, copy=False)

    # --- Compose Φ and Φ̃ ---
    Phi       = np.einsum("...ik,...kj,...jl->...il", E_p, Phi_0,       E_q_inv, optimize=True).astype(np.float32, copy=False)
    Phi_tilde = np.einsum("...ik,...kj,...jl->...il", E_q, Phi_tilde_0, E_p_inv, optimize=True).astype(np.float32, copy=False)

    # Final finite check (early detection beats downstream NaNs)
    if not (np.all(np.isfinite(Phi)) and np.all(np.isfinite(Phi_tilde))):
        raise FloatingPointError("[transport_cache] Nonfinite Φ/Φ̃ after build.")

    return Phi, Phi_tilde



# ---------------------------------------------------------------------------
# Warming & invalidation
# ---------------------------------------------------------------------------

def warm_E(ctx: Any, agents: Sequence[Any], whiches: Iterable[str] = ("q", "p")) -> None:
    for a in agents:
        for w in whiches:
            try:
                _ = E_grid(ctx, a, which=w)
            except Exception as e:
                print(f"warm-e fail ({getattr(a,'id',None)} {w}): {type(e).__name__}: {e}")


def warm_Jinv(ctx: Any, agents: Sequence[Any], whiches: Iterable[str] = ("q", "p")) -> None:
    """Precompute Jinv for many agents (idempotent)."""
    for a in agents:
        for w in whiches:
            try:
                _ = Jinv_grid(ctx, a, which=w)
            except Exception:
                print("warm-jinv fail ")



# ---------------------------------------------------------------------------
# Transitional compatibility helpers (optional)
# ---------------------------------------------------------------------------


def _matmul_shapes_ok(A, B):
    # A(..., i, k) @ B(..., k, j) -> (..., i, j)
    if A is None or B is None:
        return False
    if A.ndim < 2 or B.ndim < 2:
        return False
    return A.shape[-1] == B.shape[-2]

def _assert_chain(name, *mats):
    # Ensure M1@M2@... is dimensionally valid
    for idx in range(len(mats) - 1):
        if not _matmul_shapes_ok(mats[idx], mats[idx+1]):
            a = mats[idx].shape if mats[idx] is not None else None
            b = mats[idx+1].shape if mats[idx+1] is not None else None
            raise ValueError(f"[{name}] shape mismatch at link {idx}: {a} @ {b}")

