# -*- coding: utf-8 -*-
"""
Created on Wed Jul 23 10:32:58 2025

@author: chris and christine
"""

import time
from runtime_context import ensure_runtime_defaults

from updates.update_compute_all_gradients import _apply_children, _compute_child_grads, apply_theta_updates
from updates.update_refresh_utils import (
    refresh_agents_light,    
    mark_dirty, ensure_dirty, list_nonnull,
    
)
import numpy as np
import core.config as _cfg


class PhaseTimer:
    """Context-manager timer that aggregates per-phase wall time on runtime_ctx."""
    def __init__(self, ctx):
        self.ctx = ctx
        if not hasattr(ctx, "timings") or getattr(ctx, "timings") is None:
            ctx.timings = {}

    def __call__(self, name: str):
        ctx = self.ctx
        class _T:
            def __enter__(_s):
                _s.t0 = time.perf_counter()
                return _s
            def __exit__(_s, *_):
                dt = time.perf_counter() - _s.t0
                ctx.timings[name] = ctx.timings.get(name, 0.0) + dt
        return _T()


def CFG(params, key, default=None):
    return (params or {}).get(key, getattr(_cfg, key, default))


def ensure_observations(agents, params, ctx):
    """
    Ensure each agent has agent.observation_field (… , D_obs).
    Modes:
      - 'synthetic' (default): y = x_true (+ noise) or mu_q (+ noise)
      - 'p-as-y'            : y = Φ̃ mu_p transported into q-fiber (no noise)
    """
    mode   = str(CFG(params, "obs_mode", "synthetic"))
    s2_y   = float(CFG(params, "obs_sigma2_true", 1e-2))
    D_obs  = CFG(params, "obs_dim", None)
    rng    = getattr(ctx, "rng", None)
    if rng is None:
        rng = np.random.default_rng(0); ctx.rng = rng

    for a in agents:
        if getattr(a, "observation_field", None) is not None:
            continue

        K_q = int(a.mu_q_field.shape[-1])
        H, W = a.mask.shape[:2]
        D = int(D_obs) if (D_obs is not None) else K_q

        if mode == "synthetic":
            # source state: prefer ground-truth if you have it, else current mu_q
            x_src = getattr(a, "true_x_field", None)
            if x_src is None:
                x_src = a.mu_q_field
            # Project to D_obs if needed via a fixed proj on ctx
            if D != x_src.shape[-1]:
                P = getattr(ctx, "obs_proj", None)
                if P is None or P.shape != (D, x_src.shape[-1]):
                    P = rng.standard_normal((D, x_src.shape[-1])).astype(np.float32) / max(x_src.shape[-1], 1)
                    ctx.obs_proj = P
                y_clean = np.einsum("dk,...k->...d", P, x_src, optimize=True)
            else:
                y_clean = x_src.astype(np.float32)

            noise = rng.standard_normal((H, W, D)).astype(np.float32) * np.sqrt(max(s2_y, 1e-8))
            y = (y_clean + noise).astype(np.float32)

        elif mode == "p-as-y":
            # y = Φ̃ mu_p mapped into q-fiber; identity observation model
            # NOTE: this makes accuracy partly redundant with KL(q||Φ̃p).
            from updates.update_helpers import _phi_mats  # or wherever you expose Phi, Phĩ
            _, Phi_tilde = _phi_mats(ctx, a)
            mu_p_q = np.einsum("...dk,...k->...d", Phi_tilde, a.mu_p_field, optimize=True).astype(np.float32)
            if D != mu_p_q.shape[-1]:
                # Project to D via a fixed ctx.obs_proj
                P = getattr(ctx, "obs_proj", None)
                if P is None or P.shape != (D, mu_p_q.shape[-1]):
                    P = rng.standard_normal((D, mu_p_q.shape[-1])).astype(np.float32) / max(mu_p_q.shape[-1], 1)
                    ctx.obs_proj = P
                y = np.einsum("dk,...k->...d", P, mu_p_q, optimize=True).astype(np.float32)
            else:
                y = mu_p_q

        else:
            raise ValueError(f"Unknown obs_mode={mode!r}")

        a.observation_field = y




# --- synchronous step (simplified, timed) ------------------------------------
def synchronous_step(agents, generators_q, generators_p, params=None, n_jobs=1, runtime_ctx=None):
    """
    Single-scale (children-only) synchronous update step.
    Evolves child agents, enforces caches, warms pairwise transport (KL refresh),
    and registers children. No parents/detection/spawn/xscale.
    """
    import core.config as config

    def CFG(key, default=None):
        return (params or {}).get(key, getattr(config, key, default))

    assert runtime_ctx is not None, "synchronous_step: pass runtime_ctx"
    assert agents and (len(agents) > 0), "synchronous_step: no agents"

    params = dict(params or {})
    params["runtime_ctx"] = runtime_ctx

    runtime_ctx = ensure_runtime_defaults(runtime_ctx)

    if not hasattr(runtime_ctx, "cache") or runtime_ctx.cache is None:
        try:
            from runtime_context import CacheHub
            runtime_ctx.cache = CacheHub()
        except Exception:
            class _NoopCache:
                def clear_on_step(self, *_args, **_kw): pass
                def ns(self, *_args, **_kw):
                    class _D(dict):
                        def clear(self): super().clear()
                    return _D()
            runtime_ctx.cache = _NoopCache()

    step_now = int(getattr(runtime_ctx, "global_step", 0))
    runtime_ctx.cache.clear_on_step(step_now)

    d = getattr(runtime_ctx, "dirty", None)
    if hasattr(d, "reset_step"):
        d.reset_step(step_now)
    try:
        d.agents.clear(); d.kl.clear()
    except Exception:
        pass

    T = PhaseTimer(runtime_ctx)

    # ---------------- Phase 0: pre ----------------
    with T("pre"):
        children = list_nonnull(agents)
        if not children:
            runtime_ctx.register_agents(0, [])
            runtime_ctx.global_step += 1
            return agents
        refresh_agents_light(children, params, generators_q, generators_p, ctx=runtime_ctx)
        ensure_observations(children, params, runtime_ctx)  # <-- add this line
    # ---------------- Phase 1: child grads/apply ---
    with T("child_grad"):
        out = _compute_child_grads(children, children, generators_q, generators_p, params)
        # Unpack; support both new (5) and old (4) formats
        if len(out) == 5:
            q_updates, p_updates, phi_grads, phi_m_grads, dtheta_parts = out
        else:
            q_updates, p_updates, phi_grads, phi_m_grads = out
            dtheta_parts = [None] * len(children)

    with T("child_apply"):
        
        # Pass only the first four items to the child apply
        _apply_children(children, (q_updates, p_updates, phi_grads, phi_m_grads),
                        params, generators_q, generators_p, n_jobs, ctx=runtime_ctx)
        for a in children:
            mark_dirty(runtime_ctx, a, kl=True)  # signal pairwise caches to warm
        runtime_ctx.children_latest = children

    

    # -------- NEW: Phase 1.5 — θ apply ONCE --------
    with T("theta_apply"):
        import numpy as np
        step = int(getattr(runtime_ctx, "global_step", 0))
        warm = int((params or {}).get("theta_warmup_steps", 0))
        dtheta_sum = None

        for part in dtheta_parts:
            if part is None:
                continue
            dW, db, dS = part
            if dtheta_sum is None:
                dtheta_sum = [np.array(dW, np.float32),
                              np.array(db, np.float32),
                              float(dS)]
            else:
                dtheta_sum[0] += dW
                dtheta_sum[1] += db
                dtheta_sum[2] += dS

        # Optional: skip during warmup steps
        if (dtheta_sum is not None) and (step >= warm):
            clip = float((params or {}).get("theta_grad_clip", 0.0))
            if clip and clip > 0:
                def _clip_vec(X):
                    n = float(np.linalg.norm(X))
                    s = min(1.0, clip / (n + 1e-12))
                    return (X * s).astype(np.float32)
                dtheta_sum[0] = _clip_vec(dtheta_sum[0])
                dtheta_sum[1] = _clip_vec(dtheta_sum[1])
                dtheta_sum[2] = float(np.sign(dtheta_sum[2]) * min(abs(dtheta_sum[2]), clip))

            apply_theta_updates(runtime_ctx, tuple(dtheta_sum), params)


            th = runtime_ctx.theta
            print(f"[θ-APPLY] step={step} have_parts={dtheta_sum is not None} \n"
                  f"|ΔW| = {np.linalg.norm(dtheta_sum[0]) if dtheta_sum else 0:.2e}\n"
                  f"|Δb| = {np.linalg.norm(dtheta_sum[1]) if dtheta_sum else 0:.2e}\n"
                  f"Δσ2  = {dtheta_sum[2] if dtheta_sum else 0:.2e}\n"
                  f"|W|_F= {np.linalg.norm(th.W):.2e} σ2={th.sigma2:.2e}\n\n", flush=True)
                

    # ---------------- Phase 2: ensure/caches -------
    with T("ensure_children"):
        ensure_dirty(runtime_ctx, generators_q, generators_p, params, scope="children")

    with T("A_update"):
        from updates.update_terms_curvature_A import step_global_A
        _ = step_global_A(runtime_ctx, children, params)

    # ---------------- Phase 4: register/step -------
    with T("register"):
        runtime_ctx.register_agents(0, children)
        runtime_ctx.children_latest = children
        runtime_ctx.global_step    += 1

    # ---------------- Phase 5: timing --------------
    if bool(CFG("debug_phase_timing", True)):
        print("[timings]")
        for name, dt in sorted(getattr(runtime_ctx, "timings", {}).items()):
            print(f"  {name:20s} {dt:8.3f}s")
        if getattr(runtime_ctx, "counters", None):
            print("[counts]", runtime_ctx.counters)

    return agents














