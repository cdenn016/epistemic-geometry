# -*- coding: utf-8 -*-
"""
Natural-gradient utilities (Gaussian fields) and Lie-geometry helpers.

- No per-agent caches. Central caches (CacheHub) are used only via omega helpers.
- Strict SPD everywhere (full Σ, no diagonal shortcuts).
- Irrep-agnostic: supply generators for the target fiber K.

Author: c&c
"""
from __future__ import annotations

import numpy as np
import core.config as config

from core.numerical_utils import sanitize_sigma, safe_inv
from transport.transport_cache import Fisher_blocks
import hashlib, json

# -----------------------------------------------------------------------------
# Natural gradient in Gaussian family (μ, Σ)
# -----------------------------------------------------------------------------


def apply_natural_gradient_batch(
    mu_field,
    sigma_field,
    grad_mu_field,
    grad_sigma_field,
    mask=None,
    *,
    strict_numerics: bool = True,         # NEW: fail-fast on nonfinite
    recover: str | None = None,           # NEW: None | "nan" | "zero" (only used if strict_numerics=False)
    use_float64: bool = True,             # NEW: compute in float64 for stability
):
    """
    Vectorized natural gradient for Gaussian fields:
        δμ = -Σ ∇_μ L
        δΣ = -2 Σ sym(∇_Σ L) Σ

    Args
    ----
    mu_field         : (H,W,K)
    sigma_field      : (H,W,K,K) SPD (full)
    grad_mu_field    : (H,W,K)
    grad_sigma_field : (H,W,K,K)
    mask             : (H,W) bool or float weights (optional)

    Returns
    -------
    delta_mu   : (H,W,K)
    delta_sigma: (H,W,K,K)
    """
    H, W, K = mu_field.shape
    N = H * W

    eps = float(getattr(config, "eps", 1e-8))
    clip_sigma = getattr(config, "gradient_clip_sigma", None)
    clip_mu    = getattr(config, "gradient_clip_mu",    None)

    dtype = np.float64 if use_float64 else np.float32

    # Flatten pixel grid, lift to dtype
    mu   = np.asarray(mu_field,        dtype=dtype).reshape(N, K)
    Sig  = np.asarray(sigma_field,     dtype=dtype).reshape(N, K, K)
    gmu  = np.asarray(grad_mu_field,   dtype=dtype).reshape(N, K)
    gSig = np.asarray(grad_sigma_field,dtype=dtype).reshape(N, K, K)

    # Strict SPD sanitize once (should raise on failure)
    # Assumes sanitize_sigma(S, strict=True) returns symmetric SPD in 'dtype'
    Sig = sanitize_sigma(Sig, eps=eps, strict=True)

    # Symmetrize ∇_Σ
    gSig = 0.5 * (gSig + np.swapaxes(gSig, -1, -2))

    # Natural steps (einsum keeps it batched and BLAS-friendly)
    dmu = -np.einsum("nik,nk->ni", Sig, gmu, optimize=True)
    tmp =  np.einsum("nij,njk->nik", Sig, gSig, optimize=True)
    dS  = -2.0 * np.einsum("nij,njk->nik", tmp, Sig, optimize=True)
    dS  = 0.5 * (dS + np.swapaxes(dS, -1, -2))  # symmetry guard

    # Mask / weights
    if mask is None:
        active = np.ones(N, dtype=bool)
        wts = None
    else:
        m = np.asarray(mask)
        if m.shape != (H, W):
            raise ValueError(f"mask shape {m.shape} != {(H, W)}")
        m = m.reshape(N)
        if m.dtype == bool:
            active = m
            wts = None
        else:
            cutoff = float(getattr(config, "support_cutoff_eps", 0.0))
            active = m > cutoff
            wts = m.astype(dtype, copy=False)

    # Global norm clipping (only for active pixels)
    if clip_sigma is not None:
        ns = np.linalg.norm(dS.reshape(N, -1), axis=1)   # Frobenius per pixel
        cm = (ns > clip_sigma) & active
        if np.any(cm):
            scale = np.ones(N, dtype=dtype)
            scale[cm] = clip_sigma / np.maximum(ns[cm], eps)
            dS *= scale[:, None, None]

    if clip_mu is not None:
        nm = np.linalg.norm(dmu, axis=1)
        cm = (nm > clip_mu) & active
        if np.any(cm):
            scale = np.ones(N, dtype=dtype)
            scale[cm] = clip_mu / np.maximum(nm[cm], eps)
            dmu *= scale[:, None]

    # Apply soft weights (if provided)
    if wts is not None:
        dmu *= wts[:, None]
        dS  *= wts[:, None, None]

    # Zero outside support
    if not np.all(active):
        ia = ~active
        dmu[ia] = 0.0
        dS[ia]  = 0.0

    # Final strictness check — no in-kernel masking
    if strict_numerics:
        if not (np.all(np.isfinite(dmu)) and np.all(np.isfinite(dS))):
            raise FloatingPointError("Nonfinite natural gradient (μ or Σ).")
    else:
        if not (np.all(np.isfinite(dmu)) and np.all(np.isfinite(dS))):
            if recover is None or recover == "nan":
                dmu = np.full_like(dmu, np.nan, dtype=dtype)
                dS  = np.full_like(dS,  np.nan, dtype=dtype)
            elif recover == "zero":
                print("RECOVER zero nat grad Faialalalala\n\n\n\n\n")
                dmu = np.zeros_like(dmu, dtype=dtype)
                dS  = np.zeros_like(dS,  dtype=dtype)
            else:
                raise ValueError(f"Unknown recover policy: {recover}")

    # Restore shapes; cast back to float32 if you prefer
    out_dtype = np.float32 if not use_float64 else dtype
    return dmu.reshape(H, W, K).astype(out_dtype), dS.reshape(H, W, K, K).astype(out_dtype)



# -----------------------------------------------------------------------------
# Fisher metric (per-point) for φ / φ̃ fibers; inverse on support
# -----------------------------------------------------------------------------
def inverse_fisher_metric_field(ctx, agent, generators, *, which="q", eps=1e-8, tol=None):
    """
    Per-pixel inverse Fisher metric for algebra coords (φ or φ̃), using
        F_ab = tr( Σ^{-1} G_a Σ^{-1} G_b ), then symmetrize and invert per pixel.

    Inputs
    ------
    Sigma  : agent.sigma_{q|p}_field  (H,W,K,K) SPD
    Gens   : generators               (d,K,K)   (d=3 for so(3), K arbitrary reducible dim)
    mask   : agent.mask               (H,W)

    Output
    ------
    Finv   : (H,W,d,d) float32
    """
    import numpy as np
    
    from core import config
    
     

    # --- pull Σ and mask ---
    Sig  = np.asarray(agent.sigma_q_field if which == "q" else agent.sigma_p_field, np.float64)
    Gens = np.asarray(generators, np.float64)   # (d,K,K)
    H, W, K, _ = Sig.shape
    d = int(Gens.shape[0])

    mask = (np.asarray(agent.mask) > float(getattr(config, "support_cutoff_eps", 1e-4)))
    if mask.shape != (H, W):
        mask = np.reshape(mask, (H, W))

    # --- cache key (keep it light if your cache is already step-scoped) ---
    C = getattr(ctx, "cache", None)
    step = int(getattr(ctx, "global_step", -1))
    aid  = int(getattr(agent, "id", id(agent)))
    cfg  = getattr(ctx, "config", {}) if hasattr(ctx, "config") else {}
    def _cfg_md5(c):
        keys = ["group_name", "so3_irreps_are_orthogonal"]
        s = json.dumps({k: c.get(k, None) for k in keys}, sort_keys=True, separators=(",", ":"))
        return hashlib.md5(s.encode()).hexdigest()
    key = ("FisherMetricInv", which, aid, step, (H, W, K, d), _cfg_md5(cfg))
    if C is not None:
        out_cached = C.get("fisher", key)
        if out_cached is not None:
            return out_cached

    # --- prefer cached precision if available; else compute robustly ---
    try:
        Fb   = Fisher_blocks(ctx, agent, which=which, tol=tol)
        Prec = np.asarray(Fb["precision"], np.float64)   # (H,W,K,K)
    except Exception:
        print("FALLBACK FISHER FIELD \n\n\n\n")
        # Fallback: sanitize + safe inverse (fp64)
        Ssym = 0.5 * (Sig + np.swapaxes(Sig, -1, -2))
        Sspd = sanitize_sigma(Ssym)                      # SPD projection
        Prec = safe_inv(Sspd, eps=max(eps, 1e-12))      # robust inverse

    # --- build T_a = Σ^{-1} G_a Σ^{-1} (batched) ---
    # T: (H,W,d,K,K)
    T = np.einsum("...ij,ajk->...aik", Prec, Gens, optimize=True)
    T = np.einsum("...aik,...kl->...ail", T, Prec, optimize=True)

    # --- F_ab = tr( T_a G_b ) (H,W,d,d) ---
    F = np.einsum("...aij,bji->...ab", T, Gens, optimize=True)
    F = 0.5 * (F + np.swapaxes(F, -1, -2))              # symmetrize

    # --- invert per pixel on the mask ---
    Fflat  = F.reshape(-1, d, d)
    mflat  = mask.reshape(-1)
    Finv_f = np.zeros_like(Fflat)
    if np.any(mflat):
        M = Fflat[mflat]                                 # (M,d,d)
        # SPD eig-inverse with floor
        w, V = np.linalg.eigh(M)
        w = np.clip(w, max(eps, 1e-12), None)
        Minv = (V / w[..., None, :]) @ np.swapaxes(V, -1, -2)
        # symmetry guard
        Minv = 0.5 * (Minv + np.swapaxes(Minv, -1, -2))
        Finv_f[mflat] = Minv

    Finv = Finv_f.reshape(H, W, d, d).astype(np.float32, copy=False)

    if C is not None:
        C.put("fisher", key, Finv)
    return Finv




