# -*- coding: utf-8 -*-
"""
Created on Mon Aug 11 10:07:56 2025

@author: chris and christine
"""
import numpy as np
from core.numerical_utils import sanitize_sigma, safe_inv
from typing import Optional, Tuple



# -*- coding: utf-8 -*-
"""
Linear pushforward of Gaussian parameters under a matrix M:
  μ' = M μ
  Σ' = M Σ Mᵀ

One canonical entry-point:
  push_gaussian(mu, Sigma, M, *, approx="auto"| "exact" | "first_order", ...)

- Cache-agnostic; pure math.
- Works for square (Ω) and rectangular (Φ) maps.
- Broadcast-safe over leading dims.

Use this from transport/updates/energies; DO NOT re-implement locally.
"""


# ===== diagnostics_omega_kl.py =====





def _chol_logdet(S):
    L = np.linalg.cholesky(S)  # (..., K, K)
    diag = np.diagonal(L, axis1=-2, axis2=-1)
    logdet = 2.0 * np.sum(np.log(np.clip(diag, 1e-300, None)), axis=-1)
    return L, logdet

def kl_gaussian(
    mu1: np.ndarray,
    S1: np.ndarray,
    mu2: np.ndarray,
    S2: np.ndarray,
    *,
    eps: float = 1e-6,
    allow_diag: bool = True,
    diag_is_stddev: bool = True,
    sanitize: bool = True,
    strict_numerics: bool = True,
    recover: str | None = None,
    return_terms: bool = False,
) -> np.ndarray | tuple[np.ndarray, dict]:
    mu1 = np.asarray(mu1, dtype=float)
    mu2 = np.asarray(mu2, dtype=float)
    S1 = np.asarray(S1)
    S2 = np.asarray(S2)
 
    S1 = sanitize_sigma(S1, eps=eps)  # ensure SPD (prefer float64)
    S2 = sanitize_sigma(S2, eps=eps)
  
    L2, logdet2 = _chol_logdet(S2)
    _,  logdet1 = _chol_logdet(S1)
   
    K = mu1.shape[-1]
    dmu = mu2 - mu1                                     # (..., K)

    # Solve L2 * y = dmu  -> y shape (..., K, 1)
    y = np.linalg.solve(L2, dmu[..., None])             # (..., K, 1)
    # Solve L2^T * z = y
    z = np.linalg.solve(np.swapaxes(L2, -1, -2), y)     # (..., K, 1)
    term_quad = np.sum(dmu * np.squeeze(z, axis=-1), axis=-1)  # (...,)

    # term_trace = tr(S2^{-1} S1) via two triangular solves (no explicit inverse)
    Y = np.linalg.solve(L2, S1)                         # (..., K, K)
    X = np.linalg.solve(np.swapaxes(L2, -1, -2), Y)     # (..., K, K)
    term_trace = np.trace(X, axis1=-2, axis2=-1)        # (...,)

    kl = 0.5 * (term_trace + term_quad - K + (logdet2 - logdet1))
    # Only shave tiny negatives from roundoff; do NOT clamp or nan_to_num here.
    kl = np.where(kl < 0, np.maximum(kl, -1e-12), kl)
 
    if not np.all(np.isfinite(kl)):
        raise FloatingPointError("Nonfinite KL encountered (NaN/Inf).")
    
    if return_terms:
        return kl, {"term_trace": term_trace, "term_quad": term_quad,
                    "logdet1": logdet1, "logdet2": logdet2}
    return kl


def push_gaussian(
    mu: np.ndarray,
    Sigma: np.ndarray,
    M: np.ndarray,
    *,
    eps: float = 1e-8,
    symmetrize: bool = True,
    sanitize: bool = True,
    approx: str = "exact",              # enforced
    near_identity_tau: Optional[float] = None,  # unused
    return_inv: bool = False,
):
    """Exact pushforward of N(mu, Σ) under y = Mx, with robust numerics."""
    # Preserve original dtypes for outputs
    out_mu_dtype    = np.asarray(mu).dtype
    out_sigma_dtype = np.asarray(Sigma).dtype

    # Promote to fp64 internally
    mu64    = np.asarray(mu,    dtype=np.float64)
    Sigma64 = np.asarray(Sigma, dtype=np.float64)
    M64     = np.asarray(M,     dtype=np.float64)

    # Shapes
    K_in = int(mu64.shape[-1])
    if Sigma64.shape[-2:] != (K_in, K_in):
        raise ValueError(f"[push_gaussian] Σ dims {Sigma64.shape[-2:]} incompatible with μ dim {K_in}")
    if M64.shape[-1] != K_in:
        raise ValueError(f"[push_gaussian] M last dim {M64.shape[-1]} != μ dim {K_in}")
    K_out = int(M64.shape[-2])
        
    Sigma64 = sanitize_sigma(Sigma64)

    # Scale-aware jitter on Σ_in
    if eps and eps > 0.0:
        diag_in = np.clip(np.diagonal(Sigma64, axis1=-2, axis2=-1), 0.0, None)
        scale_in = float(np.maximum(1.0, np.nanmean(diag_in)))
        Sigma64 = Sigma64 + max(eps, 1e-12) * scale_in * np.eye(K_in, dtype=Sigma64.dtype)

    # Exact push: μ' = M μ,  Σ' = M Σ Mᵀ
    mu_out64    = np.einsum("...ik,...k->...i", M64, mu64, optimize=True)
    Sigma_out64 = np.einsum("...ik,...kl,...jl->...ij", M64, Sigma64, M64, optimize=True)

    # Σ_out: optional symmetrize + sanitize
   
    Sigma_out64 = sanitize_sigma(Sigma_out64)

    # Scale-aware jitter on Σ_out
    if eps and eps > 0.0:
        diag_out = np.clip(np.diagonal(Sigma_out64, axis1=-2, axis2=-1), 0.0, None)
        scale_out = float(np.maximum(1.0, np.nanmean(diag_out)))
        Sigma_out64 = Sigma_out64 + max(eps, 1e-12) * scale_out * np.eye(K_out, dtype=Sigma_out64.dtype)

    if return_inv:
        Sigma_out_inv64 = safe_inv(Sigma_out64, eps=max(eps, 1e-12))
        return (
            mu_out64.astype(out_mu_dtype,    copy=False),
            Sigma_out64.astype(out_sigma_dtype, copy=False),
            Sigma_out_inv64.astype(out_sigma_dtype, copy=False),
        )

    return (
        mu_out64.astype(out_mu_dtype,    copy=False),
        Sigma_out64.astype(out_sigma_dtype, copy=False),
    )
















