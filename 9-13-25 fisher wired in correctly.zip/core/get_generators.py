from __future__ import annotations
import numpy as np
from typing import Iterable, List, Tuple, Dict

Array = np.ndarray
_generator_cache: Dict[tuple, tuple[np.ndarray, dict]] = {}



# ----------------------- Irrep construction (real tesseral basis) -----------------------

def so3_irrep(K: int) -> dict:
    if K % 2 == 0:
        raise ValueError("K must be odd for SO(3) irreps (K = 2ℓ + 1).")
    ℓ = (K - 1) // 2

    # Use complex128 for higher accuracy during basis transforms
    Jp = np.zeros((K, K), dtype=np.complex128)
    Jm = np.zeros((K, K), dtype=np.complex128)
    Jz = np.zeros((K, K), dtype=np.complex128)
    for m in range(-ℓ, ℓ + 1):
        i = m + ℓ
        Jz[i, i] = m
        if m < ℓ:
            a = np.sqrt((ℓ - m) * (ℓ + m + 1))
            Jp[i, i + 1] = a
            Jm[i + 1, i] = a
    Jx = (Jp + Jm) / 2.0
    Jy = (Jp - Jm) / (2.0j)

    # Complex->real tesseral transform (unitary), in complex128
    S = np.zeros((K, K), dtype=np.complex128)
    S[0, ℓ] = 1.0
    r = 1
    for m in range(1, ℓ + 1):
        phase = (-1) ** m
        S[r,   ℓ + m] = 1 / np.sqrt(2)
        S[r,   ℓ - m] = phase / np.sqrt(2)
        S[r+1, ℓ + m] = -1j / np.sqrt(2)
        S[r+1, ℓ - m] =  1j * phase / np.sqrt(2)
        r += 2
    Sinv = S.conj().T

    def real_skew(iJ):
        G = (S @ iJ @ Sinv).real
        return 0.5 * (G - G.T)  # enforce skew

    Gx = real_skew(1j * Jx)
    Gy = real_skew(1j * Jy)
    Gz = real_skew(1j * Jz)
    return {"E": Gx, "F": Gy, "H": Gz}



# ----------------------- Reducible assembly -----------------------

def make_reducible_generators(
    spec: Iterable[Tuple[int, int]],
    *,
    mix: bool = False,
    rng: np.random.Generator | None = None,
    dtype=np.float32,
    return_meta: bool = False,
):
    """
    Build generators G = (Gx, Gy, Gz) for a real reducible SO(3) rep.

    spec: iterable of (ell, multiplicity), ell>=0, multiplicity>=1
    """
    def _casimir_index_block(G_block: np.ndarray) -> float:
        s = 0.0
        for a in range(3):
            Ga = G_block[a]
            s += -np.trace(Ga @ Ga)
        return float(s) / 3.0

    def _metric_so3(G: np.ndarray) -> np.ndarray:
        M = np.zeros((3, 3), dtype=np.float64)
        for a in range(3):
            for b in range(3):
                M[a, b] = -np.trace(G[a] @ G[b])
        return M

    def _expected_total_from_spec(spec_local: Iterable[Tuple[int, int]]) -> float:
        return sum(m * (ell * (ell + 1) * (2 * ell + 1) / 3.0) for (ell, m) in spec_local)

    blocks: List[Array] = []
    total_dim = 0
    for ell, mult in spec:
        if ell < 0 or mult <= 0:
            raise ValueError(f"Invalid (ell,mult)=({ell},{mult}).")
        d = 2 * ell + 1
        Gi_dict = so3_irrep(d)
        Gi = np.stack([Gi_dict["E"], Gi_dict["F"], Gi_dict["H"]], axis=0).astype(np.float64, copy=False)
        for _ in range(mult):
            blocks.append(Gi)
            total_dim += d

    if total_dim == 0:
        raise ValueError("Empty spec: total dimension is zero.")

    # Block-diagonal (float64 for accurate traces)
    G = _block_diag_generators(blocks)  # (3, K, K) float64

    # Diagnostics BEFORE mixing
    block_dims = [b.shape[1] for b in blocks]
    bounds, o = [], 0
    for d in block_dims:
        bounds.append((o, o + d))
        o += d

    casimir_per_block = []
    for (lo, hi) in bounds:
        Gblk = G[:, lo:hi, lo:hi]
        casimir_per_block.append(_casimir_index_block(Gblk))
    casimir_total = float(sum(casimir_per_block))

    # Sanity check vs spec
    expected_total = _expected_total_from_spec(spec)
    eps = 1e-8 * max(1.0, expected_total)
    if abs(casimir_total - expected_total) > eps:
        raise AssertionError(f"Casimir(total) mismatch: expected {expected_total}, got {casimir_total}")

    # Optional orthogonal mixing
    if mix:
        if rng is None:
            rng = np.random.default_rng()
        Q = _random_orthogonal(total_dim, rng=rng)
        for a in range(3):
            G[a] = Q @ G[a] @ Q.T

    # Cast and validate
    G = G.astype(dtype, copy=False)
    ok, resid = check_so3_relations(G, rtol=5e-6, atol=5e-7, return_resid=True)
    if not ok:
        raise RuntimeError(f"SO(3) commutator check failed, residual {resid:.3e}")

    if not return_meta:
        return G
    meta = {
        "blocks": block_dims,
        "spec": list(spec),
        "casimir_per_block": casimir_per_block,
        "casimir_total": casimir_total,
        "metric_so3": _metric_so3(G).astype(np.float32),
    }
    return G, meta


# ----------------------- Helpers -----------------------

def check_so3_relations(
    G: Array, *, rtol: float = 1e-7, atol: float = 1e-8, return_resid: bool = False
) -> bool | Tuple[bool, float]:
    Gx, Gy, Gz = G[0], G[1], G[2]
    errs = []
    errs.append(_fro_norm(Gx @ Gy - Gy @ Gx - Gz))
    errs.append(_fro_norm(Gy @ Gz - Gz @ Gy - Gx))
    errs.append(_fro_norm(Gz @ Gx - Gx @ Gz - Gy))
    target_norm = max(_fro_norm(Gx), _fro_norm(Gy), _fro_norm(Gz), 1.0)
    thresh = atol + rtol * target_norm
    ok = all(e <= thresh for e in errs)
    if return_resid:
        res = float(np.sqrt(sum(e * e for e in errs)))
        return ok, res
    return ok

def _fro_norm(A: Array) -> float:
    return float(np.linalg.norm(A, ord="fro"))

def _block_diag_generators(blocks: List[Array]) -> Array:
    if not blocks:
        raise ValueError("No blocks to assemble.")
    sizes = [b.shape[1] for b in blocks]
    K = int(sum(sizes))
    G = np.zeros((3, K, K), dtype=np.float64)
    r0 = 0
    for b in blocks:
        d = b.shape[1]
        r1 = r0 + d
        for a in range(3):
            G[a, r0:r1, r0:r1] = b[a]
        r0 = r1
    return G

def _random_orthogonal(n: int, rng: np.random.Generator) -> Array:
    A = rng.standard_normal((n, n))
    Q, R = np.linalg.qr(A)
    s = np.sign(np.diag(R))
    s[s == 0] = 1.0
    Q = Q * s
    return Q
