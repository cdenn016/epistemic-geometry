# -*- coding: utf-8 -*-
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Set, Literal
import numpy as np
import hashlib, json

Fiber = Literal["q", "p"]

# ─────────────────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────────────────

def _shape_sig(a):
    return tuple(int(x) for x in np.asarray(a).shape)

def _arr_digest(a: np.ndarray, *, tol: float | None = None) -> str:
    a = np.asarray(a, np.float32)
    if tol and tol > 0:
        b = (np.round(a / tol) * tol).tobytes()
    else:
        b = a.tobytes()
    return hashlib.sha256(b).hexdigest()

def _config_digest(cfg: dict) -> str:
    keys = ["group_name", "phi_clip", "periodic_wrap", "so3_irreps_are_orthogonal",
            "mask_edge_soften_sigma"]
    sub = {k: cfg.get(k, None) for k in keys}
    s = json.dumps(sub, sort_keys=True, separators=(",", ":"))
    return hashlib.md5(s.encode()).hexdigest()

# ─────────────────────────────────────────────────────────────────────────────
# Step-scoped flags
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class WorkFlags:
    step_tag: int = -1
    phi_touched: Dict[int, Set[Fiber]] = field(default_factory=dict)   # {aid: {"q","p"}}
    sigma_touched: Dict[int, Set[Fiber]] = field(default_factory=dict) # {aid: {"q","p"}}
    morphism_touched: Set[int] = field(default_factory=set)            # optional

    def reset_step(self, step: int) -> None:
        if step != self.step_tag:
            self.step_tag = int(step)
            self.phi_touched.clear()
            self.sigma_touched.clear()
            self.morphism_touched.clear()

    # mark helpers
    def touch_phi(self, aid: int, which: Fiber) -> None:
        self.phi_touched.setdefault(int(aid), set()).add(which)

    def touch_sigma(self, aid: int, which: Fiber) -> None:
        self.sigma_touched.setdefault(int(aid), set()).add(which)

    def touch_morphism(self, aid: int) -> None:
        self.morphism_touched.add(int(aid))

# ─────────────────────────────────────────────────────────────────────────────
# Cache hub
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class CacheHub:
    step_tag: int = -1
    spaces: Dict[str, Dict[Any, Any]] = field(default_factory=lambda: {
        "exp": {}, "omega": {}, "morphism": {}, "fisher": {}, "misc": {}, "jinv": {}
    })
    persist: Dict[str, Dict[Any, Any]] = field(default_factory=lambda: {
        "morph_base": {}
    })
    hits: int = 0
    misses: int = 0
    invalidations: int = 0

    def ns(self, name: str) -> Dict[Any, Any]:
        return self.spaces.setdefault(name, {})

    def nsp(self, name: str) -> Dict[Any, Any]:
        return self.persist.setdefault(name, {})

    def clear_on_step(self, step: int) -> None:
        if step != self.step_tag:
            for d in self.spaces.values():
                d.clear()
            self.step_tag = step

    def stats(self) -> Dict[str, int]:
        return {k: len(v) for k, v in self.spaces.items()}

    def key_E(self, *, agent_id: int, step: int, phi: np.ndarray,
          cfg: dict, wrap_flag: bool, tol: float | None = None,
          gensig: tuple | None = None):
        """
        E-cache key; includes optional generator signature to disambiguate reps.
        gensig should be a small tuple like (K, 'sha256hex') or None.
        """
        return ("E", int(agent_id), int(step),
                _shape_sig(phi), bool(wrap_flag), _config_digest(cfg),
                gensig, _arr_digest(phi, tol=tol))
    
    def key_Jinv(self, **kw):
        k = self.key_E(**kw)
        return ("Jinv",) + k[1:]
    
    def key_Omega(self, *, agent_i: int, agent_j: int, step: int,
                  phi_i: np.ndarray, phi_j: np.ndarray, cfg: dict,
                  wrap_flag: bool, tol: float | None = None,
                  gensig_i: tuple | None = None, gensig_j: tuple | None = None):
        """
        Omega-cache key; includes optional generator signatures for each endpoint.
        """
        di = _arr_digest(phi_i, tol=tol)
        dj = _arr_digest(phi_j, tol=tol)
        pair_sha = hashlib.sha256((di + "|" + dj).encode()).hexdigest()
        return ("Omega", int(agent_i), int(agent_j), int(step),
                _shape_sig(phi_i), bool(wrap_flag), _config_digest(cfg),
                gensig_i, gensig_j, pair_sha)


    def key_Fisher(self, *, agent_id: int, step: int,
                   mu: np.ndarray, Sigma: np.ndarray,
                   cfg: dict, which: str = "q", tol: float | None = None):
        mu  = np.asarray(mu,    np.float32)
        Sig = np.asarray(Sigma, np.float32)
        mu_sha  = _arr_digest(mu,  tol=tol)
        Sig_sha = _arr_digest(Sig, tol=tol)
        shape   = _shape_sig(Sig)
        return ("Fisher", which, int(agent_id), int(step),
                shape, _config_digest(cfg), mu_sha, Sig_sha)

    # ---- typed get/put with counters ----
    def get(self, ns_name: str, key):
        ns = self.ns(ns_name)
        val = ns.get(key)
        if val is None: self.misses += 1
        else:           self.hits += 1
        return val

    def put(self, ns_name: str, key, value):
        self.ns(ns_name)[key] = value

    def invalidate_like(self, ns_name: str, predicate):
        ns = self.ns(ns_name)
        todel = [k for k in list(ns.keys()) if predicate(k)]
        for k in todel:
            ns.pop(k, None)
        self.invalidations += len(todel)

   # def full_stats(self) -> Dict[str, int]:
   #     out = self.stats()
   #     out.update({"hits": self.hits, "misses": self.misses, "invalidations": self.invalidations})
    #    return out

# ─────────────────────────────────────────────────────────────────────────────
# Neighbor graph (single level)
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class LevelGraph:
    level: int
    agent_ids: List[int]
    neighbors: Dict[int, List[int]] = field(default_factory=dict)  # id -> [neighbor ids]

# ─────────────────────────────────────────────────────────────────────────────
# Runtime context (single-scale)
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class RuntimeCtx:
    global_step: int = 0
    agents_by_level: Dict[int, Dict[int, Any]] = field(default_factory=dict)  # L -> {id: Agent}
    graphs: Dict[int, LevelGraph] = field(default_factory=dict)               # L -> LevelGraph
    cache: CacheHub = field(default_factory=CacheHub)
    dirty: WorkFlags = field(default_factory=WorkFlags)
    fields: Dict[str, Any] = field(default_factory=dict)        # <--- NEW

    def register_agents(self, level: int, agents: List[Any]) -> None:
        lvl = self.agents_by_level.setdefault(level, {})
        lvl.clear()
        for a in agents:
            lvl[int(getattr(a, "id"))] = a

    def build_neighbors(self, level: int, neighbor_map: Dict[int, List[int]]) -> None:
        ids = list(self.agents_by_level.get(level, {}).keys())
        nm: Dict[int, List[int]] = {i: [j for j in neighbor_map.get(i, []) if j in ids] for i in ids}
        self.graphs[level] = LevelGraph(level=level, agent_ids=ids, neighbors=nm)

    def neighbors_of(self, level: int, agent_id: int) -> List[int]:
        g = self.graphs.get(level)
        return [] if not g else g.neighbors.get(int(agent_id), [])

    def agent(self, level: int, agent_id: int) -> Any:
        return self.agents_by_level[level][int(agent_id)]

    def agents(self, level: int) -> List[Any]:
        if level not in self.graphs:
            return list(self.agents_by_level.get(level, {}).values())
        g = self.graphs[level]
        return [self.agents_by_level[level][aid] for aid in g.agent_ids]

    def cache_stats(self) -> dict:
        return {} if not getattr(self, "cache", None) else self.cache.stats()



class Theta:
    def __init__(self, D_obs: int, K_latent: int, rng=None,
                 sigma2_init: float = 1.0, sigma2_min: float = 1e-3,
                 w_scale: float | None = None):
        rng = rng or np.random.default_rng(0)
        scale = (1.0 / max(K_latent, 1)) if w_scale is None else float(w_scale)

        W = rng.standard_normal((D_obs, K_latent)) * scale
        b = np.zeros((D_obs,), dtype=np.float32)

        self.W = np.nan_to_num(W, nan=0.0, posinf=0.0, neginf=0.0).astype(np.float32)
        self.b = np.nan_to_num(b, nan=0.0, posinf=0.0, neginf=0.0).astype(np.float32)
        self.sigma2 = float(max(sigma2_init, sigma2_min))

        self.D_obs = int(D_obs)
        self.K_latent = int(K_latent)

    def __repr__(self) -> str:
        return (f"Theta(D={self.D_obs}, K={self.K_latent}, "
                f"||W||_F={float(np.linalg.norm(self.W)):.3e}, "
                f"sigma2={self.sigma2:.3e})")

def ensure_theta(ctx, D_obs: int, K_latent: int, *,
                 sigma2_init: float = 1.0, sigma2_min: float = 1e-3,
                 w_scale: float | None = None) -> Theta:
    """
    Create (or validate) a global Theta on ctx.
    Uses ctx.rng if present for reproducible init.
    """
    # prefer a shared RNG on ctx
    rng = getattr(ctx, "rng", None)
    if rng is None:
        rng = np.random.default_rng(0)
        setattr(ctx, "rng", rng)

    th = getattr(ctx, "theta", None)
    if th is None:
        th = Theta(D_obs, K_latent, rng=rng,
                   sigma2_init=sigma2_init, sigma2_min=sigma2_min,
                   w_scale=w_scale)
        setattr(ctx, "theta", th)
        return th

    # Validate shapes; reinit or raise
    if (th.D_obs != D_obs) or (th.K_latent != K_latent):
        # Option A (strict): raise for clarity
        # raise ValueError(f"ensure_theta: existing Theta has (D={th.D_obs},K={th.K_latent}) "
        #                  f"but requested (D={D_obs},K={K_latent}).")
        # Option B (auto-reinit): uncomment to replace instead of raising
        th = Theta(D_obs, K_latent, rng=rng,
                   sigma2_init=sigma2_init, sigma2_min=sigma2_min,
                   w_scale=w_scale)
        setattr(ctx, "theta", th)
        return th

    # Sanitize in case external code mutated theta
   # th.W = np.nan_to_num(th.W, nan=0.0, posinf=0.0, neginf=0.0).astype(np.float32)
   # th.b = np.nan_to_num(th.b, nan=0.0, posinf=0.0, neginf=0.0).astype(np.float32)
    if not np.isfinite(th.sigma2) or th.sigma2 <= 0.0:
        th.sigma2 = float(max(sigma2_init, sigma2_min))

    return th


# ─────────────────────────────────────────────────────────────────────────────
# Convenience
# ─────────────────────────────────────────────────────────────────────────────

def ensure_runtime_defaults(ctx: Optional[RuntimeCtx]) -> RuntimeCtx:
    if ctx is None:
        ctx = RuntimeCtx()
    if ctx.global_step is None:
        ctx.global_step = 0
    if not hasattr(ctx, "dirty") or ctx.dirty is None:
        ctx.dirty = WorkFlags(step_tag=ctx.global_step)
    return ctx

__all__ = [
    "CacheHub",
    "LevelGraph",
    "RuntimeCtx",
    "ensure_runtime_defaults",
]
