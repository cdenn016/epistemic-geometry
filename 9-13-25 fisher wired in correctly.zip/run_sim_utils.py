from __future__ import annotations
"""
Created on Tue Aug 12 20:36:43 2025

@author: chris and christine
"""
# -*- coding: utf-8 -*-
"""run_sim_utils — streamlined"""

import os, pickle
from typing import Dict
import numpy as np
import core.config as config

from core.get_generators import make_reducible_generators
from diagnostics import compute_global_metrics, print_energy_breakdown

from core.agent_initialization import initialize_agents, initialize_agent_gradients
from runtime_context import ensure_runtime_defaults
from diagnostics import total_energy
import json, pathlib

# ------------------------------- Logging defaults ----------------------------
# replace your LOGGING_DEFAULTS with this
LOGGING_DEFAULTS = dict(
    enable_scalar=True,          # per-step scalar metrics
    enable_fields=False,         # heavy snapshots off by default
    child_snapshot_every=0,
    child_snapshot_dir="children",
    full_field_outdir="snapshots",  # <— used by generalized_simulation.py
)




def _sync_ctx_config_from_global(ctx):
    try:
        import core.config as g
    except Exception:
        import config as g

    ctx.config = {
        "alpha": float(getattr(g, "alpha", 1.0)),
        "beta": float(getattr(g, "beta", 0.0)),                 # alignment (q)
        "beta_model": float(getattr(g, "beta_model", 0.0)),     # alignment (p)
        "feedback_weight": float(getattr(g, "feedback_weight", 0.0)),  # keep 0 if unused
        "belief_mass": float(getattr(g, "belief_mass", 0.0)),
        "model_mass": float(getattr(g, "model_mass", 0.0)),
        "curvature_weight": float(getattr(g, "curvature_weight", 0.0)),
        "model_curvature_weight": float(getattr(g, "model_curvature_weight", 0.0)),
        "energy_eps": float(getattr(g, "energy_eps", 1e-6)),
        "support_cutoff_eps": float(getattr(g, "support_cutoff_eps", 1e-3)),
        "grid_dx": float(getattr(g, "grid_dx", 1.0)),
    }


def ensure_runtime(params: Dict):
    """Create/normalize the runtime context once and attach to params."""
    ctx = ensure_runtime_defaults(params.get("runtime_ctx", None))  # or your existing builder
    _sync_ctx_config_from_global(ctx)
    return ctx


def _prewarm_for_diagnostics(ctx, agents):
    try:
        from transport.transport_cache import Phi
    except Exception:
        return
    for a in agents:
        # Warm both directions Φ just once per agent
        try:
            Phi(ctx, a, kind="q_to_p")
            Phi(ctx, a, kind="p_to_q")
        except Exception:
            pass







def log_and_viz_after_step(runtime_ctx, agents, step, outdir, params, logcfg,
                           parent_metrics, metric_log, num_cores):
    """
    Minimal, objective-faithful logging hook.
    - Uses ctx+cache diagnostics for energies (self, feedback, mass, curvature).
    - Leaves your existing field logging/viz toggles intact:
        logcfg["enable_scalar"], logcfg["enable_fields"], etc. (optional)
    - No global config access; everything via runtime_ctx.config if needed.
    """
    ctx = runtime_ctx
    _sync_ctx_config_from_global(ctx)  # <— reflect any runtime overrides
    _prewarm_for_diagnostics(ctx, agents)
    # ---- 1) Energies from the SAME primitives as the solver ----
    metrics_global = compute_global_metrics(ctx, agents)
    print_energy_breakdown(ctx, metrics_global)
    
    E, terms = total_energy(ctx, agents, return_breakdown=True)
    metrics_global = dict(terms); metrics_global["E_total"] = E

    # ---- 3) Optional: push per-step scalars into your trackers ----
    if bool(logcfg.get("enable_scalar", True)):
        metric_log.append({
            "step": int(getattr(ctx, "global_step", step)),
            "E_total": float(metrics_global.get("E_total", 0.0)),
            "mean_total": float(metrics_global.get("mean_total", 0.0)),
            "self_sum": float(metrics_global.get("self_sum", 0.0)),
            "feedback_sum": float(metrics_global.get("feedback_sum", 0.0)),
            "mass_q_sum": float(metrics_global.get("mass_q_sum", 0.0)),
            "mass_p_sum": float(metrics_global.get("mass_p_sum", 0.0)),
            "curv_q_sum": float(metrics_global.get("curv_q_sum", 0.0)),
            "curv_p_sum": float(metrics_global.get("curv_p_sum", 0.0)),
        })





def load_checkpoint(outdir: str):
    # prefer compressed if present
    for name in ("checkpoint.pkl.xz", "checkpoint.pkl"):
        p = os.path.join(outdir, name)
        if os.path.exists(p):
            if name.endswith(".xz"):
                import lzma
                with lzma.open(p, "rb") as f:
                    return pickle.load(f), name
            with open(p, "rb") as f:
                return pickle.load(f), name
    # fall back to last step_XXXX
    step_files = sorted([f for f in os.listdir(outdir) if f.startswith("step_") and (f.endswith(".pkl") or f.endswith(".pkl.xz"))])
    if not step_files: return (None, None)
    last = step_files[-1]
    if last.endswith(".xz"):
        import lzma
        with lzma.open(os.path.join(outdir, last), "rb") as f:
            return pickle.load(f), last
    with open(os.path.join(outdir, last), "rb") as f:
        return pickle.load(f), last


def find_resume_step(outdir: str) -> int:
    step_files = sorted([f for f in os.listdir(outdir) if f.startswith("step_") and (f.endswith(".pkl") or f.endswith(".pkl.xz"))])
    if not step_files: return 0
    last = step_files[-1]
    num = last.replace("step_", "").replace(".pkl.xz","").replace(".pkl","")
    try: return int(num) + 1
    except: return 0




def merge_logging_cfg(params_or_cfg) -> Dict:
    cfg = {}
    if hasattr(params_or_cfg, "get"):       # dict-like
        cfg = params_or_cfg.get("logging", {}) or {}
    elif hasattr(params_or_cfg, "__dict__"): # module-like (config)
        cfg = getattr(params_or_cfg, "logging", {}) or {}
    out = dict(LOGGING_DEFAULTS)
    out.update(cfg)
    return out


# ------------------------------ Generator prep ------------------------------

def prepare_generators(params):
    import core.config as config
    

    p = dict(params or {})
    group = p.get("group_name", getattr(config, "group_name", "so3")).lower()

  # run_sim_utils.py → prepare_generators
    if "generators_q" in p and "generators_p" in p:
        Gq, Gp = p["generators_q"], p["generators_p"]
               
        config.K_q = int(Gq.shape[1]); config.K_p = int(Gp.shape[1])
        return Gq, Gp


    # Spec-path (SO(3) only): e.g. [(1,2),(2,1)]
    spec_q = p.get("so3_spec_q"); spec_p = p.get("so3_spec_p")
    mix = bool(p.get("so3_mix_blocks", False))

    if group == "so3" and (spec_q or spec_p):
        Gq = make_reducible_generators(spec_q, mix=mix).astype(np.float32)
        Gp = make_reducible_generators(spec_p, mix=mix).astype(np.float32)
        # Keep config consistent with agent init paths
        config.K_q = int(Gq.shape[1]); config.K_p = int(Gp.shape[1])
        return Gq, Gp

   
        
    return Gq, Gp


# -------------------------- Init / resume helpers ---------------------------

def initialize_or_resume(outdir: str, resume: bool, params: Dict, clear_agent_logs: bool = True):
    """Return (agents, step_start)."""
    if resume:
        agents, _ = load_checkpoint(outdir)
        step_start = find_resume_step(outdir)
    else:
        gq = params.get("generators_q") if isinstance(params, dict) else None
        gp = params.get("generators_p") if isinstance(params, dict) else None
        agents = initialize_agents(
            seed=params.get("seed", 0),
            domain_size=(config.L, config.L),
            N=config.N,
            K_q=config.K_q,
            K_p=config.K_p,
            lie_algebra_dim=getattr(config, "lie_algebra_dim", 3),
            fixed_location=getattr(config, "fixed_location", True),
            params=params,
            generators_q=gq,
            generators_p=gp,
        )
        step_start = 0
        for A in agents:
            initialize_agent_gradients(A, config)
        if clear_agent_logs:
            for A in agents:
                if hasattr(A, "metrics_log"):
                    A.metrics_log.clear()
    return agents, step_start




def save_step(agents, outdir, step, *, save_every=1, compress=True):
    import os, pickle
    os.makedirs(outdir, exist_ok=True)
    if (step % int(save_every)) != 0:
        return
    fname = os.path.join(outdir, f"step_{step:04d}.pkl")
    if compress:
        import lzma
        with lzma.open(fname + ".xz", "wb", preset=3) as f:
            pickle.dump(agents, f, protocol=pickle.HIGHEST_PROTOCOL)
    else:
        with open(fname, "wb") as f:
            pickle.dump(agents, f, protocol=pickle.HIGHEST_PROTOCOL)


  

# --- fix: checkpoint save_step wrong kw ---------------------------------------
def checkpoint_step(agents, outdir):
    """Optional pre-checkpoint compaction; then save a non-step checkpoint."""
    for A in agents:
        if hasattr(A, "clear_omega_cache"):   A.clear_omega_cache()
        if hasattr(A, "clear_fisher_caches"): A.clear_fisher_caches()
    save_step(agents, outdir, step=None)  # filename handled by save_step





def _write_metric_artifacts(outdir: str, metric_log: list[dict]):
    if not metric_log: return
    out = pathlib.Path(outdir)
    out.mkdir(parents=True, exist_ok=True)
    # pickle (legacy) + jsonl (human/tooling-friendly)
    with open(out / "metric_log.pkl", "wb") as f:
        pickle.dump(metric_log, f, protocol=pickle.HIGHEST_PROTOCOL)
    with open(out / "metrics.jsonl", "w", encoding="utf-8") as f:
        for rec in metric_log:
            f.write(json.dumps(rec, ensure_ascii=False) + "\n")

def wrap_epilogue(runtime_ctx, agents, outdir, parent_metrics, metric_log):
    # flush metrics & a lightweight “run.json” context stub
    try:
        _write_metric_artifacts(outdir, metric_log or [])
        with open(os.path.join(outdir, "run.json"), "w", encoding="utf-8") as f:
            json.dump({
                "steps": int(getattr(getattr(runtime_ctx, "config", {}), "steps", len(metric_log)) 
                             if hasattr(runtime_ctx, "config") else len(metric_log)),
                "global_step": int(getattr(runtime_ctx, "global_step", -1)),
            }, f)
    except Exception as e:
        print(f"[WRAP] failed to write artifacts: {e}")
