# -*- coding: utf-8 -*-
"""
Created on Wed Jul 23 10:32:58 2025

@author: chris and christine
"""

import time
from joblib import Parallel, delayed
import numpy as np
import config
from natural_gradient import (compute_inverse_fisher_field_natural,
                              )
from get_generators import get_generators
from omega import exp_lie_algebra_irrep, d_exp_phi_exact, d_exp_phi_tilde_exact
             
from numerical_utils import sanitize_sigma, safe_omega_inv, safe_inv, soft_clip_phi_norm         
from generalized_diagnostics_metrics import compute_alignment_field_general

from update_terms_phi import ( 
    accumulate_phi_morphism_self_feedback, accumulate_phi_alignment_gradient,
    grad_feedback_phi_direct, grad_feedback_phi_tilde_direct, grad_self_phi_direct,
    grad_self_phi_tilde_direct)

from update_terms_mu_sigma import accumulate_mu_sigma_gradient

from bundle_morphism_utils import compute_direct_morphisms


def zero_all_gradients(agent_i):
    import numpy as np

    def ensure_writeable(arr):
        if arr is None:
            return None
        if not arr.flags.writeable:
            return np.copy(arr)
        return arr

    # μ and Σ gradients (belief)
    agent_i.grad_mu_q_field = ensure_writeable(agent_i.grad_mu_q_field)
    agent_i.grad_sigma_q_field = ensure_writeable(agent_i.grad_sigma_q_field)
    agent_i.grad_mu_q = agent_i.grad_mu_q_field
    agent_i.grad_sigma_q = agent_i.grad_sigma_q_field

    # μ and Σ gradients (model)
    agent_i.grad_mu_p_field = ensure_writeable(agent_i.grad_mu_p_field)
    agent_i.grad_sigma_p_field = ensure_writeable(agent_i.grad_sigma_p_field)
    agent_i.grad_mu_p = agent_i.grad_mu_p_field
    agent_i.grad_sigma_p = agent_i.grad_sigma_p_field

    # Gauge field gradients
    agent_i.grad_phi = ensure_writeable(agent_i.grad_phi)
    agent_i.grad_phi_tilde = ensure_writeable(agent_i.grad_phi_tilde)

    # Morphism gradients
    agent_i.grad_Phi = ensure_writeable(agent_i.grad_Phi)
    agent_i.grad_Phi_tilde = ensure_writeable(agent_i.grad_Phi_tilde)

    
    # Zero everything else
    agent_i.grad_mu_q_field.fill(0)
    agent_i.grad_sigma_q_field.fill(0)
    agent_i.grad_mu_p_field.fill(0)
    agent_i.grad_sigma_p_field.fill(0)
    agent_i.grad_phi.fill(0)
    agent_i.grad_phi_tilde.fill(0)
    if agent_i.grad_Phi is not None:
        agent_i.grad_Phi.fill(0)
    if agent_i.grad_Phi_tilde is not None:
        agent_i.grad_Phi_tilde.fill(0)

        

def build_all_omega_caches(agents):
    """
    Build Ω and Ω̃ caches for each agent using their precomputed exp(φ).
    Should be called AFTER preprocess_agent_fields for all agents.
    """
    for agent_i in agents:
        agent_i.Omega_cache = {}
        agent_i.Omega_tilde_cache = {}

        for nb in agent_i.neighbors:
            j = nb["id"]
            agent_j = agents[j]

            Omega_ij = np.einsum("...ik,...kj->...ij", agent_i._exp_phi, agent_j._exp_neg_phi)
            Omega_tilde_ij = np.einsum("...ik,...kj->...ij", agent_i._exp_phi_model, agent_j._exp_neg_phi_model)

            agent_i.Omega_cache[j] = Omega_ij
            agent_i.Omega_tilde_cache[j] = Omega_tilde_ij
            
def preprocess_agent_fields(agent, params):
    """
    Sanitize sigmas, convert to natural parameters, cache Fisher info,
    compute exp(φ), exp(−φ), and inverse Fisher metrics.
    """
   

    # ───── Fetch Lie algebra generators from config ─────
    group_name = config.group_name
    G_q = get_generators(group_name, config.K_q)
    G_p = get_generators(group_name, config.K_p)

    # ───── Sanitize covariance fields ─────
    agent.sigma_q_field = sanitize_sigma(agent.sigma_q_field, eps=config.eps)
    agent.sigma_p_field = sanitize_sigma(agent.sigma_p_field, eps=config.eps)
    
    
    # ───── Compute exp(φ), exp(−φ) for belief ─────
    agent._exp_phi = exp_lie_algebra_irrep(
        agent.phi,
        G_q,
        group_name=group_name,
        max_norm=config.phi_exp_clip,
        threshold=getattr(config, "phi_exp_threshold", 1e-3),
        n_jobs=-1,
        verbose=False
    )

    # ───── Compute exp(φ_model), exp(−φ_model) for model ─────
    agent._exp_phi_model = exp_lie_algebra_irrep(
        agent.phi_model,
        G_p,
        group_name=group_name,
        max_norm=config.phi_exp_clip,
        threshold=getattr(config, "phi_exp_threshold", 1e-3),
        n_jobs=-1,
        verbose=False
    )
    agent._exp_neg_phi = safe_omega_inv(agent._exp_phi, debug=True)
    agent._exp_neg_phi_model = safe_omega_inv(agent._exp_phi_model, debug=True)

    # ─── Build and cache Omega fields ───
    agent.Omega_cache = {}
    agent.Omega_tilde_cache = {}

    # ───── Optional inverse Fisher metric cache for φ updates ─────
    agent.inverse_fisher_phi = compute_inverse_fisher_field_natural(agent, G_q, field="phi")
    agent.inverse_fisher_phi_model = compute_inverse_fisher_field_natural(agent, G_p, field="phi_model")



def compute_all_gradients(agent_i, agents, generators_q, generators_p, params):
    zero_all_gradients(agent_i)

    timings = {}

    # ─── Belief μ, Σ ───
    t0 = time.perf_counter()
    accumulate_mu_sigma_gradient(agent_i, agents, params, mode="belief")
    timings["mu_sigma_belief"] = time.perf_counter() - t0

    # ─── Model μ, Σ ───
    t0 = time.perf_counter()
    accumulate_mu_sigma_gradient(agent_i, agents, params, mode="model")
    timings["mu_sigma_model"] = time.perf_counter() - t0

    # ─── Belief alignment: φᵢ ───
    t0 = time.perf_counter()
    # Precompute once per i
    Q_all_belief_i = d_exp_phi_exact(agent_i.phi, generators_q)
    exp_neg_cache_belief = {}  # j.id -> e^{-φ_j}
    for nb in agent_i.neighbors:
        agent_j = agents[nb["id"]]
        exp_neg_phi_j = exp_neg_cache_belief.get(agent_j.id)
        if exp_neg_phi_j is None:
            exp_neg_phi_j = safe_omega_inv(agent_j._exp_phi, eps=config.eps, debug=False)
            exp_neg_cache_belief[agent_j.id] = exp_neg_phi_j

        accumulate_phi_alignment_gradient(
            agent_i, agent_j, generators_q, params,
            field="phi",
            beta_key="beta",
            omega_cache_key="Omega_cache",
            mu_key="mu_q_field",
            sigma_key="sigma_q_field",
            fisher_inv_key="inverse_fisher_phi",
            grad_key="grad_phi",
            # precomputes:
            Q_all_i=Q_all_belief_i,
            exp_neg_phi_j=exp_neg_phi_j,
        )
    timings["phi_alignment"] = time.perf_counter() - t0

    # ─── Model alignment: φ̃ᵢ ───
    t0 = time.perf_counter()
    Q_all_model_i = d_exp_phi_exact(agent_i.phi_model, generators_p)
    exp_neg_cache_model = {}  # j.id -> e^{-φ̃_j}
    for nb in agent_i.neighbors:
        agent_j = agents[nb["id"]]
        exp_neg_phi_j = exp_neg_cache_model.get(agent_j.id)
        if exp_neg_phi_j is None:
            exp_neg_phi_j = safe_omega_inv(agent_j._exp_phi_model, eps=config.eps, debug=False)
            exp_neg_cache_model[agent_j.id] = exp_neg_phi_j

        accumulate_phi_alignment_gradient(
            agent_i, agent_j, generators_p, params,
            field="phi_model",
            beta_key="beta_model",
            omega_cache_key="Omega_tilde_cache",
            mu_key="mu_p_field",
            sigma_key="sigma_p_field",
            fisher_inv_key="inverse_fisher_phi_model",
            grad_key="grad_phi_tilde",
            # precomputes:
            Q_all_i=Q_all_model_i,
            exp_neg_phi_j=exp_neg_phi_j,
        )
    timings["phi_tilde_alignment"] = time.perf_counter() - t0

    # ─── Morphism feedback/self: φᵢ ───
    t0 = time.perf_counter()
    accumulate_phi_morphism_self_feedback(
        agent_i, generators_p, generators_q, params,
        field="phi",
        fisher_inv_key="inverse_fisher_phi",
        grad_key="grad_phi",
        phi_self_func=grad_self_phi_direct,               # vectorized version OK
        phi_feedback_func=grad_feedback_phi_direct,       # vectorized version OK
    )
    timings["phi_morphism"] = time.perf_counter() - t0

    # ─── Morphism feedback/self: φ̃ᵢ ───
    t0 = time.perf_counter()
    accumulate_phi_morphism_self_feedback(
        agent_i, generators_p, generators_q, params,
        field="phi_model",
        fisher_inv_key="inverse_fisher_phi_model",
        grad_key="grad_phi_tilde",
        phi_self_func=grad_self_phi_tilde_direct,         # vectorized version OK
        phi_feedback_func=grad_feedback_phi_tilde_direct, # vectorized version OK
    )
    timings["phi_tilde_morphism"] = time.perf_counter() - t0

    if getattr(config, "debug_grad_timing", False):
        print(f"\n[GRAD TIMINGS] Agent {agent_i.id}")
        for k, v in timings.items():
            print(f"  {k:22s} : {v*1e3:7.2f} ms")

    return (
        (agent_i.grad_mu_q, agent_i.grad_sigma_q),
        (agent_i.grad_mu_p, agent_i.grad_sigma_p),
        agent_i.grad_phi,
        agent_i.grad_phi_tilde,
        agent_i.grad_Phi,
        agent_i.grad_Phi_tilde,
    )




def compute_adaptive_eta(base_eta, grad, cached_kl, sigma_field, scaling_kl, scaling_cond, eta_min):
    """
    Computes adaptive step size η based on KL alignment and condition number proxy of Σ.

    Uses:
        - KL divergence (or grad norm fallback)
        - Condition proxy: trace(Σ) / det(Σ)^{1/K} (safer than cond)

    Returns:
        eta_scaled: clipped η in [eta_min, base_eta]
    """
    eps = 1e-8
    K = sigma_field.shape[-1]

    # KL or fallback to grad norm
    kl_term = (
        np.mean(cached_kl)
        if cached_kl is not None and np.isfinite(np.mean(cached_kl))
        else np.mean(np.abs(grad))
    )

    try:
        # Reshape to (..., K, K)
        Sigma = sigma_field.reshape(-1, K, K)
        traces = np.trace(Sigma, axis1=-2, axis2=-1)            # (...,)
        dets = np.linalg.det(Sigma)                             # (...,)
        dets = np.clip(dets, eps, None)                         # avoid divide by 0
        cond_proxy = traces / (dets ** (1.0 / K))               # (...,)
        cond_avg = np.mean(cond_proxy)
    except Exception:
        cond_avg = 1.0

    denom = 1.0 + scaling_kl * kl_term + scaling_cond * cond_avg
    eta_scaled = base_eta / denom
    return np.clip(eta_scaled, eta_min, base_eta)




def apply_phi_updates(agent, grad_phi, grad_phi_m, mask, params):
    mask_exp = mask[..., None]

    def clip_lie_update(delta, threshold):
        if threshold <= 0:
            return delta
        norm = np.linalg.norm(delta, axis=-1, keepdims=True)
        factor = np.minimum(1.0, threshold / (norm + 1e-8))
        return delta * factor

    # Extract config safely
    cfg = {k: getattr(config, k) for k in dir(config) if not k.startswith("__")}
    if params is not None:
        cfg.update(params)

    # φ adaptive update
    eta_phi_tuned = compute_adaptive_eta(
        cfg["tau_phi"],
        grad_phi,
        getattr(agent, "cached_alignment_kl", None),
        agent.sigma_q_field,
        cfg["eta_phi_adaptive_scaling"],
        cfg["eta_sigma_condition_scaling"],
        cfg["eta_phi_min"],
    )
    delta_phi = eta_phi_tuned * grad_phi
    delta_phi = clip_lie_update(delta_phi, cfg.get("phi_grad_clip_threshold", 5.0))
    delta_phi = np.nan_to_num(delta_phi, nan=0.0, posinf=1e5, neginf=-1e5)
    agent.phi -= delta_phi * mask_exp

    # φ̃ adaptive update
    eta_phi_m_tuned = compute_adaptive_eta(
        cfg["tau_phi_model"],
        grad_phi_m,
        getattr(agent, "cached_model_alignment_kl", None),
        agent.sigma_p_field,
        cfg["eta_phi_model_adaptive_scaling"],
        cfg["eta_sigma_condition_scaling"],
        cfg["eta_phi_model_min"],
    )
    delta_phi_m = eta_phi_m_tuned * grad_phi_m
    delta_phi_m = clip_lie_update(delta_phi_m, cfg.get("phi_model_grad_clip_threshold", 5.0))
    delta_phi_m = np.nan_to_num(delta_phi_m, nan=0.0, posinf=1e5, neginf=-1e5)
    agent.phi_model -= delta_phi_m * mask_exp




def synchronous_step(agents, generators_q, generators_p, params=None, n_jobs=1):
    params = params or {}
    N = len(agents)

    tau_mu_belief    = params.get("tau_mu_belief",  config.tau_mu_belief)
    tau_sigma_belief = params.get("tau_sigma_belief", config.tau_sigma_belief)
    tau_mu_model     = params.get("tau_mu_model",   config.tau_mu_model)
    tau_sigma_model  = params.get("tau_sigma_model", config.tau_sigma_model)
    eps = config.eps

    # ── Step 1: preprocess φ fields (exp(φ), exp(−φ), Fisher caches, etc.)
    Parallel(n_jobs=n_jobs, backend="threading", batch_size=1)(
        delayed(preprocess_agent_fields)(A, params) for A in agents
    )

    # ── Step 2: build Ω/Ω̃ caches for current φ/φ̃
    build_all_omega_caches(agents)

    # ── Step 3: compute all gradients
    grads = Parallel(n_jobs=n_jobs, backend="loky", batch_size=2)(
        delayed(compute_all_gradients)(agent_i, agents, generators_q, generators_p, params)
        for agent_i in agents
    )
    q_updates, p_updates, phi_grads, phi_m_grads, morphism_grads, morphism_tilde_grads = zip(*grads)
    mask_list = [A.mask for A in agents]

    # ── Step 4: apply η and φ updates
    def apply_agent_updates(i):
        agent = agents[i]
        mask  = mask_list[i]

        Δη1_q, Δη2_q = q_updates[i]
        Δη1_p, Δη2_p = p_updates[i]

        # Fallback safeguards
        if Δη1_q is None: Δη1_q = np.zeros_like(agent.mu_q_field)
        if Δη2_q is None: Δη2_q = np.zeros_like(agent.sigma_q_field)
        if Δη1_p is None: Δη1_p = np.zeros_like(agent.mu_p_field)
        if Δη2_p is None: Δη2_p = np.zeros_like(agent.sigma_p_field)

        mask_mu    = mask[..., None]
        mask_sigma = mask[..., None, None]

        # μ updates
        agent.mu_q_field += tau_mu_belief   * Δη1_q * mask_mu
        agent.mu_p_field += tau_mu_model    * Δη1_p * mask_mu

        # Σ updates (assign; sanitize later in preprocess)
        agent.sigma_q_field = agent.sigma_q_field + tau_sigma_belief * Δη2_q * mask_sigma
        agent.sigma_p_field = agent.sigma_p_field + tau_sigma_model  * Δη2_p * mask_sigma

        # φ, φ̃ updates
        apply_phi_updates(agent, phi_grads[i], phi_m_grads[i], mask, params)
        
        #agent.phi       = soft_clip_phi_norm(agent.phi,       max_norm=np.pi)
        #agent.phi_model = soft_clip_phi_norm(agent.phi_model, max_norm=np.pi)

        # Update morphisms from new φ/φ̃
        agent.bundle_morphism_q_to_p, agent.bundle_morphism_p_to_q = compute_direct_morphisms(
            phi=agent.phi,
            phi_model=agent.phi_model,
            generators_q=agent.generators_q,
            generators_p=agent.generators_p,
            Phi_0=agent.Phi_0,
            Phi_tilde_0=agent.Phi_tilde_0,
        )

    Parallel(n_jobs=n_jobs, backend="threading")(
        delayed(apply_agent_updates)(i) for i in range(N)
    )

    # ── Step 4.5: POST-UPDATE REFRESH (MANDATORY)
    # Recompute exp(φ), exp(−φ), Fisher caches, and rebuild Ω/Ω̃
    Parallel(n_jobs=n_jobs, backend="threading", batch_size=1)(
        delayed(preprocess_agent_fields)(A, params) for A in agents
    )
    build_all_omega_caches(agents)

    # ── Step 5: recompute cached KL fields using *fresh* Ω/Ω̃
    for A in agents:
        A.cached_alignment_kl       = compute_alignment_field_general(agents, A.id, field_type="belief", log_eps=eps)
        A.cached_model_alignment_kl = compute_alignment_field_general(agents, A.id, field_type="model",  log_eps=eps)

    return agents



def clamp_sigma_trace(sigma, max_trace=1e2, eps=1e-8):
    trace = np.trace(sigma, axis1=-2, axis2=-1)  # (...,)
    scale = np.minimum(1.0, max_trace / (trace + eps))[..., None, None]
    return sigma * scale

