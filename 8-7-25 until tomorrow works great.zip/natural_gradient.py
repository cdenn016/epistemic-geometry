# -*- coding: utf-8 -*-
"""
Created on Wed Jul 23 09:23:50 2025

@author: chris and christine
"""
import numpy as np
import config
from joblib import Parallel, delayed
from numerical_utils import safe_inv
from get_generators import get_generators
from numerical_utils import sanitize_sigma
from omega import safe_bch_exact


def apply_natural_gradient_batch(mu_field, sigma_field, grad_mu_field, grad_sigma_field, mask=None):
    """
    Natural gradient for Gaussian fields:
      δμ = -Σ · ∇_μ L
      δΣ = -2 Σ · sym(∇_Σ L) · Σ
    """
    eps = getattr(config, "eps", 1e-8)
    debug = getattr(config, "debug_gradients", False)
    clip_sigma = getattr(config, "gradient_clip_sigma", 1e5)
    clip_mu    = getattr(config, "gradient_clip_mu",    None)

    H, W, K = mu_field.shape
    N = H * W
    dtype = np.result_type(mu_field, sigma_field, grad_mu_field, grad_sigma_field)

    mu_flat         = np.asarray(mu_field,        dtype=dtype).reshape(N, K)
    sigma_flat      = np.asarray(sigma_field,     dtype=dtype).reshape(N, K, K)
    grad_mu_flat    = np.asarray(grad_mu_field,   dtype=dtype).reshape(N, K)
    grad_sigma_flat = np.asarray(grad_sigma_field,dtype=dtype).reshape(N, K, K)

    delta_mu    = np.zeros_like(mu_flat)
    delta_sigma = np.zeros_like(sigma_flat)

    # Support boolean masks OR float weights
    if mask is None:
        active = np.ones(N, dtype=bool)
        weights = None
    else:
        m = np.asarray(mask).reshape(N)
        if m.dtype == bool:
            active = m
            weights = None
        else:
            active  = m > getattr(config, "support_cutoff_eps", 0.0)
            weights = m.astype(dtype, copy=False)

    for n in range(N):
        if not active[n]:
            continue

        # SPD hygiene
        Sigma = sanitize_sigma(sigma_flat[n], eps=eps)

        # Ensure the incoming grad is symmetric (tangent space)
        Gmu = grad_mu_flat[n]
        GSi = grad_sigma_flat[n]
        GSi = 0.5 * (GSi + GSi.T)

        # Natural gradient rules
        dmu = - Sigma @ Gmu
        dSi = -2.0 * Sigma @ GSi @ Sigma
        dSi = 0.5 * (dSi + dSi.T)  # keep symmetry

        # Optional clipping
        if clip_sigma is not None:
            ns = np.linalg.norm(dSi)
            if np.isfinite(ns) and ns > clip_sigma:
                dSi *= (clip_sigma / (ns + 1e-16))
        if clip_mu is not None:
            nm = np.linalg.norm(dmu)
            if np.isfinite(nm) and nm > clip_mu:
                dmu *= (clip_mu / (nm + 1e-16))

        # Optional soft weights
        if weights is not None:
            w = weights[n]
            dmu *= w
            dSi *= w

        delta_mu[n]    = np.nan_to_num(dmu)
        delta_sigma[n] = np.nan_to_num(dSi)

    return delta_mu.reshape(H, W, K), delta_sigma.reshape(H, W, K, K)



def clip_gradient_field(grad_field, threshold=None, norm_type=2, verbose=False, label="∇φ"):
    """
    Optionally clips a gradient field to a maximum norm (global across all entries).

    Args:
        grad_field : (..., d) array of gradients
        threshold  : float or None — if None, no clipping is applied
        norm_type  : int or float — 1, 2, or np.inf
        verbose    : bool — print when clipping happens
        label      : str — name for diagnostics

    Returns:
        clipped gradient field of same shape
    """
    if threshold is None:
        return grad_field

    norm = np.linalg.norm(grad_field.ravel(), ord=norm_type)
    if norm > threshold:
        scale = threshold / (norm + 1e-12)
        if verbose:
            print(f"[Clipping {label}] norm {norm:.2e} → {threshold} (scale {scale:.2e})")
        return grad_field * scale
    return grad_field


def cache_fisher_inverse_morphisms(agent_i, eps=1e-8):
    agent_i.fisher_inv_phi_model = compute_inverse_fisher_field_natural(
        agent_i.Phi,
        agent_i.generators_q_to_p,
        eps=eps
    )
    agent_i.fisher_inv_phi = compute_inverse_fisher_field_natural(
        agent_i.Phi_tilde,
        agent_i.generators_p_to_q,
        eps=eps
    )

def compute_lie_metric(generators: np.ndarray):
    """
    Compute Lie algebra inner product G_ab = Tr(G_aᵀ G_b), and return its inverse.

    Args:
        generators: (d, K, K) array of generators Gₐ ∈ 𝔤

    Returns:
        G:     (d, d) symmetric inner product matrix
        G_inv: (d, d) inverse with clipping safeguard
    """
    from numerical_utils import safe_inv
    import numpy as np
    import config

    d = generators.shape[0]

    # G_ab = Tr(G_aᵀ G_b)
    G = np.einsum("aij,bij->ab", generators, generators)

    # Symmetrize in case of small numerical asymmetry
    G = 0.5 * (G + G.T)

    # Invert with safety checks (e.g. clip small eigenvalues)
    eps = getattr(config, "eps", 1e-6)
    G_inv = safe_inv(G, eps=eps)

    return G, G_inv






def compute_inverse_fisher_field_natural(agent, generators, field="phi"):
    """
    Computes per-point inverse Fisher metric G^{-1}_{ab}(x) in the Lie algebra.
    Skips computation in regions where agent.mask < support_cutoff_eps.

    Args:
        agent: agent object with sigma_q_field or sigma_p_field
        generators: (d, K, K) Lie algebra basis
        field: "phi" or "phi_model"

    Returns:
        G_inv_field: (H, W, d, d)
    """
    sigma_field = agent.sigma_q_field if field == "phi" else agent.sigma_p_field
    mask = agent.mask > getattr(config, "support_cutoff_eps", 1e-4)

    sigma_field = sanitize_sigma(sigma_field, eps=config.eps, debug=config.debug_sanitize_sigma)

    H, W, K, _ = sigma_field.shape
    d = generators.shape[0]
    eye_K = np.eye(K)
    eye_d = np.eye(d)

    G_inv_field = np.zeros((H, W, d, d), dtype=sigma_field.dtype)

    flat_sigma = sigma_field.reshape(-1, K, K)
    flat_mask = mask.reshape(-1)
    N = flat_sigma.shape[0]

    valid_indices = np.flatnonzero(flat_mask)
    sigma_valid = flat_sigma[valid_indices]  # (M, K, K)

    # Step 1: invert Σ⁻¹ (with fallback)
    sigma_inv = np.empty_like(sigma_valid)
    for i in range(sigma_valid.shape[0]):
        try:
            sigma_inv[i] = np.linalg.inv(sigma_valid[i])
        except np.linalg.LinAlgError:
            sigma_inv[i] = eye_K
            if config.debug:
                print(f"[WARN] Σ⁻¹ failed at valid index {i}")

    # Step 2: compute G_ab[i, a, b] = Tr[Σ⁻¹ G^a Σ⁻¹ G^b]
    G_ab = np.zeros((sigma_inv.shape[0], d, d), dtype=sigma_field.dtype)

    for a in range(d):
        for b in range(d):
            G_a = np.broadcast_to(generators[a], sigma_inv.shape)
            G_b = np.broadcast_to(generators[b], sigma_inv.shape)


            G_ab[..., a, b] = np.einsum("...ij,...jk,...kl,...il->...", sigma_inv, G_a, sigma_inv, G_b)



    # Step 3: symmetrize and invert G_ab
    flat_G_inv = G_inv_field.reshape(-1, d, d)
    for i, flat_idx in enumerate(valid_indices):
        G_sym = 0.5 * (G_ab[i] + G_ab[i].T)
        try:
            cond = np.linalg.cond(G_sym)
            if not np.isfinite(cond) or cond > config.max_fisher_condition:
                raise np.linalg.LinAlgError
            flat_G_inv[flat_idx] = np.linalg.inv(G_sym + config.eps * eye_d)
        except np.linalg.LinAlgError:
            flat_G_inv[flat_idx] = eye_d
            if config.debug:
                print(f"[WARN] G_ab⁻¹ fallback at index {flat_idx}")

    return G_inv_field




def compute_inverse_fisher_morphism_field(agent, generators, direction="q_to_p", eps=1e-8):
    """
    Return the rectangular Lie-algebra-projected inverse Fisher metric (H, W, d, d)
    for Φ or Φ̃ depending on direction, using natural parameters (η₁, η₂).
    """
    assert direction in {"q_to_p", "p_to_q"}

    if direction == "q_to_p":
        Phi     = agent.bundle_morphism_q_to_p
        eta1_q  = agent.eta1_q_field
        eta2_q  = agent.eta2_q_field
        eta2_p  = agent.eta2_p_field
    else:
        Phi     = agent.bundle_morphism_p_to_q
        eta1_q  = agent.eta1_p_field
        eta2_q  = agent.eta2_p_field
        eta2_p  = agent.eta2_q_field

    _, F_inv = compute_fisher_metric_rectangular_natural(
        Phi=Phi,
        eta1_q=eta1_q,
        eta2_q=eta2_q,
        eta2_p=eta2_p,
        generators=generators,
        eps=eps,
        return_inverse=True,
    )

    return F_inv



def compute_fisher_metric_rectangular_natural(
    Phi, eta1_q, eta2_q, eta2_p, generators, eps=1e-8, return_inverse=True
):
    """
    Compute rectangular Fisher metric for Φ: B_q → B_p using natural parameters η₁, η₂.

    Args:
        Phi        : (H, W, K_p, K_q) morphism field
        eta1_q     : (H, W, K_q)
        eta2_q     : (H, W, K_q, K_q)
        eta2_p     : (H, W, K_p, K_p)
        generators : (d, K_p, K_q) rectangular Lie algebra generators
        eps        : regularization constant
        return_inverse : if True, return inverse metric

    Returns:
        F     : (H, W, d, d) Fisher metric
        F_inv : (H, W, d, d) inverse Fisher metric (if requested)
    """
    H, W, K_p, K_q = Phi.shape
    d = generators.shape[0]
    eye_d = np.eye(d)

    F = np.zeros((H, W, d, d), dtype=Phi.dtype)

    # Invert η₂_q stably
    eta2_q_inv = np.linalg.inv(eta2_q + eps * np.eye(K_q)[None, None])
    mu_q = -0.5 * np.einsum("...ij,...j->...i", eta2_q_inv, eta1_q)

    # Precompute dμ and dΣ for each generator
    # Pushforward: dmu[a] = G_a @ mu_q → shape (..., K_p)
    dmu = np.einsum("akq,...q->...ak", generators, mu_q)  # (..., d, K_p)
    dSigma = []
    for a in range(d):
        G_a = generators[a]
        term1 = np.einsum("ij,...jk,...lk->...il", G_a, eta2_q_inv, Phi)
        G_a_T = G_a.T  # (K_q, K_q)
        B = np.einsum("...ij,...jk->...ik", eta2_q_inv, G_a_T)  # (..., K_q, K_q)
        term2 = np.einsum("...ij,...jk->...ik", Phi, B)         # (..., K_p, K_q)

        dSigma.append(-0.5 * (term1 + term2))
    dSigma = np.stack(dSigma, axis=0)  # (d, H, W, K_p, K_q)

    # Main Fisher computation
    for a in range(d):
        for b in range(d):
            v_a = dmu[..., a, :]  # (..., K_p)
            v_b = dmu[..., b, :]  # (..., K_p)
            v_a = v_a[..., None]  # (..., K_p, 1)
            v_b = v_b[..., None]  # (..., K_p, 1)
            tmp = np.matmul(eta2_p, v_b)  # (..., K_p, 1)
            t1 = np.einsum("...i,...i->...", v_a[..., 0], tmp[..., 0])

            tmp = np.einsum("...ik,...kl->...il", eta2_p, dSigma[b])
            tmp = np.einsum("...ij,...jk->...ik", dSigma[a], tmp)
            t2 = np.einsum("...ii->...", tmp)
            F[..., a, b] = t1 + 0.5 * t2

    # Regularization and inverse
    F += eps * eye_d[None, None]
    F_inv = np.linalg.inv(F) if return_inverse else None
    return F, F_inv



def dexpinv_operator_morphism(Phi, grad_Phi, generators, fisher_inv_field=None, eps=1e-8):
    """
    Project Euclidean gradient ∂L/∂Φ ∈ R^{K_p × K_q} to Lie algebra coordinates 
    via inner product Tr[ ∂L/∂Φ · G^a ] for rectangular generators.

    Args:
        Phi               : (H, W, K_p, K_q) morphism field Φ : B_q → B_p
        grad_Phi          : (H, W, K_p, K_q) Euclidean gradient ∂L/∂Φ
        generators        : (d, K_p, K_q) rectangular generator basis
        fisher_inv_field  : (H, W, d, d) optional inverse Fisher metric
        eps               : numerical stabilizer

    Returns:
        grad_coords       : (H, W, d) gradient in Lie algebra coordinates
    """
    import numpy as np

    H, W, K_p, K_q = grad_Phi.shape
    d = generators.shape[0]

    # Sanity checks
    assert generators.shape == (d, K_p, K_q), f"Expected generators shape ({d},{K_p},{K_q}), got {generators.shape}"
    grad_coords = np.empty((H, W, d), dtype=grad_Phi.dtype)

    # Step 1: Project Euclidean gradient onto Lie generators
    for a in range(d):
        G_a = generators[a]
        grad_coords[..., a] = np.einsum("...ij,ij->...", grad_Phi, G_a)

    # Step 2: Apply inverse Fisher metric (optional)
    if fisher_inv_field is not None:
        # Safety check
        if fisher_inv_field.shape != (H, W, d, d):
            raise ValueError(
                f"Fisher shape mismatch: expected ({H},{W},{d},{d}), got {fisher_inv_field.shape}"
            )

        # Sanitize Fisher inverse in case it's degenerate
        
        fisher_inv_field = sanitize_sigma(fisher_inv_field, eps=eps)

        # Contract: (..., d, d) × (..., d) → (..., d)
        grad_coords = np.einsum("...ab,...b->...a", fisher_inv_field, grad_coords)

    # Step 3: Clamp extreme values (optional, diagnostic)
    if getattr(config, "debug_gradients", False):
        max_norm = np.linalg.norm(grad_coords, axis=-1).max()
        print(f"[DEBUG] Natural morphism grad max-norm: {max_norm:.2e}")

    return np.nan_to_num(grad_coords)



def dexpinv_operator(phi, delta, generators, order=3, threshold=0.25):
    """
    Vectorized inverse exponential pushforward (dexp⁻¹) on a Lie algebra grid.

    Given:
        φ     : (..., d) Lie algebra coordinates φ^a G_a
        δ     : (..., d) tangent perturbations δ^a G_a
        generators : (d, K, K) Lie algebra basis matrices
        order      : truncation order for BCH/commutator expansion (if using series)
        threshold  : norm cutoff for switching between series and exact

    Returns:
        corrected_delta : (..., d) array after applying dexpinv_φ to δ
    """
    # Shapes
    *grid_shape, d = phi.shape
    K = generators.shape[-1]

    # Metric coefficients for projection
    gen_norms = np.array([np.trace(G @ G) for G in generators], dtype=phi.dtype)

    # Matrix forms
    phi_mat   = np.einsum("...a,akl->...kl", phi,   generators)
    delta_mat = np.einsum("...a,akl->...kl", delta, generators)

    # Norm proxy: Frobenius norm of [φ, δ]
    ad1 = phi_mat @ delta_mat - delta_mat @ phi_mat
    ad_norm = np.linalg.norm(ad1, axis=(-2, -1))

    # ── Small φ: use commutator expansion ─────────────────────────────
    small_mask = ad_norm <= threshold
    if np.any(small_mask):
        out_small = delta_mat.copy()
        if order >= 1:
            out_small -= 0.5 * ad1
        if order >= 2:
            ad2 = phi_mat @ ad1 - ad1 @ phi_mat
            out_small += (1.0 / 12.0) * ad2
        if order >= 3:
            ad3 = phi_mat @ ad2 - ad2 @ phi_mat
            out_small -= (1.0 / 24.0) * ad3
    else:
        out_small = None

        # ── Large φ: use your safe BCH/logm wrapper ─────────────────────────
    large_mask = ~small_mask
    if np.any(large_mask):
        
        phi_large   = phi_mat[large_mask]
        delta_large = delta_mat[large_mask]
        composed = []
        for A, B in zip(phi_large, delta_large):
            # safe_bch_exact should already handle clipping & NaN guards
            C = safe_bch_exact(A, B)
            composed.append(C - A)
        out_large = np.stack(composed, axis=0)
    else:
        out_large = None


    # ── Combine back into full matrix field ───────────────────────────
    out_mat = np.zeros_like(phi_mat)
    if out_small is not None:
        out_mat[small_mask] = out_small[small_mask]
    if out_large is not None:
        out_mat[large_mask] = out_large

    # ── Project back to coefficients: δ^a = Tr(M·G_a) / Tr(G_a G_a) ───
    corrected = np.empty_like(phi)
    for a in range(d):
        G = generators[a]
        corrected[..., a] = np.einsum("...ij,ij->...", out_mat, G) / gen_norms[a]

    return corrected

def dexpinv_operatorOLD(phi, delta, generators, order=None, use_exact=None):
    """
    Applies the inverse of the exponential pushforward (dexp⁻¹) to a variation δ in Lie algebra coordinates.

    Specifically, given:
        φ ∈ 𝔤 — current Lie algebra coordinate
        δ ∈ 𝔤 — a variation in Lie algebra coordinates

    The function computes the corrected update:
        dexpinv(φ, δ) ∈ 𝔤

    using the relation:
        dexpinv(φ, δ) ≈ log(exp(φ) · exp(δ)) − φ   (in 𝔤)
    and then projecting back onto the Lie algebra basis.

    This accounts for the nonlinearity of the exponential map on matrix Lie groups
    and ensures that updates in the Lie algebra are consistent with the group manifold.

    Args:
        phi        : (..., d) tensor of Lie algebra elements φ^a G_a
        delta      : (..., d) tensor of tangent perturbations δ^a G_a
        generators : (d, K, K) basis of the Lie algebra 𝔤 ⊂ ℝ^{K×K}
        order      : (unused) placeholder for future use (e.g., BCH truncation order)
        use_exact  : (unused) placeholder for forcing exact logm even if fast

    Returns:
        corrected_delta : (..., d) result of dexpinv applied to delta, projected onto 𝔤
    """
    
    H, W, d = phi.shape
    corrected = np.zeros_like(delta)

    # Matrix form: φ, Δ ∈ 𝔤
    phi_mat   = np.einsum("...a,akl->...kl", phi, generators)
    delta_mat = np.einsum("...a,akl->...kl", delta, generators)

    composed = np.zeros_like(phi_mat)
    for i in range(H):
        for j in range(W):
            A = phi_mat[i, j]
            B = delta_mat[i, j]
            C = safe_bch_exact(A, B)  # full BCH or logm
            composed[i, j] = C - A

    # Project back: δ_corrected^a = Tr[(C - A) · G^a]
    for a in range(d):
        G = generators[a]
        corrected[..., a] = 2.0 * np.einsum("...ij,ij->...", composed, G)

    return corrected



def compute_fisher_geometry_gradient(agent_i, agents, params, field="phi"):
    """
    Compute ∇_{φ} or ∇_{φ̃} for Fisher geometry preservation:
        ∇‖Gᵢ − Ωᵢⱼ Gⱼ Ωᵢⱼᵀ‖²
    where G = Σ⁻¹ = -2 η₂.
    Supports field="phi" (beliefs) or "phi_model" (models).
    """
    if field == "phi":
        phi = agent_i.phi
        eta2_q = agent_i.eta2_q_field
        exp_phi = agent_i._exp_phi
        exp_neg_phi_j_name = "_exp_neg_phi"
        eta2_field_name = "eta2_q_field"
        fisher_weight = params.get("fisher_geometry_weight", config.fisher_geometry_weight)
    else:
        phi = agent_i.phi_model
        eta2_q = agent_i.eta2_p_field
        exp_phi = agent_i._exp_phi_model
        exp_neg_phi_j_name = "_exp_neg_phi_model"
        eta2_field_name = "eta2_p_field"
        fisher_weight = params.get("fisher_model_geometry_weight", config.fisher_model_geometry_weight)

    if fisher_weight <= 0:
        return np.zeros_like(phi)

    Gs = get_generators(config.group_name, config.K)
    d, K = Gs.shape[0], Gs.shape[1]
    mask_i = agent_i.mask > config.support_cutoff_eps
    if not np.any(mask_i):
        return np.zeros_like(phi)

    grad = np.zeros_like(phi)
    flat_self_mask = mask_i.reshape(-1)
    exp_phi_i = exp_phi.reshape(-1, K, K)
    G_i = (-2.0 * eta2_q).reshape(-1, K, K)

    for nb in agent_i.neighbors:
        agent_j = agents[nb["id"]]
        mask_j = agent_j.mask > config.support_cutoff_eps
        overlap = mask_i & mask_j
        if not np.any(overlap):
            continue

        flat_idxs = overlap.reshape(-1)
        if flat_idxs.size == 0:
            continue

        # G_j = -2 * η2_qj
        eta2_q_j = getattr(agent_j, eta2_field_name).reshape(-1, K, K)[flat_idxs]
        G_j = -2.0 * eta2_q_j
        exp_neg_phi_j = getattr(agent_j, exp_neg_phi_j_name).reshape(-1, K, K)[flat_idxs]

        Omega = np.einsum("mij,mjk->mik", exp_phi_i[flat_idxs], exp_neg_phi_j)  # (M, K, K)
        Omega_T = np.transpose(Omega, axes=(0, 2, 1))                           # (M, K, K)

        # Ω G_j Ωᵀ
        G_j_rot = np.einsum("mik,mkl,mlj->mij", Omega, G_j, Omega_T)           # (M, K, K)
        Delta = G_i[flat_idxs] - G_j_rot                                       # (M, K, K)

        for a in range(d):
            Ga = Gs[a]   

            #refactor to exact                                                     # (K, K)
            dOmega = np.einsum("ij,mjk->mik", Ga, Omega)                      # (M, K, K)
            dOmega_T = np.transpose(dOmega, axes=(0, 2, 1))                   # (M, K, K)

            # ∂G_rot = dΩ G Ωᵀ + Ω G dΩᵀ
            term1 = np.einsum("mik,mkl,mlj->mij", dOmega, G_j, Omega_T)
            term2 = np.einsum("mik,mkl,mlj->mij", Omega, G_j, dOmega_T)
            dG_rot = term1 + term2                                            # (M, K, K)

            dL = 2 * np.einsum("mij,mij->m", Delta, dG_rot)                   # (M,)
            grad.reshape(-1, d)[flat_idxs, a] += dL                           # update projected gradient

    grad *= fisher_weight
    grad[~mask_i] = 0.0
    return grad


