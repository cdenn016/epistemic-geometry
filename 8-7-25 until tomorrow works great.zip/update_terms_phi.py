# -*- coding: utf-8 -*-
"""
Created on Wed Jul 23 06:38:17 2025

@author: chris and christine
"""
import numpy as np
import config
from numerical_utils import safe_inv, sanitize_sigma
from omega import compute_curvature_gradient_analytical, d_exp_phi_exact
from natural_gradient import dexpinv_operator, compute_fisher_geometry_gradient

from numerical_utils import safe_inv, soft_clip_phi_norm
import numpy as np

from numerical_utils import safe_inv, sanitize_sigma

from numerical_utils import safe_omega_inv
from natural_gradient import dexpinv_operator
from omega import d_exp_phi_exact, d_exp_phi_tilde_exact

import config   

#==============================================================================
#
#                    GATHER PHI GAUGE FIELD GRADIENT TERMS
#                          Beliefs and Models
#==============================================================================
# ================================
# NEW UNIFIED FUNCTIONS
# ================================
def accumulate_phi_alignment_gradient(
    agent_i, agent_j, generators, params,
    field="phi", beta_key=None, omega_cache_key=None,
    mu_key=None, sigma_key=None,
    fisher_inv_key=None, grad_key=None,
    # NEW:
    Q_all_i=None,           # list/array len d, each (...,K,K)
    exp_neg_phi_j=None,     # (...,K,K)
):
    """
    Accumulate ∇_{φ} KL(x_i || Ω x_j) for belief or model.

    Args:
        field            : "phi" or "phi_model"
        beta_key         : param key, e.g. "beta" or "beta_model"
        omega_cache_key  : attr name for Ω cache
        mu_key           : attr name for μ field
        sigma_key        : attr name for Σ field
        fisher_inv_key   : attr name for inverse Fisher
        grad_key         : attr name for grad accumulator
        Q_all_i          : precomputed d_exp_phi_exact(getattr(agent_i, field), generators)
        exp_neg_phi_j    : precomputed e^{-φ_j}
    """
    beta = params.get(beta_key, getattr(config, beta_key))
    if beta <= 0:
        return

    eps = config.support_cutoff_eps
    joint_mask = ((agent_i.mask > eps) & (agent_j.mask > eps)).astype(float)[..., None]

    mu_i = getattr(agent_i, mu_key)
    sigma_i = getattr(agent_i, sigma_key)
    mu_j = getattr(agent_j, mu_key)
    sigma_j = getattr(agent_j, sigma_key)

    phi_i = getattr(agent_i, field)
    phi_j = getattr(agent_j, field)
    exp_phi_i = getattr(agent_i, f"_exp_{field}")
    exp_phi_j = getattr(agent_j, f"_exp_{field}")

    Omega_ij = getattr(agent_i, omega_cache_key)[agent_j.id]
    Omega_T = np.swapaxes(Omega_ij, -1, -2)

    # Pushforwards (always precomputed here)
    mu_j_t = np.einsum("...ij,...j->...i", Omega_ij, mu_j)
    sigma_j = sanitize_sigma(sigma_j, eps=config.eps)
    sigma_j_t = np.einsum("...ik,...kl,...lj->...ij", Omega_ij, sigma_j, Omega_T)
    sigma_j_t = sanitize_sigma(sigma_j_t, eps=config.eps)
    sigma_j_t_inv = safe_inv(sigma_j_t, eps=config.eps)

    # Precompute Q_all_i and e^{-φ_j} if the caller didn’t (kept for safety)
    if Q_all_i is None:
        Q_all_i = d_exp_phi_exact(phi_i, generators)
    if exp_neg_phi_j is None:
        exp_neg_phi_j = safe_omega_inv(exp_phi_j, eps=config.eps, debug=False)

    grad_phi_raw = grad_kl_wrt_phi_i(
        mu_i, sigma_i, mu_j, sigma_j,
        phi_i=phi_i, phi_j=phi_j,
        Omega_ij=Omega_ij,
        generators=generators,
        exp_phi_i=exp_phi_i,
        exp_phi_j=exp_phi_j,   # not used inside, but fine to keep API symmetric
        mu_j_t=mu_j_t,
        sigma_j_t_inv=sigma_j_t_inv,
        # NEW pass-through:
        exp_neg_phi_j=exp_neg_phi_j,
        Q_all=Q_all_i,
        eps=config.eps,
    )

    F_inv = getattr(agent_i, fisher_inv_key)
    grad_phi_nat = np.einsum("...ab,...b->...a", F_inv, grad_phi_raw)
    grad_phi = dexpinv_operator(phi_i, grad_phi_nat, generators)

    reg_grad = apply_regularization_terms_lie_natural(
        agent=agent_i,
        phi_field=phi_i,
        generators=generators,
        field=field,
        params=params,
    ) * joint_mask

    grad_accum = getattr(agent_i, grad_key)
    setattr(agent_i, grad_key, grad_accum + (beta * grad_phi + reg_grad) * joint_mask)


def accumulate_phi_morphism_self_feedback(
    agent_i,
    generators_src, generators_tgt,
    params,
    field="phi",                # or "phi_model"
    fisher_inv_key=None,
    grad_key=None,
    phi_self_func=None,         # e.g. grad_kl_self_phi_direct
    phi_feedback_func=None,     # e.g. grad_kl_feedback_phi_direct
):
    """
    Accumulate ∇_{φ} or ∇_{φ̃} from:
      - KL(q || Φ̃·p)    ← self-energy
      - KL(p || Φ·q)     ← feedback
    into:
      - agent_i.grad_phi or grad_phi_tilde
    """
    alpha   = params.get("alpha", config.alpha)
    lambda_ = params.get("feedback_weight", config.feedback_weight)
    if alpha <= 0 and lambda_ <= 0:
        return

    eps  = config.support_cutoff_eps
    mask = (agent_i.mask > eps)[..., None]

    mu_q, sigma_q = agent_i.mu_q_field, agent_i.sigma_q_field
    mu_p, sigma_p = agent_i.mu_p_field, agent_i.sigma_p_field
    phi           = agent_i.phi
    phi_tilde     = agent_i.phi_model

    F_inv = getattr(agent_i, fisher_inv_key)

    if alpha > 0:
        grad_self = phi_self_func(
            mu_q=mu_q, sigma_q=sigma_q,
            mu_p=mu_p, sigma_p=sigma_p,
            Phi_tilde_0=agent_i.Phi_tilde_0,
            phi=phi, phi_tilde=phi_tilde,
            generators_q=generators_tgt,
            generators_p=generators_src,
            exp_phi=agent_i._exp_phi,
            exp_phi_tilde=agent_i._exp_phi_model,
            eps=eps,
        )
        grad_self = np.einsum("...ab,...b->...a", F_inv, grad_self)
        grad_self = dexpinv_operator(getattr(agent_i, field), grad_self, generators_tgt)
        setattr(agent_i, grad_key, getattr(agent_i, grad_key) + alpha * grad_self * mask)

    if lambda_ > 0:
        grad_feedback = phi_feedback_func(
            mu_p=mu_p, sigma_p=sigma_p,
            mu_q=mu_q, sigma_q=sigma_q,
            Phi_0=agent_i.Phi_0,
            phi=phi, phi_tilde=phi_tilde,
            generators_q=generators_tgt,
            exp_phi=agent_i._exp_phi,
            exp_phi_tilde=agent_i._exp_phi_model,
            eps=eps,
        )
        grad_feedback = np.einsum("...ab,...b->...a", F_inv, grad_feedback)
        grad_feedback = dexpinv_operator(getattr(agent_i, field), grad_feedback, generators_tgt)
        setattr(agent_i, grad_key, getattr(agent_i, grad_key) + lambda_ * grad_feedback * mask)






#################################################################################

#==============================================================================
#
#                    WITH RESPECT TO phi_i TERMS
#                       VALIDATED
#==============================================================================
def grad_kl_wrt_phi_i(
    mu_i, sigma_i,
    mu_j, sigma_j,
    phi_i, phi_j,
    Omega_ij,
    generators,
    exp_phi_i,
    exp_phi_j,
    mu_j_t,            # required
    sigma_j_t_inv,     # required
    eps=1e-8,
    # NEW required precomputes:
    exp_neg_phi_j=None,  # required by our accumulate (we pass it)
    Q_all=None,          # required by our accumulate (we pass it)
):
    d, K, _ = generators.shape
    Omega_T = np.swapaxes(Omega_ij, -1, -2)
    delta_mu = mu_i - mu_j_t

    sigma_i = sanitize_sigma(sigma_i, eps=eps)
    grad = np.zeros((*mu_i.shape[:-1], d), dtype=mu_i.dtype)

    # Safety fallback if called standalone (optional; remove if you want strictness)
    if Q_all is None:
        Q_all = d_exp_phi_exact(phi_i, generators)
    if exp_neg_phi_j is None:
        exp_neg_phi_j = safe_omega_inv(exp_phi_j, eps=eps, debug=False)

    for a in range(d):
        Q_i   = np.einsum("...ik,...kj->...ij", Q_all[a], exp_neg_phi_j)
        Q_i_T = np.swapaxes(Q_i, -1, -2)

        trace_term = (
            -0.5 * np.einsum("...ij,...jk,...ki->...", sigma_j_t_inv, Q_i,   sigma_i)
            -0.5 * np.einsum("...ij,...jk,...ki->...", Q_i_T,        sigma_j_t_inv, sigma_i)
        )

        tmp = np.einsum("...ij,...j->...i", Q_i_T, delta_mu)
        tmp = np.einsum("...ij,...j->...i", sigma_j_t_inv, tmp)
        mean_term = -np.einsum("...i,...ij,...j->...", mu_j, Omega_T, tmp)

        v1 = np.einsum("...ij,...j->...i", sigma_j_t_inv, delta_mu)
        part1 = np.einsum("...ij,...j->...i", Q_i_T, v1)
        v2 = np.einsum("...ij,...j->...i", Q_i, delta_mu)
        part2 = np.einsum("...ij,...j->...i", sigma_j_t_inv, v2)
        mahalanobis_term = 0.5 * np.einsum("...i,...i->...", delta_mu, part1 + part2)

        grad[..., a] = trace_term + mean_term + mahalanobis_term

    return grad





def grad_feedback_phi_direct(
    mu_p, sigma_p,
    mu_q, sigma_q,
    Phi_0,
    phi,                # (..., d)
    phi_tilde,          # (..., d)
    generators_q,       # (d, K_q, K_q)
    exp_phi,            # (..., K_q, K_q)
    exp_phi_tilde,      # (..., K_p, K_p)
    eps=1e-8,
    # NEW optional precomputes:
    Q_all=None,         # (..., d, K_q, K_q) = d_exp_phi_exact(phi, generators_q)
    exp_neg_phi=None    # (..., K_q, K_q) = e^{-φ}
):
    """
    Vectorized over 'a': returns (..., d)
    Φ = e^{φ̃} Φ₀ e^{-φ}, ∂Φ = - Φ · (e^{-φ} (∂ e^{φ}) e^{-φ})
    """
    d, K_q, _ = generators_q.shape
    shape = mu_p.shape[:-1]

    if exp_neg_phi is None:
        exp_neg_phi = safe_omega_inv(exp_phi, eps=eps, debug=False)
    if Q_all is None:
        # stack as (..., d, K_q, K_q)
        Q_list = d_exp_phi_exact(phi, generators_q)
        Q_all = np.stack(Q_list, axis=-3)  # assuming list of d arrays

    # Φ and Φᵀ
    Phi = np.einsum("...ik,...kj,...jl->...il", exp_phi_tilde, Phi_0, exp_neg_phi)
    Phi_T = np.swapaxes(Phi, -1, -2)

    sigma_q = sanitize_sigma(sigma_q, eps=eps)
    sigma_p = sanitize_sigma(sigma_p, eps=eps)

    # A, A^{-1}
    A = np.einsum("...ik,...kl,...lj->...ij", Phi, sigma_q, Phi_T)
    A = sanitize_sigma(A, eps=eps)
    A_inv = safe_inv(A, eps=eps)

    # Δμ and v
    Phi_mu_q = np.einsum("...ij,...j->...i", Phi, mu_q)
    delta_mu = mu_p - Phi_mu_q
    v = np.einsum("...ij,...j->...i", A_inv, delta_mu)  # (..., K_p)

    # Q̄_a = e^{-φ} Q_a e^{-φ}
    Q_bar = np.einsum("...ik,...akl,...lj->...aij", exp_neg_phi, Q_all, exp_neg_phi)

    # dΦ_a = - Φ Q̄_a
    dPhi = -np.einsum("...ik,...akj->...aij", Phi, Q_bar)
    dPhi_T = np.swapaxes(dPhi, -1, -2)

    # dA_a
    dA = (
        np.einsum("...aik,...kl,...lj->...aij", dPhi, sigma_q, Phi_T) +
        np.einsum("...ik,...kl,...alj->...aij", Phi,  sigma_q, dPhi_T)
    )

    # Term 1
    dPhi_mu = np.einsum("...aij,...j->...ai", dPhi, mu_q)       # (..., a, K_p)
    term1 = -np.einsum("...ai,...i->...a", dPhi_mu, v)

    # Term 2
    term2 = 0.5 * np.einsum("...ij,...aij->...a", A_inv, dA)

    # M_a = A^{-1} dA_a A^{-1}
    M = np.einsum("...ij,...ajk,...kl->...ail", A_inv, dA, A_inv)

    # Term 3
    term3 = -0.5 * np.einsum("...i,...aij,...j->...a", delta_mu, M, delta_mu)

    # Term 4
    term4 = -0.5 * np.einsum("...aij,...ji->...a", M, sigma_p)

    grad = term1 + term2 + term3 + term4  # (..., d)
    return grad


def grad_feedback_phi_tilde_direct(
    mu_p, sigma_p,
    mu_q, sigma_q,
    Phi_0,
    phi, phi_tilde,
    generators_p, generators_q,
    exp_phi, exp_phi_tilde,
    eps=1e-8,
    # NEW optional precomputes:
    Q_tilde_all=None,       # (..., d, K_p, K_p) = d_exp_phi_tilde_exact(phi_tilde, generators_p)
    exp_neg_phi_tilde=None  # (..., K_p, K_p) = e^{-φ̃}
):
    """
    Vectorized over 'a': returns (..., d)
    Left-trivialize: dΦ_a = L_a Φ,  L_a = (∂e^{φ̃}/∂φ̃^a) e^{-φ̃}.
    """
    d, K_p, _ = generators_p.shape
    shape = mu_p.shape[:-1]

    if exp_neg_phi_tilde is None:
        exp_neg_phi_tilde = safe_omega_inv(exp_phi_tilde, eps=eps, debug=False)
    if Q_tilde_all is None:
        Q_list = d_exp_phi_tilde_exact(phi_tilde, generators_p)
        Q_tilde_all = np.stack(Q_list, axis=-3)

    # Φ
    exp_neg_phi = safe_omega_inv(exp_phi, eps=eps, debug=False)
    Phi   = np.einsum("...ik,...kj,...jl->...il", exp_phi_tilde, Phi_0, exp_neg_phi)
    Phi_T = np.swapaxes(Phi, -1, -2)

    sigma_q = sanitize_sigma(sigma_q, eps=eps)
    sigma_p = sanitize_sigma(sigma_p, eps=eps)

    A = np.einsum("...ik,...kl,...lj->...ij", Phi, sigma_q, Phi_T)
    A = sanitize_sigma(A, eps=eps)
    A_inv = safe_inv(A, eps=eps)

    Phi_mu_q = np.einsum("...ij,...j->...i", Phi, mu_q)
    delta_mu = mu_p - Phi_mu_q
    v = np.einsum("...ij,...j->...i", A_inv, delta_mu)

    # L_a = Q̃_a e^{-φ̃}
    L = np.einsum("...aik,...kj->...aij", Q_tilde_all, exp_neg_phi_tilde)

    # dΦ_a = L_a Φ
    dPhi = np.einsum("...aik,...kj->...aij", L, Phi)
    dPhi_T = np.swapaxes(dPhi, -1, -2)

    dA = (
        np.einsum("...aik,...kl,...lj->...aij", dPhi, sigma_q, Phi_T) +
        np.einsum("...ik,...kl,...alj->...aij", Phi,  sigma_q, dPhi_T)
    )

    dPhi_mu = np.einsum("...aij,...j->...ai", dPhi, mu_q)
    term1 = -np.einsum("...ai,...i->...a", dPhi_mu, v)

    term2 = 0.5 * np.einsum("...ij,...aij->...a", A_inv, dA)

    M = np.einsum("...ij,...ajk,...kl->...ail", A_inv, dA, A_inv)

    term3 = -0.5 * np.einsum("...i,...aij,...j->...a", delta_mu, M, delta_mu)
    term4 = -0.5 * np.einsum("...aij,...ji->...a", M, sigma_p)

    grad = term1 + term2 + term3 + term4
    return grad



def grad_self_phi_direct(
    mu_q, sigma_q,
    mu_p, sigma_p,
    Phi_tilde_0,
    phi, phi_tilde,
    generators_q, generators_p,
    exp_phi, exp_phi_tilde,
    eps=1e-8,
    # NEW optional precomputes:
    Q_all=None,               # (..., d, K_q, K_q)
    exp_neg_phi_tilde=None    # (..., K_p, K_p)
):
    """
    Vectorized over 'a': returns (..., d)
    Φ̃ = e^{φ} Φ̃₀ e^{-φ̃},  ∂Φ̃_a = (∂e^{φ}/∂φ^a) Φ̃₀ e^{-φ̃}.
    """
    d, K_q, _ = generators_q.shape
    shape = mu_q.shape[:-1]

    if exp_neg_phi_tilde is None:
        exp_neg_phi_tilde = safe_omega_inv(exp_phi_tilde, eps=eps, debug=False)
    if Q_all is None:
        Q_list = d_exp_phi_exact(phi, generators_q)
        Q_all = np.stack(Q_list, axis=-3)

    # Φ̃ and A
    Phi_tilde = np.einsum("...ik,...kj,...jl->...il", exp_phi, Phi_tilde_0, exp_neg_phi_tilde)
    Phi_tilde_T = np.swapaxes(Phi_tilde, -1, -2)

    sigma_q = sanitize_sigma(sigma_q, eps=eps)
    sigma_p = sanitize_sigma(sigma_p, eps=eps)

    A = np.einsum("...ik,...kl,...lj->...ij", Phi_tilde, sigma_p, Phi_tilde_T)
    A = sanitize_sigma(A, eps=eps)
    A_inv = safe_inv(A, eps=eps)

    delta_mu = mu_q - np.einsum("...ij,...j->...i", Phi_tilde, mu_p)

    # ∂Φ̃_a = Q_a Φ̃₀ e^{-φ̃}
    dPhi = np.einsum("...aik,...kj,...jl->...ail", Q_all, Phi_tilde_0, exp_neg_phi_tilde)
    dPhi_T = np.swapaxes(dPhi, -1, -2)

    dA = (
        np.einsum("...aik,...kl,...lj->...aij", dPhi, sigma_p, Phi_tilde_T) +
        np.einsum("...ik,...kl,...alj->...aij", Phi_tilde, sigma_p, dPhi_T)
    )

    # Term 1
    dPhi_mu_p = np.einsum("...aij,...j->...ai", dPhi, mu_p)
    term1 = -np.einsum("...ai,...i->...a", dPhi_mu_p, np.einsum("...ij,...j->...i", A_inv, delta_mu))

    # Term 2   (note: your earlier self/feedback sign conventions differ; keeping your current one)
    term2 = 0.5 * np.einsum("...ij,...aij->...a", A_inv, dA)

    # M = A^{-1} dA A^{-1}
    M = np.einsum("...ij,...ajk,...kl->...ail", A_inv, dA, A_inv)

    # Term 3
    term3 = -0.5 * np.einsum("...i,...aij,...j->...a", delta_mu, M, delta_mu)

    # Term 4
    term4 = -0.5 * np.einsum("...aij,...ji->...a", M, sigma_q)

    grad = term1 + term2 + term3 + term4
    return grad


def grad_self_phi_tilde_direct(
    mu_q, sigma_q,
    mu_p, sigma_p,
    Phi_tilde_0,
    phi, phi_tilde,
    generators_q, generators_p,
    exp_phi, exp_phi_tilde,
    eps=1e-8,
    # NEW optional precomputes:
    Q_tilde_all=None,         # (..., d, K_p, K_p)
    exp_neg_phi_tilde=None    # (..., K_p, K_p)
):
    """
    Vectorized over 'a': returns (..., d)
    Right-trivialize on model: R_a = (∂e^{φ̃}/∂φ̃^a) e^{-φ̃},  ∂Φ̃_a = - Φ̃ R_a.
    """
    d, K_p, _ = generators_p.shape
    shape = mu_q.shape[:-1]

    if exp_neg_phi_tilde is None:
        exp_neg_phi_tilde = safe_omega_inv(exp_phi_tilde, eps=eps, debug=False)
    if Q_tilde_all is None:
        Q_list = d_exp_phi_tilde_exact(phi_tilde, generators_p)
        Q_tilde_all = np.stack(Q_list, axis=-3)

    Phi_tilde = np.einsum("...ik,...kj,...jl->...il", exp_phi, Phi_tilde_0, exp_neg_phi_tilde)
    Phi_tilde_T = np.swapaxes(Phi_tilde, -1, -2)

    sigma_q = sanitize_sigma(sigma_q, eps=eps)
    sigma_p = sanitize_sigma(sigma_p, eps=eps)

    A = np.einsum("...ik,...kl,...lj->...ij", Phi_tilde, sigma_p, Phi_tilde_T)
    A = sanitize_sigma(A, eps=eps)
    A_inv = safe_inv(A, eps=eps)

    mu_t = np.einsum("...ij,...j->...i", Phi_tilde, mu_p)
    delta_mu = mu_q - mu_t

    # R_a = Q̃_a e^{-φ̃}
    R = np.einsum("...aik,...kj->...aij", Q_tilde_all, exp_neg_phi_tilde)

    # dΦ̃_a = - Φ̃ R_a
    dPhi = -np.einsum("...ik,...akj->...aij", Phi_tilde, R)
    dPhi_T = np.swapaxes(dPhi, -1, -2)

    dA = (
        np.einsum("...aik,...kl,...lj->...aij", dPhi, sigma_p, Phi_tilde_T) +
        np.einsum("...ik,...kl,...alj->...aij", Phi_tilde, sigma_p, dPhi_T)
    )

    dPhi_mu_p = np.einsum("...aij,...j->...ai", dPhi, mu_p)
    term1 = -np.einsum("...ai,...i->...a", dPhi_mu_p, np.einsum("...ij,...j->...i", A_inv, delta_mu))

    term2 = 0.5 * np.einsum("...ij,...aij->...a", A_inv, dA)

    M = np.einsum("...ij,...ajk,...kl->...ail", A_inv, dA, A_inv)

    term3 = -0.5 * np.einsum("...i,...aij,...j->...a", delta_mu, M, delta_mu)
    term4 = -0.5 * np.einsum("...aij,...ji->...a", M, sigma_q)

    grad = term1 + term2 + term3 + term4
    return grad


# =========================
# Helpers (cached, lightweight)
# =========================

def _algebra_matrix_from_coeffs(phi_coeffs, generators):
    """
    phi_coeffs: (..., d)
    generators: (d, K, K)
    returns: (..., K, K) matrix in the algebra
    """
    # sum_a phi^a G^a
    # reshape phi to broadcast over K,K
    return np.einsum("...a,aij->...ij", phi_coeffs, generators)


def _gram_inv_cached(agent, key_name, generators, eps=1e-8):
    """
    Cache and return Gram^{-1} for the given generator set under Frobenius inner product.
    key_name: str attribute name on agent (e.g., "_Gram_q_inv" / "_Gram_p_inv")
    """
    G_inv = getattr(agent, key_name, None)
    if G_inv is not None:
        return G_inv
    d = generators.shape[0]
    Gram = np.empty((d, d), dtype=generators.dtype)
    for a in range(d):
        for b in range(d):
            Gram[a, b] = np.tensordot(generators[a], generators[b])
    Gram += eps * np.eye(d, dtype=Gram.dtype)
    G_inv = np.linalg.inv(Gram)
    setattr(agent, key_name, G_inv)
    return G_inv


def _project_mat_to_algebra_coeffs(M, generators, G_inv):
    """
    Project matrix M (..., K, K) to algebra coefficients (..., d)
    by solving coeffs = G_inv @ h, where h_b = <G^b, M>_F.
    """
    d = generators.shape[0]
    # h_b = tr((G^b)^T M)
    h = np.stack([np.tensordot(generators[b], M) for b in range(d)], axis=-1)
    # coeffs = h @ G_inv^T (since last dim is basis index)
    # both ways are fine; using right-multiply for (..., d)
    coeffs = np.einsum("...b,bc->...c", h, G_inv)
    return coeffs


# --- helper: build C once and cache on agent ---
def _build_c_mapping_q2p(Phi_tilde_0, generators_q, generators_p, eps=1e-8):
    """
    Build linear map C (d_p x d_q) so that Ad_{Phi_tilde_0}(G_q^a) ≈ sum_b C_{ba} G_p^b,
    using Frobenius inner-product projection onto p-basis.
    """
    d_q, Kq, _ = generators_q.shape
    d_p, Kp, _ = generators_p.shape
    assert Phi_tilde_0.shape[-2:] == (Kp, Kq), "Phi_tilde_0 must be (K_p, K_q)"

    # Gram matrix of p-basis under Frobenius product
    Gp = np.zeros((d_p, d_p), dtype=generators_p.dtype)
    for b in range(d_p):
        for c in range(d_p):
            Gp[b, c] = np.tensordot(generators_p[b], generators_p[c])
    Gp += eps * np.eye(d_p, dtype=Gp.dtype)
    Gp_inv = np.linalg.inv(Gp)

    # Conjugate each q-generator: H_a = Phi0 G_q^a Phi0^{-1}
    Phi0    = Phi_tilde_0
    Phi0_inv = safe_inv(Phi0, eps=eps)

    C = np.zeros((d_p, d_q), dtype=generators_p.dtype)
    for a in range(d_q):
        H_a = np.einsum("ik,kl,lj->ij", Phi0, generators_q[a], Phi0_inv)
        h = np.array([np.tensordot(generators_p[b], H_a) for b in range(d_p)], dtype=H_a.dtype)
        C[:, a] = Gp_inv @ h
    return C


# =========================
# Regularization (base) — unchanged behavior
# =========================

def apply_regularization_terms(
    phi, generators,
    curv_weight, mass_weight,
    morphism=None, fiber="phi",   # kept for API compatibility (morphism unused)
    agent_i=None, agents=None,
    fisher_weight=0.0, params=None,
    eps=1e-8
):
    """
    Compute total φ or φ̃ regularization gradient in natural (Lie algebra) coordinates.
    Includes curvature, mass, and Fisher geometry terms.

    NOTE: Drop-in replacement; signature and behavior preserved.
    """
    if params is None:
        params = {}
    if (curv_weight == 0) and (mass_weight == 0) and (fisher_weight == 0):
        return np.zeros_like(phi)

    grad_euclidean = np.zeros_like(phi)

    if curv_weight:
        grad_curv = compute_curvature_gradient_analytical(phi, generators)
        grad_euclidean += curv_weight * grad_curv

    if mass_weight:
        grad_euclidean += (2.0 * mass_weight) * phi

    # Fisher assumed weighted inside compute_fisher_geometry_gradient (preserve behavior)
    if fisher_weight and (agent_i is not None) and (agents is not None):
        grad_fisher = compute_fisher_geometry_gradient(agent_i, agents, params, field=fiber)
        grad_euclidean += grad_fisher

    if np.allclose(grad_euclidean, 0.0):
        return grad_euclidean

    return dexpinv_operator(phi, grad_euclidean, generators)


# =========================
# Regularization (with toggleable φ–φ̃ coupling)
# =========================

def apply_regularization_terms_lie_natural(
    agent,
    phi_field,
    generators,
    field,  # "phi" or "phi_model"
):
    eps = config.eps

    # Select weights from config
    if field == "phi":
        curv_weight   = config.curvature_weight
        fisher_weight = config.fisher_geometry_weight
        mass_weight   = config.belief_mass
        lam_cpl       = getattr(config, "phi_coupling_weight", 0.0)
    elif field == "phi_model":
        curv_weight   = config.model_curvature_weight
        fisher_weight = config.fisher_model_geometry_weight
        mass_weight   = config.model_mass
        lam_cpl       = getattr(config, "phi_coupling_weight", 0.0)
    else:
        raise ValueError(f"Invalid field: {field}")

    # Base regularization
    grad_nat = apply_regularization_terms(
        phi=phi_field,
        generators=generators,
        curv_weight=curv_weight,
        mass_weight=mass_weight,
        fiber="belief" if field == "phi" else "model",
        agent_i=agent,
        agents=None,  # pass in list if you want Fisher geometry term to run
        fisher_weight=fisher_weight,
        eps=eps,
    )

    # φ–φ̃ coupling
    if lam_cpl > 0.0:
        generators_q = getattr(agent, "generators_q", None)
        generators_p = getattr(agent, "generators_p", None)
        Phi_tilde_0  = getattr(agent, "Phi_tilde_0", None)

        if (generators_q is not None) and (generators_p is not None) and (Phi_tilde_0 is not None):
            if not hasattr(agent, "_C_q2p"):
                agent._C_q2p = _build_c_mapping_q2p(Phi_tilde_0, generators_q, generators_p, eps=eps)
            C = agent._C_q2p

            phi_q = agent.phi
            phi_p = agent.phi_model
            r = phi_p - np.einsum("ba,...a->...b", C, phi_q)

            if field == "phi":
                grad_eucl = -lam_cpl * np.einsum("ab,...b->...a", C.T, r)
                grad_nat += dexpinv_operator(phi_q, grad_eucl, generators_q)
            elif field == "phi_model":
                grad_eucl = lam_cpl * r
                grad_nat += dexpinv_operator(phi_p, grad_eucl, generators_p)

    return grad_nat





