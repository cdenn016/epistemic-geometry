import numpy as np
import sys

# ===========================
# DEBUGGING AND UTILITIES
# ===========================

# 1) define at top of your script/module
def scaled_eta(base, *weights, min_den=1.0):
    """
    If all weights sum to zero, return base.
    Otherwise return base / max(sum(weights), min_den).
    """
    total = sum(weights)
    if total <= 0:
        return base
    return base / max(total, min_den)

def set_config_from_params(params):
    """Dynamically override config attributes from a dictionary."""
    this_module = sys.modules[__name__]
    for k, v in params.items():
        setattr(this_module, k, v)

use_parallel_alignment_gradient = False
n_alignment_jobs = 2

# ===========================
# GROUP & REPRESENTATION SETTINGS
# ===========================
num_cores = -1  # or however many threads you want to use

group_name = 'sl2r'               # Options: "u1", "so3", "sl2r", 'su2'.
representation_type = 'irrep'     # Options: 'irrep', 'fundamental', 'adjoint'
use_commutator = False            # use "false" to use the general exp.exp multiplication
debug = True  # Global debug flag for extra logging inside φ updates
debug_sanitize_sigma = True  # Or False by default
                    

# ===========================
# DOMAIN / SPATIAL SETTINGS
# ===========================
K = 13          # Fiber dimension of belief/model space (depends on representation)
                 # Fast up to K=15 then slow
D = 2            #dimension of base manifold - d=2 validated

L = 50         #length of hypercubic base-manifold - PBCs

steps = 250


N = 7                          # Number of agents
max_neighbors = 7             # Max number of agent neighbors

psi_radius_range = (5,5)         #agent radii
             
agent_seed    = 13
identical_models = False         # If True, all agents share the same p, mu_p_field, sigma_p_field
similar_p_models = False
diagonal_covariance = False  # Toggle: if True, Σ is diagonal; if False, use full MVN

log_full_fields = True  # default off

# ===========================
# COUPLINGS & PENALTIES
# ===========================

e_belief               = 1
e_model                = 1

alpha                  = 4.2                # KL(q || p) self-energy
beta                   = 1.5                # KL(q || Ω q) belief coupling
gamma                  = 102               # Laplacian penalty on φ
gauge_weight           = 124                  # φ² mass term

model_feedback_weight  = 0.5                  # KL feedback p || q analogous to alpha
model_align_weight     = 4                 # KL(p || Ω̃ p) analogous to beta
model_gauge_weight     = 28                  # Laplacian penalty on φ_model
model_mass_weight      = 9               # φ_model² mass term

phi_phi_tilde_coupling = 95                  # Coupling φ ↔ φ̃

model_curvature_weight = 58 
curvature_weight       = 65

phi_damping            = 0.5

variance_penalty_model_weight = 0
variance_penalty_weight = 0

#phi_natgrad_scale = 1.0  # try 1.0, 5.0, 10.0 depending on how weak φ is
eta_phi_adaptive_scaling = 1
# ===========================
# AGENT GEOMETRY
# ===========================
q_mu_range    = (0, K - 1)     # Mean of q
q_sigma_range = (1, 2)         # Eigenvalues of Σ_q

p_mu_range    = (0, K - 1)     # Mean of p
p_sigma_range = (0.5, 1.5)         # Eigenvalues of Σ_p

mu_field_smooth_range    = (2, 3)   # lower = noisier
sigma_field_smooth_range = (2, 3)

# Sigma field eigenvalue range
sigma_min_eig = 0.1     # minimum eigenvalue of Σ (lower bound on uncertainty)
sigma_max_eig = 2.0     # maximum eigenvalue of Σ (upper bound on uncertainty)

# Controls how sharply uncertainty grows away from support
sigma_decay_sharpness = 1.0  # passed as sigma to gaussian_filter
sigma_outside_mask_value = 1000.0  # or any large value you prefer

mask_sharpness           = 1.5

     #Controls how much randomness is added after masking, 
                                      #to avoid wiping out variation. Large for texture
mu_anisotropy_range  = (1.5, 2.5)       # 1 = round, 3 = stretched
mu_orientation_range = (0.1, np.pi)     # full angle range



# Optional: make smoothing stronger if needed
# config.py
# config.py
ensure_spd = True
spd_eps = 1e-6
debug_sanitize_sigma = True
phi_clip_threshold = 1e2  # Optional: to bound exp(φ)
phi_model_clip_threshold = 1e2

debug_gradients = True

# ===========================
# INITIALIZATION
# ===========================
phi_init_smooth_sigma = 1.5
phi_init              = 0.2
phi_model_offset      = 0.1

# 2) keep your base‐rate definitions
eta_base_q         = 1e-3    
eta_base_p         = 1e-3    
eta_base_phi       = 1e-2
eta_base_phi_model = 1e-1    

eta_phi_min        =1e-3
phi_step_scale = 1
# ===========================
# STABILITY AND CLIPPING
# ===========================

phi_grad_clip_threshold = 1e4
phi_model_grad_clip_threshold = 1e4
gradient_clip = 1e4  # You can tune this per experiment


# ===========================
# DISTRIBUTION SETTINGS
# ===========================
spatial_resolution  = 1
distribution_family = 'gaussian'   # Options: "gaussian", "exponential", "beta". "uniform", etc.

# ===========================
# EPSILONS & PRECISION
# ===========================

log_eps            = 1e-6
support_cutoff_eps = 1e-3           #agent and mask overlap = at 1e-1
overlap_eps        = 1e-5
eps                = 1e-3
epsilon_model      = 1.0
precision = np.float32

#=================================
# TRANSPORT DISTRIBUTION INJECTION
#=================================
injection_mode = "from_q"  # or "gaussian", "from_q", "from_p, "delta", etc

# ===========================
# CHECKPOINTING
# ===========================

checkpoint_dir      = "checkpoints"
save_checkpoints    = True
checkpoint_interval = 1

domain_size = (L,) * D

# 3) replace all the old eta_* calculations with calls to scaled_eta
eta_q = scaled_eta(eta_base_q, alpha, beta)

eta_p = scaled_eta(eta_base_p,
                   alpha,
                   model_align_weight,
                   model_feedback_weight,
                   model_gauge_weight,
                   model_mass_weight)

eta_phi = scaled_eta(eta_base_phi,
                     gauge_weight,
                     gamma,
                     curvature_weight,
                     phi_phi_tilde_coupling)

eta_model_phi = scaled_eta(eta_base_phi_model,
                           model_align_weight,
                           model_gauge_weight,
                           model_mass_weight,
                           phi_phi_tilde_coupling
                           )



ZIPF_RMIN       = 1       # minimum rank (skip top-2 symbols)
ZIPF_RMAX_FRAC  = 1     # take top 50% of symbols for fit
from get_generators import get_generators
generators = get_generators(group_name, K)
lie_dim = generators.shape[0]
