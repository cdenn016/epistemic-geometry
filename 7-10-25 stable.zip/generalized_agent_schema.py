# === PATCHED: generalized_agent_schema.py ===
from dataclasses import dataclass, field
from typing import Tuple, List, Optional, Dict, Any
import numpy as np

from generalized_agent_distributions import (
    initialize_multivariate_gaussian_distribution,
    get_fiber_basis,
)

import config


@dataclass
class Agent:
    id: int
    mask: np.ndarray  # (H, W)
    mu_q_field: np.ndarray  # (H, W, K)
    sigma_q_field: np.ndarray  # (H, W, K, K)
    mu_p_field: np.ndarray  # (H, W, K)
    sigma_p_field: np.ndarray  # (H, W, K, K)
    phi: np.ndarray  # (H, W, d)
    phi_model: np.ndarray  # (H, W, d)
    center: Tuple[int, ...]
    radius: float
    neighbors: List[dict]
    delta_phi_model: Optional[np.ndarray] = None

    # Fisher geometry (populated by diagnostics)
    fisher_I: Optional[np.ndarray] = None
    pull_M_vis: Optional[np.ndarray] = None
    pull_Delta: Optional[np.ndarray] = None
    pull_M_dark: Optional[np.ndarray] = None
    spatial_G: Optional[np.ndarray] = None

    # Meta-agent metadata
    agent_scale: float = 1.0
    hierarchy_level: int = 0

    # Metrics log and cache
    entropy: Optional[float] = None
    energy: Optional[float] = None
    coherence: Optional[float] = None
    last_update_step: Optional[int] = None
    metrics_log: List[Dict[str, Any]] = field(default_factory=list)

    # Transport memoization cache: (j_id, field_type) → (μ_rot, Σ_rot)
    transport_cache: Dict[Tuple[int, str], Tuple[np.ndarray, np.ndarray]] = field(default_factory=dict)

    # Internal caches
    _exp_phi: Optional[np.ndarray] = field(default=None, init=False)
    _exp_neg_phi: Optional[np.ndarray] = field(default=None, init=False)
    _exp_phi_model: Optional[np.ndarray] = field(default=None, init=False)
    _exp_neg_phi_model: Optional[np.ndarray] = field(default=None, init=False)

    def __post_init__(self):
        # Set grid shape
        self.grid_shape = self.mu_q_field.shape[:-1]
        self.cached_belief_alignment = {}  # for caching Ω belief transport in phi gradient

        # Optional: construct diagnostic MVG density p(c) over fiber (not required if working with μ, Σ only)
        fiber_basis = get_fiber_basis(K=self.mu_p_field.shape[-1])
        self.p_field = initialize_multivariate_gaussian_distribution(
            x_coords=fiber_basis,
            mu_field=self.mu_p_field,
            sigma_field=self.sigma_p_field,
            mask=self.mask,
            log_eps=config.eps,
        )

    def log_metrics(self, step: int, stats: Dict[str, Any]) -> None:
        entry = {'step': step}
        entry.update(stats)
        self.metrics_log.append(entry)

    def clear_omega_cache(self) -> None:
        self._exp_phi = None
        self._exp_neg_phi = None
        self._exp_phi_model = None
        self._exp_neg_phi_model = None
        self.transport_cache.clear()

    def clear_diagnostics(self) -> None:
        """
        Clears cached geometric diagnostic fields that may be stale
        after belief or model updates.
        """
        self.fisher_I    = None
        self.pull_M_vis  = None
        self.pull_Delta  = None
        self.pull_M_dark = None
        self.spatial_G   = None

    @property
    def Omega(self) -> np.ndarray:
        K = self.mu_q_field.shape[-1]
        return self._exp_phi.reshape(*self.grid_shape, K, K)

    @property
    def Omega_inv(self) -> np.ndarray:
        K = self.mu_q_field.shape[-1]
        return self._exp_neg_phi.reshape(*self.grid_shape, K, K)

    @property
    def Omega_model(self) -> np.ndarray:
        K = self.mu_p_field.shape[-1]
        return self._exp_phi_model.reshape(*self.grid_shape, K, K)

    @property
    def Omega_model_inv(self) -> np.ndarray:
        K = self.mu_p_field.shape[-1]
        return self._exp_neg_phi_model.reshape(*self.grid_shape, K, K)

    @property
    def grid_shape(self) -> tuple:
        """Returns the spatial shape (e.g. (H, W)) of the agent's base domain."""
        return self._grid_shape

    @grid_shape.setter
    def grid_shape(self, val: tuple):
        """Sets the agent's grid shape and validates it."""
        assert isinstance(val, tuple), "grid_shape must be a tuple"
        assert all(isinstance(d, int) and d > 0 for d in val), "each dimension must be a positive int"
        self._grid_shape = val