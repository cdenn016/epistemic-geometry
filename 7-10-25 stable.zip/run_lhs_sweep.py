# -*- coding: utf-8 -*-
"""
Run Latin Hypercube parameter sweep and output both individual results and a consolidated CSV of sampled parameters.
"""
import os
import numpy as np
import pickle
import pandas as pd
from scipy.stats import qmc
from generalized_simulation import run_simulation
import argparse


DEFAULT_SAMPLES = 100  # Default number of LHS samples

# --- Base simulation parameters ---
base_params = {
    "group_name": "sl2r",
    "K": 7,
    "N": 3,
    "L": 16,
    "steps": 150,
    # Enable debug prints in update routines
    "debug": True,
}


def lhs_sample(param_ranges, n_samples):
    """Generate Latin Hypercube Samples for given parameter ranges."""
    sampler = qmc.LatinHypercube(d=len(param_ranges))
    sample = sampler.random(n=n_samples)
    l_bounds = np.array([lo for lo, hi in param_ranges])
    u_bounds = np.array([hi for lo, hi in param_ranges])
    return qmc.scale(sample, l_bounds, u_bounds)


def run_lhs_sweep(n_samples=DEFAULT_SAMPLES, output_dir="lhs_results", csv_path="lhs_samples.csv"):
    os.makedirs(output_dir, exist_ok=True)

    # Define sweep parameter ranges
    sweep_params = {
        "alpha":                 (0,    5),
        "beta":                  (0,    5),
        "gamma":                 (0,    200),
        "gauge_weight":          (0,    200),
        "model_align_weight":    (0,    5),
        "model_gauge_weight":    (0,    200),
        "model_mass_weight":     (0,    200),
        "model_feedback_weight": (0,    5),
        "phi_phi_tilde_coupling":(0,    200),
        "phi_init":              (0,    1.0),
        "model_curvature_weight":(0,    200),
        "curvature_weight":       (0,    200),
        #"e_belief":              (-10,    10),
        #"e_model":               (-10,    10),
    }

    param_names = list(sweep_params)
    ranges = [sweep_params[k] for k in param_names]
    samples = lhs_sample(ranges, n_samples)

    # Save sweep specification
    sweep_spec = {
        "param_names": param_names,
        "ranges": sweep_params,
        "samples": samples.tolist(),
    }
    with open(os.path.join(output_dir, "sweep_spec.pkl"), "wb") as f:
        pickle.dump(sweep_spec, f)

    # Prepare list for CSV
    all_params = []
    

    # Run each LHS sample
    for i, row in enumerate(samples):
        sampled_params = dict(zip(param_names, row))
        

        # Collect for CSV (base + sampled)
        entry = dict(base_params)
        entry.update(sampled_params)
        all_params.append(entry)

        # Run simulation for this sample
        print(f"[SAMPLE {i}] params = {sampled_params}")
        subdir = os.path.join(output_dir, f"run_{i}")
        os.makedirs(subdir, exist_ok=True)

        agents, metrics = run_simulation(
            outdir=subdir,
            resume=False,
            log_metrics=True,
            log_fields = True,
            num_cores=-1,
            params=entry,
        )

        # Archive results
        with open(os.path.join(subdir, "final_agents.pkl"), "wb") as f:
            pickle.dump(agents, f)
        with open(os.path.join(subdir, "final_metrics.pkl"), "wb") as f:
            pickle.dump(metrics, f)
        with open(os.path.join(subdir, "params.pkl"), "wb") as f:
            pickle.dump(entry, f)

    # Write consolidated CSV of all parameter sets
    df = pd.DataFrame(all_params)
    df.to_csv(csv_path, index=False)
    print(f"[DONE] Consolidated CSV written → {csv_path}")
    print(f"[DONE] LHS sweep complete: {n_samples} samples → {output_dir}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description=f"Run Latin Hypercube parameter sweep and build CSV (default {DEFAULT_SAMPLES} samples)."
    )
    parser.add_argument(
        "-n", "--n_samples", type=int,
        default=DEFAULT_SAMPLES,
        help="Number of LHS samples"
    )
    parser.add_argument(
        "-o", "--output_dir", type=str,
        default="lhs_results",
        help="Directory to write individual run results"
    )
    parser.add_argument(
        "-c", "--csv_path", type=str,
        default="lhs_samples.csv",
        help="Path for consolidated CSV of sampled parameters"
    )
    args = parser.parse_args()
    run_lhs_sweep(
        n_samples=args.n_samples,
        output_dir=args.output_dir,
        csv_path=args.csv_path,
    )
