import numpy as np
import config
from joblib import Parallel, delayed

import config
from natural_gradient_utils import (
    apply_natural_gradient_batch,
    apply_lie_natural_gradient,
    sanitize_sigma,
)
from generalized_update_terms import (
    compute_beliefs_gradient,
    compute_models_gradient,
    compute_phi_alignment_gradient,
    compute_phi_model_update,
)
from generalized_omega import exp_lie_algebra_irrep
from joblib import Parallel, delayed

from generalized_update_terms import (
    compute_beliefs_gradient,
    compute_models_gradient,
    compute_phi_alignment_gradient,
    compute_phi_model_update,
)

from generalized_omega import batch_apply_omega

def _compute_all_grads(i, agents, params):
    ai = agents[i]
    return (
        compute_beliefs_gradient(ai, agents, params),
        compute_models_gradient(ai, agents, params),
        compute_phi_alignment_gradient(ai, agents, params),
        compute_phi_model_update(ai, agents, params),
    )

# === OPTIMIZED synchronous_step ===
import numpy as np
import config
from joblib import Parallel, delayed
from natural_gradient_utils import (
    apply_natural_gradient_batch,
    apply_lie_natural_gradient,
    sanitize_sigma,
)
from generalized_update_terms import (
    compute_beliefs_gradient,
    compute_models_gradient,
    compute_phi_alignment_gradient,
    compute_phi_model_update,
)
from generalized_omega import exp_lie_algebra_irrep

def synchronous_step(agents, generators, params=None, n_jobs=1):
    params = params or {}
    N = len(agents)

    # 0) Precompute Lie exponentials (Ω, Ω⁻¹)
    for A in agents:
        A.clear_omega_cache()
        e_belief = params.get("e_belief", config.e_belief)
        e_model  = params.get("e_model",  config.e_model)
        A.grid_shape = A.phi.shape[:-1]

        flat_phi       = A.phi.reshape(-1, A.phi.shape[-1]) / e_belief
        flat_phi_model = A.phi_model.reshape(-1, A.phi_model.shape[-1]) / e_model

        A._exp_phi       = exp_lie_algebra_irrep(flat_phi, generators)
        A._exp_phi_model = exp_lie_algebra_irrep(flat_phi_model, generators)
        A._exp_neg_phi       = np.linalg.inv(A._exp_phi)
        A._exp_neg_phi_model = np.linalg.inv(A._exp_phi_model)

    # 0.5) Ensure σ_q and σ_p are SPD
    for A in agents:
        A.sigma_q_field = sanitize_sigma(A.sigma_q_field, eps=config.eps, debug=config.debug_sanitize_sigma)
        A.sigma_p_field = sanitize_sigma(A.sigma_p_field, eps=config.eps, debug=config.debug_sanitize_sigma)

    mask_list = [A.mask for A in agents]

    # 2) Compute gradients
    grads = Parallel(n_jobs=n_jobs, backend="loky", batch_size=8)(
        delayed(lambda i: (
            compute_beliefs_gradient(agents[i], agents, params),
            compute_models_gradient(agents[i], agents, params),
            compute_phi_alignment_gradient(agents[i], agents, params),
            compute_phi_model_update(agents[i], agents, params),
        ))(i) for i in range(N)
    )
    q_grads, p_grads, phi_grads, phi_m_grads = zip(*grads)

    # 3) Step sizes
    eta_q         = params.get("eta_q",         config.eta_q)
    eta_p         = params.get("eta_p",         config.eta_p)
    eta_phi_base  = params.get("eta_phi",       config.eta_phi)
    eta_phi_model = params.get("eta_model_phi", config.eta_model_phi)
    G_inv_phi     = params.get("G_inv_phi",     None)
    G_inv_model   = params.get("G_inv_phi_model", None)

    # 4) Apply updates
    for i, agent in enumerate(agents):
        mask = mask_list[i]
        mask_mu    = mask[..., None]
        mask_sigma = mask[..., None, None]
        mask_exp   = mask[..., None]

        grad_mu_q,    grad_sigma_q    = q_grads[i]
        grad_mu_p,    grad_sigma_p    = p_grads[i]
        grad_phi,     = (phi_grads[i],)
        grad_phi_m    = phi_m_grads[i]

        # q update
        delta_mu_q, delta_sigma_q = apply_natural_gradient_batch(
            agent.mu_q_field, agent.sigma_q_field, grad_mu_q, grad_sigma_q)
        agent.mu_q_field    -= eta_q * delta_mu_q    * mask_mu
        agent.sigma_q_field -= eta_q * delta_sigma_q * mask_sigma

        # p update
        delta_mu_p, delta_sigma_p = apply_natural_gradient_batch(
            agent.mu_p_field, agent.sigma_p_field, grad_mu_p, grad_sigma_p)
        agent.mu_p_field    -= eta_p * delta_mu_p    * mask_mu
        agent.sigma_p_field -= eta_p * delta_sigma_p * mask_sigma

        # φ update — adaptive eta_phi
        grad_norm_phi = np.linalg.norm(grad_phi[mask > config.support_cutoff_eps]) + 1e-8
        eta_phi_tuned = np.clip(
            config.eta_base_phi / (1.0 + config.eta_phi_adaptive_scaling * grad_norm_phi),
            config.eta_phi_min,
            config.eta_base_phi,
        )
        delta_phi = eta_phi_tuned * apply_lie_natural_gradient(agent.phi, grad_phi, G_inv=G_inv_phi)
        agent.phi -= delta_phi * config.phi_step_scale * mask_exp

        # Optional clip φ norm
        phi_clip_thresh = getattr(config, "phi_clip_threshold", 0.0)
        if phi_clip_thresh > 0:
            phi_norm = np.linalg.norm(agent.phi, axis=-1, keepdims=True)
            clip_mask = (phi_norm > phi_clip_thresh)[..., 0]
            scale = phi_clip_thresh / (phi_norm[..., 0][clip_mask] + 1e-8)
            agent.phi[clip_mask] *= scale[:, None]

        # φ_model update — adaptive eta_phi_model
        grad_norm_phi_m = np.linalg.norm(grad_phi_m[mask > config.support_cutoff_eps]) + 1e-8
        eta_phi_model_tuned = np.clip(
            eta_phi_model / (1.0 + 0.1 * grad_norm_phi_m),
            1e-6, eta_phi_model,
        )
        delta_phi_m = eta_phi_model_tuned * apply_lie_natural_gradient(agent.phi_model, grad_phi_m, G_inv=G_inv_model)
        agent.phi_model -= delta_phi_m * mask_exp

        # Optional clip φ_model norm
        phi_model_clip_thresh = getattr(config, "phi_model_clip_threshold", 0.0)
        if phi_model_clip_thresh > 0:
            phi_m_norm = np.linalg.norm(agent.phi_model, axis=-1, keepdims=True)
            clip_mask_m = (phi_m_norm > phi_model_clip_thresh)[..., 0]
            scale_m = phi_model_clip_thresh / (phi_m_norm[..., 0][clip_mask_m] + 1e-8)
            agent.phi_model[clip_mask_m] *= scale_m[:, None]

    return agents
