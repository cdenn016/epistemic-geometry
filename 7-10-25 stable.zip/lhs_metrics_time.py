# -*- coding: utf-8 -*-
"""
Created on Thu Jul 10 13:24:30 2025

@author: chris and christine
"""

import os
import pickle
import pandas as pd
import numpy as np
from pathlib import Path

def load_pickle(path):
    with open(path, "rb") as f:
        return pickle.load(f)

def extract_run_metrics(run_dir):
    result = {"run": os.path.basename(run_dir)}
    param_path = Path(run_dir) / "params.pkl"
    if param_path.exists():
        result.update(load_pickle(param_path))

    metric_path = Path(run_dir) / "metric_log.pkl"
    if metric_path.exists():
        try:
            metrics = load_pickle(metric_path)
            if isinstance(metrics, list) and len(metrics) > 0:
                final = metrics[-1]
                for k, v in final.items():
                    if k != "step":
                        result[f"final_{k}"] = v
        except Exception as e:
            print(f"[ERROR] Failed to load metric_log from {run_dir}: {e}")

    field_dir = Path(run_dir) / "field_dumps"
    max_overlap_files = sorted(field_dir.glob("max_overlap_step*.pkl")) if field_dir.exists() else []
    if max_overlap_files:
        try:
            latest = load_pickle(max_overlap_files[-1])
            for k, v in latest.items():
                if isinstance(v, float):
                    result[f"overlap_{k}"] = v
                elif isinstance(v, (list, tuple, np.ndarray)):
                    result[f"overlap_{k}_shape"] = str(np.shape(v))
        except Exception as e:
            print(f"[ERROR] Failed to load max_overlap from {run_dir}: {e}")

    return result

def extract_timeseries(run_dir):
    run_name = os.path.basename(run_dir)
    metric_path = Path(run_dir) / "metric_log.pkl"
    if not metric_path.exists():
        return None

    try:
        metrics = load_pickle(metric_path)
        df = pd.DataFrame(metrics)
        df["run"] = run_name
        return df
    except Exception as e:
        print(f"[ERROR] Failed to parse time-series for {run_name}: {e}")
        return None

def print_and_collect_all_runs(base_dir="lhs_results",
                                summary_csv="summary_metrics.csv",
                                timeseries_csv="metrics_over_time.csv"):
    run_dirs = sorted([os.path.join(base_dir, d) for d in os.listdir(base_dir) if d.startswith("run_")])
    all_summary = []
    all_timeseries = []

    for run_dir in run_dirs:
        print(f"\n{'='*50}")
        print(f"[RUN] {run_dir}")
        print(f"{'='*50}")
        summary = extract_run_metrics(run_dir)

        keys_to_print = [k for k in summary if k.startswith("final_") or k.startswith("overlap_") or k in {"run", "alpha", "beta", "gamma"}]
        for k in keys_to_print:
            val = summary[k]
            if isinstance(val, float):
                print(f"  {k:<30} = {val:.5f}")
            else:
                print(f"  {k:<30} = {val}")
        
        all_summary.append(summary)

        ts_df = extract_timeseries(run_dir)
        if ts_df is not None:
            all_timeseries.append(ts_df)

    # Save final summary CSV
    df_summary = pd.DataFrame(all_summary)
    df_summary.to_csv(Path(base_dir) / summary_csv, index=False)
    print(f"\n✅ Saved summary CSV → {Path(base_dir) / summary_csv}")

    # Save time-series CSV
    if all_timeseries:
        df_ts = pd.concat(all_timeseries, axis=0)
        df_ts.to_csv(Path(base_dir) / timeseries_csv, index=False)
        print(f"✅ Saved time-series CSV → {Path(base_dir) / timeseries_csv}")
    else:
        print("⚠️ No time-series data found.")

if __name__ == "__main__":
    print_and_collect_all_runs("lhs_results")
