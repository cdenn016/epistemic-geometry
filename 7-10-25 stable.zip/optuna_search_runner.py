# -*- coding: utf-8 -*-
"""
Created on Mon Jun 23 17:22:53 2025

@author: chris and christine
"""

import os
import optuna
from generalized_simulation import run_simulation as gs_run
from pathlib import Path
import numpy as np

# Number of Optuna trials
N_TRIALS = 50
# How many trials to run in parallel
N_JOBS   = 12  

# Your selected parameter search space
sweep_params = {
     "alpha":                 (0,    200),
     "beta":                  (0,    200),
     "gamma":                 (0,    200),
     "gauge_weight":          (0,    200), 
     "model_align_weight":    (0,    200),
     "model_gauge_weight":    (0,    200),
     "model_mass_weight":     (0,    200),
     "model_feedback_weight": (0,    200),
     "phi_phi_tilde_coupling":(0,    200),
     "model_curvature_weight":(0,    200),
     "curvature_weight":      (0,    200),
}

TARGET_SLOPE = -1.0

def run_simulation(params: dict, trial_number: int) -> float:
    outdir = Path(f"optuna_tmp/trial_{trial_number}")
    outdir.mkdir(parents=True, exist_ok=True)

    agents, metric_log, slope = gs_run(
        outdir=outdir,
        resume=False,
        log_metrics=False,   
        num_cores=12,
        params=params,
    )
    return slope          

def objective_align(trial):
    try:
        from generalized_diagnostics_metrics import compute_alignment_energy
        from get_generators import get_generators
        import config

        # Suggest parameters
        params = {
            name: trial.suggest_float(name, max(lo, 1e-6), hi, log=True)
            for name, (lo, hi) in sweep_params.items()
        }

        # Run simulation with no logging
        agents, _, _ = gs_run(
            outdir=Path(f"optuna_tmp/trial_{trial.number}"),
            resume=False,
            log_metrics=False,  # ⬅ No metric logging
            num_cores=12,
            params=params,
        )

        # Compute alignment energy directly (D_KL(q_i || Ω_ij q_j))
        generators = get_generators(config.group, config.K)
        e_align = compute_alignment_energy(
            agents, params=params,
            generators=generators,
            q_field="q",
            phi_field="phi",
            mask_field="mask",
            support_eps=config.eps,
            n_jobs=1  # fast enough for single eval
        )

        if not isinstance(e_align, float) or not np.isfinite(e_align):
            raise ValueError("Invalid alignment energy.")

        print(f"[OPTUNA] Trial {trial.number}: e_align = {e_align:.6f}")
        return e_align

    except Exception as e:
        print(f"[ERROR] Trial {trial.number} failed: {e}")
        return float("inf")

def objective_zipf(trial):
    try:
        # Suggest parameters
        params = {
            name: trial.suggest_float(name, max(lo, 1e-6), hi, log=True)
            for name, (lo, hi) in sweep_params.items()
        }

        # Run simulation
        agents, _, _ = gs_run(
            outdir=Path(f"optuna_tmp/trial_{trial.number}"),
            resume=False,
            log_metrics=False,
            num_cores=12,
            params=params,
        )

        # Compute global Zipf slope + R²
        from powerlaw_utils import zipf_frequencies_from_q, zipf_slope
        q_final = np.stack([ag.q for ag in agents])
        mask_final = np.stack([ag.mask for ag in agents])
        freqs = zipf_frequencies_from_q(q_final, mask_final)
        slope, r2 = zipf_slope(freqs, rmin=3, rmax=int(len(freqs) * 0.5))

        # Balanced loss: penalize slope ≠ −1 and poor R²
        slope_loss = (slope + 1.0)**2
        r2_loss = (1 - r2)**2
        loss = slope_loss + r2_loss

        if not np.isfinite(loss):
            raise ValueError("Non-finite Zipf loss.")

        print(f"[OPTUNA] Trial {trial.number}: slope = {slope:.4f}, R² = {r2:.4f}, loss = {loss:.6f}")
        return loss

    except Exception as e:
        print(f"[ERROR] Trial {trial.number} failed: {e}")
        return float("inf")


def main():
    study = optuna.create_study(direction='minimize')
    study.optimize(objective_align, n_trials=N_TRIALS, n_jobs=N_JOBS)

    print("\n[RESULT] Best parameters:")
    for k, v in study.best_params.items():
        print(f"  {k}: {v:.4f}")
    print(f"\n[RESULT] Best energy: {study.best_value:.6f}")

if __name__ == "__main__":
    main()
