# -*- coding: utf-8 -*-
"""
Created on Thu Jul 10 13:36:32 2025
@author: chris and christine
"""

import pandas as pd
import matplotlib.pyplot as plt
from pathlib import Path

def load_and_filter_runs(time_csv, summary_csv, energy_thresh=40.0, require_decreasing=True):
    """
    Load metrics + summary, filter by energy threshold and E_final < E_initial.
    Returns:
        df_time_filtered, df_summary, good_run_list
    """
    df_time = pd.read_csv(time_csv)
    df_summary = pd.read_csv(summary_csv)

    if "total_energy" in df_time.columns:
        df_time = df_time.rename(columns={"total_energy": "energy_total"})

    good_runs = []
    for run, group in df_time.groupby("run"):
        if group["energy_total"].max() > energy_thresh:
            continue
        if not group["energy_total"].notna().all():
            continue
        if require_decreasing and group["energy_total"].iloc[-1] >= group["energy_total"].iloc[0]:
            continue
        good_runs.append(run)

    df_time_filtered = df_time[df_time["run"].isin(good_runs)].copy()
    return df_time_filtered, df_summary, good_runs

def format_param_value(val):
    """Format numeric or string value for folder-safe display."""
    try:
        return f"{float(val):.3g}"
    except:
        return str(val).replace(" ", "_").replace("/", "-").replace(":", "_")

def save_individual_metric_plots(df_time, df_summary, outdir="lhs_results/individual_metrics", energy_thresh=40.0):
    Path(outdir).mkdir(parents=True, exist_ok=True)

    known_cols = set(df_time.columns) | {"run"}
    param_cols = [col for col in df_summary.columns if col not in known_cols]

    # Choose short list of key params for folder name
    folder_keys = [
        "alpha", "beta", "gamma", "curvature_weight",
         "phi_phi_tilde_coupling"
    ]

    for run, group in df_time.groupby("run"):
        if group["energy_total"].max() > energy_thresh:
            continue
        if group["energy_total"].iloc[-1] >= group["energy_total"].iloc[0]:
            continue

        row = df_summary[df_summary["run"] == run]
        if row.empty:
            continue
        row = row.iloc[0]

        # Build short folder name using selected parameters only
        param_str = "__".join([
            f"{k}={format_param_value(row[k])}"
            for k in folder_keys if k in row
        ])
        run_dir = Path(outdir) / f"{run}__{param_str}"
        run_dir.mkdir(parents=True, exist_ok=True)

        # Save full parameter metadata to file
        with open(run_dir / "params.txt", "w") as f:
            for k in param_cols:
                f.write(f"{k}: {row[k]}\n")

        for metric in group.columns:
            if metric in {"step", "run"}:
                continue
            plt.figure(figsize=(6, 4))
            plt.plot(group["step"], group[metric], lw=2)
            plt.xlabel("Step")
            plt.ylabel(metric)
            plt.title(f"{run} — {metric}")
            plt.grid(True)
            plt.tight_layout()
            plt.savefig(run_dir / f"{metric}.png")
            plt.close()

        print(f"[✓] Saved metrics for {run} → {run_dir}")


def main():
    METRICS_CSV = "lhs_results/metrics_over_time.csv"
    SUMMARY_CSV = "lhs_results/summary_metrics.csv"
    OUTPUT_DIR  = "lhs_results/individual_metrics"
    ENERGY_THRESH = 40.0
    REQUIRE_DECREASING = True

    df_time, df_summary, good_runs = load_and_filter_runs(
        METRICS_CSV, SUMMARY_CSV,
        energy_thresh=ENERGY_THRESH,
        require_decreasing=REQUIRE_DECREASING
    )
    print(f"[INFO] {len(good_runs)} runs passed filter: {good_runs}")
    save_individual_metric_plots(df_time, df_summary, outdir=OUTPUT_DIR)

if __name__ == "__main__":
    main()
