
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation
from pathlib import Path
import pickle
import config
from get_generators import get_generators
from generalized_omega import compute_field_strength

# === CONFIG ===
OUTDIR         = Path("Animations")
CHECKPOINT_DIR = Path("checkpoints")
METRICS        = ["phi_norm", "curvature_norm"]
AGENT_IDS      = [1]
DOWNSAMPLE     = 1
FPS            = 10
INTERVAL       = 1000 // FPS
CMAP           = "viridis"

OUTDIR.mkdir(parents=True, exist_ok=True)


def load_checkpoints():
    files = sorted(CHECKPOINT_DIR.glob("step_*.pkl"))
    steps = [int(f.stem.split("_")[1]) for f in files]
    return [(pickle.load(open(f, "rb")), s) for f, s in zip(files, steps)]


def make_single_panel_gif(frames, field_idx, title_fmt, outname):
    def get_global_minmax(frames, idx):
        values = [f[idx][f[idx] != 0] for f in frames if np.any(f[idx] != 0)]
        flat = np.concatenate(values) if values else np.array([0])
        return flat.min(), flat.max()

    vmin, vmax = get_global_minmax(frames, field_idx)

    fig, ax = plt.subplots(figsize=(4, 4))
    im = ax.imshow(np.zeros_like(frames[0][field_idx]),
                   cmap=CMAP, vmin=vmin, vmax=vmax, animated=True)
    ax.axis("off")
    cb = fig.colorbar(im, ax=ax, fraction=0.046, pad=0.04)

    def update(idx):
        step = frames[idx][0]
        field = np.ma.masked_where(frames[idx][field_idx] == 0, frames[idx][field_idx])
        im.set_data(field)
        ax.set_title(title_fmt.format(step=step))
        return [im]

    ani = animation.FuncAnimation(
        fig, update,
        frames=len(frames),
        interval=INTERVAL,
        blit=False
    )

    path = OUTDIR / f"{outname}.gif"
    ani.save(path, writer=animation.PillowWriter(fps=FPS))
    plt.close(fig)
    print(f"[✓] Saved single-field animation: {outname} → {path}")
    
    
def compute_field(agent, metric_name, agents=None):
    """
    Compute a spatial map of metric_name over the grid for one agent.
    Everything outside the agent’s support (mask ≤ eps) is zeroed out.
    """
    eps = config.support_cutoff_eps
    mask_bool = agent.mask > eps

    if metric_name == "phi_norm":
        if agent.phi is None:
            print(f"[WARN] Agent {agent.id} missing φ field; skipping phi_norm")
            return np.zeros_like(agent.mask)
        raw = np.linalg.norm(agent.phi, axis=-1)
        return raw * mask_bool

    elif metric_name == "curvature_norm":
        if agent.phi is None:
            print(f"[WARN] Agent {agent.id} missing φ field; skipping curvature_norm")
            return np.zeros_like(agent.mask)

        gens = get_generators(config.group_name, config.K)
        F = compute_field_strength(agent.phi, gens)

        if "xy" not in F:
            print(f"[WARN] Missing F['xy'] in curvature computation for agent {agent.id}")
            return np.zeros_like(agent.mask)

        norm_xy = np.linalg.norm(F["xy"], axis=(-2, -1))  # Frobenius norm at each (H, W)
        return norm_xy * mask_bool

    else:
        raise ValueError(f"[ERROR] Unknown metric_name: {metric_name}")




def compute_phi_norm(agent):
    mask_bool = agent.mask > config.support_cutoff_eps
    norm = np.linalg.norm(agent.phi, axis=-1)
    return norm * mask_bool

def compute_combined_field(agents, metric="phi_norm"):
    field = np.zeros_like(agents[0].phi[..., 0])
    mask_overlay = np.zeros_like(field)
    label_coords = []

    for agent in agents:
        m = agent.mask > config.support_cutoff_eps
        φ_norm = compute_phi_norm(agent) if metric == "phi_norm" else 0
        field += φ_norm
        mask_overlay += m.astype(int)
        if np.any(m):
            cx, cy = np.argwhere(m).mean(axis=0)
            label_coords.append((cy, cx, agent.id))
    return field, mask_overlay, label_coords

def animate_all_phi_norm(frames):
    all_vals = [f[1] for f in frames if np.any(f[1])]
    vmin = 0
    vmax = np.percentile(np.concatenate([f.ravel() for f in all_vals]), 99)

    fig, ax = plt.subplots(figsize=(6, 6))
    im = ax.imshow(frames[0][1], cmap=CMAP, vmin=vmin, vmax=vmax, animated=True)
    ax.axis("off")
    cb = fig.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
    title = ax.set_title("")

    def update(idx):
        step, field, mask_overlay, labels = frames[idx]
        im.set_data(np.ma.masked_where(field == 0, field))
        for coll in ax.collections[:]:  # ← fix here
            coll.remove()
        ax.contour(mask_overlay, levels=[0.5], colors='white', linewidths=0.5)
        for x, y, aid in labels:
            ax.text(x, y, f"A{aid}", color='white', fontsize=6, ha='center', va='center')
        title.set_text(f"φ-norm | step={step}")
        return [im, title]


    ani = animation.FuncAnimation(
        fig, update, frames=len(frames), interval=INTERVAL, blit=False
    )

    outname = OUTDIR / "phi_norm_all_agents.gif"
    ani.save(outname, writer=animation.PillowWriter(fps=FPS))
    plt.close(fig)
    print(f"[✓] Saved multi-agent φ-norm animation → {outname}")


def main():
    agent_steps = load_checkpoints()
    agents0, _ = agent_steps[0]
    agent_ids = AGENT_IDS or [a.id for a in agents0]
    
    # --- Individual agent metric animations ---
    for metric in METRICS:
        for aid in agent_ids:
            field_seq = []
            for agents, step in agent_steps[::DOWNSAMPLE]:
                try:
                    agent = next(a for a in agents if a.id == aid)
                    field = compute_field(agent, metric, agents=agents)
                    field_seq.append((step, field))
                except Exception as e:
                    print(f"[!] Could not compute {metric} for agent {aid} at step {step}: {e}")
                    continue

            if not field_seq:
                continue

            all_vals = np.stack([f for _, f in field_seq])
            vmin = 0
            vmax = np.percentile(all_vals, 99)

            fname = OUTDIR / f"{metric}_agent{aid}.gif"
            make_single_panel_gif(field_seq, field_idx=1, title_fmt=f"{metric} (step={{step}})", outname=fname.stem)

    # --- Combined φ-norm overlay animation ---
    if "phi_norm" in METRICS:
        frames = []
        for agents, step in agent_steps[::DOWNSAMPLE]:
            field, mask_overlay, labels = compute_combined_field(agents, metric="phi_norm")
            if np.any(field):
                frames.append((step, field, mask_overlay, labels))
        if frames:
            animate_all_phi_norm(frames)
    

if __name__ == "__main__":
    main()
