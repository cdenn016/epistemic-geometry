# -*- coding: utf-8 -*-
"""
Created on Thu Jul 10 14:06:38 2025

@author: chris and christine
"""

# lhs_analysis_module.py

import os
import pickle
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from pathlib import Path

# ---------------------- #
#      LOAD HELPERS      #
# ---------------------- #
def load_pickle(path):
    with open(path, "rb") as f:
        return pickle.load(f)

def extract_run_metrics(run_dir):
    result = {"run": os.path.basename(run_dir)}
    param_path = Path(run_dir) / "params.pkl"
    if param_path.exists():
        result.update(load_pickle(param_path))

    metric_path = Path(run_dir) / "metric_log.pkl"
    if metric_path.exists():
        try:
            metrics = load_pickle(metric_path)
            if isinstance(metrics, list) and metrics:
                final = metrics[-1]
                for k, v in final.items():
                    if k != "step":
                        result[f"final_{k}"] = v
        except Exception as e:
            print(f"[ERROR] Failed to load metric_log from {run_dir}: {e}")

    return result

def extract_timeseries(run_dir):
    run_name = os.path.basename(run_dir)
    metric_path = Path(run_dir) / "metric_log.pkl"
    if not metric_path.exists():
        return None
    try:
        metrics = load_pickle(metric_path)
        df = pd.DataFrame(metrics)
        df["run"] = run_name
        return df
    except Exception as e:
        print(f"[ERROR] Failed to parse time-series for {run_name}: {e}")
        return None

# ---------------------- #
#       PLOTTING         #
# ---------------------- #
def format_param_value(val):
    try:
        return f"{float(val):.3g}"
    except:
        return str(val).replace(" ", "_").replace("/", "-").replace(":", "_")

def save_individual_metric_plots(df_time, df_summary, outdir="lhs_results/individual_metrics", energy_thresh=40.0):
    Path(outdir).mkdir(parents=True, exist_ok=True)
    known_cols = set(df_time.columns) | {"run"}
    param_cols = [col for col in df_summary.columns if col not in known_cols]
    folder_keys = ["alpha", "beta", "gamma", "curvature_weight", "phi_phi_tilde_coupling"]

    for run, group in df_time.groupby("run"):
        if group["energy_total"].max() > energy_thresh:
            continue
        if group["energy_total"].iloc[-1] >= group["energy_total"].iloc[0]:
            continue

        row = df_summary[df_summary["run"] == run]
        if row.empty:
            continue
        row = row.iloc[0]

        param_str = "__".join([f"{k}={format_param_value(row[k])}" for k in folder_keys if k in row])
        safe_dirname = f"{run}__{param_str}"
        safe_dirname = safe_dirname.replace("[", "").replace("]", "").replace("\n", "").replace(" ", "").replace("_0.", "_0p").replace(".", "p")
        run_dir = Path(outdir) / safe_dirname[:250]  # Trim to avoid Windows MAX_PATH

        try:
            run_dir.mkdir(parents=True, exist_ok=True)
        except Exception as e:
            print(f"[SKIP] Failed to create folder: {run_dir}\n → {e}")
            continue

        with open(run_dir / "params.txt", "w") as f:
            for k in param_cols:
                f.write(f"{k}: {row.get(k, '')}\n")

        for metric in group.columns:
            if metric in {"step", "run"}:
                continue
            plt.figure(figsize=(6, 4))
            plt.plot(group["step"], group[metric], lw=2)
            plt.xlabel("Step")
            plt.ylabel(metric)
            plt.title(f"{run} — {metric}")
            plt.grid(True)
            plt.tight_layout()
            plt.savefig(run_dir / f"{metric}.png")
            plt.close()

        print(f"[✓] Saved metrics for {run} → {run_dir}")

# ---------------------- #
#         MAIN           #
# ---------------------- #
def main():
    BASE_DIR = "lhs_results"
    METRICS_CSV = Path(BASE_DIR) / "metrics_over_time.csv"
    SUMMARY_CSV = Path(BASE_DIR) / "summary_metrics.csv"
    OUTPUT_DIR = Path(BASE_DIR) / "individual_metrics"
    ENERGY_THRESH = 40.0
    REQUIRE_DECREASING = True

    run_dirs = sorted([Path(BASE_DIR) / d for d in os.listdir(BASE_DIR) if d.startswith("run_")])
    all_summary = []
    all_timeseries = []

    for run_dir in run_dirs:
        summary = extract_run_metrics(run_dir)
        all_summary.append(summary)

        ts_df = extract_timeseries(run_dir)
        if ts_df is not None:
            all_timeseries.append(ts_df)

    df_summary = pd.DataFrame(all_summary)
    df_summary.to_csv(SUMMARY_CSV, index=False)

    if all_timeseries:
        df_time = pd.concat(all_timeseries, axis=0)
        if "total_energy" in df_time.columns:
            df_time = df_time.rename(columns={"total_energy": "energy_total"})
        df_time.to_csv(METRICS_CSV, index=False)
    else:
        print("⚠️ No time-series data found.")
        return

    # FILTER & PLOT
    good_runs = []
    for run, group in df_time.groupby("run"):
        if group["energy_total"].max() > ENERGY_THRESH:
            continue
        if not group["energy_total"].notna().all():
            continue
        if REQUIRE_DECREASING and group["energy_total"].iloc[-1] >= group["energy_total"].iloc[0]:
            continue
        good_runs.append(run)

    df_time_filtered = df_time[df_time["run"].isin(good_runs)]
    print(f"[INFO] {len(good_runs)} good runs: {good_runs}")
    save_individual_metric_plots(df_time_filtered, df_summary, outdir=OUTPUT_DIR)

if __name__ == "__main__":
    main()
