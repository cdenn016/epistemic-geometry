# -*- coding: utf-8 -*-
"""
Created on Sat Sep 27 15:19:10 2025

@author: chris and christine
"""

import numpy as np
from runtime_context import cfg_get
from core.numerical_utils import sanitize_sigma, kl_gaussian, push_gaussian
from core.transport_cache import Omega, Phi   
from utils import _joint_mask


# ---------- common utils ----------

def _soft_weights(logits: np.ndarray, *, mode: str, lo: float, hi: float) -> np.ndarray:
    """Per-receiver normalization (softmax) or plain exp; with clipping."""
    if mode == "softmax":
        m = np.max(logits)
        ex = np.exp(logits - m)
        w = ex / max(1e-12, float(np.sum(ex)))
    else:
        w = np.exp(logits)
    return np.clip(w, lo, hi).astype(np.float32, copy=False)


def _ids_of(agents):
    return [int(getattr(a, "id", i)) for i, a in enumerate(agents)]


# ---------- Q-fiber builders ----------

def build_beta_q_peer(ctx, agents, *, kappa: float, mode: str, lo: float, hi: float, eps: float, tau: float):
    """β_q: KL( q_i || Ω^q_ij q_j )"""
    beta_q, ids = {}, _ids_of(agents)
    for i_idx, ai in enumerate(agents):
        i_id = ids[i_idx]
        mu_i = np.asarray(ai.mu_q_field,  np.float32)
        S_i  = sanitize_sigma(np.asarray(ai.sigma_q_field, np.float64))
        KLs, js = [], []
        for j_idx, aj in enumerate(agents):
            if j_idx == i_idx: continue
            j_id = ids[j_idx]
            overlap = _joint_mask(ai, aj, tau=tau, as_vector=True)
            if not np.any(overlap): continue
            Om_q = Omega(ctx, ai, aj, which="q")
            mu_qj = np.asarray(aj.mu_q_field,  np.float32)
            S_qj  = sanitize_sigma(np.asarray(aj.sigma_q_field, np.float64))
            mu_qj_t, S_qj_t, _ = push_gaussian(mu_qj, S_qj, Om_q, eps=eps, return_inv=True, assume_orthogonal=False)
            KLpx = kl_gaussian(mu_i, S_i, mu_qj_t, S_qj_t)  # KL(q_i || Ω q_j)
            KLs.append(float(np.sum(KLpx * overlap) / max(1.0, float(np.sum(overlap)))))
            js.append(j_id)
        if js:
            logits = -np.asarray(KLs, np.float64) / max(1e-12, kappa)
            w = _soft_weights(logits, mode=mode, lo=lo, hi=hi)
            for j_id, wij in zip(js, w):
                beta_q[(i_id, int(j_id))] = float(wij)
    return beta_q


def build_beta_q_peer_rev(ctx, agents, *, kappa: float, mode: str, lo: float, hi: float, eps: float, tau: float):
    """β_q: KL( Ω^q_ij q_j || q_i )"""
    beta_q, ids = {}, _ids_of(agents)
    for i_idx, ai in enumerate(agents):
        i_id = ids[i_idx]
        mu_i = np.asarray(ai.mu_q_field,  np.float32)
        S_i  = sanitize_sigma(np.asarray(ai.sigma_q_field, np.float64))
        KLs, js = [], []
        for j_idx, aj in enumerate(agents):
            if j_idx == i_idx: continue
            j_id = ids[j_idx]
            overlap = _joint_mask(ai, aj, tau=tau, as_vector=True)
            if not np.any(overlap): continue
            Om_q = Omega(ctx, ai, aj, which="q")
            mu_qj = np.asarray(aj.mu_q_field,  np.float32)
            S_qj  = sanitize_sigma(np.asarray(aj.sigma_q_field, np.float64))
            mu_qj_t, S_qj_t, _ = push_gaussian(mu_qj, S_qj, Om_q, eps=eps, return_inv=True, assume_orthogonal=False)
            KLpx = kl_gaussian(mu_qj_t, S_qj_t, mu_i, S_i)  # KL(Ω q_j || q_i)
            KLs.append(float(np.sum(KLpx * overlap) / max(1.0, float(np.sum(overlap)))))
            js.append(j_id)
        if js:
            logits = -np.asarray(KLs, np.float64) / max(1e-12, kappa)
            w = _soft_weights(logits, mode=mode, lo=lo, hi=hi)
            for j_id, wij in zip(js, w):
                beta_q[(i_id, int(j_id))] = float(wij)
    return beta_q


def build_beta_q_model_gated(ctx, agents, *, kappa: float, mode: str, lo: float, hi: float, eps: float, tau: float):
    """β_q: KL( Ω^q_ij q_j || Φ̃_i p_i )   <-- your requested definition"""
    beta_q, ids = {}, _ids_of(agents)
    for i_idx, ai in enumerate(agents):
        i_id = ids[i_idx]
        # precompute receiver's model rendered as observation in Q_i: q_hat_i = Φ̃_i p_i
        Phit_i = Phi(ctx, ai, kind="p_to_q")   # Φ̃_i : P_i -> Q_i
        mu_pi  = np.asarray(ai.mu_p_field,  np.float32)
        S_pi   = sanitize_sigma(np.asarray(ai.sigma_p_field, np.float64))
         # A = Φ̃_i : (..., q, p)
        A = Phit_i
        
        # μ_q = A μ_p
        mu_q_hat_i = np.einsum("...qp,...p->...q", A, mu_pi, optimize=True).astype(np.float32, copy=False)
        
        # Σ_q = A Σ_p A^T
        S_q_hat_i  = np.einsum("...qp,...pr,...rq->...qr", A, S_pi, A, optimize=True)
        S_q_hat_i  = sanitize_sigma(S_q_hat_i).astype(np.float64, copy=False)

        
        KLs, js = [], []
        for j_idx, aj in enumerate(agents):
            if j_idx == i_idx: continue
            j_id = ids[j_idx]
            overlap = _joint_mask(ai, aj, tau=tau, as_vector=True)
            if not np.any(overlap): continue
            Om_q = Omega(ctx, ai, aj, which="q")
            mu_qj = np.asarray(aj.mu_q_field,  np.float32)
            S_qj  = sanitize_sigma(np.asarray(aj.sigma_q_field, np.float64))
            mu_qj_t, S_qj_t, _ = push_gaussian(mu_qj, S_qj, Om_q, eps=eps, return_inv=True, assume_orthogonal=False)
            KLpx = kl_gaussian(mu_qj_t, S_qj_t, mu_q_hat_i, S_q_hat_i)  # KL(Ω q_j || Φ̃_i p_i)
            KLs.append(float(np.sum(KLpx * overlap) / max(1.0, float(np.sum(overlap)))))
            js.append(j_id)
        if js:
            logits = -np.asarray(KLs, np.float64) / max(1e-12, kappa)
            w = _soft_weights(logits, mode=mode, lo=lo, hi=hi)
            for j_id, wij in zip(js, w):
                beta_q[(i_id, int(j_id))] = float(wij)
    return beta_q

def build_beta_q_model_gated_reversed(ctx, agents, *,
                                      kappa: float,
                                      mode: str,
                                      lo: float,
                                      hi: float,
                                      eps: float,
                                      tau: float):
    """
    β_q (reversed order):
        KL( Φ̃_i p_i  ||  Ω^q_ij q_j )

    Returns:
        dict { (i_id, j_id): scalar β_ij }
    """
    beta_q, ids = {}, _ids_of(agents)

    for i_idx, ai in enumerate(agents):
        i_id = ids[i_idx]

        # Receiver model rendered in its own q-frame: q̂_i = Φ̃_i p_i
        A = Phi(ctx, ai, kind="p_to_q")               # (..., q, p)
        mu_p = np.asarray(ai.mu_p_field,  np.float32)
        S_p  = sanitize_sigma(np.asarray(ai.sigma_p_field, np.float64))
        mu_q_hat = np.einsum("...qp,...p->...q",  A, mu_p, optimize=True).astype(np.float32, copy=False)
        S_q_hat  = np.einsum("...qp,...pr,...rq->...qr", A, S_p, A, optimize=True)
        S_q_hat  = sanitize_sigma(S_q_hat).astype(np.float64, copy=False)

        KLs, js = [], []
        for j_idx, aj in enumerate(agents):
            if j_idx == i_idx:
                continue
            j_id = ids[j_idx]

            # Overlap in i's frame
            overlap = _joint_mask(ai, aj, tau=tau, as_vector=True)
            if not np.any(overlap):
                continue

            # Sender belief pushed into i's q-frame
            Om_q   = Omega(ctx, ai, aj, which="q")
            mu_qj  = np.asarray(aj.mu_q_field,  np.float32)
            S_qj   = sanitize_sigma(np.asarray(aj.sigma_q_field, np.float64))
            mu_qj_t, S_qj_t, _ = push_gaussian(
                mu_qj, S_qj, Om_q, eps=eps, return_inv=True, assume_orthogonal=False
            )

            # Pixelwise KL: KL( Φ̃_i p_i  ||  Ω^q_ij q_j )
            KLpx  = kl_gaussian(mu_q_hat, S_q_hat, mu_qj_t, S_qj_t)
            denom = max(1.0, float(np.sum(overlap)))
            KLs.append(float(np.sum(KLpx * overlap) / denom))
            js.append(j_id)

        if js:
            logits = -np.asarray(KLs, np.float64) / max(1e-12, kappa)
            w      = _soft_weights(logits, mode=mode, lo=lo, hi=hi)
            for j_id, wij in zip(js, w):
                beta_q[(i_id, int(j_id))] = float(wij)

    return beta_q





def build_beta_q_belief_to_model(ctx, agents, *, kappa: float, mode: str, lo: float, hi: float, eps: float, tau: float):
    """β_q: KL( p_i || Φ_i[ Ω^q_ij q_j ] )   (interpret belief via Φ_i in P-space)"""
    beta_q, ids = {}, _ids_of(agents)
    for i_idx, ai in enumerate(agents):
        i_id = ids[i_idx]
        mu_pi = np.asarray(ai.mu_p_field,  np.float32)
        S_pi  = sanitize_sigma(np.asarray(ai.sigma_p_field, np.float64))
        Phi_i = Phi(ctx, ai, kind="q_to_p")  # Φ_i : Q_i -> P_i

        KLs, js = [], []
        for j_idx, aj in enumerate(agents):
            if j_idx == i_idx: continue
            j_id = ids[j_idx]
            overlap = _joint_mask(ai, aj, tau=tau, as_vector=True)
            if not np.any(overlap): continue
            Om_q = Omega(ctx, ai, aj, which="q")
            mu_qj = np.asarray(aj.mu_q_field,  np.float32)
            S_qj  = sanitize_sigma(np.asarray(aj.sigma_q_field, np.float64))
            mu_qj_t, S_qj_t, _ = push_gaussian(mu_qj, S_qj, Om_q, eps=eps, return_inv=True, assume_orthogonal=False)
            # map to P_i via Φ_i
            mu_hat_p = np.einsum("...pk,...k->...p", Phi_i, mu_qj_t, optimize=True)
            S_hat_p  = np.einsum("...pa,...ab,...pb->...pp", Phi_i, S_qj_t, Phi_i, optimize=True)
            S_hat_p  = sanitize_sigma(S_hat_p)
            KLpx = kl_gaussian(mu_pi, S_pi, mu_hat_p, S_hat_p)  # KL(p_i || Φ_i[Ω q_j])
            KLs.append(float(np.sum(KLpx * overlap) / max(1.0, float(np.sum(overlap)))))
            js.append(j_id)
        if js:
            logits = -np.asarray(KLs, np.float64) / max(1e-12, kappa)
            w = _soft_weights(logits, mode=mode, lo=lo, hi=hi)
            for j_id, wij in zip(js, w):
                beta_q[(i_id, int(j_id))] = float(wij)
    return beta_q


# ---------- P-fiber builders ----------

def build_beta_p_peer(ctx, agents, *, kappa: float, mode: str, lo: float, hi: float, eps: float, tau: float):
    """β_p: KL( p_i || Ω^p_ij p_j )"""
    
    beta_p, ids = {}, _ids_of(agents)
    for i_idx, ai in enumerate(agents):
        i_id = ids[i_idx]
        mu_pi = np.asarray(ai.mu_p_field,  np.float32)
        S_pi  = sanitize_sigma(np.asarray(ai.sigma_p_field, np.float64))
        KLs, js = [], []
        for j_idx, aj in enumerate(agents):
            if j_idx == i_idx: continue
            j_id = ids[j_idx]
            overlap = _joint_mask(ai, aj, tau=tau, as_vector=True)
            if not np.any(overlap): continue
            Om_p = Omega(ctx, ai, aj, which="p")
            mu_pj = np.asarray(aj.mu_p_field,  np.float32)
            S_pj  = sanitize_sigma(np.asarray(aj.sigma_p_field, np.float64))
            mu_pj_t, S_pj_t, _ = push_gaussian(mu_pj, S_pj, Om_p, eps=eps, return_inv=True, assume_orthogonal=False)
            KLpx = kl_gaussian(mu_pi, S_pi, mu_pj_t, S_pj_t)
            KLs.append(float(np.sum(KLpx * overlap) / max(1.0, float(np.sum(overlap)))))
            js.append(j_id)
        if js:
            logits = -np.asarray(KLs, np.float64) / max(1e-12, kappa)
            w = _soft_weights(logits, mode=mode, lo=lo, hi=hi)
            for j_id, wij in zip(js, w):
                beta_p[(i_id, int(j_id))] = float(wij)
    return beta_p


def build_beta_p_belief_from_q(ctx, agents, *, kappa: float, mode: str, lo: float, hi: float, eps: float, tau: float):
    """
    β_p: KL( Φ_i[Ω^q_ij q_j] || p_i )
    Interpret sender's belief via receiver's encoder Φ_i (Q→P) and compare to p_i.
    """
    beta_p, ids = {}, _ids_of(agents)

    for i_idx, ai in enumerate(agents):
        i_id  = ids[i_idx]

        # Receiver's model in P_i (comparison target)
        mu_pi = np.asarray(ai.mu_p_field,  np.float32)
        S_pi  = sanitize_sigma(np.asarray(ai.sigma_p_field, np.float64))

        # Receiver's encoder Φ_i : Q_i -> P_i  (shape ... x p x q)
        Phi_i = Phi(ctx, ai, kind="q_to_p")

        KLs, js = [], []
        for j_idx, aj in enumerate(agents):
            if j_idx == i_idx:
                continue
            j_id = ids[j_idx]

            # Joint support in i's base frame
            overlap = _joint_mask(ai, aj, tau=tau, as_vector=True)
            if not np.any(overlap):
                continue

            # Push sender belief into i's Q-frame: Ω^q_ij q_j
            Om_q  = Omega(ctx, ai, aj, which="q")
            mu_qj = np.asarray(aj.mu_q_field,  np.float32)
            S_qj  = sanitize_sigma(np.asarray(aj.sigma_q_field, np.float64))
            mu_qj_t, S_qj_t, _ = push_gaussian(
                mu_qj, S_qj, Om_q, eps=eps, return_inv=True, assume_orthogonal=False
            )

            # Encode into P_i via Φ_i: μ_p_hat = Φ μ_q ; Σ_p_hat = Φ Σ_q Φ^T
            mu_hat_p = np.einsum("...pq,...q->...p",  Phi_i, mu_qj_t, optimize=True)
            S_hat_p  = np.einsum("...pq,...qr,...sr->...ps", Phi_i, S_qj_t, Phi_i, optimize=True)
            S_hat_p  = sanitize_sigma(S_hat_p).astype(np.float64, copy=False)
    
            # Pixelwise KL in P_i: KL( Φ_i[Ω q_j] || p_i )
            KLpx  = kl_gaussian(mu_hat_p, S_hat_p, mu_pi, S_pi)
    
            # Average over i–j overlap
            denom = max(1.0, float(np.sum(overlap)))
            KLs.append(float(np.sum(KLpx * overlap) / denom))
            js.append(j_id)
    
        if js:
            logits = -np.asarray(KLs, np.float64) / max(1e-12, kappa)
            w = _soft_weights(logits, mode=mode, lo=lo, hi=hi)
            for j_id, wij in zip(js, w):
                beta_p[(i_id, int(j_id))] = float(wij)
    
    return beta_p





def build_beta_p_model_to_obs(ctx, agents, *, kappa: float, mode: str, lo: float, hi: float, eps: float, tau: float):
    """β_p: KL( Ω^p_ij p_j || Φ̃_i p_i )  (P-side analog of model_gated_q; rarely needed)"""
    
    beta_p, ids = {}, _ids_of(agents)
    for i_idx, ai in enumerate(agents):
        i_id = ids[i_idx]
        Phit_i = Phi(ctx, ai, kind="p_to_q")   # only used if you then re-encode; often not needed
        # render p_i in Q then (optionally) compare; provided for completeness
        mu_pi  = np.asarray(ai.mu_p_field,  np.float32)
        S_pi   = sanitize_sigma(np.asarray(ai.sigma_p_field, np.float64))
       
        mu_q_hat_i = np.einsum("...kq,...k->...q", Phit_i, mu_pi, optimize=True).astype(np.float32, copy=False)
        S_q_hat_i  = np.einsum("...qa,...ab,...qb->...qq", Phit_i, S_pi, Phit_i, optimize=True)
        S_q_hat_i  = sanitize_sigma(S_q_hat_i).astype(np.float64, copy=False)

        KLs, js = [], []
        for j_idx, aj in enumerate(agents):
            if j_idx == i_idx: continue
            j_id = ids[j_idx]
            overlap = _joint_mask(ai, aj, tau=tau, as_vector=True)
            if not np.any(overlap): continue
            Om_p = Omega(ctx, ai, aj, which="p")
            mu_pj = np.asarray(aj.mu_p_field,  np.float32)
            S_pj  = sanitize_sigma(np.asarray(aj.sigma_p_field, np.float64))
            mu_pj_t, S_pj_t, _ = push_gaussian(mu_pj, S_pj, Om_p, eps=eps, return_inv=True, assume_orthogonal=False)
            # Here we keep it in P and do the simpler peer-p instead; this function is a placeholder
            KLpx = kl_gaussian(mu_pi, S_pi, mu_pj_t, S_pj_t)  # keep parity; adjust if you truly want P→Q comparison
            KLs.append(float(np.sum(KLpx * overlap) / max(1.0, float(np.sum(overlap)))))
            js.append(j_id)
        if js:
            logits = -np.asarray(KLs, np.float64) / max(1e-12, kappa)
            w = _soft_weights(logits, mode=mode, lo=lo, hi=hi)
            for j_id, wij in zip(js, w):
                beta_p[(i_id, int(j_id))] = float(wij)
    return beta_p




def compute_edge_betas(ctx, agents):
    """
    Build per-edge attention for BOTH fibers with per-receiver normalization.

    Config keys:
      obs_beta_enable: bool
      obs_beta_clip:   (lo, hi)
      obs_beta_kappa:  float
      obs_beta_mode:   "softmax" | "exp" | ...
      obs_beta_q_basis in {"peer_q","peer_q_rev","model_gated_q","belief_to_model","model_gated_q_rev"}
      obs_beta_p_basis in {"peer_p","obs_to_model","model_to_obs"}
      obs_beta_detach: bool  (if False, gradients flow through β via s_ij weighting)
    """
    # Disabled?
    if not bool(cfg_get(ctx, "obs_beta_enable", True)):
        setattr(ctx, "_edge_beta_q", None)
        setattr(ctx, "_edge_beta_p", None)
        setattr(ctx, "_edge_kl_q",   {})
        setattr(ctx, "_edge_kl_p",   {})
        setattr(ctx, "_edge_beta_cfg", {
            "q": {"kappa": 1.0, "mode": "softmax"},
            "p": {"kappa": 1.0, "mode": "softmax"},
            "obs_beta_detach": True,
        })
        return

    lo, hi = cfg_get(ctx, "obs_beta_clip", (1e-4, 10.0))
    kappa  = float(cfg_get(ctx, "obs_beta_kappa", 1.0))
    mode   = str(cfg_get(ctx, "obs_beta_mode", "softmax")).lower()
    eps    = float(cfg_get(ctx, "eps", 1e-8))
    tau    = float(cfg_get(ctx, "support_tau", 1e-6))
    detach = bool(cfg_get(ctx, "obs_beta_detach", False))

    q_basis = str(cfg_get(ctx, "obs_beta_q_basis", "model_gated_q")).lower()
    p_basis = str(cfg_get(ctx, "obs_beta_p_basis", "peer_p")).lower()

    # Builders (some may return β, others (β, KL))
    q_builders = {
        "peer_q":            build_beta_q_peer,                  # scalar/field, no KL
        "peer_q_rev":        build_beta_q_peer_rev,
        "model_gated_q":     build_beta_q_model_gated_spatial,   # returns (β, KL)
        "belief_to_model":   build_beta_q_belief_to_model,
        "model_gated_q_rev": build_beta_q_model_gated_reversed,
    }
    p_builders = {
        "peer_p":            build_beta_p_peer,                  # scalar/field, no KL
        "obs_to_model":      build_beta_p_belief_from_q_spatial, # returns (β, KL)
        "model_to_obs":      build_beta_p_model_to_obs,
    }

    if q_basis not in q_builders:
        raise ValueError(f"Unknown obs_beta_q_basis={q_basis}")
    if p_basis not in p_builders:
        raise ValueError(f"Unknown obs_beta_p_basis={p_basis}")

    # ---- Build q-side β (and KL if provided) ----
    out_q = q_builders[q_basis](ctx, agents, kappa=kappa, mode=mode, lo=lo, hi=hi, eps=eps, tau=tau)
    if isinstance(out_q, tuple) and len(out_q) == 2:
        beta_q, kl_q = out_q
    else:
        beta_q, kl_q = out_q, {}

    # ---- Build p-side β (and KL if provided) ----
    out_p = p_builders[p_basis](ctx, agents, kappa=kappa, mode=mode, lo=lo, hi=hi, eps=eps, tau=tau)
    if isinstance(out_p, tuple) and len(out_p) == 2:
        beta_p, kl_p = out_p
    else:
        beta_p, kl_p = out_p, {}

    # Normalize empty → None for convenience in callers
    beta_q = beta_q if beta_q else None
    beta_p = beta_p if beta_p else None

    # ---- Stash on ctx ----
    setattr(ctx, "_edge_beta_q", beta_q)
    setattr(ctx, "_edge_beta_p", beta_p)
    setattr(ctx, "_edge_kl_q",   kl_q or {})
    setattr(ctx, "_edge_kl_p",   kl_p or {})

    # Config snapshot for downstream (beta_effective_weight)
    setattr(ctx, "_edge_beta_cfg", {
        "q": {"kappa": float(kappa), "mode": str(mode)},
        "p": {"kappa": float(kappa), "mode": str(mode)},
        "detach": bool(detach),
    })

    # Optional debug:
    # step = getattr(ctx, "global_step", "?")
    # qn = 0 if beta_q is None else len(beta_q)
    # pn = 0 if beta_p is None else len(beta_p)
    # print(f"[obs_beta] step {step} q:{qn} p:{pn} basis=({q_basis},{p_basis}) mode={mode} κ={kappa} detach={detach}")



def old_compute_edge_betas(ctx, agents):
    """
    Build per-edge attention for BOTH fibers with per-receiver normalization.
    Choose definitions via config:
      obs_beta_q_basis in {"peer_q","peer_q_rev","model_gated_q","belief_to_model"}
      obs_beta_p_basis in {"peer_p","obs_to_model","model_to_obs"}
    """
    if not bool(cfg_get(ctx, "obs_beta_enable", True)):
        setattr(ctx, "_edge_beta_q", None)
        setattr(ctx, "_edge_beta_p", None)
        return

    lo, hi = cfg_get(ctx, "obs_beta_clip", (1e-4, 10.0))
    kappa  = float(cfg_get(ctx, "obs_beta_kappa", 1.0))
    mode   = str(cfg_get(ctx, "obs_beta_mode", "softmax")).lower()
    eps    = float(cfg_get(ctx, "eps", 1e-8))
    tau    = float(cfg_get(ctx, "support_tau", 1e-6))

    q_basis = str(cfg_get(ctx, "obs_beta_q_basis", "model_gated_q")).lower()
    p_basis = str(cfg_get(ctx, "obs_beta_p_basis", "peer_p")).lower()

    q_builders = {
        "peer_q":            build_beta_q_peer,                 #safe
        "peer_q_rev":        build_beta_q_peer_rev,
        "model_gated_q":     build_beta_q_model_gated_spatial,  #default pixelwise KL( Ω^q_ij q_j || Φ̃_i p_i )
        "belief_to_model":   build_beta_q_belief_to_model,
        "model_gated_q_rev": build_beta_q_model_gated_reversed  # KL( Φ̃_i p_i  ||  Ω^q_ij q_j )
    }
    p_builders = {
        "peer_p":            build_beta_p_peer,                 #safe
        "obs_to_model":      build_beta_p_belief_from_q_spatial,#default pixelwise KL( Φ_i[Ω^q_ij q_j] || p_i )
        "model_to_obs":      build_beta_p_model_to_obs,
    }

    if q_basis not in q_builders:
        raise ValueError(f"Unknown obs_beta_q_basis={q_basis}")
    if p_basis not in p_builders:
        raise ValueError(f"Unknown obs_beta_p_basis={p_basis}")

    beta_q = q_builders[q_basis](ctx, agents, kappa=kappa, mode=mode, lo=lo, hi=hi, eps=eps, tau=tau)
    beta_p = p_builders[p_basis](ctx, agents, kappa=kappa, mode=mode, lo=lo, hi=hi, eps=eps, tau=tau)

    setattr(ctx, "_edge_beta_q", beta_q if beta_q else None)
    setattr(ctx, "_edge_beta_p", beta_p if beta_p else None)

   # step = getattr(ctx, "global_step", "?")
   # print(f"[obs_beta] step {step} q:{len(beta_q)} p:{len(beta_p)} "
    #      f"q_basis={q_basis} p_basis={p_basis} "
    #      f"q_samp={list(beta_q.items())[:6]} p_samp={list(beta_p.items())[:6]}")



def _lookup_beta(ctx, agent_i, agent_j, *, which: str, cfg_fallback: float, debug: bool = False):
    """
    which: "q" for phi/belief, "p" for phi_model/model.

    Returns either:
      - float β_ij  (edge-scalar), or
      - np.ndarray β_ij(x,y) with shape (H,W)  (pixelwise field)

    Falls back to cfg_fallback (scalar) when missing/invalid.
    """
    import numpy as np

    # 1) pick the right map
    map_name = "_edge_beta_q" if which == "q" else "_edge_beta_p"
    beta_map = getattr(ctx, map_name, None)

    # 2) validate ids
    i_id = getattr(agent_i, "id", None)
    j_id = getattr(agent_j, "id", None)
    if i_id is None or j_id is None:
        
        print(f"[beta] missing id(s): i_id={i_id} j_id={j_id}; using cfg={cfg_fallback}")
        return float(cfg_fallback)
    i_id = int(i_id); j_id = int(j_id)

    # 3) map present?
    if not beta_map:
        
        print(f"[beta] map {map_name} empty; using cfg={cfg_fallback}")
        return float(cfg_fallback)

    # 4) entry present?
    b = beta_map.get((i_id, j_id), None)
    if b is None:
        if debug:
            js = [jj for (ii, jj) in beta_map.keys() if ii == i_id][:8]
            print(f"[beta] no entry for (i={i_id}, j={j_id}) in {map_name}; "
                  f"have senders={js}; cfg={cfg_fallback}")
        return float(cfg_fallback)

    # 5) sanitize & return (scalar or field)
    try:
        # Field case: accept ndarray / list / tuple -> (H,W) float32
        if isinstance(b, (np.ndarray, list, tuple)):
            arr = np.asarray(b, np.float32)
            if arr.ndim == 0:
                # degenerate scalar masquerading as array
                val = float(arr)
                if not np.isfinite(val):
                    print(f"[beta] non-finite β={val}; cfg={cfg_fallback}")
                    return float(cfg_fallback)
                return val
            # elementwise finite check
            if not np.all(np.isfinite(arr)):
                bad = np.count_nonzero(~np.isfinite(arr))
                print(f"[beta] {bad} non-finite px in β field; replacing with cfg={cfg_fallback}")
                # replace bad pixels with cfg_fallback
                good = np.isfinite(arr)
                arr = np.where(good, arr, np.float32(cfg_fallback))
            return arr

        # Scalar case
        val = float(b)
        if not np.isfinite(val):          
            print(f"[beta] non-finite β={val}; cfg={cfg_fallback}")
            return float(cfg_fallback)
        return val

    except Exception as e:      
        print(f"[beta] error parsing β value {b!r}: {e}; cfg={cfg_fallback}")
        return float(cfg_fallback)







#====================================
#
#      PIXELWISE BETA FIELDS
#
#====================================


# --- update_helpers.py (or a common utils module) ---

def beta_effective_weight(ctx, i_id: int, j_id: int, *, which: str, joint_mask, allow_exp: bool = True):
    """
    Returns s_ij(x,y) for weighting ∂KL/∂θ:
      softmax beta:  s = β * [1 - (KL - KL_bar)/kappa]
      exp     beta:  s = β * [1 - KL/kappa]
    Requires ctx._edge_beta_{q,p}, ctx._edge_kl_{q,p}, and ctx._edge_beta_cfg.
    """
    import numpy as np

    beta_map = getattr(ctx, "_edge_beta_q" if which == "q" else "_edge_beta_p", {})
    kl_map   = getattr(ctx, "_edge_kl_q"   if which == "q" else "_edge_kl_p", {})
    cfg      = getattr(ctx, "_edge_beta_cfg", {})
    sub      = cfg.get(which, {})
    kappa    = float(sub.get("kappa", 1.0))
    mode     = str(sub.get("mode", "softmax")).lower()
    detach   = bool(cfg.get("obs_beta_detach", False))

    H, W = joint_mask.shape
    beta_ij = beta_map.get((i_id, j_id), None)
    if beta_ij is None:
        return np.zeros((H, W), np.float32)

    beta_ij = np.asarray(beta_ij, np.float32)
    if beta_ij.shape != (H, W):
        raise ValueError(f"beta_effective_weight: β shape {beta_ij.shape} != {(H,W)} for edge {(i_id,j_id)}")
    beta_ij = beta_ij * joint_mask.astype(np.float32)

    if detach:
        print("DETACHED!!!\n\n\n")
        return beta_ij  # old behavior

    KL_ij = np.asarray(kl_map.get((i_id, j_id), None), np.float32)
    if KL_ij is None:
        raise RuntimeError(f"beta_effective_weight: missing KL map for edge {(i_id,j_id)} and which='{which}'")
    if KL_ij.shape != (H, W):
        raise ValueError(f"beta_effective_weight: KL shape {KL_ij.shape} != {(H,W)} for edge {(i_id,j_id)}")

    if mode in ("softmax", "sm", "normexp"):
        # KL_bar = sum_r β_ir * KL_ir
        KL_bar = np.zeros((H, W), np.float32)
        for (ii, jj), b in beta_map.items():
            if ii != i_id: continue
            b = np.asarray(b, np.float32)
            if b.shape != (H, W): raise ValueError("inconsistent β field shape")
            KL_r = np.asarray(kl_map.get((ii, jj), None), np.float32)
            if KL_r is None or KL_r.shape != (H, W):
                raise RuntimeError(f"missing KL map for edge {(ii,jj)}")
            KL_bar += (b * KL_r)
        s = beta_ij * (1.0 - (KL_ij - KL_bar) / max(kappa, 1e-12))
    elif allow_exp and mode in ("exp", "gated-exp", "exp-gated"):
        s = beta_ij * (1.0 - KL_ij / max(kappa, 1e-12))
    else:
        # default to softmax formula
        KL_bar = np.zeros((H, W), np.float32)
        for (ii, jj), b in beta_map.items():
            if ii != i_id: continue
            b = np.asarray(b, np.float32); KL_r = np.asarray(kl_map.get((ii, jj), None), np.float32)
            KL_bar += (b * KL_r)
        s = beta_ij * (1.0 - (KL_ij - KL_bar) / max(kappa, 1e-12))

    return s * joint_mask.astype(np.float32)



def nograd_build_beta_q_model_gated_spatial(ctx, agents, *, kappa: float, mode: str, lo: float, hi: float, eps: float, tau: float):
    """
    Pixelwise β_q maps for each (i<-j):
      β_{i<-j}(x,y) ∝ exp( - KL_{x,y}( Ω^q_ij q_j || Φ̃_i p_i ) / κ )
    Returns: dict[(i_id, j_id)] -> (H,W) float32
    """
    import numpy as np
    from core.transport_cache import Omega, Phi
    from core.numerical_utils import sanitize_sigma, kl_gaussian, push_gaussian
    from utils import _joint_mask

    ids = [int(getattr(a, "id", i)) for i, a in enumerate(agents)]
    beta_q = {}

    # Precompute q̂_i = Φ̃_i p_i in Q_i
    qhat_mu, qhat_S = [], []
    for ai in agents:
        A     = Phi(ctx, ai, kind="p_to_q")  # (..., q, p)
        mu_p  = np.asarray(ai.mu_p_field,  np.float32)
        S_p   = sanitize_sigma(np.asarray(ai.sigma_p_field, np.float64))
        mu_q  = np.einsum("...qp,...p->...q",  A, mu_p, optimize=True).astype(np.float32, copy=False)
        S_q   = np.einsum("...qp,...pr,...rq->...qr", A, S_p, A, optimize=True)
        S_q   = sanitize_sigma(S_q).astype(np.float64, copy=False)
        qhat_mu.append(mu_q)
        qhat_S.append(S_q)

    for i_idx, ai in enumerate(agents):
        i_id     = ids[i_idx]
        mu_q_hat = qhat_mu[i_idx]  # (H,W,Kq)
        S_q_hat  = qhat_S[i_idx]   # (H,W,Kq,Kq)

        H, W = mu_q_hat.shape[:2]

        KL_maps   = []   # each (H,W)
        sender_id = []
        masks     = []   # each (H,W) bool

        for j_idx, aj in enumerate(agents):
            if j_idx == i_idx: 
                continue
            j_id = ids[j_idx]

            # **FIX**: 2-D mask, not vector — prevents (H,W,W) broadcast
            overlap = _joint_mask(ai, aj, tau=tau, as_vector=False)  # (H,W) bool
            if not np.any(overlap):
                continue

            # Push sender into i's Q-frame
            Om_q   = Omega(ctx, ai, aj, which="q")
            mu_qj  = np.asarray(aj.mu_q_field,  np.float32)
            S_qj   = sanitize_sigma(np.asarray(aj.sigma_q_field, np.float64))
            mu_t, S_t, _ = push_gaussian(
                mu_qj, S_qj, Om_q, eps=eps, return_inv=True, assume_orthogonal=False
            )

            # KL per pixel
            KLpx = kl_gaussian(mu_t, S_t, mu_q_hat, S_q_hat)  # ideally (H,W)
            KLpx = np.asarray(KLpx, np.float64)

            # enforce spatial shape (H,W); if extra trailing axes, collapse them
            if KLpx.shape[:2] != (H, W):
                raise ValueError(f"KLpx spatial dims {KLpx.shape[:2]} != (H,W)=({H},{W}) for (i={i_id}, j={j_id})")
            if KLpx.ndim == 2:
                pass
            elif KLpx.ndim > 2:
                KLpx = KLpx.reshape(H, W, -1).sum(axis=-1)
            else:
                raise ValueError(f"KLpx ndim={KLpx.ndim} unexpected for (i={i_id}, j={j_id})")

            # mask outside overlap with +inf (so exp(-inf)=0 later)
            KLpx_masked = np.where(overlap, KLpx, np.inf)

            KL_maps.append(KLpx_masked)
            sender_id.append(j_id)
            masks.append(overlap)

        if not KL_maps:
            continue

        # Stack senders: (J,H,W)
        K = np.stack(KL_maps, axis=0)
        if K.shape[1:] != (H, W):
            raise ValueError(f"Stacked KL maps shape {K.shape} wrong; expected (*,{H},{W})")

        # logits = -KL/κ
        logits = -K / max(1e-12, float(kappa))

        if mode == "softmax":
            m   = np.max(logits, axis=0, keepdims=True)           # (1,H,W)
            ex  = np.exp(logits - m) * np.isfinite(K)             # zero at masked pixels
            den = np.sum(ex, axis=0, keepdims=True)               # (1,H,W)
            den = np.maximum(den, 1e-12)
            Wj  = ex / den                                        # (J,H,W)
        else:
            Wj  = np.exp(logits) * np.isfinite(K)                 # (J,H,W)

        if not (lo <= 0.0 and hi >= 1.0):
            Wj = np.clip(Wj, lo, hi)

        # Store per-edge fields, guarantee (H,W)
        for s, j_id in enumerate(sender_id):
            wm = Wj[s]                                           # (H,W)
            wm = np.where(masks[s], wm, 0.0)
            wm = np.asarray(wm, np.float32, order="C")
            if wm.ndim != 2:
                wm = wm.reshape(H, W, -1).sum(axis=-1)
            if wm.shape != (H, W):
                raise ValueError(f"β_q map shape {wm.shape} not (H,W)=({H},{W}) for (i={i_id}, j={j_id})")
          
            beta_q[(i_id, int(j_id))] = wm

    return beta_q

def build_beta_q_model_gated_spatial(ctx, agents, *, kappa: float, mode: str, lo: float, hi: float, eps: float, tau: float):
    """
    Pixelwise β_q maps for each (i<-j):
      β_{i<-j}(x,y) ∝ exp( - KL_{x,y}( Ω^q_ij q_j || Φ̃_i p_i ) / κ )

    Returns:
      beta_q: dict[(i_id, j_id)] -> (H,W) float32
      kl_q:   dict[(i_id, j_id)] -> (H,W) float32  (KL per pixel; 0 outside overlap)
    """
    import numpy as np
    from core.transport_cache import Omega, Phi
    from core.numerical_utils import sanitize_sigma, kl_gaussian, push_gaussian
    from utils import _joint_mask

    ids = [int(getattr(a, "id", i)) for i, a in enumerate(agents)]
    beta_q, kl_q = {}, {}

    # Precompute q̂_i = Φ̃_i p_i in Q_i
    qhat_mu, qhat_S = [], []
    for ai in agents:
        A     = Phi(ctx, ai, kind="p_to_q")  # (..., q, p)
        mu_p  = np.asarray(ai.mu_p_field,  np.float32)
        S_p   = sanitize_sigma(np.asarray(ai.sigma_p_field, np.float64))
        mu_q  = np.einsum("...qp,...p->...q",  A, mu_p, optimize=True).astype(np.float32, copy=False)
        S_q   = np.einsum("...qp,...pr,...rq->...qr", A, S_p, A, optimize=True)
        S_q   = sanitize_sigma(S_q).astype(np.float64, copy=False)
        qhat_mu.append(mu_q)
        qhat_S.append(S_q)

    for i_idx, ai in enumerate(agents):
        i_id     = ids[i_idx]
        mu_q_hat = qhat_mu[i_idx]  # (H,W,Kq)
        S_q_hat  = qhat_S[i_idx]   # (H,W,Kq,Kq)

        H, W = mu_q_hat.shape[:2]

        KL_maps_masked = []   # list of (J,H,W) masked with +inf outside overlap
        KL_maps_grad   = []   # list of (J,H,W) with 0 outside overlap (for grads)
        sender_id      = []
        masks          = []   # (H,W) bool per sender

        for j_idx, aj in enumerate(agents):
            if j_idx == i_idx:
                continue
            j_id = ids[j_idx]

            overlap = _joint_mask(ai, aj, tau=tau, as_vector=False)  # (H,W) bool
            if not np.any(overlap):
                continue

            Om_q   = Omega(ctx, ai, aj, which="q")
            mu_qj  = np.asarray(aj.mu_q_field,  np.float32)
            S_qj   = sanitize_sigma(np.asarray(aj.sigma_q_field, np.float64))

            mu_t, S_t, _ = push_gaussian(
                mu_qj, S_qj, Om_q, eps=eps, return_inv=True, assume_orthogonal=False
            )

            KLpx = kl_gaussian(mu_t, S_t, mu_q_hat, S_q_hat)  # expect (H,W)
            KLpx = np.asarray(KLpx, np.float64)
            if KLpx.shape[:2] != (H, W):
                raise ValueError(f"KLpx spatial dims {KLpx.shape[:2]} != (H,W)=({H},{W}) for (i={i_id}, j={j_id})")
            if KLpx.ndim > 2:
                KLpx = KLpx.reshape(H, W, -1).sum(axis=-1)  # collapse trailing axes

            # For β construction: +inf outside overlap so exp(-inf)=0
            KL_masked = np.where(overlap, KLpx, np.inf)
            # For gradient weighting: 0 outside overlap (finite field)
            KL_grad   = np.where(overlap, KLpx, 0.0).astype(np.float32, copy=False)

            KL_maps_masked.append(KL_masked)
            KL_maps_grad.append(KL_grad)
            sender_id.append(j_id)
            masks.append(overlap)

        if not sender_id:
            continue

        # Stack senders: (J,H,W)
        K = np.stack(KL_maps_masked, axis=0)
        if K.shape[1:] != (H, W):
            raise ValueError(f"Stacked KL maps shape {K.shape} wrong; expected (*,{H},{W})")

        # logits = -KL/κ
        logits = -K / max(1e-12, float(kappa))

        mode_l = (mode or "softmax").lower()
        if mode_l in ("softmax", "sm", "normexp"):
            m   = np.max(logits, axis=0, keepdims=True)       # (1,H,W)
            ex  = np.exp(logits - m) * np.isfinite(K)         # zero at masked pixels
            den = np.sum(ex, axis=0, keepdims=True)           # (1,H,W)
            den = np.maximum(den, 1e-12)
            Wj  = ex / den                                    # (J,H,W)
        elif mode_l in ("exp", "gated-exp", "exp-gated"):
            Wj  = np.exp(logits) * np.isfinite(K)             # (J,H,W)
        else:
            m   = np.max(logits, axis=0, keepdims=True)
            ex  = np.exp(logits - m) * np.isfinite(K)
            den = np.sum(ex, axis=0, keepdims=True)
            den = np.maximum(den, 1e-12)
            Wj  = ex / den

        if not (lo <= 0.0 and hi >= 1.0):
            Wj = np.clip(Wj, lo, hi)

        # Store per-edge β and KL fields
        for s, j_id in enumerate(sender_id):
            wm = Wj[s]                               # (H,W)
            if masks[s] is not None:
                wm = np.where(masks[s], wm, 0.0)
            wm = np.asarray(wm, np.float32, order="C")
            if wm.ndim != 2:
                wm = wm.reshape(H, W, -1).sum(axis=-1)
            if wm.shape != (H, W):
                raise ValueError(f"β_q map shape {wm.shape} not (H,W)=({H},{W}) for (i={i_id}, j={j_id})")

            beta_q[(i_id, int(j_id))] = wm
            kl_q[(i_id, int(j_id))]   = KL_maps_grad[s].astype(np.float32, copy=False)

    return beta_q, kl_q


def build_beta_p_belief_from_q_spatial(
    ctx,
    agents,
    *,
    kappa: float,
    mode: str = "softmax",
    lo: float = 0.0,
    hi: float = 1.0,
    eps: float = 1e-6,
    tau: float = 1e-6,
):
    """
    β_p(x,y) from KL( Φ_i[Ω^q_ij q_j] || p_i ) in P_i, per pixel.

    Returns:
      beta_p: dict[(i_id, j_id)] -> (H,W) float32
      kl_p:   dict[(i_id, j_id)] -> (H,W) float32  (KL per pixel; 0 outside overlap)
    """
    import numpy as np
    from core.transport_cache import Omega, Phi
    from core.numerical_utils import sanitize_sigma, kl_gaussian, push_gaussian
    from utils import _joint_mask

    tiny = 1e-12
    kappa = float(max(kappa, tiny))
    lo = float(lo); hi = float(hi)

    beta_p, kl_p = {}, {}
    ids = _ids_of(agents)

    for i_idx, ai in enumerate(agents):
        i_id = int(ids[i_idx])

        mu_pi = np.asarray(ai.mu_p_field, np.float32)           # (H,W,Kp)
        S_pi  = sanitize_sigma(np.asarray(ai.sigma_p_field, np.float64))  # (H,W,Kp,Kp)
        Phi_i = Phi(ctx, ai, kind="q_to_p")                     # (H,W,Kp,Kq)
        H, W  = mu_pi.shape[:2]

        logits_list = []   # (J,H,W)
        js = []            # sender ids
        mask_list = []     # (H,W) bool
        kl_grad_list = []  # (J,H,W) KL with 0 outside overlap

        for j_idx, aj in enumerate(agents):
            if j_idx == i_idx:
                continue
            j_id = int(ids[j_idx])

            overlap = _joint_mask(ai, aj, tau=tau, as_vector=False)  # (H,W) bool
            if not np.any(overlap):
                continue

            Om_q  = Omega(ctx, ai, aj, which="q")
            mu_qj = np.asarray(aj.mu_q_field, np.float32)
            S_qj  = sanitize_sigma(np.asarray(aj.sigma_q_field, np.float64))
            mu_qj_t, S_qj_t, _ = push_gaussian(
                mu_qj, S_qj, Om_q, eps=eps, return_inv=True, assume_orthogonal=False
            )

            mu_hat_p = np.einsum("...pq,...q->...p",  Phi_i, mu_qj_t, optimize=True)            # (H,W,Kp)
            S_hat_p  = np.einsum("...pq,...qr,...sr->...ps", Phi_i, S_qj_t, Phi_i, optimize=True) # (H,W,Kp,Kp)
            S_hat_p  = sanitize_sigma(S_hat_p).astype(np.float64, copy=False)

            KLpx = kl_gaussian(mu_hat_p, S_hat_p, mu_pi, S_pi)   # expect (H,W)
            KLpx = np.asarray(KLpx, np.float64)
            if KLpx.shape[:2] != (H, W):
                raise ValueError(f"KLpx spatial dims {KLpx.shape[:2]} != (H,W)=({H},{W}) for (i={i_id}, j={j_id})")
            if KLpx.ndim > 2:
                KLpx = KLpx.reshape(H, W, -1).sum(axis=-1)

            # logits: -inf outside overlap (excluded)
            logit = -KLpx / kappa
            logit = np.where(overlap, logit, -np.inf)

            logits_list.append(logit)
            mask_list.append(overlap)
            js.append(j_id)
            # KL for gradients: 0 outside overlap
            kl_grad_list.append(np.where(overlap, KLpx, 0.0).astype(np.float32, copy=False))

        if not js:
            continue

        L = np.stack(logits_list, axis=0)    # (M,H,W)
        if L.shape[1:] != (H, W):
            raise ValueError(f"Stacked logits shape {L.shape} wrong; expected (*,{H},{W})")

        overlap_any = np.any(np.stack(mask_list, axis=0), axis=0)  # (H,W) bool

        mode_l = (mode or "softmax").lower()
        if mode_l in ("softmax", "sm", "normexp"):
            Lmax = np.max(L, axis=0)                         # (H,W)
            exps = np.exp(L - Lmax[None, ...])               # (M,H,W)
            exps = np.where(overlap_any[None, ...], exps, 0.0)
            Z = np.sum(exps, axis=0)                         # (H,W)
            Z = np.maximum(Z, tiny)
            Wjx = exps / Z[None, ...]                        # (M,H,W)
        elif mode_l in ("exp", "gated-exp", "exp-gated"):
            Wjx = np.exp(L)                                   # (M,H,W)
            Wjx = np.where(overlap_any[None, ...], Wjx, 0.0)
        else:
            Lmax = np.max(L, axis=0)
            exps = np.exp(L - Lmax[None, ...])
            exps = np.where(overlap_any[None, ...], exps, 0.0)
            Z = np.sum(exps, axis=0)
            Z = np.maximum(Z, tiny)
            Wjx = exps / Z[None, ...]

        if not (lo <= 0.0 and hi >= 1.0):
            Wjx = np.clip(Wjx, lo, hi)

        # Store per-edge fields
        for m, j_id in enumerate(js):
            w_m = Wjx[m]                                      # (H,W)
            if mask_list[m] is not None:
                w_m = np.where(mask_list[m], w_m, 0.0)
            w_m = np.asarray(w_m, np.float32, order="C")
            if w_m.ndim != 2:
                w_m = w_m.reshape(H, W, -1).sum(axis=-1)
            if w_m.shape != (H, W):
                raise ValueError(f"β_p map shape {w_m.shape} not (H,W)=({H},{W}) for (i={i_id}, j={j_id})")

            beta_p[(i_id, int(j_id))] = w_m
            kl_p[(i_id, int(j_id))]   = kl_grad_list[m]

    return beta_p, kl_p


def nograd_build_beta_p_belief_from_q_spatial(
    ctx,
    agents,
    *,
    kappa: float,
    mode: str = "softmax",   # {"softmax","exp"}
    lo: float = 0.0,
    hi: float = 1.0,
    eps: float = 1e-6,
    tau: float = 1e-6,
):
    """
    β_p(x,y): pixelwise weights for edges (i←j) based on:
        KL_px = KL( Φ_i[Ω^q_ij q_j] || p_i )   in P_i, per pixel.

    For each receiver i, and for each pixel (x,y), we compute logits_ij(x,y) = -KL_px/kappa
    across all valid senders j that overlap i at (x,y). We then map logits→weights by:

      - mode="softmax":  w_ij(x,y) = Softmax_j(logits_ij(x,y))
      - mode="exp":      w_ij(x,y) = exp(logits_ij(x,y))  (unnormalized, per-pixel)

    Finally we clamp to [lo, hi] and zero out pixels with no overlap for that edge.

    Returns:
      beta_p: dict mapping (i_id, j_id) -> np.ndarray of shape (H,W), float32.
    """
    import numpy as np

    tiny = 1e-12
    kappa = float(max(kappa, tiny))
    lo = float(lo)
    hi = float(hi)

    beta_p, ids = {}, _ids_of(agents)

    for i_idx, ai in enumerate(agents):
        i_id = int(ids[i_idx])

        # Shapes / receiver fields (in P_i)
        mu_pi = np.asarray(ai.mu_p_field, np.float32)          # (...,Kp)
        S_pi  = sanitize_sigma(np.asarray(ai.sigma_p_field, np.float64))  # (...,Kp,Kp)
        Phi_i = Phi(ctx, ai, kind="q_to_p")                    # (...,Kp,Kq)

        # We'll collect per-sender pixelwise logits for this receiver.
        logits_list = []      # list of (H,W) float64
        js = []               # sender ids (int)
        mask_list = []        # sender overlap masks (H,W) bool

        for j_idx, aj in enumerate(agents):
            if j_idx == i_idx:
                continue
            j_id = int(ids[j_idx])

            # Pixelwise joint support in i's frame
            overlap = _joint_mask(ai, aj, tau=tau, as_vector=False)  # (H,W) bool
            if not np.any(overlap):
                continue

            # Transport sender belief into Q_i via Ω^q_ij
            Om_q  = Omega(ctx, ai, aj, which="q")
            mu_qj = np.asarray(aj.mu_q_field, np.float32)
            S_qj  = sanitize_sigma(np.asarray(aj.sigma_q_field, np.float64))
            mu_qj_t, S_qj_t, _ = push_gaussian(
                mu_qj, S_qj, Om_q, eps=eps, return_inv=True, assume_orthogonal=False
            )

            # Encode into P_i via Φ_i
            # μ_hat_p = Φ μ_q ; Σ_hat_p = Φ Σ_q Φ^T
            mu_hat_p = np.einsum("...pq,...q->...p",  Phi_i, mu_qj_t, optimize=True)
            S_hat_p  = np.einsum("...pq,...qr,...sr->...ps", Phi_i, S_qj_t, Phi_i, optimize=True)
            S_hat_p  = sanitize_sigma(S_hat_p).astype(np.float64, copy=False)

            # Pixelwise KL in P_i
            KLpx = kl_gaussian(mu_hat_p, S_hat_p, mu_pi, S_pi)     # (H,W), float64
           
            # Build logits; keep values only where overlapped, else -inf (excluded from softmax)
            logit = -KLpx / kappa
            logit = np.where(overlap, logit, -np.inf)

            logits_list.append(logit)
            mask_list.append(overlap)
            js.append(j_id)

        if not js:
            continue

        # Stack logits for all senders for receiver i: (M,H,W)
        L = np.stack(logits_list, axis=0)    # float64
        M, H, W = L.shape

        # Any-pixel-overlap mask across senders: (H,W)
        overlap_any = np.clip(np.sum(np.stack(mask_list, axis=0), axis=0), 0, 1).astype(bool)

        if mode.lower() in ("softmax", "sm", "normexp"):
            # Stable per-pixel softmax along sender axis
            Lmax = np.max(L, axis=0)                                     # (H,W)
            exps = np.exp(L - Lmax[None, ...])                           # (M,H,W)
            # Zero out pixels that have no valid sender
            exps = np.where(overlap_any[None, ...], exps, 0.0)
            Z = np.sum(exps, axis=0)                                     # (H,W)
            Z = np.maximum(Z, tiny)
            Wjx = exps / Z[None, ...]                                    # (M,H,W)
        elif mode.lower() in ("exp", "gated-exp", "exp-gated"):
            # Unnormalized gated exponentials; clamp later
            Wjx = np.exp(L)                                              # (M,H,W)
            Wjx = np.where(overlap_any[None, ...], Wjx, 0.0)
        else:
            # Fallback to softmax if unknown mode
            Lmax = np.max(L, axis=0)
            exps = np.exp(L - Lmax[None, ...])
            exps = np.where(overlap_any[None, ...], exps, 0.0)
            Z = np.sum(exps, axis=0)
            Z = np.maximum(Z, tiny)
            Wjx = exps / Z[None, ...]

        # Clamp to [lo, hi]
        if not (lo <= 0.0 and hi >= 1.0):
            Wjx = np.clip(Wjx, lo, hi)

        # Store per-edge fields
        for m, j_id in enumerate(js):
            # Ensure zeros outside j's own overlap (not just overlap_any)
            w_m = Wjx[m]
            if mask_list[m] is not None:
                w_m = np.where(mask_list[m], w_m, 0.0)
            beta_p[(i_id, int(j_id))] = np.asarray(w_m, np.float32, order="C")

    return beta_p

