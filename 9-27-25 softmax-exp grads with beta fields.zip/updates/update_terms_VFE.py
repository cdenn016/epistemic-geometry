# -*- coding: utf-8 -*-
"""
Created on Mon Sep  8 17:40:08 2025

@author: chris and christine
"""

# updates/update_terms_vfe.py
from __future__ import annotations
import numpy as np
from utils import _check_finite 
from runtime_context import ensure_theta, cfg_get





def apply_theta_updates(runtime_ctx, dtheta_or_parts):
    """
    Apply global θ update.
    Accepts either a single (dW, db, dS) tuple, or an iterable of such tuples
    (with None entries allowed). Handles:
      - aggregation (sum) + optional global clipping
      - Fisher preconditioning (Sxx + λI)^-1 for dW, db/=N
      - EMA and row/global clipping
      - log-σ² update normalized by N
    """
    import numpy as np

    theta = getattr(runtime_ctx, "theta", None)
    if theta is None:
        return

    # -------- accept single tuple or iterable-of-tuples
    if isinstance(dtheta_or_parts, tuple):
        parts = [dtheta_or_parts]
    else:
        parts = list(dtheta_or_parts)

    # -------- aggregate (skip None)
    dW_sum = db_sum = None
    dS_sum = 0.0
    any_part = False
    for part in parts:
        if part is None:
            continue
        dW, db, dS = part
        if dW_sum is None:
            dW_sum = np.array(dW, np.float32)
            db_sum = np.array(db, np.float32)
        else:
            dW_sum += dW
            db_sum += db
        dS_sum += float(dS)
        any_part = True

    if not any_part:
        return  # nothing to apply

    # -------- preconditioning + apply (your previous logic, cleaned)
    W, b, sigma2 = theta.W, theta.b, float(theta.sigma2)
    lrW       = float(cfg_get(runtime_ctx,"theta_lr_W",        1e-2))
    lrb       = float(cfg_get(runtime_ctx,"theta_lr_b",        1e-2))
    lrs       = float(cfg_get(runtime_ctx,"theta_lr_sigma2",   1e-2))
    ridge     = float(cfg_get(runtime_ctx,"theta_ridge",       1e-2))
  
    s2_min    = float(cfg_get(runtime_ctx,"sigma2_min",  1e-3))
    s2_max    = float(cfg_get(runtime_ctx,"sigma2_max",  1e+2))

    # Fisher stats (per-step, from children)
    Sxx, Sx, N, K = _theta_stats_from_children(runtime_ctx)
    if Sxx is not None and K is not None and N > 0:
        I = np.eye(K, dtype=np.float32)
        Sxx_r = (Sxx + ridge * I).astype(np.float32)
        Sxx_r = 0.5 * (Sxx_r + Sxx_r.T)  # symmetry guard
        try:
            X = np.linalg.solve(Sxx_r, np.asarray(dW_sum, np.float32).T)
            dW_sum = X.T
        except np.linalg.LinAlgError:
            print("[theta apply] LINALG ERROR!!!\n\n\n\n\n")
            denom = np.clip(np.diag(Sxx_r), 1e-6, np.inf)
            dW_sum = (np.asarray(dW_sum, np.float32) / denom[None, :]).astype(np.float32)
        db_sum = (np.asarray(db_sum, np.float32) / max(float(N), 1.0)).astype(np.float32)


    # SGD/EMA update
    W = W - lrW * dW_sum
    b = b - lrb * db_sum
  
    # σ^2 update in log-space, normalized by N and scaled by σ^2 (chain rule)
    s_log  = float(np.log(max(sigma2, s2_min)))
    ds     = float(-lrs * (dS_sum / max(float(N), 1.0)) * max(sigma2, s2_min))
    s_log  = float(np.clip(s_log + ds, np.log(s2_min), np.log(s2_max)))
    sigma2 = float(np.exp(s_log))

    # write back
    runtime_ctx.theta.W = W.astype(np.float32, copy=False)
    runtime_ctx.theta.b = b.astype(np.float32, copy=False)
    runtime_ctx.theta.sigma2 = sigma2

    # optional debug print
    if bool(cfg_get(runtime_ctx, "theta_debug_apply", True)):
        step = int(getattr(runtime_ctx, "global_step", 0))
        print(
            f"[θ-APPLY] step={step}  \n"
            f"|ΔW| = {np.linalg.norm(dW_sum):.2e}\n"
            f"|Δb| = {np.linalg.norm(db_sum):.2e}\n"
            f"Δσ2  = {dS_sum:.2e}\n"
            f"|W|_F= {np.linalg.norm(W):.2e} σ2={sigma2:.2e}\n\n",
            flush=True
        )



def theta_gradients_for_agent(agent, ctx):
    """
    Compute per-agent θ gradients for the VFE term.

    Returns
    -------
    tuple | None
        (dW, db, dSigma2) scaled by vfe_weight, or None if VFE is disabled
        or the agent has no observation field
    """
    if not (cfg_get(ctx, "enable_vfe_theta", True)
            and getattr(agent, "observation_field", None) is not None):
        #print("no theta grads\n")
        return None


    try:
        y  = np.asarray(agent.observation_field, np.float32)
        mu = np.asarray(agent.mu_q_field,        np.float32)
        S  = np.asarray(agent.sigma_q_field,     np.float32)
        m  = np.asarray(agent.mask,              np.float32)

        for name, arr in [("y", y), ("mu", mu), ("Sigma", S), ("mask", m)]:
            _check_finite(name, arr)

        D_obs, K_latent = int(y.shape[-1]), int(mu.shape[-1])
        theta = ensure_theta(ctx, D_obs=D_obs, K_latent=K_latent)
        for name, arr in [("theta.W", theta.W), ("theta.b", theta.b)]:
            _check_finite(name, arr)

        s2_min = float(cfg_get(ctx, "sigma2_min", 1e-3))
        if (not np.isfinite(theta.sigma2)) or (theta.sigma2 <= 0.0):
            raise FloatingPointError("[VFEθ] theta.sigma2 invalid (non-finite or ≤ 0)")
        theta_sigma2 = max(theta.sigma2, s2_min)

        out = vfe_theta_grads(y=y, mu=mu, Sigma=S,
                              W=theta.W, b=theta.b,
                              sigma2=theta_sigma2, mask=m)
        if out is None:
            return None

        dW, db, dS = out
        if not np.isfinite(dS):
            dS = 0.0

        w = float(cfg_get(ctx, "vfe_weight", 0.0))
        return ((w * dW).astype(np.float32),
                (w * db).astype(np.float32),
                float(w * dS))
    except Exception as e:
        print(f"[θ] per-agent grads skipped: {type(e).__name__}: {e}")
        return None



def _theta_stats_from_children(ctx):
    """
    Aggregate sufficient stats over current children for preconditioning:
      Sxx = sum m * (Σ_q + μ μ^T)
      Sx  = sum m * μ
      N   = sum m   (per-pixel counts)
    Returns (Sxx, Sx, N, K_latent).
    """
   
    agents = getattr(ctx, "children_latest", None) or []
    
    if not agents:
        print("[THETA STATS] RETURN NONE \n\n\n\n")
        return None, None, 0.0, None

    A0 = agents[0]
    K = int(A0.mu_q_field.shape[-1])
    Sxx = np.zeros((K, K), np.float32)
    Sx  = np.zeros((K,),   np.float32)
    N   = 0.0

    for a in agents:
        m   = np.asarray(a.mask, np.float32)               # (H,W)
        mu  = np.asarray(a.mu_q_field, np.float32)         # (H,W,K)
        Sig = np.asarray(a.sigma_q_field, np.float32)      # (H,W,K,K)

        w = m[..., None]                                   # (H,W,1)
        N += float(np.sum(m))

        # sum μ and (Σ + μμ^T)
        Sx  += np.sum(w * mu, axis=(0,1))
        # batch outer products: (H,W,K,1)*(H,W,1,K) -> (H,W,K,K)
        outer = mu[..., :, None] * mu[..., None, :]
        Sxx  += np.sum(Sig + outer, axis=(0,1)).astype(np.float32)

    return Sxx, Sx, N, K


def vfe_theta_grads(y, mu, Sigma, W, b, sigma2, *, mask=None):
    """
    Euclidean grads wrt theta = {W, b, sigma2} for
        F = E_q[-log p(y|x_q)],  y|x_q ~ N(W x_q + b, sigma2 I)
    Returns summed grads over batch/pixels: (dW, db, d_sigma2).
    All inputs are assumed in the q-fiber.
    """
    import numpy as np

    y     = np.asarray(y,     np.float32)   # (..., D)
    mu    = np.asarray(mu,    np.float32)   # (..., K)
    Sigma = np.asarray(Sigma, np.float32)   # (..., K, K)
    W     = np.asarray(W,     np.float32)   # (D, K)
    b     = np.asarray(b,     np.float32)   # (D,)
    s2    = float(max(sigma2, 1e-12))
    inv_s2 = 1.0 / s2

    # Mask (ones if None) with convenient shapes
    if mask is None:
        m  = 1.0
        mm = 1.0          # (..., 1)
        mS = 1.0          # (..., 1, 1)
        N  = int(np.prod(y.shape[:-1]))  # number of examples
    else:
        m  = np.asarray(mask, np.float32)                 # (...)
        mm = m[..., None]                                 # (..., 1)
        mS = m[..., None, None]                           # (..., 1, 1)
        N  = int(np.sum(m))                               # active examples

    # Residuals
    r = (mu @ W.T) + b - y                                # (..., D)
    r_masked = r * mm                                     # (..., D)

    # dW: sum (r mu^T + W Σ)
    dW = np.einsum("...d,...k->dk", r_masked, mu, optimize=True)  # (D, K)
    Sigma_sum = np.sum(Sigma * mS, axis=tuple(range(Sigma.ndim-2)))  # (K, K)
    dW += W @ Sigma_sum
    dW *= inv_s2

    # db: sum r
    db = np.sum(r_masked, axis=tuple(range(r_masked.ndim-1))) * inv_s2  # (D,)

    # d sigma2:
    # num = Σ_examples [ r^2 + tr(W Σ W^T) ]
    r2   = np.sum((r * r) * mm, axis=-1)                                 # (...)
    WT_W = (W.T @ W).astype(np.float32)                                  # (K, K)
    trm  = np.einsum("...ij,ij->...", Sigma * mS, WT_W, optimize=True)   # (...)
    num  = float(np.sum(r2 + trm))
    D    = int(y.shape[-1])
    d_sigma2 = 0.5 * ( (D * max(N, 0)) / s2 - (num / (s2 * s2)) )        # scalar

    return dW.astype(np.float32), db.astype(np.float32), float(d_sigma2)

