# -*- coding: utf-8 -*-
"""
Created on Sun Sep 14 14:24:12 2025

@author: chris and christine
"""

import numpy as np
import core.config as config
from core.numerical_utils import safe_inv, sanitize_sigma, push_gaussian, safe_omega_inv
from typing import Any


# =========================
# Basic, stable miscellany
# =========================


def _aid(a: Any) -> int:
    """Stable agent id (required)."""
    aid = getattr(a, "id", None)
    if aid is None:
        raise ValueError("[transport_cache] agent is missing a stable `id`")
    return int(aid)


def mean_norm(arr):
    if arr is None:
        return np.nan
    x = np.asarray(arr)
    if x.ndim >= 3:
        return float(np.nanmean(np.linalg.norm(x, axis=-1)))
    if x.ndim == 2:
        return float(np.nanmean(np.abs(x)))
    return np.nan

def _check_finite(name, x):
    if not np.all(np.isfinite(x)):
        n_nan = int(np.isnan(x).sum())
        n_inf = int(np.isinf(x).sum())
        raise FloatingPointError(f"[vfe_mu_sigma_grads] {name} has non-finite values "
                                 f"(nan={n_nan}, inf={n_inf}).")

# =========================
#         Masks
# =========================




# --- MASKS ---------------------------------------------------------------

def make_soft_mask(
    center: tuple[int, ...],
    radius: float,
    domain_size: tuple[int, ...],
    *,
    cutoff: float | None = None,
    dtype: np.dtype | None = None,
    return_bool: bool = False,
) -> np.ndarray | tuple[np.ndarray, np.ndarray]:
    """
    Unified soft (Gaussian) mask on a periodic domain with optional cutoff.
    - If return_bool=True, also returns a boolean mask using the same cutoff.
    """
    dtype = dtype if dtype is not None else getattr(config, 'dtype', np.float64)
    cutoff = float(getattr(config, 'support_tau', 1e-3) if cutoff is None else cutoff)

    grids = np.ogrid[tuple(slice(0, s) for s in domain_size)]
    dist2 = 0.0
    for d, size in enumerate(domain_size):
        delta = np.abs(grids[d] - center[d])
        delta = np.minimum(delta, size - delta)
        dist2 = dist2 + delta * delta

    r = max(radius, np.finfo(float).eps)
    m = np.exp(-(np.sqrt(dist2) / r) ** 2).astype(dtype)

    if cutoff > 0.0:
        m[m < cutoff] = 0.0
    m = m.astype(np.float32, copy=False)
    if return_bool:
        return m, (m > 0).astype(bool)
    return m


def _joint_mask(a, b, *, tau: float, as_vector: bool = True):
    ma = mask_hw(a, tau=tau, mode="bool2")  # (H,W) bool
    mb = mask_hw(b, tau=tau, mode="bool2")  # (H,W) bool
    if ma.shape != mb.shape:
        raise ValueError(f"_joint_mask: shapes differ: {ma.shape} vs {mb.shape}")
    m = ma & mb
    return (m[..., None].astype(np.float32, copy=False)) if as_vector else m


def mask_hw(x, *, tau: float, mode: str = "float3"):
    """
    Get a standardized mask from x or x.mask.

    mode:
      - "bool2"  -> (H,W) bool
      - "float3" -> (H,W,1) float32  (good for broadcasting with (H,W,A))
      - "vec"    -> (H*W,) bool
    """
    m = getattr(x, "mask", x)
    m = np.asarray(m, np.float32)
    if m.ndim >= 3:
        m = m[..., 0]
    if m.ndim == 0:
        m = np.array([[float(m)]], dtype=np.float32)

    # do NOT hide NaNs
    if not np.isfinite(m).all():
        n_bad = int(np.size(m) - np.isfinite(m).sum())
        raise FloatingPointError(f"mask_hw: non-finite values in mask ({n_bad} cells).")

    mb = (m > tau)  # bool, NaNs would have been caught above

    if mode == "bool2":
        return mb
    if mode == "float3":
        return mb.astype(np.float32, copy=False)[..., None]
    if mode == "vec":
        return mb.ravel()

    raise ValueError(f"mask_hw: unknown mode={mode!r}")



def push_neighbor_stats(agent_j, sigma_key: str, Omega_ij: np.ndarray, eps: float):
    """
    Returns (mu_j_t, Sigma_j_t, Sigma_j_t_inv) in agent-i frame.
    Fast-path tries inverse-push of precision; fallback pushes covariance.
    """
    mu_j = np.asarray(getattr(agent_j, sigma_key.replace("sigma", "mu")), np.float32)

    inv_key = sigma_key.replace("_field", "_inv")
    S_inv = getattr(agent_j, inv_key, None)

    # Try inverse-push of precision first
    if S_inv is not None:
        S_inv = np.asarray(S_inv, np.float32)
        if S_inv.size and np.all(np.isfinite(S_inv)):
            Oinv   = safe_omega_inv(Omega_ij, eps=1e-6)
            Oinv_T = np.swapaxes(Oinv, -1, -2)
            S_inv_t = np.einsum("...ik,...kl,...jl->...ij", Oinv_T, S_inv, Oinv, optimize=True)

            # Build Σ_j→i once (stable): (S_inv_t)^{-1}
            Sigma_t = safe_inv(sanitize_sigma(S_inv_t), eps=max(eps, 1e-12))

            mu_t = np.einsum("...ij,...j->...i", Omega_ij, mu_j, optimize=True)
            return mu_t.astype(np.float32, copy=False), Sigma_t.astype(np.float32, copy=False), S_inv_t.astype(np.float32, copy=False)

    # Fallback: push covariance then invert once
    Sigma_j = sanitize_sigma(np.asarray(getattr(agent_j, sigma_key), np.float32), eps=eps)
    mu_t, Sigma_t, Sigma_t_inv = push_gaussian(
        mu=mu_j, Sigma=Sigma_j, M=Omega_ij, eps=eps,
        return_inv=True, assume_orthogonal=True, sanitize_input=False
    )
    return mu_t.astype(np.float32, copy=False), Sigma_t.astype(np.float32, copy=False), Sigma_t_inv.astype(np.float32, copy=False)




def zero_all_gradients(agent):
    """
    Zero (and if missing, create) all gradient buffers,
    keeping legacy aliases in sync and ensuring arrays are writeable.
    """
    def ensure_buf(name, like):
        arr = getattr(agent, name, None)
        if arr is None and like is not None:
            arr = np.zeros_like(like)
        elif arr is not None and not arr.flags.writeable:
            arr = np.array(arr, copy=True)
        setattr(agent, name, arr)
        return arr

    # Canonical grads (create from fields if needed)
    g_mu_q   = ensure_buf("grad_mu_q",    getattr(agent, "mu_q_field", None))
    g_sg_q   = ensure_buf("grad_sigma_q", getattr(agent, "sigma_q_field", None))
    g_mu_p   = ensure_buf("grad_mu_p",    getattr(agent, "mu_p_field", None))
    g_sg_p   = ensure_buf("grad_sigma_p", getattr(agent, "sigma_p_field", None))
    g_phi    = ensure_buf("grad_phi",       getattr(agent, "phi", None))
    g_phit   = ensure_buf("grad_phi_tilde", getattr(agent, "phi_model", None))
 
    # Keep legacy aliases in sync (as references, not copies)
    if g_mu_q is not None:
        agent.grad_mu_q_field = g_mu_q
    if g_sg_q is not None:
        agent.grad_sigma_q_field = g_sg_q
    if g_mu_p is not None:
        agent.grad_mu_p_field = g_mu_p
    if g_sg_p is not None:
        agent.grad_sigma_p_field = g_sg_p

    # Zero safely
    for arr in (g_mu_q, g_sg_q, g_mu_p, g_sg_p, g_phi, g_phit):
        if isinstance(arr, np.ndarray):
            arr.fill(0)


# =========================
# Regularization & morphism aids
# =========================


def reg_weights(field: str, *, ctx=None, config=None) -> tuple[float, float, float, float]:
    """
    Return (curv_w, fisher_w, mass_w, cpl_w) for the given field ('phi' or 'phi_model').

    Precedence for each weight:
        1) ctx.step_cfg[name]
        2) ctx.config[name]
        3) module-level config.<name>
        4) 0.0
    """
    
    from runtime_context import cfg_get
    
    if field == "phi":
        curv_w   = float(cfg_get(ctx, "curvature_weight", 0))
        fisher_w = float(cfg_get(ctx, "fisher_geometry_weight", 0.0))
        # allow legacy "belief_mass" alias
        mass_w   = float(cfg_get(ctx, "belief_mass", 0.0))
        cpl_w    = float(cfg_get(ctx, "phi_coupling_weight", 0.0))

    elif field == "phi_model":
        curv_w   = float(cfg_get(ctx, "model_curvature_weight", 0.0))
        fisher_w = float(cfg_get(ctx, "fisher_model_geometry_weight", 0.0))
        
        mass_w   = float(cfg_get(ctx, "model_mass", 0.0))
        cpl_w    = float(cfg_get(ctx, "phi_coupling_weight", 0))
    else:
        raise ValueError(f"Invalid field: {field}")
    
    return curv_w, fisher_w, mass_w, cpl_w



# === fiber view =============================================================

def fiber_view(agent, field: str, *, require_generators: bool = False):
    """
    Unified access to a fiber.
    Returns dict:
      {
        "which": "q"|"p",
        "mu":   (H,W,K),
        "Sigma":(H,W,K,K),
        "phi":  (..., d)  # your current storage for this fiber
        "G":    (d,K,K) or None,
        "K":    int
      }
    Accepts legacy attribute spellings transparently and validates shapes.
    """
    which = "q" if field == "phi" else "p"
    H, W = agent.mask.shape

    if which == "q":
        mu   = getattr(agent, "mu_q_field",  None)
        Sig  = getattr(agent, "sigma_q_field", None)
        phi  = getattr(agent, "phi_field",   getattr(agent, "phi", None))
        G    = getattr(agent, "generators_q", getattr(agent, "G_q", None))
    else:
        mu   = getattr(agent, "mu_p_field",  None)
        Sig  = getattr(agent, "sigma_p_field", None)
        phi  = getattr(agent, "phi_model_field", getattr(agent, "phi_model", None))
        G    = getattr(agent, "generators_p", getattr(agent, "G_p", None))

    if mu is None or Sig is None or phi is None:
        raise AttributeError(f"agent missing fields for fiber '{which}'")

    mu  = np.asarray(mu,  np.float32)
    Sig = np.asarray(Sig, np.float32)
    phi = np.asarray(phi, np.float32)

    if mu.shape[:2] != (H, W):
        raise ValueError(f"mu shape {mu.shape} incompatible with mask {(H,W)}")
    if Sig.shape[:2] != (H, W) or Sig.shape[-1] != Sig.shape[-2] or mu.shape[-1] != Sig.shape[-1]:
        raise ValueError(f"Sigma shape {Sig.shape} incompatible with mu {mu.shape}")

    if require_generators and G is None:
        raise AttributeError(f"generators missing for fiber '{which}'")
    G_arr = None if G is None else np.asarray(G, np.float32)

    return {"which": which, "mu": mu, "Sigma": Sig, "phi": phi, "G": G_arr, "K": int(mu.shape[-1])}


# =========================
# Linear algebra helpers
# =========================


def _ensure_q_to_p_shape(X, Kp, Kq):
    """Φ0: q→p must be (Kp, Kq). Auto-transpose if (Kq, Kp)."""
    X = np.asarray(X, np.float32)
    if X.shape == (Kp, Kq): return X
    if X.shape == (Kq, Kp): return X.T
    raise ValueError(f"Φ0 wrong shape {X.shape}; expected {(Kp, Kq)} or {(Kq, Kp)}")

def _ensure_p_to_q_shape(X, Kq, Kp):
    """Φ̃0: p→q must be (Kq, Kp). Auto-transpose if (Kp, Kq)."""
    X = np.asarray(X, np.float32)
    if X.shape == (Kq, Kp): return X
    if X.shape == (Kp, Kq): return X.T
    raise ValueError(f"Φ̃0 wrong shape {X.shape}; expected {(Kq, Kp)} or {(Kp, Kq)}")

def build_c_mapping_q2p(Phi_tilde_0, generators_q, generators_p, eps=1e-8):
    """
    Build linear map C (d_p x d_q) so that Ad_{Φ̃0}(G_q^a) ≈ sum_b C_{ba} G_p^b
    under Frobenius projection onto p-basis.
    """
    d_q, Kq, _ = generators_q.shape
    d_p, Kp, _ = generators_p.shape
    assert Phi_tilde_0.shape[-2:] == (Kq, Kp), "Phi_tilde_0 must be (K_q, K_p)"

    # Gram of p-basis
    Gp = np.zeros((d_p, d_p), dtype=generators_p.dtype)
    for b in range(d_p):
        for c in range(d_p):
            Gp[b, c] = np.tensordot(generators_p[b], generators_p[c])
    Gp += eps * np.eye(d_p, dtype=Gp.dtype)
    Gp_inv = safe_inv(Gp)

    Phi0    = Phi_tilde_0
    Phi0_inv = safe_inv(Phi0, eps=eps)

    C = np.zeros((d_p, d_q), dtype=generators_p.dtype)
    for a in range(d_q):
        H_a = np.einsum("ik,kl,lj->ij", Phi0, generators_q[a], Phi0_inv)
        h = np.array([np.tensordot(generators_p[b], H_a) for b in range(d_p)], dtype=H_a.dtype)
        C[:, a] = Gp_inv @ h
    return C



#===================================
# 
#         MU/SIGMA GRADIENT ACCUMULATE
# 
#=====================================

def _build_id_index_map(agents):
    """
    Map stable agent id -> index in `agents` list.
    Returns None as a sentinel when ids are exactly [0..N-1] in order.
    """
    # Fast-path: ids equal list indices
    for idx, a in enumerate(agents):
        aid = _aid(a)
        if aid is None or int(aid) != idx:
            break
    else:
        return None  # identity mapping

    # General path
    m = {}
    for idx, a in enumerate(agents):
        aid = _aid(a)
        if aid is None:
            raise ValueError("All agents must have a stable `id` when ids != indices.")
        aid = int(aid)
        if aid in m:
            raise ValueError(f"Duplicate agent id detected: {aid}")
        m[aid] = idx
    return m


def iter_overlapping_neighbors(agent_i, agents, *, support_eps: float, symmetric: bool = True):
    """
    Yield (j_idx, agent_j, overlap_mask_bool(H,W)) for neighbors of agent_i whose masks overlap.
    If symmetric=True, only yield pairs with i_id < j_id (undirected edges once).
    """
    nb_list = getattr(agent_i, "neighbors", None) or ()
    # generator fn: early-stop is fine (becomes StopIteration)
    if not nb_list:
        return

    id_index = _build_id_index_map(agents)
    n_agents = len(agents)

    try:
        i_id = int(getattr(agent_i, "id"))
    except Exception:
        raise ValueError("agent_i must have an integer-like `id`.")

    mask_i = mask_hw(agent_i, tau=support_eps, mode="bool2")  # (H,W) bool

    for nb in nb_list:
        j_raw = nb.get("id", None)
        if j_raw is None:
            continue
        try:
            j_id = int(j_raw)
        except Exception:
            continue

        if symmetric and not (i_id < j_id):
            continue
        if j_id == i_id:
            continue  # skip self

        # Resolve j index
        if id_index is None:
            if not (0 <= j_id < n_agents):
                continue
            j_idx = j_id
        else:
            j_idx = id_index.get(j_id)
            if j_idx is None:
                continue

        agent_j = agents[j_idx]
        mask_j = mask_hw(agent_j, tau=support_eps, mode="bool2")
        overlap = (mask_i & mask_j)
        if not overlap.any():
            continue

        yield j_idx, agent_j, overlap


# =========================
# Logging
# =========================

def log_phi_grad_like(aid, field, tag, arr):
    """Compact sign/mean/|g| logging for φ/φ̃ terms."""
    if arr is None: return
    spatial_axes = tuple(range(arr.ndim - 1))
    g_mean = np.mean(arr, axis=spatial_axes)
    sign = "".join("+" if x > 0 else "-" if x < 0 else "0" for x in g_mean.tolist())
    g_abs_mean = float(np.mean(np.abs(arr)))
    print(f"[PHI] field={field} ai={aid} term={tag} "
          f"sign={sign} mean={np.array2string(g_mean, precision=3, suppress_small=True)} "
          f"|g|_mean={g_abs_mean:.3e}", flush=True)


def get_neighbors(agent_i, agents, *, dedup=True, exclude_self=True):
    """
    Resolve agent_i.neighbors -> list[Agent].
    Supports neighbors as dicts with 'id' or raw ints.
    Works with `agents` as a list (id taken from agent.id or index)
    or as a dict keyed by id.
    """
    raw = getattr(agent_i, "neighbors", []) or []

    # Build lookup once
    if isinstance(agents, dict):
        lookup = {int(k): v for k, v in agents.items()}
    else:
        lookup = {int(getattr(a, "id", i)): a for i, a in enumerate(agents)}

    out, seen = [], set()
    self_id = int(getattr(agent_i, "id", -1))

    for nb in raw:
        # accept {"id": ...} or int id
        try:
            j = int(nb["id"]) if isinstance(nb, dict) else int(nb)
        except Exception:
            continue

        if exclude_self and j == self_id:
            continue
        if dedup and j in seen:
            continue

        a = lookup.get(j)
        if a is not None:
            out.append(a)
            if dedup:
                seen.add(j)

    return out






