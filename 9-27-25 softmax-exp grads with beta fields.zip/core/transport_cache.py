
from __future__ import annotations
from typing import Any, Iterable, Sequence
import numpy as np

# Your existing utilities
from core.omega import exp_lie_algebra_irrep, retract_phi_principal
from core.numerical_utils import safe_omega_inv
from joblib import Parallel, delayed
import hashlib
from core.get_generators import get_generators



"""
Cache Policy — Rule of One
1) One cache hub: runtime_ctx.cache (cleared once per step).
2) One facade to read/write: this file (E_grid, Omega, Jinv_grid, Phi, Phi_tilde, Lambda_*).
3) One warm point per step: ensure_dirty(...) — nowhere else.
Consumers must never pre-warm; they just call the facade.
"""



def _get_phi(agent: Any, which: str) -> np.ndarray:
    if which == "q":
        phi = getattr(agent, "phi", None)
    else:
        phi = getattr(agent, "phi_model", None)
    if phi is None:
        raise ValueError(f"[transport_cache] phi field ({which}) missing")
    return phi


def orthogonalize_intertwiner(Phi0: np.ndarray) -> np.ndarray:
    """
    If Phi0 is square, project to the nearest orthogonal matrix via polar decomposition.
    For rectangular maps, returns Phi0 unchanged.
    """
    Kp, Kq = Phi0.shape
    if Kp != Kq:
        return Phi0
    U, _, Vt = np.linalg.svd(Phi0.astype(np.float64, copy=False), full_matrices=False)
    return (U @ Vt).astype(Phi0.dtype, copy=False)





# ---------------------------------------------------------------------------
#                              Caches
# ---------------------------------------------------------------------------
# runtime_context.py (or wherever ensure_global_A lives)


def ensure_global_A(ctx, shape_hw, *, init_scale=0.0, dtype=np.float32):
    """
    Ensure a global gauge field A with shape (H, W, 2, 3):
      - axis -2: spatial direction (0 -> x, 1 -> y)
      - axis -1: so(3) components (3)
    Back-compat: if an older (H,W,3) array is found, expand to (H,W,2,3) with zeros for Ay.
    """
    if not hasattr(ctx, "fields"):
        raise RuntimeError("ctx.fields missing; update RuntimeCtx to include a fields dict.")
    H, W = int(shape_hw[0]), int(shape_hw[1])

    A = ctx.fields.get("A", None)
    if A is not None:
        A = np.asarray(A)
        if A.shape == (H, W, 2, 3):
            ctx.fields["A"] = A.astype(dtype, copy=False)
            return ctx.fields["A"]
        if A.shape == (H, W, 3):
            # upgrade: interpret as A_x, set A_y=0
            A_up = np.zeros((H, W, 2, 3), dtype=dtype)
            A_up[..., 0, :] = A.astype(dtype, copy=False)
            ctx.fields["A"] = A_up
            return ctx.fields["A"]
        # shape mismatch (new grid size) -> reinit
        ctx.fields["A"] = None

    if init_scale and init_scale > 0.0:
        rng = np.random.default_rng(0)
        A = rng.normal(0.0, init_scale, size=(H, W, 2, 3)).astype(dtype)
    else:
        A = np.zeros((H, W, 2, 3), dtype=dtype)
    ctx.fields["A"] = A
    return ctx.fields["A"]




# --- replace expA_q with this ---
def expA_q(ctx, agent):
    """
    Exponentiate the global A-connection in the agent's q-representation.

    Returns
    -------
    If A is spatial (H,W,2,3):  (H, W, 2, Kq, Kq)  split geometry [x,y]
    If A is a single 3-vector:  (Kq, Kq)
    """
    from runtime_context import cfg_get

    if agent is None:
        raise ValueError("expA_q: `agent` must be provided")
    if getattr(ctx, "cache", None) is None:
        raise RuntimeError("expA_q: ctx.cache is missing")

    C         = ctx.cache
    step_tag  = int(getattr(ctx, "global_step", -1))
    max_norm  = float(cfg_get(ctx, "exp_clip_max_norm", 1e4))

    # --- representation check/signature
    Gq = get_generators(agent, "q")
    if not (isinstance(Gq, np.ndarray) and Gq.ndim == 3 and Gq.shape[0] == 3 and Gq.shape[1] == Gq.shape[2]):
        raise ValueError(f"expA_q: generators_q must be (3,Kq,Kq); got {None if Gq is None else Gq.shape}")
    Gq   = np.asarray(Gq, np.float32, order="C")
    
    gsig = stable_sig(Gq)
    
    A = getattr(ctx, "fields", {}).get("A", None)
    if A is None:
        raise RuntimeError("Global A not initialized. Call ensure_global_A(...) first.")
    A = np.asarray(A, dtype=np.float32)

    # ---- scalar vector case (3,)
    if A.ndim == 1:
        if A.shape != (3,):
            raise ValueError(f"expA_q: A must be (3,) or (H,W,2,3); got {A.shape}")
        key = ("expA_q_scalar", step_tag, gsig)
        U = C.get("exp", key)
        if U is None:
            a = retract_phi_principal(A, margin=1e-6, use_float64=False).astype(np.float32, copy=False)
            U = exp_lie_algebra_irrep(a, Gq, max_norm=max_norm)
            if not np.all(np.isfinite(U)):
                raise FloatingPointError("expA_q produced non-finite values")
            C.put("exp", key, np.asarray(U, np.float32, order="C"))
        return U

    # ---- spatial split case (H,W,2,3)
    if not (A.ndim == 4 and A.shape[-2:] == (2, 3)):
        raise ValueError(f"expA_q: A must be (H,W,2,3); got {A.shape}")

    H, W = int(A.shape[0]), int(A.shape[1])
    key  = ("expA_q_split", step_tag, gsig, (H, W))

    U = C.get("exp", key)
    if U is not None:
        return U

    # sanitize per-axis then exponentiate
    Axy = retract_phi_principal(A, margin=1e-6, use_float64=False).astype(np.float32, copy=False)
    Ax, Ay = Axy[..., 0, :], Axy[..., 1, :]

    Ux = exp_lie_algebra_irrep(Ax, Gq, max_norm=max_norm)  # (H,W,Kq,Kq)
    Uy = exp_lie_algebra_irrep(Ay, Gq, max_norm=max_norm)  # (H,W,Kq,Kq)

    if not (np.isfinite(Ux).all() and np.isfinite(Uy).all()):
        raise FloatingPointError("expA_q: non-finite Ux/Uy")

    U = np.asarray(np.stack([Ux, Uy], axis=-3), dtype=np.float32, order="C")  # (H,W,2,Kq,Kq)
    C.put("exp", key, U)
    return U



# --- replace expA_p with this (same structure) ---
def expA_p(ctx, agent):
    
    from runtime_context import cfg_get
    
    if agent is None:
        raise ValueError("expA_p: `agent` must be provided")
    C = ctx.cache
    step_tag = int(getattr(ctx, "global_step", -1))
    
    Gp = get_generators(agent, "p")
    if not (isinstance(Gp, np.ndarray) and Gp.ndim == 3 and Gp.shape[0] == 3 and Gp.shape[1] == Gp.shape[2]):
        raise ValueError(f"expA_p: generators_p must be (3,Kp,Kp); got {None if Gp is None else Gp.shape}")
    Gp = Gp.astype(np.float32, copy=False)
    max_norm = float(cfg_get(ctx, "exp_clip_max_norm", 1e4))

    gsig = stable_sig(Gp)

    A = getattr(ctx, "fields", {}).get("A", None)
    if A is None:
        raise RuntimeError("Global A not initialized. Call ensure_global_A(...) first.")
    A = np.asarray(A, dtype=np.float32)

    if A.ndim == 1:
        if A.shape[0] != 3:
            raise ValueError(f"expA_p: A must be (3,) or (H,W,2,3); got {A.shape}")
        key = ("expA_p_scalar", step_tag, gsig)
        U = C.get("exp", key)
        if U is None:
            A1 = retract_phi_principal(A, margin=1e-6, use_float64=False).astype(np.float32, copy=False)
            U = exp_lie_algebra_irrep(A1, Gp, max_norm=max_norm)
            if not np.all(np.isfinite(U)):
                raise FloatingPointError("expA_p produced non-finite values")
            C.put("exp", key, U.astype(np.float32, copy=False))
        return U

    if not (A.ndim == 4 and A.shape[-2:] == (2, 3)):
        raise ValueError(f"expA_p: A must be (H,W,2,3); got {A.shape}")

    H, W = int(A.shape[0]), int(A.shape[1])
    key = ("expA_p_split", step_tag, gsig, (H, W))

    U = C.get("exp", key)
    if U is not None:
        return U

    Ax = retract_phi_principal(A[..., 0, :], margin=1e-6,  use_float64=False).astype(np.float32, copy=False)
    Ay = retract_phi_principal(A[..., 1, :], margin=1e-6, use_float64=False).astype(np.float32, copy=False)

    Ux = exp_lie_algebra_irrep(Ax, Gp, max_norm=max_norm)  # (H,W,Kp,Kp)
    Uy = exp_lie_algebra_irrep(Ay, Gp, max_norm=max_norm)

    if not (np.isfinite(Ux).all() and np.isfinite(Uy).all()):
        raise FloatingPointError("expA_p: non-finite Ux/Uy")

    U = np.stack([Ux, Uy], axis=-3)  # (H,W,2,Kp,Kp)
    C.put("exp", key, U.astype(np.float32, copy=False))
    return U




def E_grid(ctx, agent, which: str = "q") -> np.ndarray:
    """
    Frame map E = exp(phi · G) (optionally composed with global A).
    Returns (H,W,K,K) or (K,K) depending on phi shape.
    """
    import numpy as np
    from runtime_context import cfg_get
    from utils import _aid
    
    if getattr(ctx, "cache", None) is None:
        raise RuntimeError("E_grid: ctx.cache missing")

    C        = ctx.cache
    step_tag = int(getattr(ctx, "global_step", -1))

    # --- read knobs robustly (no hard dependency on ctx.step_cfg)
    use_A       = bool(cfg_get(ctx, "use_global_A", False))
    compose_ord = cfg_get(ctx, "A_compose_order", "yx")          # whatever your _compose supports
    th_small    = float(cfg_get(ctx, "phi_small_threshold", 1e-3))
    max_norm    = float(cfg_get(ctx, "exp_clip_max_norm",   1e4))

    # --- inputs
    phi = _get_phi(agent, which)                     # (..., 3)
    G   = get_generators(agent, which)               # (3,K,K)
    G32 = np.asarray(G, np.float32, order="C")
    if not (G32.ndim == 3 and G32.shape[0] == 3 and G32.shape[1] == G32.shape[2]):
        raise ValueError(f"E_grid[{which}]: generators must be (3,K,K); got {G32.shape}")
    K = int(G32.shape[1])

    # --- cache key pieces (stable, shape-aware)
    gsig   = stable_sig(("G", G32))
    phisig = stable_sig(("phi", np.asarray(phi, np.float32, order="C")))
    cfgsig = stable_sig(("useA", use_A), ("ord", compose_ord),
                        ("thr", th_small), ("clip", max_norm))
 
    key = ("E_grid", step_tag, _aid(agent), which, gsig, phisig, cfgsig) 
    E_cached = C.get("exp", key)
    if E_cached is not None:
        return E_cached

    # --- sanitize phi once
    phi32 = retract_phi_principal(np.asarray(phi, np.float32, order="C"),
                                  margin=1e-6, use_float64=False)
    # --- small-angle fast path (use max-norm criterion)
    if phi32.shape[-1] == 3:
        th = np.linalg.norm(phi32, axis=-1)
        if float(np.max(th)) < th_small:
            E = np.broadcast_to(np.eye(K, dtype=np.float32), phi32.shape[:-1] + (K, K)).copy()
            if use_A:
                U_geom = expA_q(ctx, agent) if which == "q" else expA_p(ctx, agent)
                U_geom = _compose_geom_if_split(U_geom, order=compose_ord)  # -> (...,K,K)
                E = U_geom @ E
            C.put("exp", key, E)
            return E

    # --- main path
    U_frame = exp_lie_algebra_irrep(phi32, G32, max_norm=max_norm).astype(np.float32, copy=False)
    E = U_frame
    if use_A:
        U_geom = expA_q(ctx, agent) if which == "q" else expA_p(ctx, agent)
        U_geom = _compose_geom_if_split(U_geom, order=compose_ord)
        E = U_geom @ U_frame

    if not np.all(np.isfinite(E)):
        raise FloatingPointError("E_grid produced non-finite matrices")

    E = np.asarray(E, np.float32, order="C")
    C.put("exp", key, E)
    return E




def _compose_geom_if_split(U_geom: np.ndarray, order: str = "yx") -> np.ndarray:
    """
    Accepts either (K,K)/(H,W,K,K) or split (H,W,2,K,K) geometry; returns (K,K)/(H,W,K,K).
    """
    U_geom = np.asarray(U_geom, np.float32)
    if U_geom.ndim >= 4 and U_geom.shape[-3] == 2:
        Ugx = U_geom[..., 0, :, :]
        Ugy = U_geom[..., 1, :, :]
        return (Ugy @ Ugx) if (order != "xy") else (Ugx @ Ugy)
    return U_geom



def Omega(ctx: Any, ai: Any, aj: Any, which: str = "q") -> np.ndarray:
    """
    Neighbor transport Ω_{ij} with optional freeze modes.

    config.freeze_omega_mode:
      - "none"     : default behavior (cached per step & φ)
      - "identity" : return per-pixel identity (shape from `ai`)
    """
    import numpy as np
    from runtime_context import cfg_get
    from utils import _aid
    
    if getattr(ctx, "cache", None) is None:
        raise RuntimeError("Omega: ctx.cache missing")
    C        = ctx.cache
    step_tag = int(getattr(ctx, "global_step", -1))
    mode     = str(cfg_get(ctx, "freeze_omega_mode", "none")).lower()

    # ---------- IDENTITY mode ----------
    if mode == "identity":
        # Use K from ai; require aj to match (otherwise identity isn't defined)
        Gi = get_generators(ai, which)
        Gj = get_generators(aj, which)
        Gi32 = np.asarray(Gi, np.float32, order="C")
        Gj32 = np.asarray(Gj, np.float32, order="C")
        if not (Gi32.ndim == 3 and Gi32.shape[0] == 3 and Gi32.shape[1] == Gi32.shape[2]):
            raise ValueError(f"Omega[{which}]: generators_i must be (3,K,K); got {Gi32.shape}")
        if not (Gj32.ndim == 3 and Gj32.shape[0] == 3 and Gj32.shape[1] == Gj32.shape[2]):
            raise ValueError(f"Omega[{which}]: generators_j must be (3,K,K); got {Gj32.shape}")
        Ki, Kj = int(Gi32.shape[1]), int(Gj32.shape[1])
        if Ki != Kj:
            raise ValueError(f"Omega[{which}]-identity: Ki ({Ki}) != Kj ({Kj}); no identity transport defined")

        # Key includes shape so we don't mix (H,W) changes
        H, W = np.asarray(getattr(ai, "mask")).shape[:2]
        keyI = ("Omega_identity", step_tag, _aid(ai), _aid(aj), which, (H, W, Ki))
        OmI = C.get("omega", keyI)
        if OmI is None:
            OmI = np.broadcast_to(np.eye(Ki, dtype=np.float32), (H, W, Ki, Ki)).copy()
            C.put("omega", keyI, OmI)
        return OmI

    # ---------- Default mode ----------
    # Pull fields/generators and validate
    phi_i = _get_phi(ai, which)
    phi_j = _get_phi(aj, which)

    Gi = get_generators(ai, which)
    Gj = get_generators(aj, which)

    Gi32 = np.asarray(Gi, np.float32, order="C")
    Gj32 = np.asarray(Gj, np.float32, order="C")
    if not (Gi32.ndim == 3 and Gi32.shape[0] == 3 and Gi32.shape[1] == Gi32.shape[2]):
        raise ValueError(f"Omega[{which}]: generators_i must be (3,K,K); got {Gi32.shape}")
    if not (Gj32.ndim == 3 and Gj32.shape[0] == 3 and Gj32.shape[1] == Gj32.shape[2]):
        raise ValueError(f"Omega[{which}]: generators_j must be (3,K,K); got {Gj32.shape}")

    # Stable, shape-aware signatures
    gensig_i = getattr(ai, f"_gensig_{which}", None)
    if gensig_i is None:
        gensig_i = stable_sig(("G", Gi32))
        setattr(ai, f"_gensig_{which}", gensig_i)

    gensig_j = getattr(aj, f"_gensig_{which}", None)
    if gensig_j is None:
        gensig_j = stable_sig(("G", Gj32))
        setattr(aj, f"_gensig_{which}", gensig_j)

    phisig_i = stable_sig(("phi", np.asarray(phi_i, np.float32, order="C")))
    phisig_j = stable_sig(("phi", np.asarray(phi_j, np.float32, order="C")))

    # Cache key (per step, agent pair, rep, gens, phis)
    key = ("Omega", step_tag, _aid(ai), _aid(aj), which, gensig_i, gensig_j, phisig_i, phisig_j)
    Om = C.get("omega", key)
    if Om is not None:
        return Om

    # Build frames (E_grid caches internally w/ its own keys)
    Ei = E_grid(ctx, ai, which)
    Ej = E_grid(ctx, aj, which)
    if not (np.isfinite(Ei).all() and np.isfinite(Ej).all()):
        raise FloatingPointError("Omega: non-finite frame exponentials")

    Ej_inv = safe_omega_inv(Ej)  # robust inverse suitable for transport
    Om = np.matmul(Ei, Ej_inv)
    if not np.isfinite(Om).all():
        raise FloatingPointError("Omega: non-finite Ω")

    C.put("omega", key, Om.astype(np.float32, copy=False))
    return Om


def Jinv_grid(ctx, agent, which="q", bbox=None):
    import numpy as np
    from utils import _aid
    
    if getattr(ctx, "cache", None) is None:
        raise RuntimeError("Jinv_grid: ctx.cache missing")
    C        = ctx.cache
    step_tag = int(getattr(ctx, "global_step", -1))

    # --- pull & sanitize phi once (the value we’ll actually use)
    phi = np.asarray(_get_phi(agent, which), np.float32, order="C")
    
    # --- cache key (per step, agent, rep, sanitized phi)
    key = ("Jinv_grid", step_tag, _aid(agent), which, stable_sig(("phi", phi)))

    J = C.get("jinv", key)
    if J is None:
        # build_dexpinv_matrix should accept (...,3) and return (...,3,3)
        J = np.asarray(build_dexpinv_matrix(phi), dtype=np.float32, order="C")
        if not np.all(np.isfinite(J)):
            raise FloatingPointError("Jinv_grid: non-finite J")
        C.put("jinv", key, J)

    if bbox is None:
        return J

    # --- spatial crop (expects (H,W,3,3))
    if J.ndim != 4 or J.shape[-2:] != (3, 3):
        # Not a spatial field; ignore bbox gracefully
        return J

    y0, y1, x0, x1 = map(int, bbox)
    H, W = J.shape[:2]
    if not (0 <= y0 < y1 <= H and 0 <= x0 < x1 <= W):
        raise ValueError(f"Jinv_grid: bbox {bbox} out of bounds for ({H},{W})")
    return J[y0:y1, x0:x1, :, :]



def Phi(ctx, agent, kind: str = "q_to_p"):
    """
    Bundle morphisms:
      q_to_p: Φ  = E_p  Φ₀   (E_q)^{-1}
      p_to_q: Φ̃ = E_q  Φ̃₀  (E_p)^{-1}
    Caches both directions per agent/rep/fields/geometry knobs.
    """
    import numpy as np
    from runtime_context import cfg_get
    from utils import _aid
    
    if getattr(ctx, "cache", None) is None:
        raise RuntimeError("Phi: ctx.cache required")
    if kind not in ("q_to_p", "p_to_q"):
        raise ValueError(f"Phi: unknown kind={kind!r}")

    C        = ctx.cache
    step_tag = int(getattr(ctx, "global_step", -1))
    aid      = _aid(agent)

    # --- Generators (validate early)
    Gq = np.asarray(get_generators(agent, "q"), np.float32, order="C")
    Gp = np.asarray(get_generators(agent, "p"), np.float32, order="C")
    if not (Gq.ndim == 3 and Gq.shape[0] == 3 and Gq.shape[1] == Gq.shape[2]):
        raise ValueError(f"Phi[q]: generators must be (3,Kq,Kq); got {Gq.shape}")
    if not (Gp.ndim == 3 and Gp.shape[0] == 3 and Gp.shape[1] == Gp.shape[2]):
        raise ValueError(f"Phi[p]: generators must be (3,Kp,Kp); got {Gp.shape}")
    Kq, Kp  = int(Gq.shape[1]), int(Gp.shape[1])
    sigGq   = stable_sig(("Gq", Gq))
    sigGp   = stable_sig(("Gp", Gp))

    # --- Bases (Φ0, Φ̃0)
    Phi0, Phit0 = get_morphism_bases(ctx, agent)  # already checked & shaped
    sigB        = stable_sig(("Phi0", Phi0), ("Phit0", Phit0))

    # --- Geometry knobs that affect E_grid -> Φ
    use_A    = bool(cfg_get(ctx, "use_global_A", False))
    ord_raw  = cfg_get(ctx, "A_compose_order", "yx")
    
    # Map to axis tokens if you added the mapper; else keep raw string:
    axis_ord = str(ord_raw).lower()
    th_small = float(cfg_get(ctx, "phi_small_threshold", 0.0))
    max_norm = float(cfg_get(ctx, "exp_clip_max_norm", 1e4))
    

    geom_sig = stable_sig(("useA", use_A), ("ord", axis_ord),
                          ("thr", th_small), ("clip", max_norm))

    # --- Sign sanitized fields (same values E_grid uses)
    phi_q = np.asarray(_get_phi(agent, "q"), np.float32, order="C")
    phi_p = np.asarray(_get_phi(agent, "p"), np.float32, order="C")
    
    
    sigPh = stable_sig(("phi_q", phi_q), ("phi_p", phi_p))

    # --- Keys (cache both directions)
    key_qp = ("morphism_full", aid, (Kq, Kp), "q_to_p", sigGq, sigGp, sigB, geom_sig, sigPh, step_tag)
    key_pq = ("morphism_full", aid, (Kq, Kp), "p_to_q", sigGq, sigGp, sigB, geom_sig, sigPh, step_tag)

    M_qp = C.get("morphism", key_qp)
    M_pq = C.get("morphism", key_pq)
    if M_qp is not None and M_pq is not None:
        return M_qp if kind == "q_to_p" else M_pq

    # --- Build frames (E_grid caches internally)
    Eq = E_grid(ctx, agent, "q")  # (...,Kq,Kq) or (Kq,Kq)
    Ep = E_grid(ctx, agent, "p")  # (...,Kp,Kp) or (Kp,Kp)
    
    inv_Eq = safe_omega_inv(Eq)
    inv_Ep = safe_omega_inv(Ep) 

    # Broadcast-safe multiplies (handles spatial or scalar reps)
    Phi_full  = Ep @ Phi0  @ inv_Eq   # q -> p
    Phit_full = Eq @ Phit0 @ inv_Ep   # p -> q

    if not (np.isfinite(Phi_full).all() and np.isfinite(Phit_full).all()):
        raise FloatingPointError("Phi: non-finite result")

    Phi_full  = np.asarray(Phi_full,  np.float32, order="C")
    Phit_full = np.asarray(Phit_full, np.float32, order="C")
    C.put("morphism", key_qp, Phi_full)
    C.put("morphism", key_pq, Phit_full)
    return Phi_full if kind == "q_to_p" else Phit_full




def get_morphism_bases(ctx, agent):
    """
    Fetch (or build+cache) intertwiner bases Φ0, Φ̃0 for this agent.
    Cache key is (agent_id, Kq, Kp); content guard via digest of generators.
    """
    import numpy as np
    from runtime_context import cfg_get
    from utils import _ensure_q_to_p_shape, _ensure_p_to_q_shape, _aid
    from core.bundle_morphism_utils import build_intertwiner_bases
    
    ns = ctx.cache.nsp("morph_base")

    # Generators → sizes
    Gq = get_generators(agent, "q")   # (3, Kq, Kq)
    Gp = get_generators(agent, "p")   # (3, Kp, Kp)
    if not (isinstance(Gq, np.ndarray) and Gq.ndim == 3 and Gq.shape[0] == 3 and Gq.shape[1] == Gq.shape[2]):
        raise ValueError(f"[morph] Gq must be (3,Kq,Kq); got {None if Gq is None else Gq.shape}")
    if not (isinstance(Gp, np.ndarray) and Gp.ndim == 3 and Gp.shape[0] == 3 and Gp.shape[1] == Gp.shape[2]):
        raise ValueError(f"[morph] Gp must be (3,Kp,Kp); got {None if Gp is None else Gp.shape}")

    Kq, Kp = int(Gq.shape[1]), int(Gp.shape[1])
    aid     = _aid(agent)

    # internal cache key (no separate helper)
    key = (aid, Kq, Kp)

    # stable content digest (invalidate if gens/policy change)
    dig_now = stable_sig(
        ("Gq", Gq), ("Gp", Gp),
        ("Kq", Kq), ("Kp", Kp),
        ("impl", "build_intertwiner_bases@v1"),
        ("method", "auto"),
    )

    entry = ns.get(key)
    if entry is not None and entry.get("digest") == dig_now:
        return entry["Phi0"], entry["Phit0"]

    # --- build fresh
    Phi0_new, Phit0_new, _ = build_intertwiner_bases(Gq, Gp, method="auto", return_meta=True)

    Phi0  = _ensure_q_to_p_shape(Phi0_new,  Kp, Kq).astype(np.float32, copy=False)  # (Kp,Kq)
    Phit0 = _ensure_p_to_q_shape(Phit0_new, Kq, Kp).astype(np.float32, copy=False)  # (Kq,Kp)

    if Kq == Kp:
        Phi0  = orthogonalize_intertwiner(Phi0)
        Phit0 = orthogonalize_intertwiner(Phit0)

    if not (np.isfinite(Phi0).all() and np.isfinite(Phit0).all()):
        raise ValueError("[morph] Φ0/Φ̃0 contain non-finite values")
    if max(np.linalg.norm(Phi0, 'fro'), np.linalg.norm(Phit0, 'fro')) == 0.0:
        raise ValueError("[morph] Φ0/Φ̃0 are zero")

    ns[key] = {"Phi0": Phi0, "Phit0": Phit0, "digest": dig_now, "warned": False}

    # optional residual check (once)
    tol_rel = float(cfg_get(ctx, "intertwiner_rel_tol", 1e-7))
    if not ns[key]["warned"]:
        try:
            r1 = _intertwining_resid(Gp, Gq, Phi0)    # || Gp Φ0 - Φ0 Gq ||
            r2 = _intertwining_resid(Gq, Gp, Phit0)   # || Gq Φ̃0 - Φ̃0 Gp ||
            scale = max(np.linalg.norm(Gq, 'fro'), np.linalg.norm(Gp, 'fro'), 1.0)
            rel = (r1 + r2) / (1e-6 + scale)
            if rel > tol_rel:
                print(f"[morph] note: relative intertwiner residual ≈ {rel:.2e}")
                ns[key]["warned"] = True
        except Exception:
            ns[key]["warned"] = False

    return Phi0, Phit0



def Phi_cached(ctx, agent, *, kind: str):
    """
    Cache Φ / Φ̃ per agent per step. Requires CacheHub.get(ns, key) / put(ns, key, val).
    """
    C = getattr(ctx, "cache", None)
    if C is None:
        # no cache hub, compute directly
        return Phi(ctx, agent, kind=kind)

    step_tag = int(getattr(ctx, "global_step", -1))
    ns = "Phi"  # namespace for morphisms
    # keep key small but unique; add kind + step
    key = (id(agent), kind, step_tag)

    val = C.get(ns, key)
    if val is not None:
        return val

    M = Phi(ctx, agent, kind=kind)
    C.put(ns, key, M)
    return M


def fisher_cached(ctx, agent, generators, *, which: str, eps: float):
    """
    Cache inverse Fisher per agent per step. Requires CacheHub.get(ns, key).
    """
    from core.omega import inverse_fisher_metric_field 
    C = getattr(ctx, "cache", None)
    if C is None:
        return inverse_fisher_metric_field(ctx, agent, generators, which=which, eps=eps)

    step_tag = int(getattr(ctx, "global_step", -1))
    ns = "FisherInv"
    # shapes are enough since step_tag changes each step
    M = getattr(agent, "mu_q_field" if which == "q" else "mu_p_field")
    S = getattr(agent, "sigma_q_field" if which == "q" else "sigma_p_field")
    key = (id(agent), which, step_tag, M.shape, S.shape)

    val = C.get(ns, key)
    if val is not None:
        return val

    Finv = inverse_fisher_metric_field(ctx, agent, generators, which=which, eps=eps)
    C.put(ns, key, Finv)
    return Finv



def E_grid_field(ctx, phi_field, generators, *, sign=+1):
    """
    Exponential from a *field* (not from agent): E = exp(sign * φ) under the given generators.
    Uses the same sanitization as E_grid. Accepts φ of shape (..., 3).
    Returns (..., K, K).
    """
    import numpy as np
    from runtime_context import cfg_get
    # sanitize φ to principal ball
    phi = retract_phi_principal(
        np.asarray(phi_field, np.float32),
        margin=1e-6, use_float64=False
    ).astype(np.float32, copy=False)

    if sign not in (+1, -1):
        raise ValueError(f"E_grid_field: sign must be +1 or -1, got {sign!r}")
    if sign == -1:
        phi = -phi

    # validate generators (3, K, K)
    G = np.asarray(generators, np.float32, order="C")
    if not (G.ndim == 3 and G.shape[0] == 3 and G.shape[1] == G.shape[2]):
        raise ValueError(f"E_grid_field: generators must be (3,K,K); got {G.shape}")

    max_norm = float(cfg_get(ctx, "exp_clip_max_norm", 1e4))
    return exp_lie_algebra_irrep(phi, G, max_norm=max_norm)



def exp_and_jinv_single(ctx, agent, field: str, base_field, generators_q, generators_p):
    """
    Resolve exp(field) and Jinv for one agent/fiber, with cache-first lookups.
    Returns:
      exp_this, exp_other, Jinv, which, G_q, G_p
    where:
      which ∈ {"q","p"}; exp_this matches 'which'.
    """

    which = "q" if field == "phi" else "p"

    # --- exp grids (cache first; fallback to local compute) ---
    exp_q = E_grid(ctx, agent, which="q")   
    exp_p = E_grid(ctx, agent, which="p")
    Jinv = Jinv_grid(ctx, agent, which=which)

    exp_this  = exp_q if which == "q" else exp_p
    exp_other = exp_p if which == "q" else exp_q

    # IMPORTANT: keep the generators aligned to their fibers
    G_q = generators_q
    G_p = generators_p

    return exp_this, exp_other, Jinv, which, G_q, G_p


def Fisher_blocks(ctx, agent, which="q", *, tol=None):
    
    from utils import _aid
    C = getattr(ctx, "cache", None)
    step_tag = int(getattr(ctx, "global_step", -1))
    Sig = np.asarray(getattr(agent, "sigma_q_field" if which == "q" else "sigma_p_field"),
                     np.float32, order="C")
    if Sig.shape[-1] != Sig.shape[-2]:
        raise ValueError(f"Sigma must be (...,K,K); got {Sig.shape}")

    key = None
    if C is not None:
        sigsig = hashlib.sha1(Sig.view(np.uint8)).hexdigest()  # faster than sha256
        key = ("Fisher_blocks", step_tag, _aid(agent), which, Sig.shape[-1], sigsig, tol)
        cached = C.get("fisher", key)
        if cached is not None:
            return cached

    Sig = 0.5 * (Sig + Sig.swapaxes(-1, -2))

    try:
        L = np.linalg.cholesky(Sig)
    except np.linalg.LinAlgError:
        raise np.linalg.LinAlgError("Σ not SPD even after symmetrization")

    I = np.eye(Sig.shape[-1], dtype=np.float32)
    I_b = np.broadcast_to(I, Sig.shape[:-2] + I.shape).copy()
    X = np.linalg.solve(L, I_b)
    Prec = np.swapaxes(X, -1, -2) @ X
    Prec = 0.5 * (Prec + Prec.swapaxes(-1, -2))

    diagL = np.diagonal(L, axis1=-2, axis2=-1)
    logdet = (2.0 * np.log(np.clip(diagL, 1e-30, None)).sum(axis=-1)).astype(np.float32)

    out = {"precision": Prec.astype(np.float32, copy=False), "logdet": logdet}
    
    if C is not None:
        C.put("fisher", key, out)
    return out



# ---------------------------------------------------------------------------
# Cached dexpinv matrices Jinv(phi)  (SO(3) axis-angle principal ball)
# ---------------------------------------------------------------------------

def build_dexpinv_matrix(
    phi: np.ndarray,
    eps: float = 1e-12,
    *,
    margin: float = 1e-6,     # principal-ball margin (π - margin)
    use_float64: bool = False,
) -> np.ndarray:
    """
    Stable SO(3) right-Jacobian inverse J^{-1}(φ).
    Returns array of shape (..., 3, 3).

    Formula (kept from your convention):
      J^{-1}(φ) = I - (θ/2) ad(u) + (1 - h) ad(u)^2,
      h(θ) = (θ/2) cot(θ/2),  φ = θ u,  ad(u) = [u]_×.
    """
    
    dtype = np.float64 if use_float64 else np.float32

    # ---- validate & retract ----
    phi = np.asarray(phi, dtype=dtype)
    if phi.shape[-1] != 3:
        raise ValueError(f"build_dexpinv_matrix: last dim must be 3, got {phi.shape}")
    phi_r = retract_phi_principal(phi, margin=margin, use_float64=use_float64).astype(dtype, copy=False)

    # ---- axis/angle pieces ----
    th   = np.linalg.norm(phi_r, axis=-1)               # (...,)
    u    = np.divide(phi_r, th[..., None] + eps, dtype=dtype)  # (...,3)

    ux, uy, uz = u[..., 0], u[..., 1], u[..., 2]
    z = np.zeros_like(ux, dtype=dtype)
    adu = np.stack([
        np.stack([ z,  -uz,  uy], axis=-1),
        np.stack([ uz,   z, -ux], axis=-1),
        np.stack([-uy,  ux,   z], axis=-1),
    ], axis=-2).astype(dtype, copy=False)               # (...,3,3)

    # ---- h(θ) = (θ/2) cot(θ/2) with small-θ series ----
    half = 0.5 * th
    small = th < 1e-3
    # series in θ (not half): 1 - θ^2/12 - θ^4/720 + O(θ^6)
    t2 = th * th
    h_series = 1.0 - (t2 / 12.0) - ((t2 * t2) / 720.0)

    # safe half-angle for non-small branch
    half_ns = np.clip(half, 1e-6, np.pi/2 - 1e-6)
    h_closed = half_ns / np.tan(half_ns)

    # piecewise combine without extra passes
    h = np.where(small, h_series, h_closed)

    # ---- build J^{-1} ----
    I = np.eye(3, dtype=dtype)
    uuT  = u[..., :, None] * u[..., None, :]           # (...,3,3)
    adu2 = (uuT - I)                                   # (...,3,3)

    Jinv = I - half[..., None, None] * adu + (1.0 - h)[..., None, None] * adu2
    if not np.all(np.isfinite(Jinv)):
        raise FloatingPointError("build_dexpinv_matrix produced non-finite values")

    return Jinv.astype(np.float32, copy=False)






#==============================================================================
#
#
#
#==============================================================================




def _intertwining_resid(G_left, G_right, X):
    """
    Residual || G_left[a] X - X G_right[a] ||_F summed over a=0..2.
    Shapes: G_left(Kout,Kout,3), G_right(Kin,Kin,3), X(Kout,Kin)
    """
    
    X  = np.asarray(X, np.float32)
    Kout = G_left.shape[0]; Kin = G_right.shape[0]
    if X.shape != (Kout, Kin):
        raise ValueError(f"X has shape {X.shape}, expected {(Kout, Kin)}")
    r = 0.0
    for a in range(3):
        r += float(np.linalg.norm(G_left[..., a] @ X - X @ G_right[..., a]))
    return r



#==============================================================================
#
#                  Gauge Curvature
#
#==============================================================================

def _roll2(a, shift):
    """
    Periodic shift along grid axes.
    Assumes a has shape (..., H, W, K, K); shifts along axes -4 (H) and -3 (W).
    """
    di, dj = int(shift[0]), int(shift[1])
    if (di | dj) == 0:
        return a
    return np.roll(np.roll(a, di, axis=-4), dj, axis=-3)



def plaquette_from_A(ctx, agent, which: str = "q"):
    """
    Lattice plaquette from the A-connection (split geometry):
      P(i,j) = Ux(i,j) · Uy(i+1,j) · Ux(i,j+1)^{-1} · Uy(i,j)^{-1}

    - Uses expA_q/expA_p to get direction-split link matrices.
    - Measures curvature: P ≈ I if curl(A)=0; otherwise nontrivial.
    - Returns (H, W, K, K).
    """
    import numpy as np

    # 1) Get split-geometry links from A
    Ugeom = expA_q(ctx, agent) if which == "q" else expA_p(ctx, agent)
    Ugeom = np.asarray(Ugeom, np.float32)

    if Ugeom.ndim == 5 and Ugeom.shape[-3] == 2:
        # Spatial A: split geometry present
        Ux = Ugeom[..., 0, :, :]           # (H, W, K, K)
        Uy = Ugeom[..., 1, :, :]
    
    elif Ugeom.ndim == 2:
        # A is a single 3-vector → uniform links (plaquette will be I)
        H, W = np.asarray(agent.mask).shape[:2]
        Ux = np.broadcast_to(Ugeom, (H, W) + Ugeom.shape).copy()
        Uy = Ux
    else:
        raise ValueError(f"expA_* must return (H,W,2,K,K) or (K,K); got {Ugeom.shape}")

    # 2) Neighbor-shifted links
    Ux_i_j1 = _roll2(Ux, (0, +1))  # Ux(i, j+1)
    Uy_i1_j = _roll2(Uy, (+1, 0))  # Uy(i+1, j)

    # 3) Plaquette: Ux ⋅ Uy(next-x) ⋅ Ux(next-y)^{-1} ⋅ Uy^{-1}
    P = Ux @ Uy_i1_j @ safe_omega_inv(Ux_i_j1) @ safe_omega_inv(Uy)

    if not np.all(np.isfinite(P)):
        raise FloatingPointError("plaquette_from_A: non-finite entries in P")

    return P.astype(np.float32, copy=False)




def plaquette_product(ctx, phi_field, generators, *,
                      split_edge=False, sign=+1):
    """
    P(i,j) = Ux(i,j) · Uy(i+1,j) · Ux(i,j+1)^T · Uy(i,j)^T
    phi_field: (..., H, W, 3)
    generators: (3,K,K) or (K,K,3)
    Returns: (..., H, W, K, K)
    
    """
    import numpy as np

    # Accept either layout; normalize to (3,K,K)
    G = np.asarray(generators, np.float32)
    if G.ndim != 3:
        raise ValueError(f"generators must be rank-3, got {G.shape}")
    if G.shape[0] == 3:
        G3 = G
    elif G.shape[-1] == 3 and G.shape[0] == G.shape[1]:
        G3 = np.moveaxis(G, -1, 0)  # (K,K,3) -> (3,K,K)
    else:
        raise ValueError(f"bad generators shape {G.shape}; expected (3,K,K) or (K,K,3)")

    # Site exponentials (orthonormal reps => inverse = transpose)
    E  = E_grid_field(ctx, phi_field, G3, sign=sign)   # (..., H, W, K, K)
    Et = np.swapaxes(E, -1, -2)

    if not split_edge:
        E_right = _roll2(E, (0, +1))  # (i, j+1)
        E_down  = _roll2(E, (+1, 0))  # (i+1, j)
        Ux_ij = np.matmul(E_down,  Et)
        Uy_ij = np.matmul(E_right, Et)
        Ux_i_j1 = _roll2(Ux_ij, (0, +1))
        Uy_i1_j = _roll2(Uy_ij, (+1, 0))
    else:
        half = 0.5
        Ehalf_here  = E_grid_field(ctx, half*phi_field, G3, sign=sign)
        Ehalf_right = _roll2(Ehalf_here, (0, +1))
        Ehalf_down  = _roll2(Ehalf_here, (+1, 0))
        Eh_t = np.swapaxes(Ehalf_here, -1, -2)
        Ux_ij = np.matmul(Ehalf_down,  Eh_t)
        Uy_ij = np.matmul(Ehalf_right, Eh_t)
        Ux_i_j1 = _roll2(Ux_ij, (0, +1))
        Uy_i1_j = _roll2(Uy_ij, (+1, 0))

    P = Ux_ij @ Uy_i1_j @ np.swapaxes(Ux_i_j1, -1, -2) @ np.swapaxes(Uy_ij, -1, -2)
    return P.astype(np.float32, copy=False)



# ---------------------------------------------------------------------------
# Warming & invalidation
# ---------------------------------------------------------------------------

def warm_E_old(ctx: Any, agents: Sequence[Any], whiches: Iterable[str] = ("q", "p")) -> None:
    for a in agents:
        for w in whiches:
            try:
                _ = E_grid(ctx, a, which=w)
            except Exception as e:
                print(f"warm-e fail ({getattr(a,'id',None)} {w}): {type(e).__name__}: {e}")



def warm_E(ctx, agents, whiches=("q","p"), n_jobs=None):
    from runtime_context import cfg_get
    n = max(1, n_jobs or int(cfg_get(ctx, "n_jobs", 1)))
    def _one(a):
        for w in whiches:
            try: _ = E_grid(ctx, a, which=w)
            except Exception as e:
                print(f"warm-e fail ({getattr(a,'id',None)} {w}): {type(e).__name__}: {e}")
    Parallel(n_jobs=n, backend="threading", batch_size="auto")(
        delayed(_one)(a) for a in agents
    )



def warm_Jinv(ctx, agents, whiches=("q","p"), n_jobs=None):
    """Precompute Jinv for many agents (idempotent)."""
    from runtime_context import cfg_get
    n = max(1, n_jobs or int(cfg_get(ctx, "n_jobs", 1)))

    def _one(a):
        for w in whiches:
            try:
                _ = Jinv_grid(ctx, a, which=w)
            except Exception as e:
                print(f"warm-jinv fail (agent={getattr(a,'id',None)} {w}): {type(e).__name__}: {e}")

    Parallel(n_jobs=n, backend="threading", batch_size="auto")(
        delayed(_one)(a) for a in agents
    )


def warm_Jinv_OLD(ctx: Any, agents: Sequence[Any], whiches: Iterable[str] = ("q", "p")) -> None:
    """Precompute Jinv for many agents (idempotent)."""
    for a in agents:
        for w in whiches:
            try:
                _ = Jinv_grid(ctx, a, which=w)
            except Exception as e:
                print(f"warm-jinv fail (agent={getattr(a,'id',None)} {w}): {type(e).__name__}: {e}")



def stable_sig(*parts, float_dtype=np.float32, order="C") -> str:
    """
    Deterministic SHA256 over heterogeneous inputs.
    - Arrays: cast to float_dtype, force C-order, include shape bytes
    - Numbers/strings/bytes: tagged
    - dicts: sorted by key; lists/tuples: include length and order
    - None: tagged
    Falls back to repr(...) for unknown types.
    """
    h = hashlib.sha256()

    def _upd(x):
        if isinstance(x, np.ndarray):
            a = np.asarray(x, dtype=float_dtype, order=order)
            h.update(b"A"); h.update(str(a.shape).encode()); h.update(a.tobytes())
        elif isinstance(x, (float, np.floating)):
            h.update(b"f"); h.update(np.asarray(x, float_dtype).tobytes())
        elif isinstance(x, (int, np.integer, bool, np.bool_)):
            # 8-byte little-endian signed for stability
            h.update(b"i"); h.update(int(x).to_bytes(8, "little", signed=True))
        elif isinstance(x, (bytes, bytearray, memoryview)):
            h.update(b"B"); h.update(bytes(x))
        elif isinstance(x, str):
            h.update(b"S"); h.update(x.encode("utf-8"))
        elif isinstance(x, dict):
            h.update(b"D")
            for k in sorted(x.keys()):
                _upd(k); _upd(x[k])
        elif isinstance(x, (list, tuple)):
            h.update(b"L"); h.update(len(x).to_bytes(8, "little"))
            for y in x: _upd(y)
        elif x is None:
            h.update(b"N")
        else:
            h.update(b"R"); h.update(repr(x).encode("utf-8"))

    for p in parts: _upd(p)
    return h.hexdigest()

