# -*- coding: utf-8 -*-
"""
Created on Thu Jul 24 17:54:26 2025

@author: chris and christine
"""
from scipy.ndimage import gaussian_filter
import core.config as config
import numpy as np
from core.agent_schema import Agent
from numpy.random import default_rng  
from core.bundle_morphism_utils import build_intertwiner_bases
from core.omega import retract_phi_principal
from core.numerical_utils import sanitize_sigma  

from utils import make_soft_mask, _ensure_q_to_p_shape, _ensure_p_to_q_shape, zero_all_gradients

def create_agent_mask_and_center(domain_size, rng, radius_range, fixed_center=None):
    radius = rng.uniform(*radius_range)
    center = fixed_center or tuple(rng.integers(0, s) for s in domain_size)
    # Return both float mask and a bool mask derived from the same cutoff rule
    mask, mask_bool = make_soft_mask(center, radius, domain_size, return_bool=True)
    return center, radius, mask, mask_bool


def initialize_agents(
    seed: int,
    domain_size: tuple[int, int],
    N: int,
    lie_algebra_dim: int,
    visualize: bool = False,
    fixed_location: bool = True,
    generators_q=None,
    generators_p=None,
) -> list:
    """
    Initialize N agents over the given domain.

    Guarantees
    ----------
    * If generators are provided (shape (3,K,K)), we enforce K_q/K_p from them.
    * Φ0 (Kp×Kq) and Φ̃0 (Kq×Kp) are built from intertwiners and shape-checked.
    * Covariances remain SPD both inside and outside masks.
    * All added noise respects config dtype.
    """
    
    rng   = default_rng(seed)
    dtype = getattr(config, "dtype", np.float32)
    cfg   = {k: getattr(config, k) for k in dir(config) if not k.startswith("__")}

    phi_init         = cfg.get("phi_init")
    phi_model_offset = float(cfg.get("phi_model_offset", 0.1))
    max_neighbors    = int(cfg.get("max_neighbors", 8))
    overlap_eps      = float(cfg.get("overlap_eps", 1e-6))
    diagonal_sigma   = bool(cfg.get("diagonal_sigma", False))
    sigma_out_val    = float(cfg.get("sigma_outside_val", 1000.0))
    eps              = float(getattr(config, "eps", 1e-6))
    use_global_belief = bool(cfg.get("use_global_belief_template", False))
    use_global_model  = bool(cfg.get("use_global_model_template",  False))
    # ---------------- Generators ----------------
    
    G_q = generators_q
    G_p = generators_p
    
    # Require both or fail early (simplest and safest)
    if (G_q is None) or (G_p is None):
        raise ValueError("initialize_agents requires both generators_q and generators_p.")
    
    G_q = np.asarray(G_q, dtype=np.float32)
    G_p = np.asarray(G_p, dtype=np.float32)
    
    if not (G_q.ndim == 3 and G_q.shape[0] == 3 and G_q.shape[1] == G_q.shape[2]):
        raise AssertionError(f"G_q must be (3,Kq,Kq), got {G_q.shape}")
    
    if not (G_p.ndim == 3 and G_p.shape[0] == 3 and G_p.shape[1] == G_p.shape[2]):
        raise AssertionError(f"G_p must be (3,Kp,Kp), got {G_p.shape}")
    
    K_q = int(G_q.shape[1])
    K_p = int(G_p.shape[1])

    # ---------------- Optional global templates ----------------
    fixed_center = (domain_size[0] // 2, domain_size[1] // 2) if fixed_location else None
    agents: list = []
   
    global_mu_q = global_sigma_q = None
    global_mu_p = global_sigma_p = None

    if use_global_belief:
        global_mu_q, global_sigma_q = generate_mu_sigma_fields(
            domain_size=domain_size, rng=rng, K=K_q,
            mu_range=config.q_mu_range, sigma_range=config.q_sigma_range,
            mask=None, sigma_outside_val=sigma_out_val,
            dtype=dtype, smooth_sigma=cfg.get("init_smooth_sigma", 2.0),
            diagonal_sigma=diagonal_sigma,
        )

    if use_global_model:
        global_mu_p, global_sigma_p = generate_mu_sigma_fields(
            domain_size=domain_size, rng=rng, K=K_p,
            mu_range=config.p_mu_range, sigma_range=config.p_sigma_range,
            mask=None, sigma_outside_val=sigma_out_val,
            dtype=dtype, smooth_sigma=cfg.get("init_smooth_sigma", 2.0),
            diagonal_sigma=diagonal_sigma,
        )

    # ---------------- Per-agent initialization ----------------
    for n in range(N):
        center, radius, mask, _ = create_agent_mask_and_center(
            domain_size, rng,
            radius_range=cfg.get("agent_radius_range", (5, 10)),
            fixed_center=fixed_center,
        )

        # Belief fields
        if use_global_belief:
            mu_q    = (global_mu_q * mask[..., None]).astype(dtype, copy=False)
            sigma_q = global_sigma_q.copy().astype(dtype, copy=False)
            outside = (mask <= 0).astype(bool)
            if outside.any():
                sigma_q[outside, :, :] = np.eye(K_q, dtype=dtype) * sigma_out_val
            mu_q  += rng.normal(scale=float(cfg.get("belief_noise_scale_mu", 0.01)),
                                size=mu_q.shape).astype(dtype, copy=False)
            sigma_q += rng.normal(scale=float(cfg.get("belief_noise_scale_sigma", 0.01)),
                                  size=sigma_q.shape).astype(dtype, copy=False)
            sigma_q = sanitize_sigma(sigma_q, eps=eps)
        else:
            mu_q, sigma_q = generate_mu_sigma_fields(
                domain_size=domain_size, rng=rng, K=K_q,
                mu_range=config.q_mu_range, sigma_range=config.q_sigma_range,
                mask=mask, sigma_outside_val=sigma_out_val,
                dtype=dtype, smooth_sigma=cfg.get("init_smooth_sigma", 2.0),
                diagonal_sigma=diagonal_sigma,
            )

        # Model fields
        if use_global_model:
            mu_p    = (global_mu_p * mask[..., None]).astype(dtype, copy=False)
            sigma_p = global_sigma_p.copy().astype(dtype, copy=False)
            outside = (mask <= 0).astype(bool)
            if outside.any():
                sigma_p[outside, :, :] = np.eye(K_p, dtype=dtype) * sigma_out_val
            mu_p  += rng.normal(scale=float(cfg.get("model_noise_scale_mu", 0.01)),
                                size=mu_p.shape).astype(dtype, copy=False)
            sigma_p += rng.normal(scale=float(cfg.get("model_noise_scale_sigma", 0.01)),
                                  size=sigma_p.shape).astype(dtype, copy=False)
            sigma_p = sanitize_sigma(sigma_p, eps=eps)
        else:
            mu_p, sigma_p = generate_mu_sigma_fields(
                domain_size=domain_size, rng=rng, K=K_p,
                mu_range=config.p_mu_range, sigma_range=config.p_sigma_range,
                mask=mask, sigma_outside_val=sigma_out_val,
                dtype=dtype, smooth_sigma=cfg.get("init_smooth_sigma", 2.0),
                diagonal_sigma=diagonal_sigma,
            )

        # Algebra fields
        phi, phi_model = initialize_phi_pair(
            domain_size, lie_algebra_dim, rng, phi_init, phi_model_offset, mask
        )
        
        phi       = retract_phi_principal(phi,       margin=1e-6)
        phi_model = retract_phi_principal(phi_model, margin=1e-6)

        # Construct agent object
        agent = construct_agent_object(
            agent_id=int(n),
            center=center,
            radius=radius,
            mask=mask.astype(dtype, copy=False),
            mu_q=mu_q, sigma_q=sigma_q,
            mu_p=mu_p, sigma_p=sigma_p,
            phi=phi.astype(dtype, copy=False),
            phi_model=phi_model.astype(dtype, copy=False),
            dtype=dtype,
        )

        # Attach generators (float32, (3,K,K))
        agent.generators_q = G_q
        agent.generators_p = G_p

        # Intertwiner bases (Φ0: Kp×Kq, Φ̃0: Kq×Kp)
        Phi_0_raw, Phi_tilde_0_raw, _ = build_intertwiner_bases(G_q, G_p, method="auto", return_meta=True)
        Phi_0       = _ensure_q_to_p_shape(Phi_0_raw, K_p, K_q).astype(np.float32, copy=False)
        Phi_tilde_0 = _ensure_p_to_q_shape(Phi_tilde_0_raw, K_q, K_p).astype(np.float32, copy=False)
        
        agent.Phi_0       = Phi_0
        agent.Phi_tilde_0 = Phi_tilde_0

        agent.morphisms_dirty = False
        zero_all_gradients(agent)

        agents.append(agent)

    # Neighbors (IoU metric; symmetric optional)
    assign_neighbors_simple(
        agents,
        overlap_eps=overlap_eps,
        max_neighbors = max_neighbors,
        symmetric=bool(cfg.get("neighbors_symmetric", False)),
    )
    return agents



def construct_agent_object(
    agent_id,
    center,
    radius,
    mask,
    mu_q, sigma_q,
    mu_p, sigma_p,
    phi, phi_model,
    dtype=np.float32
) -> Agent:
    """
    Build a level-0 Agent (no parents, no cross-scale maps yet).
    """
    a = Agent(
        id=agent_id,
        center=center,
        radius=radius,
        mask=mask.astype(dtype),

        mu_q_field=mu_q.astype(dtype),
        sigma_q_field=sigma_q.astype(dtype),
        mu_p_field=mu_p.astype(dtype),
        sigma_p_field=sigma_p.astype(dtype),

        phi=phi.astype(dtype),
        phi_model=phi_model.astype(dtype),

        neighbors=[],
    )
    # Ensure level-0 & empty relations
    a.level = 0
    a.parent_ids = []
    a.child_ids = []
        
    return a



def generate_mu_sigma_fields( 
    domain_size,
    rng,
    K,
    mu_range,
    sigma_range,
    mask=None,
    sigma_outside_val=None,
    dtype=np.float32,
    smooth_sigma=None,
    diagonal_sigma=None,
    eps=None,
    floor=None,
    *,
    cond0: float = 100.0,            # <-- NEW: target per-pixel condition cap at init (10–100 good)
    trace_match: bool = True        # normalize trace to target scale
):
    """
    Generate spatially varying (μ, Σ) fields with shape:
        μ     : (H, W, K)
        Σ     : (H, W, K, K)

    Args:
        domain_size        : (H, W)
        rng                : np.random.Generator
        K                  : int, fiber dimension
        mu_range           : tuple[float, float]
        sigma_range        : tuple[float, float]  (typical *eigenvalue* scale range)
        mask               : optional (H, W) float mask in [0,1]
        sigma_outside_val  : float, fallback Σ diagonal value outside support (>0)
        dtype              : np.float32 or np.float64
        smooth_sigma       : float, Gaussian blur width for smoothness
        diagonal_sigma     : bool, if True, initializes Σ diagonally
        eps                : float, minimal eigenvalue abs floor for SPD
        floor              : (unused; reserved)
        cond0              : (kwonly) per-pixel eigenvalue ratio upper bound at init
        trace_match        : (kwonly) if True, normalize per-pixel trace to target scale

    Returns:
        mu_field     : (H, W, K)
        sigma_field  : (H, W, K, K)
    """
    

    # --- defaults ---
    eps = eps if eps is not None else 1e-6
    sigma_outside_val = sigma_outside_val if sigma_outside_val is not None else 1e3
    smooth_sigma = smooth_sigma if smooth_sigma is not None else 2.0
    diagonal_sigma = diagonal_sigma if diagonal_sigma is not None else False
    
    if sigma_outside_val <= 0.0:
        raise ValueError("sigma_outside_val must be positive for covariance")
    if cond0 < 1.0:
        raise ValueError("cond0 must be >= 1.0")

    H, W = domain_size
    lo_s, hi_s = sigma_range
    target_scale = float(0.5 * (lo_s + hi_s))  # typical eigenvalue magnitude
    target_trace = K * target_scale

    # --- μ: smooth random field in mu_range ---
    mu = rng.uniform(*mu_range, size=(H, W, K)).astype(dtype)
    for k in range(K):
        mu[..., k] = gaussian_filter(mu[..., k], sigma=smooth_sigma, mode='wrap')

    # --- helper: per-pixel orthogonal projection via SVD (polar factor) ---
    def _orthogonalize_field(B):
        # B: (H,W,K,K) -> Q: (H,W,K,K) with Q^T Q = I and det(Q)=+1
        U, _, Vt = np.linalg.svd(B, full_matrices=False)
        Q = U @ Vt
        # enforce det=+1 per pixel
        detQ = np.linalg.det(Q)
        neg = detQ < 0
        if np.any(neg):
            # flip last column of U only where needed
            U[neg, :, -1] *= -1.0
            Q = U @ Vt
        return Q.astype(dtype, copy=False)

    # --- Σ initialization ---
    if diagonal_sigma:
        print("USING DIAGONAL SIGMA!!!!!\n\n\n\n\n\n")
        # Smooth random diagonal then clamp into [lam_min, lam_min*cond0]
        diag_raw = rng.uniform(lo_s, hi_s, size=(H, W, K)).astype(dtype)
        for k in range(K):
            diag_raw[..., k] = gaussian_filter(diag_raw[..., k], sigma=smooth_sigma, mode='wrap')

        # per-pixel lam_min: enforce lower bound relative to scale
        lam_min = np.maximum(eps, diag_raw.min(axis=-1, keepdims=True))
        lam_min = np.maximum(lam_min, target_scale / cond0)  # relative guard

        # clamp diagonal entries to [lam_min, lam_min*cond0]
        diag = np.clip(diag_raw, lam_min, lam_min * cond0)
        sigma_field = np.zeros((H, W, K, K), dtype=dtype)
        for k in range(K):
            sigma_field[..., k, k] = diag[..., k]
    else:
        # --- Controlled spectrum full covariance ---
        # 1) Smooth random orthogonal field Q
        B = rng.normal(0.0, 1.0, size=(H, W, K, K)).astype(dtype)
        for i in range(K):
            for j in range(K):
                B[..., i, j] = gaussian_filter(B[..., i, j], sigma=smooth_sigma, mode='wrap')
        Q = _orthogonalize_field(B)  # (H,W,K,K)

        # 2) Smooth per-pixel λ_min field: around target_scale/cond0
        #    Draw a base field in a reasonable band and smooth it.
        lam_min_base = rng.uniform(
            max(eps, lo_s / cond0), max(target_scale / cond0, hi_s / cond0),
            size=(H, W)
        ).astype(dtype)
        lam_min = gaussian_filter(lam_min_base, sigma=smooth_sigma, mode='wrap')[..., None]  # (H,W,1)
        lam_min = np.clip(lam_min, eps, None)

        # 3) Draw per-pixel eigenvalue ratios r_k ∈ [1, cond0] (log-uniform for spread)
        u = rng.uniform(0.0, 1.0, size=(H, W, K)).astype(dtype)
        r = cond0 ** u  # log-uniform in [1, cond0]

        # 4) Build eigenvalues and (optionally) match trace
        lam = lam_min * r  # (H,W,K)
        if trace_match:
            tr_now = np.sum(lam, axis=-1, keepdims=True)  # (H,W,1)
            # scale so sum(lam)=target_trace per pixel
            lam = lam * (target_trace / np.maximum(tr_now, eps))

        # 5) Construct Σ = Q diag(lam) Q^T
        sigma_field = (Q * lam[..., None, :]) @ np.swapaxes(Q, -1, -2)

        
    # --- Final sanitization to ensure SPD (your existing helper) ---
    sigma_field = sanitize_sigma(sigma_field, eps=eps)

    # --- Apply mask: zero μ and set fallback covariance outside support ---
    if mask is not None:
        mask = mask.astype(dtype)
        mu_zero = np.zeros_like(mu)
        sigma_outside = (sigma_outside_val * np.eye(K, dtype=dtype))

        mu = mask[..., None] * mu + (1.0 - mask[..., None]) * mu_zero
        sigma_field = (
            mask[..., None, None] * sigma_field
            + (1.0 - mask[..., None, None]) * sigma_outside[None, None, :, :]
        )

    return mu, sigma_field





def masked_normalized_blur(field, mask, sigma, eps=1e-6):
    """
    Blur 'field' only over the mask, without leaking zeros from outside.
    Computes blur(field*mask)/blur(mask).
    """
    m = mask.astype(field.dtype)
    num = gaussian_filter(field * m[..., None], sigma, mode = "wrap")
    den = gaussian_filter(m, sigma, mode = "wrap")[..., None]
    return num / np.maximum(den, eps)

# --- main initializers ---

def initialize_phi_field(
    domain_size: tuple[int, ...],
    lie_algebra_dim: int,
    rng: np.random.Generator,
    init_scale: float,
    mask: np.ndarray,
    smooth_sigma: float | tuple[float, ...] | None = None,
    *,
    use_masked_blur: bool = False,
) -> np.ndarray:
    """
    Initialize and smooth a φ field with Gaussian noise and apply mask.
    Uses periodic blur by default for toroidal domains.
    """
    if lie_algebra_dim != 3:
        raise ValueError(f"SO(3) frames expect lie_algebra_dim=3, got {lie_algebra_dim}")

    dtype = getattr(config, "dtype", mask.dtype)
    sigma = smooth_sigma if (smooth_sigma is not None) else getattr(config, "phi_init_smooth_sigma", 0.5)

    phi_raw = rng.normal(scale=init_scale, size=(*domain_size, lie_algebra_dim)).astype(dtype)

    if use_masked_blur:
        # interior-preserving blur (no leakage from outside)
        phi_smooth = masked_normalized_blur(phi_raw, mask, sigma)
    else:
        # simple periodic blur, then mask away outside
        phi_smooth = gaussian_filter(phi_raw, sigma=sigma, mode = "wrap")
        phi_smooth *= mask[..., None]
    
    return phi_smooth


def initialize_phi_pair(
    domain_size: tuple[int, ...],
    lie_algebra_dim: int,
    rng: np.random.Generator,
    phi_init: float,
    phi_model_offset: float,
    mask: np.ndarray,
    *,
    smooth_sigma: float | tuple[float, ...] | None = None,
    use_masked_blur: bool = False,
) -> tuple[np.ndarray, np.ndarray]:
    """
    Initialize φ (belief) and φ̃ (model).
      - If config.identical_models: φ̃ = 0
      - Else: φ̃ = Smooth[ φ + R·ξ ], where R ~ SO(3) (adjoint) and ξ ~ N(0, φ_model_offset^2 I)
    """
    phi = initialize_phi_field(
        domain_size, lie_algebra_dim, rng, phi_init, mask,
        smooth_sigma=smooth_sigma, use_masked_blur=use_masked_blur
    )

    if getattr(config, "identical_models", False) or phi_model_offset == 0.0:
        print("USING IDENTITICAL PHI=PHI~")
        phi_model = np.zeros_like(phi)
        return phi, phi_model

    # perturb in the Lie algebra using a single adjoint rotation (global frame twist)
    delta = rng.normal(scale=phi_model_offset, size=(*domain_size, lie_algebra_dim)).astype(phi.dtype)

    # Adjoint action of SO(3) on so(3) ≅ R^3 is an ordinary rotation
    from scipy.spatial.transform import Rotation
    R = Rotation.random(random_state=rng).as_matrix()  # (3, 3)
    delta_rot = np.einsum("ab,...b->...a", R, delta)   # (...,3)

    phi_model_raw = phi + delta_rot

    if use_masked_blur:
        print("using mask blur\n\n")
        phi_model = masked_normalized_blur(phi_model_raw, mask, smooth_sigma or getattr(config, "phi_init_smooth_sigma", 0.5))
    else:
        phi_model = gaussian_filter(
            phi_model_raw,
            sigma=smooth_sigma or getattr(config, "phi_init_smooth_sigma", 0.5),
            mode = "wrap"
        )
        phi_model *= mask[..., None]
    return phi, phi_model


def assign_neighbors_simple(
    agents,
    overlap_eps: float = 1e-6,
    *,
    symmetric: bool = True,
    max_neighbors: int | None = None,
    topk_margin: int = 8,
) -> None:
    """
    Two agents are neighbors iff their supports overlap at any pixel:
      support_i(x,y) = (mask_i(x,y) > overlap_eps)

    Builds: a.neighbors = [{"id": <neighbor_id>, "overlap": <count>}, ...]
    If max_neighbors is set, keep the top-K by overlap (ties broken by id).
    """
    import numpy as np
    from utils import mask_hw  # use your project-local version

    if not agents:
        return

    # Flattened boolean supports once
    mvecs = []
    ids   = []
    HW = None
    for i, a in enumerate(agents):
        mv = mask_hw(a, tau=overlap_eps, mode="vec")  # (HW,) bool
        if HW is None:
            HW = mv.shape[0]
        elif mv.shape[0] != HW:
            raise ValueError("All masks must share the same (H,W) shape.")
        mvecs.append(mv.astype(np.uint8, copy=False))  # uint8 so M @ M.T counts overlaps
        ids.append(int(getattr(a, "id", i)))

    ids = np.asarray(ids, dtype=np.int64)
    M = np.stack(mvecs, axis=0)               # (N, HW) uint8
    inter = (M @ M.T).astype(np.int64, copy=False)  # (N, N) overlap counts
    np.fill_diagonal(inter, 0)

    N = len(agents)
    for i in range(N):
        row = inter[i]
        js = np.flatnonzero(row > 0)
        if js.size == 0:
            agents[i].neighbors = []
            continue

        if symmetric:
            # keep only mutual overlaps
            js = js[inter[js, i] > 0]
            if js.size == 0:
                agents[i].neighbors = []
                continue

        if (max_neighbors is not None) and (js.size > max_neighbors):
            counts = row[js]
            # overfetch to soften tie bias, then stable sort
            k_fetch = min(js.size, max_neighbors + topk_margin)
            part = np.argpartition(-counts, kth=k_fetch - 1)[:k_fetch]
            cands = js[part]

            counts_c = row[cands]
            ids_c    = ids[cands]
            order = np.lexsort((ids_c, -counts_c))  # primary: -counts, secondary: id
            chosen = cands[order][:max_neighbors]
        else:
            counts = row[js]
            order = np.lexsort((ids[js], -counts))  # primary: -counts, secondary: id
            chosen = js[order]

        agents[i].neighbors = [
            {"id": int(ids[j]), "overlap": int(row[j])} for j in chosen.tolist()
        ]





def qassign_neighbors_vectorized(
    agents: list,
    overlap_eps: float,
    max_neighbors: int,
    *,
    metric: str = "iou",          # "iou" | "minfrac" | "raw"
    binarize: bool = False,       # if True, threshold masks to {0,1}
    bin_thresh: float = 0.5,      # used when binarize=True
    symmetric: bool = False,      # if True, enforce mutual neighbors
    topk_margin: int = 8          # overfetch to break ties more fairly
) -> None:
    """
    Assign neighbors via pairwise mask overlap with robust normalization.

    metric:
      - "iou": (A∩B)/(A∪B) (preferred; handles different sizes)
      - "minfrac": (A∩B)/min(|A|,|B|) (sensitive, less harsh than IoU)
      - "raw": A∩B (only safe if masks are uniform size & truly binary)
    """
    

    if max_neighbors <= 0 or not agents:
        for a in agents:
            a.neighbors = []
        return

    # ----- Validate shapes & gather masks -----
    masks = []
    H = W = None
    for idx, a in enumerate(agents):
        m = np.asarray(getattr(a, "mask", None))
        if m is None:
            raise ValueError(f"Agent {idx} missing mask.")
        if m.ndim != 2:
            raise ValueError(f"Agent {idx} mask must be 2D (H,W); got {m.shape}.")
        if H is None:
            H, W = m.shape
        elif m.shape != (H, W):
            raise ValueError(f"All masks must share shape {(H,W)}; got {m.shape} for agent {idx}.")
        # Clean numerics
        m = np.where(np.isfinite(m), m, 0.0).astype(np.float32, copy=False)
        if binarize:
            m = (m >= float(bin_thresh)).astype(np.float32, copy=False)
        else:
            # clip weights into [0,1] to keep overlap bounded
            m = np.clip(m, 0.0, 1.0, out=m)
        masks.append(m)

    N = len(agents)
    M = np.stack([m.reshape(-1) for m in masks], axis=0)   # (N, H*W)

    # ----- Area, intersection, union -----
    areas = M.sum(axis=1)                                  # (N,)
    inter = M @ M.T                                        # (N,N)

    if metric == "raw":
        score = inter
        thresh_val = overlap_eps * float(H * W)
        keep = score > thresh_val
    elif metric == "minfrac":
        # (A∩B)/min(|A|,|B|)
        # compute min area matrix without forming big repeats unnecessarily
        a1 = areas[:, None]
        a2 = areas[None, :]
        denom = np.minimum(a1, a2)
        # avoid divide by zero
        denom = np.where(denom > 0, denom, np.inf)
        score = inter / denom
        keep = score >= float(overlap_eps)
    elif metric == "iou":
        # (A∩B)/(A∪B) = inter / (a1 + a2 - inter)
        a1 = areas[:, None]
        a2 = areas[None, :]
        union = a1 + a2 - inter
        union = np.where(union > 0, union, np.inf)
        score = inter / union
        keep = score >= float(overlap_eps)
    else:
        raise ValueError(f"Unknown metric={metric!r}")

    # remove self
    np.fill_diagonal(keep, False)

    # ----- Per-node top-k with stable tie-breaking -----
    # Build a stable secondary key: target agent's stable id (int)
    tgt_ids = np.array([int(getattr(a, "id", idx)) for idx, a in enumerate(agents)], dtype=np.int64)

    # Pre-sort ids once for tie-breaking stability
    # We'll sort by (-score, id) with a small overfetch then slice top-k
    neighbors_lists = [[] for _ in range(N)]

    for i in range(N):
        srow = score[i]
        mask_row = keep[i]
        if not np.any(mask_row):
            neighbors_lists[i] = []
            continue

        candidates = np.nonzero(mask_row)[0]
        # Overfetch k to reduce bias from equal scores
        k_fetch = min(len(candidates), max_neighbors + topk_margin)

        # Argpartition by score (descending)
        part_idx = np.argpartition(-srow[candidates], kth=k_fetch-1)[:k_fetch]
        cands_top = candidates[part_idx]

        # Stable sort by (-score, id)
        # numpy doesn't sort by tuple directly, so do lexsort with secondary last
        primary = -srow[cands_top]
        secondary = tgt_ids[cands_top].astype(np.int64)
        order = np.lexsort((secondary, primary))  # primary first (since placed last)
        chosen = cands_top[order][:max_neighbors]

        neighbors_lists[i] = [{"id": int(getattr(agents[j], "id", j)),
                               "idx": int(j),
                               "score": float(srow[j])}
                              for j in chosen]

    # ----- Optional symmetry enforcement -----
    if symmetric:
        # Keep only edges that are mutual
        mutual = [set() for _ in range(N)]
        for i in range(N):
            for nb in neighbors_lists[i]:
                mutual[i].add(nb["idx"])
        for i in range(N):
            new_list = []
            for nb in neighbors_lists[i]:
                j = nb["idx"]
                # mutual if i in j's set
                if i in mutual[j]:
                    new_list.append(nb)
            neighbors_lists[i] = new_list

    # ----- Write back, drop helper fields -----
    for i, a in enumerate(agents):
        a.neighbors = [{"id": nb["id"], "score": nb["score"]} for nb in neighbors_lists[i]]








        
