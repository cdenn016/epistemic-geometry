
F = False
T = True
# Toggle between diagonal and full Σ initialization
diagonal_sigma                = F
identical_models              = F         # If True, all agents share the same model gauge frame
morphism_identity_when_square = F

enable_vfe_theta    = F         #  theta are the world's "true" parameters - agents try to 
                                #  learn them in friston's VFE.  Here we hope to treat
                                #  cross/same scale agent-agent messaging as "true" world parameters


use_global_A        = T

enable_vfe          = F
obs_enable          = F

freeze_omega_mode  = "none"     # "none" | "identity" 

agent_seed         = 241 

# ===========================
# DOMAIN / SPATIAL SETTINGS
# ===========================
joblib_prefer           = "threads"        # or "threads" or "processes"
joblib_memmap_threshold = "20M"
blas_threads_per_worker = 1


ell_q              = 3
ell_p              = 3

spec_q             = [(ell_q, 1)]   # list[(ell, multiplicity)]
spec_p             = [(ell_p, 1)]

mix_generators_q   = F
mix_generators_p   = F
                
D                  = 2           #dimension of base manifold - d=2 validated

L                  = 12         #length of hypercubic base-manifold - PBCs

steps              = 500

N                  = 4                     # Number of agents
max_neighbors      = 4             # Max number of agent neighbors

n_jobs             = 8

agent_radius_range = (3,3)         #agent radii
fixed_location     = T 


# Dynamic β from pairwise KL of messages (legacy consumer)
obs_beta_enable    = True            # master switch
obs_beta_mode      = "softmax"       # {"softmax","exp"}
obs_beta_kappa     = 1               # κ in exp(-KL/κ)
obs_beta_clip      = (1e-4, 10.0)    # clamp after normalization
obs_beta_detach    = False           
obs_beta_q_basis   = "model_gated_q" # see beta.py "model_gated_q_rev"
obs_beta_p_basis   = "obs_to_model"  #"peer_p", "obs_to_model", "model_to_obs"

detach = False #maybe unused/redundant

# ===========================
# COUPLINGS & PENALTIES
# ===========================

alpha                   = 1
beta                    = 1
belief_mass             = 0
curvature_weight        = 0         #use if not using global A

feedback_weight         = 0
beta_model              = 1
model_mass              = 0
model_curvature_weight  = 0        #use if not using global A

A_init_scale            = 1e-2    # small noise so grads aren’t identically zero
lambda_A_curv           = 1e-2
lambda_A_cov            = 1e-2

vfe_weight              = 0      # makes alignment rise?




#==========================
#    IF NEEDED/CURIOUS
#==========================

phi_coupling_weight     = 0          # set > 0 to enable scale ~ 1e4-1e6
phi_coupling_mode       = "conjugation"  # or "conjugation"


obs_mode                = "synthetic"                #  "synthetic" or  "p-as-y"
obs_sigma2_true         = 1e-2
obs_dim                 = 2*ell_q + 1

sigma2_min              = 1e-6

#======================
#
#   LEARNING RATES
#
#======================
tau_phi                 = 1e-3
tau_phi_model           = 1e-3    
tau_mu_belief           = 1e-3       
tau_sigma_belief        = 1e-3       
tau_mu_model            = 1e-3      
tau_sigma_model         = 1e-3       

A_lr                    = 1e-5

theta_lr_W              = 1e-6
theta_lr_b              = 1e-6
theta_lr_sigma2         = 1e-6
# ===========================
# INITIALIZATION
# ===========================

# ─── Belief Bundle (q) Parameters ───
q_mu_range              = (-1.0, 1.0)              # Range for μ_q
q_sigma_range           = (0.2, 1.0)           # Diagonal Σ_q entries

belief_noise_scale_mu   = 0.01         # Additive noise for μ_q
belief_noise_scale_sigma= 0.01      # Additive noise for Σ_q


# ─── Model Bundle (p) Parameters ───
p_mu_range              = (-1.0, 1.0)             # Range for μ_p
p_sigma_range           = (0.2, 1.0)           # Diagonal Σ_p entries

model_noise_scale_mu    = 0.01          # Additive noise for μ_p
model_noise_scale_sigma = 0.01       # Additive noise for Σ_p

sigma_outside_val       = 1000  # large uncertainty outside support

phi_init_smooth_sigma   = 1.5
phi_init                = 0.1
phi_model_offset        = 0.15

# ===========================
# MASK & INTERACTION THRESHOLDS
# ===========================
 
overlap_eps             = 1e-6     # Threshold for computing inter-agent overlap
support_tau             = 1e-6           #  # Mask threshold to include point in agent support


# ===== DEBUG / DIAGNOSTICS =====

debug_phase_timing      = F
debug_grad_timing       = F

#================================
#
#  INITIALIZE GLOBAL FIELDS 
#      WITH GENTLE NOISE
#================================
use_global_belief_template = F
use_global_model_template  = F

# ===========================
# STABILITY AND CLIPPING
# ===========================
   
gradient_clip_phi         = -1     # clip ‖∇φ‖ per pixel to ≤ 1.0
gradient_clip_phi_model   = -1     # same for φ̃

theta_grad_clip           = -1
A_grad_clip               = -1

# ===========================
# EPSILONS & NUMERICAL STABILITY
# ==========================

eps                       = 1e-8 #numerical general purpose eps

domain_size               = (L,) * D
num_cores                 = 1  # or however many threads you want to use



