# -*- coding: utf-8 -*-
"""
Created on Sat Jul 26 08:43:30 2025

@author: chris and christine
"""

import numpy as np
import config
from natural_params_utils import compute_bar_eta2_qj, compute_delta_eta
from numerical_utils import safe_inv
from natural_params_utils import ( grad_eta2_from_sigma_mu, 
                                  compute_bar_eta2_q_morphed,
                                  compute_bar_eta2_p_morphed,
                                  compute_delta_eta_p_Phi_q,
                                  compute_delta_eta_q_PhiTilde_p, 
                                  natural_to_mu_sigma, apply_natural_gradient_batch_eta
                                  )




#=======================================================================
#
#                 Accumulate - need to also accum p-terms
#
#===========================================================================
def accumulate_eta_gradient_belief(agent_i, agents, params):
    """
    Accumulate ∇_{η₁_q}, ∇_{η₂_q} for agent_i directly in natural parameter space
    using variational gradients:

      - Self:     KL(q_i || Φ̃ p_i)
      - Feedback: KL(p_i || Φ q_i)
      - Alignment: KL(q_i || Ω_ij q_j)   and   KL(q_k || Ω_kj q_j) for i == j

    Stores into:
        agent_i.grad_eta1_q_field
        agent_i.grad_eta2_q_field
    """
    eps = config.support_cutoff_eps
    alpha = params.get("alpha", config.alpha)
    beta  = params.get("beta", config.beta)
    lambd = params.get("lambda", config.feedback_weight)

    # ── Masked inputs ──
    mask     = agent_i.mask > eps             # (H, W) boolean
    mask1    = mask[..., None]                # (H, W, 1)
    mask2    = mask[..., None, None]          # (H, W, 1, 1)

    eta1_q   = agent_i.eta1_q_field * mask1
    eta2_q   = agent_i.eta2_q_field * mask2
    eta1_p   = agent_i.eta1_p_field * mask1
    eta2_p   = agent_i.eta2_p_field * mask2
    Phi      = agent_i.bundle_morphism_q_to_p * mask2
    Phi_tilde = agent_i.bundle_morphism_p_to_q * mask2

    # ── Self-energy ──
    grad_eta1_self = grad_eta1_q_morphism_self(eta1_q, eta2_q, eta1_p, eta2_p, Phi_tilde, eps=eps)
    grad_eta2_self = grad_eta2_q_morphism_self(eta1_q, eta2_q, eta1_p, eta2_p, Phi_tilde, eps=eps)

    # ── Feedback ──
    grad_eta1_fb = grad_eta1_q_morphism_feedback(eta1_p, eta2_p, eta1_q, eta2_q, Phi, eps=eps)
    grad_eta2_fb = grad_eta2_q_morphism_feedback(eta1_p, eta2_p, eta1_q, eta2_q, Phi, eps=eps)

    # ── Alignment (i = source) ──
    grad_eta1_align = np.zeros_like(eta1_q)
    grad_eta2_align = np.zeros_like(eta2_q)
    for neighbor in agent_i.neighbors:
        agent_j = agents[neighbor["id"]]
        Omega_ij = agent_i.Omega @ agent_j.Omega_inv
        grad_eta1_align += grad_eta1_qi_alignment(
            eta1_q, eta2_q, agent_j.eta1_q_field * mask1, agent_j.eta2_q_field * mask2, Omega_ij, eps=eps
        )
        grad_eta2_align += grad_eta2_qi_alignment(
            eta1_q, eta2_q, agent_j.eta1_q_field * mask1, agent_j.eta2_q_field * mask2, Omega_ij, eps=eps
        )

    # ── Alignment (i = target) ──
    grad_eta1_align_rev = np.zeros_like(eta1_q)
    grad_eta2_align_rev = np.zeros_like(eta2_q)
    for agent_k in agents:
        for neighbor in agent_k.neighbors:
            if neighbor.get("id") == agent_i.id:
                Omega_kj = agent_k.Omega @ agent_i.Omega_inv
                grad_eta1_align_rev += grad_eta1_qj_alignment(
                    agent_k.eta1_q_field * mask1, agent_k.eta2_q_field * mask2, eta1_q, eta2_q, Omega_kj, eps=eps
                )
                grad_eta2_align_rev += grad_eta2_qj_alignment(
                    agent_k.eta1_q_field * mask1, agent_k.eta2_q_field * mask2, eta1_q, eta2_q, Omega_kj, eps=eps
                )

    # ── Combine ──
    grad_eta1_total = (
        alpha * grad_eta1_self +
        lambd * grad_eta1_fb +
        beta * (grad_eta1_align + grad_eta1_align_rev)
    )
    grad_eta2_total = (
        alpha * grad_eta2_self +
        lambd * grad_eta2_fb +
        beta * (grad_eta2_align + grad_eta2_align_rev)
    )

    # Mask again to clean up stray updates
    grad_eta1_total *= mask1
    grad_eta2_total *= mask2

    # Optional clipping
    grad_eta1_total = np.clip(grad_eta1_total, -config.grad_eta1_clip, config.grad_eta1_clip)
    grad_eta2_total = np.clip(grad_eta2_total, -config.grad_eta2_clip, config.grad_eta2_clip)

    # Logging
    print("eta1 grad norm [total]:", np.mean(np.linalg.norm(grad_eta1_total, axis=-1)))
    print("eta2 grad norm [total]:", np.mean(np.linalg.norm(grad_eta2_total.reshape(grad_eta2_total.shape[:-2] + (-1,)), axis=-1)))

    # Apply Fisher-preconditioned update
    delta_eta1, delta_eta2 = apply_natural_gradient_batch_eta(
        eta1_q, eta2_q, grad_eta1_total, grad_eta2_total, mask1, eps=eps
    )

    agent_i.grad_eta1_q_field += delta_eta1
    agent_i.grad_eta2_q_field += delta_eta2


def accumulate_eta_gradient_beliefold(agent_i, agents, params):
    """
    Accumulate ∇_{η₁_q}, ∇_{η₂_q} for agent_i directly in natural parameter space
    using variational gradients:

      - Self:     KL(q_i || Φ̃ p_i)
      - Feedback: KL(p_i || Φ q_i)
      - Alignment: KL(q_i || Ω_ij q_j)   and   KL(q_k || Ω_kj q_j) for i == j

    Stores into:
        agent_i.grad_eta1_q_field
        agent_i.grad_eta2_q_field
    """
    eps = config.support_cutoff_eps
    alpha = params.get("alpha", config.alpha)
    beta  = params.get("beta", config.beta)
    lambd = params.get("lambda", config.feedback_weight)

    eta1_q = agent_i.eta1_q_field
    eta2_q = agent_i.eta2_q_field
    eta1_p = agent_i.eta1_p_field
    eta2_p = agent_i.eta2_p_field
    Phi       = agent_i.bundle_morphism_q_to_p
    Phi_tilde = agent_i.bundle_morphism_p_to_q

    mask = agent_i.mask[..., None]  # (..., 1)

    # ── Self-energy: ∇_{η₁_q}, ∇_{η₂_q} KL(q || Φ̃ p) ──
    grad_eta1_self = grad_eta1_q_morphism_self(eta1_q, eta2_q, eta1_p, eta2_p, Phi_tilde, eps=eps)
    grad_eta2_self = grad_eta2_q_morphism_self(eta1_q, eta2_q, eta1_p, eta2_p, Phi_tilde, eps=eps)

    # Self-energy
    print("eta1 grad norm [self]:", np.mean(np.linalg.norm(grad_eta1_self, axis=-1)))
    print("eta2 grad norm [self]:", np.mean(np.linalg.norm(grad_eta2_self.reshape(grad_eta2_self.shape[:-2] + (-1,)), axis=-1)))


    # ── Feedback: ∇_{η₁_q}, ∇_{η₂_q} KL(p || Φ q) ──
    grad_eta1_fb = grad_eta1_q_morphism_feedback(eta1_p, eta2_p, eta1_q, eta2_q, Phi, eps=eps)
    grad_eta2_fb = grad_eta2_q_morphism_feedback(eta1_p, eta2_p, eta1_q, eta2_q, Phi, eps=eps)

    # Feedback
    print("eta1 grad norm [feedback]:", np.mean(np.linalg.norm(grad_eta1_fb, axis=-1)))
    print("eta2 grad norm [feedback]:", np.mean(np.linalg.norm(grad_eta2_fb.reshape(grad_eta2_fb.shape[:-2] + (-1,)), axis=-1)))


    # ── Alignment (i = source) ──
    grad_eta1_align = np.zeros_like(eta1_q)
    grad_eta2_align = np.zeros_like(eta2_q)
    for neighbor in agent_i.neighbors:
        agent_j = agents[neighbor["id"]]
        Omega_ij = agent_i.Omega @ agent_j.Omega_inv

        grad_eta1_align += grad_eta1_qi_alignment(
            eta1_q, eta2_q, agent_j.eta1_q_field, agent_j.eta2_q_field, Omega_ij, eps=eps
        )
        grad_eta2_align += grad_eta2_qi_alignment(
            eta1_q, eta2_q, agent_j.eta1_q_field, agent_j.eta2_q_field, Omega_ij, eps=eps
        )

    # Alignment (i = source)
    print("eta1 grad norm [align]:", np.mean(np.linalg.norm(grad_eta1_align, axis=-1)))
    print("eta2 grad norm [align]:", np.mean(np.linalg.norm(grad_eta2_align.reshape(grad_eta2_align.shape[:-2] + (-1,)), axis=-1)))


    # ── Alignment (i = target q_j in q_k ‖ Ω_kj q_j) ──
    grad_eta1_align_rev = np.zeros_like(eta1_q)
    grad_eta2_align_rev = np.zeros_like(eta2_q)
    for agent_k in agents:
        for neighbor in agent_k.neighbors:
            if neighbor.get("id") == agent_i.id:
                Omega_kj = agent_k.Omega @ agent_i.Omega_inv
                grad_eta1_align_rev += grad_eta1_qj_alignment(
                    agent_k.eta1_q_field, agent_k.eta2_q_field, eta1_q, eta2_q, Omega_kj, eps=eps
                )
                grad_eta2_align_rev += grad_eta2_qj_alignment(
                    agent_k.eta1_q_field, agent_k.eta2_q_field, eta1_q, eta2_q, Omega_kj, eps=eps
                )

    # Alignment (i = target)
    print("eta1 grad norm [align_rev]:", np.mean(np.linalg.norm(grad_eta1_align_rev, axis=-1)))
    print("eta2 grad norm [align_rev]:", np.mean(np.linalg.norm(grad_eta2_align_rev.reshape(grad_eta2_align_rev.shape[:-2] + (-1,)), axis=-1)))


    # ── Combine all η₁ and η₂ gradients ──
    grad_eta1_total = (
        alpha * grad_eta1_self +
        lambd * grad_eta1_fb +
        beta * (grad_eta1_align + grad_eta1_align_rev)
    )
    grad_eta2_total = (
        alpha * grad_eta2_self +
        lambd * grad_eta2_fb +
        beta * (grad_eta2_align + grad_eta2_align_rev)
    )

    

    mask = agent_i.mask[..., None]             # (H, W, 1)
    mask2 = agent_i.mask[..., None, None]      # (H, W, 1, 1)
    grad_eta1_total *= mask
    grad_eta2_total *= mask2


    # ── Optional: Clip gradients to avoid runaway η₂ explosions ──
    clip_eta1 = getattr(config, "grad_eta1_clip", 1e3)
    clip_eta2 = getattr(config, "grad_eta2_clip", 1e3)
    grad_eta1_total = np.clip(grad_eta1_total, -clip_eta1, clip_eta1)
    grad_eta2_total = np.clip(grad_eta2_total, -clip_eta2, clip_eta2)

    print("eta1 grad norm [total]:", np.mean(np.linalg.norm(grad_eta1_total, axis=-1)))
    print("eta2 grad norm [total]:", np.mean(np.linalg.norm(grad_eta2_total.reshape(grad_eta2_total.shape[:-2] + (-1,)), axis=-1)))


    # ── Apply Fisher-preconditioned natural gradient updates ──
    delta_eta1, delta_eta2 = apply_natural_gradient_batch_eta(
        eta1_q, eta2_q, grad_eta1_total, grad_eta2_total, mask, eps=eps
    )

    agent_i.grad_eta1_q_field += delta_eta1
    agent_i.grad_eta2_q_field += delta_eta2



from natural_params_utils import convert_eta_grads_to_mu_sigma, convert_mu_sigma_grads_to_eta_grads




#========================================================
#
#          Alignment Gradients wrt to eta1, eta2
#
#==========================================================

def grad_eta1_qi_alignment(eta1_qi, eta2_qi, eta1_qj, eta2_qj, Omega_ij, eps=1e-8):
    """
    ∇_{η₁_qi} D_KL(q_i || Ω_ij q_j)
    = -½ · η2_qi⁻¹ · bar_eta2_qj · Δη
    """
    bar_eta2_qj = compute_bar_eta2_qj(eta2_qj, Omega_ij, eps=eps)
    delta_eta   = compute_delta_eta(eta1_qi, eta2_qi, eta1_qj, eta2_qj, Omega_ij, eps=eps)
    eta2_inv_qi = safe_inv(eta2_qi, eps=eps)

    intermediate = np.einsum("...ij,...j->...i", bar_eta2_qj, delta_eta)
    grad = -0.5 * np.einsum("...ij,...j->...i", eta2_inv_qi, intermediate)

    # ───── Debug ─────
   

    return grad

def grad_eta1_qj_alignment(eta1_qi, eta2_qi, eta1_qj, eta2_qj, Omega_ij, eps=1e-8):
    """
    ∇_{η₁_qj} D_KL(q_i || Ω_ij q_j)
    = -½ · η2_qj⁻¹ · Ω_ijᵀ · bar_eta2_qj · Δη
    """
    bar_eta2_qj = compute_bar_eta2_qj(eta2_qj, Omega_ij, eps=eps)
    delta_eta   = compute_delta_eta(eta1_qi, eta2_qi, eta1_qj, eta2_qj, Omega_ij, eps=eps)
    eta2_inv_qj = safe_inv(eta2_qj, eps=eps)

    intermediate = np.einsum("...ij,...j->...i", bar_eta2_qj, delta_eta)
    Omega_T = np.swapaxes(Omega_ij, -1, -2)
    projected = np.einsum("...ij,...j->...i", Omega_T, intermediate)

    grad = -0.5 * np.einsum("...ij,...j->...i", eta2_inv_qj, projected)

    

    return grad







#===================================================================
#
#               alignment gradients with respect to eta2
#
#==================================================================




def grad_eta2_qi_alignment(eta1_qi, eta2_qi, eta1_qj, eta2_qj, Omega_ij, eps=1e-8):
    """
    ∇_{η₂_qi} D_KL(q_i || Ω_ij q_j)
    """
    eta2_inv_qi = safe_inv(eta2_qi, eps=eps)
    mu_qi = -0.5 * np.einsum("...ij,...j->...i", eta2_inv_qi, eta1_qi)
    sigma_qi = -0.5 * eta2_inv_qi

    bar_eta2_qj = compute_bar_eta2_qj(eta2_qj, Omega_ij, eps=eps)
    bar_eta2_qj = 0.5 * (bar_eta2_qj + np.swapaxes(bar_eta2_qj, -1, -2))

    grad_sigma_qi = 2.0 * eta2_qi - bar_eta2_qj
    grad_sigma_qi = 0.5 * (grad_sigma_qi + np.swapaxes(grad_sigma_qi, -1, -2))

    grad_mu_qi = grad_mu_qi_alignment(
        eta1_qi, eta2_qi, eta1_qj, eta2_qj, Omega_ij, eps=eps
    )

    return grad_eta2_from_sigma_mu(grad_sigma_qi, grad_mu_qi, mu_qi, sigma_qi)


def grad_eta2_qj_alignment(
    eta1_qi, eta2_qi,
    eta1_qj, eta2_qj,
    Omega_ij,
    eps=1e-8,
):
    """
    ∇_{η₂_qj} D_KL(q_i || Ω_ij q_j)
    """
    bar_eta2 = compute_bar_eta2_q_morphed(eta2_qj, Omega_ij, eps=eps)
    bar_eta2 = 0.5 * (bar_eta2 + np.swapaxes(bar_eta2, -1, -2))

    delta_eta = compute_delta_eta(eta1_qi, eta2_qi, eta1_qj, eta2_qj, Omega_ij, eps=eps)

    intermediate = np.einsum("...ij,...j->...i", bar_eta2, delta_eta)
    grad_mu_j = -np.einsum("...ji,...i->...j", Omega_ij, intermediate)

    mu_i, _ = natural_to_mu_sigma(eta1_qi, eta2_qi, eps=eps)
    mu_j, sigma_j = natural_to_mu_sigma(eta1_qj, eta2_qj, eps=eps)

    grad_sigma_j = grad_sigma_qj_alignment(mu_i, eta2_qi, mu_j, sigma_j, Omega_ij, eps=eps)
    grad_sigma_j = 0.5 * (grad_sigma_j + np.swapaxes(grad_sigma_j, -1, -2))

    return grad_eta2_from_sigma_mu(grad_sigma_j, grad_mu_j, mu_j, sigma_j)


#helpers
def grad_mu_qi_alignment(eta1_qi, eta2_qi, eta1_qj, eta2_qj, Omega_ij, eps=1e-8):
    bar_eta2_qj = compute_bar_eta2_qj(eta2_qj, Omega_ij, eps=eps)
    bar_eta2_qj = 0.5 * (bar_eta2_qj + np.swapaxes(bar_eta2_qj, -1, -2))  # Ensure symmetry

    delta_eta = compute_delta_eta(eta1_qi, eta2_qi, eta1_qj, eta2_qj, Omega_ij, eps=eps)
    grad_mu = np.einsum("...ij,...j->...i", bar_eta2_qj, delta_eta)
    return grad_mu


def grad_sigma_qj_alignment(eta1_qi, eta2_qi, eta1_qj, eta2_qj, Omega_ij, eps=1e-8):
    bar_eta2_qj = compute_bar_eta2_qj(eta2_qj, Omega_ij, eps=eps)
    bar_eta2_qj = 0.5 * (bar_eta2_qj + np.swapaxes(bar_eta2_qj, -1, -2))

    delta_eta   = compute_delta_eta(eta1_qi, eta2_qi, eta1_qj, eta2_qj, Omega_ij, eps=eps)
    eta2_inv_qi = safe_inv(eta2_qi, eps=eps)

    term1 = bar_eta2_qj
    term2 = np.einsum("...ik,...kl,...lj->...ij", bar_eta2_qj, eta2_inv_qi, bar_eta2_qj)
    outer = np.einsum("...i,...j->...ij", delta_eta, delta_eta)
    term3 = 0.5 * np.einsum("...ik,...kl,...lj->...ij", bar_eta2_qj, outer, bar_eta2_qj)

    inner = term1 + term2 + term3
    grad_sigma_qj = np.einsum("...ki,...ij,...jl->...kl", Omega_ij, inner, Omega_ij)

    grad_sigma_qj = 0.5 * (grad_sigma_qj + np.swapaxes(grad_sigma_qj, -1, -2))
    return grad_sigma_qj


#===================================================================
#
#               feedback gradients with respect to eta1
#
#==================================================================

def grad_eta1_q_morphism_feedback(eta1_p, eta2_p, eta1_q, eta2_q, Phi, eps=1e-8):
    """
    Compute:
        ∂KL/∂η1_q = -½ η2_q⁻¹ · (Φᵀ · bar_eta2^Φ_q · Δη)

    Inputs:
        eta1_p, eta2_p : (..., K_p), (..., K_p, K_p)
        eta1_q, eta2_q : (..., K_q), (..., K_q, K_q)
        Phi            : (..., K_p, K_q)

    Returns:
        grad_eta1_q : (..., K_q)
    """
    from numerical_utils import safe_inv
    eta2_inv_q = safe_inv(eta2_q, eps=eps)

    bar_eta2_Phi_q = compute_bar_eta2_q_morphed(eta2_q, Phi, eps=eps)
    bar_eta2_Phi_q = 0.5 * (bar_eta2_Phi_q + np.swapaxes(bar_eta2_Phi_q, -1, -2))  # Ensure symmetry

    delta_eta = compute_delta_eta_p_Phi_q(eta1_p, eta2_p, eta1_q, eta2_q, Phi, eps=eps)

    tmp = np.einsum("...ij,...j->...i", bar_eta2_Phi_q, delta_eta)     # (..., K_p)
    tmp2 = np.einsum("...ij,...i->...j", Phi, tmp)                     # (..., K_q)

    grad_eta1_q = -0.5 * np.einsum("...ij,...j->...i", eta2_inv_q, tmp2)
    return grad_eta1_q


def grad_eta1_p_morphism_feedback(eta1_p, eta2_p, eta1_q, eta2_q, Phi, eps=1e-8):
    """
    Compute:
        ∇_{η1_p} D_KL(p || Φ q)
        = -½ · η2_p⁻¹ · bar_eta2^Φ_q · Δη

    Inputs:
        eta1_p : (..., K_p)
        eta2_p : (..., K_p, K_p)
        eta1_q : (..., K_q)
        eta2_q : (..., K_q, K_q)
        Phi    : (..., K_p, K_q)

    Returns:
        grad_eta1_p : (..., K_p)
    """
    from numerical_utils import safe_inv
    eta2_inv_p = safe_inv(eta2_p, eps=eps)

    bar_eta2_Phi_q = compute_bar_eta2_q_morphed(eta2_q, Phi, eps=eps)
    bar_eta2_Phi_q = 0.5 * (bar_eta2_Phi_q + np.swapaxes(bar_eta2_Phi_q, -1, -2))  # Ensure symmetry

    delta_eta = compute_delta_eta_p_Phi_q(eta1_p, eta2_p, eta1_q, eta2_q, Phi, eps=eps)

    tmp = np.einsum("...ij,...j->...i", bar_eta2_Phi_q, delta_eta)
    grad_eta1_p = -0.5 * np.einsum("...ij,...j->...i", eta2_inv_p, tmp)
    return grad_eta1_p



#===================================================================
#
#               feedback gradients with respect to eta2
#
#==================================================================


def grad_eta2_q_morphism_feedback(eta1_p, eta2_p, eta1_q, eta2_q, Phi, eps=1e-8):
    from numerical_utils import safe_inv

    eta2_inv_q = safe_inv(eta2_q, eps=eps)
    eta2_inv_q = 0.5 * (eta2_inv_q + np.swapaxes(eta2_inv_q, -1, -2))
    mu_q = -0.5 * np.einsum("...ij,...j->...i", eta2_inv_q, eta1_q)
    sigma_q = -0.5 * eta2_inv_q

    eta2_inv_p = safe_inv(eta2_p, eps=eps)
    eta2_inv_p = 0.5 * (eta2_inv_p + np.swapaxes(eta2_inv_p, -1, -2))

    bar_eta2_Phi_q = compute_bar_eta2_q_morphed(eta2_q, Phi, eps=eps)
    bar_eta2_Phi_q = 0.5 * (bar_eta2_Phi_q + np.swapaxes(bar_eta2_Phi_q, -1, -2))

    delta_eta = compute_delta_eta_p_Phi_q(eta1_p, eta2_p, eta1_q, eta2_q, Phi, eps=eps)

    # --- Stabilized terms ---
    term1 = bar_eta2_Phi_q

    term2 = np.einsum("...ik,...kl,...lj->...ij", bar_eta2_Phi_q, eta2_inv_p, bar_eta2_Phi_q)
    term2 = 0.5 * (term2 + np.swapaxes(term2, -1, -2))  # symmetrize

    outer = np.einsum("...i,...j->...ij", delta_eta, delta_eta)
    term3 = 0.5 * np.einsum("...ik,...kl,...lj->...ij", bar_eta2_Phi_q, outer, bar_eta2_Phi_q)
    term3 = 0.5 * (term3 + np.swapaxes(term3, -1, -2))  # symmetrize

    # Optional damping on term2 and term3
    damping = 0.1
    inner = term1 + damping * term2 + damping * term3

    # Final projection back to q space
    Phi_T = np.swapaxes(Phi, -1, -2)
    temp = np.einsum("...ik,...kl->...il", Phi_T, inner)
    grad_sigma_q = np.einsum("...ik,...kj->...ij", temp, Phi)

    grad_mu_q = grad_mu_q_morphism_feedback(eta1_p, eta2_p, eta1_q, eta2_q, Phi, eps=eps)

    return grad_eta2_from_sigma_mu(grad_sigma_q, grad_mu_q, mu_q, sigma_q)



def grad_eta2_p_morphism_feedback(eta1_p, eta2_p, eta1_q, eta2_q, Phi, eps=1e-8):
    """
    Compute:
        ∇_{η2_p} D_KL(p || Φ q)
    """
    from numerical_utils import safe_inv

    eta2_inv_p = safe_inv(eta2_p, eps=eps)
    mu_p = -0.5 * np.einsum("...ij,...j->...i", eta2_inv_p, eta1_p)
    sigma_p = -0.5 * eta2_inv_p

    bar_eta2_Phi_q = compute_bar_eta2_q_morphed(eta2_q, Phi, eps=eps)
    grad_sigma_p = 2.0 * eta2_p - bar_eta2_Phi_q

    grad_mu_p = grad_mu_p_morphism_feedback(eta1_p, eta2_p, eta1_q, eta2_q, Phi, eps=eps)

    return grad_eta2_from_sigma_mu(grad_sigma_p, grad_mu_p, mu_p, sigma_p)



def grad_mu_q_morphism_feedback(eta1_p, eta2_p, eta1_q, eta2_q, Phi, eps=1e-8):
    """
    Compute:
        ∇_{μ_q} D_KL(p || Φ q) = Φᵀ · bar_eta2^Φ_q · Δη
    """
    bar_eta2_Phi_q = compute_bar_eta2_q_morphed(eta2_q, Phi, eps=eps)
    bar_eta2_Phi_q = 0.5 * (bar_eta2_Phi_q + np.swapaxes(bar_eta2_Phi_q, -1, -2))  # ensure symmetry

    delta_eta = compute_delta_eta_p_Phi_q(eta1_p, eta2_p, eta1_q, eta2_q, Phi, eps=eps)

    tmp = np.einsum("...ij,...j->...i", bar_eta2_Phi_q, delta_eta)
    Phi_T = np.swapaxes(Phi, -1, -2)
    grad_mu_q = np.einsum("...ij,...j->...i", Phi_T, tmp)

    # Optional: clip large values to prevent η₂ instability
    clip = 1e3
    grad_mu_q = np.clip(grad_mu_q, -clip, clip)

    return grad_mu_q



def grad_mu_p_morphism_feedback(eta1_p, eta2_p, eta1_q, eta2_q, Phi, eps=1e-8):
    """
    Compute:
        ∇_{μ_p} D_KL(p || Φ q) = bar_eta2^Φ_q · Δη
    """
    bar_eta2_Phi_q = compute_bar_eta2_q_morphed(eta2_q, Phi, eps=eps)
    bar_eta2_Phi_q = 0.5 * (bar_eta2_Phi_q + np.swapaxes(bar_eta2_Phi_q, -1, -2))

    delta_eta = compute_delta_eta_p_Phi_q(eta1_p, eta2_p, eta1_q, eta2_q, Phi, eps=eps)
    grad_mu_p = np.einsum("...ij,...j->...i", bar_eta2_Phi_q, delta_eta)
    return grad_mu_p






#===============================================
#
#
#
#=======================================
def grad_eta1_q_morphism_self(eta1_q, eta2_q, eta1_p, eta2_p, Phi_tilde, eps=1e-8):
    """
    ∇_{η1_q} D_KL(q || Φ̃ p)
    = -½ η2_q⁻¹ · bar_eta2^Φ̃_p · Δη
    """
    from numerical_utils import safe_inv

    eta2_inv_q = safe_inv(eta2_q, eps=eps)
    bar_eta2 = compute_bar_eta2_p_morphed(eta2_p, Phi_tilde, eps=eps)
    bar_eta2 = 0.5 * (bar_eta2 + np.swapaxes(bar_eta2, -1, -2))

    delta_eta = compute_delta_eta_q_PhiTilde_p(eta1_q, eta2_q, eta1_p, eta2_p, Phi_tilde, eps=eps)

    bar_eta_dot_delta = np.einsum("...ij,...j->...i", bar_eta2, delta_eta)
    return -0.5 * np.einsum("...ij,...j->...i", eta2_inv_q, bar_eta_dot_delta)


def grad_eta1_p_morphism_self(eta1_q, eta2_q, eta1_p, eta2_p, Phi_tilde, eps=1e-8):
    """
    ∇_{η1_p} D_KL(q || Φ̃ p)
    = +½ η2_p⁻¹ · Φ̃ᵀ · bar_eta2^Φ̃_p · Δη
    """
    from numerical_utils import safe_inv

    eta2_inv_p = safe_inv(eta2_p, eps=eps)
    bar_eta2 = compute_bar_eta2_p_morphed(eta2_p, Phi_tilde, eps=eps)
    bar_eta2 = 0.5 * (bar_eta2 + np.swapaxes(bar_eta2, -1, -2))

    delta_eta = compute_delta_eta_q_PhiTilde_p(eta1_q, eta2_q, eta1_p, eta2_p, Phi_tilde, eps=eps)

    bar_eta_dot_delta = np.einsum("...ij,...j->...i", bar_eta2, delta_eta)
    Phi_T = np.swapaxes(Phi_tilde, -1, -2)
    push_term = np.einsum("...ij,...j->...i", Phi_T, bar_eta_dot_delta)

    return 0.5 * np.einsum("...ij,...j->...i", eta2_inv_p, push_term)

def grad_eta2_q_morphism_self(
    eta1_q, eta2_q,
    eta1_p, eta2_p,
    Phi_tilde,
    eps=1e-8
):
    """
    ∇_{η₂_q} KL(q || Φ̃ p) in natural coordinates.

    Uses:
        ∇_Σ_q = η̂₂^{Φ̃}_p - η₂_q
        ∇_μ_q = η̂₂^{Φ̃}_p Δη

    Then:
        ∇_{η₂_q} = -½ Σ_q [∇_Σ_q + (∇_μ_q ⊗ μ_q)] Σ_q
    """
    from numerical_utils import safe_inv
    from natural_params_utils import natural_to_mu_sigma

    bar_eta2 = compute_bar_eta2_p_morphed(eta2_p, Phi_tilde, eps=eps)
    bar_eta2 = 0.5 * (bar_eta2 + np.swapaxes(bar_eta2, -1, -2))

    delta_eta = compute_delta_eta_q_PhiTilde_p(
        eta1_q, eta2_q, eta1_p, eta2_p, Phi_tilde, eps=eps)

    grad_sigma = bar_eta2 - eta2_q
    grad_mu = np.einsum("...ij,...j->...i", bar_eta2, delta_eta)

    mu_q, sigma_q = natural_to_mu_sigma(eta1_q, eta2_q, eps=eps)
    return grad_eta2_from_sigma_mu(grad_sigma, grad_mu, mu_q, sigma_q)


def grad_eta2_p_morphism_self(
    eta1_q, eta2_q,
    eta1_p, eta2_p,
    Phi_tilde,
    eps=1e-8
):
    """
    ∇_{η₂_p} KL(q || Φ̃ p) using full chain rule:

    First compute:
        ∇_μ_p = - Φ̃ᵀ η̂₂_p Δη
        ∇_Σ_p = Φ̃ᵀ [ η̂₂_p η₂_p⁻¹ η̂₂_p − η̂₂_p − ½ η̂₂_p Δη Δηᵀ η̂₂_p ] Φ̃

    Then:
        ∇_{η₂_p} = -½ Σ_p [∇_Σ_p + (∇_μ_p ⊗ μ_p)] Σ_p
    """
    from numerical_utils import safe_inv
    from natural_params_utils import natural_to_mu_sigma

    bar_eta2 = compute_bar_eta2_p_morphed(eta2_p, Phi_tilde, eps=eps)
    bar_eta2 = 0.5 * (bar_eta2 + np.swapaxes(bar_eta2, -1, -2))

    delta_eta = compute_delta_eta_q_PhiTilde_p(
        eta1_q, eta2_q, eta1_p, eta2_p, Phi_tilde, eps=eps)

    delta_outer = np.einsum("...i,...j->...ij", delta_eta, delta_eta)
    mahal_term = 0.5 * np.einsum("...ik,...kl,...lj->...ij",
                                 bar_eta2, delta_outer, bar_eta2)

    inv_eta2_p = safe_inv(eta2_p, eps=eps)
    triple_term = np.einsum("...ik,...kl,...lj->...ij", bar_eta2, inv_eta2_p, bar_eta2)

    grad_sigma = np.einsum("...ik,...kl,...lj->...ij",
                           Phi_tilde.swapaxes(-1, -2),
                           triple_term - bar_eta2 - mahal_term,
                           Phi_tilde)

    inner = np.einsum("...ij,...j->...i", bar_eta2, delta_eta)
    grad_mu = -np.einsum("...ji,...j->...i", Phi_tilde, inner)

    mu_p, sigma_p = natural_to_mu_sigma(eta1_p, eta2_p, eps=eps)
    return grad_eta2_from_sigma_mu(grad_sigma, grad_mu, mu_p, sigma_p)

