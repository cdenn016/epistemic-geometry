# -*- coding: utf-8 -*-
"""
Created on Wed Jul 23 10:32:58 2025

@author: chris and christine
"""
from joblib import Parallel, delayed
import numpy as np
import config
from natural_gradient import (compute_inverse_fisher_field_natural, compute_inverse_fisher_morphism_field,
                              )
from generalized_omega import exp_lie_algebra_irrep   
from generalized_math_utils import safe_batch_inverse     
from numerical_utils import sanitize_sigma                
from generalized_diagnostics_metrics import compute_alignment_field_general
from update_terms_morphisms import accumulate_morphism_feedback_gradient_natural, accumulate_morphism_self_gradient_natural


from update_terms_mu_sigma_belief import accumulate_eta_gradient_belief
#from update_terms_eta1_eta2_belief import accumulate_eta_gradient_belief
from update_terms_phi import accumulate_phi_gradient_belief, accumulate_phi_gradient_model
from update_terms_mu_sigma_model import accumulate_eta_gradient_model

from omega import exp_lie_algebra_irrep, compute_exp_field
from natural_params_utils import natural_to_mu_sigma_batch

def zero_all_gradients(agent_i):
    agent_i.grad_eta1_q_field.fill(0)
    agent_i.grad_eta2_q_field.fill(0)
    agent_i.grad_eta1_p_field.fill(0)
    agent_i.grad_eta2_p_field.fill(0)
    agent_i.grad_phi.fill(0)
    agent_i.grad_phi_tilde.fill(0)

    if agent_i.grad_Phi is not None:
        agent_i.grad_Phi.fill(0)
    if agent_i.grad_Phi_tilde is not None:
        agent_i.grad_Phi_tilde.fill(0)





def preprocess_agent_fields(agent, params):
    """Sanitize sigmas, cache Fisher info, compute exp(φ), exp(−φ), and Fisher metrics."""
    e_belief = params.get("e_belief", config.e_belief)
    e_model  = params.get("e_model",  config.e_model)

    agent.clear_omega_cache()

    # ───── Fetch Lie algebra generators ─────
    G_q = agent.rho_q_func.generators  # (d_q, K_q, K_q)
    G_p = agent.rho_p_func.generators  # (d_p, K_p, K_p)

    # ───── Optional Fisher metric cache (used only if fisher_geometry_weight > 0) ─────
    if config.fisher_geometry_weight > 0:
        _, sigma_q = natural_to_mu_sigma_batch(agent.eta1_q_field, agent.eta2_q_field, eps=config.eps)
        agent.cached_fisher_q = safe_batch_inverse(sigma_q, name="σ_q")

    if config.fisher_model_geometry_weight > 0:
        _, sigma_p = natural_to_mu_sigma_batch(agent.eta1_p_field, agent.eta2_p_field, eps=config.eps)
        agent.cached_fisher_p = safe_batch_inverse(sigma_p, name="σ_p")

    # ───── Compute exp(φ), exp(−φ) for belief ─────
    agent._exp_phi = compute_exp_field(agent.phi, G_q, e_belief, max_norm=config.phi_exp_clip)
    agent._exp_neg_phi = safe_batch_inverse(agent._exp_phi)

    # ───── Compute exp(φ_model), exp(−φ_model) for model ─────
    agent._exp_phi_model = compute_exp_field(agent.phi_model, G_p, e_model, max_norm=config.phi_exp_clip)
    agent._exp_neg_phi_model = safe_batch_inverse(agent._exp_phi_model)

    # ───── Inverse Fisher metrics for φ and morphisms ─────
    agent.inverse_fisher_phi        = compute_inverse_fisher_field_natural(agent.eta2_q_field, G_q)
    agent.inverse_fisher_phi_model  = compute_inverse_fisher_field_natural(agent.eta2_p_field, G_p)

    # ───── Inverse Fisher for morphisms (optional) ─────
    if getattr(config, "use_dynamic_morphisms", True):
        agent.inverse_fisher_Phi = compute_inverse_fisher_morphism_field(
           agent, generators=params["generators_Phi"], direction="q_to_p"
       )

        agent.inverse_fisher_Phi_tilde = compute_inverse_fisher_morphism_field(
           agent, generators=params["generators_Phi_tilde"], direction="p_to_q"
       )
    else:
       agent.inverse_fisher_Phi = None
       agent.inverse_fisher_Phi_tilde = None



def compute_all_gradients(agent_i, agents, generators_q, generators_p, params):
    zero_all_gradients(agent_i)

    accumulate_eta_gradient_belief(agent_i, agents, params)
    accumulate_eta_gradient_model(agent_i, agents, params)

    for nb in agent_i.neighbors:
        agent_j = agents[nb["id"]]
        accumulate_phi_gradient_belief(agent_i, agent_j, generators_q, params)
        accumulate_phi_gradient_model(agent_i, agent_j, generators_p, params)


        # ─── Morphism feedback term: KL(p ‖ Φ·q) ───
    if getattr(config, "use_dynamic_morphisms", True):
        feedback_weight = params.get("feedback_weight", config.feedback_weight)
        generators_Phi = params.get("generators_Phi", None)
        print(f"[DEBUG] generators_Phi present: {generators_Phi is not None}")
        if generators_Phi is not None:
            G_inv_field = getattr(agent_i, "inverse_fisher_Phi", None)
            accumulate_morphism_feedback_gradient_natural(
                agent_i,
                feedback_weight=feedback_weight,
                G_inv_field=G_inv_field,
                generators=generators_Phi,
            )

        # ─── Morphism self-term: KL(q ‖ Φ̃·p) ───
        generators_Phi_tilde = params.get("generators_Phi_tilde", None)
        if generators_Phi_tilde is not None:
            G_inv_field = getattr(agent_i, "inverse_fisher_Phi_tilde", None)
            accumulate_morphism_self_gradient_natural(
                agent_i,
                alpha=params.get("alpha", config.alpha),
                G_inv_field=G_inv_field,
                generators=generators_Phi_tilde,
            )


    return (
        (agent_i.grad_eta1_q_field, agent_i.grad_eta2_q_field),
        (agent_i.grad_eta1_p_field, agent_i.grad_eta2_p_field),
        agent_i.grad_phi,
        agent_i.grad_phi_tilde,
        agent_i.grad_Phi,
        agent_i.grad_Phi_tilde,
        )


def compute_adaptive_eta(base_eta, grad, cached_kl, eta2_field, scaling_kl, scaling_cond, eta_min, eps=1e-8):
    """
    Computes adaptive step size η based on KL alignment and condition number of η₂ (inverse covariance).
    """

    # Term from KL divergence or fallback to grad magnitude
    kl_term = (
        np.mean(cached_kl)
        if cached_kl is not None and np.isfinite(np.mean(cached_kl))
        else np.mean(np.abs(grad))
    )

    # Use η₂ (natural param) instead of Σ
    try:
        eta2_reshaped = eta2_field.reshape(-1, eta2_field.shape[-2], eta2_field.shape[-1])
        conds = np.linalg.cond(eta2_reshaped + eps * np.eye(eta2_field.shape[-1]))  # Stabilize
        cond_avg = np.mean(conds)
    except Exception:
        cond_avg = 1.0

    denom = 1.0 + scaling_kl * kl_term + scaling_cond * cond_avg
    eta_scaled = base_eta / denom
    return np.clip(eta_scaled, eta_min, base_eta)




def apply_phi_updates(agent, grad_phi, grad_phi_m, mask, params):
    mask_exp = mask[..., None]

    def clip_lie_update(delta, threshold):
        if threshold <= 0:
            return delta
        norm = np.linalg.norm(delta, axis=-1, keepdims=True)
        factor = np.minimum(1.0, threshold / (norm + 1e-8))
        return delta * factor

    # Extract config safely
    cfg = {k: getattr(config, k) for k in dir(config) if not k.startswith("__")}
    if params is not None:
        cfg.update(params)

    # φ adaptive update (belief)
    eta_phi_tuned = compute_adaptive_eta(
        cfg["eta_base_phi"],
        grad_phi,
        getattr(agent, "cached_alignment_kl", None),
        agent.eta2_q_field,                          # ← PATCHED
        cfg["eta_phi_adaptive_scaling"],
        cfg["eta_sigma_condition_scaling"],
        cfg["eta_phi_min"],
    )
    delta_phi = eta_phi_tuned * grad_phi
    delta_phi = clip_lie_update(delta_phi, cfg.get("phi_grad_clip", 0.0))
    delta_phi = np.nan_to_num(delta_phi, nan=0.0, posinf=1e5, neginf=-1e5)
    agent.phi -= delta_phi * mask_exp

    # φ̃ adaptive update (model)
    eta_phi_m_tuned = compute_adaptive_eta(
        cfg["eta_base_phi_model"],
        grad_phi_m,
        getattr(agent, "cached_model_alignment_kl", None),
        agent.eta2_p_field,                          # ← PATCHED
        cfg["eta_phi_model_adaptive_scaling"],
        cfg["eta_sigma_condition_scaling"],
        cfg["eta_phi_model_min"],
    )
    delta_phi_m = eta_phi_m_tuned * grad_phi_m
    delta_phi_m = clip_lie_update(delta_phi_m, cfg.get("phi_model_grad_clip", 0.0))
    delta_phi_m = np.nan_to_num(delta_phi_m, nan=0.0, posinf=1e5, neginf=-1e5)
    agent.phi_model -= delta_phi_m * mask_exp



#from metrics import compute_alignment_field_general

from generalized_diagnostics_metrics import compute_alignment_field_general

def synchronous_step(agents, generators_q, generators_p, params=None, n_jobs=1):
    params = params or {}
    N = len(agents)
    print(f"[DEBUG] Using {n_jobs} workers in synchronous_step")

    # Step 1: Preprocess Fisher, exp(φ), etc.
    Parallel(n_jobs=n_jobs, backend="threading", batch_size=1)(
        delayed(preprocess_agent_fields)(A, params) for A in agents
    )

    # Step 2: Refresh KL alignment caches
    for A in agents:
        A.cached_alignment_kl       = compute_alignment_field_general(agents, A.id, field_type="belief", log_eps=config.eps)
        A.cached_model_alignment_kl = compute_alignment_field_general(agents, A.id, field_type="model",  log_eps=config.eps)

    # Step 3: Compute all gradients (including morphism gradients)
    grads = Parallel(n_jobs=n_jobs, backend="loky", batch_size=2)(
        delayed(compute_all_gradients)(agent_i, agents, generators_q, generators_p, params)
        for agent_i in agents
        )

    q_updates, p_updates, phi_grads, phi_m_grads, morphism_grads, morphism_tilde_grads = zip(*grads)
    mask_list = [A.mask for A in agents]

    eta_q = params.get("eta_q", config.eta_q)
    eta_p = params.get("eta_p", config.eta_p)
    lr_phi     = params.get("phi_morphism_lr", getattr(config, "phi_morphism_lr", 1e-3))
    lr_phi_til = params.get("phi_tilde_morphism_lr", getattr(config, "phi_tilde_morphism_lr", 1e-3))

    # Step 4: Apply all updates
    def apply_agent_updates(i):
        agent = agents[i]
        mask = mask_list[i]

        Δη1_q, Δη2_q = q_updates[i]
        Δη1_p, Δη2_p = p_updates[i]

        dPhi       = morphism_grads[i]
        dPhi_tilde = morphism_tilde_grads[i]

        mask_mu    = mask[..., None]
        mask_sigma = mask[..., None, None]

                # Apply updates in natural parameter space
        agent.eta1_q_field -= eta_q * Δη1_q * mask_mu
        agent.eta2_q_field -= eta_q * Δη2_q * mask_sigma
        agent.eta1_p_field -= eta_p * Δη1_p * mask_mu
        agent.eta2_p_field -= eta_p * Δη2_p * mask_sigma

        # Apply phi field updates
        apply_phi_updates(agent, phi_grads[i], phi_m_grads[i], mask, params)

        # Extract and apply only Φ and Φ̃ updates
        dPhi_tilde_matrix = dPhi_tilde["grad_Phi"] if isinstance(dPhi_tilde, dict) else dPhi_tilde
        dPhi_matrix       = dPhi["grad_Phi"]       if isinstance(dPhi, dict) else dPhi

        agent.bundle_morphism_p_to_q -= lr_phi_til * dPhi_tilde_matrix  # Φ̃ : P → Q
        agent.bundle_morphism_q_to_p -= lr_phi      * dPhi_matrix        # Φ : Q → P

        return agent


    Parallel(n_jobs=n_jobs, backend="threading", batch_size="auto")(  # Apply updates in parallel
        delayed(apply_agent_updates)(i) for i in range(N)
    )

    return agents
