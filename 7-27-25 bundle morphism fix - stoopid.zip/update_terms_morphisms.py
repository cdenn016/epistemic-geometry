# -*- coding: utf-8 -*-
"""
Created on Wed Jul 23 06:38:37 2025

@author: chris and christine
"""
import numpy as np
from natural_gradient import dexpinv_operator_morphism  # you will need to implement this
from numerical_utils import safe_inv, sanitize_sigma
from get_generators import get_generators
import config   
#==============================================================================
#
#                    Apply Natural Gradient to Bundle Morphism
#
#==============================================================================
from natural_gradient import compute_fisher_metric_rectangular_natural 



def accumulate_morphism_feedback_gradient_natural(
    agent_i,
    feedback_weight,
    G_inv_field,
    generators,
    mask=None,
    eps=1e-8,
):
    """
    Accumulate natural gradient ∇_Φ D_KL(p || Φ·q) into agent_i.grad_Phi
    using the natural parameter formulation.

    Args:
        agent_i        : Agent object with eta_q, eta_p, and bundle_morphism_q_to_p
        feedback_weight: scaling factor (e.g. config.alpha_feedback)
        G_inv_field    : (..., d, d), rectangular inverse Fisher metric for Φ
        generators     : (d, K_p, K_q), Lie generators for rectangular morphism
        mask           : (...), optional spatial mask
        eps            : stability epsilon
    """
    
    # --- Step 1: Compute Euclidean gradient in η-space ---
    grad_euclidean = grad_kl_morphism_natural_feedback(
        eta1_p = agent_i.eta1_p_field,
        eta2_p = agent_i.eta2_p_field,
        eta1_q = agent_i.eta1_q_field,
        eta2_q = agent_i.eta2_q_field,
        Phi = agent_i.bundle_morphism_q_to_p,
        eps = eps,
    )
    
    grad_euclidean = np.nan_to_num(grad_euclidean)
    

    # --- Step 1.5: Optional spatial mask ---
    if mask is not None:
        grad_euclidean *= mask[..., None, None]

    # --- Step 2: Project to natural gradient using rectangular dexpinv ---
    grad_natural = dexpinv_operator_morphism(
        Phi = agent_i.bundle_morphism_q_to_p,
        grad_Phi = grad_euclidean,
        generators = generators,
        fisher_inv_field = G_inv_field,
        eps = eps,
    )
    grad_natural = np.nan_to_num(grad_natural)

    # --- Step 3: Norm check and clipping ---
    norm = np.linalg.norm(grad_natural)
    if not np.isfinite(norm):
        print("[WARNING] grad_natural norm is NaN or Inf — zeroing update")
        grad_natural = np.zeros_like(grad_natural)
        norm = 0.0

    if getattr(config, "debug_gradients", False):
        print(f"[Grad Phi] Grad Phi norm = {norm:.2e}")

    threshold = getattr(config, "gradient_clip", 1e5)
    if getattr(config, "clip_morphism_grad", True) and norm > threshold:
        grad_natural *= threshold / (norm + eps)
        if getattr(config, "debug_gradients", False):
            print(f"[CLIP] Phi gradient norm {norm:.2e} clipped to {threshold:.1e}")

    # --- Step 4: Accumulate Lie algebra gradient into matrix ---
    delta_Phi_matrix = np.einsum("...a,aij->...ij", grad_natural, generators)
    agent_i.grad_Phi += feedback_weight * np.nan_to_num(delta_Phi_matrix)


def accumulate_morphism_self_gradient_natural(
    agent_i,
    alpha,
    generators,
    G_inv_field,
    mask=None,
    eps=1e-8,
):
    """
    Accumulate natural gradient ∇_{Φ̃} D_KL(q || Φ̃·p) into agent_i.grad_Phi_tilde,
    using natural parameter formulation.

    Args:
        agent_i     : Agent object with eta_q, eta_p, and Φ̃ = bundle_morphism_p_to_q
        alpha       : weight for the KL term (e.g. config.alpha_belief)
        generators  : shape (d, K_q, K_p), Lie generators for rectangular morphism
        G_inv_field : shape (..., d, d), inverse Fisher metric for Φ̃
        mask        : shape (...,), optional spatial mask
        eps         : numerical stability epsilon
    """

  
    grad_euclidean = grad_kl_morphism_natural_self(
        eta1_q = agent_i.eta1_q_field,
        eta2_q = agent_i.eta2_q_field,
        eta1_p = agent_i.eta1_p_field,
        eta2_p = agent_i.eta2_p_field,
        Phi_tilde = agent_i.bundle_morphism_p_to_q,
        eps = eps,
    )
    grad_euclidean = np.nan_to_num(grad_euclidean)

    # --- Step 1.5: Apply mask if provided ---
    if mask is not None:
        grad_euclidean *= mask[..., None, None]

    # --- Step 2: Project Euclidean → natural gradient ---
    grad_natural = dexpinv_operator_morphism(
        Phi=agent_i.bundle_morphism_p_to_q,
        grad_Phi=grad_euclidean,
        generators=generators,
        fisher_inv_field=G_inv_field,
        eps=eps,
    )
    grad_natural = np.nan_to_num(grad_natural)

    # --- Step 3: Optional gradient clipping ---
    norm = np.linalg.norm(grad_natural)
    if getattr(config, "debug_gradients", False):
        print(f"[Grad Phi~] Norm = {norm:.2e}")

    threshold = getattr(config, "gradient_clip", 1e5)
    if getattr(config, "clip_morphism_grad", True) and norm > threshold:
        grad_natural *= threshold / (norm + eps)
        if getattr(config, "debug_gradients", False):
            print(f"[CLIP] Phi~ gradient clipped to {threshold:.1e}")

    # --- Step 4: Convert Lie algebra back to matrix form and accumulate ---
    delta_Phi_tilde = np.einsum("...a,aij->...ij", grad_natural, generators)
    agent_i.grad_Phi_tilde += alpha * np.nan_to_num(delta_Phi_tilde)



def grad_kl_morphism_natural_feedback(
    eta1_p, eta2_p,     # (..., K_p), (..., K_p, K_p)
    eta1_q, eta2_q,     # (..., K_q), (..., K_q, K_q)
    Phi,                # (..., K_p, K_q)
    eps=1e-8
):
    """
    Compute ∇_Φ D_KL(p || Φ q) in natural parameter space.

    Returns:
        grad: (..., K_p, K_q)
    """
    from natural_params_utils import (
        compute_bar_eta2_q_morphed,
        compute_delta_eta_p_Phi_q,
        safe_inv,
    )

    eta2_p_inv = safe_inv(eta2_p, eps=eps)
    bar_eta_q = compute_bar_eta2_q_morphed(eta2_q, Phi, eps=eps)
    delta_eta = compute_delta_eta_p_Phi_q(eta1_p, eta2_p, eta1_q, eta2_q, Phi, eps=eps)

    term1 = np.einsum("...ik,...kl,...lj->...ij", bar_eta_q, eta2_p_inv, bar_eta_q)
    term2 = bar_eta_q
    outer = np.einsum("...i,...j->...ij", delta_eta, delta_eta)
    term3 = np.einsum("...ik,...kl,...lj->...ij", bar_eta_q, outer, bar_eta_q)

    inner = 0.5 * (term1 - term2 - term3)

    # Final contraction with Phi · eta2_q^{-1}
    eta2_q_inv = safe_inv(eta2_q, eps=eps)
    Phi_eta_inv = np.einsum("...ik,...kj->...ij", Phi, eta2_q_inv)
    grad = np.einsum("...ij,...jk->...ik", inner, Phi_eta_inv)

    return grad



def grad_kl_morphism_natural_self(
    eta1_q, eta2_q,     # (..., K_q), (..., K_q, K_q)
    eta1_p, eta2_p,     # (..., K_p), (..., K_p, K_p)
    Phi_tilde,          # (..., K_q, K_p)
    eps=1e-8
):
    """
    Compute ∇_{tilde_Φ} D_KL(q || tilde_Φ p) in natural parameter space.

    Returns:
        grad: (..., K_q, K_p)
    """
    from natural_params_utils import (
        compute_bar_eta2_p_morphed,
        compute_delta_eta_q_PhiTilde_p,
        safe_inv,
    )

    eta2_q_inv = safe_inv(eta2_q, eps=eps)
    eta2_p_inv = safe_inv(eta2_p, eps=eps)

    bar_eta_p = compute_bar_eta2_p_morphed(eta2_p, Phi_tilde, eps=eps)
    delta_eta = compute_delta_eta_q_PhiTilde_p(eta1_q, eta2_q, eta1_p, eta2_p, Phi_tilde, eps=eps)

    term1 = bar_eta_p
    term2 = np.einsum("...ik,...kl,...lj->...ij", bar_eta_p, eta2_q_inv, bar_eta_p)
    outer = np.einsum("...i,...j->...ij", delta_eta, delta_eta)
    term3 = np.einsum("...ik,...kl,...lj->...ij", bar_eta_p, outer, bar_eta_p)

    inner = term1 - term2 - term3

    Phi_eta_inv = np.einsum("...ik,...kj->...ij", Phi_tilde, eta2_p_inv)
    grad = 0.5 * np.einsum("...ij,...jk->...ik", inner, Phi_eta_inv)

    return grad









