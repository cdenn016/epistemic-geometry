# Updated generalized_agent_schema.py with default grad_phi and grad_phi_tilde
from dataclasses import dataclass, field
from typing import Any, Dict, List, Tuple, Optional
import numpy as np
import config
from natural_params_utils import compute_mu_sigma_from_natural  # must exist
from omega import compute_exp_field


@dataclass
class Agent:
    id: int
    center: Tuple[int, ...]
    radius: float
    mask: np.ndarray

    phi: np.ndarray
    phi_model: np.ndarray
    neighbors: List[Dict[str, Any]] = field(default_factory=list)
    metrics_log: List[Dict[str, Any]] = field(default_factory=list)

    eta1_q_field: Optional[np.ndarray] = field(default=None, init=True, repr=False)
    eta2_q_field: Optional[np.ndarray] = field(default=None, init=True, repr=False)
    eta1_p_field: Optional[np.ndarray] = field(default=None, init=True, repr=False)
    eta2_p_field: Optional[np.ndarray] = field(default=None, init=True, repr=False)

    # Lie algebra generators — required for gauge field evaluation
    generators_q: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    generators_p: Optional[np.ndarray] = field(default=None, init=False, repr=False)


    # Runtime cache fields
    _exp_phi: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    _exp_neg_phi: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    _exp_phi_model: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    _exp_neg_phi_model: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    transport_cache: Dict[str, Any] = field(default_factory=dict, init=False)

    # Morphism fields
    bundle_morphism_q_to_p: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    bundle_morphism_p_to_q: Optional[np.ndarray] = field(default=None, init=False, repr=False)

    # Natural gradient fields
    grad_eta1_q_field: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    grad_eta2_q_field: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    grad_eta1_p_field: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    grad_eta2_p_field: Optional[np.ndarray] = field(default=None, init=False, repr=False)

    grad_phi: np.ndarray = field(init=False, repr=False)
    grad_phi_tilde: np.ndarray = field(init=False, repr=False)
    grad_Phi: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    grad_Phi_tilde: Optional[np.ndarray] = field(default=None, init=False, repr=False)

    # Fisher caches
    inverse_fisher_phi: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    inverse_fisher_phi_model: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    inverse_fisher_Phi: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    inverse_fisher_Phi_tilde: Optional[np.ndarray] = field(default=None, init=False, repr=False)

    # Diagnostics
    fisher_I: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    pull_M_vis: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    pull_Delta: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    pull_M_dark: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    spatial_G: Optional[np.ndarray] = field(default=None, init=False, repr=False)

    def __post_init__(self):
        self.grad_phi = np.zeros_like(self.phi)
        self.grad_phi_tilde = np.zeros_like(self.phi_model)

        # Morphism gradients initialized if morphisms exist
        self.grad_Phi = np.zeros_like(self.bundle_morphism_q_to_p) if self.bundle_morphism_q_to_p is not None else None
        self.grad_Phi_tilde = np.zeros_like(self.bundle_morphism_p_to_q) if self.bundle_morphism_p_to_q is not None else None

    # On-demand conversion to μ and Σ
    @property
    def mu_q_field(self):
        mu, _ = compute_mu_sigma_from_natural(self.eta1_q_field, self.eta2_q_field)
        return mu

    @property
    def sigma_q_field(self):
        _, sigma = compute_mu_sigma_from_natural(self.eta1_q_field, self.eta2_q_field)
        return sigma

    @property
    def mu_p_field(self):
        mu, _ = compute_mu_sigma_from_natural(self.eta1_p_field, self.eta2_p_field)
        return mu

    @property
    def sigma_p_field(self):
        _, sigma = compute_mu_sigma_from_natural(self.eta1_p_field, self.eta2_p_field)
        return sigma

    @property
    def grid_shape(self) -> Tuple[int, ...]:
        return self.eta1_q_field.shape[:-1]

    @property
    def Omega(self):
        return compute_exp_field(
            self.phi,                   # (H, W, d)
            self.generators_q,          # (d, K, K)
            scale=config.phi_scale,     # or 1.0 if already normalized
            group_name=config.group_name,
            )


    @property
    def Omega_inv(self):
        Omega_val = compute_exp_field(
            self.phi,
            self.generators_q,
            scale=config.phi_scale,
            group_name=config.group_name,
            )
        return np.linalg.inv(Omega_val)



    @property
    def Omega_model(self) -> np.ndarray:
        """
        Returns ρ_p(exp(φ_p)) — the gauge transport operator for the model fiber.
        """
        return compute_exp_field(
            self.phi_model,              # (H, W, d)
            self.generators_p,           # (d, K, K)
            scale=config.phi_scale,
            group_name=config.group_name,
            )

    @property
    def Omega_model_inv(self) -> np.ndarray:
        """
        Returns ρ_p(exp(-φ_p)) — the inverse transport operator for the model fiber.
        """
        neg_phi = -self.phi_model
        return compute_exp_field(
            neg_phi,
            self.generators_p,
            scale=config.phi_scale,
            group_name=config.group_name,
        )   


    @property
    def bundle_morphism(self) -> Optional[np.ndarray]:
        return self.bundle_morphism_q_to_p

    @property
    def bundle_morphism_model(self) -> Optional[np.ndarray]:
        return self.bundle_morphism_p_to_q

    def log_metrics(self, step: int, stats: Dict[str, Any]) -> None:
        self.metrics_log.append({'step': step, **stats})

    def clear_omega_cache(self) -> None:
        self._exp_phi = None
        self._exp_neg_phi = None
        self._exp_phi_model = None
        self._exp_neg_phi_model = None
        self.transport_cache.clear()

    def clear_diagnostics(self) -> None:
        self.fisher_I = None
        self.pull_M_vis = None
        self.pull_Delta = None
        self.pull_M_dark = None
        self.spatial_G = None

    def clear_fisher_caches(self) -> None:
        self.inverse_fisher_phi = None
        self.inverse_fisher_phi_model = None
        self.inverse_fisher_Phi = None
        self.inverse_fisher_Phi_tilde = None

