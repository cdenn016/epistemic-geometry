# -*- coding: utf-8 -*-
"""
generalized_math_utils.py — Core math utilities for φ updates, KL divergence, and field ops.
"""
# Core scientific packages
import numpy as np
from scipy.ndimage import laplace

# Local configuration
import config

# Local utility modules
from numerical_utils import sanitize_sigma, safe_inv, safe_logdet
from mask_utils import clip_and_mask_gradient
from omega import exp_lie_algebra_irrep
from natural_gradient import compute_inverse_fisher_field_natural
from natural_params_utils import natural_to_mu_sigma_batch
from omega import compute_exp_field
from natural_gradient import compute_inverse_fisher_morphism_field




import numpy as np
from numerical_utils import sanitize_sigma, safe_inv, safe_logdet


def kl_divergenceN(
    eta1_1, eta2_1,
    eta1_2, eta2_2,
    mask=None,
    eps=1e-8
):
    """
    Batched KL[𝒩(η₁₁, η₂₁) || 𝒩(η₁₂, η₂₂)] in natural parameters.

    Args:
        eta1_1: (..., K)     — first η₁ (e.g. q)
        eta2_1: (..., K, K)  — first η₂
        eta1_2: (..., K)     — second η₁ (e.g. p)
        eta2_2: (..., K, K)  — second η₂
        mask:   (...,) optional — multiplies KL result
        eps:    float — numerical stabilizer

    Returns:
        kl: (...,) — KL divergence values (zero where masked)
    """
    # ── Sanitize η₂ fields ──
    eta2_1 = sanitize_eta2(eta2_1, eps=eps)
    eta2_2 = sanitize_eta2(eta2_2, eps=eps)

    # ── θ = ∇A(η) = (μ, Σ + μμᵀ) ──
    theta1_1, theta2_1 = grad_log_partition(eta1_1, eta2_1, eps=eps)
    theta1_2, theta2_2 = grad_log_partition(eta1_2, eta2_2, eps=eps)

    # ⟨η₁, θ₁ - θ₂⟩
    dtheta1 = theta1_1 - theta1_2
    dtheta2 = theta2_1 - theta2_2

    inner1 = np.einsum("...i,...i->...", eta1_1, dtheta1)
    inner2 = np.einsum("...ij,...ij->...", eta2_1, dtheta2)
    inner = inner1 + inner2

    # ── A(η) terms ──
    A1 = log_partition_function(eta1_1, eta2_1, eps=eps)
    A2 = log_partition_function(eta1_2, eta2_2, eps=eps)

    kl = inner - A1 + A2

    # ── Optional masking ──
    if mask is not None:
        mask = np.asarray(mask)
        if mask.ndim == 2:
            mask = np.squeeze(mask, axis=-1)
        kl *= mask

    # ── Final safety ──
    kl = np.nan_to_num(kl, nan=0.0, posinf=1e6, neginf=0.0)
    kl = np.clip(kl, 0.0, 1e6)
    return kl



def kl_divergence(mu1, sigma1, mu2, sigma2, mask=None, eps=1e-6):
    """
    Batched KL[𝒩(μ₁, Σ₁) || 𝒩(μ₂, Σ₂)] for full MVG fields.

    Args:
        mu1:    (N, K)
        sigma1: (N, K, K)
        mu2:    (N, K)
        sigma2: (N, K, K)
        mask:   (N,) or (N, 1) optional — multiplies KL result
        log_eps: float — numerical stabilizer for log and inversion

    Returns:
        kl_vals: (N,) KL divergence values (0 where masked out)
    """
    mu1 = np.asarray(mu1)
    mu2 = np.asarray(mu2)
    sigma1 = np.asarray(sigma1)
    sigma2 = np.asarray(sigma2)

    assert mu1.shape == mu2.shape
    assert sigma1.shape == sigma2.shape
    N, K = mu1.shape

    # ── Step 1: sanitize inputs ──
    sigma1 = sanitize_sigma(sigma1, eps=eps)
    sigma2 = sanitize_sigma(sigma2, eps=eps)

    # ── Step 2: invert and logdet (reuse sigma2_inv) ──
    sigma2_inv = safe_inv(sigma2, eps=eps)        # (N, K, K)
    logdet1    = safe_logdet(sigma1, eps=eps)     # (N,)
    logdet2    = safe_logdet(sigma2, eps=eps)     # (N,)

    # ── Step 3: Tr[Σ₂⁻¹ Σ₁] ──
    trace_term = np.einsum("nij,njk->nik", sigma2_inv, sigma1)
    trace_term = np.trace(trace_term, axis1=-2, axis2=-1)  # (N,)

    # ── Step 4: Mahalanobis (μ₂ − μ₁)^T Σ₂⁻¹ (μ₂ − μ₁) ──
    diff = mu2 - mu1  # (N, K)
    mahal = np.einsum("ni,nij,nj->n", diff, sigma2_inv, diff)  # (N,)

    # ── Step 5: Final KL expression ──
    kl = 0.5 * (trace_term + mahal - K + logdet2 - logdet1)  # (N,)

    # ── Step 6: Optional masking ──
    if mask is not None:
        mask = np.asarray(mask)
        if mask.ndim == 2:
            mask = np.squeeze(mask, axis=-1)
        kl *= mask

    # ── Step 7: Safety check ──
    if np.any(np.isnan(kl)) or np.any(np.isinf(kl)):
        raise ValueError("[KL Divergence] NaN or Inf detected in KL output")

    return kl

from numerical_utils import sanitize_eta2
from natural_params_utils import log_partition_function, mean_from_natural, cov_from_natural

def grad_log_partition(eta1, eta2, eps=1e-8):
    eta2 = sanitize_eta2(eta2, eps=eps)  # <- safety for all internal uses
    mu = mean_from_natural(eta1, eta2, eps=eps)
    Sigma = cov_from_natural(eta1, eta2, eps=eps)
    theta1 = mu
    theta2 = Sigma + np.einsum("...i,...j->...ij", mu, mu)
    return theta1, theta2



def laplacian_field(field):
    """
    Computes componentwise Laplacian of a field over its last axis.

    Parameters:
        field: ndarray (..., K)

    Returns:
        Laplacian of shape (..., K)
    """
    if field.ndim < 2:
        raise ValueError("laplacian_field expects at least 2D array (..., K)")
    return np.stack([laplace(field[..., i]) for i in range(field.shape[-1])], axis=-1)



def safe_batch_inverse(S, name="Σ", mask=None):
    """
    Inverts (H, W, K, K) SPD field with fallback and optional mask.
    """
    H, W, K, _ = S.shape
    eye_K = np.eye(K, dtype=S.dtype)
    inv_S = np.zeros_like(S)

    flat_S = S.reshape(-1, K, K)
    flat_mask = mask.reshape(-1) if mask is not None else np.ones(H * W, dtype=bool)

    for idx in range(H * W):
        if not flat_mask[idx]:
            inv_S.reshape(-1, K, K)[idx] = eye_K
            continue
        try:
            inv_S.reshape(-1, K, K)[idx] = np.linalg.inv(flat_S[idx])
        except np.linalg.LinAlgError:
            inv_S.reshape(-1, K, K)[idx] = eye_K
            if config.debug:
                i, j = divmod(idx, W)
                print(f"[WARN] Inversion failed at ({i},{j}) for {name} — using identity")

    return inv_S



def to_natural_params(mu, sigma, eps=1e-6):
    """
    Convert (μ, Σ) to natural parameters (θ₁, θ₂) for multivariate Gaussians.
    θ₁ = Σ⁻¹ μ, θ₂ = -½ Σ⁻¹
    """
    sigma = sanitize_sigma(sigma, eps=eps)
    inv_sigma = safe_inv(sigma, eps=eps)
    theta1 = np.einsum("...ij,...j->...i", inv_sigma, mu)
    theta2 = -0.5 * inv_sigma
    return theta1, theta2


def from_natural_params(theta1, theta2, eps=1e-6):
    """
    Convert natural parameters (θ₁, θ₂) back to (μ, Σ), ensuring stability.
    """
    inv_sigma = -2.0 * theta2
    inv_sigma = 0.5 * (inv_sigma + np.swapaxes(inv_sigma, -1, -2))  # symmetrize
    inv_sigma = sanitize_sigma(inv_sigma, eps=eps)
    sigma = safe_inv(inv_sigma, eps=eps)
    mu = np.einsum("...ij,...j->...i", sigma, theta1)

    try:
        if config.debug_sanitize_sigma:
            logdet = safe_logdet(sigma)
            
    except NameError:
        pass

    return mu, sigma

