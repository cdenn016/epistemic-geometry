import numpy as np
import sys

# ===========================
# DEBUGGING AND UTILITIES
# ===========================

# 1) define at top of your script/module
def scaled_eta(base, *weights, min_den=1.0):
    """
    If all weights sum to zero, return base.
    Otherwise return base / max(sum(weights), min_den).
    """
    total = sum(weights)
    if total <= 0:
        return base
    return base / max(total, min_den)

def set_config_from_params(params):
    """Dynamically override config attributes from a dictionary."""
    this_module = sys.modules[__name__]
    for k, v in params.items():
        setattr(this_module, k, v)





# config.py
phi_morphism_type = "gauge_covariant"         # identity  gauge_covariant rectangular_exp
phi_model_morphism_type = "gauge_covariant"


morphism_normalize = True


# Toggle between diagonal and full Σ initialization
diagonal_eta2_init = False

# ===========================
# DOMAIN / SPATIAL SETTINGS
# ===========================
K_q           = 5
K_p           = 9       # Fiber dimension of belief/model space (depends on representation)
                 
D             = 2           #dimension of base manifold - d=2 validated

L             = 16         #length of hypercubic base-manifold - PBCs

steps         = 250

N             = 2                       # Number of agents
max_neighbors = 2           # Max number of agent neighbors

agent_radius_range = (3,3)         #agent radii
             
# ===========================
# COUPLINGS & PENALTIES
# ===========================
e_belief               = 1
e_model                = 1

alpha                  = 1
beta                   = 1
belief_mass            = 1
curvature_weight       = 1

feedback_weight         = 0
beta_model              = 1
model_mass              = 1
model_curvature_weight  = 1


#==========================
#    IF NEEDED/CURIOUS
#==========================
entropy_weight                = 0
phi_phi_tilde_coupling        = 0      #not coded yet    

fisher_geometry_weight        = 0      #not operable
fisher_model_geometry_weight  = 0

# ===========================
# INITIALIZATION
# ===========================


eta_base_phi          = 1e-4
eta_base_phi_model    = 1e-4    

# Learning rates for natural parameters
eta1_belief           = 1e-5       # update rate for η₁_q
eta2_belief           = 1e-6       # update rate for η₂_q
eta1_model            = 1e-5       # update rate for η₁_p
eta2_model            = 1e-6       # update rate for η₂_p


phi_scale             = 1
phi_init_smooth_sigma = 1.5
phi_init              = 0.1
phi_model_offset      = 0.1

eta_phi_min           = 1e-6
eta_phi_model_min     = 1e-6



eta_phi_max = 1.0
eta_phi_model_max = 1.0


# ===========================
# AGENT GEOMETRY
# ===========================
# Natural parameter ranges
q_eta1_range = (-2.0, 2.0)
q_eta2_range = (-1.0, -0.1)  # ensures Σ ∈ [0.05, 1.0]

p_eta1_range = (-2.0, 2.0)
p_eta2_range = (-1.0, -0.1)

gaussian_blur_range_morphism = (1,2)
mu_clip = 3.0



#================================
#
#  INITIALIZE GLOBAL FIELDS 
#      WITH GENTLE NOISE
#================================
use_global_belief_template = False
use_global_model_template  = False


delta_eta1 = 0.005
delta_eta2 = 0.005             #  0.005 for both
belief_noise_scale_eta1 = 0.01
belief_noise_scale_eta2 = 0.005
model_noise_scale_eta1  = 0.01
model_noise_scale_eta2  = 0.005


identical_models = False         # If True, all agents share the same p, mu_p_field, sigma_p_field

agent_seed    = 42

#====================================
# ─── η₂ Sanitization Parameters ───
#
#
#=====================================
eta2_min_eigval    = -1e-12       # ensure SPD with margin...value=-1e-4                                
eta2_max_norm      = 150  #value=10                           
eta2_floor          = -1e-8     #-1e-4 
eta2_outside_val    = -1e-8        #-1
eta2_smooth_sigma   = 2          #2
#eta2_target_trace   = -(K_q) / 2   # ~Kq or Kp or comment out




# ===========================
# STABILITY AND CLIPPING
# ===========================


                                    # Gradient clipping magnitudes (optional; set to None to disable)
phi_grad_clip             = 1e4    # Max L2 norm per-point for φ update
phi_model_grad_clip       = 1e4    # Max L2 norm per-point for φ̃ update

grad_eta1_clip            = 1e3
grad_eta2_clip            = 1e3
                                       # Optional: norm type (future-proofing, L2 is default)
gradient_clip_norm_type       = 2           # Use 2 for L2 norm; 1 for L1, np.inf for max-norm
phi_exp_clip = np.pi  # or 2π if you're okay with aliasing

eta_phi_adaptive_scaling       = 1.0
eta_phi_model_adaptive_scaling = 1.0

eta_sigma_condition_scaling    = 0.05  # dampen updates if cond(Σ) is large

# Max allowed condition number for Omega matrix
max_omega_condition            = 1e6  # Adjust as needed
mask_sharpness        = 1.5
# ===========================
# EPSILONS & NUMERICAL STABILITY
# ===========================

log_eps            = 1e-6     # Stabilize log(x)
spd_eps            = 1e-5     # Ensure SPD in eta2 and Sigma
eta2_eps           = spd_eps  # Alias for clarity
eps                = 1e-5
# ===========================
# MASK & INTERACTION THRESHOLDS
# ===========================

support_cutoff_eps = 1e-3    # Mask threshold to include point in agent support
overlap_eps        = 1e-3     # Threshold for computing inter-agent overlap
kl_self_cutoff     = 1e-3
kl_feedback_cutoff = 1e-3
# ===========================
# SIMULATION THRESHOLDS
# ===========================

epsilon_model      = 1.0      # Threshold to classify meta-agents (can sweep)

# ===========================
# CHECKPOINTING
# ===========================

checkpoint_dir      = "checkpoints"
precision = np.float32

checkpoint_interval = 1

domain_size = (L,) * D

# 3) replace all the old eta_* calculations with calls to scaled_eta


num_cores = 1  # or however many threads you want to use

log_full_fields = True  # default off

group_name = 'so3'               # Options: "u1", "so3", "so3", 'su2'.
representation_type = 'irrep'     # Options: 'irrep', 'fundamental', 'adjoint'


# Enable numerical safety logging
debug = True  # Global debug flag for extra logging inside φ updates                       
debug_gradients = True                  # Log gradient-related issues
debug_sanitize_sigma = True             # Show SPD sanitization messages
fail_on_fallback = False                # Allow recovery rather than crashing


#=================
#    LOGDET
#==================


# ── Numerical Safeguards ─────────────────────────────
max_fisher_condition = 1e5   # Maximum allowed condition number before fallback


# Control fallback thresholds (optional)
max_safe_inv_fallbacks = 1000
max_safe_logdet_fallbacks = 1000

