# -*- coding: utf-8 -*-
"""
Created on Sun Aug  3 08:44:57 2025

@author: chris and christine
"""

import matplotlib.pyplot as plt
import numpy as np
import config
from agent_initialization import initialize_agents


def plot_eta_fields(agents, field="belief", include_raw=True):
    for i, agent in enumerate(agents):
        eta1 = agent.eta1_q_field if field == "belief" else agent.eta1_p_field
        eta2 = agent.eta2_q_field if field == "belief" else agent.eta2_p_field
        mask = agent.mask
        K = eta1.shape[-1]

        # ─── Optional raw diagonals (pre-rotation) ───
        if field == "belief" and include_raw:
            raw_eta1 = getattr(agent, "raw_eta1_q_diag", None)
            raw_eta2 = getattr(agent, "raw_eta2_q_diag", None)

            if raw_eta1 is not None:
                for k in range(K):
                    plt.figure(figsize=(4, 4))
                    plt.title(f"Agent {i} — raw η₁_diag[{k}]")
                    plt.imshow(raw_eta1[..., k], cmap='coolwarm')
                    plt.colorbar()
                    plt.tight_layout()
                    plt.show()

            if raw_eta2 is not None:
                for k in range(K):
                    plt.figure(figsize=(4, 4))
                    plt.title(f"Agent {i} — raw η₂_diag[{k},{k}]")
                    plt.imshow(raw_eta2[..., k, k], cmap='viridis')
                    plt.colorbar()
                    plt.tight_layout()
                    plt.show()

        # ─── Plot η₁ after full projection ───
        for k in range(K):
            plt.figure(figsize=(4, 4))
            plt.title(f"Agent {i} — η₁[{k}] ({field})")
            plt.imshow(eta1[..., k], cmap='coolwarm')
            plt.colorbar()
            plt.tight_layout()
            plt.show()

        # ─── Plot η₂ diagonal elements after full projection ───
        for k in range(K):
            plt.figure(figsize=(4, 4))
            plt.title(f"Agent {i} — η₂[{k},{k}] ({field})")
            plt.imshow(eta2[..., k, k], cmap='viridis')
            plt.colorbar()
            plt.tight_layout()
            plt.show()

        # ─── Trace of η₂ ───
        trace_eta2 = np.trace(eta2, axis1=-2, axis2=-1)
        plt.figure(figsize=(4, 4))
        plt.title(f"Agent {i} — Tr(η₂) ({field})")
        plt.imshow(trace_eta2, cmap='inferno')
        plt.colorbar()
        plt.tight_layout()
        plt.show()


if __name__ == "__main__":
    seed = 42
    domain_size = (24, 24)
    N = 2
    K_q = config.K_q
    K_p = config.K_p
    d = 3  # SO(3) dimension

    agents = initialize_agents(seed, domain_size, N, K_q, K_p, d)
    plot_eta_fields(agents, field="belief", include_raw=True)
