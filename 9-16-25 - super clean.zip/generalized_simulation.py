# generalized_simulation.py
import os
os.environ["OMP_NUM_THREADS"] = "1"
os.environ["MKL_NUM_THREADS"] = "1"
os.environ["NUMEXPR_NUM_THREADS"] = "1"
os.environ["OPENBLAS_NUM_THREADS"] = "1"
import sys
ROOT = os.path.dirname(os.path.abspath(__file__))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)
from pathlib import Path
import sys, time, pickle, shutil, multiprocessing as _mp, numpy as np
import core.config as config

from updates.update_rules import synchronous_step
from core.transport_cache import ensure_global_A, _aid
from diagnostics import compute_total_action, print_action_breakdown
from metrics_viz import VizConfig, MetricsViz
from core.get_generators import casimir_scalar
from runtime_context import ensure_runtime_defaults,build_step_settings_from_overrides, cfg_get 
from utils import mean_norm
from run_sim_utils import (
    prepare_generators, merge_logging_cfg, initialize_or_resume,
    log_and_viz_after_step, apply_param_overrides_to_ctx,
    wrap_epilogue, save_step,_extract_global_from_Q
)



def run_simulation(
    outdir="checkpoints",
    resume=False,
    log_metrics=True,
    log_fields=True,
    num_cores=None,
    params=None,
    fresh_outdir=False,
    clear_agent_logs=True,
):
    
    
    # ---------- cores + params ----------
    _avail = max(1, (_mp.cpu_count() or 1) - 1)
    num_cores = _avail if num_cores is None else int(num_cores)
    num_cores = max(1, num_cores)

    params = {} if params is None else dict(params)

    # ---------- CLI overrides -> ctx (DEPRECATE set_config_from_params) ----------
    param_override = {}
    if len(sys.argv) > 1:
        with open(sys.argv[1], "rb") as f:
            param_override = pickle.load(f)

    runtime_ctx = ensure_runtime_defaults(params.get("runtime_ctx", None))
    apply_param_overrides_to_ctx(runtime_ctx, param_override)  # CLI
    if params:
        apply_param_overrides_to_ctx(runtime_ctx, params)       # explicit params win

    # keep runtime-only knobs in ctx.config (not module config)
    rcfg = getattr(runtime_ctx, "config", {})
    rcfg["n_jobs"] = num_cores
    runtime_ctx.config = rcfg
    params["runtime_ctx"] = runtime_ctx

    # ---------- generators ----------
    G_q, G_p = prepare_generators(params)   # respects params or ctx.config fallback
    params["generators_q"] = G_q
    params["generators_p"] = G_p

    # dims from actual generators
    Kq, Kp = int(np.asarray(G_q).shape[1]), int(np.asarray(G_p).shape[1])
    runtime_ctx.config["K_q"] = Kq
    runtime_ctx.config["K_p"] = Kp
    print(f"[G] resolved generators: Kq={Kq}, Kp={Kp}  shapes: {G_q.shape}, {G_p.shape}")

    # ---------- logging cfg ----------
    # merge context mirror with params (params take precedence)
    merged_for_log = {**getattr(runtime_ctx, "config", {}), **(params or {})}
    logcfg = merge_logging_cfg(merged_for_log)
    if not log_metrics: logcfg["enable_scalar"] = False
    if not log_fields:  logcfg["enable_fields"] = False
    if logcfg.get("enable_fields", False):
        os.makedirs(os.path.join(outdir, logcfg["full_field_outdir"]), exist_ok=True)

    # ---------- init or resume ----------
    if fresh_outdir and not resume and os.path.isdir(outdir):
        shutil.rmtree(outdir, ignore_errors=True)
    os.makedirs(outdir, exist_ok=True)

    agents, step_start = initialize_or_resume(outdir, resume, params, clear_agent_logs=clear_agent_logs)

    # ---------- runtime ctx bootstrapping ----------
    runtime_ctx.global_step = step_start
    runtime_ctx.children_latest = agents

    vizcfg = VizConfig(
        outdir=Path(outdir),
        run_name=os.path.basename(outdir) or "run",
        plot_every_steps=int(logcfg.get("plot_every_steps", 10)),
        snapshot_every_steps=int(logcfg.get("snapshot_every_steps", 50)),
    )
    mv = MetricsViz(vizcfg)
    meta_generators = {
        "Kq": Kq, "Kp": Kp,
        "casimir_total_q": casimir_scalar(G_q),
        "casimir_total_p": casimir_scalar(G_p),
    }
    mv.start_run(meta=meta_generators)
    runtime_ctx.viz = mv

    # A-connection
    A_init_scale = cfg_get(runtime_ctx, "A_init_scale", getattr(config, "A_init_scale", 0.0))
    ensure_global_A(runtime_ctx, shape_hw=agents[0].hw, init_scale=A_init_scale)

    # ---------- step range ----------
    total_steps = int(cfg_get(runtime_ctx, "steps", getattr(config, "steps", 0)))
    if step_start >= total_steps:
        wrap_epilogue(runtime_ctx, agents, outdir, [], [])
        print("[DONE] Nothing to do: resume step >= total steps.")
        return agents, []


    # ---------- loop ----------
    parent_metrics, metric_log = [], []
    print(f"[RUN] Starting simulation at step {step_start} with {num_cores} cores")

    for step in range(step_start, total_steps):
        runtime_ctx.global_step = step
        # pull fresh per-step settings by overlaying ctx.config on module defaults
        runtime_ctx.step_cfg = build_step_settings_from_overrides(config, getattr(runtime_ctx, "config", {}))

        print(f"\n[STEP {step}] -----------------------------\n")
        t0 = time.perf_counter()

        step_params = {**params, "step": step, "sanitize_strict_pre": False}

        # core synchronous update
        agents = synchronous_step(
            agents, G_q, G_p,
            params=step_params,
            n_jobs=num_cores,
            runtime_ctx=runtime_ctx,
        )
        print(f"[TIMER] synchronous update: {time.perf_counter() - t0:.3f}s")

        # viz & metrics
        runtime_ctx.children_latest = agents
        Q = compute_total_action(runtime_ctx, agents, params)
        print_action_breakdown(runtime_ctx, Q)

        log_and_viz_after_step(runtime_ctx, agents, step, outdir, params, logcfg,
                               parent_metrics, metric_log, num_cores)

        # global row
        qnums = _extract_global_from_Q(Q)
        E_tot = qnums.get("Geom_total", qnums.get("Action_total", np.nan))
        gmetrics = {
            "E_total": float(E_tot) if np.isfinite(E_tot) else np.nan,
            "mean_total": float(qnums.get("Geom_total_mean", np.nan)),
            **qnums,
        }
        mv.log_global(step, gmetrics)

        # per-agent rows
        for a in agents:
            mv.log_agent(step, _aid(a), {
                "phi_norm_mean":       mean_norm(getattr(a, "phi", None)),
                "phi_model_norm_mean": mean_norm(getattr(a, "phi_model", None)),
            })

        # persist + visualize
        mv.maybe_flush(step)
        mv.maybe_plot(step)
        mv.maybe_snapshot(step, runtime_ctx, agents)

        save_step(agents, outdir, step)
        print(f"[SAVE] Checkpoint --> {outdir}/step_{step:04d}.pkl")

    # ---------- epilogue ----------
    wrap_epilogue(runtime_ctx, agents, outdir, parent_metrics, metric_log)
    print("[DONE] Simulation completed.")
    return agents, metric_log


if __name__ == "__main__":
    run_simulation()



