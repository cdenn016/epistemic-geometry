
import numpy as np

from core.numerical_utils import safe_inv, sanitize_sigma, safe_omega_inv

from core.transport_cache import build_dexpinv_matrix , Jinv_grid, E_grid, Omega, _aid
import core.config as config
from core.omega import d_exp_phi_exact, d_exp_phi_tilde_exact, exp_lie_algebra_irrep
from utils import ( log_phi_grad_like, naturalize_grad, _apply_fisher_in_body,
                   exp_and_jinv_single,push_neighbor_stats,
                   accumulate_into, _joint_mask,
                   fiber_keys, reg_weights, 
                   which_and_gens, mask_hw, build_c_mapping_q2p, 
                   )
from runtime_context import cfg_get
#==============================================================================
#
#                    GATHER PHI GAUGE FIELD GRADIENT TERMS
#                          Beliefs and Models
#==============================================================================


def accumulate_phi_alignment_gradient(
    ctx,                              # <-- explicit, required in new code paths
    agent_i, agent_j, generators, params: dict | None = None,
    *,
    field: str = "phi",
    beta_key: str | None = None,
    omega_cache_key: str | None = None,
    mu_key: str | None = None,
    sigma_key: str | None = None,
    fisher_inv_key: str | None = None,
    grad_key: str | None = None,
    Q_all_i=None,           # list/array (d, ..., K, K)
    exp_neg_phi_j=None,     # (..., K, K)
    agents=None,            # for Fisher regularizer
    strict_numerics: bool = True,
    recover: str | None = None,
):
    """
    Same-level φ/φ̃ alignment gradient (∂ KL_{i←j} / ∂φ_i):
      - param-covector → body-covector via Jinv^T, then Fisher^{-1} (body),
        add Lie-natural regularizers (body), map back by Jinv, mask & scale by β, accumulate.
    """
    assert mu_key and sigma_key and fisher_inv_key and grad_key, \
        "mu_key/sigma_key/fisher_inv_key/grad_key are required"

    
    PRINT_SIGN = False
    # ---- ctx & numeric knobs ----
    
    eps_num = float(cfg_get(ctx, "eps", 1e-8))
    tau     = float(cfg_get(ctx, "support_tau", 1e-6))

    # Which fiber are we on?
    which, _, _ = (fiber_keys("belief") if field == "phi" else fiber_keys("model"))
    
    beta = None
    if beta_key is not None:
        # 1) explicit override in params
        beta = float(cfg_get(ctx, beta_key, None) or 0.0)
    else:
        # No explicit key provided: pick default by fiber
        default_name = "beta" if which == "q" else "beta_model"
        beta = float(cfg_get(ctx, default_name, 0.0))

    if beta == 0.0:
        return  # no-op
    # Early-out if no overlap
    joint_mask = _joint_mask(agent_i, agent_j, tau=tau, as_vector=True)
    
    if not np.any(joint_mask):
        print("no joint mask! \n\n\n\n")
        return

    # Fields
    mu_i    = np.asarray(getattr(agent_i, mu_key),    np.float32)
    sigma_i = np.asarray(getattr(agent_i, sigma_key), np.float32)

    # Transports
    
    if ctx is not None:
        E_i = E_grid(ctx, agent_i, which=which)
        E_j = E_grid(ctx, agent_j, which=which)
        Omega_ij  = Omega(ctx, agent_i, agent_j, which=which)
    else:
        phi_i = np.asarray(getattr(agent_i, field), np.float32)
        phi_j = np.asarray(getattr(agent_j, field), np.float32)
        E_i = exp_lie_algebra_irrep(phi_i, generators)
        E_j = exp_lie_algebra_irrep(phi_j, generators)
        Omega_ij  = E_i @ safe_omega_inv(E_j, eps=eps_num)
    
   

    # Neighbor stats in i-frame
    mu_j_t, sigma_j_t_inv = push_neighbor_stats(agent_j, sigma_key, Omega_ij, eps_num, params)

    # d exp bits
   
    if Q_all_i is None:
        phi_i = np.asarray(getattr(agent_i, field), np.float32)
        Q_all_i = (d_exp_phi_exact(phi_i, generators)
                   if field == "phi" else
                   d_exp_phi_tilde_exact(phi_i, generators))
    if exp_neg_phi_j is None:
        exp_neg_phi_j = safe_omega_inv(E_j, eps=eps_num)


    # Raw param-space covector grad
    grad_param = grad_kl_wrt_phi_i(
        mu_i, sigma_i,
        None, None,
        phi_i=np.asarray(getattr(agent_i, field), np.float32),
        phi_j=None,
        Omega_ij=Omega_ij,
        generators=generators,
        exp_phi_i=E_i,
        exp_phi_j=E_j,
        mu_j_t=mu_j_t,
        sigma_j_t_inv=sigma_j_t_inv,
        eps=eps_num,
        exp_neg_phi_j=exp_neg_phi_j,
        Q_all=Q_all_i,
    ).astype(np.float32, copy=False)

    if strict_numerics and not np.all(np.isfinite(grad_param)):
        raise FloatingPointError("accumulate_phi_alignment_gradient: nonfinite grad_param.")

    # Jinv^T projection to body covector
    phi_field = np.asarray(getattr(agent_i, field), np.float32)
    
    Jinv = Jinv_grid(ctx, agent_i, which=which)
    if Jinv is None:
        Jinv = build_dexpinv_matrix(phi_field)
    
    g_body_cov = np.einsum("...ji,...j->...i", Jinv, grad_param, optimize=True)
    
    
    if strict_numerics and not np.all(np.isfinite(g_body_cov)):
        raise FloatingPointError("accumulate_phi_alignment_gradient: nonfinite g_body_cov.")

    # Fisher^{-1} in body
    v_body = _apply_fisher_in_body(agent_i, fisher_inv_key, g_body_cov, params)

    # Add Lie-natural regularizers (already natural/body)
    params_local = dict(params)
    params_local["agents"] = agents
    v_body_total = _apply_lie_natural_regularizers(agent_i, field, generators, params_local, ctx, v_body)
    
    if strict_numerics and not np.all(np.isfinite(v_body_total)):
        raise FloatingPointError("accumulate_phi_alignment_gradient: nonfinite v_body_total.")

    # Map back to parameter vector: Jinv · v_body_total
    v_param = np.einsum("...ab,...b->...a", Jinv, v_body_total, optimize=True)

    # Accumulate with mask & weight
    contrib = (beta * v_param) * joint_mask
    accumulate_into(agent_i, grad_key, contrib)

    # Tiny logging
    if PRINT_SIGN:
        aid  = _aid(agent_i)
        ajid = getattr(agent_j, "id", "?")
        spatial_axes = tuple(range(contrib.ndim - 1))
        g_mean = np.nanmean(contrib, axis=spatial_axes)
        def _sgn(x): return "+" if x > 0 else ("-" if x < 0 else "0")
        sign_str = "".join(_sgn(x) for x in g_mean.tolist())
        g_abs_mean = float(np.nanmean(np.abs(contrib)))
        print(f"[PHI-GRAD] field={field} ai={aid} aj={ajid} sign={sign_str} "
              f"mean={np.array2string(g_mean, precision=3, suppress_small=True)} "
              f"|g|_mean={g_abs_mean:.3e}", flush=True)




# ─────────────────────────────────────────────────────────────────────────────
# Refactored main entrypoint
# ─────────────────────────────────────────────────────────────────────────────

def accumulate_phi_morphism_self_feedback(
    ctx,
    agent_i,
    generators_src, generators_tgt,
    params,
    field="phi",                # "phi" or "phi_model"
    fisher_inv_key=None,
    grad_key=None,
    phi_self_func=None,         # ∂E_self/∂φ in parameter-covector coords
    phi_feedback_func=None,     # ∂E_fb/∂φ in parameter-covector coords
):
    """
    Accumulate SELF + FEEDBACK gradients for φ (or φ̃) into agent_i.<grad_key>.
    Uses cache-aware E/Jinv when available; otherwise constructs locally. Projection:
    Jinv^T (param-covector) → Fisher^{-1} (body) → Jinv (param-vector). 
    """
    assert fisher_inv_key and grad_key, "fisher_inv_key and grad_key are required"

    PRINT_SIGN      = True
    eps = float(cfg_get(ctx, "eps", 1e-8))
    tau     = float(cfg_get(ctx, "support_tau", 1e-6))
    
    alpha   = float(cfg_get(ctx, "alpha", 0))
    fbw = float(cfg_get(ctx, "feedback_weight", 0))
    fisher_max_norm = float(cfg_get(ctx, "fisher_max_norm", 1e3))
    

    
    
    if alpha <= 0.0 and fbw <= 0.0:
        return

    mask = mask_hw(agent_i, tau=tau, as_vector = True) 
    if not np.any(mask):
        return

    # fields & base φ
    mu_q,  sigma_q  = agent_i.mu_q_field,  agent_i.sigma_q_field
    mu_p,  sigma_p  = agent_i.mu_p_field,  agent_i.sigma_p_field
    phi,   phi_t    = np.asarray(agent_i.phi, np.float32), np.asarray(agent_i.phi_model, np.float32)
    base_field      = phi if field == "phi" else phi_t

    # transports & Jinv (cache-first) 
    exp_this, exp_other, Jinv, which, G_q, G_p = exp_and_jinv_single(
        params.get("runtime_ctx", None), agent_i, field, base_field, generators_src, generators_tgt
    )

    # Fisher^{-1} (optional, shape-flex)
    F_inv = getattr(agent_i, fisher_inv_key, None)
    
    if F_inv is None: return None
    
    Fi = np.asarray(F_inv, np.float32)
    
    if not (Fi.size > 0 and np.all(np.isfinite(Fi))): return None
    
    if fisher_max_norm:
        Finf = float(np.max(np.abs(Fi)))
        if np.isfinite(Finf) and Finf > fisher_max_norm:
            Fi = Fi * (fisher_max_norm / (Finf + 1e-12))
    
    
    total = np.zeros_like(base_field, dtype=np.float32)
    self_contrib = fb_contrib = None

    # -------- SELF term --------
    if alpha > 0.0 and phi_self_func is not None:
        # Match your original generator/exp wiring across the phi vs phi_model branches
        g_param = phi_self_func(
            mu_q=mu_q, sigma_q=sigma_q, mu_p=mu_p, sigma_p=sigma_p,
            Phi_tilde_0=getattr(agent_i, "Phi_tilde_0", None),
            phi=phi, phi_tilde=phi_t,
            exp_phi=(exp_this if field == "phi" else exp_other),
            exp_phi_tilde=(exp_other if field == "phi" else exp_this),
            eps=eps, generators_q=G_q, generators_p=G_p,
        )
        if g_param is not None:
            v_param = naturalize_grad(np.asarray(g_param, np.float32), Jinv, Fi)
            self_contrib = alpha * v_param * mask
            total += self_contrib

    # -------- FEEDBACK term --------
    if fbw > 0.0 and phi_feedback_func is not None:
        g_param = phi_feedback_func(
            mu_p=mu_p, sigma_p=sigma_p, mu_q=mu_q, sigma_q=sigma_q,
            Phi_0=getattr(agent_i, "Phi_0", None),
            phi=phi, phi_tilde=phi_t,
            exp_phi=(exp_this if field == "phi" else exp_other),
            exp_phi_tilde=(exp_other if field == "phi" else exp_this),
            eps=eps,
            # preserve your original kw choices per branch
            generators_q=G_q if field == "phi" else G_q,
            generators_p=G_p if field != "phi" else None,
        )
        if g_param is not None:
            v_param = naturalize_grad(np.asarray(g_param, np.float32), Jinv, Fi)
            
            fb_contrib = fbw * v_param * mask
            total += fb_contrib

    accumulate_into(agent_i, grad_key, total)

    if PRINT_SIGN:
        aid = _aid(agent_i)
        log_phi_grad_like(aid, field, "self", self_contrib)
        log_phi_grad_like(aid, field, "feedback", fb_contrib)
        log_phi_grad_like(aid, field, "total", total)

#==============================================================================
#
#                    WITH RESPECT TO phi_i TERMS
#                       VALIDATED
#==============================================================================




def grad_kl_wrt_phi_i(
    mu_i, sigma_i,
    mu_j, sigma_j,                 # unused; kept for signature compatibility
    phi_i, phi_j,                  # unused here
    Omega_ij,
    generators,
    exp_phi_i,
    exp_phi_j,
    mu_j_t,                        # REQUIRED: (..., K)
    sigma_j_t_inv,                 # REQUIRED: (..., K, K)
    eps=1e-8,
    exp_neg_phi_j=None,
    Q_all=None,
):
    
    
    # ---- cast to f64 for internal math ----
    mu_i   = np.asarray(mu_i,   np.float64)
    mu_j_t = np.asarray(mu_j_t, np.float64)

    Sigma_i = sanitize_sigma(np.asarray(sigma_i, np.float64), eps=eps)
   

    # Q_all → (..., a, K, K)
    if Q_all is None:
        Q_all = d_exp_phi_exact(np.asarray(phi_i, np.float64), generators)
    
    Q = np.stack([np.asarray(x, np.float64) for x in Q_all], axis=-3)

    # exp(-phi_j) broadcast to Q lead dims
    if exp_neg_phi_j is None:
        exp_neg_phi_j = safe_omega_inv(np.asarray(exp_phi_j, np.float64), eps=eps, debug=False)
   
    # Ω and Ω^{-1}
    Om   = np.asarray(Omega_ij, np.float64)
    Oinv = safe_omega_inv(Om, eps=eps, debug=False).astype(np.float64, copy=False)

    # Sanity on provided precision
    Sj_inv = np.asarray(sigma_j_t_inv, np.float64)
    Sj_inv = 0.5 * (Sj_inv + np.swapaxes(Sj_inv, -1, -2))
    

    # Core pieces
    delta_mu = (mu_i - mu_j_t)                     # (..., K)
    mu_j_src = np.einsum("...ij,...j->...i", Oinv, mu_j_t, optimize=True)  # (..., K)

    # dΩ/dφ_i^a = Q[a] @ e^{-φ_j}
    Q = np.einsum("...aik,...kj->...aij", Q, exp_neg_phi_j, optimize=True)
    Q_T = np.swapaxes(Q, -1, -2)

    # ---- gradient terms ----
    # trace term
    t1 = np.einsum("...ij,...ajk,...ki->...a", Sj_inv, Q,   Sigma_i, optimize=True)
    t2 = np.einsum("...aij,...jk,...ki->...a", Q_T,   Sj_inv, Sigma_i, optimize=True)
    trace_term = -0.5 * (t1 + t2)

    # mean term
    tmp1 = np.einsum("...aij,...j->...ai", Q_T,    delta_mu, optimize=True)
    tmp2 = np.einsum("...ij,...aj->...ai", Sj_inv, tmp1,     optimize=True)
    mean_term = -np.einsum("...i,...ai->...a", mu_j_src, tmp2, optimize=True)

    # Mahalanobis term
    v1 = np.einsum("...ij,...j->...i", Sj_inv, delta_mu, optimize=True)
    part1 = np.einsum("...aij,...j->...ai", Q_T, v1,           optimize=True)
    v2    = np.einsum("...aij,...j->...ai", Q,   delta_mu,     optimize=True)
    part2 = np.einsum("...ij,...aj->...ai", Sj_inv, v2,        optimize=True)
    mahal_term = 0.5 * np.einsum("...i,...ai->...a", delta_mu, part1 + part2, optimize=True)

    grad = (trace_term + mean_term + mahal_term)
    
    return grad





def grad_feedback_phi_direct(
    mu_p, sigma_p,
    mu_q, sigma_q,
    Phi_0,
    phi,                # (..., d)
    phi_tilde,          # (..., d)
    generators_q,       # (d, K_q, K_q)
    exp_phi,            # (..., K_q, K_q)
    exp_phi_tilde,      # (..., K_p, K_p)
    eps=1e-8,
    # NEW optional precomputes:
    Q_all=None,         # (..., d, K_q, K_q) = d_exp_phi_exact(phi, generators_q)
    exp_neg_phi=None    # (..., K_q, K_q) = e^{-φ}
):
    """
    Vectorized over 'a': returns (..., d)
    Φ = e^{φ̃} Φ₀ e^{-φ}, ∂Φ = - Φ · (e^{-φ} (∂ e^{φ}) e^{-φ})
    """
    d, K_q, _ = generators_q.shape
    

    if exp_neg_phi is None:
        exp_neg_phi = safe_omega_inv(exp_phi, eps=eps, debug=False)
    if Q_all is None:
        # stack as (..., d, K_q, K_q)
        Q_list = d_exp_phi_exact(phi, generators_q)
        Q_all = np.stack(Q_list, axis=-3)  # assuming list of d arrays

    # Φ and Φᵀ
    Phi = np.einsum("...ik,...kj,...jl->...il", exp_phi_tilde, Phi_0, exp_neg_phi)
    Phi_T = np.swapaxes(Phi, -1, -2)


    # A, A^{-1}
    A = np.einsum("...ik,...kl,...lj->...ij", Phi, sigma_q, Phi_T)
    A = sanitize_sigma(A, eps=eps)
    A_inv = safe_inv(A, eps=eps)

    # Δμ and v
    Phi_mu_q = np.einsum("...ij,...j->...i", Phi, mu_q)
    delta_mu = mu_p - Phi_mu_q
    v = np.einsum("...ij,...j->...i", A_inv, delta_mu)  # (..., K_p)

    # Q̄_a = e^{-φ} Q_a e^{-φ}
    Q_bar = np.einsum("...ik,...akl,...lj->...aij", exp_neg_phi, Q_all, exp_neg_phi)

    # dΦ_a = - Φ Q̄_a
    dPhi = -np.einsum("...ik,...akj->...aij", Phi, Q_bar)
    dPhi_T = np.swapaxes(dPhi, -1, -2)

    # dA_a
    dA = (
        np.einsum("...aik,...kl,...lj->...aij", dPhi, sigma_q, Phi_T) +
        np.einsum("...ik,...kl,...alj->...aij", Phi,  sigma_q, dPhi_T)
    )

    # Term 1
    dPhi_mu = np.einsum("...aij,...j->...ai", dPhi, mu_q)       # (..., a, K_p)
    term1 = -np.einsum("...ai,...i->...a", dPhi_mu, v)

    # Term 2
    term2 = 0.5 * np.einsum("...ij,...aij->...a", A_inv, dA)

    # M_a = A^{-1} dA_a A^{-1}
    M = np.einsum("...ij,...ajk,...kl->...ail", A_inv, dA, A_inv)

    # Term 3
    term3 = -0.5 * np.einsum("...i,...aij,...j->...a", delta_mu, M, delta_mu)

    # Term 4
    term4 = -0.5 * np.einsum("...aij,...ji->...a", M, sigma_p)

    grad = (term1 + term2 + term3 + term4).astype(np.float32, copy=False)
    return grad


def grad_feedback_phi_tilde_direct(
    mu_p, sigma_p,
    mu_q, sigma_q,
    Phi_0,
    phi, phi_tilde,
    generators_p, generators_q,
    exp_phi, exp_phi_tilde,
    eps=1e-8,
    # NEW optional precomputes:
    Q_tilde_all=None,       # (..., d, K_p, K_p) = d_exp_phi_tilde_exact(phi_tilde, generators_p)
    exp_neg_phi_tilde=None  # (..., K_p, K_p) = e^{-φ̃}
):
    """
    Vectorized over 'a': returns (..., d)
    Left-trivialize: dΦ_a = L_a Φ,  L_a = (∂e^{φ̃}/∂φ̃^a) e^{-φ̃}.
    """
    d, K_p, _ = generators_p.shape
    

    if exp_neg_phi_tilde is None:
        exp_neg_phi_tilde = safe_omega_inv(exp_phi_tilde, eps=eps, debug=False)
    if Q_tilde_all is None:
        Q_list = d_exp_phi_tilde_exact(phi_tilde, generators_p)
        Q_tilde_all = np.stack(Q_list, axis=-3)

    # Φ
    exp_neg_phi = safe_omega_inv(exp_phi, eps=eps, debug=False)
    Phi   = np.einsum("...ik,...kj,...jl->...il", exp_phi_tilde, Phi_0, exp_neg_phi)
    Phi_T = np.swapaxes(Phi, -1, -2)

  
    A = np.einsum("...ik,...kl,...lj->...ij", Phi, sigma_q, Phi_T)
    A = sanitize_sigma(A, eps=eps)
    A_inv = safe_inv(A, eps=eps)

    Phi_mu_q = np.einsum("...ij,...j->...i", Phi, mu_q)
    delta_mu = mu_p - Phi_mu_q
    v = np.einsum("...ij,...j->...i", A_inv, delta_mu)

    # L_a = Q̃_a e^{-φ̃}
    L = np.einsum("...aik,...kj->...aij", Q_tilde_all, exp_neg_phi_tilde)

    # dΦ_a = L_a Φ
    dPhi = np.einsum("...aik,...kj->...aij", L, Phi)
    dPhi_T = np.swapaxes(dPhi, -1, -2)

    dA = (
        np.einsum("...aik,...kl,...lj->...aij", dPhi, sigma_q, Phi_T) +
        np.einsum("...ik,...kl,...alj->...aij", Phi,  sigma_q, dPhi_T)
    )

    dPhi_mu = np.einsum("...aij,...j->...ai", dPhi, mu_q)
    term1 = -np.einsum("...ai,...i->...a", dPhi_mu, v)

    term2 = 0.5 * np.einsum("...ij,...aij->...a", A_inv, dA)

    M = np.einsum("...ij,...ajk,...kl->...ail", A_inv, dA, A_inv)

    term3 = -0.5 * np.einsum("...i,...aij,...j->...a", delta_mu, M, delta_mu)
    term4 = -0.5 * np.einsum("...aij,...ji->...a", M, sigma_p)

    grad = term1 + term2 + term3 + term4
    return grad



def grad_self_phi_direct(
    mu_q, sigma_q,
    mu_p, sigma_p,
    Phi_tilde_0,
    phi, phi_tilde,
    generators_q, generators_p,
    exp_phi, exp_phi_tilde,
    eps=1e-8,
    # NEW optional precomputes:
    Q_all=None,               # (..., d, K_q, K_q)
    exp_neg_phi_tilde=None    # (..., K_p, K_p)
):
    """
    Vectorized over 'a': returns (..., d)
    Φ̃ = e^{φ} Φ̃₀ e^{-φ̃},  ∂Φ̃_a = (∂e^{φ}/∂φ^a) Φ̃₀ e^{-φ̃}.
    """
    d, K_q, _ = generators_q.shape
    

    if exp_neg_phi_tilde is None:
        exp_neg_phi_tilde = safe_omega_inv(exp_phi_tilde, eps=eps, debug=False)
    if Q_all is None:
        Q_list = d_exp_phi_exact(phi, generators_q)
        Q_all = np.stack(Q_list, axis=-3)

    # Φ̃ and A
    Phi_tilde = np.einsum("...ik,...kj,...jl->...il", exp_phi, Phi_tilde_0, exp_neg_phi_tilde)
    Phi_tilde_T = np.swapaxes(Phi_tilde, -1, -2)


    A = np.einsum("...ik,...kl,...lj->...ij", Phi_tilde, sigma_p, Phi_tilde_T)
    A = sanitize_sigma(A, eps=eps)
    A_inv = safe_inv(A, eps=eps)

    delta_mu = mu_q - np.einsum("...ij,...j->...i", Phi_tilde, mu_p)

    # ∂Φ̃_a = Q_a Φ̃₀ e^{-φ̃}
    dPhi = np.einsum("...aik,...kj,...jl->...ail", Q_all, Phi_tilde_0, exp_neg_phi_tilde)
    dPhi_T = np.swapaxes(dPhi, -1, -2)

    dA = (
        np.einsum("...aik,...kl,...lj->...aij", dPhi, sigma_p, Phi_tilde_T) +
        np.einsum("...ik,...kl,...alj->...aij", Phi_tilde, sigma_p, dPhi_T)
    )

    # Term 1
    dPhi_mu_p = np.einsum("...aij,...j->...ai", dPhi, mu_p)
    term1 = -np.einsum("...ai,...i->...a", dPhi_mu_p, np.einsum("...ij,...j->...i", A_inv, delta_mu))

    # Term 2   (note: your earlier self/feedback sign conventions differ; keeping your current one)
    term2 = 0.5 * np.einsum("...ij,...aij->...a", A_inv, dA)

    # M = A^{-1} dA A^{-1}
    M = np.einsum("...ij,...ajk,...kl->...ail", A_inv, dA, A_inv)

    # Term 3
    term3 = -0.5 * np.einsum("...i,...aij,...j->...a", delta_mu, M, delta_mu)

    # Term 4
    term4 = -0.5 * np.einsum("...aij,...ji->...a", M, sigma_q)

    grad = term1 + term2 + term3 + term4
    return grad


def grad_self_phi_tilde_direct(
    mu_q, sigma_q,
    mu_p, sigma_p,
    Phi_tilde_0,
    phi, phi_tilde,
    generators_q, generators_p,
    exp_phi, exp_phi_tilde,
    eps=1e-8,
    Q_tilde_all=None,         # (..., d, K_p, K_p)
    exp_neg_phi_tilde=None    # (..., K_p, K_p)
):
    """
    Vectorized over 'a': returns (..., d)
    Right-trivialize on model: R_a = (∂e^{φ̃}/∂φ̃^a) e^{-φ̃},  ∂Φ̃_a = - Φ̃ R_a.
    """
    d, K_p, _ = generators_p.shape
    
    if exp_neg_phi_tilde is None:
        exp_neg_phi_tilde = safe_omega_inv(exp_phi_tilde, eps=eps, debug=False)
    if Q_tilde_all is None:
        Q_list = d_exp_phi_tilde_exact(phi_tilde, generators_p)
        Q_tilde_all = np.stack(Q_list, axis=-3)

    Phi_tilde = np.einsum("...ik,...kj,...jl->...il", exp_phi, Phi_tilde_0, exp_neg_phi_tilde)
    Phi_tilde_T = np.swapaxes(Phi_tilde, -1, -2)

    
    A = np.einsum("...ik,...kl,...lj->...ij", Phi_tilde, sigma_p, Phi_tilde_T)
    A = sanitize_sigma(A, eps=eps)
    A_inv = safe_inv(A, eps=eps)

    mu_t = np.einsum("...ij,...j->...i", Phi_tilde, mu_p)
    delta_mu = mu_q - mu_t

    # R_a = Q̃_a e^{-φ̃}
    R = np.einsum("...aik,...kj->...aij", Q_tilde_all, exp_neg_phi_tilde)

    # dΦ̃_a = - Φ̃ R_a
    dPhi = -np.einsum("...ik,...akj->...aij", Phi_tilde, R)
    dPhi_T = np.swapaxes(dPhi, -1, -2)

    dA = (
        np.einsum("...aik,...kl,...lj->...aij", dPhi, sigma_p, Phi_tilde_T) +
        np.einsum("...ik,...kl,...alj->...aij", Phi_tilde, sigma_p, dPhi_T)
    )

    dPhi_mu_p = np.einsum("...aij,...j->...ai", dPhi, mu_p)
    term1 = -np.einsum("...ai,...i->...a", dPhi_mu_p, np.einsum("...ij,...j->...i", A_inv, delta_mu))

    term2 = 0.5 * np.einsum("...ij,...aij->...a", A_inv, dA)

    M = np.einsum("...ij,...ajk,...kl->...ail", A_inv, dA, A_inv)

    term3 = -0.5 * np.einsum("...i,...aij,...j->...a", delta_mu, M, delta_mu)
    term4 = -0.5 * np.einsum("...aij,...ji->...a", M, sigma_q)

    grad = term1 + term2 + term3 + term4
    return grad




def compute_curvature_gradient_analytical(phi, generators, dx: float = 1.0, metric_ab: np.ndarray | None = None):
    """
    ∇_φ Tr(F^2). If generators aren't trace-orthonormal, pass metric_ab = [Tr(G^a G^b)].
    """
    H, W, d = phi.shape
    phi = np.asarray(phi, np.float32)
    G   = np.asarray(generators, np.float32)

    A_x = (np.roll(phi, -1, 0) - np.roll(phi, 1, 0)) / (2 * dx)
    A_y = (np.roll(phi, -1, 1) - np.roll(phi, 1, 1)) / (2 * dx)

    A_x_mat = np.einsum("hwd,dkm->hwkm", A_x, G)
    A_y_mat = np.einsum("hwd,dkm->hwkm", A_y, G)

    dAy_dx = (np.roll(A_y_mat, -1, 0) - np.roll(A_y_mat, 1, 0)) / (2 * dx)
    dAx_dy = (np.roll(A_x_mat, -1, 1) - np.roll(A_x_mat, 1, 1)) / (2 * dx)
    comm_xy = A_x_mat @ A_y_mat - A_y_mat @ A_x_mat
    F_xy = dAy_dx - dAx_dy + comm_xy

    dF_dx = (np.roll(F_xy, -1, 0) - np.roll(F_xy, 1, 0)) / (2 * dx)
    dF_dy = (np.roll(F_xy, -1, 1) - np.roll(F_xy, 1, 1)) / (2 * dx)
    comm1 = A_x_mat @ F_xy - F_xy @ A_x_mat
    comm2 = A_y_mat @ F_xy - F_xy @ A_y_mat
    divF = dF_dx + dF_dy + comm1 + comm2

    if metric_ab is None:
        grad = 2.0 * np.stack([np.einsum("...ij,ij->...", divF, G[a]) for a in range(d)], axis=-1)
    else:
        Ginvs = safe_omega_inv(metric_ab.astype(np.float64, copy=False))
        comps = np.array([np.einsum("...ij,ij->...", divF, G[a]) for a in range(d)])  # (d,H,W)
        grad = 2.0 * np.einsum("ab,b...->a...", Ginvs, comps).transpose(1, 2, 0)
    return grad.astype(np.float32, copy=False)


# =========================
# Regularization (with toggleable φ–φ̃ coupling)
# =========================
def apply_regularization_terms_lie_natural(
    agent,
    phi_field,
    generators,
    field,
    params,
    agents=None,
    eps=1e-8,
    *,
    ctx=None,
):
    """
    Return NATURAL (body-frame) regularizer vector for φ or φ̃.
    """
    

    phi_field = np.asarray(phi_field, np.float32)
    grad_nat  = np.zeros_like(phi_field, dtype=np.float32)    # (..., d)
    
    # --- weights, which fiber, and generator sets ---
    curv_w, fisher_w, mass_w, cpl_w = reg_weights(field, params, config=config)
        
        
    which, gen_q, gen_p = which_and_gens(agent, field, generators)

    # quick exit
    if (curv_w == 0.0) and (fisher_w == 0.0) and (mass_w == 0.0) and (cpl_w == 0.0):
        return grad_nat

    # --- mask standardization ---
    tau     = float(cfg_get(ctx, "support_tau", 1e-6))
    mask_vec = mask_hw(agent, tau=tau, as_vector=True)     # -> (H,W,1) float32
    
    Jinv = Jinv_grid(ctx, agent, which=which) if ctx is not None else None
    if Jinv is None:
        Jinv = build_dexpinv_matrix(np.asarray(phi_field, np.float32))
    # --- Jinv for current field (cached or built) ---
    #Jinv = jinv_for_field(ctx, agent, which, phi_field, build_dexpinv_matrix=build_dexpinv_matrix)
    
    # --- curvature on φ (param covector → body) ---
    if curv_w > 0.0:
        g_param_curv = compute_curvature_gradient_analytical(phi_field, generators)    # (..., d_param)
        g_body_curv  = np.einsum("...ji,...j->...i", Jinv, g_param_curv, optimize=True)
        grad_nat    += curv_w * g_body_curv * mask_vec

    

    # --- mass: ∂/∂φ (λ/2 ||φ||^2) = λ φ (param covector → body) ---
    if mass_w > 0.0:
        g_param_mass = mass_w * phi_field
        g_body_mass  = np.einsum("...ji,...j->...i", Jinv, g_param_mass, optimize=True)
        
        grad_nat    += g_body_mass * mask_vec

    # --- q↔p coupling: (1/2)||φ_p - C φ_q||^2 ---
    if cpl_w > 0.0:
        try:
            phi_q = np.asarray(getattr(agent, "phi", None), np.float32)
            phi_p = np.asarray(getattr(agent, "phi_model", None), np.float32)
            C = build_c_mapping_q2p(getattr(agent, "Phi_tilde_0", None), gen_q, gen_p, eps=eps)
            if C is not None and phi_q is not None and phi_p is not None:
                # residual in p-space
                r = phi_p - np.einsum("ab,...b->...a", C, phi_q, optimize=True)   # (..., d_p)
                if field == "phi":
                    # ∂L/∂φ_q = - C^T r  (param covector)
                    g_param = -np.einsum("ba,...a->...b", C, r, optimize=True)    # (..., d_q)
                else:
                    # ∂L/∂φ_p = r
                    g_param = r
                g_body_cpl = np.einsum("...ji,...j->...i", Jinv, g_param, optimize=True)
                grad_nat   += cpl_w * g_body_cpl * mask_vec
        except Exception as e:
            if params.get("DEBUG_PHI", False):
                print(f"[DBGALIGN-WARN] reg coupling failed: {type(e).__name__}: {e}", flush=True)

    return np.asarray(grad_nat, np.float32)



# ─────────────────────────────────────────────────────────────────────────────
# Small, focused helpers
# ─────────────────────────────────────────────────────────────────────────────

def _apply_lie_natural_regularizers(agent_i, field: str, generators, params, ctx, v_body: np.ndarray) -> np.ndarray:
    """
    Add Lie-natural regularizers (already in body coords) with safe broadcasting.
    """
    reg_nat = apply_regularization_terms_lie_natural(
        agent=agent_i,
        phi_field=np.asarray(getattr(agent_i, field), np.float32),
        generators=generators,
        field=field,
        params={**params, "step_tag": getattr(ctx, "global_step", None) if ctx is not None else None},
        agents=params.get("agents", None),   # optional
        ctx=ctx,
    )
    reg_nat = np.asarray(reg_nat, np.float32)
    if reg_nat.ndim == v_body.ndim - 1:       # (...,d) → (...,d)
        pass
    elif reg_nat.shape[-1:] in [(1,), (v_body.shape[-1],)]:
        pass
    else:
        reg_nat = np.zeros_like(v_body, dtype=np.float32)
    return v_body + (reg_nat if reg_nat.shape == v_body.shape else reg_nat[..., None])




