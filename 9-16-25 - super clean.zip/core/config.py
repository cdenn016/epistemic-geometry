import sys

def set_config_from_params(params):
    """Dynamically override config attributes from a dictionary."""
    this_module = sys.modules[__name__]
    for k, v in params.items():
        setattr(this_module, k, v)


agent_seed    = 241 

# Toggle between diagonal and full Σ initialization
diagonal_sigma = False
identical_models = False         # If True, all agents share the same p, mu_p_field, sigma_p_field
morphism_identity_when_square = False

# in your config
use_global_A        = True
enable_vfe          = True
enable_vfe_mu_sigma = True
enable_vfe_theta    = True


freeze_omega_mode = "none"     # "none" | "identity" 


# ===========================
# DOMAIN / SPATIAL SETTINGS
# ===========================
K_q           = 7
K_p           = 7     # Fiber dimension of belief/model space (depends on representation)
 
# config.py
spec_q = [(3, 1)]   # list[(ell, multiplicity)]
spec_p = [(3, 1)]
mix_generators_q = False
mix_generators_p = False

                
D             = 2           #dimension of base manifold - d=2 validated

L             = 16         #length of hypercubic base-manifold - PBCs

steps         = 500

N             = 3                      # Number of agents
max_neighbors = 3        # Max number of agent neighbors

n_jobs = N

agent_radius_range = (3,3)         #agent radii
fixed_location = True 


 
# ===========================
# COUPLINGS & PENALTIES
# ===========================

alpha                  = 0
beta                   = 1
belief_mass            = 1
curvature_weight       = 1

feedback_weight         = 0
beta_model              = 1
model_mass              = 1
model_curvature_weight  = 1


lambda_A_curv           = 1        # set >0 to enable (e.g., 1e-1)
lambda_A_cov            = 1

lambda_theta            = 0

vfe_weight              = 1

A_init_scale            = 1e-3      # small noise so grads aren’t identically zero

#==========================
#    IF NEEDED/CURIOUS
#==========================

phi_coupling_weight           = 0             # set > 0 to enable
phi_coupling_mode             = "conjugation"  # or "conjugation"


obs_mode = "synthetic"                #  "synthetic" or  "p-as-y"
obs_sigma2_true = 1e-2
obs_dim = K_q  # or set explicitly

sigma2_min = 1e-6



#======================
#
#   LEARNING RATES
#
#======================
tau_phi                 = 2e-6
tau_phi_model           = 2e-6    
tau_mu_belief           = 1e-4       
tau_sigma_belief        = 1e-4       
tau_mu_model            = 1e-4      
tau_sigma_model         = 1e-4       

A_lr                    = 1e-4

theta_lr_W              = 1e-5
theta_lr_b              = 1e-5
theta_lr_sigma2         = 1e-5
# ===========================
# INITIALIZATION
# ===========================

# ─── Belief Bundle (q) Parameters ───
q_mu_range                     = (-1.0, 1.0)              # Range for μ_q
q_sigma_range                  = (0.2, 1.0)           # Diagonal Σ_q entries

belief_noise_scale_mu          = 0.01         # Additive noise for μ_q
belief_noise_scale_sigma       = 0.01      # Additive noise for Σ_q


# ─── Model Bundle (p) Parameters ───
p_mu_range                     = (-1.0, 1.0)             # Range for μ_p
p_sigma_range                  = (0.2, 1.0)           # Diagonal Σ_p entries

model_noise_scale_mu           = 0.01          # Additive noise for μ_p
model_noise_scale_sigma        = 0.01       # Additive noise for Σ_p

sigma_outside_val              = 4  # large uncertainty outside support


phi_init_smooth_sigma   = 1.5
phi_init                = 0.1
phi_model_offset        = 0.1



# ===========================
# MASK & INTERACTION THRESHOLDS
# ===========================
 
overlap_eps        = 1e-6     # Threshold for computing inter-agent overlap
support_tau        = 1e-6           #  # Mask threshold to include point in agent support


# ===== DEBUG / DIAGNOSTICS =====

debug_phase_timing = False
debug_grad_timing  = False


#================================
#
#  INITIALIZE GLOBAL FIELDS 
#      WITH GENTLE NOISE
#================================
use_global_belief_template = False
use_global_model_template  = False

# ===========================
# STABILITY AND CLIPPING
# ===========================
   
gradient_clip_phi         = -1     # clip ‖∇φ‖ per pixel to ≤ 1.0
gradient_clip_phi_model   = -1     # same for φ̃

theta_grad_clip           = -1
A_grad_clip               = -1

# ===========================
# EPSILONS & NUMERICAL STABILITY
# ==========================

eps                = 1e-8 #numerical general purpose eps

domain_size = (L,) * D
num_cores   = 1  # or however many threads you want to use



