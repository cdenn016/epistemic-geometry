from __future__ import annotations
"""
Created on Tue Aug 12 20:36:43 2025

@author: chris and christine
"""
# -*- coding: utf-8 -*-
"""run_sim_utils — streamlined"""

import os, pickle
from typing import Dict
import numpy as np
import core.config as config

from core.get_generators import make_reducible_generators
from diagnostics import compute_global_metrics, print_energy_breakdown
from core.agent_initialization import initialize_agents
from dataclasses import asdict

from runtime_context import build_step_settings_from_overrides  # already in your file
from diagnostics import total_energy
import json, pathlib
from utils import zero_all_gradients
# ------------------------------- Logging defaults ----------------------------
# replace your LOGGING_DEFAULTS with this
LOGGING_DEFAULTS = dict(
    enable_scalar=True,          # per-step scalar metrics
    enable_fields=False,         # heavy snapshots off by default
    child_snapshot_every=0,
    child_snapshot_dir="children",
    full_field_outdir="snapshots",  # <— used by generalized_simulation.py
)




def _extract_global_from_Q(Q) -> dict:
    """
    Accepts a dict-like or object 'Q' from compute_total_action(...) and
    returns ONLY numeric fields for logging. Skips strings/bools and metadata.
    Also supports tiny dicts like {'value': 1.23, 'w': 1, 'src': 'cached'}.
    """
   
    import numbers as _numbers

    def _is_num(x):
        # true for Python/NumPy numbers, false for bools
        if isinstance(x, (bool, np.bool_)):
            return False
        return isinstance(x, _numbers.Number) or (isinstance(x, np.generic) and np.issubdtype(type(x), np.number))

    def _coerce_num(x):
        # dict with 'value' → extract; tuple/list → first numeric element; else None
        if _is_num(x):
            return float(x)
        if isinstance(x, dict) and "value" in x and _is_num(x["value"]):
            return float(x["value"])
        if isinstance(x, (list, tuple)) and len(x) > 0 and _is_num(x[0]):
            return float(x[0])
        return None

    out = {}
    if Q is None:
        return out

    if isinstance(Q, dict):
        for k, v in Q.items():
            val = _coerce_num(v)
            if val is not None:
                out[k] = val
        return out

    # object-like fallback: pick common attributes if numeric
    for k in ("Action_total","Geom_total","VFE_acc","A_curv","A_cov","ModelPrior","Curv","Frame","Comm_KL","Transp_KL"):
        if hasattr(Q, k):
            val = _coerce_num(getattr(Q, k))
            if val is not None:
                out[k] = val
    return out




def log_and_viz_after_step(runtime_ctx, agents, step, outdir, params, logcfg,
                           parent_metrics, metric_log, num_cores):
    """
    Minimal, objective-faithful logging hook.
    - Uses ctx+cache diagnostics for energies (self, feedback, mass, curvature).
    - Leaves your existing field logging/viz toggles intact:
        logcfg["enable_scalar"], logcfg["enable_fields"], etc. (optional)
    - No global config access; everything via runtime_ctx.config if needed.
    """
    ctx = runtime_ctx
        
    # ---- 1) Energies from the SAME primitives as the solver ----
    metrics_global = compute_global_metrics(ctx, agents)
    print_energy_breakdown(ctx, metrics_global)
    
    E, terms = total_energy(ctx, agents, return_breakdown=True)
    metrics_global = dict(terms); metrics_global["E_total"] = E

    # ---- 3) Optional: push per-step scalars into your trackers ----
    if bool(logcfg.get("enable_scalar", True)):
        metric_log.append({
            "step": int(getattr(ctx, "global_step", step)),
            "E_total": float(metrics_global.get("E_total", 0.0)),
            "mean_total": float(metrics_global.get("mean_total", 0.0)),
            "self_sum": float(metrics_global.get("self_sum", 0.0)),
            "feedback_sum": float(metrics_global.get("feedback_sum", 0.0)),
            "mass_q_sum": float(metrics_global.get("mass_q_sum", 0.0)),
            "mass_p_sum": float(metrics_global.get("mass_p_sum", 0.0)),
            "curv_q_sum": float(metrics_global.get("curv_q_sum", 0.0)),
            "curv_p_sum": float(metrics_global.get("curv_p_sum", 0.0)),
        })





def load_checkpoint(outdir: str):
    # prefer compressed if present
    for name in ("checkpoint.pkl.xz", "checkpoint.pkl"):
        p = os.path.join(outdir, name)
        if os.path.exists(p):
            if name.endswith(".xz"):
                import lzma
                with lzma.open(p, "rb") as f:
                    return pickle.load(f), name
            with open(p, "rb") as f:
                return pickle.load(f), name
    # fall back to last step_XXXX
    step_files = sorted([f for f in os.listdir(outdir) if f.startswith("step_") and (f.endswith(".pkl") or f.endswith(".pkl.xz"))])
    if not step_files: return (None, None)
    last = step_files[-1]
    if last.endswith(".xz"):
        import lzma
        with lzma.open(os.path.join(outdir, last), "rb") as f:
            return pickle.load(f), last
    with open(os.path.join(outdir, last), "rb") as f:
        return pickle.load(f), last


def find_resume_step(outdir: str) -> int:
    step_files = sorted([f for f in os.listdir(outdir) if f.startswith("step_") and (f.endswith(".pkl") or f.endswith(".pkl.xz"))])
    if not step_files: return 0
    last = step_files[-1]
    num = last.replace("step_", "").replace(".pkl.xz","").replace(".pkl","")
    try: return int(num) + 1
    except: return 0




def merge_logging_cfg(params_or_cfg) -> Dict:
    cfg = {}
    if hasattr(params_or_cfg, "get"):       # dict-like
        cfg = params_or_cfg.get("logging", {}) or {}
    elif hasattr(params_or_cfg, "__dict__"): # module-like (config)
        cfg = getattr(params_or_cfg, "logging", {}) or {}
    out = dict(LOGGING_DEFAULTS)
    out.update(cfg)
    return out


# ------------------------------ Generator prep ------------------------------

# ------------------------------ Generator prep ------------------------------
def prepare_generators(params):
    """
    Resolve (Gq, Gp) in canonical shape (3, K, K), float32.
    Priority:
      1) explicit params["generators_q"/"generators_p"]
      2) SO(3) spec via params["so3_spec_q"/"so3_spec_p"] (+ optional mix)
      3) SO(3) spec + mix pulled from core.config (spec_q/spec_p, mix_generators_q/mix_generators_p)
    Side effect: sets config.K_q, config.K_p to match returned gens.
    """
    p = dict(params or {})

    # ---- Path 1: explicit tensors ----
    Gq = p.get("generators_q", None)
    Gp = p.get("generators_p", None)
    if (Gq is not None) and (Gp is not None):
        Gq = np.asarray(Gq, dtype=np.float32)
        Gp = np.asarray(Gp, dtype=np.float32)
        if Gq.ndim != 3 or Gq.shape[0] != 3 or Gq.shape[1] != Gq.shape[2]:
            raise ValueError(f"generators_q must be (3,Kq,Kq), got {Gq.shape}")
        if Gp.ndim != 3 or Gp.shape[0] != 3 or Gp.shape[1] != Gp.shape[2]:
            raise ValueError(f"generators_p must be (3,Kp,Kp), got {Gp.shape}")
        config.K_q = int(Gq.shape[1]); config.K_p = int(Gp.shape[1])
        return Gq, Gp

    # ---- Path 2: specs in params ----
    spec_q = p.get("so3_spec_q", None)
    spec_p = p.get("so3_spec_p", None)
    mix_all = bool(p.get("so3_mix_blocks", False))
    if (spec_q is not None) and (spec_p is not None):
        Gq = make_reducible_generators(spec_q, mix=mix_all).astype(np.float32, copy=False)
        Gp = make_reducible_generators(spec_p, mix=mix_all).astype(np.float32, copy=False)
        if Gq.ndim != 3 or Gq.shape[0] != 3 or Gq.shape[1] != Gq.shape[2]:
            raise ValueError(f"built generators_q not (3,Kq,Kq): {Gq.shape}")
        if Gp.ndim != 3 or Gp.shape[0] != 3 or Gp.shape[1] != Gp.shape[2]:
            raise ValueError(f"built generators_p not (3,Kp,Kp): {Gp.shape}")
        config.K_q = int(Gq.shape[1]); config.K_p = int(Gp.shape[1])
        return Gq, Gp

    # ---- Path 3: specs + mix from config ----
    cfg_spec_q = getattr(config, "spec_q", None)
    cfg_spec_p = getattr(config, "spec_p", None)
    if (cfg_spec_q is not None) and (cfg_spec_p is not None):
        mix_q = bool(getattr(config, "mix_generators_q", False))
        mix_p = bool(getattr(config, "mix_generators_p", False))
        Gq = make_reducible_generators(cfg_spec_q, mix=mix_q).astype(np.float32, copy=False)
        Gp = make_reducible_generators(cfg_spec_p, mix=mix_p).astype(np.float32, copy=False)
        if Gq.ndim != 3 or Gq.shape[0] != 3 or Gq.shape[1] != Gq.shape[2]:
            raise ValueError(f"built generators_q not (3,Kq,Kq): {Gq.shape}")
        if Gp.ndim != 3 or Gp.shape[0] != 3 or Gp.shape[1] != Gp.shape[2]:
            raise ValueError(f"built generators_p not (3,Kp,Kp): {Gp.shape}")
        config.K_q = int(Gq.shape[1]); config.K_p = int(Gp.shape[1])
        return Gq, Gp

    raise ValueError(
        "prepare_generators: supply params['generators_q'/'generators_p'], "
        "or params['so3_spec_q'/'so3_spec_p'], or set config.spec_q/spec_p."
    )



STEP_KEYS = set(asdict(build_step_settings_from_overrides(config, {})).keys())

def apply_param_overrides_to_ctx(ctx, overrides: dict | None):
    """
    Split overrides into 'step settings' vs 'static config mirror', attach both to ctx.
    - StepSettings: goes to ctx.step_cfg (typed dataclass)
    - Everything else: merged into ctx.config (dict mirror)
    """
    overrides = dict(overrides or {})
    # 1) StepSettings (typed)
    ctx.step_cfg = build_step_settings_from_overrides(config, {k: v for k, v in overrides.items() if k in STEP_KEYS})
    # 2) Config mirror (non-step keys)
    base_cfg = {k: getattr(config, k) for k in dir(config) if not k.startswith("_")}
    base_cfg.update({k: v for k, v in overrides.items() if k not in STEP_KEYS})
    ctx.config = base_cfg
    return ctx
# -------------------------- Init / resume helpers ---------------------------

def initialize_or_resume(outdir: str, resume: bool, params: Dict, clear_agent_logs: bool = True):
    """Return (agents, step_start)."""
    if resume:
        agents, _ = load_checkpoint(outdir)
        step_start = find_resume_step(outdir)
    else:
        
        gq = params.get("generators_q") if isinstance(params, dict) else None
        gp = params.get("generators_p") if isinstance(params, dict) else None
        
        # >>> NEW: sanity so we never silently synthesize when we expected prepared gens <<<
        if not resume:
            assert gq is not None and gp is not None, (
                "initialize_or_resume: expected prepared generators in params "
                "('generators_q' and 'generators_p'). Ensure run_simulation() sets them."
            )

        agents = initialize_agents(
            seed=params.get("seed", 0),
            domain_size=(config.L, config.L),
            N=config.N,
            K_q=config.K_q,
            K_p=config.K_p,
            lie_algebra_dim=getattr(config, "lie_algebra_dim", 3),
            fixed_location=getattr(config, "fixed_location", True),
            params=params,
            generators_q=gq,
            generators_p=gp,
        )
        step_start = 0
        for A in agents:
            zero_all_gradients(A)
        if clear_agent_logs:
            for A in agents:
                if hasattr(A, "metrics_log"):
                    A.metrics_log.clear()
    return agents, step_start




def save_step(agents, outdir, step, *, save_every=1, compress=True):
    import os, pickle
    os.makedirs(outdir, exist_ok=True)
    if (step % int(save_every)) != 0:
        return
    fname = os.path.join(outdir, f"step_{step:04d}.pkl")
    if compress:
        import lzma
        with lzma.open(fname + ".xz", "wb", preset=3) as f:
            pickle.dump(agents, f, protocol=pickle.HIGHEST_PROTOCOL)
    else:
        with open(fname, "wb") as f:
            pickle.dump(agents, f, protocol=pickle.HIGHEST_PROTOCOL)


  

# --- fix: checkpoint save_step wrong kw ---------------------------------------
def checkpoint_step(agents, outdir):
    """Optional pre-checkpoint compaction; then save a non-step checkpoint."""
    for A in agents:
        if hasattr(A, "clear_omega_cache"):   A.clear_omega_cache()
        if hasattr(A, "clear_fisher_caches"): A.clear_fisher_caches()
    save_step(agents, outdir, step=None)  # filename handled by save_step





def _write_metric_artifacts(outdir: str, metric_log: list[dict]):
    if not metric_log: return
    out = pathlib.Path(outdir)
    out.mkdir(parents=True, exist_ok=True)
    # pickle (legacy) + jsonl (human/tooling-friendly)
    with open(out / "metric_log.pkl", "wb") as f:
        pickle.dump(metric_log, f, protocol=pickle.HIGHEST_PROTOCOL)
    with open(out / "metrics.jsonl", "w", encoding="utf-8") as f:
        for rec in metric_log:
            f.write(json.dumps(rec, ensure_ascii=False) + "\n")

def wrap_epilogue(runtime_ctx, agents, outdir, parent_metrics, metric_log):
    # flush metrics & a lightweight “run.json” context stub
    try:
        _write_metric_artifacts(outdir, metric_log or [])
        with open(os.path.join(outdir, "run.json"), "w", encoding="utf-8") as f:
            json.dump({
                "steps": int(getattr(getattr(runtime_ctx, "config", {}), "steps", len(metric_log)) 
                             if hasattr(runtime_ctx, "config") else len(metric_log)),
                "global_step": int(getattr(runtime_ctx, "global_step", -1)),
            }, f)
    except Exception as e:
        print(f"[WRAP] failed to write artifacts: {e}")
