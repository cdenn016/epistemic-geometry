# -*- coding: utf-8 -*-
"""
Created on Sun Sep 14 14:24:12 2025

@author: chris and christine
"""

import numpy as np
import core.config as config
from core.numerical_utils import safe_inv, sanitize_sigma, safe_omega_inv
from core.transport_cache import E_grid,build_dexpinv_matrix, Jinv_grid, _aid

from core.omega import exp_lie_algebra_irrep
from core.numerical_utils import push_gaussian



# =========================
# Basic, stable miscellany
# =========================



def list_nonnull(xs):
    return [x for x in (xs or []) if x is not None]

def mean_norm(arr):
    if arr is None:
        return np.nan
    x = np.asarray(arr)
    if x.ndim >= 3:
        return float(np.nanmean(np.linalg.norm(x, axis=-1)))
    if x.ndim == 2:
        return float(np.nanmean(np.abs(x)))
    return np.nan



# =========================
#         Masks
# =========================

# --- MASKS ---------------------------------------------------------------

def make_soft_mask(
    center: tuple[int, ...],
    radius: float,
    domain_size: tuple[int, ...],
    *,
    cutoff: float | None = None,
    dtype: np.dtype | None = None,
    return_bool: bool = False,
) -> np.ndarray | tuple[np.ndarray, np.ndarray]:
    """
    Unified soft (Gaussian) mask on a periodic domain with optional cutoff.
    - If return_bool=True, also returns a boolean mask using the same cutoff.
    """
    dtype = dtype if dtype is not None else getattr(config, 'dtype', np.float64)
    cutoff = float(getattr(config, 'support_tau', 1e-3) if cutoff is None else cutoff)

    grids = np.ogrid[tuple(slice(0, s) for s in domain_size)]
    dist2 = 0.0
    for d, size in enumerate(domain_size):
        delta = np.abs(grids[d] - center[d])
        delta = np.minimum(delta, size - delta)
        dist2 = dist2 + delta * delta

    r = max(radius, np.finfo(float).eps)
    m = np.exp(-(np.sqrt(dist2) / r) ** 2).astype(dtype)

    if cutoff > 0.0:
        m[m < cutoff] = 0.0
    m = m.astype(np.float32, copy=False)
    if return_bool:
        return m, (m > 0).astype(bool)
    return m




def mask_hw(x, *, tau: float, as_vector: bool = True):
    """
    Standardized mask extractor: (H,W,float32)->threshold->bool or (H,W,1) float.
    """
    m = getattr(x, "mask", x)
    m = np.asarray(m, np.float32)
    if m.ndim >= 3:
        m = m[..., 0]
    if m.ndim == 0:
        m = np.array([[float(m)]], dtype=np.float32)
    mb = (m > tau)
    return (mb.astype(np.float32)[..., None]) if as_vector else mb


def _joint_mask(a, b, *, tau: float, as_vector: bool = True):
    mb = mask_hw(a, tau=tau, as_vector=False) & mask_hw(b, tau=tau, as_vector=False)
    return (mb.astype(np.float32)[..., None]) if as_vector else mb




def normalize_mask(m, HW):
    H, W = HW
    mm = np.asarray(m, np.float32)
    if mm.ndim >= 3:
        mm = mm[..., 0]
    out = np.zeros((H, W), dtype=np.float32)
    h = min(H, mm.shape[0]); w = min(W, mm.shape[1])
    out[:h, :w] = mm[:h, :w]
    return out


def standardize_all_masks_once(all_agents, HW):
    H, W = HW
    for a in all_agents:
        if hasattr(a, "mask") and a.mask is not None:
            a.mask = normalize_mask(a.mask, (H, W))




def zero_all_gradients(agent):
    """
    Zero (and if missing, create) all gradient buffers,
    keeping legacy aliases in sync and ensuring arrays are writeable.
    """
    def ensure_buf(name, like):
        arr = getattr(agent, name, None)
        if arr is None and like is not None:
            arr = np.zeros_like(like)
        elif arr is not None and not arr.flags.writeable:
            arr = np.array(arr, copy=True)
        setattr(agent, name, arr)
        return arr

    # Canonical grads (create from fields if needed)
    g_mu_q   = ensure_buf("grad_mu_q",    getattr(agent, "mu_q_field", None))
    g_sg_q   = ensure_buf("grad_sigma_q", getattr(agent, "sigma_q_field", None))
    g_mu_p   = ensure_buf("grad_mu_p",    getattr(agent, "mu_p_field", None))
    g_sg_p   = ensure_buf("grad_sigma_p", getattr(agent, "sigma_p_field", None))
    g_phi    = ensure_buf("grad_phi",       getattr(agent, "phi", None))
    g_phit   = ensure_buf("grad_phi_tilde", getattr(agent, "phi_model", None))


 
    # Keep legacy aliases in sync (as references, not copies)
    if g_mu_q is not None:
        agent.grad_mu_q_field = g_mu_q
    if g_sg_q is not None:
        agent.grad_sigma_q_field = g_sg_q
    if g_mu_p is not None:
        agent.grad_mu_p_field = g_mu_p
    if g_sg_p is not None:
        agent.grad_sigma_p_field = g_sg_p

    # Zero safely
    for arr in (g_mu_q, g_sg_q, g_mu_p, g_sg_p, g_phi, g_phit):
        if isinstance(arr, np.ndarray):
            arr.fill(0)


# === fiber view =============================================================

def fiber_view(agent, field: str, *, require_generators: bool = False):
    """
    Unified access to a fiber.
    Returns dict:
      {
        "which": "q"|"p",
        "mu":   (H,W,K),
        "Sigma":(H,W,K,K),
        "phi":  (..., d)  # your current storage for this fiber
        "G":    (d,K,K) or None,
        "K":    int
      }
    Accepts legacy attribute spellings transparently and validates shapes.
    """
    which = "q" if field == "phi" else "p"
    H, W = agent.mask.shape

    if which == "q":
        mu   = getattr(agent, "mu_q_field",  None)
        Sig  = getattr(agent, "sigma_q_field", None)
        phi  = getattr(agent, "phi_field",   getattr(agent, "phi", None))
        G    = getattr(agent, "generators_q", getattr(agent, "G_q", None))
    else:
        mu   = getattr(agent, "mu_p_field",  None)
        Sig  = getattr(agent, "sigma_p_field", None)
        phi  = getattr(agent, "phi_model_field", getattr(agent, "phi_model", None))
        G    = getattr(agent, "generators_p", getattr(agent, "G_p", None))

    if mu is None or Sig is None or phi is None:
        raise AttributeError(f"agent missing fields for fiber '{which}'")

    mu  = np.asarray(mu,  np.float32)
    Sig = np.asarray(Sig, np.float32)
    phi = np.asarray(phi, np.float32)

    if mu.shape[:2] != (H, W):
        raise ValueError(f"mu shape {mu.shape} incompatible with mask {(H,W)}")
    if Sig.shape[:2] != (H, W) or Sig.shape[-1] != Sig.shape[-2] or mu.shape[-1] != Sig.shape[-1]:
        raise ValueError(f"Sigma shape {Sig.shape} incompatible with mu {mu.shape}")

    if require_generators and G is None:
        raise AttributeError(f"generators missing for fiber '{which}'")
    G_arr = None if G is None else np.asarray(G, np.float32)

    return {"which": which, "mu": mu, "Sigma": Sig, "phi": phi, "G": G_arr, "K": int(mu.shape[-1])}


def fiber_keys(mode: str):
    if mode == "belief": return "q", "mu_q_field", "sigma_q_field"
    if mode == "model":  return "p", "mu_p_field", "sigma_p_field"
    raise ValueError(f"Unsupported mode: {mode}")

def _fiber_views(A, which: str):
    field = "phi" if which.lower() == "q" else "phi_model"
    fv = fiber_view(A, field)
    return fv["mu"], fv["Sigma"], fv["phi"], fv["G"], fv["K"]




# =========================
# Transports & dexp
# =========================



def _apply_fisher_in_body(agent_i, fisher_inv_key: str, g_body: np.ndarray, params) -> np.ndarray:
    """
    v_body = F^{-1} g_body with flexible shapes (full, diag, or scalar field).
    """
    v_body = g_body
    F_inv = getattr(agent_i, fisher_inv_key, None)
    if F_inv is not None:
        Fi = np.asarray(F_inv, np.float32)
        if np.all(np.isfinite(Fi)) and Fi.size > 0:
            fisher_max_norm = float(params.get("fisher_max_norm",
                                               getattr(config, "fisher_max_norm", 1e3)))
            Finf = float(np.max(np.abs(Fi)))
            if np.isfinite(Finf) and Finf > fisher_max_norm:
                Fi = Fi * (fisher_max_norm / (Finf + 1e-12))
            d = int(g_body.shape[-1])
            if Fi.ndim >= 2 and Fi.shape[-2:] == (d, d):
                v_body = np.einsum("...ab,...b->...a", Fi, g_body, optimize=True)
            elif Fi.shape[-1:] == (d,):
                v_body = g_body * Fi
            elif Fi.ndim == g_body.ndim - 1:
                v_body = g_body * Fi[..., None]
    return v_body




def exp_and_jinv_single(ctx, agent, field: str, base_field: np.ndarray, gens_src, gens_tgt):
    which = "q" if field == "phi" else "p"
    G_q = gens_tgt if which == "q" else gens_src
    G_p = gens_src if which == "q" else gens_tgt

    if ctx is not None:
        exp_q = E_grid(ctx, agent, which="q")
        exp_p = E_grid(ctx, agent, which="p")
        Jinv  = Jinv_grid(ctx, agent, which=which) or build_dexpinv_matrix(np.asarray(base_field, np.float32))
    else:
        phi_q = np.asarray(getattr(agent, "phi"),       np.float32)
        phi_p = np.asarray(getattr(agent, "phi_model"), np.float32)
        exp_q = exp_lie_algebra_irrep(phi_q, G_q)
        exp_p = exp_lie_algebra_irrep(phi_p, G_p)
        Jinv  = build_dexpinv_matrix(np.asarray(base_field, np.float32))

    exp_this  = exp_q if which == "q" else exp_p
    exp_other = exp_p if which == "q" else exp_q
    return exp_this, exp_other, Jinv, which, G_q, G_p



# =========================
# Neighbor pushes (μ, Σ)
# =========================




def push_neighbor_stats(agent_j, sigma_key: str, Omega_ij: np.ndarray, eps: float, params=None):
    """
    Small + stable: if Σ_j^{-1} exists and is finite, inverse-push it.
    Else forward-push Σ_j and invert at the end.
    Returns (mu_j_t, Sigma_j_t_inv).
    """
    mu_j = np.asarray(getattr(agent_j, sigma_key.replace("sigma", "mu")), np.float32)

    # Try inverse-push path first
    inv_key = sigma_key.replace("_field", "_inv")
    S_inv = getattr(agent_j, inv_key, None)
    if S_inv is not None:
        S_inv = np.asarray(S_inv, np.float32)
        if S_inv.size and np.all(np.isfinite(S_inv)):
            Oinv = safe_omega_inv(Omega_ij, eps=eps)
            Oinv_T = np.swapaxes(Oinv, -1, -2)
            S_inv_t = np.einsum("...ik,...kl,...jl->...ij", Oinv_T, S_inv, Oinv, optimize=True)
            if np.all(np.isfinite(S_inv_t)):
                mu_t = np.einsum("...ij,...j->...i", Omega_ij, mu_j, optimize=True)
                return mu_t, S_inv_t

    # Fallback: forward-push Σ then invert (exact, fully stabilized)
    Sigma_j = sanitize_sigma(np.asarray(getattr(agent_j, sigma_key), np.float32), eps=eps)
    mu_t, S_t, _ = push_gaussian(
        mu=mu_j, Sigma=Sigma_j, M=Omega_ij, eps=eps,
        symmetrize=True, sanitize=True, approx="exact",
        near_identity_tau=0.0, return_inv=False,
    )
    return mu_t, safe_inv(S_t, eps=eps)




# =========================
# Projection, Fisher, clip, accumulate
# =========================




def naturalize_grad(grad_param: np.ndarray,
                    Jinv: np.ndarray,
                    Fi: np.ndarray | None = None,
                    clip_norm: float = 0.0) -> np.ndarray:
    """
    All-in-one: param-covector → body-covector (Jinv^T),
    apply Fisher^{-1} (full/diag/scalar), back to param (Jinv), then optional clip.
    """
    gp = np.asarray(grad_param, np.float32)
    if gp.ndim == 0:
        gp = gp.reshape((1,))
    d = Jinv.shape[-1]
    if gp.shape[-1] not in (1, d):
        # broadcast last dim to d if needed
        gp = np.broadcast_to(gp[..., :1], gp.shape[:-1] + (d,))

    g_body = np.einsum("...ji,...j->...i", Jinv, gp, optimize=True)

    if Fi is not None:
        if Fi.ndim >= 2 and Fi.shape[-2:] == (d, d):
            v_body = np.einsum("...ab,...b->...a", Fi, g_body, optimize=True)
        elif Fi.shape[-1:] == (d,):
            v_body = g_body * Fi
        else:
            v_body = g_body * Fi[..., None]
    else:
        v_body = g_body

    v_param = np.einsum("...ab,...b->...a", Jinv, v_body, optimize=True)

    if clip_norm > 0.0:
        n = np.linalg.norm(v_param, axis=-1, keepdims=True)
        v_param = v_param * np.minimum(1.0, clip_norm / np.maximum(n, 1e-9))
    return v_param




def accumulate_into(agent, grad_key: str, delta: np.ndarray):
    prev = getattr(agent, grad_key, None)
    if prev is None: prev = np.zeros_like(delta, dtype=np.float32)
    setattr(agent, grad_key, prev + delta)

# =========================
# Regularization & morphism aids
# =========================


def reg_weights(field: str, params, *, config) -> tuple[float, float, float, float]:
    """
    Returns (curv_w, fisher_w, mass_w, cpl_w) for 'phi' or 'phi_model'.
    """
    if field == "phi":
        curv_w   = float(params.get("curvature_weight",          getattr(config, "curvature_weight", 0.0)))
        fisher_w = float(params.get("fisher_geometry_weight",     getattr(config, "fisher_geometry_weight", 0.0)))
        mass_w   = float(params.get("mass_weight", params.get("belief_mass", getattr(config, "belief_mass", 0.0))))
        cpl_w    = float(params.get("phi_coupling_weight",        getattr(config, "phi_coupling_weight", 0.0)))
    elif field == "phi_model":
        curv_w   = float(params.get("model_curvature_weight",     getattr(config, "model_curvature_weight", 0.0)))
        fisher_w = float(params.get("fisher_model_geometry_weight", getattr(config, "fisher_model_geometry_weight", 0.0)))
        mass_w   = float(params.get("mass_weight", params.get("model_mass", getattr(config, "model_mass", 0.0))))
        cpl_w    = float(params.get("phi_coupling_weight",        getattr(config, "phi_coupling_weight", 0.0)))
    else:
        raise ValueError(f"Invalid field: {field}")
    return curv_w, fisher_w, mass_w, cpl_w



def which_and_gens(agent, field: str, generators):
    """Returns (which, gen_q, gen_p) aligned with the active field."""
    if field == "phi":       return "q", generators, getattr(agent, "generators_p", None)
    if field == "phi_model": return "p", getattr(agent, "generators_q", None), generators
    raise ValueError(f"Invalid field: {field}")




# =========================
# Linear algebra helpers
# =========================


def _ensure_q_to_p_shape(X, Kp, Kq):
    """Φ0: q→p must be (Kp, Kq). Auto-transpose if (Kq, Kp)."""
    X = np.asarray(X, np.float32)
    if X.shape == (Kp, Kq): return X
    if X.shape == (Kq, Kp): return X.T
    raise ValueError(f"Φ0 wrong shape {X.shape}; expected {(Kp, Kq)} or {(Kq, Kp)}")

def _ensure_p_to_q_shape(X, Kq, Kp):
    """Φ̃0: p→q must be (Kq, Kp). Auto-transpose if (Kp, Kq)."""
    X = np.asarray(X, np.float32)
    if X.shape == (Kq, Kp): return X
    if X.shape == (Kp, Kq): return X.T
    raise ValueError(f"Φ̃0 wrong shape {X.shape}; expected {(Kq, Kp)} or {(Kp, Kq)}")

def build_c_mapping_q2p(Phi_tilde_0, generators_q, generators_p, eps=1e-8):
    """
    Build linear map C (d_p x d_q) so that Ad_{Φ̃0}(G_q^a) ≈ sum_b C_{ba} G_p^b
    under Frobenius projection onto p-basis.
    """
    d_q, Kq, _ = generators_q.shape
    d_p, Kp, _ = generators_p.shape
    assert Phi_tilde_0.shape[-2:] == (Kq, Kp), "Phi_tilde_0 must be (K_q, K_p)"

    # Gram of p-basis
    Gp = np.zeros((d_p, d_p), dtype=generators_p.dtype)
    for b in range(d_p):
        for c in range(d_p):
            Gp[b, c] = np.tensordot(generators_p[b], generators_p[c])
    Gp += eps * np.eye(d_p, dtype=Gp.dtype)
    Gp_inv = safe_inv(Gp)

    Phi0    = Phi_tilde_0
    Phi0_inv = safe_inv(Phi0, eps=eps)

    C = np.zeros((d_p, d_q), dtype=generators_p.dtype)
    for a in range(d_q):
        H_a = np.einsum("ik,kl,lj->ij", Phi0, generators_q[a], Phi0_inv)
        h = np.array([np.tensordot(generators_p[b], H_a) for b in range(d_p)], dtype=H_a.dtype)
        C[:, a] = Gp_inv @ h
    return C



#===================================
# 
#         MU/SIGMA GRADIENT ACCUMULATE
# 
#=====================================


def _build_id_index_map(agents):
    """
    Map stable agent id -> index in `agents` list.
    Falls back to identity if ids are contiguous [0..N-1] and match positions.
    """
    # Fast-path: check if list index equals stable id for all agents.
    ok = True
    for idx, a in enumerate(agents):
        aid = _aid(a)
        if aid is None or int(aid) != idx:
            ok = False
            break
    if ok:
        # identity mapping (no dict allocation)
        return None  # sentinel meaning "id == index"

    # General path
    m = {}
    for idx, a in enumerate(agents):
        aid = _aid(a)
        if aid is None:
            raise ValueError("All agents must have a stable `id` when ids != indices.")
        aid = int(aid)
        if aid in m:
            raise ValueError(f"Duplicate agent id detected: {aid}")
        m[aid] = idx
    return m


def iter_overlapping_neighbors(agent_i, agents, *, support_eps: float, symmetric: bool = True):
    """
    Yield (j_idx, agent_j, overlap_mask) for neighbors of agent_i whose masks overlap.
    Enforces undirected pairs once (i_id < j_id) if symmetric=True.
    """
    nb_list = getattr(agent_i, "neighbors", []) or []
    if not nb_list:
        return

    id_index = _build_id_index_map(agents)
    i_id = int(getattr(agent_i, "id", -1))
    mask_i = mask_hw(agent_i, tau=support_eps, as_vector=False)

    for nb in nb_list:
        j_id = int(nb.get("id"))
        if symmetric and not (i_id < j_id):
            continue
        # Resolve agent_j by stable id or by index fast-path
        if id_index is None:
            # id == index fast-path
            if not (0 <= j_id < len(agents)):
                continue
            agent_j = agents[j_id]
        else:
            j_idx = id_index.get(j_id)
            if j_idx is None:
                continue
            agent_j = agents[j_idx]

        mask_j = mask_hw(agent_j, tau=support_eps, as_vector=False)
        overlap = (mask_i & mask_j)
        if not np.any(overlap):
            continue

        # Return list index for downstream in-place updates
        j_idx = j_id if id_index is None else id_index[j_id]
        yield j_idx, agent_j, overlap



# =========================
# Logging
# =========================

def log_phi_grad_like(aid, field, tag, arr):
    """Compact sign/mean/|g| logging for φ/φ̃ terms."""
    if arr is None: return
    spatial_axes = tuple(range(arr.ndim - 1))
    g_mean = np.mean(arr, axis=spatial_axes)
    sign = "".join("+" if x > 0 else "-" if x < 0 else "0" for x in g_mean.tolist())
    g_abs_mean = float(np.mean(np.abs(arr)))
    print(f"[PHI] field={field} ai={aid} term={tag} "
          f"sign={sign} mean={np.array2string(g_mean, precision=3, suppress_small=True)} "
          f"|g|_mean={g_abs_mean:.3e}", flush=True)




def thread_ctx(params, runtime_ctx):
    params = {} if params is None else dict(params)
    if runtime_ctx is not None:
        params["runtime_ctx"] = runtime_ctx
    return params, params.get("runtime_ctx", None)

def get_neighbors(agent_i, agents):
    nbs = getattr(agent_i, "neighbors", []) or []
    if isinstance(agents, dict):
        lookup = {int(k): v for k, v in agents.items()}
    else:
        lookup = {int(getattr(a, "id", i)): a for i, a in enumerate(agents)}
    out = []
    for nb in nbs:
        try:
            j = int(nb.get("id"))
        except Exception:
            continue
        a = lookup.get(j)
        if a is not None:
            out.append(a)
    return out



def _pull_agent_fields(agent_i, mu_key: str, sigma_key: str):
    return getattr(agent_i, mu_key), getattr(agent_i, sigma_key)


def _phi_mats(ctx, agent_i):
    
    from core.transport_cache import Phi
    # cache-owned matrices
    Phi_mat       = Phi(ctx, agent_i, kind="q_to_p")
    Phi_tilde_mat = Phi(ctx, agent_i, kind="p_to_q")
    return Phi_mat, Phi_tilde_mat


def _materialize_morphism(M_full, H, W, Kout, Kin, r, c):
    """
    Normalize a morphism representation to either:
      - (Kout, Kin)  (global matrix), or
      - (M, Kout, Kin)  (per-active-pixel batch)
    Accepts inputs shaped:
      - (Kout, Kin)
      - (M, Kout, Kin)         # already sliced by caller
      - (H, W, Kout, Kin)      # per-pixel field -> we index with (r,c)
    """
    import numpy as np
    M = np.asarray(M_full, np.float32)
    if M.ndim == 2 and M.shape == (Kout, Kin):
        return M  # global morphism
    if M.ndim == 3 and M.shape[1:] == (Kout, Kin):
        # assume already per-item (M == len(r))
        if M.shape[0] != len(r):
            raise ValueError(f"morphism batch length {M.shape[0]} != active pixels {len(r)}")
        return M
    if M.ndim == 4 and M.shape[:2] == (H, W) and M.shape[2:] == (Kout, Kin):
        return M[r, c]  # (M, Kout, Kin)
    raise ValueError(f"unexpected morphism shape {M.shape}; expected (Kout,Kin), (M,Kout,Kin), or (H,W,Kout,Kin)")





