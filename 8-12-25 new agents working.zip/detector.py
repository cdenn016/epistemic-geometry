# detector_online.py
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple
import numpy as np

import config
from agent_schema import Agent
from meta_agent_utils import compute_pairwise_agreement_maps, build_parent_mask_from_group
from meta_gauge_fields import coarsen_phi_from_children
import numpy as np, config
from agent_schema import Agent
from meta_agent_utils import build_parent_mask_from_group
from meta_gauge_fields import coarsen_phi_from_children
from runtime_context import runtime_ctx  # holds global_step

from meta_agent_utils import build_parent_mask_from_group
import numpy as np, config
  
# detector.py
import numpy as np
from collections import deque
from typing import Dict, List, Tuple, Optional

from parent_mask_utils import child_activity_map, cheap_dt, _iou_binary, resize_nn



@dataclass
class Region:
    id: int
    mask: np.ndarray               # (H,W) float32 in [0,1]
    state: str                     # 'candidate'|'incubating'|'active'|'decaying'
    age: int = 0
    t_activated: Optional[int] = None
    child_ids: List[int] = field(default_factory=list)


@dataclass
class DetectorState:
    regions: Dict[int, Region] = field(default_factory=dict)
    next_id: int = 0
    step: int = 0




def _make_region(mask: np.ndarray, rid: int):
    """
    Construct a Region with whatever signature your project uses.
    Tries several common ctor shapes; falls back to a simple object.
    """
    area  = int((mask > 0).sum())
    state = getattr(config, "region_active_state", "active")  # or 1 / True, if your code uses enums

    # Try common constructor shapes
    attempts = [
        lambda: Region(id=rid, state=state, mask=mask, area=area),
        lambda: Region(id=rid, state=state, mask=mask),
        lambda: Region(rid, state, mask),           # positional
        lambda: Region(mask=mask),                  # legacy minimal
        lambda: Region(mask),                       # very old minimal
    ]
    for ctor in attempts:
        try:
            return ctor()
        except TypeError:
            pass

    # Fallback: lightweight object with the fields we need downstream
    class _R: pass
    R = _R()
    R.id = rid
    R.state = state
    R.mask = mask
    R.area = area
    return R



def _label_components(binmap: np.ndarray) -> Tuple[np.ndarray, int]:
    H, W = binmap.shape
    labels = np.zeros((H, W), dtype=np.int32)
    lbl = 0
    seen = np.zeros_like(binmap, dtype=bool)
    for y in range(H):
        for x in range(W):
            if not binmap[y, x] or seen[y, x]: 
                continue
            lbl += 1
            q = deque([(y, x)])
            seen[y, x] = True
            labels[y, x] = lbl
            while q:
                cy, cx = q.popleft()
                for ny, nx in ((cy-1,cx),(cy+1,cx),(cy,cx-1),(cy,cx+1)):
                    if 0 <= ny < H and 0 <= nx < W and binmap[ny, nx] and not seen[ny, nx]:
                        seen[ny, nx] = True
                        labels[ny, nx] = lbl
                        q.append((ny, nx))
    return labels, lbl














def _parent_kl_stats(P, children, support_mask=None,
                     activity_mu_tau: float = 1e-3,
                     activity_trsig_tau: float = 1e-3,
                     eps: float = 1e-6) -> tuple[float, float]:
    """
    Robust mean/median KL inside a given support mask (or P.mask if None),
    aggregated over assigned *active* kids.
    Returns (mean, median); (inf, inf) if insufficient data.

    Activity = child mask & (||μ_q|| > tau OR tr(Σ_q) > tau).
    """

    # choose evaluation support
    pmask = np.asarray(support_mask if support_mask is not None else P.mask)
    if pmask.ndim != 2:
        pmask = pmask.squeeze()
    H, W = pmask.shape
    supp_parent = (pmask > 1e-2)
    if not supp_parent.any():
        return float("inf"), float("inf")

    vals = []
    child_ids = getattr(P, "child_ids", None)

    for ch in children:
        if child_ids is not None:
            # if child list is a subset, skip non-assigned
            if ch not in [children[i] for i in child_ids]:
                continue
        if getattr(ch, "parent_ids", None) is not None and (P.id not in ch.parent_ids):
            continue

        kl = getattr(ch, "cached_alignment_kl", None)
        if kl is None:
            continue

        k = np.asarray(kl)
        if k.ndim == 3 and k.shape[-1] == 1:
            k = k[..., 0]
        if k.shape != (H, W):
            k = resize_nn(k, (H, W))

        # activity gating
        act = child_activity_map(ch, H, W,
                                 mu_tau=activity_mu_tau,
                                 trsig_tau=activity_trsig_tau,
                                 eps=eps)
        if act is None:
            continue

        # restrict to BOTH supports: parent & child activity
        supp = supp_parent & act
        if not supp.any():
            continue

        v = k[supp]
        v = v[np.isfinite(v)]
        if v.size:
            vals.append(v)

    if not vals:
        return float("inf"), float("inf")

    vcat = np.concatenate(vals, axis=0)
    vcat = vcat[np.isfinite(vcat)]
    if vcat.size == 0:
        return float("inf"), float("inf")

    return float(vcat.mean()), float(np.median(vcat))





def _alignment_score_from_pairs(children: List[Agent], *, field: str, generators, tau=0.30) -> np.ndarray:
    """
    Fast proxy: 1 - mean(agreement) over all neighbors per pixel.
    Uses your compute_pairwise_agreement_maps (A = exp(-KL/tau)).
    """
    H, W = children[0].mask.shape
    pairs, A_maps, joint = compute_pairwise_agreement_maps(children, tau=tau, field=("q" if field=="belief" else "p"), generators=generators)
    if not pairs:
        return np.ones((H, W), dtype=np.float32)
    acc = np.zeros((H, W), dtype=np.float32)
    cnt = np.zeros((H, W), dtype=np.float32)
    for key, A in A_maps.items():
        J = joint[key]
        acc[J] += A[J]
        cnt[J] += 1.0
    cnt = np.maximum(cnt, 1.0)
    agree_mean = acc / cnt
    return 1.0 - agree_mean  # lower is better


def _update_regions_hysteresis(det: DetectorState, score: np.ndarray,
                               *, Ton: float, Toff: float,
                               persistence_on: int, persistence_off: int,
                               min_area: int, smooth_iters: int) -> None:
    """
    Very small state machine: grow where score<Ton, decay where score>Toff.
    """
    H, W = score.shape
    low = (score < Ton).astype(np.float32)
    high = (score > Toff).astype(np.float32)

    # simple smoothing (same kernel as your utils)
    if smooth_iters > 0:
        k = np.array([[1,1,1],[1,2,1],[1,1,1]], dtype=np.float32); k /= k.sum()
        for _ in range(smooth_iters):
            pad = np.pad(low, 1, mode="edge")
            sm  = (
                k[0,0]*pad[:-2, :-2] + k[0,1]*pad[:-2,1:-1] + k[0,2]*pad[:-2,2:] +
                k[1,0]*pad[1:-1, :-2] + k[1,1]*pad[1:-1,1:-1] + k[1,2]*pad[1:-1,2:] +
                k[2,0]*pad[2:,  :-2] + k[2,1]*pad[2:, 1:-1] + k[2,2]*pad[2:,  2:]
            )
            low = np.clip(sm, 0.0, 1.0).astype(np.float32)

    # single region for now: union of low-score (you can split components if desired)
    core = (low > 0.5)
    area = int(core.sum())

    # find (or create) region 0
    R = det.regions.get(0, None)
    if R is None:
        if area >= min_area:
            det.regions[0] = Region(id=0, mask=low.copy(), state="incubating", age=0, t_activated=None)
        return

    # update existing
    R.age += 1
    if area == 0:
        if R.state in ("incubating", "active"):
            R.state = "decaying"
        # shrink fast
        R.mask *= 0.5
    else:
        # grow towards low
        R.mask = np.clip(0.90*R.mask + 0.10*low, 0.0, 1.0)
        if R.state == "candidate":
            if (R.mask > 0.3).sum() >= min_area and R.age >= persistence_on:
                R.state = "incubating"
        elif R.state == "incubating":
            if (R.mask > 0.3).sum() >= min_area and R.age >= persistence_on:
                R.state = "active"; R.t_activated = det.step
        elif R.state == "active":
            if (high > 0.5).mean() > 0.5 and R.age >= persistence_off:
                R.state = "decaying"

    if R.state == "decaying":
        R.mask *= 0.8
        if (R.mask > 0.3).sum() < (min_area // 2):
            del det.regions[0]


def detector_tick(agents: List[Agent], det: DetectorState, *,
                  field: str, generators, cfg: dict) -> Dict[int, Region]:
    """
    One call per detector_period. Updates det.regions in-place and returns active regions.
    cfg keys: Ton, Toff, persistence_on, persistence_off, min_area, smooth_iters, tau_align
    """
    det.step += 1
    score = _alignment_score_from_pairs(agents, field=field, generators=generators, tau=cfg.get("tau_align", 0.30))
    _update_regions_hysteresis(
        det, score,
        Ton=cfg.get("Ton", 0.10),
        Toff=cfg.get("Toff", 0.20),
        persistence_on=cfg.get("persistence_on", 3),
        persistence_off=cfg.get("persistence_off", 3),
        min_area=int(cfg.get("min_area", 50)),
        smooth_iters=int(cfg.get("smooth_iters", 1)),
    )
    return {rid: R for rid, R in det.regions.items() if R.state == "active"}



# detector.py
def spawn_or_update_parents(active_regions, agents, parents_by_id, next_parent_id, *, field_generators):
    Gq, Gp = field_generators
    if not agents:
        return list(parents_by_id.values()), next_parent_id

    H, W = agents[0].mask.shape
    dtype = agents[0].mu_q_field.dtype
    Kq = agents[0].mu_q_field.shape[-1]
    Kp = agents[0].mu_p_field.shape[-1]
    eps = getattr(config, "support_cutoff_eps", 1e-6)

    # 1) ensure parents exist & proposals updated (and get stable rid->pid mapping)
    rid_to_pid, next_parent_id = _ensure_parents_for_regions(
        active_regions, parents_by_id, next_parent_id, H, W, dtype, Kq, Kp
    )

    # 2) assign children to each parent using the stable mapping
    _assign_children_to_parents(
        active_regions, agents, parents_by_id,
        eps=eps, use_activity=True, rid_to_pid=rid_to_pid
    )

    # 3) per-parent update (mask seed, candidate, EMA, emergence)
    step_now = getattr(runtime_ctx, "global_step", 0)
    for pid, P in parents_by_id.items():
        _update_single_parent(P, agents, step_now, H, W, eps, dtype)

    # 4) coarsen φ/φ̃ after masks settle
    _refresh_parent_gauge_fields(list(parents_by_id.values()), agents, dtype)

    return list(parents_by_id.values()), next_parent_id




def detect_overlap_aligned_regions(children, *, H, W,
                                   min_kids=2,
                                   kl_tau=0.10,
                                   min_area=20,
                                   weight_tau=0.6,         # NEW: favor interior weight
                                   activity_mu_tau=1e-3, activity_trsig_tau=1e-3, eps=1e-6):

   
    
    cover = np.zeros((H, W), dtype=np.int32)
    weight = np.zeros((H, W), dtype=np.float32)   # sum of child mask weights
    kid_act, kid_kls = [], []

    for ch in children:
        m = np.asarray(ch.mask)
        if m.shape != (H, W): m = resize_nn(m, (H, W))
        act = child_activity_map(ch, H, W, mu_tau=activity_mu_tau, trsig_tau=activity_trsig_tau, eps=eps)

        if act is not None:
            a = act.astype(bool)
            cover += a.astype(np.int32)
            weight += m.astype(np.float32) * a.astype(np.float32)
        kid_act.append(act)

        k = getattr(ch, "cached_alignment_kl", None)
        if k is None: kid_kls.append(None)
        else:
            k = np.asarray(k); 
            if k.shape != (H, W): k = resize_nn(k, (H, W))
            kid_kls.append(k)

    # multi-overlap + weight core
    keep = (cover >= int(min_kids)) & (weight >= float(weight_tau))

    # KL filter
    if kl_tau is not None:
        kl_sum = np.zeros((H, W), dtype=np.float32)
        kl_cnt = np.zeros((H, W), dtype=np.int32)
        for act, k in zip(kid_act, kid_kls):
            if act is None or k is None: 
                continue
            inside = act & np.isfinite(k)
            kl_sum[inside] += k[inside].astype(np.float32)
            kl_cnt[inside] += 1
        kl_mean = kl_sum / np.maximum(kl_cnt, 1)
        kl_mean[kl_cnt == 0] = np.inf
        keep &= (kl_mean <= float(kl_tau))

    # one-pixel erosion to avoid boundary rings
    core = keep.copy()
    # 3x3 erosion
    core_eroded = core.copy()
    for _ in range(1):
        core_eroded = (core_eroded &
                       np.roll(core_eroded,  1, 0) & np.roll(core_eroded, -1, 0) &
                       np.roll(core_eroded,  1, 1) & np.roll(core_eroded, -1, 1))
    keep = core_eroded

    # connected components → regions (unchanged)
    labels, nlab = _label_components(keep)
    regions = {}
    rid = 0
    for lbl in range(1, nlab + 1):
        comp = (labels == lbl)
        if comp.sum() < int(min_area): 
            continue
        regions[rid] = _make_region(comp.astype(np.float32), rid)
        rid += 1
    return regions


def _new_parent(pid, H, W, dtype, Kq, Kp, proposal):
    zeros3 = np.zeros((H, W, 3), dtype=dtype)
    eye_q = np.tile(np.eye(Kq, dtype=dtype), (H, W, 1, 1))
    eye_p = np.tile(np.eye(Kp, dtype=dtype), (H, W, 1, 1))
    P = Agent(
        id=pid, center=(0,0), radius=0.0, mask=np.zeros((H,W), dtype=dtype),
        mu_q_field=np.zeros((H,W,Kq), dtype=dtype), sigma_q_field=eye_q.copy(),
        mu_p_field=np.zeros((H,W,Kp), dtype=dtype), sigma_p_field=eye_p.copy(),
        phi=zeros3.copy(), phi_model=zeros3.copy(), neighbors=[]
    )
    P.level = 1
    P.birth_step = getattr(runtime_ctx, "global_step", 0)
    P.lambda_q_weight = 0.0; P.lambda_p_weight = 0.0
    P._region_proposal = np.clip(proposal, 0.0, 1.0).astype(dtype)
    P.emerged = False; P._prev_eval_mask = None
    P._emerge_on_cnt = 0; P._emerge_off_cnt = 0; P._core_map = None
    return P

def _ensure_parents_for_regions(active_regions, parents_by_id, next_parent_id, H, W, dtype, Kq, Kp):
    """
    Match current regions to existing parents by IoU. Reuse on good match; else spawn new.
    Returns (rid_to_pid, next_parent_id).
    """
    iou_thr = float(getattr(config, "parent_reuse_iou_min",
                            getattr(config, "parent_reseed_iou", 0.30)))

    # cache masks
    reg_items = [(rid, np.asarray(R.mask, dtype=bool)) for rid, R in active_regions.items()]
    par_items = [(pid,
                  np.asarray((P._region_proposal if getattr(P, "_region_proposal", None) is not None else P.mask)) > 1e-3)
                 for pid, P in parents_by_id.items()]

    def _iou(A, B):
        inter = np.count_nonzero(A & B)
        if inter == 0: return 0.0
        unio  = np.count_nonzero(A | B)
        return float(inter) / float(unio) if unio else 0.0

    taken_parents = set()
    new_map = {}      # parent_id -> parent
    rid_to_pid = {}   # region id -> parent id

    for rid, Rmask in reg_items:
        best_pid, best_iou = None, 0.0
        for pid, Pmask in par_items:
            if pid in taken_parents:
                continue
            iou = _iou(Rmask, Pmask)
            if iou > best_iou:
                best_iou, best_pid = iou, pid

        if best_pid is not None and best_iou >= iou_thr:
            # reuse
            P = parents_by_id[best_pid]
            P._region_proposal = Rmask.astype(dtype)
            new_map[best_pid] = P
            rid_to_pid[rid] = best_pid
            taken_parents.add(best_pid)
        else:
            # spawn new
            Pnew = _new_parent(next_parent_id, H, W, dtype, Kq, Kp, Rmask.astype(dtype))
            new_map[next_parent_id] = Pnew
            rid_to_pid[rid] = next_parent_id
            next_parent_id += 1

    parents_by_id.clear()
    parents_by_id.update(new_map)
    return rid_to_pid, next_parent_id



def _assign_children_to_parents(active_regions, agents, parents_by_id, *, eps=None, use_activity=True, rid_to_pid=None):
    import numpy as np
    if not agents or not active_regions:
        return

    H, W = agents[0].mask.shape
    eps = float(eps if eps is not None else getattr(config, "support_cutoff_eps", 1e-6))

    # clear
    for P in parents_by_id.values():
        P.child_ids = []

    # child supports (activity-aware)
    child_support = []
    for A in agents:
        m = np.asarray(A.mask)
        if m.shape != (H, W):
            m = resize_nn(m, (H, W))
        if use_activity:
            act = child_activity_map(A, H, W,
                                     mu_tau=getattr(config, "activity_mu_tau", 1e-3),
                                     trsig_tau=getattr(config, "activity_trsig_tau", 1e-3),
                                     eps=eps)
            sup = (np.asarray(act) > 0) if act is not None else (m > eps)
        else:
            sup = (m > eps)
        child_support.append(sup)

    # use provided mapping; no dict attribute hacks
    for rid, R in active_regions.items():
        pid = rid_to_pid.get(rid, rid) if rid_to_pid else rid
        if pid not in parents_by_id:
            continue
        P = parents_by_id[pid]

        Rmask = np.asarray(R.mask)
        if Rmask.shape != (H, W):
            Rmask = resize_nn(Rmask, (H, W))
        Rbin = (Rmask > eps)

        kids = [i for i, sup in enumerate(child_support) if np.any(sup & Rbin)]
        P.child_ids = kids
        for i in kids:
            if not hasattr(agents[i], "parent_ids") or agents[i].parent_ids is None:
                agents[i].parent_ids = []
            if P.id not in agents[i].parent_ids:
                agents[i].parent_ids.append(P.id)



def _compute_parent_candidate(P, agents):
    
    cand = build_parent_mask_from_group(
        children=agents, child_ids=getattr(P, "child_ids", []),
        A_maps={}, joint_maps={}, tau=getattr(config, "tau_align_emergent", 0.30),
        m_core=getattr(config, "m_core_emergent", 2), A_min=getattr(config, "A_min_emergent", 20),
        soft=True, smooth_iters=1,
    )
    if cand is None:
        # fallback: union of child masks
        H, W = P.mask.shape
        u = np.zeros((H, W), bool)
        for i in getattr(P, "child_ids", []): u |= (np.asarray(agents[i].mask) > 0)
        return u.astype(P.mask.dtype)
    c = np.asarray(cand)
    return c[0] if (c.ndim == 3 and c.shape[0] == 1) else c



def _emergence_gate(P, agents, eval_mask, H, W, eps):
    import numpy as np

    def _iou(a, b, thr=1e-3):
        A = (a > thr); B = (b > thr)
        inter = (A & B).sum(); union = (A | B).sum()
        return float(inter) / max(1, int(union))

    # ── thresholds / hysteresis ──────────────────────────────────────────────
    EMERGE_TAU        = getattr(config, "emerge_tau", 0.2)
    EMERGE_MIN_AREA   = getattr(config, "emerge_min_area", 30)
    EMERGE_IOU_MIN    = getattr(config, "emerge_iou_min", 0.85)
    EMERGE_ON_STEPS   = getattr(config, "emerge_on", 4)
    EMERGE_OFF_STEPS  = getattr(config, "emerge_off", 3)
    EMERGE_MIN_ACTIVE = getattr(
        config, "emerge_min_active",
        max(10, int(getattr(config, "A_min_emergent", 20) // 2))
    )

    eval_mask = np.asarray(eval_mask, bool)
    area = int(eval_mask.sum())

    # ── active-area gate (child activity within eval_mask) ──────────────────
    from parent_mask_utils import child_activity_map
    active_union = np.zeros((H, W), bool)
    for i in getattr(P, "child_ids", []):
        a = child_activity_map(agents[i], H, W, eps=eps)
        if a is not None:
            active_union |= a
    active_area = int((eval_mask & active_union).sum())

    # ── KL median inside eval (guard against NaNs/inf) ──────────────────────
    kl_med = _median_child_kl_in_mask(P, agents, eval_mask)
    if not np.isfinite(kl_med):
        kl_med = 1e9  # force fail if KL is invalid

    # ── IoU with previous eval mask; bootstrap IoU until prev mask is nontrivial
    prev_mask = getattr(P, "_prev_eval_mask", None)
    if prev_mask is None:
        prev_mask = np.zeros_like(eval_mask)
    prev_area = int(prev_mask.sum())
    iou = _iou(eval_mask.astype(np.float32), prev_mask.astype(np.float32))
    iou_ok = (iou >= EMERGE_IOU_MIN) if (prev_area >= 10) else True  # <-- bootstrap

    # ── gates ────────────────────────────────────────────────────────────────
    cond_on  = (area >= EMERGE_MIN_AREA) \
               and (active_area >= EMERGE_MIN_ACTIVE) \
               and (kl_med <= EMERGE_TAU) \
               and iou_ok

    cond_off = (area < max(1, EMERGE_MIN_AREA // 2)) or (kl_med > 1.5 * EMERGE_TAU)

    # ── hysteresis counters ─────────────────────────────────────────────────
    on_cnt  = int(getattr(P, "_emerge_on_cnt", 0))
    off_cnt = int(getattr(P, "_emerge_off_cnt", 0))
    emerged = bool(getattr(P, "emerged", False))

    if cond_on:
        on_cnt, off_cnt = on_cnt + 1, 0
    elif cond_off:
        on_cnt, off_cnt = 0, off_cnt + 1
    else:
        on_cnt, off_cnt = max(0, on_cnt - 1), max(0, off_cnt - 1)

    if not emerged and on_cnt >= EMERGE_ON_STEPS:
        emerged, on_cnt = True, 0
    if emerged and off_cnt >= EMERGE_OFF_STEPS:
        emerged, off_cnt = False, 0

    # ── persist bookkeeping ────────────────────────────────────────────────
    P._emerge_on_cnt  = on_cnt
    P._emerge_off_cnt = off_cnt
    P._prev_eval_mask = eval_mask.copy()

    return emerged





def _update_single_parent(P, agents, step_now, H, W, eps, dtype):
    freeze_steps  = getattr(config, "parent_freeze_steps", 2)
    ramp_steps    = getattr(config, "parent_ramp_steps", 12)
    alpha_base    = getattr(config, "parent_mask_alpha", 0.10)
    grow_min_kids = int(getattr(config, "parent_grow_min_kids", 2))
    delta_cap     = getattr(config, "parent_max_step_delta", 0.1)
    decay_empty   = 0.995

    kids = getattr(P, "child_ids", [])
    # refresh core cheaply every step
    P._core_map = _compute_core_from_kids(P, agents, H, W, eps).astype(np.float32) if kids else None

    # one-time seed from core
    if (P.mask <= 1e-6).all() and P._core_map is not None and P._core_map.any():
        seed = P._core_map.astype(bool)
        for _ in range(max(0, int(getattr(config, "parent_seed_expand_px", 2)))):
            seed = (seed |
                    np.roll(seed,  1, 0) | np.roll(seed, -1, 0) |
                    np.roll(seed,  1, 1) | np.roll(seed, -1, 1))
        P.mask = seed.astype(dtype) * 0.5

    cand = _compute_candidate_or_union(P, agents, H, W, dtype)

    # eval mask choice for emergence
    eval_mask = (P.mask > 1e-2)
    if not eval_mask.any():
        if getattr(P, "_region_proposal", None) is not None:
            eval_mask = (np.asarray(P._region_proposal) > 1e-2)
        elif cand is not None:
            eval_mask = (np.asarray(cand) > 1e-2)

    # --- EMERGENCE HYSTERESIS (persist state) ---
    emerged = _emergence_gate(P, agents, eval_mask, H, W, eps)
    P.emerged = bool(emerged)                     # <-- critical: persist gate result


    if not P.emerged:
        target = None
        if getattr(P, "_region_proposal", None) is not None:
            target = np.asarray(P._region_proposal, dtype=np.float32)
        elif cand is not None:
            target = np.asarray(cand, dtype=np.float32)
    
        if target is not None:
            # gentle latch to keep seed alive
            alpha_seed = float(getattr(config, "parent_seed_alpha", 0.15))
            P.mask = np.clip((1.0 - alpha_seed)*P.mask.astype(np.float32) + alpha_seed*target, 0.0, 1.0).astype(dtype)
        # no return → let counters update and keep trying
        return

    # EMA schedule
    age   = step_now - getattr(P, "birth_step", step_now)
    alpha = 0.0 if age < freeze_steps else alpha_base * min(
        1.0, max(0.0, (age - freeze_steps) / max(1, ramp_steps))
    )

    # growth gates: overlap + core distance + activity
    if cand is None:
        P.mask = (decay_empty * P.mask).astype(dtype)
        return

    gate = _growth_gate_from_overlap_core_activity(P, agents, H, W, eps, grow_min_kids)
    cand = np.clip(np.asarray(cand, np.float32), 0.0, 1.0)
    
    # --- ensure a positive target on the outer ring wherever growth is allowed ---
    # binary mask + simple 4-neighborhood dilation 'grow_band' times
    mask_bin = (np.asarray(P.mask) > 1e-3)
    outer = mask_bin.copy()
    for _ in range(max(1, int(getattr(config, "grow_band", 1)))):
        outer = (outer |
                 np.roll(mask_bin,  1, 0) | np.roll(mask_bin, -1, 0) |
                 np.roll(mask_bin,  1, 1) | np.roll(mask_bin, -1, 1))
    outer = outer & (~mask_bin)
    
    # soft growth probability from gate *and* KL thresholding that gate encodes
    growth_prob = np.clip(gate.astype(np.float32), 0.0, 1.0)
    
    # build a soft ring target: current mask + a small step scaled by growth_prob
    # this gives EMA a >0 target just outside the current boundary
    eta_ring = float(getattr(config, "eta_grow", 0.5))  # reuse your existing knob
    ring_target = np.clip(P.mask.astype(np.float32) + eta_ring * growth_prob, 0.0, 1.0)
    
    # merge: wherever we're in the outer ring, push candidate up to ring_target
    cand = np.where(outer, np.maximum(cand, ring_target), cand)
    
    # finally apply gate globally to keep cand shut off where growth is disallowed
    cand = (cand * growth_prob).astype(dtype)

    if _should_reseed(P, cand):
        P.mask = cand
    else:
        delta = alpha * (cand - P.mask)
        if delta_cap is not None and delta_cap > 0:
            delta = np.clip(delta, -delta_cap, delta_cap)
        P.mask = np.clip(P.mask + delta, 0.0, 1.0).astype(dtype)


def _compute_core_from_kids(P, agents, H, W, eps):
    
    cover = np.zeros((H, W), np.int32); weight = np.zeros((H, W), np.float32)
    kl_sum = np.zeros((H, W), np.float32); kl_cnt = np.zeros((H, W), np.int32)
    for i in getattr(P, "child_ids", []):
        ch = agents[i]; m = np.asarray(ch.mask)
        if m.shape != (H, W): m = resize_nn(m, (H, W))
        a = child_activity_map(ch, H, W, eps=eps)
        if a is None: continue
        inside = a & (m > eps)
        cover += inside.astype(np.int32); weight += m.astype(np.float32) * inside.astype(np.float32)
        k = getattr(ch, "cached_alignment_kl", None)
        if k is None: continue
        k = np.asarray(k); 
        if k.shape != (H, W): continue
        good = inside & np.isfinite(k)
        kl_sum[good] += k[good].astype(np.float32); kl_cnt[good] += 1
    keep = (cover >= int(getattr(config, "core_min_kids", 2))) & (weight >= float(getattr(config, "core_weight_tau", 0.6)))
    kl_mean = kl_sum / np.maximum(kl_cnt, 1); kl_mean[kl_cnt == 0] = np.inf
    keep &= (kl_mean <= float(getattr(config, "core_kl_tau", getattr(config, "tau_align_emergent", 0.30))))
    # tiny erosion
    e = keep.copy()
    e = (e & np.roll(e,1,0) & np.roll(e,-1,0) & np.roll(e,1,1) & np.roll(e,-1,1))
    return e

def _compute_candidate_or_union(P, agents, H, W, dtype):
    cand = _compute_parent_candidate(P, agents)
    if cand is None:
        u = np.zeros((H, W), bool)
        for i in getattr(P, "child_ids", []): u |= (np.asarray(agents[i].mask) > 0)
        return u.astype(dtype)
    return np.asarray(cand, dtype=dtype)

def _growth_gate_from_overlap_core_activity(P, agents, H, W, eps, grow_min_kids):
    
    # overlap count
    cnt = np.zeros((H, W), np.int32)
    active_union = np.zeros((H, W), bool)
    for i in getattr(P, "child_ids", []):
        ch = agents[i]
        a = child_activity_map(ch, H, W, eps=eps)
        if a is None: continue
        active_union |= a
        cnt += (a & (np.asarray(ch.mask) > eps)).astype(np.int32)
    gate = np.ones((H, W), np.float32)
    if grow_min_kids > 0:
        gate *= np.clip(cnt.astype(np.float32) / float(grow_min_kids), 0.0, 1.0)
    # distance to core
    if getattr(P, "_core_map", None) is not None and P._core_map.any():
        dt = cheap_dt(P._core_map.astype(bool))
        r = float(getattr(config, "parent_core_decay_px", 6.0))
        gate *= np.exp(-dt / max(r, 1.0)).astype(np.float32)
    # activity
    gate *= active_union.astype(np.float32)
    return np.clip(gate, 0.0, 1.0)

def _should_reseed(P, cand):
    reseed_period = getattr(config, "parent_reseed_period", 0)
    if reseed_period <= 0: return False
    if (getattr(runtime_ctx, "global_step", 0) % reseed_period) != 0: return False
    def _iou(a, b, thr=1e-3):
        A = (a > thr); B = (b > thr); inter = (A & B).sum(); union = (A | B).sum()
        return float(inter) / max(1, int(union))
    return _iou(P.mask, cand, thr=1e-3) < float(getattr(config, "parent_reseed_iou", 0.30))

def _refresh_parent_gauge_fields(parents, agents, dtype):
    
    for P in parents:
        coarsen_phi_from_children(P, agents, field="phi",
            weight_mode=lambda ch, P=P: (ch.mask[..., None] * P.mask[..., None]).astype(dtype))
        coarsen_phi_from_children(P, agents, field="phi_model",
            weight_mode=lambda ch, P=P: (ch.mask[..., None] * P.mask[..., None]).astype(dtype))

def _median_child_kl_in_mask(P, agents, eval_mask) -> float:
    """
    Median of children KL values inside eval_mask for parent P.
    Falls back to +inf if nothing valid.
    """
    import numpy as np
    H, W = P.mask.shape
    vals = []

    for i in getattr(P, "child_ids", []):
        ch = agents[i]
        kl = getattr(ch, "cached_alignment_kl", None)
        if kl is None:
            continue
        k = np.asarray(kl).squeeze()
        # resize if needed
        if k.shape != (H, W):
            # cheap NN resize
            yi = np.clip(np.rint(np.linspace(0, k.shape[0]-1, H)).astype(int), 0, k.shape[0]-1)
            xi = np.clip(np.rint(np.linspace(0, k.shape[1]-1, W)).astype(int), 0, k.shape[1]-1)
            k = k[yi][:, xi]

        m = np.isfinite(k) & eval_mask
        if m.any():
            vals.append(k[m])

    if not vals:
        return float("inf")
    v = np.concatenate(vals)
    if v.size == 0:
        return float("inf")
    return float(np.median(v))

