# -*- coding: utf-8 -*-
"""
Created on Mon Aug 11 09:15:18 2025

@author: chris and christine
"""

import numpy as np
from numerical_utils import safe_inv, sanitize_sigma
from bundle_morphism_utils import safe_batch_apply_morphism_nat
from meta_agent_utils import gaussian_pushforward_linear
from generalized_diagnostics_metrics import kl_divergence
from gaussian_core import gaussian_pushforward_linear, kl_gaussians

def compute_avg_crossscale_kl_p(children, parents, labels, eps=1e-6):
    """
    Mean over child pixels of KL( p_child || (Λ_dn_p)_# p_parent ), masked to overlaps.
    Returns per-child array of means (NaN where no overlap or invalid parent index).
    """
    labels = np.asarray(labels)
    out = np.full((len(children),), np.nan, dtype=np.float64)

    for ci, c in enumerate(children):
        # Skip if ci has no label (likely a parent in the "children" list)
        if ci >= len(labels):
            continue

        pid = int(labels[ci]) if labels[ci] >= 0 else -1
        if pid < 0:
            continue

        p = parents[pid]
        Kp = c.mu_p_field.shape[-1]

        # Get Λ_dn_p (allow global or per-pixel)
        L = getattr(p, "Lambda_dn_p", None)
        if L is None:
            L_field = np.broadcast_to(
                np.eye(Kp, dtype=c.mu_p_field.dtype),
                c.mu_p_field.shape[:2] + (Kp, Kp)
            )
        else:
            L = np.asarray(L)
            if L.ndim == 2:  # (Kp,Kp) → broadcast
                L_field = np.broadcast_to(L, c.mu_p_field.shape[:2] + L.shape)
            else:
                L_field = L  # assume already (H,W,Kp,Kp)

        # Push parent p down to child via Λ_dn_p
        mu_t, S_t = gaussian_pushforward_linear(
            p.mu_p_field,
            sanitize_sigma(p.sigma_p_field, eps=eps),
            L_field
        )
        mu_c, S_c = c.mu_p_field, sanitize_sigma(c.sigma_p_field, eps=eps)

        # Overlap mask
        m = (c.mask > eps) & (p.mask > eps)
        if np.any(m):
            kl = kl_gaussians(mu_c, S_c, mu_t, S_t, eps=eps)  # (H,W)
            out[ci] = float(np.nanmean(kl[m]))

    return out

def compute_avg_crossscale_kl_q(children, parents, labels, eps=1e-6):
    """
    For each child → parent, compute mean KL(q_child || Λ_dn_q · q_parent)
    over their spatial overlap. Λ_dn_q can be a global (Kq,Kq) or per-pixel (H,W,Kq,Kq).
    Falls back to identity if the map is missing.
    """
    vals = []
    labels = np.asarray(labels)

    for ci, child in enumerate(children):
        # Skip any agent index beyond the label array (likely parents)
        if ci >= len(labels):
            vals.append(np.nan)
            continue

        pid = int(labels[ci]) if labels[ci] >= 0 else -1
        if pid < 0:
            vals.append(np.nan)
            continue

        parent = parents[pid]
        Kq = child.mu_q_field.shape[-1]

        # Get Λ_dn_q (allow global or per-pixel)
        L = getattr(parent, "Lambda_dn_q", None)
        if L is None:
            L_field = np.broadcast_to(
                np.eye(Kq, dtype=child.mu_q_field.dtype),
                child.mu_q_field.shape[:2] + (Kq, Kq)
            )
        else:
            L = np.asarray(L)
            if L.ndim == 2:  # (Kq,Kq) → broadcast to (H,W,Kq,Kq)
                L_field = np.broadcast_to(
                    L,
                    child.mu_q_field.shape[:2] + L.shape
                )
            else:
                L_field = L  # assume already (H,W,Kq,Kq)

        # Push parent q down to child via Λ_dn_q
        mu_push, Sigma_push = safe_batch_apply_morphism_nat(
            parent.mu_q_field, parent.sigma_q_field, L_field, eps=eps
        )

        # Overlap mask
        overlap = (child.mask > eps) & (parent.mask > eps)
        if not np.any(overlap):
            vals.append(np.nan)
            continue

        # KL over overlap
        kl_vals = kl_divergence(
            child.mu_q_field[overlap],
            child.sigma_q_field[overlap],
            mu_push[overlap],
            Sigma_push[overlap],
            eps=eps,
        )
        vals.append(float(np.nanmean(kl_vals)))

    return vals


def _seed_or_revert_procrustes(meta_agents, agents, labels, eps=1e-6, worsen_factor=2.0):
    """Seed Λ_dn_q via Procrustes, measure KL before/after, and revert if it worsens.
       Always returns a dict: {"base_mean": float|nan, "seed_mean": float|nan, "reverted": bool, "error": str|None}
    """
    def _safe_mean(x):
        try:
            x = np.asarray(x)
            if x.size == 0: return float("nan")
            m = float(np.nanmean(x))
            return m
        except Exception:
            return float("nan")

    info = {"base_mean": float("nan"), "seed_mean": float("nan"), "reverted": False, "error": None}

    # baseline
    try:
        vals_base = compute_avg_crossscale_kl_q(agents, meta_agents, labels, eps=eps)
        info["base_mean"] = _safe_mean(vals_base)
    except Exception as e:
        print(f"[XSCALE] base KL eval failed: {e}")
        info["error"] = f"base_eval: {e}"

    # seed
    try:
        procrustes_seed_lambda_dn_q(meta_agents, agents, labels)
    except Exception as e:
        print(f"[XSCALE] Procrustes seed failed: {e}")
        info["error"] = f"seed: {e}"

    # after
    try:
        vals_seed = compute_avg_crossscale_kl_q(agents, meta_agents, labels, eps=eps)
        info["seed_mean"] = _safe_mean(vals_seed)
    except Exception as e:
        print(f"[XSCALE] post-seed KL eval failed: {e}")
        info["error"] = f"post_eval: {e}"

    print(f"[XSCALE] KL base {info['base_mean']:.4f} → after seed {info['seed_mean']:.4f}")

    # revert if worse by factor or NaN
    try:
        worse = (not np.isfinite(info["seed_mean"])) or (
            np.isfinite(info["base_mean"]) and info["seed_mean"] > worsen_factor * info["base_mean"]
        )
        if worse:
            Kq = meta_agents[0].mu_q_field.shape[-1]
            for P in meta_agents:
                P.Lambda_dn_q = np.eye(Kq, dtype=P.mu_q_field.dtype)
                P.Lambda_up_q = np.eye(Kq, dtype=P.mu_q_field.dtype)
            print("[XSCALE] Procrustes seed increased KL — reverted to identity.")
            info["reverted"] = True
    except Exception as e:
        print(f"[XSCALE] revert failed: {e}")
        info["error"] = (info["error"] + f"; revert: {e}") if info["error"] else f"revert: {e}"

    return info



def procrustes_seed_lambda_dn_q(parents, children, labels, eps=1e-6, center=True, min_samples=5):
    import numpy as np
    labels = np.asarray(labels)
    parent_to_kids = {}
    for ci, pid in enumerate(labels):
        if pid >= 0:
            parent_to_kids.setdefault(int(pid), []).append(ci)

    for pid, kid_ids in parent_to_kids.items():
        P = parents[pid]
        H, W, K = P.mu_q_field.shape
        if not kid_ids:
            L = np.eye(K, dtype=P.mu_q_field.dtype)
        else:
            Xs, Ys = [], []  # child, parent
            Y_flat = P.mu_q_field.reshape(-1, K)
            M_par  = (P.mask > eps).reshape(-1)
            for ci in kid_ids:
                C = children[ci]
                X_flat = C.mu_q_field.reshape(-1, K)
                M = (C.mask > eps).reshape(-1) & M_par
                if np.any(M):
                    Xs.append(X_flat[M]); Ys.append(Y_flat[M])
            if not Xs or sum(x.shape[0] for x in Xs) < max(min_samples, K):
                L = np.eye(K, dtype=P.mu_q_field.dtype)
            else:
                X = np.vstack(Xs); Y = np.vstack(Ys)
                if center:
                    X -= X.mean(axis=0, keepdims=True)
                    Y -= Y.mean(axis=0, keepdims=True)
                M = X.T @ Y                      # (K×K)
                U, _, Vt = np.linalg.svd(M, full_matrices=False)
                L = U @ Vt                        # orthogonal
                if np.linalg.det(L) < 0:          # reflection fix → proper rotation
                    U[:, -1] *= -1
                    L = U @ Vt
        P.Lambda_dn_q = L
        P.Lambda_up_q = L.T

