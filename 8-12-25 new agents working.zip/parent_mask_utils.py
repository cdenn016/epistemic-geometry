# -*- coding: utf-8 -*-
"""
Created on Tue Aug 12 10:17:46 2025

@author: chris and christine
"""

# parent_mask_utils.py
import numpy as np






def _shift_pad(x: np.ndarray, di: int, dj: int) -> np.ndarray:
    """Return x shifted by (di,dj) with zero/False padding, preserving shape."""
    x = np.asarray(x, dtype=bool)
    H, W = x.shape
    xp = np.pad(x, ((1, 1), (1, 1)), mode="constant", constant_values=False)
    # slice so result is HxW no matter the shift
    return xp[1 + di : 1 + di + H, 1 + dj : 1 + dj + W]

# --- put these helpers near the top (shared utils) ---
def _iou_binary(a: np.ndarray, b: np.ndarray, thr: float = 1e-2) -> float:
    A = (np.asarray(a) > thr)
    B = (np.asarray(b) > thr)
    inter = (A & B).sum()
    union = (A | B).sum()
    return float(inter) / max(1, int(union))


# ----- geometry / morphology -----
def resize_nn(a: np.ndarray, shape: tuple[int, int]) -> np.ndarray:
    H, W = shape; h, w = a.shape[:2]
    if (h, w) == (H, W): return a
    yi = np.clip(np.rint(np.linspace(0, h - 1, H)).astype(int), 0, h - 1)
    xi = np.clip(np.rint(np.linspace(0, w - 1, W)).astype(int), 0, w - 1)
    return a[yi][:, xi]

def binary_dilate_3x3(x: np.ndarray) -> np.ndarray:
    x = np.asarray(x, bool); H, W = x.shape
    y = np.zeros((H, W), bool)
    for di in (-1, 0, 1):
        for dj in (-1, 0, 1):
            y |= np.pad(x, 1)[1+di:1+di+H, 1+dj:1+dj+W]
    return y

def binary_erode_3x3(x: np.ndarray) -> np.ndarray:
    x = np.asarray(x, bool); H, W = x.shape
    y = np.ones((H, W), bool)
    for di in (-1, 0, 1):
        for dj in (-1, 0, 1):
            y &= np.pad(x, 1)[1+di:1+di+H, 1+dj:1+dj+W]
    return y

def gauss3(arr: np.ndarray) -> np.ndarray:
    k = np.array([[1,2,1],[2,4,2],[1,2,1]], np.float32); k /= k.sum()
    if arr.ndim == 2:
        p = np.pad(arr, ((1,1),(1,1)), mode="edge")
        out = (k[0,0]*p[:-2,:-2] + k[0,1]*p[:-2,1:-1] + k[0,2]*p[:-2,2:] +
               k[1,0]*p[1:-1,:-2] + k[1,1]*p[1:-1,1:-1] + k[1,2]*p[1:-1,2:] +
               k[2,0]*p[2:,:-2] + k[2,1]*p[2:,1:-1] + k[2,2]*p[2:,2:])
        return out.astype(np.float32)
    out = np.empty_like(arr, np.float32)
    for c in range(arr.shape[-1]): out[..., c] = gauss3(arr[..., c])
    return out

# ----- activity / overlap / distance -----
def child_activity_map(ch, H, W, mu_tau=1e-3, trsig_tau=1e-3, eps=1e-6):
    m = getattr(ch, "mask", None)
    if m is None: return None
    from parent_mask_utils import resize_nn as _r
    m = np.asarray(m); 
    if m.shape[:2] != (H, W): m = _r(m, (H, W))
    m_ok = (m > eps)

    mu = getattr(ch, "mu_q_field", None)
    Sig = getattr(ch, "sigma_q_field", None)
    if mu is None or Sig is None: return m_ok

    mu = np.asarray(mu); Sig = np.asarray(Sig)
    if mu.shape[:2] != (H, W): mu = _r(mu, (H, W))
    if Sig.shape[:2] != (H, W): Sig = _r(Sig, (H, W))
    mu_mag = np.sqrt((mu**2).sum(-1)) if mu.ndim == 3 else np.abs(mu).astype(np.float32)
    trsig  = np.trace(Sig, axis1=-2, axis2=-1) if Sig.ndim == 4 else Sig.astype(np.float32)
    return m_ok & ((mu_mag > mu_tau) | (trsig > trsig_tau))

def overlap_count(children, H, W, eps, child_ids):
    cnt = np.zeros((H, W), np.int32)
    for i in child_ids:
        ch = children[i]
        a = child_activity_map(ch, H, W, eps=eps)
        if a is None: continue
        m = getattr(ch, "mask", None)
        if m is None: continue
        from parent_mask_utils import resize_nn as _r
        m = _r(np.asarray(m).squeeze(), (H, W))
        cnt += (a & (m > eps)).astype(np.int32)
    return cnt

def cheap_dt(core_bool: np.ndarray, cap_steps: int = 32) -> np.ndarray:
    H, W = core_bool.shape
    dt = np.full((H, W), np.inf, np.float32)
    front = core_bool.astype(bool); d = 0.0
    while front.any() and d < cap_steps:
        dt[front] = np.minimum(dt[front], d)
        new = (front | np.roll(front,1,0) | np.roll(front,-1,0) |
                      np.roll(front,1,1) | np.roll(front,-1,1))
        front = new & (~np.isfinite(dt)); d += 1.0
    return dt
