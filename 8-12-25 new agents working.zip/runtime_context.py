# -*- coding: utf-8 -*-
"""
Created on Mon Aug 11 16:56:12 2025

@author: chris and christine
"""
# runtime_context.py
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any, Dict, Optional

@dataclass
class RuntimeCtx:
    """
    Lightweight run-scoped context for emergent parents and detectors.
    Keeps zero heavy imports to avoid cycles.
    """
    parents_by_region: Dict[int, Any] = field(default_factory=dict)  # pid -> parent Agent
    next_parent_id: int = 1
    global_step: int = 0
    detector_state: Optional[Any] = None  # set by detector module at runtime

def ensure_runtime_defaults(ctx: Optional[RuntimeCtx]) -> RuntimeCtx:
    if ctx is None:
        ctx = RuntimeCtx()
    if ctx.parents_by_region is None:
        ctx.parents_by_region = {}
    if ctx.next_parent_id is None:
        ctx.next_parent_id = 1
    if ctx.global_step is None:
        ctx.global_step = 0
    # detector_state is allowed to be None; detector will init it when needed
    return ctx

# module-level singleton (optional convenience)
runtime_ctx = RuntimeCtx()

__all__ = ["RuntimeCtx", "runtime_ctx", "ensure_runtime_defaults"]
