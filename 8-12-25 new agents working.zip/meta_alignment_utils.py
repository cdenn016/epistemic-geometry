# -*- coding: utf-8 -*-
"""
Created on Mon Aug 11 09:24:42 2025

@author: chris and christine
"""
# ────────────────────────
# Standard library
# ────────────────────────
import math
from pathlib import Path
#────────────────────────
# Third-party
# ────────────────────────
import numpy as np
# ────────────────────────
# Project
# ────────────────────────
import config
from generalized_io_utils import (
    
    load_meta_data,
)

from omega import compute_field_strength
from meta_agent_plots import (
    
    plot_intra_kl_distribution,
    plot_inter_vs_intra,
    plot_cluster_order_parameters,
    plot_spatial_cluster_map,
    plot_curvature_heatmap,
)
from meta_agent_utils import (
    _labels_from_overlap_connected_components,
    compute_cluster_kl_stats,
)





def get_intra_inter(stats, kl_matrix, labels):
    """
    Returns two 1D arrays: intra_vals, inter_vals.
    Tries to read from `stats`; if unavailable, computes from kl_matrix + labels.
    """
    import numpy as np

    # Try to read from stats using a few common key names
    if stats and len(stats) > 0:
        intra_all, inter_all = [], []
        for cid, entry in stats.items():
            # allow several possible key names
            k_intra = _first_present_key(entry, ["intra", "intra_kl", "intra_vals", "intra_values"])
            k_inter = _first_present_key(entry, ["inter", "inter_kl", "inter_vals", "inter_values"])
            if k_intra is not None:
                intra_all.append(np.asarray(entry[k_intra]).ravel())
            if k_inter is not None:
                inter_all.append(np.asarray(entry[k_inter]).ravel())
        if intra_all and inter_all:
            return np.concatenate(intra_all), np.concatenate(inter_all)
        # fall through to matrix-based if one is missing

    # Fallback: compute from matrix + labels
    labels = np.asarray(labels)
    uniq = np.unique(labels[labels >= 0])
    intra_vals, inter_vals = [], []
    for a in uniq:
        idx_a = np.where(labels == a)[0]
        if idx_a.size >= 2:
            # intra-cluster (exclude diagonal)
            block = kl_matrix[np.ix_(idx_a, idx_a)].astype(float)
            mask = ~np.eye(block.shape[0], dtype=bool)
            intra_vals.append(block[mask])
        # inter-cluster
        for b in uniq:
            if b <= a:
                continue
            idx_b = np.where(labels == b)[0]
            if idx_b.size == 0 or idx_a.size == 0:
                continue
            block_ab = kl_matrix[np.ix_(idx_a, idx_b)].astype(float)
            inter_vals.append(block_ab.ravel())

    intra = np.concatenate(intra_vals) if intra_vals else np.array([])
    inter = np.concatenate(inter_vals) if inter_vals else np.array([])
    return intra, inter



def condensation_score(stats, R_global, sigma_global, kl_matrix=None, labels=None):
    """
    Larger is better. Combines inter/intra separation and global order sharpness.
    Robust to missing 'intra'/'inter' keys in `stats`.
    """
    import numpy as np
    intra, inter = get_intra_inter(stats, kl_matrix, labels)

    # Handle edge cases gracefully
    if intra.size == 0 and inter.size == 0:
        return -1.0
    if intra.size == 0:  # no within-cluster pairs (e.g., all singletons)
        sep = 1.0
    elif inter.size == 0:  # only one cluster → no inter-cluster pairs
        sep = 1.0
    else:
        sep = (np.nanmean(inter) + 1e-9) / (np.nanmean(intra) + 1e-9)

    order = R_global / (sigma_global + 1e-9) if sigma_global is not None else 0.0
    return 0.7 * sep + 0.3 * order


    
def _choose_best_clustering(agents, Gq, Gp, basedir: Path,
                            force_if_empty=False,
                            force_if_score_below=None,      # e.g., 0.2 to force when weak
                            overlap_eps=1e-6,
                            min_group_size=2):
    
    specs = {
        "kl":       (basedir / "belief_alignment_output", Gq),
        "kl_model": (basedir / "model_alignment_output",  Gp),
    }
    best = {"prefix": None, "score": -math.inf, "labels": None, "kl_matrix": None}
    for prefix, (adir, curv_G) in specs.items():
        print(f"\n[INFO] Evaluating '{prefix}' clusters @ {adir}")
        res = _evaluate_prefix(agents, adir, prefix, curv_G, outdir_root=basedir / "condensation_output")
        if not res:
            continue
        s = res.get("score", -math.inf)
        if not np.isfinite(s):
            s = -math.inf
        if s > best["score"]:
            best = {**res, "score": float(s)}

    need_force = (
        best["prefix"] is None or
        (force_if_score_below is not None and (not np.isfinite(best["score"]) or best["score"] < force_if_score_below))
    )

    if need_force and force_if_empty:
        print("\n[WARN] No acceptable clustering; forcing meta-agent labels from overlap connectivity.")
        labels_forced = _labels_from_overlap_connected_components(agents, eps=overlap_eps,
                                                                  min_group_size=min_group_size)
        best = {
            "prefix": "forced_overlap",
            "score": 0.0,                 # neutral baseline
            "labels": labels_forced,
            "kl_matrix": None             # downstream code should tolerate None
        }

    if best["prefix"] is None:
        # final safety: one cluster with all agents
        print("\n[WARN] Forcing single-cluster fallback (all agents in one group).")
        labels = np.zeros(len(agents), dtype=int)
        best = {"prefix": "forced_all", "score": 0.0, "labels": labels, "kl_matrix": None}

    print(f"\n[INFO] Selected clustering: {best['prefix']} (score={best['score']:.4f})")
    return best


def _evaluate_prefix(agents, align_dir, prefix, curvature_generators, outdir_root):
    kl_matrix, labels, rankings = load_meta_data(str(align_dir), prefix)
    if len(labels) != len(agents):
        print(f"[ERROR] Label count {len(labels)} != agent count {len(agents)}")
        return None

    print(f"[INFO] Cluster label histogram: {np.bincount(labels[labels >= 0])}")
    stats = compute_cluster_kl_stats(kl_matrix, labels)
    if not stats:
        print(f"[!] No clusters detected for {prefix}; skipping.")
        return None

    # --- robust extraction of intra/inter from whatever shape keys you return ---
    def _extract_intra_inter(s):
        # dict with various possible key names
        if isinstance(s, dict):
            intra = None
            inter = None
            for k in ("intra", "intra_kl", "intra_vals", "intra_values"):
                if k in s: 
                    intra = np.asarray(s[k]); break
            for k in ("inter", "inter_kl", "inter_vals", "inter_values"):
                if k in s:
                    inter = np.asarray(s[k]); break
            return (intra if intra is not None else np.array([])), (inter if inter is not None else np.array([]))
        # tuple/list (intra, inter)
        if isinstance(s, (list, tuple)) and len(s) >= 2:
            return np.asarray(s[0]), np.asarray(s[1])
        # unknown shape → treat as intra-only
        return np.asarray(s), np.array([])

    stat_items = list(stats.values()) if hasattr(stats, "values") else list(stats)
    intra_all = []
    inter_all = []
    for s in stat_items:
        intra, inter = _extract_intra_inter(s)
        if intra.size:
            intra_all.append(intra[np.isfinite(intra)])
        if inter.size:
            inter_all.append(inter[np.isfinite(inter)])
    n_intra = int(sum(arr.size for arr in intra_all))
    n_inter = int(sum(arr.size for arr in inter_all))
    print(f"[DIAG] finite intra pairs: {n_intra} | finite inter pairs: {n_inter}")

    R_global, sigma_global = compute_order_parameter(kl_matrix)

    outdir = outdir_root / prefix
    outdir.mkdir(parents=True, exist_ok=True)
    plot_intra_kl_distribution(stats, outpath=outdir / "intra_kl.png")
    plot_inter_vs_intra(stats, outpath=outdir / "inter_vs_intra.png")
    cluster_R = compute_cluster_order_parameters(kl_matrix, labels)
    plot_cluster_order_parameters(cluster_R, outpath=outdir / "cluster_order_params.png")
    plot_spatial_cluster_map(agents, labels, outpath=outdir / "spatial_clusters.png")
    plot_curvature_heatmap(agents, labels, curvature_generators, outpath=outdir / "curvature_heatmap.png")

    # Try the canonical score first; if it fails/NaNs, use proxy = -mean(intra)
    try:
        score = condensation_score(stats, R_global, sigma_global, kl_matrix=kl_matrix, labels=labels)
    except Exception as e:
        print(f"[INFO] condensation_score failed: {e} → using proxy.")
        score = np.nan

    if not np.isfinite(score):
        proxy = -np.inf
        if n_intra > 0:
            try:
                proxy = -float(np.nanmean(np.concatenate(intra_all)))  # lower intra is better
            except Exception:
                proxy = -np.inf
        print(f"[INFO] {prefix} condensation score = NaN → proxy score {proxy:.4f}")
        score = proxy
    else:
        print(f"[INFO] {prefix} condensation score = {score:.4f}")

    return {"prefix": prefix, "score": float(score), "labels": labels, "kl_matrix": kl_matrix}





def curvature_mean_per_agent(agents, generators) -> np.ndarray:
    """
    Compute ⟨Tr(F_{μν} F^{μν})⟩ for each agent using field strength from generalized_omega.
    Only includes values inside the agent's support.
    """
    eps = getattr(config, "support_cutoff_eps", 1e-3)
    means = []

    for i, ag in enumerate(agents):
        try:
            mask = ag.mask > eps
            F_dict = compute_field_strength(ag.phi, generators)
            H, W = ag.phi.shape[:2]

            total_energy = 0.0
            count = np.sum(mask)

            for F_name, F in F_dict.items():
                if F.ndim != 4 or F.shape[-2:] != (generators.shape[1], generators.shape[2]):
                    print(f"[!] Skipping invalid F[{F_name}] shape: {F.shape}")
                    continue

                # Compute Tr(F²) per point: sum_ij F_ij²
                pointwise_energy = np.einsum("...ij,...ij->...", F, F)  # (H, W)
                total_energy += np.sum(pointwise_energy[mask])

            mean_energy = total_energy / count if count > 0 else 0.0
            means.append(mean_energy)

        except Exception as e:
            print(f"[!] Failed to compute curvature for agent {i}: {e}")
            means.append(0.0)

    return np.array(means)





def compute_phi_variance_per_cluster(agents, labels):
    """
    Compute φ-norm variance for each cluster of agents.

    Returns:
        stats: dict {cluster_id: {'phi_means': [...], 'phi_var': float}}
    """
    eps = getattr(config, "support_cutoff_eps", 1e-3)
    stats = {}

    for lab in np.unique(labels):
        if lab < 0:
            continue  # Ignore noise/outlier label

        idx = np.where(labels == lab)[0]
        means = []

        for i in idx:
            agent = agents[i]
            if agent.phi is None:
                continue
            mask = agent.mask > eps
            phi_norm = np.linalg.norm(agent.phi, axis=-1)
            if np.any(mask):
                mean_val = np.mean(phi_norm[mask])
                means.append(float(mean_val))

        if means:
            stats[int(lab)] = {
                'phi_means': means,
                'phi_var': float(np.var(means))
            }

    return stats







def rank_agent_alignment(kl_matrix):
    """
    For each agent i, rank all other agents by ascending KL divergence.
    Returns dict[i] = {"best": j, "worst": k, "full_rank": [j1, j2, ...]}
    """
    N = kl_matrix.shape[0]
    rankings = {}
    for i in range(N):
        dists = kl_matrix[i].copy()
        dists[i] = np.inf  # ignore self
        sorted_idx = np.argsort(dists)
        rankings[i] = {
            "best": int(sorted_idx[0]),
            "worst": int(sorted_idx[-1]),
            "full_rank": sorted_idx.tolist()
        }
    return rankings

def compute_symmetric_kl_matrix(kl_matrix: np.ndarray) -> np.ndarray:
    """
    Compute the symmetrized KL matrix:
        D_sym(i, j) = 0.5 * [ D_KL(q_i || Ω q_j) + D_KL(q_j || Ω⁻¹ q_i) ]
    Args:
        kl_matrix: (N, N) asymmetric KL divergence matrix
    Returns:
        symmetric KL matrix (N, N)
    """
    assert kl_matrix.shape[0] == kl_matrix.shape[1], "KL matrix must be square"
    return 0.5 * (kl_matrix + kl_matrix.T)

def compute_order_parameter(kl_matrix):
    """
    Compute global condensation order parameter R, based on median KL.
    """
    i, j = np.triu_indices(kl_matrix.shape[0], k=1)
    d = kl_matrix[i, j]
    d = d[np.isfinite(d)]
    sigma = float(np.median(d)) if d.size else 1.0
    R = float(np.sum(np.exp(-d / sigma)) / d.size) if d.size else 0.0
    return R, sigma

def compute_cluster_order_parameters(kl_matrix, labels):
    """
    For each cluster: compute (R_C, sigma_C) based on pairwise KLs.
    Returns dict[cluster_id] = (R, sigma)
    """
    clusters = {}
    for lab in sorted(set(labels)):
        if lab < 0:
            continue
        idx = np.where(labels == lab)[0]
        if len(idx) < 2:
            clusters[lab] = (1.0, 0.0)
            continue

        sub = kl_matrix[np.ix_(idx, idx)]
        i, j = np.triu_indices(len(idx), k=1)
        vals = sub[i, j][np.isfinite(sub[i, j])]

        sigma = float(np.median(vals)) if vals.size else 1.0
        R = float(np.mean(np.exp(-vals / sigma))) if sigma > 0 else 1.0
        clusters[lab] = (R, sigma)
    return clusters


def _first_present_key(d, candidates):
    for k in candidates:
        if k in d:
            return k
    return None













