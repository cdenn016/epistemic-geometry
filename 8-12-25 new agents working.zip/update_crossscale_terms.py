

from __future__ import annotations
import numpy as np
import config

# exp/log on the group and their differentials
from omega import d_exp_phi_exact, exp_lie_algebra_irrep

# SPD helpers
from numerical_utils import sanitize_sigma, safe_inv

"""
Cross-scale (child ↔ parent) energy and gradients, gauge-covariant.

- Belief side (q):   Λ = exp(φ_child) · exp(-φ_parent) = E_c · E_p^T
- Model  side (p):  Λ̃ = exp(φ̃_child) · exp(-φ̃_parent) = Ê_c · Ê_p^T

Child gradients are always accumulated.
Parent gradients are accumulated only if child_only=False.

Config knobs (expected in `config.py` or params):
  lambda_xscale_q: float   # strength on belief side
  lambda_xscale_p: float   # strength on model side
  eps: float               # numerical floor for masks / inverses
"""


def _sym(A):
    return 0.5 * (A + np.swapaxes(A, -1, -2))


def _masked_bools(child, parent, eps):
    H, W = child.mu_q_field.shape[-3], child.mu_q_field.shape[-2]
    m = ((np.asarray(child.mask) > eps) & (np.asarray(parent.mask) > eps))
    m = np.broadcast_to(np.asarray(m, dtype=bool), (H, W))
    m1 = m[..., None].astype(child.mu_q_field.dtype)
    m4 = m[..., None, None].astype(child.mu_q_field.dtype)
    return m, m1, m4


def accumulate_xscale_q_dn_gaugecov(
    child, parent, generators_q, lam_q: float, eps: float = 1e-6,
    use_cached_exp: bool = True, child_only: bool = True,
) -> float:
    """
    Cross-scale belief KL with gauge-covariant Λ. Returns masked-mean KL (float).
    """
    if lam_q <= 0.0:
        return 0.0

    # --- exp(φ) caches (child & parent) ---
    if use_cached_exp and getattr(child, "_exp_phi", None) is not None:
        E_c = child._exp_phi
    else:
        E_c = exp_lie_algebra_irrep(child.phi, generators_q)
        child._exp_phi = E_c

    if use_cached_exp and getattr(parent, "_exp_phi", None) is not None:
        E_p = parent._exp_phi
    else:
        E_p = exp_lie_algebra_irrep(parent.phi, generators_q)
        parent._exp_phi = E_p

    E_p_T = np.swapaxes(E_p, -1, -2)
    Lambda = np.einsum("...ik,...kj->...ij", E_c, E_p_T)  # (...,Kq,Kq)

    # --- fields ---
    muP = parent.mu_q_field
    SP  = sanitize_sigma(parent.sigma_q_field, eps=eps)
    mu  = child.mu_q_field
    S   = sanitize_sigma(child.sigma_q_field, eps=eps)

    # --- push down parent to child frame ---
    mu_t = np.einsum("...ij,...j->...i", Lambda, muP)
    S_t  = np.einsum("...ik,...kl,...jl->...ij", Lambda, SP, Lambda)
    S_t  = sanitize_sigma(_sym(S_t), eps=eps)

    S_t_inv = safe_inv(S_t, eps=eps)
    S_inv   = safe_inv(S,   eps=eps)

    # --- masks ---
    m, m1, m4 = _masked_bools(child, parent, eps)

    # --- child μ, Σ grads ---
    g_mu_child = (S_t_inv @ (mu - mu_t)[..., None])[..., 0]
    g_S_child  = _sym(0.5 * (S_t_inv - S_inv))

    if getattr(child, "grad_mu_q", None) is None:
        child.grad_mu_q = np.zeros_like(mu)
    if getattr(child, "grad_sigma_q", None) is None:
        child.grad_sigma_q = np.zeros_like(S)

    child.grad_mu_q    += lam_q * g_mu_child * m1
    child.grad_sigma_q += lam_q * g_S_child  * m4

    # --- shared helpers for Λ backprop ---
    dmu    = (mu - mu_t)
    dmu_t  = - (S_t_inv @ dmu[..., None])[..., 0]      # ∂KL/∂μ_t
    outer  = dmu[..., None] @ np.swapaxes(dmu[..., None], -1, -2)
    dKL_dA = 0.5 * (S + outer - S_t)
    dS_t   = _sym(- np.einsum("...ik,...kl,...lj->...ij", S_t_inv, dKL_dA, S_t_inv))

    # --- φ grads: child always; parent only if enabled ---
    term_mean = dmu_t[..., None] @ muP[..., None, :]
    term_cov  = 2.0 * np.einsum("...ij,...jk,...kl->...il", dS_t, Lambda, SP)
    GΛ = (term_mean + term_cov) * m4  # (...,K,K)

    T_child   = np.einsum("...ij,...jk->...ik", GΛ, E_p)
    D_child   = d_exp_phi_exact(child.phi, generators_q, exp_phi_all=E_c)  # list of 3 (...,K,K)
    g_phi_ch  = np.stack([np.einsum("...ij,...ij->...", T_child, D_child[a])
                          for a in range(3)], axis=-1) * m1  # (...,3)

    if getattr(child, "grad_phi", None) is None:
        child.grad_phi = np.zeros_like(child.phi)
    child.grad_phi += lam_q * g_phi_ch

    if not child_only:
        T_parent  = - np.einsum("...ij,...jk,...kl->...il", np.swapaxes(Lambda, -1, -2), GΛ, E_p)
        D_parent  = d_exp_phi_exact(parent.phi, generators_q, exp_phi_all=E_p)
        g_phi_pa  = np.stack([np.einsum("...ij,...ij->...", T_parent, D_parent[a])
                              for a in range(3)], axis=-1) * m1
        if getattr(parent, "grad_phi", None) is None:
            parent.grad_phi = np.zeros_like(parent.phi)
        parent.grad_phi += lam_q * g_phi_pa

        # parent μ, Σ grads
        g_muP = (np.swapaxes(Lambda, -1, -2) @ dmu_t[..., None])[..., 0]
        g_SP  = _sym(np.einsum("...ik,...kl,...jl->...ij",
                               np.swapaxes(Lambda, -1, -2), dS_t, Lambda))
        if getattr(parent, "grad_mu_q", None) is None:
            parent.grad_mu_q = np.zeros_like(muP)
        if getattr(parent, "grad_sigma_q", None) is None:
            parent.grad_sigma_q = np.zeros_like(SP)
        parent.grad_mu_q    += lam_q * g_muP * m1
        parent.grad_sigma_q += lam_q * g_SP  * m4

    # --- scalar KL (masked mean) ---
    diff = (mu_t - mu)[..., None]
    quad = (np.swapaxes(diff, -1, -2) @ S_t_inv @ diff)[..., 0, 0]
    tr_term = np.einsum("...ij,...ji->...", S_t_inv, S)
    sign_t, logdet_t = np.linalg.slogdet(S_t)
    sign_c, logdet_c = np.linalg.slogdet(S)
    logdet_t = np.where(sign_t > 0, logdet_t, np.nan)
    logdet_c = np.where(sign_c > 0, logdet_c, np.nan)
    kl_point = 0.5 * (tr_term + quad - S.shape[-1] + (logdet_t - logdet_c))

    valid = np.isfinite(kl_point) & m
    return float(np.nanmean(kl_point[valid])) if np.any(valid) else 0.0


def accumulate_xscale_p_dn_gaugecov(
    child, parent, generators_p, lam_p: float, eps: float = 1e-6,
    use_cached_exp: bool = True, child_only: bool = True,
) -> float:
    """
    Cross-scale model KL with gauge-covariant Λ̃. Returns masked-mean KL (float).
    """
    if lam_p <= 0.0:
        return 0.0

    # --- exp(φ̃) caches (child & parent) ---
    if use_cached_exp and getattr(child, "_exp_phi_model", None) is not None:
        Ec = child._exp_phi_model
    else:
        Ec = exp_lie_algebra_irrep(child.phi_model, generators_p)
        child._exp_phi_model = Ec

    if use_cached_exp and getattr(parent, "_exp_phi_model", None) is not None:
        Ep = parent._exp_phi_model
    else:
        Ep = exp_lie_algebra_irrep(parent.phi_model, generators_p)
        parent._exp_phi_model = Ep

    Ep_T  = np.swapaxes(Ep, -1, -2)
    Lambda = np.einsum("...ik,...kj->...ij", Ec, Ep_T)  # (...,Kp,Kp)

    # --- fields (model side) ---
    muP = parent.mu_p_field
    SP  = sanitize_sigma(parent.sigma_p_field, eps=eps)
    mu  = child.mu_p_field
    S   = sanitize_sigma(child.sigma_p_field, eps=eps)

    # --- push down parent to child frame ---
    mu_t = np.einsum("...ij,...j->...i", Lambda, muP)
    S_t  = np.einsum("...ik,...kl,...jl->...ij", Lambda, SP, Lambda)
    S_t  = sanitize_sigma(_sym(S_t), eps=eps)

    S_t_inv = safe_inv(S_t, eps=eps)
    S_inv   = safe_inv(S,   eps=eps)

    # --- masks ---
    m, m1, m4 = _masked_bools(child, parent, eps)

    # --- child μ, Σ grads (model side) ---
    g_mu_child = (S_t_inv @ (mu - mu_t)[..., None])[..., 0]
    g_S_child  = _sym(0.5 * (S_t_inv - S_inv))

    if getattr(child, "grad_mu_p", None) is None:
        child.grad_mu_p = np.zeros_like(mu)
    if getattr(child, "grad_sigma_p", None) is None:
        child.grad_sigma_p = np.zeros_like(S)

    child.grad_mu_p    += lam_p * g_mu_child * m1
    child.grad_sigma_p += lam_p * g_S_child  * m4

    # --- φ̃ grads (model gauge): child always; parent only if enabled ---
    dmu    = (mu - mu_t)
    dmu_t  = - (S_t_inv @ dmu[..., None])[..., 0]
    outer  = dmu[..., None] @ np.swapaxes(dmu[..., None], -1, -2)
    dKL_dA = 0.5 * (S + outer - S_t)
    dS_t   = _sym(- np.einsum("...ik,...kl,...lj->...ij", S_t_inv, dKL_dA, S_t_inv))

    term_mean = dmu_t[..., None] @ muP[..., None, :]
    term_cov  = 2.0 * np.einsum("...ij,...jk,...kl->...il", dS_t, Lambda, SP)
    GΛ = (term_mean + term_cov) * m4

    T_child    = np.einsum("...ij,...jk->...ik", GΛ, Ep)
    D_child    = d_exp_phi_exact(child.phi_model, generators_p, exp_phi_all=Ec)
    g_phi_m_ch = np.stack([np.einsum("...ij,...ij->...", T_child, D_child[a])
                           for a in range(3)], axis=-1) * m1

    if getattr(child, "grad_phi_tilde", None) is None:
        child.grad_phi_tilde = np.zeros_like(child.phi_model)
    child.grad_phi_tilde += lam_p * g_phi_m_ch

    if not child_only:
        T_parent   = - np.einsum("...ij,...jk,...kl->...il",
                                 np.swapaxes(Lambda, -1, -2), GΛ, Ep)
        D_parent   = d_exp_phi_exact(parent.phi_model, generators_p, exp_phi_all=Ep)
        g_phi_m_pa = np.stack([np.einsum("...ij,...ij->...", T_parent, D_parent[a])
                               for a in range(3)], axis=-1) * m1
        if getattr(parent, "grad_phi_tilde", None) is None:
            parent.grad_phi_tilde = np.zeros_like(parent.phi_model)
        parent.grad_phi_tilde += lam_p * g_phi_m_pa

        g_muP = (np.swapaxes(Lambda, -1, -2) @ dmu_t[..., None])[..., 0]
        g_SP  = _sym(np.einsum("...ik,...kl,...jl->...ij",
                               np.swapaxes(Lambda, -1, -2), dS_t, Lambda))
        if getattr(parent, "grad_mu_p", None) is None:
            parent.grad_mu_p = np.zeros_like(muP)
        if getattr(parent, "grad_sigma_p", None) is None:
            parent.grad_sigma_p = np.zeros_like(SP)
        parent.grad_mu_p    += lam_p * g_muP * m1
        parent.grad_sigma_p += lam_p * g_SP  * m4

    # --- scalar KL (masked mean) ---
    diff = (mu_t - mu)[..., None]
    quad = (np.swapaxes(diff, -1, -2) @ S_t_inv @ diff)[..., 0, 0]
    tr_term = np.einsum("...ij,...ji->...", S_t_inv, S)
    sign_t, logdet_t = np.linalg.slogdet(S_t)
    sign_c, logdet_c = np.linalg.slogdet(S)
    logdet_t = np.where(sign_t > 0, logdet_t, np.nan)
    logdet_c = np.where(sign_c > 0, logdet_c, np.nan)
    kl_point = 0.5 * (tr_term + quad - S.shape[-1] + (logdet_t - logdet_c))

    valid = np.isfinite(kl_point) & m
    return float(np.nanmean(kl_point[valid])) if np.any(valid) else 0.0


def accumulate_crossscale_gradients(agent_i, all_agents, generators_q, generators_p, params):
    lam_x_q = params.get("lambda_xscale_q", getattr(config, "lambda_xscale_q", 0.0))
    lam_x_p = params.get("lambda_xscale_p", getattr(config, "lambda_xscale_p", 0.0))
    eps     = getattr(config, "eps", 1e-6)
    child_only = params.get("xscale_child_only", True)

    id2A = {A.id: A for A in all_agents}
    kl_out = {"kl_q": [], "kl_p": []}

    pids = getattr(agent_i, "parent_ids", []) or []
    if not pids:
        return kl_out

    for pid in pids:
        parent = id2A.get(pid, None)
        if parent is None:
            continue

        # quick spatial overlap check
        if not np.any((agent_i.mask > 0) & (getattr(parent, "mask", 0) > 0)):
            continue

        # per-parent ramped weights
        eff_lam_q = float(getattr(parent, "lambda_q_weight", lam_x_q))
        eff_lam_p = float(getattr(parent, "lambda_p_weight", lam_x_p))

        if eff_lam_q > 0.0 and agent_i.mu_q_field.shape[-1] == parent.mu_q_field.shape[-1]:
            kl_q = accumulate_xscale_q_dn_gaugecov(
                child=agent_i, parent=parent, generators_q=generators_q,
                lam_q=eff_lam_q, eps=eps, child_only=child_only
            )
            kl_out["kl_q"].append(kl_q)

        if eff_lam_p > 0.0 and agent_i.mu_p_field.shape[-1] == parent.mu_p_field.shape[-1]:
            kl_p = accumulate_xscale_p_dn_gaugecov(
                child=agent_i, parent=parent, generators_p=generators_p,
                lam_p=eff_lam_p, eps=eps, child_only=child_only
            )
            kl_out["kl_p"].append(kl_p)

    return kl_out


