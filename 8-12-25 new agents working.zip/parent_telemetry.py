# -*- coding: utf-8 -*-
"""
Created on Mon Aug 11 17:13:40 2025

@author: chris and christine
"""

# parent_telemetry.py
import numpy as np

def _l2(x): 
    return float(np.sqrt(np.mean(x.astype(np.float64)**2)))

def _area(mask, thr=0.3):
    return int((np.asarray(mask) > thr).sum())

def capture_parent_snapshot(P):
    return dict(
        mu_q_l2 = _l2(P.mu_q_field),
        mu_p_l2 = _l2(getattr(P, "mu_p_field", P.mu_q_field)),
        phi_l2  = _l2(P.phi),
        phi_m_l2= _l2(P.phi_model),
        mask_px = _area(P.mask),
        w_q     = float(getattr(P, "lambda_q_weight", 0.0)),
        w_p     = float(getattr(P, "lambda_p_weight", 0.0)),
        age     = int(getattr(P, "birth_step", 0)),
        kids    = int(len(getattr(P, "child_ids", []))),
    )

def diff_snap(a, b):
    # returns small dict of deltas a->b
    out = {}
    for k in b.keys():
        if k in a:
            out["d_"+k] = float(b[k] - a[k])
    return out

def log_parent_step(runtime_ctx, step, sink_list):
    """Compute per-parent deltas vs previous snapshot and append to sink_list."""
    if not hasattr(runtime_ctx, "_parent_prev"): runtime_ctx._parent_prev = {}
    prev = runtime_ctx._parent_prev
    for rid, P in runtime_ctx.parents_by_region.items():
        snap = capture_parent_snapshot(P)
        row  = dict(step=step, parent_id=P.id, region_id=rid, age_steps=step - getattr(P, "birth_step", step))
        row.update(snap)
        if rid in prev:
            row.update(diff_snap(prev[rid], snap))
        sink_list.append(row)
        prev[rid] = snap
