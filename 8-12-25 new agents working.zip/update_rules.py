# -*- coding: utf-8 -*-
"""
Created on Wed Jul 23 10:32:58 2025

@author: chris and christine
"""
import time
from joblib import Parallel, delayed
import numpy as np
import config
from natural_gradient import (compute_inverse_fisher_field_natural,
                              )
from get_generators import get_generators
from omega import exp_lie_algebra_irrep, d_exp_phi_exact, d_exp_phi_tilde_exact
from parent_growth import grow_shrink_parent_masks  
from numerical_utils import sanitize_sigma, safe_omega_inv, safe_inv, soft_clip_phi_norm, masked_cond_proxy, masked_stat        
from generalized_diagnostics_metrics import compute_alignment_field_general

from update_terms_phi import ( 
    accumulate_phi_morphism_self_feedback, accumulate_phi_alignment_gradient,
    grad_feedback_phi_direct, grad_feedback_phi_tilde_direct, grad_self_phi_direct,
    grad_self_phi_tilde_direct)

from update_terms_mu_sigma import accumulate_mu_sigma_gradient
from bundle_morphism_utils import compute_direct_morphisms
from update_crossscale_terms import (
    accumulate_crossscale_gradients,
    accumulate_xscale_q_dn_gaugecov,
    # If/when you add model versions:
    accumulate_xscale_p_dn_gaugecov,
    
)
from crossscale_lambda import rebuild_downscale_maps
import numpy as np

# Local project imports
from preprocess_utils import ( zero_all_gradients, preprocess_agent_fields, build_all_omega_caches,
                              preprocess_all_agents, build_all_lambda_caches, update_parent_ramps)

from detector import detector_tick, spawn_or_update_parents, DetectorState, detect_overlap_aligned_regions

from runtime_context import runtime_ctx  # holds global_step




def compute_all_gradients(agent_i, agents, generators_q, generators_p, params):
    
    zero_all_gradients(agent_i)

    timings = {}

    # ─── Belief μ, Σ ───
    t0 = time.perf_counter()
    accumulate_mu_sigma_gradient(agent_i, agents, params, mode="belief")
    timings["mu_sigma_belief"] = time.perf_counter() - t0

    # ─── Model μ, Σ ───
    t0 = time.perf_counter()
    accumulate_mu_sigma_gradient(agent_i, agents, params, mode="model")
    timings["mu_sigma_model"] = time.perf_counter() - t0


    # ─── Belief alignment: φᵢ ───
    t0 = time.perf_counter()
    # Precompute once per i
    Q_all_belief_i = d_exp_phi_exact(agent_i.phi, generators_q)
    exp_neg_cache_belief = {}  # j.id -> e^{-φ_j}
    for nb in agent_i.neighbors:
        agent_j = agents[nb["id"]]
        exp_neg_phi_j = exp_neg_cache_belief.get(agent_j.id)
        if exp_neg_phi_j is None:
            exp_neg_phi_j = safe_omega_inv(agent_j._exp_phi, eps=config.eps, debug=False)
            exp_neg_cache_belief[agent_j.id] = exp_neg_phi_j

        accumulate_phi_alignment_gradient(
            agent_i, agent_j, generators_q, params,
            field="phi",
            beta_key="beta",
            omega_cache_key="Omega_cache",
            mu_key="mu_q_field",
            sigma_key="sigma_q_field",
            fisher_inv_key="inverse_fisher_phi",
            grad_key="grad_phi",
            # precomputes:
            Q_all_i=Q_all_belief_i,
            exp_neg_phi_j=exp_neg_phi_j,
        )
    timings["phi_alignment"] = time.perf_counter() - t0

    # ─── Model alignment: φ̃ᵢ ───
    t0 = time.perf_counter()
    Q_all_model_i = d_exp_phi_tilde_exact(agent_i.phi_model, generators_p)
    exp_neg_cache_model = {}  # j.id -> e^{-φ̃_j}
    for nb in agent_i.neighbors:
        agent_j = agents[nb["id"]]
        exp_neg_phi_j = exp_neg_cache_model.get(agent_j.id)
        if exp_neg_phi_j is None:
            exp_neg_phi_j = safe_omega_inv(agent_j._exp_phi_model, eps=config.eps, debug=False)
            exp_neg_cache_model[agent_j.id] = exp_neg_phi_j

        accumulate_phi_alignment_gradient(
            agent_i, agent_j, generators_p, params,
            field="phi_model",
            beta_key="beta_model",
            omega_cache_key="Omega_tilde_cache",
            mu_key="mu_p_field",
            sigma_key="sigma_p_field",
            fisher_inv_key="inverse_fisher_phi_model",
            grad_key="grad_phi_tilde",
            # precomputes:
            Q_all_i=Q_all_model_i,
            exp_neg_phi_j=exp_neg_phi_j,
        )
    timings["phi_tilde_alignment"] = time.perf_counter() - t0

    accumulate_crossscale_gradients(agent_i, agents, generators_q, generators_p, params)
           

    # ─── Morphism feedback/self: φᵢ ───
    t0 = time.perf_counter()
    accumulate_phi_morphism_self_feedback(
        agent_i, generators_p, generators_q, params,
        field="phi",
        fisher_inv_key="inverse_fisher_phi",
        grad_key="grad_phi",
        phi_self_func=grad_self_phi_direct,               # vectorized version OK
        phi_feedback_func=grad_feedback_phi_direct,       # vectorized version OK
    )
    timings["phi_morphism"] = time.perf_counter() - t0

    # ─── Morphism feedback/self: φ̃ᵢ ───
    t0 = time.perf_counter()
    accumulate_phi_morphism_self_feedback(
        agent_i, generators_p, generators_q, params,
        field="phi_model",
        fisher_inv_key="inverse_fisher_phi_model",
        grad_key="grad_phi_tilde",
        phi_self_func=grad_self_phi_tilde_direct,         # vectorized version OK
        phi_feedback_func=grad_feedback_phi_tilde_direct, # vectorized version OK
    )
    timings["phi_tilde_morphism"] = time.perf_counter() - t0

    if getattr(config, "debug_grad_timing", False):
        print(f"\n[GRAD TIMINGS] Agent {agent_i.id}")
        for k, v in timings.items():
            print(f"  {k:22s} : {v*1e3:7.2f} ms")

    return (
        (agent_i.grad_mu_q, agent_i.grad_sigma_q),
        (agent_i.grad_mu_p, agent_i.grad_sigma_p),
        agent_i.grad_phi,
        agent_i.grad_phi_tilde,
        agent_i.grad_Phi,
        agent_i.grad_Phi_tilde,
    )


def compute_adaptive_eta(base_eta, kl_scalar, cond_scalar,
                         grad=None, scaling_kl=1.0, scaling_cond=1.0,
                         eta_min=0.0, ema_prev=None, ema_alpha=None):
    """
    Returns η in [eta_min, base_eta].
    kl_scalar, cond_scalar: robust, precomputed scalars.
    If kl_scalar is None/NaN, fallback to grad norm.
    Optional EMA smoothing via ema_prev/ema_alpha.
    """
    # KL or fallback
    if kl_scalar is None or not np.isfinite(kl_scalar):
        kl_term = float(np.mean(np.abs(grad))) if grad is not None else 0.0
    else:
        kl_term = float(kl_scalar)

    cond_term = float(cond_scalar) if np.isfinite(cond_scalar) else 1.0
    denom = 1.0 + scaling_kl * kl_term + scaling_cond * cond_term
    eta = np.clip(base_eta / denom, eta_min, base_eta)

    if ema_prev is not None and ema_alpha is not None and 0.0 < ema_alpha < 1.0:
        eta = ema_alpha * eta + (1.0 - ema_alpha) * ema_prev
    return eta



def apply_phi_updates(agent, grad_phi, grad_phi_m, mask, params):
    
    agent.grad_phi = np.array(grad_phi, copy=True)
    agent.grad_phi_tilde = np.array(grad_phi_m, copy=True)
    mask_exp = mask[..., None]
    mexp = mask[..., None]
    # config pulls
    tau_phi       = params.get("tau_phi",        config.tau_phi)
    tau_phi_model = params.get("tau_phi_model",  config.tau_phi_model)
    s_eta_phi     = params.get("eta_phi_adaptive_scaling",        config.eta_phi_adaptive_scaling)
    s_eta_cond    = params.get("eta_sigma_condition_scaling",     config.eta_sigma_condition_scaling)
    eta_phi_min   = params.get("eta_phi_min",    config.eta_phi_min)
    eta_phi_m_min = params.get("eta_phi_model_min", config.eta_phi_model_min)

    # robust, masked KL scalars (precompute once per step if you like)
    kl_q = masked_stat(getattr(agent, "cached_alignment_kl", None), mask, default=0.0)
    kl_p = masked_stat(getattr(agent, "cached_model_alignment_kl", None), mask, default=0.0)

    # condition proxies cached from sanitized Σ in preprocess
    cond_q = getattr(agent, "_cond_proxy_q", 1.0)
    cond_p = getattr(agent, "_cond_proxy_p", 1.0)

    # optional EMA on η
    ema_a  = getattr(config, "eta_ema_alpha", None)
    prev_eta_phi  = getattr(agent, "_eta_phi_prev", None)
    prev_eta_phi_m= getattr(agent, "_eta_phi_m_prev", None)

    eta_phi = compute_adaptive_eta(tau_phi, kl_q, cond_q, grad=grad_phi,
                                   scaling_kl=s_eta_phi, scaling_cond=s_eta_cond,
                                   eta_min=eta_phi_min, ema_prev=prev_eta_phi, ema_alpha=ema_a)
    eta_phi_m = compute_adaptive_eta(tau_phi_model, kl_p, cond_p, grad=grad_phi_m,
                                     scaling_kl=params.get("eta_phi_model_adaptive_scaling", s_eta_phi),
                                     scaling_cond=s_eta_cond, eta_min=eta_phi_m_min,
                                     ema_prev=prev_eta_phi_m, ema_alpha=ema_a)

    delta_phi   = np.nan_to_num(eta_phi   * grad_phi,   nan=0.0, posinf=0.0, neginf=0.0)
    delta_phi_m = np.nan_to_num(eta_phi_m * grad_phi_m, nan=0.0, posinf=0.0, neginf=0.0)

    agent.phi       -= delta_phi   * mexp
    agent.phi_model += delta_phi_m * mexp # += validated by energy diff step

    agent._eta_phi_prev   = eta_phi
    agent._eta_phi_m_prev = eta_phi_m


def synchronous_step(agents, generators_q, generators_p, params=None, n_jobs=1, runtime_ctx=None):
    """
    Children-only gradient step with mid-run lvl-1 emergence & soft growth.
    Expects external defs:
      - preprocess_all_agents, build_all_omega_caches, build_all_lambda_caches
      - compute_all_gradients, apply_phi_updates, compute_direct_morphisms
      - compute_alignment_field_general, detect_overlap_aligned_regions
      - spawn_or_update_parents, grow_shrink_parent_masks
      - parent_growth.seed_new_parents_from_uncovered
    """
    import numpy as np
    from joblib import Parallel, delayed

    # --- small helper (robust container) ------------------------------------
    def _as_parent_dict(obj):
        import collections.abc as _abc
        if obj is None:
            return {}
        if isinstance(obj, dict):
            return {int(getattr(p, "id", pid)): p for pid, p in obj.items()}
        if isinstance(obj, _abc.Iterable) and not hasattr(obj, "mask"):
            return {int(getattr(p, "id", i)): p for i, p in enumerate(obj)}
        return {int(getattr(obj, "id", 0)): obj}

    # --- sanity --------------------------------------------------------------
    assert agents and (len(agents) > 0), "synchronous_step: no agents"
    assert runtime_ctx is not None, "synchronous_step: pass runtime_ctx"
    params = params or {}
    N = len(agents)

    # --- config pulls --------------------------------------------------------
    tau_mu_belief    = params.get("tau_mu_belief",    config.tau_mu_belief)
    tau_sigma_belief = params.get("tau_sigma_belief", config.tau_sigma_belief)
    tau_mu_model     = params.get("tau_mu_model",     config.tau_mu_model)
    tau_sigma_model  = params.get("tau_sigma_model",  config.tau_sigma_model)
    eps              = config.eps

    # --- runtime ctx init ----------------------------------------------------
    if not hasattr(runtime_ctx, "detector_state") or (runtime_ctx.detector_state is None):
        runtime_ctx.detector_state = DetectorState()
    if not hasattr(runtime_ctx, "global_step"):
        runtime_ctx.global_step = 0
    if not hasattr(runtime_ctx, "parents_by_region"):
        runtime_ctx.parents_by_region = {}
    if not hasattr(runtime_ctx, "next_parent_id"):
        runtime_ctx.next_parent_id = 0

    runtime_ctx.parents_by_region = _as_parent_dict(runtime_ctx.parents_by_region)

    frozen_levels     = set(params.get("frozen_levels", []))
    frozen_phi_levels = set(params.get("frozen_phi_levels", []))

    # --- children + current parents for caches/transport (pre) --------------
    all_agents = agents + list(runtime_ctx.parents_by_region.values())

    # 1) preprocess & caches (light sanitize pre)
    pre_params = dict(params)
    pre_params["sanitize_strict"] = pre_params.get("sanitize_strict_pre", False)
    pre_params["exp_n_jobs"] = 1
    preprocess_all_agents(all_agents, pre_params, generators_q, generators_p)
    build_all_omega_caches(all_agents)
    build_all_lambda_caches(all_agents)

    # 2) gradients (children only)
    grads = Parallel(n_jobs=n_jobs, backend="threading", batch_size="auto")(
        delayed(compute_all_gradients)(agent_i, all_agents, generators_q, generators_p, params)
        for agent_i in agents
    )
    q_updates, p_updates, phi_grads, phi_m_grads, morphism_grads, morphism_tilde_grads = zip(*grads)
    mask_list = [A.mask for A in agents]

    # 3) apply updates (children only)
    def apply_agent_updates(i):
        agent = agents[i]
        mask  = mask_list[i]
        Δη1_q, Δη2_q = q_updates[i]
        Δη1_p, Δη2_p = p_updates[i]

        if Δη1_q is None: Δη1_q = np.zeros_like(agent.mu_q_field)
        if Δη2_q is None: Δη2_q = np.zeros_like(agent.sigma_q_field)
        if Δη1_p is None: Δη1_p = np.zeros_like(agent.mu_p_field)
        if Δη2_p is None: Δη2_p = np.zeros_like(agent.sigma_p_field)

        mask_mu    = mask[..., None]
        mask_sigma = mask[..., None, None]

        if getattr(agent, "level", 0) not in frozen_levels:
            agent.mu_q_field    += tau_mu_belief    * Δη1_q * mask_mu
            agent.mu_p_field    += tau_mu_model     * Δη1_p * mask_mu
            agent.sigma_q_field  = agent.sigma_q_field + tau_sigma_belief * Δη2_q * mask_sigma
            agent.sigma_p_field  = agent.sigma_p_field + tau_sigma_model  * Δη2_p * mask_sigma

        if getattr(agent, "level", 0) not in frozen_phi_levels:
            apply_phi_updates(agent, phi_grads[i], phi_m_grads[i], mask, params)
            agent._exp_phi = agent._exp_neg_phi = None
            agent._exp_phi_model = agent._exp_neg_phi_model = None
            agent.Omega_cache.clear(); agent.Omega_tilde_cache.clear()

        agent.bundle_morphism_q_to_p, agent.bundle_morphism_p_to_q = compute_direct_morphisms(
            phi=agent.phi, phi_model=agent.phi_model,
            generators_q=agent.generators_q, generators_p=agent.generators_p,
            Phi_0=agent.Phi_0, Phi_tilde_0=agent.Phi_tilde_0,
        )

    Parallel(n_jobs=n_jobs, backend="threading", batch_size="auto")(
        delayed(apply_agent_updates)(i) for i in range(N)
    )

    # 4) post-refresh (strict sanitize)
    post_params = dict(params)
    post_params["sanitize_strict"] = True
    post_params["exp_n_jobs"] = 1
    preprocess_all_agents(all_agents, post_params, generators_q, generators_p)
    build_all_omega_caches(all_agents)
    build_all_lambda_caches(all_agents)

    # 5) recompute cached KL fields (children only)
    for A in agents:
        A.cached_alignment_kl       = compute_alignment_field_general(all_agents, A.id, field_type="belief", log_eps=eps)
        A.cached_model_alignment_kl = compute_alignment_field_general(all_agents, A.id, field_type="model",  log_eps=eps)

    # 5a) detector + mid-run seeding (cadenced)
    H, W = agents[0].mask.shape
    detector_period = int(getattr(config, "detector_period", 2))
    do_detect = ((runtime_ctx.global_step % detector_period) == 0)

    # define for later parts
    active = {}
    cand_map = np.zeros((H, W), np.float32)

    if do_detect:
        active = detect_overlap_aligned_regions(
            agents, H=H, W=W,
            min_kids=getattr(config, "seed_min_kids", 2),
            kl_tau  =getattr(config, "emerge_tau", 0.28),
            min_area=getattr(config, "emerge_min_area", 8),
        )
        # candidate map = union of active regions
        for R in active.values():
            cand_map = np.maximum(cand_map, np.asarray(R.mask, np.float32))

        # spawn/update FIRST, then merge (never replace)
        parents, next_pid = spawn_or_update_parents(
            active_regions=active,
            agents=agents,
            parents_by_id=runtime_ctx.parents_by_region,
            next_parent_id=runtime_ctx.next_parent_id,
            field_generators=(generators_q, generators_p),
        )
        parents = _as_parent_dict(parents)
        existing = runtime_ctx.parents_by_region
        for pid, P in parents.items():
            existing[int(pid)] = P
        runtime_ctx.parents_by_region = existing
        runtime_ctx.next_parent_id = max(
            int(runtime_ctx.next_parent_id),
            int(next_pid),
            (max(existing.keys()) + 1) if existing else 1
        )

        # coverage = hard support (no halo), optional erosion
        support_eps = float(getattr(config, "parent_cover_support_eps", 0.30))
        P_support = np.zeros((H, W), dtype=bool)
        for P in runtime_ctx.parents_by_region.values():
            P_support |= (np.asarray(P.mask, np.float32) > support_eps)

        erode_iters = int(getattr(config, "parent_cover_erode", 0))
        if erode_iters > 0:
            try:
                from scipy.ndimage import binary_erosion
                P_support = binary_erosion(P_support, iterations=erode_iters, border_value=0)
            except Exception:
                core = P_support.copy()
                for _ in range(erode_iters):
                    up    = np.pad(core[1: , : ], ((0,1),(0,0)))
                    down  = np.pad(core[:-1, : ], ((1,0),(0,0)))
                    left  = np.pad(core[: , 1: ], ((0,0),(0,1)))
                    right = np.pad(core[: , :-1], ((0,0),(1,0)))
                    core &= up & down & left & right
                P_support = core

        seed_floor = float(getattr(config, "parent_seed_floor", 0.12))
        cand_bool  = (cand_map > seed_floor)
        uncovered_bool = cand_bool & ~P_support

        # seed NEW parents only once (cap + spacing; avoid dupes)
        from parent_growth import seed_new_parents_from_uncovered
        seeded_ids = seed_new_parents_from_uncovered(
            runtime_ctx,
            uncovered_bool,                              # boolean map
            children=agents,
            generators_q=generators_q, generators_p=generators_p,
            min_area=int(getattr(config, "emerge_min_area", 8)),
            iou_thr=float(getattr(config, "parent_new_iou_thr", 0.40)),
            max_new_per_step=int(getattr(config, "parent_max_new_per_step", 2)),
            min_interseed_px=int(getattr(config, "parent_min_interseed_px", 6)),
        )
        if getattr(config, "debug_parent_masks", False):
            print(f"[EMERGE?] cand_nz={int(cand_bool.sum())} covered_nz={int(P_support.sum())} "
                  f"uncovered_nz={int(uncovered_bool.sum())} seed_floor={seed_floor:.2f} "
                  f"support_eps={support_eps:.2f} erode={erode_iters} parents_now={len(runtime_ctx.parents_by_region)}")
            if seeded_ids:
                print(f"[EMERGE] step {runtime_ctx.global_step}: seeded {len(seeded_ids)} → {seeded_ids}")

    # 5b) assign children → parents (overlap-based)
    def _assign_children_to_parents(children, parents, eps=1e-3):
        parents = _as_parent_dict(parents)
        Pmasks = {int(pid): (np.asarray(P.mask, np.float32) > float(eps)) for pid, P in parents.items()}
        if not Pmasks:
            for ch in children: setattr(ch, "parent_id", -1)
            return
        for ch in children:
            cm = (np.asarray(ch.mask, np.float32) > float(eps))
            best, best_ov = -1, 0
            for pid, pm in Pmasks.items():
                ov = int((cm & pm).sum())
                if ov > best_ov:
                    best, best_ov = pid, ov
            ch.parent_id = int(best) if best_ov > 0 else -1

    _assign_children_to_parents(agents, runtime_ctx.parents_by_region, eps=getattr(config, "support_cutoff_eps", 1e-3))

    # 5.5) grow/shrink parents (Ω-aligned) every step
    grow_shrink_parent_masks(
        runtime_ctx,
        agents,
        tau_grow     = float(getattr(config, "parent_tau_grow",   0.34)),
        tau_shrink   = float(min(getattr(config, "parent_tau_shrink", 0.22),
                                 0.85 * getattr(config, "parent_tau_grow", 0.34))),
        min_area     = int(getattr(config, "min_area_parent",   8)),
        grow_band    = int(getattr(config, "grow_band",         1)),
        shrink_band  = int(getattr(config, "shrink_band",       1)),
        delta_cap    = float(getattr(config, "parent_delta_cap", 0.04)),
        blur_iters   = int(getattr(config, "parent_blur_iters", 1)),
    )

    # optional: age parents (for grace/hysteresis logic in growth)
    for P in runtime_ctx.parents_by_region.values():
        P._age = int(getattr(P, "_age", 0)) + 1

    # feed children to viz
    runtime_ctx.children_latest = agents

    # 6) telemetry (optional)
    if params.get("log_step_telemetry", False):
        step_telemetry(agents, params.get("step", -1))

    # finalize
    runtime_ctx.global_step += 1
    return agents







def _as_parent_dict(obj):
    """Accept dict, list, or single parent object; return {pid: parent} dict."""
    import collections.abc as _abc
    if obj is None:
        return {}
    if isinstance(obj, dict):
        return {int(getattr(p, "id", pid)): p for pid, p in obj.items()}
    if isinstance(obj, _abc.Iterable) and not hasattr(obj, "mask"):
        return {int(getattr(p, "id", i)): p for i, p in enumerate(obj)}
    # single parent object
    return {int(getattr(obj, "id", 0)): obj}











































def step_telemetry(agents, step):
    floor = getattr(config, "sigma_eig_floor", 1e-6)
    eps   = 1e-12
    vals = []
    for A in agents:
        # SPD stats
        wq = np.linalg.eigvalsh(0.5*(A.sigma_q_field + np.swapaxes(A.sigma_q_field,-1,-2)))
        wp = np.linalg.eigvalsh(0.5*(A.sigma_p_field + np.swapaxes(A.sigma_p_field,-1,-2)))
        min_eig_q = float(wq.min(initial=1e9))
        min_eig_p = float(wp.min(initial=1e9))
        # η and KL
        eta_phi   = getattr(A, "_eta_phi_prev", None)
        eta_phi_m = getattr(A, "_eta_phi_m_prev", None)
        kl_q_med  = masked_stat(getattr(A, "cached_alignment_kl", None), A.mask, default=np.nan)
        kl_p_med  = masked_stat(getattr(A, "cached_model_alignment_kl", None), A.mask, default=np.nan)
        vals.append(dict(
            min_eig_q=min_eig_q, min_eig_p=min_eig_p,
            cond_q=A._cond_proxy_q, cond_p=A._cond_proxy_p,
            eta_phi=eta_phi, eta_phi_m=eta_phi_m,
            kl_q_med=kl_q_med, kl_p_med=kl_p_med
        ))
        # per-agent log for later plots
        #A.log_metrics(step, vals[-1])
        
    # quick console summary
    mq = min(v["min_eig_q"] for v in vals)
    mp = min(v["min_eig_p"] for v in vals)
    print(f"[STEP {step}] min_eig(q)={mq:.2e}\n  min_eig(p)={mp:.2e}\n  "
          f"ηφ~{np.nanmedian([v['eta_phi'] for v in vals]):.3g}\n  "
          f"KLb~{np.nanmedian([v['kl_q_med'] for v in vals]):.3g}\n\n")
    


def _masked_unit(v, mask):
    v = np.nan_to_num(v, copy=True)
    v *= (mask > getattr(config, "support_cutoff_eps", 0.0))[..., None].astype(v.dtype)
    n = float(np.linalg.norm(v))
    return (v / (n + 1e-12), n)



# diagnostics.py (or wherever you put them)
def energy_diff_for_phi(agent_i, agent_j, agents_all,
                        eps_list=(1e-4, 3e-4, 1e-3, 3e-3),
                        rel_tol=1e-8, abs_tol=1e-10,
                        expect="minus"):  # "minus" for φ (φ -= η∇E), "plus" if you ever flip
    import numpy as np, config

    def E():
        build_all_omega_caches(agents_all)
        KLi = compute_alignment_field_general(agents_all, agent_i.id, field_type="belief", log_eps=config.eps)
        m = (agent_i.mask > getattr(config, "support_cutoff_eps", 0.0)) & \
            (agent_j.mask  > getattr(config, "support_cutoff_eps", 0.0))
        return float(np.nanmean(KLi[m]))

    try:
        E0 = E()
    except Exception:
        E0 = float("nan")

    g = getattr(agent_i, "grad_phi", None)
    if g is None:
        return {"ok": None, "reason": "no_grad", "E0": E0, "gnorm": float("nan"), "rows": [], "used_eps": None}

    v = np.nan_to_num(g, copy=True)
    v *= (agent_i.mask > getattr(config, "support_cutoff_eps", 0.0))[..., None].astype(v.dtype)
    gnorm = float(np.linalg.norm(v))
    if not np.isfinite(gnorm) or gnorm == 0.0:
        return {"ok": None, "reason": "zero_or_nonfinite_grad", "E0": E0, "gnorm": gnorm, "rows": [], "used_eps": None}
    ghat = v / (gnorm + 1e-12)

    preprocess_agent_fields(agent_i, {"sanitize_strict": True})
    preprocess_agent_fields(agent_j, {"sanitize_strict": True})

    rows, used_eps = [], None
    saved = agent_i.phi.copy()
    tol = max(abs_tol, abs(E0) * rel_tol) if np.isfinite(E0) else abs_tol

    for eps in eps_list:
        deltas = []
        for sgn in (+1.0, -1.0):
            agent_i.phi = saved + sgn * eps * ghat
            preprocess_agent_fields(agent_i, {"sanitize_strict": True})
            dE = E() - E0
            rec = {"eps": float(eps), "sign": int(np.sign(sgn)), "dE": float(dE)}
            rows.append(rec); deltas.append(rec)
        if used_eps is None and any(abs(r["dE"]) > tol for r in deltas):
            used_eps = eps

    agent_i.phi = saved
    preprocess_agent_fields(agent_i, {"sanitize_strict": True})
    build_all_omega_caches(agents_all)

    ok = None
    if used_eps is not None:
        small = [r for r in rows if np.isclose(r["eps"], used_eps)]
        want = -1 if expect == "minus" else +1
        chosen = next((r for r in small if r["sign"] == want), None)
        ok = (chosen is not None and chosen["dE"] < 0.0)

    return {"ok": ok, "E0": E0, "gnorm": float(gnorm), "rows": rows, "used_eps": used_eps}



def energy_diff_for_phi_model(agent_i, agent_j, agents_all,
                              eps_list=(1e-4, 3e-4, 1e-3, 3e-3),
                              rel_tol=1e-8, abs_tol=1e-10,
                              expect="plus"):  # φ̃ += η∇E now
    import numpy as np, config

    def _masked_unit(v, mask):
        v = np.nan_to_num(v, copy=True)
        v *= (mask > getattr(config, "support_cutoff_eps", 0.0))[..., None].astype(v.dtype)
        n = float(np.linalg.norm(v))
        return (v / (n + 1e-12), n)

    def E():
        build_all_omega_caches(agents_all)
        KLm = compute_alignment_field_general(agents_all, agent_i.id, field_type="model", log_eps=config.eps)
        m = ((agent_i.mask > getattr(config, "support_cutoff_eps", 0.0)) &
             (agent_j.mask  > getattr(config, "support_cutoff_eps", 0.0)))
        return float(np.nanmean(KLm[m]))

    try:
        E0 = E()
    except Exception:
        E0 = float("nan")

    g = getattr(agent_i, "grad_phi_tilde", None)
    if g is None:
        return {"ok": None, "reason": "no_grad", "E0": E0, "gnorm": float("nan"), "rows": [], "used_eps": None}

    ĝ, gnorm = _masked_unit(g, agent_i.mask)
    if (not np.isfinite(gnorm)) or gnorm == 0.0:
        return {"ok": None, "reason": "zero_or_nonfinite_grad", "E0": E0, "gnorm": float(gnorm), "rows": [], "used_eps": None}

    preprocess_agent_fields(agent_i, {"sanitize_strict": True})
    preprocess_agent_fields(agent_j, {"sanitize_strict": True})

    rows, used_eps = [], None
    saved = agent_i.phi_model.copy()
    tol = max(abs_tol, abs(E0) * rel_tol) if np.isfinite(E0) else abs_tol

    for eps in eps_list:
        deltas = []
        for sgn in (+1.0, -1.0):
            agent_i.phi_model = saved + sgn * eps * ĝ
            preprocess_agent_fields(agent_i, {"sanitize_strict": True})
            dE = E() - E0
            rec = {"eps": float(eps), "sign": int(np.sign(sgn)), "dE": float(dE)}
            rows.append(rec); deltas.append(rec)
        if used_eps is None and any(abs(r["dE"]) > tol for r in deltas):
            used_eps = eps

    agent_i.phi_model = saved
    preprocess_agent_fields(agent_i, {"sanitize_strict": True})
    build_all_omega_caches(agents_all)

    ok = None
    if used_eps is not None:
        small = [r for r in rows if np.isclose(r["eps"], used_eps)]
        want = -1 if expect == "minus" else +1
        chosen = next((r for r in small if r["sign"] == want), None)
        ok = (chosen is not None and chosen["dE"] < 0.0)

    return {"ok": ok, "E0": E0, "gnorm": float(gnorm), "rows": rows, "used_eps": used_eps}
