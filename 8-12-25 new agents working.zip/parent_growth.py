# -*- coding: utf-8 -*-
"""
Created on Mon Aug 11 17:58:13 2025

@author: chris and christine
"""
from typing import List, Dict, Optional
import config
# parent_growth.py
import numpy as np
from agent_schema import Agent
from detector import resize_nn, child_activity_map
# parent_growth.py (top)
from parent_mask_utils import (
    resize_nn, binary_dilate_3x3, binary_erode_3x3, gauss3,
    child_activity_map, overlap_count, cheap_dt
)

# --- 4-connected components (pure NumPy) ---
def _label4(binary_mask: np.ndarray):
    """
    4-connected component labeling.
    Returns (labels:int32[H,W], n_components:int)
    """
    H, W = binary_mask.shape
    labels = np.zeros((H, W), dtype=np.int32)
    vid = 0
    # neighbors: up, left
    for y in range(H):
        for x in range(W):
            if not binary_mask[y, x]:
                continue
            up  = labels[y-1, x] if y > 0 else 0
            left= labels[y, x-1] if x > 0 else 0
            if up == 0 and left == 0:
                vid += 1
                labels[y, x] = vid
            elif up != 0 and left == 0:
                labels[y, x] = up
            elif up == 0 and left != 0:
                labels[y, x] = left
            else:
                # merge: relabel one component to the other (path compression lite)
                a, b = (up, left) if up < left else (left, up)
                labels[y, x] = a
                if a != b:
                    labels[labels == b] = a
    # compact labels to 1..n
    uniq = np.unique(labels)
    uniq = uniq[uniq != 0]
    remap = {v:i+1 for i,v in enumerate(uniq)}
    for v, i in remap.items():
        labels[labels == v] = i
    return labels, len(uniq)


def seed_new_parents_from_uncovered(runtime_ctx, candidate_map, *,
                                    children, generators_q, generators_p,
                                    min_area: int,
                                    cover_tau: float = 0.1,
                                    iou_thr: float = 0.4,
                                    max_new_per_step: int = None,
                                    min_interseed_px: int = None):
    import numpy as np
    max_new_per_step = max_new_per_step or int(getattr(config, "parent_max_new_per_step", 2))
    min_interseed_px = min_interseed_px or int(getattr(config, "parent_min_interseed_px", 6))

    # normalize container
    if not hasattr(runtime_ctx, "parents_by_region") or runtime_ctx.parents_by_region is None:
        runtime_ctx.parents_by_region = {}
    if isinstance(runtime_ctx.parents_by_region, list):
        runtime_ctx.parents_by_region = {getattr(p, "id", i): p for i,p in enumerate(runtime_ctx.parents_by_region)}
    parents = runtime_ctx.parents_by_region

    H, W = candidate_map.shape
    cand = candidate_map.astype(bool)  # boolean expected

    labels, ncc = _label4(cand)
    if ncc == 0:
        return []

    # collect components with area & centroid, then sort by area desc
    comps = []
    for c in range(1, ncc+1):
        comp = (labels == c)
        area = int(comp.sum())
        if area < int(min_area):
            continue
        ys, xs = np.nonzero(comp)
        cy, cx = float(ys.mean()), float(xs.mean())
        comps.append((area, (cy, cx), comp))
    comps.sort(key=lambda t: t[0], reverse=True)

    # IoU helper
    def _iou(a, b):
        A = a.astype(bool); B = b.astype(bool)
        inter = (A & B).sum(); union = (A | B).sum()
        return float(inter) / max(1, int(union))

    # keep already-seeded centers this call to enforce spacing
    chosen = []
    seeded_ids = []

    # template
    tmpl = children[0]
    AgentCls = tmpl.__class__
    dtype = tmpl.mu_q_field.dtype
    Kq, Kp = tmpl.mu_q_field.shape[-1], tmpl.mu_p_field.shape[-1]

    def _make_parent(pid):
        eye_q = np.tile(np.eye(Kq, dtype=dtype), (H, W, 1, 1))
        eye_p = np.tile(np.eye(Kp, dtype=dtype), (H, W, 1, 1))
        P = AgentCls(
            id=pid, center=(0,0), radius=0.0, mask=np.zeros((H, W), np.float32),
            mu_q_field=np.zeros((H, W, Kq), dtype=dtype), sigma_q_field=eye_q.copy(),
            mu_p_field=np.zeros((H, W, Kp), dtype=dtype), sigma_p_field=eye_p.copy(),
            phi=np.zeros((H, W, 3), dtype=dtype), phi_model=np.zeros((H, W, 3), dtype=dtype),
            neighbors=[]
        )
        P.level = 1
        P.emerged = True
        P._age = 0
        P._grace = int(getattr(config, "parent_grace_steps", 2))
        P._shrink_strikes = 0
        P.Omega_cache = {}; P.Omega_tilde_cache = {}
        P._exp_phi = P._exp_neg_phi = None
        P._exp_phi_model = P._exp_neg_phi_model = None
        P.generators_q = generators_q; P.generators_p = generators_p
        P.Phi_0 = getattr(tmpl, "Phi_0", None); P.Phi_tilde_0 = getattr(tmpl, "Phi_tilde_0", None)
        return P

    # union of current parent supports for IoU filtering
    P_masks_bool = [(np.asarray(P.mask) > 0.25) for P in parents.values()]

    for area, (cy, cx), comp in comps:
        # spacing against already chosen seeds this call
        if chosen and min_interseed_px > 0:
            if min((cy - y)**2 + (cx - x)**2 for (y, x) in chosen) < (min_interseed_px**2):
                continue
        # IoU against existing parents (avoid near-dupes)
        too_close = False
        for pb in P_masks_bool:
            if _iou(comp, pb) >= float(iou_thr):
                too_close = True; break
        if too_close:
            continue

        pid = int(getattr(runtime_ctx, "next_parent_id", 0))
        runtime_ctx.next_parent_id = pid + 1
        P = _make_parent(pid)
        # start a bit softer than before
        P.mask = comp.astype(np.float32) * 0.35
        parents[pid] = P
        seeded_ids.append(pid)
        chosen.append((cy, cx))

        if len(seeded_ids) >= max_new_per_step:
            break

    if getattr(config, "debug_parent_masks", False):
        print(f"[EMERGE] selected {len(seeded_ids)} / {len(comps)} comps "
              f"(cap={max_new_per_step}, spacing={min_interseed_px}px, iou_thr={iou_thr:.2f})")
    return seeded_ids






# parent_growth.py (new helpers)
def _parent_bands(mask: np.ndarray, grow_band: int, shrink_band: int):
    supp = mask > 1e-6
    dil, ero = supp.copy(), supp.copy()
    for _ in range(max(1, int(grow_band))):   dil = binary_dilate_3x3(dil)
    for _ in range(max(1, int(shrink_band))): ero = binary_erode_3x3(ero)
    band_out = dil & (~supp)
    band_in  = supp & (~ero)
    return band_out, band_in, supp



def _scores_from_kl(kl, tau_shrink, kappa, tau_grow):
    kl = np.maximum(kl, 0.0)
    grow = np.exp(-(kl / max(kappa, 1e-8)))
    shrink = 1.0 / (1.0 + np.exp(-(kl - tau_shrink) / max(kappa, 1e-8)))
    if tau_grow is not None:
        grow *= (kl <= float(tau_grow)).astype(np.float32)
    return grow.astype(np.float32), shrink.astype(np.float32)

def _agreement_gate(children, child_ids, shape):
    try:
        from parent_growth import _soft_agreement_from_phi  # reuse your existing impl
        agree = _soft_agreement_from_phi(children, child_ids, use_phi_tilde=True)
    except Exception:
        agree = None
    if agree is None: return None
    a = np.asarray(agree, np.float32)
    if a.shape != shape:
        a = resize_nn(a, shape)
    a = np.nan_to_num(a, nan=0.0, posinf=1.0, neginf=0.0)
    return np.clip(a, 0.0, 1.0)


# --- PATCH 1: allow KL helper to look outside the mask -----------------------
def _mean_child_kl_field(P, children, where=None):
    """
    Mean of children's cached KL on 'where' pixels.
    If where is None, falls back to (child.mask ∧ parent.mask).
    """
    H, W = P.mask.shape
    acc = np.zeros((H, W), dtype=np.float32)
    cnt = np.zeros((H, W), dtype=np.int32)

    for ch in children:
        # optional: restrict to this parent's kids if you track them
        pids = getattr(ch, "parent_ids", None)
        if pids is not None and P.id not in pids:
            continue

        kl = getattr(ch, "cached_alignment_kl", None)
        if kl is None:
            continue
        k = np.asarray(kl).squeeze()
        if k.shape != (H, W):
            k = resize_nn(k, (H, W))  # your existing resize helper

        if where is None:
            m = (np.asarray(ch.mask) > 0) & (np.asarray(P.mask) > 0)
        else:
            m = (np.asarray(ch.mask) > 0) & where

        if m.any():
            acc[m] += k[m]
            cnt[m] += 1

    out = np.full((H, W), np.nan, dtype=np.float32)
    nz = cnt > 0
    if nz.any():
        out[nz] = acc[nz] / np.maximum(cnt[nz], 1)
    # safe max computation
    if not np.isfinite(out).any():
        mx = None
        out = np.zeros_like(out, dtype=np.float32)
    else:
        mx = np.nanmax(out)
    
    # fill NaNs with a conservative high value so growth won't trigger there
    fill_val = 1.0 if mx is None or not np.isfinite(mx) else mx
    out = np.nan_to_num(out, nan=fill_val, posinf=fill_val, neginf=fill_val)
    
    return out



def _soft_agreement_from_phi(children: List[Agent], child_ids: List[int],
                             use_phi_tilde: bool = True, eps: float = 1e-6) -> Optional[np.ndarray]:
    """
    Soft [0,1] agreement map from kids' φ (and optionally φ̃).
    Lower cross-kid variance ⇒ higher agreement. Returns (H, W).
    """
    stacks = []

    phi_stack = [np.asarray(children[i].phi) for i in child_ids
                 if getattr(children[i], "phi", None) is not None]
    if len(phi_stack) >= 2:
        stacks.append(np.stack(phi_stack, axis=0))  # (M,H,W,3)

    if use_phi_tilde:
        ptil_stack = [np.asarray(children[i].phi_model) for i in child_ids
                      if getattr(children[i], "phi_model", None) is not None]
        if len(ptil_stack) >= 2:
            stacks.append(np.stack(ptil_stack, axis=0))  # (M,H,W,3)

    if not stacks:
        return None

    arr = np.concatenate(stacks, axis=0)  # (M,H,W,3)
    # mean across kids → (H,W,3)
    mean = arr.mean(axis=0)
    # variance across kids → (H,W,3)
    var_feat = ((arr - mean) ** 2).mean(axis=0)
    # collapse feature comps → (H,W)
    var = var_feat.sum(axis=-1)

    # normalize & map to (0,1]
    denom = float(var.mean()) + eps
    agree = np.exp(-var / denom)  # higher when kids' φ agree
    return agree.astype(arr.dtype)  # (H,W)


# --- PATCH 2: include outer band in KL sampling, keep the rest unchanged -----
def grow_shrink_parent_masks(runtime_ctx, children, *,
    tau_grow=0.30, tau_shrink=0.18,
    eta_grow=0.08, eta_shrink=0.12,
    kappa=0.05, min_area=10, max_area=None,
    grow_band=1, shrink_band=1,
    delta_cap=0.05, blur_iters=1, **compat_kwargs):

    import numpy as np
    from scipy.ndimage import binary_dilation

    def dilate_bool(mask: np.ndarray, r: int, periodic: bool = False) -> np.ndarray:
        """Binary dilation by r pixels. If periodic=True, wraps edges via tiling."""
        if r <= 0:
            return mask.astype(bool)
        se = np.ones((2*r + 1, 2*r + 1), dtype=bool)
        m = mask.astype(bool)
        if not periodic:
            return binary_dilation(m, structure=se)
        # periodic wrap: tile → dilate → crop center
        H, W = m.shape
        T = np.tile(m, (3, 3))
        Td = binary_dilation(T, structure=se)
        return Td[H:2*H, W:2*W]

    parents = getattr(runtime_ctx, "parents_by_region", {})
    if not parents:
        return

    # legacy aliases
    if compat_kwargs.get("grow_iters") is not None:
        grow_band = int(compat_kwargs["grow_iters"])
    if compat_kwargs.get("shrink_iters") is not None:
        shrink_band = int(compat_kwargs["shrink_iters"])

    periodic = bool(getattr(config, "periodic_domain", True))
    eps = float(getattr(config, "support_cutoff_eps", 1e-6))

    for rid, P in parents.items():
        mask = np.asarray(P.mask, np.float32)
        H, W = mask.shape

        if not getattr(P, "emerged", False):
            P.mask = (0.995 * mask).astype(np.float32)
            continue

        band_out, band_in, supp = _parent_bands(mask, grow_band, shrink_band)

        # --- sample KL on (support ∪ outer band) so the ring has valid KL
        look = (supp | band_out)
        kl = _mean_child_kl_field(P, children, where=look)
        grow_score, shrink_score = _scores_from_kl(kl, tau_shrink, kappa, tau_grow)

        # keep scores where they make sense
        grow_score   *= look.astype(np.float32)   # can grow on support ∪ outer ring
        shrink_score *= supp.astype(np.float32)   # shrink only inside support

        # favor interior via core distance
        core = getattr(P, "_core_map", None)
        if core is not None and np.any(core):
            dt = cheap_dt(core.astype(bool))
            r_dec = float(getattr(config, "parent_core_decay_px", 6.0))
            grow_score *= np.exp(-dt / max(r_dec, 1.0)).astype(np.float32)

        # φ/φ̃ agreement
        agree = _agreement_gate(children, getattr(P, "child_ids", []), mask.shape)
        if agree is not None:
            gamma_g = float(getattr(config, "parent_agree_gamma", 1.5))
            gamma_s = float(getattr(config, "parent_shrink_agree_gamma", 1.0))
            grow_score   *= (agree ** gamma_g)
            shrink_score *= ((1.0 - agree) ** gamma_s)

        # === activity + overlap gates (with dilation so band_out is eligible) ===
        r = int(max(1, grow_band))

        # activity gate
        active_union = np.zeros((H, W), bool)
        for i in getattr(P, "child_ids", []):
            act = child_activity_map(children[i], H, W, eps=eps)
            if act is not None:
                active_union |= dilate_bool(act, r=r, periodic=periodic)
        grow_score *= active_union.astype(np.float32)

        # overlap count gate
        min_kids_ov = int(getattr(config, "parent_grow_min_kids", 2))
        cnt = np.zeros((H, W), np.int32)
        for i in getattr(P, "child_ids", []):
            cm = (np.asarray(children[i].mask) > eps)
            cnt += dilate_bool(cm, r=r, periodic=periodic).astype(np.int32)

        not_overlap = (cnt < max(1, min_kids_ov))
        grow_score[not_overlap] = 0.0
        if min_kids_ov > 1:
            grow_score *= np.clip(cnt.astype(np.float32) / float(min_kids_ov), 0.0, 1.0)

        if getattr(config, "parent_shrink_nooverlap_boost", True):
            shrink_floor = float(getattr(config, "parent_shrink_floor", 0.6))
            shrink_score[not_overlap] = np.maximum(shrink_score[not_overlap], shrink_floor)

        # restrict to bands, update
        g = np.zeros_like(mask); g[band_out] = grow_score[band_out]
        s = np.zeros_like(mask); s[band_in]  = shrink_score[band_in]
        dmask = eta_grow * g - eta_shrink * s

        for _ in range(int(blur_iters)):
            dmask = gauss3(dmask)
        dmask = np.clip(dmask, -delta_cap, delta_cap)

        new_mask = np.clip(mask + dmask, 0.0, 1.0)

        # soft area constraints
        area = int((new_mask > 1e-2).sum())
        if area < min_area:
            new_mask = np.clip(new_mask + 0.25 * band_out.astype(new_mask.dtype), 0.0, 1.0)
        if (max_area is not None) and area > max_area:
            over = new_mask > mask
            new_mask[over] = mask[over] + 0.5 * (new_mask[over] - mask[over])

        P.mask = new_mask.astype(np.float32)

        # debug
        grow_pos = int((grow_score[band_out] > 0).sum())
        shrink_pos = int((shrink_score[band_in] > 0).sum())
        print(f"[P{P.id}] band_out={int(band_out.sum())} grow_pos={grow_pos} "
              f"shrink_pos={shrink_pos} Δsum={(float((new_mask - mask).sum())):.3f}")



