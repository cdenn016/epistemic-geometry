from dataclasses import dataclass, field
from typing import Any, Dict, List, Tuple, Optional
import numpy as np


@dataclass
class Agent:
    id: int
    center: Tuple[int, ...]
    radius: float
    mask: np.ndarray

    # Lie fields (SO(3) algebra, last dim = 3)
    phi: np.ndarray
    phi_model: np.ndarray

    # Belief/model fields (μ/Σ)
    mu_q_field: np.ndarray            # (..., Kq)
    sigma_q_field: np.ndarray         # (..., Kq, Kq)
    mu_p_field: np.ndarray            # (..., Kp)
    sigma_p_field: np.ndarray         # (..., Kp, Kp)

    # Inverses (filled in preprocess)
    sigma_q_inv: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    sigma_p_inv: Optional[np.ndarray] = field(default=None, init=False, repr=False)

    # Neighborhood & logging
    neighbors: List[Dict[str, Any]] = field(default_factory=list)
    metrics_log: List[Dict[str, Any]] = field(default_factory=list)

    # Gradient caches
    grad_mu_q: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    grad_sigma_q: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    grad_mu_p: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    grad_sigma_p: Optional[np.ndarray] = field(default=None, init=False, repr=False)

    # Generators (set once and reused)
    generators_q: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    generators_p: Optional[np.ndarray] = field(default=None, init=False, repr=False)

    # exp(φ) caches (filled in preprocess; shape (..., K, K))
    _exp_phi: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    _exp_neg_phi: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    _exp_phi_model: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    _exp_neg_phi_model: Optional[np.ndarray] = field(default=None, init=False, repr=False)

    # Inter-agent transport caches
    Omega_cache: Dict[str, Any] = field(default_factory=dict, init=False, repr=False)
    Omega_tilde_cache: Dict[str, Any] = field(default_factory=dict, init=False, repr=False)

    # Bundle morphisms (optional)
    bundle_morphism_q_to_p: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    bundle_morphism_p_to_q: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    Phi_0: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    Phi_tilde_0: Optional[np.ndarray] = field(default=None, init=False, repr=False)

    # φ/φ̃ grads (field-shaped)
    grad_phi: np.ndarray = field(init=False, repr=False)
    grad_phi_tilde: np.ndarray = field(init=False, repr=False)

    # Morphism grads (optional)
    grad_Phi: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    grad_Phi_tilde: Optional[np.ndarray] = field(default=None, init=False, repr=False)

    # Fisher caches for φ/φ̃ or morphisms
    inverse_fisher_phi: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    inverse_fisher_phi_model: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    inverse_fisher_Phi: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    inverse_fisher_Phi_tilde: Optional[np.ndarray] = field(default=None, init=False, repr=False)

    # NEW: adaptive-η & KL caches
    _cond_proxy_q: Optional[float] = field(default=None, init=False, repr=False)
    _cond_proxy_p: Optional[float] = field(default=None, init=False, repr=False)
    _eta_phi_prev: Optional[float] = field(default=None, init=False, repr=False)
    _eta_phi_m_prev: Optional[float] = field(default=None, init=False, repr=False)
    cached_alignment_kl: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    cached_model_alignment_kl: Optional[np.ndarray] = field(default=None, init=False, repr=False)

    # Cross-scale metadata
    level: int = 0
    parent_ids: List[int] = field(default_factory=list)
    child_ids: List[int] = field(default_factory=list)

    # Legacy single Λ (kept as shims for older code)
    Lambda_up_q: Optional[np.ndarray] = field(default=None, init=False, repr=False)  # (Kq,Kq)
    Lambda_dn_q: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    Lambda_up_p: Optional[np.ndarray] = field(default=None, init=False, repr=False)  # (Kp,Kp)
    Lambda_dn_p: Optional[np.ndarray] = field(default=None, init=False, repr=False)

    # Authoritative per-parent Λ fields (field-shaped per pixel): (H,W,K,K)
    Lambda_up_q_map: Dict[int, np.ndarray] = field(default_factory=dict, init=False, repr=False)
    Lambda_dn_q_map: Dict[int, np.ndarray] = field(default_factory=dict, init=False, repr=False)
    Lambda_up_p_map: Dict[int, np.ndarray] = field(default_factory=dict, init=False, repr=False)
    Lambda_dn_p_map: Dict[int, np.ndarray] = field(default_factory=dict, init=False, repr=False)

    # Optional global (coarse) Λ per parent id (Log–Euclidean mean): (K,K)
    Lambda_up_q_global: Dict[int, np.ndarray] = field(default_factory=dict, init=False, repr=False)
    Lambda_up_p_global: Dict[int, np.ndarray] = field(default_factory=dict, init=False, repr=False)

    # (optional) gradient buffers for Λ
    grad_Lambda_up_q: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    grad_Lambda_dn_q: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    grad_Lambda_up_p: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    grad_Lambda_dn_p: Optional[np.ndarray] = field(default=None, init=False, repr=False)

    # Cross-scale inference maps (Θ) — keep as placeholders if you want later
    Theta_up: Optional[np.ndarray] = field(default=None, init=False, repr=False)   # (Kp, Kq)
    Theta_dn: Optional[np.ndarray] = field(default=None, init=False, repr=False)   # (Kq, Kp)
    grad_Theta_up: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    grad_Theta_dn: Optional[np.ndarray] = field(default=None, init=False, repr=False)

    def __post_init__(self):
        self.grad_phi = np.zeros_like(self.phi)
        self.grad_phi_tilde = np.zeros_like(self.phi_model)
        if self.bundle_morphism_q_to_p is not None:
            self.grad_Phi = np.zeros_like(self.bundle_morphism_q_to_p)
        if self.bundle_morphism_p_to_q is not None:
            self.grad_Phi_tilde = np.zeros_like(self.bundle_morphism_p_to_q)

    @property
    def grid_shape(self) -> Tuple[int, ...]:
        return self.mu_q_field.shape[:-1]

    @property
    def Omega(self) -> np.ndarray:
        K = self.mu_q_field.shape[-1]
        return self._exp_phi.reshape(*self.grid_shape, K, K)

    @property
    def Omega_inv(self) -> np.ndarray:
        K = self.mu_q_field.shape[-1]
        return self._exp_neg_phi.reshape(*self.grid_shape, K, K)

    @property
    def Omega_model(self) -> np.ndarray:
        K = self.mu_p_field.shape[-1]
        return self._exp_phi_model.reshape(*self.grid_shape, K, K)

    @property
    def Omega_model_inv(self) -> np.ndarray:
        K = self.mu_p_field.shape[-1]
        return self._exp_neg_phi_model.reshape(*self.grid_shape, K, K)

    def log_metrics(self, step: int, stats: Dict[str, Any]) -> None:
        import copy
        self.metrics_log.append(copy.deepcopy({'step': step, **stats}))

    def clear_omega_cache(self) -> None:
        self._exp_phi = None
        self._exp_neg_phi = None
        self._exp_phi_model = None
        self._exp_neg_phi_model = None
        self.Omega_cache.clear()
        self.Omega_tilde_cache.clear()

    def clear_diagnostics(self) -> None:
        # keep placeholders if you write to these elsewhere
        self.fisher_I = None
        self.pull_M_vis = None
        self.pull_Delta = None
        self.pull_M_dark = None
        self.spatial_G = None

    def clear_fisher_caches(self) -> None:
        self.inverse_fisher_phi = None
        self.inverse_fisher_phi_model = None
        self.inverse_fisher_Phi = None
        self.inverse_fisher_Phi_tilde = None

    def ensure_crossscale_defaults(self, Kq: int, Kp: int) -> None:
        if self.Lambda_up_q is None:
            self.Lambda_up_q = np.eye(Kq)
            self.Lambda_dn_q = np.eye(Kq)
        if self.Lambda_up_p is None:
            self.Lambda_up_p = np.eye(Kp)
            self.Lambda_dn_p = np.eye(Kp)
        if self.Theta_up is None:
            self.Theta_up = np.zeros((Kp, Kq))
            self.Theta_dn = np.zeros((Kq, Kp))

    def ensure_crossscale_grad_buffers(self) -> None:
        if self.Lambda_up_q is not None and self.grad_Lambda_up_q is None:
            self.grad_Lambda_up_q = np.zeros_like(self.Lambda_up_q)
            self.grad_Lambda_dn_q = np.zeros_like(self.Lambda_dn_q)
        if self.Lambda_up_p is not None and self.grad_Lambda_up_p is None:
            self.grad_Lambda_up_p = np.zeros_like(self.Lambda_up_p)
            self.grad_Lambda_dn_p = np.zeros_like(self.Lambda_dn_p)
        if self.Theta_up is not None and self.grad_Theta_up is None:
            self.grad_Theta_up = np.zeros_like(self.Theta_up)
            self.grad_Theta_dn = np.zeros_like(self.Theta_dn)

    def clear_crossscale_maps(self) -> None:
        self.Lambda_up_q = None
        self.Lambda_dn_q = None
        self.Lambda_up_p = None
        self.Lambda_dn_p = None
        self.grad_Lambda_up_q = None
        self.grad_Lambda_dn_q = None
        self.grad_Lambda_up_p = None
        self.grad_Lambda_dn_p = None
        self.Lambda_up_q_map.clear()
        self.Lambda_dn_q_map.clear()
        self.Lambda_up_p_map.clear()
        self.Lambda_dn_p_map.clear()
        self.Lambda_up_q_global.clear()
        self.Lambda_up_p_global.clear()

    def build_lambda_q_to(self, parent: "Agent", parent_id: Optional[int] = None) -> np.ndarray:
        """
        Gauge-covariant cross-scale map for the belief fiber:
            Λ_{c→P}^q(c) = exp(φ_P(c)) · exp(−φ_c(c))
            Λ_{P→c}^q(c) = exp(φ_c(c)) · exp(−φ_P(c))
        Uses cached exponentials; no pseudoinverses. Stores per-parent fields and a global mean.
        """
        E_c = getattr(self, "_exp_phi", None)
        E_c_inv = getattr(self, "_exp_neg_phi", None)
        E_P = getattr(parent, "_exp_phi", None)
        E_P_inv = getattr(parent, "_exp_neg_phi", None)
        if E_c is None or E_c_inv is None or E_P is None or E_P_inv is None:
            raise RuntimeError("Missing exp(phi) caches; build exponentials before build_lambda_q_to().")

        # Field-shaped Λ (H,W,Kq,Kq)
        Lambda_up_field = E_P @ E_c_inv
        Lambda_dn_field = E_c @ E_P_inv

        pid = parent_id if parent_id is not None else parent.id
        self.Lambda_up_q_map[pid] = Lambda_up_field
        self.Lambda_dn_q_map[pid] = Lambda_dn_field

        # Back-compat shim for "primary" parent
        if self.primary_parent() == pid:
            # If you want a single global matrix, compute a masked Log–Euclidean mean.
            m = (self.mask > 0) & (parent.mask > 0)
            if m.any():
                try:
                    import scipy.linalg as la
                    L = Lambda_up_field[m]  # (M, K, K)
                    logs = np.stack([la.logm(X) for X in L], axis=0)
                    self.Lambda_up_q = la.expm(logs.mean(axis=0))
                    # dn as exact inverse in the group sense (transpose only if orthogonal reps).
                    self.Lambda_dn_q = np.linalg.inv(self.Lambda_up_q)
                    self.Lambda_up_q_global[pid] = self.Lambda_up_q.copy()
                except Exception:
                    # Fallback: simple arithmetic mean (not group-correct, but stable)
                    self.Lambda_up_q = np.mean(Lambda_up_field[m], axis=0)
                    self.Lambda_dn_q = np.linalg.pinv(self.Lambda_up_q)

        return self.Lambda_up_q_map[pid]

    def build_lambda_p_to(self, parent: "Agent", parent_id: Optional[int] = None) -> np.ndarray:
        """
        Gauge-covariant cross-scale map for the model fiber:
            Λ_{c→P}^p(c) = exp(φ̃_P(c)) · exp(−φ̃_c(c))
            Λ_{P→c}^p(c) = exp(φ̃_c(c)) · exp(−φ̃_P(c))
        Uses cached exponentials; no pseudoinverses. Stores per-parent fields and a global mean.
        """
        E_c = getattr(self, "_exp_phi_model", None)
        E_c_inv = getattr(self, "_exp_neg_phi_model", None)
        E_P = getattr(parent, "_exp_phi_model", None)
        E_P_inv = getattr(parent, "_exp_neg_phi_model", None)
        if E_c is None or E_c_inv is None or E_P is None or E_P_inv is None:
            raise RuntimeError("Missing exp(phi_tilde) caches; build exponentials before build_lambda_p_to().")

        # Field-shaped Λ (H,W,Kp,Kp)
        Lambda_up_field = E_P @ E_c_inv
        Lambda_dn_field = E_c @ E_P_inv

        pid = parent_id if parent_id is not None else parent.id
        self.Lambda_up_p_map[pid] = Lambda_up_field
        self.Lambda_dn_p_map[pid] = Lambda_dn_field

        # Back-compat shim for "primary" parent
        if self.primary_parent() == pid:
            m = (self.mask > 0) & (parent.mask > 0)
            if m.any():
                try:
                    import scipy.linalg as la
                    L = Lambda_up_field[m]
                    logs = np.stack([la.logm(X) for X in L], axis=0)
                    self.Lambda_up_p = la.expm(logs.mean(axis=0))
                    self.Lambda_dn_p = np.linalg.inv(self.Lambda_up_p)
                    self.Lambda_up_p_global[pid] = self.Lambda_up_p.copy()
                except Exception:
                    self.Lambda_up_p = np.mean(Lambda_up_field[m], axis=0)
                    self.Lambda_dn_p = np.linalg.pinv(self.Lambda_up_p)

        return self.Lambda_up_p_map[pid]

    def primary_parent(self) -> Optional[int]:
        """Return the first parent id if present, else None."""
        pids = getattr(self, "parent_ids", None)
        return pids[0] if pids else None
