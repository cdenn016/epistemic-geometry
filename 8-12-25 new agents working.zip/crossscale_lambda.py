# crossscale_lambda.py
# Clean, gauge-covariant cross-scale helpers (current architecture)

from __future__ import annotations
from typing import Sequence, Dict, Optional, Tuple, List
import numpy as np

import config
from agent_schema import Agent


# ---------- minimal compat: identity seeds (rarely needed now) ----------------

def attach_crossscale_fields(agent: Agent, Kq: int, Kp: int) -> None:
    """
    Legacy helper. Prefer creating agents at level-0 with no Λ.
    This simply ensures single-matrix Λ slots/Θ exist (for old code paths).
    """
    agent.level = getattr(agent, "level", 0)
    agent.parent_ids = getattr(agent, "parent_ids", []) or []
    agent.child_ids  = getattr(agent, "child_ids", []) or []
    if getattr(agent, "Lambda_up_q", None) is None:
        agent.Lambda_up_q = np.eye(Kq)
        agent.Lambda_dn_q = np.eye(Kq)
    if getattr(agent, "Lambda_up_p", None) is None:
        agent.Lambda_up_p = np.eye(Kp)
        agent.Lambda_dn_p = np.eye(Kp)
    if getattr(agent, "Theta_up", None) is None:
        agent.Theta_up = np.zeros((Kp, Kq))
        agent.Theta_dn = np.zeros((Kq, Kp))


# ---------- main: build Λ from current φ/φ̃ caches (no pinvs) -----------------

def _require_exp_caches(a: Agent, label: str) -> None:
    if a._exp_phi is None or a._exp_neg_phi is None:
        raise RuntimeError(f"{label}: exp(phi) caches missing. Call preprocess_all_agents() first.")
    if a._exp_phi_model is None or a._exp_neg_phi_model is None:
        raise RuntimeError(f"{label}: exp(phi_model) caches missing. Call preprocess_all_agents() first.")

def build_all_lambdas_from_links(agents: Sequence[Agent]) -> None:
    """
    Rebuild Λ maps for every existing child→parent link (per-parent maps).
    Requires exp(φ)/exp(−φ) caches to be current.
    """
    id2agent: Dict[int, Agent] = {a.id: a for a in agents}
    for ch in agents:
        if not getattr(ch, "parent_ids", []):
            continue
        _require_exp_caches(ch, f"child {ch.id}")
        for pid in ch.parent_ids:
            if pid not in id2agent:
                continue
            P = id2agent[pid]
            _require_exp_caches(P, f"parent {P.id}")
            # q-bundle
            ch.Lambda_up_q_map[pid] = np.einsum("...ik,...kj->...ij", P._exp_phi, ch._exp_neg_phi)
            ch.Lambda_dn_q_map[pid] = np.einsum("...ik,...kj->...ij", ch._exp_phi, P._exp_neg_phi)
            # p-bundle
            ch.Lambda_up_p_map[pid] = np.einsum("...ik,...kj->...ij", P._exp_phi_model, ch._exp_neg_phi_model)
            ch.Lambda_dn_p_map[pid] = np.einsum("...ik,...kj->...ij", ch._exp_phi_model, P._exp_neg_phi_model)

            # optional: update legacy single Λ for the primary parent
            if ch.primary_parent() == pid:
                m = (ch.mask > 0) & (P.mask > 0)
                if m.any():
                    Lu_q = ch.Lambda_up_q_map[pid][m]
                    ch.Lambda_up_q = Lu_q.mean(axis=0)
                    ch.Lambda_dn_q = np.linalg.pinv(ch.Lambda_up_q)
                    Lu_p = ch.Lambda_up_p_map[pid][m]
                    ch.Lambda_up_p = Lu_p.mean(axis=0)
                    ch.Lambda_dn_p = np.linalg.pinv(ch.Lambda_up_p)


def build_all_lambdas_from_labels(children: Sequence[Agent],
                                  parents: Sequence[Agent],
                                  labels: np.ndarray) -> None:
    """
    Legacy convenience: same as above but takes (children, parents, labels).
    Useful for batch/offline runs where labels[i] gives parent index.
    """
    for i, ch in enumerate(children):
        pid_local = int(labels[i]) if i < len(labels) else -1
        if pid_local < 0:
            continue
        P = parents[pid_local]
        _require_exp_caches(ch, f"child {ch.id}")
        _require_exp_caches(P, f"parent {P.id}")
        # fill per-parent maps
        ch.Lambda_up_q_map[P.id] = np.einsum("...ik,...kj->...ij", P._exp_phi, ch._exp_neg_phi)
        ch.Lambda_dn_q_map[P.id] = np.einsum("...ik,...kj->...ij", ch._exp_phi, P._exp_neg_phi)
        ch.Lambda_up_p_map[P.id] = np.einsum("...ik,...kj->...ij", P._exp_phi_model, ch._exp_neg_phi_model)
        ch.Lambda_dn_p_map[P.id] = np.einsum("...ik,...kj->...ij", ch._exp_phi_model, P._exp_neg_phi_model)


# ---------- sanity checks -----------------------------------------------------

def validate_lambdas(agents: Sequence[Agent], atol: float = 1e-5, sample: int = 64) -> None:
    """
    Optional sanity check:
      1) legacy single Λ: ||Λ Λ̃ - I|| small
      2) per-parent field Λ: check Λ_up @ Λ_dn ≈ I at a random subset of pixels
    Prints warnings; does not raise.
    """
    rng = np.random.default_rng(123)
    for ch in agents:
        # legacy single Λ
        if ch.Lambda_up_q is not None and ch.Lambda_dn_q is not None:
            nrm = np.linalg.norm(ch.Lambda_up_q @ ch.Lambda_dn_q - np.eye(ch.Lambda_up_q.shape[0]))
            if nrm > atol:
                print(f"[Λq WARN child {ch.id}] ||ΛΛ̃-I|| = {nrm:.2e}")
        if ch.Lambda_up_p is not None and ch.Lambda_dn_p is not None:
            nrm = np.linalg.norm(ch.Lambda_up_p @ ch.Lambda_dn_p - np.eye(ch.Lambda_up_p.shape[0]))
            if nrm > atol:
                print(f"[Λp WARN child {ch.id}] ||ΛΛ̃-I|| = {nrm:.2e}")

        # field-shaped maps (per-parent)
        for pid, Lu in ch.Lambda_up_q_map.items():
            Ld = ch.Lambda_dn_q_map.get(pid, None)
            if Ld is None:
                continue
            H, W = Lu.shape[:2]
            idx = rng.integers(0, H*W, size=min(sample, H*W))
            hh, ww = np.unravel_index(idx, (H, W))
            errs = []
            I = np.eye(Lu.shape[-1])
            for h, w in zip(hh, ww):
                errs.append(np.linalg.norm(Lu[h, w] @ Ld[h, w] - I))
            if np.mean(errs) > atol:
                print(f"[Λq field WARN child {ch.id}→{pid}] mean ||ΛΛ̃-I|| = {np.mean(errs):.2e}")

        for pid, Lu in ch.Lambda_up_p_map.items():
            Ld = ch.Lambda_dn_p_map.get(pid, None)
            if Ld is None:
                continue
            H, W = Lu.shape[:2]
            idx = rng.integers(0, H*W, size=min(sample, H*W))
            hh, ww = np.unravel_index(idx, (H, W))
            errs = []
            I = np.eye(Lu.shape[-1])
            for h, w in zip(hh, ww):
                errs.append(np.linalg.norm(Lu[h, w] @ Ld[h, w] - I))
            if np.mean(errs) > atol:
                print(f"[Λp field WARN child {ch.id}→{pid}] mean ||ΛΛ̃-I|| = {np.mean(errs):.2e}")


# ---------- deprecated shims (safe to delete later) --------------------------

def ensure_exp_caches(_agents: Sequence[Agent]) -> None:
    """
    DEPRECATED: Use preprocess_all_agents(...). This is now a no-op shim that
    only checks presence and throws a helpful error if missing.
    """
    for a in _agents:
        if a._exp_phi is None or a._exp_neg_phi is None or a._exp_phi_model is None or a._exp_neg_phi_model is None:
            raise RuntimeError("exp(φ)/exp(−φ) caches missing. Call preprocess_all_agents() before building Λ.")

def _prepare_xscale_context(*args, **kwargs):
    """
    DEPRECATED batch path. Use runtime_ctx + detector_tick + spawn_or_update_parents
    and then preprocess_all_agents(...) + build_all_lambdas_from_links(...).
    """
    raise RuntimeError("Deprecated: use online emergence pipeline (detector_tick + spawn_or_update_parents).")

def rebuild_downscale_maps(*_args, **_kwargs) -> Tuple[int, int]:
    """
    DEPRECATED: replaced by build_all_lambdas_from_links(...).
    Kept to avoid import errors in old call sites.
    """
    return (0, 0)
