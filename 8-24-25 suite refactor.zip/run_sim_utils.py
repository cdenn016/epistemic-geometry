# -*- coding: utf-8 -*-
"""
Created on Tue Aug 12 20:36:43 2025

@author: chris and christine
"""
import os, sys
ROOT = os.path.dirname(os.path.abspath(__file__))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

# run_sim_utils.py
import time, shutil, pickle
import numpy as np
import core.config as config

from core.config_utils import set_config_from_params  # re-exported for __main__ use
from core.get_generators import get_generators

from core.agent_initialization import initialize_agents, initialize_agent_gradients
from runtime_context import ensure_runtime_defaults
from generalized_diagnostics_metrics import log_all_metrics, dump_snapshot_npz

from data.viz_parent_masks import save_parent_mask_frame, save_alignment_vs_parents, plot_parent_masks_grid
from updates.update_rules import synchronous_step
from data.viz_parent_masks import save_parent_mask_delta
from typing import Dict, List
from generalized_diagnostics_metrics import log_all_metrics  # local import to avoid cycles
import os, time

from pathlib import Path

from transport.transport_cache import Lambda_up, Lambda_dn  # optional; may be absent
from generalized_diagnostics_metrics import (
    compute_crossscale_kl_q_single, compute_crossscale_kl_p_single
)
import os
from generalized_diagnostics_metrics import dump_snapshot_npz
# ------------------------------- Logging defaults ----------------------------

LOGGING_DEFAULTS = dict(
    # --- core scalar metrics ---
    enable_scalar=True,
    print_total_energy=True,
    normalize_by_support=True,   # used by per-agent logger

    # --- optional extras (tiny) ---
    print_crossscale=True,       # child→parent same-fiber KL summary
    log_link_norms=True,         # Λ up/dn + bundle morphism Frobenius norms
    log_typical_grads=True,     # per-step grad norms for a “typical” agent
    typical_grad_agent_id=1,  # if None, auto-pick largest support

    # --- field snapshots ---
    enable_fields=True,         # off by default to keep runs lean
    fields_every=1,              # cadence when enabled
    full_field_outdir="fields",
    snapshot_mode="full",     # "crucial" | "full"
    fp16_snapshot=True,          # smaller files
    compute_alignment=True,     # heavy → off by default
    compute_curvature=True,     # heavy → off by default

    # --- lightweight mask snapshots (parents/children) ---
    parent_snapshot_every=1,     # 0 = disabled
    parent_snapshot_dir="parents",
    child_snapshot_every=1,      # 0 = disabled
    child_snapshot_dir="children",
    snapshot_include_levels="both",

    # --- record shape ---
    store_levels=True,          # include per-level breakdown in record (can be larger)

    # --- schema/version tag for downstream tools ---
    schema_version="v3",
)




def load_checkpoint(outdir):
    """
    Load latest checkpoint.pkl or fallback to latest step_XXXX.pkl in outdir.
    Returns (agents, filename) or (None, None) if none found.
    """
    ckpt_path = os.path.join(outdir, "checkpoint.pkl")
    if os.path.exists(ckpt_path):
        with open(ckpt_path, "rb") as f:
            return pickle.load(f), "checkpoint.pkl"

    step_files = sorted(
        [f for f in os.listdir(outdir) if f.startswith("step_") and f.endswith(".pkl")]
    )
    if not step_files:
        return None, None

    last_step = step_files[-1]
    with open(os.path.join(outdir, last_step), "rb") as f:
        return pickle.load(f), last_step


def find_resume_step(outdir):
    """
    Determine the next step to resume from based on existing saved steps.
    Returns 0 if none found.
    """
    step_files = sorted(
        [f for f in os.listdir(outdir) if f.startswith("step_") and f.endswith(".pkl")]
    )
    if not step_files:
        return 0
    last_step = step_files[-1]
    return int(last_step.replace("step_", "").replace(".pkl", "")) + 1




def merge_logging_cfg(params_or_cfg):
    cfg = {}
    if hasattr(params_or_cfg, "get"):       # dict-like
        cfg = params_or_cfg.get("logging", {}) or {}
    elif hasattr(params_or_cfg, "__dict__"): # module-like (config)
        cfg = getattr(params_or_cfg, "logging", {}) or {}
    out = dict(LOGGING_DEFAULTS)
    out.update(cfg)
    return out


# ------------------------------ Generator prep ------------------------------

def prepare_generators(params):
    Gq = params.get("generators_q")
    Gp = params.get("generators_p")
    if Gq is None:
        Gq, _ = get_generators(config.group_name, config.K_q, return_meta=True)
        params["generators_q"] = Gq
    if Gp is None:
        Gp, _ = get_generators(config.group_name, config.K_p, return_meta=True)
        params["generators_p"] = Gp
    return Gq, Gp


# -------------------------- Init / resume helpers ---------------------------

def initialize_or_resume(outdir, resume, params, clear_agent_logs=True):
    """Return (agents, step_start)."""
    if resume:
        agents, _ = load_checkpoint(outdir)
        step_start = find_resume_step(outdir)
    else:
        agents = initialize_agents(
            seed=getattr(config, "seed", None),
            domain_size=config.domain_size,
            N=config.N,
            K_q=config.K_q,
            K_p=config.K_p,
            lie_algebra_dim=3,
            visualize=False,
            fixed_location=getattr(config, "fixed_location", False),  # <-- config toggle
        )
        step_start = 0
        for A in agents:
            initialize_agent_gradients(A, config)
        if clear_agent_logs:
            for A in agents:
                if hasattr(A, "metrics_log"):
                    A.metrics_log.clear()
    return agents, step_start



def ensure_runtime(params):
    ctx = ensure_runtime_defaults(params.get("runtime_ctx", None))
    ctx.mount_level(1)  # legacy lvl-1 view
    return ctx



def _log_metrics_by_levels(runtime_ctx, *, children_level0: List, step: int, params: dict, n_jobs: int) -> Dict:
    """
    Compute scalar metrics separately for:
      - level 0 (children_level0 list)
      - each parent level L present in runtime_ctx.parents_by_level
    Returns a dict: {"levels": {0: m0, 1: m1, 2: m2, ...}, "flat": m0} where "flat" preserves legacy total.
    """
    

    out = {"levels": {}}

    # lvl-0 (children)
    m0 = log_all_metrics(children_level0, step=step, params=params, n_jobs=n_jobs)
    out["levels"][0] = m0
    out["flat"] = m0  # preserve old behavior for downstream consumers

    # parents per level
    parents_levels = getattr(runtime_ctx, "parents_by_level", {}) or {}
    for L, bucket in sorted(parents_levels.items()):
        if not bucket:
            continue
        parents_L = list(bucket.values())
        if not parents_L:
            continue
        mL = log_all_metrics(parents_L, step=step, params=params, n_jobs=n_jobs)
        out["levels"][int(L)] = mL

    return out




# --------------------------- Per-step side effects --------------------------
# =========================
# logging / viz helpers
# =========================



# =========================
# slim main entry
# =========================

def log_and_viz_after_step(runtime_ctx, agents, step, outdir, params, logcfg,
                           parent_metrics, metric_log, num_cores):
    """
    Streamlined per-step logging + lightweight viz/snapshots.

    logcfg keys (optional):
      - enable_scalar: bool (default True)
      - print_total_energy: bool (default True)
      - print_crossscale: bool (default True)
      - log_link_norms: bool (default True)
      - log_typical_grads: bool (default False)
      - typical_grad_agent_id: int|None
      - enable_fields: bool (default False)
      - fields_every: int (default 1)
      - full_field_outdir: str (default "fields")
      - snapshot_mode: "crucial"|"full" (default "crucial")
      - fp16_snapshot: bool (default True)
      - parent_snapshot_every: int (default 0)
      - parent_snapshot_dir: str (default "parents")
      - child_snapshot_every: int (default 0)
      - child_snapshot_dir: str (default "children")
    """
    # 1) tiny mask snapshots (parents/children)
    write_mask_snapshots(runtime_ctx, agents, step, outdir, logcfg)

    # 2) quick overlays (best-effort)
    try:
        save_parent_mask_delta(runtime_ctx, step, outdir)
        save_parent_mask_frame(runtime_ctx, step, outdir, draw_per_parent=True)
    except Exception:
        pass

    # 3) scalar metrics (lean)
    if bool(logcfg.get("enable_scalar", True)):
        t1 = time.perf_counter()

        # Level-aware metrics (external function you already have)
        levels_metrics = _log_metrics_by_levels(
            runtime_ctx, children_level0=agents, step=step, params=params, n_jobs=num_cores
        ) or {}
        flat_rec   = levels_metrics.get("flat")   or {}
        levels_map = levels_metrics.get("levels") or {}

        # keep only core energies; default to 0.0 if missing
        keep_keys = ("e_self","e_feedback","e_align","e_mod_align","e_curv","e_curv_mod","e_mass","e_mass_mod")
        rec = {k: float(flat_rec.get(k, 0.0)) for k in keep_keys}
        rec["total_energy"] = float(flat_rec.get("total_energy", sum(rec.values())))
        rec["step"] = int(step)

        # (1) Λ + morphism norms (small)
        if bool(logcfg.get("log_link_norms", True)):
            Ps = collect_all_parents(runtime_ctx)
            rec["parent_link_norms"] = parent_link_and_morphism_norms(runtime_ctx, Ps, agents)

        # (2) typical agent grad norms
        if bool(logcfg.get("log_typical_grads", False)):
            tid = logcfg.get("typical_grad_agent_id")
            if tid is None:
                # choose the largest-support agent
                best_id, best_px = None, -1
                for a in agents:
                    m = np.asarray(getattr(a, "mask", 0.0), np.float32) > float(getattr(config, "parent_area_threshold", 0.01))
                    px = int(m.sum())
                    if px > best_px:
                        best_px = px
                        best_id = int(getattr(a, "id", -1))
                tid = best_id
            if tid is not None:
                sel = next((a for a in agents if int(getattr(a, "id", -999)) == int(tid)), None)
                if sel is not None:
                    gq = getattr(sel, "grad_phi", None)
                    gp = getattr(sel, "grad_phi_tilde", None)
                    rec["typical_grad_agent"] = int(tid)
                    rec["grad_phi_norm"] = float(np.linalg.norm(gq)) if gq is not None else np.nan
                    rec["grad_phi_model_norm"] = float(np.linalg.norm(gp)) if gp is not None else np.nan

        # (3) cross-scale KL (same fiber)
        if bool(logcfg.get("print_crossscale", True)):
            Ps = collect_all_parents(runtime_ctx)
            xs = crossscale_energy_totals(runtime_ctx, agents, Ps)
            rec.update(xs)
            # explicit aliases
            rec["xscale_qq_mean"] = rec.get("xscale_q_mean")
            rec["xscale_pp_mean"] = rec.get("xscale_p_mean")
            rec["xscale_qq_sum"]  = rec.get("xscale_q_sum")
            rec["xscale_pp_sum"]  = rec.get("xscale_p_sum")

        # timings + append
        rec["compute_ms"] = int((time.perf_counter() - t1) * 1000)
        if bool(logcfg.get("store_levels", False)):
            rec["levels"] = levels_map  # optional, can be large
        metric_log.append(rec)

        # pretty print to console
        if bool(logcfg.get("print_total_energy", True)):
            print_energy_totals(step, levels_map, flat_rec, rec, logcfg)

    # 4) field snapshots (crucial vs full)
    dump_fields_if_needed(runtime_ctx, agents, step, outdir, params, logcfg)








# -------- parents/children collection --------

def collect_all_parents(ctx):
    """Flatten parents across levels; fallback to legacy dict."""
    pbL = getattr(ctx, "parents_by_level", None)
    if isinstance(pbL, dict) and pbL:
        out = []
        for d in pbL.values():
            out.extend(list(d.values()) if isinstance(d, dict) else list(d))
        return out
    return list((getattr(ctx, "parents_by_region", {}) or {}).values())

# -------- compact NPZ snapshots (masks only; tiny) --------

def snapshot_parents_npz_simple(parents, save_path):
    """
    Minimal parent snapshot:
      - ids: (P,)
      - masks: (P,H,W) if same-shape; else masks_obj: array(object)
    """
    ids, masks = [], []
    for idx, P in enumerate(parents or ()):
        ids.append(int(getattr(P, "id", idx)))
        masks.append(np.asarray(getattr(P, "mask", 0.0), np.float32))
    out = {"ids": np.asarray(ids, dtype=np.int32)}
    shapes = {m.shape for m in masks if m is not None}
    if len(shapes) == 1 and len(masks) > 0:
        out["masks"] = np.stack(masks, axis=0)
    else:
        out["masks_obj"] = np.array(masks, dtype=object)
    os.makedirs(os.path.dirname(save_path), exist_ok=True)
    np.savez_compressed(save_path, **out)

def snapshot_children_npz_simple(children, save_path):
    """Minimal child snapshot: ids + masks."""
    ids, masks = [], []
    for idx, C in enumerate(children or ()):
        ids.append(int(getattr(C, "id", idx)))
        masks.append(np.asarray(getattr(C, "mask", 0.0), np.float32))
    out = {"ids": np.asarray(ids, dtype=np.int32)}
    shapes = {m.shape for m in masks if m is not None}
    if len(shapes) == 1 and len(masks) > 0:
        out["masks"] = np.stack(masks, axis=0)
    else:
        out["masks_obj"] = np.array(masks, dtype=object)
    os.makedirs(os.path.dirname(save_path), exist_ok=True)
    np.savez_compressed(save_path, **out)

def write_mask_snapshots(runtime_ctx, agents, step, outdir, logcfg):
    """Handles parent/child mask-only snapshots, throttled by logcfg."""
    snap_every  = int(logcfg.get("parent_snapshot_every", getattr(config, "parent_snapshot_every", 0)) or 0)
    snap_dir    = logcfg.get("parent_snapshot_dir", getattr(config, "parent_snapshot_dir", "parents"))
    child_every = int(logcfg.get("child_snapshot_every", getattr(config, "child_snapshot_every", 0)) or 0)
    child_dir   = logcfg.get("child_snapshot_dir", getattr(config, "child_snapshot_dir", "children"))

    if snap_every > 0 and (step % snap_every) == 0:
        Ps = collect_all_parents(runtime_ctx)
        if Ps:
            pdir = os.path.join(outdir, snap_dir); os.makedirs(pdir, exist_ok=True)
            try:
                snapshot_parents_npz_simple(Ps, os.path.join(pdir, f"parents_step_{step:04d}.npz"))
            except Exception as e:
                print(f"[SNAP][PARENTS][ERROR] step {step}: {e}")

    if child_every > 0 and (step % child_every) == 0 and agents:
        cdir = os.path.join(outdir, child_dir); os.makedirs(cdir, exist_ok=True)
        try:
            snapshot_children_npz_simple(agents, os.path.join(cdir, f"children_step_{step:04d}.npz"))
        except Exception as e:
            print(f"[SNAP][CHILDREN][ERROR] step {step}: {e}")

# -------- Λ / morphism norms (tiny tables) --------

def parent_link_and_morphism_norms(ctx, parents, agents, *, thr=0.30):
    """
    Per-parent norms for animation/validation:
      - Frobenius mean of bundle morphisms Φ, Φ̃ (over parent support)
      - mean norms of Lambda_up/dn (q/p), if available in CacheHub
    """
    rows = []
    if not parents:
        return rows

    Lambda_up = Lambda_dn = None

    for P in parents:
        pid = int(getattr(P, "id", -1))
        m = np.asarray(getattr(P, "mask", 0.0), np.float32)
        mb = (m > float(thr))

        def _frob_mean(M):
            if M is None:
                return np.nan
            A = np.asarray(M, np.float32)
            if A.ndim < 2:
                return np.nan
            F = np.sqrt(np.sum(A*A, axis=(-2, -1)))
            return float(F[mb].mean()) if mb.any() else 0.0

        row = {
            "parent": pid,
            "phi_map_frob": _frob_mean(getattr(P, "bundle_morphism_q_to_p", None)),
            "phi_tilde_map_frob": _frob_mean(getattr(P, "bundle_morphism_p_to_q", None)),
            "lambda_up_q_mean": np.nan,
            "lambda_dn_q_mean": np.nan,
            "lambda_up_p_mean": np.nan,
            "lambda_dn_p_mean": np.nan,
        }

        kids = list(getattr(P, "child_ids", []) or [])
        if kids and ctx is not None and (Lambda_up or Lambda_dn):
            vals = {"u_q": [], "d_q": [], "u_p": [], "d_p": []}
            # agent lookup
            amap = getattr(ctx, "agent_index", None) or {int(getattr(a, "id")): a for a in (agents or []) if hasattr(a, "id")}
            for cid in kids:
                ch = amap.get(int(cid))
                if ch is None:
                    continue
                for which, key in (("q", "q"), ("p", "p")):
                    try:
                        if Lambda_up:
                            Lu = Lambda_up(ctx, ch, P, which=which)
                            if Lu is not None:
                                A = np.asarray(Lu, np.float32)
                                vals[f"u_{key}"].append(float(np.sqrt(np.sum(A*A))))
                    except Exception:
                        pass
                    try:
                        if Lambda_dn:
                            Ld = Lambda_dn(ctx, ch, P, which=which)
                            if Ld is not None:
                                A = np.asarray(Ld, np.float32)
                                vals[f"d_{key}"].append(float(np.sqrt(np.sum(A*A))))
                    except Exception:
                        pass
            for k_map, out_key in (("u_q","lambda_up_q_mean"), ("d_q","lambda_dn_q_mean"),
                                   ("u_p","lambda_up_p_mean"), ("d_p","lambda_dn_p_mean")):
                v = vals[k_map]
                row[out_key] = float(np.mean(v)) if v else np.nan

        rows.append(row)
    return rows

# -------- cross-scale (same-fiber) KL summaries --------

def crossscale_energy_totals(ctx, agents, parents) -> dict:
    """
    SAME-FIBER child→parent KL:
      - xscale_q_* : KL(child q || parent q)
      - xscale_p_* : KL(child p || parent p)
    """
    out = {"xscale_q_mean": np.nan, "xscale_p_mean": np.nan,
           "xscale_q_sum": 0.0, "xscale_p_sum": 0.0, "xscale_pairs": 0}
    if ctx is None or not parents:
        return out
    try:
        qs, ps, n = 0.0, 0.0, 0
        amap = getattr(ctx, "agent_index", None)
        if amap is None:
            amap = {int(getattr(a, "id")): a for a in (agents or []) if hasattr(a, "id")}
        
        
        for P in (parents or []):
            for cid in getattr(P, "child_ids", []) or []:
                ch = amap.get(int(cid))
                if ch is None:
                    continue
                vq = compute_crossscale_kl_q_single(ch, P, eps=1e-6, ctx=ctx)  # q vs q
                vp = compute_crossscale_kl_p_single(ch, P, eps=1e-6, ctx=ctx)  # p vs p
                if np.isfinite(vq): qs += float(vq)
                if np.isfinite(vp): ps += float(vp)
                n += 1
        if n > 0:
            out["xscale_q_mean"] = qs / n
            out["xscale_p_mean"] = ps / n
        out["xscale_q_sum"] = qs
        out["xscale_p_sum"] = ps
        out["xscale_pairs"] = n
    except Exception:
        pass
    return out

# -------- pretty-print energies safely --------

def _pf(d, k, default=0.0):
    """safe float pull from dict-like"""
    try:
        return float((d or {}).get(k, default))
    except Exception:
        return float(default)

def print_energy_totals(step, levels_map, flat_record, all_metrics_for_print, logcfg):
    """Compact, robust console output for energies + cross-scale."""
    print(f"[Energy Totals @ step {step}]")

    # lvl-0 (children)
    m0 = (levels_map or {}).get(0) or {}
    print(f"  [lvl-0 children]")
    print(f"    Self belief      = {_pf(m0,'e_self'):.4e}")
    print(f"    Feedback model   = {_pf(m0,'e_feedback'):.4e}")
    print(f"    Belief alignment = {_pf(m0,'e_align'):.4e}")
    print(f"    Model alignment  = {_pf(m0,'e_mod_align'):.4e}")
    print(f"    Belief curvature = {_pf(m0,'e_curv'):.4e}")
    print(f"    Model curvature  = {_pf(m0,'e_curv_mod'):.4e}")
    print(f"    Belief mass      = {_pf(m0,'e_mass'):.4e}")
    print(f"    Model mass       = {_pf(m0,'e_mass_mod'):.4e}")
    if "total_energy" in (m0 or {}):
        print(f"    ----")
        print(f"    TOTAL            = {_pf(m0,'total_energy'):.4e}")

    # parents per level
    for L in sorted(k for k in (levels_map or {}).keys() if k != 0):
        mL = (levels_map or {}).get(L) or {}
        print(f"  [lvl-{L} parents]")
        print(f"    Self belief      = {_pf(mL,'e_self'):.4e}")
        print(f"    Feedback model   = {_pf(mL,'e_feedback'):.4e}")
        print(f"    Belief alignment = {_pf(mL,'e_align'):.4e}")
        print(f"    Model alignment  = {_pf(mL,'e_mod_align'):.4e}")
        print(f"    Belief curvature = {_pf(mL,'e_curv'):.4e}")
        print(f"    Model curvature  = {_pf(mL,'e_curv_mod'):.4e}")
        print(f"    Belief mass      = {_pf(mL,'e_mass'):.4e}")
        print(f"    Model mass       = {_pf(mL,'e_mass_mod'):.4e}")
        if "total_energy" in (mL or {}):
            print(f"    ----")
            print(f"    TOTAL            = {_pf(mL,'total_energy'):.4e}")

    # cross-scale summary (same fiber)
    if bool(logcfg.get("print_crossscale", True)):
        m = all_metrics_for_print or {}
        print("  [cross-scale child→parent KL (same fiber)]")
        print(f"    mean KL(q→q): {float(m.get('xscale_q_mean', np.nan)):.4e}   "
              f"mean KL(p→p): {float(m.get('xscale_p_mean', np.nan)):.4e}   "
              f"pairs: {int(m.get('xscale_pairs', 0))}")
        print(f"    sum  KL(q→q): {float(m.get('xscale_q_sum', 0.0)):.4e}   "
              f"sum  KL(p→p): {float(m.get('xscale_p_sum', 0.0)):.4e}\n")

    # NEW: single GRAND TOTAL (sum of per-level totals if present)
    try:
        totals = [
            float(v.get("total_energy", 0.0))
            for v in (levels_map or {}).values()
            if isinstance(v, dict)
        ]
        if totals:
            grand = float(sum(totals))
            print(f"[GRAND TOTAL variational energy] {grand:.4e}\n")
    except Exception:
        pass


# -------- field snapshots (crucial vs full) --------

def dump_fields_if_needed(runtime_ctx, agents, step, outdir, params, logcfg):
    """
    Writes lean 'crucial' snapshots by default; optional 'full' (larger).
    Can include children, parents, or both in the same NPZ.

    logcfg keys used:
      - enable_fields: bool
      - fields_every: int
      - full_field_outdir: str
      - snapshot_mode: "crucial" | "full"   (default: "crucial")
      - fp16_snapshot: bool                 (default: True)
      - snapshot_include_levels: "children" | "parents" | "both" (default: "both")
    """
    
    

    # ---- config & dirs ----
    do_fields     = bool(logcfg.get("enable_fields", False))
    cadence       = int(logcfg.get("fields_every", 1) or 1)
    field_dir     = os.path.join(outdir, logcfg.get("full_field_outdir", "fields"))
    snapshot_mode = (logcfg.get("snapshot_mode", "crucial") or "crucial").lower()
    include_lvls  = (logcfg.get("snapshot_include_levels", "both") or "both").lower()
    fp16          = bool(logcfg.get("fp16_snapshot", True))

    include_crucial = {"mask", "phi", "phi_model"}
    include_full    = {"mask", "phi", "phi_model", "mu_q", "sigma_q", "mu_p", "sigma_p"}

    # ---- parent collection (robust to missing ctx or structures) ----
    def _collect_all_parents(ctx):
        if ctx is None:
            return []
        pbL = getattr(ctx, "parents_by_level", None)
        if isinstance(pbL, dict) and pbL:
            out = []
            for bucket in pbL.values():
                out.extend(list(bucket.values()) if isinstance(bucket, dict) else list(bucket))
            return out
        return list((getattr(ctx, "parents_by_region", {}) or {}).values())

    def _choose_agents(children, parents, how: str):
        if how == "children": return list(children)
        if how == "parents":  return list(parents or [])
        # both (default)
        return list(children) + (list(parents or []) if parents else [])

    # ---- ensure dir ----
    os.makedirs(field_dir, exist_ok=True)

    # ---- step 0 bootstrap (always write a small snapshot to prime viz) ----
    if step == 0:
        try:
            parents_now     = _collect_all_parents(runtime_ctx)
            agents_to_dump  = _choose_agents(agents, parents_now, include_lvls)
            if agents_to_dump:
                dump_snapshot_npz(
                    agents_to_dump, step, field_dir,
                    compute_alignment=False,
                    compute_curvature=False,
                    fp16=fp16,
                    params=params,
                    include=tuple(sorted(include_crucial)),
                )
        except Exception as e:
            print(f"[SNAPSHOT][ERROR bootstrap] {e}")

    # ---- cadence-controlled snapshots ----
    if do_fields and (step % cadence == 0):
        try:
            parents_now     = _collect_all_parents(runtime_ctx)
            agents_to_dump  = _choose_agents(agents, parents_now, include_lvls)
            if not agents_to_dump:
                return  # nothing to write
            include = include_crucial if snapshot_mode == "crucial" else include_full
            dump_snapshot_npz(
                agents_to_dump, step, field_dir,
                compute_alignment=bool(logcfg.get("compute_alignment", False)),
                compute_curvature=bool(logcfg.get("compute_curvature", False)),
                fp16=fp16,
                params=params,
                include=tuple(sorted(include)),
            )
        except Exception as e:
            print(f"[SNAPSHOT][ERROR] {e}")




# run_sim_utils.py
def save_step(agents, outdir, step, *, save_every=1, compress=True):
    import pickle, os
    os.makedirs(outdir, exist_ok=True)
    ckpt_path = os.path.join(outdir, "checkpoint.pkl")
    if compress:
        import lzma
        with lzma.open(ckpt_path + ".xz", "wb", preset=3) as f:
            pickle.dump(agents, f, protocol=pickle.HIGHEST_PROTOCOL)
    else:
        with open(ckpt_path, "wb") as f:
            pickle.dump(agents, f, protocol=pickle.HIGHEST_PROTOCOL)

    if (step is not None) and (step % int(save_every) == 0):
        step_base = os.path.join(outdir, f"step_{step:04d}.pkl")
        if compress:
            import lzma
            with lzma.open(step_base + ".xz", "wb", preset=3) as f:
                pickle.dump(agents, f, protocol=pickle.HIGHEST_PROTOCOL)
        else:
            with open(step_base, "wb") as f:
                pickle.dump(agents, f, protocol=pickle.HIGHEST_PROTOCOL)












def checkpoint_step(agents, outdir):
    # clear heavy caches then save
    for A in agents:
        if hasattr(A, "clear_omega_cache"):   A.clear_omega_cache()
        if hasattr(A, "clear_fisher_caches"): A.clear_fisher_caches()
    save_step(agents, outdir, runtime_step=None)  # filename is handled downstream


def wrap_epilogue(runtime_ctx, agents, outdir, parent_metrics, metric_log):
    import pandas as pd
   
    # local snapshot helper (same as above) for the final save
    def _snapshot_parents_npz_simple(parents, save_path):
        ids = []
        masks = []
        for idx, P in enumerate(parents):
            ids.append(getattr(P, "id", idx))
            masks.append(np.asarray(getattr(P, "mask", None)))
        out = {"ids": np.asarray(ids, dtype=np.int32)}
        shapes = {m.shape for m in masks if m is not None}
        if len(shapes) == 1 and len(masks) > 0:
            out["masks"] = np.stack([m.astype(np.float32) for m in masks], axis=0)
        else:
            out["masks_obj"] = np.array([m.astype(np.float32) for m in masks], dtype=object)
        os.makedirs(os.path.dirname(save_path), exist_ok=True)
        np.savez_compressed(save_path, **out)

    # metrics log
    if metric_log:
        with open(os.path.join(outdir, "metric_log.pkl"), "wb") as f:
            pickle.dump(metric_log, f)
        #print(f"[SAVE] Metrics log --> {os.path.join(outdir, 'metric_log.pkl')}")
        rows = [{"agent": A.id, **e} for A in agents for e in getattr(A, "metrics_log", [])]
        if rows:
            pd.DataFrame(rows).to_csv(os.path.join(outdir, "per_agent_metrics.csv"), index=False)
            #print("[SAVE] Per-agent metrics --> per_agent_metrics.csv")

    # parents snapshot
    parents_now = list(runtime_ctx.parents_by_region.values())
    if parents_now:
        try:
            _snapshot_parents_npz_simple(parents_now, os.path.join(outdir, "parents_end.npz"))
        except Exception as e:
            print(f"[SNAP][ERROR] final: {e}")
    # parent metrics csv
    if parent_metrics:
        pd = __import__("pandas")
        pd.DataFrame(parent_metrics).to_csv(os.path.join(outdir, "parent_metrics.csv"), index=False)
        #print("[SAVE] Parent metrics --> parent_metrics.csv")
