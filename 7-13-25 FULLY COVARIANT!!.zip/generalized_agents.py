from numpy.random import default_rng

import numpy as np

import matplotlib.pyplot as plt

from generalized_agent_schema import Agent
from scipy.ndimage import gaussian_filter
import config
from mask_utils import create_agent_mask, generate_soft_mask


def scale_to_range(
    field: np.ndarray,
    value_range: tuple[float, float]
) -> np.ndarray:
    """
    Linearly remap `field` so that field.min()→value_range[0], field.max()→value_range[1].
    If field is constant, fill with the midpoint of the range.
    Output dtype is taken from config.dtype.
    """
    lo, hi = value_range
    fmin, fmax = field.min(), field.max()
    dtype = getattr(config, 'dtype', field.dtype)
    if fmax <= fmin:
        return np.full_like(field, (lo + hi) / 2, dtype=dtype)

    # normalize to [0,1]
    norm = (field - fmin) / (fmax - fmin)
    # scale to [lo, hi]
    out = norm * (hi - lo) + lo
    return out.astype(dtype)






def generate_anisotropic_mu_field(domain_size, rng, K, value_range, smooth_range, mu_anisotropy_range, mu_orientation_range):
    """
    Generate a (H, W, K) μ field with anisotropic smoothing.
    """
    dtype = getattr(config, "dtype", np.float32)
    fields = []
    for _ in range(K):
        sigma1 = rng.uniform(*smooth_range)
        anisotropy = rng.uniform(*mu_anisotropy_range)
        angle = rng.uniform(*mu_orientation_range)
        sigma2 = sigma1 / anisotropy

        c, s = np.cos(angle), np.sin(angle)
        R = np.array([[c, -s], [s, c]])
        Λ = np.diag([sigma1**2, sigma2**2])
        cov = R @ Λ @ R.T

        f = smooth_random_field_anisotropic(domain_size, rng, cov=cov)
        fields.append(scale_to_range(f, value_range))

    return np.stack(fields, axis=-1).astype(dtype)


def generate_mu_sigma_pair(domain_size, rng, K, mu_range, sigma_range, smooth_range):
    """
    Generate a (μ, Σ) pair using anisotropic μ and SPD Σ.
    """
    mu_anisotropy_range  = getattr(config, "mu_anisotropy_range", (1.0, 1.0))
    mu_orientation_range = getattr(config, "mu_orientation_range", (0.0, 0.0))
    mu_field = generate_anisotropic_mu_field(
        domain_size, rng, K, mu_range, smooth_range,
        mu_anisotropy_range, mu_orientation_range
    )

    sigma_field = generate_smooth_spd_matrix_field(
        H=domain_size[0], W=domain_size[1], D=K,
        min_eig=sigma_range[0], max_eig=sigma_range[1],
        sigma=rng.uniform(*getattr(config, "sigma_field_smooth_range", (1, 3))),
        seed=rng.integers(0, 1e9)
    )
    return mu_field, sigma_field


def create_smooth_fields(domain_size, rng, K, mask=None):
    """
    Create smooth μ/Σ fields for q and p bundles.
    Applies optional masking.
    """
    dtype = getattr(config, "dtype", np.float32)
    q_mu_range = getattr(config, "q_mu_range", (0, K - 1))
    q_sigma_range = getattr(config, "q_sigma_range", (1, 5))
    p_mu_range = getattr(config, "p_mu_range", (0, K - 1))
    p_sigma_range = getattr(config, "p_sigma_range", (1, 5))
    mu_smooth_range = getattr(config, "mu_field_smooth_range", (1, 3))

    mu_q, sigma_q = generate_mu_sigma_pair(domain_size, rng, K, q_mu_range, q_sigma_range, mu_smooth_range)

    if getattr(config, "identical_models", False):
        mu_p, sigma_p = generate_mu_sigma_pair(domain_size, rng, K, p_mu_range, p_sigma_range, mu_smooth_range)

    elif getattr(config, "similar_p_models", False):
        base_mu_p = rng.uniform(*p_mu_range, size=K).astype(dtype)
        mu_p = np.broadcast_to(base_mu_p, (*domain_size, K))
        sigma_p = generate_smooth_spd_matrix_field(
            H=domain_size[0], W=domain_size[1], D=K,
            min_eig=p_sigma_range[0], max_eig=p_sigma_range[1],
            sigma=rng.uniform(*getattr(config, "sigma_field_smooth_range", (1, 3))),
            seed=rng.integers(0, 1e9)
        )
    else:
        mu_p, sigma_p = generate_mu_sigma_pair(domain_size, rng, K, p_mu_range, p_sigma_range, mu_smooth_range)

    if mask is not None:
        mu_q *= mask[..., None]
        sigma_q *= mask[..., None, None]
        mu_p *= mask[..., None]
        sigma_p *= mask[..., None, None]

    return mu_q, sigma_q, mu_p, sigma_p




import scipy.ndimage

def apply_anisotropic_filter(field: np.ndarray, sigma_x: float, sigma_y: float, angle: float) -> np.ndarray:
    """
    Apply an anisotropic Gaussian filter to a 2D field by rotating, blurring, and rotating back.
    """
    # Rotate field by -angle
    rotated = scipy.ndimage.rotate(field, angle * 180 / np.pi, reshape=False, order=1, mode='wrap')

    # Apply Gaussian blur in x and y (major/minor)
    blurred = scipy.ndimage.gaussian_filter(rotated, sigma=(sigma_y, sigma_x), mode='wrap')

    # Rotate back by +angle
    unrotated = scipy.ndimage.rotate(blurred, -angle * 180 / np.pi, reshape=False, order=1, mode='wrap')

    return unrotated





def smooth_random_field_anisotropic(domain_size, rng, mean=0.0, std=1.0, cov=None):
    """
    Generate a smooth random field with an anisotropic Gaussian kernel.
    Args:
        domain_size: Tuple of spatial shape (H, W)
        rng: random generator
        mean, std: field mean and std
        cov: 2x2 SPD matrix defining smoothing kernel shape (default isotropic)
    """
    from scipy.ndimage import gaussian_filter

    field = rng.normal(loc=mean, scale=std, size=domain_size)

    if cov is None:
        # Default to isotropic
        sigma_x = sigma_y = 1.0
        angle = 0.0
    else:
        # Convert covariance to principal axes
        eigvals, eigvecs = np.linalg.eigh(cov)
        major, minor = np.sqrt(eigvals[::-1])  # σ₁, σ₂
        angle = np.arctan2(eigvecs[1, 0], eigvecs[0, 0])  # rotation of major axis

        # Apply smoothing in aligned coordinates
        field = apply_anisotropic_filter(field, major, minor, angle)

    return field


def generate_smooth_spd_matrix_field(H, W, D, min_eig=0.5, max_eig=2.0, sigma=1.0, seed=None):
    """
    Generate a smooth (H, W, D, D) field of SPD matrices by smoothing eigenvalues
    and using a fixed orthonormal basis across space.
    """
    if seed is not None:
        np.random.seed(seed)

    eigval_field = np.random.uniform(min_eig, max_eig, size=(H, W, D)).astype(np.float32)

    for d in range(D):
        eigval_field[..., d] = gaussian_filter(eigval_field[..., d], sigma=sigma)

    eigval_field = np.clip(eigval_field, min_eig, max_eig)

    A = np.random.randn(D, D)
    Q_global, _ = np.linalg.qr(A)

    sigma_field = np.zeros((H, W, D, D), dtype=np.float32)
    for i in range(H):
        for j in range(W):
            Λ = np.diag(eigval_field[i, j])
            sigma_field[i, j] = Q_global @ Λ @ Q_global.T

    return sigma_field





def initialize_phi_field(
    domain_size: tuple[int, ...],
    lie_algebra_dim: int,
    rng: np.random.Generator,
    init_scale: float,
    mask: np.ndarray,
    smooth_sigma: float = None
) -> np.ndarray:
    """
    Initialize and smooth a φ field with Gaussian noise and apply mask.
    """
    dtype = getattr(config, 'dtype', mask.dtype)
    sigma = smooth_sigma or getattr(config, 'phi_init_smooth_sigma', 0.5)

    phi_raw = rng.normal(scale=init_scale, size=(*domain_size, lie_algebra_dim)).astype(dtype)
    phi_smooth = gaussian_filter(phi_raw, sigma=sigma)
    return phi_smooth * mask[..., None]

def initialize_phi_pair(
    domain_size: tuple[int, ...],
    lie_algebra_dim: int,
    rng: np.random.Generator,
    phi_init: float,
    phi_model_offset: float,
    mask: np.ndarray
) -> tuple[np.ndarray, np.ndarray]:
    """
    Initialize φ and φ̃ (belief and model) with optional offset for φ̃.
    """
    phi = initialize_phi_field(domain_size, lie_algebra_dim, rng, phi_init, mask)

    if getattr(config, "identical_models", False):
        phi_model = np.zeros_like(phi)
    else:
        delta = rng.normal(scale=phi_model_offset, size=(*domain_size, lie_algebra_dim)).astype(phi.dtype)
        phi_model_raw = phi + delta
        phi_model = gaussian_filter(phi_model_raw, sigma=getattr(config, 'phi_init_smooth_sigma', 0.5))
        phi_model *= mask[..., None]

    return phi, phi_model








def assign_neighbors_vectorized(
    agents: list,
    overlap_eps: float,
    max_neighbors: int
) -> None:
    """
    Assigns neighbors to each agent by computing pairwise mask overlaps.
    Vectorized for efficiency.

    A pair (i, j) is considered overlapping if:
        overlap(i, j) > overlap_eps × num_pixels
    """
    if max_neighbors == 0:
        for agent in agents:
            agent.neighbors = []
        return

    N = len(agents)
    dtype = getattr(config, 'dtype', np.float32)

    # Flatten masks into (N, H×W)
    masks_flat = np.stack([agent.mask.flatten().astype(dtype) for agent in agents])

    # Compute pairwise overlap matrix
    overlap_matrix = masks_flat @ masks_flat.T  # shape: (N, N)
    pixel_thresh = overlap_eps * masks_flat.shape[1]

    # Boolean matrix: True if overlap > threshold
    above_thresh = overlap_matrix > pixel_thresh
    np.fill_diagonal(above_thresh, False)  # Exclude self-overlap

    for i in range(N):
        sorted_idx = np.argsort(-overlap_matrix[i])  # descending order
        valid_neighbors = [j for j in sorted_idx if above_thresh[i, j]]
        agents[i].neighbors = [{"id": j} for j in valid_neighbors[:max_neighbors]]

def plot_agent_overlap(agent_i, agent_j, cutoff=None):
    import matplotlib.pyplot as plt
    import numpy as np
    import config

    if cutoff is None:
        cutoff = getattr(config, "support_cutoff_eps", 1e-3)

    mask_i  = agent_i.mask > cutoff
    mask_j  = agent_j.mask > cutoff
    overlap = mask_i & mask_j

    if mask_i.ndim != 2:
        raise ValueError(f"plot_agent_overlap only supports 2D spatial domains, got shape {mask_i.shape}")

    H, W = mask_i.shape

    fig, axs = plt.subplots(1, 3, figsize=(12, 4))

    for ax, M, title in zip(
        axs,
        [mask_i, mask_j, overlap],
        [f"Agent {agent_i.id} Support",
         f"Agent {agent_j.id} Support",
         "Overlap"]
    ):
        ax.imshow(
            M,
            cmap="gray",
            origin="lower",
            extent=[0, W, 0, H],
            interpolation="nearest"
        )
        ax.set_title(title)
        ax.set_xticks([0, W//2, W])
        ax.set_yticks([0, H//2, H])

    plt.tight_layout()
    plt.show()

import numpy as np
import matplotlib.pyplot as plt
from numpy.random import default_rng

import config

def initialize_agents(
    seed: int,
    domain_size: tuple[int, ...],
    N: int,
    K: int,
    lie_algebra_dim: int,
    visualize: bool = False,         # ignored for now
    fixed_location: bool = True,
) -> list[Agent]:
    """
    Initialize N agents with belief and model fields over a domain.
    Each agent has spatially localized support, smooth μ/Σ, φ/φ̃, and neighbors.
    """
    from numpy.random import default_rng
    from scipy.ndimage import distance_transform_edt
    from natural_gradient_utils import sanitize_sigma

    rng = default_rng(seed)
    cfg = {k: getattr(config, k) for k in dir(config) if not k.startswith("__")}
    phi_init         = cfg["phi_init"]
    phi_model_offset = cfg.get("phi_model_offset", 0.1)
    max_neighbors    = cfg.get("max_neighbors", 8)
    dtype            = cfg.get("dtype", np.float32)
    sigma_outside_val = cfg.get("sigma_outside_mask_value", 100.0)
    overlap_eps      = cfg.get("overlap_eps", 1e-3)

    D = len(domain_size)
    fixed_center = tuple(s // 2 for s in domain_size) if fixed_location else None

    # ──────────────────────────────────────────────────────────────
    # Shared model fields (if identical_models)
    # ──────────────────────────────────────────────────────────────
    if getattr(config, "identical_models", False):
        _, _, shared_mu_p, shared_sigma_p = create_smooth_fields(domain_size, rng, K)
    else:
        shared_mu_p = shared_sigma_p = None

    agents = []

    for n in range(N):
        # ── Agent mask and center ──
        radius = rng.uniform(*cfg.get("psi_radius_range", (5, 10)))
        center = fixed_center or tuple(rng.integers(0, s) for s in domain_size)
        mask = create_agent_mask(center, radius, domain_size)
        mask_bool = mask.astype(bool)

        # ── Generate (μ, Σ) fields ──
        mu_q, sigma_q, mu_p, sigma_p = create_smooth_fields(domain_size, rng, K)

        if shared_mu_p is not None:
            mu_p = shared_mu_p
            sigma_p = shared_sigma_p

        # ── Apply soft masking to μ fields ──
        mu_q *= mask[..., None]
        mu_p *= mask[..., None]

        # ── Smooth Σ decay near boundary ──
        distance = distance_transform_edt(~mask_bool)
        w_field = (distance / (distance.max() + 1e-8)) ** 0.2
        sigma_outer = np.eye(K, dtype=dtype) * sigma_outside_val
        for i in range(domain_size[0]):
            for j in range(domain_size[1]):
                w = w_field[i, j]
                sigma_q[i, j] = (1 - w) * sigma_q[i, j] + w * sigma_outer
                sigma_p[i, j] = (1 - w) * sigma_p[i, j] + w * sigma_outer

        # ── φ / φ̃ initialization ──
        phi, phi_model = initialize_phi_pair(
            domain_size, lie_algebra_dim, rng,
            phi_init, phi_model_offset, mask
        )

        # ── Create Agent object ──
        agent = Agent(
            id=n,
            center=center,
            radius=radius,
            mask=mask.astype(dtype),
            mu_q_field=mu_q.astype(dtype),
            sigma_q_field=sanitize_sigma(sigma_q),
            mu_p_field=mu_p.astype(dtype),
            sigma_p_field=sanitize_sigma(sigma_p),
            phi=phi,
            phi_model=phi_model,
            neighbors=[]
        )
        agents.append(agent)

    # ── Neighbor assignment ──
    assign_neighbors_vectorized(agents, overlap_eps=overlap_eps, max_neighbors=max_neighbors)
    print(f"[DEBUG] Initialized {len(agents)} agents with K={K}, domain={domain_size}, dtype={dtype}")

    # ── Optional validation ──
    validate_agents(agents)

    return agents

from numerical_utils import check_spd_field

from numerical_utils import check_spd_field

def validate_agents(agents: list) -> None:
    """
    Run validation checks on each agent's fields.
    Ensures Σ fields are SPD, φ fields are finite, masks are valid.
    """
    support_eps = getattr(config, "support_cutoff_eps", 1e-4)
    debug = getattr(config, "debug", False)

    for agent in agents:
        support = agent.mask > support_eps

        if not np.all(np.isfinite(agent.mu_q_field[support])):
            print(f"[VALIDATION] Agent {agent.id}: non-finite μ_q inside mask")
        if not np.all(np.isfinite(agent.mu_p_field[support])):
            print(f"[VALIDATION] Agent {agent.id}: non-finite μ_p inside mask")
        if not np.all(np.isfinite(agent.sigma_q_field[support])):
            print(f"[VALIDATION] Agent {agent.id}: non-finite Σ_q inside mask")
        if not np.all(np.isfinite(agent.sigma_p_field[support])):
            print(f"[VALIDATION] Agent {agent.id}: non-finite Σ_p inside mask")
        if not np.all(np.isfinite(agent.phi[support])):
            print(f"[VALIDATION] Agent {agent.id}: non-finite φ values inside mask")
        if not np.all(np.isfinite(agent.phi_model[support])):
            print(f"[VALIDATION] Agent {agent.id}: non-finite φ̃ values inside mask")
        if not np.all((agent.mask >= 0) & (agent.mask <= 1)):
            print(f"[VALIDATION] Agent {agent.id}: mask contains invalid values outside [0,1]")

        if debug:
            print(f"[DEBUG] Agent {agent.id}: μ_q range = [{agent.mu_q_field.min():.3g}, {agent.mu_q_field.max():.3g}], "
                  f"Σ_q max norm = {np.linalg.norm(agent.sigma_q_field[support]):.3g}")
            if not check_spd_field(agent.sigma_q_field):
                print(f"[DEBUG] Agent {agent.id}: Σ_q is NOT SPD globally")
            if not check_spd_field(agent.sigma_p_field):
                print(f"[DEBUG] Agent {agent.id}: Σ_p is NOT SPD globally")

    print("[✓] Agent validation complete.")
