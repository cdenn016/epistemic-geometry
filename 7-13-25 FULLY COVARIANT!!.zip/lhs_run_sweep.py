import os
os.environ["OMP_NUM_THREADS"] = "1"
os.environ["MKL_NUM_THREADS"] = "1"
os.environ["NUMEXPR_NUM_THREADS"] = "1"  # Optional: just in case

from threadpoolctl import threadpool_info
print(threadpool_info())
import pickle
import numpy as np
import pandas as pd
from scipy.stats import qmc
import config
from generalized_simulation import run_simulation

DEFAULT_SAMPLES = 15  # Number of successful runs to obtain

# --- Load default parameters from config.py ---
base_params = {
    k: getattr(config, k)
    for k in dir(config)
    if not k.startswith("__") and not callable(getattr(config, k))
}

base_params.update({
    "debug": True,
    "steps": 4,
    "N": 4,
})


def get_scaled_sweep_params(K):
    return {
        "alpha":                  (0.05,   100),
        "beta":                   (0.05,    25),
        "gauge_weight":           (0,     1000),
        "model_align_weight":     (0,     1000),
        "model_mass_weight":      (0,     1000),
        "model_feedback_weight":  (0,       25),
        "phi_phi_tilde_coupling": (0,     1000),
        "model_curvature_weight": (0,     1000),
        "curvature_weight":       (0,     1000),
    }


def is_unstable(metrics, clip_threshold=50, energy_thresh=1e8, min_kl_thresh=-1e-5):
    if not metrics:
        return True

    kl_keys = [k for k in metrics[0].keys() if "kl" in k.lower()]
    prev_vals = {k: metrics[0].get(k, 0) for k in kl_keys}

    for step in metrics:
        if any(np.isnan(v) or np.isinf(v) for v in step.values()):
            return True
        if step.get("energy_total", 0) > energy_thresh:
            return True
        if step.get("sanitize_clipped", 0) > clip_threshold:
            return True
        for k in step:
            if "kl" in k.lower():
                if step[k] < min_kl_thresh:
                    return True
                if step[k] > prev_vals[k] + 1e-3:
                    print(f"[REJECT] KL term '{k}' increased: {prev_vals[k]:.4f} --> {step[k]:.4f}")
                    return True
                prev_vals[k] = step[k]

    return False


def is_pickleable(obj):
    try:
        pickle.dumps(obj)
        return True
    except Exception:
        return False

def sanitize_for_pickle(obj):
    """Recursively strip non-pickleable items from a dict/list."""
    if isinstance(obj, dict):
        return {k: sanitize_for_pickle(v) for k, v in obj.items() if is_pickleable(v)}
    elif isinstance(obj, list):
        return [sanitize_for_pickle(v) for v in obj if is_pickleable(v)]
    return obj  # primitive or safe


def run_lhs_sweep_for_K(K, n_samples=DEFAULT_SAMPLES):
    base_params_K = dict(base_params)
    base_params_K["K"] = K

    output_dir = f"lhs_results_K{K}"
    csv_path = f"lhs_samples_K{K}.csv"
    os.makedirs(output_dir, exist_ok=True)

    sweep_params = get_scaled_sweep_params(K)
    param_names = list(sweep_params)
    ranges = [sweep_params[k] for k in param_names]
    sampler = qmc.LatinHypercube(d=len(ranges))
    attempted_rows = set()

    sweep_spec_path = os.path.join(output_dir, "sweep_spec.pkl")
    with open(sweep_spec_path, "wb") as f:
        pickle.dump({"param_names": param_names, "ranges": sweep_params}, f)

    all_params = []
    attempt_id = 0
    max_retries = 5

    while len(all_params) < n_samples:
        raw_sample = sampler.random(n=1)[0]
        sample_key = tuple(raw_sample.round(decimals=6))
        if sample_key in attempted_rows:
            continue
        attempted_rows.add(sample_key)

        row = qmc.scale([raw_sample], [lo for lo, hi in ranges], [hi for lo, hi in ranges])[0]
        sampled_params = dict(zip(param_names, row))

        attempt = 0
        success = False

        while attempt < max_retries and not success:
            entry = dict(base_params_K)
            entry.update(sampled_params)
            entry["agent_seed"] = base_params.get("agent_seed", 13) + attempt_id

            run_name = f"run_{attempt_id}_try{attempt}"
            subdir = os.path.join(output_dir, run_name)
            os.makedirs(subdir, exist_ok=True)

            print(f"\n[TRY {attempt}] {run_name} → {sampled_params}")
            try:
                _, metrics = run_simulation(
                    outdir=subdir,
                    resume=False,
                    log_metrics=True,
                    log_fields=True,
                    num_cores=-1,
                    params=entry,
                )

                metrics_clean = sanitize_for_pickle(metrics)

                with open(os.path.join(subdir, "final_metrics.pkl"), "wb") as f:
                    pickle.dump(metrics_clean, f)
               
                params_clean = sanitize_for_pickle(entry)
                with open(os.path.join(subdir, "params.pkl"), "wb") as f:
                    pickle.dump(params_clean, f)

                log_path = os.path.join(subdir, "metric_log.pkl")
                metric_log = pickle.load(open(log_path, "rb")) if os.path.exists(log_path) else []

                if is_unstable(metric_log):
                    print(f"[REJECT] {run_name} failed stability check.")
                    attempt += 1
                    continue

                print(f"[✓] {run_name} accepted.")
                all_params.append(entry)
                attempt_id += 1
                success = True

            except Exception as e:
                print(f"[ERROR] {run_name} crashed: {e}")
                import traceback
                traceback.print_exc()
                attempt += 1

        if not success:
            print(f"[✗] Abandoned sample after {max_retries} failed attempts.")

    df = pd.DataFrame(all_params)
    df.to_csv(csv_path, index=False)
    print(f"\n[DONE] CSV written → {csv_path}")
    print(f"[DONE] LHS sweep for K={K} finished with {len(all_params)} valid runs.")


def main():
    odd_K_values = [17]
    for K in odd_K_values:
        print(f"\n{'=' * 40}\n[SWEEP] Running for K={K}\n{'=' * 40}")
        run_lhs_sweep_for_K(K)


if __name__ == "__main__":
    main()
