# -*- coding: utf-8 -*-
"""
Created on Sun Jul 13 16:45:27 2025

@author: chris and christine
"""

# -*- coding: utf-8 -*-
"""
Unified Animation Module — All Visualizations
"""

import os
import re
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation
from pathlib import Path
import pickle
from scipy.ndimage import laplace

import config
from get_generators import get_generators
from generalized_omega import compute_field_strength
from generalized_math_utils import kl_divergence

# === GLOBAL CONFIG ===
FIELD_DUMPS_DIR = Path("checkpoints/field_dumps")
CHECKPOINT_DIR  = Path("checkpoints")
OUTDIR          = Path("Animations/all_outputs")
OUTDIR.mkdir(parents=True, exist_ok=True)

FPS      = 25
INTERVAL = 1000 // FPS
CMAP     = "viridis"
LOG_EPS  = 1e-8
DOWNSAMPLE = 1


# === UTILITIES ===
def safe_masked(arr):
    return np.ma.masked_where(arr == 0, arr)

def compute_entropy(sigma_q):
    H, W, K = sigma_q.shape[:3]
    entropy = np.full((H, W), np.nan)
    for i in range(H):
        for j in range(W):
            Σ = sigma_q[i, j] + LOG_EPS * np.eye(K)
            try:
                sign, logdet = np.linalg.slogdet(Σ)
                if sign > 0:
                    entropy[i, j] = 0.5 * (K * np.log(2 * np.pi * np.e) + logdet)
            except np.linalg.LinAlgError:
                continue
    return np.nan_to_num(entropy)

def compute_kl_qp(mu_q, sigma_q, mu_p, sigma_p):
    H, W, K = mu_q.shape
    try:
        kl_vals = kl_divergence(
            mu_q.reshape(-1, K), sigma_q.reshape(-1, K, K),
            mu_p.reshape(-1, K), sigma_p.reshape(-1, K, K),
            log_eps=LOG_EPS
        )
        return np.nan_to_num(kl_vals.reshape(H, W))
    except:
        return np.zeros((H, W))

def compute_phi_norm(phi): return np.linalg.norm(phi, axis=-1)
def compute_phi_laplacian_norm(phi):
    return np.linalg.norm(np.stack([laplace(phi[..., d]) for d in range(phi.shape[-1])], axis=-1), axis=-1)

def animate_scalar_sequence(field_seq, steps, title, fname):
    vmin = np.nanmin(field_seq)
    vmax = np.nanpercentile(field_seq, 99)
    fig, ax = plt.subplots()
    im = ax.imshow(field_seq[0], cmap=CMAP, vmin=vmin, vmax=vmax)
    ax.set_title(f"{title} — Step {steps[0]}")
    plt.colorbar(im, ax=ax)

    def update(i):
        im.set_data(field_seq[i])
        ax.set_title(f"{title} — Step {steps[i]}")
        return [im]

    ani = animation.FuncAnimation(fig, update, frames=len(steps), interval=400, blit=True)
    ani.save(OUTDIR / f"{fname}.gif", writer=animation.PillowWriter(fps=FPS))
    plt.close()

# === GLOBAL FIELD ANIMATIONS ===
def animate_global_fields():
    step_dirs = sorted([d for d in FIELD_DUMPS_DIR.iterdir() if d.is_dir()])
    entropy_seq, klqp_seq, phi_norm_seq, phi_model_seq, lap_phi_seq = [], [], [], [], []
    steps = []

    for d in step_dirs:
        try:
            mu_q = np.load(d / "mu_q_field.npy")
            sigma_q = np.load(d / "sigma_q_field.npy")
            phi = np.load(d / "phi.npy")
            mu_p = np.load(d / "mu_p_field.npy")
            sigma_p = np.load(d / "sigma_p_field.npy")
            phi_m = np.load(d / "phi_model.npy")
        except:
            continue

        entropy_seq.append(compute_entropy(sigma_q))
        klqp_seq.append(compute_kl_qp(mu_q, sigma_q, mu_p, sigma_p))
        phi_norm_seq.append(compute_phi_norm(phi))
        phi_model_seq.append(compute_phi_norm(phi_m))
        lap_phi_seq.append(compute_phi_laplacian_norm(phi))
        steps.append(int(d.name.replace("step", "")))

    animate_scalar_sequence(entropy_seq, steps, "Entropy(q)", "entropy_q")
    animate_scalar_sequence(klqp_seq, steps, "KL(q‖p)", "kl_qp")
    animate_scalar_sequence(phi_norm_seq, steps, "‖φ‖", "phi_norm")
    animate_scalar_sequence(phi_model_seq, steps, "‖φ_model‖", "phi_model_norm")
    animate_scalar_sequence(lap_phi_seq, steps, "‖Δφ‖", "lap_phi")

# === AGENT-LEVEL PHI & CURVATURE ===
def load_checkpoints():
    files = sorted(CHECKPOINT_DIR.glob("step_*.pkl"))
    steps = [int(f.stem.split("_")[1]) for f in files]
    return [(pickle.load(open(f, "rb")), s) for f, s in zip(files, steps)]

def compute_field(agent, metric):
    mask = agent.mask > config.support_cutoff_eps
    if metric == "phi_norm":
        return np.linalg.norm(agent.phi, axis=-1) * mask
    elif metric == "curvature_norm":
        gens = get_generators(config.group_name, config.K)
        F = compute_field_strength(agent.phi, gens)
        return np.linalg.norm(F["xy"], axis=(-2, -1)) * mask
    else:
        return np.zeros_like(agent.mask)

def animate_agent_fields():
    agent_steps = load_checkpoints()
    agents0, _ = agent_steps[0]
    agent_ids = [a.id for a in agents0]

    for metric in ["phi_norm", "curvature_norm"]:
        for aid in agent_ids:
            fields, steps = [], []
            for agents, step in agent_steps[::DOWNSAMPLE]:
                try:
                    agent = next(a for a in agents if a.id == aid)
                    fields.append(compute_field(agent, metric))
                    steps.append(step)
                except: continue
            if fields:
                animate_scalar_sequence(fields, steps, f"{metric} agent {aid}", f"{metric}_agent{aid}")

# === PAIR ALIGNMENT ANIMATIONS ===
def animate_pair_alignments():
    pattern = re.compile(r'step(\d+)_pair_(\d+)_(\d+)\.npz')
    all_files = [f for f in os.listdir(FIELD_DUMPS_DIR) if pattern.match(f)]
    pairs = sorted(set(tuple(map(int, pattern.match(f).groups()[1:])) for f in all_files))

    for i, j in pairs:
        frames = []
        for fname in sorted(f for f in all_files if f"pair_{i}_{j}" in f):
            data = np.load(FIELD_DUMPS_DIR / fname)
            mask = data['mask_i'][..., None]
            mask4 = mask[..., None]

            def safe_norm(x):
                return np.linalg.norm(x, axis=-1) if x.ndim == 3 else np.linalg.norm(x.reshape(*x.shape[:2], -1), axis=-1)

            def safe_kl(x): return safe_norm(x) * mask[..., 0]

            frames.append((
                int(pattern.match(fname).group(1)),
                safe_kl(data['belief_alignment']),
                safe_kl(data['model_alignment']),
                safe_norm(data['mu_q'] * mask),
                safe_norm(data['sigma_q'] * mask4),
                safe_norm(data['mu_p'] * mask),
                safe_norm(data['sigma_p'] * mask4),
                safe_kl(data.get('kl_self', np.zeros_like(mask[..., 0]))),
                safe_kl(data.get('kl_feedback', np.zeros_like(mask[..., 0])))
            ))

        def animate_field(frames, idx, title, outname):
            fields = [f[idx] for f in frames]
            steps = [f[0] for f in frames]
            animate_scalar_sequence(fields, steps, title, outname)

        animate_field(frames, 1, f"Belief KL {i}→{j}", f"belief_kl_{i}_{j}")
        animate_field(frames, 2, f"Model  KL {i}→{j}", f"model_kl_{i}_{j}")
        animate_field(frames, 3, f"‖μ_q‖ {i}", f"mu_q_{i}_{j}")
        animate_field(frames, 5, f"‖μ_p‖ {i}", f"mu_p_{i}_{j}")
        animate_field(frames, 4, f"‖σ_q‖ {i}", f"sigma_q_{i}_{j}")
        animate_field(frames, 6, f"‖σ_p‖ {i}", f"sigma_p_{i}_{j}")
        animate_field(frames, 7, f"KL(q‖p) self agent {i}", f"self_kl_{i}")
        animate_field(frames, 8, f"KL(p‖q) feedback agent {i}", f"feedback_kl_{i}")

# === MAIN ===
if __name__ == "__main__":
    print("[Run] Global field animations...")
    animate_global_fields()

    print("[Run] Agent-level φ and curvature...")
    animate_agent_fields()

    print("[Run] Pairwise belief/model alignment...")
    animate_pair_alignments()

    print("[✓] All animations completed.")
