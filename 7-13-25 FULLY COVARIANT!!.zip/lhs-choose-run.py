# -*- coding: utf-8 -*-
"""
Created on Sun Jul 13 07:59:38 2025

@author: chris and christine
"""

import pickle
from generalized_simulation import run_simulation

# Load the exact LHS parameters
params = pickle.load(open("lhs_results/run_29_try0/params.pkl", "rb"))

# Optional: choose a new output folder for clarity
outdir = "checkpoints/reproduced_run_29"

# Run simulation in IDE with the loaded parameters
agents, metrics = run_simulation(
    outdir=outdir,
    resume=False,
    log_metrics=True,
    log_fields=True,
    num_cores=-1,
    params=params,
)
