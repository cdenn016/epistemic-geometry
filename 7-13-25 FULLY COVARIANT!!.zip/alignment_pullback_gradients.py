# -*- coding: utf-8 -*-
"""
Created on Sun Jul 13 20:47:08 2025

@author: chris and christine
"""

# alignment_pullback_gradients.py

import numpy as np
import config
from natural_gradient_utils import apply_natural_gradient_batch
from numerical_utils import sanitize_sigma


def transport_gaussian(mu_j, sigma_j, Omega):
    """
    Transport MVG (mu, sigma) under a linear transformation Omega:
        mu_t = Omega @ mu
        sigma_t = Omega @ sigma @ Omega^T

    Args:
        mu_j:     (..., K)
        sigma_j:  (..., K, K)
        Omega:    (..., K, K)

    Returns:
        mu_t:     (..., K)
        sigma_t:  (..., K, K)
    """
    mu_t = np.einsum("...ij,...j->...i", Omega, mu_j)
    sigma_t = np.einsum("...ij,...jk,...lk->...il", Omega, sigma_j, Omega)
    return mu_t, sigma_t


def kl_gradient_mu_sigma(mu_i, sigma_i, mu_j_t, sigma_j_t, mask=None):
    """
    Compute natural gradient of KL[𝒩(mu_i, sigma_i) || 𝒩(mu_j_t, sigma_j_t)]
    using Fisher preconditioning at q_i = (mu_i, sigma_i).

    Args:
        mu_i:      (..., K)
        sigma_i:   (..., K, K)
        mu_j_t:    (..., K)
        sigma_j_t: (..., K, K)
        mask:      (...,) or None

    Returns:
        delta_mu:     (..., K)
        delta_sigma:  (..., K, K)
    """
    delta_mu = mu_i - mu_j_t
    delta_sigma = 0.5 * (sigma_i - sigma_j_t)

    delta_mu = np.nan_to_num(delta_mu)
    delta_sigma = np.nan_to_num(delta_sigma)

    delta_mu_nat, delta_sigma_nat = apply_natural_gradient_batch(
        mu_i, sigma_i, delta_mu, delta_sigma
    )

    if mask is not None:
        mask = mask[..., None]
        delta_mu_nat *= mask
        delta_sigma_nat *= mask[..., None]

    return delta_mu_nat, delta_sigma_nat


def compute_alignment_kl_gradient(agent_i, agents, generators, params, field_type="belief"):
    """
    Compute covariant natural gradient of:
        F[q_i] = sum_j KL(q_i || Omega_ij q_j)

    Args:
        agent_i:   focal agent
        agents:    all agents
        generators: (d, K, K) Lie algebra basis (unused here but passed for API parity)
        params:    dict of parameters
        field_type: "belief" or "model"

    Returns:
        delta_mu:    (H, W, K)
        delta_sigma: (H, W, K, K)
    """
    beta = params.get("beta", config.beta) if field_type == "belief" else params.get("model_align_weight", config.model_align_weight)
    if beta <= 0:
        return np.zeros_like(agent_i.mu_q_field), np.zeros_like(agent_i.sigma_q_field)

    mu_i     = agent_i.mu_q_field if field_type == "belief" else agent_i.mu_p_field
    sigma_i  = agent_i.sigma_q_field if field_type == "belief" else agent_i.sigma_p_field
    Omega_i  = agent_i._exp_phi if field_type == "belief" else agent_i._exp_phi_model
    Omega_i  = Omega_i.reshape(*mu_i.shape[:-1], mu_i.shape[-1], mu_i.shape[-1])

    delta_mu = np.zeros_like(mu_i)
    delta_sigma = np.zeros_like(sigma_i)

    for nb in agent_i.neighbors:
        agent_j = agents[nb["id"]]

        mu_j = agent_j.mu_q_field if field_type == "belief" else agent_j.mu_p_field
        sigma_j = agent_j.sigma_q_field if field_type == "belief" else agent_j.sigma_p_field
        Omega_j_inv = agent_j._exp_neg_phi if field_type == "belief" else agent_j._exp_neg_phi_model
        Omega_j_inv = Omega_j_inv.reshape(*mu_j.shape[:-1], mu_j.shape[-1], mu_j.shape[-1])

        mask_overlap = (agent_i.mask * agent_j.mask) > config.support_cutoff_eps
        if not np.any(mask_overlap):
            continue

        Omega_ij = np.einsum("...ik,...kj->...ij", Omega_i, Omega_j_inv)

        mu_j_t, sigma_j_t = transport_gaussian(mu_j, sigma_j, Omega_ij)

        # Optional SPD sanitization
        sigma_j_t = sanitize_sigma(sigma_j_t, eps=config.eps)

        delta_mu_step, delta_sigma_step = kl_gradient_mu_sigma(
            mu_i, sigma_i, mu_j_t, sigma_j_t, mask=mask_overlap
        )

        delta_mu += delta_mu_step
        delta_sigma += delta_sigma_step

    return beta * delta_mu, beta * delta_sigma