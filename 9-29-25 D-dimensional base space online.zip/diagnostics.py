
from __future__ import annotations
from typing import Any, Sequence, Dict, Tuple
import numpy as np

from core.transport_cache import plaquette_product  
from core.get_generators import get_generators
from utils import mask_hw
from joblib import Parallel, delayed
from threadpoolctl import threadpool_limits
from runtime_context import energy_acc_get


def _reduce(field: np.ndarray, mask: np.ndarray, kind: str) -> float:
    """
    Broadcast-safe reducer over spatial dims.
    field: arbitrary shape
    mask : broadcastable to field.shape
    kind : "sum" or "mean"
    """
    f = np.asarray(field, np.float32)
    m = np.asarray(mask)

    # Try to broadcast mask to field
    if m.shape != f.shape:
        pad = (1,) * max(0, f.ndim - m.ndim)
        try:
            m = np.broadcast_to(m.reshape(pad + m.shape), f.shape)
        except Exception as e:
            raise ValueError(f"reduce mismatch: field {f.shape} vs mask {m.shape}") from e

    # Treat non-bool masks as soft weights; bool masks as hard support
    if m.dtype == bool:
        if not m.any():
            return 0.0
        if kind == "sum":
            return float(f[m].sum())
        if kind == "mean":
            return float(f[m].mean())
    else:
        w = m.astype(np.float32, copy=False)
        if kind == "sum":
            return float((f * w).sum())
        if kind == "mean":
            tot_w = float(w.sum())
            return 0.0 if tot_w == 0.0 else float((f * w).sum() / tot_w)

    raise ValueError(f"unknown reduce kind {kind}")


def _energy_mass(ctx: Any, agent: Any) -> Tuple[float, float, float, float]:
    """
    Returns (mass_q_sum, mass_q_mean, mass_p_sum, mass_p_mean) for N-D grids.
    Uses squared norm of φ and φ̃ per pixel, masked by agent.mask (broadcastable).
    """
    import numpy as np

    cfg = getattr(ctx, "step_cfg", None)
    tau = float(getattr(cfg, "support_tau", 1e-6))
    wq  = float(getattr(cfg, "belief_mass", 0.0))
    wp  = float(getattr(cfg, "model_mass",  0.0))

    # fields
    phi_q = np.asarray(getattr(agent, "phi"), np.float32)          # (*S, 3)
    phi_p = getattr(agent, "phi_model", None)
    if phi_p is not None:
        phi_p = np.asarray(phi_p, np.float32)                      # (*S, 3)

    if phi_q.ndim < 1 or phi_q.shape[-1] != 3:
        raise ValueError(f"phi_field must be (*S,3), got {phi_q.shape}")
    if (phi_p is not None) and (phi_p.shape != phi_q.shape):
        raise ValueError(f"phi_model shape {phi_p.shape} != phi shape {phi_q.shape}")

    # spatial mask — allow any broadcastable shape; threshold if float
    raw_mask = getattr(agent, "mask", None)
    if raw_mask is None:
        mask = np.ones(phi_q.shape[:-1], dtype=bool)               # (*S,)
    else:
        m = np.asarray(raw_mask)
        # Threshold soft masks to hard support for consistency with your old code
        if m.dtype != bool:
            mask = (m > tau)
        else:
            mask = m

    # per-pixel squared norms
    m_q = (phi_q ** 2).sum(axis=-1)                                # (*S,)
    if phi_p is not None:
        m_p = (phi_p ** 2).sum(axis=-1)                            # (*S,)
    else:
        m_p = np.zeros_like(m_q)

    return (
        wq * _reduce(m_q, mask, "sum"),
        wq * _reduce(m_q, mask, "mean"),
        wp * _reduce(m_p, mask, "sum"),
        wp * _reduce(m_p, mask, "mean"),
    )


def _energy_curvature(ctx: Any, agent: Any) -> Tuple[float, float, float, float]:
    """
    Returns (curv_q_sum, curv_q_mean, curv_p_sum, curv_p_mean).

    N-D backend: for spatial rank M>=2, use plaquettes over all axis pairs (a<b):
      P_ab(i) = U_a(i) · U_b(i+ê_a) · U_a(i+ê_b)^T · U_b(i)^T
    Site magnitude per pair: ||P_ab - I||_F^2, then average across pairs.

    Shapes:
      phi, phi_model : (*S, 3)
      P_ab           : (*S, K, K)
      fq, fp         : (*S,)
    """
    import numpy as np

    cfg = getattr(ctx, "step_cfg", None)
    tau = float(getattr(cfg, "support_tau", 1e-6))
    wq  = float(getattr(cfg, "curvature_weight", 0.0))
    wp  = float(getattr(cfg, "model_curvature_weight", 0.0))

    # mask: keep your existing helper; _reduce will broadcast to N-D
    mask = mask_hw(agent.mask, tau=tau, mode="bool2")
    if not np.asarray(mask).any():
        return 0.0, 0.0, 0.0, 0.0

    # --- spatial rank ---
    phi_q = np.asarray(agent.phi, np.float32)  # (*S, 3)
    if phi_q.ndim < 1 or phi_q.shape[-1] != 3:
        raise ValueError(f"phi_field must be (*S,3), got {phi_q.shape}")
    S = phi_q.shape[:-1]
    M = len(S)

    if M < 2:
        # No plaquettes in 1-D; curvature is zero.
        return 0.0, 0.0, 0.0, 0.0

    # list all spatial axis pairs
    pairs = [(a, b) for a in range(M) for b in range(a + 1, M)]
    num_pairs = len(pairs)

    # --- belief side (q) ---
    Gq = get_generators(agent, "q")
    fq_parts = []
    for pair in pairs:
        Pq = plaquette_product(ctx, phi_q, Gq, split_edge=True, pair=pair)  # (*S, K, K)
        if Pq.ndim < 2 or Pq.shape[-1] != Pq.shape[-2]:
            raise ValueError(f"Invalid plaquette (q) shape {Pq.shape}")
        Kq = int(Pq.shape[-1])
        Dq = Pq - np.eye(Kq, dtype=np.float32)  # (*S, K, K)
        fq_parts.append(np.einsum("...ij,...ij->...", Dq, Dq, optimize=True))  # (*S,)

    # average over pairs to keep scale dimension-invariant
    fq = sum(fq_parts) / float(num_pairs)  # (*S,)

    # --- model side (p) ---
    fq_sum = wq * _reduce(fq, mask, "sum")
    fq_mean = wq * _reduce(fq, mask, "mean")

    phi_p = getattr(agent, "phi_model", None)
    if phi_p is None:
        fp_sum = 0.0
        fp_mean = 0.0
    else:
        phi_p = np.asarray(phi_p, np.float32)
        if phi_p.shape != phi_q.shape:
            raise ValueError(f"phi_model shape {phi_p.shape} != phi shape {phi_q.shape}")
        Gp = get_generators(agent, "p")
        fp_parts = []
        for pair in pairs:
            Pp = plaquette_product(ctx, phi_p, Gp, split_edge=True, pair=pair)  # (*S, K, K)
            if Pp.ndim < 2 or Pp.shape[-1] != Pp.shape[-2]:
                raise ValueError(f"Invalid plaquette (p) shape {Pp.shape}")
            Kp = int(Pp.shape[-1])
            Dp = Pp - np.eye(Kp, dtype=np.float32)
            fp_parts.append(np.einsum("...ij,...ij->...", Dp, Dp, optimize=True))
        fp = sum(fp_parts) / float(num_pairs)

        fp_sum = wp * _reduce(fp, mask, "sum")
        fp_mean = wp * _reduce(fp, mask, "mean")

    return fq_sum, fq_mean, fp_sum, fp_mean


# --- diagnostics.py ---

def total_energy(ctx: Any,
                 agents: Any,
                 *,
                 return_breakdown: bool = False,
                 precomputed_metrics: Dict[str, float] | None = None
                 ) -> float | Tuple[float, Dict[str, float]]:
    """
    Variational energy minimized by the suite.

    If precomputed_metrics is provided, it should be the dict returned by
    compute_global_metrics(ctx, agents); we will skip recomputing it.
    """
    M = precomputed_metrics if precomputed_metrics is not None else compute_global_metrics(ctx, agents)
    E = float(M.get("E_total", 0.0))

    if not return_breakdown:
        return E

    breakdown = {
        "self":       float(M.get("self_sum",     0.0)),
        "feedback":   float(M.get("feedback_sum", 0.0)),
        "align_q":    float(M.get("align_q_sum",  0.0)),
        "align_p":    float(M.get("align_p_sum",  0.0)),
        "mass_q":     float(M.get("mass_q_sum",   0.0)),
        "mass_p":     float(M.get("mass_p_sum",   0.0)),
        "curv_q":     float(M.get("curv_q_sum",   0.0)),
        "curv_p":     float(M.get("curv_p_sum",   0.0)),
        "mean_total": float(M.get("mean_total",   0.0)),
    }
    return E, breakdown





def print_action_breakdown(ctx, action_dict, *, stream=None):
    step = int(getattr(ctx, "global_step", -1))
    lines = []
    lines.append(f"[Action @ step {step}]")
    lines.append(f"  Action_total = {action_dict.get('Action_total', 0.0):.6e}")
    lines.append("  ---------------------------------------")
    lines.append(f"  Geom_total   = {action_dict.get('Geom_total', 0.0):.6e}")
   
    lines.append(f"  A_curv       = {action_dict.get('A_curv', 0.0):.6e}  ")
    lines.append(f"  A_cov        = {action_dict.get('A_cov', 0.0):.6e}")
   
    print("\n".join(lines), flush=True)


def print_energy_breakdown(ctx, metrics, *, hide_zero_weight=True):
    """
    Print a consistent table:
      raw_sum, mean_per_px, weight, weighted_sum (= raw_sum * weight)
    Rows with weight==0 can be hidden unless debug asks otherwise.
    """
    cfg = getattr(ctx, "step_cfg", None)

    alpha  = float(getattr(cfg, "alpha", 0.0))
    lambd  = float(getattr(cfg, "feedback_weight", 0.0))
    beta_q = float(getattr(cfg, "beta", 0.0))
    beta_p = float(getattr(cfg, "beta_model", 0.0))
   
    w_align_q =  beta_q
    w_align_p =  beta_p

    rows = [
        ("self",      metrics.get("self_sum", 0.0),      metrics.get("self_mean", 0.0),      alpha),
        ("align_q",   metrics.get("align_q_sum", 0.0),   metrics.get("align_q_mean", 0.0),   w_align_q),
        ("align_p",   metrics.get("align_p_sum", 0.0),   metrics.get("align_p_mean", 0.0),   w_align_p),
        ("feedback",  metrics.get("feedback_sum", 0.0),  metrics.get("feedback_mean", 0.0),  lambd),
        ("mass_q",    metrics.get("mass_q_sum", 0.0),    metrics.get("mass_q_mean", 0.0),    1.0),
        ("mass_p",    metrics.get("mass_p_sum", 0.0),    metrics.get("mass_p_mean", 0.0),    1.0),
        ("curv_q",    metrics.get("curv_q_sum", 0.0),    metrics.get("curv_q_mean", 0.0),    1.0),
        ("curv_p",    metrics.get("curv_p_sum", 0.0),    metrics.get("curv_p_mean", 0.0),    1.0),
    ]

    print("\n[Energy Totals @ step {}]".format(int(getattr(ctx, "global_step", -1))))
    print("  E_total = {: .6e}  |  mean_total = {: .6e}".format(
        float(metrics.get("E_total", 0.0)),
        float(metrics.get("mean_total", 0.0)),
    ))
    print("  " + "-"*52)


    print("  {:<12} {:>14} {:>18} {:>8}".format("term", "raw_sum", "mean_per_px", "weight") +
          "   {:>14}".format("weighted_sum"))
    for name, raw_sum, mean_px, w in rows:
        if hide_zero_weight and (w == 0.0):
            # still show if raw is nonzero and you want visibility:
            # if abs(raw_sum) > 0: pass
            continue
        weighted = raw_sum * w
        print("  {:<12} {:>14.6e} {:>18.6e} {:>8g}   {:>14.6e}".format(
            name, float(raw_sum), float(mean_px), w, float(weighted)
        ))
    print()


def compute_agent_metrics(ctx: Any, agent: Any) -> Dict[str, float]:
    """
    Returns per-agent RAW (unweighted) energy components.
    We keep self/feedback unweighted here to mirror alignment’s convention.
    Mass/curv are also raw; weighting (if any) is applied in compute_global_metrics.
    """
    cfg = getattr(ctx, "step_cfg", None)
    tau = float(getattr(cfg, "support_tau", 1e-6)) if cfg is not None else 1e-6
    m = mask_hw(getattr(agent, "mask", None), tau=tau, mode="bool2")
    if (m is None) or (not np.any(m)):
        return {
            "self_sum": 0.0, "self_mean": 0.0,
            "feedback_sum": 0.0, "feedback_mean": 0.0,
            "mass_q_sum": 0.0, "mass_q_mean": 0.0,
            "mass_p_sum": 0.0, "mass_p_mean": 0.0,
            "curv_q_sum": 0.0, "curv_q_mean": 0.0,
            "curv_p_sum": 0.0, "curv_p_mean": 0.0,
        }

    S = int(np.count_nonzero(m)) or 1

    # Prefer per-agent accumulators populated earlier (raw, unweighted)
    aid = getattr(agent, "id", None)
    self_sum = fb_sum = 0.0
    if aid is not None:
        v = energy_acc_get(ctx, f"self_sum[{aid}]", None)
        if v is not None: self_sum = float(v)
        v = energy_acc_get(ctx, f"feedback_sum[{aid}]", None)
        if v is not None: fb_sum = float(v)

    self_mean = self_sum / S
    fb_mean   = fb_sum   / S

    # Mass/curvature are computed here (raw)
    mass_q_sum, mass_q_mean, mass_p_sum, mass_p_mean = _energy_mass(ctx, agent)
    curv_q_sum, curv_q_mean, curv_p_sum, curv_p_mean = _energy_curvature(ctx, agent)

    return {
        "self_sum": self_sum, "self_mean": self_mean,
        "feedback_sum": fb_sum, "feedback_mean": fb_mean,
        "mass_q_sum": mass_q_sum, "mass_q_mean": mass_q_mean,
        "mass_p_sum": mass_p_sum, "mass_p_mean": mass_p_mean,
        "curv_q_sum": curv_q_sum, "curv_q_mean": curv_q_mean,
        "curv_p_sum": curv_p_sum, "curv_p_mean": curv_p_mean,
    }



def compute_global_metrics(ctx: Any, agents: Sequence[Any]) -> Dict[str, float]:
    cfg     = getattr(ctx, "step_cfg", None)
    tau     = cfg.support_tau
    n_jobs  = int(getattr(cfg, "metrics_n_jobs", 1))

    # Weights & options
    alpha   = float(getattr(cfg, "alpha", 0.0))
    lambd   = float(getattr(cfg, "feedback_weight", 0.0))
    beta_q  = float(getattr(cfg, "beta", 0.0))
    beta_p  = float(getattr(cfg, "beta_model", 0.0))
    

    def _one(a):
        m = mask_hw(a.mask, tau=tau, mode="bool2")
        S = int(np.count_nonzero(m))
        if S <= 0:
            return None
        d = compute_agent_metrics(ctx, a)  # RAW values
        return d, S

    with threadpool_limits(1):
        outs = Parallel(n_jobs=max(1, n_jobs), backend="threading", batch_size="auto")(
            delayed(_one)(a) for a in agents
        )

    totals = {"self_sum":0.0,"feedback_sum":0.0,"mass_q_sum":0.0,"mass_p_sum":0.0,
              "curv_q_sum":0.0,"curv_p_sum":0.0,"_S":0}

    for res in outs:
        if res is None:
            continue
        d, S = res
        for k in ("self_sum","feedback_sum","mass_q_sum","mass_p_sum","curv_q_sum","curv_p_sum"):
            totals[k] += float(d[k])
        totals["_S"] += int(S)

    # Alignment RAW totals from the per-step accumulator (unweighted)
    aq = energy_acc_get(ctx, "align_q_sum", 0.0)
    ap = energy_acc_get(ctx, "align_p_sum", 0.0)
    align_q_sum_raw = float(aq or 0.0)
    align_p_sum_raw = float(ap or 0.0)

    S_tot = max(totals["_S"], 1)

    # Raw means
    out = dict(totals)
    out["self_mean"]     = out["self_sum"]     / S_tot
    out["feedback_mean"] = out["feedback_sum"] / S_tot
    out["mass_q_mean"]   = out["mass_q_sum"]   / S_tot
    out["mass_p_mean"]   = out["mass_p_sum"]   / S_tot
    out["curv_q_mean"]   = out["curv_q_sum"]   / S_tot
    out["curv_p_mean"]   = out["curv_p_sum"]   / S_tot

    # Weighted alignment
    w_align_q = beta_q
    w_align_p = beta_p
    out["align_q_sum"]  = align_q_sum_raw
    out["align_p_sum"]  = align_p_sum_raw
    out["align_q_mean"] = align_q_sum_raw / S_tot
    out["align_p_mean"] = align_p_sum_raw / S_tot

    # Weighted totals (final energy)
    self_w     = alpha * out["self_sum"]
    feedback_w = lambd * out["feedback_sum"]
    align_q_w  = w_align_q * out["align_q_sum"]
    align_p_w  = w_align_p * out["align_p_sum"]

    mass_q_w = out["mass_q_sum"]   # keep as-is unless you add a separate weight
    mass_p_w = out["mass_p_sum"]
    curv_q_w = out["curv_q_sum"]
    curv_p_w = out["curv_p_sum"]

    out["E_total"] = float(
        self_w + feedback_w +
        mass_q_w + mass_p_w +
        curv_q_w + curv_p_w +
        align_q_w + align_p_w
    )

    out["mean_total"] = float(
        (alpha  * out["self_mean"])     +
        (lambd  * out["feedback_mean"]) +
        (w_align_q * out["align_q_mean"]) +
        (w_align_p * out["align_p_mean"]) +
        out["mass_q_mean"] + out["mass_p_mean"] +
        out["curv_q_mean"] + out["curv_p_mean"]
    )

    # (Optional) also expose weighted breakdowns for logging
    out.update({
        "self_sum_w": self_w, "feedback_sum_w": feedback_w,
        "align_q_sum_w": align_q_w, "align_p_sum_w": align_p_w,
    })

    return out



def compute_total_action(ctx, agents, precomputed_metrics=None):
    
    # 1) Geometric piece
    M_geom = precomputed_metrics if (precomputed_metrics is not None) \
             else compute_global_metrics(ctx, agents)
    A_geom = float(M_geom.get("E_total", 0.0))

    
    # 4) A terms (unchanged)
    fields = getattr(ctx, "fields", {}) or {}
    A_cov = float(fields.get("A_cov_energy_last", 0.0))
    A_curv = float(fields.get("A_curv_energy", 0.0))
    A_tot = float(A_geom + A_curv + A_cov )

    return {
        "Action_total": A_tot,
        "Geom_total":   A_geom,
        "A_curv":       A_curv,
        "A_cov":        A_cov,       
        "self_sum":     float(M_geom.get("self_sum", 0.0)),
        "feedback_sum": float(M_geom.get("feedback_sum", 0.0)),
        "align_q_sum":  float(M_geom.get("align_q_sum", 0.0)),
        "align_p_sum":  float(M_geom.get("align_p_sum", 0.0)),
        "mass_q_sum":   float(M_geom.get("mass_q_sum", 0.0)),
        "mass_p_sum":   float(M_geom.get("mass_p_sum", 0.0)),
        "curv_q_sum":   float(M_geom.get("curv_q_sum", 0.0)),
        "curv_p_sum":   float(M_geom.get("curv_p_sum", 0.0)),
    }


def _fiber_maps(ctx, which: str):
    """Fetch β/ KL maps and cfg for a fiber ('q' or 'p')."""
    if which not in ("q", "p"):
        raise ValueError(f"which must be 'q' or 'p', got {which}")
    beta_map = getattr(ctx, "_edge_beta_q" if which == "q" else "_edge_beta_p", {}) or {}
    kl_map   = getattr(ctx, "_edge_kl_q"   if which == "q" else "_edge_kl_p", {}) or {}
    cfg      = getattr(ctx, "_edge_beta_cfg", {}) or {}
    sub      = cfg.get(which, {})
    kappa    = float(sub.get("kappa", 1.0))
    mode     = str(sub.get("mode", "softmax")).lower()
    detach   = bool(cfg.get("detach", True))
    return beta_map, kl_map, {"kappa": kappa, "mode": mode, "detach": detach}


def summarize_beta_fiber(ctx, agents, *, which: str = "q") -> dict:
    """
    Returns a summary dict for β on a fiber:
      - n_edges, per-receiver softmax deviations, β min/mean/max, KL stats.
    Hard-fail if it encounters NaN/∞ or inconsistent shapes.
    """
    import numpy as np

    beta_map, kl_map, cfg = _fiber_maps(ctx, which)
    ids = [int(getattr(a, "id", i)) for i, a in enumerate(agents)]

    rec_stats = {}
    beta_vals = []
    kl_vals   = []

    # --- group β by receiver -----------------------------------------------
    by_recv = {}
    for (i_id, j_id), B in beta_map.items():
        b = np.asarray(B, np.float32)
        if not np.all(np.isfinite(b)):
            raise FloatingPointError(
                f"[β/{which}] non-finite values in edge (i={i_id}, j={j_id})"
            )
        by_recv.setdefault(int(i_id), []).append((int(j_id), b))

    # --- per-receiver checks ------------------------------------------------
    for i_id, lst in by_recv.items():
        if not lst:
            continue

        B_stack = np.stack([b for _, b in lst], axis=0)  # (J,*S)
        if not np.all(np.isfinite(B_stack)):
            raise FloatingPointError(f"[β/{which}] NaN/∞ in receiver {i_id}")

        s = np.sum(B_stack, axis=0)                      # (*S,)
        overlap_any = np.any(B_stack > 0, axis=0)        # (*S,) bool
        if overlap_any.size == 0:
            raise ValueError(f"[β/{which}] empty overlap mask for receiver {i_id}")

        if cfg["mode"] in ("softmax", "sm", "normexp"):
            err = np.abs(s - 1.0)
            dev_mean = float(err[overlap_any].mean())
            dev_max  = float(err[overlap_any].max())
        else:
            dev_mean = dev_max = 0.0

        # collect β and KL values on overlap
        beta_vals.extend(B_stack[:, overlap_any].ravel().tolist())
        for (j_id, _) in lst:
            K = kl_map.get((i_id, j_id))
            if K is None:
                continue
            K = np.asarray(K, np.float32)
            if K.shape != s.shape:
                raise ValueError(
                    f"[β/{which}] KL shape {K.shape} != β shape {s.shape} "
                    f"(i={i_id}, j={j_id})"
                )
            if not np.all(np.isfinite(K)):
                raise FloatingPointError(
                    f"[β/{which}] NaN/∞ in KL map (i={i_id}, j={j_id})"
                )
            kl_vals.extend(K[overlap_any].ravel().tolist())

        rec_stats[i_id] = {
            "senders": len(lst),
            "softmax_dev_mean": dev_mean,
            "softmax_dev_max":  dev_max,
        }

    if not beta_vals:
        raise RuntimeError(f"[β/{which}] no valid β values collected")

    if not kl_vals:
        raise RuntimeError(f"[β/{which}] no valid KL values collected")

    beta_arr = np.asarray(beta_vals, np.float32)
    kl_arr   = np.asarray(kl_vals,   np.float32)

    return {
        "fiber": which,
        "mode": str(cfg.get("mode")),
        "kappa": float(cfg.get("kappa")),
        "detach": bool(cfg.get("detach")),
        "n_edges": len(beta_map),
        "n_receivers": len(rec_stats),
        "receivers": rec_stats,
        "beta_min": float(beta_arr.min()),
        "beta_mean": float(beta_arr.mean()),
        "beta_max": float(beta_arr.max()),
        "kl_min":   float(kl_arr.min()),
        "kl_med":   float(np.median(kl_arr)),
        "kl_mean":  float(kl_arr.mean()),
        "kl_max":   float(kl_arr.max()),
    }


def print_beta_summary(ctx, agents):
    """
    Pretty-print both fibers’ β statistics.
    Raises immediately if summarize_beta_fiber detects any invalid data.
    """
    q = summarize_beta_fiber(ctx, agents, which="q")
    p = summarize_beta_fiber(ctx, agents, which="p")
    step = int(getattr(ctx, "global_step", -1))

    def _fmt(f):
        return (
            f"\n[β/{f['fiber']} | step {step}] "
            f"mode={f['mode']} κ={f['kappa']:.3g} detach={f['detach']} "
            f"| edges={f['n_edges']} recv={f['n_receivers']}\n"
            f"β[min/mean/max] = {f['beta_min']:.3g} / {f['beta_mean']:.3g} / {f['beta_max']:.3g}\n"
            f"KL[min/med/mean/max] = {f['kl_min']:.3g} / {f['kl_med']:.3g} / "
            f"{f['kl_mean']:.3g} / {f['kl_max']:.3g}\n"
        )

    print(_fmt(q))
    print(_fmt(p))

    for f in (q, p):
        if f["mode"] not in ("softmax", "sm", "normexp"):
            continue
        worst = max(
            ((s["softmax_dev_max"], i_id) for i_id, s in f["receivers"].items()),
            default=None,
        )
        if worst and worst[0] > 1e-3:
            raise RuntimeError(
                f"[β/{f['fiber']}] worst softmax deviation {worst[0]:.3e} "
                f"at receiver i={worst[1]}"
            )



