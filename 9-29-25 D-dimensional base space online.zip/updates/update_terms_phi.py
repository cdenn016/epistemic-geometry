
import numpy as np
from core.numerical_utils import safe_inv, sanitize_sigma, safe_omega_inv
from core.transport_cache import (build_dexpinv_matrix , Jinv_grid, E_grid, Omega, 
                                  exp_and_jinv_single, Phi_cached )
import core.config as config
from core.omega import d_exp_exact
from runtime_context import cfg_get
from utils import ( log_phi_grad_like, _joint_mask, reg_weights, _aid, push_neighbor_stats,
                   mask_hw, build_c_mapping_q2p)
from core.numerical_utils import push_gaussian

from beta import beta_effective_weight
#==============================================================================
#
#                    GATHER PHI GAUGE FIELD GRADIENT TERMS
#                          Beliefs and Models
#==============================================================================


def accumulate_phi_alignment_gradient(
    ctx,                              # required
    agent_i, agent_j, generators,
    *,
    field: str = "phi",
    beta_key: str | None = None,
    omega_cache_key: str | None = None,
    mu_key: str | None = None,
    sigma_key: str | None = None,
    fisher_inv_key: str | None = None,
    grad_key: str | None = None,
    Q_all_i=None,
    exp_neg_phi_j=None,
    agents=None,            # for Fisher regularizer
):
    import numpy as np

    assert mu_key and sigma_key and fisher_inv_key and grad_key, \
        "mu_key/sigma_key/fisher_inv_key/grad_key are required"

    eps = float(cfg_get(ctx, "eps", 1e-8))
    tau = float(cfg_get(ctx, "support_tau", 1e-6))
    which = "q" if field == "phi" else "p"

    # ---- fields (fail-fast on finiteness & define S) ----
    mu_i    = np.asarray(getattr(agent_i, mu_key),    np.float32)
    sigma_i = np.asarray(getattr(agent_i, sigma_key), np.float32)
    if not np.isfinite(mu_i).all():    raise FloatingPointError("non-finite mu_i")
    if not np.isfinite(sigma_i).all(): raise FloatingPointError("non-finite sigma_i")

    if mu_i.ndim < 1 or mu_i.shape[-1] != mu_i.shape[-1]:
        raise ValueError(f"mu_i has bad shape {mu_i.shape}")
    S = tuple(mu_i.shape[:-1])   # arbitrary spatial shape (*S,)

    # ---- N-D joint mask over S (no 2-D helpers) ----
    mi = np.asarray(getattr(agent_i, "mask"), np.float32)
    mj = np.asarray(getattr(agent_j, "mask"), np.float32)
    if tuple(mi.shape) != S or tuple(mj.shape) != S:
        raise ValueError(f"mask shapes {mi.shape}, {mj.shape} != spatial shape {S}")
    if not (np.isfinite(mi).all() and np.isfinite(mj).all()):
        raise FloatingPointError("non-finite values in masks")

    joint_mask = (mi > tau) & (mj > tau)   # shape S, bool
    if not np.any(joint_mask):
        return

    # ---- effective β weight s_ij(x) over S ----
    i_id = int(getattr(agent_i, "id", -1))
    j_id = int(getattr(agent_j, "id", -1))
    w = beta_effective_weight(ctx, i_id, j_id, which=("q" if field == "phi" else "p"),
                              joint_mask=joint_mask.astype(np.float32))
    w = np.asarray(w, np.float32)
    if tuple(w.shape) != S:
        raise ValueError(f"beta weight shape {w.shape} != {S}")
    if not np.isfinite(w).all():
        raise FloatingPointError("non-finite beta weight")
    if not np.any(w > 1e-8):
        return

    # ---- transports / frames ----
    E_i = E_grid(ctx, agent_i, which=which)
    E_j = E_grid(ctx, agent_j, which=which)
    Omega_ij = Omega(ctx, agent_i, agent_j, which=which)

    # neighbor stats in i-frame
    mu_j_t, Sigma_j_t, sigma_j_t_inv = push_neighbor_stats(agent_j, sigma_key, Omega_ij, eps)

    # ---- d exp bits ----
    phi_i = np.asarray(getattr(agent_i, field), np.float32)
    if tuple(phi_i.shape[:-1]) != S or phi_i.shape[-1] != 3:
        raise ValueError(f"phi_i shape {phi_i.shape} incompatible with S={S} and dim=3")

    if Q_all_i is None:
        Q_all_i = d_exp_exact(phi_i, generators)
    if exp_neg_phi_j is None:
        exp_neg_phi_j = safe_omega_inv(E_j)

    # ---- raw param-space covector grad (per-pixel, 3) ----
    grad_param = grad_kl_wrt_phi_i(
        mu_i, sigma_i,
        None, None,
        phi_i=phi_i,
        phi_j=None,
        Omega_ij=Omega_ij,
        generators=generators,
        exp_phi_i=E_i,
        exp_phi_j=E_j,
        mu_j_t=mu_j_t,
        sigma_j_t_inv=sigma_j_t_inv,
        eps=eps,
        exp_neg_phi_j=exp_neg_phi_j,
        Q_all=Q_all_i,
    ).astype(np.float32, copy=False)
    if tuple(grad_param.shape) != S + (3,):
        raise ValueError(f"grad_param shape {grad_param.shape} != {S+(3,)}")
    if not np.isfinite(grad_param).all():
        raise FloatingPointError("non-finite grad_param")

    # ---- Jinv^T projection → body covector ----
    Jinv = Jinv_grid(ctx, agent_i, which=which)
    if Jinv is None:
        Jinv = build_dexpinv_matrix(phi_i)
    if tuple(Jinv.shape) != S + (3, 3):
        raise ValueError(f"Jinv shape {Jinv.shape} != {S+(3,3)}")
    if not np.isfinite(Jinv).all():
        raise FloatingPointError("non-finite Jinv")

    g_body_cov = np.einsum("...ji,...j->...i", Jinv, grad_param, optimize=True)
    if not np.isfinite(g_body_cov).all():
        raise FloatingPointError("non-finite g_body_cov")

    # ---- Fisher^{-1} (body) ----
    F_inv = getattr(agent_i, fisher_inv_key, None)
    if F_inv is None:
        raise RuntimeError(f"{fisher_inv_key} missing on agent {i_id}")
    F_inv = np.asarray(F_inv, np.float32)
    if tuple(F_inv.shape) != S + (3, 3):
        raise ValueError(f"F_inv shape {F_inv.shape} != {S+(3,3)}")
    if not np.isfinite(F_inv).all():
        raise FloatingPointError("non-finite F_inv")

    v_body = np.einsum("...ab,...b->...a", F_inv, g_body_cov, optimize=True)

    # ---- Lie-natural regularizers (body) ----
    v_body_total = _apply_lie_natural_regularizers(agent_i, field, generators, ctx, v_body, agents=agents)
    if not np.isfinite(v_body_total).all():
        raise FloatingPointError("non-finite v_body_total")

    # ---- map back to parameter vector ----
    v_param = np.einsum("...ab,...b->...a", Jinv, v_body_total, optimize=True)  # S+(3,)
    if not np.isfinite(v_param).all():
        raise FloatingPointError("non-finite v_param")

    # ---- per-pixel effective weight & accumulate ----
    contrib = w[..., None] * v_param                                     # S+(3,)
    prev = getattr(agent_i, grad_key, None)
    if prev is None:
        prev = np.zeros_like(contrib, dtype=np.float32)
    setattr(agent_i, grad_key, prev + contrib)

    # ---- energy accounting (use N-D mask) ----
    accumulate_alignment_energy(
        ctx, agent_i, agent_j,
        field=field,
        joint_mask=joint_mask,     # shape S, bool
        mu_i=mu_i, sigma_i=sigma_i,
        mu_j_t=mu_j_t,
        sigma_j_t=Sigma_j_t,
        eps=eps,
    )

    PRINT_SIGN = False
    if PRINT_SIGN:
        aid  = _aid(agent_i)
        ajid = getattr(agent_j, "id", "?")
        spatial_axes = tuple(range(contrib.ndim - 1))
        g_mean = np.nanmean(contrib, axis=spatial_axes)
        def _sgn(x): return "+" if x > 0 else ("-" if x < 0 else "0")
        
        g_abs_mean = float(np.nanmean(np.abs(contrib)))
        print(f"[PHI-GRAD] field={field} ai={aid} aj={ajid} β={w:.3g} "
              f"mean={np.array2string(g_mean, precision=3, suppress_small=True)} "
              f"|g|_mean={g_abs_mean:.3e}", flush=True)




def accumulate_alignment_energy(
    ctx,
    agent_i, agent_j,
    *,
    field: str,                  # "phi" or "phi_model"
    joint_mask,                  # boolean/broadcastable vector for active pixels
    mu_i, sigma_i,               # Ai's μ/Σ (already sliced/broadcasted as in grad path)
    mu_j_t,
    sigma_j_t: np.ndarray | None = None,        # NEW: covariance in i-frame
    sigma_j_t_inv: np.ndarray | None = None,    # kept for back-compat
    eps: float = 1e-8,
    per_agent: bool | None = None,
):
    import numpy as np
    from runtime_context import energy_acc_add
    from core.numerical_utils import kl_gaussian, safe_inv, sanitize_sigma

    mu_i = np.asarray(mu_i, np.float64, order="C")
    Si   = sanitize_sigma(np.asarray(sigma_i, np.float64, order="C"), eps=max(eps, 1e-10))

    if sigma_j_t is not None:
        Sj_t = sanitize_sigma(np.asarray(sigma_j_t, np.float64, order="C"), eps=max(eps, 1e-10))
    else:
        print("sigma-j-t is NONE!!!\n\n\n\n")
        A = np.asarray(sigma_j_t_inv, np.float64, order="C")
        A = 0.5 * (A + np.swapaxes(A, -1, -2))
        # simple SPD projection via covariance sanitizer (works for precision too)
        A = sanitize_sigma(A, eps=max(eps, 1e-10))
        Sj_t = safe_inv(A, eps=max(eps, 1e-10))

    kl_px = kl_gaussian(mu_i, Si, mu_j_t, Sj_t, eps=max(eps, 1e-10))  # (...,)

    # --- broadcast joint_mask to kl_px.shape (no reshape assumptions) ---
    def _bcast_mask_like(mask, ref):
        if mask is None:
            return np.ones_like(ref, dtype=np.float64)
        m = np.asarray(mask)
        # fast path: already same shape
        if m.shape == ref.shape:
            return m.astype(np.float64, copy=False)
        # try direct broadcast
        try:
            return np.broadcast_to(m, ref.shape).astype(np.float64, copy=False)
        except Exception:
            # try by prepending singleton axes
            pad = (1,) * max(0, ref.ndim - m.ndim)
            try:
                m2 = m.reshape(pad + m.shape)
                return np.broadcast_to(m2, ref.shape).astype(np.float64, copy=False)
            except Exception as e:
                raise ValueError(
                    f"joint_mask shape {m.shape} not broadcastable to {ref.shape}"
                ) from e

    m = _bcast_mask_like(joint_mask, kl_px)
    align_sum = float(np.sum(kl_px * m))

   

    bucket = "align_q_sum" if field == "phi" else "align_p_sum"
    energy_acc_add(ctx, bucket, align_sum)

    if per_agent is None:
        per_agent = bool(getattr(getattr(ctx, "step_cfg", None), "align_track_per_agent", False))
    if per_agent:
        aid = getattr(agent_i, "id", None)
        if aid is not None:
            energy_acc_add(ctx, f"{bucket}[{aid}]", align_sum)

    return align_sum








def grad_kl_wrt_phi_i(
    mu_i, sigma_i,
    mu_j, sigma_j,                 # unused; kept for signature compatibility
    phi_i, phi_j,                  # unused here
    Omega_ij,
    generators,
    exp_phi_i,
    exp_phi_j,
    mu_j_t,                        
    sigma_j_t_inv,                 
    eps=1e-8,
    exp_neg_phi_j=None,
    Q_all=None,
):
        
    # ---- cast to f64 for internal math ----
    mu_i   = np.asarray(mu_i,   np.float64)
    mu_j_t = np.asarray(mu_j_t, np.float64)

    Sigma_i = sanitize_sigma(np.asarray(sigma_i, np.float64), eps=eps)
   
    # Q_all → (..., a, K, K)
    if Q_all is None:
        Q_all = d_exp_exact(np.asarray(phi_i, np.float64), generators)
    
    Q = np.stack([np.asarray(x, np.float64) for x in Q_all], axis=-3)

    # exp(-phi_j) broadcast to Q lead dims
    if exp_neg_phi_j is None:
        exp_neg_phi_j = safe_omega_inv(np.asarray(exp_phi_j, np.float64))
   
    # Ω and Ω^{-1}
    Om   = np.asarray(Omega_ij, np.float64)
    Oinv = safe_omega_inv(Om).astype(np.float64, copy=False)

    # Sanity on provided precision
    Sj_inv = np.asarray(sigma_j_t_inv, np.float64)
    
    Sj_inv = 0.5 * (Sj_inv + np.swapaxes(Sj_inv, -1, -2))
    
    # Core pieces
    delta_mu = (mu_i - mu_j_t)                     # (..., K)
    mu_j_src = np.einsum("...ij,...j->...i", Oinv, mu_j_t, optimize=True)  # (..., K)

    # dΩ/dφ_i^a = Q[a] @ e^{-φ_j}
    Q = np.einsum("...aik,...kj->...aij", Q, exp_neg_phi_j, optimize=True)
    Q_T = np.swapaxes(Q, -1, -2)
   
    # dΩ Ω^{-1}
    Q_tilde   = np.einsum("...aik,...kj->...aij", Q, Oinv, optimize=True)  
    Qtilde_T  = np.swapaxes(Q_tilde, -1, -2)
    
    # ---- precision (trace) term:  -1/2 * ⟨ A, Q̃ Σ_i + Σ_i Q̃^T ⟩
    t1 = np.einsum("...ij,...ajk,...ki->...a", Sj_inv, Q_tilde,  Sigma_i, optimize=True)
    t2 = np.einsum("...aij,...jk, ...ki->...a", Qtilde_T, Sj_inv, Sigma_i, optimize=True)
    trace_term = -0.5 * (t1 + t2)
    
    # mean term
    tmp1 = np.einsum("...aij,...j->...ai", Q_T,    delta_mu, optimize=True)
    tmp2 = np.einsum("...ij,...aj->...ai", Sj_inv, tmp1,     optimize=True)
    mean_term = -np.einsum("...i,...ai->...a", mu_j_src, tmp2, optimize=True)
    
    # ---- Mahalanobis (through ∂A) term: +1/2 * Δμ^T ( A Q̃ + Q̃^T A ) Δμ
    v1 = np.einsum("...ij,...j->...i", Sj_inv, delta_mu, optimize=True)          # A Δμ
    part1 = np.einsum("...aij,...j->...ai", Qtilde_T, v1, optimize=True)         # Q̃^T A Δμ
    v2    = np.einsum("...aij,...j->...ai", Q_tilde,  delta_mu, optimize=True)   # Q̃ Δμ
    part2 = np.einsum("...ij,...aj->...ai", Sj_inv,   v2, optimize=True)         # A Q̃ Δμ
    mahal_term = 0.5 * np.einsum("...i,...ai->...a", delta_mu, part1 + part2, optimize=True)


    # ---- previous gradients -possibly incorrect? ----
    # trace term
   # t1 = np.einsum("...ij,...ajk,...ki->...a", Sj_inv, Q,   Sigma_i, optimize=True)
   # t2 = np.einsum("...aij,...jk,...ki->...a", Q_T,   Sj_inv, Sigma_i, optimize=True)
   # trace_term = -0.5 * (t1 + t2)

    # Mahalanobis term
   # v1 = np.einsum("...ij,...j->...i", Sj_inv, delta_mu, optimize=True)
   # part1 = np.einsum("...aij,...j->...ai", Q_T, v1,           optimize=True)
   # v2    = np.einsum("...aij,...j->...ai", Q,   delta_mu,     optimize=True)
   # part2 = np.einsum("...ij,...aj->...ai", Sj_inv, v2,        optimize=True)
   # mahal_term = 0.5 * np.einsum("...i,...ai->...a", delta_mu, part1 + part2, optimize=True)

    grad = (trace_term + mean_term + mahal_term)
    
    return grad





# ─────────────────────────────────────────────────────────────────────────────
#            SELF AND FEEDBACK GRADS
# ─────────────────────────────────────────────────────────────────────────────


def accumulate_phi_morphism_self_feedback(
    ctx,
    agent_i,
    generators_src, generators_tgt,
    *,
    field: str = "phi",
    fisher_inv_key: str | None = None,
    grad_key: str | None = None,
    phi_self_func=None,
    phi_feedback_func=None,
):
    """
    Accumulate SELF + FEEDBACK gradients for φ (or φ̃) into agent_i.<grad_key>.
    Pipeline: Jinv^T (param-covector) → Fisher^{-1} (body) → Jinv (param-vector).
    Uses cached Φ̃ and reuses pushed mean/precision if available.
    """
   
    assert fisher_inv_key and grad_key, "fisher_inv_key and grad_key are required"

    PRINT_SIGN = False

    eps   = float(cfg_get(ctx, "eps", 1e-8))
    tau   = float(cfg_get(ctx, "support_tau", 1e-6))
    alpha = float(cfg_get(ctx, "alpha", 0.0))
    fbw   = float(cfg_get(ctx, "feedback_weight", 0.0))

    # (H,W,1) mask for broadcasting with (...,A)
    mask = mask_hw(agent_i, tau=tau, mode="float3")
    if not np.any(mask):
        return

    # fields & base φ
    mu_q,  sigma_q  = agent_i.mu_q_field,  agent_i.sigma_q_field
    mu_p,  sigma_p  = agent_i.mu_p_field,  agent_i.sigma_p_field
    phi     = np.asarray(agent_i.phi,       np.float32)
    phi_t   = np.asarray(agent_i.phi_model, np.float32)

    base_phi = phi if field == "phi" else phi_t

    # transports & Jinv (cache-first)
    exp_this, exp_other, Jinv, which, G_q, G_p = exp_and_jinv_single(
        ctx, agent_i, field, base_phi, generators_src, generators_tgt
    )

    # Φ̃ from central cache (q <- p)
    Phi_tilde = Phi_cached(ctx, agent_i, kind="p_to_q")  # (H,W,K_q,K_p)

    # Reuse pushed mean/precision from μ/Σ pass if present, else compute once
    mu_p_push  = getattr(agent_i, "_mu_p_push",          None)  # Φ̃ μ_p
    A_inv_push = getattr(agent_i, "_Sigma_p_push_inv",    None)  # (Φ̃ Σ_p Φ̃ᵀ)^{-1}
    if (mu_p_push is None) or (A_inv_push is None):
        mu_p_push, _, A_inv_push = push_gaussian(
            mu=mu_p, Sigma=sigma_p, M=Phi_tilde,
            eps=eps, return_inv=True, assume_orthogonal=False
        )
        # keep for the rest of this step
        setattr(agent_i, "_mu_p_push",         mu_p_push.astype(np.float32, copy=False))
        setattr(agent_i, "_Sigma_p_push_inv",  A_inv_push.astype(np.float32, copy=False))

        # Fisher^{-1}: treat missing as identity (no-op, but warn once)
    F_inv = getattr(agent_i, fisher_inv_key, None)
    
    if F_inv is None:      
        print(f"[warn] Fisher metric missing for agent {getattr(agent_i,'id', '?')}, "
                  f"field={field}; using identity.\n\n\n\n")
            #setattr(agent_i, "_warned_missing_fisher", True)
        Fi = np.eye(base_phi.shape[-1], dtype=np.float32)  # identity acts as neutral metric
    else:
        Fi = np.asarray(F_inv, dtype=np.float32, order="C")

    total = np.zeros_like(base_phi, dtype=np.float32)
    self_contrib = fb_contrib = None

   # -------- SELF term --------
    if alpha > 0.0 and phi_self_func is not None:
        # unified argument set (includes cached fast-path values;
        # the target function must accept them)
        g_param = phi_self_func(
            mu_q=mu_q, sigma_q=sigma_q,
            mu_p=mu_p, sigma_p=sigma_p,
            Phi_tilde_0=getattr(agent_i, "Phi_tilde_0", None),
            phi=phi, phi_tilde=phi_t,
            generators_q=G_q, generators_p=G_p,
            exp_phi=exp_this if field == "phi" else exp_other,
            exp_phi_tilde=exp_other if field == "phi" else exp_this,
            # always provide fast-path extras
            Phi_tilde=Phi_tilde,
            A_inv_cached=A_inv_push,
            mu_t_cached=mu_p_push,
            eps=eps,
        )
        if g_param is None:
            raise RuntimeError("phi_self_func returned None; check arguments.")
    
        # param-covector → body-covector → Fisher^{-1} → param-vector
        g_body = np.einsum("...ji,...j->...i", Jinv, g_param, optimize=True)
        v_body = g_body if Fi is None else np.einsum("...ab,...b->...a", Fi, g_body, optimize=True)
        v_param = np.einsum("...ab,...b->...a", Jinv, v_body, optimize=True)
    
        self_contrib = alpha * v_param * mask
        total += self_contrib
    
    elif alpha > 0.0:
        print(f"[warn] phi_self_func is None for agent {getattr(agent_i,'id','?')} (field={field})\n\n\n\n\n\n\n")
    
    # -------- FEEDBACK term --------
    if fbw > 0.0 and phi_feedback_func is not None:
        g_param = phi_feedback_func(
            mu_p=mu_p, sigma_p=sigma_p,
            mu_q=mu_q, sigma_q=sigma_q,
            Phi_0=getattr(agent_i, "Phi_0", None),
            phi=phi, phi_tilde=phi_t,
            exp_phi=exp_this if field == "phi" else exp_other,
            exp_phi_tilde=exp_other if field == "phi" else exp_this,
            eps=eps,
            generators_q=G_q, generators_p=G_p,
        )
        if g_param is None:
            raise RuntimeError("phi_feedback_func returned None; check arguments.")
    
        g_body = np.einsum("...ji,...j->...i", Jinv, g_param, optimize=True)
        v_body = g_body if Fi is None else np.einsum("...ab,...b->...a", Fi, g_body, optimize=True)
        v_param = np.einsum("...ab,...b->...a", Jinv, v_body, optimize=True)
    
        fb_contrib = fbw * v_param * mask
        total += fb_contrib
    
    elif fbw > 0.0:
        print(f"[warn] phi_feedback_func is None for agent {getattr(agent_i,'id','?')} (field={field})\n\n\n\n\n\n")

    prev = getattr(agent_i, grad_key, None)
    
    if prev is None:
        prev = np.zeros_like(total, dtype=np.float32)
    setattr(agent_i, grad_key, prev + total)

    if PRINT_SIGN:
        aid = _aid(agent_i)
        log_phi_grad_like(aid, field, "self", self_contrib)
        log_phi_grad_like(aid, field, "feedback", fb_contrib)
        log_phi_grad_like(aid, field, "total", total)



#==============================================================================
#
#                    WITH RESPECT TO phi_i TERMS
#                       VALIDATED
#==============================================================================


def grad_self_phi_direct(
    mu_q, sigma_q, mu_p, sigma_p, Phi_tilde_0,
    phi, phi_tilde, generators_q, generators_p,
    exp_phi, exp_phi_tilde, *,
    eps=1e-8,
    # NEW fast-paths:
    Phi_tilde=None,          # (H,W,K_q,K_p) from cache
    A_inv_cached=None,       # (H,W,K_q,K_q)  inverse of Φ̃ Σ_p Φ̃ᵀ
    mu_t_cached=None,        # (H,W,K_q)      Φ̃ μ_p
    Q_all=None,
    exp_neg_phi_tilde=None
):
    d, K_q, _ = generators_q.shape

    # Inverse of exp_phi_tilde if needed for dΦ̃
    if exp_neg_phi_tilde is None:
        #print("exp-phi~ is none\n\n\n")
        exp_neg_phi_tilde = safe_omega_inv(exp_phi_tilde)

    # Derivative blocks (still need these)
    if Q_all is None:
        #print("q-all is none\n\n\n")
        Q_all = np.stack(d_exp_exact(phi, generators_q), axis=-3)  # (..., d, K_q, K_q)

    # Pull Φ̃ from cache (or build only if missing)
    if Phi_tilde is None:
        #print("Phi~ is none\n\n\n")
        Phi_tilde = np.einsum("...ik,...kj,...jl->...il",
                              exp_phi, Phi_tilde_0, exp_neg_phi_tilde, optimize=True)

    Phi_tilde_T = np.swapaxes(Phi_tilde, -1, -2)

    # A^{-1} and Φ̃ μ_p: reuse when provided
    if (A_inv_cached is None) or (mu_t_cached is None):
        #print("pushes are none\n\n\n")
        mu_t, _, A_inv = push_gaussian(
            mu=mu_p, Sigma=sigma_p, M=Phi_tilde,
            eps=eps, return_inv=True, assume_orthogonal=False
        )
    else:
        mu_t, A_inv = mu_t_cached, A_inv_cached

    delta_mu = mu_q - mu_t

    # ∂Φ̃_a = Q_a Φ̃₀ e^{-φ̃}
    dPhi = np.einsum("...aik,...kj,...jl->...ail", Q_all, Phi_tilde_0, exp_neg_phi_tilde, optimize=True)
    dPhi_T = np.swapaxes(dPhi, -1, -2)

    # dA = dΦ̃ Σ_p Φ̃ᵀ + Φ̃ Σ_p dΦ̃ᵀ
    dA = (
        np.einsum("...aik,...kl,...lj->...aij", dPhi,       sigma_p, Phi_tilde_T, optimize=True) +
        np.einsum("...ik, ...kl,...alj->...aij", Phi_tilde, sigma_p, dPhi_T,      optimize=True)
    )

    # term1: - (∂Φ̃ μ_p)^T A^{-1} Δμ
    dPhi_mu_p = np.einsum("...aij,...j->...ai", dPhi, mu_p, optimize=True)
    term1 = -np.einsum("...ai,...i->...a",
                       dPhi_mu_p,
                       np.einsum("...ij,...j->...i", A_inv, delta_mu, optimize=True),
                       optimize=True)

    # term2: + 1/2 tr(A^{-1} dA)
    term2 = 0.5 * np.einsum("...ij,...aij->...a", A_inv, dA, optimize=True)

    # M = A^{-1} dA A^{-1}
    M = np.einsum("...ij,...ajk,...kl->...ail", A_inv, dA, A_inv, optimize=True)

    # term3: - 1/2 Δμ^T M Δμ
    term3 = -0.5 * np.einsum("...i,...aij,...j->...a", delta_mu, M, delta_mu, optimize=True)

    # term4: - 1/2 tr(M Σ_q)
    term4 = -0.5 * np.einsum("...aij,...ji->...a", M, sigma_q, optimize=True)

    return (term1 + term2 + term3 + term4).astype(np.float32, copy=False)


def grad_self_phi_tilde_direct(
    mu_q, sigma_q, mu_p, sigma_p, Phi_tilde_0,
    phi, phi_tilde, generators_q, generators_p,
    exp_phi, exp_phi_tilde, *,
    eps=1e-8,
    Phi_tilde=None,          # cached (S*,K_q,K_p)
    A_inv_cached=None,       # cached (S*,K_q,K_q)
    mu_t_cached=None,        # cached Φ̃ μ_p
    Q_tilde_all=None,
    exp_neg_phi_tilde=None
):
    d, K_p, _ = generators_p.shape

    if exp_neg_phi_tilde is None:
        #print("e^-phi~ is none\n\n\n")
        exp_neg_phi_tilde = safe_omega_inv(exp_phi_tilde)

    if Q_tilde_all is None:
        #print("Q~-all is none\n\n\n")
        Q_tilde_all = np.stack(d_exp_exact(phi_tilde, generators_p), axis=-3)

    if Phi_tilde is None:
        #print("Phi~ is none\n\n\n")
        Phi_tilde = np.einsum("...ik,...kj,...jl->...il",
                              exp_phi, Phi_tilde_0, exp_neg_phi_tilde, optimize=True)
    Phi_tilde_T = np.swapaxes(Phi_tilde, -1, -2)

    if (A_inv_cached is None) or (mu_t_cached is None):
        mu_t, _, A_inv = push_gaussian(
            mu=mu_p, Sigma=sigma_p, M=Phi_tilde,
            eps=eps, return_inv=True, assume_orthogonal=False
        )
    else:
        mu_t, A_inv = mu_t_cached, A_inv_cached

    delta_mu = mu_q - mu_t

    # R_a = Q̃_a e^{-φ̃}, dΦ̃_a = - Φ̃ R_a
    R    = np.einsum("...aik,...kj->...aij", Q_tilde_all, exp_neg_phi_tilde, optimize=True)
    dPhi = -np.einsum("...ik,...akj->...aij", Phi_tilde, R, optimize=True)
    dPhi_T = np.swapaxes(dPhi, -1, -2)

    dA = (
        np.einsum("...aik,...kl,...lj->...aij", dPhi,       sigma_p, Phi_tilde_T, optimize=True) +
        np.einsum("...ik, ...kl,...alj->...aij", Phi_tilde, sigma_p, dPhi_T,      optimize=True)
    )

    dPhi_mu_p = np.einsum("...aij,...j->...ai", dPhi, mu_p, optimize=True)
    term1 = -np.einsum("...ai,...i->...a",
                       dPhi_mu_p,
                       np.einsum("...ij,...j->...i", A_inv, delta_mu, optimize=True),
                       optimize=True)

    term2 = 0.5 * np.einsum("...ij,...aij->...a", A_inv, dA, optimize=True)

    M = np.einsum("...ij,...ajk,...kl->...ail", A_inv, dA, A_inv, optimize=True)

    term3 = -0.5 * np.einsum("...i,...aij,...j->...a", delta_mu, M, delta_mu, optimize=True)
    term4 = -0.5 * np.einsum("...aij,...ji->...a", M, sigma_q, optimize=True)

    return (term1 + term2 + term3 + term4).astype(np.float32, copy=False)







def grad_feedback_phi_direct(
    mu_p, sigma_p,
    mu_q, sigma_q,
    Phi_0,
    phi,                # (..., d)
    phi_tilde,          # (..., d)
    generators_q,       # (d, K_q, K_q)
    generators_p,
    exp_phi,            # (..., K_q, K_q)
    exp_phi_tilde,      # (..., K_p, K_p)
    eps=1e-8,
    Q_all=None,         # (..., d, K_q, K_q) = d_exp_exact(phi, generators_q)
    exp_neg_phi=None    # (..., K_q, K_q) = e^{-φ}
):
    """
    Vectorized over 'a': returns (..., d)
    Φ = e^{φ̃} Φ₀ e^{-φ}, ∂Φ = - Φ · (e^{-φ} (∂ e^{φ}) e^{-φ})
    """
    
    d, K_q, _ = generators_q.shape

    if exp_neg_phi is None:
        exp_neg_phi = safe_omega_inv(exp_phi)
    if Q_all is None:
        # stack as (..., d, K_q, K_q)
        Q_list = d_exp_exact(phi, generators_q)
        Q_all = np.stack(Q_list, axis=-3)  # assuming list of d arrays

    # Φ and Φᵀ
    Phi = np.einsum("...ik,...kj,...jl->...il", exp_phi_tilde, Phi_0, exp_neg_phi)
    Phi_T = np.swapaxes(Phi, -1, -2)

    # A, A^{-1}
    A = np.einsum("...ik,...kl,...lj->...ij", Phi, sigma_q, Phi_T)
    A = sanitize_sigma(A, eps=eps)
    A_inv = safe_inv(A, eps=eps)

    # Δμ and v
    Phi_mu_q = np.einsum("...ij,...j->...i", Phi, mu_q)
    delta_mu = mu_p - Phi_mu_q
    v = np.einsum("...ij,...j->...i", A_inv, delta_mu)  # (..., K_p)

    # Q̄_a = e^{-φ} Q_a e^{-φ}
    Q_bar = np.einsum("...ik,...akl,...lj->...aij", exp_neg_phi, Q_all, exp_neg_phi)

    # dΦ_a = - Φ Q̄_a
    dPhi = -np.einsum("...ik,...akj->...aij", Phi, Q_bar)
    dPhi_T = np.swapaxes(dPhi, -1, -2)

    # dA_a
    dA = (
        np.einsum("...aik,...kl,...lj->...aij", dPhi, sigma_q, Phi_T) +
        np.einsum("...ik,...kl,...alj->...aij", Phi,  sigma_q, dPhi_T)
    )

    # Term 1
    dPhi_mu = np.einsum("...aij,...j->...ai", dPhi, mu_q)       # (..., a, K_p)
    term1 = -np.einsum("...ai,...i->...a", dPhi_mu, v)

    # Term 2
    term2 = 0.5 * np.einsum("...ij,...aij->...a", A_inv, dA)

    # M_a = A^{-1} dA_a A^{-1}
    M = np.einsum("...ij,...ajk,...kl->...ail", A_inv, dA, A_inv)

    # Term 3
    term3 = -0.5 * np.einsum("...i,...aij,...j->...a", delta_mu, M, delta_mu)

    # Term 4
    term4 = -0.5 * np.einsum("...aij,...ji->...a", M, sigma_p)

    grad = (term1 + term2 + term3 + term4).astype(np.float32, copy=False)
    return grad




def grad_feedback_phi_tilde_direct(
    mu_p, sigma_p,
    mu_q, sigma_q,
    Phi_0,
    phi, 
    phi_tilde,
    generators_q, 
    generators_p,
    exp_phi, 
    exp_phi_tilde,
    eps=1e-8,
    Q_tilde_all=None,       # (..., d, K_p, K_p) = d_exp_exact(phi_tilde, generators_p)
    exp_neg_phi_tilde=None  # (..., K_p, K_p) = e^{-φ̃}
):
    """
    Vectorized over 'a': returns (..., d)
    Left-trivialize: dΦ_a = L_a Φ,  L_a = (∂e^{φ̃}/∂φ̃^a) e^{-φ̃}.
    """
    
    d, K_p, _ = generators_p.shape
    
    if exp_neg_phi_tilde is None:
        exp_neg_phi_tilde = safe_omega_inv(exp_phi_tilde)
    if Q_tilde_all is None:
        Q_list = d_exp_exact(phi_tilde, generators_p)
        Q_tilde_all = np.stack(Q_list, axis=-3)

    # Φ
    exp_neg_phi = safe_omega_inv(exp_phi)
    Phi   = np.einsum("...ik,...kj,...jl->...il", exp_phi_tilde, Phi_0, exp_neg_phi)
    Phi_T = np.swapaxes(Phi, -1, -2)

    
    A = np.einsum("...ik,...kl,...lj->...ij", Phi, sigma_q, Phi_T)
    A = sanitize_sigma(A, eps=eps)
    A_inv = safe_inv(A, eps=eps)

    Phi_mu_q = np.einsum("...ij,...j->...i", Phi, mu_q)
    delta_mu = mu_p - Phi_mu_q
    v = np.einsum("...ij,...j->...i", A_inv, delta_mu)

    # L_a = Q̃_a e^{-φ̃}
    L = np.einsum("...aik,...kj->...aij", Q_tilde_all, exp_neg_phi_tilde)

    # dΦ_a = L_a Φ
    dPhi = np.einsum("...aik,...kj->...aij", L, Phi)
    dPhi_T = np.swapaxes(dPhi, -1, -2)

    dA = (
        np.einsum("...aik,...kl,...lj->...aij", dPhi, sigma_q, Phi_T) +
        np.einsum("...ik,...kl,...alj->...aij", Phi,  sigma_q, dPhi_T)
    )

    dPhi_mu = np.einsum("...aij,...j->...ai", dPhi, mu_q)
    term1 = -np.einsum("...ai,...i->...a", dPhi_mu, v)

    term2 = 0.5 * np.einsum("...ij,...aij->...a", A_inv, dA)

    M = np.einsum("...ij,...ajk,...kl->...ail", A_inv, dA, A_inv)

    term3 = -0.5 * np.einsum("...i,...aij,...j->...a", delta_mu, M, delta_mu)
    term4 = -0.5 * np.einsum("...aij,...ji->...a", M, sigma_p)

    grad = term1 + term2 + term3 + term4
    return grad


def compute_curvature_gradient(
    phi: np.ndarray,
    generators: np.ndarray,
    dx: float | tuple = 1.0,
    metric_ab: np.ndarray | None = None,
) -> np.ndarray:
    """
    D-dimensional Yang–Mills-style curvature gradient with periodic BC.

    Base space: *S (any rank >= 1), typically (H,W) or (H,W,Dz) etc.
    Fiber: so(3) coords per site.

    Inputs
    ------
    phi         : (*S, d)          Lie-algebra coords at each site (d=3 for so(3))
    generators  : (d, K, K)        matrix representation of basis G_a
    dx          : scalar or tuple  grid spacings along each spatial axis
    metric_ab   : optional (d,d)   trace metric M_ab = tr(G_a G_b); if None, assume
                                   generators are trace-orthonormal

    Returns
    -------
    grad        : (*S, d)          gradient wrt φ-components at each site

    Method
    ------
      A_m = ∂_m φ (component-wise in the Lie algebra)
      A_m^mat = Σ_a A_m^a G_a
      F_{mn} = ∂_m A_n - ∂_n A_m + [A_m, A_n]
      We aggregate F := Σ_{m<n} F_{mn} and use a collapsed Euler–Lagrange form:
        div_A F := Σ_n ( ∂_n F + [A_n, F] )
      grad( ½ Σ tr(F_{mn}^2) ) ≈ 2 * Project(div_A F) onto {G_a} with metric_ab.
      For 2D this reduces to your previous formula.

    Notes
    -----
    - Periodic centered differences are used.
    - Raises on shape mismatches or non-finite values.
    """
    import numpy as np

    # ----- validate shapes -----
    phi = np.asarray(phi, np.float32)
    G   = np.asarray(generators, np.float32)

    if phi.ndim < 2:
        raise ValueError(f"phi must be (*S, d); got {phi.shape}")
    *S, d = phi.shape
    if d <= 0:
        raise ValueError("last dim of phi must be > 0 (the Lie-algebra coord dim)")
    if G.ndim != 3 or G.shape[0] != d or G.shape[1] != G.shape[2]:
        raise ValueError(f"generators must be (d,K,K) with d={d}; got {G.shape}")
    K = int(G.shape[1])

    if not np.isfinite(phi).all() or not np.isfinite(G).all():
        raise FloatingPointError("compute_curvature_gradient_nd: non-finite input values")

    D = len(S)  # number of spatial axes
    if D == 0:
        # no spatial structure → zero curvature, zero gradient
        return np.zeros_like(phi, dtype=np.float32)

    # ----- grid spacings per axis -----
    if isinstance(dx, (tuple, list, np.ndarray)):
        if len(dx) != D:
            raise ValueError(f"dx length ({len(dx)}) must match spatial rank D={D}")
        hs = tuple(float(v) for v in dx)
    else:
        h = float(dx)
        if h <= 0:
            raise ValueError("dx must be positive")
        hs = (h,) * D
    if any(v <= 0 for v in hs):
        raise ValueError("all grid spacings in dx must be positive")

    # ----- centered periodic difference along arbitrary axis -----
    def cdiff(arr, axis, h):
        return (np.roll(arr, -1, axis=axis) - np.roll(arr, 1, axis=axis)) / (2.0 * h)

    # ----- A_m = ∂_m φ (as algebra coords) and lift to matrices -----
    # A_m: list of (*S, d); A_m_mat: list of (*S, K, K)
    A = [cdiff(phi, axis=i, h=hs[i]) for i in range(D)]
    A_mat = [np.einsum("...a,akl->...kl", A[i], G, optimize=True) for i in range(D)]  # (*S,K,K)

    # sanity
    for Am in A_mat:
        if Am.shape != tuple(S) + (K, K):
            raise RuntimeError("internal shape error building A_m matrices")

    # ----- curvature tensors and collapsed sum F = Σ_{m<n} F_{mn} -----
    F_sum = np.zeros(tuple(S) + (K, K), dtype=np.float32)
    for m in range(D):
        for n in range(m + 1, D):
            dAn_dm = cdiff(A_mat[n], axis=m, h=hs[m])  # ∂_m A_n
            dAm_dn = cdiff(A_mat[m], axis=n, h=hs[n])  # ∂_n A_m
            comm   = A_mat[m] @ A_mat[n] - A_mat[n] @ A_mat[m]
            F_mn   = dAn_dm - dAm_dn + comm
            F_sum += F_mn

    # ----- covariant divergence of the collapsed F: div_A F -----
    # div_A F = Σ_n ( ∂_n F + [A_n, F] )
    divF = np.zeros_like(F_sum, dtype=np.float32)
    for n in range(D):
        dF_dn = cdiff(F_sum, axis=n, h=hs[n])
        comm  = A_mat[n] @ F_sum - F_sum @ A_mat[n]
        divF += (dF_dn + comm)

    # ----- project divF onto generator basis to get algebra components -----
    # comps_a(x) = tr( divF(x) · G_a )
    comps = np.stack(
        [np.einsum("...ij,ij->...", divF, G[a], optimize=True) for a in range(d)],
        axis=-1
    )  # (*S, d)

    if metric_ab is None:
        grad = 2.0 * comps
    else:
        M = np.asarray(metric_ab, np.float64)
        if M.shape != (d, d):
            raise ValueError(f"metric_ab must be ({d},{d}); got {M.shape}")
        M = 0.5 * (M + M.T)
        # robust inverse (Cholesky if SPD, else pinv)
        try:
            L = np.linalg.cholesky(M)
            Minv = np.linalg.solve(L.T, np.linalg.solve(L, np.eye(d, dtype=np.float64)))
        except np.linalg.LinAlgError:
            Minv = np.linalg.pinv(M, rcond=1e-12)
        grad = 2.0 * np.einsum("ab,...b->...a", Minv, comps, optimize=True)

    if not np.isfinite(grad).all():
        raise FloatingPointError("compute_curvature_gradient_nd produced non-finite values")

    return grad.astype(np.float32, copy=False)


# =========================
# Regularization (with toggleable φ–φ̃ coupling)
# =========================

def _apply_lie_natural_regularizers(
    agent_i,
    field: str,
    generators,
    ctx,
    v_body: np.ndarray,           # <- 5th positional, matches call site
    *,
    agents=None,
) -> np.ndarray:
    """
    Add Lie-natural regularizers (already in BODY coords) and return v_body + reg.
    Expects reg to be the same shape as v_body (or broadcastable via trailing singleton).
    """
    import numpy as np

    # fetch φ-field explicitly; fail if missing
    try:
        phi_field = np.asarray(getattr(agent_i, field), np.float32)
    except AttributeError as e:
        raise AttributeError(f"_apply_lie_natural_regularizers: agent missing field '{field}'") from e

    reg_nat = apply_regularization_terms_lie_natural(
        agent=agent_i,
        phi_field=phi_field,
        generators=generators,
        field=field,
        agents=agents,
        ctx=ctx,
    )
    reg_nat = np.asarray(reg_nat, np.float32)

    # Strict shape handling
    if reg_nat.shape == v_body.shape:
        return v_body + reg_nat

    # Allow a trailing singleton channel (*S,1) and expand
    if reg_nat.shape == v_body.shape[:-1] + (1,):
        return v_body + np.broadcast_to(reg_nat, v_body.shape)

    raise ValueError(
        f"_apply_lie_natural_regularizers: shape mismatch: reg {reg_nat.shape} vs v_body {v_body.shape}"
    )





def apply_regularization_terms_lie_natural(
    agent,
    phi_field,
    generators,
    field,
    *,
    agents=None,
    eps=1e-8,
    ctx=None,
):
    """
    Adds Lie-natural regularizers in BODY coordinates, then returns a body-covector:
      grad_nat ( ... , d )

    Regularizers:
      - curvature:     2 * Proj_{G_a}( Σ_n (∂_n F + [A_n, F]) ), D-dimensional
      - mass:          λ ||φ||^2  → λ φ
      - q↔p coupling:  (1/2)||φ_p - C φ_q||^2  with C built from bases/generators
      - fisher:        NOT implemented here → raise if weight > 0

    Notes:
      - Uses periodic centered differences via compute_curvature_gradient_nd
      - Projects param-covectors to body with Jinv^T, then masks
    """
    import numpy as np
    from runtime_context import cfg_get
    

    phi_field = np.asarray(phi_field, np.float32)
    G = np.asarray(generators, np.float32)
    if phi_field.ndim < 1 or phi_field.shape[-1] <= 0:
        raise ValueError(f"phi_field must be (*S, d), got {phi_field.shape}")
    if G.ndim != 3 or G.shape[0] != phi_field.shape[-1] or G.shape[1] != G.shape[2]:
        raise ValueError(f"generators must be (d,K,K) matching phi last dim; got {G.shape} vs d={phi_field.shape[-1]}")

    d = int(phi_field.shape[-1])
    grad_nat = np.zeros_like(phi_field, dtype=np.float32)

    # ---- weights (no undefined `config` arg) ----
    curv_w, fisher_w, mass_w, cpl_w = reg_weights(field, ctx=ctx)

    # ---- pick fiber & available generators for coupling C ----
    if field == "phi":
        which  = "q"
        gen_q  = G
        gen_p  = getattr(agent, "generators_p", None)
    elif field == "phi_model":
        which  = "p"
        gen_q  = getattr(agent, "generators_q", None)
        gen_p  = G
    else:
        raise ValueError(f"Invalid field: {field!r}")

    # quick exit
    if (curv_w == 0.0) and (fisher_w == 0.0) and (mass_w == 0.0) and (cpl_w == 0.0):
        return grad_nat

    # ---- mask (broadcast-safe (*S,1)) ----
    tau      = float(cfg_get(ctx, "support_tau", 1e-6))
    mask_vec = mask_hw(agent, tau=tau, mode="float3")  # (*S,1)
    if not np.any(mask_vec):
        return grad_nat

    # ---- Jinv (param->body); apply as Jinv^T on covectors ----
    Jinv = Jinv_grid(ctx, agent, which=which)
    if Jinv is None:
        Jinv = build_dexpinv_matrix(phi_field)
    if Jinv.shape[:-2] != phi_field.shape[:-1] or Jinv.shape[-2:] != (d, d):
        raise ValueError(f"Jinv shape {Jinv.shape} incompatible with phi {phi_field.shape}")

    # ---- curvature (D-dimensional) ----
    if curv_w > 0.0:
        # optional per-axis spacing from cfg; accepts scalar or tuple
        dx = cfg_get(ctx, "grid_dx", 1.0)
        g_param_curv = compute_curvature_gradient(phi_field, G, dx=dx)  # (*S, d) param-covector
        if not np.all(np.isfinite(g_param_curv)):
            raise FloatingPointError("curvature grad produced non-finite values")
        g_body_curv  = np.einsum("...ji,...j->...i", Jinv, g_param_curv, optimize=True)
        grad_nat    += curv_w * g_body_curv * mask_vec

    # ---- mass ----
    if mass_w > 0.0:
        g_param_mass = mass_w * phi_field
        g_body_mass  = np.einsum("...ji,...j->...i", Jinv, g_param_mass, optimize=True)
        grad_nat    += g_body_mass * mask_vec

    
    # ---- q↔p coupling: (1/2)||φ_p - C φ_q||^2 ----
    if cpl_w > 0.0:
        phi_q = np.asarray(getattr(agent, "phi", None), np.float32)
        phi_p = np.asarray(getattr(agent, "phi_model", None), np.float32)
        if phi_q is None or phi_p is None:
            raise ValueError("Coupling requested but agent missing phi/phi_model.")
        C = build_c_mapping_q2p(getattr(agent, "Phi_tilde_0", None), gen_q, gen_p, eps=eps)
        if C is None:
            raise ValueError("Coupling requested but C mapping could not be constructed.")
        # residual in p-space
        r = phi_p - np.einsum("ab,...b->...a", C, phi_q, optimize=True)  # (*S, d_p)
        if field == "phi":
            # ∂L/∂φ_q = - C^T r
            g_param = -np.einsum("ba,...a->...b", C, r, optimize=True)
        else:
            # ∂L/∂φ_p = r
            g_param = r
        if not np.all(np.isfinite(g_param)):
            raise FloatingPointError("Coupling grad produced non-finite values")
        g_body_cpl = np.einsum("...ji,...j->...i", Jinv, g_param, optimize=True)
        grad_nat   += cpl_w * g_body_cpl * mask_vec

    if not np.all(np.isfinite(grad_nat)):
        raise FloatingPointError("apply_regularization_terms_lie_natural produced non-finite output")

    return grad_nat.astype(np.float32, copy=False)






