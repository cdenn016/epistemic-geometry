# -*- coding: utf-8 -*-
"""
Created on Wed Sep 10 12:40:31 2025

@author: chris and christine
"""

import numpy as np
from core.transport_cache import ensure_global_A
from runtime_context import cfg_get


def _fwd_diff(X, axis: int):
    # forward difference along spatial axis (PBC)
    return np.roll(X, -1, axis=axis) - X

def _bwd_diff(H, axis: int):
    # adjoint of forward diff (PBC)
    return H - np.roll(H, 1, axis=axis)

def _cross(a, b):
    # a,b: (..., 3) — Lie algebra so(3) cross
    return np.stack([
        a[...,1]*b[...,2] - a[...,2]*b[...,1],
        a[...,2]*b[...,0] - a[...,0]*b[...,2],
        a[...,0]*b[...,1] - a[...,1]*b[...,0]
    ], axis=-1)




def step_global_A(ctx, agents):
    """
    One gradient step on global A:
      - curvature (lambda_A_curv),
      - optional extra coupling grad in ctx.fields["A_grad_accum"].
    Returns: total A-related energy = A_curv + A_cov (if any).
    """
    import numpy as np
    init_scale = float(cfg_get(ctx, "A_init_scale", 0.0))

    # infer spatial shape from an agent field (robust for resume)
    a0 = agents[0]
    S = tuple(np.asarray(a0.mu_q_field).shape[:-1])   # (*S, Kq)
    A = ensure_global_A(ctx, spatial_shape=S, init_scale=init_scale)  # (*S, M, 3)

    # --- curvature term ---
    lam_A = float(cfg_get(ctx, "lambda_A_curv", 0.0))
    if lam_A > 0.0:
        E_curv, F, g_curv = curvature_energy_and_grad(A, weight=lam_A)
        if not hasattr(ctx, "fields"):
            ctx.fields = {}
        ctx.fields["A_curv_raw"]    = 0.5 * float(np.sum(F * F))  # unweighted
        ctx.fields["A_curv_energy"] = float(E_curv)               # weighted
        ctx.fields["A_curv_weight"] = float(lam_A)
    else:
        E_curv = 0.0
        F      = np.zeros(S + (3,), dtype=np.float32)    # not used, for diag
        g_curv = np.zeros_like(A, dtype=np.float32)

    # --- coupling grad accumulated during child pass ---
    E_cov = 0.0
    g_extra = None
    if hasattr(ctx, "fields"):
        g_extra = ctx.fields.pop("A_grad_accum", None)
        E_cov   = float(ctx.fields.pop("A_cov_energy", 0.0))

    g_total = g_curv if g_extra is None else (g_curv + np.asarray(g_extra, np.float32))

    # --- step (clip + lr) ---
    lr   = float(cfg_get(ctx, "A_lr", 1e-2))
    gcap = float(cfg_get(ctx, "A_grad_clip", -1))
    n = float(np.linalg.norm(g_total.reshape(-1))) if g_total.size else 0.0
    if n > 0.0 and lr > 0.0:
        s = 1.0 if gcap <= 0.0 else min(1.0, gcap / (n + 1e-9))
        A[...] = A - (lr * s) * g_total

    # --- diagnostics ---
    if not hasattr(ctx, "fields"):
        ctx.fields = {}
    ctx.fields["A_curv_energy"]     = float(E_curv)
    ctx.fields["A_cov_energy_last"] = float(E_cov)
    ctx.fields["A_grad_norm"]       = float(n)
    ctx.fields["A_curv_normF"]      = float(np.sqrt(np.mean(F * F))) if lam_A > 0.0 else 0.0

    return float(E_curv + E_cov)


def curvature_energy_and_grad(A, weight=1.0):
    """
    Non-Abelian curvature on an M-D grid (periodic):
      F_{ab} = ∂_a A_b − ∂_b A_a + A_a × A_b,  for 0 ≤ a < b < M
      E = 1/2 * weight * sum_{a<b} ||F_{ab}||^2

    Shapes:
      A : (*S, M, 3)
      F : (*S, M, M, 3)   (antisymmetric: F[...,a,b,:] = -F[...,b,a,:])
      grad w.r.t A: (*S, M, 3)
    """
    A = np.asarray(A, np.float32)
    if not (A.ndim >= 2 and A.shape[-2] >= 1 and A.shape[-1] == 3):
        raise AssertionError(f"A must be (*S, M, 3), got {A.shape}")
    S = A.shape[:-2]
    M = int(A.shape[-2])

    # compute all pairwise curvatures F_{ab}
    F = np.zeros(S + (M, M, 3), dtype=np.float32)
    for a in range(M):
        for b in range(a+1, M):
            Ab = A[..., b, :]                       # (*S, 3)
            Aa = A[..., a, :]
            d_a_Ab = _fwd_diff(Ab, axis=a)          # ∂_a A_b
            d_b_Aa = _fwd_diff(Aa, axis=b)          # ∂_b A_a
            Fab = d_a_Ab - d_b_Aa + _cross(Aa, Ab)  # (*S, 3)
            F[..., a, b, :] = Fab
            F[..., b, a, :] = -Fab

    # energy & dE/dF
    E  = 0.5 * float(weight) * float(np.sum(F * F))
    G  = (weight * F).astype(np.float32)            # same shape as F

    # gradient wrt A: accumulate contributions from all pairs
    grad = np.zeros_like(A, dtype=np.float32)       # (*S, M, 3)
    for a in range(M):
        for b in range(a+1, M):
            Gab = G[..., a, b, :]                   # (*S, 3)
            Aa  = A[..., a, :]
            Ab  = A[..., b, :]

            # from ∂_a A_b: + bwd_a(Gab) goes to A_b
            grad[..., b, :] += _bwd_diff(Gab, axis=a)

            # from −∂_b A_a: − bwd_b(Gab) goes to A_a
            grad[..., a, :] += -_bwd_diff(Gab, axis=b)

            # from Ax×Ay:  d/dA_a -> (A_b × Gab),  d/dA_b -> (Gab × A_a)
            grad[..., a, :] += _cross(Ab, Gab)
            grad[..., b, :] += _cross(Gab, Aa)

    return float(E), F, grad


def covariant_frame_energy_and_grads(phi, A, *, weight=1.0, mask=None):
    """
    E_cov = (weight/2) * sum_m ||D_m φ||^2,
      D_m φ = ∂_m φ - A_m × φ   for m=0..M-1

    Returns:
      E_cov : float
      g_phi : (*S, 3)
      g_A   : (*S, M, 3)
    """
    phi = np.asarray(phi, np.float32)      # (*S, 3)
    A   = np.asarray(A,   np.float32)      # (*S, M, 3)
    if phi.shape[:-1] != A.shape[:-2] or A.shape[-1] != 3:
        raise ValueError(f"shape mismatch: phi {phi.shape}, A {A.shape}")

    S = phi.shape[:-1]
    M = int(A.shape[-2])

    if mask is not None:
        m = np.asarray(mask, np.float32)
        # broadcast to S if needed
        if m.shape != S:
            pad = (1,) * max(0, len(S) - m.ndim)
            m = np.broadcast_to(m.reshape(pad + m.shape), S)
        m3 = m[..., None]
    else:
        m3 = 1.0

    # D_m φ and energy
    D_list = []
    for m in range(M):
        Am = A[..., m, :]                       # (*S, 3)
        Dm = _fwd_diff(phi, axis=m) - _cross(Am, phi)
        D_list.append(Dm * m3)

    E = 0.5 * float(weight) * float(sum(np.sum(Dm*Dm) for Dm in D_list))

    # grads
    g_phi = np.zeros_like(phi, dtype=np.float32)
    g_A   = np.zeros_like(A,   dtype=np.float32)

    for m in range(M):
        Dm = D_list[m]
        Gm = float(weight) * Dm                 # (*S, 3)

        # φ: adjoint of ∂_m and of (-A_m × ·)
        g_phi += -_bwd_diff(Gm, axis=m) + _cross(A[..., m, :], Gm)

        # A_m: from - A_m × φ
        g_A[..., m, :] += -_cross(phi, Gm)

    return float(E), g_phi.astype(np.float32), g_A





