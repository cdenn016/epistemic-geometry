# -*- coding: utf-8 -*-
from __future__ import annotations

from dataclasses import dataclass, field, asdict
from typing import Any, Dict, List, Optional, Literal
import numpy as np
import hashlib
from updates.update_helpers import dirty_manager

Fiber = Literal["q", "p"]

# ─────────────────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────────────────

def _shape_sig(a):
    return tuple(int(x) for x in np.asarray(a).shape)

def _arr_digest(a: np.ndarray, *, tol: float | None = None) -> str:
    a = np.asarray(a, np.float32)
    if tol and tol > 0:
        b = (np.round(a / tol) * tol).tobytes()
    else:
        b = a.tobytes()
    return hashlib.sha256(b).hexdigest()



# ─────────────────────────────────────────────────────────────────────────────
# Cache hub
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class CacheHub:
    step_tag: int = -1
    spaces: Dict[str, Dict[Any, Any]] = field(default_factory=lambda: {
        "exp": {}, "omega": {}, "morphism": {}, "fisher": {}, "misc": {}, "jinv": {}
    })
    persist: Dict[str, Dict[Any, Any]] = field(default_factory=lambda: {
        "morph_base": {}
    })
    hits: int = 0
    misses: int = 0
    invalidations: int = 0

    def ns(self, name: str) -> Dict[Any, Any]:
        return self.spaces.setdefault(name, {})

    def nsp(self, name: str) -> Dict[Any, Any]:
        return self.persist.setdefault(name, {})

    def clear_on_step(self, step: int) -> None:
        if step != self.step_tag:
            for d in self.spaces.values():
                d.clear()
            self.step_tag = step

    def stats(self) -> Dict[str, int]:
        return {k: len(v) for k, v in self.spaces.items()}

    def key_E(self, *, agent_id: int, step: int, phi: np.ndarray,
          cfg: dict, wrap_flag: bool, tol: float | None = None,
          gensig: tuple | None = None):
        """
        E-cache key; includes optional generator signature to disambiguate reps.
        gensig should be a small tuple like (K, 'sha256hex') or None.
        """
        return ("E", int(agent_id), int(step),
                _shape_sig(phi), bool(wrap_flag),
                gensig, _arr_digest(phi, tol=tol))
    
    def key_Jinv(self, **kw):
        k = self.key_E(**kw)
        return ("Jinv",) + k[1:]
    
    def key_Omega(self, *, agent_i: int, agent_j: int, step: int,
                  phi_i: np.ndarray, phi_j: np.ndarray, cfg: dict,
                  wrap_flag: bool, tol: float | None = None,
                  gensig_i: tuple | None = None, gensig_j: tuple | None = None):
        """
        Omega-cache key; includes optional generator signatures for each endpoint.
        """
        di = _arr_digest(phi_i, tol=tol)
        dj = _arr_digest(phi_j, tol=tol)
        pair_sha = hashlib.sha256((di + "|" + dj).encode()).hexdigest()
        return ("Omega", int(agent_i), int(agent_j), int(step),
                _shape_sig(phi_i), bool(wrap_flag),
                gensig_i, gensig_j, pair_sha)


    def key_Fisher(self, *, agent_id: int, step: int,
                   mu: np.ndarray, Sigma: np.ndarray,
                   cfg: dict, which: str = "q", tol: float | None = None):
        mu  = np.asarray(mu,    np.float32)
        Sig = np.asarray(Sigma, np.float32)
        mu_sha  = _arr_digest(mu,  tol=tol)
        Sig_sha = _arr_digest(Sig, tol=tol)
        shape   = _shape_sig(Sig)
        return ("Fisher", which, int(agent_id), int(step),
                shape, mu_sha, Sig_sha)

    # ---- typed get/put with counters ----
    def get(self, ns_name: str, key):
        ns = self.ns(ns_name)
        val = ns.get(key)
        if val is None: self.misses += 1
        else:           self.hits += 1
        return val

    def put(self, ns_name: str, key, value):
        self.ns(ns_name)[key] = value

    def invalidate_like(self, ns_name: str, predicate):
        ns = self.ns(ns_name)
        todel = [k for k in list(ns.keys()) if predicate(k)]
        for k in todel:
            ns.pop(k, None)
        self.invalidations += len(todel)

   # def full_stats(self) -> Dict[str, int]:
   #     out = self.stats()
   #     out.update({"hits": self.hits, "misses": self.misses, "invalidations": self.invalidations})
    #    return out

# ─────────────────────────────────────────────────────────────────────────────
# Neighbor graph (single level)
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class LevelGraph:
    level: int
    agent_ids: List[int]
    neighbors: Dict[int, List[int]] = field(default_factory=dict)  # id -> [neighbor ids]

# ─────────────────────────────────────────────────────────────────────────────
# Runtime context (single-scale)
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class RuntimeCtx:
    global_step: int = 0
    agents_by_level: Dict[int, Dict[int, Any]] = field(default_factory=dict)
    graphs: Dict[int, LevelGraph] = field(default_factory=dict)
    cache: CacheHub = field(default_factory=CacheHub)
    fields: Dict[str, Any] = field(default_factory=dict)
    step_cfg: Optional[StepSettings] = None   # <— add this

    def register_agents(self, level: int, agents: List[Any]) -> None:
        lvl = self.agents_by_level.setdefault(level, {})
        lvl.clear()
        for a in agents:
            lvl[int(getattr(a, "id"))] = a

    def build_neighbors(self, level: int, neighbor_map: Dict[int, List[int]]) -> None:
        ids = list(self.agents_by_level.get(level, {}).keys())
        nm: Dict[int, List[int]] = {i: [j for j in neighbor_map.get(i, []) if j in ids] for i in ids}
        self.graphs[level] = LevelGraph(level=level, agent_ids=ids, neighbors=nm)

    def neighbors_of(self, level: int, agent_id: int) -> List[int]:
        g = self.graphs.get(level)
        return [] if not g else g.neighbors.get(int(agent_id), [])

    def agent(self, level: int, agent_id: int) -> Any:
        return self.agents_by_level[level][int(agent_id)]

    def agents(self, level: int) -> List[Any]:
        if level not in self.graphs:
            return list(self.agents_by_level.get(level, {}).values())
        g = self.graphs[level]
        return [self.agents_by_level[level][aid] for aid in g.agent_ids]

    def cache_stats(self) -> dict:
        return {} if not getattr(self, "cache", None) else self.cache.stats()


#===================================================
#
#         CONFIG
#
#==================================================



@dataclass(frozen=True)
class StepSettings:
    # geometry / exp
    use_global_A: bool
    A_compose_order: str
    exp_clip_max_norm: float
    phi_small_threshold: float
    sigma_jitter: float

    # masks / neighbors
    overlap_eps: float
    support_tau: float
    neighbors_symmetric: bool  # keep for future; you can set False for now

    # weights / couplings (hot in updates)
    alpha: float
    beta: float
    belief_mass: float
    curvature_weight: float
    feedback_weight: float
    beta_model: float
    model_mass: float
    model_curvature_weight: float
    lambda_A_curv: float
    lambda_A_cov: float
    vfe_weight: float

    # learning rates / clips used inside loops
    tau_phi: float
    tau_phi_model: float
    tau_mu_belief: float
    tau_sigma_belief: float
    tau_mu_model: float
    tau_sigma_model: float
    A_lr: float
    theta_lr_W: float
    theta_lr_b: float
    theta_lr_sigma2: float
    gradient_clip_phi: float
    gradient_clip_phi_model: float
    theta_grad_clip: float
    A_grad_clip: float
    
    # misc numerics
    eps: float
    sigma2_min: float

def build_step_settings(config) -> StepSettings:
    # defaults for knobs not present in your config.py
    _exp_clip_max_norm   = float(getattr(config, "exp_clip_max_norm", 10.0))
    _phi_small_threshold = float(getattr(config, "phi_small_threshold", 0.0))
    _A_compose_order     = str(getattr(config, "A_compose_order", "yx")).lower()
    _sigma_jitter        = float(getattr(config, "sigma_jitter", 1e-8))
   
    
    return StepSettings(
        # geometry / exp
        use_global_A=bool(getattr(config, "use_global_A", False)),
        A_compose_order=_A_compose_order,
        exp_clip_max_norm=_exp_clip_max_norm,
        phi_small_threshold=_phi_small_threshold,
        sigma_jitter=_sigma_jitter,
        
        
        # masks / neighbors
        overlap_eps=float(getattr(config, "overlap_eps", 1e-6)),
        support_tau=float(getattr(config, "support_tau", 1e-6)),
        neighbors_symmetric=bool(getattr(config, "neighbors_symmetric", False)),

        # weights / couplings
        alpha=float(getattr(config, "alpha", 0.0)),
        beta=float(getattr(config, "beta", 0.0)),
        belief_mass=float(getattr(config, "belief_mass", 0.0)),
        curvature_weight=float(getattr(config, "curvature_weight", 0.0)),
        feedback_weight=float(getattr(config, "feedback_weight", 0.0)),
        beta_model=float(getattr(config, "beta_model", 0.0)),
        model_mass=float(getattr(config, "model_mass", 0.0)),
        model_curvature_weight=float(getattr(config, "model_curvature_weight", 0.0)),
        lambda_A_curv=float(getattr(config, "lambda_A_curv", 0.0)),
        lambda_A_cov=float(getattr(config, "lambda_A_cov", 0.0)),
        vfe_weight=float(getattr(config, "vfe_weight", 0.0)),

        # learning rates / clips
        tau_phi=float(getattr(config, "tau_phi", 0.0)),
        tau_phi_model=float(getattr(config, "tau_phi_model", 0.0)),
        tau_mu_belief=float(getattr(config, "tau_mu_belief", 0.0)),
        tau_sigma_belief=float(getattr(config, "tau_sigma_belief", 0.0)),
        tau_mu_model=float(getattr(config, "tau_mu_model", 0.0)),
        tau_sigma_model=float(getattr(config, "tau_sigma_model", 0.0)),
        A_lr=float(getattr(config, "A_lr", 0.0)),
        theta_lr_W=float(getattr(config, "theta_lr_W", 0.0)),
        theta_lr_b=float(getattr(config, "theta_lr_b", 0.0)),
        theta_lr_sigma2=float(getattr(config, "theta_lr_sigma2", 0.0)),
        gradient_clip_phi=float(getattr(config, "gradient_clip_phi", -1.0)),
        gradient_clip_phi_model=float(getattr(config, "gradient_clip_phi_model", -1.0)),
        theta_grad_clip=float(getattr(config, "theta_grad_clip", -1.0)),
        A_grad_clip=float(getattr(config, "A_grad_clip", 0.0)),

        # misc numerics
        eps=float(getattr(config, "eps", 1e-10)),
        sigma2_min=float(getattr(config, "sigma2_min", 1e-6)),
    )



# runtime_context.py
def cfg_get(ctx, name: str, default):
    """
    Robust config accessor:
      1) ctx.step_cfg   (dataclass or dict)
      2) ctx.config     (dict or attr-like object)
      3) core.config    (module fallback)
      4) default
    """
    # 1) step_cfg
    sc = getattr(ctx, "step_cfg", None)
    if sc is not None:
        if isinstance(sc, dict) and name in sc:
            return sc[name]
        if hasattr(sc, name):
            return getattr(sc, name)

    # 2) config mirror
    cc = getattr(ctx, "config", None)
    if cc is not None:
        if isinstance(cc, dict):
            return cc.get(name, default)
        # tolerate attr-like mirrors
        if hasattr(cc, name):
            return getattr(cc, name, default)

    # 3) global fallback
    try:
        import core.config as _g
        return getattr(_g, name, default)
    except Exception:
        return default





def build_step_settings_from_overrides(base_config_module, overrides: dict) -> StepSettings:
    """Create StepSettings using values from base_config_module, then apply overrides."""
    base = build_step_settings(base_config_module)  # your existing builder
    if not overrides:
        return base
    d = asdict(base)
    for k, v in (overrides or {}).items():
        if k in d:
            d[k] = v
    return StepSettings(**d)



#=====================================
#
#    VFE THETA
#
#====================================


class Theta:
    """
    Simple Gaussian observation model:
        y | x ~ N(W x + b, sigma2 I)

    All parameters are aggressively sanitized with np.nan_to_num so that
    any NaN/Inf introduced upstream (e.g. from RNG or later updates) is
    clamped to finite values.
    """
    def __init__(self,
                 D_obs: int,
                 K_latent: int,
                 rng=None,
                 sigma2_init: float = 1.0,
                 sigma2_min: float = 1e-3,
                 w_scale: float | None = None):
        rng = rng or np.random.default_rng(0)
        scale = (1.0 / max(K_latent, 1)) if w_scale is None else float(w_scale)

        # --- draw and sanitize parameters ---
        W = rng.standard_normal((D_obs, K_latent)) * scale
        b = np.zeros((D_obs,), dtype=np.float32)

        # force finite everywhere
        self.W = np.nan_to_num(W, nan=0.0, posinf=0.0, neginf=0.0).astype(np.float32)
        self.b = np.nan_to_num(b, nan=0.0, posinf=0.0, neginf=0.0).astype(np.float32)

        # sigma2: clamp and sanitize
        s2 = float(max(sigma2_init, sigma2_min))
        self.sigma2 = float(np.nan_to_num(s2, nan=sigma2_min, posinf=sigma2_min, neginf=sigma2_min))

        # metadata (cast and sanitize just in case)
        self.D_obs   = int(np.nan_to_num(D_obs))
        self.K_latent = int(np.nan_to_num(K_latent))

    def __repr__(self) -> str:
        return (f"Theta(D={self.D_obs}, K={self.K_latent}, "
                f"||W||_F={float(np.linalg.norm(self.W)):.3e}, "
                f"sigma2={self.sigma2:.3e})")

def ensure_theta(ctx, D_obs: int, K_latent: int, *,
                 sigma2_init: float = 1.0, sigma2_min: float = 1e-3,
                 w_scale: float | None = None) -> Theta:
    """
    Create (or validate) a global Theta on ctx.
    Uses ctx.rng if present for reproducible init.
    """
    # prefer a shared RNG on ctx
    rng = getattr(ctx, "rng", None)
    if rng is None:
        rng = np.random.default_rng(0)
        setattr(ctx, "rng", rng)

    th = getattr(ctx, "theta", None)
    if th is None:
        th = Theta(D_obs, K_latent, rng=rng,
                   sigma2_init=sigma2_init, sigma2_min=sigma2_min,
                   w_scale=w_scale)
        setattr(ctx, "theta", th)
        return th

    # Validate shapes; reinit or raise
    if (th.D_obs != D_obs) or (th.K_latent != K_latent):
        # Option A (strict): raise for clarity
        # raise ValueError(f"ensure_theta: existing Theta has (D={th.D_obs},K={th.K_latent}) "
        #                  f"but requested (D={D_obs},K={K_latent}).")
        # Option B (auto-reinit): uncomment to replace instead of raising
        th = Theta(D_obs, K_latent, rng=rng,
                   sigma2_init=sigma2_init, sigma2_min=sigma2_min,
                   w_scale=w_scale)
        setattr(ctx, "theta", th)
        return th


    if not np.isfinite(th.sigma2) or th.sigma2 <= 0.0:
        th.sigma2 = float(max(sigma2_init, sigma2_min))

    return th


# ─────────────────────────────────────────────────────────────────────────────
# Convenience
# ─────────────────────────────────────────────────────────────────────────────

def ensure_runtime_defaults(ctx: Optional[RuntimeCtx]) -> RuntimeCtx:
    if ctx is None:
        ctx = RuntimeCtx()
    if ctx.global_step is None:
        ctx.global_step = 0
    
    _ = dirty_manager(ctx)
    return ctx


__all__ = [
    "CacheHub",
    "LevelGraph",
    "RuntimeCtx",
    "ensure_runtime_defaults",
]
