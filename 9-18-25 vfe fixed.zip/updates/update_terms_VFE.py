# -*- coding: utf-8 -*-
"""
Created on Mon Sep  8 17:40:08 2025

@author: chris and christine
"""

# updates/update_terms_vfe.py
from __future__ import annotations
import numpy as np
from runtime_context import ensure_theta, cfg_get
from core.numerical_utils import sanitize_sigma  # you already use this elsewhere




def _theta_stats_from_children(ctx):
    """
    Aggregate sufficient stats over current children for preconditioning:
      Sxx = sum m * (Σ_q + μ μ^T)
      Sx  = sum m * μ
      N   = sum m   (per-pixel counts)
    Returns (Sxx, Sx, N, K_latent).
    """
   
    agents = getattr(ctx, "children_latest", None) or []
    
    if not agents:
        print(f"[THETA STATS] RETURN NONE \n\n\n\n")
        return None, None, 0.0, None

    A0 = agents[0]
    K = int(A0.mu_q_field.shape[-1])
    Sxx = np.zeros((K, K), np.float32)
    Sx  = np.zeros((K,),   np.float32)
    N   = 0.0

    for a in agents:
        m   = np.asarray(a.mask, np.float32)               # (H,W)
        mu  = np.asarray(a.mu_q_field, np.float32)         # (H,W,K)
        Sig = np.asarray(a.sigma_q_field, np.float32)      # (H,W,K,K)

        w = m[..., None]                                   # (H,W,1)
        N += float(np.sum(m))

        # sum μ and (Σ + μμ^T)
        Sx  += np.sum(w * mu, axis=(0,1))
        # batch outer products: (H,W,K,1)*(H,W,1,K) -> (H,W,K,K)
        outer = mu[..., :, None] * mu[..., None, :]
        Sxx  += np.sum(Sig + outer, axis=(0,1)).astype(np.float32)

    return Sxx, Sx, N, K




def expected_nll_gaussian(
    y,                # (..., D)
    mu,               # (..., Kx)
    Sigma,            # (..., Kx,Kx)
    W,                # (D, Kq)
    b,                # (D,)
    sigma2,           # scalar
    *,
    mask=None,
    Phi_tilde=None,   # optional (..., Kq, Kp) maps p → q
    sanitize_eps=1e-8
):
    y      = np.asarray(y,      np.float32)
    mu     = np.asarray(mu,     np.float32)
    Sigma  = np.asarray(Sigma,  np.float32)
    W      = np.asarray(W,      np.float32)
    b      = np.asarray(b,      np.float32)
    sigma2 = float(sigma2)

    if Phi_tilde is not None:
        raise ValueError(
            "vfe_mu_sigma_grads: Phi_tilde was provided but this build expects q-fiber inputs "
            "(mu=mu_q, Sigma=Sigma_q). Remove Phi_tilde or enable the p→q path."
        )

    # Already in q-fiber     
    mu_q = mu
    S_q  = sanitize_sigma(Sigma, eps=sanitize_eps)  # <-- FIX

    D = y.shape[-1]
    # r = (W μ_q + b) - y
    r  = (mu_q @ W.T) + b - y                  # (..., D)
    r2 = np.sum(r * r, axis=-1)                # (...)

    # tr(W Σ_q W^T) = tr(Σ_q W^T W)
    WT_W   = (W.T @ W).astype(np.float32)      # (Kq, Kq)
    tr_term = np.einsum("...ij,ij->...", S_q, WT_W, optimize=True)

    const = 0.5 * D * np.log(2.0 * np.pi * max(sigma2, 1e-12))
    quad  = 0.5 * (r2 + tr_term) / max(sigma2, 1e-12)
    nll   = const + quad

    if mask is not None:       
        nll = nll * np.asarray(mask, np.float32)

    total = float(np.sum(nll))
    return total, (r, WT_W, r2, tr_term)


def _check_finite(name, x):
    if not np.all(np.isfinite(x)):
        n_nan = int(np.isnan(x).sum())
        n_inf = int(np.isinf(x).sum())
        raise FloatingPointError(f"[vfe_mu_sigma_grads] {name} has non-finite values "
                                 f"(nan={n_nan}, inf={n_inf}).")
        
def vfe_mu_sigma_grads(
    y, mu, Sigma, W, b, sigma2, *,
    mask=None,
    # This build expects q-fiber inputs (mu=mu_q, Sigma=Sigma_q). No Phi_tilde here.
    sigma2_min: float = 1e-6,
    grad_mu_clip: float | None = 0.0,
    grad_S_clip: float | None = 0.0,
    sanitize_eps: float = 1e-8,
    strict_numerics: bool = True,
    # Prior (complexity) in the q-fiber (Friston): KL(q || N(m0, S0))
    # Provide either S0_inv or lambda * I via cfg / caller.
    ctx=None,                 # pass your runtime ctx so cfg_get works
):
    """
    Friston-style VFE grads (q-fiber):
        F = E_q[-log p(y|x_q)]  +  KL(q(x_q) || N(m0, S0))

    Inputs must be in the q-fiber (mu=mu_q, Sigma=Sigma_q).
    Returns Euclidean grads wrt (mu, Sigma) in the SAME fiber.
    """
    import numpy as np
    from runtime_context import cfg_get
    # sanitize_sigma must project to SPD; safe_batch_inverse must be numerically safe.
    from core.numerical_utils import safe_batch_inverse   # or your path
    # assume sanitize_sigma is available in scope

    def _check_finite(name, x):
        if not np.all(np.isfinite(x)):
            n_nan = int(np.isnan(x).sum()); n_inf = int(np.isinf(x).sum())
            raise FloatingPointError(f"[vfe_mu_sigma_grads] {name} non-finite (nan={n_nan}, inf={n_inf})")

    # --- to-arrays ---
    y     = np.asarray(y,     np.float32)
    mu    = np.asarray(mu,    np.float32)
    Sigma = np.asarray(Sigma, np.float32)
    W     = np.asarray(W,     np.float32)
    b     = np.asarray(b,     np.float32)

    # --- numeric guardrails (fail fast) ---
    if strict_numerics:
        _check_finite("y", y); _check_finite("mu", mu); _check_finite("Sigma", Sigma)
        _check_finite("W", W); _check_finite("b", b)
        if mask is not None:
            _check_finite("mask", np.asarray(mask))

    # --- scalar handling ---
    sigma2 = float(max(float(sigma2), float(sigma2_min)))
    if strict_numerics and (not np.isfinite(sigma2)):
        raise FloatingPointError("[vfe_mu_sigma_grads] sigma2 is non-finite.")
    inv_s2 = 1.0 / sigma2

    # --- mask helpers ---
    if mask is None:
        m1 = 1.0  # (..., 1) logically
        m2 = 1.0  # (..., 1, 1)
    else:
        m  = np.asarray(mask, np.float32)
        m1 = m[..., None]
        m2 = m[..., None, None]

    # === q-fiber only ===
    mu_q = mu
    S_q  = sanitize_sigma(Sigma, eps=sanitize_eps)  # SPD projection only

    # --- residuals (apply mask BEFORE multiplies to avoid NaN*0) ---
    # r = (W μ_q + b) - y
    r = (mu_q @ W.T) + b - y              # (..., D)
    if mask is not None:
        r = np.where(m1.astype(bool), r, 0.0)

    # --- grads: Accuracy term (likelihood) in q-fiber ---
    WT   = W.T                             # (Kq, D)
    WT_W = (WT @ W).astype(np.float32)     # (Kq, Kq) symmetric

    # ∂F_acc/∂μ_q = (1/σ²) W^T r
    g_mu_q = (inv_s2 * (WT @ r[..., None]).squeeze(-1)).astype(np.float32)      # (..., Kq)
    # ∂F_acc/∂Σ_q = (1/2σ²) W^T W   (broadcast to Σ shape)
    g_S_q  = (0.5 * inv_s2 * WT_W).astype(np.float32)                           # (Kq, Kq)
    g_S_q  = np.broadcast_to(g_S_q, S_q.shape)

    # --- complexity: Prior KL(q || N(m0, S0)) in q-fiber (Friston) ---
    use_prior = bool(cfg_get(ctx, "vfe_use_prior", True))
    if use_prior:
        # Defaults: m0 = 0, S0^{-1} = λ I
        lam = float(cfg_get(ctx, "vfe_prior_lambda", 1.0))
        m0  = cfg_get(ctx, "vfe_prior_m0", None)
        if m0 is None:
            m0 = np.zeros_like(mu_q, dtype=np.float32)
        else:
            m0 = np.asarray(m0, np.float32)

        S0_inv = cfg_get(ctx, "vfe_prior_S0_inv", None)
        if S0_inv is None:
            K = mu_q.shape[-1]
            S0_inv = (lam * np.eye(K, dtype=np.float32))
        else:
            S0_inv = np.asarray(S0_inv, np.float32)

        # ∇μ KL = S0^{-1}(μ - m0)
        g_mu_prior = np.einsum("ij,...j->...i", S0_inv, (mu_q - m0), optimize=True).astype(np.float32)

        # ∇Σ KL = 1/2 ( S0^{-1} - Σ^{-1} )
        Sigma_q_spd = sanitize_sigma(S_q, eps=sanitize_eps)
        Sigma_inv   = safe_batch_inverse(Sigma_q_spd)
        g_S_prior   = 0.5 * (S0_inv - Sigma_inv).astype(np.float32)

        # broadcast if needed
        if g_S_prior.shape != S_q.shape:
            g_S_prior = np.broadcast_to(g_S_prior, S_q.shape)

        # accumulate
        g_mu_q = g_mu_q + g_mu_prior
        g_S_q  = g_S_q  + g_S_prior
        #print(f"{g_mu_q}")
    # --- gate grads by mask (return fiber = q) ---
    if mask is None:
        g_mu, g_S = g_mu_q, g_S_q
    else:
        g_mu = g_mu_q * m1
        g_S  = g_S_q  * m2

    # --- optional per-pixel clipping in the RETURN fiber (kept default OFF) ---
    if grad_mu_clip and grad_mu_clip > 0:
        n = np.linalg.norm(g_mu, axis=-1, keepdims=True)
        s = np.minimum(1.0, grad_mu_clip / (n + 1e-9))
        g_mu = (g_mu * s).astype(np.float32)

    if grad_S_clip and grad_S_clip > 0:
        gSf = g_S.reshape(*g_S.shape[:-2], -1)
        n   = np.linalg.norm(gSf, axis=-1, keepdims=True)
        s   = np.minimum(1.0, grad_S_clip / (n + 1e-9))
        g_S = (gSf * s).reshape(g_S.shape).astype(np.float32)

    # --- single final symmetry projection (grads only) ---
    g_S = 0.5 * (g_S + np.swapaxes(g_S, -1, -2))

    if strict_numerics:
        _check_finite("g_mu", g_mu)
        _check_finite("g_S", g_S)

    return g_mu, g_S




def vfe_theta_grads(y, mu, Sigma, W, b, sigma2, *, mask=None):
    """
    Euclidean grads wrt theta = {W, b, sigma2} for
        F = E_q[-log p(y|x_q)],  y|x_q ~ N(W x_q + b, sigma2 I)
    Returns summed grads over batch/pixels: (dW, db, d_sigma2).
    All inputs are assumed in the q-fiber.
    """
    import numpy as np

    y     = np.asarray(y,     np.float32)   # (..., D)
    mu    = np.asarray(mu,    np.float32)   # (..., K)
    Sigma = np.asarray(Sigma, np.float32)   # (..., K, K)
    W     = np.asarray(W,     np.float32)   # (D, K)
    b     = np.asarray(b,     np.float32)   # (D,)
    s2    = float(max(sigma2, 1e-12))
    inv_s2 = 1.0 / s2

    # Mask (ones if None) with convenient shapes
    if mask is None:
        m  = 1.0
        mm = 1.0          # (..., 1)
        mS = 1.0          # (..., 1, 1)
        N  = int(np.prod(y.shape[:-1]))  # number of examples
    else:
        m  = np.asarray(mask, np.float32)                 # (...)
        mm = m[..., None]                                 # (..., 1)
        mS = m[..., None, None]                           # (..., 1, 1)
        N  = int(np.sum(m))                               # active examples

    # Residuals
    r = (mu @ W.T) + b - y                                # (..., D)
    r_masked = r * mm                                     # (..., D)

    # dW: sum (r mu^T + W Σ)
    dW = np.einsum("...d,...k->dk", r_masked, mu, optimize=True)  # (D, K)
    Sigma_sum = np.sum(Sigma * mS, axis=tuple(range(Sigma.ndim-2)))  # (K, K)
    dW += W @ Sigma_sum
    dW *= inv_s2

    # db: sum r
    db = np.sum(r_masked, axis=tuple(range(r_masked.ndim-1))) * inv_s2  # (D,)

    # d sigma2:
    # num = Σ_examples [ r^2 + tr(W Σ W^T) ]
    r2   = np.sum((r * r) * mm, axis=-1)                                 # (...)
    WT_W = (W.T @ W).astype(np.float32)                                  # (K, K)
    trm  = np.einsum("...ij,ij->...", Sigma * mS, WT_W, optimize=True)   # (...)
    num  = float(np.sum(r2 + trm))
    D    = int(y.shape[-1])
    d_sigma2 = 0.5 * ( (D * max(N, 0)) / s2 - (num / (s2 * s2)) )        # scalar

    return dW.astype(np.float32), db.astype(np.float32), float(d_sigma2)

