# -*- coding: utf-8 -*-
"""
Created on Wed Aug  6 12:27:32 2025

@author: chris and christine
"""

import numpy as np
import core.config as config
from core.numerical_utils import sanitize_sigma, safe_batch_inverse, push_gaussian
from core.transport_cache import Omega, _aid
from utils import _pull_agent_fields, _phi_mats, iter_overlapping_neighbors
from updates.update_terms_VFE import vfe_mu_sigma_grads
from runtime_context import ensure_theta, cfg_get

# -------------------------------------------------------------------------
#                          PUBLIC ENTRYPOINTS
# -------------------------------------------------------------------------

 

def accumulate_mu_sigma_gradient(ctx, agent_i, agents,  mode,
                                 *, strict_numerics: bool = True,
                                 recover: str | None = None):
    """
    Accumulate natural gradient ∇μ and ∇Σ for belief or model using cache-owned Φ, Φ̃, Ω.
    ...
    """
       
    if ctx is None:
        raise RuntimeError("accumulate_mu_sigma_gradient: ctx required.")

    PRINT_SIGN  = False
    
    eps         = float(cfg_get(ctx, "eps", 1e-6))
    tau         = float(cfg_get(ctx, "support_tau", 1e-6))
    alpha       = float(cfg_get(ctx, "alpha", 0))    
    lambd       = float(cfg_get(ctx, "feedback_weight", 0))
    # ── NEW: map mode→field and resolve weights via consolidated helper
   
    field = "phi" if mode == "belief" else "phi_model"                # NEW
    
    if field == "phi":
        beta_like = float(cfg_get(ctx, "beta", 0))
    else:
        beta_like = float(cfg_get(ctx, "beta_model", 0))

    
    # ── NEW: derive which/mu_key/sigma_key locally (keeps rest of code intact)
    which = "q" if field == "phi" else "p"                            # NEW
    mu_key    = "mu_q_field"    if which == "q" else "mu_p_field"     # NEW
    sigma_key = "sigma_q_field" if which == "q" else "sigma_p_field"  # NEW

    # (unchanged) direct field access if you need them later
    mu_q, S_q = agent_i.mu_q_field, agent_i.sigma_q_field
    mu_p, S_p = agent_i.mu_p_field, agent_i.sigma_p_field

    # cache-owned transforms
    Phi_mat, Phi_tilde_mat = _phi_mats(ctx, agent_i)


    mu_q_push, S_q_push, inv_q_push = push_gaussian(
        mu=mu_q, Sigma=S_q, M=Phi_mat, eps=eps,
        symmetrize=True, sanitize=True, approx="exact",
        near_identity_tau=tau, return_inv=True,
    )
    mu_p_push, S_p_push, inv_p_push = push_gaussian(
        mu=mu_p, Sigma=S_p, M=Phi_tilde_mat, eps=eps,
        symmetrize=True, sanitize=True, approx="exact",
        near_identity_tau=tau, return_inv=True,
    )

    # self + feedback grads (Euclidean)
    g_self_mu, g_self_S, g_fb_mu, g_fb_S = _self_and_feedback_grads(
        mode,
        mu_q, S_q, mu_p, S_p,
        mu_q_push, S_q_push, inv_q_push,
        mu_p_push, S_p_push, inv_p_push,
        Phi_mat, Phi_tilde_mat, eps
    )

    
    mu_field = getattr(agent_i, mu_key)
    S_field  = getattr(agent_i, sigma_key)

    dmu_align = np.zeros_like(mu_field, dtype=np.float32)
    dS_align  = np.zeros_like(S_field,  dtype=np.float32)

    if beta_like != 0.0:
        for j_idx, agent_j, overlap in iter_overlapping_neighbors(
            agent_i, agents, support_eps=tau, symmetric=True
        ):
            add_mu_i, add_S_i = _accum_align_for_pair(
                ctx, agent_i, agent_j,
                fiber=which,
                mu_key=mu_key, sigma_key=sigma_key,
                overlap_mask=overlap, beta_like=beta_like,
                strict_numerics=strict_numerics, recover=recover, eps=eps
            )
            dmu_align[overlap] += add_mu_i[overlap]
            dS_align[overlap]  += add_S_i[overlap]
    # -------- NEW: accuracy term (belief only) --------
    g_vfe_mu = None
    g_vfe_S  = None
    if (
        mode == "belief"
        and bool(cfg_get(ctx, "enable_vfe", True))
        and bool(cfg_get(ctx, "enable_vfe_mu_sigma", True))
    ):
        y = getattr(agent_i, "observation_field", None)
        if y is not None:            
            try:                
                K_latent = int(mu_q.shape[-1])
                D_obs    = int(np.asarray(y).shape[-1])
                theta = ensure_theta(ctx, D_obs=D_obs, K_latent=K_latent)
               
                w_vfe = float(cfg_get(ctx, "vfe_weight", 0.0))
               
                g_vfe_mu, g_vfe_S = vfe_mu_sigma_grads(
                    y=np.asarray(y, np.float32),
                    mu=np.asarray(mu_q, np.float32),
                    Sigma=np.asarray(S_q, np.float32),
                    W=np.asarray(theta.W, np.float32),
                    b=np.asarray(theta.b, np.float32),
                    sigma2=float(theta.sigma2),
                    mask=np.asarray(agent_i.mask, np.float32)
                )                
            except Exception:                
                print("[mu-sigma vfe branch] FAIL\n\n\n\n\n")
                g_vfe_mu, g_vfe_S = None, None

    # totals (unchanged)
    dmu_total = alpha * g_self_mu    + lambd * g_fb_mu    + dmu_align
    dS_total  = alpha * g_self_S     + lambd * g_fb_S     + dS_align

    if g_vfe_mu is not None and g_vfe_S is not None:
        w_vfe = float(cfg_get(ctx, "vfe_weight", 0.0))
        dmu_total = dmu_total + w_vfe * g_vfe_mu
        dS_total  = dS_total  + w_vfe * g_vfe_S

    dS_total  = 0.5 * (dS_total + np.swapaxes(dS_total, -1, -2))

    # project to natural gradient for agent_i
    delta_mu, delta_S = apply_natural_gradient_batch(ctx,
        getattr(agent_i, mu_key), getattr(agent_i, sigma_key),
        dmu_total.astype(np.float32, copy=False),
        dS_total.astype(np.float32,  copy=False),
        mask=agent_i.mask,
        strict_numerics=strict_numerics,
        recover=(recover if not strict_numerics else None),
    )

    # accumulate (unchanged)
    if which == "q":                                            # NEW: use 'which'
        gmu_attr, gsig_attr = "grad_mu_q", "grad_sigma_q"
    else:
        gmu_attr, gsig_attr = "grad_mu_p", "grad_sigma_p"

    if getattr(agent_i, gmu_attr, None) is None:
        setattr(agent_i, gmu_attr,  np.zeros_like(getattr(agent_i, mu_key),    dtype=np.float32))
    if getattr(agent_i, gsig_attr, None) is None:
        setattr(agent_i, gsig_attr, np.zeros_like(getattr(agent_i, sigma_key), dtype=np.float32))

    setattr(agent_i, gmu_attr,  getattr(agent_i, gmu_attr)  + delta_mu)
    setattr(agent_i, gsig_attr, getattr(agent_i, gsig_attr) + delta_S)

    if PRINT_SIGN:
        aid = _aid(agent_i)
        ax = tuple(range(delta_mu.ndim - 1))
        mu_mean = np.mean(delta_mu, axis=ax)
        S_tr = np.mean(np.trace(delta_S, axis1=-2, axis2=-1), axis=ax)
        
        def sgns(vec): return "".join("+" if v>0 else "-" if v<0 else "0" for v in vec.tolist())
        print(f"[MU/SIG] mode={mode} ai={aid} "
              f"μ_sign={sgns(mu_mean)} μ_mean={np.array2string(mu_mean, precision=3, suppress_small=True)} "
              f"|μ|_mean={float(np.mean(np.abs(delta_mu))):.3e} "
              f"|Σ|_F_mean={float(np.mean(np.linalg.norm(delta_S.reshape(*delta_S.shape[:-2], -1), axis=-1))):.3e} "
              f"tr(ΔΣ)_mean={float(S_tr):.3e}",
              flush=True)

    return delta_mu, delta_S




def _self_and_feedback_grads(mode: str,
                             mu_q, sigma_q, mu_p, sigma_p,
                             mu_q_push, Sigma_q_push, inv_q_push,
                             mu_p_push, Sigma_p_push, inv_p_push,
                             Phi_mat, Phi_tilde_mat, eps: float):
    """
    Compute self/feedback grads for the chosen mode.
    """
    if mode == "belief":
        # belief self-energy uses p pushed into q-fiber
        g_self_mu, g_self_S = grad_self_energy_belief(
            mu_q, sigma_q, mu_p_push, inv_p_push, eps=eps
        )
        g_fb_mu, g_fb_S = grad_feedback_energy_belief(
            mu_q, sigma_q, mu_p, mu_q_push, Sigma_q_push, inv_q_push, sigma_p, Phi_mat, eps=eps
        )
    elif mode == "model":
        # model self-energy uses p in its own fiber against Φ̃·q
        g_self_mu, g_self_S = grad_self_energy_model(
            mu_q, sigma_q, mu_p_push, inv_p_push, Phi_tilde_mat, eps=eps
        )
        g_fb_mu, g_fb_S = grad_feedback_energy_model(
            mu_p, sigma_p, mu_q_push, Sigma_q_push, inv_q_push, Phi_mat, eps=eps
        )
    else:
        raise ValueError(f"Unsupported mode: {mode}")
    return g_self_mu, g_self_S, g_fb_mu, g_fb_S


def _accum_align_for_pair(ctx, agent_i, agent_j,
                          fiber: str, mu_key: str, sigma_key: str,
                          overlap_mask: np.ndarray, beta_like: float,
                          *, strict_numerics: bool, recover: str | None, eps: float):
    """
    Compute alignment contributions for pair (i,j),
    add natural-grad deltas into agent_j.*grad_*,
    and return the Euclidean contributions for agent_i on the overlap.
    """
    if beta_like == 0.0 or not np.any(overlap_mask):
        # nothing to do
        return 0.0, 0.0

    Omega_ij = Omega(ctx, agent_i, agent_j, which=fiber)
    mu_i,  S_i  = _pull_agent_fields(agent_i, mu_key, sigma_key)
    mu_j,  S_j  = _pull_agent_fields(agent_j, mu_key, sigma_key)

    mu_j_t, S_j_t, inv_j_t = push_gaussian(
        mu = mu_j, Sigma = S_j, M =Omega_ij, eps=eps,
        symmetrize=True, sanitize=True, approx="exact",
        near_identity_tau=0.0, return_inv=True,
    )
  
    # i-side grads (source frame)
    gμ_i, gΣ_i = grad_alignment_energy_source(mu_i, S_i, mu_j_t, inv_j_t, eps=eps)

    # j-side grads (target frame; must be accumulated as natural-grad deltas on j)
    gμ_j, gΣ_j = grad_alignment_energy_target(mu_i, S_i, mu_j_t, inv_j_t, Omega_ij, eps=eps)

    add_mu_j    = np.zeros_like(mu_j, dtype=np.float32)
    add_sigma_j = np.zeros_like(S_j,  dtype=np.float32)
    add_mu_j[overlap_mask]    = (beta_like * gμ_j)[overlap_mask]
    add_sigma_j[overlap_mask] = (beta_like * gΣ_j)[overlap_mask]

    dmu_j_nat, dS_j_nat = apply_natural_gradient_batch(ctx,
        mu_j, S_j, add_mu_j, add_sigma_j,
        mask=getattr(agent_j, "mask", None),
        strict_numerics=strict_numerics, recover=(recover if not strict_numerics else None),
    )

    # Accumulate into agent_j.*grad_* in-place
    if fiber == "q":
        gmu_attr, gsig_attr = "grad_mu_q", "grad_sigma_q"
    else:
        gmu_attr, gsig_attr = "grad_mu_p", "grad_sigma_p"

    if getattr(agent_j, gmu_attr, None) is None:
        setattr(agent_j, gmu_attr,  np.zeros_like(mu_j, dtype=np.float32))
    if getattr(agent_j, gsig_attr, None) is None:
        setattr(agent_j, gsig_attr, np.zeros_like(S_j, dtype=np.float32))

    setattr(agent_j, gmu_attr,  getattr(agent_j, gmu_attr)  + dmu_j_nat)
    setattr(agent_j, gsig_attr, getattr(agent_j, gsig_attr) + dS_j_nat)

    # Return Euclidean contrib for i (to be added by caller on overlap)
    return (beta_like * gμ_i), (beta_like * gΣ_i)




#==============================================================================
#
#                    FEEDBACK / SELF TERMS (unchanged math, safer numerics)
#==============================================================================

def grad_alignment_energy_source(mu_i, sigma_i, mu_j_t, sigma_j_t_inv, eps=1e-8):
    delta_mu = mu_i - mu_j_t
    grad_mu = np.einsum("...ij,...j->...i", sigma_j_t_inv, delta_mu, optimize=True)

    # sanitize once per call
    sigma_i = sanitize_sigma(np.asarray(sigma_i, dtype=np.float32), strict=True)
    sigma_i_inv = safe_batch_inverse(sigma_i)

    grad_sigma = 0.5 * (sigma_j_t_inv - sigma_i_inv)
    grad_sigma = 0.5 * (grad_sigma + np.swapaxes(grad_sigma, -1, -2))
    return grad_mu.astype(np.float32, copy=False), grad_sigma.astype(np.float32, copy=False)

def grad_alignment_energy_target(
    mu_i,
    sigma_i,
    mu_j_t,           # = Ω_ij @ mu_j            (transported target mean)
    sigma_j_t_inv,    # = (Ω_ij Σ_j Ω_ij^T)^{-1} (transported target precision)
    Omega_ij,         # transport matrix Ω_ij
    eps: float = 1e-8,
):
    """
    Exact Euclidean gradients of KL(N(mu_i, sigma_i) || N(mu_j', Sigma_j')) wrt J
    mapped back to j's frame via Ω_ij^T.  (Here mu_j' = Ω_ij mu_j, Sigma_j' = Ω_ij Σ_j Ω_ij^T.)

    Returns:
        grad_mu_j   (..., K)
        grad_sigma_j(..., K, K)  [symmetric]
    """
    # --- delta in i-frame ---
    mu_i    = np.asarray(mu_i,    dtype=np.float32)
    mu_j_t  = np.asarray(mu_j_t,  dtype=np.float32)
    dmu     = mu_i - mu_j_t                      # (..., K)

    # --- sanitize inputs we multiply with ---
    Omega_ij      = np.asarray(Omega_ij,      dtype=np.float32)
    sigma_j_t_inv = np.asarray(sigma_j_t_inv, dtype=np.float32)
   

    # Σ_i only enters the Σ_j-gradient; sanitize once
    sigma_i = sanitize_sigma(np.asarray(sigma_i, dtype=np.float32), strict=True)

    # ---------- μ_j gradient ----------
    # ∂_{μ_j'} KL = - Σ_j'^{-1} (μ_i - μ_j')  ;  map back: ∂_{μ_j} = Ω_ij^T ∂_{μ_j'}
    gmu_jp = -np.einsum("...ij,...j->...i", sigma_j_t_inv, dmu, optimize=True)
    grad_mu_j = np.einsum("...ji,...j->...i", Omega_ij, gmu_jp, optimize=True)
    grad_mu_j = grad_mu_j.astype(np.float32, copy=False)

    # ---------- Σ_j gradient ----------
    # ∂_{Σ_j'} KL = 1/2 [ -S'^-1 Σ_i S'^-1 - S'^-1 dμ dμ^T S'^-1 + S'^-1 ]
    t0 = -np.einsum("...ij,...jk,...kl->...il", sigma_j_t_inv, sigma_i, sigma_j_t_inv, optimize=True)
    t1 = -np.einsum("...ij,...j,...k,...kl->...il", sigma_j_t_inv, dmu, dmu, sigma_j_t_inv, optimize=True)
    t2 =  sigma_j_t_inv
    gSigma_jp = 0.5 * (t0 + t1 + t2)

    # map back: ∂_{Σ_j} = Ω_ij^T (∂_{Σ_j'}) Ω_ij
    grad_sigma_j = np.einsum("...ji,...jk,...kl->...il",
                             Omega_ij, gSigma_jp, np.swapaxes(Omega_ij, -1, -2), optimize=True)
    # symmetrize + scrub (just in case)
    grad_sigma_j = 0.5 * (grad_sigma_j + np.swapaxes(grad_sigma_j, -1, -2))
    

    return grad_mu_j, grad_sigma_j


def grad_feedback_energy_belief(mu_q, sigma_q, mu_p, mu_q_push,
                                sigma_q_push, sigma_q_push_inv, sigma_p, Phi, eps=1e-8):
    delta_mu = mu_p - mu_q_push
    tmp = np.einsum("...ij,...j->...i", sigma_q_push_inv, delta_mu, optimize=True)
    grad_mu = -np.einsum("...ji,...j->...i", Phi, tmp, optimize=True)

    A = np.einsum("...i,...j->...ij", delta_mu, delta_mu, optimize=True)

    term1 = sigma_q_push_inv
    term2 = np.einsum("...ik,...kl,...lj->...ij", sigma_q_push_inv, A,       sigma_q_push_inv, optimize=True)
    term3 = np.einsum("...ik,...kl,...lj->...ij", sigma_q_push_inv, sigma_p, sigma_q_push_inv, optimize=True)
    M = term1 - term2 - term3

    grad_sigma = 0.5 * np.einsum("...ki,...kl,...lj->...ij", Phi, M, Phi, optimize=True)
    grad_sigma = 0.5 * (grad_sigma + np.swapaxes(grad_sigma, -1, -2))
    return grad_mu.astype(np.float32, copy=False), grad_sigma.astype(np.float32, copy=False)


def grad_feedback_energy_model(mu_p, sigma_p, mu_q_push,
                               sigma_q_push, sigma_q_push_inv, Phi=None, eps=1e-8):
    
    sigma_q_push = sanitize_sigma(np.asarray(sigma_q_push, dtype=np.float32), strict=True)
    if sigma_q_push_inv is None:
        sigma_q_push_inv = safe_batch_inverse(sigma_q_push)

    delta_mu = mu_p - mu_q_push
    grad_mu = np.einsum("...ij,...j->...i", sigma_q_push_inv, delta_mu, optimize=True)

    sigma_p = sanitize_sigma(np.asarray(sigma_p, dtype=np.float32), strict=True)
    sigma_p_inv = safe_batch_inverse(sigma_p)

    grad_sigma = 0.5 * (sigma_q_push_inv - sigma_p_inv)
    grad_sigma = 0.5 * (grad_sigma + np.swapaxes(grad_sigma, -1, -2))
    return grad_mu.astype(np.float32, copy=False), grad_sigma.astype(np.float32, copy=False)


def grad_self_energy_belief(mu_q, sigma_q, mu_p_push, sigma_p_push_inv, eps=1e-8, mask=None):
    delta_mu = mu_q - mu_p_push
    grad_mu = np.einsum("...ij,...j->...i", sigma_p_push_inv, delta_mu, optimize=True)

    sigma_q = sanitize_sigma(np.asarray(sigma_q, dtype=np.float32), strict=True)
    sigma_q_inv = safe_batch_inverse(sigma_q)

    grad_sigma = 0.5 * (sigma_p_push_inv - sigma_q_inv)
    grad_sigma = 0.5 * (grad_sigma + np.swapaxes(grad_sigma, -1, -2))

    if mask is not None:
        m = (np.asarray(mask) > float(getattr(config, "support_tau", 0.0)))
        grad_mu    = grad_mu * m[..., None]
        grad_sigma = grad_sigma * m[..., None, None]

    return grad_mu.astype(np.float32, copy=False), grad_sigma.astype(np.float32, copy=False)


def grad_self_energy_model(mu_q, sigma_q, mu_p_push, sigma_p_push_inv, Phi_tilde, eps=1e-8, mask=None):
    """
    ∂ wrt (μ_p, Σ_p) of KL(q || Φ̃·p), with A = Φ̃ Σ_p Φ̃ᵀ and Δ = μ_q − μ_p^t.
    """
    delta_mu = mu_q - mu_p_push
    tmp = np.einsum("...ij,...j->...i", sigma_p_push_inv, delta_mu, optimize=True)
    grad_mu = -np.einsum("...ji,...j->...i", Phi_tilde, tmp, optimize=True)

    delta_mu_outer = np.einsum("...i,...j->...ij", delta_mu, delta_mu, optimize=True)

    M = sigma_p_push_inv
    G = M - np.einsum("...ik,...kl,...lj->...ij", M, delta_mu_outer, M, optimize=True) \
          - np.einsum("...ik,...kl,...lj->...ij", M, sigma_q,        M, optimize=True)

    Phi_tilde_T = np.swapaxes(Phi_tilde, -1, -2)
    grad_sigma = 0.5 * np.einsum("...ki,...ij,...jl->...kl", Phi_tilde_T, G, Phi_tilde, optimize=True)
    grad_sigma = 0.5 * (grad_sigma + np.swapaxes(grad_sigma, -1, -2))  # symmetrize

    if mask is not None:
        m = (np.asarray(mask) > float(getattr(config, "support_tau", 0.0)))
        grad_mu    = grad_mu * m[..., None]
        grad_sigma = grad_sigma * m[..., None, None]

    return grad_mu.astype(np.float32, copy=False), grad_sigma.astype(np.float32, copy=False)




def apply_natural_gradient_batch(
    ctx,
    mu_field,
    sigma_field,
    grad_mu_field,
    grad_sigma_field,
    mask=None,
    *,
    strict_numerics: bool = True,
    recover: str | None = None,      # None | "nan" | "zero"
    use_float64: bool = True,
):
    """
    Vectorized natural gradient for Gaussian fields:
        δμ = -Σ ∇_μ L
        δΣ = -2 Σ sym(∇_Σ L) Σ

    Args
    ----
    mu_field         : (H,W,K)
    sigma_field      : (H,W,K,K) SPD (full)
    grad_mu_field    : (H,W,K)
    grad_sigma_field : (H,W,K,K)
    mask             : (H,W) bool or float weights (optional)

    Returns
    -------
    delta_mu   : (H,W,K)
    delta_sigma: (H,W,K,K)
    """
    # ---- config via ctx (no globals) ----
      # your shared accessor
    

    eps          = float(cfg_get(ctx, "eps", 1e-10))
    support_tau  = float(cfg_get(ctx, "support_tau", 1e-6))
    clip_sigma   = cfg_get(ctx, "gradient_clip_sigma", None)  # may be None
    clip_mu      = cfg_get(ctx, "gradient_clip_mu", None)     # may be None
    clip_sigma   = float(clip_sigma) if clip_sigma not in (None, False) else None
    clip_mu      = float(clip_mu)    if clip_mu    not in (None, False) else None

    # ---- shapes / dtypes ----
    H, W, K = mu_field.shape
    N = H * W
    dtype = np.float64 if use_float64 else np.float32

    mu   = np.asarray(mu_field,         dtype=dtype).reshape(N, K)
    Sig  = np.asarray(sigma_field,      dtype=dtype).reshape(N, K, K)
    gmu  = np.asarray(grad_mu_field,    dtype=dtype).reshape(N, K)
    gSig = np.asarray(grad_sigma_field, dtype=dtype).reshape(N, K, K)

    # ---- SPD sanitize Σ and symmetrize ∇Σ ----
    Sig = sanitize_sigma(Sig, eps=eps, strict=True)  # must return symmetric SPD in dtype
    gSig = 0.5 * (gSig + np.swapaxes(gSig, -1, -2))

    # ---- natural steps ----
    dmu = -np.einsum("nik,nk->ni", Sig, gmu, optimize=True)
    tmp =  np.einsum("nij,njk->nik", Sig, gSig, optimize=True)
    dS  = -2.0 * np.einsum("nij,njk->nik", tmp, Sig, optimize=True)
    dS  = 0.5 * (dS + np.swapaxes(dS, -1, -2))  # symmetry guard

    # ---- mask / weights ----
    if mask is None:
        active = np.ones(N, dtype=bool)
        wts = None
    else:
        m = np.asarray(mask)
        if m.shape != (H, W):
            raise ValueError(f"mask shape {m.shape} != {(H, W)}")
        m = m.reshape(N)
        if m.dtype == bool:
            active = m
            wts = None
        else:
            active = m > support_tau
            wts = m.astype(dtype, copy=False)

    # ---- global norm clipping on active pixels ----
    if clip_sigma is not None and clip_sigma >= 0:
        ns = np.linalg.norm(dS.reshape(N, -1), axis=1)   # Frobenius per pixel
        cm = (ns > clip_sigma) & active
        if np.any(cm):
            scale = np.ones(N, dtype=dtype)
            # safe divide
            scale[cm] = clip_sigma / np.maximum(ns[cm], eps)
            dS *= scale[:, None, None]

    if clip_mu is not None and clip_mu >= 0:
        nm = np.linalg.norm(dmu, axis=1)
        cm = (nm > clip_mu) & active
        if np.any(cm):
            scale = np.ones(N, dtype=dtype)
            scale[cm] = clip_mu / np.maximum(nm[cm], eps)
            dmu *= scale[:, None]

    # ---- soft weights (if provided) ----
    if wts is not None:
        dmu *= wts[:, None]
        dS  *= wts[:, None, None]

    # ---- zero outside support ----
    if not np.all(active):
        ia = ~active
        dmu[ia] = 0.0
        dS[ia]  = 0.0

    # ---- strict numerics / recovery ----
    finite = np.isfinite(dmu).all() and np.isfinite(dS).all()
    if strict_numerics:
        if not finite:
            raise FloatingPointError("Nonfinite natural gradient (μ or Σ).")
    else:
        if not finite:
            if recover is None or recover == "nan":
                dmu = np.full_like(dmu, np.nan, dtype=dtype)
                dS  = np.full_like(dS,  np.nan, dtype=dtype)
            elif recover == "zero":
                dmu = np.zeros_like(dmu, dtype=dtype)
                dS  = np.zeros_like(dS,  dtype=dtype)
            else:
                raise ValueError(f"Unknown recover policy: {recover}")

    # ---- restore shapes / cast ----
    out_dtype = np.float32 if not use_float64 else dtype
    return dmu.reshape(H, W, K).astype(out_dtype), dS.reshape(H, W, K, K).astype(out_dtype)







