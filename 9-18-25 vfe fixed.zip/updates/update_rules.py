# -*- coding: utf-8 -*-
"""
Created on Wed Jul 23 10:32:58 2025

@author: chris and christine
"""

import time
from runtime_context import ensure_runtime_defaults, CacheHub
import numpy as np
from updates.update_compute_all_gradients import _apply_children, _compute_child_grads, apply_theta_updates
from updates.update_helpers import ( dirty_manager,  refresh_agents_light,    
     ensure_dirty,  ensure_observations )

from utils import list_nonnull
import core.config as config
from runtime_context import build_step_settings, cfg_get
from updates.update_terms_curvature_A import step_global_A


class PhaseTimer:
    """Context-manager timer that aggregates per-phase wall time on runtime_ctx."""
    def __init__(self, ctx):
        self.ctx = ctx
        if not hasattr(ctx, "timings") or getattr(ctx, "timings") is None:
            ctx.timings = {}

    def __call__(self, name: str):
        ctx = self.ctx
        class _T:
            def __enter__(_s):
                _s.t0 = time.perf_counter()
                return _s
            def __exit__(_s, *_):
                dt = time.perf_counter() - _s.t0
                ctx.timings[name] = ctx.timings.get(name, 0.0) + dt
        return _T()



# --- synchronous step (simplified, timed) ------------------------------------
def synchronous_step(agents, generators_q, generators_p, n_jobs=1, runtime_ctx=None):
    """
    Single-scale (children-only) synchronous update step.
    Evolves child agents, enforces caches, warms pairwise transport (KL refresh),
    and registers children. No parents/detection/spawn/xscale.
    """
    assert runtime_ctx is not None, "synchronous_step: pass runtime_ctx"
    assert agents and (len(agents) > 0), "synchronous_step: no agents"

    # ---- ctx defaults / cache ----
    runtime_ctx = ensure_runtime_defaults(runtime_ctx)

    if not getattr(runtime_ctx, "step_cfg", None):
        runtime_ctx.step_cfg = build_step_settings(config)

    if not hasattr(runtime_ctx, "cache") or runtime_ctx.cache is None:
        runtime_ctx.cache = CacheHub()

    step_now = int(getattr(runtime_ctx, "global_step", 0))
    runtime_ctx.cache.clear_on_step(step_now)

    # ---- unified dirty manager ----
    DM = dirty_manager(runtime_ctx)

    T = PhaseTimer(runtime_ctx)

    # ---------------- Phase 0: pre ----------------
    with T("pre"):
        children = list_nonnull(agents)
        if not children:
            runtime_ctx.register_agents(0, [])
            runtime_ctx.global_step += 1
            return agents

        # Fail fast if generators missing
        if generators_q is None or generators_p is None:
            raise ValueError("synchronous_step: generators_q/p must be provided (got None)")

        refresh_agents_light(children, generators_q, generators_p, ctx=runtime_ctx)
        ensure_observations(children, runtime_ctx)  # prepares .observation_field as needed

    # ---------------- Phase 1: child grads/apply ---
    with T("child_grad"):
        out = _compute_child_grads(runtime_ctx, children, children, generators_q, generators_p)
        if len(out) == 5:
            q_updates, p_updates, phi_grads, phi_m_grads, dtheta_parts = out
        else:
            q_updates, p_updates, phi_grads, phi_m_grads = out
            dtheta_parts = [None] * len(children)

    with T("child_apply"):
        _apply_children(children, (q_updates, p_updates, phi_grads, phi_m_grads),
                        n_jobs, ctx=runtime_ctx)

        # Mark children dirty for pairwise/KL refresh in the ensure phase
        DM.mark(*children, kl=True)

    # -------- Phase 1.5 — θ apply ONCE --------
    with T("theta_apply"):
        step = int(getattr(runtime_ctx, "global_step", 0))

        dtheta_sum = None
        for part in dtheta_parts:
            if part is None:
                continue
            dW, db, dS = part
            if dtheta_sum is None:
                dtheta_sum = [np.array(dW, np.float32),
                              np.array(db, np.float32),
                              float(dS)]
            else:
                dtheta_sum[0] += dW
                dtheta_sum[1] += db
                dtheta_sum[2] += dS

        if dtheta_sum is not None:
            clip = float(cfg_get(runtime_ctx, "theta_grad_clip", 0.0))
            if clip and clip > 0:
                def _clip_vec(X):
                    n = float(np.linalg.norm(X))
                    s = min(1.0, clip / (n + 1e-12))
                    return (X * s).astype(np.float32)
                dtheta_sum[0] = _clip_vec(dtheta_sum[0])
                dtheta_sum[1] = _clip_vec(dtheta_sum[1])
                dtheta_sum[2] = float(np.sign(dtheta_sum[2]) * min(abs(dtheta_sum[2]), clip))

            apply_theta_updates(runtime_ctx, tuple(dtheta_sum))

            th = runtime_ctx.theta
            print(
                f"[θ-APPLY] step={step} have_parts={dtheta_sum is not None} \n"
                f"|ΔW| = {np.linalg.norm(dtheta_sum[0]) if dtheta_sum else 0:.2e}\n"
                f"|Δb| = {np.linalg.norm(dtheta_sum[1]) if dtheta_sum else 0:.2e}\n"
                f"Δσ2  = {dtheta_sum[2] if dtheta_sum else 0:.2e}\n"
                f"|W|_F= {np.linalg.norm(th.W):.2e} σ2={th.sigma2:.2e}\n",
                flush=True
            )

    # ---------------- Phase 2: ensure/caches -------
    with T("ensure_children"):
        ensure_dirty(runtime_ctx, generators_q, generators_p, scope="children")

    # ---------------- Phase 3: optional global A update -------
    with T("A_update"):
        _ = step_global_A(runtime_ctx, children)   # ctx-only

    # ---------------- Phase 4: register/step -------
    with T("register"):
        runtime_ctx.register_agents(0, children)
        runtime_ctx.children_latest = children
        runtime_ctx.global_step    += 1

    # ---------------- Phase 5: timing --------------
    dbg = bool(cfg_get(runtime_ctx, "debug_phase_timing", True))
    if dbg:
        print("[timings]")
        for name, dt in sorted(getattr(runtime_ctx, "timings", {}).items()):
            print(f"  {name:20s} {dt:8.3f}s")
        if getattr(runtime_ctx, "counters", None):
            print("[counts]", runtime_ctx.counters)

    return agents














