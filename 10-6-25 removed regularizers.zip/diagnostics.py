
from __future__ import annotations
from typing import Any, Dict
import numpy as np
from utils import mask_hw
from runtime_context import energy_acc_get
from joblib import Parallel, delayed
from threadpoolctl import threadpool_limits

def _reduce(field: np.ndarray, mask: np.ndarray, kind: str) -> float:
    """
    Broadcast-safe reducer over spatial dims.
    field: arbitrary shape
    mask : broadcastable to field.shape
    kind : "sum" or "mean"
    """
    f = np.asarray(field, np.float32)
    m = np.asarray(mask)

    # Try to broadcast mask to field
    if m.shape != f.shape:
        pad = (1,) * max(0, f.ndim - m.ndim)
        try:
            m = np.broadcast_to(m.reshape(pad + m.shape), f.shape)
        except Exception as e:
            raise ValueError(f"reduce mismatch: field {f.shape} vs mask {m.shape}") from e

    # Treat non-bool masks as soft weights; bool masks as hard support
    if m.dtype == bool:
        if not m.any():
            return 0.0
        if kind == "sum":
            return float(f[m].sum())
        if kind == "mean":
            return float(f[m].mean())
    else:
        w = m.astype(np.float32, copy=False)
        if kind == "sum":
            return float((f * w).sum())
        if kind == "mean":
            tot_w = float(w.sum())
            return 0.0 if tot_w == 0.0 else float((f * w).sum() / tot_w)

    raise ValueError(f"unknown reduce kind {kind}")






# --- diagnostics.py ---

def total_energy(ctx, agents, *, return_breakdown=False, precomputed_metrics=None):
    M = precomputed_metrics if precomputed_metrics is not None else compute_global_metrics(ctx, agents)
    E = float(M.get("E_total", 0.0))
    if not return_breakdown:
        return E

    breakdown = {
        # weighted pieces that actually form the action
        "self":       float(M.get("self_sum_w",     M.get("self_sum", 0.0))),
        "feedback":   float(M.get("feedback_sum_w", M.get("feedback_sum", 0.0))),
        "align_q":    float(M.get("align_q_sum_w",  M.get("align_q_sum", 0.0))),
        "align_p":    float(M.get("align_p_sum_w",  M.get("align_p_sum", 0.0))),
        
        "mean_total": float(M.get("mean_total",     0.0)),
    }
    return E, breakdown



def _sum_beta_KL_from_ctx(ctx, which: str) -> float:
    """
    Sum_x,sum_(i<-j) beta_{ij}(x) * KL_{ij}(x) for a fiber ('q' or 'p').
    Assumes ctx._edge_beta_{q,p} and ctx._edge_kl_{q,p} are filled for this step.
    Returns a scalar float (sum over all receivers/edges/pixels).
    """
    if which not in ("q", "p"):
        raise ValueError(f"_sum_beta_KL_from_ctx: which must be 'q' or 'p', got {which!r}")

    beta_map = getattr(ctx, "_edge_beta_q" if which == "q" else "_edge_beta_p", {}) or {}
    kl_map   = getattr(ctx, "_edge_kl_q"   if which == "q" else "_edge_kl_p", {}) or {}

    total = 0.0
    for key, B in beta_map.items():
        K = kl_map.get(key, None)
        if K is None:
            # If a KL is missing for a β that exists, treat as zero contribution
            # (alternatively: raise RuntimeError to hard-enforce completeness)
            continue
        b = np.asarray(B, np.float32)
        k = np.asarray(K, np.float32)
        if b.shape != k.shape:
            raise ValueError(f"_sum_beta_KL_from_ctx: β shape {b.shape} != KL shape {k.shape} for edge {key}")
        total += float((b * k).sum())
    return float(total)



def print_action_breakdown(ctx, action_dict, *, stream=None):
    step = int(getattr(ctx, "global_step", -1))
    lines = []
    lines.append(f"[Action @ step {step}]")
    lines.append(f"  Action_total = {action_dict.get('Action_total', 0.0):.6e}")
    lines.append("  ---------------------------------------")
    lines.append(f"  Geom_total   = {action_dict.get('Geom_total', 0.0):.6e}")
   
    lines.append(f"  A_curv       = {action_dict.get('A_curv', 0.0):.6e}  ")
    lines.append(f"  A_cov        = {action_dict.get('A_cov', 0.0):.6e}")
   
    print("\n".join(lines), flush=True)


def print_energy_breakdown(ctx, metrics, *, hide_zero_weight=True):
       
    rows = [
        ("self(α)",      metrics.get("self_sum_w", 0.0),      metrics.get("self_mean", 0.0),      1.0),
        ("align_q(β)",   metrics.get("align_q_sum_w", 0.0),   metrics.get("align_q_mean", 0.0),   1.0),
        ("align_p(β)",   metrics.get("align_p_sum_w", 0.0),   metrics.get("align_p_mean", 0.0),   1.0),
        ("feedback(λ)",  metrics.get("feedback_sum_w", 0.0),  metrics.get("feedback_mean", 0.0),  1.0),
        
    ]

    print("\n[Energy Totals @ step {}]".format(int(getattr(ctx, "global_step", -1))))
    print("  E_total = {: .6e}  |  mean_total = {: .6e}".format(
        float(metrics.get("E_total", 0.0)),
        float(metrics.get("mean_total", 0.0)),
    ))
    print("  " + "-"*60)
    print("  {:<14} {:>14} {:>18} {:>8}   {:>14}".format(
        "term", "contrib_sum", "mean_per_px", "weight", "contrib_sum"))
    for name, contrib, mean_px, w in rows:
        if hide_zero_weight and (w == 0.0):
            continue
        print("  {:<14} {:>14.6e} {:>18.6e} {:>8g}   {:>14.6e}".format(
            name, float(contrib), float(mean_px), w, float(contrib)
        ))

    # Optional diagnostics: show *raw* ungated alignments (not used in action)
    aq_raw = float(metrics.get("align_q_sum_raw", 0.0))
    ap_raw = float(metrics.get("align_p_sum_raw", 0.0))
    if abs(aq_raw) + abs(ap_raw) > 0:
        print("  (diagnostic, not in action) align_q_raw = {: .6e} | align_p_raw = {: .6e}".format(aq_raw, ap_raw))
    print()



def compute_agent_metrics(ctx: Any, agent: Any) -> Dict[str, float]:
    """
    Returns per-agent RAW (unweighted) energy components.
    We keep self/feedback unweighted here to mirror alignment’s convention.
    Mass/curv are also raw; weighting (if any) is applied in compute_global_metrics.
    """
    cfg = getattr(ctx, "step_cfg", None)
    tau = float(getattr(cfg, "support_tau", 1e-6)) if cfg is not None else 1e-6
    m = mask_hw(getattr(agent, "mask", None), tau=tau, mode="bool2")
    if (m is None) or (not np.any(m)):
        return {
            "self_sum": 0.0, "self_mean": 0.0,
            "feedback_sum": 0.0, "feedback_mean": 0.0,
           
        }

    S = int(np.count_nonzero(m)) or 1

    # Prefer per-agent accumulators populated earlier (raw, unweighted)
    aid = getattr(agent, "id", None)
    self_sum = fb_sum = 0.0
    if aid is not None:
        v = energy_acc_get(ctx, f"self_sum[{aid}]", None)
        if v is not None: self_sum = float(v)
        v = energy_acc_get(ctx, f"feedback_sum[{aid}]", None)
        if v is not None: fb_sum = float(v)

    self_mean = self_sum / S
    fb_mean   = fb_sum   / S

    # Mass/curvature are computed here (raw)
   

    return {
        "self_sum": self_sum, "self_mean": self_mean,
        "feedback_sum": fb_sum, "feedback_mean": fb_mean,
        
    }



def compute_global_metrics(ctx, agents):
    

    cfg     = getattr(ctx, "step_cfg", None)
    tau     = cfg.support_tau
    n_jobs  = int(getattr(cfg, "metrics_n_jobs", 1))

    # Weights & options used in both grads and energy
    alpha   = float(getattr(cfg, "alpha", 0.0))
    lambd   = float(getattr(cfg, "feedback_weight", 0.0))

    def _one(a):
        m = mask_hw(a.mask, tau=tau, mode="bool2")
        S = int(np.count_nonzero(m))
        if S <= 0:
            return None
        d = compute_agent_metrics(ctx, a)  # RAW component pieces (self/feedback/mass/curv)
        return d, S

    with threadpool_limits(1):
        outs = Parallel(n_jobs=max(1, n_jobs), backend="threading", batch_size="auto")(
            delayed(_one)(a) for a in agents
        )

    totals = {"self_sum":0.0,"feedback_sum":0.0,"_S":0}

    for res in outs:
        if res is None:
            continue
        d, S = res
        for k in ("self_sum","feedback_sum"):
            totals[k] += float(d[k])
        totals["_S"] += int(S)

    S_tot = max(totals["_S"], 1)

    # Means (diagnostic)
    out = dict(totals)
    out["self_mean"]     = out["self_sum"]     / S_tot
    out["feedback_mean"] = out["feedback_sum"] / S_tot
   

    # === Alignment: use β-weighted sums (variational) ===
    align_q_sum_beta = _sum_beta_KL_from_ctx(ctx, "q")
    align_p_sum_beta = _sum_beta_KL_from_ctx(ctx, "p")

    # Store the β-weighted alignment as the canonical alignment energy
    out["align_q_sum"]  = align_q_sum_beta
    out["align_p_sum"]  = align_p_sum_beta
    out["align_q_mean"] = align_q_sum_beta / S_tot
    out["align_p_mean"] = align_p_sum_beta / S_tot

    # === Build weighted contributions actually used in the action ===
    self_w     = alpha * out["self_sum"]
    feedback_w = lambd * out["feedback_sum"]
    align_q_w  = out["align_q_sum"]    # β already included
    align_p_w  = out["align_p_sum"]    # β already included
    

    out["E_total"] = float(
        self_w + feedback_w +
        
        align_q_w + align_p_w
    )
    out["mean_total"] = float(
        (alpha  * out["self_mean"])     +
        (lambd  * out["feedback_mean"]) +
        out["align_q_mean"] + out["align_p_mean"] 
        
    )

    # expose weighted pieces (for breakdown/logging)
    out.update({
        "self_sum_w": self_w, "feedback_sum_w": feedback_w,
        "align_q_sum_w": align_q_w, "align_p_sum_w": align_p_w,
        
    })

    # (Optional) keep raw ungated alignment sums ONLY as clearly-labeled diagnostics
    # NOTE: not used in E_total; shown only if you explicitly print them
    out["align_q_sum_raw"] = float(getattr(ctx, "energy_acc", {}).get("align_q_sum", 0.0))
    out["align_p_sum_raw"] = float(getattr(ctx, "energy_acc", {}).get("align_p_sum", 0.0))

    return out


def compute_total_action(ctx, agents, precomputed_metrics=None):
    
    # 1) Geometric piece
    M_geom = precomputed_metrics if (precomputed_metrics is not None) \
             else compute_global_metrics(ctx, agents)
    A_geom = float(M_geom.get("E_total", 0.0))

    
    # 4) A terms (unchanged)
    fields = getattr(ctx, "fields", {}) or {}
    A_cov = float(fields.get("A_cov_energy_last", 0.0))
    A_curv = float(fields.get("A_curv_energy", 0.0))
    A_tot = float(A_geom + A_curv + A_cov )

    return {
        "Action_total": A_tot,
        "Geom_total":   A_geom,
        "A_curv":       A_curv,
        "A_cov":        A_cov,       
        "self_sum":     float(M_geom.get("self_sum", 0.0)),
        "feedback_sum": float(M_geom.get("feedback_sum", 0.0)),
        "align_q_sum":  float(M_geom.get("align_q_sum", 0.0)),
        "align_p_sum":  float(M_geom.get("align_p_sum", 0.0)),
       
    }


def _fiber_maps(ctx, which: str):
    """Fetch β/ KL maps and cfg for a fiber ('q' or 'p')."""
    if which not in ("q", "p"):
        raise ValueError(f"which must be 'q' or 'p', got {which}")
    beta_map = getattr(ctx, "_edge_beta_q" if which == "q" else "_edge_beta_p", {}) or {}
    kl_map   = getattr(ctx, "_edge_kl_q"   if which == "q" else "_edge_kl_p", {}) or {}
    cfg      = getattr(ctx, "_edge_beta_cfg", {}) or {}
    sub      = cfg.get(which, {})
    kappa    = float(sub.get("kappa", 1.0))
    mode     = str(sub.get("mode", "softmax")).lower()
    detach   = bool(cfg.get("detach", True))
    return beta_map, kl_map, {"kappa": kappa, "mode": mode, "detach": detach}


def summarize_beta_fiber(ctx, agents, *, which: str = "q") -> dict:
    """
    Returns a summary dict for β on a fiber:
      - n_edges, per-receiver softmax deviations, β min/mean/max, KL stats.
    Hard-fail if it encounters NaN/∞ or inconsistent shapes.
    """
    import numpy as np

    beta_map, kl_map, cfg = _fiber_maps(ctx, which)
    

    rec_stats = {}
    beta_vals = []
    kl_vals   = []

    # --- group β by receiver -----------------------------------------------
    by_recv = {}
    for (i_id, j_id), B in beta_map.items():
        b = np.asarray(B, np.float32)
        if not np.all(np.isfinite(b)):
            raise FloatingPointError(
                f"[β/{which}] non-finite values in edge (i={i_id}, j={j_id})"
            )
        by_recv.setdefault(int(i_id), []).append((int(j_id), b))

    # --- per-receiver checks ------------------------------------------------
    for i_id, lst in by_recv.items():
        if not lst:
            continue

        B_stack = np.stack([b for _, b in lst], axis=0)  # (J,*S)
        if not np.all(np.isfinite(B_stack)):
            raise FloatingPointError(f"[β/{which}] NaN/∞ in receiver {i_id}")

        s = np.sum(B_stack, axis=0)                      # (*S,)
        overlap_any = np.any(B_stack > 0, axis=0)        # (*S,) bool
        if overlap_any.size == 0:
            raise ValueError(f"[β/{which}] empty overlap mask for receiver {i_id}")

        if cfg["mode"] in ("softmax", "sm", "normexp"):
            err = np.abs(s - 1.0)
            dev_mean = float(err[overlap_any].mean())
            dev_max  = float(err[overlap_any].max())
        else:
            dev_mean = dev_max = 0.0

        # collect β and KL values on overlap
        beta_vals.extend(B_stack[:, overlap_any].ravel().tolist())
        for (j_id, _) in lst:
            K = kl_map.get((i_id, j_id))
            if K is None:
                continue
            K = np.asarray(K, np.float32)
            if K.shape != s.shape:
                raise ValueError(
                    f"[β/{which}] KL shape {K.shape} != β shape {s.shape} "
                    f"(i={i_id}, j={j_id})"
                )
            if not np.all(np.isfinite(K)):
                raise FloatingPointError(
                    f"[β/{which}] NaN/∞ in KL map (i={i_id}, j={j_id})"
                )
            kl_vals.extend(K[overlap_any].ravel().tolist())

        rec_stats[i_id] = {
            "senders": len(lst),
            "softmax_dev_mean": dev_mean,
            "softmax_dev_max":  dev_max,
        }

    if not beta_vals:
        raise RuntimeError(f"[β/{which}] no valid β values collected")

    if not kl_vals:
        raise RuntimeError(f"[β/{which}] no valid KL values collected")

    beta_arr = np.asarray(beta_vals, np.float32)
    kl_arr   = np.asarray(kl_vals,   np.float32)

    return {
        "fiber": which,
        "mode": str(cfg.get("mode")),
        "kappa": float(cfg.get("kappa")),
        "detach": bool(cfg.get("detach")),
        "n_edges": len(beta_map),
        "n_receivers": len(rec_stats),
        "receivers": rec_stats,
        "beta_min": float(beta_arr.min()),
        "beta_mean": float(beta_arr.mean()),
        "beta_max": float(beta_arr.max()),
        "kl_min":   float(kl_arr.min()),
        "kl_med":   float(np.median(kl_arr)),
        "kl_mean":  float(kl_arr.mean()),
        "kl_max":   float(kl_arr.max()),
    }


def print_beta_summary(ctx, agents):
    """
    Pretty-print both fibers’ β statistics.
    Raises immediately if summarize_beta_fiber detects any invalid data.
    """
    q = summarize_beta_fiber(ctx, agents, which="q")
    p = summarize_beta_fiber(ctx, agents, which="p")
    step = int(getattr(ctx, "global_step", -1))

    def _fmt(f):
        return (
            f"\n[β/{f['fiber']} | step {step}] "
            f"mode={f['mode']} κ={f['kappa']:.3g} detach={f['detach']} "
            f"| edges={f['n_edges']} recv={f['n_receivers']}\n"
            f"β[min/mean/max] = {f['beta_min']:.3g} / {f['beta_mean']:.3g} / {f['beta_max']:.3g}\n"
            f"KL[min/med/mean/max] = {f['kl_min']:.3g} / {f['kl_med']:.3g} / "
            f"{f['kl_mean']:.3g} / {f['kl_max']:.3g}\n"
        )

    #print(_fmt(q))
    #print(_fmt(p))

    for f in (q, p):
        if f["mode"] not in ("softmax", "sm", "normexp"):
            continue
        worst = max(
            ((s["softmax_dev_max"], i_id) for i_id, s in f["receivers"].items()),
            default=None,
        )
        if worst and worst[0] > 1e-3:
            raise RuntimeError(
                f"[β/{f['fiber']}] worst softmax deviation {worst[0]:.3e} "
                f"at receiver i={worst[1]}"
            )



