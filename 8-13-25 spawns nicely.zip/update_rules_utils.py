# -*- coding: utf-8 -*-
"""
Created on Tue Aug 12 20:10:51 2025

@author: chris and christine
"""

import numpy as np
import config

from generalized_diagnostics_metrics import compute_alignment_field_general
from bundle_morphism_utils import init_parent_morphisms
from preprocess_utils import build_all_omega_caches, build_all_lambda_caches, preprocess_all_agents

from parent_growth import compute_parent_growth_maps_pure, apply_parent_growth










def _assign_children_to_parents(children, parents_by_id, eps=1e-3):
    Pmasks = {int(pid): (np.asarray(P.mask, np.float32) > float(eps)) for pid, P in parents_by_id.items()}
    if not Pmasks:
        for ch in children: setattr(ch, "parent_id", -1)
        return
    for ch in children:
        cm = (np.asarray(ch.mask, np.float32) > float(eps))
        best, best_ov = -1, 0
        for pid, pm in Pmasks.items():
            ov = int((cm & pm).sum())
            if ov > best_ov:
                best, best_ov = pid, ov
        ch.parent_id = int(best) if best_ov > 0 else -1




def _grow_and_age_parents(ctx, children, params):
    """
    Phase E — growth (pure -> apply), then simple aging.
    ctx: runtime context with ctx.parents_by_region
    children: list of child agents (for coverage/KL inputs)
    params: (unused here, kept for signature consistency)
    """
    # no parents -> nothing to do
    if not getattr(ctx, "parents_by_region", None):
        return

    # --- compute (pure) ---
    growth_maps = compute_parent_growth_maps_pure(
        ctx, children,
        tau_grow=getattr(config, "parent_tau_grow", 0.30),     # allow "p60"
        tau_shrink=getattr(config, "parent_tau_shrink", 0.18), # allow "p40", etc.
        kappa=getattr(config, "parent_kappa", 0.05),           # allow "auto"
        grow_band=int(getattr(config, "parent_grow_band", 1)),
        shrink_band=int(getattr(config, "parent_shrink_band", 1)),
        mask_tau=float(getattr(config, "parent_growth_core_tau", 0.20)),
    )


    # --- apply (mutating) ---
    apply_parent_growth(
        ctx, growth_maps,
        eta_grow=float(getattr(config, "parent_eta_grow", 0.08)),
        eta_shrink=float(getattr(config, "parent_eta_shrink", 0.12)),
        min_area=int(getattr(config, "parent_min_area", 10)),
        max_area=getattr(config, "parent_max_area", None),
        delta_cap=float(getattr(config, "parent_delta_cap", 0.05)),
        blur_iters=int(getattr(config, "parent_blur_iters", 1)),
    )

    # --- aging / grace bookkeeping ---
    for P in ctx.parents_by_region.values():
        P._age = int(getattr(P, "_age", 0)) + 1
        if hasattr(P, "_grace"):
            P._grace = max(0, int(getattr(P, "_grace", 0)) - 1)

    # optional terse log
    if getattr(config, "debug_growth_log", False):
        thr = float(getattr(config, "parent_area_threshold",
                    getattr(config, "parent_growth_core_tau", 0.20)))

        areas = [int((np.asarray(P.mask) > thr).sum()) for P in ctx.parents_by_region.values()]
        if areas:
            print(f"[GROW] parents={len(areas)} median_area={int(np.median(areas))} max_area={max(areas)}")




def _pre_light(all_agents, params, Gq, Gp):
    pre = dict(params)
    pre["sanitize_strict"] = pre.get("sanitize_strict_pre", False)
    pre["exp_n_jobs"] = 1
    preprocess_all_agents(all_agents, pre, Gq, Gp)
    build_all_omega_caches(all_agents)
    build_all_lambda_caches(all_agents)





def _post_strict(all_agents, params, Gq, Gp):
    post = dict(params)
    post["sanitize_strict"] = True
    post["exp_n_jobs"] = 1
    preprocess_all_agents(all_agents, post, Gq, Gp)
    build_all_omega_caches(all_agents)
    build_all_lambda_caches(all_agents)




def _refresh_child_kl_fields(children, all_agents, eps):
    for A in children:
        A.cached_alignment_kl       = compute_alignment_field_general(all_agents, A.id, field_type="belief", log_eps=eps)
        A.cached_model_alignment_kl = compute_alignment_field_general(all_agents, A.id, field_type="model",  log_eps=eps)




def _as_parent_dict(obj):
    """Accept dict, list, or single parent object; return {pid: parent} dict."""
    import collections.abc as _abc
    if obj is None:
        return {}
    if isinstance(obj, dict):
        return {int(getattr(p, "id", pid)): p for pid, p in obj.items()}
    if isinstance(obj, _abc.Iterable) and not hasattr(obj, "mask"):
        return {int(getattr(p, "id", i)): p for i, p in enumerate(obj)}
    # single parent object
    return {int(getattr(obj, "id", 0)): obj}
