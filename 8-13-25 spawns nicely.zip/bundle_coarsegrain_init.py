# -*- coding: utf-8 -*-
"""
Created on Tue Aug 12 18:56:28 2025

@author: chris and christine
"""

from agent_initialization import initialize_agent_gradients
import numpy as np
import config



def _mm(A, B): return np.matmul(A, B)
def _mt(A):    return np.swapaxes(A, -1, -2)



def _get_omega(agent, field_name, generators, fallback_dim=None):
    if field_name == "phi" and getattr(agent, "_exp_phi", None) is not None:
        return agent._exp_phi
    if field_name == "phi_model" and getattr(agent, "_exp_phi_model", None) is not None:
        return agent._exp_phi_model
    # fallback: compute or broadcast I
    try:
        from omega import exp_lie_algebra_irrep
        phi = getattr(agent, field_name)
        return exp_lie_algebra_irrep(phi, generators)
    except Exception:
        K = fallback_dim or int(getattr(agent, "mu_q_field" if field_name=="phi" else "mu_p_field").shape[-1])
        H, W = agent.mask.shape
        eye = np.eye(K, dtype=np.float64)
        return np.broadcast_to(eye, (H, W, K, K)).copy()

# --- PATCH: robust, Λ-free coarse-grain with rotation-only transport and SPD-safe aggregation ---

def _nearest_orthogonal(E):
    # Polar orthogonal factor of E (...,K,K)
    U, _, Vt = np.linalg.svd(E, full_matrices=False)
    return U @ Vt

def _spd_project_higham(S, eps=1e-8):
    # Project to SPD via Higham (eigen clip)
    S = 0.5 * (S + S.swapaxes(-1, -2))
    w, V = np.linalg.eigh(S)
    w = np.clip(w, eps, None)
    return (V * w[..., None, :]) @ V.swapaxes(-1, -2)

def _chol_apply_prec(S, X, ridge=1e-6):
    # Return S^{-1} X without explicit inverse (Cholesky solves)
    K = S.shape[-1]
    S = 0.5*(S + S.swapaxes(-1,-2)) + ridge*np.eye(K, dtype=S.dtype)
    L = np.linalg.cholesky(S)
    Y = np.linalg.solve(L, X)
    return np.linalg.solve(L.swapaxes(-1,-2), Y)




def _coarsegrain_gaussian_basic(parent, children, *, which="belief",
                                mask_tau=0.3, use_rotation=False,
                                eps=1e-8, shrink_to_I=0.05, cond_cap=1e6):
    import numpy as np
    import config

    # ---------- debug helpers ----------
    dbg = bool(getattr(config, "cg_debug_shapes", False))
    pid = getattr(parent, "id", "?")

    def shp(x):
        try:
            a = np.asarray(x)
            return f"{a.shape} (nd={a.ndim})"
        except Exception:
            return "<na>"

    def D(msg):
        if dbg:
            print(f"[CG/DBG p={pid} {which[0]}] {msg}")

    # ---------- pick fields ----------
    if which == "belief":
        get_mu = lambda A: np.asarray(A.mu_q_field, dtype=np.float64)
        get_S  = lambda A: np.asarray(A.sigma_q_field, dtype=np.float64)
        out_dtype = getattr(getattr(parent, "mu_q_field", None), "dtype", np.float32)
        get_Om = (lambda A: _get_omega(A, "phi", A.generators_q,
                                       fallback_dim=get_mu(A).shape[-1]).astype(np.float64)
                   ) if use_rotation else None
    else:
        get_mu = lambda A: np.asarray(A.mu_p_field, dtype=np.float64)
        get_S  = lambda A: np.asarray(A.sigma_p_field, dtype=np.float64)
        out_dtype = getattr(getattr(parent, "mu_p_field", None), "dtype", np.float32)
        get_Om = (lambda A: _get_omega(A, "phi_model", A.generators_p,
                                       fallback_dim=get_mu(A).shape[-1]).astype(np.float64)
                   ) if use_rotation else None

    # ---------- parent sizes ----------
    m_parent = np.asarray(parent.mask, np.float32)
    if m_parent.ndim != 2:
        m_parent = np.squeeze(m_parent)
    if m_parent.ndim != 2:
        raise RuntimeError(f"Parent mask has bad shape {m_parent.shape} (expected (H,W)).")
    H, W = m_parent.shape
    K = int(get_mu(parent).shape[-1])
    I = np.eye(K, dtype=np.float64)
    support = (m_parent > mask_tau)

    D(f"HW={(H,W)} K={K} use_rot={use_rotation}")
    if dbg:
        try:
            D(f"parent.mu raw {shp(get_mu(parent))}")
            D(f"parent.S  raw {shp(get_S(parent))}")
            if use_rotation: D(f"parent.Omega raw {shp(get_Om(parent))}")
        except Exception as e:
            D(f"parent field probe failed: {e}")

    # ---------- coercers ----------
    def _nearest_Q(M):
        U, _, Vt = np.linalg.svd(M, full_matrices=False)
        return U @ Vt

    def _ensure_rot_4d(R):
        R = np.asarray(R, np.float64)
        if R.ndim == 2 and R.shape == (K, K):
            Rb = np.broadcast_to(R, (H, W, K, K))
        elif R.ndim == 4 and R.shape[-2:] == (K, K):
            Rb = R if R.shape[:2] == (H, W) else np.broadcast_to(R, (H, W, K, K))
        elif R.ndim >= 5 and R.shape[-2:] == (K, K):
            start = 2 if R.shape[:2] == (H, W) else 0
            Rm = R.mean(axis=tuple(range(start, R.ndim - 2)))
            if Rm.ndim == 2: Rm = np.broadcast_to(Rm, (H, W, K, K))
            Rb = _nearest_Q(Rm)
        else:
            Rb = np.broadcast_to(I, (H, W, K, K))
        if dbg and R.ndim >= 5:
            D(f"ROT had stack -> collapsed {shp(R)} -> {shp(Rb)}")
        return Rb

    def _ensure_hwk(X, tag="mu"):
        X = np.asarray(X, np.float64)
        X0 = X
        if X.ndim == 1 and X.shape[0] == K:
            X = np.broadcast_to(X, (H, W, K))
        elif X.ndim == 3 and X.shape[-1] == K:
            X = X if X.shape[:2] == (H, W) else np.broadcast_to(X, (H, W, K))
        elif X.ndim >= 4 and X.shape[-1] == K:
            start = 2 if X.shape[:2] == (H, W) else 0
            X = X.mean(axis=tuple(range(start, X.ndim - 1)))
            if X.ndim == 1: X = np.broadcast_to(X, (H, W, K))
            if dbg: D(f"{tag} had stack -> collapsed {shp(X0)} -> {shp(X)}")
        else:
            raise RuntimeError(f"{tag} field bad shape {X.shape} (expected (...,K))")
        return X

    def _ensure_hwkk(S, tag="Sigma"):
        S = np.asarray(S, np.float64)
        S0 = S
        if S.ndim == 2 and S.shape == (K, K):
            S = np.broadcast_to(S, (H, W, K, K))
        elif S.ndim == 4 and S.shape[-2:] == (K, K):
            S = S if S.shape[:2] == (H, W) else np.broadcast_to(S, (H, W, K, K))
        elif S.ndim >= 5 and S.shape[-2:] == (K, K):
            start = 2 if S.shape[:2] == (H, W) else 0
            S = S.mean(axis=tuple(range(start, S.ndim - 2)))
            if S.ndim == 2: S = np.broadcast_to(S, (H, W, K, K))
            if dbg: D(f"{tag} had stack -> collapsed {shp(S0)} -> {shp(S)}")
        else:
            raise RuntimeError(f"{tag} field bad shape {S.shape} (expected (...,K,K))")
        # SPD tidy
        S = 0.5 * (S + S.swapaxes(-1, -2)) + eps * I
        return S

    # ---------- rotations ----------
    if use_rotation:
        try:
            Rp_raw = get_Om(parent)
            Rp = _ensure_rot_4d(Rp_raw)
            if dbg: D(f"Rp raw {shp(Rp_raw)} -> {shp(Rp)}")
        except Exception as e:
            if dbg: D(f"Rp error: {e}; using I")
            Rp = np.broadcast_to(I, (H, W, K, K))
    else:
        Rp = np.broadcast_to(I, (H, W, K, K))

    # ---------- accumulators ----------
    sum_logS = np.zeros((H, W, K, K), dtype=np.float64)
    Wsum     = np.zeros((H, W),        dtype=np.float64)
    h_sum    = np.zeros((H, W, K),     dtype=np.float64)

    # ---------- children loop ----------
    for C in children:
        cid = getattr(C, "id", "?")
        mC = np.asarray(getattr(C, "mask", 0.0), np.float32)
        if mC.ndim != 2:
            mC = mC.reshape(mC.shape[0], mC.shape[1], -1).max(axis=-1)
        if mC.shape != (H, W):
            from parent_mask_utils import resize_nn
            mC = resize_nn(mC, (H, W)).astype(np.float32)

        overlap = (mC > mask_tau) & support
        if not np.any(overlap):
            if dbg: D(f"child {cid}: no overlap")
            continue

        muC_raw = get_mu(C)
        SC_raw  = get_S(C)
        if dbg:
            D(f"child {cid}: mu raw {shp(muC_raw)}  S raw {shp(SC_raw)}")
            if use_rotation:
                try: D(f"child {cid}: Rc raw {shp(get_Om(C))}")
                except Exception as e: D(f"child {cid}: Rc err {e}")

        # enforce K
        if muC_raw.shape[-1] != K or SC_raw.shape[-2:] != (K, K):
            if dbg: D(f"child {cid}: skip (latent mismatch)")
            continue

        muC = _ensure_hwk(muC_raw, "muC")
        SC  = _ensure_hwkk(SC_raw,  "SC")

        # relative rotation
        if use_rotation:
            try:
                Rc = _ensure_rot_4d(get_Om(C))
                Rrel = Rp @ Rc.swapaxes(-1, -2)  # (H,W,K,K)
                if dbg: D(f"child {cid}: Rc {shp(Rc)} Rrel {shp(Rrel)}")
            except Exception as e:
                if dbg: D(f"child {cid}: Rrel err {e}; I")
                Rrel = np.broadcast_to(I, (H, W, K, K))
        else:
            Rrel = np.broadcast_to(I, (H, W, K, K))

        # transport
        muT = (Rrel @ muC[..., None])[..., 0]         # (H,W,K)
        ST  = Rrel @ SC @ Rrel.swapaxes(-1, -2)       # (H,W,K,K)
        ST  = 0.5 * (ST + ST.swapaxes(-1, -2)) + eps * I

        if dbg:
            D(f"child {cid}: muT {shp(muT)} ST {shp(ST)}")

        # eigens
        evals, V = np.linalg.eigh(ST)                 # (H,W,K), (H,W,K,K)
        if dbg and (evals.ndim != 3 or V.ndim != 4):
            D(f"child {cid}: eigh weird evals {shp(evals)} V {shp(V)}")

        evals = np.clip(evals, eps, None)
        logS  = (V * np.log(evals)[..., None, :]) @ V.swapaxes(-1, -2)

        w = overlap.astype(np.float64)
        sum_logS += w[..., None, None] * logS
        Wsum     += w
        invS_mu  = (V * (1.0 / evals)[..., None, :]) @ (V.swapaxes(-1, -2) @ muT[..., None])
        h_sum    += (w[..., None] * invS_mu[..., 0])

    if dbg:
        D(f"sum_logS {shp(sum_logS)}  Wsum {shp(Wsum)}  h_sum {shp(h_sum)}  active={int((Wsum>0).sum())}")

    # ---------- finalize (pure broadcasting; collapse stacks if any) ----------
    mu_out = np.zeros((H, W, K), dtype=np.float64)
    S_out  = np.broadcast_to(I, (H, W, K, K)).copy()

    active = (Wsum > 0)
    if np.any(active):
        Wsafe = np.maximum(Wsum, 1.0)                             # (H,W)
        M = sum_logS / Wsafe[..., None, None]                     # (H,W,K,K)
        M = np.where(active[..., None, None], M, 0.0)

        if dbg: D(f"M pre {shp(M)}")
        # if somehow got a stack axis, collapse it here
        if M.ndim >= 5:
            start = 2 if M.shape[:2] == (H, W) else 0
            M = M.mean(axis=tuple(range(start, M.ndim - 2)))
            if dbg: D(f"M collapsed -> {shp(M)}")

        eM, VM = np.linalg.eigh(0.5 * (M + M.swapaxes(-1, -2)))
        eM = np.clip(eM, np.log(eps), None)
        Sigma = (VM * np.exp(eM)[..., None, :]) @ VM.swapaxes(-1, -2)

        rhs = (h_sum / Wsafe[..., None])[..., None]               # (H,W,K,1)
        mu_cons = (Sigma @ rhs)[..., 0]                           # (H,W,K)

        if dbg: D(f"Sigma pre-mask {shp(Sigma)}  mu_cons pre {shp(mu_cons)}")
        # collapse *again* if any stray axis showed up
        if Sigma.ndim >= 5:
            start = 2 if Sigma.shape[:2] == (H, W) else 0
            Sigma = Sigma.mean(axis=tuple(range(start, Sigma.ndim - 2)))
            D(f"Sigma collapsed -> {shp(Sigma)}")
        if mu_cons.ndim >= 4:
            start = 2 if mu_cons.shape[:2] == (H, W) else 0
            mu_cons = mu_cons.mean(axis=tuple(range(start, mu_cons.ndim - 1)))
            D(f"mu_cons collapsed -> {shp(mu_cons)}")

        # regularize Σ
        Sigma = (1.0 - shrink_to_I) * Sigma + shrink_to_I * I
        ev2, V2 = np.linalg.eigh(0.5 * (Sigma + Sigma.swapaxes(-1, -2)))
        ev2 = np.clip(ev2, eps, None)
        kappa = ev2.max(axis=-1, keepdims=True) / np.maximum(ev2.min(axis=-1, keepdims=True), eps)
        too_cond = (kappa > cond_cap)[..., None]
        ev2 = np.where(too_cond,
                       np.clip(ev2, ev2.max(axis=-1, keepdims=True) / cond_cap, None),
                       ev2)
        Sigma = (V2 * ev2[..., None, :]) @ V2.swapaxes(-1, -2)

        mu_out = np.where(support[..., None],       mu_cons, 0.0)
        S_out  = np.where(support[..., None, None], Sigma,  I)

    if dbg:
        D(f"S_out final {shp(S_out)}  mu_out {shp(mu_out)}")

    if S_out.ndim != 4 or S_out.shape[:2] != (H, W) or S_out.shape[-2:] != (K, K):
        raise RuntimeError(f"S_out bad shape {S_out.shape}")
    return mu_out.astype(out_dtype), S_out.astype(out_dtype)



def coarsegrain_parent_from_children(parent, children, *, eps=1e-6, mask_tau=0.3):
    """
    Populate parent's μ/Σ (belief & model) by coarse-graining children's aligned Gaussians.
    Λ-free, SPD-safe, rotation-only transport. Assigns consensus directly to the parent.
    """
    # --- shape contracts ---------------------------------------------------
    # parent mask must be (H,W); parent fields (if present) must be 3D/4D
    parent.mask = np.asarray(parent.mask, np.float32)
    if parent.mask.ndim != 2:
        parent.mask = np.squeeze(parent.mask)
    if parent.mask.ndim != 2:
        raise RuntimeError(f"Parent mask has bad shape {parent.mask.shape} (expected (H,W)).")
    
    H, W = parent.mask.shape
    
    def _chk_field(name, arr, nd):
        if arr is None:
            return
        A = np.asarray(arr)
        if A.ndim != nd:
            raise RuntimeError(f"{name} has bad shape {A.shape} (expected {nd}D).")
    
    _chk_field("parent.mu_q_field",    getattr(parent, "mu_q_field", None),    3)
    _chk_field("parent.sigma_q_field", getattr(parent, "sigma_q_field", None), 4)
    _chk_field("parent.mu_p_field",    getattr(parent, "mu_p_field", None),    3)
    _chk_field("parent.sigma_p_field", getattr(parent, "sigma_p_field", None), 4)
    
    # children: masks (H,W), mu (H,W,K), sigma (H,W,K,K)
    for C in children:
        m = np.asarray(getattr(C, "mask", 0.0))
        if m.ndim != 2:
            mm = np.squeeze(m)
            if mm.ndim != 2:
                raise RuntimeError(f"Child {getattr(C,'id','?')} mask shape {m.shape} (expected (H,W)).")
        _chk_field("child.mu_q_field",    getattr(C, "mu_q_field", None),    3)
        _chk_field("child.sigma_q_field", getattr(C, "sigma_q_field", None), 4)
        _chk_field("child.mu_p_field",    getattr(C, "mu_p_field", None),    3)
        _chk_field("child.sigma_p_field", getattr(C, "sigma_p_field", None), 4)

    # Belief (q)
    mu_q, Sig_q = _coarsegrain_gaussian_basic(
        parent, children, which="belief", mask_tau=mask_tau,
        use_rotation=True,  eps=max(eps, 1e-8),
        shrink_to_I=float(getattr(config, "cg_shrink_I", 0.05)),
        cond_cap=float(getattr(config, "cg_cond_cap", 1e6)),
    )
    parent.mu_q_field    = mu_q
    parent.sigma_q_field = Sig_q

    # Model (p)
    mu_p, Sig_p = _coarsegrain_gaussian_basic(
        parent, children, which="model", mask_tau=mask_tau,
        use_rotation=True,  eps=max(eps, 1e-8),
        shrink_to_I=float(getattr(config, "cg_shrink_I", 0.05)),
        cond_cap=float(getattr(config, "cg_cond_cap", 1e6)),
    )
    parent.mu_p_field    = mu_p
    parent.sigma_p_field = Sig_p

    # Optional: sanitize via your existing utilities if available
    try:
        from numerical_utils import sanitize_sigma
        parent.sigma_q_field = sanitize_sigma(parent.sigma_q_field)
        parent.sigma_p_field = sanitize_sigma(parent.sigma_p_field)
    except Exception:
        pass

    # Ensure gradient buffers exist
    try:
        initialize_agent_gradients(parent)
    except Exception:
        pass


def weighted_mean_field(stack: np.ndarray, weights: np.ndarray, eps: float = 1e-8) -> np.ndarray:
    """
    stack:   (C, H, W, D)
    weights: (C, H, W, 1)  nonnegative
    return:  (H, W, D)
    """
    num = np.sum(weights * stack, axis=0)
    den = np.sum(weights, axis=0) + eps
    return num / den

def coarsen_phi_from_children(parent, children, *, field: str = "phi",
                              weight_mode: str = "mask", max_norm: float = np.pi, eps: float = 1e-6) -> None:
    """
    Build parent.{phi or phi_model} by weighted average of child fields in algebra (H,W,3).
    field: "phi" or "phi_model"
    weight_mode: "mask" | "mask*overlap" | callable(child)->(H,W,1)
    """
    if not getattr(parent, "child_ids", None):
        return
    C = len(parent.child_ids)

    phi_stack, w_stack = [], []
    for cid in parent.child_ids:
        ch = children[cid]
        phi_c = getattr(ch, field)               # (H,W,3)
        phi_stack.append(phi_c[..., :3][None, ...])
        if callable(weight_mode):
            w = weight_mode(ch)
        else:
            if weight_mode == "mask":
                w = ch.mask[..., None]
            elif weight_mode == "mask*overlap":
                w = (ch.mask * parent.mask)[..., None]
            else:
                w = ch.mask[..., None]
        w_stack.append(w[None, ...])

    phi_stack = np.concatenate(phi_stack, axis=0)   # (C,H,W,3)
    w_stack   = np.concatenate(w_stack,   axis=0)   # (C,H,W,1)

    phi_parent = weighted_mean_field(phi_stack, w_stack, eps=eps)  # (H,W,3)

    # clip radius for safety
    norms = np.linalg.norm(phi_parent, axis=-1, keepdims=True) + 1e-12
    scale = np.minimum(1.0, max_norm / norms)
    phi_parent = phi_parent * scale
    setattr(parent, field, phi_parent.astype(children[0].mu_q_field.dtype))



def _refresh_parent_gauge_fields(parents, agents, dtype) -> None:
    """
    Convenience: refresh both φ and φ̃ for every parent from its child set.
    """
    for P in parents:
        coarsen_phi_from_children(P, agents, field="phi",
            weight_mode=lambda ch, P=P: (ch.mask[..., None] * P.mask[..., None]).astype(dtype))
        coarsen_phi_from_children(P, agents, field="phi_model",
            weight_mode=lambda ch, P=P: (ch.mask[..., None] * P.mask[..., None]).astype(dtype))



def rg_weight(step, born_step, freeze=0, ramp=10, base=1.0):
    if step < born_step + freeze:
        return 0.0
    t = max(0, step - (born_step + freeze))
    if ramp <= 0:
        return float(base)
    return float(base) * min(1.0, t / ramp)


def build_child_weights(parent, child, *, mode="overlap", mask_tau=0.30):
    pm = (np.asarray(parent.mask, np.float32) > mask_tau)
    cm = (np.asarray(child.mask,  np.float32) > mask_tau)
    if callable(mode):
        w = mode(child).astype(np.float64)
    elif mode == "mask":
        w = cm[..., None].astype(np.float64)
    elif mode == "overlap":
        w = (pm & cm)[..., None].astype(np.float64)
    elif mode == "precision":
        # 1 / average variance proxy: K / trace(Σ)
        S = getattr(child, "sigma_q_field", None) or getattr(child, "sigma_p_field")
        tr = np.trace(S, axis1=-2, axis2=-1)
        K  = S.shape[-1]
        score = (K / (1e-12 + tr)).astype(np.float64)
        w = ((pm & cm)[..., None] * score[..., None]).astype(np.float64)
    else:
        w = (pm & cm)[..., None].astype(np.float64)
    # zero strictly outside parent support
    w[~pm, :] = 0.0
    return w

















