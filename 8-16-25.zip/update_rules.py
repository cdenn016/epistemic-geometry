# -*- coding: utf-8 -*-
"""
Created on Wed Jul 23 10:32:58 2025

@author: chris and christine
"""

import config
from detector import DetectorState, _detect_regions_pure
from update_compute_all_gradients import ( 
                        _apply_children, _compute_child_grads, _parent_intrascale_grad_pass, 
                        _final_apply_parents)

from update_rules_utils import ( _pre_light,  _post_strict,
                                 _assign_children_to_parents, 
                                 _as_parent_dict, prune_orphan_parents, compute_and_set_auto_agree_gate )


from parent_spawn import _apply_spawn_from_regions
from update_rules_utils import ( build_alignment_aggregates, take_dirty, _post_strict_subset,
                                mark_dirty, _refresh_child_kl_fields_subset, 
                                assign_parent_masks_from_alignment,  _invalidate_transport_caches)

from runtime_context import _Dirty






def synchronous_step(agents, generators_q, generators_p, params=None, n_jobs=1, runtime_ctx=None):
    assert runtime_ctx is not None, "synchronous_step: pass runtime_ctx"
    assert agents and (len(agents) > 0), "synchronous_step: no agents"
    params = params or {}
    
    # --------------------------- CTX INIT -----------------------------------
    if not hasattr(runtime_ctx, "detector_state") or (runtime_ctx.detector_state is None):
        runtime_ctx.detector_state = DetectorState()
    if not hasattr(runtime_ctx, "global_step"):
        runtime_ctx.global_step = 0
    if not hasattr(runtime_ctx, "parents_by_region") or (runtime_ctx.parents_by_region is None):
        runtime_ctx.parents_by_region = {}
    else:
        runtime_ctx.parents_by_region = _as_parent_dict(runtime_ctx.parents_by_region)
    if not hasattr(runtime_ctx, "next_parent_id"):
        runtime_ctx.next_parent_id = 0
    if not hasattr(runtime_ctx, "dirty"):
        runtime_ctx.dirty = _Dirty()
    if not hasattr(runtime_ctx, "cache_version"):
        runtime_ctx.cache_version = 0

    step_now = int(getattr(runtime_ctx, "global_step", 0))
    frozen_levels     = set(params.get("frozen_levels", []))
    frozen_phi_levels = set(params.get("frozen_phi_levels", []))

    # =========================== PRE (light) ================================
    parents = list(runtime_ctx.parents_by_region.values())
    all_agents = agents + parents
    _pre_light(all_agents, params, generators_q, generators_p)

    # ======================= CHILD GRADS/APPLY ==============================
    grads = _compute_child_grads(agents, all_agents, generators_q, generators_p, params)
    _apply_children(agents, grads, params, frozen_levels, frozen_phi_levels,
                    generators_q, generators_p, n_jobs)

    # mark children dirty (fields + KL need refresh)
    for a in agents:
        mark_dirty(runtime_ctx, a, kl=True)

        # strict subset/field rebuild on only dirty children
    dirty_children = take_dirty(runtime_ctx, agents, which="agents")
    _post_strict_subset(dirty_children, params, generators_q, generators_p)
    
    # refresh KL for only dirty children vs. current agents (kids + parents)
    dirty_children_kl = take_dirty(runtime_ctx, agents, which="kl")
    _refresh_child_kl_fields_subset(
        dirty_children_kl,
        agents + list(runtime_ctx.parents_by_region.values()),
        eps=config.eps,
        build_spawn=False,   # <-- don't build spawn caches here
    )
    
    # ================ ALIGNMENT AGGREGATES + AUTO GATE ======================
    try:
        build_alignment_aggregates(runtime_ctx, agents)
        if getattr(config, "detector_agree_auto", True):
            compute_and_set_auto_agree_gate(
                runtime_ctx,
                percentile=float(getattr(config, "detector_agree_percentile", 65.0)),
                ema=float(getattr(config, "detector_agree_ema", 0.2))
            )
    except Exception as e:
        if getattr(config, "debug_strict", True):
            print(f"[AGG] skipped: {e}")
    
    if getattr(config, "debug_detector_log", True):
        import numpy as _np
        A = getattr(runtime_ctx, "Aq_agg", None)
        if A is not None:
            print(f"[AGG] Aq_agg mean={float(_np.nanmean(A)):.3f} max={float(_np.nanmax(A)):.3f}")
    
    # === SPAWN CACHES (on-demand, only for changed children) ===================
    from update_rules_utils import ensure_spawn_alignment_caches
    ensure_spawn_alignment_caches(
        agents,
        agents + list(runtime_ctx.parents_by_region.values()),
        runtime_ctx,
        generators_q=generators_q,
        generators_p=generators_p,
        use_cover_weight=True,
        debug=getattr(config, "debug_spawn_log_details", False),
    )
    
    # =========================== DETECT / SPAWN =============================
    active_regions, cand_map = _detect_regions_pure(agents, params, runtime_ctx)
    if active_regions:
        new_parents = _apply_spawn_from_regions(runtime_ctx, active_regions,
                                                agents, generators_q, generators_p, params)
        if new_parents:
            # new parents: mark dirty & clear transport caches (φ/φ̃ initialized)
            for p in new_parents:
                mark_dirty(runtime_ctx, p)
            _invalidate_transport_caches(new_parents)
            runtime_ctx.cache_version += 1

    # =================== ASSIGN KIDS → PARENTS ==============================
    _assign_children_to_parents(
        agents, runtime_ctx.parents_by_region,
        eps=getattr(config, "support_cutoff_eps", 1e-3),
        tau=getattr(config, "parent_soft_assign_tau", 0.30),
        temp=getattr(config, "parent_soft_assign_temp", 0.25),
        max_parents_per_child=getattr(config, "parent_soft_assign_topk", 2),
        core_tau=getattr(config, "parent_assign_core_tau", 0.12),
        core_tau_rel=getattr(config, "parent_assign_core_tau_rel", 0.50),
        core_dilate_px=getattr(config, "parent_assign_core_dilate", 1),
        newborn_bootstrap_steps=getattr(config, "parent_assign_bootstrap", 2),
        allow_unassigned=True,
        agreement_map=getattr(runtime_ctx, "Aq_agg", None),
        use_agreement=getattr(config, "parent_assign_use_agreement", False),
        agree_weight=getattr(config, "parent_assign_agree_weight", 1.0),
        debug=getattr(config, "debug_assign_summary", False),
    )

    prune_orphan_parents(
        runtime_ctx.parents_by_region,
        patience=getattr(config, "orphan_patience_steps", 3),
        min_total_weight=getattr(config, "orphan_min_total_weight", 1e-4),
        min_area_nz=getattr(config, "orphan_min_area_nz", 5),
        support_tau=getattr(config, "parent_support_tau", 0.02),
        verbose=getattr(config, "debug_prune_log", False),
    )

    # =================== REBUILD PARENT MASKS (pure) ========================
    parents = list(runtime_ctx.parents_by_region.values())
    import numpy as _np
    _prev_masks = {int(pid): _np.asarray(P.mask, _np.float32).copy()
                   for pid, P in runtime_ctx.parents_by_region.items()} if parents else {}

    # build Ω caches for child→child transports used in evidence (cheap einsums)
    from update_rules_utils import build_all_omega_caches
    build_all_omega_caches(agents, strict=False, debug=False)

    assign_parent_masks_from_alignment(
        runtime_ctx,              # ctx that holds parents_by_region
        agents,                   # children list
        generators_q, generators_p,
        mode="max",               # or "mean"
        mask_tau=0.10,
        tau_q=float(getattr(config, "tau_align_q", 0.30)),
        tau_p=float(getattr(config, "tau_align_p", 0.30)),
        alpha=float(getattr(config, "blend_qp_alpha", 0.5)),
        agree_map=getattr(runtime_ctx, "Aq_agg", None),
        agree_power=1.0,
        clamp_to_union=True,
        kl_cap=float(getattr(config, "signal_kl_cap", 10.0)),
        floor_eps=1e-6,
        min_pair_px=8
    )

    # mark changed parents dirty & clear transports (mask/domain affects usage)
    tol = float(getattr(config, "parent_mask_change_tol", 1e-8))
    changed_parents = []
    for pid, P in runtime_ctx.parents_by_region.items():
        before = _prev_masks.get(int(pid))
        if before is None:
            changed_parents.append(P)
            continue
        now = _np.asarray(P.mask, _np.float32)
        if now.shape != before.shape or float(_np.max(_np.abs(now - before))) > tol:
            changed_parents.append(P)

    for p in changed_parents:
        mark_dirty(runtime_ctx, p)
    if changed_parents:
        _invalidate_transport_caches(changed_parents)
        runtime_ctx.cache_version += 1

    # ========== RECONCILE (hysteresis, CC/PBC, IoU + assignments) ===========
    from parent_semantics import reconcile_parent_masks_and_assignments
    H, W = agents[0].mask.shape
    periodic = bool(getattr(config, "periodic_domain", True))
    reconcile_parent_masks_and_assignments(runtime_ctx, agents, step_now, periodic=periodic, H=H, W=W)

    # delete parents flagged by reconcile
    to_del = [pid for pid, P in runtime_ctx.parents_by_region.items() if getattr(P, "_delete", False)]
    for pid in to_del:
        runtime_ctx.parents_by_region.pop(pid, None)

    # =================== PARENT GRADS/APPLY (intrascale) ====================
    parents = list(runtime_ctx.parents_by_region.values())
    if parents:
        _post_strict_subset(parents, params, generators_q, generators_p)  # refresh fields if needed

        _parent_intrascale_grad_pass(agents, parents, generators_q, generators_p, params, accum_into=True)
        _final_apply_parents(runtime_ctx, params)

        # parents changed → invalidate transports
        for p in parents:
            mark_dirty(runtime_ctx, p)
        _invalidate_transport_caches(parents)
        runtime_ctx.cache_version += 1

    # ================= FINAL STRICT (all agents, fresh) =====================
    parents = list(runtime_ctx.parents_by_region.values())
    all_agents = agents + parents
    _post_strict(all_agents, params, generators_q, generators_p)

    # bookkeeping
    runtime_ctx.children_latest = agents
    runtime_ctx.parents_latest  = runtime_ctx.parents_by_region
    runtime_ctx.global_step    += 1

    return agents




