# -*- coding: utf-8 -*-
"""
Created on Wed Aug  6 12:27:32 2025

@author: chris and christine
"""



import numpy as np
import config
from numerical_utils import sanitize_sigma, safe_inv
from natural_gradient import apply_natural_gradient_batch


def accumulate_mu_sigma_gradient(agent_i, agents, params, mode):
    """
    Accumulate natural gradient ∇μ and ∇Σ for belief or model.

    Args:
        agent_i : current agent
        agents  : list of all agents
        params  : simulation parameters
        mode    : "belief" or "model"
    """
    # Euclidean gradient
    dmu, dsigma = compute_mu_sigma_gradient_euclidean(agent_i, agents, params, mode)

    if mode == "belief":
        mu_field    = agent_i.mu_q_field
        sigma_field = agent_i.sigma_q_field
        grad_mu     = "grad_mu_q"
        grad_sigma  = "grad_sigma_q"
    elif mode == "model":
        mu_field    = agent_i.mu_p_field
        sigma_field = agent_i.sigma_p_field
        grad_mu     = "grad_mu_p"
        grad_sigma  = "grad_sigma_p"
    else:
        raise ValueError(f"Unsupported mode: {mode}")


    # Natural gradient projection
    delta_mu, delta_sigma = apply_natural_gradient_batch(
        mu_field,
        sigma_field,
        dmu,
        dsigma,
        mask=agent_i.mask,
    )

    # Accumulate
    setattr(agent_i, grad_mu, getattr(agent_i, grad_mu) + delta_mu)
    setattr(agent_i, grad_sigma, getattr(agent_i, grad_sigma) + delta_sigma)

from bundle_morphism_utils import pushforward_gaussian

def compute_mu_sigma_gradient_euclidean(agent_i, agents, params, mode):
    eps = config.support_cutoff_eps

    if mode == "belief":
        alpha  = params.get("alpha", config.alpha)
        beta   = params.get("beta", config.beta)
        lambd  = params.get("feedback_weight", config.feedback_weight)

        mu_q   = agent_i.mu_q_field
        sigma_q = agent_i.sigma_q_field
        mu_p   = agent_i.mu_p_field
        sigma_p = agent_i.sigma_p_field

        Phi        = agent_i.bundle_morphism_q_to_p
        Phi_tilde  = agent_i.bundle_morphism_p_to_q

        Omega_attr = "Omega_cache"
        mu_key     = "mu_q_field"
        sigma_key  = "sigma_q_field"

        # Pushforwards
        mu_p_push, sigma_p_push, sigma_p_push_inv = pushforward_gaussian(mu_p, sigma_p, Phi_tilde, eps=eps)
        mu_q_push, sigma_q_push, sigma_q_push_inv = pushforward_gaussian(mu_q, sigma_q, Phi, eps=eps)

        grad_self_mu, grad_self_sigma = grad_self_energy_belief(
            mu_q, sigma_q, mu_p_push, sigma_p_push_inv, eps=eps
        )
        grad_fb_mu, grad_fb_sigma = grad_feedback_energy_belief(
            mu_q, sigma_q,
            mu_p, mu_q_push, sigma_q_push, sigma_q_push_inv,
            sigma_p, Phi, eps=eps
        )

    elif mode == "model":
        alpha  = params.get("alpha", config.alpha)
        beta   = params.get("beta_model", config.beta_model)
        lambd  = params.get("feedback_weight", config.feedback_weight)

        mu_p   = agent_i.mu_p_field
        sigma_p = agent_i.sigma_p_field
        mu_q   = agent_i.mu_q_field
        sigma_q = agent_i.sigma_q_field

        Phi        = agent_i.bundle_morphism_q_to_p
        Phi_tilde  = agent_i.bundle_morphism_p_to_q

        Omega_attr = "Omega_tilde_cache"
        mu_key     = "mu_p_field"
        sigma_key  = "sigma_p_field"

        # Pushforwards
        mu_p_push, sigma_p_push, sigma_p_push_inv = pushforward_gaussian(mu_p, sigma_p, Phi_tilde, eps=eps)
        mu_q_push, sigma_q_push, sigma_q_push_inv = pushforward_gaussian(mu_q, sigma_q, Phi, eps=eps)

        grad_self_mu, grad_self_sigma = grad_self_energy_model(
            mu_q, sigma_q, mu_p_push, sigma_p_push_inv, Phi_tilde, eps=eps
        )
        grad_fb_mu, grad_fb_sigma = grad_feedback_energy_model(
            mu_p, sigma_p,
            mu_q_push, sigma_q_push, sigma_q_push_inv,
            Phi, eps=eps
        )

    else:
        raise ValueError(f"Unsupported mode: {mode}")

    # Alignment
    dmu_align = 0
    dsigma_align = 0
    for neighbor in agent_i.neighbors:
        agent_j = agents[neighbor["id"]]
        Omega_ij = getattr(agent_i, Omega_attr)[agent_j.id]

        mu_j    = getattr(agent_j, mu_key)
        sigma_j = getattr(agent_j, sigma_key)

        # Transport neighbor j → i using unified pushforward
        mu_j_t, sigma_j_t, sigma_j_t_inv = pushforward_gaussian(mu_j, sigma_j, Omega_ij, eps=eps)

        # Source fields for i
        mu_i    = mu_p if mode == "model" else mu_q
        sigma_i = sigma_p if mode == "model" else sigma_q

        dmu_i, dsigma_i = grad_alignment_energy_source(
            mu_i,
            sigma_i,
            mu_j_t,        # transported mean
            sigma_j_t_inv, # inverse transported covariance
            eps=eps
        )

        dmu_align    += dmu_i
        dsigma_align += dsigma_i

    dmu_total    = alpha * grad_self_mu + lambd * grad_fb_mu + beta * dmu_align
    dsigma_total = alpha * grad_self_sigma + lambd * grad_fb_sigma + beta * dsigma_align

    # 🔹 Add entropy regularization if in belief mode
    if mode == "belief":
        dsigma_total = accumulate_entropy_sigma_gradient(agent_i, dsigma_total, params)

    return dmu_total, dsigma_total




def accumulate_entropy_sigma_gradient(agent_i, grad_sigma_q, params):
    """
    Add entropy regularization to the Σ-gradient.

    Convention (default):
        E_total = E_other - gamma * H[q]
      ⇒ ∇_Σ E_total = ∇_Σ E_other - gamma * ∇_Σ H
      ⇒ with ∇_Σ H = ½ Σ^{-1}

    You can override the sign via params["entropy_in_energy_sign"] ∈ {+1, -1}.
    Use +1 if your energy includes +gamma * H (entropy penalty),
    use -1 if it includes -gamma * H (entropy reward, default here).
    """
    gamma = float(params.get("entropy_weight", getattr(config, "entropy_weight", 0.0)))
    if gamma == 0.0:
        return grad_sigma_q

    # Sign of entropy term in the energy:
    #   s = -1  →  E_total = E_other - γ H  (encourage higher entropy)
    #   s = +1  →  E_total = E_other + γ H  (penalize entropy)
    s = int(params.get("entropy_in_energy_sign", -1))

    # Compute ∇_Σ H = ½ Σ^{-1}, with SPD sanitization
    sigma_q = agent_i.sigma_q_field
    grad_H  = 0.5 * safe_inv(sigma_q, eps=getattr(config, "eps", 1e-8))

    # Restrict to agent support
    mask = (agent_i.mask > getattr(config, "support_cutoff_eps", 0.0))[..., None, None]
    grad_H = grad_H * mask

    # Combine: ∇_Σ E_total = ∇_Σ E_other + γ * s * ∇_Σ H
    return grad_sigma_q + gamma * s * grad_H



#==============================================================================
#
#                    FEEDBACK TERMS
#             everything validated below
#==============================================================================


def grad_alignment_energy_source(mu_i, sigma_i, mu_j_t, sigma_j_t_inv, eps=1e-8):
    delta_mu = mu_i - mu_j_t
    grad_mu = np.einsum("...ij,...j->...i", sigma_j_t_inv, delta_mu)

    
    sigma_i_inv = safe_inv(sigma_i, eps=eps)

    grad_sigma = 0.5 * (sigma_j_t_inv - sigma_i_inv)
    grad_sigma = 0.5 * (grad_sigma + np.swapaxes(grad_sigma, -1, -2))
    return grad_mu, grad_sigma


def grad_feedback_energy_belief(mu_q, sigma_q, mu_p, mu_q_push,
                                sigma_q_push, sigma_q_push_inv, sigma_p, Phi, eps=1e-8):
    delta_mu = mu_p - mu_q_push
    tmp = np.einsum("...ij,...j->...i", sigma_q_push_inv, delta_mu)
    grad_mu = -np.einsum("...ji,...j->...i", Phi, tmp)

    A = np.einsum("...i,...j->...ij", delta_mu, delta_mu)

    term1 = sigma_q_push_inv
    term2 = np.einsum("...ik,...kl,...lj->...ij", sigma_q_push_inv, A,       sigma_q_push_inv)
    term3 = np.einsum("...ik,...kl,...lj->...ij", sigma_q_push_inv, sigma_p, sigma_q_push_inv)
    M = term1 - term2 - term3

    grad_sigma = 0.5 * np.einsum("...ki,...kl,...lj->...ij", Phi, M, Phi)
    grad_sigma = 0.5 * (grad_sigma + np.swapaxes(grad_sigma, -1, -2))
    return grad_mu, grad_sigma


def grad_feedback_energy_model(mu_p, sigma_p, mu_q_push,
                               sigma_q_push, sigma_q_push_inv, Phi=None, eps=1e-8):
    # Validate / sanitize
    sigma_q_push = sanitize_sigma(sigma_q_push, eps=eps)
    if sigma_q_push_inv is None:
        sigma_q_push_inv = safe_inv(sigma_q_push, eps=eps)

    delta_mu = mu_p - mu_q_push
    grad_mu = np.einsum("...ij,...j->...i", sigma_q_push_inv, delta_mu)

    #sigma_p = sanitize_sigma(sigma_p, eps=eps)
    sigma_p_inv = safe_inv(sigma_p, eps=eps)

    grad_sigma = 0.5 * (sigma_q_push_inv - sigma_p_inv)
    grad_sigma = 0.5 * (grad_sigma + np.swapaxes(grad_sigma, -1, -2))
    return grad_mu, grad_sigma


def grad_self_energy_belief(mu_q, sigma_q, mu_p_push, sigma_p_push_inv, eps=1e-8, mask=None):
    delta_mu = mu_q - mu_p_push
    grad_mu = np.einsum("...ij,...j->...i", sigma_p_push_inv, delta_mu)

   
    sigma_q_inv = safe_inv(sigma_q, eps=eps)

    grad_sigma = 0.5 * (sigma_p_push_inv - sigma_q_inv)
    grad_sigma = 0.5 * (grad_sigma + np.swapaxes(grad_sigma, -1, -2))

    if mask is not None:
        grad_mu    = grad_mu * mask[..., None]
        grad_sigma = grad_sigma * mask[..., None, None]

    return grad_mu, grad_sigma

def grad_self_energy_model(mu_q, sigma_q, mu_p_push, sigma_p_push_inv, Phi_tilde, eps=1e-8, mask=None):
    """
    ∂ wrt (μ_p, Σ_p) of KL(q || Φ̃·p), with A = Φ̃ Σ_p Φ̃ᵀ and Δ = μ_q − μ_p^t.
    """
    # Δ and mean gradient
    delta_mu = mu_q - mu_p_push                                     # (..., K_q)
    tmp = np.einsum("...ij,...j->...i", sigma_p_push_inv, delta_mu) # A^{-1} Δ
    grad_mu = -np.einsum("...ji,...j->...i", Phi_tilde, tmp)        # -Φ̃ᵀ A^{-1} Δ

    # Covariance gradient core
   
    delta_mu_outer = np.einsum("...i,...j->...ij", delta_mu, delta_mu)

    M = sigma_p_push_inv
    G = M - np.einsum("...ik,...kl,...lj->...ij", M, delta_mu_outer, M) \
          - np.einsum("...ik,...kl,...lj->...ij", M, sigma_q,        M)

    Phi_tilde_T = np.swapaxes(Phi_tilde, -1, -2)
    grad_sigma = 0.5 * np.einsum("...ki,...ij,...jl->...kl", Phi_tilde_T, G, Phi_tilde)
    grad_sigma = 0.5 * (grad_sigma + np.swapaxes(grad_sigma, -1, -2))  # symmetrize

    if mask is not None:
        grad_mu    = grad_mu * mask[..., None]
        grad_sigma = grad_sigma * mask[..., None, None]

    return grad_mu, grad_sigma


