# === generalized_agent_distributions.py ===
import numpy as np
import config
import numpy as np
from numerical_utils import safe_inv


import numpy as np
from scipy.linalg import expm

from numerical_utils import sanitize_sigma


from scipy.ndimage import gaussian_filter
from config import diagonal_sigma

import numpy as np
from scipy.ndimage import gaussian_filter
import config

from omega import exp_lie_algebra_irrep



def generate_mu_sigma_fields( 
    domain_size,
    rng,
    K,
    mu_range,
    sigma_range,
    mask=None,
    sigma_outside_val=None,
    dtype=np.float32,
    smooth_sigma=None,
    diagonal_sigma=None,
    eps=None,
    floor=None,
):
    """
    Generate spatially varying (μ, Σ) fields with shape:
        μ     : (H, W, K)
        Σ     : (H, W, K, K)

    Args:
        domain_size        : (H, W)
        rng                : np.random.Generator
        K                  : int, fiber dimension
        mu_range           : tuple[float, float]
        sigma_range        : tuple[float, float]
        mask               : optional (H, W) float mask
        sigma_outside_val  : float, fallback Σ diagonal value outside support (must be positive)
        dtype              : np.float32 or np.float64
        smooth_sigma       : float, Gaussian blur width for smoothness
        diagonal_sigma     : bool, if True, initializes Σ diagonally
        eps                : float, minimal eigenvalue threshold for SPD enforcement
        floor              : float, floor value for numerical stability (not used here, reserved)

    Returns:
        mu_field     : (H, W, K)
        sigma_field  : (H, W, K, K)
    """
    import numpy as np
    from scipy.ndimage import gaussian_filter

    # Set safe, covariance-appropriate defaults
    eps = eps if eps is not None else 1e-6
    sigma_outside_val = sigma_outside_val if sigma_outside_val is not None else 1e3
    smooth_sigma = smooth_sigma if smooth_sigma is not None else 2.0
    diagonal_sigma = diagonal_sigma if diagonal_sigma is not None else False


    if sigma_outside_val <= 0.0:
        raise ValueError("sigma_outside_val must be positive for covariance")

    H, W = domain_size

    # Generate smooth mean field μ
    mu = rng.uniform(*mu_range, size=(H, W, K)).astype(dtype)
    for k in range(K):
        mu[..., k] = gaussian_filter(mu[..., k], sigma=smooth_sigma)

    # Generate covariance Σ field
    if diagonal_sigma:
        sigma_diag = rng.uniform(*sigma_range, size=(H, W, K)).astype(dtype)
        for k in range(K):
            sigma_diag[..., k] = gaussian_filter(sigma_diag[..., k], sigma=smooth_sigma)
        sigma_field = np.zeros((H, W, K, K), dtype=dtype)
        for k in range(K):
            # Enforce minimal eigenvalue via clipping on diagonal entries
            sigma_field[..., k, k] = np.clip(sigma_diag[..., k], eps, None)
    else:
        # Generate full covariance by A A^T + eps I construction
        A = rng.normal(0, 1, size=(H, W, K, K)).astype(dtype)
        for i in range(K):
            for j in range(K):
                A[..., i, j] = gaussian_filter(A[..., i, j], sigma=smooth_sigma)
        Sigma = np.einsum("...ik,...jk->...ij", A, A)
        for i in range(K):
            Sigma[..., i, i] += eps  # enforce positive definiteness
        # Normalize trace to desired scale
        trace = np.trace(Sigma, axis1=-2, axis2=-1)[..., None, None]
        target_trace = K * np.mean(sigma_range)
        Sigma *= target_trace / (trace + eps)
        sigma_field = Sigma

    # Final sanitization to ensure SPD
    from numerical_utils import sanitize_sigma
    sigma_field = sanitize_sigma(sigma_field, eps=eps)

    # Apply mask: zero μ and set fallback covariance outside support
    if mask is not None:
        mask = mask.astype(dtype)
        mu_zero = np.zeros_like(mu)
        sigma_outside = sigma_outside_val * np.eye(K, dtype=dtype)

        mu = mask[..., None] * mu + (1.0 - mask[..., None]) * mu_zero
        sigma_field = (
            mask[..., None, None] * sigma_field +
            (1.0 - mask[..., None, None]) * sigma_outside[None, None, :, :]
        )

    return mu, sigma_field





def generate_eta1_eta2_fields(
    domain_size,
    rng,
    K,
    eta1_range,
    eta2_range,
    mask=None,
    sigma_outside_val=None,
    dtype=np.float32,
    smooth_sigma=None,
    diagonal_eta2=None,
    floor=None,
    eps=None,
):
    eps          = eps if eps is not None else getattr(config, "eta2_min_eigval", 1e-4)
    floor        = floor if floor is not None else getattr(config, "eta2_floor", -0.5)
    sigma_outside_val = sigma_outside_val if sigma_outside_val is not None else getattr(config, "eta2_outside_val", -1.0)
    smooth_sigma = smooth_sigma if smooth_sigma is not None else getattr(config, "eta2_smooth_sigma", 2.0)
    diagonal_eta2 = diagonal_eta2 if diagonal_eta2 is not None else getattr(config, "diagonal_eta2_init", True)

    if sigma_outside_val >= 0.0:
        raise ValueError("sigma_outside_val must be negative")

    H, W = domain_size

    # ───── Temporary μ sampling: Uniform + smoothing ─────
    mu = rng.uniform(-config.mu_clip, config.mu_clip, size=(H, W, K)).astype(dtype)
    for k in range(K):
        mu[..., k] = gaussian_filter(mu[..., k], sigma=smooth_sigma)

    # ───── η₂ field ─────
    if diagonal_eta2:
        eta2_diag = rng.uniform(*eta2_range, size=(H, W, K)).astype(dtype)
        for k in range(K):
            eta2_diag[..., k] = gaussian_filter(eta2_diag[..., k], sigma=smooth_sigma)
        eta2_field = np.zeros((H, W, K, K), dtype=dtype)
        for k in range(K):
            eta2_field[..., k, k] = -np.abs(eta2_diag[..., k])  # ensure NSD
    else:
        A = rng.normal(0, 1, size=(H, W, K, K)).astype(dtype)
        for i in range(K):
            for j in range(K):
                A[..., i, j] = gaussian_filter(A[..., i, j], sigma=smooth_sigma)
        Sigma = np.einsum("...ik,...jk->...ij", A, A)
        for i in range(K):
            Sigma[..., i, i] += eps
        trace = np.trace(Sigma, axis1=-2, axis2=-1)[..., None, None]
        target_trace = K * np.mean(np.abs(eta2_range))
        Sigma *= target_trace / (trace + 1e-8)
        eta2_field = -0.5 * np.linalg.inv(Sigma)

    # ───── Sanitize BEFORE masking or scaling ─────
    eta2_field = sanitize_eta2_init(eta2_field, floor=floor, eps=eps)

    target_trace = 9
    # ───── Normalize trace AFTER sanitization ─────
    trace_eta2 = -np.trace(eta2_field, axis1=-2, axis2=-1)
    eta2_field *= target_trace / (trace_eta2[..., None, None] + eps)
    eta2_field = sanitize_eta2_init(eta2_field, floor=floor, eps=eps)  # <- sanitize last

    # ───── Mask support ─────
    if mask is not None:
        mask = mask.astype(dtype)
        mask_exp = mask[..., None]
        mu_floor = np.zeros_like(mu)
        eta2_floor = np.eye(K, dtype=dtype) * sigma_outside_val
        mu = mask_exp * mu + (1.0 - mask_exp) * mu_floor
        eta2_field = mask_exp[..., None] * eta2_field + (1.0 - mask_exp)[..., None] * eta2_floor

    # ───── Final η₁ from Gaussian consistency: η₁ = -2 η₂ μ ─────
    eta1_field = np.einsum("...ij,...j->...i", -2.0 * eta2_field, mu)

    return eta1_field, eta2_field





def rotate_eta_fields_via_phi_safe(
    eta1_field: np.ndarray,
    eta2_field: np.ndarray,
    phi_field: np.ndarray,
    generators: np.ndarray,
) -> tuple[np.ndarray, np.ndarray]:
    """
    Rotate η₁ and η₂ using the Lie group action exp(φ·G) for arbitrary K.
    Enforces η₂ is symmetric negative semi-definite (NSD).

    Args:
        eta1_field: (H, W, K)
        eta2_field: (H, W, K, K)
        phi_field : (H, W, 3)
        generators: (3, K, K)

    Returns:
        (rotated_eta1, rotated_eta2)
    """
    H, W, K = eta1_field.shape
    assert generators.shape == (3, K, K), f"Expected generators shape (3, {K}, {K}), got {generators.shape}"

    # Lie group action: ρ = exp(φ·G)
    rho_field = exp_lie_algebra_irrep(
        phi_field,
        generators,
        group_name="so3",
        max_norm=getattr(config, "phi_exp_clip", 10.0),
        n_jobs=-1,
        verbose=False
    )  # (H, W, K, K)

    # Rotate η₁
    rotated_eta1 = np.einsum("...ij,...j->...i", rho_field, eta1_field)

    # Rotate η₂: ρ η₂ ρᵀ
    rotated_eta2 = rho_field @ eta2_field @ np.swapaxes(rho_field, -1, -2)

    # Enforce symmetric NSD
    rotated_eta2 = sanitize_eta2_init(rotated_eta2, eps=1e-4, floor=-1e-3)

    # Diagnostic: verify spectrum
    eigvals = np.linalg.eigvalsh(rotated_eta2)
    if np.any(eigvals > 0):
        print(f"[WARNING] sanitize_eta2_init failed! Max eig = {np.max(eigvals):.2e}")
    else:
        print(f"[✓] η₂ NSD after rotation — max eig = {np.max(eigvals):.2e}")

    return rotated_eta1, rotated_eta2






def natural_to_mu_sigma(eta1, eta2, eps=1e-8):
    """
    Convert natural parameters (η₁, η₂) to standard form (μ, Σ).

    Args:
        eta1: (..., K)
        eta2: (..., K, K)
        eps:  regularization for safe inverse

    Returns:
        mu:    (..., K)
        sigma: (..., K, K)
    """
    sigma_inv = -2.0 * eta2
    sigma = safe_inv(sigma_inv, eps)
    mu = np.einsum('...ij,...j->...i', sigma, eta1)
    return mu, sigma




def mu_sigma_to_natural(mu, sigma, eps=1e-8):
    """
    Convert (μ, Σ) to natural parameters (η₁, η₂).

    η₁ = Σ⁻¹μ
    η₂ = -½ Σ⁻¹

    Args:
        mu:    (..., K)
        sigma: (..., K, K)
        eps:   regularization for safe inverse

    Returns:
        eta1: (..., K)
        eta2: (..., K, K)
    """
    sigma_inv = safe_inv(sigma, eps)
    eta1 = np.einsum('...ij,...j->...i', sigma_inv, mu)
    eta2 = -0.5 * sigma_inv
    return eta1, eta2



def sanitize_eta2_init(eta2, eps=1e-4, floor=-1e-3):
    """
    Force η₂ to be symmetric negative semi-definite (NSD).
    Clips all positive eigenvalues to zero.
    """
    eta2_sym = 0.5 * (eta2 + np.swapaxes(eta2, -2, -1))
    eigvals, eigvecs = np.linalg.eigh(eta2_sym)

    # Debug print
    max_eig = np.max(eigvals)
    if max_eig > 0:
        print(f"[WARNING] η₂ not NSD before sanitization: max eig = {max_eig:.3e}")

    # Strict clip
    eigvals_clipped = np.minimum(eigvals, floor)
    eta2_sanitized = np.einsum("...ik,...k,...jk->...ij", eigvecs, eigvals_clipped, eigvecs)
    return eta2_sanitized



