import config

def set_config_from_params(params):
    """Safely override known config attributes from a dictionary
    and then recompute all dependent quantities."""
    valid_keys = {
        k for k in dir(config)
        if not k.startswith("__") and not callable(getattr(config, k))
    }

    # 1) Override raw params into config.py
    for k, v in params.items():
        if k in valid_keys:
            setattr(config, k, v)
        else:
            print(f"[WARNING] Ignored unknown config key: '{k}'")

    # 2) Notice keys you didn’t touch
    unused = valid_keys - params.keys()
    #for k in sorted(unused):
        #print(f"[NOTICE] Config key '{k}' not set by params — using default or previous value.")

    # ── Recompute all dependent learning rates using scaled_eta ──────────────────
    config.eta_q = config.scaled_eta(
        config.eta_base_q,
        config.alpha,
        config.beta
    )
    config.eta_p = config.scaled_eta(
        config.eta_base_p,
        config.alpha,
        config.model_align_weight,
        config.model_feedback_weight,
        
        config.model_mass_weight
    )
    config.eta_phi = config.scaled_eta(
        config.eta_base_phi,
        config.gauge_weight,
        
        config.curvature_weight,
        config.phi_damping,
        config.phi_phi_tilde_coupling
    )
    config.eta_model_phi = config.scaled_eta(
        config.eta_base_phi_model,
        config.model_align_weight,
        
        config.model_mass_weight,
        config.phi_phi_tilde_coupling,
        config.phi_damping
    )
    # ───────────────────────────────────────────────────────────────────────────

    # ── Recompute spatial sizing & any K-dependent ranges ───────────────────────
    config.domain_size = (config.L,) * config.D
    config.q_mu_range = (2, config.K_q - 2)
    config.p_mu_range = (2, config.K_p - 2)
    # ───────────────────────────────────────────────────────────────────────────

    