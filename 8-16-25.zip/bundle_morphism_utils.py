# -*- coding: utf-8 -*-
"""
Created on Wed Jul 16 18:18:11 2025

@author: chris and christine
"""

# bundle_morphism_utils.py
import numpy as np
from typing import Optional, Tuple, List, Dict, Any, Union
import numpy as np
from scipy.ndimage import gaussian_filter
import config
from numerical_utils import sanitize_sigma, safe_inv, safe_logdet

from get_generators import get_generators

from scipy.linalg import expm
from collections import defaultdict

from omega import exp_lie_algebra_irrep


import numpy as np
from numerical_utils import sanitize_sigma, safe_inv


def pushforward_gaussian(mu, sigma, morphism, eps=1e-6):
    M = np.asarray(morphism)
    mu = np.asarray(mu); sigma = np.asarray(sigma)
    if M.ndim < 2:
        raise ValueError(f"morphism must be matrix-like, got shape {M.shape}")
    if M.shape[-1] != mu.shape[-1]:
        raise ValueError(f"morphism last dim {M.shape[-1]} != mu dim {mu.shape[-1]}")
    if M.shape[-1] != sigma.shape[-1] or M.shape[-2] != sigma.shape[-2]:
        # pushforward expects compatible dims
        pass  # allow non-square if that's your design; otherwise raise
    mu_push = np.einsum("...ik,...k->...i", M, mu)
    sigma = 0.5*(sigma + np.swapaxes(sigma, -1, -2)) + eps*np.eye(sigma.shape[-1])
    sigma_push = np.einsum("...ik,...kl,...jl->...ij", M, sigma, M)
    sigma_push = 0.5*(sigma_push + np.swapaxes(sigma_push, -1, -2)) + eps*np.eye(sigma_push.shape[-1])
    sigma_push_inv = np.linalg.inv(sigma_push)
    return mu_push, sigma_push, sigma_push_inv




def compute_direct_morphisms(phi, phi_model, generators_q, generators_p, Phi_0, Phi_tilde_0):
    """
    Build rectangular morphisms with gauge transport:
        Φ       = exp(φ̃) · Φ₀ · exp(φ)ᵀ
        Φ̃      = exp(φ) · Φ̃₀ · exp(φ̃)ᵀ
    If Φ₀/Φ̃₀ are missing or shaped wrong, fall back to identities.
    """
    Omega_q = exp_lie_algebra_irrep(phi, generators_q)         # (..., Kq, Kq)
    Omega_p = exp_lie_algebra_irrep(phi_model, generators_p)   # (..., Kp, Kp)
    Kq = Omega_q.shape[-1]
    Kp = Omega_p.shape[-1]

    # Fallback identities when base morphisms are absent/mis-shaped
    if not isinstance(Phi_0, np.ndarray) or getattr(Phi_0, "ndim", 0) < 2 or Phi_0.shape[-2:] != (Kp, Kq):
        Phi_0 = np.eye(Kp, Kq, dtype=Omega_p.dtype)
    if not isinstance(Phi_tilde_0, np.ndarray) or getattr(Phi_tilde_0, "ndim", 0) < 2 or Phi_tilde_0.shape[-2:] != (Kq, Kp):
        Phi_tilde_0 = np.eye(Kq, Kp, dtype=Omega_q.dtype)

    Omega_q_T = np.swapaxes(Omega_q, -1, -2)
    Omega_p_T = np.swapaxes(Omega_p, -1, -2)

    Phi       = Omega_p @ Phi_0       @ Omega_q_T
    Phi_tilde = Omega_q @ Phi_tilde_0 @ Omega_p_T
    return Phi, Phi_tilde

def have_parent_morphisms(P) -> bool:
    """
    True iff base morphisms exist with correct rectangular shapes:
      Phi_0       : (Kp, Kq)
      Phi_tilde_0 : (Kq, Kp)
    and generators are present.
    """
    import numpy as np
    if not hasattr(P, "mu_q_field") or not hasattr(P, "mu_p_field"):
        return False
    Kq = int(getattr(P.mu_q_field, "shape", (0,))[-1])
    Kp = int(getattr(P.mu_p_field, "shape", (0,))[-1])
    if Kq <= 0 or Kp <= 0:
        return False

    ok_gen = hasattr(P, "generators_q") and hasattr(P, "generators_p")

    A = getattr(P, "Phi_0", None)
    B = getattr(P, "Phi_tilde_0", None)
    ok_A = isinstance(A, np.ndarray) and A.ndim == 2 and A.shape == (Kp, Kq)
    ok_B = isinstance(B, np.ndarray) and B.ndim == 2 and B.shape == (Kq, Kp)

    return bool(ok_gen and ok_A and ok_B)


def init_parent_morphisms(P, generators_q, generators_p):
    """
    Ensure a newly spawned parent has base morphisms and computed bundle morphisms.
    - Sets identity Φ₀, Φ̃₀ with correct shapes (Kp×Kq and Kq×Kp).
    - Stores generators on the parent (for later recomputes).
    - Computes bundle_morphism_q_to_p and bundle_morphism_p_to_q once.
    """
    # infer dims from parent's fields
    Kq = int(getattr(P.mu_q_field, "shape", (0,))[-1])
    Kp = int(getattr(P.mu_p_field, "shape", (0,))[-1])
    if Kq <= 0 or Kp <= 0:
        # can't initialize without sizes; leave gracefully
        return
    P.Phi_0       = np.eye(Kp, Kq, dtype=getattr(P.mu_q_field, "dtype", np.float32))
    P.Phi_tilde_0 = np.eye(Kq, Kp, dtype=getattr(P.mu_q_field, "dtype", np.float32))
    P.generators_q = generators_q
    P.generators_p = generators_p

    # make sure phi fields exist
    if not hasattr(P, "phi") or P.phi is None:
        P.phi = np.zeros((Kq,), dtype=P.Phi_tilde_0.dtype)
    if not hasattr(P, "phi_model") or P.phi_model is None:
        P.phi_model = np.zeros((Kp,), dtype=P.Phi_0.dtype)

    # compute initial transported morphisms
    try:
        P.bundle_morphism_q_to_p, P.bundle_morphism_p_to_q = compute_direct_morphisms(
            phi=P.phi, phi_model=P.phi_model,
            generators_q=P.generators_q, generators_p=P.generators_p,
            Phi_0=P.Phi_0, Phi_tilde_0=P.Phi_tilde_0,
        )
    except Exception:
        # leave base identities if transport fails early
        P.bundle_morphism_q_to_p = np.eye(Kp, Kq, dtype=P.Phi_0.dtype)
        P.bundle_morphism_p_to_q = np.eye(Kq, Kp, dtype=P.Phi_tilde_0.dtype)



def safe_batch_apply_morphism_nat(mu, sigma, morphism, eps=1e-8):
    """
    Apply morphism Φ to Gaussian parameters (μ, Σ):
        μ'     = Φ μ
        Σ'     = Φ Σ Φᵀ

    Args:
        mu       : (..., K_in)
        sigma    : (..., K_in, K_in)
        morphism : (..., K_out, K_in)

    Returns:
        mu_out   : (..., K_out)
        sigma_out: (..., K_out, K_out), symmetrized and sanitized
    """
    import numpy as np
    from numerical_utils import sanitize_sigma

    # ── Shape validation ──────────────────────────────
    K_in_mu     = mu.shape[-1]
    K_in_sigma1 = sigma.shape[-2]
    K_in_sigma2 = sigma.shape[-1]
    K_in_phi    = morphism.shape[-1]
    K_out_phi   = morphism.shape[-2]

    if not (K_in_mu == K_in_sigma1 == K_in_sigma2 == K_in_phi):
        raise ValueError(
            f"[safe_batch_apply_morphism_nat] Input dimension mismatch:\n"
            f"  mu.shape[-1]      = {K_in_mu}\n"
            f"  sigma.shape[-2:]  = ({K_in_sigma1}, {K_in_sigma2})\n"
            f"  morphism.shape[-1]= {K_in_phi} (expected K_in)"
        )

    # ── Morphism application ──────────────────────────
    mu_out = np.einsum("...ij,...j->...i", morphism, mu)
    sigma_out = np.einsum("...ik,...kl,...jl->...ij", morphism, sigma, morphism)

    # ── Symmetrize and sanitize ───────────────────────
    sigma_out = 0.5 * (sigma_out + np.swapaxes(sigma_out, -1, -2))
    sigma_out = sanitize_sigma(sigma_out, eps=eps)

    return mu_out, sigma_out






#======================================================================
#
#                    Initialization
#
#======================================================================



def generate_smooth_morphism_fieldID(
    H, W,
    K_src, K_tgt,
    sigma=config.gaussian_blur_range_morphism,
    low_rank=None,
    seed=None,
    normalize=False,
    mask=None,
):
    """
    Generate a morphism field Φ(x) ∈ ℝ^{K_tgt × K_src} that approximates an identity
    map on a shared subspace of dim `shared_rank = min(K_src, K_tgt)`.

    Outside the shared rank, remaining components are set to zero.

    Args:
        H, W         : spatial domain
        K_src, K_tgt : source and target fiber dimensions
        shared_rank  : optional, default = min(K_src, K_tgt)
        smooth_sigma : smoothing for blending (e.g. 1.0)
        seed         : RNG seed

    Returns:
        field : (H, W, K_tgt, K_src) array, smooth identity-like map
    """
    import numpy as np
    from scipy.ndimage import gaussian_filter
    
    shared_rank = None
    rng = np.random.default_rng(seed)
    R = shared_rank if shared_rank is not None else min(K_src, K_tgt)

    field = np.zeros((H, W, K_tgt, K_src), dtype=np.float32)

    for i in range(R):
        coeff = np.ones((H, W), dtype=np.float32)
        coeff = gaussian_filter(coeff, sigma=1.5, mode="wrap")
        field[..., i, i] = coeff

    return field




def generate_smooth_morphism_field(
    H, W,
    K_src, K_tgt,
    sigma=config.gaussian_blur_range_morphism,
    low_rank=None,
    seed=None,
    normalize=False,
    mask=None,
):
    """
    Generate a smooth spatial field of K_tgt × K_src morphisms,
    optionally low-rank and softly masked to identity outside support.
    """
    from scipy.ndimage import gaussian_filter

    eps = 1e-8
    rng = np.random.default_rng(seed)
    rank = low_rank if low_rank is not None else min(K_src, K_tgt)

    field = np.zeros((H, W, K_tgt, K_src), dtype=np.float32)

    for r in range(rank):
        basis = rng.standard_normal((K_tgt, K_src)).astype(np.float32)
        coeff = rng.standard_normal((H, W)).astype(np.float32)
        coeff = gaussian_filter(coeff, sigma=sigma, mode="wrap")
        field += coeff[..., None, None] * basis[None, None, :, :]

    if normalize:
        norm = np.linalg.norm(field, axis=(-2, -1), keepdims=True)
        norm_safe = np.where(norm > eps, norm, eps)
        field = field / norm_safe

    # ─── Soft blend to identity outside mask ───
    if mask is not None:
        soft_mask = gaussian_filter(mask.astype(np.float32), sigma=1.0)
        soft_mask = np.clip(soft_mask, 0.0, 1.0)[..., None, None]

        I = np.eye(K_tgt, K_src, dtype=np.float32)[None, None, :, :]
        field = soft_mask * field + (1.0 - soft_mask) * I

    return field




def clip_operator_norm(field: np.ndarray, max_norm: float = 1.0, eps: float = 1e-8) -> np.ndarray:
    """
    Enforce operator norm ≤ max_norm for each Φ(x) in (H,W,Kp,Kq)
    """
    H, W, Kp, Kq = field.shape
    field_out = np.empty_like(field)
    for i in range(H):
        for j in range(W):
            Phi = field[i, j]
            u, s, vh = np.linalg.svd(Phi, full_matrices=False)
            s_clipped = np.clip(s, 0, max_norm)
            Phi_clipped = (u @ np.diag(s_clipped) @ vh).astype(field.dtype)
            field_out[i, j] = Phi_clipped
    return field_out




def initialize_morphism_pair( 
    domain_size: Tuple[int, int],
    K_q: int,
    K_p: int,
    rng: np.random.Generator,
    morphism_type: str = "identity",
    mask: Optional[np.ndarray] = None,
    config_tag: str = "",
    phi_q_field: Optional[np.ndarray] = None,
    phi_p_field: Optional[np.ndarray] = None,
    G_q: Optional[dict] = None,
    G_p: Optional[dict] = None,
) -> Tuple[np.ndarray, np.ndarray]:
    """
    Initialize bundle morphisms Φ (q→p) and Φ̃ (p→q), optionally with
    full SO(3)-gauge covariance via:
        Φ(x) = exp(φ_p(x)) · Φ₀(x) · exp(−φ_q(x))
    """
    from bundle_morphism_utils import gauge_covariant_transform_phi
    from scipy.ndimage import gaussian_filter

    H, W = domain_size

    if morphism_type == "identity":
        if K_q != K_p:
            raise ValueError(f"Cannot use identity morphism with mismatched K_q={K_q} and K_p={K_p}")
        eye = np.eye(K_q, dtype=np.float32)
        phi_q_to_p = np.broadcast_to(eye, (H, W, K_q, K_q)).copy()
        phi_p_to_q = np.broadcast_to(eye, (H, W, K_q, K_q)).copy()
        if mask is not None:
            phi_q_to_p = np.where(mask[..., None, None], phi_q_to_p, 0.0)
            phi_p_to_q = np.where(mask[..., None, None], phi_p_to_q, 0.0)
        return phi_q_to_p, phi_p_to_q

    if morphism_type == "gauge_covariant":
        assert phi_q_field is not None and phi_p_field is not None, "φ_q and φ_p fields required"
        assert G_q is not None and G_p is not None, "SO(3) generators G_q and G_p required"

        sigma = getattr(config, f"morphism_sigma{config_tag}", 1.5)
        rank  = getattr(config, f"morphism_rank{config_tag}", min(K_q, K_p))
        seed  = rng.integers(0, 1e9)

        # Base morphisms
        Phi_0_q_to_p = generate_smooth_morphism_field(
            H, W, K_src=K_q, K_tgt=K_p,
            sigma=sigma, low_rank=rank,
            normalize=False, mask=mask, seed=seed
        )
        Phi_0_p_to_q = generate_smooth_morphism_field(
            H, W, K_src=K_p, K_tgt=K_q,
            sigma=sigma, low_rank=rank,
            normalize=False, mask=mask, seed=seed + 1
        )

        # Apply gauge covariance
        phi_q_to_p = gauge_covariant_transform_phi(
            phi_p_field, phi_q_field, Phi_0_q_to_p,
            G_q=G_q, G_p=G_p
        )
        phi_p_to_q = gauge_covariant_transform_phi(
            phi_q_field, phi_p_field, Phi_0_p_to_q,
            G_q=G_p, G_p=G_q  # flipped
        )
        print(f"[INIT Φ] Φ_q→p stats: mean = {np.mean(phi_q_to_p):.4g}, std = {np.std(phi_q_to_p):.4g}")
        idx = np.random.randint(0, H * W)
        print("[Φ_q→p sample]", phi_q_to_p.reshape(-1, K_p, K_q)[idx])

        # ─── Soft masking via identity fallback ───
        if mask is not None:
            soft_mask = gaussian_filter(mask.astype(np.float32), sigma=1.0)
            soft_mask = np.clip(soft_mask, 0.0, 1.0)[..., None, None]

            I_qp = np.eye(K_p, K_q, dtype=np.float32)[None, None, :, :]
            I_pq = np.eye(K_q, K_p, dtype=np.float32)[None, None, :, :]

            phi_q_to_p = soft_mask * phi_q_to_p + (1.0 - soft_mask) * I_qp
            phi_p_to_q = soft_mask * phi_p_to_q + (1.0 - soft_mask) * I_pq

        return phi_q_to_p, phi_p_to_q

    # Else: generic smooth/lowrank morphism
    sigma     = getattr(config, f"morphism_sigma{config_tag}", 1.5)
    rank      = getattr(config, f"morphism_rank{config_tag}", min(K_q, K_p))
    normalize = getattr(config, f"morphism_normalize{config_tag}", True)
    seed      = rng.integers(0, 1e9)

    phi_q_to_p = generate_smooth_morphism_field(
        H, W, K_src=K_q, K_tgt=K_p,
        sigma=sigma, low_rank=rank,
        normalize=False, mask=mask, seed=seed
    )
    phi_p_to_q = np.swapaxes(phi_q_to_p, -1, -2)

    if normalize:
        phi_q_to_p = clip_operator_norm(phi_q_to_p, max_norm=1.0)
        phi_p_to_q = clip_operator_norm(phi_p_to_q, max_norm=1.0)

    return phi_q_to_p, phi_p_to_q

# --- add near other generators/morphism helpers ---
import numpy as np
from scipy.ndimage import gaussian_filter

def generate_morphism_pair(
    H, W,
    K_q, K_p,
    rank=None,
    sigma=1.5,
    seed=None,
    mask=None,
    s_floor=0.05,
    s_scale=0.25,
    dtype=np.float32,
):
    """
    Build a *paired* rectangular morphism field (Φ0, Φ̃0) with shared low-rank frames:
        Φ0(x)   = U  S(x) Vᵀ   ∈ ℝ^{K_p × K_q}
        Φ̃0(x)  = V  S(x) Uᵀ   ∈ ℝ^{K_q × K_p}

    - U ∈ ℝ^{K_p×r}, V ∈ ℝ^{K_q×r} are global orthonormal frames (fixed across space).
    - S(x) = diag(s_1(x),...,s_r(x)) are *positive*, *smooth* per-pixel singular values.
    - If `mask` is provided, we softly zero S(x) outside support.

    Returns:
        Phi_0        : (H, W, K_p, K_q)
        Phi_tilde_0  : (H, W, K_q, K_p)
    """
    rng = np.random.default_rng(seed)
    r = rank if rank is not None else min(K_q, K_p)

    # Global orthonormal frames (fixed across space)
    U0, _ = np.linalg.qr(rng.standard_normal((K_p, r)))
    V0, _ = np.linalg.qr(rng.standard_normal((K_q, r)))

    # Smooth positive singular spectra per pixel
    # Start with r random fields, smooth them, then enforce positivity and floor
    S_fields = []
    for _ in range(r):
        f = rng.standard_normal((H, W)).astype(dtype)
        f = gaussian_filter(f, sigma=sigma, mode="wrap")
        f = np.abs(f) * s_scale + s_floor  # positive, bounded away from 0
        if mask is not None:
            f = f * mask  # softly suppress outside support
        S_fields.append(f)
    # Stack to (H, W, r)
    S_stack = np.stack(S_fields, axis=-1)  # (H, W, r)

    # Construct Φ0(x) = U S(x) Vᵀ and Φ̃0(x) = V S(x) Uᵀ
    # Do it via batched einsum: (..., a r) * (..., r r) * (..., r b)
    # Here the middle is diagonal per pixel → expand to diag matrices cheaply
    HWr = (H * W, r)

    # Build diag S(x) explicitly as (H,W,r,r) but efficiently
    S_diag = np.zeros((H, W, r, r), dtype=dtype)
    idx = np.arange(r)
    S_diag[..., idx, idx] = S_stack

    # Φ0: (H,W,K_p,K_q) = U0 (K_p,r) · S(x) (r,r) · V0ᵀ (r,K_q)
    Phi_0 = np.einsum("pr,hwrs,sq->hwpq", U0.astype(dtype), S_diag, V0.T.astype(dtype))

    # Φ̃0: (H,W,K_q,K_p) = V0 (K_q,r) · S(x) (r,r) · U0ᵀ (r,K_p)
    Phi_tilde_0 = np.einsum("qr,hwrs,sp->hwqp", V0.astype(dtype), S_diag, U0.T.astype(dtype))

    return Phi_0, Phi_tilde_0


def gauge_covariant_transform_phi(
    phi_p, phi_q, Phi0,
    G_q, G_p,
    group_name="so3",
    eps=1e-8
):
    """
    Apply gauge-covariant morphism:
        Φ(x) = exp(φ_p(x)) · Φ₀(x) · exp(−φ_q(x))

    Args:
        phi_p    : (H, W, d) Lie algebra field for p-bundle
        phi_q    : (H, W, d) Lie algebra field for q-bundle
        Phi0     : (H, W, K_p, K_q) initial morphism
        G_q, G_p : (3, K, K) generator arrays
        group_name: "so3" or other group string (for antisymmetrization)
        eps      : small value for numerical safety

    Returns:
        Transformed morphism field: (H, W, K_p, K_q)
    """
    from omega import exp_lie_algebra_irrep

    # Compute exp(φ_p) and exp(φ_q)
    exp_phi_p = exp_lie_algebra_irrep(phi_p, G_p, group_name=group_name)         # (H, W, K_p, K_p)
    exp_phi_q = exp_lie_algebra_irrep(phi_q, G_q, group_name=group_name)         # (H, W, K_q, K_q)

    # Inverse = transpose for SO(3)
    exp_neg_phi_q = np.swapaxes(exp_phi_q, -1, -2)                               # (H, W, K_q, K_q)

    # Compose: Φ = exp(φ_p) · Φ₀ · exp(−φ_q)
    return np.einsum("...ik,...kj,...jl->...il", exp_phi_p, Phi0, exp_neg_phi_q)



