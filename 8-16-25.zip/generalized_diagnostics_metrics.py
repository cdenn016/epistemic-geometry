# Standard library
import os
# Third-party libraries
import numpy as np
from omega import (exp_lie_algebra_irrep, batch_apply_omega,
                              compute_field_strength)
from get_generators import get_generators 
from joblib import Parallel, delayed
import config
from pathlib import Path
from scipy.ndimage import laplace
from mask_utils import threshold_mask
from bundle_morphism_utils import safe_batch_apply_morphism_nat
from numerical_utils import sanitize_sigma, safe_inv,safe_logdet

#==================================================================================
#
#                  Fields
#
#==================================================================================






def kl_divergence(mu1, sigma1, mu2, sigma2, mask=None, eps=1e-6):
    """
    KL[𝒩(μ₁, Σ₁) || 𝒩(μ₂, Σ₂)] — batched over N points.

    Args:
        mu1     : (N, K)       — mean of first Gaussian
        sigma1  : (N, K, K)    — cov of first Gaussian
        mu2     : (N, K)       — mean of second Gaussian
        sigma2  : (N, K, K)    — cov of second Gaussian
        mask    : (N,) or (N, 1), optional — multiplies KL values
        eps     : regularization constant for logdet and inverse

    Returns:
        kl_vals : (N,) — KL divergence values
    """
    mu1 = np.asarray(mu1)
    mu2 = np.asarray(mu2)
    sigma1 = np.asarray(sigma1)
    sigma2 = np.asarray(sigma2)

    assert mu1.shape == mu2.shape
    assert sigma1.shape == sigma2.shape
    N, K = mu1.shape

    sigma1 = sanitize_sigma(sigma1, eps=eps)
    sigma2 = sanitize_sigma(sigma2, eps=eps)

    sigma2_inv = safe_inv(sigma2, eps=eps)
    logdet1 = safe_logdet(sigma1, eps=eps)
    logdet2 = safe_logdet(sigma2, eps=eps)

    trace_term = np.einsum("nij,njk->nik", sigma2_inv, sigma1)
    trace_term = np.trace(trace_term, axis1=-2, axis2=-1)  # (N,)

    diff = mu2 - mu1
    mahal = np.einsum("ni,nij,nj->n", diff, sigma2_inv, diff)

    kl_vals = 0.5 * (trace_term + mahal - K + logdet2 - logdet1)

    if mask is not None:
        mask = np.asarray(mask)
        if mask.ndim == 2:
            mask = np.squeeze(mask, axis=-1)
        kl_vals *= mask

    if np.any(np.isnan(kl_vals)) or np.any(np.isinf(kl_vals)):
        raise ValueError("[KL Divergence] NaN or Inf detected in KL output")

    return kl_vals






def compute_alignment_field_general(
    agents, i, field_type="belief",
    eps=config.support_cutoff_eps,
    log_eps=config.log_eps
) -> np.ndarray:
    """
    Compute spatial KL field KL[q_i(c) || Ω_ij · q_j(c)] for agent i.

    Projects neighbor fields into i's gauge frame using Ω = exp(φ_i) · exp(−φ_j),
    applies to either belief (q) or model (p) fields. KL is computed at each spatial
    overlap point with neighbors, and averaged across neighbors.

    Note: This version uses moment (μ, Σ) frame transport — not natural geometry.
    Use for visualization or spatial diagnostics, not variational gradients.

    Returns:
        (H, W) array — per-pixel average KL divergence field
    """
    A = agents[i]
    mask_i = threshold_mask(A.mask, eps)
    if not np.any(mask_i) or not A.neighbors:
        return np.zeros_like(mask_i, dtype=np.float32)

    H, W = A.mask.shape
    kl_accum = np.zeros((H, W), dtype=np.float32)
    n_nb_at = np.zeros((H, W), dtype=np.int32)

    # Select fields and generators
    if field_type == "belief":
        mu_i     = A.mu_q_field
        sigma_i  = A.sigma_q_field
        phi_i    = A.phi
        K        = config.K_q
    elif field_type == "model":
        mu_i     = A.mu_p_field
        sigma_i  = A.sigma_p_field
        phi_i    = A.phi_model
        K        = config.K_p
    else:
        raise ValueError(f"[compute_alignment_field_general] Invalid field_type: '{field_type}'")

    generators = get_generators(config.group_name, K)

    def to_full_safe(sigma):
        # Handles (H, W, K) diagonal stddev → (H, W, K, K) covariance
        return np.einsum("mk,ij->mij", sigma**2, np.eye(K)) if sigma.ndim == 2 else sigma

    for nb in A.neighbors:
        B = agents[nb["id"]]
        mask_j = threshold_mask(B.mask, eps)
        overlap = mask_i & mask_j
        if not np.any(overlap):
            continue

        idx = np.argwhere(overlap)
        i_idx, j_idx = idx[:, 0], idx[:, 1]

        mu_j    = B.mu_q_field if field_type == "belief" else B.mu_p_field
        sigma_j = B.sigma_q_field if field_type == "belief" else B.sigma_p_field
        phi_j   = B.phi if field_type == "belief" else B.phi_model

        mu_i_pts    = mu_i[overlap]
        sigma_i_pts = to_full_safe(sigma_i[overlap])
        mu_j_pts    = mu_j[overlap]
        sigma_j_pts = to_full_safe(sigma_j[overlap])

        # Sanitize both before KL
        sigma_i_pts = sanitize_sigma(sigma_i_pts, eps=log_eps)
        sigma_j_pts = sanitize_sigma(sigma_j_pts, eps=log_eps)

        # Transport using Ω = exp(φ_i) · exp(−φ_j)
        O_i     = exp_lie_algebra_irrep(phi_i[overlap], generators)
        O_j_inv = exp_lie_algebra_irrep(-phi_j[overlap], generators)
        Omega   = np.einsum("mab,mbc->mac", O_i, O_j_inv)

        if not np.all(np.isfinite(Omega)):
            print(f"[WARNING] NaN or Inf in Ω for agent {i} ↔ neighbor {nb['id']}")

        mu_j_t = np.einsum("mab,mb->ma", Omega, mu_j_pts)
        sigma_j_t = np.einsum("mab,mbc,mdc->mad", Omega, sigma_j_pts, Omega)

        sigma_j_t = sanitize_sigma(sigma_j_t, eps=log_eps)

        kl_vals = kl_divergence(mu_i_pts, sigma_i_pts, mu_j_t, sigma_j_t, eps=log_eps)
        num_bad = np.sum(~np.isfinite(kl_vals))
        if num_bad > 0:
            print(f"[KL Field] {num_bad} invalid KLs for agent {i} ↔ neighbor {nb['id']}")
        kl_vals = np.where(np.isfinite(kl_vals), kl_vals, 0.0)

        np.add.at(kl_accum, (i_idx, j_idx), kl_vals)
        np.add.at(n_nb_at,  (i_idx, j_idx), 1)

    out = np.zeros_like(kl_accum, dtype=np.float32)
    valid = n_nb_at > 0
    out[valid] = kl_accum[valid] / n_nb_at[valid]
    return out * mask_i



def compute_pairwise_kl_belief(agents, generators_q, params, return_pointwise=False):
    """
    Compute KL[q_i || Ω_ij · q_j] for all (i, j) pairs.

    Args:
        agents           : list of Agent objects
        generators_q     : (d, K_q, K_q) Lie algebra basis for beliefs
        params           : dict with 'log_eps' and 'overlap_eps'
        return_pointwise : if True, returns full per-point KL maps

    Returns:
        kl_matrix        : (N, N)
        pointwise        : (optional) {(i,j): KL_field}
    """
    from omega import batch_apply_omega, compute_inter_omega_fieldwise
    from numerical_utils import sanitize_sigma

    log_eps = params.get("log_eps", 1e-8)
    eps     = params.get("overlap_eps", 1e-6)
    N       = len(agents)
    kl_matrix = np.full((N, N), np.nan)
    pointwise = {} if return_pointwise else None

    for i, A in enumerate(agents):
        mask_i = A.mask > eps
        H, W = A.mask.shape
        for j, B in enumerate(agents):
            if i == j:
                kl_matrix[i, j] = 0.0
                continue

            mask_j = B.mask > eps
            overlap = mask_i & mask_j
            if not np.any(overlap):
                continue

            mu_i     = A.mu_q_field[overlap]
            sigma_i  = A.sigma_q_field[overlap]
            mu_j     = B.mu_q_field[overlap]
            sigma_j  = B.sigma_q_field[overlap]
            phi_i    = A.phi[overlap]
            phi_j    = B.phi[overlap]

            Omega_ij = compute_inter_omega_fieldwise(phi_i, phi_j, generators_q, config.group_name)

            if not np.all(np.isfinite(Omega_ij)):
                print(f"[WARN] Non-finite Ω_{i}{j} — check φ fields or generator setup")

            mu_j_t, sigma_j_t = batch_apply_omega(mu_j, sigma_j, Omega_ij)

            sigma_i    = sanitize_sigma(sigma_i, eps=log_eps)
            sigma_j_t  = sanitize_sigma(sigma_j_t, eps=log_eps)

            kl_vals = kl_divergence(mu_i, sigma_i, mu_j_t, sigma_j_t, eps=log_eps)

            n_bad = np.sum(~np.isfinite(kl_vals))
            if n_bad > 0:
                print(f"[KL] {n_bad} non-finite values in KL({i} || {j})")
            kl_vals = np.where(np.isfinite(kl_vals), kl_vals, 0.0)

            kl_matrix[i, j] = float(np.mean(kl_vals))

            if return_pointwise:
                pw_field = np.zeros((H, W), dtype=np.float32)
                pw_field[overlap] = kl_vals
                pointwise[(i, j)] = pw_field

    return (kl_matrix, pointwise) if return_pointwise else kl_matrix


def compute_pairwise_kl_model(agents, generators_p, params, return_pointwise=False):
    """
    Compute KL[p_i || Ω̃_ij · p_j] for all (i, j) pairs.

    Args:
        agents           : list of Agent objects
        generators_p     : (d, K_p, K_p) Lie algebra basis for models
        params           : dict with 'log_eps' and 'overlap_eps'
        return_pointwise : if True, returns full per-point KL maps

    Returns:
        kl_matrix        : (N, N)
        pointwise        : (optional) {(i,j): KL_field}
    """
    from omega import batch_apply_omega, compute_inter_omega_fieldwise
    from numerical_utils import sanitize_sigma

    log_eps = params.get("log_eps", 1e-8)
    eps     = params.get("overlap_eps", 1e-6)
    group_name = config.group_name
    N = len(agents)

    kl_matrix = np.full((N, N), np.nan)
    pointwise = {} if return_pointwise else None

    for i, A in enumerate(agents):
        mask_i = A.mask > eps
        H, W = A.mask.shape
        for j, B in enumerate(agents):
            if i == j:
                kl_matrix[i, j] = 0.0
                continue

            mask_j = B.mask > eps
            overlap = mask_i & mask_j
            if not np.any(overlap):
                continue

            mu_i     = A.mu_p_field[overlap]
            sigma_i  = A.sigma_p_field[overlap]
            mu_j     = B.mu_p_field[overlap]
            sigma_j  = B.sigma_p_field[overlap]
            phi_i    = A.phi_model[overlap]
            phi_j    = B.phi_model[overlap]

            Omega_ij = compute_inter_omega_fieldwise(phi_i, phi_j, generators_p)

            if not np.all(np.isfinite(Omega_ij)):
                print(f"[WARN] Non-finite Ω̃_{i}{j} — check φ_model fields")

            mu_j_t, sigma_j_t = batch_apply_omega(mu_j, sigma_j, Omega_ij)

            sigma_i    = sanitize_sigma(sigma_i, eps=log_eps)
            sigma_j_t  = sanitize_sigma(sigma_j_t, eps=log_eps)

            kl_vals = kl_divergence(mu_i, sigma_i, mu_j_t, sigma_j_t, eps=log_eps)

            n_bad = np.sum(~np.isfinite(kl_vals))
            if n_bad > 0:
                print(f"[KL:model] {n_bad} invalid values in KL({i} || {j})")

            kl_vals = np.where(np.isfinite(kl_vals), kl_vals, 0.0)
            kl_matrix[i, j] = float(np.mean(kl_vals))

            if return_pointwise:
                pw_field = np.zeros((H, W), dtype=np.float32)
                pw_field[overlap] = kl_vals
                pointwise[(i, j)] = pw_field

    return (kl_matrix, pointwise) if return_pointwise else kl_matrix


def compute_entropy_field(sigma_field, mask, log_eps=1e-8):
    """
    Compute per-cell entropy H[q(c)] for Gaussian fields over space.

    Args:
        sigma_field : (H, W, K) or (H, W, K, K) — stddev or full covariance
        mask        : (H, W) bool — support region
        log_eps     : stabilizer for log and inverse

    Returns:
        H_field     : (H, W) entropy values, 0 outside mask
    """
    H, W = mask.shape
    if sigma_field.ndim == 3:
        # Diagonal Σ (σ²)
        var = np.clip(sigma_field**2, log_eps, None)     # (H,W,K)
        log_det = np.sum(np.log(var), axis=-1)           # (H,W)
        K = sigma_field.shape[-1]
    else:
        # Full Σ
        K = sigma_field.shape[-1]
        log_det = np.zeros((H, W), dtype=float)
        for i in range(H):
            for j in range(W):
                if not mask[i, j]:
                    continue
                Σ = sigma_field[i, j] + log_eps * np.eye(K)
                log_det[i, j] = safe_logdet(Σ)

    H_field = 0.5 * (K * np.log(2 * np.pi * np.e) + log_det)
    H_field[~mask] = 0.0
    return H_field



def _auto_support(mask: np.ndarray, morphism: np.ndarray, thresh: float = 0.5) -> np.ndarray:
    """
    Build an automatic interior support:
      - distance gate: keep points >= 5% of agent radius from boundary of (mask>thresh)
      - morphism gate: keep points with ‖Φ̃‖_F >= 5th percentile on support
    """
    H, W = mask.shape
    m = (mask > thresh)

    if not m.any():
        return np.zeros((H, W), dtype=bool)

    # --- distance-from-boundary (scales with agent size) ---
    try:
        from scipy.ndimage import distance_transform_edt
        dist = distance_transform_edt(m)
    except Exception:
        # NumPy fallback: very small fixed erosion (>=1 px) to avoid ring
        dist = m.astype(np.int32)
        from numpy.lib.stride_tricks import sliding_window_view as swv
        pad = np.pad(dist, 1, mode="edge")
        win = swv(pad, (3, 3))
        eroded = (win.min(axis=(-2, -1)) == 1)
        dist = eroded.astype(np.int32)

    maxd = dist[m].max() if dist[m].size else 0
    # keep interior ≥ 5% of radius; at least 1 pixel if possible
    d_cut = max(1, int(round(0.05 * maxd))) if maxd > 0 else 0
    core = dist >= d_cut

    # --- morphism strength gate (robust to scale) ---
    # morphism: (H,W,Kq,Kp) for Φ̃ (p→q)
    phi_norm = np.linalg.norm(morphism.reshape(H, W, -1), axis=-1)  # Frobenius per pixel
    norms_on_support = phi_norm[m]
    if norms_on_support.size:
        n_cut = np.percentile(norms_on_support, 5.0)  # 5th percentile
    else:
        n_cut = 0.0
    strong = phi_norm >= n_cut

    return core & strong & m


def kl_divergence_field_auto(mu1, S1, mu2, S2, mask, morphism, eps=1e-6):
    """
    D_KL(N(mu1,S1) || N(mu2,S2)) on an automatically chosen interior support
    that scales with agent radius and ignores vanishing morphism regions.
    """
    support = _auto_support(mask, morphism, thresh=0.5)
    if not support.any():
        return np.zeros(mask.shape, dtype=mu1.dtype)

    S1 = sanitize_sigma(S1, eps=eps)
    S2 = sanitize_sigma(S2, eps=eps)

    vals = kl_divergence(mu1[support], S1[support], mu2[support], S2[support], eps=eps)
    out = np.zeros(mask.shape, dtype=vals.dtype)
    out[support] = vals
    return out


def compute_self_energy(agent, eps, cfg):
    """
    α · KL(q_i || Φ̃ · p_i) evaluated on automatic interior support
    (radius-scaled + morphism-strength gated). No tuning needed.
    """
    Phi_tilde = agent.bundle_morphism_p_to_q  # Φ̃: p→q
    mu_pq, S_pq = safe_batch_apply_morphism_nat(
        agent.mu_p_field, agent.sigma_p_field, Phi_tilde, eps=eps
    )

    field = kl_divergence_field_auto(
        mu1    = agent.mu_q_field,
        S1     = agent.sigma_q_field,
        mu2    = mu_pq,
        S2     = S_pq,
        mask   = agent.mask,
        morphism = Phi_tilde,
        eps    = eps,
    )
    return cfg["alpha"] * field




#====================================================================
#
#                 Energy Fields
#
#====================================================================




def compute_feedback_energy(agent, eps, cfg):
    """
    λ · KL(p_i || Φ · q_i) on the same automatic interior support
    (radius-scaled + morphism-strength gated), but using Φ: q→p.
    """
    Phi = agent.bundle_morphism_q_to_p  # Φ: q→p

    # pushforward q through Φ into the model fiber
    mu_qp, S_qp = safe_batch_apply_morphism_nat(
        agent.mu_q_field, agent.sigma_q_field, Phi, eps=eps
    )

    field = kl_divergence_field_auto(
        mu1      = agent.mu_p_field,   # first arg = p (as source in KL)
        S1       = agent.sigma_p_field,
        mu2      = mu_qp,              # second arg = Φ·q
        S2       = S_qp,
        mask     = agent.mask,
        morphism = Phi,                # gate by Φ, not Φ̃
        eps      = eps,
    )
    return cfg["feedback_weight"] * field



def compute_curvature_energy_field(phi_field, mask, weight, lie_gens, support_eps=1e-4, debug=False):
    """
    Compute curvature energy: weight × ∑_x Tr[F_{μν}(x)^2] over valid mask.

    Args:
        phi_field   : (H, W, d)     — φ or φ_model field in Lie algebra coords
        mask        : (H, W)        — agent support mask
        weight      : float         — energy weight coefficient
        lie_gens    : (d, K, K)     — Lie algebra generators
        support_eps : float         — minimum support threshold
        debug       : bool          — optional print/debug info

    Returns:
        energy      : float         — weighted curvature energy
        raw_total   : float         — ∑ Tr[F²] over support (unweighted)
    """
    F_dict = compute_field_strength(phi_field, lie_gens)  # dict of F_xy, F_yz, etc.
    support = mask > support_eps

    total = 0.0
    for key, val in F_dict.items():
        if val.ndim == 2:
            total += val**2
        elif val.ndim == 3:
            total += np.sum(val**2, axis=-1)  # vector norm²
        elif val.ndim == 4:
            total += np.sum(val**2, axis=(-2, -1))  # Frobenius norm²
        else:
            raise ValueError(f"[ERROR] Unexpected F_{key} shape: {val.shape}")

    raw_total = float(np.sum(total[support]))
    if debug:
        print(f"[φ_curv] Raw: {raw_total:.4f} | Weighted: {weight * raw_total:.4f}")

    return weight * raw_total, raw_total



def laplacian_field(field):
    """
    Computes componentwise Laplacian of a field over its last axis.

    Parameters:
        field: ndarray (..., K)

    Returns:
        Laplacian of shape (..., K)
    """
    if field.ndim < 2:
        raise ValueError("laplacian_field expects at least 2D array (..., K)")
    return np.stack([laplace(field[..., i]) for i in range(field.shape[-1])], axis=-1)



def compute_laplacian_field_energy(phi):
    """
    Return the Laplacian energy density ‖Δφ(x)‖² at each point.

    Args:
        phi : (H, W, d) — Lie algebra field

    Returns:
        (H, W) — spatial energy density field
    """
    lap = laplacian_field(phi)  # (H, W, d)
    return np.sum(lap**2, axis=-1)  # (H, W)

def compute_mass_field_energy(phi):
    """
    Return the mass energy density ‖φ(x)‖² at each point.

    Args:
        phi : (H, W, d)

    Returns:
        (H, W) — spatial energy density field
    """
    return np.sum(phi**2, axis=-1)

def compute_phi_coupling_field_energy(phi_q, phi_p, morphism_q_to_p):
    """
    Return pointwise coupling energy ‖Φ φ_q Φ⁻¹ − φ_p‖² at each point.

    Args:
        phi_q           : (H, W, d_q)
        phi_p           : (H, W, d_p)
        morphism_q_to_p : (H, W, K_p, K_q)

    Returns:
        (H, W) — spatial coupling energy field
    """
    from bundle_morphism_utils import gauge_covariant_transform_phi

    phi_q_trans = gauge_covariant_transform_phi(phi_q, morphism_q_to_p)
    assert phi_q_trans.shape == phi_p.shape, "Shape mismatch after morphism transform"

    return np.sum((phi_q_trans - phi_p)**2, axis=-1)




#===================================================================
#
#            Scalar Energies
#
#===================================================================

def compute_self_energy_scalar(agent, log_eps, cfg):
    """
    Compute total weighted KL(q_i || Φ̃ · p_i), scalar output for energy.
    """
    kl_field = compute_self_energy(agent, log_eps, cfg)
    agent.e_self_field = kl_field  # Optional: store for diagnostics

    # Mask invalid or zero-support regions
    valid_mask = (agent.mask > cfg.get("support_cutoff_eps", 1e-3)) & np.isfinite(kl_field)
    total_energy = float(np.sum(kl_field[valid_mask]))

    return total_energy

def compute_feedback_energy_scalar(agent, log_eps, cfg):
    """
    Compute total weighted KL(p_i || Φ · q_i) — returns scalar feedback energy.
    """
    kl_field = compute_feedback_energy(agent, log_eps, cfg)
    agent.e_feedback_field = kl_field  # Optional caching

    valid_mask = (agent.mask > cfg.get("support_cutoff_eps", 1e-3)) & np.isfinite(kl_field)
    total_energy = float(np.sum(kl_field[valid_mask]))

    return total_energy

def compute_alignment_energy_general(
    i, agent_i, field_list, mask_list,
    weight,
    log_eps=config.log_eps,
    field_type="belief"
) -> float:
    """
    Compute ∑_j weight * D_KL(field_i || Ω_ij · field_j), using cached Ω from preprocess.

    Args:
        i              : index of agent_i
        agent_i        : agent_i object
        field_list     : list of (mu, sigma) tuples for each agent
        mask_list      : list of masks for each agent
        weight         : scalar weight coefficient
        log_eps        : stabilizer for log det
        field_type     : "belief" or "model" (for debugging only)

    Returns:
        total_energy   : ∑_j weight · D_KL(μ_i, Σ_i || Ω_ij·(μ_j, Σ_j))
    """
    μ_i, Σ_i = field_list[i]
    mask_i = mask_list[i]
    support_i = mask_i > config.support_cutoff_eps

    total_energy = 0.0
    for nb in agent_i.neighbors:
        j = nb["id"]
        μ_j, Σ_j = field_list[j]
        mask_j = mask_list[j]
        support_j = mask_j > config.support_cutoff_eps

        overlap = support_i & support_j
        if not np.any(overlap):
            continue

        # ─── Pull from Ω cache ───
        if field_type == "belief":
            Ω_ij = agent_i.Omega_cache.get(j)
        elif field_type == "model":
            Ω_ij = agent_i.Omega_tilde_cache.get(j)
        else:
            raise ValueError(f"Unknown field_type: {field_type}")

        if Ω_ij is None:
            continue  # skip if missing

        Ω_ij = Ω_ij[overlap]
        μ_j_t, Σ_j_t = batch_apply_omega(μ_j[overlap], Σ_j[overlap], Ω_ij)

        μ_i_pts = μ_i[overlap]
        Σ_i_pts = Σ_i[overlap]

        kl_vals = kl_divergence(μ_i_pts, Σ_i_pts, μ_j_t, Σ_j_t, eps=log_eps)
        kl_vals = np.where(np.isfinite(kl_vals), kl_vals, 0.0)

        total_energy += weight * float(np.sum(kl_vals))

    return total_energy



def entropy_total(sigma_field, mask, log_eps=1e-8):
    """
    Total entropy ∑ H[q(c)] over the masked domain.
    """
    H = compute_entropy_field(sigma_field, mask, log_eps)
    return float(np.nansum(H))



def compute_laplacian_energy(phi, mask, weight):
    """
    Compute Laplacian regularization energy:
        E = weight * ∫_mask ‖Δφ‖²

    Args:
        phi   : (H, W, d) Lie algebra field
        mask  : (H, W) bool array
        weight: float

    Returns:
        float — scalar energy term
    """
    lap = laplacian_field(phi)  # (H, W, d)
    norms_sq = np.sum(lap**2, axis=-1)  # (H, W)
    return float(weight * np.sum(norms_sq[mask > 0]))


def compute_mass_energy(phi, mask, weight):
    """
    Compute mass regularization energy:
        E = weight * ∫_mask ‖φ‖²

    Args:
        phi   : (H, W, d) Lie algebra field
        mask  : (H, W) bool array
        weight: float

    Returns:
        float — scalar energy term
    """
    norms_sq = np.sum(phi**2, axis=-1)
    return float(weight * np.sum(norms_sq[mask > 0]))


def compute_phi_coupling_energy(
    phi_q, phi_p, morphism_q_to_p, mask, weight
):
    """
    Compute coupling energy ∫ ‖dΦ · φ_q · dΦ⁻¹ − φ_p‖² over the mask.

    Args:
        phi_q         : (H, W, d_q)
        phi_p         : (H, W, d_p)
        morphism_q_to_p : (H, W, K_p, K_q) — bundle morphism Φ: B_q → B_p
        mask          : (H, W)
        weight        : float

    Returns:
        float — scalar coupling energy
    """
    from bundle_morphism_utils import gauge_covariant_transform_phi

    # Transform phi_q into model frame
    phi_q_trans = gauge_covariant_transform_phi(phi_q, morphism_q_to_p)

    # Match shape
    assert phi_q_trans.shape == phi_p.shape, "Shape mismatch after morphism transform"

    diff_sq = np.sum((phi_q_trans - phi_p)**2, axis=-1)
    return float(weight * np.sum(diff_sq[mask > 0]))


def compute_curvature_energy(phi_field, mask, weight, lie_gens, support_eps=1e-4, debug=False):
    """
    Compute curvature energy: weight × ∑_x Tr[F_{μν}(x)^2] over valid mask.

    Args:
        phi_field   : (H, W, d)     — φ or φ_model field in Lie algebra coords
        mask        : (H, W)        — agent support mask
        weight      : float         — energy weight coefficient
        lie_gens    : (d, K, K)     — Lie algebra generators
        support_eps : float         — minimum support threshold
        debug       : bool          — optional print/debug info

    Returns:
        energy      : float         — weighted curvature energy
        raw_total   : float         — ∑ Tr[F²] over support (unweighted)
    """
    F_dict = compute_field_strength(phi_field, lie_gens)  # dict of F_xy, F_yz, etc.
    support = mask > support_eps

    total = 0.0
    for key, val in F_dict.items():
        if val.ndim == 2:
            total += val**2
        elif val.ndim == 3:
            total += np.sum(val**2, axis=-1)  # vector norm²
        elif val.ndim == 4:
            total += np.sum(val**2, axis=(-2, -1))  # Frobenius norm²
        else:
            raise ValueError(f"[ERROR] Unexpected F_{key} shape: {val.shape}")

    raw_total = float(np.sum(total[support]))
    if debug:
        print(f"[φ_curv] Raw: {raw_total:.4f} | Weighted: {weight * raw_total:.4f}")

    return weight * raw_total, raw_total


#==========================================================================
#
#               Logging
#
#===========================================================================
def zero_agent_metrics() -> dict:
    return {
        # energies
        "e_self": 0.0, "e_feedback": 0.0,
        "e_align": 0.0, "e_mod_align": 0.0,
        "e_curv": 0.0, "e_curv_mod": 0.0,
        "e_mass": 0.0, "e_mass_mod": 0.0,
        # norms
        "phi_norm": 0.0, "phi_model_norm": 0.0,
        # support/overlap
        "support": 0, "overlap_deg": 0,
        # conditioning (optional)
        "min_eig_q": np.nan, "max_eig_q": np.nan, "cond_q": np.nan, "clipped_q": 0,
        "min_eig_p": np.nan, "max_eig_p": np.nan, "cond_p": np.nan, "clipped_p": 0,
        # curvature summaries (optional)
        "F_norm_q_sum": 0.0, "F_norm_p_sum": 0.0,
        # grads/steps (optional; fill if you expose them)
        "grad_phi_norm": np.nan, "grad_phi_model_norm": np.nan,
        "grad_eta1_norm": np.nan, "grad_eta2_norm": np.nan,
        "clips_applied": 0, "dexpinv_calls": 0,
    }




def compute_all_agent_metrics(i, A, Q_list, P_list, Mask_list, cfg, generators, log_eps):
    logcfg = cfg.get("logging", {})
    gen_q, gen_p = generators
    mask = Mask_list[i]

    mu_q, sigma_q = Q_list[i]
    mu_p, sigma_p = P_list[i]

    stats = zero_agent_metrics()
    stats["support"] = support_size(mask)

    # Energies (guarded)
    if cfg.get("alpha", 0) > 0:
        stats["e_self"]     = compute_self_energy_scalar(A, log_eps, cfg)
        stats["e_feedback"] = compute_feedback_energy_scalar(A, log_eps, cfg)

    if logcfg.get("compute_alignment", True):
        if cfg.get("beta", 0) > 0:
            stats["e_align"] = compute_alignment_energy_general(
                i=i, agent_i=A, field_list=Q_list, mask_list=Mask_list,
                weight=cfg["beta"], log_eps=log_eps, field_type="belief")
        if cfg.get("beta_model", 0) > 0:
            stats["e_mod_align"] = compute_alignment_energy_general(
                i=i, agent_i=A, field_list=P_list, mask_list=Mask_list,
                weight=cfg["beta_model"], log_eps=log_eps, field_type="model")

    # Mass terms
    if cfg.get("belief_mass", 0) > 0:
        stats["e_mass"] = cfg["belief_mass"] * safe_sum(np.sum(A.phi[mask]**2, axis=-1))
    if cfg.get("model_mass", 0) > 0:
        stats["e_mass_mod"] = cfg["model_mass"] * safe_sum(np.sum(A.phi_model[mask]**2, axis=-1))

    # Curvature energies (only if weight > 0) and optional summaries (even if weight==0)
    if cfg.get("curvature_weight", 0) > 0:
        stats["e_curv"], _ = compute_curvature_energy(A.phi, mask, cfg["curvature_weight"], gen_q)
    if cfg.get("model_curvature_weight", 0) > 0:
        stats["e_curv_mod"], _ = compute_curvature_energy(A.phi_model, mask, cfg["model_curvature_weight"], gen_p)

    if logcfg.get("compute_curvature", True):
        Fq = compute_field_strength(A.phi, generators=gen_q, dx=cfg.get("dx",1.0))["xy"]   # (H,W,Kq,Kq)
        Fp = compute_field_strength(A.phi_model, generators=gen_p, dx=cfg.get("dx",1.0))["xy"]
        stats["F_norm_q_sum"] = safe_sum(np.linalg.norm(Fq, axis=(-2,-1)), where=mask)
        stats["F_norm_p_sum"] = safe_sum(np.linalg.norm(Fp, axis=(-2,-1)), where=mask)

    # Norms of φ fields
    stats["phi_norm"]       = support_norm(A.phi, mask)
    stats["phi_model_norm"] = support_norm(A.phi_model, mask)

    # Conditioning (optional)
    if logcfg.get("log_conditioning", True):
        qstats = eig_stats(sigma_q, mask, eps=cfg.get("eps", 1e-6))
        pstats = eig_stats(sigma_p, mask, eps=cfg.get("eps", 1e-6))
        stats.update({
            "min_eig_q": qstats["min_eig"], "max_eig_q": qstats["max_eig"], "cond_q": qstats["cond_mean"], "clipped_q": qstats["clipped"],
            "min_eig_p": pstats["min_eig"], "max_eig_p": pstats["max_eig"], "cond_p": pstats["cond_mean"], "clipped_p": pstats["clipped"],
        })

    # Overlap degree (optional; cheap)
    if logcfg.get("log_overlap_stats", True):
        stats["overlap_deg"] = len(getattr(A, "neighbors", []))

    # Gradient stats (populate if you store them)
    if logcfg.get("log_gradient_stats", True):
        if hasattr(A, "grad_phi"):        stats["grad_phi_norm"]        = support_norm(A.grad_phi, mask)
        if hasattr(A, "grad_phi_model"):  stats["grad_phi_model_norm"]  = support_norm(A.grad_phi_model, mask)
        if hasattr(A, "grad_eta1"):       stats["grad_eta1_norm"]       = support_norm(A.grad_eta1, mask)
        if hasattr(A, "grad_eta2"):       stats["grad_eta2_norm"]       = np.linalg.norm(A.grad_eta2[mask], axis=(-2,-1)).sum()
        if hasattr(A, "debug_counters"):
            stats["clips_applied"] = int(A.debug_counters.get("clips", 0))
            stats["dexpinv_calls"] = int(A.debug_counters.get("dexpinv", 0))

    return stats


def compute_agent_metrics(
    i: int,
    agent,
    Q_list, P_list, Mask_list,
    cfg, gens, log_eps
) -> tuple[int, dict]:
    """
    Compute all variational energy terms and norms for a single agent.

    Returns:
        (i, stats) where stats is a dict of per-agent scalar metrics.
    """
    mask = Mask_list[i]
    if not np.any(mask):
        return i, zero_agent_metrics()

    stats = compute_all_agent_metrics(
        i, agent, Q_list, P_list, Mask_list,
        cfg, gens, log_eps
    )
    return i, stats

import time

def log_agent_metrics(agent, step: int, stats: dict, normalize=True):
    S = stats.get("support", 0)
    S = float(S if (normalize and S > 0) else 1.0)
    log_dict = {
        "kl_self":           stats["e_self"]      / S,
        "kl_feedback":       stats["e_feedback"]  / S,
        "kl_align":          stats["e_align"]     / S,
        "kl_mod_align":      stats["e_mod_align"] / S,
        "curv_energy":       stats["e_curv"]      / S,
        "curv_model_energy": stats["e_curv_mod"]  / S,
        "mass_energy":       stats["e_mass"]      / S,
        "mass_model_energy": stats["e_mass_mod"]  / S,
        "phi_norm":          stats["phi_norm"],
        "phi_model_norm":    stats["phi_model_norm"],
        # extras
        "support":           stats["support"],
        "overlap_deg":       stats["overlap_deg"],
        "F_norm_q_sum":      stats["F_norm_q_sum"] / S,
        "F_norm_p_sum":      stats["F_norm_p_sum"] / S,
        "min_eig_q":         stats["min_eig_q"],
        "max_eig_q":         stats["max_eig_q"],
        "cond_q":            stats["cond_q"],
        "clipped_q":         stats["clipped_q"],
        "min_eig_p":         stats["min_eig_p"],
        "max_eig_p":         stats["max_eig_p"],
        "cond_p":            stats["cond_p"],
        "clipped_p":         stats["clipped_p"],
        "grad_phi_norm":     stats["grad_phi_norm"],
        "grad_phi_model_norm": stats["grad_phi_model_norm"],
        "grad_eta1_norm":    stats["grad_eta1_norm"],
        "grad_eta2_norm":    stats["grad_eta2_norm"],
        "clips_applied":     stats["clips_applied"],
        "dexpinv_calls":     stats["dexpinv_calls"],
        "schema":            (config.logging.get("schema_version", "v3") if hasattr(config, "logging") else "v3")
    }
    agent.log_metrics(step, log_dict)

def accumulate_and_log_metrics(results, agents, step: int, Q_list, Mask_list, cfg) -> dict:
    logcfg = cfg.get("logging", {})
    t0 = time.time()

    energy_keys = ["e_self","e_feedback","e_align","e_mod_align","e_curv","e_curv_mod","e_mass","e_mass_mod"]
    accum = {k: 0.0 for k in energy_keys}
    total_support = 0

    for i, stats in results:
        total_support += stats.get("support", 0)
        for k in energy_keys:
            accum[k] += stats[k]
        log_agent_metrics(agents[i], step, stats, normalize=logcfg.get("normalize_by_support", True))

    S = float(total_support if total_support > 0 else 1.0)
    metrics = {k: accum[k] / S for k in energy_keys}
    metrics["total_energy"] = sum(metrics[k] for k in energy_keys)
    metrics["support_total"] = total_support
    metrics["step"] = step
    metrics["schema"] = logcfg.get("schema_version", "v3")
    metrics["compute_ms"] = int((time.time() - t0) * 1000)

    return metrics

def log_all_metrics(
    agents, step: int, params=None,
    q_field: str = "q", p_field: str = "p",
    phi_belief_field: str = "phi", phi_model_field: str = "phi_model",
    mask_field: str = "mask", n_jobs: int = -1
) -> dict:
    cfg = config if params is None else {**vars(config), **params}
    logcfg = cfg.get("logging", {})
    log_eps = cfg.get("log_eps", 1e-10)

    K_q, K_p = cfg.get("K_q", 5), cfg.get("K_p", 5)
    name = cfg.get("group_name", "so3")
    gen_q = get_generators(name, K_q)
    gen_p = get_generators(name, K_p)
    gens  = (gen_q, gen_p)

    # Precompute fields once
    Q_list    = [(A.mu_q_field, A.sigma_q_field) for A in agents]
    P_list    = [(A.mu_p_field, A.sigma_p_field) for A in agents]
    Mask_list = [np.asarray(getattr(A, mask_field), dtype=bool) for A in agents]

    # Cheap optional global overlap matrix (debug)
    if logcfg.get("compute_pairwise_overlap", False):
        N = len(agents)
        overlaps = np.zeros((N,N), dtype=np.int32)
        masks = [m.astype(np.uint8) for m in Mask_list]
        for i in range(N):
            mi = masks[i]
            for j in range(i+1, N):
                cnt = int(np.sum(mi & masks[j]))
                overlaps[i,j] = overlaps[j,i] = cnt
        # attach to config-wide logger if you have one
        # e.g., save to disk as npz/json here

    # Parallel per-agent stats
    results = Parallel(n_jobs=n_jobs, backend="threading", batch_size=1)(
        delayed(compute_agent_metrics)(
            i, agents[i], Q_list, P_list, Mask_list, cfg, gens, log_eps
        ) for i in range(len(agents))
    )

    metrics = accumulate_and_log_metrics(results, agents, step, Q_list, Mask_list, cfg)

    if logcfg.get("print_total_energy", True):
        print(f"[STEP {step:04d}] Total Energy = {metrics['total_energy']:.6f}")

    return metrics





def full_field_logger(agents, step: int, outdir: str, params=None):
    """
    Toggleable, schema-tagged field dump:
      - Always (cheap): mu_q, sigma_q, phi, mu_p, sigma_p, phi_model, masks, Φ, Φ̃
      - Optional: belief/model alignment fields (compute_alignment)
      - Optional: curvature tensors + ||F|| maps (compute_curvature)

    Respects:
      params["logging"] or config.logging:
        - enable_fields (handled by caller)
        - compute_alignment (bool)
        - compute_curvature (bool)
        - schema_version (str)
    Uses generators from params or agent cache to avoid recompute.
    """
    import os
    from pathlib import Path
    import numpy as np

    # --- resolve logging toggles & schema ---
    cfg_dict = vars(config)
    logcfg = dict(
        compute_alignment=True,
        compute_curvature=True,
        schema_version="v3",
    )
    # prefer params.logging, then config.logging
    if params and isinstance(params, dict):
        logcfg.update(params.get("logging", {}) or {})
    if hasattr(config, "logging"):
        # config.logging fills only missing keys
        for k, v in getattr(config, "logging", {}).items():
            logcfg.setdefault(k, v)

    schema = logcfg.get("schema_version", "v3")
    do_align = bool(logcfg.get("compute_alignment", True))
    do_curv  = bool(logcfg.get("compute_curvature", True))

    # --- get generators without recomputing ---
    Gq = None
    Gp = None
    if params and isinstance(params, dict):
        Gq = params.get("generators_q")
        Gp = params.get("generators_p")
    if Gq is None:  # try per-agent cache
        Gq = getattr(agents[0], "generators_q", None)
    if Gp is None:
        Gp = getattr(agents[0], "generators_p", None)
    # final fallback: compute once (unlikely if caller set them)
    if Gq is None:
        Gq, _ = get_generators(config.group_name, config.K_q, return_meta=True)
    if Gp is None:
        Gp, _ = get_generators(config.group_name, config.K_p, return_meta=True)

    dx = cfg_dict.get("dx", 1.0)

    N = len(agents)
    H, W = agents[0].mu_q_field.shape[:2]
    K_q  = cfg_dict["K_q"]
    K_p  = cfg_dict["K_p"]

    # --- allocate ---
    mu_q     = np.zeros((N, H, W, K_q), dtype=np.float32)
    sigma_q  = np.zeros((N, H, W, K_q, K_q), dtype=np.float32)
    phi      = np.zeros((N, H, W, agents[0].phi.shape[-1]), dtype=np.float32)

    mu_p     = np.zeros((N, H, W, K_p), dtype=np.float32)
    sigma_p  = np.zeros((N, H, W, K_p, K_p), dtype=np.float32)
    phi_model= np.zeros((N, H, W, agents[0].phi_model.shape[-1]), dtype=np.float32)

    mask     = np.zeros((N, H, W), dtype=np.float32)

    # optional fields (allocate only if needed)
    if do_align:
        belief_align      = np.zeros((N, H, W), dtype=np.float32)
        model_align       = np.zeros((N, H, W), dtype=np.float32)
        kl_self_field     = np.zeros((N, H, W), dtype=np.float32)
        kl_feedback_field = np.zeros((N, H, W), dtype=np.float32)
    else:
        belief_align = model_align = kl_self_field = kl_feedback_field = None

    if do_curv:
        curv_tensor        = np.zeros((N, H, W, K_q, K_q), dtype=np.float32)
        curv_model_tensor  = np.zeros((N, H, W, K_p, K_p), dtype=np.float32)
        Fq_norm            = np.zeros((N, H, W), dtype=np.float32)
        Fp_norm            = np.zeros((N, H, W), dtype=np.float32)
    else:
        curv_tensor = curv_model_tensor = Fq_norm = Fp_norm = None

    # --- fill per-agent ---
    for idx, A in enumerate(agents):
        mu_q[idx]       = A.mu_q_field
        sigma_q[idx]    = A.sigma_q_field
        phi[idx]        = A.phi

        mu_p[idx]       = A.mu_p_field
        sigma_p[idx]    = A.sigma_p_field
        phi_model[idx]  = A.phi_model

        mask[idx]       = A.mask.astype(np.float32)

        if do_align:
            # local alignment snapshot (only χ_i region will be used downstream typically)
            belief_align[idx] = compute_alignment_field_general(agents, idx, field_type="belief")
            model_align[idx]  = compute_alignment_field_general(agents, idx, field_type="model")

          # KL fields w/ morphisms (inside A’s support) — automatic interior & Φ̃-gating
            # push p → q-space once
            mu_pq, S_pq = safe_batch_apply_morphism_nat(
                A.mu_p_field, A.sigma_p_field, A.bundle_morphism_p_to_q, eps=config.log_eps
            )
            
            # KL(q || Φ̃·p) on auto-chosen interior (kills boundary ring without tuning)
            kl_self_field[idx] = kl_divergence_field_auto(
                mu1     = A.mu_q_field,
                S1      = A.sigma_q_field,
                mu2     = mu_pq,
                S2      = S_pq,
                mask    = A.mask,
                morphism= A.bundle_morphism_p_to_q,  # Φ̃
                eps     = config.log_eps,
            )

            
                      # push q → p-space once
            mu_qp, S_qp = safe_batch_apply_morphism_nat(
                A.mu_q_field, A.sigma_q_field, A.bundle_morphism_q_to_p, eps=config.log_eps
            )
            
            # KL(p || Φ·q) on auto-chosen interior (radius-scaled + Φ-gated)
            kl_feedback_field[idx] = kl_divergence_field_auto(
                mu1      = A.mu_p_field,
                S1       = A.sigma_p_field,
                mu2      = mu_qp,
                S2       = S_qp,
                mask     = A.mask,
                morphism = A.bundle_morphism_q_to_p,  # Φ
                eps      = config.log_eps,
            )


        if do_curv:
            Fq = compute_field_strength(A.phi, generators=Gq, dx=dx)["xy"]          # (H,W,K_q,K_q)
            Fp = compute_field_strength(A.phi_model, generators=Gp, dx=dx)["xy"]    # (H,W,K_p,K_p)
            curv_tensor[idx]       = Fq
            curv_model_tensor[idx] = Fp
            # cheap scalar summaries
            Fq_norm[idx] = np.linalg.norm(Fq, axis=(-2, -1))
            Fp_norm[idx] = np.linalg.norm(Fp, axis=(-2, -1))

    # bundle morphisms
    phi_q_to_p_stack = np.stack([A.bundle_morphism_q_to_p for A in agents], axis=0)
    phi_p_to_q_stack = np.stack([A.bundle_morphism_p_to_q for A in agents], axis=0)

    # --- save ---
    os.makedirs(outdir, exist_ok=True)
    fname = Path(outdir) / f"step{step:05d}.npz"

    # build kwargs dynamically to avoid storing unused arrays
    save_kwargs = dict(
        schema=schema,
        mu_q=mu_q, sigma_q=sigma_q, phi=phi,
        mu_p=mu_p, sigma_p=sigma_p, phi_model=phi_model,
        mask=mask,
        phi_q_to_p=phi_q_to_p_stack,
        phi_p_to_q=phi_p_to_q_stack,
    )
    if do_align:
        save_kwargs.update(
            belief_align=belief_align,
            model_align=model_align,
            kl_self=kl_self_field,
            kl_feedback=kl_feedback_field,
        )
    if do_curv:
        save_kwargs.update(
            curv_tensor=curv_tensor,
            curv_model_tensor=curv_model_tensor,
            Fq_norm=Fq_norm,
            Fp_norm=Fp_norm,
        )

    np.savez_compressed(fname, **save_kwargs)
    print(f"[DUMP] step={step} → {fname}")






# ─────────────────────────────────────────────────────────────────────────────
# Meta-agent (parent) metrics
# ─────────────────────────────────────────────────────────────────────────────

def zero_parent_metrics() -> dict:
    return {
        # basics / shape
        "support": 0,               # parent mask area (thr)
        "child_count": 0,           # #children attached
        # overlaps with children
        "iou_mean": np.nan,
        "iou_min":  np.nan,
        "iou_max":  np.nan,
        "union_iou": np.nan,        # IoU(parent, union(children))
        "inter_iou": np.nan,        # IoU(parent, intersection(children))
        # φ summaries on parent support
        "phi_norm": 0.0,
        "phi_model_norm": 0.0,
        "F_norm_q_sum": 0.0,
        "F_norm_p_sum": 0.0,
        # optional conditioning of parent fields on support
        "min_eig_q": np.nan, "max_eig_q": np.nan, "cond_q": np.nan,
        "min_eig_p": np.nan, "max_eig_p": np.nan, "cond_p": np.nan,
        # (optional) cross-scale KL to children (avg over attached kids)
        "kl_q_mean": np.nan,
        "kl_p_mean": np.nan,
    }


def _mask_area(mask, thr=0.3) -> int:
    if mask is None:
        return 0
    return int((np.asarray(mask) > thr).sum())


def _iou(a_bool, b_bool) -> float:
    u = (a_bool | b_bool).sum()
    if u == 0:
        return 0.0
    return float((a_bool & b_bool).sum()) / float(u)


def _child_stack_bool(children, ids, eps=1e-6):
    if not ids:
        return None
    return np.stack([(children[i].mask > eps) for i in ids], axis=0)  # (C,H,W) bool


def compute_parent_metrics(P, children, thr=0.3, eps=1e-6, cfg=None, generators=None) -> dict:
    """
    Compute scalar diagnostics for one parent P.
    - Overlap stats w/ its children
    - φ/φ̃ norms and curvature on P.mask
    - (optional) conditioning stats on parent Σ fields
    - (optional) average cross-scale KL to attached children (best-effort)
    """
    stats = zero_parent_metrics()
    if P is None:
        return stats

    m = np.asarray(getattr(P, "mask", None))
    if m is None:
        return stats
    m_bool = (m > thr)
    stats["support"] = int(m_bool.sum())

    # children list
    kid_ids = list(getattr(P, "child_ids", []))
    stats["child_count"] = len(kid_ids)

    # Overlap summaries
    if kid_ids:
        S = _child_stack_bool(children, kid_ids, eps=eps)  # (C,H,W)
        union = S.any(axis=0)
        inter = S.all(axis=0)

        # IoU(parent, union/intersection)
        stats["union_iou"] = _iou(m_bool, union)
        stats["inter_iou"] = _iou(m_bool, inter)

        # IoU(parent, each child)
        ious = []
        for i in range(S.shape[0]):
            ious.append(_iou(m_bool, S[i]))
        if ious:
            stats["iou_mean"] = float(np.mean(ious))
            stats["iou_min"]  = float(np.min(ious))
            stats["iou_max"]  = float(np.max(ious))

    # φ norms on support
    if hasattr(P, "phi") and P.phi is not None:
        stats["phi_norm"] = float(np.linalg.norm(P.phi[m_bool], axis=-1).sum())
    if hasattr(P, "phi_model") and P.phi_model is not None:
        stats["phi_model_norm"] = float(np.linalg.norm(P.phi_model[m_bool], axis=-1).sum())

    # Curvature summaries (best-effort; ignore if helper not present)
    try:
        gen_q = (generators[0] if generators is not None else getattr(P, "generators_q", None))
        gen_p = (generators[1] if generators is not None else getattr(P, "generators_p", None))
        if gen_q is not None and hasattr(P, "phi") and P.phi is not None:
            Fq = compute_field_strength(P.phi, generators=gen_q, dx=(cfg.get("dx",1.0) if cfg else 1.0))["xy"]
            stats["F_norm_q_sum"] = float(np.linalg.norm(Fq, axis=(-2,-1))[m_bool].sum())
        if gen_p is not None and hasattr(P, "phi_model") and P.phi_model is not None:
            Fp = compute_field_strength(P.phi_model, generators=gen_p, dx=(cfg.get("dx",1.0) if cfg else 1.0))["xy"]
            stats["F_norm_p_sum"] = float(np.linalg.norm(Fp, axis=(-2,-1))[m_bool].sum())
    except Exception:
        pass

    # Conditioning of parent Σ fields on support (reuse your eig_stats helper if present)
    try:
        if hasattr(P, "sigma_q_field") and P.sigma_q_field is not None:
            qstats = eig_stats(P.sigma_q_field, m_bool, eps=(cfg.get("eps",1e-6) if cfg else 1e-6))
            stats["min_eig_q"] = qstats["min_eig"]; stats["max_eig_q"] = qstats["max_eig"]; stats["cond_q"] = qstats["cond_mean"]
        if hasattr(P, "sigma_p_field") and P.sigma_p_field is not None:
            pstats = eig_stats(P.sigma_p_field, m_bool, eps=(cfg.get("eps",1e-6) if cfg else 1e-6))
            stats["min_eig_p"] = pstats["min_eig"]; stats["max_eig_p"] = pstats["max_eig"]; stats["cond_p"] = pstats["cond_mean"]
    except Exception:
        pass

    # Optional: cross-scale KL to children (q/p) if you have helpers; otherwise skip silently
    # Expectation: functions like `kl_child_vs_parent_q(child, parent, labels)` exist.
    try:
        if kid_ids and hasattr(P, "Lambda_dn_q") and P.Lambda_dn_q is not None:
            vals = []
            for cid in kid_ids:
                # Replace with your actual KL call; this is a safe placeholder:
                v = compute_crossscale_kl_q_single(children[cid], P, eps=1e-6)  # user-provided helper if available
                if np.isfinite(v):
                    vals.append(v)
            if vals:
                stats["kl_q_mean"] = float(np.mean(vals))
    except Exception:
        pass

    try:
        if kid_ids and hasattr(P, "Lambda_dn_p") and P.Lambda_dn_p is not None:
            vals = []
            for cid in kid_ids:
                v = compute_crossscale_kl_p_single(children[cid], P, eps=1e-6)  # user-provided helper if available
                if np.isfinite(v):
                    vals.append(v)
            if vals:
                stats["kl_p_mean"] = float(np.mean(vals))
    except Exception:
        pass

    return stats


def compute_crossscale_kl_q_single(child, parent, eps=1e-6):
    mask = (child.mask > eps) & (parent.mask > eps)
    if not mask.any():
        return np.nan
    # Transform parent p → child's fiber
    q_trans = parent.Lambda_dn_q @ parent.mu_q_field[mask]
    # KL(q_child || transformed parent p)
    return kl_gaussians(child.mu_q_field[mask], child.sigma_q_field[mask],
                       q_trans, parent.sigma_q_field[mask])



def compute_crossscale_kl_p_single(child, parent, eps=1e-6):
    mask = (child.mask > eps) & (parent.mask > eps)
    if not mask.any():
        return np.nan
    # Transform parent p → child's fiber
    p_trans = parent.Lambda_dn_p @ parent.mu_p_field[mask]
    # KL(q_child || transformed parent p)
    return kl_gaussians(child.mu_p_field[mask], child.sigma_p_field[mask],
                       p_trans, parent.sigma_p_field[mask])



def log_parent_metrics(parents, step: int, cfg=None, generators=None, thr=0.3) -> list[dict]:
    """
    Returns a list of per-parent dicts (also good for CSV).
    Doesn’t mutate parent objects (but you could if you want symmetry with Agent.log_metrics).
    """
    rows = []
    for pid, P in enumerate(parents):
        s = compute_parent_metrics(P, children=P.child_ids and P._children_ref if hasattr(P, "_children_ref") else None,  # optional hidden ref
                                   thr=thr, cfg=cfg, generators=generators)
        # If no hidden ref, pass children separately via wrapper below
        s["step"] = step
        s["parent"] = pid
        rows.append(s)
    return rows


def log_parent_metrics_with_children(parents, children, step: int, cfg=None, generators=None, thr=0.3) -> list[dict]:
    rows = []
    for pid, P in enumerate(parents):
        s = compute_parent_metrics(P, children=children, thr=thr, cfg=cfg, generators=generators)
        s["step"] = step
        s["parent"] = pid
        rows.append(s)
    return rows


def _append_parent_metrics_csv(outdir, step, parents, children=None, cfg=None, generators=None, thr=0.3):
    import os, pandas as pd
    if children is not None:
        rows = log_parent_metrics_with_children(parents, children, step, cfg=cfg, generators=generators, thr=thr)
    else:
        rows = log_parent_metrics(parents, step, cfg=cfg, generators=generators, thr=thr)
    df = pd.DataFrame(rows)
    path = os.path.join(outdir, "parent_metrics.csv")
    df.to_csv(path, mode="a", header=not os.path.exists(path), index=False)
























import numpy as np

def safe_sum(x, where=None):
    if where is not None: x = np.where(where, x, 0.0)
    x = np.nan_to_num(x, nan=0.0, posinf=0.0, neginf=0.0)
    return float(np.sum(x, dtype=np.float64))

def safe_mean(x, where=None):
    if where is not None:
        x = np.where(where, x, np.nan)
    x = np.where(np.isfinite(x), x, np.nan)
    m = np.nanmean(x)
    return float(0.0 if np.isnan(m) else m)

def support_size(mask):
    return int(np.sum(mask.astype(np.int64)))

def support_norm(v, mask):
    # v: (..., d). Returns sum of vector norms over mask
    m = mask[..., None]
    vn = np.linalg.norm(np.where(m, v, 0.0), axis=-1)
    return safe_sum(vn)

def eig_stats(SIG, mask, eps=0.0):
    # SIG: (H,W,K,K)
    H,W,K,_ = SIG.shape
    m = mask[..., None, None]
    S = np.where(m, SIG, 0.0)
    # reshape to (M,K,K) only inside mask to keep cost bounded
    idx = np.flatnonzero(mask.ravel())
    if idx.size == 0:
        return dict(min_eig=np.nan, max_eig=np.nan, clipped=0, cond_mean=np.nan)
    mats = S.reshape(H*W, K, K)[idx]
    # symmetric guard
    mats = 0.5*(mats + np.swapaxes(mats, -1, -2))
    vals = np.linalg.eigvalsh(mats)
    min_e = float(np.nanmin(vals))
    max_e = float(np.nanmax(vals))
    conds = np.nan_to_num(np.abs(vals.max(axis=-1))/np.maximum(np.abs(vals.min(axis=-1)), eps), nan=np.inf, posinf=np.inf)
    return dict(
        min_eig=min_e,
        max_eig=max_e,
        clipped=int(np.sum(vals < eps)),
        cond_mean=float(np.mean(conds))
    )

























