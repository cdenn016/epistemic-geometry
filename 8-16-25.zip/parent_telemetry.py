# -*- coding: utf-8 -*-
"""
Created on Mon Aug 11 17:13:40 2025

@author: chris and christine
"""

# parent_telemetry.py
import numpy as np

def _l2(x): 
    return float(np.sqrt(np.mean(x.astype(np.float64)**2)))

def _area(mask, thr=0.3):
    return int((np.asarray(mask) > thr).sum())

def capture_parent_snapshot(P):
    return dict(
        mu_q_l2 = _l2(P.mu_q_field),
        mu_p_l2 = _l2(getattr(P, "mu_p_field", P.mu_q_field)),
        phi_l2  = _l2(P.phi),
        phi_m_l2= _l2(P.phi_model),
        mask_px = _area(P.mask),
        w_q     = float(getattr(P, "lambda_q_weight", 0.0)),
        w_p     = float(getattr(P, "lambda_p_weight", 0.0)),
        age     = int(getattr(P, "birth_step", 0)),
        kids    = int(len(getattr(P, "child_ids", []))),
    )

def diff_snap(a, b):
    # returns small dict of deltas a->b
    out = {}
    for k in b.keys():
        if k in a:
            out["d_"+k] = float(b[k] - a[k])
    return out

def log_parent_step(runtime_ctx, step, sink_list):
    """Compute per-parent deltas vs previous snapshot and append to sink_list."""
    if not hasattr(runtime_ctx, "_parent_prev"): runtime_ctx._parent_prev = {}
    prev = runtime_ctx._parent_prev
    for rid, P in runtime_ctx.parents_by_region.items():
        snap = capture_parent_snapshot(P)
        row  = dict(step=step, parent_id=P.id, region_id=rid, age_steps=step - getattr(P, "birth_step", step))
        row.update(snap)
        if rid in prev:
            row.update(diff_snap(prev[rid], snap))
        sink_list.append(row)
        prev[rid] = snap

import os
import numpy as np
import matplotlib.pyplot as plt

# ---------- SNAPSHOT ----------

def _snapshot_parents_npz(parents, path):
    """
    Snapshot of all parent fields for diagnostics.

    Saves a compressed NPZ with arrays:
      - masks:            (N, H, W)
      - phi:              (N, H, W, 3)
      - phi_model:        (N, H, W, 3)
      - mu_q_field:       (N, H, W, Kq)
      - sigma_q_field:    (N, H, W, Kq, Kq)
      - mu_p_field:       (N, H, W, Kp)
      - sigma_p_field:    (N, H, W, Kp, Kp)
      - bundle_morphism_q_to_p: (N, H, W, Kp, Kq)
      - bundle_morphism_p_to_q: (N, H, W, Kq, Kp)
      - parent_ids:       (N,) int32
    """
    import os
    import numpy as np

    # Create parent folder if provided
    d = os.path.dirname(path)
    if d and not os.path.exists(d):
        os.makedirs(d, exist_ok=True)

    if not parents:
        raise ValueError("No parents passed to _snapshot_parents_npz().")

    masks, phi, phi_model, ids = [], [], [], []
    mu_q, sigma_q, mu_p, sigma_p = [], [], [], []
    morph_qp, morph_pq = [], []
    H = W = None
    for P in parents:
        m  = np.asarray(getattr(P, "mask",   0), dtype=np.float32)
        ph = np.asarray(getattr(P, "phi",    0), dtype=np.float32)
        pm = np.asarray(getattr(P, "phi_model", 0), dtype=np.float32)

        mu_q_field    = np.asarray(getattr(P, "mu_q_field", 0), dtype=np.float32)
        sigma_q_field = np.asarray(getattr(P, "sigma_q_field", 0), dtype=np.float32)
        mu_p_field    = np.asarray(getattr(P, "mu_p_field", 0), dtype=np.float32)
        sigma_p_field = np.asarray(getattr(P, "sigma_p_field", 0), dtype=np.float32)

        Phi_qp = np.asarray(getattr(P, "bundle_morphism_q_to_p", 0), dtype=np.float32)
        Phi_pq = np.asarray(getattr(P, "bundle_morphism_p_to_q", 0), dtype=np.float32)

        if m.ndim != 2:
            raise ValueError(f"Parent {getattr(P,'id','?')} mask must be 2D; got shape {m.shape}")
        if ph.shape != (*m.shape, 3) or pm.shape != (*m.shape, 3):
            raise ValueError(f"Parent {getattr(P,'id','?')} phi/phi_model must be (H,W,3); "
                             f"got phi={ph.shape}, phi_model={pm.shape}")

        if H is None:
            H, W = m.shape
        elif m.shape != (H, W):
            raise ValueError(f"Inconsistent grid: expected {(H,W)}, got {m.shape} for parent {getattr(P,'id','?')}")

        masks.append(m)
        phi.append(ph)
        phi_model.append(pm)
        mu_q.append(mu_q_field)
        sigma_q.append(sigma_q_field)
        mu_p.append(mu_p_field)
        sigma_p.append(sigma_p_field)
        morph_qp.append(Phi_qp)
        morph_pq.append(Phi_pq)
        ids.append(int(getattr(P, "id", len(ids) + 1)))

    np.savez_compressed(
        path,
        masks=np.stack(masks, axis=0),
        phi=np.stack(phi, axis=0),
        phi_model=np.stack(phi_model, axis=0),
        mu_q_field=np.stack(mu_q, axis=0),
        sigma_q_field=np.stack(sigma_q, axis=0),
        mu_p_field=np.stack(mu_p, axis=0),
        sigma_p_field=np.stack(sigma_p, axis=0),
        bundle_morphism_q_to_p=np.stack(morph_qp, axis=0),
        bundle_morphism_p_to_q=np.stack(morph_pq, axis=0),
        parent_ids=np.asarray(ids, dtype=np.int32),
    )

    
    
def snapshot_parents_for_step(runtime_ctx, outdir, step, every=1, subdir="parents", *, ragged=True):
    """
    Save parent fields this step if (step % every)==0.
    If ragged=True, uses per-parent keys (handles mixed shapes/K).
    """
    if every <= 0 or (step % every) != 0:
        return

    # collect across all levels if present
    def _collect_all_parents(ctx):
        if hasattr(ctx, "parents_by_region_L") and isinstance(ctx.parents_by_region_L, dict):
            allp = []
            for d in ctx.parents_by_region_L.values():
                if isinstance(d, dict):
                    allp.extend(d.values())
            return allp
        return list((getattr(ctx, "parents_by_region", {}) or {}).values())

    parents = _collect_all_parents(runtime_ctx)
    if not parents:
        return

    import os
    os.makedirs(os.path.join(outdir, subdir), exist_ok=True)
    path = os.path.join(outdir, subdir, f"parents_step_{step:04d}.npz")
    if ragged:
        _snapshot_parents_npz_ragged(parents, path)
    else:
        # fallback to stacked saver (same-level, same shape)
        _snapshot_parents_npz(parents, path)


def _snapshot_parents_npz_ragged(parents, path):
    """
    Snapshot parents with mixed shapes/K by saving per-parent keys.
    Example keys: mask_12, phi_12, mu_q_12, sigma_q_12, ...
    """
    import os, numpy as np
    d = os.path.dirname(path)
    if d and not os.path.exists(d):
        os.makedirs(d, exist_ok=True)
    if not parents:
        raise ValueError("No parents passed to snapshot.")

    payload = {}
    id_list = []
    for P in parents:
        pid = int(getattr(P, "id", len(id_list) + 1))
        id_list.append(pid)

        def arr(x, dtype=None):
            a = np.asarray(x)
            return a.astype(dtype) if (dtype is not None and a.dtype != dtype) else a

        payload[f"mask_{pid}"]   = arr(getattr(P, "mask", 0), np.float32)
        payload[f"phi_{pid}"]    = arr(getattr(P, "phi", 0), np.float32)
        payload[f"phiM_{pid}"]   = arr(getattr(P, "phi_model", 0), np.float32)

        payload[f"muq_{pid}"]    = arr(getattr(P, "mu_q_field", 0), np.float32)
        payload[f"Sigq_{pid}"]   = arr(getattr(P, "sigma_q_field", 0), np.float32)
        payload[f"mup_{pid}"]    = arr(getattr(P, "mu_p_field", 0), np.float32)
        payload[f"Sigp_{pid}"]   = arr(getattr(P, "sigma_p_field", 0), np.float32)

        payload[f"Phi_qp_{pid}"] = arr(getattr(P, "bundle_morphism_q_to_p", 0), np.float32)
        payload[f"Phi_pq_{pid}"] = arr(getattr(P, "bundle_morphism_p_to_q", 0), np.float32)

    payload["parent_ids"] = np.asarray(id_list, np.int32)
    np.savez_compressed(path, **payload)


import pandas as pd  
    
def load_ragged_parent_snapshot(path):
    """Return dict: {pid: {'mask':..., 'phi':..., 'muq':..., ...}}."""
    import numpy as np
    z = np.load(path, allow_pickle=True)
    pids = list(map(int, z["parent_ids"]))
    out = {}
    for pid in pids:
        out[pid] = {
            "mask":   z.get(f"mask_{pid}", None),
            "phi":    z.get(f"phi_{pid}", None),
            "phiM":   z.get(f"phiM_{pid}", None),
            "muq":    z.get(f"muq_{pid}", None),
            "Sigq":   z.get(f"Sigq_{pid}", None),
            "mup":    z.get(f"mup_{pid}", None),
            "Sigp":   z.get(f"Sigp_{pid}", None),
            "Phi_qp": z.get(f"Phi_qp_{pid}", None),
            "Phi_pq": z.get(f"Phi_pq_{pid}", None),
        }
    return out
 
    
def _append_parent_metrics_csv(outdir, step, parents):
   
    rows = []
    for pid, P in enumerate(parents):
        m = np.asarray(getattr(P, "mask", 0), dtype=np.float32)
        area = float((m > 0.3).sum())
        # A couple of simple, universal summaries:
        n_phi = np.sqrt(np.maximum((np.asarray(P.phi)**2).sum(axis=-1), 0.0)) if hasattr(P, "phi") else 0.0
        n_mod = np.sqrt(np.maximum((np.asarray(P.phi_model)**2).sum(axis=-1), 0.0)) if hasattr(P, "phi_model") else 0.0
        e_phi_in = float((n_phi * (m > 0.3)).sum()) if hasattr(P, "phi") else 0.0
        e_phi_all = float(n_phi.sum()) if hasattr(P, "phi") else 0.0
        rows.append({
            "step": step,
            "parent": pid,
            "mask_area_thr0p3": area,
            "Ephi_in": e_phi_in,
            "Ephi_all": e_phi_all,
            "Ephi_frac_in": (e_phi_in / (e_phi_all + 1e-9)) if e_phi_all else 0.0,
        })
    df = pd.DataFrame(rows)
    path = os.path.join(outdir, "parent_metrics.csv")
    if os.path.exists(path):
        df.to_csv(path, mode="a", header=False, index=False)
    else:
        df.to_csv(path, index=False)
    
    
    
    
    
    
    