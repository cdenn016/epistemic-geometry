# -*- coding: utf-8 -*-
"""
Created on Sun Jul 13 13:06:16 2025

@author: chris and christine
"""
import sys
import numpy as np
import warnings
from collections import defaultdict
from joblib import Parallel, delayed
from numpy.linalg import LinAlgError, slogdet  # ✅ Needed for exception handling
import config
from scipy.linalg import logm  # Only if safe_logm is used
import io
import contextlib


# Global counters
fallback_counter = defaultdict(int)

#=======================================
#
#         Reporting/Logging
#
#======================================

import numpy as np
from numpy.linalg import LinAlgError
from joblib import Parallel, delayed
import config


# ----- geometry / morphology -----
def resize_nn(a: np.ndarray, shape: tuple[int, int]) -> np.ndarray:
    H, W = shape; h, w = a.shape[:2]
    if (h, w) == (H, W): return a
    yi = np.clip(np.rint(np.linspace(0, h - 1, H)).astype(int), 0, h - 1)
    xi = np.clip(np.rint(np.linspace(0, w - 1, W)).astype(int), 0, w - 1)
    return a[yi][:, xi]


def project_spd(S, eps=1e-6):
    S = 0.5 * (S + np.swapaxes(S, -1, -2))
    orig, K = S.shape[:-2], S.shape[-1]
    flat = S.reshape(-1, K, K).astype(np.float64)
    out  = np.empty_like(flat)
    for i, A in enumerate(flat):
        w, V = np.linalg.eigh(A)
        w = np.clip(w, eps, None)
        out[i] = (V / w) @ V.T
    return out.reshape(*orig, K, K)




def safe_inv(Sigma, eps=1e-10, max_eig=None, debug=False):
    """
    Batch-safe inverse of SPD matrices with eigenvalue clipping.
    Supports input shape (..., K, K).

    Returns inverse of Sigma with clipped eigenvalues from below (and optionally from above).
    """
    shape = Sigma.shape
    K = shape[-1]
    flat_S = Sigma.reshape(-1, K, K)

    # Step 1: eigen-decomposition (batch)
    eigvals, eigvecs = np.linalg.eigh(flat_S)

    if debug:
        print(f"[safe_inv] eigvals min={eigvals.min(axis=1).min():.2e}, max={eigvals.max(axis=1).max():.2e}")

    # Step 2: clip eigenvalues
    if max_eig is not None:
        eigvals_clipped = np.clip(eigvals, eps, max_eig)
    else:
        eigvals_clipped = np.maximum(eigvals, eps)

    inv_eigvals = 1.0 / eigvals_clipped

    # Step 3: reconstruct inverse matrices
    Sigma_inv = (eigvecs * inv_eigvals[..., None, :]) @ np.swapaxes(eigvecs, -2, -1)

    # Symmetrize for numerical safety
    Sigma_inv = 0.5 * (Sigma_inv + np.swapaxes(Sigma_inv, -1, -2))

    # Handle NaN / Inf
    Sigma_inv = np.nan_to_num(Sigma_inv, nan=eps, posinf=eps, neginf=eps)

    Sigma_inv = Sigma_inv.reshape(shape)

    return Sigma_inv


def safe_batch_inverse(S, name="Σ", mask=None, n_jobs=None):
    """
    Batch matrix inversion with fallback on failure, using joblib parallelism.
    Inputs:
        S: (H, W, K, K) batch of matrices to invert
        mask: optional (H, W) bool mask for which matrices to invert
        n_jobs: number of parallel workers
    Returns:
        inv_S: (H, W, K, K) inverse matrices
    """

    H, W, K, _ = S.shape
    flat_S = S.reshape(-1, K, K)

    if mask is None:
        flat_mask = np.ones(H * W, dtype=bool)
    else:
        flat_mask = mask.reshape(-1)

    if n_jobs is None:
        n_jobs = getattr(config, "num_cores", 1)

    eye_K = np.eye(K, dtype=S.dtype)

    def try_inv(i):
        if not flat_mask[i]:
            return eye_K
        try:
            return np.linalg.inv(flat_S[i])
        except LinAlgError:
            if config.debug:
                print(f"[WARN] Inversion failed at flat index {i} — using identity")
            return eye_K

    # Parallel invert with joblib (threading backend usually fine for numpy)
    inv_results = Parallel(n_jobs=n_jobs, backend="threading")(
        delayed(try_inv)(i) for i in range(H * W)
    )

    inv_S = np.stack(inv_results).reshape(H, W, K, K)
    return inv_S


def safe_invold(Sigma, eps=1e-10, max_eig=None, debug=False):
    """
    Relaxed safe inverse of symmetric positive-definite matrix Σ.

    Clips only *small* eigenvalues to prevent explosion.
    Allows large eigenvalues (unless max_eig is provided).
    Keeps fallback in case of failure.

    Args:
        Sigma     : (..., K, K) batch of SPD or NSD matrices (neg-def allowed too)
        eps       : minimal eigenvalue magnitude for stability
        max_eig   : if not None, clips large eigenvalues
        debug     : diagnostics

    Returns:
        Sigma_inv : (..., K, K)
    """
   

    try:
        eigvals, eigvecs = np.linalg.eigh(Sigma)

        if debug:
            print(f"[safe_inv] raw eig min={eigvals.min():.2e}, max={eigvals.max():.2e}")

        # ─── Clip small eigenvalues from below ───
        eigvals_clipped = np.clip(eigvals, eps, max_eig) if max_eig else np.maximum(eigvals, eps)

        inv_eigvals = 1.0 / eigvals_clipped
        Sigma_inv = np.einsum("...ik,...k,...jk->...ij", eigvecs, inv_eigvals, eigvecs)

        # Symmetrize for safety
        Sigma_inv = 0.5 * (Sigma_inv + np.swapaxes(Sigma_inv, -1, -2))
        return np.nan_to_num(Sigma_inv, nan=eps, posinf=eps, neginf=eps)

    except LinAlgError:
        if debug:
            print("[safe_inv] LinAlgError — fallback to scaled identity")
        K = Sigma.shape[-1]
        fallback = 1e2
        return np.eye(K, dtype=Sigma.dtype) * fallback

    
    
  



def safe_batch_inverseold(S, name="Σ", mask=None):
    """
    Inverts (H, W, K, K) SPD field with fallback and optional mask.
    """
    H, W, K, _ = S.shape
    eye_K = np.eye(K, dtype=S.dtype)
    inv_S = np.zeros_like(S)

    flat_S = S.reshape(-1, K, K)
    flat_mask = mask.reshape(-1) if mask is not None else np.ones(H * W, dtype=bool)

    for idx in range(H * W):
        if not flat_mask[idx]:
            inv_S.reshape(-1, K, K)[idx] = eye_K
            continue
        try:
            inv_S.reshape(-1, K, K)[idx] = np.linalg.inv(flat_S[idx])
        except np.linalg.LinAlgError:
            inv_S.reshape(-1, K, K)[idx] = eye_K
            if config.debug:
                i, j = divmod(idx, W)
                print(f"[WARN] Inversion failed at ({i},{j}) for {name} — using identity")

    return inv_S













def soft_clip_phi_norm(phi: np.ndarray, max_norm: float = np.pi, eps: float = 1e-8) -> np.ndarray:
    """
    Smoothly compress φ ∈ ℝᵈ to have norm ≤ max_norm, with soft decay and stable transition.

    Args:
        phi:      (..., d) Lie algebra field at each point
        max_norm: float, maximum allowed norm
        eps:      float, safety margin for zero division

    Returns:
        φ_clipped: (..., d) compressed φ with ‖φ‖ ≤ max_norm
    """
    norm = np.linalg.norm(phi, axis=-1, keepdims=True)  # (..., 1)
    scale = np.where(norm > max_norm, max_norm / (norm + eps), 1.0)  # (..., 1)
    return phi * scale  # (..., d)




def log_fallback(tag: str, msg: str, count_key: str = None, error: bool = False):
    """
    Standardized fallback logger.

    Args:
        tag       : str — context tag (e.g. 'safe_inv', 'logm', etc.)
        msg       : str — fallback message
        count_key : str — key for fallback_counter increment
        error     : bool — whether to raise RuntimeError (if fail_on_fallback)

    Behavior:
        - Increments fallback counter
        - Warns or raises
        - Flushes stdout
    """
    full_msg = f"[{tag}] {msg}"

    if count_key:
        fallback_counter[count_key] += 1
        full_msg = f"[{tag}] Fallback #{fallback_counter[count_key]}: {msg}"

    if getattr(config, "fail_on_fallback", False) or error:
        raise RuntimeError(full_msg)
    else:
        warnings.warn(full_msg, RuntimeWarning)
        sys.stdout.flush()


        
#====================================================
#
#                 Safety Ops
#
#=====================================================

def safe_omega_inv(M, eps=1e-10, debug=False):
    """
    Safely invert an SO(3) matrix via transpose, with validation and fallback.

    Args:
        M      : (..., K, K) matrix expected to be in SO(3)
        eps    : numerical tolerance
        debug  : if True, print diagnostic info

    Returns:
        M_inv  : (..., K, K) inverse (i.e., transpose), or identity fallback
    """
    import numpy as np

    try:
        # ───── Check shape and square ─────
        assert M.shape[-1] == M.shape[-2], "Matrix is not square"
        K = M.shape[-1]

        # ───── Check if orthogonal: M Mᵀ ≈ I ─────
        M_T = np.swapaxes(M, -1, -2)
        identity = np.eye(K, dtype=M.dtype)
        approx_I = np.matmul(M, M_T)

        if not np.all(np.isfinite(M)):
            raise ValueError("Non-finite values in Ω")

        deviation = np.linalg.norm(approx_I - identity, axis=(-2, -1))
        if np.any(deviation > eps):
            raise ValueError(f"Ω not orthogonal (‖MMᵀ − I‖ > {eps})")

        return M_T  # safe inverse for SO(3)

    except Exception as e:
        if debug:
            print(f"[safe_omega_inv] fallback: {str(e)}")
        log_fallback("safe_omega_inv", str(e), count_key="omega_inv")
        return np.eye(M.shape[-1], dtype=M.dtype)


def _sanitize_one_sigma(S, eps=1e-4, debug=False):
    """
    Ensure a single Σ is symmetric positive-definite (SPD).
    Returns: (Σ_sanitized, clipped_flag)
    """
    S = 0.5 * (S + S.T)  # enforce symmetry

    if not np.all(np.isfinite(S)):
        if debug:
            print("[sanitize_sigma] NaNs or Infs detected — replacing with eps*I")
        # fallback to scaled identity but warn heavily
        fallback = np.eye(S.shape[0]) * eps
        return fallback, True

    try:
        eigvals, eigvecs = np.linalg.eigh(S)
    except np.linalg.LinAlgError:
        if debug:
            print("[sanitize_sigma] Eigendecomposition failed — replacing with eps*I")
        fallback = np.eye(S.shape[0]) * eps
        return fallback, True

    clipped = np.any(eigvals < eps)
    if clipped:
        if debug:
            print(f"[sanitize_sigma] Minimum eigenvalue {eigvals.min():.3e} below eps {eps:.3e}, clipping...")
        # Clip eigenvalues to eps floor
        eigvals_clipped = np.clip(eigvals, eps, None)
        S = eigvecs @ np.diag(eigvals_clipped) @ eigvecs.T
        S = 0.5 * (S + S.T)  # re-symmetrize

    return S, clipped

def _spd_project_batch(A, eig_floor=1e-6, eig_cap=None, cond_cap=None, trace_target=None, eps=1e-12):
    """
    Project a stack of symmetric matrices A[..., K, K] onto SPD via eigen clipping.
    Returns A_proj with guaranteed SPD (up to eps).
    """
    A = 0.5 * (A + np.swapaxes(A, -1, -2))
    w, V = np.linalg.eigh(A)                           # batched
    # floor
    w = np.maximum(w, eig_floor)
    # condition number cap
    if cond_cap is not None:
        w_min = w.min(axis=-1, keepdims=True)
        w = np.minimum(w, w_min * cond_cap)
    # absolute cap (rarely needed)
    if eig_cap is not None:
        w = np.minimum(w, eig_cap)
    A_proj = (V * w[..., None, :]) @ np.swapaxes(V, -1, -2)
    if trace_target is not None:
        tr = np.trace(A_proj, axis1=-2, axis2=-1)[..., None, None]
        A_proj = A_proj * (trace_target / np.clip(tr, eps, None))
    return 0.5 * (A_proj + np.swapaxes(A_proj, -1, -2))


def sanitize_sigma(
    Sigma,
    eps=None,
    debug=True,
    strict=True,
    eig_floor=None,
    cond_cap=None,
    eig_cap=None,
    trace_target=None,
):
    """
    Ensure Σ is SPD. Vectorized and fast:
      - strict=True: project everything (most robust).
      - strict=False: detect-bad-then-project only those slices.
    Config fallbacks if args are None:
      - sigma_eig_floor, sigma_cond_cap, sigma_eig_cap, sigma_trace_target
    """
    import numpy as np
    import config

    eig_floor = eig_floor if eig_floor is not None else getattr(config, "sigma_eig_floor", 1e-6)
    cond_cap  = cond_cap  if cond_cap  is not None else getattr(config, "sigma_cond_cap", 1e4)
    eig_cap   = eig_cap   if eig_cap   is not None else getattr(config, "sigma_eig_cap", None)
    trace_target = trace_target if trace_target is not None else getattr(config, "sigma_trace_target", None)

    # Symmetrize and quick NaN/Inf handling
    S = 0.5 * (Sigma + np.swapaxes(Sigma, -1, -2))
    bad_finite = ~np.isfinite(S).all(axis=(-2, -1))
    if bad_finite.any():
        if debug:
            print(f"[sanitize_sigma] {int(bad_finite.sum())} matrices had NaN/Inf; replacing with floor*I")
        K = S.shape[-1]
        eye = np.eye(K, dtype=S.dtype)
        S = S.copy()
        S[bad_finite] = eig_floor * eye

    if strict:
        return _spd_project_batch(S, eig_floor, eig_cap, cond_cap, trace_target)

    # Light path: project only the bad ones
    # Cheap detection: just eigenvalues (batched)
    w = np.linalg.eigvalsh(S)
    too_small = (w <= eig_floor).any(axis=-1)
    too_cond  = (w.max(axis=-1) > np.maximum(w.min(axis=-1), eig_floor) * (cond_cap if cond_cap else np.inf))
    bad = too_small | too_cond | bad_finite

    if not bad.any():
        return S

    S = S.copy()
    S_bad = S[bad]
    S_bad = _spd_project_batch(S_bad, eig_floor, eig_cap, cond_cap, trace_target)
    S[bad] = S_bad
    if debug:
        print(f"[sanitize_sigma] projected {int(bad.sum())}/{S.shape[0]*S.shape[1] if S.ndim==4 else S.shape[0]} matrices")
    return S




def safe_logm(M, fallback_value=None, imag_tol=1e-10, context="Ω"):
    """
    Suppress logm's internal stderr output and check imag part manually.
    """
    from numerical_utils import log_fallback  # Ensure this exists

    try:
        # Suppress logm's stderr output
        with io.StringIO() as buf, contextlib.redirect_stderr(buf):
            logM = logm(M)

        imag_norm = np.linalg.norm(np.imag(logM), ord="fro")
        if imag_norm > imag_tol:
            log_fallback("safe_logm", f"{context}: ‖Im(logm)‖={imag_norm:.2e} > tol={imag_tol}")
        return np.real_if_close(logM, tol=imag_tol)

    except Exception as e:
        log_fallback("safe_logm", f"{context}: logm failed ({e})", count_key="safe_logm")
        K = M.shape[-1]
        return fallback_value if fallback_value is not None else np.zeros((K, K), dtype=M.dtype)




def safe_logdet(Sigma, eps=1e-8, alpha=1e-2, clip_range=(-1e3, 1e3)):
    """
    Safe computation of logdet(Sigma) with fallback and stabilization.
    
    Args:
        Sigma : (..., K, K) positive semi-definite matrices
        eps   : float, small stabilizer for numerical safety
        alpha : float, trace-based fallback scaling
        clip_range : tuple (min, max) to clip extreme logdet values

    Returns:
        logdet : (...) ndarray
    """
    

    K = Sigma.shape[-1]
    batch_shape = Sigma.shape[:-2]
    eye = eps * np.eye(K, dtype=Sigma.dtype)
    eye = eye.reshape((1,) * len(batch_shape) + (K, K))
    Sigma_reg = Sigma + eye

    try:
        # Attempt slogdet
        sign, ld = slogdet(Sigma_reg)
        bad = (sign <= 0) | ~np.isfinite(ld)
        if not np.any(bad):
            return np.clip(ld, *clip_range)
    except LinAlgError:
        bad = np.ones(batch_shape, dtype=bool)

    # Fallback: trace-based log surrogate
    trace = np.trace(Sigma, axis1=-2, axis2=-1)  # (...)
    surrogate = alpha * (trace / K + eps)
    fallback_ld = K * np.log(surrogate)

    # Optional: log failure
    log_fallback("safe_logdet", "fallback triggered", count_key="safe_logdet")

    # Return mixed result
    ld_final = np.where(bad, fallback_ld, ld)
    return np.clip(ld_final, *clip_range)



# ─── PATCH: safe_logm (relaxed) ───────────────────────────────────────────────
def safe_logmNEW(M, fallback_value=None, imag_tol=1e-6, context="Ω"):
    """
    Compute logm(M) with stderr suppression and imaginary-part safety.
    More relaxed version: allows larger Im parts before fallback.
    """
    import io
    import contextlib
    from scipy.linalg import logm
    from numerical_utils import log_fallback  # ensure this exists

    try:
        with io.StringIO() as buf, contextlib.redirect_stderr(buf):
            logM = logm(M)

        imag_norm = np.linalg.norm(np.imag(logM), ord="fro")
        if imag_norm > imag_tol:
            log_fallback("safe_logm", f"{context}: ‖Im(logm)‖={imag_norm:.2e} > tol={imag_tol}")
        return np.real_if_close(logM, tol=imag_tol)

    except Exception as e:
        log_fallback("safe_logm", f"{context}: logm failed ({e})", count_key="safe_logm")
        K = M.shape[-1]
        return fallback_value if fallback_value is not None else np.zeros((K, K), dtype=M.dtype)



# ─── PATCH: safe_logdet (relaxed) ─────────────────────────────────────────────
def safe_logdet_NEW(Sigma, eps=1e-10, alpha=1e-1, clip_range=(-1e5, 1e5)):
    """
    Safe computation of logdet(Sigma), fallback to surrogate if unstable.
    More relaxed: smaller eps, larger clip range, looser fallback.
    """
    import numpy as np
    from numpy.linalg import slogdet, LinAlgError
    from numerical_utils import log_fallback

    K = Sigma.shape[-1]
    batch_shape = Sigma.shape[:-2]
    eye = eps * np.eye(K, dtype=Sigma.dtype)
    eye = eye.reshape((1,) * len(batch_shape) + (K, K))
    Sigma_reg = Sigma + eye

    try:
        sign, ld = slogdet(Sigma_reg)
        bad = (sign <= 0) | ~np.isfinite(ld)
        if not np.any(bad):
            return np.clip(ld, *clip_range)
    except LinAlgError:
        bad = np.ones(batch_shape, dtype=bool)

    trace = np.trace(Sigma, axis1=-2, axis2=-1)  # (...)
    surrogate = alpha * (trace / K + eps)
    fallback_ld = K * np.log(surrogate)

    log_fallback("safe_logdet", "fallback triggered", count_key="safe_logdet")

    ld_final = np.where(bad, fallback_ld, ld)
    return np.clip(ld_final, *clip_range)


# numerical_utils.py  (PATCH)

# numerical_utils.py  (PATCH)

import numpy as np

def masked_cond_proxy(S, mask, eps=1e-12):
    # S: (H,W,K,K) already sanitized here
    H,W,K = S.shape[:3]
    S2 = S.reshape(-1, K, K)
    m  = mask.reshape(-1).astype(bool)

    tr  = np.trace(S2, axis1=-2, axis2=-1)[m]                 # (M,)
    sign, logdet = np.linalg.slogdet(S2[m])                   # (M,), (M,)
    # For SPD, sign should be +1; guard anyway
    logdet = np.where(sign > 0, logdet, np.log(eps))
    cond_proxy = tr * np.exp(-logdet / K)                     # scale-invariant

    # robust aggregate over support
    if cond_proxy.size == 0:
        return 1.0
    return float(np.median(cond_proxy))


def masked_stat(x, mask, default=0.0):
    if x is None: return default
    xx = x[mask > getattr(config, "support_cutoff_eps", 0.0)]
    if xx.size == 0 or not np.isfinite(xx).any(): return default
    return float(np.median(xx[np.isfinite(xx)]))
   