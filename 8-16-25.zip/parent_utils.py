# -*- coding: utf-8 -*-
"""
Created on Thu Aug 14 09:35:09 2025

@author: chris and christine
"""

import numpy as np
from agent_schema import Agent
from runtime_context import runtime_ctx

from numerical_utils import resize_nn





def child_activity_map(
    ch, H, W,
    # belief (q) thresholds (kept for backward compat with detector call)
    mu_tau=1e-3, trsig_tau=1e-3,
    # misc
    eps=1e-6,
    # model (p) thresholds (None ⇒ pull from config or fall back to q thresholds)
    mu_tau_p=None, trsig_tau_p=None,
    # mixing controls (None ⇒ pull from config)
    mix_mode=None,                 # 'weighted_or' | 'and' | 'or' | 'model_only' | 'belief_only'
    w_model=None, w_belief=None,   # weights for 'weighted_or'
    score_tau=None                 # threshold for 'weighted_or'
):
    
    try:
        import config  # read knobs if present; avoids hard dep at import time
    except Exception:
        config = None

    # --- mask gate (always required) ---
    m = getattr(ch, "mask", None)
    if m is None:
        return None
    m_ok = (np.asarray(m, np.float32) > eps)
    # --- fetch fields ---
    mu_q, Sig_q = getattr(ch, "mu_q_field", None), getattr(ch, "sigma_q_field", None)
    mu_p, Sig_p = getattr(ch, "mu_p_field", None), getattr(ch, "sigma_p_field", None)

    # fast path: only mask known
    if ((mu_q is None or Sig_q is None) and (mu_p is None or Sig_p is None)):
        return m_ok

     # thresholds
    if mu_tau_p is None:
        mu_tau_p = float(getattr(config, "activity_mu_tau", mu_tau))
    if trsig_tau_p is None:
        trsig_tau_p = float(getattr(config, "activity_trsig_tau", trsig_tau))
    
    # mixing
    if w_model is None:
        w_model = float(getattr(config, "activity_model_weight", 0.1))
    if w_belief is None:
        w_belief = float(getattr(config, "activity_belief_weight", 0.9))

    if mix_mode is None:
        mix_mode = getattr(config, "activity_mix_mode", "weighted_or")
   
    if score_tau is None:
        score_tau = float(getattr(config, "activity_score_tau", 0.5))

    # --- per-fiber strength (boolean maps) ---
    def _strength(mu, Sig, mu_thr, tr_thr):
        mu = np.asarray(mu); Sig = np.asarray(Sig)
        if mu.shape[:2] != (H, W):  mu = resize_nn(mu, (H, W))
        if Sig.shape[:2] != (H, W): Sig = resize_nn(Sig, (H, W))
        mu_mag = np.sqrt((mu**2).sum(-1)) if mu.ndim == 3 else np.abs(mu).astype(np.float32)
        trsig  = np.trace(Sig, axis1=-2, axis2=-1) if Sig.ndim == 4 else Sig.astype(np.float32)
        return (mu_mag > float(mu_thr)) | (trsig > float(tr_thr))

    b = _strength(mu_q, Sig_q, mu_tau, trsig_tau) if (mu_q is not None and Sig_q is not None) else None
    p = _strength(mu_p, Sig_p, mu_tau_p, trsig_tau_p) if (mu_p is not None and Sig_p is not None) else None

    # --- combine belief/model according to mix_mode ---
    if mix_mode == "model_only":
        act_core = p if p is not None else (b if b is not None else False)
    elif mix_mode == "belief_only":
        act_core = b if b is not None else (p if p is not None else False)
    elif mix_mode == "and":
        act_core = (b if b is not None else True) & (p if p is not None else True)
    elif mix_mode == "or":
        act_core = (b if b is not None else False) | (p if p is not None else False)
    else:
        # 'weighted_or': treat booleans as 0/1, threshold weighted sum
        b_f = b.astype(np.float32) if b is not None else 0.0
        p_f = p.astype(np.float32) if p is not None else 0.0
        score = w_model * p_f + w_belief * b_f
        act_core = (score >= float(score_tau))

    return m_ok & act_core


# --- add near other small utilities ---

import numpy as _np

def cover_ge2_mask(children, H: int, W: int, mask_tau: float) -> _np.ndarray:
    """Boolean mask: pixels covered by at least two children (m >= mask_tau)."""
    cover = _np.zeros((H, W), _np.int16)
    for ch in children:
        m = _np.asarray(getattr(ch, "mask", 0.0), _np.float32)
        cover += (m >= float(mask_tau)).astype(_np.int16)
    return (cover >= 2)

def clamp_to_multichild(proposal: _np.ndarray, children, H: int, W: int, mask_tau: float) -> _np.ndarray:
    """Clamp proposal to ≥2-child cover (belt & suspenders)."""
    prop = _np.asarray(proposal, _np.float32)
    return prop * cover_ge2_mask(children, H, W, mask_tau).astype(_np.float32)

def conservative_child_set_from_seed(children, seed_bool: _np.ndarray, *,
                                     mask_tau: float, min_overlap_px: int) -> list[int]:
    """Return sorted list of child ids that overlap the seed by at least min_overlap_px."""
    ids = []
    for ch in children:
        m = _np.asarray(getattr(ch, "mask", 0.0), _np.float32)
        ov_px = int(_np.logical_and(seed_bool, m >= float(mask_tau)).sum())
        if ov_px >= int(min_overlap_px):
            try:
                ids.append(int(getattr(ch, "id")))
            except Exception:
                pass
    return sorted(ids)





def ensure_hw(a, hw, reduce=None, dtype=np.float32):
    # No-op: trust standardization; just coerce dtype
    return np.asarray(a, dtype)


import numpy as np

def _label4(mask: np.ndarray, periodic: bool = False) -> np.ndarray:
    """
    4-connected component labeling with optional toroidal (periodic) wrap.
    Returns an int32 label image with labels in {0,1,2,...}, where 0 == background.
    - mask: boolean/0-1 array (H,W)
    - periodic=False: standard planar CC.
      periodic=True : toroidal CC: left<->right and top<->bottom edges are adjacent.
    """
    m = (np.asarray(mask) != 0)
    H, W = m.shape
    if H == 0 or W == 0:
        return np.zeros_like(m, dtype=np.int32)

    # Union-Find (Disjoint Set)
    N = H * W
    parent = np.arange(N, dtype=np.int32)
    rank = np.zeros(N, dtype=np.int16)

    # helpers
    def _idx(y, x): return y * W + x
    def _find(a):
        # path compression
        while parent[a] != a:
            parent[a] = parent[parent[a]]
            a = parent[a]
        return a
    def _union(a, b):
        ra, rb = _find(a), _find(b)
        if ra == rb:
            return
        if rank[ra] < rank[rb]:
            parent[ra] = rb
        elif rank[ra] > rank[rb]:
            parent[rb] = ra
        else:
            parent[rb] = ra
            rank[ra] += 1

    # First pass: planar unions (up, left) on foreground
    # (2-neighbor scan is sufficient to build 4-connectivity)
    for y in range(H):
        row = m[y]
        for x in range(W):
            if not row[x]:
                continue
            i = _idx(y, x)
            # left neighbor
            if x > 0 and row[x - 1]:
                _union(i, _idx(y, x - 1))
            # up neighbor
            if y > 0 and m[y - 1, x]:
                _union(i, _idx(y - 1, x))

    if periodic:
        # Horizontal wrap: connect (y,0) <-> (y,W-1) if both are foreground
        left_col = m[:, 0]
        right_col = m[:, W - 1]
        for y in range(H):
            if left_col[y] and right_col[y]:
                _union(_idx(y, 0), _idx(y, W - 1))

        # Vertical wrap: connect (0,x) <-> (H-1,x) if both are foreground
        top_row = m[0, :]
        bot_row = m[H - 1, :]
        for x in range(W):
            if top_row[x] and bot_row[x]:
                _union(_idx(0, x), _idx(H - 1, x))

    # Second pass: assign compact labels to foreground roots
    labels = np.zeros(N, dtype=np.int32)
    root_to_lbl = {}
    next_lbl = 1
    fg_idxs = np.flatnonzero(m.ravel())
    for i in fg_idxs:
        r = _find(i)
        lbl = root_to_lbl.get(r)
        if lbl is None:
            lbl = next_lbl
            root_to_lbl[r] = lbl
            next_lbl += 1
        labels[i] = lbl

    return labels.reshape(H, W)






#used for spawn
def _new_parent(pid, H, W, dtype, Kq, Kp, proposal):
    zeros3 = np.zeros((H, W, 3), dtype=dtype)
    eye_q = np.tile(np.eye(Kq, dtype=dtype), (H, W, 1, 1))
    eye_p = np.tile(np.eye(Kp, dtype=dtype), (H, W, 1, 1))
    P = Agent(
        id=pid, center=(0,0), radius=0.0, mask=np.zeros((H,W), dtype=dtype),
        mu_q_field=np.zeros((H,W,Kq), dtype=dtype), sigma_q_field=eye_q.copy(),
        mu_p_field=np.zeros((H,W,Kp), dtype=dtype), sigma_p_field=eye_p.copy(),
        phi=zeros3.copy(), phi_model=zeros3.copy(), neighbors=[]
    )
    P.level = 1
    P.birth_step = getattr(runtime_ctx, "global_step", 0)
    P.lambda_q_weight = 0.0; P.lambda_p_weight = 0.0
    P._region_proposal = np.clip(proposal, 0.0, 1.0).astype(dtype)
    P.emerged = False; P._prev_eval_mask = None
    P._emerge_on_cnt = 0; P._emerge_off_cnt = 0; P._core_map = None
    return P










#used all over....refactor suite to imp-lement automatically/consistently
def _as_parent_dict(obj):
    """
    Normalize parents -> {pid: Parent}. Accepts dict, list, iterable, or None.
    Uses the parent's .id if present; else falls back to enumerate index.
    """
    import collections.abc as _abc
    if obj is None:
        return {}
    if isinstance(obj, dict):
        return {int(getattr(p, "id", pid)): p for pid, p in obj.items()}
    if isinstance(obj, _abc.Iterable):
        return {int(getattr(p, "id", i)): p for i, p in enumerate(obj)}
    # Single parent object?
    return {int(getattr(obj, "id", 0)): obj}



def norm_active_regions(active_regions, shape_hw):
    """
    Normalize 'active_regions' to a list of boolean masks with shape (H, W).
    Back-compat semantics: if active_regions is None, empty, or a scalar bool,
    treat it as "whole frame" (one mask of all True).
    """
    import numpy as np
    H, W = shape_hw
    full = np.ones((H, W), dtype=bool)

    # None or empty => full frame
    if active_regions is None:
        return [full]

    # Allow simple truthy/falsy sentinels (True/False, 0-d np.bool_) => full frame
    if isinstance(active_regions, (bool, np.bool_)):
        return [full]
    if isinstance(active_regions, np.ndarray) and active_regions.shape == ():
        # 0-d scalar array (np.bool_, np.int64, etc.) -> full frame
        return [full]

    # List/tuple of regions (each may be mask or scalar)
    if isinstance(active_regions, (list, tuple)):
        regs = []
        for r in active_regions:
            # scalar entries => whole frame
            if isinstance(r, (bool, np.bool_)):
                if r:  # True -> include full; False -> include full (back-compat)
                    regs.append(full.copy())
                else:
                    regs.append(full.copy())
                continue
            arr = np.asarray(r, dtype=bool)
            if arr.shape == ():
                regs.append(full.copy())
                continue
            if arr.shape != (H, W):
                raise RuntimeError(f"active region shape {arr.shape} != {(H, W)}")
            regs.append(arr)
        return regs if regs else [full]

    # Single array mask
    m = np.asarray(active_regions, dtype=bool)
    if m.shape == ():
        return [full]
    if m.shape != (H, W):
        raise RuntimeError(f"active region shape {m.shape} != {(H, W)}")
    return [m]






# ---- alignment clustering -------------------------------------------------



# ---- child-set dedup (toroidal-aware) ------------------------------------
def dedup_peaks_by_childset(peaks, *, radius_px=3, j_thr=0.92, subset_thr=0.80,
                            H=None, W=None, per_x=False, per_y=False):
    kept, r2 = [], float(radius_px * radius_px)
    for pk in sorted(peaks or [], key=lambda d: -d.get("score", 0.0)):
        C  = set(pk.get("child_ids", ()))
        cy = float(pk.get("cy", 0.0)); cx = float(pk.get("cx", 0.0))
        replace_i = None; dup = False
        for i, q in enumerate(kept):
            hy = float(q.get("cy", 0.0)); hx = float(q.get("cx", 0.0))
            d2 = dist2_toroidal(cy, cx, hy, hx, H, W, per_y, per_x) if (H is not None and W is not None) else (cy-hy)**2 + (cx-hx)**2
            if d2 > r2: continue
            D = set(q.get("child_ids", ()))
            if not C and not D: near = True
            elif not C or not D: near = False
            else:
                inter = len(C & D)
                if inter == 0: near = False
                else:
                    j = inter / float(len(C | D))
                    sub = min(inter / float(len(C)), inter / float(len(D)))
                    near = (j >= float(j_thr)) or (sub >= float(subset_thr))
            if near:
                if float(pk.get("score", 0.0)) > float(q.get("score", 0.0)) or len(C) > len(D):
                    replace_i = i
                dup = True; break
        if dup and (replace_i is not None):
            kept[replace_i] = pk
        elif not dup:
            kept.append(pk)
    return kept




#==============================================
#
#              MATCH_OR_SPAWN HELPERS
#
#===============================================


# parent_utils.py  — spawn/match helper add-ons

def prepare_parent_match_state(parents_by_id, support_tau):
    """Precompute boolean supports and kid-sets for all existing parents."""
    import numpy as np
    exists_support = {int(pid): (np.asarray(P.mask, np.float32) > float(support_tau))
                      for pid, P in parents_by_id.items()}
    exists_kids    = {int(pid): set(getattr(P, "child_ids", ()))
                      for pid, P in parents_by_id.items()}
    return exists_support, exists_kids

def gate_and_seed_proposal(prop, *, H, W, local_tau, min_local_px,
                           agents, mask_tau_child, support_tau, min_seed_px):
    """Early local area gate → clamp to ≥2-child domain → seed boolean + size gate."""
    import numpy as np
    from parent_utils import clamp_to_multichild  # already defined here
    p = np.asarray(prop, np.float32)
    if p.shape[:2] != (H, W):
        raise RuntimeError(f"proposal shape {p.shape} != {(H, W)}")
    local_bool = (p > float(local_tau))
    if int(local_bool.sum()) < int(min_local_px):
        return None, "local"
    p = clamp_to_multichild(p, agents, H, W, float(mask_tau_child))
    seed_bool = (p > float(support_tau))
    seed_px   = int(seed_bool.sum())
    if seed_px < int(min_seed_px):
        return None, "seed"
    return (p, seed_bool, seed_px), None

def novelty_gate_ok(seed_bool, exists_support, *, H, W,
                    min_novel_px, min_novel_frac):
    """Require novel seed area not already covered by existing parents."""
    import numpy as np
    union_seed = np.zeros((H, W), np.bool_)
    for _pid, supp in (exists_support or {}).items():
        if supp is not None:
            union_seed |= np.asarray(supp, np.bool_)
    novel_bool = np.asarray(seed_bool, np.bool_) & (~union_seed)
    novel_px   = int(novel_bool.sum())
    seed_px    = int(np.asarray(seed_bool, np.bool_).sum())
    frac = (float(novel_px) / float(seed_px)) if seed_px > 0 else 0.0
    ok = (novel_px >= int(min_novel_px)) or (frac >= float(min_novel_frac))
    return ok, novel_px, frac

def continuity_match_pid(cy, cx, seed_bool, exists_support, *,
                         H, W, per_x, per_y, cont_r2, cont_iou_thr):
    """Find best continuity candidate within radius using IoU on seed."""
    from parent_utils import centroid_toroidal, dist2_toroidal, iou_bool
    cont = []
    for pid, supp in (exists_support or {}).items():
        py, px = centroid_toroidal(supp, H, W, per_y=per_y, per_x=per_x)
        if dist2_toroidal(cy, cx, py, px, H, W, per_y, per_x) <= float(cont_r2):
            iou_c = iou_bool(seed_bool, supp)
            if iou_c >= float(cont_iou_thr):
                cont.append((float(iou_c), int(pid)))
    if not cont:
        return None
    cont.sort(reverse=True)
    return cont[0]  # (iou, pid)

def match_score_for_parent(seed_bool, gkids_set, supp_bool, kids_set,
                           *, close, match_iou_thr, child_jac_thr):
    """Return tuple score or None. ‘close’ applies the continuity bias."""
    from parent_utils import iou_bool, jaccard_sets
    jac = jaccard_sets(gkids_set, kids_set)
    iou = iou_bool(seed_bool, supp_bool)
    if close and (jac >= float(child_jac_thr)):
        return (iou, jac + 1.0)  # tie-breaker bias when spatially close
    if (iou >= float(match_iou_thr)) and (jac >= float(child_jac_thr)):
        return (iou, jac)
    return None





# ---- toroidal geometry ----------------------------------------------------
def dist2_toroidal(y1, x1, y2, x2, H, W, per_y=False, per_x=False):
    dy = abs(float(y1) - float(y2))
    dx = abs(float(x1) - float(x2))
    if per_y: dy = min(dy, H - dy)
    if per_x: dx = min(dx, W - dx)
    return dy*dy + dx*dx

# --- robust toroidal centroid -------------------------------------------------
def centroid_toroidal(mask_bool, H=None, W=None, *, per_y=True, per_x=True):
    import numpy as np
    m = np.asarray(mask_bool, bool)
    h0, w0 = m.shape[:2]
    H = int(h0 if H is None else int(H))
    W = int(w0 if W is None else int(W))

    if not m.any():
        # empty: return center to avoid NaNs
        return float(h0 / 2.0), float(w0 / 2.0)

    yy, xx = np.nonzero(m)

    # x (columns)
    if per_x:
        theta = 2.0 * np.pi * (xx.astype(np.float64) / float(W))
        cx = float(np.angle(np.mean(np.exp(1j * theta)))) / (2.0 * np.pi) * W
        cx = (cx + W) % W  # wrap to [0,W)
    else:
        cx = float(xx.mean())

    # y (rows)
    if per_y:
        phi = 2.0 * np.pi * (yy.astype(np.float64) / float(H))
        cy = float(np.angle(np.mean(np.exp(1j * phi)))) / (2.0 * np.pi) * H
        cy = (cy + H) % H
    else:
        cy = float(yy.mean())

    return cy, cx


# --- append center, keyword-safe ---------------------------------------------
def append_center_from_mask(centers, mask_bool, pid, H=None, W=None, *, 
                            per_x=True, per_y=True, fallback=None):
    """
    Compute (cy,cx) toroidally for a boolean mask and append (pid, cy, cx).
    - per_x/per_y are keyword-only to avoid positional mixups.
    - H/W are optional; inferred from mask if None.
    - Falls back to provided center (or image center) if mask is empty.
    """
    import numpy as np
    m = np.asarray(mask_bool, bool)
    h0, w0 = m.shape[:2]
    H = int(h0 if H is None else int(H))
    W = int(w0 if W is None else int(W))

    if m.any():
        cy, cx = centroid_toroidal(m, H, W, per_y=per_y, per_x=per_x)
    else:
        if fallback is not None:
            cy, cx = map(float, fallback)
        else:
            cy, cx = float(h0 / 2.0), float(w0 / 2.0)

    centers.append((int(pid), float(cy), float(cx)))



def spawn_spacing_radius(allow_overlap, default_px):
    return 0 if bool(allow_overlap) else int(default_px)


#match_or spawn utils

def iou_bool(a, b):
    import numpy as np
    A = np.asarray(a, bool); B = np.asarray(b, bool)
    inter = int((A & B).sum()); union = int((A | B).sum())
    return (inter / float(max(1, union))) if union else 0.0

def jaccard_sets(A, B):
    if not A and not B: return 1.0
    if not A or not B:  return 0.0
    return len(A & B) / float(len(A | B))

def child_union_for_ids(agents, child_ids, H, W, eps=0.10):
    import numpy as np
    from parent_utils import ensure_hw
    U = np.zeros((H, W), bool)
    for cid in child_ids:
        try: C = agents[cid]
        except Exception: continue
        U |= (ensure_hw(getattr(C, "mask", 0.0), (H, W)) > float(eps))
    return U

def proposal_overlaps_children(local_bool, child_union, min_px=6, min_frac=0.10):
    import numpy as np
    L = np.asarray(local_bool, bool); U = np.asarray(child_union, bool)
    ov = int((L & U).sum()); area = int(L.sum())
    return (ov >= int(min_px)) and (ov / float(max(1, area)) >= float(min_frac)), ov




def respect_spawn_spacing(cy, cx, gkids_set, chosen_centers, exists_kids,
                          H, W, per_x, per_y, *, min_interseed_px, jac_thr, subset_thr):
    from parent_utils import dist2_toroidal
    R2 = float(max(1, min_interseed_px)) ** 2
    for (py, px, pid_near) in (chosen_centers or []):
        if dist2_toroidal(cy, cx, py, px, H, W, per_y, per_x) >= R2:
            continue
        kids_near = exists_kids.get(pid_near, set())
        inter = len(kids_near & gkids_set)
        if inter == 0: 
            continue
        j   = inter / float(len(kids_near | gkids_set))
        sub = max(inter / float(len(kids_near or {1})),
                  inter / float(len(gkids_set or {1})))
        if (j >= float(jac_thr)) or (sub >= float(subset_thr)):
            return False
    return True


def _pbc_delta(a, b, size: int) -> int:
    """Smallest signed delta on a torus of length `size`."""
    d = int(a) - int(b)
    if size <= 0: return d
    d %= size
    if d > size // 2:
        d -= size
    elif d < -size // 2:
        d += size
    return d

def pbc_distance(cy1, cx1, cy2, cx2, H, W) -> float:
    """Toroidal Euclidean distance."""
    dy = _pbc_delta(cy1, cy2, H)
    dx = _pbc_delta(cx1, cx2, W)
    return float((dy * dy + dx * dx) ** 0.5)

def fast_iou_bool(a, b) -> float:
    """IoU for boolean masks; returns 0.0 if both empty."""
    inter = int((a & b).sum())
    if inter == 0:
        return 0.0
    denom = int((a | b).sum())
    return inter / float(max(1, denom))

# --- grid bucketing ----------------------------------------------------------
def grid_bucket_points(items, H, W, radius_px, get_xy):
    """
    Bucket items by (cy,cx) onto a toroidal grid with cell size ≈ radius_px.
    Returns: dict[(gy,gx)] -> [indices], and (Gh,Gw,cell_h,cell_w).
    """
    import math
    cell = max(1, int(radius_px))
    Gh = max(1, H // cell)
    Gw = max(1, W // cell)
    buckets = {}
    for i, it in enumerate(items):
        cy, cx = get_xy(it)
        gy = int(cy) // cell
        gx = int(cx) // cell
        gy %= Gh; gx %= Gw
        buckets.setdefault((gy, gx), []).append(i)
    return buckets, (Gh, Gw, cell, cell)

def iter_neighbor_cells(gy, gx, Gh, Gw):
    """Yield this cell and its 8 toroidal neighbors."""
    for dy in (-1, 0, 1):
        for dx in (-1, 0, 1):
            yy = (gy + dy) % Gh
            xx = (gx + dx) % Gw
            yield (yy, xx)
