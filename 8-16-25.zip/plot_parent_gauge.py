# -*- coding: utf-8 -*-
"""
Created on Tue Aug 12 17:06:54 2025

@author: chris and christine
"""

# tools/meta_parent_snapshot.py
import os
import numpy as np
import matplotlib.pyplot as plt

# ---------- SNAPSHOT ----------


# parent_snapshot_plotter.py

import os, glob
import numpy as np
import matplotlib.pyplot as plt

def _mask_outline(mask: np.ndarray) -> np.ndarray:
    """Return boolean outline of mask."""
    try:
        from scipy.ndimage import binary_erosion
        return np.logical_and(mask, ~binary_erosion(mask))
    except Exception:
        # super simple fallback
        core = mask.astype(bool)
        up    = np.pad(core[1: , : ], ((0,1),(0,0)))
        down  = np.pad(core[:-1, : ], ((1,0),(0,0)))
        left  = np.pad(core[: , 1: ], ((0,0),(0,1)))
        right = np.pad(core[: , :-1], ((0,0),(1,0)))
        return core & ~(up & down & left & right)

def _save_field(img, outline, title, outpath):
    plt.figure()
    plt.imshow(img, origin="lower", cmap="viridis")
    if outline is not None and outline.any():
        yy, xx = np.where(outline)
        if len(xx) > 0:
            plt.scatter(xx, yy, s=1, c="white", linewidths=0.2)
    plt.title(title)
    plt.colorbar()
    plt.tight_layout()
    os.makedirs(os.path.dirname(outpath), exist_ok=True)
    plt.savefig(outpath, dpi=160)
    plt.close()

def _frob_norm(mat):
    # mat: (..., a, b) → frobenius norm over last two axes
    return np.sqrt(np.sum(mat * mat, axis=(-2, -1)))

def _trace(mat):
    # mat: (..., K, K)
    return np.trace(mat, axis1=-2, axis2=-1)

def _safe_logdet(mat, eps=1e-6):
    # SPD-ish logdet per pixel; clamps via eps on eigenvalues
    H, W, K, _ = mat.shape
    flat = mat.reshape(-1, K, K)
    out = np.empty((H*W,), dtype=np.float32)
    for i, M in enumerate(flat):
        # symmetrize a touch (numerical)
        Ms = 0.5*(M + M.T)
        try:
            s = np.linalg.slogdet(Ms)
            if s[0] > 0:
                out[i] = float(s[1])
            else:
                # fallback via eigen clamp
                w, _ = np.linalg.eigh(Ms)
                w = np.clip(w, eps, None)
                out[i] = float(np.sum(np.log(w)))
        except Exception:
            w, _ = np.linalg.eigh(Ms)
            w = np.clip(w, eps, None)
            out[i] = float(np.sum(np.log(w)))
    return out.reshape(H, W)

def plot_parent_everything_from_npz(npz_path: str, outdir: str = "parent_plots", mask_thresh: float = 0.3) -> None:
    """
    Load the NPZ written by your snapshot function and dump per-parent PNGs:
      - gauge:     ‖φ‖, ‖φ̃‖
      - belief:    ‖μ_q‖, tr(Σ_q), logdet(Σ_q)
      - model:     ‖μ_p‖, tr(Σ_p), logdet(Σ_p)
      - morphisms: ‖Φ‖_F, ‖Φ̃‖_F  (Frobenius norms)
    Also writes a single montage per parent.
    """
    if not os.path.exists(npz_path):
        raise FileNotFoundError(npz_path)

    data = np.load(npz_path)
    # Required
    masks      = data["masks"]          # (N,H,W)
    phi        = data["phi"]            # (N,H,W,3)
    phi_model  = data["phi_model"]      # (N,H,W,3)
    parent_ids = data.get("parent_ids", np.arange(masks.shape[0], dtype=np.int32))

    # Optional (filled with zeros if absent)
    def _opt(name, shape_like=None):
        if name in data:
            return data[name]
        if shape_like is None:
            return None
        return np.zeros_like(shape_like)

    mu_q       = _opt("mu_q_field")
    sigma_q    = _opt("sigma_q_field")
    mu_p       = _opt("mu_p_field")
    sigma_p    = _opt("sigma_p_field")
    Phi        = _opt("bundle_morphism_q_to_p")
    Phi_tilde  = _opt("bundle_morphism_p_to_q")

    os.makedirs(outdir, exist_ok=True)

    N, H, W = masks.shape
    for i in range(N):
        pid = int(parent_ids[i])
        base = os.path.join(outdir, f"parent_{pid:03d}")

        m = masks[i] > mask_thresh
        outline = _mask_outline(m)

        # --- Gauges ---
        phi_norm = np.linalg.norm(phi[i], axis=-1)                    # (H,W)
        phim_norm = np.linalg.norm(phi_model[i], axis=-1)             # (H,W)

        _save_field(phi_norm, outline,  f"Parent {pid}  ‖φ‖",   base + "_phi_norm.png")
        _save_field(phim_norm, outline, f"Parent {pid}  ‖φ̃‖",  base + "_phi_tilde_norm.png")

        # --- Belief / Model stats (if present) ---
        if mu_q is not None and mu_q.size:
            muq_norm = np.linalg.norm(mu_q[i], axis=-1)
            _save_field(muq_norm, outline, f"Parent {pid}  ‖μ_q‖", base + "_mu_q_norm.png")
        if mu_p is not None and mu_p.size:
            mup_norm = np.linalg.norm(mu_p[i], axis=-1)
            _save_field(mup_norm, outline, f"Parent {pid}  ‖μ_p‖", base + "_mu_p_norm.png")

        if sigma_q is not None and sigma_q.size:
            tr_q   = _trace(sigma_q[i])
            logd_q = _safe_logdet(sigma_q[i])
            _save_field(tr_q,   outline, f"Parent {pid}  tr(Σ_q)",   base + "_sigma_q_trace.png")
            _save_field(logd_q, outline, f"Parent {pid}  logdet(Σ_q)", base + "_sigma_q_logdet.png")

        if sigma_p is not None and sigma_p.size:
            tr_p   = _trace(sigma_p[i])
            logd_p = _safe_logdet(sigma_p[i])
            _save_field(tr_p,   outline, f"Parent {pid}  tr(Σ_p)",   base + "_sigma_p_trace.png")
            _save_field(logd_p, outline, f"Parent {pid}  logdet(Σ_p)", base + "_sigma_p_logdet.png")

        # --- Morphisms (Frobenius norms) ---
        if Phi is not None and Phi.size:
            frob_phi = _frob_norm(Phi[i])
            _save_field(frob_phi, outline, f"Parent {pid}  ‖Φ‖_F", base + "_Phi_frob.png")
        if Phi_tilde is not None and Phi_tilde.size:
            frob_phit = _frob_norm(Phi_tilde[i])
            _save_field(frob_phit, outline, f"Parent {pid}  ‖Φ̃‖_F", base + "_Phi_tilde_frob.png")

    print(f"[OK] wrote plots to {os.path.abspath(outdir)}")


# ---------- tiny demo / usage ----------
if __name__ == "__main__":
   
    plot_parent_everything_from_npz("checkpoints/parents_end.npz", outdir="parent_plots")