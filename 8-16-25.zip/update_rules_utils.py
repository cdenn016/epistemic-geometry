# -*- coding: utf-8 -*-
"""
Created on Tue Aug 12 20:10:51 2025

@author: chris and christine
"""

import numpy as np
from preprocess_utils import build_all_omega_caches, build_all_lambda_caches, preprocess_all_agents
from runtime_context import _collect_by_ids
from gaussian_core import (
    _prep_A,
    directed_kl_weight_after_transport,
    geometric_blend,
    apply_evidence_modulators,
    curvature_boltzmann_from_children,
)



def _assign_children_to_parents(
    children,
    parents_by_id,
    *,
    eps=1e-3,
    tau=0.30,
    temp=0.25,
    max_parents_per_child=2,
    core_tau=None,                 # absolute floor on parent core
    core_tau_rel=0.50,             # relative to parent.max()
    core_dilate_px=1,              # small dilation helps newborns
    newborn_bootstrap_steps=2,     # relax core τ for very young parents
    allow_unassigned=True,
    agreement_map=None,            # e.g. runtime_ctx.Aq_agg
    use_agreement=None,            # if None → read from config
    agree_weight=None,             # S *= A**agree_weight
    debug=False,
):
    import numpy as np
    import config
    try:
        from scipy.ndimage import binary_dilation
    except Exception:
        binary_dilation = None

    from parent_utils import resize_nn  # unified NN resizer used across suite

    Ps = list(parents_by_id.values())
    Pn = len(Ps); I = len(children)

    # trivial exits
    if Pn == 0 or I == 0:
        for ch in children:
            setattr(ch, "labels", {}); setattr(ch, "parent_id", -1)
        for P in Ps:
            P.child_weights = {}; P.child_ids = ()
        return

    # shapes
    H, W = np.asarray(children[0].mask).shape[:2]

    # agreement defaults
    if use_agreement is None:
        use_agreement = bool(getattr(config, "parent_assign_use_agreement", False))
    if agree_weight is None:
        agree_weight = float(getattr(config, "parent_assign_agree_weight", 1.0))

    # child boolean masks (already standardized in _pre_light)
    Cmb = [(np.asarray(ch.mask, np.float32) > float(eps)) for ch in children]

    # parent masks array (sanitize once)
    Pmasks = [np.nan_to_num(np.asarray(P.mask, np.float32), nan=0.0, posinf=0.0, neginf=0.0) for P in Ps]

    abs_core = float(core_tau if core_tau is not None
                     else getattr(config, "parent_growth_core_tau", 0.20))
    rel_core = float(core_tau_rel)

    # parent cores
    Pcore = []
    for idx, pm in enumerate(Pmasks):
        mmax = float(pm.max()) if pm.size else 0.0
        thr  = max(abs_core, rel_core * mmax)
        age  = int(getattr(Ps[idx], "_age", 0) or 0)
        if age < int(newborn_bootstrap_steps):
            thr *= 0.6  # relax for newborns
        core = (pm > thr)
        if core_dilate_px and binary_dilation is not None and core.any():
            core = binary_dilation(core, iterations=int(core_dilate_px))
        Pcore.append(core)

    # agreement map (optional)
    A_map = None
    if use_agreement and (agreement_map is not None):
        A_map = np.asarray(agreement_map, np.float32)
        if A_map.shape[:2] != (H, W):
            try:
                A_map = resize_nn(A_map, (H, W)).astype(np.float32)
            except Exception:
                A_map = None
        if A_map is not None:
            A_map = np.clip(np.nan_to_num(A_map, nan=0.0, posinf=1.0, neginf=0.0), 0.0, 1.0)

    # similarity matrix
    S = np.full((I, Pn), -np.inf, np.float32)
    for i, cm in enumerate(Cmb):
        if not cm.any():
            continue
        for p, core in enumerate(Pcore):
            if not core.any():
                continue
            ov = (cm & core)
            inter = int(ov.sum())
            if inter == 0:
                continue
            union = int((cm | core).sum())
            base = float(inter) / float(max(1, union))  # IoU on core

            if A_map is not None and ov.any():
                a = float(np.nanmean(A_map[ov]))
                if not np.isfinite(a): a = 0.0
                a = min(1.0, max(0.0, a))
                if agree_weight > 0.0:
                    base *= (a ** float(agree_weight))

            S[i, p] = base

    # threshold
    S[S < float(tau)] = -np.inf

    # top-k
    if max_parents_per_child:
        k = int(max_parents_per_child)
        for i in range(I):
            fin = np.isfinite(S[i])
            if fin.sum() > k:
                idxs = np.where(fin)[0][np.argsort(-S[i, fin])[:k]]
                row = np.full(Pn, -np.inf, np.float32); row[idxs] = S[i, idxs]
                S[i] = row

    # softmax rows that have any finite
    W = np.zeros((I, Pn), np.float32)
    finite_row = np.isfinite(S).any(axis=1)
    if finite_row.any():
        X = S[finite_row] / max(1e-6, float(temp))
        X -= np.max(X, axis=1, keepdims=True)
        W_fin = np.exp(X, dtype=np.float32)
        W_fin /= np.maximum(W_fin.sum(axis=1, keepdims=True), 1e-6)
        W[finite_row] = W_fin

    # optional fallback if disallowing unassigned: pick best raw parent IoU
    if not allow_unassigned:
        for i in range(I):
            if not np.isfinite(S[i]).any():
                cm = Cmb[i]
                # use parent masks (not cores) for a lenient fallback
                best_p, best_iou = -1, -1.0
                for p, pm in enumerate(Pmasks):
                    union = int((cm | (pm > 0)).sum())
                    if union == 0: continue
                    inter = int((cm & (pm > 0)).sum())
                    iou = float(inter) / float(union)
                    if iou > best_iou:
                        best_iou, best_p = iou, p
                if best_p >= 0 and best_iou > 0.0:
                    W[i, best_p] = 1.0  # hard-assign best

    # write back to children
    for i, ch in enumerate(children):
        labs = {int(getattr(Ps[p], "id", p)): float(W[i, p])
                for p in range(Pn) if W[i, p] > 0.0}
        ch.labels = labs
        ch.parent_id = int(max(labs, key=labs.get)) if labs else -1

    # write back to parents
    for p, P in enumerate(Ps):
        weights = {}
        ids = []
        for i, ch in enumerate(children):
            w = float(W[i, p])
            if w > 0.0:
                cid = int(getattr(ch, "id", i))
                weights[cid] = w; ids.append(cid)
        P.child_weights = weights
        P.child_ids = tuple(sorted(ids))

    if debug:
        for p, P in enumerate(Ps):
            wsum = float(sum((P.child_weights or {}).values()))
            print(f"[ASSIGN] P{getattr(P,'id',p)} kids={len(P.child_ids)} wsum={wsum:.3g}")


  
def assign_parent_masks_from_alignment(ctx, children,
                                       generators_q, generators_p,
                                       *,
                                       mode="max",                # "max" or "mean"
                                       mask_tau=0.10,
                                       tau_q=None, tau_p=None, alpha=0.5,
                                       agree_map=None, agree_power=1.0,
                                       clamp_to_union=True,
                                       floor_eps=1e-6,
                                       min_pair_px=8,
                                       kl_cap=None,
                                       pnorm=99.0):              # percentile norm inside domain
    """
    Gauge-covariant parent mask assignment (pure evidence, no dilation).
    - Lives strictly on multi-child overlap (>=2 kids above mask_tau).
    - Uses assigned_child_ids if available (>=2), else falls back to child_ids ∪ assigned.
    - Transport: Ω_{ij}(x) from caches when available:
          Ω_{ij}^q(x) = Ci.Omega_cache[Cj.id][y,x]
          Ω_{ij}^p(x) = Ci.Omega_tilde_cache[Cj.id][y,x]
      If missing, fall back to cached exp fields: exp(φ_i) @ exp(-φ_j) (and model fiber).
      On last resort only, compute exp at the pixel.
    - Evidence per pair (i,j) at pixel x:
          w_ij(x) = 1{m_i>=τ}·1{m_j>=τ} · m_i(x)·m_j(x) · exp(-[(1-α)·DQ + α·DP])
      where DQ = KL(q_i || T_{j→i}(q_j)),   DP = KL(p_i || T_{j→i}(p_j)).
    - Aggregate across pairs via max or mean, clamp to children union if requested, then
      percentile-normalize within the admissible domain and clip to [0,1].
    """
    import numpy as np
    from numerical_utils import safe_inv
    from omega import exp_lie_algebra_irrep

    # ---- temps / caps ----
    try:
        import config
        if kl_cap is None:
            kl_cap = float(getattr(config, "signal_kl_cap", 10.0))
        if tau_q is None:
            tau_q = float(getattr(config, "tau_align_q", 0.45))
        if tau_p is None:
            tau_p = float(getattr(config, "tau_align_p", 0.45))
    except Exception:
        kl_cap = 10.0 if kl_cap is None else kl_cap
        tau_q = 0.45 if tau_q is None else tau_q
        tau_p = 0.45 if tau_p is None else tau_p

    parents = getattr(ctx, "parents_by_region", {}) or {}
    if not parents or not children:
        return

    H, W = np.asarray(children[0].mask, dtype=np.float32).shape[:2]

    # optional agreement prior A(x) ∈ [0,1]
    A = None
    if agree_map is not None:
        A = np.asarray(agree_map, np.float32)
        if A.shape != (H, W):
            from parent_utils import resize_nn
            A = resize_nn(A, (H, W))
        A = np.clip(np.nan_to_num(A, nan=1.0, posinf=1.0, neginf=0.0), 0.0, 1.0)

    # helpers
    def _mask_gate(m):
        # keep graded weight but zero out below τ
        g = (m >= mask_tau).astype(np.float32)
        return g * np.asarray(m, np.float32)

    def _support_bool(m):
        # boolean gate for "present" above τ
        return (np.asarray(m, np.float32) >= mask_tau)

    def _gaussian_kl(mu1, S1, mu2, S2, cap=10.0, eps=1e-8):
        # KL( N(mu1,S1) || N(mu2,S2) ) ; numerically safe, returns float
        d = mu1.shape[-1]
        S2i = safe_inv(S2, eps=eps)
        diff = (mu2 - mu1)[..., None]  # (d,1)
        t = float(np.trace(S2i @ S1))
        md = float((diff.T @ S2i @ diff).squeeze())
        sign1, logdet1 = np.linalg.slogdet(S1)
        sign2, logdet2 = np.linalg.slogdet(S2)
        if (sign1 <= 0) or (sign2 <= 0) or not np.isfinite(md) or not np.isfinite(t):
            return np.inf
        kl = 0.5 * (t + md - d + (logdet2 - logdet1))
        if cap < np.inf:
            kl = min(kl, cap)
        if not np.isfinite(kl) or kl < 0:
            return np.inf
        return kl

    # map id->child once to avoid repeated scans
    _by_id = {int(ch.id): ch for ch in children}

    # small accessors for Ω fields (prefer cached Ω, else exp-cached products, else exp on the fly)
    def _get_O_fields(Ci, Cj):
        """Return tuple (Oq_field, Op_field) each shaped (H,W,K,K) or None if unavailable."""
        Oq = getattr(Ci, "Omega_cache", {}).get(int(getattr(Cj, "id", -1)))
        Op = getattr(Ci, "Omega_tilde_cache", {}).get(int(getattr(Cj, "id", -1)))

        ok_q = (Oq is not None) and (getattr(Oq, "shape", None) is not None) and (Oq.shape[:2] == (H, W))
        ok_p = (Op is not None) and (getattr(Op, "shape", None) is not None) and (Op.shape[:2] == (H, W))

        if ok_q and ok_p:
            return Oq, Op

        # try to build from cached exp fields (fast einsums over full field)
        Ei_q   = getattr(Ci, "_exp_phi", None)
        Ej_qn  = getattr(Cj, "_exp_neg_phi", None)
        Ei_p   = getattr(Ci, "_exp_phi_model", None)
        Ej_pn  = getattr(Cj, "_exp_neg_phi_model", None)

        if (not ok_q) and (Ei_q is not None) and (Ej_qn is not None) and Ei_q.shape[:2] == (H, W) and Ej_qn.shape[:2] == (H, W):
            Oq = np.einsum("...ik,...kj->...ij", Ei_q, Ej_qn, optimize=True)
            ok_q = True
        if (not ok_p) and (Ei_p is not None) and (Ej_pn is not None) and Ei_p.shape[:2] == (H, W) and Ej_pn.shape[:2] == (H, W):
            Op = np.einsum("...ik,...kj->...ij", Ei_p, Ej_pn, optimize=True)
            ok_p = True

        return (Oq if ok_q else None), (Op if ok_p else None)

    for rid, P in parents.items():
        base_ids = list(getattr(P, "child_ids", []) or [])
        assigned_ids = list(getattr(P, "assigned_child_ids", []) or [])

        # --- choose effective coalition per step ---
        eff_ids = sorted(set(assigned_ids) | set(base_ids))
        if len(assigned_ids) >= 2:
            eff_ids = sorted(set(assigned_ids))  # prefer assigned if valid

        if len(eff_ids) < 2:
            P.mask = np.zeros((H, W), np.float32)
            P.emerged = False
            continue

        K = []
        for k in eff_ids:
            ch = _by_id.get(int(k), None)
            if ch is not None:
                K.append(ch)
        if len(K) < 2:
            P.mask = np.zeros((H, W), np.float32)
            P.emerged = False
            continue

        # gates and (optional) union clamp
        masks_gated  = [_mask_gate(ch.mask) for ch in K]
        present_bool = [_support_bool(ch.mask) for ch in K]

        union_gate = None
        if clamp_to_union:
            union_gate = np.zeros((H, W), np.float32)
            for pb in present_bool:
                union_gate = np.maximum(union_gate, pb.astype(np.float32))

        # admissible domain: at least two kids present (≥ τ)
        present_stack = np.stack(present_bool, axis=0).astype(np.int16)  # (k,H,W)
        domain = (present_stack.sum(axis=0) >= 2)
        if not np.any(domain):
            P.mask = np.zeros((H, W), np.float32)
            P.emerged = False
            continue

        acc = np.zeros((H, W), np.float32)
        if mode == "mean":
            cnt = np.zeros((H, W), np.float32)

                # ---- pair loop (use cached helper; no inline KL math) ----
        klen = len(K)
        for a in range(klen):
            for b in range(a + 1, klen):
                Ci, Cj = K[a], K[b]
                mi, mj = masks_gated[a], masks_gated[b]

                support = (present_bool[a] & present_bool[b] & domain)
                if support.sum() < min_pair_px:
                    continue

                # weights on overlap using cached Ω / exp fields
                wq = directed_kl_weight_after_transport(
                    Ci, Cj,
                    Ci.mu_q_field, Ci.sigma_q_field,
                    Cj.mu_q_field, Cj.sigma_q_field,
                    fiber="q", H=H, W=W, K=Ci.mu_q_field.shape[-1],
                    ov=support, tau=max(1e-12, float(tau_q)),
                    assume_diag_is_stddev=True, debug=False
                )
                wp = directed_kl_weight_after_transport(
                    Ci, Cj,
                    Ci.mu_p_field, Ci.sigma_p_field,
                    Cj.mu_p_field, Cj.sigma_p_field,
                    fiber="p", H=H, W=W, K=Ci.mu_p_field.shape[-1],
                    ov=support, tau=max(1e-12, float(tau_p)),
                    assume_diag_is_stddev=True, debug=False
                )

                # blend q/p, gate by masks and optional agreement prior
                w = (wq ** (1.0 - float(alpha))) * (wp ** float(alpha))
                w *= (mi * mj)  # stays zero outside both supports
                if A is not None:
                    w *= (A ** float(agree_power))

                # accumulate
                if mode == "max":
                    acc = np.maximum(acc, w)
                else:
                    acc += w
                    # count only positive contributions
                    cnt += (w > 0).astype(np.float32)

        if mode == "mean":
            acc = acc / (cnt + floor_eps)

        # clamp to union (optional), and to domain (always)
        if union_gate is not None:
            acc *= union_gate
        acc *= domain.astype(np.float32)

        # percentile normalization inside the domain for dynamic range
        dom_vals = acc[domain]
        if dom_vals.size == 0 or np.all(dom_vals <= floor_eps):
            P.mask = np.zeros((H, W), np.float32)
            P.emerged = False
            continue

        scale = np.percentile(dom_vals, pnorm)
        if not np.isfinite(scale) or scale <= floor_eps:
            scale = float(dom_vals.max())
        if scale <= floor_eps:
            P.mask = np.zeros((H, W), np.float32)
            P.emerged = False
            continue

        acc = acc / scale
        acc = np.clip(np.nan_to_num(acc, nan=0.0, posinf=1.0, neginf=0.0), 0.0, 1.0)

        # defensive: enforce ≥2-kid domain again
        acc *= domain.astype(np.float32)

        P.mask = acc.astype(np.float32)
        P.emerged = True




def build_alignment_aggregates(runtime_ctx, children, *, kl_cap=10.0):
    """
    Aggregates per-child caches into step-level fields on runtime_ctx:
      KLq_agg, KLp_agg, Aq_agg, Ap_agg  (H,W)

    Priority (per child, per fiber):
      1) Agreement cache if present (spawn_A_final for q; optional model A for p)
      2) Softmin KL cache (spawn_softmin_kl_q/p)
      3) Fallback blended/cached KL (cached_alignment_kl / cached_model_alignment_kl)

    Aggregation occurs in AGREEMENT space; KL_agg is computed back from the agg agreement.
    """
    import numpy as np
    try:
        import config
        tau_q = float(getattr(config, "tau_align_q", 0.45))
        tau_p = float(getattr(config, "tau_align_p", 0.45))
        kl_cap = float(getattr(config, "signal_kl_cap", kl_cap))
        reduce_mode = str(getattr(config, "agg_reduce_mode", "mean"))  # "mean" | "max" | "p80" etc.
        prefer_agreement_cache = bool(getattr(config, "agg_prefer_agreement_cache", True))
    except Exception:
        tau_q = tau_p = 0.45
        reduce_mode = "mean"
        prefer_agreement_cache = True

    if not children:
        runtime_ctx.KLq_agg = runtime_ctx.KLp_agg = None
        runtime_ctx.Aq_agg  = runtime_ctx.Ap_agg  = None
        return

    H, W = children[0].mask.shape[:2]

    def _resize_to_hw(a):
        a = np.asarray(a, np.float32)
        if a.shape == (H, W): return a
        # minimal NN-like adjust without deps
        if a.shape[0] >= H and a.shape[1] >= W:
            return a[:H, :W].astype(np.float32, copy=False)
        py, px = max(0, H - a.shape[0]), max(0, W - a.shape[1])
        return np.pad(a, ((0, py), (0, px)), mode="edge")[:H, :W].astype(np.float32, copy=False)

    # Collect per-child AGREEMENT for each fiber if possible, else collect KL
    Aq_list, KLq_list = [], []
    Ap_list, KLp_list = [], []

    for ch in children:
        # ----- q fiber -----
        A_q = getattr(ch, "spawn_A_final", None) if prefer_agreement_cache else None
        if A_q is not None:
            Aq_list.append(np.clip(_resize_to_hw(A_q), 0.0, 1.0))
        else:
            # fall back to KL caches
            KLq = getattr(ch, "spawn_softmin_kl_q", None)
            if KLq is None:
                KLq = getattr(ch, "cached_alignment_kl", None)
            if KLq is not None:
                KLq = np.clip(_resize_to_hw(KLq), 0.0, kl_cap)
                KLq_list.append(KLq)

        # ----- p fiber -----
        # If you ever cache a model-side agreement (e.g., ch.spawn_A_final_p), prefer it here
        A_p = getattr(ch, "spawn_A_final_p", None) if prefer_agreement_cache else None
        if A_p is not None:
            Ap_list.append(np.clip(_resize_to_hw(A_p), 0.0, 1.0))
        else:
            KLp = getattr(ch, "spawn_softmin_kl_p", None)
            if KLp is None:
                KLp = getattr(ch, "cached_model_alignment_kl", None)
            if KLp is not None:
                KLp = np.clip(_resize_to_hw(KLp), 0.0, kl_cap)
                KLp_list.append(KLp)

    def _reduce_agree(A_list, KL_list, tau):
        """
        Prefer agreements (A_list). If absent, convert KL_list to agreements, then reduce.
        Returns (KL_eff, A_agg) or (None, None) if no inputs.
        """
        if A_list:
            A_stack = np.stack(A_list, axis=0)  # (C,H,W)
        elif KL_list:
            KL_stack = np.stack(KL_list, axis=0)
            A_stack = np.exp(-KL_stack / max(tau, 1e-8)).astype(np.float32)
        else:
            return None, None

        if reduce_mode == "mean":
            A_agg = np.mean(A_stack, axis=0)
        elif reduce_mode == "max":
            A_agg = np.max(A_stack, axis=0)
        elif reduce_mode.startswith("p"):
            try:
                q = float(reduce_mode[1:])
            except Exception:
                q = 80.0
            A_agg = np.percentile(A_stack, q, axis=0)
        else:
            A_agg = np.mean(A_stack, axis=0)

        A_agg = np.clip(np.nan_to_num(A_agg, nan=0.0, posinf=1.0, neginf=0.0), 0.0, 1.0)
        KL_eff = (-max(tau, 1e-8) * np.log(np.maximum(A_agg, 1e-20))).astype(np.float32)
        KL_eff = np.clip(KL_eff, 0.0, kl_cap)
        return KL_eff, A_agg

    KLq_agg, Aq_agg = _reduce_agree(Aq_list, KLq_list, tau_q)
    KLp_agg, Ap_agg = _reduce_agree(Ap_list, KLp_list, tau_p)

    runtime_ctx.KLq_agg = KLq_agg
    runtime_ctx.KLp_agg = KLp_agg
    runtime_ctx.Aq_agg  = Aq_agg
    runtime_ctx.Ap_agg  = Ap_agg





# --- spawn cache refresh policy --------------------------------------------
def should_refresh_spawn_cache(child, runtime_ctx, *, mask_tol=1e-8) -> bool:
    """
    Return True if child's spawn caches should be recomputed this step.
    Triggers:
      - child marked dirty (fields or KL) OR
      - child's mask changed meaningfully vs. last snapshot OR
      - transport cache_version changed since last spawn build OR
      - child carries no spawn caches yet
    """
    import numpy as np
    if getattr(child, "spawn_A_final", None) is None:
        return True
    if getattr(child, "_dirty_fields", False) or getattr(child, "_dirty_kl", False):
        return True

    # mask delta check (cheap)
    try:
        prev = getattr(child, "_mask_prev_for_spawn", None)
        if prev is None:
            return True
        now = np.asarray(child.mask, np.float32)
        if now.shape != prev.shape:
            return True
        if float(np.max(np.abs(now - prev))) > float(mask_tol):
            return True
    except Exception:
        return True

    # global transport cache version bump (parents/children changed)
    built_ver = int(getattr(child, "_spawn_cache_built_at_cachever", -1))
    glob_ver  = int(getattr(runtime_ctx, "cache_version", 0))
    return (built_ver != glob_ver)


def ensure_spawn_alignment_caches(children, agents, runtime_ctx, *,
                                  generators_q, generators_p,
                                  use_cover_weight=True, debug=False):
    """
    Build spawn caches ONLY for children that need it (policy above).
    Reuses any prebuilt Ω caches or exp(φ) caches; falls back if missing.
    """
    # prefer Ω caches; if missing, try to (re)build them *just for children*
    from update_rules_utils import build_all_omega_caches
    build_all_omega_caches(children, strict=False, debug=False)

    need = [ch for ch in children if should_refresh_spawn_cache(ch, runtime_ctx)]
    if not need:
        return

    # call the existing builder but let it leverage cached transports/exp
    refresh_spawn_alignment_caches(
        need, agents,
        tau_q=getattr(__import__("config"), "tau_align_q", 0.45),
        tau_p=getattr(__import__("config"), "tau_align_p", 0.45),
        alpha=getattr(__import__("config"), "blend_qp_alpha", 0.50),
        sm_tau=getattr(__import__("config"), "spawn_softmin_tau", 0.40),
        kl_cap=getattr(__import__("config"), "signal_kl_cap", 10.0),
        eps=getattr(__import__("config"), "support_cutoff_eps", 1e-4),
        use_cover_weight=bool(use_cover_weight),
        debug=bool(debug),
    )

    # stamp bookkeeping for next time
    import numpy as np
    cv = int(getattr(runtime_ctx, "cache_version", 0))
    for ch in need:
        ch._spawn_cache_built_at_cachever = cv
        ch._mask_prev_for_spawn = np.asarray(ch.mask, dtype=np.float32).copy()



def refresh_spawn_alignment_caches(children, agents, *,
                                   tau_q=None, tau_p=None,
                                   alpha=None,         # blend 0→model-only, 1→belief-only
                                   sm_tau=None,        # softmin temperature across neighbors
                                   kl_cap=None,        # cap *before* exponentials
                                   eps=None, log_eps=None,
                                   use_cover_weight=True,
                                   debug=False):
    """
    Build *spawn-only* caches on each child:
        ch.spawn_nb_count        : (H,W) int32
        ch.spawn_min_kl_q        : (H,W) float32
        ch.spawn_min_kl_p        : (H,W) float32
        ch.spawn_softmin_kl_q    : (H,W) float32
        ch.spawn_softmin_kl_p    : (H,W) float32
        ch.spawn_cover_weight    : (H,W) float32   (optional)
        ch.spawn_A_final         : (H,W) float32   final agreement weight for seeding
    Compatibility conveniences (for plotting / downstream):
        ch.kl_field              : blended softmin KL
        ch.agreement_field       : same as spawn_A_final
    Notes:
      - Uses moment-frame KL with *orthogonal* transport: Σ -> Ω Σ Ω^T.
      - All aggregations are per-pixel over neighbors of child i.
    """
    import numpy as np
    import config as _cfg
    from omega import exp_lie_algebra_irrep
    from numerical_utils import sanitize_sigma
    from get_generators import get_generators
    from generalized_diagnostics_metrics import kl_divergence
    # ----- knobs with safe defaults from config --------------------------------
    tau_q   = float(_cfg.tau_align_q)      if tau_q   is None else float(tau_q)
    tau_p   = float(_cfg.tau_align_p)      if tau_p   is None else float(tau_p)
    alpha   = float(getattr(_cfg, "blend_qp_alpha", 0.50)) if alpha is None else float(alpha)
    sm_tau  = float(getattr(_cfg, "spawn_softmin_tau", 0.40)) if sm_tau is None else float(sm_tau)
    kl_cap  = float(getattr(_cfg, "signal_kl_cap", 10.0)) if kl_cap is None else float(kl_cap)
    eps     = float(getattr(_cfg, "support_cutoff_eps", 1e-4)) if eps is None else float(eps)
    log_eps = float(getattr(_cfg, "log_eps", 1e-9)) if log_eps is None else float(log_eps)

    # ----- local helpers --------------------------------------------------------
    def _threshold_mask(m):
        a = np.asarray(m, np.float32)
        return a > eps

    def _to_full_cov_at(points_cov, K):
        """
        Accepts either diagonal std/var per-pixel or full SPD (K,K).
        Returns (M,K,K) for M selected pixels.
        """
        s = points_cov
        if s.ndim == 2 and s.shape[1] == K:
            # treat as diagonal stddevs: (M,K) -> (M,K,K)
            return np.einsum("mk,ij->mij", s**2, np.eye(K, dtype=s.dtype))
        if s.ndim == 3 and s.shape[1] == K and s.shape[2] == K:
            return s
        raise ValueError(f"Unexpected covariance shape {s.shape}; expected (M,K) diag or (M,K,K).")

    def _sanitize_sigma(S):
        # Your existing SPD guard; keep it light since transport is orthogonal
        return sanitize_sigma(S, eps=log_eps)

    def _expR(phi_grid, generators):
        # exp in irrep, per-pixel
        return exp_lie_algebra_irrep(phi_grid, generators)

    def _softmin_from_sumexp(sumexp, temp):
        # temp > 0.0
        return -temp * np.log(np.maximum(sumexp, 1e-20))

    # ----- main loop ------------------------------------------------------------
    for ch in children:
        Ai = ch
        if not getattr(Ai, "neighbors", None):
            # allocate empty caches
            H, W = Ai.mask.shape[:2]
            zf = np.zeros((H, W), np.float32)
            zi = np.zeros((H, W), np.int32)
            Ai.spawn_nb_count      = zi
            Ai.spawn_min_kl_q      = zf + np.inf
            Ai.spawn_min_kl_p      = zf + np.inf
            Ai.spawn_softmin_kl_q  = zf
            Ai.spawn_softmin_kl_p  = zf
            Ai.spawn_cover_weight  = zf
            Ai.spawn_A_final       = zf
            Ai.kl_field            = zf
            Ai.agreement_field     = zf
            continue

        mask_i = _threshold_mask(Ai.mask)
        if not np.any(mask_i):
            # same zero-allocation branch
            H, W = Ai.mask.shape[:2]
            zf = np.zeros((H, W), np.float32)
            zi = np.zeros((H, W), np.int32)
            Ai.spawn_nb_count      = zi
            Ai.spawn_min_kl_q      = zf + np.inf
            Ai.spawn_min_kl_p      = zf + np.inf
            Ai.spawn_softmin_kl_q  = zf
            Ai.spawn_softmin_kl_p  = zf
            Ai.spawn_cover_weight  = zf
            Ai.spawn_A_final       = zf
            Ai.kl_field            = zf
            Ai.agreement_field     = zf
            continue

        H, W = Ai.mask.shape[:2]

        # Select fields and group generators for belief/model
        Kq = int(getattr(_cfg, "K_q", Ai.mu_q_field.shape[-1]))
        Kp = int(getattr(_cfg, "K_p", Ai.mu_p_field.shape[-1]))
        Gq = get_generators(_cfg.group_name, Kq)
        Gp = get_generators(_cfg.group_name, Kp)

        # Accumulators
        nb_count      = np.zeros((H, W), np.int32)
        min_kl_q      = np.full((H, W), np.inf, np.float32)
        min_kl_p      = np.full((H, W), np.inf, np.float32)
        sumexp_q      = np.zeros((H, W), np.float32)
        sumexp_p      = np.zeros((H, W), np.float32)
        cover_weight  = np.zeros((H, W), np.float32) if use_cover_weight else None

        # local (child i) fields
        mu_q_i    = Ai.mu_q_field
        mu_p_i    = Ai.mu_p_field
        Sig_q_i   = Ai.sigma_q_field
        Sig_p_i   = Ai.sigma_p_field
        phi_q_i   = Ai.phi        # (H,W,3)
        phi_p_i   = Ai.phi_model  # (H,W,3)

        # Pre-extract i's values at overlap later
        for nb in Ai.neighbors:
            Bj = agents[nb["id"]]
            mask_j = _threshold_mask(Bj.mask)
            overlap = mask_i & mask_j
            if not np.any(overlap):
                continue

            idx = np.argwhere(overlap)
            iy, ix = idx[:, 0], idx[:, 1]

            # ---------- belief side (Kq) ----------
            mu_i = mu_q_i[overlap]                   # (M,Kq)
            mu_j = Bj.mu_q_field[overlap]            # (M,Kq)
            Si   = _to_full_cov_at(Sig_q_i[overlap], Kq)   # (M,Kq,Kq)
            Sj   = _to_full_cov_at(Bj.sigma_q_field[overlap], Kq)

            Si = _sanitize_sigma(Si)
            Sj = _sanitize_sigma(Sj)

            Ri    = _expR(phi_q_i[overlap], Gq)      # (M,Kq,Kq)
            RjInv = _expR(-Bj.phi[overlap], Gq)      # (M,Kq,Kq)
            Omega = np.einsum("mab,mbc->mac", Ri, RjInv)
            Omega_T = np.swapaxes(Omega, -1, -2)

            mu_j_t = np.einsum("mab,mb->ma", Omega, mu_j)
            Sj_t   = np.einsum("mab,mbc,mdc->mad", Omega, Sj, Omega_T)
            Sj_t   = _sanitize_sigma(Sj_t)

            KL_q_ij = kl_divergence(mu_i, Si, mu_j_t, Sj_t, eps=log_eps)  # (M,)
            KL_q_ij = np.where(np.isfinite(KL_q_ij), KL_q_ij, 0.0)
            KL_q_ij = np.clip(KL_q_ij, 0.0, kl_cap)

            # ---------- model side (Kp) ----------
            mu_i = mu_p_i[overlap]                   # (M,Kp)
            mu_j = Bj.mu_p_field[overlap]            # (M,Kp)
            Si   = _to_full_cov_at(Sig_p_i[overlap], Kp)
            Sj   = _to_full_cov_at(Bj.sigma_p_field[overlap], Kp)

            Si = _sanitize_sigma(Si)
            Sj = _sanitize_sigma(Sj)

            Ri    = _expR(phi_p_i[overlap], Gp)      # (M,Kp,Kp)
            RjInv = _expR(-Bj.phi_model[overlap], Gp)
            Omega = np.einsum("mab,mbc->mac", Ri, RjInv)
            Omega_T = np.swapaxes(Omega, -1, -2)

            mu_j_t = np.einsum("mab,mb->ma", Omega, mu_j)
            Sj_t   = np.einsum("mab,mbc,mdc->mad", Omega, Sj, Omega_T)
            Sj_t   = _sanitize_sigma(Sj_t)

            KL_p_ij = kl_divergence(mu_i, Si, mu_j_t, Sj_t, eps=log_eps)  # (M,)
            KL_p_ij = np.where(np.isfinite(KL_p_ij), KL_p_ij, 0.0)
            KL_p_ij = np.clip(KL_p_ij, 0.0, kl_cap)

            # ---------- aggregate at (iy, ix) ----------
            np.add.at(nb_count, (iy, ix), 1)

            # hard-mins
            np.minimum.at(min_kl_q, (iy, ix), KL_q_ij.astype(np.float32))
            np.minimum.at(min_kl_p, (iy, ix), KL_p_ij.astype(np.float32))

            # softmin via sumexp over neighbors
            np.add.at(sumexp_q, (iy, ix), np.exp(-KL_q_ij / max(sm_tau, 1e-8)))
            np.add.at(sumexp_p, (iy, ix), np.exp(-KL_p_ij / max(sm_tau, 1e-8)))

            # optional coverage weight (accumulate neighbor mask weight)
            if use_cover_weight:
                np.add.at(cover_weight, (iy, ix), np.asarray(Bj.mask, np.float32)[overlap])

        # --- finalize per-pixel aggregates (valid where nb_count>0) ---
        valid   = (nb_count > 0)
        support = (mask_i.astype(bool))
        pixels  = (valid & support)
        
        softmin_q = np.zeros_like(sumexp_q, np.float32)
        softmin_p = np.zeros_like(sumexp_p, np.float32)
        softmin_q[valid] = _softmin_from_sumexp(sumexp_q[valid], sm_tau).astype(np.float32)
        softmin_p[valid] = _softmin_from_sumexp(sumexp_p[valid], sm_tau).astype(np.float32)
        
        # blended softmin KL and final A(x)
        tau_blend = alpha * tau_q + (1.0 - alpha) * tau_p
        KL_blend  = alpha * softmin_q + (1.0 - alpha) * softmin_p
        
        A_final = np.zeros_like(KL_blend, np.float32)
        A_final[valid] = np.exp(-KL_blend[valid] / max(tau_blend, 1e-8)).astype(np.float32)
        
        # ---- mask using where (avoid inf*0) ----
        # KL "best" maps: +inf where no valid neighbor OR outside support
        min_kl_q = np.where(pixels, min_kl_q, np.inf).astype(np.float32)
        min_kl_p = np.where(pixels, min_kl_p, np.inf).astype(np.float32)
        
        # softmins/blends/agreements: 0 outside support
        softmin_q = np.where(support, softmin_q, 0.0).astype(np.float32)
        softmin_p = np.where(support, softmin_p, 0.0).astype(np.float32)
        KL_blend  = np.where(support,  KL_blend,  0.0).astype(np.float32)
        A_final   = np.where(support,  A_final,   0.0).astype(np.float32)
        
        if use_cover_weight:
            cover_weight = np.where(support, cover_weight, 0.0).astype(np.float32)
        
        # ---- write caches on the child ----
        Ai.spawn_nb_count       = nb_count
        Ai.spawn_min_kl_q       = min_kl_q
        Ai.spawn_min_kl_p       = min_kl_p
        Ai.spawn_softmin_kl_q   = softmin_q
        Ai.spawn_softmin_kl_p   = softmin_p
        Ai.spawn_cover_weight   = cover_weight if use_cover_weight else None
        Ai.spawn_A_final        = A_final
        
        # compatibility fields for existing downstream code/plots
        Ai.kl_field             = KL_blend
        Ai.agreement_field      = A_final
        
        if debug and np.any(pixels):
            if not np.all(np.isfinite(KL_blend[support])):
                print(f"[spawn-cache] non-finite blended KL for child {Ai.id}")
    











#=============================================================================#






def _post_strict_subset(agents_subset, params, generators_q, generators_p):
    """
    Strict refresh but only for a subset of agents/parents.
    Requires:
      - preprocess_all_agents
      - build_all_omega_caches
      - build_all_lambda_caches
    """
    if not agents_subset: return
    preprocess_all_agents(agents_subset, params)
    build_all_omega_caches(agents_subset)
    build_all_lambda_caches(agents_subset)



def mark_dirty(ctx, *agents, kl=False):
    for a in agents:
        aid = int(getattr(a, "id", id(a)))
        ctx.dirty.agents.add(aid)
        if kl: ctx.dirty.kl.add(aid)

def take_dirty(ctx, all_agents, *, which="agents"):
    ids = ctx.dirty.agents if which=="agents" else ctx.dirty.kl
    subset = _collect_by_ids(all_agents, ids)
    ids.clear()
    return subset



def _standardize_all_masks_once(all_agents, HW):
    from parent_utils import ensure_hw
    for a in all_agents:
        if hasattr(a, "mask"):
            m = getattr(a, "mask", None)
            if m is not None:
                mm = ensure_hw(m, HW)  # no-op if already right
                if mm is not m:
                    setattr(a, "mask", mm)






def compute_and_set_auto_agree_gate(runtime_ctx, *, percentile=65.0, ema=0.2, use_p_if_q_missing=True):
    """
    Sets runtime_ctx.detector_state.agree_gate_tau_eff to a smoothed percentile
    of A_agg in [0,1]. If no aggregates exist, sets it to None (gate off).
    """
    import numpy as np
    ds = getattr(runtime_ctx, "detector_state", None)
    if ds is None:
        return

    A = getattr(runtime_ctx, "Aq_agg", None)
    if (A is None) and use_p_if_q_missing:
        A = getattr(runtime_ctx, "Ap_agg", None)

    if A is None:
        ds.agree_gate_tau_eff = None
        try:
            print("[AGG] auto agree gate: no aggregates, gate OFF")
        except Exception:
            pass
        return

    A = np.asarray(A, np.float32)
    good = np.isfinite(A)
    if not good.any():
        ds.agree_gate_tau_eff = None
        try:
            print("[AGG] auto agree gate: aggregates non-finite, gate OFF")
        except Exception:
            pass
        return

    thr = float(np.percentile(A[good], float(percentile)))
    prev = getattr(ds, "agree_gate_tau_eff", None)
    if (prev is None) or (not np.isfinite(prev)):
        new_tau = thr
    else:
        new_tau = (1.0 - float(ema)) * float(prev) + float(ema) * thr

    ds.agree_gate_tau_eff = float(new_tau)
    try:
        print(f"[AGG] auto agree gate p{int(percentile)} ema={ema} tau={new_tau:.3f}")
    except Exception:
        pass




def prune_orphan_parents(
    parents_by_id,
    *,
    patience=3,
    min_total_weight=1e-4,
    min_area_nz=5,
    support_tau=0.02,
    respect_grace=True,
    verbose=False,
):
    """
    Remove parents that carry ~no child weight or tiny support for `patience` consecutive steps.
    - Weight check: sum(child_weights) < min_total_weight
    - Area check:   count(mask > support_tau) < min_area_nz
    - Respects each parent's grace window (_grace) if `respect_grace=True`.
    Returns: list of pruned parent ids.
    """
    import numpy as np

    dead = []

    for pid, P in list(parents_by_id.items()):
        # ----- stats (NaN-safe) -----
        wsum = float(sum((getattr(P, "child_weights", {}) or {}).values()))
        if not np.isfinite(wsum):
            wsum = 0.0

        m = np.nan_to_num(np.asarray(getattr(P, "mask", 0.0), np.float32), nan=0.0, posinf=0.0, neginf=0.0)
        nz = int(np.count_nonzero(m > float(support_tau)))

        # ----- grace / age gate -----
        age   = int(getattr(P, "_age", 0) or 0)
        grace = int(getattr(P, "_grace", 0) or 0)
        in_grace = respect_grace and (age < grace)

        ticks = int(getattr(P, "_orphan_ticks", 0) or 0)

        if in_grace:
            # During grace, don't accrue orphan ticks; reset if any evidence appears
            if (wsum >= float(min_total_weight)) or (nz >= int(min_area_nz)):
                ticks = 0
            # else keep ticks at 0 (don’t penalize newborns)
        else:
            # Outside grace: accrue ticks when both signals are weak
            if (wsum < float(min_total_weight)) or (nz < int(min_area_nz)):
                ticks += 1
            else:
                ticks = 0

        P._orphan_ticks = ticks

        if (ticks >= int(patience)) and (not in_grace):
            dead.append(int(pid))

    for pid in dead:
        parents_by_id.pop(pid, None)

    if verbose and dead:
        print(f"[PRUNE] removed {len(dead)} parents: {dead}")

    return dead






def _pre_light(all_agents, params, Gq, Gp):
    pre = dict(params)
    pre["sanitize_strict"] = pre.get("sanitize_strict_pre", False)
    pre["exp_n_jobs"] = 1   
    preprocess_all_agents(all_agents, pre, Gq, Gp)
    build_all_omega_caches(all_agents)
    build_all_lambda_caches(all_agents)
    # inside _pre_light(all_agents, ...):
    H, W = np.asarray(all_agents[0].mask).shape[:2]
    _standardize_all_masks_once(all_agents, (H, W))





def _post_strict(all_agents, params, Gq, Gp):
    post = dict(params)
    post["sanitize_strict"] = True
    post["exp_n_jobs"] = 1
    preprocess_all_agents(all_agents, post, Gq, Gp)
    build_all_omega_caches(all_agents)
    build_all_lambda_caches(all_agents)





# --- subset wrapper (spawn-only caches, MVG, orthogonal transport) ------------
def _refresh_child_kl_fields_subset(children_subset, all_agents, eps, build_spawn = False):
    """
    Legacy entrypoint used by detector/growth passes.
    Now delegates to spawn-only MVG cache builder for just the given subset.
    """
    if not children_subset:
        return

    try:
        import config as _cfg
        log_eps = float(getattr(_cfg, "log_eps", 1e-9))
    except Exception:
        log_eps = 1e-9

    if build_spawn:
        
        refresh_spawn_alignment_caches(
            children_subset,
            all_agents,
            eps=float(eps),
            log_eps=log_eps,
            # leave other knobs None → pulled from config inside the function
        )





def _invalidate_transport_caches(objs):
    """
    Clear all transport-related caches on the given agent objects.
    Safe to call with empty lists. Bumps a per-agent cache_version for debugging.
    """
    if not objs:
        return
    for a in objs:
        for attr in (
            "Omega_cache","Omega_tilde_cache",
            "_exp_phi","_exp_neg_phi","_exp_phi_model","_exp_neg_phi_model",
            "Lambda_up_q_map","Lambda_dn_q_map","Lambda_up_p_map","Lambda_dn_p_map",
            "kl_cache","kl_fields","cached_alignment_kl","cached_model_alignment_kl",
        ):
            if hasattr(a, attr):
                try:
                    setattr(a, attr, None)
                except Exception:
                    pass
        try:
            a.cache_version = int(getattr(a, "cache_version", 0)) + 1
        except Exception:
            pass




def _as_parent_dict(obj):
    """
    Normalize parents -> {pid: Parent}. Accepts dict, list, iterable, or None.
    Uses the parent's .id if present; else falls back to enumerate index.
    """
    import collections.abc as _abc
    if obj is None:
        return {}
    if isinstance(obj, dict):
        return {int(getattr(p, "id", pid)): p for pid, p in obj.items()}
    if isinstance(obj, _abc.Iterable):
        return {int(getattr(p, "id", i)): p for i, p in enumerate(obj)}
    # Single parent object?
    return {int(getattr(obj, "id", 0)): obj}


