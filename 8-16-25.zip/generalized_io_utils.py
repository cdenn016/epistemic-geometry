import os
import pickle
import hashlib
import csv
import re
import config
from pathlib import Path
import numpy as np
import json
import pandas as pd
import logging

def load_latest_checkpoint(checkpoint_dir="checkpoints"):
    """
    Load the most recent checkpoint file from the directory.
    Returns the agents and metrics at the latest step.
    """
    # List files starting with 'step' and ending with '.pkl'
    files = [f for f in os.listdir(checkpoint_dir) if f.startswith("step") and f.endswith(".pkl")]
    if not files:
        raise RuntimeError(f"No checkpoint files found in {checkpoint_dir}")
    
    # Sort and get the most recent file
    latest_file = max(files, key=lambda f: parse_step(f))
    latest_path = os.path.join(checkpoint_dir, latest_file)
    
    with open(latest_path, 'rb') as f:
        agents = pickle.load(f)
    
    logging.info(f"[✓] Loaded latest checkpoint: {latest_file}")
    return agents


def hash_q(agent):
    """
    Compute a SHA256 hash of the belief field `q` of an agent to detect changes.
    """
    return hashlib.sha256(agent.q.tobytes()).hexdigest()


def parse_step(filename):
    """
    Extract integer step from filenames like 'step_0001.pkl' or 'step0010_pair_1_2.pkl'.
    """
    match = re.search(r'step[_]?(\d+)', filename)
    if not match:
        raise ValueError(f"Filename '{filename}' does not match expected pattern")
    return int(match.group(1))


def load_all_checkpoints(checkpoint_dir="checkpoints"):
    """
    Load and cache all checkpoint files from a directory.
    Returns a dict mapping step → agent list or (agents, metrics) tuple.
    """
    files = [f for f in os.listdir(checkpoint_dir)
             if f.startswith("step") and f.endswith(".pkl")]
    if not files:
        raise RuntimeError(f"No checkpoint files found in {checkpoint_dir}")

    files_sorted = sorted(files, key=lambda f: parse_step(f))
    cache = {}
    for fname in files_sorted:
        step = parse_step(fname)
        path = os.path.join(checkpoint_dir, fname)
        with open(path, 'rb') as f:
            cache[step] = pickle.load(f)
        logging.info(f"[✓] Loaded checkpoint step={step}")
    return cache


def save_config_to_readme(outdir="checkpoints"):
    """
    Save current config parameters into a README.txt file inside the output directory.
    This makes simulation runs reproducible by logging all config values used.
    """
    readme_path = os.path.join(outdir, "README.txt")
    with open(readme_path, "w") as f:
        f.write("Simulation Configuration Parameters\n")
        f.write("===================================\n\n")
        for key in dir(config):
            if key.startswith("__"):
                continue
            val = getattr(config, key)
            if callable(val):
                continue
            f.write(f"{key} = {val}\n")


def load_agents(checkpoint_dir):
    """Load agents from checkpoint only; do not rerun simulation."""
    import os, pickle

    ckpt = os.path.join(checkpoint_dir, "step_0000.pkl")
    if not os.path.isfile(ckpt):
        raise FileNotFoundError(f"No checkpoint found at {ckpt}")

    with open(ckpt, "rb") as f:
        agents = pickle.load(f)
    return agents


def load_per_agent_metrics(checkpoint_dir):
    """Load per_agent_metrics.csv if it exists and has the right columns."""
    csv_path = os.path.join(checkpoint_dir, "per_agent_metrics.csv")
    if os.path.isfile(csv_path):
        df = pd.read_csv(csv_path)
        if {'agent', 'kl_align'}.issubset(df.columns):
            return df
    return None

def save_metrics_csv(metrics_list, filepath):
    """
    Save a list of dictionaries (metrics) as a CSV file.
    Handles UTF-8 encoding for special characters.
    """
    if not metrics_list:
        print("[WARNING] No metrics to save.")
        return

    fieldnames = list(metrics_list[0].keys())

    with open(filepath, mode="w", newline="", encoding="utf-8") as csvfile:
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(metrics_list)


def save_step(agents, outdir, step):
    """
    Save agent state to step_{step:04d}.pkl and update checkpoint.pkl atomically.
    """
    os.makedirs(outdir, exist_ok=True)
    step_path = os.path.join(outdir, f"step_{step:04d}.pkl")
    ckpt_path = os.path.join(outdir, "checkpoint.pkl")

    with open(step_path, "wb") as f:
        pickle.dump(agents, f)
    with open(ckpt_path, "wb") as f:
        pickle.dump(agents, f)


def load_checkpoint(outdir):
    """
    Load latest checkpoint.pkl or fallback to latest step_XXXX.pkl in outdir.
    Returns (agents, filename) or (None, None) if none found.
    """
    ckpt_path = os.path.join(outdir, "checkpoint.pkl")
    if os.path.exists(ckpt_path):
        with open(ckpt_path, "rb") as f:
            return pickle.load(f), "checkpoint.pkl"

    step_files = sorted(
        [f for f in os.listdir(outdir) if f.startswith("step_") and f.endswith(".pkl")]
    )
    if not step_files:
        return None, None

    last_step = step_files[-1]
    with open(os.path.join(outdir, last_step), "rb") as f:
        return pickle.load(f), last_step


def find_resume_step(outdir):
    """
    Determine the next step to resume from based on existing saved steps.
    Returns 0 if none found.
    """
    step_files = sorted(
        [f for f in os.listdir(outdir) if f.startswith("step_") and f.endswith(".pkl")]
    )
    if not step_files:
        return 0
    last_step = step_files[-1]
    return int(last_step.replace("step_", "").replace(".pkl", "")) + 1


def load_all_steps(outdir):
    """
    Load all step_*.pkl files as a list of agent states.
    """
    step_files = sorted(
        [f for f in os.listdir(outdir) if f.startswith("step_") and f.endswith(".pkl")]
    )
    state_log = []
    for fname in step_files:
        with open(os.path.join(outdir, fname), "rb") as f:
            state_log.append(pickle.load(f))
    return state_log


def list_step_files(run_path):
    """
    Return sorted list of (step_number, filepath) tuples for step files.
    """
    step_files = []
    for fname in os.listdir(run_path):
        match = re.match(r"step_(\d+)\.pkl", fname)
        if match:
            step_num = int(match.group(1))
            step_files.append((step_num, os.path.join(run_path, fname)))
    return sorted(step_files)


def load_final_step(run_path):
    """
    Load the agent state from the final step file in a run directory.
    Returns None if no step files found.
    """
    step_files = list_step_files(run_path)
    if not step_files:
        return None
    _, last_file = step_files[-1]
    with open(last_file, "rb") as f:
        return pickle.load(f)
    
def load_meta_data(alignment_dir: str, prefix: str = "kl"):
    """
    Load KL matrix, cluster labels, and rankings from the alignment output directory.
    Returns (kl_matrix, labels, rankings_dict).
    """
    import json
    from pathlib import Path
    import numpy as np

    alignment_path = Path(alignment_dir).resolve()
    matrix_file = alignment_path / f"{prefix}_matrix.csv"
    labels_file = alignment_path / f"{prefix}_labels.csv"
    meta_file   = alignment_path / f"{prefix}_meta.json"

    if not matrix_file.exists():
        raise FileNotFoundError(f"Missing KL matrix file: {matrix_file}")
    if not labels_file.exists():
        raise FileNotFoundError(f"Missing cluster label file: {labels_file}")

    kl_matrix = np.loadtxt(matrix_file, delimiter=',')
    labels    = np.loadtxt(labels_file, dtype=int, delimiter=',')

    if meta_file.exists():
        with open(meta_file, 'r') as f:
            meta = json.load(f)
        rankings = meta.get('rankings', {})
    else:
        rankings = {}

    print(f"[LOAD] Loaded KL matrix from {matrix_file.name}, labels from {labels_file.name}")
    return kl_matrix, labels, rankings


def save_generic_alignment_data(
    kl_matrix,
    rankings,
    labels,
    outdir="alignment_output",
    prefix="kl"
):
    """
    Write out:
      1. prefix_matrix.csv       – the symmetrized KL matrix
      2. prefix_labels.csv       – integer cluster label per agent
      3. rankings.txt            – best/worst/full_rank per agent
      4. prefix_meta.json        – a JSON with both labels & rankings
    """
    out = Path(outdir)  # ← ensure it's a Path object
    out.mkdir(parents=True, exist_ok=True)

    # 1. KL matrix
    np.savetxt(out / f"{prefix}_matrix.csv", kl_matrix, delimiter=",")

    # 2. Cluster labels (shape (N,), -1 = noise/singleton)
    np.savetxt(
        out / f"{prefix}_labels.csv",
        labels.astype(int),
        fmt="%d",
        delimiter=","
    )

    # 3. Rankings text
    with open(out / "rankings.txt", "w") as f:
        for i, data in rankings.items():
            f.write(
                f"Agent {i}:\n"
                f"  Best:      {data['best']}\n"
                f"  Worst:     {data['worst']}\n"
                f"  Full rank: {data['full_rank']}\n\n"
            )

    # 4. Combined JSON
    labels_list = labels.tolist()
    clean_rankings = {
        int(ag): {
            "best": int(data["best"]),
            "worst": int(data["worst"]),
            "full_rank": [int(x) for x in data["full_rank"]]
        }
        for ag, data in rankings.items()
    }

    meta = {
        "labels": labels_list,
        "rankings": clean_rankings
    }
    with open(out / f"{prefix}_meta.json", "w") as f:
        json.dump(meta, f, indent=2)

    print(f"[+] Saved alignment data to '{out.resolve()}/' (prefix='{prefix}')")

import joblib 

def save_meta_agents(meta_agents, output_dir="meta_agent_analysis/meta_agent_fields"):
    """
    Save each meta-agent as a .pkl file containing fields, phi, metadata.
    """
    os.makedirs(output_dir, exist_ok=True)
    for A in meta_agents:
        save_dict = {
            "id": A.id,
            "mask": A.mask,
            "mu_q": A.mu_q_field,
            "sigma_q": A.sigma_q_field,
            "mu_p": A.mu_p_field,
            "sigma_p": A.sigma_p_field,
            "phi": A.phi,
            "phi_model": A.phi_model,
            "center": A.center,
            "radius": A.radius,
            "neighbors": A.neighbors,
        }
        fname = os.path.join(output_dir, f"meta_agent_{A.id:03d}.pkl")
        joblib.dump(save_dict, fname)
        print(f"[✓] Saved meta-agent {A.id} → {fname}")


def load_meta_agents(folder="meta_agent_analysis/meta_agent_fields"):
    """
    Load all meta-agent .pkl files in the folder and return a list of dicts.
    You can later re-wrap these into Agent objects if needed.
    """
    files = sorted(f for f in os.listdir(folder) if f.endswith(".pkl"))
    meta_agents = []
    for fname in files:
        path = os.path.join(folder, fname)
        agent = joblib.load(path)
        meta_agents.append(agent)
    print(f"[✓] Loaded {len(meta_agents)} meta-agents from {folder}")
    return meta_agents


def save_meta_labels(labels, path="meta_agent_analysis/meta_labels.csv"):
    """
    Save the cluster labels (agent index → cluster ID) to CSV.
    """
    np.savetxt(path, labels, fmt="%d", delimiter=",")
    print(f"[✓] Saved meta-agent labels → {path}")
