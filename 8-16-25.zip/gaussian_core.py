# -*- coding: utf-8 -*-
"""
Created on Mon Aug 11 10:07:56 2025

@author: chris and christine
"""
import numpy as np
from numerical_utils import sanitize_sigma, safe_inv, safe_logdet
from typing import Optional, Tuple
from omega import exp_lie_algebra_irrep



def kl_gaussians(mu1, S1, mu2, S2, eps=1e-6):
    """KL(N(μ1,Σ1) || N(μ2,Σ2)) — batch-safe, no fragile squeezes."""
    S1 = sanitize_sigma(S1, eps=eps)
    S2 = sanitize_sigma(S2, eps=eps)
    K = S1.shape[-1]
    S2_inv = safe_inv(S2, eps=eps)
    dmu = (mu2 - mu1)                                       # (..., K)
    term_trace = np.einsum('...ij,...ji->...', S2_inv, S1)  # tr(S2^{-1} Σ1)
    term_quad  = np.einsum('...i,...ij,...j->...', dmu, S2_inv, dmu)  # (μ2-μ1)^T S2^{-1} (μ2-μ1)
    s1, logdet1 = np.linalg.slogdet(S1)
    s2, logdet2 = np.linalg.slogdet(S2)
    logdet_ratio = logdet2 - logdet1
    return 0.5 * (term_trace + term_quad - K + logdet_ratio)




def gaussian_pushforward_linear(mu, Sigma, A):
    """Push (mu,Sigma) by linear map A: (A mu, A Σ A^T)."""
    mu_t = np.einsum('...ij,...j->...i', A, mu)
    S_t  = np.einsum('...ik,...kl,...jl->...ij', A, Sigma, A)
    return mu_t, S_t


def _prep_A(A, H, W):
    """Prepare/resize an agreement map to (H,W) in [0,1], or return None."""
    import numpy as _np
    if A is None:
        return None
    A = _np.asarray(A, _np.float32)
    if A.shape[:2] != (H, W):
        try:
            from numerical_utils import resize_nn
            A = resize_nn(A, (H, W)).astype(_np.float32)
        except Exception:
            return None
    return _np.clip(A, 0.0, 1.0)


def QQ_orthogonal_part_4d(Omega):
    """Per-pixel polar factor (orthogonal) for (...,K,K). Ensures det≈+1."""
    import numpy as _np
    K = Omega.shape[-1]
    Z = Omega.reshape(-1, K, K)
    U, _, Vt = _np.linalg.svd(Z, full_matrices=False)
    R = (U @ Vt)
    detR = _np.linalg.det(R)
    neg = detR < 0.0
    if _np.any(neg):
        U[neg, :, -1] *= -1.0
        R = (U @ Vt)
    return R.reshape(Omega.shape).astype(_np.float32, copy=False)


def QQ_get_R_ij(i_agent, j_agent, *, fiber, H, W, K):
    """
    Rotation R_ij (j→i) for the chosen fiber.
      fiber="q" → Omega_cache (belief φ)
      fiber="p" → Omega_tilde_cache (model φ̃)
    Falls back to identity if caches/exp(φ) are missing.
    """
    import numpy as _np
    I = _np.eye(K, dtype=_np.float32)
    try:
        if fiber == "q":
            Om = getattr(i_agent, "Omega_cache", {}).get(int(getattr(j_agent, "id", -1)))
            if Om is None:
                Ei  = getattr(i_agent,  "_exp_phi", None)
                EjN = getattr(j_agent, "_exp_neg_phi", None)
                if Ei is None or EjN is None:
                    return _np.broadcast_to(I, (H, W, K, K))
                Om = _np.einsum("...ik,...kj->...ij", Ei, EjN, optimize=True)
        else:  # "p"
            Om = getattr(i_agent, "Omega_tilde_cache", {}).get(int(getattr(j_agent, "id", -1)))
            if Om is None:
                Ei  = getattr(i_agent,  "_exp_phi_model", None)
                EjN = getattr(j_agent, "_exp_neg_phi_model", None)
                if Ei is None or EjN is None:
                    return _np.broadcast_to(I, (H, W, K, K))
                Om = _np.einsum("...ik,...kj->...ij", Ei, EjN, optimize=True)
        return _orthogonal_part_4d(_np.asarray(Om, _np.float32))
    except Exception:
        return _np.broadcast_to(I, (H, W, K, K))


def _transport_gaussian(mu_j, S_j, R):
    """Transport Gaussian by orthogonal R: μ' = R μ, Σ' = R Σ Rᵀ (symmetrized)."""
    import numpy as _np
    muT = (R @ mu_j[..., None])[..., 0]
    ST  = R @ S_j @ R.swapaxes(-1, -2)
    ST  = 0.5 * (ST + ST.swapaxes(-1, -2))
    return muT.astype(_np.float32, copy=False), ST.astype(_np.float32, copy=False)





def _overlap_pairs(children, H, W, *, tau=0.10, min_pair_px=8):
    """
    Return list of (i,j, overlap_bool_mask) for child pairs whose supports overlap.
    Uses (mask > tau) as support for overlap detection.
    """
    Ms_bool = [(np.asarray(c.mask, np.float32) > float(tau)) for c in children]
    pairs = []
    n = len(children)
    for i in range(n):
        mi = Ms_bool[i]
        if not mi.any(): continue
        for j in range(i+1, n):
            ov = (mi & Ms_bool[j])
            if int(ov.sum()) >= int(min_pair_px):
                pairs.append((i, j, ov))
    return pairs


def _mahalanobis_masked_fast(mu1, S1, mu2, S2, mask, eps=1e-6):
    """Masked Mahalanobis distance with pooled covariance 0.5*(S1+S2)."""
    import numpy as _np
    H, W, K = mu1.shape[:3]
    if not mask.any():
        return _np.zeros((H, W), _np.float32)
    I = _np.eye(K, dtype=_np.float32)
    idx = _np.flatnonzero(mask.reshape(-1))
    M1  = mu1.reshape(-1, K)[idx]
    M2  = mu2.reshape(-1, K)[idx]
    S1r = S1.reshape(-1, K, K)[idx]
    S2r = S2.reshape(-1, K, K)[idx]
    Sp  = 0.5 * (S1r + S2r) + eps * I

    d  = (M1 - M2)[..., None]
    z  = _np.linalg.solve(Sp, d)
    maha = _np.squeeze(d.transpose(0,2,1) @ z, axis=(-2,-1))

    out = _np.zeros((H, W), _np.float32)
    out.reshape(-1)[idx] = _np.clip(maha.astype(_np.float32), 0.0, _np.finfo(_np.float32).max)
    return out


def _fuse_pair_weights(wq, wp, alpha, mode):
    """Fuse q/p pair weights by 'geo' (default), 'arith', or 'min'."""
    import numpy as _np
    alpha = float(alpha)
    if mode == "arith":
        return alpha * wq + (1.0 - alpha) * wp
    if mode == "min":
        return _np.minimum(wq, wp)
    # geometric
    return _np.exp(
        alpha * _np.log(_np.maximum(wq, 1e-12)) +
        (1.0 - alpha) * _np.log(_np.maximum(wp, 1e-12))
    ).astype(_np.float32, copy=False)


import numpy as _np

def curvature_boltzmann_from_children(children, H, W, *, gamma=0.0, fiber="q", curvature_map=None):
    """
    Build a curvature Boltzmann factor BF(x) = exp(-gamma * F(x)).
    If curvature_map is provided (H×W), use it directly.
    Else compute F(x) as mask-weighted Frobenius norm of F_xy from omega.compute_field_strength.
    Returns: BF ∈ ℝ^{H×W} (float32) or None if gamma<=0 or computation unavailable.
    """
    if float(gamma) <= 0.0:
        return None

    if curvature_map is not None:
        F = _np.asarray(curvature_map, _np.float32)
        if F.shape == (H, W):
            return _np.exp(-float(gamma) * _np.clip(F, 0.0, _np.finfo(_np.float32).max)).astype(_np.float32)

    try:
        from omega import compute_field_strength
    except Exception:
        return None  # fail-open

    num = _np.zeros((H, W), _np.float32)
    den = _np.zeros((H, W), _np.float32)
    phi_name = "phi" if str(fiber)=="q" else "phi_model"
    gen_name = "generators_q" if str(fiber)=="q" else "generators_p"

    for c in children:
        m = _np.asarray(getattr(c, "mask", 0.0), _np.float32)
        if m.shape[:2] != (H, W) or float(m.max()) <= 0.0:
            continue
        phi = getattr(c, phi_name, None)
        G   = getattr(c, gen_name, None)
        if phi is None or G is None:
            continue
        phi = _np.asarray(phi, _np.float32)
        Fdict = compute_field_strength(phi, _np.asarray(G, _np.float32))
        Fxy = _np.asarray(Fdict.get("xy", 0.0), _np.float32)  # (H,W,K,K)
        if Fxy.shape[:2] != (H, W):
            continue
        Fx = _np.sqrt(_np.clip(_np.sum(Fxy * Fxy, axis=(-2, -1)), 0.0, _np.finfo(_np.float32).max)).astype(_np.float32)
        num += (m * Fx)
        den += _np.maximum(m, 0.0)

    F = _np.zeros((H, W), _np.float32)
    sel = den > 1e-6
    F[sel] = (num[sel] / _np.maximum(den[sel], 1e-6)).astype(_np.float32)
    return _np.exp(-float(gamma) * _np.clip(F, 0.0, _np.finfo(_np.float32).max)).astype(_np.float32)




def directed_kl_weight_after_transport(
    Ai, Aj,
    mu_i, S_i, mu_j, S_j,
    *, fiber, H, W, K, ov, tau,
    assume_diag_is_stddev=True,
    debug=False,
    # NEW toggles (safe defaults)
    use_cached_omega=True,
    store_omega=None,          # None -> read config.cache_omega_fields else bool
):
    """
    w(x) = exp(- KL( N_i || T_{j->i}(N_j) ) / tau ) on overlap 'ov'.
    Uses SO(3) transport Ω_ij = exp(φ_i) · exp(-φ_j) (or model φ̃ for fiber='p').

    Cache policy:
      1) Try Ai.Omega_cache[Aj.id] / Omega_tilde_cache (full fields).
      2) Else use cached exp fields (Ai._exp_phi * Aj._exp_neg_phi, etc.), sliced to ov.
      3) Else compute exp(φ) on the fly (ov subset only), then (optionally) store.
    """
    import numpy as np
    from numerical_utils import sanitize_sigma, safe_inv
   

    if not np.any(ov):
        return np.zeros((H, W), np.float32)

    try:
        import config as _cfg
        if store_omega is None:
            store_omega = bool(getattr(_cfg, "cache_omega_fields", False))
        group_name = getattr(_cfg, "group_name", "so3")
    except Exception:
        class _C: pass
        _cfg = _C()
        if store_omega is None:
            store_omega = False
        group_name = "so3"

    # Overlap indices once
    iy, ix = np.nonzero(ov)

    # Slice means/covs on overlap
    mui = mu_i[iy, ix]  # (M,K)
    muj = mu_j[iy, ix]  # (M,K)
    Si  = S_i[iy, ix]   # (M,K,K) or (M,K)
    Sj  = S_j[iy, ix]

    # Ensure (M,K,K) SPD arrays (diagonal → full)
    if Si.ndim == 2:
        diag = Si.astype(np.float32)
        if assume_diag_is_stddev:
            diag = diag * diag
        Si = np.einsum("mk,ij->mij", diag, np.eye(K, dtype=np.float32), optimize=True)
    if Sj.ndim == 2:
        diag = Sj.astype(np.float32)
        if assume_diag_is_stddev:
            diag = diag * diag
        Sj = np.einsum("mk,ij->mij", diag, np.eye(K, dtype=np.float32), optimize=True)

    # ---- helper: get Ω on the overlap subset (M,K,K) in a cache-first way ----
    def _omega_subset_on_overlap():
        # 1) full Ω cache (fast path)
        if use_cached_omega:
            if fiber == "q":
                Om_full = getattr(Ai, "Omega_cache", {}).get(int(getattr(Aj, "id", -1)))
            else:
                Om_full = getattr(Ai, "Omega_tilde_cache", {}).get(int(getattr(Aj, "id", -1)))
            if Om_full is not None and getattr(Om_full, "shape", None) and Om_full.shape[:2] == (H, W):
                return Om_full[iy, ix]  # (M,K,K)

        # 2) exp caches → multiply on the subset only
        if fiber == "q":
            Ei  = getattr(Ai, "_exp_phi", None)
            EjN = getattr(Aj, "_exp_neg_phi", None)
        else:
            Ei  = getattr(Ai, "_exp_phi_model", None)
            EjN = getattr(Aj, "_exp_neg_phi_model", None)

        if Ei is not None and EjN is not None and Ei.shape[:2] == (H, W) and EjN.shape[:2] == (H, W):
            Ei_s  = Ei[iy, ix]   # (M,K,K)
            EjN_s = EjN[iy, ix]  # (M,K,K)
            return Ei_s @ EjN_s

        # 3) build exp(φ) on the fly (subset); try to cache small as we go
        try:
            from omega import exp_lie_algebra_irrep
        except Exception:
            raise RuntimeError("omega.exp_lie_algebra_irrep not available to build transports.")

        # Resolve generators (don’t assume agents carry them)
        try:
            gens = (Ai.generators_q if fiber == "q" else Ai.generators_p)
        except Exception:
            gens = None
        if gens is None:
            try:
                from get_generators import get_generators
                gens = get_generators(group_name, K)
            except Exception:
                raise RuntimeError(f"Missing generators for fiber='{fiber}', K={K}")

        # Build Ei, EjN on the overlap subset
        if fiber == "q":
            phi_i = Ai.phi[iy, ix]
            phi_j = Aj.phi[iy, ix]
        else:
            phi_i = Ai.phi_model[iy, ix]
            phi_j = Aj.phi_model[iy, ix]

        Ei_s  = np.stack([exp_lie_algebra_irrep(phi_i[m], gens)  for m in range(phi_i.shape[0])], axis=0)
        EjN_s = np.stack([exp_lie_algebra_irrep(-phi_j[m], gens) for m in range(phi_j.shape[0])], axis=0)
        Om_s  = Ei_s @ EjN_s  # (M,K,K)

        # Optionally store full Ω (expensive memory) or at least exp caches
        if store_omega:
            try:
                # if we have full exp fields, populate them; else build full once via vectorized path
                if fiber == "q":
                    if getattr(Ai, "_exp_phi", None) is None:
                        # Build full once (vectorized) to be consistent
                        Ei_full  = np.zeros((H, W, K, K), np.float32)
                        EjN_full = np.zeros((H, W, K, K), np.float32)
                        Ei_full[iy, ix]  = Ei_s
                        EjN_full[iy, ix] = EjN_s
                        Ai._exp_phi  = Ei_full
                        Aj._exp_neg_phi = EjN_full
                    cache = Ai.Omega_cache
                else:
                    if getattr(Ai, "_exp_phi_model", None) is None:
                        Ei_full  = np.zeros((H, W, K, K), np.float32)
                        EjN_full = np.zeros((H, W, K, K), np.float32)
                        Ei_full[iy, ix]  = Ei_s
                        EjN_full[iy, ix] = EjN_s
                        Ai._exp_phi_model  = Ei_full
                        Aj._exp_neg_phi_model = EjN_full
                    cache = Ai.Omega_tilde_cache
                # store a sparse/full Ω only if we already have full exp fields
                if getattr(Ai, "_exp_phi" if fiber=="q" else "_exp_phi_model", None) is not None and \
                   getattr(Aj, "_exp_neg_phi" if fiber=="q" else "_exp_neg_phi_model", None) is not None:
                    Om_full = (Ai._exp_phi  if fiber=="q" else Ai._exp_phi_model) @ \
                              (Aj._exp_neg_phi if fiber=="q" else Aj._exp_neg_phi_model)
                    cache[int(getattr(Aj, "id", -1))] = Om_full.astype(np.float32, copy=False)
            except Exception:
                pass

        return Om_s

    # Build Ω subset (M,K,K)
    Omega_ij = _omega_subset_on_overlap()  # (M,K,K)

    if debug:
        RtR = np.einsum("mab,mac->mbc", Omega_ij, Omega_ij, optimize=True)
        I   = np.broadcast_to(np.eye(K, dtype=np.float32), RtR.shape)
        if not np.allclose(RtR, I, atol=1e-4):
            print(f"[DKL] non-orthogonal Ω_ij detected for fiber={fiber}")

    # Transport j → i on overlap
    muj_t = np.einsum("mab,mb->ma", Omega_ij, muj, optimize=True)          # (M,K)
    OmT   = np.swapaxes(Omega_ij, -1, -2)
    Sj_t  = np.einsum("mab,mbc,mdc->mad", Omega_ij, Sj, OmT, optimize=True)

    # SPD sanitize
    Si   = sanitize_sigma(Si)
    Sj_t = sanitize_sigma(Sj_t)

    # KL per overlap pixel
    d = kl_gaussians(mui, Si, muj_t, Sj_t).astype(np.float32)
    d = np.clip(np.nan_to_num(d, nan=0.0, posinf=1e6, neginf=0.0), 0.0, 1e6)

    # Weights and scatter back
    invT = 1.0 / max(1e-8, float(tau))
    wvec = np.exp(-d * invT).astype(np.float32)
    w = np.zeros((H, W), np.float32)
    w[iy, ix] = wvec
    return w





def geometric_blend(wq, wp, alpha):
    """
    Geometric blend across fibers: w = wq^(1-alpha) * wp^alpha, numerically stable.
    """
    a = float(alpha)
    if a <= 0.0:
        return wq
    if a >= 1.0:
        return wp
    return _np.exp((1.0 - a) * _np.log(_np.maximum(wq, 1e-12)) +
                   a * _np.log(_np.maximum(wp, 1e-12)))


def apply_evidence_modulators(w, Mi, Mj, ov, *, A=None, agree_power=1.0, BF=None):
    """
    Combine per-pair alignment weight with spatial terms:
      wij = Mi * Mj * w * 1_ov * (BF if provided) * (A^agree_power if provided)
    """
    wij = (Mi * Mj) * w
    wij *= ov.astype(_np.float32)
    if BF is not None:
        wij *= BF
    if (A is not None) and (float(agree_power) != 0.0):
        wij *= (_np.asarray(A, _np.float32) ** float(agree_power))
    return wij.astype(_np.float32, copy=False)




