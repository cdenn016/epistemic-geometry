# -*- coding: utf-8 -*-
"""
runtime_context.py
Lightweight, level-aware run context for emergent parents & detectors.
Keeps heavy imports out to avoid cycles; DetectorState is created lazily.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, Optional, Callable, List, Tuple

import numpy as np


# ─────────────────────────────────────────────────────────────────────────────
# Same-level graph & cross-scale link carriers
# ─────────────────────────────────────────────────────────────────────────────

# --- add near top-level defs ---

class _Dirty:
    __slots__ = ("agents", "kl")
    def __init__(self):
        self.agents = set()   # ids of agents/parents with stale Ω/Λ/fields
        self.kl     = set()   # ids of children whose KL fields need refresh

def _agent_id(a):
    return int(getattr(a, "id", id(a)))

def _collect_by_ids(all_agents, ids):
    idx = { _agent_id(a): a for a in all_agents }
    return [idx[i] for i in ids if i in idx]



def _agent_id(a):
    """Robustly get an integer id for an agent/parent object."""
    # prefer explicit .id; fall back to Python's object id
    return int(getattr(a, "id", id(a)))

def _collect_by_ids(all_agents, ids):
    """
    Return the subset of objects from `all_agents` whose _agent_id is in `ids`.
    Ignores ids not present. Order follows the order of `all_agents`.
    """
    if not ids:
        return []
    # one pass to map id -> object
    idx = {}
    for a in all_agents:
        try:
            idx[_agent_id(a)] = a
        except Exception:
            # if an object can't produce an id, just skip it
            continue
    # preserve all_agents order (not ids order) for cache-coherent batching
    wanted = set(int(i) for i in ids)
    return [a for a in all_agents if _agent_id(a) in wanted]


@dataclass
class LevelGraph:
    level: int
    agent_ids: List[int]                                     # ordered ids at this level
    neighbors: Dict[int, List[int]] = field(default_factory=dict)  # id -> [neighbor ids]
    # optional per-edge caches, keyed by (i,j)
    Omega_cache: Dict[Tuple[int, int], np.ndarray] = field(default_factory=dict)
    Omega_tilde_cache: Dict[Tuple[int, int], np.ndarray] = field(default_factory=dict)


@dataclass
class CrossScaleLink:
    low_level: int
    high_level: int
    child_ids: List[int]                                     # ids at low_level
    parent_ids: List[int]                                    # ids at high_level
    labels: np.ndarray                                       # shape (len(child_ids),), parent id or -1
    # Optional precomputed Λ fields (broadcastable to grids, or callables)
    Lambda_dn_q: Optional[np.ndarray] = None
    Lambda_dn_p: Optional[np.ndarray] = None
    Lambda_up_q: Optional[np.ndarray] = None
    Lambda_up_p: Optional[np.ndarray] = None


def _lazy_detector_factory() -> Any:
    """
    Lazily import and construct a DetectorState to avoid import cycles.
    You can replace this with a different factory if needed.
    """
    try:
        from detector import DetectorState  # local import to avoid cycle at module load
        return DetectorState()
    except Exception:
        class _Stub:
            pass
        return _Stub()


# ─────────────────────────────────────────────────────────────────────────────
# Unified Runtime Context (legacy views + new level-graphs + cross-scale links)
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class RuntimeCtx:
    # ---- Legacy lvl-1 views (kept for backward compat) ---------------------
    parents_by_region: Dict[int, Any] = field(default_factory=dict)  # pid -> parent Agent (mounted level)
    next_parent_id: int = 1
    global_step: int = 0
    detector_state: Optional[Any] = None  # set by detector on first use (lazy)

    # ---- Multi-level stores (sources of truth) -----------------------------
    parents_by_level: Dict[int, Dict[int, Any]] = field(default_factory=dict)       # L -> {pid: Agent}
    next_parent_id_by_level: Dict[int, int] = field(default_factory=dict)           # L -> next pid
    detector_state_by_level: Dict[int, Any] = field(default_factory=dict)           # L -> DetectorState
    children_latest_by_level: Dict[int, Any] = field(default_factory=dict)          # (L-1) -> list[Agent] for viz

    # New, level-agnostic registries
    agents_by_level: Dict[int, Dict[int, Any]] = field(default_factory=dict)        # L -> {id: Agent}
    graphs: Dict[int, LevelGraph] = field(default_factory=dict)                     # L -> LevelGraph
    xlinks: Dict[Tuple[int, int], CrossScaleLink] = field(default_factory=dict)     # (L_lo, L_hi) -> link

    # ---- Mounted level bookkeeping (legacy exposure) -----------------------
    _mounted_level: Optional[int] = None

    # -----------------------------------------------------------------------
    # Registration / graph helpers
    # -----------------------------------------------------------------------
    def register_agents(self, level: int, agents: List[Any]) -> None:
        """Install/refresh the agent registry for a level."""
        lvl = self.agents_by_level.setdefault(level, {})
        lvl.clear()
        for a in agents:
            aid = int(getattr(a, "id"))
            lvl[aid] = a

    def build_neighbors(self, level: int, neighbor_map: Dict[int, List[int]]) -> None:
        """Install a neighbor graph for a level. IDs must be in agents_by_level[level]."""
        ids = list(self.agents_by_level.get(level, {}).keys())
        nm: Dict[int, List[int]] = {i: [j for j in neighbor_map.get(i, []) if j in ids] for i in ids}
        self.graphs[level] = LevelGraph(level=level, agent_ids=ids, neighbors=nm)

    def neighbors_of(self, level: int, agent_id: int) -> List[int]:
        """Return same-level neighbor ids (fallback to empty list)."""
        g = self.graphs.get(level)
        if not g:
            return []
        return g.neighbors.get(agent_id, [])

    def agent(self, level: int, agent_id: int) -> Any:
        """Fetch agent by (level, id)."""
        return self.agents_by_level[level][agent_id]

    def agents(self, level: int) -> List[Any]:
        """Ordered list of agents at a level."""
        if level not in self.graphs:
            return list(self.agents_by_level.get(level, {}).values())
        g = self.graphs[level]
        return [self.agents_by_level[level][aid] for aid in g.agent_ids]

    # -----------------------------------------------------------------------
    # Cross-scale helpers
    # -----------------------------------------------------------------------
    def set_crossscale_labels(
        self, low_level: int, high_level: int,
        child_ids: List[int], parent_ids: List[int], labels: np.ndarray
    ) -> None:
        """Create/refresh the cross-scale link with labeling."""
        labels = np.asarray(labels).astype(int)
        self.xlinks[(low_level, high_level)] = CrossScaleLink(
            low_level=low_level, high_level=high_level,
            child_ids=[int(x) for x in child_ids],
            parent_ids=[int(x) for x in parent_ids],
            labels=labels,
        )

    def set_lambda_fields(
        self, low_level: int, high_level: int, *,
        Lambda_dn_q=None, Lambda_dn_p=None, Lambda_up_q=None, Lambda_up_p=None
    ) -> None:
        link = self.xlinks.get((low_level, high_level))
        if not link:
            raise RuntimeError(f"No cross-scale link ({low_level},{high_level}) to attach Λ fields.")
        link.Lambda_dn_q = Lambda_dn_q
        link.Lambda_dn_p = Lambda_dn_p
        link.Lambda_up_q = Lambda_up_q
        link.Lambda_up_p = Lambda_up_p

    def crossscale_link_touching(self, level: int) -> List[CrossScaleLink]:
        """Return all links where this level participates (as low or high)."""
        out: List[CrossScaleLink] = []
        for (lo, hi), lk in self.xlinks.items():
            if lo == level or hi == level:
                out.append(lk)
        return out

    def parent_of_child(self, low_level: int, high_level: int, child_id: int) -> int:
        """Return parent id for child or -1 if unlabeled."""
        lk = self.xlinks.get((low_level, high_level))
        if not lk:
            return -1
        try:
            idx = lk.child_ids.index(int(child_id))
        except ValueError:
            return -1
        return int(lk.labels[idx]) if 0 <= idx < len(lk.labels) else -1

    # -----------------------------------------------------------------------
    # Legacy mount (kept for detector & old code)
    # -----------------------------------------------------------------------
    def mount_level(
        self,
        L: int,
        detector_factory: Optional[Callable[[], Any]] = None,
    ) -> None:
        """
        Expose level-L stores through legacy attributes:
          parents_by_region, next_parent_id, detector_state.
        Creates missing level buckets on demand.
        """
        if detector_factory is None:
            detector_factory = _lazy_detector_factory

        if L not in self.parents_by_level:
            self.parents_by_level[L] = {}
        if L not in self.next_parent_id_by_level:
            self.next_parent_id_by_level[L] = 1
        if L not in self.detector_state_by_level or self.detector_state_by_level[L] is None:
            self.detector_state_by_level[L] = detector_factory()

        # mount the legacy views
        self.parents_by_region = self.parents_by_level[L]
        self.next_parent_id = self.next_parent_id_by_level[L]
        self.detector_state = self.detector_state_by_level[L]
        self._mounted_level = L

    def persist_mounted_level(self) -> None:
        """Persist legacy-attribute edits back into the mounted level store."""
        L = self._mounted_level
        if L is None:
            return
        self.parents_by_level[L] = self.parents_by_region or {}
        self.next_parent_id_by_level[L] = int(self.next_parent_id or 1)
        self.detector_state_by_level[L] = self.detector_state

    def with_level(self, L: int, detector_factory: Optional[Callable[[], Any]] = None) -> "RuntimeCtx":
        self.mount_level(L, detector_factory=detector_factory)
        return self


def ensure_runtime_defaults(ctx: Optional[RuntimeCtx]) -> RuntimeCtx:
    """Ensure a valid RuntimeCtx with sane defaults. Does not mount a level."""
    if ctx is None:
        ctx = RuntimeCtx()
    if ctx.parents_by_region is None:
        ctx.parents_by_region = {}
    if ctx.next_parent_id is None:
        ctx.next_parent_id = 1
    if ctx.global_step is None:
        ctx.global_step = 0
    return ctx


# Optional module-level singleton
runtime_ctx = RuntimeCtx()

__all__ = [
    "LevelGraph",
    "CrossScaleLink",
    "RuntimeCtx",
    "runtime_ctx",
    "ensure_runtime_defaults",
]
