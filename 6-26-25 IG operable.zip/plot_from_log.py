import os
import pandas as pd
import pickle
import matplotlib.pyplot as plt

from IG_metrics import log_all_metrics_IG  # Adjust import based on your project structure


def plot_from_log(log_path, output_dir="plots", show_plots=True, save_plots=True):
    """
    Load a metrics log (pickle or CSV), parse it into a DataFrame, and plot all metrics over time.

    Parameters
    ----------
    log_path : str
        Path to the metrics log file. Can be a .pkl (pickled list of dicts) or .csv file.
    output_dir : str, optional
        Directory where to save plots. Default is "plots" in current working directory.
    show_plots : bool, optional
        Whether to display plots interactively. Default is True.
    save_plots : bool, optional
        Whether to save plots to files. Default is True.
    """
    # Load log into DataFrame
    if log_path.endswith('.pkl'):
        with open(log_path, 'rb') as f:
            metrics = pickle.load(f)
        df = pd.DataFrame(metrics)
    elif log_path.endswith('.csv'):
        df = pd.read_csv(log_path)
    else:
        raise ValueError("Unsupported log format: must be .pkl or .csv")

    # Ensure 'step' (or time) is the index
    if 'step' in df.columns:
        df.set_index('step', inplace=True)
    elif 'time' in df.columns:
        df.set_index('time', inplace=True)
    else:
        df.index.name = 'index'

    # Create output directory if saving
    if save_plots:
        os.makedirs(output_dir, exist_ok=True)

    # Plot each metric
    for metric in df.columns:
        plt.figure()
        plt.plot(df.index, df[metric], marker='o', linestyle='-')
        plt.xlabel(df.index.name)
        plt.ylabel(metric)
        plt.title(f"{metric} over {df.index.name}")
        plt.grid(True)

        if save_plots:
            fname = os.path.join(output_dir, f"{metric}.png")
            plt.savefig(fname, bbox_inches='tight')
            print(f"Saved plot: {fname}")

        if show_plots:
            plt.show()
        else:
            plt.close()


if __name__ == '__main__':
    import argparse

    parser = argparse.ArgumentParser(
        description="Plot all metrics from a metrics log file as a function of time or step."
    )
    parser.add_argument('log_path', nargs='?', default='checkpoints/metric_log.pkl',
                        help='Path to the .pkl or .csv metrics log file (default: checkpoints/metric_log.pkl)')
    parser.add_argument('--out-dir', dest='output_dir', default='plots', help='Directory to save plots')
    parser.add_argument('--hide-plots', dest='show_plots', action='store_false', help="Do not display plots interactively")
    parser.add_argument('--skip-save', dest='save_plots', action='store_false', help="Do not save plots to files")
    parser.add_argument('--output-dir', default='plots', help='Directory to save plots')
    parser.add_argument('--no-show', action='store_true', help="Do not display plots interactively")
    parser.add_argument('--no-save', action='store_true', help="Do not save plots to files")
    args = parser.parse_args()

    plot_from_log(
        log_path=args.log_path,
        output_dir=args.output_dir,
        show_plots=not args.no_show,
        save_plots=not args.no_save
    )
