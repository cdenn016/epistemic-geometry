# -*- coding: utf-8 -*-
"""
Created on Tue Jun 24 18:49:58 2025

@author: chris and christine
"""

from abc import ABC, abstractmethod
import numpy as np






def softplus(x):
    return np.log1p(np.exp(x))

class ExponentialFamily(ABC):
    """
    Abstract base class for exponential-family distributions.
    Coordinates are natural parameters \theta.
    """
    def __init__(self, theta: np.ndarray):
        self.theta = theta  # natural parameters

    @property
    @abstractmethod
    def dimension(self) -> int:
        """Number of natural parameters"""
        pass

    @property
    @abstractmethod
    def expectation(self) -> np.ndarray:
        """Return m-coordinates \eta = E[T(X)]"""
        pass

    @classmethod
    @abstractmethod
    def from_expectation(cls, eta: np.ndarray) -> 'ExponentialFamily':
        """Construct instance from expectation coordinates"""
        pass

    @abstractmethod
    def sufficient_stats(self, x: np.ndarray) -> np.ndarray:
        """Compute T(x)"""
        pass

    @abstractmethod
    def log_partition(self) -> float:
        """Compute log-partition function \psi(\theta)"""
        pass

    @abstractmethod
    def grad_log_partition(self) -> np.ndarray:
        """Gradient of log-partition: E[T(X)]"""
        pass

    def kl(self, other: 'ExponentialFamily') -> float:
        """
        KL divergence KL[p(theta) || p(theta')]
        = (psi(theta') - psi(theta)) - <theta' - theta, grad psi(theta)>
        """
        psi_self = self.log_partition()
        psi_other = other.log_partition()
        grad_self = self.grad_log_partition()
        delta = other.theta - self.theta
        return (psi_other - psi_self) - np.dot(delta, grad_self)

    @abstractmethod
    def push_forward(self, Omega: callable) -> 'ExponentialFamily':
        """
        Return new distribution corresponding to q'(x) = q(Omega^{-1}(x)).
        Implementation is family-specific.
        """
        pass


class GaussianFamily(ExponentialFamily):
    """
    Multivariate Gaussian with diagonal covariance.
    Natural parameters: theta = [theta1 (mean/var), theta2 (-1/(2*var))]
    """
    def __init__(self, theta: np.ndarray):
        assert theta.shape[-1] % 2 == 0, "Gaussian theta length must be even"
        super().__init__(theta)
        self.K = theta.shape[-1] // 2

    @property
    def dimension(self) -> int:
        return 2 * self.K

    @property
    def expectation(self) -> np.ndarray:
        # eta = [E[x], E[x^2]]
        theta1 = self.theta[..., :self.K]
        theta2 = self.theta[..., self.K:]
        var = -1.0 / (2.0 * theta2)
        mean = theta1 * var
        second = var + mean**2
        return np.concatenate([mean, second], axis=-1)

    @classmethod
    def from_mu_sigma(cls, mu: np.ndarray, sigma2: np.ndarray) -> 'GaussianFamily':
        theta1 = mu / sigma2
        theta2 = -0.5 / sigma2
        theta = np.concatenate([theta1, theta2])
        return cls(theta)

    @classmethod
    def from_expectation(cls, eta: np.ndarray) -> 'GaussianFamily':
        K = eta.shape[0] // 2
        mean = eta[:K]
        second = eta[K:]
        var = second - mean**2
        return cls.from_mu_sigma(mean, var)

    def sufficient_stats(self, x: np.ndarray) -> np.ndarray:
        # x shape (..., K)
        stats1 = x
        stats2 = x**2
        return np.concatenate([stats1, stats2], axis=-1)

    def log_partition(self) -> float:
        # theta1, theta2 have shape (..., K)
        theta1 = self.theta[..., :self.K]
        theta2 = self.theta[..., self.K:]
        # psi = -0.25 * ∑_i (theta1_i^2 / theta2_i) + 0.5 * ∑_i log(-π / theta2_i)
        term1 = -0.25 * np.sum(theta1**2 / theta2, axis=-1)
        term2 = 0.5  * np.sum(np.log(-np.pi / theta2), axis=-1)
        return term1 + term2

    def grad_log_partition(self) -> np.ndarray:
        # theta1, theta2 have shape (..., K)
        theta1 = self.theta[..., :self.K]
        theta2 = self.theta[..., self.K:]
        # grad wrt theta1 = -0.5 * theta1 / theta2
        grad1 = -0.5 * theta1 / theta2
        # grad wrt theta2 = 0.25 * theta1^2 / theta2^2 - 0.5 / theta2
        grad2 =  0.25 * theta1**2 / theta2**2 - 0.5 / theta2
        # concatenate along last axis to get shape (..., 2K)
        return np.concatenate([grad1, grad2], axis=-1)

    def push_forward(self, Omega: np.ndarray) -> "GaussianFamily":
       """
       Transport each local Gaussian by x ↦ Omega(c)·x.
       For non-orthonormal groups (e.g. SL(2,R)), covariance transforms as
           Σ' = Omega · Σ · Omega^T.
           We assume diagonal Σ in the original chart, so we build full Σ', then
           re-extract the diagonal variances for the next diagonal-Gaussian approximation.
           """
       θ   = self.theta
       K   = θ.shape[-1] // 2
       # natural→(μ,σ²)
       theta1 = θ[..., :K]
       theta2 = θ[..., K:]
       var     = -1.0 / (2.0 * theta2)
       mu      = theta1 * var

       # build full covariance Σ = diag(var)  → shape (...,K,K)
       # then Σ' = Omega @ Σ @ Omega^T
       # Omega is (...,K,K)
       # first compute Omega @ Σ: (...,K,K) × (...,K,K) → (...,K,K)
       Omega_var = Omega * var[..., :, None]               # broadcast multiply cols
       Sigma_p   = np.einsum('...ij,...kj->...ik', Omega_var, Omega)

       # transform mean: μ' = Omega · μ
       mu_p = np.einsum('...ij,...j->...i', Omega, mu)

        # now approximate Σ' by its diagonal (for next diagonal-Gaussian)
       var_p = np.diagonal(Sigma_p, axis1=-2, axis2=-1)    # (...,K)

       # back to natural parameters
       new_theta1 = mu_p / var_p
       new_theta2 = -0.5 / var_p
       new_theta  = np.concatenate([new_theta1, new_theta2], axis=-1)
       return self.__class__(new_theta)


    def entropy(self) -> np.ndarray:
        """
        Pointwise Shannon entropy H[p] of the diagonal Gaussian:
          H = A(θ) - θ · ∇A(θ)
        Returns an array of shape self.theta.shape[:-1].
        """
        # A(θ): log‐partition function (array shape spatial dims)
        A_val = self.log_partition()
        # η = ∇A(θ): expectation parameters (array shape (..., 2K))
        eta   = self.grad_log_partition()
        # θ: natural parameters (array shape (..., 2K))
        theta = self.theta

        # H = A - <θ, η>
        #   = A(θ) - sum_over_components θ_i * η_i
        return A_val - np.sum(theta * eta, axis=-1)
