import os
import pandas as pd

from get_generators import get_generators
from config_utils import set_config_from_params
from IG_agents import initialize_agents
from IG_update_rules import synchronous_step
from IG_metrics import log_all_metrics_IG

import config


def run_simulation(outdir="checkpoints"):
    # (re)load any overrides you want into config
    set_config_from_params({})

    # prep output dir
    os.makedirs(outdir, exist_ok=True)

    # precompute your Lie‑algebra generators
    gens = get_generators(config.group_name, config.K)

    # initialize fresh agents
    lie_dim = gens.shape[0]
    agents = initialize_agents(
        seed            = getattr(config, "agent_seed", None),
        domain_size     = config.domain_size,
        N               = config.N,
        K               = config.K,
        lie_algebra_dim = lie_dim,
        visualize       = False,
        fixed_location  = True
    )
    import numpy as np

# pick agent 0 (or whichever) and compute its Ω cache
    agent = agents[0]
    Ω_b = agent.Omega_belief     # this will trigger your batch expm if not already cached
    phi = agent.phi_belief

# find the pixel with the largest |φ|
    phi_mags = np.linalg.norm(phi, axis=-1)
    imax, jmax = np.unravel_index(np.argmax(phi_mags), phi_mags.shape)

    print(f"[DEBUG run_sim] Agent 0 max |φ| = {phi_mags[imax,jmax]:.6e} at pixel ({imax},{jmax})")
    np.set_printoptions(precision=6, suppress=False)
    print("[DEBUG run_sim] φ vector at that pixel:", phi[imax,jmax])
    print("[DEBUG run_sim] Ω matrix at that pixel:")
    print(Ω_b[imax, jmax])

    # container for per‑agent logs (filled during synchronous_step)
    # ensure each agent has an empty metrics_log
    for ag in agents:
        ag.metrics_log = []

    print("Using learning rates:")
    print("  eta_q          ", config.eta_q)
    print("  eta_p          ", config.eta_p)
    print("  eta_phi_belief ", config.eta_phi_belief)
    print("  eta_phi_model  ", config.eta_phi_model)

    # run the Euler‑step loop
# run the Euler-step loop and collect global summaries
    all_metrics = []
    for step in range(config.steps):
        print(f"[STEP {step+1}/{config.steps}]")
        agents = synchronous_step(
            agents,
            params=None,  # all rates & weights come from config
            n_jobs=config.num_cores
            )
    # log global metrics summary this step
        summary = log_all_metrics_IG(
            agents,
            step,
            weights=None,
            support_eps=None,
            n_jobs=config.num_cores
            )
        all_metrics.append(summary)

# assemble into DataFrame of global summaries
    metrics_df = pd.DataFrame(all_metrics)
    metrics_df.to_pickle(os.path.join(outdir, "metric_log.pkl"))
    return agents, metrics_df

if __name__ == "__main__":
    # Run simulation with values directly from config
    agents, metrics_df = run_simulation(outdir=config.checkpoint_dir)
    print(metrics_df.head())
    print("Final θ means:", [ag.q_fam.theta.mean() for ag in agents])
    print("Final φ stds:", [ag.phi_belief.std() for ag in agents])
