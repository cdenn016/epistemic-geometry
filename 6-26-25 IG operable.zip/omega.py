import numpy as np
import config
from scipy.linalg import expm


_EPS = config.log_eps

def repair_if_forgotten(q: np.ndarray, eps: float, threshold: float = 1e-6) -> np.ndarray:
    """
    If a belief vector q has near-zero total mass, inject small uniform mass
    so that belief learning can resume.

    Parameters:
        q         : (K,) belief vector
        eps       : small clipping constant
        threshold : total mass threshold to trigger repair

    Returns:
        q_repaired : repaired or original belief vector
    """
    total_mass = np.sum(q)
    if total_mass < threshold or not np.isfinite(total_mass):
        K = q.shape[-1]
        q = np.random.dirichlet(np.ones(K)) * eps * K
    else:
        q = np.clip(q, eps, 1.0)
        q /= np.sum(q) + eps
    return q

def compute_inter_agent_omega(
    phi_i: np.ndarray,
    phi_j: np.ndarray,
    coord: tuple[int, ...],
    generators: np.ndarray,
    use_commutator: bool = False,
    phi_key: str = "phi",
) -> np.ndarray:
    """
    Compute Ω_{ij}(coord) = exp(φ_i(coord)/e) · exp(-φ_j(coord)/e)
    or the abelian shortcut if use_commutator=True.

    Args:
        phi_i, phi_j: φ fields
        coord: spatial coordinate (tuple)
        generators: Lie algebra generators (d, K, K)
        use_commutator: whether to use exp(φ_i - φ_j) instead
        phi_key: "phi" or "phi_model" — determines e scaling

    Returns:
        Ω_{ij}(x): shape (K, K)
    """
    from config import e_belief, e_model
    e = e_belief if phi_key == "phi" else e_model

    # 1) Extract the Lie-algebra vectors at coord
    φi_vec = phi_i[coord] / e
    φj_vec = phi_j[coord] / e

    # 2) Delegate to central helper
    Ω = build_inter_agent_omega(
        φi_vec[None],       # shape (1, d)
        φj_vec[None],       # shape (1, d)
        generators,
        config=config,
        use_commutator=use_commutator
    )  # returns shape (1, K, K)

    return Ω[0]

def repair_if_forgotten_batch(q: np.ndarray, eps: float, threshold: float = 1e-6) -> np.ndarray:
    """
    Repair a batch of belief vectors where some may have near-zero total mass.

    Parameters:
        q         : (..., K) array of belief vectors
        eps       : small floor value (e.g., config.log_eps)
        threshold : total mass below which a vector is considered "forgotten"

    Returns:
        q_repaired : repaired batch, same shape as q
    """
    q = np.nan_to_num(q, nan=0.0, posinf=0.0, neginf=0.0)
    orig_shape = q.shape
    K = q.shape[-1]
    q_flat = q.reshape(-1, K)
    norms = np.sum(q_flat, axis=-1, keepdims=True)

    forgotten = (norms < threshold) | (~np.isfinite(norms))

    if np.any(forgotten):
        n_forgotten = np.sum(forgotten)
        repaired = np.random.dirichlet(np.ones(K), size=n_forgotten) * eps * K
        q_flat[forgotten.squeeze()] = repaired

    q_flat = np.clip(q_flat, eps, 1.0)
    q_flat /= np.sum(q_flat, axis=-1, keepdims=True) + eps
    return q_flat.reshape(orig_shape)

def kl_divergence(q1, q2, eps = _EPS):
    q1 = np.clip(q1, eps, 1.0)
    q2 = np.clip(q2, eps, 1.0)
    return np.sum(q1 * (np.log(q1) - np.log(q2)), axis=-1)

def adaptive_expm(G, clip_norm=None):
    """
    Safe exponentiation of a Lie algebra matrix G.
    
    Parameters:
    - G: (K, K) numpy array
    - clip_norm: float or None. If set, scales G down if ‖G‖ > clip_norm.

    Returns:
    - expm(G) or expm(scaled G)
    """
    import numpy as np
    from scipy.linalg import expm

    norm_G = np.linalg.norm(G)
    if clip_norm is not None and norm_G > clip_norm:
        G = G * (clip_norm / norm_G)
    return expm(G)



def exp_lie_algebra_operator(
    v,
    generators,
    use_expm=True,
    threshold=1e-3,
    max_norm=20,
    group_name=None,  # 'so3', 'sl2r', 'su2', etc.
):
    """
    Compute exp(Σ_a v_a T_a) for arbitrary Lie algebra representation.

    Parameters:
    - v: np.ndarray shape (dim_G,), Lie algebra coefficients
    - generators: np.ndarray shape (dim_G, K, K), generators for Lie algebra rep
    - use_expm: bool, use scipy expm for large norms
    - threshold: float, norm threshold below which to use Taylor approx
    - max_norm: float, max allowed norm to prevent blowup
    - group_name: str or None, optionally specify to apply group-specific handling

    Returns:
    - np.ndarray (K, K): the group element exp(Σ vᵃ Tₐ)
    """
    norm_v = np.linalg.norm(v)
    eps = 1e-16
    safe_norm = norm_v + eps

    scale = min(1.0, max_norm / safe_norm)
    v_scaled = v * scale

    G = np.einsum('a,aij->ij', v_scaled, generators)

    # === SO(3)-specific antisymmetrization for numerical stability ===
    if group_name == "so3":
        G = 0.5 * (G - G.T)

    if safe_norm < threshold or not use_expm:
        I = np.eye(G.shape[0], dtype=G.dtype)
        return I + G + 0.5 * (G @ G)
    else:
        return expm(G)

def exp_lie_algebra_irrep(v, generators, use_expm=True,
                          threshold=1e-3, max_norm=20,
                          group_name=None):
    import numpy as np
    from scipy.linalg import expm

    # flatten leading dims
    orig_shape = v.shape[:-1]
    d = v.shape[-1]
    K = generators.shape[-1]
    N = int(np.prod(orig_shape))
    v_flat = v.reshape((N, d))

    # compute G_flat: shape (N, K, K)
    # clamp norms
    norms = np.linalg.norm(v_flat, axis=1)
    scales = np.minimum(1, max_norm / np.maximum(norms, 1e-16))
    v_flat = v_flat * scales[:,None]
    G_flat = np.einsum('nd,dij->nij', v_flat, generators)

    # group cleanup
    if group_name == 'so3':
        G_flat = 0.5 * (G_flat - np.swapaxes(G_flat,1,2))
    elif group_name == 'su2':
        G_flat = 0.5 * (G_flat - np.swapaxes(G_flat.conj(),1,2))

    # exponentiate
    result_flat = np.empty_like(G_flat)
    small = norms < threshold
    I = np.eye(K)
    for idx in range(N):
        G_loc = G_flat[idx]
        if small[idx]:
            result_flat[idx] = I + G_loc + 0.5*(G_loc@G_loc)
        else:
            result_flat[idx] = expm(G_loc)

    # reshape back
    return result_flat.reshape((*orig_shape, K, K))


def batch_exp_lie_algebra_irrep(
    v_batch,
    generators,
    use_expm=True,
    threshold=1e-3,
    max_norm=20,
    group_name=None,
):
    """
    Compute a batch of exp(Σ v_a T_a) where T_a are Lie-algebra generators.

    Parameters:
    - v_batch: array of shape (..., dim_G)
    - generators: array of shape (dim_G, K, K)
    - use_expm: whether to use scipy.linalg.expm or Taylor for large norms
    - threshold: below this norm, use 2nd-order Taylor
    - max_norm: clamp norm of v before building G
    - group_name: e.g. "so3", "su2", "sl2r"

    Returns:
    - array of shape (..., K, K)
    """
    import numpy as np
    from scipy.linalg import expm

    # Flatten leading dims
    orig_shape = v_batch.shape[:-1]
    N = int(np.prod(orig_shape))
    dim_G = v_batch.shape[-1]
    K = generators.shape[-1]

    v_flat = v_batch.reshape(N, dim_G)

    # Clamp coefficient norms
    norms = np.linalg.norm(v_flat, axis=1)
    scales = np.minimum(1.0, max_norm / np.maximum(norms, 1e-16))
    v_flat = v_flat * scales[:, None]

    # Build Lie-algebra matrices
    G_flat = np.einsum('nd,dij->nij', v_flat, generators)

    # Group-specific cleanup
    if group_name == 'so3':
        G_flat = 0.5 * (G_flat - np.swapaxes(G_flat,1,2))
    elif group_name == 'su2':
        G_flat = 0.5 * (G_flat - np.swapaxes(G_flat.conj(),1,2))

    # Prepare output
    result_flat = np.empty_like(G_flat)
    small = norms < threshold
    I = np.eye(K)

    # Exponentiate each
    for idx in range(N):
        G_loc = G_flat[idx]
        if small[idx]:
            # 2nd-order Taylor
            result_flat[idx] = I + G_loc + 0.5 * (G_loc @ G_loc)
        else:
            # Safe expm with clipping via clip_norm
            result_flat[idx] = adaptive_expm(G_loc, clip_norm=max_norm)

    # Reshape back to spatial dims
    return result_flat.reshape(*orig_shape, K, K)


def batch_apply_omega(q_batch, omega_batch):
    """
    Apply a batch of group elements Ω to a batch of belief vectors q.

    Args:
        q_batch: np.ndarray with shape (..., K)
        omega_batch: np.ndarray with shape (..., K, K), must broadcast with q_batch

    Returns:
        Transformed batch: np.ndarray with shape (..., K)
    """
    # Validate batch dimensions match except for last dims
    assert q_batch.shape[-1] == omega_batch.shape[-2] == omega_batch.shape[-1], (
        f"Dimension mismatch: q_batch last dim {q_batch.shape[-1]} != "
        f"omega_batch last dims {omega_batch.shape[-2:]}"
    )

    # Use einsum to contract last dim of q_batch with last dim of omega_batch
    return np.einsum('...ij,...j->...i', omega_batch, q_batch)


def apply_omega(q_vec, omega):
    """
    Apply a single group matrix Ω to a belief vector or batch of vectors q_vec.

    Args:
        q_vec: np.ndarray with shape (K,) or (..., K)
        omega: np.ndarray with shape (K, K)

    Returns:
        Transformed vector(s) with shape same as q_vec
    """
    assert omega.shape[0] == omega.shape[1], "Omega must be square"
    assert q_vec.shape[-1] == omega.shape[0], (
        f"Dimension mismatch: q_vec last dim {q_vec.shape[-1]} != omega shape {omega.shape}"
    )

    # Contract last dim of q_vec with omega
    return np.einsum('ij,...j->...i', omega, q_vec)

def compute_spatial_gradient_matrix_field(A_field, axis):
    """
    Computes ∂_axis A where A is a field of KxK matrices at each point.
    A_field: shape (..., K, K)
    Returns: gradient ∂_axis A, shape (..., K, K)
    """
    grad = np.empty_like(A_field)
    K = A_field.shape[-1]
    for i in range(K):
        for j in range(K):
            grad[..., i, j] = np.gradient(A_field[..., i, j], axis=axis, edge_order=2)
    return grad


def compute_gauge_potential(phi):
    """
    Compute gauge potentials A_μ^a = ∂_μ φ^a for arbitrary Lie algebra and base dimension D.
        BE CAREFUL! CANNOT PASS THIS OUTPUT INTO COMMUTATOR WITHOUT CONVERTING
    Args:
        phi: np.ndarray, shape (..., d), where
             ... represents spatial dimensions (S_1,...,S_D),
             d = dim Lie algebra.

    Returns:
        A: tuple of length D, each entry np.ndarray of shape (..., d),
           spatial derivatives of phi along each base manifold dimension.
    """
    D = phi.ndim - 1  # subtract Lie algebra dimension axis
    spatial_axes = tuple(range(D))
    A = tuple(np.gradient(phi, axis=axis) for axis in spatial_axes)
    return A


def compute_commutator(A_mu, A_nu):
    """
    Compute matrix commutator [A_μ, A_ν] = A_μ A_ν - A_ν A_μ for batch matrices.

    Args:
        A_mu, A_nu: np.ndarray with shape (..., K, K)

    Returns:
        commutator: np.ndarray with shape (..., K, K)
    """
    return np.matmul(A_mu, A_nu) - np.matmul(A_nu, A_mu)




def compute_field_strength(phi, generators):
    """
    Computes F_{μν} = ∂_μ A_ν - ∂_ν A_μ + [A_μ, A_ν], where A_μ = ∂_μ φ^a G_a
    """
    D = phi.ndim - 1  # spatial dimensions
    A_mu_coeffs = [np.gradient(phi, axis=mu) for mu in range(D)]  # (..., d)
    
    
    A_matrices = [np.einsum('...a,aij->...ij', coeffs, generators) for coeffs in A_mu_coeffs]

    # Now project ∂_μ φ^a onto matrix-valued A_μ = ∂_μ φ^a · G_a
    A_matrices = [np.einsum('...a,aij->...ij', coeffs, generators) for coeffs in A_mu_coeffs]

    curvature_norms = {}
    for mu in range(D):
        for nu in range(mu + 1, D):
            # Derivatives of matrix-valued A_ν along μ, etc
            dA_nu_dmu = compute_spatial_gradient_matrix_field(A_matrices[nu], axis=mu)
            dA_mu_dnu = compute_spatial_gradient_matrix_field(A_matrices[mu], axis=nu)


            # Matrix commutator [A_μ, A_ν]
            comm = compute_commutator(A_matrices[mu], A_matrices[nu])

            # Final curvature
            F_munu = dA_nu_dmu - dA_mu_dnu + comm

            # Frobenius norm per spatial point
            curvature_norms[(mu, nu)] = np.linalg.norm(F_munu, axis=(-2, -1))

    return curvature_norms


def build_inter_agent_omega(phi_i, phi_j, generators, config=None, use_commutator=False):
    """
    Compute the inter-agent gauge transport operator field Ω_{ij}(x).

    Parameters:
        phi_i: np.ndarray shape (..., d) — φ_i field over spatial domain
        phi_j: np.ndarray shape (..., d) — φ_j field over spatial domain
        generators: np.ndarray shape (d, K, K) — Lie algebra generators
        config: optional config object to override use_commutator
        use_commutator: bool —
            if False, do non-abelian exp(φ_i) @ exp(-φ_j);
            if True,  do abelian exp(φ_i - φ_j)

    Returns:
        omega_ij: np.ndarray shape (..., K, K) — inter-agent transport operator
    """
    # allow config to override the flag
    if config is not None:
        use_commutator = getattr(config, "use_commutator", use_commutator)

    # difference field (..., d)
    delta = phi_i - phi_j

    if not use_commutator:
        # non-abelian: exp(φ_i) @ exp(-φ_j)
        g_i     = exp_lie_algebra_irrep(phi_i, generators, group_name=getattr(config, "group_name", None))
        g_j_inv = exp_lie_algebra_irrep(-phi_j, generators, group_name=getattr(config, "group_name", None))
        return np.matmul(g_i, g_j_inv)

    # abelian shortcut: exp(φ_i - φ_j)
    return exp_lie_algebra_irrep(delta, generators, group_name=getattr(config, "group_name", None))
