import numpy as np
import config
from typing import Tuple


from get_generators import get_generators


from typing import Tuple, Callable, List
import numpy as np
import config


def broadcast_support_mask(mask: np.ndarray, theta_shape: Tuple[int, ...]) -> np.ndarray:
    """
    Turn a 2D boolean mask (H, W) into a float mask that broadcasts
    over any trailing θ dimensions.
    E.g. mask.shape==(H,W) and theta_shape==(H,W,D) produces (H,W,1,...,1).
    """
    bool_mask = (mask > 0)
    # number of singleton dims to append
    n_trailing = len(theta_shape) - 2
    return bool_mask.astype(float).reshape((*bool_mask.shape, *([1] * n_trailing)))


def compute_self_gradient(
    agent_i,
    params: dict,
    mode: str = "q",                    # "q" for D_KL(q||p), "p" for D_KL(p||q)
    morphism: Callable = None           # optional: (fam_other) -> ExponentialFamily
) -> np.ndarray:
    """
    Generic IG self-KL gradient:
      if mode=="q": grad w.r.t. θ_q of α_belief·D_KL(q || p or morphism(p))
      if mode=="p": grad w.r.t. θ_p of α_model·D_KL(p || q or morphism(q))

    morphism: a function that takes the 'other' family and returns
              an ExponentialFamily in the same coordinates as the 'self' family.
    """
    # select KL‐weight based on bundle
    if mode == "q":
        α = params.get("alpha_belief", config.alpha_belief)
        fam_self, fam_other = agent_i.q_fam, agent_i.p_fam
    elif mode == "p":
        α = params.get("alpha_model", config.alpha_model)
        fam_self, fam_other = agent_i.p_fam, agent_i.q_fam
    else:
        raise ValueError(f"Unknown mode: {mode!r}, expected 'q' or 'p'")

    # apply optional bundle morphism
    if morphism is not None:
        fam_other = morphism(fam_other)

    support_eps = params.get("support_cutoff_eps", config.support_cutoff_eps)
    mask2d      = agent_i.mask > support_eps

    # nothing to do if weight is zero or no support
    if α <= 0 or not mask2d.any():
        return np.zeros_like(fam_self.theta)

    # compute raw gradient
    η_self   = fam_self.expectation
    η_other  = fam_other.expectation
    grad     = α * (η_self - η_other)

    # mask out outside support
    mask     = broadcast_support_mask(mask2d, fam_self.theta.shape)
    grad    *= mask

    return grad




# ——— at top of IG_update_terms.py ———



# ——— your patched function ———

def compute_theta_gradient(agent_i, agents: list, params: dict, mode: str) -> np.ndarray:
    overlap_eps = params.get("support_cutoff_eps", config.support_cutoff_eps)

    if mode == "belief":
        fam_self        = agent_i.q_fam
        fam_other       = agent_i.p_fam
        α               = params.get("alpha_belief", config.alpha_belief)
        β               = params.get("beta_belief",  config.beta_belief)
        Omega_field     = "Omega_belief"
        Omega_inv_field = "Omega_belief_inv"
    elif mode == "model":
        fam_self        = agent_i.p_fam
        fam_other       = agent_i.q_fam
        α               = params.get("alpha_model", config.alpha_model)
        β               = params.get("beta_model",  config.beta_model)
        Omega_field     = "Omega_model"
        Omega_inv_field = "Omega_model_inv"
    else:
        raise ValueError(f"Invalid mode: {mode!r}; expected 'belief' or 'model'")

    # Build a support mask that matches fam_self.theta’s trailing dims
    mask2d = (agent_i.mask > overlap_eps)
    mask    = broadcast_support_mask(mask2d, fam_self.theta.shape)

    if mask.sum() == 0:
        return np.zeros_like(fam_self.theta)

    η_self = fam_self.expectation
    grad   = np.zeros_like(fam_self.theta)

    # 1) Self‐KL term
    if α > 0:
        η_other  = fam_other.expectation
        grad_self = α * (η_self - η_other)
        grad     += grad_self * mask

    # 2) Neighbor‐alignment term
    if β > 0:
        nbr_ids = agent_i.neighbors or []
        nbs     = max(len(nbr_ids), 1)
        for j in nbr_ids:
            nbr   = agents[j]
            # compute Ω_ij in your coordinate frame
            Ω_ij  = getattr(agent_i, Omega_field) @ getattr(nbr, Omega_inv_field)
            # push neighbor's family into fam_self's frame (uses self.theta internally)
            pushed_fam = fam_self.push_forward(Ω_ij)
            η_nb       = pushed_fam.expectation

            # accumulate masked and normalized
            grad += (β / nbs) * (η_self - η_nb) * mask

    return grad




import numpy as np
import config
from get_generators import get_generators
from IG_math_utils import laplacian_field
from IG_update_terms import broadcast_support_mask


def _broadcast_mask(mask2d: np.ndarray) -> np.ndarray:
    """
    Turn a boolean mask (H×W) into a float mask (H×W×1)
    that cleanly broadcasts over φ’s last dimension.
    """
    return mask2d.astype(float)[..., None]

def compute_phi_gradient(agent_i, agents: list, params: dict, mode: str = "belief") -> np.ndarray:
    """
    ∇_φ of:
      mode='belief':  β_belief·Σ_j D_KL[q||Ω q_j]
                     + γ_belief·Δφ_belief
                     + mass_belief·φ_belief
                     + gauge_coupling·φ_model

      mode='model':   β_model·Σ_j D_KL[p||Ω̃ p_j]
                     + γ_model·Δφ_model
                     + mass_model·φ_model
                     + gauge_coupling·φ_belief
    """
    # 1) select fields & weights
    if mode == "belief":
        phi         = agent_i.phi_belief            # (H,W,G)
        fam_self    = agent_i.q_fam
        beta        = params.get("beta_belief",  config.beta_belief)
        gamma       = params.get("gamma_belief", config.gamma_belief)
        mass_coeff  = params.get("mass_belief",  config.mass_belief)
        other_phi   = agent_i.phi_model            # (H,W,G)
        Omega_i     = agent_i.Omega_belief         # (H,W,K,K)
        Omega_inv_f = lambda a: a.Omega_belief_inv
    elif mode == "model":
        phi         = agent_i.phi_model
        fam_self    = agent_i.p_fam
        beta        = params.get("beta_model",  config.beta_model)
        gamma       = params.get("gamma_model", config.gamma_model)
        mass_coeff  = params.get("mass_model",  config.mass_model)
        other_phi   = agent_i.phi_belief
        Omega_i     = agent_i.Omega_model
        Omega_inv_f = lambda a: a.Omega_model_inv
    else:
        raise ValueError(f"Unknown mode: {mode}")

    support_eps = params.get("support_cutoff_eps", config.support_cutoff_eps)
    coupling    = params.get("gauge_coupling",    config.gauge_coupling)

    # dimensions
    H, W, G_count = phi.shape
    mask2d        = (agent_i.mask > support_eps)
    mask3         = _broadcast_mask(mask2d)       # (H,W,1)

    # start gradient at zero
    grad = np.zeros_like(phi)  # (H,W,G)

    # early exit if nothing to compute
    if not mask2d.any() and beta<=0 and gamma<=0 and mass_coeff<=0 and coupling<=0:
        return grad

    # precompute means: fam_self.expectation has shape (H,W,2K)
    K            = fam_self.K
    eta_full     = fam_self.expectation.reshape(H, W, 2*K)
    eta_self_mu  = eta_full[..., :K]                # (H,W,K)

    # ——— neighbor‐alignment KL term ———
    if beta > 0 and mask2d.any():
        nbr_ids = agent_i.neighbors or []
        nbs     = max(len(nbr_ids), 1)
        # get Lie generators list length G_count
        Gs      = get_generators(config.group_name, K)
        # process each neighbor
        for j in nbr_ids:
            A_j        = agents[j]
            # build Ω_ij at each pixel
            Omega_j_inv= Omega_inv_f(A_j)
            Ω_ij       = np.einsum('...ab,...bc->...ac', Omega_i, Omega_j_inv)
            # push neighbor family into self’s frame
            fam_j_rot  = fam_self.push_forward(Ω_ij)
            # extract its mean
            eta_j_full = fam_j_rot.expectation.reshape(H, W, 2*K)
            eta_j_mu   = eta_j_full[..., :K]         # (H,W,K)

            # compute dμ = η_self_mu - η_j_mu → (H,W,K)
            dmu = eta_self_mu - eta_j_mu             # (H,W,K)

            # vectorized contraction with all generators:
            Gs_arr = np.stack(Gs, axis=0)            # (G_count,K,K)
            # compute μ_j · Gs[a].T for all a: result (H,W,G_count,K)
            Gstat  = np.tensordot(eta_j_mu, Gs_arr, axes=([2],[2]))
            # now dot dmu against Gstat’s last axis: (H,W,1,K)*(H,W,G,K) → (H,W,G)
            kl_contrib = np.sum(dmu[..., None, :] * Gstat, axis=-1)

            grad += (beta / nbs) * kl_contrib * mask3


    # ——— Laplacian penalty ———
    if gamma > 0:
        grad += gamma * laplacian_field(phi) * mask3

    # ——— Mass term ———
    if mass_coeff > 0:
        grad += mass_coeff * phi * mask3

    # ——— Cross‐coupling φ↔other_phi ———
    if coupling > 0:
        grad += coupling * other_phi * mask3

    return grad
