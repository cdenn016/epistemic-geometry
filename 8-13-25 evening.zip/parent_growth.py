# -*- coding: utf-8 -*-
"""
Created on Mon Aug 11 17:58:13 2025

@author: chris and christine
"""
from typing import List, Tuple
import config
# parent_growth.py
import numpy as np

from detector import resize_nn, child_activity_map
# parent_growth.py (top)
from parent_mask_utils import (
    binary_dilate_3x3, binary_erode_3x3, gauss3,
    cheap_dt, _label4, _bands, _dilate_bool, ensure_hw, 
    _ring_masks, _logistic
)

from bundle_morphism_utils import compute_direct_morphisms
from agent_initialization import initialize_agent_gradients
from bundle_coarsegrain_init import coarsegrain_parent_from_children
import numpy as np
import config
from parent_mask_utils import ensure_hw
from bundle_coarsegrain_init import coarsegrain_parent_from_children



def apply_parent_growth(runtime_ctx, growth_maps, *, eta_grow=0.08, eta_shrink=0.12,
                        min_area=10, max_area=None, delta_cap=0.05, blur_iters=1):
    """
    Mutating stage: given dict[pid] -> (grow_field, shrink_field), update masks.
    """
    import numpy as np
    from scipy.ndimage import gaussian_filter
    parents = getattr(runtime_ctx, "parents_by_region", {})
    if not parents:
        return

    for pid, P in parents.items():
        if pid not in growth_maps:
            continue
        grow_field, shrink_field = growth_maps[pid]
        m = np.asarray(P.mask, np.float32)
        dm = eta_grow * grow_field - eta_shrink * shrink_field
        dm = np.clip(dm, -delta_cap, delta_cap)
        if blur_iters and blur_iters > 0:
            dm = gaussian_filter(dm, sigma=blur_iters)
        m_new = np.clip(m + dm, 0.0, 1.0)

        prev_area = int((m > 0.5).sum())
        new_area  = int((m_new > 0.5).sum())
        net_dm    = float(dm.mean())
        age       = int(getattr(P, "_age", 0))
        ramp      = int(getattr(config, "parent_ramp_steps", 0))
    
        # your gating...
        skip = False
        if (max_area is not None) and (new_area > float(max_area)):
            skip = True
        if (new_area < float(min_area)) and (net_dm <= 0.0) and (age >= ramp):
            skip = True
    
        if getattr(config, "debug_growth_probe", True) and (age <= 2):
            print(f"[APPLY/PROBE pid={int(getattr(P,'id',-1))}] "
                  f"net_dm={net_dm:.4f} prevA={prev_area} newA={new_area} skip={skip}")
    
        if skip:
            continue
    
        P.mask = m_new
       


def compute_parent_growth_maps_pure(runtime_ctx, children, *,
                                    tau_grow=0.30, tau_shrink=0.18,
                                    kappa=0.05, grow_band=1, shrink_band=1,
                                    mask_tau=0.30):
    """
    Pure stage: dict[pid] -> (grow_field, shrink_field), each (H,W) in [0,1].
    Uses per-parent signal from labeled kids (Agreement or KL), falls back to coverage if needed.
    tau_* can be float or "pXX"; kappa can be float or "auto".
    """
    if not getattr(runtime_ctx, "parents_by_region", None):
        return {}

    H, W = np.asarray(children[0].mask).shape[:2]
    # global fallback coverage
    global_cov = np.zeros((H, W), np.float32)
    for c in children:
        global_cov = np.maximum(global_cov, ensure_hw(getattr(c, "mask", 0.0), (H, W)))

    out = {}

    # local parsers to avoid any name clashes
    def _parse_tau(spec, vals, fb):
        v = np.asarray(vals, np.float64).ravel()
        v = v[np.isfinite(v)]
        try:
            if isinstance(spec, str):
                s = spec.strip().lower()
                if s.startswith("p"):
                    pct = float(s[1:])
                    return float(np.percentile(v, pct)) if v.size else float(fb)
                return float(s)
            return float(spec)
        except Exception:
            return float(fb)

    def _parse_kappa(spec, vals, fb):
        v = np.asarray(vals, np.float64).ravel()
        v = v[np.isfinite(v)]
        if isinstance(spec, str) and spec.strip().lower() == "auto":
            if v.size:
                q75, q25 = np.percentile(v, [75, 25])
                return float(max(1e-6, 0.25 * (q75 - q25)))
            return float(fb)
        try:
            return float(spec)
        except Exception:
            return float(fb)

    signal_mode = getattr(config, "parent_growth_signal", "auto")  # "auto"|"kl"|"agree"|"coverage"

    for pid, P in runtime_ctx.parents_by_region.items():
        pm = ensure_hw(getattr(P, "mask", 0.0), (H, W))
        core = (pm > float(mask_tau))
        if not np.any(core):
            # NEWBORN fallback: allow a looser core for age 0 only
            if int(getattr(P, "_age", 0)) == 0:
                loose = float(getattr(config, "parent_newborn_core_tau", 0.05))
                core = (pm > loose)
            if not np.any(core):
                continue

        # per-parent signal from its labeled kids (or fallback)
        sig = _extract_per_parent_signal(pid, children, H, W, mode=signal_mode)
        if sig is None:
            sig = global_cov  # no labeled kids yet

        outer_ring, inner_ring = _ring_masks(core, grow_band, shrink_band)

        core_count = int(core.sum())
        outer_count = int(outer_ring.sum())
        inner_count = int(inner_ring.sum())
    
        # pick values for thresholds/slopes (your existing code)
        g_raw = sig * outer_ring.astype(np.float32)
        s_raw = (1.0 - sig) * inner_ring.astype(np.float32)
        g_vals = g_raw[outer_ring]
        s_vals = s_raw[inner_ring]
        vals_for_kappa = (
            np.concatenate([g_vals, s_vals]) if (g_vals.size and s_vals.size)
            else (g_vals if g_vals.size else s_vals)
        )
    
        # existing tau/kappa parsing
        tau_g = _parse_tau(tau_grow,  g_vals, 0.30)
        tau_s = _parse_tau(tau_shrink, s_vals, 0.18)
        kap   = _parse_kappa(kappa,    vals_for_kappa, 0.05)
    
        if getattr(config, "debug_growth_probe", False) and (int(getattr(P, "_age", 0)) <= 2):
            print(f"[GROW/PROBE pid={int(getattr(P,'id',-1))}] "
                  f"core={core_count} outer={outer_count} inner={inner_count} "
                  f"gmax={float(g_raw.max()) if g_vals.size else 0.0:.3f} "
                  f"smax={float(s_raw.max()) if s_vals.size else 0.0:.3f} "
                  f"tau_g={tau_g:.3f} tau_s={tau_s:.3f} kappa={kap:.3f}")
    


        # gates on rings
        g_raw = sig * outer_ring.astype(np.float32)          # grow where signal is strong just outside
        s_raw = (1.0 - sig) * inner_ring.astype(np.float32)  # shrink where signal is weak just inside

        g_vals = g_raw[outer_ring]
        s_vals = s_raw[inner_ring]
        vals_for_kappa = (
            np.concatenate([g_vals, s_vals]) if (g_vals.size and s_vals.size)
            else (g_vals if g_vals.size else s_vals)
        )

        tau_g = _parse_tau(tau_grow,  g_vals, 0.30)
        tau_s = _parse_tau(tau_shrink, s_vals, 0.18)
        kap   = _parse_kappa(kappa,    vals_for_kappa, 0.05)

        grow_field   = _logistic(g_raw, tau=tau_g, kappa=kap).astype(np.float32)
        shrink_field = _logistic(s_raw, tau=tau_s, kappa=kap).astype(np.float32)

        out[int(pid)] = (grow_field, shrink_field)

    return out





# ---------- main seeding function -------------------------------------------

def seed_new_parents_from_uncovered(runtime_ctx, candidate_map, *,
                                    children, generators_q, generators_p,
                                    min_area: int,
                                    cover_tau: float = 0.10,
                                    iou_thr: float = 0.40,
                                    max_new_per_step: int | None = None,
                                    min_interseed_px: int | None = None) -> list[int]:
    """
    Seed new parents from uncovered regions in candidate_map (H,W) boolean/float.
    - Filters by area, IoU vs existing parents, and min spacing.
    - Initializes fields and coarse-grains μ/Σ from children.
    - Returns list of new parent IDs.
    """
    

    # optional blur for feathering
    try:
        from scipy.ndimage import gaussian_filter as _gblur
        _HAS_SCIPY = True
    except Exception:
        _HAS_SCIPY = False

    max_new_per_step = int(max_new_per_step or getattr(config, "parent_max_new_per_step", 2))
    min_interseed_px = int(min_interseed_px or getattr(config, "parent_min_interseed_px", 6))

    parents = _ensure_parent_store(runtime_ctx)
    H, W = np.asarray(candidate_map).shape[:2]
    cand = (np.asarray(candidate_map, np.float32) > float(cover_tau))
   
    # Exclude a margin around any existing parent to kill the “ring of fire”.
    
    periodic = bool(getattr(config, "periodic_domain", True))
    support_eps = float(getattr(config, "parent_cover_support_eps", 0.30))
    excl_r = int(getattr(config, "parent_seed_exclusion_px", 3))
    if excl_r > 0 and parents:
        
        blocked = np.zeros((H, W), dtype=bool)
        for P in parents.values():
            pm = ensure_hw(getattr(P, "mask", 0.0), (H, W))
            blocked |= _dilate_bool((pm > support_eps), r=excl_r, periodic=periodic)
        cand &= ~blocked

    comps = _components(cand, min_area=int(min_area))
    if not comps:
        return []

    # existing parents’ supports (for IoU filtering)
    existing_bool = [(ensure_hw(getattr(P, "mask", 0.0), (H, W)) > support_eps) for P in parents.values()]

    # infer shapes/dtypes from a template child
    tmpl  = children[0]
    dtype = tmpl.mu_q_field.dtype
    Kq, Kp = tmpl.mu_q_field.shape[-1], tmpl.mu_p_field.shape[-1]

    # Seed spacing should also respect existing parent centers across steps.
    chosen: list[tuple[float, float]] = []
    def _center_of(m: np.ndarray):
        ys, xs = np.nonzero(m > support_eps)
        if ys.size == 0: return None
        return (float(ys.mean()), float(xs.mean()))
    for P in parents.values():
        pm = ensure_hw(getattr(P, "mask", 0.0), (H, W))
        c = _center_of(pm)
        if c is not None:
            chosen.append(c)
    seeded_ids: list[int] = []

    # seeding params
    seed_lvl   = float(getattr(config, "parent_seed_init_level", 0.45))   # amplitude
    feather    = float(getattr(config, "parent_seed_feather_sigma", 1.0)) # 0 = hard edge
    r0         = float(getattr(config, "parent_seed_radius_px", 4.0))     # NEW: small local radius

    for area, (cy, cx), comp in comps:
        if len(seeded_ids) >= max_new_per_step:
            break
        if not _respect_spacing(cy, cx, chosen, min_interseed_px):
            continue

        # reject if overlaps existing too much
        if _too_close_by_iou(comp, existing_bool, iou_thr=float(iou_thr)):
            continue

        # allocate id
        pid = int(getattr(runtime_ctx, "next_parent_id", 0))
        runtime_ctx.next_parent_id = pid + 1

        # make a fresh parent object
        P = _make_parent_template(runtime_ctx, tmpl, pid=pid, H=H, W=W, Kq=Kq, Kp=Kp,
                                  generators_q=generators_q, generators_p=generators_p)

        # ---- build a small local seed inside the component -----------------
        base = ensure_hw(comp, (H, W)).astype(np.float32)  # 0/1 component to (H,W)
        # Gaussian disk around component COM, clipped to the component
        yc, xc = int(round(cy)), int(round(cx))
        yy, xx = np.ogrid[:H, :W]
        d2 = (yy - yc) * (yy - yc) + (xx - xc) * (xx - xc)
        gauss = np.exp(-0.5 * (d2 / max(1.0, r0 * r0))).astype(np.float32)
        base *= gauss
        if feather > 0:
            if _HAS_SCIPY:
                base = _gblur(base, sigma=feather)
            else:
                # simple 3x3 box blur fallback, repeated ~feather times
                k = np.array([[1,1,1],[1,1,1],[1,1,1]], np.float32) / 9.0
                for _ in range(int(max(1, round(feather)))):
                    pad = np.pad(base, 1, mode="reflect")
                    base = (
                        pad[0:-2,0:-2] + pad[0:-2,1:-1] + pad[0:-2,2:] +
                        pad[1:-1,0:-2] + pad[1:-1,1:-1] + pad[1:-1,2:] +
                        pad[2:,0:-2]   + pad[2:,1:-1]   + pad[2:,2:]
                    ) / 9.0
        # normalize then scale to seed level
        mmax = float(base.max())
        if mmax > 0:
            base = base / mmax
        P.mask = np.clip(base * seed_lvl, 0.0, 1.0)
        # -------------------------------------------------------------------

        # init bookkeeping
        if not hasattr(P, "_age"):   P._age = 0
        if not hasattr(P, "_grace"): P._grace = int(getattr(config, "parent_freeze_steps", 0))

        # register before CG so ensure_hw sees it if needed
        parents[pid] = P

        # Coarse-grain μ, Σ into the new parent (hard-masked inside)
        try:
            cg_eps = float(getattr(config, "cg_eps", 1e-6))
            cg_tau = float(getattr(config, "parent_cover_support_eps", 0.30))
            coarsegrain_parent_from_children(P, children, eps=cg_eps, mask_tau=cg_tau)
        except Exception as e:
            if getattr(config, "debug_parent_masks", False):
                print(f"[COARSEGRAIN] parent {pid} init failed: {e}")
                mshape = np.asarray(P.mask).shape
                c0 = children[0]
                print(f"  P.mask {mshape}")
                print(f"  child0.mu_q_field {np.asarray(c0.mu_q_field).shape}, "
                      f"sigma_q_field {np.asarray(c0.sigma_q_field).shape}")

        # mark exp-caches dirty — central prepass will rebuild them
        for attr in ("_exp_phi", "_exp_neg_phi", "_exp_phi_model", "_exp_neg_phi_model"):
            setattr(P, attr, None)

        seeded_ids.append(pid)
        chosen.append((float(cy), float(cx)))

    return seeded_ids








def _child_is_labeled_to(child, pid):
    """Robustly detect if a child is assigned to parent pid (supports multiple schemas)."""
    if getattr(child, "parent_id", None) == pid: return True
    if getattr(child, "assigned_parent", None) == pid: return True
    lab = getattr(child, "label", None)
    if isinstance(lab, (tuple, list, set)) and pid in lab: return True
    if isinstance(lab, (int, np.integer)) and lab == pid: return True
    labs = getattr(child, "labels", None)
    if isinstance(labs, dict) and pid in labs: return True
    return False

def _extract_per_parent_signal(pid, children, H, W, *, mode="auto"):
    """
    Build a per-parent growth signal in [0,1], shape (H,W), using only the
    children currently labeled to that parent.

    Order of preference (within labeled kids):
      1) agreement_to_parent[pid] OR child.agreement_field
      2) kl_to_parent[pid] OR child.kl_field -> invert+normalize
      3) coverage of labeled kids
    If no labeled kids, returns None.
    """
    # pick labeled kids
    labeled = [c for c in children if _child_is_labeled_to(c, pid)]
    if not labeled:
        return None  # caller must fallback

    # 1) agreement (higher is better)
    agree = None
    for c in labeled:
        # try per-parent agreement dict first
        amap = getattr(c, "agreement_to_parent", None)
        fld = amap.get(pid) if isinstance(amap, dict) else getattr(c, "agreement_field", None)
        if fld is None: continue
        a = ensure_hw(fld, (H, W), reduce="mean")
        agree = a if agree is None else np.maximum(agree, a)
    if agree is not None and (mode in ("auto", "agree")):
        return np.clip(np.nan_to_num(agree, nan=0.0, posinf=1.0, neginf=0.0), 0.0, 1.0)

    # 2) KL (lower is better) -> invert to [0,1] robustly
    kl = None
    for c in labeled:
        kd = getattr(c, "kl_to_parent", None)
        fld = kd.get(pid) if isinstance(kd, dict) else getattr(c, "kl_field", None)
        if fld is None: continue
        k = np.asarray(fld, np.float32)
        if k.shape != (H, W):
            from parent_mask_utils import resize_nn
            k = resize_nn(k, (H, W)).astype(np.float32)
        kl = k if kl is None else np.minimum(kl, k)  # best (lowest) across labeled kids
    if kl is not None and (mode in ("auto", "kl")):
        finite = np.isfinite(kl)
        if finite.any():
            q25, q75 = np.percentile(kl[finite], [25, 75])
            scale = max(1e-6, q75 - q25)
            sig = 1.0 - np.clip((kl - q25) / scale, 0.0, 1.0)
        else:
            sig = np.zeros_like(kl, np.float32)
        return np.clip(np.nan_to_num(sig, nan=0.0), 0.0, 1.0)

    # 3) coverage of labeled kids (fallback)
    cov = np.zeros((H, W), np.float32)
    for c in labeled:
        cov = np.maximum(cov, ensure_hw(getattr(c, "mask", 0.0), (H, W)))
    return cov



def _make_parent_template(ctx, tmpl, *, pid: int, H: int, W: int, Kq: int, Kp: int,
                          generators_q, generators_p):
    """Construct a brand-new level-1 parent with safe defaults and gradient buffers."""
    import numpy as np

    AgentCls = tmpl.__class__
    dtype = tmpl.mu_q_field.dtype

    # identities, broadcasted (lighter than tile) but materialized via copy
    eye_q = np.broadcast_to(np.eye(Kq, dtype=dtype), (H, W, Kq, Kq)).copy()
    eye_p = np.broadcast_to(np.eye(Kp, dtype=dtype), (H, W, Kp, Kp)).copy()

    P = AgentCls(
        id=pid, center=(0, 0), radius=0.0,
        mask=np.zeros((H, W), np.float32),
        mu_q_field=np.zeros((H, W, Kq), dtype=dtype), sigma_q_field=eye_q,
        mu_p_field=np.zeros((H, W, Kp), dtype=dtype), sigma_p_field=eye_p,
        phi=np.zeros((H, W, 3), dtype=dtype), phi_model=np.zeros((H, W, 3), dtype=dtype),
        neighbors=[]
    )

    P.level = 1
    P.emerged = True
    P._age = 0
    P._grace = int(getattr(config, "parent_grace_steps", 2))
    P._shrink_strikes = 0
    P.Omega_cache = {}; P.Omega_tilde_cache = {}
    P._exp_phi = P._exp_neg_phi = None
    P._exp_phi_model = P._exp_neg_phi_model = None
    P.generators_q = generators_q
    P.generators_p = generators_p

    # Base morphisms
    P.Phi_0       = np.eye(Kp, Kq, dtype=dtype)
    P.Phi_tilde_0 = np.eye(Kq, Kp, dtype=dtype)
    try:
        P.bundle_morphism_q_to_p, P.bundle_morphism_p_to_q = compute_direct_morphisms(
            phi=P.phi, phi_model=P.phi_model,
            generators_q=P.generators_q, generators_p=P.generators_p,
            Phi_0=P.Phi_0, Phi_tilde_0=P.Phi_tilde_0,
        )
    except Exception:
        P.bundle_morphism_q_to_p = np.broadcast_to(P.Phi_0, (H, W, Kp, Kq)).copy()
        P.bundle_morphism_p_to_q = np.broadcast_to(P.Phi_tilde_0, (H, W, Kq, Kp)).copy()

    # Initialize gradient buffers
    initialize_agent_gradients(P)
    _attach_sigma_watch(P)
    # --- Guardrails: enforce 4D shapes + SPD once at birth ------------------
    def _spd_tidy(S):
        if S is None: return None
        S = 0.5*(S + np.swapaxes(S, -1, -2))
        K = S.shape[-1]
        return S + (1e-8 * np.eye(K, dtype=S.dtype))
    assert P.sigma_q_field.ndim == 4 and P.sigma_q_field.shape[-1] == P.sigma_q_field.shape[-2], \
        f"sigma_q_field bad shape {P.sigma_q_field.shape}"
    assert P.sigma_p_field.ndim == 4 and P.sigma_p_field.shape[-1] == P.sigma_p_field.shape[-2], \
        f"sigma_p_field bad shape {P.sigma_p_field.shape}"
    P.sigma_q_field = _spd_tidy(P.sigma_q_field)
    P.sigma_p_field = _spd_tidy(P.sigma_p_field)

    P.birth_step = int(getattr(ctx, "global_step", 0))
    return P


# --- helpers ---------------------------------------------------------------


def _activity_union(children, ids, H, W, r, periodic, eps):
    active_union = np.zeros((H, W), bool)
    for i in ids:
        act = child_activity_map(children[i], H, W, eps=eps)
        if act is not None:
            active_union |= _dilate_bool(act.astype(bool), r=r, periodic=periodic)
    return active_union

def _overlap_count(children, ids, H, W, r, periodic, eps):
    cnt = np.zeros((H, W), np.int32)
    for i in ids:
        cm = (np.asarray(children[i].mask) > eps)
        cnt += _dilate_bool(cm, r=r, periodic=periodic).astype(np.int32)
    return cnt


def _parent_bands(mask: np.ndarray, grow_band: int, shrink_band: int):
    supp = mask > 1e-6
    dil, ero = supp.copy(), supp.copy()
    for _ in range(max(1, int(grow_band))):   dil = binary_dilate_3x3(dil)
    for _ in range(max(1, int(shrink_band))): ero = binary_erode_3x3(ero)
    band_out = dil & (~supp)
    band_in  = supp & (~ero)
    return band_out, band_in, supp


def _agreement_gate(children, child_ids, shape):
  
    try:
        
        agree = _soft_agreement_from_phi(children, child_ids, use_phi_tilde=True)
    except Exception:
        agree = None
    if agree is None:
        return None
    a = ensure_hw(agree, shape, reduce="mean")  # (H,W) float32
    a = np.nan_to_num(a, nan=0.0, posinf=1.0, neginf=0.0)
    return np.clip(a, 0.0, 1.0)







# --- PATCH 1: allow KL helper to look outside the mask -----------------------
def _mean_child_kl_field(P, children, where=None):
    """
    Mean of children's cached KL on 'where' pixels.
    If where is None, falls back to (child.mask ∧ parent.mask).
    """
    H, W = P.mask.shape
    acc = np.zeros((H, W), dtype=np.float32)
    cnt = np.zeros((H, W), dtype=np.int32)

    for ch in children:
        # optional: restrict to this parent's kids if you track them
        pids = getattr(ch, "parent_ids", None)
        if pids is not None and P.id not in pids:
            continue

        kl = getattr(ch, "cached_alignment_kl", None)
        if kl is None:
            continue
        k = np.asarray(kl).squeeze()
        if k.shape != (H, W):
            k = resize_nn(k, (H, W))  # your existing resize helper

        if where is None:
            m = (np.asarray(ch.mask) > 0) & (np.asarray(P.mask) > 0)
        else:
            m = (np.asarray(ch.mask) > 0) & where

        if m.any():
            acc[m] += k[m]
            cnt[m] += 1

    out = np.full((H, W), np.nan, dtype=np.float32)
    nz = cnt > 0
    if nz.any():
        out[nz] = acc[nz] / np.maximum(cnt[nz], 1)
    # safe max computation
    if not np.isfinite(out).any():
        mx = None
        out = np.zeros_like(out, dtype=np.float32)
    else:
        mx = np.nanmax(out)
    
    # fill NaNs with a conservative high value so growth won't trigger there
    fill_val = 1.0 if mx is None or not np.isfinite(mx) else mx
    out = np.nan_to_num(out, nan=fill_val, posinf=fill_val, neginf=fill_val)
    
    return out

def _soft_agreement_from_phi(children, child_ids, use_phi_tilde=True, eps=1e-6):
    """
    Returns (H,W) agreement only. Refuses φ/φ̃ with unexpected rank to prevent
    accidental (M,H,W,3) stacks from leaking into downstream exp/log maps.
    """
    import numpy as np

    ids = sorted(set(child_ids))
    phis = []
    for i in ids:
        phi = getattr(children[i], "phi", None)
        if phi is None: 
            continue
        phi = np.asarray(phi)
        if not (phi.ndim == 3 and phi.shape[-1] == 3):
            raise RuntimeError(f"child {getattr(children[i],'id','?')} phi has shape {phi.shape}, expected (H,W,3)")
        phis.append(phi)

    if use_phi_tilde:
        for i in ids:
            ptil = getattr(children[i], "phi_model", None)
            if ptil is None: 
                continue
            ptil = np.asarray(ptil)
            if not (ptil.ndim == 3 and ptil.shape[-1] == 3):
                raise RuntimeError(f"child {getattr(children[i],'id','?')} phi_model has shape {ptil.shape}, expected (H,W,3)")
            phis.append(ptil)

    if len(phis) < 2:
        return None

    # Stack only inside; we return (H,W) so no (M,...) escapes
    arr  = np.stack(phis, axis=0)        # (M,H,W,3)
    mean = arr.mean(axis=0)              # (H,W,3)
    var  = ((arr - mean)**2).mean(axis=0).sum(axis=-1)  # (H,W)
    denom = float(var.mean()) + eps
    agree = np.exp(-var / denom)
    return agree.astype(np.float32)      # (H,W)



# ---------- small utilities --------------------------------------------------

def _ensure_parent_store(ctx):
    """Normalize ctx.parents_by_region → Dict[int, Parent]."""
    if not hasattr(ctx, "parents_by_region") or ctx.parents_by_region is None:
        ctx.parents_by_region = {}
    if isinstance(ctx.parents_by_region, list):
        ctx.parents_by_region = {int(getattr(p, "id", i)): p for i, p in enumerate(ctx.parents_by_region)}
    return ctx.parents_by_region

def _components(candidate_map: np.ndarray, *, min_area: int) -> List[Tuple[int, Tuple[float,float], np.ndarray]]:
    """Return components as (area, (cy,cx), mask) sorted by area desc."""
    labels, ncc = _label4(candidate_map.astype(bool))
    if ncc == 0:
        return []
    comps = []
    for c in range(1, ncc + 1):
        comp = (labels == c)
        area = int(comp.sum())
        if area < int(min_area):
            continue
        ys, xs = np.nonzero(comp)
        comps.append((area, (float(ys.mean()), float(xs.mean())), comp))
    comps.sort(key=lambda t: t[0], reverse=True)
    return comps

def _iou_bool(a: np.ndarray, b: np.ndarray) -> float:
    inter = (a & b).sum()
    union = (a | b).sum()
    return float(inter) / max(1, int(union))

def _too_close_by_iou(comp: np.ndarray, existing_bool_masks: List[np.ndarray], *, iou_thr: float) -> bool:
    for pb in existing_bool_masks:
        if _iou_bool(comp, pb) >= float(iou_thr):
            return True
    return False

def _respect_spacing(cy: float, cx: float, chosen: List[Tuple[float,float]], min_interseed_px: int) -> bool:
    if not chosen or min_interseed_px <= 0:
        return True
    r2 = min_interseed_px ** 2
    return min((cy - y) ** 2 + (cx - x) ** 2 for (y, x) in chosen) >= r2


def _attach_sigma_watch(agent, limit=6):
    import types, numpy as np, traceback

    # opt-in via config
    if not bool(getattr(config, "debug_sigma_watch", True)):
        return

    # don't double-patch
    if getattr(agent, "_sigma_watch_attached", False):
        return

    orig_setattr = agent.__setattr__

    def _watched_setattr(self, name, value):
        # Guard: if someone replaces __setattr__ again, don’t recurse infinitely
        if name == "__setattr__" and getattr(self, "_sigma_watch_attached", False):
            return orig_setattr(name, value)

        if name in ("sigma_q_field", "sigma_p_field"):
            try:
                arr = np.asarray(value)
                if arr.ndim != 4 or arr.shape[-1] != arr.shape[-2]:
                    print(f"[TRACE] {name} <- {arr.shape} on parent {getattr(self,'id','?')}")
                    traceback.print_stack(limit=limit)
            except Exception:
                # don’t let tracing break assignment
                pass
        return orig_setattr(name, value)

    agent.__setattr__ = types.MethodType(_watched_setattr, agent)
    agent._sigma_watch_attached = True
