# -*- coding: utf-8 -*-
"""
Created on Tue Aug 12 10:17:46 2025

@author: chris and christine
"""

# parent_mask_utils.py
import numpy as np
from gaussian_core import kl_gaussians, gaussian_pushforward_linear
from numerical_utils import sanitize_sigma
from omega import compute_inter_omega


def compute_pairwise_agreement_maps(children, tau=0.10, eps=1e-6, tcap=10.0,
                                    field="q", generators=None):
    """
    Build per-pair, per-pixel soft agreement maps among overlapping agents.

    `field`: "q" (belief) uses agents' 'phi'; "p" (model) uses 'phi_model'.
    `generators`: pass the irrep generators to use (e.g., Gq or Gp).
    """
    import numpy as _np

    H, W = children[0].mask.shape
    pairs, A, joint = [], {}, {}

    def _get_mu(c): return getattr(c, f"mu_{field}_field")
    def _get_S(c): return sanitize_sigma(getattr(c, f"sigma_{field}_field"), eps=eps)
    phi_field = "phi" if field == "q" else "phi_model"

    N = len(children)
    for i in range(N):
        ci = children[i]; mi = (ci.mask > eps)
        if not mi.any(): continue
        for j in range(i + 1, N):
            cj = children[j]; mj = (cj.mask > eps)
            J = (mi & mj)
            if not J.any(): continue

            ys, xs = _np.nonzero(J)
            y = int(_np.median(ys)); x = int(_np.median(xs))

            # Ω_ij at a representative overlap pixel; broadcast across (H,W)
            Ω = compute_inter_omega(ci, cj, (y, x), field=phi_field, generators=generators)  # (K,K)
            K = Ω.shape[0]
            Omega_ij = _np.broadcast_to(Ω, (H, W, K, K))
            Omega_ji = _np.swapaxes(Omega_ij, -1, -2)

            mu_i, S_i = _get_mu(ci), _get_S(ci)
            mu_j, S_j = _get_mu(cj), _get_S(cj)

            mu_j_t, S_j_t = gaussian_pushforward_linear(mu_j, S_j, Omega_ij)
            mu_i_t, S_i_t = gaussian_pushforward_linear(mu_i, S_i, Omega_ji)

            s_ij = kl_gaussians(mu_i, S_i, mu_j_t, S_j_t, eps=eps)
            s_ji = kl_gaussians(mu_j, S_j, mu_i_t, S_i_t, eps=eps)
            s_sym = 0.5 * (s_ij + s_ji)

            a = _np.zeros((H, W), dtype=_np.float32)
            s_cap = _np.minimum(s_sym[J], tcap)
            a[J] = _np.exp(-s_cap / float(tau))

            key = (i, j)
            pairs.append(key)
            A[key] = a
            joint[key] = J

    return pairs, A, joint


def build_parent_mask_from_group(children,
                                 child_ids,
                                 A_maps,          # from compute_pairwise_agreement_maps
                                 joint_maps,      # from compute_pairwise_agreement_maps
                                 tau=0.2,
                                 m_core=3,
                                 A_min=200,
                                 soft=True,
                                 smooth_iters=0):
    """
    STRICT agreement mask (no union, no averaging of child masks).
    A pixel is IN only if at least m_core children mutually agree there
    (each has >= m_core-1 agreeing neighbors at that pixel).
    Soft value = mean agreement over agreeing pairs at that pixel.
    Returns (H,W) float32 in [0,1].
    """
    import numpy as np

    if len(child_ids) == 0:
        return None

    H, W = children[child_ids[0]].mask.shape
    Cg   = len(child_ids)

    # Pairwise "agree" mats and degrees
    A_sum = np.zeros((H, W), dtype=np.float32)   # sum of A over agreeing pairs
    pairN = np.zeros((H, W), dtype=np.int32)     # number of agreeing pairs
    deg   = np.zeros((Cg, H, W), dtype=np.int16) # per-child degree

    # agreement threshold: A = exp(-KL/tau); choose KL<tau → A>=e^-1
    a_thresh = np.exp(-1.0)

    # Build agreement graph per pixel (implicit via deg + counts)
    for a in range(Cg):
        ia = child_ids[a]
        for b in range(a + 1, Cg):
            ib = child_ids[b]
            key = (ia, ib) if ia < ib else (ib, ia)
            if key not in A_maps:
                continue
            A_ij = A_maps[key]       # (H,W) in [0,1]
            J    = joint_maps[key]   # (H,W) bool where both masks>0
            agree = (A_ij >= a_thresh) & J

            if not agree.any():
                continue

            A_add = np.zeros_like(A_ij, dtype=np.float32)
            A_add[agree] = A_ij[agree]
            A_sum += A_add
            pairN += agree.astype(np.int32)
            deg[a][agree] += 1
            deg[b][agree] += 1

    # If no agreeing pairs anywhere → empty mask (NO union fallback)
    if pairN.sum() == 0:
        return np.zeros((H, W), dtype=np.float32)

    # Core condition: at least m_core children each with ≥(m_core-1) agreeing neighbors
    core_children = (deg >= (m_core - 1))          # (Cg,H,W)
    core_count    = core_children.sum(axis=0)      # (H,W)
    in_core       = (core_count >= m_core)         # (H,W) bool

    # Soft value = mean of A over agreeing pairs, gated by in_core
    A_mean = np.zeros((H, W), dtype=np.float32)
    nz = pairN > 0
    A_mean[nz] = A_sum[nz] / pairN[nz]

    soft_mask = np.where(in_core, A_mean, 0.0).astype(np.float32)

    # optional smoothing (small)
    if smooth_iters > 0:
        k = np.array([[1,1,1],[1,2,1],[1,1,1]], dtype=np.float32); k /= k.sum()
        for _ in range(smooth_iters):
            pad = np.pad(soft_mask, 1, mode="edge")
            sm  = (
                k[0,0]*pad[:-2, :-2] + k[0,1]*pad[:-2,1:-1] + k[0,2]*pad[:-2,2:] +
                k[1,0]*pad[1:-1, :-2] + k[1,1]*pad[1:-1,1:-1] + k[1,2]*pad[1:-1,2:] +
                k[2,0]*pad[2:,  :-2] + k[2,1]*pad[2:, 1:-1] + k[2,2]*pad[2:,  2:]
            )
            soft_mask = np.clip(sm, 0.0, 1.0).astype(np.float32)

    # Area guard
    if soft_mask.sum() < A_min:
        return np.zeros((H, W), dtype=np.float32)

    return soft_mask if soft else (soft_mask > 0.5).astype(np.float32)



def _dilate_bool(mask: np.ndarray, r: int, periodic: bool) -> np.ndarray:
    """Binary dilation by r px, optional periodic wrapping."""
    if r <= 0:
        return mask.astype(bool)
    try:
        from scipy.ndimage import binary_dilation
        se = np.ones((2*r + 1, 2*r + 1), dtype=bool)
        if not periodic:
            return binary_dilation(mask.astype(bool), structure=se)
        H, W = mask.shape
        T = np.tile(mask.astype(bool), (3, 3))
        Td = binary_dilation(T, structure=se)
        return Td[H:2*H, W:2*W]
    except Exception:
        # fallback: cheap square foot-print without SciPy
        m = mask.astype(bool)
        for _ in range(r):
            up    = np.pad(m[1: , : ], ((0,1),(0,0)))
            down  = np.pad(m[:-1, : ], ((1,0),(0,0)))
            left  = np.pad(m[: , 1: ], ((0,0),(0,1)))
            right = np.pad(m[: , :-1], ((0,0),(1,0)))
            m = m | up | down | left | right
        if periodic:
            # wrap edges once (approximate)
            m[0, :]  |= m[-1, :]
            m[-1, :] |= m[0, :]
            m[:, 0]  |= m[:, -1]
            m[:, -1] |= m[:, 0]
        return m

def _bands(mask: np.ndarray, grow_band: int, shrink_band: int, periodic: bool):
    m = (mask > 0).astype(bool)
    if not m.any():
        H, W = mask.shape
        z = np.zeros((H, W), bool)
        return z, z, z
    supp = m
    outer = _dilate_bool(supp, max(1, grow_band), periodic) & ~supp
    inner = supp & ~_dilate_bool(~supp, max(1, shrink_band), periodic)
    return outer, inner, supp


def ensure_hw(mask, HW, *, reduce="max"):
    """
    Return a (H, W) float32 mask in [0,1].
    - Squeezes singleton axes.
    - Collapses any trailing stacks (H,W,M,...) via max or mean.
    - Resizes to (H,W) if needed (nn).
    """
    import numpy as np
    H, W = HW
    m = np.asarray(mask, np.float32)
    # squeeze singletons
    while m.ndim > 0 and m.shape[-1] == 1:
        m = np.squeeze(m, axis=-1)
    if m.ndim == 3 and m.shape[0] == 1:
        m = np.squeeze(m, axis=0)
    # collapse stacks (H,W,M,...) -> (H,W)
    if m.ndim > 2:
        m = m.reshape(m.shape[0], m.shape[1], -1)
        if reduce == "max":
            m = m.max(axis=-1)
        elif reduce == "mean":
            m = m.mean(axis=-1)
        else:
            raise ValueError(f"reduce must be 'max' or 'mean', got {reduce}")
    # resize if needed
    if m.shape != (H, W):
        from parent_mask_utils import resize_nn  # already in your repo
        m = resize_nn(m, (H, W)).astype(np.float32)
    return np.clip(m, 0.0, 1.0)



# try SciPy for morphology; fall back to tiny NumPy kernels
try:
    from scipy.ndimage import binary_dilation as _dilate, binary_erosion as _erode
    _HAS_SCIPY = True
except Exception:
    _HAS_SCIPY = False

def _ring_masks(core_bool, grow_band=1, shrink_band=1):
    """
    Build outer (growth) and inner (shrink) ring masks around a boolean core.
    Returns (outer_ring_bool, inner_ring_bool), each shape (H,W).
    """
    core_bool = np.asarray(core_bool, dtype=bool)

    if _HAS_SCIPY:
        og = core_bool.copy()
        for _ in range(max(1, int(grow_band))):
            og = _dilate(og, iterations=1, border_value=0)
        outer = og & (~core_bool)

        ig = core_bool.copy()
        for _ in range(max(1, int(shrink_band))):
            ig = _erode(ig, iterations=1, border_value=0)
        inner = core_bool & (~ig)
        return outer, inner

    # ---- NumPy fallback (4-neighborhood) ----
    def _dilate4(b):
        up    = np.pad(b[1: , : ], ((0,1),(0,0)))
        down  = np.pad(b[:-1, : ], ((1,0),(0,0)))
        left  = np.pad(b[: , 1: ], ((0,0),(0,1)))
        right = np.pad(b[: , :-1], ((0,0),(1,0)))
        return b | up | down | left | right

    def _erode4(b):
        up    = np.pad(b[1: , : ], ((0,1),(0,0)), constant_values=False)
        down  = np.pad(b[:-1, : ], ((1,0),(0,0)), constant_values=False)
        left  = np.pad(b[: , 1: ], ((0,0),(0,1)), constant_values=False)
        right = np.pad(b[: , :-1], ((0,0),(1,0)), constant_values=False)
        return b & up & down & left & right

    og = core_bool.copy()
    for _ in range(max(1, int(grow_band))):
        og = _dilate4(og)
    outer = og & (~core_bool)

    ig = core_bool.copy()
    for _ in range(max(1, int(shrink_band))):
        ig = _erode4(ig)
    inner = core_bool & (~ig)
    return outer, inner







def _logistic(x, tau, kappa):
    """
    Stable sigmoid around threshold tau with slope governed by kappa.
    Accepts arrays; returns array in [0,1].
    """
    x = np.asarray(x, np.float64)
    z = (x - float(tau)) / max(float(kappa), 1e-6)
    z = np.clip(z, -60.0, 60.0)
    return 1.0 / (1.0 + np.exp(-z))




# --- 4-connected components (pure NumPy) ---
def _label4(binary_mask: np.ndarray):
    """
    4-connected component labeling.
    Returns (labels:int32[H,W], n_components:int)
    """
    H, W = binary_mask.shape
    labels = np.zeros((H, W), dtype=np.int32)
    vid = 0
    # neighbors: up, left
    for y in range(H):
        for x in range(W):
            if not binary_mask[y, x]:
                continue
            up  = labels[y-1, x] if y > 0 else 0
            left= labels[y, x-1] if x > 0 else 0
            if up == 0 and left == 0:
                vid += 1
                labels[y, x] = vid
            elif up != 0 and left == 0:
                labels[y, x] = up
            elif up == 0 and left != 0:
                labels[y, x] = left
            else:
                # merge: relabel one component to the other (path compression lite)
                a, b = (up, left) if up < left else (left, up)
                labels[y, x] = a
                if a != b:
                    labels[labels == b] = a
    # compact labels to 1..n
    uniq = np.unique(labels)
    uniq = uniq[uniq != 0]
    remap = {v:i+1 for i,v in enumerate(uniq)}
    for v, i in remap.items():
        labels[labels == v] = i
    return labels, len(uniq)


def _shift_pad(x: np.ndarray, di: int, dj: int) -> np.ndarray:
    """Return x shifted by (di,dj) with zero/False padding, preserving shape."""
    x = np.asarray(x, dtype=bool)
    H, W = x.shape
    xp = np.pad(x, ((1, 1), (1, 1)), mode="constant", constant_values=False)
    # slice so result is HxW no matter the shift
    return xp[1 + di : 1 + di + H, 1 + dj : 1 + dj + W]

# --- put these helpers near the top (shared utils) ---
def _iou_binary(a: np.ndarray, b: np.ndarray, thr: float = 1e-2) -> float:
    A = (np.asarray(a) > thr)
    B = (np.asarray(b) > thr)
    inter = (A & B).sum()
    union = (A | B).sum()
    return float(inter) / max(1, int(union))


# ----- geometry / morphology -----
def resize_nn(a: np.ndarray, shape: tuple[int, int]) -> np.ndarray:
    H, W = shape; h, w = a.shape[:2]
    if (h, w) == (H, W): return a
    yi = np.clip(np.rint(np.linspace(0, h - 1, H)).astype(int), 0, h - 1)
    xi = np.clip(np.rint(np.linspace(0, w - 1, W)).astype(int), 0, w - 1)
    return a[yi][:, xi]

def binary_dilate_3x3(x: np.ndarray) -> np.ndarray:
    x = np.asarray(x, bool); H, W = x.shape
    y = np.zeros((H, W), bool)
    for di in (-1, 0, 1):
        for dj in (-1, 0, 1):
            y |= np.pad(x, 1)[1+di:1+di+H, 1+dj:1+dj+W]
    return y

def binary_erode_3x3(x: np.ndarray) -> np.ndarray:
    x = np.asarray(x, bool); H, W = x.shape
    y = np.ones((H, W), bool)
    for di in (-1, 0, 1):
        for dj in (-1, 0, 1):
            y &= np.pad(x, 1)[1+di:1+di+H, 1+dj:1+dj+W]
    return y

def gauss3(arr: np.ndarray) -> np.ndarray:
    k = np.array([[1,2,1],[2,4,2],[1,2,1]], np.float32); k /= k.sum()
    if arr.ndim == 2:
        p = np.pad(arr, ((1,1),(1,1)), mode="edge")
        out = (k[0,0]*p[:-2,:-2] + k[0,1]*p[:-2,1:-1] + k[0,2]*p[:-2,2:] +
               k[1,0]*p[1:-1,:-2] + k[1,1]*p[1:-1,1:-1] + k[1,2]*p[1:-1,2:] +
               k[2,0]*p[2:,:-2] + k[2,1]*p[2:,1:-1] + k[2,2]*p[2:,2:])
        return out.astype(np.float32)
    out = np.empty_like(arr, np.float32)
    for c in range(arr.shape[-1]): out[..., c] = gauss3(arr[..., c])
    return out

# ----- activity / overlap / distance -----
def child_activity_map(ch, H, W, mu_tau=1e-3, trsig_tau=1e-3, eps=1e-6):
    m = getattr(ch, "mask", None)
    if m is None: return None
    from parent_mask_utils import resize_nn as _r
    m = np.asarray(m); 
    if m.shape[:2] != (H, W): m = _r(m, (H, W))
    m_ok = (m > eps)

    mu = getattr(ch, "mu_q_field", None)
    Sig = getattr(ch, "sigma_q_field", None)
    if mu is None or Sig is None: return m_ok

    mu = np.asarray(mu); Sig = np.asarray(Sig)
    if mu.shape[:2] != (H, W): mu = _r(mu, (H, W))
    if Sig.shape[:2] != (H, W): Sig = _r(Sig, (H, W))
    mu_mag = np.sqrt((mu**2).sum(-1)) if mu.ndim == 3 else np.abs(mu).astype(np.float32)
    trsig  = np.trace(Sig, axis1=-2, axis2=-1) if Sig.ndim == 4 else Sig.astype(np.float32)
    return m_ok & ((mu_mag > mu_tau) | (trsig > trsig_tau))

def overlap_count(children, H, W, eps, child_ids):
    cnt = np.zeros((H, W), np.int32)
    for i in child_ids:
        ch = children[i]
        a = child_activity_map(ch, H, W, eps=eps)
        if a is None: continue
        m = getattr(ch, "mask", None)
        if m is None: continue
        from parent_mask_utils import resize_nn as _r
        m = _r(np.asarray(m).squeeze(), (H, W))
        cnt += (a & (m > eps)).astype(np.int32)
    return cnt

def cheap_dt(core_bool: np.ndarray, cap_steps: int = 32) -> np.ndarray:
    H, W = core_bool.shape
    dt = np.full((H, W), np.inf, np.float32)
    front = core_bool.astype(bool); d = 0.0
    while front.any() and d < cap_steps:
        dt[front] = np.minimum(dt[front], d)
        new = (front | np.roll(front,1,0) | np.roll(front,-1,0) |
                      np.roll(front,1,1) | np.roll(front,-1,1))
        front = new & (~np.isfinite(dt)); d += 1.0
    return dt
