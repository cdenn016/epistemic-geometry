# -*- coding: utf-8 -*-
"""
Created on Mon Aug 11 16:05:57 2025

@author: chris and christine
"""

import numpy as np

import time
from joblib import Parallel, delayed
import numpy as np
import config
from natural_gradient import (compute_inverse_fisher_field_natural,
                              )
from get_generators import get_generators
from omega import exp_lie_algebra_irrep, d_exp_phi_exact, d_exp_phi_tilde_exact
             
from numerical_utils import sanitize_sigma, safe_omega_inv, safe_inv, soft_clip_phi_norm, masked_cond_proxy, masked_stat        
from generalized_diagnostics_metrics import compute_alignment_field_general

from update_terms_phi import ( 
    accumulate_phi_morphism_self_feedback, accumulate_phi_alignment_gradient,
    grad_feedback_phi_direct, grad_feedback_phi_tilde_direct, grad_self_phi_direct,
    grad_self_phi_tilde_direct)

from update_terms_mu_sigma import accumulate_mu_sigma_gradient
from bundle_morphism_utils import compute_direct_morphisms
from update_crossscale_terms import (
    accumulate_crossscale_gradients,
    accumulate_xscale_q_dn_gaugecov,
    # If/when you add model versions:
    accumulate_xscale_p_dn_gaugecov,
    
)
from bundle_crossscale_lambda import rebuild_downscale_maps




# --- 1) preprocess all agents once per outer step ----------------------------

def preprocess_all_agents(agents, params, G_q=None, G_p=None):
    """
    Build/refresh: generators, Σ sanitization + inverses, exp(φ)/exp(−φ),
    Fisher caches (optional), and reset per-step transport caches.
    Call this ONCE per step BEFORE you build Ω and Λ caches.
    """
    for a in agents:
        preprocess_agent_fields(a, params, G_q=G_q, G_p=G_p)



# --- 2) cross-scale Λ caches (per child->parent), gauge-covariant ------------

def build_all_lambda_caches(agents):
    """
    For every child that has parent_ids, build Λ_{c→P}^q and Λ_{c→P}^p
    using cached exp(φ)/exp(−φ). No pseudoinverses. Populates the per-parent maps.
    Safe to call every step after preprocess; cheap einsums.
    """
    # Quick map for id -> agent
    id2agent = {a.id: a for a in agents}

    # Require exp caches to be present
    for a in agents:
        if a._exp_phi is None or a._exp_neg_phi is None:
            raise RuntimeError(f"Agent {a.id} missing exp(phi) caches. Call preprocess_all_agents() first.")
        if a._exp_phi_model is None or a._exp_neg_phi_model is None:
            raise RuntimeError(f"Agent {a.id} missing exp(phi_model) caches. Call preprocess_all_agents() first.")

    # Build Λ for existing child→parent relations
    for child in agents:
        if not getattr(child, "parent_ids", []):
            continue
        for pid in child.parent_ids:
            if pid not in id2agent:
                continue
            parent = id2agent[pid]

            # q-bundle: Λ_up = exp(φ_P) @ exp(-φ_c), Λ_dn = exp(φ_c) @ exp(-φ_P)
            child.Lambda_up_q_map[pid] = np.einsum("...ik,...kj->...ij", parent._exp_phi, child._exp_neg_phi)
            child.Lambda_dn_q_map[pid] = np.einsum("...ik,...kj->...ij", child._exp_phi, parent._exp_neg_phi)

            # p-bundle: same with φ̃
            child.Lambda_up_p_map[pid] = np.einsum("...ik,...kj->...ij", parent._exp_phi_model, child._exp_neg_phi_model)
            child.Lambda_dn_p_map[pid] = np.einsum("...ik,...kj->...ij", child._exp_phi_model, parent._exp_neg_phi_model)

            # Optional: back-compat single Λ for the primary parent
            if child.primary_parent() == pid:
                # Global (KxK) representative via simple masked mean (fast fallback).
                # If you prefer log–Euclidean mean, replace these two with your stable logm/expm batch.
                m = (child.mask > 0) & (parent.mask > 0)
                if m.any():
                    Lu = child.Lambda_up_q_map[pid][m]
                    child.Lambda_up_q = Lu.mean(axis=0)
                    child.Lambda_dn_q = np.linalg.pinv(child.Lambda_up_q)

                    Lu_p = child.Lambda_up_p_map[pid][m]
                    child.Lambda_up_p = Lu_p.mean(axis=0)
                    child.Lambda_dn_p = np.linalg.pinv(child.Lambda_up_p)




def is_adjacent_parent(child, parent):
    return (parent is not None) and (getattr(parent, "level", None) == getattr(child, "level", None) + 1)




def zero_all_gradients(agent):
    """
    Zero (and if missing, create) all gradient buffers,
    keeping legacy aliases in sync and ensuring arrays are writeable.
    """
    def ensure_buf(name, like):
        arr = getattr(agent, name, None)
        if arr is None and like is not None:
            arr = np.zeros_like(like)
        elif arr is not None and not arr.flags.writeable:
            arr = np.array(arr, copy=True)
        setattr(agent, name, arr)
        return arr

    # Canonical grads (create from fields if needed)
    g_mu_q   = ensure_buf("grad_mu_q",    getattr(agent, "mu_q_field", None))
    g_sg_q   = ensure_buf("grad_sigma_q", getattr(agent, "sigma_q_field", None))
    g_mu_p   = ensure_buf("grad_mu_p",    getattr(agent, "mu_p_field", None))
    g_sg_p   = ensure_buf("grad_sigma_p", getattr(agent, "sigma_p_field", None))
    g_phi    = ensure_buf("grad_phi",       getattr(agent, "phi", None))
    g_phit   = ensure_buf("grad_phi_tilde", getattr(agent, "phi_model", None))
    g_Phi    = ensure_buf("grad_Phi",       getattr(agent, "bundle_morphism_q_to_p", None))
    g_Phit   = ensure_buf("grad_Phi_tilde", getattr(agent, "bundle_morphism_p_to_q", None))

    # Keep legacy aliases in sync (as references, not copies)
    if g_mu_q is not None:
        agent.grad_mu_q_field = g_mu_q
    if g_sg_q is not None:
        agent.grad_sigma_q_field = g_sg_q
    if g_mu_p is not None:
        agent.grad_mu_p_field = g_mu_p
    if g_sg_p is not None:
        agent.grad_sigma_p_field = g_sg_p

    # Zero safely
    for arr in (g_mu_q, g_sg_q, g_mu_p, g_sg_p, g_phi, g_phit, g_Phi, g_Phit):
        if isinstance(arr, np.ndarray):
            arr.fill(0)


    

        

def build_all_omega_caches(agents):
    """
    Build Ω and Ω̃ caches for each agent using their precomputed exp(φ).
    Should be called AFTER preprocess_agent_fields for all agents.
    """
    for agent_i in agents:
        agent_i.Omega_cache = {}
        agent_i.Omega_tilde_cache = {}

        for nb in agent_i.neighbors:
            j = nb["id"]
            agent_j = agents[j]

            Omega_ij = np.einsum("...ik,...kj->...ij", agent_i._exp_phi, agent_j._exp_neg_phi)
            Omega_tilde_ij = np.einsum("...ik,...kj->...ij", agent_i._exp_phi_model, agent_j._exp_neg_phi_model)

            agent_i.Omega_cache[j] = Omega_ij
            agent_i.Omega_tilde_cache[j] = Omega_tilde_ij
 
            
 
def preprocess_agent_fields(agent, params, G_q=None, G_p=None):
    eps        = getattr(config, "eps", 1e-8)
    group_name = config.group_name
    strict     = params.get("sanitize_strict", True) if params else True
    exp_jobs   = params.get("exp_n_jobs", 1)

    # ── Generators: prefer provided -> cached -> compute
    if G_q is not None:
        agent.generators_q = G_q
    if G_p is not None:
        agent.generators_p = G_p

    G_q = getattr(agent, "generators_q", None)
    if G_q is None or (isinstance(G_q, np.ndarray) and G_q.size == 0):
        G_q = get_generators(group_name, config.K_q)
        agent.generators_q = G_q

    G_p = getattr(agent, "generators_p", None)
    if G_p is None or (isinstance(G_p, np.ndarray) and G_p.size == 0):
        G_p = get_generators(group_name, config.K_p)
        agent.generators_p = G_p

    # SPD sanitize
    agent.sigma_q_field = sanitize_sigma(agent.sigma_q_field, strict=strict)
    agent.sigma_p_field = sanitize_sigma(agent.sigma_p_field, strict=strict)

    # Cache inverses
    agent.sigma_q_inv = safe_inv(agent.sigma_q_field, eps=eps)
    agent.sigma_p_inv = safe_inv(agent.sigma_p_field, eps=eps)

    # Condition proxies (masked, robust)
    agent._cond_proxy_q = masked_cond_proxy(agent.sigma_q_field, agent.mask)
    agent._cond_proxy_p = masked_cond_proxy(agent.sigma_p_field, agent.mask)

    # exp(φ), exp(φ̃)
    agent._exp_phi = exp_lie_algebra_irrep(
        agent.phi, G_q, group_name=group_name,
        max_norm=config.phi_exp_clip,
        threshold=getattr(config, "phi_exp_threshold", 1e-3),
        n_jobs=exp_jobs, verbose=False
    )
    agent._exp_phi_model = exp_lie_algebra_irrep(
        agent.phi_model, G_p, group_name=group_name,
        max_norm=config.phi_exp_clip,
        threshold=getattr(config, "phi_exp_threshold", 1e-3),
        n_jobs=exp_jobs, verbose=False
    )

    # exp(−φ), exp(−φ̃): transpose for orthogonal reps
    if getattr(config, "so3_irreps_are_orthogonal", True):
        agent._exp_neg_phi       = np.swapaxes(agent._exp_phi,      -1, -2)
        agent._exp_neg_phi_model = np.swapaxes(agent._exp_phi_model,-1, -2)
    else:
        agent._exp_neg_phi       = safe_omega_inv(agent._exp_phi, debug=False)
        agent._exp_neg_phi_model = safe_omega_inv(agent._exp_phi_model, debug=False)

    # Reset per-step transport caches
    agent.Omega_cache = {}
    agent.Omega_tilde_cache = {}

    # Optional Fisher metric caches for φ updates
    agent.inverse_fisher_phi        = compute_inverse_fisher_field_natural(agent, G_q, field="phi")
    agent.inverse_fisher_phi_model  = compute_inverse_fisher_field_natural(agent, G_p, field="phi_model")

    # Dev-only assert
    if getattr(config, "assert_spd_after_sanitize", False):
        wq = np.linalg.eigvalsh(0.5*(agent.sigma_q_field + np.swapaxes(agent.sigma_q_field,-1,-2)))
        wp = np.linalg.eigvalsh(0.5*(agent.sigma_p_field + np.swapaxes(agent.sigma_p_field,-1,-2)))
        floor = getattr(config, "sigma_eig_floor", 1e-6)
        if (wq <= floor).any() or (wp <= floor).any():
            raise RuntimeError("Non-SPD Σ after sanitize.")

def update_parent_ramps(runtime_ctx, *, base_q=None, base_p=None):
    import numpy as np, config
    base_q = config.lambda_xscale_q if base_q is None else base_q
    base_p = getattr(config, "lambda_xscale_p", 0.0) if base_p is None else base_p
    freeze = getattr(config, "parent_freeze_steps", 10)
    ramp   = getattr(config, "parent_ramp_steps", 50)
    for P in runtime_ctx.parents_by_region.values():
        age = runtime_ctx.global_step - getattr(P, "birth_step", runtime_ctx.global_step)
        if age <= freeze:
            P.lambda_q_weight = 0.0; P.lambda_p_weight = 0.0; continue
        t = min(max(age - freeze, 0), max(ramp, 1))
        s = 0.5 * (1 - np.cos(np.pi * t / max(ramp, 1)))
        P.lambda_q_weight = float(s * base_q)
        P.lambda_p_weight = float(s * base_p)

