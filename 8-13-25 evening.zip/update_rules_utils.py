# -*- coding: utf-8 -*-
"""
Created on Tue Aug 12 20:10:51 2025

@author: chris and christine
"""

import numpy as np
import config

from generalized_diagnostics_metrics import compute_alignment_field_general
from bundle_morphism_utils import init_parent_morphisms
from preprocess_utils import build_all_omega_caches, build_all_lambda_caches, preprocess_all_agents
from detector import spawn_or_update_parents, detect_overlap_aligned_regions








def _detect_and_spawn(agents, Gq, Gp, params, ctx):
    H, W = agents[0].mask.shape
    detector_period = int(getattr(config, "detector_period", 2))
    do_detect = ((ctx.global_step % detector_period) == 0)

    active = {}
    cand_map = np.zeros((H, W), np.float32)
    if not do_detect:
        return  # no change this step

    active = detect_overlap_aligned_regions(
        agents, H=H, W=W,
        min_kids=getattr(config, "seed_min_kids", 2),
        kl_tau  =getattr(config, "emerge_tau", 0.28),
        min_area=getattr(config, "emerge_min_area", 8),
    )
    for R in active.values():
        cand_map = np.maximum(cand_map, np.asarray(R.mask, np.float32))

    parents, next_pid = spawn_or_update_parents(
        active_regions=active,
        agents=agents,
        parents_by_id=ctx.parents_by_region,
        next_parent_id=ctx.next_parent_id,
        field_generators=(Gq, Gp),
    )
    # normalize & insert
    parents = _as_parent_dict(parents)
    existing = ctx.parents_by_region
    for pid, P in parents.items():
        existing[int(pid)] = P
        if not hasattr(P, "_age"):   P._age = 0
        if not hasattr(P, "_grace"): P._grace = int(getattr(config, "parent_freeze_steps", 0))
        
        try:
            from bundle_coarsegrain_init import coarsegrain_parent_from_children
            cg_eps = float(getattr(config, "cg_eps", 1e-6))
            cg_tau = float(getattr(config, "parent_cover_support_eps", 0.30))
            coarsegrain_parent_from_children(P, agents, eps=cg_eps, mask_tau=cg_tau)
           
            
           # strict shape check (pinpoint offender)
            Sq = getattr(P, "sigma_q_field", None)
            Sp = getattr(P, "sigma_p_field", None)
            if bool(getattr(config, "debug_strict", True)):
                for name, S in (("sigma_q_field", Sq), ("sigma_p_field", Sp)):
                    if S is None:
                        continue
                    S = np.asarray(S)
                    assert S.ndim == 4 and S.shape[-1] == S.shape[-2], \
                        f"[CG->ASSIGN] {name} bad shape {S.shape} for parent {getattr(P,'id','?')}"                
        except Exception as e:
            print(f"[WARN] coarsegrain/init failed for parent {getattr(P,'id','?')}: {e}")


    ctx.parents_by_region = existing
    ctx.next_parent_id = max(int(ctx.next_parent_id), int(next_pid),
                             (max(existing.keys()) + 1) if existing else 1)

    # coverage maps for optional seeding-from-uncovered
    support_eps = float(getattr(config, "parent_cover_support_eps", 0.30))
    P_support = np.zeros((H, W), dtype=bool)
    for P in ctx.parents_by_region.values():
        P_support |= (np.asarray(P.mask, np.float32) > support_eps)

    erode_iters = int(getattr(config, "parent_cover_erode", 0))
    if erode_iters > 0:
        try:
            from scipy.ndimage import binary_erosion
            P_support = binary_erosion(P_support, iterations=erode_iters, border_value=0)
        except Exception:
            core = P_support.copy()
            for _ in range(erode_iters):
                up    = np.pad(core[1: , : ], ((0,1),(0,0)))
                down  = np.pad(core[:-1, : ], ((1,0),(0,0)))
                left  = np.pad(core[: , 1: ], ((0,0),(0,1)))
                right = np.pad(core[: , :-1], ((0,0),(1,0)))
                core &= up & down & left & right
            P_support = core

    seed_floor = float(getattr(config, "parent_seed_floor", 0.12))
    cand_bool  = (cand_map > seed_floor)
    uncovered_bool = cand_bool & ~P_support

    from parent_growth import seed_new_parents_from_uncovered
    seed_new_parents_from_uncovered(
        ctx,
        uncovered_bool,
        children=agents,
        generators_q=Gq, generators_p=Gp,
        min_area=int(getattr(config, "emerge_min_area", 8)),
        iou_thr=float(getattr(config, "parent_new_iou_thr", 0.40)),
        max_new_per_step=int(getattr(config, "parent_max_new_per_step", 2)),
        min_interseed_px=int(getattr(config, "parent_min_interseed_px", 6)),
    )

# --- Drop-in guard: force Σ to (H,W,K,K) if a stack axis slipped in ---

def _coerce_sigma_4d_on_agent(agent, *, reduce_stack="mean", eps=1e-8):
    import numpy as np
    def _coerce(S, mask_hw):
        if S is None: return S
        S = np.asarray(S)
        H, W = np.asarray(mask_hw).shape
        if S.ndim == 4 and S.shape[0]==H and S.shape[1]==W and S.shape[-1]==S.shape[-2]:
            # tidy SPD
            K = S.shape[-1]
            return 0.5*(S + S.swapaxes(-1,-2)) + eps*np.eye(K, dtype=S.dtype)
        # find (H,W)
        if S.shape[-1] != S.shape[-2]:
            raise ValueError(f"Σ must end with (K,K); got {S.shape}")
        K = S.shape[-1]
        # locate H,W
        hw = None
        for i in range(S.ndim-2):
            for j in range(i+1, S.ndim-2):
                if S.shape[i]==H and S.shape[j]==W:
                    hw = (i,j); break
            if hw: break
        if hw is None:
            raise ValueError(f"cannot locate (H,W)=({H},{W}) in Σ{S.shape}")
        # move H,W to front and collapse any stack axes
        S = np.moveaxis(S, (hw[0], hw[1]), (0,1))  # (H,W,*stack*,K,K)
        if S.ndim > 4:
            n = int(np.prod(S.shape[2:-2]))
            S = S.reshape(H, W, n, K, K)
            if reduce_stack == "mean":
                S = np.nanmean(S, axis=2)
            else:
                tr = np.trace(S, axis1=-2, axis2=-1)
                idx = np.nanargmax(tr, axis=2)
                S = S[np.arange(H)[:,None], np.arange(W)[None,:], idx, :, :]
        # SPD tidy
        return 0.5*(S + S.swapaxes(-1,-2)) + eps*np.eye(K, dtype=S.dtype)

    m = getattr(agent, "mask", None)
    if m is None: return
    agent.sigma_q_field = _coerce(getattr(agent, "sigma_q_field", None), m)
    agent.sigma_p_field = _coerce(getattr(agent, "sigma_p_field", None), m)



def _assign_children_to_parents(children, parents_by_id, eps=1e-3):
    Pmasks = {int(pid): (np.asarray(P.mask, np.float32) > float(eps)) for pid, P in parents_by_id.items()}
    if not Pmasks:
        for ch in children: setattr(ch, "parent_id", -1)
        return
    for ch in children:
        cm = (np.asarray(ch.mask, np.float32) > float(eps))
        best, best_ov = -1, 0
        for pid, pm in Pmasks.items():
            ov = int((cm & pm).sum())
            if ov > best_ov:
                best, best_ov = pid, ov
        ch.parent_id = int(best) if best_ov > 0 else -1



from parent_growth import compute_parent_growth_maps_pure, apply_parent_growth
from runtime_context import runtime_ctx

# at top of the file (if not already)
import numpy as np
import config
from parent_growth import compute_parent_growth_maps_pure, apply_parent_growth

def _grow_and_age_parents(ctx, children, params):
    """
    Phase E — growth (pure -> apply), then simple aging.
    ctx: runtime context with ctx.parents_by_region
    children: list of child agents (for coverage/KL inputs)
    params: (unused here, kept for signature consistency)
    """
    # no parents -> nothing to do
    if not getattr(ctx, "parents_by_region", None):
        return

    # --- compute (pure) ---
    growth_maps = compute_parent_growth_maps_pure(
        ctx, children,
        tau_grow=getattr(config, "parent_tau_grow", 0.30),     # allow "p60"
        tau_shrink=getattr(config, "parent_tau_shrink", 0.18), # allow "p40", etc.
        kappa=getattr(config, "parent_kappa", 0.05),           # allow "auto"
        grow_band=int(getattr(config, "parent_grow_band", 1)),
        shrink_band=int(getattr(config, "parent_shrink_band", 1)),
        mask_tau=float(getattr(config, "parent_growth_core_tau", 0.20)),
    )


    # --- apply (mutating) ---
    apply_parent_growth(
        ctx, growth_maps,
        eta_grow=float(getattr(config, "parent_eta_grow", 0.08)),
        eta_shrink=float(getattr(config, "parent_eta_shrink", 0.12)),
        min_area=int(getattr(config, "parent_min_area", 10)),
        max_area=getattr(config, "parent_max_area", None),
        delta_cap=float(getattr(config, "parent_delta_cap", 0.05)),
        blur_iters=int(getattr(config, "parent_blur_iters", 1)),
    )

    # --- aging / grace bookkeeping ---
    for P in ctx.parents_by_region.values():
        P._age = int(getattr(P, "_age", 0)) + 1
        if hasattr(P, "_grace"):
            P._grace = max(0, int(getattr(P, "_grace", 0)) - 1)

    # optional terse log
    if getattr(config, "debug_growth_log", False):
        thr = float(getattr(config, "parent_area_threshold",
                    getattr(config, "parent_growth_core_tau", 0.20)))

        areas = [int((np.asarray(P.mask) > thr).sum()) for P in ctx.parents_by_region.values()]
        if areas:
            print(f"[GROW] parents={len(areas)} median_area={int(np.median(areas))} max_area={max(areas)}")




def _pre_light(all_agents, params, Gq, Gp):
    pre = dict(params)
    pre["sanitize_strict"] = pre.get("sanitize_strict_pre", False)
    pre["exp_n_jobs"] = 1
    preprocess_all_agents(all_agents, pre, Gq, Gp)
    build_all_omega_caches(all_agents)
    build_all_lambda_caches(all_agents)





def _post_strict(all_agents, params, Gq, Gp):
    post = dict(params)
    post["sanitize_strict"] = True
    post["exp_n_jobs"] = 1
    preprocess_all_agents(all_agents, post, Gq, Gp)
    build_all_omega_caches(all_agents)
    build_all_lambda_caches(all_agents)




def _refresh_child_kl_fields(children, all_agents, eps):
    for A in children:
        A.cached_alignment_kl       = compute_alignment_field_general(all_agents, A.id, field_type="belief", log_eps=eps)
        A.cached_model_alignment_kl = compute_alignment_field_general(all_agents, A.id, field_type="model",  log_eps=eps)




def _as_parent_dict(obj):
    """Accept dict, list, or single parent object; return {pid: parent} dict."""
    import collections.abc as _abc
    if obj is None:
        return {}
    if isinstance(obj, dict):
        return {int(getattr(p, "id", pid)): p for pid, p in obj.items()}
    if isinstance(obj, _abc.Iterable) and not hasattr(obj, "mask"):
        return {int(getattr(p, "id", i)): p for i, p in enumerate(obj)}
    # single parent object
    return {int(getattr(obj, "id", 0)): obj}
