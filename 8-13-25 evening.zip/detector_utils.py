# -*- coding: utf-8 -*-
"""
Created on Tue Aug 12 21:36:20 2025

@author: chris and christine
"""
from collections import deque

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass
from typing import Dict, List, Optional, Tuple
import numpy as np
import config
from agent_schema import Agent
from runtime_context import runtime_ctx
from parent_mask_utils import (child_activity_map, cheap_dt, compute_pairwise_agreement_maps,
                               resize_nn, build_parent_mask_from_group, _label4 )


@dataclass
class Region:
    id: int
    mask: np.ndarray
    state: str
    age: int = 0
    t_activated: Optional[int] = None
    child_ids: List[int] = field(default_factory=list)

@dataclass
class DetectorState:
    regions: Dict[int, Region] = field(default_factory=dict)
    next_id: int = 0
    step: int = 0


def _compute_candidate_or_union(P, agents, H, W, dtype):
    cand = _compute_parent_candidate(P, agents)
    if cand is None:
        u = np.zeros((H, W), bool)
        for i in getattr(P, "child_ids", []): u |= (np.asarray(agents[i].mask) > 0)
        return u.astype(dtype)
    return np.asarray(cand, dtype=dtype)

def _growth_gate_from_overlap_core_activity(P, agents, H, W, eps, grow_min_kids):
    
    # overlap count
    cnt = np.zeros((H, W), np.int32)
    active_union = np.zeros((H, W), bool)
    for i in getattr(P, "child_ids", []):
        ch = agents[i]
        a = child_activity_map(ch, H, W, eps=eps)
        if a is None: continue
        active_union |= a
        cnt += (a & (np.asarray(ch.mask) > eps)).astype(np.int32)
    gate = np.ones((H, W), np.float32)
    if grow_min_kids > 0:
        gate *= np.clip(cnt.astype(np.float32) / float(grow_min_kids), 0.0, 1.0)
    # distance to core
    if getattr(P, "_core_map", None) is not None and P._core_map.any():
        dt = cheap_dt(P._core_map.astype(bool))
        r = float(getattr(config, "parent_core_decay_px", 6.0))
        gate *= np.exp(-dt / max(r, 1.0)).astype(np.float32)
    # activity
    gate *= active_union.astype(np.float32)
    return np.clip(gate, 0.0, 1.0)

def _should_reseed(P, cand):
    reseed_period = getattr(config, "parent_reseed_period", 0)
    if reseed_period <= 0: return False
    if (getattr(runtime_ctx, "global_step", 0) % reseed_period) != 0: return False
    def _iou(a, b, thr=1e-3):
        A = (a > thr); B = (b > thr); inter = (A & B).sum(); union = (A | B).sum()
        return float(inter) / max(1, int(union))
    return _iou(P.mask, cand, thr=1e-3) < float(getattr(config, "parent_reseed_iou", 0.30))




def _median_child_kl_in_mask(P, agents, eval_mask) -> float:
    """
    Median of children KL values inside eval_mask for parent P.
    Falls back to +inf if nothing valid.
    """
    import numpy as np
    H, W = P.mask.shape
    vals = []

    for i in getattr(P, "child_ids", []):
        ch = agents[i]
        kl = getattr(ch, "cached_alignment_kl", None)
        if kl is None:
            continue
        k = np.asarray(kl).squeeze()
        # resize if needed
        if k.shape != (H, W):
            # cheap NN resize
            yi = np.clip(np.rint(np.linspace(0, k.shape[0]-1, H)).astype(int), 0, k.shape[0]-1)
            xi = np.clip(np.rint(np.linspace(0, k.shape[1]-1, W)).astype(int), 0, k.shape[1]-1)
            k = k[yi][:, xi]

        m = np.isfinite(k) & eval_mask
        if m.any():
            vals.append(k[m])

    if not vals:
        return float("inf")
    v = np.concatenate(vals)
    if v.size == 0:
        return float("inf")
    return float(np.median(v))




def _ensure_parents_for_regions(active_regions, parents_by_id, next_parent_id, H, W, dtype, Kq, Kp):
    """
    Match current regions to existing parents by IoU. Reuse on good match; else spawn new.
    Returns (rid_to_pid, next_parent_id).
    """
    iou_thr = float(getattr(config, "parent_reuse_iou_min",
                            getattr(config, "parent_reseed_iou", 0.30)))

    # cache masks
    reg_items = [(rid, np.asarray(R.mask, dtype=bool)) for rid, R in active_regions.items()]
    par_items = [(pid,
                  np.asarray((P._region_proposal if getattr(P, "_region_proposal", None) is not None else P.mask)) > 1e-3)
                 for pid, P in parents_by_id.items()]

    def _iou(A, B):
        inter = np.count_nonzero(A & B)
        if inter == 0: return 0.0
        unio  = np.count_nonzero(A | B)
        return float(inter) / float(unio) if unio else 0.0

    taken_parents = set()
    new_map = {}      # parent_id -> parent
    rid_to_pid = {}   # region id -> parent id

    for rid, Rmask in reg_items:
        best_pid, best_iou = None, 0.0
        for pid, Pmask in par_items:
            if pid in taken_parents:
                continue
            iou = _iou(Rmask, Pmask)
            if iou > best_iou:
                best_iou, best_pid = iou, pid

        if best_pid is not None and best_iou >= iou_thr:
            # reuse
            P = parents_by_id[best_pid]
            P._region_proposal = Rmask.astype(dtype)
            new_map[best_pid] = P
            rid_to_pid[rid] = best_pid
            taken_parents.add(best_pid)
        else:
            # spawn new
            Pnew = _new_parent(next_parent_id, H, W, dtype, Kq, Kp, Rmask.astype(dtype))
            new_map[next_parent_id] = Pnew
            rid_to_pid[rid] = next_parent_id
            next_parent_id += 1

    parents_by_id.clear()
    parents_by_id.update(new_map)
    return rid_to_pid, next_parent_id



def _assign_children_to_parents(active_regions, agents, parents_by_id, *, eps=None, use_activity=True, rid_to_pid=None):
    import numpy as np
    if not agents or not active_regions:
        return

    H, W = agents[0].mask.shape
    eps = float(eps if eps is not None else getattr(config, "support_cutoff_eps", 1e-6))

    # clear
    for P in parents_by_id.values():
        P.child_ids = []

    # child supports (activity-aware)
    child_support = []
    for A in agents:
        m = np.asarray(A.mask)
        if m.shape != (H, W):
            m = resize_nn(m, (H, W))
        if use_activity:
            act = child_activity_map(A, H, W,
                                     mu_tau=getattr(config, "activity_mu_tau", 1e-3),
                                     trsig_tau=getattr(config, "activity_trsig_tau", 1e-3),
                                     eps=eps)
            sup = (np.asarray(act) > 0) if act is not None else (m > eps)
        else:
            sup = (m > eps)
        child_support.append(sup)

    # use provided mapping; no dict attribute hacks
    for rid, R in active_regions.items():
        pid = rid_to_pid.get(rid, rid) if rid_to_pid else rid
        if pid not in parents_by_id:
            continue
        P = parents_by_id[pid]

        Rmask = np.asarray(R.mask)
        if Rmask.shape != (H, W):
            Rmask = resize_nn(Rmask, (H, W))
        Rbin = (Rmask > eps)

        kids = [i for i, sup in enumerate(child_support) if np.any(sup & Rbin)]
        P.child_ids = kids
        for i in kids:
            if not hasattr(agents[i], "parent_ids") or agents[i].parent_ids is None:
                agents[i].parent_ids = []
            if P.id not in agents[i].parent_ids:
                agents[i].parent_ids.append(P.id)



def _compute_parent_candidate(P, agents):
    
    cand = build_parent_mask_from_group(
        children=agents, child_ids=getattr(P, "child_ids", []),
        A_maps={}, joint_maps={}, tau=getattr(config, "tau_align_emergent", 0.30),
        m_core=getattr(config, "m_core_emergent", 2), A_min=getattr(config, "A_min_emergent", 20),
        soft=True, smooth_iters=1,
    )
    if cand is None:
        # fallback: union of child masks
        H, W = P.mask.shape
        u = np.zeros((H, W), bool)
        for i in getattr(P, "child_ids", []): u |= (np.asarray(agents[i].mask) > 0)
        return u.astype(P.mask.dtype)
    c = np.asarray(cand)
    return c[0] if (c.ndim == 3 and c.shape[0] == 1) else c


def _emergence_gate(P, children, eval_mask, H, W, eps):
    """
    Decide whether a parent 'emerges' (becomes active).
    Safe when KL is missing and when emerge_tau=None (disables KL test).
    """
    import numpy as np
    # config knobs
    MIN_AREA   = int(getattr(config, "emerge_min_area", 2))
    MIN_KIDS   = int(getattr(config, "seed_min_kids", 2))
    EMERGE_TAU = getattr(config, "emerge_tau", None)  # may be float or None

    # area gate
    area_ok = bool(np.asarray(eval_mask).sum() >= MIN_AREA)

    # overlap/children gate (count kids active on eval_mask)
    kids_ok = False
    if getattr(P, "child_ids", None):
        cnt = 0
        for i in P.child_ids:
            ch = children[i]
            m = np.asarray(getattr(ch, "mask", 0.0), np.float32)
            if m.shape != (H, W):
                m = resize_nn(m, (H, W))
            # "active" if mask exceeds tiny eps somewhere on eval region
            if ( (m > eps) & eval_mask ).any():
                cnt += 1
        kids_ok = (cnt >= MIN_KIDS)
    else:
        # fallback: if no explicit child_ids tracked, be permissive
        kids_ok = True

    # KL gate (median over eval_mask), but only if any KL exists and EMERGE_TAU is not None
    kl_ok = True
    if EMERGE_TAU is not None:
        kl_vals = []
        for i in getattr(P, "child_ids", range(len(children))):
            ch = children[i] if isinstance(i, int) else i
            k = getattr(ch, "cached_alignment_kl", None)
            if k is None:
                continue
            k = np.asarray(k)
            if k.shape != (H, W):
                k = resize_nn(k, (H, W))
            sel = eval_mask & np.isfinite(k)
            if sel.any():
                kl_vals.append(k[sel])
        if kl_vals:
            vec = np.concatenate(kl_vals).astype(np.float32, copy=False)
            kl_med = float(np.median(vec))
            kl_ok = (kl_med <= float(EMERGE_TAU))
        else:
            # no KL available → skip KL gating
            kl_ok = True

    emerged = bool(area_ok and kids_ok and kl_ok)

    # Optional: latch behavior / hysteresis (preserve once emerged)
    if getattr(P, "emerged", False):
        # you can add a soft condition to keep emerged unless area collapses completely
        if not area_ok:
            return False
        return True

    return emerged





def _make_region(mask: np.ndarray, rid: int):
    """
    Construct a Region with whatever signature your project uses.
    Tries several common ctor shapes; falls back to a simple object.
    """
    area  = int((mask > 0).sum())
    state = getattr(config, "region_active_state", "active")  # or 1 / True, if your code uses enums

    # Try common constructor shapes
    attempts = [
        lambda: Region(id=rid, state=state, mask=mask, area=area),
        lambda: Region(id=rid, state=state, mask=mask),
        lambda: Region(rid, state, mask),           # positional
        lambda: Region(mask=mask),                  # legacy minimal
        lambda: Region(mask),                       # very old minimal
    ]
    for ctor in attempts:
        try:
            return ctor()
        except TypeError:
            pass

    # Fallback: lightweight object with the fields we need downstream
    class _R: pass
    R = _R()
    R.id = rid
    R.state = state
    R.mask = mask
    R.area = area
    return R



def _label_components(binmap: np.ndarray) -> Tuple[np.ndarray, int]:
    H, W = binmap.shape
    labels = np.zeros((H, W), dtype=np.int32)
    lbl = 0
    seen = np.zeros_like(binmap, dtype=bool)
    for y in range(H):
        for x in range(W):
            if not binmap[y, x] or seen[y, x]: 
                continue
            lbl += 1
            q = deque([(y, x)])
            seen[y, x] = True
            labels[y, x] = lbl
            while q:
                cy, cx = q.popleft()
                for ny, nx in ((cy-1,cx),(cy+1,cx),(cy,cx-1),(cy,cx+1)):
                    if 0 <= ny < H and 0 <= nx < W and binmap[ny, nx] and not seen[ny, nx]:
                        seen[ny, nx] = True
                        labels[ny, nx] = lbl
                        q.append((ny, nx))
    return labels, lbl





def _parent_kl_stats(P, children, support_mask=None,
                     activity_mu_tau: float = 1e-3,
                     activity_trsig_tau: float = 1e-3,
                     eps: float = 1e-6) -> tuple[float, float]:
    """
    Robust mean/median KL inside a given support mask (or P.mask if None),
    aggregated over assigned *active* kids.
    Returns (mean, median); (inf, inf) if insufficient data.

    Activity = child mask & (||μ_q|| > tau OR tr(Σ_q) > tau).
    """

    # choose evaluation support
    pmask = np.asarray(support_mask if support_mask is not None else P.mask)
    if pmask.ndim != 2:
        pmask = pmask.squeeze()
    H, W = pmask.shape
    supp_parent = (pmask > 1e-2)
    if not supp_parent.any():
        return float("inf"), float("inf")

    vals = []
    child_ids = getattr(P, "child_ids", None)

    for ch in children:
        if child_ids is not None:
            # if child list is a subset, skip non-assigned
            if ch not in [children[i] for i in child_ids]:
                continue
        if getattr(ch, "parent_ids", None) is not None and (P.id not in ch.parent_ids):
            continue

        kl = getattr(ch, "cached_alignment_kl", None)
        if kl is None:
            continue

        k = np.asarray(kl)
        if k.ndim == 3 and k.shape[-1] == 1:
            k = k[..., 0]
        if k.shape != (H, W):
            k = resize_nn(k, (H, W))

        # activity gating
        act = child_activity_map(ch, H, W,
                                 mu_tau=activity_mu_tau,
                                 trsig_tau=activity_trsig_tau,
                                 eps=eps)
        if act is None:
            continue

        # restrict to BOTH supports: parent & child activity
        supp = supp_parent & act
        if not supp.any():
            continue

        v = k[supp]
        v = v[np.isfinite(v)]
        if v.size:
            vals.append(v)

    if not vals:
        return float("inf"), float("inf")

    vcat = np.concatenate(vals, axis=0)
    vcat = vcat[np.isfinite(vcat)]
    if vcat.size == 0:
        return float("inf"), float("inf")

    return float(vcat.mean()), float(np.median(vcat))







def _new_parent(pid, H, W, dtype, Kq, Kp, proposal):
    zeros3 = np.zeros((H, W, 3), dtype=dtype)
    eye_q = np.tile(np.eye(Kq, dtype=dtype), (H, W, 1, 1))
    eye_p = np.tile(np.eye(Kp, dtype=dtype), (H, W, 1, 1))
    P = Agent(
        id=pid, center=(0,0), radius=0.0, mask=np.zeros((H,W), dtype=dtype),
        mu_q_field=np.zeros((H,W,Kq), dtype=dtype), sigma_q_field=eye_q.copy(),
        mu_p_field=np.zeros((H,W,Kp), dtype=dtype), sigma_p_field=eye_p.copy(),
        phi=zeros3.copy(), phi_model=zeros3.copy(), neighbors=[]
    )
    P.level = 1
    P.birth_step = getattr(runtime_ctx, "global_step", 0)
    P.lambda_q_weight = 0.0; P.lambda_p_weight = 0.0
    P._region_proposal = np.clip(proposal, 0.0, 1.0).astype(dtype)
    P.emerged = False; P._prev_eval_mask = None
    P._emerge_on_cnt = 0; P._emerge_off_cnt = 0; P._core_map = None
    return P




def _alignment_score_from_pairs(children: List[Agent], *, field: str, generators, tau=0.30) -> np.ndarray:
    """
    Fast proxy: 1 - mean(agreement) over all neighbors per pixel.
    Uses your compute_pairwise_agreement_maps (A = exp(-KL/tau)).
    """
    H, W = children[0].mask.shape
    pairs, A_maps, joint = compute_pairwise_agreement_maps(children, tau=tau, field=("q" if field=="belief" else "p"), generators=generators)
    if not pairs:
        return np.ones((H, W), dtype=np.float32)
    acc = np.zeros((H, W), dtype=np.float32)
    cnt = np.zeros((H, W), dtype=np.float32)
    for key, A in A_maps.items():
        J = joint[key]
        acc[J] += A[J]
        cnt[J] += 1.0
    cnt = np.maximum(cnt, 1.0)
    agree_mean = acc / cnt
    return 1.0 - agree_mean  # lower is better