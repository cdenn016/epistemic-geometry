from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple
import numpy as np

import config
from agent_schema import Agent
from runtime_context import runtime_ctx
from bundle_coarsegrain_init import _refresh_parent_gauge_fields, coarsegrain_parent_from_children

from parent_mask_utils import resize_nn, child_activity_map  
from detector_utils import (
    _make_region, _label_components,
    _alignment_score_from_pairs,
    _new_parent, _ensure_parents_for_regions, _assign_children_to_parents,
    _compute_parent_candidate, _compute_candidate_or_union,
    _parent_kl_stats, _median_child_kl_in_mask,
    _emergence_gate, _should_reseed, _growth_gate_from_overlap_core_activity,
    Region, DetectorState, 
)

from parent_mask_utils import _label4 as label_components

from parent_growth import seed_new_parents_from_uncovered
from parent_mask_utils import  _dilate_bool as dilate_boolfn

from bundle_morphism_utils import have_parent_morphisms, init_parent_morphisms




# --- PURE detection wrapper (no side effects; returns regions + cand_map) ---
def compute_detection_maps_pure(
    agents,
    *,
    H=None,
    W=None,
    min_kids=2,
    kl_tau=0.28,
    min_area=8,
    resize_fn=None,         # optional: pass parent_mask_utils.resize_nn
):
    """
    Returns (active_regions, cand_map) without touching parents/ctx/caches.

    - active_regions: dict[rid -> Region], masks guaranteed to be (H,W) float32 in [0,1]
    - cand_map: (H,W) float32 in [0,1], max over region masks
    """
    import numpy as np
   

    if H is None or W is None:
        H, W = np.asarray(agents[0].mask).shape[:2]

    active = detect_overlap_aligned_regions(
        agents, H=H, W=W,
        min_kids=min_kids,
        kl_tau=kl_tau,
        min_area=min_area,
    )

    cand_map = np.zeros((H, W), np.float32)
    if not active:
        return active, cand_map

    # normalize every region mask to (H,W) float32
    for rid, R in list(active.items()):
        m = np.asarray(getattr(R, "mask", 0.0), np.float32)
        if m.ndim != 2:
            m = np.squeeze(m)
        if m.shape != (H, W):
            if resize_fn is None:
                from parent_mask_utils import resize_nn as _resize
                m = _resize(m, (H, W)).astype(np.float32)
            else:
                m = resize_fn(m, (H, W)).astype(np.float32)
        m = np.clip(m, 0.0, 1.0)
        R.mask = m  # make the Region self-consistent but still no global mutation
        cand_map = np.maximum(cand_map, m)

    return active, cand_map



def _detect_regions_pure(agents, params, ctx):
    import numpy as np
    import config as _cfg
    from detector import compute_detection_maps_pure  # if you use this; else keep your code

    H, W = np.asarray(agents[0].mask).shape[:2]
    detector_period = int(getattr(_cfg, "detector_period", 2))
    do_detect = ((ctx.global_step % detector_period) == 0)
    if not do_detect:
        return {}, np.zeros((H, W), np.float32)

    # --- SAFE parse for optional KL threshold ---
    _emerge = getattr(_cfg, "emerge_tau", 0.28)
    if (_emerge is None) or (isinstance(_emerge, str) and _emerge.strip().lower() in ("none", "off", "disabled", "")):
        kl_tau = None
    else:
        kl_tau = float(_emerge)

    active = detect_overlap_aligned_regions(
        agents, H=H, W=W,
        min_kids=int(getattr(_cfg, "seed_min_kids", 2)),
        kl_tau=kl_tau,                                # ← pass None to skip KL gating
        min_area=int(getattr(_cfg, "emerge_min_area", 8)),
        # weight_tau comes from config.parent_weight_tau inside the detector
    )

    cand_map = np.zeros((H, W), np.float32)
    for R in active.values():
        cand_map = np.maximum(cand_map, np.asarray(R.mask, np.float32))
    return active, cand_map



def _apply_spawn_from_regions(ctx, active_regions, cand_map, agents, Gq, Gp, params):
    """
    The ONLY place that mutates parents:
      - spawn/update parents for active regions
      - coarse-grain new/updated parents
      - optional 'seed from uncovered' using cand_map
    No preprocess(), no build_all_omega_caches(), no build_all_lambda_caches() here.
    """
    import numpy as np
    import config
    from parent_mask_utils import resize_nn, ensure_hw
    from bundle_coarsegrain_init import coarsegrain_parent_from_children
    # if _as_parent_dict lives elsewhere, import from there; otherwise keep your local helper
    # from detector import _as_parent_dict

    H, W = np.asarray(agents[0].mask).shape[:2]

    # 1) spawn/update from detector-active regions
    parents_list, next_pid = spawn_or_update_parents(
        active_regions=active_regions,
        agents=agents,
        parents_by_id=ctx.parents_by_region,
        next_parent_id=ctx.next_parent_id,
        field_generators=(Gq, Gp),
    )
    parents = _as_parent_dict(parents_list)

    # normalize & insert; coarsegrain immediately so masks/Σ are usable
    existing = ctx.parents_by_region
    prev_ids = set(existing.keys())

    for pid, P in parents.items():
        pid = int(getattr(P, "id", pid))
        existing[pid] = P
        if not hasattr(P, "_age"):   P._age = 0
        if not hasattr(P, "_grace"): P._grace = int(getattr(config, "parent_freeze_steps", 0))
        try:
            cg_eps = float(getattr(config, "cg_eps", 1e-6))
            cg_tau = float(getattr(config, "parent_cover_support_eps", 0.30))
            coarsegrain_parent_from_children(P, agents, eps=cg_eps, mask_tau=cg_tau)
            if bool(getattr(config, "debug_strict", True)):
                for name in ("sigma_q_field", "sigma_p_field"):
                    S = getattr(P, name, None)
                    if S is None:
                        continue
                    S = np.asarray(S)
                    assert S.ndim == 4 and S.shape[-1] == S.shape[-2], \
                        f"[CG->ASSIGN] {name} bad shape {S.shape} for parent {getattr(P,'id','?')}"
        except Exception as e:
            print(f"[WARN] coarsegrain/init failed for parent {getattr(P,'id','?')}: {e}")
            if getattr(config, "debug_parent_masks", False):
                print("  parent.mask", np.asarray(P.mask).shape)
                print("  child0.mask", np.asarray(agents[0].mask).shape)

    # registry bookkeeping
    ctx.parents_by_region = existing
    ctx.next_parent_id = max(
        int(ctx.next_parent_id),
        int(next_pid),
        (max(existing.keys()) + 1) if existing else 1
    )

    # --- visibility: log new parents from detector phase
    new_ids = sorted(set(existing.keys()) - prev_ids)
    if new_ids:
        areas = [int((np.asarray(existing[i].mask) > 0.5).sum()) for i in new_ids]
        print(f"[SPAWN] +{len(new_ids)} (detector): ids={new_ids} areas={areas}")

    # 2) seed-from-uncovered (optional)
    if bool(getattr(config, "use_seed_from_uncovered", True)):
        support_eps = float(getattr(config, "parent_cover_support_eps", 0.30))
        P_support = np.zeros((H, W), dtype=bool)
        for P in ctx.parents_by_region.values():
            pm = ensure_hw(getattr(P, "mask", 0.0), (H, W))
            P_support |= (pm > support_eps)

        erode_iters = int(getattr(config, "parent_cover_erode", 0))
        if erode_iters > 0:
            try:
                from scipy.ndimage import binary_erosion
                P_support = binary_erosion(P_support, iterations=erode_iters, border_value=0)
            except Exception:
                # simple 4-neighborhood fallback
                core = P_support.copy()
                for _ in range(erode_iters):
                    up    = np.pad(core[1: , : ], ((0,1),(0,0)))
                    down  = np.pad(core[:-1, : ], ((1,0),(0,0)))
                    left  = np.pad(core[: , 1: ], ((0,0),(0,1)))
                    right = np.pad(core[: , :-1], ((0,0),(1,0)))
                    core &= up & down & left & right
                P_support = core

        # make sure cand_map isn’t empty; if it is, fallback to child coverage
        cand_map = np.asarray(cand_map, np.float32)
        if not np.any(cand_map):
            # NEW: only allow a coverage fallback if explicitly requested
            if bool(getattr(config, "seed_from_coverage_when_no_regions", False)):
                for c in agents:
                    cand_map = np.maximum(cand_map, ensure_hw(getattr(c, "mask", 0.0), (H, W)))
                    

        seed_floor = float(getattr(config, "parent_seed_floor", 0.12))
        cand_bool  = (cand_map > seed_floor)
        uncovered_bool = cand_bool & ~P_support

        before = set(ctx.parents_by_region.keys())
        # global cap: parent_max_total (None/0 = unlimited)
        max_total = int(getattr(config, "parent_max_total", 0))
        step_budget = int(getattr(config, "parent_max_new_per_step", 2))
        if max_total > 0:
            step_budget = max(0, min(step_budget, max_total - len(before)))
        if step_budget > 0:
            seed_new_parents_from_uncovered(
                ctx,
                uncovered_bool,
                children=agents,
                generators_q=Gq, generators_p=Gp,
                min_area=int(getattr(config, "emerge_min_area", 8)),
                iou_thr=float(getattr(config, "parent_new_iou_thr", 0.40)),
                max_new_per_step=step_budget,
                min_interseed_px=int(getattr(config, "parent_min_interseed_px", 6)),
            )
        after = set(ctx.parents_by_region.keys())
        seeded = sorted(after - before)
    
        if seeded:
            thr = float(getattr(config, "parent_area_threshold",
                                getattr(config, "parent_growth_core_tau", 0.20)))
            stats = []
            for i in seeded:
                m = np.asarray(ctx.parents_by_region[i].mask, np.float32)
                stats.append({
                    "id": int(i),
                    "min": float(m.min()),
                    "max": float(m.max()),
                    "mean": float(m.mean()),
                    f"area>{thr}": int((m > thr).sum())
                })
            print("[SPAWN/DEBUG] newborn stats:", stats)














def _as_parent_dict(obj):
    """
    Normalize parents -> {pid: Parent}. Accepts dict, list, iterable, or None.
    Uses the parent's .id if present; else falls back to enumerate index.
    """
    import collections.abc as _abc
    if obj is None:
        return {}
    if isinstance(obj, dict):
        return {int(getattr(p, "id", pid)): p for pid, p in obj.items()}
    if isinstance(obj, _abc.Iterable):
        return {int(getattr(p, "id", i)): p for i, p in enumerate(obj)}
    # Single parent object?
    return {int(getattr(obj, "id", 0)): obj}










def _update_regions_hysteresis(det: DetectorState, score: np.ndarray,
                               *, Ton: float, Toff: float,
                               persistence_on: int, persistence_off: int,
                               min_area: int, smooth_iters: int) -> None:
    """
    Very small state machine: grow where score<Ton, decay where score>Toff.
    """
    H, W = score.shape
    low = (score < Ton).astype(np.float32)
    high = (score > Toff).astype(np.float32)

    # simple smoothing (same kernel as your utils)
    if smooth_iters > 0:
        k = np.array([[1,1,1],[1,2,1],[1,1,1]], dtype=np.float32); k /= k.sum()
        for _ in range(smooth_iters):
            pad = np.pad(low, 1, mode="edge")
            sm  = (
                k[0,0]*pad[:-2, :-2] + k[0,1]*pad[:-2,1:-1] + k[0,2]*pad[:-2,2:] +
                k[1,0]*pad[1:-1, :-2] + k[1,1]*pad[1:-1,1:-1] + k[1,2]*pad[1:-1,2:] +
                k[2,0]*pad[2:,  :-2] + k[2,1]*pad[2:, 1:-1] + k[2,2]*pad[2:,  2:]
            )
            low = np.clip(sm, 0.0, 1.0).astype(np.float32)

    # single region for now: union of low-score (you can split components if desired)
    core = (low > 0.5)
    area = int(core.sum())

    # find (or create) region 0
    R = det.regions.get(0, None)
    if R is None:
        if area >= min_area:
            det.regions[0] = Region(id=0, mask=low.copy(), state="incubating", age=0, t_activated=None)
        return

    # update existing
    R.age += 1
    if area == 0:
        if R.state in ("incubating", "active"):
            R.state = "decaying"
        # shrink fast
        R.mask *= 0.5
    else:
        # grow towards low
        R.mask = np.clip(0.90*R.mask + 0.10*low, 0.0, 1.0)
        if R.state == "candidate":
            if (R.mask > 0.3).sum() >= min_area and R.age >= persistence_on:
                R.state = "incubating"
        elif R.state == "incubating":
            if (R.mask > 0.3).sum() >= min_area and R.age >= persistence_on:
                R.state = "active"; R.t_activated = det.step
        elif R.state == "active":
            if (high > 0.5).mean() > 0.5 and R.age >= persistence_off:
                R.state = "decaying"

    if R.state == "decaying":
        R.mask *= 0.8
        if (R.mask > 0.3).sum() < (min_area // 2):
            del det.regions[0]


def detect_overlap_aligned_regions(children, *, H, W,
                                   min_kids=2,
                                   kl_tau=0.10,
                                   min_area=20,
                                   weight_tau=0.6,         # float or None (None = adaptive)
                                   activity_mu_tau=1e-3, activity_trsig_tau=1e-3,
                                   eps=1e-6,
                                   periodic=None):
    """
    Find regions where ≥min_kids children are active, the average child mask is strong,
    and the average alignment KL is low. Returns {rid: Region}.

    Improvements:
      • Activity fallback to mask if child_activity_map(...) returns None.
      • Interior weight gate supports adaptive threshold when weight_tau is None.
      • KL gate applies only if at least one child provided a finite KL map.
      • Optional 1px erosion (detector_edge_erode) happens after forming 'keep'.
    """
    import numpy as np
    if periodic is None:
        periodic = bool(getattr(config, "periodic_domain", False))

    cover  = np.zeros((H, W), dtype=np.int32)    # number of active kids
    weight = np.zeros((H, W), dtype=np.float32)  # sum of child mask weights
    kid_act, kid_kls = [], []

    # 1) accumulate activity, weights, and cached KLs
    mask_tau_mask = float(getattr(config, "detector_mask_tau", 1e-3))
    for ch in children:
        m = np.asarray(getattr(ch, "mask", 0.0))
        if m.shape != (H, W):
            m = resize_nn(m, (H, W)).astype(np.float32)
        else:
            m = m.astype(np.float32)

        act = child_activity_map(ch, H, W,
                                 mu_tau=activity_mu_tau,
                                 trsig_tau=activity_trsig_tau,
                                 eps=eps)
        # Fallback: if no explicit activity, use mask>tiny
        if act is None:
            a = (m > mask_tau_mask)
        else:
            a = np.asarray(act).astype(bool)

        cover  += a.astype(np.int32)
        weight += m * a.astype(np.float32)
        kid_act.append(a)

        k = getattr(ch, "cached_alignment_kl", None)
        if k is None:
            kid_kls.append(None)
        else:
            k = np.asarray(k)
            if k.shape != (H, W):
                k = resize_nn(k, (H, W))
            kid_kls.append(k.astype(np.float32))

    # 2) interior preference: require enough active kids AND strong mean mask
    keep = (cover >= int(min_kids))
    mean_weight = np.zeros((H, W), dtype=np.float32)
    nz = cover > 0
    mean_weight[nz] = weight[nz] / cover[nz].astype(np.float32)

    # interior weight gate (adaptive if weight_tau is None)
    cfg_tau = getattr(config, "parent_weight_tau", weight_tau)
    if cfg_tau is None:
        ww = mean_weight[(cover >= int(min_kids)) & (mean_weight > 0)]
        thr = float(np.percentile(ww, 60)) if ww.size else 0.0
    else:
        thr = float(cfg_tau)
    keep &= (mean_weight >= thr)

    # 3) KL filter (average over active, finite pixels) — only if any KL exists
    if kl_tau is not None:
        any_kl = any(k is not None for k in kid_kls)
        if any_kl:
            kl_sum = np.zeros((H, W), dtype=np.float32)
            kl_cnt = np.zeros((H, W), dtype=np.int32)
            for a, k in zip(kid_act, kid_kls):
                if k is None:
                    continue
                inside = a & np.isfinite(k)
                if inside.any():
                    kl_sum[inside] += k[inside]
                    kl_cnt[inside] += 1
            kl_mean = np.full((H, W), np.inf, dtype=np.float32)
            valid = kl_cnt > 0
            kl_mean[valid] = kl_sum[valid] / np.maximum(kl_cnt[valid], 1)
            keep &= (kl_mean <= float(kl_tau))
        # else: skip KL gating entirely if no KL present

    # --- connected components with optional 1px erosion ---
    pre_px = int(np.asarray(keep).sum())
    core = keep.astype(bool)

    erode_iters = int(getattr(config, "detector_edge_erode", 0))  # default OFF
    if erode_iters > 0 and core.any():
        for _ in range(erode_iters):
            if periodic:
                e = core.copy()
                e &= np.roll(core,  1, 0)
                e &= np.roll(core, -1, 0)
                e &= np.roll(core,  1, 1)
                e &= np.roll(core, -1, 1)
                core = e
            else:
                up    = np.pad(core[1: , : ], ((0,1), (0,0)))
                down  = np.pad(core[:-1, : ], ((1,0), (0,0)))
                left  = np.pad(core[: , 1: ], ((0,0), (0,1)))
                right = np.pad(core[: , :-1], ((0,0), (1,0)))
                core = core & up & down & left & right

    post_px = int(core.sum())
    min_area_eff = int(getattr(config, "emerge_min_area", min_area))

    # CC
    labels, nlab = label_components(core)
    regions = {}
    rid = 0
    for lbl in range(1, nlab + 1):
        comp = (labels == lbl)
        area = int(comp.sum())
        if area < min_area_eff:
            continue
        regions[rid] = _make_region(comp.astype(np.float32), rid)
        rid += 1

    # debug
    try:
        tau_repr = f"{cfg_tau:.3f}" if cfg_tau is not None else f"auto->{thr:.3f}"
        print(f"[DETECT] regs={len(regions)} px_keep={pre_px} px_post={post_px} "
              f"min_area={min_area_eff} weight_tau={tau_repr} "
              f"cover_sum={int(cover.sum())} mean_w={float(np.nan_to_num(mean_weight).mean()):.3f}")
    except Exception:
        pass

    return regions



def _update_single_parent(P, agents, step_now, H, W, eps, dtype):
    import numpy as np
    try:
        from parent_mask_utils import dilate_bool as dilate_boolfn
    except Exception:
        from parent_mask_utils import _dilate_bool as dilate_boolfn

    # --- knobs (new ones have safe defaults) --------------------------------
    freeze_steps  = max(0, int(getattr(config, "parent_freeze_steps", 2)))
    ramp_steps    = max(0, int(getattr(config, "parent_ramp_steps", 12)))
    alpha_base    = float(getattr(config, "parent_mask_alpha", 0.10))
    grow_min_kids = int(getattr(config, "parent_grow_min_kids", 2))
    delta_cap     = float(getattr(config, "parent_max_step_delta", 0.1))
    decay_empty   = 0.995
    periodic      = bool(getattr(config, "periodic_domain", False))

    # NEW: what counts as "support" for locality/dilation
    support_tau   = float(getattr(config, "parent_support_tau", 0.05))
    # NEW: local expansion halo around current support
    local_r_px    = int(getattr(config, "parent_local_radius_px", 3))
    # NEW: gently kill any mass far from support
    far_decay     = float(getattr(config, "parent_far_decay", 0.98))  # 1.0 = off
    # NEW: hard floor to zero-out dust
    floor_eps     = float(getattr(config, "parent_floor_eps", 1e-4))

    kids = getattr(P, "child_ids", [])
    P._core_map = _compute_core_from_kids(P, agents, H, W, eps).astype(np.float32) if kids else None

    # -- seed from core (unchanged) ------------------------------------------
    if (P.mask <= 1e-6).all() and P._core_map is not None and P._core_map.any():
        seed = P._core_map.astype(bool)
        expand_px = max(0, int(getattr(config, "parent_seed_expand_px", 2)))
        if expand_px > 0:
            seed = dilate_boolfn(seed, r=expand_px, periodic=periodic)
        P.mask = seed.astype(dtype) * 0.5

    cand = _compute_candidate_or_union(P, agents, H, W, dtype)

    # emergence gate (unchanged) ---------------------------------------------
    eval_mask = (P.mask > 1e-2)
    if not eval_mask.any():
        if getattr(P, "_region_proposal", None) is not None:
            eval_mask = (np.asarray(P._region_proposal) > 1e-2)
        elif cand is not None:
            eval_mask = (np.asarray(cand) > 1e-2)

    emerged = _emergence_gate(P, agents, eval_mask, H, W, eps)
    P.emerged = bool(emerged)

    if not P.emerged:
        target = None
        if getattr(P, "_region_proposal", None) is not None:
            target = np.asarray(P._region_proposal, dtype=np.float32)
        elif cand is not None:
            target = np.asarray(cand, dtype=np.float32)
        if target is not None:
            alpha_seed = float(getattr(config, "parent_seed_alpha", 0.15))
            pm = P.mask.astype(np.float32)
            P.mask = np.clip((1.0 - alpha_seed) * pm + alpha_seed * target, 0.0, 1.0).astype(dtype)
        return

    # EMA schedule (unchanged) -----------------------------------------------
    age = max(0, int(step_now - getattr(P, "birth_step", step_now)))
    if age < freeze_steps:
        alpha = 0.0
    else:
        denom = max(1, ramp_steps)
        ramp  = min(1.0, max(0.0, (age - freeze_steps) / denom))
        alpha = float(np.clip(alpha_base * ramp, 0.0, alpha_base))

    # no candidate → gentle decay and exit
    if cand is None:
        P.mask = (decay_empty * P.mask).astype(dtype)
        return

    # growth gates ------------------------------------------------------------
    gate = _growth_gate_from_overlap_core_activity(P, agents, H, W, eps, grow_min_kids).astype(np.float32)

    # sanitize candidate
    cand = np.asarray(cand, np.float32)
    cand = np.nan_to_num(cand, nan=0.0, posinf=1.0, neginf=0.0)
    cand = np.clip(cand, 0.0, 1.0)

    

    # ----------------- bands + HARD locality -----------------
    grow_band = max(1, int(getattr(config, "grow_band", 1)))
    pm        = P.mask.astype(np.float32)
    mask_bin  = (pm > support_tau)
    dil       = dilate_boolfn(mask_bin, r=grow_band, periodic=periodic)
    outer     = (dil & (~mask_bin))

    # gated candidate with ring boost
    growth_prob = np.clip(gate, 0.0, 1.0)
    eta_ring    = float(getattr(config, "eta_grow", 0.5))
    ring_target = np.clip(pm + eta_ring * growth_prob, 0.0, 1.0)
    cand        = np.where(outer, np.maximum(cand, ring_target), cand)
    cand        = (cand * growth_prob).astype(np.float32)

    # ---- CHILD-SUPPORT CLAMP (tight union of assigned kids) ----
    child_tau    = float(getattr(config, "child_support_tau", 0.05))
    child_dilate = int(getattr(config, "child_support_dilate_px", 2))
    child_support = np.zeros((H, W), dtype=bool)
    for ki in (getattr(P, "child_ids", []) or []):
        try:
            km = np.asarray(agents[ki].mask, np.float32) > child_tau
        except Exception:
            continue
        if child_dilate > 0:
            km = dilate_boolfn(km, r=child_dilate, periodic=periodic)
        child_support |= km
    # If no kids assigned, child_support stays False (no extra area opened)

    # ---- FINAL locality: dilate( support_now ∪ (cand>support_tau) ∪ child_support )
    include_cand = bool(getattr(config, "parent_local_include_candidate", True))
    if include_cand:
        cand_bin = (cand > support_tau)
        local_seed = mask_bin | cand_bin | child_support
    else:
        local_seed = mask_bin | child_support
    local = dilate_boolfn(local_seed, r=max(local_r_px, grow_band), periodic=periodic)

    # (optional) debug locality size
    if bool(getattr(config, "debug_parent_locality", False)):
        print(f"[P{getattr(P,'id','?')}] local={int(local.sum())} support={int(mask_bin.sum())} child={int(child_support.sum())}")

    # --------------- compose target (no move outside local) ------------------
    # Only allow movement INSIDE local; outside local we freeze at pm
    target = pm + (cand - pm)
    target = np.where(local, target, pm)

    # --------------- reseed vs EMA toward target ----------------------------
    if _should_reseed(P, target):
        new_mask = np.clip(target, 0.0, 1.0).astype(np.float32)
    else:
        delta = alpha * (target - pm)
        if delta_cap > 0:
            delta = np.clip(delta, -delta_cap, delta_cap)

        # ABSOLUTE RULE: forbid positive growth outside local
        pos_outside = (~local) & (delta > 0)
        if np.any(pos_outside):
            delta[pos_outside] = 0.0

        new_mask = np.clip(pm + delta, 0.0, 1.0).astype(np.float32)

    # --------------- monotonic no-growth outside local -----------------------
    # Even after numerical noise: clamp outside local to <= old value
    new_mask = np.where(~local, np.minimum(new_mask, pm), new_mask)

    # --------------- far-field decay + dust floor ----------------------------
    if far_decay < 1.0:
        far = ~local
        if np.any(far):
            new_mask[far] *= far_decay
    floor_eps = float(getattr(config, "parent_floor_eps", 1e-4))
    if floor_eps > 0.0:
        new_mask[new_mask < floor_eps] = 0.0

    P.mask = new_mask.astype(dtype)


def spawn_or_update_parents(active_regions, agents, parents_by_id, next_parent_id, *, field_generators):
    """
    ADDITIVE spawn/update:
      - never removes entries from parents_by_id
      - creates/updates only, then merges back
      - ensures newborns have base/bundle morphisms
    Returns (list(parents_by_id.values()), next_parent_id).
    """
    import numpy as np
    Gq, Gp = field_generators

    if not agents:
        return list(parents_by_id.values()), next_parent_id

    H, W   = np.asarray(agents[0].mask).shape[:2]
    dtype  = agents[0].mu_q_field.dtype
    Kq     = int(agents[0].mu_q_field.shape[-1])
    Kp     = int(agents[0].mu_p_field.shape[-1])
    eps    = float(getattr(config, "support_cutoff_eps", 1e-6))

    # --- snapshot current store; work on a local copy so helpers can't nuke it
    snapshot = dict(parents_by_id)   # pid -> Parent (shallow is fine)
    work     = dict(parents_by_id)   # what we let helpers mutate

    # 1) ensure parents exist for active regions (MUST NOT CLEAR the store)
    rid_to_pid, next_parent_id = _ensure_parents_for_regions(
        active_regions, work, next_parent_id, H, W, dtype, Kq, Kp
    )

    # Defensive: if helper cleared non-active parents, restore them.
    for pid, P in snapshot.items():
        if pid not in work:
            work[pid] = P

    # 2) assign children using the stable mapping
    _assign_children_to_parents(
        active_regions, agents, work, eps=eps, use_activity=True, rid_to_pid=rid_to_pid
    )

    # 3) per-parent update (seed/candidate/EMA/emergence), but first make sure
    #    EVERY parent has valid morphisms exactly once at birth.
    parents_list = list(work.values())

    for P in parents_list:
        if not have_parent_morphisms(P):
            # sets Phi_0 / Phi_tilde_0, stores generators, computes bundle morphisms once
            init_parent_morphisms(P, generators_q=Gq, generators_p=Gp)

    # step id (best-effort if runtime_ctx is module-global)
    try:
        step_now = int(getattr(runtime_ctx, "global_step", 0))
    except NameError:
        step_now = 0

    for P in parents_list:
        _update_single_parent(P, agents, step_now, H, W, eps, dtype)

    # 4) refresh gauge fields; mark exp-caches dirty so a single pre-pass can rebuild
    _refresh_parent_gauge_fields(parents_list, agents, dtype)
    for P in parents_list:
        P._exp_phi = P._exp_neg_phi = None
        P._exp_phi_model = P._exp_neg_phi_model = None

    # 5) MERGE back into the REAL store (additive — no deletions)
    for pid, P in work.items():
        parents_by_id[int(pid)] = P

    return list(parents_by_id.values()), next_parent_id




def detector_tick(agents: List[Agent], det: DetectorState, *,
                  field: str, generators, cfg: dict) -> Dict[int, Region]:
    """
    One call per detector_period. Updates det.regions in-place and returns active regions.
    cfg keys: Ton, Toff, persistence_on, persistence_off, min_area, smooth_iters, tau_align
    """
    det.step += 1
    score = _alignment_score_from_pairs(agents, field=field, generators=generators, tau=cfg.get("tau_align", 0.30))
    _update_regions_hysteresis(
        det, score,
        Ton=cfg.get("Ton", 0.10),
        Toff=cfg.get("Toff", 0.20),
        persistence_on=cfg.get("persistence_on", 3),
        persistence_off=cfg.get("persistence_off", 3),
        min_area=int(cfg.get("min_area", 50)),
        smooth_iters=int(cfg.get("smooth_iters", 1)),
    )
    return {rid: R for rid, R in det.regions.items() if R.state == "active"}



def _compute_core_from_kids(P, agents, H, W, eps):
    
    cover = np.zeros((H, W), np.int32); weight = np.zeros((H, W), np.float32)
    kl_sum = np.zeros((H, W), np.float32); kl_cnt = np.zeros((H, W), np.int32)
    for i in getattr(P, "child_ids", []):
        ch = agents[i]; m = np.asarray(ch.mask)
        if m.shape != (H, W): m = resize_nn(m, (H, W))
        a = child_activity_map(ch, H, W, eps=eps)
        if a is None: continue
        inside = a & (m > eps)
        cover += inside.astype(np.int32); weight += m.astype(np.float32) * inside.astype(np.float32)
        k = getattr(ch, "cached_alignment_kl", None)
        if k is None: continue
        k = np.asarray(k); 
        if k.shape != (H, W): continue
        good = inside & np.isfinite(k)
        kl_sum[good] += k[good].astype(np.float32); kl_cnt[good] += 1
    keep = (cover >= int(getattr(config, "core_min_kids", 2))) & (weight >= float(getattr(config, "core_weight_tau", 0.6)))
    kl_mean = kl_sum / np.maximum(kl_cnt, 1); kl_mean[kl_cnt == 0] = np.inf
    keep &= (kl_mean <= float(getattr(config, "core_kl_tau", getattr(config, "tau_align_emergent", 0.30))))
    # tiny erosion
    e = keep.copy()
    e = (e & np.roll(e,1,0) & np.roll(e,-1,0) & np.roll(e,1,1) & np.roll(e,-1,1))
    return e
