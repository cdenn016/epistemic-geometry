from __future__ import annotations

"""
Created on Tue Aug 12 20:15:47 2025

@author: chris and christine
"""
import time

from threadpoolctl import threadpool_limits

import numpy as np
from core.numerical_utils import safe_omega_inv, sanitize_sigma
from core.omega import (retract_phi_principal, exp_lie_algebra_irrep, 
                        d_exp_exact, inverse_fisher_metric_field )

from updates.update_terms_phi import ( 
    accumulate_phi_morphism_self_feedback, accumulate_phi_alignment_gradient,
    grad_feedback_phi_direct, grad_feedback_phi_tilde_direct, grad_self_phi_direct,
    grad_self_phi_tilde_direct )

from updates.update_terms_mu_sigma import accumulate_mu_sigma_gradient
from updates.update_helpers import dirty_manager
from joblib import Parallel, delayed
from runtime_context import cfg_get
from utils import get_neighbors, zero_all_gradients, _aid
from core.transport_cache import E_grid, ensure_global_A
from updates.update_terms_curvature_A import covariant_frame_energy_and_grads



# unified metadata for phi vs phi_tilde blocks
_FIELD_META = {
    "phi": {
        "which": "q",
        "beta_key": "beta",
        "mu_key": "mu_q_field",
        "sigma_key": "sigma_q_field",
        "fisher_inv_key": "inverse_fisher_phi",
        "grad_key": "grad_phi",
        "phi_attr": "phi",
        "qall_func": d_exp_exact,
    },
    "phi_model": {
        "which": "p",
        "beta_key": "beta_model",
        "mu_key": "mu_p_field",
        "sigma_key": "sigma_p_field",
        "fisher_inv_key": "inverse_fisher_phi_model",
        "grad_key": "grad_phi_tilde",
        "phi_attr": "phi_model",
        "qall_func": d_exp_exact,
    },
}



def _alignment_block(agent_i, neighbors, generators,  *, field: str, ctx):
    """
    Compute same-level alignment gradients for 'phi' or 'phi_model'.
    """
    if not neighbors:
        return 0.0

    meta = _FIELD_META[field]
    t0 = time.perf_counter()

    # Q_all for agent_i once
    phi_i = getattr(agent_i, meta["phi_attr"])
    Q_all_i = meta["qall_func"](phi_i, generators)

    # loop neighbors
    for agent_j in neighbors:

        # Build exp(-φ_j) from central cache if available, else local
        if ctx is not None:
            Ej = E_grid(ctx, agent_j, which=meta["which"])
            exp_neg_phi_j = safe_omega_inv(Ej)
        else:
            phi_j = getattr(agent_j, meta["phi_attr"])
            Ej = exp_lie_algebra_irrep(phi_j, generators)
            exp_neg_phi_j = safe_omega_inv(Ej)

        # accumulate alignment grad
        accumulate_phi_alignment_gradient(ctx,
            agent_i, agent_j, generators,
            field=field,
            beta_key=meta["beta_key"],
            omega_cache_key=None,                   # ctx handles caching centrally
            mu_key=meta["mu_key"],
            sigma_key=meta["sigma_key"],
            fisher_inv_key=meta["fisher_inv_key"],
            grad_key=meta["grad_key"],
            Q_all_i=Q_all_i,
            exp_neg_phi_j=exp_neg_phi_j,
            agents=None,                            # pass if your impl needs it; else None is fine
        )
        
    return time.perf_counter() - t0




def _morphism_block(agent_i, generators_q, generators_p, *, field: str, ctx):
    meta = _FIELD_META[field]
    t0 = time.perf_counter()

    if field == "phi":
        accumulate_phi_morphism_self_feedback(
            ctx, agent_i, generators_q, generators_p,  # q, p (fixed)
            field="phi",
            fisher_inv_key=meta["fisher_inv_key"],
            grad_key=meta["grad_key"],
            phi_self_func=grad_self_phi_direct,
            phi_feedback_func=grad_feedback_phi_direct,
        )
    else:
        accumulate_phi_morphism_self_feedback(
            ctx, agent_i, generators_q, generators_p,  # q, p (fixed)
            field="phi_model",
            fisher_inv_key=meta["fisher_inv_key"],
            grad_key=meta["grad_key"],
            phi_self_func=grad_self_phi_tilde_direct,
            phi_feedback_func=grad_feedback_phi_tilde_direct,
        )

    return time.perf_counter() - t0



# -----------------------------------
# Disentangled gradient orchestrator
# -----------------------------------


def compute_all_gradients(agent_i, agents, all_agents, generators_q, generators_p, runtime_ctx=None):
    """
    Single-scale gradient orchestrator (no parents / no cross-scale).

      Phase 0: thread runtime ctx
      Phase 1: μ, Σ (belief/model) — same-level only
      Phase 2: (optional) warm local caches for agent_i + neighbors
      Phase 3: φ alignment (belief + model), same-level only
      Phase 4: morphism self + feedback (φ, φ̃), same-level
      Phase 5: return gradients (+ per-agent θ grads; DO NOT APPLY HERE)
    """
    ctx = runtime_ctx

    # reset grads, timers
    zero_all_gradients(agent_i)
    timings = {}

    # -------- Phase 1 — μ, Σ (same-level only) --------
    t0 = time.perf_counter()
    accumulate_mu_sigma_gradient(ctx, agent_i, agents, mode="belief")
    timings["mu_sigma_belief"] = time.perf_counter() - t0

    t0 = time.perf_counter()
    accumulate_mu_sigma_gradient(ctx, agent_i, agents, mode="model")
    timings["mu_sigma_model"] = time.perf_counter() - t0

    # -------- Phase 2a — neighbors --------
    t0 = time.perf_counter()
    neighbors = get_neighbors(agent_i, agents)
    timings["neighbors"] = time.perf_counter() - t0
    timings["neighbors_count"] = len(neighbors) if neighbors else 0  # handy context

    # -------- Phase 2b — Fisher preconditioners (q/p) --------
    eps_val = float(cfg_get(ctx, "eps", 1e-8))

    t0 = time.perf_counter()
    agent_i.inverse_fisher_phi = inverse_fisher_metric_field(
        ctx, agent_i, generators_q, which="q", eps=eps_val
    )
    timings["fisher_q"] = time.perf_counter() - t0

    t0 = time.perf_counter()
    agent_i.inverse_fisher_phi_model = inverse_fisher_metric_field(
        ctx, agent_i, generators_p, which="p", eps=eps_val
    )
    timings["fisher_p"] = time.perf_counter() - t0

    # -------- Phase 3 — φ alignment (same-level only) --------
    if neighbors:
        dt = _alignment_block(agent_i, neighbors, generators_q, field="phi", ctx=ctx)
        timings["phi_alignment"] = dt

        dt = _alignment_block(agent_i, neighbors, generators_p, field="phi_model", ctx=ctx)
        timings["phi_tilde_alignment"] = dt

    # -------- Phase 4 — morphism self + feedback (same-level) --------
    dt = _morphism_block(agent_i, generators_q, generators_p, field="phi", ctx=ctx)
    timings["phi_morphism"] = dt

    dt = _morphism_block(agent_i, generators_q, generators_p, field="phi_model", ctx=ctx)
    timings["phi_tilde_morphism"] = dt
      
    dtheta_i = None

    if bool(cfg_get(ctx, "debug_grad_timing", False)):
        aid = _aid(agent_i)
        print(f"\n[GRAD TIMINGS] Agent {aid}")
        # pretty print in a stable order
        for k in ("neighbors","neighbors_count",
                  "mu_sigma_belief","mu_sigma_model",
                  "fisher_q","fisher_p",
                  "phi_alignment","phi_tilde_alignment",
                  "phi_morphism","phi_tilde_morphism"):
            if k in timings:
                v = timings[k]
                if k.endswith("_count"):
                    print(f"  {k:22s} : {int(v)}")
                else:
                    print(f"  {k:22s} : {v*1e3:7.2f} ms")

    return (
        (agent_i.grad_mu_q, agent_i.grad_sigma_q),
        (agent_i.grad_mu_p, agent_i.grad_sigma_p),
        agent_i.grad_phi,
        agent_i.grad_phi_tilde,
        dtheta_i,
    )

def apply_phi_updates(agent, grad_phi, grad_phi_m, mask, *, ctx=None):
    """
    Constant-step φ / φ̃ update (N-D, hypercubic PBC-ready).

    Inputs
      agent.phi        : (*S, 3)
      agent.phi_model  : (*S, 3) or None
      grad_phi         : (*S, 3)
      grad_phi_m       : (*S, 3)  (ignored if agent.phi_model is None)
      mask             : broadcastable to (*S,) (bool or float in [0,1])
    """
    import numpy as np

    # ---- cfg ----
    eta_phi   = float(cfg_get(ctx, "tau_phi", 1e-2))
    eta_phi_m = float(cfg_get(ctx, "tau_phi_model", 1e-2))
    debug     = bool(cfg_get(ctx, "DEBUG_APPLY", False))

    # ---- fields & shapes ----
    phi   = np.asarray(getattr(agent, "phi"), np.float32)          # (*S, 3)
    phi_m = getattr(agent, "phi_model", None)
    if phi_m is not None:
        phi_m = np.asarray(phi_m, np.float32)                      # (*S, 3) or None

    if phi.ndim < 1 or phi.shape[-1] != 3:
        raise ValueError(f"agent.phi must be (*S,3), got {phi.shape}")
    S = phi.shape[:-1]

    gphi  = np.asarray(grad_phi,   np.float32)
    gphim = np.asarray(grad_phi_m, np.float32) if phi_m is not None else None
    if gphi.shape != phi.shape:
        raise ValueError(f"grad_phi shape {gphi.shape} != phi shape {phi.shape}")
    if phi_m is not None and gphim.shape != phi_m.shape:
        raise ValueError(f"grad_phi_m shape {gphim.shape} != phi_model shape {phi_m.shape}")

    # ---- mask: broadcast to (*S,) then expand to (*S,1) ----
    if mask is None:
        mexp = 1.0
    else:
        m = np.asarray(mask, np.float32)
        if m.shape != S:
            # prepend singletons if needed, then broadcast
            pad = (1,) * max(0, len(S) - m.ndim)
            try:
                m = np.broadcast_to(m.reshape(pad + m.shape), S)
            except Exception as e:
                raise ValueError(f"mask shape {m.shape} not broadcastable to {S}") from e
        mexp = m[..., None]  # (*S,1)

    # ---- persist grads on agent (for diagnostics) ----
    agent.grad_phi = np.array(gphi, copy=True)
    if phi_m is not None:
        agent.grad_phi_tilde = np.array(gphim, copy=True)
    else:
        agent.grad_phi_tilde = None

    # ---- updates (mask-aware) ----
    delta_phi = (eta_phi * gphi).astype(np.float32, copy=False) * mexp
    phi_new   = phi - delta_phi

    if phi_m is not None:
        delta_phi_m = (eta_phi_m * gphim).astype(np.float32, copy=False) * mexp
        phim_new    = phi_m - delta_phi_m
    else:
        phim_new = None

    # ---- retract to principal SO(3) chart ----
    agent.phi = retract_phi_principal(phi_new, margin=1e-6)
    if phim_new is not None:
        agent.phi_model = retract_phi_principal(phim_new, margin=1e-6)

    # ---- diagnostics ----
    if debug:
        mean_gphi  = float(np.nanmean(np.linalg.norm(gphi,  axis=-1)))
        mean_gphim = float(np.nanmean(np.linalg.norm(gphim, axis=-1))) if gphim is not None else float("nan")
        print(
            f"[APPLY φ-step] id={getattr(agent, 'id', None)} "
            f"τφ={eta_phi:g}, τφ̃={eta_phi_m:g}, "
            f"|gφ|_mean={mean_gphi:.3e}, |gφ̃|_mean={mean_gphim:.3e}",
            flush=True,
        )

    # ---- mark dirty for transport / KL refresh ----
    if ctx is not None:
        dirty_manager(ctx).mark(agent, kl=True)



def _apply_sigma_masked(ctx, old_S, dS, tau, mask_bool):
    """
    SPD-safe masked Sigma update with exactly two retractions:
      mode="linear"  -> affine-linear step in the whitened tangent
      mode="exp"     -> affine-invariant exponential map (default)

    Trust region is applied in the affine-whitened tangent:
      R = Σ^{-1/2} (τ sym(dS)) Σ^{-1/2},  ||R||_F ≤ rho

    Config keys (others are ignored):
      support_tau               : float  (SPD floor for eigenvalues; default 1e-8)
      sigma_rel_step_max        : float  (rho; Frobenius trust on R; default 0.25)
      sigma_retraction_mode     : str    ("exp" [default] or "linear")
      sigma_update_gmax         : float  (per-eigen multiplier cap for EXP; 1.0→off)
      sigma_assert_order1_match : bool   (print whitened ||R|| diagnostics; default False)
    """
    import numpy as np
    from runtime_context import cfg_get
    from core.numerical_utils import sanitize_sigma

    # ---------- inputs & checks ----------
    S  = np.asarray(old_S, dtype=np.float32)
    D  = np.asarray(dS,    dtype=np.float32)
    mb = np.asarray(mask_bool)

    if S.shape != D.shape:
        raise ValueError(f"_apply_sigma_masked: shape mismatch {S.shape} vs {D.shape}")
    if S.ndim < 2 or S.shape[-1] != S.shape[-2]:
        raise ValueError(f"_apply_sigma_masked: covariance must be square; got {S.shape[-2:]}")
    Sshape, K = S.shape[:-2], int(S.shape[-1])
    if tuple(mb.shape) != Sshape:
        raise ValueError(f"_apply_sigma_masked: mask shape {mb.shape} != spatial shape {Sshape}")
    if not (np.isfinite(S).all() and np.isfinite(D).all()):
        raise FloatingPointError("_apply_sigma_masked: non-finite inputs")

    mb = (mb > 0)
    if not np.any(mb):
        return S

    tau     = float(tau)
    eps_spd = float(cfg_get(ctx, "support_tau", 1e-8))
    rho     = float(cfg_get(ctx, "sigma_rel_step_max", 0.25))
    mode    = str(cfg_get(ctx, "sigma_retraction_mode", "exp")).lower()
    gmax    = float(cfg_get(ctx, "sigma_update_gmax", 1.0))
    logcap  = float(np.log(max(gmax, 1.0)))

    # ---------- flatten active ----------
    N   = int(np.prod(Sshape)) if Sshape else 1
    idx = np.flatnonzero(mb.reshape(N))

    Sflat, Dflat = S.reshape(N, K, K), D.reshape(N, K, K)
    S_act = Sflat[idx].astype(np.float64, copy=False)  # (M,K,K)  f64 for eig
    D_act = Dflat[idx].astype(np.float64, copy=False)

    # Δ = τ * sym(dS)
    Delta = tau * 0.5 * (D_act + np.swapaxes(D_act, -1, -2))

    # eig(Σ) = Q diag(w) Q^T  with SPD clip
    try:
        w, Q = np.linalg.eigh(S_act)
    except np.linalg.LinAlgError as e:
        raise np.linalg.LinAlgError(f"_apply_sigma_masked: eigh failed: {e}") from e
    w = np.clip(w, eps_spd, None)
    if not (np.isfinite(w).all() and np.isfinite(Q).all()):
        raise FloatingPointError("_apply_sigma_masked: non-finite eigendecomp")

    Qt       = np.swapaxes(Q, -1, -2)
    sqrt_w   = np.sqrt(w)
    inv_sqrt = 1.0 / sqrt_w

    # handy diag to print whitened ||R|| (works for both modes)
    def _affine_whiten_norm(S, Delta):
        Deig = np.einsum("...ik,...kl,...jl->...ij", Qt, Delta, Q, optimize=True)
        R = (inv_sqrt[..., :, None] * Deig) * inv_sqrt[..., None, :]
        return np.linalg.norm(R, axis=(-2, -1))  # (M,)

    # common: build whitened symmetric R and trust-region it
    Deig = np.einsum("...ik,...kl,...jl->...ij", Qt, Delta, Q, optimize=True)
    R = (inv_sqrt[..., :, None] * Deig) * inv_sqrt[..., None, :]
    R = 0.5 * (R + np.swapaxes(R, -1, -2))
    Rnorm = np.linalg.norm(R, axis=(-2, -1), keepdims=True)
    #print(f"Rnowm = {Rnorm}\n")
    
    
    # After computing R and before the back-map
    
    lam = np.linalg.eigvalsh(0.5*(R+R.swapaxes(-1,-2)))  # safe on sym R
    clip_factor = np.minimum(1.0, rho / np.maximum(Rnorm, eps_spd))  # per-site
    
    # Useful telemetry
#    pct = np.percentile(Rnorm, [50, 90, 99, 99.9])
 #   clipped_frac = float(np.mean(clip_factor < 0.999))
 #   max_lam = float(np.max(lam))
#    print(f"[Σ R] ||R||_F med/90/99/99.9 = {pct[0]:.2e}/{pct[1]:.2e}/{pct[2]:.2e}/{pct[3]:.2e} | "
 #         f"clipped_frac={clipped_frac:.3f} | max λ(R)={max_lam:.2e}")

    R *= np.minimum(1.0, rho / np.maximum(Rnorm, eps_spd))
    
    if mode == "linear":
        # linear back-map: Σ^{1/2} R Σ^{1/2}
        if bool(cfg_get(ctx, "sigma_assert_order1_match", False)):
            diag = _affine_whiten_norm(S_act, Delta)
            print(f"[Σ tangent/linear] max||R|| = {float(np.max(diag)):.3e}", flush=True)
        Deig_scaled = (sqrt_w[..., :, None] * R) * sqrt_w[..., None, :]
        Delta_scaled = np.einsum("...ik,...kl,...jl->...ij", Q, Deig_scaled, Qt,
                                 optimize=True).astype(np.float32, copy=False)

    else:  # "exp" (default)
        lam, U = np.linalg.eigh(R)
        if gmax > 1.0:
            lam = np.clip(lam, -logcap, logcap)  # cap per-eigen multiplier exp(lam)
        exp_lam = np.exp(lam)
        expR = (U * exp_lam[..., None, :]) @ np.swapaxes(U, -1, -2)
        # Δ_scaled = Σ^{1/2} (expR - I) Σ^{1/2}
        eye = np.eye(K, dtype=np.float64)[None, ...]
        Teig_scaled = (sqrt_w[..., :, None] * (expR - eye)) * sqrt_w[..., None, :]
        Delta_scaled = np.einsum("...ik,...kl,...jl->...ij", Q, Teig_scaled, Qt,
                                 optimize=True).astype(np.float32, copy=False)

    # finalize: sanitize and scatter back
    S_new_act = sanitize_sigma(S_act.astype(np.float32, copy=False) + Delta_scaled, eps=eps_spd)
    out = S.copy()
    out.reshape(N, K, K)[idx] = S_new_act
    return out






def OLD_LINEAR_apply_sigma_masked(ctx, old_S, dS, tau, mask_bool):
    """
    SPD-safe masked Sigma update over arbitrary spatial shape S:

        S_new = sanitize( S + Δ_scaled )   on mask
        with relative trust region: ||R||_F <= rho,
        where R = Σ^{-1/2} Δ Σ^{-1/2} and Δ = tau * sym(dS).

    Shapes:
      old_S, dS : (*S, K, K)
      mask_bool : (*S,) bool/float
    """
    import numpy as np

    # ----- fast path / basic checks -----
    old_S = np.asarray(old_S, dtype=np.float32)
    dS    = np.asarray(dS,    dtype=np.float32)
    mb    = np.asarray(mask_bool)

    if old_S.shape != dS.shape:
        raise ValueError(f"_apply_sigma_masked: shape mismatch old_S {old_S.shape} vs dS {dS.shape}")
    if old_S.ndim < 2 or old_S.shape[-1] != old_S.shape[-2]:
        raise ValueError(f"_apply_sigma_masked: covariance must be square; got {old_S.shape[-2:]}")
    
    Sshape, K = old_S.shape[:-2], int(old_S.shape[-1])

    if mb.shape != Sshape:
        raise ValueError(f"_apply_sigma_masked: mask shape {mb.shape} != spatial shape {Sshape}")

    if not (np.isfinite(old_S).all() and np.isfinite(dS).all()):
        raise FloatingPointError("_apply_sigma_masked: non-finite entries in old_S or dS")

    mb = (mb > 0)  # boolean
    if not np.any(mb):
        print("nothing!!! [apply sigma masked]\n\n")
        return old_S  # nothing to do

    # ----- params -----
    step_tau = float(tau)                                  # scales Δ
    eps_spd  = float(cfg_get(ctx, "support_tau", 1e-8))    # SPD floor (eigen clip)
    rho      = float(cfg_get(ctx, "sigma_rel_step_max", 0.25))

    # ----- index active locations -----
    N   = int(np.prod(Sshape)) if Sshape else 1
    idx = np.flatnonzero(mb.reshape(N))
    # Flatten for batched linear algebra
    Sflat  = old_S.reshape(N, K, K)
    dSflat = dS.reshape(N, K, K)

    # Work only on active subset (float64 just for eig numerics; keep rest float32)
    S_act  = Sflat[idx].astype(np.float64, copy=False)  # (M,K,K)
    dS_act = dSflat[idx].astype(np.float64, copy=False) # (M,K,K)

    # symmetrize once and scale
    dS_act = 0.5 * (dS_act + np.swapaxes(dS_act, -1, -2))
    Δ      = step_tau * dS_act

    # ----- eigendecomp Σ = Q diag(w) Q^T with clipping -----
    try:
        w, Q = np.linalg.eigh(S_act)  # (M,K), (M,K,K)
    except np.linalg.LinAlgError as e:
        raise np.linalg.LinAlgError(f"_apply_sigma_masked: eigh failed: {e}") from e
    w = np.clip(w, eps_spd, None)
    if not (np.isfinite(w).all() and np.isfinite(Q).all()):
        raise FloatingPointError("_apply_sigma_masked: non-finite eigendecomp")

    # ----- R = Σ^{-1/2} Δ Σ^{-1/2} in eigen basis -----
    # Δ_eig = Q^T Δ Q
    Qt   = np.swapaxes(Q, -1, -2)
    Δeig = np.einsum("...ik,...kl,...jl->...ij", Qt, Δ, Q, optimize=True)  # (M,K,K)

    inv_sqrt_w = 1.0 / np.sqrt(w)                     # (M,K)
    R = (inv_sqrt_w[..., :, None] * Δeig) * inv_sqrt_w[..., None, :]  # (M,K,K)

    # ----- trust region: ||R||_F <= rho -----
    Rnorm = np.linalg.norm(R, axis=(-2, -1), keepdims=True)  # (M,1,1)
    scale = np.minimum(1.0, rho / np.maximum(Rnorm, eps_spd))
    R    *= scale

    # ----- back-transform: Δ_scaled = Σ^{1/2} R Σ^{1/2} -----
    sqrt_w = np.sqrt(w)
    Δeig_scaled = (sqrt_w[..., :, None] * R) * sqrt_w[..., None, :]
    Δ_scaled = np.einsum("...ik,...kl,...jl->...ij", Q, Δeig_scaled, Qt, optimize=True).astype(np.float32, copy=False)

    # ----- write back only active pixels, sanitize SPD, and merge -----
    S_new_act = sanitize_sigma((S_act.astype(np.float32, copy=False) + Δ_scaled), eps=eps_spd)
    if not np.isfinite(S_new_act).all():
        raise FloatingPointError("_apply_sigma_masked: non-finite S_new after sanitize")

    out = old_S.copy()
    out.reshape(N, K, K)[idx] = S_new_act
    # (outside mask remains unchanged by construction)
    return out

















def _apply_children(agents, grads, n_jobs, *, ctx=None):
    """
    Apply per-agent updates for μ/Σ (belief+model) and φ/φ̃ over arbitrary S.
    Frozen levels removed; updates applied wherever mask > 0.
    Hard-fails on shape/finiteness mismatches.
    """
   

    tau_mu_belief    = float(cfg_get(ctx, "tau_mu_belief",    1e-2))
    tau_sigma_belief = float(cfg_get(ctx, "tau_sigma_belief", 1e-2))
    tau_mu_model     = float(cfg_get(ctx, "tau_mu_model",     1e-2))
    tau_sigma_model  = float(cfg_get(ctx, "tau_sigma_model",  1e-2))
    DEBUG_APPLY      = bool(cfg_get(ctx, "DEBUG_APPLY", False))

    (q_updates, p_updates, phi_grads, phi_m_grads) = grads

    # Establish canonical S from first agent’s mask
    S0 = tuple(np.asarray(agents[0].mask).shape)

    def _one(i):
        A = agents[i]
        mask = np.asarray(A.mask, np.float32)
        if tuple(mask.shape) != S0:
            raise ValueError(f"[apply] agent {getattr(A,'id',i)} mask shape {mask.shape} != canonical {S0}")
        mask_mu = mask[..., None]  # broadcast over last feature dim
        
        dmu_q, dsg_q = q_updates[i]
        dmu_p, dsg_p = p_updates[i]

        mu_q_old = np.asarray(A.mu_q_field, np.float32)
        mu_p_old = np.asarray(A.mu_p_field, np.float32)
        sig_q_old = np.asarray(A.sigma_q_field, np.float32)
        sig_p_old = np.asarray(A.sigma_p_field, np.float32)
 
        # Finite checks
        for name, arr in (("mu_q", mu_q_old), ("mu_p", mu_p_old), ("sig_q", sig_q_old), ("sig_p", sig_p_old)):
            if not np.isfinite(arr).all():
                raise FloatingPointError(f"[apply] non-finite in {name} for agent {getattr(A,'id',i)}")

        # Shape checks vs S0
        if mu_q_old.shape[:-1] != S0: raise ValueError(f"[apply] mu_q_field shape {mu_q_old.shape} incompatible with {S0}")
        if mu_p_old.shape[:-1] != S0: raise ValueError(f"[apply] mu_p_field shape {mu_p_old.shape} incompatible with {S0}")
        if sig_q_old.shape[:-2] != S0: raise ValueError(f"[apply] sigma_q_field shape {sig_q_old.shape} incompatible with {S0}")
        if sig_p_old.shape[:-2] != S0: raise ValueError(f"[apply] sigma_p_field shape {sig_p_old.shape} incompatible with {S0}")

        # ---- μ updates (masked) ----
        A.mu_q_field = (mu_q_old + tau_mu_belief * np.asarray(dmu_q, np.float32) * mask_mu).astype(np.float32, copy=False)
        A.mu_p_field = (mu_p_old + tau_mu_model  * np.asarray(dmu_p, np.float32) * mask_mu).astype(np.float32, copy=False)

        # ---- Σ updates (masked, SPD-safe) ----
        A.sigma_q_field = _apply_sigma_masked(ctx, sig_q_old, np.asarray(dsg_q, np.float32), tau_sigma_belief, mask > 0.0)
        A.sigma_p_field = _apply_sigma_masked(ctx, sig_p_old, np.asarray(dsg_p, np.float32), tau_sigma_model,  mask > 0.0)

                # after A.sigma_q_field / A.sigma_p_field assignments
        A._sigma_q_for_fisher = np.asarray(A.sigma_q_field, np.float32).copy()
        A._sigma_p_for_fisher = np.asarray(A.sigma_p_field, np.float32).copy()
    
        if DEBUG_APPLY:
            dmuq_mean  = float(np.mean(np.abs(A.mu_q_field - mu_q_old)))
            dmup_mean  = float(np.mean(np.abs(A.mu_p_field - mu_p_old)))
            dsigq_mean = float(np.mean(np.abs(A.sigma_q_field - sig_q_old)))
            dsigp_mean = float(np.mean(np.abs(A.sigma_p_field - sig_p_old)))
            print(
                f"[APPLY] id={getattr(A,'id',i)} "
                f"|Δμ_q|={dmuq_mean:.3e} |Δμ_p|={dmup_mean:.3e} "
                f"|ΔΣ_q|={dsigq_mean:.3e} |ΔΣ_p|={dsigp_mean:.3e} "
                f"(τμ_q={tau_mu_belief:g}, τμ_p={tau_mu_model:g}, "
                f"τσ_q={tau_sigma_belief:g}, τσ_p={tau_sigma_model:g})",
                flush=True,
            )

        # ---- φ updates (masked internally) ----
        gp  = phi_grads[i];   gp  = np.zeros_like(A.phi,       dtype=np.float32) if gp  is None else gp
        gpm = phi_m_grads[i]; gpm = np.zeros_like(A.phi_model, dtype=np.float32) if gpm is None else gpm
        apply_phi_updates(A, gp, gpm, mask, ctx=ctx)

        # Mark morphisms dirty only (μ/Σ changes already imply transport recompute elsewhere)
        dirty_manager(ctx).mark_morphism_only(A)

    Parallel(n_jobs=int(n_jobs) if n_jobs is not None else 1, backend="threading", batch_size="auto")(
        delayed(_one)(i) for i in range(len(agents))
    )





def _compute_child_grads(ctx, agents, all_agents, Gq, Gp):
    """
    Batch-compute child gradients.
    Returns 5 lists:
      - belief μ/Σ updates
      - model  μ/Σ updates
      - φ grads
      - φ̃ grads
      - per-agent θ grads (or None entries)
    """
    if not agents:
        return ([], [], [], [], [])

    n_jobs = max(1, min(int(cfg_get(ctx, "n_jobs", 1)), len(agents)))

    # Config knobs (no parallel_config; pass to Parallel directly)
    prefer      = str(cfg_get(ctx, "joblib_prefer", "threads"))   # "processes" or "threads"
    max_nbytes  = cfg_get(ctx, "joblib_memmap_threshold", "10M")  # only used by loky
    blas_threads = int(cfg_get(ctx, "blas_threads_per_worker",
                               2 if prefer == "threads" else 1))

    with threadpool_limits(blas_threads):
        results = Parallel(
            n_jobs=n_jobs,
            prefer=prefer,          # choose backend via preference
            max_nbytes=max_nbytes,  # memmap threshold for process backend
            batch_size="auto",
        )(
            delayed(compute_all_gradients)(Ai, agents, all_agents, Gq, Gp, runtime_ctx=ctx)
            for Ai in agents
        )

    # unzip -> 5 lists
    q_updates, p_updates, phi_grads, phi_m_grads, dtheta_parts = zip(*results)
    q_updates    = list(q_updates)
    p_updates    = list(p_updates)
    phi_grads    = list(phi_grads)
    phi_m_grads  = list(phi_m_grads)
    dtheta_parts = list(dtheta_parts)

    # optional coupling
    phi_grads = apply_A_phi_covariant_coupling(ctx, agents, phi_grads)

    return (q_updates, p_updates, phi_grads, phi_m_grads, dtheta_parts)



def apply_A_phi_covariant_coupling(ctx, agents, phi_grads):
    """
    A–φ covariant coupling (N-D):
      - Adds covariant frame grad to each child's φ-grad
      - Accumulates a single global A grad for the step
      - Records total A_cov energy

    Side effects (per step):
      ctx.fields["A_grad_accum"] : np.ndarray or None
      ctx.fields["A_cov_energy"] : float

    Returns:
      updated_phi_grads (list, same length as agents)
    """
    import numpy as np

    if ctx is None:
        return phi_grads

    use_A   = bool(cfg_get(ctx, "use_global_A", False))
    lam_cov = float(cfg_get(ctx, "lambda_A_cov", 0.0))
    if not (use_A and lam_cov > 0.0):
        if getattr(ctx, "fields", None) is not None:
            ctx.fields["A_grad_accum"] = None
            ctx.fields["A_cov_energy"] = 0.0
        return phi_grads

    cov_fn = covariant_frame_energy_and_grads
    if cov_fn is None:
        if getattr(ctx, "fields", None) is not None:
            ctx.fields["A_grad_accum"] = None
            ctx.fields["A_cov_energy"] = 0.0
        return phi_grads

    # ---- get A from ctx (run_simulation ensures this once at init) ----
    A = getattr(ctx, "fields", {}).get("A", None)
    if A is None:
        raise RuntimeError("Global A missing; ensure_global_A(...) must be called before coupling.")
    # A shape: (*S, ndim, 3)
        # step-local accumulator and energy
    A_grad_accum = np.zeros_like(A, dtype=np.float32)
    E_cov_total  = 0.0

    out_phi_grads = list(phi_grads)

    for i, a in enumerate(agents):
        phi_i = getattr(a, "phi", None)
       
        mask_i = getattr(a, "mask", None)

        # compute energy and grads
        E_cov, g_phi_cov, gA_cov = cov_fn(
            phi=phi_i,     # (*S, 3)
            A=A,           # (*S, ndim, 3)
            weight=lam_cov,
            mask=mask_i,   # (*S,) or None
        )

        # accumulate onto child's φ grad
        gi = out_phi_grads[i]
        out_phi_grads[i] = (np.asarray(gi, np.float32) if gi is not None else 0.0) + g_phi_cov

        # accumulate global A grad
        A_grad_accum += np.asarray(gA_cov, np.float32)
        E_cov_total  += float(E_cov)

    if not hasattr(ctx, "fields") or ctx.fields is None:
        ctx.fields = {}
    ctx.fields["A_grad_accum"] = A_grad_accum if np.any(np.isfinite(A_grad_accum)) else None
    ctx.fields["A_cov_energy"] = float(E_cov_total)

    return out_phi_grads



