# -*- coding: utf-8 -*-
"""
Created on Mon Sep  8 17:40:08 2025

@author: chris and christine
"""

# updates/update_terms_vfe.py
from __future__ import annotations
import numpy as np

from core.numerical_utils import sanitize_sigma  # you already use this elsewhere




def _theta_stats_from_children(ctx):
    """
    Aggregate sufficient stats over current children for preconditioning:
      Sxx = sum m * (Σ_q + μ μ^T)
      Sx  = sum m * μ
      N   = sum m   (per-pixel counts)
    Returns (Sxx, Sx, N, K_latent).
    """
   
    agents = getattr(ctx, "children_latest", None) or []
    
    if not agents:
        print("[THETA STATS] RETURN NONE \n\n\n\n")
        return None, None, 0.0, None

    A0 = agents[0]
    K = int(A0.mu_q_field.shape[-1])
    Sxx = np.zeros((K, K), np.float32)
    Sx  = np.zeros((K,),   np.float32)
    N   = 0.0

    for a in agents:
        m   = np.asarray(a.mask, np.float32)               # (H,W)
        mu  = np.asarray(a.mu_q_field, np.float32)         # (H,W,K)
        Sig = np.asarray(a.sigma_q_field, np.float32)      # (H,W,K,K)

        w = m[..., None]                                   # (H,W,1)
        N += float(np.sum(m))

        # sum μ and (Σ + μμ^T)
        Sx  += np.sum(w * mu, axis=(0,1))
        # batch outer products: (H,W,K,1)*(H,W,1,K) -> (H,W,K,K)
        outer = mu[..., :, None] * mu[..., None, :]
        Sxx  += np.sum(Sig + outer, axis=(0,1)).astype(np.float32)

    return Sxx, Sx, N, K




def expected_nll_gaussian(
    y,                # (..., D)
    mu,               # (..., Kx)
    Sigma,            # (..., Kx,Kx)
    W,                # (D, Kq)
    b,                # (D,)
    sigma2,           # scalar
    *,
    mask=None,
    Phi_tilde=None,   # optional (..., Kq, Kp) maps p → q
    sanitize_eps=1e-8
):
    y      = np.asarray(y,      np.float32)
    mu     = np.asarray(mu,     np.float32)
    Sigma  = np.asarray(Sigma,  np.float32)
    W      = np.asarray(W,      np.float32)
    b      = np.asarray(b,      np.float32)
    sigma2 = float(sigma2)

    if Phi_tilde is not None:
        raise ValueError(
            "vfe_mu_sigma_grads: Phi_tilde was provided but this build expects q-fiber inputs "
            "(mu=mu_q, Sigma=Sigma_q). Remove Phi_tilde or enable the p→q path."
        )

    # Already in q-fiber     
    mu_q = mu
    S_q  = sanitize_sigma(Sigma, eps=sanitize_eps)  # <-- FIX

    D = y.shape[-1]
    # r = (W μ_q + b) - y
    r  = (mu_q @ W.T) + b - y                  # (..., D)
    r2 = np.sum(r * r, axis=-1)                # (...)

    # tr(W Σ_q W^T) = tr(Σ_q W^T W)
    WT_W   = (W.T @ W).astype(np.float32)      # (Kq, Kq)
    tr_term = np.einsum("...ij,ij->...", S_q, WT_W, optimize=True)

    const = 0.5 * D * np.log(2.0 * np.pi * max(sigma2, 1e-12))
    quad  = 0.5 * (r2 + tr_term) / max(sigma2, 1e-12)
    nll   = const + quad

    if mask is not None:       
        nll = nll * np.asarray(mask, np.float32)

    total = float(np.sum(nll))
    return total, (r, WT_W, r2, tr_term)



        




def vfe_theta_grads(y, mu, Sigma, W, b, sigma2, *, mask=None):
    """
    Euclidean grads wrt theta = {W, b, sigma2} for
        F = E_q[-log p(y|x_q)],  y|x_q ~ N(W x_q + b, sigma2 I)
    Returns summed grads over batch/pixels: (dW, db, d_sigma2).
    All inputs are assumed in the q-fiber.
    """
    import numpy as np

    y     = np.asarray(y,     np.float32)   # (..., D)
    mu    = np.asarray(mu,    np.float32)   # (..., K)
    Sigma = np.asarray(Sigma, np.float32)   # (..., K, K)
    W     = np.asarray(W,     np.float32)   # (D, K)
    b     = np.asarray(b,     np.float32)   # (D,)
    s2    = float(max(sigma2, 1e-12))
    inv_s2 = 1.0 / s2

    # Mask (ones if None) with convenient shapes
    if mask is None:
        m  = 1.0
        mm = 1.0          # (..., 1)
        mS = 1.0          # (..., 1, 1)
        N  = int(np.prod(y.shape[:-1]))  # number of examples
    else:
        m  = np.asarray(mask, np.float32)                 # (...)
        mm = m[..., None]                                 # (..., 1)
        mS = m[..., None, None]                           # (..., 1, 1)
        N  = int(np.sum(m))                               # active examples

    # Residuals
    r = (mu @ W.T) + b - y                                # (..., D)
    r_masked = r * mm                                     # (..., D)

    # dW: sum (r mu^T + W Σ)
    dW = np.einsum("...d,...k->dk", r_masked, mu, optimize=True)  # (D, K)
    Sigma_sum = np.sum(Sigma * mS, axis=tuple(range(Sigma.ndim-2)))  # (K, K)
    dW += W @ Sigma_sum
    dW *= inv_s2

    # db: sum r
    db = np.sum(r_masked, axis=tuple(range(r_masked.ndim-1))) * inv_s2  # (D,)

    # d sigma2:
    # num = Σ_examples [ r^2 + tr(W Σ W^T) ]
    r2   = np.sum((r * r) * mm, axis=-1)                                 # (...)
    WT_W = (W.T @ W).astype(np.float32)                                  # (K, K)
    trm  = np.einsum("...ij,ij->...", Sigma * mS, WT_W, optimize=True)   # (...)
    num  = float(np.sum(r2 + trm))
    D    = int(y.shape[-1])
    d_sigma2 = 0.5 * ( (D * max(N, 0)) / s2 - (num / (s2 * s2)) )        # scalar

    return dW.astype(np.float32), db.astype(np.float32), float(d_sigma2)

