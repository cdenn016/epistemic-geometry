# -*- coding: utf-8 -*-
"""
omega.py — Lie-group exponentials, transports, BCH helpers, and curvature ops.
CacheHub-ready: uses ctx.cache namespaces 'exp' and 'omega' when provided.

Author: c&c
"""
from __future__ import annotations
from typing import Optional, Iterable
import numpy as np
import math
from joblib import Parallel, delayed, parallel_backend

from core.numerical_utils import sanitize_sigma, safe_inv



# Public API
__all__ = [
    "exp_lie_algebra_irrep", 
    "retract_phi_principal",  
    "d_exp_phi_exact",
    "d_exp_phi_tilde_exact",
    "inverse_fisher_metric_field"    
]



# -----------------------------------------------------------------------------
# Principal-ball retraction (axis–angle)
# -----------------------------------------------------------------------------



def retract_phi_principal(
    phi,
    *,
    margin: Optional[float] = None,
    max_theta: Optional[float] = None,
    strict_numerics: bool = True,
    use_float64: bool = False,
):
    """
    Project axis–angle φ onto the SO(3) principal ball (‖φ‖ ≤ π − margin),
    with stable handling of small norms and 2π wrap/reflection.

    Key differences from the old version:
      - No explicit 1/t path with zeros → no small-angle collapse to 0.
      - Scale original vector directly by a safe factor (target_norm / max(t, eps)).
      - Axis flip applied only when t mod 2π exceeds π (the “reflection” branch).
    """
 
    margin = 1e-4
    margin = float(margin)

    dtype = np.float64 if use_float64 else np.float32
    v = np.asarray(phi, dtype=dtype)
    if v.shape == () or v.shape[-1] != 3:
        return v.astype(np.float32, copy=False)

    if not np.all(np.isfinite(v)):
        raise FloatingPointError("retract_phi_principal: nonfinite input detected.")

    pi = math.pi
    two_pi = 2.0 * pi
    eps = np.finfo(dtype).eps

    # norms and 2π wrapping
    t = np.linalg.norm(v, axis=-1, keepdims=True)        # (...,1)
    t_scalar = t[..., 0]                                  # (...,)
    t_mod = np.remainder(t_scalar, two_pi)                # [0, 2π)
    over = (t_mod > pi)                                   # reflect region

    # reflected target magnitude in [0, π]
    t_ref = np.where(over, (two_pi - t_mod), t_mod)       # (...,)
    # clamp to principal ball
    t_target = np.minimum(t_ref, (pi - margin))           # (...,)

    # stable scale factor: target / max(current, eps)
    denom = np.maximum(t_scalar, eps)                     # (...,)
    scale = (t_target / denom)[..., None]                 # (...,1)

    # scale the original vector; flip axis if in the reflected branch
    out = v * scale                                       # (...,3)
    out = np.where(over[..., None], -out, out)

    out = out.astype(np.float32, copy=False)

    # optional hard cap ( ≤ π - margin already, but keep for caller convenience)
    if max_theta is not None:
        cap = float(min(float(max_theta), pi - margin))
        if cap < 0.0:
            cap = 0.0
        th = np.linalg.norm(out, axis=-1, keepdims=True)  # (...,1)
        scale2 = np.where(th > 0.0, np.minimum(1.0, cap / th), 1.0).astype(np.float32)
        out = out * scale2

    return out




def pre_retract_fields(objs):
    """Project φ and φ̃ into the SO(3) principal ball before building caches."""
    for a in (objs or []):
        if a is None:
            continue
        if hasattr(a, "phi_field") and a.phi_field is not None:
            a.phi_field = retract_phi_principal(a.phi_field)
        if hasattr(a, "phi_model_field") and a.phi_model_field is not None:
            a.phi_model_field = retract_phi_principal(a.phi_model_field)





# =============================================================================
#                          Exponentials / Transports
# =============================================================================



def exp_lie_algebra_irrep(
    v_batch: np.ndarray,
    generators: np.ndarray,
    *,
    threshold: float = 1e-3,
    max_norm: Optional[float] = None,
    parallelize_expm: bool = False,
    n_jobs: int = -1,
    strict_numerics: bool = True,           # NEW: fail fast if nonfinite
    recover: Optional[str] = None,          # NEW: None | "nan" | "identity" | "zero" (used iff strict_numerics=False)
    reproject_ortho: bool = False,          # NEW: optional SVD projection to nearest orthogonal (costly)
    use_float64: bool = True,               # NEW: do math in float64, return float32
    **_legacy,                              
) -> np.ndarray:
    """
    Compute exp(Σ v^a G_a) in an arbitrary K×K irrep for a batch of v.

    v_batch:    (..., 3) axis–angle coefficients in the chosen basis
    generators: (3, K, K) irrep generators (typically skew for SO(3))
    Returns:    (..., K, K) float32

    Notes:
      - 'threshold' controls small-angle Taylor cutoff.
      - 'max_norm' clips ||v|| radially for stability.
      - No in-kernel masking; strict_numerics governs error policy.
    """
    # --- shape & dtype checks
    v = np.asarray(v_batch, dtype=(np.float64 if use_float64 else np.float32))
    G = np.asarray(generators, dtype=v.dtype)

    if v.ndim == 0 or v.shape[-1] != 3:
        raise ValueError(f"exp_lie_algebra_irrep: expected (...,3) v_batch, got {v.shape}")
    if G.ndim != 3 or G.shape[0] != 3 or G.shape[-1] != G.shape[-2]:
        raise ValueError(f"exp_lie_algebra_irrep: generators must be (3,K,K), got {G.shape}")

    if strict_numerics:
        if not (np.all(np.isfinite(v)) and np.all(np.isfinite(G))):
            raise FloatingPointError("exp_lie_algebra_irrep: nonfinite v/generators.")

    batch_shape = v.shape[:-1]
    d = 3
    K = int(G.shape[-1])

    # Optional global norm clip (safe at 0)
    if max_norm is not None:
        vv = v.reshape(-1, d)
        n = np.linalg.norm(vv, axis=1)
        scale = np.minimum(1.0, float(max_norm) / np.maximum(n, 1e-16)).astype(v.dtype)
        v = (vv * scale[:, None]).reshape(batch_shape + (d,))

    # Algebra element: Xi = v·G, then enforce skew numerically
    Xi = np.einsum("...a,aij->...ij", v, G, optimize=True)          # (...,K,K)
    X = 0.5 * (Xi - np.swapaxes(Xi, -1, -2))                        # (...,K,K)

    # Flatten for batch processing
    flat = X.reshape(-1, K, K)
    out  = np.empty_like(flat)

    # Small-angle mask
    norms = np.linalg.norm(v.reshape(-1, d), axis=1)                # (N,)
    mask_small = norms < float(threshold)
    mask_big   = ~mask_small

    # Taylor (order 4) near identity
    if np.any(mask_small):
        Xs = flat[mask_small]
        I = np.eye(K, dtype=flat.dtype)[None, ...]
        X2 = Xs @ Xs
        X3 = X2 @ Xs
        X4 = X2 @ X2
        out[mask_small] = I + Xs + 0.5*X2 + (1.0/6.0)*X3 + (1.0/24.0)*X4

    # Exact expm elsewhere
    if np.any(mask_big):
        Xh = flat[mask_big]

        # Local expm with SciPy if available; minimal fallback otherwise
        def _expm(A):
            try:
                from scipy.linalg import expm as _scipy_expm   # prefer SciPy
                return _scipy_expm(A)
            except Exception:
                # Minimal Pade(13) + scaling & squaring (batched via loop)
                return _expm_pade13(A)

        if parallelize_expm and Xh.shape[0] >= 64:
            try:
               
                with parallel_backend("threading"):
                    res = Parallel(n_jobs=n_jobs, batch_size=8)(
                        delayed(_expm)(X_i) for X_i in Xh
                    )
            except Exception:
                res = [_expm(X_i) for X_i in Xh]
        else:
            res = [_expm(X_i) for X_i in Xh]
        out[mask_big] = np.stack(res, axis=0)

    # Optional SVD reprojection to nearest orthogonal (use for fundamental or if drift bothers you)
    if reproject_ortho:
        U, _, Vt = np.linalg.svd(out, full_matrices=False)
        out = U @ Vt

    # Final finite check — no in-kernel masking
    if not np.all(np.isfinite(out)):
        raise FloatingPointError("exp_lie_algebra_irrep: nonfinite exp result.")
   

    return out.reshape(batch_shape + (K, K)).astype(np.float32, copy=False)


# ------- Minimal fallback: Pade(13) + scaling & squaring for a single matrix -------
def _expm_pade13(A: np.ndarray) -> np.ndarray:
    """
    Minimal, dependency-free expm fallback for a single (K,K) matrix.
    Good enough for skew-symmetric inputs typically seen here.
    """
    # Scaling
    A = np.asarray(A, dtype=np.float64)
    n_squarings = max(0, int(np.ceil(max(0.0, np.log2(np.linalg.norm(A, ord=np.inf))) - 1)))
    As = A / (2 ** n_squarings)

    # Pade(13) coefficients
    b = [64764752532480000., 32382376266240000., 7771770303897600., 1187353796428800.,
         129060195264000., 10559470521600., 670442572800., 33522128640., 1323241920.,
         40840800., 960960., 16380., 182., 1.]

    I = np.eye(A.shape[0], dtype=As.dtype)
    A2 = As @ As
    A4 = A2 @ A2
    A6 = A2 @ A4

    U = As @ (A6@(b[13]*A6 + b[11]*A4 + b[9]*A2) + b[7]*A6 + b[5]*A4 + b[3]*A2 + b[1]*I)
    V =      (A6@(b[12]*A6 + b[10]*A4 + b[8]*A2) + b[6]*A6 + b[4]*A4 + b[2]*A2 + b[0]*I)

    # (V - U)^{-1} (V + U)
    X = np.linalg.solve(V - U, V + U)

    # Squaring
    for _ in range(n_squarings):
        X = X @ X
    return X




# =============================================================================
#                       Exact dexp derivatives for SO(3)
# =============================================================================



def d_exp_phi_exact(
    phi_vec: np.ndarray,
    generators: np.ndarray,
    *,
    exp_phi_all: Optional[np.ndarray] = None,
    eps: float = 1e-12,
) -> Iterable[np.ndarray]:
    """
    ∂/∂φ^a e^{Φ} with Φ = Σ_a φ^a G_a  (SO(3) left-trivialized).
    Returns [dE/dφ^0, dE/dφ^1, dE/dφ^2], each (...,K,K).
    """
    phi_vec = np.asarray(phi_vec, dtype=np.float32)
    G = np.asarray(generators, dtype=np.float32)

    *shape, d = phi_vec.shape
    assert d == 3, "d_exp_phi_exact assumes SO(3) (d=3)."
    K = int(G.shape[-1])
    N = int(np.prod(shape)) if shape else 1

    φ = phi_vec.reshape(N, 3)                                 # (N,3)
    Φ = np.einsum("na,aij->nij", φ, G, optimize=True)         # (N,K,K)

    θ = np.linalg.norm(φ, axis=1)                             # (N,)
    c1 = np.empty_like(θ, dtype=np.float32)
    c2 = np.empty_like(θ, dtype=np.float32)
    small = θ < 1e-4
    if np.any(small):
        t = θ[small]; t2 = t*t; t4 = t2*t2
        c1[small] = 0.5 - t2/24.0 + t4/720.0
        c2[small] = 1.0/6.0 - t2/120.0 + t4/5040.0
    big = ~small
    if np.any(big):
        tb = θ[big]
        c1[big] = (1.0 - np.cos(tb)) / np.maximum(tb*tb, eps)
        c2[big] = (tb - np.sin(tb)) / np.maximum(tb*tb*tb, eps)

    if exp_phi_all is None:
       
        E = exp_lie_algebra_irrep(φ, G, parallelize_expm=False)  # (N,K,K)
    else:
        E = np.asarray(exp_phi_all, dtype=np.float32).reshape(N, K, K)

    # Commutators: ad_Φ(G_a) = [Φ, G_a], ad_Φ^2(G_a) = [Φ, [Φ, G_a]]
    ΦN = Φ[None, ...]                        # (1,N,K,K)
    G_A = G[:, None, :, :]                   # (3,1,K,K)

    # [Φ, G_a] = Φ G_a − G_a Φ  -> (3,N,K,K)
    comm1 = (ΦN @ G_A) - (G_A @ ΦN)

    # [Φ, [Φ, G_a]] -> (3,N,K,K)
    comm2 = (ΦN @ comm1) - (comm1 @ ΦN)

    # Q_a = G_a − c1 ad_Φ(G_a) + c2 ad_Φ^2(G_a)
    Q = G_A - c1[None, :, None, None] * comm1 + c2[None, :, None, None] * comm2  # (3,N,K,K)

    # d e^{Φ} / dφ^a = E · Q_a
    dE = np.einsum("nij,anjk->anik", E, Q, optimize=True)     # (3,N,K,K)
    dE = dE.reshape(3, *shape, K, K).astype(np.float32, copy=False)
    return [dE[i] for i in range(3)]


def d_exp_phi_tilde_exact(
    phi_tilde_vec: np.ndarray,
    generators: np.ndarray,
    *,
    exp_phi_tilde_all: Optional[np.ndarray] = None,
    eps: float = 1e-12,
):
    """
    Companion for φ̃; same construction and signs.
    """
    φ̃ = np.asarray(phi_tilde_vec, dtype=np.float32)
    G = np.asarray(generators, dtype=np.float32)

    *shape, d = φ̃.shape
    assert d == 3, "d_exp_phi_tilde_exact assumes SO(3) (d=3)."
    K = int(G.shape[-1])
    N = int(np.prod(shape)) if shape else 1

    φ = φ̃.reshape(N, 3)
    Φ = np.einsum("na,aij->nij", φ, G, optimize=True)         # (N,K,K)

    θ = np.linalg.norm(φ, axis=1)
    c1 = np.empty_like(θ, dtype=np.float32)
    c2 = np.empty_like(θ, dtype=np.float32)
    small = θ < 1e-4
    if np.any(small):
        t = θ[small]; t2 = t*t; t4 = t2*t2
        c1[small] = 0.5 - t2/24.0 + t4/720.0
        c2[small] = 1.0/6.0 - t2/120.0 + t4/5040.0
    big = ~small
    if np.any(big):
        tb = θ[big]
        c1[big] = (1.0 - np.cos(tb)) / np.maximum(tb*tb, eps)
        c2[big] = (tb - np.sin(tb)) / np.maximum(tb*tb*tb, eps)

    if exp_phi_tilde_all is None:
       
        E = exp_lie_algebra_irrep(φ, G, parallelize_expm=False)
    else:
        E = np.asarray(exp_phi_tilde_all, dtype=np.float32).reshape(N, K, K)

    ΦN = Φ[None, ...]
    G_A = G[:, None, :, :]
    comm1 = (ΦN @ G_A) - (G_A @ ΦN)
    comm2 = (ΦN @ comm1) - (comm1 @ ΦN)
    Q = G_A - c1[None, :, None, None] * comm1 + c2[None, :, None, None] * comm2

    dE = np.einsum("nij,anjk->anik", E, Q, optimize=True)
    dE = dE.reshape(3, *shape, K, K).astype(np.float32, copy=False)
    return [dE[i] for i in range(3)]


def inverse_fisher_metric_field(ctx, agent, generators, *, which="q", eps=1e-8, tol=None):
    """
    Per-pixel inverse Fisher metric for algebra coords (φ or φ̃).
    Fail fast on any invalid input or numerical issue.
    """
    import numpy as np
    from core.transport_cache import Fisher_blocks, _aid
    import core.config as config


    # --- pull Σ and mask ---
    Sig = np.asarray(
        agent.sigma_q_field if which == "q" else agent.sigma_p_field,
        np.float64,
    )
    
   

    if not np.all(np.isfinite(Sig)):
        raise FloatingPointError("Non-finite entries in Sigma")

    Gens = np.asarray(generators, np.float64)  # (d,K,K)
    if not np.all(np.isfinite(Gens)):
        raise FloatingPointError("Non-finite entries in generators")

    H, W, K, _ = Sig.shape
    d = int(Gens.shape[0])

    mask = (np.asarray(agent.mask) > float(getattr(config, "support_tau", 1e-4)))
    mask = mask.reshape(H, W)

    # --- optional cache lookup ---
    C = getattr(ctx, "cache", None)
    step = int(getattr(ctx, "global_step", -1))
    aid = _aid(agent)
    key = ("FisherMetricInv", which, aid, step, (H, W, K, d))
    if C is not None:
        cached = C.get("fisher", key)
        if cached is not None:
            return cached

    # --- strict Fisher computation ---
    # Any failure here will raise and propagate
    Fb = Fisher_blocks(ctx, agent, which=which, tol=tol)
    Prec = np.asarray(Fb["precision"], np.float64)  # (H,W,K,K)
    if not np.all(np.isfinite(Prec)):
        raise FloatingPointError("Non-finite precision matrix from Fisher_blocks")

    # --- build T_a = Σ^{-1} G_a Σ^{-1} ---
    T = np.einsum("...ij,ajk->...aik", Prec, Gens, optimize=True)
    T = np.einsum("...aik,...kl->...ail", T, Prec, optimize=True)

    # --- F_ab = tr(T_a G_b) ---
    F = np.einsum("...aij,bji->...ab", T, Gens, optimize=True)
    F = 0.5 * (F + np.swapaxes(F, -1, -2))

    # --- invert per pixel on mask ---
    Fflat = F.reshape(-1, d, d)
    mflat = mask.reshape(-1)
    Finv_f = np.zeros_like(Fflat)
    
    if np.any(mflat):
        M = Fflat[mflat]
        w, V = np.linalg.eigh(M)
        w_floor = np.clip(w, 1e-6, None)  # or config.fisher_eig_floor
        Minv = (V * (1.0 / w_floor)[..., None, :]) @ V.swapaxes(-1, -2)
        Minv = 0.5 * (Minv + Minv.swapaxes(-1, -2))
        Finv_f[mflat] = Minv
    
    Finv = Finv_f.reshape(H, W, d, d).astype(np.float32, copy=False)
    
    if C is not None:
        C.put("fisher", key, Finv)
    return Finv

# =============================================================================
#                       Holonomy / transport helpers
# =============================================================================





