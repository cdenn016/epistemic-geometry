
from __future__ import annotations
from typing import Any, Iterable, Optional, Sequence
import numpy as np

# Your existing utilities
from core.omega import exp_lie_algebra_irrep, retract_phi_principal
from core.numerical_utils import safe_omega_inv

import hashlib
from core.get_generators import get_generators

"""
Cache Policy — Rule of One
1) One cache hub: runtime_ctx.cache (cleared once per step).
2) One facade to read/write: this file (E_grid, Omega, Jinv_grid, Phi, Phi_tilde, Lambda_*).
3) One warm point per step: ensure_dirty(...) — nowhere else.
Consumers must never pre-warm; they just call the facade.
"""




def _bases_key(agent) -> tuple[int, int, int]:
    
    aid = _aid(agent)
    Kq = int(np.asarray(agent.mu_q_field).shape[-1])
    Kp = int(np.asarray(agent.mu_p_field).shape[-1])
    return (aid, Kq, Kp)



def _morphism_key(agent, kind: str, cfg: dict, step_tag: int,
                  Kq: int, Kp: int, Phi0: Optional[np.ndarray]) -> tuple:
    
    # current algebra fields (affect the transported morphisms)
    phi_q = getattr(agent, "phi", None)
    phi_p = getattr(agent, "phi_model", None)

    # side selection by kind
    if kind == "q_to_p":
        left_phi, right_phi = phi_p, phi_q
    elif kind == "p_to_q":
        left_phi, right_phi = phi_q, phi_p
    else:
        raise ValueError(f"unknown morphism kind: {kind!r}")

    # include generator signatures for safety across reducible/mixed reps
    try:
        Gsig_q = _gensig(get_generators(agent, "q"))
    except Exception:
        raise ValueError("[morphism_key] Gsig_q FAIL")
        Gsig_q = None
    try:
        Gsig_p = _gensig(get_generators(agent, "p"))
    except Exception:
        raise ValueError("[morphism_key] Gsig_p FAIL")
        Gsig_p = None

    aid = _aid(agent)  # will raise if missing
    return ("morphism",
            aid,
            str(kind),
            int(step_tag),
            (int(Kq), int(Kp)),
            _digest_array(Phi0),
            _digest_array(left_phi),
            _digest_array(right_phi),
            Gsig_q, Gsig_p)






def _get_phi(agent: Any, which: str) -> np.ndarray:
    if which == "q":
        phi = getattr(agent, "phi", None)
    else:
        phi = getattr(agent, "phi_model", None)
    if phi is None:
        raise ValueError(f"[transport_cache] phi field ({which}) missing")
    return phi





def get_A(ctx):
    A = getattr(ctx, "fields", {}).get("A", None)
    if A is None:
        raise RuntimeError("Global A not initialized. Call ensure_global_A(...) first.")
    return A



def orthogonalize_intertwiner(Phi0: np.ndarray) -> np.ndarray:
    """
    If Phi0 is square, project to the nearest orthogonal matrix via polar decomposition.
    For rectangular maps, returns Phi0 unchanged.
    """
    Kp, Kq = Phi0.shape
    if Kp != Kq:
        return Phi0
    U, _, Vt = np.linalg.svd(Phi0, full_matrices=False)
    return (U @ Vt).astype(Phi0.dtype, copy=False)




def get_morphism_bases(ctx, agent):
    
    ns  = ctx.cache.nsp("morph_base")
    key = _bases_key(agent)
    entry = ns.get(key)

    Gq = get_generators(agent, "q")
    Gp = get_generators(agent, "p")
    Kq, Kp = int(Gq.shape[1]), int(Gp.shape[1])

    dig_now = _gens_digest(Gq, Gp)
    
    if entry is not None and entry.get("digest") == dig_now:
        return entry["Phi0"], entry["Phit0"]

   
    # CONTRACT: build_intertwiner_bases
    from core.bundle_morphism_utils import build_intertwiner_bases
    from utils import _ensure_q_to_p_shape, _ensure_p_to_q_shape
    
    from runtime_context import cfg_get
    
    Phi0_new, Phit0_new, _ = build_intertwiner_bases(Gq, Gp, method="auto", return_meta=True)

    Phi0  = _ensure_q_to_p_shape(Phi0_new,  Kp, Kq).astype(np.float32, copy=False)  # (Kp,Kq)
    Phit0 = _ensure_p_to_q_shape(Phit0_new, Kq, Kp).astype(np.float32, copy=False)  # (Kq,Kp)
    if Kq == Kp:
        Phi0  = orthogonalize_intertwiner(Phi0)
        Phit0 = orthogonalize_intertwiner(Phit0)

    if not (np.isfinite(Phi0).all() and np.isfinite(Phit0).all()):
        raise ValueError("[morph] Φ0/Φ̃0 contain non-finite values")
    if max(np.linalg.norm(Phi0,'fro'), np.linalg.norm(Phit0,'fro')) == 0.0:
        raise ValueError("[morph] Φ0/Φ̃0 are zero")

    ns[key] = {"Phi0": Phi0, "Phit0": Phit0, "digest": dig_now, "warned": False}

    # Residuals using (3,K,K)
    tol_rel = float(cfg_get(ctx, "intertwiner_rel_tol", 1e-7))
    
    if not ns[key].get("warned", False):
        try:
            r1 = _intertwining_resid(Gp, Gq, Phi0)   # || Gp Φ0 - Φ0 Gq ||
            r2 = _intertwining_resid(Gq, Gp, Phit0)  # || Gq Φ~0 - Φ~0 Gp ||
            scale = max(np.linalg.norm(Gq,'fro'), np.linalg.norm(Gp,'fro'), 1.0)
            rel = (r1 + r2) / (1e-6 + scale)
            if rel > tol_rel:
                print(f"[morph] note: relative intertwiner residual ≈ {rel:.2e}")
                ns[key]["warned"] = True
        except Exception:
            ns[key]["warned"] = False

    return ns[key]["Phi0"], ns[key]["Phit0"]




# ---------------------------------------------------------------------------
#                              Caches
# ---------------------------------------------------------------------------
# runtime_context.py (or wherever ensure_global_A lives)

def bump_A_version(ctx):
    v = int(getattr(ctx, "A_version", 0))
    ctx.A_version = (v + 1) & 0x7FFFFFFF


def ensure_global_A(ctx, shape_hw, *, init_scale=0.0, dtype=np.float32):
    """
    Ensure a global gauge field A with shape (H, W, 2, 3):
      - axis -2: spatial direction (0 -> x, 1 -> y)
      - axis -1: so(3) components (3)
    Back-compat: if an older (H,W,3) array is found, expand to (H,W,2,3) with zeros for Ay.
    """
    if not hasattr(ctx, "fields"):
        raise RuntimeError("ctx.fields missing; update RuntimeCtx to include a fields dict.")
    H, W = int(shape_hw[0]), int(shape_hw[1])

    A = ctx.fields.get("A", None)
    if A is not None:
        A = np.asarray(A)
        if A.shape == (H, W, 2, 3):
            ctx.fields["A"] = A.astype(dtype, copy=False)
            return ctx.fields["A"]
        if A.shape == (H, W, 3):
            # upgrade: interpret as A_x, set A_y=0
            A_up = np.zeros((H, W, 2, 3), dtype=dtype)
            A_up[..., 0, :] = A.astype(dtype, copy=False)
            ctx.fields["A"] = A_up
            return ctx.fields["A"]
        # shape mismatch (new grid size) -> reinit
        ctx.fields["A"] = None

    if init_scale and init_scale > 0.0:
        rng = np.random.default_rng(0)
        A = rng.normal(0.0, init_scale, size=(H, W, 2, 3)).astype(dtype)
    else:
        A = np.zeros((H, W, 2, 3), dtype=dtype)
    ctx.fields["A"] = A
    return ctx.fields["A"]

# --- replace expA_q with this ---
def expA_q(ctx, agent):
    """
    Exponentiate the global A-connection in the agent's q-representation.
    Returns split geometry (H, W, 2, Kq, Kq) if A is spatial (H,W,2,3),
    else (Kq, Kq) for a single 3-vector.
    """
    from runtime_context import cfg_get
    
    if agent is None:
        raise ValueError("expA_q: `agent` must be provided")
    C = ctx.cache
    step_tag = int(getattr(ctx, "global_step", -1))
    A_version = int(getattr(ctx, "A_version", 0))  # << include in key

    Gq = get_generators(agent, "q")
    if not (isinstance(Gq, np.ndarray) and Gq.ndim == 3 and Gq.shape[0] == 3 and Gq.shape[1] == Gq.shape[2]):
        raise ValueError(f"expA_q: generators_q must be (3,Kq,Kq); got {None if Gq is None else Gq.shape}")
    Gq = Gq.astype(np.float32, copy=False)
    max_norm = float(cfg_get(ctx, "exp_clip_max_norm", 1e4))

    # Rep sig for cache
    gsig = _digest_array(Gq)

    A = get_A(ctx)  # you store (H,W,2,3)
    A = np.asarray(A, dtype=np.float32)

    # ---- scalar vector case (3,) fallback still supported ----
    if A.ndim == 1:
        if A.shape[0] != 3:
            raise ValueError(f"expA_q: A must be (3,) or (H,W,2,3); got {A.shape}")
        key = ("expA_q_scalar", step_tag, gsig, A_version)
        U = C.get("exp", key)
        if U is None:
            A1 = retract_phi_principal(A, margin=1e-4, strict_numerics=True, use_float64=False).astype(np.float32, copy=False)
            U = exp_lie_algebra_irrep(A1, Gq, max_norm=max_norm)
            if not np.all(np.isfinite(U)):
                raise FloatingPointError("expA_q produced non-finite values")
            C.put("exp", key, U.astype(np.float32, copy=False))
        return U

    # ---- spatial split case (H,W,2,3) ----
    if not (A.ndim == 4 and A.shape[-2:] == (2, 3)):
        raise ValueError(f"expA_q: A must be (H,W,2,3); got {A.shape}")

    H, W = int(A.shape[0]), int(A.shape[1])
    key = ("expA_q_split", step_tag, gsig, (H, W), A_version)

    U = C.get("exp", key)
    if U is not None:
        return U

    # sanitize + clip each axis then exponentiate
    Ax = retract_phi_principal(A[..., 0, :], margin=1e-4, strict_numerics=True, use_float64=False).astype(np.float32, copy=False)
    Ay = retract_phi_principal(A[..., 1, :], margin=1e-4, strict_numerics=True, use_float64=False).astype(np.float32, copy=False)

    
    def _clip_axis_norm(v, maxn):
        if maxn <= 0: return v
        n = np.linalg.norm(v, axis=-1, keepdims=True)
        s = np.minimum(1.0, (maxn / (n + 1e-12))).astype(np.float32)
        return (v * s).astype(np.float32, copy=False)

    Ax = _clip_axis_norm(Ax, max_norm)
    Ay = _clip_axis_norm(Ay, max_norm)

    Ux = exp_lie_algebra_irrep(Ax, Gq, max_norm=max_norm)  # (H,W,Kq,Kq)
    Uy = exp_lie_algebra_irrep(Ay, Gq, max_norm=max_norm)

    if not (np.isfinite(Ux).all() and np.isfinite(Uy).all()):
        raise FloatingPointError("expA_q: non-finite Ux/Uy")

    U = np.stack([Ux, Uy], axis=-3)  # (H,W,2,Kq,Kq)  << split geometry
    C.put("exp", key, U.astype(np.float32, copy=False))
    return U


# --- replace expA_p with this (same structure) ---
def expA_p(ctx, agent):
    
    from runtime_context import cfg_get
    
    if agent is None:
        raise ValueError("expA_p: `agent` must be provided")
    C = ctx.cache
    step_tag = int(getattr(ctx, "global_step", -1))
    A_version = int(getattr(ctx, "A_version", 0))

    Gp = get_generators(agent, "p")
    if not (isinstance(Gp, np.ndarray) and Gp.ndim == 3 and Gp.shape[0] == 3 and Gp.shape[1] == Gp.shape[2]):
        raise ValueError(f"expA_p: generators_p must be (3,Kp,Kp); got {None if Gp is None else Gp.shape}")
    Gp = Gp.astype(np.float32, copy=False)
    max_norm = float(cfg_get(ctx, "exp_clip_max_norm", 1e4))

    gsig = _digest_array(Gp)

    A = get_A(ctx)
    A = np.asarray(A, dtype=np.float32)

    if A.ndim == 1:
        if A.shape[0] != 3:
            raise ValueError(f"expA_p: A must be (3,) or (H,W,2,3); got {A.shape}")
        key = ("expA_p_scalar", step_tag, gsig, A_version)
        U = C.get("exp", key)
        if U is None:
            A1 = retract_phi_principal(A, margin=1e-4, strict_numerics=True, use_float64=False).astype(np.float32, copy=False)
            U = exp_lie_algebra_irrep(A1, Gp, max_norm=max_norm)
            if not np.all(np.isfinite(U)):
                raise FloatingPointError("expA_p produced non-finite values")
            C.put("exp", key, U.astype(np.float32, copy=False))
        return U

    if not (A.ndim == 4 and A.shape[-2:] == (2, 3)):
        raise ValueError(f"expA_p: A must be (H,W,2,3); got {A.shape}")

    H, W = int(A.shape[0]), int(A.shape[1])
    key = ("expA_p_split", step_tag, gsig, (H, W), A_version)

    U = C.get("exp", key)
    if U is not None:
        return U

    Ax = retract_phi_principal(A[..., 0, :], margin=1e-4, strict_numerics=True, use_float64=False).astype(np.float32, copy=False)
    Ay = retract_phi_principal(A[..., 1, :], margin=1e-4, strict_numerics=True, use_float64=False).astype(np.float32, copy=False)

    
    def _clip_axis_norm(v, maxn):
        if maxn <= 0: return v
        n = np.linalg.norm(v, axis=-1, keepdims=True)
        s = np.minimum(1.0, (maxn / (n + 1e-12))).astype(np.float32)
        return (v * s).astype(np.float32, copy=False)

    Ax = _clip_axis_norm(Ax, max_norm)
    Ay = _clip_axis_norm(Ay, max_norm)

    Ux = exp_lie_algebra_irrep(Ax, Gp, max_norm=max_norm)  # (H,W,Kp,Kp)
    Uy = exp_lie_algebra_irrep(Ay, Gp, max_norm=max_norm)

    if not (np.isfinite(Ux).all() and np.isfinite(Uy).all()):
        raise FloatingPointError("expA_p: non-finite Ux/Uy")

    U = np.stack([Ux, Uy], axis=-3)  # (H,W,2,Kp,Kp)
    C.put("exp", key, U.astype(np.float32, copy=False))
    return U



def _frame_E(ctx, agent, which: str) -> np.ndarray:
    from runtime_context import cfg_get
    
    G   = get_generators(agent, which)
    phi = _get_phi(agent, which)
    max_norm = float(cfg_get(ctx, "exp_clip_max_norm", 1e4))
    # Validate G early (3,K,K)
    G = np.asarray(G, dtype=np.float32)
    if not (G.ndim == 3 and G.shape[0] == 3 and G.shape[1] == G.shape[2]):
        raise ValueError(f"_frame_E: generators[{which}] must be (3,K,K); got {G.shape}")

    phi = retract_phi_principal(phi, margin=1e-4, strict_numerics=True, use_float64=False).astype(np.float32, copy=False)
    return exp_lie_algebra_irrep(phi, G, max_norm=max_norm)




def E_grid(ctx, agent, which: str = "q", *, tol=None) -> np.ndarray:
    
    # 1) Use per-step snapshot if present; otherwise build once (fallback)
    cfg = getattr(ctx, "step_cfg", None)
    
    C        = ctx.cache
    step_tag = int(getattr(ctx, "global_step", -1))

    phi = _get_phi(agent, which)
    G   = get_generators(agent, which)

    # 2) Validate generators and compute a cheap, stable signature
    G32 = np.asarray(G, np.float32, order="C")
    if not (G32.ndim == 3 and G32.shape[0] == 3 and G32.shape[1] == G32.shape[2]):
        raise ValueError(f"E_grid[{which}]: generators must be (3,K,K); got {G32.shape}")
    K = int(G32.shape[1])
    gsig = getattr(agent, f"_gensig_{which}", None)
    if gsig is None:
        gsig = (K, hashlib.sha256(G32.tobytes()).hexdigest())
        setattr(agent, f"_gensig_{which}", gsig)

    # 3) Digest phi for the cache key
    phi32  = np.asarray(phi, np.float32, order="C")
    phisig = hashlib.sha256(phi32.tobytes()).hexdigest()

    # 4) Only include the knobs that affect E
    
    
    A_version = int(getattr(ctx, "A_version", 0))
    cfgsig = (cfg.use_global_A, cfg.A_compose_order, 
              cfg.phi_small_threshold, cfg.exp_clip_max_norm, A_version)
   
    

    key = ("E_grid", step_tag, _aid(agent), which, gsig, phisig, cfgsig, tol)
    E_cached = C.get("exp", key)
    if E_cached is not None:
        return E_cached

    # 5) Sanitize phi once
    phi32 = retract_phi_principal(
        phi32, margin=1e-4, strict_numerics=True, use_float64=False
    ).astype(np.float32, copy=False)

    # 6) Small-angle fast path (use max, not all)
    if phi32.shape[-1] == 3:
        th = np.linalg.norm(phi32, axis=-1)
        if float(np.max(th)) < cfg.phi_small_threshold:
            E = np.broadcast_to(np.eye(K, dtype=np.float32), phi32.shape[:-1] + (K, K)).copy()
            if cfg.use_global_A:
                print(f"[FAST PATH A IN E_GRID] fast-path composing A and E\n\n")
                U_geom = expA_q(ctx, agent) if which == "q" else expA_p(ctx, agent)
                U_geom = _compose_geom_if_split(U_geom, order=cfg.A_compose_order)
                E = U_geom @ E
            C.put("exp", key, E)
            return E

    # 7) Main path
    U_frame = exp_lie_algebra_irrep(phi32, G32, max_norm=cfg.exp_clip_max_norm).astype(np.float32, copy=False)

    if cfg.use_global_A:
        
        U_geom = expA_q(ctx, agent) if which == "q" else expA_p(ctx, agent)
        U_geom = _compose_geom_if_split(U_geom, order=cfg.A_compose_order)
        E = U_geom @ U_frame
        #print(f"[use global A] AFTER composing A and E\n\n")
    else:
        E = U_frame

    if not np.all(np.isfinite(E)):
        raise FloatingPointError("E_grid produced non-finite matrices")

    C.put("exp", key, E.astype(np.float32, copy=False))
    return E



def _compose_geom_if_split(U_geom: np.ndarray, order: str = "yx") -> np.ndarray:
    """
    Accepts either (K,K)/(H,W,K,K) or split (H,W,2,K,K) geometry; returns (K,K)/(H,W,K,K).
    """
    U_geom = np.asarray(U_geom, np.float32)
    if U_geom.ndim >= 4 and U_geom.shape[-3] == 2:
        Ugx = U_geom[..., 0, :, :]
        Ugy = U_geom[..., 1, :, :]
        return (Ugy @ Ugx) if (order != "xy") else (Ugx @ Ugy)
    return U_geom



def Omega(ctx: Any, ai: Any, aj: Any, which: str = "q", *, tol=None) -> np.ndarray:
    """
    Neighbor transport Ω_{ij} with freeze modes.

    config.freeze_omega_mode:
      - "none"     : default behavior (cached per step & φ)
      - "identity" : return identity transport (per-pixel I_K)
      # NOTE: "snapshot" is not implemented here; remove from config/docs or implement explicitly.
    """
    from runtime_context import cfg_get
    C        = ctx.cache 
    
    step_tag = int(getattr(ctx, "global_step", -1))
    mode     = str(cfg_get(ctx, "freeze_omega_mode", "none")).lower()

    # ---------- Mode: IDENTITY ----------
    if mode == "identity":
        keyI = ("Omega_identity", _aid(ai), _aid(aj), which)
        OmI = C.get("omega", keyI)
        if OmI is None:
            OmI = _identity_field(ai, which)  # returns (H,W,K,K) or (K,K)
            C.put("omega", keyI, OmI)
        return OmI

    # ---------- Pull fields/generators ----------
    phi_i = _get_phi(ai, which)
    phi_j = _get_phi(aj, which)

    Gi = get_generators(ai, which)
    Gj = get_generators(aj, which)

    # Validate generator shapes early (3,K,K)
    Gi32 = np.asarray(Gi, np.float32, order="C")
    Gj32 = np.asarray(Gj, np.float32, order="C")
    if not (Gi32.ndim == 3 and Gi32.shape[0] == 3 and Gi32.shape[1] == Gi32.shape[2]):
        raise ValueError(f"Omega[{which}]: generators_i must be (3,K,K); got {Gi32.shape}")
    if not (Gj32.ndim == 3 and Gj32.shape[0] == 3 and Gj32.shape[1] == Gj32.shape[2]):
        raise ValueError(f"Omega[{which}]: generators_j must be (3,K,K); got {Gj32.shape}")

    # Build compact, stable signatures (don’t shove raw arrays/dicts into keys)
    def _arrsig(a: np.ndarray) -> str:
        a32 = np.asarray(a, np.float32, order="C")
        return hashlib.sha256(a32.tobytes()).hexdigest()

    gensig_i = getattr(ai, f"_gensig_{which}", None)
    if gensig_i is None:
        gensig_i = (int(Gi32.shape[1]), hashlib.sha256(Gi32.tobytes()).hexdigest())
        setattr(ai, f"_gensig_{which}", gensig_i)

    gensig_j = getattr(aj, f"_gensig_{which}", None)
    if gensig_j is None:
        gensig_j = (int(Gj32.shape[1]), hashlib.sha256(Gj32.tobytes()).hexdigest())
        setattr(aj, f"_gensig_{which}", gensig_j)

    phisig_i = _arrsig(phi_i)
    phisig_j = _arrsig(phi_j)

    # Only include cfg knobs that truly affect Ω here
    wrap_flag      = True
    cfgsig         = (wrap_flag, tol)

    key = ("Omega", step_tag, _aid(ai), _aid(aj), which, gensig_i, gensig_j, phisig_i, phisig_j, cfgsig)
    Om = C.get("omega", key)
    if Om is not None:
        return Om

    # Build frames
    Ei = _frame_E(ctx, ai, which)
    Ej = _frame_E(ctx, aj, which)
    if not (np.isfinite(Ei).all() and np.isfinite(Ej).all()):
        raise FloatingPointError("Omega: non-finite frame exponentials")

    Ej_inv = safe_omega_inv(Ej)  # expects finite SPD-ish numerics internally
    Om = np.matmul(Ei, Ej_inv)
    if not np.isfinite(Om).all():
        raise FloatingPointError("Omega: non-finite Ω")

    C.put("omega", key, Om.astype(np.float32, copy=False))
    return Om



def Jinv_grid(ctx, agent, which="q", bbox=None, *, tol=None):
    import numpy as np, hashlib

    C        = ctx.cache
    
    step_tag = int(getattr(ctx, "global_step", -1))
    wrap_flag = True

    phi = _get_phi(agent, which)

    # Build compact signature of phi (don’t push raw array/cfg into keys)
    phi32  = np.asarray(phi, np.float32, order="C")
    phisig = hashlib.sha256(phi32.tobytes()).hexdigest()
    cfgsig = (wrap_flag, tol)

    key = ("Jinv_grid", step_tag, _aid(agent), which, phisig, cfgsig)
    J = C.get("jinv", key)
    if J is None:
        phi32 = retract_phi_principal(
            phi32, margin=1e-4, strict_numerics=True, use_float64=False
        ).astype(np.float32, copy=False)
        # (...,3,3)
        J = build_dexpinv_matrix(phi32)
        C.put("jinv", key, J)

    if bbox is None:
        return J

    # If phi (and hence J) is not spatial (i.e., shape (...,3,3) with no H,W),
    # slicing by bbox would be invalid; guard it:
    if J.ndim < 4:
        # J is (3,3) or (...,3,3) without H,W — ignore bbox gracefully
        return J

    y0, y1, x0, x1 = bbox
    return J[y0:y1, x0:x1, :, :]


def Phi(ctx, agent, kind: str = "q_to_p"):
    """
    Bundle morphisms:
      kind == "q_to_p": Φ   = E_p  Φ₀   (E_q)^{-T}
      kind == "p_to_q": Φ̃   = E_q  Φ̃₀  (E_p)^{-T}

    Builds-and-caches both directions based on current (φ, φ̃), generators, bases,
    and relevant geometry config (A-connection settings).
    """
    import numpy as np, hashlib
    from runtime_context import cfg_get
    
    
    assert ctx is not None and hasattr(ctx, "cache"), "Phi: ctx with cache required"
    C = ctx.cache
    step_tag = int(getattr(ctx, "global_step", -1))

    # --- helpers ------------------------------------------------------------
    def _arrsig(a: np.ndarray | None) -> str | None:
        if a is None:
            return None
        a32 = np.asarray(a, np.float32, order="C")
        return hashlib.sha256(a32.tobytes()).hexdigest()

    # Strict agent id (no fallbacks)
    aid = _aid(agent)

    # Generators (3,K,K) with early validation
    Gq = get_generators(agent, "q")
    Gp = get_generators(agent, "p")
    Gq32 = np.asarray(Gq, np.float32, order="C")
    Gp32 = np.asarray(Gp, np.float32, order="C")
    if not (Gq32.ndim == 3 and Gq32.shape[0] == 3 and Gq32.shape[1] == Gq32.shape[2]):
        raise ValueError(f"Phi[q_to_p]: generators_q must be (3,Kq,Kq); got {Gq32.shape}")
    if not (Gp32.ndim == 3 and Gp32.shape[0] == 3 and Gp32.shape[1] == Gp32.shape[2]):
        raise ValueError(f"Phi[p_to_q]: generators_p must be (3,Kp,Kp); got {Gp32.shape}")

    Kq = int(Gq32.shape[1])
    Kp = int(Gp32.shape[1])

    # Cache a generator signature per agent to avoid hashing every call
    gensig_q = getattr(agent, "_gensig_q", None)
    if gensig_q is None:
        gensig_q = (Kq, hashlib.sha256(Gq32.tobytes()).hexdigest())
        setattr(agent, "_gensig_q", gensig_q)
    gensig_p = getattr(agent, "_gensig_p", None)
    if gensig_p is None:
        gensig_p = (Kp, hashlib.sha256(Gp32.tobytes()).hexdigest())
        setattr(agent, "_gensig_p", gensig_p)

    # Frozen bases (Kp×Kq), (Kq×Kp)
    Phi_0_in, Phi_tilde_0_in = get_morphism_bases(ctx, agent)
    Phi0sig  = _arrsig(Phi_0_in)
    Pht0sig  = _arrsig(Phi_tilde_0_in)

    # Current fields (digest after any retracts inside E_grid)
    phisig_q = _arrsig(getattr(agent, "phi", None))
    phisig_p = _arrsig(getattr(agent, "phi_model", None))

    # Geometry config that actually affects E_grid → hence Φ (keep it small)
    
    geom_sig = (
        bool(cfg_get(ctx,"use_global_A", False)),
        str(cfg_get(ctx,"A_compose_order", "yx")).lower(),
        float(cfg_get(ctx,"phi_small_threshold", 0.0)),
        float(cfg_get(ctx,"exp_clip_max_norm", 10.0)),
    )

    # Unified cache keys (compact & stable)
    def _key(direction: str):
        return (
            "morphism_full",
            aid,
            direction,
            (Kq, Kp),
            gensig_q, gensig_p,
            step_tag,          # drop this if you clear cache per step
            phisig_q, phisig_p,
            Phi0sig if direction == "q_to_p" else Pht0sig,
            geom_sig,
        )

    key_qp = _key("q_to_p")
    key_pq = _key("p_to_q")

    M_qp = C.get("morphism", key_qp)
    M_pq = C.get("morphism", key_pq)
    if (M_qp is not None) and (M_pq is not None):
        return M_qp if kind == "q_to_p" else M_pq

    # Build both directions (will use cached E_grid / expA_* internally)
    Phi_full, Phit_full = _build_morphisms_with_cache(ctx, agent, Phi_0_in, Phi_tilde_0_in)

    # Store & return
    C.put("morphism", key_qp, Phi_full)
    C.put("morphism", key_pq, Phit_full)
    return Phi_full if kind == "q_to_p" else Phit_full







def E_grid_field(ctx, phi_field, generators, *, sign=+1):
    """
    Exponential from a *field* (not from agent): E = exp(sign * φ) under the given generators.
    Uses the same sanitization as E_grid. Accepts φ of shape (..., 3).
    Returns (..., K, K).
    """
    import numpy as np
    from runtime_context import cfg_get
    # sanitize φ to principal ball
    phi = retract_phi_principal(
        np.asarray(phi_field, np.float32),
        margin=1e-4, strict_numerics=True, use_float64=False
    ).astype(np.float32, copy=False)

    if sign not in (+1, -1):
        raise ValueError(f"E_grid_field: sign must be +1 or -1, got {sign!r}")
    if sign == -1:
        phi = -phi

    # validate generators (3, K, K)
    G = np.asarray(generators, np.float32, order="C")
    if not (G.ndim == 3 and G.shape[0] == 3 and G.shape[1] == G.shape[2]):
        raise ValueError(f"E_grid_field: generators must be (3,K,K); got {G.shape}")

    max_norm = float(cfg_get(ctx, "exp_clip_max_norm", 1e4))
    return exp_lie_algebra_irrep(phi, G, max_norm=max_norm)


def Fisher_blocks(ctx, agent, which="q", *, tol=None):
    C = getattr(ctx, "cache", None)
    step_tag = int(getattr(ctx, "global_step", -1))
    Sig = np.asarray(getattr(agent, "sigma_q_field" if which == "q" else "sigma_p_field"),
                     np.float32, order="C")
    if Sig.shape[-1] != Sig.shape[-2]:
        raise ValueError(f"Sigma must be (...,K,K); got {Sig.shape}")

    key = None
    if C is not None:
        sigsig = hashlib.sha1(Sig.view(np.uint8)).hexdigest()  # faster than sha256
        key = ("Fisher_blocks", step_tag, _aid(agent), which, Sig.shape[-1], sigsig, tol)
        cached = C.get("fisher", key)
        if cached is not None:
            return cached

    Sig = 0.5 * (Sig + Sig.swapaxes(-1, -2))

    try:
        L = np.linalg.cholesky(Sig)
    except np.linalg.LinAlgError:
        raise np.linalg.LinAlgError("Σ not SPD even after symmetrization")

    I = np.eye(Sig.shape[-1], dtype=np.float32)
    I_b = np.broadcast_to(I, Sig.shape[:-2] + I.shape).copy()
    X = np.linalg.solve(L, I_b)
    Prec = np.swapaxes(X, -1, -2) @ X
    Prec = 0.5 * (Prec + Prec.swapaxes(-1, -2))

    diagL = np.diagonal(L, axis1=-2, axis2=-1)
    logdet = (2.0 * np.log(np.clip(diagL, 1e-30, None)).sum(axis=-1)).astype(np.float32)

    out = {"precision": Prec.astype(np.float32, copy=False), "logdet": logdet}
    
    if C is not None:
        C.put("fisher", key, out)
    return out







# ---------------------------------------------------------------------------
# Cached dexpinv matrices Jinv(phi)  (SO(3) axis-angle principal ball)
# ---------------------------------------------------------------------------

def build_dexpinv_matrix(
    phi: np.ndarray,
    eps: float = 1e-12,
    *,
    margin: float = 1e-4,     # principal-ball margin (π - margin)
    use_float64: bool = False,
) -> np.ndarray:
    """
    Stable SO(3) right-Jacobian inverse J^{-1}(φ).
    Returns array of shape (..., 3, 3).

    Formula (kept from your convention):
      J^{-1}(φ) = I - (θ/2) ad(u) + (1 - h) ad(u)^2,
      h(θ) = (θ/2) cot(θ/2),  φ = θ u,  ad(u) = [u]_×.
    """
    import numpy as np
    from core.omega import retract_phi_principal
    

    dtype = np.float64 if use_float64 else np.float32

    # ---- validate & retract ----
    phi = np.asarray(phi, dtype=dtype)
    if phi.shape[-1] != 3:
        raise ValueError(f"build_dexpinv_matrix: last dim must be 3, got {phi.shape}")
    phi_r = retract_phi_principal(phi, margin=margin, use_float64=use_float64).astype(dtype, copy=False)

    # ---- axis/angle pieces ----
    th   = np.linalg.norm(phi_r, axis=-1)               # (...,)
    u    = np.divide(phi_r, th[..., None] + eps, dtype=dtype)  # (...,3)

    ux, uy, uz = u[..., 0], u[..., 1], u[..., 2]
    z = np.zeros_like(ux, dtype=dtype)
    adu = np.stack([
        np.stack([ z,  -uz,  uy], axis=-1),
        np.stack([ uz,   z, -ux], axis=-1),
        np.stack([-uy,  ux,   z], axis=-1),
    ], axis=-2).astype(dtype, copy=False)               # (...,3,3)

    # ---- h(θ) = (θ/2) cot(θ/2) with small-θ series ----
    half = 0.5 * th
    small = th < 1e-3
    # series in θ (not half): 1 - θ^2/12 - θ^4/720 + O(θ^6)
    t2 = th * th
    h_series = 1.0 - (t2 / 12.0) - ((t2 * t2) / 720.0)

    # safe half-angle for non-small branch
    half_ns = np.clip(half, 1e-6, np.pi/2 - 1e-6)
    h_closed = half_ns / np.tan(half_ns)

    # piecewise combine without extra passes
    h = np.where(small, h_series, h_closed)

    # ---- build J^{-1} ----
    I = np.eye(3, dtype=dtype)
    uuT  = u[..., :, None] * u[..., None, :]           # (...,3,3)
    adu2 = (uuT - I)                                   # (...,3,3)

    Jinv = I - half[..., None, None] * adu + (1.0 - h)[..., None, None] * adu2
    if not np.all(np.isfinite(Jinv)):
        raise FloatingPointError("build_dexpinv_matrix produced non-finite values")

    return Jinv.astype(np.float32, copy=False)






#==============================================================================
#
#
#
#==============================================================================




def _intertwining_resid(G_left, G_right, X):
    """
    Residual || G_left[a] X - X G_right[a] ||_F summed over a=0..2.
    Shapes: G_left(Kout,Kout,3), G_right(Kin,Kin,3), X(Kout,Kin)
    """
    
    X  = np.asarray(X, np.float32)
    Kout = G_left.shape[0]; Kin = G_right.shape[0]
    if X.shape != (Kout, Kin):
        raise ValueError(f"X has shape {X.shape}, expected {(Kout, Kin)}")
    r = 0.0
    for a in range(3):
        r += float(np.linalg.norm(G_left[..., a] @ X - X @ G_right[..., a]))
    return r



#==============================================================================
#
#                  Gauge Curvature
#
#==============================================================================

def _roll2(a, shift, *, boundary="periodic"):
    """
    Shift (H, W) axes by (di, dj) with either periodic wrap or clamp-to-edge.
    Assumes a has shape (..., H, W, K, K); shifts along axes -4 (H) and -3 (W).
    """
    di, dj = int(shift[0]), int(shift[1])

    if boundary == "periodic":
        return np.roll(np.roll(a, di, axis=-4), dj, axis=-3)

    # ---- clamp-to-edge (match np.roll direction) ----
    out = a

    if di != 0:
        H = out.shape[-4]
        if di > 0:
            # shift DOWN by di: top di rows are filled with first row
            top = np.repeat(out[..., :1, :, :, :], di, axis=-4)
            out = np.concatenate([top, out[..., :H - di, :, :, :]], axis=-4)
        else:
            di = -di
            # shift UP by di: bottom di rows are filled with last row
            bottom = np.repeat(out[..., -1:, :, :, :], di, axis=-4)
            out = np.concatenate([out[..., di:, :, :, :], bottom], axis=-4)

    if dj != 0:
        W = out.shape[-3]
        if dj > 0:
            # shift RIGHT by dj: left dj cols filled with first col
            left = np.repeat(out[..., : , :1, :, :], dj, axis=-3)
            out = np.concatenate([left, out[..., :, :W - dj, :, :]], axis=-3)
        else:
            dj = -dj
            # shift LEFT by dj: right dj cols filled with last col
            right = np.repeat(out[..., :, -1:, :, :], dj, axis=-3)
            out = np.concatenate([out[..., :, dj:, :, :], right], axis=-3)

    return out


def plaquette_product(ctx, phi_field, generators, *, boundary="periodic",
                      split_edge=False, sign=+1):
    """
    P(i,j) = Ux(i,j) · Uy(i+1,j) · Ux(i,j+1)^T · Uy(i,j)^T
    phi_field: (..., H, W, 3)
    generators: (3,K,K) or (K,K,3)
    Returns: (..., H, W, K, K)
    """
    import numpy as np

    # Accept either layout; normalize to (3,K,K)
    G = np.asarray(generators, np.float32)
    if G.ndim != 3:
        raise ValueError(f"generators must be rank-3, got {G.shape}")
    if G.shape[0] == 3:
        G3 = G
    elif G.shape[-1] == 3 and G.shape[0] == G.shape[1]:
        G3 = np.moveaxis(G, -1, 0)  # (K,K,3) -> (3,K,K)
    else:
        raise ValueError(f"bad generators shape {G.shape}; expected (3,K,K) or (K,K,3)")

    # Site exponentials (orthonormal reps => inverse = transpose)
    E  = E_grid_field(ctx, phi_field, G3, sign=sign)   # (..., H, W, K, K)
    Et = np.swapaxes(E, -1, -2)

    if not split_edge:
        E_right = _roll2(E, (0, +1), boundary=boundary)  # (i, j+1)
        E_down  = _roll2(E, (+1, 0), boundary=boundary)  # (i+1, j)
        Ux_ij = np.matmul(E_down,  Et)
        Uy_ij = np.matmul(E_right, Et)
        Ux_i_j1 = _roll2(Ux_ij, (0, +1), boundary=boundary)
        Uy_i1_j = _roll2(Uy_ij, (+1, 0), boundary=boundary)
    else:
        half = 0.5
        Ehalf_here  = E_grid_field(ctx, half*phi_field, G3, sign=sign)
        Ehalf_right = _roll2(Ehalf_here, (0, +1), boundary=boundary)
        Ehalf_down  = _roll2(Ehalf_here, (+1, 0), boundary=boundary)
        Eh_t = np.swapaxes(Ehalf_here, -1, -2)
        Ux_ij = np.matmul(Ehalf_down,  Eh_t)
        Uy_ij = np.matmul(Ehalf_right, Eh_t)
        Ux_i_j1 = _roll2(Ux_ij, (0, +1), boundary=boundary)
        Uy_i1_j = _roll2(Uy_ij, (+1, 0), boundary=boundary)

    P = Ux_ij @ Uy_i1_j @ np.swapaxes(Ux_i_j1, -1, -2) @ np.swapaxes(Uy_ij, -1, -2)
    return P.astype(np.float32, copy=False)


def curvature_plaquette(ctx, phi_field, generators, *,
                        boundary="periodic",
                        split_edge=False,
                        metric="fro",
                        return_P=False):
    """
    Gauge-invariant lattice curvature from 1×1 plaquettes.

    metric:
      - 'fro'  : 0.5 * ||I - P||_F^2  (cheap; ~ ||log P||^2 near identity)
      - 'angle': θ^2, where θ is principal rotation angle (K==3 only; else falls back to 'fro')
    """
    P = plaquette_product(ctx, phi_field, generators,
                          boundary=boundary, split_edge=split_edge, sign=+1)
    K  = P.shape[-1]
    IK = np.eye(K, dtype=P.dtype)

    if metric == "fro":
        D = P - IK
        curv = 0.5 * np.sum(D * D, axis=(-1, -2))
    elif metric == "angle":
        if K != 3:
            D = P - IK
            curv = 0.5 * np.sum(D * D, axis=(-1, -2))
        else:
            tr = np.trace(P, axis1=-2, axis2=-1)
            x  = np.clip((tr - 1.0) * 0.5, -1.0 + 1e-6, 1.0 - 1e-6)
            theta = np.arccos(x)
            curv = theta * theta
    else:
        raise ValueError(f"curvature_plaquette: unknown metric '{metric}'")

    curv = curv.astype(np.float32, copy=False)
    return (curv, P) if return_P else curv







# ---------------------------------------------------------------------------
# Bundle morphisms (same-level) and cross-scale morphisms (Θ)
# Cached per-step in "morphism" and "theta" namespaces
# ---------------------------------------------------------------------------



def _broadcast_morphism_template(M, target_tail, lead_shape):
    M = np.asarray(M, np.float32)
    if M.shape[-2:] != tuple(target_tail):
        raise ValueError(f"[transport_cache] Bad morphism base shape {M.shape}, expected {tuple(target_tail)}")
    if M.ndim == 2:
        M = np.broadcast_to(M, tuple(lead_shape) + tuple(target_tail))
    return M



def _build_morphisms_with_cache(ctx, agent, Phi_0, Phi_tilde_0):
    """
    Build Φ and Φ̃ using the central E_grid cache.
      Φ   = E_p · Φ₀ · (E_q)^{-1}
      Φ̃  = E_q · Φ̃₀ · (E_p)^{-1}
    """
    
    E_q = E_grid(ctx, agent, which="q").astype(np.float64, copy=False)
    E_p = E_grid(ctx, agent, which="p").astype(np.float64, copy=False)

    Kq = int(E_q.shape[-1]); Kp = int(E_p.shape[-1])
    lead = np.broadcast_shapes(E_q.shape[:-2], E_p.shape[:-2])

    Phi_0       = _broadcast_morphism_template(Phi_0,       (Kp, Kq), lead)
    Phi_tilde_0 = _broadcast_morphism_template(Phi_tilde_0, (Kq, Kp), lead)

        # Compute true inverse, then transpose
    E_q_inv   = safe_omega_inv(E_q)              # (...,Kq,Kq)
    E_p_inv   = safe_omega_inv(E_p)              # (...,Kp,Kp)
    
    # Compose using inverse-transpose convention
    Phi       = np.einsum("...ik,...kj,...jl->...il", E_p, Phi_0,       E_q_inv, optimize=True)
    Phi_tilde = np.einsum("...ik,...kj,...jl->...il", E_q, Phi_tilde_0, E_p_inv, optimize=True)

    if not (np.isfinite(Phi).all() and np.isfinite(Phi_tilde).all()):
        raise FloatingPointError("[transport_cache] Nonfinite Φ/Φ̃ after build.")

    return Phi.astype(np.float32, copy=False), Phi_tilde.astype(np.float32, copy=False)




# ---------------------------------------------------------------------------
# Warming & invalidation
# ---------------------------------------------------------------------------

def warm_E(ctx: Any, agents: Sequence[Any], whiches: Iterable[str] = ("q", "p")) -> None:
    for a in agents:
        for w in whiches:
            try:
                _ = E_grid(ctx, a, which=w)
            except Exception as e:
                print(f"warm-e fail ({getattr(a,'id',None)} {w}): {type(e).__name__}: {e}")


def warm_Jinv(ctx: Any, agents: Sequence[Any], whiches: Iterable[str] = ("q", "p")) -> None:
    """Precompute Jinv for many agents (idempotent)."""
    for a in agents:
        for w in whiches:
            try:
                _ = Jinv_grid(ctx, a, which=w)
            except Exception:
                print("warm-jinv fail ")





def _digest_array(a: np.ndarray, tol: float = 0.0) -> str:
    a = np.asarray(a)
    if tol > 0:
        a = np.round(a / tol) * tol
    h = hashlib.sha256()
    h.update(str(a.shape).encode())
    h.update(a.tobytes(order="C"))
    return h.hexdigest()


def _identity_field(ai, which: str) -> np.ndarray:
    if which == "q":
        H, W, K = np.asarray(ai.mu_q_field).shape
    else:
        H, W, K = np.asarray(ai.mu_p_field).shape
    I = np.eye(K, dtype=np.float32)
    return np.broadcast_to(I, (H, W, K, K)).copy()

def _gens_digest(Gq, Gp) -> str:
        
    Gq = np.round(Gq, 9)
    Gp = np.round(Gp, 9)
    h = hashlib.sha256()
    h.update(Gq.tobytes()); h.update(b"|"); h.update(Gp.tobytes())
    return h.hexdigest()


def _gensig(G: np.ndarray) -> tuple[int, str]:
    return (int(G.shape[0]), hashlib.sha256(G.tobytes()).hexdigest())

def _aid(a: Any) -> int:
    """Stable agent id (required)."""
    aid = getattr(a, "id", None)
    if aid is None:
        raise ValueError("[transport_cache] agent is missing a stable `id`")
    return int(aid)

