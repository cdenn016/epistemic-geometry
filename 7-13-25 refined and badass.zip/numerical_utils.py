# -*- coding: utf-8 -*-
"""
Created on Sun Jul 13 13:06:16 2025

@author: chris and christine
"""

# numerical_utils.py
import numpy as np
import config
from joblib import Parallel, delayed

def _sanitize_one_sigma(S, eps=1e-6):
    """
    Sanitize a single covariance matrix to ensure it's symmetric positive-definite (SPD).

    Returns:
        (S_sanitized, clipped): sanitized matrix and boolean flag indicating if it was modified
    """
    S = 0.5 * (S + S.T)  # ensure symmetry

    # First line of defense: handle invalid or pathological cases
    if not np.all(np.isfinite(S)) or np.trace(S) < eps or np.any(np.diag(S) <= 0):
        return np.eye(S.shape[0]) * eps, True

    try:
        eigvals, eigvecs = np.linalg.eigh(S)
    except np.linalg.LinAlgError:
        return np.eye(S.shape[0]) * eps, True

    clipped = np.any(eigvals < eps)
    eigvals_clipped = np.clip(eigvals, eps, None)

    if clipped:
        S = eigvecs @ np.diag(eigvals_clipped) @ eigvecs.T
        S = 0.5 * (S + S.T)  # re-symmetrize

    return S, clipped


def sanitize_sigma(Sigma, eps=1e-6, debug=False, n_jobs=None, parallel_threshold=50):
    """
    Sanitize a batch of covariance matrices to ensure SPD.

    Parameters:
        Sigma: (..., K, K) ndarray — batch of covariances
        eps: minimum eigenvalue threshold
        debug: if True, prints a summary if any matrices are clipped
        n_jobs: number of parallel workers (default: config.num_cores or 1)
        parallel_threshold: min number of matrices before enabling parallelization

    Returns:
        Sanitized SPD matrices with same shape as input.
    """
    shape = Sigma.shape
    flat_sigma = Sigma.reshape(-1, shape[-2], shape[-1])
    n_total = flat_sigma.shape[0]
    n_jobs = n_jobs or getattr(config, "num_cores", 1)

    if n_total < parallel_threshold or n_jobs == 1:
        results = [_sanitize_one_sigma(S, eps) for S in flat_sigma]
    else:
        from joblib import parallel_backend
        with parallel_backend("threading"):
            results = Parallel(n_jobs=n_jobs)(
                delayed(_sanitize_one_sigma)(S, eps) for S in flat_sigma
            )

    Sigma_out, clipped_flags = zip(*results)
    if debug:
        n_clipped = sum(clipped_flags)
        if n_clipped > 0:
            print(f"[SPD sanitize] Clipped {n_clipped} / {n_total} matrices to eps={eps:.1e}")

    out = np.stack(Sigma_out, axis=0).astype(Sigma.dtype).reshape(shape)
    return out

def check_matrix_validity(S, eps=1e-6):
    eigvals = np.linalg.eigvalsh(S)
    return np.all(np.isfinite(S)) and np.all(eigvals > eps)


def safe_inv(Sigma, eps=1e-8, fallback_identity=True):
    K = Sigma.shape[-1]
    try:
        return np.linalg.inv(Sigma + eps * np.eye(K))
    except np.linalg.LinAlgError:
        if fallback_identity:
            return np.eye(K) * config.sanitize_fallback_value
        raise

def safe_logdet(Sigma, eps=1e-8):
    K = Sigma.shape[-1]
    try:
        sign, logdet = np.linalg.slogdet(Sigma + eps * np.eye(K))
        return logdet if sign > 0 else 0.0
    except Exception:
        return 0.0

def condition_check_and_fallback(sigma, max_cond=1e6):
    K = sigma.shape[-1]
    try:
        cond = np.linalg.cond(sigma)
        if not np.isfinite(cond) or cond > max_cond:
            raise np.linalg.LinAlgError
        return sigma
    except np.linalg.LinAlgError:
        return np.eye(K) * config.sanitize_fallback_value

def is_bad_matrix(S):
    try:
        eigs = np.linalg.eigvalsh(S)
        return (not np.all(np.isfinite(eigs))) or np.min(eigs) <= 0
    except Exception:
        return True