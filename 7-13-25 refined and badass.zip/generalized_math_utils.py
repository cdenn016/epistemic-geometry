import numpy as np
from scipy.ndimage import laplace

import matplotlib.pyplot as plt
from scipy.stats import linregress

import config

def clip_and_mask_gradient(grad, soft_mask, clip_threshold, support_eps, return_norm=False):
    support_mask = soft_mask[..., 0] > support_eps
    masked_grad = grad[support_mask]
    norm = np.linalg.norm(masked_grad)

    if norm > clip_threshold:
        scaling = clip_threshold / (norm + 1e-8)
        grad[support_mask] *= scaling

    grad *= soft_mask
    return (grad, norm) if return_norm else grad


def unpack_phi_update_params(params, field="phi"):
    prefix = "phi_model" if field == "phi_model" else "phi"

    return dict(
        gw=params.get(f"{field}_mass_weight", getattr(config, f"{prefix}_mass_weight", config.gauge_weight)),
        κ=params.get("phi_phi_tilde_coupling", config.phi_phi_tilde_coupling),
        curv_weight=params.get(f"{field}_curvature_weight", getattr(config, f"{prefix}_curvature_weight", config.curvature_weight)),
        grad_clip_threshold=params.get(f"{field}_grad_clip_threshold", getattr(config, f"{prefix}_grad_clip_threshold", config.phi_grad_clip_threshold)),
        overlap_eps=params.get("support_cutoff_eps", config.support_cutoff_eps),
        debug=params.get("debug", getattr(config, "debug_gradients", False)),
    )


def apply_regularization_terms(
    grad,
    phi,
    phi_tilde=None,
    Gs=None,
    soft_mask=None,
    *,
    gw=0.0,
    κ=0.0,
    curv_weight=0.0,
    curvature_fn=None,
):
    if gw > 0:
        grad += 2 * gw * phi * soft_mask
    if κ > 0 and phi_tilde is not None:
        grad += 2 * κ * (phi - phi_tilde) * soft_mask
    if curv_weight > 0 and curvature_fn is not None and Gs is not None:
        grad += curv_weight * curvature_fn(phi, Gs) * soft_mask
    return grad

def finalize_phi_gradient(grad, soft_mask, clip_threshold, support_eps, return_norm=False):
    grad = clip_and_mask_gradient(grad, soft_mask, clip_threshold, support_eps, return_norm=return_norm)
    return grad



def mvg_mahalanobis(mu1, sigma1, mu2, sigma2, eps=1e-8):
    """
    Mahalanobis distance between two Gaussians (centered at μ1, Σ1) and (μ2, Σ2)
    """
    diff = mu2 - mu1
    try:
        sigma_inv = np.linalg.inv(sigma1 + eps * np.eye(sigma1.shape[0]))
    except np.linalg.LinAlgError:
        sigma_inv = np.linalg.pinv(sigma1 + eps * np.eye(sigma1.shape[0]))
    return float(np.sqrt(diff.T @ sigma_inv @ diff))



def finite_difference(field, axis: int, mode="central"):
    """
    Compute finite difference ∂field/∂x[axis] with optional boundary mode.

    Parameters:
        field: ndarray (..., d) — field to differentiate
        axis: int — spatial axis
        mode: 'central' | 'forward' | 'backward'

    Returns:
        ∂field/∂xᵃ with same shape as input
    """
    if mode == "central":
        rolled_forward = np.roll(field, -1, axis=axis)
        rolled_backward = np.roll(field, 1, axis=axis)
        diff = (rolled_forward - rolled_backward) / 2.0
    elif mode == "forward":
        rolled = np.roll(field, -1, axis=axis)
        diff = rolled - field
    elif mode == "backward":
        rolled = np.roll(field, 1, axis=axis)
        diff = field - rolled
    else:
        raise ValueError(f"Unknown mode '{mode}' in finite_difference")

    return diff


from numerical_utils import sanitize_sigma, safe_inv, safe_logdet

def kl_divergence(mu1, sigma1, mu2, sigma2, log_eps=1e-6):
    """
    Batched KL[𝒩(μ₁, Σ₁) || 𝒩(μ₂, Σ₂)] for full MVG (μ, Σ) fields.
    Uses sanitization and fallback for numerical robustness.

    Parameters:
        mu1:    (N, K)
        sigma1: (N, K, K)
        mu2:    (N, K)
        sigma2: (N, K, K)

    Returns:
        kl_vals: (N,) KL divergence values
    """
    N, K = mu1.shape
    eye = np.eye(K, dtype=mu1.dtype)

    # Sanitize Σ fields
    sigma1 = sanitize_sigma(sigma1, eps=log_eps)
    sigma2 = sanitize_sigma(sigma2, eps=log_eps)

    # Inverse and determinants
    sigma2_inv = np.array([safe_inv(S, eps=log_eps) for S in sigma2])
    logdet1 = np.array([safe_logdet(S, eps=log_eps) for S in sigma1])
    logdet2 = np.array([safe_logdet(S, eps=log_eps) for S in sigma2])

    # Trace term: Tr[Σ₂⁻¹ Σ₁]
    trace_term = np.einsum("nij,njk->nik", sigma2_inv, sigma1)
    trace_term = np.trace(trace_term, axis1=-2, axis2=-1)  # (N,)

    # Mahalanobis term: (μ₂ − μ₁)^T Σ₂⁻¹ (μ₂ − μ₁)
    diff = mu2 - mu1
    mahal = np.einsum("ni,nij,nj->n", diff, sigma2_inv, diff)

    kl = 0.5 * (trace_term + mahal - K + logdet2 - logdet1)
    return kl


def laplacian_field(field):
    """Compute component‐wise Laplacian over the last (fiber) axis."""
    return np.stack([laplace(field[..., i]) for i in range(field.shape[-1])], axis=-1)

def masked_norm(field, mask, ord=2):
    """
    Compute the mean over support of ‖field(x)‖ᵒʳᵈ, i.e.
      ∑ₓ ‖field(x)‖ * mask(x)  /  (∑ₓ mask(x))
    """
    norm_vals = np.linalg.norm(field, ord=ord, axis=-1)
    return np.sum(norm_vals * mask) / (np.sum(mask) + 1e-9)

def safe_log(x, eps: float = 1e-12):
    """
    Numerically stable natural log.

    Parameters
    ----------
    x : float | np.ndarray
        Input value(s). Can be scalar or array-like.
    eps : float, optional
        Values below `eps` are clipped up to `eps` before taking log,
        preventing -inf.  Default is 1e-12.

    Returns
    -------
    np.ndarray | float
        np.log( max(x, eps) ), broadcast over x.
    """
    return np.log(np.clip(x, eps, None))


def reconstruct_density_from_mu_sigma(mu_field, sigma_field):
    """
    Evaluate MVN density q(c) at representative fiber locations.
    Output: array of shape (H, W, K) — approximate marginal over fiber index k.
    """
    from scipy.stats import multivariate_normal

    H, W, K = mu_field.shape
    q = np.zeros((H, W, K), dtype=np.float32)

    # Evaluate at K fiber-representative points: each k-th index as constant vector
    x = np.array([[k] * K for k in range(K)])  # shape (K, K)

    for i in range(H):
        for j in range(W):
            mu = mu_field[i, j]
            Sigma = sigma_field[i, j]

            if not np.all(np.isfinite(Sigma)) or np.linalg.det(Sigma) <= 0:
                continue

            try:
                mvn = multivariate_normal(mean=mu, cov=Sigma, allow_singular=False)
                pdf_vals = mvn.pdf(x)
                pdf_vals = np.clip(pdf_vals, 1e-12, None)
                q[i, j, :] = pdf_vals / pdf_vals.sum()
            except Exception:
                continue

    return q




def condition_check_and_fallback(sigma, max_cond=1e6):
    try:
        cond = np.linalg.cond(sigma)
        if not np.isfinite(cond) or cond > max_cond:
            raise np.linalg.LinAlgError
        return sigma
    except np.linalg.LinAlgError:
        return np.eye(sigma.shape[-1]) * config.sigma_outside_mask_value


def rank_frequency_plot(freqs, ax=None, **kwargs):
    """
    Plot a rank-frequency curve. Accepts optional matplotlib kwargs.

    Args:
        freqs: frequency array (should already be sorted descending)
        ax: optional matplotlib axis

    Returns:
        ax: the axis with the plot
    """
    if ax is None:
        ax = plt.gca()
    ranks = np.arange(1, len(freqs) + 1)
    ax.loglog(ranks, freqs, marker='o', linestyle='', **kwargs)
    ax.set_xlabel("Rank")
    ax.set_ylabel("Frequency")
    return ax


def fit_moments(q: np.ndarray, mask: np.ndarray):
    """
    Compute the per-pixel mean and full covariance matrices
    for a multivariate distribution q(c) over K-dimensional fibers.

    Parameters:
      q:     ndarray of shape (H, W, K) — belief distribution at each pixel
      mask:  ndarray of shape (H, W) — boolean or float mask for agent support

    Returns:
      mu:    ndarray of shape (H, W, K) — mean vector per spatial point
      cov:   ndarray of shape (H, W, K, K) — covariance matrix per spatial point
    """
    H, W, K = q.shape
    x = np.eye(K, dtype=q.dtype)          # (K, K)
    x_exp = x[None, None, :, :]           # (1, 1, K, K)
    q_exp = q[..., :, None]               # (H, W, K, 1)

    # μ = E[x]
    mu = np.sum(q_exp * x_exp, axis=2)    # (H, W, K)

    # x_k - μ for each k: (H, W, K, K)
    diff = x_exp - mu[:, :, None, :]      # (H, W, K, K)

    # Outer product: (x_k - μ)(x_k - μ)^T → (H, W, K, K, K)
    outer = diff[..., :, None] * diff[..., None, :]  # (H, W, K, K, K)

    # Weight by q_k and sum over k
    q_reshaped = q[..., :, None, None]    # (H, W, K, 1, 1)
    cov = np.sum(q_reshaped * outer, axis=2)  # (H, W, K, K)

    mu[~mask] = 0.0
    cov[~mask] = 0.0

    return mu, cov

import numpy as np
from numpy.linalg import LinAlgError

def is_spd_matrix(A: np.ndarray, tol=1e-8) -> bool:
    """
    Check whether a matrix A is symmetric positive definite (SPD).
    """
    if not np.allclose(A, A.T, atol=tol):
        return False
    try:
        np.linalg.cholesky(A)
        return True
    except LinAlgError:
        return False

import numpy as np
import networkx as nx


#TRANSPORT ONLY??
def compute_overlap_volume(mask_i, mask_j, threshold=1e-5):
    overlap = mask_i * mask_j
    return np.sum(overlap > threshold)

#HOLONOMY
def build_overlap_graph(agents, support_cutoff_eps):
    G = nx.Graph()
    N = len(agents)
    G.add_nodes_from(range(N))

    for i in range(N):
        mask_i = agents[i].mask
        for j in range(i + 1, N):
            mask_j = agents[j].mask
            overlap = (mask_i * mask_j) > support_cutoff_eps
            if np.any(overlap):
                weight = np.sum(mask_i * mask_j)
                G.add_edge(i, j, weight=weight)

    return G

#ONLY TRANSPORT??
def build_overlap_graph_with_weights(agents, support_cutoff_eps):
    G = nx.Graph()
    N = len(agents)
    G.add_nodes_from(range(N))

    for i in range(N):
        for j in range(i + 1, N):
            vol = compute_overlap_volume(agents[i].mask, agents[j].mask, support_cutoff_eps)
            if vol > 0:
                G.add_edge(i, j, weight=1.0 / (vol + 1e-8), volume=vol)

    return G


#HOLONOMY
def find_agent_chain(agents, start_id, end_id, support_cutoff_eps):
    G = build_overlap_graph(agents, support_cutoff_eps)
    try:
        path = nx.shortest_path(G, start_id, end_id)
        return path
    except nx.NetworkXNoPath:
        return None



#HOLONOMY
def get_wrapped_position(p1, p2, domain_size):
    return np.array([
        p2[d] - p1[d] - domain_size[d] * round((p2[d] - p1[d]) / domain_size[d])
        for d in range(len(domain_size))
    ])




#HOLONOMY
def get_overlap_centroid(agent_a, agent_b, domain_size, support_cutoff_eps=1e-3):
    mask_a = agent_a.mask > support_cutoff_eps
    mask_b = agent_b.mask > support_cutoff_eps

    # Sanity check: ensure masks match spatial dimension
    if mask_a.ndim != len(domain_size):
        raise ValueError(
            f"Agent mask dimension ({mask_a.ndim}) does not match domain size ({len(domain_size)})"
        )

    overlap = mask_a & mask_b
    if not np.any(overlap):
        return None
    #print(f"[DEBUG] mask_a.shape = {mask_a.shape}, mask_b.shape = {mask_b.shape}")

    coords = np.array(np.nonzero(overlap)).T  # shape (N, D)
    centroid = np.mean(coords, axis=0)        # shape (D,)
    discrete_centroid = np.round(centroid).astype(int)
    wrapped_centroid = tuple(discrete_centroid[d] % domain_size[d] for d in range(len(domain_size)))
    return wrapped_centroid



#ONLY TRANSPORT>>??
def find_candidate_paths(agents, start_id, end_id, d, domain_size, support_cutoff_eps=1e-5):
    G = build_overlap_graph_with_weights(agents, support_cutoff_eps)

    try:
        all_paths = list(nx.all_simple_paths(G, source=start_id, target=end_id, cutoff=d + 1))
    except nx.NetworkXNoPath:
        return [], None, None, None

    candidate_paths = [p for p in all_paths if len(p) == d + 2]
    if not candidate_paths:
        return [], None, None, None

    def path_weight(path):
        return sum(G[u][v]['weight'] for u, v in zip(path[:-1], path[1:]))

    candidate_paths.sort(key=path_weight, reverse=True)

    best_path = candidate_paths[0]
    start_point = tuple(agents[start_id].center)
    end_point = tuple(agents[end_id].center)

    overlap_points = []
    for u, v in zip(best_path[:-1], best_path[1:]):
        point = get_overlap_centroid(agents[u], agents[v], domain_size, support_cutoff_eps)
        overlap_points.append(point)

    return best_path, start_point, end_point, overlap_points




#HOLONOMY
def construct_spatial_path_nd(start, end, domain_size, mask=None):
    """
    Constructs a path of discrete coordinates from `start` to `end` in ND space.

    Parameters:
        start (tuple): Starting coordinates (e.g., (x, y, ...) in ND).
        end (tuple): Ending coordinates.
        domain_size (tuple): Spatial domain shape for periodic boundary handling.
        mask (ndarray or None): Optional support mask to constrain the path.

    Returns:
        path (list of tuples): Discrete coordinate path from start to end.
    """
    start = np.array(start)
    end = np.array(end)
    domain_size = np.array(domain_size)
    delta = end - start

    # Apply minimal image convention (periodic wrap)
    delta = (delta + domain_size // 2) % domain_size - domain_size // 2
    steps = int(np.max(np.abs(delta)))
    if steps == 0:
        return [tuple(start)]

    path = []
    for t in np.linspace(0, 1, steps + 1):
        point = start + t * delta
        coord = tuple(np.round(point).astype(int) % domain_size)
        if mask is None or mask[coord] > 0:
            if not path or path[-1] != coord:
                path.append(coord)

    return path

import itertools



#HOLONOMY
def build_agent_graph(agents, support_cutoff_eps=config.support_cutoff_eps):
    """
    Build an undirected adjacency list for agents based on non-empty overlaps.
    Returns: dict mapping agent_id -> set(neighbor_ids)
    """
    N = len(agents)
    graph = {i: set() for i in range(N)}
    for i, j in itertools.combinations(range(N), 2):
        # reuse your existing overlap check
        c = get_overlap_centroid(agents[i], agents[j], config.domain_size, support_cutoff_eps)
        if c is not None:
            graph[i].add(j)
            graph[j].add(i)
    return graph


#HOLONOMY
def find_simple_cycles(graph, max_length=None):
    """
    Find all simple (no repeated nodes except start=end) cycles in an undirected graph.
    - graph: {node: set(neighbors)}
    - max_length: maximum cycle length (including return edge)
    Returns: list of cycles as lists [n0, n1, ..., n0].
    """
    # Build directed graph with bidirectional edges
    G = nx.DiGraph()
    for u, nbrs in graph.items():
        for v in nbrs:
            G.add_edge(u, v)

    cycles = []
    for cyc in nx.simple_cycles(G):
        # cycle comes as [n0, n1, ..., nk], implicitly closed n0→nk
        if len(cyc) < 3:
            continue
        if max_length and (len(cyc) + 1) > max_length:
            continue

        # close the cycle
        closed = cyc + [cyc[0]]
        # rotate so the smallest node is first
        i0 = min(range(len(cyc)), key=lambda i: closed[i])
        norm = tuple(closed[i0:-1] + closed[:i0] + [closed[i0]])
        cycles.append(norm)

    # remove exact duplicates and sort
    unique = sorted(set(cycles), key=lambda c: (len(c), c))
    return unique

#USED FOR HOLONOMY
def get_agent_cycles(agents, max_length=None):
    """
    Build overlap graph and return all simple closed chains up to max_length.
    """
    graph = build_agent_graph(agents)
    return find_simple_cycles(graph, max_length=max_length)
