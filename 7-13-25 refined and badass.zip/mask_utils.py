# mask_utils.py
import numpy as np
import config

def get_support_mask(mask: np.ndarray, eps: float = None) -> np.ndarray:
    """Boolean mask where agent has support (soft mask > eps)"""
    if eps is None:
        eps = config.support_cutoff_eps
    return mask > eps

def expand_mask_for_mu(mask: np.ndarray) -> np.ndarray:
    """Expands (H, W) mask to (H, W, 1) for μ fields"""
    return mask[..., None]

def expand_mask_for_sigma(mask: np.ndarray) -> np.ndarray:
    """Expands (H, W) mask to (H, W, 1, 1) for Σ fields"""
    return mask[..., None, None]

def apply_mask_mu(mu_field: np.ndarray, mask: np.ndarray) -> np.ndarray:
    """Apply support mask to μ field"""
    return mu_field * expand_mask_for_mu(mask)

def apply_mask_sigma(sigma_field: np.ndarray, mask: np.ndarray) -> np.ndarray:
    """Apply support mask to Σ field"""
    return sigma_field * expand_mask_for_sigma(mask)

def norm_over_mask(field: np.ndarray, mask: np.ndarray) -> float:
    """Compute mean norm of field over support mask."""
    norm_vals = np.linalg.norm(field, axis=-1)
    mask_vals = get_support_mask(mask)
    return np.sum(norm_vals * mask_vals) / (np.sum(mask_vals) + 1e-8)

def threshold_mask(mask: np.ndarray, eps: float = None) -> np.ndarray:
    """Alias for get_support_mask for compatibility."""
    return get_support_mask(mask, eps)

def apply_mask_phi(phi_field: np.ndarray, mask: np.ndarray) -> np.ndarray:
    """Apply support mask to φ or φ̃ fields"""
    return phi_field * expand_mask_for_mu(mask)