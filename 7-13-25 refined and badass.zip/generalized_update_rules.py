# -*- coding: utf-8 -*-
"""
Created on Sat Jul 12 15:59:56 2025

@author: chris and christine
"""

# === generalized_update_rules.py (refactor patch) ===
import numpy as np
import config
from joblib import Parallel, delayed

from natural_gradient_utils import (
    apply_natural_gradient_batch,
    apply_lie_natural_gradient,
    sanitize_sigma, compute_inverse_fisher_field
)
from generalized_diagnostics_metrics import compute_alignment_kl, compute_model_alignment_kl

from generalized_update_terms import (
    combine_field_gradients,
    
    compute_phi_alignment_gradient,
    compute_phi_model_update,
)
from generalized_omega import exp_lie_algebra_irrep

from scipy.linalg import solve_triangular  # or np.linalg.solve per batch

def batch_matrix_inverse(mat_batch):
    """
    Solve X = A⁻¹ using A·X = I for a batch of (N, K, K) matrices.
    """
    N, K, _ = mat_batch.shape
    I = np.eye(K)[None, :, :]
    return np.linalg.solve(mat_batch, np.broadcast_to(I, (N, K, K)))

def safe_batch_inverse(S, name="Σ", mask=None):
    """
    Inverts (H, W, K, K) SPD field with fallback and optional mask.
    """
    H, W, K, _ = S.shape
    eye_K = np.eye(K, dtype=S.dtype)
    inv_S = np.zeros_like(S)

    flat_S = S.reshape(-1, K, K)
    flat_mask = mask.reshape(-1) if mask is not None else np.ones(H * W, dtype=bool)

    for idx in range(H * W):
        if not flat_mask[idx]:
            inv_S.reshape(-1, K, K)[idx] = eye_K
            continue
        try:
            inv_S.reshape(-1, K, K)[idx] = np.linalg.inv(flat_S[idx])
        except np.linalg.LinAlgError:
            inv_S.reshape(-1, K, K)[idx] = eye_K
            if config.debug:
                i, j = divmod(idx, W)
                print(f"[WARN] Inversion failed at ({i},{j}) for {name} — using identity")

    return inv_S



def preprocess_agent_fields(agent, generators, params):
    """Sanitize sigmas, cache Fisher info, compute exp(φ), exp(−φ)"""
    e_belief = params.get("e_belief", config.e_belief)
    e_model  = params.get("e_model",  config.e_model)

    agent.clear_omega_cache()
    agent.grid_shape = agent.phi.shape[:-1]

    flat_phi       = agent.phi.reshape(-1, agent.phi.shape[-1]) / e_belief
    flat_phi_model = agent.phi_model.reshape(-1, agent.phi_model.shape[-1]) / e_model

    agent._exp_phi        = exp_lie_algebra_irrep(flat_phi, generators)
    agent._exp_phi_model  = exp_lie_algebra_irrep(flat_phi_model, generators)
    agent._exp_neg_phi       = batch_matrix_inverse(agent._exp_phi)
    agent._exp_neg_phi_model = batch_matrix_inverse(agent._exp_phi_model)

    # Sanitize covariance fields
    agent.sigma_q_field = sanitize_sigma(agent.sigma_q_field, eps=config.eps, debug=config.debug_sanitize_sigma)
    agent.sigma_p_field = sanitize_sigma(agent.sigma_p_field, eps=config.eps, debug=config.debug_sanitize_sigma)

    agent.cached_fisher_q = safe_batch_inverse(agent.sigma_q_field, name="σ_q")
    agent.cached_fisher_p = safe_batch_inverse(agent.sigma_p_field, name="σ_p")





def compute_all_gradients(i, agents, params):
    ai = agents[i]
    return (
        combine_field_gradients(ai, agents, params, field_type="belief"),  # now returns Δμ_q, ΔΣ_q
        combine_field_gradients(ai, agents, params, field_type="model"),   # now returns Δμ_p, ΔΣ_p
        compute_phi_alignment_gradient(ai, agents, params),
        compute_phi_model_update(ai, agents, params),
    )


# --- Shared η scaling helper ---
def compute_adaptive_eta(base_eta, grad, cached_kl, sigma_field, scaling_kl, scaling_cond, eta_min):
    """
    Computes adaptive step size η based on KL alignment and condition number of Σ.
    """
    kl_term = (
        np.mean(cached_kl)
        if cached_kl is not None and np.isfinite(np.mean(cached_kl))
        else np.mean(np.abs(grad))
    )

    try:
        conds = np.linalg.cond(sigma_field.reshape(-1, sigma_field.shape[-2], sigma_field.shape[-1]))
        cond_avg = np.mean(conds)
    except Exception:
        cond_avg = 1.0

    denom = 1.0 + scaling_kl * kl_term + scaling_cond * cond_avg
    eta_scaled = base_eta / denom
    return np.clip(eta_scaled, eta_min, base_eta)



def apply_phi_updates(agent, grad_phi, grad_phi_m, mask, params):
    mask_exp = mask[..., None]

    def clip_lie_update(delta, threshold):
        if threshold <= 0:
            return delta
        norm = np.linalg.norm(delta, axis=-1, keepdims=True)
        factor = np.minimum(1.0, threshold / (norm + 1e-8))
        return delta * factor

    # φ adaptive update
    eta_phi_tuned = compute_adaptive_eta(
        config.eta_base_phi,
        grad_phi,
        getattr(agent, "cached_alignment_kl", None),
        agent.sigma_q_field,
        config.eta_phi_adaptive_scaling,
        config.eta_sigma_condition_scaling,
        config.eta_phi_min,
    )
    delta_phi = eta_phi_tuned * grad_phi
    delta_phi = clip_lie_update(delta_phi, getattr(config, "phi_grad_clip_threshold", 0.0))
    agent.phi -= delta_phi * mask_exp

    # φ̃ adaptive update
    eta_phi_m_tuned = compute_adaptive_eta(
        config.eta_base_phi_model,
        grad_phi_m,
        getattr(agent, "cached_model_alignment_kl", None),
        agent.sigma_p_field,
        config.eta_phi_model_adaptive_scaling,
        config.eta_sigma_condition_scaling,
        config.eta_phi_model_min,
    )
    delta_phi_m = eta_phi_m_tuned * grad_phi_m
    delta_phi_m = clip_lie_update(delta_phi_m, getattr(config, "phi_model_grad_clip_threshold", 0.0))
    agent.phi_model -= delta_phi_m * mask_exp



from numerical_utils import sanitize_sigma

from joblib import Parallel, delayed

def synchronous_step(agents, generators, params=None, n_jobs=1):
    params = params or {}
    N = len(agents)

    # Step 1: Preprocess Fisher, exp(φ), etc. — now parallel
    Parallel(n_jobs=n_jobs, backend="threading", batch_size=1)(
        delayed(preprocess_agent_fields)(A, generators, params) for A in agents
    )

    # Step 2: Refresh KL alignment caches BEFORE computing gradients
    for A in agents:
        A.cached_alignment_kl = compute_alignment_kl(A, agents, log_eps=config.eps)
        A.cached_model_alignment_kl = compute_model_alignment_kl(A, agents, log_eps=config.eps)

    # Step 3: Compute gradients in parallel
    grads = Parallel(n_jobs=n_jobs, backend="loky", batch_size=2)(
        delayed(compute_all_gradients)(i, agents, params) for i in range(N)
    )
    q_updates, p_updates, phi_grads, phi_m_grads = zip(*grads)
    mask_list = [A.mask for A in agents]

    eta_q = params.get("eta_q", config.eta_q)
    eta_p = params.get("eta_p", config.eta_p)

    # Step 4: Apply updates in parallel
    def apply_agent_updates(i):
        agent = agents[i]
        mask = mask_list[i]

        Δμ_q, ΔΣ_q = q_updates[i]
        Δμ_p, ΔΣ_p = p_updates[i]

        mask_mu    = mask[..., None]
        mask_sigma = mask[..., None, None]

        agent.mu_q_field    -= eta_q * Δμ_q * mask_mu
        agent.sigma_q_field -= eta_q * ΔΣ_q * mask_sigma
        agent.mu_p_field    -= eta_p * Δμ_p * mask_mu
        agent.sigma_p_field -= eta_p * ΔΣ_p * mask_sigma

        agent.sigma_q_field = sanitize_sigma(agent.sigma_q_field)
        agent.sigma_p_field = sanitize_sigma(agent.sigma_p_field)

        apply_phi_updates(agent, phi_grads[i], phi_m_grads[i], mask, params)
        return agent

    agents = Parallel(n_jobs=n_jobs, backend="threading", batch_size=1)(
        delayed(apply_agent_updates)(i) for i in range(N)
    )

    return agents




