import numpy as np
from get_generators import get_generators
import config


import numpy as np

def initialize_multivariate_gaussian_distribution(x_coords, mu_field, sigma_field, mask, log_eps=1e-8):
    """
    Initialize a multivariate Gaussian distribution over K fiber points,
    using spatially varying mean (mu_field) and full covariance matrix (sigma_field).

    Args:
        x_coords: (K, D) — fixed fiber coordinates
        mu_field: (H, W, D) — spatially varying mean vector field
        sigma_field: (H, W, D, D) — full SPD covariance matrices
        mask: (H, W) — spatial mask
        log_eps: regularization for Σ⁻¹ and logdet

    Returns:
        dist: (H, W, K) — probability distribution over fiber points
    """
    H, W, D = mu_field.shape
    K = x_coords.shape[0]
    assert sigma_field.shape == (H, W, D, D), f"Expected sigma_field shape (H,W,D,D), got {sigma_field.shape}"

    # Reshape for batched processing
    x = x_coords[None, None, :, :]        # (1, 1, K, D)
    mu = mu_field[:, :, None, :]          # (H, W, 1, D)
    delta = x - mu                        # (H, W, K, D)

    # Regularize sigma
    eps_eye = log_eps * np.eye(D)
    sigma_reg = sigma_field + eps_eye[None, None, :, :]  # (H, W, D, D)

    # Invert covariance with fallback
    sigma_inv = np.zeros_like(sigma_reg)
    for i in range(H):
        for j in range(W):
            try:
                sigma_inv[i, j] = np.linalg.inv(sigma_reg[i, j])
            except np.linalg.LinAlgError:
                sigma_inv[i, j] = np.eye(D) * (1.0 / log_eps)
                print(f"[WARN] Σ⁻¹ fallback at ({i},{j})")

    # Mahalanobis distance squared
    mahal_sq = np.einsum("...kd,...de,...ke->...k", delta, sigma_inv, delta)  # (H, W, K)

    # Stable exponent computation
    exponent = -0.5 * mahal_sq
    exponent -= np.max(exponent, axis=-1, keepdims=True)  # log-sum-exp stabilization

    # Softmax-like normalization
    exp_vals = np.exp(exponent)
    exp_vals *= mask[..., None]
    norm = np.clip(np.sum(exp_vals, axis=-1, keepdims=True), log_eps, None)
    dist = exp_vals / norm  # (H, W, K)

    return dist



def aggregate_fields(agent_list, attr: str):
    """Average a tensor field (e.g., mu_q_field) over agents."""
    return np.mean([getattr(ag, attr) for ag in agent_list], axis=0)


def aggregate_mask(agent_list, eps: float = 1e-3):
    """Compute union of support masks across agents."""
    masks = [(ag.mask > eps).astype(float) for ag in agent_list]
    return np.clip(np.sum(masks, axis=0), 0, 1)




def get_fiber_basis(K: int) -> np.ndarray:
    """
    Return standard basis coordinates in fiber space ℝ^K.
    Output shape: (K, D_fiber) = (K, K)
    """
    return np.eye(K, dtype=np.float32)


def initialize_gaussian_distribution(x, mu_field, sigma_field, mask):
    mu = mu_field[..., None]
    sigma = sigma_field[..., None]
    unnorm = np.exp(-0.5 * ((x - mu) / sigma) ** 2)
    dist = unnorm / (np.sum(unnorm, axis=-1, keepdims=True) + 1e-8)
    dist *= mask[..., None]
    return dist


def initialize_uniform_distribution(x, mask=None, dtype=np.float32):
    """
    Create a uniform categorical distribution with shape (*spatial*, K),
    where spatial is inferred from `mask` if it exists, otherwise from `x`.
    """
    K = config.K

    if mask is not None:
        spatial_shape = mask.shape
    elif x is not None and x.ndim >= 2:
        spatial_shape = x.shape[:-1]
    else:
        spatial_shape = config.domain_size

    base = np.full((*spatial_shape, K), 1.0 / K, dtype=dtype)

    if mask is not None:
        base = base * mask[..., None]

    return base


