# -*- coding: utf-8 -*-
"""
Created on Wed Jul 16 18:18:11 2025

@author: chris and christine
"""

# bundle_morphism_utils.py
import numpy as np
from typing import Optional, Tuple, List, Dict, Any, Union





def apply_morphism(mu, sigma, Phi):
    """
    Apply bundle morphism Φ to mean/covariance:
        μ' = Φ μ
        Σ' = Φ Σ Φᵀ

    Args:
        mu   : (..., K_q)       source mean
        sigma: (..., K_q, K_q)  source covariance
        Phi  : (..., K_p, K_q)  morphism from source to target space

    Returns:
        (mu_tgt, sigma_tgt): (..., K_p), (..., K_p, K_p)
    """
    mu_tgt = np.einsum("...ij,...j->...i", Phi, mu)
    sigma_tgt = np.einsum("...ik,...kl,...jl->...ij", Phi, sigma, Phi)
    return mu_tgt, sigma_tgt



def batch_apply_morphism(mu, sigma, Phi):
    """
    Vectorized version of apply_morphism over (H, W) grid.

    Args:
        mu    : (H, W, K_q)
        sigma : (H, W, K_q, K_q)
        Phi   : (H, W, K_p, K_q)

    Returns:
        (mu_tgt, sigma_tgt): (H, W, K_p), (H, W, K_p, K_p)
    """
    return apply_morphism(mu, sigma, Phi)


# bundle_morphism_utils.py

import numpy as np

def identity_morphism(K_src, K_tgt=None, shape=()):
    """
    Identity matrix morphism, broadcast to (H, W, K_tgt, K_src)
    """
    if K_tgt is None:
        K_tgt = K_src
    I = np.eye(K_tgt, K_src, dtype=np.float32)
    return np.broadcast_to(I, (*shape, K_tgt, K_src)).copy()

def assign_default_morphisms(agent, K):
    """
    Assign identity morphisms for:
    - Φᵢ      : Eqᵢ → Epᵢ  (belief bundle morphism)
    - Φ̃ᵢ     : Epᵢ → Eqᵢ  (model bundle morphism)

    Both are masked to agent support.
    """
    shape = agent.grid_shape
    mask = agent.mask[..., None, None]  # (H, W, 1, 1)

    Φ      = identity_morphism(K, shape=shape) * mask  # (H, W, K, K)
    Φ_tilde = identity_morphism(K, shape=shape) * mask

    agent.bundle_morphism_phi        = Φ
    agent.bundle_morphism_phi_tilde  = Φ_tilde

import numpy as np
from scipy.ndimage import gaussian_filter
import config

def generate_smooth_morphism_field(
    H, W,
    K_src, K_tgt,
    sigma=config.sigma_field_smooth_range,
    low_rank=None,
    seed=None,
    normalize=False,
    mask=None,
):
    """
    Generate a smooth spatial field of K_tgt × K_src morphisms.

    Args:
        H, W       : spatial domain
        K_src      : input dimension (e.g. q)
        K_tgt      : output dimension (e.g. p)
        sigma      : Gaussian blur σ (scalar or tuple)
        low_rank   : optional int ≤ min(K_src, K_tgt) for low-rank morphism
        seed       : optional random seed
        normalize  : if True, normalize each matrix to unit Frobenius norm
        mask       : (H, W) optional mask to apply (multiply per point)

    Returns:
        morphism_field : (H, W, K_tgt, K_src)
    """
    if seed is not None:
        rng = np.random.default_rng(seed)
    else:
        rng = np.random.default_rng()

    field = np.zeros((H, W, K_tgt, K_src), dtype=np.float32)

    # Create low-rank if desired
    rank = low_rank if low_rank is not None else min(K_src, K_tgt)

    for r in range(rank):
        outer = rng.standard_normal((K_tgt, K_src)).astype(np.float32)

        # Apply blur per entry
        coeffs = rng.standard_normal((H, W)).astype(np.float32)
        coeffs = gaussian_filter(coeffs, sigma=sigma, mode="wrap")

        field += coeffs[..., None, None] * outer[None, None, :, :]

    # Optional normalization
    if normalize:
        norm = np.linalg.norm(field, axis=(-2, -1), keepdims=True)
        field = np.divide(field, norm + 1e-8)

    # Optional masking
    if mask is not None:
        field *= mask[..., None, None]

    return field

def initialize_morphism_pair(
    domain_size: tuple[int, int],
    K_q: int,
    K_p: int,
    rng: np.random.Generator,
    morphism_type: str = "identity",
    mask: Optional[np.ndarray] = None,
    config_tag: str = "",
) -> tuple[np.ndarray, np.ndarray]:
    """
    Initialize bundle morphisms Φ (q→p) and Φ̃ (p→q).

    Args:
        domain_size    : (H, W)
        K_q, K_p       : belief and model fiber dims
        rng            : np.random.Generator
        morphism_type  : "identity", "smooth", "lowrank"
        mask           : agent support mask
        config_tag     : optional suffix to use e.g. config.phi_sigma_tagname

    Returns:
        (Phi_field, Phi_tilde_field)
    """
    H, W = domain_size

    if morphism_type == "identity" and K_q == K_p:
        eye = np.eye(K_q, dtype=np.float32)
        phi_q_to_p = np.broadcast_to(eye, (H, W, K_q, K_q)).copy()
        phi_p_to_q = np.broadcast_to(eye, (H, W, K_q, K_q)).copy()
        return phi_q_to_p, phi_p_to_q

    # Otherwise: generate two smooth morphism fields
    sigma = getattr(config, f"morphism_sigma{config_tag}", 1.5)
    rank = getattr(config, f"morphism_rank{config_tag}", min(K_q, K_p))
    normalize = getattr(config, f"morphism_normalize{config_tag}", True)

    phi_q_to_p = generate_smooth_morphism_field(
        H, W, K_src=K_q, K_tgt=K_p,
        sigma=sigma, low_rank=rank,
        normalize=normalize, mask=mask, seed=None
    )

    phi_p_to_q = generate_smooth_morphism_field(
        H, W, K_src=K_p, K_tgt=K_q,
        sigma=sigma, low_rank=rank,
        normalize=normalize, mask=mask, seed=None
    )

    return phi_q_to_p, phi_p_to_q

def compute_alignment_kl_general(agent_i, agents, field_type="belief", log_eps=config.eps):
    """
    Computes mean KL divergence KL(fiber_i || Ω_ij fiber_j) over neighbors j.
    Supports field_type = "belief" (q‖Ω·q) or "model" (q‖Ω·Φ·p).

    Args:
        agent_i: agent whose KL we compute
        agents:  list of all agents
        field_type: "belief" or "model"
        log_eps: numerical stabilizer for KL

    Returns:
        Mean KL divergence (float)
    """
    if field_type == "belief":
        mu_i      = agent_i.mu_q_field
        sigma_i   = agent_i.sigma_q_field
        Omega     = agent_i.Omega
        Omega_inv = agent_i.Omega_inv
        mu_j_f    = lambda j: agents[j].mu_q_field
        sigma_j_f = lambda j: agents[j].sigma_q_field
    elif field_type == "model":
        mu_i      = agent_i.mu_q_field
        sigma_i   = agent_i.sigma_q_field
        Omega     = agent_i.Omega
        Omega_inv = agent_i.Omega_inv
        mu_j_f    = lambda j: agents[j].mu_p_field
        sigma_j_f = lambda j: agents[j].sigma_p_field
        phi_j_f   = lambda j: agents[j].bundle_morphism_phi  # shape (H,W,K_q,K_p)
    else:
        raise ValueError(f"Invalid field_type: {field_type}")

    mask_i = agent_i.mask > config.support_cutoff_eps
    kl_vals = []

    for neighbor in agent_i.neighbors:
        j = neighbor["id"]
        agent_j = agents[j]
        mask_j = agent_j.mask > config.support_cutoff_eps
        overlap = mask_i & mask_j

        if not np.any(overlap):
            continue

        Ω_ij = np.einsum("mab,mbc->mac", Omega[overlap], Omega_inv[overlap])

        mu_j = mu_j_f(j)[overlap]
        sigma_j = sigma_j_f(j)[overlap]

        if field_type == "model":
            # Project p_j into q_i’s bundle via Φ_j
            phi_j = phi_j_f(j)[overlap]  # (N, K_q, K_p)
            mu_j = np.einsum("nij,nj->ni", phi_j, mu_j)
            sigma_j = np.einsum("nik,nkl,njl->nij", phi_j, sigma_j, phi_j)

        mu_j_t, sigma_j_t = batch_apply_omega(mu_j, sigma_j, Ω_ij)

        mu_i_pts = mu_i[overlap]
        sigma_i_pts = sigma_i[overlap]

        kl = kl_divergence(mu_i_pts, sigma_i_pts, mu_j_t, sigma_j_t, log_eps=log_eps)
        kl_vals.append(np.mean(kl))

    return np.mean(kl_vals) if kl_vals else 0.0

def compute_kl_qp_field(
    mu_q_field, sigma_q_field,
    mu_p_field, sigma_p_field,
    mask,
    phi_field=None,  # (H, W, K_q, K_p)
    log_eps=1e-8
):
    """
    Compute per-cell KL divergence KL[q || Φ·p] where q and p are MVGs.

    Args:
        mu_q_field     : (..., K_q)
        sigma_q_field  : (..., K_q, K_q)
        mu_p_field     : (..., K_p)
        sigma_p_field  : (..., K_p, K_p)
        mask           : (...,) binary mask
        phi_field      : (..., K_q, K_p) optional bundle morphism
        log_eps        : stabilizer for Σ_p

    Returns:
        kl_field : (H, W) array with zeros outside the mask
    """
    H, W = mask.shape
    K_q = mu_q_field.shape[-1]
    K_p = mu_p_field.shape[-1]

    indices = np.flatnonzero(mask.ravel())

    mu_q = mu_q_field.reshape(-1, K_q)[indices]
    sigma_q = sigma_q_field.reshape(-1, K_q, K_q)[indices]

    mu_p = mu_p_field.reshape(-1, K_p)[indices]
    sigma_p = sigma_p_field.reshape(-1, K_p, K_p)[indices]

    if phi_field is not None:
        phi = phi_field.reshape(-1, K_q, K_p)[indices]

        # Apply bundle morphism: Φ μ_p and Φ Σ_p Φᵀ
        mu_p = np.einsum("nij,nj->ni", phi, mu_p)
        sigma_p = np.einsum("nik,nkl,njl->nij", phi, sigma_p, phi)

    # Regularize Σ_p
    sigma_p += log_eps * np.eye(K_q if phi_field is not None else K_p)[None, ...]

    kl_vals = kl_divergence(mu_q, sigma_q, mu_p, sigma_p, log_eps=log_eps)

    kl_field = np.zeros((H * W,), dtype=kl_vals.dtype)
    kl_field[indices] = kl_vals
    return kl_field.reshape(H, W)

from scipy.linalg import expm

def build_rho(phi_vec: np.ndarray, generators: dict[str, np.ndarray]) -> np.ndarray:
    """
    phi_vec : (3,) Lie algebra coefficients [θ_H, θ_E, θ_F]
    generators : dict with 'H', 'E', 'F' matrices

    returns ρ(exp(φ)) ∈ SL(2,R)^K
    """
    phi_matrix = phi_vec[0] * generators['H'] + phi_vec[1] * generators['E'] + phi_vec[2] * generators['F']
    return expm(phi_matrix)


# gauge_morphism_utils.py
import numpy as np

def gauge_covariant_transform_phi(phi_field, Phi_field, rho_q_func, rho_p_func):
    """
    Apply Φ(x) ↦ ρ_p(exp(φ(x))) · Φ(x) · ρ_q(exp(φ(x)))⁻¹ for each point.

    Args:
        phi_field:  (H, W, 3)
        Phi_field:  (H, W, K_p, K_q)
        rho_q_func: φ → ρ_q(exp(φ)) (returns (K_q, K_q))
        rho_p_func: φ → ρ_p(exp(φ)) (returns (K_p, K_p))

    Returns:
        Transformed Phi_field: (H, W, K_p, K_q)
    """
    H, W = phi_field.shape[:2]
    K_p, K_q = Phi_field.shape[-2:]

    out = np.zeros_like(Phi_field)
    for i in range(H):
        for j in range(W):
            phi = phi_field[i, j]
            rho_q = rho_q_func(phi)      # (K_q, K_q)
            rho_p = rho_p_func(phi)      # (K_p, K_p)
            Phi = Phi_field[i, j]        # (K_p, K_q)

            out[i, j] = rho_p @ Phi @ np.linalg.inv(rho_q)

    return out

