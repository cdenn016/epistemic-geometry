import numpy as np


# Cache for generated generators
_generator_cache = {}
import numpy as np



def get_generators(group_name: str, K: int) -> np.ndarray:
    """
    Return the Lie algebra generators for the specified group and representation dimension.
    For 'so3', generators are now real-valued irreducible representations.
    """
    name = group_name.lower()
    key = (name, K)
    if key in _generator_cache:
        return _generator_cache[key]

    if name == "so3":
        # real-valued irreducible SO(3) rep, K = 2ℓ+1
        if K % 2 == 0:
            raise ValueError("K must be odd for SO(3) irreps (K=2ℓ+1).")
        ℓ = (K - 1) // 2
        Lx = np.zeros((K, K), dtype=float)
        Ly = np.zeros((K, K), dtype=float)
        Lz = np.zeros((K, K), dtype=float)
        for m in range(-ℓ, ℓ + 1):
            i = m + ℓ
            if i < K - 1:
                a = 0.5 * np.sqrt((ℓ - m) * (ℓ + m + 1))
                Lx[i, i + 1] = a
                Lx[i + 1, i] = a
                Ly[i, i + 1] = -a
                Ly[i + 1, i] = a
            Lz[i, i] = m
        gens = [Lx, Ly, Lz]

    elif name == "su2":
        if K % 2 == 0:
            raise ValueError("K must be odd for SU(2) irreps (K=2ℓ+1).")
        ℓ = (K - 1) // 2
        m = np.arange(ℓ, -ℓ - 1, -1)
        Jz = np.diag(m)
        Jp = np.zeros((K, K), dtype=complex)
        for i in range(K - 1):
            mm = m[i]
            Jp[i, i + 1] = np.sqrt((ℓ - mm) * (ℓ + mm + 1))
        Jm = Jp.conj().T
        Jx = 0.5 * (Jp + Jm)
        Jy = -0.5j * (Jp - Jm)
        gens = [Jx, Jy, Jz]

    elif name == "u1":
        gens = [np.eye(K, dtype=complex)]

    elif name == "sl2r":
        if K % 2 == 0:
            raise ValueError("K must be odd for SL(2,R) irreps (K=2ℓ+1).")
        ℓ = (K - 1) // 2
        L1 = np.zeros((K, K), dtype=float)
        L2 = np.zeros((K, K), dtype=float)
        L3 = np.zeros((K, K), dtype=float)
        for m in range(-ℓ, ℓ + 1):
            idx = m + ℓ
            L3[idx, idx] = m
            if idx < K - 1:
                a = np.sqrt((ℓ - m) * (ℓ + m + 1))
                L1[idx, idx + 1] = a
                L1[idx + 1, idx] = a
                L2[idx, idx + 1] = -a
                L2[idx + 1, idx] = a
        gens = [L1, L2, L3]

    else:
        raise ValueError(f"Unsupported group '{group_name}'")

    # Only non-real groups get converted to skew-Hermitian
    if name in ("su2", "u1"):
        gens = [1j * G for G in gens]

    gens = np.stack(gens, axis=0)  # shape (dim_G, K, K)
    _generator_cache[key] = gens
    return gens

# sl2r_utils.py

from scipy.linalg import expm
import numpy as np

class RhoFunction:
    def __init__(self, generators: np.ndarray):
        assert generators.shape[0] == 3, "Expecting 3 generators [E, F, H]"
        self.E = generators[0]
        self.F = generators[1]
        self.H = generators[2]

    def __call__(self, phi_vec: np.ndarray) -> np.ndarray:
        return expm(phi_vec[0] * self.E +
                    phi_vec[1] * self.F +
                    phi_vec[2] * self.H)




def infer_lie_algebra_dim(group_name: str, K: int) -> int:
    """
    Return the dimension of the Lie algebra for the given group and rep-dimension K.
    Accepts two args so calls like infer_lie_algebra_dim(name, K) work.
    """
    name = group_name.lower()
    if name == "so3":
        return 3
    if name == "su2":
        return 3
    if name == "u1":
        return 1
    if name == "sl2r":
        return 3
    raise ValueError(f"Unknown group '{group_name}' for infer_lie_algebra_dim")
