
from __future__ import annotations
from typing import Any, Dict, Iterable, Optional, Sequence, Tuple
import numpy as np

# Your existing utilities
from core.group import exp_lie_algebra_irrep
from core.numerical_utils import safe_omega_inv
import math
import core.config as CFG


"""
Created on Tue Aug 19 20:19:10 2025

@author: chris and christine
"""

# -*- coding: utf-8 -*-
"""
transport_cache.py
Centralized facade for cached transports: exp(φ), Ω_{ij}, Λ (hooks).
Backed by runtime_ctx.cache (CacheHub). One source of truth, cleared per step.
"""


def _sanitize_axis_angle(phi, *, max_theta=None):
    """
    Make axis–angle safe for exp:
      - replace NaN/Inf with 0
      - clamp ‖phi‖ into principal ball (<= pi - margin)
    """
    
    phi = np.asarray(phi, np.float32)
    # replace invalids
    phi = np.nan_to_num(phi, nan=0.0, posinf=0.0, neginf=0.0)
    # only clamp 3-vectors
    if phi.shape[-1] != 3:
        return phi
    if max_theta is None:
        margin = float(getattr(CFG, "so3_principal_ball_margin", 1e-4))
        max_theta = float(math.pi - margin)
    th2 = np.einsum("...i,...i->...", phi, phi)
    th  = np.sqrt(th2, dtype=np.float32)
    overflow = th > max_theta
    if np.any(overflow):
        scale = (max_theta / np.maximum(th, 1e-12)).astype(np.float32)
        phi = phi * scale[..., None]
    return phi


# ---------------------------------------------------------------------------
# Internal helpers (keys, accessors)
# ---------------------------------------------------------------------------

def _aid(a: Any) -> int:
    """Robust agent id (falls back to object's id if missing)."""
    return int(getattr(a, "id", id(a)))

def _exp_key(agent: Any, which: str) -> Tuple[str, int, str]:
    # which ∈ {'q','p'}
    return ("exp", _aid(agent), which)

def _omega_key(ai: Any, aj: Any, which: str) -> Tuple[str, int, int, str]:
    return ("omega", _aid(ai), _aid(aj), which)

def _lambda_key(child: Any, parent: Any, which: str, up: bool) -> Tuple[str, int, int, str, str]:
    return ("lambda", _aid(child), _aid(parent), which, "up" if up else "dn")

def _get_generators(agent: Any, which: str) -> np.ndarray:
    if which == "q":
        G = getattr(agent, "generators_q", None)
    else:
        G = getattr(agent, "generators_p", None)
    if G is None:
        raise ValueError(f"[transport_cache] generators ({which}) missing on agent id={_aid(agent)}")
    return G

def _get_phi(agent: Any, which: str) -> np.ndarray:
    if which == "q":
        phi = getattr(agent, "phi", None)
    else:
        phi = getattr(agent, "phi_model", None)
    if phi is None:
        raise ValueError(f"[transport_cache] phi field ({which}) missing on agent id={_aid(agent)}")
    return phi


# ---------------------------------------------------------------------------
# Public API: exp(φ) and Ω_{ij}
# ---------------------------------------------------------------------------

def E_grid(ctx: Any, agent: Any, which: str = "q") -> np.ndarray:
    """
    Cached exp(φ) grid for an agent in fiber 'q' or 'p'.
    Shape: (..., K, K), broadcasts over spatial dims.
    """
    cache: Dict[Any, Any] = ctx.cache.ns("exp")
    key = _exp_key(agent, which)
    E = cache.get(key)
    if E is None:
        G = _get_generators(agent, which)
        phi = _get_phi(agent, which)

        # --- NEW: sanitize φ and handle tiny-φ fast path -------------------------
        phi = _sanitize_axis_angle(phi)
        
        small_thr = float(getattr(CFG, "phi_small_threshold", 1e-6))
        if phi.shape[-1] == 3:
            # if all tiny, return identity tiles (skip exp)
            th = np.linalg.norm(phi, axis=-1)
            if np.all(th < small_thr):
                K = int(G.shape[-2])
                I = np.eye(K, dtype=np.float32)
                E = np.broadcast_to(I, phi.shape[:-1] + (K, K)).copy()
                cache[key] = E
                return E

        # optional clipping guard for very large reps
        max_norm = float(getattr(CFG, "exp_clip_max_norm", 10.0))
        E = exp_lie_algebra_irrep(phi, G, max_norm=max_norm)  # (..., K, K)
        cache[key] = E
    return E



def Omega(ctx: Any, ai: Any, aj: Any, which: str = "q") -> np.ndarray:
    """
    Cached Ω_{ij} = exp(φ_i) @ inv(exp(φ_j)) for fiber 'q' or 'p'.
    Uses safe_omega_inv for general irreps (not assuming orthogonality).
    """
    om_cache = ctx.cache.ns("omega")
    key = _omega_key(ai, aj, which)
    Om = om_cache.get(key)
    if Om is None:
        Ei = E_grid(ctx, ai, which)   # (..., K, K)
        Ej = E_grid(ctx, aj, which)   # (..., K, K)
        Ej_inv = safe_omega_inv(Ej)   # (..., K, K)
        Om = np.matmul(Ei, Ej_inv)    # (..., K, K)
        om_cache[key] = Om
    return Om





def omega_child_to_parents_batched(ctx, child, parents, G, *, invert_j=True, mask_tau=1e-3):
    """
    Compute Ω_{i->j} on overlap windows for one child vs many parents, in batch.

    Returns:
      list[(parent_id: int, bbox: (y0,y1,x0,x1), Omega_win: (h,w,K,K) float32)]

    Notes:
      - Infers fiber ('q' or 'p') from the shape of G vs child's generators.
      - Crops to the tight overlap bbox per parent to avoid full-frame work.
      - Uses a batched linear solve for Ej^{-1} (stable & faster than forming inv).
    """
    

    # -------- infer fiber from G's shape (must match child's generators) ---------
    which = None
    G = np.asarray(G, np.float32)
    if getattr(child, "generators_q", None) is not None and \
       tuple(np.shape(child.generators_q)) == tuple(G.shape):
        which = "q"
    elif getattr(child, "generators_p", None) is not None and \
         tuple(np.shape(child.generators_p)) == tuple(G.shape):
        which = "p"
    else:
        raise ValueError(
            f"[omega_child_to_parents_batched] cannot infer fiber from G.shape={G.shape}; "
            f"child.gen_q={getattr(child,'generators_q',None) and np.shape(child.generators_q)}, "
            f"child.gen_p={getattr(child,'generators_p',None) and np.shape(child.generators_p)}"
        )

    # -------- build Ei once; share memory when cropping --------------------------
    Ei_full = E_grid(ctx, child, which=which)  # (H,W,K,K)
    H, W, K, _ = Ei_full.shape

    out = []
    cmask = np.asarray(getattr(child, "mask", 0.0), np.float32)

    for p in (parents or []):
        if p is None:
            continue

        pmask = np.asarray(getattr(p, "mask", 0.0), np.float32)
        ov, bbox = _overlap_and_bbox(cmask, pmask, mask_tau)  # tight bbox
        if bbox is None:
            continue

        y0, y1, x0, x1 = bbox
        h, w = (y1 - y0), (x1 - x0)
        if h <= 0 or w <= 0:
            continue

        # crop Ei/Ej once per parent
        Ei_win = Ei_full[y0:y1, x0:x1, :, :]                          # (h,w,K,K)
        Ej_win = E_grid(ctx, p, which=which)[y0:y1, x0:x1, :, :]       # (h,w,K,K)

        # build Ω_{ij} window
        if invert_j:
            # Solve Ej^T * X^T = Ei^T  ⇒ X = (solve(Ej^T, Ei^T))^T
            N  = h * w
            A  = Ej_win.reshape(N, K, K).transpose(0, 2, 1)  # A = Ej^T
            B  = Ei_win.reshape(N, K, K).transpose(0, 2, 1)  # B = Ei^T
            Xt = np.linalg.solve(A, B)                       # (N,K,K)
            X  = Xt.transpose(0, 2, 1).reshape(h, w, K, K)   # (h,w,K,K)
        else:
            # Convention w/o inversion if you ever need it: Ω = Ei @ Ej^T
            X = np.einsum("...ab,...cb->...ac", Ei_win, Ej_win, optimize=True)

        out.append((int(getattr(p, "id", id(p))), bbox, X.astype(np.float32, copy=False)))

    return out




def _roll2(a, shift_hw, boundary="periodic", fill=None):
    """
    2D roll with simple boundary handling.
    - periodic: np.roll
    - clamp: out-of-range pulls from edge
    - zero: pad with `fill` (or identity if used with matrices)
    """
    sh, sw = shift_hw
    if boundary == "periodic":
        return np.roll(np.roll(a, sh, axis=-3), sw, axis=-2)

    H, W = a.shape[-3], a.shape[-2]
    if boundary == "clamp":
        # roll, then clamp edges by copying nearest valid row/col
        out = np.roll(np.roll(a, sh, axis=-3), sw, axis=-2)
        if sh > 0:  out[..., :sh, :, :] = out[..., sh:sh+1, :, :]
        if sh < 0:  out[..., H+sh:, :, :] = out[..., H+sh-1:H+sh, :, :]
        if sw > 0:  out[..., :, :sw, :] = out[..., :, sw:sw+1, :]
        if sw < 0:  out[..., :, W+sw:, :] = out[..., :, W+sw-1:W+sw, :]
        return out

    # boundary == "zero" (or anything else): pad with fill (expects matrices)
    out = np.roll(np.roll(a, sh, axis=-3), sw, axis=-2)
    if fill is None:
        # try to infer identity of the right size
        K = a.shape[-1]
        fill = np.eye(K, dtype=a.dtype)
    if sh > 0:  out[..., :sh, :, :] = fill
    if sh < 0:  out[..., H+sh:, :, :] = fill
    if sw > 0:  out[..., :, :sw, :] = fill
    if sw < 0:  out[..., :, W+sw:, :] = fill
    return out


def plaquette_product(ctx, phi_field, generators, *, boundary="periodic", split_edge=False, sign=+1):
    """
    Compute 1×1 plaquette P(i,j) = Ux(i,j) · Uy(i+1,j) · Ux(i,j+1)^T · Uy(i,j)^T
    using central E cache.

    Inputs
    ------
    phi_field: (..., H, W, d) algebra field at sites (SO(3) in R^3)
    generators: (K, K, 3) real irrep generators used by exp_lie_algebra_irrep
    boundary: 'periodic' | 'clamp' | 'zero'
    split_edge: if True, build edge links as exp(½ φ_here) then compose with neighbor exp(½ φ_there)
                (slightly better symmetry when φ varies a lot)

    Returns
    -------
    P: (..., H, W, K, K) plaquette matrices (orthogonal if inputs are)
    """
    # 1) site exponentials from cache: E(i,j) = exp(sign * φ(i,j))
    E = E_grid(ctx, phi_field, generators, sign=sign)           # (..., H, W, K, K)
    Et = np.swapaxes(E, -1, -2)                                 # (..., H, W, K, K) transpose

    if not split_edge:
        # simplest link choice: use site exponentials as links
        Ux_ij   = E
        Uy_ij   = E
        Ux_i_j1 = _roll2(E, (0, +1), boundary=boundary)
        Uy_i1_j = _roll2(E, (+1, 0), boundary=boundary)
    else:
        # symmetric "half-edge" links: Ux(i,j) ≈ exp(½φ(i,j)) · exp(½φ(i,j+1))
        # reuse cache by calling E_grid on scaled fields
        half = 0.5
        E_half_here  = E_grid(ctx, half * phi_field, generators, sign=sign)
        E_half_t_here = np.swapaxes(E_half_here, -1, -2)

        E_half_right = _roll2(E_grid(ctx, half * phi_field, generators, sign=sign), (0, +1), boundary=boundary)
        E_half_down  = _roll2(E_grid(ctx, half * phi_field, generators, sign=sign), (+1, 0), boundary=boundary)

        Ux_ij   = E_half_here @ E_half_right
        Uy_ij   = E_half_here @ E_half_down
        # neighbors for the other two edges:
        Ux_i_j1 = _roll2(Ux_ij, (0, +1), boundary=boundary)
        Uy_i1_j = _roll2(Uy_ij, (+1, 0), boundary=boundary)

    # 2) plaquette P = Ux(i,j) Uy(i+1,j) Ux(i,j+1)^T Uy(i,j)^T
    P = Ux_ij @ Uy_i1_j @ np.swapaxes(Ux_i_j1, -1, -2) @ np.swapaxes(Uy_ij, -1, -2)
    return P


def curvature_plaquette(ctx, phi_field, generators, *,
                        boundary="periodic",
                        split_edge=False,
                        metric="fro",
                        return_P=False,
                        eps=1e-7):
    """
    Gauge-invariant lattice curvature density from 1×1 plaquettes.

    metric:
      - 'fro'  : 0.5 * ||I - P||_F^2  (cheap, stable; ~ ||log P||^2 near identity)
      - 'angle': use principal rotation angle θ from trace(P) when K==3 and P∈SO(3),
                 returns θ^2 (NaN-safe; clipped)

    Returns
    -------
    curv: (..., H, W) float32
    (optional) P: (..., H, W, K, K)
    """
    P = plaquette_product(ctx, phi_field, generators, boundary=boundary, split_edge=split_edge, sign=+1)
    K  = P.shape[-1]
    IK = np.eye(K, dtype=P.dtype)

    if metric == "fro":
        D = P - IK
        # frob norm squared per site
        curv = 0.5 * np.sum(D * D, axis=(-1, -2))
    elif metric == "angle":
        # only meaningful for faithful SO(3) K=3; fall back if not
        if K != 3:
            D = P - IK
            curv = 0.5 * np.sum(D * D, axis=(-1, -2))
        else:
            # θ = arccos((trace(P)-1)/2), clamp arg for numeric safety
            tr = np.trace(P, axis1=-2, axis2=-1)
            x  = np.clip((tr - 1.0) * 0.5, -1.0 + 1e-6, 1.0 - 1e-6)
            theta = np.arccos(x)
            curv = theta * theta
    else:
        raise ValueError(f"curvature_plaquette: unknown metric '{metric}'")

    curv = curv.astype(np.float32, copy=False)
    return (curv, P) if return_P else curv





# ---------------------------------------------------------------------------
# Optional Λ hooks (centralize later; stubs return cached value if present)
# ---------------------------------------------------------------------------

# transport_cache.py — add/replace these definitions

def _lambda_key(child: Any, parent: Any, which: str, up: bool) -> Tuple[str, int, int, str, str]:
    return ("lambda", _aid(child), _aid(parent), which, "up" if up else "dn")

# transport_cache.py

def Lambda_dn(ctx: Any, child: Any, parent: Any, which: str = "q") -> np.ndarray:
    """
    Cached Λ↓ (parent → child): Λ↓ = E_child @ inv(E_parent)
    """
    lam_ns = ctx.cache.ns("lambda")
    key = _lambda_key(child, parent, which, up=False)
    Lam = lam_ns.get(key)
    if Lam is None:
        E_c = E_grid(ctx, child, which=which)
        E_p = E_grid(ctx, parent, which=which)
        E_p_inv = safe_omega_inv(E_p)             # <-- inverse, not transpose
        Lam = np.einsum("...ik,...kj->...ij", E_c, E_p_inv, optimize=True)
        lam_ns[key] = Lam
    return Lam

def Lambda_up(ctx: Any, child: Any, parent: Any, which: str = "q") -> np.ndarray:
    """
    Cached Λ↑ (child → parent): Λ↑ = E_parent @ inv(E_child)
    """
    lam_ns = ctx.cache.ns("lambda")
    key = _lambda_key(child, parent, which, up=True)
    Lam = lam_ns.get(key)
    if Lam is None:
        E_c = E_grid(ctx, child, which=which)
        E_p = E_grid(ctx, parent, which=which)
        E_c_inv = safe_omega_inv(E_c)             # <-- inverse, not transpose
        Lam = np.einsum("...ik,...kj->...ij", E_p, E_c_inv, optimize=True)
        lam_ns[key] = Lam
    return Lam



# ---------------------------------------------------------------------------
# Cached dexpinv matrices Jinv(phi)  (SO(3) axis-angle principal ball)
# ---------------------------------------------------------------------------

def _overlap_and_bbox(mask_i, mask_j, thr):
    """
    Return (ov, (y0,y1,x0,x1)) where ov is boolean overlap on full grid,
    and bbox tightly crops to the minimal rectangle that contains ov==True.
    If no overlap, returns (ov, None).
    """
    
    mi = np.asarray(mask_i, np.float32) > float(thr)
    mj = np.asarray(mask_j, np.float32) > float(thr)
    ov = (mi & mj)
    if not np.any(ov):
        return ov, None
    ys, xs = np.nonzero(ov)
    y0, y1 = int(ys.min()), int(ys.max()) + 1
    x0, x1 = int(xs.min()), int(xs.max()) + 1
    return ov, (y0, y1, x0, x1)


def _jinv_key(agent: Any, which: str) -> Tuple[str, int, str]:
    # which in {"q","p"}
    return ("jinv", _aid(agent), which)

def _alpha_theta(theta: np.ndarray, theta2: np.ndarray) -> np.ndarray:
    """
    Your existing LUT/Taylor alpha(θ) helper. If you already have one
    (e.g., in natural_gradient.py), import and call that instead.
    """
    # Minimal stable version (feel free to swap for your LUT):
    eps = 1e-12
    out = np.empty_like(theta, dtype=np.float32)
    small = theta < 1e-3
    # Taylor: alpha ≈ 1/12 + θ²/720
    out[small] = (1.0/12.0 + theta2[small] * (1.0/720.0)).astype(np.float32)
    # General: alpha = (1/θ²)(1 - (θ/2)cot(θ/2))
    t = theta[~small]
    t2 = theta2[~small]
    half = 0.5 * t
    out[~small] = ((1.0 / np.maximum(t2, eps)) * (1.0 - half * (np.cos(half) / np.maximum(np.sin(half), eps)))).astype(np.float32)
    return out

def build_dexpinv_matrix(phi):
    """
    Vectorized Jinv(phi) for last-dim=3 axis-angle.
    Uses small-φ fast path: if all ‖φ‖ < 1e-6 on a tile, Jinv ≈ I (skip math).
    """
    
    phi = np.asarray(phi, np.float32)
    if phi.shape[-1] != 3:
        raise ValueError(f"build_dexpinv_matrix: phi last dim must be 3, got {phi.shape}")
    th2 = np.einsum("...i,...i->...", phi, phi)
    th  = np.sqrt(th2)
    I = np.eye(3, dtype=np.float32)

    # all-small fast path
    if np.all(th < 1e-6):
        return np.broadcast_to(I, phi.shape[:-1] + (3, 3)).copy()

    alpha = _alpha_theta(th, th2)

    # skew(φ)
    K = np.zeros(phi.shape[:-1] + (3, 3), np.float32)
    K[..., 0, 1], K[..., 0, 2] = -phi[..., 2],  phi[..., 1]
    K[..., 1, 0], K[..., 1, 2] =  phi[..., 2], -phi[..., 0]
    K[..., 2, 0], K[..., 2, 1] = -phi[..., 1],  phi[..., 0]

    outer = phi[..., :, None] * phi[..., None, :]
    c0 = (1.0 - alpha * th2)[..., None, None]
    c1 = 0.5
    c2 = alpha[..., None, None]
    return (c0 * I) + (c1 * K) + (c2 * outer)


def Jinv_grid(ctx, agent, which="q", bbox=None):
    """
    Cached Jinv(phi) per pixel (3x3). If bbox=(y0,y1,x0,x1) is given,
    compute/cache only that window (and store the full grid lazily).
    """
    ns = ctx.cache.ns("jinv")
    key = ("jinv", int(getattr(agent, "id", id(agent))), which)
    J = ns.get(key)
    if J is None:
        phi = _get_phi(agent, which)  # (...,3)
        phi = np.where(np.isfinite(phi), phi, 0.0).astype(np.float32)
        J = build_dexpinv_matrix(phi)  # (...,3,3)
        ns[key] = J
        if bbox is None:
            return J
    if bbox is None:
        return J
    y0,y1,x0,x1 = bbox
    return J[y0:y1, x0:x1, :, :]


def warm_Jinv(ctx: Any, agents: Sequence[Any], whiches: Iterable[str] = ("q", "p")) -> None:
    """Precompute Jinv for many agents (idempotent)."""
    for a in agents:
        for w in whiches:
            try:
                _ = Jinv_grid(ctx, a, which=w)
            except Exception:
                pass

# ---------------------------------------------------------------------------
# Bundle morphisms (same-level) and cross-scale morphisms (Θ)
# Cached per-step in "morphism" and "theta" namespaces
# ---------------------------------------------------------------------------

def _morphism_key(agent: Any, kind: str) -> Tuple[str, int, str]:
    # kind in {"q_to_p", "p_to_q"}
    return ("morphism", _aid(agent), kind)

def _theta_key(child: Any, parent: Any, direction: str) -> Tuple[str, int, int, str]:
    # direction in {"down", "up"}
    return ("theta", _aid(child), _aid(parent), direction)


def _get_phi0(agent: Any, kind: str) -> np.ndarray:
    """
    Fetch the base (static) morphism matrices from the agent:
      - kind="q_to_p" -> agent.bundle_morphism_q_to_p (Φ_0), shape (..., Kp, Kq)
      - kind="p_to_q" -> agent.bundle_morphism_p_to_q (Φ̃_0), shape (..., Kq, Kp)
    """
    if kind == "q_to_p":
        M = getattr(agent, "bundle_morphism_q_to_p", None)
        name = "bundle_morphism_q_to_p"
    else:
        M = getattr(agent, "bundle_morphism_p_to_q", None)
        name = "bundle_morphism_p_to_q"
    if M is None:
        raise ValueError(f"[transport_cache] missing {name} on agent id={_aid(agent)}")
    return M

# add near the top
import numpy as np
import core.config as config
from core.numerical_utils import safe_omega_inv

def _infer_group_name():
    return str(getattr(config, "group_name", "so3")).lower()

def _eye_like(rows, cols, dtype=np.float32):
    return np.eye(int(rows), int(cols), dtype=dtype)

def _broadcast_morphism_template(M, target_tail, lead_shape):
    M = np.asarray(M, np.float32)
    if M.shape[-2:] != tuple(target_tail):
        M = _eye_like(*target_tail, dtype=M.dtype)
    if M.ndim == 2:
        M = np.broadcast_to(M, tuple(lead_shape) + tuple(target_tail))
    return M

def _build_morphisms_with_cache(ctx, agent, Phi_0, Phi_tilde_0, *, group_name=None):
    """
    Build Φ and Φ̃ using the central E_grid cache. Assumes ctx/cache is present.
    Φ       = E_p · Φ₀ · E_q^{-1}
    Φ̃      = E_q · Φ̃₀ · E_p^{-1}
    """
    group = (group_name or _infer_group_name())
    so3_orth = bool(getattr(config, "so3_irreps_are_orthogonal", True)) and group == "so3"

    # cached exponentials for the *agent itself*
    E_q = E_grid(ctx, agent, which="q").astype(np.float32, copy=False)  # (..., Kq, Kq)
    E_p = E_grid(ctx, agent, which="p").astype(np.float32, copy=False)  # (..., Kp, Kp)

    Kq = int(E_q.shape[-1]); Kp = int(E_p.shape[-1])
    lead = np.broadcast_shapes(E_q.shape[:-2], E_p.shape[:-2])

    # templates: ensure shape & broadcast
    Phi_0       = _broadcast_morphism_template(Phi_0,       (Kp, Kq), lead)
    Phi_tilde_0 = _broadcast_morphism_template(Phi_tilde_0, (Kq, Kp), lead)

    # inverses (transpose for orthogonal)
    E_q_inv = np.swapaxes(E_q, -1, -2) if so3_orth else safe_omega_inv(E_q).astype(np.float32, copy=False)
    E_p_inv = np.swapaxes(E_p, -1, -2) if so3_orth else safe_omega_inv(E_p).astype(np.float32, copy=False)

    # einsums
    Phi       = np.einsum("...ik,...kj,...jl->...il", E_p, Phi_0,       E_q_inv, optimize=True).astype(np.float32, copy=False)
    Phi_tilde = np.einsum("...ik,...kj,...jl->...il", E_q, Phi_tilde_0, E_p_inv, optimize=True).astype(np.float32, copy=False)
    return Phi, Phi_tilde



def Phi(ctx, agent, kind: str = "q_to_p"):
    assert ctx is not None and hasattr(ctx, "cache"), "Phi: ctx with cache required"
    ns  = ctx.cache.ns("morphism")

    # Optional step tag to avoid stale values across steps
    step_tag = getattr(ctx, "global_step", None)
    key = _morphism_key(agent, kind, step_tag=step_tag)

    M = ns.get(key)
    if M is not None:
        return M

    # Gather defaults for Φ₀ / Φ̃₀ from agent sizes
    Kq = int(np.asarray(agent.mu_q_field).shape[-1])
    Kp = int(np.asarray(agent.mu_p_field).shape[-1])

    Phi_0_attr       = getattr(agent, "Phi_0", None)
    Phi_tilde_0_attr = getattr(agent, "Phi_tilde_0", None)

    Phi_0_default       = _eye_like(Kp, Kq)
    Phi_tilde_0_default = _eye_like(Kq, Kp)

    Phi_0_in       = (np.asarray(Phi_0_attr, np.float32)       if Phi_0_attr       is not None else Phi_0_default)
    Phi_tilde_0_in = (np.asarray(Phi_tilde_0_attr, np.float32) if Phi_tilde_0_attr is not None else Phi_tilde_0_default)

    # Build both once with the central cache (no import from bundle_morphism_utils)
    Phi_full, Phit_full = _build_morphisms_with_cache(
        ctx, agent, Phi_0_in, Phi_tilde_0_in, group_name=_infer_group_name()
    )

    ns[_morphism_key(agent, "q_to_p", step_tag)] = Phi_full
    ns[_morphism_key(agent, "p_to_q", step_tag)] = Phit_full

    return Phi_full if kind == "q_to_p" else Phit_full



def Phi_tilde(ctx, agent) -> np.ndarray:
    return Phi(ctx, agent, kind="p_to_q")



def Theta_dn(ctx, child, parent):
    Lq = Lambda_dn(ctx, child, parent, which="q")  # (..., Kq_c, Kq_p)
    Lp = Lambda_dn(ctx, child, parent, which="p")  # (..., Kp_c, Kp_p)
    Phi_c   = Phi(ctx, child, kind="q_to_p")       # (..., Kp_c, Kq_c)
    Phit_c  = Phi(ctx, child, kind="p_to_q")       # (..., Kq_c, Kp_c)
    _assert_chain("Theta_dn.q", Phit_c, Lp)        # (Kq_c×Kp_c) @ (Kp_c×Kp_p)
    _assert_chain("Theta_dn.p", Phi_c,  Lq)        # (Kp_c×Kq_c) @ (Kq_c×Kq_p)
    Theta_q = np.einsum("...ik,...kj->...ij", Phit_c, Lp, optimize=True)  # (..., Kq_c, Kp_p)
    Theta_p = np.einsum("...ik,...kj->...ij", Phi_c,  Lq, optimize=True)  # (..., Kp_c, Kq_p)
    out = {"q": Theta_q, "p": Theta_p}
    ctx.cache.ns("theta")[_theta_key(child, parent, "down")] = out
    return out

def Theta_up(ctx, child, parent):
    Lq = Lambda_up(ctx, child, parent, which="q")  # (..., Kq_p, Kq_c)
    Lp = Lambda_up(ctx, child, parent, which="p")  # (..., Kp_p, Kp_c)
    Phi_p   = Phi(ctx, parent, kind="q_to_p")      # (..., Kp_p, Kq_p)
    Phit_p  = Phi(ctx, parent, kind="p_to_q")      # (..., Kq_p, Kp_p)
    _assert_chain("Theta_up.q",  Phit_p, Lp)       # (Kq_p×Kp_p) @ (Kp_p×Kp_c)
    _assert_chain("Theta_up.p",  Phi_p,  Lq)       # (Kp_p×Kq_p) @ (Kq_p×Kq_c)
    Theta_q = np.einsum("...ik,...kj->...ij", Phit_p, Lp, optimize=True)  # (..., Kq_p, Kp_c)
    Theta_p = np.einsum("...ik,...kj->...ij", Phi_p,  Lq, optimize=True)  # (..., Kp_p, Kq_c)
    out = {"q": Theta_q, "p": Theta_p}
    ctx.cache.ns("theta")[_theta_key(child, parent, "up")] = out
    return out




# ---------------------------------------------------------------------------
# Warming & invalidation
# ---------------------------------------------------------------------------

def warm_E(ctx: Any, agents: Sequence[Any], whiches: Iterable[str] = ("q", "p")) -> None:
    """Precompute exp(φ) for many agents (idempotent)."""
    for a in agents:
        for w in whiches:
            try:
                _ = E_grid(ctx, a, which=w)
            except Exception:
                # Keep warm-up best-effort; avoid failing the whole pass.
                pass



def invalidate_agent(ctx: Any, agent: Any) -> None:
    aid = int(getattr(agent, "id", id(agent)))
    for ns_name in ("exp", "omega", "lambda", "jinv", "morphism", "theta"):
        ns = ctx.cache.ns(ns_name)
        for k in list(ns.keys()):
            if isinstance(k, tuple) and (aid in k):
                ns.pop(k, None)



# ---------------------------------------------------------------------------
# Transitional compatibility helpers (optional)
# ---------------------------------------------------------------------------


def _matmul_shapes_ok(A, B):
    # A(..., i, k) @ B(..., k, j) -> (..., i, j)
    if A is None or B is None:
        return False
    if A.ndim < 2 or B.ndim < 2:
        return False
    return A.shape[-1] == B.shape[-2]

def _assert_chain(name, *mats):
    # Ensure M1@M2@... is dimensionally valid
    for idx in range(len(mats) - 1):
        if not _matmul_shapes_ok(mats[idx], mats[idx+1]):
            a = mats[idx].shape if mats[idx] is not None else None
            b = mats[idx+1].shape if mats[idx+1] is not None else None
            raise ValueError(f"[{name}] shape mismatch at link {idx}: {a} @ {b}")


