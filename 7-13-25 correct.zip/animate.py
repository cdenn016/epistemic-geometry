# -*- coding: utf-8 -*-
"""
Created on Tue Jul  8 18:30:18 2025

@author: chris and christine
"""

import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation
from pathlib import Path
from scipy.ndimage import laplace

from generalized_math_utils import kl_divergence, safe_log

INPUT_DIR = Path("checkpoints/field_dumps")
OUTPUT_DIR = Path("Animations/full_fields")
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

LOG_EPS = 1e-8

def list_step_dirs():
    return sorted([d for d in INPUT_DIR.iterdir() if d.is_dir() and "step" in d.name])

def compute_entropy(sigma_q):
    H, W, K = sigma_q.shape[:3]
    entropy = np.full((H, W), np.nan, dtype=np.float32)
    for i in range(H):
        for j in range(W):
            Σ = sigma_q[i, j]
            if not np.all(np.isfinite(Σ)):
                continue
            Σ += LOG_EPS * np.eye(K)
            try:
                sign, logdet = np.linalg.slogdet(Σ)
                if sign > 0:
                    entropy[i, j] = 0.5 * (K * np.log(2 * np.pi * np.e) + logdet)
            except np.linalg.LinAlgError:
                pass
    return np.nan_to_num(entropy)


def compute_kl_qp(mu_q, sigma_q, mu_p, sigma_p):
    H, W, K = mu_q.shape
    μq = mu_q.reshape(-1, K)
    Σq = sigma_q.reshape(-1, K, K)
    μp = mu_p.reshape(-1, K)
    Σp = sigma_p.reshape(-1, K, K)

    try:
        kl_vals = kl_divergence(μq, Σq, μp, Σp, log_eps=LOG_EPS)
    except Exception as e:
        print("KL computation error:", e)
        return np.zeros((H, W), dtype=np.float32)

    kl = kl_vals.reshape(H, W)
    if np.isnan(kl).any():
        print("[KL WARNING] NaNs in KL(q‖p)")
    return np.nan_to_num(kl)


def compute_phi_norm(phi):
    return np.linalg.norm(phi, axis=-1)

def compute_phi_laplacian_norm(phi):
    lap = np.stack([laplace(phi[..., d]) for d in range(phi.shape[-1])], axis=-1)
    return np.linalg.norm(lap, axis=-1)

def animate_field_over_time(field_seq, steps, title, fname, cmap="viridis"):
    vmin = np.nanmin(field_seq)
    vmax = np.nanmax(field_seq)

    fig, ax = plt.subplots()
    im = ax.imshow(field_seq[0], cmap=cmap, vmin=vmin, vmax=vmax)
    plt.colorbar(im, ax=ax)
    ax.set_title(f"{title} — Step {steps[0]}")

    def update(i):
        im.set_data(field_seq[i])
        ax.set_title(f"{title} — Step {steps[i]}")
        return [im]

    ani = animation.FuncAnimation(fig, update, frames=len(steps), interval=400, blit=True)
    outpath = OUTPUT_DIR / f"{fname}.gif"
    ani.save(outpath, fps=25)
    plt.close()
    print(f"[SAVED] {outpath}")

def main():
    step_dirs = list_step_dirs()
    entropy_seq, klqp_seq, phinorm_seq, phimodelnorm_seq, lapphi_seq = [], [], [], [], []
    steps = []

    for d in step_dirs:
        try:
            mu_q    = np.load(d / "mu_q_field.npy")
            sigma_q = np.load(d / "sigma_q_field.npy")
            phi     = np.load(d / "phi.npy")
            mu_p    = np.load(d / "mu_p_field.npy")
            sigma_p = np.load(d / "sigma_p_field.npy")
            phi_m   = np.load(d / "phi_model.npy")
        except FileNotFoundError:
            continue

        entropy_seq.append(compute_entropy(sigma_q))
        klqp_seq.append(compute_kl_qp(mu_q, sigma_q, mu_p, sigma_p))
        phinorm_seq.append(compute_phi_norm(phi))
        phimodelnorm_seq.append(compute_phi_norm(phi_m))
        lapphi_seq.append(compute_phi_laplacian_norm(phi))
        steps.append(int(d.name.replace("step", "")))

    animate_field_over_time(entropy_seq, steps, "Entropy(q)", "entropy_q")
    animate_field_over_time(klqp_seq, steps, "KL(q‖p)", "kl_qp")
    animate_field_over_time(phinorm_seq, steps, "‖φ‖", "phi_norm")
    animate_field_over_time(phimodelnorm_seq, steps, "‖φ_model‖", "phi_model_norm")
    animate_field_over_time(lapphi_seq, steps, "‖Δφ‖", "lap_phi")

if __name__ == "__main__":
    main()
