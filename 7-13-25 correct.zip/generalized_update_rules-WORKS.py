# -*- coding: utf-8 -*-
"""
Created on Sat Jul 12 15:59:56 2025

@author: chris and christine
"""

# === generalized_update_rules.py (refactor patch) ===
import numpy as np
import config
from joblib import Parallel, delayed

from natural_gradient_utils import (
    apply_natural_gradient_batch,
    apply_lie_natural_gradient,
    sanitize_sigma,
)
from generalized_update_terms import (
    compute_beliefs_gradient,
    compute_models_gradient,
    compute_phi_alignment_gradient,
    compute_phi_model_update,
)
from generalized_omega import exp_lie_algebra_irrep

from scipy.linalg import solve_triangular  # or np.linalg.solve per batch

def batch_matrix_inverse(mat_batch):
    """
    Solve X = A⁻¹ using A·X = I for a batch of (N, K, K) matrices.
    """
    N, K, _ = mat_batch.shape
    I = np.eye(K)[None, :, :]
    return np.linalg.solve(mat_batch, np.broadcast_to(I, (N, K, K)))


def preprocess_agent_fields(agent, generators, params):
    """Sanitize sigmas, cache Fisher info, compute exp(φ), exp(−φ)"""
    e_belief = params.get("e_belief", config.e_belief)
    e_model  = params.get("e_model",  config.e_model)

    agent.clear_omega_cache()
    agent.grid_shape = agent.phi.shape[:-1]

    flat_phi       = agent.phi.reshape(-1, agent.phi.shape[-1]) / e_belief
    flat_phi_model = agent.phi_model.reshape(-1, agent.phi_model.shape[-1]) / e_model

    agent._exp_phi       = exp_lie_algebra_irrep(flat_phi, generators)
    agent._exp_phi_model = exp_lie_algebra_irrep(flat_phi_model, generators)
    agent._exp_neg_phi       = batch_matrix_inverse(agent._exp_phi)
    agent._exp_neg_phi_model = batch_matrix_inverse(agent._exp_phi_model)

    agent.sigma_q_field = sanitize_sigma(agent.sigma_q_field, eps=config.eps, debug=config.debug_sanitize_sigma)
    agent.sigma_p_field = sanitize_sigma(agent.sigma_p_field, eps=config.eps, debug=config.debug_sanitize_sigma)

    agent.cached_fisher_q = np.linalg.inv(agent.sigma_q_field)
    agent.cached_fisher_p = np.linalg.inv(agent.sigma_p_field)


def compute_all_gradients(i, agents, params):
    ai = agents[i]
    return (
        compute_beliefs_gradient(ai, agents, params),
        compute_models_gradient(ai, agents, params),
        compute_phi_alignment_gradient(ai, agents, params),
        compute_phi_model_update(ai, agents, params),
    )


def apply_q_p_updates(agent, q_grads, p_grads, eta_q, eta_p, mask):
    mask_mu    = mask[..., None]
    mask_sigma = mask[..., None, None]

    delta_mu_q, delta_sigma_q = apply_natural_gradient_batch(
        agent.mu_q_field, agent.sigma_q_field, *q_grads)
    agent.mu_q_field    -= eta_q * delta_mu_q    * mask_mu
    agent.sigma_q_field -= eta_q * delta_sigma_q * mask_sigma

    delta_mu_p, delta_sigma_p = apply_natural_gradient_batch(
        agent.mu_p_field, agent.sigma_p_field, *p_grads)
    agent.mu_p_field    -= eta_p * delta_mu_p    * mask_mu
    agent.sigma_p_field -= eta_p * delta_sigma_p * mask_sigma


def apply_phi_updates(agent, grad_phi, grad_phi_m, mask, params):
    mask_exp = mask[..., None]
    G_inv_phi     = params.get("G_inv_phi", None)
    G_inv_model   = params.get("G_inv_phi_model", None)
    eta_phi_model = params.get("eta_model_phi", config.eta_model_phi)

    # φ update
    grad_norm_phi = np.linalg.norm(grad_phi[mask > config.support_cutoff_eps]) + 1e-8
    eta_phi_tuned = np.clip(
        config.eta_base_phi / (1.0 + config.eta_phi_adaptive_scaling * grad_norm_phi),
        config.eta_phi_min,
        config.eta_base_phi,
    )
    delta_phi = eta_phi_tuned * apply_lie_natural_gradient(agent.phi, grad_phi, G_inv=G_inv_phi)
    agent.phi -= delta_phi * mask_exp

    # Optional clip
    if (thresh := getattr(config, "phi_clip_threshold", 0.0)) > 0:
        norm = np.linalg.norm(agent.phi, axis=-1, keepdims=True)
        clip = (norm > thresh)[..., 0]
        scale = thresh / (norm[..., 0][clip] + 1e-8)
        agent.phi[clip] *= scale[:, None]

    # φ_model update
    grad_norm_phi_m = np.linalg.norm(grad_phi_m[mask > config.support_cutoff_eps]) + 1e-8
    eta_phi_model_tuned = np.clip(
        eta_phi_model / (1.0 + 0.1 * grad_norm_phi_m),
        1e-6, eta_phi_model,
    )
    delta_phi_m = eta_phi_model_tuned * apply_lie_natural_gradient(agent.phi_model, grad_phi_m, G_inv=G_inv_model)
    agent.phi_model -= delta_phi_m * mask_exp

    if (thresh := getattr(config, "phi_model_clip_threshold", 0.0)) > 0:
        norm_m = np.linalg.norm(agent.phi_model, axis=-1, keepdims=True)
        clip_m = (norm_m > thresh)[..., 0]
        scale_m = thresh / (norm_m[..., 0][clip_m] + 1e-8)
        agent.phi_model[clip_m] *= scale_m[:, None]


def synchronous_step(agents, generators, params=None, n_jobs=1):
    params = params or {}
    N = len(agents)

    for A in agents:
        preprocess_agent_fields(A, generators, params)

    mask_list = [A.mask for A in agents]

    grads = Parallel(n_jobs=n_jobs, backend="loky", batch_size=8)(
        delayed(compute_all_gradients)(i, agents, params) for i in range(N)
    )
    q_grads, p_grads, phi_grads, phi_m_grads = zip(*grads)

    eta_q = params.get("eta_q", config.eta_q)
    eta_p = params.get("eta_p", config.eta_p)

    for i, agent in enumerate(agents):
        apply_q_p_updates(agent, q_grads[i], p_grads[i], eta_q, eta_p, mask_list[i])
        apply_phi_updates(agent, phi_grads[i], phi_m_grads[i], mask_list[i], params)

    return agents
