import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation
from pathlib import Path
import re
import glob
import config

from generalized_agent_schema import Agent
from pullback_utils import compute_agent_pullback_blocks

SAVE_DIR = Path("Holonomy_Visualizations/pullback")
SAVE_DIR.mkdir(parents=True, exist_ok=True)


def extract_step(fname):
    match = re.search(r"step(\d+)", fname)
    return int(match.group(1)) if match else -1


def load_agents_from_field_dumps(folder):
    files = sorted(Path(folder).glob("step*.npz"))
    agents = []
    steps = []

    for f in files:
        data = np.load(f, allow_pickle=True)
        step_id = extract_step(f.name)

        mu_q, sigma_q = data["mu_q"], data["sigma_q"]
        mu_p, sigma_p = data["mu_p"], data["sigma_p"]
        phi_model = data.get("phi_model", np.zeros((*mu_q.shape[:2], config.lie_dim)))
        phi       = data.get("phi", np.zeros_like(phi_model))

        A = Agent(
            id             = int(data["agent_i"]),
            mask           = data["mask_i"],
            mu_q_field     = mu_q,
            sigma_q_field  = sigma_q,
            mu_p_field     = mu_p,
            sigma_p_field  = sigma_p,
            phi            = phi,
            phi_model      = phi_model,
            center         = (0, 0),
            radius         = 1.0,
            neighbors      = [],
        )
        A.grid_shape = mu_q.shape[:2]
        agents.append(A)
        steps.append(step_id)

    return steps, agents

def extract_traces(blocks, mask=None, normalize=True):
    M_vis  = blocks["M_vis"]
    M_dark = blocks["M_dark"]
    Delta  = blocks["Delta"]

    Tr_vis  = np.einsum("...ii->...", M_vis)
    Tr_dark = np.einsum("...ii->...", M_dark)
    Mix_norm = np.linalg.norm(Delta, axis=(-2, -1))

    if normalize:
        d_vis  = M_vis.shape[-1]
        d_dark = M_dark.shape[-1]
        Tr_vis  /= max(d_vis, 1)
        Tr_dark /= max(d_dark, 1)

    if mask is not None:
        mask_bool = mask.astype(bool)
        Tr_vis[~mask_bool]   = np.nan
        Tr_dark[~mask_bool]  = np.nan
        Mix_norm[~mask_bool] = np.nan

    return Tr_vis, Tr_dark, Mix_norm



def animate_single_metric(agent_seq, vis_inds, dark_inds, field: str, fname: str, cmap: str):
    """
    Animate a single pullback diagnostic field:
        field ∈ {"Tr_vis", "Tr_dark", "Delta"}
    """
    frames = []
    diagnostics = []

    for A in agent_seq:
        blocks = compute_agent_pullback_blocks(A, vis_inds, dark_inds)
        Tr_vis, Tr_dark, Mix_norm = extract_traces(blocks, mask=A.mask)

        if field == "Tr_vis":
            val = Tr_vis
        elif field == "Tr_dark":
            val = Tr_dark
        elif field == "Delta":
            val = Mix_norm
        else:
            raise ValueError(f"Unknown field: {field}")

        frames.append(val)
        diagnostics.append({
            "max": np.nanmax(val),
        })

    frames = np.stack(frames, axis=0)
    vmin = np.nanmin(frames)
    vmax = np.nanmax(frames)

    fig, ax = plt.subplots(figsize=(5, 5))
    im = ax.imshow(frames[0], cmap=cmap, vmin=vmin, vmax=vmax)
    title = ax.set_title("")
    text = ax.text(2, 2, "", color="white", fontsize=10, bbox=dict(facecolor='black', alpha=0.5))

    def update(i):
        im.set_array(frames[i])
        title.set_text(f"{field} (Frame {i})")
        text.set_text(f"max: {diagnostics[i]['max']:.2f}")
        return [im, title, text]

    ani = animation.FuncAnimation(fig, update, frames=len(frames), blit=True)
    ani.save(SAVE_DIR / fname, fps=25)
    plt.close()
    print(f"[✓] Saved {fname} ({len(frames)} frames)")



def animate_pullback_fields(agent_seq, vis_inds, dark_inds, fname="pullback_fields.gif"):
    frames = []
    for A in agent_seq:
        blocks = compute_agent_pullback_blocks(A, vis_inds, dark_inds)
        Tr_vis, Tr_dark, Mix_norm = extract_traces(blocks, mask=A.mask)

        norm_vis  = Tr_vis / np.nanmax(Tr_vis)
        norm_dark = Tr_dark / np.nanmax(Tr_dark)
        norm_mix  = Mix_norm / np.nanmax(Mix_norm)

        frame = np.concatenate([norm_vis[..., None], norm_dark[..., None], norm_mix[..., None]], axis=1)
        frames.append(frame)
    frames = np.stack(frames, axis=0)

    fig = plt.figure(figsize=(10, 4))
    im = plt.imshow(frames[0], animated=True, cmap="viridis")

    def update(i):
        im.set_array(frames[i])
        return [im]

    ani = animation.FuncAnimation(fig, update, frames=len(frames), blit=True)
    ani.save(SAVE_DIR / fname, fps=25)
    plt.close()


def animate_spatial_metric_trace(agent_seq, vis_inds, dark_inds, fname="pullback_trG.gif"):
    frames = []
    diagnostics = []

    # Build all frames and diagnostics first
    for A in agent_seq:
        blocks = compute_agent_pullback_blocks(A, vis_inds, dark_inds)
        Tr_G = np.trace(blocks["G"], axis1=-2, axis2=-1)
        Tr_G[~A.mask.astype(bool)] = np.nan
        frames.append(Tr_G)
        diagnostics.append({
            "max_TrG": np.nanmax(Tr_G),
        })

    frames = np.stack(frames, axis=0)
    vmin = np.nanmin(frames)
    vmax = np.nanmax(frames)

    fig, ax = plt.subplots(figsize=(5, 5))
    im = ax.imshow(frames[0], cmap="cividis", vmin=vmin, vmax=vmax)
    text = ax.text(2, 2, "", color="white", fontsize=10, bbox=dict(facecolor='black', alpha=0.5))

    def update(i):
        im.set_array(frames[i])
        info = f"Frame {i} | max Tr(G): {diagnostics[i]['max_TrG']:.2f}"
        text.set_text(info)
        return [im, text]

    ani = animation.FuncAnimation(fig, update, frames=len(frames), blit=True)
    ani.save(SAVE_DIR / fname, fps=25)
    plt.close()
    print(f"[✓] Saved {len(frames)} frames → {fname}")


def animate_gq_vs_gp(agent_seq, vis_inds, dark_inds, fname="pullback_trG_diff.gif"):
    gq_frames = []
    gp_frames = []
    diagnostics = []

    for A in agent_seq:
        Gq = compute_agent_pullback_blocks(A, vis_inds, dark_inds, from_belief=True)["G"]
        Gp = compute_agent_pullback_blocks(A, vis_inds, dark_inds, from_belief=False)["G"]
        Tr_Gq = np.trace(Gq, axis1=-2, axis2=-1)
        Tr_Gp = np.trace(Gp, axis1=-2, axis2=-1)

        mask = A.mask.astype(bool)
        Tr_Gq[~mask] = np.nan
        Tr_Gp[~mask] = np.nan

        gq_frames.append(Tr_Gq)
        gp_frames.append(Tr_Gp)
        diagnostics.append({
            "max_q": np.nanmax(Tr_Gq),
            "max_p": np.nanmax(Tr_Gp),
        })

    gq_frames = np.stack(gq_frames, axis=0)
    gp_frames = np.stack(gp_frames, axis=0)
    vmin = min(np.nanmin(gq_frames), np.nanmin(gp_frames))
    vmax = max(np.nanmax(gq_frames), np.nanmax(gp_frames))

    fig, axes = plt.subplots(1, 2, figsize=(10, 5))
    im_q = axes[0].imshow(gq_frames[0], vmin=vmin, vmax=vmax, cmap="Blues")
    im_p = axes[1].imshow(gp_frames[0], vmin=vmin, vmax=vmax, cmap="Oranges")
    axes[0].set_title("Tr(Gᵠ) — from Belief")
    axes[1].set_title("Tr(Gᵖ) — from Model")

    text_q = axes[0].text(1, 1, "", color="white", fontsize=8,
                          bbox=dict(facecolor='black', alpha=0.5))
    text_p = axes[1].text(1, 1, "", color="white", fontsize=8,
                          bbox=dict(facecolor='black', alpha=0.5))
    suptitle = fig.suptitle("")

    step_counter = fig.text(0.5, 0.01, "", ha="center", fontsize=10)

    def update(i):
        im_q.set_array(gq_frames[i])
        im_p.set_array(gp_frames[i])
        suptitle.set_text(f"Frame {i}")
        text_q.set_text(f"max: {diagnostics[i]['max_q']:.2f}")
        text_p.set_text(f"max: {diagnostics[i]['max_p']:.2f}")
        step_counter.set_text(f"step {i:03d}")
        return [im_q, im_p, suptitle, text_q, text_p, step_counter]

    ani = animation.FuncAnimation(fig, update, frames=len(gq_frames), blit=False)
    ani.save(SAVE_DIR / fname, fps=25)
    plt.close()
    print(f"[✓] Saved Tr(G^q vs G^p) → {fname}")


if __name__ == "__main__":
    vis_inds  = [0, 1]
    dark_inds = [2]
    dump_dir  = Path("checkpoints/field_dumps")
    steps, agents = load_agents_from_field_dumps(dump_dir)

    animate_single_metric(agents, vis_inds, dark_inds, field="Tr_vis",  fname="pullback_trM_vis.gif",   cmap="viridis")
    animate_single_metric(agents, vis_inds, dark_inds, field="Tr_dark", fname="pullback_trM_dark.gif",  cmap="inferno")
    animate_single_metric(agents, vis_inds, dark_inds, field="Delta",   fname="pullback_delta_norm.gif",cmap="plasma")
    animate_spatial_metric_trace(agents, vis_inds, dark_inds, fname="pullback_trG.gif")
    animate_gq_vs_gp(
        agent_seq = agents,
        vis_inds  = vis_inds,
        dark_inds = dark_inds,
        fname     = "pullback_trG_diff.gif"
    )




