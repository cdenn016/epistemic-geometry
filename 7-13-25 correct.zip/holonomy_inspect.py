# -*- coding: utf-8 -*-
"""
Created on Tue Jul  8 15:52:49 2025

@author: chris and christine
"""

import numpy as np
import pickle
from pathlib import Path
import re

LOG_DIR = Path("holonomy_experiments/transport_logs")

def extract_step(fname):
    match = re.search(r"step(\d+)", fname)
    return int(match.group(1)) if match else -1

def main():
    files = sorted(LOG_DIR.glob("*.pkl"), key=lambda f: extract_step(f.name))

    print(f"[INFO] Found {len(files)} logs\n")
    for f in files:
        with open(f, "rb") as pkl:
            data = pickle.load(pkl)

        mu_seq = np.asarray(data["mu_seq"])
        sigma_seq = np.asarray(data["sigma_seq"])
        label = f.name

        Δμ = np.linalg.norm(mu_seq[-1] - mu_seq[0])
        ΔΣ = np.linalg.norm(sigma_seq[-1] - sigma_seq[0])

        is_static = (Δμ < 1e-6) and (ΔΣ < 1e-6)
        flag = "[STATIC]" if is_static else "         "

        print(f"{flag} {label:45}  Δ‖μ‖ = {Δμ:.3e}   Δ‖Σ‖ = {ΔΣ:.3e}")

if __name__ == "__main__":
    main()
