import numpy as np
import config
from scipy.linalg import expm
from joblib import Parallel, delayed, parallel_backend
from natural_gradient_utils import sanitize_sigma  # assumes sanitize_sigma is in your utils
from generalized_math_utils import kl_divergence



def transport_covariance_batch(Sigma, Omega):
    """
    Transport a batch of covariance matrices: Σ → Ω Σ Ωᵀ

    Parameters:
        Sigma: (N, K, K) — batch of covariance matrices
        Omega: (N, K, K) — batch of transport operators

    Returns:
        Sigma_t: (N, K, K) — transported covariances
    """
    return Omega @ Sigma @ np.transpose(Omega, (0, 2, 1))

import numpy as np

def compute_curvature_gradient_analytical(phi: np.ndarray, generators: np.ndarray, dx: float = 1.0) -> np.ndarray:
    """
    Compute the full variational gradient of the gauge energy:
        ∇_φ Tr[F_{μν} F^{μν}] = 2 Tr[(∇^μ F_{μν}) ∂F/∂φ^a]

    This is the Lie-covariant curvature gradient, suitable for variational updates of φ.

    Args:
        phi:        (H, W, d) Lie algebra coordinates φ^a(x)
        generators: (d, K, K) Lie algebra basis G^a
        dx:         lattice spacing

    Returns:
        grad:       (H, W, d) gradient of action in Lie basis
    """
    H, W, d = phi.shape
    K = generators.shape[1]

    # Compute A_x and A_y: (H, W, d)
    A_x = (np.roll(phi, -1, axis=0) - np.roll(phi, 1, axis=0)) / (2 * dx)
    A_y = (np.roll(phi, -1, axis=1) - np.roll(phi, 1, axis=1)) / (2 * dx)

    # Convert to matrices
    A_x_mat = np.einsum("ijk,klm->ijlm", A_x, generators)  # (H, W, K, K)
    A_y_mat = np.einsum("ijk,klm->ijlm", A_y, generators)

    # Derivatives
    dAy_dx = (np.roll(A_y_mat, -1, axis=0) - np.roll(A_y_mat, 1, axis=0)) / (2 * dx)
    dAx_dy = (np.roll(A_x_mat, -1, axis=1) - np.roll(A_x_mat, 1, axis=1)) / (2 * dx)

    # Commutator [A_x, A_y]
    commutator = np.einsum("...ij,...jk->...ik", A_x_mat, A_y_mat) - np.einsum("...ij,...jk->...ik", A_y_mat, A_x_mat)

    # Curvature F_xy
    F_xy = dAy_dx - dAx_dy + commutator  # (H, W, K, K)

    # Compute divergence: ∇^x F_{xy} + ∇^y F_{yx}
    # Compute ∂F/∂x
    dF_dx = (np.roll(F_xy, -1, axis=0) - np.roll(F_xy, 1, axis=0)) / (2 * dx)
    dF_dy = (np.roll(F_xy, -1, axis=1) - np.roll(F_xy, 1, axis=1)) / (2 * dx)

    # Commutator [A_x, F_xy]
    comm1 = np.einsum("...ij,...jk->...ik", A_x_mat, F_xy) - np.einsum("...ij,...jk->...ik", F_xy, A_x_mat)
    comm2 = np.einsum("...ij,...jk->...ik", A_y_mat, F_xy) - np.einsum("...ij,...jk->...ik", F_xy, A_y_mat)

    divF = dF_dx + dF_dy + comm1 + comm2  # (H, W, K, K)

    # Project to Lie algebra
    grad = np.zeros((H, W, d), dtype=phi.dtype)
    for a in range(d):
        G = generators[a]
        grad[..., a] = 2.0 * np.einsum("...ij,ij->...", divF, G)

    return grad




def compute_gauge_potential(phi, dx=1.0):
    """
    Compute gauge potentials A_μ^a = ∂_μ φ^a using central differences with periodic boundaries.

    Args:
        phi: np.ndarray, shape (..., d), where
             ... represents spatial dimensions (S_1,...,S_D),
             d = dim Lie algebra.
        dx: float, lattice spacing

    Returns:
        A: tuple of length D, each entry np.ndarray of shape (..., d),
           spatial derivatives of phi along each base manifold dimension.
    """
    D = phi.ndim - 1  # subtract Lie algebra dimension axis
    A = tuple(
        (np.roll(phi, -1, axis=axis) - np.roll(phi, 1, axis=axis)) / (2 * dx)
        for axis in range(D)
    )
    return A



def adaptive_expm(G, clip_norm=None, max_norm=None, threshold=1e-3):
    """
    Rescales G to prevent instability, then exponentiates using:
      - 4th-order Taylor for small ‖G‖
      - expm(G) otherwise

    Parameters:
        G: (K, K) Lie algebra element
        clip_norm: soft cap — rescales G if ‖G‖ > clip_norm
        max_norm: hard cap — forcibly rescales if ‖G‖ > max_norm
        threshold: below this, use 4th-order Taylor

    Returns:
        exp(G) ∈ Lie group
    """
    norm_G = np.linalg.norm(G) + 1e-16

    if clip_norm is not None and norm_G > clip_norm:
        G = G * (clip_norm / norm_G)

    if max_norm is not None and norm_G > max_norm:
        G = G * (max_norm / norm_G)

    if norm_G < threshold:
        I = np.eye(G.shape[0], dtype=G.dtype)
        G2 = G @ G
        G3 = G2 @ G
        G4 = G3 @ G
        return I + G + 0.5 * G2 + (1/6) * G3 + (1/24) * G4
    else:
        return expm(G)


def exp_lie_algebra_irrep(
    v_batch,
    generators,
    use_expm=True,
    threshold=1e-3,
    max_norm=10,
    group_name=None,
    n_jobs=-1
):
    """
    Compute batch of exp(sum_a v[a] * T_a) using Taylor or expm depending on norm.

    Parameters:
        v_batch: (..., dim_G) Lie algebra coefficients
        generators: (dim_G, K, K) Lie algebra generators
        use_expm: fallback to expm if large-norm
        threshold: Taylor cutoff
        max_norm: clamp Lie vector norms
        group_name: used for antisymmetrization ("so3", "su2", etc)
        n_jobs: parallel expm if large batch

    Returns:
        (..., K, K) exponentiated matrices
    """
    *batch_shape, dim_G = v_batch.shape
    v_flat = v_batch.reshape(-1, dim_G)
    N = v_flat.shape[0]
    _, K, _ = generators.shape
    dtype = v_batch.dtype

    # Clip large φ vectors
    norms = np.linalg.norm(v_flat, axis=1)
    eps = 1e-16
    scale_factors = np.minimum(1.0, max_norm / (norms + eps))
    v_scaled = v_flat * scale_factors[:, None]

    if np.any(scale_factors < 1.0):
        print(f"[Ω] Clipped {np.sum(scale_factors < 1)} / {N} φ vectors to ‖φ‖ ≤ {max_norm}")

    # Build algebra elements
    G_batch = np.einsum("na,aij->nij", v_scaled, generators)

    # Antisymmetrize if applicable
    if group_name == "so3":
        G_batch = 0.5 * (G_batch - np.transpose(G_batch, axes=(0, 2, 1)))
    elif group_name == "su2":
        G_batch = 0.5 * (G_batch - np.transpose(G_batch, axes=(0, 2, 1)).conj())

    result = np.empty((N, K, K), dtype=dtype)
    approx_mask = norms * scale_factors < threshold

    # 4th-order Taylor expansion for small-norm matrices
    if np.any(approx_mask):
        G_approx = G_batch[approx_mask]
        I = np.eye(K, dtype=dtype)[None, :, :]
        G2 = G_approx @ G_approx
        G3 = G2 @ G_approx
        G4 = G2 @ G2
        result[approx_mask] = (
            I + G_approx + 0.5 * G2 + (1.0 / 6.0) * G3 + (1.0 / 24.0) * G4
        )

    # Fallback expm with NaN/Inf protection
    if np.any(~approx_mask):
        idxs = np.flatnonzero(~approx_mask)
        G_heavy = [G_batch[i] for i in idxs]
        with parallel_backend("threading"):
            expm_results = Parallel(n_jobs=n_jobs)(
                delayed(adaptive_expm)(
                    G, clip_norm=None, max_norm=max_norm, threshold=threshold
                    ) for G in G_heavy
                )
        for i, res in zip(idxs, expm_results):
            result[i] = res
            
    return result.reshape(*batch_shape, K, K)


def batch_apply_omega(mu_batch, sigma_batch, omega_batch, n_jobs=None, parallel_threshold=1000):
    """
    Applies Ω to MVGs using Cholesky transport:
        μ' = Ω μ
        Σ' = (Ω L)(Ω L)ᵀ  where Σ = LLᵀ (Cholesky)

    Returns:
        μ', Σ' with same shapes
    """
    mu_batch     = np.asarray(mu_batch)
    sigma_batch  = np.asarray(sigma_batch)
    omega_batch  = np.asarray(omega_batch)

    assert mu_batch.shape[:-1] == omega_batch.shape[:-2], "Shape mismatch in batch dims"
    assert mu_batch.shape[-1] == omega_batch.shape[-1], "Fiber dim mismatch"

    n_jobs = n_jobs or getattr(config, "num_cores", 1)
    flat_mu     = mu_batch.reshape(-1, mu_batch.shape[-1])
    flat_omega  = omega_batch.reshape(-1, omega_batch.shape[-2], omega_batch.shape[-1])
    flat_sigma  = sigma_batch.reshape(-1, sigma_batch.shape[-2], sigma_batch.shape[-1])
    N, K = flat_mu.shape[0], flat_mu.shape[1]

    # Step 1: sanitize
    flat_sigma = sanitize_sigma(flat_sigma, eps=config.eps)

    # Step 2: transport means
    if N < parallel_threshold:
        mu_t = np.einsum("...ij,...j->...i", omega_batch, mu_batch)
    else:
        with parallel_backend("threading"):
            mu_t_flat = Parallel(n_jobs=n_jobs)(
                delayed(lambda μ, Ω: Ω @ μ)(μ, Ω) for μ, Ω in zip(flat_mu, flat_omega)
            )
        mu_t = np.stack(mu_t_flat, axis=0).reshape(mu_batch.shape)

    # Step 3: transport covariances
    def robust_cholesky(Σ, eps=1e-6):
        try:
            return np.linalg.cholesky(Σ), False, False
        except:
            try:
                eigvals, eigvecs = np.linalg.eigh(Σ)
                eigvals = np.clip(eigvals, eps, None)
                Σ_fixed = eigvecs @ np.diag(eigvals) @ eigvecs.T
                Σ_fixed = 0.5 * (Σ_fixed + Σ_fixed.T)
                return np.linalg.cholesky(Σ_fixed), True, False
            except:
                return np.eye(K), True, True

    sigma_t = np.zeros_like(flat_sigma)
    repaired = 0
    fallbacks = 0

    for i in range(N):
        L, was_repaired, was_fallback = robust_cholesky(flat_sigma[i], eps=config.eps)
        if was_repaired: repaired += 1
        if was_fallback: fallbacks += 1
        L_t = flat_omega[i] @ L
        sigma_t[i] = L_t @ L_t.T

    if repaired > 0:
        print(f"[Ω SPD-repair] Repaired {repaired} / {N}")
    if fallbacks > 0:
        print(f"[Ω FINAL fallback] Used identity for {fallbacks} / {N}")

    return mu_t, sigma_t.reshape(sigma_batch.shape)


def compute_covariant_derivative_phi(phi, generators, dx=1.0):
    """
    Compute covariant derivative D_μ φ = ∂_μ φ + [A_μ, φ] with periodic BCs.

    Args:
        phi:        (H, W, d) array of Lie algebra coordinates
        generators: (d, K, K) Lie algebra basis
        dx:         lattice spacing

    Returns:
        D_phi: list of length D (spatial dims), each (H, W, K, K) matrix field
               representing D_μ φ(x) as a matrix at each point
    """
    D = phi.ndim - 1  # number of spatial dimensions
    H, W, d = phi.shape
    K = generators.shape[1]

    # Step 1: φ(x) as matrix field: (H, W, K, K)
    phi_matrix = np.einsum("ijk,klm->ijlm", phi, generators)

    # Step 2: naive derivatives of φ: (H, W, d) per axis
    dphi = [
        (np.roll(phi, -1, axis=axis) - np.roll(phi, 1, axis=axis)) / (2 * dx)
        for axis in range(D)
    ]

    # Step 3: A_μ = ∂_μ φ as matrix field
    A_mu_matrices = [np.einsum("ijk,klm->ijlm", dphi[axis], generators) for axis in range(D)]

    # Step 4: [A_μ, φ]
    commutators = [np.einsum("...ij,...jk->...ik", A, phi_matrix) -
                   np.einsum("...ij,...jk->...ik", phi_matrix, A)
                   for A in A_mu_matrices]

    # Step 5: D_μ φ = ∂_μ φ + [A_μ, φ]
    D_phi = [A_mu + comm for A_mu, comm in zip(A_mu_matrices, commutators)]

    return D_phi  # List of (H, W, K, K)


def compute_field_strength(phi: np.ndarray, generators: np.ndarray, dx: float = 1.0):
    """
    Compute curvature F_{xy} = ∂_x A_y - ∂_y A_x + [A_x, A_y]
    where A_μ = ∂_μ Φ, and Φ = φ^a G_a.

    Args:
        phi:        (H, W, d) — Lie algebra coordinates φ^a(x)
        generators: (d, K, K) — Lie algebra basis
        dx:         lattice spacing

    Returns:
        Dictionary with keys ("xy", ...) → array of shape (H, W, K, K)
    """
    H, W, d = phi.shape
    K = generators.shape[1]

    # Step 1: φ(x) as matrix field: Φ(x) = φ^a(x) G_a
    phi_matrix = np.einsum("ijk,klm->ijlm", phi, generators)  # (H, W, K, K)

    # Step 2: A_x = ∂_x Φ, A_y = ∂_y Φ  — central difference w/ PBCs
    A_x = (np.roll(phi_matrix, -1, axis=0) - np.roll(phi_matrix, 1, axis=0)) / (2 * dx)  # ∂_x Φ
    A_y = (np.roll(phi_matrix, -1, axis=1) - np.roll(phi_matrix, 1, axis=1)) / (2 * dx)  # ∂_y Φ

    # Step 3: Derivatives of A
    dAy_dx = (np.roll(A_y, -1, axis=0) - np.roll(A_y, 1, axis=0)) / (2 * dx)  # ∂_x A_y
    dAx_dy = (np.roll(A_x, -1, axis=1) - np.roll(A_x, 1, axis=1)) / (2 * dx)  # ∂_y A_x

    # Step 4: Commutator [A_x, A_y]
    comm = np.einsum("ijkl,ijln->ijkn", A_x, A_y) - np.einsum("ijkl,ijln->ijkn", A_y, A_x)

    # Step 5: Curvature
    F_xy = dAy_dx - dAx_dy + comm  # shape (H, W, K, K)

    return {"xy": F_xy}



def build_inter_agent_omega(phi_i, phi_j, generators, config=None, use_commutator=False):
    """
    Compute the inter-agent gauge transport operator field Ω_{ij}(x).

    Parameters:
        phi_i: np.ndarray shape (..., d) — φ_i field over spatial domain
        phi_j: np.ndarray shape (..., d) — φ_j field over spatial domain
        generators: np.ndarray shape (d, K, K) — Lie algebra generators
        config: optional config object to override use_commutator
        use_commutator: bool —
            if False, do non-abelian exp(φ_i) @ exp(-φ_j);
            if True,  do abelian exp(φ_i - φ_j)

    Returns:
        omega_ij: np.ndarray shape (..., K, K) — inter-agent transport operator
    """
    # allow config to override the flag
    if config is not None:
        use_commutator = getattr(config, "use_commutator", use_commutator)

    # difference field (..., d)
    delta = phi_i - phi_j

    if not use_commutator:
        # non-abelian: exp(φ_i) @ exp(-φ_j)
        g_i     = exp_lie_algebra_irrep(phi_i, generators, group_name=getattr(config, "group_name", None))
        g_j_inv = exp_lie_algebra_irrep(-phi_j, generators, group_name=getattr(config, "group_name", None))
        return np.matmul(g_i, g_j_inv)

    # abelian shortcut: exp(φ_i - φ_j)
    return exp_lie_algebra_irrep(delta, generators, group_name=getattr(config, "group_name", None))


def compute_pairwise_kl(agents, generators, params, return_pointwise=False):
    """
    Computes KL(q_i || Ω_ij q_j) using full MVG belief transport.
    """
    from generalized_omega import batch_apply_omega
    from natural_gradient_utils import sanitize_sigma
    from generalized_math_utils import kl_divergence

    log_eps = params.get("log_eps", 1e-8)
    overlap_eps = params.get("overlap_eps", 1e-6)
    N = len(agents)
    kl_matrix = np.full((N, N), np.nan)
    pointwise = {} if return_pointwise else None

    for i in range(N):
        A = agents[i]
        mu_i = A.mu_q_field
        sigma_i = A.sigma_q_field
        mask_i = A.mask > overlap_eps

        for j in range(N):
            if i == j:
                kl_matrix[i, j] = 0.0
                continue

            B = agents[j]
            mu_j = B.mu_q_field
            sigma_j = B.sigma_q_field
            mask_j = B.mask > overlap_eps

            overlap = mask_i & mask_j
            if not np.any(overlap):
                continue

            # Extract overlap data
            mu_i_ov = mu_i[overlap]
            sigma_i_ov = sigma_i[overlap]
            mu_j_ov = mu_j[overlap]
            sigma_j_ov = sigma_j[overlap]

            # Compute Ω_ij at each overlap point
            Omega_ij = build_inter_agent_omega(
                phi_i=A.phi[overlap],
                phi_j=B.phi[overlap],
                generators=generators,
                config=params,
            )  # shape (M, K, K)

            # Transport (μ_j, Σ_j) under Ω_ij
            mu_j_t, sigma_j_t = batch_apply_omega(mu_j_ov, sigma_j_ov, Omega_ij)

            # Sanitize for stability
            sigma_i_ov = sanitize_sigma(sigma_i_ov, eps=log_eps)
            sigma_j_t = sanitize_sigma(sigma_j_t, eps=log_eps)

            # Compute KL(q_i || Ω q_j)
            kl_vals = kl_divergence(mu_i_ov, sigma_i_ov, mu_j_t, sigma_j_t)
            kl_matrix[i, j] = float(np.mean(kl_vals))

            if return_pointwise:
                pw_field = np.zeros(mask_i.shape)
                pw_field[overlap] = kl_vals
                pointwise[(i, j)] = pw_field

    return (kl_matrix, pointwise) if return_pointwise else kl_matrix


def compute_pairwise_model_kl(agents, generators, params, return_pointwise=False):
    
    overlap_eps = params.get("overlap_eps", 1e-6)
    N = len(agents)
    kl_matrix = np.full((N, N), np.inf)
    pointwise = {} if return_pointwise else None

    for i in range(N):
        A = agents[i]
        mu_i = A.mu_p_field
        sigma_i = A.sigma_p_field
        mask_i = A.mask > overlap_eps

        for j in range(N):
            if i == j:
                kl_matrix[i, j] = 0.0
                continue

            B = agents[j]
            mu_j = B.mu_p_field
            sigma_j = B.sigma_p_field
            mask_j = B.mask > overlap_eps

            overlap = mask_i & mask_j
            if not np.any(overlap):
                continue

            # Get transported μ_j and Σ_j under φ_model
            Omega_ij = build_inter_agent_omega(
                phi_i = A.phi_model[overlap],
                phi_j = B.phi_model[overlap],
                generators = generators,
                config = params
            )  # (M, K, K)

            mu_j_ov = mu_j[overlap]
            sigma_j_ov = sigma_j[overlap]
            mu_j_t = np.einsum("mab,mb->ma", Omega_ij, mu_j_ov)
            sigma_j_t = transport_covariance_batch(sigma_j_ov, Omega_ij)

            mu_i_ov = mu_i[overlap]
            sigma_i_ov = sigma_i[overlap]

            kl_vals = kl_divergence(mu_i_ov, sigma_i_ov, mu_j_t, sigma_j_t)
            kl_matrix[i, j] = float(np.mean(kl_vals))

            if return_pointwise:
                pw_field = np.zeros(mask_i.shape)
                pw_field[overlap] = kl_vals
                pointwise[(i, j)] = pw_field

    return (kl_matrix, pointwise) if return_pointwise else kl_matrix



