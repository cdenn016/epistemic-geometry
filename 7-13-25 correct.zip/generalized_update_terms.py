# -*- coding: utf-8 -*-
"""
Created on Sat Jul 12 16:20:33 2025

@author: chris and christine
"""
# phi_update_terms.py

from natural_gradient_utils import apply_lie_natural_gradient
from generalized_math_utils import unpack_phi_update_params, clip_and_mask_gradient, apply_regularization_terms
from generalized_omega import compute_curvature_gradient_analytical
from get_generators import get_generators

import numpy as np
import config
from natural_gradient_utils import apply_natural_gradient_batch, compute_fisher_geometry_gradient, sanitize_sigma

from generalized_math_utils import (
    laplacian_field,
   )





# --- Shared Utilities ---

def zero_mu_sigma_like(agent_i, field="model"):
    mu_attr = f"mu_{'p' if field == 'model' else 'q'}_field"
    sigma_attr = f"sigma_{'p' if field == 'model' else 'q'}_field"
    return np.zeros_like(getattr(agent_i, mu_attr)), np.zeros_like(getattr(agent_i, sigma_attr))

def compute_mu_sigma_diff(mu_a, sigma_a, mu_b, sigma_b, direction="a_minus_b"):
    if direction == "a_minus_b":
        d_mu = mu_a - mu_b
        d_sigma = 0.5 * (sigma_a - sigma_b)
    elif direction == "b_minus_a":
        d_mu = mu_b - mu_a
        d_sigma = 0.5 * (sigma_b - sigma_a)
    else:
        raise ValueError(f"Unknown direction: {direction}")
    return d_mu, d_sigma

def apply_mask_to_mu_sigma(mu, sigma, mask):
    mu = np.where(mask[..., None], mu, 0)
    sigma = np.where(mask[..., None, None], sigma, 0)
    return mu, sigma


# --- Individual Gradient Terms ---

def grad_self_field(agent_i, alpha, field_type="model", mask=None):
    if alpha <= 0:
        return zero_mu_sigma_like(agent_i)

    if field_type == "model":
        μ_a, Σ_a = agent_i.mu_p_field, agent_i.sigma_p_field
        μ_b, Σ_b = agent_i.mu_q_field, agent_i.sigma_q_field
    elif field_type == "belief":
        μ_a, Σ_a = agent_i.mu_q_field, agent_i.sigma_q_field
        μ_b, Σ_b = agent_i.mu_p_field, agent_i.sigma_p_field
    else:
        raise ValueError(f"Unknown field_type: {field_type}")

    dμ, dΣ = compute_mu_sigma_diff(μ_a, Σ_a, μ_b, Σ_b, direction="a_minus_b")
    dμ, dΣ = np.nan_to_num(dμ), np.nan_to_num(dΣ)
    delta_mu, delta_sigma = apply_natural_gradient_batch(μ_a, Σ_a, dμ, dΣ)

    if mask is not None:
        dmu_masked, dsigma_masked = apply_mask_to_mu_sigma(delta_mu, delta_sigma, mask)
        return alpha * dmu_masked, alpha * dsigma_masked

    return alpha * delta_mu, alpha * delta_sigma


def grad_feedback_field(agent_i, feedback_weight, field_type="model", mask=None):
    if feedback_weight <= 0:
        return zero_mu_sigma_like(agent_i, field=field_type)

    if field_type == "model":
        μ_a, Σ_a = agent_i.mu_p_field, agent_i.sigma_p_field
        μ_b, Σ_b = agent_i.mu_q_field, agent_i.sigma_q_field
    elif field_type == "belief":
        μ_a, Σ_a = agent_i.mu_q_field, agent_i.sigma_q_field
        μ_b, Σ_b = agent_i.mu_p_field, agent_i.sigma_p_field
    else:
        raise ValueError(f"Unknown field_type: {field_type}")

    dμ, dΣ = compute_mu_sigma_diff(μ_a, Σ_a, μ_b, Σ_b, direction="b_minus_a")

    if mask is not None:
        masked_mu, masked_sigma = apply_mask_to_mu_sigma(dμ, dΣ, mask)
        return feedback_weight * masked_mu, feedback_weight * masked_sigma

    return feedback_weight * dμ, feedback_weight * dΣ



def grad_alignment_field(agent_i, agents, weight, params, field_type="model", mask=None):
    if weight <= 0:
        return zero_mu_sigma_like(agent_i, field=field_type)

    delta_mu, delta_sigma = compute_alignment_gradient(agent_i, agents, params, field_type=field_type)

    if mask is not None:
        masked_mu, masked_sigma = apply_mask_to_mu_sigma(delta_mu, delta_sigma, mask)
        return weight * masked_mu, weight * masked_sigma

    return weight * delta_mu, weight * delta_sigma



def grad_variance_penalty_field(agent_i, weight, field_type="model", mask=None):
    if weight <= 0:
        return zero_mu_sigma_like(agent_i)

    if field_type == "model":
        mu_zero = np.zeros_like(agent_i.mu_p_field)
        sigma = weight * agent_i.sigma_p_field
    elif field_type == "belief":
        mu_zero = np.zeros_like(agent_i.mu_q_field)
        sigma = weight * agent_i.sigma_q_field
    else:
        raise ValueError(f"Unknown field_type: {field_type}")

    if mask is not None:
        _, sigma = apply_mask_to_mu_sigma(mu_zero, sigma, mask)
    return mu_zero, sigma




def combine_field_gradients(agent_i, agents, params, field_type="model"):
    if field_type == "model" and getattr(config, "identical_models", False):
        return zero_mu_sigma_like(agent_i)

    # Load all parameters
    α  = params.get("alpha", config.alpha)
    β  = params.get("model_align_weight", config.model_align_weight) if field_type == "model" else params.get("beta", config.beta)
    fb = params.get("model_feedback_weight", config.model_feedback_weight) if field_type == "model" else params.get("belief_feedback_weight", getattr(config, "belief_feedback_weight", 0.0))
    λ  = params.get("variance_penalty_model_weight", getattr(config, "variance_penalty_model_weight", 0.0)) if field_type == "model" else params.get("variance_penalty_belief_weight", getattr(config, "variance_penalty_belief_weight", 0.0))
    eps = params.get("support_cutoff_eps", config.support_cutoff_eps)

    # Mask
    mask = agent_i.mask > eps
    if not np.any(mask):
        return zero_mu_sigma_like(agent_i)

    # Select fields
    mu_field    = agent_i.mu_p_field if field_type == "model" else agent_i.mu_q_field
    sigma_field = agent_i.sigma_p_field if field_type == "model" else agent_i.sigma_q_field

    # --- Natural-gradient components ---
    grad_mu_nat    = np.zeros_like(mu_field)
    grad_sigma_nat = np.zeros_like(sigma_field)

    if α > 0:
        dμ, dΣ = grad_self_field(agent_i, α, field_type, mask)
        grad_mu_nat += dμ
        grad_sigma_nat += dΣ
    if fb > 0:
        dμ, dΣ = grad_feedback_field(agent_i, fb, field_type, mask)
        grad_mu_nat += dμ
        grad_sigma_nat += dΣ
    if β > 0:
        dμ, dΣ = grad_alignment_field(agent_i, agents, β, params, field_type, mask)
        grad_mu_nat += dμ
        grad_sigma_nat += dΣ

    # --- Apply Fisher preconditioner only to KL terms ---
    delta_mu, delta_sigma = apply_natural_gradient_batch(
        mu_field, sigma_field, grad_mu_nat, grad_sigma_nat
    )

    # --- Add regularization (coordinate) terms AFTER natural gradient ---
    if λ > 0:
        dμ_reg, dΣ_reg = grad_variance_penalty_field(agent_i, λ, field_type, mask)
        delta_mu    += dμ_reg
        delta_sigma += dΣ_reg

    # Final nan sanitization
    delta_mu    = np.nan_to_num(delta_mu, nan=0.0, posinf=1e5, neginf=-1e5)
    delta_sigma = np.nan_to_num(delta_sigma, nan=0.0, posinf=1e5, neginf=-1e5)

    return delta_mu, delta_sigma


# --- Alignment Gradient (raw Euclidean) ---
def compute_alignment_gradient(agent_i, agents, params, field_type="model"):
    """
    Computes raw Euclidean gradient ∇μ, ∇Σ of KL(q_i || Ω q_j) or KL(p_i || Ω̃ p_j),
    without applying natural gradient.

    Parameters:
        agent_i: current agent
        agents: list of all agents
        params: parameter dict
        field_type: "belief" or "model"

    Returns:
        grad_mu_raw:    (H, W, K)
        grad_sigma_raw: (H, W, K, K)
    """
    β = params.get("model_align_weight", config.model_align_weight) if field_type == "model" else params.get("beta", config.beta)
    if β <= 0:
        return np.zeros_like(agent_i.mu_q_field), np.zeros_like(agent_i.sigma_q_field)

    μ_i = agent_i.mu_q_field if field_type == "belief" else agent_i.mu_p_field
    Σ_i = agent_i.sigma_q_field if field_type == "belief" else agent_i.sigma_p_field
    Oi = agent_i._exp_phi       if field_type == "belief" else agent_i._exp_phi_model
    Oj_inv_name = "_exp_neg_phi" if field_type == "belief" else "_exp_neg_phi_model"

    eps = params.get("support_cutoff_eps", config.support_cutoff_eps)
    grad_mu = np.zeros_like(μ_i)
    grad_sigma = np.zeros_like(Σ_i)

    for nb in agent_i.neighbors:
        agent_j = agents[nb["id"]]
        mask_overlap = (agent_i.mask * agent_j.mask > eps)
        if not np.any(mask_overlap):
            continue

        μ_j = agent_j.mu_q_field if field_type == "belief" else agent_j.mu_p_field
        Σ_j = agent_j.sigma_q_field if field_type == "belief" else agent_j.sigma_p_field
        Oj_inv = getattr(agent_j, Oj_inv_name)

        # Compute Ω = O_i @ O_j^{-1}
        Ω = np.einsum("...ij,...jk->...ik", Oi, Oj_inv)  # (H*W, K, K) or (H, W, K, K)
        if Ω.ndim == 3 and Ω.shape[0] == μ_j.shape[0] * μ_j.shape[1]:
            H, W, K = μ_j.shape
            Ω = Ω.reshape(H, W, K, K)
        Ω_T = np.transpose(Ω, (0, 1, 3, 2))

        # Apply transport
        μj_rot = np.einsum("...ij,...j->...i", Ω, μ_j)
        Σj_rot = np.einsum("...ij,...jk,...kl->...il", Ω, Σ_j, Ω_T)

        # Sanitize Σ_i and Σ_j before inverse
        Σ_i_safe = sanitize_sigma(Σ_i, eps=config.eps)
        Σj_safe  = sanitize_sigma(Σj_rot, eps=config.eps)
        try:
            Σj_inv = np.linalg.inv(Σj_safe)
        except np.linalg.LinAlgError:
            continue

        # Compute gradients
        diff = μj_rot - μ_i
        dμ = -np.einsum("...ij,...j->...i", Σj_inv, diff)
        term1 = Σj_inv
        term2 = np.einsum("...ij,...jk,...kl->...il", Σj_inv, Σ_i_safe, Σj_inv)
        dΣ = -0.5 * (term1 - term2)

        grad_mu[mask_overlap]    += β * dμ[mask_overlap]
        grad_sigma[mask_overlap] += β * dΣ[mask_overlap]

    return grad_mu, grad_sigma




def compute_phi_alignment_grad(agent_i, agents, params, field="phi"):
    """
    Computes the alignment gradient component for φ or φ_model.

    Args:
        agent_i: agent whose φ field we're updating
        agents: list of all agents
        params: parameter dict
        field: "phi" or "phi_model"

    Returns:
        grad_align: (H, W, d) alignment gradient in Lie algebra basis (Euclidean)
    """
    β = params.get("beta", config.beta) if field == "phi" else params.get("model_align_weight", config.model_align_weight)
    if β <= 0:
        return np.zeros_like(agent_i.phi if field == "phi" else agent_i.phi_model)

    μ_field = agent_i.mu_q_field if field == "phi" else agent_i.mu_p_field
    Σ_field = agent_i.sigma_q_field if field == "phi" else agent_i.sigma_p_field
    O_exp = agent_i._exp_phi if field == "phi" else agent_i._exp_phi_model
    O_exp_inv = agent_i._exp_neg_phi if field == "phi" else agent_i._exp_neg_phi_model

    eps = params.get("support_cutoff_eps", config.support_cutoff_eps)
    soft_mask = agent_i.mask[..., None]
    if not np.any(soft_mask > eps):
        return np.zeros_like(agent_i.phi if field == "phi" else agent_i.phi_model)

    N, K = np.prod(μ_field.shape[:-1]), μ_field.shape[-1]
    d = config.lie_dim
    Gs = params.get("generators", get_generators(config.group_name, K))

    μ_i = μ_field.reshape(N, K)
    Σ_i = Σ_field.reshape(N, K, K)
    Oi = O_exp.reshape(N, K, K)
    Oj_inv = O_exp_inv.reshape(N, K, K)

    flat_grad = np.zeros((N, d), dtype=μ_field.dtype)

    for nb in agent_i.neighbors:
        agent_j = agents[nb["id"]]
        overlap = (agent_i.mask * agent_j.mask > eps)
        idxs = np.flatnonzero(overlap.reshape(-1))
        if idxs.size == 0:
            continue

        μ_j_field = agent_j.mu_q_field if field == "phi" else agent_j.mu_p_field
        Σ_j_field = agent_j.sigma_q_field if field == "phi" else agent_j.sigma_p_field

        μ_j = μ_j_field.reshape(N, K)[idxs]
        Σ_j = Σ_j_field.reshape(N, K, K)[idxs]
        μ_i_ = μ_i[idxs]
        Σ_i_ = Σ_i[idxs]

        Ω = np.einsum("mij,mjk->mik", Oi[idxs], Oj_inv[idxs])
        μj_rot = np.einsum("mij,mj->mi", Ω, μ_j)
        Σj_rot = np.einsum("mij,mjk,mkl->mil", Ω, Σ_j, Ω.transpose(0, 2, 1))

        Σ_i_ = sanitize_sigma(Σ_i_, eps=1e-6, debug=config.debug_sanitize_sigma)
        Σj_rot = sanitize_sigma(Σj_rot, eps=1e-6, debug=config.debug_sanitize_sigma)

        diff = μj_rot - μ_i_

        H = np.einsum("aij,mjk->maik", Gs, Oi[idxs])           # Lie generators rotated
        dΩ = np.einsum("maik,mkl->mail", H, Oj_inv[idxs])      # ∂Ω/∂φ^a

        for a in range(d):
            dΩa = dΩ[:, a]
            dμj_rot = np.einsum("mij,mj->mi", dΩa, μ_j)
            dΣj_rot = (
                np.einsum("mij,mjk,mkl->mil", dΩa, Σ_j, Ω.transpose(0, 2, 1)) +
                np.einsum("mij,mjk,mkl->mil", Ω, Σ_j, dΩa.transpose(0, 2, 1))
            )

            # Use np.linalg.solve instead of inverse
            try:
                solved_dμ = np.linalg.solve(Σj_rot, dμj_rot)
                solved_diff = np.linalg.solve(Σj_rot, diff)
                A = np.linalg.solve(Σj_rot, dΣj_rot)    # (M, K, K)
                trace_term = np.einsum("mii->m", A)     # (M,)

                quad_term = np.einsum("mi,mi->m", solved_diff, dμj_rot)
                flat_grad[idxs, a] += β * 0.5 * (trace_term + 2 * quad_term)
            except np.linalg.LinAlgError:
                if config.debug:
                    print(f"[φ-grad skipped] Singular Σj_rot for neighbor {nb['id']}")
                continue

    return flat_grad.reshape(*μ_field.shape[:-1], d)

def compute_phi_model_alignment_gradient(agent_i, agents, params, field="model"):
    """
    Compute the alignment gradient ∇_{φ̃} KL(fiber_i ‖ Ω̃_{ij} fiber_j)
    where fiber = q if field='belief', and p if field='model'.

    Args:
        agent_i: agent whose φ_model field is being updated
        agents: all agents
        params: dict of parameters
        field: 'model' or 'belief' — determines whether p or q fibers are aligned

    Returns:
        grad: (H, W, d) — Euclidean alignment gradient w.r.t. φ_model
    """
    β = params.get("model_align_weight", config.model_align_weight)
    if β <= 0:
        return np.zeros_like(agent_i.phi_model)

    # Fiber to align: p vs q
    μ_field = agent_i.mu_p_field if field == "model" else agent_i.mu_q_field
    Σ_field = agent_i.sigma_p_field if field == "model" else agent_i.sigma_q_field

    O_exp = agent_i._exp_phi_model
    O_exp_inv = agent_i._exp_neg_phi_model

    eps = params.get("support_cutoff_eps", config.support_cutoff_eps)
    soft_mask = agent_i.mask[..., None]
    if not np.any(soft_mask > eps):
        return np.zeros_like(agent_i.phi_model)

    N, K = np.prod(μ_field.shape[:-1]), μ_field.shape[-1]
    d = config.lie_dim
    Gs = params.get("generators", get_generators(config.group_name, K))

    μ_i = μ_field.reshape(N, K)
    Σ_i = Σ_field.reshape(N, K, K)
    Oi = O_exp.reshape(N, K, K)
    Oj_inv = O_exp_inv.reshape(N, K, K)

    flat_grad = np.zeros((N, d), dtype=μ_field.dtype)

    for nb in agent_i.neighbors:
        agent_j = agents[nb["id"]]
        overlap = (agent_i.mask * agent_j.mask > eps)
        idxs = np.flatnonzero(overlap.reshape(-1))
        if idxs.size == 0:
            continue

        μ_j_field = agent_j.mu_p_field if field == "model" else agent_j.mu_q_field
        Σ_j_field = agent_j.sigma_p_field if field == "model" else agent_j.sigma_q_field

        μ_j = μ_j_field.reshape(N, K)[idxs]
        Σ_j = Σ_j_field.reshape(N, K, K)[idxs]
        μ_i_ = μ_i[idxs]
        Σ_i_ = Σ_i[idxs]

        Ω = np.einsum("mij,mjk->mik", Oi[idxs], Oj_inv[idxs])
        μj_rot = np.einsum("mij,mj->mi", Ω, μ_j)
        Σj_rot = np.einsum("mij,mjk,mkl->mil", Ω, Σ_j, Ω.transpose(0, 2, 1))

        Σ_i_ = sanitize_sigma(Σ_i_, eps=1e-6, debug=config.debug_sanitize_sigma)
        Σj_rot = sanitize_sigma(Σj_rot, eps=1e-6, debug=config.debug_sanitize_sigma)

        diff = μj_rot - μ_i_

        H = np.einsum("aij,mjk->maik", Gs, Oi[idxs])
        dΩ = np.einsum("maik,mkl->mail", H, Oj_inv[idxs])  # ∂Ω̃/∂φ̃^a

        for a in range(d):
            dΩa = dΩ[:, a]
            dμj_rot = np.einsum("mij,mj->mi", dΩa, μ_j)
            dΣj_rot = (
                np.einsum("mij,mjk,mkl->mil", dΩa, Σ_j, Ω.transpose(0, 2, 1)) +
                np.einsum("mij,mjk,mkl->mil", Ω, Σ_j, dΩa.transpose(0, 2, 1))
            )

            try:
                solved_dμ = np.linalg.solve(Σj_rot, dμj_rot)
                solved_diff = np.linalg.solve(Σj_rot, diff)
                traceA = np.linalg.solve(Σj_rot, dΣj_rot)     # shape (M, K, K)
                trace_term = np.einsum("mii->m", traceA)      # per-sample trace

                quad_term = np.einsum("mi,mi->m", solved_diff, dμj_rot)
                flat_grad[idxs, a] += β * 0.5 * (trace_term + 2 * quad_term)
            except np.linalg.LinAlgError:
                if config.debug:
                    print(f"[φ̃-grad skipped] Singular Σj_rot for neighbor {nb['id']}")
                continue

    return flat_grad.reshape(*μ_field.shape[:-1], d)

from generalized_omega import compute_curvature_gradient_analytical  # ensure this is imported

def compute_phi_update(agent_i, agents, params, field="phi"):
    """
    Unified update function for φ (belief alignment) and φ̃ (model alignment).
    Supports curvature, mass, coupling, and optional Fisher geometry terms.
    
    Applies natural gradient ONLY to the alignment term.

    Args:
        agent_i: agent being updated
        agents: list of all agents
        params: dict of parameters
        field: "phi" or "phi_model"

    Returns:
        grad: (H, W, d) Lie-algebra gradient for φ or φ̃
    """
    if field == "phi_model" and getattr(config, "identical_models", False):
        return np.zeros_like(agent_i.phi_model)

    # Unpack parameters
    unpacked = unpack_phi_update_params(params, field=field)
    β         = params.get("beta", config.beta) if field == "phi" else params.get("model_align_weight", config.model_align_weight)
    κ         = unpacked["κ"]
    gw        = unpacked["gw"]
    curv_w    = unpacked["curv_weight"]
    clip_th   = unpacked["grad_clip_threshold"]
    eps       = unpacked["overlap_eps"]
    debug     = unpacked["debug"]

    # Select φ, φ̃, mask
    phi        = agent_i.phi if field == "phi" else agent_i.phi_model
    phi_tilde  = agent_i.phi_model if field == "phi" else agent_i.phi
    soft_mask  = agent_i.mask[..., None]

    if not np.any(soft_mask > eps):
        return np.zeros_like(phi)

    grad = np.zeros_like(phi)

    # Step 1: Alignment gradient with natural gradient preconditioning
    if β > 0:
        align_fn = compute_phi_alignment_grad if field == "phi" else compute_phi_model_alignment_gradient
        G_inv = params.get("G_inv_phi", None) if field == "phi" else params.get("G_inv_phi_model", None)
        grad_align = align_fn(agent_i, agents, params, field=field)
        grad_align_nat = apply_lie_natural_gradient(phi, grad_align, G_inv=G_inv)
        grad += β * grad_align_nat

    # Step 2: Add curvature gradient ∇‖F‖²
    if curv_w > 0:
        generators = params.get("generators", get_generators(config.group_name, config.K))
        grad_curvature = compute_curvature_gradient_analytical(phi, generators, dx=1.0)
        grad += curv_w * grad_curvature * soft_mask

    # Step 3: Scalar regularization terms
    if gw > 0:
        grad += 2 * gw * phi * soft_mask  # φ² mass term
    if κ > 0:
        grad += 2 * κ * (phi - phi_tilde) * soft_mask  # coupling term

    # Step 4: Fisher geometry term (Euclidean)
    fisher_weight = params.get(
        "fisher_geometry_weight" if field == "phi" else "fisher_model_geometry_weight",
        getattr(config, "fisher_geometry_weight" if field == "phi" else "fisher_model_geometry_weight", 0.0)
    )
    if fisher_weight > 0:
        fisher_fn = compute_phi_fisher_gradient if field == "phi" else compute_phi_model_fisher_gradient
        grad += fisher_weight * fisher_fn(agent_i, agents, params)

    # Step 5: Final clip and mask
    return clip_and_mask_gradient(grad, soft_mask, clip_th, eps)





# Optional: legacy aliases
def compute_phi_fisher_gradient(agent_i, agents, params):
    return compute_fisher_geometry_gradient(agent_i, agents, params, field="phi")

def compute_phi_model_fisher_gradient(agent_i, agents, params):
    return compute_fisher_geometry_gradient(agent_i, agents, params, field="phi_model")


# Convenient aliases
def compute_phi_alignment_gradient(agent_i, agents, params):
    return compute_phi_update(agent_i, agents, params, field="phi")

def compute_phi_model_update(agent_i, agents, params):
    return compute_phi_update(agent_i, agents, params, field="phi_model")
