# -*- coding: utf-8 -*-
"""
Created on Sat Jul 12 15:59:56 2025

@author: chris and christine
"""

# === generalized_update_rules.py (refactor patch) ===
import numpy as np
import config
from joblib import Parallel, delayed

from natural_gradient_utils import (
    apply_natural_gradient_batch,
    apply_lie_natural_gradient,
    sanitize_sigma,
)
from generalized_update_terms import (
    combine_field_gradients,
    
    compute_phi_alignment_gradient,
    compute_phi_model_update,
)
from generalized_omega import exp_lie_algebra_irrep

from scipy.linalg import solve_triangular  # or np.linalg.solve per batch

def batch_matrix_inverse(mat_batch):
    """
    Solve X = A⁻¹ using A·X = I for a batch of (N, K, K) matrices.
    """
    N, K, _ = mat_batch.shape
    I = np.eye(K)[None, :, :]
    return np.linalg.solve(mat_batch, np.broadcast_to(I, (N, K, K)))


def preprocess_agent_fields(agent, generators, params):
    """Sanitize sigmas, cache Fisher info, compute exp(φ), exp(−φ)"""
    e_belief = params.get("e_belief", config.e_belief)
    e_model  = params.get("e_model",  config.e_model)

    agent.clear_omega_cache()
    agent.grid_shape = agent.phi.shape[:-1]

    flat_phi       = agent.phi.reshape(-1, agent.phi.shape[-1]) / e_belief
    flat_phi_model = agent.phi_model.reshape(-1, agent.phi_model.shape[-1]) / e_model

    agent._exp_phi       = exp_lie_algebra_irrep(flat_phi, generators)
    agent._exp_phi_model = exp_lie_algebra_irrep(flat_phi_model, generators)
    agent._exp_neg_phi       = batch_matrix_inverse(agent._exp_phi)
    agent._exp_neg_phi_model = batch_matrix_inverse(agent._exp_phi_model)

    # Sanitize covariance fields
    agent.sigma_q_field = sanitize_sigma(agent.sigma_q_field, eps=config.eps, debug=config.debug_sanitize_sigma)
    agent.sigma_p_field = sanitize_sigma(agent.sigma_p_field, eps=config.eps, debug=config.debug_sanitize_sigma)

    # Safe inverse: fallback to identity on failure
    try:
        agent.cached_fisher_q = np.linalg.inv(agent.sigma_q_field)
    except np.linalg.LinAlgError:
        if config.debug:
            print("[!] Failed to invert sigma_q_field — using identity fallback")
        H, W, K, _ = agent.sigma_q_field.shape
        agent.cached_fisher_q = np.tile(np.eye(K)[None, None, :, :], (H, W, 1, 1))

    try:
        agent.cached_fisher_p = np.linalg.inv(agent.sigma_p_field)
    except np.linalg.LinAlgError:
        if config.debug:
            print("[!] Failed to invert sigma_p_field — using identity fallback")
        H, W, K, _ = agent.sigma_p_field.shape
        agent.cached_fisher_p = np.tile(np.eye(K)[None, None, :, :], (H, W, 1, 1))




def compute_all_gradients(i, agents, params):
    ai = agents[i]
    return (
        combine_field_gradients(ai, agents, params, field_type="belief"),  # now returns Δμ_q, ΔΣ_q
        combine_field_gradients(ai, agents, params, field_type="model"),   # now returns Δμ_p, ΔΣ_p
        compute_phi_alignment_gradient(ai, agents, params),
        compute_phi_model_update(ai, agents, params),
    )


def apply_phi_updates(agent, grad_phi, grad_phi_m, mask, params):
    mask_exp = mask[..., None]
    eta_phi_model = params.get("eta_model_phi", config.eta_model_phi)

    # φ update (NO apply_lie_natural_gradient here — already done inside compute_phi_update)
    grad_norm_phi = np.linalg.norm(grad_phi[mask > config.support_cutoff_eps]) + 1e-8
    eta_phi_tuned = np.clip(
        config.eta_base_phi / (1.0 + config.eta_phi_adaptive_scaling * grad_norm_phi),
        config.eta_phi_min,
        config.eta_base_phi,
    )
    delta_phi = eta_phi_tuned * grad_phi
    agent.phi -= delta_phi * mask_exp

    # Optional clip
    if (thresh := getattr(config, "phi_clip_threshold", 0.0)) > 0:
        norm = np.linalg.norm(agent.phi, axis=-1, keepdims=True)
        clip = (norm > thresh)[..., 0]
        scale = thresh / (norm[..., 0][clip] + 1e-8)
        agent.phi[clip] *= scale[:, None]

    # φ_model update (NO apply_lie_natural_gradient here — already done inside compute_phi_update)
    grad_norm_phi_m = np.linalg.norm(grad_phi_m[mask > config.support_cutoff_eps]) + 1e-8
    eta_phi_model_tuned = np.clip(
        eta_phi_model / (1.0 + 0.1 * grad_norm_phi_m),
        1e-6, eta_phi_model,
    )
    delta_phi_m = eta_phi_model_tuned * grad_phi_m
    agent.phi_model -= delta_phi_m * mask_exp

    if (thresh := getattr(config, "phi_model_clip_threshold", 0.0)) > 0:
        norm_m = np.linalg.norm(agent.phi_model, axis=-1, keepdims=True)
        clip_m = (norm_m > thresh)[..., 0]
        scale_m = thresh / (norm_m[..., 0][clip_m] + 1e-8)
        agent.phi_model[clip_m] *= scale_m[:, None]



def synchronous_step(agents, generators, params=None, n_jobs=1):
    params = params or {}
    N = len(agents)

    for A in agents:
        preprocess_agent_fields(A, generators, params)

    mask_list = [A.mask for A in agents]

    grads = Parallel(n_jobs=n_jobs, backend="loky", batch_size=8)(
        delayed(compute_all_gradients)(i, agents, params) for i in range(N)
    )
    q_updates, p_updates, phi_grads, phi_m_grads = zip(*grads)

    eta_q = params.get("eta_q", config.eta_q)
    eta_p = params.get("eta_p", config.eta_p)

    for i, agent in enumerate(agents):
        mask_mu    = mask_list[i][..., None]
        mask_sigma = mask_list[i][..., None, None]

        Δμ_q, ΔΣ_q = q_updates[i]
        Δμ_p, ΔΣ_p = p_updates[i]

        agent.mu_q_field    -= eta_q * Δμ_q * mask_mu
        agent.sigma_q_field -= eta_q * ΔΣ_q * mask_sigma
        agent.mu_p_field    -= eta_p * Δμ_p * mask_mu
        agent.sigma_p_field -= eta_p * ΔΣ_p * mask_sigma

        apply_phi_updates(agent, phi_grads[i], phi_m_grads[i], mask_list[i], params)

    return agents
