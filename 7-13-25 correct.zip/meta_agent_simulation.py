

import numpy as np
from generalized_agent_schema import Agent
from generalized_agent_distributions import get_fiber_basis, initialize_multivariate_gaussian_distribution
import config

import os
import numpy as np
from meta_agent_aggregation import build_meta_agents_from_clusters
from generalized_agents import initialize_neighbors
from generalized_diagnostics_metrics import log_all_metrics_fused
from generalized_update_rules import synchronous_step
from generalized_io_utils import save_checkpoint, save_field_dumps
from generalized_math_utils import ensure_dir
from generalized_simulation import get_generators
import config





def run_recursive_simulation(agents, labels, run_dir="meta_checkpoints", steps=50):
    """
    Run a recursive simulation on meta-agents.
    Args:
        agents: original list of Agent objects
        labels: cluster labels for each agent (from meta_agents.py)
        run_dir: output folder
        steps: number of steps to simulate
    """
    ensure_dir(run_dir)
    generators = get_generators(config.group_name, config.K)

    # STEP 1: Aggregate meta-agent objects
    meta_agents = build_meta_agents_from_clusters(agents, labels, generators)
    initialize_neighbors(meta_agents)

    print(f"[INIT] {len(meta_agents)} meta-agents initialized.")

    for step in range(steps):
        print(f"\n[STEP {step}] -----------------------------")

        # Step 2: Belief & model updates (natural gradient)
        synchronous_step(meta_agents, generators, step=step)

        # Step 3: Log metrics and fields
        log_all_metrics_fused(meta_agents, step, outdir=run_dir)
        save_checkpoint(meta_agents, step, outdir=run_dir)
        save_field_dumps(meta_agents, step, outdir=run_dir)

    print(f"[DONE] Recursive simulation completed. Outputs → {run_dir}")
