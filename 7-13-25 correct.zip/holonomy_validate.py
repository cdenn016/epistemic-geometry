# -*- coding: utf-8 -*-
"""
Validate belief transport sequences (μ, Σ) from holonomy experiments.

Created on Tue Jul  8 14:35:21 2025
@author: chris and christine
"""

import numpy as np
import os
import matplotlib.pyplot as plt
from pathlib import Path
import pickle
from sklearn.decomposition import PCA

TRANSPORT_LOG_DIR = Path("holonomy_experiments/transport_logs")
DEFAULT_FILENAME = "step00005_cycle_0_2_1_3_0.pkl"

def load_transport_sequences(filepath):
    path = Path(filepath)
    if path.suffix == ".npz":
        data = np.load(path)
        mu_seq = data["mu_seq"]
        sigma_seq = data["sigma_seq"]
    elif path.suffix == ".pkl":
        with open(path, "rb") as f:
            payload = pickle.load(f)
        mu_seq = np.array(payload["mu_seq"])
        sigma_seq = np.array(payload["sigma_seq"])
    else:
        raise ValueError(f"Unsupported file type: {path.suffix}")
    return mu_seq, sigma_seq

def validate_transport(mu_seq, sigma_seq):
    print("─" * 60)
    print(f"[μ] shape: {mu_seq.shape}")
    mu_std = np.std(mu_seq, axis=0)
    mu_norm = np.linalg.norm(mu_seq, axis=-1)
    print(f"[μ] std deviation (mean ± std): {np.mean(mu_std):.3e} ± {np.std(mu_std):.3e}")
    print(f"[μ] norm ‖μ‖ range: {mu_norm.min():.2f} → {mu_norm.max():.2f}")
    frozen_mu_dims = np.where(mu_std < 1e-6)[0]
    if len(frozen_mu_dims) > 0:
        print(f"[μ] frozen dims (std < 1e-6): {list(frozen_mu_dims)}")

    # PCA analysis
    pca = PCA()
    try:
        pca.fit(mu_seq)
        explained = pca.explained_variance_ratio_
        print(f"[PCA] variance explained by first 5: {explained[:5]}")
        if explained[0] > 0.95:
            print(f"[PCA] ⚠ dominant single direction ({explained[0]:.2f})")
    except Exception as e:
        print(f"[PCA] failed: {e}")

    # Σ diagnostics
    print("─" * 60)
    print(f"[Σ] shape: {sigma_seq.shape}")
    traces = np.trace(sigma_seq, axis1=-2, axis2=-1)
    print(f"[Σ] trace range: {traces.min():.2f} → {traces.max():.2f}")
    bad_steps = []
    for t, Σ in enumerate(sigma_seq):
        eigvals = np.linalg.eigvalsh(Σ)
        if np.any(eigvals < 1e-6):
            bad_steps.append(t)
    if bad_steps:
        print(f"[Σ] ⚠ frozen eigenvalues (< 1e-6) at steps: {bad_steps}")
    else:
        print("[Σ] all SPD: no small eigenvalues found")

    # condition number
    cond_nums = [np.linalg.cond(Σ) for Σ in sigma_seq]
    print(f"[Σ] condition number: mean = {np.mean(cond_nums):.2e}, max = {np.max(cond_nums):.2e}")
    print("─" * 60)

def main():
    path = TRANSPORT_LOG_DIR / DEFAULT_FILENAME
    if not path.exists():
        print(f"[ERROR] File not found: {path}")
        available = sorted(TRANSPORT_LOG_DIR.glob("*.pkl"))
        if not available:
            print("No transport logs found.")
        else:
            print("Available transport logs:")
            for p in available:
                print("  -", p.name)
        return

    mu_seq, sigma_seq = load_transport_sequences(path)
    print(f"[LOADED] {path}")
    validate_transport(mu_seq, sigma_seq)

if __name__ == "__main__":
    main()
