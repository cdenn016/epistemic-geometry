import numpy as np
import config
from get_generators import get_generators
from generalized_math_utils import laplacian_field
from natural_gradient_utils import sanitize_sigma
from generalized_omega import batch_apply_omega
from natural_gradient_utils import apply_lie_natural_gradient  # ← Add this at the top
from natural_gradient_utils import apply_natural_gradient_batch
from generalized_omega import compute_field_strength,compute_curvature_gradient_analytical


from joblib import Parallel, delayed, parallel_backend


def compute_alignment_gradient_parallelized(agent_i, agents, params, field_type="belief"):
    """
    Parallelized version of compute_alignment_gradient using joblib threading.
    See original docstring for semantics.
    """
    if field_type == "belief":
        β = params.get("beta", config.beta)
        mu_i_field     = agent_i.mu_q_field
        sigma_i_field  = agent_i.sigma_q_field
        Omega_i        = agent_i.Omega
        mu_j_name      = "mu_q_field"
        sigma_j_name   = "sigma_q_field"
        Omega_inv_name = "Omega_inv"
    elif field_type == "model":
        β = params.get("model_align_weight", config.model_align_weight)
        mu_i_field     = agent_i.mu_p_field
        sigma_i_field  = agent_i.sigma_p_field
        Omega_i        = agent_i.Omega_model
        mu_j_name      = "mu_p_field"
        sigma_j_name   = "sigma_p_field"
        Omega_inv_name = "Omega_model_inv"
    else:
        raise ValueError(f"Invalid field_type: {field_type}")

    if β <= 0:
        return np.zeros_like(mu_i_field), np.zeros_like(sigma_i_field)

    eps = params.get("overlap_eps", config.support_cutoff_eps)
    grad_clip = getattr(config, "gradient_clip", 1e4)
    debug = params.get("debug", False) or getattr(config, "debug_gradients", False)

    mask_i = agent_i.mask > eps
    if not np.any(mask_i):
        return np.zeros_like(mu_i_field), np.zeros_like(sigma_i_field)

    H, W, K = mu_i_field.shape
    grad_mu    = np.zeros((H, W, K), dtype=mu_i_field.dtype)
    grad_sigma = np.zeros((H, W, K, K), dtype=sigma_i_field.dtype)

    def process_neighbor(nb):
        agent_j = agents[nb["id"]]
        mask_j = agent_j.mask > eps
        overlap = mask_i & mask_j
        if not np.any(overlap):
            return None

        μi  = mu_i_field[overlap]
        Σi  = sigma_i_field[overlap]
        μj  = getattr(agent_j, mu_j_name)[overlap]
        Σj  = getattr(agent_j, sigma_j_name)[overlap]

        Ωi     = Omega_i[overlap]
        Ωj_inv = getattr(agent_j, Omega_inv_name)[overlap]
        Ω      = np.einsum("mij,mjk->mik", Ωi, Ωj_inv)

        μj_rot, Σj_rot = batch_apply_omega(μj, Σj, Ω)

        dμ = μi - μj_rot
        dΣ = 0.5 * (Σj_rot - Σi)

        dμ = np.nan_to_num(dμ, nan=0.0, posinf=grad_clip, neginf=-grad_clip)
        dΣ = np.nan_to_num(dΣ, nan=0.0, posinf=grad_clip, neginf=-grad_clip)
        dμ = np.clip(dμ, -grad_clip, grad_clip)
        dΣ = np.clip(dΣ, -grad_clip, grad_clip)

        delta_mu, delta_sigma = apply_natural_gradient_batch(μi, Σi, dμ, dΣ)

        coords = np.argwhere(overlap)
        return coords, delta_mu, delta_sigma

    # Threaded parallel loop over neighbors
    with parallel_backend("threading"):
        results = Parallel(n_jobs=config.num_cores)(
            delayed(process_neighbor)(nb) for nb in agent_i.neighbors
        )

    for res in results:
        if res is None:
            continue
        coords, delta_mu, delta_sigma = res
        for n in range(len(coords)):
            i_, j_ = coords[n]
            grad_mu[i_, j_]    += β * delta_mu[n]
            grad_sigma[i_, j_] += β * delta_sigma[n]

    # Optional debug
    #if debug:
        #print(f"[∇μ_align:{field_type}] Agent {agent_i.id}: ‖∇μ‖ = {np.linalg.norm(grad_mu):.4e}")
        #print(f"[∇Σ_align:{field_type}] Agent {agent_i.id}: ‖∇Σ‖ = {np.linalg.norm(grad_sigma):.4e}")

    return grad_mu, grad_sigma


def compute_self_gradient(agent_i, params):
    """
    Compute Fisher-natural gradient ∇_μ and ∇_Σ for KL(q || p),
    using Fisher metric over the agent's masked region.

    Assumes σ_q and σ_p have already been sanitized (SPD).
    """
    alpha = params.get("alpha", config.alpha)
    support_eps = params.get("support_cutoff_eps", config.support_cutoff_eps)
    debug = params.get("debug", False) or getattr(config, "debug_gradients", False)

    mask = agent_i.mask > support_eps
    if not np.any(mask) or alpha <= 0:
        return (
            np.zeros_like(agent_i.mu_q_field),
            np.zeros_like(agent_i.sigma_q_field),
        )

    mu_q    = agent_i.mu_q_field        # (H, W, K)
    sigma_q = agent_i.sigma_q_field     # (H, W, K, K)
    mu_p    = agent_i.mu_p_field
    sigma_p = agent_i.sigma_p_field

    # Check for finite entries in sigma_q (assumes sanitize_sigma was applied upstream)
    assert np.all(np.isfinite(sigma_q)), "σ_q contains invalid values"

    diff_mu    = mu_q - mu_p
    diff_sigma = 0.5 * (sigma_p - sigma_q)

    # Replace NaNs/Infs with zeros before Fisher preconditioning
    diff_mu    = np.nan_to_num(diff_mu, nan=0.0, posinf=0.0, neginf=0.0)
    diff_sigma = np.nan_to_num(diff_sigma, nan=0.0, posinf=0.0, neginf=0.0)

    # Fisher preconditioning
    delta_mu, delta_sigma = apply_natural_gradient_batch(
        mu_field=mu_q,
        sigma_field=sigma_q,
        grad_mu_field=diff_mu,
        grad_sigma_field=diff_sigma,
    )

    # Optional: variance penalty shrinkage
    variance_penalty = params.get("variance_penalty_belief_weight", getattr(config, "variance_penalty_belief_weight", 0.0))
    if variance_penalty > 0:
        delta_sigma += variance_penalty * sigma_q

    # Apply mask
    mask_sigma = np.broadcast_to(mask[..., None, None], delta_sigma.shape)
    delta_sigma[~mask_sigma] = 0


    #if debug:
        #norm_mu = np.linalg.norm(delta_mu[mask])
        #mask_sigma = np.broadcast_to(mask[..., None, None], delta_sigma.shape)
       # norm_sigma = np.linalg.norm(delta_sigma[mask_sigma])
       # print(f"[mu_self] Agent {agent_i.id}:mu = {norm_mu:.4e}")
      #  print(f"[sig_self] Agent {agent_i.id}: sig = {norm_sigma:.4e}")


    return alpha * delta_mu, alpha * delta_sigma


def compute_alignment_gradient(agent_i, agents, params, field_type="belief"):
    """
    Compute natural gradient ∇_μ and ∇_Σ for:
        KL(q_i || Ω q_j)    if field_type = "belief"
        KL(p_i || Ω̃ p_j)   if field_type = "model"

    Uses Fisher geometry (natural gradient) over overlap regions.

    Args:
        agent_i: focal agent
        agents: list of all agents
        params: dict of config parameters
        field_type: "belief" or "model"

    Returns:
        grad_mu:    (H, W, K)     ∇_μ field (natural gradient)
        grad_sigma: (H, W, K, K)  ∇_Σ field (natural gradient)
    """
    if field_type == "belief":
        β = params.get("beta", config.beta)
        mu_i_field     = agent_i.mu_q_field
        sigma_i_field  = agent_i.sigma_q_field
        Omega_i        = agent_i.Omega
        mu_j_name      = "mu_q_field"
        sigma_j_name   = "sigma_q_field"
        Omega_inv_name = "Omega_inv"
    elif field_type == "model":
        β = params.get("model_align_weight", config.model_align_weight)
        mu_i_field     = agent_i.mu_p_field
        sigma_i_field  = agent_i.sigma_p_field
        Omega_i        = agent_i.Omega_model
        mu_j_name      = "mu_p_field"
        sigma_j_name   = "sigma_p_field"
        Omega_inv_name = "Omega_model_inv"
    else:
        raise ValueError(f"Invalid field_type: {field_type}")

    if β <= 0:
        return np.zeros_like(mu_i_field), np.zeros_like(sigma_i_field)

    eps = params.get("overlap_eps", config.support_cutoff_eps)
    grad_clip = getattr(config, "gradient_clip", 1e4)
    debug = params.get("debug", False) or getattr(config, "debug_gradients", False)

    mask_i = agent_i.mask > eps
    if not np.any(mask_i):
        return np.zeros_like(mu_i_field), np.zeros_like(sigma_i_field)

    grad_mu = np.zeros_like(mu_i_field)
    grad_sigma = np.zeros_like(sigma_i_field)

    for nb in agent_i.neighbors:
        agent_j = agents[nb["id"]]
        mask_j = agent_j.mask > eps
        overlap = mask_i & mask_j
        if not np.any(overlap):
            continue

        μi  = mu_i_field[overlap]
        Σi  = sigma_i_field[overlap]  # ← trust upstream sanitize
        μj  = getattr(agent_j, mu_j_name)[overlap]
        Σj  = getattr(agent_j, sigma_j_name)[overlap]

        Ωi     = Omega_i[overlap]
        Ωj_inv = getattr(agent_j, Omega_inv_name)[overlap]
        Ω      = np.einsum("mij,mjk->mik", Ωi, Ωj_inv)

        μj_rot, Σj_rot = batch_apply_omega(μj, Σj, Ω)  # ← sanitize inside this function if needed

        dμ = μi - μj_rot
        dΣ = 0.5 * (Σj_rot - Σi)


        dμ = np.nan_to_num(dμ, nan=0.0, posinf=grad_clip, neginf=-grad_clip)
        dΣ = np.nan_to_num(dΣ, nan=0.0, posinf=grad_clip, neginf=-grad_clip)
        dμ = np.clip(dμ, -grad_clip, grad_clip)
        dΣ = np.clip(dΣ, -grad_clip, grad_clip)

        delta_mu, delta_sigma = apply_natural_gradient_batch(
            mu_field=μi,
            sigma_field=Σi,
            grad_mu_field=dμ,
            grad_sigma_field=dΣ,
        )

        coords = np.argwhere(overlap)
        for n in range(len(coords)):
            i_, j_ = coords[n]
            grad_mu[i_, j_]    += β * delta_mu[n]
            grad_sigma[i_, j_] += β * delta_sigma[n]

  #  if debug:
   #     norm_mu = np.linalg.norm(grad_mu)
   #     norm_sigma = np.linalg.norm(grad_sigma)
    #    print(f"[∇μ_align:{field_type}] Agent {agent_i.id}: ‖Δμ‖ = {norm_mu:.4e}")
   #     print(f"[∇Σ_align:{field_type}] Agent {agent_i.id}: ‖ΔΣ‖ = {norm_sigma:.4e}")

    return grad_mu, grad_sigma


def compute_beliefs_gradient(agent_i, agents, params):
    """
    Compute total Fisher-preconditioned gradients ∇_μ and ∇_Σ for belief parameters q_i:
    
        ∇μ_total    = ∇μ_self + ∇μ_align
        ∇Σ_total    = ∇Σ_self + ∇Σ_align

    This corresponds to minimizing:
        F = α · D_KL(q_i || p_i) + β · D_KL(q_i || Ω_{ij} q_j)

    Args:
        agent_i: Agent whose gradient we compute
        agents:  List of all agents
        params:  Dictionary of config parameters

    Returns:
        grad_mu_total:    (H, W, K) Fisher-natural gradient on μ
        grad_sigma_total: (H, W, K, K) Fisher-natural gradient on Σ
    """
    grad_mu_self, grad_sigma_self   = compute_self_gradient(agent_i, params)
    
    if getattr(config, "use_parallel_alignment_gradient", False):
        
        grad_mu_align, grad_sigma_align = compute_alignment_gradient_parallelized(agent_i, agents, params, field_type="belief")
    else:
        grad_mu_align, grad_sigma_align = compute_alignment_gradient(agent_i, agents, params, field_type="belief")


    grad_mu_total    = grad_mu_self + grad_mu_align
    grad_sigma_total = grad_sigma_self + grad_sigma_align

    # Sanitize to prevent explosion
    grad_mu_total = np.nan_to_num(grad_mu_total, nan=0.0, posinf=1e5, neginf=-1e5)
    grad_sigma_total = np.nan_to_num(grad_sigma_total, nan=0.0, posinf=1e5, neginf=-1e5)

   # if params.get("debug", False) or getattr(config, "debug_gradients", False):
    #    print(f"[∇μ_q] Agent {agent_i.id}:")
   #     print(f"  ‖α·∇μ_self‖    = {np.linalg.norm(grad_mu_self):.4e}")
   #     print(f"  ‖β·∇μ_align‖   = {np.linalg.norm(grad_mu_align):.4e}")
   #     print(f"[∇Σ_q] Agent {agent_i.id}:")
   #     print(f"  ‖α·∇Σ_self‖    = {np.linalg.norm(grad_sigma_self):.4e}")
   #     print(f"  ‖β·∇Σ_align‖   = {np.linalg.norm(grad_sigma_align):.4e}")

    return grad_mu_total, grad_sigma_total


def compute_models_gradient(agent_i, agents, params):
    """
    Compute natural gradients ∇μ_p and ∇Σ_p for:
        1. Self energy:     KL(q || p)
        2. Feedback term:   KL(p || q)
        3. Alignment:       KL(p || Ω̃ p_j)

    All terms are Fisher-natural gradients.
    No Sigma approximations: full Σ used in all computations.
    """
    if getattr(config, "identical_models", False):
        return (
            np.zeros_like(agent_i.mu_p_field),
            np.zeros_like(agent_i.sigma_p_field),
        )

    α      = params.get("alpha", config.alpha)
    mf     = params.get("model_feedback_weight", config.model_feedback_weight)
    βm     = params.get("model_align_weight", config.model_align_weight)
    cutoff = params.get("support_cutoff_eps", config.support_cutoff_eps)
    debug  = params.get("debug", False) or getattr(config, "debug_gradients", False)

    mask = agent_i.mask > cutoff
    if not np.any(mask):
        return (
            np.zeros_like(agent_i.mu_p_field),
            np.zeros_like(agent_i.sigma_p_field),
        )

    μq = agent_i.mu_q_field
    Σq = agent_i.sigma_q_field
    μp = agent_i.mu_p_field
    Σp = agent_i.sigma_p_field

    grad_mu    = np.zeros_like(μp)
    grad_sigma = np.zeros_like(Σp)

    # 1. KL(q || p)
    if α > 0:
        dμ_self, dΣ_self = apply_natural_gradient_batch(
            mu_field=μp,
            sigma_field=Σp,
            grad_mu_field=μp - μq,
            grad_sigma_field=0.5 * (Σp - Σq),
        )
        grad_mu    += α * dμ_self
        grad_sigma += α * dΣ_self
   #     if debug:
    #        print(f"[∇μ_p:self] Agent {agent_i.id}: ‖α·∇μ_self‖ = {np.linalg.norm(α * dμ_self):.4e}")
   #         print(f"[∇Σ_p:self] Agent {agent_i.id}: ‖α·∇Σ_self‖ = {np.linalg.norm(α * dΣ_self):.4e}")

    # 2. KL(p || q) — feedback term
    if mf > 0:
        dμ_fb, dΣ_fb = apply_natural_gradient_batch(
            mu_field=μp,
            sigma_field=Σp,
            grad_mu_field=μq - μp,
            grad_sigma_field=0.5 * (Σq - Σp),
        )
        grad_mu    += mf * dμ_fb
        grad_sigma += mf * dΣ_fb
     #   if debug:
   #         print(f"[∇μ_p:fb] Agent {agent_i.id}: ‖mf·∇μ_fb‖  = {np.linalg.norm(mf * dμ_fb):.4e}")
    #        print(f"[∇Σ_p:fb] Agent {agent_i.id}: ‖mf·∇Σ_fb‖  = {np.linalg.norm(mf * dΣ_fb):.4e}")

    # 3. KL(p_i || Ω̃ p_j)
    if βm > 0:
        dμ_align, dΣ_align = compute_alignment_gradient(
            agent_i, agents, params, field_type="model"
        )
        grad_mu    += βm * dμ_align
        grad_sigma += βm * dΣ_align

    #    if debug:
    #        print(f"[∇μ_p:align] Agent {agent_i.id}: ‖βm·∇μ_align‖ = {np.linalg.norm(dμ_align):.4e}")
    #        print(f"[∇Σ_p:align] Agent {agent_i.id}: ‖βm·∇Σ_align‖ = {np.linalg.norm(dΣ_align):.4e}")

        # 4. Optional: variance penalty term on Σ_p
    variance_penalty_model = params.get("variance_penalty_model_weight", getattr(config, "variance_penalty_model_weight", 0.0))
    if variance_penalty_model > 0:
        grad_sigma += variance_penalty_model * Σp


    # Mask outside support
    grad_mu[~mask] = 0
    grad_sigma[~np.broadcast_to(mask[..., None, None], grad_sigma.shape)] = 0

    # Sanitize to prevent propagation of numerical instability
    grad_mu = np.nan_to_num(grad_mu, nan=0.0, posinf=1e5, neginf=-1e5)
    grad_sigma = np.nan_to_num(grad_sigma, nan=0.0, posinf=1e5, neginf=-1e5)

    return grad_mu, grad_sigma


def compute_phi_alignment_gradient(agent_i, agents: list, params: dict) -> np.ndarray:
    β  = params.get("beta", config.beta)
    gw = params.get("gauge_weight", config.gauge_weight)
    κ  = params.get("phi_phi_tilde_coupling", config.phi_phi_tilde_coupling)
    curv_weight = params.get("curvature_weight", getattr(config, "curvature_weight", 0.0))
    overlap_eps = params.get("overlap_eps", config.support_cutoff_eps)
    grad_clip_threshold = getattr(config, "phi_grad_clip_threshold", 1e4)
    debug = params.get("debug", False) or getattr(config, "debug_gradients", False)
    G_inv = params.get("G_inv_phi", None)

    if β <= 0:
        return np.zeros_like(agent_i.phi)

    phi_i = agent_i.phi
    phi_m = agent_i.phi_model
    soft_mask = agent_i.mask[..., None]
    if not np.any(soft_mask > overlap_eps):
        return np.zeros_like(phi_i)

    shape = agent_i.mu_q_field.shape
    N, K = np.prod(shape[:-1]), shape[-1]
    d = config.lie_dim
    flat_grad_align = np.zeros((N, d), dtype=phi_i.dtype)

    mu_i = agent_i.mu_q_field.reshape(N, K)
    Si   = agent_i.sigma_q_field.reshape(N, K, K)
    exp_phi_i     = agent_i._exp_phi.reshape(N, K, K)
    exp_neg_phi_i = agent_i._exp_neg_phi.reshape(N, K, K)
    Gs = get_generators(config.group_name, K)

    for nb in agent_i.neighbors:
        agent_j = agents[nb["id"]]
        overlap = (agent_i.mask * agent_j.mask > overlap_eps)
        idxs = np.flatnonzero(overlap.reshape(-1))
        if idxs.size == 0:
            continue

        mu_j = agent_j.mu_q_field.reshape(N, K)[idxs]
        Sj   = agent_j.sigma_q_field.reshape(N, K, K)[idxs]
        mu_i_ = mu_i[idxs]
        Si_   = Si[idxs]

        Oi     = exp_phi_i[idxs]
        Oj_inv = exp_neg_phi_i[idxs]
        Ω      = np.einsum("mab,mbc->mac", Oi, Oj_inv)

        mu_j_rot = np.einsum("mij,mj->mi", Ω, mu_j)
        Sj_rot   = np.einsum("mij,mjk,mkl->mil", Ω, Sj, Ω.transpose(0, 2, 1))
        diff     = mu_j_rot - mu_i_

        try:
            Sj_inv = np.linalg.inv(Sj_rot)
        except np.linalg.LinAlgError:
            if debug:
                print(f"[WARNING] Sigmaj not invertible in alignment gradient.")
            continue

        H  = np.einsum("aij,mjk->maik", Gs, Oi)
        dΩ = np.einsum("maik,mkl->mail", H, Oj_inv)

        for a in range(d):
            dΩa = dΩ[:, a]
            dμj_rot = np.einsum("mij,mj->mi", dΩa, mu_j)
            dΣj_rot = (
                np.einsum("mij,mjk,mkl->mil", dΩa, Sj, Ω.transpose(0, 2, 1)) +
                np.einsum("mij,mjk,mkl->mil", Ω, Sj, dΩa.transpose(0, 2, 1))
            )
            tr_term   = np.einsum("mij,mji->m", Sj_inv, dΣj_rot)
            quad_term = np.einsum("mi,mij,mj->m", diff, Sj_inv, dμj_rot)
            flat_grad_align[idxs, a] += β * 0.5 * (tr_term + 2 * quad_term)

    # Step 1: Alignment term (∇_φ KL(q_i || Ω q_j))
    grad_align = flat_grad_align.reshape(*phi_i.shape)
    delta_align = apply_lie_natural_gradient(phi=None, grad_phi=grad_align, G_inv=G_inv)
    grad = delta_align * soft_mask  # Mask immediately to avoid cross-agent contamination

# Step 2: Add curvature gradient ∇‖F‖²
    if curv_weight > 0:
        grad_curvature = compute_curvature_gradient_analytical(phi_i, Gs, dx=1.0)
        grad += curv_weight * grad_curvature * soft_mask

# Step 3: Add Fisher geometry penalty
    if config.fisher_geometry_weight > 0:
        grad += compute_phi_fisher_gradient(agent_i, agents, params) * soft_mask

# Step 4: Mass and coupling terms
    if gw > 0:
        grad += 2 * gw * phi_i * soft_mask  # Gauge mass term: φ²
    if κ > 0:
        grad += 2 * κ * (phi_i - phi_m) * soft_mask  # φ–φ̃ coupling

# Step 5: Global clipping (across support only)
    masked_grad = grad[soft_mask[..., 0] > overlap_eps]  # extract supported values
    grad_norm = np.linalg.norm(masked_grad)
    if grad_norm > grad_clip_threshold:
        if debug:
            print(f"[CLIP grad phi] Agent {agent_i.id}: grad-phi = {grad_norm:.2e} --> clipped to {grad_clip_threshold:.1e}")
        grad *= grad_clip_threshold / (grad_norm + 1e-8)

# Step 6: Final masking to ensure no bleeding
    grad *= soft_mask
    return grad




def compute_phi_model_update(agent_i, agents: list, params: dict) -> np.ndarray:
    if getattr(config, "identical_models", False):
        return np.zeros_like(agent_i.phi_model)

    βm = params.get("model_align_weight", config.model_align_weight)
    mmw = params.get("model_mass_weight", config.model_mass_weight)
    κ   = params.get("phi_phi_tilde_coupling", config.phi_phi_tilde_coupling)
    curv_weight_m = params.get("model_curvature_weight", getattr(config, "model_curvature_weight", 0.0))
    grad_clip_threshold = getattr(config, "phi_model_grad_clip_threshold", 1e4)
    debug = params.get("debug", False) or getattr(config, "debug_gradients", False)

    φm_i = agent_i.phi_model
    φ_i  = agent_i.phi
    soft_mask = agent_i.mask[..., None]
    if not np.any(soft_mask > config.support_cutoff_eps):
        return np.zeros_like(φm_i)

    shape = agent_i.mu_p_field.shape
    N, K = np.prod(shape[:-1]), shape[-1]
    Gs = get_generators(config.group_name, K)
    d = Gs.shape[0]

    mu_i = agent_i.mu_p_field.reshape(N, K)
    Si   = agent_i.sigma_p_field.reshape(N, K, K)
    flat_grad_align = np.zeros((N, d), dtype=φm_i.dtype)

    exp_phi_i     = agent_i._exp_phi_model.reshape(N, K, K)
    exp_neg_phi_i = agent_i._exp_neg_phi_model.reshape(N, K, K)

    if βm > 0:
        for nb in agent_i.neighbors:
            agent_j = agents[nb["id"]]
            ov = (agent_i.mask * agent_j.mask > config.support_cutoff_eps)
            idxs = np.flatnonzero(ov.reshape(-1))
            if idxs.size == 0:
                continue

            mu_j = agent_j.mu_p_field.reshape(N, K)[idxs]
            Sj   = agent_j.sigma_p_field.reshape(N, K, K)[idxs]
            mu_i_ = mu_i[idxs]
            Si_   = Si[idxs]

            Oi     = exp_phi_i[idxs]
            Oj_inv = exp_neg_phi_i[idxs]
            Ω      = np.einsum("mab,mbc->mac", Oi, Oj_inv)

            mu_j_rot = np.einsum("mij,mj->mi", Ω, mu_j)
            Sj_rot   = np.einsum("mij,mjk,mkl->mil", Ω, Sj, Ω.transpose(0, 2, 1))

            Si_    = sanitize_sigma(Si_, eps=1e-6, debug=config.debug_sanitize_sigma)
            Sj_rot = sanitize_sigma(Sj_rot, eps=1e-6, debug=config.debug_sanitize_sigma)
            Sj_inv = np.linalg.inv(Sj_rot)
            diff   = mu_j_rot - mu_i_

            H  = np.einsum("aij,mjk->maik", Gs, Oi)
            dΩ = np.einsum("maik,mkl->mail", H, Oj_inv)

            for a in range(d):
                dΩa = dΩ[:, a]
                dmu_j_rot = np.einsum("mij,mj->mi", dΩa, mu_j)
                dSigma_rot = (
                    np.einsum("mij,mjk,mkl->mil", dΩa, Sj, Ω.transpose(0, 2, 1)) +
                    np.einsum("mij,mjk,mkl->mil", Ω, Sj, dΩa.transpose(0, 2, 1))
                )
                tr_term   = np.einsum("mij,mji->m", Sj_inv, dSigma_rot)
                quad_term = np.einsum("mi,mij,mj->m", diff, Sj_inv, dmu_j_rot)
                flat_grad_align[idxs, a] += βm * 0.5 * (tr_term + 2 * quad_term)

    # Apply Lie-natural gradient to alignment term only
    grad_align = flat_grad_align.reshape(*φm_i.shape)
    G_inv = params.get("G_inv_phi_model", params.get("G_inv_phi", None))
    delta_align = apply_lie_natural_gradient(phi=None, grad_phi=grad_align, G_inv=G_inv)

    # Initialize total gradient
    grad = delta_align * soft_mask

    # Add Euclidean regularization terms
    if mmw > 0:
        grad += 2 * mmw * φm_i * soft_mask
    if κ > 0:
        grad += 2 * κ * (φm_i - φ_i) * soft_mask
    if curv_weight_m > 0:
        grad_curvature = compute_curvature_gradient_analytical(φm_i, Gs, dx=1.0)
        grad += curv_weight_m * grad_curvature * soft_mask
    if config.fisher_model_geometry_weight > 0:
        grad += compute_phi_model_fisher_gradient(agent_i, agents, params) * soft_mask

    # Final clip
    grad_norm = np.linalg.norm(grad[soft_mask[..., 0] > config.support_cutoff_eps])
    if grad_norm > grad_clip_threshold:
        print(f"[CLIP grad phi_model] Agent {agent_i.id}: grad phi~ norm = {grad_norm:.2e} --> clipped to {grad_clip_threshold:.1e}")
        grad *= grad_clip_threshold / (grad_norm + 1e-8)

    # Final mask to ensure smooth boundary
    grad *= soft_mask
    return grad



def compute_phi_fisher_gradient(agent_i, agents, params):
    """
    ∇_φ Fisher: Drives φ to preserve Fisher metric under parallel transport.
    Penalizes || G^i_q − Ω_{ij} G^j_q Ω_{ij}^T ||²
    """
    Gs = get_generators(config.group_name, config.K)
    d, K = Gs.shape[0], Gs.shape[1]
    mask_i = agent_i.mask > config.support_cutoff_eps
    if not np.any(mask_i): return np.zeros_like(agent_i.phi)

    phi_i = agent_i.phi
    exp_phi_i = agent_i._exp_phi
    grad = np.zeros_like(phi_i)

    for nb in agent_i.neighbors:
        agent_j = agents[nb["id"]]
        mask_j = agent_j.mask > config.support_cutoff_eps
        overlap = mask_i & mask_j
        if not np.any(overlap): continue

        Gq_i = agent_i.cached_fisher_q[overlap]  # (..., K, K)
        Gq_j = agent_j.cached_fisher_q[overlap]  # (..., K, K)

        flat_overlap = overlap.reshape(-1)
        Omega = np.einsum("...ij,...jk->...ik",
                  exp_phi_i.reshape(-1, K, K)[flat_overlap],
                  agent_j._exp_neg_phi.reshape(-1, K, K)[flat_overlap])


        Gq_j_rot = np.einsum("...ik,...kl,...jl->...ij", Omega, Gq_j, Omega)  # (..., K, K)
        Delta = Gq_i - Gq_j_rot  # (..., K, K)

        for a in range(d):
            Ga = Gs[a]  # (K, K)
            dOmega = np.einsum("ij,...jk->...ik", Ga, Omega)  # (..., K, K)

            term1 = np.einsum("...ik,...kl,...jl->...ij", dOmega, Gq_j, Omega)
            term2 = np.einsum("...ik,...kl,...jl->...ij", Omega, Gq_j, dOmega)
            dG_rot = term1 + term2  # (..., K, K)

            dL = 2 * np.einsum("...ij,...ij->...", Delta, dG_rot)  # (...,)
            grad[overlap, a] += dL  # inject into the full grid

    grad *= params.get("fisher_geometry_weight", config.fisher_geometry_weight)
    grad[~mask_i] = 0.0
    return grad


def compute_phi_model_fisher_gradient(agent_i, agents, params):
    """
    ∇_{φ̃} [‖ G^p_i − Ω̃_ij G^p_j Ω̃_ijᵀ ‖²]
    Preserves Fisher geometry of models under gauge transport.
    """
    Gs = get_generators(config.group_name, config.K)
    d, K = Gs.shape[0], Gs.shape[1]
    mask_i = agent_i.mask > config.support_cutoff_eps
    if not np.any(mask_i): return np.zeros_like(agent_i.phi_model)

    phi_m_i     = agent_i.phi_model
    exp_phi_i   = agent_i._exp_phi_model
    grad = np.zeros_like(phi_m_i)

    for nb in agent_i.neighbors:
        agent_j = agents[nb["id"]]
        mask_j = agent_j.mask > config.support_cutoff_eps
        overlap = mask_i & mask_j
        if not np.any(overlap): continue

        flat_overlap = overlap.reshape(-1)
        Gp_i = agent_i.cached_fisher_p.reshape(-1, K, K)[flat_overlap]
        Gp_j = agent_j.cached_fisher_p.reshape(-1, K, K)[flat_overlap]

        Omega = np.einsum("...ij,...jk->...ik",
                          exp_phi_i.reshape(-1, K, K)[flat_overlap],
                          agent_j._exp_neg_phi_model.reshape(-1, K, K)[flat_overlap])

        Gp_j_rot = np.einsum("...ik,...kl,...jl->...ij", Omega, Gp_j, Omega)
        Delta = Gp_i - Gp_j_rot

        for a in range(d):
            Ga = Gs[a]
            dOmega = np.einsum("ij,...jk->...ik", Ga, Omega)
            term1 = np.einsum("...ik,...kl,...jl->...ij", dOmega, Gp_j, Omega)
            term2 = np.einsum("...ik,...kl,...jl->...ij", Omega, Gp_j, dOmega)
            dG_rot = term1 + term2
            dL = 2 * np.einsum("...ij,...ij->...", Delta, dG_rot)
            grad.reshape(-1, d)[flat_overlap, a] += dL

    grad *= params.get("fisher_model_geometry_weight", config.fisher_model_geometry_weight)
    grad[~mask_i] = 0.0
    return grad
