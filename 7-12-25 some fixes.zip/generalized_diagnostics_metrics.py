# Standard library
import os

# Third-party libraries
import numpy as np
from scipy.ndimage import laplace
from generalized_omega import (exp_lie_algebra_irrep, batch_apply_omega,
                               compute_field_strength)

from get_generators import get_generators  # ← add at top if not already

from joblib import Parallel, delayed
from generalized_math_utils import (
    laplacian_field,
   )
import config

from pathlib import Path

from pullback_utils import compute_agent_pullback_blocks, compute_pullback_metric

from generalized_math_utils import kl_divergence  # ← make sure this is imported



def populate_pullbacks(agent):
    """
    Compute pullback gradient fields like pull_Delta if missing.
    """
    if agent.pull_Delta is None and np.any(agent.mask > config.support_cutoff_eps):
        # ∇μ field
        mu = agent.mu_q_field
        grad = np.stack([np.gradient(mu[..., k]) for k in range(mu.shape[-1])], axis=-1)  # (D, H, W, K)
        grad = np.moveaxis(grad, 0, -2)  # → (H, W, D, K)
        agent.pull_Delta = grad * agent.mask[..., None, None]

def compute_fisher_from_gaussian(mu, sigma, mask, log_eps=1e-8):
    """
    Approximate scalar Fisher information via ∇μᵀ Σ⁻¹ ∇μ
    """
    mu_grad = np.stack([np.gradient(mu[..., d]) for d in range(mu.shape[-1])], axis=-1)  # (D1, D2, ..., K, d)
    fisher = 0.0
    for i in range(mu.shape[0]):
        for j in range(mu.shape[1]):
            if not mask[i, j]: continue
            grad_mu = mu_grad[i, j]        # shape (K,)
            sigma_ij = sigma[i, j] + log_eps * np.eye(mu.shape[-1])
            fisher += grad_mu @ np.linalg.inv(sigma_ij) @ grad_mu.T
    return float(fisher)


def fisher_information_matrix(mu, sigma, eps=1e-8, approx_sigma_block=True):
    """
    Compute the Fisher information matrix for MVG parameters (μ, Σ).

    Supports:
        - Diagonal sigma: shape (..., K)
        - Full covariance: shape (..., K, K)

    Args:
        mu:     (..., K) mean vector
        sigma:  (..., K) if diagonal, (..., K, K) if full SPD
        eps:    Regularization for SPD stability
        approx_sigma_block: if True, use 2·Σ⁻¹ approximation for Σ–Σ block

    Returns:
        G:      (..., 2K, 2K) Fisher block matrix
    """
    K = mu.shape[-1]
    eye = np.eye(K)

    if sigma.ndim == mu.ndim:
        # Diagonal case
        sigma_diag = np.clip(sigma, eps, None)
        inv_var = 1.0 / (sigma_diag ** 2)

        F_mu = np.einsum('...k,kl->...kl', inv_var, eye)              # diag(1/σ²)
        F_sigma = np.einsum('...k,kl->...kl', 2.0 * inv_var, eye)     # diag(2/σ²)

    elif sigma.ndim == mu.ndim + 1:
        # Full covariance case
        sigma_reg = sigma + eps * eye
        sigma_inv = np.linalg.inv(sigma_reg)

        F_mu = sigma_inv

        if approx_sigma_block:
            # Approximate Σ–Σ block with 2·Σ⁻¹ (trace-style)
            F_sigma = 2.0 * sigma_inv
        else:
            # Exact Σ–Σ block: Σ⁻¹ ⊗ Σ⁻¹
            # Note: for efficiency this is usually flattened
            kron = np.einsum('...ij,...kl->...ikjl', sigma_inv, sigma_inv)
            F_sigma = kron.reshape(*kron.shape[:-4], K*K, K*K)

    else:
        raise ValueError(f"Invalid sigma shape: {sigma.shape}")

    zeros = np.zeros_like(F_mu)

    top    = np.concatenate([F_mu, zeros], axis=-1)      # (..., K, 2K)
    bottom = np.concatenate([zeros, F_sigma], axis=-1)   # (..., K, 2K)
    G = np.concatenate([top, bottom], axis=-2)           # (..., 2K, 2K)

    return G


def support_mask(mask, cutoff=config.support_cutoff_eps):
    return (mask > cutoff)

def overlap_mask(mask_i, mask_j, cutoff=config.support_cutoff_eps):
    return support_mask(mask_i, cutoff) & support_mask(mask_j, cutoff)


def threshold_mask(mask: np.ndarray, cutoff: float = None) -> np.ndarray:
    """
    Threshold a continuous support mask into a boolean mask.
    """
    if cutoff is None:
        cutoff = getattr(config, "support_cutoff_eps", 1e-3)
    return mask > cutoff


def compute_coherence(phi: np.ndarray, mask: np.ndarray, eps=1e-8) -> float:
    """
    Coherence of SL(2,ℝ) Lie-algebra-valued φ field over agent support.

    Args:
        phi:   (H, W, D) Lie algebra field (e.g., D = 3)
        mask:  (H, W) soft support mask
        eps:   Regularization to avoid divide-by-zero

    Returns:
        scalar coherence ∈ [0, 1] measuring direction alignment
    """
    mask_bool = threshold_mask(mask)
    if not np.any(mask_bool):
        return 0.0

    phi_field = phi[mask_bool]                     # (N, D)
    norms = np.linalg.norm(phi_field, axis=-1, keepdims=True) + eps
    unit_phi = phi_field / norms                   # (N, D)

    mean_vec = np.mean(unit_phi, axis=0)
    return float(np.linalg.norm(mean_vec))

#USED OPNLY IN RUNSIM
def compute_phi_norm_field(agents, i, phi_field="phi"):
    phi = getattr(agents[i], phi_field)
    mask = threshold_mask(agents[i].mask)
    return np.linalg.norm(phi, axis=-1) * mask

def masked_norm(tensor, mask):
    """
    Computes the total norm of a tensor over the masked region.

    Args:
        tensor: (H, W, D) array
        mask: (H, W) boolean or float mask

    Returns:
        scalar: sum of norms over the mask
    """
    norm_field = np.linalg.norm(tensor, axis=-1)
    return np.sum(norm_field * mask)

#USED ONLY IN RUN_SIM AND LOG_ALL_METRICS
def compute_phi_norm(
    agents,
    phi_field="phi",
    mask_field="mask",
    support_cutoff_eps=1e-3,
):
    norms = []
    for agent in agents:
        phi  = getattr(agent, phi_field)
        mask = getattr(agent, mask_field) > support_cutoff_eps
        n    = np.count_nonzero(mask)
        if n > 0:
            norms.append(masked_norm(phi, mask) / n)
    return float(np.mean(norms)) if norms else 0.0


def compute_phi_laplacian_norm(
    agents,
    phi_field: str = "phi",
    mask_field: str = "mask",
    support_cutoff_eps: float | None = None,
    log_eps: float = 1e-8,
) -> float:
    """
    Compute the average per-agent RMS norm of the Laplacian of the φ field.
    1) Threshold mask by support_cutoff_eps.
    2) Compute componentwise Laplacian via scipy.ndimage.laplace.
    3) Compute masked_norm over support and normalize by support size.
    4) Return the mean over all agents.
    """
    if support_cutoff_eps is None:
        support_cutoff_eps = getattr(config, "support_cutoff_eps", 1e-3)


    norms = []
    for agent in agents:
        phi = getattr(agent, phi_field)
        mask = getattr(agent, mask_field) > support_cutoff_eps
        if not np.any(mask):
            continue

        # componentwise Laplacian
        lap_phi = np.stack([laplace(phi[..., d]) for d in range(phi.shape[-1])], axis=-1)
        # RMS norm over support
        val = masked_norm(lap_phi, mask) / (np.count_nonzero(mask) + log_eps)
        norms.append(val)

    return float(np.mean(norms)) if norms else 0.0


def compute_kl_field(agents, i):
    """
    Compute spatial field of D_KL(q || p) between MVGs using batch operations.
    Supports diagonal or full covariance matrices.
    
    Returns:
        kl: (H, W) field of KL divergences (computed only where mask > ε)
    """
    μq = agents[i].mu_q_field       # (H, W, K)
    Σq = agents[i].sigma_q_field    # (H, W, K) or (H, W, K, K)
    μp = agents[i].mu_p_field
    Σp = agents[i].sigma_p_field
    mask = agents[i].mask           # (H, W)

    eps = getattr(config, "eps", 1e-8)
    cutoff = getattr(config, "support_cutoff_eps", 1e-3)

    valid_mask = mask > cutoff
    indices = np.argwhere(valid_mask)

    if len(indices) == 0:
        return np.zeros_like(mask)

    μq_batch = μq[valid_mask]       # (N, K)
    Σq_batch = Σq[valid_mask]       # (N, K) or (N, K, K)
    μp_batch = μp[valid_mask]
    Σp_batch = Σp[valid_mask]

    # Vectorized KL divergence for all valid points
    kl_vals = kl_divergence(μq_batch, Σq_batch, μp_batch, Σp_batch, log_eps=eps)  # shape (N,)

    kl_field = np.zeros(mask.shape, dtype=μq.dtype)
    for idx, val in zip(indices, kl_vals):
        kl_field[tuple(idx)] = val

    return kl_field


def compute_alignment_field(agents, i, eps=config.support_cutoff_eps, log_eps=config.log_eps) -> np.ndarray:
    """
    Compute spatial field of average KL(q_i || Ω_ij q_j) over neighbors of agent i.
    Uses gauge transport Ω_ij to compare belief MVGs.
    """
    A = agents[i]
    mask_i = A.mask > eps
    if not np.any(mask_i) or not A.neighbors:
        return np.zeros_like(mask_i, dtype=np.float32)

    H, W = A.mask.shape
    kl_accum = np.zeros((H, W), dtype=np.float32)
    n_nb_at = np.zeros((H, W), dtype=np.int32)

    mu_i = A.mu_q_field        # (H, W, K)
    sigma_i = A.sigma_q_field  # (H, W, K, K) or (H, W, K)

    for nb in A.neighbors:
        j = nb["id"]
        B = agents[j]
        mask_j = B.mask > eps
        overlap = mask_i & mask_j
        if not np.any(overlap):
            continue

        idx = np.argwhere(overlap)
        mu_j     = B.mu_q_field[overlap]       # (M, K)
        sigma_j  = B.sigma_q_field[overlap]    # (M, K, K) or (M, K)
        flat_idx = overlap.reshape(-1)                # (H·W,)
        omega_ij = np.einsum(
            "mab,mbc->mac",
            A._exp_phi[flat_idx],                     # (M, K, K)
            B._exp_neg_phi[flat_idx]                  # (M, K, K)
            )
        # Transport μ_j: μ_j_t = Ω_ij @ μ_j
        mu_j_t = np.einsum("mab,mb->ma", omega_ij, mu_j)  # (M, K)

        # Transport Σ_j: Σ_j_t = Ω_ij @ Σ_j @ Ω_ijᵀ
        if sigma_j.ndim == 2:  # diagonal case
            sigma_j_full = np.einsum("mk,ij->mij", sigma_j**2, np.eye(sigma_j.shape[1]))
        else:
            sigma_j_full = sigma_j
        sigma_j_t = np.einsum("mab,mbc,mdc->mad", omega_ij, sigma_j_full, omega_ij)

        # Extract μ_i and Σ_i at overlap points
        mu_i_pts    = mu_i[overlap]                  # (M, K)
        sigma_i_pts = sigma_i[overlap]               # (M, K, K) or (M, K)

        if sigma_i_pts.ndim == 2:
            sigma_i_full = np.einsum("mk,ij->mij", sigma_i_pts**2, np.eye(sigma_i_pts.shape[1]))
        else:
            sigma_i_full = sigma_i_pts

        # ⟶ Vectorized KL computation
        kl_vals = kl_divergence(
            mu_i_pts, sigma_i_full,
            mu_j_t, sigma_j_t,
            log_eps=log_eps
        )

        i_idx, j_idx = idx[:, 0], idx[:, 1]
        np.add.at(kl_accum, (i_idx, j_idx), kl_vals)
        np.add.at(n_nb_at,  (i_idx, j_idx), 1)


    out = np.zeros_like(kl_accum)
    valid = n_nb_at > 0
    out[valid] = kl_accum[valid] / n_nb_at[valid]
    return out * mask_i


def compute_model_alignment_field(agents, i, eps=1e-3) -> np.ndarray:
    """
    Compute spatial field of average KL(p_i || Ω̃_ij p_j) over neighbors of agent i.
    Uses φ_model → Ω̃ transport acting on MVG (μ_p, Σ_p) model bundles.
    """
        
    A = agents[i]
    mask_i = threshold_mask(A.mask, eps)
    if not np.any(mask_i) or not A.neighbors:
        return np.zeros_like(mask_i, dtype=np.float32)

    kl_accum = np.zeros_like(mask_i, dtype=np.float32)
    n_nb_at  = np.zeros_like(mask_i, dtype=np.int32)

    mu_i    = A.mu_p_field       # (..., K)
    sigma_i = A.sigma_p_field    # (..., K) or (..., K, K)

    generators = get_generators(config.group_name, config.K)

    for nb in A.neighbors:
        B = agents[nb["id"]]
        mask_j = threshold_mask(B.mask, eps)
        overlap = mask_i & mask_j
        if not np.any(overlap):
            continue

        idx = np.argwhere(overlap)

        mu_j    = B.mu_p_field[overlap]       # (M, K)
        sigma_j = B.sigma_p_field[overlap]    # (M, K) or (M, K, K)

        # Transport via Omega_ij = exp(φ_i) · exp(−φ_j)
        O_i     = exp_lie_algebra_irrep(A.phi_model[overlap], generators)      # (M, K, K)
        O_j_inv = exp_lie_algebra_irrep(-B.phi_model[overlap], generators)     # (M, K, K)
        Omega   = np.einsum("mab,mbc->mac", O_i, O_j_inv)                      # (M, K, K)

        mu_j_t = np.einsum("mab,mb->ma", Omega, mu_j)                          # (M, K)

        # Promote Σ_j to full matrix if diagonal
        if sigma_j.ndim == 2:
            sigma_j_full = np.einsum("mk,ij->mij", sigma_j**2, np.eye(sigma_j.shape[1]))
        else:
            sigma_j_full = sigma_j

        sigma_j_t = np.einsum("mab,mbc,mdc->mad", Omega, sigma_j_full, Omega)  # (M, K, K)

        mu_i_ov = mu_i[overlap]
        sigma_i_ov = sigma_i[overlap]

        if sigma_i_ov.ndim == 2:
            sigma_i_full = np.einsum("mk,ij->mij", sigma_i_ov**2, np.eye(sigma_i_ov.shape[1]))
        else:
            sigma_i_full = sigma_i_ov

        kl_vals = kl_divergence(mu_i_ov, sigma_i_full, mu_j_t, sigma_j_t)


        i_idx, j_idx = idx[:, 0], idx[:, 1]
        np.add.at(kl_accum, (i_idx, j_idx), kl_vals)
        np.add.at(n_nb_at,  (i_idx, j_idx), 1)


    out = np.zeros_like(kl_accum)
    valid = n_nb_at > 0
    out[valid] = kl_accum[valid] / n_nb_at[valid]
    return out * mask_i

def compute_entropy_field(
    agents,
    i,
    sigma_field="sigma_q_field",
    mask_field="mask",
    support_cutoff_eps=1e-3,
    log_eps=1e-8,
):
    """
    Compute differential entropy field of a multivariate Gaussian:
        H[q(x)] = 0.5 * [ K log(2πe) + log det Σ(x) ]

    Supports both diagonal (σ²) and full (Σ) covariance formats.

    Returns:
        entropy : (H, W) entropy values, masked
    """
    sigma = getattr(agents[i], sigma_field)    # (..., K) or (..., K, K)
    mask  = getattr(agents[i], mask_field) > support_cutoff_eps
    K     = sigma.shape[-1] if sigma.ndim >= 2 else sigma.shape[-1]
    entropy = np.zeros(mask.shape, dtype=np.float32)

    valid_idx = np.argwhere(mask)
    for idx in valid_idx:
        idx = tuple(idx)
        Σ = sigma[idx]

        if Σ.ndim == 1:  # Diagonal covariance
            var = np.clip(Σ**2, log_eps, None)
            log_det = np.sum(np.log(var))
        else:  # Full covariance
            Σ_reg = Σ + log_eps * np.eye(K)
            sign, log_det_val = np.linalg.slogdet(Σ_reg)
            log_det = log_det_val if sign > 0 else -np.inf

        entropy[idx] = 0.5 * (K * np.log(2 * np.pi * np.e) + log_det)

    return entropy * mask

def compute_entropy(sigma_field, mask, log_eps=1e-8):
    """
    Computes entropy for multivariate Gaussians:
        H[q] = 0.5 * [ K log(2πe) + log det Σ ]

    Inputs:
        sigma_field: (L, L, K) for diagonal or (L, L, K, K) for full covariance
        mask:        (L, L) boolean
    Returns:
        Scalar entropy over masked region
    """
    K = sigma_field.shape[-1] if sigma_field.ndim == 3 else sigma_field.shape[-2]
    sigma_flat = sigma_field.reshape(-1, K) if sigma_field.ndim == 3 else sigma_field.reshape(-1, K, K)
    mask_flat  = mask.reshape(-1)

    entropy_vals = np.zeros(len(mask_flat))
    for idx in np.flatnonzero(mask_flat):
        if sigma_field.ndim == 3:
            # Diagonal: σ²
            var = np.clip(sigma_flat[idx]**2, log_eps, None)
            log_det = np.sum(np.log(var))
        else:
            # Full Σ
            Σ = sigma_flat[idx] + log_eps * np.eye(K)
            sign, logdet_val = np.linalg.slogdet(Σ)
            log_det = logdet_val if sign > 0 else -np.inf

        entropy_vals[idx] = 0.5 * (K * np.log(2 * np.pi * np.e) + log_det)

    return float(np.sum(entropy_vals[mask_flat]))


def compute_alignment_field_pairwise(
    agents,
    i,
    j,
    eps: float = config.support_cutoff_eps,
    log_eps: float = config.log_eps
) -> np.ndarray:
    """
    Compute spatial KL alignment field D_KL(q_i || Ω_ij q_j) using MVG fields.

    Supports both diagonal (Σ shape: (..., K)) and full (Σ shape: (..., K, K)) covariance.

    Returns:
        2D array with KL divergence at overlap points, zero elsewhere.
    """
   
    A, B = agents[i], agents[j]
    mask_i = A.mask > eps
    mask_j = B.mask > eps
    overlap = mask_i & mask_j

    if not np.any(overlap):
        return np.zeros_like(A.mask, dtype=float)

    μ_i = A.mu_q_field[overlap]       # (M, K)
    μ_j = B.mu_q_field[overlap]
    Σ_i = A.sigma_q_field[overlap]    # (M, K) or (M, K, K)
    Σ_j = B.sigma_q_field[overlap]

    Ω_i     = A.Omega[overlap]        # (M, K, K)
    Ω_j_inv = B.Omega_inv[overlap]
    Ω_ij    = np.einsum("mab,mbc->mac", Ω_i, Ω_j_inv)  # (M, K, K)

    μ_j_t = np.einsum("mab,mb->ma", Ω_ij, μ_j)         # (M, K)

    if Σ_j.ndim == 2:
        # Diagonal: σ² → rotate elementwise
        Σ_j_t = np.einsum("mab,mb->ma", Ω_ij**2, Σ_j)   # crude approx
    else:
        Σ_j_t = np.einsum("mab,mbc,mdc->mad", Ω_ij, Σ_j, Ω_ij)

    kl_vals = kl_divergence(μ_i, Σ_i, μ_j_t, Σ_j_t, eps=log_eps)

    field = np.zeros_like(A.mask, dtype=float)
    field[overlap] = kl_vals
    return field


def compute_self_energy(mu_q, sigma_q, mu_p, sigma_p, mask, alpha, log_eps):
    """
    Compute self-energy term: α · D_KL(q || p) over the agent's mask.

    Args:
        mu_q      : (H, W, K) array of mean vectors for q
        sigma_q   : (H, W, K, K) array of full covariance matrices for q
        mu_p      : (H, W, K) array of mean vectors for p
        sigma_p   : (H, W, K, K) array of full covariance matrices for p
        mask      : (H, W) support mask
        alpha     : scalar energy weight
        log_eps   : regularization term for numerical stability

    Returns:
        Scalar: α * total KL over the mask
    """
    

    support = mask > config.support_cutoff_eps
    if not np.any(support):
        return 0.0

    μ_q = mu_q[support]        # (M, K)
    Σ_q = sigma_q[support]     # (M, K, K)
    μ_p = mu_p[support]
    Σ_p = sigma_p[support]

    kl_vals = kl_divergence(μ_q, Σ_q, μ_p, Σ_p)  # (M,)
    return alpha * float(np.sum(kl_vals))

def compute_feedback_energy(p_mu, p_sigma, q_mu, q_sigma, mask, weight, log_eps):
    """
    Compute feedback energy: weight · D_KL(p || q) over the agent's support.

    Args:
        p_mu    : (H, W, K)     — model mean field
        p_sigma : (H, W, K, K)  — model covariance field
        q_mu    : (H, W, K)     — belief mean field
        q_sigma : (H, W, K, K)  — belief covariance field
        mask    : (H, W)        — support mask
        weight  : scalar
        log_eps : float         — regularization

    Returns:
        Scalar energy over mask: weight × ∑ D_KL(p || q)
    """
    
    support = mask > config.support_cutoff_eps
    if not np.any(support):
        return 0.0

    μ_p = p_mu[support]        # (M, K)
    Σ_p = p_sigma[support]     # (M, K, K)
    μ_q = q_mu[support]        # (M, K)
    Σ_q = q_sigma[support]     # (M, K, K)

    kl_vals = kl_divergence(μ_p, Σ_p, μ_q, Σ_q)  # (M,)
    return weight * float(np.sum(kl_vals))


def compute_alignment_energy(i, A, Q_list, Mask_list, O_bel, O_inv, beta, log_eps, n_jobs):
    """
    Alignment energy: β ∑_j D_KL(q_i || Ω_{ij} q_j)
    Q_list: list of (μ, Σ) fields
    O_bel, O_inv: gauge operators Ω and Ω⁻¹ for beliefs
    """
    qi_mu, qi_sigma = Q_list[i]
    mask_i = Mask_list[i]

    total_energy = 0.0
    for nb in A.neighbors:
        j = nb["id"]
        qj_mu, qj_sigma = Q_list[j]
        mask_j = Mask_list[j]
        overlap = mask_i & mask_j
        if not np.any(overlap):
            continue

        # Compute Ω_{ij} = Ω_i · Ω_j⁻¹
        Ω_ij = np.einsum("mab,mbc->mac", O_bel[i][overlap], O_inv[j][overlap])

        # Transport q_j → q_j^t
        qj_mu_t, qj_sigma_t = batch_apply_omega(qj_mu[overlap], qj_sigma[overlap], Ω_ij)

        # KL(q_i || Ω·q_j)
        kl_vals = kl_divergence(qi_mu[overlap], qi_sigma[overlap], qj_mu_t, qj_sigma_t, log_eps)
        total_energy += beta * float(np.sum(kl_vals))

    return total_energy


def compute_model_alignment_energy(i, A, P_list, Mask_list, O_mod, O_mod_inv, model_align_weight, log_eps, n_jobs):
    """
    Model alignment energy: model_align_weight ∑_j D_KL(p_i || Ω̃_{ij} p_j)
    P_list: list of (μ, Σ) fields for models
    O_mod, O_mod_inv: gauge operators for models
    """
    pi_mu, pi_sigma = P_list[i]
    mask_i = Mask_list[i]

    total_energy = 0.0
    for nb in A.neighbors:
        j = nb["id"]
        pj_mu, pj_sigma = P_list[j]
        mask_j = Mask_list[j]
        overlap = mask_i & mask_j
        if not np.any(overlap):
            continue

        # Compute Ω̃_{ij} = exp(φ̃_i) · exp(−φ̃_j)
        Ω_tilde = np.einsum("mab,mbc->mac", O_mod[i][overlap], O_mod_inv[j][overlap])

        # Transport p_j → p_j^t
        pj_mu_t, pj_sigma_t = batch_apply_omega(pj_mu[overlap], pj_sigma[overlap], Ω_tilde)

        # KL(p_i || Ω̃·p_j)
        kl_vals = kl_divergence(pi_mu[overlap], pi_sigma[overlap], pj_mu_t, pj_sigma_t, log_eps)
        total_energy += model_align_weight * float(np.sum(kl_vals))

    return total_energy


def compute_laplacian_energy(phi, mask, weight):
    """
    Computes ∫ ‖Δφ‖ over the mask. Used as a smoothing regularizer.
    """
    lap = laplacian_field(phi)  # shape: (H, W, d)
    return weight * np.sum(np.linalg.norm(lap[mask], axis=-1))**2

def compute_mass_energy(phi, mask, weight):
    """
    Computes ∫ ‖φ‖² over the mask — a mass-like prior.
    """
    return weight * np.sum(np.linalg.norm(phi[mask], axis=-1)**2)

def compute_phi_coupling_energy(phi, phi_model, mask, weight):
    """
    Coupling term ∫ ‖φ - φ̃‖² between belief and model gauge fields.
    """
    if phi.shape[:2] != mask.shape:
        H, W = mask.shape
        d = phi.shape[-1]
        phi = phi.reshape(H, W, d)
        phi_model = phi_model.reshape(H, W, d)

    diff = (phi - phi_model)[mask > 0]
    return weight * float(np.sum(np.linalg.norm(diff, axis=-1)**2))

def compute_curvature_energy(phi, mask, weight, lie_gens):
    """
    Computes ∑ Tr[F_{μν}²] over valid support.
    """
    F = compute_field_strength(phi, lie_gens)  # e.g. {'F_xy': (H, W, K, K)}
    total = 0.0

    for v in F.values():
        if v.ndim == 2:
            total += v**2
        elif v.ndim == 3:
            total += np.sum(v**2, axis=-1)
        elif v.ndim == 4:
            total += np.sum(v**2, axis=(-2, -1))  # Frobenius²
        else:
            raise ValueError(f"Unexpected shape in curvature field: {v.shape}")

    total_energy = float(np.sum(total[mask > config.support_cutoff_eps]))
    return weight * total_energy, total_energy


def _agent_stats(
    i,
    A,
    step,
    q_field,
    p_field,
    phi_belief_field,
    phi_model_field,
    mask_field,
    cfg,
    generators,
    Q_list,
    P_list,
    Mask_list,
    O_bel,
    O_inv,
    O_mod,
    O_mod_inv,
    n_jobs
):
    mask = Mask_list[i]
    support = int(mask.sum())

    if not support:
        return i, {k: 0.0 for k in [
            "e_self", "e_align", "e_feedback", "e_mod_align",
            "e_lap_bel", "e_mass_bel", "e_lap_mod", "e_mass_mod",
            "e_couple", "e_curv", "e_curv_mod",
            "phi_norm", "phi_model_norm", "entropy",
            "lap_phi_norm", "delta_phi_norm",
            "curvature_norm", "curvature_model_norm",
            "fisher_information", "kl_align_total", "kl_align_avg_per_point",
        ]} | {"model_arr": np.zeros(len(Mask_list), dtype=float)}

    # Safely populate pull_Delta if needed
    if A.pull_Delta is None and np.any(mask > config.support_cutoff_eps):
        mu = A.mu_q_field
        grad = np.stack([np.gradient(mu[..., k]) for k in range(mu.shape[-1])], axis=-1)  # (D, H, W, K)
        grad = np.moveaxis(grad, 0, -2)  # → (H, W, D, K)
        A.pull_Delta = grad * mask[..., None, None]

    # field slices
    lie_gens = generators
    log_eps = cfg["log_eps"]

    mu_q     = A.mu_q_field
    sigma_q  = A.sigma_q_field
    mu_p     = A.mu_p_field
    sigma_p  = A.sigma_p_field

    # KL Terms
    e_self = kl_divergence(mu_q, sigma_q, mu_p, sigma_p, eps=log_eps)
    e_self = float((e_self * mask).sum()) * cfg["alpha"]

    e_feedback = kl_divergence(mu_p, sigma_p, mu_q, sigma_q, eps=log_eps)
    e_feedback = float((e_feedback * mask).sum()) * cfg["model_feedback_weight"]

    e_align = compute_alignment_energy(i, A, Q_list, Mask_list, O_bel, O_inv,
                                       cfg["beta"], log_eps, n_jobs)

    e_mod_align = compute_model_alignment_energy(i, A, P_list, Mask_list,
                                                 O_mod, O_mod_inv,
                                                 cfg["model_align_weight"], log_eps, n_jobs)

    # Laplacian + mass
    e_lap_bel     = compute_laplacian_energy(A.phi, mask, cfg["gamma"])
    e_mass_bel    = compute_mass_energy(A.phi, mask, cfg["gauge_weight"])
    e_lap_mod     = compute_laplacian_energy(A.phi_model, mask, cfg["model_gauge_weight"])
    e_mass_mod    = compute_mass_energy(A.phi_model, mask, cfg["model_mass_weight"])

    # Coupling + curvature
    e_couple      = compute_phi_coupling_energy(A.phi, A.phi_model, mask, cfg["phi_phi_tilde_coupling"])
    e_curv, curv_norm_bel = compute_curvature_energy(A.phi, mask, cfg["curvature_weight"], lie_gens)
    e_curv_mod, curv_norm_mod = compute_curvature_energy(A.phi_model, mask, cfg["curvature_weight"], lie_gens)

    # Scalar diagnostics
    entropy = compute_entropy(sigma_q, mask)

    phi_norm       = np.linalg.norm(A.phi[mask], axis=-1).sum()
    phi_model_norm = np.linalg.norm(A.phi_model[mask], axis=-1).sum()
    lap_phi_norm   = np.linalg.norm(laplacian_field(A.phi)[mask], axis=-1).sum()
    delta_phi_norm = float(np.linalg.norm(getattr(A, "delta_phi", 0.0), axis=-1)[mask].max()) if hasattr(A, "delta_phi") else 0.0

    fisher_information = compute_fisher_from_gaussian(mu_q, sigma_q, mask)

    total_overlap_points = sum((mask & Mask_list[nb["id"]]).sum() for nb in A.neighbors if (mask & Mask_list[nb["id"]]).any())

    stats = {
        "e_self":        e_self,
        "e_align":       e_align,
        "e_feedback":    e_feedback,
        "e_mod_align":   e_mod_align,
        "e_lap_bel":     e_lap_bel,
        "e_mass_bel":    e_mass_bel,
        "e_lap_mod":     e_lap_mod,
        "e_mass_mod":    e_mass_mod,
        "e_couple":      e_couple,
        "e_curv":        e_curv,
        "e_curv_mod":    e_curv_mod,
        "phi_norm":      phi_norm,
        "phi_model_norm":phi_model_norm,
        "entropy":       entropy,
        "lap_phi_norm":  lap_phi_norm,
        "delta_phi_norm":delta_phi_norm,
        "curvature_norm":       curv_norm_bel,
        "curvature_model_norm": curv_norm_mod,
        "fisher_information": fisher_information,
        "kl_align_total": e_align,
        "kl_align_avg_per_point": (e_align / max(total_overlap_points, 1)) / support,
        "model_arr": np.zeros(len(Mask_list), dtype=float)
    }

    return i, stats


def compute_agent_metrics(
    i, A, Q_list, P_list, Mask_list,
    O_bel, O_inv, O_mod, O_mod_inv,
    cfg, gens, log_eps
):
    mask = Mask_list[i]
    if not mask.any():
        return i, zero_agent_metrics(len(Q_list))

    stats = compute_all_agent_metrics(
        i, A, Q_list, P_list, Mask_list,
        O_bel, O_inv, O_mod, O_mod_inv,
        cfg, gens, log_eps
    )
    return i, stats

def zero_agent_metrics(N: int) -> dict:
    return {
        "e_self": 0.0,
        "e_align": 0.0,
        "e_mod_align": 0.0,
        "e_curv": 0.0,
        "e_curv_mod": 0.0,
        "phi_norm": 0.0,
        "phi_model_norm": 0.0
    }




def accumulate_and_log_metrics(results, agents, step, Q_list, Mask_list):
    keys = ["e_self", "e_align", "e_mod_align", "e_curv", "e_curv_mod"]
    accum = {k: 0.0 for k in keys}
    total_support = 0

    for i, s in enumerate(results):
        support = int(Mask_list[i].sum())
        total_support += support
        for k in keys:
            accum[k] += s[k]

        agents[i].log_metrics(step, {
            "kl_self":       s["e_self"]      / support,
            "kl_align":      s["e_align"]     / support,
            "kl_mod_align":  s["e_mod_align"] / support,
            "curv_energy":   s["e_curv"]      / support,
            "curv_model_energy": s["e_curv_mod"] / support,
            "phi_norm":      s["phi_norm"],
            "phi_model_norm": s["phi_model_norm"],
        })

    S = max(total_support, 1)
    metrics = {k: accum[k] / S for k in keys}
    metrics["total_energy"] = sum(accum.values()) / S
    metrics["step"] = step
    return metrics


def compute_all_agent_metrics(i, A, Q_list, P_list, Mask_list,
                               O_bel, O_inv, O_mod, O_mod_inv,
                               cfg, gens, log_eps):

    mask = Mask_list[i]
    q_mu, q_sigma = A.mu_q_field, A.sigma_q_field
    p_mu, p_sigma = A.mu_p_field, A.sigma_p_field

    stats = {
        "e_self":        compute_self_energy(q_mu, q_sigma, p_mu, p_sigma, mask, cfg["alpha"], log_eps),
        "e_align":       compute_alignment_energy(i, A, Q_list, Mask_list, O_bel, O_inv, cfg["beta"], log_eps, cfg.get("n_jobs_align", 1)),
        "e_mod_align":   compute_model_alignment_energy(i, A, P_list, Mask_list, O_mod, O_mod_inv, cfg["model_align_weight"], log_eps, cfg.get("n_jobs_align", 1)),
        "e_curv":        0.0,
        "e_curv_mod":    0.0,
        "phi_norm":      np.linalg.norm(A.phi[mask], axis=-1).sum(),
        "phi_model_norm": np.linalg.norm(A.phi_model[mask], axis=-1).sum()
    }

    # Optional: compute curvature energies if nonzero weight
    if cfg["curvature_weight"] > 0:
        stats["e_curv"], _     = compute_curvature_energy(A.phi,       mask, cfg["curvature_weight"], gens)
        stats["e_curv_mod"], _ = compute_curvature_energy(A.phi_model, mask, cfg["curvature_weight"], gens)

    return stats


def log_all_metrics_fused(
    agents,
    step,
    params=None,
    q_field="q",
    p_field="p",
    phi_belief_field="phi",
    phi_model_field="phi_model",
    mask_field="mask",
    n_jobs=-1
):
    cfg = config if params is None else {**vars(config), **params}
    log_eps = cfg.get("log_eps", 1e-10)

    N = len(agents)  # ← FIX: number of agents
    gens = get_generators(cfg["group_name"], cfg["K"])  # ← FIX: needed for curvature terms

    # Precompute fields
    Q_list     = [(A.mu_q_field, A.sigma_q_field) for A in agents]
    P_list     = [(A.mu_p_field, A.sigma_p_field) for A in agents]
    Mask_list = [np.asarray(getattr(A, mask_field), dtype=bool) for A in agents]

    O_bel      = [A.Omega for A in agents]
    O_inv      = [A.Omega_inv for A in agents]
    O_mod      = [A.Omega_model for A in agents]
    O_mod_inv  = [A.Omega_model_inv for A in agents]

    results = Parallel(n_jobs=n_jobs, backend="threading")(
        delayed(compute_all_agent_metrics)(
            i, agents[i], Q_list, P_list, Mask_list,
            O_bel, O_inv, O_mod, O_mod_inv,
            cfg, gens, log_eps
        )
        for i in range(N)
    )
    return accumulate_and_log_metrics(results, agents, step, Q_list, Mask_list)


def log_max_overlap_fields(agents, step, outdir, eps=config.support_cutoff_eps):
    """
    Logs full diagnostics from the max-overlap pair:
    - μ/Σ for q and p
    - belief/model alignment fields
    - KL fields
    - Spatial pullback metric M_ab = ∂μᵗ Σ⁻¹ ∂μ
    - Lie-algebra pullbacks: I, G, M_vis, Delta, M_dark
    """
    os.makedirs(outdir, exist_ok=True)

    # 1) Find most overlapping pair
    max_overlap = 0
    best_pair = None
    for i, A in enumerate(agents):
        mask_i = A.mask > eps
        if not mask_i.any():
            continue
        for nb in A.neighbors:
            j = nb["id"]
            mask_j = agents[j].mask > eps
            ov = mask_i & mask_j
            if (cnt := int(ov.sum())) > max_overlap:
                max_overlap = cnt
                best_pair = (i, j)

    if best_pair is None:
        print(f"[DEBUG] No overlapping pair at step {step}")
        return

    i, j = best_pair
    A = agents[i]

    # 2) Ensure Ω caches populated
    gens = get_generators(config.group_name, config.K)
    for B in [agents[i], agents[j]]:
        if B._exp_phi is None:
            B._exp_phi = exp_lie_algebra_irrep(B.phi, gens, group_name=config.group_name)
        if B._exp_neg_phi is None:
            B._exp_neg_phi = exp_lie_algebra_irrep(-B.phi, gens, group_name=config.group_name)
        if B._exp_phi_model is None:
            B._exp_phi_model = exp_lie_algebra_irrep(B.phi_model, gens, group_name=config.group_name)
        if B._exp_neg_phi_model is None:
            B._exp_neg_phi_model = exp_lie_algebra_irrep(-B.phi_model, gens, group_name=config.group_name)

        # 3) Fields
    mu_q    = A.mu_q_field                              # (H, W, K)
    sigma_q = A.sigma_q_field                           # (H, W, K) or (H, W, K, K)
    mu_p    = A.mu_p_field
    sigma_p = A.sigma_p_field
    mask_i  = (A.mask > eps).astype(np.float32)

        # Promote diagonal sigma fields to full (H, W, K, K)
    if sigma_q.ndim == 3:
        # Assume sigma_q is standard deviation → square to get variance
        sigma_q = np.einsum("...k,kl->...kl", sigma_q**2, np.eye(sigma_q.shape[-1], dtype=sigma_q.dtype))
    if sigma_p.ndim == 3:
        sigma_p = np.einsum("...k,kl->...kl", sigma_p**2, np.eye(sigma_p.shape[-1], dtype=sigma_p.dtype))


        # Flatten mu and sigma to (N, K) and (N, K, K)
    H, W, K = mu_q.shape
    mu_q_flat = mu_q.reshape(-1, K)
    mu_p_flat = mu_p.reshape(-1, K)
    sigma_q_flat = sigma_q.reshape(-1, K, K)
    sigma_p_flat = sigma_p.reshape(-1, K, K)

    # 4) Alignment and KL fields
    belief_align_field = compute_alignment_field(agents, i)
    model_align_field  = compute_model_alignment_field(agents, i)

    agent = agents[i]
    mean_kl = np.mean(belief_align_field[agent.mask > config.support_cutoff_eps])
    print(f"[KL alignment] Agent {i}: mean KL(q_i ‖ Ω q_j) = {mean_kl:.4e}")

    kl_self_vals     = kl_divergence(mu_q_flat, sigma_q_flat, mu_p_flat, sigma_p_flat)
    kl_self_field    = kl_self_vals.reshape(H, W)

    kl_feedback_vals = kl_divergence(mu_p_flat, sigma_p_flat, mu_q_flat, sigma_q_flat)
    kl_feedback_field = kl_feedback_vals.reshape(H, W)

    # 5) Spatial pullback M_ab = ∂μᵗ Σ⁻¹ ∂μ
    M = compute_pullback_metric(mu_p, sigma_p)  # shape (H, W, 2, 2)
    tr_vis     = M[..., 0, 0] + M[..., 1, 1]
    delta      = M - np.transpose(M, (0, 1, 3, 2))
    delta_norm = np.linalg.norm(delta, axis=(2, 3))

    pullback_trace_vis   = float(np.mean(tr_vis * mask_i))
    pullback_trace_dark  = 0.0  # unused
    pullback_delta_norm  = float(np.mean(delta_norm * mask_i))

    # 6) Lie-algebra pullbacks from φ_model
    vis_inds  = [0, 1]
    dark_inds = [2]
    pull = compute_agent_pullback_blocks(A, vis_inds, dark_inds)

    # 7) Save all
    fname = os.path.join(outdir, f"step{step:05d}_pair_{i}_{j}.npz")
    np.savez_compressed(
        fname,
        agent_i             = i,
        agent_j             = j,
        overlap             = max_overlap,
        mask_i              = mask_i,
        belief_alignment    = belief_align_field,
        model_alignment     = model_align_field,
        mu_q                = mu_q,
        sigma_q             = sigma_q,
        mu_p                = mu_p,
        sigma_p             = sigma_p,
        kl_self             = kl_self_field,
        kl_feedback         = kl_feedback_field,
        pullback_metric     = M,
        pullback_trace_vis  = pullback_trace_vis,
        pullback_trace_dark = pullback_trace_dark,
        pullback_delta_norm = pullback_delta_norm,
        pullback_I          = pull["I"],
        pullback_G          = pull["G"],
        pullback_M_vis      = pull["M_vis"],
        pullback_M_dark     = pull["M_dark"],
        pullback_Delta      = pull["Delta"],
        phi                 = agents[i].phi,
        phi_model           = agents[i].phi_model,
)


def full_field_logger(agents, step: int, outdir: str, support_cutoff_eps=1e-3):
    """
    Save full-grid raw fields composited over all agents:
        - mu_q_field, sigma_q_field, phi
        - mu_p_field, sigma_p_field, phi_model
        - mask_sum
    """
    H, W, K = agents[0].mu_q_field.shape
    d = agents[0].phi.shape[-1]
    dump_dir = Path(outdir) / "field_dumps" / f"step{step:05d}"
    dump_dir.mkdir(parents=True, exist_ok=True)

    # Initialize accumulators
    mu_q_accum      = np.zeros((H, W, K), dtype=np.float32)
    sigma_q_accum   = np.zeros((H, W, K, K), dtype=np.float32)
    phi_accum       = np.zeros((H, W, d), dtype=np.float32)

    mu_p_accum      = np.zeros((H, W, K), dtype=np.float32)
    sigma_p_accum   = np.zeros((H, W, K, K), dtype=np.float32)
    phi_model_accum = np.zeros((H, W, d), dtype=np.float32)

    mask_sum        = np.zeros((H, W), dtype=np.float32)

    for A in agents:
        mask = (A.mask > support_cutoff_eps).astype(np.float32)

        mu_q_accum    += A.mu_q_field * mask[..., None]
        sigma_q_accum += A.sigma_q_field * mask[..., None, None]
        phi_accum     += A.phi * mask[..., None]

        mu_p_accum    += A.mu_p_field * mask[..., None]
        sigma_p_accum += A.sigma_p_field * mask[..., None, None]
        phi_model_accum += A.phi_model * mask[..., None]

        mask_sum += mask

    # Avoid divide-by-zero
    mask_safe = np.where(mask_sum > 0, mask_sum, 1.0)

    mu_q_avg     = mu_q_accum / mask_safe[..., None]
    sigma_q_avg  = sigma_q_accum / mask_safe[..., None, None]
    phi_avg      = phi_accum / mask_safe[..., None]

    mu_p_avg     = mu_p_accum / mask_safe[..., None]
    sigma_p_avg  = sigma_p_accum / mask_safe[..., None, None]
    phi_model_avg = phi_model_accum / mask_safe[..., None]

    # Save
    np.save(dump_dir / "mu_q_field.npy", mu_q_avg)
    np.save(dump_dir / "sigma_q_field.npy", sigma_q_avg)
    np.save(dump_dir / "phi.npy", phi_avg)

    np.save(dump_dir / "mu_p_field.npy", mu_p_avg)
    np.save(dump_dir / "sigma_p_field.npy", sigma_p_avg)
    np.save(dump_dir / "phi_model.npy", phi_model_avg)

    np.save(dump_dir / "mask_sum.npy", mask_sum)

    print(f"[SAVED] Full fields → {dump_dir}")
