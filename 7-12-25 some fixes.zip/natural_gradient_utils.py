# -*- coding: utf-8 -*-
"""
Created on Sun Jul  6 14:42:59 2025

@author: chris and christine
"""
import numpy as np
import config
from joblib import Parallel, delayed



def compute_fisher_metric_block_diag(sigma: np.ndarray):
    """
    Compute block-diagonal approximation to the Fisher metric for MVN(μ, Σ)

    Fisher block structure:
    [ Σ⁻¹               0         ]
    [   0   (1/2) Σ⁻¹ ⊗ Σ⁻¹       ]

    Args:
        sigma: (K, K) positive-definite covariance matrix

    Returns:
        fisher_mu_inv: (K, K)
        fisher_sigma_inv: (K, K, K, K) tensor for Σ part
    """
    
    sigma_sanitized = sanitize_sigma(sigma, eps=1e-6, debug=config.debug_sanitize_sigma)
    sigma_inv = np.linalg.inv(sigma_sanitized)


    fisher_mu = sigma_inv
    fisher_sigma = 0.5 * np.einsum('ij,kl->ijkl', sigma_inv, sigma_inv)

    return fisher_mu, fisher_sigma

def apply_lie_natural_gradient(phi, grad_phi, G_inv=None):
    """
    Apply Lie-natural gradient update to φ using optional inverse Fisher metric.

    Args:
        phi      : (H, W, d) or None — current φ field (not used unless needed for adaptive G)
        grad_phi : (H, W, d)         — raw gradient
        G_inv    : (d, d) or None    — optional inverse Fisher metric (constant)

    Returns:
        nat_grad : (H, W, d) natural gradient update
    """
    if G_inv is None:
        return grad_phi  # Euclidean fallback

    # Apply the inverse metric globally — assume grad_phi already masked
    nat_grad = np.einsum("ab,...b->...a", G_inv, grad_phi)

    # Optional normalization to ensure consistent scale across agents
    norm = np.linalg.norm(nat_grad, axis=-1, keepdims=True) + 1e-8
    nat_grad_normalized = nat_grad / norm

    return nat_grad_normalized


def apply_natural_gradient_batch(mu_field, sigma_field, grad_mu_field, grad_sigma_field):
    """
    Fast version using approximate Fisher metric:
      G_μ = Σ⁻¹,   G_Σ = ½ Σ⁻¹ ⊗ Σ⁻¹
    Assumes sanitized SPD σ already. Checks for finite gradients.
    """
    shape = mu_field.shape
    eps = getattr(config, "eps", 1e-8)

    if len(shape) == 3:
        H, W, K = shape
        is_field = True
        mu_flat = mu_field.reshape(-1, K)
        sigma_flat = sigma_field.reshape(-1, K, K)
        grad_mu_flat = grad_mu_field.reshape(-1, K)
        grad_sigma_flat = grad_sigma_field.reshape(-1, K, K)
    elif len(shape) == 2:
        N, K = shape
        is_field = False
        mu_flat = mu_field
        sigma_flat = sigma_field
        grad_mu_flat = grad_mu_field
        grad_sigma_flat = grad_sigma_field
    else:
        raise ValueError(f"Unsupported shape {shape} for mu_field")

    # Optional: assert gradients are valid
    assert np.all(np.isfinite(grad_mu_flat)), "NaNs or Infs in ∇μ"
    assert np.all(np.isfinite(grad_sigma_flat)), "NaNs or Infs in ∇Σ"

    # Optional: clip large gradient values instead of full nan_to_num
    clip_val = getattr(config, "gradient_clip", 1e6)
    grad_mu_flat = np.clip(grad_mu_flat, -clip_val, clip_val)
    grad_sigma_flat = np.clip(grad_sigma_flat, -clip_val, clip_val)

    # Invert Fisher metric
    eye = np.eye(K, dtype=mu_flat.dtype)
    sigma_reg = sigma_flat + eps * eye[None, :, :]
    sigma_reg = 0.5 * (sigma_reg + np.transpose(sigma_reg, (0, 2, 1)))

    sigma_inv = np.linalg.inv(sigma_reg)

    # Δμ = −Σ⁻¹ ∇μ
    delta_mu = -np.einsum("nij,nj->ni", sigma_inv, grad_mu_flat)

    # ΔΣ = −½ Σ⁻¹ ⊗ Σ⁻¹ ∇Σ
    delta_sigma = -0.5 * np.einsum("nij,nkl->nijkl", sigma_inv, sigma_inv)
    delta_sigma = np.einsum("nijkl,nkl->nij", delta_sigma, grad_sigma_flat)

    assert np.all(np.isfinite(delta_sigma)), "Delta Sigma has NaNs or Infs"


    if is_field:
        return delta_mu.reshape(H, W, K), delta_sigma.reshape(H, W, K, K)
    else:
        return delta_mu, delta_sigma


def compute_lie_metric(generators: np.ndarray):
    """
    Compute inner product matrix G_{ab} = Tr(G_a^T G_b) and its inverse.

    Args:
        generators: (d, K, K) basis of Lie algebra

    Returns:
        G: (d, d) metric matrix
        G_inv: (d, d) inverse metric
    """
    d = generators.shape[0]
    G = np.einsum("aij,bij->ab", generators, generators)
    G = 0.5 * (G + G.T)  # Symmetrize for stability

    eps = getattr(config, "eps", 1e-6)
    G_inv = np.linalg.inv(G + np.eye(d) * eps)

    return G, G_inv



def _sanitize_one_sigma(S, eps=1e-6):
    """
    Sanitize a single covariance matrix to ensure it's symmetric positive-definite (SPD).

    Returns:
        (S_sanitized, clipped): sanitized matrix and boolean flag indicating if it was modified
    """
    S = 0.5 * (S + S.T)  # ensure symmetry

    # First line of defense: handle invalid or pathological cases
    if not np.all(np.isfinite(S)) or np.trace(S) < eps or np.any(np.diag(S) <= 0):
        return np.eye(S.shape[0]) * eps, True

    try:
        eigvals, eigvecs = np.linalg.eigh(S)
    except np.linalg.LinAlgError:
        return np.eye(S.shape[0]) * eps, True

    clipped = np.any(eigvals < eps)
    eigvals_clipped = np.clip(eigvals, eps, None)

    if clipped:
        S = eigvecs @ np.diag(eigvals_clipped) @ eigvecs.T
        S = 0.5 * (S + S.T)  # re-symmetrize

    return S, clipped


def sanitize_sigma(Sigma, eps=1e-6, debug=False, n_jobs=None, parallel_threshold=50):
    """
    Sanitize a batch of covariance matrices to ensure SPD.

    Parameters:
        Sigma: (..., K, K) ndarray — batch of covariances
        eps: minimum eigenvalue threshold
        debug: if True, prints a summary if any matrices are clipped
        n_jobs: number of parallel workers (default: config.num_cores or 1)
        parallel_threshold: min number of matrices before enabling parallelization

    Returns:
        Sanitized SPD matrices with same shape as input.
    """
    shape = Sigma.shape
    flat_sigma = Sigma.reshape(-1, shape[-2], shape[-1])
    n_total = flat_sigma.shape[0]
    n_jobs = n_jobs or getattr(config, "num_cores", 1)

    if n_total < parallel_threshold or n_jobs == 1:
        results = [_sanitize_one_sigma(S, eps) for S in flat_sigma]
    else:
        from joblib import parallel_backend
        with parallel_backend("threading"):
            results = Parallel(n_jobs=n_jobs)(
                delayed(_sanitize_one_sigma)(S, eps) for S in flat_sigma
            )

    Sigma_out, clipped_flags = zip(*results)
    if debug:
        n_clipped = sum(clipped_flags)
        if n_clipped > 0:
            print(f"[SPD sanitize] Clipped {n_clipped} / {n_total} matrices to eps={eps:.1e}")

    out = np.stack(Sigma_out, axis=0).astype(Sigma.dtype).reshape(shape)
    return out







