# -*- coding: utf-8 -*-
"""
Created on Tue Jul  8 18:54:35 2025

@author: chris and christine
"""

import numpy as np
import matplotlib.pyplot as plt
from generalized_agents import initialize_agents
from get_generators import get_generators
import config

# ── Parameters ──
seed = 42
domain_size = (20, 20)
N = 1
K = 5
lie_dim = 3  # for SL(2,R) or SO(3) minimal
dtype = np.float32

# ── Run agent initialization ──
agents = initialize_agents(seed, domain_size, N, K, lie_dim, visualize=False)
A = agents[0]

# ── Diagnostic fields ──
mu_q_norm = np.linalg.norm(A.mu_q_field, axis=-1)
sigma_q_trace = np.trace(A.sigma_q_field, axis1=-2, axis2=-1)
phi_norm = np.linalg.norm(A.phi, axis=-1)
mask = A.mask

# ── Plot ──
def show(field, title, cmap="viridis"):
    plt.figure()
    plt.imshow(field, cmap=cmap)
    plt.colorbar(label=title)
    plt.title(title)
    plt.axis("off")
    plt.tight_layout()

show(mu_q_norm, "‖μ_q‖")
show(sigma_q_trace, "Tr(Σ_q)")
show(phi_norm, "‖φ‖")
show(mask, "Agent Mask")

plt.show()
