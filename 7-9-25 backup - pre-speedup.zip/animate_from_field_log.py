# -*- coding: utf-8 -*-
"""
Animate all saved field dumps over time.
Created: Jul 9, 2025
"""

import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation
from pathlib import Path

# ─── Config ───────────────────────────────────────────────────────
DUMP_DIR   = Path("checkpoints/field_dumps")
OUT_DIR    = Path("field_dumps_animations")
FPS        = 25  # ← Change FPS here
OUT_DIR.mkdir(parents=True, exist_ok=True)

FIELDS = {
    "mu_q_field":    ("‖μ_q‖",      "magma"),
    "mu_p_field":    ("‖μ_p‖",      "plasma"),
    "sigma_q_field": ("Tr[σ_q]",    "cividis"),
    "sigma_p_field": ("Tr[σ_p]",    "cividis"),
    "phi":           ("‖φ‖",         "viridis"),
    "phi_model":     ("‖φ_model‖",   "viridis"),
}

# ─── Helper ────────────────────────────────────────────────────────
def compute_vmin_vmax(field_name, stack):
    vmax = np.nanmax(stack)
    if "mu_" in field_name:
        vmin = 0.5 * vmax
    elif "sigma_" in field_name:
        vmin = 0.0
    else:
        vmin = 0.0
    return vmin, vmax

def extract_field(path):
    arr = np.load(path)
    if arr.ndim == 3:
        if "sigma" in path.name:
            return np.trace(arr, axis1=-2, axis2=-1)
        else:
            return np.linalg.norm(arr, axis=-1)
    elif arr.ndim == 2:
        return arr
    return None

# ─── Main ──────────────────────────────────────────────────────────
def main():
    step_dirs = sorted([d for d in DUMP_DIR.iterdir() if d.is_dir() and "step" in d.name])
    steps = [int(d.name.replace("step", "")) for d in step_dirs]

    for fname, (title, cmap) in FIELDS.items():
        frames = []
        for d in step_dirs:
            fpath = d / f"{fname}.npy"
            if not fpath.exists():
                continue
            field = extract_field(fpath)
            frames.append(field)

        if not frames:
            print(f"[SKIP] No data found for {fname}")
            continue

        valid_frames = [f for f in frames if f is not None]
        if not valid_frames:
            print(f"[SKIP] All frames were None for {fname}")
            continue

        stack = np.stack(valid_frames)

        vmin, vmax = compute_vmin_vmax(fname, stack)

        fig, ax = plt.subplots()
        img = ax.imshow(stack[0], cmap=cmap, vmin=vmin, vmax=vmax)
        cbar = plt.colorbar(img, ax=ax)
        ttl = ax.set_title(f"{title} — Step {steps[0]}")
        plt.tight_layout()

        def update(i):
            img.set_data(stack[i])
            ttl.set_text(f"{title} — Step {steps[i]}")
            return [img, ttl]

        ani = animation.FuncAnimation(fig, update, frames=len(stack), blit=False)
        out_path = OUT_DIR / f"{fname}.gif"
        ani.save(out_path, writer="pillow", fps=FPS)
        plt.close(fig)
        print(f"[SAVED] {out_path}")

if __name__ == "__main__":
    main()
