# -*- coding: utf-8 -*-
"""
Run Latin Hypercube parameter sweep and output both individual results and a consolidated CSV of sampled parameters.
"""
import os
import numpy as np
import pickle
import pandas as pd
from scipy.stats import qmc
from generalized_simulation import run_simulation
import argparse

DEFAULT_SAMPLES = 10  # Number of successful runs to obtain

# --- Base simulation parameters ---
base_params = {
    "group_name": "sl2r",
    "K": 7,
    "N": 4,
    "L": 15,
    "steps": 150,
    "debug": True,
}


def is_unstable(metrics, clip_threshold=40, energy_thresh=1e6, min_kl_thresh=-1e-5):
    """Check if a run should be rejected due to numerical instability."""
    if not metrics:
        return True

    for step in metrics:
        if any(np.isnan(v) or np.isinf(v) for v in step.values()):
            return True
        if step.get("energy_total", 0) > energy_thresh:
            return True
        clips = step.get("sanitize_clipped", 0)
        if clips > clip_threshold:
            return True
        for k in step:
            if "kl" in k.lower() and step[k] < min_kl_thresh:
                return True
    return False


def run_lhs_sweep(n_samples=DEFAULT_SAMPLES, output_dir="lhs_results", csv_path="lhs_samples.csv"):
    os.makedirs(output_dir, exist_ok=True)

    # Define sweep parameter ranges
    sweep_params = {
        "alpha":                 (0, 20),
        #"gamma":                 (0, 100),
        #"beta":                  (0, 100),
        "gauge_weight":          (0, 300),
        "model_align_weight":    (0, 300),
        # "model_gauge_weight":    (0, 100),
        "model_mass_weight":     (0, 300),
        #"model_feedback_weight": (0, 300),
        "phi_phi_tilde_coupling":(0, 300),
        #"phi_damping":           (0, 300),
        "model_curvature_weight":(0, 300),
        "curvature_weight":      (0, 300),
    }

    param_names = list(sweep_params)
    ranges = [sweep_params[k] for k in param_names]
    sampler = qmc.LatinHypercube(d=len(ranges))
    attempted_rows = set()

    # Save sweep spec
    sweep_spec_path = os.path.join(output_dir, "sweep_spec.pkl")
    with open(sweep_spec_path, "wb") as f:
        pickle.dump({
            "param_names": param_names,
            "ranges": sweep_params,
        }, f)

    all_params = []
    attempt_id = 0
    max_retries = 5

    while len(all_params) < n_samples:
        raw_sample = sampler.random(n=1)[0]
        sample_key = tuple(raw_sample.round(decimals=6))  # Avoid floating-point duplication
        if sample_key in attempted_rows:
            continue
        attempted_rows.add(sample_key)

        # Scale to parameter ranges
        row = qmc.scale([raw_sample], [lo for lo, hi in ranges], [hi for lo, hi in ranges])[0]

        sampled_params = dict(zip(param_names, row))
        attempt = 0
        success = False

        while attempt < max_retries and not success:
            entry = dict(base_params)
            entry.update(sampled_params)
            run_name = f"run_{attempt_id}_try{attempt}"
            subdir = os.path.join(output_dir, run_name)
            os.makedirs(subdir, exist_ok=True)

            print(f"\n[TRY {attempt}] {run_name} → {sampled_params}")
            try:
                agents, metrics = run_simulation(
                    outdir=subdir,
                    resume=False,
                    log_metrics=True,
                    log_fields=True,
                    num_cores=-1,
                    params=entry,
                )

                with open(os.path.join(subdir, "final_agents.pkl"), "wb") as f:
                    pickle.dump(agents, f)
                with open(os.path.join(subdir, "final_metrics.pkl"), "wb") as f:
                    pickle.dump(metrics, f)
                with open(os.path.join(subdir, "params.pkl"), "wb") as f:
                    pickle.dump(entry, f)

                log_path = os.path.join(subdir, "metric_log.pkl")
                if os.path.exists(log_path):
                    with open(log_path, "rb") as f:
                        metric_log = pickle.load(f)
                else:
                    metric_log = []

                if is_unstable(metric_log):
                    print(f"[REJECT] {run_name} failed stability check.")
                    attempt += 1
                    continue

                print(f"[✓] {run_name} accepted.")
                all_params.append(entry)
                attempt_id += 1
                success = True

            except Exception as e:
                print(f"[ERROR] {run_name} crashed: {e}")
                attempt += 1

        if not success:
            print(f"[✗] Abandoned sample after {max_retries} failed attempts.")

    df = pd.DataFrame(all_params)
    df.to_csv(csv_path, index=False)
    print(f"\n[DONE] CSV written → {csv_path}")
    print(f"[DONE] LHS sweep finished with {len(all_params)} valid runs.")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=f"Run LHS sweep with retry-until-valid logic (default {DEFAULT_SAMPLES})")
    parser.add_argument("-n", "--n_samples", type=int, default=DEFAULT_SAMPLES, help="Number of valid runs to collect")
    parser.add_argument("-o", "--output_dir", type=str, default="lhs_results", help="Directory to write results")
    parser.add_argument("-c", "--csv_path", type=str, default="lhs_samples.csv", help="Path to save parameter CSV")
    args = parser.parse_args()
    run_lhs_sweep(n_samples=args.n_samples, output_dir=args.output_dir, csv_path=args.csv_path)
