# lhs_analysis_combined.py

import os
import pickle
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from pathlib import Path

def load_pickle(path):
    with open(path, "rb") as f:
        return pickle.load(f)

def extract_run_metrics(run_dir):
    result = {"run": os.path.basename(run_dir)}
    param_path = Path(run_dir) / "params.pkl"
    if param_path.exists():
        result.update(load_pickle(param_path))

    metric_path = Path(run_dir) / "metric_log.pkl"
    if metric_path.exists():
        try:
            metrics = load_pickle(metric_path)
            if isinstance(metrics, list) and metrics:
                final = metrics[-1]
                for k, v in final.items():
                    if k != "step":
                        result[f"final_{k}"] = v
        except Exception as e:
            print(f"[ERROR] Failed to load metric_log from {run_dir}: {e}")

    # Load overlap metrics from latest max_overlap_step file
    field_dir = Path(run_dir) / "field_dumps"
    max_overlap_files = sorted(field_dir.glob("max_overlap_step*.pkl")) if field_dir.exists() else []
    if max_overlap_files:
        try:
            latest = load_pickle(max_overlap_files[-1])
            for k, v in latest.items():
                if isinstance(v, float):
                    result[f"overlap_{k}"] = v
                elif isinstance(v, (list, tuple, np.ndarray)):
                    result[f"overlap_{k}_shape"] = str(np.shape(v))
        except Exception as e:
            print(f"[ERROR] Failed to load max_overlap from {run_dir}: {e}")

    return result

def extract_timeseries(run_dir):
    run_name = os.path.basename(run_dir)
    metric_path = Path(run_dir) / "metric_log.pkl"
    if not metric_path.exists():
        return None
    try:
        metrics = load_pickle(metric_path)
        df = pd.DataFrame(metrics)
        df["run"] = run_name
        return df
    except Exception as e:
        print(f"[ERROR] Failed to parse time-series for {run_name}: {e}")
        return None

def format_param_value(val):
    try:
        return f"{float(val):.3g}"
    except:
        return str(val).replace(" ", "_").replace("/", "-").replace(":", "_")

def save_plots_and_rename(df_time, df_summary, base_dir, outdir, energy_thresh=2000, require_decreasing=False):
    Path(outdir).mkdir(parents=True, exist_ok=True)
    known_cols = set(df_time.columns) | {"run"}
    param_cols = [col for col in df_summary.columns if col not in known_cols]

    folder_keys = ["alpha", "beta", "gamma", "curvature_weight", "phi_phi_tilde_coupling"]
    good_runs = []

    for run, group in df_time.groupby("run"):
        if group["energy_total"].max() > energy_thresh:
            continue
        if not group["energy_total"].notna().all():
            continue
        if require_decreasing and group["energy_total"].iloc[-1] >= group["energy_total"].iloc[0]:
            continue

        row = df_summary[df_summary["run"] == run]
        if row.empty:
            continue
        row = row.iloc[0]

        param_str = "__".join([f"{k}={format_param_value(row[k])}" for k in folder_keys if k in row])
        safe_name = f"{run}__{param_str}".replace("[", "").replace("]", "").replace("\n", "").replace(" ", "")
        safe_name = safe_name.replace("_0.", "_0p").replace(".", "p")
        new_dir = Path(outdir) / safe_name[:240]

        try:
            new_dir.mkdir(parents=True, exist_ok=True)
        except Exception as e:
            print(f"[SKIP] Couldn't create folder {new_dir}: {e}")
            continue

        # Save full parameter metadata
        with open(new_dir / "params.txt", "w") as f:
            for k in param_cols:
                f.write(f"{k}: {row.get(k, '')}\n")

        # Save all plots
        for metric in group.columns:
            if metric in {"step", "run"}:
                continue
            plt.figure(figsize=(6, 4))
            plt.plot(group["step"], group[metric], lw=2)
            plt.xlabel("Step")
            plt.ylabel(metric)
            plt.title(f"{run} — {metric}")
            plt.grid(True)
            plt.tight_layout()
            plt.savefig(new_dir / f"{metric}.png")
            plt.close()

        print(f"[✓] Saved and renamed {run} → {new_dir.name}")
        good_runs.append(run)

    return good_runs

def main():
    BASE_DIR = "lhs_results"
    METRICS_CSV = Path(BASE_DIR) / "metrics_over_time.csv"
    SUMMARY_CSV = Path(BASE_DIR) / "summary_metrics.csv"
    OUTPUT_DIR = Path(BASE_DIR) / "individual_metrics"

    run_dirs = sorted([Path(BASE_DIR) / d for d in os.listdir(BASE_DIR) if d.startswith("run_")])
    all_summary, all_timeseries = [], []

    for run_dir in run_dirs:
        print(f"\n{'='*40}\n[RUN] {run_dir}\n{'='*40}")
        summary = extract_run_metrics(run_dir)

        # Print relevant params
        for k in summary:
            if k.startswith("final_") or k.startswith("overlap_") or k in {"run", "alpha", "beta", "gamma"}:
                print(f"{k:<30} = {summary[k]}")

        all_summary.append(summary)

        ts_df = extract_timeseries(run_dir)
        if ts_df is not None:
            all_timeseries.append(ts_df)

    df_summary = pd.DataFrame(all_summary)
    df_summary.to_csv(SUMMARY_CSV, index=False)
    print(f"\n✅ Saved summary CSV → {SUMMARY_CSV}")

    if all_timeseries:
        df_time = pd.concat(all_timeseries, axis=0)
        if "total_energy" in df_time.columns:
            df_time = df_time.rename(columns={"total_energy": "energy_total"})
        df_time.to_csv(METRICS_CSV, index=False)
        print(f"✅ Saved timeseries CSV → {METRICS_CSV}")
    else:
        print("⚠️ No time-series data found.")
        return

    # Rename, filter, and plot
    valid_runs = save_plots_and_rename(df_time, df_summary, BASE_DIR, OUTPUT_DIR)
    print(f"\n[INFO] {len(valid_runs)} valid runs processed.")

if __name__ == "__main__":
    main()
