# -*- coding: utf-8 -*-
"""
Created on Fri Jun 20 13:35:02 2025

@author: chris and christine
"""

#!/usr/bin/env python3
import argparse
import sys
import pickle

# Import your modules
from holonomy.workflow import run_pipeline, run_experiments
from holonomy.viz import (
    plot_loop_path,
    plot_spatial_summary,
    plot_agent_cycle_summary,
    plot_time_series,
    plot_omega_deviations,
    animate_belief_vs_fiber_loop,
)

def main():
    parser = argparse.ArgumentParser(prog="holonomy",
                                     description="Holonomy analysis toolkit")
    sub = parser.add_subparsers(dest="command", required=True)

    # --- pipeline subcommand ---
    p = sub.add_parser("pipeline", help="Run the holonomy pipeline")
    p.add_argument("--loop-type", choices=["spatial", "agent_cycle"],
                   default="spatial", help="Which loop to sample")
    p.add_argument("--max-chain-length", type=int, default=3,
                   help="Max chain length for agent cycles")

    # --- experiments subcommand ---
    e = sub.add_parser("experiments", help="Run holonomy experiments")
    e.add_argument("experiment_name", type=str,
                   help="Name of the experiment to run")
    e.add_argument("--steps", type=int, default=100,
                   help="Number of time steps")

    # --- viz-path subcommand ---
    vp = sub.add_parser("viz-path", help="Visualize a single holonomy path")
    vp.add_argument("diag_pkl", type=str,
                    help="Pickle file with loop diagnostics")

    # --- viz-summary subcommand ---
    vs = sub.add_parser("viz-summary", help="Plot summary CSV of all runs")
    vs.add_argument("master_csv", type=str,
                    help="Master CSV file from workflow")

    # --- viz-timeseries subcommand ---
    vt = sub.add_parser("viz-timeseries", help="Plot time-series metrics")
    vt.add_argument("master_csv", type=str,
                    help="Master CSV file from workflow")

    # --- viz-dev subcommand ---
    vd = sub.add_parser("viz-dev", help="Plot ω-deviations diagnostics")
    vd.add_argument("diag_pkl", type=str,
                    help="Pickle file with deviation data")

    # --- viz-anim subcommand ---
    va = sub.add_parser("viz-anim", help="Animate belief vs fiber loop")
    va.add_argument("diag_pkl", type=str,
                    help="Pickle file with loop diagnostics")
    va.add_argument("--outdir", type=str, default="holonomy_gifs",
                    help="Directory to save GIFs")

    args = parser.parse_args()

    if args.command == "pipeline":
        run_pipeline(loop_type=args.loop_type,
                     max_chain_length=args.max_chain_length)

    elif args.command == "experiments":
        run_experiments(experiment_name=args.experiment_name,
                        steps=args.steps)

    elif args.command == "viz-path":
        with open(args.diag_pkl, "rb") as f:
            data = pickle.load(f)
        plot_loop_path(data)

    elif args.command == "viz-summary":
        plot_spatial_summary(args.master_csv)
        plot_agent_cycle_summary(args.master_csv)

    elif args.command == "viz-timeseries":
        plot_time_series(args.master_csv)

    elif args.command == "viz-dev":
        with open(args.diag_pkl, "rb") as f:
            data = pickle.load(f)
        plot_omega_deviations(data)

    elif args.command == "viz-anim":
        with open(args.diag_pkl, "rb") as f:
            data = pickle.load(f)
        animate_belief_vs_fiber_loop(data, outdir=args.outdir)

    else:
        parser.print_help()
        sys.exit(1)

if __name__ == "__main__":
    main()
