# -*- coding: utf-8 -*-
"""
Created on Tue Jun 17 16:26:21 2025

@author: chris and christine
"""

'''
holonomy_module.py

Module to compute gauge holonomy within a single agent (spatial loops) and across agents (agent-chain loops).
'''

import numpy as np
from transport_operator import compute_intra_agent_omega, compute_inter_agent_omega_at_point, transport_belief_spatially
import random
from config import domain_size, support_cutoff_eps

from scipy.linalg import logm, expm, norm
from find_agent_chains import construct_spatial_path_nd

def compute_spatial_loop_holonomy(agent, coords, generators, use_commutator=False, return_deviations=False):
    """
    Compute holonomy around a closed spatial loop within a single agent,
    by multiplying successive intra-agent frame maps and re-orthonormalizing
    at each step to prevent overflow/NaNs.

    Parameters:
        agent:             Agent object with a `.phi` field (array of shape domain × lie_dim)
        coords:            list of grid-coordinate tuples (first == last)
        generators:        array of shape (lie_dim, K, K) giving Lie‐algebra generators
        use_commutator:    whether to compute ω via commutator form
        return_deviations: whether to return stepwise ∥Ω - I∥ diagnostics

    Returns:
        H: np.ndarray of shape (K, K) giving the total holonomy
        deviations (optional): list of ∥Ω - I∥ norms per step
    """
    if len(coords) < 2 or coords[0] != coords[-1]:
        raise ValueError("coords must start and end at the same point")

    K = generators.shape[-1]
    H = np.eye(K, dtype=float)
    deviations = []

    for p0, p1 in zip(coords[:-1], coords[1:]):
        ω = compute_intra_agent_omega(
            agent.phi,
            p0,
            p1,
            generators,
        )
        H = ω @ H

        if return_deviations:
            deviations.append(np.linalg.norm(ω - np.eye(K)))

        if np.all(np.isfinite(H)):
            U, s, Vt = np.linalg.svd(H, full_matrices=False)
            H = U @ Vt
        else:
            raise RuntimeError(f"Holonomy overflow at step from {p0} to {p1}")

    # --- logm approximation error check ---
    try:
        logH = logm(H)
        approx_err = norm(expm(logH) - H)
        print(f"[Spatial: Holonomy logm error] ‖exp(logH) - H‖ = {approx_err:.2e}")
    except Exception as e:
        print(f"[Spatial Holonomy logm error] Exception during logm: {e}")

    return (H, deviations) if return_deviations else H

from scipy.linalg import logm, expm, norm

import time


def compute_agent_cycle_holonomy(
    agents,
    agent_cycle,
    overlap_points,
    generators,
    initial_belief=None,
    return_deviations=False,
    return_logm=False,
    return_beliefs=False,
    use_commutator=False,
):
    """
    Compute non-Abelian holonomy around a closed loop of agents,
    optionally tracking belief propagation step-by-step.

    Parameters:
        agents: list of Agent objects
        agent_cycle: list of agent IDs (first == last) defining a closed loop
        overlap_points: list of spatial coords where each consecutive pair overlaps
        generators: Lie algebra generators for gauge group
        initial_belief: np.ndarray of shape (K,) initial distribution at start
        return_deviations: track ∥Ω - I∥ norms per step
        return_logm: optionally return matrix logarithm of total holonomy
        return_beliefs: whether to return belief sequence
        use_commutator: whether to use commutator form for inter-agent transport

    Returns:
        H: np.ndarray (K×K) total holonomy operator
        deviations (optional): list of ∥Ω - I∥
        logH (optional): matrix logarithm of H
        beliefs (optional): list of propagated belief vectors at each micro-step
    """
    # Validate inputs
    if len(agent_cycle) < 2 or agent_cycle[0] != agent_cycle[-1]:
        raise ValueError("agent_cycle must start and end at the same agent")
    if len(overlap_points) != len(agent_cycle) - 1:
        raise ValueError("Mismatch between cycle and overlap points")

    K = generators.shape[-1]
    H = np.eye(K, dtype=float)
    deviations = []
    beliefs = []

    # Initialize belief tracking
    if return_beliefs:
        if initial_belief is None:
            raise ValueError("initial_belief must be provided when return_beliefs=True")
        b = initial_belief.copy()
        beliefs.append(b.copy())

    current_agent = agent_cycle[0]
    current_pos = tuple(agents[current_agent].center)

    start_time = time.time()

    # Loop through each hop
    for next_agent, overlap_pt in zip(agent_cycle[1:], overlap_points):
        # Stepwise spatial transport within current_agent
        path = construct_spatial_path_nd(current_pos, overlap_pt, domain_size, mask=agents[current_agent].mask)
        for p0, p1 in zip(path[:-1], path[1:]):
            ω = compute_intra_agent_omega(agents[current_agent].phi, p0, p1, generators)
            H = ω @ H
            if return_deviations:
                deviations.append(np.linalg.norm(ω - np.eye(K)))
            if return_beliefs:
                b = ω @ b; beliefs.append(b.copy())
            # re-orthonormalize
            U, _, Vt = np.linalg.svd(H, full_matrices=False)
            H = U @ Vt

        # Inter-agent gauge hop
        Ω = compute_inter_agent_omega_at_point(
            agents[current_agent].phi,
            agents[next_agent].phi,
            overlap_pt,
            generators,
            use_commutator
        )
        H = Ω @ H
        if return_deviations:
            deviations.append(np.linalg.norm(Ω - np.eye(K)))
        if return_beliefs:
            b = Ω @ b; beliefs.append(b.copy())
        U, _, Vt = np.linalg.svd(H, full_matrices=False)
        H = U @ Vt

        # Advance
        current_agent = next_agent
        current_pos = overlap_pt

    # Final spatial leg back to start
    start_center = tuple(agents[agent_cycle[0]].center)
    path = construct_spatial_path_nd(current_pos, start_center, domain_size, mask=agents[agent_cycle[0]].mask)
    for p0, p1 in zip(path[:-1], path[1:]):
        ω = compute_intra_agent_omega(agents[agent_cycle[0]].phi, p0, p1, generators)
        H = ω @ H
        if return_deviations:
            deviations.append(np.linalg.norm(ω - np.eye(K)))
        if return_beliefs:
            b = ω @ b; beliefs.append(b.copy())
        U, _, Vt = np.linalg.svd(H, full_matrices=False)
        H = U @ Vt

    duration = time.time() - start_time
    print(f"[✓] compute_agent_cycle_holonomy duration: {duration:.4f}s")

    # Prepare outputs
    outputs = [H]
    if return_deviations:
        outputs.append(deviations)
    if return_logm:
        outputs.append(logm(H))
    if return_beliefs:
        outputs.append(beliefs)

    return tuple(outputs) if len(outputs) > 1 else H


def sample_self_avoiding_loop_within_mask(
    center,
    mask,
    *,
    min_length=4,
    max_length=1000,
    support_cutoff=support_cutoff_eps,
    seed=None
):
    """
    Generate a random self‐avoiding closed loop on a periodic grid,
    staying entirely where mask >= support_cutoff.
    """
    D = len(domain_size)
    rng = random.Random(seed)

    while True:
        visited = {tuple(center)}
        path = [tuple(center)]
        current = np.array(center, dtype=int)
        prev = None

        for _ in range(max_length):
            neighbors = []
            for axis in range(D):
                for d in (-1, +1):
                    nb = list(current)
                    nb[axis] = (nb[axis] + d) % domain_size[axis]
                    nb = tuple(nb)
                    if np.all(mask[nb] >= support_cutoff):
                        neighbors.append(nb)

            if tuple(center) in neighbors and len(path) >= min_length:
                path.append(tuple(center))
                return path

            candidates = [nb for nb in neighbors if nb != prev and nb not in visited]
            if not candidates:
                break

            nxt = rng.choice(candidates)
            prev = tuple(current.tolist())
            current = np.array(nxt, dtype=int)
            visited.add(nxt)
            path.append(nxt)

        continue
