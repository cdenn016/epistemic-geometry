# diagnostics_metrics.py
import numpy as np
import config
from scipy.ndimage import laplace
from generalized_math_utils import sanitize_q, masked_norm
from generalized_omega import (
    exp_lie_algebra_irrep,
    batch_apply_omega,
    repair_if_forgotten_batch,
    compute_field_strength,
    get_generators,
)

_DEFAULT_CUTOFF = getattr(config, "support_cutoff_eps", 1e-3)

from config import log_eps, overlap_eps, support_cutoff_eps, K

def support_mask(mask, cutoff=_DEFAULT_CUTOFF):
    return (mask > cutoff)

def overlap_mask(mask_i, mask_j, cutoff=_DEFAULT_CUTOFF):
    return support_mask(mask_i, cutoff) & support_mask(mask_j, cutoff)


def kl_divergence(q1, q2, eps=1e-12):
    q1 = np.clip(q1, eps, 1.0)
    q2 = np.clip(q2, eps, 1.0)
    return np.sum(q1 * (np.log(q1) - np.log(q2)), axis=-1)


def compute_kl_field(agents, i):
    q = sanitize_q(agents[i].q)
    p = sanitize_q(agents[i].p)
    kl = kl_divergence(q, p)
    return kl * agents[i].mask

def compute_phi_norm_field(agents, i, phi_field="phi"):
    phi = getattr(agents[i], phi_field)
    return np.linalg.norm(phi, axis=-1) * agents[i].mask


import numpy as np
import config
from generalized_math_utils import sanitize_q, laplacian_field
from generalized_omega import exp_lie_algebra_irrep, batch_apply_omega, compute_field_strength
from generalized_update_rules import kl_divergence


from typing import Dict


def threshold_mask(mask: np.ndarray) -> np.ndarray:
    """
    Turn a float support field into a boolean support region.
    Works for any dimensionality of mask.
    """
    eps = getattr(config, "support_cutoff_eps", 1e-3)
    return mask > eps  # same shape, but boolean

def compute_free_energy(agent) -> float:
    q = agent.q   # shape (..., K)
    p = agent.p   # same shape

    # 1) threshold to boolean
    mask_bool = threshold_mask(agent.mask)    # shape (...), dtype=bool

    # 2) index out all K-vectors at masked points
    #    This works whether ... is 1D, 2D, 3D, etc.
    q_vals = q[mask_bool]     # shape (n_points, K)
    p_vals = p[mask_bool]

    # 3) compute per-point KL and average
    tiny = 1e-12
    ratio = (q_vals + tiny) / (p_vals + tiny)
    kl_per_point = np.sum(q_vals * np.log(ratio), axis=-1)
    return float(np.mean(kl_per_point))


def compute_coherence(phi: np.ndarray, mask: np.ndarray) -> float:
    # use the same threshold for boolean selection
    mask_bool = threshold_mask(mask)
    phis = phi[mask_bool]         # shape (n_points,)
    return np.abs(np.mean(np.exp(1j * phis)))

def collect_agent_metrics(agent, step: int) -> Dict[str, float]:
    """
    Build a dict of all the per-agent metrics you want to log.
    """
    metrics: Dict[str, float] = {}

    # existing diagnostics (example placeholders)
    # metrics['kl_self']   = compute_kl_self(agent.q, agent.p)
    # metrics['phi_norm']  = np.linalg.norm(agent.phi)
    # metrics['entropy']   = compute_entropy(agent.q)

    # add coherence
    metrics['coherence']    = compute_coherence(agent.phi, agent.mask)
    # add free energy
    metrics['free_energy']  = compute_free_energy(agent)

    # log into the agent
    agent.log_metrics(step, metrics)
    return metrics

from typing import Dict, List, Any
import numpy as np



# Helper wrappers for averaging per-point fields over an agent's support

def compute_avg_kl_self(agent: Any, agents: List[Any], support_eps: float = 1e-3) -> float:
    """
    Average the self-KL field D_KL(q||p) over the agent's support.
    """
    mask = agent.mask > support_eps
    field = compute_kl_field(agents, agent.id)
    values = field[mask]
    return float(values.sum() / (mask.sum() or 1))


def compute_avg_kl_align(agent: Any, agents: List[Any], generators: Any, support_eps: float = 1e-3) -> float:
    """
    Average the KL(q||Omega q) alignment field over the agent's support.
    """
    mask = agent.mask > support_eps
    field = compute_alignment_field(agents, agent.id, generators)
    values = field[mask]
    return float(values.sum() / (mask.sum() or 1))


def compute_avg_kl_model_align(agent: Any, agents: List[Any], generators: Any, support_eps: float = 1e-3) -> float:
    """
    Average the KL(p||~Omega p) model alignment field over the agent's support.
    """
    mask = agent.mask > support_eps
    field = compute_model_alignment_field(agents, agent.id, generators)
    values = field[mask]
    return float(values.sum() / (mask.sum() or 1))


def collect_agent_metrics(agent: Any,
                          agents: List[Any],
                          generators: Any,
                          step: int) -> Dict[str, float]:
    """
    Build a dict of all the per-agent metrics for logging, using helper wrappers.
    """
    metrics: Dict[str, float] = {}

    # KL-based metrics
    metrics['kl_self']        = compute_avg_kl_self(agent, agents)
    metrics['kl_align']       = compute_avg_kl_align(agent, agents, generators)
    metrics['kl_model_align'] = compute_avg_kl_model_align(agent, agents, generators)

    # Free energy & coherence
    metrics['free_energy']     = compute_free_energy(agent)
    metrics['coherence']       = compute_coherence(agent.phi,       agent.mask)
    metrics['model_coherence'] = compute_coherence(agent.phi_model, agent.mask)

    # Optional: entropy, if available
    try:
        mask = agent.mask > 1e-3
        ent_vals = compute_entropy_field(agents, agent.id)
        metrics['entropy'] = float(ent_vals[mask].sum() / (mask.sum() or 1))
    except NameError:
        pass

    # Log into agent
    agent.log_metrics(step, metrics)
    return metrics


def _batch_alignment_energy(pairs, generators, weight, log_eps):
    """
    Batch-compute alignment energy for pairs of (qi_patch, qj_patch, diff_patch).
    Returns weighted sum of D_KL(qi || Omega qj).
    """
    if not pairs:
        return 0.0
    # Stack all per-overlap data
    qi_all   = np.vstack([qi for qi, qj, diff in pairs])
    qj_all   = np.vstack([qj for qi, qj, diff in pairs])
    diff_all = np.vstack([diff for qi, qj, diff in pairs])

    # Compute all Omegas and apply
    Omegas_all = exp_lie_algebra_irrep(diff_all, generators)
    qj_rot_all = batch_apply_omega(qj_all, Omegas_all)
    # Sanitize to avoid log(0)
    qj_rot_all = sanitize_q(qj_rot_all, eps=log_eps)

    # Compute KL per point
    kl_vals = np.sum(qi_all * (np.log(qi_all) - np.log(qj_rot_all)), axis=-1)
    return weight * np.sum(kl_vals)


def compute_total_energy(
    agents,
    generators,
    params: dict,
    q_field="q",
    p_field="p",
    phi_belief_field="phi",
    phi_model_field="phi_model",
) -> dict:
    """
    Optimized total energy: combines self-KL, laplacian, curvature, and neighbor alignments in one pass.
    """
    # 1) Hyperparameters
    alpha            = params.get("alpha", config.alpha)
    beta             = params.get("beta", config.beta)
    beta_tilde       = params.get("beta_tilde", config.model_align_weight)
    gamma            = params.get("gamma", config.gamma)
    gamma_tilde      = params.get("gamma_tilde", getattr(config, "gamma_tilde", 0.0))
    curvature_weight = params.get("curvature_weight", config.curvature_weight)
    log_eps          = params.get("log_eps", config.log_eps)
    cutoff           = params.get("support_cutoff_eps", config.support_cutoff_eps)

    # 2) Pre-sanitize all fields once
    Q_list, P_list = [], []
    PHI_b_list, PHI_m_list, MASK_list = [], [], []
    for A in agents:
        mask = (A.mask > cutoff)
        MASK_list.append(mask)
        Q_list.append(sanitize_q(getattr(A, q_field), eps=log_eps))
        P_list.append(sanitize_q(getattr(A, p_field), eps=log_eps))
        PHI_b_list.append(getattr(A, phi_belief_field))
        PHI_m_list.append(getattr(A, phi_model_field))

    # 3) Initialize accumulators
    E_kl = E_lap = E_lap_m = E_curv = E_align = E_model_align = 0.0

    # 4) Single pass over agents and neighbor pairs
    for i, A in enumerate(agents):
        mask_i = MASK_list[i]
        qi, pi       = Q_list[i], P_list[i]
        phii, phim_i = PHI_b_list[i], PHI_m_list[i]

        # Self-KL
        D_kl = kl_divergence(qi, pi)
        E_kl += alpha * D_kl[mask_i].sum()

        # Belief-phase Laplacian
        lap_b = laplacian_field(phii)[mask_i]
        E_lap += gamma * np.linalg.norm(lap_b, axis=-1).sum()
        # Model-phase Laplacian
        lap_m = laplacian_field(phim_i)[mask_i]
        E_lap_m += gamma_tilde * np.linalg.norm(lap_m, axis=-1).sum()

        # Model curvature
        if curvature_weight > 0:
            Fdict = compute_field_strength(phim_i, generators)
            Fstack = np.stack(list(Fdict.values()), axis=0)  # (n_pairs, X, Y)
            E_curv += curvature_weight * Fstack[:, mask_i].sum()

        # Neighbor alignments
        for nb in A.neighbors:
            j = nb['id']
            if j <= i:
                continue
            mask_j = MASK_list[j]
            overlap = mask_i & mask_j
            if not overlap.any():
                continue

            # Belief alignment
            delta_q = phii[overlap] - PHI_b_list[j][overlap]
            Omega_q = exp_lie_algebra_irrep(delta_q, generators)        # (n, K, K)
            qj_tr = batch_apply_omega(Q_list[j][overlap], Omega_q)

            kl_q   = kl_divergence(qi[overlap], qj_tr)
            E_align += beta * kl_q.sum()

            # Model alignment
            delta_p = phim_i[overlap] - PHI_m_list[j][overlap]
            Omega_p = exp_lie_algebra_irrep(delta_p, generators)
            pj_tr = batch_apply_omega(P_list[j][overlap], Omega_p)

            kl_p    = kl_divergence(pi[overlap], pj_tr)
            E_model_align += beta_tilde * kl_p.sum()

    # 5) Normalize
    total_support = max(sum(m.sum() for m in MASK_list), 1)
    return {
        "KL(q||p)":      E_kl / total_support,
        "KL(q||Ωq)":     E_align / total_support,
        "KL(p||Ω̃p)":    E_model_align / total_support,
        "Laplacian(φ_belief)": E_lap / total_support,
        "Laplacian(φ_model)":  E_lap_m / total_support,
        "Curvature(F²)":        E_curv / total_support,
        "Total":                (E_kl + E_align + E_model_align + E_lap + E_lap_m + E_curv) / total_support,
    }

def compute_alignment_error(
    agents,
    generators,
    q_field: str = "q",
    phi_field: str = "phi",
    mask_field: str = "mask",
    support_cutoff_eps: float = 1e-3,
    overlap_eps: float = 1e-3,
    log_eps: float = 1e-8,
) -> float:
    """
    Compute average KL divergence alignment error D_KL(q_i || Ω_{ij} q_j) over overlapping neighbors.

    Parameters:
    - agents: list of agent objects with attributes q_field, phi_field, mask_field, neighbors
    - generators: Lie algebra generators (dim_G, K, K)
    - q_field: name of belief distribution field (default 'q')
    - phi_field: name of phase field (default 'phi')
    - mask_field: name of mask field (default 'mask')
    - support_cutoff_eps: mask cutoff threshold
    - overlap_eps: threshold for mask overlap
    - log_eps: numerical epsilon for KL and normalization stability

    Returns:
    - average KL alignment error (float)
    """
    total_error = 0.0
    total_weight = 0.0

    for i, agent_i in enumerate(agents):
        # binary support mask for agent_i
        mask_i = getattr(agent_i, mask_field) > support_cutoff_eps
        q_i = sanitize_q(getattr(agent_i, q_field), eps=log_eps)
        phi_i = getattr(agent_i, phi_field)

        for nb in agent_i.neighbors:
            j = nb["id"]
            # avoid double-counting pairs
            if j <= i:
                continue

            agent_j = agents[j]
            mask_j = getattr(agent_j, mask_field) > support_cutoff_eps
            overlap = mask_i & mask_j
            if not np.any(overlap):
                continue

            # extract overlapping data
            r = phi_i - getattr(agent_j, phi_field)
            r_vecs = r[overlap]
            qj_vals = sanitize_q(getattr(agent_j, q_field)[overlap], eps=log_eps)

            # ensure batch dims
            if r_vecs.ndim == 1:
                r_vecs = r_vecs[None, :]
                qj_vals = qj_vals[None, :]

            # compute transport and rotated q
            omega_batch = exp_lie_algebra_irrep(r_vecs, generators)
            qj_rot = batch_apply_omega(qj_vals, omega_batch)
            qj_rot = sanitize_q(qj_rot, eps=log_eps)

            # KL on overlaps
            D_kl = kl_divergence(q_i[overlap], qj_rot)
            total_error += np.sum(D_kl)
            total_weight += np.sum(overlap)

    return float(total_error / (total_weight + log_eps))


def compute_phi_delta_norm(
    agents,
    params: dict | None = None,
    delta_phi_field_name: str = "delta_phi",
    mask_field: str = "mask",
) -> float:
    """
    Compute the maximum update‐step norm of delta_phi across all agents.
    Hyperparameter support_cutoff_eps is pulled from params or config.
    Returns 0.0 if no valid values are found.
    """
    src = params or {}
    dphi_name = src.get("delta_phi_field_name", delta_phi_field_name)
    mask_name = src.get("mask_field",          mask_field)
    cutoff    = src.get("support_cutoff_eps", _DEFAULT_CUTOFF)

    norms = []
    for agent in agents:
        delta = getattr(agent, dphi_name, None)
        mask  = getattr(agent, mask_name, None)
        if delta is None or mask is None:
            continue

        support = mask > cutoff
        if not support.any():
            continue

        delta_norm = np.linalg.norm(delta, axis=-1)
        norms.append(np.max(delta_norm[support]))

    return float(max(norms)) if norms else 0.0

def compute_transport_strength(
    agent_i,
    agent_j,
    generators,
    q_field="q",
    phi_field="phi",
    overlap_eps=1e-3,
    log_eps=None,
):
    """
    Compute average per-point transport error between two agents:
    ||q_j(c) - Ω_{ij}(c) q_j(c)|| averaged over their overlap.
    """
    # Determine log_eps from config if not provided
    if log_eps is None:
        import config
        log_eps = config.log_eps

    phi_i = getattr(agent_i, phi_field)
    phi_j = getattr(agent_j, phi_field)
    mask_i = getattr(agent_i, "mask")
    mask_j = getattr(agent_j, "mask")

    # boolean overlap masking
    overlap_mask = (mask_i > overlap_eps) & (mask_j > overlap_eps)
    if not np.any(overlap_mask):
        return 0.0

    # extract and sanitize data
    r_vecs = phi_i[overlap_mask] - phi_j[overlap_mask]
    qj_vals = sanitize_q(getattr(agent_j, q_field)[overlap_mask], eps=log_eps)

    # ensure batch dims
    if r_vecs.ndim == 1:
        r_vecs = r_vecs[None, :]
        qj_vals = qj_vals[None, :]

    # compute transport
    omega_batch = exp_lie_algebra_irrep(r_vecs, generators)
    qj_rot = batch_apply_omega(qj_vals, omega_batch)
    qj_rot = sanitize_q(qj_rot, eps=log_eps)

    # compute per-point diffs
    diffs = qj_vals - qj_rot
    norms = np.linalg.norm(diffs, axis=-1)
    return float(np.mean(norms))


def compute_phi_laplacian_norm_field(agents, i):
    """
    Returns pointwise Frobenius norm of the Laplacian of phi_i, masked by support.
    """
    phi = agents[i].phi  # shape (..., dim_G)
    mask = agents[i].mask > 0
    # compute componentwise Laplacian
    lap_phi = np.stack([laplace(phi[..., d]) for d in range(phi.shape[-1])], axis=-1)
    # Frobenius norm over Lie-algebra components
    norm = np.linalg.norm(lap_phi, axis=-1)
    return norm * mask


def compute_network_transport_strength(
    agents,
    generators,
    q_field="q",
    phi_field="phi",
    overlap_eps=1e-3,
    log_eps=None,
):
    """
    Average transport strength over all unordered agent pairs.
    """
    total = 0.0
    count = 0
    for i, agent_i in enumerate(agents):
        for nb in agent_i.neighbors:
            j = nb["id"]
            # avoid double-counting
            if j <= i:
                continue
            ts = compute_transport_strength(
                agent_i, agent_j=agents[j], generators=generators,
                q_field=q_field, phi_field=phi_field,
                overlap_eps=overlap_eps, log_eps=log_eps
            )
            total += ts
            count += 1
    return float(total / (count + 1e-8))

def compute_average_entropy(
    agents,
    q_field="q",
    mask_field="mask",
    support_cutoff_eps=1e-3,
    log_eps=1e-8,
):
    entropies = []
    for agent in agents:
        q    = sanitize_q(getattr(agent, q_field), eps=log_eps)
        mask = getattr(agent, mask_field) > support_cutoff_eps

        # pointwise entropy
        ent  = -np.sum(q * np.log(q), axis=-1)

        # mean over support
        n = mask.sum()
        if n > 0:
            entropies.append(ent[mask].sum() / n)

    return float(np.mean(entropies)) if entropies else 0.0

def compute_phi_norm(
    agents,
    phi_field="phi",
    mask_field="mask",
    support_cutoff_eps=1e-3,
):
    norms = []
    for agent in agents:
        phi  = getattr(agent, phi_field)
        mask = getattr(agent, mask_field) > support_cutoff_eps
        n    = mask.sum()
        if n > 0:
            norms.append(masked_norm(phi, mask) / n)
    return float(np.mean(norms)) if norms else 0.0


def compute_entropy_field(agents, i, q_field="q", mask_field="mask", support_cutoff_eps=1e-3, log_eps=1e-8):
    q     = sanitize_q(getattr(agents[i], q_field), eps=log_eps)
    mask  = getattr(agents[i], mask_field) > support_cutoff_eps
    ent   = -np.sum(q * np.log(q), axis=-1)
    return ent * mask

def compute_phi_model_alignment_field(agents, i):
    from generalized_math_utils import sanitize_q
    from generalized_update_rules import kl_divergence

    q        = sanitize_q(agents[i].q)
    p_model  = sanitize_q(agents[i].p)
    mask     = agents[i].mask > config.support_cutoff_eps
    kl       = kl_divergence(q, p_model)      # shape (...,)
    return kl * mask                          # zeroed outside support

def compute_alignment_field(agents, i, generators, eps=config.support_cutoff_eps):
    import numpy as np
    from generalized_math_utils   import sanitize_q
    from generalized_update_rules import kl_divergence
    from generalized_omega         import exp_lie_algebra_irrep, batch_apply_omega

    A = agents[i]
    mask_i = A.mask > eps
    if not A.neighbors:
        return np.zeros_like(mask_i, float)

    # pre-sanitize q_i once
    q_i_full = sanitize_q(A.q)

    kl_accum = np.zeros_like(mask_i, float)
    for nb in A.neighbors:
        j = nb["id"]
        B = agents[j]
        # overlap mask
        overlap = mask_i & (B.mask > eps)
        if not overlap.any():
            continue

        # only on overlap pixels:
        q_i_pts   = q_i_full[overlap]     # (n_pts, K)
        phi_i_pts = A.phi[overlap]        # (n_pts, d)
        q_j_pts   = sanitize_q(B.q)[overlap]
        phi_j_pts = B.phi[overlap]

        # batch exponentiate & transport
        delta    = phi_i_pts - phi_j_pts                         # (n_pts, d)
        Omega    = exp_lie_algebra_irrep(delta, generators)     # (n_pts, K, K)
        qj_trans = batch_apply_omega(q_j_pts, Omega)            # (n_pts, K)

        # accumulate KL on just these pixels
        kl_vals  = kl_divergence(q_i_pts, qj_trans)             # (n_pts,)
        kl_accum[overlap] += kl_vals

    # average by number of neighbors at each pixel
    n_nb_at = sum((mask_i & (agents[nb["id"]].mask > eps)).astype(int)
                  for nb in A.neighbors)
    # avoid divide-by-zero
    denom = np.where(n_nb_at>0, n_nb_at, 1)
    return (kl_accum / denom) * mask_i

# In generalized_diagnostics_metrics.py (somewhere near the top)

def compute_model_alignment_field(
    agents,
    i,
    generators,
    eps=config.support_cutoff_eps
) -> np.ndarray:
    """
    Exactly like compute_alignment_field, but uses each agent's p & phi_model.
    Returns the per‐pixel model‐alignment field for agent i.
    """
    # Temporarily swap q→p and phi→phi_model on agent i
    A = agents[i]
    q_orig, phi_orig = A.q, A.phi
    A.q, A.phi = A.p, A.phi_model
    try:
        field = compute_alignment_field(agents, i, generators, eps)
    finally:
        A.q, A.phi = q_orig, phi_orig
    return field


def compute_curvature_field(
    agents,
    i,
    phi_field: str = "phi",
    mask_field: str = "mask",
    generators=None,
    support_cutoff_eps: float | None = None,
) -> np.ndarray:
    """
    Compute pointwise mean curvature F(x) = average over |F_{μν}(x)|,
    masked by support.

    Returns array of shape same as agent mask.
    """
    if generators is None:
        raise ValueError("`generators` must be provided to compute curvature field.")
    # determine support cutoff
    if support_cutoff_eps is None:
        support_cutoff_eps = _DEFAULT_CUTOFF

    agent = agents[i]
    phi   = getattr(agent, phi_field)
    mask  = getattr(agent, mask_field)
    support = mask > support_cutoff_eps

    # compute dict of Frobenius norms F_{μν}(x)
    F_dict = compute_field_strength(phi, generators)
    if not F_dict:
        return np.zeros_like(mask, dtype=float)

    # stack norms and average over pairs
    F_stack = np.stack(list(F_dict.values()), axis=-1)  # shape (..., n_pairs)
    mean_F  = np.mean(F_stack, axis=-1)                 # shape (...)

    return mean_F * support.astype(float)


def compute_curvature_norm(
    agents,
    phi_field: str = "phi",
    mask_field: str = "mask",
    generators=None,
    support_cutoff_eps: float | None = None,
    log_eps: float = 1e-8,
) -> float:
    """
    Compute the agent-averaged mean curvature norm:
      1) For each agent, compute pointwise mean_F(x) and mask by support
      2) Spatially average mean_F over support
      3) Finally, average over agents
    """
    if generators is None:
        raise ValueError("`generators` must be provided to compute curvature norm.")
    if support_cutoff_eps is None:
        support_cutoff_eps = _DEFAULT_CUTOFF

    norms = []
    for agent in agents:
        phi  = getattr(agent, phi_field)
        mask = getattr(agent, mask_field)
        support = mask > support_cutoff_eps
        if not support.any():
            continue

        F_dict = compute_field_strength(phi, generators)
        if not F_dict:
            continue

        F_stack = np.stack(list(F_dict.values()), axis=-1)
        mean_F   = np.mean(F_stack, axis=-1)

        # spatial average over support
        spatial_avg = np.sum(mean_F[support]) / (np.count_nonzero(support) + log_eps)
        norms.append(spatial_avg)

    return float(np.mean(norms)) if norms else 0.0


def compute_phi_laplacian_norm(
    agents,
    phi_field: str = "phi",
    mask_field: str = "mask",
    support_cutoff_eps: float | None = None,
    log_eps: float = 1e-8,
) -> float:
    """
    Compute the average per-agent RMS norm of the Laplacian of the φ field.
    1) Threshold mask by support_cutoff_eps.
    2) Compute componentwise Laplacian via scipy.ndimage.laplace.
    3) Compute masked_norm over support and normalize by support size.
    4) Return the mean over all agents.
    """
    if support_cutoff_eps is None:
        support_cutoff_eps = _DEFAULT_CUTOFF

    norms = []
    for agent in agents:
        phi = getattr(agent, phi_field)
        mask = getattr(agent, mask_field) > support_cutoff_eps
        if not np.any(mask):
            continue

        # componentwise Laplacian
        lap_phi = np.stack([laplace(phi[..., d]) for d in range(phi.shape[-1])], axis=-1)
        # RMS norm over support
        val = masked_norm(lap_phi, mask) / (np.count_nonzero(mask) + log_eps)
        norms.append(val)

    return float(np.mean(norms)) if norms else 0.0


def compute_model_alignment_kl(
    agents,
    generators,
    p_field: str = "p",
    phi_field: str = "phi_model",
    mask_field: str = "mask",
    overlap_eps: float | None = None,
    clip_val: float = 10.0,
    log_eps: float = 1e-8,
) -> float:
    """
    Compute average KL divergence D_KL(p_i || Ω_ij p_j) over unique overlapping agent pairs.
    1) Sanitize p vectors with sanitize_q.
    2) Threshold support by overlap_eps.
    3) Clip phase differences.
    4) Batch exponentiate and transport.
    5) Repair forgotten components.
    6) Compute KL and normalize by total overlap count.
    """
    if overlap_eps is None:
        overlap_eps = _DEFAULT_CUTOFF

    kl_total = 0.0
    count = 0

    for i, agent_i in enumerate(agents):
        p_i = sanitize_q(getattr(agent_i, p_field), eps=log_eps)
        phi_i = getattr(agent_i, phi_field)
        mask_i = getattr(agent_i, mask_field) > overlap_eps

        for nb in agent_i.neighbors:
            j = nb["id"]
            if j <= i:
                continue

            agent_j = agents[j]
            mask_j = getattr(agent_j, mask_field) > overlap_eps
            overlap = mask_i & mask_j
            if not np.any(overlap):
                continue

            # sanitize distributions
            pj = sanitize_q(getattr(agent_j, p_field)[overlap], eps=log_eps)
            pi = sanitize_q(p_i[overlap], eps=log_eps)
            # clipped phase differences
            r = np.clip(phi_i[overlap] - getattr(agent_j, phi_field)[overlap], -clip_val, clip_val)
            if r.ndim == 1:
                r = r[None, :]

            # transport
            omega = exp_lie_algebra_irrep(r, generators)
            pj_rot = batch_apply_omega(pj, omega)
            pj_rot = repair_if_forgotten_batch(pj_rot, eps=log_eps)
            pj_rot = np.clip(pj_rot, log_eps, 1.0)

            # KL divergence
            kl_vals = np.sum(pi * (np.log(pi) - np.log(pj_rot)), axis=-1)
            kl_total += np.sum(kl_vals)
            count += np.count_nonzero(overlap)

    return float(kl_total / (count + log_eps)) if count > 0 else 0.0



def compute_fisher_information_norm(
    agents,
    q_field: str = "q",
    mask_field: str = "mask",
    support_cutoff_eps: float | None = None,
    log_eps: float = 1e-8,
) -> float:
    """
    Compute the mean Fisher information norm across all agents:
      I = ∫ (∑_μ ||∇_μ q||^2 / q) over support
    Returns the average over agents of (spatially averaged I).
    """
    if support_cutoff_eps is None:
        support_cutoff_eps = _DEFAULT_CUTOFF

    norms = []
    for agent in agents:
        q      = sanitize_q(getattr(agent, q_field), eps=log_eps)  # (..., K)
        mask   = getattr(agent, mask_field) > support_cutoff_eps    # boolean mask
        if not mask.any():
            continue

        # compute spatial gradient list over spatial axes
        D       = q.ndim - 1
        grads   = np.gradient(q, axis=tuple(range(D)))            # list of (..., K)

        # Fisher integrand: sum over μ of (||∇_μ q||^2 / q)
        fisher = np.zeros_like(mask, dtype=float)
        for g in grads:
            # g has shape (..., K)
            fisher += np.sum((g**2) / (q + log_eps), axis=-1)

        # spatial average over support
        val = np.sum(fisher[mask]) / (np.count_nonzero(mask) + log_eps)
        norms.append(val)

    return float(np.mean(norms)) if norms else 0.0


def compute_cross_model_kl(
    agents,
    generators,
    q_field: str = "q",
    p_field: str = "p",
    phi_field: str = "phi",
    phi_model_field: str = "phi_model",
    mask_field: str = "mask",
    overlap_eps: float | None = None,
    log_eps: float = 1e-8,
    clip_val: float = 10.0,
) -> float:
    """
    Compute average D_KL(q_i || Ω̃_{ij} p_j) over unique overlapping agent pairs.
    Omega tilde is built from belief-phase phi_i and model-phase phi_model_j.
    """
    if overlap_eps is None:
        overlap_eps = _DEFAULT_CUTOFF

    total_kl = 0.0
    count    = 0

    for i, agent_i in enumerate(agents):
        q_i      = sanitize_q(getattr(agent_i, q_field),        eps=log_eps)
        phi_i    = getattr(agent_i, phi_field)
        mask_i   = getattr(agent_i, mask_field) > overlap_eps

        for nb in agent_i.neighbors:
            j = nb["id"]
            if j <= i:
                continue

            agent_j = agents[j]
            p_j     = sanitize_q(getattr(agent_j, p_field),        eps=log_eps)
            phi_m_j = getattr(agent_j, phi_model_field)
            mask_j  = getattr(agent_j, mask_field) > overlap_eps

            overlap = mask_i & mask_j
            if not overlap.any():
                continue

            # extract overlap slices
            q_overlap   = q_i[overlap]
            p_j_overlap = p_j[overlap]
            # compute phase diff and clip
            r = phi_i[overlap] - phi_m_j[overlap]
            r = np.clip(r, -clip_val, clip_val)
            if r.ndim == 1:
                r = r[None, :]

            # transport p_j into q-space
            omega      = exp_lie_algebra_irrep(r, generators)
            p_rot      = batch_apply_omega(p_j_overlap, omega)
            p_rot      = repair_if_forgotten_batch(p_rot, eps=log_eps)
            # renormalize
            p_rot      /= (np.sum(p_rot, axis=-1, keepdims=True) + log_eps)

            # KL sum
            kl_vals    = np.sum(q_overlap * (np.log(q_overlap) - np.log(p_rot + log_eps)), axis=-1)
            total_kl  += np.sum(kl_vals)
            count     += np.count_nonzero(overlap)

    return float(total_kl / (count + log_eps)) if count > 0 else 0.0




def compute_information_update_norm(
    agent,
    delta_q_field="delta_q",
    mask_field="mask",
    support_cutoff_eps: float | None = None,
    log_eps: float = 1e-8
) -> float:
    """
    Compute RMS norm of information update delta_q for a single agent over its support.

    Returns 0.0 if no support or delta_q missing.
    """
    if support_cutoff_eps is None:
        support_cutoff_eps = _DEFAULT_CUTOFF

    dq = getattr(agent, delta_q_field, None)
    mask = getattr(agent, mask_field)
    if dq is None or mask is None:
        return 0.0

    support = mask > support_cutoff_eps
    if not np.any(support):
        return 0.0

    # per-point norm of delta_q
    perpt_norm = np.linalg.norm(dq, axis=-1)
    # mean over support
    return float(np.sum(perpt_norm[support]) / (np.count_nonzero(support) + log_eps))

import numpy as np
from generalized_math_utils import sanitize_q, laplacian_field
from generalized_omega import compute_field_strength
from generalized_update_rules import kl_divergence

def compute_secondary_metrics(
    agents,
    generators,
    q_field="q",
    phi_belief_field="phi",
    phi_model_field="phi_model",
    delta_phi_field="delta_phi",
    mask_field="mask",
    support_cutoff_eps=1e-3,
    log_eps=1e-8,
):
    """
    Compute phi_norm, phi_model_norm, entropy, lap_phi_norm,
    delta_phi_norm, curvature_norm, fisher_information in ONE loop.
    """
    phi_norms        = []
    phi_model_norms  = []
    entropies        = []
    lap_phi_norms    = []
    delta_phi_norms  = []
    curvature_norms  = []
    fisher_norms     = []

    for A in agents:
        mask = getattr(A, mask_field) > support_cutoff_eps
        if not mask.any():
            continue

        # 1) sanitize belief
        q  = sanitize_q(getattr(A, q_field), eps=log_eps)        # (…,K)
        phi_b = getattr(A, phi_belief_field)                     # (… ,d)
        phi_m = getattr(A, phi_model_field)                      # (… ,d)
        # optional delta_phi
        delta_phi = getattr(A, delta_phi_field, None)            

        # agent‐level support size
        M = mask.sum()

        # φ‐norms
        phi_norms.append(np.linalg.norm(phi_b[mask], axis=-1).sum() / M)
        phi_model_norms.append(np.linalg.norm(phi_m[mask], axis=-1).sum() / M)

        # entropy: :contentReference[oaicite:0]{index=0}
        ent = -np.sum(q * np.log(q), axis=-1)
        entropies.append(ent[mask].sum() / M)

        # laplacian norm: :contentReference[oaicite:1]{index=1}
        lap_b = laplacian_field(phi_b)[mask]
        lap_phi_norms.append(np.linalg.norm(lap_b, axis=-1).sum() / M)

        # delta_phi norm (max‐step): :contentReference[oaicite:2]{index=2}
        if delta_phi is not None:
            dnorm = np.linalg.norm(delta_phi, axis=-1)
            delta_phi_norms.append(dnorm[mask].max())

        # curvature norm: :contentReference[oaicite:3]{index=3}
        Fdict = compute_field_strength(phi_m, generators)
        if Fdict:
            Fstack = np.stack(list(Fdict.values()), axis=-1)
            mean_F = np.mean(Fstack, axis=-1)
        curvature_norms.append(mean_F[mask].sum() / M)

        # Fisher information: :contentReference[oaicite:4]{index=4}
        #I = ∑_μ ||∇_μ q||² / q
        D = q.ndim - 1
        grads = np.gradient(q, axis=tuple(range(D)))
        fisher = np.zeros_like(mask, dtype=float)
        for g in grads:
            fisher += np.sum((g**2) / (q + log_eps), axis=-1)
        fisher_norms.append(fisher[mask].sum() / M)

    # average over agents
    return {
        'phi_norm':           float(np.mean(phi_norms)),
        'phi_model_norm':     float(np.mean(phi_model_norms)),
        'entropy':            float(np.mean(entropies)),
        'lap_phi_norm':       float(np.mean(lap_phi_norms)),
        'delta_phi_norm':     float(np.mean(delta_phi_norms)) if delta_phi_norms else 0.0,
        'curvature_norm':     float(np.mean(curvature_norms)) if curvature_norms else 0.0,
        'fisher_information': float(np.mean(fisher_norms)) if fisher_norms else 0.0,
    }

def log_all_metrics(
    agents,
    step: int,
    params: dict | None,
    generators,
    q_field: str = "q",
    p_field: str = "p",
    phi_belief_field: str = "phi",
    phi_model_field: str = "phi_model",
    mask_field: str = "mask",
    overlap_eps: float | None = None,
    log_eps: float = 1e-8,
) -> dict:
    """
    Cleaned diagnostics logger leveraging batched energy computation.
    """
    # Load defaults from config if params not provided
    cfg = params or {k: getattr(config, k) for k in dir(config) if not k.startswith("__")}
    if overlap_eps is None:
        overlap_eps = cfg.get('support_cutoff_eps', getattr(config, 'support_cutoff_eps', 1e-5))

    # Compute total energy dict (includes kl_self, kl_align, kl_model_align)
    energy = compute_total_energy(
        agents, generators, cfg,
        q_field=q_field,
        p_field=p_field,
        phi_belief_field=phi_belief_field,
        phi_model_field=phi_model_field
    )

    # Other diagnostics not covered by energy
    phi_norm         = compute_phi_norm(agents, phi_field=phi_belief_field, mask_field=mask_field)
    phi_model_norm   = compute_phi_norm(agents, phi_field=phi_model_field,   mask_field=mask_field)
    entropy          = compute_average_entropy(agents, q_field=q_field, mask_field=mask_field)
    lap_phi_norm     = compute_phi_laplacian_norm(agents, phi_field=phi_belief_field, mask_field=mask_field)
    delta_phi_norm   = compute_phi_delta_norm(agents, cfg, delta_phi_field_name='delta_phi', mask_field=mask_field)
    curvature_norm   = compute_curvature_norm(agents, phi_field=phi_belief_field, mask_field=mask_field, generators=generators)
    fisher_info_norm = compute_fisher_information_norm(agents, q_field=q_field, mask_field=mask_field)
    cross_model_kl   = energy.get('KL(p||Ω̃p)', 0.0)

    metrics = {
        'step': step,
        'kl_self':        energy.get('KL(q||p)', 0.0),
        'kl_align':       energy.get('KL(q||Ωq)', 0.0),
        'kl_model_align': energy.get('KL(p||Ω̃p)', 0.0),
        'phi_norm':       phi_norm,
        'phi_model_norm': phi_model_norm,
        'entropy':        entropy,
        'total_energy':   energy.get('Total', 0.0),
        'lap_phi_norm':   lap_phi_norm,
        'delta_phi_norm': delta_phi_norm,
        'curvature_norm': curvature_norm,
        'fisher_information': fisher_info_norm,
        'cross_model_kl': cross_model_kl,
    }
    return metrics
