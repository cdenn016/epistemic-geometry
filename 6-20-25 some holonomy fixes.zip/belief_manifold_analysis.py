# -*- coding: utf-8 -*-
"""
Created on Fri Jun 20 18:45:44 2025

@author: chris and christine
"""

# belief_manifold_analysis.py

import numpy as np
import config
from scipy.spatial.distance import pdist, squareform
from sklearn.manifold import MDS
import matplotlib.pyplot as plt

def extract_fibers(agent):
    """
    Returns:
      coords : ndarray (n_pts, D)   — the spatial indices c for each fiber
      q_vals : ndarray (n_pts, K)   — the belief vector at each c
    """
    # threshold support
    mask = agent.mask > getattr(config, "support_cutoff_eps", 1e-3)
    # collect fibers
    q_vals = agent.q[mask]                       # (n_pts, K)
    # record spatial coords
    # e.g. for 2D, coords[i] = (row, col) of the ith point
    coords = np.stack(np.nonzero(mask), axis=1)   # (n_pts, D)
    return coords, q_vals

def symmetrized_kl(u, v, eps=1e-12):
    """KL(u||v) + KL(v||u) / 2"""
    u = u + eps; v = v + eps
    return 0.5 * (np.sum(u * np.log(u/v)) + np.sum(v * np.log(v/u)))

def compute_distance_matrix(q_vals, metric="symkl"):
    """
    Compute an (n_pts x n_pts) distance matrix over fibers.
    metric: 'symkl' for symmetric KL, otherwise uses whatever pdist supports.
    """
    if metric == "symkl":
        D = squareform(pdist(q_vals, lambda u,v: symmetrized_kl(u,v)))
    else:
        D = squareform(pdist(q_vals, metric))
    return D

def embed_fibers(q_vals, n_components=2, metric="symkl"):
    """
    Embed the fiber-cloud into R^n_components via metric MDS.
    Returns embedding array (n_pts, n_components).
    """
    D = compute_distance_matrix(q_vals, metric)
    mds = MDS(n_components=n_components, dissimilarity="precomputed", random_state=0)
    emb = mds.fit_transform(D)
    return emb

def plot_embedding(emb, coords=None, title="Belief‐Manifold Embedding"):
    """
    Scatter the 2D embedding, optionally colored by one of the spatial coords.
    """
    fig, ax = plt.subplots(figsize=(6,6))
    if coords is not None:
        # color by x‐coordinate (for example)
        sc = ax.scatter(emb[:,0], emb[:,1], c=coords[:,0], cmap="viridis", s=20)
        plt.colorbar(sc, ax=ax, label="spatial dim 0")
    else:
        ax.scatter(emb[:,0], emb[:,1], s=20)
    ax.set_title(title)
    ax.set_xlabel("Emb. dim 1")
    ax.set_ylabel("Emb. dim 2")
    plt.tight_layout()
    return fig, ax


# — Example usage —
if __name__ == "__main__":
    import pickle
    # load a saved checkpoint to get `agents`
    import glob, os, pickle

# find all step_XXXX.pkl files in the checkpoints folder
    ckpts = sorted(glob.glob(os.path.join("checkpoints", "step_*.pkl")))
    if not ckpts:
        raise FileNotFoundError("No checkpoint files found in 'checkpoints/'")
# pick the latest one (or index into ckpts if you want an earlier step)
    latest = ckpts[-1]
    print(f"Loading checkpoint {latest}")
    with open(latest, "rb") as f:
        agents = pickle.load(f)

    A = agents[1]  # pick one agent

    coords, q_vals = extract_fibers(A)
    emb = embed_fibers(q_vals, n_components=2)
    fig, ax = plot_embedding(emb, coords)
    fig.savefig("plots/agent0_belief_manifold.png", dpi=150)
    print("Done embedding agent 0’s belief manifold.")
