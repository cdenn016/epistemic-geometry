import os
import glob
import pickle
import numpy as np
import matplotlib.pyplot as plt
import imageio

def animate_belief_seq(diagnostics_path, output_gif, fps=5, figsize=(6,4)):
    """
    Load diagnostics.pkl, extract belief_seq (list of K-vectors),
    and build a bar-chart GIF showing the distribution at each micro-step.
    """
    with open(diagnostics_path, 'rb') as f:
        diag = pickle.load(f)
    belief_seq = diag['belief_seq']
    K = belief_seq[0].shape[0]

    tmpdir = "_tmp_frames"
    os.makedirs(tmpdir, exist_ok=True)
    frames = []

    vmax = max(np.max(b) for b in belief_seq)

    for idx, b in enumerate(belief_seq):
        fig, ax = plt.subplots(figsize=figsize)
        ax.bar(np.arange(K), b)
        ax.set_ylim(0, vmax)
        ax.set_title(f"Step {idx}")
        ax.set_xlabel("Component")
        ax.set_ylabel("Belief")
        frame_path = os.path.join(tmpdir, f"frame_{idx:04d}.png")
        fig.tight_layout()
        fig.savefig(frame_path)
        plt.close(fig)
        frames.append(frame_path)

    with imageio.get_writer(output_gif, mode='I', fps=fps) as writer:
        for frame in frames:
            img = imageio.imread(frame)
            writer.append_data(img)

    for frame in frames:
        os.remove(frame)
    os.rmdir(tmpdir)
    print(f"Saved animation to {output_gif}")

def find_and_animate_all(base_dir="holonomy_runs/agent", out_dir="holonomy_animations", fps=5):
    """
    Scan each subfolder in base_dir for diagnostics.pkl and create
    a corresponding GIF in out_dir.
    """
    os.makedirs(out_dir, exist_ok=True)
    pattern = os.path.join(base_dir, "*", "diagnostics.pkl")
    for diag_path in glob.glob(pattern):
        cycle_folder = os.path.basename(os.path.dirname(diag_path))
        gif_name = f"belief_{cycle_folder}.gif"
        output_gif = os.path.join(out_dir, gif_name)
        print(f"Animating {diag_path} -> {output_gif}")
        animate_belief_seq(diag_path, output_gif, fps=fps)

if __name__ == "__main__":
    find_and_animate_all(base_dir="holonomy_runs/agent", out_dir="holonomy_animations", fps=5)
