# animate_agent_cycle_transport.py

import os
import pickle
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation, PillowWriter

from transport_operator import (
    construct_spatial_path_nd,
    compute_intra_agent_omega,
    compute_inter_agent_omega_at_point,
)
from get_generators import get_generators
from config import domain_size, group_name, K, support_cutoff_eps, checkpoint_dir

def animate_belief_transport(cycle, overlaps, agents, generators, step, save_path='agent_cycle_transport.gif'):
    D = len(domain_size)
    assert D == 2, "Only 2D spatial transport is currently supported."

    # Start from center of first agent
    A = agents[cycle[0]]
    c_0 = tuple(np.array(A.center, dtype=int))
    f = A.q[c_0].copy()
    f = np.clip(f, 1e-8, 1.0)
    f /= np.sum(f)

    frames = []
    coords = [c_0]

    for k in range(len(cycle) - 1):
        id_a = cycle[k]
        id_b = cycle[k + 1]
        a = agents[id_a]
        b = agents[id_b]

        ca = c_0 if k == 0 else overlaps[k - 1]
        cab = overlaps[k]

        # --- Intra-agent spatial transport in agent a ---
        path = construct_spatial_path_nd(ca, cab, domain_size, mask=a.mask)
        for p0, p1 in zip(path[:-1], path[1:]):
            omega = compute_intra_agent_omega(a.phi, p0, p1, generators)
            f = omega @ f
            f = np.clip(f, 1e-8, 1.0)
            f /= np.sum(f)
            frames.append((id_a, p1, f.copy()))
            coords.append(p1)

        # --- Inter-agent gauge transport ---
        omega_ab = compute_inter_agent_omega_at_point(a.phi, b.phi, cab, generators)
        f = omega_ab @ f
        f = np.clip(f, 1e-8, 1.0)
        f /= np.sum(f)
        frames.append((id_b, cab, f.copy()))
        coords.append(cab)
        c_0 = cab

    # === Animate ===
    fig, ax = plt.subplots(figsize=(6, 3))
    ax.set_ylim(0, np.max([np.max(f) for _, _, f in frames]) * 1.1)
    ax.set_xlim(0, K - 1)
    ax.set_xlabel("Fiber Index")
    ax.set_ylabel("Probability")
    line, = ax.plot([], [], lw=2, color='blue', label="Transported q")
    initial_line, = ax.plot([], [], '--', color='gray', label="Initial q")
    ax.legend()
    ax.set_title(f"Belief Transport Around Agent Cycle (Step {step})")

    def update(i):
        agent_id, pos, f_vec = frames[i]
        line.set_data(np.arange(K), f_vec)
        initial_line.set_data(np.arange(K), frames[0][2])
        ax.set_title(f"Step {i} – Agent {agent_id} at {pos}")
        return [line, initial_line]

    anim = FuncAnimation(fig, update, frames=len(frames), blit=True, interval=300)
    anim.save(save_path, writer=PillowWriter(fps=2))
    print(f"[✓] Animation saved to {save_path}")

if __name__ == '__main__':
    # === Load cycle from holonomy_experiments output ===
    step = 125
    label = "0_1_2_3_0"  # Change if needed
    diag_path = os.path.join("holonomy_runs", "agent", f"{label}_{step}", "diagnostics.pkl")
    with open(diag_path, "rb") as f:
        data = pickle.load(f)
    cycle = data["cycle"]
    overlaps = data["overlaps"]

    # === Load agent checkpoint ===
    with open(os.path.join(checkpoint_dir, f"step_{step:04d}.pkl"), "rb") as f:
        agents = pickle.load(f)

    # === Load generators ===
    generators = get_generators(group_name, K)

    # === Run animation ===
    animate_belief_transport(cycle, overlaps, agents, generators, step)
