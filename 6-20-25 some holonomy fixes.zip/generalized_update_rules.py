import numpy as np
from scipy.ndimage import laplace

from generalized_math_utils import kl_divergence, sanitize_q
from generalized_agent_schema import Agent  
import config 

# generalized_update_wrappers.py  (or wherever your updater lives)


def update_distribution_generic(
    i: int,
    agents: list,
    params: dict,
    dist_attr: str,
    eta_key: str,
    grad_fn,
    feedback_weight_key: str | None = None
) -> 'Agent':
    """
    Generic update for any probability distribution field (q or p).
    """
    # 1) Allow params to be None
    params = params or {}

    # 2) Pull defaults from params first, then fallback to config
    eta                = params.get(eta_key, getattr(config, eta_key))
    log_eps            = params.get("log_eps", config.log_eps)
    support_cutoff_eps = params.get("support_cutoff_eps", config.support_cutoff_eps)
    feedback_weight    = (
        params.get(feedback_weight_key, getattr(config, feedback_weight_key))
        if feedback_weight_key else 0.0
    )

    # ── DEBUG: dump all coupling hyperparameters ──────────────────────────────
    #if params.get("debug", False):
        #print(f"[DEBUG] HYPERPARAMS @ update_distribution_generic('{dist_attr}') agent {i}:\n"
              #f"    alpha={config.alpha:.3e}, beta={config.beta:.3e}, gamma={config.gamma:.3e},\n"
             # f"    gauge_weight={config.gauge_weight:.3e},\n"
            #  f"    model_align_weight={config.model_align_weight:.3e},\n"
            #  f"    model_gauge_weight={config.model_gauge_weight:.3e},\n"
            #  f"    model_mass_weight={config.model_mass_weight:.3e},\n"
           #   f"    model_feedback_weight={config.model_feedback_weight:.3e},\n"
          #    f"    phi_phi_tilde_coupling={config.phi_phi_tilde_coupling:.3e}")
    # ──────────────────────────────────────────────────────────────────────────
    # 4) Proceed with your existing logic
    agent_i = agents[i]
    dist     = getattr(agent_i, dist_attr)
    mask     = agent_i.mask

    grad = grad_fn(agent_i, agents, params)

    if feedback_weight_key and dist_attr == "p" and feedback_weight > 0:
        q_safe  = np.clip(agent_i.q, log_eps, 1.0)
        p_safe  = np.clip(dist,      log_eps, 1.0)
        grad_qp = np.log(p_safe / q_safe)
        grad   += feedback_weight * grad_qp

    dist_new = dist - eta * grad
    outside  = mask < support_cutoff_eps
    dist_new[outside] = dist[outside]

    try:
        dist_new = sanitize_q(dist_new, eps=log_eps)
    except Exception:
        dist_new = np.clip(dist_new, log_eps, None)
        dist_new /= dist_new.sum(axis=-1, keepdims=True) + log_eps

    setattr(agent_i, dist_attr, dist_new)
    return agent_i

def update_phi_generic(
    i: int,
    agents: list,
    params: dict,
    field_name: str,
    compute_gradient_fn,
    coupling_field_name: str | None = None,
    coupling_weight_key:   str | None = None,
    smoothing_weight_key:  str | None = None,
    mass_weight_key:       str | None = None,
    damping_weight_key:    str | None = None,
    debug_key:             str | None = None,
    eta_key:               str = "eta_phi",
    max_norm_key:          str = "phi_max_norm",
    blowup_threshold_key:  str = "blowup_threshold",
) -> 'Agent':
    
    params = params or {}

    # --- Load hyperparameters ---
    eta       = params.get(eta_key, getattr(config, eta_key))
    w_couple  = (params.get(coupling_weight_key, getattr(config, coupling_weight_key))
                 if coupling_weight_key else 0.0)
    w_smooth  = (params.get(smoothing_weight_key, getattr(config, smoothing_weight_key))
                 if smoothing_weight_key else 0.0)
    w_mass    = (params.get(mass_weight_key, getattr(config, mass_weight_key))
                 if mass_weight_key else 0.0)
    w_damp    = (params.get(damping_weight_key, getattr(config, damping_weight_key))
                 if damping_weight_key else 0.0)
    phi_max   = params.get(max_norm_key, getattr(config, max_norm_key))
    
    thresh    = params.get(blowup_threshold_key, getattr(config, blowup_threshold_key))
        
    debug     = params.get(debug_key, getattr(config, debug_key)) if debug_key else False

    clip_thresh = params.get("phi_clip_threshold", getattr(config, "phi_clip_threshold", np.inf))

    # ── DEBUG: dump all coupling hyperparameters ──────────────────────────────
    #if params.get("debug", False):
        #print(f"[DEBUG] HYPERPARAMS @ update_phi_generic('{field_name}') agent {i}:\n"
              #f"    alpha={config.alpha:.3e}, beta={config.beta:.3e}, gamma={config.gamma:.3e},\n"
             # f"    gauge_weight={config.gauge_weight:.3e},\n"
             # f"    model_align_weight={config.model_align_weight:.3e},\n"
             # f"    model_gauge_weight={config.model_gauge_weight:.3e},\n"
             # f"    model_mass_weight={config.model_mass_weight:.3e},\n"
             # f"    model_feedback_weight={config.model_feedback_weight:.3e},\n"
             # f"    phi_phi_tilde_coupling={config.phi_phi_tilde_coupling:.3e},\n"              f"    eta={eta:.3e}, w_couple={w_couple:.3e}, w_smooth={w_smooth:.3e},\n"
             # f"    w_mass={w_mass:.3e}, w_damp={w_damp:.3e}, phi_max={phi_max:.3e}, thresh={thresh:.3e}")

    agent_i = agents[i]
    phi     = getattr(agent_i, field_name)
    mask    = agent_i.mask

    # --- Compute gradient ---
    delta_phi = compute_gradient_fn(agent_i, agents, params)

    # --- Add coupling ---
    if w_couple > 0 and coupling_field_name and hasattr(agent_i, coupling_field_name):
        other = getattr(agent_i, coupling_field_name)
        term = w_couple * (phi - other) * mask[...,None]
        delta_phi -= term
        #if params.get("debug", False):
            #print(f"[TRACE] φ↔φ̃ coupling term max magnitude = {np.max(np.abs(term)):.3e}")

    # --- Add Laplacian smoothing ---
    if w_smooth > 0:
        lap = np.stack([laplace(phi[..., d]) for d in range(phi.shape[-1])], axis=-1)
        term = w_smooth * lap * mask[...,None]
        delta_phi -= term
        #if params.get("debug", False):
            #print(f"[TRACE] smoothing (γ·Δφ) term max magnitude = {np.max(np.abs(term)):.3e}")

    # --- Mass + damping ---
    if w_mass > 0:
        term = w_mass * phi * mask[...,None]
        delta_phi -= term
        #if params.get("debug", False):
            #print(f"[TRACE] mass (w_mass·φ) term max magnitude = {np.max(np.abs(term)):.3e}")
    
    if w_damp > 0:
        term = w_damp * phi * mask[...,None]
        delta_phi -= term
        #if params.get("debug", False):
            #print(f"[TRACE] damping (w_damp·φ) term max magnitude = {np.max(np.abs(term)):.3e}")

    # --- Norm-based control ---
    delta_norm = np.linalg.norm(delta_phi, axis=-1, keepdims=True)

    # Skip updates with dangerously large gradient
    skip_mask = (delta_norm > thresh)
    if np.any(skip_mask):
        delta_phi = np.where(skip_mask, 0.0, delta_phi)

    # Scale down large steps
    scale_mask = (delta_norm > clip_thresh)
    scale_factor = np.minimum(1.0, clip_thresh / (delta_norm + config.eps))
    delta_phi = np.where(scale_mask, delta_phi * scale_factor, delta_phi)

    # --- Debug logging ---
    if debug:
        clipped = int(scale_mask.sum())
        skipped = int(skip_mask.sum())
        total   = int(np.prod(delta_norm.shape[:-1]))
        max_delta = float(np.max(delta_norm))

        #print(f"[phi DIAG] {field_name} agent {i}: {clipped}/{total} clipped, {skipped} skipped")
        #if max_delta > thresh:
            #print(f"[WARNING] {field_name} update unstable at agent {i}: max_delta={max_delta:.2e}")
        #elif clipped > 0:
            #print(f"[INFO] {field_name} agent {i}: max_delta={max_delta:.2e} (clipped)")
        #else:
            #print(f"[DEBUG] {field_name} agent {i}: max_delta={max_delta:.2e}")

    # --- Safety: remove NaNs or infs ---
    delta_phi = np.nan_to_num(delta_phi, nan=0.0, posinf=0.0, neginf=0.0)

    # --- Euler update ---
    phi_new = phi + eta * delta_phi

    # --- Clip norm ---
    norm = np.linalg.norm(phi_new, axis=-1, keepdims=True)
    mask_clip = norm > phi_max
    phi_new = np.where(mask_clip, phi_new * (phi_max / (norm + config.eps)), phi_new)

    # --- Store back ---
    setattr(agent_i, field_name, phi_new)
    setattr(agent_i, f"delta_{field_name}", delta_phi)
    return agent_i
