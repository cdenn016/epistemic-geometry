#!/usr/bin/env python3
"""
holonomy_experiments.py

Run holonomy analyses across multiple configurations:
 1. Spatial loops of varying sizes.
 2. Agent-cycle loops sampled randomly from discovered cycles.

For each experiment, computes both simple curvature proxy ||H - I|| and true curvature via ||logm(H)||.
Aggregates results into a master CSV and produces summary plots.
"""
import os
import re
import pickle
import random
import logging
import numpy as np
import pandas as pd
from numpy.linalg import norm
from scipy.linalg import logm
import matplotlib.pyplot as plt

from get_generators import get_generators
from holonomy_module import (
    compute_spatial_loop_holonomy,
    compute_agent_cycle_holonomy,
    sample_self_avoiding_loop_within_mask
)
from find_agent_chains import (
    get_overlap_centroid,
    get_agent_cycles
)
from config import (
    checkpoint_dir,
    domain_size,
    support_cutoff_eps,
    group_name,
    K,
    agent_seed
)

from functools import partial


from config import domain_size, support_cutoff_eps, agent_seed, group_name, K
# ----------------------------
# Experiment parameters
# ----------------------------
max_agent_cycles = 2          # None = all cycles
spatial_sizes = [4, 6]


# ----------------------------
# Logging setup
# ----------------------------
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s %(levelname)s %(message)s'
)


def parse_step(filename):
    """
    Extract integer step from filenames like 'step_0001.pkl'.
    """
    match = re.match(r'step_(\d+)\.pkl$', filename)
    if not match:
        raise ValueError(f"Filename '{filename}' does not match expected pattern")
    return int(match.group(1))


def load_all_checkpoints():
    """
    Load and cache all checkpoint files from checkpoint_dir.
    Returns a dict mapping step -> unpickled data.
    """
    files = [f for f in os.listdir(checkpoint_dir)
             if f.startswith('step_') and f.endswith('.pkl')]
    if not files:
        raise RuntimeError(f"No checkpoint files found in {checkpoint_dir}")

    # sort by parsed step number
    files_sorted = sorted(files, key=lambda f: parse_step(f))
    cache = {}
    for fname in files_sorted:
        step = parse_step(fname)
        path = os.path.join(checkpoint_dir, fname)
        with open(path, 'rb') as f:
            cache[step] = pickle.load(f)
        logging.info(f"Loaded checkpoint step={step}")
    return cache




from scipy.linalg import logm, norm

from config import domain_size, support_cutoff_eps, agent_seed, group_name, K

from find_agent_chains import get_agent_cycles, get_overlap_centroid
from get_generators import get_generators


def run_spatial_experiments(data_cache, steps, sizes, generators):
    records = []
    for step in steps:
        # load agents for this step
        agents = data_cache[step][0] if isinstance(data_cache[step], tuple) else data_cache[step]
        agent = agents[0]
        center = tuple(agent.center)
        mask = agent.mask

        # compute effective radius from mask support
        coords_valid = np.argwhere(mask >= support_cutoff_eps)
        # distances to center
        dists = np.linalg.norm(coords_valid - np.array(center), axis=1)
        r_eff = dists.max() if dists.size > 0 else 0

        # estimate circumference and set loop-length bounds
        circ = 2 * np.pi * r_eff
        min_L = max(4, int(circ * 0.5))
        max_L = max(min_L, int(circ * 1.2))

        # sample a random self-avoiding closed loop within mask
        coords_loop = sample_self_avoiding_loop_within_mask(
            center,
            mask,
            min_length=min_L,
            max_length=max_L,
            seed=agent_seed + step
        )

        # initial belief at the loop start
        b0 = agent.q[center].copy()

        # compute holonomy + get deviations + belief trajectory
        H, deviations, belief_seq = compute_spatial_loop_holonomy(
            agent,
            coords_loop,
            generators,
            return_deviations=True,
            return_beliefs=True,
            initial_belief=b0
        )

        # save path diagnostics for visualization
        diag = {
            'path_coords': coords_loop,
            'step':        step,
            'param':       f"[{min_L}-{max_L}]",
            'holonomy':    H,
            'deviations':  deviations,    # ∥ω - I∥ at each step
            'belief_seq':  belief_seq,    # belief vector at each micro-step
        }
        outdir = os.path.join('holonomy_runs', 'spatial', f"{min_L}-{max_L}_{step}")
        os.makedirs(outdir, exist_ok=True)
        with open(os.path.join(outdir, 'diagnostics.pkl'), 'wb') as f:
            pickle.dump(diag, f)

        # compute metrics
        I = np.eye(H.shape[0])
        c_norm = norm(H - I)
        mu = np.trace(H) / 2.0
        if abs(mu) < 1.0:
            curve_type = 'elliptic'
            curve_val  = np.arccos(mu)
        elif abs(mu) > 1.0:
            curve_type = 'hyperbolic'
            curve_val  = np.arccosh(abs(mu))
        else:
            curve_type = 'parabolic'
            curve_val  = 0.0

        records.append({
            'experiment':     'spatial',
            'param':          f"[{min_L}-{max_L}]",
            'step':           step,
            'curvature_norm': c_norm,
            'curve_type':     curve_type,
            'curve_value':    curve_val,
            'det_minus1':     np.linalg.det(H) - 1,
            'trace':          np.trace(H),
            'cond':           np.linalg.cond(H),
            'loop_length':    len(coords_loop) - 1,
            'max_deviation':  np.max(deviations),
            'mean_deviation': np.mean(deviations),
            'min_deviation':  np.min(deviations),
        })

    return records


import time
def run_agent_cycle_experiments(data_cache, steps, agents_at_first_step, cycles, generators):
    records = []
    count = 0  # For counting total calls

    # Precompute all overlap centroids for each cycle
    all_overlaps = {
        tuple(cycle): [
            get_overlap_centroid(
                agents_at_first_step[i],
                agents_at_first_step[j],
                domain_size,
                support_cutoff_eps
            ) or (np.nan,)
            for i, j in zip(cycle[:-1], cycle[1:])
        ]
        for cycle in cycles
    }

    for cycle in cycles:
        label = '_'.join(map(str, cycle))
        overlaps = all_overlaps[tuple(cycle)]

        for step in steps:
            agents = data_cache[step][0] if isinstance(data_cache[step], tuple) else data_cache[step]

            # ⏱️ Time compute_agent_cycle_holonomy + capture belief trajectory
            start = time.time()
            # Initial belief at the starting agent's center
            start_agent = cycle[0]
            start_pos   = tuple(agents[start_agent].center)
            b0 = agents[start_agent].q[start_pos]

            H, deviations, F, belief_seq = compute_agent_cycle_holonomy(
                agents,
                cycle,
                overlaps,
                generators,
                initial_belief=b0,
                return_deviations=True,
                return_logm=True,
                return_beliefs=True,
            )
            elapsed = time.time() - start
            print(f"[TIMER] Step={step} Cycle={label} → compute_agent_cycle_holonomy took {elapsed:.4f} sec")
            count += 1

            # === Diagnostics ===
            c_norm = norm(H - np.eye(H.shape[0]))
            c_logm = norm(F)

            records.append({
                'experiment':     'agent_cycle',
                'param':          label,
                'step':           step,
                'curvature_norm': c_norm,
                'det_minus1':     np.linalg.det(H) - 1,
                'trace':          np.trace(H),
                'cond':           np.linalg.cond(H),
                'chordal':        c_norm,
                'loop_length':    len(cycle),
            })

            # === Save diagnostics for this cycle+step ===
            diag = {
                'cycle':        cycle,
                'overlaps':     overlaps,
                'step':         step,
                'holonomy':     H,
                'logH':         F,
                'deviations':   deviations,
                'belief_seq':   belief_seq,
                'label':        label,
            }

            outdir = os.path.join('holonomy_runs', 'agent', f"{label}_{step}")
            os.makedirs(outdir, exist_ok=True)
            with open(os.path.join(outdir, 'diagnostics.pkl'), 'wb') as f:
                pickle.dump(diag, f)

    print(f"[DEBUG] compute_agent_cycle_holonomy was called {count} times.")
    return records


def main(max_agent_cycles=None, spatial_sizes=None):
    # Load data
    data_cache = load_all_checkpoints()
    steps = sorted(data_cache.keys())

    # Spatial sizes default
    if spatial_sizes is None:
        spatial_sizes = [4, 6]

    # Find agent cycles
    first_agents = data_cache[steps[0]][0] if isinstance(data_cache[steps[0]], tuple) else data_cache[steps[0]]
    all_cycles = get_agent_cycles(first_agents, max_length=5)
    if not all_cycles:
        logging.warning("No agent cycles found; skipping agent_cycle experiments.")
    random.seed(42)
    cycles = random.sample(all_cycles, min(len(all_cycles), max_agent_cycles or len(all_cycles)))

    # Prepare
    generators = get_generators(group_name, K)
    records = []

    # Run experiments
    records += run_spatial_experiments(data_cache, steps, spatial_sizes, generators)
    if all_cycles:
        records += run_agent_cycle_experiments(data_cache, steps, first_agents, cycles, generators)

    # Save and summarize
    df = pd.DataFrame(records)
    os.makedirs('holonomy_experiments', exist_ok=True)
    master_csv = os.path.join('holonomy_experiments', 'master_summary.csv')
    df.to_csv(master_csv, index=False)
    logging.info(f"Master summary written to {master_csv}")

    # Plotting
    for metric in ['curvature_norm']:
        plt.figure(figsize=(10, 6))
        for exp in df['experiment'].unique():
            sub = df[df['experiment'] == exp]
            mean_vals = sub.groupby('param')[metric].mean()
            plt.plot(mean_vals.index, mean_vals.values, marker='o', label=exp)
        plt.xlabel('Parameter')
        plt.ylabel(metric)
        plt.title(f'Average {metric} vs. Parameter')
        plt.xticks(rotation=45, ha='right')
        plt.legend()
        plt.tight_layout()
        plt.savefig(os.path.join('holonomy_experiments', f'{metric}_vs_param.png'))
        plt.close()
    logging.info("Plots saved.")

#BE SURE TO SET THE PROPER VALUES IN MAIN!!!

if __name__ == '__main__':
    main(max_agent_cycles = 5, spatial_sizes = [4, 6, 8, 10, 12])
