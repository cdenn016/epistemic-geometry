from dataclasses import dataclass, field
from typing import Tuple, List, Optional, Dict, Any
import numpy as np

@dataclass
class Agent:
    id: int
    mask: np.ndarray
    q: np.ndarray
    p: np.ndarray
    phi: np.ndarray
    phi_model: np.ndarray
    center: Tuple[int, ...]   # arbitrary-length tuple of ints for D-dimensional center
    radius: float
    mu_q_field: np.ndarray
    sigma_q_field: np.ndarray
    mu_p_field: np.ndarray
    sigma_p_field: np.ndarray
    neighbors: List[dict]
    delta_phi_model: Optional[np.ndarray] = None  # Optional update delta for phi_model

    # New fields for future meta-agent or multi-scale studies:
    agent_scale: float = 1.0  # Effective scale of the agent (spatial or epistemic)
    hierarchy_level: int = 0  # 0 for base agents, higher for meta-agents

    # Cached summary statistics (optional; can be updated per step)
    entropy: Optional[float] = None
    energy: Optional[float] = None
    coherence: Optional[float] = None

    # Last update step index (for async or event-driven updates)
    last_update_step: Optional[int] = None

    # Per-agent metrics log: stores diagnostics per step
    metrics_log: List[Dict[str, Any]] = field(default_factory=list)

    def log_metrics(self, step: int, stats: Dict[str, Any]) -> None:
        """
        Record a dictionary of diagnostic statistics for this agent at a given step.
        The stats dict can contain keys like 'kl_self', 'phi_norm', etc.
        """
        entry = {'step': step}
        entry.update(stats)
        self.metrics_log.append(entry)
