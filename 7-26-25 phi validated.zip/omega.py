# -*- coding: utf-8 -*-
"""
Created on Wed Jul 23 18:00:25 2025

@author: chris and christine
"""

import numpy as np
import config
from scipy.linalg import expm
from joblib import Parallel, delayed, parallel_backend
from scipy.ndimage import gaussian_filter
from numerical_utils import sanitize_sigma
from numerical_utils import safe_omega_inv


from scipy.linalg import logm, expm

import numpy as np
from scipy.linalg import expm, logm
import warnings


def compute_exp_field(phi_field, generators, scale, group_name=None, debug=False, max_norm=None):
    """
    Compute exp(phi) for a field (H, W, d) given Lie algebra generators.

    Args:
        phi_field: (..., d)
        generators: (d, K, K)
        scale: scalar rescaling factor
        max_norm: float or None — if set, clip L2 norm of phi vectors before exp

    Returns:
        exp(phi): (..., K, K)
    """
    H, W, d = phi_field.shape
    K = generators.shape[1]
    flat_phi = phi_field.reshape(-1, d)

    # --- Optional clipping ---
    if max_norm is not None:
        norms = np.linalg.norm(flat_phi, axis=1, keepdims=True)
        scale_factors = np.minimum(1.0, max_norm / (norms + 1e-8))
        flat_phi = flat_phi * scale_factors

    flat_phi /= scale

    exp_batch = exp_lie_algebra_irrep(
        flat_phi,
        generators,
        group_name=group_name,
        debug=debug
    )

    return exp_batch.reshape(H, W, K, K)


import numpy as np
from scipy.linalg import expm
from joblib import Parallel, delayed


def get_exp_phi(phi_field, generators, group_name=None, n_jobs=-1):
    """
    Compute exp(φ) = exp(∑ φ^a G_a) for a batch of Lie algebra coefficients.

    Args:
        phi_field : (..., d) Lie algebra coefficients
        generators: (d, K, K) Lie algebra generators
        group_name: Optional string for group structure ("so3", "su2", etc.)
        n_jobs    : Parallel jobs (default = all cores)

    Returns:
        exp_phi : (..., K, K) matrix exponentials
    """
    *batch_shape, d = phi_field.shape
    K = generators.shape[-1]
    phi_flat = phi_field.reshape(-1, d)  # (N, d)
    N = phi_flat.shape[0]

    def single_expm(phi_vec):
        G = sum(phi_vec[a] * generators[a] for a in range(d))  # (K, K)
        return adaptive_expm(G, group_name=group_name)

    exp_list = Parallel(n_jobs=n_jobs)(
        delayed(single_expm)(phi_flat[i]) for i in range(N)
    )

    return np.stack(exp_list, axis=0).reshape(*batch_shape, K, K)


def adaptive_expm(G, clip_norm=None, max_norm=None, threshold=1e-3, group_name=None):
    """
    Rescales G to prevent instability, then exponentiates:
      - 4th-order Taylor for small ‖G‖
      - expm(G) otherwise

    Parameters:
        G: (K, K) Lie algebra matrix
        clip_norm: soft cap (rescales only if ‖G‖ > clip_norm)
        max_norm: hard cap (always rescales if ‖G‖ > max_norm)
        threshold: use Taylor below this norm
        group_name: optional group structure (e.g. "so3", "su2")

    Returns:
        exp(G): (K, K) matrix
    """
    norm_G = np.linalg.norm(G) + 1e-16

    if clip_norm and norm_G > clip_norm:
        G *= clip_norm / norm_G
    if max_norm and norm_G > max_norm:
        G *= max_norm / norm_G

    # Optional antisymmetrization
    if group_name == "so3":
        G = 0.5 * (G - G.T)
    elif group_name == "su2":
        G = 0.5 * (G - G.T.conj())

    if norm_G < threshold:
        I = np.eye(G.shape[0], dtype=G.dtype)
        G2 = G @ G
        G3 = G2 @ G
        G4 = G3 @ G
        return I + G + 0.5 * G2 + (1/6) * G3 + (1/24) * G4
    else:
        return expm(G)

def exp_lie_algebra_irrep(
    v_batch,
    generators,
    use_expm=True,
    threshold=1e-3,
    max_norm=10.0,
    group_name=None,
    n_jobs=-1,
    debug=True
):
    """
    Compute batched exp(∑ₐ vₐ Tₐ) using Taylor or matrix exp depending on ‖v‖.

    Parameters:
        v_batch: (..., d) Lie algebra coefficients
        generators: (d, K, K) Lie algebra basis
        use_expm: whether to fall back to expm for large-norm inputs
        threshold: Taylor cutoff norm
        max_norm: max norm allowed before rescaling
        group_name: "so3", "su2", etc. for antisymmetrization
        n_jobs: parallelism
        debug: enable debug printouts

    Returns:
        (..., K, K) batch of exponentials
    """
    *batch_shape, d = v_batch.shape
    v_flat = v_batch.reshape(-1, d)
    N = v_flat.shape[0]
    _, K, _ = generators.shape
    dtype = v_batch.dtype

    # Compute norms and scale safely
    norms = np.linalg.norm(v_flat, axis=1) + 1e-16
    scale = np.minimum(1.0, max_norm / norms)
    v_scaled = v_flat * scale[:, None]

    if debug and np.any(scale < 1.0):
        print(f"[Ω] Clipped {np.sum(scale < 1)} / {N} vectors to ‖φ‖ ≤ {max_norm:.2f}")

    # Construct Lie algebra elements
    G_batch = np.einsum("nd,dij->nij", v_scaled, generators)

    # Antisymmetrize if needed
    if group_name == "so3":
        G_batch = 0.5 * (G_batch - G_batch.transpose(0, 2, 1))
    elif group_name == "su2":
        G_batch = 0.5 * (G_batch - G_batch.transpose(0, 2, 1).conj())

    result = np.empty((N, K, K), dtype=dtype)

    # Apply 4th-order Taylor for small matrices
    approx_mask = (norms * scale) < threshold
    if np.any(approx_mask):
        G_approx = G_batch[approx_mask]
        I = np.eye(K, dtype=dtype)[None, :, :]
        G2 = G_approx @ G_approx
        G3 = G2 @ G_approx
        G4 = G2 @ G2
        result[approx_mask] = (
            I + G_approx + 0.5 * G2 + (1/6) * G3 + (1/24) * G4
        )

    # Apply full expm (threaded) for large matrices
    if np.any(~approx_mask):
        indices = np.flatnonzero(~approx_mask)
        G_heavy = [G_batch[i] for i in indices]

        with parallel_backend("threading"):
            expm_results = Parallel(n_jobs=n_jobs)(
                delayed(adaptive_expm)(
                    G,
                    clip_norm=None,
                    max_norm=max_norm,
                    threshold=threshold,
                    group_name=group_name
                ) for G in G_heavy
            )

        for i, res in zip(indices, expm_results):
            result[i] = res

    return result.reshape(*batch_shape, K, K)
