# -*- coding: utf-8 -*-
"""
Created on Wed Jul 23 06:38:37 2025

@author: chris and christine
"""
import numpy as np
from natural_gradient import dexpinv_operator_morphism  # you will need to implement this
from numerical_utils import safe_inv, sanitize_sigma
from get_generators import get_generators
import config   
#==============================================================================
#
#                    Apply Natural Gradient to Bundle Morphism
#
#==============================================================================
from natural_gradient import compute_fisher_metric_rectangular_natural 



def accumulate_morphism_feedback_gradient_natural(
    agent_i,
    feedback_weight,
    G_inv_field,
    generators,
    mask=None,
    eps=1e-8,
):
    """
    Accumulate natural gradient ∇_Φ D_KL(p || Φ·q) into agent_i.grad_Phi
    using the natural parameter formulation.

    Args:
        agent_i        : Agent object with eta_q, eta_p, and bundle_morphism_q_to_p
        feedback_weight: scaling factor (e.g. config.alpha_feedback)
        G_inv_field    : (..., d, d), rectangular inverse Fisher metric for Φ
        generators     : (d, K_p, K_q), Lie generators for rectangular morphism
        mask           : (...), optional spatial mask
        eps            : stability epsilon
    """

    # --- Step 1: Compute Euclidean gradient in η-space ---
    grad_euclidean = grad_kl_morphism_natural(
        eta1_a=agent_i.eta1_p_field,
        eta2_a=agent_i.eta2_p_field,
        eta1_b=agent_i.eta1_q_field,
        eta2_b=agent_i.eta2_q_field,
        morphism=agent_i.bundle_morphism_q_to_p,
        eps=eps
    )
    grad_euclidean = np.nan_to_num(grad_euclidean)

    # --- Step 1.5: Optional spatial mask ---
    if mask is not None:
        grad_euclidean *= mask[..., None, None]

    # --- Step 2: Project to natural gradient using rectangular dexpinv ---
    grad_natural = dexpinv_operator_morphism(
        Phi=agent_i.bundle_morphism_q_to_p,
        grad_Phi=grad_euclidean,
        generators=generators,
        fisher_inv_field=G_inv_field,
        eps=eps,
    )
    grad_natural = np.nan_to_num(grad_natural)

    # --- Step 3: Norm check and clipping ---
    norm = np.linalg.norm(grad_natural)
    if not np.isfinite(norm):
        print("[WARNING] grad_natural norm is NaN or Inf — zeroing update")
        grad_natural = np.zeros_like(grad_natural)
        norm = 0.0

    if getattr(config, "debug_gradients", False):
        print(f"[Grad Phi]Grad Phi norm = {norm:.2e}")

    if getattr(config, "clip_morphism_grad", True) and norm > getattr(config, "gradient_clip", 1e5):
        grad_natural *= getattr(config, "gradient_clip", 1e5) / (norm + eps)
        if getattr(config, "debug_gradients", False):
            print(f"[CLIP] Phi gradient norm {norm:.2e} clipped to {getattr(config, 'gradient_clip', 1e5):.1e}")

    # --- Step 4: Accumulate Lie algebra gradient into matrix ---
    delta_Phi_matrix = np.einsum("...a,aij->...ij", grad_natural, generators)
    agent_i.grad_Phi += feedback_weight * np.nan_to_num(delta_Phi_matrix)


def accumulate_morphism_self_gradient_natural(
    agent_i,
    alpha,
    generators,
    G_inv_field,
    mask=None,
    eps=1e-8,
):
    """
    Accumulate natural gradient ∇_{Φ̃} D_KL(q || Φ̃·p) into agent_i.grad_Phi_tilde,
    using natural parameter formulation.

    Args:
        agent_i     : Agent object with eta_q, eta_p, and Φ̃ = bundle_morphism_p_to_q
        alpha       : weight for the KL term (e.g. config.alpha_belief)
        generators  : shape (d, K_q, K_p), Lie generators for rectangular morphism
        G_inv_field : shape (..., d, d), inverse Fisher metric for Φ̃
        mask        : shape (...,), optional spatial mask
        eps         : numerical stability epsilon
    """

    # --- Step 1: Compute Euclidean gradient in η-space ---
    grad_euclidean = grad_kl_morphism_natural(
        eta1_a=agent_i.eta1_q_field,
        eta2_a=agent_i.eta2_q_field,
        eta1_b=agent_i.eta1_p_field,
        eta2_b=agent_i.eta2_p_field,
        morphism=agent_i.bundle_morphism_p_to_q,
        eps=eps
    )
    grad_euclidean = np.nan_to_num(grad_euclidean)

    # --- Step 1.5: Apply mask if given ---
    if mask is not None:
        grad_euclidean *= mask[..., None, None]

    # --- Step 2: Project Euclidean → natural gradient via dexpinv ---
    grad_natural = dexpinv_operator_morphism(
        Phi=agent_i.bundle_morphism_p_to_q,
        grad_Phi=grad_euclidean,
        generators=generators,
        fisher_inv_field=G_inv_field,
        eps=eps,
    )
    grad_natural = np.nan_to_num(grad_natural)

    # --- Step 3: Optional gradient clipping ---
    norm = np.linalg.norm(grad_natural)
    if getattr(config, "debug_gradients", False):
        print(f"[Grad Phi~] Grad Phi~ Norm = {norm:.2e}")

    threshold = getattr(config, "gradient_clip", 1e5)
    if getattr(config, "clip_morphism_grad", True) and norm > threshold:
        grad_natural *= threshold / (norm + eps)
        if getattr(config, "debug_gradients", False):
            print(f"[CLIP] Phi~ gradient norm clipped to {threshold:.1e}")

    # --- Step 4: Convert Lie algebra → matrix form and accumulate ---
    delta_Phi_tilde = np.einsum("...a,aij->...ij", grad_natural, generators)
    agent_i.grad_Phi_tilde += alpha * np.nan_to_num(delta_Phi_tilde)



def grad_kl_morphism_natural(
    eta1_a, eta2_a,    # belief or model
    eta1_b, eta2_b,    # model or belief
    morphism,          # Φ or Φ̃
    side="left",       # "left" for D_KL(q || Φ~ p), "right" for D_KL(p || Φ q)
    eps=1e-8
):
    """
    Compute ∇_Φ D_KL(a || Φ b) in natural parameter form.

    Args:
        eta1_a: (..., K_a)
        eta2_a: (..., K_a, K_a)
        eta1_b: (..., K_b)
        eta2_b: (..., K_b, K_b)
        morphism: (..., K_a, K_b)
        side: "left" for q || Φ p, "right" for p || Φ q
    Returns:
        grad: (..., K_a, K_b)
    """

    eta2_a_inv = safe_inv(eta2_a, eps=eps)
    eta2_b_inv = safe_inv(eta2_b, eps=eps)

    # Pushed inverse covariance: (Φ η_b⁻¹ Φᵀ)⁻¹
    tmp = np.einsum("...ik,...kl->...il", morphism, eta2_b_inv)
    pushed = np.einsum("...ij,...jk->...ik", tmp, morphism.swapaxes(-1, -2))
    bar_eta = safe_inv(pushed, eps=eps)  # (..., K_a, K_a)

    # Δη = η_a⁻¹ η₁_a - Φ η_b⁻¹ η₁_b
    term1 = np.einsum("...ij,...j->...i", eta2_a_inv, eta1_a)
    term2 = np.einsum("...ij,...j->...i", eta2_b_inv, eta1_b)
    morph_term2 = np.einsum("...ij,...j->...i", morphism, term2)
    delta_eta = term1 - morph_term2  # (..., K_a)

    # Build full term
    term_A = bar_eta
    term_B = np.einsum("...ik,...kl->...il", bar_eta, eta2_a_inv)
    term_B = np.einsum("...ij,...jk->...ik", term_B, bar_eta)
    outer = np.einsum("...i,...j->...ij", delta_eta, delta_eta)
    term_C = np.einsum("...ik,...kl->...il", bar_eta, outer)
    term_C = np.einsum("...ij,...jk->...ik", term_C, bar_eta)

    prefactor = 0.5 * (term_A - term_B - term_C)

    # Final contraction: (..., K_a, K_a) × (..., K_a, K_b) × (..., K_b, K_b)⁻¹
    grad = np.einsum("...ik,...kj->...ij", prefactor, morphism)
    grad = np.einsum("...ij,...jk->...ik", grad, eta2_b_inv)

    return grad









