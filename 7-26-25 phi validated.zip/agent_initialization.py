# -*- coding: utf-8 -*-
"""
Created on Thu Jul 24 17:54:26 2025

@author: chris and christine
"""
from scipy.ndimage import gaussian_filter
from scipy.ndimage import distance_transform_edt
import config
import scipy
import numpy as np
from mask_utils import create_agent_mask
from agent_distributions import generate_eta1_eta2_fields

from generalized_agent_schema import Agent

from bundle_morphism_utils import initialize_morphism_pair

from get_generators import get_generators, RhoFunction
from numerical_utils import sanitize_sigma, check_spd_field
from mask_utils import create_agent_mask

import config



def initialize_agents(
    seed: int,
    domain_size: tuple[int, ...],
    N: int,
    K_q: int,
    K_p: int,
    lie_algebra_dim: int,
    visualize: bool = False,
    fixed_location: bool = True,
    params=None,
) -> list:
    """
    Modular initialization of N agents with Gaussian beliefs, models, morphisms, φ, and neighbor structure.
    Uses only natural parameters (η₁, η₂); μ, Σ are computed on demand.
    """
    from numpy.random import default_rng
    rng = default_rng(seed)
    dtype = getattr(config, "dtype", np.float32)
    cfg = {k: getattr(config, k) for k in dir(config) if not k.startswith("__")}

    phi_init         = cfg["phi_init"]
    phi_model_offset = cfg.get("phi_model_offset", 0.1)
    max_neighbors    = cfg.get("max_neighbors", 8)
    overlap_eps      = cfg.get("overlap_eps", 1e-3)

    fixed_center = tuple(s // 2 for s in domain_size) if fixed_location else None
    agents = []

    for n in range(N):
        # ── Mask + center ──
        center, radius, mask, mask_bool = create_agent_mask_and_center(
            domain_size, rng,
            radius_range=cfg.get("agent_radius_range", (5, 10)),
            fixed_center=fixed_center
        )

        # ── q and p fields (η) ──
        eta1_q, eta2_q = generate_eta1_eta2_fields(
            domain_size, rng, K_q,
            eta1_range=config.q_eta_range,
            mask=mask,
            dtype=dtype,
        )

        eta1_p, eta2_p = generate_eta1_eta2_fields(
            domain_size, rng, K_p,
            eta1_range=config.p_eta_range,
            mask=mask,
            dtype=dtype,
        )

        # ── φ and φ̃ ──
        phi, phi_model = initialize_phi_pair(
            domain_size, lie_algebra_dim, rng,
            phi_init, phi_model_offset, mask
        )

        # ── Construct agent ──
        agent = construct_agent_object(
            agent_id=n,
            center=center,
            radius=radius,
            mask=mask,
            eta1_q=eta1_q, eta2_q=eta2_q,
            eta1_p=eta1_p, eta2_p=eta2_p,
            phi=phi, phi_model=phi_model,
            dtype=dtype
        )

        # ── Bundle morphisms Φ and Φ̃ ──
        morphism_type = cfg.get("phi_morphism_type", "identity")
        phi_q_to_p, phi_p_to_q = initialize_bundle_morphisms(
            domain_size=domain_size,
            K_q=K_q,
            K_p=K_p,
            rng=rng,
            mask=agent.mask,
            morphism_type=morphism_type,
            config_tag=""
        )
        agent.bundle_morphism_q_to_p = phi_q_to_p
        agent.bundle_morphism_p_to_q = phi_p_to_q

        # ── SL(2,R) generators ──
        G_q = get_generators(config.group_name, K_q)
        G_p = get_generators(config.group_name, K_p)
        agent.rho_q_func = RhoFunction(G_q)
        agent.rho_p_func = RhoFunction(G_p)

        # ── Initialize gradients ──
        initialize_agent_gradients(agent, config)

        agents.append(agent)

    # ── Neighbor structure ──
    assign_neighbors_vectorized(agents, overlap_eps=overlap_eps, max_neighbors=max_neighbors)
    validate_agents(agents)

    return agents

from scipy.ndimage import gaussian_filter

def initialize_eta1_eta2_fields(grid_shape, K, mask, smooth_sigma=2.0):
    """
    Initialize η₁ and η₂ fields with spatial smoothness inside agent support.
    Returns (eta1_field, eta2_field)
    """
    eta1 = np.random.randn(*grid_shape, K)
    eta2 = -np.eye(K)[None, None, :, :] * np.random.uniform(0.5, 1.5, size=(*grid_shape, 1, 1))

    # Apply spatial smoothing to η₁
    for k in range(K):
        eta1[..., k] = gaussian_filter(eta1[..., k], sigma=smooth_sigma)

    # Apply mask
    eta1 *= mask[..., None]
    eta2 *= mask[..., None, None]

    return eta1, eta2


def scale_to_range(
    field: np.ndarray,
    value_range: tuple[float, float]
) -> np.ndarray:
    """
    Linearly remap `field` so that field.min()→value_range[0], field.max()→value_range[1].
    If field is constant, fill with the midpoint of the range.
    Output dtype is taken from config.dtype.
    """
    lo, hi = value_range
    fmin, fmax = field.min(), field.max()
    dtype = getattr(config, 'dtype', field.dtype)
    if fmax <= fmin:
        return np.full_like(field, (lo + hi) / 2, dtype=dtype)

    # normalize to [0,1]
    norm = (field - fmin) / (fmax - fmin)
    # scale to [lo, hi]
    out = norm * (hi - lo) + lo
    return out.astype(dtype)




def initialize_bundle_morphisms(domain_size, K_q, K_p, rng, mask, morphism_type="identity", config_tag=""):
    """
    Initialize bundle morphisms Φ (q→p) and Φ̃ (p→q) using the configured type.

    Args:
        domain_size    : (H, W)
        K_q, K_p       : fiber dimensions
        rng            : np.random.Generator
        mask           : (H, W) support mask
        morphism_type  : string, e.g. "identity", "smooth", "gauge_covariant"
        config_tag     : optional suffix for config overrides

    Returns:
        phi_q_to_p: (H, W, K_p, K_q)
        phi_p_to_q: (H, W, K_q, K_p)
    """
    return initialize_morphism_pair(
        domain_size=domain_size,
        K_q=K_q,
        K_p=K_p,
        rng=rng,
        morphism_type=morphism_type,
        mask=mask,
        config_tag=config_tag
    )



def initialize_phi_field(
    domain_size: tuple[int, ...],
    lie_algebra_dim: int,
    rng: np.random.Generator,
    init_scale: float,
    mask: np.ndarray,
    smooth_sigma: float = None
) -> np.ndarray:
    """
    Initialize and smooth a φ field with Gaussian noise and apply mask.
    """
    dtype = getattr(config, 'dtype', mask.dtype)
    sigma = smooth_sigma or getattr(config, 'phi_init_smooth_sigma', 0.5)

    phi_raw = rng.normal(scale=init_scale, size=(*domain_size, lie_algebra_dim)).astype(dtype)
    phi_smooth = gaussian_filter(phi_raw, sigma=sigma)
    return phi_smooth * mask[..., None]

def initialize_phi_pair(
    domain_size: tuple[int, ...],
    lie_algebra_dim: int,
    rng: np.random.Generator,
    phi_init: float,
    phi_model_offset: float,
    mask: np.ndarray
) -> tuple[np.ndarray, np.ndarray]:
    """
    Initialize φ and φ̃ (belief and model) with optional offset for φ̃.
    """
    phi = initialize_phi_field(domain_size, lie_algebra_dim, rng, phi_init, mask)

    if getattr(config, "identical_models", False):
        phi_model = np.zeros_like(phi)
    else:
        delta = rng.normal(scale=phi_model_offset, size=(*domain_size, lie_algebra_dim)).astype(phi.dtype)
        phi_model_raw = phi + delta
        phi_model = gaussian_filter(phi_model_raw, sigma=getattr(config, 'phi_init_smooth_sigma', 0.5))
        phi_model *= mask[..., None]

    return phi, phi_model


def assign_neighbors_vectorized(
    agents: list,
    overlap_eps: float,
    max_neighbors: int
) -> None:
    """
    Assigns neighbors to each agent by computing pairwise mask overlaps.
    Vectorized for efficiency.

    A pair (i, j) is considered overlapping if:
        overlap(i, j) > overlap_eps × num_pixels
    """
    if max_neighbors == 0:
        for agent in agents:
            agent.neighbors = []
        return

    N = len(agents)
    dtype = getattr(config, 'dtype', np.float32)

    # Flatten masks into (N, H×W)
    masks_flat = np.stack([agent.mask.flatten().astype(dtype) for agent in agents])

    # Compute pairwise overlap matrix
    overlap_matrix = masks_flat @ masks_flat.T  # shape: (N, N)
    pixel_thresh = overlap_eps * masks_flat.shape[1]

    # Boolean matrix: True if overlap > threshold
    above_thresh = overlap_matrix > pixel_thresh
    np.fill_diagonal(above_thresh, False)  # Exclude self-overlap

    for i in range(N):
        sorted_idx = np.argsort(-overlap_matrix[i])  # descending order
        valid_neighbors = [j for j in sorted_idx if above_thresh[i, j]]
        agents[i].neighbors = [{"id": j} for j in valid_neighbors[:max_neighbors]]

def plot_agent_overlap(agent_i, agent_j, cutoff=None):
    import matplotlib.pyplot as plt
    import numpy as np
    import config

    if cutoff is None:
        cutoff = getattr(config, "support_cutoff_eps", 1e-3)

    mask_i  = agent_i.mask > cutoff
    mask_j  = agent_j.mask > cutoff
    overlap = mask_i & mask_j

    if mask_i.ndim != 2:
        raise ValueError(f"plot_agent_overlap only supports 2D spatial domains, got shape {mask_i.shape}")

    H, W = mask_i.shape

    fig, axs = plt.subplots(1, 3, figsize=(12, 4))

    for ax, M, title in zip(
        axs,
        [mask_i, mask_j, overlap],
        [f"Agent {agent_i.id} Support",
         f"Agent {agent_j.id} Support",
         "Overlap"]
    ):
        ax.imshow(
            M,
            cmap="gray",
            origin="lower",
            extent=[0, W, 0, H],
            interpolation="nearest"
        )
        ax.set_title(title)
        ax.set_xticks([0, W//2, W])
        ax.set_yticks([0, H//2, H])

    plt.tight_layout()
    plt.show()

def construct_agent_object(
    agent_id,
    center,
    radius,
    mask,
    eta1_q, eta2_q,
    eta1_p, eta2_p,
    phi, phi_model,
    dtype=np.float32
) -> Agent:
    """
    Build an Agent object from natural parameters only.
    μ and Σ are computed on demand to ensure gauge invariance.

    Args:
        agent_id   : int
        center     : (int, int)
        radius     : float
        mask       : (H, W)
        eta1_q, eta2_q : natural parameters for q (H, W, K_q), (H, W, K_q, K_q)
        eta1_p, eta2_p : natural parameters for p (H, W, K_p), (H, W, K_p, K_p)
        phi, phi_model : (..., d) gauge fields
        dtype      : float32/float64

    Returns:
        Agent
    """
    return Agent(
        id=agent_id,
        center=center,
        radius=radius,
        mask=mask.astype(dtype),

        eta1_q_field=eta1_q.astype(dtype),
        eta2_q_field=eta2_q.astype(dtype),
        eta1_p_field=eta1_p.astype(dtype),
        eta2_p_field=eta2_p.astype(dtype),

        phi=phi.astype(dtype),
        phi_model=phi_model.astype(dtype),

        neighbors=[]
    )




def create_agent_mask_and_center(domain_size, rng, radius_range, fixed_center=None):
    """
    Sample agent center and radius, and generate its soft mask.

    Args:
        domain_size  : tuple[int, int] = (H, W)
        rng          : np.random.Generator
        radius_range : (float, float)
        fixed_center : optional tuple[int, int]

    Returns:
        center : (int, int) coordinates of agent center
        radius : float
        mask   : (H, W) soft float32 mask
        mask_bool : (H, W) boolean version of mask for edge decay
    """
    radius = rng.uniform(*radius_range)
    center = fixed_center or tuple(rng.integers(0, s) for s in domain_size)
    mask = create_agent_mask(center, radius, domain_size)
    return center, radius, mask.astype(np.float32), mask.astype(bool)



def initialize_agent_gradients(agent, config):
    """
    Initialize all gradient fields for the agent using the shapes of eta fields.
    Should be called once after the agent is created and eta fields are populated.
    """
    # Natural gradient fields (belief)
    agent.grad_eta1_q_field = np.zeros_like(agent.eta1_q_field)
    agent.grad_eta2_q_field = np.zeros_like(agent.eta2_q_field)

    # Natural gradient fields (model)
    agent.grad_eta1_p_field = np.zeros_like(agent.eta1_p_field)
    agent.grad_eta2_p_field = np.zeros_like(agent.eta2_p_field)

    # Gauge field gradients
    agent.grad_phi = np.zeros_like(agent.phi)
    agent.grad_phi_tilde = np.zeros_like(agent.phi_model)

    # Morphism gradients — only if the morphisms exist
    agent.grad_Phi = (
        np.zeros_like(agent.bundle_morphism_q_to_p)
        if agent.bundle_morphism_q_to_p is not None else None
    )
    agent.grad_Phi_tilde = (
        np.zeros_like(agent.bundle_morphism_p_to_q)
        if agent.bundle_morphism_p_to_q is not None else None
    )




def validate_agents(agents: list) -> None:
    """
    Run validation checks on each agent's fields.
    Ensures η fields are finite, φ fields are finite, masks are valid.
    """
    support_eps = getattr(config, "support_cutoff_eps", 1e-4)
    debug = getattr(config, "debug", False)

    for agent in agents:
        support = agent.mask > support_eps

        if not np.all(np.isfinite(agent.eta1_q_field[support])):
            print(f"[VALIDATION] Agent {agent.id}: non-finite η₁_q inside mask")
        if not np.all(np.isfinite(agent.eta2_q_field[support])):
            print(f"[VALIDATION] Agent {agent.id}: non-finite η₂_q inside mask")
        if not np.all(np.isfinite(agent.eta1_p_field[support])):
            print(f"[VALIDATION] Agent {agent.id}: non-finite η₁_p inside mask")
        if not np.all(np.isfinite(agent.eta2_p_field[support])):
            print(f"[VALIDATION] Agent {agent.id}: non-finite η₂_p inside mask")
        if not np.all(np.isfinite(agent.phi[support])):
            print(f"[VALIDATION] Agent {agent.id}: non-finite φ values inside mask")
        if not np.all(np.isfinite(agent.phi_model[support])):
            print(f"[VALIDATION] Agent {agent.id}: non-finite φ̃ values inside mask")
        if not np.all((agent.mask >= 0) & (agent.mask <= 1)):
            print(f"[VALIDATION] Agent {agent.id}: mask contains invalid values outside [0,1]")

        if debug:
            eta1_min = agent.eta1_q_field[support].min()
            eta1_max = agent.eta1_q_field[support].max()
            eta2_norm = np.linalg.norm(agent.eta2_q_field[support])
            print(f"[DEBUG] Agent {agent.id}: η₁_q range = [{eta1_min:.3g}, {eta1_max:.3g}], "
                  f"‖η₂_q‖ = {eta2_norm:.3g}")

    print("[✓] Agent validation complete.")
