# === generalized_agent_distributions.py ===
import numpy as np
import config
import numpy as np
from numerical_utils import safe_inv


def mu_sigma_to_natural(mu, sigma, eps=1e-8):
    """
    Convert (μ, Σ) to natural parameters (η₁, η₂).

    η₁ = Σ⁻¹μ
    η₂ = -½ Σ⁻¹

    Args:
        mu:    (..., K)
        sigma: (..., K, K)
        eps:   regularization for safe inverse

    Returns:
        eta1: (..., K)
        eta2: (..., K, K)
    """
    sigma_inv = safe_inv(sigma, eps)
    eta1 = np.einsum('...ij,...j->...i', sigma_inv, mu)
    eta2 = -0.5 * sigma_inv
    return eta1, eta2

import numpy as np
from numerical_utils import sanitize_sigma

def generate_eta1_eta2_fields(
    domain_size,
    rng,
    K,
    eta1_range=(-2.0, 2.0),
    eta2_range=(-5.0, -0.1),
    mask=None,
    sigma_outside_val=-0.01,
    dtype=np.float32,
    smooth_sigma=2.0,
):
    """
    Generate smooth η₁ and η₂ fields for multivariate Gaussian natural parameters.

    eta1 ∈ ℝᵏ      (∼ μ-like)
    eta2 ∈ Symₖ    (∼ −½ Σ⁻¹)

    Args:
        domain_size      : (H, W)
        rng              : np.random.Generator
        K                : dimension of fiber
        eta1_range       : range for η₁ values
        eta2_range       : range for η₂ diagonal values
        mask             : optional spatial mask (H, W)
        sigma_outside_val: fallback value for η₂ outside mask (must be negative)
        dtype            : output type
        smooth_sigma     : spatial smoothing parameter (for Gaussian filter)

    Returns:
        eta1_field: (H, W, K)
        eta2_field: (H, W, K, K)
    """
    from scipy.ndimage import gaussian_filter

    H, W = domain_size
    eta1_field = rng.uniform(*eta1_range, size=(H, W, K)).astype(dtype)
    eta2_diag = rng.uniform(*eta2_range, size=(H, W, K)).astype(dtype)

    # Smooth each η₁ channel
    for k in range(K):
        eta1_field[..., k] = gaussian_filter(eta1_field[..., k], sigma=smooth_sigma)
        eta2_diag[..., k] = gaussian_filter(eta2_diag[..., k], sigma=smooth_sigma)

    # Build symmetric η₂ from smoothed diagonals
    eta2_field = np.zeros((H, W, K, K), dtype=dtype)
    for i in range(K):
        eta2_field[..., i, i] = eta2_diag[..., i]

    if mask is not None:
        mask_exp = mask[..., None]
        eta1_field *= mask_exp
        eta2_field *= mask_exp[..., None]
        eta2_field += (1.0 - mask_exp)[..., None] * np.eye(K, dtype=dtype) * sigma_outside_val

    return eta1_field, eta2_field



def natural_to_mu_sigma(eta1, eta2, eps=1e-8):
    """
    Convert natural parameters (η₁, η₂) to standard form (μ, Σ).

    Args:
        eta1: (..., K)
        eta2: (..., K, K)
        eps:  regularization for safe inverse

    Returns:
        mu:    (..., K)
        sigma: (..., K, K)
    """
    sigma_inv = -2.0 * eta2
    sigma = safe_inv(sigma_inv, eps)
    mu = np.einsum('...ij,...j->...i', sigma, eta1)
    return mu, sigma




def get_fiber_basis(K: int) -> np.ndarray:
    """
    Return standard basis vectors for the fiber space ℝ^K.
    Output shape: (K, K)
    """
    return np.eye(K, dtype=np.float32)


def initialize_multivariate_gaussian_distribution(
    x_coords: np.ndarray,
    mu_field: np.ndarray,
    sigma_field: np.ndarray,
    mask: np.ndarray,
    log_eps: float = 1e-8
) -> np.ndarray:
    """
    Evaluate multivariate Gaussian distribution q(x) over fiber points,
    defined by spatially varying (μ, Σ), producing a probability field (H, W, K).

    Args:
        x_coords:    (K, D) fiber coordinates
        mu_field:    (H, W, D) spatial mean
        sigma_field: (H, W, D, D) spatial covariance
        mask:        (H, W) support mask
        log_eps:     small stabilizer

    Returns:
        dist:        (H, W, K) probability distribution
    """
    H, W, D = mu_field.shape
    K = x_coords.shape[0]

    # Broadcast to compute deltas
    x = x_coords[None, None, :, :]    # (1, 1, K, D)
    mu = mu_field[:, :, None, :]      # (H, W, 1, D)
    delta = x - mu                    # (H, W, K, D)

    # Regularize Σ
    eps_eye = log_eps * np.eye(D)
    sigma_reg = sigma_field + eps_eye[None, None, :, :]

    # Inverse Σ
    sigma_inv = np.zeros_like(sigma_reg)
    for i in range(H):
        for j in range(W):
            try:
                sigma_inv[i, j] = np.linalg.inv(sigma_reg[i, j])
            except np.linalg.LinAlgError:
                sigma_inv[i, j] = np.eye(D) * (1.0 / log_eps)
                print(f"[WARN] Σ⁻¹ fallback at ({i},{j})")

    # Mahalanobis distance
    mahal_sq = np.einsum("...kd,...de,...ke->...k", delta, sigma_inv, delta)  # (H, W, K)
    exponent = -0.5 * mahal_sq
    exponent -= np.max(exponent, axis=-1, keepdims=True)

    exp_vals = np.exp(exponent) * mask[..., None]
    norm = np.clip(np.sum(exp_vals, axis=-1, keepdims=True), log_eps, None)

    return exp_vals / norm




# ─── Gaussian Distribution in Natural Parameters ────────────────────────────────

def gaussian_from_natural(eta1, eta2, eps=1e-8):
    """
    Convert natural parameters (η₁, η₂) to standard Gaussian parameters (μ, Σ).

    Args:
        eta1: (..., K) natural mean term, η₁ = Σ⁻¹μ
        eta2: (..., K, K) natural precision term, η₂ = -½ Σ⁻¹
        eps: regularization for safe inversion

    Returns:
        mu: (..., K) mean
        sigma: (..., K, K) covariance matrix
    """
    sigma_inv = -2.0 * eta2
    sigma = safe_inv(sigma_inv, eps=eps)
    mu = np.einsum("...ij,...j->...i", sigma, eta1)
    return mu, sigma


def log_gaussian_natural(x, eta1, eta2, eps=1e-8):
    """
    Evaluate the log-density of a multivariate Gaussian:
        log p(x) = η₁ᵀx + xᵀη₂x − A(η)

    Args:
        x     : (..., K) evaluation point
        eta1  : (..., K) natural mean term
        eta2  : (..., K, K) natural precision term
        eps   : numerical regularization

    Returns:
        logp: (...,) log-density at x
    """
    lin_term = np.einsum("...i,...i->...", eta1, x)
    quad_term = np.einsum("...i,...ij,...j->...", x, eta2, x)
    logZ = compute_log_partition_gaussian(eta1, eta2, eps)
    return lin_term + quad_term - logZ


def compute_log_partition_gaussian(eta1, eta2, eps=1e-8):
    """
    Compute the log-partition function A(η) for a Gaussian:
        A(η) = ½ μᵀΣ⁻¹μ + ½ log|2πΣ|

    Args:
        eta1 : (..., K) natural mean term
        eta2 : (..., K, K) natural precision term
        eps  : numerical regularization

    Returns:
        A_eta: (...,) log-normalizer
    """
    sigma_inv = -2.0 * eta2
    sigma = safe_inv(sigma_inv, eps=eps)
    mu = np.einsum("...ij,...j->...i", sigma, eta1)
    mahal = np.einsum("...i,...ij,...j->...", mu, sigma_inv, mu)
    sign, logdet = np.linalg.slogdet(sigma)
    d = eta1.shape[-1]
    return 0.5 * mahal + 0.5 * logdet + 0.5 * d * np.log(2 * np.pi)



def initialize_uniform_distribution(
    x: np.ndarray = None,
    mask: np.ndarray = None,
    dtype=np.float32
) -> np.ndarray:
    """
    Initialize uniform distribution over K fiber points, with optional spatial mask.

    Args:
        x:     optional array to infer spatial shape
        mask:  optional support mask (H, W)
        dtype: float32 or float64

    Returns:
        base: (H, W, K) uniform distribution
    """
    K = config.K
    if mask is not None:
        shape = mask.shape
    elif x is not None and x.ndim >= 2:
        shape = x.shape[:-1]
    else:
        shape = config.domain_size

    base = np.full((*shape, K), 1.0 / K, dtype=dtype)
    return base * mask[..., None] if mask is not None else base
