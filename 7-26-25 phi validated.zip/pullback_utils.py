import numpy as np
from get_generators import get_generators
from generalized_omega import compute_gauge_potential
from generalized_agent_distributions import (
    initialize_multivariate_gaussian_distribution,
    get_fiber_basis,
)
import config
from scipy.ndimage import sobel


def compute_agent_pullback_blocks(agent, vis_inds, dark_inds, from_belief=False, eps=1e-12):
    """
    Compute pullback blocks using either p(c) (default) or q(c) (if from_belief=True)
    """
    K = agent.mu_p_field.shape[-1]
    fiber_x = get_fiber_basis(K)

    # Choose which distribution to pull back
    mu_field    = agent.mu_q_field if from_belief else agent.mu_p_field
    sigma_field = agent.sigma_q_field if from_belief else agent.sigma_p_field

    dist_field = initialize_multivariate_gaussian_distribution(
        x_coords    = fiber_x,
        mu_field    = mu_field,
        sigma_field = sigma_field,
        mask        = agent.mask,
        log_eps     = eps,
    )  # shape (H, W, K)

    pull = compute_pullback_grid(
        p_grid     = dist_field,
        phi_grid   = agent.phi_model,
        K          = K,
        vis_inds   = vis_inds,
        dark_inds  = dark_inds,
        eps        = eps,
        group_name = getattr(config, "group_name", "sl2r"),
    )

    return pull



def algebra_fisher_metric(p_c, generators, eps=1e-12):
    """
    Compute the Fisher metric on the Lie algebra at a single base point.

    Args:
        p_c:         (K,) — probability vector at a single point in the fiber (∑ p_k = 1)
        generators:  (d, K, K) — Lie algebra generators T_a in the fiber representation
        eps:         float — regularization to avoid division by 0

    Returns:
        I: (d, d) — Fisher information metric over the Lie algebra directions
    """
    p_safe = np.clip(p_c, eps, 1.0)
    p_safe /= np.sum(p_safe)

    V = np.tensordot(generators, p_safe, axes=([1], [0]))  # (d, K)
    I = np.einsum('ak,bk,k->ab', V, V, 1.0 / p_safe)        # (d, d)
    return I


def block_decompose(I, vis_inds, dark_inds):
    """
    Decompose a full algebra metric I into visible, mixing, and dark blocks.
    """
    M_vis = I[np.ix_(vis_inds, vis_inds)]
    Delta = I[np.ix_(vis_inds, dark_inds)]
    M_dark = I[np.ix_(dark_inds, dark_inds)]
    return M_vis, Delta, M_dark


def pullback_metric_at_point(I_ab, A_vecs):
    """
    Contract Fisher metric I_ab with gauge vectors A_μ to get spatial pullback G.
    """
    D = len(A_vecs)
    return np.array([[A_vecs[mu] @ (I_ab @ A_vecs[nu]) for nu in range(D)]
                     for mu in range(D)])

def compute_lie_metric(generators: np.ndarray):
    """
    Compute inner product matrix G_{ab} = Tr(G_aᵀ G_b) and its inverse.

    Args:
        generators: (d, K, K) basis of Lie algebra

    Returns:
        G: (d, d) inner product matrix
        G_inv: (d, d) inverse (with fallback)
    """
    d = generators.shape[0]
    G = np.einsum("aij,bij->ab", generators, generators)
    G = 0.5 * (G + G.T)  # symmetrize

    G_inv = safe_inv(G, eps=getattr(config, "eps", 1e-6))


    return G, G_inv

def compute_pullback_grid(p_grid, phi_grid, K, vis_inds, dark_inds, eps=1e-12, group_name="sl2r"):
    """
    Compute full pullback diagnostic fields from p(c) and φ_model.
    Returns: dictionary with fields I, M_vis, M_dark, Delta, G
    """
    generators = get_generators(group_name, K)     # (d, K, K)
    A_fields = compute_gauge_potential(phi_grid)   # tuple of (H, W, d)
    N1, N2, d = phi_grid.shape
    D = len(A_fields)

    # Clip and normalize probabilities
    p_safe = np.clip(p_grid, eps, None)  # (H, W, K)

    # Fisher I_ab grid via tensor contraction
    V_batch = np.einsum('abc,ijc->ijab', generators, p_safe)         # (H, W, d, K)
    I_grid = np.einsum('ijak,ijbk,ijk->ijab', V_batch, V_batch, 1 / p_safe)  # (H, W, d, d)

    # Use reusable block_decompose function
    M_vis_grid, Delta_grid, M_dark_grid = np.empty((N1, N2, len(vis_inds), len(vis_inds))), \
                                          np.empty((N1, N2, len(vis_inds), len(dark_inds))), \
                                          np.empty((N1, N2, len(dark_inds), len(dark_inds)))

    for i in range(N1):
        for j in range(N2):
            I_ij = I_grid[i, j]
            M_vis_grid[i, j], Delta_grid[i, j], M_dark_grid[i, j] = block_decompose(I_ij, vis_inds, dark_inds)

    # G_{μν} = A_μ^a I_ab A_ν^b
    A_stack = np.stack(A_fields, axis=-2)                      # (H, W, D, d)
    G_grid = np.einsum('...ua,...ab,...vb->...uv', A_stack, I_grid, A_stack)  # (H, W, D, D)

    return {
        'I':      I_grid,
        'M_vis':  M_vis_grid,
        'Delta':  Delta_grid,
        'M_dark': M_dark_grid,
        'G':      G_grid,
    }


def compute_fisher_metric_block_diag(sigma_field, mask=None, eps=1e-8):
    """
    Compute Fisher metric G = Σ⁻¹ for a batch of SPD matrices, with optional masking.
    """
    H, W, K, _ = sigma_field.shape
    G = np.zeros_like(sigma_field)
    eye = np.eye(K, dtype=sigma_field.dtype)

    for i in range(H):
        for j in range(W):
            Σ = sigma_field[i, j]
            if mask is not None and not mask[i, j]:
                G[i, j] = np.eye(K)
                continue
            Σ_reg = Σ + eps * eye
            try:
                G[i, j] = np.linalg.inv(Σ_reg)
            except np.linalg.LinAlgError:
                G[i, j] = np.eye(K)  # fallback
    return G


def compute_pullback_metric(mu_field, sigma_field, mask=None):
    """
    Pullback Fisher metric from gradients of μ and Σ⁻¹:
        M_ab(c) = ∂_a μ_k · Σ⁻¹_kl · ∂_b μ_l
    """
    H, W, K = mu_field.shape
    D = 2
    M = np.zeros((H, W, D, D), dtype=mu_field.dtype)

    # Fisher inverse Σ⁻¹
    G_inv = compute_fisher_metric_block_diag(sigma_field, mask=mask)  # (H, W, K, K)

    # ∇μ: (H, W, D, K)
    grad_mu = np.stack([
        sobel(mu_field, axis=0, mode='wrap') / 8.0,  # ∂y μ
        sobel(mu_field, axis=1, mode='wrap') / 8.0,  # ∂x μ
    ], axis=2)  # (H, W, D, K)

    # Efficient contraction: M_ab = ∑_kl ∂_a μ_k · G_kl · ∂_b μ_l
    M = np.einsum("...ak,...kl,...bl->...ab", grad_mu, G_inv, grad_mu)
    return M
