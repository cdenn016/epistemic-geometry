# -*- coding: utf-8 -*-
"""
Created on Fri Jul 25 10:19:37 2025

@author: chris and christine
"""
import config
import numpy as np
from natural_utils import natural_to_mu_sigma_batch
from numerical_utils import sanitize_sigma, safe_logdet

def kl_divergence_natural_projected_p_to_q(
    eta1_q,        # (..., K_q)
    eta2_q,        # (..., K_q, K_q)
    eta1_p,        # (..., K_p)
    eta2_p,        # (..., K_p, K_p)
    Phi_tilde,     # (..., K_q, K_p)
    eps=1e-8
):
    """
    Compute KL[q || Φ̃·p] using natural parameters only.
    Projection: pushforward p via Φ̃ : B_p → B_q.

    Args:
        eta1_q     : (..., K_q)
        eta2_q     : (..., K_q, K_q)
        eta1_p     : (..., K_p)
        eta2_p     : (..., K_p, K_p)
        Phi_tilde  : (..., K_q, K_p)
        eps        : stabilizer for inverse and log det

    Returns:
        kl_vals    : (...,) KL divergence values
    """
    

    # ───── Compute projected natural parameters Φ̃ η₁_p and Φ̃ η₂_p Φ̃ᵀ ─────
    eta1_proj = np.einsum("...ik,...k->...i", Phi_tilde, eta1_p)                  # (..., K_q)
    eta2_proj = np.einsum("...ik,...kl,...jl->...ij", Phi_tilde, eta2_p, Phi_tilde)  # (..., K_q, K_q)

    # ───── Convert both to (μ, Σ) for KL computation ─────
    mu_q,     sigma_q     = natural_to_mu_sigma_batch(eta1_q, eta2_q, eps)
    mu_proj,  sigma_proj  = natural_to_mu_sigma_batch(eta1_proj, eta2_proj, eps)

    sigma_q    = sanitize_sigma(sigma_q, eps)
    sigma_proj = sanitize_sigma(sigma_proj, eps)

    # ───── Compute full KL divergence in μ, Σ domain ─────
    diff = mu_q - mu_proj
    sigma_proj_inv = np.linalg.inv(sigma_proj)

    # Mahalanobis term: (μ_q − μ_proj)^T Σ_proj⁻¹ (μ_q − μ_proj)
    mahal = np.einsum("...i,...ij,...j->...", diff, sigma_proj_inv, diff)

    # Trace term: Tr[Σ_proj⁻¹ Σ_q]
    trace_term = np.einsum("...ij,...ji->...", sigma_proj_inv, sigma_q)

    # log(det(Σ_proj) / det(Σ_q))
    log_det_q     = safe_logdet(sigma_q, eps)
    log_det_proj  = safe_logdet(sigma_proj, eps)
    log_det_term  = log_det_proj - log_det_q

    K_q = eta1_q.shape[-1]
    kl_vals = 0.5 * (log_det_term - K_q + trace_term + mahal)
    return kl_vals


def compute_kl_projected_field_natural(
    eta1_src, eta2_src,         # (..., K_src), (..., K_src, K_src)
    eta1_tgt, eta2_tgt,         # (..., K_tgt), (..., K_tgt, K_tgt)
    morphism,                   # (..., K_tgt, K_src) — Φ or Φ̃
    mask,                       # (...,) — float or bool mask
    direction="p_to_q",         # "p_to_q" for KL[q ‖ Φ̃·p], "q_to_p" for KL[p ‖ Φ·q]
    eps=1e-8
):
    """
    Compute per-point KL divergence with natural parameter morphism projection.

    Args:
        eta1_src, eta2_src : natural parameters of source distribution (q or p)
        eta1_tgt, eta2_tgt : natural parameters of target distribution (p or q)
        morphism           : (..., K_tgt, K_src), e.g. Φ or Φ̃
        mask               : (...,) boolean or float
        direction          : str, "p_to_q" → KL[q || Φ̃·p], "q_to_p" → KL[p || Φ·q]
        eps                : stabilizer

    Returns:
        kl_field : (...) array of KL divergences
    """
    from natural_utils import (
        natural_to_mu_sigma_batch, sanitize_sigma, safe_logdet
    )

    support = mask > config.support_cutoff_eps
    if not np.any(support):
        return np.zeros(mask.shape, dtype=np.float32)

    # Project tgt (e.g. p or q) into source fiber
    eta1_proj = np.einsum("...ik,...k->...i", morphism, eta1_tgt)
    eta2_proj = np.einsum("...ik,...kl,...jl->...ij", morphism, eta2_tgt, morphism)

    # Convert to (μ, Σ)
    mu_src, sigma_src   = natural_to_mu_sigma_batch(eta1_src, eta2_src, eps)
    mu_proj, sigma_proj = natural_to_mu_sigma_batch(eta1_proj, eta2_proj, eps)

    sigma_src = sanitize_sigma(sigma_src, eps)
    sigma_proj = sanitize_sigma(sigma_proj, eps)

    # Flatten masked entries
    mu1 = mu_src[support]
    mu2 = mu_proj[support]
    S1  = sigma_src[support]
    S2  = sigma_proj[support]

    delta = mu1 - mu2
    S2inv = np.linalg.inv(S2)

    mahal = np.einsum("...i,...ij,...j->...", delta, S2inv, delta)
    trace_term = np.einsum("...ij,...ji->...", S2inv, S1)

    logdet_S1 = safe_logdet(S1, eps)
    logdet_S2 = safe_logdet(S2, eps)

    K = eta1_src.shape[-1]
    logdet_term = logdet_S2 - logdet_S1

    kl_vals = 0.5 * (logdet_term - K + trace_term + mahal)

    kl_field = np.zeros(mask.shape, dtype=np.float32)
    kl_field[support] = np.where(np.isfinite(kl_vals), kl_vals, 0.0)
    return kl_field

def compute_alignment_field(
    agents, i, field_type="belief",
    eps=config.support_cutoff_eps,
    log_eps=config.log_eps
) -> np.ndarray:
    """
    Compute spatial KL field KL[q_i(c) || Ω_ij · q_j(c)] for agent i using natural parameters.

    Applies to either belief (q) or model (p) fields. KL is computed at each spatial
    overlap point with neighbors, and averaged across neighbors.

    Returns:
        (H, W) array — per-pixel average KL divergence field
    """
   

    A = agents[i]
    mask_i = threshold_mask(A.mask, eps)
    if not np.any(mask_i) or not A.neighbors:
        return np.zeros_like(mask_i, dtype=np.float32)

    H, W = A.mask.shape
    kl_accum = np.zeros((H, W), dtype=np.float32)
    n_nb_at = np.zeros((H, W), dtype=np.int32)

    if field_type == "belief":
        eta1_i = A.eta1_q_field
        eta2_i = A.eta2_q_field
        phi_i  = A.phi
        K      = config.K_q
    elif field_type == "model":
        eta1_i = A.eta1_p_field
        eta2_i = A.eta2_p_field
        phi_i  = A.phi_model
        K      = config.K_p
    else:
        raise ValueError(f"[compute_alignment_field_general] Invalid field_type: '{field_type}'")

    generators = get_generators(config.group_name, K)

    for nb in A.neighbors:
        B = agents[nb["id"]]
        mask_j = threshold_mask(B.mask, eps)
        overlap = mask_i & mask_j
        if not np.any(overlap):
            continue

        idx = np.argwhere(overlap)
        i_idx, j_idx = idx[:, 0], idx[:, 1]

        eta1_j = B.eta1_q_field if field_type == "belief" else B.eta1_p_field
        eta2_j = B.eta2_q_field if field_type == "belief" else B.eta2_p_field
        phi_j  = B.phi if field_type == "belief" else B.phi_model

        # (N, K) and (N, K, K)
        eta1_i_pts = eta1_i[overlap]
        eta2_i_pts = eta2_i[overlap]
        eta1_j_pts = eta1_j[overlap]
        eta2_j_pts = eta2_j[overlap]

        # Gauge transport: Ω = exp(φ_i) @ exp(−φ_j)
        O_i     = exp_lie_algebra_irrep(phi_i[overlap], generators)
        O_j_inv = exp_lie_algebra_irrep(-phi_j[overlap], generators)
        Omega   = np.einsum("mab,mbc->mac", O_i, O_j_inv)

        # Transport j's η₁ and η₂ via Ω: η₁' = Ω η₁, η₂' = Ω η₂ Ωᵀ
        eta1_j_t = np.einsum("mab,mb->ma", Omega, eta1_j_pts)
        eta2_j_t = np.einsum("mab,mbc,mcd->mad", Omega, eta2_j_pts, Omega)

        # Convert both to (μ, Σ) for KL evaluation (temporary step)
        mu_i, sigma_i = natural_to_mu_sigma_batch(eta1_i_pts, eta2_i_pts, eps=log_eps)
        mu_j, sigma_j = natural_to_mu_sigma_batch(eta1_j_t, eta2_j_t, eps=log_eps)

        sigma_i = sanitize_sigma(sigma_i, eps)
        sigma_j = sanitize_sigma(sigma_j, eps)

        delta = mu_i - mu_j
        sigma_j_inv = np.linalg.inv(sigma_j)

        mahal = np.einsum("...i,...ij,...j->...", delta, sigma_j_inv, delta)
        trace_term = np.einsum("...ij,...ji->...", sigma_j_inv, sigma_i)
        logdet_i = safe_logdet(sigma_i, eps)
        logdet_j = safe_logdet(sigma_j, eps)
        kl_vals = 0.5 * (logdet_j - logdet_i - K + trace_term + mahal)

        kl_vals = np.where(np.isfinite(kl_vals), kl_vals, 0.0)
        np.add.at(kl_accum, (i_idx, j_idx), kl_vals)
        np.add.at(n_nb_at, (i_idx, j_idx), 1)

    out = np.zeros_like(kl_accum, dtype=np.float32)
    valid = n_nb_at > 0
    out[valid] = kl_accum[valid] / n_nb_at[valid]
    return out * mask_i

def compute_pairwise_kl_field(agents, generators, params, field_type="belief", return_pointwise=False):
    """
    Compute KL[q_i || Ω_ij · q_j] or KL[p_i || Ω_ij · p_j] using natural parameters for all (i, j) pairs.

    Args:
        agents           : list of Agent objects
        generators       : (d, K, K) Lie algebra basis for the group irrep
        params           : dict with 'log_eps', 'overlap_eps', and 'group_name'
        field_type       : either "belief" or "model"
        return_pointwise : if True, returns full per-point KL maps

    Returns:
        kl_matrix        : (N, N)
        pointwise        : (optional) {(i,j): KL_field}
    """
    from generalized_omega import batch_apply_omega, compute_inter_omega_fieldwise
    from natural_utils import natural_to_mu_sigma_batch, safe_logdet, sanitize_sigma

    log_eps = params.get("log_eps", 1e-8)
    eps     = params.get("overlap_eps", 1e-6)
    group   = params.get("group_name", "sl2r")

    N = len(agents)
    kl_matrix = np.full((N, N), np.nan)
    pointwise = {} if return_pointwise else None

    for i, A in enumerate(agents):
        mask_i = A.mask > eps

        # Select fields based on field_type
        if field_type == "belief":
            eta1_i = A.eta1_q_field
            eta2_i = A.eta2_q_field
            phi_i  = A.phi
        elif field_type == "model":
            eta1_i = A.eta1_p_field
            eta2_i = A.eta2_p_field
            phi_i  = A.phi_model
        else:
            raise ValueError(f"Invalid field_type: {field_type}")

        for j, B in enumerate(agents):
            if i == j:
                kl_matrix[i, j] = 0.0
                continue

            mask_j = B.mask > eps
            overlap = mask_i & mask_j
            if not np.any(overlap):
                continue

            if field_type == "belief":
                eta1_j = B.eta1_q_field
                eta2_j = B.eta2_q_field
                phi_j  = B.phi
            else:
                eta1_j = B.eta1_p_field
                eta2_j = B.eta2_p_field
                phi_j  = B.phi_model

            eta1_i_pts = eta1_i[overlap]
            eta2_i_pts = eta2_i[overlap]
            eta1_j_pts = eta1_j[overlap]
            eta2_j_pts = eta2_j[overlap]

            phi_i_pts  = phi_i[overlap]
            phi_j_pts  = phi_j[overlap]

            # Transport j's field into i's frame
            Omega_ij = compute_inter_omega_fieldwise(phi_i_pts, phi_j_pts, generators, group_name=group)
            eta1_j_t = np.einsum("mab,mb->ma", Omega_ij, eta1_j_pts)
            eta2_j_t = np.einsum("mab,mbc,mcd->mad", Omega_ij, eta2_j_pts, Omega_ij)

            # Convert both i and Ω·j into μ, Σ for KL evaluation
            mu_i, sigma_i = natural_to_mu_sigma_batch(eta1_i_pts, eta2_i_pts, eps=log_eps)
            mu_j, sigma_j = natural_to_mu_sigma_batch(eta1_j_t, eta2_j_t, eps=log_eps)

            sigma_i = sanitize_sigma(sigma_i, eps=log_eps)
            sigma_j = sanitize_sigma(sigma_j, eps=log_eps)

            delta = mu_i - mu_j
            sigma_j_inv = np.linalg.inv(sigma_j)

            mahal = np.einsum("...i,...ij,...j->...", delta, sigma_j_inv, delta)
            trace_term = np.einsum("...ij,...ji->...", sigma_j_inv, sigma_i)
            logdet_i = safe_logdet(sigma_i, eps=log_eps)
            logdet_j = safe_logdet(sigma_j, eps=log_eps)
            kl_vals = 0.5 * (logdet_j - logdet_i - mu_i.shape[-1] + trace_term + mahal)
            kl_vals = np.where(np.isfinite(kl_vals), kl_vals, 0.0)

            kl_matrix[i, j] = float(np.mean(kl_vals))

            if return_pointwise:
                pw_field = np.zeros(mask_i.shape)
                pw_field[overlap] = kl_vals
                pointwise[(i, j)] = pw_field

    return (kl_matrix, pointwise) if return_pointwise else kl_matrix


def compute_entropy_field_from_eta(eta2_field, mask, log_eps=1e-8):
    """
    Compute per-cell entropy H[q(c)] using natural parameter η₂ = −½ Σ⁻¹

    Args:
        eta2_field : (H, W, K, K) — second natural parameter η₂
        mask       : (H, W) — boolean or float mask
        log_eps    : float — stabilizer

    Returns:
        H_field    : (H, W) — entropy values, 0 outside mask
    """
    H, W, K, _ = eta2_field.shape
    H_field = np.zeros((H, W), dtype=np.float64)

    # Compute log det(−2η₂) = log det(Sigma⁻¹)
    neg2_eta2 = -2.0 * eta2_field
    neg2_eta2 += log_eps * np.eye(K)[None, None, :, :]  # Stabilize

    for i in range(H):
        for j in range(W):
            if not mask[i, j]:
                continue
            try:
                sign, logdet = np.linalg.slogdet(neg2_eta2[i, j])
                if not np.isfinite(logdet) or sign <= 0:
                    raise np.linalg.LinAlgError
            except np.linalg.LinAlgError:
                logdet = np.nan
            H_field[i, j] = 0.5 * (K * np.log(2 * np.pi * np.e) + logdet)

    H_field[~mask] = 0.0
    return H_field


