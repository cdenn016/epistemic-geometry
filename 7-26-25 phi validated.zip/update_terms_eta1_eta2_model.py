# -*- coding: utf-8 -*-
"""
Created on Sat Jul 26 08:46:17 2025

@author: chris and christine
"""

import numpy as np
from natural_params_utils import compute_bar_eta2_qj, compute_delta_eta, grad_eta2_from_sigma_mu
from numerical_utils import safe_inv



#validated 7-25-25
def grad_eta1_pi_alignment(eta1_pi, eta2_pi, eta1_pj, eta2_pj, Omega_tilde_ij, eps=1e-8):
    """
    ∇_{η1_pi} D_KL(p_i || Ω~_ij p_j)
    = -½ · bar_eta2_pj · Δη · η2_pi⁻¹
    """
    bar_eta2_pj = compute_bar_eta2_qj(eta2_pj, Omega_tilde_ij, eps=eps)
    delta_eta   = compute_delta_eta(eta1_pi, eta2_pi, eta1_pj, eta2_pj, Omega_tilde_ij, eps=eps)
    eta2_inv_pi = safe_inv(eta2_pi, eps=eps)

    tmp = np.einsum("...ij,...j->...i", bar_eta2_pj, delta_eta)
    grad = -0.5 * np.einsum("...i,...ij->...j", tmp, eta2_inv_pi)
    return grad

#validated 7-25-25
def grad_eta1_pj_alignment(eta1_pi, eta2_pi, eta1_pj, eta2_pj, Omega_tilde_ij, eps=1e-8):
    """
    ∇_{η1_pj} D_KL(p_i || Ω~_ij p_j)
    = +½ · Ω~_ijᵀ · bar_eta2_pj · Δη · η2_pi⁻¹
    """
    bar_eta2_pj = compute_bar_eta2_qj(eta2_pj, Omega_tilde_ij, eps=eps)
    delta_eta   = compute_delta_eta(eta1_pi, eta2_pi, eta1_pj, eta2_pj, Omega_tilde_ij, eps=eps)
    eta2_inv_pi = safe_inv(eta2_pi, eps=eps)

    tmp = np.einsum("...ij,...j->...i", bar_eta2_pj, delta_eta)
    tmp2 = np.einsum("...i,...ij->...j", tmp, eta2_inv_pi)
    grad = 0.5 * np.einsum("...ji,...i->...j", Omega_tilde_ij, tmp2)
    return grad


def grad_mu_pi_alignment(eta1_pi, eta2_pi, eta1_pj, eta2_pj, Omega_tilde_ij, eps=1e-8):
    """
    Compute:
        ∂KL / ∂μ_pi = bar_eta2_pj · (η2_pi⁻¹ η1_pi − Ω~ η2_pj⁻¹ η1_pj)
    """
    bar_eta2_pj = compute_bar_eta2_qj(eta2_pj, Omega_tilde_ij, eps=eps)
    delta_eta   = compute_delta_eta(eta1_pi, eta2_pi, eta1_pj, eta2_pj, Omega_tilde_ij, eps=eps)
    grad_mu = np.einsum("...ij,...j->...i", bar_eta2_pj, delta_eta)
    return grad_mu


#===================================================================
#
#               gradients with respect to eta2
#
#==================================================================


def grad_eta2_pi_alignment(eta1_pi, eta2_pi, eta1_pj, eta2_pj, Omega_tilde_ij, eps=1e-8):
    """
    Compute:
        ∇_{η2_pi} D_KL(p_i || Ω~_ij p_j)
    """
    eta2_inv_pi = safe_inv(eta2_pi, eps=eps)
    mu_pi       = -0.5 * np.einsum("...ij,...j->...i", eta2_inv_pi, eta1_pi)
    sigma_pi    = -0.5 * eta2_inv_pi

    bar_eta2_pj = compute_bar_eta2_qj(eta2_pj, Omega_tilde_ij, eps=eps)
    grad_sigma_pi = 2.0 * eta2_pi - bar_eta2_pj

    grad_mu_pi = grad_mu_pi_alignment(
        eta1_pi, eta2_pi, eta1_pj, eta2_pj, Omega_tilde_ij, eps=eps
    )

    return grad_eta2_from_sigma_mu(grad_sigma_pi, grad_mu_pi, mu_pi, sigma_pi)


def grad_sigma_pj_alignment(eta1_pi, eta2_pi, eta1_pj, eta2_pj, Omega_tilde_ij, eps=1e-8):
    """
    Compute:
        ∇_{Σ_pj} D_KL(p_i || Ω~_ij p_j)
    """
    bar_eta2_pj = compute_bar_eta2_qj(eta2_pj, Omega_tilde_ij, eps=eps)
    delta_eta   = compute_delta_eta(eta1_pi, eta2_pi, eta1_pj, eta2_pj, Omega_tilde_ij, eps=eps)
    eta2_inv_pi = safe_inv(eta2_pi, eps=eps)

    term2 = np.einsum("...ik,...kl,...lj->...ij", bar_eta2_pj, eta2_inv_pi, bar_eta2_pj)
    outer = np.einsum("...i,...j->...ij", delta_eta, delta_eta)
    term3 = 0.5 * np.einsum("...ik,...kl,...lj->...ij", bar_eta2_pj, outer, bar_eta2_pj)

    inner = bar_eta2_pj + term2 + term3
    grad_sigma_pj = np.einsum("...ki,...ij,...jl->...kl", Omega_tilde_ij, inner, Omega_tilde_ij)
    return grad_sigma_pj
