# -*- coding: utf-8 -*-
"""
Created on Sat Jul 26 08:43:30 2025

@author: chris and christine
"""

import numpy as np
import config
from natural_params_utils import compute_bar_eta2_qj, compute_delta_eta
from numerical_utils import safe_inv
from natural_params_utils import ( grad_eta2_from_sigma_mu, 
                                  compute_bar_eta2_q_morphed,
                                  compute_bar_eta2_p_morphed,
                                  compute_delta_eta_p_Phi_q,
                                  compute_delta_eta_q_PhiTilde_p, 
                                  natural_to_mu_sigma, apply_natural_gradient_batch_eta
                                  )




#=======================================================================
#
#                 Accumulate - need to also accum p-terms
#
#===========================================================================




def accumulate_eta_gradient_belief(agent_i, agents, params):
    """
    Accumulate ∇_{η₁_q}, ∇_{η₂_q} for agent_i directly in natural parameter space
    using variational gradients:

      - Self:     KL(q_i || Φ̃ p_i)
      - Feedback: KL(p_i || Φ q_i)
      - Alignment: KL(q_i || Ω_ij q_j)   and   KL(q_k || Ω_kj q_j) for i == j

    Stores into:
        agent_i.grad_eta1_q_field
        agent_i.grad_eta2_q_field
    """
    eps = config.support_cutoff_eps
    alpha = params.get("alpha", config.alpha)
    beta  = params.get("beta", config.beta)
    lambd = params.get("lambda", config.feedback_weight)

    eta1_q = agent_i.eta1_q_field
    eta2_q = agent_i.eta2_q_field
    eta1_p = agent_i.eta1_p_field
    eta2_p = agent_i.eta2_p_field
    Phi       = agent_i.bundle_morphism_q_to_p
    Phi_tilde = agent_i.bundle_morphism_p_to_q

    # ── Self-energy: ∇_{η₁_q}, ∇_{η₂_q} KL(q || Φ̃ p) ──
    grad_eta1_self = grad_eta1_q_morphism_self(
        eta1_q, eta2_q, eta1_p, eta2_p, Phi_tilde, eps=eps
    )
    grad_eta2_self = grad_eta2_q_morphism_self(
        eta1_q, eta2_q, eta1_p, eta2_p, Phi_tilde, eps=eps
    )

    # ── Feedback: ∇_{η₁_q}, ∇_{η₂_q} KL(p || Φ q) ──
    grad_eta1_fb = grad_eta1_q_morphism_feedback(
        eta1_p, eta2_p, eta1_q, eta2_q, Phi, eps=eps
    )
    grad_eta2_fb = grad_eta2_q_morphism_feedback(
        eta1_p, eta2_p, eta1_q, eta2_q, Phi, eps=eps
    )

    # ── Alignment (i = source) ──
    grad_eta1_align = 0
    grad_eta2_align = 0
    for neighbor in agent_i.neighbors:
        agent_j = agents[neighbor["id"]]
        Omega_ij = agent_i.Omega @ agent_j.Omega_inv

        grad_eta1_align += grad_eta1_qi_alignment(
            eta1_q, eta2_q,
            agent_j.eta1_q_field, agent_j.eta2_q_field,
            Omega_ij, eps=eps
        )
        grad_eta2_align += grad_eta2_qi_alignment(
            eta1_q, eta2_q,
            agent_j.eta1_q_field, agent_j.eta2_q_field,
            Omega_ij, eps=eps
        )

    # ── Alignment (i = target q_j in q_k ‖ Ω_kj q_j) ──
    grad_eta1_align_rev = 0
    grad_eta2_align_rev = 0
    for agent_k in agents:
        for neighbor in agent_k.neighbors:
            if neighbor.get("id") == agent_i.id:
                Omega_kj = agent_k.Omega @ agent_i.Omega_inv

                grad_eta1_align_rev += grad_eta1_qj_alignment(
                    agent_k.eta1_q_field, agent_k.eta2_q_field,
                    eta1_q, eta2_q,
                    Omega_kj, eps=eps
                )
                grad_eta2_align_rev += grad_eta2_qj_alignment(
                    agent_k.eta1_q_field, agent_k.eta2_q_field,
                    eta1_q, eta2_q,
                    Omega_kj, eps=eps
                )

    # ── Combine all η₁ and η₂ gradients ──
    grad_eta1_total = (
        alpha * grad_eta1_self +
        lambd * grad_eta1_fb +
        beta * (grad_eta1_align + grad_eta1_align_rev)
    )

    grad_eta2_total = (
        alpha * grad_eta2_self +
        lambd * grad_eta2_fb +
        beta * (grad_eta2_align + grad_eta2_align_rev)
    )

    # ── Apply Fisher-preconditioned natural gradient updates ──
    mask = agent_i.mask[..., None]  # (..., 1)
    delta_eta1, delta_eta2 = apply_natural_gradient_batch_eta(
        eta1_q, eta2_q, grad_eta1_total, grad_eta2_total, mask, eps=eps
    )

    agent_i.grad_eta1_q_field += delta_eta1
    agent_i.grad_eta2_q_field += delta_eta2







#========================================================
#
#          Alignment Gradients wrt to eta1, eta2
#
#==========================================================

def grad_eta1_qi_alignment(eta1_qi, eta2_qi, eta1_qj, eta2_qj, Omega_ij, eps=1e-8):
    """
    ∇_{η1_qi} D_KL(q_i || Ω_ij q_j)
    = -½ · η2_qi⁻¹ · bar_eta2_qj · Δη
    """
    bar_eta2_qj = compute_bar_eta2_qj(eta2_qj, Omega_ij, eps=eps)
    delta_eta   = compute_delta_eta(eta1_qi, eta2_qi, eta1_qj, eta2_qj, Omega_ij, eps=eps)
    eta2_inv_qi = safe_inv(eta2_qi, eps=eps)

    # bar_eta2_qj · delta_eta
    tmp = np.einsum("...ij,...j->...i", bar_eta2_qj, delta_eta)
    # η2_qi⁻¹ · tmp
    grad = -0.5 * np.einsum("...ij,...j->...i", eta2_inv_qi, tmp)
    return grad



def grad_eta1_qj_alignment(eta1_qi, eta2_qi, eta1_qj, eta2_qj, Omega_ij, eps=1e-8):
    """
    ∇_{η1_qj} D_KL(q_i || Ω_ij q_j)
    = -½ · η2_qj⁻¹ · Ω_ijᵀ · bar_eta2_qj · Δη
    """
    bar_eta2_qj = compute_bar_eta2_qj(eta2_qj, Omega_ij, eps=eps)
    delta_eta   = compute_delta_eta(eta1_qi, eta2_qi, eta1_qj, eta2_qj, Omega_ij, eps=eps)
    eta2_inv_qj = safe_inv(eta2_qj, eps=eps)

    # Compute Ωᵀ @ bar_eta2_qj @ Δη
    tmp = np.einsum("...ij,...j->...i", bar_eta2_qj, delta_eta)
    tmp2 = np.einsum("...ji,...i->...j", Omega_ij, tmp)     # (..., K)
    grad = -0.5 * np.einsum("...ij,...j->...i", eta2_inv_qj, tmp2)
    return grad





#===================================================================
#
#               alignment gradients with respect to eta2
#
#==================================================================




def grad_eta2_qi_alignment(eta1_qi, eta2_qi, eta1_qj, eta2_qj, Omega_ij, eps=1e-8):
    """
    Full gradient:
        ∇_{η2_qi} D_KL(q_i || Ω_ij q_j)

    Steps:
      - compute ∂KL/∂Σ_i = 2η2_qi − bar_eta2_qj
      - compute ∂KL/∂μ_i using Delta-eta
      - compute μ_i, Σ_i from η
      - project into η₂ space via chain rule

    Inputs:
        eta1_qi : (..., K)
        eta2_qi : (..., K, K)
        eta1_qj : (..., K)
        eta2_qj : (..., K, K)
        Omega_ij : (..., K, K)

    Returns:
        grad_eta2_qi : (..., K, K)
    """
    eta2_inv_qi = safe_inv(eta2_qi, eps=eps)
    mu_qi = -0.5 * np.einsum("...ij,...j->...i", eta2_inv_qi, eta1_qi)
    sigma_qi = -0.5 * eta2_inv_qi

    bar_eta2_qj = compute_bar_eta2_qj(eta2_qj, Omega_ij, eps=eps)
    grad_sigma_qi = 2.0 * eta2_qi - bar_eta2_qj

    # Compute grad_mu internally
    grad_mu_qi = grad_mu_qi_alignment(
        eta1_qi, eta2_qi, eta1_qj, eta2_qj, Omega_ij, eps=eps
    )

    return grad_eta2_from_sigma_mu(grad_sigma_qi, grad_mu_qi, mu_qi, sigma_qi)

def grad_eta2_qj_alignment(
    eta1_qi, eta2_qi,
    eta1_qj, eta2_qj,
    Omega_ij,
    eps=1e-8,
):
    """
    Compute ∇_{η₂_qj} D_KL(q_i || Ω q_j) in natural parameters.

    Args:
        eta1_qi, eta2_qi : (..., K)
        eta1_qj, eta2_qj : (..., K), (..., K, K)
        Omega_ij         : (..., K, K)
        eps              : numerical stabilizer

    Returns:
        grad_eta2_qj : (..., K, K)
    """
    
    # Step 1: compute grad_mu_j (natural expression)
    bar_eta2 = compute_bar_eta2_q_morphed(eta2_qj, Omega_ij, eps=eps)
    delta_eta = compute_delta_eta(eta1_qi, eta2_qi, eta1_qj, eta2_qj, Omega_ij, eps=eps)

    grad_mu_j = -np.einsum("...ji,...i->...j", Omega_ij, np.einsum("...ij,...j->...i", bar_eta2, delta_eta))

    # Step 2: compute grad_sigma_j via derivative of KL wrt Σ_j (already known)
    mu_i, _ = natural_to_mu_sigma(eta1_qi, eta2_qi, eps=eps)
    mu_j, sigma_j = natural_to_mu_sigma(eta1_qj, eta2_qj, eps=eps)

    
    grad_sigma_j = grad_sigma_qj_alignment(mu_i, eta2_qi, mu_j, sigma_j, Omega_ij, eps=eps)


    # Step 3: chain rule to get ∇_{η₂_qj}
    return grad_eta2_from_sigma_mu(grad_sigma_j, grad_mu_j, mu_j, sigma_j)


#helpers
def grad_mu_qi_alignment(eta1_qi, eta2_qi, eta1_qj, eta2_qj, Omega_ij, eps=1e-8):
    """
    Compute:
        ∂KL / ∂μ_i = bar_eta2_qj · (η2_qi⁻¹ η1_qi − Ω η2_qj⁻¹ η1_qj)

    Returns:
        grad_mu : (..., K)
    """
    bar_eta2_qj = compute_bar_eta2_qj(eta2_qj, Omega_ij, eps=eps)
    delta_eta = compute_delta_eta(eta1_qi, eta2_qi, eta1_qj, eta2_qj, Omega_ij, eps=eps)
    grad_mu = np.einsum("...ij,...j->...i", bar_eta2_qj, delta_eta)
    return grad_mu

#helpers
def grad_sigma_qj_alignment(eta1_qi, eta2_qi, eta1_qj, eta2_qj, Omega_ij, eps=1e-8):
    """
    Compute:
        ∇_{Σ_qj} D_KL(q_i || Ω_ij q_j)

    Returns:
        grad_sigma_qj : (..., K, K)
    """
    bar_eta2_qj = compute_bar_eta2_qj(eta2_qj, Omega_ij, eps=eps)          # (..., K, K)
    delta_eta   = compute_delta_eta(eta1_qi, eta2_qi, eta1_qj, eta2_qj, Omega_ij, eps=eps)  # (..., K)
    eta2_inv_qi = safe_inv(eta2_qi, eps=eps)                                # (..., K, K)

    # term1 = bar_eta2_qj
    # term2 = bar_eta2_qj @ eta2_inv_qi @ bar_eta2_qj
    term2 = np.einsum("...ik,...kl,...lj->...ij", bar_eta2_qj, eta2_inv_qi, bar_eta2_qj)

    # term3 = ½ · bar_eta2_qj @ Δη @ Δηᵀ @ bar_eta2_qj
    outer = np.einsum("...i,...j->...ij", delta_eta, delta_eta)
    term3 = 0.5 * np.einsum("...ik,...kl,...lj->...ij", bar_eta2_qj, outer, bar_eta2_qj)

    inner = bar_eta2_qj + term2 + term3
    grad_sigma_qj = np.einsum("...ki,...ij,...jl->...kl", Omega_ij, inner, Omega_ij)
    return grad_sigma_qj


#===================================================================
#
#               feedback gradients with respect to eta1
#
#==================================================================

def grad_eta1_q_morphism_feedback(eta1_p, eta2_p, eta1_q, eta2_q, Phi, eps=1e-8):
    """
    Compute:
        ∂KL/∂η1_q = -½ η2_q⁻¹ · (Φᵀ · bar_eta2^Φ_q · Δη)

    Inputs:
        eta1_p, eta2_p : (..., K_p), (..., K_p, K_p)
        eta1_q, eta2_q : (..., K_q), (..., K_q, K_q)
        Phi            : (..., K_p, K_q)

    Returns:
        grad_eta1_q : (..., K_q)
    """
    from numerical_utils import safe_inv
    eta2_inv_q = safe_inv(eta2_q, eps=eps)

    bar_eta2_Phi_q = compute_bar_eta2_q_morphed(eta2_q, Phi, eps=eps)
    delta_eta = compute_delta_eta_p_Phi_q(eta1_p, eta2_p, eta1_q, eta2_q, Phi, eps=eps)

    tmp = np.einsum("...ij,...j->...i", bar_eta2_Phi_q, delta_eta)     # (..., K_p)
    grad_mu_q = np.einsum("...ij,...i->...j", Phi, tmp)

    grad_eta1_q = -0.5 * np.einsum("...ij,...j->...i", eta2_inv_q, grad_mu_q)
    return grad_eta1_q


def grad_eta1_p_morphism_feedback(eta1_p, eta2_p, eta1_q, eta2_q, Phi, eps=1e-8):
    """
    Compute:
        ∇_{η1_p} D_KL(p || Φ q)
        = -½ · η2_p⁻¹ · bar_eta2^Φ_q · Δη

    Inputs:
        eta1_p : (..., K_p)
        eta2_p : (..., K_p, K_p)
        eta1_q : (..., K_q)
        eta2_q : (..., K_q, K_q)
        Phi    : (..., K_p, K_q)

    Returns:
        grad_eta1_p : (..., K_p)
    """
    eta2_inv_p = safe_inv(eta2_p, eps=eps)
    bar_eta2_Phi_q = compute_bar_eta2_q_morphed(eta2_q, Phi, eps=eps)
    delta_eta = compute_delta_eta_p_Phi_q(eta1_p, eta2_p, eta1_q, eta2_q, Phi, eps=eps)

    tmp = np.einsum("...ij,...j->...i", bar_eta2_Phi_q, delta_eta)
    grad_eta1_p = -0.5 * np.einsum("...ij,...j->...i", eta2_inv_p, tmp)
    return grad_eta1_p


#===================================================================
#
#               feedback gradients with respect to eta2
#
#==================================================================


def grad_eta2_q_morphism_feedback(eta1_p, eta2_p, eta1_q, eta2_q, Phi, eps=1e-8):
    """
    Compute:
        ∇_{η2_q} D_KL(p || Φ q)
    """
    from numerical_utils import safe_inv

    eta2_inv_q = safe_inv(eta2_q, eps=eps)
    mu_q = -0.5 * np.einsum("...ij,...j->...i", eta2_inv_q, eta1_q)
    sigma_q = -0.5 * eta2_inv_q

    bar_eta2_Phi_q = compute_bar_eta2_q_morphed(eta2_q, Phi, eps=eps)
    delta_eta = compute_delta_eta_p_Phi_q(eta1_p, eta2_p, eta1_q, eta2_q, Phi, eps=eps)
    eta2_inv_p = safe_inv(eta2_p, eps=eps)

    # Three terms inside the Φᵀ(...)Φ sandwich
    term1 = -bar_eta2_Phi_q
    term2 = np.einsum("...ik,...kl,...lj->...ij", bar_eta2_Phi_q, eta2_inv_p, bar_eta2_Phi_q)
    outer = np.einsum("...i,...j->...ij", delta_eta, delta_eta)
    term3 = -0.5 * np.einsum("...ik,...kl,...lj->...ij", bar_eta2_Phi_q, outer, bar_eta2_Phi_q)

    inner = term1 + term2 + term3
    Phi_T = np.swapaxes(Phi, -1, -2)  # (H, W, K_q, K_p)

# Compute grad_sigma_q = Φᵀ · inner · Φ ∈ (H, W, K_q, K_q)
    temp = np.einsum("...ik,...kl->...il", Phi_T, inner)       # (..., K_q, K_p)
    grad_sigma_q = np.einsum("...ik,...kj->...ij", temp, Phi)  # (..., K_q, K_q)

    grad_mu_q = grad_mu_q_morphism_feedback(eta1_p, eta2_p, eta1_q, eta2_q, Phi, eps=eps)

    return grad_eta2_from_sigma_mu(grad_sigma_q, grad_mu_q, mu_q, sigma_q)

def grad_eta2_p_morphism_feedback(eta1_p, eta2_p, eta1_q, eta2_q, Phi, eps=1e-8):
    """
    Compute:
        ∇_{η2_p} D_KL(p || Φ q)
    """
    from numerical_utils import safe_inv

    eta2_inv_p = safe_inv(eta2_p, eps=eps)
    mu_p = -0.5 * np.einsum("...ij,...j->...i", eta2_inv_p, eta1_p)
    sigma_p = -0.5 * eta2_inv_p

    bar_eta2_Phi_q = compute_bar_eta2_q_morphed(eta2_q, Phi, eps=eps)
    grad_sigma_p = 2.0 * eta2_p - bar_eta2_Phi_q

    grad_mu_p = grad_mu_p_morphism_feedback(eta1_p, eta2_p, eta1_q, eta2_q, Phi, eps=eps)

    return grad_eta2_from_sigma_mu(grad_sigma_p, grad_mu_p, mu_p, sigma_p)





def grad_mu_q_morphism_feedback(eta1_p, eta2_p, eta1_q, eta2_q, Phi, eps=1e-8):
    """
    Compute:
        ∂KL/∂μ_q = Φᵀ · bar_eta2^Φ_q · Δη

    Returns:
        grad_mu_q : (..., K_q)
    """
    bar_eta2_Phi_q = compute_bar_eta2_q_morphed(eta2_q, Phi, eps=eps)
    delta_eta = compute_delta_eta_p_Phi_q(eta1_p, eta2_p, eta1_q, eta2_q, Phi, eps=eps)
    tmp = np.einsum("...ij,...j->...i", bar_eta2_Phi_q, delta_eta)
    Phi_T = np.swapaxes(Phi, -1, -2)   # (..., K_q, K_p)
    grad_mu_q = np.einsum("...ij,...j->...i", Phi_T, tmp)

    return grad_mu_q


def grad_mu_p_morphism_feedback(eta1_p, eta2_p, eta1_q, eta2_q, Phi, eps=1e-8):
    """
    Compute:
        ∂KL/∂μ_p = bar_eta2^Φ_q · Δη

    Returns:
        grad_mu_p : (..., K_p)
    """
    bar_eta2_Phi_q = compute_bar_eta2_q_morphed(eta2_q, Phi, eps=eps)
    delta_eta = compute_delta_eta_p_Phi_q(eta1_p, eta2_p, eta1_q, eta2_q, Phi, eps=eps)
    grad_mu_p = np.einsum("...ij,...j->...i", bar_eta2_Phi_q, delta_eta)
    return grad_mu_p






#===============================================
#
#
#
#=======================================

def grad_eta1_q_morphism_self(eta1_q, eta2_q, eta1_p, eta2_p, Phi_tilde, eps=1e-8):
    """
    ∇_{η1_q} D_KL(q || Φ~ p)
    = -½ η2_q⁻¹ · bar_eta2^Φ~_p · Δη
    """
    eta2_inv_q = safe_inv(eta2_q, eps=eps)
    bar_eta2 = compute_bar_eta2_p_morphed(eta2_p, Phi_tilde, eps=eps)
    delta_eta = compute_delta_eta_q_PhiTilde_p(eta1_q, eta2_q, eta1_p, eta2_p, Phi_tilde, eps=eps)

    tmp = np.einsum("...ij,...j->...i", bar_eta2, delta_eta)
    return -0.5 * np.einsum("...ij,...j->...i", eta2_inv_q, tmp)


def grad_eta1_p_morphism_self(eta1_q, eta2_q, eta1_p, eta2_p, Phi_tilde, eps=1e-8):
    """
    ∇_{η1_p} D_KL(q || Φ~ p)
    = +½ η2_p⁻¹ · Φ~ᵀ · bar_eta2^Φ~_p · Δη
    """
    eta2_inv_p = safe_inv(eta2_p, eps=eps)
    bar_eta2 = compute_bar_eta2_p_morphed(eta2_p, Phi_tilde, eps=eps)
    delta_eta = compute_delta_eta_q_PhiTilde_p(eta1_q, eta2_q, eta1_p, eta2_p, Phi_tilde, eps=eps)

    tmp = np.einsum("...ij,...j->...i", bar_eta2, delta_eta)
    tmp2 = np.einsum("...ji,...i->...j", Phi_tilde, tmp)
    return 0.5 * np.einsum("...ij,...j->...i", eta2_inv_p, tmp2)

def grad_eta2_q_morphism_self(
    eta1_q, eta2_q,
    eta1_p, eta2_p,
    Phi_tilde,
    eps=1e-8
):
    """
    ∇_{η₂_q} KL(q || Φ̃ p) in natural coordinates.

    Uses:
        ∇_Σ_q = η̂₂^{Φ̃}_p - η₂_q
        ∇_μ_q = η̂₂^{Φ̃}_p Δη

    Then:
        ∇_{η₂_q} = -½ Σ_q [∇_Σ_q + (∇_μ_q ⊗ μ_q)] Σ_q
    """
    

    bar_eta2 = compute_bar_eta2_p_morphed(eta2_p, Phi_tilde, eps=eps)
    delta_eta = compute_delta_eta_q_PhiTilde_p(eta1_q, eta2_q, eta1_p, eta2_p, Phi_tilde, eps=eps)

    # ∇_Σ_q = η̂₂_p - η₂_q
    grad_sigma = bar_eta2 - eta2_q

    # ∇_μ_q = η̂₂_p · Δη
    grad_mu = np.einsum("...ij,...j->...i", bar_eta2, delta_eta)

    # Convert to ∇_{η₂_q}
    mu_q, sigma_q = natural_to_mu_sigma(eta1_q, eta2_q, eps=eps)
    return grad_eta2_from_sigma_mu(grad_sigma, grad_mu, mu_q, sigma_q)



def grad_eta2_p_morphism_self(
    eta1_q, eta2_q,
    eta1_p, eta2_p,
    Phi_tilde,
    eps=1e-8
):
    """
    ∇_{η₂_p} KL(q || Φ̃ p) using full chain rule:
        First compute:
            ∇_μ_p     = - Φ̃ᵀ η̂₂_p Δη
            ∇_Σ_p     = Φ̃ᵀ [ η̂₂_p η₂_p⁻¹ η̂₂_p − η̂₂_p − ½ η̂₂_p Δη Δηᵀ η̂₂_p ] Φ̃
        Then:
            ∇_{η₂_p} = -½ Σ_p [∇_Σ_p + (∇_μ_p ⊗ μ_p)] Σ_p
    """
    

    bar_eta2 = compute_bar_eta2_p_morphed(eta2_p, Phi_tilde, eps=eps)  # η̂₂^Φ̃_p
    delta_eta = compute_delta_eta_q_PhiTilde_p(eta1_q, eta2_q, eta1_p, eta2_p, Phi_tilde, eps=eps)

    # --- Mahalanobis term
    delta_outer = np.einsum("...i,...j->...ij", delta_eta, delta_eta)
    mahal_term = 0.5 * np.einsum("...ik,...kl,...lj->...ij",
                                 bar_eta2, delta_outer, bar_eta2)

    # --- Composite term
    inv_eta2_p = safe_inv(eta2_p, eps=eps)
    triple_term = np.einsum("...ik,...kl,...lj->...ij", bar_eta2, inv_eta2_p, bar_eta2)

    grad_sigma = np.einsum("...ik,...kl,...lj->...ij", Phi_tilde.swapaxes(-1, -2),
                           triple_term - bar_eta2 - mahal_term,
                           Phi_tilde)

    # --- Gradient wrt μ_p
    grad_mu = -np.einsum("...ji,...j->...i", Phi_tilde, np.einsum("...ij,...j->...i", bar_eta2, delta_eta))

    # --- Convert to η₂_p via chain rule
    mu_p, sigma_p = natural_to_mu_sigma(eta1_p, eta2_p, eps=eps)
    return grad_eta2_from_sigma_mu(grad_sigma, grad_mu, mu_p, sigma_p)
