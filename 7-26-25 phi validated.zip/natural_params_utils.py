# -*- coding: utf-8 -*-
"""
Created on Thu Jul 24 17:48:40 2025

@author: chris and christine
"""

import numpy as np
from numerical_utils import safe_inv, sanitize_sigma




#Validated 7-26-25
def compute_bar_eta2_qj(eta2_qj, Omega_ij, eps=1e-8):
    """
    Compute:
        bar_eta2_qj = (Omega_ij · eta2_qj⁻¹ · Omega_ijᵀ)⁻¹
    Shape:
        eta2_qj   : (..., K, K)
        Omega_ij  : (..., K, K)
    Returns:
        bar_eta2_qj : (..., K, K)
    """
    eta2_inv = safe_inv(eta2_qj, eps=eps)                           # (..., K, K)
    tmp = np.einsum("...ik,...kl->...il", Omega_ij, eta2_inv)       # Ω η2⁻¹
    pushed = np.einsum("...ij,...jk->...ik", tmp, Omega_ij.swapaxes(-1, -2))
    bar_eta2_qj = safe_inv(pushed, eps=eps)
    return bar_eta2_qj

#VALIDATED 7-26-25
def compute_delta_eta(eta1_qi, eta2_qi, eta1_qj, eta2_qj, Omega_ij, eps=1e-8):
    """
    Compute:
        Δη = η2_qi⁻¹ · η1_qi − Ω · η2_qj⁻¹ · η1_qj
    Shape:
        eta1_qi, eta1_qj : (..., K)
        eta2_qi, eta2_qj : (..., K, K)
        Omega_ij         : (..., K, K)
    Returns:
        delta_eta : (..., K)
    """
    eta2_inv_qi = safe_inv(eta2_qi, eps=eps)                        # (..., K, K)
    eta2_inv_qj = safe_inv(eta2_qj, eps=eps)                        # (..., K, K)

    term_i = np.einsum("...ij,...j->...i", eta2_inv_qi, eta1_qi)    # η2_qi⁻¹ · η1_qi
    term_j = np.einsum("...ij,...j->...i", eta2_inv_qj, eta1_qj)    # η2_qj⁻¹ · η1_qj
    term_j_push = np.einsum("...ij,...j->...i", Omega_ij, term_j)   # Ω · η2_qj⁻¹ · η1_qj

    return term_i - term_j_push                                     # (..., K)


def compute_bar_eta2_q_morphed(eta2_q, Phi, eps=1e-8):
    """
    Compute bar_eta2^Φ_q = (Φ η2_q⁻¹ Φᵀ)⁻¹

    Shapes:
        eta2_q : (..., K_q, K_q)
        Phi    : (..., K_p, K_q)
    Returns:
        bar_eta2_q_Phi : (..., K_p, K_p)
    """
    eta2_inv = safe_inv(eta2_q, eps=eps)
    pushed = np.einsum("...ik,...kl->...il", Phi, eta2_inv)             # (..., K_p, K_q)
    pushed = np.einsum("...ij,...jk->...ik", pushed, Phi.swapaxes(-1, -2))  # (..., K_p, K_p)
    return safe_inv(pushed, eps=eps)


def compute_delta_eta_p_Phi_q(eta1_p, eta2_p, eta1_q, eta2_q, Phi, eps=1e-8):
    """
    Compute Δη = η2_p⁻¹ η1_p − Φ η2_q⁻¹ η1_q

    Returns:
        delta_eta : (..., K_p)
    """
    eta2_inv_p = safe_inv(eta2_p, eps=eps)
    eta2_inv_q = safe_inv(eta2_q, eps=eps)

    term_p = np.einsum("...ij,...j->...i", eta2_inv_p, eta1_p)
    term_q = np.einsum("...ij,...j->...i", eta2_inv_q, eta1_q)
    term_q_push = np.einsum("...ij,...j->...i", Phi, term_q)

    return term_p - term_q_push

def compute_bar_eta2_p_morphed(eta2_p, Phi_tilde, eps=1e-8):
    """
    Compute bar_eta2^Φ~_p = (Φ~ η2_p⁻¹ Φ~ᵀ)⁻¹

    Shapes:
        eta2_p     : (..., K_p, K_p)
        Phi_tilde  : (..., K_q, K_p)
    Returns:
        bar_eta2_p_PhiTilde : (..., K_q, K_q)
    """
    eta2_inv = safe_inv(eta2_p, eps=eps)
    pushed = np.einsum("...ik,...kl->...il", Phi_tilde, eta2_inv)
    pushed = np.einsum("...ij,...jk->...ik", pushed, Phi_tilde.swapaxes(-1, -2))
    return safe_inv(pushed, eps=eps)


def compute_delta_eta_q_PhiTilde_p(eta1_q, eta2_q, eta1_p, eta2_p, Phi_tilde, eps=1e-8):
    """
    Compute Δη = η2_q⁻¹ η1_q − Φ~ η2_p⁻¹ η1_p

    Returns:
        delta_eta : (..., K_q)
    """
    eta2_inv_q = safe_inv(eta2_q, eps=eps)
    eta2_inv_p = safe_inv(eta2_p, eps=eps)

    term_q = np.einsum("...ij,...j->...i", eta2_inv_q, eta1_q)
    term_p = np.einsum("...ij,...j->...i", eta2_inv_p, eta1_p)
    term_p_push = np.einsum("...ji,...i->...j", Phi_tilde, term_p)  # Φ~ᵀ · (η2_p⁻¹ η1_p)

    return term_q - term_p_push

#==================================================
#
#
#$
#===============================================

def grad_eta2_from_sigma_mu(
    grad_sigma,  # ∂L/∂Σ — shape (..., K, K)
    grad_mu,     # ∂L/∂μ — shape (..., K)
    mu,          # μ     — shape (..., K)
    sigma,       # Σ     — shape (..., K, K)
):
    """
    Compute:
        ∂L/∂η₂ = -½ Σ [∂L/∂Σ + (∂L/∂μ ⊗ μ)] Σ

    Returns:
        grad_eta2 : (..., K, K)
    """
    outer = np.einsum("...i,...j->...ij", grad_mu, mu)
    total = grad_sigma + outer
    grad_eta2 = -0.5 * np.einsum("...ik,...kl,...lj->...ij", sigma, total, sigma)
    return grad_eta2




def convert_mu_sigma_grads_to_eta_grads(mu, sigma, grad_mu, grad_sigma, eps=1e-8):
    """
    Convert gradients ∂KL/∂μ and ∂KL/∂Σ to ∂KL/∂η₁ and ∂KL/∂η₂.

    Args:
        mu         : (..., K)
        sigma      : (..., K, K)
        grad_mu    : (..., K)
        grad_sigma : (..., K, K)
        eps        : regularization constant for inversion

    Returns:
        grad_eta1  : (..., K)
        grad_eta2  : (..., K, K)
    """
    sigma_inv = safe_inv(sigma, eps=eps)

    # ∂KL / ∂η₁ = Σ ∂KL / ∂μ
    grad_eta1 = np.einsum("...ij,...j->...i", sigma, grad_mu)

    # Outer product μ μᵀ
    mu_outer = np.einsum("...i,...j->...ij", mu, mu)

    # ∂KL / ∂η₂ = −½ Σ ( ∂KL / ∂Σ + ∂KL/∂μ ⊗ μ ) Σ
    grad_eta2 = np.einsum("...ik,...kl,...lj->...ij", sigma, grad_sigma + mu_outer, sigma)
    grad_eta2 *= -0.5

    return grad_eta1, grad_eta2


def mu_sigma_to_natural(mu, sigma, eps=1e-8):
    sigma_inv = safe_inv(sigma, eps)
    eta1 = np.einsum('...ij,...j->...i', sigma_inv, mu)
    eta2 = -0.5 * sigma_inv
    return eta1, eta2

def natural_to_mu_sigma(eta1, eta2, eps=1e-8):
    sigma_inv = -2.0 * eta2
    sigma = safe_inv(sigma_inv, eps)
    mu = np.einsum('...ij,...j->...i', sigma, eta1)
    return mu, sigma



def compute_mu_sigma_from_natural(eta1: np.ndarray, eta2: np.ndarray, eps: float = 1e-8):
    """
    Convert natural parameters (η₁, η₂) to mean (μ) and covariance (Σ) for multivariate Gaussian.

    η₁ = Σ⁻¹ μ
    η₂ = -0.5 Σ⁻¹

    Args:
        eta1 : (..., K)
        eta2 : (..., K, K)
        eps  : regularization parameter to ensure SPD safety

    Returns:
        mu    : (..., K)
        sigma : (..., K, K)
    """
    # Invert η₂ to recover Σ
    sigma_inv = -2.0 * eta2
    sigma = safe_inv(sanitize_sigma(sigma_inv, eps=eps), eps=eps)

    # Recover μ = Σ η₁
    mu = np.einsum("...ij,...j->...i", sigma, eta1)

    return mu, sigma

def natural_to_mu_sigma(eta1, eta2, eps=1e-8):
    """
    Convert natural parameters η₁, η₂ to (μ, Σ) for multivariate Gaussian.

    η₁ = Σ⁻¹ μ
    η₂ = −½ Σ⁻¹  ⇒  Σ = −½ η₂⁻¹

    Returns:
        μ    : (..., K)
        Σ    : (..., K, K)
    """
    from numerical_utils import safe_inv

    eta2 = np.where(np.abs(eta2) < eps, eps, eta2)  # stabilize
    Sigma = -0.5 * safe_inv(eta2, eps=eps)
    mu = np.einsum("...ij,...j->...i", Sigma, eta1)
    return mu, Sigma



def apply_natural_gradient_batch_eta(
    eta1, eta2, d_eta1, d_eta2, mask, eps=1e-8
):
    """
    Apply natural gradient preconditioning for η₁ and η₂:
        δη₁ = Σ ⋅ ∇η₁
        δη₂ = 4 Σ ⋅ ∇η₂ ⋅ Σ

    Args:
        eta1      : (..., K)
        eta2      : (..., K, K)
        d_eta1    : (..., K)
        d_eta2    : (..., K, K)
        mask      : (..., 1) or (...,)
        eps       : stabilizer for Σ inversion

    Returns:
        delta_eta1 : (..., K)
        delta_eta2 : (..., K, K)
    """
    # Convert η₂ → Σ
    _, sigma = natural_to_mu_sigma_batch(eta1, eta2, eps=eps)  # (..., K, K)

    # Natural gradient for η₁: δη₁ = Σ ⋅ ∇η₁
    delta_eta1 = np.einsum("...ij,...j->...i", sigma, d_eta1)

    # Natural gradient for η₂: δη₂ = 4 Σ ⋅ ∇η₂ ⋅ Σ
    tmp = np.einsum("...ij,...jk->...ik", sigma, d_eta2)
    delta_eta2 = 4 * np.einsum("...ij,...jk->...ik", tmp, sigma)

    # Apply mask
    if mask.ndim == eta1.ndim:  # shape (..., K)
        mask_eta1 = mask
        mask_eta2 = mask[..., None]
    else:
        mask_eta1 = mask[..., None]
        mask_eta2 = mask[..., None, None]

    delta_eta1 *= mask_eta1
    delta_eta2 *= mask_eta2

    return delta_eta1, delta_eta2


def natural_to_mu_sigma_batch(eta1, eta2, eps=1e-8):
    """
    Convert natural parameters (η₁, η₂) to (μ, Σ) in batch.

    η₁ = Σ⁻¹ μ
    η₂ = −½ Σ⁻¹

    Args:
        eta1 : (..., K)
        eta2 : (..., K, K) — symmetric
        eps  : float, SPD regularization

    Returns:
        mu    : (..., K)
        sigma : (..., K, K)
    """
    # Invert: η₂ = −½ Σ⁻¹  ⇒  Σ = (−½ η₂)⁻¹
    sigma_inv = -2.0 * eta2
    sigma = safe_inv(sigma_inv, eps=eps)

    # μ = Σ η₁
    mu = np.einsum("...ij,...j->...i", sigma, eta1)
    return mu, sigma
