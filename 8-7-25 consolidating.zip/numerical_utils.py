# -*- coding: utf-8 -*-
"""
Created on Sun Jul 13 13:06:16 2025

@author: chris and christine
"""
import sys
import numpy as np
import warnings
from collections import defaultdict
from joblib import Parallel, delayed
from numpy.linalg import LinAlgError, slogdet  # ✅ Needed for exception handling
import config
from scipy.linalg import logm  # Only if safe_logm is used
import io
import contextlib


# Global counters
fallback_counter = defaultdict(int)

#=======================================
#
#         Reporting/Logging
#
#======================================



def safe_inv(Sigma, eps=1e-10, max_eig=None, debug=False):
    """
    Relaxed safe inverse of symmetric positive-definite matrix Σ.

    Clips only *small* eigenvalues to prevent explosion.
    Allows large eigenvalues (unless max_eig is provided).
    Keeps fallback in case of failure.

    Args:
        Sigma     : (..., K, K) batch of SPD or NSD matrices (neg-def allowed too)
        eps       : minimal eigenvalue magnitude for stability
        max_eig   : if not None, clips large eigenvalues
        debug     : diagnostics

    Returns:
        Sigma_inv : (..., K, K)
    """
   

    try:
        eigvals, eigvecs = np.linalg.eigh(Sigma)

        if debug:
            print(f"[safe_inv] raw eig min={eigvals.min():.2e}, max={eigvals.max():.2e}")

        # ─── Clip small eigenvalues from below ───
        eigvals_clipped = np.clip(eigvals, eps, max_eig) if max_eig else np.maximum(eigvals, eps)

        inv_eigvals = 1.0 / eigvals_clipped
        Sigma_inv = np.einsum("...ik,...k,...jk->...ij", eigvecs, inv_eigvals, eigvecs)

        # Symmetrize for safety
        Sigma_inv = 0.5 * (Sigma_inv + np.swapaxes(Sigma_inv, -1, -2))
        return np.nan_to_num(Sigma_inv, nan=eps, posinf=eps, neginf=eps)

    except LinAlgError:
        if debug:
            print("[safe_inv] LinAlgError — fallback to scaled identity")
        K = Sigma.shape[-1]
        fallback = 1e2
        return np.eye(K, dtype=Sigma.dtype) * fallback

    
    
  



def safe_batch_inverse(S, name="Σ", mask=None):
    """
    Inverts (H, W, K, K) SPD field with fallback and optional mask.
    """
    H, W, K, _ = S.shape
    eye_K = np.eye(K, dtype=S.dtype)
    inv_S = np.zeros_like(S)

    flat_S = S.reshape(-1, K, K)
    flat_mask = mask.reshape(-1) if mask is not None else np.ones(H * W, dtype=bool)

    for idx in range(H * W):
        if not flat_mask[idx]:
            inv_S.reshape(-1, K, K)[idx] = eye_K
            continue
        try:
            inv_S.reshape(-1, K, K)[idx] = np.linalg.inv(flat_S[idx])
        except np.linalg.LinAlgError:
            inv_S.reshape(-1, K, K)[idx] = eye_K
            if config.debug:
                i, j = divmod(idx, W)
                print(f"[WARN] Inversion failed at ({i},{j}) for {name} — using identity")

    return inv_S












def sanitize_eta2(eta2, eps=None, floor=None, debug=False):
    """
    Intermediate sanitization: mild spectrum clipping + trace normalization.
    """
    import numpy as np
    import config
    from numpy.linalg import norm

    if eps is None:
        eps = getattr(config, "eta2_min_eigval", -1e-6)
    if floor is None:
        floor = getattr(config, "eta2_floor", -1e-6)
    target_trace = getattr(config, "eta2_target_trace", -eta2.shape[-1])
    max_norm = getattr(config, "eta2_max_norm", 50)

    # 1. Symmetrize
    eta2_sym = 0.5 * (eta2 + np.swapaxes(eta2, -1, -2))

    # 2. Eigendecomposition
    eigvals, eigvecs = np.linalg.eigh(eta2_sym)

    # 3. Clip eigenvalues [lower_clip, upper_clip]
    lower_clip = floor
    upper_clip = min(floor, eps)
    eigvals = np.clip(eigvals, lower_clip, upper_clip)

    # 4. Rescale to match target trace
    trace = np.sum(eigvals, axis=-1, keepdims=True)
    scale = target_trace / np.where(np.abs(trace) < 1e-8, 1e-8, trace)
    eigvals *= scale

    # 5. Reconstruct
    eta2_sanitized = np.matmul(
        eigvecs * eigvals[..., None, :],
        np.swapaxes(eigvecs, -1, -2)
    )

    # 6. Final symmetrization + norm clip
    eta2_sanitized = 0.5 * (eta2_sanitized + np.swapaxes(eta2_sanitized, -1, -2))
    if max_norm is not None:
        frob = norm(eta2_sanitized, axis=(-2, -1), keepdims=True)
        scale = np.minimum(1.0, max_norm / np.maximum(frob, 1e-8))
        eta2_sanitized *= scale

    return np.nan_to_num(eta2_sanitized, nan=floor, posinf=floor, neginf=floor)








def soft_clip_phi_norm(phi: np.ndarray, max_norm: float = np.pi, eps: float = 1e-8) -> np.ndarray:
    """
    Smoothly compress φ ∈ ℝᵈ to have norm ≤ max_norm, with soft decay and stable transition.

    Args:
        phi:      (..., d) Lie algebra field at each point
        max_norm: float, maximum allowed norm
        eps:      float, safety margin for zero division

    Returns:
        φ_clipped: (..., d) compressed φ with ‖φ‖ ≤ max_norm
    """
    norm = np.linalg.norm(phi, axis=-1, keepdims=True)  # (..., 1)
    scale = np.where(norm > max_norm, max_norm / (norm + eps), 1.0)  # (..., 1)
    return phi * scale  # (..., d)




def log_fallback(tag: str, msg: str, count_key: str = None, error: bool = False):
    """
    Standardized fallback logger.

    Args:
        tag       : str — context tag (e.g. 'safe_inv', 'logm', etc.)
        msg       : str — fallback message
        count_key : str — key for fallback_counter increment
        error     : bool — whether to raise RuntimeError (if fail_on_fallback)

    Behavior:
        - Increments fallback counter
        - Warns or raises
        - Flushes stdout
    """
    full_msg = f"[{tag}] {msg}"

    if count_key:
        fallback_counter[count_key] += 1
        full_msg = f"[{tag}] Fallback #{fallback_counter[count_key]}: {msg}"

    if getattr(config, "fail_on_fallback", False) or error:
        raise RuntimeError(full_msg)
    else:
        warnings.warn(full_msg, RuntimeWarning)
        sys.stdout.flush()


        
#====================================================
#
#                 Safety Ops
#
#=====================================================

def safe_omega_inv(M, eps=1e-10, debug=False):
    """
    Safely invert an SO(3) matrix via transpose, with validation and fallback.

    Args:
        M      : (..., K, K) matrix expected to be in SO(3)
        eps    : numerical tolerance
        debug  : if True, print diagnostic info

    Returns:
        M_inv  : (..., K, K) inverse (i.e., transpose), or identity fallback
    """
    import numpy as np

    try:
        # ───── Check shape and square ─────
        assert M.shape[-1] == M.shape[-2], "Matrix is not square"
        K = M.shape[-1]

        # ───── Check if orthogonal: M Mᵀ ≈ I ─────
        M_T = np.swapaxes(M, -1, -2)
        identity = np.eye(K, dtype=M.dtype)
        approx_I = np.matmul(M, M_T)

        if not np.all(np.isfinite(M)):
            raise ValueError("Non-finite values in Ω")

        deviation = np.linalg.norm(approx_I - identity, axis=(-2, -1))
        if np.any(deviation > eps):
            raise ValueError(f"Ω not orthogonal (‖MMᵀ − I‖ > {eps})")

        return M_T  # safe inverse for SO(3)

    except Exception as e:
        if debug:
            print(f"[safe_omega_inv] fallback: {str(e)}")
        log_fallback("safe_omega_inv", str(e), count_key="omega_inv")
        return np.eye(M.shape[-1], dtype=M.dtype)

def _sanitize_one_sigma_NEW(S, eps=1e-8, floor=1e-10, debug=False):
    """
    Mild SPD enforcement: symmetrize and clip small/negative eigenvalues just above zero.

    Returns:
        (Σ_sanitized, clipped_flag)
    """
    import numpy as np
    S = 0.5 * (S + S.T)

    if not np.all(np.isfinite(S)):
        if debug:
            print("[sanitize_sigma] NaNs or Infs detected — fallback to floor*I")
        return np.eye(S.shape[0]) * floor, True

    try:
        eigvals, eigvecs = np.linalg.eigh(S)
    except np.linalg.LinAlgError:
        if debug:
            print("[sanitize_sigma] Eigendecomposition failed — fallback to floor*I")
        return np.eye(S.shape[0]) * floor, True

    # Mild floor — allow small eigenvalues unless dangerously close to zero
    min_safe = max(eps, floor)
    clipped = np.any(eigvals < min_safe)
    eigvals_clipped = np.clip(eigvals, min_safe, None)

    if clipped:
        S = eigvecs @ np.diag(eigvals_clipped) @ eigvecs.T
        S = 0.5 * (S + S.T)
        if debug:
            print(f"[sanitize_sigma] eigvals min={eigvals.min():.3e} → clipped to ≥ {min_safe:.3e}")

    return S, clipped



def sanitize_sigma_NEW(Sigma, eps=1e-8, debug=False, n_jobs=None, parallel_threshold=1000):
    """
    Relaxed SPD sanitization for batches of Σ matrices.

    Allows very small positive eigenvalues; fallback only if invalid.

    Returns:
        Sanitized (..., K, K) SPD matrices
    """
    import numpy as np
    shape = Sigma.shape
    flat_sigma = Sigma.reshape(-1, shape[-2], shape[-1])
    n_total = flat_sigma.shape[0]

    if n_jobs is None:
        n_jobs = getattr(config, "num_cores", 1)

    if n_total < parallel_threshold or n_jobs == 1:
        results = [_sanitize_one_sigma(S, eps, debug) for S in flat_sigma]
    else:
        from joblib import Parallel, delayed
        results = Parallel(n_jobs=n_jobs)(
            delayed(_sanitize_one_sigma)(S, eps, debug) for S in flat_sigma
        )

    Sigma_out, clipped_flags = zip(*results)
    if debug:
        n_clipped = sum(clipped_flags)
        if n_clipped > 0:
            print(f"[sanitize_sigma] Clipped {n_clipped}/{n_total} matrices to SPD (eps={eps:.2e})")

    return np.stack(Sigma_out, axis=0).astype(Sigma.dtype).reshape(shape)



def _sanitize_one_sigma(S, eps=1e-2, debug=False):
    """
    Ensure a single Σ is symmetric positive-definite (SPD).
    Returns: (Σ_sanitized, clipped_flag)
    """
    S = 0.5 * (S + S.T)

    if not np.all(np.isfinite(S)):
        if debug:
            print("[sanitize_sigma] NaNs or Infs detected — replacing with eps*I")
        return np.eye(S.shape[0]) * eps, True

    try:
        eigvals, eigvecs = np.linalg.eigh(S)
    except np.linalg.LinAlgError:
        if debug:
            print("[sanitize_sigma] Eigendecomposition failed — replacing with eps*I")
        return np.eye(S.shape[0]) * eps, True

    clipped = np.any(eigvals < eps)
    eigvals_clipped = np.clip(eigvals, eps, None)

    if clipped:
        S = eigvecs @ np.diag(eigvals_clipped) @ eigvecs.T
        S = 0.5 * (S + S.T)
        if debug:
            print(f"[sanitize_sigma] eigvals min={eigvals.min():.3e} --> clipped to >= {eps:.3e}")

    return S, clipped

def sanitize_sigma(Sigma, eps=1e-2, debug=False, n_jobs=None, parallel_threshold=50):
    """
    Sanitize a batch of Σ matrices to ensure SPD structure.

    Args:
        Sigma: (..., K, K) ndarray
        eps: minimum eigenvalue threshold
        debug: print summary and per-matrix diagnostics if True
        n_jobs: number of parallel jobs (defaults to config.num_cores)
        parallel_threshold: minimum number of matrices to enable parallelism

    Returns:
        Sanitized (..., K, K) array of SPD matrices
    """
    shape = Sigma.shape
    flat_sigma = Sigma.reshape(-1, shape[-2], shape[-1])
    n_total = flat_sigma.shape[0]

    if n_jobs is None:
        n_jobs = getattr(config, "num_cores", 1)

    if n_total < parallel_threshold or n_jobs == 1:
        results = [_sanitize_one_sigma(S, eps, debug) for S in flat_sigma]
    else:
        with Parallel(n_jobs=n_jobs) as parallel:
            results = parallel(delayed(_sanitize_one_sigma)(S, eps, debug) for S in flat_sigma)

    Sigma_out, clipped_flags = zip(*results)
    if debug:
        n_clipped = sum(clipped_flags)
        if n_clipped > 0:
            print(f"[sanitize_sigma] Clipped {n_clipped}/{n_total} matrices to SPD (eps={eps:.2e})")
            
    return np.stack(Sigma_out, axis=0).astype(Sigma.dtype).reshape(shape)



def safe_logm(M, fallback_value=None, imag_tol=1e-10, context="Ω"):
    """
    Suppress logm's internal stderr output and check imag part manually.
    """
    from numerical_utils import log_fallback  # Ensure this exists

    try:
        # Suppress logm's stderr output
        with io.StringIO() as buf, contextlib.redirect_stderr(buf):
            logM = logm(M)

        imag_norm = np.linalg.norm(np.imag(logM), ord="fro")
        if imag_norm > imag_tol:
            log_fallback("safe_logm", f"{context}: ‖Im(logm)‖={imag_norm:.2e} > tol={imag_tol}")
        return np.real_if_close(logM, tol=imag_tol)

    except Exception as e:
        log_fallback("safe_logm", f"{context}: logm failed ({e})", count_key="safe_logm")
        K = M.shape[-1]
        return fallback_value if fallback_value is not None else np.zeros((K, K), dtype=M.dtype)




def safe_logdet(Sigma, eps=1e-8, alpha=1e-2, clip_range=(-1e3, 1e3)):
    """
    Safe computation of logdet(Sigma) with fallback and stabilization.
    
    Args:
        Sigma : (..., K, K) positive semi-definite matrices
        eps   : float, small stabilizer for numerical safety
        alpha : float, trace-based fallback scaling
        clip_range : tuple (min, max) to clip extreme logdet values

    Returns:
        logdet : (...) ndarray
    """
    

    K = Sigma.shape[-1]
    batch_shape = Sigma.shape[:-2]
    eye = eps * np.eye(K, dtype=Sigma.dtype)
    eye = eye.reshape((1,) * len(batch_shape) + (K, K))
    Sigma_reg = Sigma + eye

    try:
        # Attempt slogdet
        sign, ld = slogdet(Sigma_reg)
        bad = (sign <= 0) | ~np.isfinite(ld)
        if not np.any(bad):
            return np.clip(ld, *clip_range)
    except LinAlgError:
        bad = np.ones(batch_shape, dtype=bool)

    # Fallback: trace-based log surrogate
    trace = np.trace(Sigma, axis1=-2, axis2=-1)  # (...)
    surrogate = alpha * (trace / K + eps)
    fallback_ld = K * np.log(surrogate)

    # Optional: log failure
    log_fallback("safe_logdet", "fallback triggered", count_key="safe_logdet")

    # Return mixed result
    ld_final = np.where(bad, fallback_ld, ld)
    return np.clip(ld_final, *clip_range)



# ─── PATCH: safe_logm (relaxed) ───────────────────────────────────────────────
def safe_logmNEW(M, fallback_value=None, imag_tol=1e-6, context="Ω"):
    """
    Compute logm(M) with stderr suppression and imaginary-part safety.
    More relaxed version: allows larger Im parts before fallback.
    """
    import io
    import contextlib
    from scipy.linalg import logm
    from numerical_utils import log_fallback  # ensure this exists

    try:
        with io.StringIO() as buf, contextlib.redirect_stderr(buf):
            logM = logm(M)

        imag_norm = np.linalg.norm(np.imag(logM), ord="fro")
        if imag_norm > imag_tol:
            log_fallback("safe_logm", f"{context}: ‖Im(logm)‖={imag_norm:.2e} > tol={imag_tol}")
        return np.real_if_close(logM, tol=imag_tol)

    except Exception as e:
        log_fallback("safe_logm", f"{context}: logm failed ({e})", count_key="safe_logm")
        K = M.shape[-1]
        return fallback_value if fallback_value is not None else np.zeros((K, K), dtype=M.dtype)



# ─── PATCH: safe_logdet (relaxed) ─────────────────────────────────────────────
def safe_logdet_NEW(Sigma, eps=1e-10, alpha=1e-1, clip_range=(-1e5, 1e5)):
    """
    Safe computation of logdet(Sigma), fallback to surrogate if unstable.
    More relaxed: smaller eps, larger clip range, looser fallback.
    """
    import numpy as np
    from numpy.linalg import slogdet, LinAlgError
    from numerical_utils import log_fallback

    K = Sigma.shape[-1]
    batch_shape = Sigma.shape[:-2]
    eye = eps * np.eye(K, dtype=Sigma.dtype)
    eye = eye.reshape((1,) * len(batch_shape) + (K, K))
    Sigma_reg = Sigma + eye

    try:
        sign, ld = slogdet(Sigma_reg)
        bad = (sign <= 0) | ~np.isfinite(ld)
        if not np.any(bad):
            return np.clip(ld, *clip_range)
    except LinAlgError:
        bad = np.ones(batch_shape, dtype=bool)

    trace = np.trace(Sigma, axis1=-2, axis2=-1)  # (...)
    surrogate = alpha * (trace / K + eps)
    fallback_ld = K * np.log(surrogate)

    log_fallback("safe_logdet", "fallback triggered", count_key="safe_logdet")

    ld_final = np.where(bad, fallback_ld, ld)
    return np.clip(ld_final, *clip_range)



    