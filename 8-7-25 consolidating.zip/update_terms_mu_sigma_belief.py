# -*- coding: utf-8 -*-
"""
Created on Wed Jul 23 06:37:51 2025

@author: chris and christine
"""


import numpy as np
import config
from numerical_utils import sanitize_sigma, safe_inv
from natural_gradient import apply_natural_gradient_batch


def accumulate_mu_sigma_gradient(agent_i, agents, params, mode):
    """
    Accumulate natural gradient ∇μ and ∇Σ for belief or model.

    Args:
        agent_i : current agent
        agents  : list of all agents
        params  : simulation parameters
        mode    : "belief" or "model"
    """
    # Euclidean gradient
    dmu, dsigma = compute_mu_sigma_gradient_euclidean(agent_i, agents, params, mode)

    if mode == "belief":
        mu_field    = agent_i.mu_q_field
        sigma_field = agent_i.sigma_q_field
        grad_mu     = "grad_mu_q"
        grad_sigma  = "grad_sigma_q"
    elif mode == "model":
        mu_field    = agent_i.mu_p_field
        sigma_field = agent_i.sigma_p_field
        grad_mu     = "grad_mu_p"
        grad_sigma  = "grad_sigma_p"
    else:
        raise ValueError(f"Unsupported mode: {mode}")


    # Natural gradient projection
    delta_mu, delta_sigma = apply_natural_gradient_batch(
        mu_field,
        sigma_field,
        dmu,
        dsigma,
        mask=agent_i.mask,
    )

    # Accumulate
    setattr(agent_i, grad_mu, getattr(agent_i, grad_mu) + delta_mu)
    setattr(agent_i, grad_sigma, getattr(agent_i, grad_sigma) + delta_sigma)



def accumulate_entropy_sigma_gradient(agent_i, grad_sigma_q, params):
    gamma = params.get("entropy_weight", config.entropy_weight)
    if gamma == 0:
        return grad_sigma_q

    sigma_q = sanitize_sigma(agent_i.sigma_q_field, eps=config.eps)
    grad_H = 0.5 * safe_inv(sigma_q, eps=config.eps)
    #print(f"[ENTROPY] Agent {agent_i.id} ‖∇Σ_entropy‖ = {np.linalg.norm(grad_H):.3e}")
    return grad_sigma_q - gamma * grad_H



def compute_mu_sigma_gradient_euclidean(agent_i, agents, params, mode):
    """
    Compute ∇_μ and ∇_Σ gradients for belief or model:
        mode ∈ {"belief", "model"}

    Handles:
        - Self-energy:     KL(x ‖ Φ̃·y)
        - Feedback:        KL(y ‖ Φ·x)
        - Alignment:       source and target roles in KL(x_i ‖ Ω x_j)
    """
    eps = config.support_cutoff_eps

    if mode == "belief":
        alpha = params.get("alpha", config.alpha)
        beta  = params.get("beta", config.beta)
        lambd = params.get("feedback_weight", config.feedback_weight)
    elif mode == "model":
        alpha = params.get("alpha", config.alpha)  # fallback to belief alpha if not defined
        beta  = params.get("beta_model", config.beta_model)
        lambd = params.get("feedback_weight", config.feedback_weight)
    else:
        raise ValueError(f"Unsupported mode: {mode}")


    if mode == "belief":
        mu_x       = agent_i.mu_q_field
        sigma_x    = sanitize_sigma(agent_i.sigma_q_field, eps=eps)
        mu_y       = agent_i.mu_p_field
        sigma_y    = sanitize_sigma(agent_i.sigma_p_field, eps=eps)
        
        Phi        = agent_i.bundle_morphism_q_to_p
        Phi_tilde  = agent_i.bundle_morphism_p_to_q
        
        Omega_attr = "Omega_cache"
        mu_key     = "mu_q_field"
        sigma_key  = "sigma_q_field"
        
        grad_self_mu     = grad_self_energy_mu_q(mu_x, sigma_x, mu_y, sigma_y, Phi_tilde, eps=eps)
        grad_self_sigma  = grad_self_energy_sigma_q(mu_x, sigma_x, mu_y, sigma_y, Phi_tilde,  eps=eps)
        grad_fb_mu       = grad_feedback_mu_q(mu_x, sigma_x, mu_y, Phi,  eps=eps)
        grad_fb_sigma    = grad_feedback_sigma_q(mu_x, sigma_x, mu_y, sigma_y, Phi, eps=eps)
       
        grad_align_i_mu  = grad_belief_align_mu_i
        grad_align_i_sig = grad_belief_align_sigma_i
    
    elif mode == "model":
        mu_x = agent_i.mu_p_field
        sigma_x = sanitize_sigma(agent_i.sigma_p_field, eps=eps)
        mu_y = agent_i.mu_q_field
        sigma_y = sanitize_sigma(agent_i.sigma_q_field, eps=eps)
    
        Phi = agent_i.bundle_morphism_q_to_p
        Phi_tilde = agent_i.bundle_morphism_p_to_q
    
        Omega_attr = "Omega_tilde_cache"
        mu_key = "mu_p_field"
        sigma_key = "sigma_p_field"
    
        grad_self_mu = grad_self_energy_mu_p(
            mu_q_field=mu_y,
            sigma_q_field=sigma_y,
            mu_p_field=mu_x,
            sigma_p_field=sigma_x,
            Phi_tilde=Phi_tilde,
            eps=eps
        )
    
        grad_self_sigma = grad_self_energy_sigma_p(
            mu_q_field=mu_y,
            sigma_q_field=sigma_y,
            mu_p_field=mu_x,
            sigma_p_field=sigma_x,
            Phi_tilde=Phi_tilde,
            eps=eps
        )
    
        grad_fb_mu = grad_feedback_mu_p(
            mu_p_field=mu_x,
            sigma_p_field=sigma_x,
            mu_q_field=mu_y,
            sigma_q_field=sigma_y,
            Phi=Phi,
            eps=eps
        )
    
        grad_fb_sigma = grad_feedback_sigma_p(
            mu_p_field=mu_x,
            sigma_p_field=sigma_x,
            mu_q_field=mu_y,
            sigma_q_field=sigma_y,
            Phi=Phi,
            eps=eps
        )
       
        grad_align_i_mu  = grad_align_mu_i
        grad_align_i_sig = grad_align_sigma_i
     
    else:
        raise ValueError(f"Unsupported mode: {mode}")

    # Alignment (i is source)
    dmu_align = 0
    dsigma_align = 0
    for neighbor in agent_i.neighbors:
        agent_j = agents[neighbor["id"]]
        Omega_ij = getattr(agent_i, Omega_attr)[agent_j.id]
        mu_j     = getattr(agent_j, mu_key)
        sigma_j  = sanitize_sigma(getattr(agent_j, sigma_key), eps=eps)

        dmu_align    += grad_align_i_mu(mu_x, sigma_x, mu_j, sigma_j, Omega_ij, eps=eps)
        dsigma_align += grad_align_i_sig(mu_x, sigma_x, mu_j, sigma_j, Omega_ij, eps=eps)

    

        # Combine
    dmu_total = alpha * grad_self_mu + lambd * grad_fb_mu + beta * dmu_align 
    dsigma_total = alpha * grad_self_sigma + lambd * grad_fb_sigma + beta * dsigma_align

    # 🔹 Add entropy regularization if in belief mode
    if mode == "belief":
        dsigma_total = accumulate_entropy_sigma_gradient(agent_i, dsigma_total, params)

    return dmu_total, dsigma_total






#==============================================================================
#                           OLD
#                    APPLY NATURAL GRADIENT
#
#==============================================================================


def accumulate_mu_sigma_gradient_belief(agent_i, agents, params):
    """
    Accumulate ∇μ_q and ∇Σ_q from all belief energy terms:
      - Self:     KL(q_i || Φ̃ p_i)
      - Feedback: KL(p_i || Φ q_i)
      - Alignment: KL(q_i || Ω_ij q_j) and KL(q_k || Ω_kj q_j) for i == j

    Stores total gradient into:
        agent_i.grad_mu_q_field
        agent_i.grad_sigma_q_field
    """

    # Compute total Euclidean gradient
    dmu, dsigma = compute_mu_sigma_gradient_belief_euclidean(agent_i, agents, params)
    

    # Project into Fisher-natural gradient directions
    delta_mu, delta_sigma = apply_natural_gradient_batch(
        agent_i.mu_q_field,
        agent_i.sigma_q_field,
        dmu,
        dsigma,
        mask=agent_i.mask,
    )

   

    # Accumulate
    agent_i.grad_mu_q    += delta_mu
    agent_i.grad_sigma_q += delta_sigma






#==============================================================================
#                           OLD
#                    ACCUMULATE FIELD GRADS EUCLIDEAN
#
#==============================================================================

def compute_mu_sigma_gradient_belief_euclidean(agent_i, agents, params):
    """
    Accumulate ∇_μ and ∇_Σ belief gradients for agent_i from:
    - Self-energy:     KL(q_i ‖ Φ̃ p_i)
    - Feedback:        KL(p_i ‖ Φ q_i)
    - Alignment (μ_i): KL(q_i ‖ Ω_ij q_j)
    - Alignment (μ_j): KL(q_k ‖ Ω_kj q_j) for i == j

    Returns:
        dmu_q:    (..., K_q)
        dsigma_q: (..., K_q, K_q)
    """
    eps   = config.support_cutoff_eps
    alpha = params.get("alpha", config.alpha)
    beta  = params.get("beta", config.beta)
    lambd = params.get("feedback_weight", config.feedback_weight)

    mu_q    = agent_i.mu_q_field
    sigma_q = sanitize_sigma(agent_i.sigma_q_field, eps=eps)
    mu_p    = agent_i.mu_p_field
    sigma_p = sanitize_sigma(agent_i.sigma_p_field, eps=eps)

    Phi         = agent_i.bundle_morphism_q_to_p
    Phi_tilde   = agent_i.bundle_morphism_p_to_q

    # ─── Self and Feedback terms ───
    dmu_self    = grad_self_energy_mu_q(mu_q, sigma_q, mu_p, sigma_p, Phi_tilde, eps=eps)
    dsigma_self = grad_self_energy_sigma_q(mu_q, sigma_q, mu_p, sigma_p, Phi_tilde, eps=eps)

    dmu_fb      = grad_feedback_mu_q(mu_q, sigma_q, mu_p, Phi, eps=eps)
    dsigma_fb   = grad_feedback_sigma_q(mu_q, sigma_q, mu_p, sigma_p, Phi, eps=eps)

    # ─── Alignment: i is source ───
    dmu_align = 0
    dsigma_align = 0
    for neighbor in agent_i.neighbors:
        agent_j = agents[neighbor["id"]]
        Omega_ij = agent_i.Omega_cache[agent_j.id]

        sigma_qj = sanitize_sigma(agent_j.sigma_q_field, eps=eps)

        dmu_align += grad_belief_align_mu_i(
            mu_q, sigma_q, agent_j.mu_q_field, sigma_qj, Omega_ij, eps=eps
        )
        dsigma_align += grad_belief_align_sigma_i(
            mu_q, sigma_q, agent_j.mu_q_field, sigma_qj, Omega_ij, eps=eps
        )

 
    # ─── Total gradient ───
    dmu_total = (
        alpha * dmu_self +
        lambd * dmu_fb +
        beta * (dmu_align)
    )

    dsigma_total = (
        alpha * dsigma_self +
        lambd * dsigma_fb +
        beta * (dsigma_align)
    )

    #print(f"[grad mu_q] norm from belief= {np.linalg.norm(dmu_total):.2e}")
   # print(f"[grad Sigma_q] norm from belief = {np.linalg.norm(dsigma_total):.2e}\n\n")

    return dmu_total, dsigma_total




from numerical_utils import safe_logdet

def compute_entropy_from_sigma(sigma, eps=1e-8):
    """
    Compute differential entropy of N(μ, Σ):

        H[q] = ½ log det(2πe Σ) = ½ (K log(2πe) + log det(Σ))

    Args:
        sigma: (..., K, K)
    Returns:
        entropy: (...,)
    """
    K = sigma.shape[-1]
    log_det = safe_logdet(sigma, eps=eps)
    return 0.5 * (K * (1 + np.log(2 * np.pi)) + log_det)


def grad_entropy_sigma(sigma, eps=1e-8):
    """
    Gradient of entropy with respect to Σ:

        ∇_Σ H[q] = ½ Σ⁻¹

    Args:
        sigma: (..., K, K)
    Returns:
        grad: (..., K, K)
    """
    sigma_inv = safe_inv(sigma, eps=eps)
    return 0.5 * sigma_inv


#==============================================================================
#
#                    FEEDBACK TERMS
#             everything validated below
#==============================================================================

def grad_feedback_mu_q(mu_q_field, sigma_q_field, mu_p_field, Phi, eps=1e-8):
    """
    Compute ∂/∂μ_q D_KL(p || Φ·q) over a spatial field (..., K_q)

    This computes the gradient of the KL divergence between
    a fixed distribution p = N(μ_p, Σ_p) and the pushforward of
    a belief distribution q = N(μ_q, Σ_q) under the linear transformation Φ:
        Φ·q := N(Φ μ_q, Φ Σ_q Φᵀ)

    Let:
        Δμ = μ_p − Φ μ_q
        Σ_q_push = Φ Σ_q Φᵀ
        M = Σ_q_push⁻¹

    The closed-form expression is:
        ∂/∂μ_q D_KL(p || Φ·q) = - Φᵀ · M · (μ_p − Φ μ_q)

    Args:
        mu_q_field    : (..., K_q)     — belief mean field
        sigma_q_field : (..., K_q, K_q) — belief covariance field
        mu_p_field    : (..., K_p)     — target model mean
        Phi           : (..., K_p, K_q) — bundle morphism Φ
        eps           : small regularization for matrix inversion
        
    Returns:
        grad_mu_q     : (..., K_q), the KL gradient w.r.t. μ_q
    """
    # Compute pushforward mean: Φ μ_q
    mu_q_push = np.einsum("...ij,...j->...i", Phi, mu_q_field)
    #sigma_q_field = sanitize_sigma(sigma_q_field, eps=eps)

    # Compute pushforward covariance: Φ Σ_q Φ^T
    sigma_push = np.einsum("...ik,...kl,...jl->...ij", Phi, sigma_q_field, Phi)

    # Safe inverse
    sigma_push_inv = safe_inv(sigma_push, eps=eps)

    # Δμ = μ_p − Φ μ_q
    delta_mu = mu_p_field - mu_q_push

    # Gradient: - Φ^T (Φ Σ_q Φ^T)^{-1} (μ_p - Φ μ_q)
    tmp = np.einsum("...ij,...j->...i", sigma_push_inv, delta_mu)
    grad_mu_q = -np.einsum("...ji,...j->...i", Phi, tmp)

    return grad_mu_q


def grad_feedback_sigma_q(mu_q_field, sigma_q_field, mu_p_field,
                           sigma_p_field, Phi, eps=1e-8):
    """
    Compute ∂/∂Σ_q D_KL(p || Φ·q) over spatial field (H, W, K_q, K_q)

    This computes the variational gradient of the KL divergence between
    a target distribution p = N(μ_p, Σ_p) and the pushforward of a belief
    distribution q = N(μ_q, Σ_q) under the linear transformation Φ:
        Φ·q := N(Φ μ_q, Φ Σ_q Φᵀ)

    Let:
        Δμ = μ_p - Φ μ_q
        Σ_q_push = Φ Σ_q Φᵀ
        M := Σ_q_push⁻¹
        A := Δμ Δμᵀ

    The closed-form expression is:
        ∂/∂Σ_q D_KL(p || Φ·q)
        = ½ Φᵀ [ M - M A M - M Σ_p M ] Φ

    Args:
        mu_q_field     : (..., K_q)
        sigma_q_field  : (..., K_q, K_q)
        mu_p_field     : (..., K_p)
        sigma_p_field  : (..., K_p, K_p)
        Phi            : (..., K_p, K_q)
        eps            : regularization epsilon

    Returns:
        grad_sigma_q   : (..., K_q, K_q)
    """
    mu_q_push = np.einsum("...ij,...j->...i", Phi, mu_q_field)  # (..., K_p)

    Phi_T = np.swapaxes(Phi, -1, -2)
    #sigma_q_field = sanitize_sigma(sigma_q_field, eps=eps)

    sigma_q_push = np.einsum("...ik,...kl,...jl->...ij", Phi, sigma_q_field, Phi)
    sigma_q_push_inv = safe_inv(sigma_q_push, eps=eps)

    delta_mu = mu_p_field - mu_q_push  # (..., K_p)
    A = np.einsum("...i,...j->...ij", delta_mu, delta_mu)

    inv_term     = sigma_q_push_inv
    mahal_term   = np.einsum("...ik,...kl,...lj->...ij", sigma_q_push_inv, A, sigma_q_push_inv)
    trace_term   = np.einsum("...ik,...kl,...lj->...ij", sigma_q_push_inv, sigma_p_field, sigma_q_push_inv)

    M = inv_term - mahal_term - trace_term  # (..., K_p, K_p)

    grad_sigma_q = 0.5 * np.einsum("...ki,...kl,...lj->...ij", Phi, M, Phi)

    return grad_sigma_q






#==============================================================================
#
#                    SELF-ENERGY TERMS
#
#==============================================================================

def grad_self_energy_mu_q(mu_q_field, sigma_q_field, mu_p_field, sigma_p_field, Phi_tilde, eps=1e-8):
    """
    Compute ∂/∂μ_q D_KL(q || Φ̃·p) over a spatial field (..., K_q)

    This is the gradient of the KL divergence between q and the
    pushforward of a model distribution p under Φ̃:
        Φ̃·p := N(Φ̃ μ_p, Φ̃ Σ_p Φ̃ᵀ)

    Let:
        Δμ = μ_q − Φ̃ μ_p
        Σ_p_push = Φ̃ Σ_p Φ̃ᵀ
        M = Σ_p_push⁻¹

    The gradient is:
        ∂/∂μ_q D_KL(q || Φ̃·p) = M · (μ_q − Φ̃ μ_p)

    Args:
        mu_q_field     : (..., K_q)
        sigma_q_field  : (..., K_q, K_q)
        mu_p_field     : (..., K_p)
        sigma_p_field  : (..., K_p, K_p)
        Phi_tilde      : (..., K_q, K_p)
        eps            : small regularization for inversion

    Returns:
        grad_mu_q      : (..., K_q)
    """
    mu_p_push = np.einsum("...ij,...j->...i", Phi_tilde, mu_p_field)
    
    
    #sigma_p_field = sanitize_sigma(sigma_p_field, eps=eps)
    
    sigma_p_push = np.einsum("...iq,...qr,...jr->...ij", Phi_tilde, sigma_p_field, Phi_tilde)
    sigma_p_push_inv = safe_inv(sigma_p_push, eps=eps)

    delta_mu = mu_q_field - mu_p_push
    grad_mu_q = np.einsum("...ij,...j->...i", sigma_p_push_inv, delta_mu)

    return grad_mu_q


def grad_self_energy_sigma_q(mu_q_field, sigma_q_field, mu_p_field, sigma_p_field, Phi_tilde, eps=1e-8):
    """
    Compute ∂/∂Σ_q D_KL(q || Φ̃·p) over a spatial field (..., K_q, K_q)

    This is the gradient of the KL divergence between:
        q = N(μ_q, Σ_q)
        Φ̃·p = N(Φ̃ μ_p, Φ̃ Σ_p Φ̃ᵀ)

    The closed-form expression is:
        ∂/∂Σ_q D_KL(q || Φ̃·p)
        = ½ [ Σ_q⁻¹ − (Φ̃ Σ_p Φ̃ᵀ)⁻¹ ]

    Args:
        mu_q_field     : (..., K_q)
        sigma_q_field  : (..., K_q, K_q)
        mu_p_field     : (..., K_p)
        sigma_p_field  : (..., K_p, K_p)
        Phi_tilde      : (..., K_q, K_p)
        eps            : small regularization constant for safe inversion

    Returns:
        grad_sigma_q   : (..., K_q, K_q)
    """
    sigma_q_inv = safe_inv(sigma_q_field, eps=eps)
   
    #sigma_p_field = sanitize_sigma(sigma_p_field, eps=eps)
    sigma_p_push = np.einsum("...iq,...qr,...jr->...ij", Phi_tilde, sigma_p_field, Phi_tilde)
    sigma_p_push_inv = safe_inv(sigma_p_push, eps=eps)

    #check this sign!!!!

    grad = 0.5 * (sigma_p_push_inv - sigma_q_inv)
    return grad



#==============================================================================
#
#                    ALIGNMENT TERMS
#
#==============================================================================

def grad_belief_align_mu_i(mu_i, sigma_i, mu_j, sigma_j, Omega_ij, eps=1e-8):
    """
    Compute ∂/∂μ_i D_KL(q_i || Ω q_j)

    This computes the gradient of the KL divergence between:
        q_i = N(μ_i, Σ_i)
        Ω q_j = N(Ω μ_j, Ω Σ_j Ωᵀ)

    with respect to μ_i.

    Let:
        μ_j^t := Ω μ_j
        Σ_j^t := Ω Σ_j Ωᵀ
        Δμ := μ_i − μ_j^t

    Then:
        ∂/∂μ_i D_KL(q_i || Ω q_j) = Σ_j^t⁻¹ · (μ_i − Ω μ_j)

    Args:
        mu_i     : (..., K)
        sigma_i  : (..., K, K)
        mu_j     : (..., K)
        sigma_j  : (..., K, K)
        Omega_ij : (..., K, K) — transport operator
        eps      : regularization for inversion

    Returns:
        grad_mu_i: (..., K)
    """
    
    mu_j_t = np.einsum("...ij,...j->...i", Omega_ij, mu_j)
    delta_mu = mu_i - mu_j_t

    Omega_T = np.swapaxes(Omega_ij, -1, -2)
    sigma_j_t = np.matmul(Omega_ij, np.matmul(sigma_j, Omega_T))
    sigma_j_t = sanitize_sigma(sigma_j_t, eps=eps)
    sigma_inv = safe_inv(sigma_j_t, eps=eps)

    grad = np.einsum("...ij,...j->...i", sigma_inv, delta_mu)
    return grad


def grad_belief_align_sigma_i(mu_i, sigma_i, mu_j, sigma_j, Omega_ij, eps=1e-8):
    """
    Compute ∂/∂Σ_i D_KL(q_i || Ω q_j)

    This computes the gradient of the KL divergence between:
        q_i = N(μ_i, Σ_i)
        Ω q_j = N(Ω μ_j, Ω Σ_j Ωᵀ)

    with respect to Σ_i.

    The closed-form expression is:
        ∂/∂Σ_i D_KL(q_i || Ω q_j)
        = ½ [ (Ω Σ_j Ωᵀ)^(-1) − Σ_i^(-1) ]

    Args:
        mu_i     : (..., K)
        sigma_i  : (..., K, K)
        mu_j     : (..., K)
        sigma_j  : (..., K, K)
        Omega_ij : (..., K, K)
        eps      : regularization epsilon

    Returns:
        grad_sigma_i : (..., K, K)
    """
    Omega_T = np.swapaxes(Omega_ij, -1, -2)
    sigma_j_t = np.einsum("...ik,...kl,...lj->...ij", Omega_ij, sigma_j, Omega_T)

    inv_j = safe_inv(sigma_j_t, eps=eps)
    inv_i = safe_inv(sigma_i, eps=eps)

    grad = 0.5 * (inv_j - inv_i)
    return grad


def grad_belief_align_mu_j(mu_i, sigma_i, mu_j, sigma_j, Omega_ij, eps=1e-8):
    """
    Compute ∂/∂μ_j D_KL(q_i || Ω q_j)

    This is the gradient of the KL divergence between:
        q_i = N(μ_i, Σ_i)
        Ω q_j = N(Ω μ_j, Ω Σ_j Ωᵀ)

    with respect to μ_j.

    Let:
        μ_j^t := Ω μ_j
        Σ_j^t := Ω Σ_j Ωᵀ
        Δμ := μ_i − μ_j^t
        M := Σ_j^t⁻¹

    Then:
        ∂/∂μ_j D_KL(q_i || Ω q_j)
        = - Ωᵀ M (μ_i − Ω μ_j)

    Args:
        mu_i     : (..., K)
        sigma_i  : (..., K, K)
        mu_j     : (..., K)
        sigma_j  : (..., K, K)
        Omega_ij : (..., K, K)
        eps      : small regularization constant

    Returns:
        grad_mu_j : (..., K)
    """
    mu_j_t = np.einsum("...ij,...j->...i", Omega_ij, mu_j)
    delta_mu = mu_i - mu_j_t

    Omega_T = np.swapaxes(Omega_ij, -1, -2)
    sigma_j_t = np.einsum("...ik,...kl,...lj->...ij", Omega_ij, sigma_j, Omega_T)

    #sigma_j_t = sanitize_sigma(sigma_j_t, eps=eps)
    sigma_inv = safe_inv(sigma_j_t, eps=eps)

    tmp = np.einsum("...ij,...j->...i", sigma_inv, delta_mu)
    grad = -np.einsum("...ji,...i->...j", Omega_ij, tmp)
    return grad


def grad_belief_align_sigma_j_simp(mu_i, sigma_i, mu_j, sigma_j, Omega_ij, eps=1e-8):
    """
    Compute ∂/∂Σ_j D_KL(q_i || Ω q_j), assuming Ω ∈ SO(3)

    This computes the gradient of the KL divergence between:
        q_i     = N(μ_i, Σ_i)
        Ω q_j   = N(Ω μ_j, Ω Σ_j Ωᵀ)

    Let:
        Δμ := μ_i − Ω μ_j

    Uses the SO(3)-simplified expression:
        ∂/∂Σ_j D_KL(q_i || Ω q_j)
        = ½ [ Σ_j⁻¹ Ωᵀ Δμ Δμᵀ Ω Σ_j⁻¹
             − Σ_j⁻¹ Ωᵀ Σ_i Ω Σ_j⁻¹
             − Σ_j⁻¹ ]
        simplified due to SO3
    Args:
        mu_i     : (..., K)
        sigma_i  : (..., K, K)
        mu_j     : (..., K)
        sigma_j  : (..., K, K)
        Omega_ij : (..., K, K)
        eps      : regularization constant

    Returns:
        grad_sigma_j : (..., K, K)
    """
    Omega_T = np.swapaxes(Omega_ij, -1, -2)

    mu_j_t = np.einsum("...ij,...j->...i", Omega_ij, mu_j)
    delta_mu = mu_i - mu_j_t

    #sigma_j = sanitize_sigma(sigma_j, eps=eps)
    sigma_j_inv = safe_inv(sigma_j, eps=eps)

    # Δμ Δμᵀ
    outer = np.einsum("...i,...j->...ij", delta_mu, delta_mu)

    # First term: Σ_j⁻¹ Ωᵀ Δμ Δμᵀ Ω Σ_j⁻¹
    term1 = np.einsum("...ik,...kl,...lm,...mj->...ij",
                      sigma_j_inv, Omega_T, outer, Omega_ij)
    term1 = np.einsum("...ik,...kj->...ij", term1, sigma_j_inv)

    # Second term: Σ_j⁻¹ Ωᵀ Σ_i Ω Σ_j⁻¹
    term2 = np.einsum("...ik,...kl,...lm->...im", Omega_T, sigma_i, Omega_ij)
    term2 = np.einsum("...ik,...kl,...lj->...ij",
                      sigma_j_inv, term2, sigma_j_inv)

    # Third term: Σ_j⁻¹
    term3 = sigma_j_inv

    grad = 0.5 * (term1 - term2 - term3)
    return grad



def grad_belief_align_sigma_j(mu_i, sigma_i, mu_j, sigma_j, Omega_ij, eps=1e-8):
    """
    Compute ∂/∂Σ_j D_KL(q_i || Ω q_j)

    This is the gradient of the KL divergence between:
        q_i = N(μ_i, Σ_i)
        Ω q_j = N(Ω μ_j, Ω Σ_j Ωᵀ)

    with respect to Σ_j.

    Let:
        Σ_j^t := Ω Σ_j Ωᵀ
        Δμ := μ_i − Ω μ_j
        M := (Σ_j^t)^(-1)

    The full expression is:
        ∂/∂Σ_j D_KL(q_i || Ω q_j)
        = ½ Ωᵀ [ M Δμ Δμᵀ M − M Σ_i M − M ] Ω

    Args:
        mu_i     : (..., K)
        sigma_i  : (..., K, K)
        mu_j     : (..., K)
        sigma_j  : (..., K, K)
        Omega_ij : (..., K, K)
        eps      : small regularization constant

    Returns:
        grad_sigma_j : (..., K, K)
    """
    mu_j_t = np.einsum("...ij,...j->...i", Omega_ij, mu_j)
    delta_mu = mu_i - mu_j_t

    Omega_T = np.swapaxes(Omega_ij, -1, -2)
    sigma_j_t = np.einsum("...ik,...kl,...lj->...ij", Omega_ij, sigma_j, Omega_T)
    
    #sigma_j_t = sanitize_sigma(sigma_j_t, eps=eps)
    sigma_inv = safe_inv(sigma_j_t, eps=eps)

    # Term 1: M Δμ Δμᵀ M
    tmp = np.einsum("...i,...j->...ij", delta_mu, delta_mu)
    term1 = np.einsum("...ik,...kl,...lj->...ij", sigma_inv, tmp, sigma_inv)

    # Term 2: M Σ_i M
    term2 = np.einsum("...ik,...kl,...lj->...ij", sigma_inv, sigma_i, sigma_inv)

    # Term 3: M
    term3 = sigma_inv

    # Combine and pull back to Σ_j
    diff = term1 - term2 - term3
    grad = 0.5 * np.einsum("...ik,...kl,...lj->...ij", Omega_T, diff, Omega_ij)
    return grad





#==============================================================================
#
#                 MODEL FEEDBACK TERMS
#                  all validated below
#==============================================================================

def grad_feedback_mu_p(mu_p_field, sigma_p_field,
                       mu_q_field, sigma_q_field, Phi, eps=1e-8):
    """
    Compute ∂/∂μ_p D_KL(p || Φ·q) over a spatial field (..., K_p)

    This computes the gradient of the KL divergence between:
        p        = N(μ_p, Σ_p)
        Φ·q      = N(Φ μ_q, Φ Σ_q Φᵀ)

    Let:
        μ_q^push := Φ μ_q
        Σ_q^push := Φ Σ_q Φᵀ
        Δμ       := μ_p − Φ μ_q
        M        := (Σ_q^push)^(-1)

    The closed-form gradient is:
        ∂/∂μ_p D_KL(p || Φ q) = M · (μ_p − Φ μ_q)

    Args:
        mu_p_field     : (..., K_p)       — model mean μ_p
        sigma_p_field  : (..., K_p, K_p)  — model covariance Σ_p (unused here)
        mu_q_field     : (..., K_q)       — belief mean μ_q
        sigma_q_field  : (..., K_q, K_q)  — belief covariance Σ_q
        Phi            : (..., K_p, K_q)  — bundle morphism Φ: B_q → B_p
        eps            : regularization epsilon for inversion

    Returns:
        grad_mu_p      : (..., K_p)       — gradient w.r.t. μ_p
    """
    mu_q_push = np.einsum("...ij,...j->...i", Phi, mu_q_field)

    #sigma_q_field = sanitize_sigma(sigma_q_field, eps=eps)
    sigma_q_push = np.einsum("...ik,...kl,...jl->...ij", Phi, sigma_q_field, Phi)

    sigma_q_push_inv = safe_inv(sigma_q_push, eps=eps)
    delta_mu = mu_p_field - mu_q_push

    grad_mu_p = np.einsum("...ij,...j->...i", sigma_q_push_inv, delta_mu)
    return grad_mu_p


def grad_feedback_sigma_p(mu_p_field, sigma_p_field,
                          mu_q_field, sigma_q_field, Phi, eps=1e-8):
    """
    Compute ∂/∂Σ_p D_KL(p || Φ·q) over a spatial field (..., K_p, K_p)

    This is the gradient of the KL divergence between:
        p        = N(μ_p, Σ_p)
        Φ·q      = N(Φ μ_q, Φ Σ_q Φᵀ)

    Let:
        Σ_q^push := Φ Σ_q Φᵀ

    The closed-form expression is:
        ∂/∂Σ_p D_KL(p || Φ·q) = ½ [ (Σ_q^push)^(-1) − Σ_p^(-1) ]

    Args:
        mu_p_field     : (..., K_p)
        sigma_p_field  : (..., K_p, K_p)
        mu_q_field     : (..., K_q)
        sigma_q_field  : (..., K_q, K_q)
        Phi            : (..., K_p, K_q)
        eps            : regularization epsilon for inversion

    Returns:
        grad_sigma_p   : (..., K_p, K_p)
    """
    Phi_T = np.swapaxes(Phi, -1, -2)

    #sigma_q_field = sanitize_sigma(sigma_q_field, eps=eps)
    sigma_q_push = np.einsum("...ik,...kl,...lj->...ij", Phi, sigma_q_field, Phi_T)

    sigma_q_push = sanitize_sigma(sigma_q_push, eps=eps)
   # sigma_p_field = sanitize_sigma(sigma_p_field, eps=eps)

    sigma_inv_qpush = safe_inv(sigma_q_push, eps=eps)
    sigma_inv_p     = safe_inv(sigma_p_field, eps=eps)

    grad_sigma_p = 0.5 * (sigma_inv_qpush - sigma_inv_p)
    return grad_sigma_p



#==============================================================================
#
#                   MODEL SELF-ENERGY TERMS
#
#==============================================================================

def grad_self_energy_mu_p(mu_q_field, sigma_q_field,
                          mu_p_field, sigma_p_field, Phi_tilde, eps=1e-8):
    """
    Compute ∂/∂μ_p D_KL(q || Φ̃·p) over a spatial field (..., K_p)

    This is the gradient of the KL divergence between:
        q         = N(μ_q, Σ_q)
        Φ̃·p      = N(Φ̃ μ_p, Φ̃ Σ_p Φ̃ᵀ)

    Let:
        μ_p^push := Φ̃ μ_p
        Σ_p^push := Φ̃ Σ_p Φ̃ᵀ
        Δμ       := μ_q − Φ̃ μ_p
        M        := (Σ_p^push)^(-1)

    The closed-form expression is:
        ∂/∂μ_p D_KL(q || Φ̃·p) = − Φ̃ᵀ · M · (μ_q − Φ̃ μ_p)

    Args:
        mu_q_field     : (..., K_q)
        sigma_q_field  : (..., K_q, K_q)
        mu_p_field     : (..., K_p)
        sigma_p_field  : (..., K_p, K_p)
        Phi_tilde      : (..., K_q, K_p) — bundle morphism Φ̃: B_p → B_q
        eps            : small regularization epsilon

    Returns:
        grad_mu_p      : (..., K_p)
    """
    mu_p_push = np.einsum("...qk,...k->...q", Phi_tilde, mu_p_field)
   #sigma_p_field = sanitize_sigma(sigma_p_field, eps=eps)
    
    sigma_p_push = np.einsum("...qi,...ij,...kj->...qk", Phi_tilde, sigma_p_field, Phi_tilde)

    sigma_p_push = sanitize_sigma(sigma_p_push, eps=eps)
    sigma_p_push_inv = safe_inv(sigma_p_push, eps=eps)

    delta_mu = mu_q_field - mu_p_push
    tmp = np.einsum("...ij,...j->...i", sigma_p_push_inv, delta_mu)
    grad_mu_p = -np.einsum("...qk,...q->...k", Phi_tilde, tmp)

    return grad_mu_p


def grad_self_energy_sigma_p(mu_q_field, sigma_q_field, mu_p_field,
                              sigma_p_field, Phi_tilde, eps=1e-8):
    """
    Compute ∂/∂Σ_p D_KL(q || Φ̃·p) over a spatial field (..., K_p, K_p)

    This is the gradient of the KL divergence between:
        q         = N(μ_q, Σ_q)
        Φ̃·p      = N(Φ̃ μ_p, Φ̃ Σ_p Φ̃ᵀ)

    Let:
        μ_p^push := Φ̃ μ_p
        Σ_p^push := Φ̃ Σ_p Φ̃ᵀ
        Δμ       := μ_q − Φ̃ μ_p
        M        := (Σ_p^push)^(-1)

    The closed-form expression is:
        ∂/∂Σ_p D_KL(q || Φ̃·p) = ½ · Φ̃ᵗ · [ M − M Δμ Δμᵀ M − M Σ_q M ] · Φ̃

    Args:
        mu_q_field     : (..., K_q)
        sigma_q_field  : (..., K_q, K_q)
        mu_p_field     : (..., K_p)
        sigma_p_field  : (..., K_p, K_p)
        Phi_tilde      : (..., K_q, K_p) — bundle morphism Φ̃: B_p → B_q
        eps            : small regularization epsilon

    Returns:
        grad_sigma_p   : (..., K_p, K_p)
    """
   # sigma_p_field = sanitize_sigma(sigma_p_field, eps=eps)
   # sigma_q_field = sanitize_sigma(sigma_q_field, eps=eps)

    Phi_tilde_T = np.swapaxes(Phi_tilde, -1, -2)

    sigma_proj = np.einsum("...ik,...kl,...jl->...ij", Phi_tilde, sigma_p_field, Phi_tilde)
    sigma_proj_inv = safe_inv(sigma_proj, eps=eps)

    mu_proj = np.einsum("...ij,...j->...i", Phi_tilde, mu_p_field)
    delta_mu = mu_q_field - mu_proj
    delta_mu_outer = np.einsum("...i,...j->...ij", delta_mu, delta_mu)

    term1 = sigma_proj_inv
    term2 = np.einsum("...ik,...kl,...lj->...ij", sigma_proj_inv, delta_mu_outer, sigma_proj_inv)
    term3 = np.einsum("...ik,...kl,...lj->...ij", sigma_proj_inv, sigma_q_field, sigma_proj_inv)

    M = term1 - term2 - term3
    grad_sigma_p = 0.5 * np.einsum("...ki,...ij,...jl->...kl", Phi_tilde_T, M, Phi_tilde)

    return grad_sigma_p




#==============================================================================
#
#                  GENERAL MODEL/BELIEF  
#               ALIGNMENT TERMS - NOT VALIDATED
#==============================================================================
def grad_align_mu_i(mu_i, sigma_i, mu_j, sigma_j, Omega_ij, eps=1e-8):
    """
    Compute ∂/∂μ_i D_KL(q_i || Ω q_j)

    This computes the gradient of the KL divergence between:
        q_i = N(μ_i, Σ_i)
        Ω q_j = N(Ω μ_j, Ω Σ_j Ωᵀ)

    with respect to μ_i.

    Let:
        μ_j^t := Ω μ_j
        Σ_j^t := Ω Σ_j Ωᵀ
        Δμ := μ_i − μ_j^t

    Then:
        ∂/∂μ_i D_KL(q_i || Ω q_j) = Σ_j^t⁻¹ · (μ_i − Ω μ_j)

    Args:
        mu_i     : (..., K)
        sigma_i  : (..., K, K)
        mu_j     : (..., K)
        sigma_j  : (..., K, K)
        Omega_ij : (..., K, K) — transport operator
        eps      : regularization for inversion

    Returns:
        grad_mu_i: (..., K)
    """
    mu_j_t = np.einsum("...ij,...j->...i", Omega_ij, mu_j)
    delta_mu = mu_i - mu_j_t

    sigma_j_t = np.einsum("...ik,...kl,...lj->...ij", Omega_ij, sigma_j, Omega_ij.swapaxes(-1, -2))
    sigma_j_t = sanitize_sigma(sigma_j_t, eps=eps)
    sigma_inv = safe_inv(sigma_j_t, eps=eps)

    return np.einsum("...ij,...j->...i", sigma_inv, delta_mu)



def grad_align_sigma_i(mu_i, sigma_i, mu_j, sigma_j, Omega_ij, eps=1e-8):
    """
    Compute ∂/∂Σ_i D_KL(q_i || Ω q_j)

    This computes the gradient of the KL divergence between:
        q_i = N(μ_i, Σ_i)
        Ω q_j = N(Ω μ_j, Ω Σ_j Ωᵀ)

    with respect to Σ_i.

    The closed-form expression is:
        ∂/∂Σ_i D_KL(q_i || Ω q_j)
        = ½ [ (Ω Σ_j Ωᵀ)^(-1) − Σ_i^(-1) ]

    Args:
        mu_i     : (..., K)
        sigma_i  : (..., K, K)
        mu_j     : (..., K)
        sigma_j  : (..., K, K)
        Omega_ij : (..., K, K)
        eps      : regularization epsilon

    Returns:
        grad_sigma_i : (..., K, K)
    """
    Omega_T = np.swapaxes(Omega_ij, -1, -2)
    sigma_j_t = np.einsum("...ik,...kl,...lj->...ij", Omega_ij, sigma_j, Omega_T)

    inv_j = safe_inv(sanitize_sigma(sigma_j_t, eps=eps), eps=eps)
    inv_i = safe_inv(sanitize_sigma(sigma_i,    eps=eps), eps=eps)

    return 0.5 * (inv_j - inv_i)


    
def grad_align_mu_j(mu_i, sigma_i, mu_j, sigma_j, Omega_ij, eps=1e-8):
    """
    Compute ∂/∂μ_j D_KL(q_i || Ω q_j) belief or model

    This is the gradient of the KL divergence between:
        q_i = N(μ_i, Σ_i)
        Ω q_j = N(Ω μ_j, Ω Σ_j Ωᵀ)

    with respect to μ_j.

    Let:
        μ_j^t := Ω μ_j
        Σ_j^t := Ω Σ_j Ωᵀ
        Δμ := μ_i − μ_j^t
        M := Σ_j^t⁻¹

    Then:
        ∂/∂μ_j D_KL(q_i || Ω q_j)
        = - Ωᵀ M (μ_i − Ω μ_j)

    Args:
        mu_i     : (..., K)
        sigma_i  : (..., K, K)
        mu_j     : (..., K)
        sigma_j  : (..., K, K)
        Omega_ij : (..., K, K)
        eps      : small regularization constant

    Returns:
        grad_mu_j : (..., K)
    """
    mu_j_t = np.einsum("...ij,...j->...i", Omega_ij, mu_j)
    delta_mu = mu_i - mu_j_t

    sigma_j_t = np.einsum("...ik,...kl,...lj->...ij", Omega_ij, sigma_j, Omega_ij.swapaxes(-1, -2))
    sigma_inv = safe_inv(sigma_j_t, eps=eps)

    tmp = np.einsum("...ij,...j->...i", sigma_inv, delta_mu)
    grad = -np.einsum("...ji,...i->...j", Omega_ij, tmp)
    return grad


def grad_align_sigma_j(mu_i, sigma_i, mu_j, sigma_j, Omega_ij, eps=1e-8):
    """
    Compute ∂/∂Σ_j D_KL(q_i || Ω q_j)

    This is the gradient of the KL divergence between:
        q_i = N(μ_i, Σ_i)
        Ω q_j = N(Ω μ_j, Ω Σ_j Ωᵀ)

    with respect to Σ_j.

    Let:
        Σ_j^t := Ω Σ_j Ωᵀ
        Δμ := μ_i − Ω μ_j
        M := (Σ_j^t)^(-1)

    The full expression is:
        ∂/∂Σ_j D_KL(q_i || Ω q_j)
        = ½ Ωᵀ [ M Δμ Δμᵀ M − M Σ_i M − M ] Ω

    Args:
        mu_i     : (..., K)
        sigma_i  : (..., K, K)
        mu_j     : (..., K)
        sigma_j  : (..., K, K)
        Omega_ij : (..., K, K)
        eps      : small regularization constant

    Returns:
        grad_sigma_j : (..., K, K)
    """
    mu_j_t = np.einsum("...ij,...j->...i", Omega_ij, mu_j)
    delta_mu = mu_i - mu_j_t

    Omega_T = np.swapaxes(Omega_ij, -1, -2)
    sigma_j_t = np.einsum("...ik,...kl,...lj->...ij", Omega_ij, sigma_j, Omega_T)
    sigma_inv = safe_inv(sigma_j_t, eps=eps)

    outer = np.einsum("...i,...j->...ij", delta_mu, delta_mu)

    term1 = np.einsum("...ik,...kl,...lj->...ij", sigma_inv, outer, sigma_inv)
    term2 = np.einsum("...ik,...kl,...lj->...ij", sigma_inv, sigma_i, sigma_inv)
    term3 = sigma_inv

    diff = term1 - term2 - term3
    grad = 0.5 * np.einsum("...ik,...kl,...lj->...ij", Omega_T, diff, Omega_ij)
    return grad
