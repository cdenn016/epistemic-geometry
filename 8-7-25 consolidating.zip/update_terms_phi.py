# -*- coding: utf-8 -*-
"""
Created on Wed Jul 23 06:38:17 2025

@author: chris and christine
"""
import numpy as np
import config
from numerical_utils import safe_inv, sanitize_sigma
from omega import compute_curvature_gradient_analytical, d_exp_phi_exact
from natural_gradient import dexpinv_operator, compute_fisher_geometry_gradient

from numerical_utils import safe_inv, soft_clip_phi_norm
import numpy as np

from numerical_utils import safe_inv, sanitize_sigma

from natural_gradient import dexpinv_operator
from omega import d_exp_phi_exact, d_exp_phi_tilde_exact

import config   

#==============================================================================
#
#                    GATHER PHI GAUGE FIELD GRADIENT TERMS
#                          Beliefs and Models
#==============================================================================


def accumulate_phi_gradient_belief(agent_i, agent_j, generators, params, debug=False):
    """
    Compute and apply natural gradient:
        ∇_{φ_i} KL(q_i || Ω_ij q_j)
        ∇_{φ_j} KL(q_i || Ω_ij q_j)
    using exact ∂Ω/∂φ gradients, natural projection, and dexpinv correction.
    Uses (μ, Σ) parameterization.
    """
    beta = params.get("beta", config.beta)
    if beta <= 0:
        return

    eps = config.support_cutoff_eps
    joint_mask = (agent_i.mask > eps) & (agent_j.mask > eps)
    joint_mask = joint_mask.astype(float)[..., None]

    mu_qi, sigma_qi = agent_i.mu_q_field, agent_i.sigma_q_field
    mu_qj, sigma_qj = agent_j.mu_q_field, agent_j.sigma_q_field

    phi_i = agent_i.phi
    phi_j = agent_j.phi
    exp_phi_i = agent_i._exp_phi
    exp_phi_j = agent_j._exp_phi
    exp_neg_phi_j = agent_j._exp_neg_phi

    Omega_ij = agent_i.Omega_cache[agent_j.id]

    # ── Shared pushforward terms ─────────────────────────────
    mu_j_t = np.einsum("...ij,...j->...i", Omega_ij, mu_qj)
    delta_mu = mu_qi - mu_j_t

    Omega_T = np.swapaxes(Omega_ij, -1, -2)
    sigma_j_t = np.einsum("...ik,...kl,...lj->...ij", Omega_ij, sigma_qj, Omega_T)
    sigma_j_t = sanitize_sigma(sigma_j_t, eps=config.eps)
    sigma_j_inv = safe_inv(sigma_j_t, eps=config.eps)


    # ── ∇_φ_i ───────────────────────────────────────────────
    grad_phi_i_raw = grad_kl_wrt_phi_i(
        mu_qi, sigma_qi,
        mu_qj, sigma_qj,
        phi_i=phi_i,
        phi_j=phi_j,
        Omega_ij=Omega_ij,
        generators=generators,
        exp_phi_i=exp_phi_i,
        exp_phi_j=exp_phi_j,
        mu_j_t=mu_j_t,
        sigma_j_t_inv=sigma_j_inv,
        eps=config.eps
    )


    # ── Natural projection and dexpinv ───────────────────────
    F_inv_i = agent_i.inverse_fisher_phi
  
    grad_phi_i_nat = np.einsum("...ab,...b->...a", F_inv_i, grad_phi_i_raw)


    grad_phi_i = dexpinv_operator(phi_i, grad_phi_i_nat, generators)
 

    # ── Regularization on φᵢ only ───────────────────────────
    reg_grad_i = apply_regularization_terms_lie_natural(
        agent=agent_i,
        phi_field=phi_i,
        generators=generators,
        field="phi",
        params=params,
    )
    reg_grad_i *= joint_mask


    agent_i.grad_phi += (beta * grad_phi_i + reg_grad_i) * joint_mask
     
    #print(f"[phi_i grad] norm belief = {np.mean(np.linalg.norm(grad_phi_i, axis=-1)):.2e}")
    #print(f"[phi_j grad] norm belief = {np.mean(np.linalg.norm(grad_phi_j, axis=-1)):.2e}\n\n")


def accumulate_phi_gradient_model(agent_i, agent_j, generators, params, debug=False):
    """
    Compute and apply natural gradient:
        ∇_{φ̃_i} KL(p_i || Ω̃_ij p_j)
        ∇_{φ̃_j} KL(p_i || Ω̃_ij p_j)
    using exact ∂Ω̃/∂φ̃ gradients, Fisher projection, and dexpinv correction.
    """
    beta_model = params.get("beta_model", config.beta_model)
    if beta_model <= 0:
        return

    eps = config.support_cutoff_eps
    joint_mask = (agent_i.mask > eps) & (agent_j.mask > eps)
    joint_mask = joint_mask.astype(float)[..., None]

    mu_pi, sigma_pi = agent_i.mu_p_field, agent_i.sigma_p_field
    mu_pj, sigma_pj = agent_j.mu_p_field, agent_j.sigma_p_field

    phi_i = agent_i.phi_model
    phi_j = agent_j.phi_model
    exp_phi_i = agent_i._exp_phi_model
    exp_phi_j = agent_j._exp_phi_model
    exp_neg_phi_j = agent_j._exp_neg_phi_model

    Omega_tilde_ij = agent_i.Omega_tilde_cache[agent_j.id]

    
    F_inv_i = agent_i.inverse_fisher_phi_model
    F_inv_j = agent_j.inverse_fisher_phi_model

    # ── Precompute shared transport quantities ──────────────
    mu_j_t = np.einsum("...ij,...j->...i", Omega_tilde_ij, mu_pj)
    delta_mu = mu_pi - mu_j_t

    Omega_T = np.swapaxes(Omega_tilde_ij, -1, -2)
    sigma_j_t = np.einsum("...ik,...kl,...lj->...ij", Omega_tilde_ij, sigma_pj, Omega_T)
    sigma_j_t = sanitize_sigma(sigma_j_t, eps=config.eps)
    sigma_j_inv = safe_inv(sigma_j_t, eps=config.eps)

    # ∂KL(pᵢ || Ω̃ pⱼ) w.r.t. φ̃ᵢ
    grad_phi_tilde_i_raw = grad_kl_wrt_phi_i(
        mu_pi, sigma_pi,
        mu_pj, sigma_pj,
        phi_i=phi_i,
        phi_j=phi_j,
        Omega_ij=Omega_tilde_ij,
        generators=generators,
        exp_phi_i=exp_phi_i,
        exp_phi_j=exp_phi_j,
        mu_j_t=mu_j_t,
        sigma_j_t_inv=sigma_j_inv,
        eps=config.eps,
    )

    # ── Natural gradient projection and dexpinv ─────────────
    grad_phi_tilde_i_nat = np.einsum("...ab,...b->...a", F_inv_i, grad_phi_tilde_i_raw)
  

    grad_phi_tilde_i = dexpinv_operator(phi_i, grad_phi_tilde_i_nat, generators)
  

    # ── Regularize φ̃ᵢ only ─────────────────────────────────
    reg_grad_i = apply_regularization_terms_lie_natural(
        agent=agent_i,
        phi_field=phi_i,
        generators=generators,
        field="phi_model",
        params=params,
    )
    reg_grad_i *= joint_mask

    agent_i.grad_phi_tilde += (beta_model * grad_phi_tilde_i + reg_grad_i) * joint_mask
     
    #print(f"[phi_i grad] norm model = {np.mean(np.linalg.norm(grad_phi_tilde_i, axis=-1)):.2e}")
   # print(f"[phi_j grad] norm belief = {np.mean(np.linalg.norm(grad_phi_tilde_j, axis=-1)):.2e}\n\n")


def accumulate_phi_gradient_from_morphism_self_and_feedback(agent_i, generators_p, generators_q, params, debug=False):
    """
    Accumulate ∇_φ from:
      - KL(q || Φ̃·p)    ← self-energy (belief)
      - KL(p || Φ·q)     ← feedback (model)
    into:
      - agent_i.grad_phi
    """
   

    alpha   = params.get("alpha", config.alpha)
    lambda_ = params.get("feedback_weight", config.feedback_weight)
    if alpha <= 0 and lambda_ <= 0:
        return

    eps  = config.support_cutoff_eps
    mask = (agent_i.mask > eps)[..., None]  # (H, W, 1)

    mu_q, sigma_q = agent_i.mu_q_field, agent_i.sigma_q_field
    mu_p, sigma_p = agent_i.mu_p_field, agent_i.sigma_p_field
    phi, phi_tilde = agent_i.phi, agent_i.phi_model

   
        # ───── Self-energy gradient: ∇_φ KL(q || Φ̃·p) ← direct method ─────
    if alpha > 0:
        grad_phi_self = grad_kl_self_phi_direct(
            mu_q=mu_q, sigma_q=sigma_q,
            mu_p=mu_p, sigma_p=sigma_p,
            Phi_tilde_0=agent_i.Phi_tilde_0,
            phi=phi,
            phi_tilde=phi_tilde,
            generators_q=generators_q,
            generators_p=generators_p,
            exp_phi=agent_i._exp_phi,
            exp_phi_tilde=agent_i._exp_phi_model,
            eps=eps
        )
       #@ print(f"[phi grad] raw ∇_φ̃ KL(q ‖ Φ̃p) = {np.linalg.norm(grad_phi_self):.2e}", flush=True)
        G_inv = agent_i.inverse_fisher_phi
        grad_phi_self = np.einsum("...ab,...b->...a", G_inv, grad_phi_self)
        grad_phi_self = dexpinv_operator(phi, grad_phi_self, generators_q)
        #grad_phi_self = clip_gradient_norm(grad_phi_self, config.phi_grad_clip)

        grad_phi_self *= mask
        agent_i.grad_phi += alpha * grad_phi_self
        #print(f"[phi grad] after nat + dexpinv = {np.linalg.norm(grad_phi_self):.2e}", flush=True)


        # ───── Feedback gradient: ∇_φ KL(p || Φ·q) ← use direct method ─────
    if lambda_ > 0:
        grad_phi_feedback = grad_kl_feedback_phi_direct(
            mu_p=mu_p, sigma_p=sigma_p,
            mu_q=mu_q, sigma_q=sigma_q,
            Phi_0=agent_i.Phi_0,
            phi=phi, phi_tilde=phi_tilde,
            generators_q=generators_q,
            exp_phi=agent_i._exp_phi,
            exp_phi_tilde=agent_i._exp_phi_model,
            eps=eps
        )

        # Apply natural gradient (F⁻¹), dexp⁻¹, clipping, masking
       # print(f"[phi grad] raw ∇_φ KL(p ‖ Φq) = {np.linalg.norm(grad_phi_feedback):.2e}", flush=True)
        
        grad_phi_feedback = np.einsum("...ab,...b->...a", G_inv, grad_phi_feedback)
        grad_phi_feedback = dexpinv_operator(phi, grad_phi_feedback, generators_q)
    
        #grad_phi_feedback = clip_gradient_norm(grad_phi_feedback, config.phi_grad_clip)
        grad_phi_feedback *= mask
        
        
        agent_i.grad_phi += lambda_ * grad_phi_feedback



def accumulate_phi_tilde_gradient_from_morphism_self_and_feedback(agent_i, generators_p, generators_q, params, debug=False):
    """
    Accumulate ∇_{φ̃} from:
      - KL(q || Φ̃·p)    ← self-energy (belief)
      - KL(p || Φ·q)     ← feedback (model)
    into:
      - agent_i.grad_phi_tilde
    """
    

    alpha   = params.get("alpha", config.alpha)
    lambda_ = params.get("feedback_weight", config.feedback_weight)
    if alpha <= 0 and lambda_ <= 0:
        return

    eps  = config.support_cutoff_eps
    mask = (agent_i.mask > eps)[..., None]  # (H, W, 1)

    mu_q, sigma_q = agent_i.mu_q_field, agent_i.sigma_q_field
    mu_p, sigma_p = agent_i.mu_p_field, agent_i.sigma_p_field
    phi, phi_tilde = agent_i.phi, agent_i.phi_model



       # ───── Self-energy gradient: ∇_{φ̃} KL(q || Φ̃·p) ← direct method ─────
    if alpha > 0:
        grad_phi_tilde_self = grad_kl_self_phi_tilde_direct(
            mu_q=mu_q, sigma_q=sigma_q,
            mu_p=mu_p, sigma_p=sigma_p,
            Phi_tilde_0=agent_i.Phi_tilde_0,
            phi=phi,
            phi_tilde=phi_tilde,
            generators_q=generators_q,
            generators_p=generators_p,
            exp_phi=agent_i._exp_phi,
            exp_phi_tilde=agent_i._exp_phi_model,
            eps=eps
        )
       # print(f"[phi_tilde grad] raw ∇_φ̃ KL(q ‖ Φ̃p) = {np.linalg.norm(grad_phi_tilde_self):.2e}", flush=True)
        G_inv_tilde = agent_i.inverse_fisher_phi_model
        grad_phi_tilde_self = np.einsum("...ab,...b->...a", G_inv_tilde, grad_phi_tilde_self)
        grad_phi_tilde_self = dexpinv_operator(phi_tilde, grad_phi_tilde_self, generators_p)
        
        #grad_phi_tilde_self = clip_gradient_norm(grad_phi_tilde_self, config.phi_grad_clip)
        grad_phi_tilde_self *= mask
        agent_i.grad_phi_tilde += alpha * grad_phi_tilde_self
       # print(f"[phi_tilde grad] after nat + dexpinv = {np.linalg.norm(grad_phi_tilde_self):.2e}\n\n", flush=True)


        # ───── Feedback gradient: ∇_{φ̃} KL(p || Φ·q) ← direct method ─────
    if lambda_ > 0:
        grad_phi_tilde_feedback = grad_kl_feedback_phi_tilde_direct(
            mu_p=mu_p, sigma_p=sigma_p,
            mu_q=mu_q, sigma_q=sigma_q,
            Phi_0=agent_i.Phi_0,
            phi=phi,
            phi_tilde=phi_tilde,
            generators_p=generators_p,
            generators_q=generators_q,
            exp_phi=agent_i._exp_phi,
            exp_phi_tilde=agent_i._exp_phi_model,
            eps=eps
        )

       # print(f"[phi grad] raw ∇_φ KL(p ‖ Φq) = {np.linalg.norm(grad_phi_tilde_feedback):.2e}", flush=True)

        G_inv_tilde = agent_i.inverse_fisher_phi_model
        grad_phi_tilde_feedback = np.einsum("...ab,...b->...a", G_inv_tilde, grad_phi_tilde_feedback)
        grad_phi_tilde_feedback = dexpinv_operator(phi_tilde, grad_phi_tilde_feedback, generators_p)
        #grad_phi_tilde_feedback = clip_gradient_norm(grad_phi_tilde_feedback, config.phi_grad_clip)

        grad_phi_tilde_feedback *= mask
       
        agent_i.grad_phi_tilde += lambda_ * grad_phi_tilde_feedback



#################################################################################


#==============================================================================
#
#                    WITH RESPECT TO phi_i TERMS
#                       VALIDATED
#==============================================================================
def grad_kl_wrt_phi_iFAST(
    mu_i, sigma_i,
    mu_j, sigma_j,
    phi_i, phi_j,
    Omega_ij,
    generators,
    exp_phi_i,
    exp_phi_j,
    mu_j_t=None,
    sigma_j_t_inv=None,
    eps=1e-8,
):
    """
    Fully vectorized ∇_{φ_i} KL(q_i || Ω_ij q_j) without explicit loop.
    """
    d, K, _ = generators.shape
    shape = mu_i.shape[:-1]

    Omega_T = Omega_ij.swapaxes(-1, -2)

    if mu_j_t is None:
        mu_j_t = np.einsum("...ij,...j->...i", Omega_ij, mu_j)

    delta_mu = mu_i - mu_j_t

    if sigma_j_t_inv is None:
        sigma_j_t = np.einsum("...ik,...kl,...lj->...ij", Omega_ij, sigma_j, Omega_T)
        sigma_j_t = sanitize_sigma(sigma_j_t, eps)
        sigma_j_t_inv = safe_inv(sigma_j_t, eps)

    d_exp_phi_i_all = d_exp_phi_exact(phi_i, generators)  # shape (..., d, K, K)
    Q_i = d_exp_phi_i_all                                 # (..., d, K, K)
    Q_i_T = Q_i.swapaxes(-1, -2)                          # (..., d, K, K)

    # ───── Trace term ─────
    # trace_term = -½ Tr[(Σ⁻¹ Q + Qᵀ Σ⁻¹) Σ]
    term1 = np.einsum("...ij,...djk,...ki->...d", sigma_j_t_inv, Q_i, sigma_i)
    term2 = np.einsum("...dij,...jk,...ki->...d", Q_i_T, sigma_j_t_inv, sigma_i)
    trace_term = -0.5 * (term1 + term2)  # (..., d)

    # ───── Mean term ─────
    # tmp = Qᵢᵀ Δμ
    tmp = np.einsum("...dij,...j->...di", Q_i_T, delta_mu)
    # proj = Σ⁻¹ tmp
    proj = np.einsum("...ij,...dj->...di", sigma_j_t_inv, tmp)
    # final contraction: μⱼᵀ Ωᵀ proj
    tmp2 = np.einsum("...j,...ij->...i", mu_j, Omega_T)  # (..., K)
    mean_term = -np.einsum("...i,...di->...d", tmp2, proj)  # (..., d)

    # ───── Mahalanobis term ─────
    v1 = np.einsum("...ij,...j->...i", sigma_j_t_inv, delta_mu)       # (..., K)
    part1 = np.einsum("...dij,...j->...di", Q_i_T, v1)                # (..., d, K)

    v2 = np.einsum("...dij,...j->...di", Q_i, delta_mu)               # (..., d, K)
    part2 = np.einsum("...ij,...dj->...di", sigma_j_t_inv, v2)       # (..., d, K)

    sum_part = part1 + part2                                         # (..., d, K)
    mahalanobis_term = 0.5 * np.einsum("...i,...di->...d", delta_mu, sum_part)

    # Combine terms
    grad = trace_term + mean_term + mahalanobis_term  # (..., d)

    return grad



def grad_kl_wrt_phi_i(
    mu_i, sigma_i,
    mu_j, sigma_j,
    phi_i, phi_j,
    Omega_ij,
    generators,
    exp_phi_i,
    exp_phi_j,
    mu_j_t=None,
    sigma_j_t_inv=None,
    eps=1e-8,
):
    """
    Compute ∂/∂φ_i^a KL(q_i || Ω_ij q_j)
    using boxed expression:
        ∇_φᵢ KL = 
            -½ Tr[(Σ_ij⁻¹ Qᵢ + Qᵢᵀ Σ_ij⁻¹) Σᵢ]
            - μⱼᵀ Ωᵢⱼᵀ Qᵢᵀ Σ_ij⁻¹ Δμ
            + ½ Δμᵀ (Qᵢᵀ Σ_ij⁻¹ + Σ_ij⁻¹ Qᵢ) Δμ
    """
    d, K, _ = generators.shape
    shape = mu_i.shape[:-1]

    Omega_ij_T = Omega_ij.swapaxes(-1, -2)

    if mu_j_t is None:
        mu_j_t = np.einsum("...ij,...j->...i", Omega_ij, mu_j)

    delta_mu = mu_i - mu_j_t

    if sigma_j_t_inv is None:
        sigma_j_t = np.einsum("...ik,...kl,...lj->...ij", Omega_ij, sigma_j, Omega_ij_T)
        sigma_j_t = sanitize_sigma(sigma_j_t, eps)
        sigma_j_t_inv = safe_inv(sigma_j_t, eps)

    grad = np.zeros((*shape, d), dtype=mu_i.dtype)
    d_exp_phi_i_all = d_exp_phi_exact(phi_i, generators)

    for a in range(d):
        Q_i = d_exp_phi_i_all[a]
        Q_i_T = np.swapaxes(Q_i, -1, -2)

        # Trace term: -½ Tr[(Σ_ij⁻¹ Qᵢ + Qᵢᵀ Σ_ij⁻¹) Σᵢ]
        trace_term = -0.5 * np.einsum(
            "...ij,...jk,...ki->...",
            sigma_j_t_inv, Q_i, sigma_i
        ) - 0.5 * np.einsum(
            "...ij,...jk,...ki->...",
            Q_i_T, sigma_j_t_inv, sigma_i
        )

        # Mean transport term: -μ_jᵀ Ωᵢⱼᵀ Qᵢᵀ Σ⁻¹ Δμ
        tmp = np.einsum("...jk,...k->...j", Q_i_T, delta_mu)
        mean_term = -np.einsum(
            "...j,...jk,...k->...",
            mu_j, Omega_ij_T, np.einsum("...jk,...k->...j", sigma_j_t_inv, tmp)
        )

        # Mahalanobis term: +½ Δμᵀ (Qᵢᵀ Σ⁻¹ + Σ⁻¹ Qᵢ) Δμ
        v1 = np.einsum("...ij,...j->...i", sigma_j_t_inv, delta_mu)
        part1 = np.einsum("...ij,...j->...i", Q_i_T, v1)

        v2 = np.einsum("...ij,...j->...i", Q_i, delta_mu)
        part2 = np.einsum("...ij,...j->...i", sigma_j_t_inv, v2)

        mahalanobis_term = 0.5 * np.einsum("...i,...i->...", delta_mu, part1 + part2)

        grad[..., a] = trace_term + mean_term + mahalanobis_term

    return grad




#==============================================================================
#                   IF RUNNING THE REVERSE LOOP
#                    WITH RESPECT TO PHI_J TERMS
#
#==============================================================================
def grad_kl_wrt_phi_j(
    mu_i, sigma_i,
    mu_j, sigma_j,
    phi_j, phi_i,
    Omega_ij,
    generators,
    exp_phi_j,
    exp_phi_i,
    mu_j_t=None,
    sigma_j_t_inv=None,
    eps=1e-8
):
    """
    Compute ∂/∂φ_j^a D_KL(q_i || Ω_ij q_j), where:

        - q_i ~ 𝒩(μ_i, Σ_i)           # belief
        - q_j ~ 𝒩(μ_j, Σ_j)           # transported target
        - Ω_ij = exp(φ_i) · exp(−φ_j)
        - ∂Ω_ij / ∂φ_j^a = −Ω_ij · Q_j^a
        with Q_j^a = ∂ exp(φ_j) / ∂ φ_j^a

        - μ_j^Ω = Ω_ij μ_j
        - Σ_j^Ω = Ω_ij Σ_j Ω_ijᵀ
        - Δμ = μ_i − μ_j^Ω
    
    The boxed expression is:

        ∂/∂φ_j^a KL(q_i || Ω_ij q_j) =

        −½ · Tr[ (Σ_j^Ω⁻¹ · Q̄_j + Q̄_jᵀ · Σ_j^Ω⁻¹) · Σ_i ]
        + μ_jᵀ · Q̄_jᵀ · Σ_j^Ω⁻¹ · Δμ
        + ½ · Δμᵀ · (Q̄_jᵀ · Σ_j^Ω⁻¹ + Σ_j^Ω⁻¹ · Q̄_j) · Δμ

    where:
        - Q̄_j := Ω_ij · Q_j^a ∈ ℝ^{K_i × K_j}
        is the pushforward of ∂Ω/∂φ_j^a into q_i's fiber

        All terms are computed in the fiber space of q_i.
    """

    d, K, _ = generators.shape
    shape = mu_i.shape[:-1]

    Omega_T = Omega_ij.swapaxes(-1, -2)

    if mu_j_t is None:
        mu_j_t = np.einsum("...ij,...j->...i", Omega_ij, mu_j)

    delta_mu = mu_i - mu_j_t

    if sigma_j_t_inv is None:
        sigma_ij = np.einsum("...ik,...kl,...lj->...ij", Omega_ij, sigma_j, Omega_T)
        sigma_ij = sanitize_sigma(sigma_ij, eps)
        sigma_j_t_inv = safe_inv(sigma_ij, eps)

    grad = np.zeros((*shape, d), dtype=mu_i.dtype)
    d_exp_phi_j_all = d_exp_phi_exact(phi_j, generators)

    for a in range(d):
        Q_j = d_exp_phi_j_all[a]                        # (..., K, K)
        Q_j_bar = np.einsum("...ik,...kj->...ij", Omega_ij, Q_j)   # (..., K, K)
        Q_j_bar_T = np.swapaxes(Q_j_bar, -1, -2)

        # Trace term: -½ Tr[(Σ⁻¹ Q + Qᵀ Σ⁻¹) Σᵢ]
        trace1 = -0.5 * np.einsum("...ij,...jk,...ki->...", sigma_j_t_inv, Q_j_bar, sigma_i)
        trace2 = -0.5 * np.einsum("...ij,...jk,...ki->...", Q_j_bar_T, sigma_j_t_inv, sigma_i)
        trace_term = trace1 + trace2

        v = np.einsum("...ij,...j->...i", sigma_j_t_inv, delta_mu)   
        tmp = np.einsum("...ji,...i->...j", Q_j_bar, v)               
        mean_term = np.einsum("...j,...j->...", mu_j, tmp)            


        # Mahalanobis term: +½ Δμᵀ (Qᵀ Σ⁻¹ + Σ⁻¹ Q) Δμ
        v1 = np.einsum("...ij,...j->...i", Q_j_bar_T, np.einsum("...ij,...j->...i", sigma_j_t_inv, delta_mu))
        tmp2 = np.einsum("...ij,...j->...i", Q_j_bar, delta_mu)
        v2 = np.einsum("...ij,...j->...i", sigma_j_t_inv, tmp2)
        maha_term = 0.5 * np.einsum("...i,...i->...", delta_mu, v1 + v2)


        grad[..., a] = trace_term + mean_term + maha_term

    return grad


def grad_kl_feedback_phi_direct(
    mu_p, sigma_p,
    mu_q, sigma_q,
    Phi_0,
    phi,                # (..., d)
    phi_tilde,          # (..., d)
    generators_q,       # (d, K_q, K_q)
    exp_phi,            # (..., K_q, K_q)
    exp_phi_tilde,      # (..., K_p, K_p)
    eps=1e-8
):
    """
    Compute ∂/∂φ^a D_KL(p || Φ·q), where the bundle morphism is defined as:
        Φ = e^{φ̃} · Φ₀ · e^{-φ}

    and the gradient is taken with respect to φ (the belief-side Lie algebra field),
    using the identity:
        ∂Φ/∂φ^a = - e^{φ̃} · Φ₀ · Q^a,
    where Q^a = ∂ e^φ / ∂ φ^a.

    This evaluates:
        ∂/∂φ^a D_KL(p || Φ q)
        = − (∂Φ μ_q)ᵀ A⁻¹ Δμ
          − ½ Tr(A⁻¹ ∂A)
          + ½ Δμᵀ A⁻¹ ∂A A⁻¹ Δμ

    with:
        Δμ = μ_p − Φ μ_q,
        A = Φ Σ_q Φᵀ,
        ∂A = ∂Φ Σ_q Φᵀ + Φ Σ_q ∂Φᵀ.

    Args:
        mu_p         : (..., K_p) model mean
        sigma_p      : (..., K_p, K_p) model covariance
        mu_q         : (..., K_q) belief mean
        sigma_q      : (..., K_q, K_q) belief covariance
        Phi_0        : (..., K_p, K_q) static bundle morphism
        phi          : (..., d) Lie algebra parameters on the belief side
        phi_tilde    : (..., d) Lie algebra parameters on the model side
        generators_q : (d, K_q, K_q) Lie algebra generators for q
        exp_phi      : (..., K_q, K_q), e^{φ}
        exp_phi_tilde: (..., K_p, K_p), e^{φ̃}
        eps          : regularization constant

    Returns:
        grad_phi     : (..., d) gradient of KL divergence with respect to φ
    """
  

    d, K_q, _ = generators_q.shape
    K_p = mu_p.shape[-1]
    shape = mu_p.shape[:-1]

    # Compute full Φ = exp(φ̃) · Φ₀ · exp(−φ)
    exp_mphi = exp_phi.swapaxes(-1, -2)
    Phi = exp_phi_tilde @ Phi_0 @ exp_mphi        # (..., K_p, K_q)

    # A = Φ Σ_q Φᵀ
    A = Phi @ sigma_q @ np.swapaxes(Phi, -1, -2)
    A = sanitize_sigma(A, eps)
    A_inv = safe_inv(A, eps)

    delta_mu = mu_p - np.einsum("...ij,...j->...i", Phi, mu_q)

    # Compute Q^a = ∂e^φ / ∂φ^a
    d_exp_phi_all = d_exp_phi_exact(phi, generators_q)

    grad = np.zeros((*shape, d), dtype=mu_p.dtype)

    for a in range(d):
        Q_a = d_exp_phi_all[a]                          # (..., K_q, K_q)

        # ∂Φ = - e^{φ̃} Φ₀ Q^a
        dPhi = -Phi @ Q_a @ exp_mphi
         # (..., K_p, K_q)
        dPhi_T = np.swapaxes(dPhi, -1, -2)

        # ∂A = dΦ Σ_q Φᵀ + Φ Σ_q dΦᵀ
        dA = dPhi @ sigma_q @ np.swapaxes(Phi, -1, -2) + Phi @ sigma_q @ dPhi_T  # (..., K_p, K_p)

        # Term 1: −(dΦ μ_q)ᵀ A⁻¹ Δμ
        tmp1 = dPhi @ mu_q[..., None]                   # (..., K_p, 1)
        term1 = -np.einsum("...i,...i->...", tmp1[..., 0], (A_inv @ delta_mu[..., None])[..., 0])


        # Term 2: −½ Tr(A⁻¹ dA)
        term2 = -0.5 * np.einsum("...ij,...ji->...", A_inv, dA)

        # Term 3: ½ Δμᵀ A⁻¹ dA A⁻¹ Δμ
        AdA = A_inv @ dA @ A_inv
        term3 = 0.5 * np.einsum("...i,...ij,...j->...", delta_mu, AdA, delta_mu)

        grad[..., a] = term1 + term2 + term3


    return grad



def grad_kl_feedback_phi_tilde_direct(
    mu_p, sigma_p,
    mu_q, sigma_q,
    Phi_0,
    phi, phi_tilde,
    generators_p, generators_q,
    exp_phi, exp_phi_tilde,
    eps=1e-8
):
    """
    Compute ∂/∂φ̃^a D_KL(p || Φ q) where Φ = e^{φ̃} · Φ₀ · e^{-φ},
    with ∂Φ/∂φ̃^a = Q̃^a · Φ and Q̃^a = ∂ e^{φ̃} / ∂ φ̃^a.

    Specifically computes:

        ∂/∂φ̃^a D_KL(p || Φ q)
        = - (∂Φ μ_q)ᵀ A⁻¹ Δμ
          - ½ Tr(A⁻¹ ∂A)
          + ½ Δμᵀ A⁻¹ ∂A A⁻¹ Δμ
          - ½ Tr(A⁻¹ ∂A A⁻¹ Σ_p)

    where:
        Δμ = μ_p − Φ μ_q
        A = Φ Σ_q Φᵀ
        ∂Φ = Q̃^a · Φ
        ∂A = ∂Φ Σ_q Φᵀ + Φ Σ_q ∂Φᵀ

    Args:
        mu_p       : (..., K_p) model mean
        sigma_p    : (..., K_p, K_p) model covariance
        mu_q       : (..., K_q) belief mean
        sigma_q    : (..., K_q, K_q) belief covariance
        Phi_0      : (..., K_p, K_q) initial bundle morphism
        phi        : (..., d) belief Lie algebra φ
        phi_tilde  : (..., d) model Lie algebra φ̃
        generators_p: (d, K_p, K_p) Lie algebra basis for model fiber
        generators_q: (d, K_q, K_q) Lie algebra basis for belief fiber
        exp_phi    : (..., K_q, K_q) = e^{φ}
        exp_phi_tilde: (..., K_p, K_p) = e^{φ̃}
        eps        : regularization constant

    Returns:
        grad_phi_tilde: (..., d) gradient of KL with respect to φ̃
    """
    

    d, K_p, _ = generators_p.shape
    K_q = mu_q.shape[-1]
    shape = mu_p.shape[:-1]

    # Φ = e^{φ̃} Φ₀ e^{-φ}
    exp_mphi = np.swapaxes(exp_phi, -1, -2)
    Phi = exp_phi_tilde @ Phi_0 @ exp_mphi  # (..., K_p, K_q)

    # A = Φ Σ_q Φᵀ
    A = Phi @ sigma_q @ np.swapaxes(Phi, -1, -2)
    A = sanitize_sigma(A, eps)
    A_inv = safe_inv(A, eps)

    delta_mu = mu_p - np.einsum("...ij,...j->...i", Phi, mu_q)

    # Get all ∂e^{φ̃}/∂φ̃^a
    d_exp_phi_tilde_all = d_exp_phi_tilde_exact(phi_tilde, generators_p)

    grad = np.zeros((*shape, d), dtype=mu_p.dtype)

    for a in range(d):
        Q_tilde_a = d_exp_phi_tilde_all[a]         # (..., K_p, K_p)

        # ∂Φ = Q̃^a · Φ
        dPhi = Q_tilde_a @ Phi_0 @ exp_mphi
                    # (..., K_p, K_q)
        dPhi_T = np.swapaxes(dPhi, -1, -2)

        # ∂A = dΦ Σ_q Φᵀ + Φ Σ_q dΦᵀ
        dA = dPhi @ sigma_q @ np.swapaxes(Phi, -1, -2) + Phi @ sigma_q @ dPhi_T  # (..., K_p, K_p)

        # Term 1: −(∂Φ μ_q)ᵀ A⁻¹ Δμ
        tmp1 = dPhi @ mu_q[..., None]                           # (..., K_p, 1)
        term1 = -np.einsum("...i,...i->...", tmp1[..., 0], (A_inv @ delta_mu[..., None])[..., 0])


        # Term 2: −½ Tr(A⁻¹ dA)
        term2 = -0.5 * np.einsum("...ij,...ji->...", A_inv, dA)

        # Term 3: +½ Δμᵀ A⁻¹ dA A⁻¹ Δμ
        AdA = A_inv @ dA @ A_inv
        term3 = 0.5 * np.einsum("...i,...ij,...j->...", delta_mu, AdA, delta_mu)

        # Term 4: −½ Tr(A⁻¹ dA A⁻¹ Σ_p)
        AdA_Sp = AdA @ sigma_p
        term4 = -0.5 * np.einsum("...ij,...ji->...", A_inv, AdA_Sp)

        grad[..., a] = term1 + term2 + term3 + term4

    return grad





def grad_kl_self_phi_direct(
    mu_q, sigma_q,
    mu_p, sigma_p,
    Phi_tilde_0,
    phi, phi_tilde,
    generators_q, generators_p,
    exp_phi, exp_phi_tilde,
    eps=1e-8
):

    """
    Compute ∂/∂φ^a D_KL(q || Φ̃·p) where Φ̃ = e^{φ} Φ̃₀ e^{φ̃},
    with ∂Φ̃/∂φ^a = Q^a · Φ̃ and Q^a = ∂ e^{φ} / ∂ φ^a.

    Specifically computes:

        ∂/∂φ^a D_KL(q || Φ̃·p)
        = - (∂Φ̃ μ_p)^T A⁻¹ Δμ
          - ½ Tr(A⁻¹ ∂A)
          + ½ Δμᵀ A⁻¹ ∂A A⁻¹ Δμ
          - ½ Tr(A⁻¹ ∂A A⁻¹ Σ_q)

    where:
        Δμ = μ_q − Φ̃ μ_p
        A = Φ̃ Σ_p Φ̃ᵀ
        ∂Φ̃ = Q^a · Φ̃ e^phi~
        ∂A = ∂Φ̃ Σ_p Φ̃ᵀ + Φ̃ Σ_p ∂Φ̃ᵀ

    Args:
        mu_q       : (..., K_q) belief mean
        sigma_q    : (..., K_q, K_q) belief covariance
        mu_p       : (..., K_p) model mean
        sigma_p    : (..., K_p, K_p) model covariance
        Phi_tilde_0: (..., K_q, K_p) static morphism
        phi        : (..., d) belief-side Lie algebra
        phi_tilde  : (..., d) model-side Lie algebra
        generators_q: (d, K_q, K_q) Lie algebra generators for belief
        generators_p: (d, K_p, K_p) Lie algebra generators for model
        exp_phi    : (..., K_q, K_q), e^{φ}
        exp_phi_tilde: (..., K_p, K_p), e^{φ̃}
        eps        : regularization epsilon

    Returns:
        grad_phi: (..., d) gradient of KL divergence with respect to φ
    """
  

    d, K_q, _ = generators_q.shape
    K_p = mu_p.shape[-1]
    shape = mu_q.shape[:-1]

    # Φ̃ = e^{φ} Φ̃₀ e^{-φ̃}
    exp_mphi_tilde = exp_phi_tilde.swapaxes(-1, -2)
    Phi_tilde = exp_phi @ Phi_tilde_0 @ exp_mphi_tilde


    # A = Φ̃ Σ_p Φ̃ᵀ
    A = Phi_tilde @ sigma_p @ np.swapaxes(Phi_tilde, -1, -2)  # (..., K_q, K_q)
    A = sanitize_sigma(A, eps)
    A_inv = safe_inv(A, eps)

    delta_mu = mu_q - np.einsum("...ij,...j->...i", Phi_tilde, mu_p)  # (..., K_q)

    # Get ∂e^φ/∂φ^a
    d_exp_phi_all = d_exp_phi_exact(phi, generators_q)

    grad = np.zeros((*shape, d), dtype=mu_q.dtype)

    for a in range(d):
        Q_a = d_exp_phi_all[a]                       # (..., K_q, K_q)

        # ∂Φ̃ = Q^a · Φ̃
        dPhi = Q_a @ Phi_tilde_0 @ exp_mphi_tilde                      # (..., K_q, K_p)
        dPhi_T = np.swapaxes(dPhi, -1, -2)

        # ∂A = dΦ̃ Σ_p Φ̃ᵀ + Φ̃ Σ_p dΦ̃ᵀ
        dA = dPhi @ sigma_p @ Phi_tilde.swapaxes(-1, -2) + Phi_tilde @ sigma_p @ dPhi_T

        # Term 1: −(∂Φ̃ μ_p)^T A⁻¹ Δμ
        tmp1 = dPhi @ mu_p[..., None]                # (..., K_q, 1)
        tmp2 = A_inv @ delta_mu[..., None]        # (..., K_q, 1)
        term1 = -np.einsum("...i,...i->...", tmp1[..., 0], tmp2[..., 0])


        # Term 2: −½ Tr(A⁻¹ dA)
        term2 = -0.5 * np.einsum("...ij,...ji->...", A_inv, dA)

        # Term 3: ½ Δμᵀ A⁻¹ dA A⁻¹ Δμ
        AdA = A_inv @ dA @ A_inv
        term3 = 0.5 * np.einsum("...i,...ij,...j->...", delta_mu, AdA, delta_mu)

        # Term 4: −½ Tr(A⁻¹ dA A⁻¹ Σ_q)
        AdA_Sq = AdA @ sigma_q
        term4 = -0.5 * np.einsum("...ij,...ji->...", A_inv, AdA_Sq)

        grad[..., a] = term1 + term2 + term3 + term4

    return grad


def grad_kl_self_phi_tilde_direct(
    mu_q, sigma_q,
    mu_p, sigma_p,
    Phi_tilde_0,
    phi, phi_tilde,
    generators_q, generators_p,
    exp_phi, exp_phi_tilde,
    eps=1e-8
):
    """
    Compute ∂/∂φ̃^a D_KL(q || Φ̃·p) where Φ̃ = e^{φ} Φ̃₀ e^{φ̃},
    with ∂Φ̃/∂φ̃^a = -Φ̃ · Q̃^a, and Q̃^a = ∂ e^{φ̃} / ∂ φ̃^a.

    Specifically computes:

        ∂/∂φ̃^a D_KL(q || Φ̃·p)
        = - (∂Φ̃ μ_p)^T A⁻¹ Δμ
          - ½ Tr(A⁻¹ ∂A)
          + ½ Δμᵀ A⁻¹ ∂A A⁻¹ Δμ
          - ½ Tr(A⁻¹ ∂A A⁻¹ Σ_q)

    where:
        Δμ = μ_q − Φ̃ μ_p
        A = Φ̃ Σ_p Φ̃ᵀ
        ∂Φ̃ = -Φ̃ · Q̃^a
        ∂A = ∂Φ̃ Σ_p Φ̃ᵀ + Φ̃ Σ_p ∂Φ̃ᵀ

    Args:
        mu_q       : (..., K_q) belief mean
        sigma_q    : (..., K_q, K_q) belief covariance
        mu_p       : (..., K_p) model mean
        sigma_p    : (..., K_p, K_p) model covariance
        Phi_tilde_0: (..., K_q, K_p) static morphism
        phi        : (..., d) belief-side Lie algebra
        phi_tilde  : (..., d) model-side Lie algebra
        generators_q: (d, K_q, K_q) Lie algebra generators for belief
        generators_p: (d, K_p, K_p) Lie algebra generators for model
        exp_phi    : (..., K_q, K_q), e^{φ}
        exp_phi_tilde: (..., K_p, K_p), e^{φ̃}
        eps        : regularization epsilon

    Returns:
        grad_phi_tilde: (..., d) gradient of KL divergence with respect to φ̃
    """
   

    d, K_p, _ = generators_p.shape
    K_q = mu_q.shape[-1]
    shape = mu_q.shape[:-1]

    # Φ̃ = e^{φ} Φ̃₀ e^{-φ̃}
    exp_mphi_tilde = exp_phi_tilde.swapaxes(-1, -2)
    Phi_tilde = exp_phi @ Phi_tilde_0 @ exp_mphi_tilde


    # A = Φ̃ Σ_p Φ̃ᵀ
    A = Phi_tilde @ sigma_p @ np.swapaxes(Phi_tilde, -1, -2)  # (..., K_q, K_q)
    A = sanitize_sigma(A, eps)
    A_inv = safe_inv(A, eps)

    delta_mu = mu_q - np.einsum("...ij,...j->...i", Phi_tilde, mu_p)  # (..., K_q)

    # Get ∂e^{φ̃}/∂φ̃^a = Q̃^a
    d_exp_phi_tilde_all = d_exp_phi_tilde_exact(phi_tilde, generators_p)

    grad = np.zeros((*shape, d), dtype=mu_q.dtype)

    for a in range(d):
        Q_tilde_a = d_exp_phi_tilde_all[a]              # (..., K_p, K_p)

        # ∂Φ̃ = Φ̃ · Q̃^a
        
        dPhi = -Phi_tilde @ Q_tilde_a @ exp_mphi_tilde
    # (..., K_q, K_p)
        dPhi_T = np.swapaxes(dPhi, -1, -2)


        # ∂A = dΦ Σ_p Φ̃ᵀ + Φ̃ Σ_p dΦᵀ
        dA = dPhi @ sigma_p @ Phi_tilde.swapaxes(-1, -2) + Phi_tilde @ sigma_p @ dPhi_T

        # Term 1: −(∂Φ μ_p)^T A⁻¹ Δμ
        tmp1 = dPhi @ mu_p[..., None]                   # (..., K_q, 1)
        tmp2 = A_inv @ delta_mu[..., None]
        term1 = -np.einsum("...i,...i->...", tmp1[..., 0], tmp2[..., 0])


        # Term 2: −½ Tr(A⁻¹ dA)
        term2 = -0.5 * np.einsum("...ij,...ji->...", A_inv, dA)

        # Term 3: +½ Δμᵀ A⁻¹ dA A⁻¹ Δμ
        AdA = A_inv @ dA @ A_inv
        term3 = 0.5 * np.einsum("...i,...ij,...j->...", delta_mu, AdA, delta_mu)

        # Term 4: −½ Tr(A⁻¹ dA A⁻¹ Σ_q)
        AdA_Sq = AdA @ sigma_q
        term4 = -0.5 * np.einsum("...ij,...ji->...", A_inv, AdA_Sq)

        grad[..., a] = term1 + term2 + term3 + term4

    return grad

def apply_regularization_terms(
    phi, generators,
    curv_weight, mass_weight,
    morphism=None, fiber="phi",   # use "phi" or "phi_model"
    agent_i=None, agents=None,
    fisher_weight=0.0, params=None,
    eps=1e-8
):
    """
    Compute total φ or φ̃ regularization gradient in natural (Lie algebra) coordinates.
    Includes curvature, mass, and Fisher geometry terms.
    Uses provided `generators` and supports proper morphism conjugation.

    Args:
        phi           : (..., d)
        generators    : (d, K, K)
        curv_weight   : float, weight for curvature regularization
        mass_weight   : float, weight for mass penalty ‖φ‖²
        morphism      : optional morphism for fiber coupling (currently unused)
        fiber         : "phi" or "phi_model"
        agent_i       : current agent
        agents        : all agents
        fisher_weight : float, multiplies Fisher term (computed inside)
        params        : config params (only needed for Fisher)
        eps           : numerical stability constant

    Returns:
        grad_natural  : (..., d), regularization gradient in natural coordinates
    """
    if curv_weight == 0 and mass_weight == 0 and fisher_weight == 0:
        return np.zeros_like(phi)

    grad_euclidean = np.zeros_like(phi)

    if curv_weight > 0:
        grad_curv = compute_curvature_gradient_analytical(phi, generators)
        grad_euclidean += curv_weight * grad_curv

    if mass_weight > 0:
        grad_mass = 2 * phi
        grad_euclidean += mass_weight * grad_mass

    if fisher_weight > 0 and agent_i is not None and agents is not None:
        grad_fisher = compute_fisher_geometry_gradient(agent_i, agents, params, field=fiber)
        grad_euclidean += grad_fisher  # already weighted inside function

    return dexpinv_operator(phi, grad_euclidean, generators)




def apply_regularization_terms_lie_natural(
    agent,
    phi_field,
    generators,
    field,  # "phi" or "phi_model"
    params,
):
    """
    Compute φ or φ̃ regularization gradient in natural coordinates using agent-local fields.

    Args:
        agent      : the Agent object
        phi_field  : (..., K, K) — φ or φ̃ (current field)
        generators : (d, K, K)
        field      : "phi" or "phi_model"
        params     : dict of simulation/config params

    Returns:
        grad_nat   : (..., d) — projected natural gradient
    """
    eps = params.get("eps", config.eps)

    if field == "phi":
        curv_weight     = params.get("curvature_weight", config.curvature_weight)
        fisher_weight   = params.get("phi_fisher_weight", config.fisher_geometry_weight)
        mass_weight     = params.get("phi_mass_weight", config.belief_mass)
        phi             = phi_field
        morphism        = agent.bundle_morphism_q_to_p
        fiber           = "belief"
    elif field == "phi_model":
        curv_weight     = params.get("curvature_weight", config.model_curvature_weight)
        fisher_weight   = params.get("phi_fisher_weight", config.fisher_model_geometry_weight)
        mass_weight     = params.get("phi_model_mass_weight", config.model_mass)
        phi             = phi_field
        morphism        = agent.bundle_morphism_p_to_q
        fiber           = "model"
    else:
        raise ValueError(f"Invalid field name: {field}")

    return apply_regularization_terms(
        phi=phi,
        generators=generators,
        curv_weight=curv_weight,
        mass_weight=mass_weight,
        morphism=morphism,
        fiber=fiber,
        agent_i=agent,
        agents=params.get("agents", None),
        fisher_weight=fisher_weight,
        params=params,
        eps=eps,
    )






