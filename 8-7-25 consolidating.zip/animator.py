# -*- coding: utf-8 -*-
"""
Created on Wed Aug  6 16:56:37 2025

@author: chris and christine
"""

import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation
from pathlib import Path


# ─────────────────────────────────────────────────────────────────────────────
# Helper: Load sorted .npz files
# ─────────────────────────────────────────────────────────────────────────────
def load_field_sequence(folder):
    folder = Path(folder)
    files = sorted(folder.glob("step*.npz"))
    return [np.load(f) for f in files]


# ─────────────────────────────────────────────────────────────────────────────
# Main: Animate 2D field over time
# ─────────────────────────────────────────────────────────────────────────────
def animate_field(data_seq, field_name, output_path, vmin=None, vmax=None, cmap="viridis"):
    fig, ax = plt.subplots()
    img = ax.imshow(data_seq[0], origin="lower", cmap=cmap, vmin=vmin, vmax=vmax)
    ax.set_title(field_name)
    fig.colorbar(img, ax=ax)

    def update(i):
        img.set_data(data_seq[i])
        ax.set_title(f"{field_name}, step={i:03d}")
        return [img]

    ani = animation.FuncAnimation(fig, update, frames=len(data_seq), blit=False)
    ani.save(output_path, writer="pillow", fps=25)
    plt.close(fig)


# ─────────────────────────────────────────────────────────────────────────────
# Batch Extract + Animate
# ─────────────────────────────────────────────────────────────────────────────
def extract_scalar_field_sequence(loaded, key):
    return [f[key] for f in loaded if key in f]


def animate_all_scalar_fields(folder, output_dir):
    os.makedirs(output_dir, exist_ok=True)
    loaded = load_field_sequence(folder)

    fields_to_plot = [
        "belief_align",
        "model_align",
        "kl_self",
        "kl_feedback",
        "phi",
        "phi_model",
        "mu_q",
        "mu_p",
        "curv_tensor",
        "curv_model_tensor",
    ]

    for key in fields_to_plot:
        if key not in loaded[0]:
            print(f"[WARN] Field '{key}' not found in dump.")
            continue

        array_seq = extract_scalar_field_sequence(loaded, key)

        # Project to 2D scalar field for visualization
        if array_seq[0].ndim == 4:
            # (N, H, W, K) → mean over N and K
            array_seq = [np.nanmean(a, axis=(0, -1)) for a in array_seq]
        elif array_seq[0].ndim == 3:
            # (N, H, W) → mean over N
            array_seq = [np.nanmean(a, axis=0) for a in array_seq]
        elif array_seq[0].ndim == 5:
            # (N, H, W, K, K) → mean trace over N
            array_seq = [np.trace(a, axis1=-2, axis2=-1).mean(axis=0) for a in array_seq]

        outpath = Path(output_dir) / f"{key}.gif"
        animate_field(array_seq, key, outpath)


# ─────────────────────────────────────────────────────────────────────────────
# Example usage
# ─────────────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    input_folder = "checkpoints/fields"
    output_folder = "Holonomy_Visualizations/fields"
    animate_all_scalar_fields(input_folder, output_folder)
