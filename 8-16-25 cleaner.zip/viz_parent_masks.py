# viz_parent_masks.py
import os
import numpy as np
import matplotlib.pyplot as plt
import config










def _stack_child_support(children, shape, *, eps=1e-3):
    """Return (bool stack (N,H,W), ids). Support is (mask > eps), resized as needed."""
    import numpy as np
    from numerical_utils import resize_nn
    H, W = shape
    stacks, ids = [], []
    for ch in (children or []):
        m = getattr(ch, "mask", None)
        if m is None:
            continue
        M = np.asarray(m, np.float32)
        if M.shape != (H, W):
            M = resize_nn(M, (H, W)).astype(np.float32)
        stacks.append(M > float(eps))
        ids.append(int(getattr(ch, "id", len(ids))))
    if not stacks:
        return None, ()
    return np.stack(stacks, axis=0).astype(bool), tuple(ids)


def _masked_mean_over_kids(stack, support_stack):
    """
    Pixelwise mean over the *active* kids only.
    Returns (mean, count). If no active kids at a pixel, count=0 and mean is 0 (unused).
    """
    import numpy as np
    if stack is None or support_stack is None:
        return None, None
    S = support_stack.astype(np.float32)
    num = np.nansum(np.nan_to_num(stack, nan=0.0, posinf=0.0, neginf=0.0) * S, axis=0)
    den = np.maximum(S.sum(axis=0), 1.0)
    mean = num / den
    count = support_stack.sum(axis=0).astype(np.int32)
    return mean.astype(np.float32), count


def _ensure_dir(p):
    os.makedirs(p, exist_ok=True)

def _normalize01(x):
    x = np.asarray(x, dtype=float)
    if x.size == 0 or not np.isfinite(x).any():
        return np.zeros_like(x, dtype=float)
    x = x - np.nanmin(x)
    mx = np.nanmax(x)
    return x / (mx + 1e-12) if mx > 0 else np.zeros_like(x, dtype=float)

def _autogain_support(x, *, vis_floor=1e-2, lo_p=0.0, hi_p=98.0, gamma=1.1):
    """
    Autogain only over the mask support (x >= vis_floor). Returns:
      norm_img in [0,1], support boolean, (lo, hi) original-value range used.
    """
    x = np.asarray(x, dtype=float)
    supp = x >= vis_floor
    if not supp.any():
        return np.zeros_like(x), supp, (0.0, 1.0)

    vals = x[supp]
    lo = np.percentile(vals, lo_p)
    hi = np.percentile(vals, hi_p)
    if hi <= lo:
        y = np.zeros_like(x)
        y[supp] = 1.0
        return y, supp, (lo, hi)

    y = np.zeros_like(x)
    z = np.clip((x - lo) / (hi - lo), 0.0, 1.0)
    if gamma > 0 and gamma != 1.0:
        z = np.power(z, 1.0 / gamma)
    y[supp] = z[supp]
    return y, supp, (float(lo), float(hi))

def _blend_colors_max(masks_dict, *, floor=1e-3, cmap_name="magma"):
    """
    Combine masks for a single RGB image without changing brightness
    as the number of parents changes.
    - Uses per-pixel max over *raw* mask values (after floor),
      not sum/mean/auto-gain.
    - No per-parent normalization.
    """
    import numpy as np
    import matplotlib.cm as cm

    if not masks_dict:
        return np.zeros((1, 1, 3), dtype=np.float32)

    arrs = [np.asarray(m, np.float32) for m in masks_dict.values()]
    H, W = arrs[0].shape

    # floor tiny dust to zero before combine
    arrs = [np.where(a > float(floor), a, 0.0) for a in arrs]

    # per-pixel max
    I = np.maximum.reduce(arrs)
    I = np.clip(I, 0.0, 1.0)

    # map to RGB via colormap (no extra normalization)
    cmap = cm.get_cmap(cmap_name)
    rgba = cmap(I)                     # (H,W,4)
    rgb = rgba[..., :3].astype(np.float32)
    return rgb


# --- add near the top (PBC helpers) -------------------------------------------
def _com(mask):
    import numpy as np
    m = np.asarray(mask, np.float32)
    s = float(m.sum())
    if s <= 0: return 0.0, 0.0
    H, W = m.shape[:2]
    Y, X = np.indices((H, W), dtype=np.float32)
    return float((Y*m).sum()/s), float((X*m).sum()/s)

def _wrap_delta(d, L):
    # minimal signed displacement on a ring of length L ([-L/2, L/2))
    return (d + 0.5*L) % L - 0.5*L

def roll_center(mask, *, per_x=True, per_y=True):
    """Roll mask so its COM lands at the image center (PBC-correct view)."""
    import numpy as np
    m = np.asarray(mask, np.float32)
    H, W = m.shape[:2]
    yc, xc = _com(m)
    dy = int(round(_wrap_delta(yc - (H/2.0-0.5), H))) if per_y else int(round(yc - (H/2.0-0.5)))
    dx = int(round(_wrap_delta(xc - (W/2.0-0.5), W))) if per_x else int(round(xc - (W/2.0-0.5)))
    return np.roll(np.roll(m, -dy, axis=0), -dx, axis=1)





def _stack_child_field(children, attr, shape):
    import numpy as np
    from numerical_utils import resize_nn
    H, W = shape
    fields, ids = [], []
    for ch in (children or []):
        fld = getattr(ch, attr, None)
        if fld is None: 
            continue
        f = np.asarray(fld, np.float32)
        if f.shape != (H, W):
            f = resize_nn(f, (H, W)).astype(np.float32)
        fields.append(f); ids.append(int(getattr(ch, "id", len(ids))))
    if not fields:
        return None, ()
    return np.stack(fields, axis=0), tuple(ids)


def save_alignment_vs_parents(runtime_ctx, step, outdir, *, mode="agreement", cmap="viridis"):
    import os, numpy as np, matplotlib.pyplot as plt, config
    _ensure_dir(outdir)

    children = getattr(runtime_ctx, "children_latest", None)
    parents  = getattr(runtime_ctx, "parents_by_region", {}) or {}
    parents  = list(parents.values()) if isinstance(parents, dict) else list(parents)
    if not children:
        return
    H, W = np.asarray(children[0].mask).shape[:2]

    tau_q    = float(getattr(config, "tau_align_q", 0.45))
    tau_p    = float(getattr(config, "tau_align_p", 0.45))
    kl_cap   = float(getattr(config, "signal_kl_cap", 10.0))
    child_eps= float(getattr(config, "child_support_tau", 0.08))

    # Aggregates (preferred)
    Aq_agg      = getattr(runtime_ctx, "Aq_agg", None)
    Aq_support  = getattr(runtime_ctx, "Aq_support", None)     # bool mask (pairwise support)
    KLq_mean_ag = getattr(runtime_ctx, "KLq_mean_agg", None)

    use_agg = (Aq_agg is not None) or (KLq_mean_ag is not None)

    # Build a fallback **union-of-kids** mask (≥1 child active)
    def _union_of_kids():
        try:
            M_stack, _ = _stack_child_support(children, (H, W), eps=child_eps)
            if M_stack is None:
                return None
            return np.any(M_stack.astype(bool), axis=0)
        except Exception:
            return None

    # Choose the visualization mask:
    # 1) pairwise overlap (Aq_support) if it exists and has any pixels;
    # 2) otherwise, union of kids (≥1), if any;
    # 3) otherwise, None (don’t mask).
    viz_mask = None
    if isinstance(Aq_support, np.ndarray) and Aq_support.any():
        viz_mask = Aq_support.astype(bool)
    else:
        U = _union_of_kids()
        viz_mask = U if (isinstance(U, np.ndarray) and U.any()) else None

    KLq_mean = None
    KLp_mean = None
    Aq = None
    Ap = None

    if use_agg:
        # Agreement (belief): neutral (=1) outside pairwise support
        if Aq_agg is not None:
            Aq = np.ones((H, W), np.float32)
            if isinstance(Aq_support, np.ndarray) and Aq_support.any():
                Aq[Aq_support] = np.clip(np.asarray(Aq_agg, np.float32)[Aq_support], 0.0, 1.0)
        KLq_mean = KLq_mean_ag  # may contain NaNs where undefined
    else:
        # Legacy fallback: per-child caches
        KLq_stack, child_ids = _stack_child_field(children, "cached_alignment_kl", (H, W))
        KLp_stack, _         = _stack_child_field(children, "cached_model_alignment_kl", (H, W))
        M_stack,  _          = _stack_child_support(children, (H, W), eps=child_eps)
        KLq_mean, C = _masked_mean_over_kids(KLq_stack, M_stack)
        KLp_mean, _ = _masked_mean_over_kids(KLp_stack, M_stack)
        # pairwise-overlap mask if available from counts
        if isinstance(C, np.ndarray):
            viz_mask = C >= 2 if (viz_mask is None) else viz_mask

        def _to_A_from_KL(KL_mean, tau):
            if KL_mean is None:
                return None
            K = np.clip(np.asarray(KL_mean, np.float32), 0.0, kl_cap)
            A = np.exp(-K / max(1e-6, float(tau))).astype(np.float32)
            return A

        Aq = _to_A_from_KL(KLq_mean, tau_q)
        Ap = _to_A_from_KL(KLp_mean, tau_p)

    # Model-side KL/Agreement if desired
    if use_agg and (mode in ("agreement","kl")) and (Ap is None or KLp_mean is None):
        KLp_stack, _ = _stack_child_field(children, "cached_model_alignment_kl", (H, W))
        M_stack,  _  = _stack_child_support(children, (H, W), eps=child_eps)
        KLp_mean, _  = _masked_mean_over_kids(KLp_stack, M_stack)
        if KLp_mean is not None:
            Ap = np.exp(-np.clip(KLp_mean, 0.0, kl_cap) / max(1e-6, float(tau_p))).astype(np.float32)

    # Parent & child outlines
    thr = float(getattr(config, "parent_area_threshold",
                        getattr(config, "parent_growth_core_tau", 0.20)))
    parent_outlines = [(np.asarray(P.mask, float) > thr) for P in parents]
    child_outlines = []
    try:
        M_stack_plot, _ = _stack_child_support(children, (H, W), eps=child_eps)
        if M_stack_plot is not None:
            for k in range(M_stack_plot.shape[0]):
                child_outlines.append(M_stack_plot[k])
    except Exception:
        pass

    def _draw(field, title, subdir, vmin=None, vmax=None):
        if field is None: return
        _ensure_dir(os.path.join(outdir, subdir))
        plt.figure(figsize=(4, 4))
        ax = plt.gca()
        F = np.asarray(field, np.float32)
    
        # Mask: safer to fill with vmin, not NaN
        if isinstance(viz_mask, np.ndarray):
            mask = viz_mask.astype(bool)
            if vmin is None: vmin = np.nanmin(F)
            if vmax is None: vmax = np.nanmax(F)
            F = np.where(mask, F, vmin)
    
        # Autoscale if not given
        if vmin is None or vmax is None:
            vmin, vmax = np.nanmin(F), np.nanmax(F)
            if vmin == vmax: vmax = vmin + 1e-6
    
        im = ax.imshow(F, origin="upper", cmap=cmap, vmin=vmin, vmax=vmax)
    
        for ol in child_outlines:
            if np.asarray(ol).any():
                ax.contour(ol.astype(float), levels=[0.5], colors="gray", linewidths=0.4, alpha=0.6)
        if isinstance(viz_mask, np.ndarray) and viz_mask.any():
            ax.contour(viz_mask.astype(float), levels=[0.5], colors="red", linewidths=0.8)
        for ol in parent_outlines:
            if np.asarray(ol).any():
                ax.contour(ol.astype(float), levels=[0.5], colors="white", linewidths=0.5)
    
        ax.set_title(f"{title} (step {step})")
        ax.axis("off")
        plt.colorbar(im, fraction=0.046, pad=0.04)
        plt.tight_layout()
        path = os.path.join(outdir, subdir, f"step_{step:04d}.png")
        print("Saved:", path)
        plt.savefig(path, dpi=140)
        plt.close()


    if mode == "agreement":
        _draw(Aq, "Agreement (belief) + child/overlap + parent contours",
              "alignment_belief_vs_parents", vmin=0.0, vmax=1.0)
        _draw(Ap, "Agreement (model) + child/overlap + parent contours",
              "alignment_model_vs_parents", vmin=0.0, vmax=1.0)
    else:  # "kl"
        if KLq_mean is not None:
            _draw(np.clip(KLq_mean, 0.0, kl_cap), "KL mean (belief) on overlaps + contours",
                  "alignment_belief_vs_parents", vmin=0.0, vmax=kl_cap)
        if KLp_mean is not None:
            _draw(np.clip(KLp_mean, 0.0, kl_cap), "KL mean (model) on overlaps + contours",
                  "alignment_model_vs_parents", vmin=0.0, vmax=kl_cap)

    # NPZ snapshot (preferred aggregates + viz mask)
    npz_dir = os.path.join(outdir, "alignment_npz"); _ensure_dir(npz_dir)
    parent_ids = np.array([int(getattr(P, "id", i)) for i, P in enumerate(parents)], np.int32)
    parent_masks = np.stack([np.asarray(P.mask, np.float32) for P in parents], axis=0) if parents else np.zeros((0, H, W), np.float32)

    _Aq_npz  = (Aq if Aq is not None else (np.asarray(Aq_agg, np.float32) if Aq_agg is not None else np.ones((H, W), np.float32)))
    _KLq_npz = (KLq_mean if KLq_mean is not None else np.full((H, W), np.nan, np.float32))
    _mask_npz= (viz_mask.astype(np.bool_) if isinstance(viz_mask, np.ndarray) else np.zeros((H, W), np.bool_))
    _child_ids = np.array([getattr(c, "id", i) for i, c in enumerate(children)], np.int32)

    np.savez_compressed(
        os.path.join(npz_dir, f"step_{step:04d}.npz"),
        child_ids=_child_ids,
        KLq_mean=_KLq_npz,
        Aq=_Aq_npz.astype(np.float32),
        viz_mask=_mask_npz,
        parent_ids=parent_ids,
        parent_masks=parent_masks,
    )



def save_alignment_metrics_table(runtime_ctx, step, outdir):
    import os, csv, numpy as np
    os.makedirs(outdir, exist_ok=True)
    parents = getattr(runtime_ctx, "parents_by_region", {}) or {}
    parents = list(parents.values()) if isinstance(parents, dict) else list(parents)
    if not parents:
        return
    H, W = parents[0].mask.shape[:2]
    Aq = getattr(runtime_ctx, "Aq_agg", None)
    Ap = getattr(runtime_ctx, "Ap_agg", None)
    if Aq is None and Ap is None:
        return
    try:
        import config
        thrs = list(getattr(config, "align_eval_thresholds", [0.30, 0.45, 0.60]))
    except Exception:
        thrs = [0.30, 0.45, 0.60]

    def _metrics(A, Pmask, thr):
        if A is None: return (np.nan, np.nan, np.nan)
        M = (A >= thr)
        P = Pmask.astype(bool)
        inter = np.count_nonzero(M & P)
        union = np.count_nonzero(M | P)
        iou  = (inter / union) if union else 0.0
        prec = (inter / max(1, np.count_nonzero(M)))
        rec  = (inter / max(1, np.count_nonzero(P)))
        return (iou, prec, rec)

    rows = []
    for P in parents:
        pmask = (np.asarray(P.mask, np.float32) > 0.3)
        for side, A in (("belief", Aq), ("model", Ap)):
            for t in thrs:
                iou, pr, rc = _metrics(A, pmask, t)
                rows.append({
                    "step": step, "parent_id": int(getattr(P, "id", -1)),
                    "side": side, "tau": t,
                    "IoU": iou, "Precision": pr, "Recall": rc,
                })

    csv_path = os.path.join(outdir, f"alignment_metrics_step_{step:04d}.csv")
    with open(csv_path, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader(); w.writerows(rows)


def save_parent_mask_frame(runtime_ctx, step, outdir, draw_per_parent=True, *, child_eps=1e-3):
    """
    Save two PNGs for this step:
      1) combined overlay: parent_masks_combined/step_XXXX.png
      2) per-parent panel grid (with colorbars): parent_masks_panels/step_XXXX.png
    Adds lvl-0 child union border overlays for context.
    More robust: pulls parents from multiple possible containers on runtime_ctx.
    """
    import numpy as np
    import os
    import matplotlib.pyplot as plt
    import config
    thr = float(getattr(config, "parent_area_threshold",
                    getattr(config, "parent_growth_core_tau", 0.20)))




    def _collect_parents(ctx):
        # Try several canonical locations, accept dicts or lists, then dedup by id
        candidates = []

        # 1) parents_by_region
        store = getattr(ctx, "parents_by_region", None)
        if store is not None:
            if isinstance(store, dict):
                candidates.extend(list(store.values()))
            else:
                candidates.extend(list(store))

        # 2) parents (some runners keep a list here)
        store2 = getattr(ctx, "parents", None)
        if store2 is not None:
            if isinstance(store2, dict):
                candidates.extend(list(store2.values()))
            else:
                candidates.extend(list(store2))

        # 3) parents_latest (another common alias)
        store3 = getattr(ctx, "parents_latest", None)
        if store3 is not None:
            if isinstance(store3, dict):
                candidates.extend(list(store3.values()))
            else:
                candidates.extend(list(store3))

        # Dedup by .id if available; else by object id
        uniq = {}
        for p in candidates:
            pid = getattr(p, "id", id(p))
            uniq[pid] = p
        # Stable order: sort by numeric id if present
        try:
            keys = sorted(uniq.keys())
        except Exception:
            keys = list(uniq.keys())
        return [uniq[k] for k in keys]

    parents = _collect_parents(runtime_ctx)
    if not parents:
        # optional debug
        if getattr(config, "debug_parent_masks", False):
            print(f"[viz] step {step}: no parents found in ctx")
        
        return

    # --- child union (lvl-0) for border overlays ---
    children = getattr(runtime_ctx, "children_latest", None)
    if children is None and hasattr(runtime_ctx, "last_children"):
        children = getattr(runtime_ctx, "last_children")

    H, W = parents[0].mask.shape
    child_union = np.zeros((H, W), dtype=bool)
    if children:
        for ch in children:
            child_union |= (np.asarray(ch.mask, dtype=float) > float(child_eps))

    # Build mask dict
    masks = {getattr(P, "id", i): np.asarray(P.mask, dtype=float) for i, P in enumerate(parents)}

    # Debug: confirm how many parents we see here
    if getattr(config, "debug_parent_masks", True):
        print(f"[viz] step {step}: plotting {len(parents)} parents (keys={list(masks.keys())[:8]}{'...' if len(masks)>8 else ''})")
        mx = max(float(np.asarray(m).max()) for m in masks.values())
        print(f"[viz] step {step}: n_parents={len(parents)} max_mask={mx:.3f} thr={thr}\n\n\n\n")

    # 1) combined overlay (RGB blend) + child borders
    out1 = os.path.join(outdir, "parent_masks_combined")
    _ensure_dir(out1)
    rgb = _blend_colors_max(masks, floor=float(getattr(config, "viz_union_floor", 1e-3)))


    plt.figure(figsize=(4, 4))
    ax = plt.gca()
    ax.imshow(rgb, origin="upper")
    # after ax.imshow(rgb, ...)
    for P in parents:
        pm = np.asarray(P.mask, float)
        if (pm > thr).any():
            ax.contour((pm > thr).astype(float), levels=[0.5], colors="white", linewidths=0.6)

    
    
    # child union border overlay (thin light gray)
    if child_union.any():
        ax.contour(child_union.astype(float), levels=[0.5],
                   colors=[(0.85, 0.85, 0.85)], linewidths=0.8)
    ax.set_title(f"Parents (step {step}) | n={len(parents)}")
    ax.axis("off")
    plt.tight_layout()
    plt.savefig(os.path.join(out1, f"step_{step:04d}.png"), dpi=140)
    plt.close()

    if not draw_per_parent:
        return

    # 2) per-parent panels
    out2 = os.path.join(outdir, "parent_masks_panels")
    _ensure_dir(out2)

    cols = min(4, max(1, int(np.ceil(np.sqrt(len(parents))))))
    rows = int(np.ceil(len(parents) / cols))

    fig_w = 3.6 * cols  # a bit wider to fit cbar
    fig_h = 3.2 * rows
    fig, axes = plt.subplots(rows, cols, figsize=(fig_w, fig_h))
    if not isinstance(axes, np.ndarray):
        axes = np.array([[axes]])
    axes = axes.reshape(rows, cols)

    for idx, P in enumerate(parents):
        r, c = divmod(idx, cols)
        ax = axes[r, c]

        # Lower vis_floor so newborn (soft) masks show up reliably
        norm, supp, (lo, hi) = _autogain_support(P.mask, vis_floor=1e-4, lo_p=0.0, hi_p=98.0, gamma=1.1)
        im = ax.imshow(norm, cmap="magma", origin="upper", vmin=0, vmax=1, alpha=0.95)

        # overlay crisp parent support contour
        if supp.any():
            ax.contour(supp.astype(float), levels=[0.5], colors="white", linewidths=0.8)

        # overlay child union borders for context
        if child_union.any():
            ax.contour(child_union.astype(float), levels=[0.5],
                       colors=[(0.85, 0.85, 0.85)], linewidths=0.7)

        # colorbar with ticks mapped back to ORIGINAL mask values
        cbar = fig.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
        ticks = [0.0, 0.5, 1.0]
        mids = lo + 0.5 * (hi - lo)
        cbar.set_ticks(ticks)
        cbar.set_ticklabels([f"{lo:.2e}", f"{mids:.2e}", f"{hi:.2e}"])
        cbar.ax.set_ylabel("mask value (orig)", rotation=270, labelpad=10)

        wq = getattr(P, "lambda_q_weight", 0.0)
        kids = len(getattr(P, "child_ids", []))
        nz = int(np.count_nonzero(np.asarray(P.mask) > thr))  # was >= 1e-2

        ax.set_title(f"P{getattr(P,'id','?')}  wq={wq:.2f}  kids={kids}  nz≥1e-2={nz}", fontsize=9)
        ax.axis("off")

    # hide any empty subplots
    for idx in range(len(parents), rows * cols):
        r, c = divmod(idx, cols)
        axes[r, c].axis("off")

    fig.suptitle(f"Parent Masks (step {step})", y=0.995)
    fig.tight_layout()
    fig.savefig(os.path.join(out2, f"step_{step:04d}.png"), dpi=140)
    plt.close(fig)

# --- new, PBC-aware parent grid plotter ---------------------------------------
def plot_parent_masks_grid(runtime_ctx, step, outdir,
                           *, center_on_com=True, shared_scale=True, core_from="parent_area_threshold"):
    """
    PBC-aware parent grid:
      - rolls each parent mask to center (so seam-straddlers look contiguous)
      - shared color scale across panels (optional)
      - contours at a consistent 'core' threshold
    """
    import os, numpy as np, matplotlib.pyplot as plt, config
    Ps = list((runtime_ctx.parents_by_region or {}).values())
    if not Ps:
        return
    H, W = Ps[0].mask.shape[:2]
    per_x = bool(getattr(config, "periodic_x", False))
    per_y = bool(getattr(config, "periodic_y", False))

    # core threshold: use the same one you use for area/IoU elsewhere
    core_thr = float(getattr(config, core_from,
                    getattr(config, "parent_growth_core_tau", 0.20)))

    # prepare rolled masks and meta
    masks = []
    vmaxs = []
    titles = []
    for P in Ps:
        m = np.asarray(P.mask, np.float32)
        if center_on_com:
            m = roll_center(m, per_x=per_x, per_y=per_y)
        masks.append(m)
        vmaxs.append(float(np.nanmax(m)) if m.size else 1.0)
        k = len(getattr(P, "child_ids", ()))
        nz = int((m > core_thr).sum())
        titles.append(f"P{int(getattr(P,'id',-1))}  kids={k}  nz>{core_thr:g}={nz}")

    # global scale if requested
    vmin = 0.0
    vmax = float(np.nanpercentile(vmaxs, 99.0)) if shared_scale else None

    # grid shape
    n = len(Ps)
    cols = int(np.ceil(np.sqrt(n)))
    rows = int(np.ceil(n / cols))

    os.makedirs(outdir, exist_ok=True)
    fig = plt.figure(figsize=(4*cols, 4*rows))
    for i, m in enumerate(masks):
        ax = fig.add_subplot(rows, cols, i+1)
        im = ax.imshow(m, origin="upper", vmin=vmin, vmax=(vmax if vmax is not None else None), cmap="magma")
        # draw core contour
        if (m > core_thr).any():
            ax.contour((m > core_thr).astype(float), levels=[0.5], colors="white", linewidths=0.6)
        ax.set_title(titles[i], fontsize=10)
        ax.axis("off")
    # single shared colorbar when shared_scale=True
    cax = fig.add_axes([0.92, 0.15, 0.02, 0.7])
    fig.colorbar(im, cax=cax)
    fig.suptitle(f"Parent Masks (step {step})", y=0.98, fontsize=14)
    fig.tight_layout(rect=[0.0, 0.0, 0.90, 0.95])
    fig.savefig(os.path.join(outdir, f"parent_masks_step_{step:04d}.png"), dpi=140)
    plt.close(fig)

