# -*- coding: utf-8 -*-
"""
Created on Fri Aug 15 16:38:18 2025

@author: chris and christine
"""

# parent_semantics.py
import numpy as np
from typing import Dict, Iterable, Tuple



# Parent–child semantics
parent_active_level         = 0.5   # threshold to binarize float masks
parent_assign_iou_add_thr   = 0.05  # IoU to add a child
parent_assign_iou_keep_thr  = 0.03  # IoU to keep an assigned child
parent_assign_min_overlap_px= 1     # min overlapping pixels to consider
parent_orphan_grace_steps   = 5     # steps without any assigned kids before deletion flag
parent_freeze_steps         = 3     # steps after spawn during which seed cannot shrink
parent_seed_erode_iters     = 1     # derive seed from active via 4-neigh erosion
parent_active_min_cc_px     =1     # min CC size to keep
parent_active_iou_min       = 0.30  # IoU(active, union_assigned) gate; below => pull active to assigned
parent_hysteresis_keep_frac = 0.50  # when pulling, restore up to this fraction of dropped pixels



try:
    import config
except Exception:
    class _C: pass
    config = _C()

from parent_utils import _label4  # your toroidal CC

def _to_bool(a, thr: float) -> np.ndarray:
    a = np.asarray(a)
    if a.dtype == bool:
        return a
    return a >= float(thr)

def _iou(a: np.ndarray, b: np.ndarray) -> float:
    a = a.astype(bool, copy=False)
    b = b.astype(bool, copy=False)
    inter = np.count_nonzero(a & b)
    if inter == 0:
        # handle both zero
        return 1.0 if not a.any() and not b.any() else 0.0
    return inter / float(np.count_nonzero(a | b))

def _largest_cc(mask: np.ndarray, periodic: bool, prefer_overlap: np.ndarray = None) -> np.ndarray:
    """Return boolean mask of the largest 4-conn component (toroidal if periodic).
    If prefer_overlap is given, prefer component with max overlap with it."""
    if not mask.any():
        return mask
    labels = _label4(mask, periodic=bool(periodic))
    nlab = int(labels.max())
    if nlab <= 1:
        return mask
    best_lbl, best_score = 0, -1
    for lbl in range(1, nlab + 1):
        comp = (labels == lbl)
        score = int(comp.sum())
        if prefer_overlap is not None:
            score = (comp & prefer_overlap).sum() * (10**9) + score  # lexicographic prefer-overlap
        if score > best_score:
            best_score = score
            best_lbl = lbl
    return labels == best_lbl

def _erode4(mask: np.ndarray, iters: int, periodic: bool) -> np.ndarray:
    """Simple 4-neigh erosion with/without wrap."""
    m = mask.astype(bool, copy=True)
    for _ in range(max(0, int(iters))):
        if periodic:
            e = m.copy()
            e &= np.roll(m,  1, 0); e &= np.roll(m, -1, 0)
            e &= np.roll(m,  1, 1); e &= np.roll(m, -1, 1)
            m = e
        else:
            north = np.pad(m[1:, :],  ((0,1),(0,0)), constant_values=False)
            south = np.pad(m[:-1, :], ((1,0),(0,0)), constant_values=False)
            west  = np.pad(m[:, 1:],  ((0,0),(0,1)), constant_values=False)
            east  = np.pad(m[:, :-1], ((0,0),(1,0)), constant_values=False)
            m = m & north & south & west & east
    return m

def _union_of_children(children: Iterable, ids: Iterable[int], H: int, W: int, thr: float) -> np.ndarray:
    u = np.zeros((H, W), dtype=bool)
    for cid in ids:
        cm = _to_bool(children[cid].mask, thr)
        u |= cm
    return u


def reconcile_parent_masks_and_assignments(runtime_ctx, children, step: int, *, periodic: bool, H: int, W: int) -> None:
    """
    Enforce: (1) per-step child assignment by IoU with hysteresis,
             (2) seed vs active masks (freeze), and
             (3) minimal connected support under PBC.
    Keeps P.mask as a continuous field; uses P.active_mask as a boolean view.
    Mutates parent objects in runtime_ctx.parents_by_region in place.
    """
    import numpy as np
    import config

    parents: Dict[int, object] = getattr(runtime_ctx, "parents_by_region", {})
    if not parents:
        return

    # --- Config knobs ---------------------------------------------------------
    active_thr            = float(getattr(config, "parent_active_level", 0.5))
    add_iou_thr           = float(getattr(config, "parent_assign_iou_add_thr", 0.05))
    keep_iou_thr          = float(getattr(config, "parent_assign_iou_keep_thr", 0.03))
    min_overlap_px        = int(getattr(config, "parent_assign_min_overlap_px", 8))
    orphan_grace_steps    = int(getattr(config, "parent_orphan_grace_steps", 5))
    freeze_steps          = int(getattr(config, "parent_freeze_steps", 3))
    seed_erode_iters      = int(getattr(config, "parent_seed_erode_iters", 1))
    min_cc_px             = int(getattr(config, "parent_active_min_cc_px", 8))
    active_iou_min        = float(getattr(config, "parent_active_iou_min", 0.30))
    hysteresis_keep_frac  = float(getattr(config, "parent_hysteresis_keep_frac", 0.50))

    # Soft-mask dynamics
    eta_up    = float(getattr(config, "parent_eta_up", 0.25))      # grow speed
    eta_down  = float(getattr(config, "parent_eta_down", 0.20))    # shrink speed
    sigma     = float(getattr(config, "parent_feather_sigma", 1.0))
    delta_cap = float(getattr(config, "parent_delta_cap", 0.20))   # per-step |Δmask| cap

    # --- Precompute child bool masks and id map -------------------------------
    child_ids = [int(getattr(c, "id", i)) for i, c in enumerate(children)]
    child_mask_bool_by_id = {
        child_ids[i]: _to_bool(children[i].mask, active_thr) for i in range(len(children))
    }

    for pid, P in list(parents.items()):
        # --- init persistent fields -------------------------------------------
        if not hasattr(P, "active_mask"):
            P.active_mask = _to_bool(P.mask, active_thr)
        else:
            P.active_mask = _to_bool(P.active_mask, active_thr)

        if not hasattr(P, "seed_mask") or P.seed_mask is None or not np.any(P.seed_mask):
            seed0 = _erode4(P.active_mask, seed_erode_iters, periodic=periodic)
            if not seed0.any():
                seed0 = P.active_mask.copy()
            P.seed_mask = seed0.astype(np.float32)

        if not hasattr(P, "assigned_child_ids") or P.assigned_child_ids is None:
            P.assigned_child_ids = set()

        if not hasattr(P, "freeze_until"):
            P.freeze_until = int(step) + freeze_steps

        if not hasattr(P, "orphan_steps"):
            P.orphan_steps = 0

        # --- recompute assignment with hysteresis ------------------------------
        new_assign = set()
        for cid in child_ids:
            cm = child_mask_bool_by_id[cid]
            if not cm.any():
                continue
            inter = int((P.active_mask & cm).sum())
            if inter < min_overlap_px:
                continue
            iou_pc = _iou(P.active_mask, cm)  # robust to empty-union inside
            if iou_pc >= add_iou_thr:
                new_assign.add(cid)

        kept = set()
        for cid in list(P.assigned_child_ids):
            cm = child_mask_bool_by_id.get(cid, None)
            if cm is None or not cm.any():
                continue
            inter = int((P.active_mask & cm).sum())
            if inter >= min_overlap_px and _iou(P.active_mask, cm) >= keep_iou_thr:
                kept.add(cid)

        P.assigned_child_ids = kept | new_assign

        # --- orphan detection --------------------------------------------------
        if len(P.assigned_child_ids) == 0 and step > int(P.freeze_until):
            P.orphan_steps += 1
        else:
            P.orphan_steps = 0

        if P.orphan_steps > orphan_grace_steps:
            setattr(P, "_delete", True)
            continue

        # --- build boolean TARGET support (do NOT write to P.mask) ------------
        active_bool = (np.asarray(P.mask, np.float32) >= active_thr)

        if len(P.assigned_child_ids) > 0:
            union_assigned = _union_of_children(children, P.assigned_child_ids, H, W, active_thr)

            # keep only CC overlapping assigned; pick best by (overlap, size)
            labels = _label4(active_bool, periodic=bool(periodic))
            nlab = int(labels.max())
            if nlab > 1:
                best_lbl, best_ov, best_sz = 0, -1, -1
                for lbl in range(1, nlab + 1):
                    comp = (labels == lbl)
                    if comp.sum() < min_cc_px:
                        continue
                    ov = int((comp & union_assigned).sum())
                    sz = int(comp.sum())
                    if (ov, sz) > (best_ov, best_sz):
                        best_lbl, best_ov, best_sz = lbl, ov, sz
                target_bool = (labels == best_lbl) if best_lbl != 0 else _largest_cc(active_bool, periodic=periodic)
            else:
                target_bool = active_bool

            # Active↔assigned IoU gate with smart restore
            iou_u = _iou(target_bool, union_assigned)
            if iou_u < active_iou_min:
                prev = target_bool
                target_bool = target_bool & union_assigned
                dropped = prev & (~target_bool)
                if dropped.any():
                    # Restore a fraction of dropped pixels with highest previous mask value
                    restore_frac = float(1.0 - hysteresis_keep_frac)
                    if restore_frac > 0.0:
                        restore_cap = int(np.ceil(restore_frac * dropped.sum()))
                        M_prev = np.asarray(P.mask, np.float32)
                        yy, xx = np.where(dropped)
                        if yy.size > 0:
                            vals = M_prev[yy, xx]
                            idx_sorted = np.argsort(-vals)[:restore_cap]
                            rr = np.zeros_like(prev, dtype=bool)
                            rr[yy[idx_sorted], xx[idx_sorted]] = True
                            target_bool = target_bool | rr
        else:
            # No assigned kids: prefer largest CC if sizeable
            target_bool = _largest_cc(active_bool, periodic=periodic) if active_bool.sum() >= min_cc_px else active_bool

        # --- freeze seed protection -------------------------------------------
        if step <= int(P.freeze_until):
            target_bool = target_bool | (_to_bool(P.seed_mask, 0.5))

        # --- SOFT UPDATE: blend toward feathered target ------------------------
        target_float = target_bool.astype(np.float32)
        if sigma > 0.0:
            try:
                from scipy.ndimage import gaussian_filter as _gf
                target_float = _gf(target_float, sigma=sigma, mode="wrap" if periodic else "nearest")
            except Exception:
                pass
        target_float = np.clip(target_float, 0.0, 1.0)

        M_prev = np.asarray(P.mask, np.float32)
        delta = target_float - M_prev
        eta   = np.where(delta > 0.0, eta_up, np.where(delta < 0.0, eta_down, 0.0)).astype(np.float32)
        raw   = M_prev + eta * delta

        # signed cap
        d = np.clip(raw - M_prev, -delta_cap, delta_cap)
        M_new = np.clip(M_prev + d, 0.0, 1.0)

        # minimal area safeguard during freeze: keep at least seed
        if (M_new >= active_thr).sum() < min_cc_px and step <= int(P.freeze_until):
            M_new = np.maximum(M_new, np.asarray(P.seed_mask, np.float32))

        # --- commit ------------------------------------------------------------
        P.mask = M_new.astype(np.float32)
        P.active_mask = (P.mask >= active_thr)






def _debug_assert_parents_on_multichild_cover(runtime_ctx, children, *, mask_tau=0.10):
    import numpy as np
    if not bool(getattr(config, "debug_strict", False)):
        return
    parents = getattr(runtime_ctx, "parents_by_region", {}) or {}
    if not parents:
        return
    H, W = np.asarray(children[0].mask, np.float32).shape[:2]
    cover = np.zeros((H, W), np.int16)
    for ch in children:
        cover += (np.asarray(ch.mask, np.float32) >= float(mask_tau)).astype(np.int16)
    for rid, P in parents.items():
        M = np.asarray(getattr(P, "mask", 0.0), np.float32)
        bad = (M > 0) & (cover < 2)
        if np.any(bad):
            nbad = int(bad.sum())
            raise AssertionError(f"[PARENT COVER VIOLATION] rid={rid} pixels={nbad} outside ≥2-child cover")
