import numpy as np
from get_generators import get_generators
from generalized_omega import compute_gauge_potential
from generalized_agent_distributions import (
    initialize_multivariate_gaussian_distribution,
    get_fiber_basis,
)
import config
from scipy.ndimage import sobel
from numerical_utils import safe_inv

def compute_agent_pullback_blocks(agent, vis_inds, dark_inds, from_belief=False, eps=1e-12):
    """
    Compute pullback blocks using η₁, η₂ directly — no need for mu, sigma, or fiber basis.
    """
    eta1 = agent.eta1_q_field if from_belief else agent.eta1_p_field
    eta2 = agent.eta2_q_field if from_belief else agent.eta2_p_field

    # Reconstruct normalized p_grid from η
    eta2_inv = safe_inv(eta2, eps=eps)
    sigma = -0.5 * eta2_inv
    mu    = -0.5 * np.einsum("...ij,...j->...i", eta2_inv, eta1)

    # Optional: if you want p(c) on the fiber to compute Lie Fisher metric:
    # But ideally, you compute I_ab directly from η if you can avoid p

    dist_field = None  # REMOVE this entirely if using φ, η only

    pull = compute_pullback_grid(
        p_grid     = dist_field,  # REMOVE THIS ARG in final version
        phi_grid   = agent.phi_model,
        K          = eta1.shape[-1],
        vis_inds   = vis_inds,
        dark_inds  = dark_inds,
        eps        = eps,
        group_name = getattr(config, "group_name", "so3"),
    )

    return pull


def compute_fisher_algebra_from_eta(eta1, eta2, generators, eps=1e-8):
    """
    Compute Lie algebra Fisher I_ab directly from η₁, η₂.

    Args:
        eta1: (..., K)
        eta2: (..., K, K)
        generators: (d, K, K)

    Returns:
        I: (..., d, d) Lie algebra Fisher matrix
    """
    

    eta2_inv = safe_inv(eta2, eps=eps)               # (..., K, K)
    eta2_eta1 = np.einsum("...ij,...j->...i", eta2_inv, eta1)  # (..., K)

    # v_a = T_a · η2⁻¹ η1
    v = np.einsum("akl,...l->...ak", generators, eta2_eta1)  # (..., d, K)

    # I_ab = v_aᵀ · η2 · v_b
    I = np.einsum("...ak,...kl,...bl->...ab", v, eta2, v)  # (..., d, d)
    return I


def algebra_fisher_metric(p_c, generators, eps=1e-12):
    """
    Compute the Fisher metric on the Lie algebra at a single base point.

    Args:
        p_c:         (K,) — probability vector at a single point in the fiber (∑ p_k = 1)
        generators:  (d, K, K) — Lie algebra generators T_a in the fiber representation
        eps:         float — regularization to avoid division by 0

    Returns:
        I: (d, d) — Fisher information metric over the Lie algebra directions
    """
    p_safe = np.clip(p_c, eps, 1.0)
    p_safe /= np.sum(p_safe)

    V = np.tensordot(generators, p_safe, axes=([1], [0]))  # (d, K)
    I = np.einsum('ak,bk,k->ab', V, V, 1.0 / p_safe)        # (d, d)
    return I


def block_decompose(I, vis_inds, dark_inds):
    """
    Decompose a full algebra metric I into visible, mixing, and dark blocks.
    """
    M_vis = I[np.ix_(vis_inds, vis_inds)]
    Delta = I[np.ix_(vis_inds, dark_inds)]
    M_dark = I[np.ix_(dark_inds, dark_inds)]
    return M_vis, Delta, M_dark


def pullback_metric_at_point(I_ab, A_vecs):
    """
    Contract Fisher metric I_ab with gauge vectors A_μ to get spatial pullback G.
    """
    D = len(A_vecs)
    return np.array([[A_vecs[mu] @ (I_ab @ A_vecs[nu]) for nu in range(D)]
                     for mu in range(D)])

def compute_lie_metric(generators: np.ndarray):
    """
    Compute inner product matrix G_{ab} = Tr(G_aᵀ G_b) and its inverse.

    Args:
        generators: (d, K, K) basis of Lie algebra

    Returns:
        G: (d, d) inner product matrix
        G_inv: (d, d) inverse (with fallback)
    """
    d = generators.shape[0]
    G = np.einsum("aij,bij->ab", generators, generators)
    G = 0.5 * (G + G.T)  # symmetrize

    G_inv = safe_inv(G, eps=getattr(config, "eps", 1e-6))


    return G, G_inv

def compute_pullback_grid(
    eta1_field,
    eta2_field,
    phi_grid,
    vis_inds,
    dark_inds,
    eps=1e-12,
    group_name="so3"
):
    """
    Compute pullback diagnostic tensors directly from η₁, η₂ and φ.
    Avoids any use of (μ, Σ) or belief distribution.

    Returns:
        dict with I (algebra Fisher), G (spatial pullback), M_vis, Delta, M_dark
    """
    

    H, W, K = eta1_field.shape
    generators = get_generators(group_name, K)  # (d, K, K)
    d = generators.shape[0]
    D = len(phi_grid.shape) - 1

    # Recover Σ = -½ η₂⁻¹ and μ = -½ η₂⁻¹ η₁
    eta2_inv = safe_inv(eta2_field, eps=eps)
    sigma = -0.5 * eta2_inv  # (H, W, K, K)
    mu    = -0.5 * np.einsum("...ij,...j->...i", eta2_inv, eta1_field)

    # Fisher metric I_ab = Tr[ (T_a ∂ log p)(T_b ∂ log p) p ]
    # For Gaussians, use covariance-based projection: G = Σ⁻¹
    # We'll simulate "projections" via generator pushforward: V_a = T_a μ

    # Step 1: Algebra Fisher metric I_ab from generator projections
    # V_a = T_a μ → shape (H, W, d, K)
    V_field = np.einsum("akl,ijl->ijak", generators, mu)
    I_grid = np.einsum("ijak,ijbk,ijkl->ijab", V_field, V_field, safe_inv(sigma, eps=eps))  # (H,W,d,d)

    # Step 2: Gauge field A_μ^a
    A_fields = compute_gauge_potential(phi_grid)   # list of D arrays, each (H, W, d)
    A_stack = np.stack(A_fields, axis=-2)          # (H, W, D, d)

    # Step 3: Spatial pullback G_{μν} = A_μ^a I_ab A_ν^b
    G_grid = np.einsum("...ua,...ab,...vb->...uv", A_stack, I_grid, A_stack)  # (H,W,D,D)

    # Step 4: Block decomposition
    M_vis_grid  = np.empty((H, W, len(vis_inds), len(vis_inds)))
    Delta_grid  = np.empty((H, W, len(vis_inds), len(dark_inds)))
    M_dark_grid = np.empty((H, W, len(dark_inds), len(dark_inds)))

    for i in range(H):
        for j in range(W):
            I_ij = I_grid[i, j]
            M_vis_grid[i, j]  = I_ij[np.ix_(vis_inds, vis_inds)]
            Delta_grid[i, j]  = I_ij[np.ix_(vis_inds, dark_inds)]
            M_dark_grid[i, j] = I_ij[np.ix_(dark_inds, dark_inds)]

    return {
        "I": I_grid,
        "G": G_grid,
        "M_vis": M_vis_grid,
        "Delta": Delta_grid,
        "M_dark": M_dark_grid,
    }



def compute_fisher_metric_block_diag(sigma_field, mask=None, eps=1e-8):
    """
    Compute Fisher metric G = Σ⁻¹ for a batch of SPD matrices, with optional masking.
    """
    H, W, K, _ = sigma_field.shape
    G = np.zeros_like(sigma_field)
    eye = np.eye(K, dtype=sigma_field.dtype)

    for i in range(H):
        for j in range(W):
            Σ = sigma_field[i, j]
            if mask is not None and not mask[i, j]:
                G[i, j] = np.eye(K)
                continue
            Σ_reg = Σ + eps * eye
            try:
                G[i, j] = np.linalg.inv(Σ_reg)
            except np.linalg.LinAlgError:
                G[i, j] = np.eye(K)  # fallback
    return G


def compute_pullback_metric(mu_field, sigma_field, mask=None):
    """
    Pullback Fisher metric from gradients of μ and Σ⁻¹:
        M_ab(c) = ∂_a μ_k · Σ⁻¹_kl · ∂_b μ_l
    """
    H, W, K = mu_field.shape
    D = 2
    M = np.zeros((H, W, D, D), dtype=mu_field.dtype)

    # Fisher inverse Σ⁻¹
    G_inv = compute_fisher_metric_block_diag(sigma_field, mask=mask)  # (H, W, K, K)

    # ∇μ: (H, W, D, K)
    grad_mu = np.stack([
        sobel(mu_field, axis=0, mode='wrap') / 8.0,  # ∂y μ
        sobel(mu_field, axis=1, mode='wrap') / 8.0,  # ∂x μ
    ], axis=2)  # (H, W, D, K)

    # Efficient contraction: M_ab = ∑_kl ∂_a μ_k · G_kl · ∂_b μ_l
    M = np.einsum("...ak,...kl,...bl->...ab", grad_mu, G_inv, grad_mu)
    return M
