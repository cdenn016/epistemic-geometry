# -*- coding: utf-8 -*-
"""
Created on Wed Jul 23 06:38:37 2025

@author: chris and christine
"""
import numpy as np
from natural_gradient import compute_inverse_fisher_field_natural  # you will need to implement this
from numerical_utils import safe_inv, sanitize_sigma
from get_generators import get_generators
import config   
#==============================================================================
#
#                    Apply Natural Gradient to Bundle Morphism
#
#==============================================================================

from natural_gradient import dexpinv_operator
from omega import compute_exp_field, d_exp_phi_exact, d_exp_phi_tilde_exact

from bundle_morphism_utils import compute_direct_morphisms

from numerical_utils import safe_inv
from natural_params_utils import compute_delta_eta_q_PhiTilde_p


def accumulate_phi_gradient_from_morphism_self_and_feedback(agent_i, generators_p, generators_q, params, debug=False):
    """
    Accumulate ∇_φ from:
      - KL(q || Φ̃·p)    ← self-energy (belief)
      - KL(p || Φ·q)     ← feedback (model)
    into:
      - agent_i.grad_phi
    """
    alpha   = params.get("alpha", config.alpha)
    lambda_ = params.get("feedback_weight", config.feedback_weight)
    if alpha <= 0 and lambda_ <= 0:
        return

    eps  = config.support_cutoff_eps
    mask = (agent_i.mask > eps)[..., None]  # (H, W, 1)

    eta1_q, eta2_q = agent_i.eta1_q_field, agent_i.eta2_q_field
    eta1_p, eta2_p = agent_i.eta1_p_field, agent_i.eta2_p_field
    phi, phi_tilde = agent_i.phi, agent_i.phi_model

    # Compute both Φ and Φ̃ directly from φ, φ̃
   
    agent_i.bundle_morphism_q_to_p, agent_i.bundle_morphism_p_to_q = compute_direct_morphisms(
    phi=agent_i.phi,
    phi_model=agent_i.phi_model,
    generators_q=agent_i.generators_q,
    generators_p=agent_i.generators_p,
    Phi_0=agent_i.Phi_0,
    Phi_tilde_0=agent_i.Phi_tilde_0,
)
    Phi        = agent_i.bundle_morphism_q_to_p
    Phi_tilde  = agent_i.bundle_morphism_p_to_q



    # ───── Self-energy gradient: ∇_φ KL(q || Φ̃·p) ─────
    if alpha > 0:
        grad_Phi_tilde = grad_kl_morphism_natural_self(
            eta1_q, eta2_q, eta1_p, eta2_p, Phi_tilde, eps=eps
        )
        grad_phi_self = backprop_phi_from_grad_Phi_tilde(
            grad_Phi_tilde, phi, phi_tilde,
            Phi_tilde,  # previously agent_i.bundle_morphism_p_to_q
            generators_q, generators_p
        )
        G_inv = compute_inverse_fisher_field_natural(eta2_q, generators_q, mask=mask[..., 0])
        grad_phi_self = np.einsum("...ab,...b->...a", G_inv, grad_phi_self)
        grad_phi_self = dexpinv_operator(phi, grad_phi_self, generators_q)
        grad_phi_self *= mask
        agent_i.grad_phi += alpha * grad_phi_self

    # ───── Feedback gradient: ∇_φ KL(p || Φ·q) ─────
    if lambda_ > 0:
        grad_Phi = grad_kl_morphism_natural_feedback(
            eta1_p, eta2_p, eta1_q, eta2_q, Phi, eps=eps
        )
        grad_phi_feedback = backprop_phi_from_grad_Phi(
            grad_Phi, phi, phi_tilde,
            Phi,  # previously agent_i.bundle_morphism_q_to_p
            generators_q, generators_p
        )
        G_inv = compute_inverse_fisher_field_natural(eta2_q, generators_q, mask=mask[..., 0])
        grad_phi_feedback = np.einsum("...ab,...b->...a", G_inv, grad_phi_feedback)
        grad_phi_feedback = dexpinv_operator(phi, grad_phi_feedback, generators_q)
        grad_phi_feedback *= mask
        agent_i.grad_phi += lambda_ * grad_phi_feedback


def accumulate_phi_tilde_gradient_from_morphism_self_and_feedback(agent_i, generators_p, generators_q, params, debug=False):
    """
    Accumulate ∇_{φ̃} from:
      - KL(q || Φ̃·p)    ← self-energy (belief)
      - KL(p || Φ·q)     ← feedback (model)
    into:
      - agent_i.grad_phi_tilde
    """
    alpha   = params.get("alpha", config.alpha)
    lambda_ = params.get("feedback_weight", config.feedback_weight)
    if alpha <= 0 and lambda_ <= 0:
        return

    eps  = config.support_cutoff_eps
    mask = (agent_i.mask > eps)[..., None]  # (H, W, 1)

    eta1_q, eta2_q = agent_i.eta1_q_field, agent_i.eta2_q_field
    eta1_p, eta2_p = agent_i.eta1_p_field, agent_i.eta2_p_field
    phi, phi_tilde = agent_i.phi, agent_i.phi_model

    # Compute both Φ and Φ̃ directly from φ, φ̃
    
    Phi        = agent_i.bundle_morphism_q_to_p
    Phi_tilde  = agent_i.bundle_morphism_p_to_q


    # ───── Self-energy gradient: ∇_{φ̃} KL(q || Φ̃·p) ─────
    if alpha > 0:
        grad_Phi_tilde = grad_kl_morphism_natural_self(
            eta1_q, eta2_q, eta1_p, eta2_p, Phi_tilde, eps=eps
        )
        grad_phi_tilde_self = backprop_phi_tilde_from_grad_Phi_tilde(
            grad_Phi_tilde, phi_tilde, phi,
            Phi_tilde,
            generators_p, generators_q
        )
        G_inv_tilde = compute_inverse_fisher_field_natural(eta2_p, generators_p, mask=mask[..., 0])
        grad_phi_tilde_self = np.einsum("...ab,...b->...a", G_inv_tilde, grad_phi_tilde_self)
        grad_phi_tilde_self = dexpinv_operator(phi_tilde, grad_phi_tilde_self, generators_p)
        grad_phi_tilde_self *= mask
        agent_i.grad_phi_tilde += alpha * grad_phi_tilde_self

    # ───── Feedback gradient: ∇_{φ̃} KL(p || Φ·q) ─────
    if lambda_ > 0:
        grad_Phi = grad_kl_morphism_natural_feedback(
            eta1_p, eta2_p, eta1_q, eta2_q, Phi, eps=eps
        )
        grad_phi_tilde_feedback = backprop_phi_tilde_from_grad_Phi(
            grad_Phi, phi_tilde, phi,
            Phi,
            generators_p, generators_q
        )
        G_inv_tilde = compute_inverse_fisher_field_natural(eta2_p, generators_p, mask=mask[..., 0])
        grad_phi_tilde_feedback = np.einsum("...ab,...b->...a", G_inv_tilde, grad_phi_tilde_feedback)
        grad_phi_tilde_feedback = dexpinv_operator(phi_tilde, grad_phi_tilde_feedback, generators_p)
        grad_phi_tilde_feedback *= mask
        agent_i.grad_phi_tilde += lambda_ * grad_phi_tilde_feedback





def grad_kl_morphism_natural_feedback(
    eta1_p, eta2_p,     # (..., K_p), (..., K_p, K_p)
    eta1_q, eta2_q,     # (..., K_q), (..., K_q, K_q)
    Phi,                # (..., K_p, K_q)
    eps=1e-8
):
    """
    Compute the gradient ∇_Φ D_KL(p || Φ·q) in natural parameter space.

    Let:
        η₁_p, η₂_p = natural parameters of p
        η₁_q, η₂_q = natural parameters of q
        Φ         = rectangular morphism Φ : B_q → B_p
        Σ_p⁻¹ = η₂_p,    Σ_q⁻¹ = η₂_q
        μ_p = -½ η₂_p⁻¹ η₁_p,     μ_q = -½ η₂_q⁻¹ η₁_q
        bar_η_q = (Φ η₂_q⁻¹ Φᵀ)⁻¹
        Δη = η₁_p - Φ η₁_q

    Then the exact gradient is:

        ∇_Φ D_KL(p || Φ·q) =
            ½ · [ 
                  bar_η_q
                - bar_η_q η₂_p⁻¹ bar_η_q
                - bar_η_q Δη Δηᵀ bar_η_q 
            ] · Φ · η₂_q⁻¹

    Returns:
        grad: (..., K_p, K_q) — gradient of KL w.r.t. morphism Φ
    """
   

    eta2_p_inv = safe_inv(eta2_p, eps=eps)
    bar_eta_q = compute_bar_eta2_q_morphed(eta2_q, Phi, eps=eps)
    delta_eta = compute_delta_eta_p_Phi_q(eta1_p, eta2_p, eta1_q, eta2_q, Phi, eps=eps)

    term1 = np.einsum("...ik,...kl,...lj->...ij", bar_eta_q, eta2_p_inv, bar_eta_q)
    term2 = bar_eta_q
    outer = np.einsum("...i,...j->...ij", delta_eta, delta_eta)
    term3 = np.einsum("...ik,...kl,...lj->...ij", bar_eta_q, outer, bar_eta_q)

    inner = 0.5 * (term1 - term2 - term3)

    # Final contraction with Phi · eta2_q^{-1}
    eta2_q_inv = safe_inv(eta2_q, eps=eps)
    Phi_eta_inv = np.einsum("...ik,...kj->...ij", Phi, eta2_q_inv)
    grad = np.einsum("...ij,...jk->...ik", inner, Phi_eta_inv)

    return grad



def grad_kl_morphism_natural_self (
    eta1_q, eta2_q,     # (..., K_q), (..., K_q, K_q)
    eta1_p, eta2_p,     # (..., K_p), (..., K_p, K_p)
    Phi_tilde,          # (..., K_q, K_p)
    eps=1e-8
):
    """
    Compute the gradient ∇_{Φ̃} D_KL(q || Φ̃·p) in natural parameter space.

    Let:
        η₁_q, η₂_q = natural parameters of q
        η₁_p, η₂_p = natural parameters of p
        Φ̃         = rectangular morphism Φ̃ : B_p → B_q
        Σ_q⁻¹ = η₂_q,    Σ_p⁻¹ = η₂_p
        μ_q = -½ η₂_q⁻¹ η₁_q,     μ_p = -½ η₂_p⁻¹ η₁_p
        bar_η_p = (Φ̃ η₂_p⁻¹ Φ̃ᵀ)⁻¹
        Δη = η₁_q - Φ̃ η₁_p

    Then the exact gradient is:

        ∇_{Φ̃} D_KL(q || Φ̃·p) =
            ½ · [
                  bar_η_p
                - bar_η_p η₂_q⁻¹ bar_η_p
                - bar_η_p Δη Δηᵀ bar_η_p
            ] · Φ̃ · η₂_p⁻¹

    Returns:
        grad: (..., K_q, K_p) — gradient of KL divergence w.r.t. morphism Φ̃
    """
    eta2_q_inv = safe_inv(eta2_q, eps=eps)
    eta2_p_inv = safe_inv(eta2_p, eps=eps)

    bar_eta_p = compute_bar_eta2_p_morphed(eta2_p, Phi_tilde, eps=eps)
    delta_eta = compute_delta_eta_q_PhiTilde_p(eta1_q, eta2_q, eta1_p, eta2_p, Phi_tilde, eps=eps)

    term1 = bar_eta_p
    term2 = np.einsum("...ik,...kl,...lj->...ij", bar_eta_p, eta2_q_inv, bar_eta_p)
    outer = np.einsum("...i,...j->...ij", delta_eta, delta_eta)
    term3 = np.einsum("...ik,...kl,...lj->...ij", bar_eta_p, outer, bar_eta_p)

    inner = term1 - term2 - term3

    Phi_eta_inv = np.einsum("...ik,...kj->...ij", Phi_tilde, eta2_p_inv)
    grad = 0.5 * np.einsum("...ij,...jk->...ik", inner, Phi_eta_inv)

    return grad


def compute_bar_eta2_q_morphed(eta2_q, Phi, eps=1e-8):
    """
    Compute bar_eta2^Φ_q = (Φ η2_q⁻¹ Φᵀ)⁻¹

    Shapes:
        eta2_q : (..., K_q, K_q)
        Phi    : (..., K_p, K_q)
    Returns:
        bar_eta2_q_Phi : (..., K_p, K_p)
    """
    eta2_inv = safe_inv(eta2_q, eps=eps)
    pushed = np.einsum("...ik,...kl->...il", Phi, eta2_inv)             # (..., K_p, K_q)
    pushed = np.einsum("...ij,...jk->...ik", pushed, Phi.swapaxes(-1, -2))  # (..., K_p, K_p)
    return safe_inv(pushed, eps=eps)


def compute_delta_eta_p_Phi_q(eta1_p, eta2_p, eta1_q, eta2_q, Phi, eps=1e-8):
    """
    Compute Δη = η2_p⁻¹ η1_p − Φ η2_q⁻¹ η1_q

    Returns:
        delta_eta : (..., K_p)
    """
    eta2_inv_p = safe_inv(eta2_p, eps=eps)
    eta2_inv_q = safe_inv(eta2_q, eps=eps)

    term_p = np.einsum("...ij,...j->...i", eta2_inv_p, eta1_p)
    term_q = np.einsum("...ij,...j->...i", eta2_inv_q, eta1_q)
    term_q_push = np.einsum("...ij,...j->...i", Phi, term_q)

    return term_p - term_q_push

def compute_bar_eta2_p_morphed(eta2_p, Phi_tilde, eps=1e-8):
    """
    Compute bar_eta2^Φ~_p = (Φ~ η2_p⁻¹ Φ~ᵀ)⁻¹

    Shapes:
        eta2_p     : (..., K_p, K_p)
        Phi_tilde  : (..., K_q, K_p)
    Returns:
        bar_eta2_p_PhiTilde : (..., K_q, K_q)
    """
    eta2_inv = safe_inv(eta2_p, eps=eps)
    pushed = np.einsum("...ik,...kl->...il", Phi_tilde, eta2_inv)
    pushed = np.einsum("...ij,...jk->...ik", pushed, Phi_tilde.swapaxes(-1, -2))
    return safe_inv(pushed, eps=eps)


def compute_delta_eta_q_PhiTilde_p(eta1_q, eta2_q, eta1_p, eta2_p, Phi_tilde, eps=1e-8):
    """
    Compute Δη = η2_q⁻¹ η1_q − Φ~ η2_p⁻¹ η1_p

    Returns:
        delta_eta : (..., K_q)
    """
    eta2_inv_q = safe_inv(eta2_q, eps=eps)
    eta2_inv_p = safe_inv(eta2_p, eps=eps)

    term_q = np.einsum("...ij,...j->...i", eta2_inv_q, eta1_q)
    term_p = np.einsum("...ij,...j->...i", eta2_inv_p, eta1_p)
    term_p_push = np.einsum("...ji,...i->...j", Phi_tilde, term_p)  # Φ~ᵀ · (η2_p⁻¹ η1_p)

    return term_q - term_p_push



def backprop_phi_from_grad_Phi(
    grad_Phi,           # (..., K_p, K_q)
    phi,                # (..., d_q)
    phi_tilde,          # (..., d_p)
    Phi_0,              # (..., K_p, K_q)
    generators_q,       # (d_q, K_q, K_q)
    generators_p        # (d_p, K_p, K_p)
):
    """
    Compute ∇_{φ} KL(p || Φ⋅q) where Φ = e^{φ~} Φ_0 e^{φ}
    Returns: (..., d_q) Euclidean gradients
    """
    exp_phi = compute_exp_field(phi, generators_q, scale=1.0)
    exp_phi_tilde = compute_exp_field(phi_tilde, generators_p, scale=1.0)

    d_exp_phi = d_exp_phi_exact(phi, generators_q)
    grad_vec = []
    for a, d_exp in enumerate(d_exp_phi):
        partial = np.einsum("...ik,...kj,...jl->...il", exp_phi_tilde, Phi_0, d_exp)
        grad_a = np.einsum("...ij,...ij->...", grad_Phi, partial)
        grad_vec.append(grad_a)
    return np.stack(grad_vec, axis=-1)


def backprop_phi_tilde_from_grad_Phi(
    grad_Phi,           # (..., K_p, K_q)
    phi_tilde,          # (..., d_p)
    phi,                # (..., d_q)
    Phi_0,              # (..., K_p, K_q)
    generators_p,       # (d_p, K_p, K_p)
    generators_q        # (d_q, K_q, K_q)
):
    """
    Compute ∇_{φ~} KL(p || Φ⋅q) where Φ = e^{φ~} Φ_0 e^{φ}
    Returns: (..., d_p) Euclidean gradients
    """
    exp_phi = compute_exp_field(phi, generators_q, scale=1.0)
    exp_phi_tilde = compute_exp_field(phi_tilde, generators_p, scale=1.0)

    d_exp_phi_tilde = d_exp_phi_tilde_exact(phi_tilde, generators_p)
    grad_vec = []
    for a, d_exp in enumerate(d_exp_phi_tilde):
        partial = np.einsum("...ik,...kj,...jl->...il", d_exp, Phi_0, exp_phi)
        grad_a = np.einsum("...ij,...ij->...", grad_Phi, partial)
        grad_vec.append(grad_a)
    return np.stack(grad_vec, axis=-1)

def backprop_phi_from_grad_Phi_tilde(
    grad_Phi_tilde,     # (..., K_q, K_p)
    phi,                # (..., d_q)
    phi_tilde,          # (..., d_p)
    Phi_0_tilde,        # (..., K_q, K_p)
    generators_q,       # (d_q, K_q, K_q)
    generators_p        # (d_p, K_p, K_p)
):
    """
    Compute ∇_{φ} KL(q || Φ~⋅p) where Φ~ = e^{φ} Φ~_0 e^{φ~}
    Returns: (..., d_q)
    """
    exp_phi        = compute_exp_field(phi, generators_q, scale=1.0)
    exp_phi_tilde  = compute_exp_field(phi_tilde, generators_p, scale=1.0)
    d_exp_phi      = d_exp_phi_exact(phi, generators_q)

    grad_vec = []
    for a, d_exp in enumerate(d_exp_phi):
        # ∂_a Φ̃ = (∂_a e^{φ}) ⋅ Φ̃₀ ⋅ e^{φ̃}
        partial = np.einsum("...ik,...kj,...jl->...il", d_exp, Phi_0_tilde, exp_phi_tilde)

        # ⟨grad_Phi_tilde, ∂_a Φ̃⟩ = Tr[gradᵗ ⋅ ∂Φ̃] = ⟨grad, partial⟩
        grad_a = np.einsum("...ij,...ij->...", grad_Phi_tilde, partial)
        grad_vec.append(grad_a)

    return np.stack(grad_vec, axis=-1)


def backprop_phi_tilde_from_grad_Phi_tilde(
    grad_Phi_tilde,     # (..., K_q, K_p)
    phi_tilde,          # (..., d_p)
    phi,                # (..., d_q)
    Phi_0_tilde,        # (..., K_q, K_p)
    generators_p,       # (d_p, K_p, K_p)
    generators_q        # (d_q, K_q, K_q)
):
    """
    Compute ∇_{φ~} KL(q || Φ~⋅p) where Φ~ = e^{φ} Φ~_0 e^{φ~}
    Returns: (..., d_p)
    """
    
    exp_phi = compute_exp_field(phi, generators_q, scale=1.0)
    exp_phi_tilde = compute_exp_field(phi_tilde, generators_p, scale=1.0)

    d_exp_phi_tilde = d_exp_phi_tilde_exact(phi_tilde, generators_p)
    grad_vec = []
    for a, d_exp in enumerate(d_exp_phi_tilde):
        partial = np.einsum("...ik,...kj,...jl->...il", exp_phi, Phi_0_tilde, d_exp)
        grad_a = np.einsum("...ij,...ij->...", grad_Phi_tilde, partial)
        grad_vec.append(grad_a)
    return np.stack(grad_vec, axis=-1)

