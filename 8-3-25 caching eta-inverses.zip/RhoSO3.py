# -*- coding: utf-8 -*-
"""
Created on Wed Jul 30 21:01:30 2025

@author: chris and christine
"""

import numpy as np
from scipy.linalg import expm
from generalized_generators import get_generators  # your existing utility

class RhoSO3:
    def __init__(self, K: int, dtype=np.float32):
        """
        Minimal SO(3) representation class.

        Args:
            K     : fiber dimension
            dtype : float precision
        """
        self.K = K
        self.dtype = dtype
        self.generators = get_generators("so3", K).astype(dtype)  # (3, K, K)

    def exp(self, phi: np.ndarray) -> np.ndarray:
        """
        Compute matrix exponential ρ(exp(φ)) for a single φ ∈ ℝ³.

        Args:
            phi : (3,) vector in Lie algebra

        Returns:
            ρ(exp(φ)) ∈ ℝ^{K×K}
        """
        phi_matrix = sum(phi[a] * self.generators[a] for a in range(3))
        return expm(phi_matrix)

    def exp_field(self, phi_field: np.ndarray, scale: float = 1.0, debug=False) -> np.ndarray:
        """
        Compute ρ(exp(φ)) for an entire (H, W, 3) field.

        Args:
            phi_field : (H, W, 3)
            scale     : optional scalar factor
            debug     : if True, prints occasional norms

        Returns:
            rho_field : (H, W, K, K)
        """
        H, W, _ = phi_field.shape
        K = self.K
        rho_field = np.zeros((H, W, K, K), dtype=self.dtype)

        for i in range(H):
            for j in range(W):
                phi = phi_field[i, j] * scale
                rho_field[i, j] = self.exp(phi)
                if debug and (i + j) % 10 == 0:
                    print(f"[RhoSO3] ‖φ‖ = {np.linalg.norm(phi):.3f}")

        return rho_field
