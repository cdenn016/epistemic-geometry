# === generalized_agent_distributions.py ===
import numpy as np
import config
import numpy as np
from numerical_utils import safe_inv


import numpy as np
from scipy.linalg import expm

from numerical_utils import sanitize_sigma, sanitize_eta2


from scipy.ndimage import gaussian_filter
from config import diagonal_eta2_init

import numpy as np
from scipy.ndimage import gaussian_filter
import config

from omega import compute_exp_field

def mu_sigma_to_natural(mu, sigma, eps=1e-8):
    """
    Convert (μ, Σ) to natural parameters (η₁, η₂).

    η₁ = Σ⁻¹μ
    η₂ = -½ Σ⁻¹

    Args:
        mu:    (..., K)
        sigma: (..., K, K)
        eps:   regularization for safe inverse

    Returns:
        eta1: (..., K)
        eta2: (..., K, K)
    """
    sigma_inv = safe_inv(sigma, eps)
    eta1 = np.einsum('...ij,...j->...i', sigma_inv, mu)
    eta2 = -0.5 * sigma_inv
    return eta1, eta2



def generate_eta1_eta2_fields(
    domain_size,
    rng,
    K,
    eta1_range,
    eta2_range,
    mask=None,
    sigma_outside_val=None,
    dtype=np.float32,
    smooth_sigma=None,
    diagonal_eta2=None,
    floor=None,
    eps=None,
):
    """
    Generate η₁ and η₂ fields over the base domain.

    η₁: freely initialized from uniform range, smoothed
    η₂: either diagonal SND or full-rank SND from random SPD Σ → η₂ = -½ Σ⁻¹

    Parameters:
        domain_size         : (H, W)
        rng                 : np.random.Generator
        K                   : fiber dimension
        eta1_range          : (min, max) for η₁ init
        eta2_range          : (min, max) for η₂ init (magnitude)
        mask                : (H, W) spatial mask
        sigma_outside_val   : η₂ value outside support (default from config)
        dtype               : float32 or float64
        smooth_sigma        : Gaussian filter sigma
        diagonal_eta2       : if True, use diag(-λ₁,...,-λ_K) structure
        floor               : min eigenvalue floor (optional)
        eps                 : numerical stabilizer for inv

    Returns:
        (eta1_field, eta2_field) — shapes:
            (H, W, K), (H, W, K, K)
    """
    # ───── Config fallbacks ─────
    eps          = eps if eps is not None else getattr(config, "eta2_min_eigval", 1e-4)
    floor        = floor if floor is not None else getattr(config, "eta2_floor", -0.5)
    sigma_outside_val = sigma_outside_val if sigma_outside_val is not None else getattr(config, "eta2_outside_val", -1.0)
    smooth_sigma = smooth_sigma if smooth_sigma is not None else getattr(config, "eta2_smooth_sigma", 2.0)
    diagonal_eta2 = diagonal_eta2 if diagonal_eta2 is not None else getattr(config, "diagonal_eta2_init", True)

    if sigma_outside_val >= 0.0:
        raise ValueError("sigma_outside_val must be negative")

    H, W = domain_size

    # ───── η₁ field: Uniform + smoothing ─────
    eta1_field = rng.uniform(*eta1_range, size=(H, W, K)).astype(dtype)
    for k in range(K):
        eta1_field[..., k] = gaussian_filter(eta1_field[..., k], sigma=smooth_sigma)

    # ───── η₂ field ─────
    if diagonal_eta2:
        # η₂ = diag(-λ₁, ..., -λ_K)
        eta2_diag = rng.uniform(*eta2_range, size=(H, W, K)).astype(dtype)
        for k in range(K):
            eta2_diag[..., k] = gaussian_filter(eta2_diag[..., k], sigma=smooth_sigma)
        eta2_field = np.zeros((H, W, K, K), dtype=dtype)
        for k in range(K):
            eta2_field[..., k, k] = -np.abs(eta2_diag[..., k])  # Ensure SND
    else:
        # Full SND η₂ from SPD Σ via η₂ = -½ Σ⁻¹
        A = rng.normal(0, 1, size=(H, W, K, K)).astype(dtype)
        for i in range(K):
            for j in range(K):
                A[..., i, j] = gaussian_filter(A[..., i, j], sigma=smooth_sigma)
        Sigma = np.einsum("...ik,...jk->...ij", A, A)
        for i in range(K):
            Sigma[..., i, i] += eps

        # Normalize trace to target magnitude
        trace = np.trace(Sigma, axis1=-2, axis2=-1)[..., None, None]
        target_trace = K * np.mean(np.abs(eta2_range))
        Sigma *= target_trace / (trace + 1e-8)

        eta2_field = -0.5 * np.linalg.inv(Sigma)

    # ───── Mask outside agent support ─────
    if mask is not None:
        mask = mask.astype(dtype)
        mask_exp = mask[..., None]
        eta1_field *= mask_exp
        eta2_field *= mask_exp[..., None]
        eta2_field += (1.0 - mask_exp)[..., None] * np.eye(K, dtype=dtype) * sigma_outside_val

    # Compute Σ = -½ η₂⁻¹ and clamp μ = Σ η₁
    Sigma = -0.5 * safe_inv(eta2_field, eps=eps)
    mu     = np.einsum("...ij,...j->...i", Sigma, eta1_field)
    mu_clip = 3.0
    mu     = np.clip(mu, -mu_clip, mu_clip)
    eta1_field = np.einsum("...ij,...j->...i", -2.0 * eta2_field, mu)

# Normalize trace of η₂ field
    trace_eta2 = -np.trace(eta2_field, axis1=-2, axis2=-1)  # (H, W)
    target_trace = K * np.mean(np.abs(eta2_range))
    eta2_field *= target_trace / (trace_eta2[..., None, None] + eps)

# Sanitize η₂
    
    eta2_field = sanitize_eta2(eta2_field, floor=floor, eps=eps)

    return eta1_field, eta2_field



def generate_eta1_eta2_fields_old(
    domain_size,
    rng,
    K,
    eta1_range,
    eta2_range,
    mask=None,
    sigma_outside_val=None,
    dtype=np.float32,
    smooth_sigma=None,
    diagonal_eta2=None,
    floor=None,
    eps=None,
):
    import config  # ensure access if not already in scope

    # ───── Config Fallbacks ─────
    eps_cfg    = getattr(config, "eta2_min_eigval", 1e-4)
    floor_cfg  = getattr(config, "eta2_floor", -0.5)
    sigma_cfg  = getattr(config, "eta2_outside_val", -1.0)
    smooth_cfg = getattr(config, "eta2_smooth_sigma", 2.0)

    eps_final      = eps if eps is not None else eps_cfg
    floor_final    = floor if floor is not None else floor_cfg
    sigma_outside_val = sigma_outside_val if sigma_outside_val is not None else sigma_cfg
    smooth_sigma   = smooth_sigma if smooth_sigma is not None else smooth_cfg
    debug_cfg      = getattr(config, "eta2_debug", True)
    if sigma_outside_val >= 0.0:
        raise ValueError("sigma_outside_val must be negative")

    if diagonal_eta2 is None:
        diagonal_eta2 = getattr(config, "diagonal_eta2_init", True)

    H, W = domain_size
    eta1_field = rng.uniform(*eta1_range, size=(H, W, K)).astype(dtype)

    # ───── Smooth η₁ ─────
    for k in range(K):
        eta1_field[..., k] = gaussian_filter(eta1_field[..., k], sigma=smooth_sigma)

    # ───── Construct η₂ ─────
    if diagonal_eta2:
        eta2_diag = rng.uniform(*eta2_range, size=(H, W, K)).astype(dtype)
        for k in range(K):
            eta2_diag[..., k] = gaussian_filter(eta2_diag[..., k], sigma=smooth_sigma)
        eta2_field = np.zeros((H, W, K, K), dtype=dtype)
        for k in range(K):
            eta2_field[..., k, k] = eta2_diag[..., k]
        eta2_field *= -1.0
    else:
        # ───── Full SPD η₂ via A·Aᵀ construction ─────
        A = rng.normal(0, 1, size=(H, W, K, K)).astype(dtype)
        for i in range(K):
            for j in range(K):
                A[..., i, j] = gaussian_filter(A[..., i, j], sigma=smooth_sigma)

        Sigma = np.einsum("...ik,...jk->...ij", A, A)  # SPD
        epsilon = 1e-2
        for i in range(K):
            Sigma[..., i, i] += epsilon

        # Optional trace rescale
        trace = np.trace(Sigma, axis1=-2, axis2=-1)[..., None, None]
        target_trace = K * np.mean(np.abs(eta2_range))
        Sigma *= target_trace / (trace + 1e-8)

        eta2_field = -0.5 * np.linalg.inv(Sigma)  # Natural param

    # ───── Mask outside support ─────
    if mask is not None:
        mask = mask.astype(dtype)
        mask_exp = mask[..., None]
        eta1_field *= mask_exp
        eta2_field *= mask_exp[..., None]
        eta2_field += (1.0 - mask_exp)[..., None] * np.eye(K, dtype=dtype) * sigma_outside_val

    return eta1_field, eta2_field

def rotate_eta_fields_via_phi_safe(
    eta1_field: np.ndarray,
    eta2_field: np.ndarray,
    phi_field: np.ndarray,
    generators: np.ndarray,
    scale: float = 1.0,
) -> tuple[np.ndarray, np.ndarray]:
    """
    Rotate η₁ and η₂ using the Lie group action exp(φ) for arbitrary K.

    Args:
        eta1_field: (H, W, K)
        eta2_field: (H, W, K, K)
        phi_field : (H, W, 3)
        generators: (3, K, K)
        scale     : scalar factor applied to φ

    Returns:
        (rotated_eta1, rotated_eta2) — same shape as inputs
    """
    H, W, K = eta1_field.shape
    assert generators.shape == (3, K, K), f"Expected generators shape (3, {K}, {K}), got {generators.shape}"

    rho_field = compute_exp_field(
        phi_field, generators, scale=scale, group_name="so3", debug=False
    )  # (H, W, K, K)

    # η₁ → ρ · η₁
    rotated_eta1 = np.einsum("...ij,...j->...i", rho_field, eta1_field)

    # η₂ → ρ · η₂ · ρᵀ
    rho_T = rho_field.transpose(0, 1, 3, 2)
    rotated_eta2 = np.einsum("...ik,...kl,...lj->...ij", rho_field, eta2_field, rho_T)

    return rotated_eta1, rotated_eta2









def natural_to_mu_sigma(eta1, eta2, eps=1e-8):
    """
    Convert natural parameters (η₁, η₂) to standard form (μ, Σ).

    Args:
        eta1: (..., K)
        eta2: (..., K, K)
        eps:  regularization for safe inverse

    Returns:
        mu:    (..., K)
        sigma: (..., K, K)
    """
    sigma_inv = -2.0 * eta2
    sigma = safe_inv(sigma_inv, eps)
    mu = np.einsum('...ij,...j->...i', sigma, eta1)
    return mu, sigma




def get_fiber_basis(K: int) -> np.ndarray:
    """
    Return standard basis vectors for the fiber space ℝ^K.
    Output shape: (K, K)
    """
    return np.eye(K, dtype=np.float32)


def initialize_multivariate_gaussian_distribution(
    x_coords: np.ndarray,
    mu_field: np.ndarray,
    sigma_field: np.ndarray,
    mask: np.ndarray,
    log_eps: float = 1e-8
) -> np.ndarray:
    """
    Evaluate multivariate Gaussian distribution q(x) over fiber points,
    defined by spatially varying (μ, Σ), producing a probability field (H, W, K).

    Args:
        x_coords:    (K, D) fiber coordinates
        mu_field:    (H, W, D) spatial mean
        sigma_field: (H, W, D, D) spatial covariance
        mask:        (H, W) support mask
        log_eps:     small stabilizer

    Returns:
        dist:        (H, W, K) probability distribution
    """
    H, W, D = mu_field.shape
    K = x_coords.shape[0]

    # Broadcast to compute deltas
    x = x_coords[None, None, :, :]    # (1, 1, K, D)
    mu = mu_field[:, :, None, :]      # (H, W, 1, D)
    delta = x - mu                    # (H, W, K, D)

    # Regularize Σ
    eps_eye = log_eps * np.eye(D)
    sigma_reg = sigma_field + eps_eye[None, None, :, :]

    # Inverse Σ
    sigma_inv = np.zeros_like(sigma_reg)
    for i in range(H):
        for j in range(W):
            try:
                sigma_inv[i, j] = np.linalg.inv(sigma_reg[i, j])
            except np.linalg.LinAlgError:
                sigma_inv[i, j] = np.eye(D) * (1.0 / log_eps)
                print(f"[WARN] Σ⁻¹ fallback at ({i},{j})")

    # Mahalanobis distance
    mahal_sq = np.einsum("...kd,...de,...ke->...k", delta, sigma_inv, delta)  # (H, W, K)
    exponent = -0.5 * mahal_sq
    exponent -= np.max(exponent, axis=-1, keepdims=True)

    exp_vals = np.exp(exponent) * mask[..., None]
    norm = np.clip(np.sum(exp_vals, axis=-1, keepdims=True), log_eps, None)

    return exp_vals / norm




# ─── Gaussian Distribution in Natural Parameters ────────────────────────────────



def initialize_uniform_distribution(
    x: np.ndarray = None,
    mask: np.ndarray = None,
    dtype=np.float32
) -> np.ndarray:
    """
    Initialize uniform distribution over K fiber points, with optional spatial mask.

    Args:
        x:     optional array to infer spatial shape
        mask:  optional support mask (H, W)
        dtype: float32 or float64

    Returns:
        base: (H, W, K) uniform distribution
    """
    K = config.K
    if mask is not None:
        shape = mask.shape
    elif x is not None and x.ndim >= 2:
        shape = x.shape[:-1]
    else:
        shape = config.domain_size

    base = np.full((*shape, K), 1.0 / K, dtype=dtype)
    return base * mask[..., None] if mask is not None else base
