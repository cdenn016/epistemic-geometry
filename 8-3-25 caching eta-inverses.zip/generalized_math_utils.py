# -*- coding: utf-8 -*-
"""
generalized_math_utils.py — Core math utilities for φ updates, KL divergence, and field ops.
"""
# Core scientific packages
import numpy as np
from scipy.ndimage import laplace

# Local configuration
import config

# Local utility modules
from numerical_utils import sanitize_sigma, safe_inv, safe_logdet
from mask_utils import clip_and_mask_gradient
from generalized_omega import exp_lie_algebra_irrep
from natural_gradient import compute_inverse_fisher_field_natural
from natural_params_utils import natural_to_mu_sigma_batch
from omega import compute_exp_field
from natural_gradient import compute_inverse_fisher_morphism_field

def preprocess_agent_fields(agent, params):
    """Sanitize sigmas, cache Fisher info, compute exp(φ), exp(−φ), and Fisher metrics."""
    e_belief = params.get("e_belief", config.e_belief)
    e_model  = params.get("e_model",  config.e_model)

    agent.clear_omega_cache()

    # ───── Fetch Lie algebra generators ─────
    G_q = agent.rho_q_func.generators  # (d_q, K_q, K_q)
    G_p = agent.rho_p_func.generators  # (d_p, K_p, K_p)

    # ───── Optional Fisher metric cache (used only if fisher_geometry_weight > 0) ─────
    if config.fisher_geometry_weight > 0:
        _, sigma_q = natural_to_mu_sigma_batch(agent.eta1_q_field, agent.eta2_q_field, eps=config.eps)
        agent.cached_fisher_q = safe_batch_inverse(sigma_q, name="σ_q")

    if config.fisher_model_geometry_weight > 0:
        _, sigma_p = natural_to_mu_sigma_batch(agent.eta1_p_field, agent.eta2_p_field, eps=config.eps)
        agent.cached_fisher_p = safe_batch_inverse(sigma_p, name="σ_p")

    # ───── Compute exp(φ), exp(−φ) for belief ─────
    agent._exp_phi = compute_exp_field(agent.phi, G_q, e_belief, max_norm=config.phi_exp_clip)
    agent._exp_neg_phi = safe_batch_inverse(agent._exp_phi)

    # ───── Compute exp(φ_model), exp(−φ_model) for model ─────
    agent._exp_phi_model = compute_exp_field(agent.phi_model, G_p, e_model, max_norm=config.phi_exp_clip)
    agent._exp_neg_phi_model = safe_batch_inverse(agent._exp_phi_model)

    


import numpy as np
from numerical_utils import sanitize_sigma, safe_inv, safe_logdet


def kl_divergenceold(mu1, sigma1, mu2, sigma2, mask=None, log_eps=1e-6):
    """
    Batched KL[𝒩(μ₁, Σ₁) || 𝒩(μ₂, Σ₂)] for full MVG fields.

    Args:
        mu1:    (N, K)
        sigma1: (N, K, K)
        mu2:    (N, K)
        sigma2: (N, K, K)
        mask:   (N,) or (N, 1) optional — multiplies KL result
        log_eps: float — numerical stabilizer for log and inversion

    Returns:
        kl_vals: (N,) KL divergence values (0 where masked out)
    """
    mu1 = np.asarray(mu1)
    mu2 = np.asarray(mu2)
    sigma1 = np.asarray(sigma1)
    sigma2 = np.asarray(sigma2)

    assert mu1.shape == mu2.shape
    assert sigma1.shape == sigma2.shape
    N, K = mu1.shape

    # ── Step 1: sanitize inputs ──
    sigma1 = sanitize_sigma(sigma1, eps=log_eps)
    sigma2 = sanitize_sigma(sigma2, eps=log_eps)

    # ── Step 2: invert and logdet ──
    try:
        sigma2_inv = safe_inv(sigma2, eps=log_eps)        # (N, K, K)
        logdet1    = safe_logdet(sigma1, eps=log_eps)     # (N,)
        logdet2    = safe_logdet(sigma2, eps=log_eps)     # (N,)
    except Exception as e:
        raise RuntimeError(f"[KL Divergence] Sigma inversion/logdet failed: {e}")

    # ── Step 3: Tr[Σ₂⁻¹ Σ₁] ──
    trace_term = np.einsum("nij,njk->nik", sigma2_inv, sigma1)
    trace_term = np.trace(trace_term, axis1=-2, axis2=-1)  # (N,)

    # ── Step 4: Mahalanobis (μ₂ − μ₁)^T Σ₂⁻¹ (μ₂ − μ₁) ──
    diff = mu2 - mu1  # (N, K)
    mahal = np.einsum("ni,nij,nj->n", diff, sigma2_inv, diff)  # (N,)

    # ── Step 5: Final KL expression ──
    kl = 0.5 * (trace_term + mahal - K + logdet2 - logdet1)  # (N,)

    # ── Step 6: Optional masking ──
    if mask is not None:
        mask = np.asarray(mask)
        if mask.ndim == 2:  # e.g. (N, 1)
            mask = np.squeeze(mask, axis=-1)
        kl *= mask

    # ── Step 7: Safety check ──
    if np.any(np.isnan(kl)) or np.any(np.isinf(kl)):
        raise ValueError("[KL Divergence] NaN or Inf detected in KL output")

    return kl

def kl_divergence(mu1, sigma1, mu2, sigma2, mask=None, log_eps=1e-6):
    """
    Batched KL[𝒩(μ₁, Σ₁) || 𝒩(μ₂, Σ₂)] for full MVG fields.

    Args:
        mu1:    (N, K)
        sigma1: (N, K, K)
        mu2:    (N, K)
        sigma2: (N, K, K)
        mask:   (N,) or (N, 1) optional — multiplies KL result
        log_eps: float — numerical stabilizer for log and inversion

    Returns:
        kl_vals: (N,) KL divergence values (0 where masked out)
    """
    mu1 = np.asarray(mu1)
    mu2 = np.asarray(mu2)
    sigma1 = np.asarray(sigma1)
    sigma2 = np.asarray(sigma2)

    assert mu1.shape == mu2.shape
    assert sigma1.shape == sigma2.shape
    N, K = mu1.shape

    # ── Step 1: sanitize inputs ──
    sigma1 = sanitize_sigma(sigma1, eps=log_eps)
    sigma2 = sanitize_sigma(sigma2, eps=log_eps)

    # ── Step 2: invert and logdet (reuse sigma2_inv) ──
    sigma2_inv = safe_inv(sigma2, eps=log_eps)        # (N, K, K)
    logdet1    = safe_logdet(sigma1, eps=log_eps)     # (N,)
    logdet2    = safe_logdet(sigma2, eps=log_eps)     # (N,)

    # ── Step 3: Tr[Σ₂⁻¹ Σ₁] ──
    trace_term = np.einsum("nij,njk->nik", sigma2_inv, sigma1)
    trace_term = np.trace(trace_term, axis1=-2, axis2=-1)  # (N,)

    # ── Step 4: Mahalanobis (μ₂ − μ₁)^T Σ₂⁻¹ (μ₂ − μ₁) ──
    diff = mu2 - mu1  # (N, K)
    mahal = np.einsum("ni,nij,nj->n", diff, sigma2_inv, diff)  # (N,)

    # ── Step 5: Final KL expression ──
    kl = 0.5 * (trace_term + mahal - K + logdet2 - logdet1)  # (N,)

    # ── Step 6: Optional masking ──
    if mask is not None:
        mask = np.asarray(mask)
        if mask.ndim == 2:
            mask = np.squeeze(mask, axis=-1)
        kl *= mask

    # ── Step 7: Safety check ──
    if np.any(np.isnan(kl)) or np.any(np.isinf(kl)):
        raise ValueError("[KL Divergence] NaN or Inf detected in KL output")

    return kl





def laplacian_field(field):
    """
    Computes componentwise Laplacian of a field over its last axis.

    Parameters:
        field: ndarray (..., K)

    Returns:
        Laplacian of shape (..., K)
    """
    if field.ndim < 2:
        raise ValueError("laplacian_field expects at least 2D array (..., K)")
    return np.stack([laplace(field[..., i]) for i in range(field.shape[-1])], axis=-1)



def safe_batch_inverse(S, name="Σ", mask=None):
    """
    Inverts (H, W, K, K) SPD field with fallback and optional mask.
    """
    H, W, K, _ = S.shape
    eye_K = np.eye(K, dtype=S.dtype)
    inv_S = np.zeros_like(S)

    flat_S = S.reshape(-1, K, K)
    flat_mask = mask.reshape(-1) if mask is not None else np.ones(H * W, dtype=bool)

    for idx in range(H * W):
        if not flat_mask[idx]:
            inv_S.reshape(-1, K, K)[idx] = eye_K
            continue
        try:
            inv_S.reshape(-1, K, K)[idx] = np.linalg.inv(flat_S[idx])
        except np.linalg.LinAlgError:
            inv_S.reshape(-1, K, K)[idx] = eye_K
            if config.debug:
                i, j = divmod(idx, W)
                print(f"[WARN] Inversion failed at ({i},{j}) for {name} — using identity")

    return inv_S



def to_natural_params(mu, sigma, eps=1e-6):
    """
    Convert (μ, Σ) to natural parameters (θ₁, θ₂) for multivariate Gaussians.
    θ₁ = Σ⁻¹ μ, θ₂ = -½ Σ⁻¹
    """
    sigma = sanitize_sigma(sigma, eps=eps)
    inv_sigma = safe_inv(sigma, eps=eps)
    theta1 = np.einsum("...ij,...j->...i", inv_sigma, mu)
    theta2 = -0.5 * inv_sigma
    return theta1, theta2


def from_natural_params(theta1, theta2, eps=1e-6):
    """
    Convert natural parameters (θ₁, θ₂) back to (μ, Σ), ensuring stability.
    """
    inv_sigma = -2.0 * theta2
    inv_sigma = 0.5 * (inv_sigma + np.swapaxes(inv_sigma, -1, -2))  # symmetrize
    inv_sigma = sanitize_sigma(inv_sigma, eps=eps)
    sigma = safe_inv(inv_sigma, eps=eps)
    mu = np.einsum("...ij,...j->...i", sigma, theta1)

    try:
        if config.debug_sanitize_sigma:
            logdet = safe_logdet(sigma)
            
    except NameError:
        pass

    return mu, sigma

