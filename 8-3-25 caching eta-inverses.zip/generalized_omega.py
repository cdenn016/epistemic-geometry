import numpy as np
import config
from scipy.linalg import expm
from joblib import Parallel, delayed, parallel_backend
from scipy.ndimage import gaussian_filter
from numerical_utils import sanitize_sigma
from numerical_utils import safe_omega_inv


from scipy.linalg import logm, expm

import numpy as np
from scipy.linalg import expm, logm
import warnings
#==================================================
#
#            Matrix Ops
#
#==================================================



def bch(A, B, max_norm=10.0, inf_tol=1e6, verbose=False):
    """
    4th-order BCH approximation with clipping and numerical guards.

    Computes:
        log(exp(A) @ exp(B)) ≈ A + B + ½[A,B] + 1/12 [A,[A,B]] - 1/12 [B,[B,A]] - 1/24 [B,[A,[A,B]]]

    Args:
        A, B       : (K, K) real matrices (Lie algebra elements)
        max_norm   : clip input matrices if ||M|| > max_norm (for stability)
        inf_tol    : if output norm > inf_tol, emit warning
        verbose    : if True, print norm diagnostics

    Returns:
        Real matrix (K, K) — safe approximation to log(exp(A) @ exp(B))
    """
    # Clip A and B for safety
    for name, M in zip(("A", "B"), (A, B)):
        norm = np.linalg.norm(M, ord=np.inf)
        if norm > max_norm:
            if verbose:
                print(f"[bch] Clipping {name} norm {norm:.2f} to max {max_norm}")
            M *= max_norm / norm

    # Commutators
    AB   = A @ B - B @ A
    AAB  = A @ AB - AB @ A
    BAB  = B @ AB - AB @ B
    BAAB = B @ AAB - AAB @ B

    # Truncated BCH expansion
    out = A + B
    out += 0.5 * AB
    out += (1.0 / 12.0) * AAB
    out -= (1.0 / 12.0) * BAB
    out -= (1.0 / 24.0) * BAAB

    # Final safety check
    out = np.nan_to_num(out, nan=0.0, posinf=max_norm, neginf=-max_norm)
    out_norm = np.linalg.norm(out)
    if out_norm > inf_tol:
        warnings.warn(f"[bch] Large BCH result: ‖out‖ = {out_norm:.2e}", RuntimeWarning)

    return out


def safe_bch_exact(A, B, max_norm=5.0, imag_tol=1e-10):
    """
    Safe BCH with fallback and clipping.

    Tries log(exp(A) @ exp(B)) (exact), falls back to 4th-order BCH if needed.

    Args:
        A, B     : (K, K) Lie algebra elements
        max_norm : clip matrices if ||·||_∞ > max_norm
        imag_tol : if Im(logm) > imag_tol, warn and drop imaginary part

    Returns:
        C        : real matrix ≈ log(exp(A) @ exp(B))
    """
    # Clip inputs
    for M in (A, B):
        norm = np.linalg.norm(M, ord=np.inf)
        if norm > max_norm:
            M *= max_norm / norm

    try:
        AB = expm(A) @ expm(B)
        C  = logm(AB)
        err = np.linalg.norm(C.imag)
        if err > imag_tol:
            warnings.warn(f"[safe_bch_exact] Im(logm) = {err:.2e}. Returning Re(C).", RuntimeWarning)
        return C.real
    except Exception as e:
        warnings.warn(f"[safe_bch_exact] logm failed: {e}. Falling back to 4th-order BCH.", RuntimeWarning)
        return bch(A, B)



def adaptive_expm(G, clip_norm=None, max_norm=None, threshold=1e-3):
    """
    Rescales G to prevent instability, then exponentiates using:
      - 4th-order Taylor for small ‖G‖
      - expm(G) otherwise

    Parameters:
        G: (K, K) Lie algebra element
        clip_norm: soft cap — rescales G if ‖G‖ > clip_norm
        max_norm: hard cap — forcibly rescales if ‖G‖ > max_norm
        threshold: below this, use 4th-order Taylor

    Returns:
        exp(G) ∈ Lie group
    """
    norm_G = np.linalg.norm(G) + 1e-16

    if clip_norm is not None and norm_G > clip_norm:
        G = G * (clip_norm / norm_G)

    if max_norm is not None and norm_G > max_norm:
        G = G * (max_norm / norm_G)

    if norm_G < threshold:
        I = np.eye(G.shape[0], dtype=G.dtype)
        G2 = G @ G
        G3 = G2 @ G
        G4 = G3 @ G
        return I + G + 0.5 * G2 + (1/6) * G3 + (1/24) * G4
    else:
        return expm(G)


def exp_lie_algebra_irrep(
    v_batch,
    generators,
    use_expm=True,
    threshold=1e-3,
    max_norm=None,
    group_name=None,
    n_jobs=-1,
    verbose=False
):
    """
    Compute batch of exp(sum_a v[a] * T_a) using Taylor or expm depending on norm.

    Parameters:
        v_batch: (..., dim_G) Lie algebra coefficients
        generators: (dim_G, K, K) Lie algebra generators
        use_expm: fallback to expm if large-norm
        threshold: Taylor cutoff
        max_norm: optional clip threshold (fallback to config.phi_exp_clip)
        group_name: used for antisymmetrization ("so3", "su2", etc)
        n_jobs: parallel expm if large batch
        verbose: whether to print clipping info

    Returns:
        (..., K, K) exponentiated matrices
    """
    
    *batch_shape, dim_G = v_batch.shape
    v_flat = v_batch.reshape(-1, dim_G)
    N = v_flat.shape[0]
    _, K, _ = generators.shape
    dtype = v_batch.dtype

    # ─── Clip large φ vectors ─────────────────────────────────────────────
    clip_norm = (
        max_norm
        if max_norm is not None
        else getattr(config, "phi_exp_clip", 10.0)
    )
    norm_type = getattr(config, "gradient_clip_norm_type", 2)
    eps = 1e-16

    norms = np.linalg.norm(v_flat, axis=1, ord=norm_type)
    scale_factors = np.minimum(1.0, clip_norm / (norms + eps))
    v_scaled = v_flat * scale_factors[:, None]

    if verbose and np.any(scale_factors < 1.0):
        print(f"[Ω] Clipped {np.sum(scale_factors < 1)} / {N} φ vectors to ‖φ‖ ≤ {clip_norm}")

    # ─── Build algebra elements ───────────────────────────────────────────
    G_batch = np.einsum("na,aij->nij", v_scaled, generators)

    if group_name == "so3":
        G_batch = 0.5 * (G_batch - np.transpose(G_batch, axes=(0, 2, 1)))
    elif group_name == "su2":
        G_batch = 0.5 * (G_batch - np.transpose(G_batch, axes=(0, 2, 1)).conj())

    result = np.empty((N, K, K), dtype=dtype)
    approx_mask = norms * scale_factors < threshold

    # ─── Use Taylor expansion for small matrices ──────────────────────────
    if np.any(approx_mask):
        G_approx = G_batch[approx_mask]
        I = np.eye(K, dtype=dtype)[None, :, :]
        G2 = G_approx @ G_approx
        G3 = G2 @ G_approx
        G4 = G2 @ G2
        result[approx_mask] = (
            I + G_approx + 0.5 * G2 + (1.0 / 6.0) * G3 + (1.0 / 24.0) * G4
        )

    # ─── Fallback expm for heavy matrices ─────────────────────────────────
    if np.any(~approx_mask):
        idxs = np.flatnonzero(~approx_mask)
        G_heavy = [G_batch[i] for i in idxs]
        
        with parallel_backend("threading"):
            expm_results = Parallel(n_jobs=n_jobs)(
                delayed(adaptive_expm)(
                    G, clip_norm=None, max_norm=clip_norm, threshold=threshold
                ) for G in G_heavy
            )
        for i, res in zip(idxs, expm_results):
            result[i] = res

    return result.reshape(*batch_shape, K, K)



def batch_apply_omega(mu_batch, sigma_batch, omega_batch, n_jobs=None):
    """
    Applies Ω to MVGs using gauge-covariant pushforward:
        μ' = Ω μ
        Σ' = Ω Σ Ωᵀ

    Args:
        mu_batch    : (..., K) mean field
        sigma_batch : (..., K, K) covariance field
        omega_batch : (..., K, K) gauge transport matrix field
        n_jobs      : unused (reserved for future parallelization)

    Returns:
        mu_out      : (..., K)
        sigma_out   : (..., K, K)
    """
    mu_batch    = np.asarray(mu_batch)
    sigma_batch = np.asarray(sigma_batch)
    omega_batch = np.asarray(omega_batch)

    # ───── Safety Checks ─────
    assert mu_batch.shape[:-1] == omega_batch.shape[:-2], "[Ω] Batch shape mismatch"
    assert mu_batch.shape[-1]  == omega_batch.shape[-1],  "[Ω] Fiber dimension mismatch"
    assert sigma_batch.shape[-2:] == (mu_batch.shape[-1], mu_batch.shape[-1]), "[Ω] Sigma shape mismatch"

    # ───── Sanitize input covariances ─────
    sigma_batch = sanitize_sigma(sigma_batch, eps=config.eps)

    # ───── Transport μ: μ' = Ω μ ─────
    mu_out = np.einsum("...ij,...j->...i", omega_batch, mu_batch)

    # ───── Transport Σ: Σ' = Ω Σ Ωᵀ ─────
    sigma_tmp = np.einsum("...ik,...kl->...il", omega_batch, sigma_batch)
    sigma_out = np.einsum("...ij,...jk->...ik", sigma_tmp, omega_batch)

    return mu_out, sigma_out





#==========================================================
#
#                Curvature Ops
#
#==========================================================

def compute_gauge_potential(phi, dx=1.0):
    """
    Compute gauge potentials A_μ^a = ∂_μ φ^a using central differences with periodic boundaries.

    Args:
        phi: np.ndarray, shape (..., d), where
             ... represents spatial dimensions (S_1,...,S_D),
             d = dim Lie algebra.
        dx: float, lattice spacing

    Returns:
        A: tuple of length D, each entry np.ndarray of shape (..., d),
           spatial derivatives of phi along each base manifold dimension.
    """
    D = phi.ndim - 1  # subtract Lie algebra dimension axis
    A = tuple(
        (np.roll(phi, -1, axis=axis) - np.roll(phi, 1, axis=axis)) / (2 * dx)
        for axis in range(D)
    )
    return A

def compute_field_strength(phi: np.ndarray, generators: np.ndarray, dx: float = 1.0):
    """
    Compute curvature F_{xy} = ∂_x A_y - ∂_y A_x + [A_x, A_y]
    where A_μ = ∂_μ Φ, and Φ = φ^a G_a.

    Args:
        phi:        (H, W, d) — Lie algebra coordinates φ^a(x)
        generators: (d, K, K) — Lie algebra basis
        dx:         lattice spacing

    Returns:
        Dictionary with keys ("xy", ...) → array of shape (H, W, K, K)
    """
    H, W, d = phi.shape
    K = generators.shape[1]

    # Step 1: φ(x) as matrix field: Φ(x) = φ^a(x) G_a
    phi_matrix = np.einsum("ijk,klm->ijlm", phi, generators)  # (H, W, K, K)

    # Step 2: A_x = ∂_x Φ, A_y = ∂_y Φ  — central difference w/ PBCs
    A_x = (np.roll(phi_matrix, -1, axis=0) - np.roll(phi_matrix, 1, axis=0)) / (2 * dx)  # ∂_x Φ
    A_y = (np.roll(phi_matrix, -1, axis=1) - np.roll(phi_matrix, 1, axis=1)) / (2 * dx)  # ∂_y Φ

    # Step 3: Derivatives of A
    dAy_dx = (np.roll(A_y, -1, axis=0) - np.roll(A_y, 1, axis=0)) / (2 * dx)  # ∂_x A_y
    dAx_dy = (np.roll(A_x, -1, axis=1) - np.roll(A_x, 1, axis=1)) / (2 * dx)  # ∂_y A_x

    # Step 4: Commutator [A_x, A_y]
    comm = np.einsum("ijkl,ijln->ijkn", A_x, A_y) - np.einsum("ijkl,ijln->ijkn", A_y, A_x)

    # Step 5: Curvature
    F_xy = dAy_dx - dAx_dy + comm  # shape (H, W, K, K)

    return {"xy": F_xy}


def compute_curvature_gradient_analytical(phi: np.ndarray, generators: np.ndarray, dx: float = 1.0, smoothing_sigma: float = 1.0) -> np.ndarray:
    """
    Compute the variational gradient ∇_φ Tr[F^2] in a Lie-covariant and numerically stable way.

    Args:
        phi:        (H, W, d) Lie algebra coordinates φ^a(x)
        generators: (d, K, K) Lie algebra basis G^a (must be trace-orthonormal: Tr[G^a G^b] = δ^{ab})
        dx:         lattice spacing
        smoothing_sigma: Gaussian smoothing sigma to regularize finite difference instability

    Returns:
        grad:       (H, W, d) curvature gradient in Lie algebra basis
    """

    H, W, d = phi.shape
    K = generators.shape[1]

    # Smooth φ to stabilize finite differences
    phi_smooth = np.stack([gaussian_filter(phi[..., a], sigma=smoothing_sigma, mode='wrap') for a in range(d)], axis=-1)

    # Compute A_x and A_y using central differences
    A_x = (np.roll(phi_smooth, -1, axis=0) - np.roll(phi_smooth, 1, axis=0)) / (2 * dx)
    A_y = (np.roll(phi_smooth, -1, axis=1) - np.roll(phi_smooth, 1, axis=1)) / (2 * dx)

    # Project A_μ = φ^a G^a
    A_x_mat = np.einsum("ijk,klm->ijlm", A_x, generators)
    A_y_mat = np.einsum("ijk,klm->ijlm", A_y, generators)

    # Compute F_{xy} = dA_y/dx - dA_x/dy + [A_x, A_y]
    dAy_dx = (np.roll(A_y_mat, -1, axis=0) - np.roll(A_y_mat, 1, axis=0)) / (2 * dx)
    dAx_dy = (np.roll(A_x_mat, -1, axis=1) - np.roll(A_x_mat, 1, axis=1)) / (2 * dx)

    comm_xy = np.einsum("...ij,...jk->...ik", A_x_mat, A_y_mat) - np.einsum("...ij,...jk->...ik", A_y_mat, A_x_mat)
    F_xy = dAy_dx - dAx_dy + comm_xy

    # Lie-covariant divergence D_μ F^{μν}
    dF_dx = (np.roll(F_xy, -1, axis=0) - np.roll(F_xy, 1, axis=0)) / (2 * dx)
    dF_dy = (np.roll(F_xy, -1, axis=1) - np.roll(F_xy, 1, axis=1)) / (2 * dx)

    # Commutators for covariant derivative
    comm1 = np.einsum("...ij,...jk->...ik", A_x_mat, F_xy) - np.einsum("...ij,...jk->...ik", F_xy, A_x_mat)
    comm2 = np.einsum("...ij,...jk->...ik", A_y_mat, F_xy) - np.einsum("...ij,...jk->...ik", F_xy, A_y_mat)

    divF_covariant = dF_dx + dF_dy + comm1 + comm2

    # Project back to Lie algebra basis using trace (assuming orthonormal basis)
    grad = np.zeros((H, W, d), dtype=phi.dtype)
    for a in range(d):
        G = generators[a]
        grad[..., a] = 2.0 * np.einsum("...ij,ij->...", divF_covariant, G)

    return grad

#currently unused
def compute_curvature_form(phi_x, phi_y, generators, dx=1.0, smoothing_sigma=1.0):
    """
    Computes F = dφ + 1/2 [φ ∧ φ] in discrete 2D form.

    Args:
        phi_x, phi_y: (H, W, d) components of Lie-algebra-valued 1-form φ = φ_x dx + φ_y dy
        generators:   (d, K, K) Lie algebra basis (trace-orthonormal)
        dx:           Lattice spacing
        smoothing_sigma: Optional Gaussian smoothing for stability

    Returns:
        F_xy_mat: (H, W, K, K) — curvature 2-form as Lie-algebra-valued matrix field
    """
    H, W, d = phi_x.shape
    K = generators.shape[1]

    # Optional smoothing
    phi_x_smooth = np.stack([gaussian_filter(phi_x[..., a], smoothing_sigma, mode="wrap") for a in range(d)], axis=-1)
    phi_y_smooth = np.stack([gaussian_filter(phi_y[..., a], smoothing_sigma, mode="wrap") for a in range(d)], axis=-1)

    # Compute dφ: antisymmetrized derivatives
    dphi_x = (np.roll(phi_y_smooth, -1, axis=0) - np.roll(phi_y_smooth, 1, axis=0)) / (2 * dx)
    dphi_y = (np.roll(phi_x_smooth, -1, axis=1) - np.roll(phi_x_smooth, 1, axis=1)) / (2 * dx)

    dphi_term = dphi_x - dphi_y  # Approximates ∂_x φ_y - ∂_y φ_x

    # Reconstruct φ_x, φ_y as matrices: (H, W, K, K)
    Ax = np.einsum("ijk,klm->ijlm", phi_x_smooth, generators)
    Ay = np.einsum("ijk,klm->ijlm", phi_y_smooth, generators)

    # Compute [A_x, A_y]
    commutator_term = np.einsum("...ij,...jk->...ik", Ax, Ay) - np.einsum("...ij,...jk->...ik", Ay, Ax)

    # Total curvature 2-form
    F_xy_mat = np.einsum("ijk,klm->ijlm", dphi_term, generators) + 0.5 * commutator_term

    return F_xy_mat  # shape (H, W, K, K)





#==================================================================
#
#                Holonomy And Transport Utils
#
#==================================================================


def compute_intra_omega(agent, coord_from, coord_to, generators=None):
    """
    Compute intra-agent transport Ω(p₁ ← p₀) = exp(φ(p₁)) · exp(−φ(p₀))
    """
    if generators is None:
        generators = agent.generators

    φ_from = agent.phi[coord_from]
    φ_to   = agent.phi[coord_to]

    G_from = exp_lie_algebra_irrep(φ_from[None], generators)[0]
    G_to   = exp_lie_algebra_irrep(φ_to[None], generators)[0]

    G_from_inv = safe_omega_inv(G_from)

    return G_to @ G_from_inv


def compute_inter_omega(agent_i, agent_j, overlap_pt, generators):
    """
    Compute the inter-agent gauge transform Ω_ij at a specific overlap point.
    Ω_ij = exp(φ_i) · exp(−φ_j) using a robust inversion fallback.

    Parameters
    ----------
    agent_i, agent_j : objects
        Must have an attribute `phi` of shape (H, W, D) giving the Lie-algebra
        coordinates at each grid point.
    overlap_pt : tuple of ints (h, w)
        The grid location at which the two agents overlap.
    generators : array_like
        The Lie-algebra generator matrices, passed to exp_lie_algebra_irrep.

    Returns
    -------
    Omega_ij : ndarray, shape (K, K)
        The representation matrix Ω_ij at the overlap_pt.
    """
    # extract φ vectors at the overlap point
    φi_vec = agent_i.phi[overlap_pt[0], overlap_pt[1], :]  # shape (D,)
    φj_vec = agent_j.phi[overlap_pt[0], overlap_pt[1], :]  # shape (D,)

    # exponentiate to get group elements
    Ωi_mat = exp_lie_algebra_irrep(φi_vec[None, :], generators)[0]  # (K, K)
    Ωj_mat = exp_lie_algebra_irrep(φj_vec[None, :], generators)[0]  # (K, K)

    # safely invert Ωj with condition-number checks
    Ωj_inv = safe_omega_inv(Ωj_mat)

    # multiply to get Ω_ij
    Ωij = Ωi_mat @ Ωj_inv  # (K, K)

    return Ωij



def compute_inter_omega_fieldwise(phi_i, phi_j, generators, group_name="so3"):
    """
    Compute Ω_ij = exp(φ_i) · exp(−φ_j) from two Lie algebra fields.

    Args:
        phi_i      : (H, W, d) or (N, d) array of Lie algebra coords for agent i
        phi_j      : same shape as phi_i
        generators : (d, K, K) Lie algebra generators
        group_name : string (e.g., 'sl2r', 'so3', etc.)

    Returns:
        Omega_ij   : (H, W, K, K) or (N, K, K) gauge transport matrices
    """
    phi_i = np.asarray(phi_i)
    phi_j = np.asarray(phi_j)

    if phi_i.shape != phi_j.shape:
        raise ValueError(f"[compute_inter_omega_fieldwise] Shape mismatch: {phi_i.shape} vs {phi_j.shape}")

    is_grid = (phi_i.ndim == 3)
    d = phi_i.shape[-1]

    # Reshape to flat (N, d)
    phi_i_flat = phi_i.reshape(-1, d)
    phi_j_flat = phi_j.reshape(-1, d)

    # Compute exp(φ_i) and exp(−φ_j)
    exp_i = exp_lie_algebra_irrep(phi_i_flat, generators, group_name=group_name)           # (N, K, K)
    exp_j = exp_lie_algebra_irrep(-phi_j_flat, generators, group_name=group_name)          # (N, K, K)

    # Compose: Ω_ij = exp(φ_i) · exp(−φ_j)
    Omega_flat = np.einsum("nij,njk->nik", exp_i, exp_j)                                   # (N, K, K)

    if is_grid:
        H, W = phi_i.shape[:2]
        return Omega_flat.reshape(H, W, *Omega_flat.shape[-2:])                            # (H, W, K, K)
    else:
        return Omega_flat                                                                  # (N, K, K)




