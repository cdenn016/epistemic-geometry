import numpy as np
import matplotlib.pyplot as plt
import os
from numpy.linalg import inv
from generalized_io_utils import load_all_checkpoints, load_latest_checkpoint  # From uploaded file
from get_generators import get_generators
from generalized_omega import compute_field_strength
import config

def compute_fisher_pullback_eta(eta1, eta2, mask=None, eps=1e-8):
    """
    Compute pullback Fisher metric G_{μν}(c) from η₁, η₂ fields.
    Uses masked μ, Σ to avoid spurious gradients outside agent support.

    Args:
        eta1: (H, W, K)
        eta2: (H, W, K, K)
        mask: (H, W) or None — support mask
        eps : stabilizer

    Returns:
        G: (H, W, 2, 2) pullback Fisher metric
    """
    import numpy as np
    from natural_params_utils import compute_mu_sigma_from_natural
    from numerical_utils import safe_inv

    mu, Sigma = compute_mu_sigma_from_natural(eta1, eta2, eps=eps)

    # ─── Early masking to prevent garbage gradients ───
    if mask is not None:
        mu    = mu * mask[..., None]
        Sigma = Sigma * mask[..., None, None]

    Sigma_inv = safe_inv(Sigma, eps=eps)

    # Gradients of μ and Σ
    dmu_dx     = np.gradient(mu, axis=0)
    dmu_dy     = np.gradient(mu, axis=1)
    dSigma_dx  = np.gradient(Sigma, axis=0)
    dSigma_dy  = np.gradient(Sigma, axis=1)

    # Metric components
    G_xx = np.einsum("...i,...ij,...j->...", dmu_dx, Sigma_inv, dmu_dx) + \
           0.5 * np.einsum("...ij,...jk,...kl,...li->...", Sigma_inv, dSigma_dx, Sigma_inv, dSigma_dx)

    G_xy = np.einsum("...i,...ij,...j->...", dmu_dx, Sigma_inv, dmu_dy) + \
           0.5 * np.einsum("...ij,...jk,...kl,...li->...", Sigma_inv, dSigma_dx, Sigma_inv, dSigma_dy)

    G_yy = np.einsum("...i,...ij,...j->...", dmu_dy, Sigma_inv, dmu_dy) + \
           0.5 * np.einsum("...ij,...jk,...kl,...li->...", Sigma_inv, dSigma_dy, Sigma_inv, dSigma_dy)

    G = np.stack([
        np.stack([G_xx, G_xy], axis=-1),
        np.stack([G_xy, G_yy], axis=-1)
    ], axis=-2)  # shape (H, W, 2, 2)

    # Final masking to eliminate noise
    if mask is not None:
        G *= mask[..., None, None]

    return G





def compute_pullback_curl_eta(G_field: np.ndarray, dx: float = 1.0):
    """
    Compute ∇_{[μ} G_{ν]} — antisymmetric curl of pullback Fisher metric.

    Assumes central difference approximation and periodic boundary conditions.

    Args:
        G_field: (H, W, K, K)
        dx: grid spacing

    Returns:
        curl: (H, W, K, K) — antisymmetrized derivative of Fisher metric
    """
    dG_dx = (np.roll(G_field, -1, axis=0) - np.roll(G_field, 1, axis=0)) / (2 * dx)
    dG_dy = (np.roll(G_field, -1, axis=1) - np.roll(G_field, 1, axis=1)) / (2 * dx)
    return dG_dx - dG_dy  # antisymmetric ∇_x G_y - ∇_y G_x

def compare_curvature_to_pullback(F: np.ndarray, curl_G: np.ndarray):
    """
    Compare gauge curvature F and pullback curl ∇_{[μ} G_{ν]}.

    Args:
        F       : (H, W, K, K) — gauge curvature tensor
        curl_G  : (H, W, K, K) — antisymmetric Fisher curl

    Returns:
        norm_F         : (H, W) — Frobenius norm of F
        norm_curl_G    : (H, W) — Frobenius norm of curl G
        correlation    : float — Pearson correlation between flattened norms
    """
    norm_F = np.linalg.norm(F, ord="fro", axis=(-2, -1))         # (H, W)
    norm_curl_G = np.linalg.norm(curl_G, ord="fro", axis=(-2, -1))  # (H, W)

    norm_F_flat = norm_F.flatten()
    norm_curl_flat = norm_curl_G.flatten()

    # Remove NaNs/Infs for correlation
    mask = np.isfinite(norm_F_flat) & np.isfinite(norm_curl_flat)
    correlation = np.corrcoef(norm_F_flat[mask], norm_curl_flat[mask])[0, 1]

    return norm_F, norm_curl_G, correlation

def run_diagnostics(checkpoint_path, load_latest=True):
    """
    Run Fisher curvature diagnostic:
        - Loads checkpoint with η₁, η₂, φ from agents
        - Computes pullback Fisher metric from η₂
        - Computes gauge curvature from φ
        - Compares ∇_[μ G_ν] vs F_{μν}
    """
    if load_latest:
        agents = load_latest_checkpoint(checkpoint_path)
    else:
        all_data = load_all_checkpoints(checkpoint_path)
        agents = all_data[-1]  # Use the last checkpoint list

    total_mask = np.sum([a.mask for a in agents], axis=0)  # shape (H, W)

    eta1_q = np.sum([a.eta1_q_field * a.mask[..., None] for a in agents], axis=0) \
         / (total_mask[..., None] + 1e-8)

    eta2_q = np.sum([a.eta2_q_field * a.mask[..., None, None] for a in agents], axis=0) \
         / (total_mask[..., None, None] + 1e-8)

    phi = np.sum([a.phi * a.mask[..., None] for a in agents], axis=0) \
      / (total_mask[..., None] + 1e-8)



    # Compute pullback Fisher metric
    G_pullback = compute_fisher_pullback_eta(eta1_q, eta2_q)  # (H, W, K, K)

    # Compute numerical curl of G
    curl_G = compute_pullback_curl_eta(G_pullback, dx=1.0)

    # Compute curvature from phi
    generators = get_generators(config.group_name, config.K_q)    # (d, K, K)
    F_field = compute_field_strength(phi, generators)["xy"]       # (H, W, K, K)

    # Compare norms and correlation
    norm_F, norm_curl_G, correlation = compare_curvature_to_pullback(F_field, curl_G)

    # Plot results
    plt.figure(figsize=(12, 6))

    plt.subplot(1, 2, 1)
    plt.imshow(norm_F, cmap='hot')
    plt.title("||F_{μν}||")
    plt.colorbar()

    plt.subplot(1, 2, 2)
    plt.imshow(norm_curl_G, cmap='hot')
    plt.title("||∇_{[μ} G_{ν]}||")
    plt.colorbar()

    plt.tight_layout()
    plt.show()

    print(f"[Fisher Curvature Diagnostic] Correlation = {correlation:.4f}")


# Run the diagnostics when this script is executed directly
if __name__ == "__main__":
    checkpoint_path = "checkpoints"  # Replace with the actual path
    run_diagnostics(checkpoint_path, load_latest=True)  # Set load_latest=True to use the latest checkpoint
