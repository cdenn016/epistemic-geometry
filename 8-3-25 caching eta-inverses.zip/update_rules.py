# -*- coding: utf-8 -*-
"""
Created on Wed Jul 23 10:32:58 2025

@author: chris and christine
"""
from joblib import Parallel, delayed
import numpy as np
import config
from natural_gradient import (compute_inverse_fisher_field_natural, compute_inverse_fisher_morphism_field,
                              )
from generalized_omega import exp_lie_algebra_irrep   
from generalized_math_utils import safe_batch_inverse     
from numerical_utils import sanitize_sigma, sanitize_eta2               
from generalized_diagnostics_metrics import compute_alignment_field_general
from update_terms_morphisms import (
                                    accumulate_phi_gradient_from_morphism_self_and_feedback, 
                                    accumulate_phi_tilde_gradient_from_morphism_self_and_feedback
                                    )

from get_generators import get_generators
from update_terms_eta1_eta2_belief import accumulate_eta_gradient_belief
from update_terms_eta1_eta2_model import accumulate_eta_gradient_model

from update_terms_phi import accumulate_phi_gradient_belief, accumulate_phi_gradient_model

from omega import exp_lie_algebra_irrep, compute_exp_field
from natural_params_utils import natural_to_mu_sigma_batch
from numerical_utils import soft_clip_phi_norm, safe_inv

def zero_all_gradients(agent_i):
    agent_i.grad_eta1_q_field.fill(0)
    agent_i.grad_eta2_q_field.fill(0)
    agent_i.grad_eta1_p_field.fill(0)
    agent_i.grad_eta2_p_field.fill(0)
    agent_i.grad_phi.fill(0)
    agent_i.grad_phi_tilde.fill(0)

    if agent_i.grad_Phi is not None:
        agent_i.grad_Phi.fill(0)
    if agent_i.grad_Phi_tilde is not None:
        agent_i.grad_Phi_tilde.fill(0)



def preprocess_agent_fields(agent, params):
    """Sanitize sigmas, cache Fisher info, compute exp(φ), exp(−φ), and Fisher metrics."""
    e_belief = params.get("e_belief", config.e_belief)
    e_model  = params.get("e_model",  config.e_model)

    # ───── Fetch Lie algebra generators from dicts ─────
    G_q = get_generators(config.group_name, config.K_q)
    G_p = get_generators(config.group_name, config.K_p)

    # ───── Compute exp(φ), exp(−φ) for belief ─────
    agent._exp_phi = compute_exp_field(agent.phi, G_q, e_belief, max_norm=config.phi_exp_clip)
    agent._exp_neg_phi = safe_batch_inverse(agent._exp_phi)

    # ───── Compute exp(φ_model), exp(−φ_model) for model ─────
    agent._exp_phi_model = compute_exp_field(agent.phi_model, G_p, e_model, max_norm=config.phi_exp_clip)
    agent._exp_neg_phi_model = safe_batch_inverse(agent._exp_phi_model)

    #agent.eta2_q_inv = safe_inv(agent.eta2_q_field, eps=config.eps)
    #agent.eta2_p_inv = safe_inv(agent.eta2_p_field, eps=config.eps)

    
    # ───── Optional inverse Fisher metric cache for φ updates ─────
    agent.inverse_fisher_phi = compute_inverse_fisher_field_natural(
        agent.eta2_q_field, G_q, mask=agent.mask > config.support_cutoff_eps
    )
    agent.inverse_fisher_phi_model = compute_inverse_fisher_field_natural(
        agent.eta2_p_field, G_p, mask=agent.mask > config.support_cutoff_eps
    )



def compute_all_gradients(agent_i, agents, generators_q, generators_p, params):
    zero_all_gradients(agent_i)

    # ─── η-gradient updates ───
    accumulate_eta_gradient_belief(agent_i, agents, params)
    accumulate_eta_gradient_model(agent_i, agents, params)

    # ─── φ and φ̃ updates via alignment terms ───
    for nb in agent_i.neighbors:
        agent_j = agents[nb["id"]]
        accumulate_phi_gradient_belief(agent_i, agent_j, generators_q, params)
        accumulate_phi_gradient_model(agent_i, agent_j, generators_p, params)

    # ─── φ update from morphism self + feedback terms ───
    accumulate_phi_gradient_from_morphism_self_and_feedback(
        agent_i, generators_p, generators_q, params
    )

    # ─── φ̃ update from morphism self + feedback terms ───
    accumulate_phi_tilde_gradient_from_morphism_self_and_feedback(
        agent_i, generators_p, generators_q, params
    )

    # --- Print gradient norms directly from agent_i ---
   # print(f"[grad_eta1_q] norm = {np.linalg.norm(agent_i.grad_eta1_q_field):.4e}")
  #  print(f"[grad_eta2_q] norm = {np.linalg.norm(agent_i.grad_eta2_q_field):.4e}")
  #  print(f"[grad_eta1_p] norm = {np.linalg.norm(agent_i.grad_eta1_p_field):.4e}")
  #  print(f"[grad_eta2_p] norm = {np.linalg.norm(agent_i.grad_eta2_p_field):.4e}")
  #  print(f"[grad_phi]     norm = {np.linalg.norm(agent_i.grad_phi):.4e}")
  #  print(f"[grad_phi_tilde] norm = {np.linalg.norm(agent_i.grad_phi_tilde):.4e}\n")
    
    return (
    (agent_i.grad_eta1_q_field, agent_i.grad_eta2_q_field),
    (agent_i.grad_eta1_p_field, agent_i.grad_eta2_p_field),
    agent_i.grad_phi,
    agent_i.grad_phi_tilde,
    agent_i.grad_Phi,
    agent_i.grad_Phi_tilde,
)



def compute_adaptive_eta(base_eta, grad, cached_kl, eta2_field, 
                         scaling_kl, scaling_cond, eta_min, eps=1e-8):
    """
    Computes adaptive step size η based on KL divergence and condition number of η₂.
    """

    # KL or gradient fallback
    if cached_kl is not None and np.isfinite(np.mean(cached_kl)):
        kl_term = np.mean(cached_kl)
    else:
        kl_term = np.linalg.norm(grad) / np.prod(grad.shape)

    # Condition number estimation (vectorized safely)
    try:
        eta2_reshaped = eta2_field.reshape(-1, eta2_field.shape[-2], eta2_field.shape[-1])
        conds = np.array([
            np.linalg.cond(e + eps * np.eye(e.shape[-1]))
            for e in eta2_reshaped
        ])
        cond_avg = np.mean(conds)
    except Exception:
        cond_avg = 1.0

    denom = 1.0 + scaling_kl * kl_term + scaling_cond * cond_avg
    eta_scaled = base_eta / denom
    return np.clip(eta_scaled, eta_min, base_eta)



def apply_phi_updates(agent, grad_phi, grad_phi_m, mask, params):
    
    
    mask_exp = mask[..., None]
    grad_phi = grad_phi * mask_exp
    grad_phi_m = grad_phi_m * mask_exp

    def clip_lie_update(delta, threshold):
        if threshold <= 0:
            return delta
        norm = np.linalg.norm(delta, axis=-1, keepdims=True)
        factor = np.minimum(1.0, threshold / (norm + 1e-8))
        return delta * factor

    cfg = {k: getattr(config, k) for k in dir(config) if not k.startswith("__")}
    if params is not None:
        cfg.update(params)

    # ───── φ update (belief) ─────
    eta_phi_tuned = compute_adaptive_eta(
        cfg["eta_base_phi"],
        grad_phi,
        getattr(agent, "cached_alignment_kl", None),
        agent.eta2_q_field,
        cfg["eta_phi_adaptive_scaling"],
        cfg["eta_sigma_condition_scaling"],
        cfg["eta_phi_min"],
    )
    eta_phi_tuned = np.clip(eta_phi_tuned, cfg["eta_phi_min"], cfg["eta_phi_max"])
    delta_phi = eta_phi_tuned * grad_phi
    delta_phi = clip_lie_update(delta_phi, cfg.get("phi_grad_clip", 0.0))
    delta_phi = np.nan_to_num(delta_phi, nan=0.0, posinf=1e5, neginf=-1e5)
    agent.phi -= delta_phi  # Already masked

    # ───── φ̃ update (model) ─────
    eta_phi_m_tuned = compute_adaptive_eta(
        cfg["eta_base_phi_model"],
        grad_phi_m,
        getattr(agent, "cached_model_alignment_kl", None),
        agent.eta2_p_field,
        cfg["eta_phi_model_adaptive_scaling"],
        cfg["eta_sigma_condition_scaling"],
        cfg["eta_phi_model_min"],
    )
    eta_phi_m_tuned = np.clip(eta_phi_m_tuned, cfg["eta_phi_model_min"], cfg["eta_phi_model_max"])
    delta_phi_m = eta_phi_m_tuned * grad_phi_m
    delta_phi_m = clip_lie_update(delta_phi_m, cfg.get("phi_model_grad_clip", 0.0))
    delta_phi_m = np.nan_to_num(delta_phi_m, nan=0.0, posinf=1e5, neginf=-1e5)
    agent.phi_model -= delta_phi_m  # Already masked


#from metrics import compute_alignment_field_general

from generalized_diagnostics_metrics import compute_alignment_field_general


def synchronous_step(agents, generators_q, generators_p, params=None, n_jobs=1):
    params = params or {}
    N = len(agents)
    print(f"[DEBUG] Using {n_jobs} workers in synchronous_step")

    eta1_belief = params.get("eta1_belief", config.eta1_belief)
    eta2_belief = params.get("eta2_belief", config.eta2_belief)
    eta1_model  = params.get("eta1_model",  config.eta1_model)
    eta2_model  = params.get("eta2_model",  config.eta2_model)
    eps = config.eps

    # Step 1: Preprocess
    Parallel(n_jobs=n_jobs, backend="threading", batch_size=1)(
        delayed(preprocess_agent_fields)(A, params) for A in agents
    )

    # Step 2: Compute gradients
    grads = Parallel(n_jobs=n_jobs, backend="loky", batch_size=4)(
        delayed(compute_all_gradients)(agent_i, agents, generators_q, generators_p, params)
        for agent_i in agents
    )
    q_updates, p_updates, phi_grads, phi_m_grads, morphism_grads, morphism_tilde_grads = zip(*grads)
    mask_list = [A.mask for A in agents]

    # Step 3: Apply η and φ updates
    def apply_agent_updates(i):
        agent = agents[i]
        mask = mask_list[i]

        Δη1_q, Δη2_q = q_updates[i]
        Δη1_p, Δη2_p = p_updates[i]
        
        mask_mu    = mask[..., None]
        mask_sigma = mask[..., None, None]

        # Debug: Norm of applied updates
        q_mu_update = eta1_belief * Δη1_q * mask_mu
        p_mu_update = eta1_model  * Δη1_p * mask_mu
        q_si_update = eta2_belief * Δη2_q * mask_sigma
        p_si_update = eta2_model  * Δη2_p * mask_sigma

       # print(f"[DEBUG @ agent {i}] ‖Δη1_q‖ = {np.linalg.norm(q_mu_update):.4e} | ‖Δη2_q‖ = {np.linalg.norm(q_si_update):.4e}")
       # print(f"[DEBUG @ agent {i}] ‖Δη1_p‖ = {np.linalg.norm(p_mu_update):.4e} | ‖Δη2_p‖ = {np.linalg.norm(p_si_update):.4e}")

        # Apply η updates
        agent.eta1_q_field -= q_mu_update
        agent.eta1_p_field -= p_mu_update
        agent.eta2_q_field = sanitize_eta2(agent.eta2_q_field - q_si_update, eps=eps)
        agent.eta2_p_field = sanitize_eta2(agent.eta2_p_field - p_si_update, eps=eps)

        # Apply φ and φ̃ updates
        apply_phi_updates(agent, phi_grads[i], phi_m_grads[i], mask, params)
        
        # Clip φ and φ̃ to norm ≤ π after update
        agent.phi       = soft_clip_phi_norm(agent.phi, max_norm=np.pi)
        agent.phi_model = soft_clip_phi_norm(agent.phi_model, max_norm=np.pi)

        return agent

    # Step 4: Apply updates in parallel
    Parallel(n_jobs=n_jobs, backend="threading", batch_size="auto")(
        delayed(apply_agent_updates)(i) for i in range(N)
    )


    # Step 5: Refresh cached KL fields
    for A in agents:
        A.cached_alignment_kl       = compute_alignment_field_general(agents, A.id, field_type="belief", log_eps=eps)
        A.cached_model_alignment_kl = compute_alignment_field_general(agents, A.id, field_type="model",  log_eps=eps)

    return agents

