"""
Created on Sat Sep 27 15:19:10 2025

@author: chris and christine

default gamma_q -- Case A:  KL( q_j] ||Ω^q_ji Φ̃_i p_i )
default gamma_p -- Case B:  KL( p_i || Φ_i Ω^q_ij[q_j] )  

or should they be the other way around?

Default beta_q:  KL( q_i || Ω^q_ij q_j )
Default beta_p:  KL( p_i || Ω^p_ij p_j ) 

"""
import numpy as np
from core.numerical_utils import push_gaussian, sanitize_sigma, safe_inv  # tight/safe impls
from core.transport_cache import Omega, Phi, E_grid         
from utils import push_neighbor_stats, _assert_finite


def _zeros_mu_S_like(mu):
    mu = np.asarray(mu, np.float32)
    S  = mu.shape[:-1]
    K  = mu.shape[-1]
    return (np.zeros(S + (K,),    np.float32),
            np.zeros(S + (K, K), np.float32))



def grad_gamma_mu_sigma_dispatch(
    ctx, agent_i, agent_j, *, basis,
    Omega_ij=None, Phi_i=None, Phi_tilde_i=None,
    eps: float = 1e-8,
):
    

    b = str(basis).lower()

    # ---- trivial align_* bases: no cross-fiber grads here
    if b in {"align", "align_q", "align_p"}:
        mu_i_any = getattr(agent_i, "mu_p_field", None)
        if mu_i_any is None:
            mu_i_any = getattr(agent_i, "mu_q_field", None)

        mu_j_q = getattr(agent_j, "mu_q_field", None)
        if mu_j_q is None:
            mu_j_q = getattr(agent_j, "mu_p_field", None)

        mu_rec_0, S_rec_0   = _zeros_mu_S_like(mu_i_any)
        mu_send_0, S_send_0 = _zeros_mu_S_like(mu_j_q)
        return {"mu_rec": mu_rec_0, "S_rec": S_rec_0,
                "mu_send": mu_send_0, "S_send": S_send_0}

   
    # ---- full A/B need Ω (and Φ/Φ̃ for A/B or C/D)
    if Omega_ij is None:
        raise ValueError("grad_beta_mu_sigma_dispatch: Omega_ij is required for bases A/B/C/D")

    if Phi_i is None and b in {"a","b"}:
        from core.transport_cache import Phi as _Phi
        Phi_i = _Phi(ctx, agent_i, kind="q_to_p")
    if Phi_tilde_i is None and b in {"c","d"}:
        from core.transport_cache import Phi as _Phi
        Phi_tilde_i = _Phi(ctx, agent_i, kind="p_to_q")

    mu_q_j  = np.asarray(agent_j.mu_q_field,    np.float32, order="C")
    Sig_q_j = np.asarray(agent_j.sigma_q_field, np.float32, order="C")
    mu_p_i  = np.asarray(agent_i.mu_p_field,    np.float32, order="C")
    Sig_p_i = np.asarray(agent_i.sigma_p_field, np.float32, order="C")

    if b == "a":
        dmu_rec, dS_rec = grad_gamma_A_mu_sigma_i(ctx, agent_i, agent_j, Omega_ij=Omega_ij, eps=eps)
        dmu_send, dS_send = grad_gamma_A_mu_sigma_j(
            mu_j=mu_q_j, Sigma_j=Sig_q_j,
            mu_p_i=mu_p_i, Sigma_p_i=Sig_p_i,
            Omega_ij=Omega_ij, Phi_i=Phi_i, eps=eps,
        )
        _assert_finite(f"beta_grads[{basis}]",
                       dmu_rec, dS_rec, dmu_send, dS_send)
    elif b == "b":
        dmu_rec, dS_rec = grad_gamma_B_mu_sigma_i(ctx, agent_i, agent_j, Omega_ij=Omega_ij, eps=eps)
        dmu_send, dS_send = grad_gamma_B_mu_sigma_j(
            mu_j=mu_q_j, Sigma_j=Sig_q_j,
            mu_p_i=mu_p_i, Sigma_p_i=Sig_p_i,
            Omega_ij=Omega_ij, Phi_i=Phi_i, eps=eps,
        )
    
    else:
        raise ValueError(f"Unknown beta basis: {basis}")

    dS_rec  = 0.5 * (dS_rec  + np.swapaxes(dS_rec,  -1, -2)).astype(np.float32, copy=False)
    dS_send = 0.5 * (dS_send + np.swapaxes(dS_send, -1, -2)).astype(np.float32, copy=False)
    return {
        "mu_rec":  np.asarray(dmu_rec,  np.float32),
        "S_rec":   dS_rec,
        "mu_send": np.asarray(dmu_send, np.float32),
        "S_send":  dS_send,
    }





def grad_gamma_phi_covectors(
    ctx, agent_i, agent_j,
    *,
    basis: str,
    Omega_ij=None,
    generators_irrep=None,   # (3,K,K) or None if K==3
    eps: float = 1e-8,
):
    """
    β-basis A/B dispatcher (covector-first).
    Returns param-space *covectors* (∂KL_beta/∂φ)_param per site/fiber:
        (g_phi_i_q_cov, g_phi_j_q_cov, g_phi_i_p_cov)  each (*S,3).

    For basis in {"align", "align_q", "align_p"}, returns zeros (product-rule handled elsewhere).
    """
    b = str(basis).lower()
    

    if b == "a":
        return grad_gamma_A_phi_covectors(
            ctx, agent_i, agent_j,
            Omega_ij=Omega_ij,
            generators_irrep=generators_irrep,
            eps=eps,
        )
    if b == "b":
        return grad_gamma_B_phi_covectors(
            ctx, agent_i, agent_j,
            Omega_ij=Omega_ij,
            generators_irrep=generators_irrep,
            eps=eps,
        )
    
    # Unknown basis → zeros
    S = tuple(agent_i.mu_p_field.shape[:-1])
    z = np.zeros(S + (3,), np.float32)
    return z, z, z

def grad_gamma_A_mu_sigma_i(ctx, agent_i, agent_j, *, Omega_ij=None, eps: float = 1e-8,
                           use_identity: bool = False):
    """
    ∂ KL_gamma / ∂(μ_{p_i}, Σ_{p_i}) for Case A using the dual form:
        KL_gamma = KL( q_j || Ω^q_{ji}[ Φ̃_i p_i ] )  in Q_j frame.

    If use_identity == True: use the simple (stable) limit KL(q_j || p_i).
    """
    import numpy as np
    from core.numerical_utils import sanitize_sigma, safe_inv
    from core.transport_cache import Omega, Phi

    # Receiver stats (work in float64 for stability)
    mu_p = np.asarray(agent_i.mu_p_field,  np.float64, order="C")
    S_p  = sanitize_sigma(np.asarray(agent_i.sigma_p_field, np.float64), eps=eps)

    if use_identity:
        # KL(q_j || p_i), gradients w.r.t. p_i
        mu_j = np.asarray(agent_j.mu_q_field,    np.float64, order="C")
        S_j  = sanitize_sigma(np.asarray(agent_j.sigma_q_field, np.float64), eps=eps)
        # ∂/∂μ_Q KL(P||Q) = Σ_Q^{-1}(μ_Q-μ_P)
        S_p_inv = safe_inv(S_p, eps=max(eps, 1e-12))
        dmu = np.einsum("...ij,...j->...i", S_p_inv, (mu_p - mu_j), optimize=True)
        # ∂/∂Σ_Q KL(P||Q) = 1/2(-Σ_Q^{-1} Σ_P Σ_Q^{-1} - Σ_Q^{-1}(μ_Q-μ_P)(μ_Q-μ_P)^T Σ_Q^{-1} + Σ_Q^{-1})
        d = mu_p - mu_j
        v = np.einsum("...ij,...j->...i", S_p_inv, d, optimize=True)
        vvT = np.einsum("...i,...j->...ij", v, v, optimize=True)
        term = np.einsum("...ij,...jk->...ik", S_p_inv, np.einsum("...jk,...kl->...jl", S_j, S_p_inv, optimize=True), optimize=True)
        gS  = 0.5 * (-term - vvT + S_p_inv)
        gS  = 0.5 * (gS + np.swapaxes(gS, -1, -2))
        return dmu.astype(np.float32, copy=False), gS.astype(np.float32, copy=False)

    # --- Dual path: KL(q_j || Ω_ji[ Φ̃_i p_i ]) ---
    Phit_i = np.asarray(Phi(ctx, agent_i, kind="p_to_q"), np.float64)         # Φ̃_i : P_i→Q_i
    Om_ji  = np.asarray(Omega(ctx, agent_j, agent_i, which="q"), np.float64)  # Ω_ji^q : Q_i→Q_j

    # q̂_i = Φ̃_i p_i  (in Q_i)
    mu_qhat = np.einsum("...ij,...j->...i", Phit_i, mu_p, optimize=True)
    S_qhat  = np.einsum("...ij,...jk,...lk->...il", Phit_i, S_p, Phit_i, optimize=True)

    # Landing stats in Q_j via Ω_ji
    mu_L = np.einsum("...ij,...j->...i", Om_ji, mu_qhat, optimize=True)
    S_L  = np.einsum("...ij,...jk,...lk->...il", Om_ji, S_qhat, Om_ji, optimize=True)
    S_L  = sanitize_sigma(S_L, eps=eps)
    S_L_inv = safe_inv(S_L, eps=max(eps, 1e-12))

    # Sender (fixed) stats
    mu_j = np.asarray(agent_j.mu_q_field,    np.float64, order="C")
    S_j  = sanitize_sigma(np.asarray(agent_j.sigma_q_field, np.float64), eps=eps)

    # KL(q_j || N(mu_L,S_L)) partials wrt (mu_L, S_L)
    # g_muL = Σ_L^{-1}(μ_L - μ_j)
    dL   = mu_L - mu_j
    g_muL = np.einsum("...ij,...j->...i", S_L_inv, dL, optimize=True)

    # g_SL = 1/2(-Σ_L^{-1} Σ_j Σ_L^{-1} - Σ_L^{-1} dL dL^T Σ_L^{-1} + Σ_L^{-1})
    v    = np.einsum("...ij,...j->...i", S_L_inv, dL, optimize=True)
    vvT  = np.einsum("...i,...j->...ij", v, v, optimize=True)
    term = np.einsum("...ij,...jk->...ik", S_L_inv,
                     np.einsum("...jk,...kl->...jl", S_j, S_L_inv, optimize=True),
                     optimize=True)
    g_SL = 0.5 * (-term - vvT + S_L_inv)
    g_SL = 0.5 * (g_SL + np.swapaxes(g_SL, -1, -2))

    # Backprop through Ω_ji: μ_L = Ω_ji μ_qhat, Σ_L = Ω_ji Σ_qhat Ω_ji^T
    g_mu_qhat = np.einsum("...ji,...j->...i", Om_ji, g_muL, optimize=True)                         # Ω_ji^T g_muL
    g_S_qhat  = np.einsum("...ji,...jk,...kl->...il", Om_ji, g_SL, Om_ji, optimize=True)           # Ω_ji^T g_SL Ω_ji

    # Backprop through Φ̃_i: μ_qhat = Φ̃_i μ_p, Σ_qhat = Φ̃_i Σ_p Φ̃_i^T
    dmu_p = np.einsum("...ji,...j->...i", Phit_i, g_mu_qhat, optimize=True)                        # Φ̃_i^T g_mu_qhat
    dS_p  = np.einsum("...ji,...jk,...kl->...il", Phit_i, g_S_qhat, Phit_i, optimize=True)         # Φ̃_i^T g_S_qhat Φ̃_i
    dS_p  = 0.5 * (dS_p + np.swapaxes(dS_p, -1, -2))

    return dmu_p.astype(np.float32, copy=False), dS_p.astype(np.float32, copy=False)



# ---------------- A: KL( Φ_i[Ω q_j]  ||  p_i )  — target in P_i


    
def grad_gamma_A_mu_sigma_j(
    mu_j, Sigma_j,                  # (...,K), (...,K,K)  sender q_j
    mu_p_i, Sigma_p_i,              # (...,K), (...,K,K)  receiver p_i
    Omega_ij, Phi_i,                # (...,K,K), (...,K,K)
    *,
    R=None,                         # ignored in dual path
    mu_L=None,                      # ignored in dual path
    Sigma_L=None,                   # ignored in dual path
    Sigma_L_inv=None,               # ignored in dual path
    Sigma_p_inv=None,               # optional (used for identity fallback only)
    mask=None,
    eps: float = 1e-8,
    assume_sanitized: bool = True,
    use_identity: bool = False,     # ΦΩ → Id : KL(q_j || p_i)
):
    """
    Sender-side ∂KL/∂(μ_j, Σ_j) for Case A using the dual:
        KL_A = KL( q_j || Ω^q_{ji}[ Φ̃_i p_i ] ).

    If use_identity == True, use KL(q_j || p_i).
    """
    import numpy as np
    from core.transport_cache import Omega, Phi
    from core.numerical_utils import sanitize_sigma, safe_inv

    # ---- as float64 for stability ----
    mu_j  = np.asarray(mu_j,      np.float64, order="C")
    Sj    = np.asarray(Sigma_j,   np.float64, order="C")
    mu_pi = np.asarray(mu_p_i,    np.float64, order="C")
    Sp    = np.asarray(Sigma_p_i, np.float64, order="C")
    Phi_i = np.asarray(Phi_i,     np.float64, order="C")
    Om_ij = np.asarray(Omega_ij,  np.float64, order="C")

    # sanitize covariances
    Sj = sanitize_sigma(Sj, eps=eps) if not assume_sanitized else Sj
    Sp = sanitize_sigma(Sp, eps=eps) if not assume_sanitized else Sp

    if use_identity:
        # KL(q_j || p_i)
        Sp_inv = Sigma_p_inv if Sigma_p_inv is not None else safe_inv(Sp, eps=max(eps, 1e-12))
        Sp_inv = np.asarray(Sp_inv, np.float64, order="C")
        dmu = np.einsum("...ij,...j->...i", Sp_inv, (mu_j - mu_pi), optimize=True)
        Sj_inv = safe_inv(Sj, eps=max(eps, 1e-12))
        dS  = 0.5 * (Sp_inv - Sj_inv)
        dS  = 0.5 * (dS + np.swapaxes(dS, -1, -2))
        if mask is not None:
            m = (np.asarray(mask) > 0).astype(np.float64, copy=False)
            dmu = dmu * m[..., None]
            dS  = dS  * m[..., None, None]
        return dmu.astype(np.float32, copy=False), dS.astype(np.float32, copy=False)

    # ---- dual path: build q̂_j = Ω_ji[ Φ̃_i p_i ] in Q_j ----
    Phit_i = np.asarray(Phi(None, None, kind="p_to_q") if Phi_i is None else Phi_i, np.float64)
    # If you have ctx/agents here, prefer cache: Phit_i = Phi(ctx, agent_i, kind="p_to_q")
    Om_ji  = np.asarray(Omega(None, None, which="q") if Om_ij is None else np.swapaxes(Om_ij, -1, -2), np.float64)
    # Prefer cache as well: Om_ji = Omega(ctx, agent_j, agent_i, which="q")

    # q̂_i = Φ̃_i p_i (in Q_i)
    mu_qhat_i = np.einsum("...ij,...j->...i", Phit_i, mu_pi, optimize=True)
    S_qhat_i  = np.einsum("...ij,...jk,...lk->...il", Phit_i, Sp, Phit_i, optimize=True)

    # push to Q_j via Ω_ji
    mu_hat = np.einsum("...ij,...j->...i", Om_ji, mu_qhat_i, optimize=True)
    S_hat  = np.einsum("...ij,...jk,...lk->...il", Om_ji, S_qhat_i, Om_ji, optimize=True)
    S_hat  = sanitize_sigma(S_hat, eps=eps)
    S_hat_inv = safe_inv(S_hat, eps=max(eps, 1e-12))

    # ---- KL(q_j || N(mu_hat, S_hat)) grads wrt (μ_j, Σ_j) ----
    dmu = np.einsum("...ij,...j->...i", S_hat_inv, (mu_j - mu_hat), optimize=True)
    Sj_inv = safe_inv(Sj, eps=max(eps, 1e-12))
    dS  = 0.5 * (S_hat_inv - Sj_inv)
    dS  = 0.5 * (dS + np.swapaxes(dS, -1, -2))

    # ---- optional mask ----
    if mask is not None:
        m = (np.asarray(mask) > 0).astype(np.float64, copy=False)
        dmu = dmu * m[..., None]
        dS  = dS  * m[..., None, None]

    return dmu.astype(np.float32, copy=False), dS.astype(np.float32, copy=False)




def grad_gamma_A_phi_covectors(
    ctx, agent_i, agent_j,
    *,
    Omega_ij=None,                 # <— added back for compatibility (ignored)
    generators_irrep=None,
    eps: float = 1e-8,
    **_ignored,                    # <— eat any other legacy kwargs
):
    """
    Case A : KL_gamma = KL( q_j || Ω^q_{ji} Φ̃_i p_i ) in Q_j.

    Returns covectors (NO projection here):
      g_phi_i_q_cov : (*S, 3)   # for E_q(i) — exactly 0
      g_phi_j_q_cov : (*S, 3)   # for E_q(j)
      g_phi_i_p_cov : (*S, 3)   # for E_p(i)
    """
    import numpy as np
    from core.transport_cache import E_grid
    from core.numerical_utils import sanitize_sigma, safe_inv

    # Frames
    Eqi = np.asarray(E_grid(ctx, agent_i, which="q"), np.float64)  # (*S,Kq,Kq) @ i
    Eqj = np.asarray(E_grid(ctx, agent_j, which="q"), np.float64)  # (*S,Kq,Kq) @ j
    Epi = np.asarray(E_grid(ctx, agent_i, which="p"), np.float64)  # (*S,Kp,Kp) @ i

    # Stats
    mu_j = np.asarray(agent_j.mu_q_field,    np.float64, order="C")
    Sj   = sanitize_sigma(np.asarray(agent_j.sigma_q_field, np.float64), eps=eps)
    mu_p = np.asarray(agent_i.mu_p_field,    np.float64, order="C")
    Sp   = sanitize_sigma(np.asarray(agent_i.sigma_p_field, np.float64), eps=eps)

    # Dual composite: R_dual = Ω_ji Φ̃_i = Eq(j) Ep(i)^T  (Eq(i) cancels)
    Rt = np.swapaxes
    R  = np.einsum("...ik,...jk->...ij", Eqj, Rt(Epi, -1, -2), optimize=True)       # (*S,Kq,Kp)

    # Landing model in Q_j
    mu_Q = np.einsum("...ij,...j->...i", R, mu_p, optimize=True)                    # (*S,Kq)
    S_Q  = np.einsum("...ij,...jk,...lk->...il", R, Sp, R, optimize=True)           # (*S,Kq,Kq)
    S_Q  = sanitize_sigma(S_Q, eps=eps)
    S_Qi = safe_inv(S_Q, eps=max(eps, 1e-12))

    # KL(P||Q) with P=N(mu_j,Sj), Q=N(mu_Q,S_Q):
    # ∂/∂μ_Q = Σ_Q^{-1}(μ_Q-μ_j)
    # ∂/∂Σ_Q = 1/2(-Σ_Q^{-1} Σ_j Σ_Q^{-1} - Σ_Q^{-1} d d^T Σ_Q^{-1} + Σ_Q^{-1})
    d     = (mu_Q - mu_j)
    dmuQ  = np.einsum("...ij,...j->...i", S_Qi, d, optimize=True)
    v     = np.einsum("...ij,...j->...i", S_Qi, d, optimize=True)
    vvT   = np.einsum("...i,...j->...ij", v, v, optimize=True)
    term  = np.einsum("...ij,...jk->...ik", S_Qi,
                      np.einsum("...jk,...kl->...jl", Sj, S_Qi, optimize=True),
                      optimize=True)
    dSQ   = 0.5 * (-term - vvT + S_Qi)
    dSQ   = 0.5 * (dSQ + Rt(dSQ, -1, -2))  # sym

    # ∂KL/∂R = (∂KL/∂μ_Q) μ_p^T + 2(∂KL/∂Σ_Q) R Σ_p
    G_R = np.einsum("...i,...j->...ij", dmuQ, mu_p, optimize=True) \
        + 2.0 * np.einsum("...ij,...jk,...kl->...il", dSQ, R, Sp, optimize=True)   # (*S,Kq,Kp)

    # Split via dR = dEq(j) Ep^T + Eq(j) dEp^T  ⇒
    #   <G_R, dR> = <G_R Ep, dEq(j)> + <G_R^T Eq, dEp>, with G_Eq(i) = 0.
    G_Eqj = np.einsum("...ij,...jk->...ik", G_R, Epi, optimize=True)               # (*S,Kq,Kq)
    G_Epi = np.einsum("...ji,...jk->...ik", Rt(G_R, -1, -2), Eqj, optimize=True)   # (*S,Kp,Kp)
    G_Eqi = np.zeros_like(Eqi, dtype=np.float64)

    # Matrix co-grads → parameter covectors
    g_phi_i_q_cov = matrix_cograd_to_param_covector_irrep(Eqi, G_Eqi, generators_irrep)  # zeros
    g_phi_j_q_cov = matrix_cograd_to_param_covector_irrep(Eqj, G_Eqj, generators_irrep)
    g_phi_i_p_cov = matrix_cograd_to_param_covector_irrep(Epi, G_Epi, generators_irrep)

    return (np.asarray(g_phi_i_q_cov, np.float32, order="C"),
            np.asarray(g_phi_j_q_cov, np.float32, order="C"),
            np.asarray(g_phi_i_p_cov, np.float32, order="C"))



# ---------------- B: KL( p_i  ||  Φ_i[Ω q_j] )  — source in P_i
def grad_gamma_B_mu_sigma_i(ctx, agent_i, agent_j, *, Omega_ij=None, eps: float = 1e-8):
    r"""
    ∂ KL_gamma / ∂(μ_{p_i}, Σ_{p_i}) for **Case B**.

    Definition
    ----------
      KL_gamma := KL( p_i  ||  Φ_i[ Ω^q_{ij} q_j ] ), evaluated in P_i-frame.

    Let
      • (μ_p, Σ_p) := (μ_{p_i}, Σ_{p_i})
      • Ω^q_{ij}: Q_j→Q_i,  Φ_i: Q_i→P_i
      • (μ_L, Σ_L) = Φ_i( Ω^q_{ij}(μ_{q_j}, Σ_{q_j}) )    # landed target in P_i

    Gaussian KL:
      KL = KL( 𝒩(μ_p, Σ_p)  ||  𝒩(μ_L, Σ_L) ).

    Source-form gradients in P_i:
      ∂KL/∂μ_p =  Σ_L^{-1} (μ_p − μ_L)
      ∂KL/∂Σ_p =  ½( Σ_p^{-1} − Σ_L^{-1} )

    Returns
    -------
      gμ_p : (*S, Kp)
      gΣ_p : (*S, Kp, Kp)
    """
   
    # -- p_i stats (sanitize once)
    mu_p = np.asarray(agent_i.mu_p_field,  np.float32, order="C")
    S_p  = sanitize_sigma(np.asarray(agent_i.sigma_p_field, np.float64)).astype(np.float32, copy=False)

    # -- maps
    Om_q  = np.asarray(Omega_ij if Omega_ij is not None else Omega(ctx, agent_i, agent_j, which="q"), np.float32)
    Phi_i = np.asarray(Phi(ctx, agent_i, kind="q_to_p"), np.float32)   # Φ_i: Q→P

    # -- q_j → Q_i (fast precision-push if cached), then Q_i → P_i via Φ_i
    mu_qj_t, S_qj_t, _ = push_neighbor_stats(agent_j, "sigma_q_field", Om_q, eps=eps)
    mu_L, S_L          = push_gaussian(mu_qj_t, S_qj_t, Phi_i, eps=eps)  # landed target in P_i :contentReference[oaicite:2]{index=2}

    # -- source-form KL grads in P_i
    S_L_inv = safe_inv(S_L, eps=max(eps, 1e-12))                        # Σ_L^{-1}         :contentReference[oaicite:3]{index=3}
    S_p_inv = safe_inv(S_p,  eps=max(eps, 1e-12))                        # Σ_p^{-1}

    dmu   = (mu_p - mu_L)
    gmu_p = np.einsum("...ij,...j->...i", S_L_inv, dmu, optimize=True)   # Σ_L^{-1}(μ_p−μ_L)

    gS_p  = 0.5 * (S_p_inv - S_L_inv)
    gS_p  = 0.5 * (gS_p + np.swapaxes(gS_p, -1, -2))                     # symmetrize for safety

    return gmu_p.astype(np.float32, copy=False), gS_p.astype(np.float32, copy=False)




def grad_gamma_B_mu_sigma_j(
    mu_j, Sigma_j,                  # sender q_j stats (...,K), (...,K,K)
    mu_p_i, Sigma_p_i,              # receiver p_i stats (...,K), (...,K,K)  (KL's N0)
    Omega_ij, Phi_i,                # linear maps: Ω_ij (...,K,K), Φ_i (...,K,K)
    *,
    R=None,                         # optional precomputed R = Φ_i @ Ω_ij
    mu_1=None,                      # optional landing mean:  μ_1 = R μ_j
    Sigma_1=None,                   # optional landing cov:   Σ_1 = R Σ_j R^T
    Sigma_1_inv=None,               # optional Σ_1^{-1}
    Sigma_p_inv=None,               # optional Σ_p_i^{-1}
    mask=None,                      # optional boolean mask broadcastable to (...,)
    eps: float = 1e-8,
    assume_sanitized: bool = True,
):
    """
    Sender-side μ/Σ gradients for Case B gating:
        KL_B = KL( p_i || Φ_i[Ω_ij q_j] ).
    Returns (dμ_j, dΣ_j) in the *sender q_j* frame.

    Landing-frame partials for KL(N0||N1) with N0=(μ_p,Σ_p), N1=(μ_1,Σ_1):
        ∂KL/∂μ_1 = - Σ_1^{-1} (μ_p - μ_1)
        ∂KL/∂Σ_1 =  1/2 ( -Σ_1^{-1} + Σ_1^{-1} Σ_p Σ_1^{-1} )

    Chain rule:
        ∂KL/∂μ_j = R^T ∂KL/∂μ_1
        ∂KL/∂Σ_j = R^T (∂KL/∂Σ_1) R
    """
    # ---- cast to f32 for suite consistency ----
    mu_j      = np.asarray(mu_j,      np.float32, order="C")
    Sigma_j   = np.asarray(Sigma_j,   np.float32, order="C")
    mu_p_i    = np.asarray(mu_p_i,    np.float32, order="C")
    Sigma_p_i = np.asarray(Sigma_p_i, np.float32, order="C")
    Phi_i     = np.asarray(Phi_i,     np.float32, order="C")
    Omega_ij  = np.asarray(Omega_ij,  np.float32, order="C")

    # ---- R = Φ_i Ω_ij ----
    if R is None:
        R = np.einsum("...ik,...kj->...ij", Phi_i, Omega_ij, optimize=True)  # (...,K,K)
    Rt = np.swapaxes(R, -1, -2)

    # ---- landing stats (μ_1, Σ_1) ----
    if mu_1 is None:
        mu_1 = np.einsum("...ij,...j->...i", R, mu_j, optimize=True)         # (...,K)
    if Sigma_1 is None and Sigma_1_inv is None:
        Sigma_1 = np.einsum("...ik,...kl,...jl->...ij", R, Sigma_j, R, optimize=True)

    # ---- inverses with sanitation (once) ----
    if Sigma_p_inv is None:
        Sp = Sigma_p_i if assume_sanitized else sanitize_sigma(Sigma_p_i, eps=eps)
        Sigma_p_inv = safe_inv(Sp)                                           # (...,K,K)

    if Sigma_1_inv is None:
        S1 = Sigma_1 if assume_sanitized else sanitize_sigma(Sigma_1, eps=eps)
        Sigma_1_inv = safe_inv(S1)                                           # (...,K,K)

    # ---- landing-frame KL partials (N0 = p_i, N1 = landing) ----
    # ∂μ_1 = - Σ_1^{-1} (μ_p - μ_1)
    dmu_1 = -np.einsum("...ij,...j->...i", Sigma_1_inv, (mu_p_i - mu_1), optimize=True)

    # ∂Σ_1 = 1/2 ( -Σ_1^{-1} + Σ_1^{-1} Σ_p Σ_1^{-1} )
    dS_1  = -Sigma_1_inv
    dS_1 += np.einsum("...ij,...jk,...kl->...il", Sigma_1_inv, Sigma_p_i, Sigma_1_inv, optimize=True)
    dS_1 *= 0.5
    dS_1  = 0.5 * (dS_1 + np.swapaxes(dS_1, -1, -2))                          # symmetrize

    # ---- map back to sender frame ----
    dmu_j = np.einsum("...ij,...j->...i", Rt, dmu_1, optimize=True)           # (...,K)
    dS_j  = np.einsum("...ik,...kl,...jl->...ij", Rt, dS_1, R, optimize=True) # (...,K,K)
    dS_j  = 0.5 * (dS_j + np.swapaxes(dS_j, -1, -2))                          # symmetrize

    # ---- optional masking ----
    if mask is not None:
        m = (np.asarray(mask) > 0).astype(np.float32, copy=False)
        dmu_j = dmu_j * m[..., None]
        dS_j  = dS_j  * m[..., None, None]

    return dmu_j.astype(np.float32, copy=False), dS_j.astype(np.float32, copy=False)


def grad_gamma_B_phi_covectors(
    ctx, agent_i, agent_j,
    *,
    Omega_ij=None,                # kept for backward-compat; unused
    generators_irrep=None,        # (3,K,K) for active irrep
    eps: float = 1e-8,
    **_ignored,
):
    """
    Case B (P_i frame):
        KL_gamma = KL( p_i || Φ_i[Ω^q_ij q_j] )

    Returns covectors (NO projection here):
      g_phi_i_q_cov : (*S, 3)   # for E_q(i) — exactly 0 (R = E_p(i) E_q(j)^T)
      g_phi_j_q_cov : (*S, 3)   # for E_q(j)
      g_phi_i_p_cov : (*S, 3)   # for E_p(i)
    """
    

    # --- frames (float64) ---
    Eqi = np.asarray(E_grid(ctx, agent_i, which="q"), np.float64)   # (*S,Kq,Kq) @ i
    Eqj = np.asarray(E_grid(ctx, agent_j, which="q"), np.float64)   # (*S,Kq,Kq) @ j
    Epi = np.asarray(E_grid(ctx, agent_i, which="p"), np.float64)   # (*S,Kp,Kp) @ i

    # Optional hygiene: enforce exact orthogonality to kill drift jitter
    # (uncomment if you still see noise)
    # def _orth(X):
    #     # project to nearest O(K): X = USV^T -> U V^T (per voxel)
    #     U, _, Vt = np.linalg.svd(X, full_matrices=False)
    #     return np.einsum("...ik,...kj->...ij", U, Vt, optimize=True)
    # Eqj = _orth(Eqj); Epi = _orth(Epi)

    # --- stats (float64) ---
    mu_p = np.asarray(agent_i.mu_p_field,    np.float64, order="C")
    Sp   = sanitize_sigma(np.asarray(agent_i.sigma_p_field, np.float64), eps=eps)
    mu_j = np.asarray(agent_j.mu_q_field,    np.float64, order="C")
    Sj   = sanitize_sigma(np.asarray(agent_j.sigma_q_field, np.float64), eps=eps)

    # -------------------------------------------------------------------------
    # Exact factorization for Case B:
    # Φ_i = E_p(i) E_q(i)^T,  Ω_ij = E_q(i) E_q(j)^T  ⇒  R = Φ_i Ω_ij = E_p(i) E_q(j)^T
    # Landing in P_i:  μ_L = R μ_j,  Σ_L = R Σ_j R^T
    # KL: KL( N(μ_p,Σ_p) || N(μ_L,Σ_L) )
    # Target-form partials:
    #   v = Σ_L^{-1}(μ_p - μ_L)
    #   ∂KL/∂μ_L = -v
    #   ∂KL/∂Σ_L = 1/2( -Σ_L^{-1} Σ_p Σ_L^{-1} - v v^T + Σ_L^{-1} )
    # Chain rule:
    #   ∂KL/∂R = (∂KL/∂μ_L) μ_j^T + 2 (∂KL/∂Σ_L) R Σ_j
    # Split:
    #   dR = dE_p E_q(j)^T + E_p dE_q(j)^T  ⇒
    #   <G_R, dR> = <G_R E_q(j), dE_p> + <G_R^T E_p, dE_q(j)> ;  G_Eq(i) = 0 exactly.
    # -------------------------------------------------------------------------

    Rt = np.swapaxes
    R  = np.einsum("...ik,...jk->...ij", Epi, Rt(Eqj, -1, -2), optimize=True)        # (*S,Kp,Kq)

    # ---- (1) Build Σ_L carefully; avoid the common index flip ----
    # Safer 2-step version avoids accidental "...lk" vs "...kl" swaps
    RS   = np.einsum("...ij,...jk->...ik", R, Sj, optimize=True)                     # (*,Kp,Kq)
    S_L  = np.einsum("...ik,...jk->...ij", RS, R, optimize=True)                     # (*,Kp,Kp)  (R Σ_j R^T)
    S_L  = 0.5 * (S_L + Rt(S_L, -1, -2))
    S_L  = sanitize_sigma(S_L, eps=eps)
    S_L_inv = safe_inv(S_L, eps=max(eps, 1e-12))

    # ---- (2) Target-form partials ----
    mu_L = np.einsum("...ij,...j->...i", R, mu_j, optimize=True)
    delta = (mu_p - mu_L)
    v     = np.einsum("...ij,...j->...i", S_L_inv, delta, optimize=True)
    dmuL  = -v

    vvT   = np.einsum("...i,...j->...ij", v, v, optimize=True)
    t0    = -np.einsum("...ij,...jk,...kl->...il", S_L_inv, Sp, S_L_inv, optimize=True)
    dSL   = 0.5 * (t0 - vvT + S_L_inv)
    dSL   = 0.5 * (dSL + Rt(dSL, -1, -2))

    # ---- (3) ∂KL/∂R ----
    G_R = np.einsum("...i,...j->...ij", dmuL, mu_j, optimize=True) \
        + 2.0 * np.einsum("...ij,...jk,...kl->...il", dSL, R, Sj, optimize=True)    # (*,Kp,Kq)

    # ---- (4) Split to site-frame matrix co-grads (index-safe) ----
    # G_Ep = G_R E_q(j)     (Kp,Kp)
    # G_Eqj = (G_R^T) E_p   (Kq,Kq)
    G_Epi = np.einsum("...ij,...jk->...ik", G_R, Eqj, optimize=True)                 # (*,Kp,Kp)
    G_Eqj = np.einsum("...ji,...jk->...ik", Rt(G_R, -1, -2), Epi, optimize=True)     # (*,Kq,Kq)
    G_Eqi = np.zeros_like(Eqi, dtype=np.float64)                                     # exact 0

    # ---- (5) Matrix co-grads → param covectors ----
    g_phi_i_q_cov = matrix_cograd_to_param_covector_irrep(Eqi, G_Eqi, generators_irrep)  # zeros
    g_phi_j_q_cov = matrix_cograd_to_param_covector_irrep(Eqj, G_Eqj, generators_irrep)
    g_phi_i_p_cov = matrix_cograd_to_param_covector_irrep(Epi, G_Epi, generators_irrep)

    return (np.asarray(g_phi_i_q_cov, np.float32, order="C"),
            np.asarray(g_phi_j_q_cov, np.float32, order="C"),
            np.asarray(g_phi_i_p_cov, np.float32, order="C"))




def matrix_cograd_to_param_covector_irrep(E, G_E, generators_irrep=None):
    """
    Map a matrix co-gradient G_E (same rep as E) to a parameter-space covector (*S,3).

    If generators_irrep is provided (shape (3,K,K)), use the general irrep path:
        α_a = tr( E^T G_E  · G_a^T )
    Otherwise, if K==3, use the adjoint fast-path (no generators required).

    Args:
      E:    (*S, K, K)  frame in some SO(3) rep
      G_E:  (*S, K, K)  matrix co-gradient w.r.t. E
      generators_irrep: optional (3,K,K)

    Returns:
      covector: (*S, 3)  in parameter coordinates (right-trivialized)
    """
    Rt = np.swapaxes
   
    # General irrep path when generators are given
    if generators_irrep is not None:
        H = np.einsum("...ij,...jk->...ik", Rt(E, -1, -2), G_E, optimize=True)  # H = E^T G_E
        # α_a = tr(H G_a^T)
        cov = np.stack(
            [np.einsum("...ij,ij->...", H, generators_irrep[a], optimize=True) for a in range(3)],
            axis=-1
        )
        return cov.astype(np.float32, copy=False)

    raise ValueError(
        "matrix_cograd_to_param_covector_irrep: either provide generators_irrep "
        "or ensure K==3 for the adjoint fast-path."
    )
















