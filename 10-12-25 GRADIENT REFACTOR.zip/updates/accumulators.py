# -*- coding: utf-8 -*-
"""
Created on Sun Oct 12 14:30:23 2025

@author: chris and christine
"""

# accumulators.py
from __future__ import annotations
from dataclasses import dataclass, field
import numpy as np

@dataclass
class GradBuckets:
    dmu:  np.ndarray
    dS:   np.ndarray
    dphi: np.ndarray | None = None
    notes: dict = field(default_factory=dict)

    def add_(self, other: "GradBuckets") -> "GradBuckets":
        self.dmu += other.dmu
        self.dS  += other.dS
        if self.dphi is not None or other.dphi is not None:
            a = self.dphi if self.dphi is not None else 0.0
            b = other.dphi if other.dphi is not None else 0.0
            self.dphi = a + b
        self.notes.update(other.notes)
        return self

    @staticmethod
    def zeros_like_agent(agent, *, which: str):
        mu_key = "mu_q_field" if which == "q" else "mu_p_field"
        S_key  = "sigma_q_field" if which == "q" else "sigma_p_field"
        mu = np.asarray(getattr(agent, mu_key), np.float32)
        S  = np.asarray(getattr(agent, S_key),  np.float32)
        return GradBuckets(np.zeros_like(mu), np.zeros_like(S), None, {})
