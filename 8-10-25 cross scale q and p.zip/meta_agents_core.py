# -*- coding: utf-8 -*-
"""
Created on Sun Aug 10 15:26:43 2025

@author: chris and christine
"""

