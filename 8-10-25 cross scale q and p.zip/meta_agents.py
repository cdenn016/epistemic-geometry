# ────────────────────────
# Core + standard libraries
# ────────────────────────
import itertools as it
import json
from pathlib import Path
from copy import deepcopy
import os
# ────────────────────────
# Scientific libraries
# ────────────────────────
import numpy as np
import matplotlib.pyplot as plt
from matplotlib import cm
import networkx as nx
import argparse
from pathlib import Path
import json, math
# ────────────────────────
# Project configuration
# ────────────────────────
import config
from config import checkpoint_dir, group_name, K_q, K_p, log_eps, overlap_eps
from generalized_simulation import run_simulation
# ────────────────────────
# IO + data handling
# ────────────────────────
from generalized_io_utils import (
    load_final_step,
    load_agents,
    save_generic_alignment_data,
    save_meta_agents,
    load_meta_agents,
    save_meta_labels,
    load_meta_data,
)


from meta_agent_utils import ( _shape_or_none, _as_float_or_nan, _as_int_or_none,
                              save_meta_agent_summary, _weighted_mean_field, _prepare_generators,
                              _to_py_list_int, condensation_score, get_intra_inter, wire_child_parent_links )

# ────────────────────────
# Core modules
# ────────────────────────
from get_generators import get_generators
from generalized_agent_schema import Agent


# ────────────────────────
# Meta-agent diagnostics
# ────────────────────────
from meta_agent_utils import (
    procrustes_seed_lambda_dn_q,
    build_runtime_params_for_xscale,
    compute_symmetric_kl_matrix,
    overlap_area_matrix,
    curvature_mean_per_agent,
    rank_agent_alignment,
    aggregate_fields,
    aggregate_mask,
    _ensure_parent_slots, 
    _kl_plateau
    
)
from meta_agent_plots import (
    plot_cluster_size_hist,
    plot_child_parent_overlay,
    
    plot_crossscale_kl_hist,
)
from generalized_diagnostics_metrics import compute_pairwise_kl_belief, compute_pairwise_kl_model
from meta_agent_plots import (
    plot_matrix,
    plot_generic_alignment_network,
    plot_intra_kl_distribution,
    plot_inter_vs_intra,
    plot_cluster_order_parameters,
    plot_spatial_cluster_map,
    plot_curvature_heatmap,
)

from meta_agent_utils import (
    compute_avg_crossscale_kl_q,
    compute_cluster_kl_stats,
    compute_order_parameter,
    compute_cluster_order_parameters,
)

from update_crossscale_terms import xscale_q_up_step
from agent_initialization import attach_crossscale_fields  




def _evaluate_prefix(agents, align_dir: Path, prefix: str, curvature_generators, outdir_root: Path):
    kl_matrix, labels, rankings = load_meta_data(str(align_dir), prefix)
    if len(labels) != len(agents):
        print(f"[ERROR] Label count {len(labels)} != agent count {len(agents)}")
        return None

    print(f"[INFO] Cluster label histogram: {np.bincount(labels[labels >= 0])}")
    stats = compute_cluster_kl_stats(kl_matrix, labels)
    if not stats:
        print(f"[!] No clusters detected for {prefix}; skipping.")
        return None

    R_global, sigma_global = compute_order_parameter(kl_matrix)

    outdir = outdir_root / prefix
    outdir.mkdir(parents=True, exist_ok=True)
    plot_intra_kl_distribution(stats, outpath=outdir / "intra_kl.png")
    plot_inter_vs_intra(stats, outpath=outdir / "inter_vs_intra.png")
    cluster_R = compute_cluster_order_parameters(kl_matrix, labels)
    plot_cluster_order_parameters(cluster_R, outpath=outdir / "cluster_order_params.png")
    plot_spatial_cluster_map(agents, labels, outpath=outdir / "spatial_clusters.png")
    plot_curvature_heatmap(agents, labels, curvature_generators, outpath=outdir / "curvature_heatmap.png")

    score = condensation_score(stats, R_global, sigma_global, kl_matrix=kl_matrix, labels=labels)
    print(f"[INFO] {prefix} condensation score = {score:.4f}")

    return {"prefix": prefix, "score": float(score), "labels": labels, "kl_matrix": kl_matrix}


def _choose_best_clustering(agents, Gq, Gp, basedir: Path):
    specs = {
        "kl":       (basedir / "belief_alignment_output", Gq),
        "kl_model": (basedir / "model_alignment_output",  Gp),
    }
    best = {"prefix": None, "score": -math.inf, "labels": None, "kl_matrix": None}
    for prefix, (adir, curv_G) in specs.items():
        print(f"\n[INFO] Evaluating '{prefix}' clusters @ {adir}")
        res = _evaluate_prefix(agents, adir, prefix, curv_G, outdir_root=basedir / "condensation_output")
        if res and res["score"] > best["score"]:
            best = res
    if best["prefix"] is None:
        raise RuntimeError("No valid clustering found to build meta-agents.")
    print(f"\n[INFO] Selected clustering: {best['prefix']} (score={best['score']:.4f})")
    return best


def _seed_or_revert_procrustes(meta_agents, agents, labels, eps=1e-6, worsen_factor=2.0):
    """Seed Λ_dn_q via Procrustes, measure KL before/after, and revert if it worsens.
       Always returns a dict: {"base_mean": float|nan, "seed_mean": float|nan, "reverted": bool, "error": str|None}
    """
    def _safe_mean(x):
        try:
            x = np.asarray(x)
            if x.size == 0: return float("nan")
            m = float(np.nanmean(x))
            return m
        except Exception:
            return float("nan")

    info = {"base_mean": float("nan"), "seed_mean": float("nan"), "reverted": False, "error": None}

    # baseline
    try:
        vals_base = compute_avg_crossscale_kl_q(agents, meta_agents, labels, eps=eps)
        info["base_mean"] = _safe_mean(vals_base)
    except Exception as e:
        print(f"[XSCALE] base KL eval failed: {e}")
        info["error"] = f"base_eval: {e}"

    # seed
    try:
        procrustes_seed_lambda_dn_q(meta_agents, agents, labels)
    except Exception as e:
        print(f"[XSCALE] Procrustes seed failed: {e}")
        info["error"] = f"seed: {e}"

    # after
    try:
        vals_seed = compute_avg_crossscale_kl_q(agents, meta_agents, labels, eps=eps)
        info["seed_mean"] = _safe_mean(vals_seed)
    except Exception as e:
        print(f"[XSCALE] post-seed KL eval failed: {e}")
        info["error"] = f"post_eval: {e}"

    print(f"[XSCALE] KL base {info['base_mean']:.4f} → after seed {info['seed_mean']:.4f}")

    # revert if worse by factor or NaN
    try:
        worse = (not np.isfinite(info["seed_mean"])) or (
            np.isfinite(info["base_mean"]) and info["seed_mean"] > worsen_factor * info["base_mean"]
        )
        if worse:
            Kq = meta_agents[0].mu_q_field.shape[-1]
            for P in meta_agents:
                P.Lambda_dn_q = np.eye(Kq, dtype=P.mu_q_field.dtype)
                P.Lambda_up_q = np.eye(Kq, dtype=P.mu_q_field.dtype)
            print("[XSCALE] Procrustes seed increased KL — reverted to identity.")
            info["reverted"] = True
    except Exception as e:
        print(f"[XSCALE] revert failed: {e}")
        info["error"] = (info["error"] + f"; revert: {e}") if info["error"] else f"revert: {e}"

    return info


def _coarse_grain_gauge_fields(meta_agents, agents):
    for P in meta_agents:
        coarsen_phi_from_children(P, agents, field="phi",       weight_mode="mask")
        coarsen_phi_from_children(P, agents, field="phi_model", weight_mode="mask")


def _field_norm(a, m=None):
    v = np.linalg.norm(a, axis=-1) if a.ndim == 3 else np.linalg.norm(a, axis=(-1, -2))
    if m is not None:
        v = v[m > 1e-6]
    return float(np.nanmean(v)) if v.size else float("nan")



def _run_child_with_steps(params, steps: int|None, outdir: str):
    # lightweight steps override without touching your run loop internals
    old_steps = config.steps
    if steps is not None:
        config.steps = int(steps)
    try:
        agents_after, metric_log = run_simulation(outdir=outdir, params=params)
    finally:
        config.steps = old_steps
    return agents_after, metric_log




# ---------- public API ----------

def run_meta_recursion(
    levels=2,
    base_ckpt="checkpoints",
    steps_per_level: list[int] | tuple[int, ...] | None = None,
    log_eps=1e-6,
    overlap_eps=1e-6,
    plateau_window=15,
    plateau_tol=1e-3,
    out_root="meta_agent_analysis",
):
    """
    Build parents from a checkpoint, run child simulation with XSCALE,
    then repeat for multiple levels until plateau or `levels` exhausted.

    Returns: dict manifest with per-level summaries and output dirs.
    """
    out_root = Path(out_root)
    out_root.mkdir(parents=True, exist_ok=True)

    manifest = {"base_ckpt": base_ckpt, "levels": []}
    prev_plateau_mean = None

    for L in range(levels):
        print(f"\n========== META-RECURSION: LEVEL {L} ==========")
        level_dir = out_root / f"L{L}"
        level_dir.mkdir(parents=True, exist_ok=True)

        # 1) load agents + generators for this level
        ckpt = base_ckpt if L == 0 else f"{base_ckpt}_L{L}"
        agents = load_final_step(ckpt)
        if agents is None:
            raise FileNotFoundError(f"No step_XXXX.pkl found in {ckpt}/")
        Gq, Gp, generators = _prepare_generators()

        # 2) run alignment analyses and pick best clustering
        _run_alignment_suite(agents, generators, level_dir, log_eps, overlap_eps)
        best = _choose_best_clustering(agents, Gq, Gp, basedir=level_dir)

        # 3) build parents, wire links, coarse-grain gauge, seed Λ (with revert)
        chosen_G = Gq if best["prefix"] == "kl" else Gp
        parents = build_meta_agents_from_clusters(agents, best["labels"], chosen_G)
        _ensure_parent_slots(parents, Kq=config.K_q, Kp=config.K_p)  # explicit to avoid old signature issues
        wire_child_parent_links(agents, parents, best["labels"])
        _coarse_grain_gauge_fields(parents, agents)
        _post_build_summaries(parents)
        seed_info = _seed_or_revert_procrustes(parents, agents, best["labels"]) or {}

        # 4) persist meta artifacts
        save_meta_agents(parents, output_dir=str(level_dir / "meta_agent_fields"))
        save_meta_labels(best["labels"], path=str(level_dir / "meta_labels.csv"))

        # 5) run child simulation with XSCALE context
        runtime_params = build_runtime_params_for_xscale(Gq, Gp, parents, best["labels"])
        outdir = f"{base_ckpt}_L{L+1}"
        steps = None
        if steps_per_level is not None:
            steps = steps_per_level[L] if L < len(steps_per_level) else steps_per_level[-1]
        _, metric_log = _run_child_with_steps(runtime_params, steps=steps, outdir=outdir)

        # 6) plateau check on cross-scale KL (guard for empty/missing metrics)
        if not metric_log:
            print("[XSCALE] No metrics recorded for this level; skipping plateau check.")
            hit_plateau, plateau_mean = False, float("nan")
        else:
            hit_plateau, plateau_mean = _kl_plateau(metric_log, window=plateau_window, tol=plateau_tol)

        # 7) quick plots for this level (best-effort; don't crash recursion if a plot fails)
        plots_dir = level_dir / "agent_plots"
        plots_dir.mkdir(exist_ok=True)
        try:
            plot_cluster_size_hist(best["labels"], outpath=plots_dir / "cluster_sizes.png")
            plot_child_parent_overlay(agents, parents, best["labels"],
                                      outpath=plots_dir / "child_parent_overlay.png",
                                      max_examples=12)
            vals = compute_avg_crossscale_kl_q(agents, parents, best["labels"], eps=1e-6)
            plot_crossscale_kl_hist(vals, outpath=plots_dir / "crossscale_kl_q_hist.png")
        except Exception as e:
            print(f"[PLOTS] Skipped one or more plots: {e}")

        # 8) record level summary (use .get to be robust)
        level_summary = {
            "level": L,
            "in_ckpt": ckpt,
            "out_ckpt": outdir,
            "best_prefix": best["prefix"],
            "best_score": float(best["score"]),
            "seed_base_mean": float(seed_info.get("base_mean", float("nan"))),
            "seed_after_mean": float(seed_info.get("seed_mean", float("nan"))),
            "seed_reverted": bool(seed_info.get("reverted", False)),
            "seed_error": seed_info.get("error"),
            "plateau_mean": float(plateau_mean) if np.isfinite(plateau_mean) else None,
            "hit_plateau": bool(hit_plateau),
        }
        manifest["levels"].append(level_summary)

        # save running manifest
        with open(out_root / "recursion_manifest.json", "w") as f:
            json.dump(manifest, f, indent=2)

        # 9) stopping rule
        if hit_plateau:
            print(f"[STOP] Plateau at level {L+1} (Δ<{plateau_tol}).")
            break
        prev_plateau_mean = plateau_mean

    print("\n[✓] Meta-recursion complete.")
    return manifest



def run_generic_alignment_analysis(
    agents,
    generators: dict,
    params: dict,
    mode: str = "belief",
    outdir: Path = None
):
    """
    Compute, cluster, plot, and save alignment diagnostics for either belief or model fields.

    Parameters
    ----------
    agents : list
        List of Agent objects.
    generators : dict
        Dict of Lie algebra generators: {"q": (d,K_q,K_q), "p": (d,K_p,K_p)}.
    params : dict
        Runtime parameters; expects 'log_eps', 'overlap_eps', etc.
    mode : str
        Either 'belief' or 'model' – determines which alignment metric to compute.
    outdir : Path, optional
        Directory to save results. Defaults to './alignment_output' or './model_alignment_output'.
    """
    assert mode in ("belief", "model"), f"[run_generic_alignment_analysis] Invalid mode: {mode}"
    outdir = Path(outdir) if outdir else Path("alignment_output" if mode == "belief" else "model_alignment_output")
    outdir.mkdir(parents=True, exist_ok=True)

    if mode == "belief":
        compute_kl = compute_pairwise_kl_belief
        generators_used = generators["q"]
        prefix = "kl"
        title = "Epistemic Alignment Network"
        matrix_title = "Pairwise Epistemic Misalignment"
    else:
        compute_kl = compute_pairwise_kl_model
        generators_used = generators["p"]
        prefix = "kl_model"
        title = "Model Alignment Network"
        matrix_title = "Pairwise Model Misalignment"

    # Step 1: KL divergence matrix
    kl_matrix = compute_kl(agents, generators_used, params)
    sym_kl = compute_symmetric_kl_matrix(kl_matrix)
    sym_kl = np.clip(sym_kl, 0.0, None)

    # Step 2: Auxiliary metrics
    overlap_A = overlap_area_matrix(agents, params.get("overlap_eps", 0.0))
    curv_mean = curvature_mean_per_agent(agents, generators_used)

    # Step 3: Meta-agent detection
    rankings = rank_agent_alignment(sym_kl)
    meta_list, labels, eps = find_meta_agents(sym_kl, overlap_A, curv_mean)
    print(f"[INFO] mode={mode}: adaptive ε = {eps:.3f}, meta_agents = {len(meta_list)}")

    # Step 4: Visualize KL matrix and network
    plot_matrix(sym_kl, outdir=outdir, label=f"D_KL({mode})", title=matrix_title, fname="kl_matrix.png")

    plot_generic_alignment_network(
        sym_kl, labels,
        threshold=eps,
        outpath=outdir / "alignment_network.png",
        title=f"{title} (ε={eps:.3f})"
    )

    # Step 5: Save alignment data
    save_generic_alignment_data(
        kl_matrix=sym_kl,
        rankings=rankings,
        labels=labels,
        outdir=outdir,
        prefix=prefix
    )

    print(f"[✓] {mode.capitalize()} alignment analysis completed → {outdir}/")


def find_meta_agents(
    sym_kl: np.ndarray,
    overlap_area: np.ndarray,
    curv_mean: np.ndarray,
    tau_A: float = 10,
    eta:   float = 10,
    tau_C: float = 10,
    verbose: bool = False
):
    """
    Identify meta-agent clusters satisfying:
      A) mean intra-cluster KL < tau_A
      B) intra < eta × extra-cluster KL
      C) mean curvature < tau_C

    Returns:
        meta:   list of index lists (clusters)
        labels: np.ndarray of cluster labels per agent
        eps:    threshold used to form clusters (30% quantile)
    """
    N = sym_kl.shape[0]
    finite = sym_kl[np.isfinite(sym_kl)]

    # 1) Compute adaptive connectivity threshold
    eps = np.quantile(finite, 0.30)
    min_eps = getattr(config, "epsilon_model", 1e-6)
    if eps < min_eps:
        eps = min_eps

    # 2) Build KL-based graph
    G = nx.Graph()
    G.add_nodes_from(range(N))
    for i, j in it.combinations(range(N), 2):
        d = sym_kl[i, j]
        if np.isfinite(d) and d <= eps:
            G.add_edge(i, j, weight=d)

    # 3) Extract connected components satisfying alignment + curvature
    meta = []
    for comp in nx.connected_components(G):
        C = list(comp)
        if len(C) < 2:
            continue

        C_set = set(C)
        out_set = set(range(N)) - C_set
        intra_vals = sym_kl[np.ix_(C, C)]
        intra_vals = intra_vals[np.isfinite(intra_vals)]
        intra_mean = float(intra_vals.mean()) if intra_vals.size > 0 else np.inf

        curv_meanC = float(curv_mean[np.array(C)].mean())

        extra_vals = sym_kl[np.ix_(C, list(out_set))]
        extra_vals = extra_vals[np.isfinite(extra_vals)]
        extra_mean = float(extra_vals.mean()) if extra_vals.size > 0 else np.inf

        accept = False
        if extra_vals.size == 0:
            if intra_mean < tau_A and curv_meanC < tau_C:
                accept = True
        else:
            if (intra_mean < tau_A and
                intra_mean < eta * extra_mean and
                curv_meanC < tau_C):
                accept = True

        if accept:
            meta.append(C)
            if verbose:
                print(f"[meta-cluster] size={len(C)}, "
                      f"<KL_intra>={intra_mean:.3f}, "
                      f"<KL_extra>={extra_mean:.3f}, "
                      f"<curv>={curv_meanC:.3f}")

    # 4) Assign labels to agents
    labels = np.full(N, -1, dtype=int)
    for k, C in enumerate(meta):
        labels[np.array(C)] = k

    return meta, labels, eps


def build_meta_agents_from_clusters(agents, labels, generators, verbose=True):
    """
    Build coarse-grained meta-agents (as Agent objects) using IG fields.
    Neighbors are inferred from original agent overlaps.

    Args:
        agents     : list of Agent objects
        labels     : np.ndarray of cluster labels
        generators : Lie algebra generators
        verbose    : whether to print cluster sizes

    Returns:
        List of new Agent objects, one per cluster.
    """
    

    def get_meta_agent_adjacency(agents, labels, eps=1e-3):
        labels = np.asarray(labels)
        unique = sorted(set(labels[labels >= 0]))

        label_map = {lab: i for i, lab in enumerate(unique)}

        n_meta = len(label_map)
        adj = np.zeros((n_meta, n_meta), dtype=bool)

        for i, ag_i in enumerate(agents):
            lab_i = labels[i]
            if lab_i < 0: continue
            for j, ag_j in enumerate(agents):
                lab_j = labels[j]
                if lab_j < 0 or lab_i == lab_j: continue
                if np.any(ag_i.mask * ag_j.mask > eps):
                    a = label_map[lab_i]
                    b = label_map[lab_j]
                    adj[a, b] = adj[b, a] = True

        return adj, label_map

    meta_agents = []
    unique_labels = sorted(set(labels))
    H, W, K = agents[0].mu_q_field.shape
    d = agents[0].phi.shape[-1]
    fiber_basis = np.eye(K)


    for lab in unique_labels:
        if lab < 0:
            continue
        idxs = np.where(labels == lab)[0]
        if len(idxs) == 0:
            continue

        sub = [agents[i] for i in idxs]

        mask = aggregate_mask(sub)
        mu_q = aggregate_fields(sub, "mu_q_field")
        mu_p = aggregate_fields(sub, "mu_p_field")
        sigma_q = aggregate_fields(sub, "sigma_q_field")
        sigma_p = aggregate_fields(sub, "sigma_p_field")
        phi = aggregate_fields(sub, "phi")
        phi_model = aggregate_fields(sub, "phi_model")

        sigma_q = 0.5 * (sigma_q + sigma_q.transpose(0, 1, 3, 2))
        sigma_p = 0.5 * (sigma_p + sigma_p.transpose(0, 1, 3, 2))

        inds = np.argwhere(mask > 0.5)
        center = tuple(np.round(np.mean(inds, axis=0)).astype(int)) if len(inds) else (H // 2, W // 2)

        A = Agent(
            id            = int(lab),
            mask          = mask,
            mu_q_field    = mu_q,
            sigma_q_field = sigma_q,
            mu_p_field    = mu_p,
            sigma_p_field = sigma_p,
            phi           = phi,
            phi_model     = phi_model,
            center        = center,
            radius        = np.sqrt(np.sum(mask)),
            neighbors     = [],  # set below
        )
        meta_agents.append(A)

        if verbose:
            print(f"[meta-agent {lab}] from {len(sub)} agents, center={center}, radius={A.radius:.2f}")

    # ── Assign neighbors using adjacency matrix ──
    adj, label_map = get_meta_agent_adjacency(agents, labels)
    for i, A in enumerate(meta_agents):
        A.neighbors = [meta_agents[j].id for j in range(len(meta_agents)) if adj[i, j]]

    return meta_agents







def coarsen_phi_from_children(parent, children, field="phi", weight_mode="mask", max_norm=np.pi, eps=1e-6):
    """
    Build parent.{phi or phi_model} by weighted average of children fields.
    - field: "phi" or "phi_model"
    - weight_mode: "mask" (default), or "mask*overlap", or a callable(child)->(H,W,1)
    """
    if not getattr(parent, "child_ids", None):
        return  # nothing to do
    C = len(parent.child_ids)

    # gather child fields
    phi_stack = []
    w_stack   = []
    for cid in parent.child_ids:
        ch = children[cid]
        phi_c = getattr(ch, field)                 # (H, W, 3)
        phi_stack.append(phi_c[..., :3][None, ...])  # ensure shape (1,H,W,3)

        if callable(weight_mode):
            w = weight_mode(ch)  # (H,W,1)
        else:
            if weight_mode == "mask":
                w = ch.mask[..., None]
            elif weight_mode == "mask*overlap":
                w = (ch.mask * parent.mask)[..., None]
            else:
                w = ch.mask[..., None]
        w_stack.append(w[None, ...])

    phi_stack = np.concatenate(phi_stack, axis=0)  # (C,H,W,3)
    w_stack   = np.concatenate(w_stack,   axis=0)  # (C,H,W,1)

    # algebra-space weighted average
    phi_parent = _weighted_mean_field(phi_stack, w_stack, eps=eps)  # (H,W,3)

    # clip to stay in safe radius & sanitize
    # (same style as your existing soft clip; fallback to simple norm clip)
    norms = np.linalg.norm(phi_parent, axis=-1, keepdims=True) + 1e-12
    scale = np.minimum(1.0, max_norm / norms)
    phi_parent = phi_parent * scale

    setattr(parent, field, phi_parent.astype(children[0].mu_q_field.dtype))



def _run_alignment_suite(agents, generators, basedir, log_eps, overlap_eps):
    params = {"log_eps": log_eps, "overlap_eps": overlap_eps}
    for mode in ("belief", "model"):
        outdir = basedir / f"{mode}_alignment_output"
        outdir.mkdir(exist_ok=True, parents=True)
        print(f"\n[INFO] Running alignment analysis for mode: {mode}")
        run_generic_alignment_analysis(agents, generators, params, mode, outdir=outdir)


def _evaluate_one_prefix(agents, align_dir, prefix, curvature_generators, outdir_root):
    kl_matrix, labels, rankings = load_meta_data(str(align_dir), prefix)
    if len(labels) != len(agents):
        print(f"[ERROR] Label count {len(labels)} != agent count {len(agents)}")
        return None

    print(f"[INFO] Cluster label histogram: {np.bincount(labels[labels >= 0])}")
    stats = compute_cluster_kl_stats(kl_matrix, labels)
    if not stats:
        print(f"[!] No clusters detected for {prefix}; skipping.")
        return None

    R_global, sigma_global = compute_order_parameter(kl_matrix)

    outdir = outdir_root / prefix
    outdir.mkdir(exist_ok=True, parents=True)
    plot_intra_kl_distribution(stats, outpath=outdir / "intra_kl.png")
    plot_inter_vs_intra(stats, outpath=outdir / "inter_vs_intra.png")
    cluster_R = compute_cluster_order_parameters(kl_matrix, labels)
    plot_cluster_order_parameters(cluster_R, outpath=outdir / "cluster_order_params.png")
    plot_spatial_cluster_map(agents, labels, outpath=outdir / "spatial_clusters.png")
    plot_curvature_heatmap(agents, labels, curvature_generators, outpath=outdir / "curvature_heatmap.png")

    score = condensation_score(stats, R_global, sigma_global, kl_matrix=kl_matrix, labels=labels)
    print(f"[INFO] {prefix} condensation score = {score:.4f}")

    return {"prefix": prefix, "score": score, "labels": labels, "kl_matrix": kl_matrix}





def _post_build_summaries(meta_agents):
    for P in meta_agents:
        n_phi = _field_norm(P.phi, P.mask)
        n_phim = _field_norm(P.phi_model, P.mask)
        print(f"[META] parent {P.id}: ⟨‖φ‖⟩={n_phi:.4f}  ⟨‖φ̃‖⟩={n_phim:.4f}")


def main_once(checkpoint_dir="checkpoints",
              basedir="meta_agent_analysis",
              log_eps=1e-6,
              overlap_eps=1e-6):
    
    basedir = Path(basedir)

    basedir.mkdir(exist_ok=True)

    # 1) load agents + generators
    agents = load_final_step(checkpoint_dir)
    if agents is None:
        raise FileNotFoundError(f"No step_XXXX.pkl found in {checkpoint_dir}/")
    Gq, Gp, generators = _prepare_generators()

    # 2) run alignment diagnostics (belief/model)
    _run_alignment_suite(agents, generators, basedir, log_eps, overlap_eps)
    print("\n[✓] Alignment analyses complete.\n")

    # 3) evaluate clusterings and pick best
    best = {"prefix": None, "score": -1.0, "labels": None, "kl_matrix": None}
    # map prefixes → (subfolder, curvature generators)
    eval_specs = {
        "kl":       (basedir / "belief_alignment_output", Gq),
        "kl_model": (basedir / "model_alignment_output",  Gp),
    }
    for prefix, (align_dir, curv_G) in eval_specs.items():
        print(f"\n[INFO] Processing '{prefix}' clusters from '{align_dir}'")
        res = _evaluate_one_prefix(
            agents, align_dir, prefix, curv_G, outdir_root=basedir / "condensation_output"
        )
        if res and res["score"] > best["score"]:
            best = res

    if best["prefix"] is None:
        raise RuntimeError("No valid clustering found to build meta-agents.")
    print(f"\n[INFO] Selected clustering for meta-agent build: {best['prefix']} (score={best['score']:.4f})")

    # 4) build meta-agents, wire links, coarse-grain fields, seed Λ, persist, run L0
    chosen_G = Gq if best["prefix"] == "kl" else Gp
    meta_agents = build_meta_agents_from_clusters(agents, best["labels"], chosen_G)
    _ensure_parent_slots(meta_agents, K_q, K_p)
    wire_child_parent_links(agents, meta_agents, best["labels"])

    for P in meta_agents:
        coarsen_phi_from_children(P, agents, field="phi",       weight_mode="mask")
        coarsen_phi_from_children(P, agents, field="phi_model", weight_mode="mask")
    _post_build_summaries(meta_agents)

    _seed_or_revert_procrustes(meta_agents, agents, best["labels"])

    save_meta_agents(meta_agents, output_dir=str(basedir / "meta_agent_fields"))
    save_meta_labels(best["labels"], path=str(basedir / "meta_labels.csv"))

    runtime_params = build_runtime_params_for_xscale(Gq, Gp, meta_agents, best["labels"])
    run_simulation(outdir="checkpoints_L0", params=runtime_params)

    # 5) quick plots
    plots_dir = basedir / "agent_plots"
    plots_dir.mkdir(exist_ok=True)
    plot_cluster_size_hist(best["labels"], outpath=plots_dir / "cluster_sizes.png")
    plot_child_parent_overlay(agents, meta_agents, best["labels"], outpath=plots_dir / "child_parent_overlay.png", max_examples=12)
    vals = compute_avg_crossscale_kl_q(agents, meta_agents, best["labels"], eps=1e-6)
    plot_crossscale_kl_hist(vals, outpath=plots_dir / "crossscale_kl_q_hist.png")

def main():
    """
    CLI wrapper:
      - default: run the single-level pipeline (old main behavior)
      - with --levels > 0: run multi-level recursion
    """
    p = argparse.ArgumentParser()
    p.add_argument("--levels", type=int, default = 2,
                   help="Number of recursion levels (0 = single-level only).")
    p.add_argument("--steps", type=int, nargs="*", default=None,
                   help="Optional steps per level, e.g. --steps 150 120 120.")
    p.add_argument("--base-ckpt", default="checkpoints",
                   help="Input checkpoint directory for L0 (and prefix for outputs).")
    p.add_argument("--out-root", default="meta_agent_analysis",
                   help="Root folder for analysis artifacts.")
    p.add_argument("--log-eps", type=float, default=1e-6)
    p.add_argument("--overlap-eps", type=float, default=1e-6)
    p.add_argument("--plateau-window", type=int, default=15)
    p.add_argument("--plateau-tol", type=float, default=1e-3)
    args = p.parse_args()

    if args.levels and args.levels > 0:
        # Run multi-level recursion
        run_meta_recursion(
            levels=args.levels,
            base_ckpt=args.base_ckpt,
            steps_per_level=args.steps,
            log_eps=args.log_eps,
            overlap_eps=args.overlap_eps,
            plateau_window=args.plateau_window,
            plateau_tol=args.plateau_tol,
            out_root=args.out_root,
        )
    else:
        # Run the original single-level flow
        main_once(
            checkpoint_dir=args.base_ckpt,
            basedir=args.out_root,
            log_eps=args.log_eps,
            overlap_eps=args.overlap_eps,
        )


if __name__ == "__main__":
    main()


