import numpy as np
import sys

# ===========================
# DEBUGGING AND UTILITIES
# ===========================

# 1) define at top of your script/module
def scaled_eta(base, *weights, min_den=1.0):
    """
    If all weights sum to zero, return base.
    Otherwise return base / max(sum(weights), min_den).
    """
    total = sum(weights)
    if total <= 0:
        return base
    return base / max(total, min_den)

def set_config_from_params(params):
    """Dynamically override config attributes from a dictionary."""
    this_module = sys.modules[__name__]
    for k, v in params.items():
        setattr(this_module, k, v)

epsilon_model      = 1.0      # Threshold to classify meta-agents (can sweep)

# config.py
phi_morphism_type       = "gauge_covariant"         # identity  gauge_covariant 
phi_model_morphism_type = "gauge_covariant"

morphism_normalize    = True


# Toggle between diagonal and full Σ initialization
diagonal_sigma = False

# ===========================
# DOMAIN / SPATIAL SETTINGS
# ===========================
K_q           = 7
K_p           = 9       # Fiber dimension of belief/model space (depends on representation)
                 
D             = 2           #dimension of base manifold - d=2 validated

L             = 12         #length of hypercubic base-manifold - PBCs

steps         = 100

N             = 5                       # Number of agents
max_neighbors = 5         # Max number of agent neighbors

agent_radius_range = (2,2)         #agent radii
             
# ===========================
# COUPLINGS & PENALTIES
# ===========================

alpha                  = 0.25
beta                   = 1
belief_mass            = 1
curvature_weight       = 1

feedback_weight         = 0
beta_model              = 1
model_mass              = 1
model_curvature_weight  = 1

entropy_weight          = 1


#==========================
#    IF NEEDED/CURIOUS
#==========================
exp_n_jobs = 12

phi_coupling_weight           = 0             # set > 0 to enable
phi_coupling_mode             = "projection"  # or "conjugation"


fisher_geometry_weight        = 0      
fisher_model_geometry_weight  = 0

# ===========================
# INITIALIZATION
# ===========================

# ─── Belief Bundle (q) Parameters ───
q_mu_range                     = (-1.0, 1.0)              # Range for μ_q
q_sigma_range                  = (0.2, 1.0)           # Diagonal Σ_q entries

belief_noise_scale_mu          = 0.01         # Additive noise for μ_q
belief_noise_scale_sigma       = 0.01      # Additive noise for Σ_q


# ─── Model Bundle (p) Parameters ───
p_mu_range                     = (-1.0, 1.0)             # Range for μ_p
p_sigma_range                  = (0.2, 1.0)           # Diagonal Σ_p entries

model_noise_scale_mu           = 0.01          # Additive noise for μ_p
model_noise_scale_sigma        = 0.01       # Additive noise for Σ_p

sigma_outside_val              = 1e3  # large uncertainty outside support

#======================
#
#   LEARNING RATES
#
#======================
tau_phi                 = 1e-4
tau_phi_model           = 1e-4    
tau_mu_belief           = 1e-5       # update rate for η₁_q
tau_sigma_belief        = 1e-5       # update rate for η₂_q
tau_mu_model            = 1e-5      # update rate for η₁_p
tau_sigma_model         = 1e-5       # update rate for η₂_p



phi_init_smooth_sigma   = 1.5
phi_init                = 0.1
phi_model_offset        = 0.1


eta_ema_alpha                   = 0.6          # try 0.4–0.8
eta_phi_adaptive_scaling        = 1.0
eta_phi_model_adaptive_scaling  = 1.0
eta_sigma_condition_scaling     = 0.1   # start small
sigma_eig_floor                 = 1e-6
sigma_cond_cap                  = 1e4

sigma_eig_cap                   = None          # usually None
sigma_trace_target              = None     # or K if you want trace control




eta_phi_min           = 1e-6
eta_phi_model_min     = 1e-6



#==========================================
#
#       META-AGENTS
#
#==========================================
# Cross-scale toggles
enable_crossscale = True

# Weights (q-fiber)
beta_up_q = 0.30   # child → parent
beta_dn_q = 0.10   # parent → children (smaller at first)

# Weights (p-fiber) — off for now; turn on later
beta_up_p = 0.00
beta_dn_p = 0.00

# Cross-bundle Θ terms — not implemented yet, keep 0
gamma_theta_up = 0.00
gamma_theta_dn = 0.00

# Functorial penalties (intertwining) — not implemented yet, keep 0
lambda_functor_q = 0.00
lambda_functor_p = 0.00

# Clustering / aggregation
overlap_eps = 1e-3

# Logging & seeding
xscale_log_every = 1
xscale_seed_lambda_dn_q = True      # good instant KL drop
xscale_lambda_ridge     = 1e-3      # for the Procrustes seed

# Cross-scale (model side)
enable_crossscale_p      = True
beta_up_p                = 0.20
beta_dn_p                = 0.20
xscale_lr_mu_p_up        = 0.10
xscale_lr_sigma_p_up     = 0.05
xscale_lr_mu_p_dn        = 0.08
xscale_lr_sigma_p_dn     = 0.04


# ===========================
# AGENT GEOMETRY
# ===========================


gaussian_blur_range_morphism = (1,2)
mu_clip = 3.0



#================================
#
#  INITIALIZE GLOBAL FIELDS 
#      WITH GENTLE NOISE
#================================
use_global_belief_template = False
use_global_model_template  = False



identical_models = False         # If True, all agents share the same p, mu_p_field, sigma_p_field

agent_seed    = 651


# ===========================
# STABILITY AND CLIPPING
# ===========================


                                    # Gradient clipping magnitudes (optional; set to None to disable)
phi_grad_clip             = 1e5    # Max L2 norm per-point for φ update
phi_model_grad_clip       = 1e5    # Max L2 norm per-point for φ̃ update

                                     # Optional: norm type (future-proofing, L2 is default)
gradient_clip_norm_type   = 2           # Use 2 for L2 norm; 1 for L1, np.inf for max-norm
phi_exp_clip              = np.pi  # or 2π if you're okay with aliasing


mask_sharpness        = 1.5
# ===========================
# EPSILONS & NUMERICAL STABILITY
# ===========================

log_eps            = 1e-6     # Stabilize log(x)
eps                = 1e-5
# ===========================
# MASK & INTERACTION THRESHOLDS
# ===========================

support_cutoff_eps = 1e-3    # Mask threshold to include point in agent support
overlap_eps        = 1e-3     # Threshold for computing inter-agent overlap

# ===========================
# SIMULATION THRESHOLDS
# ===========================



# ===========================
# CHECKPOINTING
# ===========================

checkpoint_dir      = "checkpoints"
precision = np.float32

checkpoint_interval = 1

domain_size = (L,) * D

# 3) replace all the old eta_* calculations with calls to scaled_eta


num_cores = 1  # or however many threads you want to use



group_name = 'so3'               # Options: "u1", "so3", "so3", 'su2'.

phi_bch_max_norm = 25.0


# Enable numerical safety logging
debug = True  # Global debug flag for extra logging inside φ updates                       

  
fail_on_fallback = False                # Allow recovery rather than crashing


#=================
#    LOGDET
#==================


# ── Numerical Safeguards ─────────────────────────────
max_fisher_condition = 1e5   # Maximum allowed condition number before fallback


# Control fallback thresholds (optional)
max_safe_inv_fallbacks = 1000
max_safe_logdet_fallbacks = 1000

# ─────────────────────────────────────────────────────────
# Logging / dump toggles (matches new logger + field dumper)
# ─────────────────────────────────────────────────────────
logging = dict(
    # master switches
    enable_scalar=True,          # run log_all_metrics (global + per-agent scalars)
    enable_fields=True,          # run full_field_logger (NPZ field dumps)

    # compute-time guards (controls what goes into NPZ)
    compute_alignment=True,      # belief/model alignment maps + KL(p→q, q→p)
    compute_curvature=True,      # curvature tensors + Fq_norm/Fp_norm
    compute_pairwise_overlap=False,  # optional: builds overlap matrix (debug)

    # summaries (affects per-agent CSV rows)
    log_support_stats=True,
    log_overlap_stats=True,
    log_gradient_stats=True,     # needs *_grad or debug counters on Agent
    log_conditioning=True,       # min/max eigs, cond numbers

    # normalization / console
    normalize_by_support=True,
    print_total_energy=True,     # console print of global energies

    # cadence + outdirs
    fields_every=1,              # dump fields every step (turn up if disk heavy)
    max_overlap_every=10,        # only used if you keep overlap logging on
    full_field_outdir="fields",
    pair_outdir="max_overlap",

    # schema
    schema_version="v3",
)

# Keep this True if any legacy gate still checks it (safe to include)
log_full_fields = True

# Finite-difference checks (optional diagnostics cadence)
fd_check_every = 1000
fd_pairs_per_step = 1
