import numpy as np
import itertools as it
import networkx as nx
import matplotlib.pyplot as plt
from matplotlib import cm
from pathlib import Path
import json
from numerical_utils import safe_inv
# --- Project-specific imports ---
import config
from config import checkpoint_dir, group_name, K_q, K_p, log_eps, overlap_eps

from generalized_io_utils import (
    load_final_step,
    load_agents,
    save_generic_alignment_data,
    save_meta_agents,
    load_meta_agents,
    save_meta_labels,
    load_meta_data,
)

from omega import (
    compute_field_strength,
    compute_inter_omega,
    batch_apply_omega,
   )
from numerical_utils import sanitize_sigma
from generalized_diagnostics_metrics import  kl_divergence
from agent_initialization import attach_crossscale_fields
# meta_agent_utils.py
import numpy as np
import config
from get_generators import get_generators





def _prepare_generators():
    Gq = get_generators(group_name, K_q)
    Gp = get_generators(group_name, K_p)
    return Gq, Gp, {"q": Gq, "p": Gp}


def wire_child_parent_links(children, parents, labels):
    for P in parents:
        P.child_ids = []
        P.level = getattr(P, "level", 1)
    for cid, child in enumerate(children):
        pid = int(labels[cid])
        child.parent_ids = [pid]
        parents[pid].child_ids.append(cid)


def _kl_plateau(metric_log, window=15, tol=1e-3):
    vals = [m.get("xscale_kl_q_mean") for m in metric_log if "xscale_kl_q_mean" in m]
    vals = [v for v in vals if v is not None and np.isfinite(v)]
    if len(vals) < 2*window:
        return False, np.nan
    a, b = np.nanmean(vals[-2*window:-window]), np.nanmean(vals[-window:])
    return (abs(a - b) < tol), b

def _ensure_parent_slots(meta_agents, Kq=None, Kp=None):
    """Ensure parents have Λ/Θ slots and a level tag."""
    Kq = getattr(config, "K_q") if Kq is None else Kq
    Kp = getattr(config, "K_p") if Kp is None else Kp
    for P in meta_agents:
        attach_crossscale_fields(P, Kq, Kp)  # no-op if present
        P.level = getattr(P, "level", 1)


def _first_present_key(d, candidates):
    for k in candidates:
        if k in d:
            return k
    return None

def get_intra_inter(stats, kl_matrix, labels):
    """
    Returns two 1D arrays: intra_vals, inter_vals.
    Tries to read from `stats`; if unavailable, computes from kl_matrix + labels.
    """
    import numpy as np

    # Try to read from stats using a few common key names
    if stats and len(stats) > 0:
        intra_all, inter_all = [], []
        for cid, entry in stats.items():
            # allow several possible key names
            k_intra = _first_present_key(entry, ["intra", "intra_kl", "intra_vals", "intra_values"])
            k_inter = _first_present_key(entry, ["inter", "inter_kl", "inter_vals", "inter_values"])
            if k_intra is not None:
                intra_all.append(np.asarray(entry[k_intra]).ravel())
            if k_inter is not None:
                inter_all.append(np.asarray(entry[k_inter]).ravel())
        if intra_all and inter_all:
            return np.concatenate(intra_all), np.concatenate(inter_all)
        # fall through to matrix-based if one is missing

    # Fallback: compute from matrix + labels
    labels = np.asarray(labels)
    uniq = np.unique(labels[labels >= 0])
    intra_vals, inter_vals = [], []
    for a in uniq:
        idx_a = np.where(labels == a)[0]
        if idx_a.size >= 2:
            # intra-cluster (exclude diagonal)
            block = kl_matrix[np.ix_(idx_a, idx_a)].astype(float)
            mask = ~np.eye(block.shape[0], dtype=bool)
            intra_vals.append(block[mask])
        # inter-cluster
        for b in uniq:
            if b <= a:
                continue
            idx_b = np.where(labels == b)[0]
            if idx_b.size == 0 or idx_a.size == 0:
                continue
            block_ab = kl_matrix[np.ix_(idx_a, idx_b)].astype(float)
            inter_vals.append(block_ab.ravel())

    intra = np.concatenate(intra_vals) if intra_vals else np.array([])
    inter = np.concatenate(inter_vals) if inter_vals else np.array([])
    return intra, inter



def gaussian_pushforward_linear(mu, Sigma, A):
    """Push (mu,Sigma) by linear map A: (A mu, A Σ A^T)."""
    mu_t = np.einsum('...ij,...j->...i', A, mu)
    S_t  = np.einsum('...ik,...kl,...jl->...ij', A, Sigma, A)
    return mu_t, S_t


def condensation_score(stats, R_global, sigma_global, kl_matrix=None, labels=None):
    """
    Larger is better. Combines inter/intra separation and global order sharpness.
    Robust to missing 'intra'/'inter' keys in `stats`.
    """
    import numpy as np
    intra, inter = get_intra_inter(stats, kl_matrix, labels)

    # Handle edge cases gracefully
    if intra.size == 0 and inter.size == 0:
        return -1.0
    if intra.size == 0:  # no within-cluster pairs (e.g., all singletons)
        sep = 1.0
    elif inter.size == 0:  # only one cluster → no inter-cluster pairs
        sep = 1.0
    else:
        sep = (np.nanmean(inter) + 1e-9) / (np.nanmean(intra) + 1e-9)

    order = R_global / (sigma_global + 1e-9) if sigma_global is not None else 0.0
    return 0.7 * sep + 0.3 * order


def save_meta_agent_summary(meta_agents, path="meta_agent_analysis/meta_agent_summary.json"):
    out = []
    for P in meta_agents:
        # center as tuple[int,int] or None
        center = getattr(P, "center", None)
        if center is not None:
            try:
                center = (int(center[0]), int(center[1]))
            except Exception:
                center = None

        row = {
            "id": _as_int_or_none(getattr(P, "id", None)),
            "level": _as_int_or_none(getattr(P, "level", None)),
            "center": center,
            "radius": _as_float_or_nan(getattr(P, "radius", None)),

            "mask_shape": _shape_or_none(getattr(P, "mask", None)),
            "K_q": (int(getattr(P, "mu_q_field").shape[-1]) 
                    if getattr(P, "mu_q_field", None) is not None else None),
            "K_p": (int(getattr(P, "mu_p_field").shape[-1]) 
                    if getattr(P, "mu_p_field", None) is not None else None),

            "Lambda_dn_q_shape": _shape_or_none(getattr(P, "Lambda_dn_q", None)),
            "Lambda_dn_p_shape": _shape_or_none(getattr(P, "Lambda_dn_p", None)),

            "child_ids": _to_py_list_int(getattr(P, "child_ids", [])),
            "parent_ids": _to_py_list_int(getattr(P, "parent_ids", [])),
        }
        out.append(row)

    Path(path).parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w") as f:
        json.dump(out, f, indent=2)



def _weighted_mean_field(stack, weights, eps=1e-8):
    """
    stack: (C, H, W, D)
    weights: (C, H, W, 1) nonnegative
    returns (H, W, D)
    """
    num = np.sum(weights * stack, axis=0)
    den = np.sum(weights, axis=0) + eps
    return num / den


def _shape_or_none(x):
    try:
        return None if x is None else tuple(int(s) for s in x.shape)
    except Exception:
        return None

def _as_int_or_none(x):
    if x is None:
        return None
    return int(x) if isinstance(x, (int, np.integer)) else int(x)

def _as_float_or_nan(x):
    if x is None:
        return float("nan")
    return float(x) if isinstance(x, (float, np.floating)) else float(x)

def _to_py_list_int(xs):
    return [int(v) for v in xs] if xs is not None else []

def procrustes_seed_lambda_dn_q(parents, children, labels, eps=1e-6, center=True, min_samples=5):
    import numpy as np
    labels = np.asarray(labels)
    parent_to_kids = {}
    for ci, pid in enumerate(labels):
        if pid >= 0:
            parent_to_kids.setdefault(int(pid), []).append(ci)

    for pid, kid_ids in parent_to_kids.items():
        P = parents[pid]
        H, W, K = P.mu_q_field.shape
        if not kid_ids:
            L = np.eye(K, dtype=P.mu_q_field.dtype)
        else:
            Xs, Ys = [], []  # child, parent
            Y_flat = P.mu_q_field.reshape(-1, K)
            M_par  = (P.mask > eps).reshape(-1)
            for ci in kid_ids:
                C = children[ci]
                X_flat = C.mu_q_field.reshape(-1, K)
                M = (C.mask > eps).reshape(-1) & M_par
                if np.any(M):
                    Xs.append(X_flat[M]); Ys.append(Y_flat[M])
            if not Xs or sum(x.shape[0] for x in Xs) < max(min_samples, K):
                L = np.eye(K, dtype=P.mu_q_field.dtype)
            else:
                X = np.vstack(Xs); Y = np.vstack(Ys)
                if center:
                    X -= X.mean(axis=0, keepdims=True)
                    Y -= Y.mean(axis=0, keepdims=True)
                M = X.T @ Y                      # (K×K)
                U, _, Vt = np.linalg.svd(M, full_matrices=False)
                L = U @ Vt                        # orthogonal
                if np.linalg.det(L) < 0:          # reflection fix → proper rotation
                    U[:, -1] *= -1
                    L = U @ Vt
        P.Lambda_dn_q = L
        P.Lambda_up_q = L.T



def build_runtime_params_for_xscale(generators_q, generators_p, parents, labels):
    return {
        "generators_q": generators_q,
        "generators_p": generators_p,
        "enable_crossscale": getattr(config, "enable_crossscale", False),

        # weights from config
        "beta_up_q":  getattr(config, "beta_up_q", 0.0),
        "beta_dn_q":  getattr(config, "beta_dn_q", 0.0),
        "beta_up_p":  getattr(config, "beta_up_p", 0.0),
        "beta_dn_p":  getattr(config, "beta_dn_p", 0.0),

        # lrs + logging
        "xscale_lr_mu_q_up":    getattr(config, "xscale_lr_mu_q_up", 0.12),
        "xscale_lr_sigma_q_up": getattr(config, "xscale_lr_sigma_q_up", 0.05),
        "xscale_lr_mu_q_dn":    getattr(config, "xscale_lr_mu_q_dn", 0.08),
        "xscale_lr_sigma_q_dn": getattr(config, "xscale_lr_sigma_q_dn", 0.04),
        "xscale_log_every":     getattr(config, "xscale_log_every", 10),

        # dynamic context stays here (not in config)
        "xscale": {
            "parents": parents,
            "labels":  np.asarray(labels),
        },
    }



def transport_covariance_batch(Sigma, Omega):
    """
    Transport a batch of covariance matrices: Σ → Ω Σ Ωᵀ

    Parameters:
        Sigma: (N, K, K) — batch of covariance matrices
        Omega: (N, K, K) — batch of transport operators

    Returns:
        Sigma_t: (N, K, K) — transported covariances
    """
    return Omega @ Sigma @ np.transpose(Omega, (0, 2, 1))


def aggregate_fields(agent_list, attr: str):
    """Average a tensor field (e.g., mu_q_field) over agents."""
    return np.mean([getattr(ag, attr) for ag in agent_list], axis=0)


def aggregate_mask(agent_list, eps: float = 1e-3):
    """Compute union of support masks across agents."""
    masks = [(ag.mask > eps).astype(float) for ag in agent_list]
    return np.clip(np.sum(masks, axis=0), 0, 1)



def curvature_mean_per_agent(agents, generators) -> np.ndarray:
    """
    Compute ⟨Tr(F_{μν} F^{μν})⟩ for each agent using field strength from generalized_omega.
    Only includes values inside the agent's support.
    """
    eps = getattr(config, "support_cutoff_eps", 1e-3)
    means = []

    for i, ag in enumerate(agents):
        try:
            mask = ag.mask > eps
            F_dict = compute_field_strength(ag.phi, generators)
            H, W = ag.phi.shape[:2]

            total_energy = 0.0
            count = np.sum(mask)

            for F_name, F in F_dict.items():
                if F.ndim != 4 or F.shape[-2:] != (generators.shape[1], generators.shape[2]):
                    print(f"[!] Skipping invalid F[{F_name}] shape: {F.shape}")
                    continue

                # Compute Tr(F²) per point: sum_ij F_ij²
                pointwise_energy = np.einsum("...ij,...ij->...", F, F)  # (H, W)
                total_energy += np.sum(pointwise_energy[mask])

            mean_energy = total_energy / count if count > 0 else 0.0
            means.append(mean_energy)

        except Exception as e:
            print(f"[!] Failed to compute curvature for agent {i}: {e}")
            means.append(0.0)

    return np.array(means)




def compute_phi_variance_per_cluster(agents, labels):
    """
    Compute φ-norm variance for each cluster of agents.

    Returns:
        stats: dict {cluster_id: {'phi_means': [...], 'phi_var': float}}
    """
    eps = getattr(config, "support_cutoff_eps", 1e-3)
    stats = {}

    for lab in np.unique(labels):
        if lab < 0:
            continue  # Ignore noise/outlier label

        idx = np.where(labels == lab)[0]
        means = []

        for i in idx:
            agent = agents[i]
            if agent.phi is None:
                continue
            mask = agent.mask > eps
            phi_norm = np.linalg.norm(agent.phi, axis=-1)
            if np.any(mask):
                mean_val = np.mean(phi_norm[mask])
                means.append(float(mean_val))

        if means:
            stats[int(lab)] = {
                'phi_means': means,
                'phi_var': float(np.var(means))
            }

    return stats


def rank_agent_alignment(kl_matrix):
    """
    For each agent i, rank all other agents by ascending KL divergence.
    Returns dict[i] = {"best": j, "worst": k, "full_rank": [j1, j2, ...]}
    """
    N = kl_matrix.shape[0]
    rankings = {}
    for i in range(N):
        dists = kl_matrix[i].copy()
        dists[i] = np.inf  # ignore self
        sorted_idx = np.argsort(dists)
        rankings[i] = {
            "best": int(sorted_idx[0]),
            "worst": int(sorted_idx[-1]),
            "full_rank": sorted_idx.tolist()
        }
    return rankings

def compute_symmetric_kl_matrix(kl_matrix: np.ndarray) -> np.ndarray:
    """
    Compute the symmetrized KL matrix:
        D_sym(i, j) = 0.5 * [ D_KL(q_i || Ω q_j) + D_KL(q_j || Ω⁻¹ q_i) ]
    Args:
        kl_matrix: (N, N) asymmetric KL divergence matrix
    Returns:
        symmetric KL matrix (N, N)
    """
    assert kl_matrix.shape[0] == kl_matrix.shape[1], "KL matrix must be square"
    return 0.5 * (kl_matrix + kl_matrix.T)

def compute_cluster_kl_stats(kl_matrix, labels, verbose=False):
    """
    Compute intra-/extra-cluster KL stats for each cluster.
    Returns dict[cluster_id] = {intra_vals, extra_vals, means, stds}
    """
    stats = {}
    for lab in np.unique(labels):
        if lab < 0:
            continue
        idx = np.where(labels == lab)[0]
        others = np.where(labels != lab)[0]

        # Intra-cluster KL
        intra_vals = kl_matrix[np.ix_(idx, idx)]
        iu = np.triu_indices(len(idx), k=1)
        intra = intra_vals[iu][np.isfinite(intra_vals[iu])]

        # Extra-cluster KL
        extra = kl_matrix[np.ix_(idx, others)].ravel()
        extra = extra[np.isfinite(extra)]

        stats[int(lab)] = {
            'intra_vals': intra,
            'extra_vals': extra,
            'intra_mean': float(np.mean(intra)) if intra.size else np.nan,
            'extra_mean': float(np.mean(extra)) if extra.size else np.nan,
            'intra_std': float(np.std(intra)) if intra.size else np.nan,
            'extra_std': float(np.std(extra)) if extra.size else np.nan,
        }

        if verbose:
            print(f"[cluster {lab}] N={len(idx)}  KL_intra={stats[lab]['intra_mean']:.3f}  KL_extra={stats[lab]['extra_mean']:.3f}")

    return stats

def compute_order_parameter(kl_matrix):
    """
    Compute global condensation order parameter R, based on median KL.
    """
    i, j = np.triu_indices(kl_matrix.shape[0], k=1)
    d = kl_matrix[i, j]
    d = d[np.isfinite(d)]
    sigma = float(np.median(d)) if d.size else 1.0
    R = float(np.sum(np.exp(-d / sigma)) / d.size) if d.size else 0.0
    return R, sigma

def compute_cluster_order_parameters(kl_matrix, labels):
    """
    For each cluster: compute (R_C, sigma_C) based on pairwise KLs.
    Returns dict[cluster_id] = (R, sigma)
    """
    clusters = {}
    for lab in sorted(set(labels)):
        if lab < 0:
            continue
        idx = np.where(labels == lab)[0]
        if len(idx) < 2:
            clusters[lab] = (1.0, 0.0)
            continue

        sub = kl_matrix[np.ix_(idx, idx)]
        i, j = np.triu_indices(len(idx), k=1)
        vals = sub[i, j][np.isfinite(sub[i, j])]

        sigma = float(np.median(vals)) if vals.size else 1.0
        R = float(np.mean(np.exp(-vals / sigma))) if sigma > 0 else 1.0
        clusters[lab] = (R, sigma)
    return clusters

def find_meta_agents(sym_kl, overlap_area, curv_mean, tau_A=10, eta=10, tau_C=10, verbose=False):
    """
    Identify meta-agent clusters based on KL, curvature, and overlap graph.
    """
    N = sym_kl.shape[0]
    finite_vals = sym_kl[np.isfinite(sym_kl)]
    eps = np.quantile(finite_vals, 0.30)
    eps = max(eps, getattr(config, "epsilon_model", 1e-6))

    # Build connectivity graph
    G = nx.Graph()
    G.add_nodes_from(range(N))
    for i, j in it.combinations(range(N), 2):
        d = sym_kl[i, j]
        if np.isfinite(d) and d <= eps:
            G.add_edge(i, j, weight=d)

    # Connected components as candidate meta-agents
    meta = []
    for comp in nx.connected_components(G):
        C = list(comp)
        if len(C) < 2:
            continue

        out_set = list(set(range(N)) - set(C))
        intra = sym_kl[np.ix_(C, C)][np.triu_indices(len(C), k=1)]
        extra = sym_kl[np.ix_(C, out_set)].ravel()
        intra = intra[np.isfinite(intra)]
        extra = extra[np.isfinite(extra)]

        intra_mean = float(np.mean(intra)) if intra.size else np.inf
        extra_mean = float(np.mean(extra)) if extra.size else np.inf
        curv_mean_C = float(np.mean(curv_mean[C])) if len(C) else np.inf

        accept = (intra_mean < tau_A and curv_mean_C < tau_C and
                  (extra.size == 0 or intra_mean < eta * extra_mean))

        if accept:
            meta.append(C)
            if verbose:
                print(f"[✓] meta-cluster size={len(C)}, <KL_intra>={intra_mean:.3f}, <KL_extra>={extra_mean:.3f}, <curv>={curv_mean_C:.3f}")

    labels = np.full(N, -1, dtype=int)
    for k, C in enumerate(meta):
        labels[np.array(C)] = k

    return meta, labels, eps


def overlap_area_matrix(agents, eps: float = 1e-6) -> np.ndarray:
    """
    Compute N x N matrix where entry (i, j) is the area of overlap between agent i and j.
    """
    N = len(agents)
    area = np.zeros((N, N), dtype=float)
    for i in range(N):
        mask_i = agents[i].mask > eps
        for j in range(i, N):
            if i == j:
                area[i, j] = np.sum(mask_i)
            else:
                mask_j = agents[j].mask > eps
                area_ij = np.sum(np.logical_and(mask_i, mask_j))
                area[i, j] = area[j, i] = area_ij
    return area


from bundle_morphism_utils import safe_batch_apply_morphism_nat


def compute_avg_crossscale_kl_p(children, parents, labels, eps=1e-6):
    """
    Mean over child pixels of KL( p_child || (Λ_dn_p)_# p_parent ), masked to overlaps.
    Returns per-child array of means (NaN where no overlap).
    """
    labels = np.asarray(labels)
    out = np.full((len(children),), np.nan, dtype=np.float64)
    for ci, c in enumerate(children):
        pid = int(labels[ci]) if labels[ci] >= 0 else -1
        if pid < 0: continue
        p = parents[pid]

        Kp = c.mu_p_field.shape[-1]
        L = getattr(p, "Lambda_dn_p", None)
        if L is None:
            L_field = np.broadcast_to(np.eye(Kp, dtype=c.mu_p_field.dtype),
                                      c.mu_p_field.shape[:2] + (Kp, Kp))
        else:
            L = np.asarray(L)
            L_field = np.broadcast_to(L, c.mu_p_field.shape[:2] + L.shape) if L.ndim == 2 else L

        mu_t, S_t = gaussian_pushforward_linear(p.mu_p_field, sanitize_sigma(p.sigma_p_field, eps=eps), L_field)
        mu_c, S_c = c.mu_p_field, sanitize_sigma(c.sigma_p_field, eps=eps)

        kl = kl_gaussians(mu_c, S_c, mu_t, S_t, eps=eps)     # (H,W)
        m = (c.mask > eps) & (p.mask > eps)
        if np.any(m):
            out[ci] = float(np.nanmean(kl[m]))
    return out



def kl_gaussians(mu1, S1, mu2, S2, eps=1e-6):
    """KL(N(μ1,Σ1) || N(μ2,Σ2)) — batch-safe, no fragile squeezes."""
    S1 = sanitize_sigma(S1, eps=eps)
    S2 = sanitize_sigma(S2, eps=eps)
    K = S1.shape[-1]
    S2_inv = safe_inv(S2, eps=eps)
    dmu = (mu2 - mu1)                                       # (..., K)
    term_trace = np.einsum('...ij,...ji->...', S2_inv, S1)  # tr(S2^{-1} Σ1)
    term_quad  = np.einsum('...i,...ij,...j->...', dmu, S2_inv, dmu)  # (μ2-μ1)^T S2^{-1} (μ2-μ1)
    s1, logdet1 = np.linalg.slogdet(S1)
    s2, logdet2 = np.linalg.slogdet(S2)
    logdet_ratio = logdet2 - logdet1
    return 0.5 * (term_trace + term_quad - K + logdet_ratio)

def compute_avg_crossscale_kl_q(children, parents, labels, eps=1e-6):
    """
    For each child → parent, compute mean KL( q_child || Λ_dn_q · q_parent )
    over their spatial overlap. Λ_dn_q can be a global (Kq,Kq) or per-pixel (H,W,Kq,Kq).
    Falls back to identity if the map is missing.
    """
    vals = []
    labels = np.asarray(labels)

    for ci, child in enumerate(children):
        pid = int(labels[ci]) if labels[ci] >= 0 else -1
        if pid < 0:
            vals.append(np.nan)
            continue

        parent = parents[pid]
        Kq = child.mu_q_field.shape[-1]

        # Get Λ_dn_q (allow global or per-pixel)
        L = getattr(parent, "Lambda_dn_q", None)
        if L is None:
            L_field = np.broadcast_to(np.eye(Kq, dtype=child.mu_q_field.dtype),
                                      child.mu_q_field.shape[:2] + (Kq, Kq))
        else:
            L = np.asarray(L)
            if L.ndim == 2:  # (Kq,Kq) → broadcast to (H,W,Kq,Kq)
                L_field = np.broadcast_to(L, child.mu_q_field.shape[:2] + L.shape)
            else:
                L_field = L  # assume already (H,W,Kq,Kq)

        # Push parent q down to child via Λ_dn_q
        mu_push, Sigma_push = safe_batch_apply_morphism_nat(
            parent.mu_q_field, parent.sigma_q_field, L_field, eps=eps
        )

        # Overlap mask
        overlap = (child.mask > eps) & (parent.mask > eps)
        if not np.any(overlap):
            vals.append(np.nan)
            continue

        # KL over overlap
        kl_vals = kl_divergence(
            child.mu_q_field[overlap],
            child.sigma_q_field[overlap],
            mu_push[overlap],
            Sigma_push[overlap],
            eps=eps,
        )
        vals.append(float(np.nanmean(kl_vals)))

    return vals

