# -*- coding: utf-8 -*-
"""
Created on Mon Sep  8 16:26:26 2025

@author: chris and christine
"""
import core.config as config
import numpy as np
from core.numerical_utils import safe_inv, sanitize_sigma  
from typing import Optional
from core.transport_cache import warm_E, warm_Jinv, get_morphism_bases, Phi, _aid
from core.omega import pre_retract_fields

from utils import standardize_all_masks_once, _phi_mats


# --- Unified dirty manager ----------------------------------------------------
class DirtyManager:
    """
    Single source of truth for 'dirty' state.

    Responsibilities:
      - Track dirty agents across categories: fields, kl, morphisms
      - Provide stable IDs (no object-id fallbacks)
      - Materialize a target agent subset by category
      - Clear agent-side flags only after successful processing
      - Bump ctx cache_version exactly when work happened
    """
    __slots__ = ("_fields", "_kl", "_morph",)

    def __init__(self):
        self._fields: set[int] = set()
        self._kl: set[int] = set()
        self._morph: set[int] = set()

    # ---- Stable ID helpers -------------------------------------------------
    @staticmethod
    def _aid(agent) -> int:
        aid = getattr(agent, "id", None)
        if aid is None:
            raise ValueError("DirtyManager: agent has no stable `id` attribute")
        return int(aid)

    # ---- Marking -----------------------------------------------------------
    def mark(self, *agents: object, kl: bool = False, morphism: bool = False) -> None:
        for a in agents:
            if a is None:
                continue
            aid = self._aid(a)
            # Always mark fields when any aspect of the agent changed
            self._fields.add(aid)
            setattr(a, "_dirty_fields", True)
            if kl:
                self._kl.add(aid)
                setattr(a, "_dirty_kl", True)
            if morphism:
                self._morph.add(aid)
                setattr(a, "morphisms_dirty", True)

    def mark_morphism_only(self, *agents: object) -> None:
        self.mark(*agents, morphism=True)

    def mark_kl_only(self, *agents: object) -> None:
        self.mark(*agents, kl=True)

    # ---- Selection ---------------------------------------------------------
    def take(self, all_agents: list, category: str = "fields") -> list:
        if   category == "fields": bag = self._fields
        elif category == "kl":     bag = self._kl
        elif category == "morph":  bag = self._morph
        else:
            raise ValueError(f"DirtyManager.take: unknown category {category!r}")

        if not bag:
            return []
        wanted = {int(x) for x in bag}
        subset = [a for a in (all_agents or []) if a is not None and self._aid(a) in wanted]
        bag.clear()
        return subset

    # ---- Post-processing cleanup ------------------------------------------
    def clear_agent_flags(self, *agents: object) -> None:
        for a in agents:
            if a is None:
                continue
            if hasattr(a, "_dirty_fields"): a._dirty_fields = False
            if hasattr(a, "_dirty_kl"):     a._dirty_kl = False
            if hasattr(a, "morphisms_dirty"): a.morphisms_dirty = False

# Attach/get from ctx (one per runtime context)
def dirty_manager(ctx) -> DirtyManager:
    d = getattr(ctx, "_dirty_manager", None)
    if d is None:
        d = DirtyManager()
        setattr(ctx, "_dirty_manager", d)
    return d




def ensure_dirty(ctx, generators_q, generators_p, scope="all"):
    """
    Resolve and process dirty agents for the given scope.
    Does: ensure transforms, warm caches, clear flags, bump cache when work happened.
    """
    from runtime_context import cfg_get
    DM = dirty_manager(ctx)

    # 1) Select targets by scope
    if scope not in ("all", "children"):
        raise ValueError(f"[ensure_dirty] unknown scope={scope!r}")
    all_children = list(getattr(ctx, "children_latest", []))
    targets = DM.take(all_children, category="fields")  # single category covers all field changes

    targets = [t for t in targets if t is not None]
    if not targets:
        return []

    # Record whether anything *was* marked dirty (for bump decision)
    had_flags = any(getattr(a, "_dirty_fields", False)
                    or getattr(a, "_dirty_kl", False)
                    or getattr(a, "morphisms_dirty", False)
                    for a in targets)

    # 2) Pre-retract fields (idempotent)
    pre_retract_fields(targets)

    did_any = False

    try:
        method = cfg_get(ctx, "intertwiner_method", "casimir")
        data   = cfg_get(ctx, "data_for_alignment", None)
        ensure_transforms(
            targets,
            generators_q=generators_q,
            generators_p=generators_p,
            ctx=ctx,
            intertwiner_method=method,
            data_for_alignment=data,
        )
        did_any = True
    except Exception as e:
        print(f"[ensure_dirty] ensure_transforms failed: {e}")

    # 4) Pre-warm caches (E, Jinv, Φ/Φ̃)
    try:
        warm_E(ctx, targets, whiches=("q", "p"))
        warm_Jinv(ctx, targets, whiches=("q", "p"))
        if Phi is not None:
            for a in targets:
                try:
                    _ = Phi(ctx, a, kind="q_to_p")
                    _ = Phi(ctx, a, kind="p_to_q")
                except Exception:
                    aid = _aid(a)
                    print(f"[ensure_dirty] Phi prewarm failed for agent id={aid}")
        did_any = True
    except Exception as e:
        print(f"[ensure_dirty] cache prewarm failed: {e}")

    # 5) Clear flags only if we actually processed them
    if did_any:
        DM.clear_agent_flags(*targets)

    # 6) Bump cache exactly when we had flags and did work
    if did_any and had_flags:
        setattr(ctx, "cache_version", int(getattr(ctx, "cache_version", 0)) + int(1))
    return targets




def ensure_transforms(
    targets,
    generators_q=None,
    generators_p=None,
    *,
    ctx=None,
    intertwiner_method="casimir",     # kept for API; get_morphism_bases builds on miss
    data_for_alignment=None,          # (unused here; building handled inside get_morphism_bases)
    fro_target: float | None = None,  # optional post-scale of cached bases
):
    """
    Ensure each target agent has geometric morphism bases (Phi0, Phit0) persisted in the central cache.
    Simplified policy: rely entirely on get_morphism_bases(ctx, agent) which fetches OR builds+persists.
    If fro_target is provided, rescale the cached bases to have that Frobenius norm (per base).
    """
    if not targets:
        return
    if ctx is None:
        raise RuntimeError("ensure_transforms: ctx is required (cache-centric design)")

    for a in targets:
        if a is None:
            continue

        # Infer fiber sizes from agent fields
        Kq = int(np.asarray(a.mu_q_field).shape[-1])
        Kp = int(np.asarray(a.mu_p_field).shape[-1])

        # Effective generators (prefer explicit, else agent-attached)
        Gq_eff = generators_q if generators_q is not None else getattr(a, "generators_q", None)
        Gp_eff = generators_p if generators_p is not None else getattr(a, "generators_p", None)
        if Gq_eff is None or Gp_eff is None:
            raise ValueError("ensure_transforms: generators_q/generators_p must be provided or attached beforehand")

        Gq_eff = np.asarray(Gq_eff, np.float32)
        Gp_eff = np.asarray(Gp_eff, np.float32)
        if Gq_eff.shape != (3, Kq, Kq):
            raise ValueError(f"ensure_transforms: generators_q shape mismatch: expected {(3, Kq, Kq)}, got {Gq_eff.shape}")
        if Gp_eff.shape != (3, Kp, Kp):
            raise ValueError(f"ensure_transforms: generators_p shape mismatch: expected {(3, Kp, Kp)}, got {Gp_eff.shape}")

        # Fetch or build+persist (single source of truth)
        Phi0, Phit0 = get_morphism_bases(ctx, a)  # (Kp,Kq), (Kq,Kp)




def ensure_observations(agents, ctx):
    """
    Ensure each agent has agent.observation_field (… , D_obs).
    Modes:
      - 'synthetic' (default): y = x_true (+ noise) or mu_q (+ noise)
      - 'p-as-y'            : y = Φ̃ mu_p transported into q-fiber (no noise)
    """
    from runtime_context import cfg_get
    
    mode   = str(cfg_get(ctx, "obs_mode", "synthetic"))
    s2_y   = float(cfg_get(ctx, "obs_sigma2_true", 1e-2))
    D_obs  = cfg_get(ctx, "obs_dim", None)
    rng    = getattr(ctx, "rng", None)
    if rng is None:
        rng = np.random.default_rng(0); ctx.rng = rng

    for a in agents:
        if getattr(a, "observation_field", None) is not None:
            continue

        K_q = int(a.mu_q_field.shape[-1])
        H, W = a.mask.shape[:2]
        D = int(D_obs) if (D_obs is not None) else K_q

        if mode == "synthetic":
            # source state: prefer ground-truth if you have it, else current mu_q
            x_src = getattr(a, "true_x_field", None)
            if x_src is None:
                x_src = a.mu_q_field
            # Project to D_obs if needed via a fixed proj on ctx
            if D != x_src.shape[-1]:
                P = getattr(ctx, "obs_proj", None)
                if P is None or P.shape != (D, x_src.shape[-1]):
                    P = rng.standard_normal((D, x_src.shape[-1])).astype(np.float32) / max(x_src.shape[-1], 1)
                    ctx.obs_proj = P
                y_clean = np.einsum("dk,...k->...d", P, x_src, optimize=True)
            else:
                y_clean = x_src.astype(np.float32)

            noise = rng.standard_normal((H, W, D)).astype(np.float32) * np.sqrt(max(s2_y, 1e-8))
            y = (y_clean + noise).astype(np.float32)

        elif mode == "p-as-y":
            # y = Φ̃ mu_p mapped into q-fiber; identity observation model
            # NOTE: this makes accuracy partly redundant with KL(q||Φ̃p).
            
            _, Phi_tilde = _phi_mats(ctx, a)
            mu_p_q = np.einsum("...dk,...k->...d", Phi_tilde, a.mu_p_field, optimize=True).astype(np.float32)
            if D != mu_p_q.shape[-1]:
                # Project to D via a fixed ctx.obs_proj
                P = getattr(ctx, "obs_proj", None)
                if P is None or P.shape != (D, mu_p_q.shape[-1]):
                    P = rng.standard_normal((D, mu_p_q.shape[-1])).astype(np.float32) / max(mu_p_q.shape[-1], 1)
                    ctx.obs_proj = P
                y = np.einsum("dk,...k->...d", P, mu_p_q, optimize=True).astype(np.float32)
            else:
                y = mu_p_q

        else:
            raise ValueError(f"Unknown obs_mode={mode!r}")

        a.observation_field = y


def preprocess_all_agents(agents, G_q=None, G_p=None, *, ctx: Optional[object] = None):
    if not agents:
        return
    for a in agents:
        preprocess_agent_fields(a, G_q=G_q, G_p=G_p, ctx=ctx)



# ---------------------------------------------------------------------
# Per-agent preprocessing
# ---------------------------------------------------------------------
def preprocess_agent_fields(agent, G_q=None, G_p=None, *, ctx: Optional[object] = None):
    
    from runtime_context import cfg_get
    
    eps      = float(getattr(config, "eps", 1e-8))
    strict   = bool(cfg_get(ctx, "sanitize_strict", True))
    step_tag = int(cfg_get(ctx, "step", getattr(ctx, "global_step", -1) or -1))

    # idempotency per step
    if getattr(agent, "_preprocessed_step", None) == step_tag and step_tag >= 0:
        return
   
    if not hasattr(agent, "mask") or agent.mask is None:
        H, W = agent.mu_q_field.shape[:2]
        agent.mask = np.ones((H, W), np.float32)

    # ---------------- SPD sanitize & inverses ----------------
    agent.sigma_q_field = sanitize_sigma(agent.sigma_q_field, strict=strict, eps=eps)
    agent.sigma_p_field = sanitize_sigma(agent.sigma_p_field, strict=strict, eps=eps)
    agent.sigma_q_inv   = safe_inv(agent.sigma_q_field, eps=eps)
    agent.sigma_p_inv   = safe_inv(agent.sigma_p_field, eps=eps)

    

    # ---------------- optional SPD assert ----------------
    if bool(getattr(config, "assert_spd_after_sanitize", False)):
        wq = np.linalg.eigvalsh(0.5 * (agent.sigma_q_field + np.swapaxes(agent.sigma_q_field, -1, -2)))
        wp = np.linalg.eigvalsh(0.5 * (agent.sigma_p_field + np.swapaxes(agent.sigma_p_field, -1, -2)))
        floor = float(getattr(config, "sigma_eig_floor", 1e-6))
        if (wq <= floor).any() or (wp <= floor).any():
            raise RuntimeError("Non-SPD Σ after sanitize.")

    agent._preprocessed_step = step_tag



def refresh_agents_light(agents, Gq, Gp, *, ctx=None):
    if not agents:
        return
    
    preprocess_all_agents(agents, G_q=Gq, G_p=Gp, ctx=ctx)
    H, W = np.asarray(agents[0].mask).shape[:2]
    standardize_all_masks_once(agents, (H, W))
















