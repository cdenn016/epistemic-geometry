# -*- coding: utf-8 -*-
"""
Numerical utilities (strict-SPD, cache-hub friendly, no legacy prints)

Author: c&c
"""
from __future__ import annotations
from typing import Optional
import numpy as np
from numpy.linalg import LinAlgError
import core.config as config



# -----------------------------------------------------------------------------
# SPD projections / inverses
# -----------------------------------------------------------------------------

def kl_gaussian(
    mu1: np.ndarray,
    S1: np.ndarray,
    mu2: np.ndarray,
    S2: np.ndarray,
    *,
    eps: float = 1e-6,
    allow_diag: bool = True,
    diag_is_stddev: bool = True,
    sanitize: bool = True,
    strict_numerics: bool = True,
    recover: str | None = None,
    return_terms: bool = False,
) -> np.ndarray | tuple[np.ndarray, dict]:
    mu1 = np.asarray(mu1, dtype=float)
    mu2 = np.asarray(mu2, dtype=float)
    S1 = np.asarray(S1)
    S2 = np.asarray(S2)
 
    S1 = sanitize_sigma(S1, eps=eps)  # ensure SPD (prefer float64)
    S2 = sanitize_sigma(S2, eps=eps)
  
    L2, logdet2 = _chol_logdet(S2)
    _,  logdet1 = _chol_logdet(S1)
   
    K = mu1.shape[-1]
    dmu = mu2 - mu1                                     # (..., K)

    # Solve L2 * y = dmu  -> y shape (..., K, 1)
    y = np.linalg.solve(L2, dmu[..., None])             # (..., K, 1)
    # Solve L2^T * z = y
    z = np.linalg.solve(np.swapaxes(L2, -1, -2), y)     # (..., K, 1)
    term_quad = np.sum(dmu * np.squeeze(z, axis=-1), axis=-1)  # (...,)

    # term_trace = tr(S2^{-1} S1) via two triangular solves (no explicit inverse)
    Y = np.linalg.solve(L2, S1)                         # (..., K, K)
    X = np.linalg.solve(np.swapaxes(L2, -1, -2), Y)     # (..., K, K)
    term_trace = np.trace(X, axis1=-2, axis2=-1)        # (...,)

    kl = 0.5 * (term_trace + term_quad - K + (logdet2 - logdet1))
    # Only shave tiny negatives from roundoff; do NOT clamp or nan_to_num here.
    kl = np.where(kl < 0, np.maximum(kl, -1e-12), kl)
 
    if not np.all(np.isfinite(kl)):
        raise FloatingPointError("Nonfinite KL encountered (NaN/Inf).")
    
    if return_terms:
        return kl, {"term_trace": term_trace, "term_quad": term_quad,
                    "logdet1": logdet1, "logdet2": logdet2}
    return kl


def push_gaussian(
    mu: np.ndarray,
    Sigma: np.ndarray,
    M: np.ndarray,
    *,
    eps: float = 1e-8,
    symmetrize: bool = True,
    sanitize: bool = True,
    approx: str = "exact",              # enforced
    near_identity_tau: Optional[float] = None,  # unused
    return_inv: bool = False,
):
    """Exact pushforward of N(mu, Σ) under y = Mx, with robust numerics."""
    # Preserve original dtypes for outputs
    out_mu_dtype    = np.asarray(mu).dtype
    out_sigma_dtype = np.asarray(Sigma).dtype

    # Promote to fp64 internally
    mu64    = np.asarray(mu,    dtype=np.float64)
    Sigma64 = np.asarray(Sigma, dtype=np.float64)
    M64     = np.asarray(M,     dtype=np.float64)

    # Shapes
    K_in = int(mu64.shape[-1])
    if Sigma64.shape[-2:] != (K_in, K_in):
        raise ValueError(f"[push_gaussian] Σ dims {Sigma64.shape[-2:]} incompatible with μ dim {K_in}")
    if M64.shape[-1] != K_in:
        raise ValueError(f"[push_gaussian] M last dim {M64.shape[-1]} != μ dim {K_in}")
    K_out = int(M64.shape[-2])
        
    Sigma64 = sanitize_sigma(Sigma64)

    # Scale-aware jitter on Σ_in
    if eps and eps > 0.0:
        diag_in = np.clip(np.diagonal(Sigma64, axis1=-2, axis2=-1), 0.0, None)
        scale_in = float(np.maximum(1.0, np.nanmean(diag_in)))
        Sigma64 = Sigma64 + max(eps, 1e-12) * scale_in * np.eye(K_in, dtype=Sigma64.dtype)

    # Exact push: μ' = M μ,  Σ' = M Σ Mᵀ
    mu_out64    = np.einsum("...ik,...k->...i", M64, mu64, optimize=True)
    Sigma_out64 = np.einsum("...ik,...kl,...jl->...ij", M64, Sigma64, M64, optimize=True)

    # Σ_out: optional symmetrize + sanitize
   
    Sigma_out64 = sanitize_sigma(Sigma_out64)

    # Scale-aware jitter on Σ_out
    if eps and eps > 0.0:
        diag_out = np.clip(np.diagonal(Sigma_out64, axis1=-2, axis2=-1), 0.0, None)
        scale_out = float(np.maximum(1.0, np.nanmean(diag_out)))
        Sigma_out64 = Sigma_out64 + max(eps, 1e-12) * scale_out * np.eye(K_out, dtype=Sigma_out64.dtype)

    if return_inv:
        Sigma_out_inv64 = safe_inv(Sigma_out64, eps=max(eps, 1e-12))
        return (
            mu_out64.astype(out_mu_dtype,    copy=False),
            Sigma_out64.astype(out_sigma_dtype, copy=False),
            Sigma_out_inv64.astype(out_sigma_dtype, copy=False),
        )

    return (
        mu_out64.astype(out_mu_dtype,    copy=False),
        Sigma_out64.astype(out_sigma_dtype, copy=False),
    )



def _chol_logdet(S):
    L = np.linalg.cholesky(S)  # (..., K, K)
    diag = np.diagonal(L, axis1=-2, axis2=-1)
    logdet = 2.0 * np.sum(np.log(np.clip(diag, 1e-300, None)), axis=-1)
    return L, logdet


def safe_inv(
    Sigma: np.ndarray,
    eps: float = 1e-10,
    max_eig: Optional[float] = None,
    debug: bool = False,
    *,
    strict_numerics: bool = True,     # NEW: fail fast on nonfinite / non-SPD
    recover: str | None = None,       # NEW: None | "nan" | "zero" (only if strict_numerics=False)
    method: str = "chol",             # "chol" | "eigh"
    use_float64: bool = True,         # promotes to float64 internally
) -> np.ndarray:
    """
    Batch-safe inverse of SPD matrices with optional eigenvalue clipping.
    Input shape: (..., K, K). Returns (..., K, K).

    Policies:
      - strict_numerics=True: raise on failure instead of masking.
      - recover: only used if strict_numerics=False.
      - method="chol": preferred for SPD; "eigh": when you need explicit clipping.
    """
    A = np.asarray(Sigma, dtype=(np.float64 if use_float64 else np.float32))
    # Symmetrize defensively
    A = 0.5 * (A + np.swapaxes(A, -1, -2))
    *batch, K, _ = A.shape

    if method == "chol":
        # Attempt Cholesky; add minimal jitter if needed (deterministic)
        jitter = 0.0
        I = np.eye(K, dtype=A.dtype)
        for attempt in range(3):
            try:
                L = np.linalg.cholesky(A + jitter * I)   # (..., K, K)
                # Compute inverse via solves: A^{-1} = (A^{-1} I)
                # cho_solve isn't batched in NumPy; emulate with two triangular solves
                # Solve L Y = I  and L^T X = Y  => X = A^{-1}
                # Broadcast identity over batch:
                I_b = np.broadcast_to(I, (*batch, K, K)).copy()
                Y = np.linalg.solve(L, I_b)
                X = np.linalg.solve(np.swapaxes(L, -1, -2), Y)
                invA = 0.5 * (X + np.swapaxes(X, -1, -2))  # symmetry guard
                
                return invA.astype(Sigma.dtype, copy=False)
            
            except Exception:
                # escalate jitter and retry
                print("cholskey fail in safe inv \n\n\n\n")
                jitter = max(eps, 10.0 * (jitter if jitter > 0 else eps))
                continue

        # Cholesky path failed; either raise or fall back
        if method != "eigh":
            raise np.linalg.LinAlgError("Cholesky failed after jitter attempts.")
 
    # ---- method == "eigh" (or chol fallback) ----
    flat = A.reshape(-1, K, K)
    
    evals, evecs = np.linalg.eigh(flat)  # (N, K), (N, K, K)

    # Clip spectrum explicitly (no silent masking)
    evals = np.clip(evals, a_min=eps, a_max=(float(max_eig) if max_eig is not None else None))
    inv_evals = 1.0 / evals

    # Recompose: A^{-1} = V diag(inv_evals) V^T
    # Multiply columns of V by inv_evals and right-multiply by V^T
    Vinv = evecs * inv_evals[..., None, :]            # scale columns
    invA = Vinv @ np.swapaxes(evecs, -1, -2)          # (N,K,K)
    invA = 0.5 * (invA + np.swapaxes(invA, -1, -2))   # symmetry guard
    
    return invA.reshape(*batch, K, K).astype(Sigma.dtype, copy=False)



def safe_batch_inverse(S: np.ndarray, name: str = "Σ", mask: Optional[np.ndarray] = None) -> np.ndarray:
    """
    Vectorized matrix inverse with optional mask and robust per-slice fallback.
    Inputs:
        S   : (..., K, K)
        mask: optional (...,) boolean; False → returns identity for that slice
    """
    S = np.asarray(S)
    *_, K, _ = S.shape
    eye = np.eye(K, dtype=S.dtype)
    X = 0.5 * (S + np.swapaxes(S, -1, -2))
    if mask is not None:
        mask = np.asarray(mask, dtype=bool)
        X = X.copy()
        X[~mask] = eye
    try:
        inv = np.linalg.inv(X)
        inv = 0.5 * (inv + np.swapaxes(inv, -1, -2))
    except LinAlgError:
        inv = np.empty_like(X)
        Xf = X.reshape(-1, K, K)
        out = inv.reshape(-1, K, K)
        for i, A in enumerate(Xf):
            try:
                Ai = np.linalg.inv(A)
            except LinAlgError:
                print("safe batch inv FAIL \n\n\n\n")
                Ai = eye
            out[i] = 0.5 * (Ai + Ai.T)
    return inv



def safe_omega_inv(M: np.ndarray, eps: float = 1e-10, debug: bool = False) -> np.ndarray:
    """
    Safely invert an (approximately) orthogonal matrix field.
    - If ||M^T M - I||_F <= tol, return M^T (fast path).
    - Else, re-orthogonalize via SVD and return Q^T with Q = argmin_Q ||M-Q||_F, Q orthogonal.
    Tolerance is adapted to dtype (float32 vs float64).
    """
    M = np.asarray(M)
    assert M.shape[-2] == M.shape[-1], "safe_omega_inv: matrix must be square"
    K = M.shape[-1]

    # Use float64 internally for stability
    M64 = M.astype(np.float64, copy=False)
    MT = np.swapaxes(M64, -1, -2)
    I = np.eye(K, dtype=np.float64)

    # Deviation from orthogonality, per batch
    dev = MT @ M64 - I
    dev_fro = np.linalg.norm(dev.reshape(-1, K * K), axis=1)

    # Adaptive tolerance: at least eps, but also ~50 * machine epsilon of input dtype
    dtype_eps = np.finfo(M.dtype).eps if np.issubdtype(M.dtype, np.floating) else 0.0
    tol = max(float(eps), 50.0 * float(dtype_eps))  # ≈5e-6 for float32, 1e-14 for float64

    if np.all(dev_fro <= tol):
        return np.swapaxes(M, -1, -2)  # fast path, keep original dtype

    # Slow but robust path: SVD re-orthogonalization
    flat = M64.reshape(-1, K, K)
    out = np.empty_like(flat)
    for i, A in enumerate(flat):
        try:
            U, S, Vt = np.linalg.svd(A, full_matrices=False)
            Q = U @ Vt
            out[i] = Q.T
        except Exception:
            # last resort: numeric inverse transpose
            print("safe omega inv SVD FAIL \n\n\n\n")
            out[i] = np.linalg.inv(A).T 
            
    return out.reshape(M.shape).astype(M.dtype, copy=False)



# -----------------------------------------------------------------------------
# Sigma sanitation (vectorized)
# -----------------------------------------------------------------------------

def sanitize_sigma(
    Sigma: np.ndarray,
    debug: bool = True,
    strict: bool = True,                 # kept for API compatibility (always projects)
    eig_floor: Optional[float] = None,
    cond_cap: Optional[float] = None,
    eig_cap: Optional[float] = None,
    trace_target: Optional[float] = None,
    eps: float = None,
) -> np.ndarray:
    """
    Symmetrize, scrub NaN/Inf, and project to SPD via eigen clipping.

    Args
    ----
    Sigma : (..., K, K) array (float32/float64)
    eig_floor : minimum eigenvalue after projection (default: config.sigma_eig_floor or 1e-6)
    cond_cap  : optional cap on condition number (λ_max <= cond_cap * λ_min)
    eig_cap   : optional absolute cap on eigenvalues
    trace_target : optional trace normalization target
    eps : reserved (unused); kept for API compatibility

    Returns
    -------
    (..., K, K) SPD matrix with same dtype as Sigma.
    """
    
    in_dtype = Sigma.dtype
    S = np.asarray(Sigma, dtype=np.float64)  # work in fp64 for eig, cast back at end

   
    eig_floor = float(eig_floor if eig_floor is not None else getattr(config, "sigma_eig_floor", 1e-6))
    cond_cap  = None if cond_cap is None else float(cond_cap)
    eig_cap   = None if eig_cap   is None else float(eig_cap)
    trace_target = None if trace_target is None else float(trace_target)

    # --- symmetrize ---
    S = 0.5 * (S + np.swapaxes(S, -1, -2))

    # --- scrub NaN/Inf (replace whole bad matrices with floor*I) ---
    bad = ~np.isfinite(S).all(axis=(-2, -1))
    if np.any(bad):
        print(f"[sanitize_sigma] {int(bad.sum())} matrices had NaN/Inf; replaced with floor*I")
        K = S.shape[-1]
        eye = np.eye(K, dtype=S.dtype)
        S = S.copy()
        S[bad] = eig_floor * eye

    # --- eigen projection (batched) ---
    # np.linalg.eigh supports batched inputs in NumPy
    w, V = np.linalg.eigh(S)                  # (..., K), (..., K, K)

    # floor
    w = np.maximum(w, eig_floor)

    # optional condition-number cap: λ_max <= cond_cap * λ_min
    if cond_cap is not None:
        lam_min = np.min(w, axis=-1, keepdims=True)
        w = np.minimum(w, lam_min * cond_cap)

    # optional absolute cap
    if eig_cap is not None:
        w = np.minimum(w, eig_cap)

    # reconstruct: V diag(w) V^T
    S_proj = (V * w[..., None, :]) @ np.swapaxes(V, -1, -2)

    # optional trace normalization
    if trace_target is not None:
        tr = np.trace(S_proj, axis1=-2, axis2=-1)[..., None, None]
        S_proj = S_proj * (trace_target / np.clip(tr, 1e-12, None))

    # final symmetrize + cast back to input dtype
    S_proj = 0.5 * (S_proj + np.swapaxes(S_proj, -1, -2))
        # right after S_proj is built in sanitize_sigma
    min_eig = np.min(np.linalg.eigvalsh(S_proj))
    if not np.isfinite(min_eig) or min_eig <= 0:
        raise FloatingPointError(f"sanitize_sigma: non-SPD result (min eig={min_eig})")

    return S_proj.astype(in_dtype, copy=False)






