# -*- coding: utf-8 -*-
"""
Created on Sun Jul  6 15:59:57 2025

@author: chris and christine
"""

# energy_logger.py

import os
import numpy as np
import pickle

from generalized_omega import build_inter_agent_omega, transport_covariance_batch
from generalized_math_utils import masked_norm
import config


def kl_divergence(mu1, sigma1, mu2, sigma2, eps=1e-8):
    """
    KL divergence D_KL[N(mu1, sigma1) || N(mu2, sigma2)]
    using the closed-form expression for multivariate Gaussians.
    """
    K = mu1.shape[-1]
    eye = np.eye(K)

    sigma2_inv = np.linalg.solve(sigma2 + eps * eye, eye)

    diff = mu2 - mu1
    trace_term = np.trace(sigma2_inv @ sigma1)
    quad_term = diff.T @ sigma2_inv @ diff
    logdet_term = np.log(np.linalg.det(sigma2 + eps * eye)) - np.log(np.linalg.det(sigma1 + eps * eye))

    return 0.5 * (trace_term + quad_term - K + logdet_term)


def compute_total_energy(agents, generators, params):
    """
    Compute total system energy using:
        α · KL(q || p) + β · KL(q || Ω q) + βm · KL(p || Ω̃ p)
    """

    alpha = params.get("alpha", config.alpha)
    beta  = params.get("beta", config.beta)
    beta_m = params.get("model_align_weight", config.model_align_weight)
    eps = params.get("eps", config.eps)
    overlap_eps = params.get("overlap_eps", config.support_cutoff_eps)

    total_e_self = 0.0
    total_e_align = 0.0
    total_e_model = 0.0

    for i, A in enumerate(agents):
        mask_i = A.mask > overlap_eps
        if not np.any(mask_i):
            continue

        # Self energy KL(q || p)
        for coord in zip(*np.where(mask_i)):
            μq, Σq = A.mu_q_field[coord], A.sigma_q_field[coord]
            μp, Σp = A.mu_p_field[coord], A.sigma_p_field[coord]
            total_e_self += alpha * kl_divergence(μq, Σq, μp, Σp, eps=eps)

        # Belief alignment KL(q_i || Ω q_j)
        for nb in A.neighbors:
            j = nb["id"]
            B = agents[j]
            mask_j = B.mask > overlap_eps
            overlap = mask_i & mask_j
            if not np.any(overlap):
                continue

            coords = zip(*np.where(overlap))
            for coord in coords:
                Ω_ij = build_inter_agent_omega(
                    phi_i=A.phi[coord][None],
                    phi_j=B.phi[coord][None],
                    generators=generators,
                    config=params
            )[0]


                μj, Σj = B.mu_q_field[coord], B.sigma_q_field[coord]
                μj_t = Ω_ij @ μj
                Σj_t = transport_covariance_batch(Σj[None, :, :], Ω_ij[None])[0]

                μi, Σi = A.mu_q_field[coord], A.sigma_q_field[coord]
                total_e_align += beta * kl_divergence(μi, Σi, μj_t, Σj_t, eps=eps)

            # Model alignment KL(p_i || Ω̃ p_j)
            if beta_m > 0:
                for coord in coords:
                    Ω̃_ij = build_inter_agent_omega(
                            phi_i=A.phi_model,
                            phi_j=B.phi_model,
                            generators=generators,
                            config=params
                            )[0]

                    μj, Σj = B.mu_p_field[coord], B.sigma_p_field[coord]
                    μj_t = Ω̃_ij @ μj
                    Σj_t = transport_covariance_batch(Σj[None, :, :], Ω̃_ij[None])[0]

                    μi, Σi = A.mu_p_field[coord], A.sigma_p_field[coord]
                    total_e_model += beta_m * kl_divergence(μi, Σi, μj_t, Σj_t, eps=eps)

    return {
        "E_self": total_e_self,
        "E_align": total_e_align,
        "E_model_align": total_e_model,
        "E_total": total_e_self + total_e_align + total_e_model
    }


def log_energy(agents, generators, step, outdir="energy_logs", params=None):
    """
    Compute and save energy at the current step.
    """
    os.makedirs(outdir, exist_ok=True)
    params = params or {}

    stats = compute_total_energy(agents, generators, params)
    stats["step"] = step

    path = os.path.join(outdir, "energy_log.pkl")
    if os.path.exists(path):
        with open(path, "rb") as f:
            log = pickle.load(f)
    else:
        log = []

    log.append(stats)
    with open(path, "wb") as f:
        pickle.dump(log, f)

    print(f"[LOG] Energy step {step}: {stats}")


def plot_energy_log(path="energy_logs/energy_log.pkl", savepath=None):
    import matplotlib.pyplot as plt
    with open(path, "rb") as f:
        log = pickle.load(f)

    steps = [entry["step"] for entry in log]
    E_self = [entry["E_self"] for entry in log]
    E_align = [entry["E_align"] for entry in log]
    E_model = [entry["E_model_align"] for entry in log]
    E_total = [entry["E_total"] for entry in log]

    plt.figure(figsize=(10, 6))
    plt.plot(steps, E_total, label="Total Energy", linewidth=2)
    plt.plot(steps, E_self, label="Self Energy (KL[q‖p])", linestyle="--")
    plt.plot(steps, E_align, label="Alignment Energy (KL[q‖Ωq])", linestyle="--")
    plt.plot(steps, E_model, label="Model Align (KL[p‖Ω̃p])", linestyle="--")
    plt.xlabel("Step")
    plt.ylabel("Energy")
    plt.title("System Energy Over Time")
    plt.legend()
    plt.grid(True)
    if savepath:
        plt.savefig(savepath, dpi=150)
    else:
        plt.show()

# plot_energy_log.py

import pickle
import matplotlib.pyplot as plt
import os
import sys

# Optional: accept path from CLI
if len(sys.argv) > 1:
    path = sys.argv[1]
else:
    path = "energy_logs/energy_log.pkl"  # Default

if not os.path.exists(path):
    raise FileNotFoundError(f"Energy log file not found at: {path}")

# Load energy log
with open(path, "rb") as f:
    log = pickle.load(f)

# Extract data
steps = [entry["step"] for entry in log]
E_total = [entry["E_total"] for entry in log]
E_self = [entry.get("E_self", 0) for entry in log]
E_align = [entry.get("E_align", 0) for entry in log]
E_model = [entry.get("E_model_align", 0) for entry in log]

# Plot
plt.figure(figsize=(10, 6))
plt.plot(steps, E_total, label="Total Energy", linewidth=2, color="black")
plt.plot(steps, E_self, label="Self (KL[q‖p])", linestyle="--", color="tab:blue")
plt.plot(steps, E_align, label="Align (KL[q‖Ωq])", linestyle="--", color="tab:orange")
plt.plot(steps, E_model, label="Model Align (KL[p‖Ω̃p])", linestyle="--", color="tab:green")

plt.xlabel("Step")
plt.ylabel("Energy")
plt.title("Epistemic Energy Over Time")
plt.grid(True)
plt.legend()
plt.tight_layout()
plt.show()
