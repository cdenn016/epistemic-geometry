import numpy as np
from scipy.ndimage import laplace



def laplacian_field(field):
    """Compute component‐wise Laplacian over the last (fiber) axis."""
    return np.stack([laplace(field[..., i]) for i in range(field.shape[-1])], axis=-1)

def masked_norm(field, mask, ord=2):
    """
    Compute the mean over support of ‖field(x)‖ᵒʳᵈ, i.e.
      ∑ₓ ‖field(x)‖ * mask(x)  /  (∑ₓ mask(x))
    """
    norm_vals = np.linalg.norm(field, ord=ord, axis=-1)
    return np.sum(norm_vals * mask) / (np.sum(mask) + 1e-9)

def even_range(min_val, max_val, num_samples):
    """
    Return a list of `num_samples` evenly spaced even integers
    between `min_val` and `max_val`, inclusive if possible.
    """
    # Ensure min and max are even
    if min_val % 2 != 0:
        min_val += 1
    if max_val % 2 != 0:
        max_val -= 1

    # Generate linearly spaced values and round to nearest even
    lin = np.linspace(min_val, max_val, num_samples)
    even_vals = [int(round(x / 2) * 2) for x in lin]

    # Remove duplicates and return sorted list
    return sorted(set(even_vals))

import numpy as np

def safe_log(x, eps: float = 1e-12):
    """
    Numerically stable natural log.

    Parameters
    ----------
    x : float | np.ndarray
        Input value(s). Can be scalar or array-like.
    eps : float, optional
        Values below `eps` are clipped up to `eps` before taking log,
        preventing -inf.  Default is 1e-12.

    Returns
    -------
    np.ndarray | float
        np.log( max(x, eps) ), broadcast over x.
    """
    return np.log(np.clip(x, eps, None))
import warnings

# powerlaw_utils.py  – lightweight fallback
import numpy as np
import matplotlib.pyplot as plt
import config

def zipf_frequencies_from_q(q, mask=None):
    """Return normalised frequencies (shape K,) from q field."""
    if mask is not None:
        mask = (mask > config.support_cutoff_eps)  # ← convert to boolean
        counts = q[mask]
    else:
        counts = q.reshape(-1, q.shape[-1])
    return counts.sum(axis=0) / counts.sum()


from scipy.stats import linregress
import numpy as np
import warnings

def zipf_slope(freqs, rmin=1, rmax=None):
    freqs = np.asarray(freqs, dtype=float).ravel()
    freqs = -np.sort(-freqs)        # sort descending
    freqs = freqs[freqs > 0]

    if len(freqs) < 2:
        return 0.0, 0.0

    ranks = np.arange(1, len(freqs) + 1)
    if rmax is None or rmax > len(freqs):
        rmax = len(freqs)

    x = np.log(ranks[rmin-1:rmax])
    y = np.log(freqs[rmin-1:rmax])

    slope, intercept, r, *_ = linregress(x, y)
    return slope, r**2


def rank_frequency_plot(freqs, ax=None, **kwargs):
    """
    Plot a rank-frequency curve. Accepts optional matplotlib kwargs.
    """
    if ax is None:
        ax = plt.gca()
    ranks = np.arange(1, len(freqs) + 1)
    ax.loglog(ranks, freqs, marker='o', linestyle='', **kwargs)
    ax.set_xlabel("Rank")
    ax.set_ylabel("Frequency")
    return ax

import numpy as np

def fit_moments(q: np.ndarray, mask: np.ndarray):
    """
    Compute the per-pixel mean and full covariance matrices
    for a multivariate distribution q(c) over K-dimensional fibers.

    Parameters:
      q:     ndarray of shape (H, W, K) — belief distribution at each pixel
      mask:  ndarray of shape (H, W) — boolean or float mask for agent support

    Returns:
      mu:    ndarray of shape (H, W, K) — mean vector per spatial point
      cov:   ndarray of shape (H, W, K, K) — covariance matrix per spatial point
    """
    H, W, K = q.shape
    x = np.eye(K, dtype=q.dtype)          # (K, K)
    x_exp = x[None, None, :, :]           # (1, 1, K, K)
    q_exp = q[..., :, None]               # (H, W, K, 1)

    # μ = E[x]
    mu = np.sum(q_exp * x_exp, axis=2)    # (H, W, K)

    # x_k - μ for each k: (H, W, K, K)
    diff = x_exp - mu[:, :, None, :]      # (H, W, K, K)

    # Outer product: (x_k - μ)(x_k - μ)^T → (H, W, K, K, K)
    outer = diff[..., :, None] * diff[..., None, :]  # (H, W, K, K, K)

    # Weight by q_k and sum over k
    q_reshaped = q[..., :, None, None]    # (H, W, K, 1, 1)
    cov = np.sum(q_reshaped * outer, axis=2)  # (H, W, K, K)

    mu[~mask] = 0.0
    cov[~mask] = 0.0

    return mu, cov
