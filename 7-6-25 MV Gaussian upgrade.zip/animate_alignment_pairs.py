import os
import re
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation

# === CONFIGURATION ===
FIELD_DUMPS_DIR = os.getenv('FIELD_DUMPS_DIR', 'checkpoints/field_dumps')
OUTPUT_DIR      = os.getenv('OUTPUT_DIR', 'Animations')

FPS             = 10
INTERVAL        = 100
CMAP            = 'viridis'


os.makedirs(OUTPUT_DIR, exist_ok=True)
_PATTERN = re.compile(r'step(\d+)_pair_(\d+)_(\d+)\.npz')


# Auto-detect all unique agent pairs from field dump filenames
PAIRS = sorted(set(
    tuple(map(int, _PATTERN.match(f).groups()[1:3]))
    for f in os.listdir(FIELD_DUMPS_DIR)
    if _PATTERN.match(f)
))


def load_pair_dumps(pair):
    i, j = pair
    files = sorted(
        f for f in os.listdir(FIELD_DUMPS_DIR)
        if _PATTERN.match(f) and tuple(map(int, _PATTERN.match(f).groups()[1:3])) == (i, j)
    )
    frames = []

    def safe_reduce_kl(arr, mask):
        """Reduce fiber-dim KL to scalar and apply mask safely."""
        reduced = np.linalg.norm(arr, axis=-1) if arr.ndim == 3 else arr
        mask_2d = mask[..., 0] if mask.ndim == 3 else mask
        out = reduced * mask_2d
        out[np.isnan(out)] = 0
        out[np.isinf(out)] = 0
        return out

    for fname in files:
        step, _, _ = map(int, _PATTERN.match(fname).groups())
        data = np.load(os.path.join(FIELD_DUMPS_DIR, fname))
        mask = data['mask_i'].astype(bool)[..., None, None]  # Full-covariance masking

        # Load belief/model alignment
        belief = data['belief_alignment']
        model  = data['model_alignment']

        # μ and σ fields, masked and reduced
        mu_q    = data['mu_q'] * mask
        sigma_q = data['sigma_q'] * mask
        mu_p    = data['mu_p'] * mask
        sigma_p = data['sigma_p'] * mask

        mu_q_norm    = np.linalg.norm(mu_q, axis=-1) if mu_q.ndim == 3 else np.zeros(mu_q.shape[:2])
        sigma_q_norm = np.linalg.norm(sigma_q.reshape(*sigma_q.shape[:2], -1), axis=-1)
        mu_p_norm    = np.linalg.norm(mu_p, axis=-1) if mu_p.ndim == 3 else np.zeros(mu_p.shape[:2])
        sigma_p_norm = np.linalg.norm(sigma_p.reshape(*sigma_p.shape[:2], -1), axis=-1)

        # KL terms, if present — using mask_i key
        kl_self     = safe_reduce_kl(data['kl_self'], data['mask_i'])     if 'kl_self'     in data else np.zeros_like(mu_q_norm)
        kl_feedback = safe_reduce_kl(data['kl_feedback'], data['mask_i']) if 'kl_feedback' in data else np.zeros_like(mu_q_norm)

        frames.append((
            step, belief, model,
            mu_q_norm, sigma_q_norm,
            mu_p_norm, sigma_p_norm,
            kl_self, kl_feedback
        ))
    return frames






def make_two_panel_gif(frames, fields, title_fmt, outname):
    """
    fields: tuple of two indices in the frame tuple
    title_fmt: tuple of two strings with {step}
    outname: filename prefix
    """
    fig, axes = plt.subplots(1, 2, figsize=(8, 4))
    ims, cbs = [], []

    # === Compute global vmin/vmax for each field ===
    def get_global_minmax(frames, idx):
        values = [f[idx][f[idx] != 0] for f in frames if idx < len(f) and np.any(f[idx] != 0)]
        flat = np.concatenate(values) if values else np.array([0])
        return flat.min(), flat.max()

    vmin_0, vmax_0 = get_global_minmax(frames, fields[0])
    vmin_1, vmax_1 = get_global_minmax(frames, fields[1])

    vmins = [vmin_0, vmin_1]
    vmaxs = [vmax_0, vmax_1]

    # === Initialize imshow and colorbars ===
    for i, ax in enumerate(axes):
        init_data = np.zeros_like(frames[0][fields[i]])
        im = ax.imshow(init_data, cmap=CMAP, animated=True,
                       vmin=vmins[i], vmax=vmaxs[i])
        ax.axis('off')
        cb = fig.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
        ims.append(im)
        cbs.append(cb)

    plt.tight_layout()

    def update(idx):
        step = frames[idx][0]
        for i, (im, f_idx, ax, fmt) in enumerate(zip(ims, fields, axes, title_fmt)):
            data = np.ma.masked_where(frames[idx][f_idx] == 0, frames[idx][f_idx])
            im.set_data(data)
            ax.set_title(fmt.format(step=step))
        return ims

    ani = animation.FuncAnimation(
        fig, update,
        frames=len(frames),
        interval=INTERVAL,
        blit=False
    )

    path = os.path.join(OUTPUT_DIR, f'{outname}.gif')
    ani.save(path, writer=animation.PillowWriter(fps=FPS))
    plt.close(fig)
    print(f'Saved {outname} → {path}')


def make_single_panel_gif(frames, field_idx, title_fmt, outname):
    """
    Animate a single scalar field (e.g. KL(q‖p)) over time.

    Parameters:
    - frames: list of tuples with (step, ..., fieldN)
    - field_idx: index of the field in each frame tuple
    - title_fmt: a string with {step} for the frame title
    - outname: filename prefix for the .gif
    """
    # === Compute global vmin/vmax excluding zero/masked values ===
    def get_global_minmax(frames, idx):
        if any(idx >= len(f) for f in frames):
            raise IndexError(f"[ERROR] Field index {idx} is out of range for frame size {len(frames[0])}")
        values = [f[idx][f[idx] != 0] for f in frames if np.any(f[idx] != 0)]
        flat = np.concatenate(values) if values else np.array([0])
        return flat.min(), flat.max()


    vmin, vmax = get_global_minmax(frames, field_idx)

    fig, ax = plt.subplots(figsize=(4, 4))
    im = ax.imshow(np.zeros_like(frames[0][field_idx]),
                   cmap=CMAP, vmin=vmin, vmax=vmax, animated=True)
    ax.axis('off')
    cb = fig.colorbar(im, ax=ax, fraction=0.046, pad=0.04)

    def update(idx):
        step = frames[idx][0]
        field = np.ma.masked_where(frames[idx][field_idx] == 0, frames[idx][field_idx])
        im.set_data(field)
        ax.set_title(title_fmt.format(step=step))
        return [im]

    ani = animation.FuncAnimation(
        fig, update,
        frames=len(frames),
        interval=INTERVAL,
        blit=False
    )

    path = os.path.join(OUTPUT_DIR, f"{outname}.gif")
    ani.save(path, writer=animation.PillowWriter(fps=FPS))
    plt.close(fig)
    print(f"[✓] Saved single-field animation: {outname} → {path}")


if __name__ == '__main__':
    for pair in PAIRS:
        frames = load_pair_dumps(pair)
        if not frames:
            print(f"No dumps for pair {pair}")
            continue

        # 1) alignment
        make_two_panel_gif(
            frames,
            fields=(1, 2),
            title_fmt=(f'Belief KL {pair[0]}→{pair[1]} @ step {{step}}',
                       f'Model  KL {pair[0]}→{pair[1]} @ step {{step}}'),
            outname=f'alignment_{pair[0]}_{pair[1]}'
        )

        # 2) mu
        make_two_panel_gif(
            frames,
            fields=(3, 5),
            title_fmt=(f'µ_q ({pair[0]}) @ step {{step}}',
                       f'µ_p ({pair[0]}) @ step {{step}}'),
            outname=f'mu_{pair[0]}_{pair[1]}'
        )

        # 3) sigma
        make_two_panel_gif(
            frames,
            fields=(4, 6),
            title_fmt=(f'σ_q ({pair[0]}) @ step {{step}}',
                       f'σ_p ({pair[0]}) @ step {{step}}'),
            outname=f'sigma_{pair[0]}_{pair[1]}'
        )

        agent_id = pair[0]

        make_single_panel_gif(
            frames,
            field_idx=7,
            title_fmt=f'Self KL q‖p (agent {agent_id}) @ step {{step}}',
            outname=f'self_kl_agent{agent_id}'
        )

        make_single_panel_gif(
            frames,
            field_idx=8,
            title_fmt=f'Feedback KL p‖q (agent {agent_id}) @ step {{step}}',
            outname=f'feedback_kl_agent{agent_id}'
        )
