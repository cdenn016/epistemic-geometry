import numpy as np
import config


from get_generators import get_generators

from generalized_omega import batch_apply_omega, repair_if_forgotten_batch
from generalized_math_utils import laplacian_field


from natural_gradient_utils import apply_natural_gradient

from natural_gradient_utils import apply_natural_gradient_batch

def compute_self_gradient(agent_i, params):
    """
    Compute natural gradient ∇_μ and ∇_Σ for KL(q || p),
    using Fisher metric over masked region.
    """
    alpha = params.get("alpha", config.alpha)
    support_eps = params.get("support_cutoff_eps", config.support_cutoff_eps)

    mask = agent_i.mask > support_eps
    if not np.any(mask) or alpha <= 0:
        return (
            np.zeros_like(agent_i.mu_q_field),
            np.zeros_like(agent_i.sigma_q_field),
        )

    mu_q     = agent_i.mu_q_field        # (H, W, K)
    sigma_q  = agent_i.sigma_q_field     # (H, W, K, K)
    mu_p     = agent_i.mu_p_field
    sigma_p  = agent_i.sigma_p_field

    diff_mu     = mu_q - mu_p                      # (H, W, K)
    diff_sigma  = 0.5 * (sigma_p - sigma_q)        # (H, W, K, K)

    # Apply Fisher preconditioner in batch
    delta_mu, delta_sigma = apply_natural_gradient_batch(
        mu_field=mu_q,
        sigma_field=sigma_q,
        grad_mu_field=diff_mu,
        grad_sigma_field=diff_sigma,
    )

    # Zero out gradients outside support
    delta_mu[~mask] = 0
    delta_sigma_mask = np.broadcast_to(mask[..., None, None], delta_sigma.shape)
    delta_sigma[~delta_sigma_mask] = 0

    return alpha * delta_mu, alpha * delta_sigma



from natural_gradient_utils import apply_natural_gradient

def compute_alignment_gradient(agent_i, agents, params, field_type="belief"):
    """
    Compute natural gradient ∇_μ and ∇_Σ for:
        KL(q_i || Ω q_j)    if field_type = "belief"
        KL(p_i || Ω̃ p_j)   if field_type = "model"

    Uses Fisher geometry (natural gradient) over overlap regions.

    Args:
        agent_i: focal agent
        agents: list of all agents
        params: dict of config parameters
        field_type: "belief" or "model"

    Returns:
        grad_mu:    (H, W, K)     ∇_μ field (natural gradient)
        grad_sigma: (H, W, K, K)  ∇_Σ field (natural gradient)
    """
    if field_type == "belief":
        β = params.get("beta", config.beta)
        mu_i_field     = agent_i.mu_q_field
        sigma_i_field  = agent_i.sigma_q_field
        Omega_i        = agent_i.Omega
        mu_j_name      = "mu_q_field"
        sigma_j_name   = "sigma_q_field"
        Omega_inv_name = "Omega_inv"
    elif field_type == "model":
        β = params.get("model_align_weight", config.model_align_weight)
        mu_i_field     = agent_i.mu_p_field
        sigma_i_field  = agent_i.sigma_p_field
        Omega_i        = agent_i.Omega_model
        mu_j_name      = "mu_p_field"
        sigma_j_name   = "sigma_p_field"
        Omega_inv_name = "Omega_model_inv"
    else:
        raise ValueError(f"Invalid field_type: {field_type}")

    if β <= 0:
        return np.zeros_like(mu_i_field), np.zeros_like(sigma_i_field)

    eps = params.get("overlap_eps", config.support_cutoff_eps)
    mask_i = agent_i.mask > eps
    if not np.any(mask_i):
        return np.zeros_like(mu_i_field), np.zeros_like(sigma_i_field)

    grad_mu = np.zeros_like(mu_i_field)
    grad_sigma = np.zeros_like(sigma_i_field)

    for nb in agent_i.neighbors:
        agent_j = agents[nb["id"]]
        mask_j = agent_j.mask > eps
        overlap = mask_i & mask_j
        if not np.any(overlap):
            continue

        μi  = mu_i_field[overlap]
        Σi  = sigma_i_field[overlap]
        μj  = getattr(agent_j, mu_j_name)[overlap]
        Σj  = getattr(agent_j, sigma_j_name)[overlap]

        Ωi      = Omega_i[overlap]
        Ωj_inv  = getattr(agent_j, Omega_inv_name)[overlap]
        Ω       = np.einsum("mij,mjk->mik", Ωi, Ωj_inv)

        μj_rot, Σj_rot = batch_apply_omega(μj, Σj, Ω)

        # KL(q_i || Ω q_j) gradients (preconditioned after)
        dμ  = μi - μj_rot
        dΣ  = 0.5 * (Σj_rot - Σi)

        delta_mu, delta_sigma = apply_natural_gradient_batch(
            mu_field=μi,
            sigma_field=Σi,
            grad_mu_field=dμ,
            grad_sigma_field=dΣ,
        )

        # Scatter back to full (H, W) field
        coords = np.argwhere(overlap)
        for n in range(len(coords)):
            i_, j_ = coords[n]
            grad_mu[i_, j_]    += β * delta_mu[n]
            grad_sigma[i_, j_] += β * delta_sigma[n]

    return grad_mu, grad_sigma


def compute_beliefs_gradient(agent_i, agents, params):
    """
    Compute total Fisher-preconditioned gradients ∇_μ and ∇_Σ for belief parameters q_i:
    
        ∇μ_total    = ∇μ_self + ∇μ_align
        ∇Σ_total    = ∇Σ_self + ∇Σ_align

    This corresponds to minimizing:
        F = α · D_KL(q_i || p_i) + β · D_KL(q_i || Ω_{ij} q_j)

    Args:
        agent_i: Agent whose gradient we compute
        agents:  List of all agents
        params:  Dictionary of config parameters

    Returns:
        grad_mu_total:    (H, W, K) Fisher-natural gradient on μ
        grad_sigma_total: (H, W, K, K) Fisher-natural gradient on Σ
    """
    grad_mu_self, grad_sigma_self   = compute_self_gradient(agent_i, params)
    grad_mu_align, grad_sigma_align = compute_alignment_gradient(agent_i, agents, params, field_type="belief")

    grad_mu_total    = grad_mu_self + grad_mu_align
    grad_sigma_total = grad_sigma_self + grad_sigma_align

    return grad_mu_total, grad_sigma_total



from natural_gradient_utils import apply_natural_gradient_batch  # Make sure this is imported

def compute_models_gradient(agent_i, agents, params):
    """
    Compute natural gradients ∇μ_p and ∇Σ_p for:
        1. Self energy:     KL(q || p)
        2. Feedback term:   KL(p || q)
        3. Alignment:       KL(p || Ω̃ p_j)
    All terms are natural gradients using Fisher geometry.
    """
    if getattr(config, "identical_models", False):
        return (
            np.zeros_like(agent_i.mu_p_field),
            np.zeros_like(agent_i.sigma_p_field),
        )

    α      = params.get("alpha", config.alpha)
    mf     = params.get("model_feedback_weight", config.model_feedback_weight)
    βm     = params.get("model_align_weight", config.model_align_weight)
    cutoff = params.get("support_cutoff_eps", config.support_cutoff_eps)

    mask = agent_i.mask > cutoff
    if not np.any(mask):
        return (
            np.zeros_like(agent_i.mu_p_field),
            np.zeros_like(agent_i.sigma_p_field),
        )

    μq = agent_i.mu_q_field
    Σq = agent_i.sigma_q_field
    μp = agent_i.mu_p_field
    Σp = agent_i.sigma_p_field

    grad_mu    = np.zeros_like(μp)
    grad_sigma = np.zeros_like(Σp)

    # === Self gradient: KL(q || p) ===
    if α > 0:
        dμ_self, dΣ_self = apply_natural_gradient_batch(
            mu_field=μp,
            sigma_field=Σp,
            grad_mu_field=μp - μq,                   # reverse!
            grad_sigma_field=0.5 * (Σp - Σq),        # reverse!
        )
        grad_mu    += α * dμ_self
        grad_sigma += α * dΣ_self

    # === Feedback gradient: KL(p || q) ===
    if mf > 0:
        dμ_fb, dΣ_fb = apply_natural_gradient_batch(
            mu_field=μp,
            sigma_field=Σp,
            grad_mu_field=μp - μq,
            grad_sigma_field=0.5 * (Σq - Σp),
        )
        grad_mu    += mf * dμ_fb
        grad_sigma += mf * dΣ_fb

    # === Alignment gradient: KL(p_i || Ω̃ p_j) ===
    if βm > 0:
        dμ_align, dΣ_align = compute_alignment_gradient(
            agent_i, agents, params, field_type="model"
        )
        grad_mu    += dμ_align
        grad_sigma += dΣ_align

    # Zero out outside support
    grad_mu[~mask] = 0
    grad_sigma[~np.broadcast_to(mask[..., None, None], grad_sigma.shape)] = 0

    return grad_mu, grad_sigma



from natural_gradient_utils import apply_lie_natural_gradient  # ← Add this at the top

def compute_phi_alignment_gradient(agent_i, agents: list, params: dict) -> np.ndarray:
    """
    Compute ∇_φ alignment from D_KL(q_i || Ω_ij q_j), using MVG natural gradient.
    """
    β  = params.get("beta", config.beta)
    γ  = params.get("gamma", config.gamma)
    gw = params.get("gauge_weight", config.gauge_weight)
    κ  = params.get("phi_phi_tilde_coupling", config.phi_phi_tilde_coupling)
    overlap_eps = params.get("overlap_eps", config.support_cutoff_eps)
    grad_clip_threshold = getattr(config, "phi_grad_clip_threshold", 1e4)

    if β <= 0:
        return np.zeros_like(agent_i.phi)

    phi_i = agent_i.phi
    phi_m = agent_i.phi_model
    mask_i = agent_i.mask > overlap_eps
    if not np.any(mask_i):
        return np.zeros_like(phi_i)

    shape = agent_i.mu_q_field.shape
    N, K = np.prod(shape[:-1]), shape[-1]
    flat_grad = np.zeros((N, config.lie_dim), dtype=phi_i.dtype)

    mu_i = agent_i.mu_q_field.reshape(N, K)
    Si   = agent_i.sigma_q_field.reshape(N, K, K)
    exp_phi_i     = agent_i._exp_phi.reshape(N, K, K)
    exp_neg_phi_i = agent_i._exp_neg_phi.reshape(N, K, K)
    Gs = get_generators(config.group_name, K)  # (d, K, K)

    for nb in agent_i.neighbors:
        agent_j = agents[nb["id"]]
        mask_j = agent_j.mask > overlap_eps
        overlap = mask_i & mask_j
        idxs = np.flatnonzero(overlap)
        if len(idxs) == 0:
            continue

        mu_j = agent_j.mu_q_field.reshape(N, K)[idxs]
        Sj   = agent_j.sigma_q_field.reshape(N, K, K)[idxs]

        Oi     = exp_phi_i[idxs]
        Oj_inv = exp_neg_phi_i[idxs]
        Ω      = np.einsum("mab,mbc->mac", Oi, Oj_inv)

        mu_j_rot = np.einsum("mij,mj->mi", Ω, mu_j)
        Sj_rot   = np.einsum("mij,mjk,mkl->mil", Ω, Sj, Ω.transpose(0, 2, 1))

        mu_i_ = mu_i[idxs]
        Si_   = Si[idxs]

        Si_inv = np.linalg.inv(Si_ + 1e-6 * np.eye(K))
        Sj_inv = np.linalg.inv(Sj_rot + 1e-6 * np.eye(K))
        diff   = mu_j_rot - mu_i_

        H  = np.einsum("aij,mjk->maik", Gs, Oi)
        dΩ = np.einsum("maik,mkl->mail", H, Oj_inv)

        d = Gs.shape[0]
        grad_phi = np.zeros((len(idxs), d), dtype=phi_i.dtype)

        for a in range(d):
            dΩa = dΩ[:, a]

            dμj_rot = np.einsum("mij,mj->mi", dΩa, mu_j)
            dΣj_rot = (
                np.einsum("mij,mjk,mkl->mil", dΩa, Sj, Ω.transpose(0, 2, 1)) +
                np.einsum("mij,mjk,mkl->mil", Ω, Sj, dΩa.transpose(0, 2, 1))
            )

            tr_term = np.einsum("mij,mji->m", Sj_inv, dΣj_rot)
            quad_term = np.einsum("mi,mij,mj->m", diff, Sj_inv, dμj_rot)

            grad_phi[:, a] = β * 0.5 * (tr_term + 2 * quad_term)

        flat_grad[idxs] += grad_phi

    grad = flat_grad.reshape(*phi_i.shape)

    # Regularization
    if γ > 0:
        grad += γ * laplacian_field(phi_i) * mask_i[..., None]
    if gw > 0:
        grad += 2 * gw * phi_i * mask_i[..., None]
    if κ > 0:
        grad += 2 * κ * (phi_i - phi_m) * mask_i[..., None]

    grad[~mask_i] = 0.0

    norm = np.linalg.norm(grad[mask_i])
    if norm > grad_clip_threshold:
        grad[mask_i] *= grad_clip_threshold / (norm + 1e-8)
        print(f"[CLIP ∇φ] Agent {agent_i.id}: ‖∇φ‖ clipped to {grad_clip_threshold:.1e}")

    return grad  # Already Fisher-preconditioned



from natural_gradient_utils import apply_lie_natural_gradient  # ← Make sure this is at the top

def compute_phi_model_update(agent_i, agents: list, params: dict) -> np.ndarray:
    """
    ∇_{φ_model} [ βm·D_KL(p_i‖Ω̃_{ij} p_j)
                 + γm·Δφ_model
                 + model_mass_weight·φ_model²
                 + φ_phi_tilde_coupling·(φ_belief − φ_model)² ]
    using MVG KL gradients via (μ, Σ); fully natural gradient descent.
    """
    if getattr(config, "identical_models", False):
        return np.zeros_like(agent_i.phi_model)

    βm = params.get("model_align_weight", config.model_align_weight)
    γm = params.get("model_gauge_weight", config.model_gauge_weight)
    mmw = params.get("model_mass_weight", config.model_mass_weight)
    κ   = params.get("phi_phi_tilde_coupling", config.phi_phi_tilde_coupling)
    overlap_eps = params.get("overlap_eps", config.support_cutoff_eps)
    grad_clip_threshold = getattr(config, "phi_model_grad_clip_threshold", 1e4)

    φm_i = agent_i.phi_model
    φ_i  = agent_i.phi
    mask_i = agent_i.mask > overlap_eps
    grad = np.zeros_like(φm_i)
    if βm <= 0 or not mask_i.any():
        return grad

    shape = agent_i.mu_p_field.shape
    N, K = np.prod(shape[:-1]), shape[-1]

    mu_i = agent_i.mu_p_field.reshape(N, K)
    Si   = agent_i.sigma_p_field.reshape(N, K, K)
    flat_grad = grad.reshape(N, -1)

    exp_phi_i     = agent_i._exp_phi_model.reshape(N, K, K)
    exp_neg_phi_i = agent_i._exp_neg_phi_model.reshape(N, K, K)
    Gs = get_generators(config.group_name, K)
    d = Gs.shape[0]

    for nb in agent_i.neighbors:
        agent_j = agents[nb["id"]]
        mask_j = agent_j.mask > overlap_eps
        ov = mask_i & mask_j
        idxs = np.flatnonzero(ov)
        if idxs.size == 0:
            continue

        mu_j = agent_j.mu_p_field.reshape(N, K)[idxs]
        Sj   = agent_j.sigma_p_field.reshape(N, K, K)[idxs]

        Oi     = exp_phi_i[idxs]
        Oj_inv = exp_neg_phi_i[idxs]
        Ω      = np.einsum("mab,mbc->mac", Oi, Oj_inv)

        mu_j_rot = np.einsum("mij,mj->mi", Ω, mu_j)
        Sj_rot   = np.einsum("mij,mjk,mkl->mil", Ω, Sj, Ω.transpose(0, 2, 1))

        mu_i_ = mu_i[idxs]
        Si_   = Si[idxs]

        Si_inv = np.linalg.inv(Si_ + 1e-6 * np.eye(K))
        Sj_inv = np.linalg.inv(Sj_rot + 1e-6 * np.eye(K))
        diff   = mu_j_rot - mu_i_

        H  = np.einsum("aij,mjk->maik", Gs, Oi)
        dΩ = np.einsum("maik,mkl->mail", H, Oj_inv)

        grad_phi = np.zeros((len(idxs), d))

        eigvals = np.linalg.eigvalsh(Sj_rot)
        min_eig = np.min(eigvals, axis=1)
        max_eig = np.max(eigvals, axis=1)
        cond_num = max_eig / np.maximum(min_eig, 1e-12)

        n_bad = np.sum(min_eig <= 0)
        n_ill = np.sum(cond_num > 1e6)
        if n_bad > 0 or n_ill > 0:
            print(f"[WARN Σ̃] Agent {agent_i.id}: {n_bad} non-SPD, {n_ill} ill-conditioned covariances after Ω̃ transport")

        for a in range(d):
            dΩa = dΩ[:, a]
            dmu_j_rot = np.einsum("mij,mj->mi", dΩa, mu_j)
            dSigma_rot = np.einsum("mij,mjk,mkl->mil", dΩa, Sj, Ω.transpose(0, 2, 1)) + \
                         np.einsum("mij,mjk,mkl->mil", Ω, Sj, dΩa.transpose(0, 2, 1))

            tr_term = np.einsum("mij,mji->m", Sj_inv, dSigma_rot)
            quad_term = np.einsum("mi,mij,mj->m", diff, Sj_inv, dmu_j_rot)
            grad_phi[:, a] = βm * 0.5 * (tr_term + 2 * quad_term)

        flat_grad[idxs] += grad_phi

    grad = flat_grad.reshape(*φm_i.shape)

    if γm > 0:
        grad[mask_i] += γm * laplacian_field(φm_i)[mask_i]
    if mmw > 0:
        grad[mask_i] += 2 * mmw * φm_i[mask_i]
    if κ > 0:
        grad[mask_i] += 2 * κ * (φ_i - φm_i)[mask_i]
    grad[~mask_i] = 0.0

    grad_norm = np.linalg.norm(grad[mask_i])
    if grad_norm > grad_clip_threshold:
        grad[mask_i] *= grad_clip_threshold / (grad_norm + 1e-8)
        print(f"[CLIP ∇φ_model] Agent {agent_i.id}: ‖∇φ̃‖ clipped to {grad_clip_threshold:.1e}")

    # === Unconditional natural gradient ===
    G_inv = params.get("G_inv_phi", None)  # spatial or global inverse metric
    grad = apply_lie_natural_gradient(phi=None, grad_phi=grad, G_inv=G_inv)

    return grad
