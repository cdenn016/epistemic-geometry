import numpy as np
import config
from joblib import Parallel, delayed

from generalized_omega import exp_lie_algebra_irrep
from generalized_update_terms import (
    compute_beliefs_gradient,
    compute_models_gradient,
    compute_phi_alignment_gradient,
    compute_phi_model_update,
)
from natural_gradient_utils import riemannian_phi_update

def _compute_all_grads(i, agents, params):
    ai = agents[i]
    return (
        compute_beliefs_gradient(ai, agents, params),
        compute_models_gradient(ai, agents, params),
        compute_phi_alignment_gradient(ai, agents, params),
        compute_phi_model_update(ai, agents, params),
    )

def synchronous_step(agents, generators, params=None, n_jobs=1):
    import config
    from natural_gradient_utils import apply_natural_gradient_batch, apply_lie_natural_gradient
    from generalized_update_terms import (
        compute_beliefs_gradient,
        compute_models_gradient,
        compute_phi_alignment_gradient,
        compute_phi_model_update,
    )
    from generalized_omega import exp_lie_algebra_irrep
    from joblib import Parallel, delayed

    params = params or {}
    N = len(agents)

    # 0) Clear caches & precompute exp(φ) and exp(−φ)
    for A in agents:
        A.clear_omega_cache()

        e_belief = params.get("e_belief", config.e_belief)
        e_model  = params.get("e_model",  config.e_model)

        flat_phi       = A.phi.reshape(-1, A.phi.shape[-1]) / e_belief
        flat_phi_model = A.phi_model.reshape(-1, A.phi_model.shape[-1]) / e_model

        A.grid_shape = A.phi.shape[:-1]
        A._exp_phi           = exp_lie_algebra_irrep(flat_phi,       generators)
        A._exp_neg_phi       = exp_lie_algebra_irrep(-flat_phi,      generators)
        A._exp_phi_model     = exp_lie_algebra_irrep(flat_phi_model, generators)
        A._exp_neg_phi_model = exp_lie_algebra_irrep(-flat_phi_model,generators)

    # 1) Snapshot old φ fields
    phi_old   = [agent.phi.copy()       for agent in agents]
    phi_m_old = [agent.phi_model.copy() for agent in agents]
    mask_list = [agent.mask            for agent in agents]

    # 2) Compute all gradients in parallel
    params_with_step = {**params}
    if "step_debug" not in params_with_step and "step" in params:
        params_with_step["step_debug"] = params["step"]

    
    q_grads, p_grads, phi_grads, phi_m_grads = zip(*Parallel(
        n_jobs=n_jobs, backend="threading"
    )(
        delayed(_compute_all_grads)(i, agents, params_with_step)
        for i in range(N)
    ))

    # 3) Step sizes
    eta_q         = params.get('eta_q',         config.eta_q)
    eta_p         = params.get('eta_p',         config.eta_p)
    eta_phi       = params.get('eta_phi',       config.eta_phi)
    eta_model_phi = params.get('eta_model_phi', config.eta_model_phi)
    G_inv_phi     = params.get('G_inv_phi', None)
    G_inv_model   = params.get('G_inv_phi_model', None)

    # 4) Apply updates
    for i, agent in enumerate(agents):
        mask = mask_list[i]
        mask_mu    = mask[..., None]       # (H, W, 1)
        mask_sigma = mask[..., None, None] # (H, W, 1, 1)

        grad_mu_q,    grad_sigma_q    = q_grads[i]
        grad_mu_p,    grad_sigma_p    = p_grads[i]
        grad_phi      = phi_grads[i]
        grad_phi_m    = phi_m_grads[i]

        # ----- Natural gradient descent for beliefs -----
        delta_mu_q, delta_sigma_q = apply_natural_gradient_batch(
            agent.mu_q_field, agent.sigma_q_field,
            grad_mu_q, grad_sigma_q
        )
        agent.mu_q_field    += eta_q * delta_mu_q    * mask_mu
        agent.sigma_q_field += eta_q * delta_sigma_q * mask_sigma

        # ----- Natural gradient descent for models -----
        delta_mu_p, delta_sigma_p = apply_natural_gradient_batch(
            agent.mu_p_field, agent.sigma_p_field,
            grad_mu_p, grad_sigma_p
        )
        agent.mu_p_field    += eta_p * delta_mu_p    * mask_mu
        agent.sigma_p_field += eta_p * delta_sigma_p * mask_sigma

        # ----- Natural gradient in φ space -----
        delta_phi = eta_phi * apply_lie_natural_gradient(agent.phi, grad_phi, G_inv=G_inv_phi)
        delta_phi_m = eta_model_phi * apply_lie_natural_gradient(agent.phi_model, grad_phi_m, G_inv=G_inv_model)

        # Masked φ updates
        mask_exp = np.broadcast_to(mask_mu, delta_phi.shape)
        agent.phi       = phi_old[i] + delta_phi * mask_exp
        agent.phi_model = phi_m_old[i] + delta_phi_m * mask_exp

        agent.delta_phi       = agent.phi - phi_old[i]
        agent.delta_phi_model = agent.phi_model - phi_m_old[i]

    return agents





def update_all(agents, generators, params=None, n_jobs=1):
    """
    Alias for synchronous_step with explicit generators argument.
    """
    return synchronous_step(agents, generators, params, n_jobs)