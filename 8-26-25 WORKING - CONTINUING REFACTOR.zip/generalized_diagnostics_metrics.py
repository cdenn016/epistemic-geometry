# Third-party libraries
import numpy as np
from pathlib import Path
from joblib import Parallel, delayed

import core.config as config
from core.get_generators import get_generators
from core.omega import (
    
    batch_apply_omega,
    compute_field_strength,
   
)

from transport.bundle_morphism_utils import safe_batch_apply_morphism_nat
from core.numerical_utils import sanitize_sigma, safe_inv, safe_logdet
from transport.transport_cache import Lambda_dn, Lambda_up

from transport.bundle_morphism_utils import safe_batch_apply_morphism_nat, compute_direct_morphisms

from core.gaussian_kl import kl_gaussian, kl_field, robust_reduce_kl

from core.group import exp_lie_algebra_irrep
from transport.transport_cache import Omega as tc_Omega 


# ==================================================================================
#                                     Fields
# ==================================================================================



def kl_divergence(mu1, sigma1, mu2, sigma2, mask=None, eps=1e-6):
    vals = kl_gaussian(mu1, sigma1, mu2, sigma2, eps=eps)
    if mask is not None:
        m = np.asarray(mask)
        if m.ndim == 2:
            m = np.squeeze(m, axis=-1)
        vals = vals * m
    return np.asarray(vals, dtype=np.float32)


def robust_aggregate_kl(kl_field_map, mask, *, cap=100.0, trim_hi=0.995, area_norm=True, nan_policy="zero"):
    total, stats = robust_reduce_kl(
        kl_field_map, mask,
        cap=cap, trim_hi=trim_hi, area_norm=area_norm, nan_policy=nan_policy
    )
    return float(total), stats



def _resolve_generators(name: str, K: int):
    """Robustly resolve generators from get_generators for dimension K."""
    ret = get_generators(name, K)
    if isinstance(ret, (list, tuple)) and len(ret) > 0:
        return ret[0]
    if isinstance(ret, dict) and "generators" in ret:
        return ret["generators"]
    return ret




def compute_alignment_field_general(
    agents, i, field_type="belief",
    eps=config.support_cutoff_eps,
    log_eps=config.log_eps,
    *, ctx=None
) -> np.ndarray:
    """
    Mean KL to neighbors on overlap, per pixel, for either belief or model fiber.
    Uses central Ω cache if ctx is provided; otherwise computes on-the-fly.
    """
    A = agents[i]
    mask_i = threshold_mask(A.mask, eps)  # same helper as before
    if not np.any(mask_i):
        return np.zeros_like(mask_i, dtype=np.float32)

    # --- neighbors (same logic as before) ---
    nb_list = getattr(A, "neighbors", None)
    if not nb_list:
        tau = float(getattr(config, "parent_area_threshold",
                            getattr(config, "overlap_eps", 0.20)))
        minpx = int(getattr(config, "min_pair_px", 8))
        nb_list = []
        for j, B in enumerate(agents):
            if j == i:
                continue
            mask_j = threshold_mask(getattr(B, "mask", None), eps)
            if not np.any(mask_j):
                continue
            inter = (np.asarray(A.mask) > tau) & (np.asarray(B.mask) > tau)
            if int(inter.sum()) >= minpx:
                nb_list.append({"id": j})

    if not nb_list:
        return np.zeros_like(mask_i, dtype=np.float32)

    H, W = A.mask.shape
    kl_accum = np.zeros((H, W), dtype=np.float32)
    n_nb_at = np.zeros((H, W), dtype=np.int32)
    kl_cap = float(getattr(config, "signal_kl_cap", 5.0))
    group = getattr(config, "group_name", "so3")

    if field_type == "belief":
        mu_i, sigma_i, phi_i, K = A.mu_q_field, A.sigma_q_field, A.phi, int(config.K_q)
        fiber_key = "q"
    elif field_type == "model":
        mu_i, sigma_i, phi_i, K = A.mu_p_field, A.sigma_p_field, A.phi_model, int(config.K_p)
        fiber_key = "p"
    else:
        raise ValueError(f"field_type must be 'belief' or 'model', got {field_type}")

    # Resolve generators for the *fallback* path only (central cache infers its own)  :contentReference[oaicite:1]{index=1}
    generators = _resolve_generators(group, K)

    for nb in nb_list:
        j = nb["id"]
        B = agents[j]
        mask_j = threshold_mask(B.mask, eps)
        overlap = mask_i & mask_j
        if not np.any(overlap):
            continue

        if field_type == "belief":
            mu_j, sigma_j, phi_j = B.mu_q_field, B.sigma_q_field, B.phi
        else:
            mu_j, sigma_j, phi_j = B.mu_p_field, B.sigma_p_field, B.phi_model

        # strict SPD shape for neighbor
        if sigma_j.ndim != 4 or sigma_j.shape[-2:] != (K, K):
            raise ValueError(f"Expected full SPD Σ_j with shape (H,W,{K},{K}); got {sigma_j.shape}")

        idx = np.argwhere(overlap)
        r, c = idx[:, 0], idx[:, 1]

        mu_i_pts = np.asarray(mu_i)[overlap]        # (M,K)
        sigma_i_pts = sanitize_sigma(np.asarray(sigma_i)[overlap], eps=log_eps)
        mu_j_pts = np.asarray(mu_j)[overlap]        # (M,K)
        sigma_j_pts = sanitize_sigma(np.asarray(sigma_j)[overlap], eps=log_eps)

        # ---------- Ω from central cache (preferred) or local fallback ----------
        if ctx is not None:
            # Centralized: Ω_{ij} = E_i @ inv(E_j), cached in ctx.cache["omega"]               :contentReference[oaicite:2]{index=2}
            # infers generators & φ from agents; we just pass which={'q','p'}
            Om_full = tc_Omega(ctx, A, B, which=fiber_key)  # (H,W,K,K)
            Omega = Om_full[overlap]  # (M,K,K)
        else:
            # Fallback (no ctx): compute on-the-fly, keeping legacy semantics
            O_i = exp_lie_algebra_irrep(np.asarray(phi_i)[overlap], generators)
            O_j_inv = exp_lie_algebra_irrep(-np.asarray(phi_j)[overlap], generators)
            Omega = np.matmul(O_i, O_j_inv)

        if not np.all(np.isfinite(Omega)):
            print(f"[WARNING] non-finite Ω({fiber_key}) for agent {i} ↔ neighbor {j}")

        # Transport neighbor stats
        mu_j_t = np.einsum("mab,mb->ma", Omega, mu_j_pts)   # (M,K)
        Omega_T = np.swapaxes(Omega, -1, -2)
        sigma_j_t = np.matmul(np.matmul(Omega, sigma_j_pts), Omega_T)
        sigma_j_t = sanitize_sigma(sigma_j_t, eps=log_eps)

        # Per-pixel KL, robust and capped
        kl_vals = kl_divergence(mu_i_pts, sigma_i_pts, mu_j_t, sigma_j_t, eps=log_eps)
        kl_vals = np.where(np.isfinite(kl_vals), kl_vals, 0.0)
        kl_vals = np.maximum(kl_vals, 0.0)
        if kl_cap is not None:
            kl_vals = np.minimum(kl_vals, kl_cap)

        np.add.at(kl_accum, (r, c), kl_vals.astype(np.float32, copy=False))
        np.add.at(n_nb_at, (r, c), 1)

    out = np.zeros_like(kl_accum, dtype=np.float32)
    valid = n_nb_at > 0
    out[valid] = kl_accum[valid] / n_nb_at[valid]
    return out * mask_i.astype(np.float32, copy=False)



# ----------------------- pairwise KL: belief/model fibers -----------------------
def compute_pairwise_kl_belief(
    agents, generators_q, params, return_pointwise: bool = False, *, only_neighbors: bool = True, ctx=None
):
    import numpy as np
    log_eps = float(params.get("log_eps", 1e-8))
    eps     = float(params.get("overlap_eps", 1e-6))
    kl_cap  = float(params.get("kl_cap", getattr(config, "signal_kl_cap", 5.0)))
    group   = getattr(config, "group_name", "so3")

    N = len(agents)
    kl_matrix = np.full((N, N), np.nan, dtype=np.float32)
    pointwise = {} if return_pointwise else None

    for i, A in enumerate(agents):
        mask_i = (np.asarray(A.mask) > eps)
        H, W   = mask_i.shape

        # Pre-sanitize Σᵢ once
        Sigma_i_full = sanitize_sigma(np.asarray(A.sigma_q_field), eps=log_eps)
        Mu_i_full    = np.asarray(A.mu_q_field)
        Phi_i_full   = np.asarray(A.phi)

        js_iter = [nb["id"] for nb in getattr(A, "neighbors", [])] if (only_neighbors and getattr(A, "neighbors", None)) else range(N)

        for j in js_iter:
            if i == j:
                kl_matrix[i, j] = 0.0
                continue

            B = agents[j]
            mask_j  = (np.asarray(B.mask) > eps)
            overlap = mask_i & mask_j
            if not np.any(overlap):
                continue

            # Overlap slices
            mu_i = Mu_i_full[overlap]                                   # (M,Kq)
            sig_i = Sigma_i_full[overlap]                                # (M,Kq,Kq)

            Mu_j_full    = np.asarray(B.mu_q_field)
            Sigma_j_full = sanitize_sigma(np.asarray(B.sigma_q_field), eps=log_eps)
            mu_j  = Mu_j_full[overlap]                                   # (M,Kq)
            sig_j = Sigma_j_full[overlap]                                # (M,Kq,Kq)
            Phi_j_full = np.asarray(B.phi)

            Kq = sig_i.shape[-1]
            if (sig_i.ndim != 3 or sig_i.shape[-2:] != (Kq, Kq) or
                sig_j.ndim != 3 or sig_j.shape[-2:] != (Kq, Kq)):
                raise ValueError("Belief Σ slices must be (M,K_q,K_q) full SPD")

            # ---- Ω_ij from central cache (preferred) or legacy fallback ----
            if ctx is not None:
                Om_full  = tc_Omega(ctx, A, B, which="q")                # (H,W,Kq,Kq)
                Omega_ij = Om_full[overlap]                              # (M,Kq,Kq)
            else:
                O_i    = exp_lie_algebra_irrep(Phi_i_full[overlap], generators_q, group_name=group)
                O_jinv = exp_lie_algebra_irrep(-Phi_j_full[overlap], generators_q, group_name=group)
                Omega_ij = np.matmul(O_i, O_jinv)

            # Pushforward B→A
            mu_j_t, sig_j_t = batch_apply_omega(mu_j, sig_j, Omega_ij, eps=log_eps)
            sig_j_t = sanitize_sigma(sig_j_t, eps=log_eps)

            # KL (robust + capped)
            kl_vals = kl_divergence(mu_i, sig_i, mu_j_t, sig_j_t, eps=log_eps)
            kl_vals = np.where(np.isfinite(kl_vals), kl_vals, 0.0)
            kl_vals = np.maximum(kl_vals, 0.0)
            if kl_cap is not None:
                kl_vals = np.minimum(kl_vals, kl_cap)

            kl_matrix[i, j] = np.float32(np.mean(kl_vals))
            if return_pointwise:
                pw = np.zeros((H, W), dtype=np.float32)
                pw[overlap] = kl_vals.astype(np.float32, copy=False)
                pointwise[(i, j)] = pw

    return (kl_matrix, pointwise) if return_pointwise else kl_matrix


def compute_pairwise_kl_model(
    agents, generators_p, params, return_pointwise: bool = False, *, only_neighbors: bool = True, ctx=None
):
    import numpy as np
    log_eps = float(params.get("log_eps", 1e-8))
    eps     = float(params.get("overlap_eps", 1e-6))
    kl_cap  = float(params.get("kl_cap", getattr(config, "signal_kl_cap", 5.0)))
    group   = getattr(config, "group_name", "so3")

    N = len(agents)
    kl_matrix = np.full((N, N), np.nan, dtype=np.float32)
    pointwise = {} if return_pointwise else None

    for i, A in enumerate(agents):
        mask_i = (np.asarray(A.mask) > eps)
        H, W   = mask_i.shape

        Sigma_i_full = sanitize_sigma(np.asarray(A.sigma_p_field), eps=log_eps)
        Mu_i_full    = np.asarray(A.mu_p_field)
        Phi_i_full   = np.asarray(A.phi_model)

        js_iter = [nb["id"] for nb in getattr(A, "neighbors", [])] if (only_neighbors and getattr(A, "neighbors", None)) else range(N)

        for j in js_iter:
            if i == j:
                kl_matrix[i, j] = 0.0
                continue

            B = agents[j]
            mask_j  = (np.asarray(B.mask) > eps)
            overlap = mask_i & mask_j
            if not np.any(overlap):
                continue

            mu_i  = Mu_i_full[overlap]                                   # (M,Kp)
            sig_i = Sigma_i_full[overlap]                                # (M,Kp,Kp)

            Mu_j_full    = np.asarray(B.mu_p_field)
            Sigma_j_full = sanitize_sigma(np.asarray(B.sigma_p_field), eps=log_eps)
            mu_j  = Mu_j_full[overlap]                                   # (M,Kp)
            sig_j = Sigma_j_full[overlap]                                # (M,Kp,Kp)
            Phi_j_full = np.asarray(B.phi_model)

            Kp = sig_i.shape[-1]
            if (sig_i.ndim != 3 or sig_i.shape[-2:] != (Kp, Kp) or
                sig_j.ndim != 3 or sig_j.shape[-2:] != (Kp, Kp)):
                raise ValueError("Model Σ slices must be (M,K_p,K_p) full SPD")

            # ---- Ω̃_ij from central cache (preferred) or legacy fallback ----
            if ctx is not None:
                Om_full  = tc_Omega(ctx, A, B, which="p")                # (H,W,Kp,Kp)
                Omega_ij = Om_full[overlap]                              # (M,Kp,Kp)
            else:
                O_i    = exp_lie_algebra_irrep(Phi_i_full[overlap], generators_p, group_name=group)
                O_jinv = exp_lie_algebra_irrep(-Phi_j_full[overlap], generators_p, group_name=group)
                Omega_ij = np.matmul(O_i, O_jinv)

            mu_j_t, sig_j_t = batch_apply_omega(mu_j, sig_j, Omega_ij, eps=log_eps)
            sig_j_t = sanitize_sigma(sig_j_t, eps=log_eps)

            kl_vals = kl_divergence(mu_i, sig_i, mu_j_t, sig_j_t, eps=log_eps)
            kl_vals = np.where(np.isfinite(kl_vals), kl_vals, 0.0)
            kl_vals = np.maximum(kl_vals, 0.0)
            if kl_cap is not None:
                kl_vals = np.minimum(kl_vals, kl_cap)

            kl_matrix[i, j] = np.float32(np.mean(kl_vals))
            if return_pointwise:
                pw = np.zeros((H, W), dtype=np.float32)
                pw[overlap] = kl_vals.astype(np.float32, copy=False)
                pointwise[(i, j)] = pw

    return (kl_matrix, pointwise) if return_pointwise else kl_matrix

# ------------------------------ robust cross-scale KLs ------------------------------


def compute_crossscale_kl_q_single(child, parent, *, eps=1e-8, support_thr=1e-3,
                                   return_field=False, ctx=None):
    """
    Cross-scale belief KL (same fiber):
        KL( q_child || Λ_q · q_parent )
    Λ_q maps parent q-fiber → child q-fiber. Supports per-pixel (H,W,Kc,Kp) or global (Kc,Kp).
    """
   
    # Soft overlap weights; gate by threshold to avoid halos
    w = np.minimum(_as_float32(child.mask), _as_float32(parent.mask))
    m = (w > float(support_thr))
    if not m.any() or ctx is None:
        if return_field:
            return 0.0, np.zeros_like(child.mask, dtype=np.float32)
        return 0.0

    # Fields on overlap (Npx, K)
    mu_c = _as_float32(child.mu_q_field)[m]
    S_c  = _as_float32(child.sigma_q_field)[m]
    mu_p = _as_float32(parent.mu_q_field)[m]
    S_p  = _as_float32(parent.sigma_q_field)[m]

    # Transport parent→child
    
    L = _as_float32(Lambda_dn(ctx, child, parent, which="q"))

    # Align shapes for batched morphism
    if L.ndim == 2:
        # (Kc,Kp) → tile to (Npx,Kc,Kp) in _apply_linear_morphism
        Lm = L
    elif L.ndim == 4 and L.shape[:2] == child.mask.shape:
        # (H,W,Kc,Kp) → (Npx,Kc,Kp) using the same overlap mask
        Lm = L[m]
    else:
        raise ValueError(f"Unexpected Λ_q shape {L.shape}; expected (Kc,Kp) or (H,W,Kc,Kp).")

    # parent → child space
    mu_p_t, S_p_t = _apply_linear_morphism(mu_p, S_p, Lm, eps=eps)

    # Ensure SPD & symmetry on both sides
    S_c   = sanitize_sigma(S_c,   eps=eps)
    S_p_t = sanitize_sigma(S_p_t, eps=eps)

    # KL per pixel (Npx,)
    kl_vals = kl_divergence(mu_c, S_c, mu_p_t, S_p_t, eps=eps)
    kl_vals = np.where(np.isfinite(kl_vals), kl_vals, 0.0).astype(np.float32, copy=False)

    # Weighted mean over overlap pixels
    w_flat = w[m].astype(np.float32, copy=False)
    w_flat = np.where(np.isfinite(w_flat), w_flat, 0.0)
    w_sum  = float(w_flat.sum())
    mean_kl = float((kl_vals * w_flat).sum() / w_sum) if w_sum > 0 else 0.0

    if return_field:
        out = np.zeros_like(child.mask, dtype=np.float32)
        out[m] = kl_vals  # note: this is unweighted KL per pixel
        return mean_kl, out
    return mean_kl


def compute_crossscale_kl_p_single(child, parent, *, eps=1e-8, support_thr=1e-3,
                                   return_field=False, ctx=None):
    """
    Cross-scale model KL (same fiber):
        KL( p_child || Λ_p · p_parent )
    Λ_p maps parent p-fiber → child p-fiber. Supports per-pixel (H,W,Kc,Kp) or global (Kc,Kp).
    """
   

    w = np.minimum(_as_float32(child.mask), _as_float32(parent.mask))
    m = (w > float(support_thr))
    if not m.any() or ctx is None:
        if return_field:
            return 0.0, np.zeros_like(child.mask, dtype=np.float32)
        return 0.0

    mu_c = _as_float32(child.mu_p_field)[m]
    S_c  = _as_float32(child.sigma_p_field)[m]
    mu_p = _as_float32(parent.mu_p_field)[m]
    S_p  = _as_float32(parent.sigma_p_field)[m]

    
    L = _as_float32(Lambda_dn(ctx, child, parent, which="p"))

    if L.ndim == 2:
        Lm = L
    elif L.ndim == 4 and L.shape[:2] == child.mask.shape:
        Lm = L[m]
    else:
        raise ValueError(f"Unexpected Λ_p shape {L.shape}; expected (Kc,Kp) or (H,W,Kc,Kp).")

    mu_p_t, S_p_t = _apply_linear_morphism(mu_p, S_p, Lm, eps=eps)

    S_c   = sanitize_sigma(S_c,   eps=eps)
    S_p_t = sanitize_sigma(S_p_t, eps=eps)

    kl_vals = kl_divergence(mu_c, S_c, mu_p_t, S_p_t, eps=eps)
    kl_vals = np.where(np.isfinite(kl_vals), kl_vals, 0.0).astype(np.float32, copy=False)

    w_flat = w[m].astype(np.float32, copy=False)
    w_flat = np.where(np.isfinite(w_flat), w_flat, 0.0)
    w_sum  = float(w_flat.sum())
    mean_kl = float((kl_vals * w_flat).sum() / w_sum) if w_sum > 0 else 0.0

    if return_field:
        out = np.zeros_like(child.mask, dtype=np.float32)
        out[m] = kl_vals
        return mean_kl, out
    return mean_kl



# ====================================================================
#                               Energy Fields
# ====================================================================





def kl_divergence_field_auto(mu1, S1, mu2, S2, mask, morphism, eps: float = 1e-8) -> np.ndarray:
    return kl_field(
        mu1, S1, mu2, S2,
        mask=mask,
        morphism=morphism,
        support="auto",
        eps=eps
    ).astype(np.float32, copy=False)




def compute_self_energy(agent, eps, cfg):
    """
    α * KL(q_i || Φ̃ · p_i) on automatic interior support (gated by Φ̃).
    Returns an (H,W) field.
    """
    Phi_tilde = getattr(agent, "bundle_morphism_p_to_q", None)  # Φ̃: p→q
    if Phi_tilde is None:
        H, W = np.asarray(agent.mask).shape[:2]
        return np.zeros((H, W), dtype=float)

    mu_pq, S_pq = safe_batch_apply_morphism_nat(
        agent.mu_p_field, agent.sigma_p_field, Phi_tilde, eps=eps
    )
    field = kl_divergence_field_auto(
        mu1=agent.mu_q_field, S1=agent.sigma_q_field,
        mu2=mu_pq,          S2=S_pq,
        mask=agent.mask,    morphism=Phi_tilde,
        eps=eps,
    )
    alpha = float(cfg.get("alpha", 1.0))
    return alpha * field


def compute_feedback_energy(agent, eps, cfg):
    """
    λ * KL(p_i || Φ · q_i) on automatic interior support (gated by Φ).
    Returns an (H,W) field.
    """
    Phi = getattr(agent, "bundle_morphism_q_to_p", None)  # Φ: q→p
    if Phi is None:
        H, W = np.asarray(agent.mask).shape[:2]
        return np.zeros((H, W), dtype=float)

    mu_qp, S_qp = safe_batch_apply_morphism_nat(
        agent.mu_q_field, agent.sigma_q_field, Phi, eps=eps
    )
    field = kl_divergence_field_auto(
        mu1=agent.mu_p_field, S1=agent.sigma_p_field,
        mu2=mu_qp,          S2=S_qp,
        mask=agent.mask,    morphism=Phi,
        eps=eps,
    )
    lam = float(cfg.get("lambda", cfg.get("feedback_weight", 0.0)))
    return lam * field


def compute_entropy_field(sigma_field, mask, log_eps=1e-8):
    m = np.asarray(mask, bool)
    if sigma_field.ndim == 3:
        var = np.clip(sigma_field**2, log_eps, None)
        log_det = np.sum(np.log(var), axis=-1)
        K = sigma_field.shape[-1]
        out = 0.5 * (K * np.log(2*np.pi*np.e) + log_det)
        out[~m] = 0.0
        return out
    H, W, K, _ = sigma_field.shape
    idx = np.flatnonzero(m.ravel())
    if idx.size == 0:
        return np.zeros((H, W), dtype=float)
    S = sigma_field.reshape(H*W, K, K)[idx]
    S = 0.5 * (S + np.swapaxes(S, -1, -2)) + log_eps * np.eye(K)[None, ...]
    sign, logdet = np.linalg.slogdet(S)
    out = np.zeros((H, W), dtype=float)
    out.reshape(-1)[idx] = 0.5 * (K * np.log(2*np.pi*np.e) + logdet)
    out[~m] = 0.0
    return out


# ===================================================================
#                           Scalar Energies
# ===================================================================


def _masked_finite_sum(arr: np.ndarray, mask: np.ndarray, thr: float) -> float:
    m = (np.asarray(mask) > thr)
    if not m.any():
        return 0.0
    a = np.where(m, arr, 0.0)
    a = np.where(np.isfinite(a), a, 0.0)
    return float(np.sum(a, dtype=np.float64))


def compute_self_energy_scalar(agent, log_eps, cfg) -> float:
    """Weighted sum of KL(q_i || Φ̃·p_i) over valid support."""
    field = compute_self_energy(agent, log_eps, cfg)
    agent.e_self_field = field  # optional cache
    thr = float(cfg.get("support_cutoff_eps", 1e-3))
    return _masked_finite_sum(field, agent.mask, thr)


def compute_feedback_energy_scalar(agent, log_eps, cfg) -> float:
    """Weighted sum of KL(p_i || Φ·q_i) over valid support."""
    field = compute_feedback_energy(agent, log_eps, cfg)
    agent.e_feedback_field = field  # optional cache
    thr = float(cfg.get("support_cutoff_eps", 1e-3))
    return _masked_finite_sum(field, agent.mask, thr)


# -------------------- Regularizers --------------------


def compute_mass_energy(phi: np.ndarray, mask: np.ndarray, weight: float) -> float:
    """
    Mass regularization: E = weight * ∑_{mask} ||phi||^2
    phi: (H,W,d), mask: (H,W) in [0,1] or bool
    """
    m = (np.asarray(mask) > 0)
    if not m.any():
        return 0.0
    norms_sq = np.sum(np.asarray(phi, np.float32)**2, axis=-1)
    return float(weight) * float(np.sum(np.where(m, norms_sq, 0.0), dtype=np.float64))


def compute_curvature_energy(phi_field, mask, weight, lie_gens, support_eps=1e-4, debug=False):
    F = compute_field_strength(phi_field, lie_gens)  
    support = np.asarray(mask) > support_eps
    total = 0.0
    for val in F.values():
        if val.ndim == 2:
            total += val**2
        elif val.ndim == 3:
            total += np.sum(val**2, axis=-1)
        elif val.ndim == 4:
            total += np.sum(val**2, axis=(-2, -1))
        else:
            raise ValueError(f"Unexpected F shape: {val.shape}")
    raw = float(np.sum(total[support]))
    if debug:
        print(f"[φ_curv] Raw: {raw:.4f} | Weighted: {weight*raw:.4f}")
    return weight * raw, raw


# ==========================================================================
#                                  Logging
# ==========================================================================



def _lambda_norms_primary(agent, mask, *, ctx=None) -> dict:
    """Return mean Frobenius norms of Λ_dn/Λ_up for q/p, for the primary parent."""
    out = {"lambda_q_dn_norm": np.nan, "lambda_q_up_norm": np.nan,
           "lambda_p_dn_norm": np.nan, "lambda_p_up_norm": np.nan}
    if ctx is None:
        return out
    parent = _select_primary_parent(agent, ctx)
    if parent is None:
        return out
    

    for which in ("q", "p"):
        try:
            Ldn = Lambda_dn(ctx, agent, parent, which=which)
            if Ldn is not None:
                out[f"lambda_{which}_dn_norm"] = _reduce_over_mask(_fro_map(Ldn), mask, "mean")
        except Exception:
            pass
        try:
            Lup = Lambda_up(ctx, agent, parent, which=which)
            if Lup is not None:
                out[f"lambda_{which}_up_norm"] = _reduce_over_mask(_fro_map(Lup), mask, "mean")
        except Exception:
            pass
    return out

def _morphism_norms(agent, mask) -> dict:
    """Mean Frobenius norms of bundle morphisms (q→p and p→q) over support."""
    out = {"morphism_q2p_norm": np.nan, "morphism_p2q_norm": np.nan}
    try:
        Phi = getattr(agent, "bundle_morphism_q_to_p", None)
        if Phi is not None:
            out["morphism_q2p_norm"] = _reduce_over_mask(_fro_map(Phi), mask, "mean")
    except Exception:
        pass
    try:
        Phit = getattr(agent, "bundle_morphism_p_to_q", None)
        if Phit is not None:
            out["morphism_p2q_norm"] = _reduce_over_mask(_fro_map(Phit), mask, "mean")
    except Exception:
        pass
    return out

#=============================================================================
#
#              Total Variational Energy Scalar
#
#
#=============================================================================

# ====================================================================
#                         Free Energy (scalar)
# ====================================================================



def _area_norm(mask):
    m = np.asarray(mask, np.float32) > float(getattr(config, "support_cutoff_eps", 1e-3))
    a = int(m.sum())
    return max(a, 1)

def _fro_sq_map(M):
    M = np.asarray(M, np.float32)
    if M.ndim < 2:
        return None
    if M.ndim == 2:  # (Kout,Kin)
        return float(np.sum(M * M))
    # (..., Kout, Kin)  -> per-pixel Fro^2
    return np.sum(M * M, axis=(-2, -1))

def _masked_mean(field, mask):
    m = np.asarray(mask, bool)
    if field is None or not np.any(m):
        return 0.0
    x = np.asarray(field, np.float64)
    x = np.where(m, x, 0.0)
    return float(np.sum(x) / max(int(m.sum()), 1))

def _first_parent(child, parents_by_id):
    for pid in getattr(child, "parent_ids", ()) or ():
        P = parents_by_id.get(int(pid))
        if P is not None:
            return P
    return None

def _alignment_energy_for_agent(A, agents, generators_q, generators_p, *, ctx=None):
    # Belief alignment (q) and model alignment (p); robust scalar aggregations
    field_q = compute_alignment_field_general(agents, A.id, field_type="belief", ctx=ctx)
    eq, _stats_q = robust_aggregate_kl(field_q, A.mask,
                                       cap=float(getattr(config, "signal_kl_cap", 1000.0)))
    field_p = compute_alignment_field_general(agents, A.id, field_type="model", ctx=ctx)
    ep, _stats_p = robust_aggregate_kl(field_p, A.mask,
                                       cap=float(getattr(config, "signal_kl_cap", 1000.0)))
    return eq + ep

def _morphism_energy_for_agent(A):
    # Penalize large bundle morphisms (both directions), averaged over support
    acc = 0.0
    cnt = 0
    for name in ("bundle_morphism_q_to_p", "bundle_morphism_p_to_q"):
        M = getattr(A, name, None)
        if M is None:
            continue
        val = _fro_sq_map(M)
        if val is None:
            continue
        if isinstance(val, float):
            # global morphism
            acc += val
            cnt += 1
        else:
            # field-shaped; average over support
            acc += _masked_mean(val, A.mask)
            cnt += 1
    return (acc / max(cnt, 1)) if cnt else 0.0

def _curvature_energy_for_agent(A, *, generators_q=None, generators_p=None, ctx=None):
    """
    Return RAW (unweighted) curvature energies for belief (φ) and model (φ̃),
    as a tuple (E_curv_q_raw, E_curv_p_raw). Weights are applied by the caller.
    """
    cq = cp = 0.0
    # Belief curvature
    try:
        if generators_q is not None and getattr(A, "phi", None) is not None:
            _, raw_q = compute_curvature_energy(
                np.asarray(A.phi), np.asarray(A.mask), weight=1.0, lie_gens=generators_q
            )
            cq = float(raw_q)
    except Exception:
        pass

    # Model curvature
    try:
        if generators_p is not None and getattr(A, "phi_model", None) is not None:
            _, raw_p = compute_curvature_energy(
                np.asarray(A.phi_model), np.asarray(A.mask), weight=1.0, lie_gens=generators_p
            )
            cp = float(raw_p)
    except Exception:
        pass

    return (cq, cp)


def _crossscale_energy_for_child(C, parents_by_id, *, ctx=None):
    # Child↔parent consistency via Λ: KL( child || Λ·parent ) on q and p fibers
    P = _first_parent(C, parents_by_id)
    if P is None:
        return 0.0
    e = 0.0
    try:
        ekq = compute_crossscale_kl_q_single(C, P, ctx=ctx)
        e  += float(ekq)
    except Exception:
        pass
    try:
        ekp = compute_crossscale_kl_p_single(C, P, ctx=ctx)
        e  += float(ekp)
    except Exception:
        pass
    return e



def _self_energy_sum(agent, cfg, *, generators_q=None, generators_p=None, ctx=None) -> float:
    """
    Clipped per-pixel SUM of KL(q || Φ̃ · p) on support, with bundle morphism applied.
    Φ̃ = bundle_morphism_p_to_q (Kq×Kp) or (H,W,Kq,Kp).
    Falls back to recomputing morphisms if not present.
    """
   
    

    # Pull fields
    mu_q = getattr(agent, "mu_q_field", None)
    sg_q = getattr(agent, "sigma_q_field", None)
    mu_p = getattr(agent, "mu_p_field", None)
    sg_p = getattr(agent, "sigma_p_field", None)
    if mu_q is None or sg_q is None or mu_p is None or sg_p is None:
        return 0.0

    # Support mask
    m = np.asarray(getattr(agent, "mask", 0.0), np.float32)
    tau = float(getattr(cfg, "support_cutoff_eps", getattr(cfg, "support_tau", 1e-3)))
    mask = (m > tau)
    if not np.any(mask):
        return 0.0

    # Get Φ̃ (p→q). Prefer cached field, else build directly from (φ, φ̃).
    Phi_tilde = getattr(agent, "bundle_morphism_p_to_q", None)
    if Phi_tilde is None:
        # Ensure bases
        if getattr(agent, "Phi_tilde_0", None) is None:
            Kq = int(mu_q.shape[-1]); Kp = int(mu_p.shape[-1])
            agent.Phi_tilde_0 = np.eye(Kq, Kp, dtype=np.float32)
        if getattr(agent, "Phi_0", None) is None:
            Kq = int(mu_q.shape[-1]); Kp = int(mu_p.shape[-1])
            agent.Phi_0 = np.eye(Kp, Kq, dtype=np.float32)
        # Build Φ, Φ̃ (ctx-aware; uses cached exp-grids)
        Phi, Phi_tilde = compute_direct_morphisms(
            phi=getattr(agent, "phi", None),
            phi_model=getattr(agent, "phi_model", None),
            generators_q=generators_q,
            generators_p=generators_p,
            Phi_0=agent.Phi_0,
            Phi_tilde_0=agent.Phi_tilde_0,
            ctx=ctx,
        )
        agent.bundle_morphism_q_to_p = Phi.astype(np.float32, copy=False)
        agent.bundle_morphism_p_to_q = Phi_tilde.astype(np.float32, copy=False)

    # Apply Φ̃ to p stats -> q-fiber stats
    # shapes: mu_p (...,Kp), sg_p (...,Kp,Kp), Φ̃ (...,Kq,Kp) → mu_pq (...,Kq), sg_pq (...,Kq,Kq)
    mu_pq, sg_pq = safe_batch_apply_morphism_nat(mu_p, sg_p, agent.bundle_morphism_p_to_q, eps=1e-8)

    # Compute per-pixel KL on support and sum with cap (exactly like your diagnostic)
    log_eps = float(getattr(cfg, "log_eps", 1e-8))
    cap     = float(getattr(cfg, "signal_kl_cap", 5.0))
    kl_qp   = kl_divergence(mu_q[mask], sg_q[mask], mu_pq[mask], sg_pq[mask], eps=log_eps)
    return float(np.sum(np.clip(kl_qp, 0.0, cap)))


# generalized_diagnostics_metrics.py

def _gauge_mass_energy_for_agent(A, *, eps=None):
    """
    Raw gauge mass for one agent (no weights):
      E_q_raw = 1/2 * sum_{mask} ||phi||^2
      E_p_raw = 1/2 * sum_{mask} ||phi_tilde||^2
    """
    import numpy as np
    if eps is None:
        try:
            from core import config
            eps = float(getattr(config, "support_cutoff_eps", 1e-6))
        except Exception:
            eps = 1e-6

    m   = (np.asarray(getattr(A, "mask", 0.0), np.float32) > eps)
    phi = np.asarray(getattr(A, "phi", None), np.float32)
    phm = np.asarray(getattr(A, "phi_model", None), np.float32)

    e_q = 0.0 if phi is None else 0.5 * np.sum((np.linalg.norm(phi, axis=-1)**2) * m)
    e_p = 0.0 if phm is None else 0.5 * np.sum((np.linalg.norm(phm, axis=-1)**2) * m)
    return float(e_q), float(e_p)



def compute_total_free_energy(agents, *, generators_q=None, generators_p=None, ctx=None, weights=None):
    import core.config as config  # ensure local import works everywhere

    # Weights (allow separate curvature weights for q and p)
    enable_xscale = bool(getattr(config, "enable_xscale", False))
    W = dict(
        self    = float(getattr(config, "E_w_self",   getattr(config, "alpha", 1.0))),
        align   = float(getattr(config, "E_w_align",  getattr(config, "beta",  1.0))),
        mass_q  = float(getattr(config, "belief_mass", 0.0)),
        mass_p  = float(getattr(config, "model_mass",  0.0)),
        cross   = float(getattr(config, "E_w_cross",  1.0 if enable_xscale else 0.0)),
        curv_q  = float(getattr(config, "E_w_curv_q", getattr(config, "curvature_weight", 0.0))),
        curv_p  = float(getattr(config, "E_w_curv_p", getattr(config, "model_curvature_weight", 0.0))),
    )
    # Overrides
    verbose = bool(getattr(config, "debug_energy_print", False))
    if isinstance(weights, dict):
        verbose = bool(weights.get("verbose", verbose))
        for k in ("self","align","mass_q","mass_p","cross","curv_q","curv_p"):
            if k in weights: W[k] = float(weights[k])
        if "curv" in weights:  # legacy shared curvature override
            W["curv_q"] = W["curv_p"] = float(weights["curv"])

    children = [a for a in agents if int(getattr(a, "level", 0)) == 0]
    parents  = [a for a in agents if int(getattr(a, "level", 0)) >= 1]
    parents_by_id = {int(a.id): a for a in parents}

    # Accumulators
    E_self = 0.0
    E_align_q = E_align_p = 0.0
    E_mass_q  = E_mass_p  = 0.0
    E_cross   = 0.0
    E_curv_q  = E_curv_p  = 0.0

    # Per-agent accumulation
    for A in agents:
        # inside compute_total_free_energy(...)
        
        cfg_dict = dict(vars(config))
        if ctx is not None:
            cfg_dict["ctx"] = ctx
        log_eps = float(getattr(config, "log_eps", 1e-8))
        
        E_self = 0.0
        for A in agents:
            # --- Self (identical definition to per-level logger) ---
            try:
                # uses compute_self_energy -> KL field (uncapped) -> masked sum
                E_self += float(compute_self_energy_scalar(A, log_eps, cfg_dict))
            except Exception:
                # ultra-safe fallback: still uncapped, same mask semantics
                try:
                    field = compute_self_energy(A, log_eps, cfg_dict)  # (H,W)
                    thr = float(cfg_dict.get("support_cutoff_eps", 1e-3))
                    m = (np.asarray(getattr(A, "mask", 0.0)) > thr)
                    E_self += float(np.sum(np.where(m, field, 0.0), dtype=np.float64))
                except Exception:
                    pass
        
            # --- keep your existing blocks for align/mass/curv/cross (gated by weights) ---


        # Alignment split (belief/model) using existing field helpers
        try:
            field_q = compute_alignment_field_general(agents, A.id, field_type="belief", ctx=ctx)
            eq, _ = robust_aggregate_kl(field_q, A.mask,
                                        cap=float(getattr(config, "signal_kl_cap", 1000.0)))
            E_align_q += float(eq)
        except Exception:
            if verbose:
                import traceback; print("[energy] align belief failed:", traceback.format_exc())

        try:
            field_p = compute_alignment_field_general(agents, A.id, field_type="model", ctx=ctx)
            ep, _ = robust_aggregate_kl(field_p, A.mask,
                                        cap=float(getattr(config, "signal_kl_cap", 1000.0)))
            E_align_p += float(ep)
        except Exception:
            if verbose:
                import traceback; print("[energy] align model failed:", traceback.format_exc())

        # Gauge mass (q/p)
        try:
            emq, emp = _gauge_mass_energy_for_agent(A)
            E_mass_q += float(emq); E_mass_p += float(emp)
        except Exception:
            if verbose:
                import traceback; print("[energy] mass term failed:", traceback.format_exc())

        # Curvature (q/p raw) — NEW: doesn’t depend on any weight here
        try:
            cq, cp = _curvature_energy_for_agent(
                A, generators_q=generators_q, generators_p=generators_p, ctx=ctx
            )
            E_curv_q += float(cq); E_curv_p += float(cp)
        except Exception:
            if verbose:
                import traceback; print("[energy] curvature term failed:", traceback.format_exc())

    # Cross-scale
    if W["cross"] != 0.0 and enable_xscale:
        for C in children:
            try:
                E_cross += _crossscale_energy_for_child(C, parents_by_id, ctx=ctx)
            except Exception:
                if verbose:
                    import traceback; print("[energy] cross-scale failed:", traceback.format_exc())

    # Weighted total
    total = (
        W["self"]   * E_self +
        W["align"]  * (E_align_q + E_align_p) +
        W["mass_q"] * E_mass_q +
        W["mass_p"] * E_mass_p +
        W["cross"]  * E_cross +
        W["curv_q"] * E_curv_q +
        W["curv_p"] * E_curv_p
    )

    breakdown = dict(
        self=E_self,
        align_q=E_align_q, align_p=E_align_p, align=(E_align_q + E_align_p),
        mass_q=E_mass_q, mass_p=E_mass_p,
        cross=E_cross,
        curv_q=E_curv_q, curv_p=E_curv_p, curv=(E_curv_q + E_curv_p),
        total=total, weights=W
    )

    if verbose:
        sc = lambda x: f"{x:.6e}"
        w  = W
        print("\n[Energy Breakdown]\n"
              f"  E_total = {sc(total)}\n"
              "  ------------------------------------\n"
              "  term               weighted                raw     weight\n"
              f"  self           {sc(w['self']*E_self):>12}  {sc(E_self):>12}  {w['self']:.0f}\n"
              f"  align_q        {sc(w['align']*E_align_q):>12}  {sc(E_align_q):>12}  {w['align']:.0f}\n"
              f"  align_p        {sc(w['align']*E_align_p):>12}  {sc(E_align_p):>12}  {w['align']:.0f}\n"
              f"  mass_q         {sc(w['mass_q']*E_mass_q):>12}  {sc(E_mass_q):>12}  {w['mass_q']:.0f}\n"
              f"  mass_p         {sc(w['mass_p']*E_mass_p):>12}  {sc(E_mass_p):>12}  {w['mass_p']:.0f}\n"
              f"  cross          {sc(w['cross']*E_cross):>12}  {sc(E_cross):>12}  {w['cross']:.0f}\n"
              f"  curv_q         {sc(w['curv_q']*E_curv_q):>12}  {sc(E_curv_q):>12}  {w['curv_q']:.0f}\n"
              f"  curv_p         {sc(w['curv_p']*E_curv_p):>12}  {sc(E_curv_p):>12}  {w['curv_p']:.0f}\n"
              "  ------------------------------------\n"
              f"  align_sum      {sc(w['align']*(E_align_q+E_align_p)):>12}  {sc(E_align_q+E_align_p):>12}          —\n"
              f"  curv_sum       {sc(w['curv_q']*E_curv_q + w['curv_p']*E_curv_p):>12}  {sc(E_curv_q+E_curv_p):>12}          —\n")
    return total, breakdown





# =========================
# TOTAL (weighted) energy
# =========================

def _pull(d, k, default=0.0):
    try:
        return float((d or {}).get(k, default))
    except Exception:
        return float(default)

def _total_energy_from_record(rec, weights=None):
    """
    Compute a *weighted* total from the standard scalar energy keys produced by log_all_metrics:
      e_self, e_feedback, e_align, e_mod_align, e_curv, e_curv_mod, e_mass, e_mass_mod

    Weights come from config (with safe defaults) but can be overridden by `weights` dict.
    """
    import core.config as _cfg

    W = dict(
        self      = float(getattr(_cfg, "E_w_self",       1.0)),
        feedback  = float(getattr(_cfg, "E_w_feedback",   1.0)),
        align     = float(getattr(_cfg, "E_w_align",      1.0)),
        mod_align = float(getattr(_cfg, "E_w_mod_align",  1.0)),
        curv      = float(getattr(_cfg, "E_w_curv",       0.0)),
        curv_mod  = float(getattr(_cfg, "E_w_curv_mod",   0.0)),
        mass      = float(getattr(_cfg, "E_w_mass",       0.0)),
        mass_mod  = float(getattr(_cfg, "E_w_mass_mod",   0.0)),
    )
    if isinstance(weights, dict):
        for k, v in weights.items():
            if k in W:
                W[k] = float(v)

    total = (
        W["self"]      * _pull(rec, "e_self")      +
        W["feedback"]  * _pull(rec, "e_feedback")  +
        W["align"]     * _pull(rec, "e_align")     +
        W["mod_align"] * _pull(rec, "e_mod_align") +
        W["curv"]      * _pull(rec, "e_curv")      +
        W["curv_mod"]  * _pull(rec, "e_curv_mod")  +
        W["mass"]      * _pull(rec, "e_mass")      +
        W["mass_mod"]  * _pull(rec, "e_mass_mod")
    )
    return float(total)

















# ============================================================
# Metrics (strict-SPD): per-agent + parent/morphism/Λ logging
# ============================================================


# ---- cheap defaults for a single agent row ----
def zero_agent_metrics() -> dict:
    # Minimal schema: energies, gauge norms, optional Λ/morphism, optional grad norms.
    return {
        "e_self": 0.0, "e_feedback": 0.0,
        "e_align": 0.0, "e_mod_align": 0.0,
        "e_curv": 0.0, "e_curv_mod": 0.0,
        "e_mass": 0.0, "e_mass_mod": 0.0,

        "phi_norm": 0.0,          # sum over support of ‖φ‖
        "phi_model_norm": 0.0,    # sum over support of ‖φ̃‖

        # Optional (only if enabled via logging flags)
        "lambda_q_dn_norm": np.nan, "lambda_q_up_norm": np.nan,
        "lambda_p_dn_norm": np.nan, "lambda_p_up_norm": np.nan,
        "morphism_q2p_norm": np.nan, "morphism_p2q_norm": np.nan,

        # Optional gradient norms
        "grad_phi_norm": np.nan, "grad_phi_model_norm": np.nan,
    }


def compute_all_agent_metrics(i, agent, Q_list, P_list, Mask_list, cfg, gens, log_eps) -> dict:
   
    stats = zero_agent_metrics()

    mask = Mask_list[i]
    if not np.any(mask):
        return stats

    (mu_q, Sig_q) = Q_list[i]
    (mu_p, Sig_p) = P_list[i]

    # ---------------- weights & thresholds ----------------
    alpha = float(cfg.get("alpha", cfg.get("self_weight", 0.0)))
    lam   = float(cfg.get("lambda_feedback", cfg.get("lambda", cfg.get("feedback_weight", 0.0))))
    thr   = float(cfg.get("support_cutoff_eps", getattr(config, "support_tau", 1e-3)))

    # ---------------- Self energy: α * KL(q || Φ̃·p) ----------------
    stats["e_self"] = 0.0
    if alpha != 0.0 and np.any(mask):
        try:
            stats["e_self"] = float(compute_self_energy_scalar(agent, log_eps, cfg))
        except Exception:
            # Fallback: map p→q via Φ̃, then KL(q || Φ̃·p) on support (robust field)
            try:
                Phi_tilde = getattr(agent, "bundle_morphism_p_to_q", None)
                if Phi_tilde is not None:
                    try:
                        # prefer natural-parameter safe morphism if present
                        mu_pq, S_pq = safe_batch_apply_morphism_nat(
                            agent.mu_p_field, agent.sigma_p_field, Phi_tilde, eps=log_eps
                        )
                    except Exception:
                        # very conservative fallback: do nothing if unavailable
                        mu_pq, S_pq = None, None

                    if mu_pq is not None and S_pq is not None:
                        try:
                            field = kl_divergence_field_auto(
                                mu1=agent.mu_q_field, S1=agent.sigma_q_field,
                                mu2=mu_pq,          S2=S_pq,
                                mask=agent.mask,    morphism=Phi_tilde,
                                eps=log_eps,
                            )
                            stats["e_self"] = float(np.nan_to_num(field[agent.mask > thr].sum(),
                                                                          nan=0.0, posinf=0.0, neginf=0.0))
                        except Exception:
                            # if robust field fn missing/failed, leave at 0.0
                            pass
            except Exception:
                pass

    # ---------------- Feedback: λ * KL(p || Φ·q) ----------------
    stats["e_feedback"] = 0.0
    if lam != 0.0 and np.any(mask):
        try:
            stats["e_feedback"] = float(compute_feedback_energy_scalar(agent, log_eps, cfg))
        except Exception:
            try:
                Phi = getattr(agent, "bundle_morphism_q_to_p", None)
                if Phi is not None:
                    try:
                        mu_qp, S_qp = safe_batch_apply_morphism_nat(
                            agent.mu_q_field, agent.sigma_q_field, Phi, eps=log_eps
                        )
                    except Exception:
                        mu_qp, S_qp = None, None

                    if mu_qp is not None and S_qp is not None:
                        try:
                            field = kl_divergence_field_auto(
                                mu1=agent.mu_p_field, S1=agent.sigma_p_field,
                                mu2=mu_qp,          S2=S_qp,
                                mask=agent.mask,    morphism=Phi,
                                eps=log_eps,
                            )
                            stats["e_feedback"] = float( np.nan_to_num(field[agent.mask > thr].sum(),
                                                                            nan=0.0, posinf=0.0, neginf=0.0))
                        except Exception:
                            pass
            except Exception:
                pass

    # ---------------- Alignment fields → sum on support ----------------
    overlap_eps = float(cfg.get("overlap_eps", getattr(config, "overlap_eps", 1e-6)))
    KLq = compute_alignment_field_general(
        agents=cfg["agents_ref"], i=i, field_type="belief",
        eps=overlap_eps, log_eps=log_eps, ctx=cfg.get("ctx")
    )
    KLp = compute_alignment_field_general(
        agents=cfg["agents_ref"], i=i, field_type="model",
        eps=overlap_eps, log_eps=log_eps, ctx=cfg.get("ctx")
    )
    stats["e_align"]     = config.beta*_sum_over_mask(KLq, mask)
    stats["e_mod_align"] = config.beta_model*_sum_over_mask(KLp, mask)

    # ---------------- Curvature (only if weights ≠ 0) ----------------
    def _get(cfgdict, *names, default=0.0):
        for n in names:
            if n in cfgdict: return cfgdict[n]
        return default

    def _frob_sq_sum(F):  # F: (..., K, K) -> (...,)
        return np.einsum("...ij,...ij->...", F, F, optimize=True)

    try:
        dx = float(cfg.get("dx", getattr(config, "dx", 1.0)))
        w_curv_q = float(_get(cfg, "curvature_weight", "belief_curvature_weight", default=0.0))
        w_curv_p = float(_get(cfg, "model_curvature_weight", "phi_model_curvature_weight", default=0.0))
        if w_curv_q != 0.0 and getattr(agent, "phi", None) is not None:
            Fq = compute_field_strength(np.asarray(agent.phi, np.float32),
                                        generators=np.asarray(gens[0], np.float32), dx=dx)["xy"]
            stats["e_curv"] = float(w_curv_q * _sum_over_mask(_frob_sq_sum(Fq), mask))
        if w_curv_p != 0.0 and getattr(agent, "phi_model", None) is not None:
            Fp = compute_field_strength(np.asarray(agent.phi_model, np.float32),
                                        generators=np.asarray(gens[1], np.float32), dx=dx)["xy"]
            stats["e_curv_mod"] = float(w_curv_p * _sum_over_mask(_frob_sq_sum(Fp), mask))
    except Exception:
        pass

    # ---------------- Mass (only if weights ≠ 0) ----------------
    try:
        w_mass_q = float(cfg.get("phi_mass_weight", cfg.get("belief_mass", 0.0)))
        w_mass_p = float(cfg.get("phi_model_mass_weight", cfg.get("model_mass", 0.0)))
        if w_mass_q != 0.0 and getattr(agent, "phi", None) is not None:
            stats["e_mass"] = float(compute_mass_energy(agent.phi, agent.mask, w_mass_q))
        if w_mass_p != 0.0 and getattr(agent, "phi_model", None) is not None:
            stats["e_mass_mod"] = float(compute_mass_energy(agent.phi_model, agent.mask, w_mass_p))
    except Exception:
        pass

    # ---------------- Gauge field norms (sum over support) ----------------
    try:
        stats["phi_norm"]       = _norm_over_mask(getattr(agent, "phi", None), mask)
        stats["phi_model_norm"] = _norm_over_mask(getattr(agent, "phi_model", None), mask)
    except Exception:
        pass

    # ---------------- Optional Λ / morphism norms ----------------
    logcfg = (cfg.get("logging") or {})
    if bool(logcfg.get("enable_lambda_norms", False)):
        stats.update(_lambda_norms_primary(agent, mask, ctx=cfg.get("ctx")))
    if bool(logcfg.get("enable_morphism_norms", False)):
        stats.update(_morphism_norms(agent, mask))

    # ---------------- Optional gradient norms ----------------
    gp  = getattr(agent, "grad_phi", None)
    gpt = getattr(agent, "grad_phi_tilde", None)
    if gp is not None:
        stats["grad_phi_norm"] = _norm_over_mask(gp, mask)
    if gpt is not None:
        stats["grad_phi_model_norm"] = _norm_over_mask(gpt, mask)

    return stats



def compute_agent_metrics(i: int, agent, Q_list, P_list, Mask_list, cfg, gens, log_eps) -> tuple[int, dict]:
    mask = Mask_list[i]
    if not np.any(mask):
        return i, zero_agent_metrics()
    stats = compute_all_agent_metrics(i, agent, Q_list, P_list, Mask_list, cfg, gens, log_eps)
    return i, stats



def log_agent_metrics(agent, step: int, stats: dict, normalize=True):
 
    eps = float(getattr(config, "support_cutoff_eps", 1e-6))
    S = float((np.asarray(agent.mask) > eps).sum()) or 1.0
    if not normalize:
        S = 1.0

    # safe getter
    def g(k, default=np.nan):
        v = stats.get(k, default)
        try:
            return float(v)
        except Exception:
            return default

    row = {
        # normalized energies
        "kl_self":            g("e_self", 0.0)      / S,
        "kl_feedback":        g("e_feedback", 0.0)  / S,
        "kl_align":           g("e_align", 0.0)     / S,
        "kl_mod_align":       g("e_mod_align", 0.0) / S,
        "curv_energy":        g("e_curv", 0.0)      / S,
        "curv_model_energy":  g("e_curv_mod", 0.0)  / S,
        "mass_energy":        g("e_mass", 0.0)      / S,
        "mass_model_energy":  g("e_mass_mod", 0.0)  / S,

        # already support-reduced in stats (keep as-is)
        "phi_norm":           g("phi_norm"),
        "phi_model_norm":     g("phi_model_norm"),

        # Optional Λ/morphism/grad norms (may be NaN if disabled/missing)
        "lambda_q_dn_norm":   g("lambda_q_dn_norm"),
        "lambda_q_up_norm":   g("lambda_q_up_norm"),
        "lambda_p_dn_norm":   g("lambda_p_dn_norm"),
        "lambda_p_up_norm":   g("lambda_p_up_norm"),
        "morphism_q2p_norm":  g("morphism_q2p_norm"),
        "morphism_p2q_norm":  g("morphism_p2q_norm"),
        "grad_phi_norm":      g("grad_phi_norm"),
        "grad_phi_model_norm": g("grad_phi_model_norm"),
    }
    agent.log_metrics(step, row)



def log_all_metrics(
    agents, step: int, params=None,
    q_field: str = "q", p_field: str = "p",
    phi_belief_field: str = "phi", phi_model_field: str = "phi_model",
    mask_field: str = "mask", n_jobs: int = -1
) -> dict:
   
    
    # dict-based cfg
    cfg = dict(vars(config))
    if params:
        cfg.update(params)
    logcfg = cfg.get("logging", {}) or {}
    log_eps = float(cfg.get("log_eps", 1e-10))
    ctx = cfg.get("ctx", None)

    # Generators (once)
    K_q = int(cfg.get("K_q", 5)); K_p = int(cfg.get("K_p", 5))
    name = cfg.get("group_name", "so3")
    gen_q = _resolve_generators(name, K_q)
    gen_p = _resolve_generators(name, K_p)
    gens = (gen_q, gen_p)

    # Precompute views
    Q_list = [(np.asarray(A.mu_q_field), np.asarray(A.sigma_q_field)) for A in agents]
    P_list = [(np.asarray(A.mu_p_field), np.asarray(A.sigma_p_field)) for A in agents]
    # --- support threshold (prefer support_tau, else support_cutoff_eps) ---
    eps_tau = cfg.get("support_tau", None)
    if eps_tau is None:
        eps_tau = cfg.get("support_cutoff_eps", 1e-6)
    try:
        eps_tau = float(eps_tau)
    except Exception:
        eps_tau = 1e-6
    
    def _safe_support_mask(m, thr):
        import numpy as _np
        m = _np.asarray(m, _np.float32)
        M = (m > float(thr))
        if not M.any():
            # Fallbacks: try a gentler cutoff, then "any positive"
            M = (m > (float(thr) * 0.1))
        if not M.any():
            M = (m > 0.0)
        return M
    
    Mask_list = [_safe_support_mask(getattr(A, mask_field), eps_tau) for A in agents]


    cfg_workers = dict(cfg)
    cfg_workers["agents_ref"] = agents
    cfg_workers["ctx"] = ctx

    # Per-agent stats
    results = Parallel(n_jobs=n_jobs, backend="threading", batch_size=1)(
        delayed(compute_agent_metrics)(
            i, agents[i], Q_list, P_list, Mask_list, cfg_workers, gens, log_eps
        )
        for i in range(len(agents))
    )

    # Accumulate unnormalized energies (we'll normalize once, globally)
    energy_keys = ["e_self", "e_feedback", "e_align", "e_mod_align",
                   "e_curv", "e_curv_mod", "e_mass", "e_mass_mod"]
    accum = {k: 0.0 for k in energy_keys}

    # Per-agent logging rows (normalized per agent if requested)
    norm_by_support = bool(logcfg.get("normalize_by_support", True))
    for i, stats in results:
        for k in energy_keys:
            accum[k] += float(stats.get(k, 0.0))
        log_agent_metrics(agents[i], step, stats, normalize=norm_by_support)

    # Global normalization by total support (for flat totals only)
    eps = float(cfg.get("support_cutoff_eps", getattr(config, "support_cutoff_eps", 1e-6)))
    total_support = int(sum((np.asarray(a.mask) > eps).sum() for a in agents)) or 1
    S = float(total_support) if norm_by_support else 1.0

    flat = {k: accum[k] / S for k in energy_keys}
    flat["total_energy"]   = float(sum(flat[k] for k in energy_keys))
    flat["support_total"]  = int(total_support)
    flat["step"]           = int(step)

    # Optional: parent rows (kept tiny / toggle off by default)
    if bool(logcfg.get("log_parent_rows", False)):
        rows = log_parent_metrics(agents, step=step, cfg=cfg_workers, generators=gens, ctx=ctx)
        flat["parent_rows"] = rows

    # Return just the flat energy dict (caller prints/merges as needed)
    return flat

# ---------- parent rows (enriched: Λ, morphisms, overlap coverage) ----------


def compute_parent_metrics(P, children=None, thr=0.30, cfg=None, generators=None, *, ctx=None) -> dict:
    """
    Summarize one parent agent — cheap by default.
    Heavy parts (Λ counts, cross-scale KL means) are gated by cfg flags:
      cfg['log_lambda_counts'], cfg['log_parent_kl_means']
    """
    cfg = (cfg or {})
    want_lambda = bool(cfg.get("log_lambda_counts", False))
    want_kl = bool(cfg.get("log_parent_kl_means", False))

    # Robust children map (accept list or dict)
    def _iter_agents(ob):
        if ob is None:
            return ()
        if isinstance(ob, dict):
            return (v for v in ob.values() if v is not None)
        return (v for v in ob if v is not None)

    children_map = {int(getattr(a, "id")): a for a in _iter_agents(children)}

    kid_ids = list(getattr(P, "child_ids", []) or [])
    n_kids = len(kid_ids)

    stats = {
        "support_px": int(np.sum((np.asarray(P.mask) > thr).astype(np.int64))),
        "level": int(getattr(P, "level", 0)),
        "n_children": int(n_kids),
        "has_Phi_q_to_p": bool(getattr(P, "bundle_morphism_q_to_p", None) is not None),
        "has_Phi_p_to_q": bool(getattr(P, "bundle_morphism_p_to_q", None) is not None),
    }

    m = np.asarray(P.mask) > thr
    stats["phi_norm"] = _norm_over_mask(getattr(P, "phi", None), m)
    stats["phi_model_norm"] = _norm_over_mask(getattr(P, "phi_model", None), m)

    # Λ availability via central transport cache (optional)
    if want_lambda and ctx is not None and n_kids:
        lambda_q_ok = lambda_p_ok = 0
        try:
            
            for cid in kid_ids:
                ch = children_map.get(int(cid))
                if ch is None:
                    continue
                try:
                    if Lambda_dn(ctx, ch, P, which="q") is not None:
                        lambda_q_ok += 1
                except Exception:
                    pass
                try:
                    if Lambda_dn(ctx, ch, P, which="p") is not None:
                        lambda_p_ok += 1
                except Exception:
                    pass
        except Exception:
            lambda_q_ok = lambda_p_ok = 0
        stats["lambda_q_ok"] = int(lambda_q_ok)
        stats["lambda_p_ok"] = int(lambda_p_ok)

    # Cross-scale KL summaries (optional)
    if want_kl and ctx is not None and n_kids:
        try:
            vals_q = []
            for cid in kid_ids:
                ch = children_map.get(int(cid))
                if ch is None:
                    continue
                v = compute_crossscale_kl_q_single(ch, P, eps=1e-6, ctx=ctx)
                if np.isfinite(v): vals_q.append(v)
            if vals_q:
                stats["kl_q_mean"] = float(np.mean(vals_q))
        except Exception:
            pass
        try:
            vals_p = []
            for cid in kid_ids:
                ch = children_map.get(int(cid))
                if ch is None:
                    continue
                v = compute_crossscale_kl_p_single(ch, P, eps=1e-6, ctx=ctx)
                if np.isfinite(v): vals_p.append(v)
            if vals_p:
                stats["kl_p_mean"] = float(np.mean(vals_p))
        except Exception:
            pass

    return stats

def log_parent_metrics(parents, step: int, cfg=None, generators=None, thr=0.3, *, ctx=None) -> list[dict]:
    rows = []
    cfg = cfg or {}
    for pid, P in enumerate(parents):
        s = compute_parent_metrics(
            P,
            children=(P.child_ids and getattr(P, "_children_ref", None)),
            thr=thr, cfg=cfg, generators=generators, ctx=ctx
        )
        s["step"] = int(step)
        s["parent"] = int(pid)
        rows.append(s)
    return rows


def log_parent_metrics_with_children(parents, children, step: int, cfg=None, generators=None, thr=0.3, *, ctx=None) -> list[dict]:
    rows = []
    for pid, P in enumerate(parents):
        s = compute_parent_metrics(P, children=children, thr=thr, cfg=cfg, generators=generators, ctx=ctx)
        s["step"] = step
        s["parent"] = pid
        rows.append(s)
    return rows


# =============================================================================
#                           Snapshot (debugging)
# =============================================================================

def dump_snapshot_npz(
    agents,
    step: int,
    outdir: str,
    *,
    include=("mu_q", "sigma_q", "phi", "mu_p", "sigma_p", "phi_model", "mask"),
    compute_alignment: bool = False,
    compute_curvature: bool = False,
    fp16: bool = True,
    params: dict | None = None,
) -> str:
    """
    Lightweight, fiber-aware snapshot of fields for debugging/analysis.

    Adds:
      - agent_ids:    (N,)  int32
      - agent_levels: (N,)  int16

    All arrays are allocated writable & C-contiguous.
    Values are clamped/denaned to avoid dtype overflows during cast.
    """
    

    # ---------------- dtypes & helpers ----------------
    tgt_dtype = np.float16 if fp16 else np.float32
    finfo = np.finfo(tgt_dtype)
    # keep a generous safety margin below max to avoid rounding to inf in fp16
    _CLIP_MAX = float(min(1e30, finfo.max * 0.9))
    _CLIP_MIN = float(max(-1e30, finfo.min * 0.9)) if np.issubdtype(tgt_dtype, np.floating) else 0.0

    def _safe_to_dtype(x, *, dtype=tgt_dtype, clip_hi=_CLIP_MAX, clip_lo=_CLIP_MIN):
        a = np.asarray(x, np.float64)                            # work in f64
        a = np.nan_to_num(a, posinf=clip_hi, neginf=clip_lo)
        a = np.clip(a, clip_lo, clip_hi)
        # If it looks like SPD (...,K,K), lightly symmetrize (visual/diagnostic only)
        if a.ndim >= 2 and a.shape[-1] == a.shape[-2]:
            a = 0.5 * (a + np.swapaxes(a, -1, -2))
        # Always return a fresh, writable, C-contiguous array
        return np.ascontiguousarray(a, dtype=dtype)

    # --------------- shape introspection ---------------
    N = len(agents)
    assert N > 0, "dump_snapshot_npz: no agents"
    H, W = agents[0].mu_q_field.shape[:2]

    # Infer K_q/K_p from fields (prefer actual tensors over config to avoid drift)
    K_q = int(agents[0].mu_q_field.shape[-1])
    K_p = int(agents[0].mu_p_field.shape[-1])
    # Fallback to cov shapes if needed
    if getattr(agents[0], "sigma_q_field", None) is not None:
        K_q = int(agents[0].sigma_q_field.shape[-1])
    if getattr(agents[0], "sigma_p_field", None) is not None:
        K_p = int(agents[0].sigma_p_field.shape[-1])

    # Phi channel count (usually 3)
    C_phi = int(getattr(agents[0].phi, "shape", (None, None, 3))[-1] or 3)
    C_phm = C_phi
    if getattr(agents[0], "phi_model", None) is not None:
        C_phm = int(agents[0].phi_model.shape[-1])

    # --------------- schema & containers ---------------
    schema = "v3"
    if hasattr(config, "logging") and isinstance(config.logging, dict):
        schema = config.logging.get("schema_version", schema)
    if params and isinstance(params, dict):
        schema = params.get("logging", {}).get("schema_version", schema)

    out = {"schema": schema}
    out["agent_ids"]    = np.ascontiguousarray(
        [int(getattr(a, "id", i)) for i, a in enumerate(agents)], dtype=np.int32
    )
    out["agent_levels"] = np.ascontiguousarray(
        [int(getattr(a, "level", 0)) for a in agents], dtype=np.int16
    )

    # Allocate writable, C-contiguous target buffers
    if "mu_q"      in include: out["mu_q"]      = np.empty((N, H, W, K_q),      dtype=tgt_dtype, order="C")
    if "sigma_q"   in include: out["sigma_q"]   = np.empty((N, H, W, K_q, K_q), dtype=tgt_dtype, order="C")
    if "phi"       in include: out["phi"]       = np.empty((N, H, W, C_phi),    dtype=tgt_dtype, order="C")
    if "mu_p"      in include: out["mu_p"]      = np.empty((N, H, W, K_p),      dtype=tgt_dtype, order="C")
    if "sigma_p"   in include: out["sigma_p"]   = np.empty((N, H, W, K_p, K_p), dtype=tgt_dtype, order="C")
    if "phi_model" in include: out["phi_model"] = np.empty((N, H, W, C_phm),    dtype=tgt_dtype, order="C")
    if "mask"      in include: out["mask"]      = np.empty((N, H, W),           dtype=tgt_dtype, order="C")

    if compute_alignment:
        out["belief_align"] = np.empty((N, H, W), dtype=tgt_dtype, order="C")
        out["model_align"]  = np.empty((N, H, W), dtype=tgt_dtype, order="C")
    if compute_curvature:
        out["Fq_norm"] = np.empty((N, H, W), dtype=tgt_dtype, order="C")
        out["Fp_norm"] = np.empty((N, H, W), dtype=tgt_dtype, order="C")

    # --------------- fill (write-safe) ---------------
    for i, A in enumerate(agents):
        if "mu_q" in include and getattr(A, "mu_q_field", None) is not None:
            out["mu_q"][i, ...] = _safe_to_dtype(A.mu_q_field)

        if "sigma_q" in include and getattr(A, "sigma_q_field", None) is not None:
            _require_spd_field(A.sigma_q_field, K_q, "Σ_q")
            out["sigma_q"][i, ...] = _safe_to_dtype(A.sigma_q_field)

        if "phi" in include and getattr(A, "phi", None) is not None:
            out["phi"][i, ...] = _safe_to_dtype(A.phi)

        if "mu_p" in include and getattr(A, "mu_p_field", None) is not None:
            out["mu_p"][i, ...] = _safe_to_dtype(A.mu_p_field)

        if "sigma_p" in include and getattr(A, "sigma_p_field", None) is not None:
            _require_spd_field(A.sigma_p_field, K_p, "Σ_p")
            out["sigma_p"][i, ...] = _safe_to_dtype(A.sigma_p_field)

        if "phi_model" in include and getattr(A, "phi_model", None) is not None:
            out["phi_model"][i, ...] = _safe_to_dtype(A.phi_model)

        if "mask" in include and getattr(A, "mask", None) is not None:
            out["mask"][i, ...] = _safe_to_dtype(A.mask)

    # --------------- optional heavy bits ---------------
    if compute_alignment or compute_curvature:
        name = getattr(config, "group_name", "so3")
        Gq = _resolve_generators(name, K_q); Gp = _resolve_generators(name, K_p)
        if isinstance(Gq, dict): Gq = Gq.get("generators", Gq)
        if isinstance(Gp, dict): Gp = Gp.get("generators", Gp)

        if compute_curvature:
            dx = float(getattr(config, "dx", 1.0))
            for i, A in enumerate(agents):
                if getattr(A, "phi", None) is not None:
                    Fq = compute_field_strength(np.asarray(A.phi, np.float32), np.asarray(Gq, np.float32), dx=dx)["xy"]
                    out["Fq_norm"][i, ...] = _safe_to_dtype(np.linalg.norm(Fq, axis=(-2, -1)))
                if getattr(A, "phi_model", None) is not None:
                    Fp = compute_field_strength(np.asarray(A.phi_model, np.float32), np.asarray(Gp, np.float32), dx=dx)["xy"]
                    out["Fp_norm"][i, ...] = _safe_to_dtype(np.linalg.norm(Fp, axis=(-2, -1)))

    # --------------- save -----------------------------
    Path(outdir).mkdir(parents=True, exist_ok=True)
    fname = str(Path(outdir) / f"step_{step:04d}.npz")
    # Ensure all arrays are writable (paranoia against inherited RO flags)
    for k, v in list(out.items()):
        if isinstance(v, np.ndarray) and not v.flags.writeable:
            out[k] = np.ascontiguousarray(v)  # makes a writable copy
    np.savez_compressed(fname, **out)
    return fname



def get_support_mask(mask: np.ndarray, eps: float = None) -> np.ndarray:
    """Boolean mask where agent has support (soft mask > eps)."""
    if eps is None:
        eps = config.support_cutoff_eps
    return np.asarray(mask, np.float32) > float(eps)


def threshold_mask(mask: np.ndarray, eps: float = None) -> np.ndarray:
    """Alias for get_support_mask for compatibility."""
    return get_support_mask(mask, eps)



def _support_mask(a, tau=None):
    tau = float(config.support_cutoff_eps if tau is None else tau)
    return (np.asarray(a, np.float32) > tau)


def _support_size(mask): return int(np.sum(np.asarray(mask, np.float32) > 0.0))


def _sum_over_mask(x, m):
    if x is None:
        return 0.0
    return float(np.sum(np.where(m, x, 0.0), dtype=np.float64))


def _norm_over_mask(v, m):
    if v is None:
        return 0.0
    vn = np.linalg.norm(np.asarray(v), axis=-1)
    return _sum_over_mask(vn, m)


def _eig_stats(SIG, mask, eps=0.0):
    H, W, K, _ = SIG.shape
    idx = np.flatnonzero(np.asarray(mask).ravel())
    if idx.size == 0:
        return dict(min_eig=np.nan, max_eig=np.nan, clipped=0, cond=np.nan)
    mats = SIG.reshape(H * W, K, K)[idx]
    I = np.eye(K, dtype=mats.dtype)
    mats = 0.5 * (mats + np.swapaxes(mats, -1, -2)) + eps * I
    w = np.linalg.eigvalsh(mats)
    w_min = np.min(w, axis=1)
    w_max = np.max(w, axis=1)
    cond = w_max / np.maximum(w_min, 1e-30)
    return dict(
        min_eig=float(np.nanmin(w_min)),
        max_eig=float(np.nanmax(w_max)),
        cond=float(np.nanmean(cond)),
        clipped=int(np.sum(w_min < getattr(config, "sigma_eig_floor", -np.inf))),
    )



def _fro_map(M):  # (..., K, K) -> (...,)
    M = np.asarray(M, np.float32)
    return np.sqrt(np.einsum("...ij,...ij->...", M, M, optimize=True))

def _reduce_over_mask(arr, mask, how="sum"):
    arr = np.asarray(arr, np.float32)
    m = np.asarray(mask, bool)
    if not m.any():
        return 0.0 if how in ("sum", "mean") else np.nan
    if how == "sum":
        return float(arr[m].sum())
    if how == "mean":
        return float(arr[m].mean())
    return float(arr[m].sum())

def _select_primary_parent(agent, ctx):
    # choose first listed parent id
    pids = list(getattr(agent, "parent_ids", []) or [])
    if not pids:
        return None
    pid = int(pids[0])
    # resolve from ctx if available
    if ctx is not None and hasattr(ctx, "parents_by_region"):
        P = ctx.parents_by_region.get(pid)
        if P is not None:
            return P
        # fallback linear scan
        for v in getattr(ctx, "parents_by_region", {}).values():
            if int(getattr(v, "id", -1)) == pid:
                return v
    return None



def _as_float32(x):
    return None if x is None else np.asarray(x, dtype=np.float32)


def _safe_symmetrize(S):
    return 0.5 * (S + np.swapaxes(S, -1, -2))


def _apply_linear_morphism(mu, Sigma, L, eps=1e-8):
    """
    Apply y = L x for Gaussian fields:
      μ' = L μ
      Σ' = L Σ L^T
    """
    mu = _as_float32(mu)
    Sigma = _as_float32(Sigma)
    L = _as_float32(L)

    if L is None:
        return mu, sanitize_sigma(Sigma, eps=eps)

    mu_t = np.einsum("...oi,...i->...o", L, mu, optimize=True)
    S_mid = np.einsum("...oi,...ij->...oj", L, Sigma, optimize=True)
    S_t = np.einsum("...oj,...kj->...ok", S_mid, L, optimize=True)

    S_t = _safe_symmetrize(S_t)
    S_t = sanitize_sigma(S_t, eps=eps)
    return mu_t, S_t


def _masked_overlap(child_mask, parent_mask, thr=1e-3):
    return (np.asarray(child_mask) > thr) & (np.asarray(parent_mask) > thr)


def _finite_mean(x):
    x = np.asarray(x, dtype=np.float64)
    x = x[np.isfinite(x)]
    return float(np.mean(x)) if x.size else np.nan


def _require_spd_field(S, K, name="Σ"):
    if S.ndim != 4 or S.shape[-2:] != (K, K):
        raise ValueError(f"{name} must be full SPD (H,W,{K},{K}); got {S.shape}")
    return S


def _require_full_spd_field(S, name="Σ"):
    if S.ndim != 4 or S.shape[-2] != S.shape[-1]:
        raise ValueError(f"{name} must be full SPD with shape (H,W,K,K); got {S.shape}")
    return S


def _prep_fields_for_alignment(agents, *, which="belief", log_eps=1e-8):
    field_list, mask_list = [], []
    for A in agents:
        if which == "belief":
            mu, S = A.mu_q_field, A.sigma_q_field
        else:
            mu, S = A.mu_p_field, A.sigma_p_field
        S_full = _require_full_spd_field(S, name="Σ_field")
        S_full = sanitize_sigma(S_full, eps=log_eps)
        field_list.append((mu, S_full))
        mask_list.append(A.mask)
    return field_list, mask_list
