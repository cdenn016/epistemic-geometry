# -*- coding: utf-8 -*-
"""
omega.py — Lie-group exponentials, transports, BCH helpers, and curvature ops.
CacheHub-ready: uses ctx.cache namespaces 'exp' and 'omega' when provided.

Author: c&c
"""
from __future__ import annotations

from typing import Tuple, Dict

from typing import Optional, Iterable
import warnings
import numpy as np
from scipy.linalg import expm

import core.config as config
from core.numerical_utils import sanitize_sigma, safe_omega_inv
# omega.py (top of file)

# NEW: import pure math from core
from core.group import (
    exp_lie_algebra_irrep,
    
    bch as _bch_core,
    safe_bch_exact as _safe_bch_core,
)



# Public API
__all__ = [
    "batch_apply_omega",
    "bch",
    "safe_bch_exact",
    "adaptive_expm",
    "adaptive_expm_batch",
    "d_exp_phi_exact",
    "d_exp_phi_tilde_exact",
    "compute_gauge_potential",
    "compute_field_strength",
    "compute_field_strength_general",
    "compute_curvature_gradient_analytical",
    "compute_intra_omega",
]


# =============================================================================
#                               Cache helpers
# =============================================================================

def _arr_key(a):
    a = np.asarray(a)
    # (data pointer, shape, dtype) — stable and cheap
    return (int(a.__array_interface__['data'][0]), a.shape, a.dtype.str)





# =============================================================================
#                          Exponentials / Transports
# =============================================================================



# =============================================================================
#                  Algebra exponentials — Taylor / expm hybrid
# =============================================================================

def adaptive_expm(G, clip_norm=None, max_norm=None, threshold=1e-3):
    """
    Robust expm(G) with optional norm clipping and 4th-order Taylor near identity.
    """
    if not np.all(np.isfinite(G)):
        raise ValueError("[adaptive_expm] Input contains NaN/Inf")
    nG = np.linalg.norm(G, ord=np.inf) + 1e-16
    if max_norm is not None and nG > max_norm:
        G = G * (max_norm / nG)
        nG = max_norm
    elif clip_norm is not None and nG > clip_norm:
        G = G * (clip_norm / nG)
        nG = clip_norm
    if nG < threshold:
        I = np.eye(G.shape[0], dtype=G.dtype)
        G2, G3, G4 = G @ G, None, None
        G3 = G2 @ G
        G4 = G2 @ G2
        out = I + G + 0.5 * G2 + (1/6) * G3 + (1/24) * G4
    else:
        out = expm(G)
    return np.nan_to_num(out, nan=0.0, posinf=1e6, neginf=-1e6)


def adaptive_expm_batch(G_batch, n_jobs=-1, clip_norm=None, max_norm=None, threshold=1e-3, parallel_threshold=64):
    """
    Batched expm with optional threading for large batches.
    """
    G_batch = np.asarray(G_batch)
    N = G_batch.shape[0]
    if N == 0:
        return G_batch
    if N < parallel_threshold:
        return np.stack([adaptive_expm(G_batch[i], clip_norm, max_norm, threshold) for i in range(N)], axis=0)
    from joblib import Parallel, delayed, parallel_backend
    with parallel_backend("threading"):
        results = Parallel(n_jobs=n_jobs, batch_size=8)(
            delayed(adaptive_expm)(G_batch[i], clip_norm, max_norm, threshold) for i in range(N)
        )
    return np.stack(results, axis=0)




def QQbch(A, B, max_norm=10.0, inf_tol=1e6, verbose=False):
    return _bch_core(A, B, max_norm=max_norm, inf_tol=inf_tol, verbose=verbose)

def QQsafe_bch_exact(A, B, max_norm=5.0, verbose=False):
    return _safe_bch_core(A, B, max_norm=max_norm, verbose=verbose)




# =============================================================================
#                       Exact dexp derivatives for SO(3)
# =============================================================================



def d_exp_phi_exact(
    phi_vec: np.ndarray,
    generators: np.ndarray,
    *,
    exp_phi_all: Optional[np.ndarray] = None,
    eps: float = 1e-12,
) -> Iterable[np.ndarray]:
    """
    ∂/∂φ^a e^{Φ} with Φ = Σ_a φ^a G_a  (SO(3) left-trivialized).
    Returns [dE/dφ^0, dE/dφ^1, dE/dφ^2], each (...,K,K).
    """
    phi_vec = np.asarray(phi_vec, dtype=np.float32)
    G = np.asarray(generators, dtype=np.float32)

    *shape, d = phi_vec.shape
    assert d == 3, "d_exp_phi_exact assumes SO(3) (d=3)."
    K = int(G.shape[-1])
    N = int(np.prod(shape)) if shape else 1

    φ = phi_vec.reshape(N, 3)                                 # (N,3)
    Φ = np.einsum("na,aij->nij", φ, G, optimize=True)         # (N,K,K)

    θ = np.linalg.norm(φ, axis=1)                             # (N,)
    c1 = np.empty_like(θ, dtype=np.float32)
    c2 = np.empty_like(θ, dtype=np.float32)
    small = θ < 1e-4
    if np.any(small):
        t = θ[small]; t2 = t*t; t4 = t2*t2
        c1[small] = 0.5 - t2/24.0 + t4/720.0
        c2[small] = 1.0/6.0 - t2/120.0 + t4/5040.0
    big = ~small
    if np.any(big):
        tb = θ[big]
        c1[big] = (1.0 - np.cos(tb)) / np.maximum(tb*tb, eps)
        c2[big] = (tb - np.sin(tb)) / np.maximum(tb*tb*tb, eps)

    if exp_phi_all is None:
        from core.group import exp_lie_algebra_irrep
        E = exp_lie_algebra_irrep(φ, G, parallelize_expm=False)  # (N,K,K)
    else:
        E = np.asarray(exp_phi_all, dtype=np.float32).reshape(N, K, K)

    # Commutators: ad_Φ(G_a) = [Φ, G_a], ad_Φ^2(G_a) = [Φ, [Φ, G_a]]
    ΦN = Φ[None, ...]                        # (1,N,K,K)
    G_A = G[:, None, :, :]                   # (3,1,K,K)

    # [Φ, G_a] = Φ G_a − G_a Φ  -> (3,N,K,K)
    comm1 = (ΦN @ G_A) - (G_A @ ΦN)

    # [Φ, [Φ, G_a]] -> (3,N,K,K)
    comm2 = (ΦN @ comm1) - (comm1 @ ΦN)

    # Q_a = G_a − c1 ad_Φ(G_a) + c2 ad_Φ^2(G_a)
    Q = G_A - c1[None, :, None, None] * comm1 + c2[None, :, None, None] * comm2  # (3,N,K,K)

    # d e^{Φ} / dφ^a = E · Q_a
    dE = np.einsum("nij,anjk->anik", E, Q, optimize=True)     # (3,N,K,K)
    dE = dE.reshape(3, *shape, K, K).astype(np.float32, copy=False)
    return [dE[i] for i in range(3)]


def d_exp_phi_tilde_exact(
    phi_tilde_vec: np.ndarray,
    generators: np.ndarray,
    *,
    exp_phi_tilde_all: Optional[np.ndarray] = None,
    eps: float = 1e-12,
):
    """
    Companion for φ̃; same construction and signs.
    """
    φ̃ = np.asarray(phi_tilde_vec, dtype=np.float32)
    G = np.asarray(generators, dtype=np.float32)

    *shape, d = φ̃.shape
    assert d == 3, "d_exp_phi_tilde_exact assumes SO(3) (d=3)."
    K = int(G.shape[-1])
    N = int(np.prod(shape)) if shape else 1

    φ = φ̃.reshape(N, 3)
    Φ = np.einsum("na,aij->nij", φ, G, optimize=True)         # (N,K,K)

    θ = np.linalg.norm(φ, axis=1)
    c1 = np.empty_like(θ, dtype=np.float32)
    c2 = np.empty_like(θ, dtype=np.float32)
    small = θ < 1e-4
    if np.any(small):
        t = θ[small]; t2 = t*t; t4 = t2*t2
        c1[small] = 0.5 - t2/24.0 + t4/720.0
        c2[small] = 1.0/6.0 - t2/120.0 + t4/5040.0
    big = ~small
    if np.any(big):
        tb = θ[big]
        c1[big] = (1.0 - np.cos(tb)) / np.maximum(tb*tb, eps)
        c2[big] = (tb - np.sin(tb)) / np.maximum(tb*tb*tb, eps)

    if exp_phi_tilde_all is None:
        from core.group import exp_lie_algebra_irrep
        E = exp_lie_algebra_irrep(φ, G, parallelize_expm=False)
    else:
        E = np.asarray(exp_phi_tilde_all, dtype=np.float32).reshape(N, K, K)

    ΦN = Φ[None, ...]
    G_A = G[:, None, :, :]
    comm1 = (ΦN @ G_A) - (G_A @ ΦN)
    comm2 = (ΦN @ comm1) - (comm1 @ ΦN)
    Q = G_A - c1[None, :, None, None] * comm1 + c2[None, :, None, None] * comm2

    dE = np.einsum("nij,anjk->anik", E, Q, optimize=True)
    dE = dE.reshape(3, *shape, K, K).astype(np.float32, copy=False)
    return [dE[i] for i in range(3)]



# =============================================================================
#                         Apply Ω to Gaussian fields
# =============================================================================

def batch_apply_omega(mu_batch, sigma_batch, omega_batch, eps=1e-8):
    """
    Legacy alias: μ' = Ω μ,  Σ' = Ω Σ Ωᵀ
    """
    from core.gaussian_core import push_gaussian
    return push_gaussian(mu_batch, sigma_batch, omega_batch,
                         eps=eps, symmetrize=True, sanitize=True,
                         approx="exact", return_inv=False)


# =============================================================================
#                             Curvature operators
# =============================================================================

def compute_gauge_potential(phi, dx=1.0):
    """
    A_μ^a = ∂_μ φ^a using central differences (periodic BC). Returns a tuple over μ.
    """
    if phi.ndim < 2:
      raise ValueError("phi must have at least one spatial and one Lie algebra dimension.")
    D = phi.ndim - 1
    return tuple((np.roll(phi, -1, axis=μ) - np.roll(phi, 1, axis=μ)) / (2.0 * dx) for μ in range(D))


def compute_field_strength(phi: np.ndarray, generators: np.ndarray, dx: float = 1.0) -> Dict[str, np.ndarray]:
    """
    2D nonabelian field strength F_{xy} from φ^a and generators.
    Returns {"xy": F_xy} with shape (H,W,K,K).
    """
    H, W, d = phi.shape
    phi = np.asarray(phi, np.float32)
    G   = np.asarray(generators, np.float32)

    Phi = np.einsum("hwd,dkm->hwkm", phi, G)  # (H,W,K,K)

    A_x = (np.roll(Phi, -1, 0) - np.roll(Phi, 1, 0)) / (2 * dx)
    A_y = (np.roll(Phi, -1, 1) - np.roll(Phi, 1, 1)) / (2 * dx)

    dAy_dx = (np.roll(A_y, -1, 0) - np.roll(A_y, 1, 0)) / (2 * dx)
    dAx_dy = (np.roll(A_x, -1, 1) - np.roll(A_x, 1, 1)) / (2 * dx)

    comm = np.einsum("...ij,...jk->...ik", A_x, A_y) - np.einsum("...ij,...jk->...ik", A_y, A_x)
    F_xy = dAy_dx - dAx_dy + comm
    return {"xy": F_xy.astype(np.float32, copy=False)}


def compute_field_strength_general(phi: np.ndarray, generators: np.ndarray, dx: float = 1.0) -> Dict[Tuple[int,int], np.ndarray]:
    """
    All nonabelian curvature components F_{μν} for φ on a D-dim grid.
    """
    phi = np.asarray(phi, np.float32)
    G   = np.asarray(generators, np.float32)
    Phi = np.einsum("...d,dkm->...km", phi, G)
    D = phi.ndim - 1
    F: Dict[Tuple[int,int], np.ndarray] = {}

    A = [(np.roll(Phi, -1, mu) - np.roll(Phi, 1, mu)) / (2 * dx) for mu in range(D)]

    for mu in range(D):
        for nu in range(mu + 1, D):
            dA_nu_mu = (np.roll(A[nu], -1, mu) - np.roll(A[nu], 1, mu)) / (2 * dx)
            dA_mu_nu = (np.roll(A[mu], -1, nu) - np.roll(A[mu], 1, nu)) / (2 * dx)
            comm = np.einsum("...ij,...jk->...ik", A[mu], A[nu]) - np.einsum("...ij,...jk->...ik", A[nu], A[mu])
            F[(mu, nu)] = (dA_nu_mu - dA_mu_nu + comm).astype(np.float32, copy=False)
    return F


def compute_curvature_gradient_analytical(phi, generators, dx: float = 1.0, metric_ab: np.ndarray | None = None):
    """
    ∇_φ Tr(F^2). If generators aren't trace-orthonormal, pass metric_ab = [Tr(G^a G^b)].
    """
    H, W, d = phi.shape
    phi = np.asarray(phi, np.float32)
    G   = np.asarray(generators, np.float32)

    A_x = (np.roll(phi, -1, 0) - np.roll(phi, 1, 0)) / (2 * dx)
    A_y = (np.roll(phi, -1, 1) - np.roll(phi, 1, 1)) / (2 * dx)

    A_x_mat = np.einsum("hwd,dkm->hwkm", A_x, G)
    A_y_mat = np.einsum("hwd,dkm->hwkm", A_y, G)

    dAy_dx = (np.roll(A_y_mat, -1, 0) - np.roll(A_y_mat, 1, 0)) / (2 * dx)
    dAx_dy = (np.roll(A_x_mat, -1, 1) - np.roll(A_x_mat, 1, 1)) / (2 * dx)
    comm_xy = A_x_mat @ A_y_mat - A_y_mat @ A_x_mat
    F_xy = dAy_dx - dAx_dy + comm_xy

    dF_dx = (np.roll(F_xy, -1, 0) - np.roll(F_xy, 1, 0)) / (2 * dx)
    dF_dy = (np.roll(F_xy, -1, 1) - np.roll(F_xy, 1, 1)) / (2 * dx)
    comm1 = A_x_mat @ F_xy - F_xy @ A_x_mat
    comm2 = A_y_mat @ F_xy - F_xy @ A_y_mat
    divF = dF_dx + dF_dy + comm1 + comm2

    if metric_ab is None:
        grad = 2.0 * np.stack([np.einsum("...ij,ij->...", divF, G[a]) for a in range(d)], axis=-1)
    else:
        Ginvs = safe_omega_inv(metric_ab.astype(np.float64, copy=False))
        comps = np.array([np.einsum("...ij,ij->...", divF, G[a]) for a in range(d)])  # (d,H,W)
        grad = 2.0 * np.einsum("ab,b...->a...", Ginvs, comps).transpose(1, 2, 0)
    return grad.astype(np.float32, copy=False)


# =============================================================================
#                       Holonomy / transport helpers
# =============================================================================

def compute_intra_omega(agent, coord_from, coord_to, generators=None, *, fiber="q"):
    """
    Ω(p_to ← p_from) within a single agent: exp(φ(to)) · exp(−φ(from)).
    """
    if coord_from == coord_to:
        K = (generators.shape[-1] if generators is not None
             else getattr(agent, "generators_q" if fiber == "q" else "generators_p").shape[-1])
        return np.eye(K, dtype=np.float32)

    if generators is None:
        generators = getattr(agent, "generators_q" if fiber == "q" else "generators_p")

    phi_field = agent.phi if fiber == "q" else agent.phi_model
    φ_from = np.asarray(phi_field[coord_from], np.float32)
    φ_to   = np.asarray(phi_field[coord_to],   np.float32)

    Ei  = exp_lie_algebra_irrep(φ_to[None], generators, parallelize_expm=False)[0]
    Emj = exp_lie_algebra_irrep((-φ_from)[None], generators, parallelize_expm=False)[0]
    return (Ei @ Emj).astype(np.float32, copy=False)
