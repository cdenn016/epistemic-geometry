
import numpy as np
from core.omega import (compute_curvature_gradient_analytical)
from core.natural_gradient import compute_fisher_geometry_gradient
from core.numerical_utils import safe_inv, sanitize_sigma, safe_omega_inv
 
from transport.transport_cache import (E_grid, Jinv_grid, 
                                       Omega, build_dexpinv_matrix )
import inspect
from core.omega import d_exp_phi_exact, d_exp_phi_tilde_exact
from core.group import exp_lie_algebra_irrep
#==============================================================================
#
#                    GATHER PHI GAUGE FIELD GRADIENT TERMS
#                          Beliefs and Models
#==============================================================================



def accumulate_phi_alignment_gradient(
    agent_i, agent_j, generators, params,
    field="phi", beta_key=None, omega_cache_key=None,
    mu_key=None, sigma_key=None,
    fisher_inv_key=None, grad_key=None,
    Q_all_i=None,           # list/array (d, ..., K, K)
    exp_neg_phi_j=None,     # (..., K, K)
    agents=None,            # for Fisher regularizer
):
    """
    Same-level φ/φ̃ alignment gradient:
      - computes ∂ KL_i←j / ∂φ_i in parameter coords
      - pre/post maps via Jinv as covector/vector respectively
      - adds Lie-natural regularizers (already in body frame)
    """
    # --- safe locals (avoid relying on module-level imports)
    import core.config as config
    # grad_kl_wrt_phi_i, apply_regularization_terms_lie_natural are in this module

    assert mu_key and sigma_key and fisher_inv_key and grad_key, \
        "mu_key/sigma_key/fisher_inv_key/grad_key are required"

    beta = params.get(beta_key, getattr(config, beta_key, 0.0)) if beta_key else float(params.get("beta", 0.0))
    if beta <= 0.0:
        return

    ctx = params.get("runtime_ctx", None) or params.get("ctx", None)

    # joint mask (broadcasts to (..., 1))
    eps_sup = float(getattr(config, "support_cutoff_eps", 1e-6))
    joint_mask = ((np.asarray(agent_i.mask) > eps_sup) & (np.asarray(agent_j.mask) > eps_sup)).astype(np.float32)[..., None]
    if not np.any(joint_mask):
        return

    # fields
    mu_i    = np.asarray(getattr(agent_i, mu_key),    np.float32)
    sigma_i = np.asarray(getattr(agent_i, sigma_key), np.float32)
    mu_j    = np.asarray(getattr(agent_j, mu_key),    np.float32)

    which = "q" if field == "phi" else "p"

    # transports (cache if possible)
    if ctx is not None:
        from transport.transport_cache import E_grid, Omega
        E_i = E_grid(ctx, agent_i, which=which)
        E_j = E_grid(ctx, agent_j, which=which)
        Omega_ij = Omega(ctx, agent_i, agent_j, which=which)
    else:
        phi_i_loc = np.asarray(getattr(agent_i, field), np.float32)
        phi_j_loc = np.asarray(getattr(agent_j, field), np.float32)
        E_i = exp_lie_algebra_irrep(phi_i_loc, generators)
        E_j = exp_lie_algebra_irrep(phi_j_loc, generators)
        Omega_ij = np.matmul(E_i, safe_omega_inv(E_j, eps=float(getattr(config, "eps", 1e-6))))

    Omega_T = np.swapaxes(Omega_ij, -1, -2)

    # push μ_j and Σ_j^{-1} correctly
    mu_j_t = np.einsum("...ij,...j->...i", Omega_ij, mu_j, optimize=True)
    inv_key = sigma_key.replace("_field", "_inv")
    sigma_j_inv = getattr(agent_j, inv_key, None)

    if sigma_j_inv is not None:
        # CORRECT mapping for an inverse: Σ′⁻¹ = Ω⁻ᵀ Σ⁻¹ Ω⁻¹
        Oinv   = safe_omega_inv(Omega_ij, eps=float(getattr(config, "eps", 1e-6)), debug=False)
        Oinv_T = np.swapaxes(Oinv, -1, -2)
        sigma_j_t_inv = np.einsum("...ik,...kl,...jl->...ij", Oinv_T, np.asarray(sigma_j_inv, np.float32), Oinv, optimize=True)
    else:
        # Map Σ then invert: Σ′ = Ω Σ Ωᵀ,  Σ′⁻¹ = (Σ′)⁻¹
        sigma_j = sanitize_sigma(np.asarray(getattr(agent_j, sigma_key), np.float32),
                                 eps=float(getattr(config, "eps", 1e-6)))
        sigma_j_t = np.einsum("...ik,...kl,...jl->...ij", Omega_ij, sigma_j, Omega_T, optimize=True)
        sigma_j_t = sanitize_sigma(sigma_j_t, eps=float(getattr(config, "eps", 1e-6)))
        sigma_j_t_inv = safe_inv(sigma_j_t, eps=float(getattr(config, "eps", 1e-6)))

    # Jacobians for exp(φ_i)/exp(-φ_j) if not provided
    if Q_all_i is None:
        if field == "phi":
            Q_all_i = d_exp_phi_exact(np.asarray(getattr(agent_i, field), np.float32), generators)
        else:
            Q_all_i = d_exp_phi_tilde_exact(np.asarray(getattr(agent_i, field), np.float32), generators)
    if exp_neg_phi_j is None:
        exp_neg_phi_j = safe_omega_inv(E_j, eps=float(getattr(config, "eps", 1e-6)), debug=False)

    # ---- raw parameter-covector grad ∂L/∂φ (…a)
    grad_param = grad_kl_wrt_phi_i(
        mu_i, sigma_i,
        None, None,
        phi_i=np.asarray(getattr(agent_i, field), np.float32),
        phi_j=None,
        Omega_ij=Omega_ij,
        generators=generators,
        exp_phi_i=E_i,
        exp_phi_j=E_j,
        mu_j_t=mu_j_t,
        sigma_j_t_inv=sigma_j_t_inv,
        eps=float(getattr(config, "eps", 1e-6)),
        exp_neg_phi_j=exp_neg_phi_j,
        Q_all=Q_all_i,
    ).astype(np.float32, copy=False)

    # ---- J^{-T}: parameter covector -> body covector
    Jinv = Jinv_grid(ctx, agent_i, which=which) if ctx is not None else None
    if Jinv is None:
        Jinv = build_dexpinv_matrix(np.asarray(getattr(agent_i, field), np.float32))
    g_body_cov = np.einsum("...ji,...j->...i", Jinv, grad_param, optimize=True)

    # ---- Fisher^{-1} in body frame
    F_inv = getattr(agent_i, fisher_inv_key, None)
    if F_inv is not None:
        v_body = np.einsum("...ab,...b->...a", np.asarray(F_inv, np.float32), g_body_cov, optimize=True)
    else:
        v_body = g_body_cov

    # ---- add regularizers (already NATURAL/body)
    reg_nat = apply_regularization_terms_lie_natural(
        agent=agent_i,
        phi_field=np.asarray(getattr(agent_i, field), np.float32),
        generators=generators,
        field=field,
        params={**params, "step_tag": getattr(ctx, "global_step", None) if ctx is not None else None},
        agents=agents,
        ctx=ctx,
    ).astype(np.float32, copy=False)
    v_body_total = v_body + reg_nat

    # ---- J^{-1}: body vector -> parameter vector
    v_param = np.einsum("...ab,...b->...a", Jinv, v_body_total, optimize=True)

    # ---- accumulate (mask and weight)
    grad_accum = getattr(agent_i, grad_key, None)
    if grad_accum is None:
        grad_accum = np.zeros_like(v_param, dtype=np.float32)
    setattr(agent_i, grad_key, grad_accum + (beta * v_param) * joint_mask)


def accumulate_phi_morphism_self_feedback(
    agent_i,
    generators_src, generators_tgt,
    params,
    field="phi",                # or "phi_model"
    fisher_inv_key=None,
    grad_key=None,
    phi_self_func=None,
    phi_feedback_func=None,
):
    
    import core.config as config
    
    # --- call helper respects callee signature (avoids passing unknown kwargs)
    def _call_sig_aware(fn, **kwargs):
        if fn is None:
            return None
        sig = inspect.signature(fn).parameters
        return fn(**{k: v for k, v in kwargs.items() if k in sig})

    alpha   = float(params.get("alpha",           getattr(config, "alpha",           1.0)))
    lambda_ = float(params.get("feedback_weight", getattr(config, "feedback_weight", 0.0)))
    if alpha <= 0.0 and lambda_ <= 0.0:
        return

    eps_sup = float(getattr(config, "support_cutoff_eps", 1e-6))
    mask = (np.asarray(agent_i.mask) > eps_sup)[..., None].astype(np.float32)

    mu_q, sigma_q = agent_i.mu_q_field, agent_i.sigma_q_field
    mu_p, sigma_p = agent_i.mu_p_field, agent_i.sigma_p_field
    phi       = np.asarray(agent_i.phi,       np.float32)
    phi_tilde = np.asarray(agent_i.phi_model, np.float32)

    ctx = params.get("runtime_ctx", None)

    # exp(φ) on q-fiber; exp(φ̃) on p-fiber
    exp_phi       = E_grid(ctx, agent_i, which="q") if ctx is not None else exp_lie_algebra_irrep(phi,       generators_tgt)
    exp_phi_tilde = E_grid(ctx, agent_i, which="p") if ctx is not None else exp_lie_algebra_irrep(phi_tilde, generators_src)

    # choose field + Jinv + which fiber; set generator roles clearly
    if field == "phi":
        which = "q"
        base_field = phi
        Jinv = Jinv_grid(ctx, agent_i, which="q") if ctx is not None else build_dexpinv_matrix(base_field)
        G_src, G_tgt = generators_src, generators_tgt   # φ lives in q-fiber; target = G_q (=generators_tgt)
    else:
        which = "p"
        base_field = phi_tilde
        Jinv = Jinv_grid(ctx, agent_i, which="p") if ctx is not None else build_dexpinv_matrix(base_field)
        # φ̃ lives in p-fiber; swap roles so target = G_p
        G_src, G_tgt = generators_tgt, generators_src

    # Fisher^{-1} in body frame (vector)
    F_inv = getattr(agent_i, fisher_inv_key, None)
    def _apply_F_inv_body(vec_body):
        if F_inv is None:
            return vec_body
        Fi = np.asarray(F_inv, np.float32)
        if Fi.ndim >= 2 and Fi.shape[-2:] == (3, 3):
            return np.einsum("...ab,...b->...a", Fi, vec_body, optimize=True)
        if Fi.ndim == 1 and Fi.shape[-1] == 3:
            return vec_body * Fi
        return vec_body  # fallback: ignore malformed Fisher

    def _accum_term(grad_param_eucl, weight):
        if grad_param_eucl is None or weight <= 0.0:
            return
        grad_param = np.asarray(grad_param_eucl, np.float32)

        # parameter covector -> body covector (Jinv^T)
        g_body_cov = np.einsum("...ji,...j->...i", Jinv, grad_param, optimize=True)
        # Fisher^{-1} in body frame
        v_body = _apply_F_inv_body(g_body_cov)
        # body vector -> parameter vector (Jinv)
        v_param = np.einsum("...ab,...b->...a", Jinv, v_body, optimize=True)

        acc = getattr(agent_i, grad_key, None)
        if acc is None:
            acc = np.zeros_like(v_param, dtype=np.float32)
        setattr(agent_i, grad_key, acc + weight * v_param * mask)

    Phi_0       = getattr(agent_i, "Phi_0", None)
    Phi_tilde_0 = getattr(agent_i, "Phi_tilde_0", None)

    # ---- SELF term ----
    if alpha > 0.0 and phi_self_func is not None:
        if field == "phi":
            # grad_self_phi_direct(..., Phi_tilde_0, ...)
            args = dict(
                mu_q=mu_q, sigma_q=sigma_q,
                mu_p=mu_p, sigma_p=sigma_p,
                Phi_tilde_0=Phi_tilde_0,
                phi=phi, phi_tilde=phi_tilde,
                exp_phi=exp_phi, exp_phi_tilde=exp_phi_tilde,
                eps=float(getattr(config, "eps", 1e-6)),
                generators_q=G_tgt,   # q-fiber target
                generators_p=G_src,   # p-fiber source
            )
        else:  # field == "phi_model"
            # grad_self_phi_tilde_direct(..., Phi_tilde_0, ...)
            args = dict(
                mu_q=mu_q, sigma_q=sigma_q,
                mu_p=mu_p, sigma_p=sigma_p,
                Phi_tilde_0=Phi_tilde_0,
                phi=phi, phi_tilde=phi_tilde,
                exp_phi=exp_phi, exp_phi_tilde=exp_phi_tilde,
                eps=float(getattr(config, "eps", 1e-6)),
                generators_q=G_src,   # p-fiber path uses p generators where needed
                generators_p=G_tgt,
            )
        grad_self_param = _call_sig_aware(phi_self_func, **args)
        _accum_term(grad_self_param, alpha)

    # ---- FEEDBACK term ----
    if lambda_ > 0.0 and phi_feedback_func is not None:
        if field == "phi":
            # grad_feedback_phi_direct(..., Phi_0, ...)
            args = dict(
                mu_p=mu_p, sigma_p=sigma_p,
                mu_q=mu_q, sigma_q=sigma_q,
                Phi_0=Phi_0,
                phi=phi, phi_tilde=phi_tilde,
                exp_phi=exp_phi, exp_phi_tilde=exp_phi_tilde,
                eps=float(getattr(config, "eps", 1e-6)),
                generators_q=G_tgt,
            )
        else:  # field == "phi_model"
            # grad_feedback_phi_tilde_direct(..., Phi_0, ...)
            args = dict(
                mu_p=mu_p, sigma_p=sigma_p,
                mu_q=mu_q, sigma_q=sigma_q,
                Phi_0=Phi_0,
                phi=phi, phi_tilde=phi_tilde,
                exp_phi=exp_phi, exp_phi_tilde=exp_phi_tilde,
                eps=float(getattr(config, "eps", 1e-6)),
                generators_p=G_src, generators_q=G_tgt,
            )
        grad_fb_param = _call_sig_aware(phi_feedback_func, **args)
        _accum_term(grad_fb_param, lambda_)









def qqaccumulate_phi_alignment_gradient(
    agent_i, agent_j, generators, params,
    field="phi", beta_key=None, omega_cache_key=None,
    mu_key=None, sigma_key=None,
    fisher_inv_key=None, grad_key=None,
    Q_all_i=None,           # list/array (d, ..., K, K)
    exp_neg_phi_j=None,     # (..., K, K)
    agents=None,            # for Fisher regularizer
):
    """
    Compute and accumulate ∇_φ alignment term for agent_i against agent_j,
    plus regularizers. Uses central transport cache when ctx is provided.
    """
    import core.config as config

    assert mu_key and sigma_key and fisher_inv_key and grad_key, "mu_key/sigma_key/fisher_inv_key/grad_key are required"

    # --- weights & context
    beta = params.get(beta_key, getattr(config, beta_key, 0.0)) if beta_key else float(params.get("beta", 0.0))
    if beta <= 0.0:
        return
    ctx = params.get("runtime_ctx", None) or params.get("ctx", None)

    # --- overlap / joint mask
    eps = float(getattr(config, "support_cutoff_eps", 1e-6))
    joint_mask = ((np.asarray(agent_i.mask) > eps) & (np.asarray(agent_j.mask) > eps)).astype(np.float32)[..., None]
    if not np.any(joint_mask):
        return

    # --- fields
    mu_i    = np.asarray(getattr(agent_i, mu_key),    np.float32)
    sigma_i = np.asarray(getattr(agent_i, sigma_key), np.float32)
    mu_j    = np.asarray(getattr(agent_j, mu_key),    np.float32)

    # Choose fiber from field name
    which = "q" if field == "phi" else "p"

    # --- transports: cache fast path
    if ctx is not None:
        E_i = E_grid(ctx, agent_i, which=which)                 # (...,K,K)
        E_j = E_grid(ctx, agent_j, which=which)                 # (...,K,K)
        Omega_ij = Omega(ctx, agent_i, agent_j, which=which)    # (...,K,K)
    else:
        
        phi_i = np.asarray(getattr(agent_i, field), np.float32)
        phi_j = np.asarray(getattr(agent_j, field), np.float32)
        E_i = exp_lie_algebra_irrep(phi_i, generators)
        E_j = exp_lie_algebra_irrep(phi_j, generators)
        Omega_ij = np.matmul(E_i, safe_omega_inv(E_j, eps=float(getattr(config, "eps", 1e-6))))

    Omega_T = np.swapaxes(Omega_ij, -1, -2)

    # μ_j pushed to i
    mu_j_t = np.einsum("...ij,...j->...i", Omega_ij, mu_j, optimize=True)

    # Σ_j^{-1} push
    inv_key = sigma_key.replace("_field", "_inv")
    sigma_j_inv = getattr(agent_j, inv_key, None)
    if sigma_j_inv is not None:
        sigma_j_t_inv = np.einsum("...ik,...kl,...lj->...ij", Omega_ij, sigma_j_inv, Omega_T, optimize=True)
    else:
        
        sigma_j = sanitize_sigma(np.asarray(getattr(agent_j, sigma_key), np.float32), eps=float(getattr(config, "eps", 1e-6)))
        sigma_j_t = np.einsum("...ik,...kl,...lj->...ij", Omega_ij, sigma_j, Omega_T, optimize=True)
        sigma_j_t = sanitize_sigma(sigma_j_t, eps=float(getattr(config, "eps", 1e-6)))
        sigma_j_t_inv = safe_inv(sigma_j_t, eps=float(getattr(config, "eps", 1e-6)))

    # Jacobians for exp(φ_i) and exp(-φ_j) if not provided
    
    if Q_all_i is None:
        Q_all_i = d_exp_phi_exact(np.asarray(getattr(agent_i, field), np.float32), generators)
    if exp_neg_phi_j is None:
        
        exp_neg_phi_j = safe_omega_inv(E_j, eps=float(getattr(config, "eps", 1e-6)), debug=False)

    # ---------- raw Euclidean gradient wrt φ_i (…a) ----------
    grad_phi_raw = grad_kl_wrt_phi_i(
        mu_i, sigma_i,
        None, None,
        phi_i=np.asarray(getattr(agent_i, field), np.float32),
        phi_j=None,
        Omega_ij=Omega_ij,
        generators=generators,
        exp_phi_i=E_i,
        exp_phi_j=E_j,
        mu_j_t=mu_j_t,
        sigma_j_t_inv=sigma_j_t_inv,
        eps=float(getattr(config, "eps", 1e-6)),
        exp_neg_phi_j=exp_neg_phi_j,
        Q_all=Q_all_i,
    )

    # ---------- apply Fisher^{-1} ONCE (natural frame) ----------
    F_inv = getattr(agent_i, fisher_inv_key, None)
    if F_inv is None:
        d = grad_phi_raw.shape[-1]
        F_inv = np.broadcast_to(np.eye(d, dtype=np.float32), grad_phi_raw.shape[:-1] + (d, d))
    grad_nat = np.einsum("...ab,...b->...a", F_inv, grad_phi_raw, optimize=True)

    # ---------- add regularizers in NATURAL frame ----------
    reg_nat = apply_regularization_terms_lie_natural(
        agent=agent_i,
        phi_field=np.asarray(getattr(agent_i, field), np.float32),
        generators=generators,
        field=field,
        params={**params, "step_tag": getattr(ctx, "global_step", None) if ctx is not None else None},
        agents=agents,
        ctx=ctx,
    ).astype(np.float32, copy=False)

    grad_nat_total = grad_nat + reg_nat

    # ---------- map through cached Jinv(phi) ONCE ----------
    Jinv = Jinv_grid(ctx, agent_i, which=which) if ctx is not None else None
    if Jinv is None:
        # fallback: local build if no ctx
        
        Jinv = build_dexpinv_matrix(np.asarray(getattr(agent_i, field), np.float32))
    grad_phi = np.einsum("...ab,...b->...a", Jinv, grad_nat_total, optimize=True)

    # ---------- accumulate ----------
    grad_accum = getattr(agent_i, grad_key, None)
    if grad_accum is None:
        grad_accum = np.zeros_like(grad_phi, dtype=np.float32)
    setattr(agent_i, grad_key, grad_accum + (beta * grad_phi) * joint_mask)



def qqaccumulate_phi_morphism_self_feedback(
    agent_i,
    generators_src, generators_tgt,
    params,
    field="phi",                # or "phi_model"
    fisher_inv_key=None,
    grad_key=None,
    phi_self_func=None,         # e.g. grad_self_phi_direct / grad_self_phi_tilde_direct
    phi_feedback_func=None,     # e.g. grad_feedback_phi_direct / grad_feedback_phi_tilde_direct
):
    import numpy as np
    import core.config as config
    

    def _call_sig_aware(fn, **kwargs):
        if fn is None:
            return None
        try:
            sig = inspect.signature(fn).parameters
            return fn(**{k:v for k,v in kwargs.items() if k in sig})
        except Exception:
            return fn(**kwargs)

    alpha   = float(params.get("alpha",           getattr(config, "alpha",           1.0)))
    lambda_ = float(params.get("feedback_weight", getattr(config, "feedback_weight", 0.0)))
    if alpha <= 0.0 and lambda_ <= 0.0:
        return

    eps  = float(getattr(config, "support_cutoff_eps", 1e-6))
    mask = (np.asarray(agent_i.mask) > eps)[..., None]

    mu_q, sigma_q = agent_i.mu_q_field, agent_i.sigma_q_field
    mu_p, sigma_p = agent_i.mu_p_field, agent_i.sigma_p_field
    phi           = agent_i.phi
    phi_tilde     = agent_i.phi_model

    ctx = params.get("runtime_ctx", None)
    if ctx is not None:
        exp_phi       = E_grid(ctx, agent_i, which="q")
        exp_phi_tilde = E_grid(ctx, agent_i, which="p")
    else:
        
        exp_phi       = exp_lie_algebra_irrep(phi,       generators_tgt)  # q
        exp_phi_tilde = exp_lie_algebra_irrep(phi_tilde, generators_src)  # p

    # Fisher^{-1} application helper
    F_inv = getattr(agent_i, fisher_inv_key, None)
    def _apply_metric(F_inv_, vec):
        if F_inv_ is None:
            return vec
        Fi = np.asarray(F_inv_)
        v  = np.asarray(vec)
        K  = v.shape[-1]
        if Fi.ndim == 1 and Fi.shape[-1] == K:
            return v * Fi
        if Fi.ndim == 2 and Fi.shape == (K, K):
            return np.einsum("...ab,...b->...a", Fi, v, optimize=True)
        if Fi.ndim >= 3 and Fi.shape[-2:] == (K, K):
            return np.einsum("...ab,...b->...a", Fi, v, optimize=True)
        return v

    # choose field + Jinv
    if field == "phi":
        base_field = phi
        Jinv = Jinv_grid(ctx, agent_i, which="q") if ctx is not None else None
        if Jinv is None:
            
            Jinv = build_dexpinv_matrix(np.asarray(base_field, np.float32))
    else:
        base_field = phi_tilde
        Jinv = Jinv_grid(ctx, agent_i, which="p") if ctx is not None else None
        if Jinv is None:
            
            Jinv = build_dexpinv_matrix(np.asarray(base_field, np.float32))

    # ---------- SELF term ----------
    if alpha > 0.0 and phi_self_func is not None:
        args = dict(
            mu_q=mu_q, sigma_q=sigma_q,
            mu_p=mu_p, sigma_p=sigma_p,
            Phi_0=getattr(agent_i, "Phi_0", None),
            Phi_tilde_0=getattr(agent_i, "Phi_tilde_0", None),
            phi=phi, phi_tilde=phi_tilde,
            exp_phi=exp_phi, exp_phi_tilde=exp_phi_tilde,
            eps=float(getattr(config, "eps", 1e-6)),
            generators_q=generators_tgt,  # target
            generators_p=generators_src,  # source
        )
        grad_self_eucl = _call_sig_aware(phi_self_func, **args)                  # (..., d)
        grad_self_nat  = _apply_metric(F_inv, grad_self_eucl).astype(np.float32)
        grad_self_man  = np.einsum("...ab,...b->...a", Jinv, grad_self_nat, optimize=True)
        setattr(agent_i, grad_key, getattr(agent_i, grad_key) + alpha * grad_self_man * mask)

    # ---------- FEEDBACK term ----------
    if lambda_ > 0.0 and phi_feedback_func is not None:
        args = dict(
            mu_p=mu_p, sigma_p=sigma_p,
            mu_q=mu_q, sigma_q=sigma_q,
            Phi_0=getattr(agent_i, "Phi_0", None),
            Phi_tilde_0=getattr(agent_i, "Phi_tilde_0", None),
            phi=phi, phi_tilde=phi_tilde,
            exp_phi=exp_phi, exp_phi_tilde=exp_phi_tilde,
            eps=float(getattr(config, "eps", 1e-6)),
            generators_q=generators_tgt,
            generators_p=generators_src,
        )
        grad_fb_eucl = _call_sig_aware(phi_feedback_func, **args)
        grad_fb_nat  = _apply_metric(F_inv, grad_fb_eucl).astype(np.float32)
        grad_fb_man  = np.einsum("...ab,...b->...a", Jinv, grad_fb_nat, optimize=True)
        setattr(agent_i, grad_key, getattr(agent_i, grad_key) + lambda_ * grad_fb_man * mask)


#==============================================================================
#
#                    WITH RESPECT TO phi_i TERMS
#                       VALIDATED
#==============================================================================
def grad_kl_wrt_phi_i(
    mu_i, sigma_i,
    mu_j, sigma_j,
    phi_i, phi_j,
    Omega_ij,
    generators,
    exp_phi_i,
    exp_phi_j,
    mu_j_t,
    sigma_j_t_inv,
    eps=1e-8,
    exp_neg_phi_j=None,
    Q_all=None,
):
    """
    Vectorized over Lie index a. Returns (..., d) float32.
    Robustly handles Q_all stacking/broadcasting so that:
        Q_all.shape == (..., a, K, K)
        exp_neg_phi_j.shape == (..., K, K) broadcastable to Q_all's leading dims
    """
    import numpy as _np
    # local safety imports
    from core.numerical_utils import sanitize_sigma
    from core.omega import d_exp_phi_exact, safe_omega_inv

    # ---- helpers -------------------------------------------------------------
    def _stack_Q_all_right_before_KK(Q_list_or_array, K_expected=None):
        """
        Ensure Q has shape (..., a, K, K), i.e., Lie axis 'a' is the -3 axis.
        Accepts:
          - list/tuple of length d with arrays shaped (..., K, K)
          - array with 'a' axis anywhere before the trailing K,K
        """
        if isinstance(Q_list_or_array, (list, tuple)):
            sample = Q_list_or_array[0]
            nd = sample.ndim
            Q_arr = _np.stack(Q_list_or_array, axis=nd - 2)  # insert 'a' right before K,K
        else:
            Q_arr = _np.asarray(Q_list_or_array)

        if Q_arr.ndim < 3:
            raise ValueError(f"Q_all has too few dims: {Q_arr.shape}")
        K1, K2 = Q_arr.shape[-2], Q_arr.shape[-1]
        if K_expected is not None and (K1 != K_expected or K2 != K_expected):
            raise ValueError(f"Q_all trailing dims {K1}x{K2} != expected {K_expected}x{K_expected}")
        d = int(generators.shape[0])
        if Q_arr.shape[-3] != d:
            a_axis = None
            for ax in range(Q_arr.ndim - 2):
                if Q_arr.shape[ax] == d:
                    a_axis = ax
                    break
            if a_axis is None:
                raise ValueError(f"Could not locate Lie axis of size d={d} in Q_all shape {Q_arr.shape}")
            if a_axis != Q_arr.ndim - 3:
                Q_arr = _np.moveaxis(Q_arr, a_axis, Q_arr.ndim - 3)
        return Q_arr

    def _broadcast_KK_to_leading(mat, lead_shape, K):
        M = _np.asarray(mat)
        if M.ndim < 2 or M.shape[-2:] != (K, K):
            raise ValueError(f"Expected a (...,{K},{K}) matrix; got {M.shape}")
        if M.ndim == 2:
            M = M.reshape((1,) * len(lead_shape) + (K, K))
        if M.shape[:-2] != tuple(lead_shape):
            M = _np.broadcast_to(M, tuple(lead_shape) + (K, K))
        return M

    def _broadcast_vec_to_leading(vec, lead_shape, K):
        v = _np.asarray(vec)
        if v.ndim == 1:
            v = v.reshape((1,) * len(lead_shape) + (K,))
        elif v.shape[-1] != K:
            raise ValueError(f"Vector trailing dim mismatch {v.shape[-1]} vs {K}")
        if v.shape[:-1] != tuple(lead_shape):
            v = _np.broadcast_to(v, tuple(lead_shape) + (K,))
        return v

    # ---- inputs & shapes -----------------------------------------------------
    sigma_i = sanitize_sigma(sigma_i, eps=eps)
    K = int(sigma_i.shape[-1])

    # Q_all: d Jacobians of exp(phi_i); ensure (..., a, K, K)
    if Q_all is None:
        Q_all = d_exp_phi_exact(phi_i, generators)  # list of length d
    Q = _stack_Q_all_right_before_KK(Q_all, K_expected=K)  # (..., a, K, K)

    # exp(-phi_j): prefer cached; broadcast to Q's leading dims (excluding a,K,K)
    if exp_neg_phi_j is None:
        exp_neg_phi_j = safe_omega_inv(exp_phi_j, eps=eps, debug=False)
    exp_neg_phi_j = _broadcast_KK_to_leading(exp_neg_phi_j, lead_shape=Q.shape[:-3], K=K)

    # push-forward pieces
    delta_mu = mu_i - mu_j_t  # (..., K)

    # Also reconstruct μ_j in the source frame for mean-term consistency
    Oinv = safe_omega_inv(Omega_ij, eps=eps, debug=False)  # (..., K, K)
    mu_j_src = _np.einsum("...ij,...j->...i", Oinv, mu_j_t, optimize=True)  # (..., K)

    # ---- terms ---------------------------------------------------------------
    # dΩ/dφ_i^a = Q[a] @ e^{-φ_j}
    Q = _np.einsum("...aik,...kj->...aij", Q, exp_neg_phi_j, optimize=True)  # (..., a, K, K)
    Q_T = _np.swapaxes(Q, -1, -2)  # (..., a, K, K)

    # trace term: -0.5 * [ Tr(Sj_inv Q Σi) + Tr(Q^T Sj_inv Σi) ]
    t1 = _np.einsum("...ij,...ajk,...ki->...a", sigma_j_t_inv, Q, sigma_i, optimize=True)
    t2 = _np.einsum("...aij,...jk,...ki->...a", Q_T,           sigma_j_t_inv, sigma_i, optimize=True)
    trace_term = -0.5 * (t1 + t2)  # (..., a)

    # mean term:  - μ_j^T (Sj_inv (Q^T Δμ))   with μ_j in the source frame
    tmp1 = _np.einsum("...aij,...j->...ai", Q_T, delta_mu, optimize=True)          # Q^T Δμ
    tmp2 = _np.einsum("...ij,...aj->...ai", sigma_j_t_inv, tmp1, optimize=True)    # Sj_inv (...)
    mean_term = -_np.einsum("...i,...ai->...a", mu_j_src, tmp2, optimize=True)

    # Mahalanobis term: 0.5 Δμ^T ( Q^T Sj_inv + Sj_inv Q ) Δμ
    v1 = _np.einsum("...ij,...j->...i", sigma_j_t_inv, delta_mu, optimize=True)   # Sj_inv Δμ
    part1 = _np.einsum("...aij,...j->...ai", Q_T, v1, optimize=True)              # Q^T Sj_inv Δμ
    v2 = _np.einsum("...aij,...j->...ai", Q,  delta_mu, optimize=True)            # Q Δμ
    part2 = _np.einsum("...ij,...aj->...ai", sigma_j_t_inv, v2, optimize=True)    # Sj_inv Q Δμ
    mahal_term = 0.5 * _np.einsum("...i,...ai->...a", delta_mu, part1 + part2, optimize=True)

    grad = (trace_term + mean_term + mahal_term).astype(_np.float32, copy=False)  # (..., a)
    return grad





def grad_feedback_phi_direct(
    mu_p, sigma_p,
    mu_q, sigma_q,
    Phi_0,
    phi,                # (..., d)
    phi_tilde,          # (..., d)
    generators_q,       # (d, K_q, K_q)
    exp_phi,            # (..., K_q, K_q)
    exp_phi_tilde,      # (..., K_p, K_p)
    eps=1e-8,
    # NEW optional precomputes:
    Q_all=None,         # (..., d, K_q, K_q) = d_exp_phi_exact(phi, generators_q)
    exp_neg_phi=None    # (..., K_q, K_q) = e^{-φ}
):
    """
    Vectorized over 'a': returns (..., d)
    Φ = e^{φ̃} Φ₀ e^{-φ}, ∂Φ = - Φ · (e^{-φ} (∂ e^{φ}) e^{-φ})
    """
    d, K_q, _ = generators_q.shape
    

    if exp_neg_phi is None:
        exp_neg_phi = safe_omega_inv(exp_phi, eps=eps, debug=False)
    if Q_all is None:
        # stack as (..., d, K_q, K_q)
        Q_list = d_exp_phi_exact(phi, generators_q)
        Q_all = np.stack(Q_list, axis=-3)  # assuming list of d arrays

    # Φ and Φᵀ
    Phi = np.einsum("...ik,...kj,...jl->...il", exp_phi_tilde, Phi_0, exp_neg_phi)
    Phi_T = np.swapaxes(Phi, -1, -2)


    # A, A^{-1}
    A = np.einsum("...ik,...kl,...lj->...ij", Phi, sigma_q, Phi_T)
    A = sanitize_sigma(A, eps=eps)
    A_inv = safe_inv(A, eps=eps)

    # Δμ and v
    Phi_mu_q = np.einsum("...ij,...j->...i", Phi, mu_q)
    delta_mu = mu_p - Phi_mu_q
    v = np.einsum("...ij,...j->...i", A_inv, delta_mu)  # (..., K_p)

    # Q̄_a = e^{-φ} Q_a e^{-φ}
    Q_bar = np.einsum("...ik,...akl,...lj->...aij", exp_neg_phi, Q_all, exp_neg_phi)

    # dΦ_a = - Φ Q̄_a
    dPhi = -np.einsum("...ik,...akj->...aij", Phi, Q_bar)
    dPhi_T = np.swapaxes(dPhi, -1, -2)

    # dA_a
    dA = (
        np.einsum("...aik,...kl,...lj->...aij", dPhi, sigma_q, Phi_T) +
        np.einsum("...ik,...kl,...alj->...aij", Phi,  sigma_q, dPhi_T)
    )

    # Term 1
    dPhi_mu = np.einsum("...aij,...j->...ai", dPhi, mu_q)       # (..., a, K_p)
    term1 = -np.einsum("...ai,...i->...a", dPhi_mu, v)

    # Term 2
    term2 = 0.5 * np.einsum("...ij,...aij->...a", A_inv, dA)

    # M_a = A^{-1} dA_a A^{-1}
    M = np.einsum("...ij,...ajk,...kl->...ail", A_inv, dA, A_inv)

    # Term 3
    term3 = -0.5 * np.einsum("...i,...aij,...j->...a", delta_mu, M, delta_mu)

    # Term 4
    term4 = -0.5 * np.einsum("...aij,...ji->...a", M, sigma_p)

    grad = (term1 + term2 + term3 + term4).astype(np.float32, copy=False)
    return grad


def grad_feedback_phi_tilde_direct(
    mu_p, sigma_p,
    mu_q, sigma_q,
    Phi_0,
    phi, phi_tilde,
    generators_p, generators_q,
    exp_phi, exp_phi_tilde,
    eps=1e-8,
    # NEW optional precomputes:
    Q_tilde_all=None,       # (..., d, K_p, K_p) = d_exp_phi_tilde_exact(phi_tilde, generators_p)
    exp_neg_phi_tilde=None  # (..., K_p, K_p) = e^{-φ̃}
):
    """
    Vectorized over 'a': returns (..., d)
    Left-trivialize: dΦ_a = L_a Φ,  L_a = (∂e^{φ̃}/∂φ̃^a) e^{-φ̃}.
    """
    d, K_p, _ = generators_p.shape
    

    if exp_neg_phi_tilde is None:
        exp_neg_phi_tilde = safe_omega_inv(exp_phi_tilde, eps=eps, debug=False)
    if Q_tilde_all is None:
        Q_list = d_exp_phi_tilde_exact(phi_tilde, generators_p)
        Q_tilde_all = np.stack(Q_list, axis=-3)

    # Φ
    exp_neg_phi = safe_omega_inv(exp_phi, eps=eps, debug=False)
    Phi   = np.einsum("...ik,...kj,...jl->...il", exp_phi_tilde, Phi_0, exp_neg_phi)
    Phi_T = np.swapaxes(Phi, -1, -2)

  
    A = np.einsum("...ik,...kl,...lj->...ij", Phi, sigma_q, Phi_T)
    A = sanitize_sigma(A, eps=eps)
    A_inv = safe_inv(A, eps=eps)

    Phi_mu_q = np.einsum("...ij,...j->...i", Phi, mu_q)
    delta_mu = mu_p - Phi_mu_q
    v = np.einsum("...ij,...j->...i", A_inv, delta_mu)

    # L_a = Q̃_a e^{-φ̃}
    L = np.einsum("...aik,...kj->...aij", Q_tilde_all, exp_neg_phi_tilde)

    # dΦ_a = L_a Φ
    dPhi = np.einsum("...aik,...kj->...aij", L, Phi)
    dPhi_T = np.swapaxes(dPhi, -1, -2)

    dA = (
        np.einsum("...aik,...kl,...lj->...aij", dPhi, sigma_q, Phi_T) +
        np.einsum("...ik,...kl,...alj->...aij", Phi,  sigma_q, dPhi_T)
    )

    dPhi_mu = np.einsum("...aij,...j->...ai", dPhi, mu_q)
    term1 = -np.einsum("...ai,...i->...a", dPhi_mu, v)

    term2 = 0.5 * np.einsum("...ij,...aij->...a", A_inv, dA)

    M = np.einsum("...ij,...ajk,...kl->...ail", A_inv, dA, A_inv)

    term3 = -0.5 * np.einsum("...i,...aij,...j->...a", delta_mu, M, delta_mu)
    term4 = -0.5 * np.einsum("...aij,...ji->...a", M, sigma_p)

    grad = term1 + term2 + term3 + term4
    return grad



def grad_self_phi_direct(
    mu_q, sigma_q,
    mu_p, sigma_p,
    Phi_tilde_0,
    phi, phi_tilde,
    generators_q, generators_p,
    exp_phi, exp_phi_tilde,
    eps=1e-8,
    # NEW optional precomputes:
    Q_all=None,               # (..., d, K_q, K_q)
    exp_neg_phi_tilde=None    # (..., K_p, K_p)
):
    """
    Vectorized over 'a': returns (..., d)
    Φ̃ = e^{φ} Φ̃₀ e^{-φ̃},  ∂Φ̃_a = (∂e^{φ}/∂φ^a) Φ̃₀ e^{-φ̃}.
    """
    d, K_q, _ = generators_q.shape
    

    if exp_neg_phi_tilde is None:
        exp_neg_phi_tilde = safe_omega_inv(exp_phi_tilde, eps=eps, debug=False)
    if Q_all is None:
        Q_list = d_exp_phi_exact(phi, generators_q)
        Q_all = np.stack(Q_list, axis=-3)

    # Φ̃ and A
    Phi_tilde = np.einsum("...ik,...kj,...jl->...il", exp_phi, Phi_tilde_0, exp_neg_phi_tilde)
    Phi_tilde_T = np.swapaxes(Phi_tilde, -1, -2)


    A = np.einsum("...ik,...kl,...lj->...ij", Phi_tilde, sigma_p, Phi_tilde_T)
    A = sanitize_sigma(A, eps=eps)
    A_inv = safe_inv(A, eps=eps)

    delta_mu = mu_q - np.einsum("...ij,...j->...i", Phi_tilde, mu_p)

    # ∂Φ̃_a = Q_a Φ̃₀ e^{-φ̃}
    dPhi = np.einsum("...aik,...kj,...jl->...ail", Q_all, Phi_tilde_0, exp_neg_phi_tilde)
    dPhi_T = np.swapaxes(dPhi, -1, -2)

    dA = (
        np.einsum("...aik,...kl,...lj->...aij", dPhi, sigma_p, Phi_tilde_T) +
        np.einsum("...ik,...kl,...alj->...aij", Phi_tilde, sigma_p, dPhi_T)
    )

    # Term 1
    dPhi_mu_p = np.einsum("...aij,...j->...ai", dPhi, mu_p)
    term1 = -np.einsum("...ai,...i->...a", dPhi_mu_p, np.einsum("...ij,...j->...i", A_inv, delta_mu))

    # Term 2   (note: your earlier self/feedback sign conventions differ; keeping your current one)
    term2 = 0.5 * np.einsum("...ij,...aij->...a", A_inv, dA)

    # M = A^{-1} dA A^{-1}
    M = np.einsum("...ij,...ajk,...kl->...ail", A_inv, dA, A_inv)

    # Term 3
    term3 = -0.5 * np.einsum("...i,...aij,...j->...a", delta_mu, M, delta_mu)

    # Term 4
    term4 = -0.5 * np.einsum("...aij,...ji->...a", M, sigma_q)

    grad = term1 + term2 + term3 + term4
    return grad


def grad_self_phi_tilde_direct(
    mu_q, sigma_q,
    mu_p, sigma_p,
    Phi_tilde_0,
    phi, phi_tilde,
    generators_q, generators_p,
    exp_phi, exp_phi_tilde,
    eps=1e-8,
    # NEW optional precomputes:
    Q_tilde_all=None,         # (..., d, K_p, K_p)
    exp_neg_phi_tilde=None    # (..., K_p, K_p)
):
    """
    Vectorized over 'a': returns (..., d)
    Right-trivialize on model: R_a = (∂e^{φ̃}/∂φ̃^a) e^{-φ̃},  ∂Φ̃_a = - Φ̃ R_a.
    """
    d, K_p, _ = generators_p.shape
    
    if exp_neg_phi_tilde is None:
        exp_neg_phi_tilde = safe_omega_inv(exp_phi_tilde, eps=eps, debug=False)
    if Q_tilde_all is None:
        Q_list = d_exp_phi_tilde_exact(phi_tilde, generators_p)
        Q_tilde_all = np.stack(Q_list, axis=-3)

    Phi_tilde = np.einsum("...ik,...kj,...jl->...il", exp_phi, Phi_tilde_0, exp_neg_phi_tilde)
    Phi_tilde_T = np.swapaxes(Phi_tilde, -1, -2)

    
    A = np.einsum("...ik,...kl,...lj->...ij", Phi_tilde, sigma_p, Phi_tilde_T)
    A = sanitize_sigma(A, eps=eps)
    A_inv = safe_inv(A, eps=eps)

    mu_t = np.einsum("...ij,...j->...i", Phi_tilde, mu_p)
    delta_mu = mu_q - mu_t

    # R_a = Q̃_a e^{-φ̃}
    R = np.einsum("...aik,...kj->...aij", Q_tilde_all, exp_neg_phi_tilde)

    # dΦ̃_a = - Φ̃ R_a
    dPhi = -np.einsum("...ik,...akj->...aij", Phi_tilde, R)
    dPhi_T = np.swapaxes(dPhi, -1, -2)

    dA = (
        np.einsum("...aik,...kl,...lj->...aij", dPhi, sigma_p, Phi_tilde_T) +
        np.einsum("...ik,...kl,...alj->...aij", Phi_tilde, sigma_p, dPhi_T)
    )

    dPhi_mu_p = np.einsum("...aij,...j->...ai", dPhi, mu_p)
    term1 = -np.einsum("...ai,...i->...a", dPhi_mu_p, np.einsum("...ij,...j->...i", A_inv, delta_mu))

    term2 = 0.5 * np.einsum("...ij,...aij->...a", A_inv, dA)

    M = np.einsum("...ij,...ajk,...kl->...ail", A_inv, dA, A_inv)

    term3 = -0.5 * np.einsum("...i,...aij,...j->...a", delta_mu, M, delta_mu)
    term4 = -0.5 * np.einsum("...aij,...ji->...a", M, sigma_q)

    grad = term1 + term2 + term3 + term4
    return grad




# --- capped body-frame map for MASS term only -------------------------------
def _cap_jinv_for_mass(J, max_gain=10.0):
    """
    Cheap row-sum norm cap on Jinv so mass regularizer can't explode near θ≈π.
    Operates elementwise over (..., 3, 3).
    """
    
    eps = 1e-8
    rs = np.sum(np.abs(J), axis=-1)           # (..., 3)
    gain = np.max(rs, axis=-1, keepdims=True) # (..., 1)
    scale = np.minimum(1.0, float(max_gain) / np.maximum(gain, eps))  # (..., 1)
    return J * scale[..., None]               # (..., 3, 3)


# =========================
# Regularization (with toggleable φ–φ̃ coupling)
# =========================
def apply_regularization_terms_lie_natural(
    agent,
    phi_field,
    generators,
    field,
    params,
    agents=None,
    eps=1e-8,
    *,
    ctx=None,
):
    """
    Return NATURAL (body-frame) regularizer vector for φ or φ̃.
    """
    import numpy as np
    import core.config as config
    

    grad_nat = np.zeros_like(phi_field, dtype=np.float32)

    # weights (params override config)
    curv_w   = float(params.get("curvature_weight", 0.0))
    fisher_w = float(params.get("fisher_geometry_weight", 0.0))
    mass_w   = float(params.get("mass_weight", 0.0))
    cpl_w    = float(params.get("phi_coupling_weight", 0.0))

    if field == "phi":
        curv_w   = float(getattr(config, "curvature_weight", curv_w))
        fisher_w = float(getattr(config, "fisher_geometry_weight", fisher_w))
        mass_w   = float(getattr(config, "belief_mass", mass_w))
        cpl_w    = float(getattr(config, "phi_coupling_weight", cpl_w))
        which    = "q"
        gen_q    = generators
        gen_p    = getattr(agent, "generators_p", None)
        phi_q    = np.asarray(getattr(agent, "phi", None), np.float32)
        phi_p    = np.asarray(getattr(agent, "phi_model", None), np.float32)
    elif field == "phi_model":
        curv_w   = float(getattr(config, "model_curvature_weight", curv_w))
        fisher_w = float(getattr(config, "fisher_model_geometry_weight", fisher_w))
        mass_w   = float(getattr(config, "model_mass", mass_w))
        cpl_w    = float(getattr(config, "phi_coupling_weight", cpl_w))
        which    = "p"
        gen_p    = generators
        gen_q    = getattr(agent, "generators_q", None)
        phi_q    = np.asarray(getattr(agent, "phi", None), np.float32)
        phi_p    = np.asarray(getattr(agent, "phi_model", None), np.float32)
    else:
        raise ValueError(f"Invalid field: {field}")

    if (curv_w == 0.0) and (fisher_w == 0.0) and (mass_w == 0.0) and (cpl_w == 0.0):
        return grad_nat

    # Build Jinv for the CURRENT field
    Jinv = Jinv_grid(ctx, agent, which=which) if ctx is not None else None
    if Jinv is None:
        base = phi_q if which == "q" else phi_p
        Jinv = build_dexpinv_matrix(np.asarray(base, np.float32))

    # Uncapped (default) param-covector -> body-covector
    def cov_param_to_body(g_param):
        return np.einsum("...ij,...j->...i", Jinv, np.asarray(g_param, np.float32), optimize=True)

    # Capped ONLY for mass
    max_gain = float(getattr(config, "phi_mass_max_gain", 10.0))
    Jinv_mass = _cap_jinv_for_mass(Jinv, max_gain=max_gain)

    def cov_param_to_body_mass(g_param):
        return np.einsum("...ij,...j->...i", Jinv_mass, np.asarray(g_param, np.float32), optimize=True)

    # --- Curvature term (param covector → body via UNcapped Jinv)
    if curv_w > 0.0:
        g_param_curv = compute_curvature_gradient_analytical(
            np.asarray(phi_field, np.float32), generators
        )
        grad_nat += curv_w * cov_param_to_body(g_param_curv)

    # --- Fisher-geometry term (assumed already NATURAL/body)
    if fisher_w > 0.0 and agents is not None:
        step_tag = params.get("step_tag", getattr(ctx, "global_step", None) if ctx is not None else None)
        g_body = compute_fisher_geometry_gradient(
            agent, agents, params, field=field, step_tag=step_tag, ctx=ctx
        )
        grad_nat += fisher_w * np.asarray(g_body, np.float32)

    # --- Mass term: L = (λ/2) ||φ||^2  => ∂L/∂φ = λ φ  (param covector) → CAPPED
    if mass_w > 0.0:
        grad_nat += cov_param_to_body_mass(mass_w * np.asarray(phi_field, np.float32))

    # --- q↔p coupling: L = (c/2) || φ_p - C φ_q ||^2  (param covector → UNcapped)
    if cpl_w > 0.0:
        try:
            C = _build_c_mapping_q2p(getattr(agent, "Phi_tilde_0", None), gen_q, gen_p, eps=eps)
            if C is not None and phi_q is not None and phi_p is not None:
                r = phi_p - np.einsum("ab,...b->...a", C, phi_q, optimize=True)
                if field == "phi":
                    # ∂L/∂φ_q = - C^T r  (param covector)
                    g_param = -np.einsum("ba,...b->...a", C, r, optimize=True)
                else:
                    # ∂L/∂φ_p = r  (param covector)
                    g_param = r
                grad_nat += cpl_w * cov_param_to_body(g_param)
        except Exception:
            pass

    return np.nan_to_num(grad_nat, nan=0.0, posinf=0.0, neginf=0.0).astype(np.float32, copy=False)




# =========================
# Helpers (cached, lightweight)
# =========================

def _algebra_matrix_from_coeffs(phi_coeffs, generators):
    """
    phi_coeffs: (..., d)
    generators: (d, K, K)
    returns: (..., K, K) matrix in the algebra
    """
    # sum_a phi^a G^a
    # reshape phi to broadcast over K,K
    return np.einsum("...a,aij->...ij", phi_coeffs, generators)


def _gram_inv_cached(agent, key_name, generators, eps=1e-8):
    """
    Cache and return Gram^{-1} for the given generator set under Frobenius inner product.
    key_name: str attribute name on agent (e.g., "_Gram_q_inv" / "_Gram_p_inv")
    """
    G_inv = getattr(agent, key_name, None)
    if G_inv is not None:
        return G_inv
    d = generators.shape[0]
    Gram = np.empty((d, d), dtype=generators.dtype)
    for a in range(d):
        for b in range(d):
            Gram[a, b] = np.tensordot(generators[a], generators[b])
    Gram += eps * np.eye(d, dtype=Gram.dtype)
    G_inv = safe_inv(Gram)
    setattr(agent, key_name, G_inv)
    return G_inv


def _project_mat_to_algebra_coeffs(M, generators, G_inv):
    """
    Project matrix M (..., K, K) to algebra coefficients (..., d)
    by solving coeffs = G_inv @ h, where h_b = <G^b, M>_F.
    """
    d = generators.shape[0]
    # h_b = tr((G^b)^T M)
    h = np.stack([np.tensordot(generators[b], M) for b in range(d)], axis=-1)
    # coeffs = h @ G_inv^T (since last dim is basis index)
    # both ways are fine; using right-multiply for (..., d)
    coeffs = np.einsum("...b,bc->...c", h, G_inv)
    return coeffs


# --- helper: build C once and cache on agent ---
def _build_c_mapping_q2p(Phi_tilde_0, generators_q, generators_p, eps=1e-8):
    """
    Build linear map C (d_p x d_q) so that Ad_{Phi_tilde_0}(G_q^a) ≈ sum_b C_{ba} G_p^b,
    using Frobenius inner-product projection onto p-basis.
    """
    d_q, Kq, _ = generators_q.shape
    d_p, Kp, _ = generators_p.shape
    assert Phi_tilde_0.shape[-2:] == (Kq, Kp), "Phi_tilde_0 must be (K_q, K_p)"

    # Gram matrix of p-basis under Frobenius product
    Gp = np.zeros((d_p, d_p), dtype=generators_p.dtype)
    for b in range(d_p):
        for c in range(d_p):
            Gp[b, c] = np.tensordot(generators_p[b], generators_p[c])
    Gp += eps * np.eye(d_p, dtype=Gp.dtype)
    Gp_inv = safe_inv(Gp)

    # Conjugate each q-generator: H_a = Phi0 G_q^a Phi0^{-1}
    Phi0    = Phi_tilde_0
    Phi0_inv = safe_inv(Phi0, eps=eps)

    C = np.zeros((d_p, d_q), dtype=generators_p.dtype)
    for a in range(d_q):
        H_a = np.einsum("ik,kl,lj->ij", Phi0, generators_q[a], Phi0_inv)
        h = np.array([np.tensordot(generators_p[b], H_a) for b in range(d_p)], dtype=H_a.dtype)
        C[:, a] = Gp_inv @ h
    return C


