# -*- coding: utf-8 -*-
"""
Created on Tue Oct  7 18:31:53 2025

@author: chris and christine
"""

def grad_beta_A_mu_sigma_i(ctx, agent_i, agent_j, *, Omega_ij=None, eps: float = 1e-8):
    """
    ∂ KL_beta / ∂ (μ_p_i, Σ_p_i) for Case A:
        KL_beta = KL( Φ_i[ Ω^q_ij q_j ]  ||  p_i )
    Returns:
      gmu_p_i  : (*S, Kp)
      gSig_p_i : (*S, Kp, Kp)

    Notes
    -----
    - Depends only on (μ_p_i, Σ_p_i) as TARGET.
    - Φ_i : Q_i → P_i built from site frames E_q(i), E_p(i).
    - Ω^q_ij : Q_j → Q_i transports j→i in q-fiber.
    """
    import numpy as np
    from core.transport_cache import Omega, E_grid
    from core.numerical_utils import sanitize_sigma, safe_inv, push_gaussian

    # --- Fields & shapes
    mu_p_i = np.asarray(agent_i.mu_p_field,  np.float32, order="C")
    S_p_i  = sanitize_sigma(np.asarray(agent_i.sigma_p_field, np.float64), eps=eps).astype(np.float32, copy=False)

    mu_q_j = np.asarray(agent_j.mu_q_field,  np.float32, order="C")
    S_q_j  = sanitize_sigma(np.asarray(agent_j.sigma_q_field, np.float64), eps=eps).astype(np.float32, copy=False)

    S = tuple(mu_p_i.shape[:-1])              # spatial shape
    Kp = int(mu_p_i.shape[-1])

    # --- Transport j → i in q: q_j  --Ω^q_ij→  q_i
    Om_q = np.asarray(Omega_ij if Omega_ij is not None else Omega(ctx, agent_i, agent_j, which="q"), np.float32)
    mu_qj_t, S_qj_t, _ = push_gaussian(
        mu_q_j, S_q_j, Om_q,
        eps=eps, return_inv=True, assume_orthogonal=False
    )  # shapes: (*S, Kq), (*S, Kq, Kq)

    # --- Build Φ_i : Q_i → P_i  from site frames
    #     Using E_p(i) (*S, Kp, K) and E_q(i) (*S, Kq, K) → Φ = E_p E_q^T : (*S, Kp, Kq)
    Eqi = np.asarray(E_grid(ctx, agent_i, which="q"), np.float32)
    Epi = np.asarray(E_grid(ctx, agent_i, which="p"), np.float32)
    Phi = np.einsum("...ik,...jk->...ij", Epi, np.swapaxes(Eqi, -1, -2), optimize=True)

    # --- Map transported q_j into p_i:  (μ_L, Σ_L) = Φ (μ_qj_t, Σ_qj_t) Φ^T
    mu_L = np.einsum("...pk,...k->...p",            Phi,   mu_qj_t, optimize=True)              # (*S, Kp)
    S_L  = np.einsum("...pa,...ab,...pb->...pp",    Phi,   S_qj_t,  Phi,        optimize=True)  # (*S, Kp, Kp)
    S_L  = sanitize_sigma(S_L, eps=eps).astype(np.float32, copy=False)

    # --- Closed-form KL gradients (target wrt p_i)
    # For KL(src||tgt) with src=(μ_L, Σ_L), tgt=(μ_p_i, Σ_p_i):
    #   v     = Σ_p^{-1}(μ_p - μ_L)
    #   gμ_p  =  v
    #   gΣ_p  =  1/2( -Σ_p^{-1} Σ_L Σ_p^{-1}  - v v^T  + Σ_p^{-1} )
    S_p_inv = safe_inv(S_p_i.astype(np.float32, copy=False))
    dmu     = (mu_p_i - mu_L)
    v       = np.einsum("...ij,...j->...i", S_p_inv, dmu, optimize=True)

    vvT     = np.einsum("...i,...j->...ij", v, v, optimize=True)
    t0      = -np.einsum("...ij,...jk,...kl->...il", S_p_inv, S_L, S_p_inv, optimize=True)
    gS_p    = 0.5 * (t0 - vvT + S_p_inv)
    gS_p    = 0.5 * (gS_p + np.swapaxes(gS_p, -1, -2))  # symmetrize

    return v.astype(np.float32, copy=False), gS_p.astype(np.float32, copy=False)



def grad_beta_B_mu_sigma_i(ctx, agent_i, agent_j, *, Omega_ij=None, eps: float = 1e-8):
    """
    ∂ KL_beta / ∂ (μ_p_i, Σ_p_i) for Case B:
        KL_beta = KL( p_i || Φ_i[ Ω^q_ij q_j ] )
    Returns:
      gmu_p_i  : (*S, Kp)
      gSig_p_i : (*S, Kp, Kp)

    Notes
    -----
    - Depends only on (μ_p_i, Σ_p_i) as SOURCE.
    - Φ_i : Q_i → P_i built from site frames E_q(i), E_p(i).
    - Ω^q_ij : Q_j → Q_i transports j→i in q-fiber.
    """
    import numpy as np
    from core.transport_cache import Omega, E_grid
    from core.numerical_utils import sanitize_sigma, safe_inv, push_gaussian

    # --- Fields (p_i as SOURCE)
    mu_p_i = np.asarray(agent_i.mu_p_field,  np.float32, order="C")
    S_p_i  = sanitize_sigma(np.asarray(agent_i.sigma_p_field, np.float64), eps=eps).astype(np.float32, copy=False)

    mu_q_j = np.asarray(agent_j.mu_q_field,  np.float32, order="C")
    S_q_j  = sanitize_sigma(np.asarray(agent_j.sigma_q_field, np.float64), eps=eps).astype(np.float32, copy=False)

    S = tuple(mu_p_i.shape[:-1])              # spatial shape
    Kp = int(mu_p_i.shape[-1])

    # --- Transport j → i in q: q_j  --Ω^q_ij→  q_i
    Om_q = np.asarray(Omega_ij if Omega_ij is not None else Omega(ctx, agent_i, agent_j, which="q"), np.float32)
    mu_qj_t, S_qj_t, _ = push_gaussian(
        mu_q_j, S_q_j, Om_q,
        eps=eps, return_inv=True, assume_orthogonal=False
    )  # (*S, Kq), (*S, Kq, Kq)

    # --- Build Φ_i : Q_i → P_i from site frames → Φ = E_p E_q^T : (*S, Kp, Kq)
    Eqi = np.asarray(E_grid(ctx, agent_i, which="q"), np.float32)
    Epi = np.asarray(E_grid(ctx, agent_i, which="p"), np.float32)
    Phi = np.einsum("...ik,...jk->...ij", Epi, np.swapaxes(Eqi, -1, -2), optimize=True)

    # --- Map transported q_j into p_i:  (μ_L, Σ_L) = Φ (μ_qj_t, Σ_qj_t) Φ^T
    mu_L = np.einsum("...pk,...k->...p",            Phi,   mu_qj_t, optimize=True)              # (*S, Kp)
    S_L  = np.einsum("...pa,...ab,...pb->...pp",    Phi,   S_qj_t,  Phi,        optimize=True)  # (*S, Kp, Kp)
    S_L  = sanitize_sigma(S_L, eps=eps).astype(np.float32, copy=False)

    # --- Closed-form KL gradients (SOURCE wrt p_i)
    # For KL(src||tgt) with src=(μ_p, Σ_p), tgt=(μ_L, Σ_L):
    #   gμ_p  =  Σ_L^{-1} (μ_p - μ_L)
    #   gΣ_p  =  1/2 ( Σ_p^{-1} - Σ_L^{-1} )
    S_L_inv = safe_inv(S_L)
    S_p_inv = safe_inv(S_p_i.astype(np.float32, copy=False))

    dmu     = (mu_p_i - mu_L)
    gmu_p   = np.einsum("...ij,...j->...i", S_L_inv, dmu, optimize=True)

    gS_p    = 0.5 * (S_p_inv - S_L_inv)
    gS_p    = 0.5 * (gS_p + np.swapaxes(gS_p, -1, -2))  # symmetrize

    return gmu_p.astype(np.float32, copy=False), gS_p.astype(np.float32, copy=False)



def grad_beta_C_mu_sigma_i(ctx, agent_i, agent_j, *, Omega_ij=None, eps: float = 1e-8):
    """
    ∂ KL_beta / ∂ (μ_p_i, Σ_p_i) for Case C:
        KL_beta = KL( Φ̃_i p_i  ||  Ω^q_ij q_j )   [Q_i frame]
    Returns:
      gmu_p_i  : (*S, Kp)
      gSig_p_i : (*S, Kp, Kp)
    """
    import numpy as np
    from core.transport_cache import Omega, E_grid
    from core.numerical_utils import sanitize_sigma, safe_inv, push_gaussian

    # --- fields
    mu_p_i = np.asarray(agent_i.mu_p_field,  np.float32, order="C")
    S_p_i  = sanitize_sigma(np.asarray(agent_i.sigma_p_field, np.float64), eps=eps).astype(np.float32, copy=False)

    mu_q_j = np.asarray(agent_j.mu_q_field,  np.float32, order="C")
    S_q_j  = sanitize_sigma(np.asarray(agent_j.sigma_q_field, np.float64), eps=eps).astype(np.float32, copy=False)

    S = tuple(mu_p_i.shape[:-1]);  Kp = int(mu_p_i.shape[-1])

    # --- transport j→i in q: q_j --Ω^q_ij→ q_i (target)
    Om_q = np.asarray(Omega_ij if Omega_ij is not None else Omega(ctx, agent_i, agent_j, which="q"), np.float32)
    mu_tgt, S_tgt, S_tgt_inv = push_gaussian(
        mu_q_j, S_q_j, Om_q, eps=eps, return_inv=True, assume_orthogonal=False
    )  # (*S,Kq), (*S,Kq,Kq), (*S,Kq,Kq)

    # --- Φ̃_i : P_i → Q_i  (use site frames)
    Eqi = np.asarray(E_grid(ctx, agent_i, which="q"), np.float32)  # (*S, Kq, K)
    Epi = np.asarray(E_grid(ctx, agent_i, which="p"), np.float32)  # (*S, Kp, K)
    Phi_t = np.einsum("...ik,...jk->...ij", Eqi, np.swapaxes(Epi, -1, -2), optimize=True)  # (*S, Kq, Kp)

    # --- map p_i → q_i (source in Q_i)
    mu_src = np.einsum("...qp,...p->...q",  Phi_t, mu_p_i, optimize=True)                       # (*S,Kq)
    S_src  = np.einsum("...qa,...ab,...qb->...qq", Phi_t, S_p_i, Phi_t, optimize=True)          # (*S,Kq,Kq)
    S_src  = sanitize_sigma(S_src, eps=eps).astype(np.float32, copy=False)

    # --- KL(src||tgt) source grads in Q_i:
    # gμ_src = Σ_tgt^{-1}(μ_src - μ_tgt)
    # gΣ_src = 1/2 ( Σ_src^{-1} - Σ_tgt^{-1} )
    S_src_inv = safe_inv(S_src.astype(np.float32, copy=False))
    dmu_q     = (mu_src - mu_tgt)
    gmu_q     = np.einsum("...ij,...j->...i", S_tgt_inv, dmu_q, optimize=True)
    gS_q      = 0.5 * (S_src_inv - S_tgt_inv)
    gS_q      = 0.5 * (gS_q + np.swapaxes(gS_q, -1, -2))

    # --- chain back to p_i via Φ̃^T
    gmu_p = np.einsum("...pq,...q->...p", np.swapaxes(Phi_t, -1, -2), gmu_q, optimize=True)
    gS_p  = np.einsum("...pa,...ab,...qb->...pq",
                      np.swapaxes(Phi_t, -1, -2), gS_q, np.swapaxes(Phi_t, -1, -2),
                      optimize=True)
    gS_p  = 0.5 * (gS_p + np.swapaxes(gS_p, -1, -2))

    return gmu_p.astype(np.float32, copy=False), gS_p.astype(np.float32, copy=False)


def grad_beta_D_mu_sigma_i(ctx, agent_i, agent_j, *, Omega_ij=None, eps: float = 1e-8):
    """
    ∂ KL_beta / ∂ (μ_p_i, Σ_p_i) for Case D:
        KL_beta = KL( Ω^q_ij q_j  ||  Φ̃_i p_i )   [Q_i frame]
    Returns:
      gmu_p_i  : (*S, Kp)
      gSig_p_i : (*S, Kp, Kp)
    """
    import numpy as np
    from core.transport_cache import Omega, E_grid
    from core.numerical_utils import sanitize_sigma, safe_inv, push_gaussian

    # --- fields
    mu_p_i = np.asarray(agent_i.mu_p_field,  np.float32, order="C")
    S_p_i  = sanitize_sigma(np.asarray(agent_i.sigma_p_field, np.float64), eps=eps).astype(np.float32, copy=False)

    mu_q_j = np.asarray(agent_j.mu_q_field,  np.float32, order="C")
    S_q_j  = sanitize_sigma(np.asarray(agent_j.sigma_q_field, np.float64), eps=eps).astype(np.float32, copy=False)

    S = tuple(mu_p_i.shape[:-1]);  Kp = int(mu_p_i.shape[-1])

    # --- transport j→i in q: (source in Q_i)
    Om_q = np.asarray(Omega_ij if Omega_ij is not None else Omega(ctx, agent_i, agent_j, which="q"), np.float32)
    mu_src, S_src, _ = push_gaussian(
        mu_q_j, S_q_j, Om_q, eps=eps, return_inv=True, assume_orthogonal=False
    )  # (*S,Kq), (*S,Kq,Kq)

    # --- Φ̃_i : P_i → Q_i
    Eqi = np.asarray(E_grid(ctx, agent_i, which="q"), np.float32)
    Epi = np.asarray(E_grid(ctx, agent_i, which="p"), np.float32)
    Phi_t = np.einsum("...ik,...jk->...ij", Eqi, np.swapaxes(Epi, -1, -2), optimize=True)  # (*S, Kq, Kp)

    # --- map p_i → q_i (target in Q_i)
    mu_tgt = np.einsum("...qp,...p->...q",  Phi_t, mu_p_i, optimize=True)
    S_tgt  = np.einsum("...qa,...ab,...qb->...qq", Phi_t, S_p_i, Phi_t, optimize=True)
    S_tgt  = sanitize_sigma(S_tgt, eps=eps).astype(np.float32, copy=False)
    S_tgt_inv = safe_inv(S_tgt)

    # --- KL(src||tgt) target grads in Q_i:
    # v       = Σ_tgt^{-1}(μ_src - μ_tgt)
    # gμ_tgt  = -v
    # gΣ_tgt  = 1/2( -Σ_tgt^{-1} Σ_src Σ_tgt^{-1} - v v^T + Σ_tgt^{-1} )
    dmu_q = (mu_src - mu_tgt)
    v     = np.einsum("...ij,...j->...i", S_tgt_inv, dmu_q, optimize=True)

    vvT   = np.einsum("...i,...j->...ij", v, v, optimize=True)
    t0    = -np.einsum("...ij,...jk,...kl->...il", S_tgt_inv, S_src, S_tgt_inv, optimize=True)
    gS_q  = 0.5 * (t0 - vvT + S_tgt_inv)
    gS_q  = 0.5 * (gS_q + np.swapaxes(gS_q, -1, -2))
    gmu_q = -v

    # --- chain back to p_i via Φ̃^T
    gmu_p = np.einsum("...pq,...q->...p", np.swapaxes(Phi_t, -1, -2), gmu_q, optimize=True)
    gS_p  = np.einsum("...pa,...ab,...qb->...pq",
                      np.swapaxes(Phi_t, -1, -2), gS_q, np.swapaxes(Phi_t, -1, -2),
                      optimize=True)
    gS_p  = 0.5 * (gS_p + np.swapaxes(gS_p, -1, -2))

    return gmu_p.astype(np.float32, copy=False), gS_p.astype(np.float32, copy=False)
