# -*- coding: utf-8 -*-
"""
Created on Sat Sep 27 15:19:10 2025

@author: chris and christine

Case A:  KL( Φ_i[Ω^q_ij q_j] || p_i )
Case B:  KL( p_i || Φ_i Ω^q_ij[q_j] )

Case C: KL( Φ̃_i p_i  ||  Ω^q_ij q_j )
Case D: KL( Ω^q_ij * q_j || Φ̃_i * p_i )

Default Q:  KL( q_i || Ω^q_ij q_j )
Default P:  KL( p_i || Ω^p_ij p_j ) 

"""

import numpy as np
from runtime_context import cfg_get
from core.numerical_utils import sanitize_sigma, kl_gaussian, push_gaussian
from core.transport_cache import Omega, E_grid




def get_edge_fields(ctx, which: str, i: int, j: int):
    """Return (beta_ij, KL1_ij) arrays stored by compute_edge_betas."""
    try:
        b = ctx._edge_beta[(which, i, j)]
        k = ctx._edge_kl1 [(which, i, j)]
    except KeyError as e:
        raise RuntimeError(f"get_edge_fields: missing {(which,i,j)}: {e}")
    return b, k



def compute_edge_betas(ctx, agents, *, which="q"):
    """
    Unified per-edge maps for a single fiber ('q' or 'p'):

        ctx._edge_kl1[(which,i,j)]  = KL1_ij  (alignment KL for updates)
        ctx._edge_kl2[(which,i,j)]  = KL2_ij  (β-basis KL; 0 off-overlap)
        ctx._edge_beta[(which,i,j)] = β_ij    (per-pixel attention; softmax over senders)

    β construction (NO external builders required):
      1) For each receiver i, compute per-sender KL2_ij(x) according to the basis:
         A: KL( Φ_i[Ω^q_ij q_j] || p_i )      (P_i frame)
         B: KL( p_i || Φ_i[Ω^q_ij q_j] )      (P_i frame)
         C: KL( Φ̃_i p_i || Ω^q_ij q_j )      (Q_i frame)
         D: KL( Ω^q_ij q_j || Φ̃_i p_i )      (Q_i frame)
         align_q: KL(q_i || Ω^q_ij q_j)       (Q_i frame)
         align_p: KL(p_i || Ω^p_ij p_j)       (P_i frame)
      2) Mask off-overlap pixels (logits=-inf → weight 0 there).
      3) Softmax over senders j for each pixel x: β_ij(x) = softmax_j( -KL2_ij(x) / κ ).

    Config keys used:
      beta_{which}        : selector in {'a','b','c','d','align_q','align_p'}
      beta_kappa_{which}  : κ (float)
      obs_beta_eps        : numeric epsilon for pushes/inverses
      support_tau         : overlap threshold for masks

    Notes:
      • KL2 stored in ctx._edge_kl2 is zeroed off-overlap (useful for gradient weighting).
      • Softmax is per-pixel and only over senders with overlap at that pixel.
    """
    
    if which not in ("q", "p"):
        raise ValueError(f"compute_edge_betas: which must be 'q' or 'p', got {which!r}")

    # ensure unified dicts exist
    if not hasattr(ctx, "_edge_kl1"):  ctx._edge_kl1  = {}
    if not hasattr(ctx, "_edge_kl2"):  ctx._edge_kl2  = {}
    if not hasattr(ctx, "_edge_beta"): ctx._edge_beta = {}

    # config
    kappa    = float(cfg_get(ctx, f"beta_kappa_{which}", 1.0))
    eps      = float(cfg_get(ctx, "obs_beta_eps", 1e-12))
    tau      = float(cfg_get(ctx, "support_tau", 1e-6))
    beta_sel = str(cfg_get(ctx, f"beta_{which}", "align_q" if which == "q" else "align_p")).lower()
    tiny     = 1e-12
    kappa    = max(kappa, tiny)

    # ---------- helpers ----------
    def _Omega_q(ai, aj):
        return np.asarray(Omega(ctx, ai, aj, which="q"), np.float32)

    def _Omega_p(ai, aj):
        return np.asarray(Omega(ctx, ai, aj, which="p"), np.float32)

    def _Phi(i_agent):
        # Φ_i : q -> p = E_p_i E_q_i^T
        Eqi = np.asarray(E_grid(ctx, i_agent, which="q"), np.float32)
        Epi = np.asarray(E_grid(ctx, i_agent, which="p"), np.float32)
        return np.einsum("...ik,...jk->...ij", Epi, np.swapaxes(Eqi, -1, -2), optimize=True)

    def _Phi_tilde(i_agent):
        # Φ̃_i : p -> q = E_q_i E_p_i^T
        Eqi = np.asarray(E_grid(ctx, i_agent, which="q"), np.float32)
        Epi = np.asarray(E_grid(ctx, i_agent, which="p"), np.float32)
        return np.einsum("...ik,...jk->...ij", Eqi, np.swapaxes(Epi, -1, -2), optimize=True)

    # KL1 used by updates/alignment
    def _KL1_q(ai, aj):
        mu_i = np.asarray(ai.mu_q_field, np.float32)
        S_i  = sanitize_sigma(np.asarray(ai.sigma_q_field, np.float64))
        Om   = _Omega_q(ai, aj)
        mu_j = np.asarray(aj.mu_q_field, np.float32)
        S_j  = sanitize_sigma(np.asarray(aj.sigma_q_field, np.float64))
        mu_t, S_t, _ = push_gaussian(mu_j, S_j, Om, eps=eps, return_inv=True, assume_orthogonal=False)
        return kl_gaussian(mu_i, S_i, mu_t, S_t).astype(np.float32, copy=False)

    def _KL1_p(ai, aj):
        mu_i = np.asarray(ai.mu_p_field, np.float32)
        S_i  = sanitize_sigma(np.asarray(ai.sigma_p_field, np.float64))
        Om   = _Omega_p(ai, aj)
        mu_j = np.asarray(aj.mu_p_field, np.float32)
        S_j  = sanitize_sigma(np.asarray(aj.sigma_p_field, np.float64))
        mu_t, S_t, _ = push_gaussian(mu_j, S_j, Om, eps=eps, return_inv=True, assume_orthogonal=False)
        return kl_gaussian(mu_i, S_i, mu_t, S_t).astype(np.float32, copy=False)

    # Analytic KL2 definitions (no external builders)
    def _KL_case_A(ai, aj):
        # KL( Φ_i[Ω^q_ij q_j] || p_i )  in P_i
        R   = np.einsum("...ik,...kj->...ij", _Phi(ai), _Omega_q(ai, aj), optimize=True)
        mu_j = np.asarray(aj.mu_q_field, np.float32)
        S_j  = sanitize_sigma(np.asarray(aj.sigma_q_field, np.float64))
        mu_L, S_L, _ = push_gaussian(mu_j, S_j, R, eps=eps, return_inv=True, assume_orthogonal=False)
        mu_p = np.asarray(ai.mu_p_field, np.float32)
        S_p  = sanitize_sigma(np.asarray(ai.sigma_p_field, np.float64))
        return kl_gaussian(mu_L, S_L, mu_p, S_p).astype(np.float32, copy=False)

    def _KL_case_B(ai, aj):
        # KL( p_i || Φ_i[Ω^q_ij q_j] )  in P_i
        R   = np.einsum("...ik,...kj->...ij", _Phi(ai), _Omega_q(ai, aj), optimize=True)
        mu_j = np.asarray(aj.mu_q_field, np.float32)
        S_j  = sanitize_sigma(np.asarray(aj.sigma_q_field, np.float64))
        mu_L, S_L, _ = push_gaussian(mu_j, S_j, R, eps=eps, return_inv=True, assume_orthogonal=False)
        mu_p = np.asarray(ai.mu_p_field, np.float32)
        S_p  = sanitize_sigma(np.asarray(ai.sigma_p_field, np.float64))
        return kl_gaussian(mu_p, S_p, mu_L, S_L).astype(np.float32, copy=False)

    def _KL_case_C(ai, aj):
        # KL( Φ̃_i p_i || Ω^q_ij q_j )  in Q_i
        Rpt = _Phi_tilde(ai)
        Om  = _Omega_q(ai, aj)
        mu_p = np.asarray(ai.mu_p_field, np.float32)
        S_p  = sanitize_sigma(np.asarray(ai.sigma_p_field, np.float64))
        mu_qhat, S_qhat, _ = push_gaussian(mu_p, S_p, Rpt, eps=eps, return_inv=True, assume_orthogonal=False)
        mu_j = np.asarray(aj.mu_q_field, np.float32)
        S_j  = sanitize_sigma(np.asarray(aj.sigma_q_field, np.float64))
        mu_t, S_t, _ = push_gaussian(mu_j, S_j, Om, eps=eps, return_inv=True, assume_orthogonal=False)
        return kl_gaussian(mu_qhat, S_qhat, mu_t, S_t).astype(np.float32, copy=False)

    def _KL_case_D(ai, aj):
        # KL( Ω^q_ij q_j || Φ̃_i p_i )  in Q_i
        Rpt = _Phi_tilde(ai)
        Om  = _Omega_q(ai, aj)
        mu_p = np.asarray(ai.mu_p_field, np.float32)
        S_p  = sanitize_sigma(np.asarray(ai.sigma_p_field, np.float64))
        mu_qhat, S_qhat, _ = push_gaussian(mu_p, S_p, Rpt, eps=eps, return_inv=True, assume_orthogonal=False)
        mu_j = np.asarray(aj.mu_q_field, np.float32)
        S_j  = sanitize_sigma(np.asarray(aj.sigma_q_field, np.float64))
        mu_t, S_t, _ = push_gaussian(mu_j, S_j, Om, eps=eps, return_inv=True, assume_orthogonal=False)
        return kl_gaussian(mu_t, S_t, mu_qhat, S_qhat).astype(np.float32, copy=False)

    # KL2 dispatcher
    if   beta_sel == "a":        KL2_fn = _KL_case_A
    elif beta_sel == "b":        KL2_fn = _KL_case_B
    elif beta_sel == "c":        KL2_fn = _KL_case_C
    elif beta_sel == "d":        KL2_fn = _KL_case_D
    elif beta_sel == "align_q":  KL2_fn = _KL1_q
    elif beta_sel == "align_p":  KL2_fn = _KL1_p
    else:
        raise ValueError(f"compute_edge_betas: unknown beta_{which}={beta_sel!r}")

    # ---------- main (softmax over senders) ----------
    ids = [int(getattr(a, "id", i)) for i, a in enumerate(agents)]

    for i_idx, ai in enumerate(agents):
        i_id = ids[i_idx]

        # authoritative spatial shape from i's fields (q or p)
        if which == "q":
            base = np.asarray(ai.mu_q_field, np.float32)
        else:
            base = np.asarray(ai.mu_p_field, np.float32)
        S = base.shape[:-1]  # *S

        # Collect per-sender KL2 for this receiver
        logits_list  = []   # (J,*S) after stacking
        mask_list    = []   # (J,*S) bool
        js           = []   # sender ids
        kl2_store    = {}   # (i,j) -> (*S,) float32 (0 off-overlap)
        kl1_store    = {}   # (i,j) -> (*S,) float32 (unmasked)

        for j_idx, aj in enumerate(agents):
            if j_idx == i_idx:
                continue
            j_id = ids[j_idx]

            # Overlap mask in receiver i's frame
            mi = np.asarray(getattr(ai, "mask"), np.float32)
            mj = np.asarray(getattr(aj, "mask"), np.float32)
            joint = (mi > tau) & (mj > tau)
            if joint.shape != S:
                try:
                    joint = np.broadcast_to(joint, S)
                except Exception as e:
                    raise ValueError(f"joint mask {joint.shape} not broadcastable to {S} for (i={i_id}, j={j_id})") from e
            overlap = (joint > 0)

            if not np.any(overlap):
                continue

            # KL1 (alignment) stored regardless of basis
            KL1_ij = _KL1_q(ai, aj) if which == "q" else _KL1_p(ai, aj)
            kl1_store[(i_id, j_id)] = np.asarray(KL1_ij, np.float32, order="C")

            # KL2 (β-basis)
            KL2_ij = KL2_fn(ai, aj)  # (*S,)
            KL2_ij = np.asarray(KL2_ij, np.float64)  # keep precision for logits
            if KL2_ij.shape != S:
                if KL2_ij.shape[:len(S)] == S and KL2_ij.ndim > len(S):
                    KL2_ij = KL2_ij.reshape(S + (-1,)).sum(axis=-1)
                else:
                    raise ValueError(f"KL2 dims {KL2_ij.shape} incompatible with {S} for (i={i_id}, j={j_id})")

            # logits with -inf where no overlap → weight 0 there
            logit = -KL2_ij / kappa
            logit = np.where(overlap, logit, -np.inf)

            logits_list.append(logit)
            mask_list.append(overlap)
            js.append(j_id)

            # store KL2 with 0 off-overlap (useful for weighting/grads)
            kl2_store[(i_id, j_id)] = np.where(overlap, KL2_ij, 0.0).astype(np.float32, copy=False)

        if not js:
            continue

        # Stack senders: (J,*S)
        L = np.stack(logits_list, axis=0)
        M = np.stack(mask_list,   axis=0)
       
        W = safe_softmax_over_senders(L, mask=M, tiny=tiny)                           # (J,*S)

        # Store per-edge fields
        for s, j_id in enumerate(js):
            beta_ij = np.where(mask_list[s], W[s], 0.0).astype(np.float32, order="C")
            ctx._edge_beta[(which, i_id, j_id)] = beta_ij
            ctx._edge_kl2[(which, i_id, j_id)]  = kl2_store[(i_id, j_id)]
            ctx._edge_kl1[(which, i_id, j_id)]  = kl1_store[(i_id, j_id)]




def safe_softmax_over_senders(logits, *, mask=None, tiny=1e-12):
    """
    Numerically safe softmax across senders (axis=0), for per-pixel weighting.

    Args
    ----
    logits : (J, *S) float array, may contain -inf where you want zero weight
    mask   : optional (J, *S) bool; True = valid sender at pixel. If None, uses np.isfinite(logits).
    tiny   : small positive epsilon to avoid division by zero

    Returns
    -------
    (J, *S) float32 with per-pixel sums over senders == 1 on overlap pixels, 0 elsewhere.
    """
    L = np.asarray(logits, dtype=np.float64)

    if mask is None:
        M = np.isfinite(L)
    else:
        M = np.asarray(mask, dtype=bool)

    # Replace invalid entries with -inf so they never contribute
    Lmasked = np.where(M, L, -np.inf)

    # Max over senders per pixel (shape (1,*S)); -inf when no sender is valid
    Lmax = np.max(Lmasked, axis=0, keepdims=True)

    # Compute subtraction ONLY where there's at least one valid sender and Lmax is finite
    valid_pix = np.isfinite(Lmax[0]) & np.any(M, axis=0)           # shape (*S,)
    valid_pix_b = np.expand_dims(valid_pix, axis=0)                # (1,*S) for broadcasting

    # Prepare output; default to -inf so exp→0 off valid pixels
    Lsafe = np.full_like(Lmasked, -np.inf, dtype=np.float64)

    # Safe, masked subtraction (no invalid warning)
    np.subtract(Lmasked, Lmax, out=Lsafe, where=np.broadcast_to(valid_pix_b, Lmasked.shape))

    # Exponentiate and zero out non-masked entries
    exps = np.exp(Lsafe) * M                                       # (J,*S)

    # Normalize per pixel
    Z = np.sum(exps, axis=0, keepdims=True)                        # (1,*S)
    Z = np.maximum(Z, tiny)                                        # avoid /0 on empty pixels
    W = exps / Z

    # Clean any residual non-finites (shouldn’t happen, but cheap insurance)
    W = np.where(np.isfinite(W), W, 0.0)

    return W.astype(np.float32, copy=False)









