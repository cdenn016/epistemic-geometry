
import numpy as np
from core.numerical_utils import safe_inv, sanitize_sigma, safe_omega_inv
from core.transport_cache import (build_dexpinv_matrix , Jinv_grid, E_grid, Omega, 
                                  exp_and_jinv_single, Phi_cached )
from core.omega import d_exp_exact
from runtime_context import cfg_get
from utils import log_phi_grad_like, _aid, push_neighbor_stats, mask_hw
from core.numerical_utils import push_gaussian

from beta import get_edge_fields

from beta_grads import grad_beta_phi
#==============================================================================
#
#                    GATHER PHI GAUGE FIELD GRADIENT TERMS
#                          Beliefs and Models
#==============================================================================



def accumulate_phi_alignment_gradient( 
    ctx,                              # required
    agent_i, agent_j, generators,
    *,
    field: str = "phi",
    beta_key: str | None = None,
    omega_cache_key: str | None = None,
    mu_key: str | None = None,
    sigma_key: str | None = None,
    fisher_inv_key: str | None = None,
    grad_key: str | None = None,
    Q_all_i=None,
    exp_neg_phi_j=None,
    agents=None,            # for Fisher regularizer
):
    

    assert mu_key and sigma_key and fisher_inv_key and grad_key, \
        "mu_key/sigma_key/fisher_inv_key/grad_key are required"

    eps   = float(cfg_get(ctx, "eps", 1e-8))
    tau   = float(cfg_get(ctx, "support_tau", 1e-6))
    which = "q" if field == "phi" else "p"

    # ---- config: beta basis + kappa ----
    beta_basis = str(cfg_get(ctx, f"beta_{which}", "align_q" if which=="q" else "align_p")).lower()
    kappa      = float(cfg_get(ctx, f"beta_kappa_{which}", 1.0))

    # ---- fields (fail fast) ----
    mu_i    = np.asarray(getattr(agent_i, mu_key),    np.float32)
    sigma_i = np.asarray(getattr(agent_i, sigma_key), np.float32)
    if not np.isfinite(mu_i).all():    raise FloatingPointError("non-finite mu_i")
    if not np.isfinite(sigma_i).all(): raise FloatingPointError("non-finite sigma_i")
    S = tuple(mu_i.shape[:-1])

    # ---- masks (N-D) ----
    mi = np.asarray(getattr(agent_i, "mask"), np.float32)
    mj = np.asarray(getattr(agent_j, "mask"), np.float32)
    if tuple(mi.shape) != S or tuple(mj.shape) != S:
        raise ValueError(f"mask shapes {mi.shape}, {mj.shape} != spatial shape {S}")
    if not (np.isfinite(mi).all() and np.isfinite(mj).all()):
        raise FloatingPointError("non-finite values in masks")
    joint_mask = (mi > tau) & (mj > tau)
    if not np.any(joint_mask):
        return

    # ---- ids & cached β, KL_align (KL1) ----
    i_id = int(getattr(agent_i, "id", -1))
    j_id = int(getattr(agent_j, "id", -1))
    beta_ij_map, KL1_map = get_edge_fields(ctx, which, i_id, j_id)  # each (*S,)
    beta_ij_map = np.asarray(beta_ij_map, np.float32)
    KL1_map     = np.asarray(KL1_map,     np.float32)
    if beta_ij_map.shape != S or KL1_map.shape != S:
        raise ValueError(f"edge fields shape mismatch: β {beta_ij_map.shape}, KL1 {KL1_map.shape}, expected {S}")

    # ---- RAW β masked by joint support (NO modulation here) ----
    beta_raw = beta_ij_map * joint_mask.astype(np.float32, copy=False)
    if not np.isfinite(beta_raw).all():
        raise FloatingPointError("non-finite beta_raw")
    if not np.any(np.abs(beta_raw) > 1e-8):
        return

    # ---- transports / frames (for align φ-grad path) ----
    E_i      = E_grid(ctx, agent_i, which=which)
    E_j      = E_grid(ctx, agent_j, which=which)
    Omega_ij = Omega(ctx, agent_i, agent_j, which=which)

    # neighbor stats in i-frame (for align term)
    mu_j_t, Sigma_j_t, sigma_j_t_inv = push_neighbor_stats(agent_j, sigma_key, Omega_ij, eps)

    # ---- exp bits for align φ-grad ----
    phi_i = np.asarray(getattr(agent_i, field), np.float32)
    if tuple(phi_i.shape[:-1]) != S or phi_i.shape[-1] != 3:
        raise ValueError(f"phi_i shape {phi_i.shape} incompatible with S={S} and dim=3")
    if Q_all_i is None:
        Q_all_i = d_exp_exact(phi_i, generators)
    if exp_neg_phi_j is None:
        exp_neg_phi_j = safe_omega_inv(E_j)

    # ---- ∂ KL_align / ∂ φ_i  (param-space COVECTOR) ----
    grad_param_align = grad_kl_wrt_phi_i(
        mu_i, sigma_i,
        None, None,
        phi_i=phi_i,
        phi_j=None,
        Omega_ij=Omega_ij,
        generators=generators,
        exp_phi_i=E_i,
        exp_phi_j=E_j,
        mu_j_t=mu_j_t,
        sigma_j_t_inv=sigma_j_t_inv,
        eps=eps,
        exp_neg_phi_j=exp_neg_phi_j,
        Q_all=Q_all_i,
    ).astype(np.float32, copy=False)

    if grad_param_align.shape != S + (3,):
        raise ValueError(f"grad_param_align shape {grad_param_align.shape} != {S+(3,)}")
    if not np.isfinite(grad_param_align).all():
        raise FloatingPointError("non-finite grad_param_align")

    # ---- Jinv & Fisher^{-1} (body) for projection of ALIGN covector ----
    Jinv = Jinv_grid(ctx, agent_i, which=which)
    if Jinv is None:
        Jinv = build_dexpinv_matrix(phi_i)
    if Jinv.shape != S + (3, 3):
        raise ValueError(f"Jinv shape {Jinv.shape} != {S+(3,3)}")
    if not np.isfinite(Jinv).all():
        raise FloatingPointError("non-finite Jinv")

    F_inv = getattr(agent_i, fisher_inv_key, None)
    if F_inv is None:
        raise RuntimeError(f"{fisher_inv_key} missing on agent {i_id}")
    F_inv = np.asarray(F_inv, np.float32)
    if F_inv.shape != S + (3, 3):
        raise ValueError(f"F_inv shape {F_inv.shape} != {S+(3,3)}")
    if not np.isfinite(F_inv).all():
        raise FloatingPointError("non-finite F_inv")

    def _param_covector_to_step(grad_param_vec):
        # param covector -> body covector -> natural body step -> param vector
        g_body_cov = np.einsum("...ji,...j->...i", Jinv, grad_param_vec, optimize=True)
        v_body     = np.einsum("...ab,...b->...a", F_inv, g_body_cov,   optimize=True)
        return np.einsum("...ab,...b->...a", Jinv, v_body, optimize=True)

    # ALIGN: covector -> step
    v_param_align = _param_covector_to_step(grad_param_align)
    if not np.isfinite(v_param_align).all():
        raise FloatingPointError("non-finite v_param_align")

    # ---- ∂ KL_beta / ∂ φ_i  (NEW) ----
    if beta_basis in ("align", "align_q", "align_p"):
        v_param_beta = v_param_align
    else:
        # For A/B/C/D we use our dispatcher, which returns PARAM-SPACE STEPS
        # Prepare j-side preconditioners when needed (q-fiber only).
        if which == "q":
            Jinv_q_j = Jinv_grid(ctx, agent_j, which="q")
            if Jinv_q_j is None:
                phi_j = np.asarray(getattr(agent_j, "phi"), np.float32)
                Jinv_q_j = build_dexpinv_matrix(phi_j)
            F_inv_q_j = getattr(agent_j, fisher_inv_key, None)
            if F_inv_q_j is not None:
                F_inv_q_j = np.asarray(F_inv_q_j, np.float32)
        else:
            Jinv_q_j = None
            F_inv_q_j = None

        g_phi_i_q, g_phi_j_q, g_phi_i_p = grad_beta_phi(
            ctx, agent_i, agent_j,
            basis=beta_basis,
            Jinv_q_i=(Jinv if which=="q" else None),   Finv_q_i=(F_inv if which=="q" else None),
            Jinv_q_j=Jinv_q_j,                          Finv_q_j=F_inv_q_j,
            Jinv_p_i=(Jinv if which=="p" else None),    Finv_p_i=(F_inv if which=="p" else None),
            Omega_ij=Omega_ij,
            generators_irrep=generators,                # <-- pass irrep generators for K!=3
            eps=eps,
        )

        # Select the component for agent_i on the active fiber
        v_param_beta = g_phi_i_q if which == "q" else g_phi_i_p
        if not np.isfinite(v_param_beta).all():
            raise FloatingPointError("non-finite v_param_beta from grad_beta_phi")

    # ---- product rule: β ∇K_align  +  K_align ∇β, with ∇β = -(β/κ) ∇K_beta ----
    beta     = beta_raw
    base     = beta[..., None] * v_param_align
    add_term = -(beta * KL1_map / max(kappa, eps))[..., None] * v_param_beta
    contrib  = base + add_term

    # ---- accumulate ----
    prev = getattr(agent_i, grad_key, None)
    if prev is None:
        prev = np.zeros_like(contrib, dtype=np.float32)
    setattr(agent_i, grad_key, (prev + contrib).astype(np.float32, copy=False))

    # ---- energy accounting ----
    accumulate_alignment_energy(
        ctx, agent_i, agent_j,
        field=field,
        joint_mask=joint_mask,
        mu_i=mu_i, sigma_i=sigma_i,
        mu_j_t=mu_j_t,
        sigma_j_t=Sigma_j_t,
        eps=eps,
    )

     # optional debug
    PRINT_SIGN = False
    if PRINT_SIGN:
        aid  = _aid(agent_i)
        ajid = getattr(agent_j, "id", "?")
        spatial_axes = tuple(range(contrib.ndim - 1))
        g_mean = np.nanmean(contrib, axis=spatial_axes)
        g_abs_mean = float(np.nanmean(np.abs(contrib)))
        print(f"[PHI-GRAD] field={field} ai={aid} aj={ajid} "
              f"mean={np.array2string(g_mean, precision=6, suppress_small=True)} "
              f"|g|_mean={g_abs_mean:.3e}", flush=True)
    




def accumulate_alignment_energy(
    ctx,
    agent_i, agent_j,
    *,
    field: str,                  # "phi" or "phi_model"
    joint_mask,                  # boolean/broadcastable vector for active pixels
    mu_i, sigma_i,               # Ai's μ/Σ (already sliced/broadcasted as in grad path)
    mu_j_t,
    sigma_j_t: np.ndarray | None = None,        # NEW: covariance in i-frame
    sigma_j_t_inv: np.ndarray | None = None,    # kept for back-compat
    eps: float = 1e-8,
    per_agent: bool | None = None,
):
    import numpy as np
    from runtime_context import energy_acc_add
    from core.numerical_utils import kl_gaussian, safe_inv, sanitize_sigma

    mu_i = np.asarray(mu_i, np.float64, order="C")
    Si   = sanitize_sigma(np.asarray(sigma_i, np.float64, order="C"), eps=max(eps, 1e-10))

    if sigma_j_t is not None:
        Sj_t = sanitize_sigma(np.asarray(sigma_j_t, np.float64, order="C"), eps=max(eps, 1e-10))
    else:
        
        A = np.asarray(sigma_j_t_inv, np.float64, order="C")
        A = 0.5 * (A + np.swapaxes(A, -1, -2))
        # simple SPD projection via covariance sanitizer (works for precision too)
        A = sanitize_sigma(A, eps=max(eps, 1e-10))
        Sj_t = safe_inv(A, eps=max(eps, 1e-10))

    kl_px = kl_gaussian(mu_i, Si, mu_j_t, Sj_t, eps=max(eps, 1e-10))  # (...,)

    # ref has shape (*S,)
    S = kl_px.shape
    if joint_mask is None:
        m = np.ones(S, dtype=np.float64)
    else:
        m = np.asarray(joint_mask, dtype=np.float64)
        if m.shape != S:
            raise ValueError(f"joint_mask shape {m.shape} != {S}")

    align_sum = float(np.sum(kl_px * m))

    bucket = "align_q_sum" if field == "phi" else "align_p_sum"
    energy_acc_add(ctx, bucket, align_sum)

    if per_agent is None:
        per_agent = bool(getattr(getattr(ctx, "step_cfg", None), "align_track_per_agent", False))
    if per_agent:
        aid = getattr(agent_i, "id", None)
        if aid is not None:
            energy_acc_add(ctx, f"{bucket}[{aid}]", align_sum)

    return align_sum




def grad_kl_wrt_phi_i(
    mu_i, sigma_i,
    mu_j, sigma_j,                 
    phi_i, phi_j,                  
    Omega_ij,
    generators,
    exp_phi_i,
    exp_phi_j,
    mu_j_t,                        
    sigma_j_t_inv,                 
    eps=1e-8,
    exp_neg_phi_j=None,
    Q_all=None,
):
        
    # ---- cast to f64 for internal math ----
    mu_i   = np.asarray(mu_i,   np.float64)
    mu_j_t = np.asarray(mu_j_t, np.float64)

    Sigma_i = sanitize_sigma(np.asarray(sigma_i, np.float64), eps=eps)
   
    # Q_all → (..., a, K, K)
    if Q_all is None:
        Q_all = d_exp_exact(np.asarray(phi_i, np.float64), generators)
    
    Q = np.stack([np.asarray(x, np.float64) for x in Q_all], axis=-3)

    # exp(-phi_j) broadcast to Q lead dims
    if exp_neg_phi_j is None:
        exp_neg_phi_j = safe_omega_inv(np.asarray(exp_phi_j, np.float64))
   
    # Ω and Ω^{-1}
    Om   = np.asarray(Omega_ij, np.float64)
    Oinv = safe_omega_inv(Om).astype(np.float64, copy=False)

    # Sanity on provided precision
    Sj_inv = np.asarray(sigma_j_t_inv, np.float64)
    
    Sj_inv = 0.5 * (Sj_inv + np.swapaxes(Sj_inv, -1, -2))
    
    # Core pieces
    delta_mu = (mu_i - mu_j_t)                     # (..., K)
    mu_j_src = np.einsum("...ij,...j->...i", Oinv, mu_j_t, optimize=True)  # (..., K)

    # dΩ/dφ_i^a = Q[a] @ e^{-φ_j}
    Q = np.einsum("...aik,...kj->...aij", Q, exp_neg_phi_j, optimize=True)
    Q_T = np.swapaxes(Q, -1, -2)
   
    # dΩ Ω^{-1}
    Q_tilde   = np.einsum("...aik,...kj->...aij", Q, Oinv, optimize=True)  
    Qtilde_T  = np.swapaxes(Q_tilde, -1, -2)
    
    # ---- precision (trace) term:  -1/2 * ⟨ A, Q̃ Σ_i + Σ_i Q̃^T ⟩
    t1 = np.einsum("...ij,...ajk,...ki->...a", Sj_inv, Q_tilde,  Sigma_i, optimize=True)
    t2 = np.einsum("...aij,...jk, ...ki->...a", Qtilde_T, Sj_inv, Sigma_i, optimize=True)
    trace_term = -0.5 * (t1 + t2)
    
    # mean term
    tmp1 = np.einsum("...aij,...j->...ai", Q_T,    delta_mu, optimize=True)
    tmp2 = np.einsum("...ij,...aj->...ai", Sj_inv, tmp1,     optimize=True)
    mean_term = -np.einsum("...i,...ai->...a", mu_j_src, tmp2, optimize=True)
    
    # ---- Mahalanobis (through ∂A) term: +1/2 * Δμ^T ( A Q̃ + Q̃^T A ) Δμ
    v1 = np.einsum("...ij,...j->...i", Sj_inv, delta_mu, optimize=True)          # A Δμ
    part1 = np.einsum("...aij,...j->...ai", Qtilde_T, v1, optimize=True)         # Q̃^T A Δμ
    v2    = np.einsum("...aij,...j->...ai", Q_tilde,  delta_mu, optimize=True)   # Q̃ Δμ
    part2 = np.einsum("...ij,...aj->...ai", Sj_inv,   v2, optimize=True)         # A Q̃ Δμ
    mahal_term = 0.5 * np.einsum("...i,...ai->...a", delta_mu, part1 + part2, optimize=True)


    # ---- previous gradients -possibly incorrect? ----
    # trace term
   # t1 = np.einsum("...ij,...ajk,...ki->...a", Sj_inv, Q,   Sigma_i, optimize=True)
   # t2 = np.einsum("...aij,...jk,...ki->...a", Q_T,   Sj_inv, Sigma_i, optimize=True)
   # trace_term = -0.5 * (t1 + t2)

    # Mahalanobis term
   # v1 = np.einsum("...ij,...j->...i", Sj_inv, delta_mu, optimize=True)
   # part1 = np.einsum("...aij,...j->...ai", Q_T, v1,           optimize=True)
   # v2    = np.einsum("...aij,...j->...ai", Q,   delta_mu,     optimize=True)
   # part2 = np.einsum("...ij,...aj->...ai", Sj_inv, v2,        optimize=True)
   # mahal_term = 0.5 * np.einsum("...i,...ai->...a", delta_mu, part1 + part2, optimize=True)

    grad = (trace_term + mean_term + mahal_term)
    #print(f"grad = {grad}")
    return grad





# ─────────────────────────────────────────────────────────────────────────────
#            SELF AND FEEDBACK GRADS
# ─────────────────────────────────────────────────────────────────────────────


def accumulate_phi_morphism_self_feedback(
    ctx,
    agent_i,
    generators_src, generators_tgt,
    *,
    field: str = "phi",
    fisher_inv_key: str | None = None,
    grad_key: str | None = None,
    phi_self_func=None,
    phi_feedback_func=None,
):
    """
    Accumulate SELF + FEEDBACK gradients for φ (or φ̃) into agent_i.<grad_key>.
    Pipeline: Jinv^T (param-covector) → Fisher^{-1} (body) → Jinv (param-vector).
    Uses cached Φ̃ and reuses pushed mean/precision if available.
    """
   
    assert fisher_inv_key and grad_key, "fisher_inv_key and grad_key are required"

    PRINT_SIGN = False

    eps   = float(cfg_get(ctx, "eps", 1e-8))
    tau   = float(cfg_get(ctx, "support_tau", 1e-6))
    alpha = float(cfg_get(ctx, "alpha", 0.0))
    fbw   = float(cfg_get(ctx, "feedback_weight", 0.0))

    # (H,W,1) mask for broadcasting with (...,A)
    mask = mask_hw(agent_i, tau=tau, mode="float3")
    if not np.any(mask):
        return

    # fields & base φ
    mu_q,  sigma_q  = agent_i.mu_q_field,  agent_i.sigma_q_field
    mu_p,  sigma_p  = agent_i.mu_p_field,  agent_i.sigma_p_field
    phi     = np.asarray(agent_i.phi,       np.float32)
    phi_t   = np.asarray(agent_i.phi_model, np.float32)

    base_phi = phi if field == "phi" else phi_t

    # transports & Jinv (cache-first)
    exp_this, exp_other, Jinv, which, G_q, G_p = exp_and_jinv_single(
        ctx, agent_i, field, base_phi, generators_src, generators_tgt
    )

    # Φ̃ from central cache (q <- p)
    Phi_tilde = Phi_cached(ctx, agent_i, kind="p_to_q")  # (H,W,K_q,K_p)

    # Reuse pushed mean/precision from μ/Σ pass if present, else compute once
    mu_p_push  = getattr(agent_i, "_mu_p_push",          None)  # Φ̃ μ_p
    A_inv_push = getattr(agent_i, "_Sigma_p_push_inv",    None)  # (Φ̃ Σ_p Φ̃ᵀ)^{-1}
    if (mu_p_push is None) or (A_inv_push is None):
        mu_p_push, _, A_inv_push = push_gaussian(
            mu=mu_p, Sigma=sigma_p, M=Phi_tilde,
            eps=eps, return_inv=True, assume_orthogonal=False
        )
        # keep for the rest of this step
        setattr(agent_i, "_mu_p_push",         mu_p_push.astype(np.float32, copy=False))
        setattr(agent_i, "_Sigma_p_push_inv",  A_inv_push.astype(np.float32, copy=False))

        # Fisher^{-1}: treat missing as identity (no-op, but warn once)
    F_inv = getattr(agent_i, fisher_inv_key, None)
    
    if F_inv is None:      
        print(f"[warn] Fisher metric missing for agent {getattr(agent_i,'id', '?')}, "
                  f"field={field}; using identity.\n\n\n\n")
            #setattr(agent_i, "_warned_missing_fisher", True)
        Fi = np.eye(base_phi.shape[-1], dtype=np.float32)  # identity acts as neutral metric
    else:
        Fi = np.asarray(F_inv, dtype=np.float32, order="C")

    total = np.zeros_like(base_phi, dtype=np.float32)
    self_contrib = fb_contrib = None

   # -------- SELF term --------
    if alpha > 0.0 and phi_self_func is not None:
        # unified argument set (includes cached fast-path values;
        # the target function must accept them)
        g_param = phi_self_func(
            mu_q=mu_q, sigma_q=sigma_q,
            mu_p=mu_p, sigma_p=sigma_p,
            Phi_tilde_0=getattr(agent_i, "Phi_tilde_0", None),
            phi=phi, phi_tilde=phi_t,
            generators_q=G_q, generators_p=G_p,
            exp_phi=exp_this if field == "phi" else exp_other,
            exp_phi_tilde=exp_other if field == "phi" else exp_this,
            # always provide fast-path extras
            Phi_tilde=Phi_tilde,
            A_inv_cached=A_inv_push,
            mu_t_cached=mu_p_push,
            eps=eps,
        )
        if g_param is None:
            raise RuntimeError("phi_self_func returned None; check arguments.")
    
        # param-covector → body-covector → Fisher^{-1} → param-vector
        g_body = np.einsum("...ji,...j->...i", Jinv, g_param, optimize=True)
        v_body = g_body if Fi is None else np.einsum("...ab,...b->...a", Fi, g_body, optimize=True)
        v_param = np.einsum("...ab,...b->...a", Jinv, v_body, optimize=True)
    
        self_contrib = alpha * v_param * mask
        total += self_contrib
    
    elif alpha > 0.0:
        print(f"[warn] phi_self_func is None for agent {getattr(agent_i,'id','?')} (field={field})\n\n\n\n\n\n\n")
    
    # -------- FEEDBACK term --------
    if fbw > 0.0 and phi_feedback_func is not None:
        g_param = phi_feedback_func(
            mu_p=mu_p, sigma_p=sigma_p,
            mu_q=mu_q, sigma_q=sigma_q,
            Phi_0=getattr(agent_i, "Phi_0", None),
            phi=phi, phi_tilde=phi_t,
            exp_phi=exp_this if field == "phi" else exp_other,
            exp_phi_tilde=exp_other if field == "phi" else exp_this,
            eps=eps,
            generators_q=G_q, generators_p=G_p,
        )
        if g_param is None:
            raise RuntimeError("phi_feedback_func returned None; check arguments.")
    
        g_body = np.einsum("...ji,...j->...i", Jinv, g_param, optimize=True)
        v_body = g_body if Fi is None else np.einsum("...ab,...b->...a", Fi, g_body, optimize=True)
        v_param = np.einsum("...ab,...b->...a", Jinv, v_body, optimize=True)
    
        fb_contrib = fbw * v_param * mask
        total += fb_contrib
    
    elif fbw > 0.0:
        print(f"[warn] phi_feedback_func is None for agent {getattr(agent_i,'id','?')} (field={field})\n\n\n\n\n\n")

    prev = getattr(agent_i, grad_key, None)
    
    if prev is None:
        prev = np.zeros_like(total, dtype=np.float32)
    setattr(agent_i, grad_key, prev + total)

    if PRINT_SIGN:
        aid = _aid(agent_i)
        log_phi_grad_like(aid, field, "self", self_contrib)
        log_phi_grad_like(aid, field, "feedback", fb_contrib)
        log_phi_grad_like(aid, field, "total", total)



#==============================================================================
#
#                    WITH RESPECT TO phi_i TERMS
#                       VALIDATED
#==============================================================================


def grad_self_phi_direct(
    mu_q, sigma_q, mu_p, sigma_p, Phi_tilde_0,
    phi, phi_tilde, generators_q, generators_p,
    exp_phi, exp_phi_tilde, *,
    eps=1e-8,
    
    Phi_tilde=None,          # (H,W,K_q,K_p) from cache
    A_inv_cached=None,       # (H,W,K_q,K_q)  inverse of Φ̃ Σ_p Φ̃ᵀ
    mu_t_cached=None,        # (H,W,K_q)      Φ̃ μ_p
    Q_all=None,
    exp_neg_phi_tilde=None
):
    d, K_q, _ = generators_q.shape

    # Inverse of exp_phi_tilde if needed for dΦ̃
    if exp_neg_phi_tilde is None:
        #print("exp-phi~ is none\n\n\n")
        exp_neg_phi_tilde = safe_omega_inv(exp_phi_tilde)

    # Derivative blocks (still need these)
    if Q_all is None:
        #print("q-all is none\n\n\n")
        Q_all = np.stack(d_exp_exact(phi, generators_q), axis=-3)  # (..., d, K_q, K_q)

    # Pull Φ̃ from cache (or build only if missing)
    if Phi_tilde is None:
        #print("Phi~ is none\n\n\n")
        Phi_tilde = np.einsum("...ik,...kj,...jl->...il",
                              exp_phi, Phi_tilde_0, exp_neg_phi_tilde, optimize=True)

    Phi_tilde_T = np.swapaxes(Phi_tilde, -1, -2)

    # A^{-1} and Φ̃ μ_p: reuse when provided
    if (A_inv_cached is None) or (mu_t_cached is None):
        #print("pushes are none\n\n\n")
        mu_t, _, A_inv = push_gaussian(
            mu=mu_p, Sigma=sigma_p, M=Phi_tilde,
            eps=eps, return_inv=True, assume_orthogonal=False
        )
    else:
        mu_t, A_inv = mu_t_cached, A_inv_cached

    delta_mu = mu_q - mu_t

    # ∂Φ̃_a = Q_a Φ̃₀ e^{-φ̃}
    dPhi = np.einsum("...aik,...kj,...jl->...ail", Q_all, Phi_tilde_0, exp_neg_phi_tilde, optimize=True)
    dPhi_T = np.swapaxes(dPhi, -1, -2)

    # dA = dΦ̃ Σ_p Φ̃ᵀ + Φ̃ Σ_p dΦ̃ᵀ
    dA = (
        np.einsum("...aik,...kl,...lj->...aij", dPhi,       sigma_p, Phi_tilde_T, optimize=True) +
        np.einsum("...ik, ...kl,...alj->...aij", Phi_tilde, sigma_p, dPhi_T,      optimize=True)
    )

    # term1: - (∂Φ̃ μ_p)^T A^{-1} Δμ
    dPhi_mu_p = np.einsum("...aij,...j->...ai", dPhi, mu_p, optimize=True)
    term1 = -np.einsum("...ai,...i->...a",
                       dPhi_mu_p,
                       np.einsum("...ij,...j->...i", A_inv, delta_mu, optimize=True),
                       optimize=True)

    # term2: + 1/2 tr(A^{-1} dA)
    term2 = 0.5 * np.einsum("...ij,...aij->...a", A_inv, dA, optimize=True)

    # M = A^{-1} dA A^{-1}
    M = np.einsum("...ij,...ajk,...kl->...ail", A_inv, dA, A_inv, optimize=True)

    # term3: - 1/2 Δμ^T M Δμ
    term3 = -0.5 * np.einsum("...i,...aij,...j->...a", delta_mu, M, delta_mu, optimize=True)

    # term4: - 1/2 tr(M Σ_q)
    term4 = -0.5 * np.einsum("...aij,...ji->...a", M, sigma_q, optimize=True)

    return (term1 + term2 + term3 + term4).astype(np.float32, copy=False)


def grad_self_phi_tilde_direct(
    mu_q, sigma_q, mu_p, sigma_p, Phi_tilde_0,
    phi, phi_tilde, generators_q, generators_p,
    exp_phi, exp_phi_tilde, *,
    eps=1e-8,
    Phi_tilde=None,          # cached (S*,K_q,K_p)
    A_inv_cached=None,       # cached (S*,K_q,K_q)
    mu_t_cached=None,        # cached Φ̃ μ_p
    Q_tilde_all=None,
    exp_neg_phi_tilde=None
):
    d, K_p, _ = generators_p.shape

    if exp_neg_phi_tilde is None:
        #print("e^-phi~ is none\n\n\n")
        exp_neg_phi_tilde = safe_omega_inv(exp_phi_tilde)

    if Q_tilde_all is None:
        #print("Q~-all is none\n\n\n")
        Q_tilde_all = np.stack(d_exp_exact(phi_tilde, generators_p), axis=-3)

    if Phi_tilde is None:
        #print("Phi~ is none\n\n\n")
        Phi_tilde = np.einsum("...ik,...kj,...jl->...il",
                              exp_phi, Phi_tilde_0, exp_neg_phi_tilde, optimize=True)
    Phi_tilde_T = np.swapaxes(Phi_tilde, -1, -2)

    if (A_inv_cached is None) or (mu_t_cached is None):
        mu_t, _, A_inv = push_gaussian(
            mu=mu_p, Sigma=sigma_p, M=Phi_tilde,
            eps=eps, return_inv=True, assume_orthogonal=False
        )
    else:
        mu_t, A_inv = mu_t_cached, A_inv_cached

    delta_mu = mu_q - mu_t

    # R_a = Q̃_a e^{-φ̃}, dΦ̃_a = - Φ̃ R_a
    R    = np.einsum("...aik,...kj->...aij", Q_tilde_all, exp_neg_phi_tilde, optimize=True)
    dPhi = -np.einsum("...ik,...akj->...aij", Phi_tilde, R, optimize=True)
    dPhi_T = np.swapaxes(dPhi, -1, -2)

    dA = (
        np.einsum("...aik,...kl,...lj->...aij", dPhi,       sigma_p, Phi_tilde_T, optimize=True) +
        np.einsum("...ik, ...kl,...alj->...aij", Phi_tilde, sigma_p, dPhi_T,      optimize=True)
    )

    dPhi_mu_p = np.einsum("...aij,...j->...ai", dPhi, mu_p, optimize=True)
    term1 = -np.einsum("...ai,...i->...a",
                       dPhi_mu_p,
                       np.einsum("...ij,...j->...i", A_inv, delta_mu, optimize=True),
                       optimize=True)

    term2 = 0.5 * np.einsum("...ij,...aij->...a", A_inv, dA, optimize=True)

    M = np.einsum("...ij,...ajk,...kl->...ail", A_inv, dA, A_inv, optimize=True)

    term3 = -0.5 * np.einsum("...i,...aij,...j->...a", delta_mu, M, delta_mu, optimize=True)
    term4 = -0.5 * np.einsum("...aij,...ji->...a", M, sigma_q, optimize=True)

    return (term1 + term2 + term3 + term4).astype(np.float32, copy=False)







def grad_feedback_phi_direct(
    mu_p, sigma_p,
    mu_q, sigma_q,
    Phi_0,
    phi,                # (..., d)
    phi_tilde,          # (..., d)
    generators_q,       # (d, K_q, K_q)
    generators_p,
    exp_phi,            # (..., K_q, K_q)
    exp_phi_tilde,      # (..., K_p, K_p)
    eps=1e-8,
    Q_all=None,         # (..., d, K_q, K_q) = d_exp_exact(phi, generators_q)
    exp_neg_phi=None    # (..., K_q, K_q) = e^{-φ}
):
    """
    Vectorized over 'a': returns (..., d)
    Φ = e^{φ̃} Φ₀ e^{-φ}, ∂Φ = - Φ · (e^{-φ} (∂ e^{φ}) e^{-φ})
    """
    
    d, K_q, _ = generators_q.shape

    if exp_neg_phi is None:
        exp_neg_phi = safe_omega_inv(exp_phi)
    if Q_all is None:
        # stack as (..., d, K_q, K_q)
        Q_list = d_exp_exact(phi, generators_q)
        Q_all = np.stack(Q_list, axis=-3)  # assuming list of d arrays

    # Φ and Φᵀ
    Phi = np.einsum("...ik,...kj,...jl->...il", exp_phi_tilde, Phi_0, exp_neg_phi)
    Phi_T = np.swapaxes(Phi, -1, -2)

    # A, A^{-1}
    A = np.einsum("...ik,...kl,...lj->...ij", Phi, sigma_q, Phi_T)
    A = sanitize_sigma(A, eps=eps)
    A_inv = safe_inv(A, eps=eps)

    # Δμ and v
    Phi_mu_q = np.einsum("...ij,...j->...i", Phi, mu_q)
    delta_mu = mu_p - Phi_mu_q
    v = np.einsum("...ij,...j->...i", A_inv, delta_mu)  # (..., K_p)

    # Q̄_a = e^{-φ} Q_a e^{-φ}
    Q_bar = np.einsum("...ik,...akl,...lj->...aij", exp_neg_phi, Q_all, exp_neg_phi)

    # dΦ_a = - Φ Q̄_a
    dPhi = -np.einsum("...ik,...akj->...aij", Phi, Q_bar)
    dPhi_T = np.swapaxes(dPhi, -1, -2)

    # dA_a
    dA = (
        np.einsum("...aik,...kl,...lj->...aij", dPhi, sigma_q, Phi_T) +
        np.einsum("...ik,...kl,...alj->...aij", Phi,  sigma_q, dPhi_T)
    )

    # Term 1
    dPhi_mu = np.einsum("...aij,...j->...ai", dPhi, mu_q)       # (..., a, K_p)
    term1 = -np.einsum("...ai,...i->...a", dPhi_mu, v)

    # Term 2
    term2 = 0.5 * np.einsum("...ij,...aij->...a", A_inv, dA)

    # M_a = A^{-1} dA_a A^{-1}
    M = np.einsum("...ij,...ajk,...kl->...ail", A_inv, dA, A_inv)

    # Term 3
    term3 = -0.5 * np.einsum("...i,...aij,...j->...a", delta_mu, M, delta_mu)

    # Term 4
    term4 = -0.5 * np.einsum("...aij,...ji->...a", M, sigma_p)

    grad = (term1 + term2 + term3 + term4).astype(np.float32, copy=False)
    return grad




def grad_feedback_phi_tilde_direct(
    mu_p, sigma_p,
    mu_q, sigma_q,
    Phi_0,
    phi, 
    phi_tilde,
    generators_q, 
    generators_p,
    exp_phi, 
    exp_phi_tilde,
    eps=1e-8,
    Q_tilde_all=None,       # (..., d, K_p, K_p) = d_exp_exact(phi_tilde, generators_p)
    exp_neg_phi_tilde=None  # (..., K_p, K_p) = e^{-φ̃}
):
    """
    Vectorized over 'a': returns (..., d)
    Left-trivialize: dΦ_a = L_a Φ,  L_a = (∂e^{φ̃}/∂φ̃^a) e^{-φ̃}.
    """
    
    d, K_p, _ = generators_p.shape
    
    if exp_neg_phi_tilde is None:
        exp_neg_phi_tilde = safe_omega_inv(exp_phi_tilde)
    if Q_tilde_all is None:
        Q_list = d_exp_exact(phi_tilde, generators_p)
        Q_tilde_all = np.stack(Q_list, axis=-3)

    # Φ
    exp_neg_phi = safe_omega_inv(exp_phi)
    Phi   = np.einsum("...ik,...kj,...jl->...il", exp_phi_tilde, Phi_0, exp_neg_phi)
    Phi_T = np.swapaxes(Phi, -1, -2)

    
    A = np.einsum("...ik,...kl,...lj->...ij", Phi, sigma_q, Phi_T)
    A = sanitize_sigma(A, eps=eps)
    A_inv = safe_inv(A, eps=eps)

    Phi_mu_q = np.einsum("...ij,...j->...i", Phi, mu_q)
    delta_mu = mu_p - Phi_mu_q
    v = np.einsum("...ij,...j->...i", A_inv, delta_mu)

    # L_a = Q̃_a e^{-φ̃}
    L = np.einsum("...aik,...kj->...aij", Q_tilde_all, exp_neg_phi_tilde)

    # dΦ_a = L_a Φ
    dPhi = np.einsum("...aik,...kj->...aij", L, Phi)
    dPhi_T = np.swapaxes(dPhi, -1, -2)

    dA = (
        np.einsum("...aik,...kl,...lj->...aij", dPhi, sigma_q, Phi_T) +
        np.einsum("...ik,...kl,...alj->...aij", Phi,  sigma_q, dPhi_T)
    )

    dPhi_mu = np.einsum("...aij,...j->...ai", dPhi, mu_q)
    term1 = -np.einsum("...ai,...i->...a", dPhi_mu, v)

    term2 = 0.5 * np.einsum("...ij,...aij->...a", A_inv, dA)

    M = np.einsum("...ij,...ajk,...kl->...ail", A_inv, dA, A_inv)

    term3 = -0.5 * np.einsum("...i,...aij,...j->...a", delta_mu, M, delta_mu)
    term4 = -0.5 * np.einsum("...aij,...ji->...a", M, sigma_p)

    grad = term1 + term2 + term3 + term4
    return grad









