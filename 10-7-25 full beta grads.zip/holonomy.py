
from __future__ import annotations
import numpy as np

# ---------- small utils ----------

def _eye3(dtype=np.float64):
    return np.eye(3, dtype=dtype)

def _sym(S):
    return 0.5*(S + np.swapaxes(S, -1, -2))

def _so3_inv(R):  # for SO(3) numeric hygiene
    return np.swapaxes(R, -1, -2)

def _clip_log_eigs(S, eps=1e-12):
    # Return log(S) for SPD S via eigh with eigenfloor
    w, V = np.linalg.eigh(_sym(S) + eps*np.eye(3, dtype=S.dtype))
    w = np.clip(w, eps, None)
    return (V * np.log(w)) @ np.swapaxes(V, -1, -2)

def _so3_log_angle(R):
    R = _sym(R)  # cheap clamp for trace
    tr = np.clip(np.trace(R, axis1=-2, axis2=-1), -1.0, 3.0)
    ang = np.arccos(0.5*(tr - 1.0))
    return float(np.asarray(ang))

# ---------- core abstraction ----------

class VertMap:
    """
    Vertical transport at one base point.
    Acts on vectors/covariances via T = A @ R, where:
      R ∈ SO(3) (frame action), A ∈ GL(3) (linear intertwiner).
    Either can be None (treated as identity).
    """
    __slots__ = ("R", "A", "label")
    def __init__(self, R: np.ndarray|None=None, A: np.ndarray|None=None, label: str=""):
        self.R = R  # (3,3) or None
        self.A = A  # (3,3) or None
        self.label = label

    def T(self) -> np.ndarray:
        R = self.R if self.R is not None else _eye3()
        A = self.A if self.A is not None else _eye3()
        return A @ R

    def compose(self, g: "VertMap") -> "VertMap":
        # function composition: apply g, then self  (self ∘ g)
        R = None
        if self.R is not None and g.R is not None:
            R = self.R @ g.R
        elif self.R is not None:
            R = self.R.copy()
        elif g.R is not None:
            R = g.R.copy()

        A = None
        if self.A is not None and g.A is not None:
            A = self.A @ g.A
        elif self.A is not None:
            A = self.A.copy()
        elif g.A is not None:
            A = g.A.copy()

        return VertMap(R=R, A=A, label=f"{self.label}∘{g.label}")

    # actions
    def act_mu(self, mu: np.ndarray) -> np.ndarray:
        return self.T() @ mu

    def act_Sigma(self, Sigma: np.ndarray) -> np.ndarray:
        T = self.T()
        return _sym(T @ Sigma @ T.T)

# ---------- adapters to your suite (vertical) ----------

def vert_from_Omega(ctx, ai, aj, *, which: str) -> VertMap:
    """
    Same-site cross-agent frame swap.
    Ω_{i←j}^which = E_i E_j^T, and acts as R on μ/Σ (A=R).
    which ∈ {"q","p"}
    """
    from transport_cache import E_grid
    Ei = np.asarray(E_grid(ctx, ai, which=which), np.float64)
    Ej = np.asarray(E_grid(ctx, aj, which=which), np.float64)
    # One base point → pick the same lattice index for both; users pass a site if needed.
    # For now assume spatially constant or we are evaluating at a chosen site/index.
    R = Ei @ Ej.T
    return VertMap(R=R, A=R, label=f"Ω^{which}[{getattr(ai,'id','?')}←{getattr(aj,'id','?')}]")

def vert_from_Phi(ctx, ai, *, kind: str) -> VertMap:
    """
    Intra-agent fiber morphism at one site:
      kind="q_to_p" for Φ_i, kind="p_to_q" for Φ̃_i.
    Returns a pure A (no R) unless your Φ stores a frame.
    """
    from transport_cache import Phi
    T = np.asarray(Phi(ctx, ai, kind=kind), np.float64)
    return VertMap(R=None, A=T, label=f"{'Φ' if kind=='q_to_p' else 'Φ̃'}[{getattr(ai,'id','?')}]")

# ---------- spatial links (optional) ----------

def spatial_link_body(ctx, ai, mu: int, *, generators, which="q", dx=1.0,
                      include_A=True, include_phi=True) -> VertMap:
    """
    One-step body-frame link along axis mu.
    L_i(x,mu) = E_i(x+μ)^-1 · U_geom(x,mu) · E_i(x)
    - include_A: include geometric parallel transport from global A
    - include_phi: include local frame variation (E-field change)
    """
    from transport_cache import E_grid, ensure_global_A
    from core.get_generators import exp_lie_algebra_irrep

    # Default identity if both disabled
    if not include_A and not include_phi:
        return VertMap(R=_eye3(), A=_eye3(), label=f"L[{ai.id},μ={mu}] I")

    Ei = np.asarray(E_grid(ctx, ai, which=which), np.float64)  # (*S,3,3)
    Ei_fwd = np.roll(Ei, +1, axis=mu)  # spatial shift along axis mu

    # Compute per-link components
    U_geom = _eye3()
    if include_A:
        A = np.asarray(ensure_global_A(ctx, spatial_shape=Ei.shape[:-2]), np.float64)
        a_mu = A[..., mu, :] * float(dx)
        U_geom = np.asarray(exp_lie_algebra_irrep(a_mu, generators=generators), np.float64)

    # Frame difference
    R_phi = _so3_inv(Ei_fwd) @ Ei if include_phi else _eye3()

    # Combine:  E(x+μ)^-1 · U_geom · E(x)
    L = _so3_inv(Ei_fwd) @ U_geom @ Ei
    # If both A and φ contributions are included, R_phi was implicitly used above,
    # but we expose it explicitly for clarity.
    if include_A and include_phi:
        L = R_phi @ U_geom  # Equivalent since R_phi = E(x+μ)^-1 E(x)

    return VertMap(R=L, A=L, label=f"L[{getattr(ai,'id','?')},μ={mu}]")


# ---------- loop composition & metrics ----------

def compose_loop(maps: list[VertMap]) -> VertMap:
    H = VertMap(R=_eye3(), A=_eye3(), label="H")
    for vm in maps:
        H = vm.compose(H)
    return H

def holonomy_metrics(H: VertMap):
    R = H.R if H.R is not None else _eye3()
    A = H.A if H.A is not None else _eye3()
    ang = _so3_log_angle(R)
    spd = float(np.linalg.norm(_clip_log_eigs(A @ A.T), "fro"))
    return {"angle_SO3": ang, "spd_defect": spd, "R": R, "A": A}

def kl_defect(mu0: np.ndarray, S0: np.ndarray, H: VertMap) -> float:
    # KL( N0 || push_through(H)(N0) )
    mu1 = H.act_mu(mu0)
    S1  = H.act_Sigma(S0)
    K = mu0.shape[0]
    # add tiny SPD jitter
    eps = 1e-12
    S1i = np.linalg.inv(S1 + eps*np.eye(K))
    dmu = (mu1 - mu0)
    t1 = np.trace(S1i @ S0)
    t2 = dmu.T @ S1i @ dmu
    sign0, logdet0 = np.linalg.slogdet(S0 + eps*np.eye(K))
    sign1, logdet1 = np.linalg.slogdet(S1 + eps*np.eye(K))
    kl = 0.5*(t1 + t2 - K + (logdet1 - logdet0))
    return float(max(0.0, kl))

# ---------- canned vertical loops (no spatial hop) ----------

def loop_intra_agent(ctx, ai):
    """Qi -> Pi -> Qi at a single site."""
    v1 = vert_from_Phi(ctx, ai, kind="q_to_p")
    v2 = vert_from_Phi(ctx, ai, kind="p_to_q")
    return [v2, v1]  # apply v1 then v2

def loop_belief_pair(ctx, ai, aj):
    """Qi -> Qj -> Qi at a single site."""
    return [vert_from_Omega(ctx, ai, aj, which="q"),
            vert_from_Omega(ctx, aj, ai, which="q")]

def loop_mixed(ctx, ai, aj):
    """Qi -> Qj -> Pj -> Pi -> Qi (agent+fiber) at a single site."""
    return [
        vert_from_Omega(ctx, ai, aj, which="q"),
        vert_from_Phi(ctx, aj, kind="q_to_p"),
        vert_from_Omega(ctx, aj, ai, which="p"),
        vert_from_Phi(ctx, ai, kind="p_to_q"),
    ]
