# -*- coding: utf-8 -*-
"""
Created on Sat Aug  9 19:38:56 2025

@author: chris and christine
"""

# diagnostics_animator.py
# Robust plotting/animation for metric_log.pkl + fields/step*.npz
# Produces PNGs + GIFs (no MP4). Matplotlib + imageio only.

import os, json, glob, math, pickle, warnings
from pathlib import Path
from dataclasses import dataclass
from typing import List, Dict, Tuple, Optional, Iterable

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")  # headless
import matplotlib.pyplot as plt
import imageio.v2 as imageio
# add near the imports
from PIL import Image, ImageDraw, ImageFont

# ─────────────────────────────────────────────────────────────────────────────
# SAFETY & HELPERS
# ─────────────────────────────────────────────────────────────────────────────

def safe_mkdir(p: str):
    Path(p).mkdir(parents=True, exist_ok=True)

def safe_nan(x):
    return np.nan_to_num(x, nan=0.0, posinf=0.0, neginf=0.0)

def pclip(arr, lo=1.0, hi=99.0):
    """Percentile clip (robust contrast)."""
    a = arr[np.isfinite(arr)]
    if a.size == 0:
        return 0.0, 1.0
    vmin, vmax = np.percentile(a, [lo, hi])
    if not np.isfinite(vmin): vmin = float(np.min(a))
    if not np.isfinite(vmax): vmax = float(np.max(a))
    if vmax <= vmin:
        vmax = vmin + 1.0
    return float(vmin), float(vmax)

def nice_grid(n, max_cols=4):
    cols = min(max_cols, max(1, int(math.ceil(math.sqrt(n)))))
    rows = int(math.ceil(n / cols))
    return rows, cols

def as_uint8(img, vmin=None, vmax=None):
    if vmin is None or vmax is None:
        vmin, vmax = pclip(img)
    x = np.clip((img - vmin) / (vmax - vmin + 1e-12), 0, 1)
    return (x * 255.0 + 0.5).astype(np.uint8)

# replace overlay_mask_outline with a scipy-free, numpy-only version (keeps sizes consistent)
def overlay_mask_outline(gray_uint8, mask_bool, thickness=1):
    if mask_bool is None:
        return gray_uint8
    m = mask_bool.astype(np.uint8)
    # 3x3 neighborhood dilation
    mp = np.pad(m, 1, mode="edge")
    s = (
        mp[0:-2,0:-2] + mp[0:-2,1:-1] + mp[0:-2,2:] +
        mp[1:-1,0:-2] + mp[1:-1,1:-1] + mp[1:-1,2:] +
        mp[2:  ,0:-2] + mp[2:  ,1:-1] + mp[2:  ,2:]
    )
    dil = (s > 0)
    edge = dil ^ (m > 0)

    out = np.stack([gray_uint8]*3, axis=-1) if gray_uint8.ndim == 2 else gray_uint8.copy()
    out[edge] = [255, 255, 255]
    return out

# helper: caption without matplotlib, no temp PNGs
def _caption_frame(rgb: np.ndarray, text: str, banner_px: int = 24, scale: int = 1) -> np.ndarray:
    """
    rgb: (H,W,3) uint8
    returns: (H+banner_px, W, 3) uint8 with text at bottom. Optional integer upscaling.
    """
    H, W = rgb.shape[:2]
    canvas = np.zeros((H + banner_px, W, 3), dtype=np.uint8)
    canvas[:H] = rgb

    # draw with PIL
    img = Image.fromarray(canvas, mode="RGB")
    draw = ImageDraw.Draw(img)
    try:
        # try a common font; falls back to default
        font = ImageFont.load_default()
    except Exception:
        font = None
    draw.text((5, H + banner_px - 18), text, fill=(255, 255, 255), font=font)

    out = np.array(img, dtype=np.uint8)

    if isinstance(scale, int) and scale > 1:
        out = np.repeat(np.repeat(out, scale, axis=0), scale, axis=1)
    return out


def downsample(arr, ds: int):
    if ds is None or ds <= 1:
        return arr
    H, W = arr.shape[:2]
    H2, W2 = H // ds, W // ds
    return arr[:H2*ds, :W2*ds].reshape(H2, ds, W2, ds, *arr.shape[2:]).mean(axis=(1,3))


# ─────────────────────────────────────────────────────────────────────────────
# DATA INDEX
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class RunIndex:
    root: Path
    fields_dir: Path
    steps: List[int]
    field_paths: Dict[int, Path]
    metrics_path: Optional[Path]
    per_agent_csv: Optional[Path]

def build_index(checkpoints_dir: str) -> RunIndex:
    root = Path(checkpoints_dir)
    fields_dir = root / "fields"
    field_paths = {}
    if fields_dir.exists():
        for p in sorted(fields_dir.glob("step*.npz")):
            try:
                s = int(p.stem.replace("step", ""))
                field_paths[s] = p
            except:
                pass
    steps = sorted(field_paths.keys())
    metrics_path = root / "metric_log.pkl"
    per_agent_csv = root / "per_agent_metrics.csv"
    return RunIndex(
        root=root,
        fields_dir=fields_dir,
        steps=steps,
        field_paths=field_paths,
        metrics_path=metrics_path if metrics_path.exists() else None,
        per_agent_csv=per_agent_csv if per_agent_csv.exists() else None,
    )

# ─────────────────────────────────────────────────────────────────────────────
# LOADERS
# ─────────────────────────────────────────────────────────────────────────────

def load_metrics(idx: RunIndex) -> pd.DataFrame:
    rows = []
    if idx.metrics_path is not None:
        with open(idx.metrics_path, "rb") as f:
            ml = pickle.load(f)
        # ml is list of dicts
        rows.extend(ml)
    # Fallback: aggregate from per-agent CSV if needed
    if not rows and idx.per_agent_csv is not None and idx.per_agent_csv.exists():
        df = pd.read_csv(idx.per_agent_csv)
        # group by step for totals/means
        ag = df.groupby("step").agg({
            "kl_self":"mean","kl_feedback":"mean",
            "kl_align":"mean","kl_mod_align":"mean",
            "curv_energy":"mean","curv_model_energy":"mean",
            "mass_energy":"mean","mass_model_energy":"mean"
        }).reset_index()
        ag["total_energy"] = (ag["kl_self"]+ag["kl_feedback"]+ag["kl_align"]+
                              ag["kl_mod_align"]+ag["curv_energy"]+ag["curv_model_energy"]+
                              ag["mass_energy"]+ag["mass_model_energy"])
        return ag.sort_values("step").reset_index(drop=True)
    return pd.DataFrame(rows).sort_values("step").reset_index(drop=True)

def load_field_npz(idx: RunIndex, step: int) -> Optional[dict]:
    p = idx.field_paths.get(step)
    if p is None or not p.exists():
        return None
    return dict(np.load(p, allow_pickle=False))

# ─────────────────────────────────────────────────────────────────────────────
# PLOTTING BASICS
# ─────────────────────────────────────────────────────────────────────────────

def plot_scalar_timeseries(df: pd.DataFrame, outdir: str, title_prefix=""):
    safe_mkdir(outdir)
    keys = [
        "e_self","e_feedback","e_align","e_mod_align",
        "e_mass","e_mass_mod","e_curv","e_curv_mod","total_energy"
    ]
    present = [k for k in keys if k in df.columns]
    if not present:
        return
    plt.figure(figsize=(10,6))
    for k in present:
        plt.plot(df["step"], df[k], label=k, linewidth=1.6)
    plt.xlabel("step")
    plt.ylabel("normalized energy")
    ttl = f"{title_prefix} Energies vs Step".strip()
    plt.title(ttl)
    plt.legend(ncol=3, fontsize=8)
    plt.tight_layout()
    fp = os.path.join(outdir, "energies_timeseries.png")
    plt.savefig(fp, dpi=150)
    plt.close()

def plot_per_agent_histograms(csv_path: str, outdir: str, step: Optional[int]=None):
    if not Path(csv_path).exists():
        return
    safe_mkdir(outdir)
    df = pd.read_csv(csv_path)
    if step is not None:
        df = df[df["step"]==step]
        suffix = f"_step{int(step):05d}"
    else:
        suffix = "_all"
    cols = ["kl_self","kl_feedback","kl_align","kl_mod_align",
            "curv_energy","curv_model_energy","mass_energy","mass_model_energy"]
    present = [c for c in cols if c in df.columns]
    if not present or df.empty:
        return
    rows, cols_n = nice_grid(len(present), max_cols=4)
    fig, axes = plt.subplots(rows, cols_n, figsize=(4*cols_n, 3.2*rows))
    axes = np.array(axes).reshape(-1)
    for ax, c in zip(axes, present):
        ax.hist(df[c].values, bins=30)
        ax.set_title(c)
    for ax in axes[len(present):]:
        ax.axis("off")
    plt.tight_layout()
    fp = os.path.join(outdir, f"per_agent_histos{suffix}.png")
    plt.savefig(fp, dpi=150)
    plt.close()

# ─────────────────────────────────────────────────────────────────────────────
# FIELD → GIF ANIMATORS
# ─────────────────────────────────────────────────────────────────────────────

def _extract_agent_scalar_field(npz: dict, key: str, agent_idx: int) -> Optional[np.ndarray]:
    """Returns H×W or None if key absent."""
    if key not in npz:
        return None
    arr = npz[key]
    if arr.ndim == 3 and arr.shape[0] > agent_idx:       # (N,H,W)
        return arr[agent_idx]
    if arr.ndim == 2:                                    # (H,W) already
        return arr
    return None

def _compute_phi_norm(npz: dict, agent_idx: int) -> Optional[np.ndarray]:
    if "phi" not in npz:
        return None
    P = npz["phi"]  # (N,H,W,3)
    if P.ndim != 4 or P.shape[0] <= agent_idx:
        return None
    return np.linalg.norm(P[agent_idx], axis=-1)



def animate_scalar_field(
    idx: RunIndex,
    out_gif: str,
    field_key: str,
    agent_idx: int = 0,
    mask_outline: bool = True,
    percentile=(1, 99),
    downsample_factor: Optional[int] = None,
    title: Optional[str] = None,
):
    """Animate a scalar H×W field across steps; centered, padded, and upscaled for readability."""
    from PIL import Image, ImageDraw, ImageFont

    def _center_pad(rgb: np.ndarray, target_h: int, target_w: int, pad_val=0) -> np.ndarray:
        """Center rgb (H,W,3) on a (target_h,target_w,3) canvas."""
        h, w = rgb.shape[:2]
        canvas = np.full((target_h, target_w, 3), pad_val, dtype=np.uint8)
        oy = (target_h - h) // 2
        ox = (target_w - w) // 2
        canvas[oy:oy+h, ox:ox+w] = rgb
        return canvas

    def _caption_top(rgb: np.ndarray, text: str, banner_px: int = 28) -> np.ndarray:
        """Add a caption bar on TOP (avoids bottom clipping)."""
        H, W = rgb.shape[:2]
        canvas = np.zeros((H + banner_px, W, 3), dtype=np.uint8)
        canvas[banner_px:] = rgb
        img = Image.fromarray(canvas, mode="RGB")
        draw = ImageDraw.Draw(img)
        try:
            font = ImageFont.load_default()
        except Exception:
            font = None
        # draw text with a subtle shadow for contrast
        y = (banner_px - 12) // 2
        for dx, dy in ((1,1),(0,1),(1,0)):
            draw.text((6+dx, y+dy), text, fill=(0, 0, 0), font=font)
        draw.text((6, y), text, fill=(255, 255, 255), font=font)
        return np.array(img, dtype=np.uint8)

    def _auto_scale(rgb: np.ndarray, min_side: int = 256) -> np.ndarray:
        """Nearest-neighbor upscale so the *smaller* side is at least min_side."""
        h, w = rgb.shape[:2]
        s = max(1, int(np.floor(min_side / max(1, min(h, w)))))
        if s <= 1:
            return rgb
        return np.repeat(np.repeat(rgb, s, axis=0), s, axis=1)

    safe_mkdir(Path(out_gif).parent.as_posix())
    frames = []

    # ── robust global vmin/vmax ──────────────────────────────────────────────
    vals = []
    for s in idx.steps:
        npz = load_field_npz(idx, s)
        if npz is None: 
            continue
        f = _compute_phi_norm(npz, agent_idx) if field_key == "phi_norm" else _extract_agent_scalar_field(npz, field_key, agent_idx)
        if f is None:
            continue
        if downsample_factor:
            f = downsample(f, downsample_factor)
        v = f[np.isfinite(f)]
        if v.size:
            vals.append(v)
    if vals:
        a = np.concatenate([v.ravel() for v in vals if v.size], axis=0)
        lo, hi = np.percentile(a, list(percentile))
        vmn = float(lo) if np.isfinite(lo) else float(np.min(a))
        vmx = float(hi) if np.isfinite(hi) else float(np.max(a))
        if vmx <= vmn:
            vmx = vmn + 1e-6
    else:
        vmn, vmx = 0.0, 1.0

    # ── per-step frames ──────────────────────────────────────────────────────
    for s in idx.steps:
        npz = load_field_npz(idx, s)
        if npz is None:
            continue

        mask = None
        if "mask" in npz and npz["mask"].ndim == 3 and npz["mask"].shape[0] > agent_idx:
            mask = npz["mask"][agent_idx].astype(bool)

        f = _compute_phi_norm(npz, agent_idx) if field_key == "phi_norm" else _extract_agent_scalar_field(npz, field_key, agent_idx)
        if f is None:
            continue

        if downsample_factor:
            f = downsample(f, downsample_factor)
            if mask is not None:
                mask = downsample(mask.astype(float), downsample_factor) > 0.5

        # normalize to uint8
        img = as_uint8(f, vmn, vmx)  # (H,W)
        # overlay outline (returns RGB) or expand to RGB
        if mask_outline and mask is not None:
            # overlay takes gray; returns RGB
            rgb = overlay_mask_outline(img, mask)
        else:
            rgb = np.stack([img]*3, axis=-1)

        # upscale and center on a square-ish canvas for consistent look
        rgb = _auto_scale(rgb, min_side=256)
        h, w = rgb.shape[:2]
        pad_h = ((h + 31) // 32) * 32  # friendly sizes
        pad_w = ((w + 31) // 32) * 32
        rgb = _center_pad(rgb, pad_h, pad_w, pad_val=0)

        # caption at top (prevents bottom clipping)
        frame = _caption_top(rgb, f"{title or field_key} | step={s}", banner_px=28)
        frames.append(frame.astype(np.uint8))

    if not frames:
        print(f"[WARN] No frames for {field_key} (agent {agent_idx}).")
        return

    # ── write GIF (robust) ───────────────────────────────────────────────────
    os.makedirs(os.path.dirname(out_gif), exist_ok=True)
    with imageio.get_writer(out_gif, mode="I", loop=0, duration=0.12) as wr:
        for fr in frames:
            wr.append_data(fr if fr.dtype == np.uint8 else fr.astype(np.uint8))
    print(f"[GIF] {out_gif}")


def animate_multi_fields_panel(
    idx: RunIndex,
    out_gif: str,
    field_keys: List[str],
    agent_idx: int = 0,
    percentile=(1,99),
    downsample_factor: Optional[int] = None,
    titles: Optional[List[str]] = None,
):
    """Make a 2×2 (or grid) panel GIF for multiple fields."""
    safe_mkdir(Path(out_gif).parent.as_posix())
    rows, cols = nice_grid(len(field_keys), max_cols=2)

    # compute per-field vmin/vmax for stable colors
    vmins, vmaxs = [], []
    for fk in field_keys:
        vals = []
        for s in idx.steps:
            npz = load_field_npz(idx, s)
            if npz is None: continue
            if fk == "phi_norm":
                f = _compute_phi_norm(npz, agent_idx)
            else:
                f = _extract_agent_scalar_field(npz, fk, agent_idx)
            if f is None: continue
            if downsample_factor: f = downsample(f, downsample_factor)
            vals.append(f[np.isfinite(f)])
        if vals:
            a = np.concatenate([v.ravel() for v in vals if v.size], axis=0)
            lo, hi = np.percentile(a, list(percentile))
        else:
            lo, hi = 0.0, 1.0
        if hi <= lo: hi = lo + 1e-6
        vmins.append(float(lo)); vmaxs.append(float(hi))

    frames = []
    for s in idx.steps:
        npz = load_field_npz(idx, s)
        if npz is None: 
            continue
        mask = None
        if "mask" in npz and npz["mask"].ndim==3 and npz["mask"].shape[0] > agent_idx:
            mask = npz["mask"][agent_idx].astype(bool)

        fig, axes = plt.subplots(rows, cols, figsize=(4*cols, 4*rows))
        axes = np.array(axes).reshape(-1)
        for k, fk in enumerate(field_keys):
            ax = axes[k]
            if fk == "phi_norm":
                f = _compute_phi_norm(npz, agent_idx)
            else:
                f = _extract_agent_scalar_field(npz, fk, agent_idx)
            if f is None:
                ax.axis("off"); continue
            if downsample_factor:
                f = downsample(f, downsample_factor)
            im = ax.imshow(f, vmin=vmins[k], vmax=vmaxs[k], interpolation="nearest")
            ax.set_title((titles[k] if titles and k<len(titles) else fk) + f" (step={s})", fontsize=10)
            ax.set_xticks([]); ax.set_yticks([])
            fig.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
        for ax in axes[len(field_keys):]:
            ax.axis("off")
        plt.tight_layout()
        tmp = Path(out_gif).with_suffix(f".panel_{s}.png")
        plt.savefig(tmp, dpi=120)
        plt.close()
        frames.append(imageio.imread(tmp))
        tmp.unlink(missing_ok=True)
    if not frames:
        print(f"[WARN] No frames for panel {field_keys}.")
        return
    os.makedirs(os.path.dirname(out_gif), exist_ok=True)
    with imageio.get_writer(out_gif, mode="I", loop=0, duration=0.18) as wr:
        for fr in frames:
            if fr.dtype != np.uint8:
                fr = fr.astype(np.uint8)
            if fr.ndim == 2:
                fr = np.stack([fr]*3, axis=-1)
            wr.append_data(fr)
    print(f"[GIF] {out_gif}")

# ─────────────────────────────────────────────────────────────────────────────
# PUBLIC ORCHESTRATOR
# ─────────────────────────────────────────────────────────────────────────────

def run_reports(
    checkpoints_dir: str = "checkpoints",
    outdir: str = "reports",
    n_agents_preview: int = 2,
    do_timeseries: bool = True,
    do_agent_histos: bool = True,
    do_gifs: bool = True,
    ds_factor: Optional[int] = None,     # optional downsample for large grids
):
    """
    End-to-end:
      1) Load metrics, make global energy curves.
      2) Per-agent histograms (optionally last step).
      3) GIFs for a handful of key fields for first few agents.

    Expects: checkpoints_dir/metric_log.pkl and checkpoints_dir/fields/step*.npz
    """
    safe_mkdir(outdir)
    idx = build_index(checkpoints_dir)

    # (1) Timeseries
    if do_timeseries and idx.metrics_path is not None:
        df = load_metrics(idx)
        plot_scalar_timeseries(df, os.path.join(outdir, "timeseries"))

    # (2) Per-agent histos at final step (and/or all)
    if do_agent_histos and idx.per_agent_csv is not None:
        # all
        plot_per_agent_histograms(idx.per_agent_csv, os.path.join(outdir, "histos"), step=None)
        # last step
        last = idx.steps[-1] if idx.steps else None
        if last is not None:
            plot_per_agent_histograms(idx.per_agent_csv, os.path.join(outdir, "histos"), step=last)

    if not do_gifs or not idx.steps:
        return

    # (3) GIFs for fields (toggle by presence)
    keys_possible = [
        "kl_self", "kl_feedback",          # from field logger
        "belief_align", "model_align",     # optional
        "Fq_norm", "Fp_norm",              # optional when curvature computed
        # synthetic field derived on the fly:
        "phi_norm",
    ]

    # detect present keys
    present = set()
    npz0 = load_field_npz(idx, idx.steps[0])
    if npz0 is None:
        print("[WARN] No field dumps found; skipping GIFs.")
        return
    for k in keys_possible:
        if k == "phi_norm":
            present.add(k)
            continue
        if k in npz0:
            present.add(k)

    # Per-agent single-field GIFs
    fields_out = os.path.join(outdir, "gifs")
    safe_mkdir(fields_out)
    for a in range(min(n_agents_preview, npz0.get("mu_q", np.zeros((0,))).shape[0] if "mu_q" in npz0 else n_agents_preview)):
        for fk in sorted(present):
            out_gif = os.path.join(fields_out, f"a{a}_{fk}.gif")
            animate_scalar_field(
                idx, out_gif, fk, agent_idx=a,
                mask_outline=True,
                percentile=(0,100),
                downsample_factor=ds_factor,
                title=fk,
            )

    # 2×2 panels for a quick dashboard
    panels = []
    # choose up to 4 fields prioritizing KL + curvature + phi_norm
    priority = [k for k in ["kl_self","kl_feedback","Fq_norm","phi_norm","belief_align","model_align","Fp_norm"] if k in present]
    if priority:
        panels.append(priority[:4])

    panels_out = os.path.join(outdir, "panels")
    safe_mkdir(panels_out)
    for a in range(min(n_agents_preview, npz0.get("mu_q", np.zeros((0,))).shape[0] if "mu_q" in npz0 else n_agents_preview)):
        for pset in panels:
            name = "_".join(pset)
            out_gif = os.path.join(panels_out, f"a{a}_{name}.gif")
            animate_multi_fields_panel(
                idx, out_gif, pset, agent_idx=a,
                percentile=(1,99),
                downsample_factor=ds_factor,
                titles=pset,
            )


import imageio.v2 as imageio
import numpy as np
import os

def save_gif_imageio(frames, path, fps=10):
    """
    frames: list of np.ndarray (H,W,3) uint8 images
    path  : output .gif path
    """
    os.makedirs(os.path.dirname(path), exist_ok=True)
    imageio.mimsave(path, frames, format="GIF", fps=fps, loop=0)  # loop=0 means infinite



if __name__ == "__main__":
    # Default: read from "checkpoints" and write to "reports"
    run_reports(
        checkpoints_dir="checkpoints",
        outdir="reports",
        n_agents_preview=2,
        do_timeseries=True,
        do_agent_histos=True,
        do_gifs=True,
        ds_factor=None,  # set to e.g. 2 for large grids
    )
