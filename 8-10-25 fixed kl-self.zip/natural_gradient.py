# -*- coding: utf-8 -*-
"""
Created on Wed Jul 23 09:23:50 2025

@author: chris and christine
"""
import numpy as np
import config
from joblib import Parallel, delayed
from numerical_utils import safe_inv
from get_generators import get_generators
from numerical_utils import sanitize_sigma
from omega import safe_bch_exact

def apply_natural_gradient_batch(mu_field, sigma_field, grad_mu_field, grad_sigma_field, mask=None):
    """
    Vectorized natural gradient for Gaussian fields:
      δμ = -Σ · ∇_μ L
      δΣ = -2 Σ · sym(∇_Σ L) · Σ

    Args:
        mu_field         : (H, W, K) mean field
        sigma_field      : (H, W, K, K) covariance field (SPD)
        grad_mu_field    : (H, W, K) Euclidean gradients ∇_μ L
        grad_sigma_field : (H, W, K, K) Euclidean gradients ∇_Σ L
        mask             : optional (H, W) bool or float weight mask

    Returns:
        delta_mu         : (H, W, K) natural gradient update for mean
        delta_sigma      : (H, W, K, K) natural gradient update for covariance
    """
    
    eps = getattr(config, "eps", 1e-8)
    clip_sigma = getattr(config, "gradient_clip_sigma", 1e5)
    clip_mu    = getattr(config, "gradient_clip_mu", None)

    H, W, K = mu_field.shape
    N = H * W

    # Flatten spatial dims
    mu_flat = mu_field.reshape(N, K)
    sigma_flat = sigma_field.reshape(N, K, K)
    grad_mu_flat = grad_mu_field.reshape(N, K)
    grad_sigma_flat = grad_sigma_field.reshape(N, K, K)

    # Sanitize sigma: symmetrize and clip eigenvalues per point, vectorized
    # Here you may use your sanitize_sigma function in batch or apply vectorized symmetrization
    sigma_flat = 0.5 * (sigma_flat + np.swapaxes(sigma_flat, -1, -2))
    # For eigenvalue clipping, you might still need a loop or use batch eigh if implemented

    # Symmetrize gradients
    grad_sigma_flat = 0.5 * (grad_sigma_flat + np.swapaxes(grad_sigma_flat, -1, -2))

    # Compute delta_mu = - Sigma @ grad_mu  (batch matmul)
    delta_mu = -np.einsum("nik,nk->ni", sigma_flat, grad_mu_flat)

    # Compute delta_sigma = -2 Sigma @ grad_sigma @ Sigma
    tmp = np.einsum("nij,njk->nik", sigma_flat, grad_sigma_flat)
    delta_sigma = -2.0 * np.einsum("nij,njk->nik", tmp, sigma_flat)

    # Ensure symmetry of delta_sigma
    delta_sigma = 0.5 * (delta_sigma + np.swapaxes(delta_sigma, -1, -2))

    # Apply mask
    if mask is None:
        active = np.ones(N, dtype=bool)
        weights = None
    else:
        m = np.asarray(mask).reshape(N)
        if m.dtype == bool:
            active = m
            weights = None
        else:
            active = m > getattr(config, "support_cutoff_eps", 0.0)
            weights = m.astype(mu_flat.dtype)

    # Clip norms per point (vectorized)
    if clip_sigma is not None:
        norms_sigma = np.linalg.norm(delta_sigma.reshape(N, -1), axis=1)
        clip_mask_sigma = (norms_sigma > clip_sigma) & active
        scale_sigma = np.ones(N, dtype=delta_sigma.dtype)
        scale_sigma[clip_mask_sigma] = clip_sigma / (norms_sigma[clip_mask_sigma] + 1e-16)
        delta_sigma = delta_sigma * scale_sigma[:, None, None]

    if clip_mu is not None:
        norms_mu = np.linalg.norm(delta_mu, axis=1)
        clip_mask_mu = (norms_mu > clip_mu) & active
        scale_mu = np.ones(N, dtype=delta_mu.dtype)
        scale_mu[clip_mask_mu] = clip_mu / (norms_mu[clip_mask_mu] + 1e-16)
        delta_mu = delta_mu * scale_mu[:, None]

    # Apply weights if provided
    if weights is not None:
        delta_mu *= weights[:, None]
        delta_sigma *= weights[:, None, None]

    # Zero out inactive points
    inactive = ~active
    delta_mu[inactive] = 0
    delta_sigma[inactive] = 0

    # Reshape back to (H, W, ...)
    delta_mu = delta_mu.reshape(H, W, K)
    delta_sigma = delta_sigma.reshape(H, W, K, K)

    # NaN/Inf protection
    delta_mu = np.nan_to_num(delta_mu)
    delta_sigma = np.nan_to_num(delta_sigma)

    return delta_mu, delta_sigma




def clip_gradient_field(grad_field, threshold=None, norm_type=2, verbose=False, label="∇φ"):
    """
    Optionally clips a gradient field to a maximum norm (global across all entries).

    Args:
        grad_field : (..., d) array of gradients
        threshold  : float or None — if None, no clipping is applied
        norm_type  : int or float — 1, 2, or np.inf
        verbose    : bool — print when clipping happens
        label      : str — name for diagnostics

    Returns:
        clipped gradient field of same shape
    """
    if threshold is None:
        return grad_field

    norm = np.linalg.norm(grad_field.ravel(), ord=norm_type)
    if norm > threshold:
        scale = threshold / (norm + 1e-12)
        if verbose:
            print(f"[Clipping {label}] norm {norm:.2e} → {threshold} (scale {scale:.2e})")
        return grad_field * scale
    return grad_field


def cache_fisher_inverse_morphisms(agent_i, eps=1e-8):
    agent_i.fisher_inv_phi_model = compute_inverse_fisher_field_natural(
        agent_i.Phi,
        agent_i.generators_q_to_p,
        eps=eps
    )
    agent_i.fisher_inv_phi = compute_inverse_fisher_field_natural(
        agent_i.Phi_tilde,
        agent_i.generators_p_to_q,
        eps=eps
    )

def compute_lie_metric(generators: np.ndarray):
    """
    Compute Lie algebra inner product G_ab = Tr(G_aᵀ G_b), and return its inverse.

    Args:
        generators: (d, K, K) array of generators Gₐ ∈ 𝔤

    Returns:
        G:     (d, d) symmetric inner product matrix
        G_inv: (d, d) inverse with clipping safeguard
    """
    from numerical_utils import safe_inv
    import numpy as np
    import config

    d = generators.shape[0]

    # G_ab = Tr(G_aᵀ G_b)
    G = np.einsum("aij,bij->ab", generators, generators)

    # Symmetrize in case of small numerical asymmetry
    G = 0.5 * (G + G.T)

    # Invert with safety checks (e.g. clip small eigenvalues)
    eps = getattr(config, "eps", 1e-6)
    G_inv = safe_inv(G, eps=eps)

    return G, G_inv






def compute_inverse_fisher_field_natural(agent, generators, field="phi"):
    """
    Computes per-point inverse Fisher metric G^{-1}_{ab}(x) in the Lie algebra.
    Skips computation in regions where agent.mask < support_cutoff_eps.

    Args:
        agent: agent object with sigma_q_field or sigma_p_field
        generators: (d, K, K) Lie algebra basis
        field: "phi" or "phi_model"

    Returns:
        G_inv_field: (H, W, d, d)
    """
    sigma_field = agent.sigma_q_field if field == "phi" else agent.sigma_p_field
    mask = agent.mask > getattr(config, "support_cutoff_eps", 1e-4)

    sigma_field = sanitize_sigma(sigma_field, eps=config.eps, debug=False)

    H, W, K, _ = sigma_field.shape
    d = generators.shape[0]
    eye_K = np.eye(K)
    eye_d = np.eye(d)

    G_inv_field = np.zeros((H, W, d, d), dtype=sigma_field.dtype)

    flat_sigma = sigma_field.reshape(-1, K, K)
    flat_mask = mask.reshape(-1)
    N = flat_sigma.shape[0]

    valid_indices = np.flatnonzero(flat_mask)
    sigma_valid = flat_sigma[valid_indices]  # (M, K, K)

    # Step 1: invert Σ⁻¹ (with fallback)
    sigma_inv = np.empty_like(sigma_valid)
    for i in range(sigma_valid.shape[0]):
        try:
            sigma_inv[i] = np.linalg.inv(sigma_valid[i])
        except np.linalg.LinAlgError:
            sigma_inv[i] = eye_K
            if config.debug:
                print(f"[WARN] Σ⁻¹ failed at valid index {i}")

    # Step 2: compute G_ab[i, a, b] = Tr[Σ⁻¹ G^a Σ⁻¹ G^b]
    G_ab = np.zeros((sigma_inv.shape[0], d, d), dtype=sigma_field.dtype)

    for a in range(d):
        for b in range(d):
            G_a = np.broadcast_to(generators[a], sigma_inv.shape)
            G_b = np.broadcast_to(generators[b], sigma_inv.shape)


            G_ab[..., a, b] = np.einsum("...ij,...jk,...kl,...il->...", sigma_inv, G_a, sigma_inv, G_b)



    # Step 3: symmetrize and invert G_ab
    flat_G_inv = G_inv_field.reshape(-1, d, d)
    for i, flat_idx in enumerate(valid_indices):
        G_sym = 0.5 * (G_ab[i] + G_ab[i].T)
        try:
            cond = np.linalg.cond(G_sym)
            if not np.isfinite(cond) or cond > config.max_fisher_condition:
                raise np.linalg.LinAlgError
            flat_G_inv[flat_idx] = np.linalg.inv(G_sym + config.eps * eye_d)
        except np.linalg.LinAlgError:
            flat_G_inv[flat_idx] = eye_d
            if config.debug:
                print(f"[WARN] G_ab⁻¹ fallback at index {flat_idx}")

    return G_inv_field









def dexpinv_operator(phi, delta, generators, order=3, threshold=0.25):
    """
    Vectorized inverse exponential pushforward (dexp⁻¹) on a Lie algebra grid.

    Given:
        φ     : (..., d) Lie algebra coordinates φ^a G_a
        δ     : (..., d) tangent perturbations δ^a G_a
        generators : (d, K, K) Lie algebra basis matrices
        order      : truncation order for BCH/commutator expansion (if using series)
        threshold  : norm cutoff for switching between series and exact

    Returns:
        corrected_delta : (..., d) array after applying dexpinv_φ to δ
    """
    # Shapes
    *grid_shape, d = phi.shape
    K = generators.shape[-1]

    # Metric coefficients for projection
    gen_norms = np.array([np.trace(G @ G) for G in generators], dtype=phi.dtype)

    # Matrix forms
    phi_mat   = np.einsum("...a,akl->...kl", phi,   generators)
    delta_mat = np.einsum("...a,akl->...kl", delta, generators)

    # Norm proxy: Frobenius norm of [φ, δ]
    ad1 = phi_mat @ delta_mat - delta_mat @ phi_mat
    ad_norm = np.linalg.norm(ad1, axis=(-2, -1))

    # ── Small φ: use commutator expansion ─────────────────────────────
    small_mask = ad_norm <= threshold
    if np.any(small_mask):
        out_small = delta_mat.copy()
        if order >= 1:
            out_small -= 0.5 * ad1
        if order >= 2:
            ad2 = phi_mat @ ad1 - ad1 @ phi_mat
            out_small += (1.0 / 12.0) * ad2
        if order >= 3:
            ad3 = phi_mat @ ad2 - ad2 @ phi_mat
            out_small -= (1.0 / 24.0) * ad3
    else:
        out_small = None

        # ── Large φ: use your safe BCH/logm wrapper ─────────────────────────
    large_mask = ~small_mask
    if np.any(large_mask):
        
        phi_large   = phi_mat[large_mask]
        delta_large = delta_mat[large_mask]
        composed = []
        for A, B in zip(phi_large, delta_large):
            # safe_bch_exact should already handle clipping & NaN guards
            C = safe_bch_exact(A, B)
            composed.append(C - A)
        out_large = np.stack(composed, axis=0)
    else:
        out_large = None


    # ── Combine back into full matrix field ───────────────────────────
    out_mat = np.zeros_like(phi_mat)
    if out_small is not None:
        out_mat[small_mask] = out_small[small_mask]
    if out_large is not None:
        out_mat[large_mask] = out_large

    # ── Project back to coefficients: δ^a = Tr(M·G_a) / Tr(G_a G_a) ───
    corrected = np.empty_like(phi)
    for a in range(d):
        G = generators[a]
        corrected[..., a] = np.einsum("...ij,ij->...", out_mat, G) / gen_norms[a]

    return corrected

def dexpinv_operatorOLD(phi, delta, generators, order=None, use_exact=None):
    """
    Applies the inverse of the exponential pushforward (dexp⁻¹) to a variation δ in Lie algebra coordinates.

    Specifically, given:
        φ ∈ 𝔤 — current Lie algebra coordinate
        δ ∈ 𝔤 — a variation in Lie algebra coordinates

    The function computes the corrected update:
        dexpinv(φ, δ) ∈ 𝔤

    using the relation:
        dexpinv(φ, δ) ≈ log(exp(φ) · exp(δ)) − φ   (in 𝔤)
    and then projecting back onto the Lie algebra basis.

    This accounts for the nonlinearity of the exponential map on matrix Lie groups
    and ensures that updates in the Lie algebra are consistent with the group manifold.

    Args:
        phi        : (..., d) tensor of Lie algebra elements φ^a G_a
        delta      : (..., d) tensor of tangent perturbations δ^a G_a
        generators : (d, K, K) basis of the Lie algebra 𝔤 ⊂ ℝ^{K×K}
        order      : (unused) placeholder for future use (e.g., BCH truncation order)
        use_exact  : (unused) placeholder for forcing exact logm even if fast

    Returns:
        corrected_delta : (..., d) result of dexpinv applied to delta, projected onto 𝔤
    """
    
    H, W, d = phi.shape
    corrected = np.zeros_like(delta)

    # Matrix form: φ, Δ ∈ 𝔤
    phi_mat   = np.einsum("...a,akl->...kl", phi, generators)
    delta_mat = np.einsum("...a,akl->...kl", delta, generators)

    composed = np.zeros_like(phi_mat)
    for i in range(H):
        for j in range(W):
            A = phi_mat[i, j]
            B = delta_mat[i, j]
            C = safe_bch_exact(A, B)  # full BCH or logm
            composed[i, j] = C - A

    # Project back: δ_corrected^a = Tr[(C - A) · G^a]
    for a in range(d):
        G = generators[a]
        corrected[..., a] = 2.0 * np.einsum("...ij,ij->...", composed, G)

    return corrected



def compute_fisher_geometry_gradient(agent_i, agents, params, field="phi"):
    """
    Compute ∇_{φ} or ∇_{φ̃} for Fisher geometry preservation:
        ∇‖Gᵢ − Ωᵢⱼ Gⱼ Ωᵢⱼᵀ‖²
    where G = Σ⁻¹ = -2 η₂.
    Supports field="phi" (beliefs) or "phi_model" (models).
    """
    if field == "phi":
        phi = agent_i.phi
        eta2_q = agent_i.eta2_q_field
        exp_phi = agent_i._exp_phi
        exp_neg_phi_j_name = "_exp_neg_phi"
        eta2_field_name = "eta2_q_field"
        fisher_weight = params.get("fisher_geometry_weight", config.fisher_geometry_weight)
    else:
        phi = agent_i.phi_model
        eta2_q = agent_i.eta2_p_field
        exp_phi = agent_i._exp_phi_model
        exp_neg_phi_j_name = "_exp_neg_phi_model"
        eta2_field_name = "eta2_p_field"
        fisher_weight = params.get("fisher_model_geometry_weight", config.fisher_model_geometry_weight)

    if fisher_weight <= 0:
        return np.zeros_like(phi)

    Gs = get_generators(config.group_name, config.K)
    d, K = Gs.shape[0], Gs.shape[1]
    mask_i = agent_i.mask > config.support_cutoff_eps
    if not np.any(mask_i):
        return np.zeros_like(phi)

    grad = np.zeros_like(phi)
    flat_self_mask = mask_i.reshape(-1)
    exp_phi_i = exp_phi.reshape(-1, K, K)
    G_i = (-2.0 * eta2_q).reshape(-1, K, K)

    for nb in agent_i.neighbors:
        agent_j = agents[nb["id"]]
        mask_j = agent_j.mask > config.support_cutoff_eps
        overlap = mask_i & mask_j
        if not np.any(overlap):
            continue

        flat_idxs = overlap.reshape(-1)
        if flat_idxs.size == 0:
            continue

        # G_j = -2 * η2_qj
        eta2_q_j = getattr(agent_j, eta2_field_name).reshape(-1, K, K)[flat_idxs]
        G_j = -2.0 * eta2_q_j
        exp_neg_phi_j = getattr(agent_j, exp_neg_phi_j_name).reshape(-1, K, K)[flat_idxs]

        Omega = np.einsum("mij,mjk->mik", exp_phi_i[flat_idxs], exp_neg_phi_j)  # (M, K, K)
        Omega_T = np.transpose(Omega, axes=(0, 2, 1))                           # (M, K, K)

        # Ω G_j Ωᵀ
        G_j_rot = np.einsum("mik,mkl,mlj->mij", Omega, G_j, Omega_T)           # (M, K, K)
        Delta = G_i[flat_idxs] - G_j_rot                                       # (M, K, K)

        for a in range(d):
            Ga = Gs[a]   

            #refactor to exact                                                     # (K, K)
            dOmega = np.einsum("ij,mjk->mik", Ga, Omega)                      # (M, K, K)
            dOmega_T = np.transpose(dOmega, axes=(0, 2, 1))                   # (M, K, K)

            # ∂G_rot = dΩ G Ωᵀ + Ω G dΩᵀ
            term1 = np.einsum("mik,mkl,mlj->mij", dOmega, G_j, Omega_T)
            term2 = np.einsum("mik,mkl,mlj->mij", Omega, G_j, dOmega_T)
            dG_rot = term1 + term2                                            # (M, K, K)

            dL = 2 * np.einsum("mij,mij->m", Delta, dG_rot)                   # (M,)
            grad.reshape(-1, d)[flat_idxs, a] += dL                           # update projected gradient

    grad *= fisher_weight
    grad[~mask_i] = 0.0
    return grad


