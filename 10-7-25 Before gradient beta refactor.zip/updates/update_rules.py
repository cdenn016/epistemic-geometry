# -*- coding: utf-8 -*-
"""
Created on Wed Jul 23 10:32:58 2025

@author: chris and christine
"""

import time
from runtime_context import ensure_runtime_defaults, CacheHub, build_step_settings, cfg_get
from updates.update_compute_all_gradients import _apply_children, _compute_child_grads
from updates.update_helpers import dirty_manager,  refresh_agents, ensure_dirty
from updates.update_terms_curvature_A import step_global_A
from core.transport_cache import warm_E, warm_Jinv
from beta import compute_edge_betas


class PhaseTimer:
    """Context-manager timer that aggregates per-phase wall time on runtime_ctx."""
    def __init__(self, ctx):
        self.ctx = ctx
        if not hasattr(ctx, "timings") or getattr(ctx, "timings") is None:
            ctx.timings = {}

    def __call__(self, name: str):
        ctx = self.ctx
        class _T:
            def __enter__(_s):
                _s.t0 = time.perf_counter()
                return _s
            def __exit__(_s, *_):
                dt = time.perf_counter() - _s.t0
                ctx.timings[name] = ctx.timings.get(name, 0.0) + dt
        return _T()


# --- synchronous step (simplified, timed) ------------------------------------
def synchronous_step(agents, generators_q, generators_p, n_jobs=1, runtime_ctx=None):
    """
    Single-scale (children-only) synchronous update step.
    Evolves child agents, enforces caches, warms pairwise transport (KL refresh),
    and registers children. No parents/detection/spawn/xscale.
    """
    assert runtime_ctx is not None, "synchronous_step: pass runtime_ctx"
    assert agents and (len(agents) > 0), "synchronous_step: no agents"
    import core.config as config
    # ---- ctx defaults / cache ----
    runtime_ctx = ensure_runtime_defaults(runtime_ctx)

    if not getattr(runtime_ctx, "step_cfg", None):
        runtime_ctx.step_cfg = build_step_settings(config)

    if not hasattr(runtime_ctx, "cache") or runtime_ctx.cache is None:
        runtime_ctx.cache = CacheHub()

    step_now = int(getattr(runtime_ctx, "global_step", 0))
    runtime_ctx.cache.clear_on_step(step_now)

    # ---- unified dirty manager ----
    DM = dirty_manager(runtime_ctx)

    T = PhaseTimer(runtime_ctx)
    # ---------------- Phase 0: pre ---------------- 
    with T("pre"):
        if not agents:
            runtime_ctx.register_agents(0, [])
            runtime_ctx.global_step += 1
            return agents
    
        children = agents
        refresh_agents(children, generators_q, generators_p, ctx=runtime_ctx)
    
        warm_E(runtime_ctx, children, ("q","p"))
        warm_Jinv(runtime_ctx, children, ("q","p"))
       
        compute_edge_betas(runtime_ctx, children)   # writes _edge_beta_q, _edge_beta_p
           
    # ---------------- Phase 1: child grads/apply ---
    with T("child_grad"):
        out = _compute_child_grads(runtime_ctx, children, children, generators_q, generators_p)
        
        if len(out) == 5:
            q_updates, p_updates, phi_grads, phi_m_grads, dtheta_parts = out
        else:
            q_updates, p_updates, phi_grads, phi_m_grads = out
            dtheta_parts = [None] * len(children)

    with T("child_apply"):
        _apply_children(children, (q_updates, p_updates, phi_grads, phi_m_grads),
                        n_jobs, ctx=runtime_ctx)

        #apply_global_phi_gauge_fix(children, mask_weighted=True, max_iters=15, tol=1e-7)
        # Mark children dirty for pairwise/KL refresh in the ensure phase
        DM.mark(*children, kl=True)

    # ---------------- Phase 2: ensure/caches -------
    with T("ensure_dirty"):
        ensure_dirty(runtime_ctx, generators_q, generators_p, scope="children")

    # ---------------- Phase 3: optional global A update -------
    with T("A_update"):
        _ = step_global_A(runtime_ctx, children)   # ctx-only

    # ---------------- Phase 4: register/step -------
    with T("register"):
        runtime_ctx.register_agents(0, children)
        runtime_ctx.children_latest = children
        runtime_ctx.global_step    += 1

    # ---------------- Phase 5: timing --------------
    dbg = bool(cfg_get(runtime_ctx, "debug_phase_timing", True))
    if dbg:
        print("[timings]")
        for name, dt in sorted(getattr(runtime_ctx, "timings", {}).items()):
            print(f"  {name:20s} {dt:8.3f}s")
        if getattr(runtime_ctx, "counters", None):
            print("[counts]", runtime_ctx.counters)

    return agents




def apply_global_phi_gauge_fix(
    agents,
    *,
    include_model_in_mean: bool = True,
    mask_weighted: bool = True,
    zero_outside_mask: bool = True,
    max_iters: int = 15,
    tol: float = 1e-7,
):
    """
    Compute Karcher mean rotation R_bar from masked pixels of BOTH phi and (optionally) phi_model,
    then left-multiply all frames by R_bar^{-1}. Finally (optionally) set both to zero outside mask.

    This treats phi and phi_model symmetrically:
      - If include_model_in_mean=True, the mean uses {phi} ∪ {phi_model where present} with the same mask.
      - The same R_bar^{-1} is applied to both.
      - Both are re-zeroed outside mask if requested.

    Invariants inside support are preserved; hard zeros outside support are preserved when zero_outside_mask=True.
    """
    import numpy as np

    # --- so(3) helpers ---
    def _hat(v):
        x, y, z = float(v[0]), float(v[1]), float(v[2])
        return np.array([[0, -z,  y],
                         [z,  0, -x],
                         [-y, x,  0]], dtype=np.float64)

    def _so3_exp(v):
        t = float(np.linalg.norm(v))
        if t < 1e-12:
            K = _hat(v)
            return np.eye(3, dtype=np.float64) + K + 0.5 * (K @ K)
        K = _hat(v); s, c = np.sin(t), np.cos(t)
        return np.eye(3) + (s / t) * K + ((1.0 - c) / (t * t)) * (K @ K)

    def _so3_log(R):
        tr = float(np.clip(np.trace(R), -1.0, 3.0))
        ct = 0.5 * (tr - 1.0)
        ct = np.clip(ct, -1.0, 1.0)
        t = float(np.arccos(ct))
        if t < 1e-12:
            # small-angle: use antisymmetric part
            return np.array([R[2, 1] - R[1, 2],
                             R[0, 2] - R[2, 0],
                             R[1, 0] - R[0, 1]], dtype=np.float64) * 0.5
        v = np.array([R[2, 1] - R[1, 2],
                      R[0, 2] - R[2, 0],
                      R[1, 0] - R[0, 1]], dtype=np.float64)
        return (t / (2.0 * np.sin(t))) * v

    # --- collect rotations and weights from masked pixels of phi (+ phi_model if enabled) ---
    Rs, ws = [], []
    for a in agents:
        # common shape and mask
        phi = np.asarray(getattr(a, "phi"), np.float64)  # (*S,3)
        shp = phi.shape[:-1]
        if mask_weighted:
            m = getattr(a, "mask", None)
            if m is not None:
                m = np.asarray(m, np.float64)
                if m.shape != shp:
                    pad = (1,) * max(0, len(shp) - m.ndim)
                    m = np.broadcast_to(m.reshape(pad + m.shape), shp)
                w_base = m.reshape(-1)  # (N,)
            else:
                w_base = np.ones(np.prod(shp, dtype=int), np.float64)
        else:
            w_base = np.ones(np.prod(shp, dtype=int), np.float64)

        # helper to add a field to the mean
        def _add_field(field_arr, w_arr):
            f = np.asarray(field_arr, np.float64).reshape(-1, 3)
            for v, ww in zip(f, w_arr):
                if ww <= 0.0:
                    continue
                Rs.append(_so3_exp(v))
                ws.append(float(ww))

        # always include phi
        _add_field(phi, w_base)

        # optionally also include phi_model (if present)
        if include_model_in_mean and getattr(a, "phi_model", None) is not None:
            _add_field(getattr(a, "phi_model"), w_base)

    if not Rs:
        return  # nothing active to define a mean

    # --- Karcher mean (left-invariant) ---
    Rbar = np.eye(3, dtype=np.float64)
    wsum = float(np.sum(ws))
    for _ in range(max_iters):
        mu = np.zeros(3, np.float64)
        for R, w in zip(Rs, ws):
            mu += w * _so3_log(Rbar.T @ R)
        mu /= max(wsum, 1e-12)
        if float(np.linalg.norm(mu)) < tol:
            break
        Rbar = Rbar @ _so3_exp(mu)
    
    
    if np.linalg.norm(mu) < 1e-6:   # radians; tune
        return  # nothing to do this step

    Rbar_inv = Rbar.T  # orthogonal inverse

    # --- apply to phi and phi_model, then zero outside mask if requested ---
    def _apply_log_left(R_left_inv, phi_field):
        x = np.asarray(phi_field, np.float64).reshape(-1, 3)
        out = np.zeros_like(x)
        for i, v in enumerate(x):
            R = _so3_exp(v)
            out[i] = _so3_log(R_left_inv @ R)
        return out.reshape(phi_field.shape).astype(np.float32)

    for a in agents:
        a.phi = _apply_log_left(Rbar_inv, getattr(a, "phi"))
        if getattr(a, "phi_model", None) is not None:
            a.phi_model = _apply_log_left(Rbar_inv, getattr(a, "phi_model"))

        if zero_outside_mask:
            m = getattr(a, "mask", None)
            if m is not None:
                m = np.asarray(m, np.float32)
                shp = a.phi.shape[:-1]
                if m.shape != shp:
                    pad = (1,) * max(0, len(shp) - m.ndim)
                    m = np.broadcast_to(m.reshape(pad + m.shape), shp)
                m3 = m[..., None]  # (*S,1)
                a.phi = (a.phi * m3).astype(np.float32)
                if getattr(a, "phi_model", None) is not None:
                    a.phi_model = (a.phi_model * m3).astype(np.float32)







