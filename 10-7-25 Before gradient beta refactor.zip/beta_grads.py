"""
Created on Sat Sep 27 15:19:10 2025

@author: chris and christine

Case A:  KL( Φ_i[Ω^q_ij q_j] || p_i )
Case B:  KL( p_i || Φ_i Ω^q_ij[q_j] )

Case C: KL( Φ̃_i p_i  ||  Ω^q_ij q_j )
Case D: KL( Ω^q_ij * q_j || Φ̃_i * p_i )

Default Q:  KL( q_i || Ω^q_ij q_j )
Default P:  KL( p_i || Ω^p_ij p_j ) 

"""

import numpy as np
from core.numerical_utils import safe_inv, sanitize_sigma

# ---------- matrix → φ projector (adjoint rep, K=3) ----------
def project_matrix_cograd_to_phi(E, G_E, Jinv_right, F_inv):
    """
    E, G_E:   (*S,3,3)   site rotation and its matrix co-gradient (same rep)
    Jinv_right, F_inv:   (*S,3,3) right-Jacobian inverse and Fisher^{-1} in body coords
    Returns:  (*S,3)     param-space natural step for φ
    """
    Rt = np.swapaxes
    EtG  = np.einsum("...ij,...jk->...ik", Rt(E,-1,-2), G_E, optimize=True)
    skew = 0.5 * (EtG - Rt(EtG,-1,-2))
    g_left  = np.stack([skew[...,2,1], skew[...,0,2], skew[...,1,0]], axis=-1)
    # left→right (Ad_E^{-T} = E for SO(3))
    g_right = np.einsum("...ij,...j->...i", E, g_left, optimize=True)
    v_body  = np.einsum("...ij,...j->...i", F_inv, g_right, optimize=True)
    v_param = np.einsum("...ij,...j->...i", Jinv_right, v_body, optimize=True)
    return v_param.astype(np.float32, copy=False)


# ---------- Case A grads wrt q_j stats ----------
def grad_caseA_source_qj(
    mu_p, sigma_p,  # RHS model p_i
    mu_j, sigma_j,  # source q_j
    R, *, eps=1e-8, sigma_p_inv=None, assume_sanitized=True
):
    """
    KL( Φ_i[Ω^q_ij q_j] || p_i ) in p-frame.
    Returns ∂KL/∂μ_j, ∂KL/∂Σ_j  (mapped back through R).
    """
    mu_p    = np.asarray(mu_p,    np.float32, order="C")
    sigma_p = np.asarray(sigma_p, np.float32, order="C")
    mu_j    = np.asarray(mu_j,    np.float32, order="C")
    sigma_j = np.asarray(sigma_j, np.float32, order="C")
    R       = np.asarray(R,       np.float32, order="C")
    Rt      = np.swapaxes(R, -1, -2)

    mu_L = np.einsum("...ij,...j->...i", R, mu_j, optimize=True)
    S_L  = np.einsum("...ik,...kl,...lj->...ij", R, sigma_j, Rt, optimize=True)  # R Σ_j R^T
    if sigma_p_inv is None:
        sigma_p_inv = safe_inv(sigma_p if assume_sanitized else sanitize_sigma(sigma_p, eps=eps))
    S_L_inv = safe_inv(S_L if assume_sanitized else sanitize_sigma(S_L, eps=eps))

    delta   = (mu_L - mu_p).astype(np.float32, copy=False)
    dKL_dmL = np.einsum("...ij,...j->...i", sigma_p_inv, delta, optimize=True)
    dKL_dSL = 0.5 * (sigma_p_inv - S_L_inv)
    dKL_dSL = 0.5 * (dKL_dSL + np.swapaxes(dKL_dSL, -1, -2))

    grad_mu_j = np.einsum("...ji,...j->...i", R, dKL_dmL, optimize=True)                 # R^T dμ_L
    grad_S_j  = np.einsum("...ji,...jk,...kl->...il", R, dKL_dSL, Rt, optimize=True)     # R^T dΣ_L R
    grad_S_j  = 0.5 * (grad_S_j + np.swapaxes(grad_S_j, -1, -2))
    return grad_mu_j.astype(np.float32, copy=False), grad_S_j.astype(np.float32, copy=False)

# ---------- Case A grads wrt p_i stats ----------
def grad_caseA_model_pi(
    mu_p, sigma_p,
    mu_j, sigma_j,
    R, *, eps=1e-8, sigma_p_inv=None, assume_sanitized=True
):
    """
    KL( Φ_i[Ω^q_ij q_j] || p_i ) in p-frame.
    Returns ∂KL/∂μ_p, ∂KL/∂Σ_p.
    """
    mu_p    = np.asarray(mu_p,    np.float32, order="C")
    sigma_p = np.asarray(sigma_p, np.float32, order="C")
    mu_j    = np.asarray(mu_j,    np.float32, order="C")
    sigma_j = np.asarray(sigma_j, np.float32, order="C")
    R       = np.asarray(R,       np.float32, order="C")
    Rt      = np.swapaxes(R, -1, -2)

    mu_L = np.einsum("...ij,...j->...i", R, mu_j, optimize=True)
    S_L  = np.einsum("...ik,...kl,...lj->...ij", R, sigma_j, Rt, optimize=True)  # R Σ_j R^T
    if sigma_p_inv is None:
        sigma_p_inv = safe_inv(sigma_p if assume_sanitized else sanitize_sigma(sigma_p, eps=eps))

    delta     = (mu_p - mu_L).astype(np.float32, copy=False)
    grad_mu_p = np.einsum("...ij,...j->...i", sigma_p_inv, delta, optimize=True)

    Spt   = np.swapaxes(sigma_p_inv, -1, -2)  # S_p^{-T}
    outer = np.einsum("...i,...j->...ij", delta, delta, optimize=True)
    term1 = Spt
    term2 = np.einsum("...ik,...kl,...lj->...ij", Spt, S_L, Spt, optimize=True)
    term3 = np.einsum("...ik,...kl,...lj->...ij", Spt, outer, Spt, optimize=True)
    grad_S_p = 0.5 * (term1 - term2 - term3)
    grad_S_p = 0.5 * (grad_S_p + np.swapaxes(grad_S_p, -1, -2))
    return grad_mu_p.astype(np.float32, copy=False), grad_S_p.astype(np.float32, copy=False)

# ---------- Case A co-gradient wrt R = Φ Ω ----------
def cograd_caseA_composite_R(
    mu_p, sigma_p, mu_j, sigma_j, R, *, eps=1e-8, sigma_p_inv=None, assume_sanitized=True
):
    """
    Returns G_R = ∂ KL( Φ_i[Ω^q_ij q_j] || p_i ) / ∂R, shape (*S,3,3).
    """
    mu_p    = np.asarray(mu_p,    np.float32, order="C")
    sigma_p = np.asarray(sigma_p, np.float32, order="C")
    mu_j    = np.asarray(mu_j,    np.float32, order="C")
    sigma_j = np.asarray(sigma_j, np.float32, order="C")
    R       = np.asarray(R,       np.float32, order="C")
    Rt      = np.swapaxes(R, -1, -2)

    mu_L = np.einsum("...ij,...j->...i", R, mu_j, optimize=True)
    S_L  = np.einsum("...ik,...kl,...lj->...ij", R, sigma_j, Rt, optimize=True)  # R Σ_j R^T
    if sigma_p_inv is None:
        sigma_p_inv = safe_inv(sigma_p if assume_sanitized else sanitize_sigma(sigma_p, eps=eps))
    S_L_inv = safe_inv(S_L if assume_sanitized else sanitize_sigma(S_L, eps=eps))

    delta   = (mu_L - mu_p).astype(np.float32, copy=False)
    dKL_dmL = np.einsum("...ij,...j->...i", sigma_p_inv, delta, optimize=True)
    dKL_dSL = 0.5 * (sigma_p_inv - S_L_inv)
    dKL_dSL = 0.5 * (dKL_dSL + np.swapaxes(dKL_dSL, -1, -2))

    term1 = np.einsum("...i,...j->...ij", dKL_dmL, mu_j, optimize=True)
    term2 = 2.0 * np.einsum("...ij,...jk,...kl->...il", dKL_dSL, R, sigma_j, optimize=True)
    G_R   = term1 + term2
    return G_R.astype(np.float32, copy=False)


# ---------- Split G_R to site-frame co-grads and project to φ ----------
def split_caseA_G_R_to_Es(G_R, Eqi, Eqj, Epi):
    """
    G_R : (*S,3,3), Eqi, Eqj, Epi : (*S,3,3)
    Returns: G_Eqi, G_Eqj, G_Epi (each *S,3,3)
    """
    Rt = np.swapaxes
    Phi   = np.einsum("...ik,...jk->...ij", Epi, Rt(Eqi,-1,-2), optimize=True)  # Epi Eqi^T
    Omega = np.einsum("...ik,...jk->...ij", Eqi, Rt(Eqj,-1,-2), optimize=True)  # Eqi Eqj^T

    G_Phi = np.einsum("...ij,...kj->...ik", G_R, Omega, optimize=True)  # G_R Ω^T
    G_Omg = np.einsum("...ij,...ik->...kj", Phi,  G_R,   optimize=True) # Φ^T G_R

    G_Epi     = np.einsum("...ij,...jk->...ik", G_Phi, Eqi, optimize=True)
    G_Eqi_phi = np.einsum("...ij,...jk->...ik", Rt(Epi,-1,-2), G_Phi, optimize=True)
    G_Eqi_omg = np.einsum("...ij,...jk->...ik", G_Omg, Eqj, optimize=True)
    G_Eqj     = np.einsum("...ij,...jk->...ik", Rt(Eqi,-1,-2), G_Omg, optimize=True)
    G_Eqi     = G_Eqi_phi + G_Eqi_omg
    return G_Eqi.astype(np.float32), G_Eqj.astype(np.float32), G_Epi.astype(np.float32)

def phi_grads_from_caseA_G_R(
    G_R, Eqi, Eqj, Epi,
    Jinv_q_i, Finv_q_i,
    Jinv_q_j, Finv_q_j,
    Jinv_p_i, Finv_p_i
):
    """
    Returns param-space grads for: φ_i (q), φ_j (q), φ_i (p).
    """
    G_Eqi, G_Eqj, G_Epi = split_caseA_G_R_to_Es(G_R, Eqi, Eqj, Epi)
    g_phi_i_q = project_matrix_cograd_to_phi(Eqi, G_Eqi, Jinv_q_i, Finv_q_i)
    g_phi_j_q = project_matrix_cograd_to_phi(Eqj, G_Eqj, Jinv_q_j, Finv_q_j)
    g_phi_i_p = project_matrix_cograd_to_phi(Epi, G_Epi, Jinv_p_i, Finv_p_i)
    return g_phi_i_q, g_phi_j_q, g_phi_i_p



#$======================================================================'
#                            case B
#
#========================================================================


# ---------- Case B grads wrt q_j stats ----------
def grad_caseB_source_qj(
    mu_p, sigma_p,     # fixed "left" dist P = N(mu_p, Σ_p)
    mu_j, sigma_j,     # source stats for pushed "right" dist Q = R[q_j]
    R, *, eps=1e-8, assume_sanitized=True
):
    """
    Case B: KL( p_i || R[q_j] ), p-frame.
    Returns ∂KL/∂μ_j, ∂KL/∂Σ_j mapped back through R.
    """
    mu_p    = np.asarray(mu_p,    np.float32, order="C")
    sigma_p = np.asarray(sigma_p, np.float32, order="C")
    mu_j    = np.asarray(mu_j,    np.float32, order="C")
    sigma_j = np.asarray(sigma_j, np.float32, order="C")
    R       = np.asarray(R,       np.float32, order="C")
    Rt      = np.swapaxes(R, -1, -2)

    # Push q_j
    mu_L = np.einsum("...ij,...j->...i", R,  mu_j, optimize=True)
    S_L  = np.einsum("...ik,...kl,...lj->...ij", R, sigma_j, Rt, optimize=True)
    S_L  = 0.5 * (S_L + np.swapaxes(S_L, -1, -2))

    # Inverses
    S_L_inv  = safe_inv(S_L if assume_sanitized else sanitize_sigma(S_L, eps=eps))

    # KL(P||Q): Δ = μ_p - μ_L
    delta    = (mu_p - mu_L).astype(np.float32, copy=False)
    # ∂KL/∂μ_L = S_L^{-1}(μ_L - μ_p) = - S_L^{-1} Δ
    dKL_dmL  = -np.einsum("...ij,...j->...i", S_L_inv, delta, optimize=True)
    # ∂KL/∂Σ_L = 1/2 ( S_L^{-1} - S_L^{-1} Σ_p S_L^{-1} - S_L^{-1} ΔΔ^T S_L^{-1} )
    outer    = np.einsum("...i,...j->...ij", delta, delta, optimize=True)
    SLSL     = np.einsum("...ik,...kl->...il", S_L_inv, sigma_p, optimize=True)
    term2    = np.einsum("...ik,...kl->...il", SLSL,    S_L_inv, optimize=True)  # S_L^{-1} Σ_p S_L^{-1}
    t3a      = np.einsum("...ik,...kj->...ij", S_L_inv, outer,   optimize=True)
    term3    = np.einsum("...ik,...kj->...ij", t3a,     S_L_inv, optimize=True)  # S_L^{-1} ΔΔ^T S_L^{-1}
    dKL_dSL  = 0.5 * (S_L_inv - term2 - term3)
    dKL_dSL  = 0.5 * (dKL_dSL + np.swapaxes(dKL_dSL, -1, -2))

    # Chain rule back to (μ_j, Σ_j)
    grad_mu_j = np.einsum("...ji,...j->...i", R,  dKL_dmL, optimize=True)                  # R^T dμ_L
    grad_S_j  = np.einsum("...ji,...jk,...kl->...il", R, dKL_dSL, Rt, optimize=True)       # R^T dΣ_L R
    grad_S_j  = 0.5 * (grad_S_j + np.swapaxes(grad_S_j, -1, -2))
    return grad_mu_j.astype(np.float32, copy=False), grad_S_j.astype(np.float32, copy=False)

# ---------- Case B grads wrt p_i stats ----------
def grad_caseB_model_pi(
    mu_p, sigma_p,     # P on the left
    mu_j, sigma_j,     # q_j that gets pushed by R
    R, *, eps=1e-8, sigma_p_inv=None, assume_sanitized=True
):
    """
    Case B: KL( p_i || R[q_j] ), p-frame.
    Returns ∂KL/∂μ_p, ∂KL/∂Σ_p.
    """
    mu_p    = np.asarray(mu_p,    np.float32, order="C")
    sigma_p = np.asarray(sigma_p, np.float32, order="C")
    mu_j    = np.asarray(mu_j,    np.float32, order="C")
    sigma_j = np.asarray(sigma_j, np.float32, order="C")
    R       = np.asarray(R,       np.float32, order="C")
    Rt      = np.swapaxes(R, -1, -2)

    mu_L = np.einsum("...ij,...j->...i", R,  mu_j, optimize=True)
    S_L  = np.einsum("...ik,...kl,...lj->...ij", R, sigma_j, Rt, optimize=True)
    S_L  = 0.5 * (S_L + np.swapaxes(S_L, -1, -2))

    S_L_inv = safe_inv(S_L if assume_sanitized else sanitize_sigma(S_L, eps=eps))
    if sigma_p_inv is None:
        sigma_p_inv = safe_inv(sigma_p if assume_sanitized else sanitize_sigma(sigma_p, eps=eps))

    delta     = (mu_p - mu_L).astype(np.float32, copy=False)
    # ∂KL/∂μ_p = Σ_p^{-1} (μ_p - μ_L)
    grad_mu_p = np.einsum("...ij,...j->...i", sigma_p_inv, delta, optimize=True)
    # ∂KL/∂Σ_p = 1/2 ( S_L^{-1} - Σ_p^{-1} )
    grad_S_p  = 0.5 * (S_L_inv - sigma_p_inv)
    grad_S_p  = 0.5 * (grad_S_p + np.swapaxes(grad_S_p, -1, -2))
    return grad_mu_p.astype(np.float32, copy=False), grad_S_p.astype(np.float32, copy=False)

# ---------- Case B co-gradient wrt R = Φ Ω ----------
def cograd_caseB_composite_R(
    mu_p, sigma_p, mu_j, sigma_j, R, *, eps=1e-8, assume_sanitized=True
):
    """
    Returns G_R = ∂ KL( p_i || R[q_j] ) / ∂R, shape (*S,3,3).
    """
    mu_p    = np.asarray(mu_p,    np.float32, order="C")
    sigma_p = np.asarray(sigma_p, np.float32, order="C")
    mu_j    = np.asarray(mu_j,    np.float32, order="C")
    sigma_j = np.asarray(sigma_j, np.float32, order="C")
    R       = np.asarray(R,       np.float32, order="C")
    Rt      = np.swapaxes(R, -1, -2)

    mu_L = np.einsum("...ij,...j->...i", R,  mu_j, optimize=True)
    S_L  = np.einsum("...ik,...kl,...lj->...ij", R, sigma_j, Rt, optimize=True)
    S_L  = 0.5 * (S_L + np.swapaxes(S_L, -1, -2))
    S_L_inv = safe_inv(S_L if assume_sanitized else sanitize_sigma(S_L, eps=eps))

    delta   = (mu_p - mu_L).astype(np.float32, copy=False)
    # dμ_L, dΣ_L as for KL(P||Q)
    dKL_dmL = -np.einsum("...ij,...j->...i", S_L_inv, delta, optimize=True)  # -S_L^{-1} Δ
    outer   = np.einsum("...i,...j->...ij", delta, delta, optimize=True)
    SLSL    = np.einsum("...ik,...kl->...il", S_L_inv, sigma_p, optimize=True)
    term2   = np.einsum("...ik,...kl->...il", SLSL,    S_L_inv, optimize=True)
    t3a     = np.einsum("...ik,...kj->...ij", S_L_inv, outer,   optimize=True)
    term3   = np.einsum("...ik,...kj->...ij", t3a,     S_L_inv, optimize=True)
    dKL_dSL = 0.5 * (S_L_inv - term2 - term3)
    dKL_dSL = 0.5 * (dKL_dSL + np.swapaxes(dKL_dSL, -1, -2))

    # G_R = (∂KL/∂μ_L) μ_j^T + 2 (∂KL/∂Σ_L)_sym R Σ_j
    term1 = np.einsum("...i,...j->...ij", dKL_dmL, mu_j, optimize=True)
    term2 = 2.0 * np.einsum("...ij,...jk,...kl->...il", dKL_dSL, R, sigma_j, optimize=True)
    G_R   = term1 + term2
    return G_R.astype(np.float32, copy=False)



#=========================================
#           case C
#===================================



# ---------- generic helper: co-grad wrt a linear map R ----------
def cograd_linear_map(R, mu_src, Sigma_src, dKL_dm_side, dKL_dS_side):
    """
    Co-gradient for a pushforward L = R[N(mu_src, Sigma_src)]:
      ∂KL/∂R = (∂KL/∂μ_L) μ_src^T + 2 (∂KL/∂Σ_L)_sym R Σ_src
    """
    dS = 0.5 * (dKL_dS_side + np.swapaxes(dKL_dS_side, -1, -2))
    t1 = np.einsum("...i,...j->...ij", dKL_dm_side, mu_src, optimize=True)
    t2 = 2.0 * np.einsum("...ij,...jk,...kl->...il", dS, R, Sigma_src, optimize=True)
    return (t1 + t2).astype(np.float32, copy=False)

# ---------- Case C: grads wrt q_j (right side) ----------
def grad_caseC_source_qj(
    mu_p, sigma_p,          # source of LEFT (p_i)
    mu_j, sigma_j,          # source of RIGHT (q_j)
    Phit, Omega, *, eps=1e-8, assume_sanitized=True
):
    """
    KL( Phit * p_i || Omega * q_j ), all in q-frame.
    Returns ∂KL/∂μ_j, ∂KL/∂Σ_j.
    """
    mu_p    = np.asarray(mu_p,    np.float32, order="C")
    sigma_p = np.asarray(sigma_p, np.float32, order="C")
    mu_j    = np.asarray(mu_j,    np.float32, order="C")
    sigma_j = np.asarray(sigma_j, np.float32, order="C")
    Phit    = np.asarray(Phit,    np.float32, order="C")   # Φ̃_i  (q <- p)
    Omega   = np.asarray(Omega,   np.float32, order="C")   # Ω_ij^q (q <- q)

    # Left (in q-frame)
    PhitT = np.swapaxes(Phit, -1, -2)
    mu_L  = np.einsum("...ij,...j->...i", Phit,  mu_p, optimize=True)
    S_L   = np.einsum("...ik,...kl,...lj->...ij", Phit, sigma_p, PhitT, optimize=True)

    # Right (in q-frame)
    OmT   = np.swapaxes(Omega, -1, -2)
    mu_R  = np.einsum("...ij,...j->...i", Omega, mu_j, optimize=True)
    S_R   = np.einsum("...ik,...kl,...lj->...ij", Omega, sigma_j, OmT, optimize=True)
    S_R   = 0.5 * (S_R + np.swapaxes(S_R, -1, -2))

    S_R_inv = safe_inv(S_R if assume_sanitized else sanitize_sigma(S_R, eps=eps))

    # KL(L||R) partials wrt RIGHT stats
    delta   = (mu_L - mu_R).astype(np.float32, copy=False)
    v       = np.einsum("...ij,...j->...i", S_R_inv, delta, optimize=True)
    dmu_R   = -v
    dS_R    = 0.5 * ( - np.einsum("...ik,...kl,...lj->...ij", S_R_inv, S_L, S_R_inv, optimize=True)
                      - np.einsum("...i,...j->...ij", v, v, optimize=True)
                      + S_R_inv )
    dS_R    = 0.5 * (dS_R + np.swapaxes(dS_R, -1, -2))

    # Chain back to (μ_j, Σ_j): μ_R = Ω μ_j, Σ_R = Ω Σ_j Ω^T
    grad_mu_j = np.einsum("...ji,...j->...i", Omega, dmu_R, optimize=True)
    grad_S_j  = np.einsum("...ji,...jk,...kl->...il", Omega, dS_R, OmT, optimize=True)
    grad_S_j  = 0.5 * (grad_S_j + np.swapaxes(grad_S_j, -1, -2))
    return grad_mu_j.astype(np.float32, copy=False), grad_S_j.astype(np.float32, copy=False)

# ---------- Case C: grads wrt p_i (left side) ----------
def grad_caseC_model_pi(
    mu_p, sigma_p,
    mu_j, sigma_j,
    Phit, Omega, *, eps=1e-8, assume_sanitized=True
):
    """
    KL( Phit * p_i || Omega * q_j ), q-frame.
    Returns ∂KL/∂μ_p, ∂KL/∂Σ_p.
    """
    mu_p    = np.asarray(mu_p,    np.float32, order="C")
    sigma_p = np.asarray(sigma_p, np.float32, order="C")
    mu_j    = np.asarray(mu_j,    np.float32, order="C")
    sigma_j = np.asarray(sigma_j, np.float32, order="C")
    Phit    = np.asarray(Phit,    np.float32, order="C")
    Omega   = np.asarray(Omega,   np.float32, order="C")

    PhitT = np.swapaxes(Phit, -1, -2)
    OmT   = np.swapaxes(Omega,-1, -2)

    mu_L = np.einsum("...ij,...j->...i", Phit,  mu_p, optimize=True)
    S_L  = np.einsum("...ik,...kl,...lj->...ij", Phit, sigma_p, PhitT, optimize=True)
    mu_R = np.einsum("...ij,...j->...i", Omega, mu_j, optimize=True)
    S_R  = np.einsum("...ik,...kl,...lj->...ij", Omega, sigma_j, OmT, optimize=True)
    S_R  = 0.5 * (S_R + np.swapaxes(S_R, -1, -2))

    S_R_inv = safe_inv(S_R if assume_sanitized else sanitize_sigma(S_R, eps=eps))

    delta    = (mu_L - mu_R).astype(np.float32, copy=False)
    v        = np.einsum("...ij,...j->...i", S_R_inv, delta, optimize=True)

    # ∂KL/∂μ_L = S_R^{-1}(μ_L - μ_R) = v
    dmu_L    = v
    # ∂KL/∂Σ_L = 1/2 ( S_R^{-1} - S_R^{-1} Σ_L S_R^{-1} - v v^T )
    dS_L     = 0.5 * ( S_R_inv
                       - np.einsum("...ik,...kl,...lj->...ij", S_R_inv, S_L, S_R_inv, optimize=True)
                       - np.einsum("...i,...j->...ij", v, v, optimize=True) )
    dS_L     = 0.5 * (dS_L + np.swapaxes(dS_L, -1, -2))

    # Chain back to (μ_p, Σ_p): μ_L = Φ̃ μ_p, Σ_L = Φ̃ Σ_p Φ̃^T
    grad_mu_p = np.einsum("...ji,...j->...i", Phit, dmu_L, optimize=True)
    grad_S_p  = np.einsum("...ji,...jk,...kl->...il", Phit, dS_L, PhitT, optimize=True)
    grad_S_p  = 0.5 * (grad_S_p + np.swapaxes(grad_S_p, -1, -2))
    return grad_mu_p.astype(np.float32, copy=False), grad_S_p.astype(np.float32, copy=False)

# ---------- Case C: co-gradients wrt Φ̃ and Ω ----------
def cograd_caseC_phit_and_omega(
    mu_p, sigma_p, mu_j, sigma_j, Phit, Omega, *, eps=1e-8, assume_sanitized=True
):
    """
    Returns a pair (G_Phit, G_Omega) where:
      G_Phit  = ∂KL / ∂Φ̃_i
      G_Omega = ∂KL / ∂Ω_ij^q
    Each has shape (*S,3,3).
    """
    mu_p    = np.asarray(mu_p,    np.float32, order="C")
    sigma_p = np.asarray(sigma_p, np.float32, order="C")
    mu_j    = np.asarray(mu_j,    np.float32, order="C")
    sigma_j = np.asarray(sigma_j, np.float32, order="C")
    Phit    = np.asarray(Phit,    np.float32, order="C")
    Omega   = np.asarray(Omega,   np.float32, order="C")

    PhitT = np.swapaxes(Phit, -1, -2)
    OmT   = np.swapaxes(Omega,-1, -2)

    mu_L = np.einsum("...ij,...j->...i", Phit,  mu_p, optimize=True)
    S_L  = np.einsum("...ik,...kl,...lj->...ij", Phit,  sigma_p, PhitT, optimize=True)
    mu_R = np.einsum("...ij,...j->...i", Omega, mu_j,  optimize=True)
    S_R  = np.einsum("...ik,...kl,...lj->...ij", Omega, sigma_j,  OmT, optimize=True)
    S_R  = 0.5 * (S_R + np.swapaxes(S_R, -1, -2))

    S_R_inv = safe_inv(S_R if assume_sanitized else sanitize_sigma(S_R, eps=eps))

    delta   = (mu_L - mu_R).astype(np.float32, copy=False)
    v       = np.einsum("...ij,...j->...i", S_R_inv, delta, optimize=True)

    # KL(L||R) partials wrt LHS & RHS stats
    dmu_L = v
    dS_L  = 0.5 * ( S_R_inv
                    - np.einsum("...ik,...kl,...lj->...ij", S_R_inv, S_L, S_R_inv, optimize=True)
                    - np.einsum("...i,...j->...ij", v, v, optimize=True) )
    dS_L  = 0.5 * (dS_L + np.swapaxes(dS_L, -1, -2))

    dmu_R = -v
    dS_Rg = 0.5 * ( - np.einsum("...ik,...kl,...lj->...ij", S_R_inv, S_L, S_R_inv, optimize=True)
                    - np.einsum("...i,...j->...ij", v, v, optimize=True)
                    + S_R_inv )
    dS_Rg = 0.5 * (dS_Rg + np.swapaxes(dS_Rg, -1, -2))

    # Co-grads wrt linear maps
    G_Phit  = cograd_linear_map(Phit,  mu_p, sigma_p, dmu_L, dS_L)
    G_Omega = cograd_linear_map(Omega, mu_j, sigma_j, dmu_R, dS_Rg)
    return G_Phit, G_Omega

# ---------- Split (Φ̃, Ω) co-grads into site-frame co-grads ----------
def split_caseC_to_Es(G_Phit, G_Omega, Eqi, Epi, Eqj):
    """
    Φ̃ = Eqi @ Epi^T,  Ω = Eqi @ Eqj^T.
    Return matrix co-grads for Eqi, Epi, Eqj: (*S,3,3) each.
    """
    Rt   = np.swapaxes
    # Φ̃ path: R = A B with A=Eqi, B=Epi^T.
    # G_A = G * B^T = G * Epi
    G_Eqi_phit = np.einsum("...ij,...jk->...ik", G_Phit, Epi, optimize=True)
    # G_B = A^T * G; co-grad wrt Epi (since B = Epi^T): G_Epi = (G_B)^T = (Eqi^T G)^T = G^T Eqi
    G_Epi       = np.einsum("...ij,...jk->...ik", Rt(G_Phit,-1,-2), Eqi, optimize=True)

    # Ω path (same as in Case A/B): Ω = Eqi @ Eqj^T
    G_Eqi_omg = np.einsum("...ij,...jk->...ik", G_Omega, Eqj, optimize=True)
    G_Eqj     = np.einsum("...ij,...jk->...ik", Rt(Eqi,-1,-2), G_Omega, optimize=True)

    # Eqi receives both contributions
    G_Eqi = G_Eqi_phit + G_Eqi_omg
    return G_Eqi.astype(np.float32), G_Epi.astype(np.float32), G_Eqj.astype(np.float32)


#===============================
#               case D
#================================


# core/kl2_caseD.py



# ---------- Case D: grads wrt q_j (LEFT, via Ω) ----------
def grad_caseD_source_qj(
    mu_p, sigma_p,          # source for RIGHT (p_i)
    mu_j, sigma_j,          # source for LEFT  (q_j)
    Omega, Phit, *, eps=1e-8, assume_sanitized=True
):
    """
    KL( Omega * q_j || Phit * p_i ), all in q-frame.
    Returns ∂KL/∂μ_j, ∂KL/∂Σ_j.
    """
    mu_p    = np.asarray(mu_p,    np.float32, order="C")
    sigma_p = np.asarray(sigma_p, np.float32, order="C")
    mu_j    = np.asarray(mu_j,    np.float32, order="C")
    sigma_j = np.asarray(sigma_j, np.float32, order="C")
    Omega   = np.asarray(Omega,   np.float32, order="C")  # Ω_ij^q (q <- q)
    Phit    = np.asarray(Phit,    np.float32, order="C")  # Φ̃_i  (q <- p)

    OmT   = np.swapaxes(Omega, -1, -2)
    PhitT = np.swapaxes(Phit,  -1, -2)

    # Left (q-frame): L = Ω q_j
    mu_L = np.einsum("...ij,...j->...i", Omega, mu_j, optimize=True)
    S_L  = np.einsum("...ik,...kl,...lj->...ij", Omega, sigma_j, OmT, optimize=True)

    # Right (q-frame): R = Φ̃ p_i
    mu_R = np.einsum("...ij,...j->...i", Phit,  mu_p, optimize=True)
    S_R  = np.einsum("...ik,...kl,...lj->...ij", Phit,  sigma_p, PhitT, optimize=True)
    S_R  = 0.5 * (S_R + np.swapaxes(S_R, -1, -2))

    S_R_inv = safe_inv(S_R if assume_sanitized else sanitize_sigma(S_R, eps=eps))

    # KL(L||R): v = S_R^{-1}(μ_L - μ_R)
    delta   = (mu_L - mu_R).astype(np.float32, copy=False)
    v       = np.einsum("...ij,...j->...i", S_R_inv, delta, optimize=True)

    # Partials wrt LEFT stats
    dmu_L = v
    dS_L  = 0.5 * ( S_R_inv
                    - np.einsum("...ik,...kl,...lj->...ij", S_R_inv, S_L, S_R_inv, optimize=True)
                    - np.einsum("...i,...j->...ij", v, v, optimize=True) )
    dS_L  = 0.5 * (dS_L + np.swapaxes(dS_L, -1, -2))

    # Chain back to (μ_j, Σ_j): μ_L = Ω μ_j, Σ_L = Ω Σ_j Ω^T
    grad_mu_j = np.einsum("...ji,...j->...i", Omega, dmu_L, optimize=True)
    grad_S_j  = np.einsum("...ji,...jk,...kl->...il", Omega, dS_L, OmT, optimize=True)
    grad_S_j  = 0.5 * (grad_S_j + np.swapaxes(grad_S_j, -1, -2))
    return grad_mu_j.astype(np.float32, copy=False), grad_S_j.astype(np.float32, copy=False)

# ---------- Case D: grads wrt p_i (RIGHT, via Φ̃) ----------
def grad_caseD_model_pi(
    mu_p, sigma_p,
    mu_j, sigma_j,
    Omega, Phit, *, eps=1e-8, assume_sanitized=True
):
    """
    KL( Omega * q_j || Phit * p_i ), q-frame.
    Returns ∂KL/∂μ_p, ∂KL/∂Σ_p.
    """
    mu_p    = np.asarray(mu_p,    np.float32, order="C")
    sigma_p = np.asarray(sigma_p, np.float32, order="C")
    mu_j    = np.asarray(mu_j,    np.float32, order="C")
    sigma_j = np.asarray(sigma_j, np.float32, order="C")
    Omega   = np.asarray(Omega,   np.float32, order="C")
    Phit    = np.asarray(Phit,    np.float32, order="C")

    OmT   = np.swapaxes(Omega, -1, -2)
    PhitT = np.swapaxes(Phit,  -1, -2)

    mu_L = np.einsum("...ij,...j->...i", Omega, mu_j, optimize=True)
    S_L  = np.einsum("...ik,...kl,...lj->...ij", Omega, sigma_j, OmT, optimize=True)
    mu_R = np.einsum("...ij,...j->...i", Phit,  mu_p, optimize=True)
    S_R  = np.einsum("...ik,...kl,...lj->...ij", Phit,  sigma_p, PhitT, optimize=True)
    S_R  = 0.5 * (S_R + np.swapaxes(S_R, -1, -2))

    S_R_inv = safe_inv(S_R if assume_sanitized else sanitize_sigma(S_R, eps=eps))

    delta   = (mu_L - mu_R).astype(np.float32, copy=False)
    v       = np.einsum("...ij,...j->...i", S_R_inv, delta, optimize=True)

    # Partials wrt RIGHT stats
    dmu_R = -v
    dS_R  = 0.5 * ( - np.einsum("...ik,...kl,...lj->...ij", S_R_inv, S_L, S_R_inv, optimize=True)
                    - np.einsum("...i,...j->...ij", v, v, optimize=True)
                    + S_R_inv )
    dS_R  = 0.5 * (dS_R + np.swapaxes(dS_R, -1, -2))

    # Chain back through Φ̃: μ_R = Φ̃ μ_p, Σ_R = Φ̃ Σ_p Φ̃^T
    grad_mu_p = np.einsum("...ji,...j->...i", Phit, dmu_R, optimize=True)
    grad_S_p  = np.einsum("...ji,...jk,...kl->...il", Phit, dS_R, PhitT, optimize=True)
    grad_S_p  = 0.5 * (grad_S_p + np.swapaxes(grad_S_p, -1, -2))
    return grad_mu_p.astype(np.float32, copy=False), grad_S_p.astype(np.float32, copy=False)

# ---------- Case D: co-grads wrt Ω and Φ̃ ----------
def cograd_caseD_phit_and_omega(
    mu_p, sigma_p, mu_j, sigma_j, Omega, Phit, *, eps=1e-8, assume_sanitized=True
):
    """
    Returns (G_Omega, G_Phit) where:
      G_Omega = ∂KL / ∂Ω_ij^q   (left map)
      G_Phit  = ∂KL / ∂Φ̃_i     (right map)
    Each is (*S,3,3).
    """
    mu_p    = np.asarray(mu_p,    np.float32, order="C")
    sigma_p = np.asarray(sigma_p, np.float32, order="C")
    mu_j    = np.asarray(mu_j,    np.float32, order="C")
    sigma_j = np.asarray(sigma_j, np.float32, order="C")
    Omega   = np.asarray(Omega,   np.float32, order="C")
    Phit    = np.asarray(Phit,    np.float32, order="C")

    OmT   = np.swapaxes(Omega, -1, -2)
    PhitT = np.swapaxes(Phit,  -1, -2)

    mu_L = np.einsum("...ij,...j->...i", Omega, mu_j, optimize=True)
    S_L  = np.einsum("...ik,...kl,...lj->...ij", Omega, sigma_j, OmT, optimize=True)
    mu_R = np.einsum("...ij,...j->...i", Phit,  mu_p, optimize=True)
    S_R  = np.einsum("...ik,...kl,...lj->...ij", Phit,  sigma_p, PhitT, optimize=True)
    S_R  = 0.5 * (S_R + np.swapaxes(S_R, -1, -2))

    S_R_inv = safe_inv(S_R if assume_sanitized else sanitize_sigma(S_R, eps=eps))

    delta = (mu_L - mu_R).astype(np.float32, copy=False)
    v     = np.einsum("...ij,...j->...i", S_R_inv, delta, optimize=True)

    # Partials
    dmu_L = v
    dS_L  = 0.5 * ( S_R_inv
                    - np.einsum("...ik,...kl,...lj->...ij", S_R_inv, S_L, S_R_inv, optimize=True)
                    - np.einsum("...i,...j->...ij", v, v, optimize=True) )
    dS_L  = 0.5 * (dS_L + np.swapaxes(dS_L, -1, -2))

    dmu_R = -v
    dS_Rg = 0.5 * ( - np.einsum("...ik,...kl,...lj->...ij", S_R_inv, S_L, S_R_inv, optimize=True)
                    - np.einsum("...i,...j->...ij", v, v, optimize=True)
                    + S_R_inv )
    dS_Rg = 0.5 * (dS_Rg + np.swapaxes(dS_Rg, -1, -2))

    # Co-gradients wrt the linear maps
    G_Omega = cograd_linear_map(Omega, mu_j, sigma_j, dmu_L, dS_L)   # left map
    G_Phit  = cograd_linear_map(Phit,  mu_p, sigma_p, dmu_R, dS_Rg)  # right map
    return G_Omega, G_Phit

# ---------- Split to site-frame co-grads ----------
def split_caseD_to_Es(G_Omega, G_Phit, Eqi, Eqj, Epi):
    """
    Ω = Eqi @ Eqj^T,  Φ̃ = Eqi @ Epi^T.
    Return matrix co-grads for Eqi, Eqj, Epi: (*S,3,3) each.
    """
    Rt = np.swapaxes
    # Ω path (same split as A/B/C): Ω = Eqi @ Eqj^T
    G_Eqi_omg = np.einsum("...ij,...jk->...ik", G_Omega, Eqj, optimize=True)
    G_Eqj     = np.einsum("...ij,...jk->...ik", Rt(Eqi,-1,-2), G_Omega, optimize=True)

    # Φ̃ path with transpose: Φ̃ = Eqi @ Epi^T
    G_Eqi_phit = np.einsum("...ij,...jk->...ik", G_Phit, Epi, optimize=True)
    G_Epi      = np.einsum("...ij,...jk->...ik", Rt(G_Phit,-1,-2), Eqi, optimize=True)  # (G^T) Eqi

    # Eqi receives both contributions
    G_Eqi = G_Eqi_omg + G_Eqi_phit
    return G_Eqi.astype(np.float32), G_Eqj.astype(np.float32), G_Epi.astype(np.float32)



#===============================================
#
#       ALIGNMENT GRADS
#
#=================================================



# =============================================================================
# Q-ALIGN: KL( q_i || Ω^q_{ij} q_j )   (all in the q-frame)
# =============================================================================

def grad_qalign_left_qi(mu_i, S_i, mu_j, S_j, Omega, *, eps=1e-8, assume_sanitized=True):
    """
    ∂ wrt (μ_i, Σ_i) for KL(q_i || Ω q_j).  Left = q_i, Right = Ω q_j.
    """
    mu_i = np.asarray(mu_i, np.float32); S_i = np.asarray(S_i, np.float32)
    mu_j = np.asarray(mu_j, np.float32); S_j = np.asarray(S_j, np.float32)
    Omega = np.asarray(Omega, np.float32)
    OmT = np.swapaxes(Omega, -1, -2)

    mu_R = np.einsum("...ij,...j->...i", Omega, mu_j, optimize=True)
    S_R  = np.einsum("...ik,...kl,...lj->...ij", Omega, S_j, OmT, optimize=True)
    S_R  = 0.5 * (S_R + np.swapaxes(S_R, -1, -2))
    S_R_inv = safe_inv(S_R if assume_sanitized else sanitize_sigma(S_R, eps=eps))

    delta = (mu_i - mu_R).astype(np.float32, copy=False)
    v     = np.einsum("...ij,...j->...i", S_R_inv, delta, optimize=True)

    # KL(L||R) wrt LEFT stats
    dmu_i = v
    dS_i  = 0.5 * ( S_R_inv
                    - np.einsum("...ik,...kl,...lj->...ij", S_R_inv, S_i, S_R_inv, optimize=True)
                    - np.einsum("...i,...j->...ij", v, v, optimize=True) )
    dS_i  = 0.5 * (dS_i + np.swapaxes(dS_i, -1, -2))
    return dmu_i.astype(np.float32, copy=False), dS_i.astype(np.float32, copy=False)

def grad_qalign_right_qj(mu_i, S_i, mu_j, S_j, Omega, *, eps=1e-8, assume_sanitized=True):
    """
    ∂ wrt (μ_j, Σ_j) for KL(q_i || Ω q_j).  Uses chain-rule through Ω.
    """
    mu_i = np.asarray(mu_i, np.float32); S_i = np.asarray(S_i, np.float32)
    mu_j = np.asarray(mu_j, np.float32); S_j = np.asarray(S_j, np.float32)
    Omega = np.asarray(Omega, np.float32)
    OmT = np.swapaxes(Omega, -1, -2)

    mu_R = np.einsum("...ij,...j->...i", Omega, mu_j, optimize=True)
    S_R  = np.einsum("...ik,...kl,...lj->...ij", Omega, S_j, OmT, optimize=True)
    S_R  = 0.5 * (S_R + np.swapaxes(S_R, -1, -2))
    S_R_inv = safe_inv(S_R if assume_sanitized else sanitize_sigma(S_R, eps=eps))

    delta = (mu_i - mu_R).astype(np.float32, copy=False)
    v     = np.einsum("...ij,...j->...i", S_R_inv, delta, optimize=True)

    # KL(L||R) partials wrt RIGHT stats
    dmu_R = -v
    dS_R  = 0.5 * ( - np.einsum("...ik,...kl,...lj->...ij", S_R_inv, S_i, S_R_inv, optimize=True)
                    - np.einsum("...i,...j->...ij", v, v, optimize=True)
                    + S_R_inv )
    dS_R  = 0.5 * (dS_R + np.swapaxes(dS_R, -1, -2))

    # Chain back through Ω
    dmu_j = np.einsum("...ji,...j->...i", Omega, dmu_R, optimize=True)
    dS_j  = np.einsum("...ji,...jk,...kl->...il", Omega, dS_R, OmT, optimize=True)
    dS_j  = 0.5 * (dS_j + np.swapaxes(dS_j, -1, -2))
    return dmu_j.astype(np.float32, copy=False), dS_j.astype(np.float32, copy=False)

def cograd_qalign_Omega(mu_i, S_i, mu_j, S_j, Omega, *, eps=1e-8, assume_sanitized=True):
    """
    Co-gradient wrt Ω in KL(q_i || Ω q_j).
    """
    mu_i = np.asarray(mu_i, np.float32); S_i = np.asarray(S_i, np.float32)
    mu_j = np.asarray(mu_j, np.float32); S_j = np.asarray(S_j, np.float32)
    Omega = np.asarray(Omega, np.float32)
    OmT = np.swapaxes(Omega, -1, -2)

    mu_R = np.einsum("...ij,...j->...i", Omega, mu_j, optimize=True)
    S_R  = np.einsum("...ik,...kl,...lj->...ij", Omega, S_j, OmT, optimize=True)
    S_R  = 0.5 * (S_R + np.swapaxes(S_R, -1, -2))
    S_R_inv = safe_inv(S_R if assume_sanitized else sanitize_sigma(S_R, eps=eps))

    delta = (mu_i - mu_R).astype(np.float32, copy=False)
    v     = np.einsum("...ij,...j->...i", S_R_inv, delta, optimize=True)

    # Partials wrt right stats (same as grad_qalign_right_qj)
    dmu_R = -v
    dS_R  = 0.5 * ( - np.einsum("...ik,...kl,...lj->...ij", S_R_inv, S_i, S_R_inv, optimize=True)
                    - np.einsum("...i,...j->...ij", v, v, optimize=True)
                    + S_R_inv )
    dS_R  = 0.5 * (dS_R + np.swapaxes(dS_R, -1, -2))

    # Co-gradient wrt Ω
    return cograd_linear_map(Omega, mu_j, S_j, dmu_R, dS_R)

def split_qalign_Omega_to_Es(G_Omega, Eqi, Eqj):
    """
    Ω = Eqi @ Eqj^T  → return (G_Eqi, G_Eqj)
    """
    Rt = np.swapaxes
    G_Eqi = np.einsum("...ij,...jk->...ik", G_Omega, Eqj, optimize=True)
    G_Eqj = np.einsum("...ij,...jk->...ik", Rt(Eqi,-1,-2), G_Omega, optimize=True)
    return G_Eqi.astype(np.float32), G_Eqj.astype(np.float32)

# =============================================================================
# P-ALIGN: KL( p_i || \tilde{Ω}^p_{ij} p_j )   (all in the p-frame)
# =============================================================================

def grad_palign_left_pi(mu_i, S_i, mu_j, S_j, Omegap, *, eps=1e-8, assume_sanitized=True):
    """
    ∂ wrt (μ_p_i, Σ_p_i) for KL(p_i || Ω~ p_j). Left = p_i, Right = Ω~ p_j (p-frame).
    """
    mu_i = np.asarray(mu_i, np.float32); S_i = np.asarray(S_i, np.float32)
    mu_j = np.asarray(mu_j, np.float32); S_j = np.asarray(S_j, np.float32)
    Omegap = np.asarray(Omegap, np.float32)
    OpT = np.swapaxes(Omegap, -1, -2)

    mu_R = np.einsum("...ij,...j->...i", Omegap, mu_j, optimize=True)
    S_R  = np.einsum("...ik,...kl,...lj->...ij", Omegap, S_j, OpT, optimize=True)
    S_R  = 0.5 * (S_R + np.swapaxes(S_R, -1, -2))
    S_R_inv = safe_inv(S_R if assume_sanitized else sanitize_sigma(S_R, eps=eps))

    delta = (mu_i - mu_R).astype(np.float32, copy=False)
    v     = np.einsum("...ij,...j->...i", S_R_inv, delta, optimize=True)

    dmu_i = v
    dS_i  = 0.5 * ( S_R_inv
                    - np.einsum("...ik,...kl,...lj->...ij", S_R_inv, S_i, S_R_inv, optimize=True)
                    - np.einsum("...i,...j->...ij", v, v, optimize=True) )
    dS_i  = 0.5 * (dS_i + np.swapaxes(dS_i, -1, -2))
    return dmu_i.astype(np.float32, copy=False), dS_i.astype(np.float32, copy=False)

def grad_palign_right_pj(mu_i, S_i, mu_j, S_j, Omegap, *, eps=1e-8, assume_sanitized=True):
    """
    ∂ wrt (μ_p_j, Σ_p_j) for KL(p_i || Ω~ p_j).  Chain through Ω~.
    """
    mu_i = np.asarray(mu_i, np.float32); S_i = np.asarray(S_i, np.float32)
    mu_j = np.asarray(mu_j, np.float32); S_j = np.asarray(S_j, np.float32)
    Omegap = np.asarray(Omegap, np.float32)
    OpT = np.swapaxes(Omegap, -1, -2)

    mu_R = np.einsum("...ij,...j->...i", Omegap, mu_j, optimize=True)
    S_R  = np.einsum("...ik,...kl,...lj->...ij", Omegap, S_j, OpT, optimize=True)
    S_R  = 0.5 * (S_R + np.swapaxes(S_R, -1, -2))
    S_R_inv = safe_inv(S_R if assume_sanitized else sanitize_sigma(S_R, eps=eps))

    delta = (mu_i - mu_R).astype(np.float32, copy=False)
    v     = np.einsum("...ij,...j->...i", S_R_inv, delta, optimize=True)

    dmu_R = -v
    dS_R  = 0.5 * ( - np.einsum("...ik,...kl,...lj->...ij", S_R_inv, S_i, S_R_inv, optimize=True)
                    - np.einsum("...i,...j->...ij", v, v, optimize=True)
                    + S_R_inv )
    dS_R  = 0.5 * (dS_R + np.swapaxes(dS_R, -1, -2))

    dmu_j = np.einsum("...ji,...j->...i", Omegap, dmu_R, optimize=True)
    dS_j  = np.einsum("...ji,...jk,...kl->...il", Omegap, dS_R, OpT, optimize=True)
    dS_j  = 0.5 * (dS_j + np.swapaxes(dS_j, -1, -2))
    return dmu_j.astype(np.float32, copy=False), dS_j.astype(np.float32, copy=False)

def cograd_palign_Omegap(mu_i, S_i, mu_j, S_j, Omegap, *, eps=1e-8, assume_sanitized=True):
    """
    Co-gradient wrt Ω~ in KL(p_i || Ω~ p_j) (p-frame).
    """
    mu_i = np.asarray(mu_i, np.float32); S_i = np.asarray(S_i, np.float32)
    mu_j = np.asarray(mu_j, np.float32); S_j = np.asarray(S_j, np.float32)
    Omegap = np.asarray(Omegap, np.float32)
    OpT = np.swapaxes(Omegap, -1, -2)

    mu_R = np.einsum("...ij,...j->...i", Omegap, mu_j, optimize=True)
    S_R  = np.einsum("...ik,...kl,...lj->...ij", Omegap, S_j, OpT, optimize=True)
    S_R  = 0.5 * (S_R + np.swapaxes(S_R, -1, -2))
    S_R_inv = safe_inv(S_R if assume_sanitized else sanitize_sigma(S_R, eps=eps))

    delta = (mu_i - mu_R).astype(np.float32, copy=False)
    v     = np.einsum("...ij,...j->...i", S_R_inv, delta, optimize=True)

    dmu_R = -v
    dS_R  = 0.5 * ( - np.einsum("...ik,...kl,...lj->...ij", S_R_inv, S_i, S_R_inv, optimize=True)
                    - np.einsum("...i,...j->...ij", v, v, optimize=True)
                    + S_R_inv )
    dS_R  = 0.5 * (dS_R + np.swapaxes(dS_R, -1, -2))

    return cograd_linear_map(Omegap, mu_j, S_j, dmu_R, dS_R)

def split_palign_Omegap_to_Es(G_Omegap, Epi, Epj):
    """
    Ω~ = Epi @ Epj^T  → return (G_Epi, G_Epj)
    """
    Rt = np.swapaxes
    G_Epi = np.einsum("...ij,...jk->...ik", G_Omegap, Epj, optimize=True)
    G_Epj = np.einsum("...ij,...jk->...ik", Rt(Epi,-1,-2), G_Omegap, optimize=True)
    return G_Epi.astype(np.float32), G_Epj.astype(np.float32)



