# -*- coding: utf-8 -*-
"""
Created on Sat Sep 27 15:19:10 2025

@author: chris and christine

Case A:  KL( Φ_i[Ω^q_ij q_j] || p_i )
Case B:  KL( p_i || Φ_i Ω^q_ij[q_j] )

Case C: KL( Φ̃_i p_i  ||  Ω^q_ij q_j )
Case D: KL( Ω^q_ij * q_j || Φ̃_i * p_i )

Default Q:  KL( q_i || Ω^q_ij q_j )
Default P:  KL( p_i || Ω^p_ij p_j ) 

"""

import numpy as np
from runtime_context import cfg_get
from core.numerical_utils import sanitize_sigma, kl_gaussian, push_gaussian
from core.transport_cache import Omega, Phi   
from utils import _joint_mask


# ---------- common utils ----------

def _ids_of(agents):
    return [int(getattr(a, "id", i)) for i, a in enumerate(agents)]


def _stable_softmax_over_senders(logits: np.ndarray) -> np.ndarray:
    """
    logits: (J,*S) with -inf where a sender is masked; +inf/nan treated as invalid.
    Returns: (J,*S) softmax over the first axis. Columns with no valid senders -> all zeros.
    """
    import numpy as np

    # Work in float64 for numerical headroom
    L = np.asarray(logits, dtype=np.float64)

    # Valid entries are finite
    valid = np.isfinite(L)                    # (J,*S)

    # Replace invalid with -inf so they never win the max
    L_masked = np.where(valid, L, -np.inf)

    # Max over senders (safe even if all -inf; result is -inf in that column)
    m = np.max(L_masked, axis=0, keepdims=True)  # (1,*S)

    # Compute (L_masked - m) only where valid to avoid (-inf) - (-inf) nans
    delta = np.zeros_like(L, dtype=np.float64)
    np.subtract(L_masked, m, out=delta, where=valid)

    # Exponentiate only where valid; others stay 0
    exps = np.zeros_like(L, dtype=np.float64)
    np.exp(delta, out=exps, where=valid)

    # Partition function
    Z = np.sum(exps, axis=0, keepdims=True)   # (1,*S)

    # Softmax; where Z==0 (no valid senders), keep zeros to avoid NaN
    W = np.divide(exps, Z, out=np.zeros_like(exps), where=(Z > 0))
  
    # Optional sanity: rows sum to 1 where any valid
  #  sums = W.sum(axis=0); overlap_any = np.any(valid, axis=0)
  #  if np.any(overlap_any):
  #      err = float(np.max(np.abs(sums[overlap_any] - 1.0)))
  #      if err > 1e-5: raise FloatingPointError(f"softmax not normalized (max err {err})")

    return W.astype(np.float32, copy=False)




def build_beta_q_peer(ctx, agents, *, kappa: float, mode: str, eps: float, tau: float):
    """
    Pixelwise β_q for each edge (i<-j) from KL(q_i || Ω^q_ij q_j), generalized to D-D grids.

    Returns:
      beta_q: dict[(i_id, j_id)] -> (*S,) float32
      kl_q:   dict[(i_id, j_id)] -> (*S,) float32  (KL per pixel; 0 outside overlap)
    """
    import numpy as np

    tiny   = 1e-12
    kappa  = float(max(kappa, tiny))
    ids    = _ids_of(agents)

    beta_q, kl_q = {}, {}

    for i_idx, ai in enumerate(agents):
        i_id = int(ids[i_idx])

        # Receiver belief (authoritative spatial shape S)
        mu_i = np.asarray(ai.mu_q_field,  np.float32)                   # (*S, Kq)
        S_i  = sanitize_sigma(np.asarray(ai.sigma_q_field, np.float64)) # (*S, Kq, Kq)
        S    = mu_i.shape[:-1]                                          # base space shape (*S,)

        K_masked = []   # list of ( *S, ) float64 with +inf off-overlap (for softmax gating)
        K_grad   = []   # list of ( *S, ) float32 with 0 off-overlap (for grad-through-beta)
        js       = []
        masks    = []   # list of ( *S, ) bool

        for j_idx, aj in enumerate(agents):
            if j_idx == i_idx:
                continue
            j_id = int(ids[j_idx])

            # Overlap mask in i's spatial frame: (*S,) bool
            overlap = _joint_mask(ai, aj, tau=tau, as_vector=False)
            if overlap.shape != S:
                # Try to broadcast to S if caller gave a different-but-compatible shape
                try:
                    overlap = np.broadcast_to(overlap, S)
                except Exception as e:
                    raise ValueError(
                        f"build_beta_q_peer: overlap mask shape {overlap.shape} not broadcastable to {S} "
                        f"for (i={i_id}, j={j_id})"
                    ) from e

            if not np.any(overlap):
                continue

            # Transport sender j into i's q-frame
            Om_q  = Omega(ctx, ai, aj, which="q")                       # (*S, Kq, Kq) or (Kq,Kq)
            mu_qj = np.asarray(aj.mu_q_field,  np.float32)              # (*S, Kq)
            S_qj  = sanitize_sigma(np.asarray(aj.sigma_q_field, np.float64))  # (*S, Kq, Kq)

            mu_t, S_t, _ = push_gaussian(
                mu_qj, S_qj, Om_q, eps=eps, return_inv=True, assume_orthogonal=False
            )  # (*S, Kq), (*S, Kq, Kq)

            # Per-pixel KL: KL(q_i || Ω^q_ij q_j)  → expected shape (*S,)
            KLpx = kl_gaussian(mu_i, S_i, mu_t, S_t)
            KLpx = np.asarray(KLpx, np.float64)

            # If implementation returns extra trailing dims, collapse them
            if KLpx.shape != S:
                # allow cases like (*S, r) → sum over trailing axes
                if KLpx.shape[:len(S)] != S:
                    raise ValueError(
                        f"KLpx spatial dims {KLpx.shape} not compatible with base shape {S} "
                        f"for (i={i_id}, j={j_id})"
                    )
                if KLpx.ndim > len(S):
                    KLpx = KLpx.reshape(*S, -1).sum(axis=-1)

            # Masked for β construction (+inf outside overlap) and for grad (0 outside)
            K_masked.append(np.where(overlap, KLpx, np.inf))
            K_grad.append(np.where(overlap, KLpx, 0.0).astype(np.float32, copy=False))
            js.append(j_id)
            masks.append(overlap)

        if not js:
            continue

        # Stack over senders: (J, *S)
        K = np.stack(K_masked, axis=0)
        if K.shape[1:] != S:
            raise ValueError(f"Stacked KL maps shape {K.shape} wrong; expected (J, {S})")

        # logits = -KL/κ
        L = -K / kappa  # (J, *S)

        mode_l = (mode or "softmax").lower()
        
        if mode_l in ("softmax", "sm", "normexp"):
            Wj = _stable_softmax_over_senders(L) 
        
        elif mode_l in ("exp", "gated-exp", "exp-gated"):
            Wj  = np.exp(L) * np.isfinite(K)                       # (J, *S)
        else:
            # fallback to softmax
            m   = np.max(L, axis=0, keepdims=True)
            ex  = np.exp(L - m) * np.isfinite(K)
            den = np.sum(ex, axis=0, keepdims=True)
            den = np.maximum(den, tiny)
            Wj  = ex / den

        # Store per-edge maps (each (*S,))
        for s, j_id in enumerate(js):
            w_m = Wj[s]                                    # (*S,)
            if masks[s] is not None:
                w_m = np.where(masks[s], w_m, 0.0)
            w_m = np.asarray(w_m, np.float32, order="C")
            if w_m.shape != S:
                # collapse any accidental trailing dims
                if w_m.shape[:len(S)] != S:
                    raise ValueError(
                        f"β_q map shape {w_m.shape} not compatible with base shape {S} "
                        f"for (i={i_id}, j={j_id})"
                    )
                if w_m.ndim > len(S):
                    w_m = w_m.reshape(*S, -1).sum(axis=-1)
            if w_m.shape != S:
                raise ValueError(f"β_q map shape {w_m.shape} not equal to base shape {S}")

            beta_q[(i_id, int(j_id))] = w_m
            kl_q[(i_id, int(j_id))]   = K_grad[s]          # (*S,) float32

    return beta_q, kl_q



def build_beta_p_peer(ctx, agents, *, kappa: float, mode: str, eps: float, tau: float):
    """
    Pixelwise β_p for each edge (i<-j) from:
        KL( p_i || Ω^p_ij p_j )   evaluated in P_i, per site.

    Returns:
      beta_p: dict[(i_id, j_id)] -> (*S,) float32
      kl_p:   dict[(i_id, j_id)] -> (*S,) float32   (KL per pixel; 0 outside overlap)
    """
    import numpy as np

    tiny  = 1e-12
    kappa = float(max(kappa, tiny))
    mode_l = (mode or "softmax").lower()
    if mode_l not in ("softmax", "sm", "normexp", "exp", "gated-exp", "exp-gated"):
        mode_l = "softmax"

    beta_p, kl_p = {}, {}
    ids = _ids_of(agents)

    for i_idx, ai in enumerate(agents):
        i_id = int(ids[i_idx])

        # Receiver model fields in P_i (authoritative spatial shape *S)
        mu_pi = np.asarray(ai.mu_p_field,  np.float32)                     # (*S, Kp)
        S_pi  = sanitize_sigma(np.asarray(ai.sigma_p_field, np.float64))   # (*S, Kp, Kp)
        S = mu_pi.shape[:-1]  # base space shape *S

        logits_list  = []   # (J,*S)
        mask_list    = []   # (J,*S) bool
        js           = []   # sender ids
        kl_grad_list = []   # (J,*S) float32

        for j_idx, aj in enumerate(agents):
            if j_idx == i_idx:
                continue
            j_id = int(ids[j_idx])

            # Overlap in i's frame → (*S,)
            ov = _joint_mask(ai, aj, tau=tau, as_vector=False)
            ov = np.asarray(ov)
            if ov.shape != S:
                pad = (1,) * max(0, len(S) - ov.ndim)
                try:
                    ov = np.broadcast_to(ov.reshape(pad + ov.shape), S)
                except Exception as e:
                    raise ValueError(f"overlap mask {ov.shape} not broadcastable to {S}") from e
            overlap = (ov > 0)
            if not np.any(overlap):
                continue

            # Push sender model into i's P-frame: Ω^p_ij p_j
            Om_p  = Omega(ctx, ai, aj, which="p")                             # (*S,Kp,Kp) or (Kp,Kp)
            mu_pj = np.asarray(aj.mu_p_field,  np.float32)                     # (*S,Kp)
            S_pj  = sanitize_sigma(np.asarray(aj.sigma_p_field, np.float64))   # (*S,Kp,Kp)

            mu_t, S_t, _ = push_gaussian(
                mu_pj, S_pj, Om_p, eps=eps, return_inv=True, assume_orthogonal=False
            )  # (*S,Kp), (*S,Kp,Kp)

            # Per-site KL in P_i: KL( p_i || Ω^p_ij p_j ) → (*S,)
            KLpx = kl_gaussian(mu_pi, S_pi, mu_t, S_t)
            KLpx = np.asarray(KLpx, np.float64)
            if KLpx.shape != S:
                if KLpx.shape[:len(S)] == S and KLpx.ndim > len(S):
                    KLpx = KLpx.reshape(S + (-1,)).sum(axis=-1)
                else:
                    raise ValueError(f"KLpx spatial dims {KLpx.shape} incompatible with {S} for (i={i_id}, j={j_id})")

            # logits with -inf where no overlap → excluded from softmax
            logit = -KLpx / kappa
            logit = np.where(overlap, logit, -np.inf)

            logits_list.append(logit)
            mask_list.append(overlap)
            js.append(j_id)
            # KL for grads: 0 outside overlap
            kl_grad_list.append(np.where(overlap, KLpx, 0.0).astype(np.float32, copy=False))

        if not js:
            continue

        # Stack senders: (J,*S)
        L = np.stack(logits_list, axis=0)
        overlap_any = np.any(np.stack(mask_list, axis=0), axis=0)  # (*S,)

        # Sender weights (mask-safe)
        if mode_l in ("softmax", "sm", "normexp"):
            Wjx = _stable_softmax_over_senders(L)   # L = -K / kappa, shape (J,*S)
        
        elif mode_l in ("exp", "gated-exp", "exp-gated"):
            Wjx  = np.exp(L)                             # (J,*S)
            Wjx  = np.where(overlap_any[None, ...], Wjx, 0.0)
        else:
            Lmax = np.max(L, axis=0, keepdims=True)
            exps = np.exp(L - Lmax)
            exps = np.where(overlap_any[None, ...], exps, 0.0)
            Z    = np.sum(exps, axis=0, keepdims=True)
            Z    = np.maximum(Z, tiny)
            Wjx  = exps / Z

        # Store per-edge fields
        for m, j_id in enumerate(js):
            w_m = Wjx[m]                       # (*S,)
            w_m = np.where(mask_list[m], w_m, 0.0)
            w_m = np.asarray(w_m, np.float32, order="C")
            if w_m.shape != S:
                if w_m.shape[:len(S)] == S:
                    w_m = w_m.reshape(S + (-1,)).sum(axis=-1)
                else:
                    raise ValueError(f"β_p map shape {w_m.shape} not {S} for (i={i_id}, j={j_id})")

            beta_p[(i_id, int(j_id))] = w_m
            kl_p[(i_id, int(j_id))]   = kl_grad_list[m]

    return beta_p, kl_p





# ---------- Q-fiber builders ----------
def build_beta_q_model_gated(ctx, agents, *, kappa: float, mode: str, eps: float, tau: float):
    """
    Pixelwise β_q maps for each (i<-j):
      β_{i<-j}(x) ∝ exp( - KL_x( Ω^q_ij q_j || Φ̃_i p_i ) / κ )

    Returns:
      beta_q: dict[(i_id, j_id)] -> (*S,) float32
      kl_q:   dict[(i_id, j_id)] -> (*S,) float32  (KL per pixel; 0 outside overlap)
    """
    import numpy as np

    ids = [int(getattr(a, "id", i)) for i, a in enumerate(agents)]
    beta_q, kl_q = {}, {}

    # --- Precompute q̂_i = Φ̃_i p_i in Q_i (per agent i) ---
    qhat_mu, qhat_S = [], []
    for ai in agents:
        A     = Phi(ctx, ai, kind="p_to_q")                       # (..., q, p)
        mu_p  = np.asarray(ai.mu_p_field,  np.float32)            # (*S, Kp)
        S_p   = sanitize_sigma(np.asarray(ai.sigma_p_field, np.float64))  # (*S, Kp, Kp)
        mu_q  = np.einsum("...qp,...p->...q",  A, mu_p, optimize=True).astype(np.float32, copy=False)  # (*S, Kq)
        S_q   = np.einsum("...qp,...pr,...rq->...qr", A, S_p, A, optimize=True)                        # (*S, Kq, Kq)
        S_q   = sanitize_sigma(S_q).astype(np.float64, copy=False)
        qhat_mu.append(mu_q)
        qhat_S.append(S_q)

    softmax_mode = (mode or "softmax").lower()
    if softmax_mode not in ("softmax", "sm", "normexp", "exp", "gated-exp", "exp-gated"):
        softmax_mode = "softmax"

    # --- Loop receivers i ---
    for i_idx, ai in enumerate(agents):
        i_id     = ids[i_idx]
        mu_q_hat = qhat_mu[i_idx]            # (*S, Kq)
        S_q_hat  = qhat_S[i_idx]             # (*S, Kq, Kq)

        S = mu_q_hat.shape[:-1]              # spatial shape *S
        Kq = int(mu_q_hat.shape[-1])

        KL_maps_masked = []   # list of ( *S,) masked with +inf outside overlap
        KL_maps_grad   = []   # list of ( *S,) with 0 outside overlap (for grads)
        sender_id      = []
        masks          = []   # (*S,) bool per sender

        # --- Loop senders j ---
        for j_idx, aj in enumerate(agents):
            if j_idx == i_idx:
                continue
            j_id = ids[j_idx]

            # Overlap mask: accept any broadcastable mask; threshold with tau
            # Prefer your existing joint mask helper if it returns (*S,), else broadcast
            overlap_raw = _joint_mask(ai, aj, tau=tau, as_vector=False)  # possibly 2-D
            ov = np.asarray(overlap_raw)
            if ov.shape != S:
                pad = (1,) * max(0, len(S) - ov.ndim)
                try:
                    ov = np.broadcast_to(ov.reshape(pad + ov.shape), S)
                except Exception as e:
                    raise ValueError(f"overlap mask {ov.shape} not broadcastable to {S}") from e
            overlap = (ov > 0)

            if not np.any(overlap):
                continue

            Om_q   = Omega(ctx, ai, aj, which="q")                             # push to i-frame
            mu_qj  = np.asarray(aj.mu_q_field,  np.float32)                    # (*S, Kq)
            S_qj   = sanitize_sigma(np.asarray(aj.sigma_q_field, np.float64))  # (*S, Kq, Kq)

            mu_t, S_t, _ = push_gaussian(
                mu_qj, S_qj, Om_q, eps=eps, return_inv=True, assume_orthogonal=False
            )  # (*S, Kq), (*S, Kq, Kq)

            # KL per site → shape (*S,)
            KLpx = kl_gaussian(mu_t, S_t, mu_q_hat, S_q_hat)  # expected (*S,)
            KLpx = np.asarray(KLpx, np.float64)
            if KLpx.shape != S:
                # if lib returns extra axes, collapse trailing dims
                if KLpx.shape[:len(S)] == S and KLpx.ndim > len(S):
                    KLpx = KLpx.reshape(S + (-1,)).sum(axis=-1)
                else:
                    raise ValueError(f"KLpx spatial dims {KLpx.shape} incompatible with {S} for (i={i_id}, j={j_id})")

            # For β: +inf outside overlap so exp(-inf)=0
            KL_masked = np.where(overlap, KLpx, np.inf)
            # For gradient weighting: 0 outside overlap
            KL_grad   = np.where(overlap, KLpx, 0.0).astype(np.float32, copy=False)

            KL_maps_masked.append(KL_masked)
            KL_maps_grad.append(KL_grad)
            sender_id.append(j_id)
            masks.append(overlap)

        if not sender_id:
            continue

        # Stack senders: (J, *S)
        Kstack = np.stack(KL_maps_masked, axis=0)
        # logits = -KL/κ
        logits = -Kstack / max(1e-12, float(kappa))

        if softmax_mode in ("softmax", "sm", "normexp"):
            # valid where logits are finite (Kstack had +inf outside)
            Wj = _stable_softmax_over_senders(logits)
                          # (J,*S)
        elif softmax_mode in ("exp", "gated-exp", "exp-gated"):
            Wj  = np.exp(logits) * np.isfinite(Kstack)         # (J,*S)
        else:
            m   = np.max(logits, axis=0, keepdims=True)
            ex  = np.exp(logits - m) * np.isfinite(Kstack)
            den = np.sum(ex, axis=0, keepdims=True)
            den = np.maximum(den, 1e-12)
            Wj  = ex / den

        # Store per-edge β and KL fields
        for s, j_id in enumerate(sender_id):
            wm = Wj[s]                          # (*S,)
            if masks[s] is not None:
                wm = np.where(masks[s], wm, 0.0)
            wm = np.asarray(wm, np.float32, order="C")
            if wm.shape != S:
                # last-gasp collapse if some numeric path produced extra dims
                if wm.shape[:len(S)] == S:
                    wm = wm.reshape(S + (-1,)).sum(axis=-1)
                else:
                    raise ValueError(f"β_q map shape {wm.shape} not {S} for (i={i_id}, j={j_id})")

            beta_q[(i_id, int(j_id))] = wm
            kl_q[(i_id, int(j_id))]   = KL_maps_grad[s].astype(np.float32, copy=False)

    return beta_q, kl_q






def build_beta_q_model_gated_reversed(
    ctx, agents, *,
    kappa: float,
    mode: str,
    eps: float,
    tau: float,
):
    """
    Pixelwise β_q (reversed order):
        KL( Φ̃_i p_i  ||  Ω^q_ij q_j )   in Q_i, per pixel.

    Returns:
      beta_q: dict[(i_id, j_id)] -> (*S,) float32
      kl_q:   dict[(i_id, j_id)] -> (*S,) float32   (KL per pixel; 0 outside overlap)
    """
    import numpy as np

    tiny  = 1e-12
    kappa = float(max(kappa, tiny))
    mode_l = (mode or "softmax").lower()

    beta_q, kl_q = {}, {}
    ids = _ids_of(agents)

    # Precompute receiver's model rendered in Q_i: q̂_i = Φ̃_i p_i, shapes (*S,Kq), (*S,Kq,Kq)
    qhat_mu, qhat_S = [], []
    for ai in agents:
        A     = Phi(ctx, ai, kind="p_to_q")  # (..., Kq, Kp) broadcastable over *S
        mu_p  = np.asarray(ai.mu_p_field,  np.float32)                    # (*S,Kp)
        S_p   = sanitize_sigma(np.asarray(ai.sigma_p_field, np.float64))  # (*S,Kp,Kp)
        mu_qh = np.einsum("...qp,...p->...q",  A, mu_p, optimize=True).astype(np.float32, copy=False)   # (*S,Kq)
        S_qh  = np.einsum("...qp,...pr,...rq->...qr", A, S_p, A, optimize=True)                         # (*S,Kq,Kq)
        S_qh  = sanitize_sigma(S_qh).astype(np.float64, copy=False)
        qhat_mu.append(mu_qh)
        qhat_S.append(S_qh)

    for i_idx, ai in enumerate(agents):
        i_id    = int(ids[i_idx])
        mu_qhat = qhat_mu[i_idx]   # (*S,Kq)
        S_qhat  = qhat_S[i_idx]    # (*S,Kq,Kq)
        S       = mu_qhat.shape[:-1]  # base shape (*S,)

        K_masked = []  # list of (*S,) with +inf off-overlap
        K_grad   = []  # list of (*S,) with 0 off-overlap
        js       = []
        masks    = []  # list of (*S,) bool

        for j_idx, aj in enumerate(agents):
            if j_idx == i_idx:
                continue
            j_id = int(ids[j_idx])

            # Overlap mask (*S,) bool; broadcast if needed
            overlap = _joint_mask(ai, aj, tau=tau, as_vector=False)
            if overlap.shape != S:
                try:
                    overlap = np.broadcast_to(overlap, S)
                except Exception as e:
                    raise ValueError(
                        f"build_beta_q_model_gated_reversed: overlap mask {overlap.shape} "
                        f"not broadcastable to {S} for (i={i_id}, j={j_id})"
                    ) from e
            if not np.any(overlap):
                continue

            # Sender belief in i's Q-frame: Ω^q_ij q_j
            Om_q  = Omega(ctx, ai, aj, which="q")                       # (*S,Kq,Kq) or (Kq,Kq)
            mu_qj = np.asarray(aj.mu_q_field,  np.float32)              # (*S,Kq)
            S_qj  = sanitize_sigma(np.asarray(aj.sigma_q_field, np.float64))  # (*S,Kq,Kq)
            mu_t, S_t, _ = push_gaussian(
                mu_qj, S_qj, Om_q, eps=eps, return_inv=True, assume_orthogonal=False
            )  # (*S,Kq), (*S,Kq,Kq)

            # KL per pixel: KL( Φ̃_i p_i || Ω^q_ij q_j ) → (*S,)
            KLpx = kl_gaussian(mu_qhat, S_qhat, mu_t, S_t)
            KLpx = np.asarray(KLpx, np.float64)
            if KLpx.shape != S:
                if KLpx.shape[:len(S)] != S:
                    raise ValueError(
                        f"KLpx spatial dims {KLpx.shape} not compatible with base shape {S} "
                        f"for (i={i_id}, j={j_id})"
                    )
                if KLpx.ndim > len(S):
                    KLpx = KLpx.reshape(*S, -1).sum(axis=-1)

            # Masked fields for β construction / grads
            K_masked.append(np.where(overlap, KLpx, np.inf))
            K_grad.append(np.where(overlap, KLpx, 0.0).astype(np.float32, copy=False))
            js.append(j_id)
            masks.append(overlap)

        if not js:
            continue

        # Stack senders: (J, *S)
        K = np.stack(K_masked, axis=0)
        if K.shape[1:] != S:
            raise ValueError(f"Stacked KL maps shape {K.shape} wrong; expected (J, {S})")

        # logits = -KL/κ
        L = -K / kappa  # (J, *S)

        if mode_l in ("softmax", "sm", "normexp"):
            m   = np.max(L, axis=0, keepdims=True)             # (1, *S)
            ex  = np.exp(L - m) * np.isfinite(K)               # (J, *S), zero off-overlap
            den = np.sum(ex, axis=0, keepdims=True)            # (1, *S)
            den = np.maximum(den, tiny)
            Wj  = ex / den                                     # (J, *S)
            if not np.all(np.isfinite(Wj)):
                raise FloatingPointError("build_beta_q_model_gated_reversed: non-finite weights after softmax")
        elif mode_l in ("exp", "gated-exp", "exp-gated"):
            Wj  = np.exp(L) * np.isfinite(K)                   # (J, *S)
        else:
            m   = np.max(L, axis=0, keepdims=True)
            ex  = np.exp(L - m) * np.isfinite(K)
            den = np.sum(ex, axis=0, keepdims=True)
            den = np.maximum(den, tiny)
            Wj  = ex / den

        # Store per-edge maps (each (*S,))
        for s, j_id in enumerate(js):
            w_m = Wj[s]
            if masks[s] is not None:
                w_m = np.where(masks[s], w_m, 0.0)
            w_m = np.asarray(w_m, np.float32, order="C")
            if w_m.shape != S:
                if w_m.shape[:len(S)] != S:
                    raise ValueError(
                        f"β_q map shape {w_m.shape} not compatible with base shape {S} "
                        f"for (i={i_id}, j={j_id})"
                    )
                if w_m.ndim > len(S):
                    w_m = w_m.reshape(*S, -1).sum(axis=-1)
            if w_m.shape != S:
                raise ValueError(f"β_q map shape {w_m.shape} not equal to base shape {S}")

            beta_q[(i_id, int(j_id))] = w_m
            kl_q[(i_id, int(j_id))]   = K_grad[s]   # (*S,) float32

    return beta_q, kl_q




def build_beta_q_belief_to_model(ctx, agents, *, kappa: float, mode: str, eps: float, tau: float):
    """
    Pixelwise β_q for edges (i<-j) from:
        KL( p_i || Φ_i[ Ω^q_ij q_j ] )   evaluated in P_i per pixel.

    Returns:
      beta_q: dict[(i_id, j_id)] -> (*S,) float32
      kl_q:   dict[(i_id, j_id)] -> (*S,) float32  (KL per pixel; 0 outside overlap)
    """
    import numpy as np

    tiny  = 1e-12
    kappa = float(max(kappa, tiny))
    mode_l = (mode or "softmax").lower()

    beta_q, kl_q = {}, {}
    ids = _ids_of(agents)

    for i_idx, ai in enumerate(agents):
        i_id = int(ids[i_idx])

        # Receiver model fields in P_i (authoritative spatial shape)
        mu_pi = np.asarray(ai.mu_p_field,  np.float32)                     # (*S,Kp)
        S_pi  = sanitize_sigma(np.asarray(ai.sigma_p_field, np.float64))   # (*S,Kp,Kp)
        S     = mu_pi.shape[:-1]                                           # base shape *S

        # Encoder Φ_i : Q_i -> P_i  (broadcastable over *S)
        Phi_i = Phi(ctx, ai, kind="q_to_p")                                # (...,Kp,Kq)

        K_masked = []      # list of (*S,) float64; +inf off-overlap (for softmax)
        K_grad   = []      # list of (*S,) float32; 0 off-overlap (for grads)
        js       = []
        masks    = []      # list of (*S,) bool

        for j_idx, aj in enumerate(agents):
            if j_idx == i_idx:
                continue
            j_id = int(ids[j_idx])

            # Overlap in i's frame: (*S,) bool (broadcast if needed)
            overlap = _joint_mask(ai, aj, tau=tau, as_vector=False)
            if overlap.shape != S:
                try:
                    overlap = np.broadcast_to(overlap, S)
                except Exception as e:
                    raise ValueError(
                        f"build_beta_q_belief_to_model: overlap {overlap.shape} not broadcastable to {S} "
                        f"for (i={i_id}, j={j_id})"
                    ) from e
            if not np.any(overlap):
                continue

            # Push sender belief into i's Q-frame
            Om_q   = Omega(ctx, ai, aj, which="q")                          # (*S,Kq,Kq) or (Kq,Kq)
            mu_qj  = np.asarray(aj.mu_q_field,  np.float32)                 # (*S,Kq)
            S_qj   = sanitize_sigma(np.asarray(aj.sigma_q_field, np.float64))# (*S,Kq,Kq)
            mu_qj_t, S_qj_t, _ = push_gaussian(
                mu_qj, S_qj, Om_q, eps=eps, return_inv=True, assume_orthogonal=False
            )                                                                # (*S,Kq), (*S,Kq,Kq)

            # Map into P_i via Φ_i
            mu_hat_p = np.einsum("...pk,...k->...p",  Phi_i,  mu_qj_t, optimize=True)             # (*S,Kp)
            S_hat_p  = np.einsum("...pa,...ab,...pb->...pp", Phi_i, S_qj_t, Phi_i, optimize=True) # (*S,Kp,Kp)
            S_hat_p  = sanitize_sigma(S_hat_p).astype(np.float64, copy=False)

            # Per-pixel KL in P_i: KL(p_i || Φ_i[Ω q_j]) → (*S,)
            KLpx = kl_gaussian(mu_pi, S_pi, mu_hat_p, S_hat_p)
            KLpx = np.asarray(KLpx, np.float64)
            if KLpx.shape != S:
                if KLpx.shape[:len(S)] != S:
                    raise ValueError(
                        f"KLpx spatial dims {KLpx.shape} not compatible with base shape {S} "
                        f"for (i={i_id}, j={j_id})"
                    )
                if KLpx.ndim > len(S):
                    KLpx = KLpx.reshape(*S, -1).sum(axis=-1)

            # Mask for β construction / grads
            K_masked.append(np.where(overlap, KLpx, np.inf))
            K_grad.append(np.where(overlap, KLpx, 0.0).astype(np.float32, copy=False))
            js.append(j_id)
            masks.append(overlap)

        if not js:
            continue

        # Stack senders: (J, *S); logits = -KL/κ
        K = np.stack(K_masked, axis=0)
        if K.shape[1:] != S:
            raise ValueError(f"Stacked KL maps shape {K.shape} wrong; expected (J, {S})")
        L = -K / kappa

        if mode_l in ("softmax", "sm", "normexp"):
            m   = np.max(L, axis=0, keepdims=True)              # (1,*S)
            ex  = np.exp(L - m) * np.isfinite(K)                # (J,*S), zero off-overlap
            den = np.sum(ex, axis=0, keepdims=True)             # (1,*S)
            den = np.maximum(den, tiny)
            Wj  = ex / den                                      # (J,*S)
            if not np.all(np.isfinite(Wj)):
                raise FloatingPointError("build_beta_q_belief_to_model: non-finite weights after softmax")
        elif mode_l in ("exp", "gated-exp", "exp-gated"):
            Wj  = np.exp(L) * np.isfinite(K)                    # (J,*S)
        else:
            m   = np.max(L, axis=0, keepdims=True)
            ex  = np.exp(L - m) * np.isfinite(K)
            den = np.sum(ex, axis=0, keepdims=True)
            den = np.maximum(den, tiny)
            Wj  = ex / den

        # Store per-edge fields (each (*S,))
        for s, j_id in enumerate(js):
            w_m = Wj[s]
            if masks[s] is not None:
                w_m = np.where(masks[s], w_m, 0.0)
            w_m = np.asarray(w_m, np.float32, order="C")
            if w_m.shape != S:
                if w_m.shape[:len(S)] != S:
                    raise ValueError(
                        f"β_q map shape {w_m.shape} not compatible with base shape {S} "
                        f"for (i={i_id}, j={j_id})"
                    )
                if w_m.ndim > len(S):
                    w_m = w_m.reshape(*S, -1).sum(axis=-1)
            if w_m.shape != S:
                raise ValueError(f"β_q map shape {w_m.shape} not equal to base shape {S}")

            beta_q[(i_id, int(j_id))] = w_m
            kl_q[(i_id, int(j_id))]   = K_grad[s]  # (*S,) float32

    return beta_q, kl_q


# ---------- P-fiber builders ----------
def build_beta_p_belief_from_q(
    ctx,
    agents,
    *,
    kappa: float,
    mode: str = "softmax",
    eps: float = 1e-6,
    tau: float = 1e-6,
):
    """
    β_p(x) from KL( Φ_i[Ω^q_ij q_j] || p_i ) in P_i, per pixel.

    Returns:
      beta_p: dict[(i_id, j_id)] -> (*S,) float32
      kl_p:   dict[(i_id, j_id)] -> (*S,) float32  (KL per pixel; 0 outside overlap)
    """
    import numpy as np

    tiny  = 1e-12
    kappa = float(max(kappa, tiny))
    mode_l = (mode or "softmax").lower()
    if mode_l not in ("softmax", "sm", "normexp", "exp", "gated-exp", "exp-gated"):
        mode_l = "softmax"

    beta_p, kl_p = {}, {}
    ids = _ids_of(agents)

    for i_idx, ai in enumerate(agents):
        i_id = int(ids[i_idx])

        mu_pi = np.asarray(ai.mu_p_field,  np.float32)                    # (*S, Kp)
        S_pi  = sanitize_sigma(np.asarray(ai.sigma_p_field, np.float64))  # (*S, Kp, Kp)
        Phi_i = Phi(ctx, ai, kind="q_to_p")                               # (..., Kp, Kq)

        S = mu_pi.shape[:-1]  # base space shape *S

        logits_list  = []   # [(J,*S)]
        mask_list    = []   # [(J,*S) bool]
        js           = []   # [sender ids]
        kl_grad_list = []   # [(J,*S) float32]

        for j_idx, aj in enumerate(agents):
            if j_idx == i_idx:
                continue
            j_id = int(ids[j_idx])

            # Overlap in i's frame → (*S,) bool
            ov = _joint_mask(ai, aj, tau=tau, as_vector=False)
            ov = np.asarray(ov)
            if ov.shape != S:
                pad = (1,) * max(0, len(S) - ov.ndim)
                try:
                    ov = np.broadcast_to(ov.reshape(pad + ov.shape), S)
                except Exception as e:
                    raise ValueError(f"overlap mask {ov.shape} not broadcastable to {S}") from e
            overlap = (ov > 0)
            if not np.any(overlap):
                continue

            # Push q_j to i-frame, then map to P_i via Φ_i
            Om_q  = Omega(ctx, ai, aj, which="q")                              # (*S,Kq,Kq) or (Kq,Kq)
            mu_qj = np.asarray(aj.mu_q_field,  np.float32)                      # (*S,Kq)
            S_qj  = sanitize_sigma(np.asarray(aj.sigma_q_field, np.float64))    # (*S,Kq,Kq)

            mu_qj_t, S_qj_t, _ = push_gaussian(
                mu_qj, S_qj, Om_q, eps=eps, return_inv=True, assume_orthogonal=False
            )  # (*S,Kq), (*S,Kq,Kq)

            # Φ_i Σ Φ_i^T  (correct transpose!):
            #   mu_hat_p = Φ mu_q
            #   S_hat_p  = Φ Σ Φᵀ
            mu_hat_p = np.einsum("...pi,...i->...p",   Phi_i,  mu_qj_t, optimize=True)             # (*S,Kp)
            S_hat_p = np.einsum("...pi,...ij,...pj->...pp", Phi_i, S_qj_t, Phi_i)# (*S,Kp,Kp)
            S_hat_p  = sanitize_sigma(S_hat_p).astype(np.float64, copy=False)

            # Per-pixel KL in P_i: KL( Φ_i[Ω q_j] || p_i ) → (*S,)
            KLpx = kl_gaussian(mu_hat_p, S_hat_p, mu_pi, S_pi)
            KLpx = np.asarray(KLpx, np.float64)
            if KLpx.shape != S:
                if KLpx.shape[:len(S)] == S and KLpx.ndim > len(S):
                    KLpx = KLpx.reshape(S + (-1,)).sum(axis=-1)
                else:
                    raise ValueError(f"KLpx spatial dims {KLpx.shape} incompatible with {S} for (i={i_id}, j={j_id})")

            # logits with -inf where no overlap (so exp→0 there)
            logit = -KLpx / kappa
            logit = np.where(overlap, logit, -np.inf)

            logits_list.append(logit)
            mask_list.append(overlap)
            js.append(j_id)
            kl_grad_list.append(np.where(overlap, KLpx, 0.0).astype(np.float32, copy=False))

        if not js:
            continue

        # Stack senders: (J,*S)
        L = np.stack(logits_list, axis=0)                 # (J,*S)
        overlap_any = np.any(np.stack(mask_list, axis=0), axis=0)  # (*S,)

        # Sender weights
        if mode_l in ("softmax", "sm", "normexp"):
            # Mask-safe softmax: avoid (-inf)-(-inf) → NaN where no overlap          
            Wjx = _stable_softmax_over_senders(L)
            #Wjx = np.where(overlap_any[None, ...], Wjx, 0.0)
            if not np.all(np.isfinite(Wjx)):
                raise FloatingPointError("build_beta_p_belief_from_q: non-finite weights after softmax")
                
        elif mode_l in ("exp", "gated-exp", "exp-gated"):
            Wjx  = np.exp(L)                                         # (J,*S)
            Wjx  = np.where(overlap_any[None, ...], Wjx, 0.0)
        else:
            Lmax = np.max(L, axis=0, keepdims=True)
            exps = np.exp(L - Lmax)
            exps = np.where(overlap_any[None, ...], exps, 0.0)
            Z    = np.sum(exps, axis=0, keepdims=True)
            Z    = np.maximum(Z, tiny)
            Wjx  = exps / Z

        # Store per-edge fields
        for m, j_id in enumerate(js):
            w_m = Wjx[m]  # (*S,)
            w_m = np.where(mask_list[m], w_m, 0.0)
            w_m = np.asarray(w_m, np.float32, order="C")
            if w_m.shape != S:
                if w_m.shape[:len(S)] == S:
                    w_m = w_m.reshape(S + (-1,)).sum(axis=-1)
                else:
                    raise ValueError(f"β_p map shape {w_m.shape} not {S} for (i={i_id}, j={j_id})")

            beta_p[(i_id, int(j_id))] = w_m
            kl_p[(i_id, int(j_id))]   = kl_grad_list[m]

    return beta_p, kl_p





#============================================================================
#
#       ENTRY POINT AND WEIGHTS
#
#===========================================================================


def compute_edge_betas(ctx, agents):
    """
    Build per-edge attention for BOTH fibers with per-receiver normalization.

    Config keys:
      obs_beta_enable: bool
     
      obs_beta_kappa:  float
      obs_beta_mode:   "softmax" | "exp" | ...
      obs_beta_q_basis in {"peer_q","peer_q_rev","model_gated_q","belief_to_model","model_gated_q_rev"}
      obs_beta_p_basis in {"peer_p","obs_to_model","model_to_obs"}
      obs_beta_detach: bool  (if False, β-through-softmax grads are enabled via s_ij)
    """
    # Disabled?
    if not bool(cfg_get(ctx, "obs_beta_enable", True)):
        setattr(ctx, "_edge_beta_q", None)
        setattr(ctx, "_edge_beta_p", None)
        setattr(ctx, "_edge_kl_q",   {})
        setattr(ctx, "_edge_kl_p",   {})
        setattr(ctx, "_edge_beta_cfg", {
            "q": {"kappa": 1.0, "mode": "softmax"},
            "p": {"kappa": 1.0, "mode": "softmax"},
            "detach": True,   # ✅ canonical key
        })
        return

   
    kappa  = float(cfg_get(ctx, "obs_beta_kappa", 1.0))
    mode   = str(cfg_get(ctx, "obs_beta_mode", "softmax")).lower()
    eps    = float(cfg_get(ctx, "eps", 1e-8))
    tau    = float(cfg_get(ctx, "support_tau", 1e-6))
    detach = bool(cfg_get(ctx, "obs_beta_detach", False))

    q_basis = str(cfg_get(ctx, "obs_beta_q_basis", "model_gated_q")).lower()
    p_basis = str(cfg_get(ctx, "obs_beta_p_basis", "peer_p")).lower()

    # Builders (some return β; some return (β, KL))
    q_builders = {
        "peer_q":            build_beta_q_peer,        
        "model_gated_q":     build_beta_q_model_gated,   # returns (β, KL)
        "belief_to_model":   build_beta_q_belief_to_model,
        "model_gated_q_rev": build_beta_q_model_gated_reversed,
    }
    p_builders = {
        "peer_p":            build_beta_p_peer,
        "obs_to_model":      build_beta_p_belief_from_q, # returns (β, KL)
        
    }

    if q_basis not in q_builders:
        raise ValueError(f"Unknown obs_beta_q_basis={q_basis}")
    if p_basis not in p_builders:
        raise ValueError(f"Unknown obs_beta_p_basis={p_basis}")

    # Q-side
    out_q = q_builders[q_basis](ctx, agents, kappa=kappa, mode=mode, eps=eps, tau=tau)
    beta_q, kl_q = (out_q if (isinstance(out_q, tuple) and len(out_q) == 2) else (out_q, {}))

    # P-side
    out_p = p_builders[p_basis](ctx, agents, kappa=kappa, mode=mode, eps=eps, tau=tau)
    beta_p, kl_p = (out_p if (isinstance(out_p, tuple) and len(out_p) == 2) else (out_p, {}))

    # Normalize empty → None for convenience
    beta_q = beta_q if beta_q else None
    beta_p = beta_p if beta_p else None

    # Stash
    setattr(ctx, "_edge_beta_q", beta_q)
    setattr(ctx, "_edge_beta_p", beta_p)
    setattr(ctx, "_edge_kl_q",   kl_q or {})
    setattr(ctx, "_edge_kl_p",   kl_p or {})
    setattr(ctx, "_edge_beta_cfg", {
        "q": {"kappa": float(kappa), "mode": str(mode)},
        "p": {"kappa": float(kappa), "mode": str(mode)},
        "detach": bool(detach),  # ✅ canonical key
    })

 

def beta_effective_weight(ctx, i_id: int, j_id: int, *, which: str, joint_mask, allow_exp: bool = True):
    """
    Returns s_ij(x) for weighting ∂KL/∂{μ,Σ,φ}:

      softmax: s = β_ij * [1 - (KL_ij - KL_bar)/kappa],  KL_bar = Σ_r β_ir KL_ir
      exp:     s = β_ij * [1 - KL_ij/kappa]

    Works for N-D spatial grids. Requires:
      ctx._edge_beta_{q,p}[(i,j)] -> (*S,)
      ctx._edge_kl_{q,p}[(i,j)]   -> (*S,)
      ctx._edge_beta_cfg = { which: {kappa, mode}, detach: bool }
    """
    import numpy as np

    if which not in ("q", "p"):
        raise ValueError(f"beta_effective_weight: which must be 'q' or 'p', got {which!r}")

    beta_map = getattr(ctx, "_edge_beta_q" if which == "q" else "_edge_beta_p", {}) or {}
    kl_map   = getattr(ctx, "_edge_kl_q"   if which == "q" else "_edge_kl_p", {}) or {}
    cfg      = getattr(ctx, "_edge_beta_cfg", {}) or {}
    sub      = cfg.get(which, {}) or {}
    kappa    = float(max(float(sub.get("kappa", 1.0)), 1e-12))
    mode     = str(sub.get("mode", "softmax")).lower()
    detach   = bool(cfg.get("detach", True))

    # Fetch β_ij
    beta_ij = beta_map.get((i_id, j_id), None)
    if beta_ij is None:
        # try to infer shape from the mask to return zeros of right shape
        m = np.asarray(joint_mask)
        return np.zeros(m.shape, np.float32, order="C")
    beta_ij = np.asarray(beta_ij, np.float32)
    S = beta_ij.shape  # spatial shape (*S,)

    # Broadcast mask to S and apply to β
    m = np.asarray(joint_mask)
    if m.shape != S:
        pad = (1,) * max(0, len(S) - m.ndim)
        try:
            m = np.broadcast_to(m.reshape(pad + m.shape), S)
        except Exception as e:
            raise ValueError(f"beta_effective_weight: joint_mask shape {m.shape} not broadcastable to {S}") from e
    m_f32 = m.astype(np.float32, copy=False)
    beta_ij = beta_ij * m_f32  # support gating

    if detach:
        return beta_ij

    # Need KL_ij for beta-through-softmax grads
    KL_ij = kl_map.get((i_id, j_id), None)
    if KL_ij is None:
        raise RuntimeError(f"beta_effective_weight: missing KL map for edge {(i_id, j_id)} and which='{which}'")
    KL_ij = np.asarray(KL_ij, np.float32)
    if KL_ij.shape != S:
        raise ValueError(f"beta_effective_weight: KL shape {KL_ij.shape} != {S} for edge {(i_id, j_id)}")

    if mode in ("softmax", "sm", "normexp"):
        # KL_bar = Σ_r β_ir KL_ir over all senders r to receiver i
        KL_bar = np.zeros(S, np.float32)
        for (ii, jj), b in beta_map.items():
            if ii != i_id:
                continue
            b  = np.asarray(b,  np.float32)
            Kr = np.asarray(kl_map.get((ii, jj), None), np.float32)
            if b.shape != S or Kr.shape != S:
                raise ValueError("beta_effective_weight: inconsistent β/KL field shapes")
            KL_bar += (b * Kr)
        s = beta_ij * (1.0 - (KL_ij - KL_bar) / kappa)

    elif allow_exp and mode in ("exp", "gated-exp", "exp-gated"):
        s = beta_ij * (1.0 - KL_ij / kappa)

    else:
        # default to softmax behavior
        KL_bar = np.zeros(S, np.float32)
        for (ii, jj), b in beta_map.items():
            if ii != i_id:
                continue
            KL_bar += (np.asarray(b, np.float32) * np.asarray(kl_map.get((ii, jj), None), np.float32))
        s = beta_ij * (1.0 - (KL_ij - KL_bar) / kappa)

    return s.astype(np.float32, copy=False)












# beta.py
def NEW_compute_edge_betas(ctx, agents, *, which="q"):
    """
    Populates for each ordered edge (i<-j):
      ctx._edge_kl1[(which,i,j)]   = KL1_ij map   (*S,)
      ctx._edge_kl2[(which,i,j)]   = KL2_ij map   (*S,)
      ctx._edge_beta[(which,i,j)]  = beta_ij map  (*S,)
    KL1 := KL(q_i || Ω^q_{ij} q_j)       (objective KL)
    KL2 := KL(Ω^q_{ij} q_j || Φ̃_i p_i)  (β-defining KL; change if you pick another basis)
    """
    import numpy as np
    from runtime_context import cfg_get

    kappa  = float(cfg_get(ctx, f"obs_beta_kappa_{which}", 1.0))
    mode   = str(cfg_get(ctx, f"obs_beta_mode_{which}", "exp")).lower()
    eps    = float(cfg_get(ctx, "obs_beta_eps", 1e-12))

    # ensure dicts
    if not hasattr(ctx, "_edge_kl1"):  ctx._edge_kl1  = {}
    if not hasattr(ctx, "_edge_kl2"):  ctx._edge_kl2  = {}
    if not hasattr(ctx, "_edge_beta"): ctx._edge_beta = {}

    # 1) First pass: compute and cache KL1, KL2 for all (i<-j)
    per_i = {}  # i -> list[(j, KL2_ij)]
    for ai in agents:
        i = int(getattr(ai, "id", -1))
        per_i[i] = []
        for aj in agents:
            if ai is aj:
                continue
            j = int(getattr(aj, "id", -1))

            # KL1 = KL(q_i || Ω q_j)
            KL1_ij = kl_map_qi_vs_Omega_qj(ctx, ai, aj).astype(np.float32, copy=False)  # (*S,)

            # KL2 = KL(Ω q_j || Φ̃_i p_i)  (change here if you choose another β basis)
            KL2_ij = kl_map_Omega_qj_vs_PhiT_pi(ctx, ai, aj).astype(np.float32, copy=False)  # (*S,)

            ctx._edge_kl1[(which, i, j)] = KL1_ij
            ctx._edge_kl2[(which, i, j)] = KL2_ij
            per_i[i].append((j, KL2_ij))

    # 2) Build β from KL2
    if mode == "exp":
        for ai in agents:
            i = int(getattr(ai, "id", -1))
            for aj in agents:
                if ai is aj:
                    continue
                j = int(getattr(aj, "id", -1))
                KL2_ij = ctx._edge_kl2[(which, i, j)]
                beta_ij = np.exp(-KL2_ij / max(kappa, eps)).astype(np.float32, copy=False)
                ctx._edge_beta[(which, i, j)] = beta_ij

    elif mode == "softmax":
        # softmax over senders j for each fixed receiver i, per-pixel
        for i, lst in per_i.items():
            if not lst:
                continue
            # logits = -KL2/kappa
            logits = [(-KL2 / max(kappa, eps)).astype(np.float32, copy=False) for (_, KL2) in lst]  # list of (*S,)
            # stable softmax: subtract per-pixel max
            m = np.maximum.reduce(logits)                           # (*S,)
            exps = [np.exp(x - m) for x in logits]                  # list of (*S,)
            denom = np.zeros_like(exps[0]);  [denom.__iadd__(e) for e in exps]
            denom = np.maximum(denom, eps)
            for (e, (j, _)) in zip(exps, lst):
                beta_ij = (e / denom).astype(np.float32, copy=False)  # (*S,)
                ctx._edge_beta[(which, i, j)] = beta_ij
    else:
        raise ValueError(f"unknown obs_beta_mode_{which}={mode!r}")

    # 3) Optional: zero β where there is no support overlap (prevents stray grads)
    if hasattr(ctx, "zero_beta_outside_overlap") and ctx.zero_beta_outside_overlap:
        for ai in agents:
            i = int(getattr(ai, "id", -1))
            mi = np.asarray(getattr(ai, "mask"), np.float32)
            for aj in agents:
                if ai is aj:
                    continue
                j = int(getattr(aj, "id", -1))
                mj = np.asarray(getattr(aj, "mask"), np.float32)
                joint = (mi > float(cfg_get(ctx, "support_tau", 1e-6))) & (mj > float(cfg_get(ctx, "support_tau", 1e-6)))
                if not joint.shape == ctx._edge_beta[(which, i, j)].shape:
                    # broadcast if needed
                    joint = np.broadcast_to(joint, ctx._edge_beta[(which, i, j)].shape)
                beta_ij = ctx._edge_beta[(which, i, j)]
                beta_ij = np.where(joint, beta_ij, 0.0).astype(np.float32, copy=False)
                ctx._edge_beta[(which, i, j)] = beta_ij



def kl_map_qi_vs_Omega_qj(ctx, ai, aj, *, eps=1e-8):
    """Per-pixel KL(q_i || Ω^q_ij q_j) in Q_i frame."""
    mu_i = np.asarray(ai.mu_q_field,  np.float32)
    S_i  = sanitize_sigma(np.asarray(ai.sigma_q_field, np.float64))
    Om_q = Omega(ctx, ai, aj, which="q")
    mu_j = np.asarray(aj.mu_q_field,  np.float32)
    S_j  = sanitize_sigma(np.asarray(aj.sigma_q_field, np.float64))
    mu_t, S_t, _ = push_gaussian(mu_j, S_j, Om_q, eps=eps, return_inv=True, assume_orthogonal=False)
    return kl_gaussian(mu_i, S_i, mu_t, S_t).astype(np.float32, copy=False)   # (*S,)

def kl_map_Omega_qj_vs_PhiT_pi(ctx, ai, aj, *, eps=1e-8):
    """Per-pixel KL(Ω^q_ij q_j || Φ̃_i p_i) in Q_i frame."""
    Om_q = Omega(ctx, ai, aj, which="q")
    mu_qj = np.asarray(aj.mu_q_field,  np.float32)
    S_qj  = sanitize_sigma(np.asarray(aj.sigma_q_field, np.float64))
    mu_t, S_t, _ = push_gaussian(mu_qj, S_qj, Om_q, eps=eps, return_inv=True, assume_orthogonal=False)
    Phi_i = Phi(ctx, ai, kind="p_to_q")
    mu_pi = np.asarray(ai.mu_p_field,  np.float32)
    S_pi  = sanitize_sigma(np.asarray(ai.sigma_p_field, np.float64))
    mu_qhat = np.einsum("...qp,...p->...q", Phi_i, mu_pi)
    S_qhat  = np.einsum("...qp,...pr,...rq->...qr", Phi_i, S_pi, Phi_i)
    S_qhat  = sanitize_sigma(S_qhat)
    return kl_gaussian(mu_t, S_t, mu_qhat, S_qhat).astype(np.float32, copy=False)
