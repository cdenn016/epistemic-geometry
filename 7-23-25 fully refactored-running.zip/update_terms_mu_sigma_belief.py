# -*- coding: utf-8 -*-
"""
Created on Wed Jul 23 06:37:51 2025

@author: chris and christine
"""


import numpy as np
import config
from numerical_utils import sanitize_sigma, safe_inv
from natural_gradient_utils import apply_natural_gradient_batch




#==============================================================================
#
#                    APPLY NATURAL GRADIENT
#
#==============================================================================


def accumulate_mu_sigma_gradient_belief(agent_i, agents, params):
    """
    Accumulate ∇μ_q and ∇Σ_q from all belief energy terms:
      - Self:     KL(q_i || Φ̃ p_i)
      - Feedback: KL(p_i || Φ q_i)
      - Alignment: KL(q_i || Ω_ij q_j)   and   KL(q_k || Ω_kj q_j) for i == j

    Stores total gradient into:
        agent_i.grad_mu_q
        agent_i.grad_sigma_q
    """
    

    # Compute total Euclidean gradient
    dmu, dsigma = compute_mu_sigma_gradient_belief_euclidean(agent_i, agents, params)

    # Project into Fisher-natural gradient directions for multivariate Gaussians
    delta_mu, delta_sigma = apply_natural_gradient_batch(
        agent_i.mu_q_field,
        agent_i.sigma_q_field,
        dmu,
        dsigma,
        mask=agent_i.mask,
    )

    agent_i.grad_mu_q_field    += delta_mu
    agent_i.grad_sigma_q_field += delta_sigma





#==============================================================================
#
#                    ACCUMULATE FIELD GRADS EUCLIDEAN
#
#==============================================================================

def compute_mu_sigma_gradient_belief_euclidean(agent_i, agents, params):
    """
    Accumulate ∇_μ and ∇_Σ belief gradients for agent_i from:
    - Self-energy:     KL(q_i ‖ Φ̃ p_i)
    - Feedback:        KL(p_i ‖ Φ q_i)
    - Alignment (μ_i): KL(q_i ‖ Ω_ij q_j)
    - Alignment (μ_j): KL(q_k ‖ Ω_kj q_j) if i == j

    Returns:
        dmu_q:    (..., K_q)
        dsigma_q: (..., K_q, K_q)
    """
    eps   = config.support_cutoff_eps
    alpha = params.get("alpha", config.alpha)
    beta  = params.get("beta", config.beta)
    lambd = params.get("lambda", config.feedback_weight)

    mu_q    = agent_i.mu_q_field
    sigma_q = agent_i.sigma_q_field
    mu_p    = agent_i.mu_p_field
    sigma_p = agent_i.sigma_p_field
    Phi         = agent_i.bundle_morphism_q_to_p
    Phi_tilde   = agent_i.bundle_morphism_p_to_q

    dmu_self    = grad_self_energy_mu_q(mu_q, sigma_q, mu_p, sigma_p, Phi_tilde, eps=eps)
    dsigma_self = grad_self_energy_sigma_q(mu_q, sigma_q, mu_p, sigma_p, Phi_tilde, eps=eps)

    dmu_fb    = grad_feedback_mu_q(mu_q, sigma_q, mu_p, Phi, eps=eps)
    dsigma_fb = grad_feedback_sigma_q(mu_q, sigma_q, mu_p, sigma_p, Phi, eps=eps)

    # Alignment terms where agent_i is the *source* q_i
    dmu_align = 0
    dsigma_align = 0
    for neighbor in agent_i.neighbors:
        agent_j = agents[neighbor["id"]]
        Omega_ij = agent_i.Omega @ agent_j.Omega_inv

        dmu_align += grad_belief_align_mu_i(
            mu_q, sigma_q, agent_j.mu_q_field, agent_j.sigma_q_field, Omega_ij, eps=eps
        )
        dsigma_align += grad_belief_align_sigma_i(
            mu_q, sigma_q, agent_j.mu_q_field, agent_j.sigma_q_field, Omega_ij, eps=eps
        )

    # Alignment terms where agent_i is the *target* q_j in q_k ‖ Ω_kj q_j
    dmu_align_rev = 0
    dsigma_align_rev = 0
    for agent_k in agents:
        for neighbor in agent_k.neighbors:
            if neighbor.get("id") == agent_i.id:
                Omega_kj = agent_k.Omega @ agent_i.Omega_inv

                dmu_align_rev += grad_belief_align_mu_j(
                    agent_k.mu_q_field, agent_k.sigma_q_field,
                    mu_q, sigma_q, Omega_kj, eps=eps
                )
                dsigma_align_rev += grad_belief_align_sigma_j(
                    agent_k.mu_q_field, agent_k.sigma_q_field,
                    mu_q, sigma_q, Omega_kj, eps=eps
                )

    # Combine all
    dmu_total = (
        alpha * dmu_self +
        lambd * dmu_fb +
        beta * (dmu_align + dmu_align_rev)
    )

    dsigma_total = (
        alpha * dsigma_self +
        lambd * dsigma_fb +
        beta * (dsigma_align + dsigma_align_rev)
    )

    return dmu_total, dsigma_total





#==============================================================================
#
#                    FEEDBACK TERMS
#
#==============================================================================



def grad_feedback_mu_q(mu_q_field, sigma_q_field, mu_p_field, Phi, eps=1e-8):
    """
    Compute ∂/∂μ_q D_KL(p || Φ q) over a spatial field (H, W, K_q).
    
    Args:
        mu_q_field    : (..., K_q)
        sigma_q_field : (..., K_q, K_q)
        mu_p_field    : (..., K_p)
        Phi           : (..., K_p, K_q)
        eps           : regularization for inversion
        
    Returns:
        grad_mu_q     : (..., K_q), gradient field
    """
    # Compute pushforward mean: Φ μ_q
    mu_q_push = np.einsum("...ij,...j->...i", Phi, mu_q_field)  # (..., K_p)

    # Compute pushforward covariance: Φ Σ_q Φ^T
    sigma_push = np.einsum("...ik,...kl,...jl->...ij", Phi, sigma_q_field, Phi)


    # Safe inverse
    sigma_push_inv = safe_inv(sigma_push, eps=eps)  # (..., K_p, K_p)

    # Δμ = μ_p − Φ μ_q
    delta_mu = mu_p_field - mu_q_push  # (..., K_p)

    # Compute gradient: - Φ^T (Φ Σ_q Φ^T)^{-1} (μ_p - Φ μ_q)
    tmp = np.einsum("...ij,...j->...i", sigma_push_inv, delta_mu)  # (..., K_p)
    grad_mu_q = -np.einsum("...ji,...j->...i", Phi, tmp)  # (..., K_q)

    return grad_mu_q



def grad_feedback_sigma_q(mu_q_field, sigma_q_field, mu_p_field,
                               sigma_p_field, Phi, eps=1e-8):
    """
    Compute ∂/∂Σ_q D_KL(p || Φ q) over spatial field (H, W, K_q, K_q)

    Args:
        mu_q_field     : (..., K_q)
        sigma_q_field  : (..., K_q, K_q)
        mu_p_field     : (..., K_p)
        sigma_p_field  : (..., K_p, K_p)
        Phi            : (..., K_p, K_q)
        eps            : regularization epsilon

    Returns:
        grad_sigma_q   : (..., K_q, K_q)
    """
    # Φ μ_q
    mu_q_push = np.einsum("...ij,...j->...i", Phi, mu_q_field)  # (..., K_p)

    # Pushforwarded covariance: Φ Σ_q Φ^T
    Phi_T = np.swapaxes(Phi, -1, -2)  # (..., K_q, K_p)
    sigma_q_push = np.einsum("...ik,...kl,...jl->...ij", Phi, sigma_q_field, Phi)

    sigma_q_push_inv = safe_inv(sigma_q_push, eps=eps)

    # Δμ = μ_p - Φ μ_q
    delta_mu = mu_p_field - mu_q_push  # (..., K_p)

    # Mahalanobis term: A = Δμ Δμᵀ
    A = np.einsum("...i,...j->...ij", delta_mu, delta_mu)  # (..., K_p, K_p)

    # Terms
    inv_term     = sigma_q_push_inv
    mahal_term   = np.einsum("...ik,...kl,...lj->...ij",
                             sigma_q_push_inv, A, sigma_q_push_inv)
    trace_term   = np.einsum("...ik,...kl,...lj->...ij",
                             sigma_q_push_inv, sigma_p_field, sigma_q_push_inv)

    # Combine: M = [inv - mahal - trace]
    M = inv_term - mahal_term - trace_term  # (..., K_p, K_p)

    # Final gradient: Φᵀ M Φ
    grad_sigma_q = 0.5 * np.einsum("...ki,...kl,...lj->...ij", Phi, M, Phi)


    return grad_sigma_q






#==============================================================================
#
#                    SELF-ENERGY TERMS
#
#==============================================================================

def grad_self_energy_mu_q(mu_q_field, sigma_q_field, mu_p_field, sigma_p_field, Phi_tilde, eps=1e-8):
    """
    Compute ∂/∂μ_q D_KL(q || Φ̃ p) over spatial field (H, W, K_q)
    """
    # Pushforwarded mean: Φ̃ μ_p
    mu_p_push = np.einsum("...ij,...j->...i", Phi_tilde, mu_p_field)  # (..., K_q)

    # Pushforwarded covariance: Φ̃ Σ_p Φ̃^T
    sigma_p_push = np.einsum("...iq,...qr,...jr->...ij", Phi_tilde, sigma_p_field, Phi_tilde)

    sigma_p_push_inv = safe_inv(sigma_p_push, eps=eps)

    # Δμ = μ_q − Φ̃ μ_p
    delta_mu = mu_q_field - mu_p_push

    # Gradient
    grad_mu_q = np.einsum("...ij,...j->...i", sigma_p_push_inv, delta_mu)

    return grad_mu_q

def grad_self_energy_sigma_q(mu_q_field, sigma_q_field, mu_p_field, sigma_p_field, Phi_tilde, eps=1e-8):
    """
    Compute ∂/∂Σ_q D_KL(q || Φ̃ p) over spatial field (H, W, K_q, K_q)
    """
    # Pushforwarded covariance: Φ̃ Σ_p Φ̃^T
    sigma_p_push = np.einsum("...iq,...qr,...jr->...ij", Phi_tilde, sigma_p_field, Phi_tilde)

    sigma_p_push_inv = safe_inv(sigma_p_push, eps=eps)  # (..., K_q, K_q)

    return 0.5 * sigma_p_push_inv



#==============================================================================
#
#                    ALIGNMENT TERMS - NOT VALIDATED
#
#==============================================================================


def grad_belief_align_mu_i(mu_i, sigma_i, mu_j, sigma_j, Omega_ij, eps=1e-8):
    """
    ∇_{μ_i} D_KL(q_i || Ω q_j) = (Ω Σ_j Ωᵀ)^(-1) (μ_i − Ω μ_j)
    """
    # ── Shape validation ─────────────────────────────────────────────
    if Omega_ij.ndim != 4:
        raise ValueError(f"Expected Omega_ij shape (..., K_q, K_q), got {Omega_ij.shape}")
    if sigma_j.shape != Omega_ij.shape:
        raise ValueError(f"Shape mismatch: sigma_j {sigma_j.shape} vs Omega_ij {Omega_ij.shape}")
    if mu_i.shape != mu_j.shape or mu_i.shape != Omega_ij.shape[:-1]:
        raise ValueError(f"mu_i, mu_j shape mismatch: mu_i {mu_i.shape}, mu_j {mu_j.shape}, expected {..., config.K_q}")

    # ── Transport mean: Ω μ_j ────────────────────────────────────────
    mu_j_t = np.einsum("...ij,...j->...i", Omega_ij, mu_j)
    delta_mu = mu_i - mu_j_t

    # ── Transport covariance: Ω Σ_j Ωᵀ ───────────────────────────────
    Omega_T = np.swapaxes(Omega_ij, -1, -2)
    sigma_j_t = np.matmul(Omega_ij, np.matmul(sigma_j, Omega_T))  # safer than einsum
    sigma_j_t = sanitize_sigma(sigma_j_t, eps=eps)
    sigma_inv = safe_inv(sigma_j_t, eps=eps)

    # ── Final gradient: Σ⁻¹ Δμ ───────────────────────────────────────
    grad = np.einsum("...ij,...j->...i", sigma_inv, delta_mu)
    return grad


def grad_belief_align_sigma_i(mu_i, sigma_i, mu_j, sigma_j, Omega_ij, eps=1e-8):
    """
    ∇_{Σ_i} D_KL(q_i || Ω q_j) = ½ [ (Ω Σ_j Ωᵀ)^(-1) − Σ_i^(-1) ]
    """
    Omega_T = np.swapaxes(Omega_ij, -1, -2)  # shape (..., K, K)
    sigma_j_t = np.einsum("...ik,...kl,...lj->...ij", Omega_ij, sigma_j, Omega_T)  # Ω Σ_j Ωᵀ

    sigma_j_t = sanitize_sigma(sigma_j_t, eps=eps)
    inv_j = safe_inv(sigma_j_t, eps=eps)
    inv_i = safe_inv(sigma_i, eps=eps)

    grad = 0.5 * (inv_j - inv_i)
    return grad

def grad_belief_align_mu_j(mu_i, sigma_i, mu_j, sigma_j, Omega_ij, eps=1e-8):
    """
    ∇_{μ_j} D_KL(q_i || Ω q_j) = -Ωᵀ (Ω Σ_j Ωᵀ)^(-1) (μ_i − Ω μ_j)
    """
    mu_j_t = np.einsum("...ij,...j->...i", Omega_ij, mu_j)
    delta_mu = mu_i - mu_j_t

    # Fix: change last einsum index from ...jl to ...lj to match the axes
    Omega_T = np.swapaxes(Omega_ij, -1, -2)
    sigma_j_t = np.einsum("...ik,...kl,...lj->...ij", Omega_ij, sigma_j, Omega_T)

    sigma_j_t = sanitize_sigma(sigma_j_t, eps=eps)
    sigma_inv = safe_inv(sigma_j_t, eps=eps)

    tmp = np.einsum("...ij,...j->...i", sigma_inv, delta_mu)
    grad = -np.einsum("...ji,...i->...j", Omega_ij, tmp)
    return grad


def grad_belief_align_sigma_j(mu_i, sigma_i, mu_j, sigma_j, Omega_ij, eps=1e-8):
    """
    ∇_{Σ_j} D_KL(q_i || Ω q_j)
    = ½ Ωᵀ [ M⁻¹ Δμ Δμᵀ M⁻¹ − M⁻¹ Σ_i M⁻¹ − M⁻¹ ] Ω
    where M = Ω Σ_j Ωᵀ
    """
    mu_j_t = np.einsum("...ij,...j->...i", Omega_ij, mu_j)
    delta_mu = mu_i - mu_j_t

    Omega_T = np.swapaxes(Omega_ij, -1, -2)  # <-- Fix here
    sigma_j_t = np.einsum("...ik,...kl,...lj->...ij", Omega_ij, sigma_j, Omega_T)
    sigma_j_t = sanitize_sigma(sigma_j_t, eps=eps)
    sigma_inv = safe_inv(sigma_j_t, eps=eps)

    # First term: M⁻¹ Δμ Δμᵀ M⁻¹
    tmp = np.einsum("...i,...j->...ij", delta_mu, delta_mu)
    term1 = np.einsum("...ik,...kl,...lj->...ij", sigma_inv, tmp, sigma_inv)

    # Second term: M⁻¹ Σ_i M⁻¹
    term2 = np.einsum("...ik,...kl,...lj->...ij", sigma_inv, sigma_i, sigma_inv)

    # Third term: M⁻¹
    term3 = sigma_inv

    # Combine and project back
    diff = term1 - term2 - term3
    grad = 0.5 * np.einsum("...ik,...kl,...lj->...ij", Omega_T, diff, Omega_ij)
    return grad


