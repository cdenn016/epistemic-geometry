# -*- coding: utf-8 -*-
"""
Created on Wed Jul 23 09:00:50 2025

@author: chris and christine
"""
# File: update_phi_terms.py
from update_terms_phi_belief import grad_kl_wrt_phi_j
import config
import numpy as np
# File: update_field_terms.py (or wherever your field updates live)
import config
from update_terms_mu_sigma_belief import (
    grad_self_energy_mu_q,
    grad_feedback_mu_q,
    grad_belief_align_mu_i,
    grad_self_energy_sigma_q,
    grad_feedback_sigma_q,
    grad_belief_align_sigma_i,
)
from utils.linalg import sanitize_sigma


def compute_total_gradient_belief(agent_i, agents, params):
    """
    Accumulate ∇_μ and ∇_Σ belief gradients for agent_i from:
    - Self-energy:     KL(q_i ‖ Φ̃ p_i)
    - Feedback:        KL(p_i ‖ Φ q_i)
    - Alignment (μ_i): KL(q_i ‖ Ω_ij q_j)
    - Alignment (μ_j): KL(q_k ‖ Ω_kj q_j) if i == j

    Returns:
        dmu_q:    (..., K_q)
        dsigma_q: (..., K_q, K_q)
    """
    eps   = config.support_cutoff_eps
    alpha = params.get("alpha", config.alpha)
    beta  = params.get("beta", config.beta)
    lambd = params.get("lambda", config.lambd)

    mu_q    = agent_i.mu_q_field
    sigma_q = agent_i.sigma_q_field
    mu_p    = agent_i.mu_p_field
    sigma_p = agent_i.sigma_p_field
    Phi         = agent_i.bundle_morphism_q_to_p
    Phi_tilde   = agent_i.bundle_morphism_p_to_q

    dmu_self    = grad_self_energy_mu_q(mu_q, sigma_q, mu_p, sigma_p, Phi_tilde, eps=eps)
    dsigma_self = grad_self_energy_sigma_q(mu_q, sigma_q, mu_p, sigma_p, Phi_tilde, eps=eps)

    dmu_fb    = grad_feedback_mu_q(mu_q, sigma_q, mu_p, Phi, eps=eps)
    dsigma_fb = grad_feedback_sigma_q(mu_q, sigma_q, mu_p, sigma_p, Phi, eps=eps)

    # Alignment terms where agent_i is the *source* q_i
    dmu_align = 0
    dsigma_align = 0
    for neighbor in agent_i.neighbors:
        agent_j = agents[neighbor["id"]]
        Omega_ij = neighbor["Omega_ij"]
        dmu_align += grad_belief_align_mu_i(
            mu_q, sigma_q, agent_j.mu_q_field, agent_j.sigma_q_field, Omega_ij, eps=eps
        )
        dsigma_align += grad_belief_align_sigma_i(
            mu_q, sigma_q, agent_j.mu_q_field, agent_j.sigma_q_field, Omega_ij, eps=eps
        )

    # Alignment terms where agent_i is the *target* q_j in q_k ‖ Ω_kj q_j
    dmu_align_rev = 0
    dsigma_align_rev = 0
    for agent_k in agents:
        for neighbor in agent_k.neighbors:
            if neighbor.get("id") == agent_i.id:
                Omega_kj = neighbor["Omega_ij"]
                dmu_align_rev += grad_belief_align_mu_j(
                    agent_k.mu_q_field, agent_k.sigma_q_field,
                    mu_q, sigma_q, Omega_kj, eps=eps
                )
                dsigma_align_rev += grad_belief_align_sigma_j(
                    agent_k.mu_q_field, agent_k.sigma_q_field,
                    mu_q, sigma_q, Omega_kj, eps=eps
                )

    # Combine all
    dmu_total = (
        alpha * dmu_self +
        lambd * dmu_fb +
        beta * (dmu_align + dmu_align_rev)
    )

    dsigma_total = (
        alpha * dsigma_self +
        lambd * dsigma_fb +
        beta * (dsigma_align + dsigma_align_rev)
    )

    return dmu_total, dsigma_total


# File: update_phi_terms.py
from update_terms_phi_belief import grad_kl_wrt_phi_i


def compute_total_gradient_phi_i(agent_i, agents, params):
    """
    Compute total ∇_{φ_i} KL(q_i ‖ Ω_ij q_j) over all neighbors j.

    Returns:
        dphi_i: (..., d)
    """
    beta = params.get("beta", config.beta)
    if beta <= 0:
        return np.zeros_like(agent_i.phi)

    mu_i    = agent_i.mu_q_field
    sigma_i = agent_i.sigma_q_field
    d       = agent_i.phi.shape[-1]
    dphi_i  = np.zeros_like(agent_i.phi)

    for neighbor in agent_i.neighbors:
        agent_j = agents[neighbor["id"]]
        Omega_ij     = neighbor["Omega_ij"]
        generators_q = neighbor["generators_q"]

        dphi_i += grad_kl_wrt_phi_i(
            mu_i, sigma_i,
            agent_j.mu_q_field, agent_j.sigma_q_field,
            Omega_ij, generators_q,
            eps=config.support_cutoff_eps
        )

    return beta * dphi_i




def compute_total_gradient_phi_j(agent_j, agents, params):
    """
    Compute total ∇_{φ_j} KL(q_i ‖ Ω_ij q_j) over all agents i that depend on φ_j.
    
    This is the φ_j counterpart to compute_total_gradient_phi.

    Returns:
        dphi_j: (..., d)
    """
    beta = params.get("beta", config.beta)
    if beta <= 0:
        return np.zeros_like(agent_j.phi)

    mu_j = agent_j.mu_q_field
    sigma_j = agent_j.sigma_q_field
    exp_phi_j = agent_j._exp_phi        # (H, W, K, K)
    exp_neg_phi_j = agent_j._exp_neg_phi

    dphi_j = np.zeros_like(agent_j.phi)

    for neighbor in agent_j.neighbors:
        agent_i = agents[neighbor["id"]]

        # Only include this neighbor if j is the *target* of Ω_ij
        if neighbor.get("target_id", None) != agent_j.id:
            continue  # skip if this isn't KL(q_i ‖ Ω_ij q_j)

        Omega_ij = neighbor["Omega_ij"]
        generators_q = neighbor["generators_q"]

        dphi_j += grad_kl_wrt_phi_j(
            agent_i.mu_q_field, agent_i.sigma_q_field,
            mu_j, sigma_j,
            Omega_ij, generators_q,
            exp_phi_j, exp_neg_phi_j,
            eps=config.support_cutoff_eps
        )

    return beta * dphi_j
