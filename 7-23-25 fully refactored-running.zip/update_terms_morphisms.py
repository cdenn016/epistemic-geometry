# -*- coding: utf-8 -*-
"""
Created on Wed Jul 23 06:38:37 2025

@author: chris and christine
"""
import numpy as np
from natural_gradient import dexpinv_operator_morphism  # you will need to implement this
from numerical_utils import( safe_inv,
                            )
from get_generators import get_generators
#==============================================================================
#
#                    Apply Natural Gradient to Bundle Morphism
#
#==============================================================================



def accumulate_morphism_feedback_gradient_natural(
    agent_i,
    feedback_weight,
    G_inv_field,
    generators,              # ← added
    mask=None,
    eps=1e-8,
):
    """
    Accumulate natural gradient ∇_Φ KL(p || Φ·q) into agent_i.grad_Phi
    """
    grad_euclidean = compute_morphism_gradient_feedback_euclidean(agent_i, eps=eps)

    if mask is not None:
        grad_euclidean *= mask[..., None, None]

    grad_natural = dexpinv_operator_morphism(
        Phi=agent_i.bundle_morphism_q_to_p,
        grad_Phi=grad_euclidean,
        generators=generators,           # use the passed-in argument
        fisher_inv_field=G_inv_field
    )

    agent_i.grad_Phi += feedback_weight * grad_natural[..., None, None]


def accumulate_morphism_self_gradient_natural(agent_i, alpha, G_inv_field, mask=None, eps=1e-8):

    """
    Accumulate natural gradient ∇_{Φ̃} KL(q || Φ̃·p) into agent_i.grad_Phi_tilde
    """
    # Step 1: Euclidean gradient
    grad_euclidean = compute_morphism_gradient_self_euclidean(agent_i, eps=eps)

    if mask is not None:
        grad_euclidean *= mask[..., None, None]

    # Step 2: Apply dexpinv operator with inverse Fisher metric
    fisher_inv = getattr(agent_i, "fisher_inv_phi", None)
    grad_natural = dexpinv_operator_morphism(
        agent_i.bundle_morphism_p_to_q,
        grad_euclidean,
        fisher_inv_field=fisher_inv,
        eps=eps
    )

    agent_i.grad_Phi_tilde += alpha * grad_natural



    
def compute_morphism_gradient_feedback_euclidean(agent_i, eps=1e-8):
    """
    Compute ∂/∂Φ KL(p || Φ·q) over spatial grid using agent fields.

    Returns:
        grad_Phi: (H, W, K_p, K_q) Euclidean gradient
    """
    return compute_morphism_feedback_gradient_batched(
        agent_i.bundle_morphism_q_to_p,
        agent_i.mu_q_field,
        agent_i.sigma_q_field,
        agent_i.mu_p_field,
        agent_i.sigma_p_field,
        eps=eps
    )


def compute_morphism_gradient_self_euclidean(agent_i, eps=1e-8):
    """
    Compute full Euclidean gradient ∂/∂Φ~ KL(q || Φ~·p) over the spatial grid.

    Returns:
        grad: (H, W, K_q, K_p) Euclidean gradient
    """
    return compute_morphism_self_gradient_batched(
        agent_i.bundle_morphism_p_to_q,
        agent_i.mu_q_field,
        agent_i.sigma_q_field,
        agent_i.mu_p_field,
        agent_i.sigma_p_field,
        eps=eps
    )




def compute_morphism_feedback_gradient_batched(Phi, mu_q, Sigma_q, mu_p, Sigma_p, eps=1e-8):
    """
    Batched version of ∂/∂Φ D_KL(p || Φ·q) for spatial grid.
    """
    H, W, K_p, K_q = Phi.shape
    grad = np.zeros_like(Phi)

    for i in range(H):
        for j in range(W):
            grad[i, j] = compute_morphism_kl_gradient_feedback(
                Phi[i, j], mu_q[i, j], Sigma_q[i, j],
                mu_p[i, j], Sigma_p[i, j], eps=eps
            )

    return grad

def compute_morphism_self_gradient_batched(Phi_tilde, mu_q, Sigma_q, mu_p, Sigma_p, eps=1e-8):
    """
    Batched version of ∂/∂Φ~ D_KL(q || Φ~·p) for spatial grid.
    
    Args:
        Phi~     : (H, W, K_q, K_p)
        mu_q     : (H, W, K_q)
        Sigma_q  : (H, W, K_q, K_q)
        mu_p     : (H, W, K_p)
        Sigma_p  : (H, W, K_p, K_p)
        eps      : float, SPD regularization
    
    Returns:
        grad     : (H, W, K_q, K_p) KL gradient w.r.t. Φ~ at each spatial location
    """
    H, W, K_q, K_p = Phi_tilde.shape
    grad = np.zeros_like(Phi_tilde)

    for i in range(H):
        for j in range(W):
            grad[i, j] = compute_morphism_kl_gradient_self(
                Phi_tilde[i, j], mu_q[i, j], Sigma_q[i, j],
                mu_p[i, j], Sigma_p[i, j], eps=eps
                )


    return grad
#==============================================================================
#
#                    FEEDBACK TERMS
#
#==============================================================================


def grad_morphism_feedback_energy(agent_i, feedback_weight, mask=None, eps=1e-8):
    """
    Compute full gradient ∂/∂Φ KL(p || Φ·q) over spatial grid (H, W)
    """
    mu_q    = agent_i.mu_q_field
    sigma_q = agent_i.sigma_q_field
    mu_p    = agent_i.mu_p_field
    sigma_p = agent_i.sigma_p_field
    Phi     = agent_i.bundle_morphism_q_to_p

    grad = compute_morphism_self_gradient_batched(
        Phi, mu_q, sigma_q, mu_p, sigma_p, eps=eps
    )

    if mask is not None:
        grad *= mask[..., None, None]  # shape (H, W, 1, 1)

    return feedback_weight * grad





def compute_morphism_feedback_gradient_primitives(Phi, mu_q, Sigma_q, mu_p, Sigma_p, eps=1e-8):
    """
    Compute shared intermediates needed to evaluate ∂/∂Φ D_KL(p || Φ·q)
    
    Args:
        Phi      : (K_p, K_q) linear morphism matrix Φ
        mu_q     : (K_q,)     mean of belief q
        Sigma_q  : (K_q, K_q) covariance of belief q
        mu_p     : (K_p,)     mean of model p
        Sigma_p  : (K_p, K_p) covariance of model p
        eps      : stabilizer for SPD inverse

    Returns:
        dict containing:
            - Delta_mu     : (K_p,)     = mu_p - Φ·mu_q
            - Sigma_q_inv  : (K_q, K_q)
            - M            : (K_p, K_p) = Φ Σ_q Φᵀ
            - M_inv        : (K_p, K_p)
            - term_trace   : (K_p, K_p) = M⁻¹ Σ_p M⁻¹
            - term_logdet  : (K_p, K_q) = M⁻¹ Φ Σ_q
    """
    K_p, K_q = Phi.shape

    # Compute Δμ = μ_p - Φ·μ_q
    Delta_mu = mu_p - Phi @ mu_q

    # Inverse of Σ_q
    Sigma_q_inv = safe_inv(Sigma_q, eps=eps)

    # M = Φ Σ_q Φᵀ
    M = Phi @ Sigma_q @ Phi.T

    # Inverse of M
    M_inv = safe_inv(M, eps=eps)

    # Precompute reusable trace/logdet gradient terms
    term_trace = 0.5*M_inv @ Sigma_p @ M_inv  # (K_p, K_p)
    term_logdet = 0.5* M_inv @ Phi @ Sigma_q  # (K_p, K_q)

    return {
        "Delta_mu": Delta_mu,
        "Sigma_q_inv": Sigma_q_inv,
        "M": M,
        "M_inv": M_inv,
        "term_trace": term_trace,
        "term_logdet": term_logdet
    }


def compute_morphism_kl_gradient_feedback(Phi, mu_q, Sigma_q, mu_p, Sigma_p, eps=1e-8):
    """
    Compute ∂/∂Φ D_KL(p || Φ·q) using decomposed analytic form.

    Args:
        Phi      : (K_p, K_q) morphism matrix Φ
        mu_q     : (K_q,)     mean of q
        Sigma_q  : (K_q, K_q) covariance of q
        mu_p     : (K_p,)     mean of p
        Sigma_p  : (K_p, K_p) covariance of p
        eps      : regularization for safe inverse

    Returns:
        grad_Phi : (K_p, K_q) gradient of KL divergence w.r.t. Φ
    """
    # Get all shared quantities
    primitives = compute_morphism_feedback_gradient_primitives(
        Phi, mu_q, Sigma_q, mu_p, Sigma_p, eps=eps
    )

    Delta_mu     = primitives["Delta_mu"]        # (K_p,)
    Sigma_q_inv  = primitives["Sigma_q_inv"]     # (K_q, K_q)
    M_inv        = primitives["M_inv"]           # (K_p, K_p)
    term_trace   = primitives["term_trace"]      # (K_p, K_p)
    term_logdet  = primitives["term_logdet"]     # (K_p, K_q)

    
    # Term 1:  M⁻¹ ΔμΔμ^TM⁻¹ Φ Σ_q
  
    term2 =  M_inv @ np.outer(Delta_mu, Delta_mu) @ M_inv @ Phi @ Sigma_q


    # Term 3: + M⁻¹ Φ Σ_q
    term3 = term_logdet

    # Term 4: - M⁻¹ Σ_p M⁻¹ Φ Σ_q
    term4 = - term_trace @ Phi @ Sigma_q

    # Total gradient
    grad_Phi =  term2 + term3 + term4

    return grad_Phi


#==============================================================================
#
#                    SELF-ENERGY TERMS
#
#==============================================================================


def grad_morphism_self_energy(agent_i, alpha, mask=None, eps=1e-8):
    """
    Compute full gradient ∂/∂Φ KL(q || Φ~·p) over spatial grid (H, W)
    """
    mu_q    = agent_i.mu_q_field
    sigma_q = agent_i.sigma_q_field
    mu_p    = agent_i.mu_p_field
    sigma_p = agent_i.sigma_p_field
    Phi_tilde     = agent_i.bundle_morphism_p_to_q

    grad = compute_morphism_self_gradient_batched(
        Phi_tilde, mu_q, sigma_q, mu_p, sigma_p, eps=eps
    )

    if mask is not None:
        grad *= mask[..., None, None]  # shape (H, W, 1, 1)

    return alpha * grad



#validated
def compute_morphism_self_gradient_primitives(Phi_tilde, mu_q, Sigma_q, mu_p, Sigma_p, eps=1e-8):
    """
    Compute shared intermediates needed to evaluate ∂/∂Φ~ D_KL(q || Φ·p)
    
    Args:
        Phi~      : (K_q, K_p) linear morphism matrix Φ~
        mu_q     : (K_q,)     mean of belief q
        Sigma_q  : (K_q, K_q) covariance of belief q
        mu_p     : (K_p,)     mean of model p
        Sigma_p  : (K_p, K_p) covariance of model p
        eps      : stabilizer for SPD inverse

    Returns:
        dict containing:
            - Delta_mu     : (K_q,)     = mu_q - Φ~·mu_p
            - Sigma_q_inv  : (K_q, K_q)
            - M            : (K_q, K_q) = Φ~ Σ_q Φ~ᵀ
            - M_inv        : (K_q, K_q)
            - term_trace   : (K_q, K_q) = M⁻¹ Σ_q M⁻¹
            - term_logdet  : (K_q, K_p) = M⁻¹ Φ~ Σ_p
    """
    K_q, K_p = Phi_tilde.shape

    # Compute Δμ = μ_p - Φ·μ_q
    Delta_mu = mu_q - Phi_tilde @ mu_p

    # Inverse of Σ_q
    Sigma_p_inv = safe_inv(Sigma_p, eps=eps)

    # M = Φ~ Σ_p Φ~ᵀ
    M = Phi_tilde @ Sigma_p @ Phi_tilde.T

    # Inverse of M
    M_inv = safe_inv(M, eps=eps)

    # Precompute reusable trace/logdet gradient terms
    term_trace = 0.5*M_inv @ Sigma_q @ M_inv  # (K_p, K_p)
    term_logdet = 0.5*M_inv @ Phi_tilde @ Sigma_p  # (K_p, K_q)

    return {
        "Delta_mu": Delta_mu,
        "Sigma_p_inv": Sigma_p_inv,
        "M": M,
        "M_inv": M_inv,
        "term_trace": term_trace,
        "term_logdet": term_logdet
    }

#validated
def compute_morphism_kl_gradient_self(Phi_tilde, mu_q, Sigma_q, mu_p, Sigma_p, eps=1e-8):
    """
    Compute ∂/∂Φ~ D_KL(q || Φ~·p), where Φ~: P → Q

    Args:
        Phi_tilde : (K_q, K_p) morphism matrix Φ~
        mu_q      : (K_q,)     mean of q
        Sigma_q   : (K_q, K_q) covariance of q
        mu_p      : (K_p,)     mean of p
        Sigma_p   : (K_p, K_p) covariance of p
        eps       : regularization for inverse safety

    Returns:
        grad_Phi  : (K_q, K_p) gradient of KL divergence w.r.t. Φ~
    """
    # Shared intermediate quantities
    primitives = compute_morphism_self_gradient_primitives(
        Phi_tilde, mu_q, Sigma_q, mu_p, Sigma_p, eps=eps
    )

    Delta_mu     = primitives["Delta_mu"]        # (K_q,)
    M_inv        = primitives["M_inv"]           # (K_q, K_q)
    term_trace   = primitives["term_trace"]      # (K_q, K_q)
    term_logdet  = primitives["term_logdet"]     # (K_q, K_p)

    # --- Gradient terms ---

    # Term 1: M⁻¹ Δμ Δμᵀ M⁻¹ Φ̃ Σ_p
    term2 = M_inv @ np.outer(Delta_mu, Delta_mu) @ M_inv @ Phi_tilde @ Sigma_p

    # Term 3: + M⁻¹ Φ̃ Σ_p (from log-det derivative)
    term3 = term_logdet

    # Term 4: - M⁻¹ Σ_q M⁻¹ Φ̃ Σ_p
    term4 = -term_trace @ Phi_tilde @ Sigma_p

    # Total gradient
    grad_Phi = term2 + term3 + term4

    return grad_Phi