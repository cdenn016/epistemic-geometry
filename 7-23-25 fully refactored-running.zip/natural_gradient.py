# -*- coding: utf-8 -*-
"""
Created on Wed Jul 23 09:23:50 2025

@author: chris and christine
"""
import numpy as np
import config
from joblib import Parallel, delayed
from numerical_utils import safe_inv
from get_generators import get_generators
from numerical_utils import sanitize_sigma
from generalized_omega import safe_bch_exact


def cache_fisher_inverse_morphisms(agent_i, eps=1e-8):
    agent_i.fisher_inv_phi_model = compute_inverse_fisher_field(
        agent_i.bundle_morphism_q_to_p,
        agent_i.generators_q_to_p,
        eps=eps
    )
    agent_i.fisher_inv_phi = compute_inverse_fisher_field(
        agent_i.bundle_morphism_p_to_q,
        agent_i.generators_p_to_q,
        eps=eps
    )

def compute_lie_metric(generators: np.ndarray):
    """
    Compute inner product matrix G_{ab} = Tr(G_aᵀ G_b) and its inverse.

    Args:
        generators: (d, K, K) basis of Lie algebra

    Returns:
        G: (d, d) inner product matrix
        G_inv: (d, d) inverse (with fallback)
    """
    d = generators.shape[0]
    G = np.einsum("aij,bij->ab", generators, generators)
    G = 0.5 * (G + G.T)  # symmetrize

    G_inv = safe_inv(G, eps=getattr(config, "eps", 1e-6))


    return G, G_inv

def compute_inverse_fisher_field(agent, generators, field="phi"):
    """
    Computes per-point inverse Fisher metric G^{-1}_{ab}(x) in the Lie algebra.
    Skips computation in regions where agent.mask < support_cutoff_eps.

    Args:
        agent: agent object with sigma_q_field or sigma_p_field
        generators: (d, K, K) Lie algebra basis
        field: "phi" or "phi_model"

    Returns:
        G_inv_field: (H, W, d, d)
    """
    sigma_field = agent.sigma_q_field if field == "phi" else agent.sigma_p_field
    mask = agent.mask > getattr(config, "support_cutoff_eps", 1e-4)

    sigma_field = sanitize_sigma(sigma_field, eps=config.eps, debug=config.debug_sanitize_sigma)

    H, W, K, _ = sigma_field.shape
    d = generators.shape[0]
    eye_K = np.eye(K)
    eye_d = np.eye(d)

    G_inv_field = np.zeros((H, W, d, d), dtype=sigma_field.dtype)

    flat_sigma = sigma_field.reshape(-1, K, K)
    flat_mask = mask.reshape(-1)
    N = flat_sigma.shape[0]

    valid_indices = np.flatnonzero(flat_mask)
    sigma_valid = flat_sigma[valid_indices]  # (M, K, K)

    # Step 1: invert Σ⁻¹ (with fallback)
    sigma_inv = np.empty_like(sigma_valid)
    for i in range(sigma_valid.shape[0]):
        try:
            sigma_inv[i] = np.linalg.inv(sigma_valid[i])
        except np.linalg.LinAlgError:
            sigma_inv[i] = eye_K
            if config.debug:
                print(f"[WARN] Σ⁻¹ failed at valid index {i}")

    # Step 2: compute G_ab[i, a, b] = Tr[Σ⁻¹ G^a Σ⁻¹ G^b]
    G_ab = np.zeros((sigma_inv.shape[0], d, d), dtype=sigma_field.dtype)

    for a in range(d):
        for b in range(d):
            G_a = np.broadcast_to(generators[a], sigma_inv.shape)
            G_b = np.broadcast_to(generators[b], sigma_inv.shape)


            G_ab[..., a, b] = np.einsum("...ij,...jk,...kl,...il->...", sigma_inv, G_a, sigma_inv, G_b)

    # Step 3: symmetrize and invert G_ab
    flat_G_inv = G_inv_field.reshape(-1, d, d)
    for i, flat_idx in enumerate(valid_indices):
        G_sym = 0.5 * (G_ab[i] + G_ab[i].T)
        try:
            cond = np.linalg.cond(G_sym)
            if not np.isfinite(cond) or cond > config.max_fisher_condition:
                raise np.linalg.LinAlgError
            flat_G_inv[flat_idx] = np.linalg.inv(G_sym + config.eps * eye_d)
        except np.linalg.LinAlgError:
            flat_G_inv[flat_idx] = eye_d
            if config.debug:
                print(f"[WARN] G_ab⁻¹ fallback at index {flat_idx}")

    return G_inv_field


def compute_inverse_fisher_morphism_field(agent, direction="q_to_p", eps=1e-8):
    """
    Compute the inverse Fisher metric over the morphism field Φ or Φ̃.

    Parameters:
    - agent    : the agent object
    - direction: "q_to_p" for Φ  or  "p_to_q" for Φ̃
    - eps      : numerical stability for inverses

    Returns:
    - inverse Fisher metric of shape (H, W, K_out, K_in, K_out, K_in)
    """
    assert direction in {"q_to_p", "p_to_q"}

    if direction == "q_to_p":
        sigma_in  = agent.sigma_q_field   # Σ_q
        sigma_out = agent.sigma_p_field   # Σ_p
        name = "Φ"
    else:
        sigma_in  = agent.sigma_p_field   # Σ_p
        sigma_out = agent.sigma_q_field   # Σ_q
        name = "Φ̃"

    H, W, K_out, _ = sigma_out.shape
    _, _, K_in,  _ = sigma_in.shape

    # Sanitize first
    sigma_in  = sanitize_sigma(sigma_in, eps=eps)
    sigma_out = sanitize_sigma(sigma_out, eps=eps)

    inv_in  = safe_inv(sigma_in,  eps=eps)   # (..., K_in, K_in)
    inv_out = safe_inv(sigma_out, eps=eps)   # (..., K_out, K_out)

    # Build Fisher metric:
    # G[m,n,p,q] = inv_out[m,p] * inv_in[n,q]
    fisher = np.einsum("...mp,...nq->...mnpq", inv_out, inv_in)

    # Flatten to square matrix for inversion
    fisher_flat = fisher.reshape(H, W, K_out * K_in, K_out * K_in)
    fisher_inv_flat = np.zeros_like(fisher_flat)

    for i in range(H):
        for j in range(W):
            fisher_inv_flat[i, j] = safe_inv(fisher_flat[i, j], eps=eps)

    # Reshape back to tensor form
    fisher_inv = fisher_inv_flat.reshape(H, W, K_out, K_in, K_out, K_in)

    return fisher_inv



def apply_lie_natural_gradient(phi, grad_phi, G_inv=None, use_dexpinv=False):
    """
    Apply Lie-natural gradient update to φ using optional inverse Fisher metric
    and optional Lie group correction via dexp⁻¹.

    Args:
        phi         : (H, W, d) Lie algebra field
        grad_phi    : (H, W, d) raw Euclidean gradient
        G_inv       : (d,d) or (H,W,d,d) inverse Fisher metric or None
        use_dexpinv : NOT SUPPORTED HERE — caller must apply dexpinv externally if needed

    Returns:
        nat_grad : (H, W, d) Lie-natural gradient
    """
    assert phi.shape == grad_phi.shape, f"Shape mismatch: phi {phi.shape} vs grad {grad_phi.shape}"

    if use_dexpinv:
        raise NotImplementedError(
            "[ERROR] `use_dexpinv=True` requires calling dexpinv_operator_covariance(...) externally."
        )

    if G_inv is None:
        return grad_phi

    if G_inv.ndim == 2:
        return np.einsum("ab,...b->...a", G_inv, grad_phi)
    elif G_inv.ndim == 4:
        return np.einsum("...ab,...b->...a", G_inv, grad_phi)
    else:
        raise ValueError(f"G_inv must be (d,d) or (H,W,d,d), got {G_inv.shape}")

def apply_natural_gradient_batch(mu_field, sigma_field, grad_mu_field, grad_sigma_field, mask=None):
    """
    Apply natural gradient descent using local Fisher metric at each spatial point.
    Handles fallbacks and invalid regions with explicit masking and logging.
    
    Fisher inverse:
        G_mu^-1 = Σ
        G_Sigma^-1 = 2 × (Σ ⊗ Σ)
    
    Returns:
        delta_mu:    (H, W, K)
        delta_sigma: (H, W, K, K)
    """
    eps = getattr(config, "eps", 1e-8)
    debug = getattr(config, "debug_gradients", False)
    fallback_clip_value = getattr(config, "sanitize_fallback_value", 1.0)
    clip_threshold = getattr(config, "gradient_clip", 1e5)

    H, W, K = mu_field.shape
    N = H * W

    mu_flat = mu_field.reshape(N, K)
    sigma_flat = sigma_field.reshape(N, K, K)
    grad_mu_flat = grad_mu_field.reshape(N, K)
    grad_sigma_flat = grad_sigma_field.reshape(N, K, K)

    delta_mu = np.zeros_like(mu_flat)
    delta_sigma = np.zeros_like(sigma_flat)

    eye = np.eye(K)

    if mask is not None:
        flat_mask = mask.reshape(N)
    else:
        flat_mask = np.ones(N, dtype=bool)

    for n in range(N):
        if not flat_mask[n]:
            continue  # skip masked-out regions

        sigma_n = 0.5 * (sigma_flat[n] + sigma_flat[n].T) + eps * eye
        grad_mu_n = grad_mu_flat[n]
        grad_sigma_n = grad_sigma_flat[n]

        try:
            sigma_inv = safe_inv(sigma_n, eps=config.eps)
        except np.linalg.LinAlgError:
            sigma_inv = eye * fallback_clip_value
            if debug:
                print(f"[WARN] NG Σ⁻¹ fallback at index {n}")

        # Compute updates
        delta_mu_n = -sigma_n @ grad_mu_n
        delta_sigma_n = -2.0 * sigma_n @ grad_sigma_n @ sigma_n

        # Clip large gradients
        norm_sigma = np.linalg.norm(delta_sigma_n)
        if norm_sigma > clip_threshold:
            delta_sigma_n *= clip_threshold / norm_sigma

        delta_mu[n] = np.nan_to_num(delta_mu_n)
        delta_sigma[n] = np.nan_to_num(delta_sigma_n)

    return (
        delta_mu.reshape(H, W, K),
        delta_sigma.reshape(H, W, K, K),
    )

import numpy as np

def dexpinv_operator_morphism(Phi, grad_Phi, generators, fisher_inv_field=None, eps=1e-8):
    """
    Project Euclidean gradient ∂L/∂Φ ∈ R^{K_p × K_q} to Lie algebra coords via Tr[ ∂L/∂Φ · (Φ·G^a) ].
    Optionally applies the inverse Fisher metric to form the natural gradient.

    Args:
        Phi               : (H, W, K_p, K_q) morphism field (Φ : B_q → B_p)
        grad_Phi          : (H, W, K_p, K_q) Euclidean gradient
        generators        : (d, K_q, K_q) Lie algebra basis for domain space
        fisher_inv_field  : (H, W, d, d) optional inverse Fisher metric
        eps               : numerical stabilizer

    Returns:
        grad_coords       : (H, W, d) gradient in Lie algebra coordinates
    """
    H, W, K_p, K_q = grad_Phi.shape
    d = generators.shape[0]
    grad_coords = np.zeros((H, W, d), dtype=grad_Phi.dtype)

    # Project using Frobenius inner product with δΦ = Φ · G_a
    for a in range(d):
        G_a = generators[a]  # shape (K_q, K_q)
        delta_Phi = np.einsum("...ik,kl->...il", Phi, G_a)  # Φ · G_a
        grad_coords[..., a] = 2.0 * np.einsum("...ij,...ij->...", grad_Phi, delta_Phi)

    # Optional inverse Fisher preconditioning
    if fisher_inv_field is not None:
        grad_coords = np.einsum("...ab,...b->...a", fisher_inv_field, grad_coords)

    return grad_coords




def dexpinv_operator(phi, delta, generators, order=None, use_exact=None):
    """
    Applies exact inverse of exp pushforward:
        dexpinv(phi, delta) ∈ 𝔤

    Uses:
        bch_exact(exp(φ), exp(δ)) - φ → projected back into 𝔤

    Args:
        phi     : (..., d) current Lie-algebra coords
        delta   : (..., d) Lie-algebra variation
        generators: (d, K, K) basis of Lie algebra

    Returns:
        corrected_delta: (..., d)
    """
    H, W, d = phi.shape
    corrected = np.zeros_like(delta)

    # Matrix form: φ, Δ ∈ 𝔤
    phi_mat   = np.einsum("...a,akl->...kl", phi, generators)
    delta_mat = np.einsum("...a,akl->...kl", delta, generators)

    composed = np.zeros_like(phi_mat)
    for i in range(H):
        for j in range(W):
            A = phi_mat[i, j]
            B = delta_mat[i, j]
            C = safe_bch_exact(A, B)  # full BCH or logm
            composed[i, j] = C - A

    # Project back: δ_corrected^a = Tr[(C - A) · G^a]
    for a in range(d):
        G = generators[a]
        corrected[..., a] = 2.0 * np.einsum("...ij,ij->...", composed, G)

    return corrected


def dexpinv_operator_covariance(phi, delta_sigma, generators, transpose=False):
    """
    Applies exact dexpinv operator to ∂L/∂Σ through transported covariance Ω Σ Ωᵀ.
    Projects gradient back into Lie-algebra coordinates via generator basis.

    Args:
        phi         : (H, W, d)  current φ field
        delta_sigma : (H, W, K, K) ∂KL/∂Σ_transport
        generators  : (d, K, K)
        transpose   : whether to apply dummy transpose (not used in practice)

    Returns:
        corrected_grad: (H, W, d)
    """
    H, W, d = phi.shape
    corrected = np.zeros((H, W, d), dtype=phi.dtype)

    # Construct φ matrix at each (i, j)
    phi_mat = np.einsum("...a,akl->...kl", phi, generators)

    for i in range(H):
        for j in range(W):
            A = phi_mat[i, j]
            dΣ = delta_sigma[i, j]

            # Use exact backprop: log(exp(A) @ exp(dΣ)) - A
            B = safe_bch_exact(A, dΣ)
            C = B - A

            for a in range(d):
                G = generators[a]
                corrected[i, j, a] += 2.0 * np.trace(C @ G)

    if transpose:
        corrected = np.swapaxes(corrected, -1, -1)  # no-op, kept for legacy compat

    return corrected