# -*- coding: utf-8 -*-
"""
Created on Wed Jul 23 09:07:26 2025

@author: chris and christine
"""
def compute_total_gradient_model(agent_i, agents, params):
    """
    Accumulate ∇_μ_p and ∇_Σ_p gradients for agent_i from:
    - Self-energy:      KL(q_i ‖ Φ̃ p_i)
    - Feedback:         KL(p_i ‖ Φ q_i)
    - Alignment (μ_i):  KL(p_i ‖ Ω̃_ij p_j)
    - Alignment (μ_j):  KL(p_k ‖ Ω̃_kj p_j) if i == j

    Returns:
        dmu_p:    (..., K_p)
        dsigma_p: (..., K_p, K_p)
    """
    eps        = config.support_cutoff_eps
    alpha      = params.get("alpha", config.alpha)
    lambd      = params.get("lambda", config.lambd)
    beta_model = params.get("beta_model", 0.0)

    mu_q       = agent_i.mu_q_field
    sigma_q    = agent_i.sigma_q_field
    mu_p       = agent_i.mu_p_field
    sigma_p    = agent_i.sigma_p_field
    Phi        = agent_i.bundle_morphism_q_to_p
    Phi_tilde  = agent_i.bundle_morphism_p_to_q

    #────────────────────────────────────
    # Self-energy: KL(q_i ‖ Φ̃ p_i)
    #────────────────────────────────────
    dmu_self    = grad_self_energy_mu_p(mu_q, sigma_q, mu_p, sigma_p, Phi_tilde, eps=eps)
    dsigma_self = grad_self_energy_sigma_p(mu_q, sigma_q, mu_p, sigma_p, Phi_tilde, eps=eps)

    #────────────────────────────────────
    # Feedback: KL(p_i ‖ Φ q_i)
    #────────────────────────────────────
    dmu_fb    = grad_feedback_mu_p(mu_p, sigma_p, mu_q, sigma_q, Phi, eps=eps)
    dsigma_fb = grad_feedback_sigma_p(mu_p, sigma_p, mu_q, sigma_q, Phi, eps=eps)

    #────────────────────────────────────
    # Alignment (agent_i is source): KL(p_i ‖ Ω̃_ij p_j)
    #────────────────────────────────────
    dmu_align_src = 0
    dsigma_align_src = 0
    for neighbor in agent_i.neighbors:
        agent_j = agents[neighbor["id"]]
        Omega_tilde_ij = neighbor.get("Omega_model_ij", None)
        if Omega_tilde_ij is not None:
            dmu_align_src += grad_model_align_mu_i(
                mu_p, sigma_p,
                agent_j.mu_p_field, agent_j.sigma_p_field,
                Omega_tilde_ij, eps=eps
            )
            dsigma_align_src += grad_model_align_sigma_i(
                mu_p, sigma_p,
                agent_j.mu_p_field, agent_j.sigma_p_field,
                Omega_tilde_ij, eps=eps
            )

    #────────────────────────────────────
    # Alignment (agent_i is target): KL(p_k ‖ Ω̃_kj p_j)
    #────────────────────────────────────
    dmu_align_tgt = 0
    dsigma_align_tgt = 0
    for agent_k in agents:
        for neighbor in agent_k.neighbors:
            if neighbor.get("id") == agent_i.id:
                Omega_tilde_kj = neighbor.get("Omega_model_ij", None)
                if Omega_tilde_kj is not None:
                    dmu_align_tgt += grad_model_align_mu_j(
                        agent_k.mu_p_field, agent_k.sigma_p_field,
                        mu_p, sigma_p, Omega_tilde_kj, eps=eps
                    )
                    dsigma_align_tgt += grad_model_align_sigma_j(
                        agent_k.mu_p_field, agent_k.sigma_p_field,
                        mu_p, sigma_p, Omega_tilde_kj, eps=eps
                    )

    #────────────────────────────────────
    # Combine all components
    #────────────────────────────────────
    dmu_total = (
        alpha * dmu_self +
        lambd * dmu_fb +
        beta_model * (dmu_align_src + dmu_align_tgt)
    )

    dsigma_total = (
        alpha * dsigma_self +
        lambd * dsigma_fb +
        beta_model * (dsigma_align_src + dsigma_align_tgt)
    )

    return dmu_total, dsigma_total

