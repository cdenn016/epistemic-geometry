# Updated generalized_agent_schema.py with default grad_phi and grad_phi_tilde
from dataclasses import dataclass, field
from typing import Any, Dict, List, Tuple, Optional
import numpy as np

@dataclass
class Agent:
    id: int
    center: Tuple[int, ...]
    radius: float
    mask: np.ndarray
    mu_q_field: np.ndarray
    sigma_q_field: np.ndarray
    mu_p_field: np.ndarray
    sigma_p_field: np.ndarray
    phi: np.ndarray
    phi_model: np.ndarray
    neighbors: List[Dict[str, Any]] = field(default_factory=list)
    metrics_log: List[Dict[str, Any]] = field(default_factory=list)

    # Runtime cache fields
    _exp_phi: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    _exp_neg_phi: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    _exp_phi_model: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    _exp_neg_phi_model: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    transport_cache: Dict[str, Any] = field(default_factory=dict, init=False)

    # Morphism fields
    bundle_morphism_q_to_p: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    bundle_morphism_p_to_q: Optional[np.ndarray] = field(default=None, init=False, repr=False)

    # Gradient fields
    grad_mu_q_field: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    grad_sigma_q_field: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    grad_mu_p_field: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    grad_sigma_p_field: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    grad_phi: np.ndarray = field(init=False, repr=False)
    grad_phi_tilde: np.ndarray = field(init=False, repr=False)
    grad_Phi: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    grad_Phi_tilde: Optional[np.ndarray] = field(default=None, init=False, repr=False)

    # Fisher-metric cache fields
    inverse_fisher_phi: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    inverse_fisher_phi_model: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    inverse_fisher_Phi: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    inverse_fisher_Phi_tilde: Optional[np.ndarray] = field(default=None, init=False, repr=False)

    # Diagnostic fields
    fisher_I: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    pull_M_vis: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    pull_Delta: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    pull_M_dark: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    spatial_G: Optional[np.ndarray] = field(default=None, init=False, repr=False)


    def __post_init__(self):
        self.grad_phi = np.zeros_like(self.phi)
        self.grad_phi_tilde = np.zeros_like(self.phi_model)

        self.grad_mu_q_field    = np.zeros_like(self.mu_q_field)
        self.grad_sigma_q_field = np.zeros_like(self.sigma_q_field)
        self.grad_mu_p_field    = np.zeros_like(self.mu_p_field)
        self.grad_sigma_p_field = np.zeros_like(self.sigma_p_field)

    # If morphisms are initialized externally, this will still work
        if self.bundle_morphism_q_to_p is not None:
            self.grad_Phi = np.zeros_like(self.bundle_morphism_q_to_p)
        else:
            self.grad_Phi = None

        if self.bundle_morphism_p_to_q is not None:
            self.grad_Phi_tilde = np.zeros_like(self.bundle_morphism_p_to_q)
        else:
            self.grad_Phi_tilde = None


    def log_metrics(self, step: int, stats: Dict[str, Any]) -> None:
        self.metrics_log.append({'step': step, **stats})

    def clear_omega_cache(self) -> None:
        self._exp_phi = None
        self._exp_neg_phi = None
        self._exp_phi_model = None
        self._exp_neg_phi_model = None
        self.transport_cache.clear()

    def clear_diagnostics(self) -> None:
        self.fisher_I = None
        self.pull_M_vis = None
        self.pull_Delta = None
        self.pull_M_dark = None
        self.spatial_G = None

    def clear_fisher_caches(self) -> None:
        self.inverse_fisher_phi = None
        self.inverse_fisher_phi_model = None
        self.inverse_fisher_Phi = None
        self.inverse_fisher_Phi_tilde = None

    @property
    def grid_shape(self) -> Tuple[int, ...]:
        return self.mu_q_field.shape[:-1]

    @property
    def Omega(self) -> np.ndarray:
        K = self.mu_q_field.shape[-1]
        return self._exp_phi.reshape(*self.grid_shape, K, K)

    @property
    def Omega_inv(self) -> np.ndarray:
        K = self.mu_q_field.shape[-1]
        return self._exp_neg_phi.reshape(*self.grid_shape, K, K)

    @property
    def Omega_model(self) -> np.ndarray:
        K = self.mu_p_field.shape[-1]
        return self._exp_phi_model.reshape(*self.grid_shape, K, K)

    @property
    def Omega_model_inv(self) -> np.ndarray:
        K = self.mu_p_field.shape[-1]
        return self._exp_neg_phi_model.reshape(*self.grid_shape, K, K)

    @property
    def bundle_morphism(self) -> Optional[np.ndarray]:
        return self.bundle_morphism_q_to_p

    @property
    def bundle_morphism_model(self) -> Optional[np.ndarray]:
        return self.bundle_morphism_p_to_q
