# -*- coding: utf-8 -*-
"""
Created on Wed Jul 23 18:00:25 2025

@author: chris and christine
"""

import numpy as np
import config
from scipy.linalg import expm
from joblib import Parallel, delayed, parallel_backend
from scipy.ndimage import gaussian_filter
from numerical_utils import sanitize_sigma
from numerical_utils import safe_omega_inv


from scipy.linalg import logm, expm

import numpy as np
from scipy.linalg import expm, logm
import warnings


def compute_exp_field(phi_field, generators, scale, group_name=None, debug=False, max_norm=None):
    """
    Compute exp(phi) for a field (H, W, d) given Lie algebra generators.

    Args:
        phi_field: (..., d)
        generators: (d, K, K)
        scale: scalar rescaling factor
        group_name: Lie group name ("so3", "sl2r", etc)
        debug: print clipping diagnostics
        max_norm: override for clipping norm (otherwise taken from config)

    Returns:
        exp(phi): (..., K, K)
    """
    
    H, W, d = phi_field.shape
    K = generators.shape[1]
    flat_phi = phi_field.reshape(-1, d)

    # ───── Configurable norm clipping ─────
    if max_norm is None:
        max_norm = getattr(config, "phi_exp_clip", 10.0)

    norm_type = getattr(config, "gradient_clip_norm_type", 2)
    eps = 1e-16
    norms = np.linalg.norm(flat_phi, ord=norm_type, axis=1)
    scale_factors = np.minimum(1.0, max_norm / (norms + eps))
    flat_phi = flat_phi * scale_factors[:, None]

    if debug and np.any(scale_factors < 1.0):
        clipped = np.sum(scale_factors < 1.0)
        print(f"[compute_exp_field] Clipped {clipped} / {flat_phi.shape[0]} φ vectors to ‖φ‖ ≤ {max_norm}")

    # ───── Scale and exponentiate ─────
    flat_phi /= scale
    exp_batch = exp_lie_algebra_irrep(
        flat_phi,
        generators,
        group_name=group_name,
        max_norm=max_norm,
    )

    return exp_batch.reshape(H, W, K, K)


def get_exp_phi(phi_field, generators, group_name=None, n_jobs=-1, verbose=False):
    """
    Compute exp(φ) = exp(∑ φ^a G_a) for a batch of Lie algebra coefficients.

    Args:
        phi_field : (..., d) Lie algebra coefficients
        generators: (d, K, K) Lie algebra generators
        group_name: Optional string for group structure ("so3", "su2", etc.)
        n_jobs    : Parallel jobs (default = all cores)
        verbose   : Whether to print clipping info

    Returns:
        exp_phi : (..., K, K) matrix exponentials
    """
    

    *batch_shape, d = phi_field.shape
    K = generators.shape[-1]
    phi_flat = phi_field.reshape(-1, d)  # (N, d)
    N = phi_flat.shape[0]

    # ───── Clip φ vectors ─────
    max_norm = getattr(config, "phi_exp_clip", 10.0)
    norm_type = getattr(config, "gradient_clip_norm_type", 2)
    eps = 1e-16

    norms = np.linalg.norm(phi_flat, axis=1, ord=norm_type)
    scale_factors = np.minimum(1.0, max_norm / (norms + eps))
    phi_clipped = phi_flat * scale_factors[:, None]

    if verbose and np.any(scale_factors < 1.0):
        print(f"[exp φ] Clipped {np.sum(scale_factors < 1)} / {N} φ vectors to ‖φ‖ ≤ {max_norm}")

    # ───── Parallel expm computation ─────
    def single_expm(phi_vec):
        G = sum(phi_vec[a] * generators[a] for a in range(d))  # (K, K)
        return adaptive_expm(G, group_name=group_name)

    exp_list = Parallel(n_jobs=n_jobs)(
        delayed(single_expm)(phi_clipped[i]) for i in range(N)
    )

    return np.stack(exp_list, axis=0).reshape(*batch_shape, K, K)



def adaptive_expm(G, clip_norm=None, max_norm=None, threshold=1e-3, group_name=None):
    """
    Rescales G to prevent instability, then exponentiates:
      - 4th-order Taylor for small ‖G‖
      - expm(G) otherwise

    Parameters:
        G: (K, K) Lie algebra matrix
        clip_norm: soft cap (rescales only if ‖G‖ > clip_norm)
        max_norm: hard cap (always rescales if ‖G‖ > max_norm)
        threshold: use Taylor below this norm
        group_name: optional group structure (e.g. "so3", "su2")

    Returns:
        exp(G): (K, K) matrix
    """
    norm_G = np.linalg.norm(G) + 1e-16

    if clip_norm and norm_G > clip_norm:
        G *= clip_norm / norm_G
    if max_norm and norm_G > max_norm:
        G *= max_norm / norm_G

    # Optional antisymmetrization
    if group_name == "so3":
        G = 0.5 * (G - G.T)
    elif group_name == "su2":
        G = 0.5 * (G - G.T.conj())

    if norm_G < threshold:
        I = np.eye(G.shape[0], dtype=G.dtype)
        G2 = G @ G
        G3 = G2 @ G
        G4 = G3 @ G
        return I + G + 0.5 * G2 + (1/6) * G3 + (1/24) * G4
    else:
        return expm(G)


def exp_lie_algebra_irrep(
    v_batch,
    generators,
    use_expm=True,
    threshold=1e-3,
    max_norm=None,
    group_name=None,
    n_jobs=-1,
    verbose=False
):
    """
    Compute batch of exp(sum_a v[a] * T_a) using Taylor or expm depending on norm.

    Parameters:
        v_batch: (..., dim_G) Lie algebra coefficients
        generators: (dim_G, K, K) Lie algebra generators
        use_expm: fallback to expm if large-norm
        threshold: Taylor cutoff
        max_norm: optional clip threshold (fallback to config.phi_exp_clip)
        group_name: used for antisymmetrization ("so3", "su2", etc)
        n_jobs: parallel expm if large batch
        verbose: whether to print clipping info

    Returns:
        (..., K, K) exponentiated matrices
    """
    
    *batch_shape, dim_G = v_batch.shape
    v_flat = v_batch.reshape(-1, dim_G)
    N = v_flat.shape[0]
    _, K, _ = generators.shape
    dtype = v_batch.dtype

    # ─── Clip large φ vectors ─────────────────────────────────────────────
    clip_norm = (
        max_norm
        if max_norm is not None
        else getattr(config, "phi_exp_clip", 10.0)
    )
    norm_type = getattr(config, "gradient_clip_norm_type", 2)
    eps = 1e-16

    norms = np.linalg.norm(v_flat, axis=1, ord=norm_type)
    scale_factors = np.minimum(1.0, clip_norm / (norms + eps))
    v_scaled = v_flat * scale_factors[:, None]

    if verbose and np.any(scale_factors < 1.0):
        print(f"[Ω] Clipped {np.sum(scale_factors < 1)} / {N} φ vectors to ‖φ‖ ≤ {clip_norm}")

    # ─── Build algebra elements ───────────────────────────────────────────
    G_batch = np.einsum("na,aij->nij", v_scaled, generators)

    if group_name == "so3":
        G_batch = 0.5 * (G_batch - np.transpose(G_batch, axes=(0, 2, 1)))
    elif group_name == "su2":
        G_batch = 0.5 * (G_batch - np.transpose(G_batch, axes=(0, 2, 1)).conj())

    result = np.empty((N, K, K), dtype=dtype)
    approx_mask = norms * scale_factors < threshold

    # ─── Use Taylor expansion for small matrices ──────────────────────────
    if np.any(approx_mask):
        G_approx = G_batch[approx_mask]
        I = np.eye(K, dtype=dtype)[None, :, :]
        G2 = G_approx @ G_approx
        G3 = G2 @ G_approx
        G4 = G2 @ G2
        result[approx_mask] = (
            I + G_approx + 0.5 * G2 + (1.0 / 6.0) * G3 + (1.0 / 24.0) * G4
        )

    # ─── Fallback expm for heavy matrices ─────────────────────────────────
    if np.any(~approx_mask):
        idxs = np.flatnonzero(~approx_mask)
        G_heavy = [G_batch[i] for i in idxs]
        
        with parallel_backend("threading"):
            expm_results = Parallel(n_jobs=n_jobs)(
                delayed(adaptive_expm)(
                    G, clip_norm=None, max_norm=clip_norm, threshold=threshold
                ) for G in G_heavy
            )
        for i, res in zip(idxs, expm_results):
            result[i] = res

    return result.reshape(*batch_shape, K, K)

def d_exp_phi_exact(phi_vec, generators, num_points=10):
    """
    Compute ∂/∂φ^a e^{φ} exactly using numerical quadrature:
        ∂_a e^{φ} = ∫₀¹ e^{sφ} G_a e^{(1−s)φ} ds

    Args:
        phi_vec   : (..., d), Lie algebra coefficients φ^a
        generators: (d, K, K), generator matrices G_a
        num_points: number of quadrature points (default 10)

    Returns:
        d_exp_list: list of (..., K, K) arrays, one for each ∂ e^φ / ∂ φ^a
    """
    d, K, _ = generators.shape
    shape = phi_vec.shape[:-1]

    # ───── Construct φ matrix ─────
    phi_mat = np.zeros(shape + (K, K), dtype=float)
    for a in range(d):
        phi_mat += phi_vec[..., a][..., None, None] * generators[a]

    # ───── Quadrature rule (trapezoidal) ─────
    s_vals = np.linspace(0, 1, num_points)
    w_vals = np.ones(num_points)
    w_vals[0] = w_vals[-1] = 0.5
    w_vals /= (num_points - 1)

    # ───── Compute ∂ e^φ / ∂ φ^a for each generator ─────
    d_exp_list = []
    for a in range(d):
        G_a = generators[a]
        grad = np.zeros_like(phi_mat)

        for s, w in zip(s_vals, w_vals):
            for idx, _ in np.ndenumerate(phi_vec[..., 0]):
                exp_s_phi   = expm(s * phi_mat[idx])
                exp_1ms_phi = expm((1 - s) * phi_mat[idx])
                grad[idx]  += w * (exp_s_phi @ G_a @ exp_1ms_phi)

        d_exp_list.append(grad)

    return d_exp_list  # list of (..., K, K) arrays




def d_exp_phi_tilde_exact(phi_tilde_vec, generators, num_points=10):
    """
    Compute ∂ e^{φ̃} / ∂ φ̃^a exactly via numerical quadrature.

    Args:
        phi_tilde_vec : (..., d), Lie algebra coords for φ̃
        generators    : (d, K, K)
        num_points    : quadrature resolution (e.g., 10)

    Returns:
        d_exp_list : list of (..., K, K), ∂ e^{φ̃} / ∂ φ̃^a
    """
    d, K, _ = generators.shape
    shape = phi_tilde_vec.shape[:-1]

    phi_mat = np.zeros(shape + (K, K), dtype=float)
    for a in range(d):
        phi_mat += phi_tilde_vec[..., a][..., None, None] * generators[a]

    # Precompute quadrature rule
    s_vals = np.linspace(0, 1, num_points)
    w_vals = np.ones(num_points)
    w_vals[0] = w_vals[-1] = 0.5  # trapezoidal rule
    w_vals /= (num_points - 1)

    # Compute ∂ e^{φ̃} / ∂ φ̃^a
    d_exp_list = []
    for a in range(d):
        G_a = generators[a]
        grad = np.zeros_like(phi_mat)
        for s, w in zip(s_vals, w_vals):
            for idx, _ in np.ndenumerate(phi_tilde_vec[..., 0]):
                exp_s_phi   = expm(s * phi_mat[idx])
                exp_1ms_phi = expm((1 - s) * phi_mat[idx])
                grad[idx]  += w * (exp_s_phi @ G_a @ exp_1ms_phi)
        d_exp_list.append(grad)

    return d_exp_list

def exact_grad_Omega(phi_i, phi_j, generators, num_points=10):
    """
    Compute ∂Ω_{ij}/∂φ_i^a and ∂Ω_{ij}/∂φ_j^a exactly using quadrature.

    Args:
        phi_i, phi_j : (..., d), Lie algebra coords
        generators   : (d, K, K)
        num_points   : quadrature resolution

    Returns:
        d_Omega_phi_i : list of (..., K, K) arrays (∂Ω/∂φ_i^a)
        d_Omega_phi_j : list of (..., K, K) arrays (∂Ω/∂φ_j^a)
    """
    from scipy.linalg import expm
    import numpy as np

    # Compute exp maps
    exp_phi_i = np.zeros(phi_i.shape[:-1] + generators.shape[1:], dtype=float)
    exp_phi_j = np.zeros_like(exp_phi_i)

    for a in range(generators.shape[0]):
        exp_phi_i += phi_i[..., a][..., None, None] * generators[a]
        exp_phi_j += phi_j[..., a][..., None, None] * generators[a]

    exp_phi_i = np.vectorize(expm, signature="(k,k)->(k,k)")(exp_phi_i)
    exp_phi_j = np.vectorize(expm, signature="(k,k)->(k,k)")(exp_phi_j)
    exp_minus_phi_j = np.vectorize(expm, signature="(k,k)->(k,k)")(-exp_phi_j)

    # Compute Ω_{ij}
    Omega_ij = np.einsum("...ik,...kj->...ij", exp_phi_i, exp_minus_phi_j)

    # Compute d_exp terms
    d_exp_i = d_exp_phi_exact(phi_i, generators, num_points)
    d_exp_j = d_exp_phi_exact(phi_j, generators, num_points)

    d_Omega_phi_i = [np.einsum("...ik,...kj->...ij", dEi, exp_minus_phi_j) for dEi in d_exp_i]
    d_Omega_phi_j = [
        -np.einsum("...ik,...kl,...lj->...ij", exp_phi_i, dEj, exp_minus_phi_j)
        for dEj in d_exp_j
    ]

    return d_Omega_phi_i, d_Omega_phi_j
