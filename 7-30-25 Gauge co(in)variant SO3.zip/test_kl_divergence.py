import numpy as np
from generalized_math_utils import kl_divergence
from natural_params_utils import mean_from_natural, cov_from_natural

def test_kl_self_consistency():
    K = 3
    N = 5
    eta1 = np.random.randn(N, K)
    eta2 = -0.5 * np.tile(np.eye(K), (N, 1, 1))
    kl = kl_divergence(eta1, eta2, eta1, eta2)
    assert np.allclose(kl, 0.0, atol=1e-6), "KL divergence should be zero for identical inputs"