

from generalized_agent_schema import Agent
from update_rules import preprocess_agent_fields
from get_generators import get_generators
import numpy as np

def test_preprocess_minimal_agent():
    H, W, K = 10, 10, 3
    mask = np.zeros((H, W))
    mask[4:7, 4:7] = 1
    eta1 = np.ones((H, W, K))
    eta2 = -0.5 * np.eye(K)[None, None, :, :]
    eta2 = np.tile(eta2, (H, W, 1, 1))

    agent = Agent(
        id=0,
        center=(5, 5),
        radius=1.5,
        mask=mask,
        phi=np.zeros((H, W, 3)),
        phi_model=np.zeros((H, W, 3)),
        eta1_q_field=eta1.copy(),
        eta2_q_field=eta2.copy(),
        eta1_p_field=eta1.copy(),
        eta2_p_field=eta2.copy(),
    )

    # Inject generators using your get_generators function
    agent.rho_q_func = type("Obj", (), {"generators": get_generators("so3", K)})
    agent.rho_p_func = type("Obj", (), {"generators": get_generators("so3", K)})

    preprocess_agent_fields(agent, {})
    assert agent._exp_phi is not None
    assert agent._exp_phi_model is not None
