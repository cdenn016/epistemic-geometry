import pytest

if __name__ == "__main__":
    # Run all tests in the current directory
    result = pytest.main(["-v", "."])
    if result == 0:
        print("\n✅ All tests passed.")
    else:
        print("\n❌ Some tests failed.")