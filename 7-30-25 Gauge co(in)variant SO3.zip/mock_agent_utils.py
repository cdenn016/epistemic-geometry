
import numpy as np
from generalized_agent_schema import Agent
from natural_params_utils import compute_natural_from_mu_sigma

def build_mock_agent_pair(domain_shape=(8, 8), K_q=3, K_p=3):
    H, W = domain_shape

    mask = np.ones((H, W), dtype=bool)
    center = (H // 2, W // 2)
    radius = min(H, W) / 2.0

    mu_q = np.zeros((H, W, K_q))
    sigma_q = np.tile(np.eye(K_q)[None, None, :, :], (H, W, 1, 1))
    eta1_q, eta2_q = compute_natural_from_mu_sigma(mu_q, sigma_q)

    mu_p = np.zeros((H, W, K_p))
    sigma_p = np.tile(np.eye(K_p)[None, None, :, :], (H, W, 1, 1))
    eta1_p, eta2_p = compute_natural_from_mu_sigma(mu_p, sigma_p)

    phi = np.zeros((H, W, 3))
    phi_model = np.zeros((H, W, 3))

    A = Agent(id=0, center=center, radius=radius, mask=mask, phi=phi, phi_model=phi_model,
              eta1_q_field=eta1_q, eta2_q_field=eta2_q, eta1_p_field=eta1_p, eta2_p_field=eta2_p)

    B = Agent(id=1, center=center, radius=radius, mask=mask, phi=phi, phi_model=phi_model,
              eta1_q_field=eta1_q.copy(), eta2_q_field=eta2_q.copy(),
              eta1_p_field=eta1_p.copy(), eta2_p_field=eta2_p.copy())

    return A, B
