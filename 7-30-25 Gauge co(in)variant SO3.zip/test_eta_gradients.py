import numpy as np
from generalized_math_utils import kl_divergence

def finite_diff_grad_eta1(eta1_q, eta2_q, eta1_r, eta2_r, eps=1e-5):
    grads = np.zeros_like(eta1_q)
    for i in range(eta1_q.shape[-1]):
        eta1_perturb = eta1_q.copy()
        eta1_perturb[..., i] += eps
        kl_plus = kl_divergence(eta1_perturb, eta2_q, eta1_r, eta2_r)
        eta1_perturb[..., i] -= 2 * eps
        kl_minus = kl_divergence(eta1_perturb, eta2_q, eta1_r, eta2_r)
        grads[..., i] = (kl_plus - kl_minus) / (2 * eps)
    return grads

def test_finite_diff_eta1():
    K = 3
    eta1_q = np.random.randn(1, K)
    eta2_q = -0.5 * np.eye(K)[None, :, :]
    grads = finite_diff_grad_eta1(eta1_q, eta2_q, eta1_q, eta2_q)
    assert grads.shape == eta1_q.shape