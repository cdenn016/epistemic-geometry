import numpy as np
from generalized_omega import exp_lie_algebra_irrep
from get_generators import get_generators

def test_identity_omega():
    phi = np.zeros((1, 3))
    G = get_generators("so3", 3)
    O_i = exp_lie_algebra_irrep(phi, G)[0]
    O_j = exp_lie_algebra_irrep(phi, G)[0]
    Omega = O_i @ O_j.T
    assert np.allclose(Omega, np.eye(3), atol=1e-6), "Ω should be identity when φ_i = φ_j"