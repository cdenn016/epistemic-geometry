# -*- coding: utf-8 -*-
"""
Created on Wed Jul 30 11:06:13 2025

@author: chris and christine
"""

# test_synchronous_step_known.py

import numpy as np
from generalized_agent_schema import Agent
from update_rules import synchronous_step
from generalized_diagnostics_metrics import compute_alignment_field_general
from numerical_utils import sanitize_eta2
from get_generators import get_generators  # alias for get_generators('sl2r', K)

import numpy as np
from update_terms_eta1_eta2_belief import accumulate_eta_gradient_belief
from update_terms_eta1_eta2_model import accumulate_eta_gradient_model
from update_terms_phi import accumulate_phi_gradient_belief, accumulate_phi_gradient_model
from update_terms_morphisms import (
    accumulate_phi_gradient_from_morphism_self_and_feedback,
    accumulate_phi_tilde_gradient_from_morphism_self_and_feedback,
)
from generalized_agent_schema import Agent

import config


def make_dummy_agent(H, W, K, id=0, phi_zero=True):
    mask = np.zeros((H, W))
    mask[2:5, 2:5] = 1.0
    eta1 = np.ones((H, W, K))
    eta2 = -0.5 * np.eye(K)[None, None, :, :]
    eta2 = np.tile(eta2, (H, W, 1, 1))

    phi = np.zeros((H, W, 3)) if phi_zero else np.random.randn(H, W, 3)

    agent = Agent(
        id=id,
        center=(4, 4),
        radius=1.5,
        mask=mask,
        phi=phi,
        phi_model=phi.copy(),
        eta1_q_field=eta1.copy(),
        eta2_q_field=eta2.copy(),
        eta1_p_field=eta1.copy(),
        eta2_p_field=eta2.copy(),
    )


    G_q = get_generators(config.group_name, config.K_q)
    G_p = get_generators(config.group_name, config.K_p)

    agent.rho_q_func = type("ρ", (), {"generators": G_q})
    agent.rho_p_func = type("ρ", (), {"generators": G_p})

    # ── Static morphism: identity-like (must match K_q, K_p) ──
    K_q = config.K_q
    K_p = config.K_p
    morphism = np.zeros((H, W, K_p, K_q))
    for i in range(min(K_q, K_p)):
        morphism[..., i, i] = 1.0
    agent.static_morphism_q_to_p = morphism  # ✅ outside the loop!
    print("STATIC MORPHISM SHAPE:", agent.static_morphism_q_to_p.shape)
    agent.bundle_morphism_q_to_p = agent.static_morphism_q_to_p
    agent.bundle_morphism_p_to_q = np.swapaxes(agent.static_morphism_q_to_p, -2, -1)  # (H,W,K_q,K_p)

    return agent

from numerical_utils import safe_inv


def test_eta_gradients():
    A = make_dummy_agent(8, 8, config.K_q, id=0)
    B = make_dummy_agent(8, 8, config.K_q, id=1)
    A.neighbors = [{"id": 1}]
    B.neighbors = [{"id": 0}]
    agents = [A, B]

    from omega import compute_exp_field
    from update_terms_morphisms import update_dynamic_morphisms

    # Attach exp(φ) and exp(−φ) to each agent
    for agent in agents:
        agent._exp_phi = compute_exp_field(agent.phi, agent.rho_q_func.generators, scale = 1)
        agent._exp_neg_phi = safe_inv(compute_exp_field(agent.phi, agent.rho_q_func.generators,scale=1))

    # Initialize Φ and Φ̃ using current φ, φ̃
    for agent in agents:
        update_dynamic_morphisms(agent, agent.rho_q_func.generators, agent.rho_p_func.generators)

    print("Testing belief η-gradients...")
    accumulate_eta_gradient_belief(A, agents, {})
    print("η₁_q ∇ norm:", np.linalg.norm(A.grad_eta1_q_field))
    print("η₂_q ∇ norm:", np.linalg.norm(A.grad_eta2_q_field))

    print("Testing model η-gradients...")
    accumulate_eta_gradient_model(A, agents, {})
    print("η₁_p ∇ norm:", np.linalg.norm(A.grad_eta1_p_field))
    print("η₂_p ∇ norm:", np.linalg.norm(A.grad_eta2_p_field))


def test_phi_gradients():
    A = make_dummy_agent(8, 8, config.K_q, id=0)
    B = make_dummy_agent(8, 8, config.K_q, id=1)
    A.neighbors = [{"id": 1}]
    B.neighbors = [{"id": 0}]
    agents = [A, B]

    print("Testing φ belief ∇...")
    accumulate_phi_gradient_belief(A, B, A.rho_q_func.generators, {})
    print("φ belief ∇ norm:", np.linalg.norm(A.grad_phi))

    print("Testing φ model ∇...")
    accumulate_phi_gradient_model(A, B, A.rho_p_func.generators, {})
    print("φ model ∇ norm:", np.linalg.norm(A.grad_phi_model))


def test_phi_from_morphisms():
    A = make_dummy_agent(8, 8, config.K_q, id=0)
    print("Testing φ from morphism self + feedback...")
    accumulate_phi_gradient_from_morphism_self_and_feedback(A, A.rho_p_func.generators, A.rho_q_func.generators, {})
    print("φ morphism ∇ norm:", np.linalg.norm(A.grad_phi))

    print("Testing φ̃ from morphism self + feedback...")
    accumulate_phi_tilde_gradient_from_morphism_self_and_feedback(A, A.rho_p_func.generators, A.rho_q_func.generators, {})
    print("φ̃ morphism ∇ norm:", np.linalg.norm(A.grad_phi_model))


if __name__ == "__main__":
    
    
    test_eta_gradients()
    test_phi_gradients()
    test_phi_from_morphisms()
