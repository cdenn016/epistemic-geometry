import numpy as np
from natural_params_utils import mean_from_natural, cov_from_natural

def test_eta_mu_sigma_inverse():
    K = 3
    N = 5
    eta1 = np.random.randn(N, K)
    eta2 = -0.5 * np.tile(np.eye(K), (N, 1, 1))
    mu = mean_from_natural(eta1, eta2)
    Sigma = cov_from_natural(eta1, eta2)
    assert mu.shape == (N, K)
    assert Sigma.shape == (N, K, K)