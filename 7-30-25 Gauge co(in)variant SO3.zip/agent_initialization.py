# -*- coding: utf-8 -*-
"""
Created on Thu Jul 24 17:54:26 2025

@author: chris and christine
"""
from scipy.ndimage import gaussian_filter
from scipy.ndimage import distance_transform_edt
import config
import scipy
import numpy as np
from mask_utils import create_agent_mask
from agent_distributions import generate_eta1_eta2_fields, rotate_eta_fields_via_phi_safe

from generalized_agent_schema import Agent

from bundle_morphism_utils import initialize_morphism_pair

from get_generators import get_generators, RhoFunction, build_rho_so3
from numerical_utils import sanitize_sigma, check_spd_field
from mask_utils import create_agent_mask

import config



def initialize_agents(
    seed: int,
    domain_size: tuple[int, ...],
    N: int,
    K_q: int,
    K_p: int,
    lie_algebra_dim: int,
    visualize: bool = False,
    fixed_location: bool = True,
    params=None,
) -> list:
    """
    Modular initialization of N agents with Gaussian beliefs, models, morphisms, φ, and neighbor structure.
    Uses only natural parameters (η₁, η₂); μ, Σ are computed on demand.
    """
    from numpy.random import default_rng
    from natural_params_utils import safe_inv, sanitize_eta2
    rng = default_rng(seed)
    dtype = getattr(config, "dtype", np.float32)
    cfg = {k: getattr(config, k) for k in dir(config) if not k.startswith("__")}
    mu_clip = cfg.get("mu_clip", 3.0)

    phi_init         = cfg["phi_init"]
    phi_model_offset = cfg.get("phi_model_offset", 0.1)
    max_neighbors    = cfg.get("max_neighbors", 8)
    overlap_eps      = cfg.get("overlap_eps", 1e-3)

    delta_eta1 = cfg.get("delta_eta1", 0.01)
    delta_eta2 = cfg.get("delta_eta2", 0.005)

    group_name = cfg.get("group_name", "so3")
    rho_q_func = build_rho_so3(K_q)
    rho_p_func = build_rho_so3(K_p)
    G_q = get_generators(group_name, K_q)  # ✅ returns array (3, K_q, K_q)
    G_p = get_generators(group_name, K_p)  # ✅ returns array (3, K_p, K_p)




    fixed_center = tuple(s // 2 for s in domain_size) if fixed_location else None
    agents = []

    for n in range(N):
        # ── Mask + center ──
        center, radius, mask, mask_bool = create_agent_mask_and_center(
            domain_size, rng,
            radius_range=cfg.get("agent_radius_range", (5, 10)),
            fixed_center=fixed_center
        )

        # ── q fields (η) ──
        eta1_q_diag, eta2_q_diag = generate_eta1_eta2_fields(
            domain_size=domain_size,
            rng=rng,
            K=K_q,
            eta1_range=config.q_eta1_range,
            eta2_range=config.q_eta2_range,
            mask=mask,
            sigma_outside_val=cfg.get("sigma_outside_val", -0.01),
            dtype=dtype,
            smooth_sigma=cfg.get("init_smooth_sigma", 2.0),
            floor=cfg.get("eta2_floor", -0.5),
            eps=cfg.get("eta2_min_eigval", 1e-4),
        )

        # Correct: Generate p-fields from scratch with K_p dimensionality
        eta1_p_diag, eta2_p_diag = generate_eta1_eta2_fields(
            domain_size=domain_size,
            rng=rng,
            K=K_p,
            eta1_range=config.p_eta1_range,   # use model-specific config range
            eta2_range=config.p_eta2_range,
            mask=mask,
            sigma_outside_val=cfg.get("sigma_outside_val", -0.01),
            dtype=dtype,
            smooth_sigma=cfg.get("init_smooth_sigma", 2.0),
            floor=cfg.get("eta2_floor", -0.5),
            eps=cfg.get("eta2_min_eigval", 1e-4),
            )


        # Step 1: recompute Sigma_p and clamp μ_p to same range
        Sigma_p = -0.5 * safe_inv(eta2_p_diag, eps=cfg.get("eta2_min_eigval", 1e-4))
        mu_p = np.einsum("...ij,...j->...i", Sigma_p, eta1_p_diag)
        mu_p = np.clip(mu_p, -mu_clip, mu_clip)
        eta1_p_diag = np.einsum("...ij,...j->...i", -2.0 * eta2_p_diag, mu_p)

# Step 2: normalize η2_p trace
        trace_eta2_p = -np.trace(eta2_p_diag, axis1=-2, axis2=-1)  # (H, W)
        target_trace = config.K_p * np.mean(np.abs(config.q_eta2_range))    # same as for q
        eta2_p_diag *= target_trace / (trace_eta2_p[..., None, None] + 1e-8)

# Step 3: sanitize
        eta2_p_diag = sanitize_eta2(eta2_p_diag, floor=cfg.get("eta2_floor", -0.5), eps=cfg.get("eta2_min_eigval", 1e-4))


        # ── φ and φ̃ ──
        phi, phi_model = initialize_phi_pair(
            domain_size, lie_algebra_dim, rng,
            phi_init, phi_model_offset, mask
        )

        # ── Rotate η fields ──
        eta1_q, eta2_q = rotate_eta_fields_via_phi_safe(eta1_q_diag, eta2_q_diag, phi, G_q)
        eta1_p, eta2_p = rotate_eta_fields_via_phi_safe(eta1_p_diag, eta2_p_diag, phi_model, G_p)

        # ── Reproject μ and sanitize η₂ ──
        def project_and_sanitize(eta1, eta2, K):
            Sigma = -0.5 * safe_inv(eta2, eps=1e-6)
            mu = np.einsum("...ij,...j->...i", Sigma, eta1)
            mu = np.clip(mu, -3.0, 3.0)
            eta1 = np.einsum("...ij,...j->...i", -2.0 * eta2, mu)
            trace = -np.trace(eta2, axis1=-2, axis2=-1)[..., None, None]
            target_trace = K * np.mean(np.abs(config.q_eta2_range))
            eta2 = eta2 * (target_trace / (trace + 1e-8))
            eta2 = sanitize_eta2(eta2, floor=config.eta2_floor, eps=config.eta2_min_eigval)
            return eta1, eta2

        eta1_q, eta2_q = project_and_sanitize(eta1_q, eta2_q, K_q)
        eta1_p, eta2_p = project_and_sanitize(eta1_p, eta2_p, K_p)

        # ── Construct agent ──
        agent = construct_agent_object(
            agent_id=n,
            center=center,
            radius=radius,
            mask=mask,
            eta1_q=eta1_q, eta2_q=eta2_q,
            eta1_p=eta1_p, eta2_p=eta2_p,
            phi=phi, phi_model=phi_model,
            dtype=dtype
        )

# ── Assign rho functions ──
        # ── Assign rho functions (SO(3)) ──
        agent.rho_q_func = rho_q_func
        agent.rho_p_func = rho_p_func
        agent.generators_q = G_q
        agent.generators_p = G_p


# ── Bundle morphisms Φ and Φ̃ ──
        morphism_type = cfg.get("phi_morphism_type", "identity")
        phi_q_to_p, phi_p_to_q = initialize_morphism_pair(
            domain_size=domain_size,
            K_q=K_q,
            K_p=K_p,
            rng=rng,
            mask=agent.mask,
            morphism_type=morphism_type,
            config_tag="",
            phi_q_field=phi,
            phi_p_field=phi_model,
            rho_q_func=rho_q_func,
            rho_p_func=rho_p_func
            )

        agent.bundle_morphism_q_to_p = phi_q_to_p
        agent.bundle_morphism_p_to_q = phi_p_to_q
        agent.dynamic_morphism_q_to_p = None
        agent.dynamic_morphism_p_to_q = None


        # ── Initialize gradients ──
        initialize_agent_gradients(agent, config)

        agents.append(agent)

    # ── Neighbor structure ──
    assign_neighbors_vectorized(agents, overlap_eps=overlap_eps, max_neighbors=max_neighbors)
    validate_agents(agents)

    return agents



def scale_to_range(
    field: np.ndarray,
    value_range: tuple[float, float]
) -> np.ndarray:
    """
    Linearly remap `field` so that field.min()→value_range[0], field.max()→value_range[1].
    If field is constant, fill with the midpoint of the range.
    Output dtype is taken from config.dtype.
    """
    lo, hi = value_range
    fmin, fmax = field.min(), field.max()
    dtype = getattr(config, 'dtype', field.dtype)
    if fmax <= fmin:
        return np.full_like(field, (lo + hi) / 2, dtype=dtype)

    # normalize to [0,1]
    norm = (field - fmin) / (fmax - fmin)
    # scale to [lo, hi]
    out = norm * (hi - lo) + lo
    return out.astype(dtype)






def initialize_phi_field(
    domain_size: tuple[int, ...],
    lie_algebra_dim: int,
    rng: np.random.Generator,
    init_scale: float,
    mask: np.ndarray,
    smooth_sigma: float = None
) -> np.ndarray:
    """
    Initialize and smooth a φ field with Gaussian noise and apply mask.
    """
    dtype = getattr(config, 'dtype', mask.dtype)
    sigma = smooth_sigma or getattr(config, 'phi_init_smooth_sigma', 0.5)

    phi_raw = rng.normal(scale=init_scale, size=(*domain_size, lie_algebra_dim)).astype(dtype)
    phi_smooth = gaussian_filter(phi_raw, sigma=sigma)
    return phi_smooth * mask[..., None]


def initialize_phi_pair(
    domain_size: tuple[int, ...],
    lie_algebra_dim: int,
    rng: np.random.Generator,
    phi_init: float,
    phi_model_offset: float,
    mask: np.ndarray
) -> tuple[np.ndarray, np.ndarray]:
    """
    Initialize φ and φ̃ (belief and model) with optional offset for φ̃.

    If config.identical_models is True, then φ̃ = 0 identically.
    If phi_model_offset == 0.0, then φ̃ is also initialized as zero.
    Otherwise, φ̃ = φ + Gaussian noise (smoothed), masked to agent region.
    """
    phi = initialize_phi_field(domain_size, lie_algebra_dim, rng, phi_init, mask)

    if getattr(config, "identical_models", False) or phi_model_offset == 0.0:
        phi_model = np.zeros_like(phi)
    else:
        delta = rng.normal(scale=phi_model_offset, size=(*domain_size, lie_algebra_dim)).astype(phi.dtype)
        phi_model_raw = phi + delta
        phi_model = gaussian_filter(
            phi_model_raw, sigma=getattr(config, 'phi_init_smooth_sigma', 0.5)
        )
        phi_model *= mask[..., None]

    return phi, phi_model


def assign_neighbors_vectorized(
    agents: list,
    overlap_eps: float,
    max_neighbors: int
) -> None:
    """
    Assigns neighbors to each agent by computing pairwise mask overlaps.
    Vectorized for efficiency.

    A pair (i, j) is considered overlapping if:
        overlap(i, j) > overlap_eps × num_pixels
    """
    if max_neighbors == 0:
        for agent in agents:
            agent.neighbors = []
        return

    N = len(agents)
    dtype = getattr(config, 'dtype', np.float32)

    # Flatten masks into (N, H×W)
    masks_flat = np.stack([agent.mask.flatten().astype(dtype) for agent in agents])

    # Compute pairwise overlap matrix
    overlap_matrix = masks_flat @ masks_flat.T  # shape: (N, N)
    pixel_thresh = overlap_eps * masks_flat.shape[1]

    # Boolean matrix: True if overlap > threshold
    above_thresh = overlap_matrix > pixel_thresh
    np.fill_diagonal(above_thresh, False)  # Exclude self-overlap

    for i in range(N):
        sorted_idx = np.argsort(-overlap_matrix[i])  # descending order
        valid_neighbors = [j for j in sorted_idx if above_thresh[i, j]]
        agents[i].neighbors = [{"id": j} for j in valid_neighbors[:max_neighbors]]

def plot_agent_overlap(agent_i, agent_j, cutoff=None):
    import matplotlib.pyplot as plt
    import numpy as np
    import config

    if cutoff is None:
        cutoff = getattr(config, "support_cutoff_eps", 1e-3)

    mask_i  = agent_i.mask > cutoff
    mask_j  = agent_j.mask > cutoff
    overlap = mask_i & mask_j

    if mask_i.ndim != 2:
        raise ValueError(f"plot_agent_overlap only supports 2D spatial domains, got shape {mask_i.shape}")

    H, W = mask_i.shape

    fig, axs = plt.subplots(1, 3, figsize=(12, 4))

    for ax, M, title in zip(
        axs,
        [mask_i, mask_j, overlap],
        [f"Agent {agent_i.id} Support",
         f"Agent {agent_j.id} Support",
         "Overlap"]
    ):
        ax.imshow(
            M,
            cmap="gray",
            origin="lower",
            extent=[0, W, 0, H],
            interpolation="nearest"
        )
        ax.set_title(title)
        ax.set_xticks([0, W//2, W])
        ax.set_yticks([0, H//2, H])

    plt.tight_layout()
    plt.show()

def construct_agent_object(
    agent_id,
    center,
    radius,
    mask,
    eta1_q, eta2_q,
    eta1_p, eta2_p,
    phi, phi_model,
    dtype=np.float32
) -> Agent:
    """
    Build an Agent object from natural parameters only.
    μ and Σ are computed on demand to ensure gauge invariance.

    Args:
        agent_id   : int
        center     : (int, int)
        radius     : float
        mask       : (H, W)
        eta1_q, eta2_q : natural parameters for q (H, W, K_q), (H, W, K_q, K_q)
        eta1_p, eta2_p : natural parameters for p (H, W, K_p), (H, W, K_p, K_p)
        phi, phi_model : (..., d) gauge fields
        dtype      : float32/float64

    Returns:
        Agent
    """
    return Agent(
        id=agent_id,
        center=center,
        radius=radius,
        mask=mask.astype(dtype),

        eta1_q_field=eta1_q.astype(dtype),
        eta2_q_field=eta2_q.astype(dtype),
        eta1_p_field=eta1_p.astype(dtype),
        eta2_p_field=eta2_p.astype(dtype),

        phi=phi.astype(dtype),
        phi_model=phi_model.astype(dtype),

        neighbors=[]
    )




def create_agent_mask_and_center(domain_size, rng, radius_range, fixed_center=None):
    """
    Sample agent center and radius, and generate its soft mask.

    Args:
        domain_size  : tuple[int, int] = (H, W)
        rng          : np.random.Generator
        radius_range : (float, float)
        fixed_center : optional tuple[int, int]

    Returns:
        center : (int, int) coordinates of agent center
        radius : float
        mask   : (H, W) soft float32 mask
        mask_bool : (H, W) boolean version of mask for edge decay
    """
    radius = rng.uniform(*radius_range)
    center = fixed_center or tuple(rng.integers(0, s) for s in domain_size)
    mask = create_agent_mask(center, radius, domain_size)
    return center, radius, mask.astype(np.float32), mask.astype(bool)



def initialize_agent_gradients(agent, config):
    """
    Initialize all gradient fields for the agent using the shapes of eta fields.
    Should be called once after the agent is created and eta fields are populated.
    """
    # Natural gradient fields (belief)
    agent.grad_eta1_q_field = np.zeros_like(agent.eta1_q_field)
    agent.grad_eta2_q_field = np.zeros_like(agent.eta2_q_field)

    # Natural gradient fields (model)
    agent.grad_eta1_p_field = np.zeros_like(agent.eta1_p_field)
    agent.grad_eta2_p_field = np.zeros_like(agent.eta2_p_field)

    # Gauge field gradients
    agent.grad_phi = np.zeros_like(agent.phi)
    agent.grad_phi_tilde = np.zeros_like(agent.phi_model)

    # Morphism gradients — only if the morphisms exist
    agent.grad_Phi = (
        np.zeros_like(agent.bundle_morphism_q_to_p)
        if agent.bundle_morphism_q_to_p is not None else None
    )
    agent.grad_Phi_tilde = (
        np.zeros_like(agent.bundle_morphism_p_to_q)
        if agent.bundle_morphism_p_to_q is not None else None
    )




def validate_agents(agents: list) -> None:
    """
    Run validation checks on each agent's fields.
    Ensures η fields are finite, φ fields are finite, masks are valid.
    """
    support_eps = getattr(config, "support_cutoff_eps", 1e-4)
    debug = getattr(config, "debug", False)

    for agent in agents:
        support = agent.mask > support_eps

        if not np.all(np.isfinite(agent.eta1_q_field[support])):
            print(f"[VALIDATION] Agent {agent.id}: non-finite η₁_q inside mask")
        if not np.all(np.isfinite(agent.eta2_q_field[support])):
            print(f"[VALIDATION] Agent {agent.id}: non-finite η₂_q inside mask")
        if not np.all(np.isfinite(agent.eta1_p_field[support])):
            print(f"[VALIDATION] Agent {agent.id}: non-finite η₁_p inside mask")
        if not np.all(np.isfinite(agent.eta2_p_field[support])):
            print(f"[VALIDATION] Agent {agent.id}: non-finite η₂_p inside mask")
        if not np.all(np.isfinite(agent.phi[support])):
            print(f"[VALIDATION] Agent {agent.id}: non-finite φ values inside mask")
        if not np.all(np.isfinite(agent.phi_model[support])):
            print(f"[VALIDATION] Agent {agent.id}: non-finite φ̃ values inside mask")
        if not np.all((agent.mask >= 0) & (agent.mask <= 1)):
            print(f"[VALIDATION] Agent {agent.id}: mask contains invalid values outside [0,1]")

        if debug:
            eta1_min = agent.eta1_q_field[support].min()
            eta1_max = agent.eta1_q_field[support].max()
            eta2_norm = np.linalg.norm(agent.eta2_q_field[support])
            print(f"[DEBUG] Agent {agent.id}: η₁_q range = [{eta1_min:.3g}, {eta1_max:.3g}], "
                  f"‖η₂_q‖ = {eta2_norm:.3g}")

    print("[✓] Agent validation complete.")
