# -*- coding: utf-8 -*-
"""
Created on Mon Sep  8 17:40:08 2025

@author: chris and christine
"""

# updates/update_terms_vfe.py
from __future__ import annotations
import numpy as np
from runtime_context import ensure_theta, cfg_get
from core.numerical_utils import sanitize_sigma  # you already use this elsewhere




def _theta_stats_from_children(ctx):
    """
    Aggregate sufficient stats over current children for preconditioning:
      Sxx = sum m * (Σ_q + μ μ^T)
      Sx  = sum m * μ
      N   = sum m   (per-pixel counts)
    Returns (Sxx, Sx, N, K_latent).
    """
   
    agents = getattr(ctx, "children_latest", None) or []
    if not agents:
        return None, None, 0.0, None

    A0 = agents[0]
    K = int(A0.mu_q_field.shape[-1])
    Sxx = np.zeros((K, K), np.float32)
    Sx  = np.zeros((K,),   np.float32)
    N   = 0.0

    for a in agents:
        m   = np.asarray(a.mask, np.float32)               # (H,W)
        mu  = np.asarray(a.mu_q_field, np.float32)         # (H,W,K)
        Sig = np.asarray(a.sigma_q_field, np.float32)      # (H,W,K,K)

        w = m[..., None]                                   # (H,W,1)
        N += float(np.sum(m))

        # sum μ and (Σ + μμ^T)
        Sx  += np.sum(w * mu, axis=(0,1))
        # batch outer products: (H,W,K,1)*(H,W,1,K) -> (H,W,K,K)
        outer = mu[..., :, None] * mu[..., None, :]
        Sxx  += np.sum(Sig + outer, axis=(0,1)).astype(np.float32)

    return Sxx, Sx, N, K




def expected_nll_gaussian(
    y,                # (..., D)      in q-fiber observation space
    mu,               # (..., Kx)     either q-fiber (default) or p-fiber if Phi_tilde is given
    Sigma,            # (..., Kx,Kx)  covariance in the same fiber as mu
    W,                # (D, Kq)       decoder/observation matrix defined on q-fiber latent
    b,                # (D,)
    sigma2,           # scalar
    *,
    mask=None,
    Phi_tilde=None,   # optional (..., Kq, Kp) to map p → q (use this when mu/Sigma are p-fiber)
    sanitize_eps= 1e-8
):
    """
    E_q[-log p(y|x)] with optional bundle morphism to compare p against q.
    If Phi_tilde is provided, (mu,Sigma) are treated as p-fiber and are pushed to q:
        mu_q = Phi_tilde @ mu_p
        S_q  = Phi_tilde @ S_p @ Phi_tilde^T
    Then compute NLL in q using W,b,sigma2.

    Returns
    -------
    total : float
    pieces: tuple (r, WT_W, r2, tr_term)
    """
    y      = np.asarray(y,      np.float32)
    mu     = np.asarray(mu,     np.float32)
    Sigma  = np.asarray(Sigma,  np.float32)
    W      = np.asarray(W,      np.float32)
    b      = np.asarray(b,      np.float32)
    sigma2 = float(sigma2)

    if Phi_tilde is not None:
        # Map p → q
        Phi_tilde = np.asarray(Phi_tilde, np.float32)
        # μ_q = Φ̃ μ_p
        mu_q = np.einsum("...dk,...k->...d", Phi_tilde, mu, optimize=True).astype(np.float32)
        # Σ_q = Φ̃ Σ_p Φ̃^T
        S_q  = np.einsum("...dk,...kj,...ej->...de", Phi_tilde, Sigma, Phi_tilde, optimize=True)
        # sanitize SPD after push
        S_q  = sanitize_sigma(0.5*(S_q + np.swapaxes(S_q,-1,-2)).astype(np.float32), eps=sanitize_eps)
    else:
        # Already in q-fiber
        mu_q = mu
        S_q  = sanitize_sigma(0.5*(Sigma + np.swapaxes(Sigma,-1,-2)).astype(np.float32), eps=sanitize_eps)

    D = y.shape[-1]
    # residual r = (W μ_q + b) - y
    r  = (mu_q @ W.T) + b - y                 # (..., D)
    r2 = np.sum(r * r, axis=-1)               # (...)

    # tr(W Σ_q W^T) = tr(Σ_q W^T W)
    WT_W   = (W.T @ W).astype(np.float32)     # (Kq, Kq)
    tr_term = np.einsum("...ij,ij->...", S_q, WT_W, optimize=True)  # (...)

    const = 0.5 * D * np.log(2.0 * np.pi * max(sigma2, 1e-12))
    quad  = 0.5 * (r2 + tr_term) / max(sigma2, 1e-12)
    nll   = const + quad

    if mask is not None:
        nll = nll * np.asarray(mask, np.float32)

    total = float(np.sum(nll))
    return total, (r, WT_W, r2, tr_term)




def vfe_mu_sigma_grads(
    y, mu, Sigma, W, b, sigma2, *,
    mask=None,
    Phi_tilde=None,             # optional (..., Kq, Kp): map p→q when mu/Sigma live in p-fiber
    sigma2_min: float = 1e-6,
    grad_mu_clip: float | None = 5.0,
    grad_S_clip: float | None = 5.0,
    sanitize_eps: float = 1e-8
):
    """
    Robust Euclidean grads wrt mu, Sigma for E_q[-log p(y|x)], y|x ~ N(Wx+b, sigma2 I).

    If Phi_tilde is provided, (mu, Sigma) are interpreted as p-fiber variables
    and are first pushed to the q-fiber for the NLL; the returned gradients are
    then mapped back to the original fiber:
        mu_q = Phi_tilde @ mu_p
        S_q  = Phi_tilde @ S_p @ Phi_tilde^T
        g_mu_p = Phi_tilde^T @ g_mu_q
        g_S_p  = Phi_tilde^T @ g_S_q @ Phi_tilde

    Returns
    -------
    g_mu : (..., Kx)       (same fiber as inputs)
    g_S  : (..., Kx, Kx)   (same fiber as inputs)
    """
    

    # --- sanitize scalar & arrays ---
    y     = np.nan_to_num(np.asarray(y,     np.float32), copy=False)
    mu    = np.nan_to_num(np.asarray(mu,    np.float32), copy=False)
    Sigma = np.nan_to_num(np.asarray(Sigma, np.float32), copy=False)
    W     = np.nan_to_num(np.asarray(W,     np.float32), copy=False)
    b     = np.nan_to_num(np.asarray(b,     np.float32), copy=False)
    sigma2 = float(max(sigma2, sigma2_min))
    inv_s2 = 1.0 / sigma2

    # --- mask helpers ---
    if mask is None:
        m1 = 1.0
        m2 = 1.0
    else:
        m  = np.asarray(mask, np.float32)
        m1 = m[..., None]          # (..., 1)
        m2 = m[..., None, None]    # (..., 1, 1)

    # === push to q if needed ===
    if Phi_tilde is not None:
        # Inputs are p-fiber → push to q for the likelihood
        Phi_tilde = np.asarray(Phi_tilde, np.float32)
        # μ_q = Φ̃ μ_p
        mu_q = np.einsum("...dk,...k->...d", Phi_tilde, mu, optimize=True).astype(np.float32)
        # Σ_q = Φ̃ Σ_p Φ̃^T   (SPD sanitize after push)
        S_q  = np.einsum("...dk,...kj,...ej->...de", Phi_tilde, Sigma, Phi_tilde, optimize=True)
        S_q  = sanitize_sigma(0.5 * (S_q + np.swapaxes(S_q, -1, -2)).astype(np.float32),
                              eps=sanitize_eps)
    else:
        # Already in q-fiber
        mu_q = mu
        S_q  = sanitize_sigma(0.5 * (Sigma + np.swapaxes(Sigma, -1, -2)).astype(np.float32),
                              eps=sanitize_eps)

    # --- residuals (apply mask BEFORE multiplies to avoid NaN*0) ---
    # r = (W μ_q + b) - y
    r = (mu_q @ W.T) + b - y           # (..., D)
    if mask is not None:
        r = np.where(m1.astype(bool), r, 0.0)

    # --- grads in q-fiber ---
    WT   = W.T                         # (Kq, D)
    WT_W = (WT @ W).astype(np.float32) # (Kq, Kq)

    # ∂/∂μ_q: (1/σ²) W^T r
    g_mu_q = (inv_s2 * (WT @ r[..., None]).squeeze(-1)).astype(np.float32)  # (..., Kq)
    # ∂/∂Σ_q: (1/2σ²) W^T W     (broadcast to per-pixel shape)
    g_S_q  = (0.5 * inv_s2 * WT_W).astype(np.float32)                       # (Kq, Kq)
    g_S_q  = np.broadcast_to(g_S_q, S_q.shape)

    # gate grads by mask
    if mask is not None:
        g_mu_q = g_mu_q * m1
        g_S_q  = g_S_q  * m2

    # symmetrize Σ-grad in q
    g_S_q = 0.5 * (g_S_q + np.swapaxes(g_S_q, -1, -2))

    # === map grads back to original fiber if inputs were p ===
    if Phi_tilde is not None:
        Pt = np.swapaxes(Phi_tilde, -1, -2)                     # (..., Kp, Kq)
        # g_mu_p = Φ̃^T g_mu_q
        g_mu = np.einsum("...kd,...d->...k", Pt, g_mu_q, optimize=True)
        # g_S_p  = Φ̃^T g_S_q Φ̃
        g_S  = np.einsum("...ik,...kl,...jl->...ij", Pt, g_S_q, Phi_tilde, optimize=True)
        # symmetrize for numerical safety
        g_S  = 0.5 * (g_S + np.swapaxes(g_S, -1, -2))
    else:
        g_mu, g_S = g_mu_q, g_S_q

    # --- optional per-pixel clipping in the RETURN fiber ---
    if grad_mu_clip is not None and grad_mu_clip > 0:
        n = np.linalg.norm(g_mu, axis=-1, keepdims=True)
        s = np.minimum(1.0, grad_mu_clip / (n + 1e-9))
        g_mu = (g_mu * s).astype(np.float32)

    if grad_S_clip is not None and grad_S_clip > 0:
        gSf = g_S.reshape(*g_S.shape[:-2], -1)
        n   = np.linalg.norm(gSf, axis=-1, keepdims=True)
        s   = np.minimum(1.0, grad_S_clip / (n + 1e-9))
        g_S = (gSf * s).reshape(g_S.shape).astype(np.float32)

    # final sanitize (symmetry only; these are grads)
    g_S = 0.5 * (g_S + np.swapaxes(g_S, -1, -2))

    return g_mu, g_S





def vfe_theta_grads(y, mu, Sigma, W, b, sigma2, *, mask=None):
    """
    Euclidean grads wrt theta = {W, b, sigma2}.
    Returns (dW, db, d_sigma2) aggregated (sum) over batch/pixels/agents.
    """
    y = np.asarray(y, np.float32)
    mu = np.asarray(mu, np.float32)
    Sigma = np.asarray(Sigma, np.float32)
    W = np.asarray(W, np.float32)
    b = np.asarray(b, np.float32)
    sigma2 = float(sigma2)

    inv_s2 = 1.0 / max(sigma2, 1e-12)
    r = (mu @ W.T) + b - y                         # (..., D)

    # dW: sum over examples of (r mu^T + W Σ)
    # shape handling:
    dW = np.einsum("...d,...k->dk", r, mu, optimize=True)          # (D,K)
    # add sum over Σ term:
    # sum_over_batch( W Σ ) = W * sum_over_batch(Σ) along appropriate dims
    Sigma_sum = np.sum(Sigma, axis=tuple(range(Sigma.ndim-2)))     # (K,K)
    dW += W @ Sigma_sum
    dW *= inv_s2

    # db: sum r
    db = np.sum(r, axis=tuple(range(r.ndim-1))) * inv_s2            # (D,)

    # d sigma2:
    D = y.shape[-1]
    r2 = np.sum(r*r, axis=-1)                                       # (...)
    WT_W = W.T @ W                                                  # (K,K)
    tr_term = np.einsum("...ij,ij->...", Sigma, WT_W, optimize=True)  # (...)
    num = np.sum(r2 + tr_term)                                      # scalar
    N  = r2.size                                                    # count of examples
    d_sigma2 = 0.5 * ( num / (sigma2**2 * max(sigma2, 1e-12)) - (D * N) / sigma2 )

    if mask is not None:
        m = np.asarray(mask, np.float32)
        # Recompute with masking to be precise:
        dW = np.einsum("...d,...k->dk", r*m[...,None], mu, optimize=True)
        Sigma_sum = np.sum(Sigma * m[...,None,None], axis=tuple(range(Sigma.ndim-2)))
        dW += W @ Sigma_sum
        dW *= inv_s2

        db = np.sum(r*m[...,None], axis=tuple(range(r.ndim-1))) * inv_s2

        r2m = np.sum((r*r) * m[...,None], axis=-1)
        trm = np.einsum("...ij,ij->...", Sigma*m[...,None,None], WT_W, optimize=True)
        num = float(np.sum(r2m + trm))
        N   = int(np.sum(m))
        d_sigma2 = 0.5 * ( num / (sigma2**2 * max(sigma2, 1e-12)) - (D * N) / sigma2 )

    return dW.astype(np.float32), db.astype(np.float32), float(d_sigma2)
