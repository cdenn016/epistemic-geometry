# -*- coding: utf-8 -*-
"""
Created on Sat Jul 19 12:51:16 2025

@author: chris and christine
"""

import numpy as np
import pytest
from bundle_morphism_utils import safe_batch_apply_morphism, safe_batch_apply_morphism_nat, initialize_morphism_pair
from bundle_update_terms import grad_morphism_self_energy, grad_morphism_feedback_energy, compute_phi_morphism_update, compute_phi_tilde_morphism_update
from generalized_agent_schema import Agent
from numpy.testing import assert_allclose
from generalized_agents import generate_anisotropic_mu_field

# Mock configuration (to be imported or setup in your environment)
class MockConfig:
    q_sigma_range = (1.0, 5.0)
    p_sigma_range = (1.0, 5.0)
    mu_field_smooth_range = 0.5
    sigma_field_smooth_range = 0.5
    eta_base_phi = 0.01
    eta_phi_min = 1e-6
    debug_gradients = False
    support_cutoff_eps = 1e-6

# Mock agents with simplified fields for testing (K_q != K_p, both odd)
def create_mock_agent(K_q=3, K_p=5):
    agent = Agent(
        id=1,
        center=(5, 5),
        radius=3.0,
        mask=np.ones((10, 10)),
        mu_q_field=np.random.randn(10, 10, K_q),
        sigma_q_field=np.random.randn(10, 10, K_q, K_q),
        mu_p_field=np.random.randn(10, 10, K_p),
        sigma_p_field=np.random.randn(10, 10, K_p, K_p),
        phi=np.random.randn(10, 10, K_q),
        phi_model=np.random.randn(10, 10, K_p),
    )
    return agent

# Test: Validate shape consistency in morphism application
def test_morphism_shape_consistency():
    agent_i = create_mock_agent(K_q=3, K_p=5)
    agent_j = create_mock_agent(K_q=3, K_p=5)

    # Identity morphism should not alter the fields
    Phi_q_to_p, Phi_p_to_q = initialize_morphism_pair((10, 10), 3, 5, np.random.default_rng(), morphism_type="identity")

    mu_out, sigma_out = safe_batch_apply_morphism(agent_i.mu_q_field, agent_i.sigma_q_field, Phi_q_to_p)
    assert mu_out.shape == agent_i.mu_q_field.shape, "Output shape mismatch for mu"
    assert sigma_out.shape == agent_i.sigma_q_field.shape, "Output shape mismatch for sigma"

    # Ensure that applying the identity morphism results in no changes
    mu_out, sigma_out = safe_batch_apply_morphism(agent_i.mu_q_field, agent_i.sigma_q_field, Phi_q_to_p)
    assert_allclose(mu_out, agent_i.mu_q_field, atol=1e-6, rtol=1e-6, err_msg="Morphism application not identity")
    assert_allclose(sigma_out, agent_i.sigma_q_field, atol=1e-6, rtol=1e-6, err_msg="Morphism application not identity")

# Test: Check numerical stability in morphism application
def test_morphism_numerical_stability():
    # Test for NaN or infinite values in morphism application
    agent_i = create_mock_agent(K_q=3, K_p=5)
    agent_j = create_mock_agent(K_q=3, K_p=5)
    
    Phi_q_to_p, Phi_p_to_q = initialize_morphism_pair((10, 10), 3, 5, np.random.default_rng(), morphism_type="gauge_covariant")
    
    mu_out, sigma_out = safe_batch_apply_morphism(agent_i.mu_q_field, agent_i.sigma_q_field, Phi_q_to_p)
    assert np.all(np.isfinite(mu_out)), "NaN or Inf in transformed mu field"
    assert np.all(np.isfinite(sigma_out)), "NaN or Inf in transformed sigma field"

# Test: Validate the computation of gradients (self-energy and feedback)
def test_morphism_gradients():
    agent_i = create_mock_agent(K_q=3, K_p=5)

    # Check self-energy gradient for belief
    grad_self = grad_morphism_self_energy(agent_i, alpha=1.0, field_type="belief")
    assert grad_self[0].shape == agent_i.mu_q_field.shape, "Self-energy gradient mu shape mismatch"
    assert grad_self[1].shape == agent_i.sigma_q_field.shape, "Self-energy gradient sigma shape mismatch"

    # Check feedback gradient for model
    grad_feedback = grad_morphism_feedback_energy(agent_i, feedback_weight=1.0)
    assert grad_feedback[0].shape == agent_i.mu_p_field.shape, "Feedback gradient mu shape mismatch"
    assert grad_feedback[1].shape == agent_i.sigma_p_field.shape, "Feedback gradient sigma shape mismatch"

# Test: Validate phi morphism update computation
def test_phi_morphism_update():
    agent_i = create_mock_agent(K_q=3, K_p=5)
    params = {"alpha": 0.1, "phi_morphism_lr": 0.01}
    
    # Test phi morphism update for belief-to-model (Φ̃)
    update = compute_phi_morphism_update(agent_i, params)
    assert update is not None, "Phi morphism update failed"

# Test: Validate phi_tilde morphism update computation
def test_phi_tilde_morphism_update():
    agent_i = create_mock_agent(K_q=3, K_p=5)
    params = {"alpha": 0.1, "phi_tilde_morphism_lr": 0.01}
    
    # Test phi_tilde morphism update for model-to-belief (Φ)
    update = compute_phi_tilde_morphism_update(agent_i, params)
    assert update is not None, "Phi_tilde morphism update failed"

# Test: Validate initialization of morphism pair
def test_initialize_morphism_pair():
    Phi_q_to_p, Phi_p_to_q = initialize_morphism_pair((10, 10), 3, 5, np.random.default_rng(), morphism_type="identity")
    assert Phi_q_to_p.shape == (10, 10, 5, 3), "Incorrect shape for Phi_q_to_p"
    assert Phi_p_to_q.shape == (10, 10, 3, 5), "Incorrect shape for Phi_p_to_q"

# Test: Validate anisotropic field generation
def test_generate_anisotropic_mu_field():
    rng = np.random.default_rng(42)
    mu_field = generate_anisotropic_mu_field((10, 10), rng, 3, (0, 1), (1, 2), (0.5, 2), (0, np.pi))
    assert mu_field.shape == (10, 10, 3), "Generated mu field has incorrect shape"

# Run all tests using pytest
if __name__ == "__main__":
    pytest.main()
