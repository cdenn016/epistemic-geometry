# === generalized_update_rules.py (refactor patch) ===
import numpy as np
import config
from joblib import Parallel, delayed

from natural_gradient_utils import (
    apply_natural_gradient_batch,
    apply_lie_natural_gradient,
    compute_inverse_fisher_field
)

from numerical_utils import sanitize_sigma
from mask_utils import clip_and_mask_gradient
from numerical_utils import safe_inv
from natural_gradient_utils import ( 
    compute_alignment_kl_gradient, 
    )
from get_generators import get_generators
from generalized_math_utils import unpack_phi_update_params
from generalized_omega import compute_curvature_gradient_analytical

from generalized_omega import dexpinv_operator, dexpinv_operator_covariance
from bundle_morphism_utils import safe_batch_apply_morphism, gauge_covariant_transform_phi
from natural_gradient_utils import compute_fisher_geometry_gradient
from generalized_math_utils import ( 
        zero_mu_sigma_like, compute_mu_sigma_diff,
        apply_mask_to_mu_sigma
        )



#verified
def grad_self_field(agent_i, alpha, field_type="model", mask=None,
                             phi_morphism=None, phi_tilde_morphism=None):
    """
    Compute raw Euclidean gradient of morphism-aware self-alignment:
  - field_type="belief" → ∂KL(q || Φ̃·p)
  - field_type="model" → ∂KL(p || Φ·q)

    The morphism acts as:
  - Φ   : q → p  (for feedback, model side)
  - Φ̃  : p → q  (for self-alignment, belief side)

    Notes:
    - For field="belief", p is pulled into q-space using Φ̃.
    - For field="model", q is pulled into p-space using Φ.
"""

    if alpha <= 0:
        return zero_mu_sigma_like(agent_i)

    H, W = agent_i.grid_shape

    if field_type == "belief":
        mu_q, sigma_q = agent_i.mu_q_field, agent_i.sigma_q_field  # q-space
        mu_p, sigma_p = agent_i.mu_p_field, agent_i.sigma_p_field  # p-space
        K_q = mu_q.shape[-1]
        K_p = mu_p.shape[-1]

        if phi_morphism is not None:
            Phi = phi_morphism  # should be (..., K_q, K_p)
        else:
            eye = np.eye(K_q, K_p, dtype=mu_q.dtype)  # p → q maps from K_p to K_q
            Phi = np.broadcast_to(eye, (H, W, K_q, K_p))

        mu_p_trans, sigma_p_trans = safe_batch_apply_morphism(mu_p, sigma_p, Phi, eps=config.eps)
        dμ, dΣ = compute_mu_sigma_diff(mu_q, sigma_q, mu_p_trans, sigma_p_trans, direction="a_minus_b")

    elif field_type == "model":
        mu_q, sigma_q = agent_i.mu_q_field, agent_i.sigma_q_field
        mu_p, sigma_p = agent_i.mu_p_field, agent_i.sigma_p_field
        K_q = mu_q.shape[-1]
        K_p = mu_p.shape[-1]

        if phi_tilde_morphism is not None:
            Phi_tilde = phi_tilde_morphism  # should be (..., K_p, K_q)
        else:
            eye = np.eye(K_p, K_q, dtype=mu_q.dtype)  # q → p maps from K_q to K_p
            Phi_tilde = np.broadcast_to(eye, (H, W, K_p, K_q))

        mu_q_trans, sigma_q_trans = safe_batch_apply_morphism(mu_q, sigma_q, Phi_tilde, eps=config.eps)
        dμ, dΣ = compute_mu_sigma_diff(mu_p, sigma_p, mu_q_trans, sigma_q_trans, direction="a_minus_b")

    else:
        raise ValueError(f"[grad_self_field_morphism] Unknown field_type: {field_type}")

    dμ = np.nan_to_num(dμ)
    dΣ = np.nan_to_num(dΣ)

    if mask is not None:
        dμ, dΣ = apply_mask_to_mu_sigma(dμ, dΣ, mask)

    return alpha * dμ, alpha * dΣ


def grad_morphism_self_energy(agent_i, alpha, mask=None):
    """
    Compute gradient ∂/∂Φ̃ of KL[q || Φ̃·p], where Φ̃ : P → Q is a bundle morphism.
    This is the canonical gauge-covariant self-energy gradient on the morphism Φ̃.

    Args:
        agent_i : agent whose morphism Φ̃ : P → Q is being updated
        alpha   : weight of the self-alignment term
        mask    : optional spatial mask (H, W)

    Returns:
        grad    : gradient of shape (H, W, K_q, K_p)
    """
    mu_q    = agent_i.mu_q_field             # (H, W, K_q)
    sigma_q = agent_i.sigma_q_field          # (H, W, K_q, K_q)
    mu_p    = agent_i.mu_p_field             # (H, W, K_p)
    sigma_p = agent_i.sigma_p_field          # (H, W, K_p, K_p)
    Phi_tilde = agent_i.bundle_morphism_p_to_q  # Φ̃ : P → Q, shape (H, W, K_q, K_p)

    # Project p into q-fiber using Φ̃ : P → Q
    mu_p_proj, sigma_p_proj = safe_batch_apply_morphism(mu_p, sigma_p, Phi_tilde, eps=config.eps)
    sigma_q_inv = safe_inv(sigma_q, eps=config.eps)

    # ∂/∂Φ̃ Tr[ Σ_q⁻¹ (Φ̃ Σ_p Φ̃ᵀ) ] = 2 Σ_q⁻¹ Φ̃ Σ_p
    term_sigma = 2 * np.einsum("...ij,...jl,...kl->...ik", sigma_q_inv, Phi_tilde, sigma_p)

    # ∂/∂Φ̃ (Φ̃μ_p - μ_q)^T Σ_q⁻¹ ∂μ_p_proj/∂Φ̃ = 2 Σ_q⁻¹ (Φ̃μ_p - μ_q) μ_pᵀ
    delta_mu = mu_p_proj - mu_q
    term_mu  = 2 * np.einsum("...ij,...j,...k->...ik", sigma_q_inv, delta_mu, mu_p)

    grad_total = term_mu + term_sigma  # shape: (H, W, K_q, K_p)

    if mask is not None:
        grad_total *= mask[..., None, None]

    return alpha * grad_total

def grad_feedback_field(agent_i, feedback_weight, field_type="model", mask=None,
                                 phi_morphism=None, phi_tilde_morphism=None):
    """
    Compute raw Euclidean gradient of feedback term:
        - field_type="belief" → ∂_q KL(q || Φ·p)
        - field_type="model"  → ∂_p KL(p || Φ̃·q)

    This is the gradient of KL(self || transformed other), with gradients taken w.r.t. self.
    """

    if feedback_weight <= 0:
        return zero_mu_sigma_like(agent_i, field=field_type)

    H, W = agent_i.grid_shape

    if field_type == "belief":
        mu_self, sigma_self = agent_i.mu_q_field, agent_i.sigma_q_field
        mu_p, sigma_p = agent_i.mu_p_field, agent_i.sigma_p_field
        K_q = mu_self.shape[-1]
        K_p = mu_p.shape[-1]
        if phi_morphism is not None:
            Phi = phi_morphism
        else:
            eye = np.eye(K_q, K_p, dtype=mu_self.dtype)
            Phi = np.broadcast_to(eye, (H, W, K_q, K_p))
        # Pull p into q-space
        mu_p_trans, sigma_p_trans = safe_batch_apply_morphism(mu_p, sigma_p, Phi, eps=config.eps)
        dμ, dΣ = compute_mu_sigma_diff(mu_self, sigma_self, mu_p_trans, sigma_p_trans, direction="b_minus_a")

    elif field_type == "model":
        mu_self, sigma_self = agent_i.mu_p_field, agent_i.sigma_p_field
        mu_q, sigma_q = agent_i.mu_q_field, agent_i.sigma_q_field
        K_q = mu_q.shape[-1]
        K_p = mu_self.shape[-1]
        if phi_tilde_morphism is not None:
            Phi_tilde = phi_tilde_morphism
        else:
            eye = np.eye(K_p, K_q, dtype=mu_self.dtype)
            Phi_tilde = np.broadcast_to(eye, (H, W, K_p, K_q))
        # Pull q into p-space
        mu_q_trans, sigma_q_trans = safe_batch_apply_morphism(mu_q, sigma_q, Phi_tilde, eps=config.eps)
        dμ, dΣ = compute_mu_sigma_diff(mu_self, sigma_self, mu_q_trans, sigma_q_trans, direction="b_minus_a")

    else:
        raise ValueError(f"[grad_feedback_field_morphism] Unknown field_type: {field_type}")

    dμ = np.nan_to_num(dμ)
    dΣ = np.nan_to_num(dΣ)

    if mask is not None:
        dμ, dΣ = apply_mask_to_mu_sigma(dμ, dΣ, mask)

    return feedback_weight * dμ, feedback_weight * dΣ

def grad_morphism_feedback_energy(agent_i, feedback_weight, mask=None):
    """
    Compute gradient ∂KL(p || Φ·q) / ∂Φ where Φ : Q → P.
    This is the gauge-covariant feedback term.

    Args:
        agent_i        : Agent object
        feedback_weight: scalar β controlling the feedback term
        mask           : optional (H, W) spatial mask

    Returns:
        ∂F/∂Φ : (H, W, K_p, K_q)
    """
    if feedback_weight <= 0:
        return np.zeros_like(agent_i.bundle_morphism_q_to_p)

    mu_q     = agent_i.mu_q_field        # (H, W, K_q)
    sigma_q  = agent_i.sigma_q_field     # (H, W, K_q, K_q)
    mu_p     = agent_i.mu_p_field        # (H, W, K_p)
    sigma_p  = agent_i.sigma_p_field     # (H, W, K_p, K_p)
    Phi_q_to_p = agent_i.bundle_morphism_q_to_p  # Φ : Q → P

    # Project q into p-fiber via Φ
    mu_q_proj, sigma_q_proj = safe_batch_apply_morphism(mu_q, sigma_q, Phi_q_to_p)

    sigma_proj_inv = safe_inv(sigma_q_proj, eps=config.eps)
    delta_mu = mu_p - mu_q_proj

    # Gradient of Tr[Σ_proj⁻¹ Σ_p]
    grad_sigma = -2 * np.einsum("...ij,...jl,...kl->...ik", sigma_proj_inv, Phi_q_to_p, sigma_q)

    # Gradient of (μ_p - μ_proj)ᵀ Σ_proj⁻¹ ∂μ_proj/∂Φ
    grad_mu = -2 * np.einsum("...ij,...j,...k->...ik", sigma_proj_inv, delta_mu, mu_q)

    grad_total = grad_mu + grad_sigma

    if mask is not None:
        grad_total *= mask[..., None, None]

    return feedback_weight * grad_total

from mask_utils import clip_and_mask_morphism

def compute_phi_tilde_morphism_update(agent_i, params):
    """
    Update for Φ̃ : P → Q (used in KL(q || Φ̃·p)).
    Applies Euclidean gradient descent to the bundle morphism.
    """
    alpha = params.get("alpha", config.alpha)
    lr_phi = params.get("phi_morphism_lr", getattr(config, "phi_morphism_lr", 1e-3))
    eps = params.get("support_cutoff_eps", config.support_cutoff_eps)
    clip_th = params.get("phi_morphism_grad_clip", getattr(config, "phi_morphism_grad_clip", 1.0))

    if alpha <= 0 or lr_phi <= 0:
        return None

    mask = agent_i.mask > eps
    dPhi = grad_morphism_self_energy(agent_i, alpha, mask=mask)

    # ── Apply Mask First ───────────────────────────────
    dPhi *= mask[..., None, None]  # Apply mask to gradient before clipping

    # ── Safety and Clipping ─────────────────────────────
    dPhi = clip_and_mask_morphism(dPhi, clip_threshold=clip_th)

    # Optional: Reapply final mask
    dPhi *= mask[..., None, None]

    dPhi = np.nan_to_num(dPhi, nan=0.0, posinf=1e5, neginf=-1e5)

    # ── Update and Debug ────────────────────────────────
    before = agent_i.bundle_morphism_p_to_q.copy()
    agent_i.bundle_morphism_p_to_q -= lr_phi * dPhi
    delta = np.linalg.norm(agent_i.bundle_morphism_p_to_q - before)

    print(f"[DEBUG] |Phi~ change (p-->q)| = {delta:.6f}")
    return dPhi


def compute_phi_morphism_update(agent_i, params):
    """
    Update for Φ : Q → P (used in KL(p || Φ·q)).
    Applies Euclidean gradient descent to the bundle morphism Φ.
    This pulls q into the p-fiber for model feedback alignment.
    """
    fb = params.get("model_feedback_weight", config.model_feedback_weight)
    lr_phi_tilde = params.get("phi_tilde_morphism_lr", getattr(config, "phi_tilde_morphism_lr", 1e-3))
    eps = params.get("support_cutoff_eps", config.support_cutoff_eps)
    clip_th = params.get("phi_tilde_morphism_grad_clip", getattr(config, "phi_tilde_morphism_grad_clip", 1.0))

    if fb <= 0 or lr_phi_tilde <= 0:
        return None

    mask = agent_i.mask > eps
    dPhi = grad_morphism_feedback_energy(agent_i, fb, mask=mask)

    # ── Apply Mask First ───────────────────────────────
    dPhi *= mask[..., None, None]  # Apply mask to gradient before clipping

    # ── Safety and Clipping ─────────────────────────────
    dPhi = clip_and_mask_morphism(dPhi, clip_threshold=clip_th)

    # Optional: Reapply final mask
    dPhi *= mask[..., None, None]

    dPhi = np.nan_to_num(dPhi, nan=0.0, posinf=1e5, neginf=-1e5)

    # ── Update and Debug ────────────────────────────────
    if not agent_i.bundle_morphism_q_to_p.flags.writeable:
        agent_i.bundle_morphism_q_to_p = agent_i.bundle_morphism_q_to_p.copy()

    before = agent_i.bundle_morphism_q_to_p.copy()
    agent_i.bundle_morphism_q_to_p -= lr_phi_tilde * dPhi
    delta = np.linalg.norm(agent_i.bundle_morphism_q_to_p - before)
    print(f"[DEBUG] |Phi change (q-->p)| = {delta:.6f}")

    return dPhi


def alignment_gradient_field(agent_i, agents, params, field_type="model", mask=None):
    """
    Raw Euclidean gradient of alignment KL divergence:
        KL(q_i || Ω_ij q_j) or KL(p_i || Ω̃_ij p_j)

    Natural gradient is applied centrally in combine_field_gradients.

    Args:
        agent_i    : focal agent
        agents     : list of agents
        params     : dict of parameters
        field_type : "model" or "belief"
        mask       : optional spatial mask to restrict update region

    Returns:
        dμ, dΣ : raw Euclidean gradients (H, W, K), (H, W, K, K)
    """
    if field_type == "model":
        weight = params.get("model_align_weight", config.model_align_weight)
        K_fiber = agent_i.mu_p_field.shape[-1]
    elif field_type == "belief":
        weight = params.get("beta", config.beta)
        K_fiber = agent_i.mu_q_field.shape[-1]
    else:
        raise ValueError(f"[alignment_gradient_field] Unknown field_type: {field_type}")

    if weight <= 0:
        return zero_mu_sigma_like(agent_i, field=field_type)

    # Load or generate the appropriate representation generators
    generators = params.get("generators", get_generators(config.group_name, K_fiber))

    # Compute raw KL alignment gradients
    dμ, dΣ = compute_alignment_kl_gradient(agent_i, agents, generators, params, field_type=field_type)

    # Ensure numerical stability
    dμ = np.nan_to_num(dμ)
    dΣ = np.nan_to_num(dΣ)

    # Apply optional mask
    if mask is not None:
        dμ, dΣ = apply_mask_to_mu_sigma(dμ, dΣ, mask)

    return weight * dμ, weight * dΣ


from generalized_omega import exp_lie_algebra_irrep
from natural_gradient_utils import sanitize_sigma, safe_inv
from generalized_omega import dexpinv_operator, dexpinv_operator_covariance

def accumulate_phi_gradient(agent_i, agent_j, generators, params, field="phi"):
    """
    Compute and accumulate both variational gradients:
        ∂/∂φ_i KL(q_i ‖ Ω_ij q_j)
        ∂/∂φ_j KL(q_i ‖ Ω_ij q_j)
    where Ω_ij = exp(φ_i) · exp(−φ_j)
    """
    assert field in ("phi", "phi_model")
    beta = params.get("beta", config.beta) if field == "phi" else params.get("model_align_weight", config.model_align_weight)
    if beta <= 0:
        return

    eps = config.support_cutoff_eps
    mask_i = agent_i.mask[..., None] > eps
    mask_j = agent_j.mask[..., None] > eps
    joint_mask = mask_i & mask_j

    # Select fibers and fields
    mu_i     = agent_i.mu_q_field     if field == "phi" else agent_i.mu_p_field
    mu_j     = agent_j.mu_q_field     if field == "phi" else agent_j.mu_p_field
    sigma_i  = agent_i.sigma_q_field  if field == "phi" else agent_i.sigma_p_field
    sigma_j  = agent_j.sigma_q_field  if field == "phi" else agent_j.sigma_p_field
    phi_i    = agent_i.phi            if field == "phi" else agent_i.phi_model
    phi_j    = agent_j.phi            if field == "phi" else agent_j.phi_model

    # Compute Ω_ij = exp(φ_i) @ exp(-φ_j)
    exp_phi_i  = exp_lie_algebra_irrep(phi_i, generators)
    exp_neg_phi_j = exp_lie_algebra_irrep(-phi_j, generators)
    Omega_ij = np.einsum("...ik,...kj->...ij", exp_phi_i, exp_neg_phi_j)
    Omega_T  = np.swapaxes(Omega_ij, -1, -2)

    # Transport q_j to i
    mu_trans = np.einsum("...ij,...j->...i", Omega_ij, mu_j)
    sigma_trans = np.einsum("...ik,...kl,...jl->...ij", Omega_ij, sigma_j, Omega_T)
    sigma_trans = sanitize_sigma(sigma_trans, eps=config.eps)
    sigma_inv = safe_inv(sigma_trans, eps=config.eps)

    delta_mu = mu_i - mu_trans
    d_mu = -np.einsum("...ij,...j->...i", sigma_inv, delta_mu)

    delta_sigma = sigma_i - sigma_trans
    d_sigma = -0.5 * np.einsum("...ik,...kl,...lj->...ij", sigma_inv, delta_sigma, sigma_inv)

    d = generators.shape[0]
    grad_phi_i = np.zeros_like(phi_i)
    grad_phi_j = np.zeros_like(phi_j)

    for a in range(d):
        G = generators[a]

        # ∂Ω/∂φ_i = Ω G
        OG = np.einsum("...ij,jk->...ik", Omega_ij, G)
        dphi_i_mu = np.einsum("...ij,...j->...i", OG, mu_j)

        OG_sigma = np.einsum("...ij,...jk->...ik", OG, sigma_j)
        dphi_sigma_1 = np.einsum("...ij,...jk->...ik", OG_sigma, Omega_T)

        sigma_GT = np.einsum("...ij,jk->...ik", sigma_j, G.T)
        O_sigma_GT = np.einsum("...ij,...jk->...ik", Omega_ij, sigma_GT)
        dphi_sigma_2 = np.einsum("...ij,...jk->...ik", O_sigma_GT, Omega_T)

        dphi_i_sigma = dphi_sigma_1 + dphi_sigma_2

        # ∂Ω/∂φ_j = -Ω G_right, where G_right = exp(φ_j) @ G @ exp(−φ_j)
        G_batch = np.broadcast_to(G, exp_phi_i.shape)
        G_right = np.einsum("...ij,...jk,...kl->...il", exp_phi_i, G_batch, exp_neg_phi_j)

        dphi_j_mu = -np.einsum("...ij,...j->...i", G_right, mu_j)

        G_right_sigma = np.einsum("...ij,...jk->...ik", G_right, sigma_j)
        dphi_j_sigma_1 = np.einsum("...ij,...jk->...ik", G_right_sigma, Omega_T)

        sigma_GT_j = np.einsum("...ij,jk->...ik", sigma_j, G.T)
        O_sigma_GT_j = np.einsum("...ij,...jk->...ik", Omega_ij, sigma_GT_j)
        dphi_j_sigma_2 = np.einsum("...ij,...jk->...ik", O_sigma_GT_j, Omega_T)

        dphi_j_sigma = dphi_j_sigma_1 + dphi_j_sigma_2

        delta_a_i = (
            np.sum(d_mu * dphi_i_mu, axis=-1) +
            np.einsum("...ij,...ij->...", d_sigma, dphi_i_sigma)
        )
        delta_a_j = (
            np.sum(d_mu * dphi_j_mu, axis=-1) +
            np.einsum("...ij,...ij->...", d_sigma, dphi_j_sigma)
        )

        grad_phi_i[..., a] += delta_a_i
        grad_phi_j[..., a] += delta_a_j

    # Apply natural gradient (μ + Σ terms separately)
    grad_phi_mu_i = dexpinv_operator(phi_i, grad_phi_i, generators)
    grad_phi_mu_j = dexpinv_operator(phi_j, grad_phi_j, generators)

    grad_phi_sigma_i = dexpinv_operator_covariance(phi_i, d_sigma, generators)
    grad_phi_sigma_j = dexpinv_operator_covariance(phi_j, -d_sigma, generators)

    grad_phi_i = grad_phi_mu_i + grad_phi_sigma_i
    grad_phi_j = grad_phi_mu_j + grad_phi_sigma_j

    # Accumulate into correct grad field
    if field == "phi":
        agent_i.grad_phi += beta * grad_phi_i * joint_mask
        agent_j.grad_phi += beta * grad_phi_j * joint_mask
    else:
        agent_i.grad_phi_tilde += beta * grad_phi_i * joint_mask
        agent_j.grad_phi_tilde += beta * grad_phi_j * joint_mask





def combine_field_gradients(agent_i, agents, params, field_type="model"):
    if field_type == "model" and getattr(config, "identical_models", False):
        return zero_mu_sigma_like(agent_i)

    # Load all parameters
    α  = params.get("alpha", config.alpha)
    β  = params.get("model_align_weight", config.model_align_weight) if field_type == "model" else params.get("beta", config.beta)
    fb = params.get("model_feedback_weight", config.model_feedback_weight) if field_type == "model" else params.get("belief_feedback_weight", getattr(config, "belief_feedback_weight", 0.0))
    λ  = params.get("variance_penalty_model_weight", getattr(config, "variance_penalty_model_weight", 0.0)) if field_type == "model" else params.get("variance_penalty_belief_weight", getattr(config, "variance_penalty_belief_weight", 0.0))
    eps = params.get("support_cutoff_eps", config.support_cutoff_eps)
    debug = getattr(config, "debug_gradients", False)

    # Mask
    mask = agent_i.mask > eps
    if not np.any(mask):
        return zero_mu_sigma_like(agent_i)

    # Select fields
    mu_field    = agent_i.mu_p_field if field_type == "model" else agent_i.mu_q_field
    sigma_field = agent_i.sigma_p_field if field_type == "model" else agent_i.sigma_q_field

    # --- Natural-gradient components ---
    grad_mu_nat    = np.zeros_like(mu_field)
    grad_sigma_nat = np.zeros_like(sigma_field)

    if α > 0:
        dμ, dΣ = grad_self_field(agent_i, α, field_type, mask)
        grad_mu_nat += dμ
        grad_sigma_nat += dΣ
        if debug:
            print(f"[{field_type.upper()}] Self grad |mu|={np.linalg.norm(dμ):.2e}, |Sigma|={np.linalg.norm(dΣ):.2e}")
    if fb > 0:
        dμ, dΣ = grad_feedback_field(agent_i, fb, field_type, mask)
        grad_mu_nat += dμ
        grad_sigma_nat += dΣ
        if debug:
            print(f"[{field_type.upper()}] Feedback grad |mu|={np.linalg.norm(dμ):.2e}, |Sigma|={np.linalg.norm(dΣ):.2e}")
    if β > 0:
        dμ, dΣ = alignment_gradient_field(agent_i, agents, params, field_type=field_type, mask=mask)

        grad_mu_nat += dμ
        grad_sigma_nat += dΣ
        if debug:
            print(f"[{field_type.upper()}] Align grad |mu|={np.linalg.norm(dμ):.2e}, |Sigma|={np.linalg.norm(dΣ):.2e}")
    # --- Apply Fisher preconditioner only to KL terms ---
    delta_mu, delta_sigma = apply_natural_gradient_batch(
        mu_field, sigma_field, grad_mu_nat, grad_sigma_nat
    )
    if debug:
        print(f"[{field_type.upper()}] delta mu nat grad ={np.linalg.norm(delta_mu):.2e}, Delta Sigma nat grad={np.linalg.norm(delta_sigma):.2e}")

    # --- Add regularization (coordinate) terms AFTER natural gradient ---
    if λ > 0:
        dμ_reg, dΣ_reg = grad_variance_penalty_field(agent_i, λ, field_type, mask)
        delta_mu    += dμ_reg
        delta_sigma += dΣ_reg
        if debug:
            print(f"[{field_type.upper()}] Reg grad mu={np.linalg.norm(dμ_reg):.2e}, Sigma Reg={np.linalg.norm(dΣ_reg):.2e}")
    # Final nan sanitization
    delta_mu    = np.nan_to_num(delta_mu, nan=0.0, posinf=1e5, neginf=-1e5)
    delta_sigma = np.nan_to_num(delta_sigma, nan=0.0, posinf=1e5, neginf=-1e5)

    return delta_mu, delta_sigma

def compute_phi_update(agent_i, agents, params, field="phi"):
    """
    Unified update for φ (belief alignment) and φ̃ (model alignment).
    Applies Lie-natural gradient to alignment + optional regularizers.
    """
    if field == "phi_model" and getattr(config, "identical_models", False):
        return np.zeros_like(agent_i.phi_model)

    # --- Unpack core parameters ---
    unpacked  = unpack_phi_update_params(params, field=field)
    β         = params.get("beta", config.beta) if field == "phi" else params.get("model_align_weight", config.model_align_weight)
    κ         = unpacked["κ"]
    gw        = unpacked["gw"]
    curv_w    = unpacked["curv_weight"]
    clip_th   = unpacked["grad_clip_threshold"]
    eps       = unpacked["overlap_eps"]
    debug     = unpacked["debug"]

    phi       = agent_i.phi if field == "phi" else agent_i.phi_model
    phi_tilde = agent_i.phi_model if field == "phi" else agent_i.phi
    soft_mask = agent_i.mask[..., None]
    generators_q = params.get("generators_q", get_generators(config.group_name, config.K_q))
    generators_p = params.get("generators_p", get_generators(config.group_name, config.K_p))


    if not np.any(soft_mask > eps):
        return np.zeros_like(phi)

    grad = np.zeros_like(phi)

    generators = generators_q if field == "phi" else generators_p
    G_inv = compute_inverse_fisher_field(agent_i, generators, field=field)


    # --- 1. Alignment gradient (Lie-natural, variationally consistent) ---
    if β > 0:
        grad_align = np.zeros_like(phi)
        for neighbor in agent_i.neighbors:
            agent_j = agents[neighbor["id"]]
            accumulate_phi_gradient(agent_i, agent_j, generators, params, field=field)
        if field == "phi":
            grad_align = agent_i.grad_phi.copy()
            agent_i.grad_phi[:] = 0.0
        else:
            grad_align = agent_i.grad_phi_tilde.copy()
            agent_i.grad_phi_tilde[:] = 0.0


        grad += apply_lie_natural_gradient(phi, grad_align, G_inv=G_inv)

    # --- 2. Curvature gradient ---
    if curv_w > 0:
        generators = generators_q if field == "phi" else generators_p
        grad_curv = compute_curvature_gradient_analytical(phi, generators)
        grad += curv_w * grad_curv

    # --- 3. Mass term: 2γ φ ---
    if gw > 0:
        grad += 2 * gw * phi

    # --- 4. φ–φ̃ coupling ---
    if κ > 0:
        grad += 2 * κ * (phi - phi_tilde)

    # --- 5. Optional Fisher geometry term ---
    fisher_key = "fisher_geometry_weight" if field == "phi" else "fisher_model_geometry_weight"
    fisher_weight = params.get(fisher_key, getattr(config, fisher_key, 0.0))
    if fisher_weight > 0:
        fisher_fn = compute_fisher_geometry_gradient if field == "phi" else compute_fisher_geometry_gradient
        fisher_grad = fisher_fn(agent_i, agents, params)
        grad += fisher_weight * fisher_grad

    # --- Final clip + mask ---
    return clip_and_mask_gradient(grad, soft_mask, clip_th, eps)

def grad_variance_penalty_field(agent_i, lambda_, field_type="model", mask=None):
    """
    Gradient of Tr(Σ⁻¹) penalty:
        ∇_Σ = -λ Σ⁻¹

    Returns:
        (Δμ, ΔΣ): where Δμ = 0, ΔΣ = -λ Σ⁻¹ (masked if needed)
    """
    if lambda_ <= 0:
        return zero_mu_sigma_like(agent_i, field=field_type)

    sigma = agent_i.sigma_p_field if field_type == "model" else agent_i.sigma_q_field
    mu_shape = agent_i.mu_p_field.shape if field_type == "model" else agent_i.mu_q_field.shape

    H, W, K, _ = sigma.shape
    d_sigma = np.zeros_like(sigma)
    fallback = np.eye(K)

    for i in range(H):
        for j in range(W):
            try:
                inv_ij = np.linalg.inv(sigma[i, j])
            except np.linalg.LinAlgError:
                if getattr(config, "debug", False):
                    print(f"[WARN] grad_variance_penalty_field: Σ⁻¹ fallback at ({i},{j})")
                inv_ij = np.linalg.pinv(sigma[i, j])  # fallback to pseudo-inverse

            d_sigma[i, j] = -lambda_ * inv_ij

    d_sigma = np.nan_to_num(d_sigma)

    if mask is not None:
        _, d_sigma = apply_mask_to_mu_sigma(None, d_sigma, mask)

    d_mu = np.zeros(mu_shape, dtype=d_sigma.dtype)
    return d_mu, d_sigma