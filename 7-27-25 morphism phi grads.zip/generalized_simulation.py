
import os
os.environ["OMP_NUM_THREADS"] = "1"
os.environ["MKL_NUM_THREADS"] = "1"
os.environ["NUMEXPR_NUM_THREADS"] = "1"  # Optional: just in case
os.environ["OPENBLAS_NUM_THREADS"]= "1"
from threadpoolctl import threadpool_info
print(threadpool_info())

# Standard library
import os
import time
import numpy as np
# Third-party
import pickle
import pandas as pd
from update_rules import synchronous_step
# Local configuration & utilities
from joblib import Parallel, delayed
from config_utils import set_config_from_params
from get_generators import get_generators
# run_simulation.py (cleaner entrypoint)
import sys
from bundle_morphism_utils import make_morphism_fn
from get_generators import RhoFunction, get_rectangular_generators


# I/O helpers
from generalized_io_utils import (
    save_step,
    load_checkpoint,
    find_resume_step,
    save_config_to_readme,
)

# Agent construction
from agent_initialization import initialize_agents, initialize_agent_gradients

import config

from natural_gradient import compute_fisher_metric_rectangular_natural, compute_lie_metric

#from metrics import log_all_metrics, full_field_logger
from generalized_diagnostics_metrics import log_all_metrics, full_field_logger





def get_bundle_morphism_q_to_p(agent_i, agent_j):
    return agent_i.bundle_morphism_q_to_p

def get_bundle_morphism_p_to_q(agent_i, agent_j):
    return agent_i.bundle_morphism_p_to_q


def compute_fisher_for_agent_natural(agent, generators_q_to_p, generators_p_to_q):
    """
    Compute and attach rectangular Lie-algebra Fisher inverses to agent
    using natural parameters (η₁, η₂) for both belief and model fibers.
    """
    

    # Φ : B_q → B_p
    F_Phi, F_inv_Phi = compute_fisher_metric_rectangular_natural(
        Phi=agent.bundle_morphism_q_to_p,
        eta1_q=agent.eta1_q_field,
        eta2_q=agent.eta2_q_field,
        eta2_p=agent.eta2_p_field,
        generators=generators_q_to_p,
        eps=1e-8,
        return_inverse=True,
    )

    # Φ̃ : B_p → B_q
    F_Phi_tilde, F_inv_Phi_tilde = compute_fisher_metric_rectangular_natural(
        Phi=agent.bundle_morphism_p_to_q,
        eta1_q=agent.eta1_p_field,    # source is p
        eta2_q=agent.eta2_p_field,
        eta2_p=agent.eta2_q_field,
        generators=generators_p_to_q,
        eps=1e-8,
        return_inverse=True,
    )

    agent.inverse_fisher_Phi = F_inv_Phi
    agent.inverse_fisher_Phi_tilde = F_inv_Phi_tilde
    return agent


def run_simulation(
    outdir="checkpoints",
    resume=False,
    log_metrics=True,
    log_fields=True,
    num_cores=None,
    params=None,  # should only contain runtime items (e.g. generators, morphism functions)
):
    import config
    from numerical_utils import reset_fallback_counters

    reset_fallback_counters()
    os.makedirs(outdir, exist_ok=True)
    save_config_to_readme(outdir)

    if num_cores is None:
        num_cores = 18

    # Extract runtime tools from params
    params = params or {}

    G_q = params.get("generators_q")
    G_p = params.get("generators_p")

    generators_morphism_q_to_p = get_rectangular_generators(config.K_p, config.K_q)
    generators_morphism_p_to_q = get_rectangular_generators(config.K_q, config.K_p)
    
    # ──────────── Initialization ─────────────
    if resume:
        agents, _ = load_checkpoint(outdir)
        step_start = find_resume_step(outdir)
    else:
        lie_dim = 3
        agents = initialize_agents(
            seed=getattr(config, "seed", None),
            domain_size=config.domain_size,
            N=config.N,
            K_q=config.K_q,
            K_p=config.K_p,
            lie_algebra_dim=lie_dim,
            visualize=False,
            fixed_location=True,
        )
        step_start = 0
        for agent in agents:
            initialize_agent_gradients(agent, config)
            # 🧩 ← Fix: set Lie algebra generators
            agent.generators_q = G_q
            agent.generators_p = G_p
        # ──────────── Compute and cache rectangular Fisher inverses for morphisms ─────────────
    if getattr(config, "use_dynamic_morphisms", True):
        agents = Parallel(n_jobs=num_cores, backend="loky")(
            delayed(compute_fisher_for_agent_natural)(
                agent, generators_morphism_q_to_p, generators_morphism_p_to_q
            ) 
            for agent in agents
        )
        # Add generators to params for gradient computations
        params["generators_Phi"] = generators_morphism_q_to_p
        params["generators_Phi_tilde"] = generators_morphism_p_to_q
    else:
        # Morphisms are static — no generators, no Fisher needed
        params["generators_Phi"] = None
        params["generators_Phi_tilde"] = None


    _, G_inv_q = compute_lie_metric(G_q)
    _, G_inv_p = compute_lie_metric(G_p)
    params["G_inv_phi"] = G_inv_q
    params["G_inv_phi_model"] = G_inv_p

    metric_log = []
    print(f"[RUN] Starting simulation at step {step_start} with {num_cores} cores")

    # ──────────── Main loop ─────────────
    for step in range(step_start, config.steps):
        print(f"\n[STEP {step}] -----------------------------")

        # (A) Gradient update
        t0 = time.perf_counter()
        step_params = dict(params)
        step_params["step"] = step

        # Inject morphism functions for joblib serialization safety
        step_params["bundle_morphism_q_to_p_fn"] = get_bundle_morphism_q_to_p
        step_params["bundle_morphism_p_to_q_fn"] = get_bundle_morphism_p_to_q

        # Add morphism generators to step_params
        step_params["generators_Phi"] = generators_morphism_q_to_p
        step_params["generators_Phi_tilde"] = generators_morphism_p_to_q

        agents = synchronous_step(agents, G_q, G_p, params=step_params, n_jobs=num_cores)
        print(f"[TIMER] synchronous update: {time.perf_counter() - t0:.3f}s")

        # (B) Log metrics
        if log_metrics:
            t0 = time.perf_counter()
            m = log_all_metrics(agents, step=step, params=params, n_jobs=num_cores)
            
            import copy
            metric_log.append(copy.deepcopy({"step": step, **m}))

            print(f"[TIMER] log_all_metrics_fused: {time.perf_counter() - t0:.3f}s")

        # (C) Dump full fields
        if log_fields and getattr(config, "log_full_fields", False):
            t0_fields = time.perf_counter()
            field_dir = os.path.join(outdir, "fields")
            full_field_logger(agents, step, field_dir)
            print(f"[TIMER] full_step_field_logger: {time.perf_counter() - t0_fields:.3f}s")

        # (D) Save checkpoint
        for A in agents:
            A.clear_omega_cache()
            A.clear_fisher_caches()
        save_step(agents, outdir, step) 
        print(f"[SAVE] Checkpoint → {outdir}/step_{step:04d}.pkl")

    # ──────────── Final logging ─────────────
    if log_metrics:
        with open(os.path.join(outdir, "metric_log.pkl"), "wb") as f:
            pickle.dump(metric_log, f)
        print(f"[SAVE] Metrics log → {outdir}/metric_log.pkl")

        # Per-agent metrics CSV
        rows = []
        for A in agents:
            for entry in A.metrics_log:
                rows.append({"agent": A.id, **entry})
        pd.DataFrame(rows).to_csv(os.path.join(outdir, "per_agent_metrics.csv"), index=False)
        print("[SAVE] Per-agent metrics → per_agent_metrics.csv")

    print("[DONE] Simulation completed.")
    return agents, metric_log



if __name__ == "__main__":
    # ─────────────────────────────────────────────
    # 1. Optional param override
    # ─────────────────────────────────────────────
    if len(sys.argv) > 1:
        with open(sys.argv[1], "rb") as f:
            param_override = pickle.load(f)
        set_config_from_params(param_override)
    else:
        param_override = {}

    # ─────────────────────────────────────────────
    # 2. Load group generators for q and p fibers
    # ─────────────────────────────────────────────
    G_q, meta_q = get_generators(config.group_name, config.K_q, return_meta=True)
    G_p, meta_p = get_generators(config.group_name, config.K_p, return_meta=True)
    rho_q = RhoFunction(G_q)
    rho_p = RhoFunction(G_p)
    morphism_q_to_p = make_morphism_fn(rho_q, rho_p)
    morphism_p_to_q = make_morphism_fn(rho_p, rho_q)

    # ─────────────────────────────────────────────
    # 4. Bundle runtime-only params
    # ─────────────────────────────────────────────
    runtime_params = {
        "generators_q": G_q,
        "generators_p": G_p,
        "bundle_morphism_transform_q_to_p": morphism_q_to_p,
        "bundle_morphism_transform_p_to_q": morphism_p_to_q,
    }
    
    # ─────────────────────────────────────────────
    # 5. Run the simulation
    # ─────────────────────────────────────────────
    run_simulation(
        outdir="checkpoints",
        resume=False,
        log_metrics=True,
        log_fields=True,
        params=runtime_params,
    )

