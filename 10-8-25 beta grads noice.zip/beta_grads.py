"""
Created on Sat Sep 27 15:19:10 2025

@author: chris and christine

Case A:  KL( Φ_i[Ω^q_ij q_j] || p_i )
Case B:  KL( p_i || Φ_i Ω^q_ij[q_j] )

Case C: KL( Φ̃_i p_i  ||  Ω^q_ij q_j )
Case D: KL( Ω^q_ij * q_j || Φ̃_i * p_i )

Default Q:  KL( q_i || Ω^q_ij q_j )
Default P:  KL( p_i || Ω^p_ij p_j ) 

"""
import numpy as np
from core.numerical_utils import push_gaussian, sanitize_sigma, safe_inv  # tight/safe impls
from core.transport_cache import Omega, Phi          
from utils import push_neighbor_stats


def grad_beta_mu_sigma_dispatch(ctx, agent_i, agent_j, *, basis, Omega_ij=None, eps: float = 1e-8):
    """
    Lightweight dispatcher for ∂ KL_beta / ∂(μ_i, Σ_i) on the active fiber.
    For bases in {"align","align_q","align_p"} we return zeros of the correct shape.
    """
    

    b = str(basis).lower()
    if   b == "a": return grad_beta_A_mu_sigma_i(ctx, agent_i, agent_j, Omega_ij=Omega_ij, eps=eps)
    elif b == "b": return grad_beta_B_mu_sigma_i(ctx, agent_i, agent_j, Omega_ij=Omega_ij, eps=eps)
    elif b == "c": return grad_beta_C_mu_sigma_i(ctx, agent_i, agent_j, Omega_ij=Omega_ij, eps=eps)
    elif b == "d": return grad_beta_D_mu_sigma_i(ctx, agent_i, agent_j, Omega_ij=Omega_ij, eps=eps)

    # align / align_q / align_p → no β-term μ/Σ gradient
    # shape must match the active fiber on agent_i
    mu_any = getattr(agent_i, "mu_q_field", None)
    # safer: infer from p if q missing, but usually caller supplies correct mu_key
    if mu_any is None:
        mu_any = getattr(agent_i, "mu_p_field")
    S  = tuple(np.asarray(mu_any, np.float32).shape[:-1])
    Ki = int(np.asarray(mu_any, np.float32).shape[-1])
    return np.zeros(S + (Ki,),    np.float32), \
           np.zeros(S + (Ki, Ki), np.float32)



def grad_beta_phi_covectors(
    ctx, agent_i, agent_j,
    *,
    basis: str,
    Omega_ij=None,
    generators_irrep=None,   # (3,K,K) or None if K==3
    eps: float = 1e-8,
):
    """
    β-basis A/B/C/D dispatcher (covector-first).
    Returns param-space *covectors* (∂KL_beta/∂φ)_param per site/fiber:
        (g_phi_i_q_cov, g_phi_j_q_cov, g_phi_i_p_cov)  each (*S,3).

    For basis in {"align", "align_q", "align_p"}, returns zeros (product-rule handled elsewhere).
    """
    b = str(basis).lower()
    if b in ("align", "align_q", "align_p"):
        S = tuple(agent_i.mu_p_field.shape[:-1])
        z = np.zeros(S + (3,), np.float32)
        return z, z, z

    if b == "a":
        return grad_beta_A_phi_covectors(
            ctx, agent_i, agent_j,
            Omega_ij=Omega_ij,
            generators_irrep=generators_irrep,
            eps=eps,
        )
    if b == "b":
        return grad_beta_B_phi_covectors(
            ctx, agent_i, agent_j,
            Omega_ij=Omega_ij,
            generators_irrep=generators_irrep,
            eps=eps,
        )
    if b == "c":
        return grad_beta_C_phi_covectors(
            ctx, agent_i, agent_j,
            Omega_ij=Omega_ij,
            generators_irrep=generators_irrep,
            eps=eps,
        )
    if b == "d":
        return grad_beta_D_phi_covectors(
            ctx, agent_i, agent_j,
            Omega_ij=Omega_ij,
            generators_irrep=generators_irrep,
            eps=eps,
        )

    # Unknown basis → zeros
    S = tuple(agent_i.mu_p_field.shape[:-1])
    z = np.zeros(S + (3,), np.float32)
    return z, z, z



# ---------------- A: KL( Φ_i[Ω q_j]  ||  p_i )  — target in P_i
def grad_beta_A_mu_sigma_i(ctx, agent_i, agent_j, *, Omega_ij=None, eps: float = 1e-8):
    r"""
    ∂ KL_beta / ∂(μ_{p_i}, Σ_{p_i}) for **Case A**.

    Definition
    ----------
      KL_beta := KL( Φ_i[ Ω^q_{ij} q_j ]  ||  p_i ), evaluated in P_i-frame.

    Let
      • (μ_qj, Σ_qj) be q_j in Q_j;  Ω^q_{ij}: Q_j→Q_i
      • (μ_t, Σ_t)   = Ω^q_{ij}(μ_qj, Σ_qj)                   # in Q_i
      • Φ_i: Q_i→P_i;  (μ_L, Σ_L) = Φ_i(μ_t, Σ_t)             # landed in P_i
      • (μ_p, Σ_p) := (μ_{p_i}, Σ_{p_i})                      # target family

    Gaussian KL:
      KL = KL( 𝒩(μ_L, Σ_L)  ||  𝒩(μ_p, Σ_p) ).

    Target-form gradients in P_i:
      v        := Σ_p^{-1} (μ_p − μ_L)
      ∂KL/∂μ_p =  v
      ∂KL/∂Σ_p =  ½( −Σ_p^{-1} Σ_L Σ_p^{-1} − v vᵀ + Σ_p^{-1} )

    Returns
    -------
      gμ_p : (*S, Kp)
      gΣ_p : (*S, Kp, Kp)
    """
    import numpy as np
    from core.numerical_utils import sanitize_sigma, push_gaussian, safe_inv  # push + SPD-safe inv
    from core.transport_cache import Omega, Phi

    # --- p_i stats (sanitize once)
    mu_p = np.asarray(agent_i.mu_p_field,  np.float32, order="C")
    S_p  = sanitize_sigma(np.asarray(agent_i.sigma_p_field, np.float64)).astype(np.float32, copy=False)

    # --- maps
    Om_q = np.asarray(Omega_ij if Omega_ij is not None else Omega(ctx, agent_i, agent_j, which="q"), np.float32)
    Phi_i = np.asarray(Phi(ctx, agent_i, kind="q_to_p"), np.float32)  # Φ_i: Q→P

    # --- q_j → Q_i (fast precision-push if available), then Q_i → P_i via Φ_i
    mu_qj_t, S_qj_t, _ = push_neighbor_stats(agent_j, "sigma_q_field", Om_q, eps=eps)
    mu_L, S_L = push_gaussian(mu_qj_t, S_qj_t, Phi_i, eps=eps)        # (μ_L, Σ_L) in P_i  :contentReference[oaicite:0]{index=0}

    # --- target-form KL grads in P_i
    S_p_inv = safe_inv(S_p, eps=max(eps, 1e-12))                      # Σ_p^{-1}          :contentReference[oaicite:1]{index=1}
    dmu     = (mu_p - mu_L)
    v       = np.einsum("...ij,...j->...i", S_p_inv, dmu, optimize=True)   # v = Σ_p^{-1}(μ_p − μ_L)
    gmu_p   = v

    t0    = -np.einsum("...ij,...jk,...kl->...il", S_p_inv, S_L, S_p_inv, optimize=True)
    vvT   = np.einsum("...i,...j->...ij", v, v, optimize=True)
    gS_p  = 0.5 * (t0 - vvT + S_p_inv)
    gS_p  = 0.5 * (gS_p + np.swapaxes(gS_p, -1, -2))  # symmetrize

    return gmu_p.astype(np.float32, copy=False), gS_p.astype(np.float32, copy=False)


def grad_beta_A_phi_covectors(
    ctx, agent_i, agent_j,
    *,
    Omega_ij=None,
    generators_irrep=None,   # (3,K,K) generators for the active irrep (K==3 ok)
    eps: float = 1e-8,
):
    r"""
    φ/φ̃ *covectors* for **Case A** (no projection here):

        KL_beta = KL( Φ_i[ Ω^q_{ij} q_j ]  ||  p_i )

    Returns param-space *covectors* (∂KL_beta/∂φ)_param, one per relevant frame:
      g_phi_i_q_cov : (*S, 3)   # for E_q(i)
      g_phi_j_q_cov : (*S, 3)   # for E_q(j)
      g_phi_i_p_cov : (*S, 3)   # for E_p(i)

    Notes
    -----
    • These are *covectors* in the parameter coordinates of each site/fiber.
      Do NOT apply Jinv/Fisher here. The caller should project exactly once via:
          step = project_phi_covector_to_step(covector, Jinv, Finv)
    """
    import numpy as np
    from core.numerical_utils import sanitize_sigma
    from core.transport_cache import Omega, Phi, E_grid

    # -- pull stats (sanitize once)
    mu_p = np.asarray(agent_i.mu_p_field,  np.float32, order="C")
    S_p  = sanitize_sigma(np.asarray(agent_i.sigma_p_field, np.float64), eps=eps).astype(np.float32, copy=False)
    mu_j = np.asarray(agent_j.mu_q_field,  np.float32, order="C")
    S_j  = sanitize_sigma(np.asarray(agent_j.sigma_q_field, np.float64), eps=eps).astype(np.float32, copy=False)

    # -- maps / composite R = Φ_i ∘ Ω^q_{ij}
    Om_q  = np.asarray(Omega_ij if Omega_ij is not None else Omega(ctx, agent_i, agent_j, which="q"), np.float32)
    Phi_i = np.asarray(Phi(ctx, agent_i, kind="q_to_p"), np.float32)
    R     = np.einsum("...ik,...kj->...ij", Phi_i, Om_q, optimize=True)

    # -- composite matrix co-gradient wrt R (Case A topology)
    G_R = cograd_caseA_composite_R(mu_p, S_p, mu_j, S_j, R, eps=eps, assume_sanitized=True)
    # G_R has shape (*S, Kp, Kq)

    # -- split to site-frame matrix co-grads (one per exponential map)
    Eqi = np.asarray(E_grid(ctx, agent_i, which="q"), np.float32)  # (*S, Kq, Kq)
    Eqj = np.asarray(E_grid(ctx, agent_j, which="q"), np.float32)  # (*S, Kq, Kq)
    Epi = np.asarray(E_grid(ctx, agent_i, which="p"), np.float32)  # (*S, Kp, Kp)

    # These helpers do the local chain rule dL/dE_* from dL/dR for topology A
    G_Eqi, G_Eqj, G_Epi = split_caseA_G_R_to_Es(G_R, Eqi, Eqj, Epi)

    # -- map matrix co-grads to param *covectors* (no Jinv/Finv here)
    #    (∂L/∂E) → (∂L/∂φ)_param via the irrep generators and frame E
    g_phi_i_q_cov = matrix_cograd_to_param_covector_irrep(Eqi, G_Eqi, generators_irrep)
    g_phi_j_q_cov = matrix_cograd_to_param_covector_irrep(Eqj, G_Eqj, generators_irrep)
    g_phi_i_p_cov = matrix_cograd_to_param_covector_irrep(Epi, G_Epi, generators_irrep)

    # dtypes/shape hygiene
    g_phi_i_q_cov = g_phi_i_q_cov.astype(np.float32, copy=False)
    g_phi_j_q_cov = g_phi_j_q_cov.astype(np.float32, copy=False)
    g_phi_i_p_cov = g_phi_i_p_cov.astype(np.float32, copy=False)

    return g_phi_i_q_cov, g_phi_j_q_cov, g_phi_i_p_cov




# ---------------- B: KL( p_i  ||  Φ_i[Ω q_j] )  — source in P_i
def grad_beta_B_mu_sigma_i(ctx, agent_i, agent_j, *, Omega_ij=None, eps: float = 1e-8):
    r"""
    ∂ KL_beta / ∂(μ_{p_i}, Σ_{p_i}) for **Case B**.

    Definition
    ----------
      KL_beta := KL( p_i  ||  Φ_i[ Ω^q_{ij} q_j ] ), evaluated in P_i-frame.

    Let
      • (μ_p, Σ_p) := (μ_{p_i}, Σ_{p_i})
      • Ω^q_{ij}: Q_j→Q_i,  Φ_i: Q_i→P_i
      • (μ_L, Σ_L) = Φ_i( Ω^q_{ij}(μ_{q_j}, Σ_{q_j}) )    # landed target in P_i

    Gaussian KL:
      KL = KL( 𝒩(μ_p, Σ_p)  ||  𝒩(μ_L, Σ_L) ).

    Source-form gradients in P_i:
      ∂KL/∂μ_p =  Σ_L^{-1} (μ_p − μ_L)
      ∂KL/∂Σ_p =  ½( Σ_p^{-1} − Σ_L^{-1} )

    Returns
    -------
      gμ_p : (*S, Kp)
      gΣ_p : (*S, Kp, Kp)
    """
    import numpy as np
    from core.numerical_utils import sanitize_sigma, push_gaussian, safe_inv  # push + SPD-safe inverse :contentReference[oaicite:0]{index=0}:contentReference[oaicite:1]{index=1}
    from core.transport_cache import Omega, Phi

    # -- p_i stats (sanitize once)
    mu_p = np.asarray(agent_i.mu_p_field,  np.float32, order="C")
    S_p  = sanitize_sigma(np.asarray(agent_i.sigma_p_field, np.float64)).astype(np.float32, copy=False)

    # -- maps
    Om_q  = np.asarray(Omega_ij if Omega_ij is not None else Omega(ctx, agent_i, agent_j, which="q"), np.float32)
    Phi_i = np.asarray(Phi(ctx, agent_i, kind="q_to_p"), np.float32)   # Φ_i: Q→P

    # -- q_j → Q_i (fast precision-push if cached), then Q_i → P_i via Φ_i
    mu_qj_t, S_qj_t, _ = push_neighbor_stats(agent_j, "sigma_q_field", Om_q, eps=eps)
    mu_L, S_L          = push_gaussian(mu_qj_t, S_qj_t, Phi_i, eps=eps)  # landed target in P_i :contentReference[oaicite:2]{index=2}

    # -- source-form KL grads in P_i
    S_L_inv = safe_inv(S_L, eps=max(eps, 1e-12))                        # Σ_L^{-1}         :contentReference[oaicite:3]{index=3}
    S_p_inv = safe_inv(S_p,  eps=max(eps, 1e-12))                        # Σ_p^{-1}

    dmu   = (mu_p - mu_L)
    gmu_p = np.einsum("...ij,...j->...i", S_L_inv, dmu, optimize=True)   # Σ_L^{-1}(μ_p−μ_L)

    gS_p  = 0.5 * (S_p_inv - S_L_inv)
    gS_p  = 0.5 * (gS_p + np.swapaxes(gS_p, -1, -2))                     # symmetrize for safety

    return gmu_p.astype(np.float32, copy=False), gS_p.astype(np.float32, copy=False)



def grad_beta_B_phi_covectors(
    ctx, agent_i, agent_j,
    *,
    Omega_ij=None,
    generators_irrep=None,   # (3,K,K) generators; K=3 fine
    eps: float = 1e-8,
):
    r"""
    Case B covectors (no projection here):
        KL_beta = KL( p_i  ||  Φ_i[ Ω^q_{ij} q_j ] ), in P_i-frame.

    Returns param-space covectors (∂KL_beta/∂φ)_param:
      g_phi_i_q_cov : (*S, 3)   # for E_q(i)
      g_phi_j_q_cov : (*S, 3)   # for E_q(j)
      g_phi_i_p_cov : (*S, 3)   # for E_p(i)

    Caller should project once:
        step = project_phi_covector_to_step(cov, Jinv, Finv)
    """
    import numpy as np
    from core.numerical_utils import sanitize_sigma
    from core.transport_cache import Omega, Phi, E_grid

    # --- stats (sanitize once)
    mu_p = np.asarray(agent_i.mu_p_field,  np.float32, order="C")
    S_p  = sanitize_sigma(np.asarray(agent_i.sigma_p_field, np.float64), eps=eps).astype(np.float32, copy=False)
    mu_j = np.asarray(agent_j.mu_q_field,  np.float32, order="C")
    S_j  = sanitize_sigma(np.asarray(agent_j.sigma_q_field, np.float64), eps=eps).astype(np.float32, copy=False)

    # --- maps
    Om_q  = np.asarray(Omega_ij if Omega_ij is not None else Omega(ctx, agent_i, agent_j, which="q"), np.float32)
    Phi_i = np.asarray(Phi(ctx, agent_i, kind="q_to_p"), np.float32)
    R     = np.einsum("...ik,...kj->...ij", Phi_i, Om_q, optimize=True)  # Q_j→P_i

    # --- composite co-grad wrt R for Case B
    G_R = cograd_caseB_composite_R(mu_p, S_p, mu_j, S_j, R, eps=eps, assume_sanitized=True)
    # shape (*S, Kp, Kq)

    # --- split to site-frame matrix co-grads
    Eqi = np.asarray(E_grid(ctx, agent_i, which="q"), np.float32)  # (*S, Kq, Kq)
    Eqj = np.asarray(E_grid(ctx, agent_j, which="q"), np.float32)  # (*S, Kq, Kq)
    Epi = np.asarray(E_grid(ctx, agent_i, which="p"), np.float32)  # (*S, Kp, Kp)

    Rt = np.swapaxes
    # Φ_i = E_p(i) E_q(i)^T, Ω^q_ij = E_q(i) E_q(j)^T  (in frames)
    Phi_m = np.einsum("...ik,...jk->...ij", Epi, Rt(Eqi, -1, -2), optimize=True)   # Q_i→P_i
    Om_m  = np.einsum("...ik,...jk->...ij", Eqi, Rt(Eqj, -1, -2), optimize=True)   # Q_j→Q_i

    # chain rule pieces
    G_Phi   = np.einsum("...ij,...kj->...ik", G_R, Rt(Om_m, -1, -2), optimize=True)      # G_R Ω^T
    G_Omega = np.einsum("...ji,...jk->...ik", Rt(Phi_m, -1, -2), G_R,  optimize=True)    # Φ^T G_R

    # wrt frame exponentials
    G_Epi     = np.einsum("...ij,...jk->...ik", G_Phi,   Eqi,                 optimize=True)
    G_Eqi_phi = np.einsum("...ij,...jk->...ik", Rt(Epi, -1, -2), G_Phi,      optimize=True)
    G_Eqi_omg = np.einsum("...ij,...jk->...ik", G_Omega, Eqj,                 optimize=True)
    G_Eqj     = np.einsum("...ij,...jk->...ik", Rt(Eqi, -1, -2), G_Omega,    optimize=True)
    G_Eqi     = G_Eqi_phi + G_Eqi_omg

    # --- map matrix co-grads → param covectors (NO Jinv/Finv here)
    g_phi_i_q_cov = matrix_cograd_to_param_covector_irrep(Eqi, G_Eqi, generators_irrep)
    g_phi_j_q_cov = matrix_cograd_to_param_covector_irrep(Eqj, G_Eqj, generators_irrep)
    g_phi_i_p_cov = matrix_cograd_to_param_covector_irrep(Epi, G_Epi, generators_irrep)

    return (g_phi_i_q_cov.astype(np.float32, copy=False),
            g_phi_j_q_cov.astype(np.float32, copy=False),
            g_phi_i_p_cov.astype(np.float32, copy=False))



# ---------------- C: KL( Φ̃_i p_i  ||  Ω q_j )  — source in Q_i (then chain back)
# ---------------- C: KL( Φ̃_i p_i  ||  Ω q_j )  — source in Q_i (then chain back)
def grad_beta_C_mu_sigma_i(ctx, agent_i, agent_j, *, Omega_ij=None, eps: float = 1e-8):
    r"""
    ∂ KL_beta / ∂ (μ_{p_i}, Σ_{p_i}) for **Case C**.

    Definition
    ----------
    KL_beta := KL( Φ̃_i p_i  ||  Ω^q_{ij} q_j ), evaluated in Q_i-frame.

    Let:
      • (μ_p, Σ_p) := (μ_{p_i}, Σ_{p_i})
      • Φ̃_i : P_i → Q_i
      • (μ_src, Σ_src) = Φ̃_i (μ_p, Σ_p)      # pushforward to Q_i
      • (μ_tgt, Σ_tgt) = Ω^q_{ij} (μ_{q_j}, Σ_{q_j})   # transported target to Q_i

    Gaussian KL:
      KL = KL( N(μ_src, Σ_src) || N(μ_tgt, Σ_tgt) )

    Source-form gradients in Q_i then chain back to P_i:
      gμ_src = Σ_tgt^{-1} (μ_src − μ_tgt)
      gΣ_src = ½ ( Σ_src^{-1} − Σ_tgt^{-1} )

      ∂KL/∂μ_p = Φ̃_iᵀ gμ_src
      ∂KL/∂Σ_p = Φ̃_iᵀ gΣ_src Φ̃_i

    Returns
    -------
      gμ_p : (*S, Kp)
      gΣ_p : (*S, Kp, Kp)
    """
    
    # If you placed push_neighbor_stats somewhere importable:
    # from <your_module> import push_neighbor_stats

    # -- pull p_i stats and sanitize once (kept in float32 like rest of the module)
    mu_p = np.asarray(agent_i.mu_p_field,  np.float32, order="C")
    S_p  = sanitize_sigma(np.asarray(agent_i.sigma_p_field, np.float64)).astype(np.float32, copy=False)

    # -- maps
    Om_q = np.asarray(Omega_ij if Omega_ij is not None else Omega(ctx, agent_i, agent_j, which="q"), np.float32)
    Phit = np.asarray(Phi(ctx, agent_i, kind="p_to_q"), np.float32)   # Φ̃_i: P→Q

    # -- target in Q_i: use the consolidated helper (fast precision-push if available)
    mu_tgt, S_tgt, S_tgt_inv = push_neighbor_stats(agent_j, "sigma_q_field", Om_q, eps=eps)

    # -- source in Q_i: push (μ_p, Σ_p) through Φ̃_i
    mu_src, S_src = push_gaussian(mu_p, S_p, Phit, eps=eps)  # μ_src=Φ̃μ_p, Σ_src=Φ̃ Σ_p Φ̃ᵀ  :contentReference[oaicite:0]{index=0}

    # -- closed-form source gradients in Q_i (avoid duplicating a helper)
    # gμ_src = Σ_tgt^{-1} (μ_src − μ_tgt)
    dmu   = (mu_src - mu_tgt)
    gmu_q = np.einsum("...ij,...j->...i", S_tgt_inv, dmu, optimize=True)

    # gΣ_src = ½ ( Σ_src^{-1} − Σ_tgt^{-1} )
    S_src_inv = safe_inv(S_src, eps=max(eps, 1e-12))          # SPD-safe inverse  :contentReference[oaicite:1]{index=1}
    gS_q = 0.5 * (S_src_inv - S_tgt_inv)
    gS_q = 0.5 * (gS_q + np.swapaxes(gS_q, -1, -2))           # symmetrize

    # -- chain back to P_i with Φ̃_iᵀ
    Phit_T = np.swapaxes(Phit, -1, -2)
    gmu_p  = np.einsum("...pq,...q->...p",  Phit_T, gmu_q, optimize=True)
    gS_p   = np.einsum("...pa,...ab,...qb->...pq", Phit_T, gS_q, Phit_T, optimize=True)
    gS_p   = 0.5 * (gS_p + np.swapaxes(gS_p, -1, -2))

    return gmu_p.astype(np.float32, copy=False), gS_p.astype(np.float32, copy=False)


def grad_beta_C_phi_covectors(
    ctx, agent_i, agent_j,
    *,
    Omega_ij=None,
    generators_irrep=None,   # (3,K,K) generators; K=3 fine
    eps: float = 1e-8,
):
    r"""
    Case C covectors (no projection here):
        KL_beta = KL( Φ̃_i p_i  ||  Ω^q_{ij} q_j )   in Q_i-frame.

    Returns param-space covectors (∂KL_beta/∂φ)_param:
      g_phi_i_q_cov : (*S, 3)   # for E_q(i)
      g_phi_j_q_cov : (*S, 3)   # for E_q(j)
      g_phi_i_p_cov : (*S, 3)   # for E_p(i)

    Caller should project once:
        step = project_phi_covector_to_step(cov, Jinv, Finv)
    """
    import numpy as np
    from core.numerical_utils import sanitize_sigma
    from core.transport_cache import Omega, Phi, E_grid

    # --- stats (sanitize once)
    mu_p = np.asarray(agent_i.mu_p_field,  np.float32, order="C")
    S_p  = sanitize_sigma(np.asarray(agent_i.sigma_p_field, np.float64), eps=eps).astype(np.float32, copy=False)
    mu_j = np.asarray(agent_j.mu_q_field,  np.float32, order="C")
    S_j  = sanitize_sigma(np.asarray(agent_j.sigma_q_field, np.float64), eps=eps).astype(np.float32, copy=False)

    # --- maps
    Om_q   = np.asarray(Omega_ij if Omega_ij is not None else Omega(ctx, agent_i, agent_j, which="q"), np.float32)
    Phit_i = np.asarray(Phi(ctx, agent_i, kind="p_to_q"), np.float32)  # Φ̃: P→Q

    # --- composite co-grads for Case C (w.r.t. Φ̃_i and Ω^q_{ij})
    G_Phit, G_Omega = cograd_caseC_phit_and_omega(
        mu_p, S_p, mu_j, S_j, Phit_i, Om_q, eps=eps, assume_sanitized=True
    )

    # --- split to site-frame matrix co-grads
    Eqi = np.asarray(E_grid(ctx, agent_i, which="q"), np.float32)  # (*S, Kq, Kq)
    Epi = np.asarray(E_grid(ctx, agent_i, which="p"), np.float32)  # (*S, Kp, Kp)
    Eqj = np.asarray(E_grid(ctx, agent_j, which="q"), np.float32)  # (*S, Kq, Kq)
    G_Eqi, G_Epi, G_Eqj = split_caseC_to_Es(G_Phit, G_Omega, Eqi, Epi, Eqj)

    # --- map matrix co-grads → param covectors (NO Jinv/Finv here)
    g_phi_i_q_cov = matrix_cograd_to_param_covector_irrep(Eqi, G_Eqi, generators_irrep)
    g_phi_j_q_cov = matrix_cograd_to_param_covector_irrep(Eqj, G_Eqj, generators_irrep)
    g_phi_i_p_cov = matrix_cograd_to_param_covector_irrep(Epi, G_Epi, generators_irrep)

    return (g_phi_i_q_cov.astype(np.float32, copy=False),
            g_phi_j_q_cov.astype(np.float32, copy=False),
            g_phi_i_p_cov.astype(np.float32, copy=False))



# ---------------- D: KL( Ω q_j  ||  Φ̃_i p_i )  — target in Q_i (then chain back)
def grad_beta_D_mu_sigma_i(ctx, agent_i, agent_j, *, Omega_ij=None, eps: float = 1e-8):
    r"""
    ∂ KL_beta / ∂(μ_{p_i}, Σ_{p_i}) for **Case D**.

    Definition
    ----------
    KL_beta := KL( Ω^q_{ij} q_j  ||  Φ̃_i p_i ), evaluated in Q_i-frame.

    Let:
      • (μ_qj, Σ_qj) be q_j in Q_j,  Ω^q_{ij}: Q_j→Q_i
      • (μ_src, Σ_src) = Ω^q_{ij}(μ_qj, Σ_qj)                  # source in Q_i
      • (μ_p, Σ_p) := (μ_{p_i}, Σ_{p_i}),  Φ̃_i: P_i→Q_i
      • (μ_tgt, Σ_tgt) = Φ̃_i(μ_p, Σ_p)                        # target in Q_i

    Gaussian KL:
      KL = KL( 𝒩(μ_src, Σ_src)  ||  𝒩(μ_tgt, Σ_tgt) ).

    Target-form gradients in Q_i then chain back to P_i:
      v        = Σ_tgt^{-1} (μ_src − μ_tgt)
      gμ_tgt   = −v
      gΣ_tgt   = ½( −Σ_tgt^{-1} Σ_src Σ_tgt^{-1} − v vᵀ + Σ_tgt^{-1} )

      ∂KL/∂μ_p = Φ̃_iᵀ gμ_tgt
      ∂KL/∂Σ_p = Φ̃_iᵀ gΣ_tgt Φ̃_i

    Returns
    -------
      gμ_p : (*S, Kp)
      gΣ_p : (*S, Kp, Kp)
    """
    import numpy as np
    from core.numerical_utils import sanitize_sigma, push_gaussian, safe_inv  # push & SPD-safe inverse :contentReference[oaicite:0]{index=0}:contentReference[oaicite:1]{index=1}
    from core.transport_cache import Omega, Phi
    # If push_neighbor_stats is in a local utils module, import it accordingly.
    # from <your_module> import push_neighbor_stats

    # -- pull p_i stats and sanitize once
    mu_p = np.asarray(agent_i.mu_p_field,  np.float32, order="C")
    S_p  = sanitize_sigma(np.asarray(agent_i.sigma_p_field, np.float64)).astype(np.float32, copy=False)

    # -- maps
    Om_q = np.asarray(Omega_ij if Omega_ij is not None else Omega(ctx, agent_i, agent_j, which="q"), np.float32)
    Phit = np.asarray(Phi(ctx, agent_i, kind="p_to_q"), np.float32)   # Φ̃_i: P→Q

    # -- SOURCE in Q_i: transported q_j → i  (fast precision-push if cached)
    mu_src, S_src, S_src_inv = push_neighbor_stats(agent_j, "sigma_q_field", Om_q, eps=eps)

    # -- TARGET in Q_i: Φ̃_i p_i
    mu_tgt, S_tgt = push_gaussian(mu_p, S_p, Phit, eps=eps)           # (μ_tgt, Σ_tgt) :contentReference[oaicite:2]{index=2}
    S_tgt_inv     = safe_inv(S_tgt, eps=max(eps, 1e-12))              # Σ_tgt^{-1}     :contentReference[oaicite:3]{index=3}

    # -- target-form Gaussian KL gradients in Q_i
    dmu   = (mu_src - mu_tgt)
    v     = np.einsum("...ij,...j->...i", S_tgt_inv, dmu, optimize=True)                 # v = Σ_tgt^{-1}(μ_src-μ_tgt)
    gmu_q = -v                                                                            # gμ_tgt

    t0    = -np.einsum("...ij,...jk,...kl->...il", S_tgt_inv, S_src, S_tgt_inv, optimize=True)
    vvT   = np.einsum("...i,...j->...ij", v, v, optimize=True)
    gS_q  = 0.5 * (t0 - vvT + S_tgt_inv)                                                 # gΣ_tgt
    gS_q  = 0.5 * (gS_q + np.swapaxes(gS_q, -1, -2))                                     # symmetrize

    # -- chain rule back to P_i with Φ̃_iᵀ
    Phit_T = np.swapaxes(Phit, -1, -2)
    gmu_p  = np.einsum("...pq,...q->...p",  Phit_T, gmu_q, optimize=True)
    gS_p   = np.einsum("...pa,...ab,...qb->...pq", Phit_T, gS_q, Phit_T, optimize=True)
    gS_p   = 0.5 * (gS_p + np.swapaxes(gS_p, -1, -2))

    return gmu_p.astype(np.float32, copy=False), gS_p.astype(np.float32, copy=False)



def grad_beta_D_phi_covectors(
    ctx, agent_i, agent_j,
    *,
    Omega_ij=None,
    generators_irrep=None,   # (3,K,K) generators; K=3 fine
    eps: float = 1e-8,
):
    r"""
    Case D covectors (no projection here):
        KL_beta = KL( Ω^q_{ij} q_j  ||  Φ̃_i p_i )  in Q_i-frame.

    Returns param-space covectors (∂KL_beta/∂φ)_param:
      g_phi_i_q_cov : (*S, 3)   # for E_q(i)
      g_phi_j_q_cov : (*S, 3)   # for E_q(j)
      g_phi_i_p_cov : (*S, 3)   # for E_p(i)

    Caller should project once:
        step = project_phi_covector_to_step(cov, Jinv, Finv)
    """
    import numpy as np
    from core.numerical_utils import sanitize_sigma
    from core.transport_cache import Omega, Phi, E_grid

    # --- stats (sanitize once)
    mu_p = np.asarray(agent_i.mu_p_field,  np.float32, order="C")
    S_p  = sanitize_sigma(np.asarray(agent_i.sigma_p_field, np.float64), eps=eps).astype(np.float32, copy=False)
    mu_j = np.asarray(agent_j.mu_q_field,  np.float32, order="C")
    S_j  = sanitize_sigma(np.asarray(agent_j.sigma_q_field, np.float64), eps=eps).astype(np.float32, copy=False)

    # --- maps
    Om_q   = np.asarray(Omega_ij if Omega_ij is not None else Omega(ctx, agent_i, agent_j, which="q"), np.float32)
    Phit_i = np.asarray(Phi(ctx, agent_i, kind="p_to_q"), np.float32)  # Φ̃: P→Q

    # --- composite co-grads for Case D (w.r.t. Ω^q_{ij} and Φ̃_i)
    # NB: ensure the helper returns (G_Omega, G_Phit) in this order
    G_Omega, G_Phit = cograd_caseD_phit_and_omega(
        mu_p, S_p, mu_j, S_j, Om_q, Phit_i, eps=eps, assume_sanitized=True
    )

    # --- split to site-frame matrix co-grads
    Eqi = np.asarray(E_grid(ctx, agent_i, which="q"), np.float32)  # (*S, Kq, Kq)
    Eqj = np.asarray(E_grid(ctx, agent_j, which="q"), np.float32)  # (*S, Kq, Kq)
    Epi = np.asarray(E_grid(ctx, agent_i, which="p"), np.float32)  # (*S, Kp, Kp)
    G_Eqi, G_Eqj, G_Epi = split_caseD_to_Es(G_Omega, G_Phit, Eqi, Eqj, Epi)

    # --- map matrix co-grads → param covectors (NO Jinv/Finv here)
    g_phi_i_q_cov = matrix_cograd_to_param_covector_irrep(Eqi, G_Eqi, generators_irrep)
    g_phi_j_q_cov = matrix_cograd_to_param_covector_irrep(Eqj, G_Eqj, generators_irrep)
    g_phi_i_p_cov = matrix_cograd_to_param_covector_irrep(Epi, G_Epi, generators_irrep)

    return (g_phi_i_q_cov.astype(np.float32, copy=False),
            g_phi_j_q_cov.astype(np.float32, copy=False),
            g_phi_i_p_cov.astype(np.float32, copy=False))





# ---------- Case A grads wrt p_i stats ----------

def cograd_caseA_composite_R(
    mu_p, sigma_p, mu_j, sigma_j, R, *, eps=1e-8, sigma_p_inv=None, assume_sanitized=True
):
    r"""
    G_R = ∂ KL( Φ_i[Ω^q_{ij} q_j] || p_i ) / ∂R, where R := Φ_i Ω^q_{ij} maps Q_j→P_i.

    Definitions
    -----------
    Let (μ_L, Σ_L) = (R μ_j, R Σ_j R^T), and KL := KL(N(μ_L, Σ_L) || N(μ_p, Σ_p)).
    The Gaussian KL is:
        KL = 1/2 [ tr(Σ_p^{-1} Σ_L) + (μ_p - μ_L)^T Σ_p^{-1} (μ_p - μ_L) - K + log(|Σ_p| / |Σ_L|) ].

    Gradients wrt source (μ_L, Σ_L):
        ∂KL/∂μ_L = Σ_p^{-1} (μ_L - μ_p)                          (source mean)
        ∂KL/∂Σ_L = 1/2 ( Σ_L^{-1} - Σ_p^{-1} )                    (source covariance)

    Chain rule to R using μ_L = R μ_j and Σ_L = R Σ_j R^T:
        ∂KL/∂R = (∂KL/∂μ_L) μ_j^T + 2 (∂KL/∂Σ_L) R Σ_j
    where (∂KL/∂Σ_L) is symmetric, so the 2× term is valid.

    Returns
    -------
      G_R : (*S, Kp, Kq)  with the same broadcasted spatial shape as inputs.
    """
    

    mu_p    = np.asarray(mu_p,    np.float32, order="C")
    sigma_p = np.asarray(sigma_p, np.float32, order="C")
    mu_j    = np.asarray(mu_j,    np.float32, order="C")
    sigma_j = np.asarray(sigma_j, np.float32, order="C")
    R       = np.asarray(R,       np.float32, order="C")
    Rt      = np.swapaxes(R, -1, -2)

    # --- map q_j → p_i: (μ_L, Σ_L) = (R μ_j, R Σ_j R^T)
    mu_L = np.einsum("...ik,...k->...i", R, mu_j, optimize=True)
    # FIX #1: use R Σ_j R^T  (the original code had "...jl" instead of "...lj")
    S_L  = np.einsum("...ik,...kl,...lj->...ij", R, sigma_j, Rt, optimize=True)
    S_L  = sanitize_sigma(S_L, eps=eps).astype(np.float32, copy=False)

    if sigma_p_inv is None:
        sigma_p_inv = safe_inv(sanitize_sigma(sigma_p, eps=eps) if not assume_sanitized else sigma_p)
    S_L_inv = safe_inv(S_L)

    # source-space grads wrt (μ_L, Σ_L)
    delta   = (mu_L - mu_p).astype(np.float32, copy=False)
    dKL_dmL = np.einsum("...ij,...j->...i", sigma_p_inv, delta, optimize=True)

    # FIX #2: sign — for SOURCE covariance: 1/2 ( Σ_L^{-1} - Σ_p^{-1} )
    dKL_dSL = 0.5 * (S_L_inv - sigma_p_inv)
    dKL_dSL = 0.5 * (dKL_dSL + np.swapaxes(dKL_dSL, -1, -2))  # symmetrize

    # assemble ∂KL/∂R = dμ term + covariance term
    term1 = np.einsum("...i,...j->...ij", dKL_dmL, mu_j, optimize=True)                      # (∂KL/∂μ_L) μ_j^T
    term2 = 2.0 * np.einsum("...ij,...jk,...kl->...il", dKL_dSL, R, sigma_j, optimize=True)  # 2 (∂KL/∂Σ_L) R Σ_j
    return (term1 + term2).astype(np.float32, copy=False)


def split_caseA_G_R_to_Es(G_R, Eqi, Eqj, Epi):
    """
    Split G_R (R = Φ_i Ω^q_{ij}) into co-grads on site frames (Eqi, Eqj, Epi).
    Returns (G_Eqi, G_Eqj, G_Epi).

    We use:
      Φ_i = E_p(i) E_q(i)^T                  (Q_i → P_i)
      Ω^q_{ij} = E_q(i) E_q(j)^T             (Q_j → Q_i)
      R = Φ_i Ω^q_{ij}.

    Matrix calculus:
      dR = dΦ · Ω + Φ · dΩ,
      with  dΦ = dE_p E_q^T + E_p dE_q^T,
            dΩ = dE_q(i) E_q(j)^T + E_q(i) dE_q(j)^T.

      Therefore:
        G_Φ  = G_R Ω^T
        G_Ω  = Φ^T G_R

        G_Ep = G_Φ E_q
        G_Eq(i) = E_p^T G_Φ + G_Ω E_q(j)
        G_Eq(j) = E_q(i)^T G_Ω

    Shapes are broadcast over spatial axes, last two are feature dims.
    """
    
    Rt = np.swapaxes

    # Φ_i and Ω_ij in site frames
    Phi   = np.einsum("...ik,...jk->...ij", Epi, Rt(Eqi, -1, -2), optimize=True)  # Q_i→P_i
    Omega = np.einsum("...ik,...jk->...ij", Eqi, Rt(Eqj, -1, -2), optimize=True)  # Q_j→Q_i

    # Use explicit transposes to avoid index mix-ups
    G_Phi = np.einsum("...ij,...kj->...ik", G_R, Rt(Omega, -1, -2), optimize=True)  # G_R Ω^T
    G_Omg = np.einsum("...ji,...jk->...ik", Rt(Phi, -1, -2), G_R,  optimize=True)   # Φ^T G_R

    G_Epi     = np.einsum("...ij,...jk->...ik", G_Phi, Eqi, optimize=True)                # G_Φ E_q(i)
    G_Eqi_phi = np.einsum("...ij,...jk->...ik", Rt(Epi, -1, -2), G_Phi, optimize=True)    # E_p(i)^T G_Φ
    G_Eqi_omg = np.einsum("...ij,...jk->...ik", G_Omg, Eqj, optimize=True)                # G_Ω E_q(j)
    G_Eqj     = np.einsum("...ij,...jk->...ik", Rt(Eqi, -1, -2), G_Omg, optimize=True)    # E_q(i)^T G_Ω

    G_Eqi = (G_Eqi_phi + G_Eqi_omg).astype(np.float32, copy=False)
    return G_Eqi, G_Eqj.astype(np.float32, copy=False), G_Epi.astype(np.float32, copy=False)





# ======================================================================
# ============================== Case B (φ / φ̃) ===============================
# KL_beta = KL( p_i || Φ_i[ Ω^q_{ij} q_j ] )  in P_i-frame
# We compute φ-gradients through the composite linear map R = Φ_i Ω^q_{ij} (Q_j→P_i)
# using your existing cograd_caseB_composite_R (∂KL/∂R), then split to frames and project.
#========================================================================


def cograd_caseB_composite_R(
    mu_p, sigma_p, mu_j, sigma_j, R, *, eps=1e-8, assume_sanitized=True
):
    r"""
    G_R = ∂/∂R KL( p_i || R[q_j] ), with R = Φ_i Ω^q_{ij}: Q_j → P_i.

    Definitions
    -----------
    Let (μ_L, Σ_L) = (R μ_j, R Σ_j R^T) and KL := KL( N(μ_p,Σ_p) || N(μ_L,Σ_L) ).
    Gaussian KL:
        KL = 1/2 [ tr(Σ_L^{-1}Σ_p) + (μ_L-μ_p)^T Σ_L^{-1} (μ_L-μ_p)
                   - K_p + log(|Σ_L|/|Σ_p|) ].

    Target-side partials (w.r.t. μ_L, Σ_L) for KL(source||target):
        v        = Σ_L^{-1}(μ_p - μ_L)
        ∂KL/∂μ_L  = -v
        ∂KL/∂Σ_L  = 1/2( -Σ_L^{-1} Σ_p Σ_L^{-1} - v v^T + Σ_L^{-1} )

    Chain rule through μ_L = R μ_j, Σ_L = R Σ_j R^T:
        ∂KL/∂R = (∂KL/∂μ_L) μ_j^T + 2 (∂KL/∂Σ_L) R Σ_j
    (since ∂KL/∂Σ_L is symmetric).

    Returns
    -------
      G_R : (*S, Kp, Kq)
    """
    

    mu_p    = np.asarray(mu_p,    np.float32, order="C")
    sigma_p = np.asarray(sigma_p, np.float32, order="C")
    mu_j    = np.asarray(mu_j,    np.float32, order="C")
    sigma_j = np.asarray(sigma_j, np.float32, order="C")
    R       = np.asarray(R,       np.float32, order="C")
    Rt      = np.swapaxes(R, -1, -2)

    # (μ_L, Σ_L) = (R μ_j, R Σ_j R^T) with explicit symmetrization
    mu_L = np.einsum("...ik,...k->...i", R,  mu_j, optimize=True)
    S_L  = np.einsum("...ik,...kl,...lj->...ij", R, sigma_j, Rt, optimize=True)
    S_L  = 0.5 * (S_L + np.swapaxes(S_L, -1, -2))
    S_L  = sanitize_sigma(S_L, eps=eps).astype(np.float32, copy=False)
    S_L_inv = safe_inv(S_L)

    delta   = (mu_p - mu_L).astype(np.float32, copy=False)
    dKL_dmL = -np.einsum("...ij,...j->...i", S_L_inv, delta, optimize=True)         # -v
    vvT     = np.einsum("...i,...j->...ij",
                        np.einsum("...ij,...j->...i", S_L_inv, delta, optimize=True),
                        np.einsum("...ij,...j->...i", S_L_inv, delta, optimize=True),
                        optimize=True)
    # 1/2( -Σ_L^{-1} Σ_p Σ_L^{-1} - v v^T + Σ_L^{-1} )
    t0      = -np.einsum("...ij,...jk,...kl->...il", S_L_inv, sigma_p, S_L_inv, optimize=True)
    dKL_dSL = 0.5 * (t0 - vvT + S_L_inv)
    dKL_dSL = 0.5 * (dKL_dSL + np.swapaxes(dKL_dSL, -1, -2))

    term1 = np.einsum("...i,...j->...ij", dKL_dmL, mu_j, optimize=True)
    term2 = 2.0 * np.einsum("...ij,...jk,...kl->...il", dKL_dSL, R, sigma_j, optimize=True)
    return (term1 + term2).astype(np.float32, copy=False)



def split_caseB_G_R_to_Es(G_R, Eqi, Eqj, Epi):
    r"""
    Split G_R = ∂KL / ∂R (with R = Φ_i Ω^q_{ij}) into co-gradients on site frames.

    Definitions
    -----------
      Φ_i    = E_p(i) E_q(i)^T     : Q_i → P_i
      Ω^q_{ij}= E_q(i) E_q(j)^T    : Q_j → Q_i
      R      = Φ_i Ω^q_{ij}

    First-order variations:
      dR = dΦ · Ω + Φ · dΩ

      with  dΦ = dE_p E_q(i)^T + E_p dE_q(i)^T
            dΩ = dE_q(i) E_q(j)^T + E_q(i) dE_q(j)^T

    Co-gradient splits:
      G_Φ  = G_R Ω^T
      G_Ω  = Φ^T G_R

      ⇒ on frames
        G_{E_p(i)}   = G_Φ E_q(i)
        G_{E_q(i)}   = E_p(i)^T G_Φ + G_Ω E_q(j)
        G_{E_q(j)}   = E_q(i)^T G_Ω

    Returns
    -------
      (G_Eqi, G_Eqj, G_Epi)  matrix co-gradients matching each frame's rep
    """
    
    Rt = np.swapaxes

    # Build Φ and Ω from frames (keeps everything explicit and local)
    Phi   = np.einsum("...ik,...jk->...ij", Epi, Rt(Eqi, -1, -2), optimize=True)   # Q_i→P_i
    Omega = np.einsum("...ik,...jk->...ij", Eqi, Rt(Eqj, -1, -2), optimize=True)   # Q_j→Q_i

    G_Phi   = np.einsum("...ij,...kj->...ik", G_R, Rt(Omega, -1, -2), optimize=True)   # G_R Ω^T
    G_Omega = np.einsum("...ji,...jk->...ik", Rt(Phi, -1, -2), G_R,            optimize=True)   # Φ^T G_R

    G_Epi     = np.einsum("...ij,...jk->...ik", G_Phi,   Eqi, optimize=True)
    G_Eqi_phi = np.einsum("...ij,...jk->...ik", Rt(Epi, -1, -2), G_Phi, optimize=True)
    G_Eqi_omg = np.einsum("...ij,...jk->...ik", G_Omega, Eqj,   optimize=True)
    G_Eqj     = np.einsum("...ij,...jk->...ik", Rt(Eqi, -1, -2), G_Omega, optimize=True)

    G_Eqi = (G_Eqi_phi + G_Eqi_omg).astype(np.float32, copy=False)
    return G_Eqi, G_Eqj.astype(np.float32, copy=False), G_Epi.astype(np.float32, copy=False)






# =========================================
#           Case C  (p → q fiber)
# KL_beta = KL( Φ̃_i p_i  ||  Ω^q_{ij} q_j )   [Q_i frame]
# =========================================

def cograd_caseC_phit_and_omega(
    mu_p, sigma_p, mu_j, sigma_j, Phit, Omega, *, eps=1e-8, assume_sanitized=True
):
    """
    Returns (G_Phit, G_Omega) with shapes (*S, 3, 3):
      G_Phit  = ∂ KL( Φ̃_i p_i  ||  Ω^q_{ij} q_j ) / ∂ Φ̃_i
      G_Omega = ∂ KL( Φ̃_i p_i  ||  Ω^q_{ij} q_j ) / ∂ Ω^q_{ij}

    Notation
    --------
      L := Φ̃_i[ p_i ]  = N(μ_L, Σ_L),   μ_L = Φ̃ μ_p,   Σ_L = Φ̃ Σ_p Φ̃^T
      R := Ω^q_{ij}[ q_j ] = N(μ_R, Σ_R), μ_R = Ω μ_j,   Σ_R = Ω Σ_j Ω^T

    Partials for KL( L || R ) (Gaussian):
      Source (L):
        dμ_L =  Σ_R^{-1}(μ_L - μ_R)
        dΣ_L =  1/2 ( Σ_L^{-1} - Σ_R^{-1} )
      Target (R):
        v    =  Σ_R^{-1}(μ_L - μ_R)
        dμ_R = -v
        dΣ_R =  1/2 ( -Σ_R^{-1} Σ_L Σ_R^{-1} - v v^T + Σ_R^{-1} )

    Chain rule through linear maps A x + … with A ∈ {Φ̃, Ω}:
      ∂KL/∂A = (∂KL/∂μ_out) μ_in^T  +  2 · sym(∂KL/∂Σ_out) · A · Σ_in
    """
    

    mu_p    = np.asarray(mu_p,    np.float32, order="C")
    sigma_p = np.asarray(sigma_p, np.float32, order="C")
    mu_j    = np.asarray(mu_j,    np.float32, order="C")
    sigma_j = np.asarray(sigma_j, np.float32, order="C")
    Phit    = np.asarray(Phit,    np.float32, order="C")
    Omega   = np.asarray(Omega,   np.float32, order="C")

    PhitT, OmT = np.swapaxes(Phit, -1, -2), np.swapaxes(Omega, -1, -2)

    # Map to Q_i frame
    mu_L = np.einsum("...ij,...j->...i", Phit,  mu_p, optimize=True)
    S_L  = np.einsum("...ik,...kl,...lj->...ij", Phit,  sigma_p, PhitT, optimize=True)

    mu_R = np.einsum("...ij,...j->...i", Omega, mu_j,  optimize=True)
    S_R  = np.einsum("...ik,...kl,...lj->...ij", Omega, sigma_j,  OmT,   optimize=True)
    S_L  = sanitize_sigma(0.5*(S_L + np.swapaxes(S_L,-1,-2)), eps=eps).astype(np.float32, copy=False)
    S_R  = sanitize_sigma(0.5*(S_R + np.swapaxes(S_R,-1,-2)), eps=eps).astype(np.float32, copy=False)

    S_L_inv = safe_inv(S_L)
    S_R_inv = safe_inv(S_R)

    # Partials
    delta = (mu_L - mu_R).astype(np.float32, copy=False)
    v     = np.einsum("...ij,...j->...i", S_R_inv, delta, optimize=True)

    # Source (L) partials -- CORRECTED
    dmu_L = v
    dS_L  = 0.5 * (S_L_inv - S_R_inv)
    dS_L  = 0.5 * (dS_L + np.swapaxes(dS_L, -1, -2))

    # Target (R) partials
    vvT   = np.einsum("...i,...j->...ij", v, v, optimize=True)
    t0    = -np.einsum("...ij,...jk,...kl->...il", S_R_inv, S_L, S_R_inv, optimize=True)
    dmu_R = -v
    dS_Rg = 0.5 * (t0 - vvT + S_R_inv)
    dS_Rg = 0.5 * (dS_Rg + np.swapaxes(dS_Rg, -1, -2))

    # Co-grads wrt linear maps
    G_Phit  = cograd_linear_map(Phit,  mu_p, sigma_p, dmu_L, dS_L)
    G_Omega = cograd_linear_map(Omega, mu_j, sigma_j, dmu_R, dS_Rg)
    return G_Phit, G_Omega

def split_caseC_to_Es(G_Phit, G_Omega, Eqi, Epi, Eqj):
    """
    Split to site-frame co-grads (all (*S,3,3)):
      Φ̃ = E_q(i) E_p(i)^T ,  Ω = E_q(i) E_q(j)^T.

      G_{E_q(i)} = (G_Phit) E_p(i) + E_q(i)^T G_Omega
      G_{E_p(i)} = (G_Phit)^T E_q(i)
      G_{E_q(j)} = E_q(i)^T G_Omega
    """
    
    Rt = np.swapaxes

    # Φ̃ path: Φ̃ = Eqi @ Epi^T
    G_Eqi_phit = np.einsum("...ij,...jk->...ik", G_Phit, Epi, optimize=True)
    G_Epi      = np.einsum("...ij,...jk->...ik", Rt(G_Phit,-1,-2), Eqi, optimize=True)

    # Ω path: Ω = Eqi @ Eqj^T
    G_Eqi_omg = np.einsum("...ij,...jk->...ik", G_Omega, Eqj, optimize=True)
    G_Eqj     = np.einsum("...ij,...jk->...ik", Rt(Eqi,-1,-2), G_Omega, optimize=True)

    G_Eqi = (G_Eqi_phit + G_Eqi_omg).astype(np.float32, copy=False)
    return G_Eqi, G_Epi.astype(np.float32, copy=False), G_Eqj.astype(np.float32, copy=False)






# ===============================
#              Case D
# KL_beta = KL( Ω^q_{ij} q_j  ||  Φ̃_i p_i )   [Q_i frame]
# ===============================

def cograd_caseD_phit_and_omega(
    mu_p, sigma_p, mu_j, sigma_j, Omega, Phit, *, eps=1e-8, assume_sanitized=True
):
    """
    Returns (G_Omega, G_Phit) with shapes (*S, 3, 3):
      G_Omega = ∂ KL( Ω^q_{ij} q_j  ||  Φ̃_i p_i ) / ∂ Ω^q_{ij}   (source path)
      G_Phit  = ∂ KL( Ω^q_{ij} q_j  ||  Φ̃_i p_i ) / ∂ Φ̃_i       (target path)

    Notation
    --------
      L := Ω[ q_j ] = N(μ_L, Σ_L) with μ_L = Ω μ_j,  Σ_L = Ω Σ_j Ω^T
      R := Φ̃[ p_i ] = N(μ_R, Σ_R) with μ_R = Φ̃ μ_p, Σ_R = Φ̃ Σ_p Φ̃^T

    Partials
    --------
      Source (L):
        dμ_L =  Σ_R^{-1}(μ_L - μ_R)
        dΣ_L =  1/2 ( Σ_L^{-1} - Σ_R^{-1} )
      Target (R):
        v    =  Σ_R^{-1}(μ_L - μ_R)
        dμ_R = -v
        dΣ_R =  1/2 ( -Σ_R^{-1} Σ_L Σ_R^{-1} - v v^T + Σ_R^{-1} )

    Chain rule (linear pushforward A x, with A ∈ {Ω, Φ̃}):
      ∂KL/∂A = (∂KL/∂μ_out) μ_in^T  +  2·sym(∂KL/∂Σ_out) · A · Σ_in
    """
    

    mu_p    = np.asarray(mu_p,    np.float32, order="C")
    sigma_p = np.asarray(sigma_p, np.float32, order="C")
    mu_j    = np.asarray(mu_j,    np.float32, order="C")
    sigma_j = np.asarray(sigma_j, np.float32, order="C")
    Omega   = np.asarray(Omega,   np.float32, order="C")
    Phit    = np.asarray(Phit,    np.float32, order="C")

    OmT, PhitT = np.swapaxes(Omega, -1, -2), np.swapaxes(Phit, -1, -2)

    # Map both sides into Q_i
    mu_L = np.einsum("...ij,...j->...i", Omega, mu_j, optimize=True)
    S_L  = np.einsum("...ik,...kl,...lj->...ij", Omega, sigma_j, OmT, optimize=True)

    mu_R = np.einsum("...ij,...j->...i", Phit,  mu_p,  optimize=True)
    S_R  = np.einsum("...ik,...kl,...lj->...ij", Phit,  sigma_p, PhitT, optimize=True)

    # SPD clean + inverses
    S_L  = sanitize_sigma(0.5*(S_L + np.swapaxes(S_L,-1,-2)), eps=eps).astype(np.float32, copy=False)
    S_R  = sanitize_sigma(0.5*(S_R + np.swapaxes(S_R,-1,-2)), eps=eps).astype(np.float32, copy=False)
    S_L_inv = safe_inv(S_L)
    S_R_inv = safe_inv(S_R)

    delta = (mu_L - mu_R).astype(np.float32, copy=False)
    v     = np.einsum("...ij,...j->...i", S_R_inv, delta, optimize=True)  # Σ_R^{-1}(μ_L - μ_R)

    # Source (L) partials — CORRECT
    dmu_L = v
    dS_L  = 0.5 * (S_L_inv - S_R_inv)
    dS_L  = 0.5 * (dS_L + np.swapaxes(dS_L, -1, -2))

    # Target (R) partials
    vvT   = np.einsum("...i,...j->...ij", v, v, optimize=True)
    t0    = -np.einsum("...ij,...jk,...kl->...il", S_R_inv, S_L, S_R_inv, optimize=True)
    dmu_R = -v
    dS_Rg = 0.5 * (t0 - vvT + S_R_inv)
    dS_Rg = 0.5 * (dS_Rg + np.swapaxes(dS_Rg, -1, -2))

    # Co-gradients wrt the linear maps
    G_Omega = cograd_linear_map(Omega, mu_j, sigma_j, dmu_L, dS_L)
    G_Phit  = cograd_linear_map(Phit,  mu_p, sigma_p, dmu_R, dS_Rg)
    return G_Omega, G_Phit


def split_caseD_to_Es(G_Omega, G_Phit, Eqi, Eqj, Epi):
    """
    Split to site-frame co-grads (all (*S,3,3)):
      Ω   = E_q(i) E_q(j)^T
      Φ̃  = E_q(i) E_p(i)^T

      ⇒
        G_{E_q(i)} = (from Ω) G_Omega E_q(j)  +  (from Φ̃) G_Phit E_p(i)
        G_{E_q(j)} = E_q(i)^T G_Omega
        G_{E_p(i)} = (G_Phit)^T E_q(i)
    """
    
    Rt = np.swapaxes

    # Ω path
    G_Eqi_omg = np.einsum("...ij,...jk->...ik", G_Omega, Eqj, optimize=True)
    G_Eqj     = np.einsum("...ij,...jk->...ik", Rt(Eqi,-1,-2), G_Omega, optimize=True)

    # Φ̃ path
    G_Eqi_phit = np.einsum("...ij,...jk->...ik", G_Phit, Epi, optimize=True)
    G_Epi      = np.einsum("...ij,...jk->...ik", Rt(G_Phit,-1,-2), Eqi, optimize=True)

    G_Eqi = (G_Eqi_omg + G_Eqi_phit).astype(np.float32, copy=False)
    return G_Eqi, G_Eqj.astype(np.float32, copy=False), G_Epi.astype(np.float32, copy=False)








# ---------- generic helper: co-grad wrt a linear map R ----------
def cograd_linear_map(R, mu_src, Sigma_src, dKL_dm_side, dKL_dS_side):
    """
    Co-gradient for a pushforward L = R[N(mu_src, Sigma_src)]:
      ∂KL/∂R = (∂KL/∂μ_L) μ_src^T + 2 (∂KL/∂Σ_L)_sym R Σ_src
    """
    dS = 0.5 * (dKL_dS_side + np.swapaxes(dKL_dS_side, -1, -2))
    t1 = np.einsum("...i,...j->...ij", dKL_dm_side, mu_src, optimize=True)
    t2 = 2.0 * np.einsum("...ij,...jk,...kl->...il", dS, R, Sigma_src, optimize=True)
    return (t1 + t2).astype(np.float32, copy=False)


def matrix_cograd_to_param_covector_irrep(E, G_E, generators_irrep=None):
    """
    Map a matrix co-gradient G_E (same rep as E) to a parameter-space covector (*S,3).

    If generators_irrep is provided (shape (3,K,K)), use the general irrep path:
        α_a = tr( E^T G_E  · G_a^T )
    Otherwise, if K==3, use the adjoint fast-path (no generators required).

    Args:
      E:    (*S, K, K)  frame in some SO(3) rep
      G_E:  (*S, K, K)  matrix co-gradient w.r.t. E
      generators_irrep: optional (3,K,K)

    Returns:
      covector: (*S, 3)  in parameter coordinates (right-trivialized)
    """
    Rt = np.swapaxes
   
    # General irrep path when generators are given
    if generators_irrep is not None:
        H = np.einsum("...ij,...jk->...ik", Rt(E, -1, -2), G_E, optimize=True)  # H = E^T G_E
        # α_a = tr(H G_a^T)
        cov = np.stack(
            [np.einsum("...ij,ij->...", H, generators_irrep[a], optimize=True) for a in range(3)],
            axis=-1
        )
        return cov.astype(np.float32, copy=False)

    raise ValueError(
        "matrix_cograd_to_param_covector_irrep: either provide generators_irrep "
        "or ensure K==3 for the adjoint fast-path."
    )
















