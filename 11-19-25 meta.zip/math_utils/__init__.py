# -*- coding: utf-8 -*-
"""
Created on Sat Nov  8 13:22:54 2025

@author: chris and christine
"""

