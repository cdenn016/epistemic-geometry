# -*- coding: utf-8 -*-
"""
Created on Wed Jul 23 18:00:25 2025

@author: chris and christine
"""

import numpy as np
import config
from scipy.linalg import expm
from joblib import Parallel, delayed, parallel_backend
from scipy.ndimage import gaussian_filter
from numerical_utils import sanitize_sigma
from numerical_utils import safe_omega_inv
import config
from generalized_math_utils import safe_batch_inverse
from scipy.linalg import logm, expm

import numpy as np
from scipy.linalg import expm, logm
import warnings

def bch(A, B, max_norm=10.0, inf_tol=1e6, verbose=False):
    """
    4th-order BCH approximation with clipping and numerical guards.

    Computes:
        log(exp(A) @ exp(B)) ≈ A + B + ½[A,B] + 1/12 [A,[A,B]] - 1/12 [B,[B,A]] - 1/24 [B,[A,[A,B]]]

    Args:
        A, B       : (K, K) real matrices (Lie algebra elements)
        max_norm   : clip input matrices if ||M|| > max_norm (for stability)
        inf_tol    : if output norm > inf_tol, emit warning
        verbose    : if True, print norm diagnostics

    Returns:
        Real matrix (K, K) — safe approximation to log(exp(A) @ exp(B))
    """
    import numpy as np
    import warnings

    # Defensive copy
    A = np.array(A, dtype=np.float64, copy=True)
    B = np.array(B, dtype=np.float64, copy=True)

    # ─── Clip A and B to max_norm ───
    for name, M in zip(("A", "B"), (A, B)):
        norm = np.linalg.norm(M, ord=np.inf)
        if not np.isfinite(norm) or norm > max_norm:
            scale = max_norm / (norm + 1e-10)
            M *= scale
            if verbose:
                print(f"[bch] Clipped {name} norm {norm:.2e} → {max_norm:.2f}")

    # ─── Commutators ───
    AB   = A @ B - B @ A
    AAB  = A @ AB - AB @ A
    BAB  = B @ AB - AB @ B
    BAAB = B @ AAB - AAB @ B

    # ─── BCH Expansion ───
    out = A + B
    out += 0.5 * AB
    out += (1.0 / 12.0) * AAB
    out -= (1.0 / 12.0) * BAB
    out -= (1.0 / 24.0) * BAAB

    # ─── Final Safety Guard ───
    out = np.nan_to_num(out, nan=0.0, posinf=max_norm, neginf=-max_norm)

    out_norm = np.linalg.norm(out, ord="fro")
    if not np.isfinite(out_norm) or out_norm > inf_tol:
        warnings.warn(f"[bch] Large or invalid BCH result ‖out‖ = {out_norm:.2e}", RuntimeWarning)

    return out

def safe_bch_exact(A, B, max_norm=5.0, imag_tol=1e-10, verbose=False):
    """
    Safe BCH with fallback and optional clipping, minimal + robust.
    """
    A = np.array(A, dtype=np.float64, copy=True)
    B = np.array(B, dtype=np.float64, copy=True)

    for name, M in zip(("A", "B"), (A, B)):
        norm = np.linalg.norm(M, ord=np.inf)
        if norm > max_norm:
            M *= max_norm / (norm + 1e-10)
            if verbose:
                warnings.warn(f"[safe_bch_exact] Clipped {name} norm {norm:.2e} → {max_norm}", RuntimeWarning)

    try:
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            C = logm(expm(A) @ expm(B))

        err = np.linalg.norm(np.imag(C), ord="fro")
        if err > imag_tol and verbose:
            warnings.warn(f"[safe_bch_exact] Im(logm) = {err:.2e}. Returning Re(C).", RuntimeWarning)

        return np.nan_to_num(C.real, nan=0.0, posinf=max_norm, neginf=-max_norm)

    except Exception as e:
        if verbose:
            warnings.warn(f"[safe_bch_exact] logm failed: {e}. Falling back to 4th-order BCH.", RuntimeWarning)
        return bch(A, B, max_norm=max_norm, inf_tol=1e6)



def safe_bch_exact_SPAM(A, B, max_norm=500, imag_tol=1e-10, verbose=False):
    """
    Safe BCH with fallback and clipping.

    Tries log(exp(A) @ exp(B)) (exact), falls back to 4th-order BCH if needed.

    Args:
        A, B     : (K, K) Lie algebra elements
        max_norm : clip matrices if ||·||_∞ > max_norm
        imag_tol : if Im(logm) > imag_tol, suppress and project to real
        verbose  : whether to emit warnings or diagnostics

    Returns:
        C        : real matrix ≈ log(exp(A) @ exp(B))
    """
    import numpy as np
    from scipy.linalg import expm, logm
    import warnings

    A = np.array(A, dtype=np.float64, copy=True)
    B = np.array(B, dtype=np.float64, copy=True)

    # Clip large input matrices (∞-norm)
    for name, M in zip(("A", "B"), (A, B)):
        norm = np.linalg.norm(M, ord=np.inf)
        if not np.isfinite(norm) or norm > max_norm:
            scale = max_norm / (norm + 1e-10)
            M *= scale
            if verbose:
                warnings.warn(f"[safe_bch_exact] Clipped {name} norm {norm:.2e} → {max_norm}", RuntimeWarning)

    try:
        AB = expm(A) @ expm(B)

        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            C = logm(AB)

        imag_norm = np.linalg.norm(np.imag(C), ord="fro")
        if imag_norm > imag_tol:
            if verbose:
                warnings.warn(f"[safe_bch_exact] ‖Im(logm)‖ = {imag_norm:.2e}. Returning Re(C).", RuntimeWarning)
            C_real = np.real(C)
        else:
            C_real = np.real_if_close(C, tol=imag_tol)

        return np.nan_to_num(C_real, nan=0.0, posinf=max_norm, neginf=-max_norm)

    except Exception as e:
        if verbose:
            warnings.warn(f"[safe_bch_exact] logm failed: {e}. Falling back to 4th-order BCH.", RuntimeWarning)
        return bch(A, B, max_norm=max_norm, inf_tol=1e6)




def adaptive_expm(G, clip_norm=None, max_norm=None, threshold=1e-3):
    """
    Numerically robust expm(G) with optional scaling and Taylor fallback.

    Args:
        G         : (K, K) Lie algebra element
        clip_norm : soft cap — rescales G if ‖G‖ > clip_norm
        max_norm  : hard cap — forcibly rescales G if ‖G‖ > max_norm
        threshold : below this, use 4th-order Taylor

    Returns:
        exp(G) ∈ Lie group, (K, K) matrix
    """
    import numpy as np
    from scipy.linalg import expm

    if not np.all(np.isfinite(G)):
        raise ValueError("[adaptive_expm] Input G contains NaN or Inf")

    norm_G = np.linalg.norm(G, ord=np.inf) + 1e-16  # use ∞-norm for stability

    # Hard cap first
    if max_norm is not None and norm_G > max_norm:
        G = G * (max_norm / norm_G)
        norm_G = max_norm  # update

    # Soft clip next
    elif clip_norm is not None and norm_G > clip_norm:
        G = G * (clip_norm / norm_G)
        norm_G = clip_norm  # update

    if norm_G < threshold:
        I = np.eye(G.shape[0], dtype=G.dtype)
        G2 = G @ G
        G3 = G2 @ G
        G4 = G3 @ G
        out = I + G + 0.5 * G2 + (1/6) * G3 + (1/24) * G4
    else:
        out = expm(G)

    return np.nan_to_num(out, nan=0.0, posinf=1e6, neginf=-1e6)

def exp_lie_algebra_irrep(
    v_batch,
    generators,
    use_expm=True,
    threshold=1e-3,
    max_norm=None,
    group_name="so3",
    n_jobs=-1,
    verbose=False
):
    """
    Compute batch of exp(sum_a v[a] * T_a) using Taylor or expm depending on norm.

    Parameters:
        v_batch    : (..., dim_G) Lie algebra coefficients
        generators : (dim_G, K, K) Lie algebra generators
        use_expm   : if True, fallback to expm for large-norm elements
        threshold  : Taylor cutoff norm
        max_norm   : optional clip threshold (default from config.phi_exp_clip)
        group_name : used for antisymmetrization ("so3", "su2", etc)
        n_jobs     : number of parallel workers for expm fallback
        verbose    : whether to print clipping info

    Returns:
        (..., K, K) exponentiated matrices
    """
   

    *batch_shape, dim_G = v_batch.shape
    v_flat = v_batch.reshape(-1, dim_G)
    N = v_flat.shape[0]
    _, K, _ = generators.shape
    dtype = np.result_type(v_batch, generators)

    # ─── Clip large φ vectors ─────────────────────────────────────────────
    
    clip_norm = max_norm if max_norm is not None else getattr(config, "phi_exp_clip", 10.0)
    norm_type = getattr(config, "gradient_clip_norm_type", 2)

    eps = 1e-16

    norms = np.linalg.norm(v_flat, axis=1, ord=norm_type)
    scale_factors = np.minimum(1.0, clip_norm / (norms + eps))
    v_scaled = v_flat * scale_factors[:, None]
    norms_scaled = np.linalg.norm(v_scaled, axis=1, ord=norm_type)

    if verbose and np.any(scale_factors < 1.0):
        print(f"[Ω] Clipped {np.sum(scale_factors < 1)} / {N} φ vectors to ‖φ‖ ≤ {clip_norm}")

    # ─── Build algebra elements ───────────────────────────────────────────
    G_batch = np.einsum("na,aij->nij", v_scaled, generators)

    if group_name == "so3":
        G_batch = 0.5 * (G_batch - np.transpose(G_batch, axes=(0, 2, 1)))
    elif group_name == "su2":
        G_batch = 0.5 * (G_batch - np.transpose(G_batch, axes=(0, 2, 1)).conj())
    elif group_name is None:
        warnings.warn("[exp_lie_algebra_irrep] group_name not set — antisymmetrization skipped", stacklevel=2)

    result = np.empty((N, K, K), dtype=dtype)
    approx_mask = norms_scaled < threshold

    # ─── Use Taylor expansion for small matrices ──────────────────────────
    if np.any(approx_mask):
        G_approx = G_batch[approx_mask]
        I = np.eye(K, dtype=dtype)[None, :, :]
        G2 = np.matmul(G_approx, G_approx)
        G3 = np.matmul(G2, G_approx)
        G4 = np.matmul(G2, G2)
        result[approx_mask] = (
            I + G_approx + 0.5 * G2 + (1.0 / 6.0) * G3 + (1.0 / 24.0) * G4
        )

    # ─── Fallback expm for heavy matrices ─────────────────────────────────
    if np.any(~approx_mask):
        G_heavy = G_batch[~approx_mask]
        with parallel_backend("threading"):
            expm_results = Parallel(n_jobs=n_jobs)(
                delayed(adaptive_expm)(
                    G, clip_norm=None, max_norm=clip_norm, threshold=0.0  # skip redundant Taylor check
                ) for G in G_heavy
            )
        result[~approx_mask] = np.stack(expm_results, axis=0)

    result = np.nan_to_num(result, nan=0.0, posinf=1e6, neginf=-1e6)
    return result.reshape(*batch_shape, K, K)









def d_exp_phi_exact(phi_vec, generators, num_points=20, group_name="so3", threshold=0.3):
    """
    Hybrid: fast approximation if ‖φ‖ < threshold, else use numerical quadrature.

    Args:
        phi_vec   : (..., d)
        generators: (d, K, K)
        num_points: for trapezoidal rule (if exact)
        group_name: e.g. "so3"
        threshold : norm cutoff to switch method

    Returns:
        d_exp_list: list of (..., K, K), one for each ∂ e^φ / ∂ φ^a
    """
    

    d, K, _ = generators.shape
    shape = phi_vec.shape[:-1]
    phi_flat = phi_vec.reshape(-1, d)
    N = phi_flat.shape[0]

    phi_mat = np.einsum("nd,dij->nij", phi_flat, generators)
    norms = np.linalg.norm(phi_flat, axis=1)
    use_fast = norms < threshold

    # Precompute e^{φ}
    exp_phi_all = exp_lie_algebra_irrep(phi_flat, generators, group_name=group_name)  # (N, K, K)

    d_exp_list = []
    for a in range(d):
        G_a = generators[a]

        grad = np.zeros((N, K, K))
        if np.any(use_fast):
            # Fast commutator approximation
            phi_batch = phi_mat[use_fast]
            exp_phi_batch = exp_phi_all[use_fast]

            # Broadcast G_a to match (N, K, K) if needed
            G_a_broadcast = np.broadcast_to(G_a, phi_batch.shape)

            # comm1 = [φ, Gₐ]
            comm1 = np.matmul(phi_batch, G_a_broadcast) - np.matmul(G_a_broadcast, phi_batch)

# comm2 = [φ, [φ, Gₐ]]
            comm2 = np.matmul(phi_batch, comm1) - np.matmul(comm1, phi_batch)

# comm3 = [φ, [φ, [φ, Gₐ]]]
            comm3 = np.matmul(phi_batch, comm2) - np.matmul(comm2, phi_batch)

            approx = (
                G_a_broadcast
                - 0.5 * comm1
                + (1.0 / 6.0) * comm2
                - (1.0 / 24.0) * comm3
                )

            grad[use_fast] = np.einsum("...ij,...jk->...ik", exp_phi_batch, approx)


        if np.any(~use_fast):
            # Exact trapezoidal quadrature
            s_vals = np.linspace(0, 1, num_points)
            w_vals = np.ones(num_points)
            w_vals[0] = w_vals[-1] = 0.5
            w_vals /= (num_points - 1)

            phi_heavy = phi_mat[~use_fast]
            grad_heavy = np.zeros_like(phi_heavy)

            for s, w in zip(s_vals, w_vals):
                exp_s_phi   = np.stack([adaptive_expm(s * M) for M in phi_heavy])
                exp_1ms_phi = np.stack([adaptive_expm((1 - s) * M) for M in phi_heavy])
               
                grad_heavy += w * np.einsum("nij,jk,nkl->nil", exp_s_phi, G_a, exp_1ms_phi)

            grad[~use_fast] = grad_heavy

        d_exp_list.append(grad.reshape(*shape, K, K))

    return d_exp_list

def d_exp_minus_phi(phi_vec, generators, num_points=20, group_name="so3", threshold=0.3):
    """
    Compute ∂/∂φ^a e^{-φ} using BCH (approx) or numerical quadrature (exact).

    Args:
        phi_vec   : (..., d)
        generators: (d, K, K)
        num_points: number of integration points (for trapezoidal rule)
        group_name: used by exp_lie_algebra_irrep
        threshold : norm cutoff for fast vs. exact method

    Returns:
        d_exp_all : (..., d, K, K)
    """
    generators = np.asarray(generators)
    if generators.ndim != 3:
        raise ValueError(f"[d_exp_minus_phi] Expected shape (d, K, K), got {generators.shape}")
    
    d, K, _ = generators.shape
    shape = phi_vec.shape[:-1]
    phi_flat = phi_vec.reshape(-1, d)
    N = phi_flat.shape[0]

    # Compute −φ
    neg_phi_flat = -phi_flat
    phi_mat = np.einsum("nd,dij->nij", neg_phi_flat, generators)
    norms = np.linalg.norm(neg_phi_flat, axis=1)
    use_fast = norms < threshold

    # Precompute e^{-φ}
    exp_phi_all = exp_lie_algebra_irrep(neg_phi_flat, generators, group_name=group_name)  # (N, K, K)

    d_exp_list = []

    for a in range(d):
        G_a = generators[a]
        grad = np.zeros((N, K, K))

        if np.any(use_fast):
            phi_batch = phi_mat[use_fast]
            exp_phi_batch = exp_phi_all[use_fast]
            G_a_broadcast = np.broadcast_to(G_a, phi_batch.shape)

            # Commutator approximation: d/dφ e^{−φ} = e^{−φ} · series
            comm1 = phi_batch @ G_a_broadcast - G_a_broadcast @ phi_batch
            comm2 = phi_batch @ comm1 - comm1 @ phi_batch
            comm3 = phi_batch @ comm2 - comm2 @ phi_batch

            approx = (
                G_a_broadcast
                - 0.5 * comm1
                + (1.0 / 6.0) * comm2
                - (1.0 / 24.0) * comm3
            )

            grad[use_fast] = np.einsum("nij,njk->nik", exp_phi_batch, approx)

        if np.any(~use_fast):
            s_vals = np.linspace(0, 1, num_points)
            w_vals = np.ones(num_points)
            w_vals[0] = w_vals[-1] = 0.5
            w_vals /= (num_points - 1)

            phi_heavy = phi_mat[~use_fast]
            grad_heavy = np.zeros((phi_heavy.shape[0], K, K))

            for s, w in zip(s_vals, w_vals):
                exp_s_phi   = np.stack([adaptive_expm(s * M) for M in phi_heavy])
                exp_1ms_phi = np.stack([adaptive_expm((1 - s) * M) for M in phi_heavy])
                grad_heavy += w * np.einsum("nij,jk,nkl->nil", exp_s_phi, G_a, exp_1ms_phi)

            grad[~use_fast] = grad_heavy

        reshaped = grad.reshape(*shape, K, K)
        d_exp_list.append(reshaped)

    # Stack: (..., d, K, K)
    return np.stack(d_exp_list, axis=-3)





def d_exp_right(phi_vec, generators, group_name="so3", threshold=0.3):
    """
    Compute ∂/∂φᵢ^a e^{φᵢ} using BCH or exact quadrature.
    """
    return d_exp_phi_exact(phi_vec, generators, group_name=group_name, threshold=threshold)


def d_exp_phi_tilde_exact(phi_tilde_vec, generators, num_points=20, group_name="so3", threshold=0.3):
    """
    Hybrid: fast approximation if ‖φ̃‖ < threshold, else use numerical quadrature.

    Args:
        phi_tilde_vec : (..., d)
        generators    : (d, K, K)
        num_points    : quadrature resolution
        group_name    : e.g. "so3"
        threshold     : norm cutoff to switch method

    Returns:
        d_exp_list    : list of (..., K, K) arrays for each ∂/∂φ̃^a
    """
    

    d, K, _ = generators.shape
    shape = phi_tilde_vec.shape[:-1]
    flat_phi = phi_tilde_vec.reshape(-1, d)  # (N, d)
    N = flat_phi.shape[0]

    phi_mat = np.einsum("nd,dij->nij", flat_phi, generators)  # (N, K, K)
    norms = np.linalg.norm(flat_phi, axis=1)
    use_fast = norms < threshold

    exp_phi_all = exp_lie_algebra_irrep(flat_phi, generators, group_name=group_name)  # (N, K, K)

    d_exp_list = []
    for a in range(d):
        G_a = generators[a]
        grad = np.zeros((N, K, K), dtype=phi_mat.dtype)

        # ───── FAST MODE ─────
        if np.any(use_fast):
            phi_batch = phi_mat[use_fast]         # (..., K, K)
            exp_phi_batch = exp_phi_all[use_fast] # (..., K, K)

            # [φ̃, G_a]
            comm1 = np.einsum("...ij,jk->...ik", phi_batch, G_a) - np.einsum("ij,...jk->...ik", G_a, phi_batch)

            # [φ̃, [φ̃, G_a]]
            comm2 = (
               np.einsum("...ij,...jk->...ik", phi_batch, comm1)
               - np.einsum("...ij,...jk->...ik", comm1, phi_batch)
               )
            
            approx = G_a - 0.5 * comm1 + (1.0 / 6.0) * comm2
            grad[use_fast] = np.einsum("nij,njk->nik", exp_phi_batch, approx)

        # ───── QUADRATURE MODE ─────
        if np.any(~use_fast):
            phi_heavy = phi_mat[~use_fast]
            grad_heavy = np.zeros_like(phi_heavy)

            s_vals = np.linspace(0, 1, num_points)
            w_vals = np.ones(num_points)
            w_vals[0] = w_vals[-1] = 0.5
            w_vals /= (num_points - 1)

            for s, w in zip(s_vals, w_vals):
                exp_s_phi   = np.stack([adaptive_expm(s * M)     for M in phi_heavy])
                exp_1ms_phi = np.stack([adaptive_expm((1 - s) * M) for M in phi_heavy])

                # grad += w · exp(sφ̃) · G_a · exp((1-s)φ̃)
                grad_heavy += w * np.einsum("...ij,jk,...kl->...il", exp_s_phi, G_a, exp_1ms_phi)

            grad[~use_fast] = grad_heavy

        # Reshape back to original spatial grid
        d_exp_list.append(grad.reshape(*shape, K, K))

    return d_exp_list




def batch_apply_omega(mu_batch, sigma_batch, omega_batch, n_jobs=None):
    """
    Applies Ω to MVGs using gauge-covariant pushforward:
        μ' = Ω μ
        Σ' = Ω Σ Ωᵀ

    Args:
        mu_batch    : (..., K) mean field
        sigma_batch : (..., K, K) covariance field
        omega_batch : (..., K, K) gauge transport matrix field
        n_jobs      : unused (reserved for future parallelization)

    Returns:
        mu_out      : (..., K)
        sigma_out   : (..., K, K)
    """
    mu_batch    = np.asarray(mu_batch)
    sigma_batch = np.asarray(sigma_batch)
    omega_batch = np.asarray(omega_batch)

    # ───── Basic Shape Checks ─────
    if mu_batch.shape[:-1] != omega_batch.shape[:-2]:
        raise ValueError(f"[Ω] Batch shape mismatch: mu {mu_batch.shape}, omega {omega_batch.shape}")
    if mu_batch.shape[-1] != omega_batch.shape[-1]:
        raise ValueError(f"[Ω] Fiber dim mismatch: mu {mu_batch.shape[-1]}, omega {omega_batch.shape[-1]}")
    if sigma_batch.shape[-2:] != (mu_batch.shape[-1], mu_batch.shape[-1]):
        raise ValueError(f"[Ω] Sigma shape mismatch: got {sigma_batch.shape[-2:]} vs mu dim {mu_batch.shape[-1]}")

    # ───── Sanitize input covariances ─────
    sigma_batch = sanitize_sigma(sigma_batch, eps=config.eps)

    # ───── Pushforward mean and covariance ─────
    mu_out = np.einsum("...ij,...j->...i", omega_batch, mu_batch)
    sigma_out = omega_batch @ sigma_batch @ np.swapaxes(omega_batch, -1, -2)

    return mu_out, sigma_out



def d_exp_phi_exactWORKSolder(phi_vec, generators, num_points=20, group_name="so3"):
    """
    Compute ∂/∂φ^a e^{φ} exactly using numerical quadrature:
        ∂_a e^{φ} = ∫₀¹ e^{sφ} G_a e^{(1−s)φ} ds

    Args:
        phi_vec   : (..., d), Lie algebra coefficients φ^a
        generators: (d, K, K), generator matrices G_a
        num_points: number of quadrature points (default 10)
        group_name: Lie group ("so3", etc.) used for structure enforcement

    Returns:
        d_exp_list: list of (..., K, K) arrays, one for each ∂ e^φ / ∂ φ^a
    """
    d, K, _ = generators.shape
    shape = phi_vec.shape[:-1]

    # ───── Construct φ matrix field φ = ∑ φ^a G_a ─────
    phi_mat = np.zeros(shape + (K, K), dtype=float)
    for a in range(d):
        phi_mat += phi_vec[..., a][..., None, None] * generators[a]

    # ───── Trapezoidal quadrature rule ─────
    s_vals = np.linspace(0, 1, num_points)
    w_vals = np.ones(num_points)
    w_vals[0] = w_vals[-1] = 0.5
    w_vals /= (num_points - 1)

    # ───── Compute ∂ e^φ / ∂ φ^a using ∫ e^{sφ} G_a e^{(1−s)φ} ds ─────
    d_exp_list = []
    for a in range(d):
        G_a = generators[a]
        grad = np.zeros_like(phi_mat)

        for s, w in zip(s_vals, w_vals):
            for idx, _ in np.ndenumerate(phi_vec[..., 0]):
                phi_s   = s * phi_mat[idx]
                phi_1ms = (1 - s) * phi_mat[idx]

                exp_s_phi   = adaptive_expm(phi_s, group_name=group_name)
                exp_1ms_phi = adaptive_expm(phi_1ms, group_name=group_name)

                grad[idx] += w * (exp_s_phi @ G_a @ exp_1ms_phi)

        d_exp_list.append(grad)

    return d_exp_list



def d_exp_phi_exactVECTORIZED(phi_vec, generators, num_points=20, group_name="so3"):
    """
    Compute ∂/∂φ^a e^{φ} using exact quadrature with minimal overhead.

    Args:
        phi_vec   : (..., d)
        generators: (d, K, K)
        num_points: number of quadrature points
        group_name: e.g., "so3"

    Returns:
        d_exp_list: list of (..., K, K) arrays
    """
    d, K, _ = generators.shape
    shape = phi_vec.shape[:-1]

    # Construct φ matrix field
    phi_mat = np.zeros(shape + (K, K), dtype=float)
    for a in range(d):
        phi_mat += phi_vec[..., a][..., None, None] * generators[a]

    s_vals = np.linspace(0, 1, num_points)
    w_vals = np.ones(num_points)
    w_vals[0] = w_vals[-1] = 0.5
    w_vals /= (num_points - 1)

    d_exp_list = []
    it = np.ndindex(shape)

    for a in range(d):
        G_a = generators[a]
        grad = np.zeros_like(phi_mat)

        for s, w in zip(s_vals, w_vals):
            for idx in it:
                phi_s   = s * phi_mat[idx]
                phi_1ms = (1 - s) * phi_mat[idx]

                # Inline expm here to eliminate overhead
                exp_s   = adaptive_expm(phi_s)
                exp_1ms = adaptive_expm(phi_1ms)

                grad[idx] += w * (exp_s @ G_a @ exp_1ms)

        d_exp_list.append(grad)

    return d_exp_list

#==========================================================
#
#                Curvature Ops
#
#==========================================================
def compute_gauge_potential(phi, dx=1.0):
    """
    Compute gauge potential A_μ^a = ∂_μ φ^a using central differences
    with periodic boundary conditions.

    Args:
        phi : np.ndarray, shape (..., d)
            Lie algebra field over a D-dimensional spatial grid.
        dx  : float
            Grid spacing of the base manifold.

    Returns:
        A : tuple of D arrays, each of shape (..., d),
            containing ∂_μ φ^a for μ=0..D−1.
    """
    if phi.ndim < 2:
        raise ValueError("phi must have at least one spatial and one Lie algebra dimension.")

    D = phi.ndim - 1
    return tuple(
        (np.roll(phi, -1, axis=μ) - np.roll(phi, 1, axis=μ)) / (2.0 * dx)
        for μ in range(D)
    )


def compute_field_strength(phi: np.ndarray, generators: np.ndarray, dx: float = 1.0):
    """
    Compute field strength F_{xy} = ∂_x Φ_y − ∂_y Φ_x + [Φ_x, Φ_y],
    treating Φ = φ^a G_a as a Lie-algebra–valued gauge potential.

    Args:
        phi        : (H, W, d) Lie algebra coefficients φ^a(x)
        generators : (d, K, K) Lie algebra basis (e.g. SO(3) or SL(2,R))
        dx         : float, lattice spacing

    Returns:
        dict {"xy": F_xy} where F_xy is (H, W, K, K) curvature tensor
    """
    H, W, d = phi.shape
    K = generators.shape[1]

    phi = np.asarray(phi)
    generators = np.asarray(generators)

    # Φ(x) = φ^a(x) G_a
    phi_matrix = np.einsum("ijk,klm->ijlm", phi, generators)  # (H, W, K, K)

    # A_μ = ∂_μ Φ
    A_x = (np.roll(phi_matrix, -1, axis=0) - np.roll(phi_matrix, 1, axis=0)) / (2 * dx)
    A_y = (np.roll(phi_matrix, -1, axis=1) - np.roll(phi_matrix, 1, axis=1)) / (2 * dx)

    # ∂_μ A_ν
    dAy_dx = (np.roll(A_y, -1, axis=0) - np.roll(A_y, 1, axis=0)) / (2 * dx)
    dAx_dy = (np.roll(A_x, -1, axis=1) - np.roll(A_x, 1, axis=1)) / (2 * dx)

    # [A_x, A_y]
    comm = np.einsum("ijkl,ijln->ijkn", A_x, A_y) - np.einsum("ijkl,ijln->ijkn", A_y, A_x)

    # F_{xy} = ∂_x A_y - ∂_y A_x + [A_x, A_y]
    F_xy = dAy_dx - dAx_dy + comm

    return {"xy": F_xy}

def compute_field_strength_general(phi: np.ndarray, generators: np.ndarray, dx: float = 1.0):
    """
    Compute all nonabelian curvature components F_{μν} = ∂_μ A_ν - ∂_ν A_μ + [A_μ, A_ν].

    Args:
        phi        : (..., d) Lie algebra coordinates
        generators : (d, K, K) Lie algebra basis
        dx         : lattice spacing

    Returns:
        Dictionary {(μ, ν): F_mn} for all μ < ν
    """
    phi_matrix = np.einsum("...a,akl->...kl", phi, generators)
    D = phi.ndim - 1  # spatial dimension
    F = {}

    # Compute A_μ = ∂_μ φ
    A = [
        (np.roll(phi_matrix, -1, axis=mu) - np.roll(phi_matrix, 1, axis=mu)) / (2 * dx)
        for mu in range(D)
    ]

    for mu in range(D):
        for nu in range(mu+1, D):
            dA_nu_mu = (np.roll(A[nu], -1, axis=mu) - np.roll(A[nu], 1, axis=mu)) / (2 * dx)
            dA_mu_nu = (np.roll(A[mu], -1, axis=nu) - np.roll(A[mu], 1, axis=nu)) / (2 * dx)
            comm = np.einsum("...ij,...jk->...ik", A[mu], A[nu]) - np.einsum("...ij,...jk->...ik", A[nu], A[mu])
            F[(mu, nu)] = dA_nu_mu - dA_mu_nu + comm

    return F

import numpy as np
from scipy.ndimage import gaussian_filter


def compute_curvature_gradient_analytical(
    phi: np.ndarray,
    generators: np.ndarray,
    dx: float = 1.0,
    smoothing_sigma: float = 1.0,
) -> np.ndarray:
    """
    Compute the variational gradient ∇_φ Tr[F_{xy}²] for nonabelian curvature F_{xy}.

    Args:
        phi             : (H, W, d) Lie algebra coordinates φ^a(x)
        generators      : (d, K, K) Lie algebra basis G^a (trace-orthonormal: Tr[G^a G^b] = δ^{ab})
        dx              : lattice spacing
        smoothing_sigma : Gaussian smoothing sigma to regularize instability

    Returns:
        grad            : (H, W, d) curvature gradient in Lie algebra basis
    """
    H, W, d = phi.shape
    K = generators.shape[-1]

    # ─── Smooth φ to stabilize finite diffs ───
    phi_smooth = np.stack([
        gaussian_filter(phi[..., a], sigma=smoothing_sigma, mode='wrap')
        for a in range(d)
    ], axis=-1)

    # ─── A_x = ∂_x φ, A_y = ∂_y φ ───
    A_x = (np.roll(phi_smooth, -1, axis=0) - np.roll(phi_smooth, 1, axis=0)) / (2 * dx)
    A_y = (np.roll(phi_smooth, -1, axis=1) - np.roll(phi_smooth, 1, axis=1)) / (2 * dx)

    # ─── Project to matrix-valued potentials: A_μ = A^a G^a ───
    A_x_mat = np.einsum("ijk,klm->ijlm", A_x, generators)  # (H, W, K, K)
    A_y_mat = np.einsum("ijk,klm->ijlm", A_y, generators)

    # ─── Compute curvature F_{xy} = ∂_x A_y - ∂_y A_x + [A_x, A_y] ───
    dAy_dx = (np.roll(A_y_mat, -1, axis=0) - np.roll(A_y_mat, 1, axis=0)) / (2 * dx)
    dAx_dy = (np.roll(A_x_mat, -1, axis=1) - np.roll(A_x_mat, 1, axis=1)) / (2 * dx)
    comm_xy = A_x_mat @ A_y_mat - A_y_mat @ A_x_mat

    F_xy = dAy_dx - dAx_dy + comm_xy  # (H, W, K, K)

    # ─── Smooth F_xy before differentiating ───
    F_xy_smooth = np.stack([
        gaussian_filter(F_xy[..., i, j], sigma=smoothing_sigma, mode='wrap')
        for i in range(K) for j in range(K)
    ], axis=0).reshape(H, W, K, K)

    # ─── Compute D_μ F^{μν} ≡ ∇ divergence term ───
    dF_dx = (np.roll(F_xy_smooth, -1, axis=0) - np.roll(F_xy_smooth, 1, axis=0)) / (2 * dx)
    dF_dy = (np.roll(F_xy_smooth, -1, axis=1) - np.roll(F_xy_smooth, 1, axis=1)) / (2 * dx)
    comm1 = A_x_mat @ F_xy_smooth - F_xy_smooth @ A_x_mat
    comm2 = A_y_mat @ F_xy_smooth - F_xy_smooth @ A_y_mat

    divF_covariant = dF_dx + dF_dy + comm1 + comm2  # (H, W, K, K)

    # ─── Project to Lie algebra basis via trace inner product ───
    grad = np.zeros((H, W, d), dtype=phi.dtype)
    for a in range(d):
        G = generators[a]
        grad[..., a] = 2.0 * np.einsum("...ij,ij->...", divF_covariant, G)

    # (Optional) gradient clipping
    # grad = safe_clip_norm(grad, max_norm=10.0)

    return grad


#currently unused
def compute_curvature_form(phi_x, phi_y, generators, dx=1.0, smoothing_sigma=1.0):
    """
    Computes F = dφ + 1/2 [φ ∧ φ] in discrete 2D form.

    Args:
        phi_x, phi_y: (H, W, d) components of Lie-algebra-valued 1-form φ = φ_x dx + φ_y dy
        generators:   (d, K, K) Lie algebra basis (trace-orthonormal)
        dx:           Lattice spacing
        smoothing_sigma: Optional Gaussian smoothing for stability

    Returns:
        F_xy_mat: (H, W, K, K) — curvature 2-form as Lie-algebra-valued matrix field
    """
    H, W, d = phi_x.shape
    K = generators.shape[1]

    # Optional smoothing
    phi_x_smooth = np.stack([gaussian_filter(phi_x[..., a], smoothing_sigma, mode="wrap") for a in range(d)], axis=-1)
    phi_y_smooth = np.stack([gaussian_filter(phi_y[..., a], smoothing_sigma, mode="wrap") for a in range(d)], axis=-1)

    # Compute dφ: antisymmetrized derivatives
    dphi_x = (np.roll(phi_y_smooth, -1, axis=0) - np.roll(phi_y_smooth, 1, axis=0)) / (2 * dx)
    dphi_y = (np.roll(phi_x_smooth, -1, axis=1) - np.roll(phi_x_smooth, 1, axis=1)) / (2 * dx)

    dphi_term = dphi_x - dphi_y  # Approximates ∂_x φ_y - ∂_y φ_x

    # Reconstruct φ_x, φ_y as matrices: (H, W, K, K)
    Ax = np.einsum("ijk,klm->ijlm", phi_x_smooth, generators)
    Ay = np.einsum("ijk,klm->ijlm", phi_y_smooth, generators)

    # Compute [A_x, A_y]
    commutator_term = np.einsum("...ij,...jk->...ik", Ax, Ay) - np.einsum("...ij,...jk->...ik", Ay, Ax)

    # Total curvature 2-form
    F_xy_mat = np.einsum("ijk,klm->ijlm", dphi_term, generators) + 0.5 * commutator_term

    return F_xy_mat  # shape (H, W, K, K)





#==================================================================
#
#                Holonomy And Transport Utils
#
#==================================================================


def compute_intra_omega(agent, coord_from, coord_to, generators=None):
    """
    Compute intra-agent transport Ω(p₁ ← p₀) = exp(φ(p₁)) · exp(−φ(p₀))
    """
    if generators is None:
        generators = agent.generators

    φ_from = agent.phi[coord_from]
    φ_to   = agent.phi[coord_to]

    Ω_from = exp_lie_algebra_irrep(φ_from[None], generators)[0]
    Ω_to   = exp_lie_algebra_irrep(φ_to[None], generators)[0]
    
    return Ω_to @ safe_omega_inv(Ω_from)



def compute_inter_omega(agent_i, agent_j, overlap_pt, generators=None):
    """
    Compute inter-agent gauge transform Ω_ij = exp(φ_i) · exp(−φ_j)
    """
    if generators is None:
        generators = agent_i.generators  # assume same group

    φ_i = agent_i.phi[overlap_pt]
    φ_j = agent_j.phi[overlap_pt]

    Ω_i = exp_lie_algebra_irrep(φ_i[None], generators)[0]
    Ω_j = exp_lie_algebra_irrep(φ_j[None], generators)[0]
    return Ω_i @ safe_omega_inv(Ω_j)


#from generalized_math_utils import safe_batch_inverse

def compute_inter_omega_fieldwise(phi_i, phi_j, generators, invert_j=False):
    """
    Compute Ω_ij = exp(φ_i) · exp(−φ_j) or exp(φ_i) · inv(exp(φ_j)).

    Args:
        phi_i      : (..., d)
        phi_j      : same shape
        generators : (d, K, K)
        invert_j   : bool, if True uses inversion instead of exp(−φ)

    Returns:
        Omega_ij   : (..., K, K)
    """
    phi_i = np.asarray(phi_i)
    phi_j = np.asarray(phi_j)
    if phi_i.shape != phi_j.shape:
        raise ValueError(f"Shape mismatch: {phi_i.shape} vs {phi_j.shape}")

    is_grid = (phi_i.ndim == 3)
    d = phi_i.shape[-1]

    phi_i_flat = phi_i.reshape(-1, d)
    phi_j_flat = phi_j.reshape(-1, d)

    exp_i = exp_lie_algebra_irrep(phi_i_flat, generators)  # (N, K, K)

    if invert_j:
        exp_j = safe_batch_inverse(exp_lie_algebra_irrep(phi_j_flat, generators))  # robust
    else:
        exp_j = exp_lie_algebra_irrep(-phi_j_flat, generators)

    Omega_flat = np.einsum("nij,njk->nik", exp_i, exp_j)  # (N, K, K)

    if is_grid:
        H, W = phi_i.shape[:2]
        return Omega_flat.reshape(H, W, *Omega_flat.shape[-2:])
    return Omega_flat
                                                               # (N, K, K)



#==================================================================
#
#                LEGACY/DEPRECATED
#
#==================================================================



def d_exp_phi_tilde_exactslow(phi_tilde_vec, generators, num_points=10, group_name="so3"):
    """
    Compute ∂ e^{φ̃} / ∂ φ̃^a exactly via numerical quadrature, ensuring SO(3) structure.

    Args:
        phi_tilde_vec : (..., d), Lie algebra coords for φ̃
        generators    : (d, K, K)
        num_points    : quadrature resolution (e.g., 10)
        group_name    : e.g. "so3" to preserve group structure

    Returns:
        d_exp_list : list of (..., K, K), ∂ e^{φ̃} / ∂ φ̃^a
    """
    d, K, _ = generators.shape
    shape = phi_tilde_vec.shape[:-1]

    # Construct φ̃ matrix field
    phi_mat = np.zeros(shape + (K, K), dtype=phi_tilde_vec.dtype)
    for a in range(d):
        phi_mat += phi_tilde_vec[..., a][..., None, None] * generators[a]

    # Trapezoidal quadrature weights
    s_vals = np.linspace(0, 1, num_points)
    w_vals = np.ones(num_points)
    w_vals[0] = w_vals[-1] = 0.5
    w_vals /= (num_points - 1)

    d_exp_list = []
    for a in range(d):
        G_a = generators[a]
        grad = np.zeros_like(phi_mat)
        for s, w in zip(s_vals, w_vals):
            for idx, _ in np.ndenumerate(phi_tilde_vec[..., 0]):
                phi_s   = s * phi_mat[idx]
                phi_1ms = (1 - s) * phi_mat[idx]

                exp_s_phi   = adaptive_expm(phi_s, group_name=group_name)
                exp_1ms_phi = adaptive_expm(phi_1ms, group_name=group_name)

                grad[idx] += w * (exp_s_phi @ G_a @ exp_1ms_phi)

        d_exp_list.append(grad)

    return d_exp_list


def exp_lie_algebra_irrepWORKS(
    v_batch,
    generators,
    use_expm=True,
    threshold=1e-3,
    max_norm=None,
    group_name=None,
    n_jobs=-1,
    verbose=False
):
    """
    Compute batch of exp(sum_a v[a] * T_a) using Taylor or expm depending on norm.
    Enforces SO(3) via orthogonal projection after exponentiation.

    Parameters:
        v_batch: (..., dim_G) Lie algebra coefficients
        generators: (dim_G, K, K) Lie algebra generators
        use_expm: fallback to expm if large-norm
        threshold: Taylor cutoff
        max_norm: optional clip threshold (fallback to config.phi_exp_clip)
        group_name: used for antisymmetrization ("so3", "su2", etc)
        n_jobs: parallel expm if large batch
        verbose: whether to print clipping info

    Returns:
        (..., K, K) exponentiated matrices (projected to SO(3))
    """
   
    def project_to_so3(M):
        U, _, Vt = np.linalg.svd(M)
        R = U @ Vt
        if np.linalg.det(R) < 0:
            U[:, -1] *= -1
            R = U @ Vt
        return R

    *batch_shape, dim_G = v_batch.shape
    v_flat = v_batch.reshape(-1, dim_G)
    N = v_flat.shape[0]
    _, K, _ = generators.shape
    dtype = v_batch.dtype

    # ─── Clip large φ vectors ─────────────────────────────────────────────
    clip_norm = (
        max_norm
        if max_norm is not None
        else getattr(config, "phi_exp_clip", 10.0)
    )
    norm_type = getattr(config, "gradient_clip_norm_type", 2)
    eps = 1e-16

    norms = np.linalg.norm(v_flat, axis=1, ord=norm_type)
    scale_factors = np.minimum(1.0, clip_norm / (norms + eps))
    v_scaled = v_flat * scale_factors[:, None]

    if verbose and np.any(scale_factors < 1.0):
        print(f"[Ω] Clipped {np.sum(scale_factors < 1)} / {N} φ vectors to ‖φ‖ ≤ {clip_norm}")

    # ─── Build algebra elements ───────────────────────────────────────────
    G_batch = np.einsum("na,aij->nij", v_scaled, generators)

    if group_name == "so3":
        G_batch = 0.5 * (G_batch - np.transpose(G_batch, axes=(0, 2, 1)))
    elif group_name == "su2":
        G_batch = 0.5 * (G_batch - np.transpose(G_batch, axes=(0, 2, 1)).conj())

    result = np.empty((N, K, K), dtype=dtype)
    approx_mask = norms * scale_factors < threshold

    # ─── Use Taylor expansion for small matrices ──────────────────────────
    if np.any(approx_mask):
        G_approx = G_batch[approx_mask]
        I = np.eye(K, dtype=dtype)[None, :, :]
        G2 = G_approx @ G_approx
        G3 = G2 @ G_approx
        G4 = G2 @ G2
        result[approx_mask] = (
            I + G_approx + 0.5 * G2 + (1.0 / 6.0) * G3 + (1.0 / 24.0) * G4
        )

    # ─── Fallback expm for heavy matrices ─────────────────────────────────
    if np.any(~approx_mask):
        idxs = np.flatnonzero(~approx_mask)
        G_heavy = [G_batch[i] for i in idxs]
        
        with parallel_backend("threading"):
            expm_results = Parallel(n_jobs=n_jobs)(
                delayed(adaptive_expm)(
                    G, clip_norm=None, max_norm=clip_norm, threshold=threshold
                ) for G in G_heavy
            )
        for i, res in zip(idxs, expm_results):
            result[i] = res

    # ─── Project everything to SO(3) ───────────────────────────────────────
    for i in range(N):
        result[i] = project_to_so3(result[i])

    return result.reshape(*batch_shape, K, K)


def adaptive_expmWORKS(G, clip_norm=None, max_norm=None, threshold=1e-3, group_name=None):
    """
    Rescales G to prevent instability, then exponentiates:
      - 4th-order Taylor for small ‖G‖
      - expm(G) otherwise
    Then projects the result to SO(3) if group_name == "so3".

    Parameters:
        G: (K, K) Lie algebra matrix
        clip_norm: soft cap (rescales only if ‖G‖ > clip_norm)
        max_norm: hard cap (always rescales if ‖G‖ > max_norm)
        threshold: use Taylor below this norm
        group_name: optional group structure (e.g. "so3", "su2")

    Returns:
        exp(G): (K, K) matrix, optionally projected to SO(3)
    """
    import numpy as np
    from scipy.linalg import expm

    def project_to_so3(M):
        U, _, Vt = np.linalg.svd(M)
        R = U @ Vt
        if np.linalg.det(R) < 0:
            U[:, -1] *= -1
            R = U @ Vt
        return R

    norm_G = np.linalg.norm(G) + 1e-16

    if clip_norm and norm_G > clip_norm:
        G *= clip_norm / norm_G
    if max_norm and norm_G > max_norm:
        G *= max_norm / norm_G

    # Optional antisymmetrization
    if group_name == "so3":
        G = 0.5 * (G - G.T)
    elif group_name == "su2":
        G = 0.5 * (G - G.T.conj())

    # Exponentiate
    if norm_G < threshold:
        I = np.eye(G.shape[0], dtype=G.dtype)
        G2 = G @ G
        G3 = G2 @ G
        G4 = G2 @ G2
        M = I + G + 0.5 * G2 + (1/6) * G3 + (1/24) * G4
    else:
        M = expm(G)

    # Project to SO(3) if needed
    if group_name == "so3":
        M = project_to_so3(M)

    return M