# -*- coding: utf-8 -*-
"""
Created on Wed Jul 23 06:38:17 2025

@author: chris and christine
"""
import numpy as np
import config
import numpy as np
from scipy.linalg import inv
from numerical_utils import safe_inv, sanitize_sigma
from omega import exp_lie_algebra_irrep, compute_curvature_gradient_analytical
from natural_gradient import dexpinv_operator, dexpinv_operator_covariance, compute_fisher_geometry_gradient, compute_inverse_fisher_field_natural

from natural_params_utils import compute_bar_eta2_qj,compute_delta_eta
from omega import d_exp_phi_exact, exp_lie_algebra_irrep
from numerical_utils import safe_inv, soft_clip_phi_norm
from natural_params_utils import compute_bar_eta2_qj, compute_delta_eta

#==============================================================================
#
#                    GATHER PHI GAUGE FIELD GRADIENT TERMS
#                          Beliefs and Models
#==============================================================================

from omega import d_exp_phi_exact, d_exp_phi_tilde_exact, d_exp_minus_phi
from numerical_utils import safe_inv


def accumulate_phi_gradient_belief(agent_i, agent_j, generators, params, debug=False):
    """
    Compute and apply natural gradient:
        ∇_{φ_i} KL(q_i || Ω_ij q_j)
        ∇_{φ_j} KL(q_i || Ω_ij q_j)
    using exact ∂Ω/∂φ gradients, natural projection, and dexpinv correction.
    Uses (μ, Σ) parameterization.
    """
    beta = params.get("beta", config.beta)
    if beta <= 0:
        return

    eps = config.support_cutoff_eps
    joint_mask = (agent_i.mask > eps) & (agent_j.mask > eps)
    joint_mask = joint_mask.astype(float)[..., None]

    mu_qi, sigma_qi = agent_i.mu_q_field, agent_i.sigma_q_field
    mu_qj, sigma_qj = agent_j.mu_q_field, agent_j.sigma_q_field

    exp_phi_i = agent_i._exp_phi
    exp_phi_j = agent_j._exp_phi
    exp_neg_phi_j = agent_j._exp_neg_phi
    Omega_ij = agent_i.Omega_cache[agent_j.id]

    Omega_expected = np.einsum("...ik,...kj->...ij", exp_phi_i, exp_neg_phi_j)
    

    F_inv_i = agent_i.inverse_fisher_phi
    F_inv_j = agent_j.inverse_fisher_phi

    # ∂KL/∂φ_i — no exp terms needed
    grad_phi_i_raw = grad_kl_wrt_phi_i(
        mu_qi, sigma_qi,
        mu_qj, sigma_qj,
        phi_i=agent_i.phi,
        phi_j=agent_j.phi,
        Omega_ij=Omega_ij,
        generators=generators,
        exp_phi_i=agent_i._exp_phi,
        exp_phi_j=agent_j._exp_phi,
        eps=config.eps,
        )


    # ∂KL/∂φ_j — uses exp(φ_j), exp(−φ_j)
    grad_phi_j_raw = grad_kl_wrt_phi_j(
        mu_qi, sigma_qi,
        mu_qj, sigma_qj,
        agent_j.phi, agent_i.phi,           # must pass phi_j, phi_i in correct order
        Omega_ij,
        generators,
        exp_phi_j,
        agent_i._exp_phi,
        eps=config.eps
        )


    # Project to natural gradient via Fisher inverse
    grad_phi_i_nat = np.einsum("...ab,...b->...a", F_inv_i, grad_phi_i_raw)
    grad_phi_j_nat = np.einsum("...ab,...b->...a", F_inv_j, grad_phi_j_raw)

    grad_phi_i = dexpinv_operator(agent_i.phi, grad_phi_i_nat, generators)
    grad_phi_j = dexpinv_operator(agent_j.phi, grad_phi_j_nat, generators)

    # Regularize φᵢ only
    reg_grad_i = apply_regularization_terms_lie_natural(
        agent=agent_i,
        phi_field=agent_i.phi,
        generators=generators,
        field="phi",
        params=params,
    )
    reg_grad_i *= joint_mask

    agent_i.grad_phi += (beta * grad_phi_i + reg_grad_i) * joint_mask
    agent_j.grad_phi += beta * grad_phi_j * joint_mask


def accumulate_phi_gradient_model(agent_i, agent_j, generators, params, debug=False):
    """
    Compute and apply natural gradient:
        ∇_{φ̃_i} KL(p_i || Ω̃_ij p_j)
        ∇_{φ̃_j} KL(p_i || Ω̃_ij p_j)
    using exact ∂Ω̃/∂φ̃ gradients, Fisher projection, and dexpinv correction.
    """
    beta_model = params.get("beta_model", config.beta_model)
    if beta_model <= 0:
        return

    eps = config.support_cutoff_eps
    joint_mask = (agent_i.mask > eps) & (agent_j.mask > eps)
    joint_mask = joint_mask.astype(float)[..., None]

    mu_pi, sigma_pi = agent_i.mu_p_field, agent_i.sigma_p_field
    mu_pj, sigma_pj = agent_j.mu_p_field, agent_j.sigma_p_field

    exp_phi_i = agent_i._exp_phi_model
    exp_phi_j = agent_j._exp_phi_model
    exp_neg_phi_j = agent_j._exp_neg_phi_model
    Omega_tilde_ij = agent_i.Omega_tilde_cache[agent_j.id]

    expected = np.einsum("...ik,...kj->...ij", exp_phi_i, exp_neg_phi_j)
    assert np.allclose(Omega_tilde_ij, expected, atol=1e-5), \
        f"[Ω̃ mismatch] agent_i={agent_i.id}, agent_j={agent_j.id}"

    F_inv_i = agent_i.inverse_fisher_phi_model
    F_inv_j = agent_j.inverse_fisher_phi_model

   # ∂KL(pᵢ || Ω̃ pⱼ) w.r.t. φ̃ᵢ
    grad_phi_tilde_i_raw = grad_kl_wrt_phi_i(
       mu_pi, sigma_pi,
       mu_pj, sigma_pj,
       phi_i=agent_i.phi_model,
       phi_j=agent_j.phi_model,
       Omega_ij=Omega_tilde_ij,
       generators=generators,
       exp_phi_i=agent_i._exp_phi_model,
       exp_phi_j=agent_j._exp_phi_model,
       eps=config.eps,
       )


    # ∂KL(pᵢ || Ω̃ pⱼ) w.r.t. φ̃ⱼ
    grad_phi_tilde_j_raw = grad_kl_wrt_phi_j(
        mu_pi, sigma_pi,
        mu_pj, sigma_pj,
        agent_j.phi_model, agent_i.phi_model,               # φ̃_j, φ̃_i
            Omega_tilde_ij,
            generators,
        agent_j._exp_phi_model, agent_i._exp_phi_model,     # exp(φ̃_j), exp(φ̃_i)
        eps=config.eps,
        )


    grad_phi_tilde_i_nat = np.einsum("...ab,...b->...a", F_inv_i, grad_phi_tilde_i_raw)
    grad_phi_tilde_j_nat = np.einsum("...ab,...b->...a", F_inv_j, grad_phi_tilde_j_raw)

    grad_phi_tilde_i = dexpinv_operator(agent_i.phi_model, grad_phi_tilde_i_nat, generators)
    grad_phi_tilde_j = dexpinv_operator(agent_j.phi_model, grad_phi_tilde_j_nat, generators)

    # Regularization on φ̃ᵢ
    reg_grad_i = apply_regularization_terms_lie_natural(
        agent=agent_i,
        phi_field=agent_i.phi_model,
        generators=generators,
        field="phi_model",
        params=params,
    )
    reg_grad_i *= joint_mask

    agent_i.grad_phi_tilde += (beta_model * grad_phi_tilde_i + reg_grad_i) * joint_mask
    agent_j.grad_phi_tilde += beta_model * grad_phi_tilde_j * joint_mask



#==============================================================================
#
#                    WITH RESPECT TO phi_i TERMS
#                       VALIDATED
#==============================================================================
def grad_kl_wrt_phi_i(
    mu_i, sigma_i,
    mu_j, sigma_j,
    phi_i, phi_j,
    Omega_ij,
    generators,
    exp_phi_i,
    exp_phi_j,
    eps=1e-8
):
    """
    Compute ∂KL(q_i || Ω_ij q_j) / ∂φ_i^a using full Lie-theoretic boxed expression.
    All exp(φ) terms and Ω_ij must be passed in — nothing is recomputed.

    Args:
        mu_i, mu_j      : (..., K)
        sigma_i, sigma_j: (..., K, K)
        phi_i, phi_j    : (..., d)
        Omega_ij        : (..., K, K), from cache = exp(φ_i) · exp(−φ_j)
        generators      : (d, K, K)
        exp_phi_i       : (..., K, K)
        exp_phi_j       : (..., K, K)
        eps             : small regularization constant

    Returns:
        grad_phi_i      : (..., d)
    """

    d, K, _ = generators.shape
    shape = mu_i.shape[:-1]

    # Compute exp(−φ_i), exp(−φ_j) via transpose (SO(3) only)
    exp_mphi_i = exp_phi_i.swapaxes(-1, -2)
    exp_mphi_j = exp_phi_j.swapaxes(-1, -2)

    # Transported σ_j
   
    Omega_ij_T = Omega_ij.swapaxes(-1, -2)
    sigma_ij = Omega_ij @ sigma_j @ Omega_ij_T
    sigma_ij = sanitize_sigma(sigma_ij, eps)
    sigma_ij_inv = safe_inv(sigma_ij, eps)

    # Precompute directional derivatives
    d_exp_i_right_all = d_exp_phi_exact(phi_i, generators)
    d_exp_i_left_all  = d_exp_phi_exact(phi_i, generators)   # same input, different contraction use


    # μ_j pushed forward
    mu_bar_j = np.einsum("...ij,...j->...i", Omega_ij, mu_j)
    delta_mu = mu_i - mu_bar_j

    grad = np.zeros((*shape, d), dtype=mu_i.dtype)

    for a in range(d):
        d_exp_i_right = d_exp_i_right_all[a]
        d_exp_i_left  = d_exp_i_left_all[a]
        

        term1 = term_trace_sandwich(
            sigma_i, sigma_ij_inv,
            exp_phi_i, d_exp_i_right,
            exp_mphi_i, d_exp_i_left
        )

        term2 = term_trace_reverse(
            Omega_ij,
            exp_phi_j,
            d_exp_i_left,
            d_exp_i_right
        )

        term3 = term_cross_mahalanobis(
            mu_i, mu_j,
            sigma_ij_inv,
            Omega_ij,
            exp_phi_j,
            d_exp_i_right,
            d_exp_i_left
            )

        term4 = term_quadratic_mahalanobis(
            mu_i, mu_j,
            Omega_ij,
            sigma_ij_inv,            
            exp_phi_i,
            d_exp_i_right,
            d_exp_i_left
        )

        grad[..., a] = term1 + term2 + term3 + term4

    return grad

def term_trace_sandwich(
    sigma_i, sigma_j,
    Omega_ij,
    exp_phi_i,             # (..., K, K)
    d_exp_phi_i_right,     # (..., K, K)
    d_exp_phi_i_left,      # (..., K, K)
    eps=1e-8
):
    """
    Compute:
        Tr[ e^{φ_i} D^R_a Σ⁻¹_{ij} Σ_i - D^L_a e^{-φ_i} Σ_i Σ⁻¹_{ij} ]
    where Σ_{ij} = Ω_ij Σ_j Ω_ijᵀ

    Args:
        sigma_i             : (..., K, K)
        sigma_j             : (..., K, K)
        Omega_ij            : (..., K, K)
        exp_phi_i           : (..., K, K)
        d_exp_phi_i_right   : (..., K, K)
        d_exp_phi_i_left    : (..., K, K)
        eps                 : float, regularization for inverse

    Returns:
        result              : (...,)
    """
   

    Omega_T = np.swapaxes(Omega_ij, -1, -2)
    sigma_ij = np.einsum("...ik,...kl,...jl->...ij", Omega_ij, sigma_j, Omega_T)
    sigma_ij = sanitize_sigma(sigma_ij, eps)
    sigma_ij_inv = safe_inv(sigma_ij, eps)
    exp_mphi_i = exp_phi_i.swapaxes(-1, -2)
    
    # First term: Tr[ e^{φ} D^R Σ⁻¹ Σ_i ]
    tmp1 = np.einsum("...ik,...kl->...il", sigma_ij_inv, sigma_i)
    dr_mat = np.einsum("...ik,...kl->...il", d_exp_phi_i_right, tmp1)
    term1_mat = np.einsum("...ik,...kl->...il", exp_phi_i, dr_mat)
    trace1 = np.einsum("...ii->...", term1_mat)

# Second term: Tr[ D^L e^{-φ} Σ_i Σ⁻¹ ]
    tmp2 = np.einsum("...ik,...kl->...il", sigma_i, sigma_ij_inv)
    dl_mat = np.einsum("...ik,...kl->...il", d_exp_phi_i_left, exp_mphi_i )
    term2_mat = np.einsum("...ik,...kl->...il", dl_mat,tmp2 )
    trace2 = np.einsum("...ii->...", term2_mat)


    return trace1 - trace2  # (...,)


def term_trace_reverse(
    Omega_ij,
    exp_phi_j,              # (..., K, K)
    d_exp_phi_j_right,      # (..., K, K) = ∂e^{φ_j} / ∂φ_j^a
    d_exp_phi_j_left        # (..., K, K) = ∂e^{φ_j} / ∂φ_j^a (your D^L)
):
    """
    Compute:
        ½ Tr[ Ω_ij (D^L_a e^{-φ_j} - e^{φ_j} D^R_a) ]
      = ½ Tr[ Ω_ij ( ∂e^{φ_j}/∂φ_j^a · e^{-φ_j} - e^{φ_j} · ∂e^{φ_j}/∂φ_j^a ) ]

    Args:
        Omega_ij           : (..., K, K)
        exp_phi_j          : (..., K, K) = e^{φ_j}
        d_exp_phi_j_right  : (..., K, K) = ∂e^{φ_j} / ∂φ_j^a
        d_exp_phi_j_left   : (..., K, K) = ∂e^{φ_j} / ∂φ_j^a

    Returns:
        trace value        : (...,)
    """
    exp_mphi_j = np.swapaxes(exp_phi_j, -1, -2)  # e^{-φ_j}

    # First term: Ω @ D^L @ e^{-φ_j}
    dl_term = np.einsum("...ik,...kl->...il", d_exp_phi_j_left, exp_mphi_j)
    term1 = np.einsum("...ik,...kl->...il", Omega_ij, dl_term)

    # Second term: Ω @ e^{φ_j} @ D^R
    dr_term = np.einsum("...ik,...kl->...il", exp_phi_j, d_exp_phi_j_right)
    term2 = np.einsum("...ik,...kl->...il", Omega_ij, dr_term)

    trace = np.einsum("...ii->...", term1 - term2)
    return 0.5 * trace

def term_cross_mahalanobis(
    mu_i, mu_j,
    sigma_ij_inv, 
    Omega_ij,           # (..., K, K)
    exp_phi_j,               # (..., K, K)
    d_exp_phi_i_right,       # (..., K, K) = ∂e^{φ}/∂φ
    d_exp_phi_i_left         # (..., K, K) = ∂e^{φ}/∂φ
):
    """
    Compute:
        ½ μᵢᵀ · D^R · Σ⁻¹ · Δμ
      - ½ Δμᵀ · Σ⁻¹ · D^L · e^{-φ} · μⱼ

    Returns:
        scalar field (...)
    """
    exp_mphi_j = np.swapaxes(exp_phi_j, -1, -2)  # e^{-φ_j}
    # Δμ = μ_i - Ω μ_j
    mu_bar_j = np.einsum("...ij,...j->...i", Omega_ij, mu_j)
    delta_mu = mu_i - mu_bar_j
    

    # First term: μᵢᵀ · e^{φ_j} ∂e^{φ_j}/∂φ · Σ⁻¹ · Δμ
    dr_term = np.einsum("...ik,...kl->...il", exp_phi_j, d_exp_phi_i_right)
    tmp1 = np.einsum("...ik,...kl->...il", dr_term, sigma_ij_inv)
    tmp1 = np.einsum("...i,...ij->...j", mu_i, tmp1)
    term1 = np.einsum("...i,...i->...", tmp1, delta_mu)

    # Second term: Δμᵀ · Σ⁻¹ · ∂e^{φ_j}/∂φ · e^{-φ_j} · μⱼ
    left_comp = np.einsum("...ik,...kl->...il", d_exp_phi_i_left, exp_mphi_j)
    tmp2 = np.einsum("...ij,...j->...i", left_comp, mu_j)
    tmp2 = np.einsum("...ij,...j->...i", sigma_ij_inv, tmp2)
    term2 = np.einsum("...i,...i->...", delta_mu, tmp2)

    return 0.5 * (term1 - term2)


def term_quadratic_mahalanobis(
    mu_i, mu_j,
    Omega_ij,                # (..., K, K)
    sigma_ij_inv,            # (..., K, K)
    exp_phi_i,               # (..., K, K)
    d_exp_phi_i_right,       # (..., K, K)
    d_exp_phi_i_left         # (..., K, K)
):
    """
    Compute:
        ½ (μ_i - Ω μ_j)^T [ e^{φ_i} ∂e^{φ_i}/∂φᵢ^a Σ⁻¹ - Σ⁻¹ ∂e^{φ_i}/∂φᵢ^a e^{-φ_i} ] (μ_i - Ω μ_j)
    """
    exp_mphi_i = np.swapaxes(exp_phi_i, -1, -2)

    # Δμ = μ_i - Ω μ_j
    mu_bar_j = np.einsum("...ij,...j->...i", Omega_ij, mu_j)
    delta_mu = mu_i - mu_bar_j

    # e^{φ_i} ∂e^{φ_i}/∂φ · Σ⁻¹
    right = exp_phi_i @ d_exp_phi_i_right @ sigma_ij_inv

    # Σ⁻¹ ∂e^{φ_i}/∂φ · e^{-φ_i}
    left = sigma_ij_inv @ d_exp_phi_i_left @ exp_mphi_i

    total = right - left

    return 0.5 * np.einsum("...i,...ij,...j->...", delta_mu, total, delta_mu)



#==============================================================================
#
#                    WITH RESPECT TO phi_j TERMS
#
#==============================================================================
def grad_kl_wrt_phi_j(
    mu_i, sigma_i,
    mu_j, sigma_j,
    phi_j, phi_i,
    Omega_ij,
    generators,              # (d, K, K)
    exp_phi_j, exp_phi_i,    # (..., K, K)
    eps=1e-8
):
    """
    Compute ∇_{φ_j^a} KL(q_i || Ω_{ij} q_j) using exact expression via ∂e^{-φ_j}/∂φ_j^a.

    Uses boxed expression with:
        G_a^R := ∂e^{-φ_j} / ∂φ_j^a
        ∂Ω_{ij}/∂φ_j^a = - e^{φ_i} G_a^R

    Returns:
        grad_phi_j : (..., d)
    """
    d, K, _ = generators.shape
    shape = mu_i.shape[:-1]

    Omega_T = np.swapaxes(Omega_ij, -1, -2)
    sigma_ij = Omega_ij @ sigma_j @ Omega_T
    sigma_ij = sanitize_sigma(sigma_ij, eps)
    sigma_ij_inv = safe_inv(sigma_ij, eps=eps)

    delta_mu = mu_i - np.einsum("...ij,...j->...i", Omega_ij, mu_j)

    exp_mphi_i = np.swapaxes(exp_phi_i, -1, -2)
    G_all_R = d_exp_minus_phi(phi_j, generators)  # (..., d, K, K)

    grad = np.zeros((*shape, d), dtype=mu_i.dtype)

    for a in range(d):
        G_a_R = G_all_R[..., a, :, :]  # (..., K, K)
        Omega_Ga = np.einsum("...ik,...kl->...il", exp_phi_i, G_a_R)
        Omega_Ga_T = np.einsum("...ik,...kl->...il", G_a_R, exp_mphi_i)

        # Term 1: -Tr[ Σ_i Σ_ij⁻¹ (e^φ_i G^R Σ_j Ωᵀ) Σ_ij⁻¹ ]
        A = Omega_Ga @ sigma_j @ Omega_T
        term1 = -np.einsum("...ij,...jk,...kl,...li->...", sigma_ij_inv, A, sigma_ij_inv, sigma_i)

        # Term 2: -Tr[ Σ_ij⁻¹ Ω Σ_j G^Rᵀ e^{-φ_i} Σ_ij⁻¹ Σ_i ]
        B = Omega_ij @ sigma_j @ Omega_Ga_T
        term2 = -np.einsum("...ij,...jk,...kl,...li->...", sigma_ij_inv, B, sigma_ij_inv, sigma_i)

        # Term 3: +Tr[ Σ_ij⁻¹ e^φ_i G^R Σ_j Ωᵀ ]
        term3 = +np.einsum("...ij,...ji->...", sigma_ij_inv, A)

        # Term 4: +Tr[ Σ_ij⁻¹ Ω Σ_j G^Rᵀ e^{-φ_i} ]
        term4 = +np.einsum("...ij,...ji->...", sigma_ij_inv, B)

        # Term 5: +½ Δμᵀ Σ_ij⁻¹ μ_j e^φ_i G^R
        mu_j_G = np.einsum("...j,...jk->...k", mu_j, G_a_R)
        mu_j_G_O = np.einsum("...j,...jk->...k", mu_j_G, exp_phi_i)
        tmp5 = np.einsum("...i,...ij->...j", delta_mu, sigma_ij_inv)
        term5 = +0.5 * np.einsum("...i,...i->...", tmp5, mu_j_G_O)

        # Term 6: +½ μ_jᵀ G^Rᵀ e^{-φ_i} Σ_ij⁻¹ Δμ
        G_R_T = np.swapaxes(G_a_R, -1, -2)
        # μ_jᵀ G^Rᵀ e^{-φ_i} Σ⁻¹
        tmp6 = np.einsum("...i,...ij->...j", mu_j, G_R_T)
        tmp6 = np.einsum("...i,...ij->...j", tmp6, exp_mphi_i)
        tmp6 = np.einsum("...i,...ij->...j", tmp6, sigma_ij_inv)
        term6 = 0.5 * np.einsum("...i,...i->...", tmp6, delta_mu)


        # Term 7: +½ Δμᵀ Σ⁻¹ ( A + B ) Σ⁻¹ Δμ
        M = A + B
        tmp7a = np.einsum("...i,...ij->...j", delta_mu, sigma_ij_inv)
        tmp7b = np.einsum("...i,...ij->...j", tmp7a, M)
        tmp7c = np.einsum("...i,...ij->...j", tmp7b, sigma_ij_inv)
        term7 = +0.5 * np.einsum("...i,...i->...", tmp7c, delta_mu)
       
        grad[..., a] = term1 + term2 + term3 + term4 + term5 + term6 + term7
        
    return grad





def apply_regularization_terms(
    phi, phi_tilde, generators,
    curv_weight, mass_weight, coupling_weight,
    morphism=None, fiber="phi",   # use "phi" or "phi_model"
    agent_i=None, agents=None,
    fisher_weight=0.0, params=None,
    eps=1e-8
):
    """
    Compute total φ or φ̃ regularization gradient in natural (Lie algebra) coordinates.
    Includes curvature, mass, φ–φ̃ coupling, and Fisher geometry terms.
    Uses provided `generators` and supports proper morphism conjugation.
    """
    if (
        curv_weight == 0 and
        mass_weight == 0 and
        coupling_weight == 0 and
        fisher_weight == 0
    ):
        
        return np.zeros_like(phi)

    grad_euclidean = np.zeros_like(phi)

    if curv_weight > 0:
        grad_curv = compute_curvature_gradient_analytical(phi, generators)
        grad_euclidean += curv_weight * grad_curv

    if mass_weight > 0:
        grad_mass = 2 * phi
        grad_euclidean += mass_weight * grad_mass

    if fisher_weight > 0 and agent_i is not None and agents is not None:
        grad_fisher = compute_fisher_geometry_gradient(agent_i, agents, params, field=fiber)
       # print(f"[REG] Fisher term:      ||∇|| = {np.linalg.norm(grad_fisher):.5e}")
        grad_euclidean += grad_fisher  # already weighted inside the function

    #print("[REG] Fisher Euclidean norm:", np.linalg.norm(grad_euclidean))
    grad_natural = dexpinv_operator(phi, grad_euclidean, generators)
    #print("[REG] Fisher Natural norm:", np.linalg.norm(grad_natural))

    return grad_natural


def apply_regularization_terms_lie_natural(
    agent,
    phi_field,
    generators,
    field,  # "phi" or "phi_model"
    params,
):
    """
    Compute φ or φ̃ regularization gradient in natural coordinates using agent-local fields.

    Args:
        agent      : the Agent object
        phi_field  : (..., K, K) — φ or φ̃ (current field)
        generators : dict of Lie generators for the current fiber
        field      : "phi" or "phi_model"
        params     : dict of simulation/config params

    Returns:
        grad_nat   : (..., d) — projected natural gradient
    """
       

    coupling_weight = params.get("phi_phi_tilde_coupling", config.phi_phi_tilde_coupling)
    eps             = params.get("eps", config.eps)

    if field == "phi":
        curv_weight     = params.get("curvature_weight", config.curvature_weight)
        fisher_weight   = params.get("phi_fisher_weight", config.fisher_geometry_weight)
        mass_weight = params.get("phi_mass_weight", config.belief_mass)
        phi         = phi_field
        phi_tilde   = agent.phi_model
        morphism    = agent.bundle_morphism_q_to_p
        fiber       = "belief"
    elif field == "phi_model":
        curv_weight     = params.get("curvature_weight", config.model_curvature_weight)
        fisher_weight   = params.get("phi_fisher_weight", config.fisher_model_geometry_weight)
        mass_weight = params.get("phi_model_mass_weight", config.model_mass)
        phi         = phi_field
        phi_tilde   = agent.phi
        morphism    = agent.bundle_morphism_p_to_q
        fiber       = "model"
    else:
        raise ValueError(f"Invalid field name: {field}")


    return apply_regularization_terms(
        phi=phi,
        phi_tilde=phi_tilde,
        generators=generators,
        curv_weight=curv_weight,
        mass_weight=mass_weight,
        coupling_weight=coupling_weight,
        morphism=morphism,
        fiber=fiber,
        agent_i=agent,
        agents=params.get("agents", None),
        fisher_weight=fisher_weight,
        params=params,
        eps=eps,
    )




def grad_kl_wrt_phi_i_OLD(mu_i, sigma_i, mu_j, sigma_j, Omega_ij, generators, eps=1e-8):
    """
    Compute ∂KL(q_i || Ω q_j) / ∂φ_i^a for all Lie algebra directions a.

    Args:
        mu_i       : (H, W, K)
        sigma_i    : (H, W, K, K)
        mu_j       : (H, W, K)
        sigma_j    : (H, W, K, K)
        Omega_ij   : (H, W, K, K)
        generators : (d, K, K)
        eps        : regularization for inverses

    Returns:
        grad_phi_i : (H, W, d)
    """
    d, K, _ = generators.shape
    H, W, _ = mu_i.shape

    grad_phi_i = np.zeros((H, W, d), dtype=mu_i.dtype)

    # Precompute log-det gradient for all directions
    t3_all = term_logdet_grad_phi_i(sigma_j, Omega_ij, generators, eps=eps)  # (H, W, d)

    for a in range(d):
        G_a = generators[a]

        t1 = term_trace_grad_phi_i(mu_i, sigma_i, mu_j, sigma_j, Omega_ij, G_a, eps)

        t2 = term_mahalanobis_grad_phi_i(mu_i, sigma_i, mu_j, sigma_j, Omega_ij, G_a, eps)  # (H, W)
        t3 = t3_all[..., a]  # Correctly extract a single slice (H, W)

        grad_phi_i[..., a] = t1 + t2 + t3  # (H, W)

    return grad_phi_i  # shape (H, W, d)

#validated
def term_trace_grad_phi_i(mu_i, sigma_i, mu_j, sigma_j, Omega_ij, G_a, eps=1e-8):
    """
    Compute the full trace gradient term for ∂/∂φ_i^a KL(q_i || Ω_ij q_j)
    Term: -Tr[ G_a Σ_i Σ_ij⁻¹ + G_aᵗ Σ_ij⁻¹ Σ_i ]
    """
    H, W, K = mu_i.shape
    Omega_T = np.swapaxes(Omega_ij, -1, -2)

    sigma_ij = np.einsum("...ik,...kl,...jl->...ij", Omega_ij, sigma_j, Omega_T)
    sigma_ij = sanitize_sigma(sigma_ij, eps)
    sigma_ij_inv = safe_inv(sigma_ij, eps)

    # First trace: Tr[G Σ_i Σ_ij⁻¹]
    temp1 = np.einsum("...ik,...kl->...il", sigma_i, sigma_ij_inv)
    trace1 = np.einsum("...ij,...ji->...", G_a, temp1)

    # Second trace: Tr[Gᵗ Σ_ij⁻¹ Σ_i]
    temp2 = np.einsum("...ik,...kl->...il", sigma_ij_inv, sigma_i)
    trace2 = np.einsum("...ij,...ji->...", G_a.transpose(), temp2)

    return -(trace1 + trace2)



 

#validated
def term_mahalanobis_grad_phi_i(mu_i, sigma_i, mu_j, sigma_j, Omega_ij, G_a, eps=1e-8):
    """
    Compute ∂/∂φ_i^a of the Mahalanobis term in KL(q_i || Ω_ij q_j):
        (μ_i - Ω_ij μ_j)^T Σ_ij^{-1} (μ_i - Ω_ij μ_j)
    where:
        Σ_ij = Ω_ij Σ_j Ω_ij^T
    and Ω_ij = exp(φ_i) @ exp(-φ_j)

    Returns:
        result : shape (H, W)
    """
    H, W, K = mu_i.shape

    Omega_T = Omega_ij.transpose(0, 1, 3, 2)
    mu_j_bar = np.einsum("...ij,...j->...i", Omega_ij, mu_j)
    delta_mu = mu_i - mu_j_bar

    sigma_ij = np.einsum("...ik,...kl,...jl->...ij", Omega_ij, sigma_j, Omega_T)
    sigma_ij = sanitize_sigma(sigma_ij, eps)
    sigma_ij_inv = safe_inv(sigma_ij, eps)

    # --- Term 1 ---
    tmp = np.einsum("...k,kl->...l", mu_j, G_a)
    mu_j_GO = np.einsum("...k,...kj->...j", tmp, Omega_ij)
    term1 = -np.einsum("...i,...ij,...j->...", delta_mu, sigma_ij_inv, mu_j_GO)

    # --- Corrected Term 2 ---
    # mu_j^T @ Omega_ij^T
    mu_j_O_T = np.einsum("...j,...ij->...i", mu_j, Omega_T)

    # (mu_j^T @ Omega_ij^T) @ G_a^T
    mu_j_O_T_G_T = np.einsum("...i,ij->...j", mu_j_O_T, G_a.T)

    # Full contraction: (μ_jᵀ Ωᵀ Gᵀ Σ⁻¹) · Δμ
    mu_j_O_T_G_T_Sinv = np.einsum("...j,...jk->...k", mu_j_O_T_G_T, sigma_ij_inv)
    term2 = -np.einsum("...k,...k->...", mu_j_O_T_G_T_Sinv, delta_mu)

    # --- Term 3 ---
    sym_term = (
        np.einsum("...ij,jk->...ik", sigma_ij_inv, G_a) +
        np.einsum("jk,...ij->...ik", G_a.T, sigma_ij_inv)
    )
    term3 = -np.einsum("...i,...ij,...j->...", delta_mu, sym_term, delta_mu)

    return 0.5* (term1 + term2 + term3)



#validated
def term_logdet_grad_phi_i(sigma_j, Omega_ij, generators, eps=1e-8):
    """
    Compute ∂/∂φ_i^a log det(Ω Σ_j Ω^T) = Tr[ Σ⁻¹ G_a Σ ]
    for each generator direction a.
    """
    H, W, K, _ = Omega_ij.shape
    d = generators.shape[0]

    Omega_T = np.transpose(Omega_ij, (0, 1, 3, 2))
    sigma_proj = Omega_ij @ sigma_j @ Omega_T
    sigma_proj = sanitize_sigma(sigma_proj, eps)
    sigma_proj_inv = safe_inv(sigma_proj, eps)

    grads = []

    for a in range(d):
        G = generators[a]  # (K, K)

        # G_a Σ
        G_sigma = np.einsum("ij,...jk->...ik", G, sigma_proj)

        # Σ⁻¹ G_a Σ
        term = np.einsum("...ij,...jk->...ik", sigma_proj_inv, G_sigma)

        # Tr[ Σ⁻¹ G_a Σ ]
        trace = np.einsum("...ii->...", term)

        grads.append(trace)

    return np.stack(grads, axis=-1)



def term_trace_grad_phi_j(
    mu_i, sigma_i, mu_j, sigma_j,
    Omega_ij, G_a_R,
    eps=1e-8
):
    """
    Compute ∂/∂φ_j^a Tr[(Ω Σ_j Ωᵀ)^−1 (Ω G_R Σ_j Ωᵀ + Ω Σ_j G_Rᵀ Ωᵀ) Σ_i]
    for a single transported generator G_R = e^{φ_j} G_a e^{-φ_j}.

    Args:
        G_a_R     : (H, W, K, K), spatially transported generator
        Omega_ij  : (H, W, K, K)
        sigma_i   : (H, W, K, K)
        sigma_j   : (H, W, K, K)
        eps       : regularization constant

    Returns:
        gradient  : (H, W)
    """
    Omega_T = np.transpose(Omega_ij, (0, 1, 3, 2))
    G_R_T   = np.transpose(G_a_R,    (0, 1, 3, 2))

    # Compute Ω Σ_j Ωᵀ and inverse
    sigma_ij = Omega_ij @ sigma_j @ Omega_T
    sigma_ij = sanitize_sigma(sigma_ij, eps)
    sigma_ij_inv = safe_inv(sigma_ij, eps=eps)

    # A = Ω G_R Σ_j Ωᵀ
    A = Omega_ij @ G_a_R @ sigma_j @ Omega_T

    # B = Ω Σ_j G_Rᵀ Ωᵀ
    B = Omega_ij @ sigma_j @ G_R_T @ Omega_T

    # Trace terms: Tr[Σ⁻¹ A Σ⁻¹ Σ_i] + Tr[Σ⁻¹ B Σ⁻¹ Σ_i]
    term1 = np.einsum("...ij,...jk,...kl,...li->...", sigma_ij_inv, A, sigma_ij_inv, sigma_i)
    term2 = np.einsum("...ij,...jk,...kl,...li->...", sigma_ij_inv, B, sigma_ij_inv, sigma_i)

    return term1 + term2  # shape (H, W)



#validated
def term_logdet_grad_phi_j(mu_i, sigma_i, mu_j, sigma_j,
                           Omega_ij, G_a,
                           exp_phi_j, exp_neg_phi_j,phi_j,
                           eps=1e-8):
    """
    Log-det gradient ∂/∂φ_j^a KL(q_i || Ω_ij q_j) for a single generator G_a:
        − Tr[ (Ω Σ_j Ωᵀ)^−1 (Ω G_R Σ_j Ωᵀ + Ω Σ_j G_Rᵀ Ωᵀ) ]
    where G_R = exp(φ_j) G_a exp(−φ_j)

    Args:
        G_a            : shape (K, K)
        exp_phi_j      : shape (H, W, K, K)
        exp_neg_phi_j  : shape (H, W, K, K)
        Omega_ij       : shape (H, W, K, K)

    Returns:
        gradient       : shape (H, W)
    """
    H, W, K, _ = sigma_j.shape

    # Correct contraction for G_R = exp(φ_j) G_a exp(-φ_j)
    
    G_R = d_exp_minus_phi(phi_vec=phi_j, generators=np.array([G_a]), group_name="so3")[..., 0, :, :]

    G_R_T = np.transpose(G_R, (0, 1, 3, 2))                        # (H, W, K, K)

    Omega_T = np.transpose(Omega_ij, (0, 1, 3, 2))
    sigma_ij = Omega_ij @ sigma_j @ Omega_T
    sigma_ij = sanitize_sigma(sigma_ij, eps)
    sigma_ij_inv = safe_inv(sigma_ij, eps=eps)

    A = Omega_ij @ G_R @ sigma_j @ Omega_T
    B = Omega_ij @ sigma_j @ G_R_T @ Omega_T

    term1 = np.einsum("...ij,...ji->...", sigma_ij_inv, A)
    term2 = np.einsum("...ij,...ji->...", sigma_ij_inv, B)

    return -(term1 + term2)  # shape (H, W)



def term_mahalanobis_grad_phi_j(
    mu_i, sigma_i, mu_j, sigma_j,
    Omega_ij, G_a_R,
    exp_phi_j, exp_neg_phi_j,phi_j,
    eps=1e-8
):
    """
    Compute ∂/∂φ_j^a (Δμᵗ Σ⁻¹ Δμ) using analytic gradient formula.
    Each term is scalar per grid point.

    Args:
        mu_i        : Agent i mean (H, W, K)
        sigma_i     : Agent i covariance (unused here)
        mu_j        : Agent j mean (H, W, K)
        sigma_j     : Agent j covariance (H, W, K, K)
        Omega_ij    : Transport operator from j to i (H, W, K, K)
        G_a_R       : Transported generator: Gᵃʳ = exp(φ_j) G_a exp(−φ_j) (H, W, K, K)
        exp_phi_j   : Not used here (included for API parity)
        exp_neg_phi_j : Not used here (included for API parity)
        eps         : Numerical stability for inverse/sanitize

    Returns:
        term        : Scalar field (H, W)
    """
    H, W, K = mu_i.shape

    Omega_T = np.transpose(Omega_ij, (0, 1, 3, 2))  # (H, W, K, K)

    # Transported μ_j
    mu_j_bar = np.einsum("...ij,...j->...i", Omega_ij, mu_j)  # (H, W, K)
    delta_mu = mu_i - mu_j_bar  # (H, W, K)

    # Transported covariance: Σ_{ij} = Ω Σ_j Ωᵀ
    Sigma_ij = np.einsum("...ik,...kl,...jl->...ij", Omega_ij, sigma_j, Omega_T)  # (H, W, K, K)
    Sigma_ij = sanitize_sigma(Sigma_ij, eps=eps)
    Sigma_ij_inv = safe_inv(Sigma_ij, eps=eps)  # (H, W, K, K)

    # --- Term 1: -Δμᵗ Σ⁻¹ μ_j Ω G ---
    mu_j_G = np.einsum("...ij,...j->...i", G_a_R, mu_j)
    mu_j_G_O = np.einsum("...ij,...j->...i", Omega_ij, mu_j_G)

    tmp1 = np.einsum("...i,...ij,...j->...", delta_mu, Sigma_ij_inv, mu_j_G_O)  # (H, W)
    term1 = -tmp1

    # --- Term 2: -μ_jᵗ Gᵀ Ωᵗ Σ⁻¹ Δμ ---
    G_R_T = np.transpose(G_a_R, (0, 1, 3, 2))                     # (H, W, K, K)
    tmp2a = np.einsum("...ij,...jk->...ik", G_R_T, Omega_T)       # (H, W, K, K)
    tmp2b = np.einsum("...ij,...jk->...ik", tmp2a, Sigma_ij_inv)  # (H, W, K, K)
    mu_j_G_RO_inv = np.einsum("...i,...ij->...j", mu_j, tmp2b)    # (H, W, K)
    term2 = -np.einsum("...i,...i->...", mu_j_G_RO_inv, delta_mu) # (H, W)

    # --- Term 3: -Δμᵗ Σ⁻¹ (Ω G Σ Ωᵗ + Ω Σ Gᵀ Ωᵗ) Σ⁻¹ Δμ ---
    # A = Ω G Σ Ωᵀ
    A = np.einsum("...ik,...kl,...lj->...ij", Omega_ij, G_a_R, sigma_j)  # (H, W, K, K)
    A = np.einsum("...ij,...jk->...ik", A, Omega_T)

    # B = Ω Σ Gᵀ Ωᵀ
    B = np.einsum("...ik,...kl,...lj->...ij", Omega_ij, sigma_j, G_R_T)  # (H, W, K, K)
    B = np.einsum("...ij,...jk->...ik", B, Omega_T)

    M = A + B  # (H, W, K, K)

    # Full sandwich: Δμᵗ Σ⁻¹ M Σ⁻¹ Δμ
    tmp3a = np.einsum("...i,...ij->...j", delta_mu, Sigma_ij_inv)       # (H, W, K)
    tmp3b = np.einsum("...i,...ij->...j", tmp3a, M)                     # (H, W, K)
    tmp3c = np.einsum("...i,...ij->...j", tmp3b, Sigma_ij_inv)          # (H, W, K)
    term3 = -np.einsum("...i,...i->...", tmp3c, delta_mu)
             # (H, W)

    return term1 + term2 + term3  # (H, W)