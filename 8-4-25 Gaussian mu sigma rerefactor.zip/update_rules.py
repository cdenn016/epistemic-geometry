# -*- coding: utf-8 -*-
"""
Created on Wed Jul 23 10:32:58 2025

@author: chris and christine
"""
from joblib import Parallel, delayed
import numpy as np
import config
from natural_gradient import (compute_inverse_fisher_field_natural, compute_inverse_fisher_morphism_field,
                              )
from get_generators import get_generators
from omega import exp_lie_algebra_irrep
from natural_params_utils import natural_to_mu_sigma_batch
from numerical_utils import soft_clip_phi_norm, safe_inv                       

from generalized_math_utils import safe_batch_inverse     
from numerical_utils import sanitize_sigma, sanitize_eta2, safe_omega_inv              
from generalized_diagnostics_metrics import compute_alignment_field_general


from generalized_diagnostics_metrics import compute_alignment_field_general


from update_terms_morphisms import (
                                    accumulate_phi_gradient_from_morphism_self_and_feedback, 
                                    accumulate_phi_tilde_gradient_from_morphism_self_and_feedback
                                    )


from update_terms_mu_sigma_belief import accumulate_mu_sigma_gradient_belief
from update_terms_mu_sigma_model import accumulate_mu_sigma_gradient_model

from update_terms_phi import accumulate_phi_gradient_belief, accumulate_phi_gradient_model


from update_terms_eta1_eta2_belief import accumulate_eta_gradient_belief
from update_terms_eta1_eta2_model import accumulate_eta_gradient_model

def zero_all_gradients(agent_i):
    import numpy as np

    def ensure_writeable(arr):
        if arr is None:
            return None
        if not arr.flags.writeable:
            return np.copy(arr)
        return arr

    # μ and Σ gradients (belief)
    agent_i.grad_mu_q_field = ensure_writeable(agent_i.grad_mu_q_field)
    agent_i.grad_sigma_q_field = ensure_writeable(agent_i.grad_sigma_q_field)
    agent_i.grad_mu_q = agent_i.grad_mu_q_field
    agent_i.grad_sigma_q = agent_i.grad_sigma_q_field

    # μ and Σ gradients (model)
    agent_i.grad_mu_p_field = ensure_writeable(agent_i.grad_mu_p_field)
    agent_i.grad_sigma_p_field = ensure_writeable(agent_i.grad_sigma_p_field)
    agent_i.grad_mu_p = agent_i.grad_mu_p_field
    agent_i.grad_sigma_p = agent_i.grad_sigma_p_field

    # Gauge field gradients
    agent_i.grad_phi = ensure_writeable(agent_i.grad_phi)
    agent_i.grad_phi_tilde = ensure_writeable(agent_i.grad_phi_tilde)

    # Morphism gradients
    agent_i.grad_Phi = ensure_writeable(agent_i.grad_Phi)
    agent_i.grad_Phi_tilde = ensure_writeable(agent_i.grad_Phi_tilde)

    # Natural parameter gradients (if defined)
    if hasattr(agent_i, "grad_eta1_q_field") and agent_i.grad_eta1_q_field is not None:
        agent_i.grad_eta1_q_field = ensure_writeable(agent_i.grad_eta1_q_field)
        agent_i.grad_eta1_q_field.fill(0)
    if hasattr(agent_i, "grad_eta2_q_field") and agent_i.grad_eta2_q_field is not None:
        agent_i.grad_eta2_q_field = ensure_writeable(agent_i.grad_eta2_q_field)
        agent_i.grad_eta2_q_field.fill(0)
    if hasattr(agent_i, "grad_eta1_p_field") and agent_i.grad_eta1_p_field is not None:
        agent_i.grad_eta1_p_field = ensure_writeable(agent_i.grad_eta1_p_field)
        agent_i.grad_eta1_p_field.fill(0)
    if hasattr(agent_i, "grad_eta2_p_field") and agent_i.grad_eta2_p_field is not None:
        agent_i.grad_eta2_p_field = ensure_writeable(agent_i.grad_eta2_p_field)
        agent_i.grad_eta2_p_field.fill(0)

    # Zero everything else
    agent_i.grad_mu_q_field.fill(0)
    agent_i.grad_sigma_q_field.fill(0)
    agent_i.grad_mu_p_field.fill(0)
    agent_i.grad_sigma_p_field.fill(0)
    agent_i.grad_phi.fill(0)
    agent_i.grad_phi_tilde.fill(0)
    if agent_i.grad_Phi is not None:
        agent_i.grad_Phi.fill(0)
    if agent_i.grad_Phi_tilde is not None:
        agent_i.grad_Phi_tilde.fill(0)

        

def build_all_omega_caches(agents):
    """
    Build Ω and Ω̃ caches for each agent using their precomputed exp(φ).
    Should be called AFTER preprocess_agent_fields for all agents.
    """
    for agent_i in agents:
        agent_i.Omega_cache = {}
        agent_i.Omega_tilde_cache = {}

        for nb in agent_i.neighbors:
            j = nb["id"]
            agent_j = agents[j]

            Omega_ij = np.einsum("...ik,...kj->...ij", agent_i._exp_phi, agent_j._exp_neg_phi)
            Omega_tilde_ij = np.einsum("...ik,...kj->...ij", agent_i._exp_phi_model, agent_j._exp_neg_phi_model)

            agent_i.Omega_cache[j] = Omega_ij
            agent_i.Omega_tilde_cache[j] = Omega_tilde_ij
            
def preprocess_agent_fields(agent, params):
    """
    Sanitize sigmas, convert to natural parameters, cache Fisher info,
    compute exp(φ), exp(−φ), and inverse Fisher metrics.
    """
    from numerical_utils import sanitize_sigma, safe_inv
    from natural_params_utils import convert_mu_sigma_to_eta

    # ───── Fetch Lie algebra generators from config ─────
    group_name = config.group_name
    G_q = get_generators(group_name, config.K_q)
    G_p = get_generators(group_name, config.K_p)

    # ───── Sanitize covariance fields ─────
    agent.sigma_q_field = sanitize_sigma(agent.sigma_q_field, eps=config.eta2_min_eigval)
    agent.sigma_p_field = sanitize_sigma(agent.sigma_p_field, eps=config.eta2_min_eigval)

    # ───── Convert to natural parameters and cache inverses ─────
    #agent.eta1_q_field, agent.eta2_q_field = convert_mu_sigma_to_eta(agent.mu_q_field, agent.sigma_q_field)
    #agent.eta1_p_field, agent.eta2_p_field = convert_mu_sigma_to_eta(agent.mu_p_field, agent.sigma_p_field)

    #agent.eta2_q_inv = safe_inv(agent.eta2_q_field, eps=config.eta2_min_eigval)
    #agent.eta2_p_inv = safe_inv(agent.eta2_p_field, eps=config.eta2_min_eigval)

    # ───── Initialize natural gradient fields ─────
   # agent.grad_eta1_q_field = np.zeros_like(agent.eta1_q_field)
  #  agent.grad_eta2_q_field = np.zeros_like(agent.eta2_q_field)
  #  agent.grad_eta1_p_field = np.zeros_like(agent.eta1_p_field)
  #  agent.grad_eta2_p_field = np.zeros_like(agent.eta2_p_field)

    # ───── Compute exp(φ), exp(−φ) for belief ─────
    agent._exp_phi = exp_lie_algebra_irrep(
        agent.phi,
        G_q,
        group_name=group_name,
        max_norm=config.phi_exp_clip,
        threshold=getattr(config, "phi_exp_threshold", 1e-3),
        n_jobs=-1,
        verbose=False
    )

    # ───── Compute exp(φ_model), exp(−φ_model) for model ─────
    agent._exp_phi_model = exp_lie_algebra_irrep(
        agent.phi_model,
        G_p,
        group_name=group_name,
        max_norm=config.phi_exp_clip,
        threshold=getattr(config, "phi_exp_threshold", 1e-3),
        n_jobs=-1,
        verbose=False
    )
    agent._exp_neg_phi = safe_omega_inv(agent._exp_phi, debug=True)
    agent._exp_neg_phi_model = safe_omega_inv(agent._exp_phi_model, debug=True)

    # ─── Build and cache Omega fields ───
    agent.Omega_cache = {}
    agent.Omega_tilde_cache = {}

    # ───── Optional inverse Fisher metric cache for φ updates ─────
    agent.inverse_fisher_phi = compute_inverse_fisher_field_natural(agent, G_q, field="phi")
    agent.inverse_fisher_phi_model = compute_inverse_fisher_field_natural(agent, G_p, field="phi_model")



def compute_all_gradients(agent_i, agents, generators_q, generators_p, params):
    zero_all_gradients(agent_i)

    use_natural = params.get("use_natural_gradients", False)

    # ─── Gradient updates (either natural or standard) ───
    if use_natural:
        accumulate_eta_gradient_belief(agent_i, agents, params)
        accumulate_eta_gradient_model(agent_i, agents, params)
    else:
        accumulate_mu_sigma_gradient_belief(agent_i, agents, params)
        accumulate_mu_sigma_gradient_model(agent_i, agents, params)

    # ─── φ and φ̃ updates via alignment terms ───
    for nb in agent_i.neighbors:
        agent_j = agents[nb["id"]]
        accumulate_phi_gradient_belief(agent_i, agent_j, generators_q, params)
        accumulate_phi_gradient_model(agent_i, agent_j, generators_p, params)

    # ─── φ update from morphism self + feedback terms ───
    accumulate_phi_gradient_from_morphism_self_and_feedback(
        agent_i, generators_p, generators_q, params
    )

    # ─── φ̃ update from morphism self + feedback terms ───
    accumulate_phi_tilde_gradient_from_morphism_self_and_feedback(
        agent_i, generators_p, generators_q, params
    )

    return (
        (agent_i.grad_mu_q, agent_i.grad_sigma_q),
        (agent_i.grad_mu_p, agent_i.grad_sigma_p),
        agent_i.grad_phi,
        agent_i.grad_phi_tilde,
        agent_i.grad_Phi,
        agent_i.grad_Phi_tilde,
    )



def compute_adaptive_eta(base_eta, grad, cached_kl, sigma_field, scaling_kl, scaling_cond, eta_min):
    """
    Computes adaptive step size η based on KL alignment and condition number proxy of Σ.

    Uses:
        - KL divergence (or grad norm fallback)
        - Condition proxy: trace(Σ) / det(Σ)^{1/K} (safer than cond)

    Returns:
        eta_scaled: clipped η in [eta_min, base_eta]
    """
    eps = 1e-8
    K = sigma_field.shape[-1]

    # KL or fallback to grad norm
    kl_term = (
        np.mean(cached_kl)
        if cached_kl is not None and np.isfinite(np.mean(cached_kl))
        else np.mean(np.abs(grad))
    )

    try:
        # Reshape to (..., K, K)
        Sigma = sigma_field.reshape(-1, K, K)
        traces = np.trace(Sigma, axis1=-2, axis2=-1)            # (...,)
        dets = np.linalg.det(Sigma)                             # (...,)
        dets = np.clip(dets, eps, None)                         # avoid divide by 0
        cond_proxy = traces / (dets ** (1.0 / K))               # (...,)
        cond_avg = np.mean(cond_proxy)
    except Exception:
        cond_avg = 1.0

    denom = 1.0 + scaling_kl * kl_term + scaling_cond * cond_avg
    eta_scaled = base_eta / denom
    return np.clip(eta_scaled, eta_min, base_eta)




def apply_phi_updates(agent, grad_phi, grad_phi_m, mask, params):
    mask_exp = mask[..., None]

    def clip_lie_update(delta, threshold):
        if threshold <= 0:
            return delta
        norm = np.linalg.norm(delta, axis=-1, keepdims=True)
        factor = np.minimum(1.0, threshold / (norm + 1e-8))
        return delta * factor

    # Extract config safely
    cfg = {k: getattr(config, k) for k in dir(config) if not k.startswith("__")}
    if params is not None:
        cfg.update(params)

    # φ adaptive update
    eta_phi_tuned = compute_adaptive_eta(
        cfg["tau_phi"],
        grad_phi,
        getattr(agent, "cached_alignment_kl", None),
        agent.sigma_q_field,
        cfg["eta_phi_adaptive_scaling"],
        cfg["eta_sigma_condition_scaling"],
        cfg["eta_phi_min"],
    )
    delta_phi = eta_phi_tuned * grad_phi
    delta_phi = clip_lie_update(delta_phi, cfg.get("phi_grad_clip_threshold", 0.0))
    delta_phi = np.nan_to_num(delta_phi, nan=0.0, posinf=1e5, neginf=-1e5)
    agent.phi -= delta_phi * mask_exp

    # φ̃ adaptive update
    eta_phi_m_tuned = compute_adaptive_eta(
        cfg["tau_phi_model"],
        grad_phi_m,
        getattr(agent, "cached_model_alignment_kl", None),
        agent.sigma_p_field,
        cfg["eta_phi_model_adaptive_scaling"],
        cfg["eta_sigma_condition_scaling"],
        cfg["eta_phi_model_min"],
    )
    delta_phi_m = eta_phi_m_tuned * grad_phi_m
    delta_phi_m = clip_lie_update(delta_phi_m, cfg.get("phi_model_grad_clip_threshold", 0.0))
    delta_phi_m = np.nan_to_num(delta_phi_m, nan=0.0, posinf=1e5, neginf=-1e5)
    agent.phi_model -= delta_phi_m * mask_exp






def synchronous_step(agents, generators_q, generators_p, params=None, n_jobs=1):
    params = params or {}
    N = len(agents)
    print(f"[DEBUG] Using {n_jobs} workers in synchronous_step")

    tau_mu_belief   = params.get("tau_mu_belief", config.tau_mu_belief)
    tau_sigma_belief = params.get("tau_sigma_belief", config.tau_sigma_belief)
    tau_mu_model    = params.get("tau_mu_model", config.tau_mu_model)
    tau_sigma_model = params.get("tau_sigma_model", config.tau_sigma_model)
    eps = config.eps

    # Step 1: Preprocess φ, φ̃ and exp(·) fields
    Parallel(n_jobs=n_jobs, backend="threading", batch_size=1)(
        delayed(preprocess_agent_fields)(A, params) for A in agents
    )

    # Step 2: Build all Ω caches after φ exponential maps are prepared
    build_all_omega_caches(agents)

    # Step 3: Compute all gradients
    grads = Parallel(n_jobs=n_jobs, backend="loky", batch_size=2)(
        delayed(compute_all_gradients)(agent_i, agents, generators_q, generators_p, params)
        for agent_i in agents
    )
    q_updates, p_updates, phi_grads, phi_m_grads, morphism_grads, morphism_tilde_grads = zip(*grads)
    mask_list = [A.mask for A in agents]

    # Step 4: Apply η and φ updates
    def apply_agent_updates(i):
        agent = agents[i]
        mask = mask_list[i]

        Δη1_q, Δη2_q = q_updates[i]
        Δη1_p, Δη2_p = p_updates[i]

        # Fallback safeguards
        if Δη1_q is None: Δη1_q = np.zeros_like(agent.mu_q_field)
        if Δη2_q is None: Δη2_q = np.zeros_like(agent.sigma_q_field)
        if Δη1_p is None: Δη1_p = np.zeros_like(agent.mu_p_field)
        if Δη2_p is None: Δη2_p = np.zeros_like(agent.sigma_p_field)

        mask_mu    = mask[..., None]
        mask_sigma = mask[..., None, None]

        # Apply μ updates
        q_mu_update = tau_mu_belief   * Δη1_q * mask_mu
        p_mu_update = tau_mu_model    * Δη1_p * mask_mu

        # Apply Σ updates
        q_si_update = tau_sigma_belief * Δη2_q * mask_sigma
        p_si_update = tau_sigma_model  * Δη2_p * mask_sigma

        agent.mu_q_field -= q_mu_update
        agent.mu_p_field -= p_mu_update
        agent.sigma_q_field = sanitize_sigma(agent.sigma_q_field - q_si_update, eps=eps)
        agent.sigma_p_field = sanitize_sigma(agent.sigma_p_field - p_si_update, eps=eps)

        # Apply φ and φ̃ updates
        apply_phi_updates(agent, phi_grads[i], phi_m_grads[i], mask, params)
        
        agent.phi       = soft_clip_phi_norm(agent.phi, max_norm=np.pi)
        agent.phi_model = soft_clip_phi_norm(agent.phi_model, max_norm=np.pi)

        return agent

    Parallel(n_jobs=n_jobs, backend="threading", batch_size="auto")(
        delayed(apply_agent_updates)(i) for i in range(N)
    )

    # Step 5: Refresh cached KL fields for animation and analysis
    for A in agents:
        A.cached_alignment_kl       = compute_alignment_field_general(agents, A.id, field_type="belief", log_eps=eps)
        A.cached_model_alignment_kl = compute_alignment_field_general(agents, A.id, field_type="model", log_eps=eps)

    return agents


