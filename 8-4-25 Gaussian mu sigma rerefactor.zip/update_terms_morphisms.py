# -*- coding: utf-8 -*-
"""
Created on Wed Jul 23 06:38:37 2025

@author: chris and christine
"""
import numpy as np
from natural_gradient import compute_inverse_fisher_field_natural  # you will need to implement this
from numerical_utils import safe_inv, sanitize_sigma
from get_generators import get_generators
import config   
#==============================================================================
#
#                    Apply Natural Gradient to Bundle Morphism
#
#==============================================================================

from natural_gradient import dexpinv_operator
from omega import d_exp_phi_exact, d_exp_phi_tilde_exact, exp_lie_algebra_irrep

from bundle_morphism_utils import compute_direct_morphisms

from numerical_utils import safe_inv
from natural_params_utils import compute_delta_eta_q_PhiTilde_p

def clip_gradient_norm(grad, max_norm=5.0, eps=1e-8):
    norm = np.linalg.norm(grad, axis=-1, keepdims=True)
    scale = np.minimum(1.0, max_norm / (norm + eps))
    return grad * scale


def accumulate_phi_gradient_from_morphism_self_and_feedback(agent_i, generators_p, generators_q, params, debug=False):
    """
    Accumulate ∇_φ from:
      - KL(q || Φ̃·p)    ← self-energy (belief)
      - KL(p || Φ·q)     ← feedback (model)
    into:
      - agent_i.grad_phi
    """
   

    alpha   = params.get("alpha", config.alpha)
    lambda_ = params.get("feedback_weight", config.feedback_weight)
    if alpha <= 0 and lambda_ <= 0:
        return

    eps  = config.support_cutoff_eps
    mask = (agent_i.mask > eps)[..., None]  # (H, W, 1)

    mu_q, sigma_q = agent_i.mu_q_field, agent_i.sigma_q_field
    mu_p, sigma_p = agent_i.mu_p_field, agent_i.sigma_p_field
    phi, phi_tilde = agent_i.phi, agent_i.phi_model

    # Compute Φ and Φ̃ from φ, φ̃
    agent_i.bundle_morphism_q_to_p, agent_i.bundle_morphism_p_to_q = compute_direct_morphisms(
        phi        = agent_i.phi,
        phi_model  = agent_i.phi_model,
        generators_q = agent_i.generators_q,
        generators_p = agent_i.generators_p,
        Phi_0        = agent_i.Phi_0,
        Phi_tilde_0  = agent_i.Phi_tilde_0,
    )
    Phi       = agent_i.bundle_morphism_q_to_p
    Phi_tilde = agent_i.bundle_morphism_p_to_q

    # ───── Self-energy gradient: ∇_φ KL(q || Φ̃·p) ─────
    if alpha > 0:
        grad_Phi_tilde = grad_kl_morphism_self(mu_q, sigma_q, mu_p, sigma_p, Phi_tilde, eps=eps)
        grad_phi_self = backprop_phi_from_grad_Phi_tilde(
            grad_Phi_tilde, phi, phi_tilde,
            Phi_tilde,
            generators_q, generators_p,
            exp_phi=agent_i._exp_phi,
            exp_phi_tilde=agent_i._exp_phi_model,
        )
        G_inv = agent_i.inverse_fisher_phi
        grad_phi_self = np.einsum("...ab,...b->...a", G_inv, grad_phi_self)
        grad_phi_self = dexpinv_operator(phi, grad_phi_self, generators_q)
        grad_phi_self = clip_gradient_norm(grad_phi_self, config.phi_grad_clip)

        grad_phi_self *= mask
        agent_i.grad_phi += alpha * grad_phi_self

    # ───── Feedback gradient: ∇_φ KL(p || Φ·q) ─────
    if lambda_ > 0:
        grad_Phi = grad_kl_morphism_feedback(mu_p, sigma_p, mu_q, sigma_q, Phi, eps=eps)
        grad_phi_feedback = backprop_phi_from_grad_Phi(
            grad_Phi, phi, phi_tilde,
            Phi,
            generators_q, generators_p,
            exp_phi=agent_i._exp_phi,
            exp_phi_tilde=agent_i._exp_phi_model,
        )
        G_inv = agent_i.inverse_fisher_phi
        grad_phi_feedback = np.einsum("...ab,...b->...a", G_inv, grad_phi_feedback)
        grad_phi_feedback = dexpinv_operator(phi, grad_phi_feedback, generators_q)
        grad_phi_feedback = clip_gradient_norm(grad_phi_feedback, config.phi_grad_clip)
        grad_phi_feedback *= mask
        agent_i.grad_phi += lambda_ * grad_phi_feedback


def accumulate_phi_tilde_gradient_from_morphism_self_and_feedback(agent_i, generators_p, generators_q, params, debug=False):
    """
    Accumulate ∇_{φ̃} from:
      - KL(q || Φ̃·p)    ← self-energy (belief)
      - KL(p || Φ·q)     ← feedback (model)
    into:
      - agent_i.grad_phi_tilde
    """
    

    alpha   = params.get("alpha", config.alpha)
    lambda_ = params.get("feedback_weight", config.feedback_weight)
    if alpha <= 0 and lambda_ <= 0:
        return

    eps  = config.support_cutoff_eps
    mask = (agent_i.mask > eps)[..., None]  # (H, W, 1)

    mu_q, sigma_q = agent_i.mu_q_field, agent_i.sigma_q_field
    mu_p, sigma_p = agent_i.mu_p_field, agent_i.sigma_p_field
    phi, phi_tilde = agent_i.phi, agent_i.phi_model

    Phi        = agent_i.bundle_morphism_q_to_p  # (..., K_p, K_q)
    Phi_tilde  = agent_i.bundle_morphism_p_to_q  # (..., K_q, K_p)

    # ───── Self-energy gradient: ∇_{φ̃} KL(q || Φ̃·p) ─────
    if alpha > 0:
        grad_Phi_tilde = grad_kl_morphism_self(
            mu_q, sigma_q, mu_p, sigma_p, Phi_tilde, eps=eps
        )
        grad_phi_tilde_self = backprop_phi_tilde_from_grad_Phi_tilde(
            grad_Phi_tilde, phi_tilde, phi,
            Phi_tilde,
            generators_p, generators_q,
            exp_phi=agent_i._exp_phi,
            exp_phi_tilde=agent_i._exp_phi_model,
        )
        G_inv_tilde = agent_i.inverse_fisher_phi_model
        grad_phi_tilde_self = np.einsum("...ab,...b->...a", G_inv_tilde, grad_phi_tilde_self)
        grad_phi_tilde_self = dexpinv_operator(phi_tilde, grad_phi_tilde_self, generators_p)
        grad_phi_tilde_self = clip_gradient_norm(grad_phi_tilde_self, config.phi_grad_clip)
        grad_phi_tilde_self *= mask
        agent_i.grad_phi_tilde += alpha * grad_phi_tilde_self

    # ───── Feedback gradient: ∇_{φ̃} KL(p || Φ·q) ─────
    if lambda_ > 0:
        grad_Phi = grad_kl_morphism_feedback(
            mu_p, sigma_p, mu_q, sigma_q, Phi, eps=eps
        )
        grad_phi_tilde_feedback = backprop_phi_tilde_from_grad_Phi(
            grad_Phi, phi_tilde, phi,
            Phi,
            generators_p, generators_q,
            exp_phi=agent_i._exp_phi,
            exp_phi_tilde=agent_i._exp_phi_model,
        )
        G_inv_tilde = agent_i.inverse_fisher_phi_model
        grad_phi_tilde_feedback = np.einsum("...ab,...b->...a", G_inv_tilde, grad_phi_tilde_feedback)
        grad_phi_tilde_feedback = dexpinv_operator(phi_tilde, grad_phi_tilde_feedback, generators_p)
        grad_phi_tilde_feedback = clip_gradient_norm(grad_phi_tilde_feedback, config.phi_grad_clip)
        grad_phi_tilde_feedback *= mask
        agent_i.grad_phi_tilde += lambda_ * grad_phi_tilde_feedback



def grad_kl_morphism_feedback(mu_p, Sigma_p, mu_q, Sigma_q, Phi, eps=1e-8):
    """
    Gradient of KL(p || Φ·q) w.r.t. morphism Φ : B_q → B_p in (μ, Σ) coordinates.

    Args:
        mu_p     : (..., K_p)
        Sigma_p  : (..., K_p, K_p)
        mu_q     : (..., K_q)
        Sigma_q  : (..., K_q, K_q)
        Phi      : (..., K_p, K_q)

    Returns:
        grad     : (..., K_p, K_q)
    """
    
    Sigma_q_inv = safe_inv(Sigma_q, eps=eps)
    Sigma_p_inv = safe_inv(Sigma_p, eps=eps)

    # bar_Sigma_q = Φ Σ_q Φᵀ
    bar_Sigma_q = np.einsum("...ik,...kl,...jl->...ij", Phi, Sigma_q, Phi)

    bar_Sigma_q_inv = safe_inv(bar_Sigma_q, eps=eps)

    delta_mu = mu_p - np.einsum("...ik,...k->...i", Phi, mu_q)  # (..., K_p)
    outer = np.einsum("...i,...j->...ij", delta_mu, delta_mu)   # (..., K_p, K_p)

    term1 = bar_Sigma_q_inv
    term2 = np.einsum("...ik,...kl,...lj->...ij", bar_Sigma_q_inv, Sigma_p, bar_Sigma_q_inv)
    term3 = np.einsum("...ik,...kl,...lj->...ij", bar_Sigma_q_inv, outer, bar_Sigma_q_inv)

    pre = 0.5 * (term1 - term2 - term3)

    grad = np.einsum("...ij,...jk->...ik", pre, np.einsum("...ik,...kj->...ij", Phi, Sigma_q_inv))

    return grad  # (..., K_p, K_q)



def grad_kl_morphism_self(mu_q, Sigma_q, mu_p, Sigma_p, Phi_tilde, eps=1e-8):
    """
    Gradient of KL(q || Φ̃·p) w.r.t. morphism Φ̃ : B_p → B_q in (μ, Σ) coordinates.

    Args:
        mu_q      : (..., K_q)
        Sigma_q   : (..., K_q, K_q)
        mu_p      : (..., K_p)
        Sigma_p   : (..., K_p, K_p)
        Phi_tilde : (..., K_q, K_p)

    Returns:
        grad      : (..., K_q, K_p)
    """
 

    Sigma_q_inv = safe_inv(Sigma_q, eps=eps)
    Sigma_p_inv = safe_inv(Sigma_p, eps=eps)

    # bar_Sigma_p = Φ̃ Σ_p Φ̃ᵀ
    bar_Sigma_p = np.einsum("...ik,...kl,...jl->...ij", Phi_tilde, Sigma_p, Phi_tilde)
    bar_Sigma_p_inv = safe_inv(bar_Sigma_p, eps=eps)

    delta_mu = mu_q - np.einsum("...ik,...k->...i", Phi_tilde, mu_p)
    outer = np.einsum("...i,...j->...ij", delta_mu, delta_mu)

    term1 = bar_Sigma_p_inv
    term2 = np.einsum("...ik,...kl,...lj->...ij", bar_Sigma_p_inv, Sigma_q, bar_Sigma_p_inv)
    term3 = np.einsum("...ik,...kl,...lj->...ij", bar_Sigma_p_inv, outer, bar_Sigma_p_inv)

    pre = 0.5 * (term1 - term2 - term3)

    grad = np.einsum("...ij,...jk->...ik", pre, np.einsum("...ik,...kj->...ij", Phi_tilde, Sigma_p_inv))

    return grad





def backprop_phi_from_grad_Phi(
    grad_Phi,           # (..., K_p, K_q)
    phi,                # (..., d_q)
    phi_tilde,          # (..., d_p)
    Phi_0,              # (..., K_p, K_q)
    generators_q,       # (d_q, K_q, K_q)
    generators_p,       # (d_p, K_p, K_p)
    exp_phi=None,       # optional (..., K_q, K_q)
    exp_phi_tilde=None  # optional (..., K_p, K_p)
):
    """
    Compute ∇_{φ} KL(p || Φ·q) where Φ = e^{φ~} Φ₀ e^{φ}
    Returns: (..., d_q) Euclidean gradient
    """
    from omega import exp_lie_algebra_irrep
    import config

    if exp_phi is None:
        exp_phi = exp_lie_algebra_irrep(
            phi,
            generators_q,
            group_name="so3",
            max_norm=config.phi_exp_clip,
            threshold=config.phi_exp_threshold,
            n_jobs=-1,
            verbose=False
        )
    if exp_phi_tilde is None:
        exp_phi_tilde = exp_lie_algebra_irrep(
            phi_tilde,
            generators_p,
            group_name="so3",
            max_norm=config.phi_exp_clip,
            threshold=config.phi_exp_threshold,
            n_jobs=-1,
            verbose=False
        )

    d_exp_phi = d_exp_phi_exact(phi, generators_q)
    grad_vec = []
    for a, d_exp in enumerate(d_exp_phi):
        partial = np.einsum("...ik,...kj,...jl->...il", exp_phi_tilde, Phi_0, d_exp)
        grad_a = np.einsum("...ij,...ij->...", grad_Phi, partial)
        grad_vec.append(grad_a)
    return np.stack(grad_vec, axis=-1)




def backprop_phi_tilde_from_grad_Phi(
    grad_Phi,           # (..., K_p, K_q)
    phi_tilde,          # (..., d_p)
    phi,                # (..., d_q)
    Phi_0,              # (..., K_p, K_q)
    generators_p,       # (d_p, K_p, K_p)
    generators_q,       # (d_q, K_q, K_q)
    exp_phi=None,       # optional (..., K_q, K_q)
    exp_phi_tilde=None  # optional (..., K_p, K_p)
):
    """
    Compute ∇_{φ~} KL(p || Φ·q) where Φ = e^{φ~} Φ₀ e^{φ}
    Returns: (..., d_p) Euclidean gradients
    """
    
    if exp_phi is None:
        exp_phi = exp_lie_algebra_irrep(
            phi,
            generators_q,
            group_name="so3",
            max_norm=config.phi_exp_clip,
            threshold=config.phi_exp_threshold,
            n_jobs=-1,
            verbose=False
        )
    if exp_phi_tilde is None:
        exp_phi_tilde = exp_lie_algebra_irrep(
            phi_tilde,
            generators_p,
            group_name="so3",
            max_norm=config.phi_exp_clip,
            threshold=config.phi_exp_threshold,
            n_jobs=-1,
            verbose=False
        )

    d_exp_phi_tilde = d_exp_phi_tilde_exact(phi_tilde, generators_p)
    grad_vec = []
    for a, d_exp in enumerate(d_exp_phi_tilde):
        partial = np.einsum("...ik,...kj,...jl->...il", d_exp, Phi_0, exp_phi)
        grad_a = np.einsum("...ij,...ij->...", grad_Phi, partial)
        grad_vec.append(grad_a)
    return np.stack(grad_vec, axis=-1)

def backprop_phi_from_grad_Phi_tilde(
    grad_Phi_tilde,     # (..., K_q, K_p)
    phi,                # (..., d_q)
    phi_tilde,          # (..., d_p)
    Phi_0_tilde,        # (..., K_q, K_p)
    generators_q,       # (d_q, K_q, K_q)
    generators_p,       # (d_p, K_p, K_p)
    exp_phi=None,       # optional (..., K_q, K_q)
    exp_phi_tilde=None  # optional (..., K_p, K_p)
):
    """
    Compute ∇_{φ} KL(q || Φ̃·p) where Φ̃ = e^{φ} Φ̃₀ e^{φ̃}
    Returns: (..., d_q)
    """
    

    if exp_phi is None:
        exp_phi = exp_lie_algebra_irrep(
            phi,
            generators_q,
            group_name="so3",
            max_norm=config.phi_exp_clip,
            threshold=config.phi_exp_threshold,
            n_jobs=-1,
            verbose=False
        )
    if exp_phi_tilde is None:
        exp_phi_tilde = exp_lie_algebra_irrep(
            phi_tilde,
            generators_p,
            group_name="so3",
            max_norm=config.phi_exp_clip,
            threshold=config.phi_exp_threshold,
            n_jobs=-1,
            verbose=False
        )

    d_exp_phi = d_exp_phi_exact(phi, generators_q)
    grad_vec = []
    for a, d_exp in enumerate(d_exp_phi):
        partial = np.einsum("...ik,...kj,...jl->...il", d_exp, Phi_0_tilde, exp_phi_tilde)
        grad_a = np.einsum("...ij,...ij->...", grad_Phi_tilde, partial)
        grad_vec.append(grad_a)

    return np.stack(grad_vec, axis=-1)

def backprop_phi_tilde_from_grad_Phi_tilde(
    grad_Phi_tilde,     # (..., K_q, K_p)
    phi_tilde,          # (..., d_p)
    phi,                # (..., d_q)
    Phi_0_tilde,        # (..., K_q, K_p)
    generators_p,       # (d_p, K_p, K_p)
    generators_q,       # (d_q, K_q, K_q)
    exp_phi=None,       # optional (..., K_q, K_q)
    exp_phi_tilde=None  # optional (..., K_p, K_p)
):
    """
    Compute ∇_{φ̃} KL(q || Φ̃·p) where Φ̃ = e^{φ} Φ̃₀ e^{φ̃}
    Returns: (..., d_p)
    """
   
    if exp_phi is None:
        exp_phi = exp_lie_algebra_irrep(
            phi,
            generators_q,
            group_name="so3",
            max_norm=config.phi_exp_clip,
            threshold=config.phi_exp_threshold,
            n_jobs=-1,
            verbose=False
        )
    if exp_phi_tilde is None:
        exp_phi_tilde = exp_lie_algebra_irrep(
            phi_tilde,
            generators_p,
            group_name="so3",
            max_norm=config.phi_exp_clip,
            threshold=config.phi_exp_threshold,
            n_jobs=-1,
            verbose=False
        )

    d_exp_phi_tilde = d_exp_phi_tilde_exact(phi_tilde, generators_p)
    grad_vec = []
    for a, d_exp in enumerate(d_exp_phi_tilde):
        partial = np.einsum("...ik,...kj,...jl->...il", exp_phi, Phi_0_tilde, d_exp)
        grad_a = np.einsum("...ij,...ij->...", grad_Phi_tilde, partial)
        grad_vec.append(grad_a)

    return np.stack(grad_vec, axis=-1)


