# -*- coding: utf-8 -*-
"""
Created on Tue Oct 21 21:52:01 2025

@author: chris and christine
"""

# updates/update_terms_phi.py (REFACTORED KEY SECTIONS)
"""
Multiprocessing-safe φ gradient accumulation using pure functions.
"""
import numpy as np
from grad_config import PhiGradientConfig
from grad_utils_phi import (
    create_phi_accum, add_phi_term, 
    get_cached_preconditioners, project_phi_covector,
    push_neighbor_stats_pure, iter_neighbors_with_masks
)
from core.transport_cache import E_grid, Omega, Phi_cached
from core.omega import d_exp_exact
from core.numerical_utils import safe_omega_inv


# Keep _FIELD_META unchanged (it's just data)


# ============================================================================
# PUBLIC API - Loky-Compatible Entry Point
# ============================================================================

def _run_phi_phase(
    ctx, agent_i, neighbors, *,
    field: str,
    generators_q, generators_p,
    fisher_inv_key: str,
    grad_key: str,
    phi_self_func, phi_feedback_func,
    timings: dict, prefix: str,
):
    """
    REFACTORED: Uses frozen PhiGradientConfig.
    
    Returns
    -------
    recv_step : ndarray (*S, 3)
    send_list : list[(agent_j, dphi_j)]
    ener_pair : (float, float)
    """
    import time
    
    # Extract or build frozen config
    if hasattr(ctx, 'phi_grad_cfg') and ctx.phi_grad_cfg is not None:
        cfg = ctx.phi_grad_cfg
    else:
        cfg = PhiGradientConfig.from_context(ctx)
    
    t0 = time.perf_counter()
    
    # Receiver step (pure functions)
    recv_step, ener_pair = phi_recv_step_pure(
        ctx, agent_i, neighbors, generators_q, generators_p,
        cfg=cfg,
        field=field,
        fisher_inv_key=fisher_inv_key,
        terms=("align", "gamma", "self"),
        phi_self_func=phi_self_func,
        phi_feedback_func=phi_feedback_func,
    )
    recv_step = recv_step.astype(np.float32, copy=False)
    timings[f"{prefix}_recv_total"] = time.perf_counter() - t0
    
    # Sender steps (pure functions)
    t1 = time.perf_counter()
    send_list = phi_send_steps_pure(
        ctx, agent_i, neighbors, generators_q, generators_p,
        cfg=cfg,
        field=field,
        fisher_inv_key=fisher_inv_key,
        strategies=("align", "gamma"),
    ) or []
    timings[f"{prefix}_send_total"] = time.perf_counter() - t1
    
    return recv_step, send_list, ener_pair


def phi_recv_step_pure(
    ctx, agent_i, neighbors, generators_q, generators_p, *,
    cfg: PhiGradientConfig,
    field: str,
    fisher_inv_key: str,
    terms=("align", "gamma", "self"),
    phi_self_func=None,
    phi_feedback_func=None,
):
    """
    Pure receiver φ gradient computation.
    
    Returns
    -------
    recv : ndarray (*S, 3)
    (self_n, fb_n) : (float, float)
    """
    which, phi_attr, mu_key, S_key, _, _ = _which_meta(field)
    gens = generators_q if field == "phi" else generators_p
    
    # Get preconditioners (cached, process-safe)
    E_i, Jinv_i, Finv_i = get_cached_preconditioners(
        ctx, agent_i, which=which, 
        fisher_inv_key=fisher_inv_key, 
        eps=cfg.eps
    )
    
    phi_i = np.asarray(getattr(agent_i, phi_attr), np.float32)
    accum = create_phi_accum(phi_i.shape)
    
    self_n = 0.0
    fb_n = 0.0
    
    # Alignment term
    if "align" in terms:
        dphi_align = compute_phi_align_recv_pure(
            ctx, agent_i, neighbors, cfg,
            which=which, gens=gens, 
            E_i=E_i, Jinv_i=Jinv_i, Finv_i=Finv_i,
            mu_key=mu_key, S_key=S_key, phi_attr=phi_attr
        )
        add_phi_term(accum, "align", dphi_align)
    
    # Gamma term
    if "gamma" in terms:
        dphi_gamma = compute_phi_gamma_recv_pure(
            ctx, agent_i, neighbors, cfg,
            which=which, gens=gens,
            E_i=E_i, Jinv_i=Jinv_i, Finv_i=Finv_i
        )
        add_phi_term(accum, "gamma", dphi_gamma)
    
    # Self + feedback
    if "self" in terms:
        dphi_self, (self_n, fb_n) = compute_phi_self_feedback_pure(
            ctx, agent_i, generators_q, generators_p, cfg,
            field=field,
            fisher_inv_key=fisher_inv_key,
            phi_self_func=phi_self_func,
            phi_feedback_func=phi_feedback_func,
        )
        add_phi_term(accum, "self", dphi_self)
    
    return accum['phi'], (self_n, fb_n)


# ============================================================================
# Alignment φ Receiver (Pure)
# ============================================================================

def compute_phi_align_recv_pure(
    ctx, ai, neighbors, cfg, *,
    which, gens, E_i, Jinv_i, Finv_i,
    mu_key, S_key, phi_attr
):
    """
    β-weighted alignment φ gradient (receiver side, pure).
    
    Implements softmax-β product rule:
        ∇φ_i = Σ_j β_ij (1 - KL/κ) g_ij + (Σ β·KL/κ) ḡ_i
    
    Returns
    -------
    dphi : ndarray (*S, 3)
    """
    from beta import beta_align_maps
    
    kappa = max(cfg.beta_kappa_q if which == "q" else cfg.beta_kappa_p, cfg.eps)
    
    mu_i = getattr(ai, mu_key)
    S_i = getattr(ai, S_key)
    phi_i = np.asarray(getattr(ai, phi_attr), np.float32)
    
    # Precompute dexp once
    Q_all_i = d_exp_exact(phi_i, gens)
    
    Sshape = np.asarray(mu_i).shape[:-1]
    i_id = int(getattr(ai, "id", -1))
    
    # Accumulators
    step_core = np.zeros_like(phi_i, np.float32)
    gbar = np.zeros_like(phi_i, np.float32)
    sum_beta_KL = np.zeros(Sshape, np.float32)
    
    for aj, m_bool, m_float in iter_neighbors_with_masks(ai, neighbors, ctx):
        # Get β/KL from edge store (pre-computed on master)
        j_id = int(getattr(aj, "id", -1))
        beta_map, KL_map = ctx.edge.get_align(ctx, which, i_id, j_id, shape=Sshape)
        if beta_map is None:
            continue
        
        beta = np.asarray(beta_map, np.float32) * m_float
        if not np.any(beta):
            continue
        KL1 = np.asarray(KL_map, np.float32) * m_float
        
        # Transport
        Om = Omega(ctx, ai, aj, which=which)
        E_j = E_grid(ctx, aj, which=which)
        exp_neg_phi_j = safe_omega_inv(E_j)
        
        mu_j_t, _, S_j_t_inv = push_neighbor_stats_pure(aj, S_key, Om, cfg.eps)
        
        # Gradient covector (unprojected)
        g_ij = grad_kl_wrt_phi_i(
            mu_i, S_i, None, None, phi_i, None,
            Om, gens, E_i, E_j, mu_j_t, S_j_t_inv, cfg.eps,
            exp_neg_phi_j=exp_neg_phi_j,
            Q_all=Q_all_i,
        ).astype(np.float32, copy=False)
        
        # Accumulate
        gbar += beta[..., None] * g_ij
        step_core += (beta * (1.0 - KL1 / kappa))[..., None] * g_ij
        sum_beta_KL += (beta * KL1)
    
    if not (np.any(step_core) or np.any(gbar)):
        return np.zeros_like(phi_i, np.float32)
    
    # Full covector with correction term
    full_cov = step_core + (sum_beta_KL / kappa)[..., None] * gbar
    
    # Project once
    return project_phi_covector(full_cov, Jinv_i, Finv_i)


# ============================================================================
# Gamma φ Receiver (Pure)
# ============================================================================

def compute_phi_gamma_recv_pure(
    ctx, ai, neighbors, cfg, *,
    which, gens, E_i, Jinv_i, Finv_i
):
    """
    γ-weighted gating φ gradient (receiver side, pure).
    
    Returns
    -------
    dphi : ndarray (*S, 3)
    """
    use_A = cfg.use_gamma_A_q if which == "q" else cfg.use_gamma_A_p
    use_B = cfg.use_gamma_B_q if which == "q" else cfg.use_gamma_B_p
    kap = cfg.kappa_gamma_q if which == "q" else cfg.kappa_gamma_p
    
    if not (use_A or use_B):
        phi_attr = "phi" if which == "q" else "phi_model"
        return np.zeros_like(getattr(ai, phi_attr), np.float32)
    
    Sshape_recv = np.asarray(
        getattr(ai, "mu_q_field" if which == "q" else "mu_p_field")
    ).shape[:-1]
    
    # Pre-fetch receiver frames/stats
    Eqi = np.asarray(E_grid(ctx, ai, which="q"), np.float64)
    Epi = np.asarray(E_grid(ctx, ai, which="p"), np.float64)
    mu_p_i = np.asarray(ai.mu_p_field, np.float64, order="C")
    Sig_p_i = np.asarray(ai.sigma_p_field, np.float64, order="C")
    
    out = None
    
    for aj, m_bool, m_float in iter_neighbors_with_masks(ai, neighbors, ctx):
        i_id = int(getattr(ai, "id", -1))
        j_id = int(getattr(aj, "id", -1))
        
        # Get γ maps (pre-computed on master)
        gA, KA = ctx.edge.get_gamma(ctx, "A", j_id, i_id, shape=Sshape_recv) if use_A else (None, None)
        gB, KB = ctx.edge.get_gamma(ctx, "B", i_id, j_id, shape=Sshape_recv) if use_B else (None, None)
        
        if (gA is None or not np.any(gA)) and (gB is None or not np.any(gB)):
            continue
        
        # Sender stats/frame
        Eqj = np.asarray(E_grid(ctx, aj, which="q"), np.float64)
        mu_q_j = np.asarray(aj.mu_q_field, np.float64, order="C")
        Sig_q_j = np.asarray(aj.sigma_q_field, np.float64, order="C")
        
        def _accum(Wmap, Kmap, basis):
            nonlocal out
            if Wmap is None or not np.any(Wmap):
                return
            W = np.asarray(Wmap, np.float32) * m_float
            if Kmap is not None:
                K = np.asarray(Kmap, np.float32) * m_float
                W = W * (1.0 - K / max(kap, cfg.eps))
            if not np.any(W):
                return
            
            # Pure dispatcher
            cov_i_q, _, cov_i_p = grad_gamma_phi_covectors(
                Eqi=Eqi, Eqj=Eqj, Epi=Epi,
                mu_q_j=mu_q_j, Sigma_q_j=Sig_q_j,
                mu_p_i=mu_p_i, Sigma_p_i=Sig_p_i,
                generators_irrep=gens,
                basis=basis, eps=cfg.eps,
            )
            
            cov_i = cov_i_q if which == "q" else cov_i_p
            term = W[..., None] * project_phi_covector(
                cov_i.astype(np.float32, copy=False), Jinv_i, Finv_i
            )
            out = term if out is None else (out + term)
        
        if use_A: _accum(gA, KA, "a")
        if use_B: _accum(gB, KB, "b")
    
    if out is None:
        phi_attr = "phi" if which == "q" else "phi_model"
        return np.zeros_like(getattr(ai, phi_attr), np.float32)
    return out


# ============================================================================
# Self + Feedback φ (Pure)
# ============================================================================

def compute_phi_self_feedback_pure(
    ctx, agent_i, generators_q, generators_p, cfg, *,
    field: str,
    fisher_inv_key: str,
    phi_self_func=None,
    phi_feedback_func=None,
):
    """
    Self + feedback φ gradients (pure function).
    
    Returns
    -------
    dphi : ndarray (*S, 3)
    (self_n, fb_n) : (float, float)
    """
    from utils import mask_hw
    
    mask3 = mask_hw(agent_i, tau=cfg.tau, mode="float3")
    if not np.any(mask3):
        phi_attr = "phi" if field == "phi" else "phi_model"
        return np.zeros_like(getattr(agent_i, phi_attr), np.float32), (0.0, 0.0)
    
    # ... (rest of implementation - same logic as before but with cfg parameter) ...
    # This is already pure - just needs cfg passed instead of cfg_get calls
    
    # (Keep existing logic, replace cfg_get with cfg.alpha, cfg.feedback_weight, etc.)
    
    pass  # Full implementation in actual file


# ============================================================================
# Sender Steps (Pure)
# ============================================================================

def phi_send_steps_pure(
    ctx, agent_i, neighbors, generators_q, generators_p, *,
    cfg: PhiGradientConfig,
    field: str,
    fisher_inv_key: str,
    strategies=("align", "gamma"),
):
    """
    Sender-side φ gradient contributions (pure function).
    
    Returns
    -------
    send_list : list[(agent_j, dphi_j)]
    """
    # ... (similar refactoring - replace cfg_get with cfg attributes) ...
    
    pass  # Full implementation in actual file


# ============================================================================
# KEEP ALL EXISTING grad_kl_wrt_phi_*, grad_self_phi_*, etc.
# These are already pure numpy functions - no changes needed
# ============================================================================

# (All the existing gradient math functions stay unchanged - they're already pure)