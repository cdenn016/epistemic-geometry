# -*- coding: utf-8 -*-
"""
Created on Tue Oct 21 21:45:45 2025

@author: chris and christine
"""

# updates/update_terms_mu_sigma.py (REFACTORED SECTION)
"""
Multiprocessing-safe μ/Σ gradient accumulation using pure functions.
"""
import numpy as np
from core.numerical_utils import (
    sanitize_sigma, safe_inv, push_gaussian, kl_gaussian,
    softmax_align_rule_receiver, softmax_align_rule_sender, plain_rule
)
from core.transport_cache import Omega, Phi_cached
from grad_config import GradientConfig
from grad_utils import (
    create_gradient_accum, add_gradient_term, symmetrize,
    safe_cast_and_sanitize, get_cached_push_forward, get_cached_push_backward,
    kl_target_partials, kl_source_partials, iter_overlap_pairs
)


# ============================================================================
# PUBLIC API - Loky-Compatible Entry Point
# ============================================================================

def accumulate_mu_sigma_gradient(ctx, agent_i, agents, mode):
    """
    Accumulate natural gradients (μ, Σ) for belief or model fiber.
    
    **Multiprocessing-safe:**
    - Uses frozen GradientConfig (picklable)
    - Pure functions with explicit config passing
    - SharedDiskCache for expensive pushes
    - No mutations to ctx.edge (read-only in workers)
    
    Parameters
    ----------
    ctx : RuntimeCtx
        Must have ctx.cache (SharedDiskCache) and ctx.grad_cfg (GradientConfig)
    agent_i : Agent
        Receiver agent (modified in-place: grad_mu_*, grad_sigma_*)
    agents : list[Agent]
        All agents at this level (for neighbors)
    mode : str
        "belief" or "model"
    
    Returns
    -------
    delta_mu : ndarray (*S, K)
        Natural gradient step for μ
    delta_S : ndarray (*S, K, K)
        Natural gradient step for Σ
    energy_tuple : (float, float)
        (self_raw, feedback_raw) energy contributions
    """
    if ctx is None:
        raise RuntimeError("accumulate_mu_sigma_gradient: ctx required")
    
    # Extract frozen config (built once in master, passed to workers)
    if hasattr(ctx, 'grad_cfg') and ctx.grad_cfg is not None:
        cfg = ctx.grad_cfg
    else:
        # Fallback: build on-the-fly (master process)
        cfg = GradientConfig.from_context(ctx)
    
    # Fiber-specific keys
    which, mu_key, S_key, gmu_key, gS_key = _fiber_keys_from_mode(mode)
    
    # Initialize accumulator
    mu_i = np.asarray(getattr(agent_i, mu_key), np.float32)
    accum = create_gradient_accum(mu_i.shape)
    
    # ========== PHASE 1: Self + Feedback ==========
    self_raw, fb_raw, dmu_self, dS_self, dmu_fb, dS_fb = \
        compute_self_feedback_pure(ctx, agent_i, cfg, mode)
    
    add_gradient_term(accum, "self", dmu_self, dS_self, weight=cfg.alpha)
    add_gradient_term(accum, "feedback", dmu_fb, dS_fb, weight=cfg.feedback_weight)
    
    # ========== PHASE 2: Alignment (β·KL) ==========
    dmu_align, dS_align, send_align = compute_alignment_gradients_pure(
        ctx, agent_i, agents, cfg, which, mu_key, S_key
    )
    add_gradient_term(accum, "align", dmu_align, dS_align)
    
    # ========== PHASE 3: Gamma (γ·KL) ==========
    dmu_gamma, dS_gamma, send_gamma = compute_gamma_gradients_pure(
        ctx, agent_i, agents, cfg, which, mu_key, S_key
    )
    add_gradient_term(accum, "gamma", dmu_gamma, dS_gamma)
    
    # ========== PHASE 4: Sender Inbox (if enabled) ==========
    if cfg.accumulate_sender_grads:
        dmu_inbox, dS_inbox = drain_inbox_pure(agent_i, which)
        add_gradient_term(accum, "inbox", dmu_inbox, dS_inbox)
    
    # ========== PHASE 5: Natural Projection ==========
    delta_mu, delta_S = apply_natural_gradient_batch(
        ctx,
        getattr(agent_i, mu_key),
        getattr(agent_i, S_key),
        accum['mu'],
        accum['S'],
        mask=getattr(agent_i, "mask", None),
        assume_sanitized=True,
        grad_sigma_is_symmetric=True,
        use_float64=True,
    )
    
    # ========== PHASE 6: Accumulate to Agent (Side Effect) ==========
    _accumulate_into_agent(agent_i, gmu_key, gS_key, delta_mu, delta_S)
    
    return delta_mu, delta_S, (float(self_raw), float(fb_raw))


# ============================================================================
# Self + Feedback (Pure)
# ============================================================================

def compute_self_feedback_pure(ctx, agent_i, cfg, mode):
    """
    Compute self and feedback gradients using cached pushes.
    
    Returns
    -------
    self_raw : float
        Self energy contribution
    fb_raw : float
        Feedback energy contribution
    dmu_self : ndarray
    dS_self : ndarray
    dmu_fb : ndarray
    dS_fb : ndarray
    """
    # Get fields
    mu_q = agent_i.mu_q_field
    S_q = agent_i.sigma_q_field
    mu_p = agent_i.mu_p_field
    S_p = agent_i.sigma_p_field
    
    # Get cached pushes (process-safe via SharedDiskCache)
    mu_q_push, S_q_push, inv_q_push = get_cached_push_forward(ctx, agent_i, eps=cfg.eps)
    mu_p_push, S_p_push, inv_p_push = get_cached_push_backward(ctx, agent_i, eps=cfg.eps)
    
    # Precompute inverses if not cached
    sigma_q_inv = getattr(agent_i, "sigma_q_inv", None)
    if sigma_q_inv is None:
        sigma_q_inv = safe_inv(sanitize_sigma(S_q, eps=cfg.eps), eps=cfg.eps)
    
    sigma_p_inv = getattr(agent_i, "sigma_p_inv", None)
    if sigma_p_inv is None:
        sigma_p_inv = safe_inv(sanitize_sigma(S_p, eps=cfg.eps), eps=cfg.eps)
    
    # Energy accounting (for diagnostics)
    mask = getattr(agent_i, "mask", None)
    if mask is not None:
        mm = (np.asarray(mask) > cfg.tau)
        if np.any(mm):
            self_kl = kl_gaussian(mu_q[mm], S_q[mm], mu_p_push[mm], S_p_push[mm], eps=cfg.eps)
            fb_kl = kl_gaussian(mu_p[mm], S_p[mm], mu_q_push[mm], S_q_push[mm], eps=cfg.eps)
            self_raw = float(np.sum(self_kl))
            fb_raw = float(np.sum(fb_kl))
        else:
            self_raw, fb_raw = 0.0, 0.0
    else:
        self_raw, fb_raw = 0.0, 0.0
    
    # Gradients
    if mode == "belief":
        dmu_self, dS_self = grad_self_energy_belief(
            mu_q, S_q, mu_p_push, inv_p_push,
            sigma_q_inv=sigma_q_inv, mask=mask
        )
        dmu_fb, dS_fb = grad_feedback_energy_belief(
            mu_q, S_q, mu_p, mu_q_push,
            S_q_push, inv_q_push, S_p, Phi_cached(ctx, agent_i, kind="q_to_p")
        )
    else:  # model
        from core.transport_cache import Phi_cached
        Phi_tilde = Phi_cached(ctx, agent_i, kind="p_to_q")
        dmu_self, dS_self = grad_self_energy_model(
            mu_q, S_q, mu_p_push, inv_p_push, Phi_tilde, mask=mask
        )
        dmu_fb, dS_fb = grad_feedback_energy_model(
            mu_p, S_p, mu_q_push, S_q_push, inv_q_push,
            sigma_p_inv=sigma_p_inv
        )
    
    return self_raw, fb_raw, dmu_self, dS_self, dmu_fb, dS_fb


# ============================================================================
# Alignment Block (Pure)
# ============================================================================

def compute_alignment_gradients_pure(ctx, agent_i, agents, cfg, which, mu_key, S_key):
    """
    β-weighted alignment gradients with exact softmax product rule.
    
    Returns
    -------
    dmu_align : ndarray (*S, K)
    dS_align : ndarray (*S, K, K)
    send_list : list[(neighbor_id, dmu, dS, overlap)]
        Sender contributions for master reduction
    """
    from beta import beta_align_maps
    
    # Precompute receiver stats
    mu_i_arr = np.asarray(getattr(agent_i, mu_key), np.float32, order="C")
    S_i_arr = sanitize_sigma(np.asarray(getattr(agent_i, S_key), np.float64), eps=cfg.eps) \
        .astype(np.float32, copy=False)
    
    Sshape = tuple(mu_i_arr.shape[:-1])
    Ki = int(mu_i_arr.shape[-1])
    
    dmu_align = np.zeros_like(mu_i_arr, dtype=np.float32)
    dS_align = np.zeros_like(S_i_arr, dtype=np.float32)
    
    # Bar terms for softmax rule
    gbar_mu_i = np.zeros(Sshape + (Ki,), np.float32)
    gbar_S_i = np.zeros(Sshape + (Ki, Ki), np.float32)
    
    pairs = []
    send_list = []
    
    # First pass: collect gradients and bar terms
    for agent_j, overlap in iter_overlap_pairs(agent_i, agents, cfg.tau, which, mu_key, ctx):
        if not np.any(overlap):
            continue
        
        # Get β/KL maps (pre-computed on master)
        KL1_map, beta_map = beta_align_maps(ctx, agent_i, agent_j, which=which)
        
        m = overlap.astype(np.float32, copy=False)
        beta_ij = beta_map * m
        KL1 = KL1_map * m
        
        if not np.any(beta_ij > 0):
            continue
        
        # Transport
        Om_align = Omega(ctx, agent_i, agent_j, which=which)
        
        mu_j_arr = np.asarray(getattr(agent_j, mu_key), np.float32, order="C")
        S_j_arr = sanitize_sigma(np.asarray(getattr(agent_j, S_key), np.float64), eps=cfg.eps) \
            .astype(np.float32, copy=False)
        
        mu_j_t, _, S_j_t_inv = push_gaussian(
            mu_j_arr, S_j_arr, Om_align, eps=cfg.eps, return_inv=True, sanitize_input=False
        )
        
        # Receiver gradient
        gmu_align, gS_align = grad_alignment_energy_source(
            mu_i_arr, S_i_arr, mu_j_t, S_j_t_inv, eps=cfg.eps,
            sigma_i_inv=None, assume_sanitized=True
        )
        
        # Sender gradient
        gmu_align_j, gS_align_j = grad_alignment_energy_target(
            mu_i=mu_i_arr, sigma_i=S_i_arr,
            mu_j_t=mu_j_t, sigma_j_t_inv=S_j_t_inv,
            Omega_ij=Om_align, eps=cfg.eps, assume_sanitized=True
        )
        
        # Accumulate bar terms
        gbar_mu_i += beta_ij[..., None] * gmu_align
        gbar_S_i += beta_ij[..., None, None] * gS_align
        
        pairs.append({
            'j': agent_j,
            'j_id': int(getattr(agent_j, 'id', -1)),
            'overlap': overlap,
            'beta_ij': beta_ij,
            'KL1': KL1,
            'gmu_align': gmu_align,
            'gS_align': gS_align,
            'gmu_align_j': gmu_align_j,
            'gS_align_j': gS_align_j,
        })
    
    # Second pass: apply softmax rule
    kappa = max(float(cfg.beta_kappa_q if which == "q" else cfg.beta_kappa_p), 1e-12)
    
    for P in pairs:
        # Receiver contribution
        add_mu_i = softmax_align_rule_receiver(
            P['beta_ij'], P['KL1'], kappa, P['gmu_align'], gbar_mu_i
        )
        add_S_i = softmax_align_rule_receiver(
            P['beta_ij'], P['KL1'], kappa, P['gS_align'], gbar_S_i
        )
        
        dmu_align[P['overlap']] += add_mu_i[P['overlap']]
        dS_align[P['overlap']] += add_S_i[P['overlap']]
        
        # Sender contribution (for master reduction)
        if cfg.accumulate_sender_grads:
            add_mu_j = softmax_align_rule_sender(
                P['beta_ij'], P['KL1'], kappa, P['gmu_align_j']
            )
            add_S_j = softmax_align_rule_sender(
                P['beta_ij'], P['KL1'], kappa, P['gS_align_j']
            )
            send_list.append((P['j_id'], add_mu_j, add_S_j, P['overlap']))
    
    # Sanity
    assert np.all(np.isfinite(dmu_align)) and np.all(np.isfinite(dS_align)), \
        "β-align NaN/Inf"
    
    return dmu_align, dS_align, send_list


# ============================================================================
# Gamma Block (Pure)
# ============================================================================

def compute_gamma_gradients_pure(ctx, agent_i, agents, cfg, which, mu_key, S_key):
    """
    γ-weighted gating gradients with plain product rule.
    
    Returns
    -------
    dmu_gamma : ndarray (*S, K)
    dS_gamma : ndarray (*S, K, K)
    send_list : list[(neighbor_id, dmu, dS, overlap)]
    """
    from beta import gamma_maps
    from updates.update_terms_mu_sigma import grad_gamma_mu_sigma_dispatch
    
    # Config toggles
    use_A = cfg.use_gamma_A_q if which == "q" else cfg.use_gamma_A_p
    use_B = cfg.use_gamma_B_q if which == "q" else cfg.use_gamma_B_p
    kap = cfg.kappa_gamma_q if which == "q" else cfg.kappa_gamma_p
    
    if not (use_A or use_B):
        mu_i = getattr(agent_i, mu_key)
        return (np.zeros_like(mu_i), 
                np.zeros_like(getattr(agent_i, S_key)), 
                [])
    
    # Init
    mu_i_arr = np.asarray(getattr(agent_i, mu_key), np.float32, order="C")
    S_i_arr = np.asarray(getattr(agent_i, S_key), np.float32, order="C")
    
    dmu_G = np.zeros_like(mu_i_arr, dtype=np.float32)
    dS_G = np.zeros_like(S_i_arr, dtype=np.float32)
    send_list = []
    
    # Gather entries per case
    entries_A = []
    entries_B = []
    
    # Pre-fetch receiver Φ
# Pre-fetch receiver Φ
    from core.transport_cache import Phi_cached
    Phi_i = Phi_cached(ctx, agent_i, kind="q_to_p") if which == "q" else None
    Phi_tilde_i = Phi_cached(ctx, agent_i, kind="p_to_q") if which == "p" else None
    
    Omega_q = {}  # Cache Ω_ij per neighbor
    
    for agent_j, overlap in iter_overlap_pairs(agent_i, agents, cfg.tau, which, mu_key, ctx):
        if not np.any(overlap):
            continue
        
        # Cache Ω for this pair
        j_id = int(getattr(agent_j, 'id', -1))
        Om_q_ij = Omega_q.get(j_id)
        if Om_q_ij is None:
            Om_q_ij = Omega(ctx, agent_i, agent_j, which="q")
            Omega_q[j_id] = Om_q_ij
        
        # Get γ maps (pre-computed on master)
        gam = gamma_maps(ctx, agent_i, agent_j)
        if not gam:
            continue
        
        m = overlap.astype(np.float32, copy=False)
        
        # Case A
        if use_A and ("A" in gam):
            KLc, Gc = gam["A"]
            outA = grad_gamma_mu_sigma_dispatch(
                ctx, agent_i, agent_j,
                basis="a",
                Omega_ij=Om_q_ij,
                Phi_i=Phi_i,
                Phi_tilde_i=Phi_tilde_i,
                eps=cfg.eps,
            )
            
            w = (np.asarray(Gc, np.float32) * m).astype(np.float32, copy=False)
            K = (np.asarray(KLc, np.float32) * m).astype(np.float32, copy=False)
            
            if cfg.gamma_cap > 0.0:
                w = np.clip(w, 0.0, cfg.gamma_cap)
            
            entries_A.append({
                'w': w, 'K': K, 'overlap': overlap,
                'j_id': j_id,
                'mu_rec': np.asarray(outA["mu_rec"], np.float32, order="C"),
                'S_rec': np.asarray(outA["S_rec"], np.float32, order="C"),
                'mu_send': np.asarray(outA["mu_send"], np.float32, order="C"),
                'S_send': np.asarray(outA["S_send"], np.float32, order="C"),
            })
        
        # Case B
        if use_B and ("B" in gam):
            KLc, Gc = gam["B"]
            outB = grad_gamma_mu_sigma_dispatch(
                ctx, agent_i, agent_j,
                basis="b",
                Omega_ij=Om_q_ij,
                Phi_i=Phi_i,
                Phi_tilde_i=Phi_tilde_i,
                eps=cfg.eps,
            )
            
            w = (np.asarray(Gc, np.float32) * m).astype(np.float32, copy=False)
            K = (np.asarray(KLc, np.float32) * m).astype(np.float32, copy=False)
            
            if cfg.gamma_cap > 0.0:
                w = np.clip(w, 0.0, cfg.gamma_cap)
            
            entries_B.append({
                'w': w, 'K': K, 'overlap': overlap,
                'j_id': j_id,
                'mu_rec': np.asarray(outB["mu_rec"], np.float32, order="C"),
                'S_rec': np.asarray(outB["S_rec"], np.float32, order="C"),
                'mu_send': np.asarray(outB["mu_send"], np.float32, order="C"),
                'S_send': np.asarray(outB["S_send"], np.float32, order="C"),
            })
    
    # Optional normalization per-receiver
    def _normalize_entries(entries, mode, cap_val):
        if (not cfg.normalize_gamma) or (not entries):
            return [e["w"] for e in entries]
        W = np.stack([e["w"] for e in entries], axis=-1)
        Ssum = np.sum(W, axis=-1, keepdims=True)
        eps_ = 1e-6
        if mode == "rowsum":
            Wn = W / (Ssum + eps_)
        else:  # "sumcap"
            scale = np.minimum(1.0, cap_val / (Ssum + eps_))
            Wn = W * scale
        return [Wn[..., j] for j in range(Wn.shape[-1])]
    
    wA_norm = _normalize_entries(entries_A, cfg.gamma_norm_mode, cfg.gamma_sumcap)
    wB_norm = _normalize_entries(entries_B, cfg.gamma_norm_mode, cfg.gamma_sumcap)
    
    # Accumulate with plain rule
    def _accumulate(entries, w_norm_list):
        nonlocal dmu_G, dS_G
        for e, w_norm in zip(entries, w_norm_list):
            w = np.asarray(w_norm, np.float32, order="C")
            K = np.asarray(e["K"], np.float32, order="C")
            
            add_mu_i = plain_rule(w, K, kap, e["mu_rec"])
            add_S_i = plain_rule(w, K, kap, e["S_rec"])
            dmu_G += add_mu_i
            dS_G += add_S_i
            
            if cfg.accumulate_sender_grads:
                add_mu_j = plain_rule(w, K, kap, e["mu_send"])
                add_S_j = plain_rule(w, K, kap, e["S_send"])
                send_list.append((e['j_id'], add_mu_j, add_S_j, e['overlap']))
    
    _accumulate(entries_A, wA_norm)
    _accumulate(entries_B, wB_norm)
    
    # Sanity
    assert np.all(np.isfinite(dmu_G)) and np.all(np.isfinite(dS_G)), "γ NaN/Inf"
    
    return dmu_G, dS_G, send_list


# ============================================================================
# Sender Inbox Drain (Pure)
# ============================================================================

def drain_inbox_pure(agent, which):
    """
    Drain accumulated sender contributions from agent's inbox.
    
    Returns
    -------
    dmu : ndarray (*S, K)
    dS : ndarray (*S, K, K)
    """
    inbox_key = f"_inbox_{which}"
    inbox = getattr(agent, inbox_key, None)
    
    if inbox is None or not inbox:
        mu = getattr(agent, f"mu_{which}_field")
        S = getattr(agent, f"sigma_{which}_field")
        return np.zeros_like(mu), np.zeros_like(S)
    
    dmu_total = inbox.get('mu', None)
    dS_total = inbox.get('S', None)
    
    # Clear inbox after draining
    setattr(agent, inbox_key, {'mu': None, 'S': None})
    
    if dmu_total is None:
        mu = getattr(agent, f"mu_{which}_field")
        dmu_total = np.zeros_like(mu)
    if dS_total is None:
        S = getattr(agent, f"sigma_{which}_field")
        dS_total = np.zeros_like(S)
    
    return np.asarray(dmu_total, np.float32), np.asarray(dS_total, np.float32)


# ============================================================================
# Helper: Fiber Keys
# ============================================================================

def _fiber_keys_from_mode(mode):
    """
    Extract fiber-specific attribute names from mode.
    
    Returns
    -------
    which : str ("q" or "p")
    mu_key : str
    S_key : str
    gmu_key : str
    gS_key : str
    """
    if mode == "belief":
        return "q", "mu_q_field", "sigma_q_field", "grad_mu_q", "grad_sigma_q"
    elif mode == "model":
        return "p", "mu_p_field", "sigma_p_field", "grad_mu_p", "grad_sigma_p"
    else:
        raise ValueError(f"Unknown mode: {mode}")


def _accumulate_into_agent(agent, gmu_key, gS_key, delta_mu, delta_S):
    """
    Side effect: accumulate gradients into agent attributes.
    """
    prev_mu = getattr(agent, gmu_key, None)
    prev_S = getattr(agent, gS_key, None)
    
    if prev_mu is None:
        setattr(agent, gmu_key, np.asarray(delta_mu, np.float32, copy=True))
    else:
        setattr(agent, gmu_key, np.asarray(prev_mu, np.float32) + np.asarray(delta_mu, np.float32))
    
    if prev_S is None:
        setattr(agent, gS_key, np.asarray(delta_S, np.float32, copy=True))
    else:
        setattr(agent, gS_key, np.asarray(prev_S, np.float32) + np.asarray(delta_S, np.float32))


# ============================================================================
# KEEP EXISTING GRADIENT FUNCTIONS (grad_self_energy_belief, etc.)
# These are already process-safe - they're pure numpy functions
# ============================================================================

# ... (keep all your existing grad_*_energy_* functions unchanged) ...

def compute_all_gradients(agent_i, agents, all_agents, generators_q, generators_p, runtime_ctx=None):
    """
    UPDATED: Uses grad_cfg from context (pre-built, frozen, picklable).
    """
    ctx = runtime_ctx
    
    # Ensure grad_cfg exists (built once on master, passed to workers)
    if not hasattr(ctx, 'grad_cfg') or ctx.grad_cfg is None:
        from grad_config import GradientConfig
        ctx.grad_cfg = GradientConfig.from_context(ctx)
    
    # NEW: per-agent energy accumulators (local to worker)
    self_sum_raw = 0.0
    fb_sum_raw = 0.0
    
    # Reset grads
    zero_all_gradients(agent_i)
    timings = {}
    
    # -------- Phase 1: μ, Σ (SIMPLIFIED with new API) --------
    t0 = time.perf_counter()
    _, _, (self_bel, fb_bel) = accumulate_mu_sigma_gradient(
        ctx, agent_i, agents, mode="belief"
    )
    timings["mu_sigma_belief"] = time.perf_counter() - t0
    
    t0 = time.perf_counter()
    _, _, (self_mod, fb_mod) = accumulate_mu_sigma_gradient(
        ctx, agent_i, agents, mode="model"
    )
    timings["mu_sigma_model"] = time.perf_counter() - t0
    
    # Energy tallies
    self_sum_raw = float(self_bel + self_mod)
    fb_sum_raw = float(fb_bel + fb_mod)
    
    # -------- Phase 2: neighbors --------
    t0 = time.perf_counter()
    neighbors = get_neighbors(agent_i, agents)
    timings["neighbors"] = time.perf_counter() - t0
    
    recv_phi = np.zeros_like(agent_i.phi, dtype=np.float32)
    recv_phi_tilde = np.zeros_like(agent_i.phi_model, dtype=np.float32)
    send_phi = []
    send_phi_tilde = []
    
    if neighbors:
        neighbors = sorted(neighbors, key=lambda a: int(getattr(a, "id", -1)))
        
        # φ phase
        _res = _run_phi_phase(
            ctx, agent_i, neighbors,
            field="phi",
            generators_q=generators_q, generators_p=generators_p,
            fisher_inv_key=_FIELD_META["phi"]["fisher_inv_key"],
            grad_key=_FIELD_META["phi"]["grad_key"],
            phi_self_func=grad_self_phi_direct,
            phi_feedback_func=grad_feedback_phi_direct,
            timings=timings, prefix="phi",
        )
        if isinstance(_res, tuple) and len(_res) == 3:
            r, s, (self_raw_phi, fb_raw_phi) = _res
            self_sum_raw += float(self_raw_phi)
            fb_sum_raw += float(fb_raw_phi)
        else:
            r, s = _res
        recv_phi = np.asarray(r, np.float32)
        send_phi = [(int(getattr(aj, "id", -1)), np.asarray(dphi_j, np.float32)) 
                    for (aj, dphi_j) in (s or [])]
        
        # φ~ phase
        _res = _run_phi_phase(
            ctx, agent_i, neighbors,
            field="phi_model",
            generators_q=generators_q, generators_p=generators_p,
            fisher_inv_key=_FIELD_META["phi_model"]["fisher_inv_key"],
            grad_key=_FIELD_META["phi_model"]["grad_key"],
            phi_self_func=grad_self_phi_tilde_direct,
            phi_feedback_func=grad_feedback_phi_tilde_direct,
            timings=timings, prefix="phi_tilde",
        )
        if isinstance(_res, tuple) and len(_res) == 3:
            r, s, (self_raw_t, fb_raw_t) = _res
            self_sum_raw += float(self_raw_t)
            fb_sum_raw += float(fb_raw_t)
        else:
            r, s = _res
        recv_phi_tilde = np.asarray(r, np.float32)
        send_phi_tilde = [(int(getattr(aj, "id", -1)), np.asarray(dphi_j, np.float32)) 
                         for (aj, dphi_j) in (s or [])]
    
    dtheta_i = None
    ener_tuple = (int(getattr(agent_i, "id", -1)), float(self_sum_raw), float(fb_sum_raw))
    
    return (
        (agent_i.grad_mu_q, agent_i.grad_sigma_q),
        (agent_i.grad_mu_p, agent_i.grad_sigma_p),
        recv_phi,
        recv_phi_tilde,
        dtheta_i,
        send_phi,
        send_phi_tilde,
        ener_tuple,
    )


def worker_entry(ctx_view, Ai, agents, all_agents, Gq, Gp):
    """
    UPDATED: Ensures grad_cfg is available in worker.
    """
    from runtime_context import ensure_shared_cache_attached
    
    ctx = ensure_shared_cache_attached(ctx_view)
    
    # Verify grad_cfg exists (should be in ctx_view already)
    assert hasattr(ctx, 'grad_cfg'), "grad_cfg missing in worker context"
    
    with threadpool_limits(1):
        return compute_all_gradients(Ai, agents, all_agents, Gq, Gp, runtime_ctx=ctx)