# -*- coding: utf-8 -*-
"""
Created on Tue Oct 21 21:46:38 2025

@author: chris and christine
"""

# test_loky_gradients.py
"""
Test that refactored gradients work in multiprocessing.
"""
import numpy as np
from runtime_context import RuntimeCtx, ensure_runtime_defaults, ctx_view_for_workers, ensure_shared_cache_attached
from grad_config import GradientConfig
from updates.update_terms_mu_sigma import accumulate_mu_sigma_gradient
from joblib import Parallel, delayed
import tempfile
import os


def test_gradient_config_picklable():
    """Test that GradientConfig can be pickled."""
    import pickle
    
    cfg = GradientConfig(
        eps=1e-7,
        alpha=0.5,
        feedback_weight=0.3,
    )
    
    # Should pickle without error
    data = pickle.dumps(cfg)
    cfg2 = pickle.loads(data)
    
    assert cfg == cfg2
    assert hash(cfg) == hash(cfg2)
    print("✓ GradientConfig is picklable")


def test_ctx_view_picklable():
    """Test that ctx_view_for_workers is picklable."""
    import pickle
    
    ctx = ensure_runtime_defaults(None)
    ctx.global_step = 42
    ctx.config = {"eps": 1e-7, "alpha": 0.5}
    
    view = ctx_view_for_workers(ctx)
    
    # Should pickle without error
    data = pickle.dumps(view)
    view2 = pickle.loads(data)
    
    assert view2.global_step == 42
    assert hasattr(view2, 'grad_cfg')
    print("✓ ctx_view is picklable")


def test_parallel_gradient_computation():
    """Test gradient computation in parallel workers."""
    from shared_cache import SharedDiskCache
    
    # Setup context with shared cache
    with tempfile.TemporaryDirectory() as tmpdir:
        ctx = ensure_runtime_defaults(None)
        ctx.config = {
            "shared_cache_dir": tmpdir,
            "eps": 1e-7,
            "alpha": 0.5,
            "feedback_weight": 0.3,
            "support_tau": 1e-6,
        }
        ctx.cache = SharedDiskCache(tmpdir)
        ctx.global_step = 0
        
        # Build grad_cfg
        ctx.grad_cfg = GradientConfig.from_context(ctx)
        
        # Create minimal test agents
        from types import SimpleNamespace
        agents = []
        for i in range(3):
            a = SimpleNamespace(
                id=i,
                spatial_shape=(10, 10),
                mask=np.ones((10, 10), np.float32),
                mu_q_field=np.random.randn(10, 10, 5).astype(np.float32),
                sigma_q_field=np.tile(np.eye(5, dtype=np.float32), (10, 10, 1, 1)),
                mu_p_field=np.random.randn(10, 10, 5).astype(np.float32),
                sigma_p_field=np.tile(np.eye(5, dtype=np.float32), (10, 10, 1, 1)),
                sigma_q_inv=np.tile(np.eye(5, dtype=np.float32), (10, 10, 1, 1)),
                sigma_p_inv=np.tile(np.eye(5, dtype=np.float32), (10, 10, 1, 1)),
                phi=np.zeros((10, 10, 3), np.float32),
                phi_model=np.zeros((10, 10, 3), np.float32),
            )
            agents.append(a)
        
        # Worker function
        def worker_func(ctx_view, agent, all_agents):
            ctx_local = ensure_shared_cache_attached(ctx_view)
            
            # This should work without errors
            dmu, dS, (self_e, fb_e) = accumulate_mu_sigma_gradient(
                ctx_local, agent, all_agents, mode="belief"
            )
            
            return {
                'id': agent.id,
                'dmu_shape': dmu.shape,
                'dS_shape': dS.shape,
                'self_energy': self_e,
                'fb_energy': fb_e,
            }
        
        # Run in parallel
        view = ctx_view_for_workers(ctx)
        results = Parallel(n_jobs=2, backend="loky")(
            delayed(worker_func)(view, a, agents) for a in agents
        )
        
        # Verify
        assert len(results) == 3
        for r in results:
            assert r['dmu_shape'] == (10, 10, 5)
            assert r['dS_shape'] == (10, 10, 5, 5)
            assert np.isfinite(r['self_energy'])
            assert np.isfinite(r['fb_energy'])
        
        print(f"✓ Parallel gradient computation successful: {len(results)} workers")


if __name__ == "__main__":
    test_gradient_config_picklable()
    test_ctx_view_picklable()
    test_parallel_gradient_computation()
    print("\n✓✓✓ All loky compatibility tests passed!")