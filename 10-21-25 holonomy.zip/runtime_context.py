# -*- coding: utf-8 -*-
from __future__ import annotations

from dataclasses import dataclass, field, asdict
from typing import Any, Dict, List, Optional, Literal
import numpy as np
import hashlib
from updates.update_helpers import dirty_manager
import threading
from dataclasses import is_dataclass
from types import SimpleNamespace
from dataclasses import dataclass
from typing import Tuple, Sequence




Fiber = Literal["q", "p"]

# ─────────────────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────────────────

def _shape_sig(a):
    return tuple(int(x) for x in np.asarray(a).shape)

def _arr_digest(a: np.ndarray, *, tol: float | None = None) -> str:
    a = np.asarray(a, np.float32)
    if tol and tol > 0:
        b = (np.round(a / tol) * tol).tobytes()
    else:
        b = a.tobytes()
    return hashlib.sha256(b).hexdigest()



# runtime_context.py (ADDITIONS)

def ctx_view_for_workers(ctx):
    """
    UPDATED: Include PhiGradientConfig for φ computations.
    """
    from new.grad_config import GradientConfig, PhiGradientConfig
    
    cfg = _to_plain_dict(getattr(ctx, "config", {}))
    fields = _to_plain_dict(getattr(ctx, "fields", {}))
    step_cfg = _to_plain_dict(getattr(ctx, "step_cfg", {}))
    
    # Pre-build frozen configs
    grad_cfg = GradientConfig.from_context(ctx)
    phi_grad_cfg = PhiGradientConfig.from_context(ctx)
    
    return SimpleNamespace(
        config=cfg,
        fields=fields,
        step_cfg=step_cfg,
        grad_cfg=grad_cfg,           # μ/Σ gradients
        phi_grad_cfg=phi_grad_cfg,   # φ/φ~ gradients
        global_step=int(getattr(ctx, "global_step", 0)),
    )


def ensure_shared_cache_attached(ctx_view):
    """
    UPDATED: Preserve both gradient configs.
    """
    from shared_cache import SharedDiskCache
    from new.grad_config import GradientConfig, PhiGradientConfig
    
    cache_dir = (getattr(ctx_view, "config", {}) or {}).get(
        "shared_cache_dir", "./_shared_cache"
    )
    ctx_view.cache = SharedDiskCache(cache_dir)
    
    # Ensure configs exist
    if not hasattr(ctx_view, 'grad_cfg'):
        ctx_view.grad_cfg = GradientConfig.from_context(ctx_view)
    if not hasattr(ctx_view, 'phi_grad_cfg'):
        ctx_view.phi_grad_cfg = PhiGradientConfig.from_context(ctx_view)
    
    return ctx_view


# ─────────────────────────────────────────────────────────────────────────────
# Edge maps (unified API for β / KL / γ)
# ─────────────────────────────────────────────────────────────────────────────


@dataclass
class EdgeMaps:
    """
    Unified, fiber-aware per-edge storage:
      - beta[(which,i,j)]  : β_ij(*S,) float32
      - kl1[(which,i,j)]   : ALIGN KL(*S,) float32
      - kl_basis[(basis,i,j)] : KL for A/B/C/D/align_{q,p} if you add them later
      - gamma[(case,i,j)]  : γ maps where case ∈ {"A","B"}
      - klX[(case,i,j)]    : KL behind γ (diagnostics)

    Back-compat mirrors are kept on the ctx (ctx._edge_beta, ctx._edge_kl1, ctx._edge_gamma, ctx._edge_klX)
    so legacy readers continue to work during the transition.
    """
    beta: Dict[tuple, np.ndarray] = field(default_factory=dict)
    kl1: Dict[tuple, np.ndarray] = field(default_factory=dict)
    kl_basis: Dict[tuple, np.ndarray] = field(default_factory=dict)
    gamma: Dict[tuple, np.ndarray] = field(default_factory=dict)
    klX: Dict[tuple, np.ndarray] = field(default_factory=dict)

    # ---- clears ----
    def clear_all(self):
        self.beta.clear(); self.kl1.clear(); self.kl_basis.clear(); self.gamma.clear(); self.klX.clear()

    def clear_fiber(self, which: str):
        which = str(which)
        self.beta  = {k:v for k,v in self.beta.items()  if k and k[0] != which}
        self.kl1   = {k:v for k,v in self.kl1.items()   if k and k[0] != which}
        # kl_basis keyed by textual basis (e.g., "A","B","align_q"), leave alone here

    # ---- setters (keep legacy mirrors for now) ----
    def set_align(self, ctx, which: str, i_id: int, j_id: int, *, kl, beta):
        key = (str(which), int(i_id), int(j_id))
        self.kl1[key]  = np.asarray(kl,   np.float32, order="C")
        self.beta[key] = np.asarray(beta, np.float32, order="C")
        if not hasattr(ctx, "_edge_kl1") or ctx._edge_kl1 is None:  ctx._edge_kl1 = {}
        if not hasattr(ctx, "_edge_beta") or ctx._edge_beta is None: ctx._edge_beta = {}
        ctx._edge_kl1[key]  = self.kl1[key]
        ctx._edge_beta[key] = self.beta[key]

    def set_gamma(self, ctx, case: str, a_id: int, b_id: int, *, gamma_map, kl_map=None):
        key = (str(case), int(a_id), int(b_id))
        self.gamma[key] = np.asarray(gamma_map, np.float32, order="C")
        if kl_map is not None:
            self.klX[key] = np.asarray(kl_map, np.float32, order="C")
        if not hasattr(ctx, "_edge_gamma") or ctx._edge_gamma is None: ctx._edge_gamma = {}
        if not hasattr(ctx, "_edge_klX") or ctx._edge_klX is None:     ctx._edge_klX   = {}
        ctx._edge_gamma[key] = self.gamma[key]
        if kl_map is not None:
            ctx._edge_klX[key] = self.klX[key]

    # ---- getters (preferred read path) ----
    def get_align(self, ctx, which: str, i_id: int, j_id: int, *, shape) -> tuple[np.ndarray, np.ndarray]:
        """
        Returns (beta_ij, KL1_ij) each shaped `shape` and float32.
        Provides zero maps if missing.
        """
        key = (str(which), int(i_id), int(j_id))
        B = self.beta.get(key); K = self.kl1.get(key)
        if B is None or K is None:
            z = np.zeros(tuple(shape), np.float32)
            return z, z
        return np.asarray(B, np.float32), np.asarray(K, np.float32)


    def get_gamma(self, ctx, case: str, a_id: int, b_id: int, *, shape) -> tuple[np.ndarray, np.ndarray]:
        """
        Returns (gamma_map, KL_map) shaped `shape`; if KL is missing, returns zeros.
        """
        key = (str(case), int(a_id), int(b_id))
        G = self.gamma.get(key)
        K = self.klX.get(key)
        z = np.zeros(tuple(shape), np.float32)
    
        if G is None:
            # No gamma written: return zeros for both to keep callers simple
            return z, z
    
        G = np.asarray(G, np.float32)
        if K is None:
            # Gamma exists but KL wasn’t stored (e.g., off-overlap): return zeros KL
            return G, z
    
        # Both exist
        return G, np.asarray(K, np.float32)



# ─────────────────────────────────────────────────────────────────────────────
# Cache hub
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class CacheHub:
    step_tag: int = -1
    spaces: Dict[str, Dict[Any, Any]] = field(default_factory=lambda: {
        "exp": {}, "omega": {}, "morphism": {}, "fisher": {}, "misc": {}, "jinv": {}
    })
    persist: Dict[str, Dict[Any, Any]] = field(default_factory=lambda: {
        "morph_base": {}
    })
    hits: int = 0
    misses: int = 0
    invalidations: int = 0

    def ns(self, name: str) -> Dict[Any, Any]:
        return self.spaces.setdefault(name, {})

    def nsp(self, name: str) -> Dict[Any, Any]:
        return self.persist.setdefault(name, {})

    def clear_on_step(self, step: int) -> None:
        if step != self.step_tag:
            for d in self.spaces.values():
                d.clear()
            self.step_tag = step

    def stats(self) -> Dict[str, int]:
        return {k: len(v) for k, v in self.spaces.items()}

    def key_E(self, *, agent_id: int, step: int, phi: np.ndarray,
          cfg: dict, wrap_flag: bool, tol: float | None = None,
          gensig: tuple | None = None):
        """
        E-cache key; includes optional generator signature to disambiguate reps.
        gensig should be a small tuple like (K, 'sha256hex') or None.
        """
        return ("E", int(agent_id), int(step),
                _shape_sig(phi), bool(wrap_flag),
                gensig, _arr_digest(phi, tol=tol))
    
    def key_Jinv(self, **kw):
        k = self.key_E(**kw)
        return ("Jinv",) + k[1:]
    
    def key_Omega(self, *, agent_i: int, agent_j: int, step: int,
                  phi_i: np.ndarray, phi_j: np.ndarray, cfg: dict,
                  wrap_flag: bool, tol: float | None = None,
                  gensig_i: tuple | None = None, gensig_j: tuple | None = None):
        """
        Omega-cache key; includes optional generator signatures for each endpoint.
        """
        di = _arr_digest(phi_i, tol=tol)
        dj = _arr_digest(phi_j, tol=tol)
        pair_sha = hashlib.sha256((di + "|" + dj).encode()).hexdigest()
        return ("Omega", int(agent_i), int(agent_j), int(step),
                _shape_sig(phi_i), bool(wrap_flag),
                gensig_i, gensig_j, pair_sha)


    def key_Fisher(self, *, agent_id: int, step: int,
                   mu: np.ndarray, Sigma: np.ndarray,
                   cfg: dict, which: str = "q", tol: float | None = None):
        mu  = np.asarray(mu,    np.float32)
        Sig = np.asarray(Sigma, np.float32)
        mu_sha  = _arr_digest(mu,  tol=tol)
        Sig_sha = _arr_digest(Sig, tol=tol)
        shape   = _shape_sig(Sig)
        return ("Fisher", which, int(agent_id), int(step),
                shape, mu_sha, Sig_sha)

    # ---- typed get/put with counters ----
    def get(self, ns_name: str, key):
        ns = self.ns(ns_name)
        val = ns.get(key)
        if val is None: self.misses += 1
        else:           self.hits += 1
        return val

    def put(self, ns_name: str, key, value):
        self.ns(ns_name)[key] = value

    def invalidate_like(self, ns_name: str, predicate):
        ns = self.ns(ns_name)
        todel = [k for k in list(ns.keys()) if predicate(k)]
        for k in todel:
            ns.pop(k, None)
        self.invalidations += len(todel)

    def full_stats(self) -> Dict[str, int]:
        out = self.stats()
        out.update({"hits": self.hits, "misses": self.misses, "invalidations": self.invalidations})
        return out

# ─────────────────────────────────────────────────────────────────────────────
# Neighbor graph (single level)
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class LevelGraph:
    level: int
    agent_ids: List[int]
    neighbors: Dict[int, List[int]] = field(default_factory=dict)  # id -> [neighbor ids]

# ─────────────────────────────────────────────────────────────────────────────
# Runtime context (single-scale)
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class RuntimeCtx:
    global_step: int = 0
    agents_by_level: Dict[int, Dict[int, Any]] = field(default_factory=dict)
    graphs: Dict[int, LevelGraph] = field(default_factory=dict)
    cache: CacheHub = field(default_factory=CacheHub)
    fields: Dict[str, Any] = field(default_factory=dict)
    step_cfg: Optional[StepSettings] = None   # <— add this
    edge: EdgeMaps = field(default_factory=EdgeMaps)     # <— unified per-edge state
    
    def register_agents(self, level: int, agents: List[Any]) -> None:
        lvl = self.agents_by_level.setdefault(level, {})
        lvl.clear()
        for a in agents:
            lvl[int(getattr(a, "id"))] = a

    def build_neighbors(self, level: int, neighbor_map: Dict[int, List[int]]) -> None:
        ids = list(self.agents_by_level.get(level, {}).keys())
        nm: Dict[int, List[int]] = {i: [j for j in neighbor_map.get(i, []) if j in ids] for i in ids}
        self.graphs[level] = LevelGraph(level=level, agent_ids=ids, neighbors=nm)

    def neighbors_of(self, level: int, agent_id: int) -> List[int]:
        g = self.graphs.get(level)
        return [] if not g else g.neighbors.get(int(agent_id), [])

    def agent(self, level: int, agent_id: int) -> Any:
        return self.agents_by_level[level][int(agent_id)]

    def agents(self, level: int) -> List[Any]:
        if level not in self.graphs:
            return list(self.agents_by_level.get(level, {}).values())
        g = self.graphs[level]
        return [self.agents_by_level[level][aid] for aid in g.agent_ids]

    def cache_stats(self) -> dict:
        return {} if not getattr(self, "cache", None) else self.cache.stats()





#=============================================================================
#
#           ENERGY LOGGER
#
#==========================================================================




#===================================================
#
#         CONFIG
#
#==================================================



@dataclass(frozen=True)
class StepSettings:
    # ===== Feature toggles / modes =====

    freeze_omega_mode: str         # "none" | "identity"


    # ===== Domain / graph / seeding =====
    D: int
    L: int
    steps: int
    N: int
    max_neighbors: int
    n_jobs: int
    agent_seed: int
    agent_radius_range: Tuple[int, int]
    fixed_location: bool
    domain_size: Tuple[int, ...]
    num_cores: int

    # ===== Generator specs =====
    ell_q: int
    ell_p: int
    spec_q: Sequence[Tuple[int, int]]
    spec_p: Sequence[Tuple[int, int]]
    mix_generators_q: bool
    mix_generators_p: bool

    # ===== Geometry / exp / connection =====
    use_global_A: bool
    A_compose_order: str
    exp_clip_max_norm: float
    phi_small_threshold: float
    sigma_jitter: float
    A_init_scale: float

    # ===== Masks / neighbors =====
    overlap_eps: float
    support_tau: float
    neighbors_symmetric: bool

    # ===== Couplings & penalties =====
    alpha: float
    beta: float
    
    feedback_weight: float
    beta_model: float
    
    lambda_A_curv: float
    lambda_A_cov: float
    

    # ===== Likelihood / observations =====
    obs_sigma2_true: float
    obs_dim: int
    sigma2_min: float

    # ===== Learning rates =====
    tau_phi: float
    tau_phi_model: float
    tau_mu_belief: float
    tau_sigma_belief: float
    tau_mu_model: float
    tau_sigma_model: float
    A_lr: float



    # ===== Initialization ranges / noise =====
    diagonal_sigma: bool
    identical_models: bool

    q_mu_range: Tuple[float, float]
    q_sigma_range: Tuple[float, float]
    
    p_mu_range: Tuple[float, float]
    p_sigma_range: Tuple[float, float]
    
    phi_init_smooth_sigma: float
    phi_init: float
    phi_model_offset: float
    

    # ===== Stability / clipping =====
    gradient_clip_phi: float
    gradient_clip_phi_model: float

    A_grad_clip: float

    # ===== Numerics / debug =====
    eps: float
    debug_phase_timing: bool
    debug_grad_timing: bool


def build_step_settings(config) -> StepSettings:
    # Convenience helpers (respecting your T/F aliases)
    def _b(name, default=False):
        return bool(getattr(config, name, default))
    def _i(name, default=0):
        return int(getattr(config, name, default))
    def _f(name, default=0.0):
        return float(getattr(config, name, default))
    def _s(name, default=""):
        return str(getattr(config, name, default))
    def _t(name, default):
        v = getattr(config, name, default)
        return tuple(v) if isinstance(v, (list, tuple)) else default
    def _seq(name, default=()):
        v = getattr(config, name, default)
        return tuple(tuple(x) for x in v) if isinstance(v, (list, tuple)) else tuple(default)

    return StepSettings(
        # ===== Feature toggles / modes =====

        freeze_omega_mode   = _s("freeze_omega_mode", "none"),


        # ===== Domain / graph / seeding =====
        D             = _i("D", 2),
        L             = _i("L", 14),
        steps         = _i("steps", 500),
        N             = _i("N", 3),
        max_neighbors = _i("max_neighbors", 3),
        n_jobs        = _i("n_jobs", _i("N", 3)),
        agent_seed    = _i("agent_seed", 0),
        agent_radius_range = _t("agent_radius_range", (3, 3)),
        fixed_location     = _b("fixed_location", False),
        domain_size   = _t("domain_size", (_i("L",14),) * _i("D",2)),
        num_cores     = _i("num_cores", 1),

        # ===== Generator specs =====
        ell_q = _i("ell_q", 3),
        ell_p = _i("ell_p", 3),
        spec_q = _seq("spec_q", ((3,1),)),
        spec_p = _seq("spec_p", ((3,1),)),
        mix_generators_q = _b("mix_generators_q", False),
        mix_generators_p = _b("mix_generators_p", False),

        # ===== Geometry / exp / connection =====
        use_global_A        = _b("use_global_A", False),
        A_compose_order     = _s("A_compose_order", "yx").lower(),
        exp_clip_max_norm   = _f("exp_clip_max_norm", 1e4),
        phi_small_threshold = _f("phi_small_threshold", 0.0),
        sigma_jitter        = _f("sigma_jitter", 1e-8),
        A_init_scale        = _f("A_init_scale", 1e-3),

        # ===== Masks / neighbors =====
        overlap_eps        = _f("overlap_eps", 1e-6),
        support_tau        = _f("support_tau", 1e-6),
        neighbors_symmetric= _b("neighbors_symmetric", False),

        # ===== Couplings & penalties =====
        alpha                  = _f("alpha", 0.0),
        beta                   = _f("beta", 0.0),
        
        feedback_weight        = _f("feedback_weight", 0.0),
        beta_model             = _f("beta_model", 1.0),
        
        lambda_A_curv          = _f("lambda_A_curv", 0.0),
        lambda_A_cov           = _f("lambda_A_cov", 0.0),

        

        # ===== Likelihood / observations =====
        obs_sigma2_true = _f("obs_sigma2_true", 1e-2),
        obs_dim         = _i("obs_dim", 2*_i("ell_q",3) + 1),
        sigma2_min      = _f("sigma2_min", 1e-6),

        # ===== Learning rates =====
        tau_phi          = _f("tau_phi", 0.0),
        tau_phi_model    = _f("tau_phi_model", 0.0),
        tau_mu_belief    = _f("tau_mu_belief", 0.0),
        tau_sigma_belief = _f("tau_sigma_belief", 0.0),
        tau_mu_model     = _f("tau_mu_model", 0.0),
        tau_sigma_model  = _f("tau_sigma_model", 0.0),
        A_lr             = _f("A_lr", 0.0),


        # ===== Initialization ranges / noise =====
        diagonal_sigma                = _b("diagonal_sigma", False),
        identical_models              = _b("identical_models", False),

        q_mu_range              = _t("q_mu_range", (-1.0, 1.0)),
        q_sigma_range           = _t("q_sigma_range", (0.2, 1.0)),
        
        p_mu_range              = _t("p_mu_range", (-1.0, 1.0)),
        p_sigma_range           = _t("p_sigma_range", (0.2, 1.0)),
       
        
        phi_init_smooth_sigma   = _f("phi_init_smooth_sigma", 1.5),
        phi_init                = _f("phi_init", 0.1),
        phi_model_offset        = _f("phi_model_offset", 0.1),
        

        # ===== Stability / clipping =====
        gradient_clip_phi       = _f("gradient_clip_phi", -1.0),
        gradient_clip_phi_model = _f("gradient_clip_phi_model", -1.0),

        A_grad_clip             = _f("A_grad_clip", -1.0),

        # ===== Numerics / debug =====
        eps                = _f("eps", 1e-10),
        debug_phase_timing = _b("debug_phase_timing", False),
        debug_grad_timing  = _b("debug_grad_timing", False),
    )



# runtime_context.py
def cfg_get(ctx, name: str, default):
    """
    Robust config accessor:
      1) ctx.step_cfg   (dataclass or dict)
      2) ctx.config     (dict or attr-like object)
      3) core.config    (module fallback)
      4) default
    """
    # 1) step_cfg
    sc = getattr(ctx, "step_cfg", None)
    if sc is not None:
        if isinstance(sc, dict) and name in sc:
            return sc[name]
        if hasattr(sc, name):
            return getattr(sc, name)

    # 2) config mirror
    cc = getattr(ctx, "config", None)
    if cc is not None:
        if isinstance(cc, dict):
            return cc.get(name, default)
        # tolerate attr-like mirrors
        if hasattr(cc, name):
            return getattr(cc, name, default)

    # 3) global fallback
    try:
        import core.config as _g
        return getattr(_g, name, default)
    except Exception:
        return default





def build_step_settings_from_overrides(base_config_module, overrides: dict) -> StepSettings:
    """Create StepSettings using values from base_config_module, then apply overrides."""
    base = build_step_settings(base_config_module)  # your existing builder
    if not overrides:
        return base
    d = asdict(base)
    for k, v in (overrides or {}).items():
        if k in d:
            d[k] = v
    return StepSettings(**d)






# ─────────────────────────────────────────────────────────────────────────────
# Convenience
# ─────────────────────────────────────────────────────────────────────────────
# --- in runtime_context.py (top-level dataclass or simple attrs init) ---
def ensure_clock_defaults(ctx):
    if not hasattr(ctx, "clock_t"):             ctx.clock_t = 0.0       # intrinsic time
    if not hasattr(ctx, "clock_last"):          ctx.clock_last = {}     # last speeds per field
    if not hasattr(ctx, "clock_cfg"):           ctx.clock_cfg = {
        "aggregate": "max_agent_mean",          # or: "mean_agent_mean"
        "w_mu": 1.0, "w_S": 1.0,                # Gaussian fibre weights
        "w_phi": 1.0, "w_tphi": 1.0,            # Lie algebra weights
        "w_A": 0.5,                             # global A (optional)
        "eps": 1e-8,
    }
    return ctx




def ensure_runtime_defaults(ctx: Optional[RuntimeCtx]) -> RuntimeCtx:
    if ctx is None:
        ctx = RuntimeCtx()
    if ctx.global_step is None:
        ctx.global_step = 0

    # existing
    _ = dirty_manager(ctx)
    if not hasattr(ctx, "edge") or ctx.edge is None:
        ctx.edge = EdgeMaps()

    return ctx



def ensure_shared_cache_attached(ctx_view):
    """
    Reattach a SharedDiskCache in this process.
    Safe to call on both master and worker views.
    """
    try:
        from core.shared_cache import SharedDiskCache
    except Exception:
        from shared_cache import SharedDiskCache

    cache_dir = (getattr(ctx_view, "config", {}) or {}).get("shared_cache_dir", "./_shared_cache")
    ctx_view.cache = SharedDiskCache(cache_dir)

    # unify backend to cached mode
    cfg = getattr(ctx_view, "config", {}) or {}
    cfg["transport_backend"] = "ctx"
    cfg["transport_validation"] = False
    ctx_view.config = cfg
    return ctx_view



def _to_plain_dict(obj):
    """Return a JSON/pickle-friendly dict for config-like objects."""
    if obj is None:
        return {}
    if isinstance(obj, dict):
        return dict(obj)
    if is_dataclass(obj):
        return asdict(obj)               # handles nested dataclasses too
    if hasattr(obj, "__dict__"):
        # best-effort for simple objects
        return dict(obj.__dict__)
    # last resort: empty (don’t blow up on unknown types)
    return {}

def ctx_view_for_workers(ctx):
    """
    Build a lightweight, picklable context view for loky workers.
    Drops non-picklables (locks, live caches).
    """
    cfg      = _to_plain_dict(getattr(ctx, "config", {}) or {})
    fields   = _to_plain_dict(getattr(ctx, "fields", {}) or {})
    step_cfg = _to_plain_dict(getattr(ctx, "step_cfg", {}) or {})

    return SimpleNamespace(
        config=cfg,
        fields=fields,
        step_cfg=step_cfg,
        global_step=int(getattr(ctx, "global_step", 0)),
    )






__all__ = [
    "CacheHub",
    "LevelGraph",
    "RuntimeCtx",
    "EdgeMaps",
    "StepSettings",
    "build_step_settings",
    "build_step_settings_from_overrides",
    "cfg_get",
    "ensure_runtime_defaults",
]
