from __future__ import annotations
"""
Created on Sun Sep 14 14:24:12 2025

@author: chris and christine
"""

import numpy as np
from core.numerical_utils import sanitize_sigma, push_gaussian, safe_omega_inv
import os, pickle
import json, pathlib
from typing import Any

# updates/grad_utils.py
"""
Pure, stateless gradient utilities for multiprocessing-safe gradient computation.
All functions are picklable and side-effect free.
"""
# updates/grad_utils_phi.py
"""
Pure, stateless φ gradient utilities for multiprocessing-safe computation.
All functions are picklable and side-effect free.
"""

from core.transport_cache import E_grid
from core.omega import build_dexpinv_matrix


# ============================================================================
# Phi Accumulator (Pure Function Pattern)
# ============================================================================

def create_phi_accum(shape, dtype=np.float32):
    """
    Create φ gradient accumulator dict (picklable).
    
    Parameters
    ----------
    shape : tuple
        Shape of phi field, e.g. (*S, 3)
    dtype : numpy dtype
    
    Returns
    -------
    dict with keys:
        'phi': (*S, 3) array
        'diagnostics': dict of per-term magnitudes
    """
    return {
        'phi': np.zeros(shape, dtype),
        'diagnostics': {},
    }


def add_phi_term(accum, name, dphi, weight=1.0, mask=None):
    """
    Add weighted φ gradient term to accumulator.
    
    Parameters
    ----------
    accum : dict
        From create_phi_accum()
    name : str
        Term identifier
    dphi : ndarray (*S, 3)
    weight : float
    mask : ndarray (*S,) or None
    
    Returns
    -------
    accum : dict (same object, for chaining)
    """
    dphi = np.asarray(dphi, np.float32)
    
    if mask is not None:
        m = np.asarray(mask, np.float32)
        dphi = dphi * m[..., None]
    
    accum['phi'] += weight * dphi
    accum['diagnostics'][name] = float(np.sum(np.abs(dphi)))
    return accum


# ============================================================================
# Cached Preconditioners (SharedDiskCache-backed)
# ============================================================================

def get_cached_preconditioners(ctx, agent, which, fisher_inv_key, eps=1e-8):
    """
    Get (E, Jinv, Finv) with shared cache (process-safe).
    
    Returns
    -------
    E : ndarray (*S, K, K)
        exp(φ) or exp(φ_tilde)
    Jinv : ndarray (*S, 3, 3)
        J^{-1} = dexp^{-1}
    Finv : ndarray (*S, 3, 3)
        Fisher inverse metric
    """
    aid = int(getattr(agent, "id", -1))
    step = int(getattr(ctx, "global_step", 0))
    
    cache_key = ("precond", which, aid, step)
    
    # Try shared cache
    cached = ctx.cache.get("phi_precond", cache_key)
    if cached is not None:
        return cached["E"], cached["Jinv"], cached["Finv"]
    
    # Compute
    E = np.asarray(E_grid(ctx, agent, which=which), np.float32)
    
    # Jinv from cache or compute
    from core.transport_cache import Jinv_grid
    Jinv = Jinv_grid(ctx, agent, which=which)
    if Jinv is None:
        base_phi = np.asarray(
            getattr(agent, "phi" if which == "q" else "phi_model"), 
            np.float32
        )
        Jinv = build_dexpinv_matrix(base_phi)
    
    # Finv from agent attribute (must be pre-computed)
    Finv = getattr(agent, fisher_inv_key, None)
    if Finv is None:
        raise AttributeError(
            f"Agent {aid} missing '{fisher_inv_key}' for which='{which}'"
        )
    
    Finv = np.asarray(Finv, np.float32)
    
    # Validate
    if Finv.shape != Jinv.shape:
        raise ValueError(f"Finv shape {Finv.shape} != Jinv shape {Jinv.shape}")
    if not (np.isfinite(E).all() and np.isfinite(Jinv).all() and np.isfinite(Finv).all()):
        raise FloatingPointError("Non-finite preconditioners")
    
    # Store in shared cache
    ctx.cache.put("phi_precond", cache_key, {
        "E": E,
        "Jinv": Jinv,
        "Finv": Finv,
    })
    
    return E, Jinv, Finv


def project_phi_covector(cov, Jinv, Finv):
    """
    Project φ-space covector to parameter-space step.
    
    Parameters
    ----------
    cov : ndarray (*S, 3)
        Unprojected covector
    Jinv : ndarray (*S, 3, 3)
    Finv : ndarray (*S, 3, 3)
    
    Returns
    -------
    step : ndarray (*S, 3)
    """
    from core.omega import project_phi_covector_to_step
    return project_phi_covector_to_step(
        np.asarray(cov, np.float32), Jinv, Finv
    )


# ============================================================================
# Pure Transport Helpers
# ============================================================================

def push_neighbor_stats_pure(agent_j, S_key, Omega_ij, eps=1e-8):
    """
    Push neighbor stats through Ω (pure function).
    
    Returns
    -------
    mu_j_t : ndarray (*S, K)
    S_j_t : ndarray (*S, K, K) (unused but kept for signature)
    S_j_t_inv : ndarray (*S, K, K)
    """
    mu_j = np.asarray(getattr(agent_j, S_key.replace("sigma", "mu")), np.float32)
    S_j = np.asarray(getattr(agent_j, S_key), np.float32)
    
    mu_j_t, _, S_j_t_inv = push_gaussian(
        mu_j, S_j, Omega_ij, 
        eps=eps, return_inv=True, 
        sanitize_input=False
    )
    
    return mu_j_t, None, S_j_t_inv


def iter_neighbors_with_masks(agent_i, neighbors, ctx):
    """
    Pure generator for neighbors with joint masks.
    
    Yields
    ------
    (agent_j, mask_bool, mask_float) : (Agent, ndarray (*S,), ndarray (*S,))
    """
    from utils import joint_masks
    
    for aj in (neighbors or []):
        if aj is agent_i:
            continue
        
        m_bool, m_vec = joint_masks(ctx, agent_i, aj)
        if not np.any(m_bool):
            continue
        
        m_float = m_vec[..., 0].astype(np.float32, copy=False)
        yield aj, m_bool, m_float

# ============================================================================
# Gradient Accumulator (Pure Function Pattern)
# ============================================================================

def create_gradient_accum(shape, dtype=np.float32):
    """
    Create gradient accumulator dict (picklable).
    
    Parameters
    ----------
    shape : tuple
        Shape of mu field, e.g. (*S, K)
    dtype : numpy dtype
        Data type for gradients
    
    Returns
    -------
    dict with keys:
        'mu': (*S, K) array
        'S': (*S, K, K) array
        'diagnostics': dict of per-term magnitudes
    """
    K = int(shape[-1])
    S = shape[:-1]
    return {
        'mu': np.zeros(S + (K,), dtype),
        'S': np.zeros(S + (K, K), dtype),
        'diagnostics': {},
    }


def add_gradient_term(accum, name, dmu, dS, weight=1.0, mask=None):
    """
    Add weighted gradient term to accumulator (in-place, pure side effect).
    
    Parameters
    ----------
    accum : dict
        From create_gradient_accum()
    name : str
        Term identifier for diagnostics
    dmu : ndarray (*S, K)
    dS : ndarray (*S, K, K)
    weight : float
        Scaling factor
    mask : ndarray (*S,) or None
        Spatial mask
    
    Returns
    -------
    accum : dict (same object, for chaining)
    """
    dmu = np.asarray(dmu, np.float32)
    dS = np.asarray(dS, np.float32)
    
    if mask is not None:
        m = np.asarray(mask, np.float32)
        dmu = dmu * m[..., None]
        dS = dS * m[..., None, None]
    
    accum['mu'] += weight * dmu
    accum['S'] += weight * dS
    accum['diagnostics'][name] = (
        float(np.sum(np.abs(dmu))),
        float(np.sum(np.abs(dS)))
    )
    return accum


def symmetrize(A):
    """Ensure matrix symmetry."""
    return 0.5 * (A + np.swapaxes(A, -1, -2))


def safe_cast_and_sanitize(mu, sigma, eps=1e-8, dtype=np.float64):
    """
    Cast and sanitize Gaussian parameters in one pass.
    
    Returns
    -------
    mu_out : ndarray (dtype)
    sigma_out : ndarray (dtype, SPD)
    """
    mu_out = np.asarray(mu, dtype, order="C")
    sigma_out = sanitize_sigma(np.asarray(sigma, dtype), eps=eps)
    return mu_out, sigma_out


# ============================================================================
# Cached Push Operations (Uses SharedDiskCache)
# ============================================================================

def get_cached_push_forward(ctx, agent, eps=1e-8):
    """
    Get q->p push with shared cache (process-safe).
    
    Returns
    -------
    mu_push : (*S, Kp)
    S_push : (*S, Kp, Kp)
    S_push_inv : (*S, Kp, Kp)
    """
    from core.transport_cache import Phi_cached
    
    aid = int(getattr(agent, "id", -1))
    step = int(getattr(ctx, "global_step", 0))
    
    cache_key = ("push_forward", aid, step)
    
    # Try shared cache
    cached = ctx.cache.get("push", cache_key)
    if cached is not None:
        return cached["mu"], cached["S"], cached["inv"]
    
    # Compute
    Phi = Phi_cached(ctx, agent, kind="q_to_p")
    mu_q = agent.mu_q_field
    S_q = agent.sigma_q_field
    
    mu_push, S_push, S_push_inv = push_gaussian(
        mu_q, S_q, Phi, eps=eps, return_inv=True,
        Sigma_inv=getattr(agent, "sigma_q_inv", None),
        assume_orthogonal=False
    )
    
    # Store in shared cache (mmap-backed)
    ctx.cache.put("push", cache_key, {
        "mu": np.asarray(mu_push, np.float32),
        "S": np.asarray(S_push, np.float32),
        "inv": np.asarray(S_push_inv, np.float32),
    })
    
    return mu_push, S_push, S_push_inv


def get_cached_push_backward(ctx, agent, eps=1e-8):
    """
    Get p->q push with shared cache (process-safe).
    
    Returns
    -------
    mu_push : (*S, Kq)
    S_push : (*S, Kq, Kq)
    S_push_inv : (*S, Kq, Kq)
    """
    from core.transport_cache import Phi_cached
    
    aid = int(getattr(agent, "id", -1))
    step = int(getattr(ctx, "global_step", 0))
    
    cache_key = ("push_backward", aid, step)
    
    # Try shared cache
    cached = ctx.cache.get("push", cache_key)
    if cached is not None:
        return cached["mu"], cached["S"], cached["inv"]
    
    # Compute
    Phi_tilde = Phi_cached(ctx, agent, kind="p_to_q")
    mu_p = agent.mu_p_field
    S_p = agent.sigma_p_field
    
    mu_push, S_push, S_push_inv = push_gaussian(
        mu_p, S_p, Phi_tilde, eps=eps, return_inv=True,
        Sigma_inv=getattr(agent, "sigma_p_inv", None),
        assume_orthogonal=False
    )
    
    # Store in shared cache
    ctx.cache.put("push", cache_key, {
        "mu": np.asarray(mu_push, np.float32),
        "S": np.asarray(S_push, np.float32),
        "inv": np.asarray(S_push_inv, np.float32),
    })
    
    return mu_push, S_push, S_push_inv


# ============================================================================
# KL Standard Forms (For Reuse)
# ============================================================================

def kl_target_partials(mu_p, Sigma_p, mu_q, Sigma_q_inv, eps=1e-8):
    """
    Target-form KL(P||Q) partials: derivatives wrt Q parameters.
    
    Returns
    -------
    dmu_q : (*S, K)
    dSigma_q : (*S, K, K)
    """
    delta = mu_p - mu_q
    v = np.einsum("...ij,...j->...i", Sigma_q_inv, delta, optimize=True)
    dmu = -v
    
    vvT = np.einsum("...i,...j->...ij", v, v, optimize=True)
    term = np.einsum("...ij,...jk,...kl->...il", 
                     Sigma_q_inv, Sigma_p, Sigma_q_inv, optimize=True)
    dS = 0.5 * (-term - vvT + Sigma_q_inv)
    return dmu, symmetrize(dS)


def kl_source_partials(mu_p, Sigma_p_inv, mu_q, Sigma_q_inv, eps=1e-8):
    """
    Source-form KL(P||Q) partials: derivatives wrt P parameters.
    
    Returns
    -------
    dmu_p : (*S, K)
    dSigma_p : (*S, K, K)
    """
    delta = mu_p - mu_q
    dmu = np.einsum("...ij,...j->...i", Sigma_q_inv, delta, optimize=True)
    dS = 0.5 * (Sigma_q_inv - Sigma_p_inv)
    return dmu, symmetrize(dS)


# ============================================================================
# Overlap Iteration (Pure)
# ============================================================================

def iter_overlap_pairs(agent_i, agents, tau, which, mu_key, ctx):
    """
    Pure generator for overlapping neighbors.
    
    Yields
    ------
    (agent_j, overlap_mask) : (Agent, ndarray (*S,) bool)
    """
    from utils import joint_masks
    
    for aj in (agents or []):
        if aj is agent_i:
            continue
        
        m_bool, m_vec = joint_masks(ctx, agent_i, aj)
        if not np.any(m_bool):
            continue
        
        yield aj, m_bool

def _get_phi(agent: Any, which: str) -> np.ndarray:
    if which == "q":
        phi = getattr(agent, "phi", None)
    else:
        phi = getattr(agent, "phi_model", None)
    if phi is None:
        raise ValueError(f"[transport_cache] phi field ({which}) missing")
    return phi



def _zeros_mu_S_like(mu):
    mu = np.asarray(mu, np.float32)
    S  = mu.shape[:-1]
    K  = mu.shape[-1]
    return (np.zeros(S + (K,),    np.float32),
            np.zeros(S + (K, K), np.float32))



def _to32_no_underflow(x):
    """
    Cast to float32 but zero out sub-f32-tiny magnitudes to avoid denorm underflow
    in later ops. Preserves sign on non-tiny entries.
    """
    x64 = np.asarray(x, dtype=np.float64)
    tiny32 = np.finfo(np.float32).tiny
    with np.errstate(under="ignore"):
        x64 = np.where(np.abs(x64) < tiny32, 0.0, x64)
    return x64.astype(np.float32, copy=False)




def _roll_spatial_axis(a, axis_m: int, shift: int, *, trailing: int = 2):
    """
    Periodic roll along the m-th spatial axis (0-based among spatial axes).
    trailing: number of non-spatial trailing dims (e.g., 2 for (...,K,K), 1 for (...,3)).
    Pure / loky-safe.
    """
    import numpy as np
    a = np.asarray(a)
    if trailing < 0 or trailing > a.ndim:
        raise ValueError(f"trailing={trailing} invalid for shape {a.shape}")
    spatial_rank = a.ndim - trailing
    if spatial_rank <= 0:
        return a  # nothing to roll

    # normalize axis index
    m = int(axis_m)
    if m < 0:
        m += spatial_rank
    if not (0 <= m < spatial_rank):
        raise IndexError(f"axis_m={axis_m} out of range for spatial rank {spatial_rank} (shape {a.shape}, trailing={trailing})")

    ax = m  # among leading spatial axes [0..spatial_rank-1]
    n = a.shape[ax]
    if n == 0:
        return a
    # normalize shift
    s = int(shift) % n
    if s == 0:
        return a
    return np.roll(a, shift=s, axis=ax)




def _assert_finite(tag, *arrs):
    import numpy as np
    for a in arrs:
        if a is None:
            continue
        A = np.asarray(a)
        # Skip non-numeric types (e.g., strings, objects)
        if not np.issubdtype(A.dtype, np.number):
            continue
        if not np.all(np.isfinite(A)):
            n_nan = int(np.isnan(A).sum())
            n_inf = int(np.isinf(A).sum())
            raise FloatingPointError(f"[{tag}] non-finite values (nan={n_nan}, inf={n_inf})")



def _add_to_inbox(agent, which, add_mu, add_S, mask):
    """Enqueue sender-side alignment grads into agent's inbox (no projection)."""
    mu_key = "inbox_align_mu_q" if which == "q" else "inbox_align_mu_p"
    S_key  = "inbox_align_S_q"  if which == "q" else "inbox_align_S_p"

    # lazy init on first use (idempotent)
    if getattr(agent, mu_key, None) is None:
        base_mu = getattr(agent, "mu_q_field" if which == "q" else "mu_p_field")
        setattr(agent, mu_key, np.zeros_like(base_mu, dtype=np.float32))
    if getattr(agent, S_key, None) is None:
        base_S = getattr(agent, "sigma_q_field" if which == "q" else "sigma_p_field")
        setattr(agent, S_key, np.zeros_like(base_S, dtype=np.float32))

    # --- re-fetch; re-initialize if another thread cleared them in-between ---
    inbox_mu = getattr(agent, mu_key, None)
    inbox_S  = getattr(agent, S_key, None)
    if inbox_mu is None:
        base_mu = getattr(agent, "mu_q_field" if which == "q" else "mu_p_field")
        inbox_mu = np.zeros_like(base_mu, dtype=np.float32)
        setattr(agent, mu_key, inbox_mu)
    if inbox_S is None:
        base_S = getattr(agent, "sigma_q_field" if which == "q" else "sigma_p_field")
        inbox_S = np.zeros_like(base_S, dtype=np.float32)
        setattr(agent, S_key, inbox_S)

    # scatter-add only where overlap is true
    inbox_mu[mask] += add_mu[mask]
    inbox_S [mask] += add_S [mask]


def _drain_inbox_into_dalign(agent, which, dmu_align, dS_align):
    """Pull any queued sender grads into receiver's running align grads, then clear."""
    mu_key = "inbox_align_mu_q" if which == "q" else "inbox_align_mu_p"
    S_key  = "inbox_align_S_q"  if which == "q" else "inbox_align_S_p"
    have_mu = getattr(agent, mu_key, None)
    have_S  = getattr(agent, S_key, None)
    if have_mu is not None:
        dmu_align += have_mu.astype(np.float32, copy=False)
        setattr(agent, mu_key, None)    # clear
    if have_S is not None:
        dS_align  += have_S.astype(np.float32, copy=False)
        setattr(agent, S_key, None)     # clear
    return dmu_align, dS_align






# =========================
# Basic, stable miscellany
# =========================

def _aid(agent) -> int:
    # Strict: never use id(obj); enforce a real, stable id
    try:
        return int(getattr(agent, "id"))
    except Exception:
        raise RuntimeError("Agent missing stable .id; call ensure_stable_agent_ids(...) before Parallel.")





def _safe_vector_norm(x: np.ndarray) -> np.ndarray:
    """
    Robust vector 2-norm along the last axis, tolerant to underflow.
    Uses float64 and hypot (when small last-dim) to avoid tiny* tiny raises.
    Returns an array of norms (same shape as x without the last axis).
    """
    x = np.asarray(x)
    if x.ndim == 0:
        return np.abs(x.astype(np.float64))

    # Prefer hypot for 2D/3D vectors (most common in your fields)
    with np.errstate(under='ignore', over='ignore', invalid='ignore'):
        if x.shape[-1] == 2:
            a = x[..., 0].astype(np.float64, copy=False)
            b = x[..., 1].astype(np.float64, copy=False)
            return np.hypot(a, b)
        elif x.shape[-1] == 3:
            a = x[..., 0].astype(np.float64, copy=False)
            b = x[..., 1].astype(np.float64, copy=False)
            c = x[..., 2].astype(np.float64, copy=False)
            return np.hypot(np.hypot(a, b), c)
        else:
            # General case: float64 accumulation; safe underflow handling
            x64 = x.astype(np.float64, copy=False)
            # sum(..., dtype=float64) keeps the accumulator wide
            return np.sqrt(np.sum(x64 * x64, axis=-1, dtype=np.float64))


def mean_norm(x) -> float:
    """
    Mean 2-norm along the last axis, NaN-safe, and underflow-safe.
    Returns 0.0 if there are no finite entries (so plots don’t disappear).
    """
    if x is None:
        return 0.0
    n = _safe_vector_norm(x)
    n = np.asarray(n, dtype=np.float64)
    m = np.isfinite(n)
    if not np.any(m):
        
        return 0.0
    return float(np.mean(n[m]))




# =========================
#         Masks
# =========================




# --- small helpers ------------------------------------------------------------
def _broadcast_mask_to_S(S, m_raw, tau: float):
    import numpy as np
    if m_raw is None:
        return np.ones(S, dtype=bool)
    m = np.asarray(m_raw)
    if m.shape != S:
        pad = (1,) * max(0, len(S) - m.ndim)
        try:
            m = np.broadcast_to(m.reshape(pad + m.shape), S)
        except Exception as e:
            raise ValueError(f"agent.mask shape {m_raw.shape} not broadcastable to {S}") from e
    return (m > tau)


def mask_hw(x, *, tau: float, mode: str = "float3"):
    """
    N-D mask normalizer (broadcast- & dtype-safe).

    Accepts x.mask or x (array-like) in shapes (*S,) or (*S,1).
    Modes:
      - "bool2"  -> (*S,)   bool
      - "float3" -> (*S,1)  float32 (broadcast-friendly channel)
      - "vec"    -> (|S|,)  bool (raveled)
    """
    m = getattr(x, "mask", x)
    m = np.asarray(m)

    # Squeeze trailing singleton channel if present
    if m.ndim >= 1 and m.shape[-1] == 1:
        m = m[..., 0]

    if m.ndim == 0:
        m = m.reshape(1)

    if np.issubdtype(m.dtype, np.floating) or np.issubdtype(m.dtype, np.integer):
        if not np.isfinite(m).all():
            n_bad = int(m.size - np.isfinite(m).sum())
            raise FloatingPointError(f"mask_hw: non-finite values in mask ({n_bad} cells).")

    mb = m if (m.dtype == bool) else (m.astype(np.float32, copy=False) > float(tau))

    if mode == "bool2":
        return mb.astype(bool, copy=False)
    if mode == "float3":
        return mb.astype(np.float32, copy=False)[..., None]
    if mode == "vec":
        return mb.astype(bool, copy=False).ravel()

    raise ValueError(f"mask_hw: unknown mode={mode!r}")


def _joint_mask(a, b, *, tau: float, as_vector: bool = True):
    """
    Joint support of two agents' masks (broadcast-safe, N-D).
    Returns:
      - (*S,1) float32 if as_vector=True
      - (*S,)  bool    if as_vector=False
    """
    ma = mask_hw(a, tau=tau, mode="bool2")
    mb = mask_hw(b, tau=tau, mode="bool2")

    try:
        S = np.broadcast(ma, mb).shape
    except Exception as e:
        raise ValueError(f"joint_mask: shapes not broadcastable: {ma.shape} vs {mb.shape}") from e

    if ma.shape != S: ma = np.broadcast_to(ma, S)
    if mb.shape != S: mb = np.broadcast_to(mb, S)

    m = ma & mb
    return (m[..., None].astype(np.float32, copy=False)) if as_vector else m



def joint_masks(ctx, ai, aj, *, tau: float | None = None):
    """
    Canonical joint mask over the base manifold C (N-D, broadcast-safe).

    Returns:
      m_bool  : (*S,)   bool      – for indexing/guarding loops
      m_float : (*S,1)  float32   – for weighting/broadcast-safe math

    Notes:
      • Uses ctx.support_tau (default 1e-6). The 'tau' argument is deprecated.
      • Masks live on the base lattice C and are shared by all fibers (q/p).
    """
    import warnings
    from runtime_context import cfg_get
    
    if tau is not None and not _MASK_WARNED["joint_masks_tau"]:
        warnings.warn("joint_masks: 'tau' arg is deprecated; using ctx.support_tau instead.",
                      RuntimeWarning, stacklevel=2)
        _MASK_WARNED["joint_masks_tau"] = True

    m_bool  = _joint_mask(ai, aj, tau=float(cfg_get(ctx, "support_tau", 1e-6)), as_vector=False)
    m_float = _joint_mask(ai, aj, tau=float(cfg_get(ctx, "support_tau", 1e-6)), as_vector=True)

    # Guarantee writeable arrays for downstream in-place ops
    if isinstance(m_bool, np.ndarray) and not m_bool.flags.writeable:
        m_bool = np.array(m_bool, copy=True)
    if isinstance(m_float, np.ndarray) and not m_float.flags.writeable:
        m_float = np.array(m_float, copy=True)
    return m_bool, m_float




def make_soft_mask(
    center, radius, domain_size, *,
    cutoff=None, dtype=None, return_bool=False, feather=None, soft_cut=True
):
    
    import core.config
    """
    N-D soft (Gaussian-like) mask on a periodic hypercube.
    m(x) = exp( - sum_d (δ_d / r_d)^2 ), with periodic min-image δ_d.

    radius semantics:
      r_d is the 1/e falloff along axis d (m=exp(-1) at |δ_d|=r_d).
      If you want m=cutoff at |δ|=R, use r = R / sqrt(log(1/cutoff)).
    """
    S = tuple(int(s) for s in domain_size)
    D = len(S)

    if dtype is None:
        dtype = getattr(core.config, "dtype", np.float64)

    if cutoff is None:
        cutoff = float(getattr(core.config, "support_tau", 1e-6))
    cutoff = float(cutoff)

    # center → length D, periodic
    if center is None:
        c = tuple(s // 2 for s in S)
    elif np.isscalar(center):
        c = (int(center),) * D
    else:
        c = tuple(int(x) for x in center)
        if len(c) < D:
            c = tuple(c) + tuple(S[i] // 2 for i in range(len(c), D))
        elif len(c) > D:
            c = tuple(c[:D])
    c = tuple((ci % si) for ci, si in zip(c, S))

    # radius → length D
    if np.isscalar(radius):
        r = (float(radius),) * D
    else:
        r = tuple(float(x) for x in radius)
        if len(r) < D:
            r = tuple(r) + (float(r[-1]),) * (D - len(r))
        elif len(r) > D:
            r = tuple(r[:D])
    eps = np.finfo(dtype).eps
    r = tuple(max(abs(x), eps) for x in r)

    grids = np.ogrid[tuple(slice(0, s) for s in S)]
    rho2 = 0.0
    for d in range(D):
        g = grids[d]
        sz = S[d]
        delta = np.abs(g - c[d])
        delta = np.minimum(delta, sz - delta)
        rho2 = rho2 + (delta / r[d])**2

    m = np.exp(-rho2, dtype=dtype).astype(dtype, copy=False)

    if soft_cut and cutoff > 0.0:
        delta_val = 0.5 * (1.0 - cutoff) if feather is None else min(0.49, float(feather))
        lo = max(0.0, cutoff - delta_val)
        hi = min(1.0, cutoff + delta_val)
        t = (m - lo) / max(1e-12, (hi - lo))
        t = np.clip(t, 0.0, 1.0)
        smooth = t*t*(3.0 - 2.0*t)
        m = m * smooth
    elif (not soft_cut) and cutoff > 0.0:
        m = np.where(m < cutoff, 0.0, m)

    m = m.astype(dtype, copy=False)
    if return_bool:
        return m, (m > cutoff)
    return m

# utils.py  --- masks section

_MASK_WARNED = {"joint_masks_tau": False}







def assert_mask_shapes(mbool, mfloat, Sshape):
    """
    Dev-time sanity: masks have expected shapes/dtypes.
    """
    if mbool.shape != Sshape or mbool.dtype != np.bool_:
        raise AssertionError(f"mbool shape/dtype mismatch: {mbool.shape}, {mbool.dtype} vs {Sshape}, bool")
    if mfloat.shape != (Sshape + (1,)) or mfloat.dtype != np.float32:
        raise AssertionError(f"mfloat shape/dtype mismatch: {mfloat.shape}, {mfloat.dtype} vs {Sshape+(1,)}, float32")


# ------------------------------ Agents ---------------------------------------




def get_neighbors(agent_i, agents, *, dedup=True, exclude_self=True):
    """
    Resolve agent_i.neighbors -> list[Agent]. Accepts neighbors as dicts with 'id' or raw ints.
    Works with `agents` as a list (id from agent.id or index) or dict keyed by id.
    """
    raw = getattr(agent_i, "neighbors", []) or []

    if isinstance(agents, dict):
        lookup = {int(k): v for k, v in agents.items()}
    else:
        lookup = {int(getattr(a, "id", i)): a for i, a in enumerate(agents)}

    out, seen = [], set()
    self_id = int(getattr(agent_i, "id", -1))

    for nb in raw:
        try:
            j = int(nb["id"]) if isinstance(nb, dict) else int(nb)
        except Exception:
            continue
        if exclude_self and j == self_id:
            continue
        if dedup and j in seen:
            continue
        a = lookup.get(j)
        if a is not None:
            out.append(a)
            if dedup:
                seen.add(j)
    return out


def _iter_overlap_pairs(agent_i, agents, *, tau: float, which: str, mu_key: str, ctx=None):
    """
    Yield (neighbor_agent, joint_bool_mask) for neighbors that overlap the receiver.

    Back-compat:
      - Keeps the same yields as before: (aj, joint_bool_mask).
      - If ctx is provided, uses utils.joint_masks (single source of truth).
      - If ctx is None, falls back to legacy tau/broadcast logic.
    """
    import numpy as np
    
    # Establish receiver spatial shape from the active fiber
    Sshape = tuple(np.asarray(getattr(agent_i, mu_key)).shape[:-1])

    # Deterministic order
    i_id = int(getattr(agent_i, "id", -1))
    triples = []
    for aj in agents:
        j_id = int(getattr(aj, "id", -1))
        if j_id == i_id:
            continue

        if ctx is not None:
            # Canonical path: use joint_masks (returns bool + (*S,1) float mask)
            mbool, _ = joint_masks(ctx, agent_i, aj)
            if np.any(mbool):
                triples.append((j_id, aj, mbool.astype(bool, copy=False)))
        else:
            # Legacy fallback: manual broadcast + tau threshold
            i_mask = np.asarray(getattr(agent_i, "mask"), np.float32)
            if i_mask.shape != Sshape:
                i_mask = np.broadcast_to(i_mask, Sshape)
            j_mask = np.asarray(getattr(aj, "mask"), np.float32)
            if j_mask.shape != Sshape:
                j_mask = np.broadcast_to(j_mask, Sshape)
            joint = (i_mask > float(tau)) & (j_mask > float(tau))
            if np.any(joint):
                triples.append((j_id, aj, joint))

    triples.sort(key=lambda t: t[0])  # deterministic accumulation order
    for _, aj, joint in triples:
        yield aj, joint





def _accumulate_into_agent(agent, gmu_attr: str, gS_attr: str, dmu: np.ndarray, dS: np.ndarray):
    """
    Create grad buffers if missing and add in-place (float32).
    """
    if getattr(agent, gmu_attr, None) is None:
        setattr(agent, gmu_attr, np.zeros_like(dmu, dtype=np.float32))
    if getattr(agent, gS_attr, None) is None:
        setattr(agent, gS_attr, np.zeros_like(dS, dtype=np.float32))
    setattr(agent, gmu_attr, getattr(agent, gmu_attr) + np.asarray(dmu, np.float32))
    setattr(agent, gS_attr,  getattr(agent, gS_attr)  + np.asarray(dS,  np.float32))


def zero_all_gradients(agent):
    """
    Zero (and if missing, create) all gradient buffers,
    keeping legacy aliases in sync and ensuring arrays are writeable.
    """
    def ensure_buf(name, like):
        arr = getattr(agent, name, None)
        if arr is None and like is not None:
            arr = np.zeros_like(like)
        elif arr is not None and not arr.flags.writeable:
            arr = np.array(arr, copy=True)
        setattr(agent, name, arr)
        return arr

    g_mu_q   = ensure_buf("grad_mu_q",    getattr(agent, "mu_q_field", None))
    g_sg_q   = ensure_buf("grad_sigma_q", getattr(agent, "sigma_q_field", None))
    g_mu_p   = ensure_buf("grad_mu_p",    getattr(agent, "mu_p_field", None))
    g_sg_p   = ensure_buf("grad_sigma_p", getattr(agent, "sigma_p_field", None))
    g_phi    = ensure_buf("grad_phi",       getattr(agent, "phi", None))
    g_phit   = ensure_buf("grad_phi_tilde", getattr(agent, "phi_model", None))

    # legacy aliases
    if g_mu_q is not None: agent.grad_mu_q_field    = g_mu_q
    if g_sg_q is not None: agent.grad_sigma_q_field = g_sg_q
    if g_mu_p is not None: agent.grad_mu_p_field    = g_mu_p
    if g_sg_p is not None: agent.grad_sigma_p_field = g_sg_p

    for arr in (g_mu_q, g_sg_q, g_mu_p, g_sg_p, g_phi, g_phit):
        if isinstance(arr, np.ndarray):
            arr.fill(0)










def push_neighbor_stats(agent_j, sigma_key: str, Omega_ij: np.ndarray, eps: float):
    """
    Returns (mu_j_t, Sigma_j_t, Sigma_j_t_inv) in agent-i frame.
    Fast path pushes the PRECISION with an explicit spectral inverse (robust),
    fallback pushes the covariance using push_gaussian.
    """
    # ---- stats (sender j) ----
    mu_j = np.asarray(getattr(agent_j, sigma_key.replace("sigma", "mu")), np.float64, order="C")

    inv_key = sigma_key.replace("_field", "_inv")
    S_inv = getattr(agent_j, inv_key, None)

    # ---- mapping ----
    Om  = np.asarray(Omega_ij, np.float64, order="C")
    
    # ---------- PRECISION FAST-PATH ----------
    if S_inv is not None:
        S_inv = np.asarray(S_inv, np.float64, order="C")
        if S_inv.size and np.all(np.isfinite(S_inv)):
            try:
                Oinv = np.asarray(safe_omega_inv(Om, eps=1e-6), np.float64, order="C")
                OinvT = np.swapaxes(Oinv, -1, -2)

                # S_inv_t = Oinv^T S_inv Oinv  (do this in fp64 + symmetrize)
                S_inv_t = np.einsum("...ik,...kl,...jl->...ij", OinvT, S_inv, Oinv, optimize=True)
                S_inv_t = 0.5 * (S_inv_t + np.swapaxes(S_inv_t, -1, -2))

                # Robust spectral inverse (clip tiny eigs; no chol)
                flat = S_inv_t.reshape(-1, S_inv_t.shape[-1], S_inv_t.shape[-1])
                w, V = np.linalg.eigh(flat)
                lo = max(eps, np.finfo(w.dtype).eps)
                w = np.clip(w, a_min=lo, a_max=None)
                w_inv = 1.0 / w
                # Reconstruct Sigma_t = (S_inv_t)^{-1}
                Sigma_t = (V * w_inv[..., None, :]) @ np.swapaxes(V, -1, -2)
                Sigma_t = Sigma_t.reshape(S_inv_t.shape)
                Sigma_t = 0.5 * (Sigma_t + np.swapaxes(Sigma_t, -1, -2))

                # Mean push μ_t = Ω μ_j  (simple, stable)
                mu_t = np.einsum("...ij,...j->...i", Om, mu_j, optimize=True)

                # Also return S_inv_t in fp32 for callers that need it
                return (mu_t.astype(np.float32, copy=False),
                        Sigma_t.astype(np.float32, copy=False),
                        S_inv_t.astype(np.float32, copy=False))
            except Exception as e:
                # fall through to covariance path
                print(f"[push_neighbor_stats] precision fast-path failed: {e}")

    # ---------- COVARIANCE FALLBACK ----------
    Sigma_j = sanitize_sigma(np.asarray(getattr(agent_j, sigma_key), np.float64))
    # Be conservative about orthogonality; only assume if clearly near-ortho
    def _near_ortho(M, tol=1e-3):
        K = M.shape[-1]
        I = np.eye(K, dtype=M.dtype)
        M0 = M.reshape(-1, K, K)[0]
        return np.linalg.norm(M0.T @ M0 - I, ord='fro') / K < tol

    assume_ortho = _near_ortho(Om)

    mu_t, Sigma_t, Sigma_t_inv = push_gaussian(
        mu=mu_j, Sigma=Sigma_j, M=Om, eps=eps,
        return_inv=True, assume_orthogonal=assume_ortho, sanitize_input=False
    )
    return (mu_t.astype(np.float32, copy=False),
            Sigma_t.astype(np.float32, copy=False),
            Sigma_t_inv.astype(np.float32, copy=False))





# =========================
# Linear algebra helpers
# =========================


def _ensure_q_to_p_shape(X, Kp, Kq):
    """Φ0: q→p must be (Kp, Kq). Auto-transpose if (Kq, Kp)."""
    X = np.asarray(X, np.float32)
    if X.shape == (Kp, Kq): return X
    if X.shape == (Kq, Kp): return X.T
    raise ValueError(f"Φ0 wrong shape {X.shape}; expected {(Kp, Kq)} or {(Kq, Kp)}")

def _ensure_p_to_q_shape(X, Kq, Kp):
    """Φ̃0: p→q must be (Kq, Kp). Auto-transpose if (Kp, Kq)."""
    X = np.asarray(X, np.float32)
    if X.shape == (Kq, Kp): return X
    if X.shape == (Kp, Kq): return X.T
    raise ValueError(f"Φ̃0 wrong shape {X.shape}; expected {(Kq, Kp)} or {(Kp, Kq)}")


def _fiber_keys_from_mode(mode: str):
    """Map 'belief'/'model' → fiber and attribute names (q/p)."""
    which = "q" if mode == "belief" else "p"
    field = "phi" if which == "q" else "phi_model"
    mu_key = "mu_q_field" if which == "q" else "mu_p_field"
    S_key  = "sigma_q_field" if which == "q" else "sigma_p_field"
    gmu_key= "grad_mu_q" if which == "q" else "grad_mu_p"
    gS_key = "grad_sigma_q" if which == "q" else "grad_sigma_p"
    return which, field, mu_key, S_key, gmu_key, gS_key







# =========================
# Logging
# =========================


def _beta_cfg(ctx, which: str):
    """
    Canonical β config reader (ALIGN-only version).

    Returns (kappa, eps, tau_support)
      • β now always corresponds to the alignment KL:
          which == 'q' → KL(q_i || Ω^q_ij q_j)
          which == 'p' → KL(p_i || Ω^p_ij p_j)
      • No basis selection; basis is implicit in the fiber.
    """
    from runtime_context import cfg_get

    kappa = float(cfg_get(ctx, f"beta_kappa_{which}", 1.0))
    eps   = float(cfg_get(ctx, "obs_beta_eps", 1e-12))
    tau   = float(cfg_get(ctx, "support_tau", 1e-6))

    # Guard numerical stability
    kappa = max(kappa, 1e-12)

    return kappa, eps, tau





def _pre_checkpoint_cleanup(agents):
    """
    Drop/clear large transient caches so checkpoints stay small.
    Calls common methods if present; otherwise clears known attributes.
    Safe no-ops if attributes/methods don't exist.
    """
    for A in agents:
        # Try explicit compactors first
        for meth in (
            "compact_for_checkpoint",
            "clear_omega_cache",
            "clear_fisher_caches",
            "clear_transport_cache",
            "clear_theta_cache",
            "clear_misc_cache",
        ):
            if hasattr(A, meth):
                try:
                    getattr(A, meth)()
                except Exception:
                    pass

        # Then try to clear/delete typical cache attributes
        for attr in (
            "omega_cache",
            "fisher_cache",
            "transport_cache",
            "theta_cache",
            "misc_cache",
        ):
            if hasattr(A, attr):
                try:
                    obj = getattr(A, attr)
                    if hasattr(obj, "clear"):
                        obj.clear()
                    else:
                        setattr(A, attr, None)
                except Exception:
                    pass




def _extract_global_from_Q(Q) -> dict:
    """
    Accepts a dict-like or object 'Q' from compute_total_action(...) and
    returns ONLY numeric fields for logging. Skips strings/bools and metadata.
    Also supports tiny dicts like {'value': 1.23, 'w': 1, 'src': 'cached'}.
    """
   
    import numbers as _numbers

    def _is_num(x):
        # true for Python/NumPy numbers, false for bools
        if isinstance(x, (bool, np.bool_)):
            return False
        return isinstance(x, _numbers.Number) or (isinstance(x, np.generic) and np.issubdtype(type(x), np.number))

    def _coerce_num(x):
        # dict with 'value' → extract; tuple/list → first numeric element; else None
        if _is_num(x):
            return float(x)
        if isinstance(x, dict) and "value" in x and _is_num(x["value"]):
            return float(x["value"])
        if isinstance(x, (list, tuple)) and len(x) > 0 and _is_num(x[0]):
            return float(x[0])
        return None

    out = {}
    if Q is None:
        return out

    if isinstance(Q, dict):
        for k, v in Q.items():
            val = _coerce_num(v)
            if val is not None:
                out[k] = val
        return out

    # object-like fallback: pick common attributes if numeric
    for k in ("Action_total","Geom_total","VFE_acc","A_curv","A_cov","ModelPrior","Curv","Frame","Comm_KL","Transp_KL"):
        if hasattr(Q, k):
            val = _coerce_num(getattr(Q, k))
            if val is not None:
                out[k] = val
    return out





def log_and_viz_after_step(runtime_ctx, agents, step, outdir,
                           parent_metrics, metric_log, num_cores,
                           precomputed_metrics=None,
                           precomputed_Q=None):

    
    ctx = runtime_ctx
    from diagnostics import compute_global_metrics, print_energy_breakdown, total_energy
    cfg = getattr(ctx, "step_cfg", None)
    print_energy_every = int(getattr(cfg, "print_energy_every", 1) or 1)
    log_metrics_every  = int(getattr(cfg, "log_metrics_every", 1) or 1)
    
    rid   = int(getattr(ctx, "run_id", 1))
    rname = str(getattr(ctx, "run_label", f"run {rid}"))

    # ---- 1) reuse precomputed metrics OR compute once ----
    mg = precomputed_metrics if precomputed_metrics is not None else compute_global_metrics(ctx, agents)

    if (step % print_energy_every) == 0:
        print_energy_breakdown(ctx, mg)

    # ---- 2) reuse precomputed Q OR compute from metrics (no recompute of metrics) ----
    if precomputed_Q is None:
        E, terms = total_energy(ctx, agents, return_breakdown=True, precomputed_metrics=mg)
        Q = {"Action_total": float(E), **terms}
    else:
        Q = dict(precomputed_Q)

    # ---- 3) append to metric_log (throttled) ----
    if (step % log_metrics_every) == 0:
        metric_log.append({
            "run_id": rid,
            "run_name": rname,
            "run_label": rname,
            "step": int(getattr(ctx, "global_step", step)),

            # totals
            "E_total":    float(Q.get("Action_total", 0.0)),
            "mean_total": float(mg.get("mean_total", 0.0)),

            # weighted sums used in the action (fallbacks kept for robustness)
            "self_sum":       float(mg.get("self_sum_w",     mg.get("self_sum", 0.0))),
            "feedback_sum":   float(mg.get("feedback_sum_w", mg.get("feedback_sum", 0.0))),
            "align_q_sum":    float(mg.get("align_q_sum_w",  mg.get("align_q_sum", 0.0))),
            "align_p_sum":    float(mg.get("align_p_sum_w",  mg.get("align_p_sum", 0.0))),

            # NEW: gamma terms (already “weighted” by gamma; if diagnostics haven’t been patched yet,
            # fall back to raw sums or 0)
            "gamma_A_sum":    float(mg.get("gamma_A_sum_w",  mg.get("gamma_A_sum", 0.0))),
            "gamma_B_sum":    float(mg.get("gamma_B_sum_w",  mg.get("gamma_B_sum", 0.0))),
        })

   



def load_checkpoint(outdir: str):
    # prefer compressed if present
    for name in ("checkpoint.pkl.xz", "checkpoint.pkl.gz", "checkpoint.pkl"):
        p = os.path.join(outdir, name)
        if os.path.exists(p):
            if name.endswith(".xz"):
                import lzma
                with lzma.open(p, "rb") as f:
                    return pickle.load(f), name
            if name.endswith(".gz"):
                import gzip
                with gzip.open(p, "rb") as f:
                    return pickle.load(f), name
            with open(p, "rb") as f:
                return pickle.load(f), name

    # fall back to last step_XXXX
    step_files = sorted(
        f for f in os.listdir(outdir)
        if f.startswith("step_") and (f.endswith(".pkl") or f.endswith(".pkl.xz") or f.endswith(".pkl.gz"))
    )
    if not step_files:
        return (None, None)
    last = step_files[-1]
    p = os.path.join(outdir, last)
    if last.endswith(".xz"):
        import lzma
        with lzma.open(p, "rb") as f:
            return pickle.load(f), last
    if last.endswith(".gz"):
        import gzip
        with gzip.open(p, "rb") as f:
            return pickle.load(f), last
    with open(p, "rb") as f:
        return pickle.load(f), last


def find_resume_step(outdir: str) -> int:
    step_files = sorted(
        f for f in os.listdir(outdir)
        if f.startswith("step_") and (f.endswith(".pkl") or f.endswith(".pkl.xz") or f.endswith(".pkl.gz"))
    )
    if not step_files:
        return 0
    last = step_files[-1]
    num = (last.replace("step_", "")
               .replace(".pkl.xz", "")
               .replace(".pkl.gz", "")
               .replace(".pkl", ""))
    try:
        return int(num) + 1
    except Exception:
        return 0





# ------------------------------ Generator prep ------------------------------

# ------------------------------ Generator prep ------------------------------
def prepare_generators(ctx):
    """
    Resolve (Gq, Gp) in canonical shape (3, K, K), float32.

    Priority:
     
      1) SO(3) specs:    spec_q / spec_p (+ optional mix_generators_q / mix_generators_p)

    Side effect: writes K_q, K_p into ctx.config (runtime-scoped).
    """
    from core.get_generators import make_reducible_generators
    from runtime_context import cfg_get
    spec_q = cfg_get(ctx, "spec_q", None)
    spec_p = cfg_get(ctx, "spec_p", None)
        
    if (spec_q is None) or (spec_p is None):
        raise ValueError(
            "prepare_generators: provide either "
            "generators_q/generators_p, or so3_spec_q/so3_spec_p, "
            "or spec_q/spec_p in ctx/config."
        )
    mix_q = bool(cfg_get(ctx, "mix_generators_q", False))
    mix_p = bool(cfg_get(ctx, "mix_generators_p", False))
    
    Gq = make_reducible_generators(spec_q, mix=mix_q).astype(np.float32, copy=False)
    Gp = make_reducible_generators(spec_p, mix=mix_p).astype(np.float32, copy=False)
   
    # ---- record K into ctx.config (runtime-scoped) ----
    Kq, Kp = int(Gq.shape[1]), int(Gp.shape[1])
    rcfg = dict(getattr(ctx, "config", {}) or {})
    rcfg["K_q"] = Kq
    rcfg["K_p"] = Kp
    ctx.config = rcfg

    return Gq, Gp



# -------------------------- Init / resume helpers ---------------------------
def initialize_or_resume(outdir: str, resume: bool, runtime_ctx, clear_agent_logs: bool = True):
    """
    Initialize a fresh run or resume from checkpoints.
    Returns: (agents, step_start)
    """
    from core.agent_initialization import initialize_agents
    import core.config as config
    from runtime_context import cfg_get
    
    if resume:
        agents, _ = load_checkpoint(outdir)
        step_start = find_resume_step(outdir)
        return agents, int(step_start)

    # ---------- fresh init ----------
    if clear_agent_logs and os.path.isdir(outdir):
        # optional: wipe agent logs or temp dirs specific to a fresh start
        pass

    # Generators must be available; prefer those already persisted on ctx
    G_q = cfg_get(runtime_ctx, "generators_q", None)
    G_p = cfg_get(runtime_ctx, "generators_p", None)
    if (G_q is None) or (G_p is None):
        # compute from ctx-config and persist
        G_q, G_p = prepare_generators(runtime_ctx)
        rcfg = dict(getattr(runtime_ctx, "config", {}) or {})
        rcfg["generators_q"] = G_q
        rcfg["generators_p"] = G_p
        runtime_ctx.config = rcfg

    # ---- N-D domain size ----
    
    S_run = cfg_get(runtime_ctx, "domain_size", 0)
    # coerce to tuple of ints
   
    agents = initialize_agents(
        seed=cfg_get(runtime_ctx, "agent_seed", 0),
        domain_size=S_run,                     
        N=cfg_get(runtime_ctx, "N", config.N),
        lie_algebra_dim=cfg_get(runtime_ctx, "lie_algebra_dim", 3),
        fixed_location=cfg_get(runtime_ctx, "fixed_location", True),
        generators_q=G_q,
        generators_p=G_p,
    )

    step_start = 0
    return agents, step_start



def save_step(agents, outdir, step, *, save_every=1, compress=True):
    import os, pickle
    os.makedirs(outdir, exist_ok=True)
    if step is not None and (step % int(save_every)) != 0:
        return

    # prune big transient state before serializing
    try:
        _pre_checkpoint_cleanup(agents)
    except Exception:
        pass

    base = os.path.join(outdir, f"step_{(step if step is not None else 0):04d}.pkl")

    if compress:
        # Try LZMA first (lower preset for smaller working set), then fall back to gzip.
        try:
            import lzma
            with lzma.open(base + ".xz", "wb", preset=2) as f:  # preset=2 keeps memory modest
                pickle.dump(agents, f, protocol=pickle.HIGHEST_PROTOCOL)
            return
        except MemoryError:
            # Fall back to gzip (much smaller memory overhead) and still continue the run.
            import gzip
            with gzip.open(base + ".gz", "wb", compresslevel=1) as f:
                pickle.dump(agents, f, protocol=pickle.HIGHEST_PROTOCOL)
            return

    # Uncompressed as last resort
    with open(base, "wb") as f:
        pickle.dump(agents, f, protocol=pickle.HIGHEST_PROTOCOL)


  

def _write_metric_artifacts(outdir: str, metric_log: list[dict]):
    if not metric_log: return
    out = pathlib.Path(outdir)
    out.mkdir(parents=True, exist_ok=True)
    # pickle (legacy) + jsonl (human/tooling-friendly)
    with open(out / "metric_log.pkl", "wb") as f:
        pickle.dump(metric_log, f, protocol=pickle.HIGHEST_PROTOCOL)
    with open(out / "metrics.jsonl", "w", encoding="utf-8") as f:
        for rec in metric_log:
            f.write(json.dumps(rec, ensure_ascii=False) + "\n")

def wrap_epilogue(runtime_ctx, agents, outdir, parent_metrics, metric_log):
    # flush metrics & a lightweight “run.json” context stub
    try:
        _write_metric_artifacts(outdir, metric_log or [])
        with open(os.path.join(outdir, "run.json"), "w", encoding="utf-8") as f:
            json.dump({
                "steps": int(getattr(getattr(runtime_ctx, "config", {}), "steps", len(metric_log)) 
                             if hasattr(runtime_ctx, "config") else len(metric_log)),
                "global_step": int(getattr(runtime_ctx, "global_step", -1)),
            }, f)
    except Exception as e:
        print(f"[WRAP] failed to write artifacts: {e}")
















